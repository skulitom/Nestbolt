"""Disaggregate the four cog choices before interpreting the LP bound."""
from pathlib import Path
from datetime import datetime,timezone
import json,shutil,time,warnings
import numpy as np
from scipy.optimize import linprog
import solve_h5_area_relaxations as lp
ROOT=lp.ROOT;SRC=lp.OUT;OUT=ROOT/'output/h5-area-cog-conditioned-20261020'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    result=lp.load(SRC/'with-area/result.json')
    assert result['exact_bound']['integer_insert_upper_bound']==21
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):lp.digest(p) for p in [SRC/'plan.json',SRC/'preparation.json',SRC/'translation-audit.json',SRC/'with-area/result.json',SRC/'with-area/solution.npz']},
        'reason':'The area-augmented LP has nonzero mass on three mutually exclusive cog arrangements. Fix each of the four original arrangements in turn, preserving every area cut, family count, candidate and conflict. The four cases partition the binary cog-choice requirement; they are new restricted relaxations, not repeated integer searches.',
        'cases':[0,1,2,3],'LP_seconds_limit_each':120,'LP_threads':8,'LP_seed':0,
        'certificate':'The existing exact dual-bound identity includes the new four cog-fixing inequalities. A fractional solution is not a layout; infeasible or timed-out cases without a verified certificate must not support a global impossibility claim.',
        'native_packing_calls':0,'quality_runs':0}
    lp.write(OUT/'plan.json',plan)
    for name,h in lp.load(SRC/'preparation.json')['prepared_hashes'].items():assert lp.digest(SRC/name)==h
    obj=lp.load(SRC/'objective.json');ub=lp.rows(SRC/'inequalities.jsonl.gz')+lp.rows(SRC/'area-cuts.jsonl.gz')
    eq=lp.rows(SRC/'equalities.jsonl.gz');n=len(obj);E=lp.matrix(eq,n);d=np.asarray([r['rhs'] for r in eq],dtype=float)
    summaries=[]
    for si in plan['cases']:
        path=OUT/f'case-{si}';path.mkdir()
        fixes=[{'indices':[j],'coeffs':[-1 if j==si else 1],'rhs':-1 if j==si else 0,'kind':'fixed-cog-choice'} for j in range(4)]
        current=ub+fixes;A=lp.matrix(current,n);b=np.asarray([r['rhs'] for r in current],dtype=float)
        lp.write(path/'fixes.json',fixes);lp.write(path/'started.json',{'utc':datetime.now(timezone.utc).isoformat()})
        t0=time.perf_counter()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            result=linprog(np.asarray(obj,dtype=float),A_ub=A,b_ub=b,A_eq=E,b_eq=d,bounds=(0,1),method='highs-ds',
                options={'time_limit':120.,'presolve':True,'threads':8,'random_seed':0})
        record={'case':si,'status':int(result.status),'success':bool(result.success),'message':result.message,
            'seconds':time.perf_counter()-t0,'iterations':int(result.nit),'warnings':[str(w.message) for w in caught],
            'physical_layout_found':False}
        if result.x is not None:
            x=result.x;assert np.max(A@x-b)<1e-5 and np.max(abs(E@x-d))<1e-5 and min(x)>-1e-6 and max(x)<1+1e-6
            assert all(abs(x[j]-int(si==j))<1e-7 for j in range(4))
            record.update(objective_inserts=float(-result.fun),fractional_variables=int(np.count_nonzero((x>1e-7)&(x<1-1e-7))))
            np.savez_compressed(path/'solution.npz',x=x,inequality_marginals=result.ineqlin.marginals,equality_marginals=result.eqlin.marginals)
            if result.success:
                certificate=lp.exact_upper_bound(obj,current,eq,result.ineqlin.marginals,result.eqlin.marginals)
                lp.write(path/'exact-bound.json',certificate);record['exact_bound']=certificate
        lp.write(path/'result.json',record);summaries.append(record);print(json.dumps(record),flush=True)
    lp.write(OUT/'results.json',summaries)
if __name__=='__main__':main()
