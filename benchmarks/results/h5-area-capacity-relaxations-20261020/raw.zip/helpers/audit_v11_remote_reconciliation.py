from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,sys,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/v1-1-reconcile-20261020'
sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    head=git('rev-parse','HEAD').decode().strip()
    local=git('rev-parse','HEAD^1').decode().strip();remote=git('rev-parse','HEAD^2').decode().strip()
    assert local=='3172d02703bc0217e5af19a37baea1621856739f' and remote=='36edfbd3d142281b8b12829626f73c50b709e33c'
    base=git('merge-base',local,remote).decode().strip()
    ours=git('diff','--name-only',base,local).decode().splitlines()
    theirs=git('diff','--name-only',base,remote).decode().splitlines()
    assert len(ours)==21 and len(theirs)==29 and not set(ours)&set(theirs)
    for rev,paths in [(local,ours),(remote,theirs)]:
        for p in paths:assert git('show',head+':'+p)==git('show',rev+':'+p)==(ROOT/p).read_bytes(),p
    assert git('show',head+':BENCHMARKS.md').startswith(git('show',remote+':BENCHMARKS.md'))
    assert source_digest()=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
    checks={}
    for run,name,sha in [
        ('39394387011','c824e5a-checks','c824e5a6060028eb4f71800faa2ed6190aff1abe'),
        ('39399961638','36edfbd-checks',remote),('39404776369','36edfbd-pages',remote)]:
        value=json.loads(subprocess.check_output(['gh','run','view',run,'--json','name,status,conclusion,headSha,jobs,url'],cwd=ROOT))
        assert value['headSha']==sha and value['status']=='completed' and value['conclusion']=='success'
        assert all(j['conclusion']=='success' for j in value['jobs'])
        write(OUT/(name+'.json'),value);checks[name]=value['url']
    readmes={n:sha256((ROOT/n).read_bytes()).hexdigest() for n in ['README.md','README.ja.md','README.zh-CN.md']}
    write(OUT/'checks.json',{'verified_utc':datetime.now(timezone.utc).isoformat(),'merge_commit':head,'parents':[local,remote],
        'common_base':base,'local_changed_paths':ours,'remote_changed_paths':theirs,'all_50_changed_files_exactly_preserved':True,
        'benchmark_append_only':True,'core_source_unchanged':True,'current_readmes':readmes,'hosted_checks':checks,
        'push_history':'Initial ordinary push of 3172d02 was rejected non-fast-forward after origin/main advanced. No force push or remote overwrite. Merge preserves both histories.',
        'hosted_browser':'36edfbd Pages deployment passes; the merged READMEs identify the hosted browser as a main preview. Earlier v0.1.0-hosted statements are historical.',
        'H2_complete':False,'H5_complete':False,'completion_percent':60})
    subprocess.run(['git','diff',base,head,'--check'],cwd=ROOT,check=True)
    print(json.dumps({'merge_commit':head,'preserved_files':len(ours)+len(theirs),'all_three_hosted_runs_pass':True,'core_source_unchanged':True}),flush=True)
if __name__=='__main__':main()
