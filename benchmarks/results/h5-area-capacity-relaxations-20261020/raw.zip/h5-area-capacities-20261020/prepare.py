"""Necessary area capacities; audit every positive coefficient by rational clipping."""
from pathlib import Path
from fractions import Fraction
from datetime import datetime,timezone
from hashlib import sha256
import gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import box
import audit_h5_cog_lattices as geometry
ROOT=geometry.ROOT; SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
OUT=ROOT/'output/h5-area-capacities-20261020'
load=geometry.load;write=geometry.write;digest=geometry.digest

def fraction_area(vertices,bounds):
    """Clip a polygon's oriented boundary to four exact rational half-planes."""
    points=[(Fraction(x),Fraction(y)) for x,y in vertices]
    for axis,edge,greater in [(0,bounds[0],True),(0,bounds[2],False),(1,bounds[1],True),(1,bounds[3],False)]:
        edge=Fraction(edge); result=[]
        if not points:return Fraction(0)
        previous=points[-1]; previous_in=previous[axis]>=edge if greater else previous[axis]<=edge
        for point in points:
            inside=point[axis]>=edge if greater else point[axis]<=edge
            if inside!=previous_in:
                t=(edge-previous[axis])/(point[axis]-previous[axis])
                result.append((previous[0]+t*(point[0]-previous[0]),previous[1]+t*(point[1]-previous[1])))
            if inside:result.append(point)
            previous,previous_in=point,inside
        points=result
    return abs(sum((a[0]*b[1]-a[1]*b[0] for a,b in zip(points,points[1:]+points[:1])),Fraction(0)))/2

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    sourcefiles=[SRC/n for n in ['job.json','candidates.json','cog-skeletons.json','conditional-target.json','mapping.json','model.pbtxt','model-audit.json','projected-cliques.jsonl.gz','audit/checks.json']]
    sealed=load(ROOT/'benchmarks/results/h5-coordinated-contact-selection-20261020/raw-manifest.json')
    sealedhashes={r['path']:r['sha256'] for r in sealed['files']}
    for p in sourcefiles:assert digest(p)==sealedhashes[SRC.name+'/'+p.relative_to(SRC).as_posix()]
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sourcefiles},
        'method':'Compare two continuous relaxations of the verified finite placement model: original conflict cliques, then the same model plus necessary local filled-area capacities. No integer search and no new placements. Selectable cog groups contribute the sum of all fifteen original cog intersections. Frames reserve their holes. Both sheets use original margins, edge clearance and height target.',
        'regions':'For each sheet, the whole usable stock plus equal horizontal and vertical dyadic partitions into 2, 4 and 8 bands. Deduplicate identical full-stock rectangles: 29 regions per sheet, 58 total.',
        'rounding':'Each coefficient is max(0, floor(GEOS intersection area minus 0.000001 mm2)); capacity is ceil(region area plus 0.000001 mm2). Every positive coefficient is independently bounded below its exact rational clipped area, treating original transformed binary64 vertices as exact. Capacity is checked above exact rational rectangle area. Zero coefficients are trivially conservative.',
        'objective':'Maximize inserts from 13 to original 21, with exactly 18 frames, 12 brackets and one complete 15-cog arrangement. All variables relaxed to [0,1]. Fractional solutions are never layouts.',
        'LP_seconds_limit_each':120,'LP_method':'highs-ds','LP_threads':8,'LP_seed':0,
        'certificate':'Verify a safe upper bound using exact integer arithmetic over the returned binary64 dual multipliers and integer coefficients; no reliance on rounded solver objective alone.',
        'native_packing_calls':0,'quality_runs':0,'original_quantities_and_acceptance_unchanged':True})
    job=load(SRC/'job.json');pool=load(SRC/'candidates.json');mp=load(SRC/'mapping.json');sets=load(SRC/'cog-skeletons.json')['sets'];target=load(SRC/'conditional-target.json')
    parts={p['id']:p for p in job['parts']};st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance']
    geoms=np.asarray([geometry.shape(parts[p['placement']['part_id']],p['placement']['transform']) for p in pool],dtype=object)
    sheets=[p['placement']['sheet_id'] for p in pool];vertices=[list(g.exterior.coords)[:-1] for g in geoms]
    vi={r['candidate']:r['var'] for r in mp['candidates']};n=len(vi)+4
    warmset=set(mp['warm_candidates']);warm=[int(i==mp['warm_skeleton']) for i in range(4)]+[int(i in warmset) for i in vi]
    regions=[]
    for sheet in ['sheet-0','sheet-1']:
        top=st['height'] if sheet=='sheet-0' else target['required_used_height_mm']
        bounds=[m['left']+edge,m['bottom']+edge,st['width']-m['right']-edge,top-m['top']-edge]
        regions.append({'sheet':sheet,'axis':'whole','divisions':1,'band':0,'bounds':bounds})
        for axis in [0,1]:
            for divisions in [2,4,8]:
                cuts=[bounds[axis]+(bounds[axis+2]-bounds[axis])*k/divisions for k in range(divisions+1)]
                for k in range(divisions):
                    b=bounds.copy();b[axis]=cuts[k];b[axis+2]=cuts[k+1]
                    regions.append({'sheet':sheet,'axis':axis,'divisions':divisions,'band':k,'bounds':b})
    assert len(regions)==58
    ub=[];eq=[{'indices':[0,1,2,3],'coeffs':[1]*4,'rhs':1,'kind':'one-cog-arrangement'}]
    for r in mp['candidates']:
        if len(r['compatible_skeletons'])<4:
            terms=sorted([(si,-1) for si in r['compatible_skeletons']]+[(r['var'],1)])
            ub.append({'indices':[i for i,c in terms],'coeffs':[c for i,c in terms],'rhs':0,'kind':'cog-compatibility'})
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            ids=json.loads(line);ub.append({'indices':[vi[i] for i in ids],'coeffs':[1]*len(ids),'rhs':1,'kind':'conflict-clique'})
    objective=[0]*n
    for part in job['parts']:
        if part['id']=='cog':continue
        ids=[vi[i] for i in vi if pool[i]['placement']['part_id']==part['id']]
        if part['id']=='insert':
            for i in ids:objective[i]=-1
            ub.extend([{'indices':ids,'coeffs':[1]*len(ids),'rhs':21,'kind':'maximum-inserts'},
                       {'indices':ids,'coeffs':[-1]*len(ids),'rhs':-13,'kind':'minimum-inserts'}])
        else:eq.append({'indices':ids,'coeffs':[1]*len(ids),'rhs':part['quantity'],'kind':'exact-'+part['id']})
    rows=[];rationalchecks=0;minimum_slack=math.inf;maximum_area_error=0.
    for ri,region in enumerate(regions):
        b=region['bounds'];rect=box(*b);same=[i for i in range(len(pool)) if sheets[i]==region['sheet']]
        areas=np.zeros(len(pool));areas[same]=shapely.area(shapely.intersection(geoms[same],rect))
        exact_cache={}
        def exact(i):
            if i not in exact_cache:exact_cache[i]=fraction_area(vertices[i],b)
            return exact_cache[i]
        coefficients={}
        for si,s in enumerate(sets):
            ids=[i for i in s['candidates'] if sheets[i]==region['sheet']]
            approx=sum(areas[i] for i in ids);coefficient=max(0,math.floor(approx-1e-6))
            if coefficient:
                true=sum((exact(i) for i in ids),Fraction(0));assert coefficient<=true
                maximum_area_error=max(maximum_area_error,abs(float(true)-approx));rationalchecks+=1;coefficients[si]=coefficient
        for i,v in vi.items():
            coefficient=max(0,math.floor(areas[i]-1e-6))
            if coefficient:
                true=exact(i);assert coefficient<=true
                maximum_area_error=max(maximum_area_error,abs(float(true)-areas[i]));rationalchecks+=1;coefficients[v]=coefficient
        true_capacity=(Fraction(b[2])-Fraction(b[0]))*(Fraction(b[3])-Fraction(b[1]))
        capacity=math.ceil(rect.area+1e-6);assert capacity>=true_capacity
        ids=sorted(coefficients);row={'indices':ids,'coeffs':[coefficients[i] for i in ids],'rhs':capacity,'kind':'local-area','region':ri}
        slack=capacity-sum(c*warm[i] for i,c in coefficients.items());assert slack>=0;minimum_slack=min(minimum_slack,slack);rows.append(row)
    for row in ub:assert sum(c*warm[i] for i,c in zip(row['indices'],row['coeffs']))<=row['rhs']
    for row in eq:assert sum(c*warm[i] for i,c in zip(row['indices'],row['coeffs']))==row['rhs']
    for name,records in [('inequalities.jsonl.gz',ub),('equalities.jsonl.gz',eq),('area-cuts.jsonl.gz',rows)]:
        with gzip.open(OUT/name,'xt',encoding='utf-8',newline='\n') as f:
            for row in records:f.write(json.dumps(row)+'\n')
    write(OUT/'regions.json',regions);write(OUT/'objective.json',objective);write(OUT/'warm.json',warm)
    result={'variables':n,'base_inequalities':len(ub),'equalities':len(eq),'area_cuts':len(rows),'positive_coefficients_exactly_audited':rationalchecks,
        'maximum_GEOS_area_discrepancy_mm2':maximum_area_error,'minimum_integer_hint_slack_mm2':minimum_slack,
        'complete_partial_hint_feasible':True,'rounding_conservative':True,'seconds':time.perf_counter()-start,
        'prepared_hashes':{name:digest(OUT/name) for name in ['inequalities.jsonl.gz','equalities.jsonl.gz','area-cuts.jsonl.gz','objective.json','warm.json','regions.json']}}
    write(OUT/'preparation.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':main()
