"""Separate Fraction-based dual-bound reconstruction and saved primal checks."""
from pathlib import Path
from fractions import Fraction
import json,math,shutil
import numpy as np
import solve_h5_area_relaxations as base
ROOT=base.ROOT;OUT=base.OUT;CASES=ROOT/'output/h5-area-cog-conditioned-20261020'
def verify(path,ub,eq,obj):
    result=base.load(path/'result.json');assert result['success'] and result['status']==0
    saved=np.load(path/'solution.npz');x=saved['x'];assert len(x)==len(obj)
    y=[Fraction(min(0.,float(v))) for v in saved['inequality_marginals']]
    z=[Fraction(float(v)) for v in saved['equality_marginals']]
    assert len(y)==len(ub) and len(z)==len(eq)
    assert np.min(x)>-1e-6 and np.max(x)<1+1e-6
    max_ineq=0.;max_eq=0.
    for row in ub:
        max_ineq=max(max_ineq,math.fsum(float(x[i])*c for i,c in zip(row['indices'],row['coeffs']))-row['rhs'])
    for row in eq:
        max_eq=max(max_eq,abs(math.fsum(float(x[i])*c for i,c in zip(row['indices'],row['coeffs']))-row['rhs']))
    assert max_ineq<1e-5 and max_eq<1e-5
    costs=list(map(Fraction,obj));dual_constant=Fraction(0)
    for row,weight in zip(ub+eq,y+z):
        if not weight:continue
        dual_constant+=weight*row['rhs']
        for i,c in zip(row['indices'],row['coeffs']):costs[i]-=weight*c
    lower=dual_constant+sum((min(Fraction(0),c) for c in costs),Fraction(0))
    certificate=base.load(path/'exact-bound.json');upper=-lower
    assert upper==Fraction(int(certificate['numerator']),int(certificate['denominator']))
    objective=-math.fsum(c*float(v) for c,v in zip(obj,x));assert abs(objective-result['objective_inserts'])<1e-6
    fractional=int(np.count_nonzero((x>1e-7)&(x<1-1e-7)));assert fractional==result['fractional_variables'] and fractional>0
    if 'case' in result:
        assert all(abs(x[i]-int(result['case']==i))<1e-7 for i in range(4))
    return {'path':str(path.relative_to(ROOT)),'seconds':result['seconds'],'fractional_variables':fractional,
        'cog_choice_values':x[:4].tolist(),'objective_inserts':objective,'exact_upper_bound':str(upper),
        'integer_insert_upper_bound':upper.numerator//upper.denominator,
        'maximum_primal_inequality_violation':max_ineq,'maximum_primal_equality_violation':max_eq,
        'nonzero_dual_inequalities':sum(bool(v) for v in y),'all_saved_values_verified':True,'physical_layout':False}
def main():
    shutil.copyfile(__file__,OUT/'audit-results.py')
    prep=base.load(OUT/'preparation.json')
    for name,h in prep['prepared_hashes'].items():assert base.digest(OUT/name)==h
    for name,h in base.load(CASES/'plan.json')['inputs'].items():assert base.digest(ROOT/name)==h
    ub=base.rows(OUT/'inequalities.jsonl.gz');eq=base.rows(OUT/'equalities.jsonl.gz')
    area=base.rows(OUT/'area-cuts.jsonl.gz');obj=base.load(OUT/'objective.json')
    results=[verify(OUT/'original',ub,eq,obj),verify(OUT/'with-area',ub+area,eq,obj)]
    for si in range(4):
        path=CASES/f'case-{si}';fixes=base.load(path/'fixes.json')
        assert fixes==[{'indices':[j],'coeffs':[-1 if j==si else 1],'rhs':-1 if j==si else 0,'kind':'fixed-cog-choice'} for j in range(4)]
        results.append(verify(path,ub+area+fixes,eq,obj))
    assert all(r['exact_upper_bound']=='21' for r in results)
    report={'results':results,'exact_certificates_independently_reconstructed':6,
        'area_cuts_tighten_insert_bound':False,'conditioning_tightens_insert_bound':False,
        'no_complete_layout_or_infeasibility_proof':True,'no_integer_search_repeated':True,
        'native_packing_calls':0,'quality_runs':0}
    base.write(OUT/'result-audit.json',report);print(json.dumps(report),flush=True)
if __name__=='__main__':main()
