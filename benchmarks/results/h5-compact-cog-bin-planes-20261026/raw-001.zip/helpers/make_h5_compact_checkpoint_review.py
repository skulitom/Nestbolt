from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_band_linked_phase_checkpoint.py').read_text(encoding='utf-8')
s=s.replace('h5-band-linked-phase-checkpoint-review-20261026','h5-compact-cog-checkpoint-review-20261026').replace('50cdc07ecf823e0e02b0c256b41d026de1427b41','7271cc8beb5caae3a3dced77d129ffcdcb1ec7ed')
ast.parse(s)
with (ROOT/'output/review_h5_compact_checkpoint.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
