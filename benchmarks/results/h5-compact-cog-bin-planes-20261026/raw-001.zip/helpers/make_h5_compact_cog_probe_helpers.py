from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
for name in ['run_h5_eight_phase_balanced_probe.py','audit_h5_eight_phase_balanced_response.py']:
    s=(ROOT/'output'/name).read_text(encoding='utf-8');old="BASE=ROOT/'output/h5-eight-phase-balanced-probe-20261026'";assert old in s;s=s.replace(old,"BASE=ROOT/'output/h5-compact-cog-plane-probe-20261026'")
    if name.startswith('audit'):
        old='A negative is limited to this nine-part profile-group composition/eight declared cog angles and both insert choices, requiring at least one new-phase cog/grid and conservative source guards; UNKNOWN excludes nothing.'
        assert old in s;s=s.replace(old,'A negative is limited to the compact sufficient bin-plane construction, eight declared cog angles and both insert choices with at least one new-phase cog, grid and source guards. It cannot exclude the full source family; UNKNOWN excludes nothing.')
    ast.parse(s)
    with (ROOT/'output'/name.replace('eight_phase_balanced','compact_cog')).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'created_helpers':2,'all_helpers_parse':True})
