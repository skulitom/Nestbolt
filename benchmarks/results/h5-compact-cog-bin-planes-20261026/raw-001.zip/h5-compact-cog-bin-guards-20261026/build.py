"""Certify sufficient cog separation for entire relative-Y bins using exact source planes."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,math,shutil,time
from shapely.geometry import box,shape
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';BINS=ROOT/'output/h5-relative-y-cog-spacing-20261026';OUT=ROOT/'output/h5-compact-cog-bin-guards-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def ceildiv(a,b):return -((-a)//b)
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240
assert load(SOURCE/'audit/checks.json')['passed'] and load(BINS/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');binplan=load(BINS/'plan.json');phases=spec['allowed_profiles'][5];bounds=spec['anchor_bounds_units1000'];cases=[c for c in spec['mutual_cases'] if c['profile_a'] in phases and c['profile_b'] in phases]
paths=[SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',BINS/'plan.json',BINS/'audit/checks.json']+[SOURCE/'mutual'/f"{c['index']:03d}.json" for c in cases]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'phases':phases,'bins_units1000':binplan['bins_units1000'],'construction_limit_seconds':240,'method':'For each ordered cog phase pair and every complete2mm relative-Y bin, intersect the bin with its source stock-relative Y interval. For each exact original source convex-face clause, find an edge whose rounded outside-plane inequality holds on the entire rectangle deltaX=D..maximum-stock-deltaX, deltaY=clipped-bin. Positive-X normals yield an exact integer threshold; nonpositive normals either hold on the whole stock rectangle or cannot establish this proof. Set D to the largest face threshold. The resulting per-bin X bound implies every original source face clause, not merely clearance of sampled points. Independently verify every full-rectangle corner against its chosen source edge and geometric separation from the guarded source obstacle. Empty right rectangles simply make that phase/bin choice infeasible. This sufficient construction can exclude valid original source points, so negative results do not exclude the full source family. No solver call.'})
rows=[];edge_checks=0
for c in cases:
    assert time.perf_counter()<deadline
    pa,pb=c['profile_a'],c['profile_b'];aa,bb=bounds[str(pa)],bounds[str(pb)];ylo,yhi=bb[1]-aa[3],bb[3]-aa[1];xmax=bb[2]-aa[0];source=load(SOURCE/'mutual'/f"{c['index']:03d}.json");guard=shape(source['expanded_forbidden'])
    for ordinal,(a,b) in enumerate(binplan['bins_units1000']):
        low,high=max(a,ylo),min(b,yhi)
        if low>high:continue
        face_proofs=[]
        for f in source['faces']:
            candidates=[]
            for j,h in enumerate(f['outside_halfplanes']):
                A,B,C=h['a'],h['b'],h['bound'];edge_checks+=1;y=low if B>=0 else high
                if A>0:candidates.append((max(0,ceildiv(C-B*y,A)),j))
                elif A*xmax+B*y>=C:candidates.append((0,j))
            assert candidates
            threshold,edge=min(candidates);face_proofs.append({'face':f['index'],'edge':edge,'minimum_dx_units1000':threshold})
        D=max(r['minimum_dx_units1000'] for r in face_proofs);empty=D>xmax
        margin=None
        if not empty:
            rectangle=box(D/1000,low/1000,xmax/1000,high/1000);margin=guard.distance(rectangle);assert guard.disjoint(rectangle) and margin>1e-8
        rows.append({'profiles':[pa,pb],'source_case':c['index'],'bin':ordinal,'relative_y_units1000':[low,high],'maximum_dx_units1000':xmax,'sufficient_dx_units1000':D,'face_proofs':face_proofs,'right_rectangle_empty':empty,'guarded_geometry_margin_mm':margin})
    if len(rows)%100<35:print({'completed_source_case':c['index'],'rows':len(rows),'seconds':time.perf_counter()-start},flush=True)
assert len(rows)==2191
write(OUT/'guards.json',rows);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'ordered_cog_pairs':64,'relative_y_bins':35,'complete_pair_bin_guards':len(rows),'exact_source_plane_candidates':edge_checks,'all_source_faces_proved':sum(len(r['face_proofs']) for r in rows),'empty_right_rectangles':sum(r['right_rectangle_empty'] for r in rows),'minimum_sufficient_dx_mm':min(r['sufficient_dx_units1000'] for r in rows)/1000,'maximum_sufficient_dx_mm':max(r['sufficient_dx_units1000'] for r in rows)/1000,'minimum_guarded_geometry_margin_mm':min(r['guarded_geometry_margin_mm'] for r in rows if not r['right_rectangle_empty']),'construction_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
