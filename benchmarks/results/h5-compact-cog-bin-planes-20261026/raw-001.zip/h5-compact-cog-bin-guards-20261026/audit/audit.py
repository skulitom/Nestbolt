"""Independent exact-corner proof that every compact cog bin implies every source face."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,math,shutil,time
from shapely.geometry import box,shape
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-compact-cog-bin-guards-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();deadline=start+240
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'audit_limit_seconds':240,'method':'Derive every global relative-Y bin and clipped phase pair interval independently from source stock bounds. Recompute each face threshold by exact Fraction arithmetic, then evaluate the selected rounded source plane at all four corners of the entire right rectangle. Require every source face covered by its specific proof and independently check the whole right rectangle is disjoint from the guarded collision obstacle. Every compact witness therefore extends to all removed source clauses by setting the original shared flags from plane truth. This is sufficient, not equivalent: a negative cannot exclude the full source family. No solver.'})
s=load(BASE/'plan.json')
for n,h in s['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];source=load(SOURCE/'plan.json');phases=source['allowed_profiles'][5];bounds=source['anchor_bounds_units1000'];assert source['allowed_profiles'][5:]==[phases]*4 and s['phases']==phases
low=min(bounds[str(p)][1] for p in phases);high=max(bounds[str(p)][3] for p in phases);bins=[[a,min(a+1999,high-low)] for a in range(low-high,high-low+1,2000)];assert bins==s['bins_units1000'] and len(bins)==35
rows=load(BASE/'guards.json');seen=set();face_count=corner_count=0;details=[]
for pa,pb in product(phases,repeat=2):
    assert time.perf_counter()<deadline
    case=next(c['index'] for c in source['mutual_cases'] if [c['profile_a'],c['profile_b']]==[pa,pb]);datum=load(SOURCE/'mutual'/f'{case:03d}.json');guard=shape(datum['expanded_forbidden']);aa,bb=bounds[str(pa)],bounds[str(pb)];ylo,yhi=bb[1]-aa[3],bb[3]-aa[1];xmax=bb[2]-aa[0];following=ylo
    for ordinal,(a,b) in enumerate(bins):
        low,high=max(a,ylo),min(b,yhi)
        if low>high:continue
        matching=[r for r in rows if r['profiles']==[pa,pb] and r['bin']==ordinal];assert len(matching)==1;r=matching[0];assert r['relative_y_units1000']==[low,high] and r['source_case']==case and r['maximum_dx_units1000']==xmax and low==following;following=high+1;seen.add((pa,pb,ordinal));proofs=[]
        for f in datum['faces']:
            candidates=[]
            for j,h in enumerate(f['outside_halfplanes']):
                A,B,C=h['a'],h['b'],h['bound'];term=min(B*low,B*high)
                if A>0:candidates.append((max(0,math.ceil(F(C-term,A))),j))
                elif min(A*x+B*y for x,y in product([0,xmax],[low,high]))>=C:candidates.append((0,j))
            assert candidates;threshold,edge=min(candidates);proofs.append({'face':f['index'],'edge':edge,'minimum_dx_units1000':threshold})
        assert proofs==r['face_proofs'];D=max(v['minimum_dx_units1000'] for v in proofs);assert D==r['sufficient_dx_units1000'] and r['right_rectangle_empty']==(D>xmax)
        if D<=xmax:
            for proof,f in zip(proofs,datum['faces']):
                assert proof['face']==f['index'];h=f['outside_halfplanes'][proof['edge']]
                for x,y in product([D,xmax],[low,high]):assert h['a']*x+h['b']*y>=h['bound'];corner_count+=1
            rectangle=box(D/1000,low/1000,xmax/1000,high/1000);margin=guard.distance(rectangle);assert guard.disjoint(rectangle) and margin>1e-8 and abs(margin-r['guarded_geometry_margin_mm'])<1e-10
        else:assert r['guarded_geometry_margin_mm'] is None
        face_count+=len(proofs);details.append({'profiles':[pa,pb],'bin':ordinal,'source_faces_proved':len(proofs),'sufficient_dx_units1000':D,'passed':True})
    assert following==yhi+1
assert len(rows)==len(seen)==2191
write(OUT/'case-checks.json',details);write(OUT/'implication.json',{'compact_witness_implies_full_source_witness':True,'reverse_implication_claimed':False,'negative_excludes_full_source_family':False,'statement':'The chosen angle pair and exact relative-Y bin identify a certified full source rectangle. The conditional compact X threshold places each cog-pair difference inside that rectangle. Every original rounded source face clause has a named edge holding over the entire rectangle by exact corner checks. Set each removed source plane flag to its actual truth value; all original face ORs hold while retained constraints are unchanged. Some source points can fail the compact threshold, so a compact negative is narrower than a full source negative.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'ordered_cog_pairs':64,'complete_pair_bin_guards':2191,'source_face_proofs_checked':face_count,'exact_source_plane_corner_checks':corner_count,'all_relative_y_values_covered':True,'compact_witness_implies_full_source':True,'equivalent_source_feasibility_claimed':False,'audit_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
