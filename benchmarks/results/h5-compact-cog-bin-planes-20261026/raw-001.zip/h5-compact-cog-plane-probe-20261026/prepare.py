"""Replace only cog-pair source clauses with independently proved compact bin planes."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-eight-phase-balanced-probe-20261026';DATA=ROOT/'output/h5-compact-cog-bin-planes-20261026';OUT=ROOT/'output/h5-compact-cog-plane-probe-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def lit(v,remap):
    old=v if v>=0 else -v-1;new=remap[old];assert new>=0;return new if v>=0 else -new-1
def remapped(c,remap):
    copy=cp_model_pb2.ConstraintProto();copy.CopyFrom(c);copy.enforcement_literal[:]=[lit(v,remap) for v in c.enforcement_literal];kind=c.WhichOneof('constraint')
    if kind=='linear':copy.linear.vars[:]=[remap[v] for v in c.linear.vars];assert all(v>=0 for v in copy.linear.vars)
    else:assert kind=='bool_or';copy.bool_or.literals[:]=[lit(v,remap) for v in c.bool_or.literals]
    return copy
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'] and load(PARENT/'search/000/result.json')['status']=='UNKNOWN' and load(DATA/'audit/checks.json')['passed']
paths=[PARENT/n for n in ['plan.json','models/000.pb','models/000-mapping.json','profile-flags.json','shared-planes.json','cell-selectors.json','cell-groups.json','spacing-constraints.json','inventory.json','model-audit/checks.json','model-audit/source-extension-proof.json','response-audit/checks.json','search/000/result.json']]+[p for p in DATA.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'maximum_calls':1,'solver_seconds':45,'shared_seconds':60,'workers':4,'seed':0,'method':'Remove exactly the148074 shared plane flags and their implication constraints for cog/cog pairs, plus exactly3660 corresponding face OR clauses. Retain every original coordinate, angle flag, stock/count/symmetry constraint, other pair clause, vertical-cell selector, area bound and existing spacing bound, remapping variable indices without changing fields. Add35 complete relative-Y bins for each of six cog pairs and the independently proved undominated sloping source planes, enforced by both angle flags and the selected bin. These sufficient requirements imply every removed original cog face; they may exclude some full-source layouts, so negative scope is restricted to the compact construction. No optional original, fixed pose or hint. No flat-bound or intermediate solve. Independently reconstruct all deletions, retained fields and new constraints before one45solver/60shared4worker seed0 call. All prior UNKNOWN calls remain closed.'})
parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'models/000.pb').read_bytes());assert {f.name for f,v in parent.ListFields()}=={'variables','constraints'}
planes=load(PARENT/'shared-planes.json');maps=load(PARENT/'models/000-mapping.json');removed={r['flag'] for r in planes if min(r['parts'])>=5};assert len(removed)==148074
or_counts=Counter()
for mode in maps:
    if min(mode['parts'])<5:continue
    for f in mode['faces']:
        if f.get('tautological'):continue
        c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-v-1 for v in mode['active']]+f['shared_flags']);or_counts[c.SerializeToString()]+=1
assert sum(or_counts.values())==3660
remap=[];kept_variables=[];m=cp_model_pb2.CpModelProto()
for i,v in enumerate(parent.variables):
    if i in removed:remap.append(-1)
    else:remap.append(len(m.variables));kept_variables.append(i);m.variables.add().CopyFrom(v)
kept_constraints=[];dropped=[]
for i,c in enumerate(parent.constraints):
    if c.WhichOneof('constraint')=='linear' and len(c.enforcement_literal)==1 and c.enforcement_literal[0] in removed:
        dropped.append({'parent_constraint':i,'kind':'cog-plane'});continue
    key=c.SerializeToString()
    if c.WhichOneof('constraint')=='bool_or' and or_counts[key]:or_counts[key]-=1;dropped.append({'parent_constraint':i,'kind':'cog-face'});continue
    kept_constraints.append(i);m.constraints.add().CopyFrom(remapped(c,remap))
assert not +or_counts and Counter(r['kind'] for r in dropped)=={'cog-plane':148074,'cog-face':3660};nv,nc=len(m.variables),len(m.constraints);assert (nv,nc)==(85489,88493)
flags={i:{p:remap[v] for p,v in f.items()} for i,f in load(PARENT/'profile-flags.json').items()};spec=load(DATA/'plan.json');rows=load(DATA/'guards.json');selectors=[];requirements=[]
for a,b in combinations(range(5,9),2):
    ids=[]
    for ordinal,(low,high) in enumerate(spec['bins_units1000']):
        v=len(m.variables);m.variables.add(name=f'pair-{a}-{b}-relative-y-bin{ordinal}',domain=[0,1]);c=m.constraints.add();c.enforcement_literal.append(v);c.linear.vars.extend([2*a+1,2*b+1]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([low,high]);ids.append(v);selectors.append({'parts':[a,b],'bin':ordinal,'variable':v,'relative_y_units1000':[low,high]})
    c=m.constraints.add();c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([1,1])
    for r in rows:
        pa,pb=r['profiles']
        for j,h in enumerate(r['requirements']):
            terms={2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']};variables=sorted(v for v,k in terms.items() if k);c=m.constraints.add();c.enforcement_literal.extend([flags[str(a)][str(pa)],flags[str(b)][str(pb)],ids[r['bin']]]);c.linear.vars.extend(variables);c.linear.coeffs.extend(terms[v] for v in variables);c.linear.domain.extend([h['bound'],2**63-1]);requirements.append({'parts':[a,b],'profiles':[pa,pb],'bin':r['bin'],'requirement':j,'a':h['a'],'b':h['b'],'bound':h['bound']})
assert len(m.variables)==85699 and len(selectors)==210
write(OUT/'variable-remap.json',remap);write(OUT/'kept-parent-variables.json',kept_variables);write(OUT/'kept-parent-constraints.json',kept_constraints);write(OUT/'dropped-parent-constraints.json',dropped);write(OUT/'profile-flags.json',flags)
kept_planes=[{**r,'flag':remap[r['flag']]} for r in planes if r['flag'] not in removed];write(OUT/'shared-planes.json',kept_planes)
kept_maps=[]
for r in maps:
    if min(r['parts'])>=5:continue
    kept_maps.append({**r,'active':[remap[v] for v in r['active']],'faces':[{**f,'shared_flags':[remap[v] for v in f['shared_flags']]} if not f.get('tautological') else f for f in r['faces']]})
write(OUT/'models/000-mapping.json',kept_maps);write(OUT/'cell-selectors.json',[{**r,'variable':remap[r['variable']]} for r in load(PARENT/'cell-selectors.json')]);write(OUT/'cell-groups.json',[{**r,'profile_flag':remap[r['profile_flag']],'cell_flags':[remap[v] for v in r['cell_flags']]} for r in load(PARENT/'cell-groups.json')]);shutil.copyfile(PARENT/'spacing-constraints.json',OUT/'spacing-constraints.json')
write(OUT/'relative-y-selectors.json',selectors);write(OUT/'compact-requirements.json',requirements)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
old=load(PARENT/'inventory.json')[0];record={**old,'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(p),'shared_planes':len(kept_planes),'edge_uses':sum(len(f['shared_flags']) for r in kept_maps for f in r['faces'] if not f.get('tautological')),'face_clauses':sum(not f.get('tautological',False) for r in kept_maps for f in r['faces']),'tautological_faces':sum(f.get('tautological',False) for r in kept_maps for f in r['faces']),'retained_physical_modes':360,'compact_cog_physical_modes':384,'removed_shared_planes':len(removed),'relative_y_bin_selectors':210,'relative_y_bin_equalities':6,'compact_sloping_constraints':len(requirements),'retained_parent_variables':nv,'retained_parent_constraints':nc,'compact_witness_implies_full_source':True,'equivalent_full_source_feasibility':False};write(OUT/'inventory.json',[record]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**record,'solver_calls':0});print(load(OUT/'prepared.json'))
