"""Independently reconstruct every retained field and prove safe compact substitution."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-compact-cog-plane-probe-20261026';PARENT=ROOT/'output/h5-eight-phase-balanced-probe-20261026';DATA=ROOT/'output/h5-compact-cog-bin-planes-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently derive removed cog-only variables from the full source plane records, reconstruct all148074 exact original plane implications and3660 full face clauses as multisets, and remove only those exact constraints. Reconstruct every retained variable and every remapped constraint field, proving no remaining reference uses a removed flag. Rebuild complete35-bin selectors for each cog pair and all14442 conditional sloping source-plane requirements from audited geometry. Check all remapped cell/choice/source records, complete proto equality, actual solver import/export and the forward compact-to-source implication. No reverse equivalence or full-family negative is claimed. No solver.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'] and load(PARENT/'search/000/result.json')['status']=='UNKNOWN' and load(DATA/'audit/checks.json')['passed']
parent=proto(PARENT/'models/000.pb');actual=proto(BASE/'models/000.pb');assert {f.name for f,v in parent.ListFields()}=={'variables','constraints'};planes=load(PARENT/'shared-planes.json');maps=load(PARENT/'models/000-mapping.json');dropped_vars={r['flag'] for r in planes if r['parts'][0]>=5 and r['parts'][1]>=5};assert len(dropped_vars)==148074
remove_linear=Counter();remove_or=Counter()
for row in planes:
    if row['flag'] not in dropped_vars:continue
    a,b=row['parts'];terms={2*a:-row['a'],2*a+1:-row['b'],2*b:row['a'],2*b+1:row['b']};ids=sorted(v for v,k in terms.items() if k);c=cp_model_pb2.ConstraintProto();c.enforcement_literal.append(row['flag']);c.linear.vars.extend(ids);c.linear.coeffs.extend(terms[v] for v in ids);c.linear.domain.extend([row['bound'],2**63-1]);remove_linear[c.SerializeToString()]+=1
for mode in maps:
    if min(mode['parts'])<5:continue
    for face in mode['faces']:
        if face.get('tautological'):continue
        assert all(v in dropped_vars for v in face['shared_flags']);c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-v-1 for v in mode['active']]+face['shared_flags']);remove_or[c.SerializeToString()]+=1
assert sum(remove_linear.values())==148074 and sum(remove_or.values())==3660
expected=cp_model_pb2.CpModelProto();kept_vars=[i for i in range(len(parent.variables)) if i not in dropped_vars];mapping={old:new for new,old in enumerate(kept_vars)};remap=[mapping.get(i,-1) for i in range(len(parent.variables))]
for old in kept_vars:expected.variables.add().CopyFrom(parent.variables[old])
def literal(v):
    return mapping[v] if v>=0 else -mapping[-v-1]-1
kept_constraints=[];dropped=[]
for ordinal,c in enumerate(parent.constraints):
    raw=c.SerializeToString()
    if remove_linear[raw]:remove_linear[raw]-=1;dropped.append({'parent_constraint':ordinal,'kind':'cog-plane'});continue
    if remove_or[raw]:remove_or[raw]-=1;dropped.append({'parent_constraint':ordinal,'kind':'cog-face'});continue
    kept_constraints.append(ordinal);new=expected.constraints.add();new.CopyFrom(c);new.enforcement_literal[:]=[literal(v) for v in c.enforcement_literal]
    if c.WhichOneof('constraint')=='linear':new.linear.vars[:]=[mapping[v] for v in c.linear.vars]
    else:assert c.WhichOneof('constraint')=='bool_or';new.bool_or.literals[:]=[literal(v) for v in c.bool_or.literals]
assert not +remove_linear and not +remove_or and (len(expected.variables),len(expected.constraints))==(85489,88493)
for name,value in [('variable-remap.json',remap),('kept-parent-variables.json',kept_vars),('kept-parent-constraints.json',kept_constraints),('dropped-parent-constraints.json',dropped)]:assert load(BASE/name)==value
flags={i:{p:mapping[v] for p,v in f.items()} for i,f in load(PARENT/'profile-flags.json').items()};assert flags==load(BASE/'profile-flags.json') and all(mapping[v]==v for f in load(PARENT/'profile-flags.json').values() for v in f.values())
retained_planes=[{**r,'flag':mapping[r['flag']]} for r in planes if r['flag'] not in dropped_vars];retained_maps=[]
for r in maps:
    if min(r['parts'])>=5:continue
    retained_maps.append({**r,'active':[mapping[v] for v in r['active']],'faces':[{**f,'shared_flags':[mapping[v] for v in f['shared_flags']]} if not f.get('tautological') else f for f in r['faces']]})
assert retained_planes==load(BASE/'shared-planes.json') and retained_maps==load(BASE/'models/000-mapping.json')
assert load(BASE/'cell-selectors.json')==[{**r,'variable':mapping[r['variable']]} for r in load(PARENT/'cell-selectors.json')]
assert load(BASE/'cell-groups.json')==[{**r,'profile_flag':mapping[r['profile_flag']],'cell_flags':[mapping[v] for v in r['cell_flags']]} for r in load(PARENT/'cell-groups.json')]
assert (BASE/'spacing-constraints.json').read_bytes()==(PARENT/'spacing-constraints.json').read_bytes()
spec=load(DATA/'plan.json');rows=load(DATA/'guards.json');assert len(rows)==2191 and len(spec['bins_units1000'])==35;selectors=[];requirements=[]
for a,b in combinations(range(5,9),2):
    ids=[]
    for ordinal,(low,high) in enumerate(spec['bins_units1000']):
        v=len(expected.variables);expected.variables.add(name=f'pair-{a}-{b}-relative-y-bin{ordinal}',domain=[0,1]);c=expected.constraints.add();c.enforcement_literal.append(v);c.linear.vars.extend([2*a+1,2*b+1]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([low,high]);ids.append(v);selectors.append({'parts':[a,b],'bin':ordinal,'variable':v,'relative_y_units1000':[low,high]})
    c=expected.constraints.add();c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([1,1])
    for row in rows:
        pa,pb=row['profiles']
        for ordinal,h in enumerate(row['requirements']):
            assert h['a']>0;coefficients={2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']};vs=sorted(v for v,k in coefficients.items() if k);c=expected.constraints.add();c.enforcement_literal.extend([flags[str(a)][str(pa)],flags[str(b)][str(pb)],ids[row['bin']]]);c.linear.vars.extend(vs);c.linear.coeffs.extend(coefficients[v] for v in vs);c.linear.domain.extend([h['bound'],2**63-1]);requirements.append({'parts':[a,b],'profiles':[pa,pb],'bin':row['bin'],'requirement':ordinal,'a':h['a'],'b':h['b'],'bound':h['bound']})
assert selectors==load(BASE/'relative-y-selectors.json') and requirements==load(BASE/'compact-requirements.json') and len(requirements)==14442
assert expected==actual and len(actual.variables)==85699 and len(actual.constraints)==103151
record={**load(PARENT/'inventory.json')[0],'variables':85699,'constraints':103151,'model_sha256':digest(BASE/'models/000.pb'),'shared_planes':83713,'edge_uses':sum(len(f['shared_flags']) for r in retained_maps for f in r['faces'] if not f.get('tautological')),'face_clauses':2472,'tautological_faces':6438,'retained_physical_modes':360,'compact_cog_physical_modes':384,'removed_shared_planes':148074,'relative_y_bin_selectors':210,'relative_y_bin_equalities':6,'compact_sloping_constraints':14442,'retained_parent_variables':85489,'retained_parent_constraints':88493,'compact_witness_implies_full_source':True,'equivalent_full_source_feasibility':False};assert load(BASE/'inventory.json')==[record]
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb')) and proto(OUT/'roundtrip.pb')==actual
write(OUT/'implication.json',{'compact_witness_implies_full_source':True,'reverse_implication_claimed':False,'negative_excludes_full_source_family':False,'statement':'Every non-cog parent variable and constraint is retained by exact remapping. The original angle flags, stock intervals, mandatory counts, cog x order and all band cells are unchanged. Each physical cog pair selects a unique complete relative-Y bin. With its chosen phase pair, the retained sloping requirements imply every original rounded source face by the independent full-bin proof. Set each removed shared plane flag to its actual plane truth to extend the compact witness to every removed source implication and face OR. The substitute is sufficient, so a compact negative cannot be used as a full-source family exclusion.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':85699,'constraints':103151,'removed_cog_plane_variables':148074,'removed_cog_face_clauses':3660,'retained_parent_variables':85489,'retained_parent_constraints':88493,'all_retained_fields_exactly_reconstructed':True,'complete_relative_y_bin_selectors':210,'compact_sloping_constraints':14442,'all_original_identities_preserved':True,'compact_witness_implies_full_source':True,'reverse_equivalence_claimed':False,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
