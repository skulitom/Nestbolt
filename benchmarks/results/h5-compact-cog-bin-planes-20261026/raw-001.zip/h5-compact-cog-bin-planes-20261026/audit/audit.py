"""Independently prove exact rational endpoint dominance for each original face."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-compact-cog-bin-planes-20261026';PARENT=ROOT/'output/h5-compact-cog-bin-guards-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();deadline=start+240
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'audit_limit_seconds':240,'method':'Restore every certified pair/bin and its complete original face list. Independently reconstruct unique positive-X source edges, normalize each line with Fraction arithmetic and recompute all undominated requirements from exact endpoint comparisons. Check each retained plane is an actual original rounded source plane. For every face verify a retained line dominates its selected edge at both endpoints, hence everywhere on the interval; nonpositive-X edges must hold at all full-stock rectangle corners. Require exact records and full coverage. No solving; only the forward compact-to-source implication is proved.'})
spec=load(BASE/'plan.json')
for n,h in spec['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'audit/checks.json')['passed'];old=load(PARENT/'guards.json');rows=load(BASE/'guards.json');assert len(old)==len(rows)==2191;checked=retained=stockproofs=0;details=[];cache={}
for r,parent in zip(rows,old):
    assert time.perf_counter()<deadline
    for key in ['profiles','source_case','bin','relative_y_units1000','maximum_dx_units1000']:assert r[key]==parent[key]
    case=r['source_case']
    if case not in cache:cache[case]=load(SOURCE/'mutual'/f'{case:03d}.json')
    faces=cache[case]['faces'];lo,hi=r['relative_y_units1000'];unique=[];keys=set()
    for proof in parent['face_proofs']:
        h=faces[proof['face']]['outside_halfplanes'][proof['edge']];key=tuple(h[k] for k in ['a','b','bound'])
        if h['a']>0 and key not in keys:keys.add(key);unique.append({'a':h['a'],'b':h['b'],'bound':h['bound'],'source_face':proof['face'],'source_edge':proof['edge']})
    endpoints=[[F(h['bound']-h['b']*y,h['a']) for y in [lo,hi]] for h in unique]
    keep=[i for i,v in enumerate(endpoints) if not any(i!=j and all(a>=b for a,b in zip(w,v)) and (w!=v or j<i) for j,w in enumerate(endpoints))];requirements=[unique[i] for i in keep]
    assert requirements==r['requirements'] and len(unique)==r['unique_positive_source_edges'];retained+=len(requirements)
    assert len(r['source_face_proofs'])==len(faces)
    for proof,previous in zip(r['source_face_proofs'],parent['face_proofs']):
        assert [proof['face'],proof['edge']]==[previous['face'],previous['edge']];h=faces[proof['face']]['outside_halfplanes'][proof['edge']];chosen=proof['dominant_requirement']
        if h['a']>0:
            valid=[i for i,q in enumerate(requirements) if all(F(q['bound']-q['b']*y,q['a'])>=F(h['bound']-h['b']*y,h['a']) for y in [lo,hi])];assert valid and chosen==valid[0]
        else:
            assert chosen is None and all(h['a']*x+h['b']*y>=h['bound'] for x in [0,r['maximum_dx_units1000']] for y in [lo,hi]);stockproofs+=1
        checked+=1
    details.append({'profiles':r['profiles'],'bin':r['bin'],'source_faces_checked':len(faces),'retained_requirements':len(requirements),'passed':True})
write(OUT/'case-checks.json',details);write(OUT/'implication.json',{'compact_witness_implies_full_source':True,'reverse_implication_claimed':False,'flat_guard_witness_implies_sloping_guard_witness':True,'statement':'For the active phase pair and relative-Y bin, each retained positive-X plane supplies a lower bound on deltaX. For each original source face, either a source edge already holds throughout its full stock-difference rectangle or a retained line dominates a chosen source edge throughout the complete bin. The latter follows exactly from endpoint dominance of two affine functions. Thus every original face has a satisfied rounded outside edge. Retained source planes can be set from truth to extend the compact witness to the original source model. No reverse implication or full-family exclusion from a negative is asserted.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'complete_pair_bin_guards':2191,'retained_sloping_requirements_verified':retained,'original_source_face_implications_verified':checked,'full_stock_edge_implications_verified':stockproofs,'full_original_cog_source_implication_verified':True,'flat_guards_remain_uncalled':True,'audit_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
