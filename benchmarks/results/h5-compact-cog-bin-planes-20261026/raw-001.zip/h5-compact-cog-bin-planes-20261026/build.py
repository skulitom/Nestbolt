"""Retain sloping source planes and prune only exactly dominated bin requirements."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';PARENT=ROOT/'output/h5-compact-cog-bin-guards-20261026';OUT=ROOT/'output/h5-compact-cog-bin-planes-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def dominates(u,v,lo,hi):return all((u['bound']-u['b']*y)*v['a']>=(v['bound']-v['b']*y)*u['a'] for y in [lo,hi])
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240
assert load(PARENT/'audit/checks.json')['passed'];spec=load(PARENT/'plan.json');guards=load(PARENT/'guards.json');cases={r['source_case']:load(SOURCE/'mutual'/f"{r['source_case']:03d}.json") for r in guards}
paths=[PARENT/'plan.json',PARENT/'guards.json',PARENT/'audit/checks.json',PARENT/'audit/implication.json']+[SOURCE/'mutual'/f'{c:03d}.json' for c in sorted(cases)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'phases':spec['phases'],'bins_units1000':spec['bins_units1000'],'construction_limit_seconds':240,'method':'Use each previously certified source-face edge but retain its sloping exact rounded inequality instead of replacing it by the worst-case horizontal distance over the bin. Edges with nonpositive X coefficient already hold throughout the full stock-difference rectangle and require no new constraint. Among positive-X edges, compare normalized lower-X lines at both interval endpoints using integer cross-products. Remove a line only if another line dominates it throughout the entire interval; exact equal lines retain the first occurrence. For every original source face record a retained dominating requirement or its full-stock proof. Every compact solution implies every original source face. The flat-distance version remains uncalled. This is sufficient, not equivalent, to full source feasibility; no negative transfer is justified.'})
rows=[];total=0;max_count=0
for r in guards:
    assert time.perf_counter()<deadline
    lo,hi=r['relative_y_units1000'];faces=cases[r['source_case']]['faces'];unique=[];lookup={}
    for proof in r['face_proofs']:
        f=faces[proof['face']];assert f['index']==proof['face'];h=f['outside_halfplanes'][proof['edge']]
        if h['a']<=0:continue
        key=tuple(h[k] for k in ['a','b','bound'])
        if key not in lookup:lookup[key]=len(unique);unique.append({'a':h['a'],'b':h['b'],'bound':h['bound'],'source_face':f['index'],'source_edge':proof['edge']})
    kept=[i for i,h in enumerate(unique) if not any(i!=j and dominates(g,h,lo,hi) and (not dominates(h,g,lo,hi) or j<i) for j,g in enumerate(unique))];requirements=[unique[i] for i in kept];proofs=[]
    for proof in r['face_proofs']:
        h=faces[proof['face']]['outside_halfplanes'][proof['edge']]
        if h['a']>0:dominant=next(i for i,g in enumerate(requirements) if dominates(g,h,lo,hi))
        else:
            assert min(h['a']*x+h['b']*y for x in [0,r['maximum_dx_units1000']] for y in [lo,hi])>=h['bound'];dominant=None
        proofs.append({'face':proof['face'],'edge':proof['edge'],'dominant_requirement':dominant})
    total+=len(requirements);max_count=max(max_count,len(requirements));rows.append({'profiles':r['profiles'],'source_case':r['source_case'],'bin':r['bin'],'relative_y_units1000':r['relative_y_units1000'],'maximum_dx_units1000':r['maximum_dx_units1000'],'unique_positive_source_edges':len(unique),'requirements':requirements,'source_face_proofs':proofs})
write(OUT/'guards.json',rows);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'complete_pair_bin_guards':len(rows),'retained_sloping_requirements':total,'maximum_requirements_per_bin':max_count,'original_source_face_proofs':sum(len(r['source_face_proofs']) for r in rows),'positive_source_edges_before_pruning':sum(r['unique_positive_source_edges'] for r in rows),'construction_budget_honored':time.perf_counter()<deadline,'flat_model_called':False,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
