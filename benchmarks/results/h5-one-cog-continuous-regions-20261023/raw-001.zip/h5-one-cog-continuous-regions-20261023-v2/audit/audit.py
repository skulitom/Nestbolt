"""Independent original geometry, source event replay, bracket effects and all-core membership."""
from collections import Counter,deque
from datetime import datetime,timezone
import copy,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,Point,shape as from_geojson
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_individual_frame_joint import ROOT,SRC,OUT as FULL,load,write,digest,read_graph
BASE=ROOT/'output/h5-one-cog-continuous-regions-20261023-v2';COVER=ROOT/'output/h5-one-cog-release-coverage-20261023';OUT=BASE/'audit'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json');result=load(BASE/'result.json');mp=load(BASE/'mapping.json');oldmp=load(COVER/'mapping.json');pool=load(BASE/'candidates.json');oldpool=load(FULL/'candidates.json');new=mp['new_candidates'];oldn=len(oldpool);assert pool[:oldn]==oldpool and new==list(range(oldn,len(pool))) and len(new)==4000
    inputs=[BASE/n for n in ['plan.json','candidates.json','mapping.json','result.json','events.json','new-pose-diagnostics.json','pending-region-queries.json','pending-proposal-lists.json','obstacle-cache-audit.json']]+[COVER/n for n in ['mapping.json','checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently reconstruct every accepted cog from original vertices, audit stock and the generating 32-part core, replay every queue event and pending-list position, remeasure nearest original cog centers by affine centroid transforms, and recalculate bracket gain/loss through a sequential bounds scan and exact original distances. Check every new candidate against all 30 cores using both per-fixed-part distances and distances to original filled core unions. Preserve all original candidates, memberships and 30 mapped baselines. No new region generation, proposal continuation or solve.'})
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    assert all(r['hausdorff_error_mm']<1e-7 and r['symmetric_difference_area_mm2']<1e-4 for r in load(BASE/'obstacle-cache-audit.json'))
    start=time.perf_counter();job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};target=load(SRC/'conditional-target.json');stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];queries=[]
    for spec in plan['queries'][:result['regions_completed']]:
        q=load(BASE/'regions'/f"query-{spec['index']:03d}.json");assert all(q[k]==v for k,v in spec.items());region=from_geojson(q['region']);assert region.is_valid and abs(region.area-q['region_area_mm2'])<1e-7 and q['proposals']==proposals(region);queries.append(q)
    assert load(BASE/'pending-region-queries.json')==plan['queries'][len(queries):]
    events=load(BASE/'events.json');queue=deque((q['index'],0) for q in queries if q['proposals']);keys={identity(p['placement']):i for i,p in enumerate(oldpool)};added=[]
    for event in events:
        qi,pi=queue.popleft();assert event['query']==qi and event['proposal']==pi;q=queries[qi];p={'part_id':'cog','sheet_id':q['sheet_id'],'transform':{'rotation_radians':q['rotation_radians'],'translation':q['proposals'][pi]['point'],'mirrored':False}};k=identity(p)
        if k in keys:assert not event['added'] and event['reason']=='exact_duplicate' and event['candidate']==keys[k]
        else:
            assert event['added'];i=oldn+len(added);assert event['candidate']==i and pool[i]['placement']==p and pool[i]['index']==i;keys[k]=i;added.append(i)
        if pi+1<len(q['proposals']):queue.append((qi,pi+1))
    assert added==new and load(BASE/'pending-proposal-lists.json')==[{'query':q,'next_proposal':p} for q,p in queue]
    groups=oldmp['core_groups'];fixedids=sorted({i for g in groups for i in g['fixed_candidates']});fixed={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixedids};gs=np.asarray([shape(parts['cog'],pool[i]['placement']['transform']) for i in new],dtype=object);sheets=np.asarray([pool[i]['placement']['sheet_id'] for i in new]);per_sheet={s:np.flatnonzero(sheets==s) for s in ['sheet-0','sheet-1']};distances={};originalpairs=0
    for i in fixedids:
        ix=per_sheet[pool[i]['placement']['sheet_id']];ds=shapely.distance(gs[ix],fixed[i]);distances[i]={int(j):float(d) for j,d in zip(ix,ds)};originalpairs+=len(ix)
    compat={i:[] for i in new};memberships=uniondistances=0
    for g in groups:
        f=g['fixed_candidates'];assert len(f)==32 and Counter(pool[i]['placement']['part_id'] for i in f)==Counter(frame=18,cog=14)
        for sheet,ix in per_sheet.items():
            here=[i for i in f if pool[i]['placement']['sheet_id']==sheet];union=unary_union([fixed[i] for i in here]);ds=shapely.distance(gs[ix],union);uniondistances+=len(ix)
            for j,d in zip(ix,ds):
                byparts=all(distances[i][int(j)]>=clear-1e-7 for i in here);assert byparts==bool(d>=clear-1e-7);memberships+=1
                if byparts:compat[new[int(j)]].append(g['index'])
    geometry_pairs=0
    for j,i in enumerate(new):
        p=pool[i]['placement'];t=p['transform'];q=queries[pool[i]['source']['query']];g=gs[j];a,b,c,d=g.bounds;height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        assert g.is_valid and not t['mirrored'] and parts['cog']['rotations']['kind']=='free' and q['core_group'] in compat[i]
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=height-m['top']-edge+1e-7
        assert from_geojson(q['region']).distance(Point(t['translation']))<=1e-8
        assert abs(g.area-pool[i]['filled_area_mm2'])<1e-6
        geometry_pairs+=sum(pool[k]['placement']['sheet_id']==p['sheet_id'] for k in groups[q['core_group']]['fixed_candidates'])
    assert geometry_pairs==result['original_fixed_pair_checks']
    local={i:j for j,i in enumerate(oldmp['candidates'])};br=[i for i in oldmp['candidates'] if pool[i]['placement']['part_id']=='bracket'];brgs=np.asarray([shape(parts['bracket'],pool[i]['placement']['transform']) for i in br],dtype=object);bounds=shapely.bounds(brgs);brsheets=np.asarray([pool[i]['placement']['sheet_id'] for i in br]);br_allowed={g['index']:{i for i in br if g['index'] in oldmp['compatible_groups'][local[i]]} for g in groups[:15]};nearchecks=0
    def blocked(g,sheet):
        nonlocal nearchecks
        a,b,c,d=g.bounds;dx=np.maximum(np.maximum(bounds[:,0]-c,a-bounds[:,2]),0);dy=np.maximum(np.maximum(bounds[:,1]-d,b-bounds[:,3]),0);ix=np.flatnonzero((brsheets==sheet)&(dx*dx+dy*dy<=(clear+1e-7)**2));nearchecks+=len(ix);ds=shapely.distance(brgs[ix],g)
        return {br[int(j)] for j,v in zip(ix,ds) if v<clear-1e-7}
    previous_blocked={g['index']:blocked(shape(parts['cog'],pool[g['sources'][0]['released_cog']]['placement']['transform']),pool[g['sources'][0]['released_cog']]['placement']['sheet_id'])&br_allowed[g['index']] for g in groups[:15]}
    rawcenter=Polygon(parts['cog']['geometry'][0]['outer']).centroid.coords[0]
    def center(p):
        t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);x,y=rawcenter;tx,ty=t['translation'];assert not t['mirrored'];return np.asarray([x*c-y*s+tx,x*s+y*c+ty])
    old_cogs={s:[i for i,p in enumerate(oldpool) if p['placement']['part_id']=='cog' and p['placement']['sheet_id']==s] for s in per_sheet};centers={s:np.asarray([center(pool[i]['placement']) for i in ids]) for s,ids in old_cogs.items()};rows=load(BASE/'new-pose-diagnostics.json');assert [r['candidate'] for r in rows]==new
    gains=nontrivial=0;max_gain=0
    for j,r in enumerate(rows):
        i=r['candidate'];p=pool[i]['placement'];source=pool[i]['source'];assert (r['query'],r['proposal'],r['core_group'])==(source['query'],source['proposal'],source['core_group']);newblocked=blocked(gs[j],p['sheet_id']);oldblocked=previous_blocked[r['core_group']];allowed=br_allowed[r['core_group']]
        assert sorted(oldblocked-newblocked)==r['newly_available_bracket_candidates'] and sorted((allowed-oldblocked)&newblocked)==r['newly_blocked_bracket_candidates']
        ds=np.linalg.norm(centers[p['sheet_id']]-center(p),axis=1);nearest=old_cogs[p['sheet_id']].index(r['nearest_old_cog_center_candidate']);assert abs(float(ds.min())-r['nearest_old_cog_center_distance_mm'])<1e-8 and abs(float(ds[nearest])-float(ds.min()))<1e-8
        assert bool(ds.min()>.05)==r['new_center_over_0_05_mm'];nontrivial+=r['new_center_over_0_05_mm'];gains+=bool(r['newly_available_bracket_candidates']);max_gain=max(max_gain,len(r['newly_available_bracket_candidates']))
    ids=oldmp['candidates']+new;write(OUT/'new-core-memberships.json',[{'candidate':i,'compatible_groups':compat[i]} for i in new]);write(OUT/'mapping.json',{**oldmp,'source_pool':(BASE/'candidates.json').relative_to(ROOT).as_posix(),'candidates':ids,'compatible_groups':oldmp['compatible_groups']+[compat[i] for i in new],'family_caps':oldmp['variable_family_caps'],'new_candidates':new,'source_original_candidate_count':len(oldmp['candidates'])})
    checks={'passed':True,'seconds':time.perf_counter()-start,'original_pool_exactly_preserved':oldn,'new_poses_independently_checked':len(new),'region_files_and_proposal_lists_verified':len(queries),'queue_events_replayed':len(events),'pending_queries_preserved':len(plan['queries'])-len(queries),'pending_proposal_lists_preserved':len(queue),'cache_equivalence_cases':len(load(BASE/'obstacle-cache-audit.json')),'original_generation_pairs_verified':geometry_pairs,'new_pose_distinct_fixed_part_pairs':originalpairs,'new_pose_core_memberships_checked_both_methods':memberships,'core_union_distances':uniondistances,'all_30_cores_covered':True,'old_variable_choices_preserved':len(oldmp['candidates']),'total_variable_choices':len(ids),'all_30_original_baselines_preserved_in_mapping':True,'bracket_diagnostic_exact_pair_checks':nearchecks,'bracket_gain_loss_diagnostics_independently_verified':len(rows),'new_centers_over_0_05_mm':nontrivial,'new_poses_opening_old_bracket_choices':gains,'maximum_newly_available_bracket_choices':max_gain,'new_full_mutual_graph_and_reduction_pending':True,'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
