"""Fresh continuous translations for 15 audited one-cog cores; finite phases and original checks."""
from collections import Counter,deque
from datetime import datetime,timezone
from pathlib import Path
import copy,json,math,shutil,time,traceback
import numpy as np
import shapely
from shapely.affinity import translate
from shapely.geometry import Polygon,box,mapping
from shapely.ops import unary_union
from shapely.strtree import STRtree
import diagnose_h5_concave_gaps as gap
from conservative_h5_polygon_obstacles import obstacle as polygon_obstacle,circle_check
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_individual_frame_joint import ROOT,SRC,OUT as FULL,load,write,digest,read_graph
COVER=ROOT/'output/h5-one-cog-release-coverage-20261023';PREVIOUS=ROOT/'output/h5-one-cog-release-joint-20261023';OUT=ROOT/'output/h5-one-cog-continuous-regions-20261023-v2';FAILED=ROOT/'output/h5-one-cog-continuous-regions-20261023'
REGION_SECONDS=120;PROPOSAL_SECONDS=60;MAX_NEW=4000

def main():
    assert load(FAILED/'polygon-repair-diagnosis/checks.json')['passed'] and not list((FAILED/'regions').glob('*.json'))
    assert load(PREVIOUS/'layout-audit/checks.json')['passed'] and not load(PREVIOUS/'layout-audit/checks.json')['full_target_witness']
    assert load(COVER/'checks.json')['passed'];mp=load(COVER/'mapping.json');pool=load(FULL/'candidates.json');oldn=len(pool);assert oldn==35488
    job=load(SRC/'job.json');target=load(SRC/'conditional-target.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];clear=job['clearance'];edge=job['edge_clearance'];m=stock['margins']
    groups=mp['core_groups'][:15];assert all(g['index']==i and g['sources'][0]['source_seed']==0 for i,g in enumerate(groups))
    released=[g['sources'][0]['released_cog'] for g in groups];angles={pool[i]['placement']['transform']['rotation_radians'] for i in released};assert len(angles)==1;angle=angles.pop();offsets=[0.,4.5,9.,13.5];queries=[]
    for offset in offsets:
        for group,old in zip(groups,released):
            sheet=pool[old]['placement']['sheet_id']
            for target_sheet in [sheet,'sheet-1' if sheet=='sheet-0' else 'sheet-0']:
                queries.append({'index':len(queries),'core_group':group['index'],'released_cog':old,'sheet_id':target_sheet,'phase_offset_degrees':offset,'rotation_radians':angle+math.radians(offset),'rotation_degrees':math.degrees(angle)+offset})
    assert len(queries)==120;OUT.mkdir();(OUT/'regions').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    inputs=[FULL/n for n in ['candidates.json','adjacency.bin.gz','audit/checks.json']]+[COVER/n for n in ['plan.json','mapping.json','checks.json']]+[PREVIOUS/n for n in ['plan.json','solve/result.json','layout-audit/checks.json','next-step.json']]+[SRC/n for n in ['job.json','conditional-target.json']]+[Path(gap.__file__)]+[FAILED/n for n in ['plan.json','build.py','failure.txt','translation-diagnosis/result.json','round-repair-diagnosis-v2/checks.json','polygon-repair-diagnosis/checks.json']]+[ROOT/'output/conservative_h5_polygon_obstacles.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'region_seconds':REGION_SECONDS,'proposal_seconds':PROPOSAL_SECONDS,'maximum_new_cogs':MAX_NEW,'phase_offsets_degrees':offsets,'base_angle_radians':angle,'base_angle_degrees':math.degrees(angle),'queries':queries,'construction_margin_mm':.0001,'clearance_polygon':circle_check(clear),'preparation_repair':'The original generator stopped in its first cache-equivalence assertion before writing any completed query or proposal. Preserve its helper, plan and failure. Direct diagnosis showed mitre-buffer amplification of tiny union differences; round-buffer tessellation also failed the strict equivalence check. The explicit circumscribed 128-gon offset now passes unchanged equivalence thresholds and independent concave/hole identities. This repaired generator uses a new directory and unchanged 120-second region, 60-second proposal and 4000-pose limits; no completed search or solver is retried.','method':'For the original wide seed alone, use its 15 checked fixed cores of 18 frames and 14 cogs. For each core and each sheet, compute the full conservative translation region for a moving cog at the original angle and three additional 4.5-degree phase offsets. These are four sampled free angles, not an exhaustive rotation proof. Construct clearance by Minkowski addition of an explicit circumscribed 128-gon. Cache original-outline Minkowski obstacles by fixed family/orientation and moving angle, translate them by the fixed transform, and independently compare representative translated obstacles with direct global-outline constructions. Subtract all 32 fixed-part obstacles from original legal stock bounds. Preserve every region, vertex/midpoint/interior proposal and pending query. Process proposal lists round-robin with exact transform deduplication, original geometry checks and separate declared time/pose limits. Keep the entire original pool and all seeds unchanged.','diagnostic':'For each accepted new pose, measure distance to the nearest original cog center on its sheet, and count original bracket poses made available or blocked relative to the released cog under that exact fixed core. Candidate counts are not part quantities or an acceptance score. Rebuild every new-pose/core membership independently before any future conditional selection; no old reduced graph is reusable for these new poses.','qualification':'This is development geometry diagnosis. Conservative padding cannot prove impossibility. Original fixed cores and new poses are not native-margin qualified. Full 66 parts, unchanged target, native guard, original production budget and full H5 matrix remain required. No solver, native packing, quality run or held-out evaluation occurs.','solver_calls':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    gap.EPS=.0001;source_shapes={f:Polygon(p['geometry'][0]['outer']) for f,p in parts.items()};fixed_ids=sorted({i for g in groups for i in g['fixed_candidates']});geometry={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixed_ids};obstacles={};translated={};cache_audits=[];completed=[];start=time.perf_counter()
    for query in queries:
        if time.perf_counter()-start>=REGION_SECONDS:break
        qstart=time.perf_counter();theta=query['rotation_radians'];moving=gap.pose(source_shapes['cog'],{'rotation_radians':theta,'mirrored':False,'translation':[0.,0.]});fixed=groups[query['core_group']]['fixed_candidates'];here=[i for i in fixed if pool[i]['placement']['sheet_id']==query['sheet_id']];forbidden=[]
        for i in here:
            p=pool[i]['placement'];t=p['transform'];k=(p['part_id'],float(t['rotation_radians']).hex(),t['mirrored'],float(theta).hex())
            if k not in obstacles:
                base=gap.pose(source_shapes[p['part_id']],{**t,'translation':[0.,0.]});obstacles[k]=polygon_obstacle(base,moving,clear)
                shifted=translate(obstacles[k],*t['translation']);direct=polygon_obstacle(geometry[i],moving,clear);distance=shifted.hausdorff_distance(direct);area=shifted.symmetric_difference(direct).area
                assert distance<1e-7 and area<1e-4;cache_audits.append({'family':p['part_id'],'fixed_rotation_radians':t['rotation_radians'],'moving_rotation_radians':theta,'source_candidate':i,'hausdorff_error_mm':distance,'symmetric_difference_area_mm2':area})
            tk=(i,float(theta).hex())
            if tk not in translated:translated[tk]=translate(obstacles[k],*t['translation'])
            forbidden.append(translated[tk])
        x0,y0,x1,y1=moving.bounds;height=stock['height'] if query['sheet_id']=='sheet-0' else target['required_used_height_mm'];domain=(m['left']+edge+gap.EPS-x0,m['bottom']+edge+gap.EPS-y0,stock['width']-m['right']-edge-gap.EPS-x1,height-m['top']-edge-gap.EPS-y1)
        region=box(*domain).difference(unary_union(forbidden)) if domain[0]<domain[2] and domain[1]<domain[3] else Polygon();points=proposals(region)
        result={**query,'seconds':time.perf_counter()-qstart,'region_empty':region.is_empty,'region_area_mm2':region.area,'region_count':len(gap.polygons(region)),'region':mapping(region),'proposals':points};write(OUT/'regions'/f"query-{query['index']:03d}.json",result);completed.append(result)
        print({k:result[k] for k in ['index','core_group','sheet_id','phase_offset_degrees','seconds','region_empty','region_area_mm2']}|{'proposals':len(points)},flush=True)
    region_seconds=time.perf_counter()-start;write(OUT/'pending-region-queries.json',queries[len(completed):]);write(OUT/'obstacle-cache-audit.json',cache_audits)
    adj=read_graph(FULL/'adjacency.bin.gz',oldn);assert digest(FULL/'adjacency.bin.gz')==mp['source_graph_sha256'];local={i:j for j,i in enumerate(mp['candidates'])};brackets=[i for i in mp['candidates'] if pool[i]['placement']['part_id']=='bracket'];brgeoms=np.asarray([shape(parts['bracket'],pool[i]['placement']['transform']) for i in brackets],dtype=object);brloc={i:j for j,i in enumerate(brackets)}
    per_sheet={s:np.asarray([j for j,i in enumerate(brackets) if pool[i]['placement']['sheet_id']==s],dtype=int) for s in ['sheet-0','sheet-1']};trees={s:STRtree(brgeoms[js]) for s,js in per_sheet.items()};allowed_br={g['index']:{i for i in brackets if g['index'] in mp['compatible_groups'][local[i]]} for g in groups}
    old_cogs={s:[i for i,p in enumerate(pool) if p['placement']['part_id']=='cog' and p['placement']['sheet_id']==s] for s in ['sheet-0','sheet-1']};centers={s:np.asarray([shape(parts['cog'],pool[i]['placement']['transform']).centroid.coords[0] for i in ids]) for s,ids in old_cogs.items()};keys={identity(p['placement']):i for i,p in enumerate(pool)}
    queue=deque((q['index'],0) for q in completed if q['proposals']);events=[];added=[];new_rows=[];proposal_start=time.perf_counter();pair_checks=0
    while queue and len(added)<MAX_NEW and time.perf_counter()-proposal_start<PROPOSAL_SECONDS:
        qi,pi=queue.popleft();q=completed[qi];xy=q['proposals'][pi]['point'];p={'part_id':'cog','sheet_id':q['sheet_id'],'transform':{'rotation_radians':q['rotation_radians'],'translation':xy,'mirrored':False}};key=identity(p);event={'query':qi,'proposal':pi,'core_group':q['core_group']}
        if key in keys:event.update(added=False,reason='exact_duplicate',candidate=keys[key])
        else:
            g=gap.pose(source_shapes['cog'],p['transform']);direct=shape(parts['cog'],p['transform']);assert g.hausdorff_distance(direct)<1e-8 and g.symmetric_difference(direct).area<1e-5
            a,b,c,d=direct.bounds;height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>height-m['top']-edge+1e-7
            here=[i for i in groups[q['core_group']]['fixed_candidates'] if pool[i]['placement']['sheet_id']==p['sheet_id']];distances=[direct.distance(geometry[i]) for i in here];pair_checks+=len(here);blocked=[i for i,distance in zip(here,distances) if distance<clear-1e-7]
            if outside or blocked:event.update(added=False,reason='original_geometry_rejection',outside=bool(outside),fixed_blockers=blocked)
            else:
                i=len(pool);keys[key]=i;pool.append({'index':i,'placement':p,'source':{'kind':'one-cog-continuous-contact','query':qi,'proposal':pi,'core_group':q['core_group']},'filled_area_mm2':direct.area});added.append(i);geometry[i]=direct
                center=np.asarray(direct.centroid.coords[0]);ds=np.linalg.norm(centers[p['sheet_id']]-center,axis=1);nearest=int(np.argmin(ds));js=per_sheet[p['sheet_id']][trees[p['sheet_id']].query(direct,predicate='dwithin',distance=clear+1e-7)];js=js[shapely.distance(brgeoms[js],direct)<clear-1e-7];newblocked={brackets[int(j)] for j in js};allowed=allowed_br[q['core_group']];oldblocked={j for j in allowed if (adj[q['released_cog']]>>j)&1};gain=sorted(oldblocked-newblocked);loss=sorted((allowed-oldblocked)&newblocked)
                row={'candidate':i,'core_group':q['core_group'],'query':qi,'proposal':pi,'nearest_old_cog_center_candidate':old_cogs[p['sheet_id']][nearest],'nearest_old_cog_center_distance_mm':float(ds[nearest]),'new_center_over_0_05_mm':bool(ds[nearest]>.05),'newly_available_bracket_candidates':gain,'newly_blocked_bracket_candidates':loss,'minimum_fixed_distance_mm':min(distances,default=None)};new_rows.append(row);event.update(added=True,candidate=i)
        events.append(event)
        if pi+1<len(q['proposals']):queue.append((qi,pi+1))
    proposal_seconds=time.perf_counter()-proposal_start;write(OUT/'candidates.json',pool);write(OUT/'new-pose-diagnostics.json',new_rows);write(OUT/'events.json',events);write(OUT/'pending-proposal-lists.json',[{'query':qi,'next_proposal':pi} for qi,pi in queue]);write(OUT/'mapping.json',{'source_pool':(FULL/'candidates.json').relative_to(ROOT).as_posix(),'original_pool_size':oldn,'new_candidates':added,'core_groups':groups,'source_coverage_mapping':(COVER/'mapping.json').relative_to(ROOT).as_posix()})
    result={'regions_declared':len(queries),'regions_completed':len(completed),'pending_region_queries':len(queries)-len(completed),'empty_regions':sum(q['region_empty'] for q in completed),'region_seconds':region_seconds,'region_limit_reached':region_seconds>=REGION_SECONDS,'obstacle_cache_cases_independently_checked':len(cache_audits),'proposal_seconds':proposal_seconds,'proposal_limit_reached':proposal_seconds>=PROPOSAL_SECONDS,'pose_limit_reached':len(added)>=MAX_NEW,'original_pool_preserved':pool[:oldn]==load(FULL/'candidates.json'),'new_cog_poses':len(added),'new_centers_over_0_05_mm':sum(r['new_center_over_0_05_mm'] for r in new_rows),'new_poses_opening_old_bracket_choices':sum(bool(r['newly_available_bracket_candidates']) for r in new_rows),'maximum_newly_available_bracket_choices':max((len(r['newly_available_bracket_candidates']) for r in new_rows),default=0),'events':len(events),'event_outcomes':dict(Counter(e.get('reason','added') for e in events)),'pending_proposal_lists':len(queue),'original_fixed_pair_checks':pair_checks,'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
