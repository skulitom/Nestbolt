"""Verify the explicit clearance polygon on the unchanged failed first query."""
from pathlib import Path
import shutil,time
from shapely.affinity import translate
from shapely.geometry import Polygon,mapping,box
import diagnose_h5_concave_gaps as gap
from conservative_h5_polygon_obstacles import raw_obstacle,obstacle,expand,circle_check,disk_vertices
from audit_h5_cog_lattices import shape
from build_h5_individual_frame_joint import ROOT,SRC,OUT as FULL,load,write,digest
FAILED=ROOT/'output/h5-one-cog-continuous-regions-20261023';OUT=FAILED/'polygon-repair-diagnosis'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'check.py');pool=load(FULL/'candidates.json');job=load(SRC/'job.json');part=next(p for p in job['parts'] if p['id']=='cog');failure=load(FAILED/'translation-diagnosis/result.json');q=failure['query'];fixed=failure['fixed_candidate'];t=pool[fixed]['placement']['transform'];raw=Polygon(part['geometry'][0]['outer']);moving=gap.pose(raw,{'rotation_radians':q['rotation_radians'],'mirrored':False,'translation':[0.,0.]});base=gap.pose(raw,{**t,'translation':[0.,0.]});direct_shape=shape(part,t);start=time.perf_counter();unbuffered=raw_obstacle(base,moving);direct_raw=raw_obstacle(direct_shape,moving);raw_shifted=translate(unbuffered,*t['translation']);shifted=translate(obstacle(base,moving,job['clearance']),*t['translation']);direct=obstacle(direct_shape,moving,job['clearance']);distance=shifted.hausdorff_distance(direct);area=shifted.symmetric_difference(direct).area
    # Independently compare the boundary-sweep identity with distributive sums
    # of exact convex pieces for one concave polygon and one polygon with a hole.
    from shapely.geometry import MultiPoint
    from shapely.ops import unary_union
    import numpy as np
    sanity=[];disk=disk_vertices(job['clearance'])
    for name,poly in [('concave',Polygon([(0,0),(8,0),(8,2),(2,2),(2,8),(0,8)])),('hole',Polygon([(0,0),(8,0),(8,8),(0,8)],holes=[[(2,2),(2,6),(6,6),(6,2)]]))]:
        swept=expand(poly,job['clearance']);pieces=gap.convex_pieces(poly);alternative=unary_union([MultiPoint((np.asarray(p.exterior.coords)[:-1,None,:]+disk[None,:,:]).reshape(-1,2)).convex_hull for p in pieces]);hd=swept.hausdorff_distance(alternative);diff=swept.symmetric_difference(alternative).area;assert hd<1e-9 and diff<1e-9;sanity.append({'case':name,'hausdorff_mm':hd,'symmetric_difference_mm2':diff})
    check={'passed':distance<1e-7 and area<1e-4,'seconds':time.perf_counter()-start,'source_shape_exactly_unchanged':translate(base,*t['translation']).equals(direct_shape),'unbuffered_translation_hausdorff_mm':raw_shifted.hausdorff_distance(direct_raw),'unbuffered_translation_area_mm2':raw_shifted.symmetric_difference(direct_raw).area,'old_mitre_translation_hausdorff_mm':failure['hausdorff_error_mm'],'polygon_translation_hausdorff_mm':distance,'polygon_translation_area_mm2':area,'circle':circle_check(job['clearance']),'independent_concave_and_hole_identity_checks':sanity,'original_clearance_unchanged':True,'original_part_vertices_unchanged':True,'interpretation':'The explicit circumscribed clearance polygon avoids mitre amplification and phase-dependent round-buffer tessellation. Both globally constructed and translated Minkowski obstacles meet the original strict equivalence checks. All future placement proposals still require original-vertex distance checks.','generation_restarted':False,'solver_calls':0}
    for name,g in [('polygon-shifted',shifted),('polygon-direct',direct),('polygon-difference',shifted.symmetric_difference(direct))]:write(OUT/(name+'.geojson'),mapping(g))
    write(OUT/'checks.json',check);print(check,flush=True);assert check['passed']
if __name__=='__main__':main()
