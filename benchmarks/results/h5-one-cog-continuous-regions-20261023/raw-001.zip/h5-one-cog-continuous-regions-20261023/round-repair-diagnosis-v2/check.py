"""Verify the diagnosed mitre issue and conservative round repair on the unchanged first case."""
from pathlib import Path
import json,shutil,time
from shapely.affinity import translate
from shapely.geometry import Polygon,mapping,shape as from_geojson
import diagnose_h5_concave_gaps as gap
from conservative_h5_round_obstacles import raw_obstacle,obstacle,circle_check
from audit_h5_cog_lattices import shape
from build_h5_individual_frame_joint import ROOT,SRC,OUT as FULL,load,write,digest
FAILED=ROOT/'output/h5-one-cog-continuous-regions-20261023';OUT=FAILED/'round-repair-diagnosis-v2'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'check.py');pool=load(FULL/'candidates.json');job=load(SRC/'job.json');part=next(p for p in job['parts'] if p['id']=='cog');failure=load(FAILED/'translation-diagnosis/result.json');q=failure['query'];fixed=failure['fixed_candidate'];t=pool[fixed]['placement']['transform'];raw=Polygon(part['geometry'][0]['outer']);moving=gap.pose(raw,{'rotation_radians':q['rotation_radians'],'mirrored':False,'translation':[0.,0.]});base=gap.pose(raw,{**t,'translation':[0.,0.]});direct_shape=shape(part,t);start=time.perf_counter();unbuffered=raw_obstacle(base,moving);direct_raw=raw_obstacle(direct_shape,moving);raw_shifted=translate(unbuffered,*t['translation']);shifted=translate(obstacle(base,moving,job['clearance']),*t['translation']);direct=obstacle(direct_shape,moving,job['clearance']);distance=shifted.hausdorff_distance(direct);area=shifted.symmetric_difference(direct).area
    # Record all diagnostics before deciding whether the proposed repair passes.
    check={'passed':True,'seconds':time.perf_counter()-start,'source_shape_exactly_unchanged':translate(base,*t['translation']).equals(direct_shape),'unbuffered_translation_hausdorff_mm':raw_shifted.hausdorff_distance(direct_raw),'unbuffered_translation_area_mm2':raw_shifted.symmetric_difference(direct_raw).area,'old_mitre_translation_hausdorff_mm':failure['hausdorff_error_mm'],'old_mitre_translation_area_mm2':failure['difference_area_mm2'],'new_round_translation_hausdorff_mm':distance,'new_round_translation_area_mm2':area,'circle':circle_check(job['clearance']),'original_clearance_unchanged':True,'original_part_vertices_unchanged':True,'interpretation':'Unbuffered Minkowski obstacles agree to numerical precision. Mitred buffering amplifies tiny union slivers into 0.0307 mm boundary differences. Conservative circumscribed round buffering removes the amplification while retaining an explicit positive construction margin. Original geometry acceptance is unchanged; all future proposed placements still require direct original-distance checks.','generation_restarted':False,'solver_calls':0}
    check['passed']=raw_shifted.hausdorff_distance(direct_raw)<1e-8 and distance<1e-7 and area<1e-4
    check['interpretation']='Diagnostic only: record the unbuffered and buffered differences before interpreting the failed tolerance check. The earlier diagnostic stopped at its assertion; its copied helper remains preserved. No placement generation has occurred.'
    check['round_shifted_area_mm2']=shifted.area;check['round_direct_area_mm2']=direct.area
    check['round_shifted_holes']=len(shifted.interiors);check['round_direct_holes']=len(direct.interiors)
    check['raw_shifted_holes']=len(raw_shifted.interiors);check['raw_direct_holes']=len(direct_raw.interiors)
    check['round_difference_outside_1e_6_buffer_mm2']=shifted.difference(direct.buffer(1e-6)).area+direct.difference(shifted.buffer(1e-6)).area
    for name,g in [('raw-shifted',raw_shifted),('raw-direct',direct_raw),('round-shifted',shifted),('round-direct',direct),('round-difference',shifted.symmetric_difference(direct)),('raw-difference',raw_shifted.symmetric_difference(direct_raw))]:write(OUT/(name+'.geojson'),mapping(g))
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
