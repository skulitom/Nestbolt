"""Read-only picture and transforms of the current original wide 64-part seed."""
from pathlib import Path
from hashlib import sha256
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle,Patch
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-current-cog-gap-inspection-20261023';load=lambda p:json.loads(p.read_bytes())
def main():
    OUT.mkdir();poolpath=ROOT/'output/h5-individual-frame-joint-20261023/candidates.json';mpath=ROOT/'output/h5-one-cog-release-coverage-20261023/mapping.json';jobpath=ROOT/'output/h5-skeleton-contact-selection-20261020/job.json';targetpath=ROOT/'output/h5-skeleton-contact-selection-20261020/conditional-target.json';pool=load(poolpath);mp=load(mpath);job=load(jobpath);parts={p['id']:p for p in job['parts']};target=load(targetpath);seed=mp['source_seeds'][0]['selected_indices'];colors={'frame':'#879596','cog':'#9b59b6','bracket':'#df8d32','insert':'#5a91cc'}
    fig,axes=plt.subplots(2,1,figsize=(9,18),gridspec_kw={'height_ratios':[3000,550]});records=[]
    for si,ax in enumerate(axes):
        sheet=f'sheet-{si}';height=3000 if si==0 else target['required_used_height_mm'];ax.add_patch(Rectangle((0,0),1500,height,facecolor='#fcfbf8',edgecolor='#333'))
        for i in seed:
            p=pool[i]['placement']
            if p['sheet_id']!=sheet:continue
            t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];vertices=[(m*c*x-s*y+tx,m*s*x+c*y+ty) for x,y in parts[p['part_id']]['geometry'][0]['outer']]
            ax.add_patch(Polygon(vertices,facecolor=colors[p['part_id']],edgecolor='white',linewidth=.5));xs,ys=zip(*vertices);label=f"{p['part_id'][0].upper()}{i}";ax.text((min(xs)+max(xs))/2,(min(ys)+max(ys))/2,label,fontsize=6,ha='center',va='center',color='black')
            records.append({'candidate':i,**p,'rotation_degrees':math.degrees(t['rotation_radians']),'bounds':[min(xs),min(ys),max(xs),max(ys)]})
        ax.set(xlim=(-15,1515),ylim=(-15,height+15),aspect='equal',title=f'{sheet}: 64-part seed, filled frame holes');ax.grid(alpha=.15)
    axes[0].legend(handles=[Patch(facecolor=c,label=f) for f,c in colors.items()],loc='upper left',bbox_to_anchor=(1.01,1));fig.tight_layout();fig.savefig(OUT/'seed.png',dpi=130);plt.close(fig)
    result={'source_hashes':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in [poolpath,mpath,jobpath,targetpath]},'parts':records}
    (OUT/'inspection.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps([r for r in records if r['part_id']=='cog'],indent=2))
if __name__=='__main__':main()
