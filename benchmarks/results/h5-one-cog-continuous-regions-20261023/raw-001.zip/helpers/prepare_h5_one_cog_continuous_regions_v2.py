"""Prepare a repaired region generator after pre-generation obstacle checks failed."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];FAILED=ROOT/'output/h5-one-cog-continuous-regions-20261023'
assert not list((FAILED/'regions').glob('*.json'))
assert json.loads((FAILED/'polygon-repair-diagnosis/checks.json').read_bytes())['passed']
s=(FAILED/'build.py').read_text(encoding='utf-8')
def replace(a,b):
    global s
    assert a in s,a
    s=s.replace(a,b)
replace('import diagnose_h5_concave_gaps as gap','import diagnose_h5_concave_gaps as gap\nfrom conservative_h5_polygon_obstacles import obstacle as polygon_obstacle,circle_check')
replace("OUT=ROOT/'output/h5-one-cog-continuous-regions-20261023'","OUT=ROOT/'output/h5-one-cog-continuous-regions-20261023-v2';FAILED=ROOT/'output/h5-one-cog-continuous-regions-20261023'")
replace("    assert load(PREVIOUS/'layout-audit/checks.json')", "    assert load(FAILED/'polygon-repair-diagnosis/checks.json')['passed'] and not list((FAILED/'regions').glob('*.json'))\n    assert load(PREVIOUS/'layout-audit/checks.json')")
replace("+[Path(gap.__file__)]", "+[Path(gap.__file__)]+[FAILED/n for n in ['plan.json','build.py','failure.txt','translation-diagnosis/result.json','round-repair-diagnosis-v2/checks.json','polygon-repair-diagnosis/checks.json']]+[ROOT/'output/conservative_h5_polygon_obstacles.py']")
replace("'construction_margin_mm':.0001,", "'construction_margin_mm':.0001,'clearance_polygon':circle_check(clear),'preparation_repair':'The original generator stopped in its first cache-equivalence assertion before writing any completed query or proposal. Preserve its helper, plan and failure. Direct diagnosis showed mitre-buffer amplification of tiny union differences; round-buffer tessellation also failed the strict equivalence check. The explicit circumscribed 128-gon offset now passes unchanged equivalence thresholds and independent concave/hole identities. This repaired generator uses a new directory and unchanged 120-second region, 60-second proposal and 4000-pose limits; no completed search or solver is retried.',")
replace('Cache original-outline Minkowski obstacles','Construct clearance by Minkowski addition of an explicit circumscribed 128-gon. Cache original-outline Minkowski obstacles')
replace('gap.obstacle(base,moving,clear)','polygon_obstacle(base,moving,clear)')
replace('gap.obstacle(geometry[i],moving,clear)','polygon_obstacle(geometry[i],moving,clear)')
with (ROOT/'output/build_h5_one_cog_continuous_regions_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared repaired generator; no region query or solve executed.')
