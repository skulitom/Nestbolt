"""Inspect the first failed translated-obstacle equivalence check without restarting generation."""
from pathlib import Path
import json,time
from shapely.affinity import translate
from shapely.geometry import Polygon,mapping
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_individual_frame_joint import ROOT,SRC,OUT as FULL,load,write,digest
OUT=ROOT/'output/h5-one-cog-continuous-regions-20261023/translation-diagnosis'
def main():
    OUT.mkdir();pool=load(FULL/'candidates.json');job=load(SRC/'job.json');part=next(p for p in job['parts'] if p['id']=='cog');plan=load(OUT.parent/'plan.json');q=plan['queries'][0];mp=load(ROOT/'output/h5-one-cog-release-coverage-20261023/mapping.json');fixed=next(i for i in mp['core_groups'][q['core_group']]['fixed_candidates'] if pool[i]['placement']['sheet_id']==q['sheet_id']);p=pool[fixed]['placement'];t=p['transform'];raw=Polygon(part['geometry'][0]['outer']);moving=gap.pose(raw,{'rotation_radians':q['rotation_radians'],'mirrored':False,'translation':[0.,0.]});base=gap.pose(raw,{**t,'translation':[0.,0.]});direct_shape=shape(part,t);gap.EPS=plan['construction_margin_mm'];start=time.perf_counter();local=gap.obstacle(base,moving,job['clearance']);shifted=translate(local,*t['translation']);direct=gap.obstacle(direct_shape,moving,job['clearance']);diff=shifted.symmetric_difference(direct)
    result={'fixed_candidate':fixed,'query':q,'seconds':time.perf_counter()-start,'source_shape_translation_hausdorff_mm':translate(base,*t['translation']).hausdorff_distance(direct_shape),'source_shape_translation_area_mm2':translate(base,*t['translation']).symmetric_difference(direct_shape).area,'base_pieces':len(gap.convex_pieces(base)),'direct_pieces':len(gap.convex_pieces(direct_shape)),'shifted_area_mm2':shifted.area,'direct_area_mm2':direct.area,'difference_area_mm2':diff.area,'hausdorff_error_mm':shifted.hausdorff_distance(direct),'shifted_bounds':shifted.bounds,'direct_bounds':direct.bounds,'shifted_valid':shifted.is_valid,'direct_valid':direct.is_valid,'shifted_type':shifted.geom_type,'direct_type':direct.geom_type,'shifted_exclusive_area_mm2':shifted.difference(direct).area,'direct_exclusive_area_mm2':direct.difference(shifted).area}
    write(OUT/'result.json',result)
    for name,g in [('local',local),('shifted',shifted),('direct',direct),('difference',diff)]:write(OUT/(name+'.geojson'),mapping(g))
    print(result,flush=True)
if __name__=='__main__':main()
