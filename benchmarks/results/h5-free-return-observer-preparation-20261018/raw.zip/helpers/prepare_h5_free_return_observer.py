"""Observe actual free-return seeds, repair losses and accepted material without a search change."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import difflib,json,shutil,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-free-return-observer-20261018'
old=root/'output/h5-free-return-probe-20261018/candidate';work=out/'workspace'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
pilot=root/'benchmarks/results/h5-free-return-pilot-20261018'
assert load(pilot/'verification.json')['valid']==72 and load(pilot/'filled-outer-audit.json')['all_holes_reserved']
assert load(pilot/'interpretation.json')['failed_material_pairs']==5
out.mkdir();shutil.copytree(old,work)
rel='crates/core/src/sheets/vstrip/exchange.rs';original=(old/rel).read_text(encoding='utf-8');text=original;changes=[]
def replace(a,b):
 global text
 assert text.count(a)==1,(a,text.count(a));text=text.replace(a,b);changes.append((a,b))
for a,b in load(root/'output/h5-boundary-observer-20261018/substitutions.json'):replace(a,b)
replace('"outcome":"pending"}));','"outcome":"pending", "return_seed_detail":null, "repair_detail":null, "material_detail":null}));')
needle='''                    for ((_, victim, _), pose) in victims.iter().zip(returned) {'''
addition='''                    trace.attempts[attempt_index]["return_seed_detail"] = serde_json::json!({
                        "source_before": source.placed_items().values().map(|p| {
                            let item=p.item().idx();
                            serde_json::json!({"part_id":self.model.job.parts[self.model.part[item]].id,
                                "transform":self.model.external(item,&p.d_transf())})
                        }).collect::<Vec<_>>(),
                        "contained": victims.iter().zip(&returned).map(|((_,item,_),pose)| {
                            let item=item.idx();
                            serde_json::json!({"part_id":self.model.job.parts[self.model.part[item]].id,
                                "transform":self.model.external(item,pose)})
                        }).collect::<Vec<_>>(),
                        "placed": [], "work_before":self.clock.counts(), "work_after":null,
                    });
'''
replace(needle,addition+needle)
needle='''                        next_source.place_item(victim, pose);'''
replace(needle,'''                        trace.attempts[attempt_index]["return_seed_detail"]["placed"].as_array_mut().expect("seed observations").push(
                            serde_json::json!({"part_id":self.model.job.parts[self.model.part[victim.idx()]].id,
                                "transform":self.model.external(victim.idx(),&pose)}));
'''+needle)
needle='''                    self.clock
                        .charge(Work::RegisteredItem, changed_keys.len() as f64);
                    let now = self.clock.now();'''
replace(needle,'''                    trace.attempts[attempt_index]["return_seed_detail"]["work_after"] = serde_json::json!(self.clock.counts());
'''+needle)
needle='''                    if receiver_tracker.total_loss() > 0.0 {'''
replace(needle,'''                    trace.attempts[attempt_index]["repair_detail"] = serde_json::json!({
                        "receiver_loss":receiver_tracker.total_loss(), "source_loss":null, "source_after":null,
                    });
'''+needle)
needle='''                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(exchange_until)'''
replace(needle,'''                    trace.attempts[attempt_index]["repair_detail"]["source_loss"] = serde_json::json!(source_tracker.total_loss());
                    trace.attempts[attempt_index]["repair_detail"]["source_after"] = serde_json::json!(
                        JLayout::from_snapshot(&source_snapshot).placed_items().values().map(|p| {
                            let item=p.item().idx();
                            serde_json::json!({"part_id":self.model.job.parts[self.model.part[item]].id,
                                "transform":self.model.external(item,&p.d_transf())})
                        }).collect::<Vec<_>>());
'''+needle)
needle='''                    let after = report.metrics.as_ref().expect("valid exchange");'''
replace(needle,needle+'''
                    trace.attempts[attempt_index]["material_detail"] = serde_json::json!({
                        "material_increased":exchange_increases_material(before,after),
                        "metrics":after, "layout":trial_layout,
                    });''')
reverse=text
for a,b in reversed(changes):assert reverse.count(b)==1;reverse=reverse.replace(b,a)
assert reverse==original and text.split('#[cfg(test)]',1)[1]==original.split('#[cfg(test)]',1)[1]
# No new time reads, charges, random draws or mutation of solver entities.
for marker in ['clock.now(','.charge(','.validated(','.next_u64(','.place_item(','.remove_item(']:assert text.count(marker)==original.count(marker),marker
(work/rel).write_text(text,encoding='utf-8',newline='\n')
(out/'substitutions.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='free-return/'+rel,tofile='observer/'+rel)),encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_source':str(old),
 'source_files':[{'path':p.relative_to(old).as_posix(),'sha256':digest(p)} for p in sorted(old.rglob('*')) if p.is_file()],
 'changed_file':rel,'changed_files':[rel],'production_digest':source_digest(),'target':str(root/'output/h5-free-return-observer-target-20261018'),
 'all_137_prior_tests_unchanged':True,'exact_preformat_reversal':True,'decisions_budgets_work_charges_unchanged':True,
 'actual_seed_poses_not_recomputed':True,'trace_overhead_can_change_wall_trajectory':True,'measured_search_started':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'prepare.py')
for name in ['build_h5_exchange_failure_observer.py','check_h5_exchange_failure_observer_source.py']:
 s=(root/'output'/name).read_text(encoding='utf-8').replace('h5-exchange-failure-observer','h5-free-return-observer').replace('all_130_original_tests','all_137_original_tests')
 target=root/'output'/name.replace('h5_exchange_failure_observer','h5_free_return_observer');compile(s,str(target),'exec');target.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'prepared':True,'tests_unchanged':137,'new_searches':0,'substitutions':len(changes)}))
