"""Qualify the new schema using unchanged authored tests and saved parent outcomes."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/check_h5_exchange_failure_observer_reader.py').read_text(encoding='utf-8')
s=s.replace('h5-exchange-failure-observer','h5-free-return-observer').replace('h5_exchange_failure_observer','h5_free_return_observer')
s=s.replace('productive_exchange_rejects_unchanged_inventory_without_material_gain','productive_exchange_requires_gain_for_changed_equal_inventory')
s=s.replace('exact_duplicate_rejection_preserves_incumbent_and_disabled_boundaries','exact_duplicate_guard_allows_only_gain_and_preserves_disabled_boundaries')
s=s.replace('material_profile_rejection_preserves_incumbent_and_disabled_boundaries','material_profile_guard_allows_only_gain_and_preserves_disabled_boundaries')
s=s.replace("'failure_details']", "'attempt_observations']")
s=s.replace('output/h5-boundary-pair-probe-20261018/branch-checks','output/h5-free-return-probe-20261018/branch-checks')
s=s.replace("summary['outcomes']['material_profile_rejected']>0 and summary['outcomes']['exact_state_rejected']>0", "summary['outcomes']['material_profile_rejected']>0")
start=s.index('# These are parser-only fixtures');end=s.index("cli=root/'target/release/nestbolt.exe'",start)
s=s[:start]+'''# Mutations of actual records test failure-closed parsing. These do not prove geometry.
source_trace=next(t for t in all_traces if any(a['outcome']=='source_repair_or_expiry' for a in t['attempts']))
source_index=next(i for i,a in enumerate(source_trace['attempts']) if a['outcome']=='source_repair_or_expiry')
receiver_trace=next(t for t in all_traces if any(a['outcome']=='receiver_repair_failed' for a in t['attempts']))
receiver_index=next(i for i,a in enumerate(receiver_trace['attempts']) if a['outcome']=='receiver_repair_failed')
assert summary['reason_counts']['source_loss_positive']>0 and summary['reason_counts']['receiver_loss_positive']>0
def reject_detail(name,original,index,mutate):
    t=copy.deepcopy(original);mutate(t['attempts'][index])
    try:runner.check_traces([t])
    except (AssertionError,KeyError,TypeError,IndexError):rejected.append(name)
    else:raise AssertionError('Reader accepted '+name)
for value in [-1.0,float('nan'),True,None]:
    reject_detail('invalid source loss '+repr(value),source_trace,source_index,lambda a,v=value:a['repair_detail'].update(source_loss=v))
reject_detail('missing seed detail',source_trace,source_index,lambda a:a.pop('return_seed_detail'))
reject_detail('missing contained pose',source_trace,source_index,lambda a:a['return_seed_detail']['contained'].pop())
reject_detail('missing actual pose',source_trace,source_index,lambda a:a['return_seed_detail']['placed'].pop())
reject_detail('missing original source member',source_trace,source_index,lambda a:a['return_seed_detail']['source_before'].pop())
reject_detail('changed original source pose',source_trace,source_index,lambda a:a['return_seed_detail']['source_before'][0]['transform']['translation'].__setitem__(0,999999.0))
reject_detail('changed returned rotation',source_trace,source_index,lambda a:a['return_seed_detail']['placed'][0]['transform'].update(rotation_radians=0.123))
reject_detail('changed returned reflection',source_trace,source_index,lambda a:a['return_seed_detail']['placed'][0]['transform'].update(mirrored=not a['return_seed_detail']['contained'][0]['transform']['mirrored']))
reject_detail('nonfinite actual seed',source_trace,source_index,lambda a:a['return_seed_detail']['placed'][0]['transform']['translation'].__setitem__(0,float('inf')))
reject_detail('missing work counter',source_trace,source_index,lambda a:a['return_seed_detail']['work_after'].pop('evaluations'))
reject_detail('negative work delta',source_trace,source_index,lambda a:a['return_seed_detail']['work_after'].update(evaluations=0))
reject_detail('unbounded seed evaluations',source_trace,source_index,lambda a:a['return_seed_detail']['work_after'].update(evaluations=1e12))
reject_detail('unrelated validator work',source_trace,source_index,lambda a:a['return_seed_detail']['work_after'].update(validated_vertices=1e12))
reject_detail('missing repaired member',source_trace,source_index,lambda a:a['repair_detail']['source_after'].pop())
reject_detail('zero receiver failure',receiver_trace,receiver_index,lambda a:a['repair_detail'].update(receiver_loss=0.0))
accepted_index=next(i for i,a in enumerate(accepted['attempts']) if a['outcome']=='accepted')
reject_detail('missing accepted material',accepted,accepted_index,lambda a:a.update(material_detail=None))
reject_detail('false material classification',accepted,accepted_index,lambda a:a['material_detail'].update(material_increased=True))
reject_detail('missing accepted placement',accepted,accepted_index,lambda a:a['material_detail']['layout']['placements'].pop())
reject_detail('nonfinite accepted material',accepted,accepted_index,lambda a:a['material_detail']['metrics'].update(material_area=float('inf')))
reject_detail('unknown accepted sheet',accepted,accepted_index,lambda a:a['material_detail']['layout']['placements'][0].update(sheet_id='unknown'))
synthetic=[]
t=copy.deepcopy(source_trace);t['attempts'][source_index]['repair_detail']['source_loss']=0.0
check=runner.check_traces([t]);assert any(d['attempt_index']==source_index and d['reason']=='source_deadline' for d in check['attempt_observations'])
synthetic.append('parser-only zero source loss distinguishes original deadline branch; no geometry claim')
for mode in ['deadline','material_area','sheets_used']:
    t=copy.deepcopy(accepted);a=t['attempts'][accepted_index];a['outcome']='material_guard_or_expiry'
    a['material_detail']['metrics']=copy.deepcopy(t['baseline']['metrics']);a['material_detail']['material_increased']=False
    if mode!='deadline':a['material_detail']['metrics'][mode]+=1;a['material_detail']['material_increased']=True
    check=runner.check_traces([t]);expected='exchange_deadline' if mode=='deadline' else 'material_increased'
    assert any(d['attempt_index']==accepted_index and d['reason']==expected for d in check['attempt_observations'])
    synthetic.append('parser-only '+mode+' classification; layout/metrics intentionally not geometry evidence')
assert len(synthetic)==4 and len(rejected)==44

'''+s[end:]
s=s.replace("summary['failure_reason_counts']", "summary['reason_counts']")
# Record and independently validate every material-bearing actual trial as well as the baselines.
start=s.index("runner.write(out/'checks.json'")
addition='''material_checks=0
for invocation,trace in enumerate(all_traces):
    for index,attempt in enumerate(trace['attempts']):
        detail=attempt['material_detail']
        if detail is None:continue
        case=out/f'trial-{invocation}-{index}';case.mkdir()
        runner.write(case/'job.json',trace['baseline']['job']);runner.write(case/'layout.json',detail['layout'])
        args=[str(cli),'validate','--job',str(case/'job.json'),'--layout',str(case/'layout.json')]
        r=subprocess.run(args,capture_output=True,timeout=60)
        (case/'stdout.json').write_bytes(r.stdout);(case/'stderr.log').write_bytes(r.stderr)
        runner.write(case/'command.json',{'command':args,'exit_code':r.returncode})
        value=json.loads(r.stdout);assert r.returncode==0 and value['valid'] and value['metrics']==detail['metrics'];material_checks+=1
runner.write(out/'actual-traces.json',all_traces)
'''
s=s[:start]+addition+s[start:]
s=s.replace("'baseline_metrics_exact':True", "'frozen_CLI_trial_checks':material_checks,'baseline_and_trial_metrics_exact':True")
s=s.replace("'frozen_CLI_baselines':len(all_traces)", "'frozen_CLI_baselines':len(all_traces),'frozen_CLI_trials':material_checks")
p=root/'output/check_h5_free_return_observer_reader.py';compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
print('Prepared actual authored outcomes, exact parent witness checks, malformed-record tests and frozen-CLI trial validation.')
