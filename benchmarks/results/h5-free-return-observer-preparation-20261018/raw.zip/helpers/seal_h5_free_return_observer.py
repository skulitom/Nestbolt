"""Seal observation qualification before four serial diagnostic measurements."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-free-return-observer-20261018';out=root/'benchmarks/results/h5-free-return-observer-preparation-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_free_return_observer as runner
load,write,digest=runner.load,runner.write,runner.digest
build=load(probe/'build.json');plan=load(probe/'preparation.json');reader=load(probe/'authored-trace-reader/checks.json');source=load(probe/'reconstruction.json')
assert build['all_passed'] and digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert '137 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert source['all_formatted_files_exact'] and len(source['files'])==156 and source['unchanged_other_files']==155 and source['all_137_original_tests_unchanged']
assert runner.prior.source_digest()==plan['production_digest']
for rel,expected in build['observed_sources'].items():assert digest(probe/'workspace'/rel)==expected
assert reader['all_checks_pass'] and len(reader['authored_test_traces'])==16 and len(reader['malformed_records_rejected'])==44
assert reader['reader_sha256']==digest(root/'scripts/h5_free_return_observer.py') and reader['all_choice_poses_match_unique_baseline_members']
assert len(reader['synthetic_parser_cases'])==5 and reader['source_return_inventories_verified']
assert reader['cached_authored_executions_reused']==16 and reader['native_receiver_failure_observed'] is False
assert reader['parent_profile_branch_witnesses_exact']==12 and reader['actual_profile_branch_counters_exact']
assert reader['frozen_CLI_baseline_checks']==reader['actual_invocations']>0 and reader['frozen_CLI_trial_checks']>0
assert digest(probe/'authored-tests.exe')==reader['test_binary_sha256']
method=load(probe/'runner-method.json');assert method['measurement_function_AST_exact_except_result_count'] and method['runner_sha256']==reader['reader_sha256']
assert digest(root/method['reference'])==method['reference_sha256']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_free_return_observer.py','prepare_h5_free_return_observer_reader.py','refine_h5_free_return_observer_reader.py',
 'prepare_h5_free_return_observer_checks.py','prepare_h5_free_return_observer_finish.py','check_h5_free_return_details.py',
 'build_h5_free_return_observer.py','check_h5_free_return_observer_reader.py','check_h5_free_return_observer_source.py',
 'seal_h5_free_return_observer.py','record_h5_free_return_observer_preparation.py','repair_h5_free_return_observer_reader_coverage.py']:
 files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_free_return_observer.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(inventory)
 for n,row in inventory.items():
  b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_qualified':True,'optimized_core_tests_passed':137,'original_tests_unchanged':137,'strict_lint_passed':True,'observer_build_passed':True,
 'authored_test_cases':16,'malformed_records_rejected':44,'frozen_CLI_baseline_checks':reader['frozen_CLI_baseline_checks'],
 'frozen_CLI_trial_checks':reader['frozen_CLI_trial_checks'],'baseline_and_trial_metrics_exact':True,'parent_profile_branch_witnesses_exact':12,
 'actual_profile_branch_counters_exact':True,'actual_return_poses_not_recomputed':True,'exact_choice_poses_verified':True,
 'source_inventory_and_poses_verified':True,'exact_parent_reconstruction':True,'unchanged_other_files':155,
 'production_unchanged':True,'measured_search_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','reconstruction.json','instrumentation.patch','runner-method.json']:shutil.copyfile(probe/name,out/name)
shutil.copyfile(probe/'authored-trace-reader/checks.json',out/'reader-checks.json')
doc=f'''# Actual return seeds and exchange outcomes — observation preparation, 2026-10-18

The [failed free-space pilot](h5-free-return-pilot-20261018.md) accepts eight
mechanical exchanges in 75 attempts, yet all four mechanical material pairs fail.
Its aggregate counters cannot explain which returned parts moved or why the
final material remains high. This diagnostic observes that exact candidate.

It captures each actual contained return pose and the pose subsequently passed
to source repair, along with the unchanged source members, charged work counts,
receiver/source repair losses, repaired source poses and every validated material
trial, including acceptance. It does not reconstruct an obsolete seed formula.
The original choices, conditions, short-circuit time reads, random draws, work
charges, repairs, validation and material guards remain unchanged. Logging and
serialization can perturb wall trajectories; this is not a quality comparison.

All 137 unchanged optimized tests, strict lint and the executable build pass.
Removing the recorded substitutions reconstructs all 156 files exactly, with
155 unchanged. Sixteen authored test cases exercise actual logs. All
{reader['frozen_CLI_baseline_checks']} saved baselines and {reader['frozen_CLI_trial_checks']}
actual material trials pass the frozen CLI with exact metrics. Twelve parent
branch witnesses and counters match exactly. The reader checks every unchanged
source pose against its original baseline and choice, returned membership/order,
rotation/reflection, finite work counters and their cap, repair stage consistency,
trial quantities and original material predicates. Forty-four malformed records
are rejected. Five clearly labelled synthetic parser cases test receiver failure,
deadline and material classification only; they are not geometry evidence. The
original qualification assumed a native receiver failure would occur, but the
actual logs contain none. That failed reader and all captured logs remain. The
same sixteen executions are reused without repetition; receiver classification
is covered only by the labelled synthetic case. Native receiver-failure coverage
is explicitly not claimed.

The planned diagnostic uses both mechanical jobs, both kerfs, seed zero and
60 seconds per case, serially on physical CCD0 CPU 8. Its original measurement
method is unchanged apart from expected result cardinality increasing from two
to four. Every final output, baseline, recorded material trial and seed/repair
snapshot still needs independent original-geometry inspection. Failed snapshots
remain failures, and a finite repair failure proves no global packing bound.

No measurement has started at this qualification checkpoint. Production,
reserved geometry, release and original H5 limits remain unchanged.
**H2/H5 remain open; completed milestone weight is 60%.**

[Checks](h5-free-return-observer-preparation-20261018/checks.json),
[reader qualification](h5-free-return-observer-preparation-20261018/reader-checks.json),
[exact source reconstruction](h5-free-return-observer-preparation-20261018/reconstruction.json),
[raw evidence](h5-free-return-observer-preparation-20261018/raw.zip),
[archive and member hashes](h5-free-return-observer-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n');print(json.dumps(checks|{'archive_bytes':archive.stat().st_size,'sealed_members':len(inventory)}))
