"""Preserve missing native branch coverage; reuse actual logs and label synthetic coverage."""
from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-free-return-observer-20261018';out=probe/'reader-coverage-failure';out.mkdir()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
p=root/'output/check_h5_free_return_observer_reader.py';shutil.copyfile(p,out/'failed-reader.py')
cached=probe/'authored-trace-reader';rows=load(cached/'progress.json');assert len(rows)==16
outcomes={}
for row in rows:
 for k,v in row['outcomes'].items():outcomes[k]=outcomes.get(k,0)+v
assert outcomes.get('receiver_repair_failed',0)==0 and outcomes.get('source_repair_or_expiry',0)>0
record={'reason':'All sixteen captured authored tests completed; no receiver_repair_failed observation exists, so the old reader qualification assumption raised StopIteration. Preserve actual logs; cover the receiver-only parser branch with an explicitly synthetic record and make no native coverage claim.',
 'test_binary_sha256':digest(next((Path(load(probe/'preparation.json')['target'])/'release/deps').glob('nestbolt_core-*.exe'))),
 'captured_outcomes':outcomes,'cached_files':{str(f.relative_to(cached)):digest(f) for f in cached.iterdir() if f.is_file()}}
(out/'checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(cached/'progress.json',out/'original-progress.json')
s=p.read_text(encoding='utf-8').replace("out.mkdir()", "out.mkdir(exist_ok=True)")
a='''    r=subprocess.run(command,capture_output=True,timeout=120)
    (out/(name+'-stdout.log')).write_bytes(r.stdout);(out/(name+'-stderr.log')).write_bytes(r.stderr)'''
b='''    cache=load(probe/'reader-coverage-failure/checks.json')
    assert digest(binary)==cache['test_binary_sha256']
    for suffix in ['-stdout.log','-stderr.log']:
        assert digest(out/(name+suffix))==cache['cached_files'][name+suffix]
    r=subprocess.CompletedProcess(command,0,(out/(name+'-stdout.log')).read_bytes(),(out/(name+'-stderr.log')).read_bytes())'''
assert s.count(a)==1;s=s.replace(a,b)
a="receiver_trace=next(t for t in all_traces if any(a['outcome']=='receiver_repair_failed' for a in t['attempts']))\nreceiver_index=next(i for i,a in enumerate(receiver_trace['attempts']) if a['outcome']=='receiver_repair_failed')\nassert summary['reason_counts']['source_loss_positive']>0 and summary['reason_counts']['receiver_loss_positive']>0"
b="receiver_trace=copy.deepcopy(source_trace);receiver_index=source_index\nreceiver_attempt=receiver_trace['attempts'][receiver_index];receiver_attempt['outcome']='receiver_repair_failed'\nreceiver_attempt['repair_detail']={'receiver_loss':1.0,'source_loss':None,'source_after':None};receiver_attempt['material_detail']=None\nreceiver_summary=runner.check_traces([receiver_trace]);assert receiver_summary['reason_counts']['receiver_loss_positive']>0\nassert summary['reason_counts']['source_loss_positive']>0"
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('synthetic=[]',"synthetic=['parser-only positive receiver loss classification; this branch did not occur in the actual authored logs']")
s=s.replace('assert len(synthetic)==4 and len(rejected)==44','assert len(synthetic)==5 and len(rejected)==44')
s=s.replace("'new_searches':0}","'cached_authored_executions_reused':16,'native_receiver_failure_observed':False,'new_searches':0}")
compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'repair.py')
print(json.dumps({'actual_tests_preserved':16,'native_outcomes':outcomes,'new_authored_test_runs':0,'synthetic_receiver_case_labelled':True}))
