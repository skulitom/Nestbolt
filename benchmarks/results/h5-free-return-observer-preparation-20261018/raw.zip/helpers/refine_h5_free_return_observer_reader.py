from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-free-return-observer-20261018'
script=ast.parse((root/'output/prepare_h5_free_return_observer_reader.py').read_text(encoding='utf-8'))
reader=next(ast.literal_eval(n.value) for n in script.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='reader' for t in n.targets))
p=root/'scripts/h5_free_return_observer.py';s=p.read_text(encoding='utf-8');start=s.index('def check_traces(');end=s.index('def parse_log(',start)
s=s[:start]+reader+s[end:];compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
method=json.loads((probe/'runner-method.json').read_bytes());method['runner_sha256']=sha256(p.read_bytes()).hexdigest()
(probe/'runner-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Reader now verifies every remaining original source pose against the actual baseline.')
