"""Extend the qualified exact-copy reader for actual seeds, repairs and material outcomes."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];out=root/'output/h5-free-return-observer-20261018'
ref=root/'scripts/h5_exchange_failure_observer.py';original=ref.read_text(encoding='utf-8')
s=original.replace('h5-exchange-failure-observer','h5-free-return-observer').replace('h5_exchange_failure_observer','h5_free_return_observer')
s=s.replace('import h5_boundary_pair_pilot as prior','import h5_free_return_pilot as prior').replace("ROOT/'scripts/h5_boundary_pair_pilot.py'", "ROOT/'scripts/h5_free_return_pilot.py'")
s=s.replace("OLD = ROOT/'benchmarks/results/h5-boundary-pair-pilot-20261018'", "OLD = ROOT/'benchmarks/results/h5-free-return-pilot-20261018'")
s=s.replace("JOBS = ['m-mechanical-panel-hardware']", "JOBS = ['m-mechanical-large-plates','m-mechanical-panel-hardware']")
s=s.replace("'attempts':2", "'attempts':4").replace('len(records)==2','len(records)==4')
end=s.index('"""',3)+3
s='''"""Observe actual free-return seeding and subsequent repair/material outcomes.

Four diagnostic-only searches: both mechanical jobs, both kerfs, seed zero,
60 seconds, serial physical CCD0 CPU 8. No search decision, work charge,
deadline, random draw, geometry or acceptance guard changes. All 137 tests
are unchanged. Logging can perturb wall trajectories; no quality claim.
"""'''+s[end:]
a="'source_change':'Add failure details only after the original short-circuit branches reject: exact loss and source poses, or validated trial layout and material. The original conditions, clock reads, work charges and 130 tests remain. Recomputed return poses are pure and are observed only after failure.'"
b="'source_change':'Capture actual contained and placed return poses, source inventory, work counters, repair losses and full validated material outcomes including acceptance. No former seed formula is recomputed. Removing observation code reconstructs the failed candidate exactly; all 137 tests remain unchanged.'"
assert s.count(a)==1;s=s.replace(a,b)
reader='''def check_traces(traces, stats=None):
    import copy
    import h5_boundary_pair_observer as parent
    stripped=copy.deepcopy(traces);observations=[]
    count_fields={'constructor_checks','containers','evaluated_vertices','evaluations','rect_operations',
                  'registered_items','tracked_items','tracked_vertices','validated_vertices'}
    def finite(value):
        assert type(value) in [int,float] and math.isfinite(value) and value>=0
    def poses(values):
        assert isinstance(values,list)
        for p in values:pose_key(p)
        return Counter(p['part_id'] for p in values)
    for invocation,(trace,clean) in enumerate(zip(traces,stripped)):
        base=trace['baseline'];inventory=Counter({p['id']:p['quantity'] for p in base['job']['parts']})
        source=Counter(p['part_id'] for p in base['layout']['placements'] if p['sheet_id']==base['source_sheet'])
        for index,(attempt,without) in enumerate(zip(trace['attempts'],clean['attempts'])):
            seed=without.pop('return_seed_detail');repair=without.pop('repair_detail');material=without.pop('material_detail')
            outcome=attempt['outcome'];choice=trace['choices'][attempt['choice_index']]
            expected=source.copy();expected.subtract(choice);assert all(v>=0 for v in expected.values());expected=+expected
            if outcome=='forbidden_incoming_orientation':
                assert seed is repair is material is None
                continue
            assert isinstance(seed,dict) and set(seed)=={'source_before','contained','placed','work_before','work_after'}
            assert poses(seed['source_before'])==expected
            physical_source=Counter(pose_key({'part_id':p['part_id'],'transform':p['transform']})
                for p in base['layout']['placements'] if p['sheet_id']==base['source_sheet'])
            physical_source.subtract(pose_key(p) for p in trace['choice_poses'][attempt['choice_index']])
            assert all(v>=0 for v in physical_source.values())
            assert Counter(pose_key(p) for p in seed['source_before'])==+physical_source
            expected.update(attempt['returned'])
            assert poses(seed['contained'])==poses(seed['placed'])==Counter(attempt['returned'])
            assert [p['part_id'] for p in seed['contained']]==[p['part_id'] for p in seed['placed']]==attempt['returned']
            for before,after in zip(seed['contained'],seed['placed']):
                for field in ['rotation_radians','mirrored']:assert before['transform'][field]==after['transform'][field]
            for work in [seed['work_before'],seed['work_after']]:
                assert isinstance(work,dict) and set(work)==count_fields
                for v in work.values():finite(v)
            delta={k:seed['work_after'][k]-seed['work_before'][k] for k in count_fields}
            assert all(v>=0 for v in delta.values()) and delta['evaluations']<=257*len(attempt['returned'])
            assert all(delta[k]==0 for k in count_fields-{'evaluations','evaluated_vertices','rect_operations'})
            assert isinstance(repair,dict) and set(repair)=={'receiver_loss','source_loss','source_after'}
            finite(repair['receiver_loss'])
            if outcome=='receiver_repair_failed':
                assert repair['receiver_loss']>0 and repair['source_loss'] is repair['source_after'] is material is None
                reason='receiver_loss_positive'
            else:
                assert repair['receiver_loss']==0;finite(repair['source_loss']);assert poses(repair['source_after'])==expected
                if outcome=='source_repair_or_expiry':
                    assert material is None
                    reason='source_loss_positive' if repair['source_loss']>0 else 'source_deadline'
                else:
                    assert repair['source_loss']==0;reason=outcome
            if outcome in ['material_guard_or_expiry','neutral_inventory_rejected','accepted']:
                assert isinstance(material,dict) and set(material)=={'material_increased','metrics','layout'}
                after=material['metrics'];old=base['metrics'];finite(after['material_area'])
                assert type(after['sheets_used']) is int and after['sheets_used']>0
                assert type(material['material_increased']) is bool
                increased=after['sheets_used']>old['sheets_used'] or after['material_area']>old['material_area']
                assert material['material_increased']==increased
                layout=material['layout'];assert set(layout)==set(base['layout'])
                assert Counter(p['part_id'] for p in layout['placements'])==inventory
                assert len({(p['part_id'],p['copy_index']) for p in layout['placements']})==len(layout['placements'])
                known_sheets={p['sheet_id'] for p in base['layout']['placements']}
                for p in layout['placements']:
                    assert p['sheet_id'] in known_sheets;pose_key({'part_id':p['part_id'],'transform':p['transform']})
                if outcome=='accepted':
                    assert not increased
                    if Counter(choice)==Counter(attempt['returned']):assert after['material_area']<old['material_area']
                elif outcome=='neutral_inventory_rejected':
                    assert Counter(choice)==Counter(attempt['returned']) and not increased and after['material_area']==old['material_area']
                else:reason='material_increased' if increased else 'exchange_deadline'
            else:assert material is None
            observations.append({'invocation':invocation,'attempt_index':index,'choice_index':attempt['choice_index'],
                'target_sheet':attempt['target_sheet'],'outcome':outcome,'reason':reason,'work_delta':delta,
                'return_seed_detail':seed,'repair_detail':repair,'material_detail':material})
    result=parent.check_traces(stripped,stats);result['traces']=traces
    result['attempt_observations']=observations;result['reason_counts']=dict(Counter(o['reason'] for o in observations))
    result['actual_seed_and_stage_records_verified']=True
    return result


'''
start=s.index('def check_traces(');end=s.index('def parse_log(',start);s=s[:start]+reader+s[end:]
target=root/'scripts/h5_free_return_observer.py';assert not target.exists();compile(s,str(target),'exec');target.write_text(s,encoding='utf-8',newline='\n')
def fn(t,n):return next(x for x in ast.parse(t).body if isinstance(x,ast.FunctionDef) and x.name==n)
for name in ['pose_key','parse_log','read_trace']:assert ast.dump(fn(s,name))==ast.dump(fn(original,name))
# Only expected result cardinality differs in the serial measurement method.
assert ast.dump(fn(s.replace('len(records)==4','len(records)==2'),'run'))==ast.dump(fn(original,'run'))
method={'reference':ref.relative_to(root).as_posix(),'reference_sha256':sha256(ref.read_bytes()).hexdigest(),
 'runner_sha256':sha256(target.read_bytes()).hexdigest(),'measurement_function_AST_exact_except_result_count':True,
 'pose_and_archive_reader_functions_AST_exact':True,'case_method_reused_unchanged':True,'jobs_expanded_to_both_mechanical_jobs':True}
(out/'runner-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(method))
