"""Qualify actual authored trace coverage, independent baselines and malformed inputs."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-free-return-observer-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_free_return_observer as runner
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_passed'];out=probe/'authored-trace-reader';out.mkdir()
target=Path(load(probe/'preparation.json')['target']);binaries=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1;binary=binaries[0]
names=['balanced_pair_moves_two_incoming_and_three_returns','balanced_pair_without_return_room_preserves_incumbent',
    'balanced_pair_disabled_or_expired_preserves_incumbent','return_frame_alternative_respects_strict_material_guard',
    'productive_exchange_requires_gain_for_changed_equal_inventory','productive_exchange_keeps_same_inventory_when_material_decreases',
    'mixed_pair_moves_different_parts_and_three_returns','mixed_pair_preserves_a_frozen_sheet','mixed_pair_failed_return_room_preserves_incumbent',
    'larger_return_moves_both_incoming_with_strict_material_guard','larger_return_disabled_or_expired_preserves_incumbent',
    'larger_return_failed_room_preserves_incumbent','larger_return_preserves_a_frozen_sheet','accepted_exchange_still_fills_a_known_gap',
    'exact_duplicate_guard_allows_only_gain_and_preserves_disabled_boundaries','material_profile_guard_allows_only_gain_and_preserves_disabled_boundaries']
rows=[];all_traces=[];witnesses=[]
for name in names:
    command=[str(binary),'--exact','sheets::vstrip::exchange::tests::'+name,'--nocapture']
    r=subprocess.run(command,capture_output=True,timeout=120)
    (out/(name+'-stdout.log')).write_bytes(r.stdout);(out/(name+'-stderr.log')).write_bytes(r.stderr)
    assert r.returncode==0 and '1 passed; 0 failed' in r.stdout.decode(),name
    traces=runner.parse_log(r.stderr.decode());summary=runner.check_traces(traces)
    all_traces+=traces
    row={'test':name,'command':command,'exit_code':r.returncode,**{k:v for k,v in summary.items() if k not in ['traces','attempt_rows','visit_rows','attempt_observations']}}
    rows.append(row);runner.write(out/'progress.json',rows)
    if name==names[-1]:
        witnesses=[json.loads(line.removeprefix('PROFILE_REJECT_WITNESS ')) for line in r.stderr.decode().splitlines() if line.startswith('PROFILE_REJECT_WITNESS ')]
        assert len(witnesses)==12
        totals=Counter()
        for i,w in enumerate(witnesses):
            assert w==load(root/f'output/h5-free-return-probe-20261018/branch-checks/case-{i}/observation.json')
            totals.update(w['stats'])
        runner.check_traces(traces,dict(totals))
summary=runner.check_traces(all_traces)
assert summary['outcomes']['accepted']>=4
assert summary['outcomes']['material_profile_rejected']>0
assert summary['outcomes']['source_repair_or_expiry']>0
accepted=next(t for t in all_traces if any(a['outcome']=='accepted' for a in t['attempts']))
def mutate_attempt(t,**values):next(a for a in t['attempts'] if a['outcome']=='accepted').update(values)
def reject(name,mutate,stats=None):
    t=copy.deepcopy(accepted);mutate(t)
    try:runner.check_traces([t],stats)
    except (AssertionError,KeyError,TypeError,IndexError):return name
    raise AssertionError('Reader accepted '+name)
rejected=[
    reject('unknown incoming family',lambda t:t['choices'][0].__setitem__(0,'missing')),
    reject('missing single-copy choice',lambda t:t['choices'].pop()),
    reject('duplicate visit',lambda t:t['visits'].append(t['visits'][0])),
    reject('negative visit index',lambda t:t['visits'][0].update(choice_index=-1)),
    reject('too many retained proposals',lambda t:t['visits'][0].update(retained_proposals=7)),
    reject('source used as target',lambda t:t['visits'][0].update(target_sheet=t['baseline']['source_sheet'])),
    reject('unknown returned family',lambda t:mutate_attempt(t,returned=['missing'])),
    reject('four returned members',lambda t:mutate_attempt(t,returned=[t['choices'][0][0]]*4)),
    reject('unfinished outcome',lambda t:mutate_attempt(t,outcome='pending')),
    reject('negative attempt index',lambda t:mutate_attempt(t,choice_index=-1)),
    reject('attempt after acceptance',lambda t:t['attempts'].append(t['attempts'][-1])),
    reject('inconsistent counters',lambda t:None,{'directed_exchange_attempts':999999}),
    reject('nonfinite material',lambda t:t['baseline']['metrics'].update(material_area=float('nan'))),
    reject('unknown credited sheet',lambda t:t['baseline']['metrics'].update(last_sheet_id='missing')),
    reject('missing baseline',lambda t:t.pop('baseline')),
]
def first_pair(t):return next(i for i,c in enumerate(t['choices']) if len(c)==2)
rejected += [
    reject('missing physical poses',lambda t:t.pop('choice_poses')),
    reject('missing physical choice',lambda t:t['choice_poses'].pop()),
    reject('duplicate physical pair member',lambda t:t['choice_poses'][first_pair(t)].__setitem__(1,t['choice_poses'][first_pair(t)][0])),
    reject('nonfinite physical translation',lambda t:t['choice_poses'][0][0]['transform']['translation'].__setitem__(0,float('nan'))),
    reject('unmatched physical pose',lambda t:t['choice_poses'][0][0]['transform']['translation'].__setitem__(0,999999.0)),
]

different=next(t for t in all_traces if any(Counter(t['choices'][a['choice_index']])!=Counter(a['returned']) for a in t['attempts']))
t=copy.deepcopy(different)
next(a for a in t['attempts'] if Counter(t['choices'][a['choice_index']])!=Counter(a['returned']))['outcome']='material_profile_rejected'
try:runner.check_traces([t])
except AssertionError:rejected.append('neutral rejection with changed inventory')
else:raise AssertionError('Reader accepted changed inventory as neutral')
# Mutations of actual records test failure-closed parsing. These do not prove geometry.
source_trace=next(t for t in all_traces if any(a['outcome']=='source_repair_or_expiry' for a in t['attempts']))
source_index=next(i for i,a in enumerate(source_trace['attempts']) if a['outcome']=='source_repair_or_expiry')
receiver_trace=next(t for t in all_traces if any(a['outcome']=='receiver_repair_failed' for a in t['attempts']))
receiver_index=next(i for i,a in enumerate(receiver_trace['attempts']) if a['outcome']=='receiver_repair_failed')
assert summary['reason_counts']['source_loss_positive']>0 and summary['reason_counts']['receiver_loss_positive']>0
def reject_detail(name,original,index,mutate):
    t=copy.deepcopy(original);mutate(t['attempts'][index])
    try:runner.check_traces([t])
    except (AssertionError,KeyError,TypeError,IndexError):rejected.append(name)
    else:raise AssertionError('Reader accepted '+name)
for value in [-1.0,float('nan'),True,None]:
    reject_detail('invalid source loss '+repr(value),source_trace,source_index,lambda a,v=value:a['repair_detail'].update(source_loss=v))
reject_detail('missing seed detail',source_trace,source_index,lambda a:a.pop('return_seed_detail'))
reject_detail('missing contained pose',source_trace,source_index,lambda a:a['return_seed_detail']['contained'].pop())
reject_detail('missing actual pose',source_trace,source_index,lambda a:a['return_seed_detail']['placed'].pop())
reject_detail('missing original source member',source_trace,source_index,lambda a:a['return_seed_detail']['source_before'].pop())
reject_detail('changed original source pose',source_trace,source_index,lambda a:a['return_seed_detail']['source_before'][0]['transform']['translation'].__setitem__(0,999999.0))
reject_detail('changed returned rotation',source_trace,source_index,lambda a:a['return_seed_detail']['placed'][0]['transform'].update(rotation_radians=0.123))
reject_detail('changed returned reflection',source_trace,source_index,lambda a:a['return_seed_detail']['placed'][0]['transform'].update(mirrored=not a['return_seed_detail']['contained'][0]['transform']['mirrored']))
reject_detail('nonfinite actual seed',source_trace,source_index,lambda a:a['return_seed_detail']['placed'][0]['transform']['translation'].__setitem__(0,float('inf')))
reject_detail('missing work counter',source_trace,source_index,lambda a:a['return_seed_detail']['work_after'].pop('evaluations'))
reject_detail('negative work delta',source_trace,source_index,lambda a:a['return_seed_detail']['work_after'].update(evaluations=0))
reject_detail('unbounded seed evaluations',source_trace,source_index,lambda a:a['return_seed_detail']['work_after'].update(evaluations=1e12))
reject_detail('unrelated validator work',source_trace,source_index,lambda a:a['return_seed_detail']['work_after'].update(validated_vertices=1e12))
reject_detail('missing repaired member',source_trace,source_index,lambda a:a['repair_detail']['source_after'].pop())
reject_detail('zero receiver failure',receiver_trace,receiver_index,lambda a:a['repair_detail'].update(receiver_loss=0.0))
accepted_index=next(i for i,a in enumerate(accepted['attempts']) if a['outcome']=='accepted')
reject_detail('missing accepted material',accepted,accepted_index,lambda a:a.update(material_detail=None))
reject_detail('false material classification',accepted,accepted_index,lambda a:a['material_detail'].update(material_increased=True))
reject_detail('missing accepted placement',accepted,accepted_index,lambda a:a['material_detail']['layout']['placements'].pop())
reject_detail('nonfinite accepted material',accepted,accepted_index,lambda a:a['material_detail']['metrics'].update(material_area=float('inf')))
reject_detail('unknown accepted sheet',accepted,accepted_index,lambda a:a['material_detail']['layout']['placements'][0].update(sheet_id='unknown'))
synthetic=[]
t=copy.deepcopy(source_trace);t['attempts'][source_index]['repair_detail']['source_loss']=0.0
check=runner.check_traces([t]);assert any(d['attempt_index']==source_index and d['reason']=='source_deadline' for d in check['attempt_observations'])
synthetic.append('parser-only zero source loss distinguishes original deadline branch; no geometry claim')
for mode in ['deadline','material_area','sheets_used']:
    t=copy.deepcopy(accepted);a=t['attempts'][accepted_index];a['outcome']='material_guard_or_expiry'
    a['material_detail']['metrics']=copy.deepcopy(t['baseline']['metrics']);a['material_detail']['material_increased']=False
    if mode!='deadline':a['material_detail']['metrics'][mode]+=1;a['material_detail']['material_increased']=True
    check=runner.check_traces([t]);expected='exchange_deadline' if mode=='deadline' else 'material_increased'
    assert any(d['attempt_index']==accepted_index and d['reason']==expected for d in check['attempt_observations'])
    synthetic.append('parser-only '+mode+' classification; layout/metrics intentionally not geometry evidence')
assert len(synthetic)==4 and len(rejected)==44

cli=root/'target/release/nestbolt.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
for i,trace in enumerate(all_traces):
    case=out/f'baseline-{i}';case.mkdir();base=trace['baseline']
    runner.write(case/'job.json',base['job']);runner.write(case/'layout.json',base['layout'])
    args=[str(cli),'validate','--job',str(case/'job.json'),'--layout',str(case/'layout.json')]
    r=subprocess.run(args,capture_output=True,timeout=60)
    (case/'stdout.json').write_bytes(r.stdout);(case/'stderr.log').write_bytes(r.stderr)
    runner.write(case/'command.json',{'command':args,'exit_code':r.returncode})
    checked=json.loads(r.stdout);assert r.returncode==0 and checked['valid'] and checked['metrics']==base['metrics']
material_checks=0
for invocation,trace in enumerate(all_traces):
    for index,attempt in enumerate(trace['attempts']):
        detail=attempt['material_detail']
        if detail is None:continue
        case=out/f'trial-{invocation}-{index}';case.mkdir()
        runner.write(case/'job.json',trace['baseline']['job']);runner.write(case/'layout.json',detail['layout'])
        args=[str(cli),'validate','--job',str(case/'job.json'),'--layout',str(case/'layout.json')]
        r=subprocess.run(args,capture_output=True,timeout=60)
        (case/'stdout.json').write_bytes(r.stdout);(case/'stderr.log').write_bytes(r.stderr)
        runner.write(case/'command.json',{'command':args,'exit_code':r.returncode})
        value=json.loads(r.stdout);assert r.returncode==0 and value['valid'] and value['metrics']==detail['metrics'];material_checks+=1
runner.write(out/'actual-traces.json',all_traces)
runner.write(out/'checks.json',{'all_checks_pass':True,'synthetic_parser_cases':synthetic,'actual_failure_reason_counts':summary['reason_counts'],'source_return_inventories_verified':True,'authored_test_traces':rows,'actual_invocations':len(all_traces),
    'malformed_records_rejected':rejected,'frozen_CLI_baseline_checks':len(all_traces),
    'frozen_CLI_trial_checks':material_checks,'baseline_and_trial_metrics_exact':True,'parent_profile_branch_witnesses_exact':12,
    'actual_profile_branch_counters_exact':True,'all_choice_poses_match_unique_baseline_members':True,'reader_sha256':digest(root/'scripts/h5_free_return_observer.py'),
    'test_binary_sha256':digest(binary),'CLI_sha256':digest(cli),'new_searches':0})
shutil.copyfile(binary,probe/'authored-tests.exe');shutil.copyfile(__file__,out/'check.py')
print(json.dumps({'authored_tests':len(rows),'actual_invocations':len(all_traces),'malformed_rejected':len(rejected),'frozen_CLI_baselines':len(all_traces),'frozen_CLI_trials':material_checks,'parent_branch_witnesses_exact':12}))
