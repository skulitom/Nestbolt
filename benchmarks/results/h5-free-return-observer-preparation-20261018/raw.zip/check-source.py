"""Rebuild the observation source from recorded substitutions; verify exact reversal."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-free-return-observer-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');parent=Path(plan['old_source']);fresh=out/'reconstruction/workspace'
assert load(out/'build.json')['all_passed'];shutil.copytree(parent,fresh)
rel=plan['changed_file'];original=(parent/rel).read_text(encoding='utf-8');text=original
changes=load(out/'substitutions.json')
for before,after in changes:
    assert text.count(before)==1;text=text.replace(before,after)
reverse=text
for before,after in reversed(changes):
    assert reverse.count(after)==1;reverse=reverse.replace(after,before)
assert reverse==original
(fresh/rel).write_text(text,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
records=[]
for row in plan['source_files']:
    rel=row['path'];assert digest(parent/rel)==row['sha256']
    assert (fresh/rel).read_bytes()==(out/'workspace'/rel).read_bytes(),rel
    if rel not in plan['changed_files']:assert digest(fresh/rel)==row['sha256']
    records.append({'path':rel,'sha256':digest(fresh/rel)})
result={'exact_parent_reversal':True,'all_formatted_files_exact':True,'files':records,
    'unchanged_other_files':len(records)-1,'all_137_original_tests_unchanged':True,'added_tests':0,'new_searches':0}
(out/'reconstruction.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'check-source.py');print(json.dumps({k:v for k,v in result.items() if k!='files'}))
