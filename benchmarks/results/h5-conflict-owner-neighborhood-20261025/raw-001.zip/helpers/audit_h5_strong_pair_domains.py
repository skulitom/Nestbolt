"""Independent whole-region coverage, rational inequalities and integer SAT atlas."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime,timezone
from itertools import product
import json,math,shutil,time,traceback
from shapely.geometry import shape,MultiPoint,Point
from shapely.geometry.polygon import orient
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-strong-pair-convex-domains-recovered-20261025'
OLD=ROOT/'output/h5-strong-pair-convex-domains-20261025'
REG=ROOT/'output/h5-original-fixed-pair-regions-recovered-20261025'
GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
PRIOR=ROOT/'output/h5-pair-core-relocation-regions-20261025'
OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def hull(points):
    pts=sorted(set(map(tuple,points)))
    def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    low=[];high=[]
    for p in pts:
        while len(low)>1 and cross(low[-2],low[-1],p)<=0:low.pop()
        low.append(p)
    for p in reversed(pts):
        while len(high)>1 and cross(high[-2],high[-1],p)<=0:high.pop()
        high.append(p)
    return low[:-1]+high[:-1]

def admits(face,x,y):
    a,b,c,d=face['coordinate_bounds']
    return a<=x<=c and b<=y<=d and all(h['a']*x+h['b']*y<=h['upper'] for h in face['halfplanes'])

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json');result=load(BASE/'result.json')
    inputs=[BASE/n for n in ['plan.json','result.json','support-atlas.json','recovery-plan.json']]
    inputs += [REG/n for n in ['plan.json','audit/checks.json','audit/surviving-neighborhoods.json']]
    inputs += [GEO/'moving-proxies.json',GEO/'audit/checks.json',SRC/'hint-poses.json',PRIOR/'solve/positions.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'audit_limit_seconds':120,'query_hashes':{p.name:digest(p) for p in sorted((BASE/'queries').glob('*.json'))},
          'method':'Independently reconstruct all207 surviving cases,286 allocations and every eligible role/mode query. Verify byte-identical reuse of40 completed queries after the empty-set guard repair. Reconstruct each face square expansion, require the complete expanded union to cover the whole certified source region, and verify all expanded vertices against rationally reconstructed outward integer bounds and every rounded halfplane. Check all source region bytes against committed evidence. Independently derive every support value and all324 ordered convex-component Minkowski sums using exact integer monotone-chain hulls; require every hull edge normal in the common separation basis. Check source-pose integer representatives and prior false-anchor status. No solver or acceptance claim.'})
    start=time.perf_counter();assert result['queries_completed']==result['queries_planned']==2206 and not load(BASE/'pending.json')
    assert result['total_domains']==32626 and not result['domain_cap_reached'] and not result['merge_cap_queries'] and not result['merge_time_queries']
    assert load(REG/'audit/checks.json')['passed'] and load(GEO/'audit/checks.json')['passed']
    recovery=load(BASE/'recovery-plan.json');assert recovery['wall_seconds_plan_to_failure']<60 and result['seconds']<60
    assert recovery['failed_phase_conservative_charge_seconds']+recovery['remaining_query_limit_seconds']==120
    for n,h in recovery['completed_query_hashes'].items():assert digest(OLD/'queries'/n)==digest(BASE/'queries'/n)==h
    assert digest(OLD/'support-atlas.json')==digest(BASE/'support-atlas.json')
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    cases=[]
    for c in load(REG/'audit/surviving-neighborhoods.json'):
        cases.append({'case':c['case'],'released_items':c['released_items'],'families':c['families'],
                      'allocations':[{'prior_allocation':a['prior_allocation'],'value':a['allocation']} for a in c['allocations'] if not a['excluded_by_empty_role']]})
    assert cases==plan['cases'] and len(cases)==207 and sum(len(c['allocations']) for c in cases)==286
    caseby={c['case']:c for c in cases};expected=[]
    for q in load(REG/'plan.json')['queries']:
        if q['case'] not in caseby:continue
        permitted=set()
        for a in caseby[q['case']]['allocations']:
            if q['role']=='bracket':permitted.update(s for s in [0,1] if a['value']['brackets_per_sheet'][s])
            else:permitted.add(a['value']['restored_sheets'][int(q['role'][-1])])
        if q['sheet'] in permitted:expected.append({**q,'index':len(expected),'region_query':q['index']})
    assert expected==plan['queries']
    manifest=ROOT/'benchmarks/results/h5-original-outline-collision-regions-20261025/raw-manifest.json'
    mf=load(manifest);members=mf['files']+mf['aliases'];byhash={r['sha256']:r for r in members};provenance=[]
    for p in [REG/'plan.json',REG/'audit/checks.json',REG/'audit/surviving-neighborhoods.json',GEO/'moving-proxies.json',GEO/'audit/checks.json',SRC/'hint-poses.json']:
        h=digest(p);assert h in byhash,p;provenance.append({'source':p.relative_to(ROOT).as_posix(),'sha256':h,'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':byhash[h]['path']})
    atlas=load(BASE/'support-atlas.json');moving=load(GEO/'moving-proxies.json');components=[];normals=set();specs=[]
    for m in moving:
        if m['family']=='cog':cs=[m['vertices_units10000']]
        else:cs=[[[r[0]*100,r[1]*100],[r[2]*100,r[1]*100],[r[2]*100,r[3]*100],[r[0]*100,r[3]*100]] for r in m['components_units100']]
        for points in cs:
            assert hull(points)==hull(hull(points))
            for a,b in zip(points,points[1:]+points[:1]):
                nx,ny=b[1]-a[1],a[0]-b[0];div=math.gcd(nx,ny);normals.add((nx//div,ny//div))
            components.append(points)
        specs.append({'moving_proxy':m['index'],'family':m['family'],'class':m['class'],'components':cs})
    normals=sorted(normals);assert atlas['normals']==[list(n) for n in normals] and len(normals)==20
    assert atlas['opposite_normal_indices']==[normals.index((-x,-y)) for x,y in normals]
    assert (atlas['geometry_units_per_mm'],atlas['coordinate_units_per_mm'],atlas['geometry_units_per_coordinate_unit'])==(10000,100,100)
    for s in specs:s['supports']=[[max(a*x+b*y for x,y in c) for a,b in normals] for c in s['components']]
    assert atlas['proxies']==specs and len(components)==18
    pair_count=facet_count=0
    for a,b in product(components,repeat=2):
        summed=hull([(x-u,y-v) for x,y in a for u,v in b]);assert len(summed)>=3
        for p,q in zip(summed,summed[1:]+summed[:1]):
            nx,ny=q[1]-p[1],p[0]-q[0];div=math.gcd(nx,ny);assert (nx//div,ny//div) in normals;facet_count+=1
        for nx,ny in normals:
            assert max(nx*x+ny*y for x,y in summed)==max(nx*x+ny*y for x,y in a)+max(-nx*x-ny*y for x,y in b)
        pair_count+=1
    hintmap={r['item']:r for r in load(SRC/'hint-poses.json')};querychecks=[];domains=edges=vertex_tests=source_poses=0
    selected=load(PRIOR/'solve/positions.json');candidate_tests=[]
    for q in expected:
        assert time.perf_counter()-start<120
        stored=load(BASE/'queries'/f"{q['index']:04d}.json");assert stored['query']==q
        p=ROOT/stored['source_cover'];h=digest(p);assert h==stored['source_cover_sha256']==plan['region_cover_hashes'][str(q['region_query'])] and h in byhash
        source_region=shape(load(p)['cover']);assert source_region.is_empty==stored['source_empty'];polys=[]
        for i,face in enumerate(stored['domains']):
            assert face['index']==i;raw=shape(face['raw_face']);poly=shape(face['expanded_convex_face']);assert raw.is_valid and poly.is_valid and poly.equals(poly.convex_hull)
            expanded=MultiPoint([(x+dx,y+dy) for x,y in list(raw.exterior.coords)[:-1] for dx,dy in [(-.001,-.001),(-.001,.001),(.001,.001),(.001,-.001)]]).convex_hull
            assert expanded.equals(poly) and poly.covers(raw);pts=list(orient(poly,sign=1).exterior.coords);vertices=[[F(v) for v in point] for point in pts[:-1]]
            bx=[math.floor(min(x for x,y in vertices)*100),math.floor(min(y for x,y in vertices)*100),
                math.ceil(max(x for x,y in vertices)*100),math.ceil(max(y for x,y in vertices)*100)]
            assert bx==face['coordinate_bounds'] and 0<=bx[0]<=bx[2]<=150000 and 0<=bx[1]<=bx[3]<=300000
            reconstructed=[]
            for p0,p1 in zip(pts,pts[1:]):
                x,y=map(F,p0);u,v=map(F,p1);aa=v-y;bb=x-u
                if not aa and not bb:continue
                unit=max(abs(aa),abs(bb));aa/=unit;bb/=unit;cc=aa*x+bb*y
                A=round(aa*10**7);B=round(bb*10**7);error=abs(F(A)-aa*10**7)*150000+abs(F(B)-bb*10**7)*300000+1
                C=math.ceil(cc*100*10**7+error)
                reconstructed.append({'edge':[list(p0),list(p1)],'a':A,'b':B,'upper':C,'rounding_error_bound':[error.numerator,error.denominator]})
                assert (A or B) and max(abs(A)*150000+abs(B)*300000,abs(C))<2**60
                for vx,vy in vertices:assert A*vx*100+B*vy*100<=C;vertex_tests+=1
            assert reconstructed==face['halfplanes'];edges+=len(reconstructed);domains+=1;polys.append(poly)
        if source_region.is_empty:assert not polys
        else:assert polys and unary_union(polys).covers(source_region)
        if q['role']!='bracket':
            hint=hintmap[caseby[q['case']]['released_items'][int(q['role'][-1])]]
            if hint['sheet']==q['sheet'] and hint['mode']==q['mode']:
                assert any(admits(f,hint['x_units'],hint['y_units']) for f in stored['domains']);source_poses+=1
        for p in selected['movable_parts']:
            if p['case']==q['case'] and p['query']==q['prior_query']:
                candidate_tests.append({'part':p['part'],'query':q['index'],'admitted_by_integer_domains':any(admits(f,p['x_units'],p['y_units']) for f in stored['domains'])})
        querychecks.append({'query':q['index'],'case':q['case'],'domains':len(polys),'whole_source_region_covered':True,'source_sha256':h})
        if len(querychecks)%400==0:print({'queries_audited':len(querychecks),'domains':domains,'seconds':time.perf_counter()-start},flush=True)
    assert domains==32626 and pair_count==324
    for p in selected['movable_parts']:
        if not any(t['part']==p['part'] for t in candidate_tests):candidate_tests.append({'part':p['part'],'query':None,'admitted_by_integer_domains':False,'reason':'No eligible query remains after audited allocation filtering'})
    assert not next(t['admitted_by_integer_domains'] for t in candidate_tests if t['part']==3)
    write(OUT/'provenance.json',{'source_members_matching_committed_evidence':provenance,'committed_region_cover_matches':len(querychecks)})
    write(OUT/'query-checks.json',querychecks);write(OUT/'selected-anchor-checks.json',candidate_tests)
    checks={'passed':True,'seconds':time.perf_counter()-start,'cases':207,'allocations':286,'queries':len(querychecks),
            'convex_domains':domains,'outward_rational_halfplanes':edges,'exact_vertex_inequality_checks':vertex_tests,
            'all_whole_source_regions_covered':True,'committed_source_matches':len(provenance),'committed_region_cover_matches':len(querychecks),
            'byte_identical_reused_queries':40,'source_pose_integer_memberships':source_poses,
            'exact_component_types':18,'common_edge_normals':20,'exact_ordered_minkowski_hulls':pair_count,'minkowski_facets_in_basis':facet_count,
            'all_integer_support_values_independently_reconstructed':True,'no_projection_rounding_required_with100_to1_scale':True,
            'selected_false_anchors_rejected':sum(not t['admitted_by_integer_domains'] for t in candidate_tests),
            'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
