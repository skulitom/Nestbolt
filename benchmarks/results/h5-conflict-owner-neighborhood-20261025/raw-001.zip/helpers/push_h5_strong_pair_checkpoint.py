from pathlib import Path
import datetime
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'output/h5-strong-pair-main-sync-20261025'
DEST.mkdir(exist_ok=False)

def run(args, name):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(args, cwd=ROOT, capture_output=True, text=True)
    record = dict(command=args, started_at=started,
                  completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)
    (DEST / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record), flush=True)
    result.check_returncode()
    return result.stdout.strip()

head = run(['git', 'rev-parse', 'HEAD'], 'head-before')
assert head == '51fe56c096103464379068c99e10993b5b8516bb'
main = run(['git', 'rev-parse', 'origin/main'], 'main-before')
assert main == '247e823a9feef2bf906e27204981b957dc55cdfc'
counts = run(['git', 'rev-list', '--left-right', '--count', 'origin/main...HEAD'], 'ahead-before')
assert counts.split() == ['0', '6']
assert not run(['git', 'diff', 'HEAD', '--name-only'], 'tracked-worktree-before')
run(['git', 'push', 'origin', 'HEAD:main'], 'push')
remote = run(['git', 'ls-remote', 'origin', 'refs/heads/main'], 'remote-main-after')
assert remote.split()[0] == head
run(['git', 'rev-parse', 'origin/main'], 'tracking-main-after')
run(['gh', 'run', 'list', '--repo', 'skulitom/Nestbolt', '--branch', 'main',
     '--commit', head, '--limit', '10', '--json',
     'databaseId,name,status,conclusion,headSha,url,createdAt,updatedAt'], 'new-ci-initial')
(DEST / 'receipt.json').write_text(json.dumps(dict(
    source_head=head, previous_main=main, pushed_commits=6,
    normal_fast_forward_push=True, remote_main_verified=True,
    previous_successful_ci=40233299884, new_ci_pass_claimed=False,
    H2_complete=False, H5_complete=False, completion_percent=60
), indent=2) + '\n', encoding='utf-8')
