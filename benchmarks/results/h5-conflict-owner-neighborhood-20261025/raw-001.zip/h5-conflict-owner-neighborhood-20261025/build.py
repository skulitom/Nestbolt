"""Fresh complete nine-part domains against 57 unchanged original outlines."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product
from collections import Counter
import json,math,shutil,time,traceback
from shapely.geometry import box,shape,mapping,MultiPoint,GeometryCollection
from shapely.geometry.polygon import orient
from shapely.affinity import translate
from shapely.ops import unary_union
from conservative_h5_round_obstacles import raw_obstacle
from build_h5_strong_pair_domains import convex_faces,halfplanes,support_atlas

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
PREV=ROOT/'output/h5-strong-pair-convex-domains-recovered-20261025'
OUT=ROOT/'output/h5-conflict-owner-neighborhood-20261025'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    assert load(GEO/'audit/checks.json')['passed'] and load(PREV/'audit/checks.json')['passed']
    assert load(PREV/'solve/result.json')['status']=='INFEASIBLE'
    OUT.mkdir();(OUT/'obstacles').mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    census=load(PREV/'next-neighborhood/census.json');items=load(SRC/'items.json');g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json')
    moving_ids=census['additional_mandatory_bracket_items']+census['released_original_items']
    movable=[items[i] for i in moving_ids];fixed_ids=census['fixed_original_items']
    assert len(movable)==9 and len(fixed_ids)==57 and set(moving_ids).isdisjoint(fixed_ids)
    assert set(moving_ids+fixed_ids)==set(range(66))
    assert Counter(items[i]['family'] for i in moving_ids+fixed_ids)==census['required_original_counts']
    proxies=load(GEO/'moving-proxies.json');inner=aux['inner_non_cog_components'][13]['components']
    assert len(inner)==1
    polygons=[box(*(v/100 for v in r)) for r in inner]
    proxies.append({'index':10,'family':'insert','class':13,'components_units100':inner,
                    'component_polygons':[mapping(p) for p in polygons],'geometry':mapping(unary_union(polygons))})
    byclass={p['class']:p['index'] for p in proxies}
    queries=[]
    for m in g['modes']:
        if m['family']=='bracket' or m['index'] in [22,23]:
            queries.append({'index':len(queries),'mode':m['index'],'family':m['family'],'class':m['class'],
                            'sheet':m['sheet'],'coordinate_bounds':m['coordinate_bounds'],'moving_proxy':byclass[m['class']]})
    for s,b in enumerate(g['cog_center_bounds']):
        queries.append({'index':len(queries),'mode':s,'family':'cog','class':None,'sheet':s,
                        'coordinate_bounds':b,'moving_proxy':byclass[None]})
    assert len(queries)==20
    for p in movable:
        assert sorted(q['mode'] for q in queries if q['family']==p['family'] and q['mode'] in p['allowed_modes'])==p['allowed_modes']
    inputs=[PREV/'next-neighborhood/census.json',PREV/'next-neighborhood/plan.json',PREV/'solve/result.json',PREV/'audit/checks.json']
    inputs += [SRC/n for n in ['items.json','geometry.json','propagation.json','hint-poses.json','plan.json']]
    inputs += [GEO/n for n in ['moving-proxies.json','fixed-originals.json','fixed-styles.json','cache-plan.json','audit/checks.json']]
    inputs += [ROOT/'output'/n for n in ['build_h5_strong_pair_domains.py','conservative_h5_round_obstacles.py','diagnose_h5_concave_gaps.py']]
    inputs += [ROOT/'benchmarks/results'/n/'raw-manifest.json' for n in ['h5-strong-pair-relocation-exclusion-20261025','h5-original-outline-collision-regions-20261025']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'reused_obstacle_hashes':{p.name:digest(p) for p in sorted((GEO/'obstacles').glob('*.json'))},
        'construction_limit_seconds':120,'maximum_domains':20000,'per_query_merge_attempt_limit':10000,
        'region_padding_mm':.001,'convex_padding_square_mm':.001,'coefficient_scale':10**7,
        'coordinate_units_per_mm':100,'coordinate_maxima':[150000,300000],
        'fixed_items':fixed_ids,'movable_parts':movable,'queries':queries,
        'fixed_original_area_units_per_sheet':census['fixed_original_area_units_per_sheet'],
        'required_original_counts':census['required_original_counts'],
        'method':'One new neighborhood:57 unchanged original outlines plus9 mandatory moving originals, restoring all7 collision-owner releases and both missing brackets. Reuse100 immutable fixed-original cache entries and append10 entries for the floor-safe vertical insert. Every mode starts from its complete original stock anchor rectangle. Subtract only certified strict-interior obstacles from all fixed originals on that sheet; positively pad the whole free region, including any line/point components. Require padded region plus excluded obstacles to cover the whole original anchor rectangle. Form complete outward convex domains with the audited expansion/rounding rules. No earlier two-core cells, source-position hints, pose samples or restricted sheet allocations. Original area charges retained. Separate independent audit before any bounded solver.'})
    start=time.perf_counter();deadline=start+120
    write(OUT/'moving-proxies.json',proxies);write(OUT/'support-atlas.json',support_atlas(proxies))
    fixed=[r for r in load(GEO/'fixed-originals.json') if r['item'] in fixed_ids]
    assert sorted(r['item'] for r in fixed)==fixed_ids
    write(OUT/'fixed-originals.json',fixed)
    for s in [0,1]:assert sum(aux['part_areas'][r['family']]['lower_units'] for r in fixed if r['sheet']==s)==census['fixed_original_area_units_per_sheet'][s]
    local={};cache_refs=[]
    for q in load(GEO/'cache-plan.json'):
        path=GEO/'obstacles'/f"{q['index']:03d}.json";row=load(path)
        local[(q['fixed_style'],q['moving_proxy'])]=shape(row['strict_interior_exclusion'])
        cache_refs.append({**q,'source':path.relative_to(ROOT).as_posix(),'sha256':digest(path),'reused':True})
    new_cache=[]
    for style in load(GEO/'fixed-styles.json'):
        assert time.perf_counter()<deadline
        raw=raw_obstacle(shape(style['geometry']),shape(proxies[10]['geometry']))
        excluded=raw.buffer(-.001,quad_segs=8).intersection(raw);margin=excluded.distance(raw.boundary)
        assert raw.is_valid and excluded.is_valid and not excluded.is_empty and excluded.difference(raw).is_empty and margin>.0005
        path=OUT/'obstacles'/f"{style['index']:03d}.json"
        row={'index':100+style['index'],'fixed_style':style['index'],'moving_proxy':10,
             'raw_forbidden':mapping(raw),'strict_interior_exclusion':mapping(excluded),'actual_boundary_margin_mm':margin}
        write(path,row);local[(style['index'],10)]=excluded;new_cache.append(row)
        cache_refs.append({'index':row['index'],'fixed_style':style['index'],'moving_proxy':10,
                           'source':path.relative_to(ROOT).as_posix(),'sha256':digest(path),'reused':False})
    write(OUT/'cache-references.json',cache_refs)
    absolute={(r['item'],mi):translate(local[(r['style'],mi)],*r['transform']['translation']) for r in fixed for mi in range(11)}
    records=[];total=0
    for q in queries:
        if time.perf_counter()>=deadline or total>=20000:break
        bounds=q['coordinate_bounds'];stock=box(*(v/100 for v in bounds))
        owners=[r['item'] for r in fixed if r['sheet']==q['sheet']]
        forbidden=unary_union([absolute[(i,q['moving_proxy'])] for i in owners])
        free=stock.difference(forbidden)
        region=free.buffer(.001,quad_segs=8) if not free.is_empty else GeometryCollection()
        assert free.is_valid and region.is_valid and (free.is_empty or region.covers(free))
        assert unary_union([region,forbidden]).covers(stock)
        faces,merge=convex_faces(region,deadline);domains=[];expanded_polys=[]
        for i,face in enumerate(faces):
            pts=list(face.exterior.coords)[:-1]
            expanded=orient(MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product(pts,[(-.001,-.001),(-.001,.001),(.001,.001),(.001,-.001)])]).convex_hull,sign=1)
            a,b,c,d=expanded.bounds;bounds=[math.floor(F(a)*100),math.floor(F(b)*100),math.ceil(F(c)*100),math.ceil(F(d)*100)]
            assert 0<=bounds[0]<=bounds[2]<=150000 and 0<=bounds[1]<=bounds[3]<=300000
            domains.append({'index':i,'raw_face':mapping(face),'expanded_convex_face':mapping(expanded),
                            'coordinate_bounds':bounds,'halfplanes':halfplanes(expanded)})
            expanded_polys.append(expanded)
        assert region.is_empty or unary_union(expanded_polys).covers(region)
        write(OUT/'queries'/f"{q['index']:04d}.json",{'query':q,'fixed_items':owners,
            'original_anchor_rectangle':mapping(stock),'strict_interior_forbidden_union':mapping(forbidden),
            'free_outer_region':mapping(free),'padded_region':mapping(region),'domains':domains,'merge':merge})
        total+=len(domains);records.append({'query':q['index'],'family':q['family'],'sheet':q['sheet'],'domains':len(domains),
                                          'empty':free.is_empty,**merge})
    write(OUT/'pending.json',queries[len(records):]);write(OUT/'query-summary.json',records)
    result={'seconds':time.perf_counter()-start,'fixed_originals':57,'mandatory_movable_originals':9,'required_originals':66,
        'queries_planned':20,'queries_completed':len(records),'pending_queries':20-len(records),'convex_domains':total,
        'reused_cache_entries':100,'new_cache_entries':len(new_cache),'empty_queries':sum(r['empty'] for r in records),
        'merge_cap_queries':sum(r['merge_cap_reached'] for r in records),'merge_time_queries':sum(r['merge_time_reached'] for r in records),
        'domain_cap_reached':total>=20000,'no_prior_neighborhood_domains_used':True,'independent_audit_pending':True,
        'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
