"""Independent new proxy, original-stock coverage and exact support audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
from collections import Counter
import json,math,shutil,time,traceback
import shapely
from shapely.geometry import Polygon,MultiPoint,Point,box,shape
from shapely.geometry.polygon import orient
from shapely.affinity import translate
from shapely.ops import unary_union
from audit_h5_strong_pair_domains import hull,admits

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-conflict-owner-neighborhood-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
PREV=ROOT/'output/h5-strong-pair-convex-domains-recovered-20261025'
OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    plan=load(BASE/'plan.json');result=load(BASE/'result.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(BASE.rglob('*.json')) if OUT not in p.parents},
        'method':'Verify source hashes against committed raw manifests, all57 fixed transforms, exact original counts/area charges, and full-stock rational coordinate bounds. Prove the new vertical insert proxy at every floor-error corner and derive its10 obstacles independently from unmerged original triangles. Reconstruct all20 free regions against all57 fixed owners, check their complete padded coverage and whole original stock-box coverage with the certified exclusions. Reconstruct each expanded convex face and every rational rounded inequality, checking all vertices and all restored source poses. Rebuild all exact integer supports and every ordered convex-component Minkowski hull. No solver or native acceptance.'})
    start=time.perf_counter();assert result['queries_completed']==20 and not load(BASE/'pending.json')
    assert not any(result[k] for k in ['merge_cap_queries','merge_time_queries','domain_cap_reached'])
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    for name,h in plan['reused_obstacle_hashes'].items():assert digest(GEO/'obstacles'/name)==h
    manifests=[ROOT/'benchmarks/results'/n/'raw-manifest.json' for n in
        ['h5-strong-pair-relocation-exclusion-20261025','h5-original-outline-collision-regions-20261025','h5-source-inventory-and-proxy-slot-coverage-20261025']]
    catalog={}
    for m in manifests:
        data=load(m)
        for r in data['files']+data['aliases']:catalog.setdefault(r['sha256'],(m,r['path']))
    sourcepath=ROOT/load(SRC/'plan.json')['hint_source'];jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
    diskpath=ROOT/'output/h5-cog-center-capacity-20261020/disk.json'
    trusted=[PREV/'next-neighborhood/census.json',SRC/'geometry.json',SRC/'items.json',SRC/'propagation.json',SRC/'hint-poses.json',sourcepath,jobpath,diskpath,
             GEO/'moving-proxies.json',GEO/'fixed-originals.json',GEO/'fixed-styles.json',GEO/'audit/checks.json']
    trusted += sorted((GEO/'obstacles').glob('*.json'))
    provenance=[]
    for p in trusted:
        h=digest(p);assert h in catalog,p;m,member=catalog[h]
        provenance.append({'source':p.relative_to(ROOT).as_posix(),'sha256':h,'manifest':m.relative_to(ROOT).as_posix(),
                           'manifest_sha256':digest(m),'member':member})
    census=load(PREV/'next-neighborhood/census.json');items=load(SRC/'items.json');g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json')
    released=[50,54,57,58,62,64,65];assert census['released_original_items']==released
    assert census['certified_fixed_conflict_owners']==[50,54,57,62,64]
    expected_ids=[28,29]+released;fixed_ids=sorted(set(range(66))-set(expected_ids))
    assert plan['movable_parts']==[items[i] for i in expected_ids] and plan['fixed_items']==fixed_ids and len(fixed_ids)==57
    assert Counter(i['family'] for i in items)==plan['required_original_counts']=={'frame':18,'bracket':12,'insert':21,'cog':15}
    job=load(jobpath);part_by={p['id']:p for p in job['parts']};source=load(sourcepath)
    for family in part_by:
        pts=[[F(v) for v in p] for p in part_by[family]['geometry'][0]['outer']]
        area=abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1])))/2
        assert aux['part_areas'][family]['lower_units']==math.floor(area*1000)
    fixed=load(BASE/'fixed-originals.json');expected_fixed=[r for r in load(GEO/'fixed-originals.json') if r['item'] in fixed_ids]
    assert fixed==expected_fixed;actual_fixed={};maxerr=0.
    for r in fixed:
        p=source['placements'][items[r['item']]['source_index']];t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        poly=Polygon([(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in part_by[r['family']]['geometry'][0]['outer']])
        err=poly.hausdorff_distance(shape(r['geometry']));assert err<1e-7;maxerr=max(maxerr,err);actual_fixed[r['item']]=poly
    areas=[sum(aux['part_areas'][r['family']]['lower_units'] for r in fixed if r['sheet']==s) for s in [0,1]]
    assert areas==plan['fixed_original_area_units_per_sheet']==census['fixed_original_area_units_per_sheet']
    proxies=load(BASE/'moving-proxies.json');assert proxies[:10]==load(GEO/'moving-proxies.json') and len(proxies)==11
    insert=proxies[10];assert insert['index']==10 and insert['family']=='insert' and insert['class']==13
    # Quarter-turn1 of the original insert, translated to a lower-left anchor.
    coords=[(-int(y),int(x)) for x,y in part_by['insert']['geometry'][0]['outer']]
    mx,my=min(x for x,y in coords),min(y for x,y in coords);original=Polygon([(x-mx,y-my) for x,y in coords])
    assert original.equals(box(0,0,110,180));rect=insert['components_units100'][0]
    assert insert['components_units100']==[[1,1,10999,17999]]==aux['inner_non_cog_components'][13]['components']
    floor_checks=0
    for x,y in [(rect[0],rect[1]),(rect[2],rect[1]),(rect[2],rect[3]),(rect[0],rect[3])]:
        for ex,ey in product([0,1],repeat=2):assert 0<=x-ex<=11000 and 0<=y-ey<=18000;floor_checks+=1
    newpoly=box(*(v/100 for v in rect));assert shape(insert['geometry']).equals(newpoly) and len(insert['component_polygons'])==1 and shape(insert['component_polygons'][0]).equals(newpoly)
    local={};new_obstacles=[];hulls=0;minmargin=float('inf');maxhd=0.;maxarea=0.
    refs=load(BASE/'cache-references.json');assert len(refs)==110 and len({(r['fixed_style'],r['moving_proxy']) for r in refs})==110
    styles=load(GEO/'fixed-styles.json')
    for r in refs:
        p=ROOT/r['source'];assert digest(p)==r['sha256'];row=load(p)
        assert all(row[k]==r[k] for k in ['index','fixed_style','moving_proxy'])
        exclusion=shape(row['strict_interior_exclusion']);local[(r['fixed_style'],r['moving_proxy'])]=exclusion
        if r['reused']:
            assert r['moving_proxy']<10 and p.parent==GEO/'obstacles' and r['sha256'] in catalog
            continue
        assert r['moving_proxy']==10 and r['index']==100+r['fixed_style']
        st=styles[r['fixed_style']];poly=shape(st['geometry']);triangles=list(shapely.constrained_delaunay_triangles(poly).geoms)
        assert unary_union(triangles).equals(poly)
        pieces=[MultiPoint([(a[0]-b[0],a[1]-b[1]) for a in list(t.exterior.coords)[:-1] for b in list(newpoly.exterior.coords)[:-1]]).convex_hull for t in triangles]
        reconstructed=unary_union(pieces);raw=shape(row['raw_forbidden']);hd=raw.hausdorff_distance(reconstructed);area=raw.symmetric_difference(reconstructed).area
        assert hd<1e-7 and area<1e-4 and exclusion.difference(reconstructed).is_empty
        margin=exclusion.distance(reconstructed.boundary);assert margin>.0005
        hulls+=len(pieces);minmargin=min(minmargin,margin);maxhd=max(maxhd,hd);maxarea=max(maxarea,area)
        new_obstacles.append({'fixed_style':r['fixed_style'],'hulls':len(pieces),'hausdorff_error_mm':hd,'symmetric_difference_mm2':area,'strict_margin_mm':margin})
    assert len(new_obstacles)==10
    # Derive every source stock bound with rational outward rounding.
    stocks=[[F(*v) for v in row] for row in g['stock_bounds_rational']];radius=F(load(diskpath)['radius_units'],10000)
    expected=[];byclass={p['class']:p['index'] for p in proxies}
    for m in g['modes']:
        if m['family']!='bracket' and m['index'] not in [22,23]:continue
        st=stocks[m['sheet']];cl=g['classes'][m['class']]
        bounds=[math.floor(st[0]*100)-1,math.floor(st[1]*100)-1,math.ceil((st[2]-cl['width'])*100)+1,math.ceil((st[3]-cl['height'])*100)+1]
        assert bounds==m['coordinate_bounds']
        expected.append({'index':len(expected),'mode':m['index'],'family':m['family'],'class':m['class'],'sheet':m['sheet'],'coordinate_bounds':bounds,'moving_proxy':byclass[m['class']]})
    for s,st in enumerate(stocks):
        bounds=[math.floor((st[0]+radius)*100)-1,math.floor((st[1]+radius)*100)-1,math.ceil((st[2]-radius)*100)+1,math.ceil((st[3]-radius)*100)+1]
        assert bounds==g['cog_center_bounds'][s]
        expected.append({'index':len(expected),'mode':s,'family':'cog','class':None,'sheet':s,'coordinate_bounds':bounds,'moving_proxy':byclass[None]})
    assert expected==plan['queries'] and len(expected)==20
    atlas=load(BASE/'support-atlas.json');components=[];specs=[];normals=set()
    for m in proxies:
        cs=[m['vertices_units10000']] if m['family']=='cog' else [[[r[0]*100,r[1]*100],[r[2]*100,r[1]*100],[r[2]*100,r[3]*100],[r[0]*100,r[3]*100]] for r in m['components_units100']]
        for pts in cs:
            components.append(pts)
            for a,b in zip(pts,pts[1:]+pts[:1]):
                nx,ny=b[1]-a[1],a[0]-b[0];d=math.gcd(nx,ny);normals.add((nx//d,ny//d))
        specs.append({'moving_proxy':m['index'],'family':m['family'],'class':m['class'],'components':cs})
    normals=sorted(normals);assert atlas['normals']==[list(n) for n in normals] and len(normals)==20
    assert atlas['opposite_normal_indices']==[normals.index((-x,-y)) for x,y in normals]
    assert [atlas[k] for k in ['geometry_units_per_mm','coordinate_units_per_mm','geometry_units_per_coordinate_unit']]==[10000,100,100]
    for s in specs:s['supports']=[[max(a*x+b*y for x,y in c) for a,b in normals] for c in s['components']]
    assert specs==atlas['proxies'] and len(components)==19
    facets=0
    for a,b in product(components,repeat=2):
        summed=hull([(x-u,y-v) for x,y in a for u,v in b])
        for p,q in zip(summed,summed[1:]+summed[:1]):
            nx,ny=q[1]-p[1],p[0]-q[0];d=math.gcd(nx,ny);assert (nx//d,ny//d) in normals;facets+=1
        for nx,ny in normals:assert max(nx*x+ny*y for x,y in summed)==max(nx*x+ny*y for x,y in a)+max(-nx*x-ny*y for x,y in b)
    hints=[h for h in load(SRC/'hint-poses.json') if h['item'] in released];domain_count=planes=tests=memberships=0;rows=[]
    for q in expected:
        assert time.perf_counter()-start<120
        row=load(BASE/'queries'/f"{q['index']:04d}.json");assert row['query']==q
        owners=[r for r in fixed if r['sheet']==q['sheet']];assert row['fixed_items']==[r['item'] for r in owners]
        obstacles=unary_union([translate(local[(r['style'],q['moving_proxy'])],*r['transform']['translation']) for r in owners])
        stock=box(*(v/100 for v in q['coordinate_bounds']));free=stock.difference(obstacles);region=shape(row['padded_region'])
        assert stock.equals(shape(row['original_anchor_rectangle'])) and obstacles.equals(shape(row['strict_interior_forbidden_union']))
        assert free.equals(shape(row['free_outer_region'])) and region.covers(free)
        assert unary_union([region,obstacles]).covers(stock)
        polys=[]
        for i,f in enumerate(row['domains']):
            assert f['index']==i;raw=shape(f['raw_face']);poly=shape(f['expanded_convex_face'])
            expanded=MultiPoint([(x+dx,y+dy) for x,y in list(raw.exterior.coords)[:-1] for dx,dy in [(-.001,-.001),(-.001,.001),(.001,.001),(.001,-.001)]]).convex_hull
            assert poly.is_valid and poly.equals(expanded) and poly.equals(poly.convex_hull) and poly.covers(raw)
            pts=list(orient(poly,sign=1).exterior.coords);vertices=[[F(v) for v in p] for p in pts[:-1]]
            bounds=[math.floor(min(x for x,y in vertices)*100),math.floor(min(y for x,y in vertices)*100),math.ceil(max(x for x,y in vertices)*100),math.ceil(max(y for x,y in vertices)*100)]
            assert bounds==f['coordinate_bounds'] and 0<=bounds[0]<=bounds[2]<=150000 and 0<=bounds[1]<=bounds[3]<=300000
            reconstructed=[]
            for p0,p1 in zip(pts,pts[1:]):
                x,y=map(F,p0);u,v=map(F,p1);aa,bb=v-y,x-u
                if not aa and not bb:continue
                scale=max(abs(aa),abs(bb));aa/=scale;bb/=scale;cc=aa*x+bb*y
                A,B=round(aa*10**7),round(bb*10**7);error=abs(F(A)-aa*10**7)*150000+abs(F(B)-bb*10**7)*300000+1;C=math.ceil(cc*100*10**7+error)
                assert (A or B) and max(abs(A)*150000+abs(B)*300000,abs(C))<2**60
                reconstructed.append({'edge':[list(p0),list(p1)],'a':A,'b':B,'upper':C,'rounding_error_bound':[error.numerator,error.denominator]})
                for vx,vy in vertices:assert A*vx*100+B*vy*100<=C;tests+=1
            assert reconstructed==f['halfplanes'];planes+=len(reconstructed);domain_count+=1;polys.append(poly)
        assert unary_union(polys).covers(region)
        for h in hints:
            if h['family']==q['family'] and h['mode']==q['mode']:
                assert any(admits(f,h['x_units'],h['y_units']) for f in row['domains']);memberships+=1
                proxy=translate(shape(proxies[q['moving_proxy']]['geometry']),h['x_units']/100,h['y_units']/100)
                for r in owners:assert proxy.intersection(actual_fixed[r['item']]).is_empty
        rows.append({'query':q['index'],'domains':len(polys),'fixed_owners':len(owners),'complete_original_anchor_rectangle_covered':True})
    assert domain_count==result['convex_domains'] and memberships==7
    write(OUT/'provenance.json',provenance);write(OUT/'new-obstacle-checks.json',new_obstacles);write(OUT/'query-checks.json',rows)
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_source_matches':len(provenance),
        'fixed_original_transforms':57,'maximum_fixed_transform_error_mm':maxerr,'mandatory_original_parts':66,
        'new_insert_floor_corner_checks':floor_checks,'reused_cache_entries':100,'new_cache_entries':10,
        'new_independent_triangle_minkowski_hulls':hulls,'maximum_new_obstacle_hausdorff_error_mm':maxhd,
        'maximum_new_obstacle_symmetric_difference_mm2':maxarea,'minimum_new_exclusion_interior_margin_mm':minmargin,
        'complete_original_stock_queries':20,'convex_domains':domain_count,'outward_halfplanes':planes,'rational_vertex_checks':tests,
        'released_source_pose_memberships':memberships,'all_original_stock_boxes_covered':True,'exact_component_types':19,
        'common_edge_normals':20,'exact_ordered_minkowski_hulls':361,'minkowski_facets_in_basis':facets,
        'every_mode_and_sheet_retained':True,'prior_two_core_domains_used':False,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
