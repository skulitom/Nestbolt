"""Verify the necessary-model solution, then diagnose a full original lift."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import combinations,product
from collections import Counter
import copy,json,math,shutil,time,traceback
from shapely.geometry import Polygon,Point,shape
from shapely.affinity import affine_transform,translate

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-conflict-owner-neighborhood-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';OUT=BASE/'solution-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    sourcepath=ROOT/load(SRC/'plan.json')['hint_source'];jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';diskpath=ROOT/'output/h5-cog-center-capacity-20261020/disk.json'
    inputs=[BASE/n for n in ['plan.json','audit/checks.json','solve/model-audit.json','solve/result.json','solve/positions.json','support-atlas.json','fixed-originals.json','moving-proxies.json']]
    inputs += [SRC/n for n in ['geometry.json','propagation.json','items.json','hint-poses.json']]+[sourcepath,jobpath,diskpath]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Check all66 required copies, all9 selected modes/domains/stock bounds, exact integer cross-part component separation and original area charges independently of solver assignments. Diagnose relaxed proxy intersections with57 fixed originals explicitly; outward padding can allow tiny false positives. Build one full original-outline trial preserving57 source transforms, choosing the recorded orientation for each non-cog and its own source angle for each restored cog. Check all original pairs and stock bounds. Use certified all-angle inscribed disks and full floor-center uncertainty to identify robust invalid anchors. This does not exhaust other cog angles/anchors or qualify native cutting geometry. No solver retry or native call on an invalid trial.'})
    start=time.perf_counter();assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'solve/model-audit.json')['passed']
    assert load(BASE/'solve/result.json')['has_complete_66_part_necessary_proxy_solution']
    plan=load(BASE/'plan.json');solution=load(BASE/'solve/positions.json');atlas=load(BASE/'support-atlas.json');proxies=load(BASE/'moving-proxies.json');fixed=load(BASE/'fixed-originals.json')
    g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json');items=load(SRC/'items.json');hints=load(SRC/'hint-poses.json');source=load(sourcepath);job=load(jobpath);parts={p['id']:p for p in job['parts']}
    disk=load(diskpath);center=[float(F(*v)) for v in disk['center']];radius=disk['radius_units']/10000
    assert solution['fixed_items']==plan['fixed_items'];moved=solution['movable_parts'];assert len(moved)==9
    records=[{'item':h['item'],'family':h['family'],'sheet':h['sheet'],'fixed':True} for h in hints if h['item'] in plan['fixed_items']]
    mutual=[];proxyfixed=[];domainchecks=[]
    for i,p in enumerate(moved):
        item=plan['movable_parts'][i];assert p['part']==i and p['item']==item['index'] and p['family']==item['family'] and p['mode'] in item['allowed_modes']
        q=plan['queries'][p['query']];assert all(q[k]==p[k] for k in ['family','sheet','class','mode','moving_proxy'])
        row=load(BASE/'queries'/f"{q['index']:04d}.json");face=row['domains'][p['domain']];x,y=p['x_units'],p['y_units']
        for b in [face['coordinate_bounds'],q['coordinate_bounds']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
        assert all(h['a']*x+h['b']*y<=h['upper'] for h in face['halfplanes'])
        domainchecks.append({'item':p['item'],'query':p['query'],'domain':p['domain'],'halfplanes_checked':len(face['halfplanes'])})
        records.append({**p,'fixed':False})
        actual=translate(shape(proxies[p['moving_proxy']]['geometry']),x/100,y/100)
        for r in fixed:
            if r['sheet']!=p['sheet']:continue
            obstacle=shape(r['geometry']);area=actual.intersection(obstacle).area
            if area>1e-8:proxyfixed.append({'moving_item':p['item'],'fixed_item':r['item'],'intersection_area_mm2':area,'distance_mm':actual.distance(obstacle)})
    for a,b in combinations(moved,2):
        if a['sheet']!=b['sheet']:continue
        sa=atlas['proxies'][a['moving_proxy']];sb=atlas['proxies'][b['moving_proxy']]
        for ai,bi in product(range(len(sa['components'])),range(len(sb['components']))):
            possible=[]
            for n,(nx,ny) in enumerate(atlas['normals']):
                left=100*(nx*(b['x_units']-a['x_units'])+ny*(b['y_units']-a['y_units']))
                right=max(nx*x+ny*y for x,y in sa['components'][ai])+max(-nx*x-ny*y for x,y in sb['components'][bi])
                if left>=right:possible.append({'normal':n,'exact_integer_margin':left-right})
            assert possible,(a['item'],b['item'],ai,bi)
            mutual.append({'items':[a['item'],b['item']],'components':[ai,bi],'separating_normals':possible})
    assert len(records)==len({r['item'] for r in records})==66 and {r['item'] for r in records}==set(range(66))
    assert Counter(r['family'] for r in records)==plan['required_original_counts']
    for family,count in plan['required_original_counts'].items():assert sorted(items[r['item']]['copy'] for r in records if r['family']==family)==list(range(count))
    areas=[sum(aux['part_areas'][r['family']]['lower_units'] for r in records if r['sheet']==s) for s in [0,1]]
    assert all(areas[s]<=aux['sheet_capacities'][s]['upper_area_units'] for s in [0,1])
    layout=copy.deepcopy(source);layout['placements']=[];shapes={};stockbounds=[[float(F(*v)) for v in row] for row in g['stock_bounds_rational']]
    for r in sorted(records,key=lambda r:r['item']):
        item=items[r['item']]
        if r['fixed']:p=copy.deepcopy(source['placements'][item['source_index']])
        else:
            x,y=r['x_units']/100,r['y_units']/100
            if r['family']=='cog':
                angle=source['placements'][item['source_index']]['transform']['rotation_radians'];mirror=False;c,s=math.cos(angle),math.sin(angle)
                tx=x-c*center[0]+s*center[1];ty=y-s*center[0]-c*center[1]
            else:
                cl=g['classes'][r['class']];angle=cl['quarter_turn']*math.pi/2;mirror=cl['mirrored'];c,s=math.cos(angle),math.sin(angle);mi=-1 if mirror else 1
                coords=[(mi*a*c-b*s,mi*a*s+b*c) for a,b in parts[r['family']]['geometry'][0]['outer']];tx=x-min(a for a,b in coords);ty=y-min(b for a,b in coords)
            p={'part_id':r['family'],'sheet_id':f"sheet-{r['sheet']}",'transform':{'rotation_radians':angle,'translation':[tx,ty],'mirrored':mirror}}
        p['copy_index']=item['copy'];layout['placements'].append(p);t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        shapes[r['item']]=affine_transform(Polygon(parts[r['family']]['geometry'][0]['outer']),[mi*c,-s,mi*s,c,tx,ty])
    write(OUT/'original-outline-trial.json',layout)
    byid={r['item']:r for r in records};collisions=[];stockfail=[];originalpairs=0
    for i,j in combinations(sorted(shapes),2):
        if byid[i]['sheet']!=byid[j]['sheet']:continue
        a,b=shapes[i],shapes[j];distance=a.distance(b);originalpairs+=1
        if distance<job['clearance']-1e-7:
            collisions.append({'items':[i,j],'families':[byid[i]['family'],byid[j]['family']],'distance_mm':distance,
                               'intersection_area_mm2':a.intersection(b).area,'involves_moved_part':not(byid[i]['fixed'] and byid[j]['fixed'])})
    assert all(r['involves_moved_part'] for r in collisions)
    for i,p in shapes.items():
        b=p.bounds;st=stockbounds[byid[i]['sheet']];violations=[max(0,st[0]-b[0]),max(0,st[1]-b[1]),max(0,b[2]-st[2]),max(0,b[3]-st[3])]
        if max(violations)>1e-7:stockfail.append({'item':i,'family':byid[i]['family'],'sheet':byid[i]['sheet'],'bounds':list(b),'stock_bounds':st,'violations_mm':violations})
    robust=[];uncertainty=math.sqrt(2)/100
    for p in moved:
        if p['family']!='cog':continue
        point=Point(p['x_units']/100,p['y_units']/100)
        for r in fixed:
            if r['sheet']!=p['sheet']:continue
            distance=point.distance(shapes[r['item']]);deficit=radius-uncertainty-distance
            if deficit>1e-7:robust.append({'kind':'moved_cog_vs_fixed_original','items':[p['item'],r['item']],'fixed_family':r['family'],
                'anchor_distance_to_original_mm':distance,'disk_radius_mm':radius,'maximum_center_floor_displacement_mm':uncertainty,'strict_overlap_margin_after_uncertainty_mm':deficit})
    for a,b in combinations([p for p in moved if p['family']=='cog'],2):
        if a['sheet']!=b['sheet']:continue
        distance=math.hypot(a['x_units']-b['x_units'],a['y_units']-b['y_units'])/100;deficit=2*radius-2*uncertainty-distance
        if deficit>1e-7:robust.append({'kind':'two_moved_cog_disks','items':[a['item'],b['item']],'center_distance_mm':distance,
            'disk_radius_mm':radius,'maximum_combined_floor_displacement_mm':2*uncertainty,'strict_overlap_margin_after_uncertainty_mm':deficit})
    write(OUT/'domain-memberships.json',domainchecks);write(OUT/'exact-moving-separations.json',mutual)
    write(OUT/'relaxed-proxy-fixed-intersections.json',proxyfixed);write(OUT/'original-pair-failures.json',collisions)
    write(OUT/'original-stock-failures.json',stockfail);write(OUT/'angle-independent-cog-conflicts.json',robust)
    assert time.perf_counter()-start<120
    checks={'passed':True,'seconds':time.perf_counter()-start,'all66_original_copies_present':True,'fixed_source_transforms_preserved':57,
        'mandatory_movable_parts':9,'selected_domain_and_mode_memberships':9,'exact_same_sheet_moving_component_pairs':len(mutual),
        'original_area_units_per_sheet':areas,'necessary_model_solution_verified':True,'relaxed_proxy_fixed_intersections':len(proxyfixed),
        'original_outline_trial_pairs':originalpairs,'original_outline_trial_pair_failures':len(collisions),'original_outline_trial_stock_failures':len(stockfail),
        'robust_angle_independent_cog_conflicts':len(robust),'original_outline_trial_valid':not collisions and not stockfail,
        'native_packing_calls':0,'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True);print({'robust_conflicts':robust},flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
