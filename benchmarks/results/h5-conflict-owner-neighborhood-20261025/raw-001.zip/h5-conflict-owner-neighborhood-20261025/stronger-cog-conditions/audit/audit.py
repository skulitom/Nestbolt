"""Independent rational halfplane and distance checks for stronger cog rules."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time,traceback

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-conflict-owner-neighborhood-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';PREP=BASE/'stronger-cog-conditions';OUT=PREP/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def distance2(p,points):
    # Ray crossing and clamped rational projections, independently of preparer.
    inside=False;dist=[]
    for a,b in zip(points,points[1:]+points[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1];length=dx*dx+dy*dy
        if not length:continue
        t=max(F(0),min(F(1),((p[0]-a[0])*dx+(p[1]-a[1])*dy)/length))
        dist.append((p[0]-a[0]-t*dx)**2+(p[1]-a[1]-t*dy)**2)
        if (a[1]>p[1])!=(b[1]>p[1]) and p[0]<a[0]+(p[1]-a[1])*dx/dy:inside=not inside
    return F(0) if inside else min(dist)

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(PREP.glob('*.json'))},
        'method':'Verify the original disk by independent rational ray crossing and clamped segment projections. Verify the convex-hull certificate as40 distinct original vertices with every original point inside every oriented halfplane, so the certified convex polygon equals the original convex hull. Check its centered support disk against every rational halfplane, derive both stock bounds and preserve all15 known source cog centers. Recompute every selected whole-circle pair distance, fixed-outline distance and stock exclusion. The support disk remains restricted to stock bounds, never collision geometry. No search.'})
    start=time.perf_counter();plan=load(PREP/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    cert=load(PREP/'certificate.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');disk=load(ROOT/'output/h5-cog-center-capacity-20261020/disk.json')
    original=next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer'];pts=[tuple(F(v) for v in p) for p in original];center=tuple(F(*v) for v in disk['center'])
    assert [list(v) for v in disk['center']]==cert['original_center_rational']
    assert cert['original_disk_radius_units10000']==disk['radius_units']==1091157
    r=cert['floor_safe_whole_circle_radius_units10000'];assert r==1091000 and cert['floor_error_square_side_units10000']==100
    assert (1091157-r)**2>20000 and cert['squared_radius_difference_margin_units']==(1091157-r)**2-20000
    assert distance2(center,pts)==0;ed=[]
    for a,b in zip(pts,pts[1:]+pts[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1];t=max(F(0),min(F(1),((center[0]-a[0])*dx+(center[1]-a[1])*dy)/(dx*dx+dy*dy)))
        d=(center[0]-a[0]-t*dx)**2+(center[1]-a[1]-t*dy)**2
        assert d>F(1091157,10000)**2;ed.append([d.numerator,d.denominator])
    assert ed==cert['original80_edge_distances_squared_mm2']
    hull=[tuple(F(*v) for v in p) for p in cert['convex_hull_rational_vertices']]
    assert len(hull)==len(set(hull))==40 and set(hull)<=set(pts)
    sides=[];tests=0
    for a,b in zip(hull,hull[1:]+hull[:1]):
        nx,ny=b[1]-a[1],a[0]-b[0];c=nx*a[0]+ny*a[1]
        for x,y in pts:assert nx*x+ny*y<=c;tests+=1
        margin=c-nx*center[0]-ny*center[1];assert margin>0;sides.append(margin*margin/(nx*nx+ny*ny))
    assert [[v.numerator,v.denominator] for v in sides]==cert['convex_hull_edge_support_distance_squared_mm2']
    radius=F(cert['all_angle_stock_support_lower_radius_units10000'],10000)
    assert all(radius*radius<d for d in sides) and radius>F(139,1)
    assert cert['hull_support_disk_must_not_be_used_for_collision'] is True
    g=load(SRC/'geometry.json');stocks=[[F(*v) for v in b] for b in g['stock_bounds_rational']]
    bounds=[[math.floor((s[0]+radius)*100)-1,math.floor((s[1]+radius)*100)-1,
             math.ceil((s[2]-radius)*100)+1,math.ceil((s[3]-radius)*100)+1] for s in stocks]
    assert bounds==cert['stronger_stock_center_bounds_units100']
    hints=[h for h in load(SRC/'hint-poses.json') if h['family']=='cog'];assert len(hints)==15
    for h in hints:
        b=bounds[h['sheet']];assert b[0]<=h['x_units']<=b[2] and b[1]<=h['y_units']<=b[3]
    moved=[p for p in load(BASE/'solve/positions.json')['movable_parts'] if p['family']=='cog'];fixed=load(BASE/'fixed-originals.json');pairchecks=[];fixedchecks=[];stockchecks=[]
    for a,b in combinations(moved,2):
        if a['sheet']!=b['sheet']:continue
        d=(a['x_units']-b['x_units'])**2+(a['y_units']-b['y_units'])**2
        pairchecks.append({'items':[a['item'],b['item']],'center_distance_squared_units100':d,'required_squared_distance_units100':21820**2,'excluded':d<21820**2})
    for p in moved:
        b=bounds[p['sheet']];x,y=p['x_units'],p['y_units'];stockchecks.append({'item':p['item'],'sheet':p['sheet'],'bounds':b,'anchor':[x,y],'excluded':not(b[0]<=x<=b[2] and b[1]<=y<=b[3])})
        for f in fixed:
            if f['sheet']!=p['sheet']:continue
            points=[tuple(F(v) for v in point) for point in f['geometry']['coordinates'][0][:-1]];d=distance2((F(x,100),F(y,100)),points);threshold=F(1091,10)**2
            fixedchecks.append({'moving_item':p['item'],'fixed_item':f['item'],'distance_squared_mm2':[d.numerator,d.denominator],
                                'radius_squared_mm2':[threshold.numerator,threshold.denominator],'excluded':d<threshold})
    assert pairchecks==load(PREP/'selected-cog-pair-checks.json') and fixedchecks==load(PREP/'selected-fixed-checks.json') and stockchecks==load(PREP/'selected-stock-checks.json')
    counts=[sum(r['excluded'] for r in rows) for rows in [pairchecks,fixedchecks,stockchecks]];assert counts==[3,2,3]
    checks={'passed':True,'seconds':time.perf_counter()-start,'original_disk_edges_independently_checked':80,
        'whole_floor_safe_circle_radius_mm':109.1,'convex_hull_vertices_verified_as_original_points':40,'exact_halfplane_memberships':tests,
        'all_angle_stock_support_lower_radius_mm':float(radius),'source_cog_centers_preserved':15,
        'selected_cog_pair_distances_checked':len(pairchecks),'selected_fixed_outline_distances_checked':len(fixedchecks),
        'selected_stock_anchors_checked':len(stockchecks),'selected_cog_pair_exclusions':counts[0],'selected_fixed_pair_exclusions':counts[1],
        'selected_stock_exclusions':counts[2],'no_convex_hull_collision_substitution':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    assert checks['seconds']<60;write(OUT/'checks.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
