"""Certify two stronger necessary cog conditions without another search."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time,traceback

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-conflict-owner-neighborhood-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';OUT=BASE/'stronger-cog-conditions'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rational(x):return [x.numerator,x.denominator]
def hull(points):
    points=sorted(set(points));low=[];high=[]
    def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    for p in points:
        while len(low)>1 and cross(low[-2],low[-1],p)<=0:low.pop()
        low.append(p)
    for p in reversed(points):
        while len(high)>1 and cross(high[-2],high[-1],p)<=0:high.pop()
        high.append(p)
    return low[:-1]+high[:-1]

def point_distance_squared(point,poly):
    winding=0;distances=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1];px,py=point[0]-a[0],point[1]-a[1]
        cross=dx*py-dy*px;dot=dx*px+dy*py;length=dx*dx+dy*dy
        if not length:continue
        if a[1]<=point[1]<b[1] and cross>0:winding+=1
        if b[1]<=point[1]<a[1] and cross<0:winding-=1
        distances.append(px*px+py*py if dot<=0 else (point[0]-b[0])**2+(point[1]-b[1])**2 if dot>=length else cross*cross/length)
    return F(0) if winding else min(distances)

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';diskpath=ROOT/'output/h5-cog-center-capacity-20261020/disk.json'
    inputs=[jobpath,diskpath,SRC/'geometry.json',SRC/'hint-poses.json',BASE/'fixed-originals.json',BASE/'solve/positions.json',BASE/'solution-audit/checks.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'preparation_limit_seconds':60,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Prove the whole circle of radius109.1mm about a floored cog center is inside the original all-angle inscribed disk for every0.01mm floor error, using an exact squared radius-difference inequality. Independently derive the cog convex hull from all80 original vertices using rational arithmetic and certify a centered disk inside that hull. The hull disk is usable ONLY for necessary sheet-boundary supports, never as a filled collision proxy. Derive stronger stock anchor bounds from that universal support radius; retain all15 known compatible source cog centers. Check the selected9-part solution against exact cog-cog circle distances, rational point-to-fixed-original distances and the stronger stock bounds. Preparation only: no new solver call, no original-layout acceptance.'})
    start=time.perf_counter();job=load(jobpath);disk=load(diskpath);g=load(SRC/'geometry.json');center=tuple(F(*v) for v in disk['center'])
    original=next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer'];pts=[tuple(F(v) for v in p) for p in original]
    R=disk['radius_units'];r=1091000;difference=R-r;assert difference>0 and difference*difference>2*100*100
    # Recheck original disk containment, including winding and every edge distance.
    assert point_distance_squared(center,pts)==0
    edge_distances=[]
    for a,b in zip(pts,pts[1:]+pts[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1];px,py=center[0]-a[0],center[1]-a[1];dot=dx*px+dy*py;length=dx*dx+dy*dy;cross=dx*py-dy*px
        d=px*px+py*py if dot<=0 else (center[0]-b[0])**2+(center[1]-b[1])**2 if dot>=length else cross*cross/length
        assert d>F(R,10000)**2;edge_distances.append(d)
    convex=hull(pts);sides=[];point_checks=0
    for a,b in zip(convex,convex[1:]+convex[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1];cross=dx*(center[1]-a[1])-dy*(center[0]-a[0]);assert cross>0
        for p in pts:assert dx*(p[1]-a[1])-dy*(p[0]-a[0])>=0;point_checks+=1
        sides.append(cross*cross/(dx*dx+dy*dy))
    minimum=min(sides);radius_units=math.isqrt(minimum.numerator*10000**2//minimum.denominator)-1
    hull_radius=F(radius_units,10000);assert all(hull_radius*hull_radius<d for d in sides)
    assert all(p in pts for p in convex) and len(convex)>=3
    stocks=[[F(*v) for v in b] for b in g['stock_bounds_rational']]
    stronger=[]
    for st in stocks:
        stronger.append([math.floor((st[0]+hull_radius)*100)-1,math.floor((st[1]+hull_radius)*100)-1,
                         math.ceil((st[2]-hull_radius)*100)+1,math.ceil((st[3]-hull_radius)*100)+1])
    source=[h for h in load(SRC/'hint-poses.json') if h['family']=='cog'];assert len(source)==15
    for h in source:
        b=stronger[h['sheet']];assert b[0]<=h['x_units']<=b[2] and b[1]<=h['y_units']<=b[3]
    moved=[p for p in load(BASE/'solve/positions.json')['movable_parts'] if p['family']=='cog'];fixed=load(BASE/'fixed-originals.json')
    pairchecks=[];fixedchecks=[];stockchecks=[];circle_radius_units100=r//100;assert r%100==0
    for a,b in combinations(moved,2):
        if a['sheet']!=b['sheet']:continue
        squared=(a['x_units']-b['x_units'])**2+(a['y_units']-b['y_units'])**2
        pairchecks.append({'items':[a['item'],b['item']],'center_distance_squared_units100':squared,
                           'required_squared_distance_units100':(2*circle_radius_units100)**2,'excluded':squared<(2*circle_radius_units100)**2})
    for p in moved:
        anchor=(F(p['x_units'],100),F(p['y_units'],100));bounds=stronger[p['sheet']]
        stockchecks.append({'item':p['item'],'sheet':p['sheet'],'bounds':bounds,'anchor':[p['x_units'],p['y_units']],
                            'excluded':not(bounds[0]<=p['x_units']<=bounds[2] and bounds[1]<=p['y_units']<=bounds[3])})
        for f in fixed:
            if f['sheet']!=p['sheet']:continue
            poly=[tuple(F(v) for v in point) for point in f['geometry']['coordinates'][0][:-1]]
            distance=point_distance_squared(anchor,poly);threshold=F(r,10000)**2
            fixedchecks.append({'moving_item':p['item'],'fixed_item':f['item'],'distance_squared_mm2':rational(distance),
                                'radius_squared_mm2':rational(threshold),'excluded':distance<threshold})
    write(OUT/'certificate.json',{'original_disk_radius_units10000':R,'floor_safe_whole_circle_radius_units10000':r,
        'floor_error_square_side_units10000':100,'squared_radius_difference_margin_units':difference*difference-20000,
        'original80_edge_distances_squared_mm2':[rational(v) for v in edge_distances],
        'original_center_rational':[rational(v) for v in center],'convex_hull_rational_vertices':[[rational(x),rational(y)] for x,y in convex],
        'convex_hull_edge_support_distance_squared_mm2':[rational(v) for v in sides],
        'all_angle_stock_support_lower_radius_units10000':radius_units,'stronger_stock_center_bounds_units100':stronger,
        'hull_support_disk_must_not_be_used_for_collision':True})
    write(OUT/'selected-cog-pair-checks.json',pairchecks);write(OUT/'selected-fixed-checks.json',fixedchecks);write(OUT/'selected-stock-checks.json',stockchecks)
    checks={'passed':True,'seconds':time.perf_counter()-start,'exact_original_edge_checks':80,'full_floor_error_square_certified':True,
        'whole_circle_radius_mm':r/10000,'convex_hull_vertices':len(convex),'exact_original_point_halfplane_checks':point_checks,
        'all_angle_minimum_stock_support_mm':radius_units/10000,'all15_source_cog_centers_preserved':True,
        'selected_cog_pair_tests':len(pairchecks),'selected_cog_pairs_excluded':sum(r['excluded'] for r in pairchecks),
        'selected_cog_fixed_tests':len(fixedchecks),'selected_cog_fixed_pairs_excluded':sum(r['excluded'] for r in fixedchecks),
        'selected_cog_stock_tests':len(stockchecks),'selected_cog_stock_anchors_excluded':sum(r['excluded'] for r in stockchecks),
        'independent_certificate_audit_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    assert checks['seconds']<60;write(OUT/'checks.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
