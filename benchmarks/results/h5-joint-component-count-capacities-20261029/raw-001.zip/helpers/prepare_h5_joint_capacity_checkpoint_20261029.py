from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/seal_h5_finite_pose_checkpoint_20261029.py').read_text(encoding='utf-8')
archive=old[old.index('OUT.mkdir();members='):old.index('copies=[]')]
archive=archive.replace('for folder in [CENTROID,BOUNDARY,FAST,BASE,DIAGONAL,SYNC]:','for folder in [JOINT,BASE]:')
a=archive.index('helpers=set()');b=archive.index('while queue:')
archive=archive[:a]+'''helpers=set()
for pattern in ['*h5_joint_component_capacity*20261029.py','*h5_separated_component_capacity*20261029.py','*h5_component_subset_halfspaces*20261029.py','*h5_joint_capacity*20261029.py']:
    helpers.update((ROOT/'output').glob(pattern))
helpers.update(ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','ccd1.py','push_h5_finite_pose_checkpoint_20261029.py',Path(__file__).name])
for p in sorted(helpers):add('helpers/'+p.name,p)
add('publication/h5-finite-pose-push-pending-20261029.json',ROOT/'output/h5-finite-pose-push-pending-20261029.json')
'''+archive[b:]
header='''"""Seal independent continuous component-count capacity proofs and their diagnostics."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-first55-separated-component-capacity-20261029';JOINT=ROOT/'output/h5-first55-joint-component-capacity-20261029';SUBSET=BASE/'subset-halfspaces';PUB=BASE/'publication';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
NAME='h5-joint-component-count-capacities-20261029';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
def append(p,v):
    with p.open('a',encoding='utf-8',newline='\\n') as f:f.write(v)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='c228096782655f2310e2c7008f1916eb5ae3c2ea' and not git('diff','HEAD','--name-only')
for folder in [JOINT,BASE,SUBSET]:
    assert load(folder/'audit/checks.json')['passed'] and load(folder/'checks.json')['cap_overrun_seconds']==0
    assert load(folder/'audit/checks.json')['solver_calls']==load(folder/'audit/checks.json')['native_calls']==0
    assert load(folder/'audit/checks.json')['global_allocation_exclusions']==0 and load(folder/'audit/checks.json')['restricted_pairs_remaining']==29
one=load(BASE/'audit/checks.json');two=load(SUBSET/'audit/checks.json')
assert one['initial_distributions_independently_enumerated']==329 and one['count_distributions_excluded']==190 and one['necessary_area_certificates_verified']==33 and one['remaining_count_distributions']==139
assert two['initial_count_distributions']==139 and two['count_distributions_excluded']==7 and two['necessary_halfspace_certificates_verified']==6 and two['remaining_count_distributions']==132 and two['independent_exact_polygon_clippings']==118
assert digest(SHORT/'search/source-response/candidate-source11.json')=='8b7fa5f6ad765aab6fdba1a586c29d8cac2cce607ed1d7fcd0fb6938c4eeada0'
assert digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
prior=load(ROOT/'benchmarks/results/h5-finite-source-poses-and-equivalent-graph-reduction-20261029/publication-review.json');production=source_digest();readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert production==prior['production_digest'] and readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];remote=load(PUB/'main.json')['commit']['sha'];assert remote==ci['head_sha']=='286223aee0bead996d02a5c1ef4d8b4b403b904b' and ci['id']==40831504620
assert len(jobs)==6 and sum(j['conclusion']=='success' for j in jobs)==5 and [(j['name'],j['status']) for j in jobs if j['conclusion']!='success']==[('checks (windows-latest)','in_progress')]
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json';assert sum(r['excluded_by'] is None for r in load(frontier))==440
'''
footer='''copies=[]
for prefix,folder in [('joint',JOINT),('separated',BASE),('subset-halfspace',SUBSET)]:copies.extend([(folder/'checks.json',prefix+'-preparation.json'),(folder/'audit/checks.json',prefix+'-audit.json')])
copies.extend([(BASE/'all29-separated-bounds.json','all29-separated-bounds.json'),(SUBSET/'all29-subset-halfspaces.json','all29-subset-halfspaces.json'),(SUBSET/'audit/allowed-empty-site-pairs.json','allowed-empty-site-pairs.json'),(JOINT/'source-inner-rectangles.json','source-inner-rectangles.json'),(BASE/'next-step.json','next-step.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')])
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':remote,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40831504620,'main_all6_pass':False,'successful_jobs_at_snapshot':5,'pending_job':'checks (windows-latest)','normal_push_requires_all6_and_fresh_head_and_live_run_checks':True,'unchanged_frontier_path':frontier.relative_to(ROOT).as_posix(),'unchanged_frontier_sha256':digest(frontier),'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'independent_family_components_verified':122,'source_region_mappings_verified':6940,'initial_count_distributions':329,'necessary_area_certificates_verified':39,'count_distributions_excluded':197,'remaining_count_distributions':132,'independent_exact_polygon_clippings':118,'all_recorded_exclusions_independently_verified':True,'unrecorded_scan_values_diagnostic_only':True,'new_solver_calls':0,'native_calls':0,'new_restricted_site_exclusions':0,'restricted_site_pairs_remaining':29,'new_allocation_exclusions':0,'remaining_candidates':440,'source_valid_short11_preserved':True,'valid64_preserved':True,'source_valid66_created':False,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [finite source poses and equivalent graph reduction](../benchmarks/results/h5-finite-source-poses-and-equivalent-graph-reduction-20261029.md).';new=f'Latest H5 evidence: [joint component count capacities](../benchmarks/results/{NAME}.md).';assert s.count(old)==1
with status.open('w',encoding='utf-8',newline='\\n') as f:f.write(s.replace(old,new,1))
append(ROOT/'.gitattributes',f'\\nbenchmarks/results/{NAME}/** -text -whitespace\\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'verified_count_exclusions':197,'remaining_count_distributions':132,'restricted_site_pairs_remaining':29,'remaining_allocations':440,'new_solver_calls':0,'completion_percent':60})
'''
s=header+archive+footer;p=ROOT/'output/seal_h5_joint_capacity_checkpoint_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
v=(ROOT/'output/verify_h5_local_grid_archive_20261029.py').read_text(encoding='utf-8').replace('h5-local-grid-construction-and-component-halfspaces-20261029','h5-joint-component-count-capacities-20261029')
with (ROOT/'output/verify_h5_joint_capacity_archive_20261029.py').open('x',encoding='utf-8',newline='\n') as f:f.write(v)
print({'prepared':p.name})
