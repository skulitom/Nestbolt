
**2026-10-29 H5 joint component count capacities:**
[independent source/component audits]({link}) verify 39 necessary area certificates
that eliminate 197 of 329 distributions of seven brackets and six inserts among
their continuous source-support components. The remaining 132 distributions span
all 29 retained cog-site choices; no full site choice or overall allocation is
excluded. The readers verify 122 family components, 6,940 source-region mappings
and every recorded exclusion; the last six certificates use 118 independent exact
polygon clippings. Unrecorded scan values remain diagnostic. All preparation caps
pass, and no new solver or native call was opened. The next model will constrain
component counts while keeping positions variable inside original source hulls.
The 440 allocation candidates, valid short11/64, production source, READMEs,
releases and reserved H2 vectors remain unchanged. H2/H5 remain open at 60%.
