"""Extract and verify the exact fixed core for a fresh actual-compound query."""
from collections import Counter
from datetime import datetime,timezone
from itertools import combinations
import copy,math,shutil
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_latest_wide_joint import ROOT,SRC,OUT as BASE,load,write,digest
OUT=ROOT/'output/h5-latest-wide-compound-core-20261023'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'check.py')
    source=BASE/'layout-audit/layout-final.json';inputs=[source,BASE/'layout-audit/checks.json',BASE/'candidates.json',ROOT/'output/h5-two-sheet-cog-group-choice-20261023/layout-audit/layout-final.json']+[SRC/n for n in ['job.json','conditional-target.json']]+[ROOT/'output/h5-cog-lattices-20261018/all-patterns.json']
    assert load(inputs[1])['passed'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Extract exactly the 18 frames and 15 cogs from the newly checked 64-part layout without moving them. Preserve the entire original 64-part source as the next completion seed. Recheck core original geometry, all same-sheet pairs, stock and allowed transforms. Map every source pose to the current complete pool. Inventory the 36 previously checked bracket/insert compounds for a future fresh actual-outline contact query against this core. No new contacts, candidates, solver, native packing or repeated CLI call occur here; this subset geometry check is not a full-job acceptance.', 'new_queries':0,'solver_calls':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    layout=load(source);assert Counter(p['part_id'] for p in layout['placements'])==Counter(frame=18,cog=15,bracket=10,insert=21)
    core={**copy.deepcopy(layout),'placements':[copy.deepcopy(p) for p in layout['placements'] if p['part_id'] in ['frame','cog']]};assert len(core['placements'])==33
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};st=job['stocks'][0];target=load(SRC/'conditional-target.json');m=st['margins'];edge=job['edge_clearance'];gs=[]
    for p in core['placements']:
        part=parts[p['part_id']];t=p['transform'];g=shape(part,t);a,b,c,d=g.bounds;h=st['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert g.is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=st['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7;gs.append(g)
    pairs=0;minimum=math.inf
    for i,j in combinations(range(33),2):
        if core['placements'][i]['sheet_id']!=core['placements'][j]['sheet_id']:continue
        pairs+=1;d=gs[i].distance(gs[j]);minimum=min(minimum,d);assert gs[i].disjoint(gs[j]) and d>=job['clearance']-1e-7
    pool=load(BASE/'candidates.json');keys={identity(p['placement']):i for i,p in enumerate(pool)};mapped=[]
    for p in layout['placements']:
        p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert pool[i]['placement']==p;mapped.append(i)
    assert len(set(mapped))==64;fixed=sorted(i for i in mapped if pool[i]['placement']['part_id'] in ['frame','cog']);small=sorted(set(mapped)-set(fixed));assert len(fixed)==33 and len(small)==31
    older=load(inputs[3]);oldcog={identity(p) for p in older['placements'] if p['part_id']=='cog'};newcog={identity(p) for p in core['placements'] if p['part_id']=='cog'}
    patterns=load(inputs[-1]);compounds=sorted(n for n,p in patterns.items() if len(p['members'])>1 and all(m['part_id'] in ['bracket','insert'] for m in p['members']));assert len(compounds)==36
    write(OUT/'layout.json',core);shutil.copyfile(source,OUT/'source-seed.json');write(OUT/'mapping.json',{'fixed_candidates':fixed,'seed_candidates':small,'source_pool':(BASE/'candidates.json').relative_to(ROOT).as_posix(),'compound_patterns':compounds})
    checks={'passed':True,'fixed_core_count':33,'seed_count':64,'fixed_original_geometry_pairs':pairs,'minimum_distance_mm':minimum,'core_and_seed_coordinates_unchanged':True,'all_original_core_stock_transforms_checked':True,'source_poses_exactly_mapped':64,'core_cog_sheet_counts':dict(Counter(p['sheet_id'] for p in core['placements'] if p['part_id']=='cog')),'core_cog_poses_absent_from_previous_63':len(newcog-oldcog),'compound_patterns_available':36,'new_contact_queries_pending':True,'no_full_job_CLI_acceptance_claimed':True,'native_margin_qualified':False,'solver_calls':0}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
