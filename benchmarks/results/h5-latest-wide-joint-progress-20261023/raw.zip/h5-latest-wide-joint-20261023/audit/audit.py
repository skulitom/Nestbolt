"""Independent bounds scan, full original distance graph, filter and seed audit."""
from collections import Counter
from itertools import combinations
import copy,math,shutil,time
import numpy as np
import shapely
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_latest_wide_joint import ROOT,SRC,COVER,OUT,load,write,digest,read_graph
def main():
    dst=OUT/'audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');start=time.perf_counter()
    plan=load(OUT/'plan.json');mp=load(OUT/'mapping.json');coverage=load(COVER/'mapping.json');pool=load(OUT/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];target=load(SRC/'conditional-target.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    assert pool==load(ROOT/coverage['source_pool']) and mp['candidates']==coverage['candidates'] and mp['fixed_candidates']==coverage['fixed_candidates'] and mp['seeds']==coverage['seeds']
    ids=mp['candidates'];fixed=mp['fixed_candidates'];assert len(fixed)==18 and all(pool[i]['placement']['part_id']=='frame' for i in fixed)
    gg={i:shape(parts[p['placement']['part_id']],p['placement']['transform']) for i,p in enumerate(pool)};filters=load(COVER/'filter.json');eligible=[];fixedpairs=0
    for i,r in zip([i for i,p in enumerate(pool) if p['placement']['part_id']!='frame'],filters,strict=True):
        blockers=[]
        for j in fixed:
            if pool[i]['placement']['sheet_id']==pool[j]['placement']['sheet_id']:
                fixedpairs+=1
                if gg[i].distance(gg[j])<clear-1e-7:blockers.append(j)
        assert r=={'candidate':i,'fixed_blockers':blockers}
        if not blockers:eligible.append(i)
    assert ids==eligible
    for i in ids+fixed:
        p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform'];g=gg[i];a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        assert g.is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
    for i,j in combinations(fixed,2):assert gg[i].disjoint(gg[j]) and gg[i].distance(gg[j])>=clear-1e-7
    saved=read_graph(OUT/'adjacency.bin.gz',len(ids));expected=[0]*len(ids);gs=np.asarray([gg[i] for i in ids],dtype=object);bb=shapely.bounds(gs);ss=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);possible=near=0
    for i in range(len(ids)):
        js=np.arange(i+1,len(ids));js=js[ss[js]==ss[i]];possible+=len(js);dx=np.maximum(0,np.maximum(bb[js,0]-bb[i,2],bb[i,0]-bb[js,2]));dy=np.maximum(0,np.maximum(bb[js,1]-bb[i,3],bb[i,1]-bb[js,3]));js=js[np.hypot(dx,dy)<=clear+1e-7];near+=len(js)
        for j in js[shapely.distance(gs[i],gs[js])<clear-1e-7]:j=int(j);expected[i]|=1<<j;expected[j]|=1<<i
        if i and i%4000==0:print({'audit_rows':i,'seconds':time.perf_counter()-start},flush=True)
    assert expected==saved;edges=sum(a.bit_count() for a in expected)//2;result=load(OUT/'result.json');assert edges==result['conflicts'] and digest(OUT/'adjacency.bin.gz')==result['graph_sha256']
    local={i:j for j,i in enumerate(ids)};keys={identity(p['placement']):i for i,p in enumerate(pool)};seedpairs=0
    for seed in mp['seeds']:
        path=ROOT/seed['source'];assert digest(path)==seed['source_sha256'];layout=load(path);mapped=[]
        for p in layout['placements']:
            p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert p==pool[i]['placement'];mapped.append(i)
        assert sorted(mapped)==seed['selected_indices'] and len(mapped)==len(set(mapped))
        chosen=[local[i] for i in mapped if i not in fixed];mask=sum(1<<j for j in chosen);assert all(not(saved[j]&mask) for j in chosen)
        for i,j in combinations(mapped,2):
            if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
            seedpairs+=1;assert gg[i].disjoint(gg[j]) and gg[i].distance(gg[j])>=clear-1e-7
    best=max(mp['seeds'],key=lambda r:r['filled_area_mm2']);assert mp['seed_candidates']==sorted(set(best['selected_indices'])-set(fixed))
    check={'passed':True,'seconds':time.perf_counter()-start,'complete_source_pool_exact':True,'all_original_stock_transforms_checked':True,'fixed_frame_filter_pairs':fixedpairs,'fixed_frame_pairs':153,'small_pair_possibilities':possible,'small_pair_exact_distances':near,'conflicts':edges,'every_binary_adjacency_row_independently_rebuilt':True,'both_original_seeds_mapped_and_geometry_checked':True,'seed_same_sheet_pairs':seedpairs,'native_margin_qualified':False}
    write(dst/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
