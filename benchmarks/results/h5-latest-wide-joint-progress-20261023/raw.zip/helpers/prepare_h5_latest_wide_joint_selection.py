"""Adapt independently reconstructing model and original-layout checks."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def change(s,a,b):
    assert a in s,a
    return s.replace(a,b)
def save(name,s):
    with (ROOT/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'solve_h5_dense_wide_contacts.py').read_text(encoding='utf-8').replace('h5-dense-wide-contacts-20261023','h5-latest-wide-joint-20261023').replace("BASE/'group-hints'","BASE/'hints'")
s=change(s,"RED/'best-hint.json',HINT/'best-hint.json'","RED/'best-hint.json',RED/'adjacency.bin.gz',RED/'substitutions.json',HINT/'best-hint.json'")
save('solve_h5_latest_wide_joint.py',s)
s=(ROOT/'audit_h5_dense_wide_layouts.py').read_text(encoding='utf-8')
s=change(s,'from build_h5_dense_wide_contacts import OUT','from build_h5_latest_wide_joint import OUT,read_graph')
s=change(s,"old=SEED/'layout-audit'","old=ROOT/'output/h5-two-sheet-cog-group-choice-20261023/layout-audit'")
a=s.index("    prior=ROOT/'output/h5-wide-small-pool")
b=s.index('    best=',a)
s=s[:a]+s[b:]
s=change(s,"OUT/'group-hints/best-hint.json'","OUT/'hints/best-hint.json'")
s=change(s,"cliques=rows(RED/'cliques.jsonl.gz')","adj=read_graph(RED/'adjacency.bin.gz',len(ids))")
s=change(s,"selected_local={local[i] for i in sm};assert all(len(selected_local&set(c))<=1 for c in cliques)","selected_local={local[i] for i in sm};mask=sum(1<<j for j in selected_local);assert all(not(adj[j]&mask) for j in selected_local)")
s=change(s,"'new_candidates_selected':sorted(sm&set(load(OUT/'mapping.json')['new_candidates']))","'additional_pool_candidates_selected':sorted(sm&set(load(OUT/'mapping.json')['additional_candidates']))")
save('audit_h5_latest_wide_joint_layouts.py',s)
print('Prepared one bounded joint solve and all original layout checks.')
