"""Prepare one fresh fixed-64 bracket-only insertion check."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
s=(ROOT/'check_h5_two_sheet_final_gaps.py').read_text(encoding='utf-8')
def change(a,b):
    global s
    assert a in s,a
    s=s.replace(a,b)
change('from build_h5_two_sheet_cog_group_choice import ROOT,SRC,OUT as SEED,load,write,digest,save_rows','from build_h5_latest_wide_joint import ROOT,SRC,OUT as SEED,load,write,digest')
change('h5-two-sheet-final-gaps-20261023','h5-latest-wide-bracket-gaps-20261023')
change('bracket=10,insert=20','bracket=10,insert=21')
change("[('bracket',[0,90,180,270],[False,True]),('insert',[0,90],[False])]","[('bracket',[0,90,180,270],[False,True])]")
change("'new_pose_caps':{'bracket':200,'insert':200}","'new_pose_caps':{'bracket':200}")
change('Keep every returned 63-part placement exactly fixed. Query all bracket quarter-turn/reflection and both insert rectangle classes','Keep every returned 64-part placement exactly fixed. Query all bracket quarter-turn/reflection classes')
change('Enumerate zero, one or two compatible brackets and choose the first compatible insert if one exists, respecting remaining quantities two brackets and one insert.','Enumerate zero, one or two compatible brackets, respecting the remaining quantity of two brackets.')
change('and frozen CLI for the chosen result.','and frozen CLI for the chosen result. Reuse the prior CLI outcome only when the entire final layout is identical, recording every source hash; do not rerun an unchanged validation.')
a=s.index('    cp=subprocess.run(cmd,capture_output=True,timeout=60);')
b=s.index('    missing=',a)
s=s[:a]+'''    if layout==original:
        pp=SEED/'layout-audit/public-final.json';cc=SEED/'layout-audit/command-final.json';code=load(cc)['exit_code'];shutil.copyfile(pp,OUT/'public.json');public=load(pp);fresh=0
        write(OUT/'command.json',{'rerun':False,'exact_layout_match':True,'exit_code':code,'source_files':{p.relative_to(ROOT).as_posix():digest(p) for p in [inputs[0],pp,cc]}})
    else:
        cp=subprocess.run(cmd,capture_output=True,timeout=60);code=cp.returncode;(OUT/'public.json').write_bytes(cp.stdout);(OUT/'public.stderr').write_bytes(cp.stderr);write(OUT/'command.json',{'command':cmd,'exit_code':code});public=load(OUT/'public.json');fresh=1
'''+s[b:]
change('(cp.returncode==0)==(not missing)','(code==0)==(not missing)')
change("'fresh_frozen_CLI_calls':1","'fresh_frozen_CLI_calls':fresh,'exact_CLI_reuse':not fresh")
with (ROOT/'check_h5_latest_wide_bracket_gaps.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'plot_h5_dense_insert_gap.py').read_text(encoding='utf-8').replace('h5-dense-insert-gap-20261023','h5-latest-wide-joint-20261023').replace("src/'layout.json'","src/'layout-audit/layout-final.json'").replace('Improved partial: 64 of 66 parts; missing two cogs','Improved partial: 64 of 66 parts; missing two brackets')
with (ROOT/'plot_h5_latest_wide_joint.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared fixed-layout gap check and original-outline plot.')
