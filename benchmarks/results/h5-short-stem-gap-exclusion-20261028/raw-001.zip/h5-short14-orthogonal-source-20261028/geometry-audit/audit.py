"""Independent original-polygon, Minkowski-buffer and known-layout readback."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
from shapely.affinity import translate
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short14-orthogonal-source-20261028';OUT=BASE/'geometry-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
assert plan['pad_um']==112 and plan['stock_anchor_guard_um']==13 and plan['counts']==[8,6,0]
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']}
modes=load(BASE/'modes.json');assert len(modes)==10
expected=[('bracket',q,mirror) for mirror in [False,True] for q in range(4)]+[('insert',q,False) for q in [0,1]]
checks=[];shapes={};expanded={}
for i,(m,(family,q,mirror)) in enumerate(zip(modes,expected)):
    assert (m['id'],m['family'],m['quarter'],m['mirrored'])==(i,family,q,mirror)
    p=parts[family];assert q*90 in p['rotations']['degrees'] and (not mirror or p['allow_mirror'])
    c=round(math.cos(q*math.pi/2));s=round(math.sin(q*math.pi/2));sign=-1 if mirror else 1
    raw=[(1000*(sign*x*c-y*s),1000*(sign*x*s+y*c)) for x,y in p['geometry'][0]['outer']]
    lo=[min(x[k] for x in raw) for k in [0,1]];assert lo==m['transformed_min_um']
    original=Polygon([(x-lo[0],y-lo[1]) for x,y in raw]);saved=Polygon(m['outer_um'])
    assert original.is_valid and original.equals(saved)
    assert original.bounds==(0,0,m['width_um'],m['height_um'])
    source_boxes=[box(*r) for r in m['original_rectangles_um']]
    inflated_boxes=[box(*r) for r in m['expanded_rectangles_um']]
    assert all(a.area>0 for a in source_boxes+inflated_boxes)
    assert unary_union(source_boxes).equals(original)
    padded=original.buffer(112,join_style=2);union=unary_union(inflated_boxes)
    assert padded.equals(union) and padded.covers(original)
    assert all(a.intersection(b).area==0 for a,b in combinations(inflated_boxes,2))
    # Independently confirm the requested Euclidean clearance disk is covered.
    assert padded.covers(original.buffer(112,quad_segs=32))
    shapes[i]=original;expanded[i]=padded
    checks.append({'mode':i,'source_area_um2':original.area,'expanded_area_um2':padded.area,
        'source_components':len(source_boxes),'expanded_components':len(inflated_boxes),'passed':True})
stock=load(BASE/'stock.json');lo=stock['anchor_bounds_um'];ex=stock['expanded_stock_bounds_um']
assert ex==[lo[0]-112,lo[1]-112,lo[2]+112,lo[3]+112]
assert stock['expanded_capacity_um']==[ex[2]-ex[0],ex[3]-ex[1]]
actual=stock['actual_outline_bounds_mm']
assert min(lo[0]/1000-actual[0],lo[1]/1000-actual[1],actual[2]-lo[2]/1000,actual[3]-lo[3]/1000)>stock['native_guard_mm']
assert .224>stock['required_source_gap_mm']
control=load(BASE/'positive-control.json');assert len(control)==13
placed=[];rows=[];xs={'bracket':[],'insert':[]}
for i,r in enumerate(control):
    assert i==r['index'];m=modes[r['mode']];assert m['family']==r['family'];x,y=r['anchor_um']
    assert lo[0]<=x<=lo[2]-m['width_um'] and lo[1]<=y<=lo[3]-m['height_um']
    positioned=translate(shapes[m['id']],xoff=x,yoff=y);original_row=r['original_source_row'];t=original_row['transform']
    assert original_row['part_id']==r['family'] and t['mirrored']==m['mirrored']
    assert abs(math.remainder(t['rotation_radians']-math.pi/2*m['quarter'],math.tau))<1e-12
    assert max(abs((x,y)[k]-(t['translation'][k]*1000+m['transformed_min_um'][k])) for k in [0,1])<1e-5
    placed.append(translate(expanded[m['id']],xoff=x,yoff=y));rows.append(original_row);xs[r['family']].append(x)
for group in xs.values():assert group==sorted(group)
pair_checks=[]
for i,j in combinations(range(13),2):
    assert placed[i].disjoint(placed[j]);pair_checks.append({'indices':[i,j],'expanded_gap_um':placed[i].distance(placed[j])})
source=audit(job,rows,{'sheet-1':actual},stock['required_source_gap_mm'],stock['native_guard_mm'])
assert source['valid'] and source['family_counts']=={'bracket':8,'insert':5}
write(OUT/'modes.json',checks);write(OUT/'positive-control-pairs.json',pair_checks);write(OUT/'positive-control-source.json',source)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_modes_verified':10,
    'exact_expanded_unions_verified':10,'positive_control_originals':13,'positive_control_pairs':78,
    'minimum_expanded_control_gap_um':min(r['expanded_gap_um'] for r in pair_checks),
    'positive_control_source_valid':True,'minimum_source_control_gap_mm':source['minimum_pair_gap_mm'],
    'minimum_source_stock_extra_mm':source['minimum_extra_stock_mm'],'pad_um':112,'guaranteed_source_gap_mm':.224,
    'geometry_sha256':digest(BASE/'modes.json'),'stock_sha256':digest(BASE/'stock.json'),
    'control_sha256':digest(BASE/'positive-control.json'),'plan_sha256':digest(BASE/'plan.json'),
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
