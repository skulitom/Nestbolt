"""Freeze one full-shape8/6/0 construction with complete XY and mode freedom."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil
from h5_orthogonal_source_model_geometry_20261028 import original_um,transformed,polygon_rectangles,expanded_rectangles
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-short14-orthogonal-source-20261028'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SOURCE=ROOT/'output/h5-oblique64-source-20261028/source64.json'
FRONT=ROOT/'benchmarks/results/h5-short-count-x-screen-20261028/updated-allocations.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
assert any(r['short_counts']==[8,6,0] and r['excluded_by'] is None for r in load(FRONT))
inputs=[JOB,SOURCE,FRONT,ROOT/'output/h5_orthogonal_source_model_geometry_20261028.py',
    ROOT/'output/h5-baseline-target-review-20261028/checks.json',ROOT/'output/h5-oblique64-source-20261028/plan.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'counts':[8,6,0],'pad_um':112,'stock_anchor_guard_um':13,'solver_seconds':60,'shared_process_seconds':90,
    'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'maximum_calls':1,'retry_permitted':False,
    'method':'One new conservative full-source orthogonal construction for eight brackets and six inserts on the unchanged target short sheet. All14 are mandatory. Retain complete integer-micrometre X/Y domains, all8 bracket modes and both insert outer classes. Expand each original filled outer by112um in L-infinity; independently partition the union into disjoint rectangles. Nonoverlap of every expanded component guarantees at least224um source clearance. Components from one original have disjoint interiors. Stock domains keep at least13um extra original clearance. Order identical copies by actual bounding-box left X. Add only redundant X/Y cumulative constraints over the expanded stock bounds. A partial hint uses the13 independently valid prior short-sheet originals, relabelled in X order, without fixing them; the new sixth insert has no hint. Audit original geometry, positive control and every serialized model constraint before one60-second four-worker call within90seconds shared. A failed or infeasible conservative construction never excludes the actual8/6/0 count. A solution needs independent original-ring readback and still does not complete66 or H5. No native or production call.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};modes=[]
for family,qs,mirrors in [('bracket',range(4),[False,True]),('insert',[0,1],[False])]:
    p=parts[family];points=original_um(p['geometry'][0]['outer'])
    for mirror in mirrors:
        for q in qs:
            assert q*90 in p['rotations']['degrees'] and (not mirror or p['allow_mirror'])
            outer,offset=transformed(points,q,mirror);rects=polygon_rectangles(outer);expanded=expanded_rectangles(rects,112)
            modes.append({'id':len(modes),'family':family,'quarter':q,'mirrored':mirror,'transformed_min_um':offset,
                'outer_um':outer,'width_um':max(v[0] for v in outer),'height_um':max(v[1] for v in outer),
                'original_rectangles_um':rects,'expanded_rectangles_um':expanded})
stocks={'actual_outline_bounds_mm':[6.5,6.5,1493.5,319.42690232999934],
    'anchor_bounds_um':[6513,6513,1493487,319413],'expanded_stock_bounds_um':[6401,6401,1493599,319525],
    'expanded_capacity_um':[1487198,313124],'required_source_gap_mm':0.21170867250963943,'native_guard_mm':0.011444091796875}
write(OUT/'modes.json',modes);write(OUT/'stock.json',stocks)
selected={f:[] for f in ['bracket','insert']}
for r in load(SOURCE):
    if r['sheet_id']!='sheet-1':continue
    family=r['part_id'];t=r['transform'];q=round(t['rotation_radians']/(math.pi/2))%4
    mode=next(m for m in modes if m['family']==family and m['quarter']==q and m['mirrored']==t['mirrored'])
    anchor=[round(t['translation'][k]*1000)+mode['transformed_min_um'][k] for k in [0,1]]
    assert all(abs(t['translation'][k]*1000-round(t['translation'][k]*1000))<1e-5 for k in [0,1])
    selected[family].append({'mode':mode['id'],'anchor_um':anchor,'original_source_row':r})
assert len(selected['bracket'])==8 and len(selected['insert'])==5
control=[]
for family in ['bracket','insert']:
    for copy,r in enumerate(sorted(selected[family],key=lambda r:(r['anchor_um'][0],r['anchor_um'][1]))):
        control.append({'index':len(control),'family':family,'copy_index':copy,**r})
write(OUT/'positive-control.json',control)
write(OUT/'prepared.json',{'modes':len(modes),'mandatory_originals':14,'positive_control_originals':13,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
