"""Full XY packing of conservative original-shape components, without search."""
from pathlib import Path
from hashlib import sha256
import json,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short14-orthogonal-source-20261028';OUT=BASE/'model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');audit=load(BASE/'geometry-audit/checks.json');assert audit['passed']
for name,key in [('modes.json','geometry_sha256'),('stock.json','stock_sha256'),('positive-control.json','control_sha256'),('plan.json','plan_sha256')]:assert digest(BASE/name)==audit[key]
modes=load(BASE/'modes.json');stock=load(BASE/'stock.json');bounds=stock['anchor_bounds_um'];m=cp_model.CpModel();items=[];flags={};coordinates=[]
identities=[('bracket',i) for i in range(8)]+[('insert',i) for i in [0,1,2,3,4,16]]
for i,(family,copy) in enumerate(identities):
    choices=[v for v in modes if v['family']==family]
    x=m.new_int_var(bounds[0],bounds[2]-min(v['width_um'] for v in choices),f'x_{i}')
    y=m.new_int_var(bounds[1],bounds[3]-min(v['height_um'] for v in choices),f'y_{i}')
    zs=[m.new_bool_var(f'mode_{i}_{v["id"]}') for v in choices];one=m.add_exactly_one(zs);options=[]
    for v,z in zip(choices,zs):
        cs=[m.add(x>=bounds[0]),m.add(x<=bounds[2]-v['width_um']),m.add(y>=bounds[1]),m.add(y<=bounds[3]-v['height_um'])]
        for ct in cs:ct.only_enforce_if(z)
        options.append({'mode':v['id'],'selector':z.index,'domain_constraints':[ct.index for ct in cs]});flags[i,v['id']]=z
    items.append({'index':i,'family':family,'copy_index':copy,'x':x.index,'y':y.index,'exactly_one':one.index,'options':options});coordinates.append((x,y))
symmetry=[]
for group in [list(range(8)),list(range(8,14))]:
    for a,b in zip(group,group[1:]):symmetry.append({'items':[a,b],'constraint':m.add(coordinates[a][0]<=coordinates[b][0]).index})
components=[];xis=[];yis=[];widths=[];heights=[]
for it in items:
    i=it['index'];x,y=coordinates[i]
    for o in it['options']:
        v=modes[o['mode']]
        for k,(a,b,c,d) in enumerate(v['expanded_rectangles_um']):
            xi=m.new_optional_fixed_size_interval_var(x+a,c-a,flags[i,v['id']],f'expanded_x_{len(components)}')
            yi=m.new_optional_fixed_size_interval_var(y+b,d-b,flags[i,v['id']],f'expanded_y_{len(components)}')
            components.append({'item':i,'mode':v['id'],'component':k,'bounds_um':[a,b,c,d],
                'presence':o['selector'],'x_interval':xi.index,'y_interval':yi.index})
            xis.append(xi);yis.append(yi);widths.append(c-a);heights.append(d-b)
overlap=m.add_no_overlap_2d(xis,yis)
xc=m.add_cumulative(xis,heights,stock['expanded_capacity_um'][1]);yc=m.add_cumulative(yis,widths,stock['expanded_capacity_um'][0]);hints=[]
for r in load(BASE/'positive-control.json'):
    i=r['index'];it=items[i];assert it['family']==r['family'];x,y=coordinates[i]
    for variable,value in [(x,r['anchor_um'][0]),(y,r['anchor_um'][1])]+[(flags[i,o['mode']],int(o['mode']==r['mode'])) for o in it['options']]:
        m.add_hint(variable,value);hints.append([variable.index,value])
assert m.validate()=='' and m.export_to_file(str(OUT/'model.pb')) and m.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'items':items,'symmetry':symmetry,'components':components,'no_overlap_2d':overlap.index,
    'x_cumulative':xc.index,'y_cumulative':yc.index,'partial_hint':hints})
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'modes.json',BASE/'stock.json',BASE/'positive-control.json',BASE/'geometry-audit/checks.json']}})
write(OUT/'built.json',{'variables':len(m.proto.variables),'constraints':len(m.proto.constraints),'optional_components':len(components),
    'partial_hint_variables':len(hints),'unhinted_variables':len(m.proto.variables)-len(hints),'model_sha256':digest(OUT/'model.pb'),
    'all14_mandatory':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
