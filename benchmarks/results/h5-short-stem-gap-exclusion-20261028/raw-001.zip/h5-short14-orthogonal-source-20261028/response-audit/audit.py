"""Independently evaluate a returned assignment; never exclude a real count."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
from itertools import combinations
import json,math,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short14-orthogonal-source-20261028';SEARCH=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
model_audit=load(BASE/'model-audit/checks.json');assert model_audit['passed']
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
process=load(SEARCH/'process.json');result=load(SEARCH/'result.json');opened=load(SEARCH/'opened.json')
assert not process['timeout'] and process['exit_code']==0 and process['seconds']<90
assert result['solver_calls']==1 and result['closed'] and opened['maximum_calls']==1
assert opened['model_audit_sha256']==digest(BASE/'model-audit/checks.json')
assert digest(SEARCH/'model.pb')==digest(BASE/'model/model.pb')==model_audit['model_sha256']==opened['model_sha256']
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
assert params.max_time_in_seconds==60 and params.num_search_workers==4 and params.random_seed==0
assert list(params.ignore_subsolvers)==['fj'] and params.log_search_progress and not params.log_to_stdout
assert {f.name for f,v in params.ListFields()}==set(opened['parameters'])
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes())
status=cp_model_pb2.CpSolverStatus.Name(response.status);assert status==result['status'] and status in ['UNKNOWN','OPTIMAL','FEASIBLE','INFEASIBLE']
assert response.wall_time==result['solver_wall_seconds'] and response.num_branches==result['returned_response_branches']
assert response.num_conflicts==result['returned_response_conflicts'] and bool(response.solution)==result['has_solution']
assert bool(response.solution)==(status in ['OPTIMAL','FEASIBLE'])
log=(SEARCH/'solver.log').read_text(encoding='utf-8');assert f'status: {status}' in log
printed=Decimal(re.search(r'^walltime: ([0-9.e+-]+)$',log,re.M).group(1))
assert abs(printed-Decimal(str(response.wall_time)))<=Decimal(5).scaleb(printed.as_tuple().exponent-1)+Decimal('1e-12')
assert result['returned_soft_overrun_seconds']==max(0.,result['returned_solve_seconds']-60)
assert result['solver_soft_overrun_seconds']==max(0.,response.wall_time-60)
checked=variables=active=pair_checks=0
if response.solution:
    model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'model/model.pb').read_bytes());sol=list(response.solution)
    assert len(sol)==len(model.variables)==104
    for v,value in zip(model.variables,sol):assert any(a<=value<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    variables=len(sol)
    def expr(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
    def literal(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
    def present(ct):return all(literal(v) for v in ct.enforcement_literal)
    intervals={i:(expr(ct.interval.start),expr(ct.interval.end),expr(ct.interval.size),present(ct))
        for i,ct in enumerate(model.constraints) if ct.WhichOneof('constraint')=='interval'}
    for i,ct in enumerate(model.constraints):
        checked+=1
        if not present(ct):continue
        kind=ct.WhichOneof('constraint')
        if kind=='linear':
            value=sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs))
            assert any(a<=value<=b for a,b in zip(ct.linear.domain[::2],ct.linear.domain[1::2]))
        elif kind=='exactly_one':assert sum(literal(v) for v in ct.exactly_one.literals)==1
        elif kind=='interval':
            a,b,size,on=intervals[i];assert a+size==b and size>0 and on
        elif kind=='no_overlap_2d':
            rects=[]
            for x,y in zip(ct.no_overlap_2d.x_intervals,ct.no_overlap_2d.y_intervals):
                assert intervals[x][3]==intervals[y][3]
                if intervals[x][3]:rects.append((*intervals[x][:2],*intervals[y][:2]))
            active=len(rects)
            for a,b in combinations(rects,2):
                assert a[1]<=b[0] or b[1]<=a[0] or a[3]<=b[2] or b[3]<=a[2];pair_checks+=1
        elif kind=='cumulative':
            events={}
            for ix,dem in zip(ct.cumulative.intervals,ct.cumulative.demands):
                a,b,size,on=intervals[ix]
                if on:
                    d=expr(dem);events[a]=events.get(a,0)+d;events[b]=events.get(b,0)-d
            height=0;cap=expr(ct.cumulative.capacity)
            for x,delta in sorted(events.items()):height+=delta;assert 0<=height<=cap
            assert height==0
        else:raise AssertionError(kind)
    assert load(SEARCH/'assignment.json')=={v.name:value for v,value in zip(model.variables,sol)}
    mapping=load(BASE/'model/mapping.json');modes=load(BASE/'modes.json');poses=[];rows=[]
    for r in mapping['items']:
        selected=[o for o in r['options'] if sol[o['selector']]];assert len(selected)==1;m=modes[selected[0]['mode']]
        anchor=[sol[r['x']],sol[r['y']]];poses.append({'index':r['index'],'family':r['family'],'copy_index':r['copy_index'],'mode':m['id'],'anchor_um':anchor})
        rows.append({'part_id':r['family'],'copy_index':r['copy_index'],'sheet_id':'sheet-1',
            'transform':{'rotation_radians':m['quarter']*math.pi/2,'mirrored':m['mirrored'],
                'translation':[(anchor[k]-m['transformed_min_um'][k])/1000 for k in [0,1]]}})
    write(OUT/'selected-poses.json',poses);write(OUT/'source14-candidate.json',rows)
else:assert not (SEARCH/'assignment.json').exists()
inputs=[BASE/'plan.json',BASE/'model/plan.json',BASE/'model-audit/checks.json',BASE/'model/model.pb',BASE/'model/mapping.json',BASE/'modes.json',BASE/'stock.json']+list(SEARCH.glob('*'))
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs if p.is_file()}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':status,'closed':True,'solver_calls':1,
    'returned_branches':response.num_branches,'returned_conflicts':response.num_conflicts,'solver_wall_seconds':response.wall_time,
    'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],
    'returned_soft_overrun_seconds':result['returned_soft_overrun_seconds'],'assignment_variables_verified':variables,
    'assignment_constraints_verified':checked,'active_expanded_components_verified':active,'expanded_component_pairs_verified':pair_checks,
    'has_full_source_candidate':bool(response.solution),'source_geometry_validated':False,'actual_count_exclusion_claimed':False,
    'remaining_necessary_allocations':448,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
