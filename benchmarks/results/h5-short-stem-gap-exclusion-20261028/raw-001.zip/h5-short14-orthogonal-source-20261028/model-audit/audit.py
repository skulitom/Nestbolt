"""Independent exhaustive protobuf readback before the sole construction call."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short14-orthogonal-source-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def fields(p,allowed):assert {f.name for f,v in p.ListFields()}<=set(allowed)
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(MODEL/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
ga=load(BASE/'geometry-audit/checks.json');assert ga['passed'] and ga['positive_control_source_valid']
modes=load(BASE/'modes.json');stock=load(BASE/'stock.json');bounds=stock['anchor_bounds_um'];mp=load(MODEL/'mapping.json')
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());fields(p,['variables','constraints','solution_hint'])
vi=ci=0;LOW=-9223372036854775808;HIGH=9223372036854775807
def var(ix,name,domain):
    global vi
    assert ix==vi;v=p.variables[ix];fields(v,['name','domain']);assert v.name==name and list(v.domain)==domain;vi+=1
def ct_at(ix,kind,enforcement=(),name=''):
    global ci
    assert ix==ci;ct=p.constraints[ix];fields(ct,['name','enforcement_literal',kind])
    assert ct.WhichOneof('constraint')==kind and ct.name==name and list(ct.enforcement_literal)==list(enforcement);ci+=1;return ct
def coefficients(e,co):assert len(e.vars)==len(e.coeffs)==len(co) and dict(zip(e.vars,e.coeffs))==co
def linear(ix,co,domain,enforcement=()):
    ct=ct_at(ix,'linear',enforcement);fields(ct.linear,['vars','coeffs','domain']);coefficients(ct.linear,co);assert list(ct.linear.domain)==domain
def expr(e,co,offset=0):
    fields(e,['vars','coeffs','offset']);coefficients(e,co);assert e.offset==offset
identities=[('bracket',i) for i in range(8)]+[('insert',i) for i in [0,1,2,3,4,16]]
assert len(mp['items'])==14
for i,((family,copy),r) in enumerate(zip(identities,mp['items'])):
    assert r['index']==i and r['family']==family and r['copy_index']==copy
    choices=[m for m in modes if m['family']==family]
    var(r['x'],f'x_{i}',[bounds[0],bounds[2]-min(m['width_um'] for m in choices)])
    var(r['y'],f'y_{i}',[bounds[1],bounds[3]-min(m['height_um'] for m in choices)])
    assert len(r['options'])==len(choices)
    for o,m in zip(r['options'],choices):assert o['mode']==m['id'];var(o['selector'],f'mode_{i}_{m["id"]}',[0,1])
    ct=ct_at(r['exactly_one'],'exactly_one');fields(ct.exactly_one,['literals']);assert list(ct.exactly_one.literals)==[o['selector'] for o in r['options']]
    for o,m in zip(r['options'],choices):
        assert len(o['domain_constraints'])==4
        expected=[(r['x'],[bounds[0],HIGH]),(r['x'],[LOW,bounds[2]-m['width_um']]),
            (r['y'],[bounds[1],HIGH]),(r['y'],[LOW,bounds[3]-m['height_um']])]
        for ix,(variable,domain) in zip(o['domain_constraints'],expected):linear(ix,{variable:1},domain,[o['selector']])
order=[(a,b) for group in [list(range(8)),list(range(8,14))] for a,b in zip(group,group[1:])]
assert len(mp['symmetry'])==len(order)
for (a,b),r in zip(order,mp['symmetry']):
    assert r['items']==[a,b];linear(r['constraint'],{mp['items'][a]['x']:1,mp['items'][b]['x']:-1},[LOW,0])
ri=0;xis=[];yis=[];widths=[];heights=[]
for r in mp['items']:
    for o in r['options']:
        m=modes[o['mode']]
        for k,(a,b,c,d) in enumerate(m['expanded_rectangles_um']):
            saved=mp['components'][ri]
            assert saved=={'item':r['index'],'mode':m['id'],'component':k,'bounds_um':[a,b,c,d],
                'presence':o['selector'],'x_interval':ci,'y_interval':ci+1}
            for axis,left,right in [('x',a,c),('y',b,d)]:
                ix=ci;ct=ct_at(ix,'interval',[o['selector']],f'expanded_{axis}_{ri}');fields(ct.interval,['start','size','end'])
                expr(ct.interval.start,{r[axis]:1},left);expr(ct.interval.end,{r[axis]:1},right);expr(ct.interval.size,{},right-left)
                (xis if axis=='x' else yis).append(ix)
            widths.append(c-a);heights.append(d-b);ri+=1
assert ri==len(mp['components'])==140
ct=ct_at(mp['no_overlap_2d'],'no_overlap_2d');fields(ct.no_overlap_2d,['x_intervals','y_intervals'])
assert list(ct.no_overlap_2d.x_intervals)==xis and list(ct.no_overlap_2d.y_intervals)==yis
for key,intervals,demands,cap in [('x_cumulative',xis,heights,stock['expanded_capacity_um'][1]),('y_cumulative',yis,widths,stock['expanded_capacity_um'][0])]:
    ct=ct_at(mp[key],'cumulative');fields(ct.cumulative,['intervals','demands','capacity'])
    assert list(ct.cumulative.intervals)==intervals and len(ct.cumulative.demands)==len(demands)
    for e,d in zip(ct.cumulative.demands,demands):expr(e,{},d)
    expr(ct.cumulative.capacity,{},cap)
expected_hints=[]
for control in load(BASE/'positive-control.json'):
    r=mp['items'][control['index']];expected_hints.extend([[r['x'],control['anchor_um'][0]],[r['y'],control['anchor_um'][1]]])
    expected_hints.extend([o['selector'],int(o['mode']==control['mode'])] for o in r['options'])
fields(p.solution_hint,['vars','values'])
assert len(p.solution_hint.vars)==len(p.solution_hint.values)==100
assert list(map(list,zip(p.solution_hint.vars,p.solution_hint.values)))==expected_hints==mp['partial_hint']
assert len(set(p.solution_hint.vars))==100 and vi==len(p.variables)==104 and ci==len(p.constraints)==613
for ix,value in expected_hints:assert p.variables[ix].domain[0]<=value<=p.variables[ix].domain[-1]
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':vi,'constraints_verified':ci,
    'optional_components_verified':ri,'positive_control_hint_variables_verified':100,'unhinted_new_insert_variables':4,
    'all14_originals_mandatory':True,'all_bracket_and_insert_outer_modes_retained':True,'complete_integer_XY_domains':True,
    'no_fixed_placements_or_objective_or_assumptions':True,'conservative_construction_not_necessity_proof':True,
    'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),
    'geometry_audit_sha256':digest(BASE/'geometry-audit/checks.json'),'plan_sha256':digest(BASE/'plan.json'),
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
