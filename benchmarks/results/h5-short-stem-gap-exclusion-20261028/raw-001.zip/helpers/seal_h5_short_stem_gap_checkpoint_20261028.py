"""Preserve the closed source construction and independently proved stem-gap exclusion."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-short-stem-gap-exclusion-20261028';OUT=ROOT/'benchmarks/results'/NAME
SOURCE=ROOT/'output/h5-short14-orthogonal-source-20261028';PROOF=ROOT/'output/h5-short-stem-gap-bound-20261028';PUB=PROOF/'publication'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='f61f25d6c8baa7e34264b47d6cb8d5b5ad6c45c2' and not git('diff','HEAD','--name-only')
audits=[SOURCE/'geometry-audit/checks.json',SOURCE/'model-audit/checks.json',SOURCE/'response-audit/checks.json',PROOF/'audit/checks.json',PROOF/'audit/source-mode-completeness.json']
assert all(load(p)['passed'] for p in audits)
result=load(SOURCE/'response-audit/checks.json');proof=load(PROOF/'audit/checks.json')
assert result['status']=='UNKNOWN' and result['closed'] and not result['has_full_source_candidate']
assert proof['newly_excluded_counts']==[[8,6,0],[8,7,0]] and proof['remaining_necessary_allocations']==446
assert proof['width_deficit_um']==2908 and not proof['unknown_solver_response_used_for_exclusion']
old=load(ROOT/'benchmarks/results/h5-short-count-x-screen-20261028/publication-review.json')
production=source_digest();assert production==old['production_digest']
readmes={n:digest(ROOT/n) for n in old['current_readmes']};assert readmes==old['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],
    'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==old[k] for k in up);assert load(PUB/'main.json')['commit']['sha']==head
jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [SOURCE,PROOF,ROOT/'output/h5-short-count-screen-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['h5_orthogonal_source_model_geometry_20261028.py','prepare_h5_short14_orthogonal_source_20261028.py',
    'audit_h5_short14_orthogonal_geometry_20261028.py','build_h5_short14_orthogonal_model_20261028.py',
    'audit_h5_short14_orthogonal_model_20261028.py','run_h5_short14_orthogonal_source_20261028.py',
    'audit_h5_short14_orthogonal_response_20261028.py','derive_h5_short_stem_gap_bound_20261028.py',
    'audit_h5_short_stem_gap_bound_20261028.py','audit_h5_stem_gap_mode_coverage_20261028.py',
    'push_short_count_screen_checkpoint_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for f in ['output','scripts']:
                    q=ROOT/f/(module+'.py')
                    if q.is_file():add('imported-helpers/'+f+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(SOURCE/'geometry-audit/checks.json','source-geometry-checks.json'),(SOURCE/'model-audit/checks.json','source-model-checks.json'),
    (SOURCE/'response-audit/checks.json','source-response-checks.json'),(PROOF/'derived.json','gap-derived.json'),
    (PROOF/'audit/checks.json','gap-audit-checks.json'),(PROOF/'audit/source-mode-completeness.json','source-mode-completeness.json'),
    (PROOF/'audit/necessity-proof.json','necessity-proof.json'),(PROOF/'audit/positive-control-gaps.json','positive-control-gaps.json'),
    (PROOF/'audit/updated-allocations.json','updated-allocations.json'),(PROOF/'audit/newly-excluded-allocations.json','newly-excluded-allocations.json'),
    (PROOF/'audit/pareto-necessary-counts.json','pareto-necessary-counts.json'),(PROOF/'gap-widths.json','gap-widths.json'),
    (PROOF/'terminal.json','terminal-width-bounds.json'),(PUB/'main-ci-jobs.json','prior-main-ci.json')]
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,
    'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,
    'main_CI':40704324149,'main_all6_pass':True,'normal_push_authorized_after_fresh_live_run_check':True,
    'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'source_construction_calls':1,'source_status':'UNKNOWN','source_call_closed':True,
    'source_original_modes_and_positive_control_verified':True,'gap_proof_independently_verified':True,'gap_proof_solver_calls':0,
    'new_count_exclusions':[[8,6,0],[8,7,0]],'remaining_necessary_allocations':446,'all4576_rows_retained':True,
    'unknown_response_used_for_exclusion':False,'source14_witness':False,'full66_exclusion_claimed':False,'native_calls':0,
    'main_all6_pass':True,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='The conservative full-shape8/6/0 call is closed UNKNOWN; do not extend, reseed or rerun it. The separate exact source stem-gap certificate now excludes actual8/6/0 and its8/7/0 superset, so both branches are closed independently of that solver response. Keep all4576 original count rows and446 remaining candidates, including source-valid8/5/0 and7/4/1. The new structural model covers all actual modes and both coordinates through source necessities: stems partition stock into gaps, each gap is bounded by an exhaustively enumerated cumulative interval schedule, and the complete chain is checked forward and backward. Before selecting another whole-source construction, predeclare a finite extension of the gap table for the still-open seven-bracket allocations, such as7/8/0 and7/9/0. Reuse the already verified0..6-insert tables byte-for-byte; derive only the new larger-gap cases, retain every task order, and audit their completeness and the whole recurrence before any further exclusion. This is deterministic necessary geometry, not another CP-SAT retry. Use the resulting permitted counts to choose a materially different all66 source construction. The current valid64 still lacks two brackets; native validation and integration require all66, the unchanged PIH-OFF rule, target and guards. H2 stays open under the explicit unchanged-gate decision;22 reserved vectors remain unopened and no release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Source stem-gap width exclusion — 2026-10-28

**Eight brackets and six inserts cannot fit on the target short sheet.**
An independently checked source-geometry argument requires at least
**1,489.948 mm** of horizontal width. The outward-relaxed sheet offers
**1,487.040 mm**, a deficit of **2.908 mm**. Deleting extras also excludes
eight brackets/seven inserts. These two new exclusions reduce the complete
frontier from 448 to **446** necessary candidates. All 4,576 original rows,
including previous exclusions, remain recorded.

## Closed full-shape construction

Before deriving the structural bound, one conservative source construction
tries eight brackets and six inserts with complete integer-micrometre X/Y
domains and all allowed outer modes. Each original filled outer is expanded
by 112 µm and partitioned into disjoint rectangles; nonoverlap would guarantee
224 µm source clearance, above the unchanged 211.708673 µm requirement.
Original stock domains retain at least 13 µm extra clearance.

Independent original-polygon checks verify all ten outer classes, their exact
expanded unions and the known source-valid 13-part control. Its minimum source
gap is 0.225 mm, with 0.025 mm extra stock clearance; its expanded shapes retain
a 1 µm gap. The model reader verifies all 104 variables, 613 constraints, 140
optional components and 100 partial-hint values. No placement is fixed. The
sixth insert is unhinted, and all 14 originals are mandatory.

The sole 60-second, four-worker call returns **UNKNOWN** after 288,795 branches
and 79,656 conflicts: 60.104262 s returned / 60.912529 s shared. The 0.104262 s
soft return overrun is retained. There is no assignment, source14 witness or
native call, and the call is closed. Its unknown result contributes **nothing
to the exclusion proof** below.

## Source-to-gap argument

Inset each original orthogonal rectangle by 2 µm, then floor the source anchor
to integer micrometres. The inset covers the less-than-1 µm displacement, so
every resulting rectangle remains inside the original filled outer. Holes stay
reserved. A separate check covers every one of the job's 12 declared transform
combinations: eight bracket transforms and four insert rotations reduce to ten
occupied outer classes.

Each bracket has one full-height stem and one wing. A stem is at least
249,996 µm high, and any wing or insert is at least 74,996 µm high. Their sum,
324,992 µm, exceeds the relaxed stock height of 312,967 µm. Therefore a stem's
X interval cannot overlap another source rectangle's X interval. Eight stems
partition the stock width into nine gaps; every insert stays in one gap.

A wing is separated from its own inward stem by only 4 µm. Another stem is
at least 74,996 µm wide, so it cannot intervene there. Each wing therefore
belongs to the adjacent left or right gap. At most two wings border any gap.
All eight bracket modes map to one of four stem-type/direction choices.

Within a gap, discard fixed wing anchors and source Y positions, retaining
only interval widths and summed vertical capacity. This is a relaxation.
For each wing combination and each 0–6 insert orientation split, enumerate
every distinct task order and place each interval at its earliest feasible X.
The exactness argument is given in the [necessity proof]({NAME}/necessity-proof.json).
In brief, processing any feasible schedule in original start order and shifting
each next task to its earliest feasible start cannot delay it or any later task.
An earliest start is zero or a previous interval end. Consequently at least one
enumerated order attains a relaxed minimum no greater than any source schedule.

The independent reader checks **168 cases, all 12,925 distinct orders and
94,348 earliest-start steps**, including nonoptimal schedules. It then verifies
all 42 gap bounds, 169 chain states and 2,380 transitions. A separately written
backward recurrence agrees on all 63 terminal bracket/insert count cases.
The known valid eight-bracket/five-insert source layout maps into its actual
nine gaps and passes; its relaxed width lower bound is 1,424.948 mm.

For eight brackets/six inserts, the minimum sum of inward stem widths and
relaxed gap widths is **1,489.948 mm**. This exceeds even the larger relaxed
stock by 2.908 mm, so the actual smaller target cannot contain that subset.
Only **8/6/0 and 8/7/0** were previously surviving supersets. Known valid
8/5/0 and 7/4/1 remain allowed. This is not a full66 infeasibility argument.

## Next work and publication

Both eight-bracket branches are now closed. Next predeclare the finite larger
gap cases needed for the remaining seven-bracket allocations, reusing the
verified 0–6-insert tables exactly. Independently check the extended enumeration
and recurrence before excluding anything. Use the remaining counts to choose a
different complete source construction; the valid64 still lacks two brackets.
No source search is restarted and no material, PIH or clearance rule changes.

The previous main checkpoint `f61f25d6` passes all six jobs in
[CI 40704324149](https://github.com/skulitom/Nestbolt/actions/runs/40704324149).
Production, READMEs and upstream heads/releases are unchanged. H2 and H5 remain
open at **60% completed milestone weight**; all 22 reserved H2 vectors remain
unopened and no new release qualifies.

[Closed source response]({NAME}/source-response-checks.json),
[independent width audit]({NAME}/gap-audit-checks.json),
[complete allocation list]({NAME}/updated-allocations.json),
[next step]({NAME}/next-step.json),
[byte-verified archive]({NAME}/raw-manifest.json).
The archive preserves {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including every task order, schedule, source model, input,
auditor, failed call and the preceding main-push receipt.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 source stem-gap exclusion, 2026-10-28:** [the evidence]({link})
rules out actual short-sheet 8/6/0 and 8/7/0 independently of the preserved
conservative source call, which closed UNKNOWN in 60.104262 returned /
60.912529 shared seconds. Source stems divide the sheet into nine gaps.
Exhaustive scheduling and independent readback cover all 12,925 task orders,
94,348 earliest-start steps, 42 gap bounds and 2,380 chain transitions; a backward
recurrence agrees. Eight brackets/six inserts need 1,489.948 mm, exceeding the
relaxed stock width by 2.908 mm. All original modes and the valid 8/5/0 control
pass. All 4,576 count rows remain recorded and 446 candidates survive. No full66
or native pass exists. Both excluded branches are closed. Next predeclare and
audit the larger gap cases for remaining seven-bracket allocations, reusing
existing bounds exactly. Main f61f25d6 passes all six CI jobs. Production,
READMEs and upstream releases are unchanged. H2/H5 remain open at 60%; all
22 reserved vectors remain unopened and no new release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'bound_source_inputs':len(bindings),'remaining_necessary_allocations':446,'completion_percent':60})
