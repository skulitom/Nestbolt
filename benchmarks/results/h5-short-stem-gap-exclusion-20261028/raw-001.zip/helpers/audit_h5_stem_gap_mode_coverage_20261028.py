"""Check every job-declared orthogonal transform against the occupied outer classes."""
from pathlib import Path
from hashlib import sha256
import json,math
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';BASE=ROOT/'output/h5-short-stem-gap-bound-20261028'
load=lambda p:json.loads(p.read_bytes());job=load(JOB);modes=load(ROOT/'output/h5-short14-orthogonal-source-20261028/modes.json');records=[]
for p in job['parts']:
    if p['id'] not in ['bracket','insert']:continue
    assert p['rotations']['kind']=='list' and set(p['rotations']['degrees'])=={0,90,180,270}
    for mirror in ([False,True] if p['allow_mirror'] else [False]):
        for degrees in p['rotations']['degrees']:
            c=round(math.cos(math.radians(degrees)));s=round(math.sin(math.radians(degrees)));sign=-1 if mirror else 1
            raw=[(1000*(sign*x*c-y*s),1000*(sign*x*s+y*c)) for x,y in p['geometry'][0]['outer']]
            xmin=min(x for x,y in raw);ymin=min(y for x,y in raw);shape=Polygon([(x-xmin,y-ymin) for x,y in raw])
            matches=[m['id'] for m in modes if m['family']==p['id'] and shape.equals(Polygon(m['outer_um']))];assert matches
            records.append({'family':p['id'],'rotation_degrees':degrees,'mirrored':mirror,'equal_filled_outer_modes':matches})
assert len(records)==12
out={'passed':True,'job_sha256':sha256(JOB.read_bytes()).hexdigest(),'declared_transform_combinations_verified':12,
    'occupied_outer_classes':10,'PIH_OFF_filled_outer_equivalence':True,'records':records}
with (BASE/'audit/source-mode-completeness.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(out,f,indent=2);f.write('\n')
print({'passed':True,'declared_transform_combinations_verified':12,'occupied_outer_classes':10})
