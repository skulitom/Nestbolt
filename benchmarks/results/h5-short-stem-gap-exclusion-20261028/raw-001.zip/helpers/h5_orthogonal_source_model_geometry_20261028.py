"""Integer orthogonal geometry; no solver or filesystem effects on import."""
from decimal import Decimal
def original_um(outer):
    result=[]
    for point in outer:
        values=[Decimal(str(v))*1000 for v in point];assert all(v==int(v) for v in values)
        result.append([int(v) for v in values])
    return result
def transformed(points,q,mirror):
    out=[]
    for x,y in points:
        if mirror:x=-x
        out.append([(x,-y,-x,y)[q],(y,x,-y,-x)[q]])
    lo=[min(v[k] for v in out) for k in [0,1]]
    return [[x-lo[0],y-lo[1]] for x,y in out],lo
def merge_slabs(slabs):
    # Extend rectangles only across consecutive slabs with exactly equal Y spans.
    result=[];active={}
    for left,right,spans in slabs:
        new={}
        for low,high in spans:
            key=(low,high)
            if key in active and result[active[key]][2]==left:
                ix=active[key];result[ix][2]=right
            else:ix=len(result);result.append([left,low,right,high])
            new[key]=ix
        active=new
    return result
def polygon_rectangles(points):
    xs=sorted({v[0] for v in points});edges=list(zip(points,points[1:]+points[:1]));slabs=[]
    assert all(a[0]==b[0] or a[1]==b[1] for a,b in edges)
    for left,right in zip(xs,xs[1:]):
        twice_x=left+right
        ys=sorted(a[1] for a,b in edges if a[1]==b[1] and 2*min(a[0],b[0])<twice_x<2*max(a[0],b[0]))
        assert len(ys)%2==0;slabs.append((left,right,list(zip(ys[::2],ys[1::2]))))
    return merge_slabs(slabs)
def expanded_rectangles(rects,pad):
    boxes=[[a-pad,b-pad,c+pad,d+pad] for a,b,c,d in rects];xs=sorted({v[k] for v in boxes for k in [0,2]});slabs=[]
    for left,right in zip(xs,xs[1:]):
        ys=sorted((b,d) for a,b,c,d in boxes if a<=left and right<=c);merged=[]
        for lo,hi in ys:
            if merged and lo<=merged[-1][1]:merged[-1][1]=max(hi,merged[-1][1])
            else:merged.append([lo,hi])
        slabs.append((left,right,merged))
    return merge_slabs(slabs)
