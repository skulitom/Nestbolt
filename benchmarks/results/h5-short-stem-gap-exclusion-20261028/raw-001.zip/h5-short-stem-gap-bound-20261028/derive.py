"""Finite source-derived gap scheduling and stem-chain width lower bound."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import itertools,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-short-stem-gap-bound-20261028';SOURCE=ROOT/'output/h5-short14-orthogonal-source-20261028'
SHAPES=ROOT/'output/h5-short13-necessary-geometry-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'schedules').mkdir();shutil.copyfile(__file__,OUT/'derive.py');start=time.perf_counter()
inputs=[SOURCE/'plan.json',SOURCE/'modes.json',SOURCE/'stock.json',SOURCE/'geometry-audit/checks.json',SOURCE/'positive-control.json',
    SHAPES/'stock.json',SHAPES/'audit/checks.json',ROOT/'benchmarks/results/h5-short-count-x-screen-20261028/updated-allocations.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'maximum_brackets':8,'maximum_inserts':6,'inward_inset_um':2,'algorithm':'For every unordered pair of zero/one/two adjacent wing types and every0..6 insert count/orientation split, enumerate every distinct task order. Serially place each source-inner rectangle interval at its earliest resource-feasible X. The candidate starts are0 and previous interval ends. Preserve every order and returned schedule, including nonoptimal orders. Take the minimum makespan for each gap. Then exhaustively dynamic-program0..8 stems,0..6 inserts and pending right-wing type, charging every source-inner stem width and every gap lower width. No cog, source Y, fixed gap anchoring or clearance demand is added. Audit the source-to-gap mapping, exhaustive order coverage, schedules and full recurrence before applying any exclusion. There are no solver/native/production calls and no restart of the closed full-source model.'})
assert load(SOURCE/'geometry-audit/checks.json')['passed'] and load(SHAPES/'audit/checks.json')['passed']
stock=load(SHAPES/'stock.json');W,H=stock['capacity_um'];assert (W,H)==(1487040,312967)
profiles=[]
for m in load(SOURCE/'modes.json'):
    if m['family']!='bracket':continue
    rects=m['original_rectangles_um'];assert len(rects)==2
    stems=[r for r in rects if r[3]-r[1]==m['height_um']];assert len(stems)==1;stem=stems[0];wing=next(r for r in rects if r!=stem)
    direction='right' if wing[0]==stem[2] else 'left';assert direction=='right' or wing[2]==stem[0]
    si=[stem[0]+2,stem[1]+2,stem[2]-2,stem[3]-2];wi=[wing[0]+2,wing[1]+2,wing[2]-2,wing[3]-2]
    kind='A' if si[2]-si[0]==74996 else 'B';assert si[2]-si[0] in [74996,99996]
    profiles.append({'mode':m['id'],'stem_um':si,'wing_um':wi,'direction':direction,'kind':kind})
tasks={'A':[174996,99996],'B':[199996,74996],'H':[179996,109996],'V':[109996,179996]}
for r in profiles:
    a,b,c,d=r['wing_um'];assert [c-a,d-b]==tasks[r['kind']]
    assert r['stem_um'][3]-r['stem_um'][1]+min(t[1] for t in tasks.values())>H
write(OUT/'profiles.json',profiles);write(OUT/'tasks.json',tasks)
def orders(counts,prefix=()):
    if not any(counts.values()):yield prefix;return
    for t in sorted(counts):
        if counts[t]:
            counts[t]-=1;yield from orders(counts,prefix+(t,));counts[t]+=1
def feasible(placed,start,duration,demand):
    events={start:demand,start+duration:-demand}
    for s,t in placed:
        length,height=tasks[t];events[s]=events.get(s,0)+height;events[s+length]=events.get(s+length,0)-height
    height=0
    for x,delta in sorted(events.items()):
        height+=delta
        if height>H:return False
    assert height==0;return True
def schedule(order):
    placed=[]
    for t in order:
        length,height=tasks[t];candidates=sorted({0}|{s+tasks[u][0] for s,u in placed})
        s=next(s for s in candidates if feasible(placed,s,length,height));placed.append((s,t))
    return [s for s,t in placed],max((s+tasks[t][0] for s,t in placed),default=0)
wing_sets=[(),('A',),('B',),('A','A'),('A','B'),('B','B')];records=[];gap={};total_orders=0
for wings in wing_sets:
    key=''.join(wings) or 'none'
    for count in range(7):
        alternatives=[]
        for horizontal in range(count+1):
            counts=Counter(wings);counts['H']+=horizontal;counts['V']+=count-horizontal;schedules=[]
            for order in orders(counts):
                starts,width=schedule(order);schedules.append({'order':list(order),'starts_um':starts,'width_um':width})
            best=min(r['width_um'] for r in schedules);name=f'{key}-i{count}-h{horizontal}'
            write(OUT/'schedules'/f'{name}.json',schedules);total_orders+=len(schedules)
            row={'case':name,'wings':list(wings),'inserts':count,'horizontal':horizontal,'vertical':count-horizontal,
                'orders':len(schedules),'minimum_width_um':best,'schedules_sha256':digest(OUT/'schedules'/f'{name}.json')}
            records.append(row);alternatives.append(best)
        gap[wings,count]=min(alternatives)
write(OUT/'schedule-cases.json',records)
write(OUT/'gap-widths.json',[{'wings':list(w),'inserts':k,'minimum_width_um':v} for (w,k),v in gap.items()])
stem_width={'A':74996,'B':99996};dp={(0,0,'none'):0};transitions=[];parents={}
for number in range(8):
    for (n,used,pending),value in list(dp.items()):
        if n!=number:continue
        for kind,direction in itertools.product(['A','B'],['left','right']):
            wings=tuple(sorted(([pending] if pending!='none' else [])+([kind] if direction=='left' else [])))
            new_pending=kind if direction=='right' else 'none'
            for k in range(7-used):
                target=(n+1,used+k,new_pending);candidate=value+gap[wings,k]+stem_width[kind]
                transitions.append({'from':list((n,used,pending)),'to':list(target),'kind':kind,'direction':direction,'gap_inserts':k,'gap_wings':list(wings),'candidate_um':candidate})
                if target not in dp or candidate<dp[target]:dp[target]=candidate;parents[target]=(n,used,pending,kind,direction,k)
terminal=[]
for n in range(9):
    for count in range(7):
        alternatives=[]
        for (nn,used,pending),value in dp.items():
            if nn==n and used<=count:
                wings=() if pending=='none' else (pending,);alternatives.append(value+gap[wings,count-used])
        terminal.append({'brackets':n,'inserts':count,'minimum_required_width_um':min(alternatives),'stock_width_um':W,'excluded':min(alternatives)>W})
write(OUT/'states.json',[{'state':list(s),'width_um':v} for s,v in sorted(dp.items())]);write(OUT/'transitions.json',transitions);write(OUT/'terminal.json',terminal)
write(OUT/'derived.json',{'seconds':time.perf_counter()-start,'schedule_cases':len(records),'distinct_task_orders':total_orders,
    'gap_count_cases':len(gap),'states':len(dp),'transitions':len(transitions),'terminal_cases':len(terminal),
    'target':next(r for r in terminal if r['brackets']==8 and r['inserts']==6),
    'positive_control':next(r for r in terminal if r['brackets']==8 and r['inserts']==5),
    'exclusion_not_applied_until_independent_audit':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'derived.json'))
