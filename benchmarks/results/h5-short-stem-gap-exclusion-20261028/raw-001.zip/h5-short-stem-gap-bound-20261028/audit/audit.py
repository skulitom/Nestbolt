"""Independent exhaustive schedule/recurrence and source-to-gap certificate readback."""
from pathlib import Path
from hashlib import sha256
from itertools import permutations,product
from collections import Counter
from functools import lru_cache
from fractions import Fraction
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-stem-gap-bound-20261028';SOURCE=ROOT/'output/h5-short14-orthogonal-source-20261028';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
ga=load(SOURCE/'geometry-audit/checks.json');assert ga['passed'] and ga['positive_control_source_valid']
assert digest(SOURCE/'modes.json')==ga['geometry_sha256']
modes=load(SOURCE/'modes.json');tasks=load(BASE/'tasks.json');profiles=load(BASE/'profiles.json');stock=load(ROOT/'output/h5-short13-necessary-geometry-20261028/stock.json')
W,H=stock['capacity_um'];assert (W,H)==(1487040,312967)
relaxed=[Fraction(*v)*1000 for v in stock['relaxed_bounds_rational']]
actual=load(SOURCE/'stock.json')['actual_outline_bounds_mm']
assert float(relaxed[0])<=actual[0]*1000 and float(relaxed[1])<=actual[1]*1000
assert float(relaxed[2])>=actual[2]*1000 and float(relaxed[3])>=actual[3]*1000
assert relaxed[2]-relaxed[0]==W and relaxed[3]-relaxed[1]<=H
expected_profiles=[];stem_width={};barrier_slacks=[]
for m in modes:
    rects=m['original_rectangles_um'];inner=[[a+2,b+2,c-2,d-2] for a,b,c,d in rects]
    if m['family']=='insert':
        assert len(inner)==1;a,b,c,d=inner[0];key='H' if c-a>d-b else 'V';assert tasks[key]==[c-a,d-b];continue
    assert len(inner)==2
    si=next(r for r in inner if r[3]-r[1]==m['height_um']-4);wi=next(r for r in inner if r!=si)
    direction='right' if si[2]<wi[0] else 'left'
    assert wi[0]-si[2]==4 if direction=='right' else si[0]-wi[2]==4
    kind='A' if wi[3]-wi[1]==99996 else 'B';assert tasks[kind]==[wi[2]-wi[0],wi[3]-wi[1]]
    stem_width[kind]=si[2]-si[0];assert stem_width[kind]>4
    for _,height in tasks.values():
        slack=si[3]-si[1]+height-H;assert slack>0;barrier_slacks.append(slack)
    expected_profiles.append({'mode':m['id'],'stem_um':si,'wing_um':wi,'direction':direction,'kind':kind})
assert expected_profiles==profiles
assert Counter((r['kind'],r['direction']) for r in profiles)==Counter({(t,d):2 for t,d in product(['A','B'],['left','right'])})
assert min(r['stem_um'][3]-r['stem_um'][1] for r in profiles)*2>H
wing_sets=[(),('A',),('B',),('A','A'),('A','B'),('B','B')]
records=load(BASE/'schedule-cases.json');expected_cases=[(w,k,h) for w in wing_sets for k in range(7) for h in range(k+1)]
assert len(records)==len(expected_cases)==168
minima={};orders_checked=starts_checked=0
def capacity_ok(placed,candidate,t):
    # Independent segment-midpoint evaluation; no shared event-sweep helper.
    length,height=tasks[t];segments=placed+[(candidate,candidate+length,height)]
    ends=sorted({v for a,b,h in segments for v in [a,b]})
    return all(sum(h for a,b,h in segments if 2*a<=left+right<2*b)<=H for left,right in zip(ends,ends[1:]))
for r,(w,k,horizontal) in zip(records,expected_cases):
    assert r['wings']==list(w) and r['inserts']==k and r['horizontal']==horizontal and r['vertical']==k-horizontal
    path=BASE/'schedules'/f'{r["case"]}.json';assert digest(path)==r['schedules_sha256'];saved=load(path)
    labels=list(w)+['H']*horizontal+['V']*(k-horizontal)
    expected_orders=set(permutations(labels));seen=set();best=None
    for s in saved:
        order=tuple(s['order']);assert order in expected_orders and order not in seen;seen.add(order)
        assert len(s['starts_um'])==len(order);placed=[]
        for t,at in zip(order,s['starts_um']):
            candidates=sorted({0}|{b for a,b,height in placed})
            valid=[x for x in candidates if capacity_ok(placed,x,t)]
            assert valid and at==min(valid);length,height=tasks[t];placed.append((at,at+length,height));starts_checked+=1
        width=max((b for a,b,height in placed),default=0);assert width==s['width_um']
        best=width if best is None else min(best,width)
    assert seen==expected_orders and len(saved)==r['orders'] and best==r['minimum_width_um'];orders_checked+=len(saved)
    minima[w,k,horizontal]=best
gap={(w,k):min(minima[w,k,h] for h in range(k+1)) for w in wing_sets for k in range(7)}
assert load(BASE/'gap-widths.json')==[{'wings':list(w),'inserts':k,'minimum_width_um':v} for (w,k),v in gap.items()]
@lru_cache(None)
def suffix(stems,inserts,pending):
    if stems==0:return gap[(() if pending=='none' else (pending,)),inserts]
    values=[]
    for kind,direction in product(['A','B'],['left','right']):
        wings=tuple(sorted(([pending] if pending!='none' else [])+([kind] if direction=='left' else [])))
        future=kind if direction=='right' else 'none'
        for k in range(inserts+1):values.append(gap[wings,k]+stem_width[kind]+suffix(stems-1,inserts-k,future))
    return min(values)
terminals=load(BASE/'terminal.json');expected_terminal=[]
for b in range(9):
    for i in range(7):
        width=suffix(b,i,'none');expected_terminal.append({'brackets':b,'inserts':i,'minimum_required_width_um':width,'stock_width_um':W,'excluded':width>W})
assert terminals==expected_terminal
states={tuple(r['state']):r['width_um'] for r in load(BASE/'states.json')};assert states[0,0,'none']==0 and len(states)==169
expected_edges=[];incoming={}
for state,value in states.items():
    n,used,pending=state
    if n==8:continue
    for kind,direction in product(['A','B'],['left','right']):
        wings=tuple(sorted(([pending] if pending!='none' else [])+([kind] if direction=='left' else [])))
        future=kind if direction=='right' else 'none'
        for k in range(7-used):
            target=(n+1,used+k,future);candidate=value+gap[wings,k]+stem_width[kind]
            edge={'from':list(state),'to':list(target),'kind':kind,'direction':direction,'gap_inserts':k,'gap_wings':list(wings),'candidate_um':candidate}
            expected_edges.append(edge);incoming.setdefault(target,[]).append(candidate)
assert set(states)==set(incoming)|{(0,0,'none')}
for state,values in incoming.items():assert states[state]==min(values)
canon=lambda r:json.dumps(r,sort_keys=True)
saved_edges=load(BASE/'transitions.json');assert len(saved_edges)==2380 and sorted(map(canon,saved_edges))==sorted(map(canon,expected_edges))
# Map the known source13 into its actual stem gaps without solving anything.
control=load(SOURCE/'positive-control.json');by_mode={r['mode']:r for r in profiles};stems=[];inserts=[]
for r in control:
    x,y=r['anchor_um'];m=modes[r['mode']]
    if r['family']=='bracket':
        p=by_mode[r['mode']];si=p['stem_um'];wi=p['wing_um']
        stems.append({'stem':[x+si[0],x+si[2]],'wing':[x+wi[0],x+wi[2]],'direction':p['direction'],'kind':p['kind']})
    else:
        a,b,c,d=m['original_rectangles_um'][0];inserts.append({'interval':[x+a+2,x+c-2],'kind':'H' if c-a>d-b else 'V'})
stems.sort(key=lambda r:r['stem'][0]);assert len(stems)==8
gaps=[[int(relaxed[0]),stems[0]['stem'][0]]]+[[a['stem'][1],b['stem'][0]] for a,b in zip(stems,stems[1:])]+[[stems[-1]['stem'][1],int(relaxed[2])]]
members=[{'wings':[],'insert_modes':[]} for _ in gaps]
for index,r in enumerate(stems):
    g=index+(r['direction']=='right');assert gaps[g][0]<=r['wing'][0]<r['wing'][1]<=gaps[g][1];members[g]['wings'].append(r['kind'])
for r in inserts:
    eligible=[j for j,(a,b) in enumerate(gaps) if a<=r['interval'][0]<r['interval'][1]<=b];assert len(eligible)==1;members[eligible[0]]['insert_modes'].append(r['kind'])
control_rows=[]
for bounds,m in zip(gaps,members):
    w=tuple(sorted(m['wings']));k=len(m['insert_modes']);horizontal=m['insert_modes'].count('H');lower=minima[w,k,horizontal]
    assert bounds[1]-bounds[0]>=lower;control_rows.append({'bounds_um':bounds,**m,'same_mode_lower_width_um':lower})
assert suffix(8,5,'none')<=W;write(OUT/'positive-control-gaps.json',control_rows)
prior_path=ROOT/'benchmarks/results/h5-short-count-x-screen-20261028/updated-allocations.json';prior=load(prior_path);excluded_counts=[r for r in terminals if r['excluded']]
assert [(r['brackets'],r['inserts']) for r in excluded_counts]==[(8,6)]
updated=[];new=[]
for original in prior:
    r=dict(original);b,i,c=r['short_counts']
    if r['excluded_by'] is None and any(b>=q['brackets'] and i>=q['inserts'] for q in excluded_counts):
        r['excluded_by']='source_stem_gap_width_8_6_0';new.append(r)
    updated.append(r)
assert [r['short_counts'] for r in new]==[[8,6,0],[8,7,0]]
survivors=[r['short_counts'] for r in updated if r['excluded_by'] is None];assert len(survivors)==446
assert [8,5,0] in survivors and [7,4,1] in survivors
pareto=[r for r in survivors if not any(q!=r and all(q[k]>=r[k] for k in range(3)) for q in survivors)]
write(OUT/'updated-allocations.json',updated);write(OUT/'newly-excluded-allocations.json',new);write(OUT/'pareto-necessary-counts.json',pareto)
write(OUT/'necessity-proof.json',{
    'inward_source_geometry':'Use each independently reconstructed exact orthogonal source mode, split into its full-height stem and one wing (or one insert rectangle), then inset each rectangle by2um. Floor the actual source bounding-box anchor in both axes. Its displacement is less than1um per axis, so every inset rectangle remains inside the original filled outer. They lie in the outward-relaxed stock. Holes stay reserved under PIH OFF. All8 bracket modes and both insert outer classes are represented.',
    'barrier_argument':'A stem has height at least249996um, while every wing or insert has height at least74996um. Their sum324992 exceeds the complete relaxed stock height312967. Thus a stem cannot overlap the X interior of any other original rectangle; two stems also cannot overlap. Eight stems therefore partition the X stock interval into nine gaps. Each wing is separated from its own stem by exactly4um. No other stem (minimum width74996um) can fit into that4um separation. Since it cannot overlap the wing either, each wing must lie in the adjacent gap indicated by its left/right direction. Each gap has at most the right-facing wing of its left stem and the left-facing wing of its right stem. Every insert interval lies wholly in one gap.',
    'gap_relaxation':'At each X, heights of the disjoint source rectangles in one gap sum to at most312967um. Discard source Y positions, fixed wing-edge offsets and their absolute anchors; allow arbitrary interval scheduling inside the gap. Each wing and each chosen insert outer mode becomes a task with its exact inward width as duration and inward height as demand. This relaxation can only lower the required gap width.',
    'finite_order_completeness':'For any feasible continuous interval schedule, process its tasks in nondecreasing original start order. Place each next task at the earliest time feasible against earlier placed tasks. Inductively every earlier task starts and ends no later than in the original schedule. At times at or after the current original start, the earlier shifted tasks that are active are a subset of those originally active, so the current original start remains feasible. The new start/end therefore cannot be later. Thus some serial earliest-start schedule has makespan no larger than any given feasible schedule. Its earliest start is0 or an earlier task end: otherwise it could move left until such an event without increasing peak demand. All durations are integer, so every resulting start is integer. Enumerating every distinct task order therefore gives the exact relaxed minimum even for continuous original positions. All12925 orders and every placement step are independently checked; no heuristic lower estimate is used.',
    'chain_completeness':'The four stem choices are the two source width/wing types times left/right direction, covering all8 modes after harmless removal of vertical orientation. The recurrence tries every choice, every pending right wing and every distribution of0..6 inserts among the nine gaps; each gap also tries every insert orientation split. Every real source placement maps into one branch. The sum of its stem widths and actual gap widths is the full stock width, while each actual gap is at least its independently proved relaxed minimum. Forward readback and an independent backward recurrence agree on all63 terminal count cases.',
    'conclusion':'Eight brackets and six inserts require at least1489948um of total horizontal width, greater than the relaxed stock width1487040um by2908um. Hence no actual source8/6/0 placement exists at the unchanged target. By deleting extras,8/7/0 is also excluded. These are the only two newly excluded vectors among the448 previous survivors. All4576 original rows remain recorded and446 survive. The closed conservative CP-SAT UNKNOWN response is not used as evidence of this exclusion. No full66 infeasibility or H5 completion follows.'})
inputs=[BASE/'plan.json',BASE/'profiles.json',BASE/'tasks.json',BASE/'schedule-cases.json',BASE/'gap-widths.json',BASE/'states.json',BASE/'transitions.json',BASE/'terminal.json',SOURCE/'geometry-audit/checks.json',prior_path]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
summary={'passed':True,'seconds':time.perf_counter()-start,'source_modes_verified':10,'minimum_barrier_height_slack_um':min(barrier_slacks),
    'schedule_cases_verified':168,'distinct_orders_verified':orders_checked,'earliest_start_steps_verified':starts_checked,
    'gap_bounds_verified':42,'forward_states_verified':169,'forward_transitions_verified':2380,'backward_terminal_cases_verified':63,
    'known_source13_gap_mapping_passed':True,'short8_6_minimum_width_um':suffix(8,6,'none'),'relaxed_stock_width_um':W,
    'width_deficit_um':suffix(8,6,'none')-W,'short8_5_minimum_width_um':suffix(8,5,'none'),
    'newly_excluded_counts':[r['short_counts'] for r in new],'remaining_necessary_allocations':446,'pareto_necessary_count_vectors':len(pareto),
    'all_count_allocations_retained':4576,'unknown_solver_response_used_for_exclusion':False,'full66_exclusion_claimed':False,
    'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',summary);print(summary)
