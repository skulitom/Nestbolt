"""Clique certificates for every diagnostic deletion of at most two seed core poses."""
from collections import Counter
from datetime import datetime, timezone
from itertools import combinations
import gzip, json, shutil, time
from reduce_h5_free_cog_pool import ROOT, SRC, OLD, load, write, digest
from census_h5_one_part_moves import bits

RUN = ROOT / 'output/h5-full-insert-blockers-20261020'
OUT = ROOT / 'output/h5-insert-blocker-certificates-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'certify.py')
    sources = [RUN / n for n in ['mapping.json', 'audit/checks.json', 'audit/insert-blockers.json', 'result.json']]
    sources += [OLD / 'cliques.jsonl.gz', SRC / 'new-cliques.jsonl.gz', SRC / 'candidates.json']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'method': 'Exhaustively enumerate all zero/one/two deletions of original seed core poses, without relocating any remaining core. Keep every compatible retained insert pose. Cover each exact available-insert set with original cliques and verify every certificate with explicit sets. These are necessary upper bounds and may be loose.',
        'scope': 'Independently check the minimum-blocker diagnostic where possible. Omitted core parts still prevent original-job acceptance.',
        'solver_calls': 0, 'native_packing_calls': 0, 'quality_runs': 0})
    start = time.perf_counter()
    mapping = load(RUN / 'mapping.json')
    core = mapping['core']
    inserts = set(mapping['inserts'])
    blocker_sets = {int(i): set(bs) for i, bs in load(RUN / 'audit/insert-blockers.json').items()}
    blockers = {i: sum(1 << b for b in bs) for i, bs in blocker_sets.items()}
    cliques = []
    for path in [OLD / 'cliques.jsonl.gz', SRC / 'new-cliques.jsonl.gz']:
        with gzip.open(path, 'rt', encoding='utf-8') as f:
            cliques.extend(set(json.loads(line)) for line in f)
    projection = {}
    for ci, c in enumerate(cliques):
        cut = c & inserts
        if len(cut) > 1:
            projection.setdefault(sum(1 << i for i in cut), ci)
    deletions = [()]
    deletions += [(i,) for i in core]
    deletions += list(combinations(core, 2))
    groups = {}
    for removed in deletions:
        rm = sum(1 << i for i in removed)
        available = sum(1 << i for i in inserts if not(blockers[i] & ~rm))
        groups.setdefault(available, []).append(list(removed))
    records = []
    for index, (available, removals) in enumerate(sorted(groups.items())):
        options = {}
        for mask, ci in projection.items():
            cut = mask & available
            if cut.bit_count() > 1:
                options.setdefault(cut, ci)
        remaining = available
        cover = []
        while remaining:
            best = max(options, key=lambda m: ((m & remaining).bit_count(), -options[m]), default=0)
            cut = best & remaining
            ci = options[best] if cut.bit_count() > 1 else None
            if ci is None:
                cut = remaining & -remaining
            cover.append({'source_clique': ci, 'candidates': list(bits(cut))})
            remaining &= ~cut
        records.append({'index': index, 'insert_candidates': list(bits(available)), 'removed_core_sets': removals,
                        'cover': cover, 'insert_upper_bound': len(cover)})
    write(OUT / 'certificates.json', records)
    # Independent set reconstruction and coverage verification, including all 1036 deletion sets.
    seen = set()
    bound_rows = []
    for row in records:
        available = set(row['insert_candidates'])
        assert len(available) == len(row['insert_candidates'])
        covered = set()
        for entry in row['cover']:
            vs = set(entry['candidates'])
            assert vs and len(vs) == len(entry['candidates']) and vs <= available and not(vs & covered)
            if entry['source_clique'] is None:
                assert len(vs) == 1
            else:
                assert vs <= cliques[entry['source_clique']]
            covered.update(vs)
        assert covered == available
        for removed in row['removed_core_sets']:
            key = tuple(removed)
            assert key not in seen
            seen.add(key)
            expected = {i for i in inserts if blocker_sets[i] <= set(removed)}
            assert expected == available
            bound_rows.append({'removed': removed, 'insert_upper_bound': len(row['cover'])})
    expected_deletions = {tuple(sorted(s)) for n in range(3) for s in combinations(sorted(core), n)}
    assert seen == expected_deletions
    dominant = mapping['count_coefficient']
    areas = {int(i): a for i, a in mapping['rounded_core_areas'].items()}
    cost = lambda ids: dominant * len(ids) + sum(areas[i] for i in ids)
    admitted = [r for r in bound_rows if r['insert_upper_bound'] >= 21]
    result = load(RUN / 'result.json')
    pool = load(SRC / 'candidates.json')
    known_cost = cost(result['removed_core'])
    lower_cost = min((cost(r['removed']) for r in admitted), default=None)
    zero_one_bound = max(r['insert_upper_bound'] for r in bound_rows if len(r['removed']) < 2)
    check = {'all_deletions_independently_enumerated': True, 'deletion_sets': len(seen),
             'distinct_insert_sets': len(records), 'cover_entries_verified': sum(len(r['cover']) for r in records),
             'maximum_insert_bound_with_zero_or_one_deletion': zero_one_bound,
             'at_least_two_seed_core_deletions_certified': zero_one_bound < 21,
             'admitted_deletion_sets': len(admitted),
             'admitted_removed_families': dict(Counter(
                 ','.join(sorted(pool[i]['placement']['part_id'] for i in r['removed']))
                 for r in admitted)),
             'certificate_lower_lexicographic_deletion_cost': lower_cost,
             'audited_witness_deletion_cost': known_cost,
             'entire_diagnostic_optimum_certified_by_covers': lower_cost == known_cost,
             'seconds': time.perf_counter() - start, 'full_target_witness': False,
             'unrestricted_impossibility_claimed': False}
    write(OUT / 'admitted-deletions.json', admitted)
    write(OUT / 'checks.json', check)
    print(json.dumps(check), flush=True)

if __name__ == '__main__':
    main()
