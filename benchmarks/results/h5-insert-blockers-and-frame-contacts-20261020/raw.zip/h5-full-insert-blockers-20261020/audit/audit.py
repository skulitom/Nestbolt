"""Independently audit every diagnostic output and its original core blockers."""
from collections import Counter, defaultdict
from itertools import combinations
import copy, gzip, json, math, shutil, subprocess
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT, SRC, OLD, OUT as PARENT, load, write, digest

RUN = ROOT / 'output/h5-full-insert-blockers-20261020'
OUT = RUN / 'audit'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'audit.py')
    for p, h in load(RUN / 'plan.json')['inputs'].items():
        assert digest(ROOT / p) == h
    pool = load(SRC / 'candidates.json')
    job = load(SRC / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    required = Counter({k: p['quantity'] for k, p in parts.items()})
    target = load(SRC / 'conditional-target.json')
    mapping = load(RUN / 'mapping.json')
    core = set(mapping['core'])
    allowed = set(mapping['candidates'])
    inserts = set(mapping['inserts'])
    stock = job['stocks'][0]
    margins = stock['margins']
    edge = job['edge_clearance']
    sheets = load(PARENT / 'seed-layout.json')['sheets']
    cliques = []
    for path in [OLD / 'cliques.jsonl.gz', SRC / 'new-cliques.jsonl.gz']:
        with gzip.open(path, 'rt', encoding='utf-8') as f:
            cliques.extend(set(json.loads(line)) for line in f)
    graph_blockers = {i: set() for i in inserts}
    for c in cliques:
        for i in c & inserts:
            graph_blockers[i].update(c & core)
    geometry = {i: shape(parts[pool[i]['placement']['part_id']], pool[i]['placement']['transform'])
                for i in allowed}
    original_pairs = 0
    for i in inserts:
        exact = set()
        for j in core:
            if pool[i]['placement']['sheet_id'] != pool[j]['placement']['sheet_id']:
                continue
            original_pairs += 1
            if geometry[i].distance(geometry[j]) < job['clearance'] - 1e-7:
                exact.add(j)
        assert graph_blockers[i] == exact
    weights = {int(i): w for i, w in mapping['core_objective_weights'].items()}
    for i in core:
        area = round(geometry[i].area)
        assert area == mapping['rounded_core_areas'][str(i)]
        assert weights[i] == mapping['count_coefficient'] + area
    assert mapping['count_coefficient'] > sum(round(geometry[i].area) for i in core)
    result = load(RUN / 'result.json')
    outcomes = [load(RUN / f'incumbent-{i}.json') for i in range(result['incumbents'])]
    final = load(RUN / 'selected-indices.json')
    if not outcomes or final != outcomes[-1]['selected_indices']:
        outcomes.append({'index': 'final', 'selected_indices': final, 'objective': result['objective']})
    cli = ROOT / 'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli) == '97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    records = []
    for r in outcomes:
        ids = r['selected_indices']
        chosen = set(ids)
        assert len(chosen) == len(ids) and chosen <= allowed and len(chosen & inserts) == 21
        assert all(len(c & chosen) <= 1 for c in cliques)
        removed = core - chosen
        blockers = set().union(*(graph_blockers[i] for i in chosen & inserts))
        assert blockers <= removed
        score = sum(weights[i] for i in chosen & core)
        assert score == r['objective']
        counts = Counter()
        placements = []
        geoms = defaultdict(list)
        tops = Counter()
        for i in ids:
            p = copy.deepcopy(pool[i]['placement'])
            t = p['transform']
            part = parts[p['part_id']]
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind'] == 'list':
                assert any(abs(math.remainder(t['rotation_radians'] - math.radians(a), math.tau)) < 1e-9
                           for a in part['rotations']['degrees'])
            p['copy_index'] = counts[p['part_id']]
            counts[p['part_id']] += 1
            placements.append(p)
            g = geometry[i]
            x0, y0, x1, y1 = g.bounds
            height = stock['height'] if p['sheet_id'] == 'sheet-0' else target['required_used_height_mm']
            assert g.is_valid and x0 >= margins['left'] + edge - 1e-7 and y0 >= margins['bottom'] + edge - 1e-7
            assert x1 <= stock['width'] - margins['right'] - edge + 1e-7
            assert y1 <= height - margins['top'] - edge + 1e-7
            tops[p['sheet_id']] = max(tops[p['sheet_id']], y1 + margins['top'] + edge)
            geoms[p['sheet_id']].append(g)
        pairs = 0
        minimum = math.inf
        for group in geoms.values():
            for a, b in combinations(group, 2):
                pairs += 1
                minimum = min(minimum, a.distance(b))
                assert a.disjoint(b) and a.distance(b) >= job['clearance'] - 1e-7
        key = r['index']
        layout = {'version': 1, 'units': 'mm', 'sheets': sheets, 'placements': placements}
        path = OUT / f'layout-{key}.json'
        write(path, layout)
        cmd = [str(cli), 'validate', '--library', str(SRC / 'library.json'),
               '--request', str(SRC / 'request.json'), '--layout', str(path)]
        cp = subprocess.run(cmd, capture_output=True, timeout=60)
        (OUT / f'public-{key}.json').write_bytes(cp.stdout)
        (OUT / f'public-{key}.stderr').write_bytes(cp.stderr)
        write(OUT / f'command-{key}.json', {'command': cmd, 'exit_code': cp.returncode})
        public = json.loads(cp.stdout)
        missing = required - counts
        expected = sorted(f'part {f}: expected {required[f]}, found {counts[f]}' for f in missing)
        assert cp.returncode != 0 and not public['valid']
        assert all(v['code'] == 'quantity' for v in public['violations'])
        assert sorted(v['message'] for v in public['violations']) == expected
        material = stock['width'] * (stock['height'] + tops['sheet-1'])
        assert material <= target['target_material_mm2'] + 1e-6
        records.append({'incumbent': key, 'counts': dict(counts), 'missing': dict(missing),
                        'core_removed': sorted(removed), 'actual_insert_blockers': sorted(blockers),
                        'unnecessarily_omitted_core': sorted(removed - blockers),
                        'pairs': pairs, 'minimum_distance_mm': minimum,
                        'charged_material_mm2': material,
                        'filled_area_mm2': sum(g.area for group in geoms.values() for g in group),
                        'original_CLI_valid': False})
    blockers = set().union(*(graph_blockers[i] for i in set(final) & inserts))
    assert blockers == core - set(final) == set(result['removed_core'])
    write(OUT / 'insert-blockers.json', {i: sorted(b) for i, b in graph_blockers.items()})
    write(OUT / 'final-removed-placements.json',
          [{'candidate': i, 'placement': pool[i]['placement'], 'bounds': list(geometry[i].bounds)}
           for i in sorted(blockers)])
    check = {'all_original_insert_core_pairs_checked': original_pairs,
             'all_insert_blocker_sets_match_original_geometry': True,
             'all_returned_layouts_checked': len(records), 'records': records,
             'final_inserts': 21, 'final_missing_core': result['removed_core_by_family'],
             'solver_status': result['status'], 'solver_optimum_only_within_diagnostic_pool': True,
             'full_target_witness': False, 'native_margin_qualified': False,
             'fresh_frozen_CLI_calls': len(records), 'native_packing_calls': 0, 'quality_runs': 0}
    write(OUT / 'checks.json', check)
    print(json.dumps({k: v for k, v in check.items() if k != 'records'}), flush=True)

if __name__ == '__main__':
    main()
