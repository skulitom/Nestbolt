"""Find exact seed-core blockers of 21 mutually compatible retained insert poses."""
from collections import Counter
from datetime import datetime, timezone
import gzip, json, shutil, time, traceback
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT, SRC, OLD, OUT as PARENT, load, write, digest

OUT = ROOT / 'output/h5-full-insert-blockers-20261020'

def outer_area(part):
    assert len(part['geometry']) == 1
    points = part['geometry'][0]['outer']
    return abs(sum(a[0] * b[1] - b[0] * a[1]
                   for a, b in zip(points, points[1:] + points[:1]))) / 2

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'diagnose.py')
    sources = [PARENT / n for n in ['kept-candidates.json', 'seed-indices.json', 'audit.json']]
    sources += [SRC / n for n in ['candidates.json', 'job.json', 'new-cliques.jsonl.gz']]
    sources += [OLD / 'cliques.jsonl.gz',
                ROOT / 'output/h5-two-core-move-census-20261020/audit.json']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'seconds_limit': 20, 'workers': 8, 'seed': 0,
        'method': 'Select exactly 21 mutually compatible insert poses from the 686 retained candidates. Keep or temporarily omit each of the 45 saved core poses; introduce no new core poses. Maximize retained core count first, then retained rounded original filled-outer area. A count-dominating integer coefficient enforces the lexicographic order. Independently reconstruct the complete model before one bounded solve; preserve every incumbent.',
        'scope': 'Diagnostic only. Omitted frames, brackets or cogs remain required by the original job; this relaxation never counts as a full layout. An optimum bounds required seed-pose removals only within the retained insert pool.',
        'next': 'Use the exact core blocker union of selected inserts to inspect relocation regions. Restore all original family quantities in any follow-up completion model.',
        'native_packing_calls': 0, 'quality_runs': 0})
    pool = load(SRC / 'candidates.json')
    parts = {p['id']: p for p in load(SRC / 'job.json')['parts']}
    kept = load(PARENT / 'kept-candidates.json')
    core = sorted(i for i in load(PARENT / 'seed-indices.json') if pool[i]['placement']['part_id'] != 'insert')
    inserts = sorted(i for i in kept if pool[i]['placement']['part_id'] == 'insert')
    assert len(core) == 45 and len(inserts) == 686
    ids = sorted(core + inserts)
    local = {i: j for j, i in enumerate(ids)}
    original_cliques = []
    for path in [OLD / 'cliques.jsonl.gz', SRC / 'new-cliques.jsonl.gz']:
        with gzip.open(path, 'rt', encoding='utf-8') as f:
            original_cliques.extend(set(json.loads(line)) for line in f)
    rows = sorted({tuple(sorted(c & local.keys())) for c in original_cliques if len(c & local.keys()) > 1})
    areas = {i: round(outer_area(parts[pool[i]['placement']['part_id']])) for i in core}
    dominant = 1 + sum(areas.values())
    weights = {i: dominant + areas[i] for i in core}
    model = cp_model.CpModel()
    variables = [model.new_bool_var(f'p{i}') for i in ids]
    for row in rows:
        model.add_at_most_one(variables[local[i]] for i in row)
    model.add(sum(variables[local[i]] for i in inserts) == 21)
    model.maximize(sum(weights[i] * variables[local[i]] for i in core))
    assert model.validate() == ''
    model.export_to_file(str(OUT / 'model.pbtxt'))
    expected = cp_model_pb2.CpModelProto()
    for i in ids:
        v = expected.variables.add()
        v.name = f'p{i}'
        v.domain.extend([0, 1])
    independent_rows = set()
    for clique in original_cliques:
        row = tuple(sorted(local[i] for i in clique if i in local))
        if len(row) > 1:
            independent_rows.add(row)
    for row in sorted(independent_rows):
        expected.constraints.add().at_most_one.literals.extend(row)
    c = expected.constraints.add().linear
    c.vars.extend(local[i] for i in inserts)
    c.coeffs.extend([1] * len(inserts))
    c.domain.extend([21, 21])
    expected.objective.vars.extend(local[i] for i in core)
    expected.objective.coeffs.extend(-weights[i] for i in core)
    expected.objective.scaling_factor = -1
    actual = text_format.Parse((OUT / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
    assert actual.SerializeToString(deterministic=True) == expected.SerializeToString(deterministic=True)
    write(OUT / 'mapping.json', {'candidates': ids, 'core': core, 'inserts': inserts,
                               'rounded_core_areas': areas, 'count_coefficient': dominant,
                               'core_objective_weights': weights})
    write(OUT / 'model-audit.json', {
        'all_model_fields_independently_reconstructed': True, 'variables': len(ids),
        'cliques': len(rows), 'constraints': len(actual.constraints),
        'insert_quantity': 21, 'core_deletion_is_diagnostic_only': True,
        'count_coefficient_exceeds_all_area_ties': dominant > sum(areas.values()),
        'model_sha256': digest(OUT / 'model.pbtxt')})
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 20
    solver.parameters.num_search_workers = 8
    solver.parameters.random_seed = 0
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = False
    (OUT / 'parameters.pbtxt').write_text(str(solver.parameters), encoding='utf-8', newline='\n')
    records = []
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            chosen = [i for j, i in enumerate(ids) if self.value(model.get_int_var_from_proto_index(j))]
            removed = sorted(set(core) - set(chosen))
            record = {'index': len(records), 'selected_indices': chosen, 'removed_core': removed,
                      'removed_core_by_family': dict(Counter(pool[i]['placement']['part_id'] for i in removed)),
                      'seconds': self.wall_time, 'objective': self.objective_value,
                      'best_bound': self.best_objective_bound}
            write(OUT / f"incumbent-{record['index']}.json", record)
            records.append(record)
            print(json.dumps({k: v for k, v in record.items() if k not in ['selected_indices', 'removed_core']}), flush=True)
    write(OUT / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'seconds_limit': 20})
    with (OUT / 'solver.log').open('x', encoding='utf-8', newline='\n') as log:
        solver.log_callback = lambda s: (log.write(s + '\n'), log.flush())
        start = time.perf_counter()
        status = solver.solve(model, Capture())
        seconds = time.perf_counter() - start
    feasible = status in [cp_model.OPTIMAL, cp_model.FEASIBLE]
    result = {'status': solver.status_name(status), 'seconds': seconds, 'incumbents': len(records),
              'feasible': feasible, 'response_stats': solver.response_stats(),
              'full_target_witness': False, 'native_margin_qualified': False}
    if feasible:
        chosen = [i for j, i in enumerate(ids) if solver.value(model.get_int_var_from_proto_index(j))]
        write(OUT / 'selected-indices.json', chosen)
        removed = sorted(set(core) - set(chosen))
        result.update(removed_core=removed, removed_core_count=len(removed),
                      removed_core_by_family=dict(Counter(pool[i]['placement']['part_id'] for i in removed)),
                      objective=solver.objective_value, best_bound=solver.best_objective_bound)
    else:
        assert not records
    write(OUT / 'result.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'response_stats'}), flush=True)

if __name__ == '__main__':
    try:
        main()
    except BaseException:
        if OUT.exists():
            (OUT / 'failure.txt').write_text(traceback.format_exc(), encoding='utf-8', newline='\n')
        raise
