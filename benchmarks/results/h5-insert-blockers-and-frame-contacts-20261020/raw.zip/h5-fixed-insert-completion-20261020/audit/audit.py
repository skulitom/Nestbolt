"""Audit conditional frame-completion outputs against original geometry and CLI."""
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path
import argparse, copy, json, math, shutil, subprocess
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT, SRC, OUT as PARENT, load, write, digest

DIAG = ROOT / 'output/h5-full-insert-blockers-20261020'

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--run', default='output/h5-fixed-insert-completion-20261020')
    ap.add_argument('--pool', default=str(SRC / 'candidates.json'))
    args = ap.parse_args()
    run = (ROOT / args.run).resolve()
    poolpath = (ROOT / args.pool).resolve()
    assert run.is_relative_to(ROOT / 'output') and poolpath.is_relative_to(ROOT / 'output')
    out = run / 'audit'
    out.mkdir()
    shutil.copyfile(__file__, out / 'audit.py')
    for p, h in load(run / 'plan.json')['inputs'].items():
        assert digest(ROOT / p) == h
    mapping = load(run / 'mapping.json')
    pool = load(poolpath)
    job = load(SRC / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    required = Counter({k: p['quantity'] for k, p in parts.items()})
    stock = job['stocks'][0]
    m, edge = stock['margins'], job['edge_clearance']
    target = load(SRC / 'conditional-target.json')
    fixed = set(mapping['fixed_insert_candidates'])
    allowed = set(mapping['candidates']) | fixed
    result = load(run / 'result.json')
    outcomes = [load(run / f'incumbent-{i}.json') for i in range(result['incumbents'])]
    if result['feasible']:
        final = load(run / 'selected-indices.json')
        if not outcomes or final != outcomes[-1]['selected_indices']:
            outcomes.append({'index': 'final', 'selected_indices': final, 'frames': result['frames']})
    else:
        assert not outcomes
    seed = load(DIAG / 'selected-indices.json')
    seed_layout = load(DIAG / 'audit/layout-final.json')
    sheets = seed_layout['sheets']
    cli = ROOT / 'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli) == '97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    records = []
    fresh = reused = 0
    for r in outcomes:
        ids = r['selected_indices']
        chosen = set(ids)
        assert len(ids) == len(chosen) and chosen <= allowed and fixed <= chosen
        counts = Counter()
        placements = []
        geoms = defaultdict(list)
        tops = Counter()
        for i in ids:
            p = copy.deepcopy(pool[i]['placement'])
            part, t = parts[p['part_id']], p['transform']
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind'] == 'list':
                assert any(abs(math.remainder(t['rotation_radians'] - math.radians(a), math.tau)) < 1e-9
                           for a in part['rotations']['degrees'])
            p['copy_index'] = counts[p['part_id']]
            counts[p['part_id']] += 1
            placements.append(p)
            g = shape(part, t)
            x0, y0, x1, y1 = g.bounds
            height = stock['height'] if p['sheet_id'] == 'sheet-0' else target['required_used_height_mm']
            assert g.is_valid and x0 >= m['left'] + edge - 1e-7 and y0 >= m['bottom'] + edge - 1e-7
            assert x1 <= stock['width'] - m['right'] - edge + 1e-7
            assert y1 <= height - m['top'] - edge + 1e-7
            geoms[p['sheet_id']].append(g)
            tops[p['sheet_id']] = max(tops[p['sheet_id']], y1 + m['top'] + edge)
        assert counts == Counter(frame=r['frames'], bracket=12, cog=15, insert=21)
        assert 16 <= counts['frame'] <= 18
        pairs = 0
        minimum = math.inf
        for gs in geoms.values():
            for a, b in combinations(gs, 2):
                pairs += 1
                minimum = min(minimum, a.distance(b))
                assert a.disjoint(b) and a.distance(b) >= job['clearance'] - 1e-7
        layout = {'version': 1, 'units': 'mm', 'sheets': sheets, 'placements': placements}
        key = r['index']
        path = out / f'layout-{key}.json'
        write(path, layout)
        if ids == seed:
            assert layout == seed_layout
            public = load(DIAG / 'audit/public-final.json')
            code = load(DIAG / 'audit/command-final.json')['exit_code']
            write(out / f'validation-reuse-{key}.json', {
                'rerun': False, 'exact_layout_match': True,
                'source_files': {str((DIAG / n).relative_to(ROOT)): digest(DIAG / n)
                                 for n in ['audit/layout-final.json', 'audit/public-final.json', 'audit/command-final.json']}})
            shutil.copyfile(DIAG / 'audit/public-final.json', out / f'public-{key}.json')
            reused += 1
        else:
            cmd = [str(cli), 'validate', '--library', str(SRC / 'library.json'),
                   '--request', str(SRC / 'request.json'), '--layout', str(path)]
            cp = subprocess.run(cmd, capture_output=True, timeout=60)
            code = cp.returncode
            (out / f'public-{key}.json').write_bytes(cp.stdout)
            (out / f'public-{key}.stderr').write_bytes(cp.stderr)
            write(out / f'command-{key}.json', {'command': cmd, 'exit_code': code})
            public = json.loads(cp.stdout)
            fresh += 1
        missing = required - counts
        assert public['valid'] == (not missing)
        if missing:
            assert code != 0 and public['violations'] == [
                {'code': 'quantity', 'message': f"part frame: expected 18, found {counts['frame']}"}]
        else:
            assert code == 0 and not public['violations']
        material = stock['width'] * (stock['height'] + tops['sheet-1'])
        assert material <= target['target_material_mm2'] + 1e-6
        records.append({'incumbent': key, 'frames': counts['frame'], 'missing_frames': 18 - counts['frame'],
                        'pairs': pairs, 'minimum_distance_mm': minimum,
                        'charged_material_mm2': material,
                        'filled_area_mm2': sum(g.area for gs in geoms.values() for g in gs),
                        'original_CLI_valid': public['valid'], 'exact_seed_validation_reused': ids == seed})
    check = {'status': result['status'], 'seconds': result['seconds'],
             'all_returned_layouts_checked': len(records), 'records': records,
             'fresh_frozen_CLI_calls': fresh, 'reused_frozen_CLI_results': reused,
             'best_frame_count': max((r['frames'] for r in records), default=None),
             'full_target_witness': any(r['original_CLI_valid'] for r in records),
             'native_margin_qualified': False, 'native_packing_calls': 0, 'quality_runs': 0}
    write(out / 'checks.json', check)
    print(json.dumps({k: v for k, v in check.items() if k != 'records'}), flush=True)

if __name__ == '__main__':
    main()
