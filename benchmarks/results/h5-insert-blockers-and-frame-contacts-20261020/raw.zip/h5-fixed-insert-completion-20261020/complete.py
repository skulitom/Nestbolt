"""Restore missing frames while allowing every bracket, cog and frame to move."""
from collections import Counter
from datetime import datetime, timezone
import gzip, json, shutil, time
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT, SRC, OLD, OUT as PARENT, load, write, digest

DIAG = ROOT / 'output/h5-full-insert-blockers-20261020'
OUT = ROOT / 'output/h5-fixed-insert-completion-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'complete.py')
    assert load(DIAG / 'audit/checks.json')['all_insert_blocker_sets_match_original_geometry']
    sources = [PARENT / 'kept-candidates.json', DIAG / 'selected-indices.json', DIAG / 'audit/checks.json',
               SRC / 'candidates.json', OLD / 'cliques.jsonl.gz', SRC / 'new-cliques.jsonl.gz']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'seconds_limit': 20, 'workers': 8, 'seed': 0,
        'method': 'Fix the audited diagnostic final 21-insert set. Allow all retained original frame/bracket/cog poses compatible with those inserts. Require all 12 brackets and 15 cogs; maximize frames from the known feasible 16 through the original quantity18. Preserve every projected conflict and give a complete feasible hint. Reconstruct every model field and hint before one bounded solve.',
        'scope': 'Only this fixed insert set and finite original retained pool. A partial frame count remains a failed original job. All18 is a candidate pending independent geometry, original CLI and native margin checks.',
        'native_packing_calls': 0, 'quality_runs': 0})
    pool = load(SRC / 'candidates.json')
    seed = set(load(DIAG / 'selected-indices.json'))
    fixed = {i for i in seed if pool[i]['placement']['part_id'] == 'insert'}
    assert len(fixed) == 21
    kept = set(load(PARENT / 'kept-candidates.json'))
    cliques = []
    blocked = set()
    for p in [OLD / 'cliques.jsonl.gz', SRC / 'new-cliques.jsonl.gz']:
        with gzip.open(p, 'rt', encoding='utf-8') as f:
            for line in f:
                c = set(json.loads(line))
                assert len(c & fixed) <= 1
                cliques.append(c)
                if c & fixed:
                    blocked |= c - fixed
    ids = sorted(i for i in kept - blocked if pool[i]['placement']['part_id'] != 'insert')
    assert seed - fixed <= set(ids)
    local = {i: j for j, i in enumerate(ids)}
    rows = sorted({tuple(sorted(c & local.keys())) for c in cliques if len(c & local.keys()) > 1})
    model = cp_model.CpModel()
    variables = [model.new_bool_var(f'p{i}') for i in ids]
    for row in rows:
        model.add_at_most_one(variables[local[i]] for i in row)
    families = {f: [j for j, i in enumerate(ids) if pool[i]['placement']['part_id'] == f]
                for f in ['frame', 'bracket', 'cog']}
    for f, lo, hi in [('frame', 16, 18), ('bracket', 12, 12), ('cog', 15, 15)]:
        model.add_linear_constraint(sum(variables[j] for j in families[f]), lo, hi)
    model.maximize(sum(variables[j] for j in families['frame']))
    hint = [int(i in seed) for i in ids]
    for j, value in enumerate(hint):
        model.add_hint(variables[j], value)
    assert model.validate() == ''
    model.export_to_file(str(OUT / 'model.pbtxt'))
    # Reconstruct filtering from per-candidate conflict lists, independently of the union above.
    neighbors = {i: set() for i in kept}
    for c in cliques:
        for i in c & kept:
            neighbors[i].update(c - {i})
    expected_ids = sorted(i for i in kept if pool[i]['placement']['part_id'] != 'insert'
                          and not(neighbors[i] & fixed))
    assert expected_ids == ids
    expected = cp_model_pb2.CpModelProto()
    for i in ids:
        v = expected.variables.add()
        v.name = f'p{i}'
        v.domain.extend([0, 1])
    projected = {tuple(sorted(local[i] for i in c if i in local)) for c in cliques}
    for row in sorted(r for r in projected if len(r) > 1):
        expected.constraints.add().at_most_one.literals.extend(row)
    for f, lo, hi in [('frame', 16, 18), ('bracket', 12, 12), ('cog', 15, 15)]:
        c = expected.constraints.add().linear
        c.vars.extend(families[f])
        c.coeffs.extend([1] * len(families[f]))
        c.domain.extend([lo, hi])
    expected.objective.vars.extend(families['frame'])
    expected.objective.coeffs.extend([-1] * len(families['frame']))
    expected.objective.scaling_factor = -1
    expected.solution_hint.vars.extend(range(len(ids)))
    expected.solution_hint.values.extend(hint)
    actual = text_format.Parse((OUT / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
    assert actual.SerializeToString(deterministic=True) == expected.SerializeToString(deterministic=True)
    for c in actual.constraints:
        if c.WhichOneof('constraint') == 'at_most_one':
            assert sum(hint[j] for j in c.at_most_one.literals) <= 1
        else:
            value = sum(co * hint[j] for j, co in zip(c.linear.vars, c.linear.coeffs))
            assert c.linear.domain[0] <= value <= c.linear.domain[1]
    write(OUT / 'mapping.json', {'candidates': ids, 'fixed_insert_candidates': sorted(fixed),
                               'complete_hint': hint})
    write(OUT / 'model-audit.json', {
        'all_model_fields_independently_reconstructed': True,
        'all_fixed_insert_filters_exact': True, 'complete_hint_exactly_feasible': True,
        'variables': len(ids), 'constraints': len(actual.constraints),
        'eligible_by_family': {f: len(v) for f, v in families.items()},
        'model_sha256': digest(OUT / 'model.pbtxt')})
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 20
    solver.parameters.num_search_workers = 8
    solver.parameters.random_seed = 0
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = False
    (OUT / 'parameters.pbtxt').write_text(str(solver.parameters), encoding='utf-8', newline='\n')
    records = []
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            chosen = sorted(fixed | {i for j, i in enumerate(ids) if self.value(model.get_int_var_from_proto_index(j))})
            count = sum(pool[i]['placement']['part_id'] == 'frame' for i in chosen)
            r = {'index': len(records), 'selected_indices': chosen, 'frames': count,
                 'seconds': self.wall_time, 'objective': self.objective_value, 'best_bound': self.best_objective_bound}
            assert count == r['objective']
            write(OUT / f"incumbent-{r['index']}.json", r)
            records.append(r)
            print(json.dumps({k: v for k, v in r.items() if k != 'selected_indices'}), flush=True)
    write(OUT / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'seconds_limit': 20})
    with (OUT / 'solver.log').open('x', encoding='utf-8', newline='\n') as log:
        solver.log_callback = lambda s: (log.write(s + '\n'), log.flush())
        start = time.perf_counter()
        status = solver.solve(model, Capture())
        seconds = time.perf_counter() - start
    feasible = status in [cp_model.FEASIBLE, cp_model.OPTIMAL]
    result = {'status': solver.status_name(status), 'seconds': seconds, 'incumbents': len(records),
              'feasible': feasible, 'response_stats': solver.response_stats(),
              'full_target_witness': False, 'native_margin_qualified': False}
    if feasible:
        chosen = sorted(fixed | {i for j, i in enumerate(ids) if solver.value(model.get_int_var_from_proto_index(j))})
        write(OUT / 'selected-indices.json', chosen)
        frames = sum(pool[i]['placement']['part_id'] == 'frame' for i in chosen)
        result.update(frames=frames, missing_frames=18 - frames,
                      best_bound=solver.best_objective_bound, full_inventory_candidate=frames == 18)
    else:
        assert not records
    write(OUT / 'result.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'response_stats'}), flush=True)

if __name__ == '__main__':
    main()
