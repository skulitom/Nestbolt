"""Read and hash evidence; retain one specifically bound failed JSON serialization."""
from pathlib import Path
from hashlib import sha256
import json, zipfile, re

ROOT = next(p for p in Path(__file__).resolve().parents if (p/'Cargo.toml').is_file() and (p/'docs/PLAN_V1_1.md').is_file())
NAME = 'h5-four-row-contact-phase-and-companion-spaces-20261107'
OUT = ROOT/'benchmarks/results'/NAME
load = lambda p: json.loads(p.read_bytes())
digest = lambda b: sha256(b).hexdigest()
failure = load(OUT/'serialization-failure.json')
assert failure['failed_partial_sha256'] == 'af1893f16edf62908ab2b97b356a9c7dcb28291a45606ef5c3c01bd3fc34ad72'
assert failure['failed_partial_bytes'] == failure['json_error_position'] == 28411
expected_failures = []

def check_json(data, name):
    try:
        json.loads(data)
        return 1
    except json.JSONDecodeError as exc:
        assert name.endswith('/h5-four-row-companion-spaces-20261107/queries/03.json') or name == 'h5-four-row-companion-spaces-20261107/queries/03.json', name
        assert digest(data) == failure['failed_partial_sha256'], name
        assert len(data) == failure['failed_partial_bytes'] and exc.pos == failure['json_error_position'], name
        expected_failures.append({'member': name, 'sha256': digest(data), 'bytes': len(data), 'json_error_position': exc.pos})
        return 0

blobs = {}; archives = {}; cache = {}; json_count = 0
manifest = load(OUT/'raw-manifest.json'); files = {r['path']: r for r in manifest['files']}
for a in manifest['archives']:
    p = OUT/a['path']; assert p.stat().st_size == a['bytes'] and digest(p.read_bytes()) == a['sha256']
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None
        for name in z.namelist():
            row = files[name]; data = z.read(name)
            assert row['archive'] == a['path'] and len(data) == row['bytes'] and digest(data) == row['sha256']
            blobs[name] = data
            if name.endswith('.json'): json_count += check_json(data, name)
assert set(blobs) == set(files)
for row in manifest['aliases']:
    data = blobs[row['canonical']]
    assert len(data) == row['bytes'] and digest(data) == row['sha256']
    blobs[row['path']] = data
external = load(OUT/'external-evidence.json'); parent_manifests = {}; parent_jsons = 0
for name, row in external.items():
    assert name not in blobs
    p = ROOT/row['manifest']; assert p.is_relative_to(ROOT) and p.is_file()
    if p not in parent_manifests:
        assert digest(p.read_bytes()) == row['manifest_sha256']
        m = load(p)
        parent_manifests[p] = (row['manifest_sha256'], {r['path']: r for r in m['files']}, {r['path']: r for r in m['archives']})
    h, entries, parts = parent_manifests[p]; assert h == row['manifest_sha256']; entry = entries[row['member']]
    assert entry['archive'] == row['archive'] and entry['bytes'] == row['bytes'] and entry['sha256'] == row['sha256']
    archive = p.parent/row['archive']
    if archive not in archives:
        part = parts[row['archive']]
        assert archive.stat().st_size == part['bytes'] and digest(archive.read_bytes()) == part['sha256']
        archives[archive] = zipfile.ZipFile(archive); assert archives[archive].testzip() is None
    key = (archive, row['member'])
    if key not in cache:
        data = archives[archive].read(row['member'])
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        cache[key] = data
        if row['member'].endswith('.json'): parent_jsons += check_json(data, row['member'])
    blobs[name] = cache[key]
assert len(expected_failures) == 1, expected_failures
bindings = load(OUT/'source-bindings.json')
for name, h in bindings.items(): assert digest(blobs['source-inputs/'+name]) == h == digest((ROOT/name).read_bytes())
links = []
for name in re.findall(r'\]\(([^)]+)\)', OUT.with_suffix('.md').read_text(encoding='utf-8')):
    if '://' not in name:
        target = (OUT.parent/name).resolve()
        if target != (OUT/'archive-checks.json').resolve(): assert target.is_file(), name
        links.append(name)
for p in OUT.glob('*.json'): load(p)
for z in archives.values(): z.close()
runtime = load(OUT/'runtime-bindings.json')
for name, h in runtime.items(): assert name.startswith('.cache/') and digest((ROOT/name).read_bytes()) == h
result = {'passed': True, 'pinned_runtime_files_verified': len(runtime), 'new_archive_parts': len(manifest['archives']), 'new_canonical_members': len(files), 'new_aliases': len(manifest['aliases']), 'external_references_verified': len(external), 'unique_parent_members_verified': len(cache), 'parent_archives_verified': len(archives), 'source_bindings_verified': len(bindings), 'new_json_files_parsed': json_count, 'parent_json_files_parsed': parent_jsons, 'expected_malformed_json_failures_preserved': expected_failures, 'local_report_links_verified': len(links), 'new_archive_bytes': sum(a['bytes'] for a in manifest['archives'])}
with (OUT/'archive-checks.json').open('x', encoding='utf-8', newline='\n') as f: json.dump(result, f, indent=2); f.write('\n')
for name in links: assert (OUT.parent/name).resolve().is_file(), name
assert load(OUT/'archive-checks.json') == result
print(result)
