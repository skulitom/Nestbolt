"""One source-derived gap-bisector phase for the fixed four-row construction."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,time,os,math
import numpy as np
from h5_screened_augmented_objective_20261107 import Objective,compile_model,problem_key
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
from h5_mixed_direct_pose_20261107 import source_rows
from h5_legacy64_source_readback import audit
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-four-row-contact-phase-20261107';BASE=ROOT/'output/h5-four-row-source-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';P=ROOT/'benchmarks/results/h5-runtime-profile-and-four-row-source-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
paths=[Path(__file__),JOB]+[A/n for n in ['library.json','initial-state.json','objective-identity.json']]+[B/'regions.json']+[P/n for n in ['next-step.json','archive-checks.json','four-row-source-controls.json','closed-problems.json']]+[BASE/n for n in ['plan.json','centers.json','source-state.json','checks.json']]+[ROOT/'output'/n for n in ['h5_screened_augmented_objective_20261107.py','h5_screened_weighted_model_20261107.py','h5_screened_boundary_gradient_20261107.py','h5_movable_roof_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py']]
prior=load(P/'four-row-source-controls.json')['complete_preparation_seconds_if_consumed'];assert prior==40.933948199497536
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Construct one common cog phase from the original boundary and exact original-source four-row pitches. Fold the two diagonal contact directions into the observed20-tooth period and bisect their nearest-to-zero representatives. Align the bisector of the first source tooth gap (outer vertices2and5) with that contact-direction bisector. The phase is a geometric representative, not a claimed optimum or symmetry equivalence: every actual original polygon pair is checked afterward. Preserve all15 centers and all non-cog coordinates, modes, weights and fixed33 source rows. No phase/offset/seed sweep, no optimizer and no reopening of a mathematical key. Compute fresh full scores and all66 source checks; preserve failure if any.','candidate_count':1,'tooth_pattern_points_per_tooth':4,'observed_tooth_count':20,'source_gap_vertex_indices':[2,5],'exact_symmetry_assumed':False,'optimized_or_validation_state_consumed':False,'complete_prior_preparation_seconds':prior,'charge_entire_new_process':True,'cap_seconds':22,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');family=lib['families']['cog'];vertices=np.asarray(family['original']);center=np.asarray(family['source_center']);relative=vertices-center
assert len(vertices)==80
angles=np.unwrap(np.arctan2(relative[:,1],relative[:,0]));radii=np.sqrt(np.sum(relative*relative,axis=1));period=math.tau/20
angular_error=max(abs(float(angles[4*k+j]-angles[j])-k*period) for k in range(20) for j in range(4));radial_error=max(abs(float(radii[4*k+j]-radii[j])) for k in range(20) for j in range(4));assert angular_error<1e-9 and radial_error<1e-8 and radii[1]>radii[0] and radii[2]>radii[3]
centers=load(BASE/'centers.json');dx=F(centers['exact_horizontal_pitch'])/2;dy=F(centers['exact_vertical_pitch']);directions=[math.atan2(float(dy),float(dx)),math.atan2(float(dy),-float(dx))];folded=[math.remainder(a,period) for a in directions];contact_axis=sum(folded)/2
gap_axis=float((angles[2]+angles[5])/2);phase=math.remainder(contact_axis-gap_axis,period)
write(OUT/'phase-derivation.json',{'source_vertices':vertices.tolist(),'source_center':center.tolist(),'source_radial_pattern_mm':radii[:4].tolist(),'source_angular_pattern_radians':angles[:4].tolist(),'observed_period_radians':period,'maximum_pattern_angular_error_radians':angular_error,'maximum_pattern_radial_error_mm':radial_error,'exact_symmetry_assumed':False,'exact_diagonal_dx':str(dx),'exact_diagonal_dy':str(dy),'diagonal_directions_radians':directions,'folded_contact_directions_radians':folded,'contact_bisector_radians':contact_axis,'source_gap_bisector_radians':gap_axis,'phase_radians':phase,'phase_degrees':math.degrees(phase),'phase_is_geometric_representative_not_optimum':True})
modes=initial['modes'].copy();weights=initial['pair_weights'];values=initial['values'].copy()
for saved in centers['centers']:
    owner=saved['owner'];assert owner in lib['angle_owners'];values[2*owner:2*owner+2]=[float(F(z)) for z in saved['exact_center']]
for k in range(66,81):values[k]=phase*lib['angle_scale_mm']
old=load(BASE/'source-state.json');assert values[:66]==old['values'][:66] and modes==old['modes'] and weights==old['pair_weights']
model=compile_model(lib,modes,values,weights,identity);assert model['initial']==values
key=problem_key(physical_key(lib,family_classes(lib),modes),weights,identity);closed=load(P/'closed-problems.json');assert len(closed)==25 and key==old['key'] and key in {r['key'] for r in closed}
write(OUT/'model.json',model);write(OUT/'source-state.json',{'modes':modes,'values':values,'pair_weights':weights,'key':key,'key_already_closed':True,'optimizer_allowed_for_this_key':False,'source_only':True,'optimized_ancestor_consumed':False});write(OUT/'closed-problems.json',closed)
value,g,details=Objective(model,regions,identity).evaluate(values,True);write(OUT/'fresh-objective.json',{'value':value,'gradient':g.tolist(),'details':details})
rows=source_rows(model,values);write(OUT/'source66.json',rows);job=load(JOB)
source=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));write(OUT/'source-checks.json',source)
partial=rows[:33]+[r for r in rows[33:] if r['part_id']=='cog'];assert len(partial)==48
write(OUT/'fixed33-and-cogs15.json',partial);pc=audit(job,partial,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in partial]);write(OUT/'fixed33-and-cogs15-checks.json',pc)
baseline=load(BASE/'checks.json');write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'candidate_count':1,'common_phase_degrees':math.degrees(phase),'exact_symmetry_assumed':False,'centers_unchanged':True,'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'source_valid66':source['valid'],'partial48_valid':pc['valid'],'partial48_pair_failures':pc['pair_failures'],'partial48_minimum_pair_gap_mm':pc['minimum_pair_gap_mm'],'fresh_objective_mm2':value,'prior_four_row_objective_mm2':baseline['fresh_objective_mm2'],'original_AW_objective_mm2':baseline['original_source_objective_mm2'],'improves_prior_four_row':value<baseline['fresh_objective_mm2']-1e-6,'improves_original_AW':value<baseline['original_source_objective_mm2']-1e-6,'key_already_closed':True,'optimizer_calls':0,'old_calls_resumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
