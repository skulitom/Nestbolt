"""Finite constructive companion-center regions around the valid source48 core."""
from pathlib import Path
from hashlib import sha256
import json,time,math,os
import numpy as np
import shapely
from shapely.geometry import Polygon,box,mapping
from shapely.affinity import translate
from h5_direct_pose_model_20261107 import transformed
from h5_original_overlap_gradient_v2_20261107 import pose_polygon
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-four-row-companion-spaces-v2-20261107';BASE=ROOT/'output/h5-four-row-contact-phase-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def components(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    if hasattr(g,'geoms'):return [p for x in g.geoms for p in components(x)]
    return []
def local(family,angle,mirror):
    cx,cy=family['source_center'];cs,sn=math.cos(angle),math.sin(angle);sign=-1 if mirror else 1
    return Polygon(transformed(family['clearance'],{'rotation_radians':angle,'mirrored':mirror,'translation':[-(sign*cx*cs-cy*sn),-(sign*cx*sn+cy*cs)]}))
OUT.mkdir();(OUT/'queries').mkdir();(OUT/'templates').mkdir();began=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'fixed33-and-cogs15-checks.json')['valid']
lib=load(A/'library.json');state=load(BASE/'source-state.json');core=load(BASE/'fixed33-and-cogs15.json');job=load(JOB);parts={p['id']:p for p in job['parts']};prior=load(BASE/'audit/checks.json')['complete_preparation_seconds']+load(ROOT/'output/h5-four-row-companion-spaces-process-20261107/process.json')['complete_seconds']
paths=[Path(__file__),ROOT/'output/prepare_h5_four_row_companion_spaces_20261107.py',ROOT/'output/h5-four-row-companion-spaces-serialization-failure-20261107.json',ROOT/'output/h5-four-row-companion-spaces-process-20261107/process.json',ROOT/'output/h5-four-row-companion-spaces-20261107/queries/03.json',JOB,A/'library.json',A/'initial-state.json',ROOT/'output/h5_direct_pose_model_20261107.py',ROOT/'output/h5_original_overlap_gradient_v2_20261107.py']+[BASE/n for n in ['plan.json','source-state.json','fixed33-and-cogs15.json','fixed33-and-cogs15-checks.json','audit/plan.json','audit/checks.json']]
queries=[(family,mode) for family in ['bracket','insert'] for mode in lib['family_modes'][family]]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Serialization-corrected v2; failed query03 write and full process cost retained. Only persisted validity scalar conversion changes. For all16 declared bracket/insert source center cells, form the nonconvex Minkowski forbidden region between the already verified clearance outlines and the15 fixed source cogs at the derived common phase. Decompose by constrained triangles, sum all Cartesian vertex differences and take convex hulls; union every triangle-pair hull. Reuse only identical family/source-mode template geometry, translated to each exact cog center. Subtract from the inherited frame-safe center rectangle. These are constructive regions for the existing conservative cells, not a necessary/global placement cover or infeasibility proof. Retain every component, representative point and exterior vertex; directly validate each unique proposed center against all33 same-sheet original core parts and stock. No companion-companion placement selection, optimizer or solver.','queries':16,'internal_seconds':10,'cap_seconds':12,'maximum_proposals_per_query':1000,'complete_prior_preparation_seconds':prior,'charge_entire_process_if_consumed':True,'geometric_exclusion_claimed':False,'optimizer_calls':0,'retry_permitted':False})
theta=state['values'][66]/lib['angle_scale_mm'];fixed=local(lib['families']['cog'],theta,False);fixed_triangles=list(shapely.constrained_delaunay_triangles(fixed).geoms);assert shapely.union_all(fixed_triangles).equals(fixed)
fixed_vertices=np.asarray([list(t.exterior.coords)[:-1] for t in fixed_triangles]);assert fixed_vertices.shape[1:]==(3,2)
core_geometries=np.asarray([pose_polygon(parts[r['part_id']],r['transform']) for r in core if r['sheet_id']=='sheet-0'],dtype=object);assert len(core_geometries)==33
cog_centers=[state['values'][2*i:2*i+2] for i in lib['angle_owners']];cache={};records=[];pending=[];proposal_total=0
for index,(family,mode) in enumerate(queries):
    if time.perf_counter()-began>=10:pending=list(range(index,len(queries)));break
    key=(family,mode['source_mode']);template_name=f'{family}-{mode["source_mode"]:02d}.json'
    if key not in cache:
        moving=local(lib['families'][family],mode['rotation_radians'],mode['mirrored'])
        moving_parts=[moving] if moving.equals(moving.convex_hull) else list(shapely.constrained_delaunay_triangles(moving).geoms);assert shapely.union_all(moving_parts).equals(moving)
        hulls=[]
        for piece in moving_parts:
            vertices=np.asarray(piece.exterior.coords)[:-1];points=(fixed_vertices[:,:,None,:]-vertices[None,None,:,:]).reshape((len(fixed_triangles),-1,2));hulls.extend(shapely.convex_hull(shapely.multipoints(points)).tolist())
        obstacle=shapely.union_all(hulls);assert obstacle.is_valid
        write(OUT/'templates'/template_name,{'family':family,'source_mode':mode['source_mode'],'fixed_clearance':mapping(fixed),'moving_clearance':mapping(moving),'fixed_triangles':[mapping(t) for t in fixed_triangles],'moving_parts':[mapping(t) for t in moving_parts],'convex_hulls':[mapping(t) for t in hulls],'forbidden':mapping(obstacle)})
        cache[key]=obstacle
    forbidden=shapely.union_all([translate(cache[key],xoff=x,yoff=y) for x,y in cog_centers]);(x0,x1),(y0,y1)=mode['center_bounds_mm'];domain=box(x0,y0,x1,y1);region=domain.difference(forbidden);pieces=components(region);points=[];seen=set()
    for piece in pieces:
        candidates=[tuple(piece.representative_point().coords[0])]+list(piece.exterior.coords)[:-1]
        for xy in candidates:
            if xy not in seen:points.append(xy);seen.add(xy)
    capped=len(points)>1000;proposals=points[:1000];validations=[]
    if proposals:
        source=parts[family];cx,cy=lib['families'][family]['source_center'];cs,sn=math.cos(mode['rotation_radians']),math.sin(mode['rotation_radians']);sign=-1 if mode['mirrored'] else 1
        posed=[pose_polygon(source,{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[x-(sign*cx*cs-cy*sn),y-(sign*cx*sn+cy*cs)]}) for x,y in proposals];array=np.asarray(posed,dtype=object)
        distances=shapely.distance(array[:,None],core_geometries[None,:]);intersects=shapely.intersects(array[:,None],core_geometries[None,:]);bounds=shapely.bounds(array);stock=lib['source_stocks']['sheet-0']
        for k,xy in enumerate(proposals):
            extras=[bounds[k,0]-stock[0],bounds[k,1]-stock[1],stock[2]-bounds[k,2],stock[3]-bounds[k,3]];minimum=float(np.min(distances[k]));valid=not bool(np.any(intersects[k])) and minimum>lib['required_pair_gap_mm'] and min(extras)>lib['stock_guard_mm']
            validations.append({'center_mm':list(xy),'minimum_original_gap_mm':minimum,'stock_extra_mm':extras,'valid_against_fixed_core':bool(valid)})
    write(OUT/'queries'/f'{index:02d}.json',{'index':index,'family':family,'mode':mode,'template':template_name,'cog_centers':cog_centers,'forbidden_union':mapping(forbidden),'source_center_domain':mapping(domain),'constructive_region':mapping(region),'polygon_components':len(pieces),'region_area_mm2':region.area,'all_unique_proposals':len(points),'proposal_cap_reached':capped,'proposals':validations})
    records.append({'index':index,'family':family,'mode':mode['mode'],'components':len(pieces),'area_mm2':region.area,'proposals':len(proposals),'valid_proposals':sum(r['valid_against_fixed_core'] for r in validations),'proposal_cap_reached':capped});proposal_total+=len(proposals)
write(OUT/'pending.json',pending);write(OUT/'summary.json',records)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'completed_queries':len(records),'pending_queries':len(pending),'unique_templates':len(cache),'proposals':proposal_total,'valid_proposals':sum(r['valid_proposals'] for r in records),'invalid_proposals':sum(r['proposals']-r['valid_proposals'] for r in records),'all_queries_and_proposals_complete':not pending and not any(r['proposal_cap_reached'] for r in records),'companion_counts_required':{'bracket':6,'insert':12},'simultaneous_companion_placement_checked':False,'geometric_exclusion_claimed':False,'source_valid66':False,'optimizer_calls':0,'solver_calls':0,'old_calls_resumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
