"""Independent phase derivation, scalar gradients and original cog edge distances."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,time,math
import numpy as np
from h5_bracket_augmented_reference_20261107 import Reference
from h5_bracket_augmented_readback_20261107 import verify
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-four-row-contact-phase-20261107';OUT=BASE/'audit';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';OLD=ROOT/'output/h5-four-row-source-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b):return a[...,0]*b[...,1]-a[...,1]*b[...,0]
def inside(p,vertices):
    x,y=p;result=False
    for a,b in zip(vertices,np.roll(vertices,-1,axis=0)):
        if (a[1]>y)!=(b[1]>y) and x<a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]):result=not result
    return result
def separation(a,b):
    a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float);aa=np.roll(a,-1,axis=0);bb=np.roll(b,-1,axis=0);u=aa-a;v=bb-b
    o1=cross(u[:,None,:],b[None,:,:]-a[:,None,:]);o2=cross(u[:,None,:],bb[None,:,:]-a[:,None,:]);o3=cross(v[None,:,:],a[:,None,:]-b[None,:,:]);o4=cross(v[None,:,:],aa[:,None,:]-b[None,:,:])
    boxes=np.all(np.maximum(np.minimum(a,aa)[:,None,:],np.minimum(b,bb)[None,:,:])<=np.minimum(np.maximum(a,aa)[:,None,:],np.maximum(b,bb)[None,:,:]),axis=2)
    intersects=bool(np.any((o1*o2<=0)&(o3*o4<=0)&boxes))
    contained=inside(a[0],b) or inside(b[0],a)
    def point_edges(p,start,delta):
        den=np.sum(delta*delta,axis=1);t=np.sum((p[:,None,:]-start[None,:,:])*delta[None,:,:],axis=2)/np.where(den>0,den,1.)[None,:];t=np.clip(t,0.,1.)
        residual=p[:,None,:]-(start[None,:,:]+t[:,:,None]*delta[None,:,:]);return float(np.min(np.sum(residual*residual,axis=2)))
    distance=math.sqrt(min(point_edges(a,b,v),point_edges(b,a,u))) if not intersects and not contained else 0.
    return {'distance_mm':distance,'edge_intersection':intersects,'containment':bool(contained),'edge_pairs':len(a)*len(b)}
OUT.mkdir();start=time.perf_counter();paths=[Path(__file__),JOB]+[A/n for n in ['library.json','initial-state.json','objective-identity.json']]+[B/'regions.json',OLD/'source-state.json',OLD/'centers.json',ROOT/'output/h5-four-row-contact-phase-preparation-process-20261107/process.json']+[p for p in BASE.iterdir() if p.is_file()]
bindings={p.relative_to(ROOT).as_posix():digest(p) for p in paths}
for name,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h;bindings[name]=h
write(OUT/'plan.json',{'inputs':bindings,'method':'Recompute the source gap bisector by summing normalized vertex vectors rather than averaging their angles; verify the two folded diagonal directions have zero bisector. Read back every unchanged center/non-cog field and all15 new angle coordinates. Reconstruct all66 original poses and all81 scalar gradients independently. Additionally compare all105 original cog-pair gaps using direct segment-intersection, ray-containment and endpoint-to-segment projection formulas without GEOS distance/intersection. Six analytic geometry controls precede the pair checks. This is floating-point validation with positive gap margins, not an exact all-angle proof or a complete packing witness.','optimizer_calls':0,'retry_permitted':False})
sq=[[0,0],[2,0],[2,2],[0,2]];cases=[('separated',sq,[[3,0],[5,0],[5,2],[3,2]],1.),('overlap',sq,[[1,1],[3,1],[3,3],[1,3]],0.),('contained',sq,[[.5,.5],[1.5,.5],[1.5,1.5],[.5,1.5]],0.),('edge_touch',sq,[[2,0],[4,0],[4,2],[2,2]],0.),('corner',sq,[[2,2],[4,2],[4,4],[2,4]],0.),('zero_edge',[[0,0]]+sq,[[3,0],[5,0],[5,2],[3,2]],1.)];fixtures=[]
for name,a,b,expected in cases:
    result=separation(a,b);assert abs(result['distance_mm']-expected)<1e-12;fixtures.append({'case':name,'expected_mm':expected,**result})
write(OUT/'distance-fixtures.json',fixtures)
lib=load(A/'library.json');initial=load(A/'initial-state.json');state=load(BASE/'source-state.json');old=load(OLD/'source-state.json');model=load(BASE/'model.json');derived=load(BASE/'phase-derivation.json');v=np.asarray(lib['families']['cog']['original']);c=np.asarray(lib['families']['cog']['source_center']);directions=[]
for k in [2,5]:q=v[k]-c;directions.append(q/math.hypot(*q))
bisector=directions[0]+directions[1];gap=math.atan2(bisector[1],bisector[0]);phase=math.tau/20-gap
assert abs(phase-derived['phase_radians'])<1e-15 and abs(sum(derived['folded_contact_directions_radians']))<1e-15
assert state['values'][:66]==old['values'][:66] and state['modes']==old['modes']==initial['modes'] and state['pair_weights']==initial['pair_weights']
assert all(abs(x/lib['angle_scale_mm']-phase)<1e-15 for x in state['values'][66:])
assert verify(model,lib,state['modes'],state['values'],state['pair_weights'],load(A/'objective-identity.json'))
fresh=load(BASE/'fresh-objective.json');value,gradient,detail=Reference(lib).evaluate(model,state['values'],True,fresh['details']['auxiliary_terms']);gradient_error=float(np.max(np.abs(gradient-np.asarray(fresh['gradient']))));assert abs(value-fresh['value'])<1e-6 and gradient_error<1e-6
job=load(JOB);rows=load(BASE/'source66.json');checked=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));assert checked==load(BASE/'source-checks.json') and checked['stock_failures']==0
assert rows[:33]==lib['fixed_source_rows']
for owner,row in zip(model['owners'],rows[33:]):
    i=owner['owner'];theta=state['values'][owner['angle_coordinate']]/owner['angle_scale_mm'] if owner['angle_coordinate'] is not None else owner['rotation_radians'];cs,sn=math.cos(theta),math.sin(theta);sign=-1 if owner['mirrored'] else 1;px,py=owner['source_center']
    assert row['part_id']==owner['identity'][0] and row['copy_index']==owner['identity'][1] and row['sheet_id']=='sheet-0' and row['transform']=={'rotation_radians':theta,'mirrored':owner['mirrored'],'translation':[state['values'][2*i]-(sign*px*cs-py*sn),state['values'][2*i+1]-(sign*px*sn+py*cs)]}
partial=load(BASE/'fixed33-and-cogs15.json');assert partial==rows[:33]+[r for r in rows[33:] if r['part_id']=='cog'];pc=audit(job,partial,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in partial]);assert pc==load(BASE/'fixed33-and-cogs15-checks.json') and pc['valid']
part=next(p for p in job['parts'] if p['id']=='cog');vertices=part['geometry'][0]['outer'];polygons={}
for row in partial:
    if row['part_id']!='cog':continue
    t=row['transform'];cs,sn=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation'];polygons[row['copy_index']]=np.asarray([[cs*x-sn*y+tx,sn*x+cs*y+ty] for x,y in vertices])
oracle={tuple(k[1] for k in r['keys']):r for r in pc['pairs'] if all(k[0]=='cog' for k in r['keys'])};controls=[]
for i,j in combinations(sorted(polygons),2):
    result=separation(polygons[i],polygons[j]);error=abs(result['distance_mm']-oracle[i,j]['distance_mm']);assert not result['edge_intersection'] and not result['containment'] and result['distance_mm']>lib['required_pair_gap_mm']+1e-7 and error<1e-8
    controls.append({'copies':[i,j],**result,'GEOS_distance_mm':oracle[i,j]['distance_mm'],'difference_mm':error})
write(OUT/'direct-cog-pair-controls.json',controls)
closed=load(BASE/'closed-problems.json');assert len(closed)==25 and state['key']==old['key'] and state['key'] in {r['key'] for r in closed} and not state['optimizer_allowed_for_this_key']
process=load(ROOT/'output/h5-four-row-contact-phase-preparation-process-20261107/process.json');assert process['passed'] and process['closed'] and process['job']['active_processes']==0
charge=load(BASE/'plan.json')['complete_prior_preparation_seconds']+process['complete_seconds'];write(OUT/'source-bindings.json',bindings)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'independent_phase_degrees':math.degrees(phase),'phase_derivation_error_radians':abs(phase-derived['phase_radians']),'all66_originals_verified':66,'source_same_sheet_pairs':checked['same_sheet_pairs'],'source_stock_edges':checked['stock_edges'],'source_pair_failures':checked['pair_failures'],'source_stock_failures':0,'source_valid66':checked['valid'],'valid_partial_originals':48,'partial_same_sheet_pairs':pc['same_sheet_pairs'],'partial_stock_edges':pc['stock_edges'],'partial_minimum_gap_mm':pc['minimum_pair_gap_mm'],'direct_cog_pairs_verified':105,'direct_edge_pairs_checked':sum(r['edge_pairs'] for r in controls),'direct_distance_fixtures':6,'minimum_cog_gap_mm':min(r['distance_mm'] for r in controls),'maximum_direct_distance_error_mm':max(r['difference_mm'] for r in controls),'scalar_gradient_coordinates':81,'maximum_scalar_gradient_error':gradient_error,'complete_preparation_seconds':charge,'new_source_preparation_seconds':process['complete_seconds'],'closed_problem_keys':25,'current_key_already_closed':True,'optimizer_calls':0,'old_calls_resumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
