"""Preserve a valid source48 core and the rejected conservative companion construction."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-four-row-contact-phase-and-companion-spaces-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-four-row-contact-phase-20261107';D=ROOT/'output/h5-four-row-companion-spaces-v2-20261107';F=D/'audit'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-runtime-profile-and-four-row-source-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['maximum_brackets_in_current_region_construction']==3 and front['original_proposals_verified']==227 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-four-row-companion-spaces-20261107',ROOT/'output/h5-runtime-four-row-main-sync-20261107']+[ROOT/'output'/f'h5-{stage}-process-20261107' for stage in ['four-row-contact-phase-preparation','four-row-contact-phase-audit','four-row-companion-spaces','four-row-companion-spaces-v2','four-row-companion-spaces-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*four_row*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_four_row_phase_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json','runtime-cost-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(ROOT/'output/h5-screened-source-preflight-20261107/runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(BASE/'plan.json','phase-source-plan.json'),(BASE/'phase-derivation.json','phase-derivation.json'),(BASE/'checks.json','phase-preparation.json'),(BASE/'audit/checks.json','phase-audit.json'),(BASE/'audit/distance-fixtures.json','distance-fixtures.json'),(BASE/'audit/direct-cog-pair-controls.json','direct-cog-pair-controls.json'),(BASE/'source-state.json','phase-source-state.json'),(BASE/'source-checks.json','full66-source-checks.json'),(BASE/'fixed33-and-cogs15-checks.json','valid48-source-checks.json'),(BASE/'fixed33-and-cogs15.json','valid48-source.json'),(BASE/'closed-problems.json','closed-problems.json'),(D/'plan.json','companion-space-plan.json'),(D/'checks.json','companion-preparation.json'),(D/'summary.json','companion-space-summary.json'),(F/'checks.json','companion-audit.json'),(F/'bracket-envelope-capacity.json','bracket-envelope-capacity.json'),(F/'original-proposal-controls.json','original-proposal-controls.json'),(ROOT/'output/h5-four-row-companion-spaces-serialization-failure-20261107.json','serialization-failure.json'),(ROOT/'output/h5-runtime-four-row-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for stage in ['four-row-contact-phase-preparation','four-row-contact-phase-audit','four-row-companion-spaces','four-row-companion-spaces-v2','four-row-companion-spaces-audit']:copies.append((ROOT/'output'/f'h5-{stage}-process-20261107/process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
phase=load(OUT/'phase-audit.json');prepared=load(OUT/'phase-preparation.json');capacity=load(OUT/'bracket-envelope-capacity.json');failure=load(OUT/'serialization-failure.json');receipt=load(OUT/'prior-main-push-receipt.json');assert phase['passed'] and phase['valid_partial_originals']==48 and capacity['maximum_brackets_in_this_region_construction']==3
ci=json.loads(subprocess.check_output(['gh','run','view','42399328273','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']==receipt['new_main']=='bf239548117594ce78bae7b588fc1e8508ffc74e'
write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'checks.json',{'passed':True,**archive,'source_bindings':len(bindings),'external_evidence_references':len(external),'pinned_runtime_files':len(runtime),'valid_partial_originals':48,'full66_pair_failures':29,'direct_cog_pairs_verified':105,'original_companion_proposals_verified':227,'maximum_brackets_in_current_region_construction':3,'required_brackets':6,'serialization_failure_preserved':True,'complete_source_preparation_seconds_if_consumed':front['complete_preparation_seconds_if_consumed'],'optimizer_calls':0,'H5_complete':False})
write(OUT/'next-step.json',{'status':'necessary_source_region_review_before_fixed_core_exclusion',
    'finding':'One source-derived common phase at about2.25degrees resolves all10 diagonal cog contacts. The actual original48-part core passes633 pair checks, and all105 cog pairs also pass an independent direct edge-distance implementation. The full66 state remains invalid with29 failed pairs. All16 conservative companion-center cells are constructed and227 individual poses pass original49-part checks. Their possible bracket occupancy lies in a156256.130137mm2 rectangle, allowing at most3 brackets versus6 required. This rejects only this conservative region construction, not unrestricted placements around the fixed core.',
    'proposal':'Compare the constructive regions with a source-necessary outer cover for all permitted original bracket orientations against the original fixed core and stock. Use only certified inner collision exclusions if claiming a necessary cover; padded clearance obstacles and conservative safe center cells cannot prove absence of other legal poses. Assess whether the original-bracket occupied-area bound persists. Prove the scope and every cover/exclusion before ruling out the fixed core, or construct any newly uncovered source-safe placements before further selection. No solver should run on the already capacity-infeasible conservative regions.',
    'requirements':['Preserve all66 identities, fixed48 geometry, original stock/clearance requirements, all25 closed mathematical keys and every failed result. No continuous-angle or coordinate change alone reopens a key.','The source-only phase preparation totals41.54094439954497s. Consuming both the failed0.5361506000626832s region preparation and corrected0.9743246000725776s process gives43.05141959968023s before further construction. Do not discard failed preparation or validation failures.','The current regions are sufficient construction domains, not a complete necessary cover. No statement here excludes arbitrary geometry or any of440 whole-job allocations.','Full66 source/native/material validity, production integration/parity and the original H5 matrix still apply. No new optimizer/search contract is prepared.'],
    'closed_problem_keys':25,'valid_partial_originals':48,'full_source_valid':False,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'complete_preparation_seconds_if_consumed':front['complete_preparation_seconds_if_consumed'],'optimizer_calls':0,'H5_complete':False})
report=f'''# Four-row contact phase and companion spaces — 2026-11-07

A source-derived cog phase removes all ten diagonal contacts and gives a valid
**48-part core**. The complete 66-part arrangement still fails **29 pairs**.
The conservative regions generated for the remaining companions can contain
at most **three of the six required brackets**, so this particular construction
is rejected without a solver call. This is not an unrestricted packing exclusion.
H2/H5 remain open at **60% completed milestone weight**.

[The source derivation]({NAME}/phase-derivation.json) aligns a tooth-gap bisector
with the two diagonal contact directions of the existing 4/4/4/3 centers. It
produces one common phase, **{prepared['common_phase_degrees']:.12f}°**, without an
angle/offset/seed sweep. All centers, non-cog coordinates, modes, weights and fixed
33 rows remain unchanged. The observed 20-tooth pattern is slightly rounded;
no exact rotational symmetry or optimal phase is assumed.

[Independent phase readback]({NAME}/phase-audit.json) derives the gap bisector
using normalized vertex-vector sums and checks all 81 scalar gradients, with
maximum error **{phase['maximum_scalar_gradient_error']:.3e}**. It reconstructs
all 66 original parts and validates the [48-part core]({NAME}/valid48-source.json)
with **633 same-sheet pairs and 192 stock edges**. Its minimum pair gap is
**{phase['partial_minimum_gap_mm']:.12f} mm**, above the retained source requirement.
[Original core checks]({NAME}/valid48-source-checks.json) preserve every pair.

A separate implementation uses segment intersection, ray containment and
endpoint projection, without GEOS distance/intersection, for all **105 cog pairs**
and **672,000 edge pairs**. [Six analytic controls]({NAME}/distance-fixtures.json)
pass. [Direct pair checks]({NAME}/direct-cog-pair-controls.json) give minimum cog
gap **{phase['minimum_cog_gap_mm']:.12f} mm**, with maximum difference from GEOS
**{phase['maximum_direct_distance_error_mm']:.3e} mm**. This is floating-point
validation with positive margins, not an exact all-angle theorem.

[Full66 source checks]({NAME}/full66-source-checks.json) have zero stock failures
but 29 pair failures. The fresh objective is **{prepared['fresh_objective_mm2']:.6f} mm²**,
below the failed four-row state's **{prepared['prior_four_row_objective_mm2']:.6f} mm²**
but above original A/W's **{prepared['original_AW_objective_mm2']:.6f} mm²**. The
[mathematical key]({NAME}/phase-source-state.json) was already closed; changing
continuous angles does not permit another optimizer call.

[Companion construction]({NAME}/companion-space-plan.json) covers all 16 declared
bracket/insert center cells. It forms nonconvex forbidden geometry from the
verified clearance outlines via all Cartesian convex-piece vertex differences,
then translates each template to the 15 cogs. The inherited center rectangles
are safe around the fixed frames. Subtracting the forbidden unions leaves
**18 polygon components**. These conservative safe regions are not a complete
necessary cover of all possible original placements.

[Independent geometry readback]({NAME}/companion-audit.json) verifies **12 templates,
5,928 convex Minkowski hulls and all 16 regions**. All **227 representative/vertex
proposals** pass independent original **49-part checks**, including the full
48-part core: [proposal controls]({NAME}/original-proposal-controls.json).
Individual compatibility does not establish simultaneous placement of six
brackets and twelve inserts. [The complete census]({NAME}/companion-space-summary.json)
retains zero-region orientations and every generated proposal.

[The exact envelope bound]({NAME}/bracket-envelope-capacity.json) places every
possible original bracket in these recorded constructive regions inside
**[{capacity['combined_bounds_mm'][0]:.6f}, {capacity['combined_bounds_mm'][1]:.6f}]
to [{capacity['combined_bounds_mm'][2]:.6f}, {capacity['combined_bounds_mm'][3]:.6f}] mm**.
Exact rational interval sums include 1e-6 mm outward numerical padding. Envelope
area is **{capacity['envelope_area_mm2']:.6f} mm²**; each bracket requires at least
**39,999 mm²**, a conservative bound below its original 40,000 mm² area with an
explicit rounding allowance. Four brackets already exceed the envelope, so at
most three fit. Six are required. No selection or optimizer is justified within
these regions. The bound does not exclude source-safe positions outside them.

The first region process [fails during serialization]({NAME}/four-row-companion-spaces-process.json)
because a NumPy boolean reaches the JSON writer. Complete queries 00–02, the
28,411-byte truncated query03, templates and stderr are preserved. The
[failure record]({NAME}/serialization-failure.json) binds the exact malformed bytes.
A separate version converts only the persisted validity flag to a built-in bool;
[its process]({NAME}/four-row-companion-spaces-v2-process.json) completes all queries.
The initial correction command's wrong assumption about the failed query number
is also recorded; no geometry process was launched by that command.

[Phase preparation]({NAME}/four-row-contact-phase-preparation-process.json) costs
**{phase['new_source_preparation_seconds']:.6f} s**, for a retained lineage of
**{phase['complete_preparation_seconds']:.6f} s**. Consuming the failed and corrected
region preparations adds **0.536151 + 0.974325 s**, giving
**{front['complete_preparation_seconds_if_consumed']:.6f} s** before further work.
[Phase audit]({NAME}/four-row-contact-phase-audit-process.json) and
[region audit]({NAME}/four-row-companion-spaces-audit-process.json) close under the
same CCD1/one-thread/2 GiB controls. Every process is terminal; no search ran.

[Next]({NAME}/next-step.json), compare these conservative regions with a certified
source-necessary outer cover before deciding whether the fixed core itself is
excluded. All [25 mathematical keys]({NAME}/closed-problems.json) remain closed;
four earlier arrangements and all 440 whole-job allocations remain unresolved.
Full66/native/material checks, parity and the original H5 matrix are still needed.

[Three preceding checkpoints reached main bf239548 normally]({NAME}/prior-main-push-receipt.json)
after all six prior checks passed, preserving all 52 protected files. Fresh main
CI has {success} passed / {live} live jobs in [this snapshot]({NAME}/main-ci-at-review.json).
Product code, README and releases are unchanged.

[Archive checks]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the evidence, including the
expected malformed JSON failure.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 four-row contact phase:** [independent source/contact/space audits]({{link}}) verify one source-derived 2.25-degree phase, resolving all ten cog contacts and producing a valid 48-part core. All 105 cog pairs and 672,000 edge pairs pass an independent direct-distance check; minimum cog gap is 1.381413 mm. Full66 still fails 29 pairs. All 16 conservative companion cells, 12 templates and 5,928 hulls replay; 227 individual poses pass original49 checks. An exact 156256.130137 mm2 envelope allows at most three required brackets in these regions, below six needed. This construction is rejected, without excluding unrestricted source placements. The failed NumPy-boolean serialization, truncated query03 and corrected version are retained; consumed source preparation totals 43.051420 s. No optimizer runs and all 25 keys stay closed. Next establish a source-necessary outer cover before any fixed-core exclusion. Four arrangements and 440 allocations remain; H2/H5 stay at 60%. Three previous checkpoints reached main bf239548 after all six prior checks passed; new CI has {success} passed / {live} live jobs.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [four-row contact phase and companion spaces](../benchmarks/results/{NAME}.md).
A source-derived 2.25-degree phase removes all ten cog contacts and gives a
valid 48-part core. All 105 cog pairs independently pass; the full66 state still
fails 29 pairs. All 16 conservative companion cells replay and 227 individual
poses pass original49 checks, but an exact occupied-area bound allows at most
three brackets within those regions, versus six required. That construction
is rejected; unrestricted source placements are not excluded. Next establish
a necessary outer cover before a fixed-core exclusion. The serialization
failure and correction are preserved; consumed preparation totals 43.051420 s.
No optimizer runs; all 25 keys stay closed. Four earlier arrangements and 440
whole allocations remain. H2/H5 stay open at 60%. Three preceding checkpoints
reached main bf239548 normally after all six prior checks passed. Its fresh CI
has {success} passed / {live} live jobs at review. Product and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
