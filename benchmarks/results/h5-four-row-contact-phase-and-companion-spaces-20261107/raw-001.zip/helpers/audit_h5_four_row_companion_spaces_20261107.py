"""Read back all constructive regions and bound their bracket capacity."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,time,math
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,shape,box
from shapely.affinity import translate
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-four-row-companion-spaces-v2-20261107';OUT=BASE/'audit';PHASE=ROOT/'output/h5-four-row-contact-phase-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';FAILURE=ROOT/'output/h5-four-row-companion-spaces-serialization-failure-20261107.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def polys(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    return [p for child in g.geoms for p in polys(child)] if hasattr(g,'geoms') else []
def vertices(g):return [p for poly in polys(g) for ring in [poly.exterior,*poly.interiors] for p in list(ring.coords)[:-1]]
OUT.mkdir();began=time.perf_counter();lib=load(A/'library.json');state=load(PHASE/'source-state.json');core=load(PHASE/'fixed33-and-cogs15.json');job=load(JOB);sourceparts={p['id']:p for p in job['parts']};plan=load(BASE/'plan.json');prepared=load(BASE/'checks.json')
assert load(PHASE/'audit/checks.json')['passed'] and prepared['all_queries_and_proposals_complete'] and not load(BASE/'pending.json')
paths=[Path(__file__),JOB,A/'library.json',PHASE/'source-state.json',PHASE/'fixed33-and-cogs15.json',PHASE/'audit/checks.json',FAILURE]+[p for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents]+[ROOT/'output'/f'h5-four-row-companion-spaces{suffix}-process-20261107/process.json' for suffix in ['', '-v2']]
bindings={p.relative_to(ROOT).as_posix():digest(p) for p in paths}
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h;bindings[name]=h
failed=load(FAILURE);raw=(ROOT/failed['failed_partial_json']).read_bytes();assert sha256(raw).hexdigest()==failed['failed_partial_sha256'] and len(raw)==failed['failed_partial_bytes']
try:json.loads(raw)
except json.JSONDecodeError as e:assert e.pos==failed['json_error_position']
else:raise AssertionError('Expected retained failed serialization')
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently rebuild every Cartesian convex-piece Minkowski hull and complete translated union for all16 constructive center cells. Reconstruct and compare every region, component and representative/vertex proposal. Independently recheck every proposed original part with the48-part core using the original-source validator. Preserve and hash the failed truncated query03 and both process costs. Bound every possible original bracket in the declared constructive regions by exact interval sums of region-coordinate extrema and local source-vertex extrema, plus1e-6mm outward numerical padding. Derive a conservative39999mm2 source bracket area lower bound and compare with the exact envelope area. This limits this conservative region construction only; it does not exclude other source-safe placements outside these regions, moving cogs or whole-job allocations.','optimizer_calls':0,'retry_permitted':False})
templates={};hulls_checked=0
for p in sorted((BASE/'templates').glob('*.json')):
    t=load(p);fixed=shape(t['fixed_clearance']);moving=shape(t['moving_clearance']);fp=[shape(x) for x in t['fixed_triangles']];mp=[shape(x) for x in t['moving_parts']]
    assert shapely.union_all(fp).equals(fixed) and shapely.union_all(mp).equals(moving) and all(g.equals(g.convex_hull) for g in fp+mp)
    # Producer loops moving first, then fixed. Compare every hull in that order.
    reconstructed=[MultiPoint([(x-u,y-v) for x,y in list(a.exterior.coords)[:-1] for u,v in list(b.exterior.coords)[:-1]]).convex_hull for b in mp for a in fp]
    assert len(reconstructed)==len(t['convex_hulls'])
    for a,b in zip(reconstructed,t['convex_hulls']):assert a.equals_exact(shape(b),0.) or a.equals(shape(b))
    obstacle=shapely.union_all(reconstructed);assert obstacle.equals(shape(t['forbidden']));templates[p.name]=obstacle;hulls_checked+=len(reconstructed)
queries=[(f,m) for f in ['bracket','insert'] for m in lib['family_modes'][f]];source_checks=[];envelopes=[];component_count=0;proposal_count=0
for index,(family,mode) in enumerate(queries):
    q=load(BASE/'queries'/f'{index:02d}.json');assert q['index']==index and q['family']==family and q['mode']==mode and q['cog_centers']==[state['values'][2*i:2*i+2] for i in lib['angle_owners']]
    forbidden=shapely.union_all([translate(templates[q['template']],xoff=x,yoff=y) for x,y in q['cog_centers']]);assert forbidden.equals(shape(q['forbidden_union']))
    (x0,x1),(y0,y1)=mode['center_bounds_mm'];domain=box(x0,y0,x1,y1);region=domain.difference(forbidden);assert region.equals(shape(q['constructive_region'])) and domain.equals(shape(q['source_center_domain']))
    pieces=polys(region);assert len(pieces)==q['polygon_components'];component_count+=len(pieces);points=[];seen=set()
    for piece in pieces:
        for xy in [tuple(piece.representative_point().coords[0])]+list(piece.exterior.coords)[:-1]:
            if xy not in seen:seen.add(xy);points.append(xy)
    assert len(points)==q['all_unique_proposals']==len(q['proposals']) and not q['proposal_cap_reached'] and [list(p) for p in points]==[r['center_mm'] for r in q['proposals']]
    cx,cy=lib['families'][family]['source_center'];cs,sn=math.cos(mode['rotation_radians']),math.sin(mode['rotation_radians']);sgn=-1 if mode['mirrored'] else 1;local=[(sgn*x*cs-y*sn-(sgn*cx*cs-cy*sn),sgn*x*sn+y*cs-(sgn*cx*sn+cy*cs)) for x,y in sourceparts[family]['geometry'][0]['outer']]
    if family=='bracket' and pieces:
        coords=vertices(region);lo=[min(F(p[k]) for p in coords)+min(F(v[k]) for v in local)-F(1,10**6) for k in [0,1]];hi=[max(F(p[k]) for p in coords)+max(F(v[k]) for v in local)+F(1,10**6) for k in [0,1]]
        envelopes.append({'query':index,'mode':mode['mode'],'exact_lower':list(map(str,lo)),'exact_upper':list(map(str,hi)),'bounds_mm':[float(x) for x in lo+hi]})
    for rec in q['proposals']:
        x,y=rec['center_mm'];row={'part_id':family,'copy_index':6 if family=='bracket' else 0,'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[x-(sgn*cx*cs-cy*sn),y-(sgn*cx*sn+cy*cs)]}}
        allrows=core+[row];check=audit(job,allrows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in allrows]);assert check['valid']==rec['valid_against_fixed_core'] and check['valid'] and check['originals']==49
        related=[r for r in check['pairs'] if [family,row['copy_index']] in r['keys']];assert len(related)==33;minimum=min(r['distance_mm'] for r in related);error=abs(minimum-rec['minimum_original_gap_mm']);assert error<1e-8
        source_checks.append({'query':index,'proposal':proposal_count,'minimum_candidate_gap_mm':minimum,'gap_error_mm':error,'source_originals':49,'source_pair_failures':0,'stock_failures':0});proposal_count+=1
assert proposal_count==227 and len(envelopes)==2
lo=[min(F(r['exact_lower'][k]) for r in envelopes) for k in [0,1]];hi=[max(F(r['exact_upper'][k]) for r in envelopes) for k in [0,1]];envelope_area=(hi[0]-lo[0])*(hi[1]-lo[1]);original=sourceparts['bracket']['geometry'][0]['outer'];area=abs(sum(F(a[0])*F(b[1])-F(a[1])*F(b[0]) for a,b in zip(original,original[1:]+original[:1])))/2;assert area==40000
# All source vertices and center coordinates are below4096mm in magnitude.
# The transform has fewer than64 rounded arithmetic operations, with intermediates
# below8192mm. This deliberately loose forward bound is below1e-6mm.
rounding_bound=F(64*8192,2**53-64);padding=F(1,10**6);assert rounding_bound<padding
# A per-coordinate vertex perturbation <=padding changes the absolute shoelace
# area by at most N*(2*4096*padding+padding^2). The rotation determinant differs
# from1 by less than2^-40 for every recorded mode; all are explicitly checked.
assert all(abs(F(math.cos(m['rotation_radians']))**2+F(math.sin(m['rotation_radians']))**2-1)<F(1,2**40) for f,m in queries if f=='bracket')
area_error=len(original)*(2*4096*padding+padding*padding)+area/F(2**40);lower=F(39999);assert area-area_error>lower
capacity=int(envelope_area//lower);assert capacity<6
write(OUT/'bracket-envelope-capacity.json',{'passed':True,'scope':'Only placements whose centers lie in the recorded constructive regions and modes. These conservative regions do not cover every source-feasible placement.','component_envelopes':envelopes,'exact_combined_lower':list(map(str,lo)),'exact_combined_upper':list(map(str,hi)),'combined_bounds_mm':list(map(float,lo+hi)),'exact_envelope_area_mm2':str(envelope_area),'envelope_area_mm2':float(envelope_area),'original_bracket_area_mm2':40000,'conservative_area_lower_bound_mm2':39999,'maximum_brackets_in_this_region_construction':capacity,'required_brackets':6,'complete_current_region_construction_possible':False,'rounding_bound_mm':float(rounding_bound),'padding_mm':1e-6,'source_area_error_bound_mm2':float(area_error),'no_unrestricted_geometry_exclusion':True,'no_whole_allocation_exclusion':True})
write(OUT/'original-proposal-controls.json',source_checks)
old=load(ROOT/'output/h5-four-row-companion-spaces-process-20261107/process.json');new=load(ROOT/'output/h5-four-row-companion-spaces-v2-process-20261107/process.json');assert old['closed'] and not old['passed'] and new['closed'] and new['passed']
charge=load(PHASE/'audit/checks.json')['complete_preparation_seconds']+old['complete_seconds']+new['complete_seconds'];assert plan['complete_prior_preparation_seconds']==load(PHASE/'audit/checks.json')['complete_preparation_seconds']+old['complete_seconds']
write(OUT/'source-bindings.json',bindings);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'templates_verified':len(templates),'convex_minkowski_hulls_verified':hulls_checked,'center_queries_verified':16,'polygon_components_verified':component_count,'original_proposals_verified':227,'valid_49_part_source_checks':227,'maximum_brackets_in_current_region_construction':capacity,'required_brackets':6,'current_region_construction_rejected':True,'failed_serialization_preserved':True,'complete_preparation_seconds_if_consumed':charge,'source_valid66':False,'optimizer_calls':0,'solver_calls':0,'old_calls_resumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
