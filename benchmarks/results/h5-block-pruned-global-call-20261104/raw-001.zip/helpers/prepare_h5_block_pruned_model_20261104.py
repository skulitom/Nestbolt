from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def write(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def replace_common(s):return s.replace('h5-first55-fine-components-model-20261029','h5-first55-block-pruned-model-20261104').replace('h5-first55-direct-fine-filtered-components-20261029','h5-first55-block-count-model-inputs-20261104').replace('all18-filtered-bounds.json','all14-filtered-bounds.json')
extra=";ORIGINAL_COUNT=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029';FINAL_COUNT=ROOT/'output/h5-first55-direct-smaller-block-filtered-20261104';PAIR_BOUND=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';FOUR_BOUND=ROOT/'output/h5-shared-four-direct-difference-bound-20261104';THREE_BOUND=ROOT/'output/h5-shared-three-bracket-difference-bound-20261104'"
charge="'component_count_filter_seconds':load(ORIGINAL_COUNT/'checks.json')['seconds'],'continuous_pair_bound_seconds':load(PAIR_BOUND/'checks.json')['seconds'],'direct_four_part_bound_seconds':load(FOUR_BOUND/'checks.json')['seconds'],'three_bracket_bound_seconds':load(THREE_BOUND/'checks.json')['seconds'],'direct_block_count_filter_seconds':load(FINAL_COUNT/'checks.json')['seconds'],'count_input_preparation_seconds':load(COUNT/'checks.json')['seconds']"
s=replace_common((ROOT/'output/build_h5_fine_component_model_20261029.py').read_text(encoding='utf-8'))
s=s.replace("PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'","PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'"+extra)
s=s.replace("'component_count_filter_seconds':load(COUNT/'checks.json')['seconds']",charge)
s=s.replace('inputs=[Path(__file__),',"inputs=[Path(__file__)]+[folder/'checks.json' for folder in [ORIGINAL_COUNT,FINAL_COUNT,PAIR_BOUND,FOUR_BOUND,THREE_BOUND]]+[")
s=s.replace('and18 audited','and14 audited').replace('all42 independently','all24 independently').replace('this eliminates1876 impossible owner-region choices','this eliminates only impossible owner-region choices')
s=s.replace("'retained_empty_site_pairs':18,'forbidden_site_pair_constraints':87", "'retained_empty_site_pairs':len(allowed),'forbidden_site_pair_constraints':len(forbidden)")
write('build_h5_block_pruned_model_20261104.py',s)
s=replace_common((ROOT/'output/check_h5_fine_component_candidate_20261029.py').read_text(encoding='utf-8'));write('check_h5_block_pruned_candidate_20261104.py',s)
s=replace_common((ROOT/'output/run_h5_fine_component_model_20261029.py').read_text(encoding='utf-8')).replace('check_h5_fine_component_candidate_20261029.py','check_h5_block_pruned_candidate_20261104.py');write('run_h5_block_pruned_model_20261104.py',s)
print('Prepared a new14-choice/24-distribution model and one-call runner with full direct-proof charges.')
