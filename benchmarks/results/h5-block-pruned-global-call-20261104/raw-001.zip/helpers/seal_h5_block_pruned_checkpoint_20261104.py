"""Seal the new model with exact references to already committed source evidence."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-block-pruned-global-call-20261104';OUT=ROOT/'benchmarks/results'/NAME;PARENT=ROOT/'benchmarks/results/h5-continuous-small-block-exclusions-20261104';BASE=ROOT/'output/h5-first55-block-pruned-model-v2-20261104';COUNT=ROOT/'output/h5-first55-block-count-model-inputs-20261104';FAILED=ROOT/'output/h5-first55-block-pruned-model-20261104'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
assert load(PARENT/'archive-checks.json')['passed'] and load(BASE/'model-audit/checks.json')['passed']
response=load(BASE/'response-audit/checks.json');assert response['passed'] and response['solver_status']=='UNKNOWN' and response['closed_solver_calls']==1 and response['assignments']==0 and response['overall_algorithm_shared_overruns_seconds']==0
parent_manifest=load(PARENT/'raw-manifest.json');parent_by_hash={}
for row in parent_manifest['files']:parent_by_hash[(row['sha256'],row['bytes'])]=row
OUT.mkdir();members={};external={};queue=[];seen=set();bindings={}
def add(name,p):
    assert p.is_file() and p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts)
    h=digest(p);size=p.stat().st_size;old=parent_by_hash.get((h,size))
    if old:external[name]={'manifest':(PARENT/'raw-manifest.json').relative_to(ROOT).as_posix(),'manifest_sha256':digest(PARENT/'raw-manifest.json'),'archive':old['archive'],'member':old['path'],'bytes':size,'sha256':h}
    else:members[name]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [BASE,COUNT,FAILED]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*block_pruned*20261104.py','*h5*block_count_model*20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]:add('helpers/'+name,ROOT/'output'/name)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for name,h in load(p).get('inputs',{}).items():
            q=ROOT/name;assert digest(q)==h,name;bindings[name]=h;add('source-inputs/'+name,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'external-evidence.json',external);write(OUT/'source-bindings.json',bindings)
for p,name in [(COUNT/'audit/checks.json','count-input-audit.json'),(BASE/'model/checks.json','model.json'),(BASE/'model/preparation-charges.json','preparation-charges.json'),(BASE/'model-audit/checks.json','model-audit.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/lp-diagnostics.txt','lp-diagnostics.txt'),(BASE/'next-step.json','next-step.json')]:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'external_parent_manifest':(PARENT/'raw-manifest.json').relative_to(ROOT).as_posix(),'external_parent_manifest_sha256':digest(PARENT/'raw-manifest.json'),'source_bindings':len(bindings),'closed_solver_calls':1,'solver_status':'UNKNOWN','assignments':0,'solve_slice_overrun_seconds':response['solve_slice_overrun_seconds'],'overall_algorithm_shared_overruns_seconds':0,'remaining_count_distributions':24,'remaining_site_choices':14,'remaining_allocation_candidates':440,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Smaller first55 model: closed UNKNOWN — 2026-11-04

The [continuous source exclusions](h5-continuous-small-block-exclusions-20261104.md)
reduce the canonical first55 model to 14 site choices and 24 count distributions.
All 6,498 variables and 32,697 constraints pass [independent readback]({NAME}/model-audit.json),
including source-mode coupling, all 183 different-owner rectangle pairs,
182 canonical component equalities and 227 valid within-component orderings.
The [count-input audit]({NAME}/count-input-audit.json) checks all 3,676 retained
source-mode attributions and preserves the proved count-table bytes.

The sole declared call returned **UNKNOWN**, with 53,720 branches, 4,508 conflicts
and no assignment. [The response audit]({NAME}/response-audit.json) records
42.969984 s charged preparation, 12.282428 s allocated solve time and 12.348058 s
returned solve time. The **0.065630 s solve-slice overrun is preserved**.
Algorithm time 56.080238 s and shared time 56.175358 s remain within 60/90 s.
There is no new infeasibility or placement claim, and the call remains closed.
[All preparation charges]({NAME}/preparation-charges.json) include the original
short-sheet construction, source capacities, original count filter, new direct
proofs and new model build. The longer strip derivation is not a required input
to this direct algorithm.

The first builder stopped on a stale forbidden-pair count before producing a
model or calling a solver. Its files and failure record remain preserved; v2
uses the correct 91 forbidden pairs. The successful model and result were not
modified after their audits.

The new archive contains {archive['archive_members']} canonical files and
{archive['archive_bytes']:,} compressed bytes. [Its manifest]({NAME}/raw-manifest.json)
and [exact external evidence map]({NAME}/external-evidence.json) form a complete
bundle with the preceding committed evidence archive; every reused member is
bound by manifest hash, member path, byte count and SHA-256. This avoids another
copy of the same historical source data. [Source bindings]({NAME}/source-bindings.json)
resolve across both bundles and are independently checked before commit.

The 14/24 restricted domain and 440 whole-job allocation candidates remain open.
No source66 check, native validation or release follows. H2/H5 remain open at
**60%**; product source, original gates and all 22 reserved H2 vectors are
unchanged. [Next work]({NAME}/next-step.json) examines the remaining independent
two-insert blocks and their companions; this global call must not be repeated.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 smaller global construction:** [the independently audited 14-choice/24-distribution model]({link}) has 6,498 variables and 32,697 constraints. Its sole call is closed UNKNOWN with no assignment. The 0.065630 s solve-slice overrun is preserved; total algorithm/shared time remains within 60/90 s. No restart, new exclusion or placement claim follows. H2/H5 remain open at 60%; full66 source/native/material checks and the H5 matrix remain required.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [continuous small-block exclusions](../benchmarks/results/h5-continuous-small-block-exclusions-20261104.md).';assert s.count(old)==1;s=s.replace(old,f'Latest H5 evidence: [smaller global construction](../benchmarks/results/{NAME}.md).',1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
