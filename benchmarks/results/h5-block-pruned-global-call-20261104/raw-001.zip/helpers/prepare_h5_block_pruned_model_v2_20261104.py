from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('build_h5_block_pruned_model_20261104.py','build_h5_block_pruned_model_v2_20261104.py'),('check_h5_block_pruned_candidate_20261104.py','check_h5_block_pruned_candidate_v2_20261104.py'),('run_h5_block_pruned_model_20261104.py','run_h5_block_pruned_model_v2_20261104.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-first55-block-pruned-model-20261104','h5-first55-block-pruned-model-v2-20261104').replace('check_h5_block_pruned_candidate_20261104.py','check_h5_block_pruned_candidate_v2_20261104.py').replace('assert len(forbidden)==87','assert len(forbidden)==91')
    p=ROOT/'output'/new;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
