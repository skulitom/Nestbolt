from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_fine_component_response_20261029.py').read_text(encoding='utf-8')
for a,b in [('h5-first55-fine-components-model-20261029','h5-first55-block-pruned-model-v2-20261104'),('len(model.variables)==6520 and len(model.constraints)==32928','len(model.variables)==6498 and len(model.constraints)==32697'),("result['returned_response_branches']==39749","result['returned_response_branches']==53720"),("result['returned_response_conflicts']==51","result['returned_response_conflicts']==4508")]:assert a in s,a;s=s.replace(a,b)
a=s.index('assert "\'max_lp\'');b=s.index("with (OUT/'lp-diagnostics.txt')",a);s=s[:a]+s[b:]
a=s.index("'max_lp_cut_propagations':");b=s.index("'assignments':0",a);s=s[:a]+s[b:]
p=ROOT/'output/audit_h5_block_pruned_response_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
