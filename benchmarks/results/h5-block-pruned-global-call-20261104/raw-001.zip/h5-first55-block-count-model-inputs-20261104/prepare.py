"""Verify source-mode aliases and materialize the audited 14-choice count input."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-first55-direct-smaller-block-filtered-20261104';OUT=ROOT/'output/h5-first55-block-count-model-inputs-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(SOURCE/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'audit').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();rows=load(SOURCE/'all-filtered-bounds.json');assignments=0;unique=0
for r in rows:
    bygeometry={}
    for family,mode,gid,region,group in r['region_component_assignments']:
        assert r['groups'][group]['family']==family;bygeometry.setdefault((family,gid,region),set()).add(group);assignments+=1
    assert all(len(v)==1 for v in bygeometry.values());unique+=len(bygeometry)
    assert len({tuple(v) for v in r['remaining_distributions']})==len(r['remaining_distributions'])
    for counts in r['remaining_distributions']:
        assert len(counts)==len(r['groups'])
        for f,count in [('bracket',7),('insert',6)]:assert sum(n for n,g in zip(counts,r['groups']) if g['family']==f)==count
allowed=[r['empty_sites'] for r in rows];assert len(rows)==14 and sum(len(r['remaining_distributions']) for r in rows)==24
shutil.copyfile(SOURCE/'all-filtered-bounds.json',OUT/'all14-filtered-bounds.json');assert digest(OUT/'all14-filtered-bounds.json')==digest(SOURCE/'all-filtered-bounds.json')
write(OUT/'audit/allowed-empty-site-pairs.json',allowed);elapsed=time.perf_counter()-started
inputs=[Path(__file__),SOURCE/'plan.json',SOURCE/'audit/plan.json',SOURCE/'audit/checks.json',SOURCE/'all-filtered-bounds.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':elapsed,'all_source_mode_aliases_agree_on_component':True,'source_mode_assignments_verified':assignments,'unique_geometry_region_assignments_verified':unique,'retained_empty_site_pairs':14,'retained_count_distributions':24,'source_count_bytes_unchanged':True,'packing_solver_calls':0}
write(OUT/'checks.json',checks);write(OUT/'audit/checks.json',checks)
write(OUT/'audit/plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),OUT/'plan.json',OUT/'checks.json',OUT/'all14-filtered-bounds.json',OUT/'audit/allowed-empty-site-pairs.json']}})
print(checks)
