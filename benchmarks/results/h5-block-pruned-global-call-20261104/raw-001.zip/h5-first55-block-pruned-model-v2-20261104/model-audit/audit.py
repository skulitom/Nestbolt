"""Verify every protobuf variable, site mask, mode coupling and original-pair constraint."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations
import json, shutil, time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';PRE=BASE;TARGET=ROOT/'output/h5-first55-block-pruned-model-v2-20261104';COUNT=ROOT/'output/h5-first55-block-count-model-inputs-20261104';GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';STRIP=ROOT/'output/h5-first55-direct-fine-strip-capacity-20261029';FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';MODEL=TARGET/'model';OUT=TARGET/'model-audit';RID=BASE;ORIGINAL_COUNT=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029';FINAL_COUNT=ROOT/'output/h5-first55-direct-smaller-block-filtered-20261104';PAIR_BOUND=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';FOUR_BOUND=ROOT/'output/h5-shared-four-direct-difference-bound-20261104';THREE_BOUND=ROOT/'output/h5-shared-three-bracket-difference-bound-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [PRE,MODEL,BASE/'geometry-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
assert load(BASE/'geometry-audit/checks.json')['passed']
assert load(COUNT/'audit/checks.json')['passed'] and load(COUNT/'audit/checks.json')['all_source_mode_aliases_agree_on_component']
queue=[MODEL/'plan.json',COUNT/'audit/plan.json',BASE/'geometry-audit/plan.json'];seen=set();bindings={}
while queue:
    source=queue.pop()
    if source in seen:continue
    seen.add(source)
    for name,h in load(source).get('inputs',{}).items():
        path=ROOT/name;assert path.is_relative_to(ROOT) and not {'.claude','.cache'}&set(path.parts) and digest(path)==h,name;bindings[name]=h
        if path.name in ['plan.json','opened.json']:queue.append(path)
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints'} and len(p.variables)==6498 and len(p.constraints)==32697
mapping=load(MODEL/'mapping.json');modes=load(PRE/'family-modes.json');unary=load(PRE/'unary-templates.json');instances=load(BASE/'instances.json');inventory=load(BASE/'inventory.json');owners=mapping['owners']
assert len(owners)==len(instances)==13 and mapping['position_units_per_mm']==10 and mapping['world_origin_mm']==[0,2100] and [o['identity'] for o in owners]==inventory['moving13_orthogonal_identities']
used_vars=set();used_ct=set();false_clauses=0
def variable(i,name,domain):
    assert i not in used_vars;used_vars.add(i);v=p.variables[i];assert v.name==name and list(v.domain)==domain and {f.name for f,x in v.ListFields()}=={'name','domain'}
def linear(i,coeff,lo,hi,guard=None):
    global false_clauses
    assert i not in used_ct;used_ct.add(i);c=p.constraints[i];co={j:v for j,v in coeff.items() if v}
    assert list(c.enforcement_literal)==([] if guard is None else [guard])
    if not co and not lo<=0<=hi:
        assert c.WhichOneof('constraint')=='bool_or' and not c.bool_or.literals and {f.name for f,x in c.ListFields()}=={'bool_or'}|({'enforcement_literal'} if guard is not None else set());false_clauses+=1;return
    assert c.WhichOneof('constraint')=='linear' and {f.name for f,x in c.ListFields()}=={'linear'}|({'enforcement_literal'} if guard is not None else set())
    assert dict(zip(c.linear.vars,c.linear.coeffs))==co and len(c.linear.vars)==len(co) and list(c.linear.domain)==[lo,hi]
mode_count=unary_count=unary_planes=mask_links=0
for i,(owner,instance) in enumerate(zip(owners,instances)):
    assert owner['owner']==i and owner['identity']==instance['identity'] and owner['positions']==[2*i,2*i+1]
    expected=modes[owner['identity'][0]];assert len(owner['modes'])==len(expected)
    for k in [0,1]:variable(2*i+k,f'{"x" if k==0 else "y"}_{i}_grid',[min(m['integer_lower_left_bounds'][k][0] for m in expected),max(m['integer_lower_left_bounds'][k][1] for m in expected)])
    for actual,source in zip(owner['modes'],expected):
        assert {k:v for k,v in actual.items() if k not in ['selector','stock_constraints']}==source
        selector=actual['selector'];assert 26<=selector<106;variable(selector,f'mode_{i}_{source["mode"]}',[0,1]);assert len(actual['stock_constraints'])==2
        for k in [0,1]:linear(actual['stock_constraints'][k],{2*i+k:1},*source['integer_lower_left_bounds'][k],selector)
        mode_count+=1
    linear(owner['one_mode_constraint'],{m['selector']:1 for m in owner['modes']},1,1)
empty=mapping['empty_site_selectors'];assert empty==list(range(106,121))
for site,var in enumerate(empty):variable(var,f'empty_cog_site_{site}',[0,1])
linear(mapping['exactly_two_empty_sites_constraint'],{v:1 for v in empty},2,2)
assert len(list(combinations(empty,2)))==105
allowed=load(COUNT/'audit/allowed-empty-site-pairs.json');expected_forbidden=[list(pair) for pair in combinations(range(15),2) if list(pair) not in allowed]
assert len(allowed)==14 and len(expected_forbidden)==91
assert [r['empty_sites'] for r in mapping['forbidden_site_pairs']]==expected_forbidden
for r in mapping['forbidden_site_pairs']:
    a,b=r['empty_sites'];linear(r['constraint'],{empty[a]:1,empty[b]:1},MIN,1)
for i,owner in enumerate(owners):
    geometries=sorted({m['normalized_geometry'] for m in owner['modes']});expected=[(gid,r['region']) for gid in geometries for r in unary[gid]['regions'] if any(set(r['required_empty_sites'])<=set(sites) for sites in allowed)]
    assert [(r['geometry'],r['region']) for r in owner['unary_regions']]==expected
    for region in owner['unary_regions']:
        gid,ri=region['geometry'],region['region'];source=next(r for r in unary[gid]['regions'] if r['region']==ri);selector=region['selector'];assert 121<=selector<5648
        variable(selector,f'unary_{i}_{gid}_{ri}',[0,1]);assert region['required_empty_sites']==source['required_empty_sites'] and len(region['plane_constraints'])==len(source['planes'])
        for ci,plane in zip(region['plane_constraints'],source['planes']):
            nx,ny=plane['coefficients'];linear(ci,{2*i:nx,2*i+1:ny},MIN,plane['upper'],selector);unary_planes+=1
        assert len(region['empty_site_constraints'])==len(source['required_empty_sites'])
        for ci,site in zip(region['empty_site_constraints'],source['required_empty_sites']):linear(ci,{selector:1,empty[site]:-1},MIN,0);mask_links+=1
        unary_count+=1
    linear(owner['one_unary_region_constraint'],{r['selector']:1 for r in owner['unary_regions']},1,1)
    assert [m['geometry'] for m in owner['unary_geometry_marginals']]==geometries
    for marginal in owner['unary_geometry_marginals']:
        gid=marginal['geometry'];ms=[m['selector'] for m in owner['modes'] if m['normalized_geometry']==gid];rs=[r['selector'] for r in owner['unary_regions'] if r['geometry']==gid]
        assert marginal['mode_selectors']==ms and marginal['region_selectors']==rs and ms and rs;linear(marginal['constraint'],{**{v:-1 for v in ms},**{v:1 for v in rs}},0,0)
pair_count=pair_planes=marginals=0
assert mapping['pairs']==[] and mapping['rectangle_gap_grid']==3 and load(RID/'geometry-audit/checks.json')['passed']
source_rectangles=load(RID/'mode-rectangles.json');source_components=load(RID/'components.json');source_pairs=load(RID/'component-pairs.json');components=mapping['rigid_components'];separations=mapping['rectangle_separations'];coordinate_links=0
assert len(components)==20 and len(separations)==183
for actual,expected_component in zip(components,source_components):
    assert {k:v for k,v in actual.items() if k not in ['coordinates','mode_links']}==expected_component
    ci,oi,pi=actual['component'],actual['owner'],actual['piece'];owner=owners[oi];family=owner['identity'][0];assert actual['identity']==owner['identity'] and actual['coordinates']==list(range(5648+4*ci,5652+4*ci))
    for k,(label,vi) in enumerate(zip(['left','bottom','right','top'],actual['coordinates'])):
        axis=k%2
        lower=min(m['integer_lower_left_bounds'][axis][0]+source_rectangles[family][m['mode']]['rectangles'][pi]['outward_offsets_grid'][k] for m in owner['modes'])
        upper=max(m['integer_lower_left_bounds'][axis][1]+source_rectangles[family][m['mode']]['rectangles'][pi]['outward_offsets_grid'][k] for m in owner['modes'])
        variable(vi,f'rect_{ci}_{label}_grid',[lower,upper])
    assert len(actual['mode_links'])==len(owner['modes'])
    for link,mode in zip(actual['mode_links'],owner['modes']):
        offsets=source_rectangles[family][mode['mode']]['rectangles'][pi]['outward_offsets_grid']
        assert link['mode']==mode['mode'] and link['mode_selector']==mode['selector'] and link['outward_offsets_grid']==offsets and len(link['constraints'])==4
        for k,(ct,vi,offset) in enumerate(zip(link['constraints'],actual['coordinates'],offsets)):
            linear(ct,{vi:1,owner['positions'][k%2]:-1},offset,offset,mode['selector']);coordinate_links+=1
for index,(actual,expected_pair) in enumerate(zip(separations,source_pairs)):
    assert actual['components']==expected_pair['components'] and actual['owners']==expected_pair['owners'] and actual['owners'][0]!=actual['owners'][1]
    ai,bi=actual['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];assert actual['selectors']==list(range(5728+4*index,5732+4*index)) and len(actual['constraints'])==4
    directions=[{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}]
    for direction,(vi,ct,coeff) in enumerate(zip(actual['selectors'],actual['constraints'],directions)):
        variable(vi,f'separate_{ai}_{bi}_{direction}',[0,1]);linear(ct,coeff,MIN,-3,vi)
    linear(actual['one_direction_constraint'],{vi:1 for vi in actual['selectors']},1,1)
assert coordinate_links==544
assert mapping['symmetry_constraints']==[]
source_choices=load(COUNT/'all14-filtered-bounds.json');choices=mapping['component_count_choices'];assert len(choices)==len(source_choices)==14
all_d=[];all_p=[];component_equalities=0
for pair_index,(actual,source) in enumerate(zip(choices,source_choices)):
    sites=source['empty_sites'];a,b=sites;assert actual['empty_sites']==sites
    pv=actual['pair_selector'];all_p.append(pv);variable(pv,f'component_site_pair_{a}_{b}',[0,1]);assert len(actual['pair_and_constraints'])==3
    linear(actual['pair_and_constraints'][0],{pv:1,empty[a]:-1},MIN,0)
    linear(actual['pair_and_constraints'][1],{pv:1,empty[b]:-1},MIN,0)
    linear(actual['pair_and_constraints'][2],{pv:1,empty[a]:-1,empty[b]:-1},-1,2**63-1)
    assert [r['counts'] for r in actual['distributions']]==source['remaining_distributions']
    for di,distribution in enumerate(actual['distributions']):
        var=distribution['selector'];variable(var,f'component_distribution_{pair_index}_{di}',[0,1]);all_d.append(var)
    linear(actual['distribution_pair_constraint'],{**{r['selector']:1 for r in actual['distributions']},pv:-1},0,0)
    lookup={}
    for family,mode,gid,ri,ci in source['region_component_assignments']:lookup.setdefault((family,gid,ri),set()).add(ci)
    assert all(len(v)==1 for v in lookup.values());expected=[[] for _ in source['groups']];observed=set()
    for owner in owners:
        family=owner['identity'][0]
        for region in owner['unary_regions']:
            if set(region['required_empty_sites'])-set(sites):continue
            key=(family,region['geometry'],region['region']);assert key in lookup;ci=next(iter(lookup[key]));expected[ci].append(region['selector']);observed.add(key)
    assert observed==set(lookup) and len(actual['component_counts'])==len(source['groups'])
    for ci,(record,group,selectors) in enumerate(zip(actual['component_counts'],source['groups'],expected)):
        assert record['group']==ci and record['family']==group['family'] and record['region_selectors']==selectors and selectors
        co={v:1 for v in selectors}
        for distribution in actual['distributions']:
            count=distribution['counts'][ci]
            if count:co[distribution['selector']]=-count
        linear(record['constraint'],co,0,0,pv);component_equalities+=1
assert len(all_p)==14 and len(all_d)==24 and component_equalities==51
linear(mapping['one_site_pair_choice_constraint'],{v:1 for v in all_p},1,1)
linear(mapping['one_count_distribution_constraint'],{v:1 for v in all_d},1,1)
canonical_equalities=lexicographic_constraints=0
for owner in owners:
    peers=[o for o in owners if o['identity'][0]==owner['identity'][0]]
    for peer in peers:
        assert [list(p.variables[v].domain) for v in owner['positions']]==[list(p.variables[v].domain) for v in peer['positions']]
        assert [(r['geometry'],r['region'],r['required_empty_sites']) for r in owner['unary_regions']]==[(r['geometry'],r['region'],r['required_empty_sites']) for r in peer['unary_regions']]
        assert [{k:v for k,v in m.items() if k not in ['selector','stock_constraints']} for m in owner['modes']]==[{k:v for k,v in m.items() if k not in ['selector','stock_constraints']} for m in peer['modes']]
expected_rect_pairs=[list(pair) for pair in combinations(range(len(components)),2) if components[pair[0]]['owner']!=components[pair[1]]['owner']]
assert [r['components'] for r in separations]==expected_rect_pairs
for actual,source in zip(choices,source_choices):
    peers={f:sorted((o for o in owners if o['identity'][0]==f),key=lambda o:o['identity'][1]) for f in ['bracket','insert']}
    for distribution in actual['distributions']:
        assigned=[None]*len(owners)
        for family,family_owners in peers.items():
            cursor=0
            for gi,g in enumerate(source['groups']):
                if g['family']!=family:continue
                count=distribution['counts'][gi]
                for rank in range(cursor,cursor+count):assigned[family_owners[rank]['owner']]=gi
                cursor+=count
            assert cursor==len(family_owners)
        assert distribution['canonical_owner_groups']==assigned and all(v is not None for v in assigned)
        expected_order=[]
        for family,family_owners in peers.items():
            for a,b in zip(family_owners,family_owners[1:]):
                if assigned[a['owner']]==assigned[b['owner']]:expected_order.append((family,a,b,assigned[a['owner']]))
        assert len(distribution['within_component_order'])==len(expected_order)
        for record,(family,a,b,group) in zip(distribution['within_component_order'],expected_order):
            ymin=min(list(p.variables[o['positions'][1]].domain)[0] for o in [a,b]);ymax=max(list(p.variables[o['positions'][1]].domain)[1] for o in [a,b]);scale=ymax-ymin+1
            assert record['family']==family and record['owners']==[a['owner'],b['owner']] and record['group']==group and record['x_scale']==scale and scale>ymax-ymin
            linear(record['constraint'],{a['positions'][0]:scale,b['positions'][0]:-scale,a['positions'][1]:1,b['positions'][1]:-1},MIN,0,distribution['selector']);lexicographic_constraints+=1
    lookup={}
    for family,mode,gid,ri,ci in source['region_component_assignments']:
        key=(family,gid,ri)
        if key in lookup:assert lookup[key]==ci
        lookup[key]=ci
    assert len(actual['canonical_owner_component_constraints'])==len(owners)
    for record,owner in zip(actual['canonical_owner_component_constraints'],owners):
        expected=[];co={};family=owner['identity'][0]
        for r in owner['unary_regions']:
            if set(r['required_empty_sites'])-set(source['empty_sites']):continue
            group=lookup[(family,r['geometry'],r['region'])];expected.append({'selector':r['selector'],'group':group});co[r['selector']]=group+1
        for distribution in actual['distributions']:co[distribution['selector']]=-(distribution['canonical_owner_groups'][owner['owner']]+1)
        assert record['owner']==owner['owner'] and record['region_groups']==expected
        linear(record['constraint'],co,0,0,actual['pair_selector']);canonical_equalities+=1
assert canonical_equalities==182 and lexicographic_constraints==227
expected_charges=load(BASE/'model/preparation-charges.json');expected_charges['cp_model_build_seconds']=load(MODEL/'checks.json')['seconds'];expected_charges['component_axis_capacity_bound_seconds']=load(BASE/'component-halfspace-bound/checks.json')['seconds'];expected_charges['generic_component_count_preparation_seconds']=load(GENERIC/'checks.json')['seconds'];expected_charges['direct_fine_area_bound_seconds']=load(FINE/'checks.json')['seconds'];expected_charges['direct_fine_strip_bound_seconds']=load(STRIP/'checks.json')['seconds'];expected_charges['component_count_filter_seconds']=load(ORIGINAL_COUNT/'checks.json')['seconds'];expected_charges['continuous_pair_bound_seconds']=load(PAIR_BOUND/'checks.json')['seconds'];expected_charges['direct_four_part_bound_seconds']=load(FOUR_BOUND/'checks.json')['seconds'];expected_charges['three_bracket_bound_seconds']=load(THREE_BOUND/'checks.json')['seconds'];expected_charges['direct_block_count_filter_seconds']=load(FINAL_COUNT/'checks.json')['seconds'];expected_charges['count_input_preparation_seconds']=load(COUNT/'checks.json')['seconds']
assert load(MODEL/'preparation-charges.json')==expected_charges
write(OUT/'source-bindings.json',bindings)
assert used_vars==set(range(6498)) and used_ct==set(range(32697)) and mode_count==80 and unary_count==5527 and unary_planes==22439 and mask_links==7935 and pair_count==0 and pair_planes==0 and marginals==0
pruned=[]
for owner in owners:
    geometries=sorted({m['normalized_geometry'] for m in owner['modes']})
    represented={(r['geometry'],r['region']) for r in owner['unary_regions']}
    for gid in geometries:
        for region in unary[gid]['regions']:
            compatible=[sites for sites in allowed if all(site in sites for site in region['required_empty_sites'])]
            assert ((gid,region['region']) in represented)==bool(compatible)
            if not compatible:pruned.append({'owner':owner['owner'],'geometry':gid,'region':region['region'],'required_empty_sites':region['required_empty_sites']})
assert len(pruned)==1876 and load(MODEL/'checks.json')['unary_site_mask_pruned_selectors']==1876
write(OUT/'impossible-unary-mask-choices.json',pruned)
assert load(MODEL/'checks.json')['preparation_seconds_charged']==sum(load(MODEL/'preparation-charges.json').values())
inputs=[Path(__file__),FINE/'plan.json',FINE/'checks.json',FINE/'audit/plan.json',FINE/'audit/checks.json',GENERIC/'checks.json',STRIP/'plan.json',STRIP/'checks.json',STRIP/'audit/plan.json',STRIP/'audit/checks.json',COUNT/'plan.json',COUNT/'checks.json',COUNT/'audit/plan.json',COUNT/'audit/checks.json',COUNT/'all14-filtered-bounds.json',COUNT/'audit/allowed-empty-site-pairs.json',BASE/'model/preparation-charges.json',BASE/'component-halfspace-bound/checks.json',RID/'plan.json',RID/'geometry-audit/plan.json',RID/'geometry-audit/checks.json',RID/'mode-rectangles.json',RID/'components.json',RID/'component-pairs.json',BASE/'plan.json',BASE/'instances.json',BASE/'inventory.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json']+[PRE/n for n in ['plan.json','family-modes.json','unary-templates.json','allowed-empty-site-pairs.json']]+[MODEL/n for n in ['plan.json','checks.json','model.pb','model.pbtxt','mapping.json','preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'passed':True,'seconds':time.perf_counter()-started,'variables_verified':len(used_vars),'constraints_verified':len(used_ct),'original_moving_parts':13,'source_mode_selectors_verified':mode_count,'empty_site_selectors_verified':15,'exactly_two_empty_sites_verified':True,'unary_regions_verified':unary_count,'unary_planes_verified':unary_planes,'empty_site_implications_verified':mask_links,'pair_regions_verified':pair_count,'pair_planes_verified':pair_planes,'pair_geometry_marginals_verified':marginals,'rigid_components_verified':20,'source_mode_coordinate_links_verified':544,'different_owner_rectangle_pairs_verified':183,'separation_direction_selectors_verified':732,'all_components_rigidly_tied_to_original_source_poses':True,'disabled_region_empty_clauses_verified':false_clauses,'same_family_order_constraints_verified':0,'canonical_owner_component_equalities_verified':182,'within_component_lexicographic_order_constraints_verified':227,'same_family_owner_domains_and_geometry_identical':True,'all_different_owner_rectangle_pairs_present':True,'canonical_relabelling_preserves_every_feasible_placement':True,'all_model_fields_exhaustively_verified':True,'pruned_unary_choices_impossible_for_every_retained_site_pair':True,'unary_mask_pruned_selectors_verified':1876,'binary_and_text_models_identical':True,'all14_remaining_empty_site_pairs_represented':True,'forbidden_site_pairs_verified':91,'component_pair_selectors_verified':14,'count_distribution_selectors_verified':24,'conditional_component_equalities_verified':51,'all_source_mode_aliases_agree_on_component':True,'recursive_bindings':len(bindings),'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
