"""Apply the proved continuous source block exclusion only where source options are covered."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
PRIOR=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029'
BLOCK=ROOT/'output/h5-shared-five-fine-domain-bound-20261104'
PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029'
OUT=ROOT/'output/h5-first55-continuous-block-filtered-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRIOR/'audit/checks.json')['passed'] and load(BLOCK/'audit/checks.json')['continuous_source_block_excluded']
OUT.mkdir();shutil.copyfile(__file__,OUT/'filter.py');started=time.perf_counter()
keys={tuple(n['key']) for n in load(PAIR/'nodes.json')};rows=load(PRIOR/'all18-filtered-bounds.json');certs=[];remaining=[]
for row in rows:
    eligible={'bracket':[],'insert':[]};group_keys={}
    for group_index,group in enumerate(row['groups']):
        options={tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==group_index}
        if options and options<=keys:
            eligible[group['family']].append(group_index);group_keys[group_index]=sorted(options)
    kept=[]
    for counts in row['remaining_distributions']:
        totals={family:sum(counts[g] for g in groups) for family,groups in eligible.items()}
        if totals['bracket']>=2 and totals['insert']>=3:
            certs.append({'empty_sites':row['empty_sites'],'counts':counts,'covered_groups':eligible,'covered_family_counts':totals,'source_options_by_group':group_keys})
        else:kept.append(counts)
    new={**row,'remaining_distributions':kept}
    if kept:remaining.append(new)
elapsed=time.perf_counter()-started
inputs=[Path(__file__),PAIR/'plan.json',PAIR/'nodes.json']+[PRIOR/n for n in ['plan.json','audit/plan.json','audit/checks.json','all18-filtered-bounds.json']]+[BLOCK/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','audit/retained-option-multisets.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each original count row, identify every source group whose complete family/mode/geometry/region option set is a subset of the independently excluded block domain. A count distribution placing at least two brackets and three inserts in these covered groups contains an impossible five-part subset. Remove exactly those distributions. Preserve every other field and all source assignments. No component separation assumption or grid solver result is needed.','global_allocation_exclusion_permitted':False,'solver_calls':0,'native_calls':0})
write(OUT/'exclusion-certificates.json',certs);write(OUT/'all18-filtered-bounds.json',remaining)
result={'passed':True,'seconds':elapsed,'prior_distributions':sum(len(r['remaining_distributions']) for r in rows),'new_count_distribution_exclusions':len(certs),'remaining_count_distributions':sum(len(r['remaining_distributions']) for r in remaining),'prior_site_choices':len(rows),'remaining_site_choices':len(remaining),'independent_audit_required':True,'remaining_allocation_candidates':440,'global_allocation_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
