"""Independent count-row conservation and coverage of the excluded continuous block."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
PRIOR=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029'
BLOCK=ROOT/'output/h5-shared-five-fine-domain-bound-20261104'
PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029'
BASE=ROOT/'output/h5-first55-continuous-block-filtered-20261104';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(BLOCK/'audit/checks.json')['passed'] and load(BLOCK/'audit/checks.json')['continuous_source_block_excluded']
assert load(BLOCK/'audit/retained-option-multisets.json')==[]
allowed={tuple(n['key']) for n in load(PAIR/'nodes.json')};before=load(PRIOR/'all18-filtered-bounds.json');after=load(BASE/'all18-filtered-bounds.json');certs=load(BASE/'exclusion-certificates.json');actual={(tuple(c['empty_sites']),tuple(c['counts'])):c for c in certs};assert len(actual)==len(certs)
expected=[];excluded=[];checked_options=0
for row in before:
    grouped=[set() for _ in row['groups']]
    for f,m,g,r,component in row['region_component_assignments']:
        assert f==row['groups'][component]['family'];grouped[component].add((f,m,g,r));checked_options+=1
    covered={f:[i for i,options in enumerate(grouped) if options and row['groups'][i]['family']==f and not options.difference(allowed)] for f in ['bracket','insert']}
    kept=[]
    for counts in row['remaining_distributions']:
        totals={f:sum(counts[i] for i in covered[f]) for f in covered}
        if totals['bracket']>=2 and totals['insert']>=3:
            key=(tuple(row['empty_sites']),tuple(counts));c=actual[key];excluded.append(key)
            assert c['covered_groups']==covered and c['covered_family_counts']==totals
            assert c['source_options_by_group']=={str(i):[list(k) for k in sorted(grouped[i])] for indices in covered.values() for i in indices}
        else:kept.append(counts)
    if kept:expected.append({**row,'remaining_distributions':kept})
assert set(excluded)==set(actual) and after==expected and len(excluded)==3
assert len(after)==18 and sum(len(r['remaining_distributions']) for r in after)==39
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','exclusion-certificates.json','all18-filtered-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_assignments_verified':checked_options,'new_count_distribution_exclusions':3,'remaining_count_distributions':39,'remaining_site_choices':18,'complete_group_options_covered_by_continuous_proof':True,'all_other_source_fields_unchanged':True,'remaining_allocation_candidates':440,'global_allocation_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
