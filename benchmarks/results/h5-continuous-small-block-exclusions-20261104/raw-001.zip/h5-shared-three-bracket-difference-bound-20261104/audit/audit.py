"""Verify every disjunction tree with rational Floyd-Warshall closure, independently of scaled incremental closure."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,combinations_with_replacement
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';PRIOR=ROOT/'output/h5-shared-five-subset-domain-bound-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';BASE=ROOT/'output/h5-shared-three-bracket-difference-bound-20261104';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(PRIOR/'audit/checks.json')['passed'];nodes=load(PAIR/'nodes.json');compat=[int(v,16) for v in load(PAIR/'compatibility.json')];br=[i for i,n in enumerate(nodes) if n['key'][0]=='bracket'];initial=[list(v) for v in combinations_with_replacement(br,3) if all(compat[i]>>j&1 for i,j in combinations(v,2))];assert initial==load(BASE/'initial-option-multisets.json');gap=F(149,1000);assert 2*gap*gap<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2
def close(matrix):
    d=[r[:] for r in matrix]
    for k in range(len(d)):
        for i in range(len(d)):
            for j in range(len(d)):
                if d[i][k] is not None and d[k][j] is not None:
                    v=d[i][k]+d[k][j]
                    if d[i][j] is None or v<d[i][j]:d[i][j]=v
    return d
trees=leaves=splits=branches=0
def check(proof,matrices,clauses):
    global trees,leaves,splits,branches
    trees+=1
    if 'contradiction_clause' in proof:
        assert set(proof)=={'contradiction_clause'};clause=clauses[proof['contradiction_clause']]
        for axis,a,b,c in clause:assert matrices[axis][b][a]+c<0
        leaves+=1;return
    assert set(proof)=={'split_clause','children'};clause=clauses[proof['split_clause']];possible=[]
    for di,(axis,a,b,c) in enumerate(clause):
        proposed=[r[:] for r in matrices[axis]];proposed[a][b]=min(proposed[a][b],c);closed=close(proposed)
        if all(closed[i][i]>=0 for i in range(len(closed))):possible.append((di,axis,closed))
    assert possible and [di for di,axis,d in possible]==[c['direction'] for c in proof['children']]
    splits+=1
    for child,(di,axis,closed) in zip(proof['children'],possible):
        assert set(child)=={'direction','proof'};updated=matrices[:];updated[axis]=closed;branches+=1;check(child['proof'],updated,clauses)
certs=load(BASE/'exclusion-certificates.json');excluded=set()
for cert in certs:
    whole=tuple(cert['nodes']);assert list(whole) in initial and whole not in excluded
    bounds=[list(map(F,nodes[i]['translation_bounds_mm'])) for i in whole];size=len(whole)+1;origin=size-1;matrices=[]
    for axis in [0,1]:
        d=[[F(0) if i==j else None for j in range(size)] for i in range(size)]
        for i,b in enumerate(bounds):d[i][origin]=b[axis+2];d[origin][i]=-b[axis]
        matrices.append(close(d))
    pieces=[(owner,list(map(F,b))) for owner,i in enumerate(whole) for b in nodes[i]['contained_rectangles_mm']];clauses=[]
    for k,(a,A) in enumerate(pieces):
        for b,B in pieces[k+1:]:
            if a!=b:clauses.append([(0,a,b,B[0]-A[2]-gap),(0,b,a,A[0]-B[2]-gap),(1,a,b,B[1]-A[3]-gap),(1,b,a,A[1]-B[3]-gap)])
    assert len(clauses)==12;check(cert['proof'],matrices,clauses);excluded.add(whole)
retained=[v for v in initial if tuple(v) not in excluded];assert retained==load(BASE/'retained-option-multisets.json')==[] and len(excluded)==40
checks=load(BASE/'checks.json');assert checks['scan_complete'] and checks['cap_overrun_seconds']==0
write(OUT/'source-bindings.json',bindings);write(OUT/'retained-option-multisets.json',retained)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','initial-option-multisets.json','exclusion-certificates.json','retained-option-multisets.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'independent_method':'Reconstruct exact rational source interval constraints, perform full Floyd-Warshall closure, check every branch of each separation disjunction, and verify all negative-cycle contradictions. This auditor uses neither producer integer scaling nor incremental closure. All 40 pair-compatible three-bracket multisets must have a complete verified tree.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'complete_disjunction_trees_verified':len(excluded),'tree_nodes_verified':trees,'contradiction_leaves_verified':leaves,'complete_split_nodes_verified':splits,'rational_closed_branches_verified':branches,'necessary_multisets_remaining':len(retained),'continuous_source_block_excluded':True,'any_placement_proven':False,'count_distribution_application_pending':True,'remaining_count_distributions':39,'remaining_site_choices':18,'remaining_allocation_candidates':440,'packing_solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
