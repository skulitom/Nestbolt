"""Exact difference-constraint disjunction certificates for necessary continuous domains."""
from pathlib import Path
from fractions import Fraction as F
from math import lcm
from itertools import combinations,combinations_with_replacement
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';PRIOR=ROOT/'output/h5-shared-five-subset-domain-bound-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';OUT=ROOT/'output/h5-shared-three-bracket-difference-bound-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRIOR/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
nodes=load(PAIR/'nodes.json');compatible=[int(v,16) for v in load(PAIR/'compatibility.json')];br=[i for i,n in enumerate(nodes) if n['key'][0]=='bracket'];initial=[list(v) for v in combinations_with_replacement(br,3) if all(compatible[i]>>j&1 for i,j in combinations(v,2))];gap=F(149,1000);required=F(load(FIRST/'plan.json')['required_pair_gap_mm']);assert 2*gap**2<required**2
visited=0;timed_out=False;certs=[];retained=[];processed=0;relaxed_solutions=0
def domain(whole):
    bounds=[list(map(F,nodes[i]['translation_bounds_mm'])) for i in whole];pieces=[(owner,list(map(F,b))) for owner,i in enumerate(whole) for b in nodes[i]['contained_rectangles_mm']]
    scale=lcm(gap.denominator,*(v.denominator for b in bounds for v in b),*(v.denominator for owner,b in pieces for v in b));bounds=[[int(v*scale) for v in b] for b in bounds];pieces=[(o,[int(v*scale) for v in b]) for o,b in pieces];q=int(gap*scale)
    size=len(whole)+1;matrices=[]
    for axis in [0,1]:
        lo=[b[axis] for b in bounds]+[0];hi=[b[axis+2] for b in bounds]+[0]
        matrices.append([[0 if i==j else hi[i]-lo[j] for j in range(size)] for i in range(size)])
    clauses=[]
    for k,(a,A) in enumerate(pieces):
        for b,B in pieces[k+1:]:
            if a==b:continue
            clauses.append([(0,a,b,B[0]-A[2]-q),(0,b,a,A[0]-B[2]-q),(1,a,b,B[1]-A[3]-q),(1,b,a,A[1]-B[3]-q)])
    return matrices,clauses
def search(matrices,clauses):
    global visited,timed_out
    visited+=1
    if time.perf_counter()-started>=58:timed_out=True;return 'unknown',None
    selected=None
    for ci,clause in enumerate(clauses):
        if any(matrices[axis][a][b]<=c for axis,a,b,c in clause):continue
        possible=[di for di,(axis,a,b,c) in enumerate(clause) if matrices[axis][b][a]+c>=0]
        if not possible:return 'excluded',{'contradiction_clause':ci}
        if selected is None or len(possible)<len(selected[1]):selected=(ci,possible)
    if selected is None:return 'relaxed',None
    ci,possible=selected;children=[]
    for di in possible:
        axis,a,b,c=clauses[ci][di];old=matrices[axis]
        new=[[min(old[i][j],old[i][a]+c+old[b][j]) for j in range(len(old))] for i in range(len(old))]
        assert all(new[i][i]==0 for i in range(len(old)))
        updated=matrices[:];updated[axis]=new;status,proof=search(updated,clauses)
        if status!='excluded':return status,None
        children.append({'direction':di,'proof':proof})
    return 'excluded',{'split_clause':ci,'children':children}
for whole in initial:
    if time.perf_counter()-started>=58:timed_out=True;break
    matrices,clauses=domain(whole);status,proof=search(matrices,clauses)
    if status=='excluded':certs.append({'nodes':whole,'proof':proof})
    else:retained.append(whole);relaxed_solutions+=status=='relaxed'
    processed+=1
    if timed_out:break
retained.extend(initial[processed:]);elapsed=time.perf_counter()-started
inputs=[Path(__file__),PAIR/'plan.json',PAIR/'nodes.json',PAIR/'compatibility.json',FIRST/'plan.json']+[PRIOR/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Use only original source translation bounding intervals and contained rectangles. For each pair of rectangles belonging to different parts, required Euclidean separation implies at least one of four axis separations of 149/1000 mm, since 2*q^2 < required_gap^2. Encode each direction as an exact difference bound. Start with interval closure, branch on a clause with fewest viable directions, and close each new edge with exact integer-scaled arithmetic. An excluded leaf has all four directions impossible. Retain relaxed-feasible and every unprocessed branch. The relaxation ignores source-hull coupling, so surviving assignments are not placements.','gap_mm':str(gap),'discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'packing_solver_calls':0,'native_calls':0})
write(OUT/'initial-option-multisets.json',initial);write(OUT/'exclusion-certificates.json',certs);write(OUT/'retained-option-multisets.json',retained)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'scan_complete':not timed_out and processed==len(initial),'initial_multisets':len(initial),'processed_multisets':processed,'exact_search_nodes':visited,'excluded_multisets_pending_audit':len(certs),'relaxed_feasible_multisets':relaxed_solutions,'necessary_multisets_remaining':len(retained),'continuous_block_excluded_pending_audit':not retained,'independent_audit_required':True,'packing_solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
