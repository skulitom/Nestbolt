"""Independent interval-union certificates and exhaustive continuous multiset readback."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,combinations_with_replacement
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029'
OLD=ROOT/'output/h5-shared-five-subset-domain-bound-20261029'
FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029'
GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'
BASE=ROOT/'output/h5-shared-five-fine-domain-bound-20261104';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(OLD/'audit/checks.json')['passed'] and load(FINE/'audit/checks.json')['passed']
nodes=load(PAIR/'nodes.json');keys=[tuple(n['key']) for n in nodes];assert len(keys)==len(set(keys))==81
inner=load(GEN/'source-inner-rectangles.json');areas=[]
for n in nodes:
    f,m,gid,ri=n['key'];assert n['contained_rectangles_mm']==inner[f][m]
    areas.append(sum((F(r)-F(l))*(F(t)-F(b)) for l,b,r,t in inner[f][m]))
assert [str(v) for v in areas]==load(BASE/'node-source-areas.json')
spans=[{} for _ in nodes];key_index={key:i for i,key in enumerate(keys)};pieces=0
for row in load(FINE/'source-fine-covers.json'):
    key=tuple(row['source_key'])
    if key not in key_index:continue
    pieces+=1;byrow=spans[key_index[key]]
    for y,l,r in row['band_spans_tenths_mm']:byrow.setdefault(y,[]).append((l,r))
def merge(intervals):
    result=[]
    for left,right in sorted(intervals):
        assert left<=right
        if result and left<=result[-1][1]:result[-1]=(result[-1][0],max(result[-1][1],right))
        else:result.append((left,right))
    return result
spans=[{y:merge(intervals) for y,intervals in byrow.items()} for byrow in spans]
grid=load(BASE/'grid.json');x0=min(l for byrow in spans for intervals in byrow.values() for l,r in intervals);x1=max(r for byrow in spans for intervals in byrow.values() for l,r in intervals);y0=min(y for byrow in spans for y in byrow);y1=max(y for byrow in spans for y in byrow)+1;w=x1-x0
assert grid=={'x_origin_tenths_mm':x0,'x_end_tenths_mm':x1,'width_cells':w,'y_origin_two_mm_rows':y0,'y_end_two_mm_rows':y1,'cell_area_mm2':'1/5','x_span_end_exclusive':True}
# Decode emitted bitsets row by row and require exactly the independent merged intervals.
emitted=[int(s,16) for s in load(BASE/'node-supports.json')]
for i,byrow in enumerate(spans):
    expected=0
    for y in range(y0,y1):
        rowbits=(emitted[i]>>((y-y0)*w))&((1<<w)-1)
        decoded=[];x=0
        while x<w:
            if rowbits>>x&1:
                end=x+1
                while end<w and rowbits>>end&1:end+=1
                decoded.append((x+x0,end+x0));x=end
            else:x+=1
        assert decoded==[(l,r) for l,r in byrow.get(y,[]) if l<r],(i,y)
    assert emitted[i]>>(w*(y1-y0))==0
certs=load(BASE/'subset-certificates.json');bad=set();interval_rows_verified=0
for cert in certs:
    indices=tuple(cert['nodes']);assert indices==tuple(sorted(indices)) and 1<=len(indices)<=5 and indices not in bad and all(0<=i<81 for i in indices)
    rows={}
    for i in set(indices):
        for y,intervals in spans[i].items():rows.setdefault(y,[]).extend(intervals)
    tenths_width=sum(r-l for intervals in rows.values() for l,r in merge(intervals));interval_rows_verified+=len(rows)
    upper=F(tenths_width,5);lower=sum(areas[i] for i in indices)
    assert str(upper)==cert['upper_support_area_mm2'] and str(lower)==cert['lower_source_area_mm2'] and lower>upper
    bad.add(indices)
compat=[int(s,16) for s in load(PAIR/'compatibility.json')];br=[i for i,key in enumerate(keys) if key[0]=='bracket'];ins=[i for i,key in enumerate(keys) if key[0]=='insert'];necessary=0;retained=[]
for a,b in combinations_with_replacement(br,2):
    if not compat[a]>>b&1:continue
    choices=[i for i in ins if compat[a]>>i&1 and compat[b]>>i&1]
    for c,d,e in combinations_with_replacement(choices,3):
        if not (compat[c]>>d&1 and compat[c]>>e&1 and compat[d]>>e&1):continue
        necessary+=1;whole=(a,b,c,d,e)
        if not any(part in bad for k in range(1,6) for part in combinations(whole,k)):retained.append(list(whole))
checks=load(BASE/'checks.json');assert necessary==139124 and len(bad)==checks['positive_subset_certificates']
if checks['enumeration_complete']:assert retained==load(BASE/'visited-retained-option-multisets.json')
assert checks['cap_overrun_seconds']==0
write(OUT/'retained-option-multisets.json',retained);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','grid.json','node-supports.json','node-source-areas.json','subset-certificates.json','visited-retained-option-multisets.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'independent_method':'Merge source intervals per row and per certificate with integer endpoint sweeps; do not use producer bitset union or area calculation. Exhaustively enumerate the continuous pair-compatible domain with combinations_with_replacement and test certificate subsets. Original fine-cover containment and continuous pair prerequisites are hash-bound independent audits.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'original_continuous_source_options_verified':len(nodes),'source_pieces':pieces,'exact_subset_certificates_verified':len(bad),'independent_interval_union_rows':interval_rows_verified,'necessary_pair_compatible_multisets':necessary,'necessary_option_multisets_remaining':len(retained),'all_nonnegative_multisets_independently_enumerated':True,'repeated_options_supported':True,'continuous_source_block_excluded':not retained,'any_placement_proven':False,'new_count_distribution_exclusions':0,'count_distribution_application_pending':True,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
