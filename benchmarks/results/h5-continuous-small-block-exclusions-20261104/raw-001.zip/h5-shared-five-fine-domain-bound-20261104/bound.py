"""Necessary source-domain subset capacities from audited 2 mm / 0.1 mm covers."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from math import lcm
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029'
OLD=ROOT/'output/h5-shared-five-subset-domain-bound-20261029'
FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029'
OUT=ROOT/'output/h5-shared-five-fine-domain-bound-20261104'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(FINE/'audit/checks.json')['passed'] and load(OLD/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
nodes=load(PAIR/'nodes.json');compatible=[int(s,16) for s in load(PAIR/'compatibility.json')]
keys={tuple(n['key']) for n in nodes};rows=[r for r in load(FINE/'source-fine-covers.json') if tuple(r['source_key']) in keys]
spans=[s for r in rows for s in r['band_spans_tenths_mm']]
x0=min(lo for y,lo,hi in spans);x1=max(hi for y,lo,hi in spans);y0=min(y for y,lo,hi in spans);y1=max(y for y,lo,hi in spans)+1;width=x1-x0
bykey={}
for row in rows:
    key=tuple(row['source_key']);v=bykey.get(key,0)
    for y,lo,hi in row['band_spans_tenths_mm']:
        assert x0<=lo<=hi<=x1 and y0<=y<y1
        v|=((1<<(hi-lo))-1)<<((y-y0)*width+lo-x0)
    bykey[key]=v
bits=[bykey[tuple(n['key'])] for n in nodes]
area=[sum((F(r)-F(l))*(F(t)-F(b)) for l,b,r,t in n['contained_rectangles_mm']) for n in nodes]
den=lcm(*(v.denominator for v in area));weighted=[int(v*den) for v in area]
cache={};certs=[];prefixes=[0]*6;leaves=[];complete=True;cache_hits=0
def violation(indices):
    global cache_hits
    if indices in cache:cache_hits+=1;return cache[indices]
    support=0;lower=0
    for i in indices:support|=bits[i];lower+=weighted[i]
    cells=support.bit_count();bad=5*lower>den*cells;cache[indices]=bad
    if bad:certs.append({'nodes':list(indices),'upper_support_area_mm2':str(F(cells,5)),'lower_source_area_mm2':str(F(lower,den))})
    return bad
br=[i for i,n in enumerate(nodes) if n['key'][0]=='bracket'];ins=[i for i,n in enumerate(nodes) if n['key'][0]=='insert'];families=[br,br,ins,ins,ins]
def visit(selected):
    global complete
    if time.perf_counter()-started>=58:complete=False;return
    depth=len(selected);prefixes[depth]+=1
    if depth==5:leaves.append(selected[:]);return
    for i in families[depth]:
        if depth in [1,3,4] and i<selected[-1]:continue
        if any(not compatible[j]>>i&1 for j in selected):continue
        if not any(violation(tuple([j for k,j in enumerate(selected) if mask>>k&1]+[i])) for mask in range(1<<depth)):visit(selected+[i])
        if not complete:return
visit([]);elapsed=time.perf_counter()-started
inputs=[Path(__file__),PAIR/'plan.json',PAIR/'checks.json',PAIR/'nodes.json',PAIR/'compatibility.json',OLD/'audit/plan.json',OLD/'audit/checks.json',FINE/'plan.json',FINE/'audit/plan.json',FINE/'audit/checks.json',FINE/'source-fine-covers.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Regenerate all necessary nondecreasing two-bracket/three-insert option multisets from the original continuous pair graph. Bound every tested subset with unions of independently audited fine source support bands. One bit is exactly 0.1 mm x 2 mm = 1/5 mm2. Compare exact contained-source rectangle areas with multiplicity against the union upper bound. No coarse subset certificates are used to prune. All unprocessed branches survive if the fixed cap is reached; independent readback reconstructs the whole retained domain.','discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'unprocessed_domain_retained':True,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'grid.json',{'x_origin_tenths_mm':x0,'x_end_tenths_mm':x1,'width_cells':width,'y_origin_two_mm_rows':y0,'y_end_two_mm_rows':y1,'cell_area_mm2':'1/5','x_span_end_exclusive':True})
write(OUT/'node-supports.json',[hex(v) for v in bits]);write(OUT/'node-source-areas.json',[str(v) for v in area]);write(OUT/'subset-certificates.json',certs);write(OUT/'visited-retained-option-multisets.json',leaves)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'enumeration_complete':complete,'source_options':len(nodes),'source_pieces':len(rows),'support_cells_per_node':[v.bit_count() for v in bits],'prefixes_visited_by_depth':prefixes,'unique_subsets_checked':len(cache),'cached_subset_visits':cache_hits,'positive_subset_certificates':len(certs),'visited_necessary_option_multisets_remaining':len(leaves),'source_block_excluded_pending_independent_audit':complete and not leaves,'independent_audit_required':True,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print({k:v for k,v in checks.items() if k!='support_cells_per_node'})
