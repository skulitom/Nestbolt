"""Rebuild covered source groups and verify complete count/site conservation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-continuous-block-filtered-20261104';PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';FOUR=ROOT/'output/h5-shared-four-difference-bound-20261104';THREE=ROOT/'output/h5-shared-three-bracket-difference-bound-20261104';BASE=ROOT/'output/h5-first55-smaller-block-filtered-20261104';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
for p in [FOUR,THREE]:assert load(p/'audit/checks.json')['passed'] and load(p/'audit/checks.json')['continuous_source_block_excluded'] and load(p/'audit/retained-option-multisets.json')==[]
before=load(PRIOR/'all18-filtered-bounds.json');after=load(BASE/'all-filtered-bounds.json');certs=load(BASE/'exclusion-certificates.json');actual={(tuple(c['empty_sites']),tuple(c['counts'])):c for c in certs};assert len(actual)==len(certs);keys={tuple(n['key']) for n in load(PAIR/'nodes.json')};expected=[];excluded=[];source_assignments=0
for row in before:
    source=[set() for _ in row['groups']]
    for f,m,g,r,gi in row['region_component_assignments']:assert f==row['groups'][gi]['family'];source[gi].add((f,m,g,r));source_assignments+=1
    eligible={f:[i for i,v in enumerate(source) if v and not v.difference(keys) and row['groups'][i]['family']==f] for f in ['bracket','insert']};kept=[]
    for counts in row['remaining_distributions']:
        n={f:sum(counts[i] for i in eligible[f]) for f in eligible};conditions={'three_brackets':n['bracket']>=3,'two_brackets_two_inserts':n['bracket']>=2 and n['insert']>=2}
        if any(conditions.values()):
            key=(tuple(row['empty_sites']),tuple(counts));c=actual[key];assert conditions[c['proof']] and c['covered_groups']==eligible and c['covered_family_counts']==n
            assert c['source_options_by_group']=={str(i):[list(k) for k in sorted(source[i])] for indices in eligible.values() for i in indices};excluded.append(key)
        else:kept.append(counts)
    if kept:expected.append({**row,'remaining_distributions':kept})
assert set(excluded)==set(actual) and after==expected and len(excluded)==15 and len(after)==14 and sum(len(r['remaining_distributions']) for r in after)==24
removed=[r['empty_sites'] for r in before if r['empty_sites'] not in [v['empty_sites'] for v in after]];assert removed==[[0,11],[0,12],[0,13],[0,14]]
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','all-filtered-bounds.json','exclusion-certificates.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_assignments_verified':source_assignments,'new_count_distribution_exclusions':15,'total_count_exclusions_this_checkpoint':18,'remaining_count_distributions':24,'remaining_site_choices':14,'excluded_site_choices':removed,'all_surviving_source_fields_unchanged':True,'all_unprocessed_domains_preserved':True,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'packing_solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
