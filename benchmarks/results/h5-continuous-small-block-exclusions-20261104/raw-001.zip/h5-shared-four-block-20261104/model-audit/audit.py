"""Exhaustive source-domain, rigid-geometry and protobuf readback of the shared four-part block."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-shared-four-block-20261104';MODEL=BASE/'model';OUT=BASE/'model-audit';GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';COUNT=ROOT/'output/h5-first55-continuous-block-filtered-20261104';FACTOR=ROOT/'output/h5-first55-component-factorization-20261029';PREVIOUS=ROOT/'output/h5-first55-fine-components-model-20261029';PROOF=ROOT/'output/h5-shared-five-fine-domain-bound-20261104';PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[MODEL/'plan.json'];seen=set();bindings={}
while queue:
    path=queue.pop()
    if path in seen:continue
    seen.add(path)
    for n,h in load(path).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(FACTOR/'audit/checks.json')['passed'] and load(COUNT/'audit/checks.json')['passed'] and load(GEO/'geometry-audit/checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto()) and {f.name for f,v in p.ListFields()}=={'variables','constraints'}
assert len(p.variables)==192
mapping=load(MODEL/'mapping.json');assert set(mapping)=={'identities','source_options','compatible_uses','owners','components','pairs','copy_order','position_units_per_mm','world_origin_mm','rectangle_gap_grid'} and mapping['position_units_per_mm']==10 and mapping['world_origin_mm']==[0,2100] and mapping['rectangle_gap_grid']==3
assert mapping['identities']==[['bracket',0],['bracket',1],['insert',15],['insert',16]]
source={tuple(r['empty_sites']):r for r in load(COUNT/'all18-filtered-bounds.json')};expected_uses=[];all_keys=[]
for graph in load(FACTOR/'all18-factorizations.json'):
    if len(graph['independent_blocks'])<=1:continue
    row=source[tuple(graph['empty_sites'])]
    for distribution in row['remaining_distributions']:
        for block in graph['independent_blocks']:
            counts={f:sum(distribution[i] for i in block if row['groups'][i]['family']==f) for f in ['bracket','insert']}
            if counts!={'bracket':2,'insert':2}:continue
            expected_uses.append({'empty_sites':row['empty_sites'],'counts':distribution,'block_groups':block})
            all_keys.append(sorted(a[:4] for a in row['region_component_assignments'] if a[4] in block))
assert mapping['compatible_uses']==expected_uses and len(expected_uses)==3 and all(k==mapping['source_options'] for k in all_keys)
keys={tuple(k) for k in mapping['source_options']};assert len(keys)==81
modes=load(GEO/'family-modes.json');unary=load(GEO/'unary-templates.json');rects=load(GEO/'mode-rectangles.json');owners=mapping['owners'];assert len(owners)==4 and [o['identity'] for o in owners]==mapping['identities'];uv=set();uc=set()
def var(i,name,domain):
    assert i not in uv;uv.add(i);v=p.variables[i];assert v.name==name and list(v.domain)==domain and {f.name for f,x in v.ListFields()}=={'name','domain'}
def linear(i,coeff,lo,hi,guard=None):
    assert i not in uc;uc.add(i);c=p.constraints[i];co={j:v for j,v in coeff.items() if v}
    assert c.WhichOneof('constraint')=='linear' and list(c.enforcement_literal)==([] if guard is None else [guard]) and {f.name for f,x in c.ListFields()}=={'linear'}|({'enforcement_literal'} if guard is not None else set())
    assert dict(zip(c.linear.vars,c.linear.coeffs))==co and len(c.linear.vars)==len(co) and list(c.linear.domain)==[lo,hi]
for i,owner in enumerate(owners):
    assert owner['owner']==i and owner['positions']==[2*i,2*i+1];family=owner['identity'][0];ids={m for f,m,g,r in keys if f==family};expected=[m for m in modes[family] if m['mode'] in ids]
    assert len(owner['modes'])==len(expected)
    for axis in [0,1]:var(owner['positions'][axis],f'position_{i}_{axis}',[min(m['integer_lower_left_bounds'][axis][0] for m in expected),max(m['integer_lower_left_bounds'][axis][1] for m in expected)])
    for m,src in zip(owner['modes'],expected):
        assert {k:v for k,v in m.items() if k not in ['selector','stock_constraints']}==src;var(m['selector'],f'mode_{i}_{m["mode"]}',[0,1]);assert len(m['stock_constraints'])==2
        for axis in [0,1]:linear(m['stock_constraints'][axis],{owner['positions'][axis]:1},*src['integer_lower_left_bounds'][axis],m['selector'])
    linear(owner['one_mode_constraint'],{m['selector']:1 for m in owner['modes']},1,1)
    expected_regions=sorted({(g,r) for f,m,g,r in keys if f==family});assert [(r['geometry'],r['region']) for r in owner['unary_regions']]==expected_regions
    for r in owner['unary_regions']:
        gid,ri=r['geometry'],r['region'];src=next(s for s in unary[gid]['regions'] if s['region']==ri);assert all(set(src['required_empty_sites'])<=set(u['empty_sites']) for u in expected_uses)
        var(r['selector'],f'unary_{i}_{gid}_{ri}',[0,1]);assert len(r['plane_constraints'])==len(src['planes'])
        for ci,plane in zip(r['plane_constraints'],src['planes']):linear(ci,dict(zip(owner['positions'],plane['coefficients'])),MIN,plane['upper'],r['selector'])
    linear(owner['one_region_constraint'],{r['selector']:1 for r in owner['unary_regions']},1,1)
    gids=sorted({m['normalized_geometry'] for m in owner['modes']});assert [r['geometry'] for r in owner['geometry_marginals']]==gids
    for marginal in owner['geometry_marginals']:
        gid=marginal['geometry'];ms=[m for m in owner['modes'] if m['normalized_geometry']==gid];rs=[r for r in owner['unary_regions'] if r['geometry']==gid]
        assert all((family,m['mode'],gid,r['region']) in keys for m in ms for r in rs)
        linear(marginal['constraint'],{**{m['selector']:-1 for m in ms},**{r['selector']:1 for r in rs}},0,0)
components=mapping['components'];assert [(r['owner'],r['piece']) for r in components]==[(o['owner'],piece) for o in owners for piece in range(2 if o['identity'][0]=='bracket' else 1)]
for ci,c in enumerate(components):
    assert c['component']==ci and len(c['coordinates'])==4;owner=owners[c['owner']];family=owner['identity'][0];piece=c['piece']
    for k,index in enumerate(c['coordinates']):
        lo=min(m['integer_lower_left_bounds'][k%2][0]+rects[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes']);hi=max(m['integer_lower_left_bounds'][k%2][1]+rects[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes']);var(index,f'rect_{ci}_{k}',[lo,hi])
    assert [r['mode'] for r in c['mode_links']]==[m['mode'] for m in owner['modes']]
    for links,m in zip(c['mode_links'],owner['modes']):
        offsets=rects[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'];assert len(links['constraints'])==4
        for k,ct in enumerate(links['constraints']):linear(ct,{c['coordinates'][k]:1,owner['positions'][k%2]:-1},offsets[k],offsets[k],m['selector'])
expected_pairs=[[a['component'],b['component']] for a,b in combinations(components,2) if a['owner']!=b['owner']];assert len(expected_pairs)==19 and [r['components'] for r in mapping['pairs']]==expected_pairs
for pair in mapping['pairs']:
    ai,bi=pair['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];assert len(pair['selectors'])==len(pair['constraints'])==4
    for d,(selector,ct,coeff) in enumerate(zip(pair['selectors'],pair['constraints'],[{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}])):var(selector,f'separate_{ai}_{bi}_{d}',[0,1]);linear(ct,coeff,MIN,-3,selector)
    linear(pair['one_direction_constraint'],{v:1 for v in pair['selectors']},1,1)
assert [r['owners'] for r in mapping['copy_order']]==[[0,1],[2,3]]
for order in mapping['copy_order']:
    a,b=[owners[i] for i in order['owners']];assert a['identity'][0]==b['identity'][0]
    assert [(m['mode'],m['integer_lower_left_bounds'],m['normalized_geometry']) for m in a['modes']]==[(m['mode'],m['integer_lower_left_bounds'],m['normalized_geometry']) for m in b['modes']]
    assert [(r['geometry'],r['region']) for r in a['unary_regions']]==[(r['geometry'],r['region']) for r in b['unary_regions']]
    lo=min(m['integer_lower_left_bounds'][1][0] for m in a['modes']);hi=max(m['integer_lower_left_bounds'][1][1] for m in a['modes']);scale=hi-lo+1;assert order['x_scale']==scale
    linear(order['constraint'],{a['positions'][0]:scale,b['positions'][0]:-scale,a['positions'][1]:1,b['positions'][1]:-1},MIN,0)
assert uv==set(range(len(p.variables))) and uc==set(range(len(p.constraints)))
charges=load(PREVIOUS/'model/preparation-charges.json');del charges['cp_model_build_seconds'];charges['component_factorization_seconds']=load(FACTOR/'checks.json')['seconds'];charges['continuous_pair_domain_seconds']=load(PAIR/'checks.json')['seconds'];charges['continuous_fine_block_bound_seconds']=load(PROOF/'checks.json')['seconds'];charges['continuous_block_count_filter_seconds']=load(COUNT/'checks.json')['seconds'];charges['cp_model_build_seconds']=load(MODEL/'checks.json')['seconds'];assert charges==load(MODEL/'preparation-charges.json') and sum(charges.values())==load(MODEL/'checks.json')['preparation_seconds_charged']
write(OUT/'source-bindings.json',bindings);inputs=[Path(__file__)]+[MODEL/n for n in ['plan.json','checks.json','model.pb','model.pbtxt','mapping.json','preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'variables_verified':len(uv),'constraints_verified':len(uc),'original_copies':4,'source_mode_options':12,'source_region_selectors':96,'source_mode_geometry_region_keys':81,'rigid_source_rectangles':6,'complete_different_owner_pairs':13,'compatible_fixed_site_choices':3,'every_compatible_use_has_identical_source_options':True,'canonical_copy_relabelling_valid':True,'all_model_fields_exhaustively_verified':True,'preparation_seconds_charged':sum(charges.values()),'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
