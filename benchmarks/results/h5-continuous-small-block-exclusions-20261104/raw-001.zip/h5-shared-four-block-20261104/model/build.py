"""Build the common two-bracket/two-insert source block for three independent decompositions."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';COUNT=ROOT/'output/h5-first55-continuous-block-filtered-20261104';FACTOR=ROOT/'output/h5-first55-component-factorization-20261029';PREVIOUS=ROOT/'output/h5-first55-fine-components-model-20261029';BASE=ROOT/'output/h5-shared-four-block-20261104';OUT=BASE/'model';PROOF=ROOT/'output/h5-shared-five-fine-domain-bound-20261104';PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(FACTOR/'audit/checks.json')['passed'] and load(COUNT/'audit/checks.json')['passed'] and load(GEO/'geometry-audit/checks.json')['passed'];BASE.mkdir();OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
source=load(COUNT/'all18-filtered-bounds.json');factor=load(FACTOR/'all18-factorizations.json');uses=[];keys=None
for row,graph in zip(source,factor):
    for distribution in graph['distributions']:
        if distribution['counts'] not in row['remaining_distributions']:continue
        for block,total,families in zip(graph['independent_blocks'],distribution['block_copy_totals'],distribution['block_family_totals']):
            if len(graph['independent_blocks'])<2 or families!={'bracket':2,'insert':2}:continue
            selected=sorted(tuple(a[:4]) for a in row['region_component_assignments'] if a[4] in block)
            if keys is None:keys=selected
            assert keys==selected
            uses.append({'empty_sites':row['empty_sites'],'counts':distribution['counts'],'block_groups':block})
assert len(uses)==3 and [u['empty_sites'] for u in uses]==[[0,11],[0,12],[0,13]]
modes=load(GEO/'family-modes.json');unary=load(GEO/'unary-templates.json');rects=load(GEO/'mode-rectangles.json');model=cp_model.CpModel();owners=[]
identities=[['bracket',0],['bracket',1],['insert',15],['insert',16]]
def linear(coeff,lo,hi,guard=None):
    ct=model.add_linear_constraint(sum(c*model.get_int_var_from_proto_index(i) for i,c in coeff.items() if c),lo,hi)
    if guard is not None:ct.only_enforce_if(model.get_bool_var_from_proto_index(guard))
    return ct.index
for i,identity in enumerate(identities):
    family=identity[0];allowed_modes=sorted({m for f,m,gid,ri in keys if f==family});selected=[m for m in modes[family] if m['mode'] in allowed_modes];positions=[]
    for axis in [0,1]:positions.append(model.new_int_var(min(m['integer_lower_left_bounds'][axis][0] for m in selected),max(m['integer_lower_left_bounds'][axis][1] for m in selected),f'position_{i}_{axis}').index)
    owners.append({'owner':i,'identity':identity,'positions':positions,'modes':[],'unary_regions':[],'geometry_marginals':[]})
for owner in owners:
    i=owner['owner'];family=owner['identity'][0];allowed_modes=sorted({m for f,m,gid,ri in keys if f==family})
    for source_mode in modes[family]:
        if source_mode['mode'] not in allowed_modes:continue
        selector=model.new_bool_var(f'mode_{i}_{source_mode["mode"]}').index;stock=[]
        for axis,var in enumerate(owner['positions']):stock.append(linear({var:1},*source_mode['integer_lower_left_bounds'][axis],selector))
        owner['modes'].append({**source_mode,'selector':selector,'stock_constraints':stock})
    owner['one_mode_constraint']=linear({m['selector']:1 for m in owner['modes']},1,1)
for owner in owners:
    i=owner['owner'];family=owner['identity'][0]
    for gid,ri in sorted({(g,r) for f,m,g,r in keys if f==family}):
        region=next(r for r in unary[gid]['regions'] if r['region']==ri);assert all(set(region['required_empty_sites'])<=set(u['empty_sites']) for u in uses)
        selector=model.new_bool_var(f'unary_{i}_{gid}_{ri}').index;constraints=[]
        for plane in region['planes']:constraints.append(linear(dict(zip(owner['positions'],plane['coefficients'])),cp_model.INT_MIN,plane['upper'],selector))
        owner['unary_regions'].append({'geometry':gid,'region':ri,'selector':selector,'plane_constraints':constraints})
    owner['one_region_constraint']=linear({r['selector']:1 for r in owner['unary_regions']},1,1)
    for gid in sorted({m['normalized_geometry'] for m in owner['modes']}):
        ms=[m for m in owner['modes'] if m['normalized_geometry']==gid];rs=[r for r in owner['unary_regions'] if r['geometry']==gid]
        assert all((family,m['mode'],gid,r['region']) in keys for m in ms for r in rs)
        owner['geometry_marginals'].append({'geometry':gid,'constraint':linear({**{m['selector']:-1 for m in ms},**{r['selector']:1 for r in rs}},0,0)})
components=[]
for owner in owners:
    family=owner['identity'][0]
    for piece in range(2 if family=='bracket' else 1):
        ci=len(components);coords=[]
        for k in range(4):
            lo=min(m['integer_lower_left_bounds'][k%2][0]+rects[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes']);hi=max(m['integer_lower_left_bounds'][k%2][1]+rects[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes']);coords.append(model.new_int_var(lo,hi,f'rect_{ci}_{k}').index)
        links=[]
        for m in owner['modes']:
            offsets=rects[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'];links.append({'mode':m['mode'],'constraints':[linear({var:1,owner['positions'][k%2]:-1},offset,offset,m['selector']) for k,(var,offset) in enumerate(zip(coords,offsets))]})
        components.append({'component':ci,'owner':owner['owner'],'piece':piece,'coordinates':coords,'mode_links':links})
pairs=[]
for i,A in enumerate(components):
    for B in components[i+1:]:
        if A['owner']==B['owner']:continue
        a,b=A['coordinates'],B['coordinates'];selectors=[];constraints=[]
        for d,coeff in enumerate([{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}]):
            var=model.new_bool_var(f'separate_{A["component"]}_{B["component"]}_{d}').index;selectors.append(var);constraints.append(linear(coeff,cp_model.INT_MIN,-3,var))
        pairs.append({'components':[A['component'],B['component']],'selectors':selectors,'constraints':constraints,'one_direction_constraint':linear({v:1 for v in selectors},1,1)})
order=[]
for family in ['bracket','insert']:
    peers=[o for o in owners if o['identity'][0]==family]
    for a,b in zip(peers,peers[1:]):
        lo=min(m['integer_lower_left_bounds'][1][0] for m in a['modes']);hi=max(m['integer_lower_left_bounds'][1][1] for m in a['modes']);scale=hi-lo+1
        order.append({'owners':[a['owner'],b['owner']],'x_scale':scale,'constraint':linear({a['positions'][0]:scale,b['positions'][0]:-scale,a['positions'][1]:1,b['positions'][1]:-1},cp_model.INT_MIN,0)})
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
mapping={'identities':identities,'source_options':[list(k) for k in keys],'compatible_uses':uses,'owners':owners,'components':components,'pairs':pairs,'copy_order':order,'position_units_per_mm':10,'world_origin_mm':[0,2100],'rectangle_gap_grid':3};write(OUT/'mapping.json',mapping);elapsed=time.perf_counter()-started
charges=load(PREVIOUS/'model/preparation-charges.json');del charges['cp_model_build_seconds'];charges['component_factorization_seconds']=load(FACTOR/'checks.json')['seconds'];charges['continuous_pair_domain_seconds']=load(PAIR/'checks.json')['seconds'];charges['continuous_fine_block_bound_seconds']=load(PROOF/'checks.json')['seconds'];charges['continuous_block_count_filter_seconds']=load(COUNT/'checks.json')['seconds'];charges['cp_model_build_seconds']=elapsed;write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),PROOF/'plan.json',PROOF/'checks.json',PROOF/'audit/plan.json',PROOF/'audit/checks.json',PAIR/'checks.json',COUNT/'checks.json',COUNT/'plan.json',COUNT/'audit/plan.json',COUNT/'audit/checks.json',COUNT/'all18-filtered-bounds.json',FACTOR/'plan.json',FACTOR/'checks.json',FACTOR/'audit/plan.json',FACTOR/'audit/checks.json',FACTOR/'all18-factorizations.json',PREVIOUS/'model/plan.json',PREVIOUS/'model/preparation-charges.json']+[GEO/n for n in ['plan.json','family-modes.json','unary-templates.json','mode-rectangles.json','inventory.json','geometry-audit/plan.json','geometry-audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Select the common independent two-bracket/two-insert block from all retained factorizations with that family inventory. Verify equality of every original mode/geometry/region option across its three uses. Build the complete local0.1mm source-hull construction for those four copies, with rigid outward source rectangles, all different-owner rectangle separations and valid interchangeable-copy ordering. This is a partial construction only; no negative result excludes a continuous source domain or an allocation.','maximum_calls':1,'algorithm_seconds':60,'shared_seconds':90,'retry_permitted':False,'solver_calls':0})
checks={'passed':True,'seconds':elapsed,'preparation_seconds_charged':sum(charges.values()),'owners':len(owners),'mode_selectors':sum(len(o['modes']) for o in owners),'unary_selectors':sum(len(o['unary_regions']) for o in owners),'rigid_rectangles':len(components),'different_owner_rectangle_pairs':len(pairs),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'compatible_site_choices':len(uses),'model_sha256':digest(OUT/'model.pb'),'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
