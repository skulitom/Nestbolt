"""Source-region-conditioned strip capacities for the retained four-part option domain."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,combinations_with_replacement
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time,math
import numpy as np
ROOT=Path(__file__).resolve().parents[1];PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';FINE=ROOT/'output/h5-shared-five-fine-domain-bound-20261104';COVER=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';OUT=ROOT/'output/h5-shared-four-strip-bound-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(FINE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');start=time.perf_counter()
nodes=load(PAIR/'nodes.json');keys={tuple(n['key']):i for i,n in enumerate(nodes)};compat=[int(s,16) for s in load(PAIR/'compatibility.json')];bad={tuple(c['nodes']) for c in load(FINE/'subset-certificates.json') if len(c['nodes'])<=4}
br=[i for i,n in enumerate(nodes) if n['key'][0]=='bracket'];ins=[i for i,n in enumerate(nodes) if n['key'][0]=='insert'];candidates=[]
for a,b in combinations_with_replacement(br,2):
    if not compat[a]>>b&1:continue
    choices=[i for i in ins if compat[a]>>i&1 and compat[b]>>i&1]
    for c,d in combinations_with_replacement(choices,2):
        if not compat[c]>>d&1:continue
        whole=(a,b,c,d)
        if not any(sub in bad for k in range(1,5) for sub in combinations(whole,k)):candidates.append(whole)
spans=[{} for _ in nodes]
for row in load(COVER/'source-fine-covers.json'):
    i=keys.get(tuple(row['source_key']))
    if i is None:continue
    for y,l,r in row['band_spans_tenths_mm']:spans[i].setdefault(y,[]).append((l,r))
grid=load(FINE/'grid.json');x0=grid['x_origin_tenths_mm'];x1=grid['x_end_tenths_mm'];y0=grid['y_origin_two_mm_rows'];y1=grid['y_end_two_mm_rows'];w=x1-x0
strips=[]
for axis,lo,hi in [(0,x0/10,x1/10),(1,y0*2,y1*2)]:
    cuts=range(math.floor(lo/10)*10,math.ceil(hi/10)*10+1,10)
    strips.extend((axis,l,r) for l,r in combinations(cuts,2))
left=np.array([l for a,l,r in strips],dtype=float);right=np.array([r for a,l,r in strips],dtype=float);axes=np.array([a for a,l,r in strips]);forced=np.zeros((len(nodes),len(strips)))
for i,n in enumerate(nodes):
    boxes=[list(map(float,map(F,b))) for b in n['contained_rectangles_mm']];bounds=list(map(float,map(F,n['translation_bounds_mm'])))
    for axis in [0,1]:
        mask=axes==axis;L=left[mask];R=right[mask];lo,hi=bounds[axis],bounds[axis+2];ts=[np.full(len(L),lo),np.full(len(L),hi)]
        for b in boxes:
            for edge in [b[axis],b[axis+2]]:ts.extend([np.clip(L-edge,lo,hi),np.clip(R-edge,lo,hi)])
        best=np.full(len(L),np.inf)
        for t in ts:
            value=sum((b[3-axis]-b[1-axis])*np.maximum(0,np.minimum(t+b[axis+2],R)-np.maximum(t+b[axis],L)) for b in boxes)
            best=np.minimum(best,value)
        forced[i,mask]=best
def merge(seq):
    merged=[]
    for l,r in sorted(seq):
        if merged and l<=merged[-1][1]:merged[-1]=(merged[-1][0],max(merged[-1][1],r))
        else:merged.append((l,r))
    return merged
def exact_min(i,axis,L,R):
    n=nodes[i];bounds=list(map(F,n['translation_bounds_mm']));lo,hi=bounds[axis],bounds[axis+2];boxes=[list(map(F,b)) for b in n['contained_rectangles_mm']];points={lo,hi}
    for b in boxes:
        for edge in [b[axis],b[axis+2]]:
            for v in [L-edge,R-edge]:
                if lo<=v<=hi:points.add(v)
    return min(sum((b[3-axis]-b[1-axis])*max(F(0),min(t+b[axis+2],R)-max(t+b[axis],L)) for b in boxes) for t in points)
certs=[];retained=[];processed=0;positive_screens=0;best_margin=-float('inf');sample=None
for whole in candidates:
    if time.perf_counter()-start>=58:break
    rows={}
    for i in set(whole):
        for y,intervals in spans[i].items():rows.setdefault(y,[]).extend(intervals)
    rows={y:merge(intervals) for y,intervals in rows.items()};dx=np.zeros(w+1,dtype=np.int64);yw=np.zeros(y1-y0,dtype=np.int64)
    for y,intervals in rows.items():
        for l,r in intervals:dx[l-x0]+=1;dx[r-x0]-=1;yw[y-y0]+=r-l
    xp=np.concatenate(([0],np.cumsum(np.cumsum(dx)[:-1])));yp=np.concatenate(([0],np.cumsum(yw)))
    upper=np.zeros(len(strips),dtype=np.int64)
    for axis,prefix,origin,scale in [(0,xp,x0,10),(1,yp,y0,.5)]:
        mask=axes==axis;ls=np.clip((left[mask]*scale-origin).astype(np.int64),0,len(prefix)-1);rs=np.clip((right[mask]*scale-origin).astype(np.int64),0,len(prefix)-1);upper[mask]=prefix[rs]-prefix[ls]
    lower=np.sum(forced[list(whole)],axis=0);margin=lower-upper/5;idx=int(np.argmax(margin))
    if float(margin[idx])>best_margin:best_margin=float(margin[idx]);sample={'nodes':whole,'strip':strips[idx],'screen_margin_mm2':best_margin}
    excluded=False
    for si in np.flatnonzero(margin>1e-5):
        positive_screens+=1;axis,L,R=strips[int(si)];exact=sum(exact_min(i,axis,F(L),F(R)) for i in whole);available=F(int(upper[si]),5)
        if exact>available:
            certs.append({'nodes':whole,'axis':axis,'strip_mm':[L,R],'upper_support_area_mm2':str(available),'lower_source_area_mm2':str(exact)});excluded=True;break
    if not excluded:retained.append(whole)
    processed+=1
retained.extend(candidates[processed:]);elapsed=time.perf_counter()-start
inputs=[Path(__file__),PAIR/'plan.json',PAIR/'nodes.json',PAIR/'compatibility.json']+[FINE/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','subset-certificates.json','grid.json']]+[COVER/n for n in ['plan.json','audit/plan.json','audit/checks.json','source-fine-covers.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Regenerate all two-bracket/two-insert necessary multisets under the audited pair and fine subset certificates. For each retained multiset, screen every axis strip on a 10 mm boundary grid enclosing its support. The available area is the exact fine-support union clipped to the strip. Each option lower bound is the minimum sum of its contained rectangles clipped to the strip over the original source translation projection; exact minima occur at interval endpoints or overlap breakpoints. Floating arithmetic only screens; emit a certificate only after exact rational lower/upper comparison. Retain all unprocessed multisets at the 58-second stop.','discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'solver_calls':0,'native_calls':0})
write(OUT/'strips.json',strips);write(OUT/'initial-option-multisets.json',candidates);write(OUT/'retained-option-multisets.json',retained);write(OUT/'strip-certificates.json',certs)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'scan_complete':processed==len(candidates),'initial_necessary_option_multisets':len(candidates),'processed_multisets':processed,'strips_per_multiset':len(strips),'strip_screens':processed*len(strips),'exact_positive_certificates':len(certs),'positive_float_screens_checked_exactly':positive_screens,'necessary_option_multisets_remaining':len(retained),'best_screen_sample':sample,'continuous_block_excluded_pending_audit':not retained,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
