"""Independent exact rectangle clipping, support intervals and retained-domain readback."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,combinations_with_replacement
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';FINE=ROOT/'output/h5-shared-five-fine-domain-bound-20261104';COVER=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';BASE=ROOT/'output/h5-shared-four-strip-bound-20261104';OUT=BASE/'audit';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(FINE/'audit/checks.json')['passed'];nodes=load(PAIR/'nodes.json');keys={tuple(n['key']):i for i,n in enumerate(nodes)};unary=load(PRIOR/'integer-preparation/unary-templates.json');boxes=[];bounds=[]
for n in nodes:
    f,m,gid,ri=n['key'];hull=[list(map(F,p)) for p in next(r for r in unary[gid]['regions'] if r['region']==ri)['hull_vertices']];b=[min(p[a] for p in hull) for a in [0,1]]+[max(p[a] for p in hull) for a in [0,1]]
    assert list(map(F,n['translation_bounds_mm']))==b;bounds.append(b);boxes.append([list(map(F,b)) for b in n['contained_rectangles_mm']])
compat=[int(s,16) for s in load(PAIR/'compatibility.json')];bad={tuple(c['nodes']) for c in load(FINE/'subset-certificates.json') if len(c['nodes'])<=4};initial=[];br=[i for i,n in enumerate(nodes) if n['key'][0]=='bracket'];ins=[i for i,n in enumerate(nodes) if n['key'][0]=='insert']
for a,b in combinations_with_replacement(br,2):
    for c,d in combinations_with_replacement(ins,2):
        whole=(a,b,c,d)
        if not all(compat[i]>>j&1 for i,j in combinations(whole,2)):continue
        if not any(sub in bad for k in range(1,5) for sub in combinations(whole,k)):initial.append(whole)
assert [list(v) for v in initial]==load(BASE/'initial-option-multisets.json') and len(initial)==8529
spans=[{} for _ in nodes]
for row in load(COVER/'source-fine-covers.json'):
    i=keys.get(tuple(row['source_key']))
    if i is not None:
        for y,l,r in row['band_spans_tenths_mm']:spans[i].setdefault(y,[]).append((l,r))
clip_operations=0
def clip(poly,axis,edge,keep_greater):
    global clip_operations
    clip_operations+=1;result=[]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        a=(p[axis]>=edge) if keep_greater else (p[axis]<=edge);b=(q[axis]>=edge) if keep_greater else (q[axis]<=edge)
        if a:result.append(p)
        if a!=b:
            t=(edge-p[axis])/(q[axis]-p[axis]);result.append([p[k]+t*(q[k]-p[k]) for k in [0,1]])
    return result
def area(poly):return abs(sum(p[0]*q[1]-q[0]*p[1] for p,q in zip(poly,poly[1:]+poly[:1])))/2
@lru_cache(None)
def lower(i,axis,L,R):
    lo,hi=bounds[i][axis],bounds[i][axis+2];breakpoints={lo,hi}
    for b in boxes[i]:
        for v in [L-b[axis],R-b[axis],L-b[axis+2],R-b[axis+2]]:
            if lo<=v<=hi:breakpoints.add(v)
    # Rectangle/strip intersection is continuous piecewise linear in this translation.
    values=[]
    for t in breakpoints:
        value=F(0)
        for l,b,r,top in boxes[i]:
            poly=[[l,b],[r,b],[r,top],[l,top]]
            for p in poly:p[axis]+=t
            poly=clip(clip(poly,axis,F(L),True),axis,F(R),False)
            value+=area(poly)
        values.append(value)
    return min(values)
certs=load(BASE/'strip-certificates.json');excluded=set();source_rows=0
for c in certs:
    whole=tuple(c['nodes']);assert whole in initial and whole not in excluded;axis=c['axis'];L,R=c['strip_mm'];assert axis in [0,1] and L<R
    rows={}
    for i in set(whole):
        for y,intervals in spans[i].items():rows.setdefault(y,[]).extend(intervals)
    upper=F(0)
    for y,intervals in rows.items():
        merged=[]
        for l,r in sorted(intervals):
            if merged and l<=merged[-1][1]:merged[-1]=(merged[-1][0],max(merged[-1][1],r))
            else:merged.append((l,r))
        height=F(2) if axis==0 else max(F(0),min(F(2*y+2),F(R))-max(F(2*y),F(L)))
        for l,r in merged:
            width=F(r-l,10) if axis==1 else max(F(0),min(F(r,10),F(R))-max(F(l,10),F(L)))
            upper+=height*width
        source_rows+=1
    required=sum(lower(i,axis,L,R) for i in whole)
    assert str(upper)==c['upper_support_area_mm2'] and str(required)==c['lower_source_area_mm2'] and required>upper
    excluded.add(whole)
retained=[v for v in initial if v not in excluded];assert [list(v) for v in retained]==load(BASE/'retained-option-multisets.json')
checks=load(BASE/'checks.json');assert len(excluded)==checks['exact_positive_certificates']==7374 and len(retained)==1155 and checks['cap_overrun_seconds']==0
write(OUT/'source-bindings.json',bindings);write(OUT/'retained-option-multisets.json',retained)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','initial-option-multisets.json','retained-option-multisets.json','strip-certificates.json','strips.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'independent_method':'Recover each original convex-hull translation projection. Clip exact rational translated source rectangles to each certificate strip and minimize at every overlap breakpoint and both domain endpoints. Compute upper support areas using merged intervals and exact strip intersections. Re-enumerate all original four-option multisets and retain exactly those with no audited certificate. The nonpositive floating screens are not infeasibility evidence.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'original_continuous_source_options':81,'initial_multisets_verified':len(initial),'exact_strip_certificates_verified':len(excluded),'independent_polygon_clip_operations':clip_operations,'independent_support_rows_verified':source_rows,'cached_exact_source_strip_minima':lower.cache_info().currsize,'necessary_option_multisets_remaining':len(retained),'continuous_source_block_excluded':False,'new_count_distribution_exclusions':0,'remaining_count_distributions':39,'remaining_site_choices':18,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
