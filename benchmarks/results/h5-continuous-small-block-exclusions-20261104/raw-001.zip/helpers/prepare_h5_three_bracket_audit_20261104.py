from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_shared_four_difference_domains_20261104.py').read_text(encoding='utf-8')
s=s.replace('from fractions import Fraction as F','from fractions import Fraction as F\nfrom itertools import combinations,combinations_with_replacement')
s=s.replace('h5-shared-four-strip-bound-20261104','h5-shared-five-subset-domain-bound-20261029').replace('h5-shared-four-difference-bound-20261104','h5-shared-three-bracket-difference-bound-20261104').replace('audit-v2','audit')
s=s.replace("initial=load(PRIOR/'audit/retained-option-multisets.json');nodes=load(PAIR/'nodes.json');", "nodes=load(PAIR/'nodes.json');compat=[int(v,16) for v in load(PAIR/'compatibility.json')];br=[i for i,n in enumerate(nodes) if n['key'][0]=='bracket'];initial=[list(v) for v in combinations_with_replacement(br,3) if all(compat[i]>>j&1 for i,j in combinations(v,2))];assert initial==load(BASE/'initial-option-multisets.json');")
s=s.replace('len(clauses)==13','len(clauses)==12').replace('len(excluded)==1155','len(excluded)==40').replace('All 1155 prior surviving multisets','All 40 pair-compatible three-bracket multisets').replace("['plan.json','checks.json','exclusion-certificates.json'", "['plan.json','checks.json','initial-option-multisets.json','exclusion-certificates.json'")
p=ROOT/'output/audit_h5_three_bracket_domains_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
