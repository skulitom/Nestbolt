from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('filter_h5_smaller_block_counts_20261104.py','filter_h5_direct_smaller_block_counts_20261104.py'),('audit_h5_smaller_block_counts_20261104.py','audit_h5_direct_smaller_block_counts_20261104.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-first55-continuous-block-filtered-20261104','h5-first55-direct-fine-filtered-components-20261029').replace('h5-shared-four-difference-bound-20261104','h5-shared-four-direct-difference-bound-20261104').replace('h5-first55-smaller-block-filtered-20261104','h5-first55-direct-smaller-block-filtered-20261104').replace("'prior_distributions':39","'prior_distributions':42").replace('len(excluded)==15','len(excluded)==18').replace("'new_count_distribution_exclusions':15","'new_count_distribution_exclusions':18")
    if old.startswith('audit_'):
        s=s.replace("write(OUT/'source-bindings.json',bindings)", "assert (BASE/'all-filtered-bounds.json').read_bytes()==(ROOT/'output/h5-first55-smaller-block-filtered-20261104/all-filtered-bounds.json').read_bytes()\nwrite(OUT/'source-bindings.json',bindings)")
        s=s.replace("'all_surviving_source_fields_unchanged':True", "'all_surviving_source_fields_unchanged':True,'retained_bytes_identical_to_sequential_proof':True")
    p=ROOT/'output'/new;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared direct original42 to retained24 filtering and independent audit.')
