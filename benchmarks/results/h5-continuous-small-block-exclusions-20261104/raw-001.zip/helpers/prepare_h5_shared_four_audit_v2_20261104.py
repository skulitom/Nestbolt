from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'output/audit_h5_shared_four_block_20261104.py'
s=source.read_text(encoding='utf-8');assert s.count('len(expected_pairs)==19')==1
s=s.replace('len(expected_pairs)==19','len(expected_pairs)==13').replace("OUT=BASE/'model-audit'","OUT=BASE/'model-audit-v2'")
p=ROOT/'output/audit_h5_shared_four_block_v2_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_shared_four_block_20261104.py').read_text(encoding='utf-8').replace('model-audit','model-audit-v2')
p=ROOT/'output/run_h5_shared_four_block_v2_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Preserved first auditor; corrected expected pair inventory from 19 to 13 in v2.')
