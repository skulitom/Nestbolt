"""Prepare a new four-part construction after independent continuous exclusion of five."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def write(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def common(s):
    return s.replace('h5-shared-five-block-20261029','h5-shared-four-block-20261104').replace('h5-first55-direct-fine-filtered-components-20261029','h5-first55-continuous-block-filtered-20261104').replace("'bracket':2,'insert':3","'bracket':2,'insert':2").replace(",['insert',17]",'').replace('two-bracket/three-insert','two-bracket/two-insert').replace('five-part','four-part').replace('five copies','four copies')
proof=";PROOF=ROOT/'output/h5-shared-five-fine-domain-bound-20261104';PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029'"
charges="charges['continuous_pair_domain_seconds']=load(PAIR/'checks.json')['seconds'];charges['continuous_fine_block_bound_seconds']=load(PROOF/'checks.json')['seconds'];charges['continuous_block_count_filter_seconds']=load(COUNT/'checks.json')['seconds'];"
s=common((ROOT/'output/build_h5_shared_five_block_20261029.py').read_text(encoding='utf-8'))
s=s.replace("OUT=BASE/'model'","OUT=BASE/'model'"+proof)
s=s.replace("for distribution in graph['distributions']:\n", "for distribution in graph['distributions']:\n        if distribution['counts'] not in row['remaining_distributions']:continue\n")
s=s.replace("charges['cp_model_build_seconds']=elapsed;",charges+"charges['cp_model_build_seconds']=elapsed;")
s=s.replace("inputs=[Path(__file__),", "inputs=[Path(__file__),PROOF/'plan.json',PROOF/'checks.json',PROOF/'audit/plan.json',PROOF/'audit/checks.json',PAIR/'checks.json',COUNT/'checks.json',")
write('build_h5_shared_four_block_20261104.py',s)
s=common((ROOT/'output/check_h5_shared_five_block_candidate_20261029.py').read_text(encoding='utf-8'))
s=s.replace('58','57').replace('1136','1090').replace('232','228').replace('72','71').replace('[18,19,20]','[17,18,19,20]').replace('shared-source5','shared-source4').replace("'shared_block_originals':5","'shared_block_originals':4").replace("'remaining_originals':8","'remaining_originals':9")
write('check_h5_shared_four_block_candidate_20261104.py',s)
s=common((ROOT/'output/run_h5_shared_five_block_20261029.py').read_text(encoding='utf-8'))
s=s.replace('check_h5_shared_five_block_candidate_20261029.py','check_h5_shared_four_block_candidate_20261104.py').replace('source_valid58','source_valid57')
write('run_h5_shared_four_block_20261104.py',s)
s=common((ROOT/'output/audit_h5_shared_five_block_20261029.py').read_text(encoding='utf-8'))
s=s.replace("PREVIOUS=ROOT/'output/h5-first55-fine-components-model-20261029'","PREVIOUS=ROOT/'output/h5-first55-fine-components-model-20261029'"+proof)
s=s.replace('assert len(p.variables)==259 and len(p.constraints)==708','assert len(p.variables)==192')
s=s.replace('len(owners)==5','len(owners)==4').replace('[[0,1],[2,3],[3,4]]','[[0,1],[2,3]]')
s=s.replace('uv==set(range(259)) and uc==set(range(708))','uv==set(range(len(p.variables))) and uc==set(range(len(p.constraints)))')
s=s.replace("charges['cp_model_build_seconds']=load(MODEL/'checks.json')['seconds'];",charges+"charges['cp_model_build_seconds']=load(MODEL/'checks.json')['seconds'];")
s=s.replace("'original_copies':5,'source_mode_options':16,'source_region_selectors':129", "'original_copies':4,'source_mode_options':12,'source_region_selectors':96").replace("'rigid_source_rectangles':7,'complete_different_owner_pairs':19","'rigid_source_rectangles':6,'complete_different_owner_pairs':13")
write('audit_h5_shared_four_block_20261104.py',s)
print('Prepared the four-part model, exhaustive auditor, single-call runner and original-source checker.')
