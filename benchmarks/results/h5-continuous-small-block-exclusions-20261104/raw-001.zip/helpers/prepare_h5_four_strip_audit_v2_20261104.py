from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_shared_four_strips_20261104.py').read_text(encoding='utf-8')
a="def area(poly):return abs(sum(p[0]*q[1]-q[0]*p[1] for p,q in zip(poly,poly[1:]+poly[:1])))/2"
b="def area(poly):return abs(sum((p[0]*q[1]-q[0]*p[1] for p,q in zip(poly,poly[1:]+poly[:1])),F(0)))/2"
assert s.count(a)==1;s=s.replace(a,b).replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'")
s=s.replace("assert str(upper)==c['upper_support_area_mm2'] and str(required)==c['lower_source_area_mm2'] and required>upper", "assert str(upper)==c['upper_support_area_mm2'] and str(required)==c['lower_source_area_mm2'] and required>upper,(c,str(upper),str(required))")
p=ROOT/'output/audit_h5_shared_four_strips_v2_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Preserved first audit; empty clipped polygons now return exact rational zero.')
