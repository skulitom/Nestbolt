from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_shared_five_response_20261029.py').read_text(encoding='utf-8')
s=s.replace('h5-shared-five-block-20261029','h5-shared-four-block-20261104').replace('model-audit','model-audit-v2').replace('len(model.variables)==259 and len(model.constraints)==708','len(model.variables)==192 and len(model.constraints)==527').replace("result['returned_response_branches']==59","result['returned_response_branches']==51").replace('source_valid58','source_valid57')
p=ROOT/'output/audit_h5_shared_four_response_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
