"""Archive independently checked continuous exclusions and the one closed grid call."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-continuous-small-block-exclusions-20261104';OUT=ROOT/'benchmarks/results'/NAME
names=['h5-shared-five-fine-domain-bound-20261104','h5-first55-continuous-block-filtered-20261104','h5-shared-four-block-20261104','h5-shared-four-strip-bound-20261104','h5-shared-four-difference-bound-20261104','h5-shared-three-bracket-difference-bound-20261104','h5-first55-smaller-block-filtered-20261104','h5-shared-four-direct-difference-bound-20261104','h5-first55-direct-smaller-block-filtered-20261104']
FIVE,FILTER1,MODEL,STRIP,DIFF,THREE,FILTER2,DIRECT,FINAL=[ROOT/'output'/n for n in names]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,v):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(v)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
assert git('rev-parse','HEAD')=='114bcf656ac727ef9681b7b2f52b0b4f9759baa8' and not git('diff','HEAD','--name-only')
proofs=[FIVE/'audit/checks.json',FILTER1/'audit/checks.json',MODEL/'model-audit-v2/checks.json',MODEL/'response-audit/checks.json',STRIP/'audit-v2/checks.json',DIFF/'audit/checks.json',THREE/'audit/checks.json',FILTER2/'audit/checks.json',DIRECT/'audit/checks.json',FINAL/'audit/checks.json']
assert all(load(p)['passed'] for p in proofs)
assert load(FIVE/'audit/checks.json')['exact_subset_certificates_verified']==28903 and load(FIVE/'audit/checks.json')['continuous_source_block_excluded']
assert load(STRIP/'audit-v2/checks.json')['exact_strip_certificates_verified']==7374
assert load(DIFF/'audit/checks.json')['complete_disjunction_trees_verified']==1155
assert load(THREE/'audit/checks.json')['complete_disjunction_trees_verified']==40
assert load(DIRECT/'audit/checks.json')['complete_disjunction_trees_verified']==14336
assert all(load(p/'audit/checks.json')['continuous_source_block_excluded'] for p in [DIFF,THREE,DIRECT])
assert load(FINAL/'audit/checks.json')['remaining_count_distributions']==24 and load(FINAL/'audit/checks.json')['remaining_site_choices']==14 and load(FINAL/'audit/checks.json')['retained_bytes_identical_to_sequential_proof']
response=load(MODEL/'response-audit/checks.json');assert response['closed_solver_calls']==1 and response['solver_status']=='INFEASIBLE' and response['assignments']==0 and response['overall_algorithm_shared_overruns_seconds']==0 and not response['independent_unsat_certificate_available']
assert digest(ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json')=='8b7fa5f6ad765aab6fdba1a586c29d8cac2cce607ed1d7fcd0fb6938c4eeada0'
assert digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json';assert sum(r['excluded_by'] is None for r in load(frontier))==440
production=source_digest();assert production=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
assert not git('diff','379761aa..HEAD','--','crates','web/src','scripts')
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(name,p):
    assert p.is_file() and '.claude' not in p.parts;members[name]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [ROOT/'output'/n for n in names]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=set()
for pattern in ['*h5*five*fine*20261104.py','*h5*four*20261104.py','*h5*three*20261104.py','*h5*block*counts*20261104.py','*h5*small*20261104.py']:
    helpers.update((ROOT/'output').glob(pattern))
helpers.update(ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name])
for p in sorted(helpers):add('helpers/'+p.name,p)
add('publication/ci-repair-push-receipt.json',ROOT/'output/ci-runner-main-sync-20261104/receipt.json')
while queue:
    path=queue.pop()
    if path in seen:continue
    seen.add(path)
    if path.name in ['plan.json','opened.json']:
        for name,h in load(path).get('inputs',{}).items():
            p=ROOT/name;assert p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts) and digest(p)==h,name;bindings[name]=h;add('source-inputs/'+name,p)
    elif path.suffix=='.py':
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    p=ROOT/folder/(module+'.py')
                    if p.is_file():add('imported-helpers/'+folder+'/'+p.name,p)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for p,name in [(FIVE/'checks.json','five-preparation.json'),(FIVE/'audit/checks.json','five-audit.json'),(MODEL/'model-audit-v2/checks.json','four-model-audit.json'),(MODEL/'response-audit/checks.json','four-response-audit.json'),(STRIP/'checks.json','strip-preparation.json'),(STRIP/'audit-v2/checks.json','strip-audit.json'),(DIFF/'audit/checks.json','four-sequential-proof-audit.json'),(THREE/'checks.json','three-preparation.json'),(THREE/'audit/checks.json','three-audit.json'),(DIRECT/'checks.json','four-direct-preparation.json'),(DIRECT/'audit/checks.json','four-direct-audit.json'),(FINAL/'checks.json','direct-count-preparation.json'),(FINAL/'audit/checks.json','direct-count-audit.json'),(FINAL/'all-filtered-bounds.json','remaining-counts.json'),(FINAL/'next-step.json','next-step.json')]:shutil.copyfile(p,OUT/name)
ci=json.loads(subprocess.check_output(['gh','run','view','41848153978','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));write(OUT/'main-ci-snapshot.json',ci)
review={'utc':datetime.now(timezone.utc).isoformat(),'source_head':git('rev-parse','HEAD'),'production_digest':production,'current_readmes':{p.name:digest(p) for p in ROOT.glob('README*.md')},'remote_ornament_commit_preserved':'34e408df358f04f2dc168fd17ed7ffcd4509ace3','sparrow_head':'6067f007f02758b1a477be51b5a03a2f72db298b','sparrow_change_only_benchmark_archives':True,'studio_head':'c0bb9e8671defc5c25a02feb91789601a08f2e75','stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_ci_run':41848153978,'main_ci_status':ci['status'],'main_ci_conclusion':ci['conclusion'],'normal_push_requires_no_active_main_run_and_all_six_passing':True,'reserved_H2_vectors_opened':0}
write(OUT/'publication-review.json',review)
write(OUT/'checks.json',{'passed':True,**archive,'continuous_three_bracket_exclusion_proven':True,'continuous_two_bracket_two_insert_exclusion_proven':True,'source_count_distributions_before':42,'source_count_distributions_after':24,'restricted_site_choices_before':18,'restricted_site_choices_after':14,'restricted_sites_excluded':[[0,11],[0,12],[0,13],[0,14]],'closed_new_grid_solver_calls':1,'grid_solver_status':'INFEASIBLE','grid_independent_unsat_certificate_available':False,'source_assignments_created':0,'valid64_preserved':True,'valid_short11_preserved':True,'source_valid66_created':False,'remaining_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False,'native_calls':0,'release_created':False})
report=f'''# Continuous small-block exclusions — 2026-11-04

Exact source-domain proofs remove **18 of 42 count distributions** and **four of
18 restricted cog-site choices**. The matching first sheet now has 24 necessary
distributions over 14 site choices. [The retained table]({NAME}/remaining-counts.json)
and [independent count audit]({NAME}/direct-count-audit.json) preserve every
surviving source group, mode attribution and geometric field. This does not
exclude any of the 440 whole-job allocation candidates or prove a placement.

The common lower-left region cannot hold three brackets, or two brackets with
two inserts. Each proof uses original continuous translation intervals and
rectangles independently known to lie inside the original source parts.
Required Euclidean clearance implies an axis gap of at least 0.149 mm for one
of four relative directions. Exact difference constraints prove that every
possible branch contradicts the source intervals. The independent auditor uses
rational Floyd-Warshall closure rather than the producer's scaled integer
incremental closure.

| Evidence | Independently checked result |
|---|---|
| [Direct four-part proof]({NAME}/four-direct-audit.json) | All 14,336 pair-compatible combinations excluded; 38,306 proof nodes checked |
| [Three-bracket proof]({NAME}/three-audit.json) | All 40 combinations excluded; 113 proof nodes checked |
| [Earlier five-part support proof]({NAME}/five-audit.json) | 28,903 exact subset certificates; all 139,124 pair-compatible combinations excluded |
| [Four-part strip refinement]({NAME}/strip-audit.json) | 7,374 exact certificates reduce 8,529 combinations to 1,155; independent source-polygon clipping passes |
| [Sequential difference proof]({NAME}/four-sequential-proof-audit.json) | All 1,155 strip survivors excluded |

The final direct proof takes 2.738666 s of preparation and does not use the
fine-support or strip exclusions. The three-bracket proof takes 0.008494 s.
Direct filtering of the original 42 distributions yields exactly the same
bytes as the longer sequential derivation. Removed empty-site pairs are
`[0,11]`, `[0,12]`, `[0,13]` and `[0,14]`.

The [four-part grid model]({NAME}/four-model-audit.json) has 192 variables and
527 independently checked constraints. Its sole call returned INFEASIBLE:
45.235264 s charged preparation, 0.052230 s solving, 45.995583 s algorithm and
46.066749 s shared time, with no overrun. [Response readback]({NAME}/four-response-audit.json)
passes. The grid response has no independent unsat certificate and is not used
as the continuous proof. The call remains closed; no assignment or native
validation was produced.

Two failed audit attempts are preserved in the archive: a copied five-part
pair-count expectation, and a floating zero from an empty clipping polygon.
Their corrected auditors pass without changing the models or certificates.

The byte-verified archive contains {archive['archive_members']} canonical files,
{archive['verified_aliases']} identical-content aliases and {archive['archive_bytes']:,}
compressed bytes in {archive['archive_parts']} independently readable ZIPs.
[The manifest]({NAME}/raw-manifest.json) and [source bindings]({NAME}/source-bindings.json)
cover the new records and their recursively required source evidence.

Main's new ornament example and README changes are preserved. The separate
[CI runner correction](ci-python-runner-recovery-20261104.md) retains the frozen
Python generator runtime. [The current CI snapshot]({NAME}/main-ci-snapshot.json)
records its state at archive time; a later evidence push waits for all six jobs.
Sparrow changed only benchmark archives; Sparrow Studio and release versions
remain unchanged. Product source is unchanged.

H2 and H5 remain open at **60%**. The original H2 gate and all 22 unopened vectors
remain untouched; no new release qualifies. The valid 64-part layout and valid
11-part short sheet are preserved. [Next work]({NAME}/next-step.json) rebuilds
and independently audits a smaller first55 model using the direct proofs,
then requires full66 original-source validation before native and material checks.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 continuous small-block exclusions:** [the independent proofs]({link}) rule out three brackets and two brackets with two inserts in the common source region. They remove18 of42 count distributions and four of18 restricted site choices, leaving24 distributions over14 choices. The direct difference-constraint proof covers all14336 four-part combinations without the earlier strip pass; a separate rational closure audit verifies every branch. The new four-part grid call is closed INFEASIBLE with no placement and no overruns; it is not the continuous proof. All440 whole-job allocations, full66 validation and the H5 matrix remain open. H2/H5 remain open at60%; no new release qualifies.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [direct capacities, component factorization and shared block](../benchmarks/results/h5-direct-capacities-component-factorization-and-shared-block-20261029.md).';new=f'Latest H5 evidence: [continuous small-block exclusions](../benchmarks/results/{NAME}.md).';assert s.count(old)==1
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s.replace(old,new,1))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'remaining_distributions':24,'remaining_site_choices':14,'main_CI':ci['status'],'completion_percent':60})
