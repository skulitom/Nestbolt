from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/bound_h5_shared_four_difference_domains_20261104.py').read_text(encoding='utf-8')
s=s.replace('from math import lcm','from math import lcm\nfrom itertools import combinations,combinations_with_replacement')
s=s.replace('h5-shared-four-strip-bound-20261104','h5-shared-five-subset-domain-bound-20261029').replace('h5-shared-four-difference-bound-20261104','h5-shared-three-bracket-difference-bound-20261104').replace('audit-v2','audit')
a="initial=load(PRIOR/'audit/retained-option-multisets.json');"
b="compatible=[int(v,16) for v in load(PAIR/'compatibility.json')];br=[i for i,n in enumerate(nodes) if n['key'][0]=='bracket'];initial=[list(v) for v in combinations_with_replacement(br,3) if all(compatible[i]>>j&1 for i,j in combinations(v,2))];"
assert a in s;s=s.replace(a,b)
s=s.replace('matrices=[]\n    for axis','size=len(whole)+1;matrices=[]\n    for axis').replace('range(5)','range(len(old))')
s=s.replace('for j in range(len(old))] for i in range(len(old))])','for j in range(size)] for i in range(size)])')
s=s.replace("PAIR/'nodes.json',FIRST/'plan.json'", "PAIR/'nodes.json',PAIR/'compatibility.json',FIRST/'plan.json'")
s=s.replace(",'audit/retained-option-multisets.json'",'')
s=s.replace("write(OUT/'exclusion-certificates.json',certs);", "write(OUT/'initial-option-multisets.json',initial);write(OUT/'exclusion-certificates.json',certs);")
p=ROOT/'output/bound_h5_three_bracket_domains_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared three-bracket source-domain bound with dynamically sized matrices.')
