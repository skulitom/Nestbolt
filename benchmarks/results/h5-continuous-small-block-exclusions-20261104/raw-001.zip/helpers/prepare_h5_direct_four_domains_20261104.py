from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/bound_h5_three_bracket_domains_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-shared-three-bracket-difference-bound-20261104','h5-shared-four-direct-difference-bound-20261104')
a="initial=[list(v) for v in combinations_with_replacement(br,3) if all(compatible[i]>>j&1 for i,j in combinations(v,2))];"
b="ins=[i for i,n in enumerate(nodes) if n['key'][0]=='insert'];initial=[]\nfor a,b in combinations_with_replacement(br,2):\n    if not compatible[a]>>b&1:continue\n    choices=[i for i in ins if compatible[a]>>i&1 and compatible[b]>>i&1]\n    initial.extend([a,b,c,d] for c,d in combinations_with_replacement(choices,2) if compatible[c]>>d&1)\n"
assert a in s;s=s.replace(a,b)
p=ROOT/'output/bound_h5_direct_four_domains_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared direct four-part interval proof; no fine-area or strip exclusions are inputs.')
