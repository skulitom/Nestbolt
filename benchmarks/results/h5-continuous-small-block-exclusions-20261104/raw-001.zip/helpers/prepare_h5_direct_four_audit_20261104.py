from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_three_bracket_domains_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-shared-three-bracket-difference-bound-20261104','h5-shared-four-direct-difference-bound-20261104')
a="initial=[list(v) for v in combinations_with_replacement(br,3) if all(compat[i]>>j&1 for i,j in combinations(v,2))];"
b="ins=[i for i,n in enumerate(nodes) if n['key'][0]=='insert'];initial=[list(ab+cd) for ab in combinations_with_replacement(br,2) for cd in combinations_with_replacement(ins,2) if all(compat[i]>>j&1 for i,j in combinations(ab+cd,2))];"
assert a in s;s=s.replace(a,b).replace('len(clauses)==12','len(clauses)==13').replace('len(excluded)==40','len(excluded)==14336').replace('All 40 pair-compatible three-bracket multisets','All 14336 pair-compatible four-part multisets')
p=ROOT/'output/audit_h5_direct_four_domains_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
