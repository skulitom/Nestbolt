"""Apply independently proved four-part and three-bracket continuous exclusions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029';PAIR=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';FOUR=ROOT/'output/h5-shared-four-direct-difference-bound-20261104';THREE=ROOT/'output/h5-shared-three-bracket-difference-bound-20261104';OUT=ROOT/'output/h5-first55-direct-smaller-block-filtered-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
for base in [FOUR,THREE]:assert load(base/'audit/checks.json')['passed'] and load(base/'audit/checks.json')['continuous_source_block_excluded']
assert load(PRIOR/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'filter.py');started=time.perf_counter();keys={tuple(n['key']) for n in load(PAIR/'nodes.json')};rows=load(PRIOR/'all18-filtered-bounds.json');remaining=[];certs=[]
for row in rows:
    groups={f:[] for f in ['bracket','insert']};options={}
    for gi,g in enumerate(row['groups']):
        source={tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi}
        if source and source<=keys:groups[g['family']].append(gi);options[gi]=sorted(source)
    kept=[]
    for counts in row['remaining_distributions']:
        totals={f:sum(counts[g] for g in gs) for f,gs in groups.items()};reason='three_brackets' if totals['bracket']>=3 else ('two_brackets_two_inserts' if totals['bracket']>=2 and totals['insert']>=2 else None)
        if reason:certs.append({'empty_sites':row['empty_sites'],'counts':counts,'proof':reason,'covered_groups':groups,'covered_family_counts':totals,'source_options_by_group':options})
        else:kept.append(counts)
    if kept:remaining.append({**row,'remaining_distributions':kept})
elapsed=time.perf_counter()-started;inputs=[Path(__file__),PAIR/'nodes.json']+[PRIOR/n for n in ['plan.json','audit/plan.json','audit/checks.json','all18-filtered-bounds.json']]+[base/n for base in [FOUR,THREE] for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','audit/retained-option-multisets.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Each source component whose complete option set is covered by the proved common domain must contain fewer than three brackets, and cannot contain two brackets with two inserts. Apply these two impossible-subset conditions to exact original component counts. Preserve all surviving count rows, source groups and assignments; exclude a site choice only if none of its original remaining distributions survives.','global_allocation_exclusion_permitted':False,'packing_solver_calls':0,'native_calls':0})
write(OUT/'exclusion-certificates.json',certs);write(OUT/'all-filtered-bounds.json',remaining)
checks={'passed':True,'seconds':elapsed,'prior_distributions':42,'new_count_distribution_exclusions':len(certs),'remaining_count_distributions':sum(len(r['remaining_distributions']) for r in remaining),'prior_site_choices':18,'remaining_site_choices':len(remaining),'excluded_site_choices':[r['empty_sites'] for r in rows if r['empty_sites'] not in [v['empty_sites'] for v in remaining]],'independent_audit_required':True,'remaining_allocation_candidates':440,'global_allocation_exclusions':0,'packing_solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
