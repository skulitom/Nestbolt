"""Independently read the sole individual-cog model response, assignments and charges."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from h5_source_projection_short_core_reader_20261029 import violations
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json',MODEL/'plan.json',BASE/'model-audit/plan.json',SEARCH/'opened.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name;bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
opened,result,process,budget=[load(SEARCH/n) for n in ['opened.json','result.json','process.json','budget.json']];ma=load(BASE/'model-audit/checks.json');assert ma['passed']
assert digest(MODEL/'model.pb')==digest(SEARCH/'model.pb')==opened['model_sha256']==ma['model_sha256']
model=cp_model_pb2.CpModelProto();model.ParseFromString((SEARCH/'model.pb').read_bytes());assert len(model.variables)==ma['variables_verified']==load(MODEL/'checks.json')['variables'] and len(model.constraints)==ma['constraints_verified']==load(MODEL/'checks.json')['constraints'] and {f.name for f,v in model.ListFields()}=={'variables','constraints','solution_hint'}
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes());status=cp_model_pb2.CpSolverStatus.Name(response.status);assert status==result['status'] and status in ['UNKNOWN','INFEASIBLE','FEASIBLE','OPTIMAL']
parameters=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
assert {f.name for f,v in parameters.ListFields()}=={'max_time_in_seconds','num_search_workers','random_seed','log_search_progress','log_to_stdout','ignore_subsolvers'}
assert parameters.max_time_in_seconds==opened['parameters']['max_time_in_seconds']==result['allocated_solve_seconds'] and parameters.max_time_in_seconds>0
assert parameters.num_search_workers==4 and parameters.random_seed==0 and parameters.log_search_progress and not parameters.log_to_stdout and list(parameters.ignore_subsolvers)==['fj']
assert response.num_branches==result['returned_response_branches'] and response.num_conflicts==result['returned_response_conflicts'] and response.wall_time==result['solver_wall_seconds']
assert result['closed'] and result['solver_calls']==1 and not result['any_allocation_excluded'] and process['closed'] and process['exit_code']==0 and not process['timeout']
assert opened['maximum_calls']==budget['maximum_calls']==1 and not opened['retry_permitted'] and not budget['retry_permitted']
charge=load(MODEL/'budget.json')['preparation_seconds_charged'];charges=load(MODEL/'final-preparation-charges.json')
assert charge==sum(charges.values())==opened['preparation_seconds_charged']==budget['preparation_seconds_charged']==result['preparation_seconds_charged']==ma['complete_preparation_seconds_charged']
assert charges['direct_short9_inventory_complete_process_seconds']==load(ROOT/'output/h5-first57-direct-short9-process-20261104/process.json')['complete_process_seconds']
assert process['job']['closed'] and process['job']['active_processes']==0 and process['job']['reason_code']==process['job']['error_code']==0 and process['tree_closed']
supervisor=load(SEARCH/'supervisor-opened.json')
for name,h in supervisor['inputs'].items():assert digest(ROOT/name)==h
assert supervisor['aggregate_memory_bytes']==2*1024**3 and not supervisor['retry_permitted'] and supervisor['preparation_seconds_charged']==charge
assert opened['source_validation_reserve_seconds']==budget['source_validation_reserve_seconds']==4 and charge+parameters.max_time_in_seconds<=56
assert result['algorithm_overrun_seconds']==max(0.,result['algorithm_seconds_including_preparation']-60)
assert result['returned_solve_overrun_seconds']==max(0.,result['returned_solve_seconds']-result['allocated_solve_seconds'])
assert process['seconds_including_preparation']>=result['algorithm_seconds_including_preparation']>=charge+result['returned_solve_seconds'] and result['returned_solve_seconds']>=response.wall_time
incumbents=sorted((SEARCH/'incumbents').glob('*.json'));assert len(incumbents)==result['incumbents_recorded'];assignment_checks=[]
for i,p in enumerate(incumbents):
    row=load(p);assert row['sequence']==i;checked=violations(model,row['values']);assert not checked['failed_constraints'];assignment_checks.append({'file':p.name,'checked':checked})
source_valid=False;source_calls=0
if response.solution:
    assert status in ['FEASIBLE','OPTIMAL'] and result['has_assignment'];values=load(SEARCH/'assignment.json');assert values==list(response.solution);checked=violations(model,values);assert not checked['failed_constraints'] and checked==load(SEARCH/'assignment-check.json')
    source=load(SEARCH/'source-response/original-source-checks.json');summary=load(SEARCH/'source-response/checks.json');rows=load(SEARCH/'source-response/candidate-source66.json')
    assert source['originals']==summary['originals']==len(rows)==66 and source['same_sheet_pairs']==summary['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026
    assert source['pair_failures']==sum(not p['passed'] for p in source['pairs']) and source['stock_failures']==sum(not p['passed'] for p in source['stock'])
    assert source['valid']==(source['pair_failures']==source['stock_failures']==0)
    source_valid=source['valid'];source_calls=1
    assert summary['source_valid66']==source_valid and (SEARCH/'source-check-stderr.txt').read_text()==''
else:
    assert status in ['UNKNOWN','INFEASIBLE'] and not result['has_assignment'] and not incumbents and not (SEARCH/'assignment.json').exists() and not (SEARCH/'source-response').exists()
assert result['source_checker_calls']==source_calls and result['source_valid66']==source_valid and result['native_calls']==0
assert (SEARCH/'stderr.txt').read_text()=='';log=(SEARCH/'solver.log').read_text();assert 'status: '+status in log
if 'Lp debug' in log and 'Lp pool' in log:
    with (OUT/'lp-diagnostics.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(log[log.index('Lp debug'):log.index('Lp pool')])
write(OUT/'source-bindings.json',bindings);write(OUT/'incumbent-checks.json',assignment_checks)
inputs=[Path(__file__),ROOT/'output/h5_source_projection_short_core_reader_20261029.py',BASE/'plan.json',MODEL/'plan.json',MODEL/'checks.json',MODEL/'budget.json',MODEL/'final-preparation-charges.json',MODEL/'build-process.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json']+[p for p in SEARCH.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read the frozen model and response protobufs, all parameters, source bindings, preparation charges and parent/child timings. Independently evaluate every returned assignment and incumbent against all model domains and constraints. If a candidate exists, require the separately reconstructed66-original source check with1632 pairs,264 stock edges,90 holes and10026 hole vertices. Preserve unknown results and all overruns; solver infeasibility alone is not an independent continuous proof.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_input_bindings_verified':len(bindings),'closed_solver_calls':1,'windows_job_descendants_closed':True,'solver_status':status,'branches':response.num_branches,'conflicts':response.num_conflicts,'incumbents_verified':len(incumbents),'assignments':int(bool(response.solution)),'source_checker_calls':source_calls,'source_valid66':source_valid,'preparation_seconds_charged':charge,'allocated_solve_seconds':result['allocated_solve_seconds'],'returned_solve_seconds':result['returned_solve_seconds'],'solve_slice_overrun_seconds':result['returned_solve_overrun_seconds'],'algorithm_seconds_including_preparation':result['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':process['seconds_including_preparation'],'algorithm_overrun_seconds':result['algorithm_overrun_seconds'],'shared_overrun_seconds':max(0,process['seconds_including_preparation']-90),'independent_unsat_certificate_available':False,'continuous_source_domain_excluded':False,'any_allocation_excluded':False,'remaining_allocation_candidates':440,'count_capacity_tables_used':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
