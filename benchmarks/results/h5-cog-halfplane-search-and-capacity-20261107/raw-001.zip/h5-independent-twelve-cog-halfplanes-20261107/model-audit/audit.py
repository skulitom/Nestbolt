"""Exhaustive independent readback of the typed support-halfplane/pocket model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-twelve-cog-integer-20261107';GEOM=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';MODEL=GEOM/'model';OUT=GEOM/'model-audit';PRE=ROOT/'output/h5-independent-twelve-cog-checkpoint-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[MODEL/'plan.json'];seen=set();bindings={}
while queue:
    z=queue.pop()
    if z in seen:continue
    seen.add(z)
    for name,h in load(z).get('inputs',{}).items():
        pth=ROOT/name;assert pth.is_relative_to(ROOT) and not {'.claude','.cache'}&set(pth.parts) and digest(pth)==h,name;bindings[name]=h
        if pth.name in ['plan.json','opened.json'] or pth.name.endswith('process.json'):queue.append(pth)
assert load(BASE/'audit/checks.json')['passed'] and load(GEOM/'audit-v2/checks.json')['passed'] and load(PRE/'checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'}
real=cp_model.CpModel();assert real.proto.parse_text_format(text_format.MessageToString(p));assert real.validate()=='';del real
mapping=load(MODEL/'mapping.json');assert set(mapping)=={'owners','cog_interactions','rigid_components','rectangle_separations','symmetry_constraints','partial_cog_hint','position_units_per_mm','world_origin_mm','rectangle_gap_grid'}
assert mapping['position_units_per_mm']==100 and mapping['world_origin_mm']==[0,2100] and mapping['rectangle_gap_grid']==23
owners=mapping['owners'];instances=load(BASE/'instances.json');modes=load(BASE/'family-modes.json');inventory=load(BASE/'inventory.json');templates={t['class']:t for t in load(GEOM/'templates.json')};aliases=load(BASE/'aliases.json')
assert len(owners)==28 and [o['identity'] for o in owners]==[r['identity'] for r in instances]==inventory['moving16_orthogonal_identities']+inventory['required_cog12_identities']
assert len(set(tuple(o['identity']) for o in owners))==28 and all(o['identity'][0]=='cog' for o in owners[16:])
used_vars=set();used_ct=set();max_activity=0
def variable(i,name,domain):
    assert i not in used_vars;used_vars.add(i);v=p.variables[i];assert v.name==name and list(v.domain)==domain and {f.name for f,x in v.ListFields()}=={'name','domain'}
def linear(i,co,lo,hi,guard=None):
    global max_activity
    assert i not in used_ct;used_ct.add(i);c=p.constraints[i];co={k:v for k,v in co.items() if v}
    assert c.WhichOneof('constraint')=='linear' and list(c.enforcement_literal)==([] if guard is None else [guard]) and {f.name for f,x in c.ListFields()}=={'linear'}|({'enforcement_literal'} if guard is not None else set())
    assert len(c.linear.vars)==len(co) and dict(zip(c.linear.vars,c.linear.coeffs))==co and list(c.linear.domain)==[lo,hi]
    bound=sum(abs(coeff)*max(abs(v) for v in p.variables[vi].domain) for vi,coeff in co.items());assert bound<2**53;max_activity=max(max_activity,bound)
mode_count=0
for i,o in enumerate(owners):
    assert set(o)=={'owner','identity','positions','modes','one_mode_constraint'} and o['owner']==i and o['positions']==[2*i,2*i+1]
    opts=modes[o['identity'][0]];assert len(o['modes'])==len(opts)
    for k in [0,1]:variable(2*i+k,f'world_{i}_{k}_grid',[min(m['integer_world_lower_left_bounds'][k][0] for m in opts),max(m['integer_world_lower_left_bounds'][k][1] for m in opts)])
    for a,b in zip(o['modes'],opts):
        assert {k:v for k,v in a.items() if k not in ['selector','stock_constraints']}==b and len(a['stock_constraints'])==2
        variable(a['selector'],f'mode_{i}_{b["mode"]}',[0,1])
        for k in [0,1]:linear(a['stock_constraints'][k],{o['positions'][k]:1},*b['integer_world_lower_left_bounds'][k],a['selector'])
        mode_count+=1
    linear(o['one_mode_constraint'],{m['selector']:1 for m in o['modes']},1,1)
pairs=mapping['cog_interactions'];source_pairs=load(BASE/'owner-pairs.json');assert len(pairs)==len(source_pairs)==258
expected_physical={tuple(sorted((a,b))) for a,b in combinations(range(28),2) if a>=16 or b>=16};seen_physical=set();links=selectors=planes=marginals=coords=0
for pi,(r,s) in enumerate(zip(pairs,source_pairs)):
    assert {k:v for k,v in r.items() if k not in ['pair','canonical_positions','coordinate_links','regions','class_marginals','one_region_constraint']}==s and r['pair']==pi
    ai,bi=s['owners'];a,b=owners[ai],owners[bi];physical=tuple(sorted((ai,bi)));assert physical not in seen_physical;seen_physical.add(physical)
    if s['kind']=='cog_orthogonal':
        assert ai>=16 and bi<16;family=b['identity'][0];maps={x['mode']:x for x in aliases if x['family']==family};z=r['canonical_positions'];assert len(z)==2 and len(r['coordinate_links'])==len(b['modes'])
        for k,vi in enumerate(z):variable(vi,f'canonical_{ai}_{bi}_{k}_grid',[min(x['canonical_relative_grid_bounds'][k][0] for x in maps.values()),max(x['canonical_relative_grid_bounds'][k][1] for x in maps.values())]);coords+=1
        for link,mode in zip(r['coordinate_links'],b['modes']):
            alias=maps[mode['mode']];q=alias['matrix'];shift=alias['offset_grid'];assert link['mode']==mode['mode'] and link['selector']==mode['selector'] and link['class']==alias['class'] and link['matrix']==q and link['offset_grid']==shift and len(link['constraints'])==2
            # Exact equation z_k - sum_j Q_kj*(world_Bj-world_Aj) = K_k.
            for k,ci in enumerate(link['constraints']):
                co={z[k]:1}
                for j in [0,1]:co[b['positions'][j]]=-q[k][j];co[a['positions'][j]]=q[k][j]
                linear(ci,co,shift[k],shift[k],mode['selector']);links+=1
                # The declared aux domain includes all endpoints for this mode.
                assert p.variables[z[k]].domain[0]<=alias['canonical_relative_grid_bounds'][k][0]<=alias['canonical_relative_grid_bounds'][k][1]<=p.variables[z[k]].domain[-1]
    else:
        assert s['kind']=='cog_cog' and 16<=ai<bi<28 and r['canonical_positions'] is None and not r['coordinate_links'] and not r['class_marginals']
    expected_regions=[]
    for cid in s['classes']:
        t=templates[cid]
        expected_regions.extend((cid,'halfplane',h) for h in t['retained_halfplane_ids'])
        expected_regions.extend((cid,'pocket',q['region']) for q in t['pockets'])
    assert [(v['class'],v['kind'],v['source_id']) for v in r['regions']]==expected_regions
    for v in r['regions']:
        cid,kind,rid,sel=v['class'],v['kind'],v['source_id'],v['selector'];variable(sel,f'pair_choice_{pi}_{cid}_{kind}_{rid}',[0,1]);selectors+=1
        assert set(v)=={'class','kind','source_id','selector','source_edges','constraints'}
        if kind=='halfplane':
            source=templates[cid]['halfplanes'][rid];assert source['halfplane']==rid and rid in templates[cid]['retained_halfplane_ids'] and v['source_edges']==[] and len(v['constraints'])==1
            expected=[(source['coefficients'],source['lower'],2**63-1)]
        else:
            assert kind=='pocket';source=next(q for q in templates[cid]['pockets'] if q['region']==rid)
            assert v['source_edges']==source['retained_edges'] and len(v['constraints'])==len(source['retained_edges'])
            expected=[(source['planes'][edge]['coefficients'],MIN,source['planes'][edge]['upper']) for edge in source['retained_edges']]
        for ci,(coefs,lo,hi) in zip(v['constraints'],expected):
            nx,ny=coefs
            if s['kind']=='cog_orthogonal':co={r['canonical_positions'][0]:nx,r['canonical_positions'][1]:ny}
            else:co={b['positions'][0]:nx,b['positions'][1]:ny,a['positions'][0]:-nx,a['positions'][1]:-ny}
            linear(ci,co,lo,hi,sel);planes+=1
    linear(r['one_region_constraint'],{v['selector']:1 for v in r['regions']},1,1)
    if s['kind']=='cog_orthogonal':
        assert [v['class'] for v in r['class_marginals']]==s['classes']
        for v in r['class_marginals']:
            cid=v['class'];required_modes={x['mode'] for x in aliases if x['family']==b['identity'][0] and x['class']==cid};ms=[m['selector'] for m in b['modes'] if m['mode'] in required_modes];rs=[x['selector'] for x in r['regions'] if x['class']==cid]
            assert v['mode_selectors']==ms and v['region_selectors']==rs and ms and rs
            linear(v['constraint'],{**{x:-1 for x in ms},**{x:1 for x in rs}},0,0);marginals+=1
        assert sorted(x for v in r['class_marginals'] for x in v['mode_selectors'])==sorted(m['selector'] for m in b['modes'])
assert seen_physical==expected_physical and len(expected_physical)==258 and links==2304 and coords==384 and selectors==26538 and planes==53070
rectangles=load(BASE/'mode-rectangles.json');source_components=load(BASE/'components.json');components=mapping['rigid_components'];separations=mapping['rectangle_separations'];source_separations=load(BASE/'component-pairs.json');rect_links=0
assert len(components)==24 and len(separations)==268
for r,s in zip(components,source_components):
    assert {k:v for k,v in r.items() if k not in ['coordinates','mode_links']}==s;o=owners[s['owner']];family=o['identity'][0];piece=s['piece'];assert s['owner']<16 and len(r['coordinates'])==4
    for k,(vi,label) in enumerate(zip(r['coordinates'],['left','bottom','right','top'])):
        lo=min(m['integer_world_lower_left_bounds'][k%2][0]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in o['modes']);hi=max(m['integer_world_lower_left_bounds'][k%2][1]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in o['modes']);variable(vi,f'rect_{s["component"]}_{label}_grid',[lo,hi])
    assert len(r['mode_links'])==len(o['modes'])
    for link,m in zip(r['mode_links'],o['modes']):
        offsets=rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'];assert link['mode']==m['mode'] and link['mode_selector']==m['selector'] and link['offsets']==offsets and len(link['constraints'])==4
        for k,(ci,value) in enumerate(zip(link['constraints'],offsets)):linear(ci,{r['coordinates'][k]:1,o['positions'][k%2]:-1},value,value,m['selector']);rect_links+=1
for r,s in zip(separations,source_separations):
    assert r['components']==s['components'] and r['owners']==s['owners'];ai,bi=s['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];assert len(r['selectors'])==len(r['constraints'])==4
    for d,(vi,ci,co) in enumerate(zip(r['selectors'],r['constraints'],[{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}])):variable(vi,f'separate_{ai}_{bi}_{d}',[0,1]);linear(ci,co,MIN,-23,vi)
    linear(r['one_direction_constraint'],{v:1 for v in r['selectors']},1,1)
assert [r['components'] for r in separations]==[list(pair) for pair in combinations(range(24),2) if components[pair[0]]['owner']!=components[pair[1]]['owner']]
assert {tuple(sorted(r['owners'])) for r in separations}==set(combinations(range(16),2))
expected_sym=[]
for family in ['bracket','insert','cog']:
    peers=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1]);expected_sym.extend((family,[a['owner'],b['owner']]) for a,b in zip(peers,peers[1:]))
    for o in peers:
        assert [list(p.variables[v].domain) for v in o['positions']]==[list(p.variables[v].domain) for v in peers[0]['positions']]
        assert [{k:v for k,v in m.items() if k not in ['selector','stock_constraints']} for m in o['modes']]==[{k:v for k,v in m.items() if k not in ['selector','stock_constraints']} for m in peers[0]['modes']]
assert [(v['family'],v['owners']) for v in mapping['symmetry_constraints']]==expected_sym and len(expected_sym)==25
for v in mapping['symmetry_constraints']:
    a,b=v['owners'];linear(v['constraint'],{owners[a]['positions'][0]:1,owners[b]['positions'][0]:-1},MIN,0)
assert [o['identity'][1] for o in owners[16:]]==sorted(o['identity'][1] for o in owners[16:])
# Every cog pair uses an ordered difference. The complete adjacent chain implies
# all66 nonnegative-X domains without imposing a rigid row or fixing a cog.
assert [v['owners'] for v in mapping['symmetry_constraints'] if v['family']=='cog']==[[i,i+1] for i in range(16,27)]
hints={};positions=load(BASE/'control-positions.json');choices={tuple(v['owners']):(v['kind'],v['id']) for v in load(GEOM/'control-regions.json')}
for o,xy in zip(owners[16:],positions):hints.update({o['positions'][0]:xy[0],o['positions'][1]:xy[1]-210000,o['modes'][0]['selector']:1})
for pair in pairs:
    if pair['kind']=='cog_cog':hints.update({r['selector']:int((r['kind'],r['source_id'])==choices[tuple(pair['owners'])]) for r in pair['regions']})
assert mapping['partial_cog_hint']==[[i,v] for i,v in sorted(hints.items())] and list(p.solution_hint.vars)==sorted(hints) and list(p.solution_hint.values)==[hints[i] for i in sorted(hints)]
assert {f.name for f,v in p.solution_hint.ListFields()}=={'vars','values'} and len(hints)==5646
for vi,value in hints.items():assert p.variables[vi].domain[0]<=value<=p.variables[vi].domain[-1]
hint_constraints=0
for ct in p.constraints:
    if any(g not in hints for g in ct.enforcement_literal):continue
    if any(hints[g]==0 for g in ct.enforcement_literal):continue
    if not all(vi in hints for vi in ct.linear.vars):continue
    value=sum(hints[vi]*co for vi,co in zip(ct.linear.vars,ct.linear.coeffs));assert ct.linear.domain[0]<=value<=ct.linear.domain[-1];hint_constraints+=1
assert used_vars==set(range(len(p.variables))) and used_ct==set(range(len(p.constraints))) and mode_count==108 and rect_links==640 and marginals==288
counts=load(MODEL/'checks.json');assert counts['variables']==len(p.variables) and counts['constraints']==len(p.constraints) and counts['model_sha256']==digest(MODEL/'model.pb') and counts['canonical_coordinate_links']==links and counts['region_selectors']==selectors and counts['guarded_region_planes']==planes
charges=load(PRE/'preparation-charges.json');charges['halfplanes_complete_preparation_seconds']=load(ROOT/'output/h5-independent-twelve-cog-halfplanes-process-20261107/prepare.json')['complete_seconds'];charges['cp_model_build_seconds']=counts['seconds'];assert charges==load(MODEL/'preparation-charges.json') and sum(charges.values())==counts['preparation_seconds_charged']
process=load(MODEL/'build-process.json');assert process['exit_code']==0 and process['job']['closed'] and process['job']['active_processes']==0 and process['complete_process_seconds']>=charges['cp_model_build_seconds']
for name,h in process['inputs'].items():assert digest(ROOT/name)==h
assert process['script_sha256']==digest(ROOT/'output/build_h5_independent_twelve_cog_halfplane_model_20261107.py')
charges['cp_model_build_seconds']=process['complete_process_seconds'];assert charges==load(MODEL/'final-preparation-charges.json') and sum(charges.values())==load(MODEL/'budget.json')['preparation_seconds_charged']
assert load(MODEL/'validation.json')['validation']==''
assert not any(name.startswith('output/h5-independent-twelve-cog-integer-20261107/'+prefix) for name in bindings for prefix in ['model/','model-audit/','search/','memory-stop-audit/'])
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),ROOT/'output/prepare_h5_independent_twelve_cog_halfplane_model_helpers_20261107.py',ROOT/'output/audit_h5_independent_twelve_cog_model_20261107.py',GEOM/'plan.json',GEOM/'templates.json',GEOM/'control-regions.json',GEOM/'audit-v2/plan.json',GEOM/'audit-v2/checks.json',ROOT/'output/h5-independent-twelve-cog-halfplanes-process-20261107/prepare.json',BASE/'audit/plan.json',BASE/'audit/checks.json',PRE/'plan.json',PRE/'checks.json',PRE/'preparation-charges.json']+list(BASE.glob('*.json'))+[z for z in MODEL.glob('*') if z.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{z.relative_to(ROOT).as_posix():digest(z) for z in inputs},'method':'Read every protobuf field and all variable domains and guarded linear constraints. Independently reconstruct all28 owners,108 modes, exact canonical coordinate links and class marginals. Each retained typed exterior choice must use its certified integer LOWER bound; each retained pocket uses all its audited UPPER bounds. Verify all258 cog interactions and all120 orthogonal pairs through the complete24-component graph. Check all25 valid X-order conditions, each new partial-hint value and every fully hinted active constraint. Binary/text equality, actual solver import and complete new preparation/model process charges pass. Confirm the current failed predecessor model/search is absent from this input graph.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings_verified':len(bindings),'variables_verified':len(used_vars),'constraints_verified':len(used_ct),'original_movers_verified':28,'independent_cogs_verified':12,'world_position_variables':56,'source_mode_selectors_verified':108,'canonical_coordinate_variables_verified':coords,'canonical_mode_links_verified':links,'region_class_marginals_verified':marginals,'cog_physical_pairs_verified':258,'orthogonal_physical_pairs_verified':120,'region_selectors_verified':selectors,'guarded_source_planes_verified':planes,'rigid_components_verified':24,'rigid_component_links_verified':rect_links,'component_pairs_verified':268,'same_family_order_constraints_verified':25,'partial_hint_values_verified':len(hints),'fully_hinted_active_constraints_satisfied':hint_constraints,'all_model_fields_verified':True,'typed_lower_and_upper_geometry_bounds_verified':True,'current_failed_predecessor_model_or_search_consumed':False,'binary_text_models_identical':True,'actual_solver_import_validation_passed':True,'maximum_proto_linear_activity':max_activity,'complete_preparation_seconds_charged':sum(charges.values()),'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
