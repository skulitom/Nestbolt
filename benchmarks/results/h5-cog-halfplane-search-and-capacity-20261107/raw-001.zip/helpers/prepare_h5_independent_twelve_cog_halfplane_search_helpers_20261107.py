from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
runner=(ROOT/'output/run_h5_independent_twelve_cog_model_20261107.py').read_text(encoding='utf-8')
runner=runner.replace("BASE = ROOT / 'output/h5-independent-twelve-cog-integer-20261107'", "BASE = ROOT / 'output/h5-independent-twelve-cog-halfplanes-20261107'\nSOURCE = ROOT / 'output/h5-independent-twelve-cog-integer-20261107'")
runner=runner.replace('h5_independent_twelve_cog_candidate_20261107.py','h5_independent_twelve_cog_halfplane_candidate_20261107.py').replace('prepare_h5_independent_twelve_cog_search_helpers_20261107.py','prepare_h5_independent_twelve_cog_halfplane_search_helpers_20261107.py')
runner=runner.replace("BASE / 'audit'","BASE / 'audit-v2'").replace("BASE/'audit/plan.json'","BASE/'audit-v2/plan.json'").replace("BASE/'audit/checks.json'","BASE/'audit-v2/checks.json'")
for name in ['inventory.json','family-modes.json','aliases.json','owner-pairs.json','control-positions.json']:runner=runner.replace("BASE/'"+name+"'","SOURCE/'"+name+"'")
checker=(ROOT/'output/check_h5_independent_twelve_cog_candidate_20261107.py').read_text(encoding='utf-8')
checker=checker.replace("BASE=ROOT/'output/h5-independent-twelve-cog-integer-20261107';", "BASE=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';SOURCE=ROOT/'output/h5-independent-twelve-cog-integer-20261107';")
checker=checker.replace("BASE/'inventory.json'","SOURCE/'inventory.json'")
checker=checker.replace("'region':region['region']", "'choice_kind':region['kind'],'source_id':region['source_id']")
checker=checker.replace('verify all258 selected cog regions','verify all258 selected typed halfplane/pocket choices')
auditor=(ROOT/'output/audit_h5_independent_twelve_cog_response_20261107.py').read_text(encoding='utf-8').replace('h5-independent-twelve-cog-integer-20261107','h5-independent-twelve-cog-halfplanes-20261107')
for name,s in [('run_h5_independent_twelve_cog_halfplane_model_20261107.py',runner),('check_h5_independent_twelve_cog_halfplane_candidate_20261107.py',checker),('audit_h5_independent_twelve_cog_halfplane_response_20261107.py',auditor)]:
    ast.parse(s)
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Distinct single-call runner, typed source checker and response reader prepared.')
