from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-cog-halfplane-search-and-capacity-20261107';OUT=ROOT/'benchmarks/results'/NAME
H=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';C=ROOT/'output/h5-independent-cog-capacity-20261107';F=ROOT/'output/h5-cog-halfplane-capacity-checkpoint-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
front=load(F/'checks.json');assert front['passed'] and front['closed_solver_calls']==1 and front['solver_status']=='UNKNOWN' and not front['new_model_created']
inventory_ast=ast.parse((ROOT/'output/seal_h5_polygon_clearance_proofs_20261107.py').read_text(encoding='utf-8')).body
def assignment(node,name):return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
inventory_start=next(i for i,node in enumerate(inventory_ast) if assignment(node,'setup'));inventory_end=next(i for i,node in enumerate(inventory_ast) if assignment(node,'walker'))
exec(compile(ast.Module(body=inventory_ast[inventory_start:inventory_end],type_ignores=[]),'historical-parent-archives','exec'))
PARENTS.extend(ROOT/'benchmarks/results'/name for name in ['h5-polygon-clearance-proofs-20261107','h5-exact-circle-forest-20261107','h5-strip-capacity-models-20261107','h5-twelve-cog-row-construction-20261107','h5-twelve-cog-543-constructions-20261107','h5-independent-twelve-cog-preparation-20261107','h5-independent-cog-search-and-halfplanes-20261107'])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
exec(old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']"))
folders=[H,C,F]+[ROOT/'output'/n for n in ['h5-independent-twelve-cog-halfplane-model-process-20261107','h5-independent-cog-capacity-process-20261107']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*independent*twelve*cog*halfplane*20261107.py','*h5*independent*cog*capacity*20261107.py','*h5*cog*halfplane*capacity*20261107.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['ccd1.py','pack_h5_evidence_archive.py',walker.name,'seal_h5_polygon_clearance_proofs_20261107.py']:add('helpers/'+name,ROOT/'output'/name)
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'next-preparation-charges.json','next-preparation-charges.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(H/'model-audit/checks.json','model-audit.json'),(H/'model/final-preparation-charges.json','closed-model-preparation-charges.json'),(H/'response-audit/checks.json','response-audit.json'),(H/'search/process.json','closed-search-process.json'),(C/'audit/checks.json','capacity-source-audit.json'),(C/'checks.json','capacity-preparation.json'),(C/'capacity.json','capacity-stock.json'),(ROOT/'output/h5-independent-cog-capacity-process-20261107/process.json','capacity-process.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Cog halfplane search and exact source capacity — 2026-11-07

The smaller support-halfplane model completes its sole call **UNKNOWN**, with
no incumbent or placement. It stays within the overall 60/90-second and 2 GiB
limits. The call is closed. New exact source-contained rectangles now support
global packing constraints for a distinct model; that model has not been built.
Four fixed arrangements and all 440 whole allocations remain. H2/H5 stay open
at **60% completed milestone weight**.

## Complete model and independently read response

[Full serialized-model readback]({NAME}/model-audit.json) verifies all **28,254
variables and 58,169 constraints**, binary/text equality and an actual solver
import. All 28 movers, twelve independently positioned cogs, 108 source modes,
258 cog interactions and 120 orthogonal-owner interactions remain. Every typed
halfplane uses its certified lower bound and every pocket its upper-bound planes.
The 5,646-value partial cog hint satisfies all 221 fully hinted active constraints;
it does not place the sixteen orthogonal companions.

[Complete preparation]({NAME}/closed-model-preparation-charges.json) totals
**6.504612 seconds**, including the 2.573594-second complete new model build.
[The response audit]({NAME}/response-audit.json) verifies one four-worker,
seed-zero call: 48.670477 seconds allocated, 50.188645 seconds returned,
165,457 branches and 490 conflicts. **The 1.518168-second solve-slice overrun
is preserved**. Preparation-inclusive algorithm/shared totals are
**57.533015 / 57.630837 seconds**, below the original 60/90-second limits.

[The Windows Job record]({NAME}/closed-search-process.json) closes all three
processes with zero active descendants. Peak aggregate committed memory is
**2,102,865,920 bytes**, below 2,147,483,648. Unlike the preceding model's
memory stop, this call returns an actual response protobuf. Its status is
UNKNOWN, with no assignment, incumbent, source checker or native call.
It proves no continuous or whole-allocation exclusion and will not be repeated,
reseeded or extended. The raw LP diagnostics are preserved in the archive.

## New global necessary occupancy constraints

[The fresh preparation]({NAME}/capacity-preparation.json) retains all **13
source modes and 108 per-original mode options**. Each transformed L bracket
contributes two inset component rectangles; each insert contributes one.
For the 7-degree cog, 32 horizontal bands use every source vertex-height section
and both band edges. All common intervals are rounded inward on the 0.01 mm grid.
The resulting cog rectangles cover **90.562604%** of its filled outer area.
Holes remain part of the final source geometry; filled outer occupancy is used
because common-line part-in-hole remains disabled.

[Independent exact readback]({NAME}/capacity-source-audit.json) verifies
**101 rectangle-containment proofs and 5,104 source edge/box checks** using
rational values of the original vertices and actual affine coefficients.
For each rectangle, its center is inside the source outer and no source boundary
edge enters its open interior. Each mode's rectangles have disjoint interiors.
These checks cover 80 profile rectangles and 21 separate coarse rectangles.

The auditor independently partitions both projection axes at every source and
profile endpoint, checking **230 elementary slabs** and exact area conservation.
Expanding over every owner/mode gives **1,564 X-axis and 552 Y-axis profile
intervals**. The [outward-rounded stock]({NAME}/capacity-stock.json) permits
capacities 88,561 and 148,696 grid units respectively. Every rectangle stays
inside it at every source-mode domain extreme.

A separate coarse system has **172 optional rectangles**, with 36 active under
any full mode selection: 24 orthogonal components and twelve source-contained
cog squares. Each rectangle's two intervals must share the original mode
selector and translate rigidly with the original coordinates. This permits a
global NoOverlap2D constraint alongside the two cumulative profiles.
No count-capacity table, detached strip coordinate or omitted part is allowed.

[Both preparation and audit processes close successfully]({NAME}/capacity-process.json).
The complete new preparation takes **0.315775 seconds**; the separate complete
audit takes 2.133900 seconds. The current closed models/searches are absent from
the capacity geometry's input graph. Historical source provenance is retained.

## Next complete construction

[The next model specification]({NAME}/next-step.json) adds these globally
coupled necessary constraints while preserving all full pair halfplanes/pockets,
original modes, rigid component geometry and valid identical-copy ordering.
The [complete source-preparation ledger]({NAME}/next-preparation-charges.json)
is **4.246794 seconds before the new model build**, which must also be charged.
Every protobuf field and all capacity/rectangle assignments require independent
readback before one newly frozen call under the same limits.

No new complete model or search opens in this checkpoint. A source-valid 66-part
layout, native/material validation, production integration and the unchanged
complete H5 matrix remain required. H2 retains its original gate and unopened
reserved vectors. Production, READMEs and release assets remain unchanged.
[Main CI at review]({NAME}/main-ci-at-review.json) is preserved; no live run is
cancelled. A normal push waits for all six jobs and aggregate success.

[The archive]({NAME}/raw-manifest.json) contains {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes.
[Historical references]({NAME}/external-evidence.json) and
[source bindings]({NAME}/source-bindings.json) preserve all consumed evidence.
Independent archive verification is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-07 H5 halfplane search and exact capacity:** [complete model, response and source audits]({link}) verify 28,254 variables and 58,169 constraints. The sole call closes UNKNOWN with no incumbent or placement; preparation-inclusive algorithm/shared totals are 57.533015/57.630837 s and peak memory is 2,102,865,920 bytes. The 1.518168 s solve-slice overrun remains recorded. New source capacity checks verify 101 exact rectangle-containment proofs, 5,104 edge/box checks and 230 projection slabs across all 13 modes and 108 owner/mode options. Cog strips cover 90.562604% of the filled outer. The proposed global model has 1,564/552 projection intervals and 172 optional coarse rectangles, each rigidly coupled to its original mode and coordinates; all full pair geometry remains required. Complete source preparation is 4.246794 s before a fresh model build. No new model or solver call is opened; all closed calls stay closed. Four fixed arrangements and 440 allocations remain, with H2/H5 open at 60%. No release is made.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
s=s[:a]+f'''Latest H5 evidence: [halfplane search and exact source capacity](../benchmarks/results/{NAME}.md).
The smaller 28-mover model passes all 28,254 variable and 58,169 constraint
checks. Its sole call closes UNKNOWN without a placement, within the overall
time and memory limits. The solve-slice overrun is retained and the call stays
closed. New exact source-contained rectangles pass 101 containment proofs and
230 projection-slab checks across every original mode. They support global
capacity and coarse rectangle constraints for a distinct complete model,
while all full pair geometry remains mandatory. That model and its independent
protobuf audit are next; no new call is prepared.
Four fixed arrangements and all 440 allocations remain; full66 source/material/
native checks and the full H5 gate are open. H2/H5 stay open at 60%.
The current main c339bc7a CI snapshot is preserved in the report. The next normal
push waits for all six jobs and aggregate success; no release is made.
'''+s[b:]
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':True,**archive,'closed_solver_calls':1,'source_valid66':False})
