"""Generate a distinct full model and independent reader; never edit the closed model."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
old_build=ROOT/'output/build_h5_independent_twelve_cog_model_20261107.py'
old_audit=ROOT/'output/audit_h5_independent_twelve_cog_model_20261107.py'
b=old_build.read_text(encoding='utf-8')
b=b.replace('"""Complete28-mover construction with mode-coupled individual-cog coordinates."""','"""Distinct source-support halfplane/pocket model with all28 independent movers."""')
b=b.replace("OUT=BASE/'model';PRE=", "GEOM=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';OUT=GEOM/'model';PRE=")
b=b.replace("assert load(BASE/'audit/checks.json')['passed'] and load(PRE/'checks.json')['passed'];", "assert load(BASE/'audit/checks.json')['passed'] and load(GEOM/'audit-v2/checks.json')['passed'] and load(PRE/'checks.json')['passed'];")
b=b.replace("templates={t['class']:t for t in load(BASE/'templates.json')}","templates={t['class']:t for t in load(GEOM/'templates.json')}")
a=b.index("    for cid in source['classes']:");z=b.index("    record['one_region_constraint']",a)
b=b[:a]+'''    for cid in source['classes']:
        template=templates[cid]
        choices=[('halfplane',p['halfplane'],p) for p in template['halfplanes'] if p['halfplane'] in template['retained_halfplane_ids']]
        choices.extend(('pocket',r['region'],r) for r in template['pockets'])
        for kind,rid,choice in choices:
            sel=model.new_bool_var(f'pair_choice_{pi}_{cid}_{kind}_{rid}').index;cts=[]
            inequalities=[(choice['coefficients'],choice['lower'],cp_model.INT_MAX)] if kind=='halfplane' else [(choice['planes'][e]['coefficients'],cp_model.INT_MIN,choice['planes'][e]['upper']) for e in choice['retained_edges']]
            for coefficients,lo,hi in inequalities:
                nx,ny=coefficients
                if source['kind']=='cog_orthogonal':co={record['canonical_positions'][0]:nx,record['canonical_positions'][1]:ny}
                else:co={b['positions'][0]:nx,b['positions'][1]:ny,a['positions'][0]:-nx,a['positions'][1]:-ny}
                cts.append(linear(co,lo,hi,sel));plane_count+=1
            record['regions'].append({'class':cid,'kind':kind,'source_id':rid,'selector':sel,'source_edges':[] if kind=='halfplane' else choice['retained_edges'],'constraints':cts});region_count+=1
'''+b[z:]
b=b.replace("selected={tuple(r['owners']):r['region'] for r in load(BASE/'control-regions.json')}","selected={tuple(r['owners']):(r['kind'],r['id']) for r in load(GEOM/'control-regions.json')}")
b=b.replace("int(r['region']==selected[tuple(pair['owners'])])","int((r['kind'],r['source_id'])==selected[tuple(pair['owners'])])")
b=b.replace("charges=load(PRE/'preparation-charges.json');charges['cp_model_build_seconds']=elapsed", "charges=load(PRE/'preparation-charges.json');charges['halfplanes_complete_preparation_seconds']=load(ROOT/'output/h5-independent-twelve-cog-halfplanes-process-20261107/prepare.json')['complete_seconds'];charges['cp_model_build_seconds']=elapsed")
b=b.replace("inputs=[Path(__file__),", "inputs=[Path(__file__),ROOT/'output/prepare_h5_independent_twelve_cog_halfplane_model_helpers_20261107.py',ROOT/'output/build_h5_independent_twelve_cog_model_20261107.py',GEOM/'plan.json',GEOM/'templates.json',GEOM/'control-regions.json',GEOM/'audit-v2/plan.json',GEOM/'audit-v2/checks.json',ROOT/'output/h5-independent-twelve-cog-halfplanes-process-20261107/opened.json',ROOT/'output/h5-independent-twelve-cog-halfplanes-process-20261107/prepare.json',")
old_method=b[b.index("'method':'")+len("'method':'"):b.index("','algorithm_seconds':")]
b=b.replace(old_method,'Distinct complete28-mover construction using source-certified lower-bound support halfplanes for exterior choices and unchanged upper-bound integer pocket planes. Every one of258 cog pairs selects one typed choice; all108 modes,2,304 exact mode-coordinate links,288 class marginals,56 world coordinates and24 rigid source components remain. Keep640 component links,268 component separations and25 interchangeable-copy X-order constraints. A new partial hint uses only the12 source-checked cogs and66 typed halfplane/pocket choices. No objective, rigid row, fixed-site choice or capacity table is used. The prior memory-limited model is never reopened; it is not a geometry or budget input. Charge original source preparation, the complete new halfplane preparation and the complete new model build before one frozen60/90-second call.')
a=old_audit.read_text(encoding='utf-8')
a=a.replace('"""Exhaustive independent protobuf readback for the complete individual-cog model."""','"""Exhaustive independent readback of the typed support-halfplane/pocket model."""')
a=a.replace("MODEL=BASE/'model';OUT=BASE/'model-audit';PRE=", "GEOM=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';MODEL=GEOM/'model';OUT=GEOM/'model-audit';PRE=")
a=a.replace("assert load(BASE/'audit/checks.json')['passed'] and load(PRE/'checks.json')['passed']", "assert load(BASE/'audit/checks.json')['passed'] and load(GEOM/'audit-v2/checks.json')['passed'] and load(PRE/'checks.json')['passed']")
a=a.replace("templates={t['class']:t for t in load(BASE/'templates.json')}","templates={t['class']:t for t in load(GEOM/'templates.json')}")
i=a.index('    expected_regions=');j=a.index("    linear(r['one_region_constraint']",i)
a=a[:i]+'''    expected_regions=[]
    for cid in s['classes']:
        t=templates[cid]
        expected_regions.extend((cid,'halfplane',h) for h in t['retained_halfplane_ids'])
        expected_regions.extend((cid,'pocket',q['region']) for q in t['pockets'])
    assert [(v['class'],v['kind'],v['source_id']) for v in r['regions']]==expected_regions
    for v in r['regions']:
        cid,kind,rid,sel=v['class'],v['kind'],v['source_id'],v['selector'];variable(sel,f'pair_choice_{pi}_{cid}_{kind}_{rid}',[0,1]);selectors+=1
        assert set(v)=={'class','kind','source_id','selector','source_edges','constraints'}
        if kind=='halfplane':
            source=templates[cid]['halfplanes'][rid];assert source['halfplane']==rid and rid in templates[cid]['retained_halfplane_ids'] and v['source_edges']==[] and len(v['constraints'])==1
            expected=[(source['coefficients'],source['lower'],2**63-1)]
        else:
            assert kind=='pocket';source=next(q for q in templates[cid]['pockets'] if q['region']==rid)
            assert v['source_edges']==source['retained_edges'] and len(v['constraints'])==len(source['retained_edges'])
            expected=[(source['planes'][edge]['coefficients'],MIN,source['planes'][edge]['upper']) for edge in source['retained_edges']]
        for ci,(coefs,lo,hi) in zip(v['constraints'],expected):
            nx,ny=coefs
            if s['kind']=='cog_orthogonal':co={r['canonical_positions'][0]:nx,r['canonical_positions'][1]:ny}
            else:co={b['positions'][0]:nx,b['positions'][1]:ny,a['positions'][0]:-nx,a['positions'][1]:-ny}
            linear(ci,co,lo,hi,sel);planes+=1
'''+a[j:]
a=a.replace('selectors==27594 and planes==97284','selectors==26538 and planes==53070')
a=a.replace("choices={tuple(v['owners']):v['region'] for v in load(BASE/'control-regions.json')}","choices={tuple(v['owners']):(v['kind'],v['id']) for v in load(GEOM/'control-regions.json')}")
a=a.replace("int(r['region']==choices[tuple(pair['owners'])])","int((r['kind'],r['source_id'])==choices[tuple(pair['owners'])])").replace('len(hints)==6702','len(hints)==5646')
a=a.replace("charges=load(PRE/'preparation-charges.json');charges['cp_model_build_seconds']=counts['seconds']", "charges=load(PRE/'preparation-charges.json');charges['halfplanes_complete_preparation_seconds']=load(ROOT/'output/h5-independent-twelve-cog-halfplanes-process-20261107/prepare.json')['complete_seconds'];charges['cp_model_build_seconds']=counts['seconds']")
a=a.replace("output/build_h5_independent_twelve_cog_model_20261107.py","output/build_h5_independent_twelve_cog_halfplane_model_20261107.py")
a=a.replace("write(OUT/'source-bindings.json',bindings)", "assert not any(name.startswith('output/h5-independent-twelve-cog-integer-20261107/'+prefix) for name in bindings for prefix in ['model/','model-audit/','search/','memory-stop-audit/'])\nwrite(OUT/'source-bindings.json',bindings)")
a=a.replace("inputs=[Path(__file__),", "inputs=[Path(__file__),ROOT/'output/prepare_h5_independent_twelve_cog_halfplane_model_helpers_20261107.py',ROOT/'output/audit_h5_independent_twelve_cog_model_20261107.py',GEOM/'plan.json',GEOM/'templates.json',GEOM/'control-regions.json',GEOM/'audit-v2/plan.json',GEOM/'audit-v2/checks.json',ROOT/'output/h5-independent-twelve-cog-halfplanes-process-20261107/prepare.json',")
old_method=a[a.index("'method':'")+len("'method':'"):a.index("'})\nresult=",a.index("'method':'"))]
a=a.replace(old_method,'Read every protobuf field and all variable domains and guarded linear constraints. Independently reconstruct all28 owners,108 modes, exact canonical coordinate links and class marginals. Each retained typed exterior choice must use its certified integer LOWER bound; each retained pocket uses all its audited UPPER bounds. Verify all258 cog interactions and all120 orthogonal pairs through the complete24-component graph. Check all25 valid X-order conditions, each new partial-hint value and every fully hinted active constraint. Binary/text equality, actual solver import and complete new preparation/model process charges pass. Confirm the current failed predecessor model/search is absent from this input graph.')
a=a.replace("'all_model_fields_verified':True,", "'all_model_fields_verified':True,'typed_lower_and_upper_geometry_bounds_verified':True,'current_failed_predecessor_model_or_search_consumed':False,")
r=(ROOT/'output/run_h5_independent_twelve_cog_model_build_20261107.py').read_text(encoding='utf-8').replace('h5-independent-twelve-cog-integer-20261107/model','h5-independent-twelve-cog-halfplanes-20261107/model').replace('h5-independent-twelve-cog-model-process-20261107','h5-independent-twelve-cog-halfplane-model-process-20261107').replace('h5_independent_twelve_cog_model_20261107.py','h5_independent_twelve_cog_halfplane_model_20261107.py')
for name,text in [('build_h5_independent_twelve_cog_halfplane_model_20261107.py',b),('audit_h5_independent_twelve_cog_halfplane_model_20261107.py',a),('run_h5_independent_twelve_cog_halfplane_model_build_20261107.py',r)]:
    ast.parse(text)
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print('Distinct halfplane model, reader and bounded build runner generated; no model executed.')
