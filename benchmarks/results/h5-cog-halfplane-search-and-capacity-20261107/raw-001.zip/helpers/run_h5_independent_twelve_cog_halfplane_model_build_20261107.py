from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];MODEL=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107/model';OUT=ROOT/'output/h5-independent-twelve-cog-halfplane-model-process-20261107'
SCRIPT=ROOT/'output/build_h5_independent_twelve_cog_halfplane_model_20261107.py';AUDIT=ROOT/'output/audit_h5_independent_twelve_cog_halfplane_model_20261107.py';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not MODEL.exists();OUT.mkdir();controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
inputs={p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),SCRIPT,AUDIT,EXE,EXE.parent/'checks.json']}
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'build_cap_seconds':30,'audit_cap_seconds':90,'memory_bytes':2*1024**3,'maximum_calls':1,'retry_permitted':False})
records=[];started=time.perf_counter()
for stage,script,cap in [('build',SCRIPT,30),('audit',AUDIT,90)]:
    args=[str(EXE),str(cap*1000),str(2*1024**3),str(OUT/(stage+'-job.json')),str(OUT/(stage+'-stdout.txt')),str(OUT/(stage+'-stderr.txt')),str(OUT/(stage+'-stop')),subprocess.list2cmdline([str(PY),str(script)]),str(ROOT),'version4']
    t=time.perf_counter();r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=cap+8);elapsed=time.perf_counter()-t
    (OUT/(stage+'-runner-stdout.txt')).write_bytes(r.stdout);(OUT/(stage+'-runner-stderr.txt')).write_bytes(r.stderr)
    job=load(OUT/(stage+'-job.json'));passed=r.returncode==0 and job['closed'] and job['active_processes']==0 and job['reason_code']==job['error_code']==0
    record={'stage':stage,'exit_code':r.returncode,'complete_seconds':elapsed,'job':job,'passed':passed};records.append(record);write(OUT/(stage+'.json'),record);print(record,flush=True)
    if stage=='build' and MODEL.exists():
        write(MODEL/'build-process.json',{'utc':datetime.now(timezone.utc).isoformat(),'script_sha256':digest(SCRIPT),'complete_process_seconds':elapsed,'exit_code':r.returncode,'inputs':inputs,'job':job})
    if not passed:break
    if stage=='build':
        charges=load(MODEL/'preparation-charges.json');assert elapsed>=charges['cp_model_build_seconds'];charges['cp_model_build_seconds']=elapsed
        write(MODEL/'final-preparation-charges.json',charges)
        write(MODEL/'budget.json',{'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False,'preparation_seconds_charged':sum(charges.values()),'complete_geometry_and_model_process_times_charged':True,'count_capacity_tables_used':False})
write(OUT/'process.json',{'closed':True,'complete_seconds':time.perf_counter()-started,'stages':records,'passed':len(records)==2 and all(r['passed'] for r in records),'retry_permitted':False})
