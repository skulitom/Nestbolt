"""Exact rational original-ring containment and every projection slab readback."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations, product
import json, math, shutil, time
ROOT=Path(__file__).resolve().parents[1];I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';D=ROOT/'output/h5-independent-twelve-cog-geometry-20261107';BASE=ROOT/'output/h5-independent-cog-capacity-20261107';OUT=BASE/'audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def boundary_enters_open_rectangle(a,b,r):
    lower,upper=F(0),F(1)
    for k in [0,1]:
        delta=b[k]-a[k]
        if delta==0:
            if not r[k]<a[k]<r[k+2]:return False
        else:
            t0,t1=(r[k]-a[k])/delta,(r[k+2]-a[k])/delta
            lower=max(lower,min(t0,t1));upper=min(upper,max(t0,t1))
    if lower>upper:return False
    t=(lower+upper)/2
    return 0<=t<=1 and all(r[k]<a[k]+t*(b[k]-a[k])<r[k+2] for k in [0,1])

def inside(p,vertices):
    winding=0
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        cross=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
        if a[1]<=p[1]<b[1] and cross>0:winding+=1
        if b[1]<=p[1]<a[1] and cross<0:winding-=1
    return winding!=0

def certified_rectangle(rect,vertices):
    return inside(((rect[0]+rect[2])/2,(rect[1]+rect[3])/2),vertices) and not any(boundary_enters_open_rectangle(a,b,rect) for a,b in zip(vertices,vertices[1:]+vertices[:1]))

OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
square=[(F(0),F(0)),(F(4),F(0)),(F(4),F(4)),(F(0),F(4))]
controls=[([F(1),F(1),F(3),F(3)],True),([F(-1),F(1),F(1),F(3)],False),([F(5),F(5),F(6),F(6)],False),([F(0),F(0),F(4),F(4)],True)]
assert all(certified_rectangle(r,square)==expected for r,expected in controls)
assert boundary_enters_open_rectangle((F(-1),F(2)),(F(5),F(2)),[F(1),F(1),F(3),F(3)])
assert not boundary_enters_open_rectangle((F(-1),F(1)),(F(5),F(1)),[F(1),F(1),F(3),F(3)])
queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h;bindings[name]=h
        if z.name in ['plan.json','opened.json']:queue.append(z)
job=load(JOB);parts={p['id']:p for p in job['parts']};modes=load(I/'family-modes.json');rows=load(BASE/'modes.json');assert {(r['family'],r['mode']) for r in rows}=={(family,m['mode']) for family,items in modes.items() for m in items} and len(rows)==13
proofs=[];slabs=0;edges=0
for row in rows:
    family=row['family'];m=next(m for m in modes[family] if m['mode']==row['mode']);c,s=F(math.cos(m['rotation_radians'])),F(math.sin(m['rotation_radians']));sign=-1 if m['mirrored'] else 1;tx,ty=map(F,m['translation_from_lower_left'])
    vertices=[((sign*F(x)*c-F(y)*s+tx)*100,(sign*F(x)*s+F(y)*c+ty)*100) for x,y in parts[family]['geometry'][0]['outer']]
    for kind in ['rectangles_grid','coarse_rectangles_grid']:
        rects=row[kind]
        assert rects and all(len(r)==4 and all(isinstance(v,int) for v in r) and r[0]<r[2] and r[1]<r[3] for r in rects)
        for ri,r in enumerate(rects):
            assert certified_rectangle(list(map(F,r)),vertices),(family,row['mode'],kind,ri)
            proofs.append({'family':family,'mode':row['mode'],'kind':kind,'rectangle':ri,'exact_center_inside':True,'source_edges_avoiding_open_rectangle':len(vertices)});edges+=len(vertices)
        assert all(a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1] for a,b in combinations(rects,2))
    rects=row['rectangles_grid'];area=sum((r[2]-r[0])*(r[3]-r[1]) for r in rects);assert area==row['occupied_area_grid2']
    for axis,profile in enumerate(row['profiles']):
        assert profile and all(set(p)=={'start','end','demand'} and all(isinstance(v,int) for v in p.values()) and p['start']<p['end'] and p['demand']>0 for p in profile)
        assert all(a['end']<=b['start'] and not (a['end']==b['start'] and a['demand']==b['demand']) for a,b in zip(profile,profile[1:]))
        points=sorted({v for r in rects for v in [r[axis],r[axis+2]]}|{v for p in profile for v in [p['start'],p['end']]})
        for lo,hi in zip(points,points[1:]):
            midpoint=F(lo+hi,2);expected=sum(r[3-axis]-r[1-axis] for r in rects if r[axis]<=midpoint<r[axis+2]);actual=sum(p['demand'] for p in profile if p['start']<=midpoint<p['end']);assert actual==expected;slabs+=1
        assert sum((p['end']-p['start'])*p['demand'] for p in profile)==area
    for mlo,mhi in m['integer_world_lower_left_bounds']:assert mlo<mhi
    capacity=load(BASE/'capacity.json');stock=capacity['stock_outer_grid']
    for r in row['rectangles_grid']+row['coarse_rectangles_grid']:
        for axis in [0,1]:assert m['integer_world_lower_left_bounds'][axis][0]+r[axis]>=stock[axis] and m['integer_world_lower_left_bounds'][axis][1]+r[axis+2]<=stock[axis+2]
safe=list(map(F,load(D/'domain.json')['safe_world_bounds_mm']));expected=[math.floor(safe[0]*100),math.floor((safe[1]-2100)*100),math.ceil(safe[2]*100),math.ceil((safe[3]-2100)*100)];assert stock==expected and capacity['world_origin_mm']==[0,2100] and capacity['profile_axis_capacities']==[stock[3]-stock[1],stock[2]-stock[0]]
instances=load(I/'instances.json');lookup={(r['family'],r['mode']):r for r in rows};counts=[sum(len(lookup[(i['identity'][0],m['mode'])]['profiles'][axis]) for i in instances for m in modes[i['identity'][0]]) for axis in [0,1]];coarse=sum(len(lookup[(i['identity'][0],m['mode'])]['coarse_rectangles_grid']) for i in instances for m in modes[i['identity'][0]])
source=load(BASE/'checks.json');assert source['original_movers']==len(instances)==28 and source['mode_options']==sum(len(modes[i['identity'][0]]) for i in instances)==108 and source['expanded_profile_intervals']==counts and source['expanded_coarse_rectangles']==coarse
assert not any(name.startswith('output/h5-independent-twelve-cog-halfplanes-20261107/model') or name.startswith('output/h5-independent-twelve-cog-halfplanes-20261107/search') or name.startswith('output/h5-independent-twelve-cog-integer-20261107/model') or name.startswith('output/h5-independent-twelve-cog-integer-20261107/search') for name in bindings)
write(OUT/'source-bindings.json',bindings);write(OUT/'containment-proofs.json',proofs)
inputs=[Path(__file__),BASE/'plan.json',BASE/'modes.json',BASE/'capacity.json',BASE/'checks.json',JOB,I/'family-modes.json',I/'instances.json',D/'domain.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read the original vertices and actual sine/cosine/translation floats as exact rationals. For every rectangle, an exact winding check puts its center inside the filled source outer, and exact segment/open-box clipping excludes every outer boundary edge from its interior. Thus its connected open interior cannot leave the polygon; its closure is source-contained. Ignore holes only for necessary occupancy because part-in-hole is disabled. Verify same-mode rectangles have disjoint interiors. Independently enumerate every union of source/profile endpoints and compare cross-section demands on every resulting elementary slab, with exact area conservation. Verify each translated inner rectangle stays inside the outward-rounded stock at every domain extreme. Keep all owners and mode aliases; this is not a full placement or exclusion.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'source_modes_verified':13,'original_movers_verified':28,'mode_options_verified':108,'exact_rectangle_containment_proofs':len(proofs),'exact_source_edge_box_checks':edges,'independent_projection_slabs':slabs,'expanded_profile_intervals':counts,'expanded_coarse_rectangles':coarse,'all_mode_domain_extremes_inside_capacity_stock':True,'exact_area_conservation_both_axes':True,'same_owner_rectangles_interior_disjoint':True,'current_closed_models_or_searches_consumed':False,'recursive_bindings_verified':len(bindings),'solver_calls':0,'source_valid66':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
