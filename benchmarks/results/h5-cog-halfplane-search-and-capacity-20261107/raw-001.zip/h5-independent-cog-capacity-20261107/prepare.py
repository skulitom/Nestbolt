"""Fresh source-contained rectangles and exact projection profiles for all 13 modes."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations
import json, math, shutil, time
from shapely.geometry import Polygon, LineString, box
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1]
I=ROOT/'output/h5-independent-twelve-cog-integer-20261107'
D=ROOT/'output/h5-independent-twelve-cog-geometry-20261107'
OUT=ROOT/'output/h5-independent-cog-capacity-20261107'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def transform(vertices,m):
    c,s=math.cos(m['rotation_radians']),math.sin(m['rotation_radians']);sign=-1 if m['mirrored'] else 1;tx,ty=m['translation_from_lower_left']
    return [(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in vertices]

def segments(g):
    if g.geom_type=='LineString':
        a,_,b,_=g.bounds
        if a<b:yield LineString([(a,0),(b,0)])
    elif hasattr(g,'geoms'):
        for child in g.geoms:yield from segments(child)

def projections(rects):
    result=[]
    for axis in [0,1]:
        events={}
        for r in rects:
            lo,hi=r[axis],r[axis+2];demand=r[3-axis]-r[1-axis]
            events[lo]=events.get(lo,0)+demand;events[hi]=events.get(hi,0)-demand
        levels=sorted(events);demand=0;rows=[]
        for lo,hi in zip(levels,levels[1:]):
            demand+=events[lo]
            if not demand:continue
            assert demand>0
            if rows and rows[-1]['end']==lo and rows[-1]['demand']==demand:rows[-1]['end']=hi
            else:rows.append({'start':lo,'end':hi,'demand':demand})
        assert demand+events[levels[-1]]==0
        result.append(rows)
    return result

OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
assert load(I/'audit/checks.json')['passed']
inputs=[Path(__file__),JOB,I/'plan.json',I/'audit/plan.json',I/'audit/checks.json',I/'family-modes.json',I/'instances.json',D/'domain.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Fresh occupied source subsets for all 28 original movers and all 108 mode options. Inset each original orthogonal component by one 0.01mm unit after its actual source transform. For the 7-degree cog, intersect every original vertex-height section and both edges in each of 32 horizontal bands; retain common X intervals rounded inward. Preserve holes in final geometry; filled outer occupancy is necessary because common-line part-in-hole remains disabled. Independently prove each inner rectangle is inside the exact rational affine original outer, and prove same-owner rectangles have disjoint interiors. Aggregate each mode into exact integer X/Y cumulative profiles. A separate 153mm cog square plus the orthogonal component rectangles may support one additional coarse NoOverlap2D system. These are necessary global constraints only; full pair geometry and all66 original-source checks remain required. Do not consume or rerun any closed model/search. No model or solver is opened here.','position_units_per_mm':100,'slices_per_cog':32,'prepare_cap_seconds':30,'audit_cap_seconds':60,'solver_calls':0,'retry_permitted':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};modes=load(I/'family-modes.json');rows=[]
for family,options in modes.items():
    for m in options:
        outer=transform(parts[family]['geometry'][0]['outer'],m);g=Polygon(outer);rects=[]
        if family in ['bracket','insert']:
            pieces=[[(0,0),(300,0),(300,75),(0,75)],[(0,75),(100,75),(100,250),(0,250)]] if family=='bracket' else [parts[family]['geometry'][0]['outer']]
            for piece in pieces:
                vertices=transform(piece,m);b=[min(p[k] for p in vertices) for k in [0,1]]+[max(p[k] for p in vertices) for k in [0,1]]
                rects.append([math.ceil(b[0]*100)+1,math.ceil(b[1]*100)+1,math.floor(b[2]*100)-1,math.floor(b[3]*100)-1])
            coarse=rects
        else:
            assert family=='cog' and m['mode']==0
            xmin,ymin,xmax,ymax=g.bounds;low=math.ceil(ymin*100);high=math.floor(ymax*100);levels=[low+(high-low)*i//32 for i in range(33)]
            for bottom,top in zip(levels,levels[1:]):
                lo,hi=bottom+1,top-1;assert lo<hi
                knots=sorted({lo/100,hi/100,*[y for x,y in outer if lo/100<y<hi/100]});common=LineString([(xmin-1,0),(xmax+1,0)])
                for y in knots:common=common.intersection(unary_union(list(segments(g.intersection(LineString([(xmin-1,y),(xmax+1,y)]))))))
                for interval in segments(common):
                    a,_,b,_=interval.bounds;left=math.ceil(a*100)+1;right=math.floor(b*100)-1
                    if left<right:rects.append([left,lo,right,hi])
            cx,cy=(xmin+xmax)/2,(ymin+ymax)/2
            coarse=[[math.ceil((cx-76.5)*100)+1,math.ceil((cy-76.5)*100)+1,math.floor((cx+76.5)*100)-1,math.floor((cy+76.5)*100)-1]]
        for r in rects+coarse:assert r[0]<r[2] and r[1]<r[3] and g.covers(box(*(v/100 for v in r)))
        assert all(a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1] for a,b in combinations(rects,2))
        profiles=projections(rects);area=sum((r[2]-r[0])*(r[3]-r[1]) for r in rects)
        rows.append({'family':family,'mode':m['mode'],'rectangles_grid':rects,'coarse_rectangles_grid':coarse,'profiles':profiles,'occupied_area_grid2':area,'source_outer_area_mm2':g.area,'occupied_area_fraction':area/10000/g.area})
        assert time.perf_counter()-started<30
safe=list(map(F,load(D/'domain.json')['safe_world_bounds_mm']))
stock=[math.floor(safe[0]*100),math.floor((safe[1]-2100)*100),math.ceil(safe[2]*100),math.ceil((safe[3]-2100)*100)]
write(OUT/'modes.json',rows);write(OUT/'capacity.json',{'stock_outer_grid':stock,'world_origin_mm':[0,2100],'profile_axis_capacities':[stock[3]-stock[1],stock[2]-stock[0]],'bound_rounding':'outward from the already audited construction stock; capacity may only be enlarged'})
instances=load(I/'instances.json');lookup={(r['family'],r['mode']):r for r in rows}
counts=[sum(len(lookup[(i['identity'][0],m['mode'])]['profiles'][axis]) for i in instances for m in modes[i['identity'][0]]) for axis in [0,1]]
checks={'passed':True,'seconds':time.perf_counter()-started,'original_movers':len(instances),'mode_options':sum(len(modes[i['identity'][0]]) for i in instances),'source_modes':len(rows),'source_rectangles':sum(len(r['rectangles_grid']) for r in rows),'source_coarse_rectangles':sum(len(r['coarse_rectangles_grid']) for r in rows),'expanded_profile_intervals':counts,'expanded_coarse_rectangles':sum(len(lookup[(i['identity'][0],m['mode'])]['coarse_rectangles_grid']) for i in instances for m in modes[i['identity'][0]]),'cog_occupied_area_fraction':next(r['occupied_area_fraction'] for r in rows if r['family']=='cog'),'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
