"""One bounded spatial subdivision of unresolved continuous frame regions."""
from collections import deque
from fractions import Fraction as F
from datetime import datetime,timezone
import copy,json,shutil,time
from bound_h5_cog_centers import free_slabs
from census_h5_non_cog_releases import component_bound
from bound_h5_cog_reachable_area import sweep_area
from refine_h5_non_cog_release_components import max_distance_squared
from reduce_h5_free_cog_pool import ROOT,load,write,digest

FRAME=ROOT/'output/h5-single-frame-center-regions-20261020'
PRIOR=ROOT/'output/h5-single-frame-region-capacity-20261020'
CENTER=ROOT/'output/h5-cog-center-capacity-20261020'
AREA=ROOT/'output/h5-cog-reachable-area-20261020'
OUT=ROOT/'output/h5-single-frame-spatial-refinement-20261020'
S=10000

def bbox(cells):
    return [min(r[0] for r in cells),min(r[1] for r in cells),
            max(r[2] for r in cells),max(r[3] for r in cells)]

def split(cells):
    bounds=bbox(cells)
    axis=0 if bounds[2]-bounds[0]>=bounds[3]-bounds[1] else 1
    middle=(bounds[axis]+bounds[axis+2])//2
    if not bounds[axis]<middle<bounds[axis+2]:
        return None
    children=[[],[]]
    for cell in cells:
        low=list(cell)
        low[axis+2]=min(low[axis+2],middle)
        high=list(cell)
        high[axis]=max(high[axis],middle)
        for side,r in enumerate([low,high]):
            if r[0]<r[2] and r[1]<r[3]:
                children[side].append(r)
    assert all(children)
    return {'axis':axis,'coordinate_units':middle},children

def evaluate(removed,axis,cells,primitives,disk,cog,last):
    bounds=bbox(cells)
    hx,hy=(2249998,1749998) if axis==0 else (1749998,2249998)
    core=[bounds[2]-hx,bounds[3]-hy,bounds[0]+hx,bounds[1]+hy]
    if core[0]>=core[2] or core[1]>=core[3]:
        core=None
    solid_raw=[p['inner_rectangle_units'] for p in primitives
               if p['fixed_candidate']!=removed and p['sheet_id']=='sheet-0']
    if core is not None:
        solid_raw.append(core)
    offsets=disk['offset_rectangles_half_sizes_units']
    separation=disk['center_separation_units']
    radius=cog['circumradius_units']
    area_lower=F(*cog['filled_area_lower_bound'])
    obstacles=[[a-x,b-y,c+x,d+y] for a,b,c,d in solid_raw for x,y in offsets]
    domain=load(CENTER/'sheet-0.json')['domain_units']
    free,groups,clipped=free_slabs(domain,obstacles)
    solid_domain=load(AREA/'sheet-0.json')['usable_domain_units']
    left,bottom,right,top=solid_domain
    solid=[]
    for a,b,c,d in solid_raw:
        r=[max(left,a),max(bottom,b),min(right,c),min(top,d)]
        if r[0]<r[2] and r[1]<r[3]:
            solid.append(r)
    components=[]
    for ids in groups:
        comp=component_bound([free[i] for i in ids],solid_domain,solid,radius,separation,area_lower)
        comp['cell_indices']=ids
        components.append(comp)
    included=[r for c in components for r in c['included_reachable_rectangles']]
    _,area=sweep_area(included,solid)
    whole_bound=F(area,S*S)//area_lower
    cliques=[]
    for i,c in enumerate(components):
        if c['upper_bound']!=1:
            continue
        for group in cliques:
            if all(max_distance_squared(c['bounding_box_units'],components[j]['bounding_box_units'])<separation**2
                   for j in group):
                group.append(i)
                break
        else:
            cliques.append([i])
    bound=min(whole_bound,len(cliques)+sum(c['upper_bound'] for c in components if c['upper_bound']!=1))
    row={'sheet':'sheet-0','center_domain_units':domain,'solid_domain_units':solid_domain,
         'forbidden_rectangles':clipped,'solid_rectangles':solid,'free_cells':free,
         'components':components,'capacity_one_component_cliques':cliques,
         'whole_reachable_area_units_squared':area,'whole_area_bound':whole_bound,'upper_bound':bound}
    return {'frame_center_bounding_box':bounds,'common_solid_frame_rectangle':core,
            'sheets':[row,copy.deepcopy(last)],'cog_upper_bound':bound+last['upper_bound']}

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'refine.py')
    prior=load(PRIOR/'result.json')
    sources=[PRIOR/n for n in ['result.json','audit/checks.json']]
    sources += [PRIOR/r['file'] for r in prior['regions']]
    sources += [FRAME/n for n in ['result.json','audit/checks.json']]
    sources += [FRAME/r['file'] for r in load(FRAME/'result.json')['queries']]
    sources += [CENTER/n for n in ['disk.json','interior-rectangles.json','sheet-0.json']]
    sources += [AREA/n for n in ['cog.json','sheet-0.json']]
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
          'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources},
          'maximum_new_nodes':256,'maximum_depth':6,'seconds_limit':120,
          'method':'Retain all16 already-excluded whole components. Start at each of36 inconclusive audited components, bisect its longest center-box dimension at the integer midpoint, clip its exact free cells and evaluate both children in breadth-first order. Recompute a guaranteed common frame core and independent-area/diameter cog capacity. A bound below15 excludes the whole child. Otherwise split again only below depth6. Preserve every parent, child, unresolved leaf and unprocessed queue entry. Reuse the unchanged audited last-sheet certificate exactly; all moved frames are on the first sheet.',
          'limit_policy':'One changed spatial certificate construction; no solver retry or extension. Stop between nodes at120 seconds or256 new nodes. Never infer impossibility from an unfinished tree.',
          'native_packing_calls':0,'quality_runs':0,'solver_calls':0})
    assert load(PRIOR/'audit/checks.json')['passed']
    primitives=load(CENTER/'interior-rectangles.json')
    disk=load(CENTER/'disk.json')
    cog=load(AREA/'cog.json')
    last=load(PRIOR/prior['regions'][0]['file'])['sheets'][1]
    roots=[]
    queue=deque()
    completed=[]
    terminal=[]
    for summary in prior['regions']:
        old=load(PRIOR/summary['file'])
        assert old['frame_sheet']=='sheet-0' and old['sheets'][1]==last
        source=load(FRAME/old['frame_query'])
        cells=[source['free_cells'][i] for i in source['components'][old['frame_component']]['cell_indices']]
        root={'id':f"root-{len(roots)}",'parent':None,'depth':0,'prior_region':summary['file'],
              'removed_candidate':old['removed_candidate'],'axis_class':old['axis_class'],
              'frame_query':old['frame_query'],'frame_component':old['frame_component'],
              'frame_center_cells':cells,'cog_upper_bound':old['cog_upper_bound'],
              'region_ruled_out':old['region_ruled_out']}
        if root['region_ruled_out']:
            root['children']=[]
        else:
            subdivision=split(cells)
            assert subdivision
            cut,child_cells=subdivision
            root['split']=cut
            root['children']=[f"{root['id']}-0",f"{root['id']}-1"]
            for i,subset in enumerate(child_cells):
                queue.append({'id':root['children'][i],'parent':root['id'],'depth':1,
                              'prior_region':summary['file'],'removed_candidate':old['removed_candidate'],
                              'axis_class':old['axis_class'],'frame_query':old['frame_query'],
                              'frame_component':old['frame_component'],'frame_center_cells':subset})
        roots.append(root)
    write(OUT/'roots.json',roots)
    write(OUT/'last-sheet-reuse.json',{'prior_region':prior['regions'][0]['file'],
                                      'prior_sha256':digest(PRIOR/prior['regions'][0]['file']),
                                      'sheet':last,'rerun':False})
    start=time.perf_counter()
    while queue and len(completed)<256 and time.perf_counter()-start<120:
        node=queue.popleft()
        node_start=time.perf_counter()
        node.update(evaluate(node['removed_candidate'],node['axis_class'],node['frame_center_cells'],
                             primitives,disk,cog,last))
        node['region_ruled_out']=node['cog_upper_bound']<15
        node['children']=[]
        if not node['region_ruled_out'] and node['depth']<6:
            subdivision=split(node['frame_center_cells'])
            if subdivision:
                cut,child_cells=subdivision
                node['split']=cut
                node['children']=[f"{node['id']}-0",f"{node['id']}-1"]
                for i,subset in enumerate(child_cells):
                    queue.append({'id':node['children'][i],'parent':node['id'],'depth':node['depth']+1,
                                  'prior_region':node['prior_region'],'removed_candidate':node['removed_candidate'],
                                  'axis_class':node['axis_class'],'frame_query':node['frame_query'],
                                  'frame_component':node['frame_component'],'frame_center_cells':subset})
        if not node['region_ruled_out'] and not node['children']:
            terminal.append(node['id'])
        node['seconds']=time.perf_counter()-node_start
        name=f"node-{len(completed)}.json"
        write(OUT/name,node)
        completed.append({'id':node['id'],'file':name,'depth':node['depth'],'upper_bound':node['cog_upper_bound'],
                          'region_ruled_out':node['region_ruled_out'],'children':node['children']})
    write(OUT/'pending-nodes.json',list(queue))
    result={'nodes':completed,'new_nodes_completed':len(completed),'pending_nodes':len(queue),
            'terminal_inconclusive_nodes':terminal,'seconds':time.perf_counter()-start,
            'node_limit_reached':bool(queue) and len(completed)>=256,
            'time_limit_reached':bool(queue) and time.perf_counter()-start>=120,
            'all_single_frame_moves_ruled_out':not queue and not terminal,
            'independent_audit_pending':True,'full_target_witness':False,
            'native_packing_calls':0,'quality_runs':0}
    write(OUT/'result.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='nodes'}))

if __name__=='__main__':
    main()
