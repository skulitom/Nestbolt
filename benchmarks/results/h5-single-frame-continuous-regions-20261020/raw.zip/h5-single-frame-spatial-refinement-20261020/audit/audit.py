"""Audit the complete spatial tree, coverage and every new conditional bound."""
from collections import deque
import json,shutil,time
from audit_h5_single_frame_region_capacity import audit_sheet
from reduce_h5_free_cog_pool import ROOT,load,write,digest

FRAME=ROOT/'output/h5-single-frame-center-regions-20261020'
PRIOR=ROOT/'output/h5-single-frame-region-capacity-20261020'
CENTER=ROOT/'output/h5-cog-center-capacity-20261020'
AREA=ROOT/'output/h5-cog-reachable-area-20261020'
RUN=ROOT/'output/h5-single-frame-spatial-refinement-20261020'
OUT=RUN/'audit'

def bounding(cells):
    return [min(r[0] for r in cells),min(r[1] for r in cells),
            max(r[2] for r in cells),max(r[3] for r in cells)]

def verify_children(parent,children):
    assert len(children)==2
    axis=parent['split']['axis']
    mid=parent['split']['coordinate_units']
    bounds=bounding(parent['frame_center_cells'])
    assert axis==(0 if bounds[2]-bounds[0]>=bounds[3]-bounds[1] else 1)
    assert mid==(bounds[axis]+bounds[axis+2])//2 and bounds[axis]<mid<bounds[axis+2]
    for side,child in enumerate(children):
        assert child['parent']==parent['id'] and child['depth']==parent['depth']+1
        assert child['id']==parent['children'][side]
        for k in ['prior_region','removed_candidate','axis_class','frame_query','frame_component']:
            assert child[k]==parent[k]
        expected=[]
        for cell in parent['frame_center_cells']:
            r=list(cell)
            if side==0:
                r[axis+2]=min(r[axis+2],mid)
            else:
                r[axis]=max(r[axis],mid)
            if r[0]<r[2] and r[1]<r[3]:
                expected.append(r)
        assert expected and expected==child['frame_center_cells']
    # The two closed midpoint half-boxes cover each parent rectangle exactly;
    # zero-area edge clips are included in the closure of their positive sibling.

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'audit.py')
    start=time.perf_counter()
    for p,h in load(RUN/'plan.json')['inputs'].items():
        assert digest(ROOT/p)==h
    assert load(PRIOR/'audit/checks.json')['passed']
    roots=load(RUN/'roots.json')
    result=load(RUN/'result.json')
    nodes=[load(RUN/r['file']) for r in result['nodes']]
    pending=load(RUN/'pending-nodes.json')
    all_nodes=roots+nodes+pending
    by_id={r['id']:r for r in all_nodes}
    assert len(by_id)==len(all_nodes)
    prior=load(PRIOR/'result.json')
    assert len(roots)==len(prior['regions'])==52
    reuse=load(RUN/'last-sheet-reuse.json')
    assert digest(PRIOR/reuse['prior_region'])==reuse['prior_sha256'] and reuse['rerun'] is False
    last=load(PRIOR/reuse['prior_region'])['sheets'][1]
    assert last==reuse['sheet'] and last['sheet']=='sheet-1' and last['upper_bound']==3
    queue=deque()
    initial_excluded=0
    for root,old_summary in zip(roots,prior['regions']):
        old=load(PRIOR/old_summary['file'])
        assert root['parent'] is None and root['depth']==0 and root['prior_region']==old_summary['file']
        for k in ['removed_candidate','axis_class','frame_query','frame_component']:
            assert root[k]==old[k]
        source=load(FRAME/root['frame_query'])
        assert source['sheet']=='sheet-0'
        expected=[source['free_cells'][i] for i in source['components'][root['frame_component']]['cell_indices']]
        assert root['frame_center_cells']==expected
        assert root['cog_upper_bound']==old['cog_upper_bound']
        assert root['region_ruled_out']==old['region_ruled_out']
        if root['region_ruled_out']:
            assert root['children']==[]
            initial_excluded+=1
        else:
            verify_children(root,[by_id[i] for i in root['children']])
            queue.extend(root['children'])
    assert initial_excluded==16
    disk=load(CENTER/'disk.json')
    cog=load(AREA/'cog.json')
    primitives=load(CENTER/'interior-rectangles.json')
    component_count=cover_count=0
    records=[]
    terminal=[]
    for node,summary in zip(nodes,result['nodes']):
        assert queue.popleft()==node['id']==summary['id']
        assert 1<=node['depth']<=6
        bounds=bounding(node['frame_center_cells'])
        assert bounds==node['frame_center_bounding_box']
        hx,hy=(2249998,1749998) if node['axis_class']==0 else (1749998,2249998)
        core=[bounds[2]-hx,bounds[3]-hy,bounds[0]+hx,bounds[1]+hy]
        if core[0]>=core[2] or core[1]>=core[3]:
            core=None
        assert core==node['common_solid_frame_rectangle']
        if core:
            for x in [bounds[0],bounds[2]]:
                for y in [bounds[1],bounds[3]]:
                    assert x-hx<=core[0]<core[2]<=x+hx and y-hy<=core[1]<core[3]<=y+hy
        remaining=[p for p in primitives if p['fixed_candidate']!=node['removed_candidate']]
        assert len({p['fixed_candidate'] for p in remaining})==50
        solid=[p['inner_rectangle_units'] for p in remaining if p['sheet_id']=='sheet-0']
        if core is not None:
            solid.append(core)
        assert len(node['sheets'])==2 and node['sheets'][1]==last
        bound,nc,nv=audit_sheet(node['sheets'][0],solid,disk,cog)
        component_count+=nc
        cover_count+=nv
        total=bound+last['upper_bound']
        assert total==node['cog_upper_bound']==summary['upper_bound']
        assert node['region_ruled_out']==summary['region_ruled_out']==(total<15)
        assert node['children']==summary['children']
        if node['region_ruled_out']:
            assert node['children']==[]
        elif node['children']:
            assert node['depth']<6
            verify_children(node,[by_id[i] for i in node['children']])
            queue.extend(node['children'])
        else:
            terminal.append(node['id'])
        records.append({'id':node['id'],'depth':node['depth'],'upper_bound':total,
                        'region_ruled_out':total<15,'children':node['children']})
    assert list(queue)==[r['id'] for r in pending] and len(pending)==result['pending_nodes']
    assert terminal==result['terminal_inconclusive_nodes']
    assert len(nodes)==result['new_nodes_completed']<=256
    def excluded(i):
        n=by_id[i]
        if 'region_ruled_out' not in n:
            return False
        if n['region_ruled_out']:
            return True
        return bool(n['children']) and all(excluded(j) for j in n['children'])
    root_proofs=[{'id':r['id'],'removed_candidate':r['removed_candidate'],
                  'axis_class':r['axis_class'],'whole_component_ruled_out':excluded(r['id'])} for r in roots]
    all_excluded=all(r['whole_component_ruled_out'] for r in root_proofs)
    assert all_excluded==result['all_single_frame_moves_ruled_out']
    by_frame=[{'candidate':i,'single_frame_move_ruled_out':all(r['whole_component_ruled_out']
                       for r in root_proofs if r['removed_candidate']==i)}
              for i in sorted({r['removed_candidate'] for r in roots})]
    checks={'passed':True,'root_regions_verified':52,'initial_excluded_regions':16,
            'new_nodes_verified':len(nodes),'pending_nodes':len(pending),
            'terminal_inconclusive_nodes':terminal,'all_tree_partitions_cover_exactly':True,
            'all_common_cores_verified':True,'all_cog_center_and_area_certificates_exact':True,
            'cog_components_verified':component_count,'band_covers_verified':cover_count,
            'last_sheet_certificate_reused_exactly':True,'root_proofs':root_proofs,
            'frame_proofs':by_frame,'all_single_frame_moves_ruled_out':all_excluded,
            'records':records,'seconds':time.perf_counter()-start,
            'scope':'All allowed frame quarter turns and continuous positions, all cog angles and positions, with50 other non-cog poses fixed. No claim about multiple non-cog moves or an attainable packing.',
            'full_target_witness':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks)
    print(json.dumps({k:v for k,v in checks.items() if k not in ['records','root_proofs','frame_proofs']}
                     |{'frames_ruled_out':sum(r['single_frame_move_ruled_out'] for r in by_frame)}))

if __name__=='__main__':
    main()
