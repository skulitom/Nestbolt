"""Necessary area bound for all-angle cogs in the certified center regions."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json, math, shutil, time
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'output/h5-cog-center-capacity-20261020'
ORIGINAL = ROOT/'output/h5-coordinated-placement-selection-20261018'
OUT = ROOT/'output/h5-cog-reachable-area-20261020'
S = 10000
load = lambda p:json.loads(p.read_bytes())
digest = lambda p:sha256(p.read_bytes()).hexdigest()

def write(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,indent=2)
        f.write('\n')

def union(intervals):
    result = []
    for a,b in sorted(intervals):
        if result and a <= result[-1][1]:
            result[-1][1] = max(result[-1][1],b)
        else:
            result.append([a,b])
    return result

def subtract(included,excluded):
    result = []
    for a,b in included:
        cursor = a
        for c,d in excluded:
            if d <= cursor:
                continue
            if c >= b:
                break
            if cursor < c:
                result.append([cursor,min(b,c)])
            cursor = max(cursor,d)
            if cursor >= b:
                break
        if cursor < b:
            result.append([cursor,b])
    return result

def sweep_area(included,excluded):
    xs = sorted({v for b in included+excluded for v in [b[0],b[2]]})
    cells = []
    for a,b in zip(xs,xs[1:]):
        inc = union((r[1],r[3]) for r in included if r[0] <= a and b <= r[2])
        exc = union((r[1],r[3]) for r in excluded if r[0] <= a and b <= r[2])
        cells.extend([[a,c,b,d] for c,d in subtract(inc,exc)])
    return cells,sum((c-a)*(d-b) for a,b,c,d in cells)

def independent_area(included,excluded):
    # Coordinate compression and two-dimensional integer difference arrays:
    # independent of the interval-union/subtraction sweep above.
    rects = included+excluded
    xs = sorted({v for b in rects for v in [b[0],b[2]]})
    ys = sorted({v for b in rects for v in [b[1],b[3]]})
    xi,yi = {v:i for i,v in enumerate(xs)},{v:i for i,v in enumerate(ys)}
    grids = []
    for source in [included,excluded]:
        grid = [[0]*len(ys) for _ in xs]
        for a,b,c,d in source:
            for x,y,delta in [(a,b,1),(c,b,-1),(a,d,-1),(c,d,1)]:
                grid[xi[x]][yi[y]] += delta
        for i in range(len(xs)):
            for j in range(len(ys)):
                if i:
                    grid[i][j] += grid[i-1][j]
                if j:
                    grid[i][j] += grid[i][j-1]
                if i and j:
                    grid[i][j] -= grid[i-1][j-1]
        grids.append(grid)
    total = sum((xs[i+1]-xs[i])*(ys[j+1]-ys[j])
                for i in range(len(xs)-1) for j in range(len(ys)-1)
                if grids[0][i][j] > 0 and grids[1][i][j] == 0)
    return total

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'bound.py')
    sources = [SRC/n for n in ['disk.json','sheet-0.json','sheet-1.json',
                               'interior-rectangles.json','audit/checks.json']]
    sources += [ORIGINAL/'job.json',ORIGINAL/'conditional-target.json']
    write(OUT/'plan.json',{'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources},
          'method':'An exact rational circumradius contains the filled cog at any angle. Expand every certified free-center cell by its axis-aligned radius square. Clip to outward-rounded usable stock and subtract only independently certified interior non-cog rectangles. This union is an upper bound on area reachable by any cog. Disjoint filled cogs consume their original polygon area. Two independent integer area computations verify the bound.',
          'solver_calls':0,'native_packing_calls':0,'quality_runs':0})
    assert load(SRC/'audit/checks.json')['passed']
    start = time.perf_counter()
    job = load(ORIGINAL/'job.json')
    cog = next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer']
    polygon = [[F(x),F(y)] for x,y in cog]
    center = [F(*v) for v in load(SRC/'disk.json')['center']]
    maximum = max(sum((p[k]-center[k])**2 for k in [0,1]) for p in polygon)
    radius = math.ceil(math.sqrt(float(maximum))*S)+1
    assert F(radius,S)**2 > maximum
    area = abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(polygon,polygon[1:]+polygon[:1])))/2
    # Weaken by 0.000001mm², larger than rigid-transform rounding at this scale.
    area_lower = area-F(1,1000000)
    write(OUT/'cog.json',{'circumradius_units':radius,'maximum_vertex_distance_squared':[maximum.numerator,maximum.denominator],
                         'filled_area_exact':[area.numerator,area.denominator],
                         'filled_area_lower_bound':[area_lower.numerator,area_lower.denominator]})
    primitives = load(SRC/'interior-rectangles.json')
    target = load(ORIGINAL/'conditional-target.json')
    rows = []
    for sheet in ['sheet-0','sheet-1']:
        stock = job['stocks'][0]
        m,edge = stock['margins'],F(job['edge_clearance'])
        height = stock['height'] if sheet=='sheet-0' else target['required_used_height_mm']
        tol = F(1,1000000)
        domain = [math.floor((F(m['left'])+edge-tol)*S),math.floor((F(m['bottom'])+edge-tol)*S),
                  math.ceil((F(stock['width'])-F(m['right'])-edge+tol)*S),
                  math.ceil((F(height)-F(m['top'])-edge+tol)*S)]
        left,bottom,right,top = domain
        included = [[max(left,a-radius),max(bottom,b-radius),min(right,c+radius),min(top,d+radius)]
                    for a,b,c,d in load(SRC/f'{sheet}.json')['free_cells_units']]
        excluded = []
        for p in primitives:
            if p['sheet_id'] != sheet:
                continue
            a,b,c,d = p['inner_rectangle_units']
            rect = [max(left,a),max(bottom,b),min(right,c),min(top,d)]
            if rect[0]<rect[2] and rect[1]<rect[3]:
                excluded.append(rect)
        cells,total = sweep_area(included,excluded)
        assert independent_area(included,excluded) == total
        upper = F(total,S*S)//area_lower
        record = {'sheet':sheet,'usable_domain_units':domain,
                  'included_reachable_rectangles':included,'excluded_solid_rectangles':excluded,
                  'remaining_cells':cells,'reachable_area_units_squared':total,
                  'reachable_area_mm2':float(F(total,S*S)),'cog_upper_bound':upper,
                  'independent_integer_area_matches':True}
        write(OUT/f'{sheet}.json',record)
        rows.append({k:record[k] for k in ['sheet','reachable_area_mm2','cog_upper_bound']})
    bound = sum(r['cog_upper_bound'] for r in rows)
    checks = {'passed':True,'sheets':rows,'all_angle_cog_upper_bound':bound,
              'required15_ruled_out':bound<15,'circumradius_mm':radius/S,
              'original_filled_cog_area_mm2':float(area),'two_independent_exact_area_algorithms':True,
              'seconds':time.perf_counter()-start,
              'scope':'Only the same51 fixed non-cog filled-outer poses; arbitrary cog rotations and continuous centers.',
              'full_target_witness':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks)
    print(json.dumps(checks))

if __name__ == '__main__':
    main()
