"""Tighten release bounds when distinct small center regions cannot coexist."""
from itertools import combinations
import json, shutil
from reduce_h5_free_cog_pool import ROOT, load, write, digest

RUN=ROOT/'output/h5-single-non-cog-release-census-20261020'
OUT=RUN/'component-covers'
CENTER=ROOT/'output/h5-cog-center-capacity-20261020'

def max_distance_squared(a,b):
    return sum(max(abs(a[k]-b[k+2]),abs(a[k+2]-b[k]))**2 for k in [0,1])

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'refine.py')
    audit=load(RUN/'audit/checks.json')
    assert audit['passed'] and audit['cases_verified']==51
    sources=[RUN/'audit/checks.json',CENTER/'disk.json']
    sources.extend(RUN/f"case-{r['removed_candidate']}.json" for r in audit['records'])
    write(OUT/'plan.json',{'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources},
          'method':'For every audited case and sheet, form deterministic greedy cliques of capacity-one center components whose maximum cross-component bounding-box distance is strictly below required center separation. One cog at most can occupy any such clique. Retain all larger component capacities. Independently check every clique pair and exact component partition; take the minimum of this bound and the prior whole-sheet bound.',
          'solver_calls':0,'native_packing_calls':0,'quality_runs':0})
    separation=load(CENTER/'disk.json')['center_separation_units']
    records=[]
    merged=0
    for r in audit['records']:
        case=load(RUN/f"case-{r['removed_candidate']}.json")
        sheets=[]
        for sheet in case['sheets']:
            comps=sheet['components']
            ones=[i for i,c in enumerate(comps) if c['upper_bound']==1]
            groups=[]
            for i in ones:
                for group in groups:
                    if all(max_distance_squared(comps[i]['bounding_box_units'],comps[j]['bounding_box_units'])
                           <separation**2 for j in group):
                        group.append(i)
                        break
                else:
                    groups.append([i])
            # Separate certificate verification: cross-component rectangle corners.
            assert sorted(i for group in groups for i in group)==ones
            for group in groups:
                for i,j in combinations(group,2):
                    a,b=comps[i]['bounding_box_units'],comps[j]['bounding_box_units']
                    corners_a=[(x,y) for x in [a[0],a[2]] for y in [a[1],a[3]]]
                    corners_b=[(x,y) for x in [b[0],b[2]] for y in [b[1],b[3]]]
                    assert all((x-u)**2+(y-v)**2<separation**2
                               for x,y in corners_a for u,v in corners_b)
                if len(group)>1:
                    merged+=1
            remaining=sum(c['upper_bound'] for c in comps if c['upper_bound']!=1)
            bound=min(sheet['upper_bound'],remaining+len(groups))
            sheets.append({'sheet':sheet['sheet'],'capacity_one_component_cliques':groups,
                           'other_component_capacity':remaining,'prior_bound':sheet['upper_bound'],
                           'upper_bound':bound})
        total=sum(s['upper_bound'] for s in sheets)
        records.append({'removed_candidate':r['removed_candidate'],'part_id':r['part_id'],
                        'sheets':sheets,'prior_bound':r['upper_bound'],'upper_bound':total,
                        'single_pose_change_ruled_out':total<15})
    summary={part:{'ruled_out':sum(r['part_id']==part and r['single_pose_change_ruled_out'] for r in records),
                   'inconclusive':sum(r['part_id']==part and not r['single_pose_change_ruled_out'] for r in records)}
             for part in ['frame','bracket','insert']}
    checks={'passed':True,'all_component_partitions_and_corner_pairs_verified':True,'cases':records,
            'by_part':summary,'nontrivial_component_cliques':merged,
            'single_pose_changes_ruled_out':sum(r['single_pose_change_ruled_out'] for r in records),
            'not_ruled_out':[r['removed_candidate'] for r in records if not r['single_pose_change_ruled_out']],
            'full_target_witness':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks)
    print(json.dumps({k:v for k,v in checks.items() if k!='cases'}))

if __name__=='__main__':
    main()
