"""Cover certified continuous free-center regions by small-diameter rectangles."""
from pathlib import Path
from math import isqrt
from hashlib import sha256
import json, shutil, time
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'output/h5-cog-center-capacity-20261020'
OUT = ROOT/'output/h5-cog-center-band-cover-20261020'
load = lambda p:json.loads(p.read_bytes())
digest = lambda p:sha256(p.read_bytes()).hexdigest()

def write(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,indent=2)
        f.write('\n')

def cover_strip(cells,lo,hi,d):
    height = hi-lo
    if height >= d:
        return None
    width = isqrt(d*d-height*height-1)
    if width < 1:
        return None
    intervals = sorted((a,c) for a,b,c,e in cells if b < hi and e > lo)
    merged = []
    for a,c in intervals:
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1],c)
        else:
            merged.append([a,c])
    rectangles = []
    end = None
    for a,c in merged:
        cursor = max(a,end) if end is not None else a
        while cursor < c:
            rectangles.append([cursor,lo,cursor+width,hi])
            end = cursor+width
            cursor = end
    return rectangles

def solve(cells,d,axis):
    if axis == 'vertical':
        cells = [[b,a,e,c] for a,b,c,e in cells]
    low,high = min(c[1] for c in cells),max(c[3] for c in cells)
    points = sorted({c[k] for c in cells for k in [1,3]} |
                    {low+(high-low)*i//64 for i in range(65)})
    scores = [10**9]*len(points)
    parents = [None]*len(points)
    scores[0] = 0
    candidates = 0
    for j in range(1,len(points)):
        for i in range(j-1,-1,-1):
            if points[j]-points[i] >= d:
                break
            rects = cover_strip(cells,points[i],points[j],d)
            candidates += 1
            if rects is not None and scores[i]+len(rects) < scores[j]:
                scores[j] = scores[i]+len(rects)
                parents[j] = i
    assert parents[-1] is not None
    j = len(points)-1
    bands = []
    rectangles = []
    while j:
        i = parents[j]
        bands.append([points[i],points[j]])
        rectangles.extend(cover_strip(cells,points[i],points[j],d))
        j = i
    if axis == 'vertical':
        rectangles = [[b,a,e,c] for a,b,c,e in rectangles]
    return {'axis':axis,'candidate_boundaries':points,'candidate_strips':candidates,
            'selected_bands':list(reversed(bands)),'rectangles_units':rectangles,'capacity':len(rectangles)}

def audit_cover(cells,rects,d):
    assert all(a<c and b<e and (c-a)**2+(e-b)**2 < d*d for a,b,c,e in rects)
    # Separate exact rectangle-union coverage audit, independent of DP choices.
    for cell in cells:
        a,b,c,e = cell
        xs = sorted({a,c}|{x for r in rects for x in [r[0],r[2]] if a<x<c})
        for left,right in zip(xs,xs[1:]):
            intervals = sorted((max(b,r[1]),min(e,r[3])) for r in rects
                               if 2*r[0] <= left+right <= 2*r[2] and r[1]<e and r[3]>b)
            cursor = b
            for lo,hi in intervals:
                assert lo <= cursor, (cell,left,right,cursor,lo)
                cursor = max(cursor,hi)
                if cursor >= e:
                    break
            assert cursor >= e
    return True

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'cover.py')
    inputs = [SRC/n for n in ['disk.json','sheet-0.json','sheet-1.json','audit/checks.json']]
    write(OUT/'plan.json',{'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
          'method':'One finite dynamic program in each axis per sheet. Band boundaries comprise free-cell sides and 65 evenly spaced integer points. Every band is covered by rectangles of squared diagonal strictly below the necessary center-separation squared. Independently audit full free-cell coverage by the resulting rectangle union.',
          'solver_calls':0,'native_packing_calls':0,'quality_runs':0,'limit_extensions':0})
    assert load(SRC/'audit/checks.json')['passed']
    d = load(SRC/'disk.json')['center_separation_units']
    start = time.perf_counter()
    rows = []
    for sheet in ['sheet-0','sheet-1']:
        cells = load(SRC/f'{sheet}.json')['free_cells_units']
        candidates = []
        for axis in ['horizontal','vertical']:
            r = solve(cells,d,axis)
            assert audit_cover(cells,r['rectangles_units'],d)
            write(OUT/f'{sheet}-{axis}.json',r)
            candidates.append(r)
        best = min(candidates,key=lambda r:r['capacity'])
        rows.append({'sheet':sheet,'capacities':{r['axis']:r['capacity'] for r in candidates},
                     'chosen_axis':best['axis'],'upper_bound':best['capacity']})
    bound = sum(r['upper_bound'] for r in rows)
    result = {'passed':True,'sheets':rows,'all_angle_cog_upper_bound':bound,
              'prior_component_box_bound':18,'required15_ruled_out':bound<15,
              'all_four_covers_independently_verified':True,'seconds':time.perf_counter()-start,
              'scope':'Arbitrary angles and continuous cog positions, but exactly the same51 fixed non-cog poses. A bound at least15 is inconclusive.'}
    write(OUT/'checks.json',result)
    print(json.dumps(result))

if __name__ == '__main__':
    main()
