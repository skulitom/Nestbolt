"""Independent rational containment and exact rectangle-complement certificate audit."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json, math, shutil, time
from hashlib import sha256

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'output/h5-cog-center-capacity-20261020'
OUT = RUN / 'audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
S = 10000
q = F

def write(path, obj):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(obj, f, indent=2)
        f.write('\n')

def cross(a, b, p):
    return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])

def winding(p, vs):
    n = 0
    for a, b in zip(vs, vs[1:]+vs[:1]):
        c = cross(a, b, p)
        if c == 0 and all(min(a[k], b[k]) <= p[k] <= max(a[k], b[k]) for k in [0,1]):
            return 0
        if a[1] <= p[1] < b[1] and c > 0:
            n += 1
        elif b[1] <= p[1] < a[1] and c < 0:
            n -= 1
    return n

def intersects_rectangle(a, b, rect):
    interval = [F(0), F(1)]
    for k in [0,1]:
        lo, hi, d = rect[k], rect[k+2], b[k]-a[k]
        if not d:
            if a[k] < lo or a[k] > hi:
                return False
        else:
            limits = sorted([(lo-a[k])/d, (hi-a[k])/d])
            interval = [max(interval[0], limits[0]), min(interval[1], limits[1])]
            if interval[0] > interval[1]:
                return False
    return True

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT/'audit.py')
    started = time.perf_counter()
    plan = load(RUN/'plan.json')
    for p, h in plan['inputs'].items():
        assert digest(ROOT/p) == h
    source = ROOT/'output/h5-coordinated-placement-selection-20261018'
    job = load(source/'job.json')
    target = load(source/'conditional-target.json')
    parts = {p['id']:p for p in job['parts']}
    disk = load(RUN/'disk.json')
    center = [F(*x) for x in disk['center']]
    cog = [[q(x),q(y)] for x,y in parts['cog']['geometry'][0]['outer']]
    assert winding(center, cog) != 0
    distances = []
    for a,b in zip(cog,cog[1:]+cog[:1]):
        v = [b[k]-a[k] for k in [0,1]]
        t = sum((center[k]-a[k])*v[k] for k in [0,1])/sum(x*x for x in v)
        t = min(F(1), max(F(0), t))
        distances.append(sum((center[k]-a[k]-t*v[k])**2 for k in [0,1]))
    minimum = min(distances)
    assert minimum == F(*disk['minimum_boundary_distance_squared'])
    radius = disk['radius_units']
    assert F(radius,S)**2 < minimum
    clearance = disk['effective_clearance_units']
    assert F(clearance,S) < q(job['clearance']) - F(1,1000000)
    assert disk['center_separation_units'] == 2*radius+clearance
    padding = disk['forbidden_offset_radius_units']
    assert padding < radius+clearance
    offsets = disk['offset_rectangles_half_sizes_units']
    assert all(a >= 0 and b >= 0 and a*a+b*b <= padding*padding for a,b in offsets)
    pool = load(ROOT/'output/h5-insert-aligned-frame-pool-20261020/candidates.json')
    selected = load(ROOT/'output/h5-joint-full-frame-small-search-20261020/selected-indices.json')
    fixed = {i for i in selected if pool[i]['placement']['part_id'] != 'cog'}
    assert Counter(pool[i]['placement']['part_id'] for i in fixed) == Counter(frame=18,bracket=12,insert=21)
    primitives = load(RUN/'interior-rectangles.json')
    for primitive in primitives:
        i = primitive['fixed_candidate']
        assert i in fixed
        p = pool[i]['placement']
        assert primitive['sheet_id'] == p['sheet_id']
        t = p['transform']
        c,s = math.cos(t['rotation_radians']),math.sin(t['rotation_radians'])
        vs = []
        for x,y in parts[p['part_id']]['geometry'][0]['outer']:
            if t['mirrored']:
                x = -x
            vs.append([q(x*c-y*s+t['translation'][0]), q(x*s+y*c+t['translation'][1])])
        rect = [F(v,S) for v in primitive['inner_rectangle_units']]
        assert rect[0] < rect[2] and rect[1] < rect[3]
        corners = [(rect[0],rect[1]),(rect[2],rect[1]),(rect[2],rect[3]),(rect[0],rect[3])]
        assert all(winding(p,vs) for p in corners)
        assert not any(intersects_rectangle(a,b,rect) for a,b in zip(vs,vs[1:]+vs[:1]))
    rows = []
    for sheet in ['sheet-0','sheet-1']:
        r = load(RUN/f'{sheet}.json')
        stock = job['stocks'][0]
        m,edge = stock['margins'],q(job['edge_clearance'])
        h = q(stock['height'] if sheet == 'sheet-0' else target['required_used_height_mm'])
        margin = F(1,1000000)
        expected = [math.floor((q(m['left'])+edge+F(radius,S)-margin)*S),
                    math.floor((q(m['bottom'])+edge+F(radius,S)-margin)*S),
                    math.ceil((q(stock['width'])-q(m['right'])-edge-F(radius,S)+margin)*S),
                    math.ceil((h-q(m['top'])-edge-F(radius,S)+margin)*S)]
        assert r['domain_units'] == expected
        left,bottom,right,top = expected
        obstacles = []
        for p in primitives:
            if p['sheet_id'] != sheet:
                continue
            x0,y0,x1,y1 = p['inner_rectangle_units']
            for a,b in offsets:
                box = [max(left,x0-a),max(bottom,y0-b),min(right,x1+a),min(top,y1+b)]
                if box[0] < box[2] and box[1] < box[3]:
                    obstacles.append(box)
        assert obstacles == r['forbidden_rectangles_units']
        xs = sorted({left,right}|{v for b in obstacles for v in [b[0],b[2]]})
        rebuilt = []
        for x0,x1 in zip(xs,xs[1:]):
            active = [b for b in obstacles if 2*b[0] < x0+x1 < 2*b[2]]
            ys = sorted({bottom,top}|{v for b in active for v in [b[1],b[3]]})
            intervals = []
            for y0,y1 in zip(ys,ys[1:]):
                if not any(2*b[1] < y0+y1 < 2*b[3] for b in active):
                    if intervals and intervals[-1][1] == y0:
                        intervals[-1][1] = y1
                    else:
                        intervals.append([y0,y1])
            rebuilt.extend([[x0,y0,x1,y1] for y0,y1 in intervals])
        assert rebuilt == r['free_cells_units']
        seen = []
        for comp in r['components']:
            ids = comp['cell_indices']
            seen.extend(ids)
            box = comp['bounding_box_units']
            assert all(box[0] <= rebuilt[i][0] <= rebuilt[i][2] <= box[2]
                       and box[1] <= rebuilt[i][1] <= rebuilt[i][3] <= box[3] for i in ids)
            grid = comp['grid']
            nx,ny = grid['columns'],grid['rows']
            assert nx > 0 and ny > 0 and grid['capacity'] == nx*ny
            cw,ch = (box[2]-box[0]+nx-1)//nx,(box[3]-box[1]+ny-1)//ny
            assert cw == grid['maximum_cell_width_units'] and ch == grid['maximum_cell_height_units']
            assert cw*cw+ch*ch < disk['center_separation_units']**2
        assert sorted(seen) == list(range(len(rebuilt)))
        assert sum(c['grid']['capacity'] for c in r['components']) == r['cog_upper_bound']
        rows.append({'sheet':sheet,'free_cells':len(rebuilt),'forbidden_rectangles':len(obstacles),
                     'upper_bound':r['cog_upper_bound']})
    total = sum(r['upper_bound'] for r in rows)
    assert total == load(RUN/'result.json')['all_angle_cog_upper_bound']
    checks = {'passed':True,'exact_rational_disk_and_containment':True,'interior_rectangles':len(primitives),
              'complement_independently_reconstructed':True,'sheets':rows,'all_angle_cog_upper_bound':total,
              'required15_ruled_out':total<15,'fixed_non_cog_parts':len(fixed),'seconds':time.perf_counter()-started,
              'boundary_coverage':'Forbidden rectangles lie strictly inside necessary forbidden distance regions. Any valid center therefore has positive distance from them; the closures of positive-width complementary cells cover every valid center, including stock edges.',
              'scope':'Fixed 51 non-cog poses, filled outer outlines, arbitrary cog angles and continuous centers. An upper bound at least 15 is inconclusive.',
              'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks)
    print(json.dumps(checks))

if __name__ == '__main__':
    main()
