"""Independent reachable-area, continuous-cover and seed-witness audit."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import json, math, shutil, time
from shapely.geometry import box, Point
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
ROOT = Path(__file__).resolve().parents[1]
CENTER = ROOT/'output/h5-cog-center-capacity-20261020'
BAND = ROOT/'output/h5-cog-center-band-cover-20261020'
RUN = ROOT/'output/h5-cog-reachable-area-20261020'
OUT = RUN/'audit'
ORIGINAL = ROOT/'output/h5-coordinated-placement-selection-20261018'
S = 10000
load = lambda p:json.loads(p.read_bytes())
digest = lambda p:sha256(p.read_bytes()).hexdigest()

def write(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,indent=2)
        f.write('\n')

def exact_difference_area(included,excluded):
    """Event sweep with active rectangle counts on every elementary y interval."""
    events = {}
    ys = sorted({v for r in included+excluded for v in [r[1],r[3]]})
    yi = {v:i for i,v in enumerate(ys)}
    for group,rects in enumerate([included,excluded]):
        for a,b,c,d in rects:
            events.setdefault(a,[]).append((group,yi[b],yi[d],1))
            events.setdefault(c,[]).append((group,yi[b],yi[d],-1))
    counts = [[0]*(len(ys)-1) for _ in range(2)]
    total = 0
    last = None
    for x,changes in sorted(events.items()):
        if last is not None:
            total += (x-last)*sum(ys[j+1]-ys[j] for j in range(len(ys)-1)
                                  if counts[0][j]>0 and counts[1][j]==0)
        for g,start,end,delta in changes:
            for j in range(start,end):
                counts[g][j] += delta
                assert counts[g][j]>=0
        last = x
    assert all(v==0 for group in counts for v in group)
    return total

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'audit.py')
    start = time.perf_counter()
    inputs = {}
    for root in [CENTER,BAND,RUN]:
        for p,h in load(root/'plan.json')['inputs'].items():
            assert digest(ROOT/p)==h
            inputs[p]=h
    assert load(CENTER/'audit/checks.json')['passed']
    job = load(ORIGINAL/'job.json')
    cog = next(p for p in job['parts'] if p['id']=='cog')
    vs = [[F(x),F(y)] for x,y in cog['geometry'][0]['outer']]
    c = [F(*v) for v in load(CENTER/'disk.json')['center']]
    r = load(RUN/'cog.json')
    radius = r['circumradius_units']
    assert all(sum((p[k]-c[k])**2 for k in [0,1]) < F(radius,S)**2 for p in vs)
    a = vs[0]
    area = abs(sum((b[0]-a[0])*(d[1]-a[1])-(b[1]-a[1])*(d[0]-a[0])
                   for b,d in zip(vs[1:],vs[2:])))/2
    assert area==F(*r['filled_area_exact'])
    area_lower = F(*r['filled_area_lower_bound'])
    assert 0 < area_lower <= area-F(1,1000000)
    primitives = load(CENTER/'interior-rectangles.json')
    target = load(ORIGINAL/'conditional-target.json')
    pool = load(ROOT/'output/h5-insert-aligned-frame-pool-20261020/candidates.json')
    selected = load(ROOT/'output/h5-joint-full-frame-small-search-20261020/selected-indices.json')
    d = load(CENTER/'disk.json')['center_separation_units']
    rows = []
    for sheet in ['sheet-0','sheet-1']:
        saved = load(RUN/f'{sheet}.json')
        free = load(CENTER/f'{sheet}.json')['free_cells_units']
        stock = job['stocks'][0]
        m,edge = stock['margins'],F(job['edge_clearance'])
        height = F(stock['height'] if sheet=='sheet-0' else target['required_used_height_mm'])
        t = F(1,1000000)
        domain = [math.floor((F(m['left'])+edge-t)*S),math.floor((F(m['bottom'])+edge-t)*S),
                  math.ceil((F(stock['width'])-F(m['right'])-edge+t)*S),
                  math.ceil((height-F(m['top'])-edge+t)*S)]
        assert domain==saved['usable_domain_units']
        left,bottom,right,top = domain
        included = [[max(left,a-radius),max(bottom,b-radius),min(right,c+radius),min(top,e+radius)]
                    for a,b,c,e in free]
        excluded = []
        for p in primitives:
            if p['sheet_id']==sheet:
                a,b,cx,e = p['inner_rectangle_units']
                clipped = [max(left,a),max(bottom,b),min(right,cx),min(top,e)]
                if clipped[0]<clipped[2] and clipped[1]<clipped[3]:
                    excluded.append(clipped)
        assert included==saved['included_reachable_rectangles']
        assert excluded==saved['excluded_solid_rectangles']
        measure = exact_difference_area(included,excluded)
        assert measure==saved['reachable_area_units_squared']
        upper = F(measure,S*S)//area_lower
        assert upper==saved['cog_upper_bound']
        bands = []
        for axis in ['horizontal','vertical']:
            cover = load(BAND/f'{sheet}-{axis}.json')
            rects = cover['rectangles_units']
            assert cover['capacity']==len(rects)
            assert all(a<cx and b<e and (cx-a)**2+(e-b)**2<d*d for a,b,cx,e in rects)
            assert exact_difference_area(free,rects)==0
            # Closed rectangles cover free-cell interiors, hence also their closures.
            bands.append(len(rects))
        reachable = unary_union([box(*(v/S for v in b)) for b in included]).difference(
            unary_union([box(*(v/S for v in b)) for b in excluded]))
        assert abs(reachable.area-measure/(S*S))<1e-6
        center_region = unary_union([box(*(v/S for v in b)) for b in free])
        seeds = []
        for i in selected:
            p=pool[i]['placement']
            if p['part_id']!='cog' or p['sheet_id']!=sheet:
                continue
            tr=p['transform']
            theta=tr['rotation_radians']
            cx,cy=map(float,c)
            if tr['mirrored']:
                cx=-cx
            center=(cx*math.cos(theta)-cy*math.sin(theta)+tr['translation'][0],
                    cx*math.sin(theta)+cy*math.cos(theta)+tr['translation'][1])
            assert center_region.covers(Point(center))
            outside=shape(cog,tr).difference(reachable).area
            assert outside<1e-7
            seeds.append({'candidate':i,'center':center,'area_outside_reachable_region_mm2':outside})
        rows.append({'sheet':sheet,'reachable_area_mm2':measure/(S*S),'area_bound':upper,
                     'band_bounds':bands,'combined_upper_bound':min(upper,*bands),'seed_cogs':seeds})
    total=sum(r['combined_upper_bound'] for r in rows)
    assert sum(len(r['seed_cogs']) for r in rows)==9
    checks={'passed':True,'sheets':rows,'all_angle_cog_upper_bound':total,
            'required15_ruled_out':total<15,'nine_known_cogs_retained':True,
            'independent_rational_circumradius_and_area':True,'third_exact_area_algorithm_matches':True,
            'independent_four_band_cover_audits':True,'inputs':inputs,
            'seconds':time.perf_counter()-start,
            'conclusion':'At most13 cogs fit with these51 non-cog poses, even at arbitrary angles and continuous positions. At least one non-cog pose must change to reach the original15.',
            'scope':'Necessary geometric upper bound only, not an attainable13-cog layout or an impossibility claim after non-cog parts move.',
            'full_target_witness':False,'native_packing_calls':0,'quality_runs':0}
    assert total==13
    write(OUT/'checks.json',checks)
    print(json.dumps({k:v for k,v in checks.items() if k not in ['sheets','inputs']}))

if __name__ == '__main__':
    main()
