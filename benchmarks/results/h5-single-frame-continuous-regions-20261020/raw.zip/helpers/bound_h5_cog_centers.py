"""Necessary center-space bound using inscribed disks and exact integer rectangles."""
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction as F
from math import isqrt
import json, math, shutil, time
from reduce_h5_free_cog_pool import ROOT, SRC as ORIGINAL, load, write, digest

JOINT = ROOT / 'output/h5-joint-full-frame-small-search-20261020'
POOL = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
OUT = ROOT / 'output/h5-cog-center-capacity-20261020'
SCALE = 10000

def q(v):
    return F(v) if isinstance(v, int) else F.from_float(v)

def point_inside(p, poly):
    x, y = p
    inside = False
    for a, b in zip(poly, poly[1:] + poly[:1]):
        cross = (b[0] - a[0]) * (y - a[1]) - (b[1] - a[1]) * (x - a[0])
        if cross == 0 and min(a[0], b[0]) <= x <= max(a[0], b[0]) and min(a[1], b[1]) <= y <= max(a[1], b[1]):
            return False
        if (a[1] > y) != (b[1] > y):
            hit = a[0] + (y - a[1]) * (b[0] - a[0]) / (b[1] - a[1])
            if x < hit:
                inside = not inside
    return inside

def segment_enters_box(a, b, box):
    low, high = F(0), F(1)
    for k, lo, hi in [(0, box[0], box[2]), (1, box[1], box[3])]:
        d = b[k] - a[k]
        if d == 0:
            if not lo < a[k] < hi:
                return False
        else:
            one, two = (lo - a[k]) / d, (hi - a[k]) / d
            low, high = max(low, min(one, two)), min(high, max(one, two))
    return low < high

def box_inside(box, poly):
    corners = [(box[0], box[1]), (box[2], box[1]), (box[2], box[3]), (box[0], box[3])]
    return (all(point_inside(p, poly) for p in corners)
            and not any(segment_enters_box(a, b, box) for a, b in zip(poly, poly[1:] + poly[:1])))

def distance_squared(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    dot = (p[0] - a[0]) * dx + (p[1] - a[1]) * dy
    length = dx * dx + dy * dy
    if dot <= 0:
        return (p[0] - a[0]) ** 2 + (p[1] - a[1]) ** 2
    if dot >= length:
        return (p[0] - b[0]) ** 2 + (p[1] - b[1]) ** 2
    return ((p[0] - a[0]) * dy - (p[1] - a[1]) * dx) ** 2 / length

def transform(points, t):
    c, s = math.cos(t['rotation_radians']), math.sin(t['rotation_radians'])
    mirror = -1 if t['mirrored'] else 1
    x, y = t['translation']
    return [(mirror * a * c - b * s + x, mirror * a * s + b * c + y) for a, b in points]

def free_slabs(domain, obstacles):
    left, bottom, right, top = domain
    clipped = []
    for a, b, c, d in obstacles:
        box = [max(left, a), max(bottom, b), min(right, c), min(top, d)]
        if box[0] < box[2] and box[1] < box[3]:
            clipped.append(box)
    xs = sorted({left, right} | {x for r in clipped for x in [r[0], r[2]]})
    cells = []
    slab_nodes = []
    parent = []
    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    previous = []
    for x0, x1 in zip(xs, xs[1:]):
        intervals = sorted((b, d) for a, b, c, d in clipped if a <= x0 and x1 <= c)
        union = []
        for lo, hi in intervals:
            if union and lo <= union[-1][1]:
                union[-1][1] = max(union[-1][1], hi)
            else:
                union.append([lo, hi])
        cursor = bottom
        free = []
        for lo, hi in union:
            if cursor < lo:
                free.append((cursor, lo))
            cursor = max(cursor, hi)
        if cursor < top:
            free.append((cursor, top))
        current = []
        for lo, hi in free:
            i = len(cells)
            cells.append([x0, lo, x1, hi])
            parent.append(i)
            current.append(i)
            for j in previous:
                if max(lo, cells[j][1]) <= min(hi, cells[j][3]):
                    a, b = find(i), find(j)
                    if a != b:
                        parent[a] = b
        slab_nodes.append(current)
        previous = current
    groups = {}
    for i in range(len(cells)):
        groups.setdefault(find(i), []).append(i)
    return cells, list(groups.values()), clipped

def box_grid_capacity(box, separation):
    width, height = box[2] - box[0], box[3] - box[1]
    step = isqrt((separation * separation - 1) // 2)
    ceildiv = lambda a, b: (a + b - 1) // b
    initial = max(1, ceildiv(width, step)) * max(1, ceildiv(height, step))
    best = None
    for nx in range(1, initial + 1):
        cw = ceildiv(width, nx)
        if cw >= separation:
            continue
        max_height = isqrt(separation * separation - cw * cw - 1)
        if max_height == 0:
            continue
        ny = max(1, ceildiv(height, max_height))
        ch = ceildiv(height, ny)
        assert cw * cw + ch * ch < separation * separation
        record = {'columns': nx, 'rows': ny, 'capacity': nx * ny,
                  'maximum_cell_width_units': cw, 'maximum_cell_height_units': ch}
        if best is None or record['capacity'] < best['capacity']:
            best = record
    assert best is not None
    return best

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'bound.py')
    sources = [JOINT / 'selected-indices.json', JOINT / 'audit/checks.json',
               POOL / 'candidates.json', ORIGINAL / 'job.json', ORIGINAL / 'conditional-target.json']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'units_per_mm': SCALE, 'offset_samples': 17,
        'method': 'Use a rational radius strictly below the exact local filled-outer cog inradius about a rational interior center. Every cog at any angle contains this disk. For each fixed non-cog polygon, derive strictly interior axis rectangles and verify containment with exact rational predicates on original transformed vertices. Expand each by17 integer axis rectangles contained in a disk of radius R+effective_clearance-0.0001mm. Their union is a necessary forbidden center region. Compute its complement inside outward-rounded stock center domains with exact integer rectangle sweeps. Cover each resulting component bounding box by grid cells of diagonal strictly below2R+effective_clearance; each cell holds at most one cog center.',
        'effective_clearance': 'Floor (original clearance -0.000001mm) to the0.0001mm grid, weaker than the original0.2mm requirement and its0.0000001mm geometry-check tolerance.',
        'scope': 'A necessary geometric bound for the51 fixed non-cog filled-outer poses, allowing arbitrary cog angles/positions. A bound15 or greater is inconclusive. This does not bound rearranged non-cog parts.',
        'solver_calls': 0, 'native_packing_calls': 0, 'quality_runs': 0})
    start = time.perf_counter()
    job = load(ORIGINAL / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    raw_cog = parts['cog']['geometry'][0]['outer']
    polygon = [(q(x), q(y)) for x, y in raw_cog]
    center = (F(round(sum(x for x, _ in raw_cog) / len(raw_cog), 6)),
              F(round(sum(y for _, y in raw_cog) / len(raw_cog), 6)))
    assert point_inside(center, polygon)
    minimum = min(distance_squared(center, a, b) for a, b in zip(polygon, polygon[1:] + polygon[:1]))
    radius = math.floor(math.sqrt(float(minimum)) * SCALE) - 1
    assert radius > 0 and F(radius, SCALE) ** 2 < minimum
    clearance = math.floor((q(job['clearance']) - F(1, 1000000)) * SCALE)
    pad_radius = radius + clearance - 1
    separation = 2 * radius + clearance
    offsets = []
    for k in range(17):
        a = pad_radius * k // 16
        b = isqrt(pad_radius * pad_radius - a * a)
        assert a * a + b * b <= pad_radius * pad_radius
        offsets.append([a, b])
    write(OUT / 'disk.json', {
        'center': [[v.numerator, v.denominator] for v in center],
        'minimum_boundary_distance_squared': [minimum.numerator, minimum.denominator],
        'radius_units': radius, 'effective_clearance_units': clearance,
        'forbidden_offset_radius_units': pad_radius, 'center_separation_units': separation,
        'offset_rectangles_half_sizes_units': offsets})
    pool = load(POOL / 'candidates.json')
    fixed = [i for i in load(JOINT / 'selected-indices.json') if pool[i]['placement']['part_id'] != 'cog']
    assert Counter(pool[i]['placement']['part_id'] for i in fixed) == Counter(frame=18, bracket=12, insert=21)
    primitives = []
    for i in fixed:
        p = pool[i]['placement']
        part = parts[p['part_id']]
        local = part['geometry'][0]['outer']
        local_q = [(q(x), q(y)) for x, y in local]
        xs, ys = sorted(set(x for x, _ in local)), sorted(set(y for _, y in local))
        world_q = [(q(x), q(y)) for x, y in transform(local, p['transform'])]
        for x0, x1 in zip(xs, xs[1:]):
            for y0, y1 in zip(ys, ys[1:]):
                if not point_inside((q((x0 + x1) / 2), q((y0 + y1) / 2)), local_q):
                    continue
                corners = transform([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], p['transform'])
                inner = [math.ceil(min(x for x, _ in corners) * SCALE) + 1,
                         math.ceil(min(y for _, y in corners) * SCALE) + 1,
                         math.floor(max(x for x, _ in corners) * SCALE) - 1,
                         math.floor(max(y for _, y in corners) * SCALE) - 1]
                assert inner[0] < inner[2] and inner[1] < inner[3]
                assert box_inside([F(v, SCALE) for v in inner], world_q)
                primitives.append({'fixed_candidate': i, 'sheet_id': p['sheet_id'],
                                   'local_cell': [x0, y0, x1, y1], 'inner_rectangle_units': inner})
    write(OUT / 'interior-rectangles.json', primitives)
    stock = job['stocks'][0]
    target = load(ORIGINAL / 'conditional-target.json')
    results = []
    for sheet in ['sheet-0', 'sheet-1']:
        height = stock['height'] if sheet == 'sheet-0' else target['required_used_height_mm']
        m, edge = stock['margins'], job['edge_clearance']
        tolerance = F(1, 1000000)
        radius_mm = F(radius, SCALE)
        domain = [math.floor((q(m['left']) + q(edge) + radius_mm - tolerance) * SCALE),
                  math.floor((q(m['bottom']) + q(edge) + radius_mm - tolerance) * SCALE),
                  math.ceil((q(stock['width']) - q(m['right']) - q(edge) - radius_mm + tolerance) * SCALE),
                  math.ceil((q(height) - q(m['top']) - q(edge) - radius_mm + tolerance) * SCALE)]
        obstacles = []
        for p in primitives:
            if p['sheet_id'] != sheet:
                continue
            x0, y0, x1, y1 = p['inner_rectangle_units']
            obstacles.extend([x0 - a, y0 - b, x1 + a, y1 + b] for a, b in offsets)
        cells, groups, clipped = free_slabs(domain, obstacles)
        components = []
        for g in groups:
            bbox = [min(cells[i][0] for i in g), min(cells[i][1] for i in g),
                    max(cells[i][2] for i in g), max(cells[i][3] for i in g)]
            components.append({'cell_indices': g, 'bounding_box_units': bbox,
                               'grid': box_grid_capacity(bbox, separation)})
        record = {'sheet_id': sheet, 'domain_units': domain, 'forbidden_rectangles_units': clipped,
                  'free_cells_units': cells, 'components': components,
                  'cog_upper_bound': sum(c['grid']['capacity'] for c in components)}
        write(OUT / f'{sheet}.json', record)
        results.append({'sheet_id': sheet, 'free_cells': len(cells), 'components': len(components),
                        'cog_upper_bound': record['cog_upper_bound'],
                        'component_capacities': [c['grid']['capacity'] for c in components]})
    bound = sum(r['cog_upper_bound'] for r in results)
    result = {'radius_mm': radius / SCALE, 'effective_clearance_mm': clearance / SCALE,
              'pair_center_separation_mm': separation / SCALE,
              'interior_rectangles': len(primitives), 'sheets': results,
              'all_angle_cog_upper_bound': bound, 'required15_ruled_out': bound < 15,
              'seconds': time.perf_counter() - start, 'independent_audit_pending': True,
              'full_target_witness': False}
    write(OUT / 'result.json', result)
    print(json.dumps(result), flush=True)

if __name__ == '__main__':
    main()
