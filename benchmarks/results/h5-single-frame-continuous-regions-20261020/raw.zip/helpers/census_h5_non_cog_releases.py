"""Finite necessary-relaxation census: remove each fixed non-cog obstacle once."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
import json, shutil, time
from bound_h5_cog_centers import free_slabs, box_grid_capacity
from cover_h5_cog_centers_by_bands import solve as band_cover
from bound_h5_cog_reachable_area import sweep_area
from reduce_h5_free_cog_pool import ROOT, load, write, digest

CENTER = ROOT/'output/h5-cog-center-capacity-20261020'
AREA = ROOT/'output/h5-cog-reachable-area-20261020'
OUT = ROOT/'output/h5-single-non-cog-release-census-20261020'
S = 10000

def component_bound(cells,domain,solid,radius,separation,area_lower):
    left,bottom,right,top=domain
    included=[[max(left,a-radius),max(bottom,b-radius),min(right,c+radius),min(top,d+radius)]
              for a,b,c,d in cells]
    _,area=sweep_area(included,solid)
    area_bound=F(area,S*S)//area_lower
    bbox=[min(r[0] for r in cells),min(r[1] for r in cells),
          max(r[2] for r in cells),max(r[3] for r in cells)]
    grid=box_grid_capacity(bbox,separation)
    bands=[band_cover(cells,separation,axis) for axis in ['horizontal','vertical']]
    bound=min(area_bound,grid['capacity'],*(r['capacity'] for r in bands))
    return {'included_reachable_rectangles':included,'reachable_area_units_squared':area,
            'area_bound':area_bound,'bounding_box_units':bbox,'grid':grid,
            'band_covers':bands,'upper_bound':bound}

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'census.py')
    sources=[CENTER/n for n in ['disk.json','interior-rectangles.json','sheet-0.json','sheet-1.json','audit/checks.json']]
    sources += [AREA/n for n in ['cog.json','sheet-0.json','sheet-1.json','audit/checks.json']]
    pool_path=ROOT/'output/h5-insert-aligned-frame-pool-20261020/candidates.json'
    sources += [pool_path]
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
          'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources},
          'maximum_cases':51,'generation_seconds_limit':90,'solver_calls':0,
          'method':'In deterministic candidate-index order, remove each of the51 non-cog obstacles once. Keep the other50 original poses fixed. Recompute the conservative all-angle center region and bound each component by exact reachable area, grid diameter and two finite band covers. Also retain the tighter whole-sheet area bound when applicable. A total below15 excludes completing the job by moving only that non-cog part; a bound at least15 is merely inconclusive. No removed part is placed and no original-job acceptance is asserted.',
          'native_packing_calls':0,'quality_runs':0,'held_out_evaluations':0,
          'limit_policy':'Stop between cases at90 seconds, retain all completed cases and pending ids; no restart or limit extension.'})
    assert load(CENTER/'audit/checks.json')['passed'] and load(AREA/'audit/checks.json')['all_angle_cog_upper_bound']==13
    primitives=load(CENTER/'interior-rectangles.json')
    fixed=sorted({p['fixed_candidate'] for p in primitives})
    assert len(fixed)==51
    pool=load(pool_path)
    disk=load(CENTER/'disk.json')
    offsets=disk['offset_rectangles_half_sizes_units']
    separation=disk['center_separation_units']
    cog=load(AREA/'cog.json')
    radius=cog['circumradius_units']
    area_lower=F(*cog['filled_area_lower_bound'])
    baseline_sheets={s:load(AREA/f'{s}.json') for s in ['sheet-0','sheet-1']}
    baseline_centers={s:load(CENTER/f'{s}.json') for s in baseline_sheets}
    results=[]
    start=time.perf_counter()
    for removed in fixed:
        if time.perf_counter()-start>=90:
            break
        case_start=time.perf_counter()
        rows=[]
        for sheet in ['sheet-0','sheet-1']:
            remaining=[p for p in primitives if p['fixed_candidate']!=removed and p['sheet_id']==sheet]
            domain=baseline_centers[sheet]['domain_units']
            solid_domain=baseline_sheets[sheet]['usable_domain_units']
            left,bottom,right,top=solid_domain
            obstacles=[]
            solid=[]
            for p in remaining:
                a,b,c,d=p['inner_rectangle_units']
                obstacles.extend([[a-x,b-y,c+x,d+y] for x,y in offsets])
                r=[max(left,a),max(bottom,b),min(right,c),min(top,d)]
                if r[0]<r[2] and r[1]<r[3]:
                    solid.append(r)
            cells,groups,clipped=free_slabs(domain,obstacles)
            components=[]
            for ids in groups:
                component=component_bound([cells[i] for i in ids],solid_domain,solid,
                                          radius,separation,area_lower)
                component['cell_indices']=ids
                components.append(component)
            all_included=[r for c in components for r in c['included_reachable_rectangles']]
            _,whole_area=sweep_area(all_included,solid)
            whole_area_bound=F(whole_area,S*S)//area_lower
            bound=min(whole_area_bound,sum(c['upper_bound'] for c in components))
            rows.append({'sheet':sheet,'center_domain_units':domain,'solid_domain_units':solid_domain,
                         'forbidden_rectangles':clipped,'solid_rectangles':solid,
                         'free_cells':cells,'components':components,
                         'whole_reachable_area_units_squared':whole_area,'whole_area_bound':whole_area_bound,
                         'upper_bound':bound})
        total=sum(r['upper_bound'] for r in rows)
        record={'removed_candidate':removed,'part_id':pool[removed]['placement']['part_id'],
                'sheets':rows,'upper_bound':total,'single_pose_change_ruled_out':total<15,
                'seconds':time.perf_counter()-case_start}
        write(OUT/f'case-{removed}.json',record)
        results.append({k:record[k] for k in ['removed_candidate','part_id','upper_bound',
                                            'single_pose_change_ruled_out','seconds']})
    pending=fixed[len(results):]
    checks={'cases':results,'cases_completed':len(results),'pending_candidates':pending,
            'seconds':time.perf_counter()-start,'limit_reached':bool(pending),
            'single_pose_changes_ruled_out':sum(r['single_pose_change_ruled_out'] for r in results),
            'not_ruled_out':[r['removed_candidate'] for r in results if not r['single_pose_change_ruled_out']],
            'independent_audit_pending':True,'full_target_witness':False,
            'native_packing_calls':0,'quality_runs':0}
    write(OUT/'result.json',checks)
    print(json.dumps({k:v for k,v in checks.items() if k!='cases'}))

if __name__=='__main__':
    main()
