"""Independent exact audit of necessary continuous frame-center domains."""
from fractions import Fraction as F
import json,math,shutil,time
from audit_h5_cog_center_capacity import winding,intersects_rectangle
from audit_h5_cog_reachable_area import exact_difference_area
from reduce_h5_free_cog_pool import ROOT,SRC as ORIGINAL,load,write,digest

RUN=ROOT/'output/h5-single-frame-center-regions-20261020'
OUT=RUN/'audit'
CENTER=ROOT/'output/h5-cog-center-capacity-20261020'
POOL=ROOT/'output/h5-insert-aligned-frame-pool-20261020'
S=10000

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'audit.py')
    start=time.perf_counter()
    for p,h in load(RUN/'plan.json')['inputs'].items():
        assert digest(ROOT/p)==h
    assert load(CENTER/'audit/checks.json')['passed']
    job=load(ORIGINAL/'job.json')
    frame=next(p for p in job['parts'] if p['id']=='frame')
    assert frame['geometry'][0]['outer']==[[0.0,0.0],[450.0,0.0],[450.0,350.0],[0.0,350.0]]
    moving=load(RUN/'moving-frame.json')
    assert moving['local_center']==[225.0,175.0]
    assert [r['degrees'] for r in moving['rotations']]==frame['rotations']['degrees']
    for r in moving['rotations']:
        theta=math.radians(r['degrees'])
        assert theta==r['rotation_radians'] and r['axis_class']==int(r['degrees'])%180
        c,s=math.cos(theta),math.sin(theta)
        vs=[(F((x-225)*c-(y-175)*s),F((x-225)*s+(y-175)*c))
            for x,y in frame['geometry'][0]['outer']]
        hx,hy=r['half_width_units'],r['half_height_units']
        assert [hx,hy]==([2249998,1749998] if r['axis_class']==0 else [1749998,2249998])
        rect=[F(-hx,S),F(-hy,S),F(hx,S),F(hy,S)]
        corners=[(x,y) for x in [rect[0],rect[2]] for y in [rect[1],rect[3]]]
        assert all(winding(p,vs) for p in corners)
        assert not any(intersects_rectangle(a,b,rect) for a,b in zip(vs,vs[1:]+vs[:1]))
    pad=moving['clearance_radius_units']
    assert F(pad,S)<F(job['clearance'])-F(1,1000000)
    offsets=moving['clearance_offset_half_sizes']
    assert all(a>=0 and b>=0 and a*a+b*b<=pad*pad for a,b in offsets)
    primitives=load(CENTER/'interior-rectangles.json')
    pool=load(POOL/'candidates.json')
    result=load(RUN/'result.json')
    frames=load(ROOT/'output/h5-single-non-cog-release-census-20261020/component-covers/checks.json')['not_ruled_out']
    expected=[(i,axis,sheet) for i in frames for axis in [0,90] for sheet in ['sheet-0','sheet-1']]
    assert len(expected)==72 and not result['pending_queries']
    assert [(r['removed_candidate'],r['axis_class'],r['sheet']) for r in result['queries']]==expected
    target=load(ORIGINAL/'conditional-target.json')
    stock=job['stocks'][0]
    records=[]
    old_poses=[]
    for row in result['queries']:
        r=load(RUN/row['file'])
        removed,axis,sheet=r['removed_candidate'],r['axis_class'],r['sheet']
        hx,hy=(2249998,1749998) if axis==0 else (1749998,2249998)
        height=stock['height'] if sheet=='sheet-0' else target['required_used_height_mm']
        m,edge,tol=stock['margins'],F(job['edge_clearance']),F(1,1000000)
        domain=[math.floor((F(m['left'])+edge+F(hx,S)-tol)*S),
                math.floor((F(m['bottom'])+edge+F(hy,S)-tol)*S),
                math.ceil((F(stock['width'])-F(m['right'])-edge-F(hx,S)+tol)*S),
                math.ceil((F(height)-F(m['top'])-edge-F(hy,S)+tol)*S)]
        assert domain==r['domain_units']
        empty=domain[0]>=domain[2] or domain[1]>=domain[3]
        assert empty==r['empty_stock_center_domain']==row['empty_stock_center_domain']
        remaining=[p for p in primitives if p['fixed_candidate']!=removed]
        assert len({p['fixed_candidate'] for p in remaining})==50
        forbidden=[]
        if not empty:
            for p in remaining:
                if p['sheet_id']!=sheet:
                    continue
                a,b,c,d=p['inner_rectangle_units']
                for x,y in offsets:
                    rect=[max(domain[0],a-hx-x),max(domain[1],b-hy-y),
                          min(domain[2],c+hx+x),min(domain[3],d+hy+y)]
                    if rect[0]<rect[2] and rect[1]<rect[3]:
                        forbidden.append(rect)
        assert forbidden==r['forbidden_rectangles']
        cells=r['free_cells']
        if empty:
            assert cells==[] and r['components']==[]
        else:
            area=exact_difference_area(cells,[])
            assert area==sum((c-a)*(d-b) for a,b,c,d in cells)
            assert exact_difference_area(cells,[domain])==0
            assert exact_difference_area(cells,forbidden)==area
            assert exact_difference_area([domain],forbidden)==area
            seen=[]
            for comp in r['components']:
                seen.extend(comp['cell_indices'])
                a,b,c,d=comp['bounding_box_units']
                assert all(a<=cells[i][0]<cells[i][2]<=c and b<=cells[i][1]<cells[i][3]<=d
                           for i in comp['cell_indices'])
            assert sorted(seen)==list(range(len(cells)))
        p=pool[removed]['placement']
        t=p['transform']
        old_axis=(round(t['rotation_radians']/(math.pi/2))%2)*90
        if p['sheet_id']==sheet and old_axis==axis:
            c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians'])
            x=(225*c-175*s+t['translation'][0])*S
            y=(225*s+175*c+t['translation'][1])*S
            assert any(a<=x<=cx and b<=y<=d for a,b,cx,d in cells)
            old_poses.append(removed)
        records.append({'removed_candidate':removed,'axis_class':axis,'sheet':sheet,
                        'free_cells':len(cells),'components':len(r['components']),'empty_stock_domain':empty})
    assert sorted(old_poses)==sorted(frames)
    checks={'passed':True,'queries_verified':len(records),'all_four_rotations_containment_exact':True,
            'all_forbidden_rectangles_exact':True,'all_center_complements_exact':True,
            'original_frame_poses_retained':len(old_poses),'records':records,
            'nonempty_queries':sum(r['free_cells']>0 for r in records),
            'free_cells_verified':sum(r['free_cells'] for r in records),
            'components_verified':sum(r['components'] for r in records),
            'seconds':time.perf_counter()-start,
            'scope':'Necessary frame-center superset for each single-frame release, with all50 other non-cog poses fixed. No new placement or full-job feasibility is asserted.',
            'full_target_witness':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks)
    print(json.dumps({k:v for k,v in checks.items() if k!='records'}))

if __name__=='__main__':
    main()
