"""Necessary continuous frame-center regions after releasing one of eighteen frames."""
from fractions import Fraction as F
from datetime import datetime,timezone
from math import isqrt
import json,math,shutil,time
from bound_h5_cog_centers import free_slabs,box_inside
from reduce_h5_free_cog_pool import ROOT,SRC as ORIGINAL,load,write,digest

CENTER=ROOT/'output/h5-cog-center-capacity-20261020'
CENSUS=ROOT/'output/h5-single-non-cog-release-census-20261020'
POOL=ROOT/'output/h5-insert-aligned-frame-pool-20261020'
OUT=ROOT/'output/h5-single-frame-center-regions-20261020'
S=10000

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'build.py')
    sources=[CENTER/n for n in ['disk.json','interior-rectangles.json','audit/checks.json']]
    sources += [CENSUS/'component-covers/checks.json',POOL/'candidates.json',
                ORIGINAL/'job.json',ORIGINAL/'conditional-target.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
          'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources},
          'maximum_queries':72,'generation_seconds_limit':120,'units_per_mm':S,
          'method':'Release each frame, retaining all50 other non-cog poses. The original rectangular frame at every allowed quarter turn contains an axis rectangle inset0.0002mm per side about its transformed local center. Verify this with exact rational containment for all four rotations. For each of two axis-size classes and two sheets, expand the certified solid rectangles of the remaining parts by these half-extents and clearance rectangles contained in a0.1998mm disk. Their exact integer complement is a necessary superset of all valid frame centers. Outward-rounded stock center bounds are weaker than original geometry. Preserve empty last-sheet domains and the original pose in its orientation class.',
          'limit_policy':'Stop between queries after120 seconds; retain pending queries without any completeness or impossibility claim.',
          'native_packing_calls':0,'solver_calls':0,'quality_runs':0})
    start=time.perf_counter()
    job=load(ORIGINAL/'job.json')
    frame=next(p for p in job['parts'] if p['id']=='frame')
    assert frame['geometry'][0]['outer']==[[0.0,0.0],[450.0,0.0],[450.0,350.0],[0.0,350.0]]
    assert frame['rotations']=={'kind':'list','degrees':[0.0,90.0,180.0,270.0]} and not frame['allow_mirror']
    local_center=[225.0,175.0]
    rotations=[]
    for degrees in frame['rotations']['degrees']:
        angle=math.radians(degrees)
        c,s=math.cos(angle),math.sin(angle)
        vs=[(F((x-225)*c-(y-175)*s),F((x-225)*s+(y-175)*c))
            for x,y in frame['geometry'][0]['outer']]
        hx,hy=(2249998,1749998) if int(degrees)%180==0 else (1749998,2249998)
        assert box_inside([F(-hx,S),F(-hy,S),F(hx,S),F(hy,S)],vs)
        rotations.append({'degrees':degrees,'rotation_radians':angle,'axis_class':int(degrees)%180,
                          'half_width_units':hx,'half_height_units':hy})
    pad=load(CENTER/'disk.json')['effective_clearance_units']-1
    assert pad==1998 and F(pad,S)<F(job['clearance'])-F(1,1000000)
    offsets=[[pad*k//16,isqrt(pad*pad-(pad*k//16)**2)] for k in range(17)]
    write(OUT/'moving-frame.json',{'local_center':local_center,'rotations':rotations,
                                  'clearance_radius_units':pad,'clearance_offset_half_sizes':offsets})
    primitives=load(CENTER/'interior-rectangles.json')
    prior=load(CENSUS/'component-covers/checks.json')
    frames=prior['not_ruled_out']
    pool=load(POOL/'candidates.json')
    assert len(frames)==18 and all(pool[i]['placement']['part_id']=='frame' for i in frames)
    target=load(ORIGINAL/'conditional-target.json')
    stock=job['stocks'][0]
    queries=[(i,axis,sheet) for i in frames for axis in [0,90] for sheet in ['sheet-0','sheet-1']]
    results=[]
    for removed,axis,sheet in queries:
        if time.perf_counter()-start>=120:
            break
        hx,hy=(2249998,1749998) if axis==0 else (1749998,2249998)
        height=stock['height'] if sheet=='sheet-0' else target['required_used_height_mm']
        m,edge=stock['margins'],F(job['edge_clearance'])
        tol=F(1,1000000)
        domain=[math.floor((F(m['left'])+edge+F(hx,S)-tol)*S),
                math.floor((F(m['bottom'])+edge+F(hy,S)-tol)*S),
                math.ceil((F(stock['width'])-F(m['right'])-edge-F(hx,S)+tol)*S),
                math.ceil((F(height)-F(m['top'])-edge-F(hy,S)+tol)*S)]
        obstacles=[]
        for p in primitives:
            if p['fixed_candidate']==removed or p['sheet_id']!=sheet:
                continue
            a,b,c,d=p['inner_rectangle_units']
            obstacles.extend([[a-hx-x,b-hy-y,c+hx+x,d+hy+y] for x,y in offsets])
        empty_domain=domain[0]>=domain[2] or domain[1]>=domain[3]
        cells,groups,clipped=([],[],[]) if empty_domain else free_slabs(domain,obstacles)
        components=[{'cell_indices':ids,
                     'bounding_box_units':[min(cells[i][0] for i in ids),min(cells[i][1] for i in ids),
                                           max(cells[i][2] for i in ids),max(cells[i][3] for i in ids)]}
                    for ids in groups]
        record={'removed_candidate':removed,'axis_class':axis,'sheet':sheet,'domain_units':domain,
                'empty_stock_center_domain':empty_domain,'forbidden_rectangles':clipped,
                'free_cells':cells,'components':components}
        name=f'frame-{removed}-axis-{axis}-{sheet}.json'
        write(OUT/name,record)
        results.append({'removed_candidate':removed,'axis_class':axis,'sheet':sheet,'file':name,
                        'empty_stock_center_domain':empty_domain,'free_cells':len(cells),
                        'components':len(components)})
    result={'queries':results,'queries_completed':len(results),'pending_queries':queries[len(results):],
            'seconds':time.perf_counter()-start,'independent_audit_pending':True,
            'candidate_frame_poses_generated':0,'full_target_witness':False,
            'native_packing_calls':0,'quality_runs':0}
    write(OUT/'result.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='queries'}| {
        'nonempty_queries':sum(r['free_cells']>0 for r in results),
        'total_free_cells':sum(r['free_cells'] for r in results),
        'total_components':sum(r['components'] for r in results)}))

if __name__=='__main__':
    main()
