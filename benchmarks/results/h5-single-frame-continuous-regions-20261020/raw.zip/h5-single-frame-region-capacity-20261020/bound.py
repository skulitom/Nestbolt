"""Bound cogs using a solid rectangle common to every frame pose in each region."""
from fractions import Fraction as F
from datetime import datetime,timezone
import json,shutil,time
from bound_h5_cog_centers import free_slabs
from census_h5_non_cog_releases import component_bound
from bound_h5_cog_reachable_area import sweep_area
from refine_h5_non_cog_release_components import max_distance_squared
from reduce_h5_free_cog_pool import ROOT,load,write,digest

FRAME=ROOT/'output/h5-single-frame-center-regions-20261020'
CENTER=ROOT/'output/h5-cog-center-capacity-20261020'
AREA=ROOT/'output/h5-cog-reachable-area-20261020'
OUT=ROOT/'output/h5-single-frame-region-capacity-20261020'
S=10000

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'bound.py')
    frame_result=load(FRAME/'result.json')
    sources=[FRAME/n for n in ['result.json','moving-frame.json','audit/checks.json']]
    sources += [FRAME/r['file'] for r in frame_result['queries']]
    sources += [CENTER/n for n in ['disk.json','interior-rectangles.json','sheet-0.json','sheet-1.json','audit/checks.json']]
    sources += [AREA/n for n in ['cog.json','sheet-0.json','sheet-1.json','audit/checks.json']]
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
          'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources},
          'maximum_region_cases':52,'seconds_limit':120,
          'method':'For each of52 audited nonempty necessary frame-center components, take its bounding box. Intersect the moving frame inner rectangle over every center in that box. The remaining common solid rectangle, if nonempty, is occupied for every allowed frame pose in the component. Add it to the original50 fixed non-cog primitives, recompute necessary all-angle cog-center regions, and bound cog counts by reachable areas, grid/band diameter covers and compatible capacity-one component cliques. All52 region bounds below15 would exclude any single-frame move. Any incomplete or larger-bound region remains inconclusive.',
          'limit_policy':'One deterministic pass; stop between cases at120 seconds, retaining pending cases. No retry.',
          'native_packing_calls':0,'solver_calls':0,'quality_runs':0})
    assert load(FRAME/'audit/checks.json')['passed']
    disk=load(CENTER/'disk.json')
    offsets=disk['offset_rectangles_half_sizes_units']
    separation=disk['center_separation_units']
    cog=load(AREA/'cog.json')
    radius=cog['circumradius_units']
    area_lower=F(*cog['filled_area_lower_bound'])
    primitives=load(CENTER/'interior-rectangles.json')
    center_sheets={s:load(CENTER/f'{s}.json') for s in ['sheet-0','sheet-1']}
    area_sheets={s:load(AREA/f'{s}.json') for s in center_sheets}
    queries=[(r,ci) for r in frame_result['queries'] for ci in range(r['components'])]
    assert len(queries)==52
    results=[]
    start=time.perf_counter()
    for query,ci in queries:
        if time.perf_counter()-start>=120:
            break
        case_start=time.perf_counter()
        source=load(FRAME/query['file'])
        removed,axis=source['removed_candidate'],source['axis_class']
        bbox=source['components'][ci]['bounding_box_units']
        hx,hy=(2249998,1749998) if axis==0 else (1749998,2249998)
        core=[bbox[2]-hx,bbox[3]-hy,bbox[0]+hx,bbox[1]+hy]
        if core[0]>=core[2] or core[1]>=core[3]:
            core=None
        rows=[]
        for sheet in ['sheet-0','sheet-1']:
            solid_raw=[p['inner_rectangle_units'] for p in primitives
                       if p['fixed_candidate']!=removed and p['sheet_id']==sheet]
            if core is not None and sheet==source['sheet']:
                solid_raw.append(core)
            obstacles=[[a-x,b-y,c+x,d+y] for a,b,c,d in solid_raw for x,y in offsets]
            domain=center_sheets[sheet]['domain_units']
            cells,groups,clipped=free_slabs(domain,obstacles)
            solid_domain=area_sheets[sheet]['usable_domain_units']
            left,bottom,right,top=solid_domain
            solid=[]
            for a,b,c,d in solid_raw:
                r=[max(left,a),max(bottom,b),min(right,c),min(top,d)]
                if r[0]<r[2] and r[1]<r[3]:
                    solid.append(r)
            components=[]
            for ids in groups:
                c=component_bound([cells[i] for i in ids],solid_domain,solid,radius,separation,area_lower)
                c['cell_indices']=ids
                components.append(c)
            included=[r for c in components for r in c['included_reachable_rectangles']]
            _,area=sweep_area(included,solid)
            whole_bound=F(area,S*S)//area_lower
            cliques=[]
            for i,c in enumerate(components):
                if c['upper_bound']!=1:
                    continue
                for group in cliques:
                    if all(max_distance_squared(c['bounding_box_units'],components[j]['bounding_box_units'])
                           <separation**2 for j in group):
                        group.append(i)
                        break
                else:
                    cliques.append([i])
            component_bound_sum=len(cliques)+sum(c['upper_bound'] for c in components if c['upper_bound']!=1)
            bound=min(whole_bound,component_bound_sum)
            rows.append({'sheet':sheet,'center_domain_units':domain,'solid_domain_units':solid_domain,
                         'forbidden_rectangles':clipped,'solid_rectangles':solid,
                         'free_cells':cells,'components':components,'capacity_one_component_cliques':cliques,
                         'whole_reachable_area_units_squared':area,'whole_area_bound':whole_bound,
                         'upper_bound':bound})
        total=sum(r['upper_bound'] for r in rows)
        record={'frame_query':query['file'],'frame_component':ci,'removed_candidate':removed,
                'axis_class':axis,'frame_sheet':source['sheet'],'frame_center_bounding_box':bbox,
                'common_solid_frame_rectangle':core,'sheets':rows,'cog_upper_bound':total,
                'region_ruled_out':total<15,'seconds':time.perf_counter()-case_start}
        name=f'region-{len(results)}.json'
        write(OUT/name,record)
        results.append({k:record[k] for k in ['frame_query','frame_component','removed_candidate',
                                             'axis_class','cog_upper_bound','region_ruled_out','seconds']}|{'file':name})
    pending=[{'query':q['file'],'component':ci} for q,ci in queries[len(results):]]
    ruled_out=len(results)==52 and all(r['region_ruled_out'] for r in results)
    result={'regions':results,'regions_completed':len(results),'pending_regions':pending,
            'seconds':time.perf_counter()-start,'all_single_frame_moves_ruled_out':ruled_out,
            'inconclusive_regions':[r['file'] for r in results if not r['region_ruled_out']],
            'independent_audit_pending':True,'full_target_witness':False,
            'native_packing_calls':0,'quality_runs':0}
    write(OUT/'result.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='regions'}))

if __name__=='__main__':
    main()
