"""Independent conditional core and all-angle cog-capacity certificate checks."""
from fractions import Fraction as F
from itertools import combinations
import json,shutil,time
from audit_h5_cog_reachable_area import exact_difference_area
from reduce_h5_free_cog_pool import ROOT,load,write,digest

FRAME=ROOT/'output/h5-single-frame-center-regions-20261020'
CENTER=ROOT/'output/h5-cog-center-capacity-20261020'
AREA=ROOT/'output/h5-cog-reachable-area-20261020'
RUN=ROOT/'output/h5-single-frame-region-capacity-20261020'
OUT=RUN/'audit'
S=10000

def audit_sheet(row,solid_raw,disk,cog):
    sheet=row['sheet']
    domain=load(CENTER/f'{sheet}.json')['domain_units']
    solid_domain=load(AREA/f'{sheet}.json')['usable_domain_units']
    assert domain==row['center_domain_units'] and solid_domain==row['solid_domain_units']
    forbidden=[]
    solid=[]
    for a,b,c,d in solid_raw:
        for x,y in disk['offset_rectangles_half_sizes_units']:
            rect=[max(domain[0],a-x),max(domain[1],b-y),min(domain[2],c+x),min(domain[3],d+y)]
            if rect[0]<rect[2] and rect[1]<rect[3]:
                forbidden.append(rect)
        rect=[max(solid_domain[0],a),max(solid_domain[1],b),
              min(solid_domain[2],c),min(solid_domain[3],d)]
        if rect[0]<rect[2] and rect[1]<rect[3]:
            solid.append(rect)
    assert forbidden==row['forbidden_rectangles'] and solid==row['solid_rectangles']
    free=row['free_cells']
    area=exact_difference_area(free,[])
    assert area==sum((c-a)*(d-b) for a,b,c,d in free)
    assert exact_difference_area(free,[domain])==0
    assert exact_difference_area(free,forbidden)==area
    assert exact_difference_area([domain],forbidden)==area
    radius=cog['circumradius_units']
    area_lower=F(*cog['filled_area_lower_bound'])
    separation=disk['center_separation_units']
    seen=[]
    included_all=[]
    component_bounds=[]
    covers=0
    for comp in row['components']:
        ids=comp['cell_indices']
        seen.extend(ids)
        cells=[free[i] for i in ids]
        left,bottom,right,top=solid_domain
        included=[[max(left,a-radius),max(bottom,b-radius),min(right,c+radius),min(top,d+radius)]
                  for a,b,c,d in cells]
        assert included==comp['included_reachable_rectangles']
        included_all.extend(included)
        measure=exact_difference_area(included,solid)
        assert measure==comp['reachable_area_units_squared']
        area_bound=F(measure,S*S)//area_lower
        assert area_bound==comp['area_bound']
        bbox=comp['bounding_box_units']
        assert all(bbox[0]<=a<c<=bbox[2] and bbox[1]<=b<d<=bbox[3] for a,b,c,d in cells)
        nx,ny=comp['grid']['columns'],comp['grid']['rows']
        assert nx>0 and ny>0 and nx*ny==comp['grid']['capacity']
        w,h=(bbox[2]-bbox[0]+nx-1)//nx,(bbox[3]-bbox[1]+ny-1)//ny
        assert w*w+h*h<separation*separation
        band_bounds=[]
        assert {c['axis'] for c in comp['band_covers']}=={'horizontal','vertical'}
        for cover in comp['band_covers']:
            boxes=cover['rectangles_units']
            assert len(boxes)==cover['capacity']
            assert all(a<c and b<d and (c-a)**2+(d-b)**2<separation*separation for a,b,c,d in boxes)
            assert exact_difference_area(cells,boxes)==0
            band_bounds.append(len(boxes))
            covers+=1
        bound=min(area_bound,nx*ny,*band_bounds)
        assert bound==comp['upper_bound']
        component_bounds.append(bound)
    assert sorted(seen)==list(range(len(free)))
    cliques=row['capacity_one_component_cliques']
    assert sorted(i for g in cliques for i in g)==[i for i,b in enumerate(component_bounds) if b==1]
    for group in cliques:
        assert group
        for i,j in combinations(group,2):
            a,b=row['components'][i]['bounding_box_units'],row['components'][j]['bounding_box_units']
            ca=[(x,y) for x in [a[0],a[2]] for y in [a[1],a[3]]]
            cb=[(x,y) for x in [b[0],b[2]] for y in [b[1],b[3]]]
            assert all((x-u)**2+(y-v)**2<separation**2 for x,y in ca for u,v in cb)
    measure=exact_difference_area(included_all,solid)
    assert measure==row['whole_reachable_area_units_squared']
    whole_bound=F(measure,S*S)//area_lower
    assert whole_bound==row['whole_area_bound']
    component_bound=len(cliques)+sum(b for b in component_bounds if b!=1)
    final=min(whole_bound,component_bound)
    assert final==row['upper_bound']
    return final,len(component_bounds),covers

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'audit.py')
    start=time.perf_counter()
    for p,h in load(RUN/'plan.json')['inputs'].items():
        assert digest(ROOT/p)==h
    assert load(FRAME/'audit/checks.json')['passed']
    result=load(RUN/'result.json')
    frame_results=load(FRAME/'result.json')
    expected=[(q['file'],i) for q in frame_results['queries'] for i in range(q['components'])]
    done=[(r['frame_query'],r['frame_component']) for r in result['regions']]
    pending=[(r['query'],r['component']) for r in result['pending_regions']]
    assert done+pending==expected and len(expected)==52
    primitives=load(CENTER/'interior-rectangles.json')
    disk=load(CENTER/'disk.json')
    cog=load(AREA/'cog.json')
    records=[]
    component_count=cover_count=0
    for summary in result['regions']:
        r=load(RUN/summary['file'])
        source=load(FRAME/r['frame_query'])
        ci=r['frame_component']
        assert r['removed_candidate']==source['removed_candidate']
        assert r['axis_class']==source['axis_class'] and r['frame_sheet']==source['sheet']
        bbox=source['components'][ci]['bounding_box_units']
        assert bbox==r['frame_center_bounding_box']
        hx,hy=(2249998,1749998) if r['axis_class']==0 else (1749998,2249998)
        core=[bbox[2]-hx,bbox[3]-hy,bbox[0]+hx,bbox[1]+hy]
        if core[0]>=core[2] or core[1]>=core[3]:
            core=None
        assert core==r['common_solid_frame_rectangle']
        if core:
            # These four center corners maximize every linear containment bound.
            for x in [bbox[0],bbox[2]]:
                for y in [bbox[1],bbox[3]]:
                    assert x-hx<=core[0]<core[2]<=x+hx and y-hy<=core[1]<core[3]<=y+hy
        remaining=[p for p in primitives if p['fixed_candidate']!=r['removed_candidate']]
        assert len({p['fixed_candidate'] for p in remaining})==50
        bounds=[]
        assert [s['sheet'] for s in r['sheets']]==['sheet-0','sheet-1']
        for row in r['sheets']:
            solid=[p['inner_rectangle_units'] for p in remaining if p['sheet_id']==row['sheet']]
            if core is not None and row['sheet']==source['sheet']:
                solid.append(core)
            bound,nc,nv=audit_sheet(row,solid,disk,cog)
            bounds.append(bound)
            component_count+=nc
            cover_count+=nv
        total=sum(bounds)
        assert total==r['cog_upper_bound']==summary['cog_upper_bound']
        assert r['region_ruled_out']==summary['region_ruled_out']==(total<15)
        records.append({'frame_query':r['frame_query'],'frame_component':ci,
                        'removed_candidate':r['removed_candidate'],'axis_class':r['axis_class'],
                        'sheet_bounds':bounds,'upper_bound':total,'region_ruled_out':total<15})
    all_excluded=len(records)==52 and all(r['region_ruled_out'] for r in records)
    assert all_excluded==result['all_single_frame_moves_ruled_out']
    checks={'passed':True,'regions_verified':len(records),'pending_regions':pending,
            'all_guaranteed_frame_cores_verified':True,'all_center_complements_and_areas_exact':True,
            'cog_components_verified':component_count,'band_covers_verified':cover_count,
            'all_single_frame_moves_ruled_out':all_excluded,
            'inconclusive_regions':[r for r in records if not r['region_ruled_out']],
            'records':records,'seconds':time.perf_counter()-start,
            'scope':'Only one non-cog frame pose may change; all50 other non-cog poses stay fixed. Cog positions and angles are unrestricted. This does not exclude changing multiple non-cog poses.',
            'full_target_witness':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks)
    print(json.dumps({k:v for k,v in checks.items() if k!='records'}))

if __name__=='__main__':
    main()
