"""Replay capped compound contacts and independently verify every small-pose/core membership."""
from collections import Counter,deque
from datetime import datetime,timezone
from itertools import combinations
import copy,math,shutil,time
import numpy as np
import shapely
from shapely.affinity import rotate
from shapely.geometry import Point,shape as from_geojson
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_shifted_core_small_contacts import ROOT,SRC,PRIOR,CAT,REF,OUT as BASE,load,write,digest,members
OUT=BASE/'audit'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(BASE/'result.json');mp=load(BASE/'mapping.json');pool=load(BASE/'candidates.json');oldpool=load(PRIOR/'candidates.json');oldn=len(oldpool);assert oldn==39488 and pool[:oldn]==oldpool and mp['new_candidates']==list(range(oldn,len(pool)))
    inputs=[BASE/n for n in ['plan.json','candidates.json','mapping.json','result.json','core-groups.json','core-checks.json','source-seeds.json','specification-checks.json','old-small-filter.json','events.json','pending.json','cache-index.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconstruct all original compound member transforms using independent whole-shape rotation, verify original internal pairs and permitted transforms, verify all saved query/member/proposal lists, and replay every FIFO member event and every family-cap deferral. Independently compute every old and new bracket/insert membership against all seven fixed cores from per-fixed-part distances and compare with complete filled core union distances. Recheck each generating contact against its declared positive padding, all stock bounds, both complete64-part baselines and original area weights. No new generation, pending-list continuation or solver call.'})
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];target=load(SRC/'conditional-target.json');clear=job['clearance'];edge=job['edge_clearance'];m=stock['margins'];padding=plan['construction_padding_mm'];groups=mp['core_groups'];original=load(CAT/'all-patterns.json');reflected=load(REF/'new-patterns.json');specmembers=[];specpairs=affines=0;maxdistance=maxarea=0.
    for si,spec in enumerate(plan['specifications']):
        mm=members(spec,original,reflected);gs=[]
        for mi,p in enumerate(mm):
            part=parts[p['part_id']];t=p['transform'];assert not t['mirrored'] or part['allow_mirror'];assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees']);g=shape(part,t);gs.append(g)
            if spec['kind']=='compound':
                source=original[spec['pattern']]['members'][mi];alternative=rotate(shape(part,source['transform']),spec['degrees'],origin=(0,0));hd=g.hausdorff_distance(alternative);area=g.symmetric_difference(alternative).area;assert hd<1e-8 and area<1e-6;affines+=1;maxdistance=max(maxdistance,hd);maxarea=max(maxarea,area)
            elif spec['kind']=='reflected':assert p==reflected[spec['pattern']]['members'][mi]
        for a,b in combinations(gs,2):assert a.disjoint(b) and a.distance(b)>=clear-1e-7;specpairs+=1
        specmembers.append(mm)
    queries=[];regions=[]
    for spec in plan['queries'][:result['completed_queries']]:
        q=load(BASE/'regions'/f"query-{spec['index']:04d}.json");assert all(q[k]==v for k,v in spec.items()) and q['members']==specmembers[q['spec_index']];region=from_geojson(q['region']);assert region.is_valid and region.is_empty==q['region_empty'] and abs(region.area-q['region_area_mm2'])<1e-7 and proposals(region)==q['proposals'];queries.append(q);regions.append(region)
    pending=load(BASE/'pending.json');assert pending['queries']==plan['queries'][len(queries):]
    caches=load(BASE/'cache-index.json');assert all(r['hausdorff_error_mm']<1e-7 and r['symmetric_difference_area_mm2']<1e-4 for r in caches)
    for r in caches:
        saved=load(BASE/'obstacles'/f"{r['index']:03d}.json");assert all(saved[k]==v for k,v in r.items()) and from_geojson(saved['geometry']).is_valid
    events=load(BASE/'events.json');queue=deque((q['index'],0) for q in queries if q['proposals']);deferred=[];keys={identity(p['placement']):i for i,p in enumerate(oldpool)};new=[];counts=Counter();ei=0;event_points=[]
    while queue:
        qi,at=queue.popleft();q=queries[qi];pi,mi=divmod(at,len(q['members']));member=q['members'][mi];f=member['part_id']
        if counts[f]>=plan['new_pose_caps'][f]:deferred.append({'query':qi,'next_member_position':at,'reason':'family_cap'});continue
        if ei==len(events):queue.appendleft((qi,at));break
        event=events[ei];ei+=1;assert (event['query'],event['proposal'],event['member'],event['core_group'])==(qi,pi,mi,q['core_group']);t=copy.deepcopy(member['transform']);x,y=t['translation'];dx,dy=q['proposals'][pi]['point'];t['translation']=[x+dx,y+dy];p={'part_id':f,'sheet_id':q['sheet_id'],'transform':t};key=identity(p);assert regions[qi].distance(Point(dx,dy))<=1e-8
        if key in keys:assert not event['added'] and event['reason']=='exact_duplicate' and event['candidate']==keys[key]
        else:
            assert event['added'];i=oldn+len(new);assert event['candidate']==i and pool[i]['placement']==p and pool[i]['index']==i;new.append(i);keys[key]=i;counts[f]+=1
        event_points.append((event['candidate'],q['core_group']))
        if at+1<len(q['proposals'])*len(q['members']):queue.append((qi,at+1))
    assert ei==len(events) and new==mp['new_candidates'] and dict(counts)==result['new_candidates_by_family']
    assert pending['member_lists']==deferred+[{'query':qi,'next_member_position':at,'reason':'time_limit'} for qi,at in queue]
    small=mp['old_small_candidates']+new;assert small==[i for i,p in enumerate(pool) if p['placement']['part_id'] in ['bracket','insert']];gs=np.asarray([shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in small],dtype=object);local={i:j for j,i in enumerate(small)};sheets=np.asarray([pool[i]['placement']['sheet_id'] for i in small]);per_sheet={s:np.flatnonzero(sheets==s) for s in ['sheet-0','sheet-1']};fixedids=sorted({i for g in groups for i in g['fixed_candidates']});fixed={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixedids};partdist={};pairchecks=0
    for i in fixedids:
        ix=per_sheet[pool[i]['placement']['sheet_id']];ds=shapely.distance(gs[ix],fixed[i]);partdist[i]=np.full(len(small),np.inf);partdist[i][ix]=ds;pairchecks+=len(ix)
    compat={i:[] for i in small};memberships=uniondistances=corepairs=0
    for g in groups:
        f=g['fixed_candidates'];assert len(f)==33 and Counter(pool[i]['placement']['part_id'] for i in f)==Counter(frame=18,cog=15)
        for i,j in combinations(f,2):
            if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
            corepairs+=1;assert fixed[i].disjoint(fixed[j]) and fixed[i].distance(fixed[j])>=clear-1e-7
        for sheet,ix in per_sheet.items():
            here=[i for i in f if pool[i]['placement']['sheet_id']==sheet];by_parts=np.minimum.reduce([partdist[i][ix] for i in here]);union=unary_union([fixed[i] for i in here]);ds=shapely.distance(gs[ix],union);assert np.array_equal(by_parts>=clear-1e-7,ds>=clear-1e-7);uniondistances+=len(ix)
            for j,d in zip(ix,ds):
                memberships+=1
                if d>=clear-1e-7:compat[small[int(j)]].append(g['index'])
    assert corepairs==result['original_core_pairs']
    oldfilter=load(BASE/'old-small-filter.json');assert [r['candidate'] for r in oldfilter]==mp['old_small_candidates']
    for row in oldfilter:assert row['compatible_groups']==compat[row['candidate']]
    generating_pairs=0;minimum_padding=math.inf;checked_events=set()
    for i,group in event_points:
        assert group in compat[i];here=[k for k in groups[group]['fixed_candidates'] if pool[k]['placement']['sheet_id']==pool[i]['placement']['sheet_id']];generating_pairs+=len(here)
        if (i,group) in checked_events:continue
        checked_events.add((i,group));j=local[i];mind=min(partdist[k][j] for k in here);minimum_padding=min(minimum_padding,mind-clear);assert mind>=clear+padding-1e-7
        p=pool[i]['placement'];a,b,c,d=gs[j].bounds;height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert a>=m['left']+edge+padding-1e-7 and b>=m['bottom']+edge+padding-1e-7 and c<=stock['width']-m['right']-edge-padding+1e-7 and d<=height-m['top']-edge-padding+1e-7
    assert generating_pairs==result['original_fixed_pair_checks']
    for i in new:
        p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform'];assert not t['mirrored'] or part['allow_mirror'];assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees']);assert abs(gs[local[i]].area-pool[i]['filled_area_mm2'])<1e-6 and pool[i]['source']['core_group'] in compat[i]
    seedpairs=0
    for seed in mp['mapped_seeds']:
        smallids=seed['selected_variable_candidates'];fixedids=groups[seed['core_group']]['fixed_candidates'];allids=fixedids+smallids;assert len(allids)==len(set(allids))==64 and Counter(pool[i]['placement']['part_id'] for i in allids)==Counter(frame=18,cog=15,bracket=10,insert=21);assert all(seed['core_group'] in compat[i] for i in smallids)
        allgs={i:(fixed[i] if i in fixed else gs[local[i]]) for i in allids}
        for i,j in combinations(allids,2):
            if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
            seedpairs+=1;assert allgs[i].disjoint(allgs[j]) and allgs[i].distance(allgs[j])>=clear-1e-7
        assert sum(mp['area_weights'][pool[i]['placement']['part_id']] for i in smallids)==815800000
    for f,w in mp['area_weights'].items():assert shape(parts[f],{'rotation_radians':0.,'mirrored':False,'translation':[0.,0.]}).area*1000==w
    ids=[i for i in small if compat[i]];assert len(ids)==result['old_eligible_small_candidates']+len(new)
    write(OUT/'memberships.json',[{'candidate':i,'compatible_groups':compat[i]} for i in small]);write(OUT/'mapping.json',{**mp,'source_pool':(BASE/'candidates.json').relative_to(ROOT).as_posix(),'candidates':ids,'compatible_groups':[compat[i] for i in ids]})
    checks={'passed':True,'seconds':time.perf_counter()-start,'original_pool_records_preserved':oldn,'new_poses_checked':len(new),'specifications_checked':len(specmembers),'compound_member_affine_checks':affines,'maximum_affine_distance_mm':maxdistance,'maximum_affine_area_difference_mm2':maxarea,'original_internal_compound_pairs':specpairs,'cache_equivalence_records_verified':len(caches),'query_regions_and_proposals_verified':len(queries),'queue_events_replayed':len(events),'family_cap_deferrals_replayed':len(deferred),'pending_queries_preserved':len(pending['queries']),'pending_member_lists_preserved':len(pending['member_lists']),'distinct_fixed_part_distances':pairchecks,'all_old_and_new_core_memberships_checked_both_methods':memberships,'core_union_distances':uniondistances,'original_core_pairs':corepairs,'original_generation_pairs_verified':generating_pairs,'minimum_construction_clearance_padding_mm':minimum_padding,'both_complete_64_baselines_verified':True,'baseline_same_sheet_pairs':seedpairs,'old_eligible_small_candidates':result['old_eligible_small_candidates'],'total_variable_choices':len(ids),'core_choices':len(groups),'original_filled_area_weights_verified':True,'seed_score':815800000,'full_score':895800000,'full_mutual_graph_and_selection_pending':True,'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
