"""Fresh original-outline small-part contacts for two baseline and five shifted-cog cores."""
from collections import Counter,deque
from datetime import datetime,timezone
from itertools import combinations
import copy,math,shutil,time,traceback
import numpy as np
import shapely
from shapely.affinity import translate,rotate
from shapely.geometry import Polygon,box,mapping
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from conservative_h5_polygon_obstacles import obstacle,circle_check
from build_h5_individual_frame_joint import ROOT,SRC,load,write,digest
PRIOR=ROOT/'output/h5-continuous-cog-joint-20261023';CAT=ROOT/'output/h5-cog-lattices-20261018';REF=ROOT/'output/h5-reflected-small-compounds-20261023';OUT=ROOT/'output/h5-shifted-core-small-contacts-20261023'
PADDING=.0126;QUERY_SECONDS=120;PROPOSAL_SECONDS=90;CAPS={'bracket':2000,'insert':2000}

def members(spec,original,reflected):
    if spec['kind']=='single':return [{'part_id':spec['family'],'transform':{'rotation_radians':math.radians(spec['degrees']),'mirrored':spec['mirrored'],'translation':[0.,0.]}}]
    if spec['kind']=='reflected':return copy.deepcopy(reflected[spec['pattern']]['members'])
    angle=math.radians(spec['degrees']);c,s=math.cos(angle),math.sin(angle);result=[]
    for p in original[spec['pattern']]['members']:
        t=copy.deepcopy(p['transform']);x,y=t['translation'];t['translation']=[c*x-s*y,s*x+c*y];t['rotation_radians']+=angle;result.append({'part_id':p['part_id'],'transform':t})
    return result

def main():
    assert load(PRIOR/'layout-audit/checks.json')['passed'] and not load(PRIOR/'layout-audit/checks.json')['full_target_witness'] and load(PRIOR/'retention/checks.json')['passed'];assert load(REF/'checks.json')['passed']
    pool=load(PRIOR/'candidates.json');oldn=len(pool);assert oldn==39488;oldmp=load(PRIOR/'mapping.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];target=load(SRC/'conditional-target.json');clear=job['clearance'];m=stock['margins'];edge=job['edge_clearance'];groups=[];seeds=[]
    for seed in oldmp['source_seeds']:
        selected=seed['selected_indices'];fixed=sorted(i for i in selected if pool[i]['placement']['part_id'] in ['frame','cog']);small=sorted(set(selected)-set(fixed));g=len(groups);groups.append({'index':g,'fixed_candidates':fixed,'source':seed['source'],'kind':'original-baseline'});counts=Counter(pool[i]['placement']['part_id'] for i in small);assert len(small)==31 and counts==Counter(bracket=10,insert=21);seeds.append({'source':seed['source'],'core_group':g,'selected_variable_candidates':small,'counts':dict(counts),'objective':815800000})
    for r in load(PRIOR/'retention/review-cores.json'):groups.append({'index':len(groups),'fixed_candidates':r['fixed_candidates'],'source_core_group':r['source_core_group'],'new_cog_candidate':r['new_cog_candidate'],'kind':'shifted-cog-review'})
    assert len(groups)==len({tuple(g['fixed_candidates']) for g in groups})==7 and len(seeds)==2
    original=load(CAT/'all-patterns.json');reflected=load(REF/'new-patterns.json');names=sorted(n for n,p in original.items() if len(p['members'])>1 and all(v['part_id'] in CAPS for v in p['members']));assert len(names)==36 and len(reflected)==114
    specs=[{'kind':'single','family':f,'degrees':angle,'mirrored':mirror} for f,angles,mirrors in [('bracket',[0,90,180,270],[False,True]),('insert',[0,90],[False])] for mirror in mirrors for angle in angles]
    specs += [{'kind':'compound','pattern':n,'degrees':angle} for n in names for angle in [0,90,180,270]]
    specs += [{'kind':'reflected','pattern':n,'degrees':0} for n in sorted(reflected)]
    queries=[{'index':j,'spec_index':si,'core_group':g['index'],'sheet_id':sheet} for j,(si,g,sheet) in enumerate((si,g,sheet) for si in range(len(specs)) for g in groups for sheet in ['sheet-0','sheet-1'])];assert len(specs)==268 and len(queries)==3752
    OUT.mkdir();(OUT/'regions').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'build.py');inputs=[PRIOR/n for n in ['candidates.json','mapping.json','layout-audit/checks.json','retention/plan.json','retention/checks.json','retention/review-cores.json','next-step.json']]+[CAT/'all-patterns.json',CAT/'audit/checks.json',REF/'new-patterns.json',REF/'checks.json']+[SRC/n for n in ['job.json','conditional-target.json']]+[ROOT/'output/conservative_h5_polygon_obstacles.py',ROOT/'output/conservative_h5_round_obstacles.py',ROOT/'output/diagnose_h5_concave_gaps.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'query_seconds':QUERY_SECONDS,'proposal_seconds':PROPOSAL_SECONDS,'new_pose_caps':CAPS,'construction_padding_mm':PADDING,'clearance_polygon':circle_check(clear,PADDING),'specifications':specs,'queries':queries,'method':'Fix one of seven original-geometry cores, each with18 frames and all15 cogs: both complete64-part baseline cores and five recorded shifted-cog review cores. Retain the entire39488-pose source pool and both exact original baseline mappings. Generate ten single-part orientation classes,36 existing two-to-four-member small-part compounds at four whole quarter turns, and114 verified reflected geometries. Cycle each specification through every core and both original sheets before the next specification. Use member-wise original-outline Minkowski exclusions with the independently verified explicit128-gon clearance offset; a compound bounding box only restricts stock translations. Audit every cached obstacle against a direct global member calculation. Preserve every region, proposal and unbuilt query. Process member proposals round-robin under separate time and family caps, recording exact duplicates, rejections and all deferred cursors. Compound members remain independently selectable. This is fresh generation for changed cores and the repaired clearance construction, not continuation of earlier capped lists.','padding_scope':'The0.0126mm construction padding is applied to new contacts with the fixed core and stock. Saved internal compound distances and existing cores retain their independently checked original values. Native-margin qualification is not claimed.','selection':'Independently verify all old and new small-part memberships against every core, then build a fresh complete mutual graph, compatibility-preserving reduction and exact constraint encoding. Preserve both64-part baseline mappings. A future model chooses exactly one33-part core and at most12 brackets and21 inserts, with original area floor815800000 and full score895800000. One60-second/eight-worker/seed-zero/presolve-disabled call only, following fresh30-second/50-million-comparison reduction and20-second compression. No earlier solver, reduction or60 unfinished cog proposal lists are resumed.','reduction_seconds':30,'reduction_comparisons':50000000,'compression_seconds':20,'solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'cp_model_presolve':False,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    write(OUT/'core-groups.json',groups);write(OUT/'source-seeds.json',seeds);fixedids=sorted({i for g in groups for i in g['fixed_candidates']});oldsmall=[i for i,p in enumerate(pool) if p['placement']['part_id'] in CAPS];geometry={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixedids+oldsmall};corepairs=0;corechecks=[]
    for group in groups:
        fixed=group['fixed_candidates'];assert len(fixed)==len(set(fixed))==33 and Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=15);minimum=math.inf
        for i,j in combinations(fixed,2):
            if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
            d=geometry[i].distance(geometry[j]);assert geometry[i].disjoint(geometry[j]) and d>=clear-1e-7;corepairs+=1;minimum=min(minimum,d)
        corechecks.append({'core_group':group['index'],'minimum_distance_mm':minimum})
    write(OUT/'core-checks.json',{'pairs':corepairs,'cores':corechecks})
    spec_members=[];spec_checks=[]
    for si,spec in enumerate(specs):
        mm=members(spec,original,reflected);gs=[shape(parts[p['part_id']],p['transform']) for p in mm];pairmin=math.inf
        for p in mm:
            t=p['transform'];part=parts[p['part_id']];assert not t['mirrored'] or part['allow_mirror'];assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
        for a,b in combinations(gs,2):d=a.distance(b);assert a.disjoint(b) and d>=clear-1e-7;pairmin=min(pairmin,d)
        spec_members.append(mm);spec_checks.append({'spec_index':si,'members':len(mm),'pairs':len(mm)*(len(mm)-1)//2,'minimum_distance_mm':None if len(mm)==1 else pairmin})
    write(OUT/'specification-checks.json',spec_checks)
    compat={i:[] for i in oldsmall};oldgs=np.asarray([geometry[i] for i in oldsmall],dtype=object);oldsheets=np.asarray([pool[i]['placement']['sheet_id'] for i in oldsmall]);here={(g['index'],sheet):[i for i in g['fixed_candidates'] if pool[i]['placement']['sheet_id']==sheet] for g in groups for sheet in ['sheet-0','sheet-1']}
    for group in groups:
        for sheet in ['sheet-0','sheet-1']:
            ix=np.flatnonzero(oldsheets==sheet);union=unary_union([geometry[i] for i in here[group['index'],sheet]]);ds=shapely.distance(oldgs[ix],union)
            for j,d in zip(ix,ds):
                if d>=clear-1e-7:compat[oldsmall[int(j)]].append(group['index'])
    for seed in seeds:assert all(seed['core_group'] in compat[i] for i in seed['selected_variable_candidates'])
    caches={};cachegs={};cache_records=[]
    def exclusion(i,member):
        fp=pool[i]['placement'];ft=fp['transform'];mt=member['transform'];fz={**ft,'translation':[0.,0.]};mz={**mt,'translation':[0.,0.]};key=(fp['part_id'],float(ft['rotation_radians']).hex(),ft['mirrored'],member['part_id'],float(mt['rotation_radians']).hex(),mt['mirrored'])
        if key not in caches:
            index=len(caches);caches[key]=index;g=obstacle(shape(parts[fp['part_id']],fz),shape(parts[member['part_id']],mz),clear,PADDING);shifted=translate(g,ft['translation'][0]-mt['translation'][0],ft['translation'][1]-mt['translation'][1]);direct=obstacle(geometry[i],shape(parts[member['part_id']],mt),clear,PADDING);hd=shifted.hausdorff_distance(direct);area=shifted.symmetric_difference(direct).area;assert hd<1e-7 and area<1e-4;cachegs[index]=g
            row={'index':index,'fixed_part':fp['part_id'],'fixed_zero_transform':fz,'moving_part':member['part_id'],'moving_zero_transform':mz,'first_fixed_candidate':i,'first_moving_member':member,'hausdorff_error_mm':hd,'symmetric_difference_area_mm2':area,'geometry':mapping(g)};write(OUT/'obstacles'/f'{index:03d}.json',row);cache_records.append({k:v for k,v in row.items() if k!='geometry'})
        return translate(cachegs[caches[key]],ft['translation'][0]-mt['translation'][0],ft['translation'][1]-mt['translation'][1])
    completed=[];start=time.perf_counter()
    for query in queries:
        if time.perf_counter()-start>=QUERY_SECONDS:break
        qstart=time.perf_counter();mm=spec_members[query['spec_index']];gg=[shape(parts[p['part_id']],p['transform']) for p in mm];a=min(g.bounds[0] for g in gg);b=min(g.bounds[1] for g in gg);c=max(g.bounds[2] for g in gg);d=max(g.bounds[3] for g in gg);height=stock['height'] if query['sheet_id']=='sheet-0' else target['required_used_height_mm'];domain=[m['left']+edge+PADDING-a,m['bottom']+edge+PADDING-b,stock['width']-m['right']-edge-PADDING-c,height-m['top']-edge-PADDING-d]
        region=box(*domain).difference(unary_union([exclusion(i,member) for i in here[query['core_group'],query['sheet_id']] for member in mm])) if domain[0]<domain[2] and domain[1]<domain[3] else Polygon();q={**query,'members':mm,'domain_bounds':domain,'region':mapping(region),'region_empty':region.is_empty,'region_area_mm2':region.area,'proposals':proposals(region),'seconds':time.perf_counter()-qstart};write(OUT/'regions'/f"query-{q['index']:04d}.json",q);completed.append(q)
        if len(completed)%100==0:print({'queries_completed':len(completed),'seconds':time.perf_counter()-start},flush=True)
    query_seconds=time.perf_counter()-start;queue=deque((q['index'],0) for q in completed if q['proposals']);deferred=[];keys={identity(p['placement']):i for i,p in enumerate(pool)};events=[];added=[];counts=Counter();pairchecks=0;start=time.perf_counter()
    while queue and time.perf_counter()-start<PROPOSAL_SECONDS:
        qi,at=queue.popleft();q=completed[qi];pi,mi=divmod(at,len(q['members']));member=q['members'][mi];f=member['part_id']
        if counts[f]>=CAPS[f]:deferred.append((qi,at));continue
        t=copy.deepcopy(member['transform']);x,y=t['translation'];dx,dy=q['proposals'][pi]['point'];t['translation']=[x+dx,y+dy];p={'part_id':f,'sheet_id':q['sheet_id'],'transform':t};g=shape(parts[f],t);a,b,c,d=g.bounds;height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>height-m['top']-edge+1e-7;fixed=here[q['core_group'],p['sheet_id']];distances=[g.distance(geometry[i]) for i in fixed];pairchecks+=len(fixed);blocked=[i for i,v in zip(fixed,distances) if v<clear-1e-7];event={'query':qi,'proposal':pi,'member':mi,'core_group':q['core_group']}
        if outside or blocked:event.update(added=False,reason='original_geometry_rejection',outside=bool(outside),fixed_blockers=blocked)
        elif identity(p) in keys:event.update(added=False,reason='exact_duplicate',candidate=keys[identity(p)])
        else:
            i=len(pool);pool.append({'index':i,'placement':p,'source':{'kind':'shifted-core-small-contact','query':qi,'proposal':pi,'member':mi,'core_group':q['core_group']},'filled_area_mm2':g.area});keys[identity(p)]=i;geometry[i]=g;added.append(i);counts[f]+=1;event.update(added=True,candidate=i)
        events.append(event)
        if at+1<len(q['proposals'])*len(q['members']):queue.append((qi,at+1))
    proposal_seconds=time.perf_counter()-start;pending={'queries':queries[len(completed):],'member_lists':[{'query':qi,'next_member_position':at,'reason':'family_cap'} for qi,at in deferred]+[{'query':qi,'next_member_position':at,'reason':'time_limit'} for qi,at in queue]}
    write(OUT/'candidates.json',pool);write(OUT/'old-small-filter.json',[{'candidate':i,'compatible_groups':compat[i]} for i in oldsmall]);write(OUT/'events.json',events);write(OUT/'pending.json',pending);write(OUT/'cache-index.json',cache_records);write(OUT/'mapping.json',{'source_pool':(PRIOR/'candidates.json').relative_to(ROOT).as_posix(),'source_pool_size':oldn,'core_groups':groups,'old_small_candidates':oldsmall,'old_eligible':[i for i in oldsmall if compat[i]],'new_candidates':added,'mapped_seeds':seeds,'area_weights':{'bracket':40000000,'insert':19800000},'family_caps':{'bracket':12,'insert':21},'fixed_family_counts':{'frame':18,'cog':15}})
    result={'source_pool_records_preserved':pool[:oldn]==load(PRIOR/'candidates.json'),'fixed_cores':len(groups),'original_baselines':len(seeds),'original_core_pairs':corepairs,'specifications':len(specs),'planned_queries':len(queries),'completed_queries':len(completed),'query_seconds':query_seconds,'query_limit_reached':query_seconds>=QUERY_SECONDS,'empty_regions':sum(q['region_empty'] for q in completed),'cache_entries_checked':len(caches),'old_small_candidates':len(oldsmall),'old_eligible_small_candidates':sum(bool(compat[i]) for i in oldsmall),'new_candidates_by_family':dict(counts),'new_candidates':len(added),'proposal_seconds':proposal_seconds,'proposal_limit_reached':proposal_seconds>=PROPOSAL_SECONDS,'family_caps_reached':{f:counts[f]>=CAPS[f] for f in CAPS},'events':len(events),'event_outcomes':dict(Counter(e.get('reason','added') for e in events)),'original_fixed_pair_checks':pairchecks,'pending_queries':len(pending['queries']),'pending_member_lists':len(pending['member_lists']),'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
