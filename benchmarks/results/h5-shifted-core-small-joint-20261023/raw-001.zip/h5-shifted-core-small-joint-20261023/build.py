"""Fresh complete geometric graph for seven fixed cores and original small parts."""
from collections import Counter
from datetime import datetime,timezone
import shutil,time
import numpy as np
import shapely
from shapely.strtree import STRtree
from audit_h5_cog_lattices import shape
from build_h5_individual_frame_joint import ROOT,SRC,load,write,digest,read_graph,save_graph
REG=ROOT/'output/h5-shifted-core-small-contacts-20261023';OUT=ROOT/'output/h5-shifted-core-small-joint-20261023'

def main():
    assert load(REG/'audit/checks.json')['passed'];mp=load(REG/'audit/mapping.json');pool=load(REG/'candidates.json');ids=mp['candidates']
    assert len(ids)==14046 and ids==sorted(set(ids)) and len(mp['core_groups'])==7 and len(mp['mapped_seeds'])==2
    assert mp['family_caps']=={'bracket':12,'insert':21} and mp['fixed_family_counts']=={'frame':18,'cog':15}
    OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');inputs=[REG/n for n in ['plan.json','candidates.json','mapping.json','result.json','audit/plan.json','audit/checks.json','audit/mapping.json']]+[SRC/n for n in ['job.json','conditional-target.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'scope':'Fresh selection of every eligible old and new bracket/insert pose across seven distinct fixed18-frame/15-cog cores. Preserve both64-part baselines and the original66-copy target. No capped proposal lists resumed.','graph':'Build every same-sheet original-geometry conflict using a spatial tree. Independently reconstruct every row using sequential bounding-box distances and exact original polygon distances. No derived cog clique or inherited old graph.','reduction_seconds':30,'maximum_reduction_comparisons':50000000,'compression_seconds':20,'additional_greedy_hint_calls':0,'solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'cp_model_presolve':False,'objective':'Variable filled area floor815800000, full score895800000; bracket12/insert21 caps and exactly one fixed33-part core. Independently reconstruct all model and parameter fields; check every returned layout against original geometry and frozen CLI.','native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    shutil.copyfile(REG/'candidates.json',OUT/'candidates.json');write(OUT/'mapping.json',mp);start=time.perf_counter();job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};clear=job['clearance'];gs=np.asarray([shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in ids],dtype=object);sheets=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);adj=[0]*len(ids);near=edges=0
    for sheet in ['sheet-0','sheet-1']:
        js=np.flatnonzero(sheets==sheet);tree=STRtree(gs[js])
        for j in js:
            ks=js[tree.query(gs[j],predicate='dwithin',distance=clear+1e-7)];ks=ks[ks>j];near+=len(ks);ks=ks[shapely.distance(gs[ks],gs[j])<clear-1e-7];j=int(j)
            for k in ks:k=int(k);adj[j]|=1<<k;adj[k]|=1<<j;edges+=1
    save_graph(OUT/'adjacency.bin.gz',adj);assert read_graph(OUT/'adjacency.bin.gz',len(ids))==adj
    result={'seconds':time.perf_counter()-start,'variable_poses':len(ids),'families':dict(Counter(pool[i]['placement']['part_id'] for i in ids)),'fixed_core_choices':7,'near_pairs':near,'geometric_conflicts':edges,'derived_edges':0,'native_margin_qualified':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
