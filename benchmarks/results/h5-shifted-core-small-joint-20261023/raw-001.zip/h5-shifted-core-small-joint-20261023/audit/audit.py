"""Independently reconstruct every small-part conflict using a sequential bounds scan."""
from collections import Counter
import shutil,time
import numpy as np
import shapely
from audit_h5_cog_lattices import shape
from build_h5_shifted_core_small_joint import ROOT,SRC,REG,OUT as BASE,load,write,digest,read_graph
OUT=BASE/'audit'

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    for name,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
    start=time.perf_counter();mp=load(BASE/'mapping.json');pool=load(BASE/'candidates.json');ids=mp['candidates'];assert mp==load(REG/'audit/mapping.json') and pool==load(REG/'candidates.json')
    actual=read_graph(BASE/'adjacency.bin.gz',len(ids));expected=[0]*len(ids);job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};clear=job['clearance'];gs=np.asarray([shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in ids],dtype=object);bb=shapely.bounds(gs);sheets=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);indexes=np.arange(len(ids));poss=exact=edges=0
    for j in range(len(ids)):
        eligible=(sheets==sheets[j])&(indexes>j);poss+=int(eligible.sum());a,b,c,d=bb[j];dx=np.maximum(np.maximum(bb[:,0]-c,a-bb[:,2]),0);dy=np.maximum(np.maximum(bb[:,1]-d,b-bb[:,3]),0);ks=np.flatnonzero(eligible&(dx*dx+dy*dy<=(clear+1e-7)**2));exact+=len(ks);ds=shapely.distance(gs[ks],gs[j])
        for k,v in zip(ks,ds):
            if v<clear-1e-7:k=int(k);expected[j]|=1<<k;expected[k]|=1<<j;edges+=1
    assert expected==actual and all(not((v>>j)&1) for j,v in enumerate(actual));local={i:j for j,i in enumerate(ids)};seeds=0
    for seed in mp['mapped_seeds']:
        chosen=seed['selected_variable_candidates'];js=[local[i] for i in chosen];selected=sum(1<<j for j in js);assert len(chosen)==len(set(chosen))==31 and Counter(pool[i]['placement']['part_id'] for i in chosen)==Counter(bracket=10,insert=21)
        assert all(not(actual[j]&selected) and seed['core_group'] in mp['compatible_groups'][j] for j in js)
        assert sum(mp['area_weights'][pool[i]['placement']['part_id']] for i in chosen)==seed['objective']==815800000;fixed=mp['core_groups'][seed['core_group']]['fixed_candidates'];assert len(fixed)==33 and Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=15) and len(set(fixed+chosen))==64;seeds+=1
    assert load(BASE/'result.json')['geometric_conflicts']==edges
    checks={'passed':True,'seconds':time.perf_counter()-start,'all_input_hashes_verified':True,'all_source_pool_and_core_mappings_preserved':True,'variable_poses':len(ids),'same_sheet_possibilities':poss,'independent_exact_distances':exact,'geometric_conflicts':edges,'every_graph_row_matches':True,'both_exact_64_baselines_verified':seeds==2,'seed_score':815800000,'full_score':895800000,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
