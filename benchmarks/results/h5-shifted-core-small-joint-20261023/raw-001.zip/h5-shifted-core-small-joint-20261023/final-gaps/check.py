"""Inspect fresh continuous insertion regions in both new 63-part arrangements."""
from collections import Counter
from datetime import datetime,timezone
import math,shutil,time
from shapely.geometry import Polygon,box,mapping,shape as read_geometry
from shapely.affinity import translate
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import proposals
from conservative_h5_polygon_obstacles import obstacle,circle_check
from build_h5_shifted_core_small_joint import ROOT,SRC,OUT as BASE,load,write,digest
OUT=BASE/'final-gaps';PADDING=.0126

def main():
    assert load(BASE/'layout-audit/checks.json')['passed'];OUT.mkdir();(OUT/'queries').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'check.py');sources=[BASE/'layout-audit'/f'layout-{index}.json' for index in ['1','final']];layouts=[load(p) for p in sources]
    assert layouts[0]!=layouts[1] and all(Counter(p['part_id'] for p in v['placements'])==Counter(frame=18,cog=15,bracket=11,insert=19) for v in layouts)
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];target=load(SRC/'conditional-target.json');queries=[{'index':j,'layout':li,'sheet_id':s,'family':f,'degrees':a,'mirrored':mir} for j,(li,s,f,a,mir) in enumerate((li,s,f,a,mir) for li in range(2) for s in ['sheet-0','sheet-1'] for f,angles,mirrors in [('bracket',[0,90,180,270],[False,True]),('insert',[0,90],[False])] for mir in mirrors for a in angles)]
    inputs=sources+[BASE/'layout-audit/checks.json',SRC/'job.json',SRC/'conditional-target.json',ROOT/'output/conservative_h5_polygon_obstacles.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'query_seconds':90,'queries':queries,'construction_padding_mm':PADDING,'clearance_polygon':circle_check(clear,PADDING),'method':'For each distinct new63-part returned layout, preserve all placements exactly. Inspect all ten permitted bracket/insert orientation/reflection classes on both original sheets using original filled outlines and the verified explicit128-gon exclusion. Independently compare every cached obstacle first use against a direct global calculation. Save every region, representative/vertex/midpoint proposal and unprocessed query. This is a fresh geometric diagnosis for changed layouts, not a solver retry or continuation of any capped list. No insertion, selection, native validation or impossibility claim. If a region is nonempty, its proposals still require original-geometry validation before use.','solver_calls':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    geometry=[[shape(parts[p['part_id']],p['transform']) for p in layout['placements']] for layout in layouts];cache={};cachegs={};checks=[];completed=[];start=time.perf_counter()
    for q in queries:
        if time.perf_counter()-start>=90:break
        mt={'rotation_radians':math.radians(q['degrees']),'mirrored':q['mirrored'],'translation':[0.,0.]};moving=shape(parts[q['family']],mt);a,b,c,d=moving.bounds;height=stock['height'] if q['sheet_id']=='sheet-0' else target['required_used_height_mm'];domain=[m['left']+edge+PADDING-a,m['bottom']+edge+PADDING-b,stock['width']-m['right']-edge-PADDING-c,height-m['top']-edge-PADDING-d];obstacles=[]
        for p,g in zip(layouts[q['layout']]['placements'],geometry[q['layout']]):
            if p['sheet_id']!=q['sheet_id']:continue
            ft=p['transform'];fz={**ft,'translation':[0.,0.]};key=(p['part_id'],float(ft['rotation_radians']).hex(),ft['mirrored'],q['family'],q['degrees'],q['mirrored'])
            if key not in cache:
                k=len(cache);cache[key]=k;local=obstacle(shape(parts[p['part_id']],fz),moving,clear,PADDING);direct=obstacle(g,moving,clear,PADDING);shifted=translate(local,*ft['translation']);hd=shifted.hausdorff_distance(direct);area=shifted.symmetric_difference(direct).area;assert hd<1e-7 and area<1e-4;cachegs[k]=local;row={'index':k,'fixed_placement':p,'moving_family':q['family'],'moving_transform':mt,'hausdorff_error_mm':hd,'area_error_mm2':area};checks.append(row);write(OUT/'obstacles'/f'{k:03d}.json',{**row,'geometry':mapping(local)})
            obstacles.append(translate(cachegs[cache[key]],*ft['translation']))
        region=box(*domain).difference(unary_union(obstacles)) if domain[0]<domain[2] and domain[1]<domain[3] else Polygon();assert region.is_valid;row={**q,'domain_bounds':domain,'region':mapping(region),'empty':region.is_empty,'region_area_mm2':region.area,'proposals':proposals(region)};assert proposals(read_geometry(row['region']))==row['proposals'];write(OUT/'queries'/f"{q['index']:03d}.json",row);completed.append(row)
    seconds=time.perf_counter()-start;write(OUT/'cache-checks.json',checks);write(OUT/'pending.json',queries[len(completed):]);assert len(queries)==40
    result={'passed':True,'seconds':seconds,'planned_queries':len(queries),'completed_queries':len(completed),'empty_regions':sum(q['empty'] for q in completed),'proposals':sum(len(q['proposals']) for q in completed),'nonempty_queries':[q['index'] for q in completed if not q['empty']],'pending_queries':len(queries)-len(completed),'cached_obstacles_independently_compared':len(cache),'both_original_layouts_unchanged':all(load(p)==v for p,v in zip(sources,layouts)),'new_placements_validated':0,'solver_calls':0,'impossibility_proof':False,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'checks.json',result);print(result,flush=True)
if __name__=='__main__':main()
