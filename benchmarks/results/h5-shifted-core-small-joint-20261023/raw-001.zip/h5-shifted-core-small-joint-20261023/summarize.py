"""Record retained new geometry and actual outcomes without extending the search."""
from collections import Counter
import shutil
from build_h5_shifted_core_small_joint import ROOT,REG,OUT,load,write,digest

def main():
    pool=load(OUT/'candidates.json');mp=load(OUT/'mapping.json');red=load(OUT/'reduced/mapping.json');subs=load(OUT/'reduced/substitutions.json');run=load(OUT/'solve/result.json');audit=load(OUT/'layout-audit/checks.json');assert audit['passed']
    new=set(mp['new_candidates']);assert new==set(range(39488,43488));kept=set(red['candidates']);removed={r['removed']:r['replacement'] for r in subs};assert new<=kept|removed.keys() and kept.isdisjoint(removed)
    percore=[]
    for g in mp['core_groups']:
        ids=[i for i,groups in zip(red['candidates'],red['compatible_groups']) if g['index'] in groups];percore.append({'core_group':g['index'],'kind':g['kind'],'retained':dict(Counter(pool[i]['placement']['part_id'] for i in ids)),'retained_new':dict(Counter(pool[i]['placement']['part_id'] for i in ids if i in new))})
    returned=[load(OUT/'solve'/f'incumbent-{i}.json') for i in range(run['incumbents'])]
    if (OUT/'solve/selected-indices.json').exists():returned.append({'index':'final','core_group':run['core_group'],'selected_indices':load(OUT/'solve/selected-indices.json')})
    outcomes=[{'index':r['index'],'core_group':r['core_group'],'selected_new':sorted(new&set(r['selected_indices']))} for r in returned]
    result={'passed':True,'new_poses':len(new),'new_retained':len(new&kept),'old_retained':len(kept-new),'new_removed_replaced_by_old':sum(i in new and r not in new for i,r in removed.items()),'new_removed_replaced_by_new':sum(i in new and r in new for i,r in removed.items()),'old_removed_replaced_by_new':sum(i not in new and r in new for i,r in removed.items()),'retained_by_family':dict(Counter(pool[i]['placement']['part_id'] for i in kept)),'retained_new_by_family':dict(Counter(pool[i]['placement']['part_id'] for i in new&kept)),'per_core':percore,'returned_new_geometry':outcomes,'full_target_witness':audit['full_target_witness'],'native_margin_qualified':False,'solver_calls_in_this_audit':0}
    shutil.copyfile(__file__,OUT/'summarize.py');write(OUT/'selection-summary.json',result);print(result,flush=True)
if __name__=='__main__':main()
