"""Complete changed all-family graph, stored as fixed-width little-endian rows."""
from collections import Counter
from datetime import datetime,timezone
import gzip,shutil,time
import numpy as np
import shapely
from shapely.geometry import box
from shapely.strtree import STRtree
from audit_h5_cog_lattices import shape
from build_h5_group_choice import ROOT,SRC,load,write,digest
COVER=ROOT/'output/h5-expanded-frame-group-coverage-20261023'
OUT=ROOT/'output/h5-expanded-frame-joint-20261023'

def save_graph(path,adj):
    width=(len(adj)+7)//8
    with gzip.open(path,'wb') as f:
        for a in adj:f.write(a.to_bytes(width,'little'))
def read_graph(path,n):
    width=(n+7)//8;adj=[]
    with gzip.open(path,'rb') as f:
        for _ in range(n):
            data=f.read(width);assert len(data)==width;adj.append(int.from_bytes(data,'little'))
        assert f.read(1)==b''
    return adj
def main():
    assert load(COVER/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py')
    mp=load(COVER/'mapping.json');source=ROOT/mp['source_pool'];inputs=[source]+[COVER/n for n in ['plan.json','mapping.json','group-filter.json','checks.json']]+[SRC/n for n in ['job.json','conditional-target.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'graph':'Choose exactly one of the 29 checked complete 18-frame groups. Recompute every mutual cog/bracket/insert conflict from all 29,631 eligible poses, preserving the exact 64-part seed in group 26. Use independently checked per-pose group compatibility. All small families move together. Query original expanded bounds through STRtree, then evaluate original filled-outer distances. Save complete undirected adjacency as n fixed-width little-endian rows, each ceil(n/8) bytes, gzip-compressed; no edge pruning or clique cap applies to the graph itself. Independently rebuild the entire graph with a sequential bounds scan before selection. Do not resume any older pending list or solver.',
      'reduction_seconds':30,'reduction_comparisons':50000000,'reduction':'Fresh adjacent same-family substitution only when N(replacement) minus removed is contained in N(removed), and replacement allows every frame group allowed by removed. Certify every original neighbor and compatible group, and map the exact 64-part seed. Compress only after this safe reduction to avoid building redundant constraints; keep every residual edge when compression ends.',
      'compression_seconds':20,'hint_seconds':30,'hint_cases':1508,'hints':'Compare 52 deterministic family/order/sheet choices for each of 29 frame groups, starting empty. Preserve the mapped 64-part seed if no fresh hint improves its original filled area. No prior reduction, graph or solver is reused.',
      'solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'objective':'Original integer filled-area weights and original family caps 12 brackets, 15 cogs, 21 inserts, with exactly one compatible complete frame group. Independently reconstruct every protobuf field and validate every returned layout against original geometry and frozen CLI. Full 66-copy acceptance, native margins, original production budget and full H5 matrix remain required.',
      'new_poses_generated':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    pool=load(source);shutil.copyfile(source,OUT/'candidates.json');ids=mp['candidates'];job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};clear=job['clearance']
    write(OUT/'mapping.json',{**mp,'seed_candidates':sorted(set(mp['seed_indices'])-set(mp['frame_groups'][mp['seed_group']]['candidates'])),'new_candidates':[]})
    gs=np.asarray([shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in ids],dtype=object);bounds=shapely.bounds(gs);sheets=[pool[i]['placement']['sheet_id'] for i in ids]
    local={s:np.asarray([j for j,v in enumerate(sheets) if v==s],dtype=int) for s in ['sheet-0','sheet-1']};trees={s:STRtree(gs[ix]) for s,ix in local.items()};adj=[0]*len(ids);near=edges=0;start=time.perf_counter()
    for i,(a,b,c,d) in enumerate(bounds):
        js=local[sheets[i]][trees[sheets[i]].query(box(a-clear-1e-7,b-clear-1e-7,c+clear+1e-7,d+clear+1e-7))];js=np.sort(js[js>i]);near+=len(js)
        for j in js[shapely.distance(gs[i],gs[js])<clear-1e-7]:j=int(j);adj[i]|=1<<j;adj[j]|=1<<i;edges+=1
        if i and i%4000==0:print({'graph_rows':i,'conflicts':edges,'seconds':time.perf_counter()-start},flush=True)
    elapsed=time.perf_counter()-start;save_graph(OUT/'adjacency.bin.gz',adj);assert read_graph(OUT/'adjacency.bin.gz',len(ids))==adj
    checks={'graph_seconds':elapsed,'retained_candidates':len(ids),'retained_by_family':dict(Counter(pool[i]['placement']['part_id'] for i in ids)),'bounds_candidates_exactly_checked':near,'conflicts':edges,'graph_format':'gzip; n consecutive ceil(n/8)-byte little-endian unsigned adjacency rows; bits are local candidate indices','graph_sha256':digest(OUT/'adjacency.bin.gz'),'all_edges_retained':True,'new_poses_generated':0,'independent_audit_pending':True}
    write(OUT/'result.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
