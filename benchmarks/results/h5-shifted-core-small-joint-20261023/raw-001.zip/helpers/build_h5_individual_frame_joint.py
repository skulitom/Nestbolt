"""Full four-family graph with independently selectable original frame poses."""
from collections import Counter
from datetime import datetime,timezone
import copy,gzip,shutil,time
import numpy as np
import shapely
from shapely.geometry import box
from shapely.strtree import STRtree
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_group_choice import ROOT,SRC,load,write,digest
from build_h5_expanded_frame_joint import read_graph
COVER=ROOT/'output/h5-all-pose-coverage-20261023'
OUT=ROOT/'output/h5-individual-frame-joint-20261023'
def save_graph(path,adj):
    width=(len(adj)+7)//8
    with gzip.open(path,'wb',compresslevel=6) as f:
        for row in adj:f.write(row.to_bytes(width,'little'))
def main():
    assert load(COVER/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py')
    mp=load(COVER/'mapping.json');source=ROOT/mp['source_pool'];seedpaths=[ROOT/mp['seed_source'],ROOT/'output/h5-expanded-frame-direct-search-20261023/layout-audit/layout-final.json']
    inputs=[source]+[COVER/n for n in ['plan.json','mapping.json','filter.json','checks.json']]+[SRC/n for n in ['job.json','conditional-target.json']]+seedpaths+[ROOT/'output/h5-expanded-frame-direct-search-20261023'/n for n in ['parameter-delta-audit.json','solve/result.json','layout-audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'graph':'Free every original frame pose individually instead of choosing one of 29 complete frame sets. Retain all 35,488 independently checked original poses, with original four-family caps. Build every frame/frame, frame/small and small/small conflict afresh from original filled outlines and exact distance at original clearance; reserved frame holes remain filled. No group-filtered graph or earlier reduction is reused. Independently rebuild the entire binary graph by sequential bounds scan. Preserve both exact original 64-part layouts by pose identity.','reduction_seconds':30,'reduction_comparisons':50000000,'reduction':'Fresh adjacent same-family substitutions with full original neighbor inclusion. Preserve both original complete hints and every unprocessed choice. Independently enumerate every substitution certificate. Project the exact induced graph.','compression_seconds':20,'compression':'Fresh first-fit clique cover, choosing the lowest-index common neighbor directly. Retain every residual edge and independently reconstruct the full induced graph. Emit residual edges as endpoint-aggregated implications to avoid separate-constraint overhead.','hint_seconds':30,'hint_cases':1960,'hints':'196 deterministic four-family order/coordinate/sheet choices for each of ten starts: both mapped original 64-part layouts, with either all poses retained or each one of four families removed. Keep the original score floor if none improve it; preserve all cases and pending work.','solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'cp_model_presolve':False,'objective':'Original filled-area weights across all four families, caps frame18/bracket12/cog15/insert21, and original best filled-area floor 4,401,740,785. Full inventory score 4,481,740,785. Exactly18 frames is a derived strengthening: even all other families with17 frames score only4,324,240,785, below the floor; independently verify the implication. Reconstruct all model fields and every returned original layout.','qualification':'A full original66-copy target witness is still required before native-margin qualification, unchanged production-budget repair and complete H5 matrix. No partial or diagnostic gets gate credit.','new_poses_generated':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    pool=load(source);shutil.copyfile(source,OUT/'candidates.json');ids=mp['candidates'];assert ids==list(range(len(pool)));keys={identity(r['placement']):i for i,r in enumerate(pool)};seeds=[]
    for path in seedpaths:
        chosen=[]
        for p in load(path)['placements']:
            p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert pool[i]['placement']==p;chosen.append(i)
        assert len(chosen)==len(set(chosen))==64
        seeds.append({'source':path.relative_to(ROOT).as_posix(),'source_sha256':digest(path),'selected_indices':sorted(chosen),'counts':dict(Counter(pool[i]['placement']['part_id'] for i in chosen)),'objective':sum(mp['area_weights'][pool[i]['placement']['part_id']] for i in chosen)})
    assert all(r['objective']==4401740785 for r in seeds);write(OUT/'mapping.json',{**mp,'seeds':seeds,'seed_candidates':seeds[0]['selected_indices'],'new_candidates':[]})
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};clear=job['clearance'];gs=np.asarray([shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in ids],dtype=object);bounds=shapely.bounds(gs);sheets=[pool[i]['placement']['sheet_id'] for i in ids]
    local={s:np.asarray([j for j,v in enumerate(sheets) if v==s],dtype=int) for s in ['sheet-0','sheet-1']};trees={s:STRtree(gs[ix]) for s,ix in local.items()};adj=[0]*len(ids);near=edges=0;start=time.perf_counter()
    for i,(a,b,c,d) in enumerate(bounds):
        js=local[sheets[i]][trees[sheets[i]].query(box(a-clear-1e-7,b-clear-1e-7,c+clear+1e-7,d+clear+1e-7))];js=np.sort(js[js>i]);near+=len(js)
        for j in js[shapely.distance(gs[i],gs[js])<clear-1e-7]:j=int(j);adj[i]|=1<<j;adj[j]|=1<<i;edges+=1
        if i and i%4000==0:print({'graph_rows':i,'conflicts':edges,'seconds':time.perf_counter()-start},flush=True)
    elapsed=time.perf_counter()-start;save_graph(OUT/'adjacency.bin.gz',adj);assert read_graph(OUT/'adjacency.bin.gz',len(ids))==adj
    check={'graph_seconds':elapsed,'retained_candidates':len(ids),'retained_by_family':dict(Counter(pool[i]['placement']['part_id'] for i in ids)),'bounds_candidates_exactly_checked':near,'conflicts':edges,'graph_format':'gzip; n consecutive ceil(n/8)-byte little-endian unsigned adjacency rows, local candidate-index bits','graph_sha256':digest(OUT/'adjacency.bin.gz'),'all_edges_retained':True,'new_poses_generated':0,'independent_audit_pending':True}
    write(OUT/'result.json',check);print(check,flush=True)
if __name__=='__main__':main()
