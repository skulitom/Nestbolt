"""One finite model lets all small families choose poses with any audited frame group."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
from collections import Counter
import gzip, heapq, itertools, json, math, shutil, time, traceback
import numpy as np
import shapely
from shapely.strtree import STRtree
from audit_h5_cog_lattices import shape
from census_h5_one_part_moves import bits
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
CENSUS=ROOT/'output/h5-whole-frame-census-20261020'
OUT=ROOT/'output/h5-group-choice-20261023'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,obj):
    with p.open('x',encoding='utf-8',newline='\n') as f: json.dump(obj,f,indent=2);f.write('\n')
def rows(path):
    with gzip.open(path,'rt',encoding='utf-8') as f: return [json.loads(line) for line in f]
def save_rows(path,data):
    with gzip.open(path,'xt',encoding='utf-8',newline='\n') as f:
        for row in data:f.write(json.dumps(row)+'\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py')
    inputs=[SRC/n for n in ['candidates.json','job.json','library.json','request.json','conditional-target.json','selected-indices.json','audit/checks.json']]
    inputs += [CENSUS/n for n in ['groups.json','checks.json']]
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
      'method':'Choose exactly one of all26 previously audited complete18-frame sets while jointly choosing bracket, insert and cog poses from the entire11319-pose source pool. Recompute all group compatibility and all small-pose conflicts from original filled outlines; the old graph conditional on fixed cogs is not reused. No new coordinates, source filtering by old cog arrangements, or same-family domination. Every source small pose compatible with any frame group is retained.',
      'limits':{'compression_seconds':30,'solver_seconds':60,'solver_calls':1,'workers':8,'seed':0},
      'objective':'Maximize filled area with integer weights round(original family area times1000). Verify the ordering of all4576 count combinations against original floating areas. Original family caps12/15/21 remain. Require at least the known58-part seed area; its group2 plus all40 small poses is a complete feasible hint. Preserve all callbacks and final outcome.',
      'scope':'Finite group/pose construction only; no unrestricted infeasibility proof. Missing copies have no original-job credit. A full66-copy candidate still requires original CLI, native margins and unchanged H5 qualification.',
      'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();pool=load(SRC/'candidates.json');groups=load(CENSUS/'groups.json')
    assert len(pool)==11319 and len(groups)==26
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};clearance=job['clearance']
    gs=np.asarray([shape(parts[p['placement']['part_id']],p['placement']['transform']) for p in pool],dtype=object)
    sheets=np.asarray([p['placement']['sheet_id'] for p in pool]);small=[i for i,p in enumerate(pool) if p['placement']['part_id']!='frame']
    frames=sorted({i for g in groups for i in g['candidates']})
    blockers={i:set() for i in small}
    for sheet in ['sheet-0','sheet-1']:
        small_here=np.asarray([i for i in small if sheets[i]==sheet],dtype=int)
        frame_here=np.asarray([i for i in frames if sheets[i]==sheet],dtype=int)
        tree=STRtree(gs[small_here]);near=tree.query(gs[frame_here],predicate='dwithin',distance=clearance+1e-7)
        a,b=frame_here[near[0]],small_here[near[1]]
        keep=shapely.distance(gs[a],gs[b])<clearance-1e-7
        for a,b in zip(a[keep],b[keep]):blockers[int(b)].add(int(a))
    compatibility={i:[g['index'] for g in groups if not blockers[i].intersection(g['candidates'])] for i in small}
    ids=[i for i in small if compatibility[i]]
    write(OUT/'group-filter.json',[{'candidate':i,'frame_blockers':sorted(blockers[i]),'compatible_groups':compatibility[i]} for i in small])
    localgs=gs[ids];adj=[0]*len(ids);edges=[]
    for sheet in ['sheet-0','sheet-1']:
        local=np.asarray([j for j,i in enumerate(ids) if sheets[i]==sheet],dtype=int)
        if not len(local):continue
        tree=STRtree(localgs[local]);pair=tree.query(localgs[local],predicate='dwithin',distance=clearance+1e-7)
        a,b=local[pair[0]],local[pair[1]];keep=a<b;a,b=a[keep],b[keep]
        keep=shapely.distance(localgs[a],localgs[b])<clearance-1e-7
        for a,b in zip(a[keep],b[keep]):
            a,b=int(a),int(b);edges.append((a,b));adj[a]|=1<<b;adj[b]|=1<<a
    remaining=adj.copy();heap=[(-a.bit_count(),i) for i,a in enumerate(adj) if a];heapq.heapify(heap)
    cliques=[];covered=0;beg=time.perf_counter()
    while heap and time.perf_counter()-beg<30:
        degree,i=heapq.heappop(heap)
        if -degree!=remaining[i].bit_count() or not remaining[i]:continue
        choices=remaining[i];clique=[i];mask=1<<i
        while choices:
            sample=list(itertools.islice(bits(choices),16));j=max(sample,key=lambda v:((adj[v]&choices).bit_count(),-v))
            clique.append(j);mask|=1<<j;choices&=adj[j]
        assert all(not((mask^(1<<j))&~adj[j]) for j in clique)
        cliques.append(sorted(clique))
        for j in clique:
            old=remaining[j].bit_count();remaining[j]&=~mask;covered+=old-remaining[j].bit_count()
            if remaining[j]:heapq.heappush(heap,(-remaining[j].bit_count(),j))
    compressed=len(cliques);residual=0
    for i,mask in enumerate(remaining):
        for j in bits(mask&~((1<<(i+1))-1)):cliques.append([i,j]);residual+=1
    assert covered//2+residual==len(edges)
    save_rows(OUT/'conflicts.jsonl.gz',sorted(edges));save_rows(OUT/'cliques.jsonl.gz',sorted(set(map(tuple,cliques))))
    seed=set(load(SRC/'selected-indices.json'));seed_frames=sorted(i for i in seed if pool[i]['placement']['part_id']=='frame')
    seed_group=next(g['index'] for g in groups if g['candidates']==seed_frames)
    assert seed_group==2 and seed-set(seed_frames)<=set(ids)
    weights={f:round(shape(p,{'rotation_radians':0,'translation':[0,0],'mirrored':False}).area*1000) for f,p in parts.items() if f!='frame'}
    write(OUT/'mapping.json',{'candidates':ids,'compatible_groups':[compatibility[i] for i in ids],
      'frame_groups':groups,'seed_group':seed_group,'seed_indices':sorted(seed),'area_weights':weights})
    result={'seconds':time.perf_counter()-start,'source_small_poses':len(small),'retained_small_poses':len(ids),'frames_used_by_groups':len(frames),
      'families':dict(Counter(pool[i]['placement']['part_id'] for i in ids)),'groups':len(groups),
      'edges':len(edges),'compressed_cliques':compressed,'residual_edges':residual,'compression_limit_reached':bool(heap)}
    write(OUT/'generation.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
