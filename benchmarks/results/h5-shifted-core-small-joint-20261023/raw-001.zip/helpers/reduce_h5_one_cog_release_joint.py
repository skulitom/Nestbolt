"""Fresh full-neighbor substitutions before bounded constraint compression."""
from collections import Counter
from datetime import datetime,timezone
import gzip,heapq,itertools,json,shutil,time
from build_h5_one_cog_release_joint import ROOT,OUT as BASE,load,write,digest,read_graph,save_graph
from build_h5_group_choice import save_rows
from census_h5_one_part_moves import bits
OUT=BASE/'reduced'
def rows(path):
    with gzip.open(path,'rt',encoding='utf-8') as f:
        for line in f:yield json.loads(line)
def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'reduce.py')
    inputs=[BASE/n for n in ['plan.json','candidates.json','mapping.json','adjacency.bin.gz','audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_seconds':30,'maximum_comparisons':50000000,'compression_seconds':20,'method':'Order by original degree then global index. Remove b only for earlier retained same-family adjacent a with N(a) minus b contained in N(b), and compatible-groups(b) a subset of compatible-groups(a). Keep all unprocessed candidates on either bound. Independently enumerate every certificate neighbor, map all 30 exact original 64-part seeds with quantity and full-graph checks, then compress the exact induced graph by first-fit lowest-index clique expansion. Preserve every residual edge after the 20-second compression limit; independently reconstruct the entire final graph from all cliques and residual edges.'})
    mp=load(BASE/'mapping.json');pool=load(BASE/'candidates.json');ids=mp['candidates'];adj=read_graph(BASE/'adjacency.bin.gz',len(ids));allowed=[sum(1<<g for g in groups) for groups in mp['compatible_groups']];local={i:j for j,i in enumerate(ids)};family=[pool[i]['placement']['part_id'] for i in ids];order=sorted(range(len(ids)),key=lambda j:(adj[j].bit_count(),ids[j]));kept=[];removed=[];byfamily={f:[] for f in set(family)};comparisons=0;bounded=False;start=time.perf_counter()
    for at,b in enumerate(order):
        if time.perf_counter()-start>=30 or comparisons>=50000000:kept+=order[at:];bounded=True;break
        replacement=None
        for a in byfamily[family[b]]:
            comparisons+=1
            if (adj[b]>>a)&1 and not(allowed[b]&~allowed[a]) and not(adj[a]&~(adj[b]|(1<<b))):replacement=a;break
            if comparisons>=50000000 or time.perf_counter()-start>=30:break
        if replacement is None:kept.append(b);byfamily[family[b]].append(b)
        else:removed.append({'removed':ids[b],'replacement':ids[replacement]})
    seconds=time.perf_counter()-start;kept=sorted(kept);ks=set(kept);globals_kept=[ids[j] for j in kept];replacements={r['removed']:r['replacement'] for r in removed};certificate=groupcert=0
    assert set(globals_kept).isdisjoint(replacements) and set(globals_kept)|replacements.keys()==set(ids)
    for r in removed:
        b,a=local[r['removed']],local[r['replacement']];assert a in ks and family[a]==family[b] and (adj[b]>>a)&1
        for g in mp['compatible_groups'][b]:
            groupcert+=1;assert g in mp['compatible_groups'][a]
        for j in bits(adj[a]):
            certificate+=1
            if j!=b:assert (adj[b]>>j)&1
    remap={old:new for new,old in enumerate(kept)};keptmask=sum(1<<j for j in kept);projected=[sum(1<<remap[j] for j in bits(adj[i]&keptmask)) for i in kept];save_graph(OUT/'adjacency.bin.gz',projected);assert read_graph(OUT/'adjacency.bin.gz',len(kept))==projected
    newlocal={i:j for j,i in enumerate(globals_kept)};seeds=[]
    area=mp['area_weights'];mapped=[]
    for seed in mp['mapped_seeds']:
        group=seed['core_group'];chosen_global=sorted(replacements.get(i,i) for i in seed['selected_variable_candidates']);chosen=[newlocal[i] for i in chosen_global];mask=sum(1<<j for j in chosen);counts=Counter(pool[i]['placement']['part_id'] for i in chosen_global)
        assert len(chosen)==len(set(chosen))==32 and counts==Counter(bracket=10,cog=1,insert=21)
        assert all(not(projected[j]&mask) for j in chosen) and all(group in mp['compatible_groups'][local[i]] for i in chosen_global)
        row={**seed,'source':'mapped-64-part-seed','source_original_seed':seed['source'],'selected_variable_candidates':chosen_global,'counts':dict(counts),'objective':sum(area[pool[i]['placement']['part_id']] for i in chosen_global)}
        assert row['objective']==865862719;mapped.append(row)
    assert len(mapped)==30;best=mapped[0]
    write(OUT/'mapping.json',{**mp,'candidates':globals_kept,'compatible_groups':[mp['compatible_groups'][j] for j in kept],'mapped_seeds':mapped});write(OUT/'best-hint.json',best);write(OUT/'substitutions.json',removed)
    remaining=projected.copy();heap=[(-a.bit_count(),i) for i,a in enumerate(projected) if a];heapq.heapify(heap);cliques=[];covered=0;start=time.perf_counter()
    while heap and time.perf_counter()-start<20:
        degree,i=heapq.heappop(heap)
        if -degree!=remaining[i].bit_count() or not remaining[i]:continue
        choices=remaining[i];c=[i];mask=1<<i
        while choices:
            j=(choices&-choices).bit_length()-1;c.append(j);mask|=1<<j;choices&=projected[j]
        assert all(not((mask^(1<<j))&~projected[j]) for j in c);cliques.append(sorted(c))
        for j in c:
            before=remaining[j].bit_count();remaining[j]&=~mask;covered+=before-remaining[j].bit_count()
            if remaining[j]:heapq.heappush(heap,(-remaining[j].bit_count(),j))
    compression_seconds=time.perf_counter()-start;residual=sum(a.bit_count() for a in remaining)//2;edges=sum(a.bit_count() for a in projected)//2;assert covered//2+residual==edges
    def all_rows():
        yield from cliques
        for i,mask in enumerate(remaining):
            for j in bits(mask&~((1<<(i+1))-1)):yield [i,j]
    save_rows(OUT/'cliques.jsonl.gz',all_rows());independent=[0]*len(kept);rowcount=0
    for c in rows(OUT/'cliques.jsonl.gz'):
        assert len(c)==len(set(c));mask=sum(1<<j for j in c);rowcount+=1
        for j in c:other=mask^(1<<j);assert not(other&~projected[j]);independent[j]|=other
    assert independent==projected and rowcount==len(cliques)+residual
    check={'passed':True,'seconds':seconds,'comparisons':comparisons,'limit_reached':bounded,'original_candidates':len(ids),'kept_candidates':len(kept),'removed_candidates':len(removed),'certificate_neighbors_independently_verified':certificate,'all_substitutions_preserve_family_count_and_area':True,'all_30_exact_64_seeds_counts_groups_and_full_graph_checked':True,'mapped_seeds':len(mapped),'compatible_group_memberships_independently_certified':groupcert,'best_seed_objective':best['objective'],'induced_edges':edges,'compression_seconds':compression_seconds,'compressed_cliques':len(cliques),'residual_edges':residual,'compression_limit_reached':bool(heap),'projected_cliques':rowcount,'every_induced_edge_reconstructed_from_constraints':True,'native_margin_qualified':False}
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
