"""Match reused core, catalogue and clearance sources against committed evidence."""
from collections import Counter
from datetime import datetime,timezone
from build_h5_shifted_core_small_joint import ROOT,SRC,REG,OUT,load,write,digest

def main():
    checks=[]
    specs=[('h5-continuous-cog-joint-20261023','h5-continuous-cog-joint-20261023',['candidates.json','mapping.json','layout-audit/checks.json','retention/plan.json','retention/checks.json','retention/review-cores.json','next-step.json']),('h5-cog-lattices-20261018','h5-cog-lattices-20261018',['all-patterns.json','audit/checks.json']),('h5-wide-core-compound-limits-20261023','h5-reflected-small-compounds-20261023',['new-patterns.json','checks.json'])]
    for report,folder,names in specs:
        manifest=ROOT/'benchmarks/results'/report/'raw-manifest.json';data=load(manifest);hashes={r['path']:r['sha256'] for r in data['files']+data.get('aliases',[])}
        for name in names:
            p=ROOT/'output'/folder/name;key=folder+'/'+name;assert digest(p)==hashes[key];checks.append({'source':p.relative_to(ROOT).as_posix(),'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':key,'sha256':hashes[key]})
    manifest=ROOT/'benchmarks/results/h5-one-cog-continuous-regions-20261023/raw-manifest.json';data=load(manifest);hashes={r['path']:r['sha256'] for r in data['files']+data.get('aliases',[])}
    for name in ['conservative_h5_polygon_obstacles.py','conservative_h5_round_obstacles.py','diagnose_h5_concave_gaps.py']:
        p=ROOT/'output'/name;key='helpers/'+name;assert digest(p)==hashes[key];checks.append({'source':p.relative_to(ROOT).as_posix(),'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':key,'sha256':hashes[key]})
    for plan in [REG/'plan.json',REG/'audit/plan.json',OUT/'plan.json']:
        for name,h in load(plan)['inputs'].items():assert digest(ROOT/name)==h
    pool=load(OUT/'candidates.json');mp=load(OUT/'mapping.json');job=load(SRC/'job.json');quantities={p['id']:p['quantity'] for p in job['parts']};assert quantities=={'bracket':12,'frame':18,'cog':15,'insert':21}
    for g in mp['core_groups']:assert len(g['fixed_candidates'])==33 and Counter(pool[i]['placement']['part_id'] for i in g['fixed_candidates'])==Counter(frame=18,cog=15)
    assert mp['family_caps']=={f:quantities[f] for f in ['bracket','insert']} and len(mp['core_groups'])==7
    result={'passed':True,'utc':datetime.now(timezone.utc).isoformat(),'source_members_matching_committed_evidence':checks,'original_job_sha256':digest(SRC/'job.json'),'fixed_cogs_in_each_core':15,'fixed_frames_in_each_core':18,'all_seven_core_counts_verified':True,'original_family_caps_unchanged':True,'all_generation_audit_and_graph_input_hashes_verified':True};write(OUT/'provenance-audit.json',result);print({'passed':True,'committed_source_members_verified':len(checks)},flush=True)
if __name__=='__main__':main()
