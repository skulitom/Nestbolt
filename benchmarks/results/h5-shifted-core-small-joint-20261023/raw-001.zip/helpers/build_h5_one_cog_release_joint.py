"""Project the fully audited original graph into a distinct conditional repair neighborhood."""
from collections import Counter
from datetime import datetime,timezone
from itertools import product
import shutil,time
from build_h5_individual_frame_joint import ROOT,SRC,OUT as FULL,load,write,digest,read_graph,save_graph
from census_h5_one_part_moves import bits
COVER=ROOT/'output/h5-one-cog-release-coverage-20261023';OUT=ROOT/'output/h5-one-cog-release-joint-20261023'

def main():
    coverage=load(COVER/'checks.json');assert coverage['passed'] and coverage['distinct_fixed_cores']==30
    for name,h in load(COVER/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
    OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py')
    inputs=[COVER/n for n in ['plan.json','checks.json','mapping.json','filter.json','groups.json']]+[FULL/n for n in ['candidates.json','adjacency.bin.gz','audit/checks.json','next-step.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'reason':'A new one-cog-release repair neighborhood, not a retry of the complete four-family solve. Choose one of 30 independently audited fixed cores and jointly relocate one cog plus all brackets and inserts.','method':'Project the complete unconditioned original graph onto every eligible variable pose. Retain all original conflicts even when a pair has no shared core. Reconstruct every projected row back into original global indices and compare to the full source row. Recheck every complete mapped 64-part seed against the full graph, all fixed cores and original caps. Preserve every original input and 66-copy acceptance requirement.','maximum_reduction_seconds':30,'maximum_reduction_comparisons':50000000,'maximum_compression_seconds':20,'additional_greedy_hint_calls':0,'maximum_solver_calls':1,'maximum_solver_seconds':60,'solver_workers':8,'solver_seed':0,'cp_model_presolve':False,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();mp=load(COVER/'mapping.json');pool=load(FULL/'candidates.json');assert digest(FULL/'adjacency.bin.gz')==mp['source_graph_sha256'];adj=read_graph(FULL/'adjacency.bin.gz',len(pool));ids=mp['candidates'];local={i:j for j,i in enumerate(ids)};mask=sum(1<<i for i in ids)
    assert ids==sorted(set(ids)) and len(ids)==16058
    projected=[sum(1<<local[j] for j in bits(adj[i]&mask)) for i in ids]
    save_graph(OUT/'adjacency.bin.gz',projected);assert read_graph(OUT/'adjacency.bin.gz',len(ids))==projected
    for j,i in enumerate(ids):
        reconstructed=sum(1<<ids[k] for k in bits(projected[j]));assert reconstructed==(adj[i]&mask) and not((projected[j]>>j)&1)
    mp={**mp,'family_caps':mp['variable_family_caps']};shutil.copyfile(FULL/'candidates.json',OUT/'candidates.json');write(OUT/'mapping.json',mp)
    checked=0
    for seed in mp['mapped_seeds']:
        group=seed['core_group'];fixed=mp['core_groups'][group]['fixed_candidates'];chosen=seed['selected_variable_candidates'];allids=fixed+chosen;fullmask=sum(1<<i for i in allids)
        assert len(allids)==len(set(allids))==64 and all(not(adj[i]&fullmask) for i in allids)
        assert Counter(pool[i]['placement']['part_id'] for i in allids)==Counter(frame=18,cog=15,bracket=10,insert=21)
        assert all(group in mp['compatible_groups'][local[i]] for i in chosen);checked+=1
    area=mp['area_weights']
    # The already audited full count ordering covers this subset too; independently enumerate its integer range.
    combinations=[(b,c,i) for b,c,i in product(range(13),range(2),range(22))]
    scores=[b*area['bracket']+c*area['cog']+i*area['insert'] for b,c,i in combinations]
    assert len(combinations)==572 and max(scores)==945862719 and 12*area['bracket']+21*area['insert']>=865862719
    audit=OUT/'audit';audit.mkdir()
    checks={'passed':True,'seconds':time.perf_counter()-start,'original_pool_size':len(pool),'eligible_variable_poses':len(ids),'fixed_core_choices':len(mp['core_groups']),'all_source_inputs_match_frozen_hashes':True,'every_projected_row_reconstructed_in_global_indices':True,'projected_conflicts':sum(r.bit_count() for r in projected)//2,'all_30_complete_original_seeds_verified':checked==30,'mapped_seeds_checked':checked,'variable_count_combinations':len(combinations),'zero_variable_cog_allowed_when_area_floor_met':True,'seed_score':865862719,'full_score':945862719,'native_margin_qualified':False}
    write(audit/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
