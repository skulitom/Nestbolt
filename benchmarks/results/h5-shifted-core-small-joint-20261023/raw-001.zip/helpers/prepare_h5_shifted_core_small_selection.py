"""Adapt reviewed reduction/model/audit mechanics to two families and seven fixed33 cores."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    names=['reduce','seed','solve','audit']
    for name in names:
        old=f'{name}_h5_one_cog_release_'+('layouts' if name=='audit' else 'joint')+'.py'
        new=f'{name}_h5_shifted_core_small_'+('layouts' if name=='audit' else 'joint')+'.py'
        text=(ROOT/'output'/old).read_text(encoding='utf-8')
        text=text.replace('h5_one_cog_release_joint','h5_shifted_core_small_joint').replace('h5-one-cog-release-joint-20261023','h5-shifted-core-small-joint-20261023')
        text=text.replace('one-cog repair','seven-core small-part').replace('all 30','both').replace('all_30_exact','both_exact')
        text=text.replace('len(mapped)==30','len(mapped)==2').replace('len(seeds)==30','len(seeds)==2')
        text=text.replace('len(set(chosen))==32','len(set(chosen))==31').replace('Counter(bracket=10,cog=1,insert=21)','Counter(bracket=10,insert=21)')
        text=text.replace('865862719','815800000').replace('945862719','895800000')
        text=text.replace("names=['bracket','cog','insert']","names=['bracket','insert']").replace("'zero_variable_cog_permitted':True,",'')
        text=text.replace('len(fixed)==32','len(fixed)==33').replace('Counter(frame=18,cog=14)','Counter(frame=18,cog=15)')
        text=text.replace("'variable_cog_poses':sorted(i for i in sm if pool[i]['placement']['part_id']=='cog')","'new_small_poses':sorted(i for i in sm if i>=39488)")
        with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
if __name__=='__main__':main()
