"""Original filled-outline comparison for the preserved64 and changed63 layouts."""
from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Patch
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-shifted-core-small-joint-20261023'
load=lambda p:json.loads(p.read_bytes())
def main():
    job=load(ROOT/'output/h5-skeleton-contact-selection-20261020/job.json');parts={p['id']:p for p in job['parts']};colors={'frame':'#8095aa','cog':'#d79831','bracket':'#378c84','insert':'#8d6cb5'};target=load(ROOT/'output/h5-skeleton-contact-selection-20261020/conditional-target.json');fig=plt.figure(figsize=(13,15));grid=fig.add_gridspec(2,2,height_ratios=[3000,target['required_used_height_mm']])
    for col,(index,title) in enumerate([('hint','64 parts: 10 brackets + 21 inserts'),('final','63 parts: 11 brackets + 19 inserts')]):
        layout=load(BASE/'layout-audit'/f'layout-{index}.json')
        for row,sheet in enumerate(['sheet-0','sheet-1']):
            ax=fig.add_subplot(grid[row,col]);height=3000 if row==0 else target['required_used_height_mm'];ax.set(xlim=(0,1500),ylim=(0,height),aspect='equal');ax.set_xlabel('mm');ax.set_ylabel('mm');ax.grid(alpha=.15)
            if row==0:ax.set_title(title+'\n18 frames and 15 cogs in each',fontsize=12)
            for p in layout['placements']:
                if p['sheet_id']!=sheet:continue
                t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation'];raw=parts[p['part_id']]['geometry'][0]['outer'];points=[]
                for x,y in raw:
                    if t['mirrored']:x=-x
                    points.append((c*x-s*y+tx,s*x+c*y+ty))
                ax.add_patch(Polygon(points,facecolor=colors[p['part_id']],edgecolor='white',linewidth=.4));x=sum(p[0] for p in points)/len(points);y=sum(p[1] for p in points)/len(points)
                if p['part_id'] in ['bracket','insert']:ax.text(x,y,f"{p['part_id'][0].upper()}{p['copy_index']}",fontsize=7,ha='center',va='center',color='white')
    fig.legend(handles=[Patch(facecolor=c,label=f) for f,c in colors.items()],loc='lower center',ncol=4);fig.suptitle('Original development job; all holes reserved\nBoth layouts remain incomplete. New layout fills 400 mm² more, but loses one part.',fontsize=14);fig.subplots_adjust(top=.93,bottom=.06,wspace=.16,hspace=.08);fig.savefig(BASE/'layout-comparison.png',dpi=150);plt.close(fig)
if __name__=='__main__':main()
