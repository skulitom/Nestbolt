"""Verify the count-only change without dropping insert37 from the job."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-eight-part-band-model-20261026';PARENT=ROOT/'output/h5-nine-part-band-model-20261026';EXCHANGE=ROOT/'output/h5-insert36-cog53-exchange-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Reconstruct exactly336 insert variable upper-bound changes and one count-equality change from1 to0; require complete proto equality with the audited parent otherwise. Verify every capacity and coefficient unchanged. Independently account for55 checked first-sheet IDs,eight mandatory second-sheet IDs and pending first-sheet28/29/37 as exactly all66 unique originals. No pose for37 or complete layout is implied. Check actual solver import/export.'})
for path in [BASE/'plan.json',PARENT/'plan.json',PARENT/'audit/plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'audit/checks.json')['passed'];mapping=load(BASE/'mapping.json');assert mapping==load(PARENT/'mapping.json');model=proto(BASE/'model.pb');expected=proto(PARENT/'model.pb');changed=[]
for r in mapping:
    if r['family']=='insert':assert list(expected.variables[r['variable']].domain)==[0,1];expected.variables[r['variable']].domain[1]=0;changed.append(r['variable'])
assert len(changed)==336 and list(expected.constraints[1].linear.vars)==changed and list(expected.constraints[1].linear.coeffs)==[1]*336 and list(expected.constraints[1].linear.domain)==[1,1];expected.constraints[1].linear.domain[:]=[0,0];assert expected==model and load(BASE/'changes.json')=={'insert_count_constraint':1,'old_count':1,'new_count':0,'insert_variable_upper_bounds_changed':changed};plan=load(BASE/'plan.json');first=load(EXCHANGE/'first-sheet-identities.json');second=plan['mandatory_originals'];pending=plan['pending_first_sheet_originals'];assert second==[21,22,25,26,53,63,64,65] and pending==[28,29,37] and sorted(first+second+pending)==list(range(66));assert 36 in first and 37 not in first and plan['required_original_counts']=={'bracket':4,'insert':0,'cog':4}
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'solver-import-roundtrip.pb'));assert proto(OUT/'solver-import-roundtrip.pb')==model;write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':673,'constraints':66,'exact_parent_restoration_verified':True,'insert_variable_bounds_changed':336,'insert_count_equality_changed':1,'all63_capacity_constraints_unchanged':True,'all66_original_identities_accounted_for':True,'pending_first_sheet_originals':pending,'actual_import_export_verified':True,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
