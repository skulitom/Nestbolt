from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('run_h5_all_bracket_strip_probe.py','run_h5_shared_bracket_strip_probe.py'),('audit_h5_all_bracket_strip_response.py','audit_h5_shared_bracket_strip_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-all-bracket-strip-probe-20261026','h5-shared-bracket-strip-probe-20261026')
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
