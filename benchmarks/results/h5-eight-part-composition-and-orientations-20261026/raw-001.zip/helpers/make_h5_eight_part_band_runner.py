"""Distinct eight-part necessary call and complete response readback helpers."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('run_h5_nine_part_band_model.py','run_h5_eight_part_band_model.py'),('audit_h5_nine_part_band_response.py','audit_h5_eight_part_band_response.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-nine-part-band-model-20261026','h5-eight-part-band-model-20261026').replace('h5-nine-part-band-search-20261026','h5-eight-part-band-search-20261026').replace('All4brackets/1insert/4cogs mandatory after the verified insert36/cog53 exchange; all66 original IDs accounted for.','All4brackets/4cogs mandatory on sheet2; insert37 and brackets28/29 remain required on sheet1 beside its55 checked originals. All66 original IDs accounted for.')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
