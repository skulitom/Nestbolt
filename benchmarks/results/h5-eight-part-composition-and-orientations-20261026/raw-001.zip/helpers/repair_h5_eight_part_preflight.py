"""Preserve failed preflight artifacts; repair a mistaken audit constant before any solver call."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
failed=OUT/'h5-eight-part-strip-probe-20261026'
assert not list(failed.rglob('opened.json'))
record={'solver_calls':0,'failed_stage':'geometry audit budget assertion','cause':'A broad ==45 to ==28 text substitution altered the expected solver budget as well as pair count. The declared source budget remains45 seconds. Downstream preparation failed because the audit did not pass; solver never opened.','repair':'Correct only the45second audit expectation. Preserve original failure folders and use new repaired audit/model paths. No change to source geometry, inventories, domains or declared budgets.'}
with (failed/'preflight-failure.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
names=['audit_h5_eight_part_strip_geometry.py','prepare_h5_eight_part_strip_model.py','audit_h5_eight_part_strip_model.py','run_h5_eight_part_strip_probe.py','audit_h5_eight_part_strip_response.py']
for name in names:
    s=(OUT/name).read_text(encoding='utf-8')
    s=s.replace('h5-eight-part-strip-probe-20261026','h5-eight-part-strip-probe-repaired-20261026')
    if name=='audit_h5_eight_part_strip_geometry.py':
        assert "spec['per_pattern_solver_seconds']==28" in s
        s=s.replace("spec['per_pattern_solver_seconds']==28","spec['per_pattern_solver_seconds']==45").replace("OUT=BASE/'audit'","OUT=BASE/'audit-repaired'")
    else:s=s.replace("SOURCE/'audit/checks.json'","SOURCE/'audit-repaired/checks.json'")
    dst=name.replace('.py','_repaired.py');s=s.replace('run_h5_eight_part_strip_probe.py','run_h5_eight_part_strip_probe_repaired.py')
    compile(s,dst,'exec')
    with (OUT/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
