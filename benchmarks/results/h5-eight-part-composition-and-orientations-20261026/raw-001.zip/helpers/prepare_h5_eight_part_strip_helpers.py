"""Declare a new eight-original coordinate subproblem from audited band counts."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def make(src,dst,changes):
    s=(ROOT/'output'/src).read_text(encoding='utf-8')
    for old,new in changes:
        assert old in s,(src,old);s=s.replace(old,new)
    for old,new in [('three predeclared','one predeclared'),('three declared','one declared'),('the three','the single'),('ten mandatory originals and20','eight mandatory originals and16'),('ten-original','eight-original'),('20 exact','16 exact'),('all45','all28'),('12second','45second')]:s=s.replace(old,new)
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
paths=[('h5-second-strip-four-cogs-source-20261026','h5-eight-part-strip-source-20261026'),('h5-second-strip-four-cogs-probes-20261026','h5-eight-part-strip-probe-20261026')]
make('build_h5_second_strip_four_cogs.py','build_h5_eight_part_strip.py',paths[:1]+[
('Three new whole-strip orientation constructions with ten original parts.','One eight-original strip construction selected by the audited necessary band allocation.'),
('ids=[21,22,25,26,36,37,53,63,64,65];patterns=[[1,1,3,3,10,10,9,9,9,9],[0,0,2,2,10,10,9,9,9,9],[0,4,2,6,10,10,9,9,9,9]]','ids=[21,22,25,26,53,63,64,65];patterns=[[5,5,6,7,9,9,9,9]]'),
('range(10)','range(8)'),
("write(OUT/'plan.json',", "band=ROOT/'output/h5-eight-part-band-search-20261026';assert load(band/'audit/checks.json')['passed'];allocation=load(band/'allocation.json');assert sorted(pi for r in allocation for pi in [r['profile']]*r['count'])==patterns[0];paths.extend([band/'allocation.json',band/'audit/checks.json',ROOT/'output/h5-insert36-cog53-exchange-20261026/first-sheet-identities.json']);first=load(paths[-1]);assert len(first)==55 and set(first).isdisjoint(ids) and sorted(first+ids+[28,29,37])==list(range(66))\nwrite(OUT/'plan.json',"),
("'maximum_calls':3,'per_pattern_solver_seconds':12", "'maximum_calls':1,'per_pattern_solver_seconds':45"),
("'method':'Distinct second-sheet-only constructive test:","'pending_first_sheet_originals':[28,29,37],'first_sheet_checked_originals':first,'method':'NEW SCOPE: eight originals only, IDs21/22/25/26/53/63/64/65, with orientation5/5/6/7/9/9/9/9 selected by independently verified band allocation. All16 coordinates free throughout native-guarded stock bounds; no band-cell locks or hints. One45second solver call, four workers seed0, within60shared seconds. Mandatory first-sheet pending IDs28/29/37 and55 checked IDs preserve all66 originals. The following old historical description is superseded by this exact inventory: Distinct second-sheet-only constructive test:"),
("'patterns':3,'mandatory_sheet_originals':10,'brackets':4,'inserts':2", "'patterns':1,'mandatory_sheet_originals':8,'brackets':4,'inserts':0"),
("'physical_pairs_per_pattern':45","'physical_pairs_per_pattern':28")])
make('audit_h5_second_strip_four_cogs_geometry.py','audit_h5_eight_part_strip_geometry.py',paths[:1]+[
("if 'h5-three-free-brackets-search' not in n:assert h in known,n", "if not any(k in n for k in ['h5-three-free-brackets-search','h5-eight-part-band-search','h5-insert36-cog53-exchange']):assert h in known,n"),
('[21,22,25,26,36,37,53,63,64,65]','[21,22,25,26,53,63,64,65]'),
('[[1,1,3,3,10,10,9,9,9,9],[0,0,2,2,10,10,9,9,9,9],[0,4,2,6,10,10,9,9,9,9]]','[[5,5,6,7,9,9,9,9]]'),
('==10 and all','==8 and all'),("spec['maximum_calls']==3 and spec['per_pattern_solver_seconds']==12","spec['maximum_calls']==1 and spec['per_pattern_solver_seconds']==45"),
('range(10)','range(8)'),('==45','==28'),("'patterns':3,'mandatory_originals_per_pattern':10,'physical_pairs_checked':135","'patterns':1,'mandatory_originals_per_pattern':8,'physical_pairs_checked':28"),
('all ten original IDs','all eight original IDs'),('all45 physical pairs in each ofthree declared patterns','all28 physical pairs in the sole declared pattern'),
("geoms={};triangles={}","first=spec['first_sheet_checked_originals'];ids=[p['item'] for p in spec['parts']];assert len(first)==55 and len(set(first+ids+[28,29,37]))==66 and sorted(first+ids+[28,29,37])==list(range(66));assert spec['pending_first_sheet_originals']==[28,29,37]\ngeoms={};triangles={}")])
for src,dst in [('prepare_h5_second_strip_models.py','prepare_h5_eight_part_strip_model.py'),('audit_h5_second_strip_models.py','audit_h5_eight_part_strip_model.py')]:
    changes=paths+[('range(10)','range(8)'),("'solver_seconds':12.0","'solver_seconds':45.0"), ("'models':3","'models':1")]
    if src.startswith('audit'):changes+=[('len(rows)==3','len(rows)==1'),("row['solver_seconds']==12.0","row['solver_seconds']==45.0"),('all45_original_pairs_preserved','all28_original_pairs_preserved')];changes.remove(("'solver_seconds':12.0","'solver_seconds':45.0"))
    else:changes +=[("'coordinate_variables_per_model':20,'full_physical_pairs_per_model':45","'coordinate_variables_per_model':16,'full_physical_pairs_per_model':28")]
    make(src,dst,changes)
make('run_h5_second_strip_probes.py','run_h5_eight_part_strip_probe.py',paths[1:]+[
('Three predeclared ten-original strip models, one12second call each, sharing60seconds.','One eight-original strip model:45solver seconds within60shared seconds.'),
('-17:break','-50:break'),("'maximum_calls':3,'per_group_solver_seconds':12","'maximum_calls':1,'per_group_solver_seconds':45")])
make('audit_h5_second_strip_responses.py','audit_h5_eight_part_strip_response.py',paths+[
('three','one'),('range(10)','range(8)'),('len(rows)==3','len(rows)==1'),("budget['maximum_calls']==3","budget['maximum_calls']==1"),("budget['per_group_solver_seconds']==12","budget['per_group_solver_seconds']==45"),
("rglob('opened.json')))==3","rglob('opened.json')))==1"),('max_time_in_seconds=12','max_time_in_seconds=45'),("opened['seconds_limit']==12","opened['seconds_limit']==45"),("saved['seconds']-12","saved['seconds']-45"),('solution[:20]','solution[:16]'),('ten original','eight original'),('ten_original_source_witness','eight_original_source_witness'),('==3 and census','==1 and census'),("'closed_calls':3","'closed_calls':1"),('all45','all28')])
make('review_h5_second_strip_final.py','review_h5_eight_part_final.py',[
('h5-second-strip-final-review-20261026','h5-eight-part-final-review-20261026'),('4817fefff0739e7d92a15cf0e710b6d29d6c51dc','81cc41866306a639fa09f0db9590bb411c0c987e'),('c22d3e39e315b040b3afc694acae3e1beca685f8','81cc41866306a639fa09f0db9590bb411c0c987e')])
