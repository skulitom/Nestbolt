from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(name,s):
    compile(s,name,'exec')
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_second_strip_four_cogs_geometry.py').read_text(encoding='utf-8')
changes=[('h5-second-strip-four-cogs-source-20261026','h5-all-bracket-strip-source-20261026'),
("if 'h5-three-free-brackets-search' not in n:assert h in known,n","if not any(t in n for t in ['h5-insert36-cog53-exchange','h5-eight-part-strip-probe-repaired']):assert h in known,n"),
('[21,22,25,26,36,37,53,63,64,65]','[21,22,25,26,53,63,64,65]'),
("assert spec['orientation_patterns']==[[1,1,3,3,10,10,9,9,9,9],[0,0,2,2,10,10,9,9,9,9],[0,4,2,6,10,10,9,9,9,9]]","assert spec['allowed_profiles']==[list(range(8)) for _ in range(4)]+[[9] for _ in range(4)];first=spec['first_sheet_checked_originals'];ids=[p['item'] for p in spec['parts']];assert len(first)==55 and sorted(first+ids+spec['pending_first_sheet_originals'])==list(range(66)) and spec['pending_first_sheet_originals']==[28,29,37]"),
("==10 and all","==8 and all"),
("spec['maximum_calls']==3 and spec['per_pattern_solver_seconds']==12 and spec['shared_solver_seconds']==60 and spec['solver_workers']==4 and spec['solver_seed']==0","spec['maximum_calls']==1 and spec['solver_seconds']==45 and spec['shared_seconds']==60 and spec['workers']==4 and spec['seed']==0"),
("needed=sorted({(r[a],r[b]) for r in spec['orientation_patterns'] for a,b in combinations(range(10),2)})","needed=sorted({(pa,pb) for a,b in combinations(range(8),2) for pa,pb in product(spec['allowed_profiles'][a],spec['allowed_profiles'][b])})"),
("for row in spec['orientation_patterns']:\n    for p,pi in zip(spec['parts'],row):assert p['family']==profiles[pi]['family']\n    assert len(list(combinations(row,2)))==45","for p,options in zip(spec['parts'],spec['allowed_profiles']):\n    assert all(p['family']==profiles[pi]['family'] for pi in options)\nassert len(needed)==73 and sum(len(spec['allowed_profiles'][a])*len(spec['allowed_profiles'][b]) for a,b in combinations(range(8),2))==518"),
("'patterns':3,'mandatory_originals_per_pattern':10,'physical_pairs_checked':135","'all_bracket_orientations':True,'mandatory_originals':8,'physical_pairs_checked':28,'physical_orientation_modes':518"),
('all ten original IDs','all eight original IDs'),('all45 physical pairs in each ofthree declared patterns','all28 physical pairs and518 orientation modes')]
for old,new in changes:assert old in s,old;s=s.replace(old,new)
save('audit_h5_all_bracket_strip_geometry.py',s)
s=(ROOT/'output/run_h5_eight_part_strip_probe_repaired.py').read_text(encoding='utf-8').replace('h5-eight-part-strip-probe-repaired-20261026','h5-all-bracket-strip-probe-20261026')
save('run_h5_all_bracket_strip_probe.py',s)
