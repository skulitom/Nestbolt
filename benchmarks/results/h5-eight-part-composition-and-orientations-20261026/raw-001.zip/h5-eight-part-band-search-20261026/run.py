"""One separately bounded necessary capacity solve, preserving all prior calls."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess,sys,time,traceback
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'output/h5-eight-part-band-model-20261026';OUT=ROOT/'output/h5-eight-part-band-search-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2,sat_parameters_pb2
    from ortools.sat.python import cp_model
    assert load(PREP/'audit/checks.json')['passed']
    for path in [PREP/'plan.json',PREP/'audit/plan.json']:
        for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
    real=cp_model.CpModel();assert real.proto.parse_text_format((PREP/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'model.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());expected=cp_model_pb2.CpModelProto();expected.ParseFromString((PREP/'model.pb').read_bytes());assert actual==expected
    remaining=load(OUT/'budget.json')['deadline_perf_counter']-time.perf_counter()-5;assert remaining>0;params={'max_time_in_seconds':min(20,remaining),'num_search_workers':4,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False};solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params);(OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'remaining_shared_seconds':remaining,'solver_seconds_limit':params['max_time_in_seconds']})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
        solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());start=time.perf_counter();status=solver.solve(real);elapsed=time.perf_counter()-start
    response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(OUT/'response.pb').write_bytes(response.SerializeToString());positive=status in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    if positive:write(OUT/'allocation.json',[{**m,'count':response.solution[m['variable']]} for m in load(PREP/'mapping.json') if response.solution[m['variable']]])
    write(OUT/'result.json',{'status':solver.status_name(status),'seconds':elapsed,'solver_calls':1,'has_necessary_allocation':positive,'solver_soft_overrun_seconds':max(0,elapsed-params['max_time_in_seconds']),'full_target_witness':False,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in PREP.rglob('*') if p.is_file()},'method':'One necessary band-capacity call on the independently audited673-variable/66-constraint model. All4brackets/4cogs mandatory on sheet2; insert37 and brackets28/29 remain required on sheet1 beside its55 checked originals. All66 original IDs accounted for. At most20solver seconds within30shared seconds, four workers seed0, five-second shutdown reserve. No restart/reseed/extension. Positive is only a necessary vertical allocation; negative scope remains fixed-angle guarded-source geometry.'});write(OUT/'budget.json',{'start_perf_counter':start,'deadline_perf_counter':start+30,'shared_seconds':30,'solver_cap_seconds':20,'workers':4,'seed':0,'shutdown_reserve_seconds':5,'maximum_solver_calls':1})
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=max(.01,start+30-time.perf_counter()));(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'exit_code':p.returncode,'seconds':time.perf_counter()-start,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final response. Opened call remains closed.')
if __name__=='__main__':
    try:child() if '--child' in sys.argv else main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
