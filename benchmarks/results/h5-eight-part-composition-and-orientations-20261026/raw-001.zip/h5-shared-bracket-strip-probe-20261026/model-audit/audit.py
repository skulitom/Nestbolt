"""Whole-model equivalence verification for shared pair-plane flags."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-shared-bracket-strip-probe-20261026';PARENT=ROOT/'output/h5-all-bracket-strip-probe-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify all original coordinate/profile variables and stock/count/symmetry constraints unchanged. For every one of95700 original edge flags, verify the complete plane fields equal its mapped shared plane and its old activation list equals the corresponding mode. Rebuild every original mode-face OR under that mapping, including exact negative escape literals. Exhaustively verify shared variables/constraints/inventory and actual import. Equisatisfiability argument: for any old feasible coordinates set each shared flag to its plane truth; all active old faces retain a true plane. Conversely copy each shared flag to its old edge flags; every active old plane implication and OR is satisfied. No solving.'})
for path in [BASE/'plan.json',PARENT/'model-audit/plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'];old=proto(PARENT/'models/000.pb');m=proto(BASE/'models/000.pb');assert {f.name for f,v in m.ListFields()}=={'variables','constraints'} and m.variables[:48]==old.variables[:48] and m.constraints[:74]==old.constraints[:74];projection=load(BASE/'edge-flag-projection.json');assert len(projection)==95700
table={r['old_flag']:r for r in projection};assert set(table)==set(range(48,95748));distinct={};expected=[]
for c in old.constraints[74:]:
    if c.WhichOneof('constraint')=='bool_or':continue
    assert c.WhichOneof('constraint')=='linear' and c.enforcement_literal;oldflag=c.enforcement_literal[-1];r=table[oldflag];assert list(c.enforcement_literal[:-1])==r['old_active_profiles'];key=c.linear.SerializeToString()
    if key not in distinct:distinct[key]=48+len(distinct);expected.append(c.linear)
    assert r['shared_flag']==distinct[key]
assert len(distinct)==40402 and len(m.variables)==40450
for j,plane in enumerate(expected):
    v=48+j;assert m.variables[v]==cp_model_pb2.IntegerVariableProto(name=f'plane-{v}',domain=[0,1]);c=cp_model_pb2.ConstraintProto();c.linear.CopyFrom(plane);c.enforcement_literal.append(v);assert c==m.constraints[74+j]
index=74+len(expected);faces=0
for oldc in old.constraints[74:]:
    if oldc.WhichOneof('constraint')!='bool_or':continue
    negative=[v for v in oldc.bool_or.literals if v<0];assert all(16<=-v-1<48 for v in negative)
    c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend(v if v<0 else table[v]['shared_flag'] for v in oldc.bool_or.literals);assert c==m.constraints[index];index+=1;faces+=1
assert faces==1862 and index==len(m.constraints)==42338;row=load(BASE/'inventory.json')[0];assert row['variables']==len(m.variables) and row['constraints']==len(m.constraints) and row['solver_seconds']==45 and row['model_sha256']==digest(BASE/'models/000.pb');assert load(BASE/'profile-flags.json')==load(PARENT/'profile-flags.json')
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':len(m.variables),'constraints':len(m.constraints),'all95700_edge_projections_verified':True,'shared_planes':40402,'preserved_mode_face_disjunctions':1862,'coordinate_and_profile_feasible_set_unchanged':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
