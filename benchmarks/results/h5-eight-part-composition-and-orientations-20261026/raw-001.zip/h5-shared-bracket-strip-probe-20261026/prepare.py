"""Factor identical physical pair planes across orientation modes."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-all-bracket-strip-probe-20261026';SOURCE=ROOT/'output/h5-all-bracket-strip-source-20261026';OUT=ROOT/'output/h5-shared-bracket-strip-probe-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'response-audit/checks.json')['passed'];old=cp_model_pb2.CpModelProto();old.ParseFromString((PARENT/'models/000.pb').read_bytes());assert len(old.variables)==95748 and len(old.constraints)==97636
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [PARENT/'models/000.pb',PARENT/'models/000-mapping.json',PARENT/'inventory.json',PARENT/'profile-flags.json',PARENT/'response-audit/checks.json',SOURCE/'plan.json']},'method':'Distinct equivalent factorization of the closed all-orientation model: preserve first48 coordinate/profile variables and74 stock/count/symmetry constraints byte-for-byte. Merge repeated edge flags when their physical pair linear expression and bound are identical. Each shared flag implies its plane unconditionally; each original mode-face OR includes its original inactive-mode escape literals. This is equisatisfiable by setting shared flags to plane truth for any old feasible coordinates, and copying shared flags to old edge flags in the reverse direction. Preserve all518 modes/28 pairs/1862 face disjunctions. One separately bounded45second4worker seed0 call in60shared seconds only after complete equivalence/import audit. No extended or repeated old call.'})
m=cp_model_pb2.CpModelProto();m.variables.extend(old.variables[:48]);m.constraints.extend(old.constraints[:74]);assert old.constraints[74].enforcement_literal
keys={};mapping=[];clauses=[]
for c in old.constraints[74:]:
    kind=c.WhichOneof('constraint')
    if kind=='linear':
        assert c.enforcement_literal;oldflag=c.enforcement_literal[-1];active=list(c.enforcement_literal[:-1]);assert oldflag>=48 and all(v<48 for v in active);key=(tuple(c.linear.vars),tuple(c.linear.coeffs),tuple(c.linear.domain))
        if key not in keys:
            v=len(m.variables);keys[key]=v;m.variables.add(name=f'plane-{v}',domain=[0,1]);new=m.constraints.add();new.linear.CopyFrom(c.linear);new.enforcement_literal.append(v)
        mapping.append({'old_flag':oldflag,'shared_flag':keys[key],'old_active_profiles':active})
    else:
        assert kind=='bool_or' and not c.enforcement_literal;clauses.append(list(c.bool_or.literals))
lookup={r['old_flag']:r['shared_flag'] for r in mapping};assert len(lookup)==95700
for lits in clauses:m.constraints.add().bool_or.literals.extend(v if v<0 else lookup[v] for v in lits)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');write(OUT/'edge-flag-projection.json',mapping);shutil.copyfile(PARENT/'profile-flags.json',OUT/'profile-flags.json');row={**load(PARENT/'inventory.json')[0],'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(p),'shared_physical_planes':len(keys)};write(OUT/'inventory.json',[row]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'old_edge_flags':95700,'shared_edge_flags':len(keys),'removed_repeated_flags':95700-len(keys),'preserved_face_disjunctions':len(clauses),'variables':len(m.variables),'constraints':len(m.constraints),'solver_calls':0});print(load(OUT/'prepared.json'))
