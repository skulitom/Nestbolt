"""One all-orientation coordinate model with optional guarded collision clauses."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,product
from datetime import datetime,timezone
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-all-bracket-strip-source-20261026';OUT=ROOT/'output/h5-all-bracket-strip-probe-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(SOURCE/'audit/checks.json')['passed'];s=load(SOURCE/'plan.json');allowed=s['allowed_profiles'];bounds=s['anchor_bounds_units1000'];data={(c['profile_a'],c['profile_b']):load(SOURCE/'mutual'/f"{c['index']:03d}.json") for c in s['mutual_cases']}
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in SOURCE.rglob('*') if p.is_file()},'method':'16 free integer anchor coordinates;32 one-hot bracket profile flags. All profile-specific stock boxes are conditionally enforced. For all518 pair modes, all convex forbidden faces must be avoided when both profiles are active. Retain exact outside-plane clauses after whole-mode difference-box proofs. Profile flags plus OR clauses disable inactive modes without restricting their free anchors. Order bracket profile numbers and cog x coordinates only, exploiting identical complete family copies. Independent full reconstruction, symmetry argument and import before one45second4worker seed0 call in60shared seconds.'})
m=cp_model_pb2.CpModelProto()
for i,ps in enumerate(allowed):
    for axis in range(2):m.variables.add(name=f'p{i}-'+('xy'[axis]),domain=[min(bounds[str(p)][axis] for p in ps),max(bounds[str(p)][axis+2] for p in ps)])
flags={}
for i in range(4):
    flags[i]=[]
    for p in range(8):flags[i].append(len(m.variables));m.variables.add(name=f'p{i}-profile{p}',domain=[0,1])
def lin(terms,lo,hi,enforce=()):
    c=m.constraints.add();keys=sorted(k for k,v in terms.items() if v);c.linear.vars.extend(keys);c.linear.coeffs.extend(terms[k] for k in keys);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(enforce)
for i in range(4):
    lin({v:1 for v in flags[i]},1,1)
    for p,v in enumerate(flags[i]):
        b=bounds[str(p)]
        for axis in range(2):lin({2*i+axis:1},b[axis],b[axis+2],[v])
for i in range(3):lin({**{flags[i][p]:p for p in range(8)},**{flags[i+1][p]:-p for p in range(8)}},-2**63,0)
for i in range(4,7):lin({2*i:1,2*(i+1):-1},-2**63,0)
maps=[];totals={'tautological_faces':0,'singleton_faces':0,'disjunctive_faces':0,'impossible_faces':0}
for a,b in combinations(range(8),2):
    for pa,pb in product(allowed[a],allowed[b]):
        aa,bb=bounds[str(pa)],bounds[str(pb)];d=[bb[0]-aa[2],bb[1]-aa[3],bb[2]-aa[0],bb[3]-aa[1]];active=([flags[a][pa]] if a<4 else [])+([flags[b][pb]] if b<4 else []);records=[]
        for face in data[pa,pb]['faces']:
            hs=face['outside_halfplanes'];ranges=[(h['a']*d[0 if h['a']>=0 else 2]+h['b']*d[1 if h['b']>=0 else 3],h['a']*d[2 if h['a']>=0 else 0]+h['b']*d[3 if h['b']>=0 else 1]) for h in hs]
            if any(lo>=h['bound'] for h,(lo,hi) in zip(hs,ranges)):records.append({'face':face['index'],'tautological':True});totals['tautological_faces']+=1;continue
            live=[j for j,(h,(lo,hi)) in enumerate(zip(hs,ranges)) if hi>=h['bound']];ef=[]
            def plane(j,enforce):
                h=hs[j];lin({2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']},h['bound'],2**63-1,enforce)
            if len(live)==1:plane(live[0],active);totals['singleton_faces']+=1
            else:
                for j in live:
                    v=len(m.variables);ef.append(v);m.variables.add(name=f'p{a}-{b}-q{pa}-{pb}-f{face["index"]}-e{j}',domain=[0,1]);plane(j,active+[v])
                c=m.constraints.add();c.bool_or.literals.extend([-v-1 for v in active]+ef);totals['disjunctive_faces' if live else 'impossible_faces']+=1
            records.append({'face':face['index'],'live_edges':live,'flags':ef})
        maps.append({'parts':[a,b],'profiles':[pa,pb],'active':active,'difference_bounds':d,'faces':records})
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');write(OUT/'models/000-mapping.json',maps);write(OUT/'profile-flags.json',flags)
row={'index':0,'parts':list(range(8)),'originals':[p['item'] for p in s['parts']],'allowed_profiles':allowed,'variables':len(m.variables),'constraints':len(m.constraints),'solver_seconds':45.,'model_sha256':digest(p),**totals};write(OUT/'inventory.json',[row]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'physical_modes':len(maps),'models':1,'solver_calls':0,**row});print(load(OUT/'prepared.json'))
