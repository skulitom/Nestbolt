"""Independent complete optional-orientation model and symmetry readback."""
from pathlib import Path
from hashlib import sha256
from itertools import product,combinations
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-all-bracket-strip-probe-20261026';SOURCE=ROOT/'output/h5-all-bracket-strip-source-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Reconstruct all variables and constraints in order independently. Compute each plane range by enumerating difference-box corners. Recheck exact optional profile implications, inactive-mode escape OR literals, full mode inventory, flags, names and domains. Explain why family-copy symmetry preserves a witness by relabelling identical original family copies. Verify entire proto and actual import/export. No solver calls.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];s=load(SOURCE/'plan.json');allowed=s['allowed_profiles'];stock=s['anchor_bounds_units1000'];rows=load(BASE/'inventory.json');assert len(rows)==1;row=rows[0];assert row['parts']==list(range(8)) and row['originals']==[p['item'] for p in s['parts']] and row['allowed_profiles']==allowed and row['solver_seconds']==45
m=cp_model_pb2.CpModelProto();m.ParseFromString((BASE/'models/000.pb').read_bytes());assert {f.name for f,v in m.ListFields()}=={'variables','constraints'};vc=cc=0
def var(name,domain):
    global vc
    assert m.variables[vc]==cp_model_pb2.IntegerVariableProto(name=name,domain=domain),vc;vc+=1
def lin(terms,lo,hi,enforce=()):
    global cc
    c=cp_model_pb2.ConstraintProto();keys=sorted(k for k,v in terms.items() if v);c.linear.vars.extend(keys);c.linear.coeffs.extend(terms[k] for k in keys);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(enforce);assert m.constraints[cc]==c,cc;cc+=1
for i,options in enumerate(allowed):
    for axis in [0,1]:var(f'p{i}-'+('xy'[axis]),[min(stock[str(p)][axis] for p in options),max(stock[str(p)][axis+2] for p in options)])
flags={}
for i in range(4):
    flags[i]=[]
    for p in range(8):flags[i].append(vc);var(f'p{i}-profile{p}',[0,1])
assert {str(k):v for k,v in flags.items()}==load(BASE/'profile-flags.json')
for i in range(4):
    lin(dict.fromkeys(flags[i],1),1,1)
    for p,v in enumerate(flags[i]):
        b=stock[str(p)]
        for axis in range(2):lin({2*i+axis:1},b[axis],b[axis+2],[v])
# Original copy numbers carry identity only; every member references the same family geometry,
# identical allowed orientations and the same stock. Relabelling the four placements preserves
# all contours and pair constraints. Sorting profiles and cog x coordinates preserves feasibility.
for group,family in [(s['parts'][:4],'bracket'),(s['parts'][4:],'cog')]:
    assert len({r['copy'] for r in group})==4 and all(r['family']==family for r in group)
for i in range(3):
    terms={}
    for p in range(8):terms[flags[i][p]]=p;terms[flags[i+1][p]]=-p
    lin(terms,-2**63,0)
for i in range(4,7):lin({2*i:1,2*(i+1):-1},-2**63,0)
records=[];count={'tautological_faces':0,'singleton_faces':0,'disjunctive_faces':0,'impossible_faces':0};data={(c['profile_a'],c['profile_b']):load(SOURCE/'mutual'/f"{c['index']:03d}.json") for c in s['mutual_cases']}
for a,b in combinations(range(8),2):
    for pa,pb in product(allowed[a],allowed[b]):
        aa,bb=stock[str(pa)],stock[str(pb)];box=[bb[0]-aa[2],bb[1]-aa[3],bb[2]-aa[0],bb[3]-aa[1]];corners=list(product([box[0],box[2]],[box[1],box[3]]));active=([flags[a][pa]] if a<4 else [])+([flags[b][pb]] if b<4 else []);faces=[]
        for face in data[pa,pb]['faces']:
            hs=face['outside_halfplanes'];values=[[h['a']*x+h['b']*y for x,y in corners] for h in hs]
            if any(min(v)>=h['bound'] for h,v in zip(hs,values)):count['tautological_faces']+=1;faces.append({'face':face['index'],'tautological':True});continue
            live=[j for j,(h,v) in enumerate(zip(hs,values)) if max(v)>=h['bound']];efs=[]
            def plane(j,enforce):
                h=hs[j];lin({2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']},h['bound'],2**63-1,enforce)
            if len(live)==1:plane(live[0],active);count['singleton_faces']+=1
            else:
                for j in live:
                    efs.append(vc);var(f'p{a}-{b}-q{pa}-{pb}-f{face["index"]}-e{j}',[0,1]);plane(j,active+[efs[-1]])
                c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-v-1 for v in active]+efs);assert c==m.constraints[cc];cc+=1;count['disjunctive_faces' if live else 'impossible_faces']+=1
            faces.append({'face':face['index'],'live_edges':live,'flags':efs})
        records.append({'parts':[a,b],'profiles':[pa,pb],'active':active,'difference_bounds':box,'faces':faces})
assert records==load(BASE/'models/000-mapping.json') and len(records)==518 and vc==row['variables']==len(m.variables) and cc==row['constraints']==len(m.constraints) and all(row[k]==v for k,v in count.items()) and digest(BASE/'models/000.pb')==row['model_sha256']
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==m
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':vc,'constraints':cc,'physical_orientation_modes':518,'all_profile_choices_preserved_up_to_identical_copy_relabelling':True,'every_constraint_reconstructed':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
