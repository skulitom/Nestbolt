"""Audit the exact count-only change and all66-original identity accounting."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-nine-part-band-model-20261026';PARENT=ROOT/'output/h5-second-strip-band-model-20261026';EXCHANGE=ROOT/'output/h5-insert36-cog53-exchange-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Verify immutable committed parent and first-sheet exchange evidence. Reconstruct precisely336 insert-cell upper-bound changes and one exact count-equality change; require entire proto equality to the parent after reversing only those changes. Verify every coefficient, capacity and other family count remains. Account for55 distinct first-sheet originals,nine distinct second-sheet originals,and still-required28/29 as exactly all66 original IDs. Actual solver import/export must match. No solving.'})
manifest=load(ROOT/'benchmarks/results/h5-second-strip-capacity-and-insert-exchange-20261026/raw-manifest.json');known={r['sha256'] for r in manifest['files']+manifest['aliases']}
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h and h in known,n
for path in [PARENT/'plan.json',PARENT/'audit/plan.json',EXCHANGE/'plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'audit/checks.json')['passed'] and load(EXCHANGE/'checks.json')['passed'];mapping=load(BASE/'mapping.json');assert mapping==load(PARENT/'mapping.json');model=proto(BASE/'model.pb');parent=proto(PARENT/'model.pb');expected=cp_model_pb2.CpModelProto();expected.CopyFrom(parent);changed=[]
for r in mapping:
    assert list(parent.variables[r['variable']].domain)==[0,{'bracket':4,'insert':2,'cog':4}[r['family']]]
    if r['family']=='insert':expected.variables[r['variable']].domain[1]=1;changed.append(r['variable'])
assert len(changed)==336 and list(parent.constraints[1].linear.vars)==changed and list(parent.constraints[1].linear.coeffs)==[1]*336 and list(parent.constraints[1].linear.domain)==[2,2];expected.constraints[1].linear.domain[:]=[1,1];assert expected==model and load(BASE/'changes.json')=={'insert_count_constraint':1,'old_count':2,'new_count':1,'insert_variable_upper_bounds_changed':changed}
first=load(EXCHANGE/'first-sheet-identities.json');second=load(EXCHANGE/'mandatory-second-sheet-originals.json');assert len(first)==len(set(first))==55 and len(second)==len(set(second))==9 and set(first).isdisjoint(second) and sorted(first+second+[28,29])==list(range(66));assert 36 in first and 53 in second and 36 not in second;items=load(ROOT/'output/h5-source-orientation-construction-20261025/items.json');assert Counter(items[i]['family'] for i in second)=={'bracket':4,'insert':1,'cog':4};assert load(BASE/'plan.json')['required_original_counts']=={'bracket':4,'insert':1,'cog':4} and load(BASE/'plan.json')['mandatory_originals']==second
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'solver-import-roundtrip.pb'));assert proto(OUT/'solver-import-roundtrip.pb')==model;write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':673,'constraints':66,'exact_parent_restoration_verified':True,'insert_variable_bounds_changed':336,'insert_count_equality_changed':1,'all63_capacity_constraints_unchanged':True,'all66_original_identities_accounted_for':True,'mandatory_second_sheet_originals':second,'actual_import_export_verified':True,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
