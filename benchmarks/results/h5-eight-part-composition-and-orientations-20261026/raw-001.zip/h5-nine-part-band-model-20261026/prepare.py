"""Change only the mandatory insert count after the verified original exchange."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-second-strip-band-model-20261026';EXCHANGE=ROOT/'output/h5-insert36-cog53-exchange-20261026';OUT=ROOT/'output/h5-nine-part-band-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed'] and load(EXCHANGE/'checks.json')['passed'];paths=[PARENT/n for n in ['model.pb','mapping.json','plan.json','audit/checks.json','audit/plan.json']]+[EXCHANGE/n for n in ['plan.json','checks.json','mandatory-second-sheet-originals.json','first-sheet-identities.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'required_original_counts':{'bracket':4,'insert':1,'cog':4},'mandatory_originals':load(EXCHANGE/'mandatory-second-sheet-originals.json'),'method':'Distinct nine-original composition after the independently verified insert36/cog53 exchange. Retain every audited band coefficient, all63 capacities and all673 profile/cell variables. Change only the336 insert-cell upper bounds from2 to1 and the exact insert-count equality from2 to1. Four brackets,insert37,and four cogs stay mandatory; the55 first-sheet originals and missing28/29 are accounted for separately. No coordinate, collision, objective or hint is added. Independent whole-parent restoration before one20second call within30shared seconds. All prior calls remain closed; the old two-insert obstruction is not transferred.'})
model=cp_model_pb2.CpModelProto();model.ParseFromString((PARENT/'model.pb').read_bytes());mapping=load(PARENT/'mapping.json');changed=[]
for row in mapping:
    if row['family']=='insert':assert list(model.variables[row['variable']].domain)==[0,2];model.variables[row['variable']].domain[1]=1;changed.append(row['variable'])
assert len(changed)==336 and list(model.constraints[1].linear.domain)==[2,2];model.constraints[1].linear.domain[:]=[1,1];shutil.copyfile(PARENT/'mapping.json',OUT/'mapping.json');write(OUT/'changes.json',{'insert_count_constraint':1,'old_count':2,'new_count':1,'insert_variable_upper_bounds_changed':changed});(OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');write(OUT/'result.json',{'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'family_counts':{'bracket':4,'insert':1,'cog':4},'insert_upper_bounds_changed':len(changed),'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'result.json'))
