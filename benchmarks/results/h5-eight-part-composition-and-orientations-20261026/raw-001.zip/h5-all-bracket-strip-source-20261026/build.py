"""All approved bracket orientations for the eight-original short-sheet subproblem."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations,product
from datetime import datetime,timezone
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-all-bracket-strip-source-20261026';PARENT=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';STOCK=ROOT/'output/h5-source-orientation-construction-20261025';EXCHANGE=ROOT/'output/h5-insert36-cog53-exchange-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'mutual').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
assert load(PARENT/'audit/checks.json')['passed'];profiles=load(PARENT/'profiles.json');items=load(STOCK/'items.json');stock=load(STOCK/'geometry.json')['stock_bounds_rational'][1]
ids=[21,22,25,26,53,63,64,65];allowed=[list(range(8)) for _ in range(4)]+[[9] for _ in range(4)];first=load(EXCHANGE/'first-sheet-identities.json');assert len(first)==55 and sorted(first+ids+[28,29,37])==list(range(66))
keys=sorted({(pa,pb) for a,b in combinations(range(8),2) for pa,pb in product(allowed[a],allowed[b])});assert len(keys)==73
old={(c['profile_a'],c['profile_b']):c for c in load(PARENT/'plan.json')['mutual_cases']};cases=[{'index':i,'profile_a':a,'profile_b':b} for i,(a,b) in enumerate(keys)];bounds={};st=[F(*x) for x in stock];pad=F(.0125)+F(.000001)
for pi in sorted({p for a in allowed for p in a}):
    b=profiles[pi]['bounds'];bounds[pi]=[math.ceil((st[0]+pad-F(b[0]))*1000),math.ceil((st[1]+pad-F(b[1]))*1000),math.floor((st[2]-pad-F(b[2]))*1000),math.floor((st[3]-pad-F(b[3]))*1000)]
inputs=[PARENT/'profiles.json',PARENT/'plan.json',PARENT/'audit/checks.json',STOCK/'items.json',STOCK/'geometry.json',EXCHANGE/'first-sheet-identities.json',ROOT/'output/h5-eight-part-strip-probe-repaired-20261026/response-audit/checks.json']+[PARENT/'mutual'/f"{old[key]['index']:03d}.json" for key in keys]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'parts':[{'part':i,'item':n,'family':items[n]['family'],'copy':items[n]['copy']} for i,n in enumerate(ids)],'allowed_profiles':allowed,'used_profiles':list(range(8))+[9],'mutual_cases':cases,'anchor_bounds_units1000':bounds,'stock_bounds_rational':stock,'first_sheet_checked_originals':first,'pending_first_sheet_originals':[28,29,37],'maximum_calls':1,'solver_seconds':45,'shared_seconds':60,'workers':4,'seed':0,'method':'Release all four bracket orientations: each independently chooses any of its eight approved quarter-turn/mirror profiles. All eight original translations remain free. Four cogs retain the recorded source angle. Include every one of518 physical orientation pair modes across28 pairs. Copy symmetry may order bracket profile numbers and cog x anchors because each family is four identical copies with the same complete geometry and allowed transforms; preserve original identities by assigning sorted placements to them. One new45second call inside60shared seconds after whole-model audit. The earlier fixed orientation negative is not transferred. A positive is only an eight-part sheet witness; IDs28/29/37 and all complete-job/native/production/H5 checks remain required.'})
write(OUT/'profiles.json',profiles)
for c in cases:
    oldc=old[c['profile_a'],c['profile_b']];p=PARENT/'mutual'/f"{oldc['index']:03d}.json";r=load(p);r['case']=c;r['reused_source_case']=oldc;r['reused_source_sha256']=digest(p);write(OUT/'mutual'/f"{c['index']:03d}.json",r)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'originals':8,'pair_cases':73,'physical_pairs':28,'physical_orientation_modes':518,'solver_calls':0,'H5_complete':False})
print(load(OUT/'result.json'))
