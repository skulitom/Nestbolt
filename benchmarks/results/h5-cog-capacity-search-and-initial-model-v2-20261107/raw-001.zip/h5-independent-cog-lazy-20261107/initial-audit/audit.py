"""Independently read the smaller initial model and complete preparation ledger."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from h5_independent_cog_lazy_model_reader_20261107 import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-cog-lazy-20261107';MODEL=BASE/'initial-model';OUT=BASE/'initial-audit';P=ROOT/'output/h5-independent-twelve-cog-checkpoint-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();queue=[MODEL/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
proto=cp_model_pb2.CpModelProto();proto.ParseFromString((MODEL/'model.pb').read_bytes());assert proto==text_format.Parse((MODEL/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto())
checks=verify(proto,load(MODEL/'mapping.json'),[]);assert checks['variables_verified']==1332 and checks['constraints_verified']==4712 and checks['source_region_selectors_verified']==checks['source_region_planes_verified']==0 and checks['partial_hint_values_verified']==36
source=load(MODEL/'checks.json');assert source['variables']==1332 and source['constraints']==4712 and source['model_sha256']==digest(MODEL/'model.pb')
charges=load(P/'preparation-charges.json');charges['halfplanes_complete_preparation_seconds']=load(ROOT/'output/h5-independent-twelve-cog-halfplanes-process-20261107/prepare.json')['complete_seconds'];charges['capacity_complete_preparation_seconds']=load(ROOT/'output/h5-independent-cog-capacity-process-20261107/prepare.json')['complete_seconds'];charges['cp_model_build_seconds']=source['seconds'];assert charges==load(MODEL/'preparation-charges.json') and sum(charges.values())==source['preparation_seconds_charged']
process=load(MODEL/'build-process.json');assert process['exit_code']==0 and process['job']['closed'] and process['job']['active_processes']==0 and process['complete_process_seconds']>=charges['cp_model_build_seconds'];charges['cp_model_build_seconds']=process['complete_process_seconds'];assert charges==load(MODEL/'final-preparation-charges.json') and sum(charges.values())==load(MODEL/'budget.json')['preparation_seconds_charged']
for name,h in process['inputs'].items():assert digest(ROOT/name)==h
assert process['script_sha256']==digest(ROOT/'output/build_h5_independent_cog_lazy_initial_20261107.py')
for folder in ['h5-independent-twelve-cog-integer-20261107','h5-independent-twelve-cog-halfplanes-20261107','h5-independent-cog-capacity-20261107']:
    assert not any(name.startswith('output/'+folder+'/'+prefix) for name in bindings for prefix in ['model/','model-audit/','search/','response-audit/','memory-stop-audit/'])
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),ROOT/'output/h5_independent_cog_lazy_model_reader_20261107.py',ROOT/'output/h5_independent_cog_capacity_model_reader_20261107.py',ROOT/'output/prepare_h5_independent_cog_lazy_helpers_20261107.py',ROOT/'output/audit_h5_independent_cog_capacity_model_20261107.py']+[p for p in MODEL.glob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently read every field of the initial necessary model. Reconstruct all owners, modes, original bounds,24 rigid components,268 full orthogonal component separations,25 copy orders and all source profile/coarse occupancy constraints. Require exactly zero detailed cog-pair choices or canonical coordinate links. Verify36 source-control hint values and the partial cog capacity/non-overlap controls. Binary/text equality and actual solver import pass. Verify complete source/build charges and absence of all three current closed model/search artifacts. Later changed models require the same exhaustive independent reader before any solve, and every candidate requires full66 original-source checking.'})
result={**checks,'seconds':time.perf_counter()-start,'recursive_bindings_verified':len(bindings),'binary_text_equal':True,'actual_solver_import_validation_passed':True,'complete_preparation_seconds_charged':sum(charges.values()),'model_sha256':digest(MODEL/'model.pb'),'current_closed_models_consumed':False,'source_pair_geometry_absent_is_not_source_validity':True,'pipeline_prepared':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',result);print(result)
