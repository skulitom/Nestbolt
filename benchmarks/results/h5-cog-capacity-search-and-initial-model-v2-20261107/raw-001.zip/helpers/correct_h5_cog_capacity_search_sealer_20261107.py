from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'output/prepare_h5_cog_capacity_search_sealer_20261107.py';new=ROOT/'output/prepare_h5_cog_capacity_search_sealer_v2_20261107.py';source=old.read_text(encoding='utf-8')
source=source.replace('s=s[:a]+f'+chr(39)*3+'Latest','s=s[:a]+f'+chr(34)*3+'Latest').replace(chr(39)*3+'+s[b:]',chr(34)*3+'+s[b:]')
needle="for name,h in load(F/'source-bindings.json').items():"
extra="add('sealer-correction.json',ROOT/'output/h5-cog-capacity-search-sealer-correction-20261107.json')\n"+needle
source=source.replace('suffix=r'+chr(39)*3,'prefix=prefix.replace('+repr(needle)+','+repr(extra)+')\nsuffix=r'+chr(39)*3)
source=source.replace('Independent archive verification is required before commit.', 'A pre-execution sealer-generator quoting error and its attempted missing-file invocation are preserved in the archive with a versioned correction. Neither invoked a model, search or artifact write. Independent archive verification is required before commit.')
ast.parse(source)
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
record={'utc':datetime.now(timezone.utc).isoformat(),'failed_generator':old.relative_to(ROOT).as_posix(),'failed_generator_sha256':sha256(old.read_bytes()).hexdigest(),'failure':'SyntaxError: invalid decimal literal at line134; nested same-delimiter triple string ended the generator source early. The subsequent command could not open the nonexistent sealer file.','corrected_generator':new.relative_to(ROOT).as_posix(),'corrected_generator_sha256':sha256(new.read_bytes()).hexdigest(),'correction':'Use distinct triple-string delimiters in the generated status text. Preserve the original generator and this record in the archive.','model_preparation_repeated':False,'solver_repeated':False,'frozen_evidence_changed':False,'artifact_created_by_failed_commands':False}
with (ROOT/'output/h5-cog-capacity-search-sealer-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print('Original pre-execution failure preserved; corrected generator passes syntax parsing.')
