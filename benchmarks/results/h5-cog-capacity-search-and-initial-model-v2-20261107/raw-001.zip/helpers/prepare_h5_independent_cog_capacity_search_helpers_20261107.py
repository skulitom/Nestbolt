from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
runner=(ROOT/'output/run_h5_independent_twelve_cog_halfplane_model_20261107.py').read_text(encoding='utf-8')
runner=runner.replace("BASE = ROOT / 'output/h5-independent-twelve-cog-halfplanes-20261107'", "BASE = ROOT / 'output/h5-independent-cog-capacity-20261107'\nGEOM = ROOT / 'output/h5-independent-twelve-cog-halfplanes-20261107'")
runner=runner.replace('h5_independent_twelve_cog_halfplane_candidate_20261107.py','h5_independent_cog_capacity_candidate_20261107.py').replace('prepare_h5_independent_twelve_cog_halfplane_search_helpers_20261107.py','prepare_h5_independent_cog_capacity_search_helpers_20261107.py')
runner=runner.replace("BASE / 'audit-v2'","BASE / 'audit'").replace("BASE/'audit-v2/plan.json'","BASE/'audit/plan.json'").replace("BASE/'audit-v2/checks.json'","BASE/'audit/checks.json'")
runner=runner.replace("BASE/'control-regions.json'", "GEOM/'control-regions.json',BASE/'modes.json',BASE/'capacity.json'")
checker=(ROOT/'output/check_h5_independent_twelve_cog_halfplane_candidate_20261107.py').read_text(encoding='utf-8').replace('h5-independent-twelve-cog-halfplanes-20261107','h5-independent-cog-capacity-20261107')
auditor=(ROOT/'output/audit_h5_independent_twelve_cog_halfplane_response_20261107.py').read_text(encoding='utf-8').replace('h5-independent-twelve-cog-halfplanes-20261107','h5-independent-cog-capacity-20261107')
for name,source in [('run_h5_independent_cog_capacity_model_20261107.py',runner),('check_h5_independent_cog_capacity_candidate_20261107.py',checker),('audit_h5_independent_cog_capacity_response_20261107.py',auditor)]:
    ast.parse(source)
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print('Fresh one-call capacity runner, full66 checker and response auditor prepared.')
