from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'output/seal_h5_cog_capacity_search_checkpoint_20261107.py';new=ROOT/'output/seal_h5_cog_capacity_search_checkpoint_v2_20261107.py'
empty=ROOT/'benchmarks/results/h5-cog-capacity-search-and-initial-model-20261107';assert empty.is_dir() and not list(empty.iterdir())
record=json.loads((ROOT/'output/h5-cog-capacity-search-sealer-correction-20261107.json').read_bytes());bad=ROOT/record['failed_generator'];assert sha256(bad.read_bytes()).hexdigest()==record['failed_generator_sha256']
try:ast.parse(bad.read_text(encoding='utf-8'))
except SyntaxError as exc:assert exc.lineno==134
else:raise AssertionError('Expected preserved source syntax failure')
s=old.read_text(encoding='utf-8').replace('h5-cog-capacity-search-and-initial-model-20261107','h5-cog-capacity-search-and-initial-model-v2-20261107')
needle="exec(old[old.index('while queue:'):old.index('for source,name in [(')])"
target="for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):"
replacement="""if p==ROOT/'output/prepare_h5_cog_capacity_search_sealer_20261107.py':
            record=load(ROOT/'output/h5-cog-capacity-search-sealer-correction-20261107.json');assert digest(p)==record['failed_generator_sha256']
            try:ast.parse(p.read_text(encoding='utf-8'))
            except SyntaxError as exc:assert exc.lineno==134
            else:raise AssertionError('Expected preserved raw-source failure')
            continue
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):"""
assert needle in s
s=s.replace(needle,"exec(old[old.index('while queue:'):old.index('for source,name in [(')].replace("+repr(target)+","+repr(replacement)+"))")
s=s.replace("add('sealer-correction.json',ROOT/'output/h5-cog-capacity-search-sealer-correction-20261107.json')", "add('sealer-correction.json',ROOT/'output/h5-cog-capacity-search-sealer-correction-20261107.json')\nadd('archive-correction.json',ROOT/'output/h5-cog-capacity-search-archive-correction-20261107.json')")
s=s.replace('A pre-execution sealer-generator quoting error and its attempted missing-file invocation are preserved in the archive with a versioned correction. Neither invoked a model, search or artifact write.', 'The pre-execution sealer-generator quoting error is retained as raw evidence. A first packaging pass then stops while trying to parse that known-invalid source, before writing any archive or documentation. Version2 verifies its exact hash and expected syntax failure, retains it as data and otherwise keeps strict helper parsing. Both failures and corrections are archived; no model, search or frozen evidence is repeated or changed.')
ast.parse(s)
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
correction={'utc':datetime.now(timezone.utc).isoformat(),'failed_sealer':old.relative_to(ROOT).as_posix(),'failed_sealer_sha256':sha256(old.read_bytes()).hexdigest(),'failure':'The archive dependency walker tried to AST-parse the deliberately preserved invalid generator and stopped at its known SyntaxError line134.','failed_output_directory':empty.relative_to(ROOT).as_posix(),'failed_output_directory_is_empty':True,'corrected_sealer':new.relative_to(ROOT).as_posix(),'corrected_sealer_sha256':sha256(new.read_bytes()).hexdigest(),'correction':'Handle only the exact hash-bound known-invalid generator as raw evidence after confirming its expected SyntaxError. All other helpers remain strict AST-parsed. Use a distinct v2 artifact directory; preserve the empty failed directory.','closed_preparations_or_searches_repeated':False,'frozen_evidence_changed':False}
with (ROOT/'output/h5-cog-capacity-search-archive-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(correction,f,indent=2);f.write('\n')
print('Packaging failure preserved; v2 archives the known invalid helper as hash-bound raw data.')
