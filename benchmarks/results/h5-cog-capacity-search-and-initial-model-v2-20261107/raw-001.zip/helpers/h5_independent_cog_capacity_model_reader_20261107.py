"""Independent exhaustive reader of owner-coupled optional source occupancy."""
from itertools import combinations

def inspect(p,mapping,owners,source,stock,used_ct,hints):
    src={(r['family'],r['mode']):r for r in source}
    assert set(mapping)=={'profiles','coarse_rectangles','no_overlap_constraint'}
    assert len(mapping['profiles'])==2 and len(mapping['coarse_rectangles'])==172
    checked_intervals=0
    def ct(index,kind,name,on=()):
        assert index not in used_ct;used_ct.add(index);item=p.constraints[index]
        assert item.WhichOneof('constraint')==kind and item.name==name and list(item.enforcement_literal)==list(on)
        assert {f.name for f,v in item.ListFields()}=={kind,'name'}|({'enforcement_literal'} if on else set())
        return item
    def expression(e,var,offset):
        assert list(e.vars)==([] if var is None else [var]) and list(e.coeffs)==([] if var is None else [1]) and e.offset==offset
        assert {f.name for f,v in e.ListFields()}==({'vars','coeffs'} if var is not None else set())|({'offset'} if offset else set())
    def interval(index,name,position,start,end,selector):
        nonlocal checked_intervals
        item=ct(index,'interval',name,[selector]);assert end>start
        expression(item.interval.start,position,start);expression(item.interval.size,None,end-start);expression(item.interval.end,position,end)
        assert {f.name for f,v in item.interval.ListFields()}=={'start','size','end'}
        checked_intervals+=1
    profile_counts=[];hint_profiles=[]
    for axis,row in enumerate(mapping['profiles']):
        assert set(row)=={'axis','intervals','constraint','capacity'} and row['axis']==axis and row['capacity']==stock['profile_axis_capacities'][axis]
        expected=[(o,m,pi,r) for o in owners for m in o['modes'] for pi,r in enumerate(src[(o['identity'][0],m['mode'])]['profiles'][axis])]
        assert len(expected)==len(row['intervals'])==[1564,552][axis]
        indices=[];demands=[];hint_events={}
        for saved,(o,m,pi,r) in zip(row['intervals'],expected):
            assert set(saved)=={'owner','mode','selector','source_profile','interval'} and saved['owner']==o['owner'] and saved['mode']==m['mode'] and saved['selector']==m['selector'] and saved['source_profile']==pi
            interval(saved['interval'],f'capacity_{axis}_{o["owner"]}_{m["mode"]}_{pi}',o['positions'][axis],r['start'],r['end'],m['selector'])
            indices.append(saved['interval']);demands.append(r['demand'])
            if m['selector'] in hints and hints[m['selector']]:
                assert o['positions'][axis] in hints;start=hints[o['positions'][axis]]+r['start'];end=hints[o['positions'][axis]]+r['end']
                hint_events[start]=hint_events.get(start,0)+r['demand'];hint_events[end]=hint_events.get(end,0)-r['demand']
        item=ct(row['constraint'],'cumulative',f'capacity_axis_{axis}');assert list(item.cumulative.intervals)==indices and len(item.cumulative.demands)==len(demands)
        assert {f.name for f,v in item.cumulative.ListFields()}=={'intervals','demands','capacity'}
        for e,d in zip(item.cumulative.demands,demands):expression(e,None,d)
        expression(item.cumulative.capacity,None,stock['profile_axis_capacities'][axis])
        live=peak=0
        for t,delta in sorted(hint_events.items()):live+=delta;peak=max(peak,live)
        assert live==0 and peak<=row['capacity'];hint_profiles.append({'axis':axis,'partial_cog_demand_peak':peak,'capacity':row['capacity'],'only_known_cogs_checked':True});profile_counts.append(len(indices))
    expected=[(o,m,ri,r) for o in owners for m in o['modes'] for ri,r in enumerate(src[(o['identity'][0],m['mode'])]['coarse_rectangles_grid'])]
    assert len(expected)==172;xx=[];yy=[];hint_rects=[]
    for saved,(o,m,ri,r) in zip(mapping['coarse_rectangles'],expected):
        assert set(saved)=={'owner','mode','selector','source_rectangle','intervals'} and saved['owner']==o['owner'] and saved['mode']==m['mode'] and saved['selector']==m['selector'] and saved['source_rectangle']==ri and len(saved['intervals'])==2
        for axis in [0,1]:interval(saved['intervals'][axis],f'coarse_{o["owner"]}_{m["mode"]}_{ri}_{axis}',o['positions'][axis],r[axis],r[axis+2],m['selector'])
        xx.append(saved['intervals'][0]);yy.append(saved['intervals'][1])
        if m['selector'] in hints and hints[m['selector']]:hint_rects.append([hints[o['positions'][k%2]]+v for k,v in enumerate(r)])
    item=ct(mapping['no_overlap_constraint'],'no_overlap_2d','coarse_source_occupancy')
    assert list(item.no_overlap_2d.x_intervals)==xx and list(item.no_overlap_2d.y_intervals)==yy and {f.name for f,v in item.no_overlap_2d.ListFields()}=={'x_intervals','y_intervals'}
    assert len(hint_rects)==12 and all(a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1] for a,b in combinations(hint_rects,2))
    assert checked_intervals==2460
    return {'source_profile_intervals_verified':profile_counts,'cumulative_constraints_verified':2,'coarse_optional_rectangles_verified':172,'coarse_axis_intervals_verified':344,'no_overlap_2d_constraints_verified':1,'all_added_constraints_verified':2463,'new_coordinate_variables':0,'all_intervals_mode_and_owner_coupled':True,'partial_cog_capacity_controls':hint_profiles,'partial_cog_coarse_pair_controls':66,'partial_control_is_not_full66':True}
