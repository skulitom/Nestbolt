from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-cog-capacity-search-and-initial-model-v2-20261107';OUT=ROOT/'benchmarks/results'/NAME
H=ROOT/'output/h5-independent-cog-capacity-20261107';C=ROOT/'output/h5-independent-cog-lazy-20261107';F=ROOT/'output/h5-cog-capacity-search-checkpoint-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
front=load(F/'checks.json');assert front['passed'] and front['closed_solver_calls']==1 and front['closed_solver_status']=='UNKNOWN' and not front['pipeline_prepared']
inventory_ast=ast.parse((ROOT/'output/seal_h5_polygon_clearance_proofs_20261107.py').read_text(encoding='utf-8')).body
def assignment(node,name):return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
inventory_start=next(i for i,node in enumerate(inventory_ast) if assignment(node,'setup'));inventory_end=next(i for i,node in enumerate(inventory_ast) if assignment(node,'walker'))
exec(compile(ast.Module(body=inventory_ast[inventory_start:inventory_end],type_ignores=[]),'historical-parent-archives','exec'))
PARENTS.extend(ROOT/'benchmarks/results'/name for name in ['h5-polygon-clearance-proofs-20261107','h5-exact-circle-forest-20261107','h5-strip-capacity-models-20261107','h5-twelve-cog-row-construction-20261107','h5-twelve-cog-543-constructions-20261107','h5-independent-twelve-cog-preparation-20261107','h5-independent-cog-search-and-halfplanes-20261107','h5-cog-halfplane-search-and-capacity-20261107'])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
exec(old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']"))
folders=[H,C,F]+[ROOT/'output'/n for n in ['h5-independent-cog-capacity-model-process-20261107','h5-independent-cog-lazy-initial-process-20261107','h5-cog-halfplane-capacity-main-sync-20261107']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*independent*cog*capacity*20261107.py','*h5*independent*cog*lazy*20261107.py','*h5*cog*capacity*search*20261107.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['ccd1.py','pack_h5_evidence_archive.py',walker.name,'seal_h5_polygon_clearance_proofs_20261107.py']:add('helpers/'+name,ROOT/'output'/name)
add('sealer-correction.json',ROOT/'output/h5-cog-capacity-search-sealer-correction-20261107.json')
add('archive-correction.json',ROOT/'output/h5-cog-capacity-search-archive-correction-20261107.json')
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
exec(old[old.index('while queue:'):old.index('for source,name in [(')].replace("for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):","if p==ROOT/'output/prepare_h5_cog_capacity_search_sealer_20261107.py':\n            record=load(ROOT/'output/h5-cog-capacity-search-sealer-correction-20261107.json');assert digest(p)==record['failed_generator_sha256']\n            try:ast.parse(p.read_text(encoding='utf-8'))\n            except SyntaxError as exc:assert exc.lineno==134\n            else:raise AssertionError('Expected preserved raw-source failure')\n            continue\n        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):"))
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(H/'model-audit/checks.json','closed-model-audit.json'),(H/'model/final-preparation-charges.json','closed-model-preparation-charges.json'),(H/'response-audit/checks.json','response-audit.json'),(H/'search/process.json','closed-search-process.json'),(C/'initial-audit/checks.json','initial-model-audit.json'),(C/'initial-model/final-preparation-charges.json','initial-preparation-charges.json'),(ROOT/'output/h5-independent-cog-lazy-initial-process-20261107/process.json','initial-process.json'),(ROOT/'output/h5-cog-halfplane-capacity-main-sync-20261107/receipt.json','main-push-receipt.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f"""# Global-capacity search and smaller initial model — 2026-11-07

The complete global-capacity construction closes its sole call **UNKNOWN**,
with no placement. All model and response audits pass, and the overall time
and memory limits hold. A distinct staged approach now has a fully audited
**1,332-variable, 4,712-constraint initial model**, with all original movers
and modes retained. Its source-check/cut pipeline has not been prepared or run.
Four fixed arrangements and all 440 allocations remain; H2/H5 stay open at
**60% completed milestone weight**.

## Complete global model and closed response

[The exhaustive model audit]({NAME}/closed-model-audit.json) verifies
**28,254 variables and 60,632 constraints**. All 258 detailed cog interactions
and all 120 orthogonal-owner interactions remain. The new global system adds
2,460 optional affine intervals, two cumulative constraints and one NoOverlap2D
constraint. Every interval shares its original owner coordinates and mode
selector. Both axes and all 172 coarse rectangle alternatives are checked.
The partial twelve-cog control passes both capacity bounds and all 66 coarse
pair checks, while remaining sixteen parts are unplaced in that control.

[Complete preparation and model building]({NAME}/closed-model-preparation-charges.json)
take **6.938077 seconds**, including the 2.691284-second complete build process.
The separate complete model audit takes 8.251503 seconds.

[Independent response readback]({NAME}/response-audit.json) verifies one
four-worker, seed-zero call with **48.164376 seconds allocated** and
**48.274940 seconds returned**, preserving the **0.110564-second solve-slice
overrun**. It records 148,027 branches and 17,411 conflicts, with no incumbent
or assignment. Preparation-inclusive algorithm/shared totals are
**56.129667 / 56.232693 seconds**, below the original 60/90-second limits.

[The Windows Job closes normally]({NAME}/closed-search-process.json), with
all three processes closed and zero active descendants. Peak aggregate
committed memory is **1,981,014,016 bytes**, below 2,147,483,648. The returned
UNKNOWN response proves no continuous or whole-allocation exclusion. This call
is permanently closed and will not be repeated, reseeded or extended.

## Initial model for staged source constraints

The new approach first asks for a necessary assignment using full orthogonal
geometry and globally coupled source occupancy. Detailed cog-pair disjunctions
are introduced only after an actual original-source collision is observed.
This differs from reopening either closed full model: no previous model or
search artifact is consumed, and the new initial model has no detailed cog-pair
choices. A necessary assignment cannot qualify as a valid layout by itself.

[Initial-model readback]({NAME}/initial-model-audit.json) verifies every field
of **1,332 variables and 4,712 constraints**. It retains all 28 original movers,
108 mode options, 56 world coordinates, 24 rigid orthogonal components,
640 component links, 268 component-pair separations and 25 valid copy orders.
All 1,564 X-axis and 552 Y-axis source projection intervals, both cumulative
constraints and the 172 optional coarse rectangles remain. There are exactly
zero detailed cog-pair selectors, planes or canonical-coordinate links.

The 36-value partial cog hint satisfies all 47 fully hinted active linear
constraints. Its projection peaks are 75,936 / 88,561 and 98,896 / 148,696 grid
units, and all 66 coarse cog pairs pass. It remains a partial control.
Binary/text equality, actual solver import, every original source-mode domain
and all constraint fields pass independent checks.

[The complete initial build]({NAME}/initial-process.json) takes **0.858846
seconds**; its separate complete audit takes 3.043320 seconds. With all consumed
source preparation, [the next pipeline starts with a charge of 5.105639
seconds]({NAME}/initial-preparation-charges.json). Closed previous model builds
are not reused, and their outputs are absent from the new runtime input graph.

## Remaining staged-pipeline obligations

[The proposed bounded pipeline]({NAME}/next-step.json) allows at most four
strictly changing rounds within the original preparation-inclusive 60/90-second
and 2 GiB limits: first solve at most 30 seconds, later solves at most eight,
each also limited by remaining time with a four-second source-check reserve.
Every dynamic rebuild, in-process audit, source check and solve is charged.

Every returned candidate must reconstruct all 66 original identities and check
1,632 same-sheet pairs, 264 stock edges, 90 holes and 10,026 hole vertices.
Before a later round, every newly failing cog pair must be mapped to its
complete certified source interaction. Keep all previous cuts and independently
audit the entire changed model before its sole call. A stock, fixed-part,
orthogonal-only or already-constrained pair failure is an inconsistency and
stops the pipeline. UNKNOWN, INFEASIBLE, invalid model, no new cut or deadline
also stop it; an unchanged model can never be retried.

No pipeline runner or new solver call is prepared in this checkpoint. These
limits and source-cut obligations must be frozen in executable code before any
call. Source-valid full66, native/material validation, production integration
and the unchanged complete H5 matrix remain required. H2 retains its original
gate and unopened reserved vectors. No release is made.

## Repository evidence

[The preceding two checkpoints reached main 37ede828 normally]({NAME}/main-push-receipt.json)
after all six prior checks passed, preserving all 52 remote files. The working
branch was updated atomically. [New main CI at review]({NAME}/main-ci-at-review.json)
is preserved; no live run is cancelled. Production and READMEs are unchanged.

[The archive]({NAME}/raw-manifest.json) contains {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes.
[Historical references]({NAME}/external-evidence.json) and
[source bindings]({NAME}/source-bindings.json) retain all consumed evidence.
The pre-execution sealer-generator quoting error is retained as raw evidence. A first packaging pass then stops while trying to parse that known-invalid source, before writing any archive or documentation. Version2 verifies its exact hash and expected syntax failure, retains it as data and otherwise keeps strict helper parsing. Both failures and corrections are archived; no model, search or frozen evidence is repeated or changed. Independent archive verification is required before commit.
"""
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-07 H5 global-capacity search and smaller initial model:** [complete model/response and initial-model audits]({link}) verify the full 28,254-variable/60,632-constraint construction, including all 2,463 new global constraints. Its sole call closes UNKNOWN with no incumbent; algorithm/shared totals are 56.129667/56.232693 s including preparation, peak memory is 1,981,014,016 bytes, and the 0.110564 s solve-slice overrun is preserved. A distinct 1,332-variable/4,712-constraint initial model retains all 28 movers, 108 modes, full orthogonal spacing and source capacity constraints while deferring detailed cog pairs. Every field passes independent readback; complete preparation is 5.105639 s. A future bounded pipeline must check all66 originals after each candidate and add only newly witnessed source-pair constraints, audit every changed model and never retry an unchanged one. That pipeline is not yet prepared or run. Four fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%. The preceding checkpoints reached main 37ede828 after all six prior CI checks passed, preserving all 52 remote files. No release is made.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
s=s[:a]+f"""Latest H5 evidence: [global-capacity search and smaller initial model](../benchmarks/results/{NAME}.md).
The complete global-capacity model passes all 28,254 variable and 60,632
constraint checks. Its sole call closes UNKNOWN without a placement, within
the overall time and memory limits; the solve-slice overrun is preserved.
A distinct necessary initial model has 1,332 variables and 4,712 constraints,
retaining every original mover/mode, full orthogonal spacing and source capacity.
Its entire readback passes. The next pipeline must validate all66 original
contours after each candidate and add detailed constraints only for newly
observed cog-pair failures, with independent readback before each changed call.
That bounded pipeline has not been prepared or run; all previous calls stay closed.
Four fixed arrangements and all 440 allocations remain; full66 source/material/
native checks and the full H5 gate are open. H2/H5 stay open at 60%.
The preceding checkpoints reached main 37ede828 after all six prior CI checks
passed, preserving all52 remote files. New CI is underway; no release is made.
"""+s[b:]
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':True,**archive,'closed_solver_calls':1,'new_pipeline_calls':0,'source_valid66':False})
