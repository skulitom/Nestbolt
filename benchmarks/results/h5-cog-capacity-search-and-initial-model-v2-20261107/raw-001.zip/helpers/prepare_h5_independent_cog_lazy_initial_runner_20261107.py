from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_independent_cog_capacity_model_build_20261107.py').read_text(encoding='utf-8')
s=s.replace('h5-independent-cog-capacity-20261107/model','h5-independent-cog-lazy-20261107/initial-model').replace('h5-independent-cog-capacity-model-process-20261107','h5-independent-cog-lazy-initial-process-20261107').replace('build_h5_independent_cog_capacity_model_20261107.py','build_h5_independent_cog_lazy_initial_20261107.py').replace('audit_h5_independent_cog_capacity_model_20261107.py','audit_h5_independent_cog_lazy_initial_20261107.py')
ast.parse(s)
with (ROOT/'output/run_h5_independent_cog_lazy_initial_build_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Distinct bounded initial-model build/audit runner prepared.')
