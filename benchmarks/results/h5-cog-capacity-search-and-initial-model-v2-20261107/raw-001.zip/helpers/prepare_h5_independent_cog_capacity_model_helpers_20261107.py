"""Generate a fresh complete model from source and an exhaustive independent audit."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
build=ROOT/'output/build_h5_independent_twelve_cog_halfplane_model_20261107.py'
audit=ROOT/'output/audit_h5_independent_twelve_cog_halfplane_model_20261107.py'
b=build.read_text(encoding='utf-8')
b=b.replace("OUT=GEOM/'model';PRE=", "CAP=ROOT/'output/h5-independent-cog-capacity-20261107';OUT=CAP/'model';PRE=")
b=b.replace("assert load(BASE/'audit/checks.json')['passed']", "assert load(CAP/'audit/checks.json')['passed'] and load(BASE/'audit/checks.json')['passed']")
insert='''capacity_sources={(r['family'],r['mode']):r for r in load(CAP/'modes.json')};stock=load(CAP/'capacity.json');capacity_mapping={'profiles':[],'coarse_rectangles':[]}
for axis in [0,1]:
    intervals=[];demands=[];rows=[]
    for o in owners:
        for m in o['modes']:
            source=capacity_sources[(o['identity'][0],m['mode'])]
            for pi,row in enumerate(source['profiles'][axis]):
                it=model.new_optional_fixed_size_interval_var(model.get_int_var_from_proto_index(o['positions'][axis])+row['start'],row['end']-row['start'],model.get_bool_var_from_proto_index(m['selector']),f'capacity_{axis}_{o["owner"]}_{m["mode"]}_{pi}')
                intervals.append(it);demands.append(row['demand']);rows.append({'owner':o['owner'],'mode':m['mode'],'selector':m['selector'],'source_profile':pi,'interval':it.index})
    c=model.add_cumulative(intervals,demands,stock['profile_axis_capacities'][axis]).with_name(f'capacity_axis_{axis}')
    capacity_mapping['profiles'].append({'axis':axis,'intervals':rows,'constraint':c.index,'capacity':stock['profile_axis_capacities'][axis]})
xx=[];yy=[]
for o in owners:
    for m in o['modes']:
        for ri,r in enumerate(capacity_sources[(o['identity'][0],m['mode'])]['coarse_rectangles_grid']):
            intervals=[model.new_optional_fixed_size_interval_var(model.get_int_var_from_proto_index(o['positions'][axis])+r[axis],r[axis+2]-r[axis],model.get_bool_var_from_proto_index(m['selector']),f'coarse_{o["owner"]}_{m["mode"]}_{ri}_{axis}') for axis in [0,1]]
            xx.append(intervals[0]);yy.append(intervals[1]);capacity_mapping['coarse_rectangles'].append({'owner':o['owner'],'mode':m['mode'],'selector':m['selector'],'source_rectangle':ri,'intervals':[it.index for it in intervals]})
capacity_mapping['no_overlap_constraint']=model.add_no_overlap_2d(xx,yy).with_name('coarse_source_occupancy').index
'''
needle='mapping={';assert b.count(needle)==1;b=b.replace(needle,insert+needle)
b=b.replace("'rectangle_gap_grid':23};write", "'rectangle_gap_grid':23,'source_capacity':capacity_mapping};write")
b=b.replace("charges['cp_model_build_seconds']=elapsed", "charges['capacity_complete_preparation_seconds']=load(ROOT/'output/h5-independent-cog-capacity-process-20261107/prepare.json')['complete_seconds'];charges['cp_model_build_seconds']=elapsed")
inputs="ROOT/'output/prepare_h5_independent_cog_capacity_model_helpers_20261107.py',CAP/'plan.json',CAP/'modes.json',CAP/'capacity.json',CAP/'audit/plan.json',CAP/'audit/checks.json',ROOT/'output/h5-independent-cog-capacity-process-20261107/opened.json',ROOT/'output/h5-independent-cog-capacity-process-20261107/prepare.json',"
b=b.replace("inputs=[Path(__file__),", "inputs=[Path(__file__),ROOT/'output/build_h5_independent_twelve_cog_halfplane_model_20261107.py',"+inputs)
b=b.replace('Distinct complete28-mover construction using source-certified lower-bound', 'Distinct complete28-mover construction with exact source-contained global occupancy:1,564 X and552 Y optional profile intervals feed two cumulative constraints;172 optional coarse rectangles feed one NoOverlap2D. Every interval uses its original owner position plus fixed source offsets and exactly its original mode selector; no detached coordinates or capacity-count tables. All full pair geometry is retained. Build directly from source, never consume either closed current model or search. Keep source-certified lower-bound')
b=b.replace("'guarded_region_planes':plane_count,", "'guarded_region_planes':plane_count,'capacity_profile_intervals':[len(r['intervals']) for r in capacity_mapping['profiles']],'coarse_optional_rectangles':len(capacity_mapping['coarse_rectangles']),'global_constraints':3,'source_capacity_added_constraints':2463,")
a=audit.read_text(encoding='utf-8')
a=a.replace('from ortools.sat.python import cp_model', 'from ortools.sat.python import cp_model\nfrom h5_independent_cog_capacity_model_reader_20261107 import inspect as inspect_capacity')
a=a.replace("MODEL=GEOM/'model';OUT=GEOM/'model-audit';PRE=", "CAP=ROOT/'output/h5-independent-cog-capacity-20261107';MODEL=CAP/'model';OUT=CAP/'model-audit';PRE=")
a=a.replace("assert load(BASE/'audit/checks.json')['passed']", "assert load(CAP/'audit/checks.json')['passed'] and load(BASE/'audit/checks.json')['passed']")
a=a.replace("'world_origin_mm','rectangle_gap_grid'}", "'world_origin_mm','rectangle_gap_grid','source_capacity'}")
a=a.replace("for ct in p.constraints:\n", "for ct in p.constraints:\n    if ct.WhichOneof('constraint')!='linear':continue\n")
needle='assert used_vars==set(range(len(p.variables)))';assert needle in a
a=a.replace(needle,"capacity_checks=inspect_capacity(p,mapping['source_capacity'],owners,load(CAP/'modes.json'),load(CAP/'capacity.json'),used_ct,hints)\n"+needle)
a=a.replace("charges['cp_model_build_seconds']=counts['seconds']", "charges['capacity_complete_preparation_seconds']=load(ROOT/'output/h5-independent-cog-capacity-process-20261107/prepare.json')['complete_seconds'];charges['cp_model_build_seconds']=counts['seconds']")
a=a.replace("digest(ROOT/'output/build_h5_independent_twelve_cog_halfplane_model_20261107.py')", "digest(ROOT/'output/build_h5_independent_cog_capacity_model_20261107.py')")
a=a.replace("write(OUT/'source-bindings.json',bindings)","assert not any(name.startswith('output/h5-independent-twelve-cog-halfplanes-20261107/'+prefix) for name in bindings for prefix in ['model/','model-audit/','search/','response-audit/'])\nassert len(p.variables)==28254 and len(p.constraints)==60632 and counts['capacity_profile_intervals']==[1564,552] and counts['coarse_optional_rectangles']==172 and counts['source_capacity_added_constraints']==2463 and counts['global_constraints']==3\nwrite(OUT/'capacity-checks.json',capacity_checks)\nwrite(OUT/'source-bindings.json',bindings)")
a=a.replace("inputs=[Path(__file__),", "inputs=[Path(__file__),ROOT/'output/audit_h5_independent_twelve_cog_halfplane_model_20261107.py',ROOT/'output/h5_independent_cog_capacity_model_reader_20261107.py',"+inputs)
a=a.replace('Read every protobuf field and all variable domains and guarded linear constraints.', 'Read every protobuf field, variable domain and guarded linear constraint. Additionally independently read all2,460 optional affine intervals, two cumulative constraints and one NoOverlap2D constraint. Verify every owner/mode/offset/demand/capacity, all172 coarse rectangle pairs of intervals, and partial cog profile/non-overlap controls. Retain every full geometry check.')
a=a.replace("'passed':True,'seconds':time.perf_counter()-started,", "'passed':True,**capacity_checks,'seconds':time.perf_counter()-started,")
r=(ROOT/'output/run_h5_independent_twelve_cog_halfplane_model_build_20261107.py').read_text(encoding='utf-8').replace('h5-independent-twelve-cog-halfplanes-20261107/model','h5-independent-cog-capacity-20261107/model').replace('h5-independent-twelve-cog-halfplane-model-process-20261107','h5-independent-cog-capacity-model-process-20261107').replace('h5_independent_twelve_cog_halfplane_model_20261107.py','h5_independent_cog_capacity_model_20261107.py')
for name,source in [('build_h5_independent_cog_capacity_model_20261107.py',b),('audit_h5_independent_cog_capacity_model_20261107.py',a),('run_h5_independent_cog_capacity_model_build_20261107.py',r)]:
    ast.parse(source)
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print('Fresh complete capacity builder, full model reader and bounded build runner prepared.')
