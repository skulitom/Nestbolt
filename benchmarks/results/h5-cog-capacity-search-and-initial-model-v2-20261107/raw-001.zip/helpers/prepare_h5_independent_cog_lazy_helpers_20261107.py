"""Prepare a source-only model factory and an independent active-pair reader."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
b=(ROOT/'output/build_h5_independent_cog_capacity_model_20261107.py').read_text(encoding='utf-8')
body=b[b.index('model=cp_model.CpModel()'):b.index('validation=model.validate()')]
body=body.replace("for pi,source in enumerate(load(BASE/'owner-pairs.json')):\n", "for pi,source in enumerate(load(BASE/'owner-pairs.json')):\n    if pi not in active_pairs:continue\n")
body=body.replace("'source_capacity':capacity_mapping};write(OUT/'mapping.json',mapping)", "'source_capacity':capacity_mapping,'active_cog_pairs':sorted(active_pairs)}")
assert 'OUT/' not in body and "'active_cog_pairs'" in body
header='''from pathlib import Path
import json
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-twelve-cog-integer-20261107';GEOM=ROOT/'output/h5-independent-twelve-cog-halfplanes-20261107';CAP=ROOT/'output/h5-independent-cog-capacity-20261107'
load=lambda p:json.loads(p.read_bytes())
'''
factory=header+'''\ndef build(active_pairs):
    assert len(active_pairs)==len(set(active_pairs)) and all(isinstance(i,int) and 0<=i<258 for i in active_pairs)
    active_pairs=set(active_pairs)
'''+''.join('    '+line+'\n' for line in body.splitlines())+'    assert model.validate()==""\n    return model,mapping\n'
a=(ROOT/'output/audit_h5_independent_cog_capacity_model_20261107.py').read_text(encoding='utf-8')
reader=a[a.index("assert {f.name for f,v in p.ListFields()}"):a.index("counts=load(MODEL/'checks.json')")]
reader=reader.replace("mapping=load(MODEL/'mapping.json');",'')
reader=reader.replace("'rectangle_gap_grid','source_capacity'}", "'rectangle_gap_grid','source_capacity','active_cog_pairs'}")
reader=reader.replace("source_pairs=load(BASE/'owner-pairs.json');assert len(pairs)==len(source_pairs)==258", "all_source_pairs=load(BASE/'owner-pairs.json');source_pairs=[all_source_pairs[i] for i in sorted(expected_active)];assert len(pairs)==len(source_pairs)==len(expected_active) and mapping['active_cog_pairs']==sorted(expected_active)")
reader=reader.replace("expected_physical={tuple(sorted((a,b))) for a,b in combinations(range(28),2) if a>=16 or b>=16}", "expected_physical={tuple(sorted(s['owners'])) for s in source_pairs}")
reader=reader.replace('for pi,(r,s) in enumerate(zip(pairs,source_pairs)):', 'for pi,r,s in zip(sorted(expected_active),pairs,source_pairs):')
reader=reader.replace('assert seen_physical==expected_physical and len(expected_physical)==258 and links==2304 and coords==384 and selectors==26538 and planes==53070', '''assert seen_physical==expected_physical and len(expected_physical)==len(expected_active)
assert links==sum(2*len(owners[s['owners'][1]]['modes']) for s in source_pairs if s['kind']=='cog_orthogonal') and coords==2*sum(s['kind']=='cog_orthogonal' for s in source_pairs)
assert selectors==sum(len(templates[cid]['retained_halfplane_ids'])+len(templates[cid]['pockets']) for s in source_pairs for cid in s['classes'])
assert planes==sum(len(templates[cid]['retained_halfplane_ids'])+sum(len(q['retained_edges']) for q in templates[cid]['pockets']) for s in source_pairs for cid in s['classes'])''')
reader=reader.replace('and len(hints)==5646', "and len(hints)==36+sum(len(pair['regions']) for pair in pairs if pair['kind']=='cog_cog')")
reader=reader.replace('and marginals==288', "and marginals==sum(len(s['classes']) for s in source_pairs if s['kind']=='cog_orthogonal')")
assert 'MODEL/' not in reader and 'PRE/' not in reader
# A function-local variable and constraint registry is required for each changed model.
reader=reader.replace('    global max_activity', '    nonlocal max_activity')
audit_header=header+'''from itertools import combinations
from google.protobuf import text_format
from h5_independent_cog_capacity_model_reader_20261107 import inspect as inspect_capacity
MIN=-(2**63)
'''
verify=audit_header+'''\ndef verify(p,mapping,expected_active):
    assert len(expected_active)==len(set(expected_active)) and all(isinstance(i,int) and 0<=i<258 for i in expected_active)
'''+''.join('    '+line+'\n' for line in reader.splitlines())+'''    return {'passed':True,'variables_verified':len(used_vars),'constraints_verified':len(used_ct),'active_cog_pairs_verified':len(expected_active),'active_cog_pair_ids':sorted(expected_active),'world_positions_verified':56,'source_modes_verified':108,'rigid_components_verified':24,'orthogonal_pairs_verified':120,'rigid_links_verified':640,'component_pairs_verified':268,'same_family_orders_verified':25,'canonical_mode_links_verified':links,'class_marginals_verified':marginals,'source_region_selectors_verified':selectors,'source_region_planes_verified':planes,'partial_hint_values_verified':len(hints),'fully_hinted_active_linear_constraints_satisfied':hint_constraints,'all_model_fields_verified':True,'maximum_linear_activity':max_activity,**capacity_checks}
'''
for name,source in [('h5_independent_cog_lazy_model_20261107.py',factory),('h5_independent_cog_lazy_model_reader_20261107.py',verify)]:
    ast.parse(source)
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print('Fresh active-pair factory and full independent reader prepared; no model or solver opened.')
