"""Complete independent source/identity audit after the preserved summary-key error."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-slab10-source-20261028/short12-transfer-preflight';OUT=BASE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');short=load(BASE/'short12.json');assert short==load(ROOT/'output/h5-short-cog-transfer-20261028/result-audit/source12.json');fixed={(r['part_id'],r['copy_index']) for r in short};expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
r=audit(job,short,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],fixed);assert r==load(BASE/'source12-audit.json') and r['valid'] and r['originals']==12
remaining=load(BASE/'remaining54.json');keys=[(p['family'],p['copy_index']) for p in remaining];assert len(keys)==len(set(keys))==54 and set(keys)==expected-fixed;counts=Counter(f for f,i in keys);assert counts=={'frame':18,'bracket':5,'insert':17,'cog':14}
blocks=load(BASE/'first43-blocks.json');recovered=[];sizes=[]
for b in blocks:
    if b['family']=='cog-row':assert b['row_size']==len(b['copy_indices']);sizes.append(b['row_size']);recovered.extend(('cog',i) for i in b['copy_indices'])
    else:recovered.append((b['family'],b['copy_index']))
assert sizes==[5,5,4] and len(blocks)==43 and len(recovered)==54 and len(set(recovered))==54 and set(recovered)==set(keys)
frontier=load(ROOT/'benchmarks/results/h5-seven-bracket-source-and-bound-20261028/updated-allocations.json');matching=[p for p in frontier if p['short_counts']==[7,4,1]];assert len(matching)==1 and matching[0]==load(BASE/'frontier-row.json') and matching[0]['excluded_by'] is None and matching[0]['first_counts']==[18,5,17,14]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.glob('*.json')}});result={'passed':True,'seconds':time.perf_counter()-started,'summary_key_failure_preserved':True,'original_short12_poses_preserved':True,'short_source_originals':12,'short_source_pairs':r['same_sheet_pairs'],'short_source_holes':r['cutouts'],'short_source_hole_vertices':r['hole_vertices'],'short_minimum_pair_gap_mm':r['minimum_pair_gap_mm'],'short_minimum_extra_stock_mm':r['minimum_extra_stock_mm'],'first_counts':dict(counts),'first_originals':54,'first_blocks':43,'row_sizes':sizes,'all66_originals_accounted_once':True,'unchanged_source_stock_and_material_target':True,'existing_nonexcluded_frontier_row':True,'frontier_modified':False,'new_first_sheet_placement':False,'new_packing_model_built':False,'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
