"""Check complete model fields and distinguish partial51 from the full66 target."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_joint39_slab10_cp_reader_20261028 import inspect,violations
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-slab10-source-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,BASE/'geometry-audit-verified',MODEL]:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');sol=load(MODEL/'partial-control-assignment.json');bad=load(MODEL/'negative-assignment.json');built=load(MODEL/'built.json');assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256']
checked,disabled=inspect(p,mp,load(BASE/'blocks39.json'),load(BASE/'modes.json'),load(BASE/'control.json'),load(BASE/'negative.json'),load(MODEL/'partial-hints.json'),sol,bad)
fail=violations(p,sol);assert fail['failed_constraints']==[{'constraint':ix,'kind':'linear'} for ix in disabled] and fail['cover_collisions']==0;write(OUT/'partial-target-rejections.json',fail)
partial=cp_model_pb2.CpModelProto();partial.CopyFrom(p)
for ix in disabled:partial.constraints[ix].linear.domain[:]=[0,0]
valid=evaluate(partial,sol,0);assert valid['expanded_pairs']==310078 and not violations(partial,sol)['failed_constraints'];write(OUT/'partial-control-check.json',valid);(OUT/'partial-control-model.pb').write_bytes(partial.SerializeToString())
for ix in disabled:partial.constraints[ix].linear.domain[:]=[1,1]
assert partial.SerializeToString()==p.SerializeToString()
negative=violations(p,bad);assert {r['constraint'] for r in negative['failed_constraints']}=={mp['no_overlap_2d'],mp['x_cumulative'],mp['y_cumulative']} and negative['cover_collisions']>0;write(OUT/'negative-target-rejections.json',negative)
inputs=[BASE/'plan.json',BASE/'geometry-audit-verified/plan.json',BASE/'geometry-audit-verified/checks.json',MODEL/'plan.json',MODEL/'model.pb',MODEL/'mapping.json',MODEL/'partial-hints.json',MODEL/'partial-control-assignment.json',MODEL/'negative-assignment.json',ROOT/'output/h5_joint39_slab10_cp_reader_20261028.py',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{**checked,'seconds':time.perf_counter()-started,'control_originals':56,'control_rejected_by_exactly10_mandatory_constraints':True,'control_only_presence_changes_verified':True,'control_cover_pairs_checked':310078,'negative_full66_rejected_by_all3_collision_constraints':True,'negative_cover_collisions':negative['cover_collisions'],'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
