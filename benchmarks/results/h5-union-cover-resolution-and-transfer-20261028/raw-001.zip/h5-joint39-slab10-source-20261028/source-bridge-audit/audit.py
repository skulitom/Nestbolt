"""Bind the independently reconstructed original-source controls to model poses."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from h5_joint39_source_bridge_20261028 import reconstruct
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-slab10-source-20261028';OUT=BASE/'source-bridge-audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');cases=[]
for name,filename,valid in [('control','control-source56',True),('negative','negative-source66',False)]:
    rows,error=reconstruct(load(JOB),load(BASE/'blocks39.json'),load(BASE/'modes.json'),load(BASE/(name+'.json')),load(BASE/'short15.json'));saved=load(BASE/(filename+'.json'));assert len(rows)==len(saved);position_error=0
    for a,b in zip(rows,saved):
        assert all(a[k]==b[k] for k in ['part_id','copy_index','sheet_id']);assert a['transform']['rotation_radians']==b['transform']['rotation_radians'] and a['transform']['mirrored']==b['transform']['mirrored'];position_error=max(position_error,max(abs(x-y) for x,y in zip(a['transform']['translation'],b['transform']['translation'])))
    assert position_error<1e-9
    result=audit(load(JOB),rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows]);assert result['valid']==valid and result['stock_failures']==0;write(OUT/(name+'-reconstructed.json'),rows);write(OUT/(name+'-source-checks.json'),result);cases.append({'case':name,'originals':len(rows),'collisions':result['pair_failures'],'valid':valid,'maximum_offset_error_mm':error,'maximum_position_error_mm':position_error})
inputs=[BASE/n for n in ['plan.json','blocks39.json','modes.json','control.json','negative.json','short15.json','control-source56.json','negative-source66.json']]+[JOB,ROOT/'output/h5_joint39_source_bridge_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'cases':cases,'all_saved_controls_bound_to_model_poses':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
