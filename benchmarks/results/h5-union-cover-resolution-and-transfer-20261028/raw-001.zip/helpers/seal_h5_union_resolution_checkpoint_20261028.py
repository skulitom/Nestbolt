"""Seal two closed union-cover trials and the independently revalidated allocation."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
FIRST=ROOT/'output/h5-joint39-union-covers-20261028';BASE=ROOT/'output/h5-joint39-slab10-source-20261028';PUB=BASE/'publication';NAME='h5-union-cover-resolution-and-transfer-20261028';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='b0468c71695a5c1359ff5b2a65a11fda3e981bd1' and not git('diff','HEAD','--name-only')
for folder in [FIRST,BASE]:
    assert all(load(folder/a/'checks.json')['passed'] for a in ['geometry-audit-verified','model-audit','source-bridge-audit','response-audit']);r=load(folder/'search/result.json');assert r['closed'] and r['solver_calls']==1 and r['status']=='UNKNOWN' and not r['has_solution']
axis=load(FIRST/'cover-axis-study/audit/checks.json');assert axis['passed'] and axis['selected']=='vertical10' and axis['variants_independently_verified']==4
transfer=load(BASE/'short12-transfer-preflight/audit/checks.json');assert transfer['passed'] and transfer['all66_originals_accounted_once'] and transfer['first_blocks']==43 and transfer['row_sizes']==[5,5,4]
prior=load(ROOT/'benchmarks/results/h5-joint-sheet-and-union-covers-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main=='75ee537cdd9855c40216eccd5b011817ea91378e';jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6;passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==5 and live==['checks (windows-latest)']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [FIRST,BASE,ROOT/'output/h5-joint39-slab10-helper-generation-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_joint39_union_20261028.py','audit_h5_joint39_union_geometry_20261028.py','prepare_h5_joint39_union_helpers_20261028.py','build_h5_joint39_union_model_20261028.py','h5_joint39_union_cp_reader_20261028.py','audit_h5_joint39_union_model_20261028.py','audit_h5_joint39_union_source_bridge_20261028.py','check_h5_joint39_union_candidate_20261028.py','run_h5_joint39_union_model_20261028.py','audit_h5_joint39_union_response_20261028.py','study_h5_union_cover_axes_20261028.py','audit_h5_union_cover_axes_20261028.py','prepare_h5_slab10_helpers_20261028.py','prepare_h5_joint39_slab10_20261028.py','audit_h5_joint39_slab10_geometry_20261028.py','build_h5_joint39_slab10_model_20261028.py','h5_joint39_slab10_cp_reader_20261028.py','audit_h5_joint39_slab10_model_20261028.py','audit_h5_joint39_slab10_source_bridge_20261028.py','check_h5_joint39_slab10_candidate_20261028.py','run_h5_joint39_slab10_model_20261028.py','audit_h5_joint39_slab10_response_20261028.py','prepare_h5_short12_transfer_preflight_20261028.py','audit_h5_short12_transfer_preflight_20261028.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_union_resolution_archive_20261028.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for folder,prefix in [(FIRST,'union5'),(BASE,'slab10')]:
    for a,b in [('geometry-audit-verified/checks.json','geometry-audit.json'),('model-audit/checks.json','model-audit.json'),('source-bridge-audit/checks.json','source-bridge-audit.json'),('response-audit/checks.json','response-audit.json'),('search/result.json','search-result.json')]:shutil.copyfile(folder/a,OUT/(prefix+'-'+b))
shutil.copyfile(FIRST/'cover-axis-study/audit/checks.json',OUT/'axis-study-audit.json');shutil.copyfile(BASE/'short12-transfer-preflight/audit/checks.json',OUT/'transfer-preflight-audit.json');shutil.copyfile(BASE/'short12-transfer-preflight/first43-blocks.json',OUT/'next-first43-blocks.json');shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'queued_prior_checkpoint':head,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'main_CI':40764537562,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':(BASE/'next-step-text.txt').read_text(encoding='utf-8'),'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'independent_audit_groups':10,'closed_packing_sequences':2,'solver_calls':2,'complete_candidates':0,'source_valid66_count':0,'geometry_variants_verified':4,'all39_blocks_mandatory_in_both_models':True,'short12_transfer_originals_accounted':66,'next_first_sheet_originals':54,'next_first_sheet_blocks':43,'next_first_sheet_layout_or_model_created':False,'valid64_preserved':True,'remaining_necessary_allocations':444,'actual_or_global_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 union-cover resolution and allocation transfer, 2026-10-28:** [the evidence]({link})
preserves two closed complete39-block trials, both UNKNOWN with no candidate.
All model fields and original controls pass independent audits. A frozen
four-variant geometry comparison selects10mm vertical slabs (253 rectangles
per row versus523); search begins3.16s instead of18.87s. Both60s algorithm
budgets and their0.048065s/0.026304s overruns remain recorded. No full66 or
native claim follows. The next preflight revalidates the existing short12
(7brackets4inserts1cog), keeping the material target and all66 identities.
It leaves54 first-sheet originals and a prospective43-block5/5/4-cog-row model;
no such placement or model is created yet. All failed controls and the corrected
summary-key error are preserved. Main75ee537c remains unchanged; prior local
checkpointb0468c71 and this checkpoint wait for CI40764537562 (five passes,
Windows checks live). Production/READMEs, valid64,444 necessary allocations,
originalH2 gate and22 unopened vectors stay unchanged. H2/H5 open at60%; no
new release qualifies.
'''
for a,b in [('complete39','complete 39'),('selects10mm','selects 10 mm'),('versus523','versus 523'),('begins3.16s instead of18.87s','begins at 3.16 s instead of 18.87 s'),('Both60s','Both 60 s'),('their0.048065s/0.026304s','their 0.048065 s / 0.026304 s'),('full66','full 66'),('short12','short 12'),('7brackets4inserts1cog','7 brackets, 4 inserts, 1 cog'),('all66','all 66'),('leaves54','leaves 54'),('prospective43-block5/5/4-cog-row','prospective 43-block model with cog rows of 5/5/4'),('Main75','Main 75'),('checkpointb046','checkpoint b046'),('CI407','CI 407'),('valid64,444','valid 64, 444'),('originalH2','original H2'),('and22','and 22'),('at60%','at 60%')]:note=note.replace(a,b)
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
