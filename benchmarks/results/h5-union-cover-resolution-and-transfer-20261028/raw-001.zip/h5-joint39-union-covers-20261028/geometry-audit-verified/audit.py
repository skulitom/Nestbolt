"""Independently verify original clearance, stock envelope, partition and controls."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-union-covers-20261028';OUT=BASE/'geometry-audit-verified';OLD=ROOT/'output/h5-joint39-row-covers-20261028';STUDY=OLD/'union-cover-study-verified';CORE=ROOT/'output/h5-mixed26-height-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
assert load(STUDY/'audit/checks.json')['passed'] and not plan['old_hull_height_certificate_applies'] and not plan['common_line_part_in_hole']
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');blocks=load(BASE/'blocks39.json');short=load(BASE/'short15.json');oldmodes=load(CORE/'modes.json');assert modes==load(STUDY/'modes.json') and blocks==load(OLD/'blocks39.json') and short==load(OLD/'short15.json')
assert len(modes)==13 and Counter(m['family'] for m in modes)=={'frame':2,'bracket':8,'insert':2,'cog-row':1}
keys=[(r['part_id'],r['copy_index']) for r in short]
for b in blocks:keys += [('cog',i) for i in b['copy_indices']] if b['family']=='cog-row' else [(b['family'],b['copy_index'])]
assert len(keys)==len(set(keys))==66 and set(keys)=={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
radius=plan['required_source_gap_mm']/2/math.cos(math.pi/64)+1e-7;mode_checks=[];pairs=0
for m in modes:
    rects=m['cover_rectangles_um'];cover=unary_union([box(a/1000,b/1000,c/1000,d/1000) for a,b,c,d in rects]);sources=[]
    instances=m['source_instances'] if m['family']=='cog-row' else [{'part_id':m['family'],'angle':m['angle'],'mirrored':m['mirrored'],'translation':m['source_translation_offset']}]
    for r in instances:
        p=parts[r['part_id']];c,s=math.cos(r['angle']),math.sin(r['angle']);sign=-1 if r['mirrored'] else 1;ox,oy=r['translation'];g=Polygon([(sign*x*c-y*s+ox,sign*x*s+y*c+oy) for x,y in p['geometry'][0]['outer']]);assert cover.covers(g.buffer(radius,quad_segs=16));sources.append(g)
    source=unary_union(sources);assert max(abs(a-b) for a,b in zip(source.bounds,m['source_bounds_mm']))<1e-9
    if m['family']!='cog-row':
        old=oldmodes[m['old_mode']];assert rects==old['expanded_rectangles_um'] and (m['family'],m['quarter'],m['mirrored'])==(old['family'],old['quarter'],old['mirrored'])
    for a,b in combinations(rects,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];pairs+=1
    sb,cb=source.bounds,cover.bounds;overhang=[sb[0]-cb[0],sb[1]-cb[1],cb[2]-sb[2],cb[3]-sb[3]];assert max(overhang)<=.114
    for axis in [0,1]:
        low=math.ceil(6513-m['source_bounds_mm'][axis]*1000);high=math.floor([1493487,2993487][axis]-m['source_bounds_mm'][axis+2]*1000);assert low+min(r[axis] for r in rects)>=6399 and high+max(r[axis+2] for r in rects)<=[1493601,2993601][axis]
    mode_checks.append({'mode':m['id'],'source_originals':len(sources),'cover_components':len(rects),'max_overhang_mm':max(overhang),'required_clearance_discs_covered':True})
write(OUT/'mode-checks.json',mode_checks);cases=[]
for name,valid,count in [('control-source56',True,56),('negative-source66',False,66)]:
    rows=load(BASE/(name+'.json'));r=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows]);assert r['valid']==valid and len(rows)==count and not r['stock_failures'];write(OUT/(name+'.json'),r);cases.append({'name':name,'originals':count,'pairs':r['same_sheet_pairs'],'collisions':r['pair_failures'],'holes':r['cutouts'],'hole_vertices':r['hole_vertices']})
control=load(BASE/'control.json');rectangles=[]
for p in control:
    m=modes[p['mode']];x,y=p['anchor_um'];rectangles += [[a+x,b+y,c+x,d+y] for a,b,c,d in m['cover_rectangles_um']]
for a,b in combinations(rectangles,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
assert len(control)==29 and len(rectangles)==1598
area=sum(sum((c-a)*(d-b) for a,b,c,d in next(m for m in modes if m['family']==block['family'])['cover_rectangles_um']) for block in blocks);assert area==4112088300216
write(OUT/'necessary-area.json',{'cover_area_um2':area,'cover_envelope_area_um2':1487202*2987202,'slack_um2':1487202*2987202-area,'necessary_condition_passes':area<=1487202*2987202,'no_feasibility_claim':True,'old_hull_section_bound_used':False})
inputs=[BASE/n for n in ['plan.json','modes.json','blocks39.json','short15.json','control.json','control-source56.json','negative.json','negative-source66.json']]+[CORE/'modes.json',STUDY/'audit/plan.json',STUDY/'audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'modes_verified':len(modes),'same_owner_rectangle_pairs':pairs,'source_stock_and_cover_envelope_verified':True,'cover_bounds_um':plan['cover_bounds_um'],'x_capacity_um':2987202,'y_capacity_um':1487202,'all66_originals_accounted_once':True,'positive_control_originals':56,'control_blocks':29,'control_cover_components':1598,'control_cover_pairs':len(rectangles)*(len(rectangles)-1)//2,'control_missing_originals':10,'control_missing_blocks':10,'negative_control_originals':66,'source_cases':cases,'necessary_area_slack_mm2':(1487202*2987202-area)/1e6,'old_hull_section_certificate_not_reused':True,'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
