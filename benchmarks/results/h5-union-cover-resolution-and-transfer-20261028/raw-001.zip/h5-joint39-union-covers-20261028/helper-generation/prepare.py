"""Copy audited helper structure to new paths; preserve all closed-trial helpers."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-union-covers-20261028';OUT=BASE/'helper-generation';OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');digest=lambda p:sha256(p.read_bytes()).hexdigest();records=[]
jobs=[
 ('build_h5_joint39_model_20261028.py','build_h5_joint39_union_model_20261028.py',{}),
 ('h5_joint39_cp_reader_20261028.py','h5_joint39_union_cp_reader_20261028.py',{'len(disabled)==11':'len(disabled)==10'}),
 ('audit_h5_joint39_model_20261028.py','audit_h5_joint39_union_model_20261028.py',{'10440':'1276003',"'control_originals':51":"'control_originals':56",'exactly11':'exactly10'}),
 ('audit_h5_joint39_source_bridge_20261028.py','audit_h5_joint39_union_source_bridge_20261028.py',{}),
 ('check_h5_joint39_candidate_20261028.py','check_h5_joint39_union_candidate_20261028.py',{}),
 ('run_h5_joint39_model_20261028.py','run_h5_joint39_union_model_20261028.py',{}),
 ('audit_h5_joint39_response_20261028.py','audit_h5_joint39_union_response_20261028.py',{'23220':'1296855',"'cover_components_per_complete_assignment':216":"'cover_components_per_complete_assignment':1611"})]
common={'h5-joint39-row-covers-20261028':'h5-joint39-union-covers-20261028','control-source51':'control-source56','h5_joint39_cp_reader_20261028':'h5_joint39_union_cp_reader_20261028','check_h5_joint39_candidate_20261028':'check_h5_joint39_union_candidate_20261028'}
for old,new,changes in jobs:
    p=ROOT/'output'/old;q=ROOT/'output'/new;source=p.read_text(encoding='utf-8');original=digest(p);applied={}
    for a,b in common.items():
        if a in source:applied[a]=b;source=source.replace(a,b)
    for a,b in changes.items():assert a in source,(old,a);applied[a]=b;source=source.replace(a,b)
    with q.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
    assert digest(p)==original;records.append({'original':p.relative_to(ROOT).as_posix(),'original_sha256':original,'new':q.relative_to(ROOT).as_posix(),'new_sha256':digest(q),'replacements':applied})
with (OUT/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'inputs':{r['original']:r['original_sha256'] for r in records},'closed_trial_helpers_unchanged':True,'solver_calls':0},f,indent=2);f.write('\n')
with (OUT/'generated.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(records,f,indent=2);f.write('\n')
print({'new_helpers':len(records),'closed_helpers_preserved':True})
