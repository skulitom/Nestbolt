"""Mandatory whole-first-sheet blocks with complete cover separation in every mode."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-union-covers-20261028';OUT=BASE/'model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter();ga=load(BASE/'geometry-audit-verified/checks.json');assert ga['passed']
for n,h in load(BASE/'geometry-audit-verified/plan.json')['inputs'].items():assert digest(ROOT/n)==h
modes=load(BASE/'modes.json');blocks=load(BASE/'blocks39.json');control={p['block']:p for p in load(BASE/'control.json')};negative={p['block']:p for p in load(BASE/'negative.json')};model=cp_model.CpModel();items=[];allx=[];ally=[];widths=[];heights=[];hints={};values={};badvalues={}
for i,block in enumerate(blocks):
    present=model.new_bool_var(f'present_{i}');mandatory=model.add(present==1);x=model.new_int_var(0,1500000,f'x_{i}');y=model.new_int_var(0,3000000,f'y_{i}');options=[];known=control.get(i);hints[present.index]=1
    values[present.index]=int(known is not None);values[x.index],values[y.index]=known['anchor_um'] if known else [0,0];badvalues[present.index]=1;badvalues[x.index],badvalues[y.index]=negative[i]['anchor_um']
    if known:hints[x.index],hints[y.index]=known['anchor_um']
    for m in [m for m in modes if m['family']==block['family']]:
        mi=m['id'];select=model.new_bool_var(f'mode_{i}_{mi}');a,b,c,d=m['source_bounds_mm'];xc=model.add_linear_constraint(x,math.ceil(6513-a*1000),math.floor(1493487-c*1000));xc.only_enforce_if(select);yc=model.add_linear_constraint(y,math.ceil(6513-b*1000),math.floor(2993487-d*1000));yc.only_enforce_if(select);components=[]
        for k,(a,b,c,d) in enumerate(m['cover_rectangles_um']):
            ix=model.new_optional_fixed_size_interval_var(x+a,c-a,select,f'cover_x_{i}_{mi}_{k}');iy=model.new_optional_fixed_size_interval_var(y+b,d-b,select,f'cover_y_{i}_{mi}_{k}');components.append({'component':k,'x_interval':ix.index,'y_interval':iy.index});allx.append(ix.index);ally.append(iy.index);widths.append(c-a);heights.append(d-b)
        options.append({'mode':mi,'selector':select.index,'x_bound':xc.index,'y_bound':yc.index,'components':components});values[select.index]=int(known is not None and known['mode']==mi);badvalues[select.index]=int(negative[i]['mode']==mi)
        if known:hints[select.index]=int(known['mode']==mi)
    choice=model.add(sum(model.get_int_var_from_proto_index(o['selector']) for o in options)==present)
    items.append({'index':i,'source_block':block,'presence':present.index,'mandatory':mandatory.index,'x':x.index,'y':y.index,'options':options,'choice':choice.index})
xints=[model.get_interval_var_from_proto_index(i) for i in allx];yints=[model.get_interval_var_from_proto_index(i) for i in ally];no=model.add_no_overlap_2d(xints,yints);xc=model.add_cumulative(xints,heights,ga['x_capacity_um']);yc=model.add_cumulative(yints,widths,ga['y_capacity_um']);orders=[]
for family in ['bracket','frame','insert','cog-row']:
    group=[p for p in items if p['source_block']['family']==family];axis='y' if family=='cog-row' else 'x'
    for a,b in zip(group,group[1:]):
        ct=model.add(model.get_int_var_from_proto_index(a[axis])<=model.get_int_var_from_proto_index(b[axis]));ct.only_enforce_if([model.get_int_var_from_proto_index(a['presence']),model.get_int_var_from_proto_index(b['presence'])]);orders.append({'left':a['index'],'right':b['index'],'axis':axis,'constraint':ct.index})
for ix,v in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(ix),v)
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'items':items,'no_overlap_2d':no.index,'x_cumulative':xc.index,'y_cumulative':yc.index,'x_capacity_um':ga['x_capacity_um'],'y_capacity_um':ga['y_capacity_um'],'orders':orders,'control_disabled_mandatory_constraints':[p['mandatory'] for p in items if p['index'] not in control]})
write(OUT/'partial-control-assignment.json',[values[i] for i in range(len(model.proto.variables))]);write(OUT/'negative-assignment.json',[badvalues[i] for i in range(len(model.proto.variables))]);write(OUT/'partial-hints.json',{str(k):v for k,v in hints.items()})
inputs=[BASE/n for n in ['plan.json','modes.json','blocks39.json','short15.json','control.json','control-source56.json','negative.json','negative-source66.json','geometry-audit-verified/plan.json','geometry-audit-verified/checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0})
write(OUT/'built.json',{'seconds':time.perf_counter()-started,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'independent_anchor_coordinates':78,'mandatory_blocks':39,'target_originals':66,'mode_options':sum(len(p['options']) for p in items),'component_options':len(allx),'symmetry_orders':len(orders),'partial_hints':len(hints),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
