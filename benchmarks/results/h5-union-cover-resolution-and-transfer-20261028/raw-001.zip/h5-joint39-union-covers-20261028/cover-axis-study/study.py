"""Four frozen geometry-only slab alternatives; no packing or solver retries."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import shape,mapping
from shapely.affinity import affine_transform
from h5_outer_cover_geometry_20261028 import slab_cover,rectangle_union
from h5_joint39_source_bridge_20261028 import reconstruct
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-union-covers-20261028';SOURCE=ROOT/'output/h5-joint39-row-covers-20261028/union-cover-study-verified';OUT=BASE/'cover-axis-study';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'study.py');started=time.perf_counter();assert load(BASE/'search/result.json')['closed'] and load(BASE/'response-audit/checks.json')['passed']
variants=[{'name':'vertical10','axis':'x','slab_um':10000},{'name':'vertical20','axis':'x','slab_um':20000},{'name':'horizontal5','axis':'y','slab_um':5000},{'name':'horizontal10','axis':'y','slab_um':10000}]
inputs=[JOB,BASE/'plan.json',BASE/'modes.json',BASE/'blocks39.json',BASE/'short15.json',BASE/'control.json',BASE/'response-audit/plan.json',BASE/'response-audit/checks.json',SOURCE/'row-geometry.json',SOURCE/'audit/checks.json',ROOT/'output/h5_outer_cover_geometry_20261028.py',ROOT/'output/h5_joint39_source_bridge_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'variants':variants,'maximum_variants':4,'selection_policy':'Among variants whose complete56 source control and all control-cover pairs pass, whose source expansion is fully covered, and whose added cover area per row is at most20000mm2 relative to the audited5mm vertical union cover, choose the fewest cover rectangles; break ties by smaller area then fixed listed order. If none qualify do not select a fallback or extend this study.','maximum_added_area_per_row_mm2':20000,'row_x_offsets_um':[0,80000,0],'row_base_anchor_um':[6700,2160000],'row_y_separation_method':'exact maximum upper-minus-lower bound over every pair with intersecting X interiors for both adjacent X displacements; also enforce the nonadjacent zero-X bound; add1um.','geometry_only':True,'packing_solver_calls':0,'retry_permitted':False})
expanded=shape(load(SOURCE/'row-geometry.json')['expanded_union']);oldmodes=load(BASE/'modes.json');oldarea=sum((c-a)*(d-b) for a,b,c,d in oldmodes[-1]['cover_rectangles_um']);blocks=load(BASE/'blocks39.json');job=load(JOB);baseplan=load(BASE/'plan.json');results=[]
for variant in variants:
    folder=OUT/variant['name'];folder.mkdir();g=expanded if variant['axis']=='x' else affine_transform(expanded,[0,1,1,0,0,0]);raw,slabs=slab_cover(g,variant['slab_um']);rects=raw if variant['axis']=='x' else [[b,a,d,c] for a,b,c,d in raw];cover=rectangle_union(rects);assert cover.covers(expanded)
    def separation(dx):return max(a[3]-b[1] for a in rects for b in rects if a[0]<b[2]+dx and b[0]+dx<a[2])
    sep={str(dx):separation(dx) for dx in [80000,-80000,0]};dy=max(sep['80000'],sep['-80000'],(sep['0']+1)//2)+1;modes=oldmodes[:-1]+[{**oldmodes[-1],'cover_rectangles_um':rects}];control=[p for p in load(BASE/'control.json') if blocks[p['block']]['family']!='cog-row']
    for i,x,y in zip([i for i,b in enumerate(blocks) if b['family']=='cog-row'],[6700,86700,6700],[2160000,2160000+dy,2160000+2*dy]):control.append({'block':i,'mode':modes[-1]['id'],'anchor_um':[x,y]})
    rows,error=reconstruct(job,blocks,modes,control,load(BASE/'short15.json'));source=audit(job,rows,baseplan['source_stocks'],baseplan['required_source_gap_mm'],baseplan['native_stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows]);allrects=[]
    for p in control:
        x,y=p['anchor_um'];allrects.extend([[a+x,b+y,c+x,d+y] for a,b,c,d in modes[p['mode']]['cover_rectangles_um']])
    collisions=sum(not(a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]) for a,b in combinations(allrects,2));area=sum((c-a)*(d-b) for a,b,c,d in rects);eligible=source['valid'] and collisions==0 and area-oldarea<=20000000000
    write(folder/'modes.json',modes);write(folder/'row-geometry.json',{'cover':mapping(cover),'rectangles_um':rects,'slabs_in_sweep_coordinates':slabs});write(folder/'control29.json',control);write(folder/'source56.json',rows);write(folder/'source56-audit.json',source);write(folder/'separation.json',{'needed_um':sep,'chosen_dy_um':dy,'control_cover_pairs':len(allrects)*(len(allrects)-1)//2,'control_cover_collisions':collisions})
    r={**variant,'rectangles_per_row':len(rects),'cover_area_per_row_mm2':area/1e6,'added_area_per_row_mm2':(area-oldarea)/1e6,'control_row_dy_mm':dy/1000,'source56_valid':source['valid'],'source_collisions':source['pair_failures'],'source_stock_failures':source['stock_failures'],'control_cover_collisions':collisions,'eligible_by_frozen_policy':eligible,'solver_calls':0};write(folder/'result.json',r);results.append(r)
eligible=[r for r in results if r['eligible_by_frozen_policy']];selected=min(eligible,key=lambda r:(r['rectangles_per_row'],r['cover_area_per_row_mm2'],[v['name'] for v in variants].index(r['name'])))['name'] if eligible else None
write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-started,'variants':results,'selected':selected,'independently_audited':False,'new_packing_model_built':False,'packing_solver_calls':0,'source_full66_verified':False,'H5_complete':False});print(load(OUT/'result.json'))
