"""Independent source expansion, disjoint rectangles, controls and frozen selection."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,box,shape
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-joint39-union-covers-20261028';STUDY=BASE/'cover-axis-study';OUT=STUDY/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(STUDY/'plan.json');result=load(STUDY/'result.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
expected=[('vertical10','x',10000),('vertical20','x',20000),('horizontal5','y',5000),('horizontal10','y',10000)];assert [(v['name'],v['axis'],v['slab_um']) for v in plan['variants']]==expected and plan['maximum_variants']==4 and plan['maximum_added_area_per_row_mm2']==20000 and result['closed']
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='cog');oldmodes=load(BASE/'modes.json');oldarea=sum((c-a)*(d-b) for a,b,c,d in oldmodes[-1]['cover_rectangles_um']);blocks=load(BASE/'blocks39.json');baseplan=load(BASE/'plan.json');radius=baseplan['required_source_gap_mm']/2/math.cos(math.pi/64)+1e-7;hulls=[];polys=[]
for r in oldmodes[-1]['source_instances']:
    c,s=math.cos(r['angle']),math.sin(r['angle']);x,y=r['translation'];g=Polygon([(c*a-s*b+x,s*a+c*b+y) for a,b in part['geometry'][0]['outer']]);polys.append(g);triangles=list(shapely.constrained_delaunay_triangles(g).geoms);assert unary_union(triangles).equals(g)
    for t in triangles:hulls.append(MultiPoint([(x+dx,y+dy) for x,y in list(t.exterior.coords)[:-1] for dx in [-.112,.112] for dy in [-.112,.112]]).convex_hull)
assert len(hulls)==390;checks=[]
for name,axis,step in expected:
    folder=STUDY/name;modes=load(folder/'modes.json');assert modes[:-1]==oldmodes[:-1];m=dict(modes[-1]);rects=m.pop('cover_rectangles_um');om=dict(oldmodes[-1]);om.pop('cover_rectangles_um');assert m==om
    cover=unary_union([box(a/1000,b/1000,c/1000,d/1000) for a,b,c,d in rects]);assert cover.equals(shape(load(folder/'row-geometry.json')['cover']))
    for g in polys:assert cover.covers(g.buffer(radius,quad_segs=16))
    for h in hulls:assert cover.covers(h)
    for a,b in combinations(rects,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
    source_bounds=m['source_bounds_mm'];cover_bounds=cover.bounds
    for k in [0,1]:assert source_bounds[k]-cover_bounds[k]<=.114 and cover_bounds[k+2]-source_bounds[k+2]<=.114
    proof=load(folder/'separation.json');needed={}
    for dx in [80000,-80000,0]:needed[str(dx)]=max(a[3]-b[1] for a in rects for b in rects if max(a[0],b[0]+dx)<min(a[2],b[2]+dx))
    assert needed==proof['needed_um'];dy=max(needed['80000'],needed['-80000'],(needed['0']+1)//2)+1;assert dy==proof['chosen_dy_um']
    control=load(folder/'control29.json');rows=load(folder/'source56.json');allrects=[];rowposes=[]
    for p in control:
        b=blocks[p['block']];mode=modes[p['mode']];x,y=p['anchor_um'];allrects.extend([[a+x,b+y,c+x,d+y] for a,b,c,d in mode['cover_rectangles_um']]);specs=mode['source_instances'] if b['family']=='cog-row' else [{'part_id':b['family'],'angle':mode['angle'],'mirrored':mode['mirrored'],'translation':mode['source_translation_offset']}];copies=b['copy_indices'] if b['family']=='cog-row' else [b['copy_index']]
        if b['family']=='cog-row':rowposes.append(p['anchor_um'])
        for r,copy in zip(specs,copies):
            saved=next(v for v in rows if v['part_id']==r['part_id'] and v['copy_index']==copy);assert saved['sheet_id']=='sheet-0' and saved['transform']['rotation_radians']==r['angle'] and saved['transform']['mirrored']==r['mirrored'] and max(abs(a-b) for a,b in zip(saved['transform']['translation'],[x/1000+r['translation'][0],y/1000+r['translation'][1]]))<1e-9
    assert rowposes==[[6700,2160000],[86700,2160000+dy],[6700,2160000+2*dy]]
    collision=sum(not(a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]) for a,b in combinations(allrects,2));assert collision==proof['control_cover_collisions'] and len(allrects)*(len(allrects)-1)//2==proof['control_cover_pairs']
    source=audit(job,rows,baseplan['source_stocks'],baseplan['required_source_gap_mm'],baseplan['native_stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows]);assert source==load(folder/'source56-audit.json') and len(rows)==56 and source['cutouts']==74 and source['hole_vertices']==8074
    area=sum((c-a)*(d-b) for a,b,c,d in rects);r=load(folder/'result.json');eligible=source['valid'] and collision==0 and area-oldarea<=20000000000
    assert r==next(v for v in result['variants'] if v['name']==name) and r['rectangles_per_row']==len(rects) and r['cover_area_per_row_mm2']==area/1e6 and r['added_area_per_row_mm2']==(area-oldarea)/1e6 and r['eligible_by_frozen_policy']==eligible
    checks.append({'name':name,'rectangles_per_row':len(rects),'cover_area_per_row_mm2':area/1e6,'added_area_per_row_mm2':(area-oldarea)/1e6,'source56_valid':source['valid'],'source_collisions':source['pair_failures'],'source_stock_failures':source['stock_failures'],'cover_collisions':collision,'control_cover_components':len(allrects),'control_cover_pairs':proof['control_cover_pairs'],'eligible':eligible,'row_dy_mm':dy/1000})
eligible=[r for r in checks if r['eligible']];selected=min(eligible,key=lambda r:(r['rectangles_per_row'],r['cover_area_per_row_mm2'],[v[0] for v in expected].index(r['name'])))['name'] if eligible else None;assert selected==result['selected']
inputs=[STUDY/'plan.json',STUDY/'result.json']+[p for name,axis,step in expected for p in (STUDY/name).glob('*.json')];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'variants_independently_verified':len(checks),'triangle_square_hulls_per_variant':390,'required_clearance_and_stock_envelope_verified':True,'same_owner_partitions_verified':True,'variants':checks,'selected':selected,'selection_matches_frozen_policy':True,'packing_solver_calls':0,'source_full66_verified':False,'H5_complete':False});print(load(OUT/'checks.json'))
