"""Create a separately frozen10mm model from the independently selected geometry."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-joint39-slab10-helper-generation-20261028';OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');digest=lambda p:sha256(p.read_bytes()).hexdigest();records=[]
jobs=[('prepare_h5_joint39_union_20261028.py','prepare_h5_joint39_slab10_20261028.py','prepare'),('audit_h5_joint39_union_geometry_20261028.py','audit_h5_joint39_slab10_geometry_20261028.py','geometry'),('build_h5_joint39_union_model_20261028.py','build_h5_joint39_slab10_model_20261028.py','build'),('h5_joint39_union_cp_reader_20261028.py','h5_joint39_slab10_cp_reader_20261028.py','reader'),('audit_h5_joint39_union_model_20261028.py','audit_h5_joint39_slab10_model_20261028.py','model-audit'),('audit_h5_joint39_union_source_bridge_20261028.py','audit_h5_joint39_slab10_source_bridge_20261028.py','bridge'),('check_h5_joint39_union_candidate_20261028.py','check_h5_joint39_slab10_candidate_20261028.py','candidate'),('run_h5_joint39_union_model_20261028.py','run_h5_joint39_slab10_model_20261028.py','run'),('audit_h5_joint39_union_response_20261028.py','audit_h5_joint39_slab10_response_20261028.py','response')]
common={'h5-joint39-union-covers-20261028':'h5-joint39-slab10-source-20261028','h5_joint39_union_cp_reader_20261028':'h5_joint39_slab10_cp_reader_20261028','check_h5_joint39_union_candidate_20261028':'check_h5_joint39_slab10_candidate_20261028'}
for old,new,kind in jobs:
    p=ROOT/'output'/old;q=ROOT/'output'/new;source=p.read_text(encoding='utf-8');oldhash=digest(p);changes={}
    for a,b in common.items():
        if a in source:changes[a]=b;source=source.replace(a,b)
    special={}
    if kind in ['prepare','geometry']:
        special.update({'h5-joint39-row-covers-20261028':'h5-joint39-union-covers-20261028',"STUDY=OLD/'union-cover-study-verified'":"STUDY=OLD/'cover-axis-study/vertical10'","STUDY/'audit/checks.json'":"STUDY.parent/'audit/checks.json'","STUDY/'audit/plan.json'":"STUDY.parent/'audit/plan.json'"})
    if kind=='prepare':
        special.update({"STUDY/'plan.json'":"STUDY.parent/'plan.json'","STUDY/'row-separation.json'":"STUDY/'separation.json'","STUDY/'prepared.json'":"STUDY/'result.json'",'distinct from the closed hull-cover search':'distinct from the closed5mm union-cover search','Five-millimetre slabs':'Ten-millimetre slabs',"'old_hull_search_closed':True":"'old_union_search_closed':True", "'union_cover_rectangles_per_row':523":"'union_cover_rectangles_per_row':253", "'row_cover_components':523":"'row_cover_components':253"})
        source=source.replace("assert load(OLD/'search/result.json')['closed']", "assert load(STUDY.parent/'audit/checks.json')['selected']=='vertical10' and load(OLD/'search/result.json')['closed']")
    if kind=='geometry':special.update({'len(rectangles)==1598':'len(rectangles)==788','area==4112088300216':'area==4149001503696',"'control_cover_components':1598":"'control_cover_components':788"})
    if kind=='model-audit':special.update({'1276003':'310078'})
    if kind=='response':special.update({'1296855':'320400',"'cover_components_per_complete_assignment':1611":"'cover_components_per_complete_assignment':801"})
    for a,b in special.items():assert a in source,(old,a);changes[a]=b;source=source.replace(a,b)
    with q.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
    assert digest(p)==oldhash;records.append({'original':p.relative_to(ROOT).as_posix(),'original_sha256':oldhash,'new':q.relative_to(ROOT).as_posix(),'new_sha256':digest(q),'replacements':changes})
with (OUT/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'inputs':{r['original']:r['original_sha256'] for r in records},'closed_helpers_preserved':True,'solver_calls':0},f,indent=2);f.write('\n')
with (OUT/'generated.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(records,f,indent=2);f.write('\n')
print({'new_helpers':len(records),'closed_helpers_preserved':True})
