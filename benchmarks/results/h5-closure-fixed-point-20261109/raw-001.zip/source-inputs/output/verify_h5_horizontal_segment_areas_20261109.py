"""Exhaustive unit-cell oracle and real-source certified controls for interval tree."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_horizontal_segment_areas_20261109 import horizontal_segment_areas

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-horizontal-segment-area-controls-20261109'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,value):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter()
PARENT=ROOT/'output/h5-fixed29-conditional-frontier-20261108';COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108'
assert load(PARENT/'audit/checks.json')['passed']
inputs=[Path(__file__),ROOT/'output/h5_horizontal_segment_areas_20261109.py',PARENT/'audit/checks.json',PARENT/'audit/plan.json',PARENT/'audit/case-results.json']
for index in [1,9,21]:inputs.extend([PARENT/f'choice-{index:02d}-frontier.json',COVER/f'choice-{index:02d}-regions.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'All4096 subsets of12 labelled overlapping/nested/touching rectangles (four per category), independently enumerated as exact unit-cell sets. Repeat after negative translation and integer scaling to test signed coordinates and exact area scaling. Check duplicate rectangle multiplicity, empty groups and fully occupied fixed regions. Then read all three previously independently audited full-source global bounds, including the excluded choice21; no new scope is opened. The interval tree sweeps horizontal events and is distinct from the producer vertical prefix arrays.','process_cap_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
rectangles=[(0,0,6,6),(1,1,3,5),(3,0,6,3),(2,2,5,5),(0,3,4,6),(2,1,6,4),(0,0,2,3),(4,0,6,6),(1,0,5,2),(0,2,3,6),(3,2,6,6),(2,2,4,4)]
pixels=[{(x,y) for x in range(r[0],r[2]) for y in range(r[1],r[3])} for r in rectangles]
for mask in range(4096):
    groups=[[],[],[]];sets=[set(),set(),set()]
    for i,rectangle in enumerate(rectangles):
        if mask>>i&1:groups[i//4].append(rectangle);sets[i//4].update(pixels[i])
    expected=[len(sets[0]-sets[2]),len(sets[1]-sets[2]),len((sets[0]|sets[1])-sets[2])]
    assert horizontal_segment_areas(*groups)==expected,mask
    shifted=[[[3*r[k]+(-100003 if k%2==0 else 200009) for k in range(4)] for r in rows] for rows in groups]
    assert horizontal_segment_areas(*shifted)==[9*x for x in expected],mask
assert horizontal_segment_areas([rectangles[0]]*3,[rectangles[0]]*2,[rectangles[1]]*4)==[28,28,28]
real=[]
for row in load(PARENT/'audit/case-results.json'):
    index=row['refinement_index'];regions=load(PARENT/f'choice-{index:02d}-frontier.json')['family_component_regions_um'];fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um']
    result=horizontal_segment_areas(regions['bracket'],regions['insert'],fixed)
    assert result==[row['family_area_upper_um2']['bracket'],row['family_area_upper_um2']['insert'],row['joint_area_upper_um2']]
    real.append({'refinement_index':index,'areas_um2':result});print(real[-1],flush=True)
write(OUT/'real-source-controls.json',real)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'exhaustive_unit_cell_cases':4096,'translated_scaled_cases':4096,'duplicate_multiplicity_control':True,'real_source_area_bounds':9,'all_source_bounds_match_prior_independent_horizontal_merge_audits':True,'optimizer_calls':0})
print(load(OUT/'checks.json'))
