"""Exact horizontal event sweep with an independently maintained interval tree."""

def horizontal_segment_areas(brackets,inserts,fixed):
    groups=[brackets,inserts,fixed]
    xs=sorted({r[k] for rows in groups for r in rows for k in (0,2)})
    if not xs:return [0,0,0]
    positions={x:i for i,x in enumerate(xs)};events={}
    for kind,rows in enumerate(groups):
        for left,bottom,right,top in rows:
            assert left<right and bottom<top
            lo,hi=positions[left],positions[right]
            events.setdefault(bottom,[]).append((lo,hi,kind,1))
            events.setdefault(top,[]).append((lo,hi,kind,-1))
    n=len(xs)-1;size=4*n+8
    counts=[[0]*size for _ in range(3)]
    free=[0]*size;blen=[0]*size;ilen=[0]*size;union=[0]*size
    def build(node,lo,hi):
        free[node]=xs[hi]-xs[lo]
        if hi-lo>1:
            mid=(lo+hi)//2;build(2*node,lo,mid);build(2*node+1,mid,hi)
    build(1,0,n)
    def update(node,lo,hi,start,end,kind,sign):
        if start<=lo and hi<=end:
            counts[kind][node]+=sign
            assert counts[kind][node]>=0
        else:
            mid=(lo+hi)//2
            if start<mid:update(2*node,lo,mid,start,end,kind,sign)
            if end>mid:update(2*node+1,mid,hi,start,end,kind,sign)
        if counts[2][node]:
            free[node]=blen[node]=ilen[node]=union[node]=0
        else:
            leaf=hi-lo==1;a=2*node;b=a+1
            free[node]=xs[hi]-xs[lo] if leaf else free[a]+free[b]
            blen[node]=free[node] if counts[0][node] else 0 if leaf else blen[a]+blen[b]
            ilen[node]=free[node] if counts[1][node] else 0 if leaf else ilen[a]+ilen[b]
            union[node]=free[node] if counts[0][node] or counts[1][node] else 0 if leaf else union[a]+union[b]
    totals=[0,0,0];ys=sorted(events)
    for yi,y in enumerate(ys):
        for lo,hi,kind,sign in events[y]:update(1,0,n,lo,hi,kind,sign)
        if yi+1<len(ys):
            height=ys[yi+1]-y
            for k,length in enumerate([blen[1],ilen[1],union[1]]):totals[k]+=height*length
    assert all(not any(rows) for rows in counts) and blen[1]==ilen[1]==union[1]==0
    assert free[1]==xs[-1]-xs[0]
    return totals
