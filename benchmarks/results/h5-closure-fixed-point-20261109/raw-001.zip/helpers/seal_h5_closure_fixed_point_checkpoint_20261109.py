"""Seal the complete clique/conditional fixed point and preserved audit failure."""
from pathlib import Path
import json, shutil, subprocess
ROOT = Path(__file__).resolve().parents[1]
original = (ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8')
prefix = original[:original.index('copies=[')]
changes = {
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-closure-fixed-point-20261109'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-incremental-closure-20261109';F=BASE/'audit-v2';D=ROOT/'output/h5-closure-clique-frontier-20261109'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-possible-node-closure-20261109'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['combined_clique_and_conditional_fixed_point'] and front['new_seed_exclusions']==0 and front['complete_query_rows']==3138",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-weighted-query-mask-controls-20261109',ROOT/'output/h5-possible-node-closure-main-sync-20261109']+[ROOT/'output'/(label+'-process-20261109') for label in ['h5-closure-clique-frontier','h5-closure-clique-frontier-audit','h5-weighted-query-mask-controls','h5-incremental-closure-plan','h5-incremental-closure-producer','h5-incremental-closure-audit','h5-incremental-closure-audit-v2']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*closure_clique*20261109.py','*h5*incremental_closure*20261109.py','*h5*weighted_query*20261109.py','*h5*closure_fixed_point*20261109.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_closure_fixed_point_checkpoint_20261109.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"load(F/'source-bindings.json').items()":"load(F/'plan.json')['inputs'].items()",
}
for before, after in changes.items():
    assert before in prefix, before
    prefix = prefix.replace(before, after)
exec(prefix)
labels = [('h5-closure-clique-frontier',True,True),('h5-closure-clique-frontier-audit',True,False),('h5-weighted-query-mask-controls',True,True),('h5-incremental-closure-plan',True,True),('h5-incremental-closure-producer',True,True),('h5-incremental-closure-audit',False,True),('h5-incremental-closure-audit-v2',True,False)]
processes = []; cost = load(PARENT/'checkpoint-audit.json')['complete_preparation_seconds_if_consumed']
for label, passed, charged in labels:
    p = load(ROOT/'output'/(label+'-process-20261109')/'process.json')
    assert p['passed']==passed and p['closed'] and p['job']['closed'] and p['job']['active_processes']==0 and p['job']['job_committed_memory_limit']==2**31
    if charged: cost += p['complete_seconds']
    processes.append({'stage':label,'passed':passed,'closed':True,'active_processes':0,'complete_seconds':p['complete_seconds'],'charged':charged})
assert abs(cost-front['complete_preparation_seconds_if_consumed']) < 1e-8
inherited = load(PARENT/'process-summary.json')+load(PARENT/'inherited-process-summary.json')
assert len(inherited)==472 and all(p['closed'] and p['active_processes']==0 for p in inherited)
write(OUT/'process-summary.json',processes); write(OUT/'inherited-process-summary.json',inherited)
copies = [(F/'checks.json','conditional-audit.json'),(F/'case-results.json','conditional-case-results.json'),(BASE/'plan.json','complete-plan.json'),(BASE/'producer/query-results.json','all3138-query-results.json'),(BASE/'audit-sequencing-correction.json','audit-sequencing-correction.json'),(D/'audit/checks.json','clique-and-geometry-audit.json'),(D/'audit/case-results.json','global-exact-case-results.json'),(ROOT/'output/h5-weighted-query-mask-controls-20261109/checks.json','weighted-mask-controls.json'),(ROOT/'output/h5-incremental-closure-audit-process-20261109/process.json','preserved-failed-audit.json'),(ROOT/'output/h5-possible-node-closure-main-sync-20261109/receipt.json','prior-main-push-receipt.json')]
for index in [1,9]:
    copies.append((BASE/f'producer/choice-{index:02d}-frontier.json',f'choice-{index:02d}-frontier.json'))
for source,name in copies: shutil.copyfile(source,OUT/name)
runtime = load(PARENT/'runtime-bindings.json')
for name,h in runtime.items(): assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
ci = json.loads(subprocess.check_output(['gh','run','view','42547117998','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True))
assert ci['headSha']=='2ae15d964798b097284abaefe7e0d143a0de1905'
write(OUT/'main-ci-at-review.json',ci)
write(OUT/'checks.json',{**front,**archive,'passed':True,'new_processes_closed':7,'inherited_processes_closed':472,'all479_processes_closed':True,'new_failed_auditor_preserved':True,'completion_percent':60,'remaining_current_nodes':8569,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime)})
proposal = 'Freeze a complete conditional-capacity check for EVERY active insert reference in both remaining cases (1683+1829=3512 cells). A chosen insert leaves8brackets+7inserts, requiring319992/138593/458585mm2. Build each raw graph forbidden row with verified source self collision and restrict it to the current masks. Reuse the already certified possible covering-node sets P for every original physical signature, intersect P with current active masks, then project against all insert-reference rows. The resulting bounds are conservative even though P was derived from bracket-query signatures. Independently verify all new projections and weighted family/joint areas, preserving every physical record and current insert mapping target. No new source atlas or repeated bracket fixed-point call is needed. No insert-specific preflight or query has been prepared. Preserve full accumulated cost and original failures; an eventual timed constructor must recompute source inputs and meet the complete preparation-inclusive budget.'
write(OUT/'next-step.json',{'status':'combined_bracket_clique_and_conservative_conditional_bound_at_fixed_point','proposal':proposal,'new_insert_query_stage_prepared':False,'authoritative_current_masks':'output/h5-incremental-closure-20261109/producer/choice-{01,09}-frontier.json remaining_current_positions (identical to prior committed masks)','consumed_preparation_seconds':cost,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'whole_allocations_remaining':440,'H5_complete':False})
passed=sum(j['conclusion']=='success' for j in ci['jobs']); live=sum(j['status']!='completed' for j in ci['jobs'])
report=f'''# Complete bracket-bound fixed point — 2026-11-09

**The current clique and bracket-conditional area bounds are at a fixed point.**
A complete follow-on pass finds no new exclusion in either remaining fixed29
choice, `[0,5,10]` or `[5,10,11]`. The 8,569 current nodes remain: 3,801 in case 01
and 4,768 in case 09. This closes this necessary-bound iteration; it proves
neither feasibility nor whole-arrangement impossibility. H2/H5 remain open at
**60% completed milestone weight**.

## Full clique and geometry check

Starting from the [previous verified masks](h5-possible-node-closure-20261109.md),
the [independent clique audit]({NAME}/clique-and-geometry-audit.json) checks all
8,914 source self-collision witnesses, 1,848,482 directed clique edges and every
remaining candidate's necessary companion counts. It removes no additional node.
Original closed anchor covers and 21,698 retained source-component sweeps
reconstruct all six exact swept-envelope union areas independently.
The [global results]({NAME}/global-exact-case-results.json) remain above the required
478,384 mm² joint area, with 497,091.028543 and 484,740.614909 mm² available upper bounds.

## Complete conditional fixed point

[The frozen follow-on plan]({NAME}/complete-plan.json) accounts for both complete
cases, all 87,484 certified possible covering-node sets, all 151,597 physical
records and every one of 3,138 original bracket-reference queries. Case 01's
active mask is identical. Case 09's thirteen removals change 3,651 projected
family signatures and produce 41,576 weighted query updates, but no new deficit
target. The producer subtracts only newly lost areas from the earlier audited
bounds; unchanged possible-node intersections carry their identical signatures.

The [independent auditor]({NAME}/conditional-audit.json) uses allowed-query columns
to project every changed set, then recomputes every current area from all original
physical pieces. It uses binary digit planes to sum each query's weighted losses.
[Scalar controls]({NAME}/weighted-mask-controls.json) cover 16,384 exhaustive small
two-record cases and 256 large-weight, cross-word cases: 562,432 scalar query
comparisons, including query index 2,004 and carries beyond the source weight width.
Every one of [9,414 conditional bounds]({NAME}/all3138-query-results.json) matches
the delta-loss producer. All current mapping targets remain covered. With no
new conditional seed after the complete clique check, this method is at a fixed point.

The areas remain conservative bounds on common-line occupied outer envelopes
with holes reserved. All 90 cutting holes are preserved. Possible-node sets
are not exact geometric coverage; no ordinary part-in-hole claim follows.

## Preserved failed audit and process closure

The first auditor was mistakenly launched while its producer was still live.
It failed on the not-yet-created query-results file. [That failed process]({NAME}/preserved-failed-audit.json)
remains preserved, with its full 2.476507 s charged. The producer completed once
and was not repeated. [The corrected audit]({NAME}/audit-sequencing-correction.json)
requires a terminal successful producer with zero descendants and verifies a
complete frozen output snapshot before starting. It covers the same full scope
under the unchanged 60 s / 2 GiB limit and passes in 46.295622 s.

[All seven new processes]({NAME}/process-summary.json) and
[472 inherited processes]({NAME}/inherited-process-summary.json) are terminal
with zero descendants. Workers retain CCD1 logical processors 16–31, one
BLAS/OMP/MKL thread and Windows Job memory caps. Consumed preparation is
**{cost:.6f} s**. No optimizer, timer reset or timed H5 acceptance follows.

[Next]({NAME}/next-step.json), evaluate every active insert as a conditional
reference. The existing complete reference set covers brackets; an insert leaves
eight brackets and seven other inserts, with a different capacity requirement.
The certified possible-node sets support conservative bounds for these new rows
without rerunning the geometric partition. This stage is not prepared.

All 440 whole-job allocations, full66 source/native/material validation,
production integration and the H5 matrix remain open. The valid64 layout stays
best. Existing 453/455 fixed29 exclusions, eight older first32 closures and 680
five-column closures stand. Product, README and releases are unchanged.

[The prior checkpoint reached main 2ae15d96]({NAME}/prior-main-push-receipt.json)
after all six preceding checks passed. [Its CI at review]({NAME}/main-ci-at-review.json)
has {passed} passed / {live} live jobs. This checkpoint awaits the ordinary push gate.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the complete evidence chain.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-09 H5 bracket-bound fixed point:** [complete clique and conditional audits]({{link}}) add no new exclusion after all 8,914 source self witnesses, 1,848,482 directed clique edges, 87,484 possible-node sets, 151,597 physical entries and 3,138 reference rows are accounted for. All 9,414 conservative conditional bounds independently match; 3,651 signatures tighten and 41,576 weighted updates yield no new seed. Both fixed29 choices remain with 8,569 nodes. The first auditor was launched before producer completion and failed on a missing output; it is preserved and fully charged. A corrected audit pins complete terminal output and passes the unchanged limit; the producer is not repeated. All seven new and 472 inherited processes close. Consumed preparation {cost:.6f} s cannot reset or open an optimizer. Next freeze a complete insert-reference conditional check for all 3,512 active insert cells; none is prepared. All 440 allocations/full66/H5 remain open, valid64 stays best, and H2/H5 remain open at 60%. Common-line holes remain reserved; product/README/releases unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md'
    append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md'; content=status.read_text(encoding='utf-8')
start=content.index('Latest H5 evidence:'); end=content.index('\nThe earlier fixed 13-cog construction',start)
intro=f'''Latest H5 evidence: [complete bracket-bound fixed point](../benchmarks/results/{NAME}.md).
The full clique check adds no removal. A further complete conditional pass
reprojects all changed possible-node sets and independently recomputes all
9,414 bounds from 151,597 physical records. No new seed follows. This necessary
bound is at a fixed point, with both choices [0,5,10] and [5,10,11] still open
and 8,569 current nodes. The 453/455 whole-choice exclusions stand, including
428 at zero clearance. These common-line bounds reserve holes; no ordinary
part-in-hole or whole-allocation exclusion follows. An auditor launched before
its producer finished is preserved as failed; the corrected complete audit
passes with a terminal-output prerequisite and unchanged limits. All seven
new and 472 inherited processes close. Consumed preparation is {cost:.6f} s;
no optimizer or timer reset is permitted. Next assess all 3,512 active insert
references using the certified possible-node sets; this stage is not prepared.
All 440 allocations and full66/H5 validation remain open; valid64 stays best.
H2/H5 remain open at 60%. Separate eight older first32 and 680 five-column
cores stay closed. Product, README and releases are unchanged. Main 2ae15d96
has {passed} passed/{live} live CI jobs at review; this checkpoint awaits ordinary push.
'''
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(content[:start]+intro+content[end:])
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text\n')
print({'passed':True,'archive':archive,'bindings':len(bindings),'historical_references':len(external),'consumed_preparation_seconds':cost,'fixed_point':True,'remaining_nodes':8569})
