"""Freeze one complete follow-on restriction, including unchanged case carry-forward."""
from pathlib import Path
from hashlib import sha256
import json, time
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/h5-incremental-closure-20261109'
PREVIOUS = ROOT / 'output/h5-complete-closure-plan-20261109'
load = lambda p: json.loads(p.read_bytes())
OUT.mkdir()
started = time.perf_counter()
inputs = [Path(__file__), ROOT/'benchmarks/results/h5-possible-node-closure-20261109/archive-checks.json', ROOT/'benchmarks/results/h5-possible-node-closure-20261109/all3138-query-results.json', PREVIOUS/'plan.json', PREVIOUS/'checkpoint-audit/checks.json', ROOT/'output/h5-closure-clique-frontier-20261109/audit/checks.json', ROOT/'output/h5-closure-clique-frontier-20261109/audit/plan.json', ROOT/'output/h5-closure-clique-frontier-20261109/audit/additional-source-bindings.json', ROOT/'output/h5-weighted-query-mask-controls-20261109/checks.json', ROOT/'output/h5-weighted-query-mask-controls-20261109/source-bindings.json', ROOT/'output/h5-weighted-query-mask-controls-process-20261109/process.json', ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json']
assert load(inputs[1])['passed']
assert load(ROOT/'output/h5-weighted-query-mask-controls-20261109/checks.json')['passed']
cases = []
for case in [1, 9]:
    source = ROOT/f'output/h5-fixed29-complete-row-preflight-20261109/choice-{case:02d}.json'
    oldfront = ROOT/f'benchmarks/results/h5-complete-reference-capacity-20261109/choice-{case:02d}-frontier.json'
    newfront = ROOT/f'output/h5-closure-clique-frontier-20261109/choice-{case:02d}-frontier.json'
    inputs.extend([source, oldfront, newfront, PREVIOUS/f'choice-{case:02d}-atoms.json'])
    old = load(oldfront)['remaining_current_positions']
    new = load(newfront)['remaining_current_positions']
    assert set(new) <= set(old)
    for spec in load(PREVIOUS/'plan.json')['closure_batches']:
        if spec['refinement_index'] == case:
            folder = PREVIOUS/f"closure-batch-{spec['batch_index']:02d}"
            assert load(folder/'audit/checks.json')['passed']
            inputs.extend([folder/'plan.json', folder/'closures.json', folder/'audit/checks.json', folder/'audit/source-bindings.json'])
    cases.append({'refinement_index': case, 'baseline_nodes': len(old), 'current_nodes': len(new), 'newly_removed_positions': sorted(set(old)-set(new)), 'unchanged_mask': old == new, 'all_query_rows': len(load(source)['required_representatives'])})
for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
    folder = ROOT/piece['folder']
    inputs.extend([folder/'atoms.json', folder/'audit/checks.json'])
cost = load(ROOT/'output/h5-closure-clique-frontier-20261109/audit/checks.json')['complete_preparation_seconds_if_consumed'] + load(ROOT/'output/h5-weighted-query-mask-controls-process-20261109/process.json')['complete_seconds']
plan = {'inputs': {p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest() for p in inputs}, 'cases': cases, 'method': 'One complete frozen follow-on restriction. Reuse only certified original possible-node sets and their prior projected signatures. If the possible-node intersection with the active mask is unchanged, its prior signature is identical by proof; otherwise recompute it. Producer subtracts only newly lost weighted areas from all previously audited conditional bounds. Independent auditor projects changed sets through allowed-query columns and recomputes every current area directly from original physical pieces with separately controlled weighted bit planes. Include both complete cases even when unchanged. Apply all deficit seeds through the original mapping. A no-seed result after the preceding complete clique fixed point proves this combined necessary bound is at a fixed point; it does not prove packing feasibility.', 'maximum_rounds': 1, 'producer_cap_seconds': 30, 'auditor_cap_seconds': 60, 'memory_bytes': 2**31, 'inherited_numeric_preparation_seconds': cost, 'optimizer_calls': 0, 'retry_permitted': False}
for name, value in [('plan.json', plan), ('checks.json', {'prepared': True, 'seconds': time.perf_counter()-started, 'complete_cases': 2, 'complete_query_rows': 3138, 'new_mask_removals': sum(len(c['newly_removed_positions']) for c in cases), 'independent_audit_pending': True, 'optimizer_calls': 0})]:
    with (OUT/name).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')
print(cases)
