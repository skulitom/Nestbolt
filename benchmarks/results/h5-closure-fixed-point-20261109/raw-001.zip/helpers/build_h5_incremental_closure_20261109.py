"""Complete delta-loss update of every old conditional bound under reduced masks."""
from pathlib import Path
from hashlib import sha256
import json, time
from h5_possible_node_closure_20261109 import query_signature
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'output/h5-incremental-closure-20261109'
PREVIOUS = ROOT/'output/h5-complete-closure-plan-20261109'
OUT = BASE/'producer'
load = lambda p: json.loads(p.read_bytes())
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')
OUT.mkdir()
started = time.perf_counter()
plan = load(BASE/'plan.json')
for name, h in plan['inputs'].items():
    assert sha256((ROOT/name).read_bytes()).hexdigest() == h, name
inputs = dict(plan['inputs'])
for p in [Path(__file__), ROOT/'output/h5_possible_node_closure_20261109.py', BASE/'plan.json']:
    inputs[p.relative_to(ROOT).as_posix()] = sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json', {'inputs': inputs, 'method': plan['method']})
old_queries = load(ROOT/'benchmarks/results/h5-possible-node-closure-20261109/all3138-query-results.json')
all_results = []
cases = []
for case in [1, 9]:
    data = load(ROOT/f'output/h5-fixed29-complete-row-preflight-20261109/choice-{case:02d}.json')
    old_active = load(ROOT/f'benchmarks/results/h5-complete-reference-capacity-20261109/choice-{case:02d}-frontier.json')['remaining_current_positions']
    active = load(ROOT/f'output/h5-closure-clique-frontier-20261109/choice-{case:02d}-frontier.json')['remaining_current_positions']
    old_mask = sum(1 << p for p in old_active); active_mask = sum(1 << p for p in active)
    rows = [int(v, 16) for v in data['representative_active_forbidden_rows_hex']]
    maps = [{}, {}]; signature_records = [[], []]; changed = [0, 0]
    for spec in load(PREVIOUS/'plan.json')['closure_batches']:
        if spec['refinement_index'] != case:
            continue
        family = spec['family']
        for old_text, possible_text, prior_text in load(PREVIOUS/f"closure-batch-{spec['batch_index']:02d}/closures.json"):
            key = int(old_text, 16); possible = int(possible_text, 16); prior = int(prior_text, 16)
            new = query_signature(rows, possible & active_mask) if possible & old_mask != possible & active_mask else prior
            assert prior & ~new == 0
            changed[family] += new != prior
            maps[family][key] = (prior, new)
            signature_records[family].append([old_text, hex(new)])
    old_case = [r for r in old_queries if r['refinement_index'] == case]
    assert [r['representative_current_position'] for r in old_case] == data['required_representatives']
    areas = [r['family_and_joint_area_upper_um2'][:] for r in old_case]
    entries = 0; delta_updates = 0
    for b, i, area in load(PREVIOUS/f'choice-{case:02d}-atoms.json'):
        b0, b1 = maps[0][int(b,16)]; i0, i1 = maps[1][int(i,16)]
        delta = [b1 & ~b0, i1 & ~i0, (b1 & i1) & ~(b0 & i0)]
        for family, loss in enumerate(delta):
            while loss:
                bit = loss & -loss; qi = bit.bit_length()-1
                areas[qi][family] -= area; delta_updates += 1; loss ^= bit
        entries += 1
    mapping = [(p, rep) for p, rep in data['pivot_to_representative'] if active_mask & (1 << p)]
    results = []; excluded = []
    for qi, values in enumerate(areas):
        rep = data['required_representatives'][qi]
        failures = [k for k, (a, b) in enumerate(zip(values, [279993000000,158392000000,438385000000])) if a < b]
        targets = [p for p, r in mapping if r == rep] if failures else []
        excluded.extend(targets)
        results.append({'refinement_index': case, 'representative_current_position': rep, 'representative_query_index': qi, 'family_and_joint_area_upper_um2': values, 'failing_area_indices': failures, 'reference_query_excluded': bool(failures), 'dominated_active_bracket_positions_excluded': targets})
    remaining = [p for p in active if p not in set(excluded)]
    result = {'refinement_index': case, 'input_nodes': len(active), 'remaining_nodes': len(remaining), 'new_seed_exclusions': len(excluded), 'changed_family_signatures': changed, 'merged_physical_entries': entries, 'delta_weighted_query_updates': delta_updates, 'all_query_rows': len(results), 'fixed_point_for_conditional_bound': not excluded}
    write(OUT/f'choice-{case:02d}-signatures.json', signature_records)
    write(OUT/f'choice-{case:02d}-frontier.json', {**result, 'remaining_current_positions': remaining, 'excluded_current_positions': sorted(excluded)})
    cases.append(result); all_results.extend(results)
write(OUT/'case-results.json', cases)
write(OUT/'query-results.json', all_results)
write(OUT/'checks.json', {'prepared': True, 'seconds': time.perf_counter()-started, 'complete_cases': 2, 'complete_query_rows': len(all_results), 'new_seed_exclusions': sum(r['new_seed_exclusions'] for r in cases), 'independent_audit_pending': True, 'optimizer_calls': 0, 'H5_complete': False})
print(cases)
