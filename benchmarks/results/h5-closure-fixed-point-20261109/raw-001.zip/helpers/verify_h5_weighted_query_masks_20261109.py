"""Compare parallel binary counters with independent scalar dot products."""
from pathlib import Path
from hashlib import sha256
import json, time
from h5_weighted_query_masks_20261109 import weighted_query_sums
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/h5-weighted-query-mask-controls-20261109'
OUT.mkdir()
started = time.perf_counter()
cases = 0
for left in range(8):
    for right in range(8):
        for a in range(16):
            for b in range(16):
                expected = [a * bool(left & (1 << q)) + b * bool(right & (1 << q)) for q in range(3)]
                assert weighted_query_sums([(left, a), (right, b)], 3) == expected
                cases += 1
positions = [0, 7, 63, 64, 129, 511, 1132, 2004]
cross = 0
for seed in range(256):
    rows = []
    for j in range(32):
        mask = sum(1 << p for k, p in enumerate(positions) if ((seed * (j + 1) + 19 * j) >> k) & 1)
        weight = (1 << (j + 10)) - 1 + seed * 1009
        rows.append((mask, weight))
    expected = [sum(weight for mask, weight in rows if mask & (1 << q)) for q in range(2005)]
    assert weighted_query_sums(rows, 2005) == expected
    cross += 1
assert weighted_query_sums([], 2005) == [0] * 2005
result = {'passed': True, 'exhaustive_two_record_cases': cases, 'cross_word_large_weight_cases': cross, 'scalar_queries_verified': 3 * cases + 2005 * cross, 'empty_input_checked': True, 'seconds': time.perf_counter() - started, 'optimizer_calls': 0}
for name, value in [('checks.json', result), ('source-bindings.json', {p.relative_to(ROOT).as_posix(): sha256(p.read_bytes()).hexdigest() for p in [Path(__file__), ROOT / 'output/h5_weighted_query_masks_20261109.py']})]:
    with (OUT / name).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')
print(result)
