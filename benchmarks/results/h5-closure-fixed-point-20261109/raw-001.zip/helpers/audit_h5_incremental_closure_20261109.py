"""Recompute complete current losses from all physical pieces with binary counters."""
from pathlib import Path
from hashlib import sha256
import json, time
from h5_possible_node_closure_20261109 import allowed_columns, column_signature
from h5_weighted_query_masks_20261109 import weighted_query_sums
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'output/h5-incremental-closure-20261109'
PREVIOUS = ROOT/'output/h5-complete-closure-plan-20261109'
SOURCE = BASE/'producer'; OUT = BASE/'audit'
load = lambda p: json.loads(p.read_bytes())
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')
OUT.mkdir()
started = time.perf_counter()
inputs = dict(load(SOURCE/'plan.json')['inputs'])
for name, h in inputs.items():
    assert sha256((ROOT/name).read_bytes()).hexdigest() == h, name
for p in [Path(__file__), ROOT/'output/h5_weighted_query_masks_20261109.py', SOURCE/'plan.json'] + list(SOURCE.glob('*.json')):
    inputs[p.relative_to(ROOT).as_posix()] = sha256(p.read_bytes()).hexdigest()
for name, h in load(ROOT/'output/h5-weighted-query-mask-controls-20261109/source-bindings.json').items():
    assert sha256((ROOT/name).read_bytes()).hexdigest() == h; inputs[name] = h
assert load(ROOT/'output/h5-weighted-query-mask-controls-20261109/checks.json')['passed']
results = []; physical = signatures = 0
for case in [1, 9]:
    data = load(ROOT/f'output/h5-fixed29-complete-row-preflight-20261109/choice-{case:02d}.json')
    active = load(ROOT/f'output/h5-closure-clique-frontier-20261109/choice-{case:02d}-frontier.json')['remaining_current_positions']
    old_active = load(ROOT/f'benchmarks/results/h5-complete-reference-capacity-20261109/choice-{case:02d}-frontier.json')['remaining_current_positions']
    old_mask = sum(1 << p for p in old_active); active_mask = sum(1 << p for p in active)
    assert active_mask & ~old_mask == 0
    rows = [int(v,16) for v in data['representative_active_forbidden_rows_hex']]
    maps = [{}, {}]; columns = [None, None]; expected_signatures = [[], []]
    for spec in load(PREVIOUS/'plan.json')['closure_batches']:
        if spec['refinement_index'] != case:
            continue
        family = spec['family']
        for key_text, possible_text, prior_text in load(PREVIOUS/f"closure-batch-{spec['batch_index']:02d}/closures.json"):
            possible = int(possible_text,16)
            before = possible & old_mask; after = possible & active_mask
            if before == after:
                current = int(prior_text,16)
            else:
                if columns[family] is None:
                    positions = [r['current_position'] for r in data['node_regions'] if r['family'] == family]
                    universe = sum(1 << p for p in positions)
                    columns[family] = allowed_columns([r & universe for r in rows], positions)
                current = column_signature(columns[family], after, len(rows))
            expected_signatures[family].append([key_text, hex(current)])
            maps[family][int(key_text,16)] = current
            signatures += 1
    assert expected_signatures == load(SOURCE/f'choice-{case:02d}-signatures.json')
    records = [[], [], []]; total = 0
    for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
        if piece['refinement_index'] != case:
            continue
        for b, i, area in load(ROOT/piece['folder']/'atoms.json'):
            b = maps[0][int(b,16)]; i = maps[1][int(i,16)]
            for family, mask in enumerate([b, i, b & i]):
                records[family].append((mask, area))
            total += area; physical += 1
    loss_vectors = [weighted_query_sums(values, len(rows)) for values in records]
    saved = [r for r in load(SOURCE/'query-results.json') if r['refinement_index'] == case]
    assert [r['representative_current_position'] for r in saved] == data['required_representatives']
    rejected = set()
    for qi, row in enumerate(saved):
        values = [total - loss_vectors[family][qi] for family in range(3)]
        assert row['family_and_joint_area_upper_um2'] == values
        failures = [k for k,(a,b) in enumerate(zip(values,[279993000000,158392000000,438385000000])) if a < b]
        assert failures == row['failing_area_indices']
        expected = sorted(p for p,rep in data['pivot_to_representative'] if p in set(active) and rep == row['representative_current_position']) if failures else []
        assert expected == row['dominated_active_bracket_positions_excluded']
        rejected.update(expected)
    frontier = load(SOURCE/f'choice-{case:02d}-frontier.json')
    assert frontier['remaining_current_positions'] == [p for p in active if p not in rejected]
    assert frontier['new_seed_exclusions'] == len(rejected)
    results.append({k:v for k,v in frontier.items() if k not in ['remaining_current_positions','excluded_current_positions']})
assert physical == 151597 and signatures == 87484
producer_process = load(ROOT/'output/h5-incremental-closure-producer-process-20261109/process.json')
planner_process = load(ROOT/'output/h5-incremental-closure-plan-process-20261109/process.json')
assert producer_process['passed'] and planner_process['passed'] and producer_process['closed'] and planner_process['closed']
charge = load(BASE/'plan.json')['inherited_numeric_preparation_seconds'] + planner_process['complete_seconds'] + producer_process['complete_seconds']
for label in ['h5-incremental-closure-producer','h5-incremental-closure-plan']:
    p = ROOT/'output'/(label+'-process-20261109')/'process.json'; inputs[p.relative_to(ROOT).as_posix()] = sha256(p.read_bytes()).hexdigest()
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'complete_cases': 2, 'unique_family_signatures_verified': signatures, 'original_physical_entries_verified': physical, 'complete_query_rows': 3138, 'conservative_conditional_area_bounds': 9414, 'new_seed_exclusions': sum(r['new_seed_exclusions'] for r in results), 'combined_clique_and_conditional_fixed_point': all(r['new_seed_exclusions']==0 for r in results), 'complete_preparation_seconds_if_consumed': charge, 'remaining_fixed29_cases': 2, 'whole_allocations_remaining': 440, 'optimizer_allowed_from_current_lineage': False, 'optimizer_calls': 0, 'H5_complete': False}
write(OUT/'plan.json', {'inputs': inputs, 'method': 'Independent allowed-query projection for every changed possible-node set; exact carry-forward only when its intersection with the active mask is identical. Recompute full current loss vectors from every original physical record using controlled binary digit planes, compare all9414 bounds and all current deficit targets, then check seed frontier. Full source coverage includes both cases and every original query.'})
write(OUT/'case-results.json', results); write(OUT/'checks.json', checks)
print(checks); print(results)
