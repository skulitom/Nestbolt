"""Exact sums for all query bits using binary digit planes and carry masks."""


def weighted_query_sums(records, query_count):
    columns = []
    full = (1 << query_count) - 1
    for mask, weight in records:
        assert mask >= 0 and not mask & ~full and weight >= 0
        while weight:
            bit = weight & -weight
            position = bit.bit_length() - 1
            carry = mask
            weight ^= bit
            while carry:
                if position >= len(columns):
                    columns.extend([0] * (position + 1 - len(columns)))
                old = columns[position]
                columns[position] = old ^ carry
                carry &= old
                position += 1
    return [sum(((column >> query) & 1) << digit for digit, column in enumerate(columns)) for query in range(query_count)]
