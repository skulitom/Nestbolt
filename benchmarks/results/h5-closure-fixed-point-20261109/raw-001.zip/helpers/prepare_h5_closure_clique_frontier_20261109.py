"""Propagate complete conditional area exclusions, then recompute full-domain capacity."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_exact_rectangle_areas_20261108 import vertical_areas
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-closure-clique-frontier-20261109'
QUERY=ROOT/'output/h5-complete-closure-plan-20261109/reconciliation';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109'
FRONT=ROOT/'output/h5-fixed29-conditional-frontier-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();parent=load(QUERY/'checks.json');assert parent['passed'] and parent['complete_query_rows']==3138
qprocess=load(ROOT/'output/h5-restricted-closure-reconciliation-process-20261109/process.json');assert qprocess['passed'] and qprocess['closed']
cases=load(QUERY/'case-results.json');assert len(cases)==2
inputs=[Path(__file__),ROOT/'output/h5_exact_rectangle_areas_20261108.py',QUERY/'checks.json',QUERY/'plan.json',QUERY/'case-results.json',QUERY/'query-results.json',ROOT/'output/h5-restricted-closure-reconciliation-process-20261109/process.json',PRE/'audit/checks.json',PRE/'audit/plan.json',FRONT/'audit/checks.json',FRONT/'audit/plan.json',FRONT/'audit/remaining-cases.json',OLD/'geometries.json']
for case in cases:
    index=case['refinement_index'];data=load(PRE/f'choice-{index:02d}.json');graph=ROOT/data['graph']
    inputs.extend([ROOT/f'benchmarks/results/h5-possible-node-closure-20261109/choice-{index:02d}-frontier.json',PRE/f'choice-{index:02d}.json',QUERY/f'choice-{index:02d}-exclusions.json',FRONT/f'choice-{index:02d}-frontier.json',graph/'nodes.json',graph/'conflicts.bin',graph/'root-covers.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Start exactly from both committed possible-node-closure seed masks, which already apply every complete conditional deficit. Add no new seed. Recheck the necessary root-clique counts on these changed masks. Verify source self collision and every root-cover clique, then apply at most8 simultaneous necessary clique-count rounds. Every chosen cell must leave7/8or8/7other parts. Retain every unexcluded current node and every original closed source cover. Recompute all three occupied-envelope union areas against unchanged fixed0.2mm forbidden regions. Common-line holes reserved; no whole-allocation or orientation-class claim.','maximum_clique_rounds':8,'process_cap_seconds':30,'memory_bytes':2**31,'inherited_numeric_preparation_seconds':parent['complete_preparation_seconds_before_this_reconciliation']+qprocess['complete_seconds'],'optimizer_calls':0,'retry_permitted':False})
geometries=load(OLD/'geometries.json');results=[]
for case in cases:
    index=case['refinement_index'];data=load(PRE/f'choice-{index:02d}.json');graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');N=len(nodes);width=(N+7)//8;raw=(graph/'conflicts.bin').read_bytes();assert len(raw)==N*width
    rows=[int.from_bytes(raw[p*width:(p+1)*width],'little')|(1<<p) for p in range(N)];previous=load(FRONT/f'choice-{index:02d}-frontier.json');original=load(ROOT/f'benchmarks/results/h5-possible-node-closure-20261109/choice-{index:02d}-frontier.json')['remaining_current_positions'];assert set(original)<=set(data['active_current_positions'])
    for p,node in enumerate(nodes):
        box=node['bounds_um'];c=geometries[node['geometry']]['inner_rectangles_um'][previous['source_self_collision_components'][p]]
        assert box[2]-box[0]<c[2]-c[0] and box[3]-box[1]<c[3]-c[1]
    cliques=[]
    for family,groups in enumerate(load(graph/'root-covers.json')):
        family_masks=[];covered=set()
        for group in groups:
            assert len(set(group))==len(group) and all(nodes[p]['family']==family for p in group)
            bits=sum(1<<p for p in group)
            for p in group:assert rows[p]&bits==bits
            family_masks.append(bits);covered.update(group)
        assert covered=={p for p,node in enumerate(nodes) if node['family']==family};cliques.append(family_masks)
    causes=[];seed=[]  # The committed input masks already contain every verified seed.
    assert len(set(seed))==len(seed) and set(seed)<=set(original) and all(nodes[p]['family']==0 for p in seed)
    active=sum(1<<p for p in original)&~sum(1<<p for p in seed);rounds=[]
    for iteration in range(8):
        removed=[]
        for p in original:
            if not active>>p&1:continue
            allowed=active&~rows[p];upper=[sum(bool(group&allowed) for group in groups) for groups in cliques];need=[8-(nodes[p]['family']==0),8-(nodes[p]['family']==1)]
            if any(a<b for a,b in zip(upper,need)):removed.append({'current_position':p,'remaining_family_upper_counts':upper,'required_remaining_counts':need})
        rounds.append({'round':iteration,'removed':removed})
        if not removed:break
        active&=~sum(1<<r['current_position'] for r in removed)
    retained=[p for p in original if active>>p&1];regions=[set(),set()]
    for r in data['node_regions']:
        if active>>r['current_position']&1:regions[r['family']].update(map(tuple,r['regions_um']))
    regions=[sorted(r) for r in regions];areas=vertical_areas(*regions,data['fixed_forbidden_clearance_regions_um']);global_counts=[sum(bool(group&active) for group in groups) for groups in cliques]
    required=[319992000000,158392000000,478384000000];failures=[k for k,(area,need) in enumerate(zip(areas,required)) if area<need]
    excluded=bool(failures) or min(global_counts)<8
    write(OUT/f'choice-{index:02d}-frontier.json',{'refinement_index':index,'original_active_positions':original,'seed_exclusions':causes,'clique_rounds':rounds,'remaining_current_positions':retained,'family_component_regions_um':[[list(r) for r in rows] for rows in regions]})
    row={'refinement_index':index,'empty_sites':case['empty_sites'],'active_nodes_before':len(original),'conditional_seed_exclusions':len(seed),'additional_clique_exclusions':sum(len(r['removed']) for r in rounds),'remaining_current_nodes':len(retained),'remaining_bracket_nodes':sum(nodes[p]['family']==0 for p in retained),'remaining_insert_nodes':sum(nodes[p]['family']==1 for p in retained),'global_clique_upper_counts':global_counts,'family_and_joint_area_upper_um2':areas,'required_family_and_joint_area_lower_um2':required,'failing_area_indices':failures,'provisional_fixed_scope_excluded':excluded}
    results.append(row);print(row,flush=True)
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':2,'new_conditional_seed_exclusions':sum(r['conditional_seed_exclusions'] for r in results),'additional_clique_exclusions':sum(r['additional_clique_exclusions'] for r in results),'provisional_fixed_scope_exclusions':sum(r['provisional_fixed_scope_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False})
