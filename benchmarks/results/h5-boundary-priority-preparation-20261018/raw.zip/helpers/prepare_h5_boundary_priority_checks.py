"""Reuse the preceding comparison method and public checks for boundary ordering."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-boundary-priority-probe-20261018'
ref=root/'scripts/h5_material_profile_pilot.py';s=ref.read_text(encoding='utf-8')
s=s.replace('h5-material-profile-probe','h5-boundary-priority-probe').replace('h5-material-profile-preparation','h5-boundary-priority-preparation')
s=s.replace('h5-exact-reject-pilot','h5-material-profile-pilot')
s=s.replace("PROBE/'profile-checks/checks.json'", "PROBE/'order-checks/checks.json', PROBE/'reconstruction.json',\n                  ROOT/'benchmarks/results/h5-material-profile-preparation-20261018/profile-checks.json',\n                  ROOT/'benchmarks/results/h5-frontier-observer-20261018/layout-checks.json',\n                  ROOT/'benchmarks/results/h5-frontier-observer-20261018/source-review.json'")
s=s.replace('Isolated material-profile rejection candidate','Isolated boundary-priority candidate')
end=s.index('"""',3)+3
s='''"""Paired development pilot of incoming-member priority at the sheet boundary.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The baseline is the unchanged preview. The isolated candidate changes the
incoming member order to descending placed-shape upper extent in the last
sheet, then descending area, retaining stable equal ties. The existing six
same-item and six mixed-pair caps, pair generators, sampling, repair limits,
full acceptance validation, early proven-neutral rejections and work charges
remain. All 123 prior tests are unchanged; three authored ranking tests are
added. This descriptive pilot cannot close H5 or justify a comparative claim.
"""'''+s[end:]
path=root/'scripts/h5_boundary_priority_pilot.py';assert not path.exists();compile(s,str(path),'exec')
path.write_text(s,encoding='utf-8',newline='\n')
def fn(t,n):return next(x for x in ast.parse(t).body if isinstance(x,ast.FunctionDef) and x.name==n)
names=['blocks','summarize','case','measure']
for n in names:assert ast.dump(fn(s,n))==ast.dump(fn(ref.read_text(encoding='utf-8'),n))
method={'reference':ref.relative_to(root).as_posix(),'reference_sha256':sha256(ref.read_bytes()).hexdigest(),
    'candidate_runner':path.relative_to(root).as_posix(),'runner_sha256':sha256(path.read_bytes()).hexdigest(),
    'identical_function_ASTs':names,'scoring_or_measurement_changed':False}
(probe/'pilot-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
for stage in ['public','branch','harness']:
    s=(root/f'output/check_h5_material_profile_{stage}.py').read_text(encoding='utf-8')
    s=s.replace('h5-material-profile-probe','h5-boundary-priority-probe').replace('h5_material_profile_pilot','h5_boundary_priority_pilot')
    path=root/f'output/check_h5_boundary_priority_{stage}.py';path.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(method))
