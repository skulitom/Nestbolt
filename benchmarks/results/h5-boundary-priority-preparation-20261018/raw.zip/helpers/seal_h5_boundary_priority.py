"""Seal qualified boundary-priority ordering before its unchanged quality pilot."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-boundary-priority-probe-20261018'
out=root/'benchmarks/results/h5-boundary-priority-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');source=load(probe/'reconstruction.json')
public=load(probe/'public-checks/checks.json');branch=load(probe/'branch-checks/checks.json');order=load(probe/'order-checks/checks.json')
assert build['all_checks_passed'] and source['all_checks_passed'] and public['all_checks_passed'] and branch['all_checks_passed'] and order['all_checks_passed']
assert '126 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert source['original_frame_preserved_within_each_selected_pair']
failed=load(probe/'failed-boundary-order/failure.json');assert failed['tests_failed']==3
assert digest(probe/'failed-boundary-order/authored-tests.exe')==failed['test_binary_sha256']
assert digest(probe/'failed-boundary-order/core-tests.log')==failed['log_sha256']
assert source['all_123_prior_tests_unchanged'] and source['other_runtime_exact'] and source['unchanged_other_files']==155
red=load(probe/'before-boundary-ranking/checks.json');assert red['expected_runtime_failure']
assert digest(probe/'before-boundary-ranking/expected-failure.log')==red['log_sha256'] and digest(probe/'before-boundary-ranking/authored-tests.exe')==red['binary_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not(arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
assert public['observer_outcomes']==10 and public['CLI_cross_checks']==4
assert branch['actual_outcomes']==12 and branch['public_validations']==24
assert order['new_order_tests']==3 and order['public_CLI_validations']==1
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json');assert digest(root/method['reference'])==method['reference_sha256'] and digest(root/method['candidate_runner'])==method['runner_sha256']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
helpers=['prepare_h5_boundary_priority.py','check_h5_boundary_priority_red.py','apply_h5_boundary_priority.py','build_h5_boundary_priority.py',
    'prepare_h5_boundary_priority_checks.py','check_h5_boundary_priority_source.py','check_h5_boundary_priority_witness.py',
    'check_h5_boundary_priority_public.py','check_h5_boundary_priority_branch.py','check_h5_boundary_priority_harness.py',
    'seal_h5_boundary_priority.py','record_h5_boundary_priority_preparation.py']
helpers.extend(['repair_h5_boundary_pair_frames.py','build_h5_boundary_priority_frames.py','update_h5_boundary_qualification.py'])
for name in helpers:files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_boundary_priority_pilot.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        b=z.read(name);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_functional_checks_pass':True,'optimized_core_tests_passed':126,'prior_tests_unchanged':123,'new_tests':3,
    'expected_two_failures_preserved':True,'first_three_regressions_preserved':True,'original_pair_frames_preserved':True,'strict_lint_passed':True,'observer_build_passed':True,
    'only_member_order_changes':True,'existing_generators_caps_budgets_work_charges_acceptance_unchanged':True,
    'all_156_formatted_files_reconstruct_exactly':True,'unchanged_other_files':155,
    'actual_branch_outcomes':12,'branch_frozen_CLI_checks':24,'order_witness_CLI_checks':1,
    'public_observer_outcomes':10,'public_CLI_cross_checks':4,'normal_exact_except_wall':True,
    'common_replay_exact_except_wall':True,'pilot_harness_tests':5,'production_unchanged':True,
    'measurement_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','source-checks.json','reconstruction.json','candidate.patch','pilot-method.json']:shutil.copyfile(probe/name,out/name)
for sub,name in [('before-boundary-ranking','expected-failure'),('public-checks','public-checks'),('branch-checks','branch-checks'),('order-checks','order-checks')]:shutil.copyfile(probe/sub/'checks.json',out/(name+'.json'))
shutil.copyfile(probe/'failed-boundary-order/failure.json',out/'first-revision-failures.json')

doc='''# Boundary-priority ordering — preparation, 2026-10-18

The [two focused diagnostics](h5-frontier-observer-20261018.md) make 25
attempts but never visit an insert choice. Two inserts set the height of the
sheet receiving offcut credit. The earlier material-profile pilot still
fails five material pairs; early rejection alone did not meet H5.

This isolated candidate ranks last-sheet incoming members by descending
placed-shape upper extent, then area, with stable equal ties. In the model's
rotated strip frame the upper extent is the rightmost bounding coordinate.
The existing same-item and mixed-pair generators consume that ordered list.
Each selected pair then retains its original area/stable member order, so
priority does not redefine the pair anchor or relative placement frame;
their six-plus-six limits, sampling, repairs, budgets and work charges remain
unchanged. Exact-state/material-profile rejection and every accepted full
geometry/material check also remain. This is a proposal-order heuristic,
not a validity test or a material-cost approximation used for acceptance.

All 126 optimized core tests pass: 123 prior tests unchanged and three new
ranking tests. The original area order first fails both boundary regressions
while passing stable ties. That source, executable and log are preserved.
The first pure-boundary revision passes the three new tests but fails three
existing exchange regressions. Its sources, executable and failed log remain.
Restoring the original member anchor within each selected pair resolves those
failures without changing their assertions. The new tests cover smaller upper parts ahead of larger interior parts,
stable equal extent/area ties, and the upper family's place in the existing
bounded pair lists. Their public fixture validates with the frozen CLI.
Twelve existing rejection-boundary outcomes pass another 24 frozen-CLI
checks. Strict lint/build, ten public outcomes, four CLI comparisons and five
pilot harness checks pass. Normal outcomes and common replays are exact
apart from wall time. All 156 formatted files reconstruct; the other 155
files and every non-ranking runtime block remain unchanged.

The planned 72-outcome pilot retains the preceding four jobs, both kerfs,
three seeds, rotating sequential three-arm blocks, eight physical CCD0 cores
and 60-second budgets. Block, case, scoring and measurement functions are
AST-identical. Its plan is committed before measurement. Passing this
qualification provides no quality result: the original full 13-job gate is
still required if the pilot passes. Production, held-out data, published
preview and README claims remain unchanged. H2/H5 remain open at 60%.

[Checks](h5-boundary-priority-preparation-20261018/checks.json),
[expected failures](h5-boundary-priority-preparation-20261018/expected-failure.json),
[ordering witness](h5-boundary-priority-preparation-20261018/order-checks.json),
[source reconstruction](h5-boundary-priority-preparation-20261018/reconstruction.json),
[archive integrity](h5-boundary-priority-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-boundary-priority-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'all_functional_checks_pass':True,'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size}))
