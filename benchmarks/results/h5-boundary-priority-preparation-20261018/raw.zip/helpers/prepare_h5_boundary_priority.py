"""Add boundary-order regressions against the unchanged area-first member order."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-boundary-priority-probe-20261018'
old=root/'output/h5-material-profile-probe-20261018';out.mkdir()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(root/'benchmarks/results/h5-frontier-observer-20261018/layout-checks.json')['attempts_with_height_family']==0
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
original=path.read_text(encoding='utf-8');text=original
start=text.index('        incoming_keys.sort_by(');end=text.index('        let mut fill',start)
old_sort=text[start:end]
helper='''fn rank_incoming(layout: &JLayout, keys: &mut [PItemKey]) {
    keys.sort_by(|&a, &b| {
        layout.placed_items()[b]
            .item()
            .area()
            .total_cmp(&layout.placed_items()[a].item().area())
    });
}

'''
assert text.count('struct Proposal {')==1
text=text.replace('struct Proposal {',helper+'struct Proposal {')
text=text.replace(old_sort,'        rank_incoming(&sep.layout, &mut incoming_keys);\n')
assert text.replace(helper,'').replace('        rank_incoming(&sep.layout, &mut incoming_keys);\n',old_sort)==original
tests='''
    // BEGIN boundary-priority tests
    fn boundary_priority_fixture() -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.name = "Boundary priority witness".into();
        job.parts = vec![rectangle("anchor",94.0,94.0),rectangle("large",40.0,20.0),
            rectangle("wide",20.0,5.0),rectangle("small",5.0,5.0)];
        job.parts[1].quantity=2;job.parts[3].quantity=2;
        layout.placements=[("anchor",0,0,[2.0,2.0]),("large",0,1,[2.0,10.0]),
            ("large",1,1,[47.0,10.0]),("wide",0,1,[2.0,80.0]),
            ("small",0,1,[40.0,80.0]),("small",1,1,[50.0,80.0])]
            .into_iter().map(|(id,copy_index,sheet,translation)|Placement {
                part_id:id.into(),copy_index,sheet_id:format!("sheet-{sheet}"),
                transform:RigidTransform {translation,..Default::default()}
            }).collect();
        assert!(validate(&job,&layout).unwrap().valid);
        (job,layout)
    }

    #[test]
    fn boundary_priority_prefers_high_small_parts_over_low_large_parts() {
        let (job,layout)=boundary_priority_fixture();
        let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
        let source=sheets[1].layout();let mut keys:Vec<_>=source.placed_items().keys().collect();
        let before=keys.clone();rank_incoming(source,&mut keys);
        let names:Vec<_>=keys.iter().map(|k|job.parts[model.part[source.placed_items()[*k].item().idx()]].id.as_str()).collect();
        eprintln!("BOUNDARY_ORDER_WITNESS {}",serde_json::json!({"job":job,"layout":layout,"names":names}));
        assert_eq!(names,vec!["wide","small","small","large","large"],"Boundary parts must precede larger interior parts");
        let mut a=before;let mut b=keys;a.sort();b.sort();assert_eq!(a,b);
    }

    #[test]
    fn boundary_priority_preserves_equal_extent_area_ties() {
        let (job,layout)=boundary_priority_fixture();
        let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
        let source=sheets[1].layout();let mut keys:Vec<_>=source.placed_items().iter()
            .filter(|(_,p)|job.parts[model.part[p.item().idx()]].id=="small").map(|(k,_)|k).collect();
        assert_eq!(keys.len(),2);keys.reverse();let before=keys.clone();
        let a=&source.placed_items()[keys[0]];let b=&source.placed_items()[keys[1]];
        assert_eq!(a.shape().bbox().x_max,b.shape().bbox().x_max);assert_eq!(a.item().area(),b.item().area());
        rank_incoming(source,&mut keys);assert_eq!(keys,before,"Equal boundary/area ties must retain their input order");
    }

    #[test]
    fn boundary_priority_pair_choices_start_with_the_high_family() {
        let (job,layout)=boundary_priority_fixture();
        let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
        let source=sheets[1].layout();let mut keys:Vec<_>=source.placed_items().keys().collect();
        rank_incoming(source,&mut keys);let pairs=incoming_pairs(source,&keys);
        assert!(!pairs.is_empty() && pairs.len()<=6);
        let first:Vec<_>=pairs[0].iter().map(|k|job.parts[model.part[source.placed_items()[*k].item().idx()]].id.as_str()).collect();
        assert_eq!(first,vec!["small","small"],"Boundary family must enter the bounded pair choices first");
        let mixed=mixed_incoming_pairs(source,&keys);assert!(!mixed.is_empty() && mixed.len()<=6);
        assert!(mixed[0].iter().any(|k|job.parts[model.part[source.placed_items()[*k].item().idx()]].id=="wide"));
    }
    // END boundary-priority tests
'''
pos=text.rindex('\n}');text=text[:pos]+tests+text[pos:]
path.write_text(text,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),
    'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
    'changed_files':[rel],'added_files':{},'production_digest':source_digest(),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),
    'target':str(root/'output/h5-boundary-priority-target-20261018'),'unchanged_prior_tests':123,'new_tests':3,
    'sort_extraction_reverses_exactly':True,'boundary_ranking_installed':False,'held_out_access':False,'acceptance_guards_unchanged':True}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'sort-extraction.json').write_text(json.dumps({'original':old_sort,'extracted_helper':helper},indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
builder=(root/'output/build_h5_material_profile.py').read_text(encoding='utf-8').replace('h5-material-profile','h5-boundary-priority')
(root/'output/build_h5_boundary_priority.py').write_text(builder,encoding='utf-8',newline='\n')
print(json.dumps({'expected_tests':126,'prior_unchanged':123,'boundary_ranking_installed':False}))
