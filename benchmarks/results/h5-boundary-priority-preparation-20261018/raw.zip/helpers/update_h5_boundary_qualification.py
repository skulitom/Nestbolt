"""Reflect preserved original pair frames and the failed first revision in qualification."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1]
p=root/'scripts/h5_boundary_priority_pilot.py';s=p.read_text(encoding='utf-8')
old='sheet, then descending area, retaining stable equal ties. The existing six'
new='sheet, then descending area, retaining stable equal ties. Selected pairs\nretain the original area/stable member anchor order. The existing six'
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,encoding='utf-8',newline='\n')
ref=root/'scripts/h5_material_profile_pilot.py'
def fn(t,n):return next(x for x in ast.parse(t).body if isinstance(x,ast.FunctionDef) and x.name==n)
for n in ['blocks','summarize','case','measure']:assert ast.dump(fn(s,n))==ast.dump(fn(ref.read_text(encoding='utf-8'),n))
method=root/'output/h5-boundary-priority-probe-20261018/pilot-method.json';m=json.loads(method.read_bytes());m['runner_sha256']=sha256(p.read_bytes()).hexdigest()
method.write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'output/seal_h5_boundary_priority.py';s=p.read_text(encoding='utf-8')
s=s.replace("assert source['all_123_prior_tests_unchanged']", "assert source['original_frame_preserved_within_each_selected_pair']\nfailed=load(probe/'failed-boundary-order/failure.json');assert failed['tests_failed']==3\nassert digest(probe/'failed-boundary-order/authored-tests.exe')==failed['test_binary_sha256']\nassert digest(probe/'failed-boundary-order/core-tests.log')==failed['log_sha256']\nassert source['all_123_prior_tests_unchanged']")
s=s.replace("for name in helpers:files['helpers/'+name]=root/'output'/name", "helpers.extend(['repair_h5_boundary_pair_frames.py','build_h5_boundary_priority_frames.py','update_h5_boundary_qualification.py'])\nfor name in helpers:files['helpers/'+name]=root/'output'/name")
s=s.replace("'expected_two_failures_preserved':True", "'expected_two_failures_preserved':True,'first_three_regressions_preserved':True,'original_pair_frames_preserved':True")
s=s.replace("doc='''", "shutil.copyfile(probe/'failed-boundary-order/failure.json',out/'first-revision-failures.json')\n\ndoc='''")
s=s.replace('The existing same-item and mixed-pair generators consume that ordered list;', 'The existing same-item and mixed-pair generators consume that ordered list.\nEach selected pair then retains its original area/stable member order, so\npriority does not redefine the pair anchor or relative placement frame;')
s=s.replace('The new tests cover smaller upper parts ahead of larger interior parts,', 'The first pure-boundary revision passes the three new tests but fails three\nexisting exchange regressions. Its sources, executable and failed log remain.\nRestoring the original member anchor within each selected pair resolves those\nfailures without changing their assertions. The new tests cover smaller upper parts ahead of larger interior parts,')
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'output/record_h5_boundary_priority_preparation.py';s=p.read_text(encoding='utf-8')
s=s.replace('by upper extent before area, retaining stable ties and the existing bounded\npair generators.', 'by upper extent before area, retaining stable ties and the existing bounded\npair generators. Selected pairs keep their original member anchor order.')
s=s.replace('expected and are preserved; all three new tests pass afterwards.', 'expected and are preserved; all three new tests pass afterwards. The first\nrevision also exposes three existing exchange regressions; preserving pair\nanchors resolves them with unchanged assertions and retained failures.')
p.write_text(s,encoding='utf-8',newline='\n');print('Updated qualification description and method hash; no scoring or test assertions changed.')
