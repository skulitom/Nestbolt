"""Check actual ordering witnesses and the preserved rejection boundaries."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-boundary-priority-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_checks_passed'];out=probe/'order-checks';out.mkdir()
target=Path(load(probe/'preparation.json')['target']);bins=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1;binary=bins[0]
command=[str(binary),'boundary_priority','--nocapture','--test-threads=1']
r=subprocess.run(command,capture_output=True,timeout=120)
(out/'stdout.log').write_bytes(r.stdout);(out/'stderr.log').write_bytes(r.stderr)
(out/'command.json').write_text(json.dumps({'command':command,'exit_code':r.returncode},indent=2)+'\n',encoding='utf-8',newline='\n')
assert r.returncode==0 and '3 passed; 0 failed' in r.stdout.decode()
rows=[json.loads(s.removeprefix('BOUNDARY_ORDER_WITNESS ')) for s in r.stderr.decode().splitlines() if s.startswith('BOUNDARY_ORDER_WITNESS ')];assert len(rows)==1
row=rows[0];assert row['names']==['wide','small','small','large','large']
for name in ['job','layout']:(out/(name+'.json')).write_text(json.dumps(row[name],indent=2)+'\n',encoding='utf-8',newline='\n')
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
args=[str(cli),'validate','--job',str(out/'job.json'),'--layout',str(out/'layout.json')]
r=subprocess.run(args,capture_output=True,timeout=60);(out/'validate-stdout.json').write_bytes(r.stdout);(out/'validate-stderr.log').write_bytes(r.stderr)
checked=json.loads(r.stdout);assert r.returncode==0 and checked['valid']
shutil.copyfile(binary,out/'authored-tests.exe');shutil.copyfile(__file__,out/'check.py')
checks={'all_checks_passed':True,'new_order_tests':3,'public_CLI_validations':1,'order':row['names'],
    'stable_equal_ties_and_bounded_pair_coverage_checked':True,'CLI_sha256':expected,'test_binary_sha256':digest(binary),
    'quality_claim':False,'new_measured_searches':0}
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(checks))
