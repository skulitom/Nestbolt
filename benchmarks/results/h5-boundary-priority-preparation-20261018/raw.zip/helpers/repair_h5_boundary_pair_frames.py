"""Preserve failed pure-boundary ordering; keep original anchors within chosen pairs."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import difflib,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-boundary-priority-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(probe/'preparation.json');failed=probe/'failed-boundary-order';failed.mkdir()
assert (probe/'build-failure.json').exists() and not (probe/'build.json').exists()
log=(probe/'core-tests.log').read_text(encoding='utf-8');assert '123 passed; 3 failed' in log
names=['balanced_pair_moves_two_incoming_and_three_returns','balanced_pair_preserves_frozen_prefix','productive_exchange_keeps_same_inventory_when_material_decreases']
for name in names:assert f'test sheets::vstrip::exchange::tests::{name} ... FAILED' in log
for rel in plan['changed_files']:
    p=failed/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(probe/'candidate'/rel,p)
for name in ['core-tests.log','format.log','progress.json','build-failure.json','apply.py','candidate.patch','source-checks.json','ranking-substitution.json']:
    shutil.copyfile(probe/name,failed/name)
binary=list((Path(plan['target'])/'release/deps').glob('nestbolt_core-*.exe'));assert len(binary)==1;shutil.copyfile(binary[0],failed/'authored-tests.exe')
record={'utc':datetime.now(timezone.utc).isoformat(),'tests_passed':123,'tests_failed':3,'failed_tests':names,
    'original_tests_passed':120,'new_order_tests_passed':3,'test_binary_sha256':digest(failed/'authored-tests.exe'),
    'log_sha256':digest(failed/'core-tests.log'),'source_sha256':digest(failed/plan['changed_files'][0]),
    'inference':'Per-member priority also reverses a same-family pair anchor when its higher member originally follows the lower member. Restore original area/stable member order inside each selected pair while retaining boundary priority between choices. Full original tests must pass; no assertion is relaxed.',
    'quality_measurement_started':False}
(failed/'failure.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
rel=plan['changed_files'][0];p=probe/'candidate'/rel;before=p.read_text(encoding='utf-8');s=before;changes=[]
def replace(a,b):
    global s
    assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b);changes.append((a,b))
helper='''// Priority selects which members are considered. The original area/stable
// order still defines the anchor and relative frame of each chosen pair.
fn preserve_pair_frames(pairs: &mut [Vec<PItemKey>], original_order: &[PItemKey]) {
    for pair in pairs {
        pair.sort_by_key(|key| original_order.iter().position(|old| old == key).expect("source member"));
    }
}

'''
replace('struct Proposal {',helper+'struct Proposal {')
replace('''        rank_incoming(&sep.layout, &mut incoming_keys);
''','''        let mut original_order = incoming_keys.clone();
        original_order.sort_by(|&a, &b| sep.layout.placed_items()[b].item().area()
            .total_cmp(&sep.layout.placed_items()[a].item().area()));
        rank_incoming(&sep.layout, &mut incoming_keys);
''')
replace('''        let same_pairs = incoming_pairs(&sep.layout, &incoming_keys);
        let mixed_pairs = mixed_incoming_pairs(&sep.layout, &incoming_keys);
''','''        let mut same_pairs = incoming_pairs(&sep.layout, &incoming_keys);
        let mut mixed_pairs = mixed_incoming_pairs(&sep.layout, &incoming_keys);
        preserve_pair_frames(&mut same_pairs, &original_order);
        preserve_pair_frames(&mut mixed_pairs, &original_order);
''')
reverse=s
for a,b in reversed(changes):assert reverse.count(b)==1;reverse=reverse.replace(b,a)
assert reverse==before and s.split('#[cfg(test)]',1)[1]==before.split('#[cfg(test)]',1)[1]
p.write_text(s,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=probe/'candidate',check=True)
(probe/'pair-frame-substitutions.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
parent=(Path(plan['old_probe'])/'candidate'/rel).read_text(encoding='utf-8');after=p.read_text(encoding='utf-8')
(probe/'candidate.patch').write_text(''.join(difflib.unified_diff(parent.splitlines(True),after.splitlines(True),fromfile='material-profile/'+rel,tofile='boundary-priority/'+rel)),encoding='utf-8',newline='\n')
checks=load(probe/'source-checks.json');checks.update(original_pair_member_frames_preserved=True,
    first_three_regressions_preserved=True,pair_frame_changes_reverse_exactly=True,source_sha256=digest(p))
(probe/'source-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(__file__,probe/'repair-pair-frames.py')
# The first attempt's sources/binary/logs remain in failed-boundary-order.
# A distinct build log directory prevents overwriting its records.
builder=(root/'output/build_h5_boundary_priority.py').read_text(encoding='utf-8')
builder=builder.replace("plan=load(out/'preparation.json');records=[]", "plan=load(out/'preparation.json');records=[]\nlogs=out/'frame-preserving-build';logs.mkdir()")
builder=builder.replace("out/(label+'.log')", "logs/(label+'.log')").replace("write(out/'progress.json',records)","write(logs/'progress.json',records)")
builder=builder.replace("write(out/'build-failure.json'", "write(logs/'build-failure.json'")
builder=builder.replace("guards();shutil.copyfile(Path(plan['target'])", "guards();\n    for name in ['format','core-tests','clippy','observer']:shutil.copyfile(logs/(name+'.log'),out/(name+'.log'))\n    shutil.copyfile(Path(plan['target'])")
path=root/'output/build_h5_boundary_priority_frames.py';compile(builder,str(path),'exec');path.write_text(builder,encoding='utf-8',newline='\n')
print(json.dumps({'preserved_failures':names,'pair_member_anchor_order_restored':True,'original_tests_changed':False,'new_quality_run':False}))
