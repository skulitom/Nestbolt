"""Make the completed build index current while preserving the first failure."""
from pathlib import Path
import json,shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-boundary-priority-probe-20261018'
build=json.loads((probe/'build.json').read_bytes());assert build['all_checks_passed']
assert (probe/'progress.json').read_bytes()==(probe/'failed-boundary-order/progress.json').read_bytes()
assert (probe/'build-failure.json').read_bytes()==(probe/'failed-boundary-order/build-failure.json').read_bytes()
shutil.copyfile(probe/'frame-preserving-build/progress.json',probe/'progress.json')
(probe/'build-failure.json').rename(probe/'first-build-failure.json')
shutil.copyfile(__file__,probe/'finalize-build.py')
print('Current build index updated; the failed first source, executable and logs remain.')
