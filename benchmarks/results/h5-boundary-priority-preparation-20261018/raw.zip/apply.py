"""Install upper-boundary-first ordering after preserving its failing regressions."""
from pathlib import Path
from hashlib import sha256
import difflib,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-boundary-priority-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');red=load(out/'before-boundary-ranking/checks.json');assert red['expected_runtime_failure']
assert digest(out/'before-boundary-ranking/expected-failure.log')==red['log_sha256']
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
before=path.read_text(encoding='utf-8');assert path.read_bytes()==(out/'before-boundary-ranking'/rel).read_bytes()
start=before.index('fn rank_incoming(');end=before.index('struct Proposal {',start);original=before[start:end]
replacement='''// In the rotated strip frame, rightmost extent is original sheet height.
// Reach boundary parts before larger interior parts; equal geometry/area ties
// retain their input order. This changes proposal order, never acceptance.
fn rank_incoming(layout: &JLayout, keys: &mut [PItemKey]) {
    keys.sort_by(|&a, &b| {
        let a = &layout.placed_items()[a];
        let b = &layout.placed_items()[b];
        b.shape().bbox().x_max.total_cmp(&a.shape().bbox().x_max)
            .then_with(|| b.item().area().total_cmp(&a.item().area()))
    });
}

'''
after=before[:start]+replacement+before[end:];assert after.replace(replacement,original)==before
assert after.split('#[cfg(test)]',1)[1]==before.split('#[cfg(test)]',1)[1]
path.write_text(after,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
(out/'ranking-substitution.json').write_text(json.dumps({'before':original,'after':replacement},indent=2)+'\n',encoding='utf-8',newline='\n')
parent=(Path(plan['old_probe'])/'candidate'/rel).read_text(encoding='utf-8');current=path.read_text(encoding='utf-8')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(parent.splitlines(True),current.splitlines(True),fromfile='material-profile/'+rel,tofile='boundary-priority/'+rel)),encoding='utf-8',newline='\n')
checks={'boundary_ranking_installed':True,'prior_tests_unchanged':123,'new_tests':3,
    'ranking_substitution_reverses_exactly':True,'test_source_unchanged_from_expected_failure':True,
    'existing_choice_limits_and_generators_unchanged':True,'existing_geometry_material_guards_unchanged':True,
    'existing_deadlines_work_charges_and_coefficients_unchanged':True,'normal_mode_unchanged':True,
    'source_sha256':digest(path),'production_changed':False,'quality_claim':False}
(out/'source-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'apply.py');print(json.dumps(checks))
