"""Verify that only the incoming comparator and three new tests change."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-boundary-priority-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');assert load(out/'build.json')['all_checks_passed']
rel=plan['changed_files'][0];parent=Path(plan['old_probe'])/'candidate'
prior=(parent/rel).read_text(encoding='utf-8');current=(out/'candidate'/rel).read_text(encoding='utf-8')
old_runtime,old_tests=prior.split('#[cfg(test)]',1);runtime,tests=current.split('#[cfg(test)]',1)
start=runtime.index('// In the rotated strip frame');end=runtime.index('struct Proposal {',start)
restored=runtime[:start]+runtime[end:]
start=restored.index('        let mut original_order = incoming_keys.clone();')
end=restored.index('        let mut fill',start)
restored=restored[:start]+load(out/'sort-extraction.json')['original']+restored[end:]
start=restored.index('        let mut same_pairs = incoming_pairs(')
end=restored.index('        let mut choices =',start)
old_start=old_runtime.index('        let same_pairs = incoming_pairs(')
old_end=old_runtime.index('        let mut choices =',old_start)
restored=restored[:start]+old_runtime[old_start:old_end]+restored[end:]
assert restored==old_runtime
test_prefix=tests.split('    // BEGIN boundary-priority tests',1)[0].rstrip()
assert test_prefix==old_tests.rsplit('\n}',1)[0].rstrip()
work=root/'output/h5-boundary-priority-reconstruction-20261018';shutil.copytree(out/'candidate',work)
s=(out/'before-boundary-ranking'/rel).read_text(encoding='utf-8');change=load(out/'ranking-substitution.json')
assert s.count(change['before'])==1;s=s.replace(change['before'],change['after'])
(work/rel).write_text(s,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=work,check=True)
assert (work/rel).read_bytes()==(out/'failed-boundary-order'/rel).read_bytes()
s=(work/rel).read_text(encoding='utf-8')
for before,after in load(out/'pair-frame-substitutions.json'):
    assert s.count(before)==1;s=s.replace(before,after)
(work/rel).write_text(s,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=work,check=True)
files=[]
for row in plan['old_source_files']['candidate']:
    name=row['path'];assert digest(parent/name)==row['sha256']
    assert (work/name).read_bytes()==(out/'candidate'/name).read_bytes()
    if name!=rel:assert digest(out/'candidate'/name)==row['sha256']
    files.append(name)
record={'all_checks_passed':True,'all_123_prior_tests_unchanged':True,'other_runtime_exact':True,
    'all_formatted_reconstructed_files_exact':True,'reconstructed_files':len(files),'unchanged_other_files':len(files)-1,
    'material_profile_and_validator_sources_unchanged':True,'only_member_order_changes':True,
    'original_frame_preserved_within_each_selected_pair':True,'failed_first_revision_reconstructed_exactly':True,
    'choice_generators_limits_budgets_acceptance_work_charges_unchanged':True,'new_searches':0}
(out/'reconstruction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'check-source.py');print(json.dumps(record))
