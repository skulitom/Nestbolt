"""Exact new child graphs and complete root clique bounds for25 arrangements."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-frontier-refined-graphs-20261106'
REF=ROOT/'output/h5-first57-frontier-refined-covers-20261106';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106';PAIR=ROOT/'output/h5-first57-clearance-pair-edges-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def members(mask):
    while mask:
        b=mask&-mask;yield b.bit_length()-1;mask-=b
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for base in [REF,AUG,PAIR]:assert load(base/'audit/checks.json')['passed']
selection=load(REF/'audit/graph-candidates.json');assert len(selection)==25 and all(r['source_selection']['empty_sites']!=[4,5,10] for r in selection)
inputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_graph_helpers_20261106.py',ROOT/'output/prepare_h5_refined_conflict_graph_20261106.py',SOURCE/'geometry-domains.json',REF/'plan.json',REF/'audit/graph-candidates.json']
inputs += [base/name for base in [REF,AUG,PAIR] for name in ['audit/plan.json','audit/checks.json']]
for r in selection:
    row=r['source_selection'];ci=r['refinement_index']
    inputs += [REF/f'choice-{ci:02d}'/name for name in ['nodes.json','retained.json','checks.json']]
    inputs += [base/f"choice-{row[key]:02d}.json" for base,key in [(BR,'choice_index'),(INS,'insert_choice_index'),(AUG,'augmentation_index'),(PAIR,'clearance_edge_index')]]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':selection,
    'per_case_graph_cap_seconds':10,'per_case_complete_cap_seconds':12,'global_graph_cap_seconds':60,'preparation_cap_seconds':70,'maximum_process_seconds':80,
    'required_job_clearance_mm':0.2,'square_radius_um':140,'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,
    'method':'Construct each new refined necessary graph with every inherited parent zero-single, union and clearance edge, plus exact140 micrometre square child conflicts. Preserve every retained source child and alias. Save every graph bit. Derive complete family conflict-clique covers from inherited covers and deterministic ascending/descending-degree greedy orders. Only an independently verified complete cover below8 may exclude a fixed arrangement. All25 domains are new; the previously refined[4,5,10] case is omitted. No tree is run here.'})
results=[]
for selection_row in selection:
    ci=selection_row['refinement_index'];row=selection_row['source_selection'];case_started=time.perf_counter()
    folder=OUT/f'choice-{ci:02d}';folder.mkdir();ref_folder=REF/f'choice-{ci:02d}'
    paths=[BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json",AUG/f"choice-{row['augmentation_index']:02d}.json",PAIR/f"choice-{row['clearance_edge_index']:02d}.json"]
    br,ins,augmentation,pair=map(load,paths);parents=br['nodes']+ins['nodes'];oldoffset=len(br['nodes'])
    allnodes=load(ref_folder/'nodes.json');retained=load(ref_folder/'retained.json')
    ids=retained['bracket']+retained['insert'];nodes=[allnodes[n] for n in ids];offset=len(retained['bracket'])
    geometry=load(SOURCE/'geometry-domains.json')
    def matrix(cells,padding):
        n=len(cells);result=np.eye(n,dtype=bool);bounds=np.array([v['bounds_um'] for v in cells],dtype=np.int64)
        groups={g:np.array([i for i,v in enumerate(cells) if v['geometry']==g],dtype=np.int64) for g in range(10)}
        for ga in range(10):
            for gb in range(ga,10):
                assert time.perf_counter()-case_started<10 and time.perf_counter()-started<60
                ia,ib=groups[ga],groups[gb]
                if not len(ia) or not len(ib):continue
                a,b=bounds[ia],bounds[ib]
                lx=b[None,:,0]-a[:,None,2];ly=b[None,:,1]-a[:,None,3]
                ux=b[None,:,2]-a[:,None,0];uy=b[None,:,3]-a[:,None,1]
                clash=np.zeros((len(ia),len(ib)),dtype=bool)
                for ra in geometry[ga]['inner_rectangles_um']:
                    for rb in geometry[gb]['inner_rectangles_um']:
                        clash |= ((ra[0]-rb[2]-padding<lx)&(ra[1]-rb[3]-padding<ly)&(ux<ra[2]-rb[0]+padding)&(uy<ra[3]-rb[1]+padding))
                result[np.ix_(ia,ib)] |= clash;result[np.ix_(ib,ia)] |= clash.T
        return result
    parent_graph=matrix(parents,0)
    for a,b in augmentation['added_conflict_edges']+pair['added_conflict_edges']:parent_graph[a,b]=parent_graph[b,a]=True
    parent_ids=np.array([n['parent_node'] for n in nodes],dtype=np.int64)
    inherited=parent_graph[np.ix_(parent_ids,parent_ids)]
    single=matrix(nodes,140);graph=inherited|single
    new=np.triu(graph&~inherited,1);new_count=int(np.count_nonzero(new))
    assert np.all(graph==graph.T) and np.all(np.diag(graph))
    sample=list(map(int,next(zip(*np.nonzero(new))))) if new_count else None
    original=[]
    for f,groups in enumerate([br['cliques'],ins['insert_cliques']]):
        family=[]
        for group in groups:
            parent_set={n+(oldoffset if f else 0) for n in group['nodes']}
            cells=[i for i,n in enumerate(nodes) if n['parent_node'] in parent_set]
            if cells:family.append(cells)
        original.append(family)
    assert sorted(n for group in original[0] for n in group)==list(range(offset))
    assert sorted(n for group in original[1] for n in group)==list(range(offset,len(nodes)))
    for name,m in [('conflicts.bin',graph),('inherited.bin',inherited)]: (folder/name).write_bytes(np.packbits(m,axis=1,bitorder='little').tobytes())
    write(folder/'nodes.json',nodes);write(folder/'initial-covers.json',original)
    masks=[int.from_bytes(v.tobytes(),'little') for v in np.packbits(graph,axis=1,bitorder='little')]
    root_covers=[]
    for f,seed in enumerate(original):
        vertices=list(range(offset)) if f==0 else list(range(offset,len(nodes)))
        family_mask=sum(1<<n for n in vertices);best=seed
        for order in [vertices,sorted(vertices,key=lambda v:(-(masks[v]&family_mask).bit_count(),v))]:
            if len(best)<8:break
            groups=[]
            for v in order:
                fitting=[i for i,g in enumerate(groups) if not g&~masks[v]]
                if fitting:
                    i=max(fitting,key=lambda i:(groups[i].bit_count(),-i));groups[i]|=1<<v
                else:groups.append(1<<v)
            if len(groups)<len(best):best=[list(members(g)) for g in groups]
        root_covers.append(best)
    write(folder/'root-covers.json',root_covers)
    elapsed=time.perf_counter()-case_started
    checks={'refinement_index':ci,'source_selection':row,'compact_nodes':len(nodes),'bracket_nodes':offset,'insert_nodes':len(nodes)-offset,
        'row_bytes':(len(nodes)+7)//8,'parent_nodes':len(parents),'all_unordered_pairs':len(nodes)*(len(nodes)-1)//2,
        'genuinely_new_child_conflicts':new_count,'new_conflict_example':sample,'initial_clique_counts':list(map(len,original)),
        'root_clique_counts':list(map(len,root_covers)),'diagnostic_excluded':any(len(c)<8 for c in root_covers),
        'conflict_bytes_sha256':digest(folder/'conflicts.bin'),'inherited_bytes_sha256':digest(folder/'inherited.bin'),
        'case_seconds':elapsed,'complete_case_cap_overrun_seconds':max(0,elapsed-12)}
    write(folder/'checks.json',checks);results.append(checks);assert time.perf_counter()-started<70
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':results,
    **{k:sum(r[k] for r in results) for k in ['compact_nodes','all_unordered_pairs','genuinely_new_child_conflicts','complete_case_cap_overrun_seconds']},
    'diagnostic_excluded_cases':[r['source_selection']['empty_sites'] for r in results if r['diagnostic_excluded']],
    'independent_graph_audit_pending':True,'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
print({k:v for k,v in load(OUT/'checks.json').items() if k!='choices'})
