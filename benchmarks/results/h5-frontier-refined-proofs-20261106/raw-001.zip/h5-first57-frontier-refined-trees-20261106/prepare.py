"""Fresh bounded joint trees for the25 newly refined arrangements."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-frontier-refined-trees-20261106'
GRAPHS=ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def members(mask):
    while mask:
        b=mask&-mask;yield b.bit_length()-1;mask-=b
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(GRAPHS/'audit/checks.json')['passed']
selection=load(GRAPHS/'audit/stronger-tree-candidates.json');assert len(selection)==25 and all(r['genuinely_new_child_conflicts']>0 and r['source_selection']['empty_sites']!=[4,5,10] for r in selection)
inputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_refined_tree_helpers_20261106.py',ROOT/'output/prepare_h5_refined_anchor_tree_20261106.py',GRAPHS/'audit/plan.json',GRAPHS/'audit/checks.json',GRAPHS/'audit/stronger-tree-candidates.json']
inputs += [GRAPHS/f"choice-{r['refinement_index']:02d}"/name for r in selection for name in ['checks.json','nodes.json','conflicts.bin','root-covers.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'selection':selection,'per_case_search_seconds':1.6,'per_case_complete_cap_seconds':2,'maximum_expanded_nodes_per_case':1500,
    'global_search_seconds':45,'preparation_cap_seconds':55,'maximum_process_seconds':65,'required_job_clearance_mm':0.2,
    'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,
    'method':'Run one fresh joint include/skip proof per newly refined arrangement using the complete independently certified child cover and every-pair-audited graph. Each has genuinely new source constraints. Keep exact candidate sets, mandatory support proofs and explicit open cutoff/witness leaves. Fresh1.6/2-second case caps,1500nodes and45/55/65 global caps. Only fully closed independently replayed trees exclude fixed29/current-cog poses at required0.2mm clearance. The previously refined[4,5,10] case stays closed and is omitted.'})
results=[]
for tree_index,selection_row in enumerate(selection):
    case_started=time.perf_counter();deadline=min(started+45,case_started+1.6)
    row=selection_row['source_selection'];graph_folder=GRAPHS/f"choice-{selection_row['refinement_index']:02d}"
    nodes=load(graph_folder/'nodes.json');offset=selection_row['retained_bracket_children'];n=len(nodes);universe=(1<<n)-1
    rowbytes=(n+7)//8;raw=(graph_folder/'conflicts.bin').read_bytes();assert len(raw)==rowbytes*n
    conflicting={i:int.from_bytes(raw[i*rowbytes:(i+1)*rowbytes],'little') for i in range(n)}
    compatible={i:universe&~conflicting[i] for i in range(n)}
    original=[[sum(1<<n for n in group) for group in cover] for cover in load(graph_folder/'root-covers.json')]
    root_available=[(1<<offset)-1,universe^((1<<offset)-1)]
    graph_complete=True;records=[];witness=None;expanded=0
    def cover(family,mask,need,seed):
        options=[[g&mask for g in partition if g&mask] for partition in [original[family],seed]]
        best=min(options,key=len)
        if len(best)<need:return best
        vertices=list(members(mask))
        for order in [vertices,sorted(vertices,key=lambda n:(-(conflicting[n]&mask).bit_count(),n))]:
            groups=[]
            for v in order:
                options=[i for i,g in enumerate(groups) if not g&~conflicting[v]]
                if options:
                    i=max(options,key=lambda i:(groups[i].bit_count(),-i));groups[i]|=1<<v
                else:groups.append(1<<v)
            if len(groups)<len(best):best=groups
            if len(best)<need:break
        return best
    def visit(available,chosen,seeds):
        global expanded,witness
        index=len(records);record={'node':index,'expanded':False,'propagation':[]};records.append(record)
        def opened(reason):
            record.update({'kind':'open','reason':reason,'case_elapsed':time.perf_counter()-case_started,
                           'global_elapsed':time.perf_counter()-started});return index
        if not graph_complete:return opened('graph_preparation_limit')
        if witness is not None:return opened('earlier_joint_graph_witness')
        if time.perf_counter()>=deadline or expanded>=1500:return opened('time_or_expansion_limit')
        record['expanded']=True;expanded+=1;available=list(available);seeds=[list(s) for s in seeds]
        while True:
            if time.perf_counter()>=deadline:return opened('time_or_expansion_limit')
            need=[8-len(c) for c in chosen]
            if need==[0,0]:
                witness=[list(c) for c in chosen];record.update({'kind':'open_graph_witness','witness':witness});return index
            groups=[cover(f,available[f],need[f],seeds[f]) for f in range(2)];seeds=groups
            for f in range(2):
                if len(groups[f])<need[f]:
                    record.update({'kind':'closed_count_cover','family':f,'cover':[list(members(g)) for g in groups[f]]});return index
            changed=False
            for mf in range(2):
                if need[mf]==0 or len(groups[mf])!=need[mf]:continue
                step={'mandatory_family':mf,'cover':[list(members(g)) for g in groups[mf]],'removals':[]}
                empty_group=False
                for f in range(2):
                    for value in list(members(available[f])):
                        for gi,g in enumerate(groups[mf]):
                            current=g&available[mf]
                            assert current
                            if current&(1<<value):continue
                            if not current&compatible[value]:
                                step['removals'].append([f,value,gi]);available[f]&=~(1<<value);changed=True
                                empty_group=any(not (g&available[mf]) for g in groups[mf]);break
                        if empty_group:break
                    if empty_group:break
                if step['removals']:record['propagation'].append(step);break
            if not changed:break
        families=[f for f in range(2) if need[f]>0]
        family=min(families,key=lambda f:(len(groups[f])-need[f],min(g.bit_count() for g in groups[f]),f))
        group=min(groups[family],key=lambda g:(g.bit_count(),next(members(g))))
        values=list(members(group));record.update({'kind':'branch_clique','family':family,'clique':values,'children':[]})
        for value in values:
            child_available=[a&compatible[value] for a in available]
            child_chosen=[list(c) for c in chosen];child_chosen[family].append(value)
            if len(child_chosen[family])==8:child_available[family]=0
            record['children'].append({'value':value,'node':visit(child_available,child_chosen,groups)})
        skipped=list(available);skipped[family]&=~group
        record['skip']=visit(skipped,[list(c) for c in chosen],groups)
        return index
    root=visit(root_available,[[],[]],original)
    open_nodes=[r['node'] for r in records if r['kind'] in ['open','open_graph_witness']]
    elapsed=time.perf_counter()-case_started
    result={'source_selection':row,'refinement_index':selection_row['refinement_index'],'empty_sites':row['empty_sites'],'refined_bracket_node_count':offset,'graph_complete':True,
        'root':root,'records':records,'expanded_nodes':expanded,'open_nodes':open_nodes,'joint_graph_witness':witness,
        'case_seconds':elapsed,'case_complete_cap_overrun_seconds':max(0,elapsed-2),'diagnostic_excluded':not open_nodes}
    write(OUT/f'choice-{tree_index:02d}.json',result)
    summary={k:v for k,v in result.items() if k not in ['source_selection','records','open_nodes','joint_graph_witness']}|{'tree_records':len(records),'open_leaves':len(open_nodes),'graph_witness':witness is not None}
    results.append(summary);print(summary,flush=True);assert time.perf_counter()-started<55
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':results,
    'independent_tree_audit_pending':True,'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
