"""Complete new refined covers for the25 survivors not previously refined."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-frontier-refined-covers-20261106'
FRONT=ROOT/'output/h5-first57-refined-anchor-tree-20261106';OLD=ROOT/'output/h5-first57-clearance-pair-trees-20261106'
CLEAR=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for p in [FRONT/'audit/checks.json',CLEAR/'audit-v2/checks.json']:assert load(p)['passed']
remaining={tuple(r['empty_sites']) for r in load(FRONT/'audit/remaining-fixed29-choices.json')}
selection=[r for r in load(OLD/'plan.json')['selection'] if tuple(r['empty_sites']) in remaining and r['empty_sites']!=[4,5,10]]
assert len(selection)==25
inputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_refinement_helpers_20261106.py',ROOT/'output/prepare_h5_refined_anchor_cover_20261106.py',
    FRONT/'audit/plan.json',FRONT/'audit/checks.json',FRONT/'audit/remaining-fixed29-choices.json',OLD/'plan.json',
    CLEAR/'audit-v2/plan.json',CLEAR/'audit-v2/checks.json',CLEAR/'integer-source.json',CLEAR/'collision-polygons.json']
inputs += [base/f"choice-{row[key]:02d}.json" for row in selection for base,key in [(BR,'choice_index'),(INS,'insert_choice_index'),(CLEAR,'clearance_pruning_index')]]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'selection':selection,'already_refined_case_not_repeated':[4,5,10],'required_job_clearance_mm':0.2,'cog_diamond_radius_um':199,
    'per_case_pruning_scan_seconds':1.5,'per_case_complete_cap_seconds':2,'global_pruning_scan_seconds':45,'preparation_cap_seconds':50,'maximum_process_seconds':60,
    'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,
    'method':'Create complete midpoint Cartesian closed children for every retained parent of the other25 surviving arrangements. Preserve all boundaries and source aliases. Reuse only geometry/bounds queries within the same case with the same present cog sites. Remove a child only by an exact strict-corner certificate inside a present original cog collision polygon plus199 micrometre diamond. Unproved or scan-limited children remain. Independently audit all complete covers and source removals before graphs or clique bounds. The prior[4,5,10] process stays closed.'})
summaries=[]
for ci,row in enumerate(selection):
    case_started=time.perf_counter();folder=OUT/f'choice-{ci:02d}';folder.mkdir()
    br=load(BR/f"choice-{row['choice_index']:02d}.json");ins=load(INS/f"choice-{row['insert_choice_index']:02d}.json")
    parent=load(CLEAR/f"choice-{row['clearance_pruning_index']:02d}.json");oldnodes=br['nodes']+ins['nodes'];oldoffset=len(br['nodes'])
    source=load(CLEAR/'integer-source.json');scale=int(source['scaled_units_per_micrometre'])
    templates=load(CLEAR/'collision-polygons.json');polygons={g:[] for g in range(10)}
    for ti,t in enumerate(templates):
        for site in range(15):
            if site in row['empty_sites']:continue
            shift=list(map(int,source['sites'][site]['translation_scaled']))
            poly=[(int(x)+shift[0],int(y)+shift[1]) for x,y in t['vertices_scaled']]
            bounds=(min(x for x,y in poly),min(y for x,y in poly),max(x for x,y in poly),max(y for x,y in poly))
            polygons[t['geometry']].append((ti,site,poly,bounds))
    nodes=[];parents=[]
    for f,numbers in enumerate([parent['retained_bracket_nodes'],parent['retained_insert_nodes']]):
        for pn in numbers:
            p=oldnodes[pn];box=p['bounds_um'];axes=[]
            for lo,hi in zip(box[:2],box[2:]):
                axes.append([(lo,(lo+hi)//2),((lo+hi)//2,hi)] if hi-lo>=2 else [(lo,hi)])
            children=[]
            for (x0,x1),(y0,y1) in product(*axes):
                n=len(nodes);children.append(n)
                nodes.append({'node':n,'family':f,'geometry':p['geometry'],'parent_node':pn,'bounds_um':[x0,y0,x1,y1]})
            parents.append({'parent_node':pn,'children':children})
    removed=[];retained=[[],[]];cache={};queries=[]
    for node in nodes:
        key=(node['geometry'],tuple(node['bounds_um']))
        if key not in cache:
            qi=len(queries);cache[key]=qi;query={'query':qi,'geometry':node['geometry'],'bounds_um':node['bounds_um'],'certificate':None,'scan_limited':False}
            if time.perf_counter()-case_started>=1.5 or time.perf_counter()-started>=45:query['scan_limited']=True
            else:
                a,b,c,d=[v*scale for v in node['bounds_um']]
                for ti,site,poly,(px0,py0,px1,py1) in polygons[node['geometry']]:
                    if not (px0<a and py0<b and c<px1 and d<py1):continue
                    if all((v[0]-u[0])*(y-u[1])-(v[1]-u[1])*(x-u[0])>0
                           for u,v in zip(poly,poly[1:]+poly[:1]) for x,y in product([a,c],[b,d])):
                        query['certificate']={'template':ti,'site':site};break
            queries.append(query)
        qi=cache[key];node['query']=qi
        if queries[qi]['certificate'] is not None:removed.append(node['node'])
        else:retained[node['family']].append(node['node'])
        assert time.perf_counter()-started<50
    write(folder/'nodes.json',nodes);write(folder/'parents.json',parents);write(folder/'queries.json',queries)
    write(folder/'retained.json',{'bracket':retained[0],'insert':retained[1],'removed':removed})
    elapsed=time.perf_counter()-case_started
    summary={'refinement_index':ci,'source_selection':row,'parent_bracket_node_count':oldoffset,'parent_cells':len(parents),'child_cells':len(nodes),
        'unique_child_queries':len(queries),'source_certified_removed_children':len(removed),'retained_children':list(map(len,retained)),
        'limited_queries':sum(q['scan_limited'] for q in queries),'case_seconds':elapsed,'complete_case_cap_overrun_seconds':max(0,elapsed-2)}
    write(folder/'checks.json',summary);summaries.append(summary);assert time.perf_counter()-started<50
checks={'prepared':True,'seconds':time.perf_counter()-started,'choices':summaries,
    **{key:sum(r[key] for r in summaries) for key in ['parent_cells','child_cells','unique_child_queries','source_certified_removed_children','limited_queries','complete_case_cap_overrun_seconds']},
    'independent_geometry_audit_pending':True,'new_whole_arrangement_exclusions':0,'remaining_fixed29_choices':26,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print({k:v for k,v in checks.items() if k!='choices'})
