from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'prepare_h5_frontier_refined_graphs_20261106.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-frontier-refined-graphs-20261106','h5-first57-frontier-refined-graphs-v2-20261106')
s=s.replace("for base in [REF,AUG,PAIR]:assert load(base/'audit/checks.json')['passed']","for base in [AUG,PAIR]:assert load(base/'audit/checks.json')['passed']\nassert load(REF/'audit-v2/checks.json')['passed']")
s=s.replace("REF/'audit/graph-candidates.json'","REF/'audit-v2/graph-candidates.json'")
s=s.replace("inputs=[Path(__file__),","assert all(r['refinement_index']==i for i,r in enumerate(selection))\ninputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_graph_helpers_v2_20261106.py',ROOT/'output/prepare_h5_frontier_refined_graphs_20261106.py',ROOT/'output/h5-frontier-refinement-index-correction-20261106.json',REF/'audit-v2/plan.json',REF/'audit-v2/checks.json',")
s=s.replace("for base in [REF,AUG,PAIR] for name","for base in [AUG,PAIR] for name")
with (O/'prepare_h5_frontier_refined_graphs_v2_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_frontier_refined_graphs_20261106.py').read_text(encoding='utf-8')
s=s.replace('frontier-refined-graphs-process-20261106','frontier-refined-graphs-v2-process-20261106').replace('prepare_h5_frontier_refined_graphs_20261106.py','prepare_h5_frontier_refined_graphs_v2_20261106.py')
with (O/'run_h5_frontier_refined_graphs_v2_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared graph input correction with unchanged caps; prior preflight remains closed.')
