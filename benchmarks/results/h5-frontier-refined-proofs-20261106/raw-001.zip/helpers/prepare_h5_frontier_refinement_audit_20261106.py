from pathlib import Path
from textwrap import indent
O=Path(__file__).resolve().parent
s=(O/'audit_h5_refined_anchor_cover_20261106.py').read_text(encoding='utf-8')
body=s[s.index("paths=[BR/"):s.index("write(OUT/'plan.json'")]
body=body.replace("BASE/","folder/").replace("plan['parent_bracket_node_count']","case_checks['parent_bracket_node_count']")
prefix='''"""Independent complete child-cover and source-removal replay for all25 cases."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-frontier-refined-covers-20261106';OUT=BASE/'audit'
PROCESS=ROOT/'output/h5-first57-frontier-refined-covers-process-20261106'
FRONT=ROOT/'output/h5-first57-refined-anchor-tree-20261106';OLD=ROOT/'output/h5-first57-clearance-pair-trees-20261106'
CLEAR=ROOT/'output/h5-first57-clearance-cog-pruning-20261106';BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),ROOT/'output/prepare_h5_frontier_refinement_audit_20261106.py',ROOT/'output/audit_h5_refined_anchor_cover_20261106.py',
    JOB,BASE/'plan.json',BASE/'checks.json',PROCESS/'opened.json',PROCESS/'process.json',FRONT/'audit/remaining-fixed29-choices.json',OLD/'plan.json',
    CLEAR/'integer-source.json',CLEAR/'collision-polygons.json'}
for base in [BASE,FRONT/'audit',CLEAR/'audit-v2']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [FRONT/'audit',CLEAR/'audit-v2']:
    inputs.add(base/'checks.json');assert load(base/'checks.json')['passed']
process=load(PROCESS/'process.json');assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
plan=load(BASE/'plan.json');assert load(JOB)['clearance']==plan['required_job_clearance_mm']==0.2 and plan['cog_diamond_radius_um']==199 and 199**2<200**2
remaining={tuple(r['empty_sites']) for r in load(FRONT/'audit/remaining-fixed29-choices.json')}
selection=[r for r in load(OLD/'plan.json')['selection'] if tuple(r['empty_sites']) in remaining and r['empty_sites']!=[4,5,10]]
assert len(selection)==25 and plan['selection']==selection and plan['already_refined_case_not_repeated']==[4,5,10]
results=[]
for ci,row in enumerate(selection):
    folder=BASE/f'choice-{ci:02d}';case_checks=load(folder/'checks.json')
    assert case_checks['refinement_index']==ci and case_checks['source_selection']==row
    inputs.update(folder/name for name in ['checks.json','nodes.json','parents.json','queries.json','retained.json'])
'''
suffix='''    assert case_checks['parent_cells']==len(parents) and case_checks['child_cells']==len(nodes) and case_checks['source_certified_removed_children']==len(removed)
    assert case_checks['retained_children']==list(map(len,expected)) and case_checks['complete_case_cap_overrun_seconds']==max(0,case_checks['case_seconds']-2)
    results.append({'refinement_index':ci,'source_selection':row,'parent_cells_verified':len(parents),'closed_children_verified':len(nodes),
        'complete_axis_product_covers':areas,'unique_queries_verified':len(queries),'certified_child_removals':len(removed),
        'strict_corner_halfplane_checks':corner_checks,'retained_bracket_children':len(expected[0]),'retained_insert_children':len(expected[1]),
        'complete_case_cap_overrun_seconds':case_checks['complete_case_cap_overrun_seconds']})
write(OUT/'graph-candidates.json',results)
write(OUT/'remaining-fixed29-choices.json',load(FRONT/'audit/remaining-fixed29-choices.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Independently replay every closed Cartesian child cover and present-cog strict integer corner certificate for the25 previously unrefined survivors. Each parent is exactly covered, including shared boundaries, with unchanged source geometry and all aliases. Query caches are separate per case and each consumed certificate site must be present in that case. Remove only children proved below the original200 micrometre clearance by the audited199 micrometre diamond. Every unproved child remains. The previously refined[4,5,10] case is not repeated and remains in the full frontier.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':results,
    **{k:sum(r[k] for r in results) for k in ['parent_cells_verified','closed_children_verified','complete_axis_product_covers','unique_queries_verified','certified_child_removals','strict_corner_halfplane_checks','retained_bracket_children','retained_insert_children','complete_case_cap_overrun_seconds']},
    'continuous_covers_complete':True,'all_source_aliases_preserved':True,'required_job_clearance_mm':0.2,'new_zero_clearance_exclusion_claimed':False,
    'new_whole_arrangement_exclusions':0,'remaining_fixed29_choices':26,'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='choices'})
'''
with (O/'audit_h5_frontier_refined_covers_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+indent(body,'    ')+suffix)
print('Prepared independent25-case continuous-cover replay.')
