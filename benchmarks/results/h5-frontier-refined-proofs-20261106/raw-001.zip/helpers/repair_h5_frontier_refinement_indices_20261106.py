from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'output'
REF=O/'h5-first57-frontier-refined-covers-20261106';FAILED=O/'h5-first57-frontier-refined-graphs-20261106'
PROCESS=O/'h5-first57-frontier-refined-graphs-process-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(PROCESS/'process.json')['exit_code']==1 and load(PROCESS/'process.json')['closed']
assert sorted(p.name for p in FAILED.iterdir())==['prepare.py']
source=O/'audit_h5_frontier_refined_covers_20261106.py';s=source.read_text(encoding='utf-8')
s=s.replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'")
s=s.replace("for ci,row in enumerate(selection):","for case_index,row in enumerate(selection):")
s=s.replace("folder=BASE/f'choice-{ci:02d}'","folder=BASE/f'choice-{case_index:02d}'")
s=s.replace("case_checks['refinement_index']==ci","case_checks['refinement_index']==case_index")
s=s.replace("results.append({'refinement_index':ci","results.append({'refinement_index':case_index")
s=s.replace("inputs={Path(__file__),","inputs={Path(__file__),ROOT/'output/repair_h5_frontier_refinement_indices_20261106.py',ROOT/'output/h5-frontier-refinement-index-correction-20261106.json',ROOT/'output/audit_h5_frontier_refined_covers_20261106.py',REF_V1_PLAN,REF_V1_CHECKS,")
s=s.replace("OUT.mkdir();started=", "REF_V1_PLAN=BASE/'audit/plan.json';REF_V1_CHECKS=BASE/'audit/checks.json'\nOUT.mkdir();started=")
target=O/'audit_h5_frontier_refined_covers_v2_20261106.py'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
record={'utc':datetime.now(timezone.utc).isoformat(),'cause':'The audit outer loop used ci for case index, but the independently replayed inner child-cover loop also used ci. Geometry/corner/coverage checks and counts are correct; emitted refinement_index values incorrectly contain the last child node id. The consumer fails while hashing nonexistent choice3159 input, before writing its plan or constructing any graph.',
    'preserved_v1_audit':(REF/'audit').relative_to(ROOT).as_posix(),'preserved_failed_process':PROCESS.relative_to(ROOT).as_posix(),
    'failed_preparation_seconds':load(PROCESS/'process.json')['complete_process_seconds'],
    'graphs_constructed_before_failure':0,'proof_trees_run_before_failure':0,'original_geometry_preparation_repeated':False,
    'correction':'Use an independent case_index variable for selection and output metadata; replay all geometry checks in a separate audit-v2. Any corrected graph preparation uses a new versioned folder and unchanged caps; the failed process stays closed.',
    'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [source,REF/'audit/plan.json',REF/'audit/checks.json',REF/'audit/graph-candidates.json',FAILED/'prepare.py',PROCESS/'opened.json',PROCESS/'process.json',PROCESS/'stderr.txt']}}
with (O/'h5-frontier-refinement-index-correction-20261106.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print('Preserved audit index error and pre-graph failure; prepared independent audit-v2.')
