from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-frontier-refined-proofs-20261106';OUT=ROOT/'benchmarks/results'/NAME
REF=ROOT/'output/h5-first57-frontier-refined-covers-20261106'
FAILED=ROOT/'output/h5-first57-frontier-refined-graphs-20261106'
GRAPH=ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106'
TREE=ROOT/'output/h5-first57-frontier-refined-trees-20261106'
SYNC=ROOT/'output/h5-refined-cover-main-sync-20261106'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
cover=load(REF/'audit-v2/checks.json');graph=load(GRAPH/'audit/checks.json');tree=load(TREE/'audit/checks.json')
assert all(a['passed'] for a in [cover,graph,tree])
assert cover['certified_child_removals']==2794 and cover['closed_children_verified']==75416
assert graph['all_unordered_child_pairs_verified']==110803502 and graph['genuinely_new_child_conflicts']==6172577
assert tree['tree_records_verified']==11716 and tree['open_leaves']==1453 and tree['new_fixed29_choices_excluded']==tree['new_graph_witnesses']==0
assert len(tree['new_cutoff_cases'])==25 and tree['remaining_fixed29_choices']==26
assert load(SYNC/'receipt.json')['new_main']=='3046006dc0778f347e0cb4f0479df9dee8717aea'
stage_names=['frontier-refined-covers','frontier-refined-graphs','frontier-refined-graphs-v2','frontier-refined-trees']
process_folders=[ROOT/'output'/f'h5-first57-{n}-process-20261106' for n in stage_names]
processes=[load(p/'process.json') for p in process_folders]
assert all(p['closed'] and not p['timeout'] and p['complete_process_cap_overrun_seconds']==0 for p in processes)
assert [p['exit_code'] for p in processes]==[0,1,0,0]
assert sorted(p.name for p in FAILED.iterdir())==['prepare.py']
assert cover['complete_case_cap_overrun_seconds']==tree['complete_case_cap_overrun_seconds']==0
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
parsed=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in parsed.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
previous=ROOT/'output/seal_h5_clearance_pair_proofs_20261106.py'
parsed=ast.parse(previous.read_text(encoding='utf-8'))
extension=next(n for n in parsed.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='PARENTS' and n.value.func.attr=='extend')
exec(compile(ast.Module(body=[extension],type_ignores=[]),str(previous),'exec'))
PARENTS.extend([ROOT/'benchmarks/results/h5-clearance-pair-proofs-20261106',ROOT/'benchmarks/results/h5-refined-cover-proofs-20261106'])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for folder in [REF,FAILED,GRAPH,TREE,SYNC]+process_folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_frontier_refin*20261106.py','*h5_frontier_graph*20261106.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,previous.name,'h5-frontier-refinement-index-correction-20261106.json',
    'h5-sat-certificate-method-assessment-20261106.json','h5-frontier-refined-proofs-report-20261106.md','push_h5_refined_cover_checkpoint_20261106.py']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(REF/'audit/checks.json','cover-audit-v1.json'),(REF/'audit-v2/checks.json','cover-audit-v2.json'),(GRAPH/'audit/checks.json','graph-audit.json'),
    (TREE/'audit/checks.json','tree-audit.json'),(TREE/'audit/remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(SYNC/'receipt.json','main-sync-receipt.json'),
    (ROOT/'output/h5-frontier-refinement-index-correction-20261106.json','index-correction.json'),(ROOT/'output/h5-sat-certificate-method-assessment-20261106.json','sat-method-assessment.json')]:
    shutil.copyfile(source,OUT/name)
write(OUT/'process-ledger.json',{'stages':stage_names,'all_consumed_complete_preparation_seconds':sum(p['complete_process_seconds'] for p in processes),
    'processes':processes,'closed_preflight_failure_preserved':True,'graphs_or_trees_before_preflight_failure':0,
    'independent_audit_seconds':[load(REF/'audit/checks.json')['seconds'],cover['seconds'],graph['seconds'],tree['seconds']],
    'all_processes_closed':True,'all_final_complete_case_and_process_caps_pass':True,'placement_solver_calls':0,'native_calls':0,'full_construction_60_90_budget_claimed':False})
write(OUT/'frontier-classification.json',{'prior_refined_cutoff':[[4,5,10]],'new_refined_cutoffs':tree['new_cutoff_cases'],'refined_graph_witnesses':0,'total_remaining':26})
write(OUT/'next-step.json',{'all_prior_processes_closed':True,'remaining_fixed29_choices':26,'total_fixed29_choices_excluded_at_required_clearance':429,
    'next_method':'Assess a different formal-certificate workflow over the complete necessary graphs: Boolean cell selectors, certified incompatible-pair clauses and independently verified at-least8 constraints for both families. First pin permissive solver/checker sources and hashes, validate positive/tampered proof controls and exhaustively check small cardinality encodings. Audit every emitted clause and exact DIMACS bytes before one frozen bounded SAT/proof call. An UNSAT status alone never excludes anything; require a complete proof accepted by a separate checker bound to the exact formula. A SAT assignment is only a necessary graph witness, not source-valid geometry. UNKNOWN, missing or truncated proof remains unresolved. This changes the certificate method and does not rerun or extend any closed recursive tree; no new geometric constraint is claimed. No such model or call has yet been made.',
    'assessment':'output/h5-sat-certificate-method-assessment-20261106.json',
    'survivors':'output/h5-first57-frontier-refined-trees-20261106/audit/remaining-fixed29-choices.json',
    'batch_graphs':'output/h5-first57-frontier-refined-graphs-v2-20261106',
    'earlier_single_graph':'output/h5-first57-refined-conflict-graph-20261106',
    'whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'new_whole_arrangement_exclusions':0,'remaining_fixed29_choices':26,'total_fixed29_choices_excluded_at_required_clearance':429,'previous_zero_clearance_exclusions':427,
    'new_refined_cases':25,'complete_parent_cells':18854,'complete_child_cells':75416,'source_certified_child_removals':2794,'retained_child_cells':72622,
    'all_child_pairs_verified':110803502,'new_child_conflicts':6172577,'tree_records_verified':11716,'tree_open_leaves':1453,'refined_graph_witnesses':0,
    'preserved_pre_graph_input_failure':True,'authoritative_cover_audit':'audit-v2','required_job_clearance_mm':0.2,'new_zero_clearance_exclusion_claimed':False,
    'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-frontier-refined-proofs-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 complete refined frontier:** [independent cover, every-pair and tree audits]({link}) verify the other 25 survivors: 18,854 complete parent covers, 75,416 closed children and 2,794 exact cog-clearance removals. The 72,622 retained nodes have 6,172,577 new conflicts; all 110,803,502 unordered pairs and complete root clique bounds pass. A cover-audit metadata index error caused graph preflight to fail before any graph was constructed; the original audit/failure are preserved, audit-v2 corrects the index, and versioned graph preparation keeps the same caps. The 25 fresh joint trees verify 11,716 records and 666,103 removals but retain 1,453 open leaves, with no refined graph witness or new exclusion. Together with the earlier [4,5,10] cutoff, all 26 refined arrangements remain unresolved. Complete preparation costs are 10.539071, 0.316752 (failed preflight), 7.361615 and 44.052088 s; final complete-case/process caps pass. No placement/native call or full construction budget is claimed. The previous checkpoints reached main 3046006d after all six prior CI checks passed. Next assess an independently checked Boolean unsatisfiability certificate workflow; no SAT model or call has yet run. Full66 checks, 440 whole allocations and H2/H5 remain open at 60%; every prior bounded process stays closed.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8')
a='Latest H5 evidence: [refined continuous cover](../benchmarks/results/h5-refined-cover-proofs-20261106.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [complete refined frontier](../benchmarks/results/{NAME}.md).',1)
a='twenty-one coarse cutoff cases and this refined cutoff remain. New child covers\nand root clique bounds for the other 25 arrangements are next. All prior calls\nand bounded processes stay closed.'
b='twenty-one coarse cutoff cases and this refined cutoff remained. The other 25\narrangements now have complete child covers, 2,794 certified child removals and\n6,172,577 new conflicts verified over 110,803,502 pairs. Their distinct trees\nretain 1,453 open leaves. All 26 refined arrangements remain unresolved.\nThe corrected index audit and pre-graph failure are preserved. An independently\nchecked Boolean certificate method is next; no SAT model or call has run.\nAll prior calls and bounded processes stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
