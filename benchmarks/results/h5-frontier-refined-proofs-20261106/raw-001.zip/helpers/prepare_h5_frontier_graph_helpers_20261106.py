from pathlib import Path
from textwrap import indent
O=Path(__file__).resolve().parent
s=(O/'prepare_h5_refined_conflict_graph_20261106.py').read_text(encoding='utf-8')
read=s[s.index('paths=[BR/'):s.index('inputs=[Path(__file__)')]
read=read.replace('REF/','ref_folder/')
body=s[s.index('def matrix('):s.index("checks={'prepared'")]
body=body.replace('assert time.perf_counter()-started<10','assert time.perf_counter()-case_started<10 and time.perf_counter()-started<60')
body=body.replace('assert new_count>0 and np.all','assert np.all')
body=body.replace("sample=next(zip(*np.nonzero(new)));sample=list(map(int,sample))","sample=list(map(int,next(zip(*np.nonzero(new))))) if new_count else None")
body=body.replace('OUT/','folder/')
prefix='''"""Exact new child graphs and complete root clique bounds for25 arrangements."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-frontier-refined-graphs-20261106'
REF=ROOT/'output/h5-first57-frontier-refined-covers-20261106';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106';PAIR=ROOT/'output/h5-first57-clearance-pair-edges-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
def members(mask):
    while mask:
        b=mask&-mask;yield b.bit_length()-1;mask-=b
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for base in [REF,AUG,PAIR]:assert load(base/'audit/checks.json')['passed']
selection=load(REF/'audit/graph-candidates.json');assert len(selection)==25 and all(r['source_selection']['empty_sites']!=[4,5,10] for r in selection)
inputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_graph_helpers_20261106.py',ROOT/'output/prepare_h5_refined_conflict_graph_20261106.py',SOURCE/'geometry-domains.json',REF/'plan.json',REF/'audit/graph-candidates.json']
inputs += [base/name for base in [REF,AUG,PAIR] for name in ['audit/plan.json','audit/checks.json']]
for r in selection:
    row=r['source_selection'];ci=r['refinement_index']
    inputs += [REF/f'choice-{ci:02d}'/name for name in ['nodes.json','retained.json','checks.json']]
    inputs += [base/f"choice-{row[key]:02d}.json" for base,key in [(BR,'choice_index'),(INS,'insert_choice_index'),(AUG,'augmentation_index'),(PAIR,'clearance_edge_index')]]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':selection,
    'per_case_graph_cap_seconds':10,'per_case_complete_cap_seconds':12,'global_graph_cap_seconds':60,'preparation_cap_seconds':70,'maximum_process_seconds':80,
    'required_job_clearance_mm':0.2,'square_radius_um':140,'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,
    'method':'Construct each new refined necessary graph with every inherited parent zero-single, union and clearance edge, plus exact140 micrometre square child conflicts. Preserve every retained source child and alias. Save every graph bit. Derive complete family conflict-clique covers from inherited covers and deterministic ascending/descending-degree greedy orders. Only an independently verified complete cover below8 may exclude a fixed arrangement. All25 domains are new; the previously refined[4,5,10] case is omitted. No tree is run here.'})
results=[]
for selection_row in selection:
    ci=selection_row['refinement_index'];row=selection_row['source_selection'];case_started=time.perf_counter()
    folder=OUT/f'choice-{ci:02d}';folder.mkdir();ref_folder=REF/f'choice-{ci:02d}'
'''
root='''    masks=[int.from_bytes(v.tobytes(),'little') for v in np.packbits(graph,axis=1,bitorder='little')]
    root_covers=[]
    for f,seed in enumerate(original):
        vertices=list(range(offset)) if f==0 else list(range(offset,len(nodes)))
        family_mask=sum(1<<n for n in vertices);best=seed
        for order in [vertices,sorted(vertices,key=lambda v:(-(masks[v]&family_mask).bit_count(),v))]:
            if len(best)<8:break
            groups=[]
            for v in order:
                fitting=[i for i,g in enumerate(groups) if not g&~masks[v]]
                if fitting:
                    i=max(fitting,key=lambda i:(groups[i].bit_count(),-i));groups[i]|=1<<v
                else:groups.append(1<<v)
            if len(groups)<len(best):best=[list(members(g)) for g in groups]
        root_covers.append(best)
    write(folder/'root-covers.json',root_covers)
    elapsed=time.perf_counter()-case_started
    checks={'refinement_index':ci,'source_selection':row,'compact_nodes':len(nodes),'bracket_nodes':offset,'insert_nodes':len(nodes)-offset,
        'row_bytes':(len(nodes)+7)//8,'parent_nodes':len(parents),'all_unordered_pairs':len(nodes)*(len(nodes)-1)//2,
        'genuinely_new_child_conflicts':new_count,'new_conflict_example':sample,'initial_clique_counts':list(map(len,original)),
        'root_clique_counts':list(map(len,root_covers)),'diagnostic_excluded':any(len(c)<8 for c in root_covers),
        'conflict_bytes_sha256':digest(folder/'conflicts.bin'),'inherited_bytes_sha256':digest(folder/'inherited.bin'),
        'case_seconds':elapsed,'complete_case_cap_overrun_seconds':max(0,elapsed-12)}
    write(folder/'checks.json',checks);results.append(checks);assert time.perf_counter()-started<70
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':results,
    **{k:sum(r[k] for r in results) for k in ['compact_nodes','all_unordered_pairs','genuinely_new_child_conflicts','complete_case_cap_overrun_seconds']},
    'diagnostic_excluded_cases':[r['source_selection']['empty_sites'] for r in results if r['diagnostic_excluded']],
    'independent_graph_audit_pending':True,'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
print({k:v for k,v in load(OUT/'checks.json').items() if k!='choices'})
'''
with (O/'prepare_h5_frontier_refined_graphs_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+indent(read+body,'    ')+root)
s=(O/'run_h5_refined_conflict_graph_20261106.py').read_text(encoding='utf-8').replace('refined-conflict-graph','frontier-refined-graphs').replace('prepare_h5_refined_conflict_graph','prepare_h5_frontier_refined_graphs')
s=s.replace("'maximum_process_seconds':20","'maximum_process_seconds':80").replace('timeout=20','timeout=80').replace('elapsed-20','elapsed-80')
with (O/'run_h5_frontier_refined_graphs_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared25 new necessary graphs and complete root clique bounds.')
