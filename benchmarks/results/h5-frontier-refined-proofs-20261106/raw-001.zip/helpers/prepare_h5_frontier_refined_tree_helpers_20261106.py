from pathlib import Path
from textwrap import indent
O=Path(__file__).resolve().parent
s=(O/'prepare_h5_refined_anchor_tree_20261106.py').read_text(encoding='utf-8')
methods=s[s.index('def cover('):s.index('root=visit(')].replace('expanded>=5000','expanded>=1500')
prefix='''"""Fresh bounded joint trees for the25 newly refined arrangements."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-frontier-refined-trees-20261106'
GRAPHS=ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
def members(mask):
    while mask:
        b=mask&-mask;yield b.bit_length()-1;mask-=b
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(GRAPHS/'audit/checks.json')['passed']
selection=load(GRAPHS/'audit/stronger-tree-candidates.json');assert len(selection)==25 and all(r['genuinely_new_child_conflicts']>0 and r['source_selection']['empty_sites']!=[4,5,10] for r in selection)
inputs=[Path(__file__),ROOT/'output/prepare_h5_frontier_refined_tree_helpers_20261106.py',ROOT/'output/prepare_h5_refined_anchor_tree_20261106.py',GRAPHS/'audit/plan.json',GRAPHS/'audit/checks.json',GRAPHS/'audit/stronger-tree-candidates.json']
inputs += [GRAPHS/f"choice-{r['refinement_index']:02d}"/name for r in selection for name in ['checks.json','nodes.json','conflicts.bin','root-covers.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'selection':selection,'per_case_search_seconds':1.6,'per_case_complete_cap_seconds':2,'maximum_expanded_nodes_per_case':1500,
    'global_search_seconds':45,'preparation_cap_seconds':55,'maximum_process_seconds':65,'required_job_clearance_mm':0.2,
    'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,
    'method':'Run one fresh joint include/skip proof per newly refined arrangement using the complete independently certified child cover and every-pair-audited graph. Each has genuinely new source constraints. Keep exact candidate sets, mandatory support proofs and explicit open cutoff/witness leaves. Fresh1.6/2-second case caps,1500nodes and45/55/65 global caps. Only fully closed independently replayed trees exclude fixed29/current-cog poses at required0.2mm clearance. The previously refined[4,5,10] case stays closed and is omitted.'})
results=[]
for tree_index,selection_row in enumerate(selection):
    case_started=time.perf_counter();deadline=min(started+45,case_started+1.6)
    row=selection_row['source_selection'];graph_folder=GRAPHS/f"choice-{selection_row['refinement_index']:02d}"
    nodes=load(graph_folder/'nodes.json');offset=selection_row['retained_bracket_children'];n=len(nodes);universe=(1<<n)-1
    rowbytes=(n+7)//8;raw=(graph_folder/'conflicts.bin').read_bytes();assert len(raw)==rowbytes*n
    conflicting={i:int.from_bytes(raw[i*rowbytes:(i+1)*rowbytes],'little') for i in range(n)}
    compatible={i:universe&~conflicting[i] for i in range(n)}
    original=[[sum(1<<n for n in group) for group in cover] for cover in load(graph_folder/'root-covers.json')]
    root_available=[(1<<offset)-1,universe^((1<<offset)-1)]
    graph_complete=True;records=[];witness=None;expanded=0
'''
suffix='''    root=visit(root_available,[[],[]],original)
    open_nodes=[r['node'] for r in records if r['kind'] in ['open','open_graph_witness']]
    elapsed=time.perf_counter()-case_started
    result={'source_selection':row,'refinement_index':selection_row['refinement_index'],'empty_sites':row['empty_sites'],'refined_bracket_node_count':offset,'graph_complete':True,
        'root':root,'records':records,'expanded_nodes':expanded,'open_nodes':open_nodes,'joint_graph_witness':witness,
        'case_seconds':elapsed,'case_complete_cap_overrun_seconds':max(0,elapsed-2),'diagnostic_excluded':not open_nodes}
    write(OUT/f'choice-{tree_index:02d}.json',result)
    summary={k:v for k,v in result.items() if k not in ['source_selection','records','open_nodes','joint_graph_witness']}|{'tree_records':len(records),'open_leaves':len(open_nodes),'graph_witness':witness is not None}
    results.append(summary);print(summary,flush=True);assert time.perf_counter()-started<55
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':results,
    'independent_tree_audit_pending':True,'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
'''
with (O/'prepare_h5_frontier_refined_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+indent(methods,'    ')+suffix)
s=(O/'run_h5_refined_anchor_tree_20261106.py').read_text(encoding='utf-8').replace('refined-anchor-tree','frontier-refined-trees').replace('prepare_h5_refined_anchor_tree','prepare_h5_frontier_refined_trees')
s=s.replace("'maximum_process_seconds':12","'maximum_process_seconds':65").replace('timeout=12','timeout=65').replace('elapsed-12','elapsed-65')
with (O/'run_h5_frontier_refined_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared25 fresh source-refined joint trees.')
