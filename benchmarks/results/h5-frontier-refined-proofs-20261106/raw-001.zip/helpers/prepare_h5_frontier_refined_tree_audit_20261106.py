from pathlib import Path
from textwrap import indent
O=Path(__file__).resolve().parent
s=(O/'audit_h5_refined_anchor_tree_20261106.py').read_text(encoding='utf-8')
body=s[s.index("nodes=load(GRAPH/"):s.index("prior=load(FRONT/")]
body=body.replace("GRAPH/","graph_folder/")
body=body.replace("load(graph_folder/'audit/checks.json')['retained_bracket_children']","selection_row['retained_bracket_children']")
body=body.replace('<=5000','<=1500').replace('>=5000','>=1500')
body=body.replace("record['case_elapsed']>=5.0 or record['global_elapsed']>=5.0","record['case_elapsed']>=1.6 or record['global_elapsed']>=45")
body=body.replace("data['case_seconds']-5.5","data['case_seconds']-2")
prefix='''"""Independent complete candidate-set and certificate replay for25 refined trees."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
from functools import lru_cache
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-frontier-refined-trees-20261106';OUT=BASE/'audit'
GRAPHS=ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106';FRONT=GRAPHS
PROCESS=ROOT/'output/h5-first57-frontier-refined-trees-process-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),ROOT/'output/prepare_h5_frontier_refined_tree_audit_20261106.py',ROOT/'output/audit_h5_refined_anchor_tree_20261106.py',
    BASE/'plan.json',BASE/'checks.json',PROCESS/'opened.json',PROCESS/'process.json',GRAPHS/'audit/stronger-tree-candidates.json',FRONT/'audit/remaining-fixed29-choices.json'}
for base in [BASE,GRAPHS/'audit']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
inputs.add(GRAPHS/'audit/checks.json');assert load(GRAPHS/'audit/checks.json')['passed']
process=load(PROCESS/'process.json');assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
plan=load(BASE/'plan.json');assert plan['per_case_search_seconds']==1.6 and plan['per_case_complete_cap_seconds']==2 and plan['maximum_expanded_nodes_per_case']==1500 and plan['global_search_seconds']==45
selection=load(GRAPHS/'audit/stronger-tree-candidates.json');assert plan['selection']==selection and len(selection)==25
results=[];excluded=[];witnesses=[]
for case_index,selection_row in enumerate(selection):
    tree_path=BASE/f'choice-{case_index:02d}.json';inputs.add(tree_path);data=load(tree_path)
    row=selection_row['source_selection'];assert data['source_selection']==row and data['empty_sites']==row['empty_sites'] and row['empty_sites']!=[4,5,10] and data['graph_complete']
    assert data['refinement_index']==selection_row['refinement_index']
    graph_folder=GRAPHS/f"choice-{selection_row['refinement_index']:02d}"
    inputs.update(graph_folder/name for name in ['nodes.json','conflicts.bin','checks.json'])
'''
suffix='''    if closed:excluded.append(row['empty_sites'])
    witnesses += [{'source_selection':row,'refinement_index':selection_row['refinement_index'],'selected_nodes':w,'bracket_cells':[nodes[i] for i in w[0]],'insert_cells':[nodes[i] for i in w[1]],'source_placement':False} for w in found]
    results.append({'refinement_index':selection_row['refinement_index'],'source_selection':row,'tree_records_verified':len(records),'expanded_nodes_verified':expanded[0],**stats,
        'distinct_audited_graph_pair_checks':evaluated[0],'open_leaves':len(opened),'joint_graph_witness':bool(found),'complete_case_cap_overrun_seconds':0,
        'continuous_fixed29_choice_excluded':closed})
    if (case_index+1)%5==0:print({'audited_trees':case_index+1},flush=True)
prior=load(FRONT/'audit/remaining-fixed29-choices.json');assert len(prior)==26
excluded_set=set(map(tuple,excluded));assert len(excluded_set)==len(excluded)
remaining=[r for r in prior if tuple(r['empty_sites']) not in excluded_set]
write(OUT/'remaining-fixed29-choices.json',remaining);write(OUT/'joint-graph-witnesses.json',witnesses)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Consume only the independently complete source-child covers and every-pair-audited graphs. Independently reconstruct every include/skip child candidate set. Verify complete clique partitions, all pair conflicts and every ordered mandatory support removal. Every record is reached once; selected nodes remain compatible and all open leaves prevent exclusion. Only fully closed trees exclude fixed29/current-cog poses at original0.2mm clearance. The earlier refined[4,5,10] case is carried without another search. Necessary graph witnesses are not source placements.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':results,
    **{k:sum(r[k] for r in results) for k in ['tree_records_verified','expanded_nodes_verified','branch_cliques','closed_count_leaves','propagation_covers','propagation_removals','mandatory_support_pair_checks','clique_pair_checks','distinct_audited_graph_pair_checks','open_leaves','complete_case_cap_overrun_seconds']},
    'new_graph_witnesses':len(witnesses),'new_cutoff_cases':[r['source_selection']['empty_sites'] for r in results if r['time_or_node_limit_leaves'] or r['graph_preparation_limit_leaves']],
    'new_excluded_choices':excluded,'new_fixed29_choices_excluded':len(excluded),'total_fixed29_choices_excluded_at_required_clearance':429+len(excluded),'remaining_fixed29_choices':len(remaining),
    'required_job_clearance_mm':0.2,'new_zero_clearance_exclusion_claimed':False,'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='choices'})
'''
with (O/'audit_h5_frontier_refined_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+indent(body,'    ')+suffix)
print('Prepared independent25-tree exhaustive candidate replay.')
