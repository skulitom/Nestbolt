"""Exact lattice and bound proofs for the closed expanded-row representation."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-expanded-cog-row-integer-20261104';OUT=ROOT/'output/h5-expanded-row-integer-reduction-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'geometry-audit/checks.json')['passed'] and load(BASE/'model-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','family-modes.json','rows.json','pair-domains.json','mover-row-templates.json','row-pair-templates.json','geometry-audit/plan.json','geometry-audit/checks.json','model/checks.json','model-audit/plan.json','model-audit/checks.json','row-control/selected-control.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Exact representation reduction, without a packing solver. For every region derive a necessary integer bounding box from its exact source hull and the union of eligible source-mode relative bounds, or the row-pair difference domain. Test four centroid grid neighbours; if none fits, enumerate every coordinate on the shorter bounding-box axis and derive exact remaining-axis integer intervals from all integer planes. A region is removed only if every such slice is empty. Retain a witness for every nonempty region. Separately certify planes already implied by the eligible mode/row domain box; these may be omitted without changing admissible assignments. Source-hull bounds are used only for emptiness proofs, never to justify removing planes. Preserve every original region and certificate. This proves equivalence for the current conservative integer representation only, no continuous exclusion.','preparation_stop_seconds':20,'solver_calls':0,'new_model_created':False,'native_calls':0,'H5_complete':False})
modes=load(BASE/'family-modes.json');rows=load(BASE/'rows.json');origin=[0,2100];grid=100
records=[];scanned=0;empty=0;omitted=0;expanded_empty=0;expanded_plane_savings=0
def inside(p,planes):return all(sum(c*v for c,v in zip(q['coefficients'],p))<=q['upper'] for q in planes)
templates=[('mover',t) for t in load(BASE/'mover-row-templates.json')]+[('pair',t) for t in load(BASE/'row-pair-templates.json')]
for kind,t in templates:
    if kind=='mover':
        ri,gid=t['row'],t['geometry'];eligible=[m for opts in modes.values() for m in opts if m['normalized_geometry']==gid]
        domain=[[min(m['integer_relative_lower_left_bounds_by_row'][ri][k][0] for m in eligible),max(m['integer_relative_lower_left_bounds_by_row'][ri][k][1] for m in eligible)] for k in [0,1]]
        offset=origin;copies=7 if gid<8 else 6;key=[kind,ri,gid]
    else:
        a,b=t['rows'];domain=[[rows[b]['shift_bounds_grid'][k][0]-rows[a]['shift_bounds_grid'][k][1],rows[b]['shift_bounds_grid'][k][1]-rows[a]['shift_bounds_grid'][k][0]] for k in [0,1]]
        offset=[0,0];copies=1;key=[kind,a,b]
    out=[]
    for r in t['regions']:
        assert time.perf_counter()-started<20,'Closed reduction preparation limit reached.'
        vertices=[[ (F(v)-offset[k])*grid for k,v in enumerate(p)] for p in r['hull_vertices']]
        bounds=[[max(domain[k][0],math.ceil(min(p[k] for p in vertices))),min(domain[k][1],math.floor(max(p[k] for p in vertices)))] for k in [0,1]]
        center=[sum(p[k] for p in vertices)/len(vertices) for k in [0,1]]
        candidates=sorted(set(product(*[[math.floor(v),math.ceil(v)] for v in center])))
        witness=next((list(p) for p in candidates if all(lo<=v<=hi for v,(lo,hi) in zip(p,bounds)) and inside(p,r['planes'])),None)
        axis=min(range(2),key=lambda k:bounds[k][1]-bounds[k][0]);steps=0
        if witness is None and all(lo<=hi for lo,hi in bounds):
            other=1-axis
            for value in range(bounds[axis][0],bounds[axis][1]+1):
                steps+=1;lo,hi=bounds[other]
                for plane in r['planes']:
                    a,b=plane['coefficients'][axis],plane['coefficients'][other];right=plane['upper']-a*value
                    if b>0:hi=min(hi,right//b)
                    elif b<0:lo=max(lo,-((-right)//b))
                    elif right<0:lo=1;hi=0
                    if lo>hi:break
                if lo<=hi:
                    witness=[0,0];witness[axis]=value;witness[other]=lo;assert inside(witness,r['planes']);break
        scanned+=steps
        removed=[]
        if witness is not None:
            for i,p in enumerate(r['planes']):
                maximum=sum(c*domain[k][1 if c>=0 else 0] for k,c in enumerate(p['coefficients']))
                if maximum<=p['upper']:removed.append({'plane':i,'maximum_activity':maximum})
            omitted+=len(removed);expanded_plane_savings+=copies*len(removed)
        else:
            empty+=1;expanded_empty+=copies;expanded_plane_savings+=copies*len(r['planes'])
        out.append({'region':r['region'],'necessary_integer_bounds':bounds,'scan_axis':axis,'slices_examined':steps,'witness':witness,'empty':witness is None,'domain_implied_planes':removed})
    records.append({'template':key,'eligible_domain_bounds':domain,'copies_in_model':copies,'regions':out})
write(OUT/'region-reductions.json',records)
old=load(BASE/'model/checks.json')
result={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-started,'source_regions_reviewed':sum(len(t['regions']) for t in records),'integer_empty_regions':empty,'nonempty_region_witnesses':sum(not r['empty'] for t in records for r in t['regions']),'integer_axis_slices_examined':scanned,'domain_implied_planes':omitted,'expanded_region_selectors_removable':expanded_empty,'expanded_guarded_planes_removable':expanded_plane_savings,'original_variables':old['variables'],'estimated_reduced_variables':old['variables']-expanded_empty,'original_constraints':old['constraints'],'estimated_reduced_constraints':old['constraints']-expanded_plane_savings,'independent_proof_audit_required':True,'new_model_created':False,'solver_calls':0,'continuous_source_domain_excluded':False,'source_valid66':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
