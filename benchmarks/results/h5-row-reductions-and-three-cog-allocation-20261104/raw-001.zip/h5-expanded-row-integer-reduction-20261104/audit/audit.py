"""Verify lattice emptiness and domain-implied planes without a packing solver."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-expanded-cog-row-integer-20261104';RED=ROOT/'output/h5-expanded-row-integer-reduction-20261104';OUT=RED/'audit';PROCESS=ROOT/'output/h5-expanded-row-integer-reduction-process-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for name,h in load(RED/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(BASE/'geometry-audit/checks.json')['passed'] and load(BASE/'model-audit/checks.json')['passed']
modes=load(BASE/'family-modes.json');rows=load(BASE/'rows.json');instances=load(BASE/'instances.json')
templates={('mover',t['row'],t['geometry']):t for t in load(BASE/'mover-row-templates.json')}
templates.update({('pair',*t['rows']):t for t in load(BASE/'row-pair-templates.json')})
records=load(RED/'region-reductions.json');assert {tuple(r['template']) for r in records}==set(templates) and len(records)==len(templates)
empty=nonempty=slices=omitted=expanded_empty=expanded_planes=0;selected={tuple(p):r for p,r in zip([(0,1),(0,2),(1,2)],load(BASE/'row-control/selected-control.json')['row_pair_regions'])};selected_passed=0
for record in records:
    key=tuple(record['template']);kind=key[0];template=templates[key]
    if kind=='mover':
        ri,gid=key[1:];eligible=[m for opts in modes.values() for m in opts if m['normalized_geometry']==gid]
        domain=[[min(m['integer_relative_lower_left_bounds_by_row'][ri][k][0] for m in eligible),max(m['integer_relative_lower_left_bounds_by_row'][ri][k][1] for m in eligible)] for k in [0,1]]
        copies=sum(any(m['normalized_geometry']==gid for m in modes[i['identity'][0]]) for i in instances);offset=[0,2100]
    else:
        a,b=key[1:];domain=[[rows[b]['shift_bounds_grid'][k][0]-rows[a]['shift_bounds_grid'][k][1],rows[b]['shift_bounds_grid'][k][1]-rows[a]['shift_bounds_grid'][k][0]] for k in [0,1]];copies=1;offset=[0,0]
    assert record['eligible_domain_bounds']==domain and record['copies_in_model']==copies
    assert [r['region'] for r in record['regions']]==[r['region'] for r in template['regions']]
    for rec,reg in zip(record['regions'],template['regions']):
        vertices=[[(F(v)-offset[k])*100 for k,v in enumerate(p)] for p in reg['hull_vertices']]
        bounds=[[max(domain[k][0],math.ceil(min(p[k] for p in vertices))),min(domain[k][1],math.floor(max(p[k] for p in vertices)))] for k in [0,1]]
        assert rec['necessary_integer_bounds']==bounds
        axis=min(range(2),key=lambda k:bounds[k][1]-bounds[k][0]);assert rec['scan_axis']==axis
        if rec['empty']:
            assert rec['witness'] is None and not rec['domain_implied_planes'];local=0
            if all(lo<=hi for lo,hi in bounds):
                for value in range(bounds[axis][0],bounds[axis][1]+1):
                    local+=1;lo,hi=map(F,bounds[1-axis]);impossible=False
                    for plane in reg['planes']:
                        a,b=plane['coefficients'][axis],plane['coefficients'][1-axis]
                        if b==0:
                            if a*value>plane['upper']:impossible=True;break
                        else:
                            limit=F(plane['upper']-a*value,b)
                            if b>0:hi=min(hi,limit)
                            else:lo=max(lo,limit)
                    assert impossible or math.ceil(lo)>math.floor(hi),(key,reg['region'],value)
            assert local==rec['slices_examined'];slices+=local;empty+=1;expanded_empty+=copies;expanded_planes+=copies*len(reg['planes'])
        else:
            point=rec['witness'];assert len(point)==2 and all(isinstance(v,int) and lo<=v<=hi for v,(lo,hi) in zip(point,bounds))
            assert all(sum(c*v for c,v in zip(p['coefficients'],point))<=p['upper'] for p in reg['planes'])
            expected=[]
            for i,plane in enumerate(reg['planes']):
                maximum=max(sum(c*v for c,v in zip(plane['coefficients'],corner)) for corner in product(*domain))
                if maximum<=plane['upper']:expected.append({'plane':i,'maximum_activity':maximum})
            assert expected==rec['domain_implied_planes'];omitted+=len(expected);expanded_planes+=copies*len(expected);nonempty+=1
        if kind=='pair' and reg['region']==selected[key[1:]]:
            assert not rec['empty'];control=load(BASE/'row-control/selected-control.json');a,b=key[1:];point=[control['row_shifts_grid'][b][k]-control['row_shifts_grid'][a][k] for k in [0,1]]
            assert all(sum(c*v for c,v in zip(p['coefficients'],point))<=p['upper'] for p in reg['planes']);selected_passed+=1
checks=load(RED/'checks.json');old=load(BASE/'model/checks.json')
assert checks['source_regions_reviewed']==empty+nonempty==2666 and checks['integer_empty_regions']==empty and checks['nonempty_region_witnesses']==nonempty
assert checks['domain_implied_planes']==omitted and checks['expanded_region_selectors_removable']==expanded_empty and checks['expanded_guarded_planes_removable']==expanded_planes
assert checks['estimated_reduced_variables']==old['variables']-expanded_empty and checks['estimated_reduced_constraints']==old['constraints']-expanded_planes and selected_passed==3
process=load(PROCESS/'process.json');opened=load(PROCESS/'opened.json');assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_seconds']>=checks['seconds_including_evidence_serialization']
assert digest(ROOT/opened['script'])==opened['script_sha256'] and opened['maximum_calls']==1 and not opened['retry_permitted']
inputs=[Path(__file__),BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',BASE/'instances.json']+list(RED.glob('*.json'))+list(PROCESS.glob('*'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconstruct source-relative domain boxes and hull extrema exactly. For each allegedly empty region, derive exact rational intervals on every integer slice of the shorter axis and prove that none contains an integer. Independently test every nonempty witness. Compute each allegedly implied halfplane maximum by enumerating the four mode/row domain corners; source-hull bounds are not used for these implications. Derive copy multiplicities from all13 original instances, verify total variable/constraint estimates, and preserve the three selected positive-control regions. No new model or packing call.'})
result={'passed':True,'seconds':time.perf_counter()-started,'regions_verified':empty+nonempty,'integer_empty_regions_verified':empty,'nonempty_integer_witnesses_verified':nonempty,'empty_region_integer_slices_verified':slices,'domain_implied_planes_verified':omitted,'expanded_selectors_removable_verified':expanded_empty,'expanded_guarded_planes_removable_verified':expanded_planes,'positive_row_control_regions_preserved':selected_passed,'estimated_reduced_variables':checks['estimated_reduced_variables'],'estimated_reduced_constraints':checks['estimated_reduced_constraints'],'variable_reduction_percent':100*expanded_empty/old['variables'],'constraint_reduction_percent':100*expanded_planes/old['constraints'],'complete_reduction_process_seconds':process['complete_process_seconds'],'reduction_not_large_enough_to_warrant_new_search':True,'new_model_created':False,'solver_calls':0,'continuous_source_domain_excluded':False,'source_valid66':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
