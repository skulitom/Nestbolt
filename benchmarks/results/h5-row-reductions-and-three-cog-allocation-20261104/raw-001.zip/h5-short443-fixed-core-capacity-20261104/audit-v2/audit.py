"""Replay exact source containment and an independent integer event sweep."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,math,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short443-fixed-core-capacity-20261104';OUT=BASE/'audit-v2'
PRE=ROOT/'output/h5-short443-fixed-core-preflight-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
STOCK=ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(v):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(v,v[1:]+v[:1]))/2
def orient(v):return v if area(v)>0 else list(reversed(v))
def split_boundary(polys):
    points=set(p for poly in polys for p in poly);result=Counter()
    for poly in polys:
        for a,b in zip(poly,poly[1:]+poly[:1]):
            on=sorted((p for p in points if cross(a,b,p)==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1])),reverse=a>b)
            assert on[0]==a and on[-1]==b
            result.update(zip(on,on[1:]))
    for a,b in list(result):
        n=min(result[a,b],result[b,a]);result[a,b]-=n;result[b,a]-=n
    return +result
def transform(v,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;x0,y0=map(F,t['translation'])
    return [(m*F(x)*c-F(y)*s+x0,m*F(x)*s+F(y)*c+y0) for x,y in v]
def inside(point,poly):return all(cross(a,b,point)>=0 for a,b in zip(poly,poly[1:]+poly[:1]))
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,PRE]:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
job=load(JOB);parts={p['id']:p for p in job['parts']};canonical=load(PIECES)
partition=[]
for family in ['bracket','cog']:
    pieces=[orient([tuple(map(F,p)) for p in v]) for v in canonical[family]]
    outer=orient([tuple(map(F,p)) for p in parts[family]['geometry'][0]['outer']])
    assert all(all(cross(a,b,c)>0 for a,b,c in zip(p,p[1:]+p[:1],p[2:]+p[:2])) for p in pieces)
    assert sum(area(p) for p in pieces)==area(outer)
    # Split the outer ring at piece vertices too, then cancel exact internal edges.
    points={v for p in pieces for v in p}|set(outer)
    def boundary_with_points(polys):
        out=Counter()
        for p in polys:
            for a,b in zip(p,p[1:]+p[:1]):
                on=sorted((v for v in points if cross(a,b,v)==0 and min(a[0],b[0])<=v[0]<=max(a[0],b[0]) and min(a[1],b[1])<=v[1]<=max(a[1],b[1])),reverse=a>b)
                out.update(zip(on,on[1:]))
        for a,b in list(out):
            n=min(out[a,b],out[b,a]);out[a,b]-=n;out[b,a]-=n
        return +out
    assert boundary_with_points(pieces)==boundary_with_points([outer])
    partition.append({'family':family,'positive_convex_pieces':len(pieces),'exact_area_and_boundary_cancellation':True})
core=load(PRE/'fixed-source7.json');st=load(STOCK)
assert len(core)==7
original=load(ROOT/'output/h5-legacy64-sliding-geometry-20261026/short-repair/placements.json')
assert [r['transform'] for r in core]==[r['transform'] for r in original if r['part_id']!='insert']
source_check=audit(job,core,{'sheet-1':st['source_stock']},st['required_pair_gap_mm'],st['stock_guard_mm'])
assert source_check['valid']
write(OUT/'fixed-core-source-readback.json',source_check)
pieces={}
for owner,r in enumerate(core):
    for pi,v in enumerate(canonical[r['part_id']]):pieces[owner,pi]=orient(transform(v,r['transform']))
recorded=load(BASE/'source-pieces.json')
assert len(recorded)==len(pieces)==71
for r in recorded:assert [tuple(map(F,p)) for p in r['vertices']]==pieces[r['owner'],r['piece']]
rectangles=load(BASE/'inner-rectangles.json')
for r in rectangles:
    a,b,c,d=map(F,r['bounds']);assert a<c and b<d
    assert all(inside(p,pieces[r['owner'],r['piece']]) for p in product([a,c],[b,d]))
epsilon=F('0.000001');dimensions=[(F(180)-2*epsilon,F(110)-2*epsilon),(F(110)-2*epsilon,F(180)-2*epsilon)]
insert_modes=[]
part=parts['insert'];assert not part['allow_mirror'] and part['rotations']['degrees']==[0,90,180,270]
for angle in part['rotations']['degrees']:
    poly=orient(transform(part['geometry'][0]['outer'],{'rotation_radians':math.radians(angle),'mirrored':False,'translation':[0,0]}))
    ox=min(x for x,y in poly);oy=min(y for x,y in poly)
    w,h=dimensions[int(angle//90)%2]
    assert all(inside(p,poly) for p in product([ox+epsilon,ox+epsilon+w],[oy+epsilon,oy+epsilon+h]))
    insert_modes.append({'angle':angle,'inner_dimensions':list(map(str,[w,h])),'inner_offset':[str(ox+epsilon),str(oy+epsilon)]})
records=load(BASE/'necessary-domains.json');assert len(records)==2
stock=list(map(F,st['source_stock']));sweep_count=free_box_count=0
for geometry,(r,(w,h)) in enumerate(zip(records,dimensions)):
    assert r['geometry']==geometry and list(map(F,r['inner_dimensions']))==[w,h]
    domain=(stock[0],stock[1],stock[2]-w,stock[3]-h)
    assert tuple(map(F,r['domain']))==domain
    expected_obs=[]
    for rect in rectangles:
        a,b,c,d=map(F,rect['bounds']);o=(a-w,b-h,c,d)
        if o[0]<domain[2] and o[2]>domain[0] and o[1]<domain[3] and o[3]>domain[1]:expected_obs.append(o)
    assert [tuple(map(F,o)) for o in r['obstacles']]==expected_obs
    # Exact integer units make this independent event-count implementation cheap.
    scale=2*math.lcm(*(v.denominator for o in [domain]+expected_obs for v in o))
    conv=lambda v:int(v*scale)
    D=tuple(map(conv,domain));O=[tuple(map(conv,o)) for o in expected_obs]
    xs=sorted({D[0],D[2]}|{v for a,b,c,d in O for v in [a,c] if D[0]<=v<=D[2]})
    classes=sorted([(x,x,x) for x in xs]+[(a,b,(a+b)//2) for a,b in zip(xs,xs[1:])])
    assert len(classes)==len(r['sweep'])
    all_free=[]
    for (xa,xb,x),saved in zip(classes,r['sweep']):
        assert [conv(F(v)) for v in saved['x_interval']]==[xa,xb] and conv(F(saved['x_sample']))==x
        events=defaultdict(lambda:[0,0])
        events[D[1]];events[D[3]]
        for a,b,c,d in O:
            if a<x<c:events[b][0]+=1;events[d][1]+=1
        active=0;free=[];keys=sorted(events)
        for i,y in enumerate(keys):
            starts,ends=events[y];at_point=active-ends;assert at_point>=0
            if at_point==0 and D[1]<=y<=D[3]:free.append((y,y))
            active=at_point+starts
            if active==0 and i+1<len(keys):
                a=max(y,D[1]);b=min(keys[i+1],D[3])
                if a<b:free.append((a,b))
        assert active==0
        merged=[]
        for a,b in sorted(free):
            if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
            else:merged.append((a,b))
        assert [tuple(conv(F(v)) for v in q) for q in saved['free_y_intervals']]==merged
        all_free.extend((xa,a,xb,b) for a,b in merged);sweep_count+=1
    assert [tuple(conv(F(v)) for v in q) for q in r['free_boxes']]==all_free
    components=[tuple(conv(F(v)) for v in q) for q in r['component_bounds']]
    assert all(any(a<=x and b<=y and z<=c and t<=d for a,b,c,d in components) for x,y,z,t in all_free)
    assert all(c-a<conv(w) and d-b<conv(h) for a,b,c,d in components)
    assert r['each_component_single_capacity']
    free_box_count+=len(all_free)
assert len(records[0]['component_bounds'])==2 and records[1]['component_bounds']==[]
write(OUT/'source-partitions.json',partition);write(OUT/'insert-inner-rectangle-certificates.json',insert_modes)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,PIECES,STOCK,PRE/'fixed-source7.json',PRE/'inventory.json',
    ROOT/'output/h5-legacy64-sliding-geometry-20261026/short-repair/placements.json']+[BASE/n for n in ['plan.json','checks.json','source-pieces.json','inner-rectangles.json','necessary-domains.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'fixed_originals':7,'source_partitions_exact':True,'source_convex_pieces':71,
    'inner_rectangles_exactly_contained':len(rectangles),'legal_insert_inner_modes':len(insert_modes),
    'exact_open_intervals_and_boundary_x_classes_replayed':sweep_count,'free_boxes_covered':free_box_count,
    'horizontal_components':2,'vertical_components':0,'each_horizontal_component_capacity':1,
    'maximum_inserts_with_this_fixed_core':2,'required_inserts':4,'zero_clearance_relaxation':True,
    'continuous_fixed_core_exclusion_certified':True,'whole_allocation_excluded':False,'remaining_allocation_candidates':440,
    'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
