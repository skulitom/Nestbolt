"""Prepare a certified geometric merge of the expanded triangulated regions."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/prepare_h5_cog_row_reduced_cover_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-independent-cog-row-overlap-regions-20261104','h5-expanded-cog-row-regions-20261104').replace('h5-independent-cog-row-reduced-cover-20261104','h5-expanded-row-geometric-merge-20261104').replace('h5-cog-row-overlap-regions-process-20261104','h5-expanded-cog-row-regions-process-20261104')
s=s.replace('Reduce the overlapping convex covers','Reduce the expanded full-space triangulation')
s=s.replace('Remove contained regions through the same union operation.','Bridge numerical partition seams only when the full candidate hull passes the obstacle filter. Remove contained regions through the same union operation.')
save('prepare_h5_expanded_row_geometric_merge_20261104.py',s)
s=(ROOT/'output/run_h5_cog_row_overlap_regions_20261104.py').read_text(encoding='utf-8').replace('h5-cog-row-overlap-regions-process-20261104','h5-expanded-row-geometric-merge-process-20261104').replace('prepare_h5_cog_row_overlap_regions_20261104.py','prepare_h5_expanded_row_geometric_merge_20261104.py')
save('run_h5_expanded_row_geometric_merge_20261104.py',s)
s=(ROOT/'output/audit_h5_expanded_cog_row_regions_20261104.py').read_text(encoding='utf-8').replace('h5-expanded-cog-row-regions-20261104','h5-expanded-row-geometric-merge-20261104')
save('audit_h5_expanded_row_geometric_merge_20261104.py',s)
