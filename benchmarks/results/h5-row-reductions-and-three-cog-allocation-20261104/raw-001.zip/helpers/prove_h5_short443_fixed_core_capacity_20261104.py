"""Exact necessary rectangle cover for inserts around a fixed original-source core."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,math,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-short443-fixed-core-capacity-20261104'
PRE=ROOT/'output/h5-short443-fixed-core-preflight-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
STOCK=ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p):return sum((a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1])),F(0))/2
def transformed(v,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    return [(m*F(x)*c-F(y)*s+tx,m*F(x)*s+F(y)*c+ty) for x,y in v]
def deadline():
    assert time.perf_counter()-started<55,'Preparation cap; retain partial evidence and do not claim capacity.'
def interval(p,y):
    xs=[]
    for a,b in zip(p,p[1:]+p[:1]):
        if a[1]==b[1]:
            if y==a[1]:xs.extend([a[0],b[0]])
        elif min(a[1],b[1])<=y<=max(a[1],b[1]):
            xs.append(a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]))
    return min(xs),max(xs)
def rectinside(r,p):
    return all(cross(a,b,c)>=0 for a,b in zip(p,p[1:]+p[:1]) for c in [(r[0],r[1]),(r[0],r[3]),(r[2],r[1]),(r[2],r[3])])
OUT.mkdir();started=time.perf_counter()
inputs=[Path(__file__),JOB,PIECES,STOCK,PRE/'fixed-source7.json',PRE/'plan.json',PRE/'inventory.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Necessary relaxation only: exact rational rectangles contained in the fixed original source convex pieces, and a slightly shrunken axis-aligned rectangle contained in each legal insert orientation. Zero clearance. Exhaustively sweep all open X intervals and every boundary X point through the open rectangular configuration obstacles. Preserve all closed free Y intervals and isolated points. Coarse overlapping box components may enlarge the free space; bounding-box pair exclusions can then upper-bound insert capacity. Independent replay required before any negative claim.',
    'preparation_cap_seconds':55,'maximum_process_seconds':90,'solver_calls':0,'native_calls':0,'global_allocation_exclusion':False})
parts={p['id']:p for p in load(JOB)['parts']};canonical=load(PIECES);core=load(PRE/'fixed-source7.json')
rectangles=[];piece_records=[]
for owner,r in enumerate(core):
    for pi,vertices in enumerate(canonical[r['part_id']]):
        p=transformed(vertices,r['transform'])
        if area(p)<0:p.reverse()
        assert all(cross(a,b,c)>0 for a,b,c in zip(p,p[1:]+p[:1],p[2:]+p[:2]))
        # The exact affine image of a certified original source piece is convex.
        ys=sorted({q[1] for q in p});sections={y:interval(p,y) for y in ys}
        piece_records.append({'owner':owner,'piece':pi,'vertices':[[str(x),str(y)] for x,y in p]})
        candidates=[]
        for i,ya in enumerate(ys):
            for yb in ys[i+1:]:
                xa=max(sections[ya][0],sections[yb][0]);xb=min(sections[ya][1],sections[yb][1])
                if xa<xb:
                    rec=(xa,ya,xb,yb)
                    assert rectinside(rec,p)
                    candidates.append(rec)
        # Rounded inward to 1 micrometre for tractable exact sweeps.
        for rec in candidates:
            reduced=(F(math.ceil(rec[0]*1000),1000),F(math.ceil(rec[1]*1000),1000),F(math.floor(rec[2]*1000),1000),F(math.floor(rec[3]*1000),1000))
            if reduced[0]<reduced[2] and reduced[1]<reduced[3]:
                assert rectinside(reduced,p)
                rectangles.append({'owner':owner,'piece':pi,'bounds':reduced})
        deadline()
# Remove only rectangles contained in another retained rectangle.
unique={}
for r in rectangles:unique.setdefault(tuple(r['bounds']),r)
ordered=sorted(unique.values(),key=lambda r:-(r['bounds'][2]-r['bounds'][0])*(r['bounds'][3]-r['bounds'][1]))
retained=[]
for r in ordered:
    a,b,c,d=r['bounds']
    if not any(s['bounds'][0]<=a and s['bounds'][1]<=b and c<=s['bounds'][2] and d<=s['bounds'][3] for s in retained):
        retained.append(r)
write(OUT/'source-pieces.json',piece_records)
write(OUT/'inner-rectangles.json',[{**r,'bounds':list(map(str,r['bounds']))} for r in retained])
stock=list(map(F,load(STOCK)['source_stock']));epsilon=F('0.000001')
records=[]
for geometry,(w,h) in enumerate([(F(180)-2*epsilon,F(110)-2*epsilon),(F(110)-2*epsilon,F(180)-2*epsilon)]):
    domain=(stock[0],stock[1],stock[2]-w,stock[3]-h)
    obs=[(r['bounds'][0]-w,r['bounds'][1]-h,r['bounds'][2],r['bounds'][3]) for r in retained]
    obs=[r for r in obs if r[0]<domain[2] and r[2]>domain[0] and r[1]<domain[3] and r[3]>domain[1]]
    xs=sorted({domain[0],domain[2]}|{x for r in obs for x in [r[0],r[2]] if domain[0]<=x<=domain[2]})
    slabs=[(x,x,x) for x in xs]+[(a,b,(a+b)/2) for a,b in zip(xs,xs[1:])]
    free=[];sweep=[]
    for xa,xb,x in sorted(slabs):
        intervals=sorted((y0,y1) for x0,y0,x1,y1 in obs if x0<x<x1)
        merged=[]
        for ya,yb in intervals:
            if merged and ya<merged[-1][1]:merged[-1][1]=max(merged[-1][1],yb)
            else:merged.append([ya,yb])
        cursor=domain[1];ys=[]
        for ya,yb in merged:
            if yb<domain[1] or ya>domain[3]:continue
            if cursor<=ya:ys.append((cursor,min(ya,domain[3])))
            cursor=max(cursor,yb)
            if cursor>domain[3]:break
        if cursor<=domain[3]:ys.append((cursor,domain[3]))
        for ya,yb in ys:free.append((xa,ya,xb,yb))
        sweep.append({'x_interval':[str(xa),str(xb)],'x_sample':str(x),'free_y_intervals':[[str(a),str(b)] for a,b in ys]})
        deadline()
    # Merge overlapping free boxes by union of their bounding rectangles. This
    # deliberately enlarges the free space and remains a necessary relaxation.
    components=[]
    for r in free:
        current=r
        while True:
            hits=[s for s in components if max(s[0],current[0])<=min(s[2],current[2]) and max(s[1],current[1])<=min(s[3],current[3])]
            if not hits:break
            for s in hits:components.remove(s)
            current=(min([current[0]]+[s[0] for s in hits]),min([current[1]]+[s[1] for s in hits]),
                     max([current[2]]+[s[2] for s in hits]),max([current[3]]+[s[3] for s in hits]))
        components.append(current)
    records.append({'geometry':geometry,'inner_dimensions':list(map(str,[w,h])),'domain':list(map(str,domain)),
        'obstacles':[list(map(str,r)) for r in obs],'sweep':sweep,'free_boxes':[list(map(str,r)) for r in free],
        'component_bounds':[list(map(str,r)) for r in components],
        'each_component_single_capacity':all(c-a<w and d-b<h for a,b,c,d in components)})
write(OUT/'necessary-domains.json',records)
checks={'prepared':True,'seconds':time.perf_counter()-started,'fixed_source_pieces':len(piece_records),'retained_inner_rectangles':len(retained),
    'components_by_geometry':[len(r['component_bounds']) for r in records],
    'component_bounds':[r['component_bounds'] for r in records],
    'each_component_single_capacity':[r['each_component_single_capacity'] for r in records],
    'independent_source_and_sweep_audit_pending':True,'negative_claim_certified':False,'global_allocation_excluded':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
