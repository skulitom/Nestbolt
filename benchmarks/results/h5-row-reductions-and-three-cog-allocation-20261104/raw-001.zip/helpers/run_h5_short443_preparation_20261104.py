from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,time,sys
ROOT=Path(__file__).resolve().parents[1]
phase=sys.argv[1]
assert phase in ['preparation','model']
script=ROOT/('output/prepare_h5_short443_20261104.py' if phase=='preparation' else 'output/build_h5_short443_20261104.py')
out=ROOT/('output/h5-short443-'+phase+'-process-20261104');out.mkdir()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=time.perf_counter()
write(out/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'script':script.relative_to(ROOT).as_posix(),'script_sha256':sha256(script.read_bytes()).hexdigest(),'maximum_process_seconds':10,'retry_permitted':False})
try:
    r=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(script)],cwd=ROOT,capture_output=True,timeout=10)
    result={'exit_code':r.returncode,'timeout':False};stdout,stderr=r.stdout,r.stderr
except subprocess.TimeoutExpired as e:
    result={'timeout':True};stdout,stderr=e.stdout or b'',e.stderr or b''
elapsed=time.perf_counter()-started
(out/'stdout.txt').write_bytes(stdout);(out/'stderr.txt').write_bytes(stderr)
result.update({'complete_process_seconds':elapsed,'complete_process_cap_overrun_seconds':max(0,elapsed-10),'closed':True})
write(out/'process.json',result);print(result);print(stdout.decode(errors='replace'));print(stderr.decode(errors='replace'))
