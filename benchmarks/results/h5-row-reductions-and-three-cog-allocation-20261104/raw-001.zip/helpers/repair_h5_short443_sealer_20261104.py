from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
old=OUT/'seal_h5_short443_checkpoint_20261104.py'
s=old.read_text(encoding='utf-8')
s=s.replace(",'h5-retained64-allocation-source-search-20261026'","")
s=s.replace("def write(p,v):\n", """def write(p,v):
    if p.exists() and p in [CAP/'audit-attempts.json', ROOT/'output/h5-short443-fixed-core-preflight-20261104/diagnostics.json', BASE/'prior-main-ci.json']:
        assert load(p)==v
        return
""")
s=s.replace("'h5-short443-checkpoint-report-20261104.md']","'h5-short443-checkpoint-report-20261104.md','h5-short443-checkpoint-sealing-attempts.json']")
with (OUT/'seal_h5_short443_checkpoint_v2_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
record={'first_sealer_failed_before_archive_directory_creation':True,
    'error':'Older legacy report uses a different archive verification layout; generic parent archive-checks.json was absent.',
    'correction':'Omit that optional deduplication parent; read and archive any required legacy inputs directly.',
    'three_prepared_metadata_files_preserved_and_byte_content_asserted_on_resume':True,
    'source_geometry_models_and_solver_results_unchanged':True}
with (OUT/'h5-short443-checkpoint-sealing-attempts.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
