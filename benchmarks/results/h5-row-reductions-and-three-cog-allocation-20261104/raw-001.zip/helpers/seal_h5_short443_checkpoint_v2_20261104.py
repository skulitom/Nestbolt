"""Seal reductions, a new bounded allocation call, and the exact fixed-core capacity proof."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-row-reductions-and-three-cog-allocation-20261104';OUT=ROOT/'benchmarks/results'/NAME
BASE=ROOT/'output/h5-short443-integer-regions-20261104'
CAP=ROOT/'output/h5-short443-fixed-core-capacity-20261104'
RED=ROOT/'output/h5-expanded-row-integer-reduction-20261104'
MERGE=ROOT/'output/h5-expanded-row-geometric-merge-20261104'
PARENTS=[ROOT/'benchmarks/results'/n for n in ['h5-continuous-small-block-exclusions-20261104','h5-continuous-inserts-and-bracket-capacities-20261104','h5-direct-counts-and-relative-hull-capacities-20261104','h5-corner-channel-construction-20261104','h5-relative-projections-and-movable-packet-20261104','h5-translated-cog-packet-construction-20261104','h5-independent-cog-rows-and-expanded-domains-20261104','h5-expanded-joint-and-staged-row-constructions-20261104']]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    if p.exists() and p in [CAP/'audit-attempts.json', ROOT/'output/h5-short443-fixed-core-preflight-20261104/diagnostics.json', BASE/'prior-main-ci.json']:
        assert load(p)==v
        return
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
for folder in ['audit','geometry-audit','model-audit','response-audit']:assert load(BASE/folder/'checks.json')['passed']
response=load(BASE/'response-audit/checks.json')
assert response['solver_status']=='UNKNOWN' and response['assignments']==0 and response['closed_solver_calls']==1
assert response['algorithm_overrun_seconds']==response['shared_overrun_seconds']==0
capacity=load(CAP/'audit-v2/checks.json')
assert capacity['passed'] and capacity['maximum_inserts_with_this_fixed_core']==2 and not capacity['whole_allocation_excluded']
assert load(RED/'audit/checks.json')['passed'] and load(MERGE/'source-region-audit/checks.json')['passed']
write(CAP/'audit-attempts.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [ROOT/'output/audit_h5_short443_fixed_core_capacity_20261104.py',CAP/'audit/audit.py',ROOT/'output/audit_h5_short443_fixed_core_capacity_v2_20261104.py',CAP/'audit-v2/checks.json']},
    'first_attempt_failed':True,'first_error':'TypeError: list indices must be integers or slices, not float; at the legal-angle dimensions lookup.',
    'first_attempt_source_partition_and_core_checks_completed':True,'correction':'Explicit integer index for the quarter-turn mode; preserve both scripts and first readback.','second_audit_passed':True})
write(ROOT/'output/h5-short443-fixed-core-preflight-20261104/diagnostics.json',{'floating_regions_are_not_negative_certificates':True,
    'empty_vertical_polygon_serializes_nan_bounds':True,'original_raw_output_preserved':True,
    'conservative_0_226_mm_domains_do_not_cover_all_guard_valid_placements':True,
    'authoritative_negative_proof':'Exact inner-rectangle zero-clearance relaxation in h5-short443-fixed-core-capacity-20261104/audit-v2.',
    'exact_proof_uses_fixed_core_source_rows_and_original_geometry_only':True})
# Preserve the successful pre-push CI snapshot; no remote mutation here.
ci=json.loads(subprocess.check_output(['gh','run','view','41901621693','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True))
assert ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs'])
assert ci['headSha']=='e47197f12ff3a9b0a9ea44622b1f22fa7966f150'
write(BASE/'prior-main-ci.json',ci)
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')]
setup=setup.replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation.json','audit-preflight-failure.json','audit-attempts.json']")
exec(setup)
folders=[ROOT/'output'/n for n in ['h5-expanded-row-integer-reduction-20261104','h5-expanded-row-integer-reduction-process-20261104',
    'h5-expanded-row-geometric-merge-20261104','h5-expanded-row-geometric-merge-process-20261104',
    'h5-short443-integer-regions-20261104','h5-short443-preparation-process-20261104','h5-short443-model-process-20261104',
    'h5-short443-fixed-core-preflight-20261104','h5-short443-fixed-core-capacity-20261104']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*short443*20261104.py','*h5*expanded_row*reduction*20261104.py','*h5*expanded_row*merge*20261104.py','*h5*row_reductions*20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,'h5-short443-checkpoint-report-20261104.md','h5-short443-checkpoint-sealing-attempts.json']:
    add('helpers/'+name,ROOT/'output'/name)
walk=old[old.index('while queue:'):old.index('for source,name in [(')]
walk=walk.replace("for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):","""try:
            tree=ast.parse(p.read_text(encoding='utf-8'))
        except SyntaxError:
            failure=load(BASE/'audit-preflight-failure.json')
            assert p==ROOT/failure['script'] and digest(p)==failure['script_sha256']
            continue
        for node in ast.walk(tree):""")
exec(walk)
copies=[(RED/'audit/checks.json','integer-reduction-audit.json'),(MERGE/'source-region-audit/checks.json','merged-source-region-audit.json'),
    (ROOT/'output/h5-expanded-row-geometric-merge-process-20261104/process.json','merge-process.json'),
    (BASE/'audit/checks.json','short-source-mode-audit.json'),(BASE/'geometry-audit/checks.json','short-integer-audit.json'),
    (BASE/'model-audit/checks.json','short-model-audit.json'),(BASE/'final-preparation.json','short-preparation-charges.json'),
    (BASE/'response-audit/checks.json','short-response-audit.json'),(BASE/'inventory.json','short-inventory.json'),
    (BASE/'audit-preflight-failure.json','model-audit-first-attempt.json'),(CAP/'audit-attempts.json','capacity-audit-attempts.json'),
    (CAP/'audit-v2/checks.json','fixed-core-capacity-audit.json'),(CAP/'audit-v2/source-partitions.json','source-partition-certificates.json'),
    (CAP/'audit-v2/insert-inner-rectangle-certificates.json','insert-inner-rectangle-certificates.json'),
    (CAP/'checks.json','fixed-core-capacity-preparation.json'),(BASE/'prior-main-ci.json','prior-main-ci.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'next-step.json',{'closed_short443_call_must_not_be_repeated':True,'closed_model_sha256':load(BASE/'model-audit/checks.json')['model_sha256'],
    'row_reductions_do_not_warrant_new_calls':True,'retained_fixed_seven_part_core_capacity':2,
    'next_method':'Assess a coordinated source construction that moves the four brackets and three cogs while placing all four inserts. The older fixed core is now exactly excluded for four inserts, so do not spend another packing call on it. A different mechanism must use fresh source-certified geometry and charge every preparation; changing the cog phase or seed alone is not sufficient justification to retry the closed joint short443 model. Alternatively assess a different whole-job allocation against the existing necessary frontier. Retain both the valid old 5/4/2 short sheet and valid old 4/2/3 short sheet. No first55 search is qualified for the new 4/4/3 allocation without a source-valid short11.',
    'new_construction_prepared':False,'full66_source_required_before_native':True,'remaining_allocation_candidates':440,
    'fixed_cog_frontier':{'site_choices':2,'count_distributions':3},'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'row_reduction_solver_calls':0,'new_short443_closed_calls':1,'short443_status':'UNKNOWN','assignments':0,
    'solve_slice_overrun_seconds':response['solve_slice_overrun_seconds'],'overall_algorithm_shared_overruns_seconds':0,
    'fixed_core_continuous_insert_capacity':2,'whole_allocation_excluded':False,'remaining_allocation_candidates':440,
    'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-short443-checkpoint-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 row reductions and three-cog allocation:** [independent audits]({link}) find the expanded-row reductions too small to justify new calls. A distinct 4-bracket/4-insert/3-cog short-sheet model has 7,071 variables / 23,988 constraints; its sole 25/35-second stage closes UNKNOWN without an assignment. The 0.059281 s solve-slice overrun is preserved; complete preparation-inclusive algorithm/shared totals are 22.074408 / 22.142098 s. An exact original-source inner-rectangle proof shows the older fixed four-bracket/three-cog core can hold at most two inserts even at zero clearance. This excludes only that fixed core, not the whole allocation; all 440 candidates remain. Further construction must move the core or use a genuinely different allocation/mechanism. Full66 validation and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [expanded joint and staged row constructions](../benchmarks/results/h5-expanded-joint-and-staged-row-constructions-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [row reductions and three-cog allocation](../benchmarks/results/{NAME}.md).',1)
a='The expanded joint and deterministic staged constructions are audited; their\nsole calls close UNKNOWN and grid-INFEASIBLE without a placement. A certified\ninteger-domain reduction is the next method to assess before further search.'
b='Expanded-row reductions are audited but do not justify another call. The new\n4/4/3 short-sheet call closes UNKNOWN; an exact proof limits the older fixed\nfour-bracket/three-cog core to two inserts. A new construction must move the core.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
