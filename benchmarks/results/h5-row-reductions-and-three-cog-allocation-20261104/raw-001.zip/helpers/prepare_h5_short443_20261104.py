from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-short443-integer-regions-20261104'
OLD=ROOT/'output/h5-short11-integer-mode-regions-20261029'
MODES=ROOT/'output/h5-short11-all-modes-preflight-20261029'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
FRONTIER=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
BASE.mkdir();started=time.perf_counter()
short=[['bracket',i] for i in [7,8,10,11]]+[['cog',i] for i in [0,13,14]]+[['insert',i] for i in [4,5,6,7]]
job=load(JOB);universe=[[p['id'],i] for p in job['parts'] for i in range(p['quantity'])]
first=[v for v in universe if v not in short]
assert len(first)==55 and len(short)==11 and len({tuple(v) for v in first+short})==66
frontier=load(FRONTIER)
if isinstance(frontier,dict):
    raise AssertionError('Inspect unexpected frontier structure before proceeding')
matching=[r for r in frontier if r['short_counts']==[4,4,3]]
assert len(matching)==1 and matching[0]['excluded_by'] is None and matching[0]['first_counts']==[18,8,17,12]
for name in ['family-modes.json','integer-templates.json']:
    shutil.copyfile(OLD/name,BASE/name)
shutil.copyfile(MODES/'geometry-library.json',BASE/'geometry-library.json')
modes=load(BASE/'family-modes.json');templates=load(BASE/'integer-templates.json')
indices={tuple(t['geometries']):i for i,t in enumerate(templates)}
assert len(indices)==len(templates)==95
instances=[{'identity':v,'mode_count':len(modes[v[0]])} for v in short]
pairs=[]
for a,b in combinations(range(11),2):
    gs=[sorted({m['normalized_geometry'] for m in modes[short[o][0]]}) for o in [a,b]]
    geometry_pairs=list(product(*gs))
    pairs.append({'owners':[a,b],'identities':[short[a],short[b]],'geometry_pairs':[list(g) for g in geometry_pairs],'template_indices':[indices[g] for g in geometry_pairs]})
write(BASE/'instances.json',instances);write(BASE/'owner-pairs.json',pairs)
write(BASE/'inventory.json',{'short11_identities':short,'mandatory_first55_identities':first,'short_counts':[4,4,3],'first_counts':[18,8,17,12],'all66_originals_accounted_once':True})
inputs=[Path(__file__),ROOT/'output/prepare_h5_short443_helpers_20261104.py',JOB,FRONTIER,MODES/'geometry-library.json',
    OLD/'plan.json',OLD/'checks.json',OLD/'family-modes.json',OLD/'integer-templates.json',OLD/'geometry-audit/plan.json',OLD/'geometry-audit/checks.json']
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'A distinct whole-job split: short 4 brackets, 4 inserts, 3 cogs; first 18 frames, 8 brackets, 17 inserts, 12 cogs. Reuse unchanged source-certified intrinsic geometry and integer planes, rebuild every owner-mode pair and all identity constraints. One short-sheet stage at fixed 7 degree cog phase; no old solver result or placement is used. A negative result is restricted to this conservative grid model and cannot exclude the allocation. Any later first-sheet stage must charge this complete stage and remain within whole-job 60/90 seconds.',
    'position_units_per_mm':1000,'normal_coefficient_scale':1000000000,'relative_domain_envelope_mm':[1500,320],
    'algorithm_seconds':25,'shared_seconds':35,'whole_job_algorithm_seconds':60,'whole_job_shared_seconds':90,
    'source_validation_reserve_seconds':3,'maximum_calls':1,'retry_permitted':False,'solver_calls':0})
checks={'passed':True,'seconds':time.perf_counter()-started,'short_originals':11,'first_originals':55,'all66_originals_accounted_once':True,
    'source_mode_options':sum(i['mode_count'] for i in instances),'owner_pairs':len(pairs),
    'source_mode_pairs':sum(instances[a]['mode_count']*instances[b]['mode_count'] for a,b in combinations(range(11),2)),
    'region_selectors':sum(len(templates[t]['regions']) for p in pairs for t in p['template_indices']),
    'solver_calls':0,'native_calls':0,'H5_complete':False}
write(BASE/'checks.json',checks);print(checks)
