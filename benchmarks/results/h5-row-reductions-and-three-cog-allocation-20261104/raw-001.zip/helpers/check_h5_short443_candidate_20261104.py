"""Read a joint-mode integer assignment back into all eleven original source contours."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, sys, time
from h5_legacy64_source_readback import audit

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-short443-integer-regions-20261104'
SEARCH = BASE / 'search'
OUT = SEARCH / 'source-response'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

started = float(sys.argv[1])
OUT.mkdir()
values = load(SEARCH / 'assignment.json')
mapping = load(BASE / 'model/mapping.json')
rows, chosen = [], []
for owner in mapping['owners']:
    selected = [m for m in owner['modes'] if values[m['selector']] == 1]
    assert len(selected) == 1
    mode = selected[0]
    position = [values[v]/mapping['position_units_per_mm'] for v in owner['positions']]
    rows.append({'part_id': owner['identity'][0], 'copy_index': owner['identity'][1], 'sheet_id': 'sheet-1',
                 'transform': {'rotation_radians': mode['rotation_radians'], 'mirrored': mode['mirrored'],
                               'translation': [position[k]+mode['translation_from_lower_left'][k] for k in [0, 1]]}})
    chosen.append({'owner': owner['owner'], 'identity': owner['identity'], 'mode': mode['mode'],
                   'geometry': mode['normalized_geometry'], 'lower_left_mm': position})
for pair in mapping['pairs']:
    selected = [r for r in pair['regions'] if values[r['selector']] == 1]
    assert len(selected) == 1 and selected[0]['geometries'] == [chosen[i]['geometry'] for i in pair['owners']]
job, stock = load(JOB), load(STOCK)
inventory = load(BASE / 'inventory.json')
expected = list(map(tuple, inventory['short11_identities']))
assert len(rows) == 11 and len(inventory['mandatory_first55_identities']) == 55
check = audit(job, rows, {'sheet-1': stock['source_stock']}, stock['required_pair_gap_mm'], stock['stock_guard_mm'], expected)
parts = {p['id']: p for p in job['parts']}
assert check['cutouts'] == sum(len(parts[f]['geometry'][0].get('holes', [])) for f, i in expected)
assert check['hole_vertices'] == sum(sum(len(h) for h in parts[f]['geometry'][0].get('holes', [])) for f, i in expected)
write(OUT / 'candidate-source11.json', rows)
write(OUT / 'selected-modes.json', chosen)
write(OUT / 'original-source-checks.json', check)
inputs = [Path(__file__), ROOT / 'output/h5_legacy64_source_readback.py', JOB, STOCK,
          BASE / 'model/mapping.json', BASE / 'inventory.json', SEARCH / 'assignment.json', SEARCH / 'assignment-check.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
write(OUT / 'checks.json', {'source_valid11': check['valid'], 'originals': 11, 'required_first_originals': 55,
                          'same_sheet_pairs': check['same_sheet_pairs'], 'stock_edges': check['stock_edges'],
                          'cutouts': check['cutouts'], 'hole_vertices': check['hole_vertices'],
                          'source_checker_calls': 1, 'algorithm_seconds_including_preparation': time.perf_counter()-started,
                          'source_valid66': False, 'native_calls': 0, 'H5_complete': False})
print(load(OUT / 'checks.json'))
