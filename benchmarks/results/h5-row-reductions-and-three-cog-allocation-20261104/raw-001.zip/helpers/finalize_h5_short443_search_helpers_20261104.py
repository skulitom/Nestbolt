"""Finalize complete-process charges and prepare the single new short-sheet call."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
BASE=OUT/'h5-short443-integer-regions-20261104'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def save(p,s):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
old=OUT/'audit_h5_short443_model_20261104.py'
assert not (BASE/'model-audit').exists()
s=old.read_text()
bad="prior_symmetry.extend([[family,[a['owner'],b['owner']]] for a,b in zip(same,same[1:]))"
assert bad in s
s=s.replace(bad,"prior_symmetry.extend([[family,[a['owner'],b['owner']]] for a,b in zip(same,same[1:])])")
s=s.replace("inputs = [Path(__file__),", "inputs = [Path(__file__), BASE/'final-preparation.json', BASE/'audit-preflight-failure.json',")
save(OUT/'audit_h5_short443_model_v2_20261104.py',s)
write(BASE/'audit-preflight-failure.json',{'utc':datetime.now(timezone.utc).isoformat(),'script':old.relative_to(ROOT).as_posix(),
    'script_sha256':digest(old),'exit_code':1,'error':"SyntaxError at line 115: closing parenthesis ')' does not match opening parenthesis '['",
    'failed_before_model_audit_directory_creation':True,'model_unchanged':True,'solver_calls':0})
charges=load(BASE/'model/preparation-charges.json')
internal=charges.pop('cp_model_build_internal_seconds')
process=OUT/'h5-short443-model-process-20261104/process.json'
assert load(process)['exit_code']==0 and not load(process)['timeout']
charges['cp_model_complete_process_seconds']=load(process)['complete_process_seconds']
inputs=[Path(__file__),BASE/'model/preparation-charges.json',process,OUT/'h5-short443-preparation-process-20261104/process.json']
write(BASE/'final-preparation.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'charges':charges,'internal_model_build_seconds_replaced_by_complete_process':internal,
    'preparation_seconds_charged':sum(charges.values()),'algorithm_seconds':25,'shared_seconds':35,'source_validation_reserve_seconds':3})

s=(OUT/'check_h5_integer_mode_candidate_20261029.py').read_text().replace('h5-short11-integer-mode-regions-20261029','h5-short443-integer-regions-20261104')
save(OUT/'check_h5_short443_candidate_20261104.py',s)
s=(OUT/'run_h5_integer_mode_regions_20261029.py').read_text().replace('h5-short11-integer-mode-regions-20261029','h5-short443-integer-regions-20261104')
s=s.replace('check_h5_integer_mode_candidate_20261029.py','check_h5_short443_candidate_20261104.py')
s=s.replace('remaining = 60-','remaining = 25-').replace('90-(','35-(')
s=s.replace("'algorithm_seconds': 60", "'algorithm_seconds': 25").replace("'shared_seconds': 90","'shared_seconds': 35")
s=s.replace('algorithm-60','algorithm-25')
s=s.replace("load(MODEL / 'checks.json')['preparation_seconds_charged']","load(BASE/'final-preparation.json')['preparation_seconds_charged']")
s=s.replace("BASE / 'plan.json', MODEL / 'plan.json'","BASE / 'plan.json', BASE/'final-preparation.json', MODEL / 'plan.json'")
s=s.replace('One declared 60/90-second','One declared 25/35-second short-stage')
s=s.replace("for folder in [BASE, MODEL, BASE / 'model-audit', BASE / 'geometry-audit']:","for folder in [BASE, MODEL, BASE / 'model-audit', BASE / 'geometry-audit']:")
save(OUT/'run_h5_short443_20261104.py',s)
print({'final_preparation_seconds':sum(charges.values()),'model_internal_seconds_replaced':internal})
