"""Prepare a distinct 4-bracket/4-insert/3-cog short-sheet construction."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output'
NEW='h5-short443-integer-regions-20261104'
OLD='h5-short11-integer-mode-regions-20261029'

def save(name,text):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)

save('prepare_h5_short443_20261104.py',r'''from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-short443-integer-regions-20261104'
OLD=ROOT/'output/h5-short11-integer-mode-regions-20261029'
MODES=ROOT/'output/h5-short11-all-modes-preflight-20261029'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
FRONTIER=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
BASE.mkdir();started=time.perf_counter()
short=[['bracket',i] for i in [7,8,10,11]]+[['cog',i] for i in [0,13,14]]+[['insert',i] for i in [4,5,6,7]]
job=load(JOB);universe=[[p['id'],i] for p in job['parts'] for i in range(p['quantity'])]
first=[v for v in universe if v not in short]
assert len(first)==55 and len(short)==11 and len({tuple(v) for v in first+short})==66
frontier=load(FRONTIER)
if isinstance(frontier,dict):
    raise AssertionError('Inspect unexpected frontier structure before proceeding')
matching=[r for r in frontier if r['short_counts']==[4,4,3]]
assert len(matching)==1 and matching[0]['excluded_by'] is None and matching[0]['first_counts']==[18,8,17,12]
for name in ['family-modes.json','integer-templates.json']:
    shutil.copyfile(OLD/name,BASE/name)
shutil.copyfile(MODES/'geometry-library.json',BASE/'geometry-library.json')
modes=load(BASE/'family-modes.json');templates=load(BASE/'integer-templates.json')
indices={tuple(t['geometries']):i for i,t in enumerate(templates)}
assert len(indices)==len(templates)==95
instances=[{'identity':v,'mode_count':len(modes[v[0]])} for v in short]
pairs=[]
for a,b in combinations(range(11),2):
    gs=[sorted({m['normalized_geometry'] for m in modes[short[o][0]]}) for o in [a,b]]
    geometry_pairs=list(product(*gs))
    pairs.append({'owners':[a,b],'identities':[short[a],short[b]],'geometry_pairs':[list(g) for g in geometry_pairs],'template_indices':[indices[g] for g in geometry_pairs]})
write(BASE/'instances.json',instances);write(BASE/'owner-pairs.json',pairs)
write(BASE/'inventory.json',{'short11_identities':short,'mandatory_first55_identities':first,'short_counts':[4,4,3],'first_counts':[18,8,17,12],'all66_originals_accounted_once':True})
inputs=[Path(__file__),ROOT/'output/prepare_h5_short443_helpers_20261104.py',JOB,FRONTIER,MODES/'geometry-library.json',
    OLD/'plan.json',OLD/'checks.json',OLD/'family-modes.json',OLD/'integer-templates.json',OLD/'geometry-audit/plan.json',OLD/'geometry-audit/checks.json']
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'A distinct whole-job split: short 4 brackets, 4 inserts, 3 cogs; first 18 frames, 8 brackets, 17 inserts, 12 cogs. Reuse unchanged source-certified intrinsic geometry and integer planes, rebuild every owner-mode pair and all identity constraints. One short-sheet stage at fixed 7 degree cog phase; no old solver result or placement is used. A negative result is restricted to this conservative grid model and cannot exclude the allocation. Any later first-sheet stage must charge this complete stage and remain within whole-job 60/90 seconds.',
    'position_units_per_mm':1000,'normal_coefficient_scale':1000000000,'relative_domain_envelope_mm':[1500,320],
    'algorithm_seconds':25,'shared_seconds':35,'whole_job_algorithm_seconds':60,'whole_job_shared_seconds':90,
    'source_validation_reserve_seconds':3,'maximum_calls':1,'retry_permitted':False,'solver_calls':0})
checks={'passed':True,'seconds':time.perf_counter()-started,'short_originals':11,'first_originals':55,'all66_originals_accounted_once':True,
    'source_mode_options':sum(i['mode_count'] for i in instances),'owner_pairs':len(pairs),
    'source_mode_pairs':sum(instances[a]['mode_count']*instances[b]['mode_count'] for a,b in combinations(range(11),2)),
    'region_selectors':sum(len(templates[t]['regions']) for p in pairs for t in p['template_indices']),
    'solver_calls':0,'native_calls':0,'H5_complete':False}
write(BASE/'checks.json',checks);print(checks)
''')

# Repeat the original-source affine/corner audit on the new inventory.
s=(OUT/'h5-short11-all-modes-preflight-20261029/audit/audit.py').read_text()
s=s.replace("BASE = ROOT / 'output/h5-short11-all-modes-preflight-20261029'",f"BASE = ROOT / 'output/{NEW}'")
s=s.replace('232','204').replace('58','51')
save('audit_h5_short443_source_20261104.py',s)

# Reprove every inward integer plane, with a new complete owner-pair mapping.
s=(OUT/f'{OLD}/geometry-audit/audit.py').read_text()
s=s.replace(f"BASE = ROOT / 'output/{OLD}'",f"BASE = ROOT / 'output/{NEW}'")
s=s.replace("assert load(BASE / 'owner-pairs.json') == load(REGIONS / 'owner-pairs.json')\nassert load(BASE / 'instances.json') == load(MODES / 'instances.json')\nassert load(BASE / 'inventory.json') == load(MODES / 'inventory.json')",r'''
from itertools import combinations,product
assert load(BASE/'audit/checks.json')['passed']
instances=load(BASE/'instances.json')
inventory=load(BASE/'inventory.json')
assert inventory['short_counts']==[4,4,3] and inventory['first_counts']==[18,8,17,12]
expected_pairs=[]
indices={tuple(t['geometries']):i for i,t in enumerate(templates)}
for a,b in combinations(range(11),2):
    ids=[instances[o]['identity'] for o in [a,b]]
    gs=[sorted({m['normalized_geometry'] for m in integer_modes[v[0]]}) for v in ids]
    pairs=list(product(*gs))
    expected_pairs.append({'owners':[a,b],'identities':ids,'geometry_pairs':[list(g) for g in pairs],'template_indices':[indices[g] for g in pairs]})
assert load(BASE/'owner-pairs.json')==expected_pairs
assert sum(instances[a]['mode_count']*instances[b]['mode_count'] for a,b in combinations(range(11),2))==1139
''')
s=s.replace("inputs = [Path(__file__),","inputs = [Path(__file__), BASE/'audit/plan.json', BASE/'audit/checks.json',")
save('audit_h5_short443_integer_20261104.py',s)

# Model uses the same audited intrinsic planes; count all selectors afresh.
s=(OUT/f'{OLD}/model/build.py').read_text().replace(f"BASE = ROOT / 'output/{OLD}'",f"BASE = ROOT / 'output/{NEW}'")
s=s.replace('assert len(model.proto.variables) == 80','assert len(model.proto.variables) == 73')
s=s.replace("assert validation == '' and len(model.proto.variables) == 7634","assert validation == ''")
a=s.index("charges = {");b=s.index("inputs = ",a)
s=s[:a]+"""charges = {'prior_source_mode_and_template_preparation_seconds': load(PRIOR / 'checks.json')['preparation_seconds_charged'],
           'prior_integer_plane_preparation_seconds': load(ROOT/'output/h5-short11-integer-mode-regions-20261029/checks.json')['seconds'],
           'new_inventory_complete_process_seconds': load(ROOT/'output/h5-short443-preparation-process-20261104/process.json')['complete_process_seconds'],
           'cp_model_build_internal_seconds': elapsed}
write(OUT / 'preparation-charges.json', charges)
"""+s[b:]
s=s.replace("inputs = [Path(__file__),","inputs = [Path(__file__), ROOT/'output/h5-short443-preparation-process-20261104/process.json', ROOT/'output/h5-short11-integer-mode-regions-20261029/checks.json',")
s=s.replace("'source_mode_options': 58, 'region_selectors': 7554","'source_mode_options': 51, 'region_selectors': sum(len(p['regions']) for p in pairs)")
s=s.replace("'guarded_mode_stock_domains': 116, 'both_owner_mode_marginals': 500","'guarded_mode_stock_domains': 102, 'both_owner_mode_marginals': sum(len(p['mode_marginals']) for p in pairs)")
save('build_h5_short443_20261104.py',s)

# Reconstruct every protobuf field independently; derive counts from templates.
s=(OUT/f'{OLD}/model-audit/audit.py').read_text().replace(f"BASE = ROOT / 'output/{OLD}'",f"BASE = ROOT / 'output/{NEW}'")
s=s.replace('assert len(p.variables) == 7634 and len(p.constraints) == 26264','assert len(p.variables) > 73 and len(p.constraints) > 100')
s=s.replace('selector < 80','selector < 73').replace('80 <= selector < 7634','73 <= selector < len(p.variables)')
s=s.replace("prior_symmetry = load(PRIOR / 'audit/symmetry-review.json')['ordered_adjacent_copy_pairs']",r"""prior_symmetry=[]
for family in ['bracket','insert','cog']:
    same=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1])
    prior_symmetry.extend([[family,[a['owner'],b['owner']]] for a,b in zip(same,same[1:]))
""")
s=s.replace('set(range(7634))','set(range(len(p.variables)))').replace('set(range(26264))','set(range(len(p.constraints)))')
s=s.replace('assert mode_count == 58 and region_count == 7554 and plane_count == 25574 and marginal_count == 500',"""assert mode_count == 51
assert region_count==sum(len(templates[t]['regions']) for p in owner_pairs for t in p['template_indices'])
assert plane_count==sum(len(r['planes']) for p in owner_pairs for t in p['template_indices'] for r in templates[t]['regions'])
assert marginal_count==sum(len({m['normalized_geometry'] for m in owners[o]['modes']}) for p in owner_pairs for o in p['owners'])
assert len(p.variables)==22+mode_count+region_count
assert len(p.constraints)==2*mode_count+11+plane_count+55+marginal_count+8""")
s=s.replace("assert load(BASE / 'inventory.json') == load(PRIOR / 'inventory.json')","assert load(BASE/'audit/checks.json')['passed']")
s=s.replace("'guarded_mode_stock_domains_verified': 116","'guarded_mode_stock_domains_verified': 102")
save('audit_h5_short443_model_20261104.py',s)

save('run_h5_short443_preparation_20261104.py',r'''from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,time,sys
ROOT=Path(__file__).resolve().parents[1]
phase=sys.argv[1]
assert phase in ['preparation','model']
script=ROOT/('output/prepare_h5_short443_20261104.py' if phase=='preparation' else 'output/build_h5_short443_20261104.py')
out=ROOT/('output/h5-short443-'+phase+'-process-20261104');out.mkdir()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=time.perf_counter()
write(out/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'script':script.relative_to(ROOT).as_posix(),'script_sha256':sha256(script.read_bytes()).hexdigest(),'maximum_process_seconds':10,'retry_permitted':False})
try:
    r=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(script)],cwd=ROOT,capture_output=True,timeout=10)
    result={'exit_code':r.returncode,'timeout':False};stdout,stderr=r.stdout,r.stderr
except subprocess.TimeoutExpired as e:
    result={'timeout':True};stdout,stderr=e.stdout or b'',e.stderr or b''
elapsed=time.perf_counter()-started
(out/'stdout.txt').write_bytes(stdout);(out/'stderr.txt').write_bytes(stderr)
result.update({'complete_process_seconds':elapsed,'complete_process_cap_overrun_seconds':max(0,elapsed-10),'closed':True})
write(out/'process.json',result);print(result);print(stdout.decode(errors='replace'));print(stderr.decode(errors='replace'))
''')
print('Prepared new allocation, source/integer audits, model builder/auditor and complete-process runner.')
