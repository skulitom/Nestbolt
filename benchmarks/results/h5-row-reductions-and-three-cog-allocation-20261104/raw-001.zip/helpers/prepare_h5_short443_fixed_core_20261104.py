"""Inspect continuous insert-placement space around the older source-valid seven-part core."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,math,time
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-short443-fixed-core-preflight-20261104'
OLD=ROOT/'output/h5-legacy64-sliding-geometry-20261026'
NEW=ROOT/'output/h5-short443-integer-regions-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
STOCK=ROOT/'output/h5-short-two-cog-exchange-20261028/plan.json'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transform(v,t):
    a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    return [[m*x*c-y*s+tx,m*x*s+y*c+ty] for x,y in v]
OUT.mkdir();started=time.perf_counter()
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,PIECES,STOCK,OLD/'short-repair/placements.json',
    OLD/'short-repair/result.json',OLD/'short-repair/plan.json',OLD/'prepared.json',NEW/'inventory.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Keep the older source-valid four-bracket/three-cog core and its exact transforms. Relabel identical family copies to the new full66 inventory. Both existing inserts are released; assess all four required inserts jointly in the continuous source-derived free space. Construct two filled-geometry domains by subtracting every core source-piece Minkowski obstacle. These floating domains require independent source certification before construction; their count or emptiness alone is not a continuous exclusion.',
    'algorithm_seconds':20,'shared_seconds':30,'solver_calls':0,'maximum_calls':0,'new_orientation_search':False,'negative_coverage_claimed':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};stock=load(STOCK);canonical=load(PIECES)
rows=load(OLD/'short-repair/placements.json')
mapping_ids={'bracket':dict(zip([0,3,8,9],[7,8,10,11])),'insert':{12:4,13:5},'cog':{0:0,1:13,2:14}}
for r in rows:r['copy_index']=mapping_ids[r['part_id']][r['copy_index']]
core=[r for r in rows if r['part_id']!='insert']
inventory=load(NEW/'inventory.json')
assert set((r['part_id'],r['copy_index']) for r in core)|{('insert',i) for i in [4,5,6,7]}==set(map(tuple,inventory['short11_identities']))
control=audit(job,rows,{'sheet-1':stock['source_stock']},stock['required_pair_gap_mm'],stock['stock_guard_mm'])
corecheck=audit(job,core,{'sheet-1':stock['source_stock']},stock['required_pair_gap_mm'],stock['stock_guard_mm'])
assert control['valid'] and corecheck['valid']
write(OUT/'fixed-source7.json',core);write(OUT/'source9-control.json',rows);write(OUT/'source9-checks.json',control);write(OUT/'fixed-source7-checks.json',corecheck);write(OUT/'inventory.json',inventory)
corepieces=[]
for r in core:
    pieces=[transform(v,r['transform']) for v in canonical[r['part_id']]]
    source=Polygon(transform(parts[r['part_id']]['geometry'][0]['outer'],r['transform']))
    assert unary_union([Polygon(v) for v in pieces]).symmetric_difference(source).area<1e-7
    corepieces.extend(pieces)
free_records=[]
for geometry,(width,height) in enumerate([(180,110),(110,180)]):
    moving=np.array([[0,0],[width,0],[width,height],[0,height]],dtype=float)
    obstacles=[MultiPoint((np.asarray(v)[:,None,:]-moving[None,:,:]).reshape(-1,2)).convex_hull for v in corepieces]
    raw=unary_union(obstacles)
    inflated=raw.buffer(.226/math.cos(math.pi/32),quad_segs=8)
    st=stock['source_stock'];domain=box(st[0]+.025,st[1]+.025,st[2]-.025-width,st[3]-.025-height)
    free=domain.difference(inflated)
    triangles=list(shapely.constrained_delaunay_triangles(free).geoms) if not free.is_empty else []
    record={'geometry':geometry,'dimensions':[width,height],'domain':list(domain.bounds),
        'free':mapping(free),'regions':[list(map(list,p.exterior.coords[:-1])) for p in triangles],
        'components':[{'bounds':list(p.bounds),'area_mm2':p.area} for p in ([free] if free.geom_type=='Polygon' else free.geoms)],
        'free_space_area_mm2':free.area,'source_safe_certification_pending':True}
    free_records.append(record)
    assert time.perf_counter()-started<20
write(OUT/'free-regions.json',free_records)
checks={'passed':True,'seconds':time.perf_counter()-started,'fixed_core_originals':7,'source9_control_valid':True,
    'required_insert_originals':4,'full66_inventory_preserved':True,'original_core_pieces':len(corepieces),
    'geometry_regions':[len(r['regions']) for r in free_records],'geometry_components':[len(r['components']) for r in free_records],
    'component_bounds':[[c['bounds'] for c in r['components']] for r in free_records],
    'new_source_valid11':False,'source_valid66':False,'negative_coverage_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
