from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_cog_row_overlap_regions_20261104.py').read_text(encoding='utf-8').replace('h5-cog-row-overlap-regions-process-20261104','h5-expanded-row-integer-reduction-process-20261104').replace('prepare_h5_cog_row_overlap_regions_20261104.py','prepare_h5_expanded_row_integer_reduction_20261104.py')
p=ROOT/'output/run_h5_expanded_row_integer_reduction_20261104.py'
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
