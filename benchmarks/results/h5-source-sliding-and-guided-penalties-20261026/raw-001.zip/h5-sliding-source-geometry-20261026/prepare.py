"""Source configuration obstacles for a bounded joint sliding experiment."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time
from shapely.geometry import Polygon,mapping
from shapely.affinity import affine_transform
import diagnose_h5_concave_gaps as geom
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-sliding-source-geometry-20261026';CORE=ROOT/'output/h5-eight-bracket-short-core-20261026/audit-horizontal-mode-repaired';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'free').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();deadline=start+180
spec=load(CORE/'next-neighborhood.json');assert load(CORE/'checks.json')['passed'] and spec['mandatory_moving_family_counts']=={'bracket':4,'insert':5,'cog':15};job=load(JOB);parts={p['id']:p for p in job['parts']};guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);geom.EPS=.0126
inputs=[JOB,CORE/'next-neighborhood.json',CORE/'checks.json',ROOT/'output/h5-mixed-rows-contact-pool-20261026/response-audit-log-precision-repaired/checks.json',Path(geom.__file__)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'preparation_seconds':180,'search_seconds':60,'shared_search_seconds':90,'maximum_positional_stages':4,'per_stage_maximum_iterations':300,'per_stage_maximum_function_evaluations':700,'finite_cog_phases_degrees':[0,4.5,9,13.5],'allowed_bracket_modes':8,'insert_outer_classes':2,'required_pair_gap_mm':required,'stock_guard_mm':guard,'construction_eps_mm':geom.EPS,'method':'All24 current movers slide simultaneously in48 continuous coordinates around the verified29 first-sheet originals, retaining13 fixed short originals. Build source Minkowski collision obstacles from exactly covering convex pieces and conservative mitred clearance buffers. Build each orientation\'s complete fixed-core/stock free-anchor region. A squared signed-distance penalty uses nearest obstacle boundaries for overlapping moving pairs and nearest free-region points for fixed/stock violations. Numerical finite-difference checks precede optimization. One bounded run alternates at most4 L-BFGS positional stages with deterministic strictly improving original-mode changes; it has one initial configuration, no random restarts and no native call unless all66 actual outlines pass independent readback. Fifteen cogs start on a source-derived0/13.5-degree checkerboard; four corner brackets and five spread inserts may initially overlap. No quantity is dropped. Geometry preparation and this diagnostic search do not constitute a60-second H5 quality run. A local minimum or time limit proves no infeasibility. Prior calls remain closed.'})
def world(p):
    t=p['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1;return affine_transform(Polygon(parts[p['part_id']]['geometry'][0]['outer']),[m*c,-s,m*s,c,*t['translation']])
modes=[];shapes=[]
for family,angles,mirrors in [('cog',[math.radians(d) for d in [0,4.5,9,13.5]],[False]),('bracket',[q*math.pi/2 for q in range(4)],[False,True]),('insert',[0.,math.pi/2],[False])]:
    for mirror in mirrors:
        for a in angles:
            c,s=math.cos(a),math.sin(a);m=-1 if mirror else 1;g=affine_transform(Polygon(parts[family]['geometry'][0]['outer']),[m*c,-s,m*s,c,0,0])
            offset=[-139.723742*c+139.723742*s,-139.723742*s-139.723742*c] if family=='cog' else [-g.bounds[0],-g.bounds[1]]
            g=affine_transform(g,[1,0,0,1,*offset]);modes.append({'index':len(modes),'family':family,'angle':a,'mirrored':mirror,'source_translation_offset':offset,'anchor_kind':'original cog center' if family=='cog' else 'rotated outer lower left','geometry':mapping(g)});shapes.append(g)
fixed=[world(p) for p in spec['fixed_first_placements']];stock=job['stocks'][0];free=[]
for i,g in enumerate(shapes):
    assert time.perf_counter()<deadline;region=geom.regions(g,fixed,stock,job['edge_clearance'],required);assert not region.is_empty and region.is_valid;free.append(region);write(OUT/'free'/f'{i:02d}.json',mapping(region))
for i,a in enumerate(shapes):
    for j in range(i,len(shapes)):
        assert time.perf_counter()<deadline;obstacle=geom.obstacle(a,shapes[j],required);assert not obstacle.is_empty and obstacle.is_valid;write(OUT/'obstacles'/f'{i:02d}-{j:02d}.json',mapping(obstacle))
items=load(ROOT/'output/h5-source-orientation-construction-20261025/items.json');moving=[]
for original in spec['mandatory_moving_first_originals']:
    family=items[original]['family'];allowed=[r['index'] for r in modes if r['family']==family]
    if family=='bracket':
        k=original-26;angle=[0.,0.,math.pi,math.pi][k];mirror=[False,True,True,False][k];mode=next(r['index'] for r in modes if r['family']==family and r['angle']==angle and r['mirrored']==mirror);xy=[[6.525,2107.875],[1193.475,2107.875],[6.525,2743.475],[1193.475,2743.475]][k]
    elif family=='insert':
        k=original-46;mode=12 if k<3 else 13;xy=[[400.,2170.],[800.,2170.],[600.,2860.],[350.,2530.],[1040.,2530.]][k]
    else:
        row,col=divmod(original-51,5);mode=0 if (row+col)%2==0 else 3;xy=[750.+(col-2)*261.25,2550.675+(row-1)*261.25]
    moving.append({'original':original,'family':family,'copy_index':items[original]['copy'],'allowed_modes':allowed,'initial_mode':mode,'initial_anchor':xy})
assert len(moving)==24 and len(modes)==14;write(OUT/'modes.json',modes);write(OUT/'inventory.json',spec);write(OUT/'moving.json',moving)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'modes':14,'free_regions':14,'unordered_configuration_obstacles':105,'moving_originals':24,'position_variables':48,'fixed_first_originals':29,'fixed_short_originals':13,'all66_originals_accounted':True,'optimizer_opened':False,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
