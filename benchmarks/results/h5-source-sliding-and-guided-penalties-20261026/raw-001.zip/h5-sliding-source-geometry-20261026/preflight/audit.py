"""Direct source modes, finite geometry samples and numerical penalty-gradient checks."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,Point,shape
from h5_sliding_objective import SlidingObjective
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-sliding-source-geometry-20261026';OUT=BASE/'preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};objective=SlidingObjective(BASE);moving=objective.moving;modes=objective.modes;inventory=load(BASE/'inventory.json');required=plan['required_pair_gap_mm'];guard=plan['stock_guard_mm'];assert len(moving)==24 and sorted(r['original'] for r in moving)==list(range(26,30))+list(range(46,66))
def source_shape(p):
    t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[p['part_id']]['geometry'][0]['outer']])
shapes=[]
for mode in modes:
    p={'part_id':mode['family'],'transform':{'rotation_radians':mode['angle'],'mirrored':mode['mirrored'],'translation':mode['source_translation_offset']}};g=source_shape(p);saved=shape(mode['geometry']);assert g.is_valid and g.symmetric_difference(saved).area<1e-8 and abs(g.area-Polygon(parts[mode['family']]['geometry'][0]['outer']).area)<1e-6;part=parts[mode['family']];assert not mode['mirrored'] or part['allow_mirror'];assert part['rotations']['kind']=='free' or any(abs(math.remainder(mode['angle']-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees']);shapes.append(g)
fixed=np.asarray([source_shape(p) for p in inventory['fixed_first_placements']],dtype=object);stock=job['stocks'][0];edge=job['edge_clearance'];m=stock['margins'];bounds=[m['left']+edge,m['bottom']+edge,stock['width']-m['right']-edge,stock['height']-m['top']-edge];freechecks=0;minimum=math.inf;minstock=math.inf
for mi,region in enumerate(objective.free):
    coords=shapely.get_coordinates(region);indices=np.linspace(0,len(coords)-1,min(128,len(coords)),dtype=int);pts=[coords[i].tolist() for i in indices]+[list(region.representative_point().coords)[0]]
    for xy in pts:
        row=next(i for i,item in enumerate(moving) if mi in item['allowed_modes']);part=moving[row];mode=modes[mi];p={'part_id':part['family'],'transform':{'rotation_radians':mode['angle'],'mirrored':mode['mirrored'],'translation':[xy[k]+mode['source_translation_offset'][k] for k in range(2)]}};g=source_shape(p);d=float(np.min(shapely.distance(g,fixed)));b=g.bounds;extra=min(b[0]-bounds[0],b[1]-bounds[1],bounds[2]-b[2],bounds[3]-b[3]);assert d>required and extra>guard,(mi,xy,d,extra);minimum=min(minimum,d);minstock=min(minstock,extra);freechecks+=1
pair_samples=outside_samples=0
for a in range(14):
    for b in range(a,14):
        obstacle=objective.obstacles[a*14+b];box=obstacle.bounds
        for x in np.linspace(box[0]-1,box[2]+1,5):
            for y in np.linspace(box[1]-1,box[3]+1,5):
                point=Point(x,y);pair_samples+=1
                if not obstacle.covers(point):
                    mode=modes[b];p={'part_id':mode['family'],'transform':{'rotation_radians':mode['angle'],'mirrored':mode['mirrored'],'translation':[x+mode['source_translation_offset'][0],y+mode['source_translation_offset'][1]]}};assert shapes[a].distance(source_shape(p))>required;outside_samples+=1
initial=np.asarray([r['initial_anchor'] for r in moving],dtype=float).reshape(-1);initial_modes=[r['initial_mode'] for r in moving];initial_poses=objective.placements(initial,initial_modes);cogs=[source_shape(p) for p in initial_poses if p['part_id']=='cog'];cg_pairs=[]
for i,j in combinations(range(15),2):d=cogs[i].distance(cogs[j]);assert d>required;cg_pairs.append(d)
for g in cogs:assert float(np.min(shapely.distance(g,fixed)))>required;b=g.bounds;assert min(b[0]-bounds[0],b[1]-bounds[1],bounds[2]-b[2],bounds[3]-b[3])>guard
gradients=[]
for variant in range(3):
    x=initial+.037*np.sin(np.arange(48)*1.7+variant*.31);value,analytic,diag=objective.evaluate(x,initial_modes)
    for coordinate in [0,1,4,7,10,15,18,23,30,35,42,47]:
        h=1e-5;plus=x.copy();minus=x.copy();plus[coordinate]+=h;minus[coordinate]-=h;numeric=(objective.evaluate(plus,initial_modes)[0]-objective.evaluate(minus,initial_modes)[0])/(2*h);error=abs(numeric-analytic[coordinate]);tolerance=.003+1e-5*abs(analytic[coordinate]);assert error<tolerance,(variant,coordinate,numeric,analytic[coordinate]);gradients.append({'variant':variant,'coordinate':coordinate,'analytic':float(analytic[coordinate]),'numeric':numeric,'absolute_error':error,'tolerance':tolerance})
value,gradient,diag=objective.evaluate(initial,initial_modes);write(OUT/'gradient-checks.json',gradients);write(OUT/'initial-moving-placements.json',initial_poses);write(OUT/'initial-diagnostics.json',{'value':value,**diag,'all66_layout_valid_claimed':False});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_modes_verified':14,'free_region_source_samples':freechecks,'sampled_fixed_pairs':29*freechecks,'configuration_obstacle_samples':pair_samples,'outside_obstacle_source_samples':outside_samples,'geometry_sampling_is_not_a_continuous_proof':True,'minimum_sampled_fixed_gap_mm':minimum,'minimum_sampled_extra_stock_mm':minstock,'initial_cogs_source_valid':True,'initial_cog_pairs':105,'initial_cog_fixed_pairs':435,'initial_cog_minimum_gap_mm':min(cg_pairs),'numerical_gradient_checks':len(gradients),'maximum_gradient_error':max(r['absolute_error'] for r in gradients),'initial_penalty_mm2':value,'initial_overlap_pairs':diag['overlapping_configuration_pairs'],'all24_movers_mandatory':True,'all66_originals_accounted':True,'optimizer_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
