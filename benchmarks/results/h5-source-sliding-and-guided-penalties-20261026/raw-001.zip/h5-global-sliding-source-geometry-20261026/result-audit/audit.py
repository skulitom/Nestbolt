"""Independent original-ring readback of the closed local result, including all failures."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
from h5_global_sliding_objective import SlidingObjective
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-sliding-source-geometry-20261026';SEARCH=BASE/'search';OUT=BASE/'result-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(SEARCH/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');opened=load(SEARCH/'opened.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<90 and result['closed'] and result['initial_configurations']==1 and result['random_restarts']==0 and opened['maximum_positional_stages']==8;stages=load(SEARCH/'position-stages.json');trials=load(SEARCH/'mode-trials.json');changes=load(SEARCH/'accepted-mode-changes.json');assert len(stages)==result['positional_stages_returned']<=8 and len(trials)==result['mode_trials'] and len(changes)==result['accepted_mode_changes'];assert result['objective_evaluations']==1+len(stages)+len(trials)+sum(r['function_evaluations'] for r in stages);assert all(r['before_value']>r['after_value']+1e-8 for r in changes)
objective=SlidingObjective(BASE);best=load(SEARCH/'best.json');value,gradient,diag=objective.evaluate(best['anchors'],best['modes']);assert abs(value-best['value'])<1e-8 and value==result['best_value'] and diag==best['diagnostics']==result['best_diagnostics'];moving=objective.placements(best['anchors'],best['modes']);assert moving==load(SEARCH/'best-moving-placements.json');inventory=load(BASE/'inventory.json');rows=inventory['fixed_first_placements']+moving+inventory['fixed_short_placements'];job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};items=load(ROOT/'output/h5-source-orientation-construction-20261025/items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};assert Counter(p['part_id'] for p in rows)==Counter({p['id']:p['quantity'] for p in job['parts']}) and sorted(ids[p['part_id'],p['copy_index']] for p in rows)==list(range(66));stocks=[[float(F(*v)) for v in r] for r in load(ROOT/'output/h5-source-orientation-construction-20261025/geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);shapes={};stock=[];holes=vertices=0;invalid_stock=[]
for p in rows:
    original=ids[p['part_id'],p['copy_index']];t=p['transform'];part=parts[p['part_id']];assert not t['mirrored'] or part['allow_mirror'];assert part['rotations']['kind']=='free' or any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees']);c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];g=part['geometry'][0]
    def ring(r):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in r]
    filled=Polygon(ring(g['outer']));full=Polygon(ring(g['outer']),[ring(h) for h in g.get('holes',[])]);assert filled.is_valid and full.is_valid and abs(filled.area-Polygon(g['outer']).area)<1e-6 and abs(full.area-Polygon(g['outer'],g.get('holes',[])).area)<1e-6;sheet=int(p['sheet_id'].split('-')[1]);b=filled.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];entry={'original':original,'extra_mm':extra,'guard_passed':min(extra)>guard};stock.append(entry)
    if not entry['guard_passed']:invalid_stock.append(entry)
    shapes[original]=(sheet,filled);holes+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]))
pairs=[];failures=[]
for i,j in combinations(sorted(shapes),2):
    sa,a=shapes[i];sb,b=shapes[j]
    if sa!=sb:continue
    d=a.distance(b);entry={'originals':[i,j],'distance_mm':d,'intersection_area_mm2':a.intersection(b).area,'guard_passed':a.disjoint(b) and d>required};pairs.append(entry)
    if not entry['guard_passed']:failures.append(entry)
valid=not failures and not invalid_stock;assert holes==90 and vertices==10026 and len(pairs)==1456;write(OUT/'all66-placements.json',rows);write(OUT/'source-pairs.json',pairs);write(OUT/'stock-edges.json',stock);write(OUT/'source-failures.json',{'pair_failures':failures,'stock_failures':invalid_stock,'full_source_valid':valid})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'optimizer_status':result['status'],'closed':True,'shared_process_seconds':process['seconds'],'optimization_seconds':result['search_seconds'],'objective_evaluations':result['objective_evaluations'],'positional_stages':len(stages),'mode_trials':len(trials),'accepted_mode_changes':len(changes),'initial_penalty_mm2':load(BASE/'preflight/checks.json')['initial_penalty_mm2'],'best_penalty_mm2':value,'all66_originals_verified':True,'same_sheet_source_pairs':len(pairs),'stock_edge_checks':4*len(rows),'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'source_pair_failures':len(failures),'source_stock_failures':len(invalid_stock),'actual_source_geometry_valid':valid,'native_call_qualified':valid,'finite_mode_local_search_only':True,'unrestricted_exclusion':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
