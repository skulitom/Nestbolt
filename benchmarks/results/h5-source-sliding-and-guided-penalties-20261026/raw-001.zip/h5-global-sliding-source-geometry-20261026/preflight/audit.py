"""Source reconstruction, fresh stock regions and numerical gradients for all53 movers."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon,Point,shape
from h5_global_sliding_objective import SlidingObjective
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-sliding-source-geometry-20261026';OUT=BASE/'preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
for n,h in load(BASE/'reused-intrinsic-obstacles.json').items():assert digest(ROOT/n)==h and digest(BASE/'obstacles'/Path(n).name)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};obj=SlidingObjective(BASE);inventory=load(BASE/'inventory.json');assert not inventory['fixed_first_placements'] and len(obj.moving)==53 and len(obj.modes)==16;assert Counter(r['family'] for r in obj.moving)=={'frame':18,'bracket':4,'insert':16,'cog':15};assert sorted([r['original'] for r in obj.moving]+inventory['fixed_short_originals'])==list(range(66));required=plan['required_pair_gap_mm'];guard=plan['stock_guard_mm'];stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];bounds=[m['left']+edge,m['bottom']+edge,stock['width']-m['right']-edge,stock['height']-m['top']-edge]
def source(mi,xy):
    mode=obj.modes[mi];c,s=math.cos(mode['angle']),math.sin(mode['angle']);sgn=-1 if mode['mirrored'] else 1;tx,ty=[mode['source_translation_offset'][k]+xy[k] for k in range(2)];return Polygon([(sgn*x*c-y*s+tx,sgn*x*s+y*c+ty) for x,y in parts[mode['family']]['geometry'][0]['outer']])
shapes=[];free_samples=0;minstock=math.inf
for mi,mode in enumerate(obj.modes):
    g=source(mi,[0.,0.]);part=parts[mode['family']];assert g.is_valid and g.symmetric_difference(shape(mode['geometry'])).area<1e-8 and abs(g.area-Polygon(part['geometry'][0]['outer']).area)<1e-6;assert not mode['mirrored'] or part['allow_mirror'];assert part['rotations']['kind']=='free' or any(abs(math.remainder(mode['angle']-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees']);shapes.append(g);region=obj.free[mi];assert region.geom_type=='Polygon' and len(region.interiors)==0 and region.equals(region.envelope)
    for xy in list(region.exterior.coords)+[list(region.representative_point().coords)[0]]:
        b=source(mi,xy).bounds;extra=min(b[0]-bounds[0],b[1]-bounds[1],bounds[2]-b[2],bounds[3]-b[3]);assert extra>guard;minstock=min(minstock,extra);free_samples+=1
samples=outside=0
for i in range(16):
    for j in range(i,16):
        obstacle=obj.obstacles[i*16+j];b=obstacle.bounds
        for x in np.linspace(b[0]-1,b[2]+1,5):
            for y in np.linspace(b[1]-1,b[3]+1,5):
                samples+=1
                if not obstacle.covers(Point(x,y)):assert shapes[i].distance(source(j,[x,y]))>required;outside+=1
initial=np.asarray([r['initial_anchor'] for r in obj.moving],dtype=float).reshape(-1);modes=[r['initial_mode'] for r in obj.moving];actual=obj.placements(initial,modes);seed=load(BASE/'initial-source-placements.json');assert len(actual)==len(seed)==53
for a,b in zip(actual,seed):
    assert all(a[k]==b[k] for k in ['part_id','copy_index','sheet_id']);at,bt=a['transform'],b['transform'];assert at['rotation_radians']==bt['rotation_radians'] and at['mirrored']==bt['mirrored'] and max(abs(at['translation'][k]-bt['translation'][k]) for k in range(2))<1e-9
gradients=[]
for variant in range(3):
    x=initial+.037*np.sin(np.arange(106)*1.7+variant*.31);value,analytic,diag=obj.evaluate(x,modes)
    for coordinate in np.linspace(0,105,20,dtype=int):
        h=1e-5;plus=x.copy();minus=x.copy();plus[coordinate]+=h;minus[coordinate]-=h;numeric=(obj.evaluate(plus,modes)[0]-obj.evaluate(minus,modes)[0])/(2*h);error=abs(numeric-analytic[coordinate]);tolerance=.003+1e-5*abs(analytic[coordinate]);assert error<tolerance,(variant,int(coordinate),numeric,analytic[coordinate]);gradients.append({'variant':variant,'coordinate':int(coordinate),'analytic':float(analytic[coordinate]),'numeric':numeric,'absolute_error':error,'tolerance':tolerance})
value,gradient,diag=obj.evaluate(initial,modes);write(OUT/'gradient-checks.json',gradients);write(OUT/'initial-diagnostics.json',{'value':value,**diag,'source_fit_claimed':False});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_modes_verified':16,'fresh_stock_rectangles_verified':16,'stock_samples':free_samples,'minimum_sampled_extra_stock_mm':minstock,'configuration_obstacle_samples':samples,'outside_obstacle_source_samples':outside,'geometry_sampling_is_not_a_continuous_proof':True,'intrinsic_obstacle_hashes_verified':105,'new_frame_pairs_sampled':31,'initial53_source_poses_preserved':True,'numerical_gradient_checks':len(gradients),'maximum_gradient_error':max(r['absolute_error'] for r in gradients),'initial_penalty_mm2':value,'all53_first_originals_movable':True,'fixed_first_originals':0,'all66_originals_accounted':True,'optimizer_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
