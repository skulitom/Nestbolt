from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-assignment-bridge-probe-20261018'
plan=json.loads((probe/'preparation.json').read_bytes());target=Path(plan['target'])
out=probe/'before-assignment-bridge';out.mkdir()
for rel in plan['changed_files']:
 p=out/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(probe/'candidate'/rel,p)
command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',str(target),'assignment_bridge_new_','--','--nocapture','--test-threads=1']
started=datetime.now(timezone.utc).isoformat()
with (out/'expected-failure.log').open('xb') as f:r=subprocess.run(command,cwd=probe/'candidate',stdout=f,stderr=subprocess.STDOUT,timeout=1800)
s=(out/'expected-failure.log').read_text(encoding='utf-8')
record={'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,
 'log_sha256':sha256((out/'expected-failure.log').read_bytes()).hexdigest(),
 'expected_runtime_failure':r.returncode!=0 and '2 passed; 5 failed' in s and 'Whole window must cross the remaining flat state' in s and 'Actual flat steps must be tried before rollback' in s,
 'new_searches':0}
binaries=list((target/'release/deps').glob('nestbolt_core-*.exe'))
if len(binaries)==1:
 shutil.copyfile(binaries[0],out/'authored-tests.exe');record['binary_sha256']=sha256(binaries[0].read_bytes()).hexdigest()
(out/'checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'check.py');print(json.dumps(record),flush=True);assert record['expected_runtime_failure']
