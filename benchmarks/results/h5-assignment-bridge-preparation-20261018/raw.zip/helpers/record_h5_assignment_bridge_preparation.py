from pathlib import Path
import json, subprocess
root=Path(__file__).resolve().parents[1];out=root/'benchmarks/results/h5-assignment-bridge-preparation-20261018'
assert json.loads((out/'checks.json').read_bytes())['all_functional_checks_pass']
prior=(root/'BENCHMARKS.md').read_bytes();assert prior==subprocess.check_output(['git','show','HEAD:BENCHMARKS.md'],cwd=root)
note='''**N4 provisional assignment qualification, 2026-10-18:** the [isolated candidate](../benchmarks/results/h5-assignment-bridge-preparation-20261018.md)
keeps the original short search, then may cross validated material-flat steps
when last-sheet filled area strictly decreases. Only a final material gain commits
the sequence; incomplete steps roll back with their accepted counters. An actual
old-policy fixture demonstrates two flat steps followed by a valid material gain.
All 156 native tests pass: 148 old bodies, that witness and seven new policy tests.
Five expected old-behavior failures remain. Eight initial and 24 new-output CLI
checks, independent filled geometry, exact old witnesses, public replay, source
reconstruction, lint, build and five harness tests pass. The original four-step
cap, total deadline, validation reserve and geometry guards remain. No quality
comparison has begun, and no production change or H5 credit is claimed.
H2/H5 stay open at 60%.
'''
def append(p,s):
 with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
append(root/'BENCHMARKS.md','\n\n## 2026-10-18 — Provisional assignment qualification\n\n'+note.replace('../benchmarks/','benchmarks/'))
for name in ['docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']:append(root/name,'\n\n'+note)
p=root/'docs/STATUS.md';s=p.read_text(encoding='utf-8');at=s.index('**N4 ')
p.write_text(s[:at]+note+'\n'+s[at:],encoding='utf-8',newline='\n')
append(root/'.gitattributes','\nbenchmarks/results/h5-assignment-bridge-preparation-20261018/** -text -whitespace\nbenchmarks/results/h5-assignment-bridge-pilot-20261018/** -text -whitespace\n')
assert (root/'BENCHMARKS.md').read_bytes().startswith(prior)
print('Recorded assignment-bridge qualification; no new quality claim.')
