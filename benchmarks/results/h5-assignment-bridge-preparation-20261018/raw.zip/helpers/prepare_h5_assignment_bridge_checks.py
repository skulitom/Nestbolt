from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-assignment-bridge-probe-20261018'
for stage in ['public','harness']:
 s=(root/f'output/check_h5_extended_repair_{stage}.py').read_text(encoding='utf-8').replace('h5-extended-repair','h5-assignment-bridge').replace('h5_extended_repair','h5_assignment_bridge')
 (root/f'output/check_h5_assignment_bridge_{stage}.py').write_text(s,encoding='utf-8',newline='\n')
ref=root/'scripts/h5_extended_repair_pilot.py';original=ref.read_text(encoding='utf-8')
s=original.replace('h5-extended-repair-probe','h5-assignment-bridge-probe').replace('h5-extended-repair-preparation','h5-assignment-bridge-preparation')
end=s.index('"""',3)+3;s='''"""Paired development pilot of provisional area-reducing assignment steps.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The isolated candidate retains the short exchange phase. The remaining original
relocation allowance may cross validated material-flat steps only when canonical
last-sheet filled area decreases. Steps stay provisional until strict whole-job
material reduction; incomplete sequences restore their saved layout and counts.
The original four-step cap, deadline, validation reserve and geometry guards
remain. 148 prior tests, one original-policy witness and seven new policy tests
must qualify first. This pilot cannot close H5 or establish a comparative claim.
"""'''+s[end:]
s=s.replace('Isolated extended-source-repair candidate','Isolated assignment-bridge candidate')
old="PROBE/'branch-checks/checks.json', PROBE/'extended-checks/checks.json', PROBE/'repair-checks/checks.json', PROBE/'restored-witnesses.json', PROBE/'reconstruction.json'"
new="PROBE/'bridge-checks/checks.json', PROBE/'initial-geometry/checks.json', PROBE/'reconstruction.json'"
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace("'previous_failed_pilot': 'benchmarks/results/h5-exchange-chain-pilot-20261018/results.json'","'previous_failed_pilot': 'benchmarks/results/h5-extended-repair-pilot-20261018/results.json'")
needle="ROOT/'benchmarks/results/h5-continuous-repair-failure-20261018/checks.json'";assert s.count(needle)==1
s=s.replace(needle,needle+",\n                  ROOT/'benchmarks/results/h5-extended-repair-pilot-20261018/verification.json',\n                  ROOT/'benchmarks/results/h5-extended-repair-pilot-20261018/interpretation.json',\n                  ROOT/'benchmarks/results/h5-extended-repair-pilot-20261018/fixed-inventory-area.json'")
needle='def guards():\n';assert s.count(needle)==1
s=s.replace(needle,needle+'''    previous = ROOT/'benchmarks/results/h5-extended-repair-pilot-20261018'
    assert load(previous/'verification.json')['valid'] == 72
    require_runner_stopped(load(previous/'opened.json'), 'h5_extended_repair_pilot.py')
''')
path=root/'scripts/h5_assignment_bridge_pilot.py';assert not path.exists();compile(s,str(path),'exec');path.write_text(s,encoding='utf-8',newline='\n')
def fn(t,n):return next(x for x in ast.parse(t).body if isinstance(x,ast.FunctionDef) and x.name==n)
names=['blocks','summarize','case','measure','require_runner_stopped','require_measurements_finished']
for n in names:assert ast.dump(fn(s,n))==ast.dump(fn(original,n))
method={'reference':ref.relative_to(root).as_posix(),'reference_sha256':sha256(ref.read_bytes()).hexdigest(),
 'candidate_runner':path.relative_to(root).as_posix(),'runner_sha256':sha256(path.read_bytes()).hexdigest(),
 'identical_function_ASTs':names,'scoring_measurement_and_PID_reuse_guard_unchanged':True,
 'previous_extended_pilot_terminal_check_added_to_guards':True}
(probe/'pilot-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(method))
