"""Add the transactional policy contract with old behavior before implementing it."""
from pathlib import Path
import json, shutil, subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-assignment-bridge-probe-20261018'
assert json.loads((probe/'initial-geometry/checks.json').read_bytes())['all_checks_passed']
rel='crates/core/src/sheets/vstrip/exchange.rs';p=probe/'candidate'/rel;s=p.read_text(encoding='utf-8')
stub='''fn assignment_source_area(_strip: &Strip, _layout: &JLayout, _shape: Shape) -> f64 { 0.0 }

'''
needle='impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search'
assert s.count(needle)==1;s=s.replace(needle,stub+needle)
stub_methods='''    pub(super) fn assignment_bridge_window(
        &mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,short_until:f64,until:f64,
    )->Result<usize> {
        self.directed_exchange_window(strip,frozen,sep,shape,short_until,until)
    }

    fn assignment_bridge_chain(
        &mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,until:f64,accepted:usize,
    )->Result<usize> {
        self.extend_exchange_chain(strip,frozen,sep,shape,until,accepted)
    }

'''
needle='    pub(super) fn directed_exchange_window('
assert s.count(needle)==1;s=s.replace(needle,stub_methods+needle)
a=s.index('    fn extended_exercise(');b=s.index('    // BEGIN extended-repair tests',a)
helper=s[a:b].replace('fn extended_exercise(','fn assignment_bridge_exercise(')
helper=helper.replace('.directed_exchange_window(','.assignment_bridge_window(')
a=helper.index('            1 => usize::from(');b=helper.index('            2 => {',a)
helper=helper[:a]+'''            1 => search.assignment_bridge_chain(&strip,frozen,&mut sep,shape,until,0).unwrap(),
            3 => search.assignment_bridge_chain(&strip,frozen,&mut sep,shape,until,3).unwrap(),
'''+helper[b:]
helper=helper.replace('.extend_exchange_chain(','.assignment_bridge_chain(')
helper=helper.replace('"EXTENDED_REPAIR_WITNESS {}"','"BRIDGE_RESULT_WITNESS {}"')
tests='''
    // BEGIN assignment-bridge new policy tests
    #[test]
    fn assignment_bridge_new_canonical_area_reserves_holes_and_ignores_keys() {
        let (mut job,layout)=assignment_bridge_fixture();
        job.parts[2].geometry[0].holes=vec![vec![[5.0,5.0],[5.0,80.0],[25.0,80.0],[25.0,5.0]]];
        let model=Model::new(&job).unwrap();let clock=Clock::new(Timing::Work,30.0);
        let strip=Strip {model:&model,gap:2.0,clock,containers:Default::default()};
        let sheets=model.sheets_of(&layout).unwrap();let shape=Shape {sheets:4,last:model.full_width};
        let native=strip.layout(&sheets,shape).unwrap();
        let mut reverse=JLayout::new(native.container().clone());
        let items:Vec<_>=native.placed_items().values().collect();
        for item in items.into_iter().rev() {reverse.place_item(item.item(),item.d_transf());}
        assert_eq!(assignment_source_area(&strip,&native,shape),7650.0,"Filled source area must include hole interiors");
        assert_eq!(assignment_source_area(&strip,&native,shape),assignment_source_area(&strip,&reverse,shape));
    }

    #[test]
    fn assignment_bridge_new_window_crosses_flat_steps_and_replays() {
        let (job,layout)=assignment_bridge_fixture();
        let (moved,after,stats)=assignment_bridge_exercise(&job,&layout,0,true,(3.0,12.0,0),0);
        assert_eq!(moved,3,"Whole window must cross the remaining flat state");
        assert_eq!(stats.directed_exchanges,3);assert!(stats.assignment_bridge_flat_steps>0);
        assert_eq!(stats.assignment_bridge_committed,2);assert_eq!(stats.assignment_bridge_rolled_back,0);
        assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area<33000.0);
        let (again,replay,replay_stats)=assignment_bridge_exercise(&job,&layout,0,true,(3.0,12.0,0),0);
        assert_eq!(again,moved);assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(replay).unwrap());
        assert_eq!(serde_json::to_value(stats).unwrap(),serde_json::to_value(replay_stats).unwrap());
    }

    #[test]
    fn assignment_bridge_new_tail_commits_only_after_final_material_gain() {
        let (job,layout)=assignment_bridge_fixture();
        let (moved,after,stats)=assignment_bridge_exercise(&job,&layout,0,true,(0.0,12.0,1),0);
        assert_eq!(moved,3,"Tail must bridge two flat states");
        assert_eq!(stats.assignment_bridge_flat_steps,2);assert_eq!(stats.assignment_bridge_steps,3);
        assert_eq!(stats.assignment_bridge_committed,3);assert_eq!(stats.assignment_bridge_rolled_back,0);
        assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area<33000.0);
    }

    #[test]
    fn assignment_bridge_new_no_final_gain_restores_active_and_frozen_layouts() {
        let (job,layout)=assignment_bridge_fixture();
        let (moved,_,stats)=assignment_bridge_exercise(&job,&layout,0,true,(0.0,12.0,1),1);
        assert_eq!(moved,0);assert_eq!(stats.directed_exchanges,0);
        assert!(stats.assignment_bridge_flat_steps>0,"Actual flat steps must be tried before rollback");
        assert_eq!(stats.assignment_bridge_steps,stats.assignment_bridge_rolled_back);
        assert_eq!(stats.assignment_bridge_committed,0);assert_eq!(stats.assignment_bridge_rollbacks,1);
    }

    #[test]
    fn assignment_bridge_new_disabled_expired_and_fast_expiry_keep_incumbents() {
        let (job,layout)=assignment_bridge_fixture();
        let (_,baseline,_)=assignment_bridge_exercise(&job,&layout,0,false,(0.0,12.0,1),0);
        for (enabled,budget) in [(false,12.0),(true,0.0),(true,1e-12)] {
            let (moved,after,stats)=assignment_bridge_exercise(&job,&layout,0,enabled,(0.0,budget,1),0);
            assert_eq!(moved,0);assert_eq!(stats.assignment_bridge_steps,0);
            assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(&baseline).unwrap());
        }
        let (moved,_,stats)=assignment_bridge_exercise(&job,&layout,0,true,(3.0,12.0,2),0);
        assert_eq!(moved,1);assert_eq!(stats.assignment_bridge_steps,0);
    }

    #[test]
    fn assignment_bridge_new_last_available_slot_cannot_publish_a_flat_step() {
        let (job,layout)=assignment_bridge_fixture();
        let (moved,_,stats)=assignment_bridge_exercise(&job,&layout,0,true,(0.0,12.0,3),0);
        assert_eq!(moved,0);assert_eq!(stats.directed_exchanges,0);
        assert_eq!(stats.assignment_bridge_steps,1,"One remaining slot must admit one provisional flat step");
        assert_eq!(stats.assignment_bridge_flat_steps,1);assert_eq!(stats.assignment_bridge_rolled_back,1);
        assert_eq!(stats.assignment_bridge_committed,0);
    }

    #[test]
    fn assignment_bridge_new_keeps_the_prior_fast_opportunities() {
        for ((job,layout),seed) in [(larger_return_fixture(),3),(mixed_fixture(),0)] {
            let (fast,baseline,_)=chain_exercise(&job,&layout,seed,true,3.0,0);assert!(fast>0);
            let (moved,after,stats)=assignment_bridge_exercise(&job,&layout,seed,true,(3.0,5.0,0),0);
            assert!((fast..=4).contains(&moved));assert_eq!(stats.directed_exchanges,moved as u64);
            assert_eq!(stats.assignment_bridge_committed,(moved-fast) as u64);
            assert_eq!(stats.assignment_bridge_steps,stats.assignment_bridge_committed+stats.assignment_bridge_rolled_back);
            if moved>fast {assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area<validate(&job,&baseline).unwrap().metrics.unwrap().material_area);}
            else {assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(baseline).unwrap());}
        }
    }
    // END assignment-bridge new policy tests
'''
pos=s.rindex('\n}');s=s[:pos]+'\n'+helper+tests+s[pos:];p.write_text(s,encoding='utf-8',newline='\n')
stats=probe/'candidate/crates/core/src/sheets.rs';s=stats.read_text(encoding='utf-8')
needle='    pub extended_flat_rejections: u64,'
extra=''.join('\n    #[serde(skip_serializing_if = "is_zero")]\n    pub '+name+': u64,' for name in ['assignment_bridge_steps','assignment_bridge_flat_steps','assignment_bridge_committed','assignment_bridge_rolled_back','assignment_bridge_area_rejections','assignment_bridge_rollbacks'])
assert s.count(needle)==1;stats.write_text(s.replace(needle,needle+extra),encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=probe/'candidate',check=True)
shutil.copyfile(__file__,probe/'prepare-red.py')
print(json.dumps({'new_policy_tests':7,'total_tests':156,'prior_148_tests_unchanged':True,'search_policy_still_old':True}))
