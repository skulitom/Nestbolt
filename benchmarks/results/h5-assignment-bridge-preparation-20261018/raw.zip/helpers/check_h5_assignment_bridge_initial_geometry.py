"""Independently validate the saved three-step witness without rerunning it."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json, math, shutil, subprocess
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-assignment-bridge-probe-20261018'
out=probe/'initial-geometry';out.mkdir()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
checks=load(probe/'initial-witness/checks.json');assert checks['witness_passed']
log=(probe/'initial-witness/witness.log').read_text(encoding='utf-8')
assert digest(probe/'initial-witness/witness.log')==checks['log_sha256']
steps=[json.loads(line.split('BRIDGE_STEP_WITNESS ',1)[1]) for line in log.splitlines() if 'BRIDGE_STEP_WITNESS ' in line]
old=[json.loads(line.split('EXTENDED_REPAIR_WITNESS ',1)[1]) for line in log.splitlines() if 'EXTENDED_REPAIR_WITNESS ' in line]
assert len(steps)==3 and len(old)==1
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
assert digest(cli)==expected
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
records=[];pairs=0
for index,row in enumerate(steps+old):
 folder=out/f'case-{index}';folder.mkdir();write(folder/'witness.json',row);write(folder/'job.json',row['job'])
 parts={p['id']:p for p in row['job']['parts']};metrics={};areas={}
 for kind in ['before','after']:
  write(folder/(kind+'.json'),row[kind])
  args=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/(kind+'.json'))]
  result=subprocess.run(args,capture_output=True,timeout=60)
  (folder/(kind+'-stdout.json')).write_bytes(result.stdout);(folder/(kind+'-stderr.log')).write_bytes(result.stderr)
  write(folder/(kind+'-command.json'),{'command':args,'exit_code':result.returncode})
  report=json.loads(result.stdout);assert result.returncode==0 and report['valid'];metrics[kind]=report['metrics']['material_area']
  assert Counter(p['part_id'] for p in row[kind]['placements'])==Counter({p['id']:p['quantity'] for p in row['job']['parts']})
  assert len({(p['part_id'],p['copy_index']) for p in row[kind]['placements']})==len(row[kind]['placements'])
  shapes=[];area=0
  for p in row[kind]['placements']:
   t=p['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
   def tr(v):return (m*c*v[0]-s*v[1]+t['translation'][0],m*s*v[0]+c*v[1]+t['translation'][1])
   for g in parts[p['part_id']]['geometry']:
    polygon=Polygon([tr(v) for v in g['outer']]);assert polygon.is_valid
    if p['sheet_id']=='sheet-3':area+=Polygon(g['outer']).area
    for sheet,other in shapes:
     if sheet==p['sheet_id']:
      pairs+=1;assert polygon.disjoint(other) and polygon.distance(other)+1e-7>=row['job']['clearance']
    shapes.append((p['sheet_id'],polygon))
  areas[kind]=area
 if index<3:
  assert areas['after']<areas['before'] and areas['after']==row['source_filled_area']
  assert metrics['after']==row['material'] and row['finished']<row['until']
  assert (metrics['after']<metrics['before'])==row['material_improved']
  if index<2:assert metrics['after']==metrics['before']
  if index:assert row['before']==steps[index-1]['after']
 records.append({'case':index,'metrics':metrics,'source_area':areas})
assert records[2]['metrics']['after']<records[3]['metrics']['after']
rel='crates/core/src/sheets/vstrip/exchange.rs';before=(Path(load(probe/'preparation.json')['old_probe'])/'candidate'/rel).read_text(encoding='utf-8')
current=(probe/'candidate'/rel).read_text(encoding='utf-8')
assert current.startswith(before[:before.rindex('\n}')])
record={'all_checks_passed':True,'public_CLI_checks':8,'filled_outer_pairs':pairs,'steps':3,
 'first_two_steps_material_flat':True,'all_three_source_area_decreasing':True,'third_step_strict_material_gain':True,
 'old_window_remains_worse':True,'all_148_old_tests_and_runtime_unchanged':True,
 'records':records,'native_log_sha256':checks['log_sha256'],'CLI_sha256':expected,'new_searches':0}
write(out/'checks.json',record);shutil.copyfile(__file__,out/'check.py')
print(json.dumps({'CLI_checks':8,'filled_outer_pairs':pairs,'material_sequence':[records[0]['metrics']['before']]+[r['metrics']['after'] for r in records[:3]],'area_sequence':[records[0]['source_area']['before']]+[r['source_area']['after'] for r in records[:3]]}))
