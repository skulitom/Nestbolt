"""Author a flat-to-improving assignment witness before changing search behavior."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, shutil, subprocess, sys
root=Path(__file__).resolve().parents[1]
old=root/'output/h5-extended-repair-probe-20261018'
out=root/'output/h5-assignment-bridge-probe-20261018'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert json.loads((root/'benchmarks/results/h5-extended-repair-pilot-20261018/interpretation.json').read_bytes())['failed_material_pairs']==5
out.mkdir()
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
original=path.read_text(encoding='utf-8');s=original
a=original.index('    fn chain_exercise(');b=original.index('    // BEGIN exchange-chain tests',a)
helper=original[a:b].replace('fn chain_exercise(', 'fn assignment_bridge_manual_exercise(')
helper=helper.replace(') -> (usize, Layout, Stats) {', ') -> (usize, Layout, Stats, Vec<(bool, f64, f64)>) {')
a=helper.index('        let moved = search\n');b=helper.index('        if moved == 0 {',a)
helper=helper[:a]+'''        let source_id=format!("sheet-{}",sheets.len()-1);
        let mut steps=vec![];
        let mut moved=0;
        let mut step_before=before_layout.clone();
        for step in 0..3 {
            let improved=search.directed_exchange_once(&strip,frozen,&mut sep,shape,until)
                .unwrap().expect("Existing per-step rule must admit all three authored exchanges");
            let step_after=search.exchange_layout(&strip,frozen,&sep.layout,shape).unwrap();
            let report=validate(job,&step_after).unwrap();assert!(report.valid);
            let material=report.metrics.unwrap().material_area;
            let area=assignment_bridge_public_area(job,&step_after,&source_id);
            steps.push((improved,material,area));moved+=1;
            eprintln!("BRIDGE_STEP_WITNESS {}",serde_json::json!({"job":job,"seed":seed,
                "step":step,"before":step_before,"after":step_after,"source_sheet":source_id,
                "material_improved":improved,"material":material,"source_filled_area":area,
                "until":until,"finished":search.clock.now(),"stats":search.stats}));
            step_before=step_after;
        }
'''+helper[b:]
helper=helper.replace('"CHAIN_WITNESS {}"','"BRIDGE_MANUAL_WITNESS {}"')
helper=helper.replace('(moved, after, search.stats)','(moved, after, search.stats, steps)')
tests='''
    // BEGIN assignment-bridge witness tests
    fn assignment_bridge_public_area(job:&Job,layout:&Layout,sheet:&str)->f64 {
        layout.placements.iter().filter(|p|p.sheet_id==sheet).map(|p| {
            let part=job.parts.iter().find(|part|part.id==p.part_id).unwrap();
            part.geometry.iter().map(|g|crate::curves::signed_area(&g.outer).abs()).sum::<f64>()
        }).sum()
    }

    fn assignment_bridge_fixture()->(Job,Layout) {
        let (mut job,mut layout)=fixture();
        job.name="Three equal height owners require two material-flat assignments".into();
        for part in &mut job.parts {part.quantity=3;}
        layout.sheets=(0..4).map(|i|Sheet {id:format!("sheet-{i}"),stock_id:"stock".into()}).collect();
        layout.placements.clear();
        for i in 0..3 {
            for (id,translation) in [("filler",[2.0,2.0]),("return",[64.0,2.0])] {
                layout.placements.push(Placement {part_id:id.into(),copy_index:i,sheet_id:format!("sheet-{i}"),
                    transform:RigidTransform {translation,..Default::default()}});
            }
            layout.placements.push(Placement {part_id:"incoming".into(),copy_index:i,sheet_id:"sheet-3".into(),
                transform:RigidTransform {translation:[2.0+32.0*i as f64,2.0],..Default::default()}});
        }
        assert!(validate(&job,&layout).unwrap().valid);
        (job,layout)
    }

    #[test]
    fn assignment_bridge_existing_steps_cross_two_flat_states_before_a_gain() {
        let (job,layout)=assignment_bridge_fixture();
        let original_area=assignment_bridge_public_area(&job,&layout,"sheet-3");
        let (moved,after,stats,steps)=assignment_bridge_manual_exercise(&job,&layout,0,true,12.0,0);
        assert_eq!(moved,3);assert_eq!(stats.directed_exchanges,3);
        assert_eq!(steps.iter().map(|s|s.0).collect::<Vec<_>>(),vec![false,false,true]);
        assert_eq!(steps[0].1,steps[1].1);assert!(steps[2].1<steps[1].1);
        assert!(original_area>steps[0].2 && steps[0].2>steps[1].2 && steps[1].2>steps[2].2);
        let (_,old,old_stats)=extended_exercise(&job,&layout,0,true,(3.0,12.0,0),0);
        assert!(validate(&job,&old).unwrap().metrics.unwrap().material_area>
            validate(&job,&after).unwrap().metrics.unwrap().material_area,
            "The retained short-plus-strict-tail policy must expose the authored bridge gap: {old_stats:?}");
    }
    // END assignment-bridge witness tests
'''
pos=s.rindex('\n}');s=s[:pos]+'\n'+helper+tests+s[pos:]
assert s.split('#[cfg(test)]\nmod tests',1)[0]==original.split('#[cfg(test)]\nmod tests',1)[0]
path.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),
 'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
 'changed_files':[rel,'crates/core/src/sheets/vstrip.rs','crates/core/src/sheets.rs'],'added_files':{},
 'production_digest':source_digest(),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),
 'target':str(root/'output/h5-assignment-bridge-target-20261018'),'unchanged_prior_tests':148,
 'initial_new_tests':1,'runtime_unchanged_for_initial_witness':True,'measured_search_started':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'prepared':True,'prior_tests_unchanged':148,'new_witness_tests':1,'runtime_unchanged':True}))
