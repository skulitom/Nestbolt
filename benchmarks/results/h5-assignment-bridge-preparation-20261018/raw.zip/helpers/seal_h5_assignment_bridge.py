"""Seal the qualified transactional assignment experiment before quality measurement."""
from pathlib import Path
from hashlib import sha256
import json, shutil, sys, zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-assignment-bridge-probe-20261018'
out=root/'benchmarks/results/h5-assignment-bridge-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');source=load(probe/'source-checks.json')
initial=load(probe/'initial-geometry/checks.json');bridge=load(probe/'bridge-checks/checks.json');public=load(probe/'public-checks/checks.json')
assert all(x['all_checks_passed'] for x in [build,source,initial,bridge,public])
assert '156 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert source['all_148_prior_test_bodies_unchanged'] and source['new_tests']==8 and source['unchanged_other_files']==153
assert initial['public_CLI_checks']==8 and initial['filled_outer_pairs']==48
assert bridge['saved_bridge_outcomes']==12 and bridge['public_CLI_checks']==24 and bridge['filled_outer_pairs']==156
assert bridge['actual_partial_expiry_rollback_observed']
assert public['observer_outcomes']==10 and public['CLI_cross_checks']==4
red=load(probe/'before-assignment-bridge/checks.json');assert red['expected_runtime_failure']
for folder,log,record in [('before-assignment-bridge','expected-failure.log',red),('initial-witness','witness.log',load(probe/'initial-witness/checks.json'))]:
 assert digest(probe/folder/log)==record['log_sha256'] and digest(probe/folder/'authored-tests.exe')==record['binary_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
 for row in rows:
  assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
  if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for rel,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/rel)==expected
for name,expected in bridge['prior_independent_checks_reused_only_for_exact_witnesses'].items():assert digest(Path(plan['old_probe'])/name)==expected
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json');assert method['scoring_measurement_and_PID_reuse_guard_unchanged']
assert digest(root/method['reference'])==method['reference_sha256'] and digest(root/method['candidate_runner'])==method['runner_sha256']
counter=load(probe/'counter-audit-method.json')
assert digest(root/counter['parent'])==counter['parent_sha256']
assert digest(root/'output/finish_h5_assignment_bridge_pilot.py')==counter['candidate_finisher_sha256']
bins=list((Path(plan['target'])/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1
shutil.copyfile(bins[0],probe/'bridge-checks/authored-tests.exe')
write(probe/'final-test-binary.json',{'sha256':digest(bins[0]),'core_log_sha256':digest(probe/'core-tests.log'),'source_sha256':build['source_sha256']})
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
helpers=['prepare_h5_assignment_bridge.py','check_h5_assignment_bridge_initial.py','check_h5_assignment_bridge_initial_geometry.py',
 'prepare_h5_assignment_bridge_red.py','check_h5_assignment_bridge_red.py','apply_h5_assignment_bridge.py',
 'build_h5_assignment_bridge.py','check_h5_assignment_bridge_source.py','check_h5_assignment_bridge_witness.py',
 'prepare_h5_assignment_bridge_checks.py','check_h5_assignment_bridge_public.py','check_h5_assignment_bridge_harness.py',
 'prepare_h5_assignment_bridge_finish.py','finish_h5_assignment_bridge_pilot.py','audit_h5_assignment_bridge.py',
 'seal_h5_assignment_bridge.py','record_h5_assignment_bridge_preparation.py']
for name in helpers:files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_assignment_bridge_pilot.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};out.mkdir();archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(inventory)
 for n,row in inventory.items():
  b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_functional_checks_pass':True,'optimized_core_tests_passed':156,'prior_tests_unchanged':148,
 'original_policy_witness_tests':1,'new_policy_tests':7,'expected_five_runtime_failures_preserved':True,
 'strict_lint_passed':True,'observer_build_passed':True,'short_phase_runtime_and_deadline_retained':True,
 'canonical_source_area_reserves_holes_and_ignores_keys':True,'provisional_flat_steps_require_strict_area_descent':True,
 'only_strict_material_descent_commits_sequences':True,'failed_and_expired_partial_sequences_restore_layout_tracker_and_accepted_counts':True,
 'maximum_combined_steps_per_window':4,'whole_search_budget_validation_reserve_and_original_guards_unchanged':True,
 'all_156_formatted_files_reconstruct_exactly':True,'unchanged_other_files':153,
 'initial_witness_CLI_checks':8,'initial_filled_outer_pairs':48,'bridge_outcomes':12,
 'bridge_CLI_checks':24,'bridge_filled_outer_pairs':156,'actual_partial_expiry_rollback_observed':True,
 'prior_independently_checked_native_witnesses_exact':True,'public_observer_outcomes':10,'public_CLI_cross_checks':4,
 'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,'pilot_harness_tests':5,
 'PID_reuse_guard_unchanged':True,'previous_pilot_terminal_guard_added':True,'production_unchanged':True,
 'measurement_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','source-checks.json','reconstruction.json','candidate.patch','pilot-method.json','counter-audit-method.json','final-test-binary.json']:
 shutil.copyfile(probe/name,out/name)
for sub,name in [('before-assignment-bridge','expected-failure'),('initial-witness','initial-witness'),('initial-geometry','initial-geometry'),('bridge-checks','bridge-checks'),('public-checks','public-checks')]:
 shutil.copyfile(probe/sub/'checks.json',out/(name+'.json'))
doc='''# Provisional assignment sequences — preparation, 2026-10-18

The [extended-repair pilot](h5-extended-repair-pilot-20261018.md) still fails five
material pairs. Five of its six large-plate last-sheet assignments exceed the area
available at the conditional target height. Longer repair alone cannot fit those
same inventories into that same target prefix. Other assignments remain possible;
this is not global infeasibility evidence.

A new authored four-sheet fixture demonstrates an actual missing transition.
Three tall source parts share the upper boundary. Three existing exchanges reduce
source filled area from 7,650 to 5,700, 3,750 and 1,800 mm². Material stays at
38,800.001 mm² after the first two steps, then falls to 32,200.0559 mm². The previous
short-plus-strict-tail policy stops before that gain. Eight frozen-CLI checks and
48 independent filled-outer pair checks validate every saved intermediate state
and the previous policy's output. The fixture does not predict real-job quality.

The candidate retains the original short phase. During the remaining existing
relocation allowance, a validated material-flat step may remain provisional only
if the last sheet's canonical filled area strictly decreases. Original part order
and multiplicities make this area independent of placement keys; hole interiors
remain reserved. This ranking prevents revisiting an equal-material, equal-area
state. Area scans and snapshots are charged work. The acceptance deadline is
checked again after scanning. The original four-step cap includes provisional
steps as well as committed steps across both phases.

A sequence commits only when whole-job material strictly decreases. Failure,
expiry or exhaustion of the move cap restores the last committed layout and its
matching tracker. Original accepted counters are restored too; attempts, flat
steps and rollbacks remain visible separately. Existing quantity, orientation,
frozen-sheet, filled-hole, material and geometry checks remain. The whole-search
budget and validation reserve are unchanged.

All 156 optimized native tests pass: 148 prior test bodies unchanged, the original
policy witness and seven new policy tests. Before implementation, the seven new
tests produce five expected runtime failures and two preservation passes; their
source, binary and log remain. Twelve saved new outputs pass 24 frozen-CLI checks
and 156 independent filled-outer pairs. They include committed flat-to-gain
sequences, a real partially completed sequence that expires and rolls back, the
one-slot rollback, repeatability, disabled/expired behavior and prior fast gains.
Every previously independently checked native witness remains byte-equivalent as
JSON; those old checks are reused only for exact matching witnesses.

Strict lint, executable build, ten public outcomes, four CLI comparisons and five
adversarial harness tests pass. Normal results remain exact except wall time;
common replay is exact. All 156 formatted files reconstruct exactly, with 153
unchanged. Reversing the explicit policy adapter restores the original per-step
runtime; the caller changes only its dispatch name. Measurement, scoring, rotating
order and process identity functions remain AST-identical to the preceding pilot.
The guards additionally require that preceding pilot to be terminal.

The next matched four-job, two-kerf, three-seed pilot must commit its plan before
measurement. Each of 72 searches receives 60 seconds on a physical CCD0 core, with
at most eight running together. No quality run has begun. Production and releases
are unchanged. Every original H5 limit and the complete 13-job gate remain.
**H2/H5 are open; completed milestone weight stays 60%.**

[Checks](h5-assignment-bridge-preparation-20261018/checks.json),
[initial sequence](h5-assignment-bridge-preparation-20261018/initial-geometry.json),
[new outputs and exact prior witnesses](h5-assignment-bridge-preparation-20261018/bridge-checks.json),
[reconstruction](h5-assignment-bridge-preparation-20261018/reconstruction.json),
[raw evidence](h5-assignment-bridge-preparation-20261018/raw.zip),
[archive integrity](h5-assignment-bridge-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
print(json.dumps({'all_functional_checks_pass':True,'members':len(inventory),'archive_bytes':archive.stat().st_size,'quality_runs':0}))
