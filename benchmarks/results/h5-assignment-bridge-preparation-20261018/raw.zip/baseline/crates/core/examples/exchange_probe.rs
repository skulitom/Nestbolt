//! Development-only observer of the unchanged public preparation/search API.
//! Counters are written after search; no timed logging or hidden budget changes.
use std::{fs, path::PathBuf};

use anyhow::{Result, ensure};
use nestbolt_core::{
    clock::Timing,
    project::{Library, Request},
    sheets::Options,
};

fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    ensure!(
        args.len() == 7,
        "usage: exchange_probe LIBRARY REQUEST OUT_DIR SECONDS SEED wall|work"
    );
    let library: Library = serde_json::from_slice(&fs::read(&args[1])?)?;
    let request: Request = serde_json::from_slice(&fs::read(&args[2])?)?;
    let out = PathBuf::from(&args[3]);
    ensure!(!out.exists(), "output directory already exists");
    let timing = match args[6].as_str() {
        "wall" => Timing::Wall,
        "work" => Timing::Work,
        _ => anyhow::bail!("timing must be wall or work"),
    };
    let prepared = request.prepare(&library)?;
    let (result, cutting) = prepared.optimize(
        Options {
            seconds: args[4].parse()?,
            seed: args[5].parse()?,
            timing,
            time_limit: (timing == Timing::Work).then_some(30.0),
            ..Default::default()
        },
        |_, _| {},
    )?;
    ensure!(
        result.validation.valid && cutting.validation.valid,
        "invalid diagnostic result"
    );
    fs::create_dir(&out)?;
    fs::write(out.join("search.json"), serde_json::to_vec_pretty(&result)?)?;
    fs::write(
        out.join("layout.json"),
        serde_json::to_vec_pretty(&result.layout)?,
    )?;
    fs::write(
        out.join("job.json"),
        serde_json::to_vec_pretty(&prepared.job)?,
    )?;
    fs::write(
        out.join("cutting-report.json"),
        serde_json::to_vec_pretty(&cutting)?,
    )?;
    Ok(())
}
