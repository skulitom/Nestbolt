"""Keep area-reducing flat steps provisional and publish only strict material gains."""
from pathlib import Path
import json, shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-assignment-bridge-probe-20261018'
assert json.loads((probe/'before-assignment-bridge/checks.json').read_bytes())['expected_runtime_failure']
rel='crates/core/src/sheets/vstrip/exchange.rs';p=probe/'candidate'/rel;s=p.read_text(encoding='utf-8');changes=[]
def replace(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b);changes.append((a,b))
a=s.index('fn assignment_source_area(');b=s.index('impl<F:',a)
replace(s[a:b],'''#[derive(Clone, Copy, PartialEq, Eq)]
enum ExchangePolicy {
    Short,
    Extended,
    AssignmentBridge,
}

// Stable original-part order gives equal inventories exactly equal areas,
// regardless of placement keys, copy order, internal orientation or reflection.
// Hole interiors remain reserved. This is an internal progress measure only.
fn assignment_source_area(strip: &Strip, layout: &JLayout, shape: Shape) -> f64 {
    let mut counts=vec![0_usize;strip.model.job.parts.len()];
    for p in layout.placed_items().values().filter(|p| !strip.is_blocker(p)
        && strip.sheet_of(p.shape())==shape.sheets-1) {
        counts[strip.model.part[p.item().idx()]]+=1;
    }
    strip.clock.charge(Work::RegisteredItem,layout.placed_items().len() as f64);
    let mut area=0.0;
    for (part,count) in strip.model.job.parts.iter().zip(counts) {
        if count==0 {continue;}
        let one=part.geometry.iter().map(|g|crate::curves::signed_area(&g.outer).abs()).sum::<f64>();
        let vertices=part.geometry.iter().map(|g|g.outer.len()).sum::<usize>();
        strip.clock.charge(Work::TrackedVertex,vertices as f64);
        area+=one*count as f64;
    }
    area
}

''')
a=s.index('    pub(super) fn assignment_bridge_window(');b=s.index('    pub(super) fn directed_exchange_window(',a)
replace(s[a:b],'''    pub(super) fn assignment_bridge_window(
        &mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,short_until:f64,until:f64,
    )->Result<usize> {
        let accepted=self.directed_exchange_chain(strip,frozen,sep,shape,short_until)?;
        let extra=self.assignment_bridge_chain(strip,frozen,sep,shape,until,accepted)?;
        Ok(accepted+extra)
    }

    fn assignment_bridge_chain(
        &mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,until:f64,accepted:usize,
    )->Result<usize> {
        if accepted>=4 || !self.allow_exchange || shape.sheets<2
            || self.clock.now()>=self.last_step(until) {return Ok(0);}
        let mut checkpoint=(sep.layout.save(),sep.tracker.clone(),[
            self.stats.directed_exchanges,self.stats.paired_exchanges,
            self.stats.mixed_exchanges,self.stats.extended_exchanges,
        ]);
        self.clock.charge(Work::RegisteredItem,sep.layout.placed_items().len() as f64);
        let mut pending=0_usize;
        let mut committed=0_usize;
        let outcome=(|| -> Result<()> {
            for _ in accepted..4 {
                let Some(improved)=self.directed_exchange_policy(
                    strip,frozen,sep,shape,until,ExchangePolicy::AssignmentBridge,
                )? else {break;};
                pending+=1;
                self.stats.assignment_bridge_steps+=1;
                self.stats.assignment_bridge_flat_steps+=u64::from(!improved);
                if improved {
                    committed+=pending;
                    self.stats.assignment_bridge_committed+=pending as u64;
                    pending=0;
                    checkpoint=(sep.layout.save(),sep.tracker.clone(),[
                        self.stats.directed_exchanges,self.stats.paired_exchanges,
                        self.stats.mixed_exchanges,self.stats.extended_exchanges,
                    ]);
                    self.clock.charge(Work::RegisteredItem,sep.layout.placed_items().len() as f64);
                }
            }
            Ok(())
        })();
        // The snapshot and tracker are kept together: stale placement keys
        // are never transferred to a separately rebuilt/re-keyed layout.
        // Keep attempts and provisional diagnostics, restore only committed
        // acceptance counts along with the last strictly improved incumbent.
        if pending>0 {
            self.stats.assignment_bridge_rolled_back+=pending as u64;
            self.stats.assignment_bridge_rollbacks+=1;
            sep.layout=JLayout::from_snapshot(&checkpoint.0);
            sep.tracker=checkpoint.1;
            self.clock.charge(Work::RegisteredItem,sep.layout.placed_items().len() as f64);
            [self.stats.directed_exchanges,self.stats.paired_exchanges,
                self.stats.mixed_exchanges,self.stats.extended_exchanges]=checkpoint.2;
        }
        outcome?;
        Ok(committed)
    }

    #[cfg(test)]
''')
replace('    fn extend_exchange_chain(', '    #[cfg(test)]\n    fn extend_exchange_chain(')
replace('fn continue_remaining_exchanges(', '#[cfg(test)]\nfn continue_remaining_exchanges(')
needle='''    /// At most one exchange. The original separator is untouched until both'''
wrapper='''    fn directed_exchange_mode(
        &mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,until:f64,extended:bool,
    )->Result<Option<bool>> {
        self.directed_exchange_policy(strip,frozen,sep,shape,until,
            if extended {ExchangePolicy::Extended} else {ExchangePolicy::Short})
    }

'''
replace(needle,wrapper+needle)
a=s.index(needle);b=s.index('\n}\n\n#[cfg(test)]\nmod tests',a)
old=s[a:b];body=old.replace('fn directed_exchange_mode(', 'fn directed_exchange_policy(')
body=body.replace('        extended: bool,','        policy: ExchangePolicy,')
needle='''    ) -> Result<Option<bool>> {
        if !self.allow_exchange'''
assert body.count(needle)==1
body=body.replace(needle,'''    ) -> Result<Option<bool>> {
        let extended=policy!=ExchangePolicy::Short;
        let bridge=policy==ExchangePolicy::AssignmentBridge;
        if !self.allow_exchange''')
needle='        let baseline_profile = std::cell::OnceCell::new();'
assert body.count(needle)==1;body=body.replace(needle,needle+'\n        let baseline_source_area=std::cell::OnceCell::new();')
needle='''                    if extended && after.material_area >= before.material_area {
                        self.stats.extended_flat_rejections += 1;
                        continue;
                    }'''
new='''                    if extended && after.material_area >= before.material_area {
                        let area_improved=if bridge {
                            let initial=*baseline_source_area.get_or_init(||assignment_source_area(strip,&sep.layout,shape));
                            assignment_source_area(strip,&trial,shape)<initial
                        } else {false};
                        if !area_improved {
                            self.stats.extended_flat_rejections += 1;
                            self.stats.assignment_bridge_area_rejections+=u64::from(bridge);
                            continue;
                        }
                    }
                    // Canonical area scans are charged work; they cannot let
                    // a proposal cross the original acceptance deadline.
                    if bridge && self.clock.now()>=exchange_until {continue;}'''
assert body.count(needle)==1;body=body.replace(needle,new)
body=body.replace('''                    // The additional phase must improve on the retained
                    // short-phase incumbent; a flat rearrangement is insufficient.''','''                    // Strict mode rejects flat material. Bridge mode may
                    // retain a validated flat step provisionally only when the
                    // canonical filled area on the last sheet strictly falls.''')
replace(old,body)
p.write_text(s,encoding='utf-8',newline='\n')
caller=probe/'candidate/crates/core/src/sheets/vstrip.rs';c=caller.read_text(encoding='utf-8')
assert c.count('self.directed_exchange_window(')==1
caller.write_text(c.replace('self.directed_exchange_window(','self.assignment_bridge_window('),encoding='utf-8',newline='\n')
(probe/'implementation-substitutions.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,probe/'apply.py')
print(json.dumps({'implemented':True,'provisional_steps_require_strict_source_area_descent':True,
 'only_strict_whole_job_material_improvements_commit':True,'shared_four_step_cap':True,
 'original_short_phase_and_all_148_old_tests_preserved':True,'quality_runs':0}))
