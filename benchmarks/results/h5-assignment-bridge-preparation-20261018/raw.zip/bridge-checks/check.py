"""Validate committed and rolled-back native bridge outputs from the completed test log."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json, math, shutil, subprocess
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-assignment-bridge-probe-20261018'
out=probe/'bridge-checks';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_checks_passed'];out.mkdir()
log=(probe/'core-tests.log').read_text(encoding='utf-8');assert '156 passed; 0 failed' in log
rows=[json.loads(line.split('BRIDGE_RESULT_WITNESS ',1)[1]) for line in log.splitlines() if 'BRIDGE_RESULT_WITNESS ' in line]
assert len(rows)==12
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
records=[];pairs=0
for index,row in enumerate(rows):
 folder=out/f'case-{index}';folder.mkdir();write(folder/'witness.json',row);write(folder/'job.json',row['job'])
 parts={p['id']:p for p in row['job']['parts']};metrics={}
 for kind in ['before','after']:
  write(folder/(kind+'.json'),row[kind])
  args=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/(kind+'.json'))]
  result=subprocess.run(args,capture_output=True,timeout=60)
  (folder/(kind+'-stdout.json')).write_bytes(result.stdout);(folder/(kind+'-stderr.log')).write_bytes(result.stderr)
  write(folder/(kind+'-command.json'),{'command':args,'exit_code':result.returncode})
  report=json.loads(result.stdout);assert result.returncode==0 and report['valid'];metrics[kind]=report['metrics']['material_area']
  assert Counter(p['part_id'] for p in row[kind]['placements'])==Counter({p['id']:p['quantity'] for p in row['job']['parts']})
  assert len({(p['part_id'],p['copy_index']) for p in row[kind]['placements']})==len(row[kind]['placements'])
  shapes=[]
  for p in row[kind]['placements']:
   t=p['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
   def tr(v):return (m*c*v[0]-s*v[1]+t['translation'][0],m*s*v[0]+c*v[1]+t['translation'][1])
   for g in parts[p['part_id']]['geometry']:
    polygon=Polygon([tr(v) for v in g['outer']]);assert polygon.is_valid
    for sheet,other in shapes:
     if sheet==p['sheet_id']:
      pairs+=1;assert polygon.disjoint(other) and polygon.distance(other)+1e-7>=row['job']['clearance']
    shapes.append((p['sheet_id'],polygon))
  if kind=='after':
   # Every sheet before the active window remains fixed in the actual native
   # helper; public comparison is explicit for the frozen rollback outcome.
   if row['mode']==1 and row['stats'].get('assignment_bridge_rollbacks',0)>0:
    assert row['after']==row['before']
 stats=row['stats'];names=['assignment_bridge_steps','assignment_bridge_flat_steps','assignment_bridge_committed','assignment_bridge_rolled_back','assignment_bridge_area_rejections','assignment_bridge_rollbacks']
 counts={n:stats.get(n,0) for n in names};assert all(type(x)is int and x>=0 for x in counts.values())
 total,flat,committed,rolled,rejected,rollbacks=[counts[n] for n in names]
 assert total==committed+rolled and flat<=total<=stats.get('extended_exchange_attempts',0)
 assert committed<=stats.get('extended_exchanges',0)<=stats.get('directed_exchanges',0)
 assert rejected<=stats.get('extended_flat_rejections',0)
 assert row['moved']==stats.get('directed_exchanges',0) and 0<=row['moved']<=4
 assert metrics['after']<=metrics['before']
 if row['moved']==0:assert row['after']==row['before']
 if row['mode'] in [1,3]:
  assert row['moved']==committed
  if committed:assert metrics['after']<metrics['before']
 if row['mode']==2:assert row['after']==row['fast_layout'] and total==committed==rolled==0
 if row['mode']==3:assert total==flat==rolled==1 and committed==0
 records.append({'case':index,'job':row['job']['name'],'mode':row['mode'],'moved':row['moved'],
  'before_material':metrics['before'],'after_material':metrics['after'],'steps':total,'flat_steps':flat,
  'committed':committed,'rolled_back':rolled,'rollbacks':rollbacks,'finished':row['finished'],'until':row['until']})
assert sum(r['flat_steps']>0 and r['committed']>0 for r in records)>=3
assert any(r['rollbacks']>0 and r['mode']==1 for r in records)
expired=any(r['rolled_back']>0 and r['finished']>=r['until'] for r in records)
old=Path(load(probe/'preparation.json')['old_probe']);old_log=(old/'core-tests.log').read_text(encoding='utf-8')
markers=['EXTENDED_REPAIR_WITNESS ','CHAIN_WITNESS ','PROFILE_REJECT_WITNESS ','CONTINUOUS_REPAIR_WITNESS ','LARGER_RETURN_WITNESS ','MIXED_WITNESS ']
retained=[]
for marker in markers:
 def captured(text):return Counter(json.dumps(json.loads(line.split(marker,1)[1]),sort_keys=True) for line in text.splitlines() if marker in line)
 previous=captured(old_log);current=captured(log)
 assert previous and not (previous-current),(marker,'prior saved native output changed')
 retained.append({'marker':marker,'previous_outcomes_retained_exactly':sum(previous.values()),'new_additional_outcomes':sum(current.values())-sum(previous.values())})
references={name:digest(old/name) for name in ['extended-checks/checks.json','branch-checks/checks.json','repair-checks/checks.json','restored-witnesses.json']}
for name in references:assert load(old/name)['all_checks_passed']
record={'all_checks_passed':True,'saved_bridge_outcomes':len(rows),'public_CLI_checks':24,
 'filled_outer_pairs':pairs,'actual_flat_to_strict_gain_observed':True,'actual_rolled_back_flat_steps_observed':True,
 'actual_partial_expiry_rollback_observed':expired,'only_one_available_slot_rolls_back':True,
 'accepted_counts_exclude_rolled_back_steps':True,'prior_witnesses_retained_exactly':retained,
 'prior_independent_checks_reused_only_for_exact_witnesses':references,
 'CLI_sha256':expected,'core_log_sha256':digest(probe/'core-tests.log'),'records':records,'new_searches':0,'quality_claim':False}
write(out/'checks.json',record);shutil.copyfile(__file__,out/'check.py')
print(json.dumps({k:record[k] for k in ['saved_bridge_outcomes','public_CLI_checks','filled_outer_pairs','actual_partial_expiry_rollback_observed']}))
