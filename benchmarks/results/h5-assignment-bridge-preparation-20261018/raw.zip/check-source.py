"""Reconstruct the candidate and verify exact preservation of the prior policy."""
from pathlib import Path
from hashlib import sha256
import difflib, json, re, shutil, subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-assignment-bridge-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(probe/'preparation.json');old=Path(plan['old_probe']);rel='crates/core/src/sheets/vstrip/exchange.rs'
before=(old/'candidate'/rel).read_text(encoding='utf-8');after=(probe/'candidate'/rel).read_text(encoding='utf-8')
marker='#[cfg(test)]\nmod tests'
old_tests=before.split(marker,1)[1];new_tests=after.split(marker,1)[1]
assert new_tests.startswith(old_tests[:old_tests.rindex('\n}')])
assert before.count('#[test]')+8==after.count('#[test]')
def function(text,name):
 match=re.search(r'(?m)^(?:    )?(?:pub\(super\) )?fn '+name+r'\(',text);assert match,name
 start=text.index('{',match.start());depth=0
 for i in range(start,len(text)):
  depth+=(text[i]=='{')-(text[i]=='}')
  if depth==0:return text[match.start():i+1]
 raise AssertionError(name)
runtime_before=before.split(marker,1)[0];runtime_after=after.split(marker,1)[0]
names=re.findall(r'(?m)^(?:    )?(?:pub\(super\) )?fn (\w+)\(',runtime_before)
for name in names:
 if name!='directed_exchange_mode':assert function(runtime_before,name)==function(runtime_after,name),name
original=function(runtime_before,'directed_exchange_mode');adapted=function(runtime_after,'directed_exchange_policy')
adapted=adapted.replace('fn directed_exchange_policy(','fn directed_exchange_mode(').replace('policy: ExchangePolicy,','extended: bool,')
for line in ['        let extended = policy != ExchangePolicy::Short;\n','        let bridge = policy == ExchangePolicy::AssignmentBridge;\n','        let baseline_source_area = std::cell::OnceCell::new();\n']:
 assert adapted.count(line)==1;adapted=adapted.replace(line,'')
a=adapted.index('                    // Strict mode rejects flat material.')
b=adapted.index('                    // Same inventory can still improve',a)
c=original.index('                    // The additional phase must improve')
d=original.index('                    // Same inventory can still improve',c)
adapted=adapted[:a]+original[c:d]+adapted[b:]
assert adapted==original,'Per-step runtime differs outside the reviewed bridge acceptance adapter'
caller='crates/core/src/sheets/vstrip.rs'
assert (probe/'candidate'/caller).read_text(encoding='utf-8').replace('self.assignment_bridge_window(','self.directed_exchange_window(')==(old/'candidate'/caller).read_text(encoding='utf-8')
stats='crates/core/src/sheets.rs';s=(probe/'candidate'/stats).read_text(encoding='utf-8')
fields=['assignment_bridge_steps','assignment_bridge_flat_steps','assignment_bridge_committed','assignment_bridge_rolled_back','assignment_bridge_area_rejections','assignment_bridge_rollbacks']
for name in fields:
 needle='    #[serde(skip_serializing_if = "is_zero")]\n    pub '+name+': u64,\n'
 assert s.count(needle)==1;s=s.replace(needle,'')
assert s==(old/'candidate'/stats).read_text(encoding='utf-8')
rebuild=root/'output/h5-assignment-bridge-reconstruction-20261018';shutil.copytree(probe/'candidate',rebuild)
for name in plan['changed_files']:shutil.copyfile(probe/'before-assignment-bridge'/name,rebuild/name)
s=(rebuild/rel).read_text(encoding='utf-8')
for a,b in load(probe/'implementation-substitutions.json'):
 assert s.count(a)==1;s=s.replace(a,b)
(rebuild/rel).write_text(s,encoding='utf-8',newline='\n')
p=rebuild/caller;s=p.read_text(encoding='utf-8');assert s.count('self.directed_exchange_window(')==1
p.write_text(s.replace('self.directed_exchange_window(','self.assignment_bridge_window('),encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=rebuild,check=True)
files=[p for p in (probe/'candidate').rglob('*') if p.is_file()]
assert len(files)==156
for p in files:assert digest(p)==digest(rebuild/p.relative_to(probe/'candidate'))
unchanged=0
for row in plan['old_source_files']['candidate']:
 if row['path'] not in plan['changed_files']:
  assert digest(probe/'candidate'/row['path'])==row['sha256'];unchanged+=1
record={'all_checks_passed':True,'all_148_prior_test_bodies_unchanged':True,'new_tests':8,
 'prior_runtime_functions_unchanged_except_mode_adapter':len(names)-1,'original_per_step_policy_restores_exactly':True,
 'original_short_window_and_deadline_unchanged':True,'caller_only_dispatch_name_changed':True,
 'normal_mode_has_no_new_runtime_call':True,'six_zero_omitted_diagnostic_fields':True,
 'new_policy_requires_material_descent_or_canonical_source_area_descent':True,
 'only_strict_material_descent_commits_provisional_steps':True,'shared_four_step_cap_retained':True,
 'all_formatted_reconstructed_files_exact':True,'reconstructed_files':len(files),'unchanged_other_files':unchanged,
 'whole_search_budget_validation_reserve_and_original_geometry_guards_preserved':True,'new_searches':0}
for name in ['source-checks.json','reconstruction.json']:(probe/name).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(probe/'candidate.patch').write_text(''.join(''.join(difflib.unified_diff((old/'candidate'/name).read_text(encoding='utf-8').splitlines(True),(probe/'candidate'/name).read_text(encoding='utf-8').splitlines(True),fromfile='extended-repair/'+name,tofile='assignment-bridge/'+name)) for name in plan['changed_files']),encoding='utf-8',newline='\n')
shutil.copyfile(__file__,probe/'check-source.py');print(json.dumps(record))
