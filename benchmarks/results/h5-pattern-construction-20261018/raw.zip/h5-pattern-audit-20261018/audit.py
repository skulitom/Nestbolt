"""Audit every retained cluster and partial placement; no new packing search."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,gzip,importlib.util,itertools,json,math,shutil,subprocess,traceback
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('base',ROOT/'output/construct_h5_pattern_layouts.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
OUT=ROOT/'output/h5-pattern-audit-20261018'
load=base.load;write=base.write;digest=base.digest


def geometry(job,layout):
    parts={p['id']:p for p in job['parts']};stocks={s['id']:s for s in job['stocks']}
    sheets={s['id']:stocks[s['stock_id']] for s in layout['sheets']};groups={}
    assert Counter(p['part_id'] for p in layout['placements'])==Counter({p['id']:p['quantity'] for p in job['parts']})
    assert len({(p['part_id'],p['copy_index']) for p in layout['placements']})==len(layout['placements'])
    for p in layout['placements']:
        part=parts[p['part_id']];t=p['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians'])
        assert not t['mirrored'] or part['allow_mirror']
        if part['rotations']['kind']=='list':
            assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
        coords=[]
        for x,y in part['geometry'][0]['outer']:
            if t['mirrored']:x=-x
            coords.append((c*x-s*y+t['translation'][0],s*x+c*y+t['translation'][1]))
        poly=Polygon(coords);assert poly.is_valid and poly.area>0
        st=sheets[p['sheet_id']];m=st['margins'];e=job['edge_clearance'];a,b,c,d=poly.bounds
        assert not st['outline'] and not st['defects']
        assert a>=m['left']+e-1e-7 and b>=m['bottom']+e-1e-7
        assert c<=st['width']-m['right']-e+1e-7 and d<=st['height']-m['top']-e+1e-7
        groups.setdefault(p['sheet_id'],[]).append(poly)
    pairs=0;minimum=None
    for geoms in groups.values():
        for a,b in itertools.combinations(geoms,2):
            pairs+=1;assert a.disjoint(b);slack=a.distance(b)-job['clearance']
            assert slack>=-1e-7
            minimum=slack if minimum is None else min(minimum,slack)
    return {'pairs':pairs,'minimum_clearance_slack_mm':minimum}


def component(job,p):
    job=copy.deepcopy(job);counts=Counter(m['part_id'] for m in p['members'])
    job['parts']=[x for x in job['parts'] if counts[x['id']]]
    for x in job['parts']:x['quantity']=counts[x['id']]
    st=job['stocks'][0];e=job['edge_clearance'];m=st['margins']
    # Component geometry only; this enlarged stock is never a whole-job result.
    st['width']=max(st['width'],p['width']+m['left']+m['right']+2*e+1.)
    st['height']=max(st['height'],p['height']+m['top']+m['bottom']+2*e+1.)
    counts=Counter();placements=[]
    for q in p['members']:
        t=copy.deepcopy(q['transform']);t['translation'][0]+=m['left']+e+.01;t['translation'][1]+=m['bottom']+e+.01
        placements.append({'part_id':q['part_id'],'copy_index':counts[q['part_id']],'sheet_id':'sheet-0','transform':t});counts[q['part_id']]+=1
    layout={'version':1,'units':job['units'],'sheets':[{'id':'sheet-0','stock_id':st['id']}],'placements':placements}
    return job,layout


def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');cache={};records=[];partial=[]
    cli=base.gap.CLI;assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    source_rows={Path(r['archive']).stem:r for r in load(base.PRIOR/'results.json')['records'] if r['arm']=='candidate' and r['seed']==0 and r['job'].startswith('m-mechanical')}
    try:
        for phase in ['h5-pattern-construction-20261018','h5-mixed-pattern-catalog-20261018','h5-radial-angle-diagnosis-20261018']:
            assert load(ROOT/'output'/phase/'results.json')['complete']
            for folder in sorted((ROOT/'output'/phase).glob('m-*')):
                source=ROOT/'output/h5-pattern-construction-20261018'/folder.name
                job=load(source/'job.json');raw=load(folder/'patterns.json')
                patterns=raw if isinstance(raw,list) else list(raw.values())
                for index,p in enumerate(patterns):
                    component_job,layout=component(job,p)
                    key=sha256(json.dumps([component_job,layout],sort_keys=True).encode()).hexdigest()
                    if key not in cache:
                        target=OUT/f'case-{len(cache):04d}';target.mkdir();write(target/'job.json',component_job);write(target/'layout.json',layout)
                        command=[str(cli),'validate','--job',str(target/'job.json'),'--layout',str(target/'layout.json')]
                        r=subprocess.run(command,capture_output=True,timeout=60)
                        (target/'stdout.json').write_bytes(r.stdout);(target/'stderr.log').write_bytes(r.stderr)
                        write(target/'command.json',{'command':command,'exit_code':r.returncode})
                        report=json.loads(r.stdout);assert r.returncode==0 and report['valid']
                        cache[key]={'folder':target.name,**geometry(component_job,layout),'job_sha256':digest(target/'job.json'),'layout_sha256':digest(target/'layout.json')}
                    records.append({'phase':phase,'case':folder.name,'pattern':p['id'] or index,'geometry_hash':key})
                if phase=='h5-mixed-pattern-catalog-20261018':
                    result=load(folder/'result.json');counts=Counter();area=0.;meta=load(folder/'metadata.json');g=meta['block_spacing']
                    for name,n in result['selected'].items():
                        for m in raw[name]['members']:counts[m['part_id']]+=n
                        area+=n*(raw[name]['width']+g)*(raw[name]['height']+g)
                    assert counts==Counter({p['id']:p['quantity'] for p in job['parts']})
                    assert abs(area-result['padded_area'])<=1e-6 and result['optimal_in_this_finite_catalog']
        for folder in sorted((ROOT/'output/h5-mixed-pattern-placement-20261018').glob('m-*')):
            original_job=load(folder/'job.json');patterns=load(folder/'patterns.json');frames=load(folder/'frames.json');target=load(folder/'conditional-target.json');count=0
            with gzip.open(folder/'attempts.jsonl.gz','rt',encoding='utf-8') as f:
                for line in f:
                    row=json.loads(line);count+=1;assert row['attempt']==count and row['left']
                    layout=base.layout_of(original_job,patterns,frames[row['frame_config']]['placed']+row['placed'])
                    qty=Counter(p['part_id'] for p in layout['placements']);missing=Counter(m['part_id'] for n in row['left'] for m in patterns[n]['members'])
                    assert qty+missing==Counter({p['id']:p['quantity'] for p in original_job['parts']})
                    job=copy.deepcopy(original_job);job['parts']=[p for p in job['parts'] if qty[p['id']]]
                    for p in job['parts']:p['quantity']=qty[p['id']]
                    audit=geometry(job,layout)
                    # Check actual part tops against the smaller second-sheet target.
                    parts={p['id']:p for p in job['parts']};st=job['stocks'][0]
                    for p in layout['placements']:
                        if p['sheet_id']!='sheet-1':continue
                        top=base.gap.pose(Polygon(parts[p['part_id']]['geometry'][0]['outer']),p['transform']).bounds[3]
                        assert top+st['margins']['top']+job['edge_clearance']<=target['required_used_height_mm']+1e-7
                    partial.append({'case':folder.name,'attempt':count,'placed':len(layout['placements']),'missing':sum(missing.values()),**audit})
            assert count==load(folder/'result.json')['attempts']==300
        for name,row in source_rows.items():
            assert digest(base.PRIOR/row['archive'])==row['archive_sha256']
            assert digest(ROOT/'output/h5-pattern-construction-20261018'/name/'original.json')==row['layout_sha256']
        assert base.gap.source_digest()=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
        result={'all_checks_passed':True,'unique_component_CLI_checks':len(cache),'pattern_references':len(records),
            'component_pairs':sum(v['pairs'] for v in cache.values()),'partial_placement_attempts':len(partial),
            'partial_placement_pairs':sum(v['pairs'] for v in partial),'component_stock_may_be_enlarged':True,
            'component_quantities_are_pattern_members_only':True,'component_checks_are_not_whole_job_or_stock_feasibility':True,
            'all_original_shapes_orientations_clearance_and_hole_reservations_preserved':True,
            'unchanged_sources_and_production':True,'absolute_clearance_tolerance_mm':1e-7,
            'new_solver_searches':0,'H5_complete':False,'components':cache,'references':records,'partial':partial}
        write(OUT/'checks.json',result)
        print(json.dumps({k:result[k] for k in ['all_checks_passed','unique_component_CLI_checks','pattern_references','component_pairs','partial_placement_attempts','partial_placement_pairs']}),flush=True)
    except BaseException:
        write(OUT/'failure.json',{'error':traceback.format_exc(),'completed_components':len(cache),'completed_partial':len(partial)});raise


if __name__=='__main__':main()
