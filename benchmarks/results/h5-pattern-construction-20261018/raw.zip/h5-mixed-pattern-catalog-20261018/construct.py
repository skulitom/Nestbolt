"""Refine the retained rectangular-pattern diagnosis with mixed clusters."""
from pathlib import Path
import importlib.util,itertools,math,json,copy,sys,traceback,shutil
import numpy as np
from shapely.geometry import Polygon,LineString
from shapely.affinity import affine_transform
from shapely.ops import unary_union
from scipy.optimize import milp,Bounds,LinearConstraint
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('base',ROOT/'output/construct_h5_pattern_layouts.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
gap=base.gap
OUT=ROOT/'output/h5-mixed-pattern-catalog-20261018'
write=base.write


def boundary_points(geom):
    if geom.is_empty:return []
    if geom.geom_type=='Point':return [(geom.x,geom.y)]
    if geom.geom_type in ['LineString','LinearRing']:return list(geom.coords)
    if hasattr(geom,'geoms'):return [p for g in geom.geoms for p in boundary_points(g)]
    raise AssertionError(geom.geom_type)


def expand(existing,family,parts,shapes,g):
    fixed=[gap.pose(shapes[m['part_id']],m['transform']) for m in existing['members']]
    best=[];seen=set();W,H=existing['width'],existing['height']
    for t in gap.orientations(parts[family],base.transform()):
        moving=gap.pose(shapes[family],t)
        forbidden=unary_union([gap.obstacle(f,moving,g) for f in fixed])
        xmin,ymin,xmax,ymax=moving.bounds
        boundary=forbidden.boundary
        pts=boundary_points(boundary)
        # A bounding-box minimum can occur inside an obstacle edge where an
        # extremum changes owner; obstacle vertices alone miss such contacts.
        reach=10*max(W,H,xmax-xmin,ymax-ymin)
        for x in [-xmin,W-xmax]:pts+=boundary_points(boundary.intersection(LineString([(x,-reach),(x,reach)])))
        for y in [-ymin,H-ymax]:pts+=boundary_points(boundary.intersection(LineString([(-reach,y),(reach,y)])))
        for x,y in pts:
            placed=affine_transform(moving,[1,0,0,1,x,y])
            if any(not placed.disjoint(f) or placed.distance(f)<g-1e-8 for f in fixed):continue
            members=existing['members']+[base.member(family,{**t,'translation':[x,y]})]
            p=base.pattern('',members,shapes)
            key=(round(p['width'],6),round(p['height'],6),tuple((m['part_id'],round(m['transform']['rotation_radians'],9),m['transform']['mirrored'],tuple(round(v,6) for v in m['transform']['translation'])) for m in p['members']))
            if key in seen:continue
            seen.add(key);best.append(p)
    assert best
    best.sort(key=lambda p:(p['width']*p['height'],max(p['width'],p['height']),p['height']))
    # Keep a small diverse beam: same inventory, materially distinct aspect ratio.
    chosen=[];aspects=set()
    for p in best:
        aspect=round(min(p['width'],p['height'])/max(p['width'],p['height']),2)
        if aspect in aspects:continue
        aspects.add(aspect);chosen.append(p)
        if len(chosen)==3:break
    return chosen


def generate(job):
    parts,shapes,patterns,meta=base.catalog(job)
    families=[meta[x] for x in ['corner','radial','small']]
    pools={tuple(1 if f==a else 0 for f in families):[patterns[a]] for a in families}
    catalog={k:v for k,v in patterns.items() if k in parts}
    g=meta['block_spacing'];counts_by_depth={}
    for size in [2,3,4]:
        candidates={}
        for inventory,old in list(pools.items()):
            if sum(inventory)!=size-1:continue
            for f in families:
                new=tuple(n+int(k==f) for n,k in zip(inventory,families))
                # Limit each cluster to two radial parts; large identical grids
                # were already tested in the first retained diagnosis.
                if new[1]>2:continue
                for p in old:
                    candidates.setdefault(new,[]).extend(expand(p,f,parts,shapes,g))
        for inv,ps in candidates.items():
            ps.sort(key=lambda p:(p['width']*p['height'],max(p['width'],p['height']),p['height']))
            beam=[];aspects=set()
            for p in ps:
                aspect=round(min(p['width'],p['height'])/max(p['width'],p['height']),2)
                if aspect in aspects:continue
                aspects.add(aspect);beam.append(p)
                if len(beam)==3:break
            pools[inv]=beam
            for i,p in enumerate(beam):
                p['id']='mix-'+'-'.join(map(str,inv))+f'-{i}';catalog[p['id']]=p
        counts_by_depth[str(size)]={'inventories':len(candidates),'patterns':sum(len(pools[k]) for k in candidates)}
        print(json.dumps({'depth':size,**counts_by_depth[str(size)]}),flush=True)
    checks=0
    for p in catalog.values():
        geoms=[gap.pose(shapes[m['part_id']],m['transform']) for m in p['members']]
        for a,b in itertools.combinations(geoms,2):
            checks+=1;assert a.disjoint(b) and a.distance(b)>=job['clearance']
    names=list(catalog);matrix=np.array([[sum(m['part_id']==f for m in catalog[n]['members']) for n in names] for f in parts],dtype=float)
    costs=np.array([(catalog[n]['width']+g)*(catalog[n]['height']+g) for n in names])
    quantities=np.array([p['quantity'] for p in parts.values()],dtype=float)
    result=milp(c=costs,integrality=np.ones(len(names)),bounds=Bounds(0,np.inf),
        constraints=LinearConstraint(matrix,quantities,quantities),options={'time_limit':60,'mip_rel_gap':0})
    assert result.x is not None,result.message
    selected=np.rint(result.x).astype(int);assert np.allclose(selected,result.x,atol=1e-6) and np.array_equal(matrix@selected,quantities)
    selection={name:int(n) for name,n in zip(names,selected) if n}
    return catalog,meta,{'selected':selection,'padded_area':float(costs@selected),'status':int(result.status),'message':result.message,
        'optimal_in_this_finite_catalog':bool(result.success and result.status==0),'counts_by_depth':counts_by_depth,
        'compound_pair_checks':checks,'family_order':list(parts),'mixed_family_order':families}


def main():
    OUT.mkdir();source=base.digest(Path(__file__));production=gap.source_digest()
    data=base.load(base.PRIOR/'results.json');rows=[r for r in data['records'] if r['arm']=='candidate' and r['seed']==0 and r['job'].startswith('m-mechanical')]
    plan={'script_sha256':source,'base_sha256':base.digest(Path(base.__file__)),'production_digest':production,
        'method':'Generate mixed patterns with two, three and four parts, with at most two radial parts. Add each allowed part orientation to each prior beam pattern at exact filled-outer Minkowski boundary vertices and at intersections where bounding-box extrema change owner. Keep up to three aspect-ratio-diverse smallest rectangle patterns per inventory. Independently check every compound pair. Solve finite integer pattern coverage minimizing padded rectangle area; this is only a rectangle-budget necessary condition for this restricted pattern packing, never a global lower bound or quality claim. Preserve the earlier simple-pattern failure and original jobs.',
        'new_solver_searches':0,'posthoc_diagnosis':True,'milp_time_limit_seconds':60,'cases':[r['archive'] for r in rows]}
    write(OUT/'plan.json',plan);shutil.copyfile(__file__,OUT/'construct.py');shutil.copyfile(base.__file__,OUT/'base.py')
    results=[]
    try:
        for row in rows:
            folder=OUT/Path(row['archive']).stem;folder.mkdir()
            src=ROOT/'output/h5-pattern-construction-20261018'/folder.name
            for name in ['job.json','library.json','request.json','original.json','conditional-target.json']:
                shutil.copyfile(src/name,folder/name)
            job=base.load(folder/'job.json');patterns,meta,result=generate(job)
            write(folder/'patterns.json',patterns);write(folder/'metadata.json',meta)
            b=base.load(folder/'conditional-target.json');st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];g=meta['block_spacing']
            width=st['width']-m['left']-m['right']-2*e-2e-4
            heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,b['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
            result.update(case=folder.name,available_padded_rectangle_area=(width+g)*sum(h+g for h in heights),target_material=b['target_material_mm2'])
            result['area_possible']=result['padded_area']<=result['available_padded_rectangle_area']
            write(folder/'result.json',result);results.append(result)
            print(json.dumps({k:v for k,v in result.items() if k not in ['selected','counts_by_depth']}),flush=True)
        assert gap.source_digest()==production
        write(OUT/'results.json',{'complete':True,'cases':results,'production_unchanged':True,'H5_complete':False,'new_solver_searches':0})
    except BaseException:
        write(OUT/'failure.json',{'error':traceback.format_exc(),'completed':results});raise


if __name__=='__main__':main()
