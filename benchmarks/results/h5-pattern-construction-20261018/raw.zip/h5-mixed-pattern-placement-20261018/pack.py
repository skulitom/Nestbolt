from pathlib import Path
import importlib.util,json,gzip,itertools,shutil,traceback
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('base',ROOT/'output/construct_h5_pattern_layouts.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
OUT=ROOT/'output/h5-mixed-pattern-placement-20261018'
PRIOR=ROOT/'output/h5-mixed-pattern-catalog-20261018'
load=base.load;write=base.write


def main():
    OUT.mkdir();data=load(PRIOR/'results.json');assert data['complete']
    write(OUT/'plan.json',{'source_results_sha256':base.digest(PRIOR/'results.json'),'script_sha256':base.digest(Path(__file__)),
        'method':'For each saved mixed catalog whose selected padded rectangle areas fit the two usable target beds, try that exact inventory with all previously specified largest-rectangle column configurations, four sort orders and three fit scores. Retain every attempted macro placement. Validate any complete layout through the original library/request and independently filled outer geometry. No solver or quality rerun.'})
    shutil.copyfile(__file__,OUT/'pack.py');results=[]
    try:
        for result in data['cases']:
            if not result['area_possible']:continue
            src=PRIOR/result['case'];folder=OUT/result['case'];folder.mkdir()
            for name in ['job.json','library.json','request.json','original.json','conditional-target.json','patterns.json','metadata.json']:
                shutil.copyfile(src/name,folder/name)
            job=load(folder/'job.json');original=load(folder/'original.json');patterns=load(folder/'patterns.json');meta=load(folder/'metadata.json')
            st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];g=meta['block_spacing'];b=load(folder/'conditional-target.json')
            width=st['width']-m['left']-m['right']-2*e-2e-4
            heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,b['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
            qty=next(p['quantity'] for p in job['parts'] if p['id']==meta['large'])
            assert result['selected'][meta['large']]==qty
            frames=base.frame_configs(patterns[meta['large']],qty,width,heights[0],g)
            write(folder/'frames.json',frames)
            items=[name for name,n in result['selected'].items() if name!=meta['large'] for _ in range(n)]
            attempts=0;success=None;best=None;best_area=None
            with gzip.open(folder/'attempts.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
                for fi,f in enumerate(frames):
                    for sort,fit in itertools.product(['area','long','short','filled'],['short','area','bottom']):
                        placed,left=base.pack(items,patterns,[f['free'],[(0,0,width+g,heights[1]+g)]],sort,fit,g)
                        attempts+=1;row={'attempt':attempts,'frame_config':fi,'sort':sort,'fit':fit,'placed':placed,'left':left}
                        log.write(json.dumps(row,separators=(',',':'))+'\n')
                        area=sum(patterns[k]['area'] for k in left)
                        if best_area is None or area<best_area:best_area=area;best=row
                        if not left:
                            layout=base.layout_of(job,patterns,f['placed']+placed)
                            checked=base.gap.validate(folder,'constructed',layout,job,original,{(p['part_id'],p['copy_index']) for p in original['placements']})
                            assert checked['metrics']['material_area']<=b['target_material_mm2']+1e-6
                            success={'attempt':row,'checked':checked};write(folder/'success.json',success);break
                    if success:break
            write(folder/'best-attempt.json',best)
            report={'case':result['case'],'attempts':attempts,'frame_configs':len(frames),'complete_layout_found':success is not None,
                    'best_unplaced_filled_area_mm2':best_area,'original_selected_inventory_preserved':True}
            write(folder/'result.json',report);results.append(report);print(json.dumps(report),flush=True)
        write(OUT/'results.json',{'complete':True,'cases':results,'new_solver_searches':0,'H5_complete':False})
    except BaseException:
        write(OUT/'failure.json',{'error':traceback.format_exc(),'completed':results});raise


if __name__=='__main__':main()
