"""Diagnose finite free-angle pair patterns without rerunning a solver."""
from pathlib import Path
import importlib.util,json,math,copy,shutil,traceback
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('mix',ROOT/'output/construct_h5_mixed_patterns.py')
mix=importlib.util.module_from_spec(spec);spec.loader.exec_module(mix)
base=mix.base;gap=base.gap
OUT=ROOT/'output/h5-radial-angle-diagnosis-20261018'
original=gap.orientations


def rotations(part,old):
    if part['rotations']['kind']=='free':
        for a in range(0,360,15):yield base.transform(angle=math.radians(a))
    else:yield from original(part,old)


def main():
    OUT.mkdir();gap.orientations=rotations
    base.write(OUT/'plan.json',{'method':'For each of the four saved development jobs, construct pairs of the original free-rotation radial part at 15-degree increments, using exact filled-outer forbidden geometry and bounding-extrema contact points. Retain the three aspect-ratio-diverse smallest enclosing rectangles. Compare their geometry with the saved quarter-turn pair; this is a finite offline construction, not runtime quality or gate evidence.',
        'script_sha256':base.digest(Path(__file__)),'catalog_builder_sha256':base.digest(Path(mix.__file__))})
    shutil.copyfile(__file__,OUT/'check.py');results=[]
    try:
        for src in sorted((ROOT/'output/h5-mixed-pattern-catalog-20261018').glob('m-*')):
            job=base.load(src/'job.json');parts={p['id']:p for p in job['parts']};meta=base.load(src/'metadata.json')
            shapes={p['id']:mix.Polygon(p['geometry'][0]['outer']) for p in job['parts']};family=meta['radial']
            assert parts[family]['rotations']['kind']=='free'
            start=base.pattern(family,[base.member(family)],shapes)
            candidates=mix.expand(start,family,parts,shapes,meta['block_spacing'])
            folder=OUT/src.name;folder.mkdir();base.write(folder/'patterns.json',candidates)
            prior=base.load(src/'patterns.json')['mix-0-2-0-0'];best=candidates[0]
            checks=[]
            for p in candidates:
                a,b=[gap.pose(shapes[m['part_id']],m['transform']) for m in p['members']]
                assert a.disjoint(b) and a.distance(b)>=job['clearance']
                checks.append({'distance':a.distance(b),'rotation':p['members'][1]['transform']['rotation_radians'],
                    'width':p['width'],'height':p['height']})
            record={'case':src.name,'before_area':prior['width']*prior['height'],'after_area':best['width']*best['height'],
                'relative_rectangle_reduction':1-best['width']*best['height']/(prior['width']*prior['height']),'checks':checks}
            base.write(folder/'result.json',record);results.append(record);print(json.dumps(record),flush=True)
        base.write(OUT/'results.json',{'complete':True,'cases':results,'new_solver_searches':0,'H5_complete':False})
    except BaseException:
        base.write(OUT/'failure.json',{'error':traceback.format_exc(),'completed':results});raise


if __name__=='__main__':main()
