"""Try independently checked free-angle pairs in whole-job rectangle packing."""
from pathlib import Path
import copy,gzip,importlib.util,itertools,json,math,shutil,traceback
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('base',ROOT/'output/construct_h5_pattern_layouts.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
OUT=ROOT/'output/h5-angle-pattern-placement-20261018'
PRIOR=ROOT/'output/h5-mixed-pattern-catalog-20261018'
load=base.load;write=base.write


def pack(items,patterns,free,sort,fit,g,global_fit):
    score=lambda p:({'area':p['width']*p['height'],'long':max(p['width'],p['height']),
                     'short':min(p['width'],p['height']),'filled':p['area']}[sort],p['width']*p['height'],p['id'])
    ordered=sorted(items,key=lambda n:score(patterns[n]),reverse=True)
    free=[list(f) for f in free];placed=[]
    for index,name in enumerate(ordered):
        p=patterns[name];best=None
        for b,rects in enumerate(free):
            for x,y,w,h in rects:
                for rot in [False,True]:
                    pw,ph=(p['height']+g,p['width']+g) if rot else (p['width']+g,p['height']+g)
                    if pw>w+1e-8 or ph>h+1e-8:continue
                    dw,dh=w-pw,h-ph
                    criterion={'short':(min(dw,dh),max(dw,dh)), 'area':(w*h-pw*ph,min(dw,dh)), 'bottom':(y+ph,x)}[fit]
                    rank=(*criterion,b,y,x,rot) if global_fit else (b,*criterion,y,x,rot)
                    if best is None or rank<best[0]:best=(rank,{'pattern':name,'bin':b,'x':x,'y':y,'rotated':rot,'rect':[x,y,pw,ph]})
        if best is None:return placed,ordered[index:]
        q=best[1];placed.append(q);free[q['bin']]=base.subtract(free[q['bin']],q['rect'])
    return placed,[]


def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'pack.py')
    write(OUT/'plan.json',{'script_sha256':base.digest(Path(__file__)),
        'method':'Add the three independently checked 15-degree radial-pair patterns to each retained mixed catalog. Re-solve the finite integer coverage model at the same original quantities and padded-area objective. For area-eligible inventories, first try all original largest-rectangle columns; then try all rectangles unpinned using the same four sort orders and three fit scores, with both first-sheet preference and global fit preference. Preserve every attempt. No original result or catalog is replaced. A complete construction must pass the original public library/request and filled-outer audit before any feasibility claim.',
        'original_margins_clearance_orientations_and_material_targets_unchanged':True,'new_Nestbolt_searches':0})
    results=[]
    try:
        for prior in load(PRIOR/'results.json')['cases']:
            src=PRIOR/prior['case'];folder=OUT/prior['case'];folder.mkdir()
            for name in ['job.json','library.json','request.json','original.json','conditional-target.json','metadata.json']:
                shutil.copyfile(src/name,folder/name)
            job=load(folder/'job.json');original=load(folder/'original.json');patterns=load(src/'patterns.json');meta=load(folder/'metadata.json')
            radial=load(ROOT/'output/h5-radial-angle-diagnosis-20261018'/folder.name/'patterns.json')
            for i,p in enumerate(radial):p['id']=f'angle-pair-{i}';patterns[p['id']]=p
            write(folder/'patterns.json',patterns)
            g=meta['block_spacing'];names=list(patterns);families=[p['id'] for p in job['parts']]
            matrix=np.array([[sum(m['part_id']==f for m in patterns[n]['members']) for n in names] for f in families],float)
            qty=np.array([p['quantity'] for p in job['parts']],float)
            costs=np.array([(patterns[n]['width']+g)*(patterns[n]['height']+g) for n in names])
            opt=milp(c=costs,integrality=np.ones(len(names)),bounds=Bounds(0,np.inf),constraints=LinearConstraint(matrix,qty,qty),options={'time_limit':60,'mip_rel_gap':0})
            assert opt.status==0 and opt.x is not None
            x=np.rint(opt.x).astype(int);assert np.allclose(x,opt.x,atol=1e-6) and np.array_equal(matrix@x,qty)
            selected={k:int(n) for k,n in zip(names,x) if n};area=float(costs@x)
            st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];b=load(folder/'conditional-target.json')
            width=st['width']-m['left']-m['right']-2*e-2e-4
            heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,b['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
            available=(width+g)*sum(h+g for h in heights);possible=area<=available
            write(folder/'selection.json',{'selected':selected,'padded_area':area,'available_area':available,'area_possible':possible,'finite_catalog_optimal':True})
            attempts=0;success=None;best=None;best_area=None
            if possible:
                count=selected[meta['large']]
                frames=base.frame_configs(patterns[meta['large']],count,width,heights[0],g)
                write(folder/'frames.json',frames)
                rest=[k for k,n in selected.items() if k!=meta['large'] for _ in range(n)]
                all_items=[k for k,n in selected.items() for _ in range(n)]
                configs=[{'frame':i,'fixed':f['placed'],'free':[f['free'],[(0,0,width+g,heights[1]+g)]],'items':rest,'global_fit':False} for i,f in enumerate(frames)]
                configs += [{'frame':None,'fixed':[],'free':[[(0,0,width+g,h+g)] for h in heights],'items':all_items,'global_fit':v} for v in [False,True]]
                with gzip.open(folder/'attempts.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
                    for config in configs:
                        for sort,fit in itertools.product(['area','long','short','filled'],['short','area','bottom']):
                            placed,left=pack(config['items'],patterns,config['free'],sort,fit,g,config['global_fit'])
                            attempts+=1;row={'attempt':attempts,'frame_config':config['frame'],'global_fit':config['global_fit'],'sort':sort,'fit':fit,'placed':config['fixed']+placed,'left':left}
                            log.write(json.dumps(row,separators=(',',':'))+'\n')
                            missing=sum(patterns[k]['area'] for k in left)
                            if best_area is None or missing<best_area:best_area=missing;best=row
                            if not left:
                                layout=base.layout_of(job,patterns,row['placed'])
                                checked=base.gap.validate(folder,'constructed',layout,job,original,{(p['part_id'],p['copy_index']) for p in original['placements']})
                                assert checked['metrics']['material_area']<=b['target_material_mm2']+1e-6
                                success={'attempt':row,'checked':checked};write(folder/'success.json',success);break
                        if success:break
                write(folder/'best-attempt.json',best)
            record={'case':folder.name,'area_possible':possible,'padded_area':area,'available_area':available,
                'attempts':attempts,'complete_layout_found':success is not None,'best_unplaced_filled_area_mm2':best_area}
            write(folder/'result.json',record);results.append(record);print(json.dumps(record),flush=True)
        write(OUT/'results.json',{'complete':True,'cases':results,'new_Nestbolt_searches':0,'H5_complete':False})
    except BaseException:
        write(OUT/'failure.json',{'error':traceback.format_exc(),'completed':results});raise


if __name__=='__main__':main()
