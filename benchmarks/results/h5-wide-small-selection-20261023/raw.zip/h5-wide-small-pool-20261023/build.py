"""Individual small-part choices for the wider frame group, including translated compounds."""
from collections import Counter,deque
from fractions import Fraction as F
from datetime import datetime,timezone
from itertools import combinations,product
import copy,math,shutil,time,traceback
import shapely
from shapely.geometry import mapping,box
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_cog_insert_contacts import graph
from build_h5_group_choice import ROOT,SRC,load,write,digest
WIDE=ROOT/'output/h5-wide-frame-group-20261023';CAT=ROOT/'output/h5-cog-lattices-20261018'
OUT=ROOT/'output/h5-wide-small-pool-20261023'
def rotated_member(member,turn,height,anchor):
    t=copy.deepcopy(member['transform']);x,y=t['translation']
    if turn:t['rotation_radians']+=math.pi/2;x,y=height-y,x
    t['translation']=[x+anchor[0],y+anchor[1]]
    return {'part_id':member['part_id'],'transform':t}
def main():
    OUT.mkdir();(OUT/'regions').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    inputs=[SRC/n for n in ['candidates.json','job.json','conditional-target.json']]+[WIDE/n for n in ['frame-group.json','optional-insert-strip.json','checks.json']]
    inputs += [CAT/n for n in ['all-patterns.json','generation.json','frames.json','audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
      'generation_seconds':120,'new_pose_caps':{'bracket':2000,'cog':3000,'insert':2000},'compression_seconds':20,'solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,
      'method':'Fix the verified18-frame wide group, retain every old bracket/cog/insert pose compatible with it, and add11 optional side-strip inserts. Add original-outline free-region representative points, vertices and edge midpoints for all discrete bracket orientations/mirroring, two rectangle size classes and four cog phases. Add individual member poses from translated/quarter-turned saved compound patterns at corners, center and bottom-left tilings of the top/side/last-sheet rectangles. The individual model may combine members from different groups. Recompute all conflicts and independently audit before solving.',
      'catalogue':'All saved non-frame patterns outside the b-prefixed cog lattice catalogue, plus the seven sizes from each of the three previously ranked best cog lattice variants. Original geometry checks cover every used compound pair.',
      'ordering':'Add optional insert strip first. Then cycle between free-region proposal lists and compound-placement member lists in recorded order, respecting family caps and120 seconds. Retain rejected, duplicate and pending events. Greedy feasible hints will use a separately declared finite enumeration; no full witness is assumed.',
      'construction_padding_mm':0.0126,'acceptance':'Original clearance, quantities, stock, target and filled outer geometry unchanged. New positive padding is construction-only; native margins and full H5 gates remain unproved.',
      'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();source=load(SRC/'candidates.json');pool=copy.deepcopy(source);job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    stock=job['stocks'][0];target=load(SRC/'conditional-target.json');m=stock['margins'];edge=job['edge_clearance'];pad=.0126
    fixed=[]
    for p in load(WIDE/'frame-group.json'):
        p=copy.deepcopy(p);p.pop('copy_index');i=len(pool);pool.append({'index':i,'placement':p,'source':{'kind':'wide-frame'},'filled_area_mm2':157500.});fixed.append(i)
    geometry={i:shape(parts[p['placement']['part_id']],p['placement']['transform']) for i,p in enumerate(pool)}
    # Area is a necessary relaxation, not a certificate that all small families coexist.
    usable_width=F(stock['width'])-F(m['left'])-F(m['right'])-2*F(edge)
    usable_heights=[F(h)-F(m['bottom'])-F(m['top'])-2*F(edge) for h in [stock['height'],target['required_used_height_mm']]]
    free_area=usable_width*sum(usable_heights)-18*F(157500)
    required=sum(F(shape(p,{'rotation_radians':0,'translation':[0,0],'mirrored':False}).area)*p['quantity'] for f,p in parts.items() if f!='frame')
    assert free_area>required
    prior_frames=load(CAT/'frames.json');matches=[{'index':i,'rotations':r['rotations'],'counts':r['counts'],'method':r['method']} for i,r in enumerate(prior_frames) if r['rotations']==[False]*3 and r['counts']==[6]*3]
    assert len(matches)==1
    write(OUT/'preflight.json',{'free_area_upper_bound_mm2':float(free_area),'required_small_filled_area_mm2':float(required),'area_check_inconclusive':True,
      'prior_balanced_orientation_pattern':matches,'historical_method':'The20261018 study tried this orientation/count pattern using padded compound bounding rectangles. The present exact coordinates differ, and this is a new individual-pose conflict model, not a rerun of that heuristic.',
      'native_margin_qualified':False})
    here={s:[i for i in fixed if pool[i]['placement']['sheet_id']==s] for s in ['sheet-0','sheet-1']}
    filters=[];eligible=[]
    for i,p in enumerate(source):
        if p['placement']['part_id']=='frame':continue
        blockers=[j for j in here[p['placement']['sheet_id']] if geometry[i].distance(geometry[j])<job['clearance']-1e-7]
        filters.append({'candidate':i,'fixed_blockers':blockers})
        if not blockers:eligible.append(i)
    gap.EPS=pad;queries=[]
    orientations=[('bracket',a,mirror) for mirror in [False,True] for a in [0,90,180,270]]+[('cog',a,False) for a in [0,4.5,9,13.5]]+[('insert',a,False) for a in [0,90]]
    planned=[{'sheet':s,'family':f,'degrees':a,'mirrored':mir} for s in ['sheet-0','sheet-1'] for f,a,mir in orientations]
    for item in planned:
        if time.perf_counter()-start>=120:break
        this=copy.deepcopy(stock)
        if item['sheet']=='sheet-1':this['height']=target['required_used_height_mm']
        angle=math.radians(item['degrees']);t={'rotation_radians':angle,'translation':[0,0],'mirrored':item['mirrored']}
        region=gap.regions(shape(parts[item['family']],t),[geometry[j] for j in here[item['sheet']]],this,edge,job['clearance'])
        q={'index':len(queries),**item,'rotation_radians':angle,'region':mapping(region),'proposals':proposals(region)}
        write(OUT/'regions'/f"query-{q['index']}.json",q);queries.append(q)
    patterns=load(CAT/'all-patterns.json');best=load(CAT/'generation.json')['best']
    names=sorted({n for n,p in patterns.items() if n!='frame' and not n.startswith('b')}|{'bracket'}|{n for r in best for n in r['patterns']})
    assert all(all(v['part_id']!='frame' for v in patterns[n]['members']) for n in names)
    pattern_checks=[]
    for name in names:
        p=patterns[name];gs=[shape(parts[v['part_id']],v['transform']) for v in p['members']];minimum=math.inf
        for a,b in combinations(gs,2):
            d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=job['clearance']-1e-7
        assert abs(min(g.bounds[0] for g in gs))<1e-7 and abs(min(g.bounds[1] for g in gs))<1e-7
        assert abs(max(g.bounds[2] for g in gs)-p['width'])<1e-7 and abs(max(g.bounds[3] for g in gs)-p['height'])<1e-7
        pattern_checks.append({'pattern':name,'members':len(gs),'pairs':len(gs)*(len(gs)-1)//2,'minimum_distance_mm':minimum if len(gs)>1 else None})
    write(OUT/'pattern-checks.json',pattern_checks)
    left,bottom=m['left']+edge+pad,m['bottom']+edge+pad;right=stock['width']-m['right']-edge-pad
    frame_right=max(geometry[i].bounds[2] for i in fixed);frame_top=max(geometry[i].bounds[3] for i in fixed)
    zones=[{'id':'top','sheet':'sheet-0','bounds':[left,frame_top+job['clearance']+pad,right,stock['height']-m['top']-edge-pad]},
      {'id':'side','sheet':'sheet-0','bounds':[frame_right+job['clearance']+pad,bottom,right,frame_top]},
      {'id':'last','sheet':'sheet-1','bounds':[left,bottom,right,target['required_used_height_mm']-m['top']-edge-pad]}]
    compound=[]
    for name in names:
        p=patterns[name]
        for zone,turn in product(zones,[False,True]):
            a,b,c,d=zone['bounds'];w,h=(p['height'],p['width']) if turn else (p['width'],p['height'])
            if w>c-a or h>d-b:continue
            anchors=[(a,b),(c-w,b),(a,d-h),(c-w,d-h),((a+c-w)/2,(b+d-h)/2)]
            nx,ny=math.floor((c-a+.225)/(w+.225)),math.floor((d-b+.225)/(h+.225))
            anchors.extend((a+x*(w+.225),b+y*(h+.225)) for y in range(ny) for x in range(nx))
            for anchor in dict.fromkeys(anchors):compound.append({'index':len(compound),'pattern':name,'zone':zone['id'],'sheet':zone['sheet'],'turn':turn,'anchor':list(anchor)})
    write(OUT/'zones.json',zones);write(OUT/'compound-placements.json',compound)
    keys={identity(p['placement']):i for i,p in enumerate(pool)};assert len(keys)==len(pool);events=[];added=[];counts=Counter();caps=load(OUT/'plan.json')['new_pose_caps'];strip=[]
    def consider(p,origin):
        g=shape(parts[p['part_id']],p['transform']);a,b,c,d=g.bounds;height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>height-m['top']-edge+1e-7
        blockers=[j for j in here[p['sheet_id']] if g.distance(geometry[j])<job['clearance']-1e-7];event={'origin':origin}
        if outside or blockers:event.update(added=False,reason='geometry',outside=bool(outside),blockers=blockers)
        elif identity(p) in keys:event.update(added=False,reason='duplicate',candidate=keys[identity(p)])
        else:
            i=len(pool);pool.append({'index':i,'placement':p,'source':{'kind':'wide-small',**origin},'filled_area_mm2':g.area});geometry[i]=g;keys[identity(p)]=i;added.append(i);counts[p['part_id']]+=1;event.update(added=True,candidate=i)
        events.append(event);return event
    for j,p in enumerate(load(WIDE/'optional-insert-strip.json')):
        p=copy.deepcopy(p);p.pop('copy_index');e=consider(p,{'kind':'side-strip','index':j});assert 'candidate' in e;strip.append(e['candidate'])
    lists=[]
    for q in queries:
        lists.append([{'part_id':q['family'],'sheet_id':q['sheet'],'transform':{'rotation_radians':q['rotation_radians'],'translation':v['point'],'mirrored':q['mirrored']},
          'origin':{'kind':'region','query':q['index'],'proposal':j}} for j,v in enumerate(q['proposals'])])
    for case in compound:
        p=patterns[case['pattern']];items=[]
        for j,v in enumerate(p['members']):items.append({**rotated_member(v,case['turn'],p['height'],case['anchor']),'sheet_id':case['sheet'],'origin':{'kind':'compound','case':case['index'],'member':j}})
        lists.append(items)
    queue=deque((j,0) for j,v in enumerate(lists) if v);deferred=[]
    while queue and time.perf_counter()-start<120:
        j,k=queue.popleft();item=copy.deepcopy(lists[j][k]);f=item['part_id']
        if counts[f]>=caps[f]:deferred.append([j,k]);continue
        origin=item.pop('origin');consider(item,origin)
        if k+1<len(lists[j]):queue.append((j,k+1))
    elapsed=time.perf_counter()-start;ids=sorted(eligible+added)
    write(OUT/'candidates.json',pool);write(OUT/'old-filter.json',filters);write(OUT/'source-events.json',events)
    write(OUT/'pending.json',{'unbuilt_queries':planned[len(queries):],'proposal_lists':sorted(deferred+list(map(list,queue)))})
    write(OUT/'mapping.json',{'candidates':ids,'fixed_candidates':fixed,'old_eligible':eligible,'new_candidates':added,'optional_insert_strip':strip,'source_pool_size':len(source)})
    r={'generation_seconds':elapsed,'queries':len(queries),'compound_placements':len(compound),'compound_patterns':len(names),'old_eligible':len(eligible),'new_candidates':dict(counts),
      'retained_candidates':len(ids),'events':len(events),'pending_lists':len(deferred)+len(queue),'pending_queries':len(planned)-len(queries),'generation_limit_reached':elapsed>=120,
      **graph(OUT,ids,pool,geometry,job['clearance'])}
    write(OUT/'result.json',r);print(r,flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
