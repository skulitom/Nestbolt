"""Certify safe same-family substitutions, then enumerate a finite set of feasible hints."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from fractions import Fraction
from itertools import permutations
import gzip,json,shutil,time
from hashlib import sha256
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-wide-small-pool-20261023';OUT=BASE/'reduced'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def bits(mask):
    while mask:b=mask&-mask;yield b.bit_length()-1;mask^=b
def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'reduce.py')
    inputs=[BASE/n for n in ['candidates.json','mapping.json','cliques.jsonl.gz','audit/checks.json']]
    inputs += [ROOT/'output/h5-group-choice-20261023/mapping.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
      'maximum_reduction_seconds':30,'maximum_comparisons':10000000,
      'reduction':'Order by full original graph degree and global candidate id. Remove a pose only for an earlier retained adjacent pose of the same family whose other original neighbors are a subset. This preserves all original family counts and filled area in every feasible selection. Endpoints of every substitution remain retained. Check each certificate independently by enumerating the replacement neighbors. If a bound is reached, retain all remaining poses. Project the already audited complete cliques; no expired compression is resumed.',
      'hint_enumeration':'Exactly40 greedy scans: all six family orders with bottom-left, top-left or degree order; plus global descending area and exact degree/area order; each with either no forced choices or the safely mapped11 optional side-strip inserts. Follow original family caps, skip every conflicting pose, audit every resulting set. Retain all outcomes and choose highest exact integer area, then count, then deterministic list. These are starting hints, not quality runs or original-job acceptance.',
      'solver_calls':0,'native_packing_calls':0,'quality_runs':0})
    pool=load(BASE/'candidates.json');mapping=load(BASE/'mapping.json');ids=mapping['candidates'];local={i:j for j,i in enumerate(ids)}
    adjacency=[0]*len(ids);cliques=[]
    with gzip.open(BASE/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);cliques.append(row);mask=sum(1<<i for i in row)
            for i in row:adjacency[i]|=mask^(1<<i)
    assert sum(a.bit_count() for a in adjacency)//2==load(BASE/'audit/checks.json')['conflicts']
    families=[pool[i]['placement']['part_id'] for i in ids];order=sorted(range(len(ids)),key=lambda j:(adjacency[j].bit_count(),ids[j]))
    kept=[];byfamily={f:[] for f in set(families)};removed=[];comparisons=0;beg=time.perf_counter();bounded=False
    for at,b in enumerate(order):
        replacement=None
        if time.perf_counter()-beg>=30 or comparisons>=10000000:
            kept+=order[at:];bounded=True;break
        for a in byfamily[families[b]]:
            comparisons+=1
            if (adjacency[b]>>a)&1 and not(adjacency[a]&~(adjacency[b]|(1<<b))):replacement=a;break
            if comparisons>=10000000:break
        if replacement is None:kept.append(b);byfamily[families[b]].append(b)
        else:removed.append({'removed':ids[b],'replacement':ids[replacement]})
    seconds=time.perf_counter()-beg;kept=sorted(kept);kept_global=[ids[i] for i in kept];kept_set=set(kept)
    replacement={row['removed']:row['replacement'] for row in removed}
    assert set(kept_global).isdisjoint(replacement) and set(kept_global)|replacement.keys()==set(ids)
    certificate_neighbors=0
    for row in removed:
        b,a=local[row['removed']],local[row['replacement']]
        assert a in kept_set and families[a]==families[b] and ((adjacency[b]>>a)&1)
        for neighbor in bits(adjacency[a]):
            certificate_neighbors+=1
            if neighbor!=b:assert (adjacency[b]>>neighbor)&1
    remap={old:new for new,old in enumerate(kept)};projected=sorted({tuple(sorted(remap[j] for j in c if j in kept_set)) for c in cliques})
    projected=[r for r in projected if len(r)>1];covered=[0]*len(kept)
    for row in projected:
        mask=sum(1<<j for j in row)
        for j in row:covered[j]|=mask^(1<<j)
    expected=[sum(1<<remap[j] for j in bits(adjacency[i]) if j in kept_set) for i in kept];assert covered==expected
    with gzip.open(OUT/'cliques.jsonl.gz','xt',encoding='utf-8',newline='\n') as f:
        for row in projected:f.write(json.dumps(row)+'\n')
    write(OUT/'substitutions.json',removed)
    weights=load(ROOT/'output/h5-group-choice-20261023/mapping.json')['area_weights'];caps={'bracket':12,'cog':15,'insert':21}
    poses=[pool[i]['placement'] for i in kept_global];family=[p['part_id'] for p in poses];local2={i:j for j,i in enumerate(kept_global)}
    strip=[local2[replacement.get(i,i)] for i in mapping['optional_insert_strip']]
    assert len(strip)==len(set(strip))==11
    def coordinate_key(j,kind):
        p=poses[j];x,y=p['transform']['translation'];sheet=p['sheet_id']
        return (covered[j].bit_count(),sheet,y,x,kept_global[j]) if kind=='degree' else (sheet,-y if kind=='top-left' else y,x,kept_global[j])
    orders=[]
    for families_order in permutations(caps):
        rank={f:i for i,f in enumerate(families_order)}
        for kind in ['bottom-left','top-left','degree']:
            orders.append(({'families':list(families_order),'kind':kind},sorted(range(len(kept)),key=lambda j:(rank[family[j]],coordinate_key(j,kind)))))
    orders.append(({'kind':'area'},sorted(range(len(kept)),key=lambda j:(-weights[family[j]],covered[j].bit_count(),kept_global[j]))))
    orders.append(({'kind':'degree-per-area'},sorted(range(len(kept)),key=lambda j:(Fraction(covered[j].bit_count(),weights[family[j]]),kept_global[j]))))
    hints=[]
    for force_strip in [False,True]:
        for description,order in orders:
            chosen=strip.copy() if force_strip else [];counts=Counter(family[j] for j in chosen);mask=sum(1<<j for j in chosen)
            assert all(not(covered[j]&mask) for j in chosen)
            for j in order:
                if (mask>>j)&1 or counts[family[j]]>=caps[family[j]] or covered[j]&mask:continue
                chosen.append(j);mask|=1<<j;counts[family[j]]+=1
            assert all(not(covered[j]&mask) for j in chosen) and all(counts[f]<=caps[f] for f in caps)
            global_ids=sorted(kept_global[j] for j in chosen);score=sum(weights[family[j]] for j in chosen)
            hints.append({'index':len(hints),'ordering':description,'forced_strip':force_strip,'selected_small_candidates':global_ids,'counts':dict(counts),'objective':score})
    assert len(hints)==40;best=max(hints,key=lambda r:(r['objective'],len(r['selected_small_candidates']),r['selected_small_candidates']))
    write(OUT/'hints.json',hints);write(OUT/'best-hint.json',best)
    write(OUT/'mapping.json',{'candidates':kept_global,'fixed_candidates':mapping['fixed_candidates'],'seed_candidates':best['selected_small_candidates'],'area_weights':weights})
    check={'passed':True,'reduction_seconds':seconds,'limit_reached':bounded,'comparisons':comparisons,'original_candidates':len(ids),'kept_candidates':len(kept),'removed_candidates':len(removed),
      'substitution_neighbors_independently_verified':certificate_neighbors,'all_substitutions_preserve_family_counts_and_area':True,'projected_cliques':len(projected),
      'all_projected_conflicts_covered':True,'all_forty_greedy_hints_verified':True,'best_hint':{k:v for k,v in best.items() if k!='selected_small_candidates'},
      'full_inventory_hint':best['counts']==caps,'original_CLI_acceptance_pending':True,'native_margin_qualified':False}
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
