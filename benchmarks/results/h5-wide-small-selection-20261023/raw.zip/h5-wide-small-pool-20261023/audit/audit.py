"""Verify every retained pose, construction event and geometric conflict independently."""
from collections import Counter,deque
from itertools import combinations,product
from fractions import Fraction as F
import copy,gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import shape as read_geometry
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_wide_small_pool import ROOT,SRC,WIDE,CAT,OUT,load,write,digest
def main():
    dst=OUT/'audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');start=time.perf_counter();plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    source=load(SRC/'candidates.json');pool=load(OUT/'candidates.json');mp=load(OUT/'mapping.json');result=load(OUT/'result.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    assert pool[:len(source)]==source and mp['source_pool_size']==len(source)
    expected=[]
    for p in load(WIDE/'frame-group.json'):
        p=copy.deepcopy(p);p.pop('copy_index');expected.append(p)
    fixed=mp['fixed_candidates'];assert fixed==list(range(len(source),len(source)+18)) and [pool[i]['placement'] for i in fixed]==expected
    geometry={i:shape(parts[p['placement']['part_id']],p['placement']['transform']) for i,p in enumerate(pool)}
    stock=job['stocks'][0];target=load(SRC/'conditional-target.json');m=stock['margins'];edge=job['edge_clearance']
    here={s:[i for i in fixed if pool[i]['placement']['sheet_id']==s] for s in ['sheet-0','sheet-1']}
    small=[i for i,p in enumerate(source) if p['placement']['part_id']!='frame'];filters=load(OUT/'old-filter.json');assert len(filters)==len(small);eligible=[];oldpairs=0
    for i,row in zip(small,filters):
        blockers=[]
        for j in here[pool[i]['placement']['sheet_id']]:
            oldpairs+=1
            if geometry[i].distance(geometry[j])<job['clearance']-1e-7:blockers.append(j)
        assert row=={'candidate':i,'fixed_blockers':blockers}
        if not blockers:eligible.append(i)
    assert eligible==mp['old_eligible']
    queries=[load(OUT/'regions'/f'query-{i}.json') for i in range(result['queries'])];lists=[]
    orientations=[('bracket',a,mir) for mir in [False,True] for a in [0,90,180,270]]+[('cog',a,False) for a in [0,4.5,9,13.5]]+[('insert',a,False) for a in [0,90]]
    planned=[{'sheet':s,'family':f,'degrees':a,'mirrored':mir} for s in ['sheet-0','sheet-1'] for f,a,mir in orientations]
    for q in queries:
        assert {k:q[k] for k in ['sheet','family','degrees','mirrored']}==planned[q['index']] and q['rotation_radians']==math.radians(q['degrees'])
        assert q['proposals']==proposals(read_geometry(q['region']))
        lists.append([({'part_id':q['family'],'sheet_id':q['sheet'],'transform':{'rotation_radians':q['rotation_radians'],'translation':r['point'],'mirrored':q['mirrored']}},
          {'kind':'region','query':q['index'],'proposal':j}) for j,r in enumerate(q['proposals'])])
    patterns=load(CAT/'all-patterns.json');names=sorted({n for n in patterns if n!='frame' and not n.startswith('b')}|{'bracket'}|{n for r in load(CAT/'generation.json')['best'] for n in r['patterns']})
    checks=load(OUT/'pattern-checks.json');assert [r['pattern'] for r in checks]==names;patternpairs=0
    for record in checks:
        p=patterns[record['pattern']];gs=[shape(parts[v['part_id']],v['transform']) for v in p['members']];minimum=math.inf
        for a,b in combinations(gs,2):
            patternpairs+=1;distance=a.distance(b);minimum=min(minimum,distance);assert a.disjoint(b) and distance>=job['clearance']-1e-7
        assert record['members']==len(gs) and record['pairs']==len(gs)*(len(gs)-1)//2
        assert record['minimum_distance_mm']==(minimum if len(gs)>1 else None)
        assert abs(min(g.bounds[0] for g in gs))<1e-7 and abs(min(g.bounds[1] for g in gs))<1e-7
        assert abs(max(g.bounds[2] for g in gs)-p['width'])<1e-7 and abs(max(g.bounds[3] for g in gs)-p['height'])<1e-7
    zones=load(OUT/'zones.json');pad=plan['construction_padding_mm'];right=stock['width']-m['right']-edge-pad;left=m['left']+edge+pad;bottom=m['bottom']+edge+pad
    fr=max(geometry[i].bounds[2] for i in fixed);ft=max(geometry[i].bounds[3] for i in fixed)
    assert zones==[{'id':'top','sheet':'sheet-0','bounds':[left,ft+job['clearance']+pad,right,stock['height']-m['top']-edge-pad]},
      {'id':'side','sheet':'sheet-0','bounds':[fr+job['clearance']+pad,bottom,right,ft]},
      {'id':'last','sheet':'sheet-1','bounds':[left,bottom,right,target['required_used_height_mm']-m['top']-edge-pad]}]
    compounds=[]
    for name in names:
        p=patterns[name]
        for zone,turn in product(zones,[False,True]):
            a,b,c,d=zone['bounds'];w,h=(p['height'],p['width']) if turn else (p['width'],p['height'])
            if w>c-a or h>d-b:continue
            anchors=[(a,b),(c-w,b),(a,d-h),(c-w,d-h),((a+c-w)/2,(b+d-h)/2)]
            nx,ny=math.floor((c-a+.225)/(w+.225)),math.floor((d-b+.225)/(h+.225))
            anchors.extend((a+x*(w+.225),b+y*(h+.225)) for y in range(ny) for x in range(nx))
            for anchor in dict.fromkeys(anchors):compounds.append({'index':len(compounds),'pattern':name,'zone':zone['id'],'sheet':zone['sheet'],'turn':turn,'anchor':list(anchor)})
    assert compounds==load(OUT/'compound-placements.json')
    for case in compounds:
        p=patterns[case['pattern']];items=[]
        for j,v in enumerate(p['members']):
            t=copy.deepcopy(v['transform']);x,y=t['translation']
            if case['turn']:t['rotation_radians']+=math.pi/2;x,y=p['height']-y,x
            t['translation']=[x+case['anchor'][0],y+case['anchor'][1]]
            items.append(({'part_id':v['part_id'],'sheet_id':case['sheet'],'transform':t},{'kind':'compound','case':case['index'],'member':j}))
        lists.append(items)
    events=load(OUT/'source-events.json');strip=load(WIDE/'optional-insert-strip.json');keys={identity(p['placement']):i for i,p in enumerate(pool[:len(source)+18])}
    queue=deque((i,0) for i,v in enumerate(lists) if v);counts=Counter();added=[];deferred=[];proposalpairs=rejected=duplicates=0
    for at,event in enumerate(events):
        if at<len(strip):p=copy.deepcopy(strip[at]);p.pop('copy_index');origin={'kind':'side-strip','index':at}
        else:
            while True:
                i,j=queue.popleft();p,origin=lists[i][j]
                if counts[p['part_id']]>=plan['new_pose_caps'][p['part_id']]:deferred.append([i,j])
                else:break
        assert event['origin']==origin;g=shape(parts[p['part_id']],p['transform']);a,b,c,d=g.bounds;height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>height-m['top']-edge+1e-7
        blockers=[]
        for k in here[p['sheet_id']]:
            proposalpairs+=1
            if g.distance(geometry[k])<job['clearance']-1e-7:blockers.append(k)
        if outside or blockers:rejected+=1;assert event=={'origin':origin,'added':False,'reason':'geometry','outside':bool(outside),'blockers':blockers}
        elif identity(p) in keys:duplicates+=1;assert event=={'origin':origin,'added':False,'reason':'duplicate','candidate':keys[identity(p)]}
        else:
            k=len(source)+18+len(added);assert event=={'origin':origin,'added':True,'candidate':k} and pool[k]['placement']==p
            assert pool[k]['source']==origin and abs(pool[k]['filled_area_mm2']-g.area)<1e-7
            keys[identity(p)]=k;added.append(k);counts[p['part_id']]+=1
        if at<len(strip):assert event['candidate']==mp['optional_insert_strip'][at]
        elif j+1<len(lists[i]):queue.append((i,j+1))
    pending=load(OUT/'pending.json');assert pending['unbuilt_queries']==planned[len(queries):] and pending['proposal_lists']==sorted(deferred+list(map(list,queue)))
    assert added==mp['new_candidates'] and dict(counts)==result['new_candidates'];ids=mp['candidates'];assert ids==sorted(eligible+added)
    for i in ids+fixed:
        p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform'];g=geometry[i];a,b,c,d=g.bounds
        assert g.is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=height-m['top']-edge+1e-7
    gs=np.asarray([geometry[i] for i in ids],dtype=object);bb=shapely.bounds(gs);ss=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);adj=[0]*len(ids);allpairs=near=0
    for i in range(len(ids)):
        js=np.arange(i+1,len(ids));js=js[ss[js]==ss[i]];allpairs+=len(js)
        dx=np.maximum(0,np.maximum(bb[js,0]-bb[i,2],bb[i,0]-bb[js,2]));dy=np.maximum(0,np.maximum(bb[js,1]-bb[i,3],bb[i,1]-bb[js,3]));js=js[np.hypot(dx,dy)<=job['clearance']+1e-7];near+=len(js)
        for j in js[shapely.distance(gs[i],gs[js])<job['clearance']-1e-7]:j=int(j);adj[i]|=1<<j;adj[j]|=1<<i
    edgecount=sum(a.bit_count() for a in adj)//2;seen=0;previous=(-1,-1)
    with gzip.open(OUT/'conflicts.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            pair=tuple(json.loads(line));i,j=pair;assert pair>previous and i<j and (adj[i]>>j)&1;previous=pair;seen+=1
    assert seen==edgecount==result['conflicts'];covered=[0]*len(ids);cliquecount=0
    with gzip.open(OUT/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            c=json.loads(line);assert len(c)==len(set(c));mask=sum(1<<i for i in c);cliquecount+=1
            for i in c:others=mask^(1<<i);assert not(others&~adj[i]);covered[i]|=others
    assert covered==adj
    record={'passed':True,'seconds':time.perf_counter()-start,'old_filter_pairs':oldpairs,'proposal_fixed_pairs':proposalpairs,'rejections':rejected,'duplicates':duplicates,
      'all_queries_and_compound_placements_verified':True,'compound_internal_pairs_verified':patternpairs,'pending_lists_preserved':len(pending['proposal_lists']),
      'all_small_pair_possibilities':allpairs,'exact_pair_distances':near,'conflicts':edgecount,'cliques_including_residual_edges':cliquecount,
      'all_geometry_and_graph_coverage_checked':True,'native_margin_qualified':False,'full_target_witness':False}
    write(dst/'checks.json',record);print(record,flush=True)
if __name__=='__main__':main()
