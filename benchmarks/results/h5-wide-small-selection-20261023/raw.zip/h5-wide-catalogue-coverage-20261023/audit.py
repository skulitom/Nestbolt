"""Finite audit of saved denser cog groups omitted from the wide-pool catalogue."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
from itertools import combinations,product
from hashlib import sha256
import copy,json,math,shutil
from audit_h5_cog_lattices import shape

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-wide-small-pool-20261023'
OUT=ROOT/'output/h5-wide-catalogue-coverage-20261023'
ALIGNED=ROOT/'output/h5-aligned-stagger-20261018'
RAGGED=ROOT/'output/h5-ragged-cogs-20261018'
SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def key(p):
    t=p['transform']
    return (p['part_id'],p['sheet_id'],t['mirrored'],float(t['rotation_radians']).hex(),*(float(x).hex() for x in t['translation']))
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    inputs=[BASE/n for n in ['candidates.json','mapping.json','zones.json','compound-placements.json','layout-audit/checks.json']]
    inputs += [ALIGNED/n for n in ['patterns.json','pareto.json','audit.json']]+[RAGGED/n for n in ['patterns.json','selection.json']]
    inputs += [SRC/n for n in ['job.json','conditional-target.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
      'finite_cases':'Every saved aligned Pareto group and every selected ragged-row group; both whole-group quarter turns; all recorded wide-pool free rectangles; four corners and center, deduplicated within each rectangle. These are placements of already existing components, not a repeated search or a new packing run.',
      'checks':'Recompute every selected original component pair and dimension, every transformed member, every stock and fixed-frame pair, and exact-hex identity coverage in the completed wide pool. Preserve all records. This only identifies missing candidate coordinates; it does not accept a complete job or claim that the omitted groups were never tested elsewhere.',
      'solver_calls':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clearance=job['clearance']
    target=load(SRC/'conditional-target.json');pool=load(BASE/'candidates.json');mp=load(BASE/'mapping.json');present={key(p['placement']) for p in pool}
    fixed=[pool[i]['placement'] for i in mp['fixed_candidates']];fixed_g=[(p['sheet_id'],shape(parts[p['part_id']],p['transform'])) for p in fixed]
    catalogue=[]
    for folder,ids in [(ALIGNED,load(ALIGNED/'pareto.json')),(RAGGED,[r['pattern'] for r in load(RAGGED/'selection.json')])]:
        source=load(folder/'patterns.json')
        for ident in ids:catalogue.append((folder.name,source[ident]))
    zones=load(BASE/'zones.json');records=[];components=[];component_pairs=0;placed_pairs=0;frame_pairs=0;unique={};new={};minimum=math.inf
    for source,pattern in catalogue:
        gs=[shape(parts[p['part_id']],p['transform']) for p in pattern['members']]
        assert all(p['part_id']=='cog' and not p['transform']['mirrored'] for p in pattern['members'])
        bounds=[min(g.bounds[0] for g in gs),min(g.bounds[1] for g in gs),max(g.bounds[2] for g in gs),max(g.bounds[3] for g in gs)]
        assert abs(bounds[0])+abs(bounds[1])<1e-7 and abs(bounds[2]-pattern['width'])<1e-7 and abs(bounds[3]-pattern['height'])<1e-7
        local=math.inf
        for a,b in combinations(gs,2):
            component_pairs+=1;d=a.distance(b);local=min(local,d);assert a.disjoint(b) and d>=clearance-1e-7
        components.append({'source':source,'pattern':pattern['id'],'count':len(gs),'width':bounds[2],'height':bounds[3],'minimum_distance_mm':local if math.isfinite(local) else None})
        for turn,zone in product([0,1],zones):
            a,b,c,d=zone['bounds'];width,height=(pattern['height'],pattern['width']) if turn else (pattern['width'],pattern['height'])
            if width>c-a+1e-9 or height>d-b+1e-9:continue
            anchors=sorted(set([(a,b),(c-width,b),(a,d-height),(c-width,d-height),((a+c-width)/2,(b+d-height)/2)]))
            for x,y in anchors:
                poses=[];geoms=[]
                for member in pattern['members']:
                    t=copy.deepcopy(member['transform']);tx,ty=t['translation']
                    if turn:tx,ty=pattern['height']-ty,tx;t['rotation_radians']+=math.pi/2
                    t['translation']=[tx+x,ty+y];p={'part_id':'cog','sheet_id':zone['sheet'],'transform':t};g=shape(parts['cog'],t)
                    h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];ga,gb,gc,gd=g.bounds
                    assert g.is_valid and ga>=m['left']+edge-1e-7 and gb>=m['bottom']+edge-1e-7 and gc<=stock['width']-m['right']-edge+1e-7 and gd<=h-m['top']-edge+1e-7
                    for sheet,frame in fixed_g:
                        if sheet!=p['sheet_id']:continue
                        frame_pairs+=1;dist=g.distance(frame);minimum=min(minimum,dist);assert g.disjoint(frame) and dist>=clearance-1e-7
                    poses.append(p);geoms.append(g);unique[key(p)]=p
                    if key(p) not in present:new[key(p)]=p
                for g,h in combinations(geoms,2):
                    placed_pairs+=1;dist=g.distance(h);minimum=min(minimum,dist);assert g.disjoint(h) and dist>=clearance-1e-7
                records.append({'source':source,'pattern':pattern['id'],'quarter_turn':turn,'zone':zone,'anchor':[x,y],'placements':poses,'new_members':sum(key(p) not in present for p in poses)})
    write(OUT/'components.json',components);write(OUT/'placements.json',records);write(OUT/'new-poses.json',list(new.values()))
    checks={'passed':True,'components':len(components),'component_pairs':component_pairs,'placed_groups':len(records),'placed_member_pairs':placed_pairs,'fixed_frame_pairs':frame_pairs,'unique_cog_poses':len(unique),'new_cog_poses':len(new),'minimum_distance_mm':minimum,
      'complete_fifteen_cog_groups':sum(len(r['placements'])==15 for r in records),'native_margin_qualified':False,'full_target_witness':False,'solver_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
