from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,subprocess
import numpy as np
from h5_mixed_mode_union_20261107 import ROOT,BASE,load,Objective
OUT=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107';S=BASE/'search/round-00'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();pre=load(BASE/'audit/checks.json');response=load(BASE/'response-audit/checks.json');diag=load(D/'checks.json')
assert pre['passed'] and response['passed'] and diag['passed'] and response['closed_optimizer_calls']==1 and response['source_pair_failures']==39
records=load(D/'pair-diagnostic.json');assert len(records)==526
raw=load(S/'original-source-checks.json');lookup={tuple(sorted(map(tuple,p['keys']))):p for p in raw['pairs']};meta=load(S/'selected-mapping.json');lib=load(BASE/'library.json')
npz=np.load(S/'selected-arrays.npz',allow_pickle=False);a={k:npz[k] for k in npz.files};r=load(S/'response.json');energy,gradient,groups,orth=Objective(a,meta).evaluate(r['best_values_mm'],True)
by_pair={}
for group in groups:
    gi=group['group']['group']
    for i,pair in enumerate(group['group']['pairs']):
        ri=int(group['selected_regions'][i]);by_pair[pair]=(a[f'g{gi}_owners'][i].tolist(),float(group['squared_distances'][i,ri]),group['points'][i].tolist(),group['closest'][i,ri].tolist(),group['group']['source_region_indices'][ri],group['group']['source_region_signs'][ri])
seen=set()
for record in records:
    key=(record['kind'],record['pair']);assert key not in seen;seen.add(key)
    actual=lookup[tuple(sorted(map(tuple,record['identities'])))];assert record['source_passed']==actual['passed'] and record['source_distance_mm']==actual['distance_mm'] and record['source_intersection_area_mm2']==actual['intersection_area_mm2']
    if record['kind']=='cog_pair':
        owners,distance,query,nearest,index,sign=by_pair[record['pair']]
        assert record['owners']==owners and record['surrogate_squared_distance_mm2']==distance and record['canonical_query_mm']==query and record['nearest_certified_point_mm']==nearest and record['source_region_index']==index and record['source_region_sign']==sign
    else:
        source_pair=lib['component_pairs'][record['pair']];assert record['owners']==source_pair['owners'] and record['components']==source_pair['components'] and record['surrogate_squared_distance_mm2']==float(orth[record['pair']]**2)
    assert record['identities']==[meta['owners'][i]['identity'] for i in record['owners']]
assert seen=={('cog_pair',i) for i in range(258)}|{('orthogonal_component_pair',i) for i in range(268)}
misses=[p for p in records if p['source_passed'] and p['surrogate_squared_distance_mm2']>1e-12]
assert misses==load(D/'source-safe-outside-certified-union.json')==[] and diag['source_safe_positive_surrogate_terms']==diag['false_safe_cog_terms']==0
assert abs(sum(p['surrogate_squared_distance_mm2'] for p in records)-energy)<1e-8
diagnostic_process=load(ROOT/'output/h5-mixed-mode-coverage-process-20261107/process.json');assert diagnostic_process['passed'] and diagnostic_process['closed'] and diagnostic_process['job']['active_processes']==0
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');cog=next(p for p in job['parts'] if p['id']=='cog');assert cog['rotations']['kind']=='free' and not cog['allow_mirror']
current_cog=lib['family_modes']['cog'];assert len(current_cog)==1 and current_cog[0]['rotation_degrees']==7
old_report=ROOT/'benchmarks/results/h5-mixed-cog-rotations-and-capacity-20261026.md';assert old_report.is_file()
charge=response['shared_seconds_including_preparation']+diagnostic_process['complete_seconds']
next_step={'next':'Prepare independently certified two-phase original-cog geometry for the current first57/short9 construction before considering a new model. Do not repeat or extend any closed optimizer or orientation-descent pipeline.',
    'observed_limitation':'The28-mover construction includes all bracket/insert quarter-turn and mirror choices, but fixes all12 cogs to7degrees even though the original job permits free rotation. The one-owner bracket/insert descent is closed. At its terminal candidate every source-safe pair already has zero surrogate penalty, so no missing safe region is identified by this diagnostic.',
    'proposed_cog_phases_degrees':[7,16], 'basis':'Add a half-tooth9degree phase to the current7degree original source pose; check the actual80-vertex/20-tooth geometry and all200 hole vertices again. The earlier October26 two-phase work concerns a different short-sheet family at56.25/65.25degrees; preserve its closed calls and do not transfer any exclusion or reuse their search state.',
    'proposed_owner_mode_options':120,'source_requirements':['All8 original bracket modes,4 insert modes and2 declared cog phases; preserve all66 originals and the validated short9/fixed29.','Derive both phases from original affine source vertices, new exact inward stock/core bounds and every phase-dependent canonical offset/error. Never reuse7degree bounds or aliases for16degrees without proof.','Build and independently source-certify every cog-to-orthogonal and ordered cog-to-cog phase interaction. Mixed phases are not individually centrally symmetric: use correct K_ab and K_ba=-K_ab relations, never assume K_ab=-K_ab.','Read back every mode-dependent pose, pair, bound and rectangle coupling. Only after full geometry/model controls may a distinct frozen phase-coupled pipeline be considered.','Any optimizer vector identical to a previously closed full physical mode vector is forbidden. New calls require an actually changed source phase or other newly certified constraints, complete charged preparation and the original60/90second2GiB limits.','Every returned candidate requires full66 source checking before native/material work; no surrogate/local-minimum/grid status yields an exclusion.'],
    'optional_invalid_warm_start':'output/h5-mixed-mode-union-20261107/search/result.json final_modes/final_values_mm',
    'complete_consumed_charge_if_warm_start_and_diagnostic_used_seconds':charge,'charge_note':'Entire mixed-mode shared process35.98353959969245s already includes prior32.90726559958421s warm-start pipeline and complete new all-mode preparation. Add complete diagnostic0.3297646001446992s only if consumed; never add earlier components twice. Fresh phase geometry and model preparation are additional. Independent verification is separate.',
    'new_phase_geometry_prepared':False,'new_phase_model_prepared':False,'new_phase_solver_calls':0,'any_allocation_excluded':False,'fixed_arrangements_remaining':4,'whole_allocations_remaining':440,'H2_complete':False,'H5_complete':False}
write(OUT/'next-step.json',next_step)
receipt=load(ROOT/'output/h5-joint-union-main-sync-20261107/receipt.json');assert receipt['new_main']=='4ca0d8cd68c3c6fac8c4c995b2b85334c72dc766' and receipt['prior_main_all6_pass'] and receipt['remote_files_preserved']==52
ci=json.loads(subprocess.check_output(['gh','run','view','42343100154','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']==receipt['new_main'];write(OUT/'main-ci-at-review.json',ci)
inputs=[Path(__file__),old_report,ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-joint-union-main-sync-20261107/receipt.json']+[BASE/n for n in ['plan.json','audit/plan.json','audit/checks.json','response-audit/plan.json','response-audit/checks.json','search/process.json']]+[D/n for n in ['plan.json','checks.json','pair-diagnostic.json','source-safe-outside-certified-union.json']]+[ROOT/'output/h5-mixed-mode-coverage-process-20261107'/n for n in ['opened.json','process.json']]+[ROOT/'output/h5-mixed-mode-union-preparation-process-20261107'/n for n in ['opened.json','process.json']]
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in {**data.get('inputs',{}),**data.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconcile all audited legal-mode model/response evidence and independently compare every526 surrogate term with its original-source pair record. Preserve the terminal local minimum and every failed original pair. Verify that current cog phase is fixed7degrees while original rotation policy is free, and scope a new two-phase source-geometry investigation without opening any new solve or transferring old short-sheet exclusions.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'source_bindings':len(bindings),'mode_options':108,'mode_trial_evaluations':159,'closed_optimizer_calls':1,'source_pair_failures':39,'source_stock_failures':0,'source_valid66':False,'coverage_diagnostic_terms':526,'source_safe_positive_surrogate_terms':0,'false_safe_cog_terms':0,'current_cog_phase_degrees':7,'original_cog_rotation_policy':'free','new_phase_geometry_prepared':False,'next_consumed_charge_seconds':charge,'fixed_arrangements_remaining':4,'whole_allocations_remaining':440,'main':receipt['new_main'],'main_ci_status':ci['status'],'main_ci_conclusion':ci['conclusion'],'completion_percent':60,'H2_complete':False,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
