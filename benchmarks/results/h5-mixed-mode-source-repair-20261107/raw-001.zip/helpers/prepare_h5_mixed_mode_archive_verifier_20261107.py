from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'output/verify_h5_joint_and_union_checkpoint_20261107.py'
text=source.read_text(encoding='utf-8')
assert text.count("NAME='h5-joint-region-and-continuous-repairs-20261107'")==1
text=text.replace("NAME='h5-joint-region-and-continuous-repairs-20261107'","NAME='h5-mixed-mode-source-repair-20261107'")
with (ROOT/'output/verify_h5_mixed_mode_checkpoint_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
