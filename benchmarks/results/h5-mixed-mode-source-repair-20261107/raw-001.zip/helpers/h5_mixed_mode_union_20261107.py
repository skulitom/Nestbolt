"""Auditable source library for legal-mode distance-to-safe-union repair."""
from pathlib import Path
from fractions import Fraction
import json
import numpy as np
from h5_cog_physical_union_distance_v2_20261107 import Objective

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-mixed-mode-union-20261107'
I = ROOT / 'output/h5-independent-twelve-cog-integer-20261107'
P = ROOT / 'output/h5-cog-candidate-projections-20261107'
V = ROOT / 'output/h5-cog-physical-union-distance-v2-20261107'
load = lambda p: json.loads(p.read_bytes())


def prepare_library():
    owners = load(P / 'owners.json')
    library = {'owners': owners, 'family_modes': load(I / 'family-modes.json'),
               'aliases': load(I / 'aliases.json'), 'rectangles': load(I / 'mode-rectangles.json'),
               'components': load(I / 'components.json'), 'component_pairs': load(I / 'component-pairs.json'),
               'pairs': [{'pair': p['pair'], 'owners': p['owners'], 'kind': p['kind']}
                         for p in load(P / 'pair-projections.json')],
               'initial_modes': [o['mode'] for o in owners],
               'initial_values_mm': load(V / 'search/response.json')['best_values_mm'],
               'world_origin_mm': [0, 2100], 'rectangle_gap_grid': 23, 'groups': []}
    regions = load(P / 'regions.json')
    arrays = {}
    for gi, cid in enumerate([0, 1, 2, 'cog_cog']):
        selected = [(i, r, 1) for i, r in enumerate(regions) if r['class'] == cid and not r['empty']]
        if cid == 'cog_cog':
            selected += [(i, r, -1) for i, r, _ in selected]
        nv = max(len(r['vertices']) for _, r, _ in selected)
        nh = max(len(r['planes']) for _, r, _ in selected)
        starts = np.zeros((len(selected), nv, 2)); ends = starts.copy()
        valid = np.zeros((len(selected), nv), dtype=bool)
        normals = np.zeros((len(selected), nh, 2)); upper = np.full((len(selected), nh), np.inf)
        for ri, (_, r, sign) in enumerate(selected):
            v = np.array([[sign * float(Fraction(x)/100) for x in p] for p in r['vertices']])
            n = len(v); starts[ri, :n] = v; ends[ri, :n] = np.roll(v, -1, axis=0); valid[ri, :n] = True
            for j, plane in enumerate(r['planes']):
                normal = np.array(plane['coefficients'], dtype=float)
                length = np.sqrt(normal @ normal)
                normals[ri, j] = sign * normal / length
                upper[ri, j] = plane['upper'] / 100 / length
        prefix = f'g{gi}_'
        arrays.update({prefix+'starts': starts, prefix+'ends': ends, prefix+'valid': valid,
                       prefix+'normals': normals, prefix+'upper': upper})
        library['groups'].append({'group': gi, 'class': cid,
                                  'source_region_indices': [i for i, _, _ in selected],
                                  'source_region_signs': [s for _, _, s in selected]})
    return arrays, library


def compile_modes(regions, library, modes, values):
    assert len(modes) == 28 and all(isinstance(m, int) for m in modes)
    owners = []
    for old, mode in zip(library['owners'], modes):
        source = library['family_modes'][old['identity'][0]][mode]
        assert source['mode'] == mode
        owners.append({'owner': old['owner'], 'identity': old['identity'], 'mode': mode,
                       'position_bounds_grid': source['integer_world_lower_left_bounds'],
                       'rotation_radians': source['rotation_radians'], 'mirrored': source['mirrored'],
                       'translation_from_lower_left': source['translation_from_lower_left']})
    a = dict(regions)
    a['bounds'] = np.array([b for o in owners for b in o['position_bounds_grid']], dtype=float)/100
    a['initial'] = np.clip(np.asarray(values, dtype=float), a['bounds'][:, 0], a['bounds'][:, 1])
    aliases = {(r['family'], r['mode']): r for r in library['aliases']}
    groups = []
    for group in library['groups']:
        records = []
        for pair in library['pairs']:
            if pair['kind'] == 'cog_cog':
                cid, matrix, offset = 'cog_cog', [[1, 0], [0, 1]], [0, 0]
            else:
                owner = owners[pair['owners'][1]]
                alias = aliases[owner['identity'][0], owner['mode']]
                cid, matrix, offset = alias['class'], alias['matrix'], alias['offset_grid']
            if cid == group['class']:
                records.append((pair, matrix, offset))
        prefix = f'g{group["group"]}_'
        a[prefix+'owners'] = np.array([p['owners'] for p, _, _ in records], dtype=np.int64).reshape(-1, 2)
        a[prefix+'matrix'] = np.array([m for _, m, _ in records], dtype=float).reshape(-1, 2, 2)
        a[prefix+'offset'] = np.array([o for _, _, o in records], dtype=float).reshape(-1, 2)/100
        if records:
            groups.append({**group, 'pairs': [p['pair'] for p, _, _ in records]})
    axes, positive, negative, upper = [], [], [], []
    for pair in library['component_pairs']:
        ca, cb = [library['components'][i] for i in pair['components']]
        oa, ob = [owners[i] for i in pair['owners']]
        ra = library['rectangles'][oa['identity'][0]][oa['mode']]['rectangles'][ca['piece']]['outward_offsets_grid']
        rb = library['rectangles'][ob['identity'][0]][ob['mode']]['rectangles'][cb['piece']]['outward_offsets_grid']
        x, y = pair['owners']; gap = library['rectangle_gap_grid']
        axes.append([0, 0, 1, 1]); positive.append([x, y, x, y]); negative.append([y, x, y, x])
        upper.append([rb[0]-ra[2]-gap, ra[0]-rb[2]-gap, rb[1]-ra[3]-gap, ra[1]-rb[3]-gap])
    a['orth_axis'] = np.array(axes, dtype=np.int64)
    a['orth_positive'] = np.array(positive, dtype=np.int64)
    a['orth_negative'] = np.array(negative, dtype=np.int64)
    a['orth_upper'] = np.array(upper, dtype=float)/100
    return a, {'groups': groups, 'owners': owners}


def readback_compilation(a, meta, regions, library, modes, previous):
    """Check each dynamically coupled field without invoking the compiler again."""
    assert len(meta['owners']) == len(modes) == 28
    expected_keys = set(regions) | {'bounds', 'initial', 'orth_axis', 'orth_positive', 'orth_negative', 'orth_upper'}
    for key, value in regions.items():
        assert a[key] is value, key  # immutable source arrays are shared, not rebuilt
    for i, (owner, mode) in enumerate(zip(meta['owners'], modes)):
        identity = library['owners'][i]['identity']; source = library['family_modes'][identity[0]][mode]
        assert owner == {'owner': i, 'identity': identity, 'mode': mode,
                         'position_bounds_grid': source['integer_world_lower_left_bounds'],
                         'rotation_radians': source['rotation_radians'], 'mirrored': source['mirrored'],
                         'translation_from_lower_left': source['translation_from_lower_left']}
        assert np.array_equal(a['bounds'][2*i:2*i+2], np.array(source['integer_world_lower_left_bounds'])/100)
    assert np.array_equal(a['initial'], np.minimum(np.maximum(previous, a['bounds'][:, 0]), a['bounds'][:, 1]))
    seen = []; active = []
    for source_group in library['groups']:
        gi = source_group['group']; prefix = f'g{gi}_'; pp = []
        expected_keys.update(prefix+k for k in ['owners', 'matrix', 'offset'])
        for p in library['pairs']:
            if p['kind'] == 'cog_cog':
                cid, matrix, offset = 'cog_cog', [[1, 0], [0, 1]], [0, 0]
            else:
                oi = p['owners'][1]; family = library['owners'][oi]['identity'][0]
                alias, = [r for r in library['aliases'] if r['family'] == family and r['mode'] == modes[oi]]
                cid, matrix, offset = alias['class'], alias['matrix'], alias['offset_grid']
            if cid != source_group['class']:
                continue
            j = len(pp); pp.append(p['pair'])
            assert a[prefix+'owners'][j].tolist() == p['owners']
            assert a[prefix+'matrix'][j].tolist() == matrix
            assert a[prefix+'offset'][j].tolist() == [x/100 for x in offset]
        assert a[prefix+'owners'].shape == (len(pp), 2)
        assert a[prefix+'matrix'].shape == (len(pp), 2, 2) and a[prefix+'offset'].shape == (len(pp), 2)
        if pp:
            active.append({**source_group, 'pairs': pp}); seen.extend(pp)
    assert meta['groups'] == active and sorted(seen) == list(range(258))
    for i, pair in enumerate(library['component_pairs']):
        rectangles = []
        for ci in pair['components']:
            component = library['components'][ci]; oi = component['owner']; family = component['identity'][0]
            rectangles.append(library['rectangles'][family][modes[oi]]['rectangles'][component['piece']]['outward_offsets_grid'])
        ra, rb = rectangles; oa, ob = pair['owners']; gap = library['rectangle_gap_grid']
        expected = [(0, oa, ob, rb[0]-ra[2]-gap), (0, ob, oa, ra[0]-rb[2]-gap),
                    (1, oa, ob, rb[1]-ra[3]-gap), (1, ob, oa, ra[1]-rb[3]-gap)]
        for j, (axis, positive, negative, bound) in enumerate(expected):
            assert a['orth_axis'][i, j] == axis and a['orth_positive'][i, j] == positive
            assert a['orth_negative'][i, j] == negative and a['orth_upper'][i, j] == bound/100
    assert all(a[k].shape == (268, 4) for k in ['orth_axis', 'orth_positive', 'orth_negative', 'orth_upper'])
    assert set(a) == expected_keys
    return True


def source_rows(library, modes, values, fixed):
    rows = list(fixed)
    for i, owner in enumerate(library['owners']):
        mode = library['family_modes'][owner['identity'][0]][modes[i]]
        rows.append({'part_id': owner['identity'][0], 'copy_index': owner['identity'][1], 'sheet_id': 'sheet-0',
                     'transform': {'rotation_radians': mode['rotation_radians'], 'mirrored': mode['mirrored'],
                                   'translation': [float(values[2*i+k])+library['world_origin_mm'][k]+mode['translation_from_lower_left'][k] for k in [0, 1]]}})
    return rows
