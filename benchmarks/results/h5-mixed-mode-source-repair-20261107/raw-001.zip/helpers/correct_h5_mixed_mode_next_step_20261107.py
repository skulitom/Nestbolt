"""Preserve and correct an overstrong symmetry sentence in the proposed next step."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-mode-checkpoint-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
before=load(BASE/'next-step.json');after=json.loads(json.dumps(before))
old=after['source_requirements'][2]
assert 'Mixed phases are not individually centrally symmetric' in old
after['source_requirements'][2]='Build and independently source-certify every cog-to-orthogonal and ordered cog-to-cog phase interaction. Reversing an ordered pair changes its phase labels: prove the appropriate K_ab and K_ba=-K_ab mapping from original source coordinates. Do not assume a same-phase symmetric-array shortcut applies to mixed phases without proof. Different phase labels alone do not imply absence of central symmetry.'
write(BASE/'next-step-v2.json',after)
write(BASE/'next-step-correction.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),BASE/'next-step.json',BASE/'next-step-v2.json']},'reason':'The first proposed-next-step text made an overstrong central-symmetry assertion. Different phases alone do not destroy central symmetry. The actual requirement is to certify ordered phase mappings and source rounding; do not assume an unproved shortcut. No new phase geometry or solver call has been built, and no computation relied on the incorrect sentence. Original text and hash remain preserved.','changed_fields':['source_requirements[2]'],'algorithm_data_changed':False,'new_optimizer_calls':0,'authoritative_next_step':'next-step-v2.json'})
print({'corrected':'next-step-v2.json','original_preserved':True})
