"""Seal new evidence, reusing exact bytes from the preceding verified archive graph."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-mixed-mode-source-repair-20261107';OUT=ROOT/'benchmarks/results'/NAME
BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'
PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
front=load(F/'checks.json');assert front['passed'] and front['closed_optimizer_calls']==1 and front['source_pair_failures']==39
assert load(PARENT/'archive-checks.json')['passed']
parents={};manifest=load(PARENT/'raw-manifest.json');mh=digest(PARENT/'raw-manifest.json')
for row in manifest['files']:
    parents[row['sha256'],row['bytes']]={'manifest':(PARENT/'raw-manifest.json').relative_to(ROOT).as_posix(),'manifest_sha256':mh,'archive':row['archive'],'member':row['path'],'bytes':row['bytes'],'sha256':row['sha256']}
for row in load(PARENT/'external-evidence.json').values():parents.setdefault((row['sha256'],row['bytes']),row)
OUT.mkdir();members={};external={};bindings={};queue=[];seen=set()
def traversable(p):return p.name in ['plan.json','opened.json','final-preparation-charges.json','next-step-correction.json'] or p.name.endswith('process.json')
def add(name,p):
    assert p.is_file() and p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts)
    key=(digest(p),p.stat().st_size)
    if key in parents:external[name]=parents[key]
    else:members[name]=p
    if traversable(p) or p.suffix=='.py':queue.append(p)
folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*mixed*mode*20261107.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,'verify_h5_mixed_mode_checkpoint_20261107.py']:add('helpers/'+name,ROOT/'output'/name)
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if traversable(p):
        data=load(p)
        for name,h in {**data.get('inputs',{}),**data.get('preserved_inputs',{})}.items():
            z=ROOT/name;assert digest(z)==h,name;bindings[name]=h;add('source-inputs/'+name,z)
        if 'script' in data and 'script_sha256' in data:
            z=ROOT/data['script'];assert digest(z)==data['script_sha256'];bindings[data['script']]=data['script_sha256'];add('source-inputs/'+data['script'],z)
    elif p.suffix=='.py':
        if p==ROOT/'output/prepare_h5_cog_capacity_search_sealer_20261107.py':
            correction=load(ROOT/'output/h5-cog-capacity-search-sealer-correction-20261107.json');assert digest(p)==correction['failed_generator_sha256']
            try:ast.parse(p.read_text(encoding='utf-8'))
            except SyntaxError as exc:assert exc.lineno==134
            else:raise AssertionError('Expected preserved raw-source failure')
            continue
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for directory in ['output','scripts']:
                    z=ROOT/directory/(module+'.py')
                    if z.is_file():add('imported-helpers/'+directory+'/'+z.name,z)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'external-evidence.json',external);write(OUT/'source-bindings.json',bindings)
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step-v2.json','next-step.json'),(F/'next-step-correction.json','next-step-correction.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(BASE/'audit/checks.json','mode-model-audit.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/round-reconciliation.json','mode-selection-audit.json'),(BASE/'response-audit/round-00-collision-details.json','source-failures.json'),(BASE/'search/process.json','closed-process.json'),(D/'checks.json','coverage-diagnostic.json'),(ROOT/'output/h5-mixed-mode-union-preparation-process-20261107/process.json','preparation-process.json'),(ROOT/'output/h5-mixed-mode-coverage-process-20261107/process.json','coverage-process.json'),(ROOT/'output/h5-joint-union-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Legal-mode source repair — 2026-11-07

The new orientation-change construction closes after **one changed-mode
optimization and 159 mode evaluations**. Its candidate remains invalid:
independent original-source replay finds **39 failing pairs**, with all stock
checks passing. No remaining single-owner bracket/insert change improves the
model objective at that candidate. This is a local heuristic result, not a
packing impossibility proof. Four fixed arrangements and all 440 allocations
remain. H2/H5 stay open at **60% completed milestone weight**.

## Audited legal-mode geometry

[The complete model preflight]({NAME}/mode-model-audit.json) checks **108 owner/mode
options**: eight brackets with eight quarter-turn/mirror modes each, eight
inserts with four modes each, and twelve cogs with one declared 7-degree phase.
The original job allows free cog rotation; the108 options are the current
construction's finite modes, not every possible legal cog orientation.

All four certified region classes, **1,340 vertices, 2,350 planes and 760 exact
rational projection comparisons** pass independent readback. The full cog-pair
union retains both reflected halves. Every rigid rectangle pair retains all
four axis directions. Every mode-specific stock bound, affine pose, canonical
matrix and offset is coupled to its original owner.

Controls cover all108 source pose reconstructions, **81 distinct mode vectors**,
168 analytic derivatives, cog-identity reversal and [six deliberately corrupted
dynamic models]({NAME}/negative-controls.json). The initial energy and gradient
reproduce the previous invalid candidate. Pinned SciPy1.17.1 controls and tool
hashes are retained. [Complete preparation]({NAME}/preparation-process.json)
takes **0.321369s**; the separate complete preflight audit takes **3.211676s**.

## Closed bounded pipeline

The pipeline fully scores every unvisited single-owner legal orientation
change, clamps only that owner to its new source stock bounds, and independently
reads back every dynamic model. Only an objective improvement greater than
0.000001mm² can open a call, using objective/identity/mode tie-breaking.
The initial closed vector and every previously optimized full vector are
excluded. A chosen model is serialized and read back before its sole call.

[Independent selection replay]({NAME}/mode-selection-audit.json) verifies all
**80 first-round options** and the selected change: original bracket4 moves
to mode5. The surrogate energy falls from **22,384.710841 to17,611.290512mm²**
before optimization. One L-BFGS-B call then reaches **16,524.058157mm²**, with
26 iterations,29 evaluations and27 retained improving points. All points,
gradients, bounds, selected modes and serialized model fields replay.

The second round checks **79 unvisited alternatives**, with no strict
improvement. It opens no optimizer call and stops the whole pipeline. The
maximum of eight calls is a ceiling, not permission to restart or continue
after this stop. This pipeline and its complete mode vector stay closed.

[All66 original source parts are reconstructed and checked]({NAME}/response-audit.json):
**1,632 same-sheet pairs,264 stock edges,90 holes and10,026 hole vertices**.
[The39 failing original pairs are preserved]({NAME}/source-failures.json).
No native or material-validity call follows an invalid candidate. Numerical
convergence and reduced penalty give no H5 credit or allocation exclusion.

Charged preparation is **33.228634s**, including the entire consumed
32.907266s warm-start process and new all-mode preparation exactly once.
Algorithm/shared totals are **35.911924/35.983540s**, within60/90s, with no
optimizer-slice or algorithm overrun. [All five processes close]({NAME}/closed-process.json)
with **97,972,224bytes** peak committed memory, below2GiB. Every evaluated
mode, selected model, incumbent and failed source result remains preserved.

## Coverage diagnostic and remaining geometric freedom

[A deterministic diagnostic]({NAME}/coverage-diagnostic.json) reconciles all
**526 surrogate terms** with original-source pair checks. At this candidate,
every actually source-safe pair has zero penalty; there are no false-safe cog
terms. It identifies no missing safe region to add here. This is a statement
about this candidate only, not a global completeness proof of the safe union.
Its [complete bounded process]({NAME}/coverage-process.json) takes **0.329765s**;
the checkpoint audit independently reads back every diagnostic field.

[The next specification]({NAME}/next-step.json) investigates original cog
phases **7 and16degrees**, a half-tooth phase apart, for the current first57
and valid short9 construction. This would add12 options for120 total.
It requires fresh original-source geometry, stock bounds, aliases and ordered
phase interactions before any new model or call. Earlier October26 mixed-angle
short-sheet calls remain closed; their exclusions and search states do not
transfer. The new geometry and model are **not prepared or run**.

[A wording correction]({NAME}/next-step-correction.json) preserves the first
next-step text and corrects its overstrong symmetry sentence: differing phases
do not by themselves rule out central symmetry. Ordered pair mappings and
rounding must be proved from source geometry; no computation used that sentence.

If the invalid warm start and diagnostic are consumed, the next construction
starts with **36.313304s** already charged before fresh preparation. Full66
source/native/material validity, production integration, UI/CLI/MCP parity
and the unchanged H5 matrix remain necessary. H2 retains its original gate
and unopened reserved vectors. Production, README and releases are unchanged.

[The prior checkpoint reached main4ca0d8cd normally]({NAME}/prior-main-push-receipt.json)
after all six prior checks passed, preserving52 remote files. [Current main CI
at review]({NAME}/main-ci-at-review.json) is retained; no run is cancelled.

[Raw evidence]({NAME}/raw-manifest.json) stores {archive['archive_members']}
canonical members and {archive['archive_bytes']:,}ZIP bytes. [Historical
references]({NAME}/external-evidence.json) and [source bindings]({NAME}/source-bindings.json)
preserve the complete consumed source graph. An independent byte-level archive
readback is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 legal-mode source repair:** [independent model/selection/source audits]({link}) verify108 finite owner/mode options,760 exact projection comparisons,168 derivatives and six corruption controls. The bounded pipeline evaluates80 initial and79 subsequent legal orientation changes, opens one strictly changed-mode call, then stops with no improving unvisited single-owner change. All27 improving points replay, but full66 original-source checks still fail39 pairs; all stock edges pass. Algorithm/shared totals are35.911924/35.983540s including33.228634s preparation, with no overruns and all processes closed. A526-term diagnostic finds no positive penalty on source-safe pairs at this candidate. The next unprepared source investigation adds a second original cog phase7/16degrees, requiring fresh geometry and ordered-pair proofs; the current12cogs remain fixed7degrees although the job permits free rotation. The next warm-start-plus-diagnostic charge is36.313304s before fresh preparation. Every closed call stays closed. Four fixed arrangements and440 allocations remain; H2/H5 stay open at60%. The preceding checkpoint reached main4ca0d8cd after all six prior checks passed, preserving52 remote files. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md';text=status.read_text(encoding='utf-8');begin=text.index('Latest H5 evidence:');end=text.index('\nThe earlier fixed 13-cog construction',begin)
intro=f'''Latest H5 evidence: [legal-mode source repair](../benchmarks/results/{NAME}.md).
All108 finite modes and159 actual orientation evaluations pass independent
readback. One changed-mode call converges numerically, but full66 original
source checks still fail39 pairs. All stock checks pass. The second round
has no improving unvisited single-owner orientation change; the pipeline is
closed without a valid layout or exclusion. All526 surrogate terms agree with
the diagnostic: no source-safe pair has positive penalty at this candidate.
The original job permits free cog rotation while the current construction
fixes all12 cogs at7degrees. A second phase at16degrees is the next source
geometry investigation, with fresh ordered-pair/stock/alias proofs required.
It is not built or run. The warm-start-plus-diagnostic lineage costs36.313304s
before new preparation. Four fixed arrangements and440 allocations remain.
H2/H5 stay open at60%; full source/native/material validity, production parity
and the unchanged H5 matrix remain required. The prior checkpoint reached
main4ca0d8cd after all six prior checks passed, preserving52 remote files.
Current CI is retained; production, README and releases are unchanged.
'''
status.write_text(text[:begin]+intro+text[end:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
