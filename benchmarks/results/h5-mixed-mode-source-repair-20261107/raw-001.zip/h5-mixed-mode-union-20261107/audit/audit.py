from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime, timezone
import json, time, shutil
import numpy as np
from h5_mixed_mode_union_20261107 import ROOT, BASE, I, P, V, load, compile_modes, readback_compilation, Objective, source_rows
from h5_cog_union_distance_20261107 import nearest_regions

OUT=BASE/'audit'; digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
lib=load(BASE/'library.json');archive=np.load(BASE/'regions.npz',allow_pickle=False);regions={k:archive[k] for k in archive.files}
for a in regions.values():a.flags.writeable=False
for key,name in [('family_modes','family-modes.json'),('aliases','aliases.json'),('rectangles','mode-rectangles.json'),('components','components.json'),('component_pairs','component-pairs.json')]:assert lib[key]==load(I/name)
assert lib['owners']==load(P/'owners.json')
assert lib['pairs']==[{k:p[k] for k in ['pair','owners','kind']} for p in load(P/'pair-projections.json')]
assert lib['initial_modes']==[o['mode'] for o in lib['owners']]
assert lib['initial_values_mm']==load(V/'search/response.json')['best_values_mm']
assert lib['world_origin_mm']==[0,2100] and lib['rectangle_gap_grid']==23
assert sum(len(lib['family_modes'][o['identity'][0]]) for o in lib['owners'])==108
source=load(P/'regions.json');expected_keys=set();vertices=planes=projection_checks=0

def exact_projection(point,r,sign):
    v=[tuple(sign*F(z)/100 for z in p) for p in r['vertices']]
    if all(sum(sign*c*x for c,x in zip(p['coefficients'],point))<=F(p['upper'],100) for p in r['planes']):return point,F(0)
    choices=[]
    for aa,bb in zip(v,v[1:]+v[:1]):
        edge=[b-a for a,b in zip(aa,bb)];den=sum(x*x for x in edge)
        t=F(0) if den==0 else max(F(0),min(F(1),sum((point[k]-aa[k])*edge[k] for k in [0,1])/den))
        q=tuple(aa[k]+t*edge[k] for k in [0,1]);choices.append((sum((point[k]-q[k])**2 for k in [0,1]),q))
    distance,q=min(choices);return q,distance

for gi,cid in enumerate([0,1,2,'cog_cog']):
    ids=[i for i,r in enumerate(source) if r['class']==cid and not r['empty']];signs=[1]*len(ids)
    if cid=='cog_cog':signs += [-1]*len(ids);ids=ids+ids
    assert lib['groups'][gi]=={'group':gi,'class':cid,'source_region_indices':ids,'source_region_signs':signs}
    prefix=f'g{gi}_';expected_keys.update(prefix+k for k in ['starts','ends','valid','normals','upper'])
    for ri,(index,sign) in enumerate(zip(ids,signs)):
        r=source[index];v=np.array([[sign*float(F(z)/100) for z in p] for p in r['vertices']]);n=len(v);vertices+=n;planes+=len(r['planes'])
        assert np.array_equal(regions[prefix+'starts'][ri,:n],v) and np.array_equal(regions[prefix+'ends'][ri,:n],v[list(range(1,n))+[0]])
        assert regions[prefix+'valid'][ri].tolist()==[True]*n+[False]*(regions[prefix+'valid'].shape[1]-n)
        assert np.all(regions[prefix+'starts'][ri,n:]==0) and np.all(regions[prefix+'ends'][ri,n:]==0)
        for j,p in enumerate(r['planes']):
            x,y=p['coefficients'];norm=(x*x+y*y)**.5
            assert np.allclose(regions[prefix+'normals'][ri,j],[sign*x/norm,sign*y/norm],atol=0,rtol=2e-16)
            assert abs(regions[prefix+'upper'][ri,j]-p['upper']/100/norm)<1e-11
        assert np.all(regions[prefix+'normals'][ri,len(r['planes']):]==0) and np.all(np.isposinf(regions[prefix+'upper'][ri,len(r['planes']):]))
    probes=[(F(0),F(0)),(F(23333,100),F(-18425,100))]
    q,d=nearest_regions(np.array(probes,dtype=float),*[regions[prefix+k] for k in ['starts','ends','valid','normals','upper']])
    for pi,point in enumerate(probes):
        for ri,(index,sign) in enumerate(zip(ids,signs)):
            expected,dist=exact_projection(point,source[index],sign)
            assert np.max(np.abs(q[pi,ri]-np.array(expected,dtype=float)))<1e-8
            assert abs(d[pi,ri]-float(dist))<1e-7+1e-12*float(dist);projection_checks+=1
assert set(regions)==expected_keys
initial=lib['initial_modes'];x=np.array(lib['initial_values_mm']);a,meta=compile_modes(regions,lib,initial,x)
assert readback_compilation(a,meta,regions,lib,initial,x)
value,gradient=Objective(a,meta).evaluate(a['initial'])
old=np.load(V/'source-arrays.npz',allow_pickle=False);old_a={k:old[k] for k in old.files}
old_value,old_gradient=Objective(old_a,load(V/'mapping.json')).evaluate(x)
assert abs(value-old_value)<1e-8 and np.max(np.abs(gradient-old_gradient))<1e-9
assert value==load(V/'search/response.json')['best_objective_mm2']
compiled=1;poses=0;mode_readbacks=[];fixed=load(ROOT/'output/h5-first57-direct-short9-20261104/fixed29.json')+load(ROOT/'output/h5-first57-direct-short9-20261104/short9-source.json')
for oi,owner in enumerate(lib['owners']):
    for mode in lib['family_modes'][owner['identity'][0]]:
        modes=initial.copy();modes[oi]=mode['mode'];aa,mm=compile_modes(regions,lib,modes,x)
        assert readback_compilation(aa,mm,regions,lib,modes,x)
        rows=source_rows(lib,modes,aa['initial'],fixed);row=rows[38+oi]
        original_mode=load(I/'family-modes.json')[owner['identity'][0]][mode['mode']]
        assert row['transform']=={'rotation_radians':original_mode['rotation_radians'],'mirrored':original_mode['mirrored'],
            'translation':[float(aa['initial'][2*oi+k])+[0,2100][k]+original_mode['translation_from_lower_left'][k] for k in [0,1]]}
        assert rows[:38]==fixed and sorted((r['part_id'],r['copy_index']) for r in rows)==sorted(map(tuple,load(I/'inventory.json')['full66_identities']))
        poses+=1
        if mode['mode']!=initial[oi]:compiled+=1
        mode_readbacks.append({'owner':oi,'mode':mode['mode'],'passed':True})
assert compiled==81 and poses==108
write(OUT/'mode-readbacks.json',mode_readbacks)
derivatives=[]
for phase in range(3):
    modes=initial.copy()
    if phase:
        modes[:8]=[4 if phase==1 else 7]*8;modes[8:16]=[phase]*8
    aa,mm=compile_modes(regions,lib,modes,x);point=aa['initial']+.037*np.sin(np.arange(56)*2**.5+.2+phase)
    objective=Objective(aa,mm);energy,g=objective.evaluate(point);errors=[];h=1e-4
    for i in range(56):
        plus=point.copy();minus=point.copy();plus[i]+=h;minus[i]-=h
        observed=(objective.evaluate(plus)[0]-objective.evaluate(minus)[0])/(2*h)
        error=abs(observed-g[i]);assert error<.003+1e-6*abs(g[i]),(phase,i,observed,g[i],error);errors.append(error)
    assert np.max(np.abs(g.reshape(28,2).sum(axis=0)))<1e-8
    assert objective.evaluate(point-1e-7*g)[0]<energy
    swapped=point.reshape(28,2).copy();swapped[16:]=swapped[16:][::-1]
    ev,gg=objective.evaluate(swapped.reshape(-1));expected=g.reshape(28,2).copy();expected[16:]=expected[16:][::-1]
    assert abs(ev-energy)<1e-7 and np.max(np.abs(gg.reshape(28,2)-expected))<1e-8
    derivatives.append({'phase':phase,'modes':modes,'coordinates':56,'maximum_error':max(errors),'energy_mm2':energy})
write(OUT/'derivative-controls.json',derivatives)
negative=[]
for corruption in ['bound','mode_pose','pair_matrix','pair_offset','rectangle','missing_pair']:
    aa,mm=compile_modes(regions,lib,initial,x)
    if corruption=='bound':aa['bounds'][0,0]+=1
    elif corruption=='mode_pose':mm['owners'][0]['rotation_radians']+=.1
    elif corruption=='pair_matrix':aa['g0_matrix'][0,0,0]+=1
    elif corruption=='pair_offset':aa['g0_offset'][0,0]+=1
    elif corruption=='rectangle':aa['orth_upper'][0,0]+=1
    else:mm['groups'][0]['pairs'].pop()
    caught=False
    try:readback_compilation(aa,mm,regions,lib,initial,x)
    except AssertionError:caught=True
    assert caught,corruption;negative.append({'corruption':corruption,'rejected':True})
write(OUT/'negative-controls.json',negative)
controls=load(V/'audit/optimizer-controls.json');assert controls['passed']
for name,r in load(V/'audit/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==r['sha256']
write(OUT/'optimizer-controls.json',controls);write(OUT/'tool-provenance.json',load(V/'audit/tool-provenance.json'))
files=[Path(__file__),ROOT/'output/h5_mixed_mode_union_20261107.py',ROOT/'output/h5_cog_union_distance_20261107.py',ROOT/'output/h5_cog_physical_union_distance_v2_20261107.py']+[BASE/n for n in ['plan.json','checks.json','regions.npz','library.json']]+[I/n for n in ['audit/plan.json','audit/checks.json','family-modes.json','aliases.json','mode-rectangles.json','components.json','component-pairs.json','inventory.json']]+[P/n for n in ['audit/plan.json','audit/checks.json','owners.json','regions.json','pair-projections.json']]+[V/n for n in ['source-arrays.npz','mapping.json','search/response.json','audit/optimizer-controls.json','audit/tool-provenance.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'method':'Independent readback of every source-mode/alias/component/pair/region field, exact rational projections for all four region classes and both cog halves, all108 mode pose/bound couplings,81 distinct dynamic vectors, six corruption controls,168 finite-difference derivatives and cog-identity permutation controls. Reproduce the prior invalid warm-start objective/gradient exactly. Reuse unchanged audited SciPy controls and verify tool hashes. No source optimizer call and no layout validity claim.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'mode_alternatives':108,'distinct_mode_vectors':81,'vertices_checked':vertices,'planes_checked':planes,'exact_projection_comparisons':projection_checks,'analytic_derivatives':168,'negative_controls':6,'initial_objective_mm2':value,'regions_sha256':digest(BASE/'regions.npz'),'library_sha256':digest(BASE/'library.json'),'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False})
print(load(OUT/'checks.json'))
