from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
from h5_mixed_mode_union_20261107 import ROOT,BASE,I,load,compile_modes,readback_compilation,Objective
from h5_legacy64_source_readback import audit
OUT=BASE/'response-audit';S=BASE/'search';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
lib=load(BASE/'library.json');archive=np.load(BASE/'regions.npz',allow_pickle=False);regions={k:archive[k] for k in archive.files}
for a in regions.values():a.flags.writeable=False
plan=load(S/'plan.json');result=load(S/'result.json');process=load(S/'process.json');job=load(S/'job.json')
assert load(BASE/'audit/checks.json')['passed'];modes=lib['initial_modes'];x=np.array(lib['initial_values_mm']);visited={tuple(modes)}
trials_count=incumbents_count=evaluations_count=iterations_count=calls=0;last_source=None;reports=[]
folders=sorted(S.glob('round-*'));assert len(folders)==2
for folder in folders:
    opened=load(folder/'opened.json');trials=load(folder/'mode-trials.json')
    assert opened['modes']==modes and np.array_equal(opened['values_mm'],x)
    assert opened['previously_optimized_or_initial_modes']==[list(v) for v in sorted(visited)]
    a,meta=compile_modes(regions,lib,modes,x);assert readback_compilation(a,meta,regions,lib,modes,x)
    energy,g=Objective(a,meta).evaluate(x);assert energy==opened['objective_mm2'] and trials['complete']
    expected=[];skipped=[]
    for owner in lib['owners'][:16]:
        oi=owner['owner']
        for option in lib['family_modes'][owner['identity'][0]]:
            mode=option['mode']
            if mode==modes[oi]:continue
            candidate=modes.copy();candidate[oi]=mode
            if tuple(candidate) in visited:skipped.append({'owner':oi,'mode':mode,'reason':'complete_mode_vector_already_optimized_or_initial'});continue
            aa,mm=compile_modes(regions,lib,candidate,x);assert readback_compilation(aa,mm,regions,lib,candidate,x)
            value,gradient=Objective(aa,mm).evaluate(aa['initial'])
            changed={str(i):float(aa['initial'][i]) for i in range(56) if aa['initial'][i]!=x[i]};assert all(int(i)//2==oi for i in changed)
            expected.append({'sequence':len(expected),'owner':oi,'identity':owner['identity'],'mode':mode,'modes':candidate,'objective_mm2':value,'decrease_mm2':energy-value,'clamped_coordinates':changed,'dynamic_readback_passed':True})
    assert trials=={'complete':True,'evaluated':expected,'skipped':skipped,'strict_improvement_threshold_mm2':1e-6};trials_count+=len(expected)
    candidates=[t for t in expected if t['decrease_mm2']>1e-6]
    if not candidates:
        assert folder==folders[-1] and not (folder/'optimizer-opened.json').exists() and result['status']=='NO_IMPROVING_UNVISITED_MODE_VECTOR'
        reports.append({'round':len(reports),'mode_trials':len(expected),'improving_options':0,'optimizer_calls':0});continue
    selected=min(candidates,key=lambda t:(t['objective_mm2'],t['identity'][0],t['identity'][1],t['mode']))
    assert selected==load(folder/'selected-mode.json') and tuple(selected['modes']) not in visited
    aa,mm=compile_modes(regions,lib,selected['modes'],x);assert readback_compilation(aa,mm,regions,lib,selected['modes'],x)
    saved=np.load(folder/'selected-arrays.npz',allow_pickle=False)
    assert set(saved.files)==set(aa) and all(np.array_equal(saved[k],aa[k]) for k in aa) and load(folder/'selected-mapping.json')==mm
    opened_call=load(folder/'optimizer-opened.json');r=load(folder/'response.json');summary=load(folder/'result.json');obj=Objective(aa,mm)
    assert opened_call['array_sha256']==digest(folder/'selected-arrays.npz') and opened_call['modes']==selected['modes']
    assert opened_call['options']==load(BASE/'audit/optimizer-controls.json')['options'] and opened_call['maximum_calls_for_this_vector']==1 and not opened_call['retry_permitted']
    assert r['optimizer_calls']==1 and r['modes']==selected['modes'] and r['status']=='RETURNED' and r['numerical_result']['success']
    incumbents=sorted((folder/'incumbents').glob('*.json'));assert len(incumbents)==r['incumbents']
    last=float('inf');last_evaluation=-1
    for i,p in enumerate(incumbents):
        inc=load(p);point=np.array(inc['values_mm']);value,gradient=obj.evaluate(point)
        assert inc['sequence']==i and value==inc['objective_mm2']<last and np.array_equal(gradient,inc['gradient'])
        assert last_evaluation<inc['evaluation']<=r['evaluations'] and np.all(point>=aa['bounds'][:,0]) and np.all(point<=aa['bounds'][:,1])
        last=value;last_evaluation=inc['evaluation']
    assert load(incumbents[0])['objective_mm2']==selected['objective_mm2'] and load(incumbents[-1])['values_mm']==r['best_values_mm']
    assert last==r['best_objective_mm2']==summary['objective_after_optimization_mm2'] and np.array_equal(load(incumbents[-1])['gradient'],r['best_gradient'])
    x=np.array(r['best_values_mm']);modes=selected['modes'];visited.add(tuple(modes));calls+=1;incumbents_count+=len(incumbents);evaluations_count+=r['evaluations'];iterations_count+=r['numerical_result']['iterations']
    rows=load(FIRST/'fixed29.json')+load(FIRST/'short9-source.json')
    source_modes=load(I/'family-modes.json');source_owners=load(ROOT/'output/h5-cog-candidate-projections-20261107/owners.json')
    for i,owner in enumerate(source_owners):
        mode=source_modes[owner['identity'][0]][modes[i]]
        rows.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[float(x[2*i+k])+[0,2100][k]+mode['translation_from_lower_left'][k] for k in [0,1]]}})
    assert rows==load(folder/'candidate-source66.json');spec=load(FIRST/'plan.json')
    source=audit(load(JOB),rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],list(map(tuple,load(I/'inventory.json')['full66_identities'])))
    assert source==load(folder/'original-source-checks.json') and source['valid']==summary['source_valid66'] and source['pair_failures']==summary['source_pair_failures'] and source['stock_failures']==summary['source_stock_failures']
    assert source['originals']==66 and source['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026
    write(OUT/(folder.name+'-source-replay.json'),source);bad=[p for p in source['pairs'] if not p['passed']]
    collision={'pair_failures':len(bad),'positive_area_intersections':sum(p['intersection_area_mm2']>0 for p in bad),'clearance_only_failures':sum(p['intersection_area_mm2']==0 for p in bad),'summed_pairwise_intersection_area_mm2':sum(p['intersection_area_mm2'] for p in bad),'failing_pairs':bad,'scope':'Invalid candidate only; areas may double count and do not exclude a whole allocation.'}
    write(OUT/(folder.name+'-collision-details.json'),collision);last_source=source
    assert r['allocated_seconds']==opened_call['allocated_seconds'] and r['slice_overrun_seconds']==max(0.,r['returned_seconds']-r['allocated_seconds'])==0
    reports.append({'round':len(reports),'mode_trials':len(expected),'improving_options':len(candidates),'optimizer_calls':1,'incumbents':len(incumbents),'evaluations':r['evaluations'],'iterations':r['numerical_result']['iterations'],'selected':selected,'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures']})
assert calls==result['optimizer_calls']==result['source_checker_calls']==1 and trials_count==result['mode_trials']==159
assert result['final_modes']==modes and np.array_equal(result['final_values_mm'],x) and not result['source_valid66'] and last_source['pair_failures']==39 and last_source['stock_failures']==0
assert result['algorithm_seconds_including_preparation']<=process['seconds_including_preparation']<60 and result['algorithm_overrun_seconds']==0
assert process['exit_code']==job['reason_code']==job['error_code']==job['active_processes']==0 and job['closed'] and process['tree_closed'] and process['job']==job and job['peak_job_committed_memory']<2**31
charges=load(S/'preparation-charges.json');assert sum(charges.values())==plan['preparation_seconds_charged']
assert charges['complete_consumed_warm_start_process']==load(ROOT/'output/h5-cog-physical-union-distance-v2-20261107/search/process.json')['seconds_including_preparation']
assert charges['complete_new_all_mode_preparation']==load(ROOT/'output/h5-mixed-mode-union-preparation-process-20261107/prepare.json')['complete_seconds']
assert result['native_calls']==0 and not result['any_allocation_excluded'] and not result['retry_permitted']
write(OUT/'round-reconciliation.json',reports)
inputs=[Path(__file__),ROOT/'output/h5_mixed_mode_union_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,FIRST/'plan.json',FIRST/'fixed29.json',FIRST/'short9-source.json',I/'family-modes.json',I/'inventory.json',ROOT/'output/h5-cog-candidate-projections-20261107/owners.json']+[BASE/n for n in ['plan.json','library.json','regions.npz','audit/plan.json','audit/checks.json','audit/optimizer-controls.json','audit/tool-provenance.json']]+[p for p in S.rglob('*') if p.is_file()]
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in {**data.get('inputs',{}),**data.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently enumerate/recompute every legal unvisited single-owner mode trial at each actual coordinate vector, verify strict improvement and deterministic best selection, read back all serialized dynamic arrays, replay every incumbent/gradient, and independently reconstruct all66 original source poses. Reconcile process caps, all preparation charges and closure. The terminal absence of a one-owner improving move is only a local heuristic event, never a continuous or allocation exclusion.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'source_bindings':len(bindings),'closed_optimizer_calls':calls,'mode_trials_replayed':trials_count,'improving_points_replayed':incumbents_count,'optimizer_evaluations':evaluations_count,'optimizer_iterations':iterations_count,'stop':result['status'],'source_pair_failures':39,'source_stock_failures':0,'source_valid66':False,'originals':66,'same_sheet_pairs':1632,'stock_edges':264,'holes':90,'hole_vertices':10026,'preparation_seconds_charged':sum(charges.values()),'algorithm_seconds_including_preparation':result['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':process['seconds_including_preparation'],'all_descendants_closed':True,'peak_job_committed_memory':job['peak_job_committed_memory'],'any_allocation_excluded':False,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
