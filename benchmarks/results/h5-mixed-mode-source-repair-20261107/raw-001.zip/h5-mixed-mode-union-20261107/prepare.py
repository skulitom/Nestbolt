from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, time, shutil
import numpy as np
from h5_mixed_mode_union_20261107 import ROOT, BASE, I, P, V, prepare_library, load
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n')

BASE.mkdir(); start = time.perf_counter(); shutil.copyfile(__file__, BASE/'prepare.py')
assert all(load(p/'audit/checks.json')['passed'] for p in [I, P, V])
assert load(V/'response-audit/checks.json')['passed'] and not load(V/'search/result.json')['source_valid66']
arrays, library = prepare_library()
np.savez_compressed(BASE/'regions.npz', **arrays); write(BASE/'library.json', library)
files = [Path(__file__), ROOT/'output/h5_mixed_mode_union_20261107.py', ROOT/'output/h5_cog_union_distance_20261107.py', ROOT/'output/h5_cog_physical_union_distance_v2_20261107.py', ROOT/'output/h5-joint-and-union-checkpoint-20261107/next-step.json']
files += [I/n for n in ['audit/plan.json','audit/checks.json','family-modes.json','aliases.json','mode-rectangles.json','components.json','component-pairs.json','inventory.json']]
files += [P/n for n in ['audit/plan.json','audit/checks.json','owners.json','regions.json','pair-projections.json']]
files += [V/n for n in ['search/process.json','search/response.json','search/result.json','response-audit/plan.json','response-audit/checks.json']]
charge = load(V/'search/process.json')['seconds_including_preparation']
write(BASE/'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix():digest(p) for p in files},
    'method': 'All108 original legal modes, exact source-certified pair-region aliases, all four rigid rectangle separation directions, full K union -K for identical cogs. Start from the explicitly invalid corrected physical-union best candidate. A distinct mode-descent pipeline may evaluate all unvisited single-owner legal substitutions with stock clamping, choose the deterministic best strict improvement above1e-6mm2, independently read back every dynamic coupling, and call L-BFGS-B only on the changed never-optimized vector. The initial closed vector is never optimized again. Check all66 original source parts after every returned call.',
    'complete_consumed_prior_process_seconds':charge, 'algorithm_seconds':60, 'shared_seconds':90, 'source_check_reserve_seconds':4, 'memory_bytes':2**31,
    'maximum_changed_mode_calls':8, 'restarts':0, 'retry_permitted':False, 'native_requires_source_valid66':True})
write(BASE/'checks.json', {'passed':True,'seconds':time.perf_counter()-start,'owners':28,'mode_alternatives':sum(len(library['family_modes'][o['identity'][0]]) for o in library['owners']),
    'source_region_classes':len(library['groups']),'source_region_alternatives':sum(len(g['source_region_indices']) for g in library['groups']),
    'regions_sha256':digest(BASE/'regions.npz'),'library_sha256':digest(BASE/'library.json'),'optimizer_calls':0,'source_valid66':False,'H5_complete':False})
print(load(BASE/'checks.json'))
