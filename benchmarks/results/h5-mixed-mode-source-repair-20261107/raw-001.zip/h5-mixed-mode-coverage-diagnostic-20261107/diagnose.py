"""Deterministic source-vs-surrogate coverage diagnostic; no search calls."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
from h5_mixed_mode_union_20261107 import ROOT,BASE,load,Objective
OUT=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107';S=BASE/'search/round-00'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'diagnose.py');assert load(BASE/'response-audit/checks.json')['passed']
archive=np.load(S/'selected-arrays.npz',allow_pickle=False);arrays={k:archive[k] for k in archive.files};meta=load(S/'selected-mapping.json');r=load(S/'response.json');source=load(S/'original-source-checks.json');lib=load(BASE/'library.json')
lookup={tuple(sorted(map(tuple,p['keys']))):p for p in source['pairs']}
value,g,details,orth=Objective(arrays,meta).evaluate(r['best_values_mm'],True);assert value==r['best_objective_mm2']
records=[]
for group in details:
    gi=group['group']['group']
    for local,pair in enumerate(group['group']['pairs']):
        owners=arrays[f'g{gi}_owners'][local].tolist();ids=[meta['owners'][i]['identity'] for i in owners];actual=lookup[tuple(sorted(map(tuple,ids)))];region=int(group['selected_regions'][local]);distance=float(group['squared_distances'][local,region])
        records.append({'kind':'cog_pair','pair':pair,'owners':owners,'identities':ids,'source_passed':actual['passed'],'source_distance_mm':actual['distance_mm'],'source_intersection_area_mm2':actual['intersection_area_mm2'],'surrogate_squared_distance_mm2':distance,'canonical_query_mm':group['points'][local].tolist(),'nearest_certified_point_mm':group['closest'][local,region].tolist(),'source_region_index':group['group']['source_region_indices'][region],'source_region_sign':group['group']['source_region_signs'][region]})
for i,pair in enumerate(lib['component_pairs']):
    owners=pair['owners'];ids=[meta['owners'][j]['identity'] for j in owners];actual=lookup[tuple(sorted(map(tuple,ids)))]
    records.append({'kind':'orthogonal_component_pair','pair':i,'owners':owners,'components':pair['components'],'identities':ids,'source_passed':actual['passed'],'source_distance_mm':actual['distance_mm'],'source_intersection_area_mm2':actual['intersection_area_mm2'],'surrogate_squared_distance_mm2':float(orth[i]**2)})
assert abs(sum(p['surrogate_squared_distance_mm2'] for p in records)-value)<1e-8
misses=[p for p in records if p['source_passed'] and p['surrogate_squared_distance_mm2']>1e-12]
false_safe=[p for p in records if not p['source_passed'] and p['surrogate_squared_distance_mm2']<=1e-12 and p['kind']=='cog_pair']
assert not false_safe
write(OUT/'pair-diagnostic.json',records);write(OUT/'source-safe-outside-certified-union.json',misses)
inputs=[Path(__file__),ROOT/'output/h5_mixed_mode_union_20261107.py',ROOT/'output/h5_cog_physical_union_distance_v2_20261107.py',ROOT/'output/h5_cog_union_distance_20261107.py']+[BASE/n for n in ['library.json','response-audit/plan.json','response-audit/checks.json']]+[S/n for n in ['selected-arrays.npz','selected-mapping.json','response.json','original-source-checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'At the single returned invalid candidate only, reconcile every surrogate term with original-source spacing. Identify actual source-safe pairs outside the currently certified safe-region union. This is a representation-coverage diagnostic and permits no repeated solve or global exclusion. Any fresh region requires independent exact original-source certification before a changed model could be considered.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'surrogate_terms':len(records),'source_safe_positive_surrogate_terms':len(misses),'cog_coverage_misses':sum(p['kind']=='cog_pair' for p in misses),'orthogonal_positive_safe_terms':sum(p['kind']=='orthogonal_component_pair' for p in misses),'source_safe_positive_surrogate_energy_mm2':sum(p['surrogate_squared_distance_mm2'] for p in misses),'total_surrogate_energy_mm2':value,'false_safe_cog_terms':len(false_safe),'optimizer_calls':0,'source_valid66':False,'any_allocation_excluded':False})
print(load(OUT/'checks.json'))
