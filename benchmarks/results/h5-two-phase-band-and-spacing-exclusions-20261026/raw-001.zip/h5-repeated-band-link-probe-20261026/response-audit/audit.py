"""Read back the sole all-orientation call and every returned source clause."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
from datetime import datetime,timezone
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-repeated-band-link-probe-20261026';SOURCE=ROOT/'output/h5-repeated-bracket-phase-source-20261026';RUN=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify sole actual model/parameters/response, call inventory, deadline and original identities. On a positive check every returned variable and active constraint, derive all selected original profiles, then independently evaluate every full guarded pair face and exact profile stock bounds. A negative is limited to this nine-part profile-group composition/declared both declared cog angles and both insert choices, requiring at least one new-phase cog/grid and conservative source guards; UNKNOWN excludes nothing. No retry or native call.'})
for path in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];s=load(SOURCE/'plan.json');proc=load(RUN/'process.json');budget=load(RUN/'budget.json');census=load(RUN/'census.json');assert proc['exit_code']==0 and not proc['timeout'] and proc['seconds']<=60 and budget['shared_seconds']==60 and budget['deadline_perf_counter']==budget['start_perf_counter']+60 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==45 and budget['workers']==4 and budget['seed']==0
assert not census['pending_pairs'] and len(census['results'])==census['solver_calls']==len(list(RUN.rglob('opened.json')))==1
folder=RUN/'000';r=load(folder/'result.json');opened=load(folder/'opened.json');assert r==census['results'][0] and opened['maximum_calls']==r['solver_calls']==1 and opened['pair']==r['pair']==0 and r['parts']==list(range(9))
m=proto(folder/'model.pb');assert m==proto(BASE/'models/000.pb') and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=45,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'] and opened['seconds_limit']==45
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert cp_model_pb2.CpSolverStatus.Name(response.status)==r['status'] and abs(response.wall_time-r['seconds'])<.2 and r['seconds']<=r['stage_seconds'] and r['solver_soft_overshoot_seconds']==max(0,r['seconds']-45);sol=list(response.solution);positive=r['status'] in ['OPTIMAL','FEASIBLE'];variables=constraints=faces=0
if positive:
    assert len(sol)==len(m.variables) and sol[:18]==r['original_coordinates_units1000']
    for v,n in zip(m.variables,sol):assert any(lo<=n<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]));variables+=1
    def truth(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
    for c in m.constraints:
        if not all(truth(v) for v in c.enforcement_literal):continue
        if c.WhichOneof('constraint')=='linear':n=sum(sol[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=n<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        else:assert c.WhichOneof('constraint')=='bool_or' and any(truth(v) for v in c.bool_or.literals)
        constraints+=1
    flags=load(BASE/'profile-flags.json');selected=[]
    for i in range(9):
        chosen=[int(p) for p,v in flags[str(i)].items() if sol[v]];assert len(chosen)==1;selected.extend(chosen)
    assert len(selected)==9 and all(selected[i] in s["allowed_profiles"][i] for i in range(9)) and selected[5:].count(11)>=1 and sol[10:18:2]==sorted(sol[10:18:2]) and sol[4]<=sol[6]
    for i,p in enumerate(selected):
        b=s['anchor_bounds_units1000'][str(p)];x,y=sol[2*i:2*i+2];assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
    for a,b in combinations(range(9),2):
        case=next(c['index'] for c in s['mutual_cases'] if [c['profile_a'],c['profile_b']]==[selected[a],selected[b]]);dx,dy=sol[2*b]-sol[2*a],sol[2*b+1]-sol[2*a+1]
        for f in load(SOURCE/'mutual'/f'{case:03d}.json')['faces']:assert any(h['a']*dx+h['b']*dy>=h['bound'] for h in f['outside_halfplanes']);faces+=1
    cells=load(BASE/'cell-selectors.json');chosen_cells=[r for r in cells if sol[r['variable']]]
    assert len(chosen_cells)==9 and sorted(r['part'] for r in chosen_cells)==list(range(9))
    for row in chosen_cells:
        i=row['part'];assert row['profile']==selected[i] and row['y_bounds_units1000'][0]<=sol[2*i+1]<=row['y_bounds_units1000'][1]
    loads=[sum(r['demands'][j] for r in chosen_cells) for j in range(63)];caps=load(ROOT/'output/h5-mixed-cog-band-capacity-20261026/band-capacities.json');assert all(a<=b for a,b in zip(loads,caps))
    write(OUT/'verified-band-selections.json',{'cells':chosen_cells,'band_loads':loads,'capacities':caps})
    write(OUT/'verified-source-witness.json',{'parts':[{**p,'profile':selected[i],'anchor_units1000':sol[2*i:2*i+2]} for i,p in enumerate(s['parts'])],'first_sheet_pending_originals':[28,29],'full66_target_witness':False})
else:assert r['status'] in ['INFEASIBLE','UNKNOWN'] and not sol and r['original_coordinates_units1000'] is None
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':1,'status':r['status'],'source_witness':positive,'solver_seconds':r['seconds'],'shared_seconds':proc['seconds'],'shared_budget_honored':True,'soft_overrun_seconds':r['solver_soft_overshoot_seconds'],'positive_variables_checked':variables,'positive_active_constraints_checked':constraints,'positive_full_guarded_faces_checked':faces,'all66_identity_obligations_preserved':True,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
