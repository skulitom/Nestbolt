"""Independently verify complete original-Y cell channeling and every band coefficient."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-repeated-band-link-probe-20261026';PARENT=ROOT/'output/h5-repeated-bracket-phase-base-20261026';SOURCE=ROOT/'output/h5-repeated-bracket-phase-source-20261026';DATA=ROOT/'output/h5-mixed-cog-band-capacity-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Restore the entire parent proto exactly, with its complete144 source modes, choices and valid cog symmetry. For every one of18 part/profile choices independently reconstruct the complete ordered cell cover against original stock-Y domains and exact audited coefficients. Reconstruct all916 Boolean variables and Y implications,18 sum-to-profile equalities and63 area inequalities. Verify exact selector records, all copied source mappings, no additional fields/hints and actual solver import/export. Prove each parent source-coordinate witness extends uniquely to the selected integer-Y cells and respects floored occupied-band capacity; no existing cell is locked. No solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for p in [PARENT/'model-audit/checks.json',SOURCE/'audit/checks.json',DATA/'audit/checks.json']:assert load(p)['passed']
assert not (PARENT/'search').exists()
m=proto(BASE/'models/000.pb');parent=proto(PARENT/'models/000.pb');assert (len(parent.variables),len(parent.constraints))==(31892,32746)
restored=cp_model_pb2.CpModelProto();restored.CopyFrom(m);del restored.variables[31892:];del restored.constraints[32746:];assert restored==parent
for n in ['models/000-mapping.json','profile-flags.json','shared-planes.json']:assert (BASE/n).read_bytes()==(PARENT/n).read_bytes()
s=load(SOURCE/'plan.json');flags=load(BASE/'profile-flags.json');vi,ci=31892,32746;selectors=[];groups=[];covered_values=0
for part,options in enumerate(s['allowed_profiles']):
    for pi in options:
        data=load(DATA/'profiles'/f'{pi:03d}.json');lo,hi=s['anchor_bounds_units1000'][str(pi)][1::2];assert data['y_bounds_units1000']==[lo,hi];following=lo;ids=[]
        for ordinal,cell in enumerate(data['cells']):
            a,b=cell['y_bounds_units1000'];assert cell['index']==ordinal and a==following and b==min(a+999,hi);following=b+1;covered_values+=b-a+1
            assert m.variables[vi]==cp_model_pb2.IntegerVariableProto(name=f'p{part}-profile{pi}-cell{ordinal}',domain=[0,1])
            c=cp_model_pb2.ConstraintProto();c.enforcement_literal.append(vi);c.linear.vars.append(2*part+1);c.linear.coeffs.append(1);c.linear.domain.extend([a,b]);assert c==m.constraints[ci];ci+=1;ids.append(vi)
            selectors.append({'variable':vi,'part':part,'profile':pi,'cell':ordinal,'y_bounds_units1000':[a,b],'demands':cell['band_lower_area_units']});vi+=1
        assert following==hi+1;groups.append({'part':part,'profile':pi,'profile_flag':flags[str(part)][str(pi)],'cell_flags':ids})
for group in groups:
    c=cp_model_pb2.ConstraintProto();c.linear.vars.extend([group['profile_flag']]+group['cell_flags']);c.linear.coeffs.extend([-1]+[1]*len(group['cell_flags']));c.linear.domain.extend([0,0]);assert c==m.constraints[ci];ci+=1
caps=load(DATA/'band-capacities.json');assert len(caps)==63
for band,capacity in enumerate(caps):
    rows=[r for r in selectors if r['demands'][band]>0];c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(r['variable'] for r in rows);c.linear.coeffs.extend(r['demands'][band] for r in rows);c.linear.domain.extend([-2**63,capacity]);assert c==m.constraints[ci];ci+=1
assert vi==len(m.variables)==32808 and ci==len(m.constraints)==33743 and len(selectors)==916 and len(groups)==18
assert selectors==load(BASE/'cell-selectors.json') and groups==load(BASE/'cell-groups.json')
r=load(BASE/'inventory.json')[0];old=load(PARENT/'inventory.json')[0];expected={**old,'variables':32808,'constraints':33743,'model_sha256':digest(BASE/'models/000.pb'),'added_cell_selectors':916,'added_y_interval_implications':916,'added_profile_cell_equalities':18,'added_band_inequalities':63};assert r==expected
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'extension-proof.json',{'statement':'For each parent placement the exact-one profile flags choose one original shape, whose integer Y lies in its complete disjoint cell cover. Set its unique cell flag to1 and every other cell flag to0. Profile sums and Y implications hold. Every source pair clause prevents overlap of the original filled outer profiles and the stock domains place them inside the stock. Each occupied horizontal band area is at least the independently audited lower area of its selected cell. Summing their floored area units cannot exceed the floored stock capacity. Hence all63 added band inequalities are necessary, every parent source-coordinate witness extends, and no original coordinate/profile choice is fixed by the construction. Projection of any new witness satisfies the unchanged parent.','equivalent_source_coordinate_feasibility':True,'no_conditional_profile_exclusions_transferred':True,'no_full_layout_claim':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':vi,'constraints':ci,'exact_parent_restoration_verified':True,'physical_modes_preserved':144,'cell_selectors_checked':916,'profile_cell_equalities_checked':18,'complete_profile_y_values_covered':covered_values,'band_inequalities_checked':63,'cell_band_coefficients_checked':916*63,'all_original_coordinate_choices_preserved':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
