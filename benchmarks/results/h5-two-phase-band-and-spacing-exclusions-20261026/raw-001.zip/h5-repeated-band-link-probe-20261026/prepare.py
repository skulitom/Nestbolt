"""Add complete vertical-cell channeling and exact necessary band bounds to the source model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-repeated-bracket-phase-base-20261026';SOURCE=ROOT/'output/h5-repeated-bracket-phase-source-20261026';DATA=ROOT/'output/h5-mixed-cog-band-capacity-20261026';OUT=ROOT/'output/h5-repeated-band-link-probe-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(PARENT/'model-audit/checks.json')['passed'] and not (PARENT/'search').exists()
assert load(DATA/'audit/checks.json')['passed'];s=load(SOURCE/'plan.json');allowed=s['allowed_profiles'];flags=load(PARENT/'profile-flags.json');m=cp_model_pb2.CpModelProto();m.ParseFromString((PARENT/'models/000.pb').read_bytes());nv,nc=len(m.variables),len(m.constraints);assert (nv,nc)==(31892,32746)
paths=[PARENT/n for n in ['plan.json','models/000.pb','models/000-mapping.json','profile-flags.json','shared-planes.json','inventory.json','model-audit/checks.json']]+[SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',DATA/'plan.json',DATA/'band-capacities.json',DATA/'audit/checks.json']+list((DATA/'profiles').glob('*.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'parent_variables':nv,'parent_constraints':nc,'maximum_calls':1,'solver_seconds':45,'shared_seconds':60,'workers':4,'seed':0,'method':'Preserve every field of the audited, uncalled31892-variable/32746-constraint144-mode source model. Add one Boolean per physical part/allowed profile/complete vertical cell, with its full Y interval enforced when selected. For each part/profile, equate its cell-selector sum to the existing profile flag. This channels every permitted integer Y value; no selected capacity cell is fixed or preferred. Add all63 exact rationally audited lower-area inequalities for actual cell selections. Any parent source witness extends uniquely to cells and satisfies the valid filled-outer band capacities, so no valid source-coordinate witness is lost. No prior conditional count exclusion is copied, no original is optional, no objective/hint added. Independently audit cell coverage, channeling, every coefficient, exact parent restoration and real import before one newly declared45solver/60shared4worker seed0 call. This is the first and only call for the repeated-bracket two-phase family; the base is never called.'})
selectors=[];groups=[]
for i,options in enumerate(allowed):
    for pi in options:
        data=load(DATA/'profiles'/f'{pi:03d}.json');ids=[]
        for cell in data['cells']:
            var=len(m.variables);m.variables.add(name=f'p{i}-profile{pi}-cell{cell["index"]}',domain=[0,1]);c=m.constraints.add();c.enforcement_literal.append(var);c.linear.vars.append(2*i+1);c.linear.coeffs.append(1);c.linear.domain.extend(cell['y_bounds_units1000']);ids.append(var)
            selectors.append({'variable':var,'part':i,'profile':pi,'cell':cell['index'],'y_bounds_units1000':cell['y_bounds_units1000'],'demands':cell['band_lower_area_units']})
        groups.append({'part':i,'profile':pi,'profile_flag':flags[str(i)][str(pi)],'cell_flags':ids})
for group in groups:
    c=m.constraints.add();c.linear.vars.extend([group['profile_flag']]+group['cell_flags']);c.linear.coeffs.extend([-1]+[1]*len(group['cell_flags']));c.linear.domain.extend([0,0])
for band,cap in enumerate(load(DATA/'band-capacities.json')):
    c=m.constraints.add();rows=[r for r in selectors if r['demands'][band]];c.linear.vars.extend(r['variable'] for r in rows);c.linear.coeffs.extend(r['demands'][band] for r in rows);c.linear.domain.extend([-2**63,cap])
assert len(selectors)==916 and len(groups)==18 and len(m.variables)==32808 and len(m.constraints)==33743
for n in ['models/000-mapping.json','profile-flags.json','shared-planes.json']:shutil.copyfile(PARENT/n,OUT/n)
write(OUT/'cell-selectors.json',selectors);write(OUT/'cell-groups.json',groups)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
row={**load(PARENT/'inventory.json')[0],'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(p),'added_cell_selectors':len(selectors),'added_y_interval_implications':len(selectors),'added_profile_cell_equalities':len(groups),'added_band_inequalities':63};write(OUT/'inventory.json',[row]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**row,'solver_calls':0});print(load(OUT/'prepared.json'))
