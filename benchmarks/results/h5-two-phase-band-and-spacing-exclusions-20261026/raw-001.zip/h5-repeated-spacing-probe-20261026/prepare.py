"""Expose independently proved cog spacing as linear propagation bounds."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-repeated-band-link-probe-20261026';BOUNDS=ROOT/'output/h5-cog-spacing-bounds-20261026';OUT=ROOT/'output/h5-repeated-spacing-probe-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'] and load(PARENT/'search/000/result.json')['status']=='UNKNOWN' and load(BOUNDS/'audit/checks.json')['passed']
paths=[PARENT/n for n in ['plan.json','models/000.pb','inventory.json','profile-flags.json','cell-selectors.json','cell-groups.json','model-audit/checks.json','response-audit/checks.json','search/000/model.pb','search/000/response.pb','search/000/result.json']]+[BOUNDS/'plan.json',BOUNDS/'bounds.json',BOUNDS/'audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'maximum_calls':1,'solver_seconds':45,'shared_seconds':60,'workers':4,'seed':0,'method':'Preserve the full closed32808-variable/33743-constraint repeated-bracket source plus band model. Add30 valid linear cog-spacing bounds: six unconditional pair bounds at the minimum over all four phase choices, plus24 exact phase-pair bounds enforced by their two original choice flags. The full-height forbidden-rectangle audit proves each threshold for every stock-allowed relative Y. Existing global cog x ordering makes each deltaX nonnegative; original integer coordinates then imply the stated lower bound. No variable, source clause, cell channel or choice is removed, and no original is omitted. Independent exact parent restoration, symmetry/stock/phase-domain proof and real import precede one new45solver/60shared4worker seed0 call. Earlier UNKNOWN is preserved, not treated as an exclusion.'})
m=cp_model_pb2.CpModelProto();m.ParseFromString((PARENT/'models/000.pb').read_bytes());assert (len(m.variables),len(m.constraints))==(32808,33743)
flags=load(PARENT/'profile-flags.json');rows=load(BOUNDS/'bounds.json');bounds={tuple(r['profiles']):r['minimum_integer_dx_units1000'] for r in rows};common=min(bounds.values());added=[]
for a,b in combinations(range(5,9),2):
    for profiles,minimum in [(None,common)]+[(list(key),bounds[key]) for key in product([9,11],repeat=2)]:
        c=m.constraints.add();c.linear.vars.extend([2*a,2*b]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([minimum,2**63-1])
        if profiles:c.enforcement_literal.extend([flags[str(a)][str(profiles[0])],flags[str(b)][str(profiles[1])]])
        added.append({'parts':[a,b],'profiles':profiles,'minimum_dx_units1000':minimum})
assert len(m.constraints)==33773 and len(added)==30
for n in ['models/000-mapping.json','profile-flags.json','shared-planes.json','cell-selectors.json','cell-groups.json']:shutil.copyfile(PARENT/n,OUT/n)
write(OUT/'spacing-constraints.json',added);p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
row={**load(PARENT/'inventory.json')[0],'constraints':len(m.constraints),'model_sha256':digest(p),'added_spacing_constraints':30};write(OUT/'inventory.json',[row]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**row,'solver_calls':0});print(load(OUT/'prepared.json'))
