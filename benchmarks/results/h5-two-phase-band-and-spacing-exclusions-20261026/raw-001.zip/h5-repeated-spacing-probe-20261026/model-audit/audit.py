"""Independently reconstruct all valid spacing implications and the unchanged source parent."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-repeated-spacing-probe-20261026';PARENT=ROOT/'output/h5-repeated-band-link-probe-20261026';SOURCE=ROOT/'output/h5-repeated-bracket-phase-source-20261026';BOUNDS=ROOT/'output/h5-cog-spacing-bounds-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Check the independently reconstructed full forbidden rectangles, exact phase stock-Y intervals, and the unchanged parent global cog x-order constraints. Restore the entire parent proto and all auxiliary source/cell mappings exactly. For each of six cog pairs rebuild one minimum-over-phases linear bound and four bounds enforced by the actual profile-choice flags. Verify every threshold and literal, whole proto fields, inventory and actual solver import/export. Existing exact-one phase choices and full-height rectangle containment make every added bound necessary. No solve and no dropped source face.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'] and load(BOUNDS/'audit/checks.json')['passed']
assert load(PARENT/'search/000/result.json')['status']=='UNKNOWN'
s=load(SOURCE/'plan.json');assert s['allowed_profiles'][5:]==[[9,11]]*4;m=proto(BASE/'models/000.pb');parent=proto(PARENT/'models/000.pb');assert len(m.variables)==32808 and len(m.constraints)==33773
restored=cp_model_pb2.CpModelProto();restored.CopyFrom(m);del restored.constraints[33743:];assert restored==parent
for n in ['models/000-mapping.json','profile-flags.json','shared-planes.json','cell-selectors.json','cell-groups.json']:assert (BASE/n).read_bytes()==(PARENT/n).read_bytes()
for i in range(5,8):
    c=cp_model_pb2.ConstraintProto();c.linear.vars.extend([2*i,2*(i+1)]);c.linear.coeffs.extend([1,-1]);c.linear.domain.extend([-2**63,0]);assert c==parent.constraints[45+i-5]
flags=load(BASE/'profile-flags.json');rows=load(BOUNDS/'bounds.json');lookup={tuple(r['profiles']):r for r in rows};assert set(lookup)==set(product([9,11],repeat=2));minimum=min(r['minimum_integer_dx_units1000'] for r in rows)
for pa,pb in lookup:
    row=lookup[pa,pb];a,b=s['anchor_bounds_units1000'][str(pa)],s['anchor_bounds_units1000'][str(pb)];assert row['relative_y_bounds_units1000']==[b[1]-a[3],b[3]-a[1]] and row['rectangle_boundary_gap_mm']>1e-8
ci=33743;expected=[]
for a,b in combinations(range(5,9),2):
    for profiles,threshold in [(None,minimum)]+[(list(key),lookup[key]['minimum_integer_dx_units1000']) for key in product([9,11],repeat=2)]:
        c=cp_model_pb2.ConstraintProto();c.linear.vars.extend([2*a,2*b]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([threshold,2**63-1])
        if profiles:c.enforcement_literal.extend([flags[str(a)][str(profiles[0])],flags[str(b)][str(profiles[1])]])
        assert c==m.constraints[ci];ci+=1;expected.append({'parts':[a,b],'profiles':profiles,'minimum_dx_units1000':threshold})
assert ci==33773 and expected==load(BASE/'spacing-constraints.json')
row=load(BASE/'inventory.json')[0];assert row=={**load(PARENT/'inventory.json')[0],'constraints':33773,'model_sha256':digest(BASE/'models/000.pb'),'added_spacing_constraints':30}
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'implication.json',{'statement':'Existing cog x ordering gives deltaX>=0 for every ordered physical cog pair. Its two exact-one phase choices and stock bounds select a certified full relative-Y interval. If integer deltaX<D, then deltaX<=D-1, placing the difference vector in the rectangle strictly contained in the source forbidden envelope. Complete source face coverage rules this out. Thus the phase-specific lower bound is necessary; minimizing over all four exhaustive phase pairs gives the unconditional bound. Adding these linear implications preserves every parent source-coordinate witness.','all_parent_coordinates_and_choices_preserved':True,'no_inference_from_UNKNOWN':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':32808,'constraints':33773,'exact_parent_restoration_verified':True,'full_y_phase_cases_verified':4,'physical_cog_pairs_checked':6,'unconditional_spacing_bounds_checked':6,'conditional_spacing_bounds_checked':24,'cog_order_constraints_verified':3,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
