from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('run_h5_repeated_band_link_probe.py','run_h5_repeated_spacing_probe.py'),('audit_h5_repeated_band_link_response.py','audit_h5_repeated_spacing_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-repeated-band-link-probe-20261026','h5-repeated-spacing-probe-20261026')
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
