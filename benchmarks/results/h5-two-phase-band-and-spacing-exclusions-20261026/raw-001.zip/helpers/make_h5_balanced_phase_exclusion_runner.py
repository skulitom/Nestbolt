from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('run_h5_mixed_cog_exclusion_master.py','run_h5_balanced_phase_exclusion_master.py'),('audit_h5_mixed_cog_exclusion_response.py','audit_h5_balanced_phase_exclusion_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-mixed-cog-exclusion-master-20261026','h5-balanced-phase-exclusion-master-20261026').replace('h5-mixed-cog-exclusion-search-20261026','h5-balanced-phase-exclusion-search-20261026').replace('714-variable/78-constraint','718-variable/87-constraint').replace('all714 variable domains and78 constraints','all718 variable domains and87 constraints').replace('len(sol)==714','len(sol)==718')
    if src.startswith('audit'):
        old="assert totals[11]>=1 and (totals[0]+totals[4],totals[2]+totals[6],totals[3]+totals[5],totals[10],totals[11])!=(1,1,2,1,2);";assert old in s;s=s.replace(old,old+"assert (totals[0]+totals[4],totals[2]+totals[6],totals[1]+totals[7],totals[3]+totals[5])!=(1,1,1,1);")
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
