"""Broaden the remaining repeated-bracket family before any coordinate solve."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('build_h5_balanced_phase_choice_strip.py','build_h5_repeated_bracket_phase_strip.py'),('audit_h5_balanced_phase_choice_geometry.py','audit_h5_repeated_bracket_phase_geometry.py'),('prepare_h5_balanced_phase_choice_model.py','prepare_h5_repeated_bracket_phase_model.py'),('audit_h5_balanced_phase_choice_model.py','audit_h5_repeated_bracket_phase_model.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-balanced-phase-choice-source-20261026','h5-repeated-bracket-phase-source-20261026').replace('h5-balanced-phase-choice-probe-20261026','h5-repeated-bracket-phase-base-20261026')
    s=s.replace('[[0,4],[2,6],[1,7],[3,5],[8,10],[9,11],[9,11],[9,11],[9,11]]','[[0,4],[2,6],[3,5],[3,5],[8,10],[9,11],[9,11],[9,11],[9,11]]')
    if src.startswith('build'):
        s=s.replace('len(keys)==64','len(keys)==48').replace("'pair_cases':64","'pair_cases':48").replace('all64 cases','all48 cases')
        old="ROOT/'output/h5-three-one-cog-strip-source-20261026']:";assert old in s;s=s.replace(old,"ROOT/'output/h5-three-one-cog-strip-source-20261026',ROOT/'output/h5-balanced-phase-choice-source-20261026']:")
        s=s.replace('h5-mixed-cog-exclusion-search-20261026','h5-balanced-phase-exclusion-search-20261026')
        old='(totals[0]+totals[4],totals[2]+totals[6],totals[1]+totals[7],totals[3]+totals[5],totals[8],totals[9],totals[11])==(1,1,1,1,1,3,1)';new='(totals[0]+totals[4],totals[2]+totals[6],totals[3]+totals[5],totals[10],totals[9],totals[11])==(1,1,2,1,3,1)';assert old in s;s=s.replace(old,new)
        old="[{'profiles':[0,4],'count':1},{'profiles':[2,6],'count':1},{'profiles':[1,7],'count':1},{'profiles':[3,5],'count':1},{'profiles':[8,10],'count':1},{'profiles':[9,11],'count':4}]";new="[{'profiles':[0,4],'count':1},{'profiles':[2,6],'count':1},{'profiles':[3,5],'count':2},{'profiles':[8,10],'count':1},{'profiles':[9,11],'count':4}]";assert old in s;s=s.replace(old,new)
        s=s.replace('one bracket each from0/4,2/6,1/7,3/5.','one bracket from0/4, one from2/6 and two from3/5.')
        s=s.replace('An unfactored model may be prepared/audited but remains uncalled; share identical plane literals before the one45second4worker seed0 call within60shared seconds.','Prepare and audit the shared-plane base without calling it, then add independently audited complete vertical-cell channeling and all63 band inequalities before the only45second4worker seed0 call within60shared seconds.')
    elif 'geometry' in src:
        s=s.replace('len(needed)==64','len(needed)==48').replace("'h5-mixed-cog-exclusion-search']","'h5-balanced-phase-choice-source','h5-balanced-phase-exclusion-search']")
    elif src.startswith('prepare'):
        old='linear({flags[i][11]:1 for i in range(5,9)},1,4)';assert old in s;s=s.replace(old,old+'\nlinear({4:1,6:-1},-2**63,0)')
        s=s.replace('len(m.constraints)==49','len(m.constraints)==50').replace('Distinct bracket type slots are unordered.','Only the two bracket slots2/3 with identical allowed3/5 choices are x-ordered together with their profile choices; other bracket types are unordered.')
        s=s.replace('make49 base constraints.','plus one repeated-bracket x order make50 base constraints.').replace('No unfactored source call','The audited base is not called; complete band constraints are added before the sole search. No unfactored source call')
    elif 'model' in src:
        old='linear({flags[i][11]:1 for i in range(5,9)},1,4)';assert old in s;s=s.replace(old,old+'\nassert allowed[2]==allowed[3]==[3,5];linear({4:1,6:-1},-2**63,0)')
        s=s.replace('vi==36 and ci==49','vi==36 and ci==50').replace('Distinct bracket type slots are unordered.','Only repeated bracket slots2/3 have an x order; relabel their profile choices with the identical copies, with no separate profile order.')
        old='assert symmetry_cases==360';new="""assert symmetry_cases==360
bracket_order_cases=0
for chosen in product([3,5],repeat=2):
    for ranks in permutations(range(2)):
        order=sorted(range(2),key=lambda i:ranks[i]);assigned=[chosen[i] for i in order]
        assert sorted(assigned)==sorted(chosen) and all(p in allowed[2+i] for i,p in enumerate(assigned));bracket_order_cases+=1
assert bracket_order_cases==8""";assert old in s;s=s.replace(old,new)
        s=s.replace("'cog_phase_order_cases_checked':symmetry_cases","'repeated_bracket_order_cases_checked':bracket_order_cases,'cog_phase_order_cases_checked':symmetry_cases")
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
