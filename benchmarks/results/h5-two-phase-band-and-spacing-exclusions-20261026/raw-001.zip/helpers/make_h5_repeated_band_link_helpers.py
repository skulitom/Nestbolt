"""Add full area channeling to the audited, uncalled repeated-bracket base."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('prepare_h5_balanced_band_link_model.py','prepare_h5_repeated_band_link_model.py'),('audit_h5_balanced_band_link_model.py','audit_h5_repeated_band_link_model.py'),('run_h5_balanced_band_link_probe.py','run_h5_repeated_band_link_probe.py'),('audit_h5_balanced_band_link_response.py','audit_h5_repeated_band_link_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-balanced-phase-choice-probe-20261026','h5-repeated-bracket-phase-base-20261026').replace('h5-balanced-phase-choice-source-20261026','h5-repeated-bracket-phase-source-20261026').replace('h5-balanced-band-link-probe-20261026','h5-repeated-band-link-probe-20261026')
    for a,b in [('31797','31892'),('32646','32746'),('32713','32808'),('33643','33743')]:s=s.replace(a,b)
    if src.startswith('prepare'):
        old="assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'] and load(PARENT/'search/000/result.json')['status']=='UNKNOWN'";assert old in s;s=s.replace(old,"assert load(PARENT/'model-audit/checks.json')['passed'] and not (PARENT/'search').exists()")
        old=",'response-audit/checks.json','search/000/model.pb','search/000/response.pb','search/000/result.json'";assert old in s;s=s.replace(old,'')
        s=s.replace('of the closed31892-variable/32746-constraint144-mode source model','of the audited, uncalled31892-variable/32746-constraint144-mode source model').replace('The previous UNKNOWN remains closed and proves no exclusion.','This is the first and only call for the repeated-bracket two-phase family; the base is never called.')
    elif src.endswith('link_model.py'):
        old=",PARENT/'response-audit/checks.json'";assert old in s;s=s.replace(old,'')
        old="assert load(PARENT/'search/000/result.json')['status']=='UNKNOWN'";assert old in s;s=s.replace(old,"assert not (PARENT/'search').exists()")
    elif 'response' in src:
        old='and sol[10:18:2]==sorted(sol[10:18:2])';assert old in s;s=s.replace(old,old+' and sol[4]<=sol[6]')
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
