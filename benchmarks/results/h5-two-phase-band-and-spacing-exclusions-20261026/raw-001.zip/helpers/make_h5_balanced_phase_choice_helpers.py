"""Broaden balanced brackets to both insert orientations and independent cog phase choices."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('build_h5_three_one_cog_strip.py','build_h5_balanced_phase_choice_strip.py'),('audit_h5_three_one_cog_geometry.py','audit_h5_balanced_phase_choice_geometry.py'),('prepare_h5_three_one_cog_shared_model.py','prepare_h5_balanced_phase_choice_model.py'),('audit_h5_three_one_cog_shared_model.py','audit_h5_balanced_phase_choice_model.py'),('run_h5_three_one_cog_probe.py','run_h5_balanced_phase_choice_probe.py'),('audit_h5_three_one_cog_response.py','audit_h5_balanced_phase_choice_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-three-one-cog-strip-source-20261026','h5-balanced-phase-choice-source-20261026').replace('h5-three-one-cog-shared-probe-20261026','h5-balanced-phase-choice-probe-20261026')
    old_allowed='[[0,4],[2,6],[1,7],[3,5],[8],[9],[9],[9],[11]]';new_allowed='[[0,4],[2,6],[1,7],[3,5],[8,10],[9,11],[9,11],[9,11],[9,11]]';s=s.replace(old_allowed,new_allowed)
    s=s.replace('all74','all144').replace('all 74','all 144').replace('one of74','one of144').replace('pairs and74','pairs and144').replace('==74','==144').replace("'physical_orientation_modes':74","'physical_orientation_modes':144").replace("'orientation_pair_modes':74","'orientation_pair_modes':144").replace("'physical_modes_checked':74","'physical_modes_checked':144")
    if src.startswith('build'):
        s=s.replace('len(keys)==52','len(keys)==64').replace("'pair_cases':52","'pair_cases':64").replace('all52 cases','all64 cases')
        old="ROOT/'output/h5-mixed-cog-group-strip-source-20261026']:";assert old in s
        s=s.replace(old,"ROOT/'output/h5-mixed-cog-group-strip-source-20261026',ROOT/'output/h5-balanced-horizontal-strip-source-20261026',ROOT/'output/h5-three-one-cog-strip-source-20261026']:")
        old="[{'profiles':[0,4],'count':1},{'profiles':[2,6],'count':1},{'profiles':[1,7],'count':1},{'profiles':[3,5],'count':1},{'profiles':[8],'count':1},{'profiles':[9],'count':3},{'profiles':[11],'count':1}]"
        new="[{'profiles':[0,4],'count':1},{'profiles':[2,6],'count':1},{'profiles':[1,7],'count':1},{'profiles':[3,5],'count':1},{'profiles':[8,10],'count':1},{'profiles':[9,11],'count':4}],'minimum_new_phase_cogs':1";assert old in s;s=s.replace(old,new)
        s=s.replace('Insert8, three56.25degree cogs9 and one65.25degree cog11 remain.','The insert chooses8/10 and every cog independently chooses56.25degree9 or65.25degree11, with at least one11.').replace('three/one cog-angle counts','two allowed cog angles with at least one new-phase cog')
    elif 'geometry' in src:
        s=s.replace('len(needed)==52','len(needed)==64')
        s=s.replace("'h5-aligned-profile-family-exclusions-20261026']","'h5-aligned-profile-family-exclusions-20261026','h5-mixed-cog-rotations-and-capacity-20261026']")
        old="assert spec['allowed_profiles']==";assert old in s
        s=s.replace(old,"assert spec['minimum_new_phase_cogs']==1;assert spec['allowed_profiles']==")
    elif src.startswith('prepare'):
        s=s.replace('for i in range(4):','for i in range(9):')
        s=s.replace('for i in [5,6]:linear','for i in range(5,8):linear')
        old='assert len(m.variables)==26 and len(m.constraints)==22';new="linear({flags[i][11]:1 for i in range(5,9)},1,4)\nassert len(m.variables)==36 and len(m.constraints)==49";assert old in s;s=s.replace(old,new)
        s=s.replace('active=([flags[a][pa]] if a<4 else [])+([flags[b][pb]] if b<4 else [])','active=[flags[a][pa],flags[b][pb]]')
        s=s.replace('18 original coordinates,8 exact-one bracket choice flags','18 original coordinates and18 profile flags, with nine exact-one choices')
        s=s.replace('Distinct bracket type slots are unordered; x-order only the three identical profile9 cog copies5/6/7, with no order relative to the profile11 cog8.','Distinct bracket type slots are unordered. All four cog copies have identical allowed9/11 choices and may be globally x-ordered by relabelling copies together with their chosen profiles. Require at least one11; do not order their profiles. Nine exact-one constraints,36 conditional stock bounds, three cog x orders and one phase count make49 base constraints.')
    elif src.endswith('shared_model.py'):
        s=s.replace('from itertools import combinations,product','from itertools import combinations,product,permutations')
        s=s.replace('for i in range(4):','for i in range(9):').replace('for i in [5,6]:linear','for i in range(5,8):linear')
        old='assert vi==26 and ci==22;';new="linear({flags[i][11]:1 for i in range(5,9)},1,4)\nassert vi==36 and ci==49;";assert old in s;s=s.replace(old,new)
        s=s.replace('active=([flags[a][pa]] if a<4 else [])+([flags[b][pb]] if b<4 else [])','active=[flags[a][pa],flags[b][pb]]')
        s=s.replace('Distinct bracket type slots are unordered. Only the three identical profile9 cog copies are x-ordered; never order relative to profile11.','Distinct bracket type slots are unordered. All four cog copies have identical allowed9/11 choices, so x sorting relabels their phase choices too. Verify all360 phase/order combinations with at least one11, without a separate phase order; reconstruct the at-least-one11 constraint.')
        old="write(OUT/'checks.json',";new="""assert allowed[5:]==[[9,11]]*4 and s['minimum_new_phase_cogs']==1
symmetry_cases=0
for chosen in product([9,11],repeat=4):
    if 11 not in chosen:continue
    for ranks in permutations(range(4)):
        order=sorted(range(4),key=lambda i:ranks[i]);assigned=[chosen[i] for i in order]
        assert sorted(ranks[i] for i in order)==list(range(4)) and sorted(assigned)==sorted(chosen) and all(p in allowed[5+i] for i,p in enumerate(assigned));symmetry_cases+=1
assert symmetry_cases==360
write(OUT/'cog-order-proof.json',{'cases_checked':symmetry_cases,'statement':'All four original cog copies have identical allowed choices and identical stock bounds for each choice. Sort by x and relabel each copy together with its chosen phase. Exact-one, at-least-one11, stock and every physical pair mode remain represented. No separate phase ordering is added.'})
write(OUT/'checks.json',""";assert old in s;s=s.replace(old,new)
        s=s.replace("'actual_import_export_verified':True","'cog_phase_order_cases_checked':symmetry_cases,'actual_import_export_verified':True")
    elif 'response' in src:
        s=s.replace('for i in range(4):','for i in range(9):')
        old='selected.extend([8,9,9,9,11]);assert all(selected[i] in s["allowed_profiles"][i] for i in range(9)) and sol[10:16:2]==sorted(sol[10:16:2])';new='assert len(selected)==9 and all(selected[i] in s["allowed_profiles"][i] for i in range(9)) and selected[5:].count(11)>=1 and sol[10:18:2]==sorted(sol[10:18:2])';assert old in s;s=s.replace(old,new).replace('three/one cog-angle counts','both declared cog angles and both insert choices, requiring at least one new-phase cog')
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
