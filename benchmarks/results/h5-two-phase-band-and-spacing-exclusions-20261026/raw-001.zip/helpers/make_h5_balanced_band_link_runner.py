from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('run_h5_balanced_phase_choice_probe.py','run_h5_balanced_band_link_probe.py'),('audit_h5_balanced_phase_choice_response.py','audit_h5_balanced_band_link_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-balanced-phase-choice-probe-20261026','h5-balanced-band-link-probe-20261026')
    if 'response' in src:
        old="write(OUT/'verified-source-witness.json',";assert old in s
        new="""cells=load(BASE/'cell-selectors.json');chosen_cells=[r for r in cells if sol[r['variable']]]
    assert len(chosen_cells)==9 and sorted(r['part'] for r in chosen_cells)==list(range(9))
    for row in chosen_cells:
        i=row['part'];assert row['profile']==selected[i] and row['y_bounds_units1000'][0]<=sol[2*i+1]<=row['y_bounds_units1000'][1]
    loads=[sum(r['demands'][j] for r in chosen_cells) for j in range(63)];caps=load(ROOT/'output/h5-mixed-cog-band-capacity-20261026/band-capacities.json');assert all(a<=b for a,b in zip(loads,caps))
    write(OUT/'verified-band-selections.json',{'cells':chosen_cells,'band_loads':loads,'capacities':caps})
    write(OUT/'verified-source-witness.json',"""
        s=s.replace(old,new)
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
