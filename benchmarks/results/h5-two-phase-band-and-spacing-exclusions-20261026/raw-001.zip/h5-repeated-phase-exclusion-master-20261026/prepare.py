"""Exclude balanced bracket counts using the complete two-phase, two-insert source negative."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-balanced-phase-exclusion-master-20261026';SOURCE=ROOT/'output/h5-repeated-bracket-phase-source-20261026';PROBE=ROOT/'output/h5-repeated-spacing-probe-20261026';OUT=ROOT/'output/h5-repeated-phase-exclusion-master-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(PARENT/'audit/checks.json')['passed'] and load(PROBE/'response-audit/checks.json')['passed'] and load(PROBE/'search/000/result.json')['status']=='INFEASIBLE'
m=cp_model_pb2.CpModelProto();m.ParseFromString((PARENT/'model.pb').read_bytes());assert len(m.variables)==718 and len(m.constraints)==87;mapping=load(PARENT/'mapping.json');groups=[[0,4],[2,6],[3,5]]
paths=[PARENT/'model.pb',PARENT/'mapping.json',PARENT/'audit/checks.json',SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',PROBE/'models/000.pb',PROBE/'models/000-mapping.json',PROBE/'model-audit/checks.json',PROBE/'model-audit/implication.json',ROOT/'output/h5-repeated-band-link-probe-20261026/model-audit/extension-proof.json',PROBE/'response-audit/checks.json',PROBE/'search/000/model.pb',PROBE/'search/000/response.pb',PROBE/'search/000/result.json',ROOT/'output/h5-repeated-bracket-phase-base-20261026/model-audit/checks.json',ROOT/'output/h5-repeated-bracket-phase-base-20261026/model-audit/cog-order-proof.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'excluded_group_counts':[{'profiles':g,'count':n} for g,n in zip(groups,[1,1,2])],'method':'Preserve the entire718/87 mixed-angle master. Add three exact count-equality reifications and a not-all clause for counts(p0+p4,p2+p6,p3+p5)=(1,1,2). Both insert orientations and all cog9/11 counts with at least one11 are covered by the new144-mode full-coordinate negative. Its complete vertical-cell area bounds and certified full-height cog-spacing bounds preserve parent source-coordinate feasibility. The two repeated bracket slots can be x-sorted together with their chosen3/5 profiles. Identical cogs can be globally x-sorted with their selected phase choices because every slot allows9/11; no separate phase order. No negative inference is made from the earlier UNKNOWN, and no single-angle cut transfers. Independent source projection, stock/mode/area-link audit, parent restoration, truth cases and actual import before one20solver/30shared call.'})
rows=[]
for group,count in zip(groups,[1,1,2]):
    flag=len(m.variables);name='-'.join(map(str,group));m.variables.add(name=f'excluded-repeated-two-phase-{name}',domain=[0,1]);ids=[r['variable'] for r in mapping if r['profile'] in group]
    for lit,dom in [(flag,[count,count]),(-flag-1,[-2**63,count-1,count+1,2**63-1])]:
        c=m.constraints.add();c.enforcement_literal.append(lit);c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend(dom)
    rows.append({'profiles':group,'count':count,'flag':flag,'cell_variables':ids})
m.constraints.add().bool_or.literals.extend(-r['flag']-1 for r in rows);shutil.copyfile(PARENT/'mapping.json',OUT/'mapping.json');write(OUT/'exclusion.json',rows);(OUT/'model.pb').write_bytes(m.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
