"""Audit the full balanced-family exclusion from source cells, choices and original-copy symmetry."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,permutations,combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-repeated-phase-exclusion-master-20261026';PARENT=ROOT/'output/h5-balanced-phase-exclusion-master-20261026';SOURCE=ROOT/'output/h5-repeated-bracket-phase-source-20261026';PROBE=ROOT/'output/h5-repeated-spacing-probe-20261026';DATA=ROOT/'output/h5-mixed-cog-band-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify the actual144-mode source model and its closed negative, full stock domains, every orientation pair, matching original profiles and the independently audited complete916-cell area extension. Check9216 bracket identity/mirror/x-order relabellings and360 cog phase/x-order cases, with both insert choices, covering their6635520 Cartesian combinations. Verify that the master still permits only cog9/11 and insert8/10, with at least one11. Reconstruct three exact count reifications and OR, enumerate1000 truth cases, restore the full parent proto and check actual import. No solve and no inference from UNKNOWN.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for p in [PARENT/'audit/checks.json',SOURCE/'audit/checks.json',PROBE/'model-audit/checks.json',PROBE/'response-audit/checks.json']:assert load(p)['passed']
assert load(PROBE/'model-audit/implication.json')['all_parent_coordinates_and_choices_preserved'] and load(ROOT/'output/h5-repeated-band-link-probe-20261026/model-audit/extension-proof.json')['equivalent_source_coordinate_feasibility']
s=load(SOURCE/'plan.json');groups=[[0,4],[2,6],[3,5]];allowed=[groups[0],groups[1],groups[2],groups[2],[8,10]]+[[9,11]]*4
assert s['allowed_profiles']==allowed and s['minimum_new_phase_cogs']==1
assert load(SOURCE/'profiles.json')==load(ROOT/'output/h5-mixed-cog-angle-screen-20261026/profiles.json')
assert [p['item'] for p in s['parts']]==[21,22,25,26,37,53,63,64,65] and all(p['family']=='bracket' for p in s['parts'][:4]) and all(p['family']=='cog' for p in s['parts'][5:])
assert len({p['copy'] for p in s['parts'][:4]})==4 and len({p['copy'] for p in s['parts'][5:]})==4
closed=proto(PROBE/'search/000/model.pb');assert closed==proto(PROBE/'models/000.pb');response=cp_model_pb2.CpSolverResponse();response.ParseFromString((PROBE/'search/000/response.pb').read_bytes());assert response.status==cp_model_pb2.INFEASIBLE and not response.solution
for i,options in enumerate(allowed):
    for axis in range(2):assert list(closed.variables[2*i+axis].domain)==[min(s['anchor_bounds_units1000'][str(p)][axis] for p in options),max(s['anchor_bounds_units1000'][str(p)][axis+2] for p in options)]
    for p in options:assert s['anchor_bounds_units1000'][str(p)][1::2]==load(DATA/'profiles'/f'{p:03d}.json')['y_bounds_units1000']
maps=load(PROBE/'models/000-mapping.json');assert len(maps)==144 and {(tuple(r['parts']),tuple(r['profiles'])) for r in maps}=={((a,b),(pa,pb)) for a,b in combinations(range(9),2) for pa,pb in product(allowed[a],allowed[b])}
bracket_cases=cog_cases=0
for chosen in product(*allowed[:4]):
    for perm in permutations(range(4)):
        assigned=[chosen[i] for i in perm]
        for ranks in permutations(range(4)):
            left=list(range(4));back=[]
            for group in groups[:2]:
                ids=[i for i in left if assigned[i] in group];assert len(ids)==1;back.extend(ids);left.remove(ids[0])
            back.extend(sorted(left,key=lambda i:ranks[i]));result=[assigned[i] for i in back]
            assert sorted(back)==list(range(4)) and all(p in allowed[i] for i,p in enumerate(result)) and ranks[back[2]]<=ranks[back[3]];bracket_cases+=1
for chosen in product([9,11],repeat=4):
    if 11 not in chosen:continue
    for ranks in permutations(range(4)):
        order=sorted(range(4),key=lambda i:ranks[i]);assigned=[chosen[i] for i in order];assert sorted(assigned)==sorted(chosen) and all(p in allowed[5+i] for i,p in enumerate(assigned));cog_cases+=1
assert bracket_cases==9216 and cog_cases==360 and allowed[4]==[8,10]
m=proto(BASE/'model.pb');old=proto(PARENT/'model.pb');assert len(m.variables)==721 and len(m.constraints)==94
restored=cp_model_pb2.CpModelProto();restored.CopyFrom(m);del restored.variables[718:];del restored.constraints[87:];assert restored==old
mapping=load(BASE/'mapping.json');assert mapping==load(PARENT/'mapping.json');assert {r['profile'] for r in mapping if r['family']=='cog'}=={9,11} and {r['profile'] for r in mapping if r['family']=='insert'}=={8,10}
c=cp_model_pb2.ConstraintProto();ids=[r['variable'] for r in mapping if r['profile']==11];c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([1,4]);assert c==m.constraints[66]
rows=[]
for j,(group,count) in enumerate(zip(groups,[1,1,2])):
    flag=718+j;name='-'.join(map(str,group));assert m.variables[flag]==cp_model_pb2.IntegerVariableProto(name=f'excluded-repeated-two-phase-{name}',domain=[0,1]);ids=[r['variable'] for r in mapping if r['profile'] in group]
    for k,(lit,dom) in enumerate([(flag,[count,count]),(-flag-1,[-2**63,count-1,count+1,2**63-1])]):
        c=cp_model_pb2.ConstraintProto();c.enforcement_literal.append(lit);c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend(dom);assert c==m.constraints[87+2*j+k]
    rows.append({'profiles':group,'count':count,'flag':flag,'cell_variables':ids})
assert rows==load(BASE/'exclusion.json');c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-719,-720,-721]);assert c==m.constraints[93];cases=0
for totals in product(range(5),repeat=3):
    exists=False
    for bits in product([0,1],repeat=3):
        valid=not all(bits)
        for j,(value,bit) in enumerate(zip(totals,bits)):
            dom=list(m.constraints[87+2*j+(0 if bit else 1)].linear.domain);valid &= any(lo<=value<=hi for lo,hi in zip(dom[::2],dom[1::2]))
        exists |= valid;cases+=1
    assert exists==(totals!=(1,1,2))
assert cases==1000;real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'implication.json',{'statement':'The three aggregate equalities(1,1,2) consume all4 brackets. The sole insert chooses8/10; all4 cogs choose9/11 with at least one11 by unchanged parent constraint66. Relabel brackets into their type slots and x-sort the two repeated3/5 choices with their profiles and sort identical cogs by x together with phase choices. Every choice and all144 physical modes are available. Complete cell channeling, independently audited band bounds and full-height forbidden-rectangle cog-spacing implications preserve source-coordinate feasibility. Thus a matching guarded-source/grid witness contradicts the actual negative response. This excludes only the specified repeated-type counts within the declared two-angle source/grid family.','cartesian_assignments_covered':9216*360*2,'prior_UNKNOWN_used_as_negative':False,'all_original_identities_retained':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':721,'constraints':94,'exact_parent_restoration_verified':True,'bracket_identity_mirror_x_order_cases':9216,'cog_phase_order_cases':360,'insert_choices':2,'cartesian_assignments_covered':9216*360*2,'source_modes_checked':144,'source_physical_pairs_checked':36,'count_flag_cases_checked':cases,'actual_import_export_verified':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
