"""Exact conditional exclusion for the full repeated-bracket two-phase family."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('prepare_h5_balanced_phase_exclusion_master.py','prepare_h5_repeated_phase_exclusion_master.py'),('audit_h5_balanced_phase_exclusion_master.py','audit_h5_repeated_phase_exclusion_master.py'),('run_h5_balanced_phase_exclusion_master.py','run_h5_repeated_phase_exclusion_master.py'),('audit_h5_balanced_phase_exclusion_response.py','audit_h5_repeated_phase_exclusion_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8')
    s=s.replace('h5-balanced-phase-exclusion-master-20261026','h5-repeated-phase-exclusion-master-20261026').replace('h5-balanced-phase-exclusion-search-20261026','h5-repeated-phase-exclusion-search-20261026').replace('h5-mixed-cog-exclusion-master-20261026','h5-balanced-phase-exclusion-master-20261026')
    s=s.replace('h5-balanced-phase-choice-source-20261026','h5-repeated-bracket-phase-source-20261026').replace('h5-balanced-band-link-probe-20261026','h5-repeated-spacing-probe-20261026').replace('h5-balanced-phase-choice-probe-20261026','h5-repeated-bracket-phase-base-20261026')
    # Literal number substitutions are simultaneous to preserve old/new parent sizes.
    numbers={'714':'718','718':'721','78':'87','87':'94','86':'93'}
    s=re.sub(r'(?<!\d)(714|718|78|87|86)(?!\d)',lambda m:numbers[m.group()],s)
    s=s.replace('excluded-balanced-two-phase-','excluded-repeated-two-phase-')
    if src.startswith('prepare'):
        s=s.replace('groups=[[0,4],[2,6],[1,7],[3,5]]','groups=[[0,4],[2,6],[3,5]]')
        s=s.replace("PROBE/'model-audit/extension-proof.json'","PROBE/'model-audit/implication.json',ROOT/'output/h5-repeated-band-link-probe-20261026/model-audit/extension-proof.json'")
        s=s.replace("[{'profiles':g,'count':1} for g in groups]","[{'profiles':g,'count':n} for g,n in zip(groups,[1,1,2])]")
        s=s.replace('for group in groups:','for group,count in zip(groups,[1,1,2]):')
        old='[(flag,[1,1]),(-flag-1,[-2**63,0,2,2**63-1])]';new='[(flag,[count,count]),(-flag-1,[-2**63,count-1,count+1,2**63-1])]';assert old in s;s=s.replace(old,new)
        s=s.replace("'count':1,'flag':flag","'count':count,'flag':flag")
        s=s.replace('Add four exact count-equality reifications and a not-all clause for one bracket in each0/4,2/6,1/7,3/5 group.','Add three exact count-equality reifications and a not-all clause for counts(p0+p4,p2+p6,p3+p5)=(1,1,2).')
        s=s.replace('Its complete vertical-cell area bounds preserve parent source-coordinate feasibility.','Its complete vertical-cell area bounds and certified full-height cog-spacing bounds preserve parent source-coordinate feasibility. The two repeated bracket slots can be x-sorted together with their chosen3/5 profiles.')
    elif src.endswith('exclusion_master.py'):
        old="assert load(PROBE/'model-audit/extension-proof.json')['equivalent_source_coordinate_feasibility']";new="assert load(PROBE/'model-audit/implication.json')['all_parent_coordinates_and_choices_preserved'] and load(ROOT/'output/h5-repeated-band-link-probe-20261026/model-audit/extension-proof.json')['equivalent_source_coordinate_feasibility']";assert old in s;s=s.replace(old,new)
        s=s.replace('groups=[[0,4],[2,6],[1,7],[3,5]];allowed=groups+[[8,10]]+[[9,11]]*4','groups=[[0,4],[2,6],[3,5]];allowed=[groups[0],groups[1],groups[2],groups[2],[8,10]]+[[9,11]]*4')
        a=s.index('bracket_cases=cog_cases=0');b=s.index('for chosen in product([9,11],repeat=4):',a)
        s=s[:a]+'''bracket_cases=cog_cases=0
for chosen in product(*allowed[:4]):
    for perm in permutations(range(4)):
        assigned=[chosen[i] for i in perm]
        for ranks in permutations(range(4)):
            left=list(range(4));back=[]
            for group in groups[:2]:
                ids=[i for i in left if assigned[i] in group];assert len(ids)==1;back.extend(ids);left.remove(ids[0])
            back.extend(sorted(left,key=lambda i:ranks[i]));result=[assigned[i] for i in back]
            assert sorted(back)==list(range(4)) and all(p in allowed[i] for i,p in enumerate(result)) and ranks[back[2]]<=ranks[back[3]];bracket_cases+=1
''' +s[b:]
        s=s.replace('bracket_cases==384','bracket_cases==9216').replace("'bracket_identity_mirror_cases':384","'bracket_identity_mirror_x_order_cases':9216").replace('384*360*2','9216*360*2')
        s=s.replace('for j,group in enumerate(groups):','for j,(group,count) in enumerate(zip(groups,[1,1,2])):')
        old='[(flag,[1,1]),(-flag-1,[-2**63,0,2,2**63-1])]';new='[(flag,[count,count]),(-flag-1,[-2**63,count-1,count+1,2**63-1])]';assert old in s;s=s.replace(old,new)
        s=s.replace("'count':1,'flag':flag","'count':count,'flag':flag").replace('[-715,-716,-717,-721]','[-719,-720,-721]')
        s=s.replace('product(range(5),repeat=4)','product(range(5),repeat=3)').replace('product([0,1],repeat=4)','product([0,1],repeat=3)').replace('totals!=(1,1,1,1)','totals!=(1,1,2)').replace('cases==10000','cases==1000')
        s=s.replace('Check384 bracket identity/mirror relabellings and360 cog phase/x-order cases, with both insert choices, covering their276480 Cartesian combinations.','Check9216 bracket identity/mirror/x-order relabellings and360 cog phase/x-order cases, with both insert choices, covering their6635520 Cartesian combinations.')
        s=s.replace('Reconstruct four exact count reifications and OR, enumerate10000 truth cases','Reconstruct three exact count reifications and OR, enumerate1000 truth cases')
        s=s.replace('Four balanced group equalities consume all4 brackets.','The three aggregate equalities(1,1,2) consume all4 brackets.')
        s=s.replace('Relabel brackets into their unique type slots','Relabel brackets into their type slots and x-sort the two repeated3/5 choices with their profiles')
        s=s.replace('Complete cell channeling plus independently audited band bounds preserves source-coordinate feasibility.','Complete cell channeling, independently audited band bounds and full-height forbidden-rectangle cog-spacing implications preserve source-coordinate feasibility.')
        s=s.replace('excludes only balanced counts','excludes only the specified repeated-type counts')
    elif 'response' in src:
        old="assert (totals[0]+totals[4],totals[2]+totals[6],totals[1]+totals[7],totals[3]+totals[5])!=(1,1,1,1);";assert old in s;s=s.replace(old,old+"assert (totals[0]+totals[4],totals[2]+totals[6],totals[3]+totals[5])!=(1,1,2);")
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
