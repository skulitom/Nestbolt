"""Preserve the helper-generation failure and create only the missing runners."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,re,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-repeated-phase-runner-recovery-20261026';OUT.mkdir()
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert not (ROOT/'output/h5-repeated-phase-exclusion-search-20261026').exists()
assert json.loads((ROOT/'output/h5-repeated-phase-exclusion-master-20261026/audit/checks.json').read_bytes())['passed']
old=ROOT/'output/make_h5_repeated_phase_exclusion_helpers.py';shutil.copyfile(old,OUT/'original-generator.py');shutil.copyfile(__file__,OUT/'repair.py')
failure={'utc':datetime.now(timezone.utc).isoformat(),'failed_helper':old.relative_to(ROOT).as_posix(),'original_helper_sha256':digest(old),'exit_code':1,'failure':'AssertionError at the extension-proof replacement in line23. The third loop entry was run_h5_balanced_phase_exclusion_master.py; the overly broad endswith(exclusion_master.py) branch treated it as the model auditor.','completed_before_failure':['prepare_h5_repeated_phase_exclusion_master.py','audit_h5_repeated_phase_exclusion_master.py'],'already_generated_model_and_audit_passed':True,'runner_created_before_failure':False,'solver_calls_opened':0,'preservation':'Keep the original generator, model, completed audit and all prior responses unchanged. Generate only the two missing runner/readback helpers with separate explicit logic. No solver retry.'}
with (OUT/'preflight-failure.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(failure,f,indent=2);f.write('\n')
created=[]
for src,dst in [('run_h5_balanced_phase_exclusion_master.py','run_h5_repeated_phase_exclusion_master.py'),('audit_h5_balanced_phase_exclusion_response.py','audit_h5_repeated_phase_exclusion_response.py')]:
    p=ROOT/'output'/dst;assert not p.exists()
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-balanced-phase-exclusion-master-20261026','h5-repeated-phase-exclusion-master-20261026').replace('h5-balanced-phase-exclusion-search-20261026','h5-repeated-phase-exclusion-search-20261026')
    s=s.replace('718-variable/87-constraint','721-variable/94-constraint').replace('all718 variable domains and87 constraints','all721 variable domains and94 constraints').replace('len(sol)==718','len(sol)==721')
    if src.startswith('audit'):
        marker="assert (totals[0]+totals[4],totals[2]+totals[6],totals[1]+totals[7],totals[3]+totals[5])!=(1,1,1,1);";assert marker in s;s=s.replace(marker,marker+"assert (totals[0]+totals[4],totals[2]+totals[6],totals[3]+totals[5])!=(1,1,2);")
    compile(s,dst,'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    created.append({'path':p.relative_to(ROOT).as_posix(),'sha256':digest(p)})
with (OUT/'recovery.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'passed':True,'created_helpers':created,'original_generator_unchanged':digest(old)==failure['original_helper_sha256'],'solver_calls':0},f,indent=2);f.write('\n')
print({'repaired':True,'missing_helpers_created':len(created),'solver_calls':0})
