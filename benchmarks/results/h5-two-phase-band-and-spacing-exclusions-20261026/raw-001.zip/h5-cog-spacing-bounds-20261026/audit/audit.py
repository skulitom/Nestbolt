"""Independently verify full original collision geometry and certified forbidden rectangles."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,box,shape
from shapely.affinity import affine_transform
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-spacing-bounds-20261026';SOURCE=ROOT/'output/h5-repeated-bracket-phase-source-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rings(g):
    for p in [g] if g.geom_type=='Polygon' else g.geoms:
        yield p.exterior
        yield from p.interiors
def rightmost(g,y):
    values=[]
    for ring in rings(g):
        xy=list(ring.coords)
        for (x0,y0),(x1,y1) in zip(xy,xy[1:]):
            if y0==y1:
                if y==y0:values.extend([x0,x1])
            elif min(y0,y1)<=y<=max(y0,y1):values.append(x0+(x1-x0)*(y-y0)/(y1-y0))
    assert values;return max(values)
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently rotate full original cog polygons and reconstruct all four raw forbidden regions with unmerged triangle-pair hulls. Check source guard containment and complete face coverage. Derive full relative-Y intervals from source stock bounds, recompute each boundary sample using analytic segment interpolation, and reconstruct the integer forbidden rectangle independently. Require strict whole-rectangle containment and positive distance to every forbidden boundary, not only sampled points. Integer deltaX nonnegative and below D necessarily lies in that rectangle and is therefore forbidden by the original source clauses. No solver or unrestricted-geometry exclusion.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];s=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');g=next(p for p in job['parts'] if p['id']=='cog');tri={}
for pi in [9,11]:
    p=profiles[pi];co,si=math.cos(p['rotation_radians']),math.sin(p['rotation_radians']);cx,cy=p['original_center'];a=affine_transform(Polygon(g['geometry'][0]['outer']),[co,-si,si,co,-co*cx+si*cy,-si*cx-co*cy]);assert a.hausdorff_distance(shape(p['geometry']))<1e-7;tri[pi]=list(shapely.constrained_delaunay_triangles(a).geoms);assert unary_union(tri[pi]).symmetric_difference(a).area<1e-7
rows=load(BASE/'bounds.json');assert {tuple(r['profiles']) for r in rows}==set(product([9,11],repeat=2));hulls=samples=0;checks=[]
for row in rows:
    pa,pb=row['profiles'];c=next(c for c in s['mutual_cases'] if [c['profile_a'],c['profile_b']]==[pa,pb]);assert c['index']==row['source_case'];r=load(SOURCE/'mutual'/f"{c['index']:03d}.json");pieces=[]
    for a,b in product(tri[pa],tri[pb]):pieces.append(MultiPoint([(x-u,y-v) for x,y in list(a.exterior.coords)[:-1] for u,v in list(b.exterior.coords)[:-1]]).convex_hull);hulls+=1
    raw=unary_union(pieces);guard=shape(r['expanded_forbidden']);assert raw.hausdorff_distance(shape(r['raw_forbidden']))<1e-7 and guard.covers(raw) and guard.boundary.distance(raw)>.21170867250963943
    assert unary_union([shape(f['expanded_face']) for f in r['faces']]).covers(guard)
    aa,bb=s['anchor_bounds_units1000'][str(pa)],s['anchor_bounds_units1000'][str(pb)];lo,hi=bb[1]-aa[3],bb[3]-aa[1];assert row['relative_y_bounds_units1000']==[lo,hi]
    ys=sorted({lo/1000,hi/1000}|{y for ring in rings(guard) for x,y in ring.coords if lo/1000<=y<=hi/1000});assert ys==[v['y_mm'] for v in row['samples']]
    for sample in row['samples']:assert abs(rightmost(guard,sample['y_mm'])-sample['rightmost_x_mm'])<1e-7;samples+=1
    minimum=min(v['rightmost_x_mm'] for v in row['samples']);D=math.floor(minimum*1000);assert minimum==row['minimum_screened_rightmost_x_mm'] and D==row['minimum_integer_dx_units1000']
    rect=box(0,lo/1000,(D-1)/1000,hi/1000);assert rect.equals(shape(row['forbidden_rectangle'])) and guard.contains(rect) and guard.boundary.distance(rect)>1e-8 and abs(guard.boundary.distance(rect)-row['rectangle_boundary_gap_mm'])<1e-10
    checks.append({'profiles':[pa,pb],'minimum_dx_units1000':D,'full_relative_y_interval_verified':True,'rectangle_interior_margin_mm':guard.boundary.distance(rect),'passed':True})
write(OUT/'case-checks.json',checks);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'ordered_cog_cases':4,'unmerged_triangle_pair_hulls':hulls,'boundary_samples_checked':samples,'entire_forbidden_rectangles_checked':4,'all_bounds_cover_every_source_y_value':True,'minimum_rectangle_interior_margin_mm':min(r['rectangle_interior_margin_mm'] for r in checks),'common_minimum_dx_units1000':min(r['minimum_dx_units1000'] for r in checks),'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
