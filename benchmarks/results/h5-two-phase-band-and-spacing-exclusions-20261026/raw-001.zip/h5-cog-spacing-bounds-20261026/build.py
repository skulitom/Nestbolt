"""Derive conservative cog x-separation bounds from full-height forbidden rectangles."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,math,shutil,time
from shapely.geometry import LineString,box,shape,mapping
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-repeated-bracket-phase-source-20261026';OUT=ROOT/'output/h5-cog-spacing-bounds-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rings(g):
    for p in [g] if g.geom_type=='Polygon' else g.geoms:
        yield p.exterior
        yield from p.interiors
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();assert load(SOURCE/'audit/checks.json')['passed'];s=load(SOURCE/'plan.json');bounds=s['anchor_bounds_units1000'];cases=[c for c in s['mutual_cases'] if c['profile_a'] in [9,11] and c['profile_b'] in [9,11]];assert len(cases)==4
paths=[SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json']+[SOURCE/'mutual'/f"{c['index']:03d}.json" for c in cases]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'For each of the four ordered cog9/11 choices derive the full relative Y interval from native-guarded stock domains. Screen the rightmost forbidden X at every envelope vertex height and interval endpoint. Choose a conservative integer bound D=floor(minimum_rightmost_X*1000), then separately certify the entire rectangle X in[0,(D-1)/1000],Y in its full allowed interval is strictly inside the audited forbidden envelope, with positive boundary distance. This direct containment is the proof; screening alone is not. Because cog anchors are globally x-ordered and integer, every valid source placement must have deltaX>=D. Add no geometry approximation or packing claim; all original source clauses remain.'})
rows=[]
for c in cases:
    pa,pb=c['profile_a'],c['profile_b'];r=load(SOURCE/'mutual'/f"{c['index']:03d}.json");g=shape(r['expanded_forbidden']);aa,bb=bounds[str(pa)],bounds[str(pb)];lo,hi=bb[1]-aa[3],bb[3]-aa[1]
    ys=sorted({lo/1000,hi/1000}|{y for ring in rings(g) for x,y in ring.coords if lo/1000<=y<=hi/1000});samples=[]
    for y in ys:
        section=g.intersection(LineString([(-1000,y),(1000,y)]));assert not section.is_empty;samples.append({'y_mm':y,'rightmost_x_mm':section.bounds[2]})
    minimum=min(v['rightmost_x_mm'] for v in samples);D=math.floor(minimum*1000);rect=box(0,lo/1000,(D-1)/1000,hi/1000);gap=g.boundary.distance(rect)
    assert D>0 and g.contains(rect) and gap>1e-8
    rows.append({'profiles':[pa,pb],'source_case':c['index'],'relative_y_bounds_units1000':[lo,hi],'samples':samples,'minimum_screened_rightmost_x_mm':minimum,'minimum_integer_dx_units1000':D,'forbidden_rectangle':mapping(rect),'rectangle_boundary_gap_mm':gap})
assert {tuple(r['profiles']) for r in rows}==set(product([9,11],repeat=2));write(OUT/'bounds.json',rows);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'ordered_cog_cases':4,'certified_minimum_dx_units1000':{f"{r['profiles'][0]}-{r['profiles'][1]}":r['minimum_integer_dx_units1000'] for r in rows},'common_minimum_dx_units1000':min(r['minimum_integer_dx_units1000'] for r in rows),'minimum_containment_margin_mm':min(r['rectangle_boundary_gap_mm'] for r in rows),'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
