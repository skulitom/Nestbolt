"""Direct shared-plane model for all declared bracket mirror choices."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-repeated-bracket-phase-source-20261026';OUT=ROOT/'output/h5-repeated-bracket-phase-base-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(SOURCE/'audit/checks.json')['passed'];s=load(SOURCE/'plan.json');allowed=s['allowed_profiles'];bounds=s['anchor_bounds_units1000'];data={(c['profile_a'],c['profile_b']):load(SOURCE/'mutual'/f"{c['index']:03d}.json") for c in s['mutual_cases']}
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in SOURCE.rglob('*') if p.is_file()},'method':'Direct equivalent shared-plane representation for all144 declared physical orientation modes. 18 original coordinates and18 profile flags, with nine exact-one choices; conditional stock boxes. Only the two bracket slots2/3 with identical allowed3/5 choices are x-ordered together with their profile choices; other bracket types are unordered. All four cog copies have identical allowed9/11 choices and may be globally x-ordered by relabelling copies together with their chosen profiles. Require at least one11; do not order their profiles. Nine exact-one constraints,36 conditional stock bounds, three cog x orders and one phase count plus one repeated-bracket x order make50 base constraints. Every non-tautological source face becomes one OR of inactive-mode literals and shared outside-plane flags; each shared flag unconditionally implies its exact physical pair plane. Coordinate feasibility is preserved by assigning flags from plane truth. The audited base is not called; complete band constraints are added before the sole search. No unfactored source call, optional original, cell lock or hint. Independent complete geometric-clause, sharing and actual-import audit before one45second4worker seed0 call in60shared seconds.'})
m=cp_model_pb2.CpModelProto();flags={}
for i,options in enumerate(allowed):
    for axis in range(2):m.variables.add(name=f'p{i}-'+('xy'[axis]),domain=[min(bounds[str(p)][axis] for p in options),max(bounds[str(p)][axis+2] for p in options)])
for i in range(9):
    flags[i]={}
    for p in allowed[i]:flags[i][p]=len(m.variables);m.variables.add(name=f'p{i}-profile{p}',domain=[0,1])
def linear(terms,lo,hi,enforce=()):
    c=m.constraints.add();ids=sorted(v for v,k in terms.items() if k);c.linear.vars.extend(ids);c.linear.coeffs.extend(terms[v] for v in ids);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(enforce)
for i in range(9):
    linear({v:1 for v in flags[i].values()},1,1)
    for p,v in flags[i].items():
        b=bounds[str(p)]
        for axis in range(2):linear({2*i+axis:1},b[axis],b[axis+2],[v])
for i in range(5,8):linear({2*i:1,2*(i+1):-1},-2**63,0)
linear({flags[i][11]:1 for i in range(5,9)},1,4)
linear({4:1,6:-1},-2**63,0)
assert len(m.variables)==36 and len(m.constraints)==50
planes={};plane_rows=[];clauses=[];maps=[];taut=uses=0
for a,b in combinations(range(9),2):
    for pa,pb in product(allowed[a],allowed[b]):
        aa,bb=bounds[str(pa)],bounds[str(pb)];d=[bb[0]-aa[2],bb[1]-aa[3],bb[2]-aa[0],bb[3]-aa[1]];active=[flags[a][pa],flags[b][pb]];fs=[]
        for face in data[pa,pb]['faces']:
            hs=face['outside_halfplanes'];ranges=[(h['a']*d[0 if h['a']>=0 else 2]+h['b']*d[1 if h['b']>=0 else 3],h['a']*d[2 if h['a']>=0 else 0]+h['b']*d[3 if h['b']>=0 else 1]) for h in hs]
            if any(lo>=h['bound'] for h,(lo,hi) in zip(hs,ranges)):taut+=1;fs.append({'face':face['index'],'tautological':True});continue
            live=[j for j,(h,(lo,hi)) in enumerate(zip(hs,ranges)) if hi>=h['bound']];edge_flags=[]
            for j in live:
                h=hs[j];key=(a,b,h['a'],h['b'],h['bound'])
                if key not in planes:
                    v=len(m.variables);planes[key]=v;m.variables.add(name=f'pair-plane-{v}',domain=[0,1]);linear({2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']},h['bound'],2**63-1,[v]);plane_rows.append({'flag':v,'parts':[a,b],'a':h['a'],'b':h['b'],'bound':h['bound']})
                edge_flags.append(planes[key]);uses+=1
            clause=[-v-1 for v in active]+edge_flags;clauses.append(clause);fs.append({'face':face['index'],'live_edges':live,'shared_flags':edge_flags})
        maps.append({'parts':[a,b],'profiles':[pa,pb],'active':active,'difference_bounds':d,'faces':fs})
for lits in clauses:m.constraints.add().bool_or.literals.extend(lits)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');write(OUT/'models/000-mapping.json',maps);write(OUT/'profile-flags.json',flags);write(OUT/'shared-planes.json',plane_rows);row={'index':0,'parts':list(range(9)),'originals':[p['item'] for p in s['parts']],'allowed_profiles':allowed,'variables':len(m.variables),'constraints':len(m.constraints),'solver_seconds':45.,'model_sha256':digest(p),'shared_planes':len(planes),'edge_uses':uses,'face_clauses':len(clauses),'tautological_faces':taut,'physical_modes':len(maps)};write(OUT/'inventory.json',[row]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**row,'solver_calls':0});print(load(OUT/'prepared.json'))
