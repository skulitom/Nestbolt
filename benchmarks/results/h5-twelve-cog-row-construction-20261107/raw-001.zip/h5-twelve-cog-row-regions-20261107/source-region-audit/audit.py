"""Certify fresh mover/row and row/row regions against original filled outlines."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import hull
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-twelve-cog-row-regions-20261107';OUT=BASE/'source-region-audit';PRE=ROOT/'output/h5-twelve-cog-row-domains-20261107';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
EXP=ROOT/'output/h5-twelve-cog-row-domains-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transform(points,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    return [(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in points]
def rational(points):return [tuple(map(F,p)) for p in points]
def nf(a,b):return MultiPoint((np.asarray(a)[:,None,:]-np.asarray(b)[None,:,:]).reshape(-1,2)).convex_hull
def support(region,moving,fixed,normal):
    nx,ny=map(F,normal);norm=nx*nx+ny*ny
    gap=min(x*nx+y*ny for x,y in region)+min(x*nx+y*ny for x,y in moving)-max(x*nx+y*ny for x,y in fixed)
    return gap>0 and gap*gap>=F('.225')**2*norm,float(gap)/math.sqrt(float(norm))
def certificate(region,shape,moving,fixed,obstacle):
    seg=list(shapely.shortest_line(obstacle,shape).coords)
    if len(seg)!=2:return None
    dx,dy=seg[1][0]-seg[0][0],seg[1][1]-seg[0][1];length=math.hypot(dx,dy)
    if not length:return None
    normal=[dx/length,dy/length];valid,gap=support(region,moving,fixed,normal)
    return (normal,gap) if valid else None
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for name,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(PRE/'audit/checks.json')['passed']
job=load(JOB);parts={p['id']:p for p in job['parts']};canonical=load(PIECES);modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');inventory=load(BASE/'inventory.json');sites=load(BASE/'source-cogs.json');groups=load(BASE/'rows.json');library=load(FIRST/'geometry-library.json')
assert sites==load(PRE/'source-cogs.json') and inventory==load(PRE/'inventory.json') and groups==load(EXP/'rows.json') and load(EXP/'audit/checks.json')['passed']
for family,opts in modes.items():
    assert len(opts)==len(load(FIRST/'family-modes.json')[family])
    for m,original in zip(opts,load(FIRST/'family-modes.json')[family]):
        assert {k:v for k,v in m.items() if k!='relative_lower_left_bounds_by_row_mm'}==original
        assert len(m['relative_lower_left_bounds_by_row_mm'])==3
        for ri,g in enumerate(groups):
            for axis,bounds in enumerate(m['relative_lower_left_bounds_by_row_mm'][ri]):
                assert list(map(F,bounds))==[F(original['lower_left_bounds'][axis][0])-F(g['shift_bounds_grid'][axis][1],100),F(original['lower_left_bounds'][axis][1])-F(g['shift_bounds_grid'][axis][0],100)]
assert [r['identity'] for r in instances]==inventory['moving16_orthogonal_identities'] and sum(r['mode_count'] for r in instances)==96
assert [len(g['source_indices']) for g in groups]==[4,4,4]
controls=load(BASE/'controls.json');assert controls==[{'control':0,'row_shifts_grid':[[0,0]]*3,'source':'reference50-source.json','source_checks':'reference50-checks.json'}]
for name in ['reference50-source.json','reference50-checks.json']:assert load(BASE/name)==load(EXP/name)
assert load(EXP/'reference50-checks.json')['valid'] and load(EXP/'reference50-checks.json')['same_sheet_pairs']==856
for family in ['bracket','insert','cog']:
    shapes=[Polygon(p) for p in canonical[family]];source=Polygon(parts[family]['geometry'][0]['outer'])
    assert unary_union(shapes).symmetric_difference(source).area<1e-7 and abs(sum(p.area for p in shapes)-source.area)<1e-7
cogs=[]
for site in sites:
    t=site['transform'];outer=transform(parts['cog']['geometry'][0]['outer'],t);pieces=[transform(p,t) for p in canonical['cog']]
    assert unary_union([Polygon(p) for p in pieces]).symmetric_difference(Polygon(outer)).area<1e-7
    cogs.append({'outer':outer,'hull':hull(rational(outer)),'pieces':pieces,'rational_pieces':[rational(p) for p in pieces]})
mode_data={};full_nf={};piece_nf={}
for family,items in modes.items():
    for mode in items:
        key=(family,mode['mode']);t={'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':mode['translation_from_lower_left']};pieces=[transform(p,t) for p in canonical[family]];outline=transform(parts[family]['geometry'][0]['outer'],t)
        assert unary_union([Polygon(p) for p in pieces]).symmetric_difference(Polygon(outline)).area<1e-7 and Polygon(outline).hausdorff_distance(Polygon(library[mode['normalized_geometry']]['outer']))<1e-9
        mode_data[key]={'mode':mode,'pieces':pieces,'rational_pieces':[rational(p) for p in pieces]}
        for si,cg in enumerate(cogs):
            for pi,p in enumerate(pieces):full_nf[key,si,pi]=nf(cg['outer'],p)
mover_proofs=[];mover_rounded=[];pair_proofs=[];pair_rounded=[];disabled=[];minimum=math.inf;fallback=0;checked_regions=0
for group in groups:
    row=group['row']
    for gid in range(10):
        data=load(BASE/'mover-rows'/f'{row}-{gid:02d}.json');assert data['row']==row and data['geometry']==gid
        eligible=[(k,v) for k,v in mode_data.items() if v['mode']['normalized_geometry']==gid];assert eligible
        bounds=[[max(F(v['mode']['relative_lower_left_bounds_by_row_mm'][row][k][0]) for _,v in eligible),min(F(v['mode']['relative_lower_left_bounds_by_row_mm'][row][k][1]) for _,v in eligible)] for k in [0,1]]
        assert list(map(F,data['domain_mm']))==[bounds[0][0],bounds[1][0],bounds[0][1],bounds[1][1]]
        for index,region in enumerate(data['regions']):
            assert region['region']==index;rounded=hull([tuple(F(round(v,9)) for v in p) for p in region['vertices']]);checked_regions+=1
            if len(rounded)<3:disabled.append(['mover',row,gid,index]);continue
            shape=Polygon([(float(x),float(y)) for x,y in rounded]);assert shape.is_valid and shape.area>0
            mover_rounded.append({'row':row,'geometry':gid,'region':index,'hull_vertices':[[str(x),str(y)] for x,y in rounded]})
            for key,moving in eligible:
                for si in group['source_indices']:
                    cg=cogs[si]
                    for pi,source in enumerate(moving['rational_pieces']):
                        cert=certificate(rounded,shape,source,cg['hull'],full_nf[key,si,pi])
                        if cert:
                            n,gap=cert;mover_proofs.append([row,gid,index,key[0],key[1],si,pi,-1,*n]);minimum=min(minimum,gap)
                        else:
                            fallback+=1
                            for ci,cp in enumerate(cg['rational_pieces']):
                                cache=(key,si,pi,ci)
                                if cache not in piece_nf:piece_nf[cache]=nf(cg['pieces'][ci],moving['pieces'][pi])
                                cert=certificate(rounded,shape,source,cp,piece_nf[cache]);assert cert,(row,gid,index,key,si,pi,ci)
                                n,gap=cert;mover_proofs.append([row,gid,index,key[0],key[1],si,pi,ci,*n]);minimum=min(minimum,gap)
row_full_nf={};row_piece_nf={};row_both_piece_nf={};whole_pair_proofs=0;pair_fallback=0
for ga,gb in combinations(groups,2):
    ra,rb=ga['row'],gb['row'];data=load(BASE/'row-pairs'/f'{ra}-{rb}.json');assert data['rows']==[ra,rb] and data['relative_coordinate']=='shift_B_minus_shift_A'
    bounds=[[F(gb['shift_bounds_grid'][k][0]-ga['shift_bounds_grid'][k][1],100),F(gb['shift_bounds_grid'][k][1]-ga['shift_bounds_grid'][k][0],100)] for k in [0,1]];assert list(map(F,data['domain_mm']))==[bounds[0][0],bounds[1][0],bounds[0][1],bounds[1][1]]
    for index,region in enumerate(data['regions']):
        assert region['region']==index;rounded=hull([tuple(F(round(v,9)) for v in p) for p in region['vertices']]);checked_regions+=1
        if len(rounded)<3:disabled.append(['pair',ra,rb,index]);continue
        shape=Polygon([(float(x),float(y)) for x,y in rounded]);assert shape.is_valid and shape.area>0
        pair_rounded.append({'rows':[ra,rb],'region':index,'hull_vertices':[[str(x),str(y)] for x,y in rounded]})
        for ai in ga['source_indices']:
            for bi in gb['source_indices']:
                A,B=cogs[ai],cogs[bi]
                if (ai,bi) not in row_full_nf:row_full_nf[ai,bi]=nf(A['outer'],B['outer'])
                cert=certificate(rounded,shape,B['hull'],A['hull'],row_full_nf[ai,bi])
                if cert:
                    n,gap=cert;pair_proofs.append([ra,rb,index,ai,bi,-1,-1,*n]);minimum=min(minimum,gap);whole_pair_proofs+=1;continue
                pair_fallback+=1
                for bp,source in enumerate(B['rational_pieces']):
                    key=(ai,bi,bp)
                    if key not in row_piece_nf:row_piece_nf[key]=nf(A['outer'],B['pieces'][bp])
                    cert=certificate(rounded,shape,source,A['hull'],row_piece_nf[key])
                    if cert:
                        n,gap=cert;pair_proofs.append([ra,rb,index,ai,bi,-1,bp,*n]);minimum=min(minimum,gap);continue
                    for ap,fixed in enumerate(A['rational_pieces']):
                        key=(ai,bi,ap,bp)
                        if key not in row_both_piece_nf:row_both_piece_nf[key]=nf(A['pieces'][ap],B['pieces'][bp])
                        cert=certificate(rounded,shape,source,fixed,row_both_piece_nf[key]);assert cert,(ra,rb,index,ai,bi,ap,bp)
                        n,gap=cert;pair_proofs.append([ra,rb,index,ai,bi,ap,bp,*n]);minimum=min(minimum,gap)
for name,data in [('mover-row-supports.json',mover_proofs),('row-pair-supports.json',pair_proofs),('rounded-mover-regions.json',mover_rounded),('rounded-row-pair-regions.json',pair_rounded),('disabled-regions.json',disabled)]:write(OUT/name,data)
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',JOB,PIECES,FIRST/'geometry-library.json',PRE/'audit/plan.json',PRE/'audit/checks.json',PRE/'domain.json',EXP/'plan.json',EXP/'audit/plan.json',EXP/'audit/checks.json',EXP/'rows.json',EXP/'row-modes.json',EXP/'pair-domains.json']+[p for p in BASE.rglob('*.json') if OUT not in p.parents]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconstruct original source convex partitions, every source transform and mode alias. For each mover-to-row region, prove exact rational support separation from all source cogs in that row. For each row-pair relative shift region, prove separation for every cross-row original-cog pair: try whole filled hulls, then every moving original convex piece against the fixed hull, then every pair of original convex pieces. Verify all modes and all row pairs without assuming one shared translation. The simultaneous reference50 control is identical to the independently verified source control; it is not claimed to lie in the conservative new model or row grid bounds. Source stock/fixed-core safety follows from each independently verified expanded individual row box; new inter-row support certificates provide the missing cross-row safety. No global free-space coverage claim.'})
result={'passed':True,'seconds':time.perf_counter()-started,'source_modes_verified':len(mode_data),'source_cog_rows_verified':3,'row_source_counts_verified':[4,4,4],'source_cogs_verified':12,'original_source_controls_verified':1,'source_control_pairs_verified':856,'mover_row_regions_verified':len(mover_rounded),'row_pair_regions_verified':len(pair_rounded),'rounded_regions_reviewed':checked_regions,'disabled_degenerate_regions':len(disabled),'exact_mover_row_support_proofs':len(mover_proofs),'mover_whole_cog_fallbacks':fallback,'exact_row_pair_support_proofs':len(pair_proofs),'whole_cog_pair_proofs':whole_pair_proofs,'whole_cog_pair_fallbacks':pair_fallback,'minimum_certified_source_gap_mm':minimum,'source_controls_claimed_as_model_controls':False,'all_source_mode_aliases_checked':True,'all_three_row_pairs_checked':True,'expanded_row_specific_mode_domains_verified':36,'individual_row_shift_boxes_verified':3,'global_coverage_claimed':False,'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
