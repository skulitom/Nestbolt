"""Fresh movable-row domains, source controls and all row interaction regions."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import merge_exact
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];PACKET=ROOT/'output/h5-twelve-cog-row-domains-20261107';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';SHORT=ROOT/'output/h5-first57-direct-short9-20261104/short9-source.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
OUT=ROOT/'output/h5-twelve-cog-row-regions-20261107';EXP=ROOT/'output/h5-twelve-cog-row-domains-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygonal(g):
    if g.is_empty:return Polygon()
    if g.geom_type=='Polygon':return g
    children=[polygonal(p) for p in g.geoms] if hasattr(g,'geoms') else []
    return unary_union([p for p in children if not p.is_empty]) if children else Polygon()
def partition(domain,obstacles):
    free=polygonal(box(*map(float,domain)).difference(unary_union(obstacles)))
    triangles=[p for p in shapely.constrained_delaunay_triangles(free).geoms if p.area>0]
    assert all(p.geom_type=='Polygon' and len(p.exterior.coords)==4 for p in triangles)
    convex,merges=merge_exact(triangles) if triangles else ([],0)
    polys=[Polygon(p) for p in convex];error=unary_union(polys).symmetric_difference(free).area if polys else free.area;assert error<1e-6
    return {'domain_mm':[str(v) for v in domain],'free_area_mm2':free.area,'initial_triangles':len(triangles),'exact_merges':merges,'regions':[{'region':i,'vertices':v} for i,v in enumerate(convex)],'floating_partition_coverage_error_mm2':error}
assert load(PACKET/'audit/checks.json')['passed'] and load(EXP/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'mover-rows').mkdir();(OUT/'row-pairs').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
inputs=[Path(__file__),ROOT/'output/prepare_h5_twelve_cog_region_helpers_20261107.py',ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT]+[FIRST/n for n in ['plan.json','fixed29.json','family-modes.json','geometry-library.json','audit/plan.json','audit/checks.json']]+[PACKET/n for n in ['plan.json','source-cogs.json','inventory.json','domain.json','reference50-source.json','reference50-checks.json','audit/plan.json','audit/checks.json']]+[EXP/n for n in ['plan.json','checks.json','rows.json','row-modes.json','pair-domains.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New construction using independently source-certified individual stock/core translation boxes for each rigid4/4/4-cog row. Rebuild every mover-to-row and row-pair Minkowski obstacle from original convex source pieces over the enlarged row-specific relative domains. Triangulate each bounded free region and exactly merge adjacent convex polygons. Every rounded region requires independent original-source support certification. Preserve the independently checked simultaneous reference50 control without claiming it satisfies the inflated model or row grid bounds. The closed13-cog/short11 models are not reused or rerun; this model uses12 cogs and16 orthogonal companions with short9. No fixed-cog capacity exclusions transfer.','square_halfwidth_mm':.226,'required_certified_source_gap_mm':.225,'source_geometry_preparation_target_seconds':30,'complete_process_cap_seconds':90,'future_algorithm_seconds':60,'future_shared_seconds':90,'future_maximum_calls':1,'retry_permitted':False,'source_controls_are_not_model_controls':True,'count_capacity_tables_used':False,'new_model_created':False,'solver_calls':0})
sites=load(EXP/'source-cogs.json');modes={family:[{**m,'relative_lower_left_bounds_by_row_mm':[next(r['relative_lower_left_bounds_mm'] for r in load(EXP/'row-modes.json') if r['row']==row and r['family']==family and r['mode']==m['mode']) for row in range(3)]} for m in load(FIRST/'family-modes.json')[family]] for family in ['bracket','insert']};inventory=load(PACKET/'inventory.json');library=load(FIRST/'geometry-library.json');cgmode=load(FIRST/'family-modes.json')['cog'][0];grid=100
groups=load(EXP/'rows.json');assert [len(g['source_indices']) for g in groups]==[4,4,4]
anchors=[]
for site in sites:
    t=site['transform'];assert t['rotation_radians']==cgmode['rotation_radians'] and t['mirrored']==cgmode['mirrored'];anchors.append([t['translation'][k]-cgmode['translation_from_lower_left'][k] for k in [0,1]])
job,spec=load(JOB),load(FIRST/'plan.json');fixed=load(FIRST/'fixed29.json');short=load(SHORT);missing=set(map(tuple,inventory['moving16_orthogonal_identities']));expected=[tuple(x) for x in inventory['full66_identities'] if tuple(x) not in missing]
controls=[{'control':0,'row_shifts_grid':[[0,0]]*3,'source':'reference50-source.json','source_checks':'reference50-checks.json'}]
for name in ['reference50-source.json','reference50-checks.json']:shutil.copyfile(EXP/name,OUT/name)
assert load(OUT/'reference50-checks.json')['valid'] and len(load(OUT/'reference50-source.json'))==50
square=np.asarray([[-.226,-.226],[.226,-.226],[.226,.226],[-.226,.226]])
def inflated(a,b):
    polys=[]
    for pa in a:
        for pb in b:
            differences=(np.asarray(pa)[:,None,:]-np.asarray(pb)[None,:,:]).reshape(-1,2)
            polys.append(MultiPoint((differences[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
    return unary_union(polys)
mover_records=[];obstacle_records=[]
for gid in range(10):
    aliases=[m for opts in modes.values() for m in opts if m['normalized_geometry']==gid];assert aliases
    nf=inflated(library[10]['pieces'],library[gid]['pieces'])
    for group in groups:
        ri=group['row'];bounds=[[max(F(m['relative_lower_left_bounds_by_row_mm'][ri][k][0]) for m in aliases),min(F(m['relative_lower_left_bounds_by_row_mm'][ri][k][1]) for m in aliases)] for k in [0,1]];domain=[bounds[0][0],bounds[1][0],bounds[0][1],bounds[1][1]]
        obstacles=[translate(nf,xoff=anchors[i][0],yoff=anchors[i][1]) for i in group['source_indices']]
        record={'row':ri,'geometry':gid,**partition(domain,obstacles)}
        write(OUT/'mover-rows'/f'{ri}-{gid:02d}.json',record);mover_records.append(record)
        obstacle_records.append({'row':ri,'geometry':gid,'obstacles':[mapping(p) for p in obstacles]})
    assert time.perf_counter()-started<30,'Fresh expanded-row geometry preparation closed at target.'
pair_nf=inflated(library[10]['pieces'],library[10]['pieces']);pair_records=[]
pair_domains=load(EXP/'pair-domains.json')
for ga,gb in combinations(groups,2):
    relative_bounds=[list(map(F,b)) for b in next(p['bounds_mm'] for p in pair_domains if p['rows']==[ga['row'],gb['row']])];domain=[relative_bounds[0][0],relative_bounds[1][0],relative_bounds[0][1],relative_bounds[1][1]]
    obstacles=[translate(pair_nf,xoff=anchors[a][0]-anchors[b][0],yoff=anchors[a][1]-anchors[b][1]) for a in ga['source_indices'] for b in gb['source_indices']]
    record={'rows':[ga['row'],gb['row']],'relative_coordinate':'shift_B_minus_shift_A',**partition(domain,obstacles)}
    write(OUT/'row-pairs'/f'{ga["row"]}-{gb["row"]}.json',record);pair_records.append(record)
    obstacle_records.append({'rows':record['rows'],'obstacles':[mapping(p) for p in obstacles]})
    assert time.perf_counter()-started<30,'Fresh inter-row geometry preparation target reached; no solver may open.'
for name,data in [('pair-domains.json',pair_domains),('source-cogs.json',sites),('rows.json',groups),('controls.json',controls),('family-modes.json',modes),('inventory.json',inventory),('obstacles.json',obstacle_records),('instances.json',[{'identity':x,'mode_count':len(modes[x[0]])} for x in inventory['moving16_orthogonal_identities']])]:write(OUT/name,data)
checks={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-started,'source_cog_rows':3,'source_row_sizes':[4,4,4],'independent_row_translation_variables':6,'source_orthogonal_modes':12,'source_mode_options':96,'mover_row_templates':len(mover_records),'mover_row_regions':sum(len(r['regions']) for r in mover_records),'row_pair_templates':len(pair_records),'row_pair_regions':sum(len(r['regions']) for r in pair_records),'source50_controls':1,'source_control_pairs_verified':856,'independent_source_region_audit_required':True,'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
