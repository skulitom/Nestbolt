"""Construct one deterministic partial row control from fresh certified regions."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-twelve-cog-row-integer-20261107';OUT=BASE/'row-control';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';SHORT=ROOT/'output/h5-first57-direct-short9-20261104/short9-source.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'geometry-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT,FIRST/'plan.json',FIRST/'fixed29.json']+[BASE/n for n in ['plan.json','rows.json','source-cogs.json','inventory.json','row-pair-templates.json','geometry-audit/plan.json','geometry-audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Prepare a partial positive control without any packing solver or old control input. Enumerate four floor/ceil grid neighbours of each fresh adjacent-row region vertex centroid and retain those satisfying its audited integer planes. Sort each adjacent-pair list by squared distance to zero, then region ID and point. Inspect the Cartesian product in that order and stop at its first member whose summed0/2 difference is inside a certified region and whose three distinct row domains admit a common base shift. Choose the lowest base per axis and lowest containing0/2 region ID. Verify all50 original placed outlines and holes. No minimum-spread or full66 claim.','preparation_stop_seconds':20,'maximum_calls':1,'packing_solver_calls':0,'retry_permitted':False})
templates={tuple(t['rows']):t['regions'] for t in load(BASE/'row-pair-templates.json')};groups=load(BASE/'rows.json');grid=100
def inside(point,region):return all(sum(c*v for c,v in zip(p['coefficients'],point))<=p['upper'] for p in region['planes'])
options={};rounding_candidates=0
for pair in [(0,1),(1,2)]:
    candidates=[]
    for r in templates[pair]:
        h=[list(map(F,p)) for p in r['hull_vertices']];center=[sum(p[k] for p in h)*grid/len(h) for k in [0,1]]
        for point in sorted(set(product(*[[math.floor(v),math.ceil(v)] for v in center]))):
            rounding_candidates+=1
            if inside(point,r):candidates.append({'region':r['region'],'difference_grid':list(point)})
    options[pair]=sorted(candidates,key=lambda r:(sum(v*v for v in r['difference_grid']),r['region'],r['difference_grid']))
write(OUT/'centroid-grid-options.json',{','.join(map(str,k)):v for k,v in options.items()})
examined=0;chosen=None
for a,b in product(options[(0,1)],options[(1,2)]):
    examined+=1;assert time.perf_counter()-started<20,'Closed control preparation limit reached.'
    offsets=[[0,0],a['difference_grid'],[a['difference_grid'][k]+b['difference_grid'][k] for k in [0,1]]]
    covered=[r['region'] for r in templates[(0,2)] if inside(offsets[2],r)]
    if not covered:continue
    base_bounds=[[max(g['shift_bounds_grid'][k][0]-p[k] for g,p in zip(groups,offsets)),min(g['shift_bounds_grid'][k][1]-p[k] for g,p in zip(groups,offsets))] for k in [0,1]]
    if any(lo>hi for lo,hi in base_bounds):continue
    base=[b[0] for b in base_bounds];shifts=[[base[k]+p[k] for k in [0,1]] for p in offsets]
    chosen={'row_shifts_grid':shifts,'row_pair_regions':[a['region'],min(covered),b['region']],'row_pair_differences_grid':[offsets[1],offsets[2],b['difference_grid']],'base_bounds_grid':base_bounds,'inspected_prefix':examined};break
assert chosen,'No control found in the declared finite centroid set.'
write(OUT/'selected-control.json',chosen)
rows=deepcopy(load(BASE/'source-cogs.json'))
for group,delta in zip(groups,chosen['row_shifts_grid']):
    assert all(lo<=v<=hi for v,(lo,hi) in zip(delta,group['shift_bounds_grid']))
    for i in group['source_indices']:rows[i]['transform']['translation']=[v+delta[k]/grid for k,v in enumerate(rows[i]['transform']['translation'])]
rows=load(FIRST/'fixed29.json')+rows+load(SHORT);job,spec=load(JOB),load(FIRST/'plan.json');inv=load(BASE/'inventory.json');missing=set(map(tuple,inv['moving16_orthogonal_identities']));expected=[tuple(x) for x in inv['full66_identities'] if tuple(x) not in missing]
check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
write(OUT/'candidate-source50.json',rows);write(OUT/'original-source-checks.json',check);assert check['valid'] and check['same_sheet_pairs']==856 and check['cutouts']==58 and check['hole_vertices']==6122
checks={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-started,'centroid_rounding_candidates':rounding_candidates,'adjacent_difference_combinations_checked':examined,'selected_row_shifts_grid':chosen['row_shifts_grid'],'source_valid50':True,'source_pairs':856,'stock_edges':200,'source_holes':58,'source_hole_vertices':6122,'all_three_integer_row_pair_regions_satisfied':True,'independent_control_audit_required':True,'packing_solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
