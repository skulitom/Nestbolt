"""Verify all integer implications and coordinate envelopes for independent rows."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-twelve-cog-row-integer-20261107';REG=ROOT/'output/h5-twelve-cog-row-regions-20261107';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';OUT=BASE/'geometry-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
floor=lambda v:v.numerator//v.denominator
ceil=lambda v:-floor(-v)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json']:queue.append(z)
assert load(REG/'source-region-audit/checks.json')['passed'];spec=load(BASE/'plan.json');grid=spec['grid_units_per_mm'];scale=spec['normal_scale'];origin=list(map(F,spec['world_origin_mm']));limits=list(map(F,spec['mover_relative_error_envelope_mm']));pair_limits=list(map(F,spec['row_pair_error_envelope_mm']))
assert grid==100 and scale==100000 and origin==[0,2100] and limits==[2000,1500] and pair_limits==[600,1100] and spec['plane_inset_mm']=='1/10000000' and spec['rectangle_gap_grid']==23
rows=load(BASE/'rows.json');assert rows==load(REG/'rows.json');assert len(rows)==3
for a in range(3):
    for b in range(a+1,3):
        for axis in [0,1]:
            lo=rows[b]['shift_bounds_grid'][axis][0]-rows[a]['shift_bounds_grid'][axis][1];hi=rows[b]['shift_bounds_grid'][axis][1]-rows[a]['shift_bounds_grid'][axis][0]
            assert -pair_limits[axis]*grid<=lo<=hi<=pair_limits[axis]*grid
modes=load(BASE/'family-modes.json');original=load(REG/'family-modes.json');mode_count=0
for family,opts in modes.items():
    assert len(opts)==len(original[family])
    for m,source in zip(opts,original[family]):
        assert {k:v for k,v in m.items() if k not in ['integer_world_lower_left_bounds','integer_relative_lower_left_bounds_by_row']}==source
        for axis in [0,1]:
            a,b=map(F,source['lower_left_bounds'][axis]);lo,hi=m['integer_world_lower_left_bounds'][axis]
            assert [lo,hi]==[ceil((a-origin[axis])*grid),floor((b-origin[axis])*grid)]
            assert F(lo,grid)+origin[axis]>=a and F(hi,grid)+origin[axis]<=b
        assert len(m['integer_relative_lower_left_bounds_by_row'])==3
        for ri,row in enumerate(rows):
            for axis in [0,1]:
                a,b=map(F,source['relative_lower_left_bounds_by_row_mm'][ri][axis]);lo,hi=m['integer_relative_lower_left_bounds_by_row'][ri][axis]
                assert [lo,hi]==[ceil((a-origin[axis])*grid),floor((b-origin[axis])*grid)]
                assert F(lo,grid)+origin[axis]>=a and F(hi,grid)+origin[axis]<=b
                wl,wh=m['integer_world_lower_left_bounds'][axis];sl,sh=row['shift_bounds_grid'][axis]
                assert [lo,hi]==[wl-sh,wh-sl] and -limits[axis]*grid<=lo<=hi<=limits[axis]*grid
        mode_count+=1
planes=0;insets=[];activities=[]
def check_region(actual,source,offset,envelope):
    global planes
    assert {k:v for k,v in actual.items() if k!='planes'}==source
    poly=[tuple(map(F,p)) for p in source['hull_vertices']];assert len(actual['planes'])==len(poly)>=3
    for edge,(a,b,p) in enumerate(zip(poly,poly[1:]+poly[:1],actual['planes'])):
        dx,dy=b[0]-a[0],b[1]-a[1];den=max(abs(dx),abs(dy));normal=[dy/den,-dx/den]
        assert p['edge']==edge and F(p['normalization_denominator'])==den and list(map(F,p['exact_infinity_normal']))==normal
        raw=p['unreduced_coefficients'];div=p['divisor'];co=p['coefficients'];assert div>0 and all(c*div==v for c,v in zip(co,raw))
        error=sum(abs(normal[k]-F(raw[k],scale))*envelope[k] for k in [0,1]);assert error==F(p['rounding_error_bound_mm'])
        rhs=sum(normal[k]*(a[k]-offset[k]) for k in [0,1]);upper=p['upper'];assert upper==floor((rhs-error-F('1e-7'))*scale*grid)//div
        inset=rhs-(F(div*upper,scale*grid)+error);assert inset>=F('1e-7');insets.append(inset)
        activity=sum(abs(c)*int(v*grid) for c,v in zip(co,envelope));assert activity<2**53 and abs(upper)<2**53;activities.append(activity);planes+=1
mover=load(REG/'source-region-audit/rounded-mover-regions.json');pairs=load(REG/'source-region-audit/rounded-row-pair-regions.json');templates=load(BASE/'mover-row-templates.json');pt=load(BASE/'row-pair-templates.json')
assert [(t['row'],t['geometry']) for t in templates]==[(row,gid) for row in range(3) for gid in range(10)]
for t in templates:
    expected=[{k:v for k,v in r.items() if k not in ['row','geometry']} for r in mover if r['row']==t['row'] and r['geometry']==t['geometry']]
    assert len(expected)==len(t['regions'])
    for a,b in zip(t['regions'],expected):check_region(a,b,origin,limits)
assert [t['rows'] for t in pt]==[[0,1],[0,2],[1,2]]
for t in pt:
    expected=[{k:v for k,v in r.items() if k!='rows'} for r in pairs if r['rows']==t['rows']];assert len(expected)==len(t['regions'])
    for a,b in zip(t['regions'],expected):check_region(a,b,[F(0),F(0)],pair_limits)
rectangles=load(BASE/'mode-rectangles.json');old_rect=load(PRIOR/'rigid-rectangle-preflight/mode-rectangles.json');rectangle_count=0;padding=[]
for family,opts in rectangles.items():
    assert len(opts)==len(old_rect[family])
    for actual,old in zip(opts,old_rect[family]):
        assert {k:v for k,v in actual.items() if k!='rectangles'}=={k:v for k,v in old.items() if k!='rectangles'} and len(actual['rectangles'])==len(old['rectangles'])
        for a,b in zip(actual['rectangles'],old['rectangles']):
            assert {k:v for k,v in a.items() if k!='outward_offsets_grid'}==b
            for i,(raw,tick) in enumerate(zip(a['exact_affine_bounds_mm'],a['outward_offsets_grid'])):
                value=F(raw);assert tick==(floor(value*grid) if i<2 else ceil(value*grid));extra=value-F(tick,grid) if i<2 else F(tick,grid)-value;assert 0<=extra<F('.01');padding.append(extra)
            rectangle_count+=1
for name in ['rows.json','source-cogs.json','instances.json','inventory.json','controls.json','pair-domains.json']:assert digest(BASE/name)==digest(REG/name)
instances=load(BASE/'instances.json');inv=load(BASE/'inventory.json')
assert [r['identity'] for r in instances]==inv['moving16_orthogonal_identities'] and len(instances)==16
assert sum(r['mode_count'] for r in instances)==96
components=load(BASE/'components.json');expected=[]
for owner,r in enumerate(instances):
    counts={len(m['rectangles']) for m in rectangles[r['identity'][0]]};assert len(counts)==1
    for piece in range(next(iter(counts))):expected.append({'component':len(expected),'owner':owner,'identity':r['identity'],'piece':piece})
assert components==expected and len(components)==24
pairs=load(BASE/'component-pairs.json');expected_pairs=[]
for ai in range(len(components)):
    for bi in range(ai+1,len(components)):
        a,b=components[ai],components[bi]
        if a['owner']!=b['owner']:expected_pairs.append({'components':[ai,bi],'owners':[a['owner'],b['owner']]})
assert pairs==expected_pairs and len(pairs)==268
assert planes==load(BASE/'checks.json')['integer_planes'];write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),REG/'source-region-audit/plan.json',REG/'source-region-audit/checks.json',REG/'source-region-audit/rounded-mover-regions.json',REG/'source-region-audit/rounded-row-pair-regions.json']+[p for p in BASE.glob('*.json')]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently reconstruct all source mode domains and each exact source hull halfplane. Verify inward coefficient rounding over both relative-coordinate envelopes, including negative coordinates; prove every world-bound coordinate minus any admissible row shift lies inside the mover envelope and every row-shift difference lies inside the row-pair envelope. Verify complete retained region correspondence, rigid outward source rectangles, all96 mode options and all original identities. Future model coefficients must preserve the two different relative-coordinate definitions.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_modes_verified':mode_count,'orthogonal_instances_verified':len(instances),'rigid_components_verified':len(components),'different_owner_component_pairs_verified':len(pairs),'row_specific_relative_domains_verified':3*mode_count,'mover_row_regions_verified':len(mover),'row_pair_regions_verified':len(pairs),'exact_integer_plane_implications':planes,'minimum_certified_inset_mm':float(min(insets)),'maximum_integer_relative_plane_activity':max(activities),'mode_component_rectangles_verified':rectangle_count,'maximum_outward_padding_mm':float(max(padding)),'relative_coordinate_envelopes_verified':True,'row_shift_difference_envelope_verified':True,'source_identity_and_domain_files_preserved':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
