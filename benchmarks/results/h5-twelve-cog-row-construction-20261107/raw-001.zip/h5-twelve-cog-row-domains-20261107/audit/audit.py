"""Independent exact-domain and original-polygon readback for individual rows."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations, product
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json, math, shutil, time
from shapely.geometry import Polygon

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-twelve-cog-row-domains-20261107';OUT=BASE/'audit'
PROCESS=ROOT/'output/h5-twelve-cog-row-domains-process-20261107'
PRE=ROOT/'output/h5-first57-direct-short9-20261104'
FIRST=PRE
SHORT=PRE/'short9-source.json'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name
        bindings[name]=h
        if z.name in ['plan.json','opened.json']:queue.append(z)
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(FIRST/'plan.json')
cogs=load(BASE/'source-cogs.json');sites=load(PRE/'source-cog-sites.json')
assert len(cogs)==12
for i,(r,site) in enumerate(zip(cogs,[s for i,s in enumerate(sites) if i%5<4])):
    assert r['part_id']=='cog' and r['copy_index']==i+1
    assert {k:v for k,v in r.items() if k!='copy_index'}=={k:v for k,v in site.items() if k!='copy_index'}
fixed=load(FIRST/'fixed29.json');short=load(SHORT);inventory=load(BASE/'inventory.json')
assert inventory==load(PRE/'inventory.json') and load(PRE/'audit/checks.json')['passed']
full={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
missing=set(map(tuple,inventory['moving16_orthogonal_identities']))
assert len(full)==66 and full==set(map(tuple,inventory['full66_identities']))
assert {(r['part_id'],r['copy_index']) for r in fixed+cogs+short}|missing==full
assert len(fixed+cogs+short)==50 and len(missing)==16
def exact_vertices(r):
    t=r['transform'];c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));tx,ty=map(F,t['translation']);sign=-1 if t['mirrored'] else 1
    return [(tx+sign*F(x)*c-F(y)*s,ty+sign*F(x)*s+F(y)*c) for x,y in parts[r['part_id']]['geometry'][0]['outer']]
stock=list(map(F,spec['construction_stock']));extra=F(1,40);eps=F(1,1000000);grid=100
safe=[stock[0]+extra,stock[1]+extra,stock[2]-extra,stock[3]-extra]
domain=load(BASE/'domain.json');assert list(map(F,domain['safe_world_bounds_mm']))==safe
assert domain['grid_units_per_mm']==grid and domain['inter_row_safety_not_proven'] and domain['independent_row_bounds_are_not_a_joint_feasible_domain']
assert domain['reference50_is_not_yet_a_model_control']
top=max(v[1] for r in fixed for v in exact_vertices(r));levels=sorted({r['transform']['translation'][1] for r in cogs})
rows=load(BASE/'rows.json');assert len(rows)==3
clearances=[]
for ri,(row,y) in enumerate(zip(rows,levels)):
    indices=[i for i,r in enumerate(cogs) if r['transform']['translation'][1]==y]
    assert row['row']==ri and row['source_indices']==indices==list(range(ri*4,ri*4+4)) and row['reference_y_mm']==y
    assert row['reference_sites']==list(range(ri*5,ri*5+4))
    assert row['source_identities']==[[cogs[i]['part_id'],cogs[i]['copy_index']] for i in indices]
    vertices=[v for i in indices for v in exact_vertices(cogs[i])]
    box=[min(v[k] for v in vertices) for k in [0,1]]+[max(v[k] for v in vertices) for k in [0,1]]
    assert list(map(F,row['source_row_bounds_mm']))==box
    for k,(lo,hi) in enumerate(row['shift_bounds_grid']):
        assert F(lo,grid)>=safe[k]-box[k]+eps>F(lo-1,grid)
        assert F(hi,grid)<=safe[k+2]-box[k+2]-eps<F(hi+1,grid)
        assert list(map(F,row['shift_bounds_mm'][k]))==[F(lo,grid),F(hi,grid)]
    clearance=box[1]+F(row['shift_bounds_grid'][1][0],grid)-top
    assert clearance>F(spec['required_pair_gap_mm']);clearances.append(float(clearance))
assert [len(r['source_indices']) for r in rows]==[4,4,4]
assert F(domain['core_top_mm'])==top and safe[1]-top>F(spec['required_pair_gap_mm'])
realstock=list(map(F,spec['source_stocks']['sheet-0']))
assert min(safe[0]-realstock[0],safe[1]-realstock[1],realstock[2]-safe[2],realstock[3]-safe[3])>F(spec['stock_guard_mm'])
base_modes=load(FIRST/'family-modes.json');modes=load(BASE/'row-modes.json');keys=set()
for mode in modes:
    key=(mode['row'],mode['family'],mode['mode']);assert key not in keys;keys.add(key)
    original=next(m for m in base_modes[mode['family']] if m['mode']==mode['mode'])
    assert {k:v for k,v in mode.items() if k not in ['row','family','relative_lower_left_bounds_mm']}==original
    shift=rows[mode['row']]['shift_bounds_grid']
    for k,(lo,hi) in enumerate(mode['relative_lower_left_bounds_mm']):
        assert F(lo)==F(original['lower_left_bounds'][k][0])-F(shift[k][1],grid)
        assert F(hi)==F(original['lower_left_bounds'][k][1])-F(shift[k][0],grid)
assert keys=={(ri,family,m['mode']) for ri in range(3) for family in ['bracket','insert'] for m in base_modes[family]} and len(keys)==36
pairs=load(BASE/'pair-domains.json');assert len(pairs)==3
for p,(a,b) in zip(pairs,combinations(range(3),2)):
    assert p['rows']==[a,b] and p['relative_coordinate']=='shift_B_minus_shift_A'
    for k,bounds in enumerate(p['bounds_grid']):
        assert bounds==[rows[b]['shift_bounds_grid'][k][0]-rows[a]['shift_bounds_grid'][k][1],rows[b]['shift_bounds_grid'][k][1]-rows[a]['shift_bounds_grid'][k][0]]
        assert list(map(F,p['bounds_mm'][k]))==[F(v,grid) for v in bounds]
counts={'pairs':0,'stock_edges':0,'holes':0,'hole_vertices':0};min_gap=math.inf;min_stock=math.inf
def source_check(source,previous,expected):
    global min_gap,min_stock
    assert len(source)==len(expected) and {(r['part_id'],r['copy_index']) for r in source}==set(expected)
    shapes=[];local={k:0 for k in counts};lgap=lstock=math.inf
    for r in source:
        part=parts[r['part_id']];t=r['transform'];angle=t['rotation_radians']
        assert not t['mirrored'] or part['allow_mirror']
        assert part['rotations']['kind']=='free' or any(abs(math.remainder(angle-math.radians(v),math.tau))<1e-12 for v in part['rotations']['degrees'])
        c,s=math.cos(angle),math.sin(angle);sign=-1 if t['mirrored'] else 1
        def ring(points):return [(sign*x*c-y*s+t['translation'][0],sign*x*s+y*c+t['translation'][1]) for x,y in points]
        g=part['geometry'][0];outer=Polygon(ring(g['outer']));material=Polygon(ring(g['outer']),[ring(h) for h in g.get('holes',[])])
        assert outer.is_valid and material.is_valid and abs(material.area-Polygon(g['outer'],g.get('holes',[])).area)<1e-6
        bounds=outer.bounds;st=spec['source_stocks'][r['sheet_id']];margin=min(bounds[0]-st[0],bounds[1]-st[1],st[2]-bounds[2],st[3]-bounds[3])
        assert margin>spec['stock_guard_mm'];lstock=min(lstock,margin);local['stock_edges']+=4
        local['holes']+=len(g.get('holes',[]));local['hole_vertices']+=sum(len(h) for h in g.get('holes',[]));shapes.append((r['sheet_id'],outer))
    for (sa,a),(sb,b) in combinations(shapes,2):
        if sa!=sb:continue
        gap=a.distance(b);assert a.disjoint(b) and gap>spec['required_pair_gap_mm'];lgap=min(lgap,gap);local['pairs']+=1
    assert previous['valid'] and previous['originals']==len(source) and previous['same_sheet_pairs']==local['pairs']
    assert previous['cutouts']==local['holes'] and previous['hole_vertices']==local['hole_vertices']
    assert abs(previous['minimum_pair_gap_mm']-lgap)<1e-12 and abs(previous['minimum_extra_stock_mm']-lstock)<1e-12
    for k,v in local.items():counts[k]+=v
    min_gap=min(min_gap,lgap);min_stock=min(min_stock,lstock)
controls=load(BASE/'controls.json');assert len(controls)==12
for ri,row in enumerate(rows):
    for ci,delta in enumerate(product(*row['shift_bounds_grid'])):
        control=controls[ri*4+ci];assert control['row']==ri and control['corner']==ci and control['shift_grid']==list(delta)
        moved=deepcopy([cogs[i] for i in row['source_indices']])
        for r in moved:r['transform']['translation']=[v+delta[k]/grid for k,v in enumerate(r['transform']['translation'])]
        source=load(BASE/control['source']);assert source==fixed+moved+short
        source_check(source,load(BASE/control['source_checks']),[(r['part_id'],r['copy_index']) for r in fixed+moved+short])
assert counts['pairs']==6768
shared=load(BASE/'reference50-source.json');assert shared==fixed+cogs+short
source_check(shared,load(BASE/'reference50-checks.json'),full-missing)
process=load(PROCESS/'prepare.json');opened=load(PROCESS/'opened.json');check=load(BASE/'checks.json')
assert process['passed'] and process['exit_code']==0 and process['job']['closed'] and process['job']['active_processes']==0
assert process['complete_seconds']>=check['seconds_including_source_controls']
assert process['complete_seconds']<=30 and check['seconds_including_source_controls']<=20
for p,h in opened['inputs'].items():assert digest(ROOT/p)==h
assert not opened['repeat_permitted']
inputs=[Path(__file__)]+list(BASE.glob('*.json'))+[PROCESS/n for n in ['opened.json','prepare.json','prepare-job.json','prepare-stdout.txt','prepare-stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independent exact affine extrema and neighbouring excluded-grid-point verification for every individual row. Prove stock containment and vertical fixed-core separation over each entire row box. Verify original identity/mode partitions and all36 mover-minus-row domains and3 row differences. Independently reconstruct every original filled outline and cutout for12 individual-row corner controls and the reference50 control; test every same-sheet pair and stock edge. The Cartesian product of row boxes is NOT asserted collision-free.'})
write(OUT/'source-bindings.json',bindings)
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_input_bindings_verified':len(bindings),
        'individual_row_boxes_verified':3,'row_sizes':[4,4,4],'individual_shift_bounds_grid':[r['shift_bounds_grid'] for r in rows],
        'continuous_stock_and_core_separation_verified':True,'continuous_core_clearances_mm':clearances,
        'row_source_mode_domains_verified':36,'row_pair_difference_domains_verified':3,
        'individual_row_controls_verified':12,'reference_source50_controls_verified':1,**counts,
        'minimum_source_gap_mm':min_gap,'minimum_extra_stock_mm':min_stock,'complete_preparation_process_seconds':process['complete_seconds'],
        'all66_identities_verified':True,'joint_inter_row_feasibility_claimed':False,'fresh_interaction_regions_required':True,
        'source_valid66':False,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
