from pathlib import Path
R=Path(__file__).resolve().parents[1]
def write(name,s):
    with (R/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def rename(s):
    return s.replace('h5-expanded-cog-row-integer-20261104','h5-twelve-cog-row-integer-20261107').replace('h5-first55-after-source-valid11-20261029','h5-first57-direct-short9-20261104').replace('moving13_orthogonal_identities','moving16_orthogonal_identities')
process_names="process_names={key:'h5-twelve-cog-row-'+name+'-process-20261107' for key,name in [('row_domains_complete_preparation_seconds','domains'),('row_regions_complete_preparation_seconds','regions'),('row_integer_complete_preparation_seconds','integer'),('row_control_complete_preparation_seconds','control')]}\n"
charges="""charges={'fixed_source_mode_geometry_preparation_seconds':load(ROOT/'output/h5-first55-after-source-valid11-20261029/checks.json')['seconds'],
    'source_cog_site_preparation_seconds':load(SLOTS/'checks.json')['seconds'],
    'source_rectangle_preparation_seconds':load(PRIOR/'rigid-rectangle-preflight/checks.json')['seconds'],
    'direct_short9_and_inventory_complete_process_seconds':load(ROOT/'output/h5-first57-direct-short9-process-20261104/process.json')['complete_process_seconds'],
    **{key:load(ROOT/'output'/name/'prepare.json')['complete_seconds'] for key,name in process_names.items()},
    'cp_model_build_seconds':BUILD_TIME}
"""
inputs="""inputs=[Path(__file__),ROOT/'output/h5-first55-after-source-valid11-20261029/checks.json',SLOTS/'checks.json',PRIOR/'rigid-rectangle-preflight/checks.json',
    ROOT/'output/h5-first57-direct-short9-process-20261104/opened.json',ROOT/'output/h5-first57-direct-short9-process-20261104/process.json',
    CONTROL/'plan.json',CONTROL/'selected-control.json',CONTROL/'audit/plan.json',CONTROL/'audit/checks.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json']+[p for p in BASE.glob('*.json')]+[ROOT/'output'/name/file for name in process_names.values() for file in ['opened.json','prepare.json','process.json']]
"""
s=rename((R/'output/build_h5_expanded_cog_row_model_20261104.py').read_text(encoding='utf-8'))
s=s.replace('list(range(26,32))','list(range(32,38))')
a=s.index('process_names=');b=s.index("write(OUT/'plan.json'",a)
s=s[:a]+process_names+charges.replace('BUILD_TIME','elapsed')+"write(OUT/'preparation-charges.json',charges)\n"+inputs+s[b:]
s=s.replace('All13 orthogonal originals have independent world positions and all80 source modes','All16 orthogonal originals have independent world positions and all96 source modes').replace('All20 orthogonal component rectangles','All24 orthogonal component rectangles')
s=s.replace('substantially enlarged from the previously closed restricted-row model','for the new4/4/4-row source allocation with short9; prior13-cog/short11 solver results are not consumed')
s=s.replace('Charge source-valid short11, source/core preparation, expanded individual row domains, fresh row geometry, integer/control preparation and complete model build','Charge direct source-valid short9 and its complete process, fixed source mode geometry, reference sites, source rectangles, all new row domain/geometry/integer/control complete preparation processes and complete model build')
s=s.replace("'orthogonal_originals':13,'row_cog_originals':13,'source_mode_selectors':80", "'orthogonal_originals':16,'row_cog_originals':12,'source_mode_selectors':96")
write('build_h5_twelve_cog_row_model_20261107.py',s)
s=rename((R/'output/audit_h5_expanded_cog_row_model_20261104.py').read_text(encoding='utf-8'))
s=s.replace('len(owners)==13','len(owners)==16').replace('list(range(13))','list(range(12))').replace('32<=sel<112','38<=sel<134').replace("[26+2*row['row'],27+2*row['row']]","[32+2*row['row'],33+2*row['row']]").replace('len(components)==20','len(components)==24').replace('len(separations)==183','len(separations)==268').replace('combinations(range(20),2)','combinations(range(24),2)').replace('links==544 and mode_count==80','links==640 and mode_count==96')
a=s.index('process_names=');b=s.index("inputs=[Path(__file__),BASE/'geometry-audit",a)
s=s[:a]+process_names+charges.replace('BUILD_TIME',"load(MODEL/'checks.json')['seconds']")+"""assert charges==load(MODEL/'preparation-charges.json') and sum(charges.values())==load(MODEL/'checks.json')['preparation_seconds_charged']
process=load(MODEL/'build-process.json');assert process['exit_code']==0 and process['job']['closed'] and process['job']['active_processes']==0 and process['complete_process_seconds']>=charges['cp_model_build_seconds']
for name,h in process['inputs'].items():assert digest(ROOT/name)==h
assert process['script_sha256']==digest(ROOT/'output/build_h5_twelve_cog_row_model_20261107.py')
charges['cp_model_build_seconds']=process['complete_process_seconds']
assert charges==load(MODEL/'final-preparation-charges.json') and sum(charges.values())==load(MODEL/'budget.json')['preparation_seconds_charged']
for name in process_names.values():
    record=load(ROOT/'output'/name/'process.json');assert record['passed'] and record['closed'] and all(r['passed'] and r['job']['active_processes']==0 for r in record['stages'])
"""+s[b:]
s=s.replace("'orthogonal_originals_verified':13,'row_cog_originals_verified':13", "'orthogonal_originals_verified':16,'row_cog_originals_verified':12").replace("'rigid_components_verified':20", "'rigid_components_verified':24").replace("'different_owner_rectangle_pairs_verified':183", "'different_owner_rectangle_pairs_verified':268")
write('audit_h5_twelve_cog_row_model_20261107.py',s)
s="""from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];MODEL=ROOT/'output/h5-twelve-cog-row-integer-20261107/model';OUT=ROOT/'output/h5-twelve-cog-row-model-process-20261107'
SCRIPT=ROOT/'output/build_h5_twelve_cog_row_model_20261107.py';AUDIT=ROOT/'output/audit_h5_twelve_cog_row_model_20261107.py';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
assert not MODEL.exists();OUT.mkdir();controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
inputs={p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),SCRIPT,AUDIT,EXE,EXE.parent/'checks.json']}
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'build_cap_seconds':30,'audit_cap_seconds':90,'memory_bytes':2*1024**3,'maximum_calls':1,'retry_permitted':False})
records=[];started=time.perf_counter()
for stage,script,cap in [('build',SCRIPT,30),('audit',AUDIT,90)]:
    args=[str(EXE),str(cap*1000),str(2*1024**3),str(OUT/(stage+'-job.json')),str(OUT/(stage+'-stdout.txt')),str(OUT/(stage+'-stderr.txt')),str(OUT/(stage+'-stop')),subprocess.list2cmdline([str(PY),str(script)]),str(ROOT),'version4']
    t=time.perf_counter();r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=cap+8);elapsed=time.perf_counter()-t
    (OUT/(stage+'-runner-stdout.txt')).write_bytes(r.stdout);(OUT/(stage+'-runner-stderr.txt')).write_bytes(r.stderr)
    job=load(OUT/(stage+'-job.json'));passed=r.returncode==0 and job['closed'] and job['active_processes']==0 and job['reason_code']==job['error_code']==0
    record={'stage':stage,'exit_code':r.returncode,'complete_seconds':elapsed,'job':job,'passed':passed};records.append(record);write(OUT/(stage+'.json'),record);print(record,flush=True)
    if stage=='build' and MODEL.exists():
        write(MODEL/'build-process.json',{'utc':datetime.now(timezone.utc).isoformat(),'script_sha256':digest(SCRIPT),'complete_process_seconds':elapsed,'exit_code':r.returncode,'inputs':inputs,'job':job})
    if not passed:break
    if stage=='build':
        charges=load(MODEL/'preparation-charges.json');assert elapsed>=charges['cp_model_build_seconds'];charges['cp_model_build_seconds']=elapsed
        write(MODEL/'final-preparation-charges.json',charges)
        write(MODEL/'budget.json',{'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False,'preparation_seconds_charged':sum(charges.values()),'complete_geometry_and_model_process_times_charged':True,'count_capacity_tables_used':False})
write(OUT/'process.json',{'closed':True,'complete_seconds':time.perf_counter()-started,'stages':records,'passed':len(records)==2 and all(r['passed'] for r in records),'retry_permitted':False})
"""
write('run_h5_twelve_cog_row_model_build_20261107.py',s)
print({'prepared':True})
