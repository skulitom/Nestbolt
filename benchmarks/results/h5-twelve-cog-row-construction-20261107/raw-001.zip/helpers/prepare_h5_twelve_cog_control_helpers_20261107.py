from pathlib import Path
R=Path(__file__).resolve().parents[1]
def write(name,s):
    with (R/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def rename(s):
    s=s.replace('h5-expanded-cog-row-integer-20261104','h5-twelve-cog-row-integer-20261107').replace('h5-expanded-cog-row-control-process-20261104','h5-twelve-cog-row-control-process-20261107').replace('h5-first55-after-source-valid11-20261029','h5-first57-direct-short9-20261104').replace('h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json','h5-first57-direct-short9-20261104/short9-source.json').replace('moving13_orthogonal_identities','moving16_orthogonal_identities').replace('source53','source50').replace('source_valid53','source_valid50')
    s=s.replace('==916','==856').replace('==63','==58').replace('==6732','==6122').replace("'source_pairs':916", "'source_pairs':856").replace("'stock_edges':212", "'stock_edges':200").replace("'source_holes':63", "'source_holes':58").replace("'source_hole_vertices':6732", "'source_hole_vertices':6122").replace("'stock_edges_verified':212", "'stock_edges_verified':200")
    return s.replace('all53 original','all50 original').replace('len(expected_ids)==53','len(expected_ids)==50').replace('all916 same-sheet pairs,212 stock edges and the full53 identity set','all856 same-sheet pairs,200 stock edges and the full50 identity set').replace('13 orthogonal originals remain unplaced','16 orthogonal originals remain unplaced')
s=rename((R/'output/prepare_h5_expanded_cog_row_control_20261104.py').read_text(encoding='utf-8'))
write('prepare_h5_twelve_cog_row_control_20261107.py',s)
s=rename((R/'output/audit_h5_expanded_cog_row_control_20261104.py').read_text(encoding='utf-8'))
a=s.index("process=load(PROCESS/");b=s.index('inputs=[Path(__file__)',a)
s=s[:a]+"""process=load(PROCESS/'prepare.json');opened=load(PROCESS/'opened.json')
assert process['passed'] and process['exit_code']==0 and process['job']['closed'] and process['job']['active_processes']==0
assert process['complete_seconds']<=30 and process['complete_seconds']>=load(CONTROL/'checks.json')['seconds_including_evidence_serialization']
assert load(CONTROL/'checks.json')['seconds_including_evidence_serialization']<=20
for p,h in opened['inputs'].items():assert digest(ROOT/p)==h
assert not opened['repeat_permitted']
"""+s[b:]
s=s.replace("['opened.json','process.json','stdout.txt','stderr.txt']", "['opened.json','prepare.json','prepare-job.json','prepare-stdout.txt','prepare-stderr.txt']").replace("process['complete_process_seconds']", "process['complete_seconds']")
write('audit_h5_twelve_cog_row_control_20261107.py',s)
s=(R/'output/run_h5_twelve_cog_row_integer_20261107.py').read_text(encoding='utf-8').replace('h5-twelve-cog-row-integer-process','h5-twelve-cog-row-control-process').replace('prepare_h5_twelve_cog_row_integer','prepare_h5_twelve_cog_row_control').replace('audit_h5_twelve_cog_row_integer','audit_h5_twelve_cog_row_control')
write('run_h5_twelve_cog_row_control_20261107.py',s)
print({'prepared':True})
