from pathlib import Path
R=Path(__file__).resolve().parents[1]
def write(name,s):
    with (R/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def rename(s):
    return s.replace('h5-expanded-cog-row-integer-20261104','h5-twelve-cog-row-integer-20261107').replace('h5-first55-after-source-valid11-20261029','h5-first57-direct-short9-20261104').replace('h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json','h5-first57-direct-short9-20261104/short9-source.json').replace('check_h5_expanded_cog_row_candidate_20261104.py','check_h5_twelve_cog_row_candidate_20261107.py').replace('h5-translated-cog-packet-preflight-20261104','h5-twelve-cog-row-domains-20261107').replace('packet-source13.json','source-cogs.json').replace('1540','1632')
s=rename((R/'output/check_h5_expanded_cog_row_candidate_20261104.py').read_text(encoding='utf-8'))
s=s.replace("'first_originals':55,'short_originals':11", "'first_originals':57,'short_originals':9")
write('check_h5_twelve_cog_row_candidate_20261107.py',s)
s=rename((R/'output/run_h5_expanded_cog_row_model_20261104.py').read_text(encoding='utf-8'))
s=s.replace('on a micrometre grid','on a0.01mm grid')
a=s.index('    try:\n',s.index('def main():'));b=s.index("    write(OUT / 'process.json', summary)",a)
s=s[:a]+"""    exe=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe'
    controls=load(exe.parent/'checks.json');assert controls['passed'] and digest(exe)==controls['runner_sha256']
    cap=max(1,int((90-(time.perf_counter()-start))*1000))
    write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),exe,exe.parent/'checks.json']},'maximum_ms':cap,'aggregate_memory_bytes':2*1024**3,'preparation_seconds_charged':charge,'retry_permitted':False})
    cmd=subprocess.list2cmdline([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child',str(start)])
    args=[str(exe),str(cap),str(2*1024**3),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),cmd,str(ROOT),'version4']
    completed=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=cap/1000+8)
    (OUT/'supervisor-stdout.txt').write_bytes(completed.stdout);(OUT/'supervisor-stderr.txt').write_bytes(completed.stderr)
    job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0
    summary={'seconds_including_preparation':time.perf_counter()-start,'exit_code':completed.returncode,'timeout':job['reason_code']==1,'closed':True,'job':job,'tree_closed':True,'repeat_permitted':False}
"""+s[b:]
write('run_h5_twelve_cog_row_model_20261107.py',s)
s=rename((R/'output/audit_h5_expanded_cog_row_response_20261104.py').read_text(encoding='utf-8'))
s=s.replace("assert charges['source_valid_short11_shared_seconds']==load(ROOT/'output/h5-short11-integer-mode-regions-20261029/response-audit/checks.json')['shared_seconds_including_preparation']", """assert charges['direct_short9_and_inventory_complete_process_seconds']==load(ROOT/'output/h5-first57-direct-short9-process-20261104/process.json')['complete_process_seconds']
assert process['job']['closed'] and process['job']['active_processes']==0 and process['job']['reason_code']==process['job']['error_code']==0 and process['tree_closed']
supervisor=load(SEARCH/'supervisor-opened.json')
for name,h in supervisor['inputs'].items():assert digest(ROOT/name)==h
assert supervisor['aggregate_memory_bytes']==2*1024**3 and not supervisor['retry_permitted'] and supervisor['preparation_seconds_charged']==charge""")
s=s.replace("'closed_solver_calls':1", "'closed_solver_calls':1,'windows_job_descendants_closed':True")
write('audit_h5_twelve_cog_row_response_20261107.py',s)
print({'prepared':True})
