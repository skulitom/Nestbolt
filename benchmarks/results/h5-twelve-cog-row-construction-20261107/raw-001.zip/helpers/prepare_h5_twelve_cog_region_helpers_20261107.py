"""Prepare fresh constructive regions and source support certificates for 12 cogs."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def write(name,s):
    with (R/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def rename(s):
    return s.replace('h5-expanded-cog-row-regions-20261104','h5-twelve-cog-row-regions-20261107').replace('h5-individual-cog-row-domains-20261104','h5-twelve-cog-row-domains-20261107').replace('h5-translated-cog-packet-preflight-20261104','h5-twelve-cog-row-domains-20261107').replace('h5-first55-after-source-valid11-20261029','h5-first57-direct-short9-20261104').replace('h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json','h5-first57-direct-short9-20261104/short9-source.json').replace('moving13_orthogonal_identities','moving16_orthogonal_identities').replace('[5,4,4]','[4,4,4]').replace('5/4/4-cog','4/4/4-cog').replace('prepare_h5_expanded_cog_row_region_helpers_20261104.py','prepare_h5_twelve_cog_region_helpers_20261107.py')
s=rename((R/'output/prepare_h5_expanded_cog_row_regions_20261104.py').read_text(encoding='utf-8'))
s=s.replace("['plan.json','packet-source13.json','inventory.json','translation-domain.json','audit/plan.json','audit/checks.json']", "['plan.json','source-cogs.json','inventory.json','domain.json','reference50-source.json','reference50-checks.json','audit/plan.json','audit/checks.json']")
s=s.replace("sites=load(PACKET/'packet-source13.json');packet=load(PACKET/'translation-domain.json');", "sites=load(EXP/'source-cogs.json');")
s=s.replace("grid=packet['shift_grid_units_per_mm'];shift=packet['shift_bounds_grid'];assert grid==100", 'grid=100')
a=s.index('controls=[];base_y=');b=s.index('square=np.asarray',a)
s=s[:a]+"""controls=[{'control':0,'row_shifts_grid':[[0,0]]*3,'source':'reference50-source.json','source_checks':'reference50-checks.json'}]
for name in ['reference50-source.json','reference50-checks.json']:shutil.copyfile(EXP/name,OUT/name)
assert load(OUT/'reference50-checks.json')['valid'] and len(load(OUT/'reference50-source.json'))==50
"""+s[b:]
s=s.replace('Preserve four common-shift53 controls without claiming they satisfy the inflated model. The closed restricted-row UNKNOWN model is not reused or rerun.', 'Preserve the independently checked simultaneous reference50 control without claiming it satisfies the inflated model or row grid bounds. The closed13-cog/short11 models are not reused or rerun; this model uses12 cogs and16 orthogonal companions with short9.')
s=s.replace("'source_mode_options':80", "'source_mode_options':96").replace("'source53_controls':4,'source_control_pairs_verified':3664", "'source50_controls':1,'source_control_pairs_verified':856")
write('prepare_h5_twelve_cog_row_regions_20261107.py',s)
s=rename((R/'output/audit_h5_expanded_cog_row_regions_20261104.py').read_text(encoding='utf-8'))
s=s.replace("PRE/'packet-source13.json'", "PRE/'source-cogs.json'").replace("PRE/'translation-domain.json'", "PRE/'domain.json'").replace("sum(r['mode_count'] for r in instances)==80", "sum(r['mode_count'] for r in instances)==96")
a=s.index("controls=load(BASE/'controls.json')");b=s.index("for family in ['bracket','insert','cog']:",a)
s=s[:a]+"""controls=load(BASE/'controls.json');assert controls==[{'control':0,'row_shifts_grid':[[0,0]]*3,'source':'reference50-source.json','source_checks':'reference50-checks.json'}]
for name in ['reference50-source.json','reference50-checks.json']:assert load(BASE/name)==load(EXP/name)
assert load(EXP/'reference50-checks.json')['valid'] and load(EXP/'reference50-checks.json')['same_sheet_pairs']==856
"""+s[b:]
s=s.replace('The four source53 controls are identical to the independently verified common-shift controls; they are not claimed to lie in the conservative new model.', 'The simultaneous reference50 control is identical to the independently verified source control; it is not claimed to lie in the conservative new model or row grid bounds.')
s=s.replace("'source_cogs_verified':13,'original_source_controls_verified':4,'source_control_pairs_verified':3664", "'source_cogs_verified':12,'original_source_controls_verified':1,'source_control_pairs_verified':856")
write('audit_h5_twelve_cog_row_regions_20261107.py',s)
s=(R/'output/run_h5_twelve_cog_row_domains_20261107.py').read_text(encoding='utf-8')
s=s.replace('h5-twelve-cog-row-domains-process','h5-twelve-cog-row-regions-process').replace('prepare_h5_twelve_cog_row_domains','prepare_h5_twelve_cog_row_regions').replace('audit_h5_twelve_cog_row_domains','audit_h5_twelve_cog_row_regions')
s=s.replace("regions_20261107.py',30", "regions_20261107.py',40").replace("regions_20261107.py',60", "regions_20261107.py',120")
write('run_h5_twelve_cog_row_regions_20261107.py',s)
print({'prepared':True})
