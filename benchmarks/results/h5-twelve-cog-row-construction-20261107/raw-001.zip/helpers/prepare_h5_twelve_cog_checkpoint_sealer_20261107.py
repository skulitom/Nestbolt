from pathlib import Path
R=Path(__file__).resolve().parents[1]
old=(R/'output/seal_h5_exact_circle_forest_20261107.py').read_text(encoding='utf-8')
head="""from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-twelve-cog-row-construction-20261107';OUT=ROOT/'benchmarks/results'/NAME
D=ROOT/'output/h5-twelve-cog-row-domains-20261107';G=ROOT/'output/h5-twelve-cog-row-regions-20261107';I=ROOT/'output/h5-twelve-cog-row-integer-20261107';F=ROOT/'output/h5-twelve-cog-checkpoint-20261107';SYNC=ROOT/'output/h5-strip-capacity-main-sync-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
front=load(F/'checks.json');assert front['passed'] and front['result']=='UNKNOWN' and not front['source_valid66']
assert front['remaining_fixed_arrangements']==4 and front['new_exclusions']==0
assert load(SYNC/'receipt.json')['new_main']=='9e8782435232308c3c17411b414e0be0f281ce5d'
"""
inventory=old[old.index('inventory_ast='):old.index('walker=')]+"PARENTS.extend([ROOT/'benchmarks/results/h5-exact-circle-forest-20261107',ROOT/'benchmarks/results/h5-strip-capacity-models-20261107'])\n"+old[old.index('walker='):old.index('folders=')]
body="""folders=[D,G,I,F,SYNC]+[ROOT/'output'/('h5-twelve-cog-row-'+s+'-process-20261107') for s in ['domains','regions','integer','control','model','integer-audit-v2']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for p in (ROOT/'output').glob('*h5*twelve*cog*20261107.py'):add('helpers/'+p.name,p)
for name in ['ccd1.py','pack_h5_evidence_archive.py',walker.name,'seal_h5_exact_circle_forest_20261107.py','seal_h5_polygon_clearance_proofs_20261107.py','push_h5_capacity_checkpoint_20261107.py']:
    add('helpers/'+name,ROOT/'output'/name)
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(D/'audit/checks.json','row-domain-audit.json'),(D/'rows.json','row-domains.json'),(G/'source-region-audit/checks.json','source-region-audit.json'),(I/'geometry-audit/checks.json','original-integer-audit-report.json'),(I/'geometry-audit-v2/checks.json','corrected-integer-audit.json'),(I/'row-control/audit/checks.json','row-control-audit.json'),(I/'row-control/selected-control.json','selected-row-control.json'),(I/'model-audit/checks.json','model-audit.json'),(I/'model/final-preparation-charges.json','preparation-charges.json'),(I/'search/process.json','construction-process.json'),(I/'response-audit/checks.json','response-audit.json'),(SYNC/'receipt.json','main-sync-receipt.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
"""
report='''# Twelve-cog independent-row construction — 2026-11-07

A fresh **4/4/4-cog row construction** uses the independently source-valid
nine-part small sheet and all sixteen remaining orthogonal parts. Exact domain,
interaction, integer, control and complete model audits pass. Its sole bounded
call returns **UNKNOWN with no placement**. The call is closed; it excludes no
continuous domain or whole allocation. Four of 455 fixed arrangements and all
440 whole allocations remain. H2/H5 stay open at **60% completed milestone weight**.

## New source allocation and continuous row domains

Earlier independent rows used thirteen cogs with an eleven-part small sheet.
This construction instead retains four sites from each reference row and remaps
the identical cog copies to the twelve identities left by short9. All 66 original
identities are accounted for once: fixed29, twelve moving cogs, sixteen moving
orthogonal originals and short9. No earlier closed solver output is consumed.

[Exact affine readback]({NAME}/row-domain-audit.json) proves each entire closed
row box stays inside the source stock and above the fixed artwork. Inward 0.01 mm
rounding includes a 1e-6 mm reserve. [The three independent shift ranges]({NAME}/row-domains.json) are:

| Row | X shift, mm | Y shift, mm |
|---|---|---|
| 0 | -91.56 to 338.85 | 0.01 to 605.65 |
| 1 | -171.56 to 258.85 | -246.19 to 359.46 |
| 2 | -91.56 to 338.85 | -492.38 to 113.27 |

The audit verifies nearest excluded grid points, 36 mover-relative domains and
all three row-difference domains. Twelve individual-row corner controls and a
simultaneous 50-part reference pass 7,624 same-sheet pair checks, 2,216 stock-edge
checks, 658 cutout checks and 60,386 hole-vertex checks across the controls.
Minimum fixed-core separation over each box is at least 0.225489808 mm.
The Cartesian product of row boxes is **not** claimed collision-free.
Complete domain preparation takes 1.337919 seconds.

## Fresh interaction geometry and verified integer model

Fresh Minkowski regions cover allowed mover-minus-row and row-shift differences
for these source rows. [Original-source readback]({NAME}/source-region-audit.json)
certifies **2,367 mover/row regions and 583 row/row regions**, with 53,016 and
109,368 exact rational support proofs respectively. All twelve source modes,
all twelve cogs and every cross-row pair are covered. Twelve degenerate regions
are disabled. Minimum certified clearance is 0.225999999 mm. No global free-space
coverage claim is made. Complete geometry preparation takes 3.265552 seconds;
independent source verification takes a separate 29.643462-second process.

[Integer readback]({NAME}/corrected-integer-audit.json) verifies all 10,819 plane
implications over the complete relative-coordinate error envelopes. It retains
all source-mode aliases and constructs 24 rigid component rectangles with all
268 different-owner pairs for the sixteen orthogonal originals.
The [original integer audit report]({NAME}/original-integer-audit-report.json)
incorrectly reported 268 row regions because a local name was reused for
component pairs. The versioned recheck reports 583 row regions and 268 component
pairs separately. The original report is preserved; no region or model bytes
change, and the complete model audit independently covers all 583 row regions.

[A deterministic partial control]({NAME}/row-control-audit.json) checks 1,548
centroid grid neighbors and accepts the first adjacent-row combination. Its
[row shifts]({NAME}/selected-row-control.json), in 0.01 mm units, are
[-9009,1], [-8685,1269] and [-9156,2475]. All three selected row-pair regions and
all 50 placed originals pass source readback: 856 pairs, 200 stock edges,
58 holes and 6,122 hole vertices. The sixteen orthogonal companions are still
missing from this control. It supplies only a partial model hint.

[Every model field is checked]({NAME}/model-audit.json): **20,821 variables and
74,296 constraints**, 32 orthogonal world coordinates, six row shifts, all 96
source-mode selectors, 18,936 mover/row selectors and 583 row-pair selectors.
The reader verifies 69,696 mover planes, 2,107 row-pair planes, 640 rigid links,
all 268 component pairs, fourteen valid identical-copy ordering constraints and
589 partial hint values. Binary and text model forms are identical.

## One closed bounded call

[The preparation ledger]({NAME}/preparation-charges.json) charges **11.751349
seconds**, including source geometry, reference sites, source rectangles,
the complete direct-short9 preparation, every new domain/region/integer/control
preparation process and the complete 5.419855-second model build.
Independent verification is recorded separately; no consumed construction
preparation is made free by caching it.

[Response readback]({NAME}/response-audit.json) confirms UNKNOWN with no
incumbent, assignment or source66 check: 117,653 branches and 18,546 conflicts.
The solver receives 43.290991 seconds and returns in 43.416732 seconds. Its
**0.125741-second solve-slice overrun is retained**. Preparation-inclusive
algorithm/shared totals are **56.147634 / 56.243310 seconds**, within 60/90 s.
The [Windows Job Object process record]({NAME}/construction-process.json)
confirms closure of every descendant and a 1,576,177,664-byte peak aggregate
commit below the frozen 2 GiB limit. No native or LightBurn call follows.
This model will not be repeated, reseeded or extended.

[The next hypothesis]({NAME}/next-step.json) is a new 5/4/3 twelve-cog row
allocation based on the still-unresolved [5,10,11] empty-site choice. Its shorter
third row would permit a wider translation interval. This is prospective only:
new stock/core domains, all source interactions, controls and complete charges
must be verified before any new call. Full66 source/material/native checks,
production integration and the H5 matrix remain required.

The preceding two checkpoints reached **main 9e878243** by normal atomic
fast-forward after all six jobs and aggregate
[CI42325413099](https://github.com/skulitom/Nestbolt/actions/runs/42325413099)
passed. [The receipt]({NAME}/main-sync-receipt.json) verifies all 52 reconciled
remote files and unchanged refs before push. New
[CI42328915911](https://github.com/skulitom/Nestbolt/actions/runs/42328915911)
is tracked separately. No live run is cancelled and no new release qualifies.

[The manifest]({NAME}/raw-manifest.json) contains {archive['archive_members']}
new canonical members in {archive['archive_parts']} ZIP parts, totaling
{archive['archive_bytes']:,} bytes. [Historical references]({NAME}/external-evidence.json)
and [source bindings]({NAME}/source-bindings.json) preserve the original inputs.
Independent archive verification is required before commit.
'''
tail='report=f'+repr(report)+"\nwith OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\\n') as f:f.write(report)\n"
note="\n\n**2026-11-07 H5 twelve-cog rows:** [the new4/4/4-row construction]({link}) uses short9, twelve movable cogs and all sixteen orthogonal companions, distinct from closed13-cog/short11 models. Exact stock/core row domains, 2,367 mover regions, 583 row-pair regions, 162,384 source support proofs and 10,819 integer implications pass independent readback. The source-valid50 control preserves all original geometry while leaving sixteen companions unplaced. Full model checks cover 20,821 variables, 74,296 constraints, 96 modes, 24 rigid components and 268 component pairs. The sole bounded call closes UNKNOWN with no incumbent; complete preparation11.751349 s and algorithm/shared totals56.147634/56.243310 s remain within60/90 s. The0.125741 s solve-slice overrun and original misreported integer-region count remain preserved; a versioned audit corrects the count without changing model bytes. Four fixed arrangements and440 allocations remain, and H2/H5 stay open at60%. Next assess fresh5/4/3 row domains with short9; no closed model is repeated. Prior checkpoints reached main9e878243 after all six CI checks passed, preserving52 remote files. No new release is made.\n"
tail+='note='+repr(note)+"\nfor name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))\n"
tail+="""p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8')
a=s.index('Latest H5 evidence:');b=s.index('\\nThe earlier fixed 13-cog construction',a)
s=s[:a]+f'''Latest H5 evidence: [twelve-cog independent-row construction](../benchmarks/results/{NAME}.md).
The new4/4/4-cog row model with short9 passes full source/domain/model audits,
then closes UNKNOWN with no placement. All16 orthogonal originals and96 modes
are included; preparation-inclusive algorithm/shared totals56.147634/56.243310 s
stay within60/90 s. The solve-slice overrun remains recorded. Its call is closed;
next assess fresh5/4/3 row domains. The separate fixed29/current-cog frontier
remains four arrangements:451 of455 excluded at original0.2 mm clearance,
427 even at zero. Sixteen source strip capacities strengthen those graphs but
their four bounded calls add no exclusion. No source-valid66 or whole-allocation
exclusion follows. H2/H5 remain open at60%.
'''+s[b:]
with p.open('w',encoding='utf-8',newline='\\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\\nbenchmarks/results/{NAME}/** -text -whitespace\\n')
print({'sealed':True,**archive,'source_valid66':False,'remaining':4})
"""
with (R/'output/seal_h5_twelve_cog_checkpoint_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(head+inventory+body+tail)
s=(R/'output/verify_h5_exact_circle_forest_20261107.py').read_text(encoding='utf-8').replace('h5-exact-circle-forest-20261107','h5-twelve-cog-row-construction-20261107')
with (R/'output/verify_h5_twelve_cog_checkpoint_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':True})
