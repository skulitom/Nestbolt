from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-twelve-cog-row-integer-process-20261107'
EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/shop-venv/Scripts/python.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
stages=[('prepare','prepare_h5_twelve_cog_row_integer_20261107.py',30),('audit','audit_h5_twelve_cog_row_integer_20261107.py',60)]
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']+[ROOT/'output'/s for _,s,_ in stages]},'stages':stages,'committed_memory_bytes':2*1024**3,'repeat_permitted':False,'solver_calls':0})
records=[]
for name,script,cap in stages:
    args=[str(EXE),str(cap*1000),str(2*1024**3),str(OUT/(name+'-job.json')),str(OUT/(name+'-stdout.txt')),str(OUT/(name+'-stderr.txt')),str(OUT/(name+'-stop')),subprocess.list2cmdline([str(PY),str(ROOT/'output'/script)]),str(ROOT),'version4']
    t=time.perf_counter();r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=cap+8)
    (OUT/(name+'-runner-stdout.txt')).write_bytes(r.stdout);(OUT/(name+'-runner-stderr.txt')).write_bytes(r.stderr)
    job=load(OUT/(name+'-job.json'));passed=r.returncode==0 and job['closed'] and job['active_processes']==0 and job['reason_code']==0 and job['error_code']==0
    record={'stage':name,'exit_code':r.returncode,'complete_seconds':time.perf_counter()-t,'job':job,'passed':passed};records.append(record);write(OUT/(name+'.json'),record);print(json.dumps(record),flush=True)
    if not passed:break
write(OUT/'process.json',{'closed':True,'complete_seconds':time.perf_counter()-start,'stages':records,'passed':len(records)==2 and all(r['passed'] for r in records),'retry_permitted':False})
