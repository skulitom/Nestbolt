"""Prepare a distinct exact affine/source reader for the twelve-cog domain."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
s=(R/'output/audit_h5_individual_cog_row_domains_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-individual-cog-row-domains-20261104','h5-twelve-cog-row-domains-20261107').replace('h5-individual-cog-row-domains-process-20261104','h5-twelve-cog-row-domains-process-20261107')
s=s.replace("PRE=ROOT/'output/h5-translated-cog-packet-preflight-20261104'", "PRE=ROOT/'output/h5-first57-direct-short9-20261104'")
s=s.replace("FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'",'FIRST=PRE')
s=s.replace("SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json'", "SHORT=PRE/'short9-source.json'")
s=s.replace("cogs=load(BASE/'source-cogs.json');assert cogs==load(PRE/'packet-source13.json')", """cogs=load(BASE/'source-cogs.json');sites=load(PRE/'source-cog-sites.json')
assert len(cogs)==12
for i,(r,site) in enumerate(zip(cogs,[s for i,s in enumerate(sites) if i%5<4])):
    assert r['part_id']=='cog' and r['copy_index']==i+1
    assert {k:v for k,v in r.items() if k!='copy_index'}=={k:v for k,v in site.items() if k!='copy_index'}""")
s=s.replace('moving13_orthogonal_identities','moving16_orthogonal_identities').replace('len(fixed+cogs+short)==53 and len(missing)==13','len(fixed+cogs+short)==50 and len(missing)==16')
s=s.replace("old=load(PRE/'translation-domain.json')['shift_bounds_grid'];assert domain['previous_shared_shift_bounds_grid']==old", "assert domain['reference50_is_not_yet_a_model_control']")
s=s.replace('clearances=[];range_expansion=[]','clearances=[]')
s=s.replace("assert row['row']==ri and row['source_indices']==indices and row['reference_y_mm']==y", "assert row['row']==ri and row['source_indices']==indices==list(range(ri*4,ri*4+4)) and row['reference_y_mm']==y\n    assert row['reference_sites']==list(range(ri*5,ri*5+4))")
s=s.replace('        assert lo<=old[k][0]<=old[k][1]<=hi\n','')
s=s.replace("    range_expansion.append([(hi-lo)/(old[k][1]-old[k][0]) for k,(lo,hi) in enumerate(row['shift_bounds_grid'])])\n",'')
s=s.replace("assert [len(r['source_indices']) for r in rows]==[5,4,4]", "assert [len(r['source_indices']) for r in rows]==[4,4,4]\nassert F(domain['core_top_mm'])==top and safe[1]-top>F(spec['required_pair_gap_mm'])")
s=s.replace("assert counts['pairs']==7128", "assert counts['pairs']==6768")
s=s.replace("shared=load(BASE/'shared-control-source53.json');assert shared==load(PRE/'corner-0-source53.json')\nsource_check(shared,load(BASE/'shared-control-checks.json'),full-missing)", "shared=load(BASE/'reference50-source.json');assert shared==fixed+cogs+short\nsource_check(shared,load(BASE/'reference50-checks.json'),full-missing)")
a=s.index("process=load(PROCESS/");b=s.index("inputs=[Path(__file__)",a)
s=s[:a]+"""process=load(PROCESS/'prepare.json');opened=load(PROCESS/'opened.json');check=load(BASE/'checks.json')
assert process['passed'] and process['exit_code']==0 and process['job']['closed'] and process['job']['active_processes']==0
assert process['complete_seconds']>=check['seconds_including_source_controls']
assert process['complete_seconds']<=30 and check['seconds_including_source_controls']<=20
for p,h in opened['inputs'].items():assert digest(ROOT/p)==h
assert not opened['repeat_permitted']
"""+s[b:]
# Job runner is still creating audit stdout/report; bind only completed prepare records.
s=s.replace("list(PROCESS.glob('*'))", "[PROCESS/n for n in ['opened.json','prepare.json','prepare-job.json','prepare-stdout.txt','prepare-stderr.txt']]")
s=s.replace('shared53 control','reference50 control').replace("'row_sizes':[5,4,4]", "'row_sizes':[4,4,4]")
s=s.replace("'axis_span_expansion_factors':range_expansion,",'')
s=s.replace("'shared_source53_controls_verified':1", "'reference_source50_controls_verified':1")
s=s.replace("process['complete_process_seconds']", "process['complete_seconds']")
with (R/'output/audit_h5_twelve_cog_row_domains_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'output/run_h5_strip_capacity_set_20261107.py').read_text(encoding='utf-8')
s=s.replace('h5-strip-capacity-set-process-20261107','h5-twelve-cog-row-domains-process-20261107').replace('.cache/h5-cpsat-cpython-venv','.cache/shop-venv')
s=s.replace("('prepare','prepare_h5_strip_capacity_set_20261107.py',80),('audit','audit_h5_strip_capacity_set_20261107.py',90)", "('prepare','prepare_h5_twelve_cog_row_domains_20261107.py',30),('audit','audit_h5_twelve_cog_row_domains_20261107.py',60)")
with (R/'output/run_h5_twelve_cog_row_domains_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':True})
