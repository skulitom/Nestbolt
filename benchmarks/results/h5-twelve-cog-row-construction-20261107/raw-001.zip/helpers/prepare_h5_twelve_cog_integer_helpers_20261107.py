from pathlib import Path
R=Path(__file__).resolve().parents[1]
def write(name,s):
    with (R/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def rename(s):
    return s.replace('h5-expanded-cog-row-regions-20261104','h5-twelve-cog-row-regions-20261107').replace('h5-expanded-cog-row-integer-20261104','h5-twelve-cog-row-integer-20261107').replace('h5-translated-cog-packet-preflight-20261104','h5-twelve-cog-row-domains-20261107')
s=rename((R/'output/prepare_h5_expanded_cog_row_integer_20261104.py').read_text(encoding='utf-8'))
s=s.replace("for name in ['components.json','component-pairs.json']:shutil.copyfile(PRIOR/'rigid-rectangle-preflight'/name,OUT/name)", """instances=load(REG/'instances.json');components=[]
for owner,item in enumerate(instances):
    for piece in range(2 if item['identity'][0]=='bracket' else 1):components.append({'component':len(components),'owner':owner,'identity':item['identity'],'piece':piece})
pairs=[{'components':[a['component'],b['component']],'owners':[a['owner'],b['owner']]} for i,a in enumerate(components) for b in components[i+1:] if a['owner']!=b['owner']]
assert len(instances)==16 and len(components)==24 and len(pairs)==268
write(OUT/'components.json',components);write(OUT/'component-pairs.json',pairs)""")
s=s.replace("'source_mode_options':80", "'source_mode_options':96")
write('prepare_h5_twelve_cog_row_integer_20261107.py',s)
s=rename((R/'output/audit_h5_expanded_cog_row_integer_20261104.py').read_text(encoding='utf-8'))
s=s.replace("for name in ['components.json','component-pairs.json']:assert digest(BASE/name)==digest(PRIOR/'rigid-rectangle-preflight'/name)", """instances=load(BASE/'instances.json');inv=load(BASE/'inventory.json')
assert [r['identity'] for r in instances]==inv['moving16_orthogonal_identities'] and len(instances)==16
assert sum(r['mode_count'] for r in instances)==96
components=load(BASE/'components.json');expected=[]
for owner,r in enumerate(instances):
    counts={len(m['rectangles']) for m in rectangles[r['identity'][0]]};assert len(counts)==1
    for piece in range(next(iter(counts))):expected.append({'component':len(expected),'owner':owner,'identity':r['identity'],'piece':piece})
assert components==expected and len(components)==24
pairs=load(BASE/'component-pairs.json');expected_pairs=[]
for ai in range(len(components)):
    for bi in range(ai+1,len(components)):
        a,b=components[ai],components[bi]
        if a['owner']!=b['owner']:expected_pairs.append({'components':[ai,bi],'owners':[a['owner'],b['owner']]})
assert pairs==expected_pairs and len(pairs)==268""")
s=s.replace('all80 mode options','all96 mode options').replace("'source_modes_verified':mode_count", "'source_modes_verified':mode_count,'orthogonal_instances_verified':len(instances),'rigid_components_verified':len(components),'different_owner_component_pairs_verified':len(pairs)")
write('audit_h5_twelve_cog_row_integer_20261107.py',s)
s=(R/'output/run_h5_twelve_cog_row_regions_20261107.py').read_text(encoding='utf-8').replace('h5-twelve-cog-row-regions-process','h5-twelve-cog-row-integer-process').replace('prepare_h5_twelve_cog_row_regions','prepare_h5_twelve_cog_row_integer').replace('audit_h5_twelve_cog_row_regions','audit_h5_twelve_cog_row_integer').replace("integer_20261107.py',40", "integer_20261107.py',30").replace("integer_20261107.py',120", "integer_20261107.py',60")
write('run_h5_twelve_cog_row_integer_20261107.py',s)
print({'prepared':True})
