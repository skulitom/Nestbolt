"""Bind the source, model, response and corrected report into one closed checkpoint."""
from pathlib import Path
from hashlib import sha256
import json,time
R=Path(__file__).resolve().parents[1];OUT=R/'output/h5-twelve-cog-checkpoint-20261107';OUT.mkdir();start=time.perf_counter()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
D=R/'output/h5-twelve-cog-row-domains-20261107';G=R/'output/h5-twelve-cog-row-regions-20261107';I=R/'output/h5-twelve-cog-row-integer-20261107'
domains=load(D/'audit/checks.json');regions=load(G/'source-region-audit/checks.json');integer=load(I/'geometry-audit-v2/checks.json');model=load(I/'model-audit/checks.json');response=load(I/'response-audit/checks.json');control=load(I/'row-control/audit/checks.json')
assert all(c['passed'] for c in [domains,regions,integer,model,response,control])
assert domains['row_sizes']==regions['row_source_counts_verified']==[4,4,4]
assert integer['row_pair_regions_verified']==regions['row_pair_regions_verified']==model['row_pair_region_selectors_verified']==583
assert load(I/'geometry-audit/checks.json')['row_pair_regions_verified']==268
assert integer['different_owner_component_pairs_verified']==model['different_owner_rectangle_pairs_verified']==268
assert integer['model_or_region_bytes_changed'] is False and integer['exact_integer_plane_implications']==10819
assert model['model_sha256']==digest(I/'model/model.pb')==digest(I/'search/model.pb')==load(I/'search/opened.json')['model_sha256']
assert model['orthogonal_originals_verified']==16 and model['row_cog_originals_verified']==12 and model['source_mode_selectors_verified']==96
assert control['source_valid50'] and control['source_pairs_verified']==856 and control['source_holes_verified']==58 and control['source_hole_vertices_verified']==6122
assert response['closed_solver_calls']==1 and response['solver_status']=='UNKNOWN' and response['incumbents_verified']==response['assignments']==response['source_checker_calls']==0
assert response['windows_job_descendants_closed'] and response['algorithm_overrun_seconds']==response['shared_overrun_seconds']==0
assert not response['source_valid66'] and not response['continuous_source_domain_excluded'] and not response['any_allocation_excluded']
processes=[]
for stem in ['domains','regions','integer','control','model','integer-audit-v2']:
    p=R/'output'/('h5-twelve-cog-row-'+stem+'-process-20261107')/'process.json';r=load(p)
    assert r['passed'] and r['closed'] and all(x['passed'] and x['job']['closed'] and x['job']['active_processes']==0 for x in r['stages'])
    processes.append(p)
front=load(R/'output/h5-capacity-sat-batch-20261107/audit/checks.json');assert front['passed'] and front['remaining_fixed29_choices']==4 and front['total_excluded_at_required_clearance']==451
sync=load(R/'output/h5-strip-capacity-main-sync-20261107/receipt.json');assert sync['new_main']=='9e8782435232308c3c17411b414e0be0f281ce5d' and sync['prior_main_all6_pass'] and sync['remote_files_preserved']==52
bindings=load(I/'response-audit/source-bindings.json')
for folder in [D,G,I]:
    for p in folder.rglob('*'):
        if p.is_file():bindings[p.relative_to(R).as_posix()]=digest(p)
for p in [Path(__file__),*processes,R/'output/h5-strip-capacity-main-sync-20261107/receipt.json',R/'output/h5-capacity-sat-batch-20261107/audit/checks.json']:
    bindings[p.relative_to(R).as_posix()]=digest(p)
for p,h in bindings.items():assert digest(R/p)==h
write('plan.json',{'inputs':bindings,'method':'Read all closed source/domain/region/integer/control/model/result records and current frontier. Verify the corrected integer audit reports583 row regions separately from268 component pairs, retaining the original reporting error and every unchanged model hash. No solver, source placement preparation or native call is made.'})
write('source-bindings.json',bindings)
write('checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_row_sizes':[4,4,4],'orthogonal_originals':16,'source_modes':96,
    'continuous_individual_row_boxes_verified':3,'domain_control_pairs':domains['pairs'],'source_control50_valid':True,
    'mover_regions':2367,'row_pair_regions':583,'exact_mover_supports':53016,'exact_row_pair_supports':109368,'integer_plane_implications':10819,
    'model_variables':model['variables_verified'],'model_constraints':model['constraints_verified'],'all_model_fields_verified':True,
    'reported_region_count_correction_preserved':True,'closed_construction_calls':1,'result':'UNKNOWN','source_valid66':False,
    'new_exclusions':0,'remaining_fixed_arrangements':4,'excluded_fixed_arrangements_at_original_clearance':451,'whole_allocations':440,
    'complete_preparation_seconds':response['preparation_seconds_charged'],'algorithm_seconds':response['algorithm_seconds_including_preparation'],
    'shared_seconds':response['shared_seconds_including_preparation'],'solve_slice_overrun_seconds':response['solve_slice_overrun_seconds'],
    'complete_algorithm_or_shared_overrun':False,'active_descendants':0,'native_or_LightBurn_calls':0,'completed_milestone_weight_percent':60,'H2_complete':False,'H5_complete':False})
write('next-step.json',{'all_existing_calls_closed':True,'no_retry_reseed_or_extension':True,
    'next_hypothesis':'Assess a new5/4/3 twelve-cog row construction for short9, anchored initially to reference sites0..4,6..9,12..14. This corresponds to unresolved empty sites[5,10,11] but would give each unequal row independent source-safe translations. The three-cog row can move through a wider interval and changes available orthogonal-part regions. This is a prospective hypothesis only; derive and independently verify fresh stock/core row domains and all mover/row and row/row source interactions, controls and full preparation charges before any new call. Existing4/4/4 and earlier13-cog/short11 models remain closed and their results do not transfer.',
    'new_solver_prepared':False,'new_solver_calls':0,'source_valid66_required_before_native':True,'full_material_matrix_and_production_parity_required':True,'H5_complete':False})
print(load(OUT/'checks.json'))
