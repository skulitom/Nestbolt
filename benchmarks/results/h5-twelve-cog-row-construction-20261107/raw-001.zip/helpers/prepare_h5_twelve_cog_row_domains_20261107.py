"""Fresh 4/4/4 cog-row domain construction for the source-valid short9 split."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
import json,math,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];PRE=ROOT/'output/h5-first57-direct-short9-20261104'
OUT=ROOT/'output/h5-twelve-cog-row-domains-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRE/'audit/checks.json')['passed'];OUT.mkdir();started=time.perf_counter()
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[PRE/n for n in ['plan.json','audit/plan.json','audit/checks.json','short9-source.json','fixed29.json','source-cog-sites.json','family-modes.json','inventory.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'A new constructive source domain for short9: retain the first four source sites in each of three ordered reference cog rows, remap their identical original copies to the twelve remaining cog identities, and allow each rigid row independent X/Y shifts within its own exact stock/fixed-core-safe bounding rectangle. Compute complete bounds at0.01mm grid with1e-6mm inward reserve. Check each row at all four corners with fixed29 and short9. Also check the simultaneous unshifted50-part reference. These controls do not establish joint safety of independently shifted rows or place the16 orthogonal companions. Fresh inter-row and mover-row interactions and complete charged preparation remain required. Earlier13-cog/short11 and fixed-site calls remain closed; no old negative result is transferred.',
    'selected_reference_sites':[0,1,2,3,5,6,7,8,10,11,12,13],'row_sizes':[4,4,4],
    'grid_units_per_mm':100,'inward_rounding_reserve_mm':'0.000001','extra_stock_mm':'0.025',
    'preparation_target_seconds':20,'complete_process_cap_seconds':30,'future_algorithm_seconds':60,'future_shared_seconds':90,
    'maximum_calls':1,'retry_permitted':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(PRE/'plan.json');inventory=load(PRE/'inventory.json')
fixed=load(PRE/'fixed29.json');short=load(PRE/'short9-source.json');sites=load(PRE/'source-cog-sites.json');chosen=[i for i in range(15) if i%5<4]
cogs=deepcopy([sites[i] for i in chosen]);assert len(cogs)==len(inventory['required_cog12_identities'])==12
for r,(family,copy) in zip(cogs,inventory['required_cog12_identities']):assert family=='cog';r['copy_index']=copy
full={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};missing=set(map(tuple,inventory['moving16_orthogonal_identities']))
assert len(missing)==16 and len(fixed+cogs+short)==50 and {(r['part_id'],r['copy_index']) for r in fixed+cogs+short}==full-missing
grid=100;stock=list(map(F,spec['construction_stock']));extra=F(1,40);eps=F(1,1000000)
safe=[stock[0]+extra,stock[1]+extra,stock[2]-extra,stock[3]-extra]
def exact(r):
    t=r['transform'];c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));tx,ty=map(F,t['translation']);sign=-1 if t['mirrored'] else 1
    return [(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in parts[r['part_id']]['geometry'][0]['outer']]
core_top=max(p[1] for r in fixed for p in exact(r));assert safe[1]-core_top>F(spec['required_pair_gap_mm'])
rows=[];controls=[];row_modes=[];modes=load(PRE/'family-modes.json')
for ri in range(3):
    indices=list(range(ri*4,ri*4+4));source=[cogs[i] for i in indices];vertices=[v for r in source for v in exact(r)]
    box=[min(v[k] for v in vertices) for k in [0,1]]+[max(v[k] for v in vertices) for k in [0,1]]
    shift=[[math.ceil((safe[k]-box[k]+eps)*grid),math.floor((safe[k+2]-box[k+2]-eps)*grid)] for k in [0,1]]
    assert all(lo<hi for lo,hi in shift)
    rows.append({'row':ri,'source_indices':indices,'reference_sites':chosen[ri*4:ri*4+4],
                 'source_identities':[[r['part_id'],r['copy_index']] for r in source],
                 'reference_y_mm':source[0]['transform']['translation'][1],
                 'source_row_bounds_mm':[str(v) for v in box],'shift_bounds_grid':shift,
                 'shift_bounds_mm':[[str(F(v,grid)) for v in b] for b in shift]})
    for ci,delta in enumerate(product(*shift)):
        moved=deepcopy(source)
        for r in moved:r['transform']['translation']=[v+delta[k]/grid for k,v in enumerate(r['transform']['translation'])]
        result=fixed+moved+short;check=audit(job,result,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in result])
        stem=f'row-{ri}-corner-{ci}';write(OUT/(stem+'-source.json'),result);write(OUT/(stem+'-checks.json'),check);assert check['valid']
        controls.append({'row':ri,'corner':ci,'shift_grid':delta,'source':stem+'-source.json','source_checks':stem+'-checks.json'})
    for family in ['bracket','insert']:
        for m in modes[family]:
            relative=[[F(b[0])-F(shift[k][1],grid),F(b[1])-F(shift[k][0],grid)] for k,b in enumerate(m['lower_left_bounds'])]
            row_modes.append({'row':ri,'family':family,**m,'relative_lower_left_bounds_mm':[[str(v) for v in b] for b in relative]})
    assert time.perf_counter()-started<20
pair_domains=[]
for a,b in combinations(range(3),2):
    bounds=[[rows[b]['shift_bounds_grid'][k][0]-rows[a]['shift_bounds_grid'][k][1],rows[b]['shift_bounds_grid'][k][1]-rows[a]['shift_bounds_grid'][k][0]] for k in [0,1]]
    pair_domains.append({'rows':[a,b],'relative_coordinate':'shift_B_minus_shift_A','bounds_grid':bounds,'bounds_mm':[[str(F(v,grid)) for v in bb] for bb in bounds]})
reference=fixed+cogs+short;check=audit(job,reference,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],full-missing)
write(OUT/'reference50-source.json',reference);write(OUT/'reference50-checks.json',check);assert check['valid']
for name,v in [('source-cogs.json',cogs),('rows.json',rows),('controls.json',controls),('row-modes.json',row_modes),('pair-domains.json',pair_domains),('inventory.json',inventory)]:write(OUT/name,v)
write(OUT/'domain.json',{'safe_world_bounds_mm':[str(v) for v in safe],'core_top_mm':str(core_top),'grid_units_per_mm':grid,'inter_row_safety_not_proven':True,'independent_row_bounds_are_not_a_joint_feasible_domain':True,'reference50_is_not_yet_a_model_control':True})
result={'passed':True,'seconds_including_source_controls':time.perf_counter()-started,'row_sizes':[4,4,4],
        'individual_shift_bounds_grid':[r['shift_bounds_grid'] for r in rows],'partial_row_controls':12,
        'source_control_pairs_checked':sum(load(OUT/r['source_checks'])['same_sheet_pairs'] for r in controls),
        'reference50_source_valid':True,'reference50_pairs':check['same_sheet_pairs'],'orthogonal_companions_missing':16,
        'row_source_mode_domains':len(row_modes),'row_pair_difference_domains':len(pair_domains),
        'all66_identities_accounted_once':True,'independent_audit_required':True,'fresh_interaction_regions_required':True,
        'source_valid66':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
