import{n}from"./engine-B4QNcwKh.js";window.nestJob=n;window.benchReady=!0;
