"""Necessary full-stock bracket covers for all17 valid frozen roof cores."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json,math,time,os
import numpy as np
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-orientation-roofs-20261107';OUT=ROOT/'output/h5-orientation-roof-covers-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();PAD=F(1,10**6)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))/2
def transform(p,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));sign=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation']);q=[(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in p];return q if area(q)>0 else q[::-1]
def contains(p,r):return all(cross(a,b,v)>0 for a,b in zip(p,p[1:]+p[:1]) for v in product([r[0],r[2]],[r[1],r[3]]))
def expanded(r):return [F(v,1000)+(-PAD if k<2 else PAD) for k,v in enumerate(r)]
def inward(r):return [math.ceil((v+2*PAD)*1000) if k<2 else math.floor((v-2*PAD)*1000) for k,v in enumerate(r)]
def orthogonal(p):
    r=inward([min(x for x,y in p),min(y for x,y in p),max(x for x,y in p),max(y for x,y in p)]);assert contains(p,expanded(r));return r
def section(p,y):
    xs=[]
    for a,b in zip(p,p[1:]+p[:1]):
        if a[1]==b[1]:
            if y==a[1]:xs.extend([a[0],b[0]])
        elif min(a[1],b[1])<=y<=max(a[1],b[1]):xs.append(a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]))
    return min(xs),max(xs)
def classes(cuts):
    out=np.empty(2*len(cuts)-1,dtype=np.int64);out[::2]=2*cuts;out[1::2]=cuts[:-1]+cuts[1:];return out
def union_area(rects):
    xs=sorted({r[k] for r in rects for k in [0,2]});total=0
    for a,b in zip(xs,xs[1:]):
        intervals=sorted((r[1],r[3]) for r in rects if r[0]<b and a<r[2]);length=0;hi=None
        for lo,end in intervals:
            if hi is None or lo>hi:length+=end-lo;hi=end
            elif end>hi:length+=end-hi;hi=end
        total+=(b-a)*length
    return total
def deadline():assert time.perf_counter()-began<30,'Declared preparation cap reached; no exclusion certified.'
OUT.mkdir();began=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']);assert load(BASE/'audit/checks.json')['passed']
inputs=[Path(__file__),JOB,BASE/'plan.json',BASE/'audit/checks.json',BASE/'source-recipe.json',BASE/'cog-derivation.json',BASE/'fixed27-source.json',ROOT/'output/h5-orientation-roofs-process-20261107/process.json']+[BASE/f'turned-{k}'/n for k in [1,2] for n in ['sites.json','roof-source.json','cases.json']]
prior=load(ROOT/'output/h5-orientation-roofs-process-20261107/process.json')['complete_seconds']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For the seventeen source-valid48 cores, derive source-contained convex-piece inner rectangles and exact open forbidden bracket-center rectangles at zero clearance, over every allowed bracket mode and the entire physical first stock. Include all axis boundary points and open intervals; label forbidden cells by cog site bits and a fixed-frame bit. Keep zero or at most one cog bit according to the source pool. Produce every15-of16 omission cover together, with no lost boundaries. Outward occupied rectangles cover every possible bracket footprint. Compute their exact integer union area for each fixed core. Independent containment, count-event masks, cover equality and area replay required before any exclusion. No optimizer, no claim of sufficient placement domains. Only these fixed cores can be excluded.','preparation_internal_cap_seconds':30,'process_cap_seconds':35,'memory_bytes':2**31,'maximum_classes_per_mode':40000000,'inherited_numeric_preparation_seconds':prior,'charge_entire_process_if_consumed':True,'fixed_frame_bit':16,'site_bits':'0..14 for k1;0..15 for k2','bracket_area_lower_mm2':39999,'required_brackets':6,'optimizer_calls':0,'solver_calls':0,'retry_permitted':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};recipe=load(BASE/'source-recipe.json');deriv=load(BASE/'cog-derivation.json');fixed=load(BASE/'fixed27-source.json');stock=list(map(F,recipe['source_stocks']['sheet-0']));theta=deriv['rotation_radians'];cx,cy=deriv['source_center'];cs,sn=math.cos(theta),math.sin(theta);pieces=deriv['convex_pieces'];localpieces=[transform(p,{'rotation_radians':theta,'mirrored':False,'translation':[0.,0.]}) for p in pieces];candidates=[]
for pi,p in enumerate(localpieces):
    ys=sorted({v[1] for v in p});ss={y:section(p,y) for y in ys}
    for i,a in enumerate(ys):
        for b in ys[i+1:]:
            r=inward([max(ss[a][0],ss[b][0]),a,min(ss[a][1],ss[b][1]),b])
            if r[0]<r[2] and r[1]<r[3] and contains(p,expanded(r)):candidates.append({'piece':pi,'bounds_um':r})
unique={tuple(r['bounds_um']):r for r in candidates};retained=[]
for r in sorted(unique.values(),key=lambda r:-(r['bounds_um'][2]-r['bounds_um'][0])*(r['bounds_um'][3]-r['bounds_um'][1])):
    a,b,c,d=r['bounds_um']
    if not any(q['bounds_um'][0]<=a and q['bounds_um'][1]<=b and c<=q['bounds_um'][2] and d<=q['bounds_um'][3] for q in retained):retained.append(r)
write(OUT/'local-cog-rectangles.json',retained)
bracket=parts['bracket'];assert bracket['allow_mirror'] and bracket['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]};assert bracket['geometry'][0]['outer']==[[0.,0.],[300.,0.],[300.,75.],[100.,75.],[100.,250.],[0.,250.]]
components=[[[0,0],[300,0],[300,75],[0,75]],[[0,75],[100,75],[100,250],[0,250]]];geometries=[]
for mirror,deg in product([False,True],[0,90,180,270]):
    a=math.radians(deg);c,s=math.cos(a),math.sin(a);sign=-1 if mirror else 1;pose={'rotation_radians':a,'mirrored':mirror,'translation':[-(sign*150*c-125*s),-(sign*150*s+125*c)]};outer=transform(bracket['geometry'][0]['outer'],pose);assert area(outer)>39999
    inner=[orthogonal(transform(p,pose)) for p in components];low=[min(v[k] for v in outer) for k in range(2)];high=[max(v[k] for v in outer) for k in range(2)];domain=[stock[0]-low[0]-PAD,stock[1]-low[1]-PAD,stock[2]-high[0]+PAD,stock[3]-high[1]+PAD];domain=[math.floor(v*1000) if k<2 else math.ceil(v*1000) for k,v in enumerate(domain)];bounds=[math.floor(v*1000)-1 if k<2 else math.ceil(v*1000)+1 for k,v in enumerate(low+high)]
    geometries.append({'mode':len(geometries),'pose':pose,'inner_components_um':inner,'stock_center_domain_um':domain,'outer_bounds_um':bounds,'source_area_mm2':str(area(outer))})
write(OUT/'bracket-geometries.json',geometries);summary=[]
for k in [1,2]:
    folder=OUT/f'turned-{k}';folder.mkdir();roof=load(BASE/f'turned-{k}/roof-source.json');sites=load(BASE/f'turned-{k}/sites.json');sources=[]
    for row in [r for r in fixed if r['sheet_id']=='sheet-0']+roof:
        sources.append({'kind':'frame','identity':[row['part_id'],row['copy_index']],'site_bit':16,'piece':0,'bounds_um':orthogonal(transform(parts['frame']['geometry'][0]['outer'],row['transform']))})
    for site in sites:
        shift=[site['center'][0]-(cx*cs-cy*sn),site['center'][1]-(cx*sn+cy*cs)];pose={'rotation_radians':theta,'mirrored':False,'translation':shift};pp=[transform(p,pose) for p in pieces]
        for rec in retained:
            r=inward([F(v,1000)+F(shift[j%2]) for j,v in enumerate(rec['bounds_um'])]);assert contains(pp[rec['piece']],expanded(r));sources.append({'kind':'cog','site_bit':site['site'],'piece':rec['piece'],'bounds_um':r})
    write(folder/'source-inner-rectangles.json',sources);covers={};records=[]
    for g in geometries:
        mode=g['mode'];d=g['stock_center_domain_um'];obstacles=[]
        for si,source in enumerate(sources):
            u,v,w,z=source['bounds_um']
            for ci,(a,b,c,e) in enumerate(g['inner_components_um']):
                r=[u-c,v-e,w-a,z-b]
                if r[0]>=d[2] or r[2]<=d[0] or r[1]>=d[3] or r[3]<=d[1]:continue
                obstacles.append({'source':si,'component':ci,'bit':source['site_bit'],'bounds_um':r})
        xs=np.array(sorted({d[0],d[2]}|{v for o in obstacles for v in o['bounds_um'][::2] if d[0]<=v<=d[2]}),dtype=np.int64);ys=np.array(sorted({d[1],d[3]}|{v for o in obstacles for v in o['bounds_um'][1::2] if d[1]<=v<=d[3]}),dtype=np.int64);xx,yy=classes(xs),classes(ys);assert len(xx)*len(yy)<=40000000;mask=np.zeros((len(yy),len(xx)),dtype=np.uint32)
        for o in obstacles:
            a,b,c,e=o['bounds_um'];xa=int(np.searchsorted(xx,2*a,side='right'));xb=int(np.searchsorted(xx,2*c,side='left'));ya=int(np.searchsorted(yy,2*b,side='right'));yb=int(np.searchsorted(yy,2*e,side='left'));mask[ya:yb,xa:xb]|=np.uint32(1<<o['bit'])
        np.savez_compressed(folder/f'mode-{mode:02d}-classes.npz',xcuts_um=xs,ycuts_um=ys,mask=mask);boxes=[];active={}
        def close(key,span):
            m,xa,xb=key;ya,yb=span;boxes.append([m,int(xs[xa//2]),int(ys[ya//2]),int(xs[(xb+1)//2]),int(ys[(yb+1)//2]),xa,ya,xb,yb])
        for yi,row in enumerate(mask):
            legal=(row==0) if k==1 else (((row&65536)==0)&((row&(row-1))==0));labels=np.where(legal,row,np.uint32(131071));starts=np.r_[0,np.flatnonzero(labels[1:]!=labels[:-1])+1];ends=np.r_[starts[1:]-1,len(labels)-1];current={}
            for xa,xb in zip(starts.tolist(),ends.tolist()):
                m=int(labels[xa])
                if m==131071:continue
                key=(m,xa,xb);current[key]=[active[key][0] if key in active else yi,yi]
            for key,span in active.items():
                if key not in current:close(key,span)
            active=current
        for key,span in active.items():close(key,span)
        boxes.sort();covers[mode]=boxes;write(folder/f'mode-{mode:02d}.json',{'geometry':mode,'obstacles':obstacles,'cover':boxes});records.append({'mode':mode,'classes':int(mask.size),'cover_boxes':len(boxes),'retained_classes':sum((r[7]-r[5]+1)*(r[8]-r[6]+1) for r in boxes)});deadline()
    cases=[]
    for omission in ([None] if k==1 else list(range(16))):
        allowed=0 if omission is None else 1<<omission;occupied=[]
        for g in geometries:
            a,b,c,d=g['outer_bounds_um']
            for r in covers[g['mode']]:
                if r[0]&~allowed==0:occupied.append([r[1]+a,r[2]+b,r[3]+c,r[4]+d])
        occupied=sorted(set(map(tuple,occupied)));exact=union_area(occupied);capacity=exact//(39999*10**6);case='all15' if omission is None else f'omit-{omission:02d}'
        result={'case':case,'omitted_site':omission,'occupied_cover_rectangles_um':occupied,'occupied_cover_union_area_um2':exact,'occupied_cover_union_area_mm2':exact/1e6,'bracket_area_lower_mm2':39999,'provisional_bracket_capacity':capacity,'required_brackets':6,'independent_audit_pending':True,'fixed_core_excluded':False};write(folder/(case+'-capacity.json'),result);cases.append({x:result[x] for x in ['case','omitted_site','occupied_cover_union_area_mm2','provisional_bracket_capacity']})
    write(folder/'summary.json',{'modes':records,'cases':cases});summary.append({'turned_frames':k,'classes':sum(r['classes'] for r in records),'cover_boxes':sum(r['cover_boxes'] for r in records),'cases':cases});deadline()
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'patterns':summary,'total_classes':sum(r['classes'] for r in summary),'fixed48_cases':17,'provisional_cases_below_six':sum(c['provisional_bracket_capacity']<6 for r in summary for c in r['cases']),'independent_audit_pending':True,'fixed_cores_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
