"""Complete nominal frame-orientation census; closed calls are not exclusions."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
from collections import Counter
import json,math,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-upper-frame-orientation-classes-20261107'
OLD=ROOT/'output/h5-six-upper-frames-model-20261107';NEW=ROOT/'output/h5-six-unturned-model-20261107'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def outline_key(original,center,angle):
    q=round(angle/(math.pi/2))%4;assert abs(math.remainder(angle-q*math.pi/2,math.tau))<1e-12;v=[]
    for x,y in original:
        x,y=F(x)-F(center[0]),F(y)-F(center[1])
        for _ in range(q):x,y=-y,x
        v.append((x,y))
    return tuple(sorted(tuple(sorted((a,b))) for a,b in zip(v,v[1:]+v[:1])))
OUT.mkdir();started=time.perf_counter();job=load(JOB);part=next(p for p in job['parts'] if p['id']=='frame');assert part['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]} and not part['allow_mirror']
historical=[ROOT/'output/prepare_h5_aligned_aspect_model.py',ROOT/'output/prepare_h5_ragged_model.py',ROOT/'benchmarks/results/h5-orientation-aliases-and-source-hints-20261025.md',ROOT/'benchmarks/results/h5-wide-core-compound-limits-20261023.md']
paths=[Path(__file__),JOB]+historical
scopes=[];calls=[]
for name,base,count in [('four-turned-two-unturned',OLD,3),('six-unturned',NEW,1)]:
    lib=load(base/'library.json');controls=load(base/'audit/physical-mode-controls.json');checked=load(base/'audit/checks.json');response=load(base/'response-audit/checks.json');assert checked['passed'] and controls['passed'] and response['passed']
    paths.extend(base/n for n in ['library.json','audit/physical-mode-controls.json','audit/checks.json','response-audit/checks.json','search/plan.json','search/result.json'])
    frames=[i for i,identity in enumerate(lib['identities']) if identity[0]=='frame'];assert frames==list(range(6)) and len(lib['identities'])==39
    modes=lib['family_modes']['frame'];assert len(modes)==4 and [m['rotation_radians'] for m in modes]==[0.,math.pi/2,math.pi,3*math.pi/2] and all(not m['mirrored'] for m in modes)
    source=lib['families']['frame'];assert source['original']==part['geometry'][0]['outer'] and source['source_holes']==part['geometry'][0]['holes']
    keys=[(outline_key(source['original'],source['source_center'],m['rotation_radians']),tuple(map(F,m['rectangle_mm']))) for m in modes]
    assert keys[0]==keys[2] and keys[1]==keys[3] and keys[0]!=keys[1] and controls['family_classes']['frame']==[0,1,0,1]
    raw=Counter();ordered=set();orbit_representatives=set()
    for vector in product(range(4),repeat=6):
        physical=tuple(v%2 for v in vector);raw[sum(physical)]+=1;ordered.add(physical);orbit_representatives.add(tuple(sorted(physical)))
    assert len(ordered)==64 and len(orbit_representatives)==7 and sum(raw.values())==4096
    assert raw=={k:64*math.comb(6,k) for k in range(7)}
    for k in range(7):assert len([v for v in ordered if sum(v)==k])==math.comb(6,k)
    model_fixed=sorted((r['part_id'],r['transform']['rotation_radians'],r['transform']['mirrored'],tuple(r['transform']['translation']),r['sheet_id']) for r in lib['fixed_source_rows'])
    scopes.append({'name':name,'library_sha256':digest(base/'library.json'),'frame_ids':[lib['identities'][i] for i in frames],'frame_modes':modes,'raw_vectors':4096,'ordered_physical_vectors':64,'orientation_count_orbits':7,'fixed_geometry_ignoring_copy_labels':model_fixed,'source_stocks':lib['source_stocks'],'raw_vectors_per_turned_count':dict(raw),'source_clearance':lib['required_pair_gap_mm'],'scope':'Nominal filled original frame outlines, identical effective hard domains and interchangeable copies; original holes remain preserved and are not nesting space.'})
    for i in range(count):
        folder=base/'search'/f'round-{i:02d}';opened=load(folder/'optimizer-opened.json');mm=load(folder/'model.json');outcome=load(folder/'result.json');paths.extend(folder/n for n in ['optimizer-opened.json','model.json','result.json'])
        assert mm['objective_weights']=={'original_area':1,'clearance_area':1} and len(mm['owners'])==39 and mm['parameters']==93
        frame_key=[controls['family_classes']['frame'][mm['owners'][j]['mode']] for j in frames];assert frame_key==opened['physical_key'][:6]
        assert all(mm['owners'][j]['identity']==lib['identities'][j] for j in frames)
        calls.append({'scope':name,'round':i,'optimizer_opened':(folder/'optimizer-opened.json').relative_to(ROOT).as_posix(),'model_sha256':digest(folder/'model.json'),'physical_key':opened['physical_key'],'frame_turned_count':sum(frame_key),'frame_physical_vector':frame_key,'source_valid66':outcome['source_valid66'],'source_pair_failures':outcome['source_pair_failures'],'this_call_closed':True,'orientation_class_excluded':False})
assert [c['frame_turned_count'] for c in calls]==[4,4,4,0] and all(not c['source_valid66'] for c in calls)
classes=[]
for k in range(7):
    selected=[r for r in calls if r['frame_turned_count']==k]
    classes.append({'turned_frames':k,'unturned_frames':6-k,'raw_quarter_turn_vectors':64*math.comb(6,k),'ordered_nominal_physical_vectors':math.comb(6,k),'canonical_nominal_frame_vector':[0]*(6-k)+[1]*k,'closed_fixed_count_continuous_calls_in_selected_39_owner_family':len(selected),'closed_call_scopes':[[r['scope'],r['round']] for r in selected],'global_feasibility':'unresolved','orientation_class_excluded':False,'globally_untested_claimed':False})
same_fixed=scopes[0]['fixed_geometry_ignoring_copy_labels']==scopes[1]['fixed_geometry_ignoring_copy_labels'];same_domains=scopes[0]['frame_modes']==scopes[1]['frame_modes'];assert scopes[0]['source_stocks']==scopes[1]['source_stocks']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Enumerate all4^6 quarter-turn vectors separately for both checked39-owner source scopes. Verify exact nominal source-outline/effective-domain aliases0=180 and90=270; quotient the64 binary vectors by identical-frame permutations and cross-check every multiplicity against binomial coefficients. Read every actual closed93-parameter call in these two scopes. Failed calls do not exclude entire orientation classes; broader historical all-frame formulations are explicitly bound and not reclassified. No old optimized coordinate vector is used as a seed. Census only, no geometry search or optimizer.','optimizer_calls':0,'closed_calls_resumed':False})
write(OUT/'scopes.json',scopes);write(OUT/'closed-calls.json',calls);write(OUT/'orientation-classes.json',classes)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_scopes':2,'raw_vectors_per_scope':4096,'ordered_nominal_physical_vectors_per_scope':64,'orientation_count_classes':7,'closed_continuous_calls_mapped':4,'turned_counts_with_calls_in_selected_family':[0,4],'turned_counts_without_calls_in_selected_family':[1,2,3,5,6],'fixed_source_geometry_exactly_equal_ignoring_copy_labels':same_fixed,'frame_domains_exactly_equal':same_domains,'whole_orientation_classes_excluded':0,'globally_untested_classes_claimed':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
