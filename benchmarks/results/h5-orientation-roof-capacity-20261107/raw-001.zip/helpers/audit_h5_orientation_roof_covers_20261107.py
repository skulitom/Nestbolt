"""Independent exact containment, count-event masks and integer union areas."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
from bisect import bisect_left,bisect_right
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-orientation-roofs-20261107';BASE=ROOT/'output/h5-orientation-roof-covers-20261107';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PAD=Q(1,10**6)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def det(a,b):return a[0]*b[1]-a[1]*b[0]
def area(p):return sum(det(a,b) for a,b in zip(p,p[1:]+p[:1]))/2
def posed(vertices,pose):
    c,s=Q(math.cos(pose['rotation_radians'])),Q(math.sin(pose['rotation_radians']));m=-1 if pose['mirrored'] else 1;matrix=((m*c,-s),(m*s,c));translation=list(map(Q,pose['translation']));p=[tuple(sum(matrix[k][j]*Q(v[j]) for j in range(2))+translation[k] for k in range(2)) for v in vertices];return p if area(p)>0 else p[::-1]
def contains(p,r):
    corners=[(Q(x,1000)+sx*PAD,Q(y,1000)+sy*PAD) for x,sx in [(r[0],-1),(r[2],1)] for y,sy in [(r[1],-1),(r[3],1)]]
    return all(det((b[0]-a[0],b[1]-a[1]),(v[0]-a[0],v[1]-a[1]))>0 for a,b in zip(p,p[1:]+p[:1]) for v in corners)
def axis(cuts):return [v for i,x in enumerate(cuts) for v in ([2*x,x+cuts[i+1]] if i+1<len(cuts) else [2*x])]
def counts(xx,yy,rects):
    d=np.zeros((len(yy)+1,len(xx)+1),dtype=np.int32)
    for a,b,c,e in rects:
        i,j=bisect_right(xx,2*a),bisect_left(xx,2*c);k,l=bisect_right(yy,2*b),bisect_left(yy,2*e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
    return np.cumsum(np.cumsum(d,0,dtype=np.int32),1,dtype=np.int32)[:-1,:-1]
def union_area(rects):
    if not rects:return 0
    xs=sorted({r[k] for r in rects for k in [0,2]});ys=sorted({r[k] for r in rects for k in [1,3]});d=np.zeros((len(ys),len(xs)),dtype=np.int32)
    for a,b,c,e in rects:
        i,j=bisect_left(xs,a),bisect_left(xs,c);k,l=bisect_left(ys,b),bisect_left(ys,e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
    covered=np.cumsum(np.cumsum(d,axis=0),axis=1)[:-1,:-1]>0;return int(np.sum(covered*np.diff(ys)[:,None]*np.diff(xs)[None,:],dtype=np.int64))
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');prepared=load(BASE/'checks.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+[p for p in BASE.rglob('*') if p.is_file()]+[SOURCE/'audit/checks.json']:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Exact-rational source-contained obstacle and bracket rectangles, including floating evaluation padding. Independently reconstruct all open forbidden boxes and axis boundary/interval classes. For each site bit use signed corner counts and two prefix sums, then compare every mask. Verify exact retained class coverage per label, reconstruct occupied rectangles for every omission, and compute exact union area by a different two-dimensional signed-count grid. No Shapely, solver, optimizer or chosen pose search. Exclude only fixed cores with capacity below six.','process_cap_seconds':65,'retry_permitted':False})
assert load(SOURCE/'audit/checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};deriv=load(SOURCE/'cog-derivation.json');recipe=load(SOURCE/'source-recipe.json');fixed=load(SOURCE/'fixed27-source.json');stock=list(map(Q,recipe['source_stocks']['sheet-0']));geometries=load(BASE/'bracket-geometries.json');components=[[[0,0],[300,0],[300,75],[0,75]],[[0,75],[100,75],[100,250],[0,250]]]
assert parts['bracket']['geometry'][0]['outer']==[[0.,0.],[300.,0.],[300.,75.],[100.,75.],[100.,250.],[0.,250.]];assert parts['bracket']['allow_mirror'] and parts['bracket']['rotations']['degrees']==[0.,90.,180.,270.];assert len(geometries)==8;seen=set();maxdet=Q(0)
for g in geometries:
    t=g['pose'];seen.add((t['rotation_radians'],t['mirrored']));outer=posed(parts['bracket']['geometry'][0]['outer'],t);assert str(area(outer))==g['source_area_mm2'] and area(outer)>39999
    for p,r in zip(components,g['inner_components_um']):assert contains(posed(p,t),r)
    low=[min(v[k] for v in outer) for k in range(2)];high=[max(v[k] for v in outer) for k in range(2)];domain=[stock[0]-low[0]-PAD,stock[1]-low[1]-PAD,stock[2]-high[0]+PAD,stock[3]-high[1]+PAD];assert g['stock_center_domain_um']==[math.floor(v*1000) if k<2 else math.ceil(v*1000) for k,v in enumerate(domain)]
    assert g['outer_bounds_um']==[math.floor(v*1000)-1 if k<2 else math.ceil(v*1000)+1 for k,v in enumerate(low+high)];c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));maxdet=max(maxdet,abs(c*c+s*s-1))
assert seen==set(product([0,math.pi/2,math.pi,3*math.pi/2],[False,True]));rounding=Q(64*8192,2**53-64);assert rounding<PAD;area_error=6*(2*4096*PAD+PAD*PAD)+40000*maxdet;assert 40000-area_error>39999
fixture=counts([0,1,2,3,4],[0,1,2,3,4],[(0,0,2,2)]);assert fixture.tolist()==[[0,0,0,0,0],[0,1,1,1,0],[0,1,1,1,0],[0,1,1,1,0],[0,0,0,0,0]];assert union_area([[0,0,2,2],[1,1,3,3]])==7
total=0;rectangles=0;records=[];case_results=[]
for k in [1,2]:
    folder=BASE/f'turned-{k}';roof=load(SOURCE/f'turned-{k}/roof-source.json');sites=load(SOURCE/f'turned-{k}/sites.json');sources=load(folder/'source-inner-rectangles.json');shapes={};theta=deriv['rotation_radians'];c,s=math.cos(theta),math.sin(theta);cx,cy=deriv['source_center']
    frames={(r['part_id'],r['copy_index']):r for r in fixed+roof if r['sheet_id']=='sheet-0'};assert len(frames)==18
    for identity,row in frames.items():shapes[('frame',identity)]=[posed(parts['frame']['geometry'][0]['outer'],row['transform'])]
    for site in sites:
        t={'rotation_radians':theta,'mirrored':False,'translation':[site['center'][0]-(cx*c-cy*s),site['center'][1]-(cx*s+cy*c)]};shapes[('cog',site['site'])]=[posed(p,t) for p in deriv['convex_pieces']]
    for r in sources:
        if r['kind']=='frame':assert r['site_bit']==16;key=('frame',tuple(r['identity']))
        else:assert 0<=r['site_bit']<len(sites);key=('cog',r['site_bit'])
        p=shapes[key][r['piece']];assert all(abs(v)<4096 for point in p for v in point);assert contains(p,r['bounds_um']);rectangles+=1
    assert len({tuple(r['identity']) for r in sources if r['kind']=='frame'})==18 and {r['site_bit'] for r in sources if r['kind']=='cog'}==set(range(len(sites)))
    covers={}
    for g in geometries:
        mode=g['mode'];data=load(folder/f'mode-{mode:02d}.json');d=g['stock_center_domain_um'];expected=[]
        for si,r in enumerate(sources):
            u,v,w,z=r['bounds_um']
            for ci,(a,b,c,e) in enumerate(g['inner_components_um']):
                q=[u-c,v-e,w-a,z-b]
                if q[0]<d[2] and q[2]>d[0] and q[1]<d[3] and q[3]>d[1]:expected.append({'source':si,'component':ci,'bit':r['site_bit'],'bounds_um':q})
        assert expected==data['obstacles'];xs=sorted({d[0],d[2]}|{o['bounds_um'][j] for o in expected for j in [0,2] if d[0]<=o['bounds_um'][j]<=d[2]});ys=sorted({d[1],d[3]}|{o['bounds_um'][j] for o in expected for j in [1,3] if d[1]<=o['bounds_um'][j]<=d[3]});xx,yy=axis(xs),axis(ys);mask=np.zeros((len(yy),len(xx)),dtype=np.uint32)
        for bit in list(range(len(sites)))+[16]:
            values=counts(xx,yy,[o['bounds_um'] for o in expected if o['bit']==bit]);assert values.min()>=0;mask|=(values>0).astype(np.uint32)<<bit
        with np.load(folder/f'mode-{mode:02d}-classes.npz',allow_pickle=False) as saved:assert saved['xcuts_um'].tolist()==xs and saved['ycuts_um'].tolist()==ys and np.array_equal(saved['mask'],mask)
        legal=(mask==0) if k==1 else (((mask&65536)==0)&((mask&(mask-1))==0));covered=np.zeros(mask.shape,dtype=np.bool_)
        for label,a,b,c,e,xa,ya,xb,yb in data['cover']:
            assert [a,b,c,e]==[xs[xa//2],ys[ya//2],xs[(xb+1)//2],ys[(yb+1)//2]];assert np.all(mask[ya:yb+1,xa:xb+1]==label) and np.all(legal[ya:yb+1,xa:xb+1]);covered[ya:yb+1,xa:xb+1]=True
        assert np.array_equal(covered,legal);covers[mode]=data['cover'];total+=mask.size;records.append({'turned_frames':k,'mode':mode,'classes':int(mask.size),'retained_classes':int(legal.sum()),'cover_boxes':len(data['cover']),'independent_masks_and_complete_cover':True})
    for omission in ([None] if k==1 else list(range(16))):
        case='all15' if omission is None else f'omit-{omission:02d}';saved=load(folder/(case+'-capacity.json'));allowed=0 if omission is None else 1<<omission;rects=[]
        for g in geometries:
            a,b,c,e=g['outer_bounds_um']
            for label,l,bot,r,top,*_ in covers[g['mode']]:
                if label&~allowed==0:rects.append([l+a,bot+b,r+c,top+e])
        rects=list(map(list,sorted(set(map(tuple,rects)))));assert rects==saved['occupied_cover_rectangles_um'];exact=union_area(rects);capacity=exact//(39999*10**6);assert exact==saved['occupied_cover_union_area_um2'] and capacity==saved['provisional_bracket_capacity'];assert load(SOURCE/f'turned-{k}'/(case+'-checks.json'))['valid']
        case_results.append({'turned_frames':k,'case':case,'omitted_site':omission,'occupied_union_area_mm2':exact/1e6,'maximum_brackets_from_necessary_cover':capacity,'required_brackets':6,'fixed48_cannot_extend_to_full66':capacity<6,'capacity_at_least_six_proves_feasibility':False})
assert total==prepared['total_classes'];excluded=sum(c['fixed48_cannot_extend_to_full66'] for c in case_results);assert excluded==prepared['provisional_cases_below_six'];process=load(ROOT/'output/h5-orientation-roof-covers-process-20261107/process.json');assert process['passed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'class-controls.json',records);write(OUT/'capacity-results.json',case_results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source_inner_rectangles_verified':rectangles,'legal_bracket_modes':8,'continuous_classes_verified':int(total),'fixed48_cases':17,'fixed48_cores_excluded':excluded,'fixed48_cores_unresolved':17-excluded,'complete_preparation_seconds_if_consumed':charge,'bracket_area_error_bound_mm2':float(area_error),'whole_orientation_classes_excluded':0,'whole_allocations_excluded':0,'earlier_arrangements_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
