"""Three frozen original-source frame/cog constructions, before any solver."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from statistics import median
from itertools import combinations,product
import json,math,time,os
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,LineString
from h5_exact_convex_partition_tools_20261029 import merge_exact
from h5_legacy64_source_readback import audit
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-orientation-roofs-20261107'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';BENCH=ROOT/'benchmarks/results/h5-source-frontier-pilot-20261018/results.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def deadline():assert time.perf_counter()-began<18,'Preparation cap reached; no solver may run.'
def local(family,angle):
    c,s=math.cos(angle),math.sin(angle);return [(x*c-y*s,x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']]
def normalized(family,index,angle,xy,sheet='sheet-0'):
    v=local(family,angle)
    return {'part_id':family,'copy_index':index,'sheet_id':sheet,'transform':{'rotation_radians':angle,'mirrored':False,'translation':[xy[k]-min(p[k] for p in v) for k in range(2)]}}
def shape(row):
    t=row['transform'];v=local(row['part_id'],t['rotation_radians']);return Polygon([(x+t['translation'][0],y+t['translation'][1]) for x,y in v])
def cog_row(index,xy):
    c,s=math.cos(theta),math.sin(theta);cx,cy=center
    return {'part_id':'cog','copy_index':index,'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':False,'translation':[xy[0]-(cx*c-cy*s),xy[1]-(cx*s+cy*c)]}}
OUT.mkdir();began=time.perf_counter()
assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
inputs=[Path(__file__),JOB,BENCH]+[ROOT/'output'/n for n in ['h5_exact_convex_partition_tools_20261029.py','h5_legacy64_source_readback.py','h5_checked_affinity_20261107.py']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'source_inputs_only':[JOB.relative_to(ROOT).as_posix(),BENCH.relative_to(ROOT).as_posix()],'method':'Construct exactly three frame patterns from original dimensions. Keep twelve turned base frames, then three unturned frames in the first roof row. The last row has 3-k unturned followed by k turned frames, k=1,2,3. Derive one cog phase from tooth vertices and one outward axis pitch from all convex-piece differences plus the source gap square; no angle/pitch sweep. For k=1 use a3x3 left pool and2x3 right pool above their corresponding roof tops. For k=2,3 use4x3 above the highest roof and1x4 right of the second roof row above the first row. These latter16-site pools each induce every15-of16 case. All33 intended cores receive complete original-source checks even if invalid; invalid cases cannot proceed to a solver. Original holes are preserved, not nesting space. No old coordinates, optimizer states, numeric geometry or initializer is consumed. Historical orientation comparison occurs in a separate census.','turned_counts':[1,2,3],'proposed_cog_pool_sizes':[15,16,16],'intended_fixed48_cases':33,'preparation_internal_cap_seconds':18,'process_cap_seconds':20,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'inherited_numeric_preparation_seconds':0,'charge_entire_process_if_consumed':True,'optimizer_calls':0,'retry_permitted':False,'class_exclusions_claimed':False})
job=load(JOB);assert digest(JOB)=='2aede6286cf59186781a67a2c355f305aad2d50e735bbfa6cad5ea7dd2ffc6bb';parts={p['id']:p for p in job['parts']}
stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];lo=[m['left']+edge,m['bottom']+edge];hi=[stock['width']-m['right']-edge,stock['height']-m['top']-edge]
normal=[r for r in load(BENCH)['records'] if r['job']==job['name'] and r['kerf_mm']==.2 and r['arm']=='normal'];assert len(normal)==3 and {r['seed'] for r in normal}=={0,1,2} and all(r['status']=='valid' for r in normal)
normal_area=median(r['metrics']['material_area'] for r in normal);target=normal_area*1.01;short_height=(target-stock['width']*stock['height'])/stock['width'];stocks={'sheet-0':lo+hi,'sheet-1':lo+[hi[0],short_height-m['top']-edge]}
guard=max(stock['width'],stock['height'])*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);gap=math.ceil((required+.01)*100)/100;reserve=.025;origin=[v+reserve for v in lo];safe=[origin[0],origin[1],hi[0]-reserve,hi[1]-reserve]
write(OUT/'benchmark-target.json',{'normal_median_material_mm2':normal_area,'unchanged_multiplier':1.01,'target_material_mm2':target,'short_used_height_limit_mm':short_height,'source_stocks':stocks,'normal_records':[{'seed':r['seed'],'archive':r['archive'],'archive_sha256':r['archive_sha256'],'material_mm2':r['metrics']['material_area']} for r in normal]})
fv=parts['frame']['geometry'][0]['outer'];fw=max(p[0] for p in fv)-min(p[0] for p in fv);fh=max(p[1] for p in fv)-min(p[1] for p in fv);assert (fw,fh)==(450,350)
base=[normalized('frame',3*c+r,math.pi/2,[origin[0]+c*(fh+gap),origin[1]+r*(fw+gap)]) for c in range(4) for r in range(3)];base_top=origin[1]+3*fw+2*gap;roof_bottom=base_top+gap;row2=roof_bottom+fh+gap
br=parts['bracket']['geometry'][0]['outer'];assert br==[[0.,0.],[300.,0.],[300.,75.],[100.,75.],[100.,250.],[0.,250.]];arm,stem=br[2][1],br[3][0];iv=parts['insert']['geometry'][0]['outer'];iw=max(p[0] for p in iv)-min(p[0] for p in iv);ih=max(p[1] for p in iv)-min(p[1] for p in iv);mw,mh=2*arm+iw+2*gap,2*stem+ih+2*gap;short=[]
for n in range(3):
    x=origin[0]+n*(mw+gap);y=origin[1]
    short.extend([{'part_id':'bracket','copy_index':2*n,'sheet_id':'sheet-1','transform':{'rotation_radians':3*math.pi/2,'mirrored':False,'translation':[x,y+mh]}},{'part_id':'bracket','copy_index':2*n+1,'sheet_id':'sheet-1','transform':{'rotation_radians':math.pi/2,'mirrored':False,'translation':[x+mw,y]}},normalized('insert',11+n,0.,[x+arm+gap,y+stem+gap],'sheet-1')])
right=origin[0]+3*(mw+gap)
for n in range(4):short.append(normalized('insert',14+n,math.pi/2,[right+n*(ih+gap),origin[1]],'sheet-1'))
for n in range(2):short.append(normalized('insert',18+n,0.,[right+n*(iw+gap),origin[1]+iw+gap],'sheet-1'))
fixed=base+short;fixedcheck=audit(job,fixed,stocks,required,guard);assert fixedcheck['valid'] and len(fixed)==27;write(OUT/'fixed27-source.json',fixed);write(OUT/'fixed27-checks.json',fixedcheck)
cv=parts['cog']['geometry'][0]['outer'];center=[float((min(F(p[k]) for p in cv)+max(F(p[k]) for p in cv))/2) for k in range(2)];radii=[math.dist(p,center) for p in cv];threshold=(min(radii)+max(radii))/2;outer={i for i,r in enumerate(radii) if r>threshold};starts=[i for i in sorted(outer) if (i-1)%len(cv) not in outer];assert len(starts)==20 and all((i+1)%len(cv) in outer and (i+2)%len(cv) not in outer for i in starts)
polar=lambda i:math.atan2(cv[i][1]-center[1],cv[i][0]-center[0]);first,second=starts[:2];pitch_angle=(polar(second)-polar(first))%math.tau;bisector=polar(first)+((polar((first+1)%len(cv))-polar(first))%math.tau)/2;theta=.75*pitch_angle-bisector;radius=math.ceil(max(radii)*1e6)/1e6+.000001
triangles=list(shapely.constrained_delaunay_triangles(Polygon(cv)).geoms);pieces,merges=merge_exact(triangles);assert shapely.union_all([Polygon(p) for p in pieces]).equals(Polygon(cv));cs,sn=math.cos(theta),math.sin(theta);rotated=[np.array([[x*cs-y*sn,x*sn+y*cs] for x,y in p]) for p in pieces];square=np.array([[-gap,-gap],[gap,-gap],[gap,gap],[-gap,gap]]);extent=4*radius+4*gap;axes=[LineString([(-extent,0),(extent,0)]),LineString([(0,-extent),(0,extent)])];support=[]
for i,a in enumerate(rotated):
    for j,b in enumerate(rotated):
        diff=(a[:,None,:]-b[None,:,:]).reshape(-1,2);hull=MultiPoint((diff[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull
        support.append({'piece_pair':[i,j],'positive_axis_ends_mm':[None if (section:=hull.intersection(line)).is_empty else section.bounds[axis+2] for axis,line in enumerate(axes)]})
    deadline()
ends=[max(r['positive_axis_ends_mm'][k] for r in support if r['positive_axis_ends_mm'][k] is not None) for k in range(2)];pitch=math.ceil((max(ends)+.000002)*1000)/1000
write(OUT/'cog-derivation.json',{'source_center':center,'source_tooth_starts':starts,'source_tooth_pitch_radians':pitch_angle,'first_tooth_bisector_radians':bisector,'rotation_radians':theta,'rotation_degrees':math.degrees(theta),'radius_upper_mm':radius,'convex_pieces':pieces,'triangles':len(triangles),'exact_merges':merges,'pair_axis_sections':support,'positive_axis_maxima_mm':ends,'square_gap_mm':gap,'axis_pitch_mm':pitch})
write(OUT/'source-recipe.json',{'gap_mm':gap,'reserve_mm':reserve,'source_stocks':stocks,'safe_stock':safe,'required_pair_gap_mm':required,'stock_guard_mm':guard,'origin':origin,'frame_dimensions':[fw,fh],'base_top':base_top,'roof_bottom':roof_bottom,'second_roof_row_y':row2,'short_module_dimensions':[mw,mh]})
results=[]
for k in [1,2,3]:
    folder=OUT/f'turned-{k}';folder.mkdir();roof=[normalized('frame',12+c,0.,[origin[0]+c*(fw+gap),roof_bottom]) for c in range(3)];x=origin[0]
    for c in range(3):
        turned=c>=3-k;roof.append(normalized('frame',15+c,math.pi/2 if turned else 0.,[x,row2]));x+=(fh if turned else fw)+gap
    roof_right=x-gap;lower_top=row2+fh;higher_top=row2+fw;first_top=roof_bottom+fh;sites=[]
    blocks=[(3,3,origin[0]+radius,lower_top+gap+radius),(2,3,origin[0]+2*(fw+gap)+radius,higher_top+gap+radius)] if k==1 else [(4,3,origin[0]+radius,higher_top+gap+radius),(1,4,roof_right+gap+radius,first_top+gap+radius)]
    for block,(nx,ny,x0,y0) in enumerate(blocks):
        for cy in range(ny):
            for cx in range(nx):sites.append({'site':len(sites),'block':block,'grid':[cx,cy],'center':[x0+cx*pitch,y0+cy*pitch]})
    frames=base+roof;fs=[shape(r) for r in frames];shapes=[shape(cog_row(i,s['center'])) for i,s in enumerate(sites)];poolpairs=[];poolframes=[];poolstock=[]
    for i,j in combinations(range(len(sites)),2):
        distance=shapes[i].distance(shapes[j]);poolpairs.append({'sites':[i,j],'gap_mm':distance,'intersection_mm2':shapes[i].intersection(shapes[j]).area,'passed':distance+1e-7>=required})
    for i,g in enumerate(shapes):
        for j,f in enumerate(fs):
            distance=g.distance(f);poolframes.append({'site':i,'frame':j,'gap_mm':distance,'intersection_mm2':g.intersection(f).area,'passed':distance+1e-7>=required})
        b=g.bounds;poolstock.append({'site':i,'bounds':list(b),'passed':b[0]>=lo[0]+guard and b[1]>=lo[1]+guard and b[2]<=hi[0]-guard and b[3]<=hi[1]-guard})
    write(folder/'roof-source.json',roof);write(folder/'sites.json',sites);write(folder/'pool-checks.json',{'pairs':poolpairs,'frames':poolframes,'stock':poolstock,'pool_is_capacity_upper_bound':False,'anonymous_sites_not_extra_source_copies':True});cases=[]
    for omission in ([None] if k==1 else list(range(16))):
        selected=[s for s in sites if s['site']!=omission];assert len(selected)==15;rows=fixed+roof+[cog_row(i,s['center']) for i,s in enumerate(selected)];assert len(rows)==48
        check=audit(job,rows,stocks,required,guard);case='all15' if omission is None else f'omit-{omission:02d}';write(folder/(case+'-source.json'),rows);write(folder/(case+'-checks.json'),check)
        cases.append({'case':case,'omitted_site':omission,'source_valid48':check['valid'],'pair_failures':check['pair_failures'],'stock_failures':check['stock_failures']});deadline()
    write(folder/'cases.json',cases);results.append({'turned_roof_frames':k,'unturned_roof_frames':6-k,'site_count':len(sites),'cases':len(cases),'valid48_cases':sum(c['source_valid48'] for c in cases),'failed_site_pairs':sum(not r['passed'] for r in poolpairs),'failed_site_frame_pairs':sum(not r['passed'] for r in poolframes),'failed_sites_stock':sum(not r['passed'] for r in poolstock),'class_excluded':False})
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'patterns':results,'cases':sum(r['cases'] for r in results),'valid48_cases':sum(r['valid48_cases'] for r in results),'full66_cases':0,'remaining_parts_per_case':{'bracket':6,'insert':12},'optimizer_calls':0,'independent_audit_pending':True,'H5_complete':False});print(load(OUT/'checks.json'))
