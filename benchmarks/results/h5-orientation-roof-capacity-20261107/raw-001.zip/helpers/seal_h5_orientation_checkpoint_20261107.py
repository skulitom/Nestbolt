"""Archive the orientation census, source cores and continuous necessary covers."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-orientation-roof-capacity-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-orientation-roof-covers-20261107';F=BASE/'audit';D=ROOT/'output/h5-orientation-roofs-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-six-unturned-frame-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['fixed48_cores_excluded']==5 and front['fixed48_cores_unresolved']==12",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-upper-frame-orientation-classes-20261107',ROOT/'output/h5-four-row-necessary-main-sync-20261107']+[ROOT/'output'/('h5-'+n+'-process-20261107') for n in ['orientation-census','orientation-roofs','orientation-roofs-audit','orientation-roof-covers','orientation-roof-covers-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*orientation*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_orientation_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
census=ROOT/'output/h5-upper-frame-orientation-classes-20261107'
copies=[(census/'checks.json','census-checks.json'),(census/'orientation-classes.json','orientation-classes.json'),(census/'closed-calls.json','historical-closed-calls.json'),(D/'plan.json','source-plan.json'),(D/'benchmark-target.json','benchmark-target.json'),(D/'checks.json','source-cases.json'),(D/'audit/checks.json','source-audit.json'),(BASE/'plan.json','necessary-cover-plan.json'),(F/'checks.json','necessary-cover-audit.json'),(F/'capacity-results.json','fixed-core-capacities.json'),(F/'class-controls.json','class-controls.json'),(ROOT/'output/h5-four-row-necessary-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for n in ['orientation-census','orientation-roofs','orientation-roofs-audit','orientation-roof-covers','orientation-roof-covers-audit']:copies.append((ROOT/'output'/('h5-'+n+'-process-20261107')/'process.json',n+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42402787576','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='a45826d315434c357fa855da0be08162eabf94f3';write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime)})
unresolved=[r['omitted_site'] for r in load(F/'capacity-results.json') if not r['fixed48_cannot_extend_to_full66']];assert unresolved==[0,1,3,7,8,9,10,11,12,13,14,15]
write(OUT/'next-step.json',{'status':'source_cores_and_bracket_necessary_covers_audited','remaining_new_fixed48_cases':{'turned_roof_frames':2,'omitted_cog_sites':unresolved},'proposal':'Derive independent full-stock necessary covers for all allowed insert orientations in the two-turned-frame16-site pool. Combine each remaining case\'s bracket and insert occupied covers: six brackets and twelve inserts must all fit disjointly. Preserve all continuous boundary classes, source containment, original filled-outline semantics and exact union area; require an independent audit. Only if this coupled necessary screen leaves a case unresolved, construct a complete original-source companion model and initializer before any frozen bounded search.','constraints':['All old optimizer calls and mathematical keys remain closed. No saved optimized point is a new seed.','This constructor recomputes source geometry from original JOB and frozen normal metrics. Complete source1.5572348998393863s plus necessary-cover10.629206000128761s gives12.186440899968147s preparation if consumed; charge all additional preparation. Audits run separately.','The five new excluded cores and sixteen invalid three-turned cases concern only their exact fixed source geometry. They exclude no full orientation class or allocation.','The twelve unresolved cases are additional to four earlier arrangements and440 allocation candidates. The preserved valid64 remains best.','Full66 source/native/material checks, product integration, surface parity and original H5 jobs/two-kerf matrix remain required. H2 keeps its original denominator and22 reserved vectors unopened.'],'optimizer_calls':0,'full66_valid':False,'H5_complete':False})
report=f'''# Frame orientations and fixed-core capacity — 2026-11-07

**Seventeen source-valid 48-part cores** emerge from three declared frame
patterns. An independently checked necessary-area proof excludes **five** of
those exact cores; **twelve remain unresolved**. No optimizer runs. There is no
new full66 layout and the preserved valid64 remains best. H2/H5 remain open at
**60% completed milestone weight**.

[The complete orientation census]({NAME}/orientation-classes.json) enumerates
all4^6 quarter-turn vectors for each of two checked39-owner model scopes.
Identical nominal occupied frame outlines and effective hard domains reduce
them to64 ordered binary vectors and seven orientation-count classes.
Their multiplicities are64 times the corresponding binomial coefficients.
The [four closed calls]({NAME}/historical-closed-calls.json) used turned counts
4,4,4 and0. The fixed source geometry and frame domains match exactly after
copy labels are ignored. This classification concerns occupied outlines;
original holes remain preserved and are not nesting space. Earlier broader
models are bound in the archive: no class is claimed globally untested or
excluded merely because these four calls failed.

[Fresh source construction]({NAME}/source-plan.json) reads only the original
job and [unchanged normal acceptance metrics]({NAME}/benchmark-target.json)
as numeric inputs. Twelve turned base frames and the six-bracket/nine-insert
short-sheet modules are reconstructed. Above the base, three unturned frames
form the first roof row. The second roof row has one, two or three turned
frames, with the other frames unturned. One cog phase is derived from source
tooth vertices; all convex-piece difference hulls determine one outward axis
pitch. There is no phase or pitch sweep, old coordinate seed or resumed call.

The one-turned pattern uses15 cog sites. The two- and three-turned patterns
each propose16 sites, with every single-site omission checked. Thus all
**33 declared cases** receive complete original-source readback. [Independent
source checks]({NAME}/source-audit.json) replay all33 cases, **882 axis sections**
using a separate hull/line calculation, **1,191 direct pool/frame distances**
and **1,980 original holes across the cases**. The one-turned case and all16
two-turned cases pass. The three-turned pool has collided pairs3/14 and7/15;
deleting one site cannot remove both collisions. All16 failures are preserved.
The smallest passing cog/cog gap is **0.301548 mm**.

[Necessary covers]({NAME}/necessary-cover-plan.json) consider all eight allowed
bracket orientations over the entire physical first stock. Source-contained
inner rectangles induce open forbidden center rectangles at zero clearance.
Every axis boundary point and intervening open interval is represented.
Cog-site masks produce all omission cases together; fixed frames cannot be
omitted. These are necessary outer covers, not sufficient placement domains.

[Independent proof readback]({NAME}/necessary-cover-audit.json) verifies
**2,423 source-contained rectangles** and **40,376,496 continuous classes**
using signed corner counts and prefix sums instead of the producer's slice
assignment. Every retained class is covered with its correct mask. Exact
integer unions of outward occupied rectangles bound all possible bracket
footprints. A conservative **39,999 mm²** per bracket includes the checked
floating area allowance; six brackets are required.

| Exact fixed core | Occupied-cover area (mm²) | Brackets at most | Outcome |
|---|---:|---:|---|
| One turned roof frame, all15 sites | 99,544.864275 | 2 | Cannot extend to66 |
| Two turned roof frames, omit site2 | 158,995.726128 | 3 | Cannot extend to66 |
| Two turned roof frames, omit site4 | 158,995.726128 | 3 | Cannot extend to66 |
| Two turned roof frames, omit site5 | 158,995.726128 | 3 | Cannot extend to66 |
| Two turned roof frames, omit site6 | 158,995.726128 | 3 | Cannot extend to66 |
| Other twelve two-turned cases | 260,889.014200–341,336.756218 | 6–8 | Unresolved |

[Every exact case and bound]({NAME}/fixed-core-capacities.json) is retained.
A bound of six or more does not establish feasibility. Moving a frame or cog
changes the fixed-core problem; no orientation class or whole allocation is
excluded. Four earlier arrangements and440 allocations remain unresolved.

[Source preparation]({NAME}/orientation-roofs-process.json) takes **1.557235 s**,
and [necessary-cover preparation]({NAME}/orientation-roof-covers-process.json)
**10.629206 s**: **12.186441 s** total if consumed. Full source and proof audits
take **1.920012 s** and **11.192307 s**, separately. The census takes0.226364 s.
Each bounded Job Object closes all three processes under the2GiB cap, logical
CPUs16–31 and single BLAS/OMP/MKL threads. No time limit is relaxed and no
closed computation is restarted.

[Next]({NAME}/next-step.json), compute source-necessary insert covers and
combine them with the bracket covers for the remaining twelve exact cases.
Only a case surviving the coupled screen can justify a complete companion
model and bounded search. Full source/native/material validity, product
integration, UI/CLI/MCP parity and the original H5 matrix are still required.

[Main a45826d3]({NAME}/prior-main-push-receipt.json) contains the earlier two
checkpoints, pushed ordinarily after all six prior checks passed with52
protected files intact. Its [current CI snapshot]({NAME}/main-ci-at-review.json)
has **{success} passed / {live} live jobs**. The subsequent six-unturned checkpoint
and this evidence checkpoint await the ordinary main push gate. Product code,
README and releases are unchanged.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve inputs and outcomes.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 orientation and fixed-core capacity:** [complete source and necessary-cover audits]({{link}}) enumerate seven nominal frame-orientation classes in the checked39-owner scopes; the four closed calls used counts4,4,4,0 without excluding a class. Three fresh source patterns with counts1,2,3 yield33 declared48part cases:17 pass and16 fail two disjoint cog contacts. Independent readback checks882 axis sections,1191 distances and every case. Exact bracket covers verify2423 source-contained rectangles and40376496 continuous classes. The one-turned core holds at most2 brackets; four two-turned omission cores hold at most3, below6 required. These five exact cores are excluded;12 new cases remain unresolved, alongside four earlier arrangements and440 allocations. No optimizer runs and valid64 remains best. Complete consumed preparation is12.186441s; separate audits pass and all processes close. Next derive insert covers and the coupled six-bracket/twelve-insert area bound before any complete model. H2/H5 remain open at60%. Main a45826d3 has{success}passed/{live}live CI jobs; this and the preceding six-unturned checkpoint await the ordinary push gate. Product and release state is unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';text=p.read_text(encoding='utf-8');a=text.index('Latest H5 evidence:');b=text.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [frame orientation and fixed-core capacity](../benchmarks/results/{NAME}.md).
Seven nominal orientation-count classes are verified in the checked39-owner
model scopes. Three source-derived roof patterns yield17 valid48part cores
and16 invalid cases. Independent full-stock bracket covers exclude five exact
cores after2423 source-containment checks and40376496 continuous classes.
Twelve new two-turned-frame cases remain unresolved; no full66 placement or
optimizer call results. Complete consumed preparation is12.186441s, with
separate source/proof audits and all bounded processes closed. Next derive
insert covers and a coupled six-bracket/twelve-insert area bound before any
complete companion model. All prior calls stay closed and valid64 remains
best. No whole orientation class or allocation is excluded. Four earlier
arrangements and440 allocations remain. H2/H5 stay open at60%. Main a45826d3
has{success}passed/{live}live CI jobs; this and the preceding six-unturned
checkpoint await the ordinary main push gate. Product and releases unchanged.
'''
p.write_text(text[:a]+intro+text[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings)})
