from pathlib import Path
root=Path(__file__).resolve().parents[1]
template=(root/'output/run_h5_six_unturned_source_stage_20261107.py').read_text(encoding='utf-8')
for name,script,cap in [('orientation_census','audit_h5_upper_frame_orientation_classes_20261107.py',10),('orientation_roofs','prepare_h5_orientation_roofs_20261107.py',20)]:
    value=template.replace('prepare_h5_six_unturned_source_20261107.py',script).replace("',20)","',"+str(cap)+")").replace('h5-six-unturned-source-process-20261107','h5-'+name.replace('_','-')+'-process-20261107')
    with (root/'output'/('run_h5_'+name+'_stage_20261107.py')).open('x',encoding='utf-8',newline='\n') as f:f.write(value)
