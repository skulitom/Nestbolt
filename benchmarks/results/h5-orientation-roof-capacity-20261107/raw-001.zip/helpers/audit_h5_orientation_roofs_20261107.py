"""Independent source, construction, pair and census readback."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations,product
from collections import Counter
from statistics import median
import json,math,time
import numpy as np
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-orientation-roofs-20261107';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def edge_count(p):
    out=Counter()
    for a,b in zip(p,p[1:]+p[:1]):
        a,b=tuple(a),tuple(b);out[(min(a,b),max(a,b))]+=1 if a<b else -1
    return out
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
    points=sorted(set(map(tuple,points)));halves=[]
    for chain in [points,points[::-1]]:
        q=[]
        for p in chain:
            while len(q)>1 and cross(q[-2],q[-1],p)<=0:q.pop()
            q.append(p)
        halves.append(q[:-1])
    return halves[0]+halves[1]
def axis_end(p,k):
    vals=[];other=1-k
    for a,b in zip(p,p[1:]+p[:1]):
        if a[other]==0:vals.append(a[k])
        if a[other]*b[other]<0:vals.append(a[k]+(b[k]-a[k])*(-a[other])/(b[other]-a[other]))
    return max(vals) if vals else None
def world(row):
    t=row['transform'];theta=t['rotation_radians'];c,s=math.cos(theta),math.sin(theta);matrix=np.array([[c,-s],[s,c]])
    p=np.array(parts[row['part_id']]['geometry'][0]['outer']);return p@matrix.T+np.array(t['translation'])
def direct_gap(a,b):
    def one(p,q):
        d=np.roll(q,-1,axis=0)-q;v=p[:,None,:]-q[None,:,:];t=np.clip((v*d[None,:,:]).sum(2)/(d*d).sum(1)[None,:],0,1);delta=v-t[:,:,None]*d[None,:,:];return float(np.sqrt((delta*delta).sum(2).min()))
    return min(one(a,b),one(b,a))
OUT.mkdir();began=time.perf_counter();job=load(JOB);parts={p['id']:p for p in job['parts']};plan=load(BASE/'plan.json')
for path,sha in plan['inputs'].items():assert digest(ROOT/path)==sha
inputs=[Path(__file__),JOB]+sorted(BASE.glob('*.json'))+[p for p in sorted(BASE.glob('turned-*/*.json'))]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently reconstruct source dimensions, normal comparator, exact boundary-cancelling convex partition and source-derived phase. Recompute every pair NFP axis endpoint using a monotone-chain hull and explicit line intersections (no Shapely hull/section). Replay all three frame/grid recipes. Compare every pool record with independently matrix-transformed original outlines and direct vertex-to-segment distances. Replay every48part case and all original holes/identities using the source validator. Verify census orbit multiplicities and all closed frame counts. No optimizer or changed layout.'})
recipe=load(BASE/'source-recipe.json');target=load(BASE/'benchmark-target.json');deriv=load(BASE/'cog-derivation.json');stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];lo=[m['left']+edge,m['bottom']+edge];hi=[stock['width']-m['right']-edge,stock['height']-m['top']-edge];origin=[v+.025 for v in lo];guard=max(stock['width'],stock['height'])*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);gap=math.ceil((required+.01)*100)/100
normal=[r for r in load(ROOT/'benchmarks/results/h5-source-frontier-pilot-20261018/results.json')['records'] if r['job']==job['name'] and r['kerf_mm']==.2 and r['arm']=='normal'];material=median(r['metrics']['material_area'] for r in normal)*1.01;short_height=(material-stock['width']*stock['height'])/stock['width'];stocks={'sheet-0':lo+hi,'sheet-1':lo+[hi[0],short_height-m['top']-edge]};assert stocks==recipe['source_stocks']==target['source_stocks'] and material==target['target_material_mm2']
assert recipe['origin']==origin and recipe['gap_mm']==gap and recipe['required_pair_gap_mm']==required and recipe['stock_guard_mm']==guard
cv=parts['cog']['geometry'][0]['outer'];center=[(min(p[k] for p in cv)+max(p[k] for p in cv))/2 for k in range(2)];assert center==deriv['source_center'];radii=[math.dist(p,center) for p in cv];threshold=(max(radii)+min(radii))/2;starts=[i for i,r in enumerate(radii) if r>threshold and radii[i-1]<=threshold];polar=lambda i:math.atan2(cv[i][1]-center[1],cv[i][0]-center[0]);pitch_angle=(polar(starts[1])-polar(starts[0]))%math.tau;bisector=polar(starts[0])+((polar(starts[0]+1)-polar(starts[0]))%math.tau)/2;theta=.75*pitch_angle-bisector;assert theta==deriv['rotation_radians'] and starts==deriv['source_tooth_starts'];radius=math.ceil(max(radii)*1e6)/1e6+.000001;assert radius==deriv['radius_upper_mm']
edges=Counter();pieces=deriv['convex_pieces']
for piece in pieces:
    exact=[tuple(map(F,p)) for p in piece];assert all(cross(a,b,c)>=0 for a,b,c in zip(exact,exact[1:]+exact[:1],exact[2:]+exact[:2]));edges.update(edge_count(piece))
assert {k:v for k,v in edges.items() if v}=={k:v for k,v in edge_count(cv).items() if v}
c,s=math.cos(theta),math.sin(theta);rotated=[[(x*c-y*s,x*s+y*c) for x,y in p] for p in pieces];allends=[]
for row in deriv['pair_axis_sections']:
    i,j=row['piece_pair'];p=hull([(a[0]-b[0]+dx,a[1]-b[1]+dy) for a,b in product(rotated[i],rotated[j]) for dx,dy in product([-gap,gap],repeat=2)]);ends=[axis_end(p,k) for k in range(2)]
    for expected,actual in zip(row['positive_axis_ends_mm'],ends):assert (expected is None and actual is None) or (expected is not None and actual is not None and abs(expected-actual)<1e-9)
    allends.extend(v for v in ends if v is not None)
pitch=math.ceil((max(allends)+.000002)*1000)/1000;assert pitch==deriv['axis_pitch_mm'];fixed=load(BASE/'fixed27-source.json');assert len(fixed)==27 and audit(job,fixed,stocks,required,guard)['valid']
fw,fh=recipe['frame_dimensions'];assert [fw,fh]==[450,350];row1=origin[1]+3*fw+3*gap;row2=row1+fh+gap;counts=[];pairtotal=0;holetotal=0;min_gap=math.inf
for k in [1,2,3]:
    folder=BASE/f'turned-{k}';roof=load(folder/'roof-source.json');sites=load(folder/'sites.json');checks=load(folder/'pool-checks.json');assert [r['copy_index'] for r in roof]==list(range(12,18));assert sum(r['transform']['rotation_radians']!=0 for r in roof)==k
    expected=[];x=origin[0]
    for i in range(6):
        turned=i>=6-k;angle=math.pi/2 if turned else 0;xy=[origin[0]+i*(fw+gap),row1] if i<3 else [x,row2]
        if i>=3:x+=(fh if turned else fw)+gap
        vv=world(roof[i]);assert roof[i]['transform']['rotation_radians']==angle;assert np.allclose(vv.min(0),xy,atol=1e-10,rtol=0)
    roofright=x-gap
    blocks=[(3,3,origin[0]+radius,row2+fh+gap+radius),(2,3,origin[0]+2*(fw+gap)+radius,row2+fw+gap+radius)] if k==1 else [(4,3,origin[0]+radius,row2+fw+gap+radius),(1,4,roofright+gap+radius,row1+fh+gap+radius)]
    expected=[(block,[cx,cy],[x0+cx*pitch,y0+cy*pitch]) for block,(nx,ny,x0,y0) in enumerate(blocks) for cy in range(ny) for cx in range(nx)];assert len(expected)==len(sites)
    for rec,(block,grid,xy) in zip(sites,expected):assert rec['block']==block and rec['grid']==grid and rec['center']==xy
    cogvertices=[(np.array(cv)-center)@np.array([[c,s],[-s,c]])+site['center'] for site in sites];polys=list(map(Polygon,cogvertices));frames=[world(r) for r in fixed if r['part_id']=='frame']+list(map(world,roof));framepolys=list(map(Polygon,frames));badpairs=[]
    for rec in checks['pairs']:
        i,j=rec['sites'];a,b=polys[i],polys[j];area=a.intersection(b).area;d=0. if area>0 else direct_gap(cogvertices[i],cogvertices[j]);assert abs(area-rec['intersection_mm2'])<1e-7 and abs(d-rec['gap_mm'])<1e-8 and rec['passed']==(d+1e-7>=required);pairtotal+=1
        if not rec['passed']:badpairs.append([i,j])
        else:min_gap=min(min_gap,d)
    for rec in checks['frames']:
        i,j=rec['site'],rec['frame'];area=polys[i].intersection(framepolys[j]).area;d=0. if area>0 else direct_gap(cogvertices[i],frames[j]);assert abs(area-rec['intersection_mm2'])<1e-7 and abs(d-rec['gap_mm'])<1e-8 and rec['passed']==(d+1e-7>=required);pairtotal+=1
    for rec in checks['stock']:
        b=polys[rec['site']].bounds;assert np.allclose(b,rec['bounds'],rtol=0,atol=1e-10) and rec['passed']==(b[0]>=lo[0]+guard and b[1]>=lo[1]+guard and b[2]<=hi[0]-guard and b[3]<=hi[1]-guard)
    cases=load(folder/'cases.json');valid=0
    for case in cases:
        rows=load(folder/(case['case']+'-source.json'));stored=load(folder/(case['case']+'-checks.json'));fresh=audit(job,rows,stocks,required,guard);assert fresh==stored and fresh['valid']==case['source_valid48'];assert rows[:27]==fixed and rows[27:33]==roof
        chosen=[r for r in sites if r['site']!=case['omitted_site']]
        for index,(row,site) in enumerate(zip(rows[33:],chosen)):
            assert row['part_id']=='cog' and row['copy_index']==index and row['transform']['rotation_radians']==theta;assert np.allclose(world(row),cogvertices[site['site']],atol=1e-10,rtol=0)
        assert len({(r['part_id'],r['copy_index']) for r in rows})==48;valid+=fresh['valid'];holetotal+=fresh['source_holes_checked'] if 'source_holes_checked' in fresh else sum(len(parts[r['part_id']]['geometry'][0]['holes']) for r in rows)
    if k==3:assert len(badpairs)==2 and set(badpairs[0]).isdisjoint(badpairs[1]) and valid==0
    counts.append({'turned_count':k,'cases':len(cases),'valid48':valid,'bad_pool_pairs':badpairs})
census=load(ROOT/'output/h5-upper-frame-orientation-classes-20261107/orientation-classes.json');assert len(census)==7
for k,r in enumerate(census):assert r['turned_frames']==k and r['raw_quarter_turn_vectors']==math.comb(6,k)*64 and r['ordered_nominal_physical_vectors']==math.comb(6,k) and not r['orientation_class_excluded']
assert [r['valid48'] for r in counts]==[1,16,0]
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'patterns':counts,'independent_axis_sections':2*len(deriv['pair_axis_sections']),'independent_pool_pair_and_frame_distances':pairtotal,'minimum_valid_cog_pair_gap_mm':min_gap,'full48_cases_replayed':33,'valid48_cases':17,'original_holes_across_cases':holetotal,'census_classes':7,'third_pattern_failure':'Two vertex-disjoint collided cog pairs; deleting one site cannot remove both. Only these16 exact cases fail.','whole_orientation_classes_excluded':0,'full66_placements':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
