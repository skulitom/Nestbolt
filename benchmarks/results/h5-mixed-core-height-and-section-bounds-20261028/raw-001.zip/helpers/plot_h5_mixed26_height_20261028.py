"""Show the checked filled outers, keeping cutouts visibly reserved with PIH off."""
from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed26-height-20261028';load=lambda p:json.loads(p.read_bytes());parts={p['id']:p for p in load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json')['parts']};rows=load(BASE/'response-audit/source41.json');assert load(BASE/'source-audit/checks.json')['passed'];colors={'frame':'#d2dbe3','bracket':'#d69052','insert':'#6da998'}
fig,axes=plt.subplots(1,2,figsize=(12,11),gridspec_kw={'width_ratios':[1,1]});fig.suptitle('Checked 41-part core — all 25 remaining parts still required',fontsize=17)
for sheet,ax in enumerate(axes):
    for p in rows:
        if p['sheet_id']!=f'sheet-{sheet}':continue
        t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];g=parts[p['part_id']]['geometry'][0]
        def tr(r):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in r]
        outer=tr(g['outer']);ax.add_patch(Patch(outer,facecolor=colors[p['part_id']],edgecolor='#33424e',linewidth=.65))
        for hole in g.get('holes',[]):ax.add_patch(Patch(tr(hole),fill=False,edgecolor='#6f7a84',linewidth=.4,linestyle=':'))
        x0=min(x for x,y in outer);x1=max(x for x,y in outer);y0=min(y for x,y in outer);y1=max(y for x,y in outer);ax.text((x0+x1)/2,(y0+y1)/2,p['part_id'][0].upper()+str(p['copy_index']),ha='center',va='center',fontsize=7)
    height=3000 if sheet==0 else 325.92690233;ax.set_xlim(0,1500);ax.set_ylim(height,0);ax.set_aspect('equal');ax.set_xlabel('mm');ax.set_ylabel('mm');ax.set_title('First sheet: 26 optimized originals' if sheet==0 else 'Short sheet: 15 preserved originals');ax.grid(alpha=.15)
axes[0].axhline(2157.409,color='#7b3e46',linestyle='--',linewidth=.8);axes[0].text(750,2570,'Still required: 3 brackets,\n7 inserts and 15 cogs',ha='center',fontsize=13,color='#5b2730');axes[1].text(750,620,'Holes remain reserved.\nThis is not a complete layout.\n\nCore top is 10.466 mm lower.\nAll 25 other parts still need placement;\nno full-job material gain is claimed.',ha='center',fontsize=12,va='top');fig.tight_layout();fig.savefig(BASE/'core.png',dpi=140);plt.close(fig)
