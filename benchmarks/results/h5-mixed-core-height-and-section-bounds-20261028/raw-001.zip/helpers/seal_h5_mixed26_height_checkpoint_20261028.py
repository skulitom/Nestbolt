"""Seal source-valid mixed-core compaction and exact section-weight bounds."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-mixed26-height-20261028';PUB=BASE/'publication';NAME='h5-mixed-core-height-and-section-bounds-20261028';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='2adfa5699201a537ad04d5f58e772e27bae7aefe' and not git('diff','HEAD','--name-only')
geometry=load(BASE/'geometry-audit/checks.json');model=load(BASE/'model-audit/checks.json');response=load(BASE/'response-audit/checks.json');source=load(BASE/'source-audit/checks.json');free=load(BASE/'new-free-regions/audit/checks.json');bounds=load(BASE/'section-bounds/audit/checks.json')
assert all(r['passed'] for r in [geometry,model,response,source,free,bounds]);assert response['status']=='FEASIBLE' and response['incumbents_verified']==7 and source['actual_core_top_mm']==2157.409
assert bounds['certificates'][1]['comparison_core_height_excluded'] and bounds['total_section_patterns_verified']==11741
for case in load(BASE/'section-bounds/plan.json')['cases']:assert 0<=load(BASE/'section-bounds'/case['name']/'linear-program-result.json')['seconds']<10
prior=load(ROOT/'benchmarks/results/h5-staggered-core-independent-placement-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest']
readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==prior[k] for k in up);assert load(PUB/'main.json')['commit']['sha']==head
jobs=load(PUB/'main-ci-jobs.json')['jobs'];passed=[r['name'] for r in jobs if r['status']=='completed' and r['conclusion']=='success'];live=[r['name'] for r in jobs if r['status']!='completed']
assert len(jobs)==6 and len(passed)==4 and set(live)=={'checks (ubuntu-latest)','checks (windows-latest)'}
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-staggered25-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_mixed26_height_20261028.py','audit_h5_mixed26_height_geometry_20261028.py','build_h5_mixed26_height_model_20261028.py',
    'audit_h5_mixed26_height_model_20261028.py','run_h5_mixed26_height_model_20261028.py','audit_h5_mixed26_height_response_20261028.py',
    'audit_h5_mixed26_height_source_20261028.py','plot_h5_mixed26_height_20261028.py','plot_h5_mixed26_height_labelled_20261028.py',
    'prepare_h5_mixed26_free_regions_20261028.py','audit_h5_mixed26_free_regions_20261028.py','derive_h5_mixed_core_section_bounds_20261028.py',
    'audit_h5_mixed_core_section_bounds_20261028.py','push_staggered25_checkpoint_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[('geometry-audit/checks.json','source-geometry-audit.json'),('model-audit/checks.json','model-audit.json'),('response-audit/checks.json','response-audit.json'),
    ('source-audit/checks.json','source-audit.json'),('source-audit/incumbents.json','source-incumbents.json'),('response-audit/source41.json','source41.json'),('remaining25.json','remaining25.json'),
    ('core-labelled.png','core.png'),('new-free-regions/comparisons.json','free-region-comparisons.json'),('new-free-regions/audit/checks.json','free-region-audit.json'),
    ('section-bounds/audit/checks.json','section-bound-audit.json'),('section-bounds/audit/certificates.json','height-certificates.json'),('section-bounds/audit/proof.json','height-bound-proof.json'),
    ('publication/main-ci-jobs.json','prior-main-ci.json')]
for a,b in copies:shutil.copyfile(BASE/a,OUT/b)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,'production_digest':production,'current_readmes':readmes,**up,
    'upstream_heads_and_releases_unchanged':True,'main_CI':40735870933,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,
    'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'independent_audits':6,'core_solver_status':'FEASIBLE','core_search_closed':True,'packing_solver_calls':1,'linear_program_proposals':3,
    'exact_height_certificates':3,'source41_valid':True,'new_core_top_mm':2157.409,'core_height_reduction_mm':10.466,'source64_core_plus_two_brackets_at_old_height_excluded':True,
    'previous_source64_preserved':True,'remaining_necessary_allocations':444,'full66_witness':False,'actual_full66_exclusion_claimed':False,'native_calls':0,
    'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='The mixed26 core-height optimization is CLOSED FEASIBLE at2157.409mm,10.466mm below its starting height; preserve all7 incumbents and0.0475587s returned soft overrun. All8 model assignments and all7 original-source incumbents plus final41 pass. The new owner-dependent free regions are audited; cog anchor-area gain is only1354.085730mm2 (about0.20%) and some prior positions are removed. Do not rerun the same height model or automatically repeat the closed25-mover placement call for this modest domain change. Exact section weights cover every quarter/mirror mode and arbitrary positions: current26 core top>=2113.619939mm; old source64 frame18/insert11 core with the2 missing brackets added requires>=2144.593263mm, excluding its old2107.65mm height by36.943263mm; all36 first-sheet noncogs under short6/9 require>=2249.796028mm. These are core-height bounds only, not full66/count exclusions. A fully separate cog band above that last core could have at most about743.481mm of height at the unchanged stock/gaps, so the existing772.329mm cog packet cannot simply be stacked above it. Next investigate cog-packet height directly with a materially different source model: all15 cog positions independent, original full usable width, a height objective, initially the already audited phase7 constructive subset and exact intrinsic cog pair cells. Review existing fixed triangular and oblique finite constructions first; none of their closed calls may be resumed. Prepare a complete original-source-valid, conservative-cell-compatible cog control (the existing oblique source64 packet needs careful clearance adjustment before any rounded hint), audit all coordinates/cell constraints/objective, and declare one bounded call only after those checks. A phase7 no-result or optimum is not a free-angle/global proof. A useful cog-height result still needs the complementary original noncogs and all66 readback/native/material evidence before integration or full H5 matrix. Keep all444 necessary count candidates, old valid64, H2 original gate and22 unopened reserved vectors. Prior push2adfa569 is recorded; CI40735870933 has4passing and Ubuntu/Windows checks live at review. Wait for allsix and fresh refs before the next normal push. No release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Mixed-core compaction and exact height bounds — 2026-10-28

A new source-valid mixed core is **10.466 mm shorter**. Exact section-weight
certificates also rule out simply adding the two missing brackets to the old
source64 lower core without raising its top. These are partial constructions
and scoped core-height bounds. H2/H5 remain open at **60% completed milestone
weight**; no full 66-part placement or H5 material result follows.

## Core optimization and source readback

The new model moves all 18 frames, three L brackets and five inserts independently.
It retains all four frame/insert quarter turns and all eight bracket quarter /
mirror modes. The actual short15 layout remains exact. All 25 remaining originals
are explicitly listed. The unchanged stock, source gap, margin and material target
apply; part-in-hole remains off as required by the plan.

Each full source outer is expanded by 112 µm, then its union is partitioned into
rectangles with disjoint interiors. This preserves the complete L shape without
creating collisions between overlapping padded pieces of the same bracket.
Independent readback verifies all 16 source/expanded mode unions and the complete
valid initial core, including 325 expanded original-pair checks. The complete
model audit covers **169 variables, 564 constraints, 52 independent coordinates,
116 legal mode options, 140 expanded component options and every hint value**.

The sole 60-second, four-worker optimization returns **FEASIBLE**, with seven
incumbents. The final top is **2,157.409 mm**, down from 2,167.875 mm. Solver time
is 60.046240 s, returned time 60.047559 s and shared time 60.831537 s. The returned
soft overrun of **0.047559 s** is retained. Its solver bound is 2,062.452 mm;
the result is not a proven optimum. Returned protobuf branch/conflict counters
are zero, which does not mean the worker portfolio performed no search.

All seven incumbents and the final assignment pass the independent model reader,
including 406 expanded component pairs per assignment. Every incumbent and the
final layout also pass original-source readback. Each includes 41 originals,
**430 same-sheet pairs, 164 stock edges and all 59 holes / 5,074 hole vertices**.
Final minimum source gap is 0.224 mm and extra stock clearance is 0.013 mm.
The earlier valid64 is preserved; this smaller core is not a better full partial
count. No native call is made.

![Source-valid optimized core and preserved short sheet]({NAME}/core.png)

## Changed placement regions

All eleven source-mode free regions are rebuilt against the new 26 first-sheet
poses. Independent source geometry checks cover 286 neighbour relations and
3,920 Minkowski hulls. The cog-anchor region grows by **1,354.085730 mm²**, about
**0.20%**. It gains 1,744.991891 mm² but loses 390.906160 mm²; lower maximum height
does not preserve every old position. Bracket/insert regions likewise have both
additions and removals. These modest changes do not justify blindly repeating
the closed 25-mover search.

## Exact section-weight bounds

Three bounded linear programs propose weights for source-contained rectangular
sections. Their floating results are not used as proof. Each proposal is converted
to exact rational weights and normalized by the exact maximum feasible section
weight. A separate reader reconstructs every legal source quarter/mirror mode,
checks 24 contained rectangles against 128 exact source edges, independently
enumerates all **11,741 section-count patterns**, and verifies every rational sum.
Each bracket's two rectangles have disjoint Y spans, so at most one component
from that original appears at a horizontal section. Integrating these section
weights gives necessary bounds for arbitrary independent core positions.

| Core composition | Patterns | Necessary minimum top |
| --- | ---: | ---: |
| 18 frames, 3 brackets, 5 inserts | 2,369 | 2,113.619939 mm |
| 18 frames, 2 brackets, 11 inserts | 1,827 | 2,144.593263 mm |
| 18 frames, 6 brackets, 12 inserts | 7,545 | 2,249.796028 mm |

The second composition is the source64 frame/insert core with its two missing
brackets added. It **cannot fit within the old 2,107.65 mm core height**, even
with arbitrary repositioning and every legal turn/mirror: the minimum exceeds
that height by **36.943263 mm**. This excludes that particular lower-core repair,
not the full job. Cogs and upper inserts would also need a changed arrangement.

The first certificate leaves at most 43.789061 mm of further height reduction
for the new mixed26 core. The third covers every first-sheet non-cog under the
actual short6/9 allocation. If all cogs were placed in a wholly separate band
above those non-cogs, only about **743.481 mm** could remain after the original
stock guard and source gap. The existing 772.329 mm cog packet cannot simply be
stacked above that core. Interleaved full layouts remain possible; no full66,
free-angle cog or count-frontier exclusion is claimed.

The next investigation therefore targets cog-packet height with independently
movable source coordinates and a height objective, beginning with the audited
phase7 constructive subset. Review the earlier fixed triangular/oblique attempts,
build and audit a fully valid positive control, and declare a new bounded call
only after checking the entire model. Existing closed calls remain closed. A
useful packet still requires all complementary originals, full66 source/native
validation and material evidence before integration or a new H5 matrix.

## Publication state

The previous two checkpoints were normally pushed to main and the working branch
as **2adfa569**, after all six jobs on d71c9c85 passed. The receipt is archived.
At this review CI 40735870933 has four passing jobs; Ubuntu and Windows checks
remain live. Wait for all six plus fresh remote guards before the next push.
Production and all READMEs remain unchanged. Sparrow stays 6f7b9d35 / v0.3.0;
Studio stays c0bb9e86 with no release. No stop rule fires. The 444-count frontier,
H2 gate and all 22 unopened reserved vectors are unchanged. No release qualifies.

Evidence: [complete model]({NAME}/model-audit.json),
[response]({NAME}/response-audit.json),
[source readback]({NAME}/source-audit.json),
[region comparison]({NAME}/free-region-comparisons.json),
[exact height certificates]({NAME}/section-bound-audit.json),
[proof]({NAME}/height-bound-proof.json),
[next step]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The archive retains {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including every incumbent, both plot versions, all original
inputs, closed call records and exact pattern/weight certificates.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 mixed-core height and exact bounds, 2026-10-28:** [the evidence]({link})
verifies a mixed 26-part core at 2,157.409 mm, 10.466 mm shorter, with all seven
source-valid incumbents preserved. The sole search stays closed, including its
0.047559 s returned soft overrun. Rebuilt cog-anchor area grows only about 0.20%.
Three independent exact section-weight certificates check 11,741 patterns.
Adding the two missing brackets to the old 18-frame/11-insert lower core requires
a top of at least 2,144.593263 mm, exceeding its old height by 36.943263 mm;
this excludes that core-only repair, not the full job. The current mixed26 core
has a 2,113.619939 mm lower bound; all first-sheet non-cogs under short6/9 need
at least 2,249.796028 mm. Next investigate an independently positioned cog packet
with a height objective and fully audited positive control, preserving all other
original obligations. Best valid64, 444 necessary counts, the H2 gate and 22
unopened reserved vectors stay unchanged. Main 2adfa569 has four passing CI jobs
and Ubuntu/Windows checks live; wait for all six before pushing. Production,
READMEs and upstream releases are unchanged. H2/H5 remain open at 60%.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
