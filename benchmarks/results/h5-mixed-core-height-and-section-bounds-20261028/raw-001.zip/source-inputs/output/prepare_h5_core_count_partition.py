"""Declare an exhaustive count partition with redundant global core propagation."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product
import json, shutil, time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb
ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT/'output/h5-stem-ordered-nine-decision-20261026'
SUPPORT=ROOT/'output/h5-all-angle-support-bounds-20261026'
OUT=ROOT/'output/h5-core-count-partition-20261026'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['status']=='UNKNOWN'
counts=[list(t) for t in product(range(7),range(2),range(5)) if sum(t)>=9 and (t[0]<=3 or t[2]<=3)]
assert counts==[[5,1,3],[6,0,3],[6,1,2],[6,1,3]]
inputs=[p for p in PARENT.rglob('*') if p.is_file()]+[SUPPORT/'bracket-direction-bounds.json',SUPPORT/'cog-spacing-proof.json',SUPPORT/'audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'exact_counts':counts,'maximum_calls':4,'solver_seconds_per_case':20,'shared_seconds_per_case':30,'workers':4,'seed':0,'method':'Partition all remaining >=9 count families exactly, retaining the complete stem-ordered parent. Add redundant one-dimensional no-overlap over full-height bracket stems and 245034-unit-wide cog-centered cores. Each pair follows from retained stem order, original-support directions or cog spacing, independently checked before search. Three exact family-count equalities per case. No prior call is retried; no original disappears.'})
parent=pb.CpModelProto();parent.ParseFromString((PARENT/'models/000.pb').read_bytes())
flags=load(PARENT/'profile-flags.json');presence=load(PARENT/'presence-flags.json');stems=load(PARENT/'stem-variables.json')
profiles={r['profile']:r['stem_bounds_units1000'] for r in load(SUPPORT/'bracket-direction-bounds.json')}
common=pb.CpModelProto();common.CopyFrom(parent);intervals=[]
def interval(var,offset,width,flag):
    index=len(common.constraints);c=common.constraints.add();c.enforcement_literal.append(flag)
    c.interval.start.vars.append(var);c.interval.start.coeffs.append(1);c.interval.start.offset=offset
    c.interval.end.vars.append(var);c.interval.end.coeffs.append(1);c.interval.end.offset=offset+width
    c.interval.size.offset=width;intervals.append(index)
for i in range(6):
    for p in range(8):interval(stems[i],0,profiles[p][2]-profiles[p][0],flags[str(i)][str(p)])
for i in range(7,11):interval(2*i,-122517,245034,presence[i])
common.constraints.add().no_overlap.intervals.extend(intervals)
assert len(common.constraints)==995
write(OUT/'core-intervals.json',intervals);inventory=[]
copied=['profile-flags.json','presence-flags.json','direction-flags.json','direction-requirements.json','stem-variables.json','optional-rectangles.json']
for index,counts3 in enumerate(counts):
    folder=OUT/f'case-{index:03d}';folder.mkdir();(folder/'models').mkdir()
    m=pb.CpModelProto();m.CopyFrom(common)
    for slots,n in zip([list(range(6)),[6],list(range(7,11))],counts3):
        c=m.constraints.add();c.linear.vars.extend(presence[i] for i in slots);c.linear.coeffs.extend([1]*len(slots));c.linear.domain.extend([n,n])
    assert len(m.variables)==122 and len(m.constraints)==998
    for n in copied:shutil.copyfile(PARENT/n,folder/n)
    plan={**load(PARENT/'plan.json'),'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs+[OUT/'plan.json']},'exact_family_counts':dict(zip(['bracket','insert','cog'],counts3)),'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'method':'Exact disjoint family-count partition of audited stem-ordered >=9 decision; retain parent and add independently verified redundant global core separation.'}
    write(folder/'plan.json',plan);p=folder/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
    record={**load(PARENT/'inventory.json')[0],'model_sha256':digest(p),'variables':122,'constraints':998,'exact_family_counts':counts3,'new_optional_core_intervals':52,'new_global_no_overlap':1,'new_exact_count_equalities':3}
    write(folder/'inventory.json',[record]);inventory.append({'case':index,**record})
write(OUT/'inventory.json',inventory);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'cases':4,'solver_calls':0});print(load(OUT/'prepared.json'))
