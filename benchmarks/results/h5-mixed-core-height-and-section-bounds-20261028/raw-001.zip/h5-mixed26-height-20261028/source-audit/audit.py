"""Read every mixed-core incumbent directly from original source rings."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed26-height-20261028';OUT=BASE/'source-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();response=load(BASE/'response-audit/checks.json');assert response['passed'] and response['has_source_core_candidate']
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};mapping=load(BASE/'model/mapping.json');modes=load(BASE/'modes.json');short=load(BASE/'short15.json')
expected={('frame',i) for i in range(18)}|{('bracket',i) for i in range(3)}|{('insert',i) for i in range(8,13)}|{(r['part_id'],r['copy_index']) for r in short}
remaining={(r['family'],r['copy_index']) for r in load(BASE/'remaining25.json')};assert len(expected)==41 and len(remaining)==25 and expected.isdisjoint(remaining)
assert expected|remaining=={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
stocks={'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]}
def rows_from(solution):
    rows=[]
    for item in mapping['items']:
        selected=[o for o in item['options'] if solution[o['selector']]];assert len(selected)==1;mode=modes[selected[0]['mode']]
        rows.append({'part_id':item['family'],'copy_index':item['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['quarter']*math.pi/2,'mirrored':mode['mirrored'],
            'translation':[(solution[item['x']]-mode['transformed_min_um'][0])/1000,(solution[item['y']]-mode['transformed_min_um'][1])/1000]}})
    return rows+short
def top_of(rows):
    result=0
    for r in rows:
        if r['sheet_id']!='sheet-0':continue
        t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1
        result=max(result,max(sign*x*s+y*c+t['translation'][1] for x,y in parts[r['part_id']]['geometry'][0]['outer']))
    return result
records=[]
for path in sorted((BASE/'search/incumbents').glob('*.json')):
    saved=load(path);rows=rows_from(saved['values']);source=audit(job,rows,stocks,.21170867250963943,.011444091796875,expected);assert source['valid'];actual=top_of(rows)
    assert abs(actual-saved['top_um']/1000)<1e-8
    records.append({'sequence':saved['sequence'],'source_valid':True,'actual_core_top_mm':actual,**{k:source[k] for k in ['same_sheet_pairs','stock_edges','cutouts','hole_vertices','minimum_pair_gap_mm','minimum_extra_stock_mm']}})
sol=load(BASE/'search/assignment.json');rows=rows_from(sol);assert rows==load(BASE/'response-audit/source41.json');source=audit(job,rows,stocks,.21170867250963943,.011444091796875,expected);assert source['valid']
actual=top_of(rows);assert abs(actual-response['top_mm'])<1e-8 and rows[-15:]==short
write(OUT/'incumbents.json',records);write(OUT/'source-readback.json',source)
inputs=[BASE/'plan.json',BASE/'model/mapping.json',BASE/'modes.json',BASE/'short15.json',BASE/'remaining25.json',BASE/'response-audit/checks.json',BASE/'response-audit/source41.json',BASE/'search/assignment.json',ROOT/'output/h5_legacy64_source_readback.py']+sorted((BASE/'search/incumbents').glob('*.json'))
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_incumbents_verified':len(records),'source_final_verified':True,'source_originals':41,'core_originals':26,'unchanged_short_originals':15,
    'actual_core_top_mm':actual,'height_reduction_mm':2167.875-actual,'source_pairs_verified':source['same_sheet_pairs'],'source_stock_edges':source['stock_edges'],'source_holes':source['cutouts'],'source_hole_vertices':source['hole_vertices'],
    'minimum_source_pair_gap_mm':source['minimum_pair_gap_mm'],'minimum_extra_stock_mm':source['minimum_extra_stock_mm'],'missing_originals':[list(k) for k in sorted(remaining)],
    'previous_source64_preserved':True,'all66_originals_accounted_once':True,'full66_witness':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
