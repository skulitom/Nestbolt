"""Independently read every core-height incumbent and the final response."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed26-height-20261028';MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();ma=load(BASE/'model-audit/checks.json');assert ma['passed']
for path in [BASE/'plan.json',MODEL/'plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
process=load(SEARCH/'process.json');result=load(SEARCH/'result.json');opened=load(SEARCH/'opened.json')
assert process['exit_code']==0 and not process['timeout'] and process['seconds']<90
assert opened['maximum_calls']==result['solver_calls']==1 and result['closed']
assert opened['model_audit_sha256']==digest(BASE/'model-audit/checks.json')
assert digest(SEARCH/'model.pb')==digest(MODEL/'model.pb')==ma['model_sha256']==opened['model_sha256']
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
assert params.max_time_in_seconds==60 and params.num_search_workers==4 and params.random_seed==0
assert list(params.ignore_subsolvers)==['fj'] and params.log_search_progress and not params.log_to_stdout
assert {f.name for f,v in params.ListFields()}==set(opened['parameters'])
p=cp_model_pb2.CpModelProto();p.ParseFromString((SEARCH/'model.pb').read_bytes());r=cp_model_pb2.CpSolverResponse();r.ParseFromString((SEARCH/'response.pb').read_bytes())
status=cp_model_pb2.CpSolverStatus.Name(r.status);assert status==result['status'] and status in ['UNKNOWN','FEASIBLE','OPTIMAL','INFEASIBLE']
assert r.wall_time==result['solver_wall_seconds'] and r.num_branches==result['returned_response_branches'] and r.num_conflicts==result['returned_response_conflicts']
assert bool(r.solution)==result['has_solution']==(status in ['FEASIBLE','OPTIMAL'])
assert r.objective_value==result['top_um'] and r.best_objective_bound==result['bound_um']
log=(SEARCH/'solver.log').read_text(encoding='utf-8');assert f'status: {status}' in log
printed=Decimal(re.search(r'^walltime: ([0-9.e+-]+)$',log,re.M).group(1));assert abs(printed-Decimal(str(r.wall_time)))<=Decimal(5).scaleb(printed.as_tuple().exponent-1)+Decimal('1e-12')
assert result['returned_soft_overrun_seconds']==max(0.,result['returned_solve_seconds']-60) and result['solver_soft_overrun_seconds']==max(0.,r.wall_time-60)
records=[]
for i,path in enumerate(sorted((SEARCH/'incumbents').glob('*.json'))):
    saved=load(path);assert saved['sequence']==i;checked=evaluate(p,saved['values'],saved['top_um']);assert checked['expanded_pairs']==406
    assert 0<=saved['solver_wall_seconds']<=r.wall_time and saved['bound_um']<=saved['top_um']
    if records:assert saved['top_um']<=records[-1]['top_um'] and saved['solver_wall_seconds']>=records[-1]['solver_wall_seconds']
    records.append(saved)
assert len(records)==result['incumbents_recorded']
if r.solution:
    sol=list(r.solution);assert sol==load(SEARCH/'assignment.json');checked=evaluate(p,sol,r.objective_value)
    assert records[-1]['top_um']==r.objective_value
    if status=='OPTIMAL':assert r.objective_value==r.best_objective_bound
    mp=load(MODEL/'mapping.json');modes=load(BASE/'modes.json');rows=[];poses=[]
    for item in mp['items']:
        choices=[o for o in item['options'] if sol[o['selector']]];assert len(choices)==1;m=modes[choices[0]['mode']];xy=[sol[item['x']],sol[item['y']]]
        poses.append({'family':item['family'],'copy_index':item['copy_index'],'mode':m['id'],'anchor_um':xy})
        rows.append({'part_id':item['family'],'copy_index':item['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':m['quarter']*3.141592653589793/2,'mirrored':m['mirrored'],
            'translation':[(xy[k]-m['transformed_min_um'][k])/1000 for k in [0,1]]}})
    write(OUT/'selected-poses.json',poses);write(OUT/'source26.json',rows);write(OUT/'source41.json',rows+load(BASE/'short15.json'))
inputs=[BASE/'plan.json',MODEL/'plan.json',MODEL/'mapping.json',BASE/'model-audit/checks.json',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py']+list(SEARCH.glob('*'))+list((SEARCH/'incumbents').glob('*'))
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs if p.is_file()}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'status':status,'incumbents_verified':len(records),'assignments_verified':len(records)+bool(r.solution),
    'variables_per_assignment':169,'constraints_per_assignment':564,'expanded_pairs_per_assignment':406,'top_mm':r.objective_value/1000,'bound_mm':r.best_objective_bound/1000,
    'top_improvement_mm':(2167875-r.objective_value)/1000 if r.solution else None,'solver_wall_seconds':r.wall_time,'shared_seconds':process['seconds'],
    'returned_soft_overrun_seconds':result['returned_soft_overrun_seconds'],'has_source_core_candidate':bool(r.solution),'source_core_verified':False,
    'full66_witness':False,'actual_or_global_infeasibility_claimed':False,'solver_calls':1,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
