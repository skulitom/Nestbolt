"""Independent original-rectangle, complete model and full-control audit."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed26-height-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for plan in [load(BASE/'plan.json'),load(MODEL/'plan.json')]:
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={r['id']:r for r in job['parts']};modes=load(BASE/'modes.json');control=load(BASE/'control.json')
ga=load(BASE/'geometry-audit/checks.json');assert ga['passed']
assert digest(BASE/'modes.json')==ga['geometry_sha256'] and digest(BASE/'control.json')==ga['control_sha256'] and digest(BASE/'plan.json')==ga['plan_sha256']
assert len(modes)==16 and ga['expanded_same_owner_components_disjoint'] and ga['all66_originals_accounted_once']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');built=load(MODEL/'built.json')
assert {f.name for f,v in p.ListFields()}=={'variables','constraints','objective','solution_hint'}
assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256']
pad=112;left=6513;right=1493487;maximum=2167875;width=right-left+2*pad;area=18*450224*350224+3*(40000000000+1100000*112+4*112**2)+5*180224*110224;lower=(area+width-1)//width+left-2*pad
assert (mp['expanded_width_um'],mp['expanded_area_um2'],mp['area_lower_top_um'])==(width,area,lower)
seenvars=set();seencts=set();MIN=-9223372036854775808;MAX=9223372036854775807
def var(ix,name,domain):
    assert ix not in seenvars;seenvars.add(ix);v=p.variables[ix];assert v.name==name and list(v.domain)==domain
    assert {f.name for f,z in v.ListFields()}=={'name','domain'}
def linear(ix,coeffs,lo=MIN,hi=MAX,on=None):
    assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='linear'
    assert {f.name for f,z in ct.ListFields()}<= {'linear','enforcement_literal'} and list(ct.enforcement_literal)==([] if on is None else [on])
    assert dict(zip(ct.linear.vars,ct.linear.coeffs))==coeffs and len(ct.linear.vars)==len(coeffs) and list(ct.linear.domain)==[lo,hi]
def expr(e,variable,offset):
    assert e.offset==offset and list(e.vars)==([] if variable is None else [variable]) and list(e.coeffs)==([] if variable is None else [1])
    assert {f.name for f,z in e.ListFields()}<= {'vars','coeffs','offset'}
top=mp['top_variable'];var(top,'core_top_um',[lower,maximum]);expectedhints={top:maximum};allx=[];ally=[];demw=[];demh=[]
expected=[('frame',i,list(range(4))) for i in range(18)]+[('bracket',i,list(range(4,12))) for i in range(3)]+[('insert',i,list(range(12,16))) for i in range(8,13)]
assert len(mp['items'])==len(control)==26
for i,(item,(family,copy,allowed),hint) in enumerate(zip(mp['items'],expected,control)):
    assert (item['index'],item['family'],item['copy_index'])==(i,family,copy) and (hint['family'],hint['copy_index'])==(family,copy)
    x,y=item['x'],item['y'];var(x,f'x_{i}',[left,right]);var(y,f'y_{i}',[left,maximum]);expectedhints[x],expectedhints[y]=hint['anchor_um']
    assert [o['mode'] for o in item['options']]==allowed
    for o in item['options']:
        mi=o['mode'];m=modes[mi];sv=o['selector'];var(sv,f'mode_{i}_{mi}',[0,1]);expectedhints[sv]=int(hint['mode']==mi);w,h=m['width_um'],m['height_um']
        linear(o['x_bound'],{x:1},hi=right-w,on=sv);linear(o['top_bound'],{y:1,top:-1},hi=-h,on=sv)
        assert len(o['components'])==len(m['expanded_rectangles_um'])
        for k,(part,(a,b,c,d)) in enumerate(zip(o['components'],m['expanded_rectangles_um'])):
            assert part['component']==k
            for axis,variable,begin,end,key in [('x',x,a,c,'x_interval'),('y',y,b,d,'y_interval')]:
                ix=part[key];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix]
                assert {f.name for f,z in ct.ListFields()}=={'name','enforcement_literal','interval'} and ct.name==f'expanded_{axis}_{i}_{mi}_{k}' and list(ct.enforcement_literal)==[sv]
                assert {f.name for f,z in ct.interval.ListFields()}=={'start','size','end'}
                expr(ct.interval.start,variable,begin);expr(ct.interval.size,None,end-begin);expr(ct.interval.end,variable,end)
            allx.append(part['x_interval']);ally.append(part['y_interval']);demw.append(c-a);demh.append(d-b)
    ix=item['choice'];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix]
    assert {f.name for f,z in ct.ListFields()}=={'exactly_one'} and list(ct.exactly_one.literals)==[o['selector'] for o in item['options']]
ix=mp['no_overlap_2d'];seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,z in ct.ListFields()}=={'no_overlap_2d'}
assert list(ct.no_overlap_2d.x_intervals)==allx and list(ct.no_overlap_2d.y_intervals)==ally
for key,intervals,demands,variable,offset in [('x_cumulative',allx,demh,top,-left+2*pad),('y_cumulative',ally,demw,None,width)]:
    ix=mp[key];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,z in ct.ListFields()}=={'cumulative'}
    assert list(ct.cumulative.intervals)==intervals and len(ct.cumulative.demands)==len(demands);expr(ct.cumulative.capacity,variable,offset)
    for e,d in zip(ct.cumulative.demands,demands):expr(e,None,d)
expectedorders=[(a,b) for f in ['frame','bracket','insert'] for group in [[r for r in mp['items'] if r['family']==f]] for a,b in zip(group,group[1:])]
assert len(mp['orders'])==len(expectedorders)==23
for row,(a,b) in zip(mp['orders'],expectedorders):
    assert (row['left'],row['right'])==(a['index'],b['index']);linear(row['constraint'],{a['x']:1,b['x']:-1},hi=0)
assert seenvars==set(range(len(p.variables))) and seencts==set(range(len(p.constraints)))
assert list(p.objective.vars)==[top] and list(p.objective.coeffs)==[1] and p.objective.offset==0 and p.objective.scaling_factor==1
assert {f.name for f,z in p.objective.ListFields()}=={'vars','coeffs','scaling_factor'}
assert len(p.solution_hint.vars)==len(set(p.solution_hint.vars))==len(p.variables)
assert expectedhints==dict(zip(p.solution_hint.vars,p.solution_hint.values))=={int(k):v for k,v in load(MODEL/'control-assignment.json').items()}
sol=expectedhints
def ev(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
def present(ct):return all(sol[v]==1 for v in ct.enforcement_literal)
active=[];pairs=0
for v,x in zip(p.variables,[sol[i] for i in range(len(p.variables))]):assert v.domain[0]<=x<=v.domain[-1]
for ct in p.constraints:
    if not present(ct):continue
    kind=ct.WhichOneof('constraint')
    if kind=='linear':
        value=sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs));assert ct.linear.domain[0]<=value<=ct.linear.domain[-1]
    elif kind=='exactly_one':assert sum(sol[v] for v in ct.exactly_one.literals)==1
    elif kind=='interval':assert ev(ct.interval.start)+ev(ct.interval.size)==ev(ct.interval.end) and ev(ct.interval.size)>0
    elif kind=='no_overlap_2d':
        for xx,yy in zip(ct.no_overlap_2d.x_intervals,ct.no_overlap_2d.y_intervals):
            a,b=p.constraints[xx],p.constraints[yy];assert present(a)==present(b)
            if present(a):active.append([ev(a.interval.start),ev(b.interval.start),ev(a.interval.end),ev(b.interval.end)])
        for a,b in combinations(active,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];pairs+=1
    elif kind=='cumulative':
        events={}
        for ix,e in zip(ct.cumulative.intervals,ct.cumulative.demands):
            c=p.constraints[ix]
            if not present(c):continue
            begin,end,amount=ev(c.interval.start),ev(c.interval.end),ev(e);events[begin]=events.get(begin,0)+amount;events[end]=events.get(end,0)-amount
        running=0
        for where,delta in sorted(events.items()):running+=delta;assert 0<=running<=ev(ct.cumulative.capacity)
        assert running==0
    else:raise AssertionError(kind)
assert len(active)==29 and pairs==406
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_modes_verified':16,'nominal_source_gap_lower_bound_mm':.224,
    'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'mandatory_originals':26,'independent_anchor_coordinates':52,
    'full_control_values_verified':len(sol),'full_control_expanded_pairs_verified':pairs,'area_lower_top_um':lower,'initial_top_um':maximum,
    'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'plan_sha256':digest(BASE/'plan.json'),
    'constructive_core_only':True,'full66_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
