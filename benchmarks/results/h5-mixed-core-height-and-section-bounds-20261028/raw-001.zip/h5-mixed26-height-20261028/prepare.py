"""Prepare an independently movable frame/bracket/insert core, without search."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil
from h5_orthogonal_source_model_geometry_20261028 import original_um,transformed,polygon_rectangles,expanded_rectangles
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-mixed26-height-20261028';OLD=ROOT/'output/h5-staggered25-source-regions-20261028'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[JOB,OLD/'fixed41.json',OLD/'remaining.json',OLD/'audit/checks.json',OLD/'capacity/response-audit/checks.json',
    ROOT/'output/h5_orthogonal_source_model_geometry_20261028.py',ROOT/'output/h5_legacy64_source_readback.py',
    ROOT/'output/build_h5_mixed_rows_core.py',ROOT/'output/build_h5_central_notch_mixed_core.py',ROOT/'output/build_h5_staggered_frame_bracket_core_repaired.py',
    ROOT/'output/prepare_h5_core29_height_20261028.py',ROOT/'output/prepare_h5_core_count_partition.py',
    ROOT/'benchmarks/results/h5-staggered-core-independent-placement-20261028/next-step.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Change the core construction after the independent staggered25 call closed UNKNOWN. Existing mixed-row, central-notch and staggered cores are fixed source constructions, and the separate closed core29 height call moved only frames/inserts. This model moves all26 originals of the staggered core independently:18 frames,3 full L brackets and5 inserts, with all4 legal frame/insert quarter turns and all8 bracket quarter/mirror modes. Minimize their maximum upperY within2167.875mm, retaining the actual15 short-sheet originals exactly. All25 remaining first-sheet originals remain explicit unmet obligations. Model every filled original outer (holes reserved), expanded112um in L-infinity; partition the expanded union into nonoverlapping rectangles, including each L bracket, so same-owner components introduce no artificial collision. Both axes remain integer micrometre coordinates, with13um extra original stock clearance. A complete valid current-core hint relabels only identical family copies in X order. Independently prove original/expanded geometry coverage and positive-control source validity, then read back every model field before one60-second optimization within90seconds shared. No old call is resumed. Original-source readback is mandatory for all incumbents selected for use; no partial-core/native/full66/H5 claim follows.',
    'core_counts':{'frame':18,'bracket':3,'insert':5},'pad_um':112,'stock_anchor_guard_um':13,'anchor_left_um':6513,'anchor_right_um':1493487,
    'maximum_top_um':2167875,'solver_seconds':60,'shared_process_seconds':90,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'maximum_calls':1,'retry_permitted':False})
assert load(OLD/'audit/checks.json')['passed'] and load(OLD/'capacity/response-audit/checks.json')['status']=='UNKNOWN'
job=load(JOB);parts={p['id']:p for p in job['parts']};fixed=load(OLD/'fixed41.json');modes=[]
for family in ['frame','bracket','insert']:
    p=parts[family];points=original_um(p['geometry'][0]['outer'])
    for mirror in ([False,True] if family=='bracket' else [False]):
        for q in range(4):
            assert q*90 in p['rotations']['degrees'] and (not mirror or p['allow_mirror'])
            outer,offset=transformed(points,q,mirror);rects=polygon_rectangles(outer);expanded=expanded_rectangles(rects,112)
            modes.append({'id':len(modes),'family':family,'quarter':q,'mirrored':mirror,'transformed_min_um':offset,'outer_um':outer,
                'width_um':max(v[0] for v in outer),'height_um':max(v[1] for v in outer),'original_rectangles_um':rects,'expanded_rectangles_um':expanded})
assert len(modes)==16
control=[];rows=[]
for family,ids in [('frame',list(range(18))),('bracket',list(range(3))),('insert',list(range(8,13)))]:
    chosen=[]
    for r in fixed:
        if r['sheet_id']!='sheet-0' or r['part_id']!=family:continue
        t=r['transform'];q=round(t['rotation_radians']/(math.pi/2))%4;m=next(m for m in modes if m['family']==family and m['quarter']==q and m['mirrored']==t['mirrored'])
        anchor=[round(t['translation'][k]*1000)+m['transformed_min_um'][k] for k in [0,1]]
        assert all(abs(t['translation'][k]*1000-round(t['translation'][k]*1000))<1e-5 for k in [0,1]);chosen.append({'mode':m['id'],'anchor_um':anchor,'old_source_row':r})
    assert len(chosen)==len(ids)
    for copy,r in zip(ids,sorted(chosen,key=lambda r:r['anchor_um'])):
        m=modes[r['mode']];control.append({'index':len(control),'family':family,'copy_index':copy,**r})
        rows.append({'part_id':family,'copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':m['quarter']*math.pi/2,'mirrored':m['mirrored'],
            'translation':[(r['anchor_um'][k]-m['transformed_min_um'][k])/1000 for k in [0,1]]}})
short=[r for r in fixed if r['sheet_id']=='sheet-1'];remaining=load(OLD/'remaining.json');expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
used={(r['part_id'],r['copy_index']) for r in rows+short};assert len(rows)==26 and len(short)==15 and len(used)==41 and used|{(r['family'],r['copy_index']) for r in remaining}==expected
readback=audit(job,rows+short,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},.21170867250963943,.011444091796875,used);assert readback['valid']
top=max(r['anchor_um'][1]+modes[r['mode']]['height_um'] for r in control);assert top==2167875
write(OUT/'modes.json',modes);write(OUT/'control.json',control);write(OUT/'control-source26.json',rows);write(OUT/'control-source41.json',rows+short);write(OUT/'control-source-readback.json',readback);write(OUT/'short15.json',short);write(OUT/'remaining25.json',remaining)
write(OUT/'prepared.json',{'source_modes':16,'mandatory_core_originals':26,'source_control_valid':True,'initial_top_um':top,'source_control_pairs':readback['same_sheet_pairs'],
    'minimum_pair_gap_mm':readback['minimum_pair_gap_mm'],'minimum_extra_stock_mm':readback['minimum_extra_stock_mm'],'remaining_first_sheet_originals':25,'unchanged_short_originals':15,
    'all66_originals_accounted_once':True,'full66_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
