"""Measure the changed core's exact source placement regions; no search."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,shape,mapping
import diagnose_h5_concave_gaps as geom
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed26-height-20261028';OLD=ROOT/'output/h5-staggered25-source-regions-20261028';OUT=BASE/'new-free-regions'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();assert load(BASE/'source-audit/checks.json')['passed']
inputs=[BASE/'response-audit/source41.json',BASE/'source-audit/checks.json',OLD/'modes.json',OLD/'audit/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',Path(geom.__file__)]+sorted((OLD/'source-free').glob('*.json'))
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_regions':11,'maximum_seconds':60,'maximum_runs':1,'retry_permitted':False,
    'method':'Rebuild all11 source-mode free regions against the newly optimized26 first-sheet originals. Compare exact conservative old/new anchor-region areas, additions and removals using the same source modes, clearance and construction margin. Do not assume the lower maximum height implies every old region remains valid: individual frames, brackets and inserts moved. This is a bounded geometry characterization only, with no new candidate, optimization, native call or infeasibility claim. Independently validate source conservatism before reusing any domain.'})
job=load(inputs[4]);parts={p['id']:p for p in job['parts']};fixed=[];geom.EPS=.0126
for r in load(BASE/'response-audit/source41.json'):
    if r['sheet_id']!='sheet-0':continue
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    fixed.append(Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in parts[r['part_id']]['geometry'][0]['outer']]))
assert len(fixed)==26;rows=[]
for mode in load(OLD/'modes.json'):
    assert time.perf_counter()-started<60;g=geom.regions(shape(mode['geometry']),fixed,job['stocks'][0],job['edge_clearance'],.21170867250963943);assert g.is_valid
    write(OUT/f"{mode['index']:02d}.json",mapping(g));old=shape(load(OLD/'source-free'/f"{mode['index']:02d}.json"))
    rows.append({'mode':mode['index'],'family':mode['family'],'old_anchor_area_mm2':old.area,'new_anchor_area_mm2':g.area,'added_anchor_area_mm2':g.difference(old).area,
        'removed_anchor_area_mm2':old.difference(g).area,'net_area_change_mm2':g.area-old.area,'components':len(geom.polygons(g)),'empty':g.is_empty})
write(OUT/'comparisons.json',rows);write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-started,'regions':11,'solver_calls':0,'native_calls':0,'no_old_owner_region_reused':True,'actual_or_global_infeasibility_claimed':False})
print(load(OUT/'result.json'));print(rows)
