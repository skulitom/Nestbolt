"""Independent source-clearance checks for the saved residual regions."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,shape,box
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed26-height-20261028';OLD=ROOT/'output/h5-staggered25-source-regions-20261028';SRC=BASE/'new-free-regions';OUT=SRC/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for n,h in load(SRC/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
assert load(SRC/'result.json')['closed'] and load(SRC/'result.json')['seconds']<60
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};fixed=[]
def original(family,a,mir,t):
    c,s=math.cos(a),math.sin(a);sign=-1 if mir else 1
    return Polygon([(sign*x*c-y*s+t[0],sign*x*s+y*c+t[1]) for x,y in parts[family]['geometry'][0]['outer']])
for r in load(BASE/'response-audit/source41.json'):
    if r['sheet_id']=='sheet-0':
        t=r['transform'];fixed.append(original(r['part_id'],t['rotation_radians'],t['mirrored'],t['translation']))
cache={};hulls=0
def pieces(g):
    if g.wkb not in cache:
        ps=[g] if g.equals(g.convex_hull) else list(shapely.constrained_delaunay_triangles(g).geoms)
        assert unary_union(ps).equals(g) and all(p.equals(p.convex_hull) for p in ps);cache[g.wkb]=ps
    return cache[g.wkb]
checks=[];tested=0
for mode,saved in zip(load(OLD/'modes.json'),load(SRC/'comparisons.json')):
    g=shape(load(SRC/f"{mode['index']:02d}.json"));assert g.is_valid and saved['mode']==mode['index'] and saved['empty']==g.is_empty and saved['new_anchor_area_mm2']==g.area
    m=original(mode['family'],mode['angle'],mode['mirrored'],mode['source_translation_offset']);assert m.equals_exact(shape(mode['geometry']),1e-10)
    if g.is_empty:
        assert saved['bounds'] is None and saved['components']==0;checks.append({'mode':mode['index'],'empty_conservative_region':True,'actual_infeasibility_claimed':False});continue
    x0,y0,x1,y1=m.bounds;guard=.011444091796875;assert box(6.5+guard-x0,6.5+guard-y0,1493.5-guard-x1,2993.5-guard-y1).covers(g)
    for w in fixed:
        sums=[]
        for p in pieces(w):
            for q in pieces(m):
                sums.append(MultiPoint([(x-u,y-v) for x,y in list(p.exterior.coords)[:-1] for u,v in list(q.exterior.coords)[:-1]]).convex_hull);hulls+=1
        forbidden=unary_union(sums).buffer(.21170867250963943/math.cos(math.pi/64)+1e-7,quad_segs=16)
        assert g.disjoint(forbidden);tested+=1
    old=shape(load(OLD/'source-free'/f"{mode['index']:02d}.json"))
    assert saved['old_anchor_area_mm2']==old.area and saved['added_anchor_area_mm2']==g.difference(old).area and saved['removed_anchor_area_mm2']==old.difference(g).area
    assert saved['net_area_change_mm2']==g.area-old.area
    checks.append({'mode':mode['index'],'source_fixed_neighbours':len(fixed),'source_stock_guard_verified':True})
write(OUT/'regions.json',checks);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'regions_read':11,'source_fixed_originals':26,'old_new_comparisons_verified':11,'source_neighbour_clearance_checks':tested,'independent_source_minkowski_hulls':hulls,'source_convex_pieces_verified':sum(map(len,cache.values())),'actual_or_global_infeasibility_claimed':False,'solver_calls':0,'native_calls':0})
print(load(OUT/'checks.json'))
