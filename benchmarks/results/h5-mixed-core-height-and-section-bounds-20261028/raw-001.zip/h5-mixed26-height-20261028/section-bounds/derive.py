"""Find section weights, then turn them into exact rational core-height bounds."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,shutil,time
import numpy as np
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed26-height-20261028';OUT=BASE/'section-bounds'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'derive.py');started=time.perf_counter()
cases=[{'name':'current-core26','frame':18,'bracket':3,'insert':5,'comparison_top_mm':2157.409},
    {'name':'source64-core-plus-two-brackets','frame':18,'bracket':2,'insert':11,'comparison_top_mm':2107.65},
    {'name':'all-first-noncogs-short6-9','frame':18,'bracket':6,'insert':12,'comparison_top_mm':None}]
inputs=[BASE/'plan.json',BASE/'source-audit/checks.json',BASE/'geometry-audit/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-oblique64-source-20261028/source64.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'cases':cases,
    'maximum_linear_programs':3,'maximum_seconds_per_linear_program':10,'retry_permitted':False,'source_inset_um':2,'stock_width_um':1487000,
    'method':'Derive necessary arbitrary-position/all-quarter-turn core-height bounds by horizontal section weights. Frame and insert inner rectangles contribute one active width at each section. Each L bracket is split into two source-contained rectangles with disjoint Y spans; a section intersects at most one component per original. Their two orientation profiles are300/100mm widths across75/175mm heights, or250/75mm widths across100/200mm heights, each rectangle inset2um. Enumerate every feasible section-count pattern under original stock width and family counts. Up to three bounded linear programs propose nonnegative width weights. Their floating solutions are not evidence: round weights to rational numbers, normalize by the exact maximum pattern weight, then use exact minimum per-family integrated contributions. Independently enumerate all patterns and verify source containment before using any resulting bound. No layout search, original exclusion beyond the stated core-height scope, native call or count-frontier change.'})
widths=[449996,349996,179996,109996,299996,99996,249996,74996]
write(OUT/'section-widths-um.json',widths);results=[]
for case in cases:
    folder=OUT/case['name'];folder.mkdir();patterns=[]
    # Family combinations are enumerated independently before width filtering.
    frames=[r for r in product(range(5),repeat=2) if sum(r)<=case['frame']]
    inserts=[r for r in product(range(min(case['insert'],13)+1),repeat=2) if sum(r)<=case['insert']]
    brackets=[r for r in product(range(case['bracket']+1),repeat=4) if sum(r)<=case['bracket']]
    for a in frames:
        for b in inserts:
            for c in brackets:
                row=list(a+b+c)
                if sum(n*w for n,w in zip(row,widths))<=1487000:patterns.append(row)
    write(folder/'patterns.json',patterns)
    # Variables: eight width weights, then integrated frame/insert/bracket weights.
    rows=[r+[0,0,0] for r in patterns];rhs=[1.]*len(rows)
    profiles=[(8,{0:349996}),(8,{1:449996}),(9,{2:109996}),(9,{3:179996}),
        (10,{4:74996,5:174996}),(10,{6:99996,7:199996})]
    for z,terms in profiles:
        r=[0.]*11;r[z]=1
        for k,h in terms.items():r[k]=-h
        rows.append(r);rhs.append(0.)
    objective=[0.]*8+[-case['frame'],-case['insert'],-case['bracket']]
    begun=time.perf_counter();lp=linprog(objective,A_ub=np.array(rows),b_ub=np.array(rhs),bounds=(0,None),method='highs',options={'time_limit':10.});elapsed=time.perf_counter()-begun
    write(folder/'linear-program-result.json',{'status':int(lp.status),'message':lp.message,'success':bool(lp.success),'seconds':elapsed,'objective':None if lp.fun is None else float(lp.fun),'x':None if lp.x is None else list(map(float,lp.x))})
    assert lp.success and lp.x is not None
    proposed=[F(float(max(0.,x))).limit_denominator(1000000) for x in lp.x[:8]];normalizer=max(sum(n*w for n,w in zip(r,proposed)) for r in patterns);assert normalizer>0
    weights=[w/normalizer for w in proposed];assert max(sum(n*w for n,w in zip(r,weights)) for r in patterns)==1
    f=min(349996*weights[0],449996*weights[1]);i=min(109996*weights[2],179996*weights[3]);b=min(74996*weights[4]+174996*weights[5],99996*weights[6]+199996*weights[7])
    span=case['frame']*f+case['insert']*i+case['bracket']*b;top=span+6500
    row={'case':case,'section_patterns':len(patterns),'width_weights':[[v.numerator,v.denominator] for v in weights],
        'family_integrals_um':{k:[v.numerator,v.denominator] for k,v in [('frame',f),('insert',i),('bracket',b)]},
        'span_lower_um':[span.numerator,span.denominator],'top_lower_um':[top.numerator,top.denominator],'top_lower_mm':float(top/1000),
        'excludes_comparison_core_height':case['comparison_top_mm'] is not None and top>F(str(case['comparison_top_mm']))*1000,
        'actual_full66_exclusion_claimed':False,'count_frontier_changed':False}
    write(folder/'certificate.json',row);results.append(row)
write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-started,'linear_programs':3,'certificates':results,'packing_solver_calls':0,'native_calls':0,'independently_audited':False})
print({'seconds':time.perf_counter()-started,'certificates':[{k:r[k] for k in ['case','section_patterns','top_lower_mm','excludes_comparison_core_height']} for r in results]})
