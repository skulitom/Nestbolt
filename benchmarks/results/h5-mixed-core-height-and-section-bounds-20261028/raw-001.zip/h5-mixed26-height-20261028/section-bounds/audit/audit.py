"""Exact source and exhaustive section-pattern verification; no optimizer."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed26-height-20261028/section-bounds';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
assert plan['source_inset_um']==2 and plan['stock_width_um']==1487000
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']}
assert job['stocks'][0]['width']==1500 and all(v==5 for v in job['stocks'][0]['margins'].values()) and job['edge_clearance']==1.5
widths=load(BASE/'section-widths-um.json');assert widths==[449996,349996,179996,109996,299996,99996,249996,74996]
families=['frame','frame','insert','insert','bracket','bracket','bracket','bracket'];profiles=[];edge_checks=0;rectangles=0
def inside(pt,vertices):
    x,y=pt;answer=False
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        if (a[1]>y)!=(b[1]>y) and x<a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]):answer=not answer
    return answer
def hits(a,b,r):
    low,high=F(0),F(1)
    for k in [0,1]:
        delta=b[k]-a[k]
        if delta==0:
            if not r[k]<=a[k]<=r[k+2]:return False
        else:
            u,v=sorted([(r[k]-a[k])/delta,(r[k+2]-a[k])/delta]);low=max(low,u);high=min(high,v)
            if low>high:return False
    return True
for family in ['frame','insert','bracket']:
    part=parts[family];assert part['rotations']['degrees']==[0.,90.,180.,270.]
    for mir in ([False,True] if family=='bracket' else [False]):
        assert not mir or part['allow_mirror']
        for q,(c,s) in enumerate([(1,0),(0,1),(-1,0),(0,-1)]):
            sign=-1 if mir else 1;raw=[]
            for x,y in part['geometry'][0]['outer']:
                x,y=F(str(x))*1000,F(str(y))*1000;raw.append((sign*x*c-y*s,sign*x*s+y*c))
            lo=[min(r[k] for r in raw) for k in [0,1]];v=[(x-lo[0],y-lo[1]) for x,y in raw];ys=sorted({p[1] for p in v});rects=[]
            for bottom,top in zip(ys,ys[1:]):
                mid=(bottom+top)/2;xs=sorted(a[0] for a,b in zip(v,v[1:]+v[:1]) if a[0]==b[0] and min(a[1],b[1])<mid<max(a[1],b[1]))
                assert len(xs)==2;r=[xs[0]+2,bottom+2,xs[1]-2,top-2];assert r[0]<r[2] and r[1]<r[3] and inside(r[:2],v)
                for a,b in zip(v,v[1:]+v[:1]):assert not hits(a,b,r);edge_checks+=1
                assert all(x.denominator==1 for x in r);rects.append(list(map(int,r)));rectangles+=1
            assert all(a[3]<b[1] for a,b in zip(rects,rects[1:]));signature=sorted((r[2]-r[0],r[3]-r[1]) for r in rects)
            allowed=([[(449996,349996)],[(349996,449996)]] if family=='frame' else [[(179996,109996)],[(109996,179996)]] if family=='insert' else [sorted([(299996,74996),(99996,174996)]),sorted([(249996,99996),(74996,199996)])])
            assert signature in allowed;profiles.append({'family':family,'quarter':q,'mirrored':mir,'rectangles_um':rects,'width_height_pairs_um':signature})
assert len(profiles)==16 and rectangles==24;write(OUT/'source-profiles.json',profiles)
certificates=[]
for case in plan['cases']:
    folder=BASE/case['name'];cert=load(folder/'certificate.json');assert cert['case']==case
    saved=load(folder/'patterns.json');assert len(saved)==len(set(map(tuple,saved)));independent=[]
    def visit(k,available,remaining,chosen):
        if k==8:independent.append(tuple(chosen));return
        family=families[k];maximum=min(available//widths[k],remaining[family])
        for count in range(maximum+1):
            nxt=dict(remaining);nxt[family]-=count;visit(k+1,available-count*widths[k],nxt,chosen+[count])
    visit(0,1487000,{f:case[f] for f in ['frame','insert','bracket']},[])
    assert set(independent)==set(map(tuple,saved)) and len(independent)==cert['section_patterns']
    weights=[F(*x) for x in cert['width_weights']];assert len(weights)==8 and all(x>=0 for x in weights)
    maximum=max(sum(count*w for count,w in zip(row,weights)) for row in independent);assert maximum==1
    per_family={}
    for family in ['frame','insert','bracket']:
        per_family[family]=min(sum(weights[widths.index(w)]*h for w,h in p['width_height_pairs_um']) for p in profiles if p['family']==family)
        assert per_family[family]==F(*cert['family_integrals_um'][family])
    span=sum(case[f]*per_family[f] for f in per_family);top=span+6500
    assert span==F(*cert['span_lower_um']) and top==F(*cert['top_lower_um']) and float(top/1000)==cert['top_lower_mm']
    excluded=case['comparison_top_mm'] is not None and top>F(str(case['comparison_top_mm']))*1000
    assert excluded==cert['excludes_comparison_core_height']
    certificates.append({'case':case['name'],'patterns_verified':len(independent),'maximum_exact_section_weight':1,'top_lower_um':[top.numerator,top.denominator],
        'top_lower_mm':float(top/1000),'comparison_core_height_excluded':excluded,
        'comparison_gap_mm':None if case['comparison_top_mm'] is None else float(top/1000-F(str(case['comparison_top_mm'])))})
write(OUT/'certificates.json',certificates)
write(OUT/'proof.json',{'statement':'Every inset rectangle is strictly contained in its actual source filled outer by exact point parity and source-edge separation. Rectangle Y spans belonging to one bracket are disjoint, so at any horizontal section each original contributes at most one width from its family. For any nonoverlapping core, these section intervals fit the original stock width and belong to the exhaustively verified count-pattern set. Every such pattern has total nonnegative rational weight at most one. Integration over the core vertical span therefore bounds that span below by the sum of each original family minimum integrated contribution, across every legal quarter/mirror mode. The actual core top is at least6500um plus that span. Arbitrary independent X/Y positions are covered. This is a necessary bound on the named core composition and height, not a full66, sheet allocation, global job or free-angle cog exclusion.',
    'floating_linear_program_used_as_evidence':False,'exact_rational_weights_and_all_patterns_verified':True,'source_holes_reserved':True})
inputs=[BASE/'plan.json',BASE/'section-widths-um.json',BASE/'result.json']+[p for case in plan['cases'] for p in (BASE/case['name']).glob('*.json')]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'legal_source_modes_verified':16,'source_contained_rectangles_verified':rectangles,'exact_source_edge_checks':edge_checks,
    'certificates_verified':len(certificates),'total_section_patterns_verified':sum(r['patterns_verified'] for r in certificates),'certificates':certificates,
    'all_core_positions_and_legal_quarter_mirror_modes_covered':True,'actual_full66_exclusion_claimed':False,'count_frontier_changed':False,'packing_solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
