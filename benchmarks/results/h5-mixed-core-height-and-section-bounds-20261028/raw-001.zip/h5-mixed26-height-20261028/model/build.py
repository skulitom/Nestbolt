"""Compact full expanded source components with all core anchors independent."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed26-height-20261028';OUT=BASE/'model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter();ga=load(BASE/'geometry-audit/checks.json');assert ga['passed']
for n,k in [('modes.json','geometry_sha256'),('control.json','control_sha256'),('plan.json','plan_sha256')]:assert digest(BASE/n)==ga[k]
inputs=[BASE/n for n in ['plan.json','modes.json','control.json','control-source26.json','control-source-readback.json','prepared.json','short15.json','remaining25.json','geometry-audit/checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
model=cp_model.CpModel();modes=load(BASE/'modes.json');control=load(BASE/'control.json');pad=112;left=6513;right=1493487;maximum=2167875;width=right-left+2*pad
area=sum(sum((c-a)*(d-b) for a,b,c,d in modes[r['mode']]['expanded_rectangles_um']) for r in control);lower=(area+width-1)//width+left-2*pad
assert (area,lower)==(ga['expanded_area_um2'],ga['area_lower_top_um'])
top=model.new_int_var(lower,maximum,'core_top_um');items=[];xints=[];yints=[];ws=[];hs=[];hints={top.index:maximum};component_count=0
for i,r in enumerate(control):
    family=r['family'];x=model.new_int_var(left,right,f'x_{i}');y=model.new_int_var(left,maximum,f'y_{i}');options=[];hints[x.index],hints[y.index]=r['anchor_um']
    for mode in [m for m in modes if m['family']==family]:
        mi=mode['id'];select=model.new_bool_var(f'mode_{i}_{mi}');w,h=mode['width_um'],mode['height_um'];xe=model.add(x+w<=right);xe.only_enforce_if(select);ye=model.add(y+h<=top);ye.only_enforce_if(select)
        components=[]
        for k,(a,b,c,d) in enumerate(mode['expanded_rectangles_um']):
            ix=model.new_optional_fixed_size_interval_var(x+a,c-a,select,f'expanded_x_{i}_{mi}_{k}');iy=model.new_optional_fixed_size_interval_var(y+b,d-b,select,f'expanded_y_{i}_{mi}_{k}')
            xints.append(ix);yints.append(iy);ws.append(c-a);hs.append(d-b);components.append({'component':k,'x_interval':ix.index,'y_interval':iy.index});component_count+=1
        options.append({'mode':mi,'selector':select.index,'x_bound':xe.index,'top_bound':ye.index,'components':components});hints[select.index]=int(r['mode']==mi)
    choice=model.add_exactly_one(model.get_int_var_from_proto_index(o['selector']) for o in options)
    items.append({'index':i,'family':family,'copy_index':r['copy_index'],'x':x.index,'y':y.index,'options':options,'choice':choice.index})
no_overlap=model.add_no_overlap_2d(xints,yints);xc=model.add_cumulative(xints,hs,top-left+2*pad);yc=model.add_cumulative(yints,ws,width)
orders=[]
for family in ['frame','bracket','insert']:
    group=[r for r in items if r['family']==family]
    for a,b in zip(group,group[1:]):
        ct=model.add(model.get_int_var_from_proto_index(a['x'])<=model.get_int_var_from_proto_index(b['x']));orders.append({'left':a['index'],'right':b['index'],'constraint':ct.index})
model.minimize(top)
for ix,value in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(ix),value)
assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));assert model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'items':items,'top_variable':top.index,'expanded_width_um':width,'expanded_area_um2':area,'area_lower_top_um':lower,'no_overlap_2d':no_overlap.index,'x_cumulative':xc.index,'y_cumulative':yc.index,'orders':orders})
write(OUT/'control-assignment.json',{str(k):v for k,v in sorted(hints.items())})
write(OUT/'built.json',{'seconds':time.perf_counter()-started,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'mandatory_originals':26,'independent_anchor_coordinates':52,
    'legal_mode_options':sum(len(r['options']) for r in items),'expanded_component_options':component_count,'all_variables_hinted':len(hints)==len(model.proto.variables),'initial_top_um':maximum,'area_lower_top_um':lower,
    'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
