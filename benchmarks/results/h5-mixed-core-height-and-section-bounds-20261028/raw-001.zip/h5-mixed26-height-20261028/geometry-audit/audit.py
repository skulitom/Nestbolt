"""Independent original/expanded geometry and complete positive-control reader."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
from shapely.affinity import translate
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed26-height-20261028';OUT=BASE/'geometry-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
assert plan['pad_um']==112 and plan['stock_anchor_guard_um']==13 and plan['core_counts']=={'frame':18,'bracket':3,'insert':5}
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json')
expected=[('frame',q,False) for q in range(4)]+[('bracket',q,mir) for mir in [False,True] for q in range(4)]+[('insert',q,False) for q in range(4)]
assert len(modes)==len(expected)==16;expanded={};source={};mode_checks=[]
for i,(mode,(family,q,mir)) in enumerate(zip(modes,expected)):
    assert (mode['id'],mode['family'],mode['quarter'],mode['mirrored'])==(i,family,q,mir)
    p=parts[family];assert q*90 in p['rotations']['degrees'] and (not mir or p['allow_mirror'])
    c,s=round(math.cos(q*math.pi/2)),round(math.sin(q*math.pi/2));sign=-1 if mir else 1
    raw=[(1000*(sign*x*c-y*s),1000*(sign*x*s+y*c)) for x,y in p['geometry'][0]['outer']];lo=[min(r[k] for r in raw) for k in [0,1]]
    assert lo==mode['transformed_min_um'];g=Polygon([(x-lo[0],y-lo[1]) for x,y in raw]);assert g.equals(Polygon(mode['outer_um']))
    assert g.bounds==(0,0,mode['width_um'],mode['height_um']) and g.is_valid
    boxes=[box(*r) for r in mode['original_rectangles_um']];padded=[box(*r) for r in mode['expanded_rectangles_um']]
    assert all(p.area>0 for p in boxes+padded) and unary_union(boxes).equals(g)
    union=unary_union(padded);assert union.equals(g.buffer(112,join_style=2)) and union.covers(g.buffer(112,quad_segs=32))
    assert all(a.intersection(b).area==0 for a,b in combinations(padded,2))
    source[i]=g;expanded[i]=union;mode_checks.append({'mode':i,'source_area_um2':g.area,'expanded_area_um2':union.area,'expanded_components':len(padded)})
for family in ['frame','bracket','insert']:assert len({r['expanded_area_um2'] for r,m in zip(mode_checks,modes) if m['family']==family})==1
control=load(BASE/'control.json');assert len(control)==26;placed=[];rows=load(BASE/'control-source26.json');seen=set();xs={f:[] for f in ['frame','bracket','insert']}
for i,(r,row) in enumerate(zip(control,rows)):
    assert r['index']==i;mode=modes[r['mode']];assert r['family']==mode['family']==row['part_id'] and r['copy_index']==row['copy_index'];seen.add((r['family'],r['copy_index']))
    x,y=r['anchor_um'];assert 6513<=x<=1493487-mode['width_um'] and 6513<=y<=2167875-mode['height_um'];xs[r['family']].append(x)
    t=row['transform'];assert t['rotation_radians']==mode['quarter']*math.pi/2 and t['mirrored']==mode['mirrored'] and t['translation']==[(r['anchor_um'][k]-mode['transformed_min_um'][k])/1000 for k in [0,1]]
    old=r['old_source_row']['transform'];assert old['mirrored']==mode['mirrored'] and abs(old['rotation_radians']-t['rotation_radians'])<1e-12
    assert max(abs(old['translation'][k]-t['translation'][k]) for k in [0,1])<1e-9
    placed.append(translate(expanded[r['mode']],xoff=x,yoff=y))
assert seen=={('frame',i) for i in range(18)}|{('bracket',i) for i in range(3)}|{('insert',i) for i in range(8,13)}
assert all(x==sorted(x) for x in xs.values());pairs=[]
for i,j in combinations(range(26),2):assert placed[i].disjoint(placed[j]);pairs.append({'indices':[i,j],'expanded_gap_um':placed[i].distance(placed[j])})
short=load(BASE/'short15.json');assert len(short)==15 and short==[r for r in load(ROOT/'output/h5-staggered25-source-regions-20261028/fixed41.json') if r['sheet_id']=='sheet-1']
remaining=load(BASE/'remaining25.json');allkeys=seen|{(r['part_id'],r['copy_index']) for r in short}|{(r['family'],r['copy_index']) for r in remaining}
assert len(remaining)==25 and allkeys=={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])} and len(allkeys)==66
readback=audit(job,rows+short,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},.21170867250963943,.011444091796875)
assert readback['valid'] and readback==load(BASE/'control-source-readback.json')
area=sum(expanded[r['mode']].area for r in control);width=1493487-6513+224;lower=(int(area)+width-1)//width+6513-224
assert area==int(area) and lower<=2167875
write(OUT/'mode-coverage.json',mode_checks);write(OUT/'control-expanded-pairs.json',pairs);write(OUT/'source-readback.json',readback)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_modes_verified':16,'all_legal_quarter_mirror_modes_retained':True,'exact_original_and_expanded_unions_verified':16,
    'expanded_same_owner_components_disjoint':True,'positive_control_core_originals':26,'positive_control_expanded_pairs':325,'minimum_expanded_control_gap_um':min(r['expanded_gap_um'] for r in pairs),
    'positive_control_source_originals':41,'source_pairs_verified':readback['same_sheet_pairs'],'source_stock_edges':readback['stock_edges'],'source_holes':readback['cutouts'],'hole_vertices':readback['hole_vertices'],
    'expanded_area_um2':int(area),'expanded_width_um':width,'area_lower_top_um':lower,'all66_originals_accounted_once':True,'remaining_first_sheet_originals':25,
    'geometry_sha256':digest(BASE/'modes.json'),'control_sha256':digest(BASE/'control.json'),'plan_sha256':digest(BASE/'plan.json'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
