"""Seal completed release-candidate integration checks without rerunning them."""
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'output/depth-integration-20261016'
OUT=ROOT/'benchmarks/results/h4-depth-integration-20261016'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest

result=load(WORK/'results.json')
assert result['all_checks_passed'] and result['product_digest']==source_digest()
assert not subprocess.check_output(['git','diff','HEAD','--name-only','--','crates','web/src','Cargo.toml','Cargo.lock'],cwd=ROOT).strip(), 'Commit the checked source before sealing commit identity'
for row in result['commands']:
    assert row['exit_code']==0 and digest(WORK/(row['label']+'.log'))==row['log_sha256']
assert len(result['commands'])==12
def log(name):return re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',(WORK/(name+'.log')).read_text(encoding='utf-8',errors='replace'))
workspace=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log('workspace-tests'))]
counts={'workspace_passed':sum(r[0] for r in workspace),'workspace_ignored':sum(r[2] for r in workspace),
    'optimized_core':int(re.search(r'test result: ok\. (\d+) passed;',log('optimized-core')).group(1)),
    'optimized_cli':int(re.search(r'test result: ok\. (\d+) passed;',log('optimized-cli')).group(1)),
    'browser_passed':int(re.search(r'(\d+) passed \(',log('web-build-tests')).group(1)),
    'browser_skipped':int(re.search(r'(\d+) skipped',log('web-build-tests')).group(1)),
    'packaging_passed':int(re.search(r'\bpass (\d+)',log('packaging-tests')).group(1)),
    'packaging_skipped':int(re.search(r'\bskipped (\d+)',log('packaging-tests')).group(1))}
assert counts['workspace_passed']>=302 and counts['optimized_core']==75 and counts['optimized_cli']>=27
assert counts['browser_passed']>=86 and counts['packaging_passed']>=23
assert 'MCPB verified: Nestbolt 0.2.0-alpha.1, 5 tools, 4 files; import, nest and validation passed.' in log('verify-bundle-recheck')
assert result['original_bundle_verification_failed'] and result['controlled_bundle_recheck_passed']
assert not OUT.exists();OUT.mkdir()
snap=WORK/'snapshots';snap.mkdir()
for src,name in [(ROOT/'crates/core/src/sheets/vstrip.rs','vstrip.rs'),(ROOT/'target/release/nestbolt.exe','nestbolt.exe'),
    (ROOT/'web/src/pkg/nestbolt_wasm_bg.wasm','nestbolt_wasm_bg.wasm')]:shutil.copyfile(src,snap/name)
shutil.copyfile(ROOT/'output/integrate_h4_depth_candidate.py',WORK/'integrate.py')
shutil.copyfile(ROOT/'output/recheck_depth_bundle.py',WORK/'recheck-bundle.py')
shutil.copyfile(__file__,WORK/'seal.py')
files=sorted(p for p in WORK.rglob('*') if p.is_file())
inventory={p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p)} for p in files}
archive=OUT/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        raw=z.read(name);assert len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256']
write(OUT/'integrity.json',{'archive':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive),
    'members':inventory,'crc_and_every_member_verified':True})
write(OUT/'checks.json',{'scope':__doc__,'all_checks_passed':True,'counts':counts,
    'release_candidate_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    'product_digest':source_digest(),'cli_sha256':result['cli_sha256'],'mcp_sha256':result['mcp_sha256'],
    'wasm_sha256':result['wasm_sha256'],'candidate_vstrip_sha256':result['candidate_vstrip_sha256'],
    'actual_windows_bundle_verified':True,'H5_exchange_integrated':False,
    'original_bundle_inventory_failure_preserved':True,'controlled_bundle_recheck_passed':True,
    'full_current_quality_and_scale_still_required':True,'H4_complete':False,'held_out_geometry_read':False})
shutil.copyfile(WORK/'results.json',OUT/'results.json')
print(json.dumps({'checks':counts,'members':len(files),'bytes':archive.stat().st_size,'sha256':digest(archive)}))
