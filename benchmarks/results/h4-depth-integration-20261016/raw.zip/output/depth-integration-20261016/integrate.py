"""Integrate the depth-three candidate only after its pilot passes and diagnosis finishes."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import psutil

ROOT=Path(__file__).resolve().parents[1]
PROBE=ROOT/'output/h4-quadtree-depth-probe'
OUT=ROOT/'output/depth-integration-20261016'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')

sys.stdout.reconfigure(encoding='utf-8',errors='replace')
sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest

H4=ROOT/'benchmarks/results/h4-quadtree-depth-probe-20261016'
H5=ROOT/'benchmarks/results/h5-exchange-diagnosis-20261016'
sequence=ROOT/'output/depth-diagnosis-sequence-20261016'
reviewed=load(sequence/'reviewed-completion.json')
assert reviewed['h4_passed_pilot'] and reviewed['h5_all_layouts_valid']
assert reviewed['h5_trace_counts_rechecked'] and reviewed['original_sequence_interruption_retained']
assert digest(H5/'verification.json')==reviewed['verification_sha256']
assert digest(H5/'rechecked-traces.json')==reviewed['trace_sha256']
assert load(H4/'assessment.json')['passed_pilot']
assert load(H4/'verification.json')['all_saved_artifacts_verified']
assert load(H4/'verification.json')['valid']==99
assert load(H4/'integrity.json')['crc_and_every_member_verified']
assert load(H5/'verification.json')['all_archives_and_members_verified']
for folder,runner in [(H4,'h4_quadtree_depth_probe.py'),(H5,'h5_exchange_diagnosis.py'),(sequence,'continue_depth_diagnosis.py')]:
    pid=load(folder/'opened.json')['pid']
    assert not psutil.pid_exists(pid) or not any(runner in p for p in psutil.Process(pid).cmdline()),folder

assert not OUT.exists()
OUT.mkdir()
source=PROBE/'workspace/crates/core/src/sheets/vstrip.rs'
destination=ROOT/'crates/core/src/sheets/vstrip.rs'
preparation=load(PROBE/'preparation.json')
for row in preparation['baseline_files']:assert digest(ROOT/row['path'])==row['sha256'],row['path']
assert digest(source)==load(PROBE/'build.json')['candidate_sha256']
old_digest=source_digest()
shutil.copyfile(destination,OUT/'baseline-vstrip.rs')
shutil.copyfile(source,destination)
assert subprocess.check_output(['git','diff','--name-only','--','crates','web/src','Cargo.toml','Cargo.lock'],cwd=ROOT,text=True).splitlines()==['crates/core/src/sheets/vstrip.rs']
plan={'scope':__doc__,'previous_product_digest':old_digest,'new_product_digest':source_digest(),
    'candidate_vstrip_sha256':digest(destination),'source_change':'Separator-window base quadtree depth four to three only; exact isolated source',
    'H5_exchange_integrated':False,'reason':'The earlier H5 exchange pilot failed five of eight material pairs; stage diagnosis is observational only.',
    'prior_failures_preserved':True,'held_out_geometry_read':False,'release_still_pending':True}
write(OUT/'plan.json',plan)

records=[]
def run(label,command):
    log=OUT/(label+'.log')
    full=[sys.executable,'-X','utf8',str(ROOT/'output/ccd1.py'),*map(str,command)]
    env={**os.environ,'PYTHONIOENCODING':'utf-8'}
    started=datetime.now(timezone.utc).isoformat()
    with log.open('xb') as stream:
        result=subprocess.run(full,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
    records.append({'label':label,'command':full,'started':started,'finished':datetime.now(timezone.utc).isoformat(),
        'exit_code':result.returncode,'log_sha256':digest(log)})
    write(OUT/'progress.json',records)
    print(label,result.returncode,log.read_text(encoding='utf-8',errors='replace')[-1600:],flush=True)
    assert result.returncode==0,label

run('format',['cargo','fmt','--all','--check'])
run('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'])
run('workspace-tests',['cargo','test','--workspace','--locked'])
run('optimized-core',['cargo','test','--release','--locked','-p','nestbolt-core','--lib'])
run('optimized-cli',['cargo','test','--release','--locked','-p','nestbolt-cli','--test','features'])
run('native-build',['cargo','build','--release','--locked','-p','nestbolt-cli','-p','nestbolt-mcp'])
run('web-build-tests',[sys.executable,'-X','utf8','scripts/build_web.py','--test'])
run('notices',[sys.executable,'scripts/notices.py','--check'])
run('schemas',[sys.executable,'scripts/schemas.py','--check'])
run('packaging-tests',['node','--test','mcpb/mcpb.test.mjs'])
run('bundle',['node','mcpb/build.mjs','--binary',ROOT/'target/release/nestbolt-mcp.exe','--out',OUT/'bundle'])
run('verify-bundle',['node','mcpb/verify.mjs',OUT/'bundle/nestbolt-windows-x64.mcpb'])
assert source_digest()==plan['new_product_digest']
write(OUT/'results.json',{'all_checks_passed':True,'commands':records,'product_digest':source_digest(),
    'cli_sha256':digest(ROOT/'target/release/nestbolt.exe'),
    'mcp_sha256':digest(ROOT/'target/release/nestbolt-mcp.exe'),
    'wasm_sha256':digest(ROOT/'web/src/pkg/nestbolt_wasm_bg.wasm'),
    'candidate_vstrip_sha256':digest(destination),'H5_exchange_integrated':False,'release_still_pending':True})
print('Tree-depth candidate integrated and checked; fresh full comparison and scale remain.',flush=True)
