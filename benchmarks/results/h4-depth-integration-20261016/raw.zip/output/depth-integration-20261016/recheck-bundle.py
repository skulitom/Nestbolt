"""Repeat only bundle confinement verification after stopping competing evidence writes."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json, subprocess, sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/depth-integration-20261016'
sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
records=load(OUT/'progress.json');plan=load(OUT/'plan.json')
assert len(records)==12 and all(r['exit_code']==0 for r in records[:-1])
assert records[-1]['label']=='verify-bundle' and records[-1]['exit_code']==1
assert 'h5-obstruction-set-preparation-20261016' in (OUT/'verify-bundle.log').read_text(encoding='utf-8')
assert source_digest()==plan['new_product_digest']
bundle=OUT/'bundle/nestbolt-windows-x64.mcpb';before=digest(bundle)
assert before=='2af78ddc07b2f46ac4edd67447aab3ad37fa54099cb3d46c5d10f850a888c129'
log=OUT/'verify-bundle-recheck.log';command=[sys.executable,str(ROOT/'output/ccd1.py'),'node','mcpb/verify.mjs',str(bundle)]
started=datetime.now(timezone.utc).isoformat()
with log.open('xb') as f:r=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,timeout=120)
record={'label':'verify-bundle-recheck','command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'log_sha256':digest(log)}
write(OUT/'bundle-recheck.json',{'original_failure_retained':True,'reason':'Original write-confinement inventory overlapped this task creating the H5 preparation evidence folder; stop all competing repository writes before this recheck','bundle_sha256_before':before,'bundle_sha256_after':digest(bundle),'original_failed_record':records[-1],'recheck':record})
assert r.returncode==0 and digest(bundle)==before and source_digest()==plan['new_product_digest']
write(OUT/'results.json',{'all_checks_passed':True,'commands':records[:-1]+[record],'original_commands':records,
    'original_bundle_verification_failed':True,'controlled_bundle_recheck_passed':True,'product_digest':source_digest(),
    'cli_sha256':digest(ROOT/'target/release/nestbolt.exe'),'mcp_sha256':digest(ROOT/'target/release/nestbolt-mcp.exe'),
    'wasm_sha256':digest(ROOT/'web/src/pkg/nestbolt_wasm_bg.wasm'),'candidate_vstrip_sha256':digest(ROOT/'crates/core/src/sheets/vstrip.rs'),
    'H5_exchange_integrated':False,'release_still_pending':True})
print(log.read_text(encoding='utf-8'))
