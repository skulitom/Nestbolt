"""One bounded LP proposes an exactly verified necessary bound for the row covers."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime, timezone
import json, shutil, time
import numpy as np
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parents[1]
STUDY=ROOT/'output/h5-rational-source-20261028/row-cover-study'
OUT=STUDY/'section-bound'; CORE=ROOT/'output/h5-mixed26-height-20261028'
load=lambda p:json.loads(p.read_bytes()); digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'derive.py');started=time.perf_counter()
inputs=[STUDY/n for n in ['plan.json','audit/checks.json','row-mode.json','first39-blocks.json','area-necessity.json']]+[CORE/'modes.json',CORE/'source-audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Necessary horizontal-section bound on the declared three rigid five-cog hull covers and all36 orthogonal expanded covers, all movable. At each horizontal section of one cover, sum its disjoint rectangle widths. Enumerate every total-family-capped pattern fitting stock width. Row widths all exceed half stock width, so at most one row contributes per section. One bounded LP proposes nonnegative section weights; exact rational normalization and minimum per-family profile integrals provide the certificate. An independent enumerator must verify it before interpretation. Exclusion applies only to these covers, not original-source feasibility or all rigid rows.',
    'stock_width_um':1487000,'stock_height_um':2987000,'counts':{'frame':18,'bracket':6,'insert':12,'cog-row':3},'maximum_linear_programs':1,'maximum_lp_seconds':10,'retry_permitted':False,'packing_solver_calls':0})
assert load(STUDY/'audit/checks.json')['passed']
def profile(rects):
    ys=sorted({y for r in rects for y in [r[1],r[3]]});out={}
    for lo,hi in zip(ys,ys[1:]):
        w=sum(r[2]-r[0] for r in rects if r[1]<=lo and r[3]>=hi)
        if w:out[w]=out.get(w,0)+hi-lo
    return sorted(out.items())
modes=load(CORE/'modes.json');profiles=[{'family':m['family'],'mode':m['id'],'profile':profile(m['expanded_rectangles_um'])} for m in modes]
rp=profile(load(STUDY/'row-mode.json')['cover_rectangles_um']);profiles.append({'family':'cog-row','mode':'row','profile':rp});write(OUT/'profiles.json',profiles)
families=['frame','frame','insert','insert','bracket','bracket','bracket','bracket']
widths=[450224,350224,180224,110224,300224,100224,250224,75224]
assert set(w for p in profiles[:-1] for w,h in p['profile'])==set(widths)
row_widths=[w for w,h in rp];assert 2*min(row_widths)>1487000
all_widths=widths+row_widths;n=len(all_widths);patterns=[];caps={'frame':18,'insert':12,'bracket':6}
def enumerate_base(available,row_index):
    def visit(k,left,remaining,chosen):
        if k==8:patterns.append(chosen+[row_index]);return
        family=families[k]
        for count in range(min(left//widths[k],remaining[family])+1):
            nxt=dict(remaining);nxt[family]-=count;visit(k+1,left-count*widths[k],nxt,chosen+[count])
    visit(0,available,caps,[])
enumerate_base(1487000,-1)
for j,w in enumerate(row_widths):enumerate_base(1487000-w,j)
write(OUT/'patterns.json',patterns);write(OUT/'widths.json',all_widths)
A=np.zeros((len(patterns)+len(profiles)-1,n+3));b=np.ones(len(A));b[len(patterns):]=0
for i,p in enumerate(patterns):
    A[i,:8]=p[:8]
    if p[8]>=0:A[i,8+p[8]]=1
family_order=['frame','bracket','insert'];counts=[18,6,12];objective=np.zeros(n+3);objective[n:]=-np.array(counts)
for w,h in rp:objective[all_widths.index(w)]-=3*h
for j,p in enumerate(profiles[:-1]):
    A[len(patterns)+j,n+family_order.index(p['family'])]=1
    for w,h in p['profile']:A[len(patterns)+j,all_widths.index(w)]=-h
begun=time.perf_counter();lp=linprog(objective,A_ub=A,b_ub=b,bounds=(0,None),method='highs',options={'time_limit':10.});elapsed=time.perf_counter()-begun
write(OUT/'linear-program-result.json',{'status':int(lp.status),'message':lp.message,'success':bool(lp.success),'seconds':elapsed,'objective':None if lp.fun is None else float(lp.fun),'x':None if lp.x is None else list(map(float,lp.x))})
assert lp.success and lp.x is not None
proposed=[F(float(max(0,x))).limit_denominator(1000000) for x in lp.x[:n]]
def weight(p,ws):return sum(k*w for k,w in zip(p[:8],ws[:8]))+(ws[8+p[8]] if p[8]>=0 else 0)
normalizer=max(weight(p,proposed) for p in patterns);assert normalizer>0
weights=[w/normalizer for w in proposed];assert max(weight(p,weights) for p in patterns)==1
integrals={f:min(sum(weights[all_widths.index(w)]*h for w,h in p['profile']) for p in profiles if p['family']==f) for f in family_order+['cog-row']}
span=sum(F(c)*integrals[f] for f,c in load(OUT/'plan.json')['counts'].items());excess=span-2987000
cert={'width_weights':[[w.numerator,w.denominator] for w in weights],'family_integrals_um':{k:[v.numerator,v.denominator] for k,v in integrals.items()},'section_patterns':len(patterns),'span_lower_um':[span.numerator,span.denominator],'span_lower_mm':float(span/1000),'stock_height_mm':2987,'excess_over_stock_mm':float(excess/1000),'declared_cover_model_excluded':excess>0,'original_source_feasibility_excluded':False,'all_rigid_row_models_excluded':False,'packing_solver_calls':0}
write(OUT/'certificate.json',cert);write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-started,'linear_programs':1,'packing_solver_calls':0,'independently_audited':False});print({k:cert[k] for k in ['section_patterns','span_lower_mm','excess_over_stock_mm','declared_cover_model_excluded']})
