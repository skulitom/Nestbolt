"""Independent integer sweep and exact enumeration verify the cover-only bound."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];STUDY=ROOT/'output/h5-rational-source-20261028/row-cover-study';BASE=STUDY/'section-bound';OUT=BASE/'audit';CORE=ROOT/'output/h5-mixed26-height-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');begun=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
assert plan['counts']=={'frame':18,'bracket':6,'insert':12,'cog-row':3} and plan['stock_width_um']==1487000 and plan['stock_height_um']==2987000
assert load(STUDY/'audit/checks.json')['passed'] and load(CORE/'source-audit/checks.json')['passed']
def sweep(rects):
    events={}
    for a,b,c,d in rects:
        assert all(isinstance(v,int) for v in (a,b,c,d)) and a<c and b<d
        events.setdefault(b,[]).append((1,a,c));events.setdefault(d,[]).append((-1,a,c))
    active=[];last=None;profile={}
    for y,changes in sorted(events.items()):
        if last is not None and active:
            ordered=sorted(active);assert all(a[1]<=b[0] for a,b in zip(ordered,ordered[1:]))
            w=sum(b-a for a,b in ordered);profile[w]=profile.get(w,0)+y-last
        for sign,a,c in changes:
            if sign==1:active.append((a,c))
            else:active.remove((a,c))
        last=y
    assert not active
    return sorted(profile.items())
profiles=[]
for m in load(CORE/'modes.json'):profiles.append({'family':m['family'],'mode':m['id'],'profile':[list(v) for v in sweep(m['expanded_rectangles_um'])]})
rp=sweep(load(STUDY/'row-mode.json')['cover_rectangles_um']);profiles.append({'family':'cog-row','mode':'row','profile':[list(v) for v in rp]});assert profiles==load(BASE/'profiles.json')
widths=load(BASE/'widths.json');assert widths[:8]==[450224,350224,180224,110224,300224,100224,250224,75224] and widths[8:]==[w for w,h in rp] and 2*min(widths[8:])>1487000
# Enumerate all row-free orthogonal patterns once, then independently test all row widths.
families=['frame','frame','insert','insert','bracket','bracket','bracket','bracket'];rows=[]
def visit(k,counts):
    if k==8:
        used=sum(c*w for c,w in zip(counts,widths));rows.append(tuple(counts+[-1]))
        for j,w in enumerate(widths[8:]):
            if used+w<=1487000:rows.append(tuple(counts+[j]))
        return
    family=families[k];used_width=sum(c*w for c,w in zip(counts,widths));family_used=sum(c for c,f in zip(counts,families) if f==family)
    for c in range(min((1487000-used_width)//widths[k],plan['counts'][family]-family_used)+1):visit(k+1,counts+[c])
visit(0,[]);saved=load(BASE/'patterns.json');assert len(rows)==len(saved)==len(set(rows)) and set(rows)==set(map(tuple,saved))
cert=load(BASE/'certificate.json');weights=[F(*v) for v in cert['width_weights']];assert len(weights)==len(widths) and all(v>=0 for v in weights)
maximum=max(sum(c*w for c,w in zip(p[:8],weights[:8]))+(weights[8+p[8]] if p[8]>=0 else 0) for p in rows);assert maximum==1
integrals={f:min(sum(weights[widths.index(w)]*h for w,h in p['profile']) for p in profiles if p['family']==f) for f in plan['counts']}
assert integrals=={k:F(*v) for k,v in cert['family_integrals_um'].items()}
span=sum(plan['counts'][f]*v for f,v in integrals.items());assert span==F(*cert['span_lower_um']) and float(span/1000)==cert['span_lower_mm'] and float((span-2987000)/1000)==cert['excess_over_stock_mm'] and (span>2987000)==cert['declared_cover_model_excluded']
assert not cert['original_source_feasibility_excluded'] and not cert['all_rigid_row_models_excluded'] and load(BASE/'result.json')['closed']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/n for n in ['plan.json','profiles.json','patterns.json','widths.json','certificate.json','result.json']]}})
write(OUT/'proof.json',{'statement':'For any nonoverlapping placement of the stated expanded covers, the cover intervals at almost every horizontal section are disjoint. The sweep sums each original cover width, and every legal orientation is represented. No two row covers can intersect the same horizontal section because each exceeds half the stock width. Every possible family-count-capped section is exhaustively enumerated. Its exact nonnegative rational weight is at most one. Integration yields the saved lower bound on required vertical span, independent of all translations and family orientations. The convex hull and slabs add space absent from original cog rows. Therefore this certificate can exclude this cover model only; it does not exclude the original 66-part problem, all rigid rows, other covers or any global allocation.'})
result={'passed':True,'seconds':time.perf_counter()-begun,'cover_modes_verified':len(profiles),'horizontal_sections_of_row':sum(1 for _ in rp),'section_patterns_verified':len(rows),'maximum_exact_pattern_weight':1,'span_lower_um':[span.numerator,span.denominator],'span_lower_mm':float(span/1000),'stock_height_mm':2987,'excess_over_stock_mm':float((span-2987000)/1000),'declared_cover_model_excluded':span>2987000,'original_source_feasibility_excluded':False,'all_rigid_row_models_excluded':False,'count_frontier_changed':False,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
