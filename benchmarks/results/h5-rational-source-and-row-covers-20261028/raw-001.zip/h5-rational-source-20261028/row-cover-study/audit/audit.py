"""Reconstruct original row vertices and independently prove conservative rectangle coverage."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,MultiPoint,box,shape
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';STUDY=BASE/'row-cover-study';OUT=STUDY/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for n,h in load(STUDY/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='cog');row=load(STUDY/'row-mode.json');rects=row['cover_rectangles_um'];polys=[]
assert len(row['source_instances'])==5 and row['pitch_mm']==258.9 and row['angle_radians']==math.radians(7)
for i,r in enumerate(row['source_instances']):
    assert r['relative_copy']==i and r['part_id']=='cog' and r['angle']==math.radians(7) and r['mirrored'] is False;c,s=math.cos(r['angle']),math.sin(r['angle']);tx,ty=r['translation'];polys.append(Polygon([(c*x-s*y+tx,s*x+c*y+ty) for x,y in part['geometry'][0]['outer']]))
    if i:assert abs(tx-row['source_instances'][i-1]['translation'][0]-258.9)<1e-10 and ty==row['source_instances'][i-1]['translation'][1]
covered=unary_union([box(a/1000,b/1000,c/1000,d/1000) for a,b,c,d in rects]);assert covered.equals(shape(row['cover_geometry']))
radius=load(BASE/'plan.json')['required_pair_gap_mm']/2/math.cos(math.pi/64)+1e-7
for g in polys:assert covered.covers(g.buffer(radius,quad_segs=16))
all_vertices=[v for p in polys for v in list(p.exterior.coords)[:-1]];hull=MultiPoint(all_vertices).convex_hull;assert hull.symmetric_difference(shape(row['convex_hull'])).area<1e-7
expanded=MultiPoint([(x+dx,y+dy) for x,y in list(hull.exterior.coords)[:-1] for dx in [-.112,.112] for dy in [-.112,.112]]).convex_hull;assert covered.covers(expanded) or expanded.difference(covered).area<1e-12
pairs=0
for a,b in combinations(rects,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];pairs+=1
plan=load(BASE/'plan.json');r=audit(job,load(STUDY/'source5.json'),plan['source_stocks'],plan['required_pair_gap_mm'],plan['stock_guard_mm'],[('cog',i) for i in range(5)]);assert r==load(STUDY/'source5-audit.json') and r['valid']
short=load(STUDY/'short15.json');short_result=audit(job,short,plan['source_stocks'],plan['required_pair_gap_mm'],plan['stock_guard_mm'],[(p['part_id'],p['copy_index']) for p in short]);assert short_result['valid'];write(OUT/'short15-source.json',short_result)
blocks=load(STUDY/'first39-blocks.json');keys=[]
for b in blocks:keys.extend([('cog',i) for i in b['copy_indices']] if b['family']=='cog-row' else [(b['family'],b['copy_index'])])
keys += [(r['part_id'],r['copy_index']) for r in short];assert len(keys)==len(set(keys))==66 and set(keys)=={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
area=load(STUDY/'area-necessity.json');row_area=sum((c-a)*(d-b) for a,b,c,d in rects);assert row_area==area['row_cover_area_um2'];stock=1487000*2987000;total=3*row_area+sum(area['first_sheet_source_counts'][f]*v for f,v in area['orthogonal_source_expanded_areas_um2'].items());assert stock==area['usable_stock_area_um2'] and total==area['first_sheet_cover_area_um2'] and stock-total==area['slack_um2']
inputs=[STUDY/n for n in ['plan.json','row-mode.json','source5.json','source5-audit.json','first39-blocks.json','short15.json','area-necessity.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'original_cog_shapes_verified':5,'row_internal_source_pairs':r['same_sheet_pairs'],'minimum_internal_source_gap_mm':r['minimum_pair_gap_mm'],'row_cover_components':len(rects),'same_owner_rectangle_pairs_verified':pairs,'required_clearance_discs_contained':True,'short15_source_valid':True,'all66_originals_accounted_once':True,'area_necessary_condition_passes':total<=stock,'cover_area_slack_mm2':(stock-total)/1e6,'no_full_placement_or_feasibility_claim':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
