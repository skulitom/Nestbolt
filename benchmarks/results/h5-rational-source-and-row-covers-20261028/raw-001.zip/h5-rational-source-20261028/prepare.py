"""Freeze an independently readable real-arithmetic formulation with all111 known cases."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from h5_rational_formula_builder_20261028 import build
from h5_rational_formula_reader_20261028 import inspect,evaluate
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-mode-collision-source-20261028';BASE=ROOT/'output/h5-rational-source-20261028';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,BASE/'prepare.py');started=time.perf_counter();assert load(OLD/'response-audit/checks.json')['passed'] and load(OLD/'originals-audit/checks.json')['passed'] and load(OLD/'search/result.json')['closed'];assert load(BASE/'dependency/installed.json')['runtime']['z3_version']=='5.3.2'
inputs=[OLD/n for n in ['plan.json','response-audit/checks.json','originals-audit/checks.json','search/02/mapping.json','search/02/model.pb','search/00/selected-poses.json','search/00/source-audit.json','search/01/selected-poses.json','search/01/source-audit.json','remaining25.json','fixed41.json','modes.json','control.json','control-source56.json']]+sorted((OLD/'free').glob('*.json'))+sorted((OLD/'relative').glob('*.json'))+[BASE/'dependency'/n for n in ['installed.json','runtime-bindings.json','wheel-checks.json','upstream-tag-LICENSE.txt']]+[ROOT/'output'/n for n in ['h5_rational_formula_builder_20261028.py','h5_rational_formula_reader_20261028.py']]
plan=load(OLD/'plan.json');write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New Z3 QF_LRA source-generation sequence with50 continuous real anchor coordinates and Boolean legal modes. Direct audited halfplane disjunctions replace the CP selector/integer encoding. Start with all111 observed mode cases from the closed CP experiment. Add only newly source-failing mode cases incrementally in one solver instance. Preserve all25 mandatory movers around fixed41, mode restrictions and ordering. Exact rational assignment evaluation and float-converted original-source checks are separate mandatory acceptance stages.','required_pair_gap_mm':plan['required_pair_gap_mm'],'stock_guard_mm':plan['stock_guard_mm'],'source_stocks':plan['source_stocks'],'mode_subset':plan['modes'],'algorithm_seconds':60,'shared_seconds':90,'maximum_distinct_checks':32,'maximum_seconds_per_check':15,'threads':1,'random_seed':0,'stop_after_no_candidate_response':True,'no_repeat_identical_formula':True,'budget_includes_dynamic_build_audit_checks_and_source_readback':True,'real_coordinates_not_integer_grid':True,'halfplane_rounding_error_bound_applies_to_all_reals_in_same_absolute_bounds':True,'float_conversion_original_source_check_required':True,'native_calls':0,'H5_complete':False})
for n in ['remaining25.json','fixed41.json','modes.json','control.json','control-source56.json']:shutil.copyfile(OLD/n,BASE/n)
for n in ['free','relative']:shutil.copytree(OLD/n,BASE/n)
oldmp=load(OLD/'search/02/mapping.json');cases=sorted([r['left'],r['right'],g['left_mode'],g['right_mode']] for r in oldmp['pairs'] for g in r['groups']);assert len(cases)==111
remaining=load(BASE/'remaining25.json');modes=load(BASE/'modes.json');free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)};control=load(BASE/'control.json')
text,mp=build(remaining,modes,free,relative,cases);(OUT/'model.smt2').write_text(text,encoding='utf-8',newline='\n');write(OUT/'mapping.json',mp);write(OUT/'cases.json',cases);checks,assertions,partial,decls=inspect((OUT/'model.smt2').read_text(),mp,remaining,modes,free,relative,cases,control);write(OUT/'partial-control-assignment.json',{k:v if isinstance(v,bool) else str(v) for k,v in partial.items()})
rejections=[]
for name in ['00','01']:
    poses=load(OLD/f'search/{name}/selected-poses.json');bykey={(r['family'],r['copy_index']):r for r in poses};values={}
    for item in mp['items']:
        row=bykey[item['family'],item['copy_index']];values[item['presence']]=True;values[item['x']],values[item['y']]=map(__import__('fractions').Fraction,row['anchor_um'])
        for o in item['options']:values[o['selector']]=o['mode']==row['mode']
    failed=[i for i,a in enumerate(assertions) if not evaluate(a,values)];assert failed and all(i in [r['assertion'] for r in mp['cases']] for i in failed);source=load(OLD/f'search/{name}/source-audit.json');byindex={(r['family'],r['copy_index']):r['index'] for r in mp['items']};required=[]
    for failure in source['pairs']:
        if failure['passed']:continue
        li,ri=sorted(byindex[tuple(k)] for k in failure['keys']);left,right=mp['items'][li],mp['items'][ri];a,b=[bykey[it['family'],it['copy_index']]['mode'] for it in [left,right]];record=next(r for r in mp['cases'] if [r['left'],r['right'],r['left_mode'],r['right_mode']]==[li,ri,a,b]);assert record['assertion'] in failed;required.append(record['assertion'])
    rejections.append({'previous_candidate':name,'source_pair_failures':source['pair_failures'],'all_violating_cases_excluded':True,'failed_assertions':failed,'required_case_assertions':required})
write(OUT/'previous-candidate-rejections.json',rejections);write(OUT/'checks.json',{**checks,'seconds':time.perf_counter()-started,'previous_rejected_candidates_excluded':2,'all111_cases_preserved':True,'model_sha256':digest(OUT/'model.smt2'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False})
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',OUT/'cases.json',ROOT/'output/h5_rational_formula_builder_20261028.py',ROOT/'output/h5_rational_formula_reader_20261028.py']}});print(load(OUT/'checks.json'))
