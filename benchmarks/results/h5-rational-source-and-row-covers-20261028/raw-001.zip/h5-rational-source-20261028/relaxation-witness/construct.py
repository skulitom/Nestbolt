"""Deterministic SAT certificate for the closed relaxation; never a physical layout claim."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,shutil,subprocess,sys,time
from shapely.geometry import shape
from h5_rational_formula_reader_20261028 import parse,evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';OUT=BASE/'relaxation-witness';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');started=time.perf_counter();assert load(BASE/'search/result.json')['closed'] and load(BASE/'search/result.json')['reason']=='NO_CANDIDATE_UNKNOWN';mp=load(BASE/'model/mapping.json');control={(r['family'],r['copy_index']):r for r in load(BASE/'control.json')};values={};poses=[]
for item in mp['items']:
    known=control.get((item['family'],item['copy_index']))
    if known:mode=known['mode'];x,y=known['anchor_um']
    else:
        mode={'bracket':3,'insert':10}[item['family']];cells=load(BASE/'free'/f'{mode:02d}.json')['cells'];center=shape(cells[0]['geometry']).centroid;x,y=round(center.x*1000),round(center.y*1000)
        assert any(all(a*x+b*y>=c for a,b,c in cell['halfplanes']) for cell in cells)
    values[item['presence']]=True;values[item['x']]=F(x);values[item['y']]=F(y)
    for o in item['options']:values[o['selector']]=o['mode']==mode
    poses.append({'family':item['family'],'copy_index':item['copy_index'],'mode':mode,'anchor_um':[x,y]})
assertions=[r[1] for r in parse((BASE/'model/model.smt2').read_text()) if r[0]=='assert'];assert len(assertions)==352 and all(evaluate(a,values) for a in assertions)
active=[];inactive=[]
for row in mp['cases']:
    left,right=mp['items'][row['left']],mp['items'][row['right']];selectors=[next(o['selector'] for o in it['options'] if o['mode']==mode) for it,mode in [(left,row['left_mode']),(right,row['right_mode'])]];(active if all(values[s] for s in selectors) else inactive).append(row)
assert len(active)==21 and len(inactive)==90 and all(mp['items'][r['left']]['family']==mp['items'][r['right']]['family']=='cog' for r in active)
write(OUT/'assignment-rational.json',{k:v if isinstance(v,bool) else str(v) for k,v in values.items()});write(OUT/'integer-poses.json',poses);shutil.copyfile(BASE/'model/mapping.json',OUT/'mapping.json')
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'model/model.smt2',BASE/'model/mapping.json',BASE/'model/cases.json',BASE/'control.json',BASE/'search/result.json',ROOT/'output/h5_rational_formula_reader_20261028.py',ROOT/'output/check_h5_rational_source_candidate_20261028.py']},'method':'No search: keep15 source-control cogs, place all3 brackets in mode3 at the first free-cell centroid rounded to micrometres, and all7 inserts in mode10 at their first free-cell centroid. Check every SMT assertion exactly. This assignment activates only21 cog/cog cases and bypasses90 cases tied to other modes. Original-source rejection remains mandatory.','solver_calls':0,'does_not_resume_closed_search':True})
p=subprocess.run([sys.executable,str(ROOT/'output/check_h5_rational_source_candidate_20261028.py'),str(OUT)],cwd=ROOT,capture_output=True,timeout=30);(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode();r=load(OUT/'source-audit.json');assert not r['valid'] and r['pair_failures']>=24 and r['stock_failures']==0
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'full_relaxation_satisfiable_by_exact_certificate':True,'exact_assertions_passed':352,'all25_required_movers_present':True,'source_originals':66,'active_mode_cases':21,'inactive_mode_cases':90,'active_cases_all_cog_cog':True,'source_pair_failures':r['pair_failures'],'source_stock_failures':0,'source_valid':False,'physical_feasibility_not_proved':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
