"""Ground every parsed Z3 assertion under the constructive certificate, without a solve."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
import z3
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';OUT=BASE/'relaxation-witness/engine-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();raw=load(BASE/'relaxation-witness/assignment-rational.json');subs=[]
for name,v in raw.items():subs.append((z3.Bool(name),z3.BoolVal(v)) if isinstance(v,bool) else (z3.Real(name),z3.RealVal(v)))
asts=z3.parse_smt2_file(str(BASE/'model/model.smt2'));assert len(asts)==352 and len(subs)==128
for a in asts:assert z3.is_true(z3.simplify(z3.substitute(a,*subs)))
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'model/model.smt2',BASE/'relaxation-witness/plan.json',BASE/'relaxation-witness/checks.json',BASE/'relaxation-witness/assignment-rational.json',BASE/'dependency/runtime-bindings.json']}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'Z3_ground_assertions_true':352,'full_assignment_variables':128,'symbolic_satisfiability_checks':0,'relaxation_satisfiable_certificate_confirmed':True,'physical_layout_invalid':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
