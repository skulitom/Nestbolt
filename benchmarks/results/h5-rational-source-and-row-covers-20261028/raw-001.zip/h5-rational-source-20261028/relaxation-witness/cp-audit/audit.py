"""Read the constructive certificate against the closed integer CP model as well."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';CP=ROOT/'output/h5-mode-collision-source-20261028/search/02';OUT=BASE/'relaxation-witness/cp-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();p=cp_model_pb2.CpModelProto();p.ParseFromString((CP/'model.pb').read_bytes());mp=load(CP/'mapping.json');poses={(r['family'],r['copy_index']):r for r in load(BASE/'relaxation-witness/integer-poses.json')};values={}
def cell_for(cells,x,y):return next(k for k,c in enumerate(cells) if all(a*x+b*y>=v for a,b,v in c['halfplanes']))
for item in mp['items']:
    r=poses[item['family'],item['copy_index']];values[item['presence']]=1;x,y=r['anchor_um'];values[item['x']]=x;values[item['y']]=y
    for o in item['options']:
        active=o['mode']==r['mode'];values[o['selector']]=int(active);k=cell_for(load(BASE/'free'/f"{o['mode']:02d}.json")['cells'],x,y) if active else None
        for j,v in enumerate(o['cells']):values[v]=int(active and j==k)
for pair in mp['pairs']:
    left,right=mp['items'][pair['left']],mp['items'][pair['right']];la,rb=poses[left['family'],left['copy_index']],poses[right['family'],right['copy_index']]
    for group in pair['groups']:
        a,b=group['left_mode'],group['right_mode'];active=(la['mode'],rb['mode'])==(a,b);sign=1 if a<=b else -1;k=cell_for(load(BASE/'relative'/f'{min(a,b):02d}-{max(a,b):02d}.json')['cells'],*[sign*(rb['anchor_um'][i]-la['anchor_um'][i]) for i in [0,1]]) if active else None
        for j,v in enumerate(group['cells']):values[v]=int(active and j==k)
sol=[values[i] for i in range(len(p.variables))];check=evaluate(p,sol,0);assert check['variables']==5871 and check['constraints']==20824;write(OUT/'assignment.json',sol)
write(OUT/'plan.json',{'inputs':{q.relative_to(ROOT).as_posix():digest(q) for q in [CP/'model.pb',CP/'mapping.json',BASE/'relaxation-witness/plan.json',BASE/'relaxation-witness/checks.json',BASE/'relaxation-witness/integer-poses.json',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py']}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,**check,'closed_CP_model_is_satisfiable':True,'same_full_required_part_accounting':True,'physical_layout_is_invalid':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
