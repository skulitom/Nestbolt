"""One incremental QF_LRA sequence, exact assignment checks and original-source rejection."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    import z3
    from h5_rational_formula_builder_20261028 import build
    from h5_rational_formula_reader_20261028 import inspect,evaluate
    from h5_rational_z3_ast_20261028 import tree
    started=time.perf_counter();deadline=started+60
    for folder in [BASE,BASE/'model',BASE/'real-domain-audit',BASE/'engine-input-audit',BASE/'rational-source-fixtures',BASE/'hint-audit']:
        for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    for n,h in load(BASE/'dependency/runtime-bindings.json').items():assert digest(ROOT/n)==h,n
    assert all(load(BASE/n)['passed'] for n in ['model/checks.json','real-domain-audit/checks.json','engine-input-audit/checks.json','rational-source-fixtures/checks.json','hint-audit/checks.json']) and z3.get_version_string()=='5.3.2'
    inputs=[BASE/n for n in ['plan.json','model/model.smt2','model/mapping.json','model/cases.json','model/checks.json','engine-input-audit/checks.json','initial-values.json','hint-audit/checks.json','dependency/runtime-bindings.json']]+[ROOT/'output'/n for n in ['h5_rational_formula_builder_20261028.py','h5_rational_formula_reader_20261028.py','h5_rational_z3_ast_20261028.py','check_h5_rational_source_candidate_20261028.py','h5_legacy64_source_readback.py',Path(__file__).name]]
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'engine':'Z3 5.3.2 QF_LRA','algorithm_seconds':60,'shared_seconds':90,'maximum_distinct_checks':32,'maximum_seconds_per_check':15,'threads':1,'random_seed':0,'incremental_single_solver':True,'stop_after_no_candidate':True})
    remaining=load(BASE/'remaining25.json');modes=load(BASE/'modes.json');free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)};control=load(BASE/'control.json');cases=load(BASE/'model/cases.json');known=set(map(tuple,cases));solver=z3.SolverFor('QF_LRA');solver.set(random_seed=0,threads=1);records=[];seen_hashes=set();previous=[];pending=[];valid=False;reason='MAXIMUM_DISTINCT_CHECKS'
    for sequence in range(32):
        if time.perf_counter()>=deadline:reason='ALGORITHM_DEADLINE';break
        folder=OUT/f'{sequence:02d}';folder.mkdir();iteration_start=time.perf_counter();cases.extend([list(v) for v in pending]);known.update(pending);text,mp=build(remaining,modes,free,relative,cases);(folder/'model.smt2').write_text(text,encoding='utf-8',newline='\n');write(folder/'mapping.json',mp);write(folder/'cases.json',cases);h=digest(folder/'model.smt2');assert h not in seen_hashes;seen_hashes.add(h)
        checks,assertions,_,decls=inspect(text,mp,remaining,modes,free,relative,cases,control);assert assertions[:len(previous)]==previous;asts=z3.parse_smt2_string(text);assert len(asts)==len(assertions)
        if sequence==0:
            assert h==load(BASE/'model/checks.json')['model_sha256'];solver.add(asts)
            for name,value in load(BASE/'initial-values.json').items():solver.set_initial_value(z3.Bool(name) if isinstance(value,bool) else z3.Real(name),z3.BoolVal(value) if isinstance(value,bool) else z3.RealVal(value))
            engine_fields_verified='Initial formula hash equals the fully walked engine-input audit.'
        else:
            for ix in range(len(previous),len(assertions)):assert tree(asts[ix],decls)==assertions[ix]
            solver.add(*list(asts)[len(previous):]);engine_fields_verified='Every newly appended Z3 AST matches the independent parsed assertion tree.'
        current=solver.assertions();assert len(current)==len(assertions) and all(a.eq(b) for a,b in zip(current,asts));write(folder/'model-audit.json',{**checks,'model_sha256':h,'mapping_sha256':digest(folder/'mapping.json'),'new_mode_cases':[list(v) for v in pending],'assertion_prefix_unchanged':True,'engine_input_verification':engine_fields_verified,'single_incremental_solver_assertions_match_current_formula':True})
        allowance_ms=min(15000,int((deadline-time.perf_counter())*1000))
        if allowance_ms<=0:reason='ALGORITHM_DEADLINE_DURING_BUILD_AUDIT';break
        solver.set(timeout=allowance_ms);write(folder/'opened.json',{'sequence':sequence,'algorithm_elapsed_seconds':time.perf_counter()-started,'timeout_ms':allowance_ms,'threads':1,'random_seed':0,'initial_value_count':70,'model_sha256':h});check_start=time.perf_counter();status=solver.check();elapsed=time.perf_counter()-check_start;status_text=str(status);statistics=solver.statistics();write(folder/'statistics.json',{k:statistics.get_key_value(k) for k in statistics.keys()});record={'sequence':sequence,'status':status_text,'formula_sha256':h,'assertions':len(assertions),'mode_cases':len(cases),'timeout_ms':allowance_ms,'returned_check_seconds':elapsed,'soft_overrun_seconds':max(0.,elapsed-allowance_ms/1000),'has_solution':status==z3.sat,'reason_unknown':solver.reason_unknown() if status==z3.unknown else None}
        if status!=z3.sat:reason='NO_CANDIDATE_'+status_text.upper();write(folder/'result.json',record);records.append(record);break
        model=solver.model();(folder/'z3-model.txt').write_text(model.sexpr(),encoding='utf-8',newline='\n');values={};raw={}
        for name,sort in decls.items():
            value=model.eval(z3.Bool(name) if sort=='Bool' else z3.Real(name),model_completion=True)
            if sort=='Bool':assert z3.is_true(value) or z3.is_false(value);values[name]=z3.is_true(value);raw[name]=values[name]
            else:assert z3.is_rational_value(value);values[name]=F(value.numerator_as_long(),value.denominator_as_long());raw[name]=str(values[name])
        write(folder/'assignment-rational.json',raw);assert all(evaluate(a,values) for a in assertions);write(folder/'assignment-audit.json',{'passed':True,'variables':len(values),'exact_rational_assertions':len(assertions),'all25_presence_true':all(values[it['presence']] for it in mp['items'])})
        source_allowance=deadline-time.perf_counter()
        if source_allowance<=0:reason='ALGORITHM_DEADLINE_BEFORE_SOURCE';write(folder/'result.json',record);records.append(record);break
        try:
            proc=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(ROOT/'output/check_h5_rational_source_candidate_20261028.py'),str(folder)],cwd=ROOT,capture_output=True,timeout=source_allowance);(folder/'source-stdout.txt').write_bytes(proc.stdout);(folder/'source-stderr.txt').write_bytes(proc.stderr);assert proc.returncode==0,proc.stderr.decode()
        except subprocess.TimeoutExpired as e:
            (folder/'source-stdout.txt').write_bytes(e.stdout or b'');(folder/'source-stderr.txt').write_bytes(e.stderr or b'');reason='ALGORITHM_DEADLINE_IN_SOURCE';write(folder/'result.json',record);records.append(record);break
        source=load(folder/'source-audit.json');record.update({'source_valid':source['valid'],'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'maximum_anchor_float_error_mm':source['maximum_anchor_float_error_mm'],'iteration_seconds':time.perf_counter()-iteration_start});write(folder/'result.json',record);records.append(record)
        if source['valid']:valid=True;reason='SOURCE_VALID66';break
        assert source['stock_failures']==0;bykey={(it['family'],it['copy_index']):it['index'] for it in mp['items']};pending=[]
        for failure in source['pairs']:
            if failure['passed']:continue
            a,b=map(tuple,failure['keys']);assert a in bykey and b in bykey,'fixed-owner failure contradicts source-free geometry';li,ri=sorted([bykey[a],bykey[b]]);ma,mb=[next(o['mode'] for o in mp['items'][i]['options'] if values[o['selector']]) for i in [li,ri]];case=(li,ri,ma,mb);assert case not in known,'source failure contradicts an existing exact case';pending.append(case)
        pending=sorted(set(pending));assert pending;write(folder/'next-mode-cases.json',[list(v) for v in pending]);previous=assertions
    elapsed=time.perf_counter()-started;write(OUT/'result.json',{'reason':reason,'closed':True,'algorithm_seconds':elapsed,'algorithm_soft_overrun_seconds':max(0.,elapsed-60),'distinct_checks':len(records),'records':records,'source_full66_verified':valid,'native_calls':0,'actual_or_global_infeasibility_claimed':False,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');started=time.perf_counter();write(OUT/'budget.json',{'algorithm_seconds':60,'shared_seconds':90,'maximum_distinct_checks':32,'maximum_seconds_per_check':15,'retry_permitted':False,'incremental_single_solver':True})
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-z3-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90);(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);process={'seconds':time.perf_counter()-started,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds':time.perf_counter()-started,'timeout':True}
    write(OUT/'process.json',process);print(process);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final result; sequence is closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
