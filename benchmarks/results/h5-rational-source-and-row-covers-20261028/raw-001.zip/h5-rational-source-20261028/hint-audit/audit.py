"""Audit soft initial values from the source56 control without checking satisfiability."""
from pathlib import Path
from hashlib import sha256
import json,shutil
import z3
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';OUT=BASE/'hint-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');mp=load(BASE/'model/mapping.json');control={(r['family'],r['copy_index']):r for r in load(BASE/'control.json')};hints={}
for item in mp['items']:
    hints[item['presence']]=True;known=control.get((item['family'],item['copy_index']))
    if known:
        hints[item['x']],hints[item['y']]=map(str,known['anchor_um'])
        for o in item['options']:hints[o['selector']]=o['mode']==known['mode']
assert len(hints)==70;s=z3.SolverFor('QF_LRA');asts=z3.parse_smt2_file(str(BASE/'model/model.smt2'));s.add(asts);before=list(s.assertions())
for name,value in hints.items():s.set_initial_value(z3.Bool(name) if isinstance(value,bool) else z3.Real(name),z3.BoolVal(value) if isinstance(value,bool) else z3.RealVal(value))
after=list(s.assertions());assert len(before)==len(after)==352 and all(a.eq(b) for a,b in zip(before,after));write(BASE/'initial-values.json',hints)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'model/model.smt2',BASE/'model/mapping.json',BASE/'control.json',BASE/'initial-values.json',BASE/'dependency/runtime-bindings.json']}})
write(OUT/'checks.json',{'passed':True,'initial_values':70,'required_presence_preferences':25,'source_control_cog_coordinates':30,'source_control_cog_mode_preferences':15,'assertions_unchanged_after_hints':True,'hints_do_not_force_coordinates':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
