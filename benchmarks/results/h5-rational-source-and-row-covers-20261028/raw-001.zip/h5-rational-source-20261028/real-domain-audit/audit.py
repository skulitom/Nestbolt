"""Prove the retained coefficient-error bounds hold for real, not just integer, anchors."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';OLD=ROOT/'output/h5-mixed25-lazy-source-20261028';OUT=BASE/'real-domain-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();assert load(OLD/'audit/checks.json')['passed'];planes=cells=domains=0;minimum=None;inputs=[OLD/'audit/plan.json',OLD/'audit/checks.json',ROOT/'output/audit_h5_mixed25_lazy_geometry_20261028.py']
for folder in ['free','relative']:
    for p in sorted((BASE/folder).glob('*.json')):
        assert digest(p)==digest(OLD/folder/p.name);inputs += [p,OLD/folder/p.name];domains+=1
        for cell in load(p)['cells']:
            vv=[tuple(F(str(c)) for c in v) for v in cell['geometry']['coordinates'][0][:-1]];assert len(vv)==len(cell['halfplanes']);cells+=1
            for (u,v),(a,b,c) in zip(zip(vv,vv[1:]+vv[:1]),cell['halfplanes']):
                nx,ny=u[1]-v[1],v[0]-u[0];norm=max(abs(nx),abs(ny));nx/=norm;ny/=norm;assert all(nx*(w[0]-u[0])+ny*(w[1]-u[1])>=0 for w in vv)
                assert a==round(nx*10**9) and b==round(ny*10**9);target=10**12*(nx*u[0]+ny*u[1]);error=abs(F(a)-nx*10**9)*1600000+abs(F(b)-ny*10**9)*3100000;margin=F(c)-target-error;assert margin>0;minimum=margin if minimum is None else min(minimum,margin);planes+=1
assert domains==77 and cells==1138 and planes==4129
write(OUT/'proof.json',{'statement':'For every real x,y with |x|<=1600000 and |y|<=3100000 micrometres, the coefficient-error dot product is bounded by |A-1e9*nx|*1600000+|B-1e9*ny|*3100000. Since C is strictly greater than the exact edge target plus this bound, A*x+B*y>=C implies the strict inward-edge inequality for every real point. No integrality is used. Absolute anchor bounds0..1500000 and0..3000000, and all pair differences, lie inside these limits. Convexity makes all inward edges sufficient for cell containment. Previously audited source-free and obstacle geometry is byte-identical.','minimum_strict_margin_rational':str(minimum),'source_geometry_unchanged':True,'integers_not_required':True})
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_bound_domains':domains,'convex_cells':cells,'exact_halfplane_bounds':planes,'valid_for_all_reals_in_bounds':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
