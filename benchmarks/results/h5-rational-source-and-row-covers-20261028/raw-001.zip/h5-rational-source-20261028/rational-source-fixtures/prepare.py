"""Exercise rational decoding and float geometry on saved rejected, non-solver fixtures."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';OLD=ROOT/'output/h5-mode-collision-source-20261028';OUT=BASE/'rational-source-fixtures';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');mp=load(BASE/'model/mapping.json');summaries=[]
for name,source,sx,sy in [('integer-00','00',F(0),F(0)),('integer-01','01',F(0),F(0)),('submicrometre-00','00',F(1,3),F(1,7))]:
    folder=OUT/name;folder.mkdir();shutil.copyfile(BASE/'model/mapping.json',folder/'mapping.json');poses=load(OLD/f'search/{source}/selected-poses.json');bykey={(r['family'],r['copy_index']):r for r in poses};values={}
    for item in mp['items']:
        r=bykey[item['family'],item['copy_index']];values[item['presence']]=True;values[item['x']]=str(F(r['anchor_um'][0])+sx);values[item['y']]=str(F(r['anchor_um'][1])+sy)
        for o in item['options']:values[o['selector']]=o['mode']==r['mode']
    write(folder/'assignment-rational.json',values);write(folder/'purpose.json',{'not_a_solver_candidate':True,'not_a_valid_layout':True,'source_saved_candidate':source,'common_mover_shift_um':[str(sx),str(sy)],'solver_calls':0})
    p=subprocess.run([sys.executable,str(ROOT/'output/check_h5_rational_source_candidate_20261028.py'),str(folder)],cwd=ROOT,capture_output=True,timeout=30);(folder/'stdout.txt').write_bytes(p.stdout);(folder/'stderr.txt').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode();a=load(folder/'source-audit.json');assert not a['valid'] and a['stock_failures']==0 and a['pair_failures']=={'00':20,'01':48}[source]
    if sx==sy==0:assert load(folder/'candidate66.json')==load(OLD/f'search/{source}/candidate66.json')
    else:assert F(a['maximum_anchor_float_error_um_rational'])>0 and a['maximum_anchor_float_error_mm']<1e-9
    summaries.append({'fixture':name,'source_pair_failures':a['pair_failures'],'source_stock_failures':0,'originals':66,'holes':90,'hole_vertices':10026,'maximum_anchor_float_error_mm':a['maximum_anchor_float_error_mm'],'source_rejection_preserved':True})
inputs=[BASE/'plan.json',BASE/'model/mapping.json',ROOT/'output/check_h5_rational_source_candidate_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']+[OLD/f'search/{n}/selected-poses.json' for n in ['00','01']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'fixtures':summaries,'all_rejected_as_expected':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
