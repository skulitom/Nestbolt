"""Verify the sole closed timeout, formula identity and unchanged source acceptance gates."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from h5_rational_formula_reader_20261028 import inspect
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';OUT=BASE/'response-audit';SEARCH=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,BASE/'model',BASE/'engine-input-audit',BASE/'hint-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for n,h in load(SEARCH/'opened.json')['inputs'].items():assert digest(ROOT/n)==h,n
for n,h in load(BASE/'dependency/runtime-bindings.json').items():assert digest(ROOT/n)==h,n
r=load(SEARCH/'result.json');process=load(SEARCH/'process.json');assert r['closed'] and r['reason']=='NO_CANDIDATE_UNKNOWN' and r['distinct_checks']==len(r['records'])==1 and not r['source_full66_verified'] and not r['actual_or_global_infeasibility_claimed'] and r['native_calls']==0
assert process['exit_code']==0 and not process['timeout'] and process['seconds']<90 and r['algorithm_seconds']<60 and r['algorithm_soft_overrun_seconds']==0
assert sorted(p.name for p in SEARCH.iterdir() if p.is_dir())==['00'];folder=SEARCH/'00';row=load(folder/'result.json');opened=load(folder/'opened.json');stats=load(folder/'statistics.json');assert row==r['records'][0] and row['status']=='unknown' and row['reason_unknown']=='timeout' and not row['has_solution'];assert row['timeout_ms']==opened['timeout_ms']==15000 and opened['threads']==1 and opened['random_seed']==0 and opened['initial_value_count']==70 and stats['num checks']==1
assert row['soft_overrun_seconds']==max(0.,row['returned_check_seconds']-15);assert digest(folder/'model.smt2')==digest(BASE/'model/model.smt2')==row['formula_sha256'];assert digest(folder/'mapping.json')==digest(BASE/'model/mapping.json') and digest(folder/'cases.json')==digest(BASE/'model/cases.json')
assert not any((folder/n).exists() for n in ['assignment-rational.json','z3-model.txt','source-audit.json','next-mode-cases.json'])
free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)};check,*_=inspect((folder/'model.smt2').read_text(),load(folder/'mapping.json'),load(BASE/'remaining25.json'),load(BASE/'modes.json'),free,relative,load(folder/'cases.json'),load(BASE/'control.json'))
assert check['passed'] and check['real_coordinates']==50 and check['boolean_variables']==78 and check['assertions_verified']==352 and check['mode_cases']==111
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'model/checks.json',BASE/'engine-input-audit/checks.json',BASE/'dependency/installed.json',BASE/'dependency/runtime-bindings.json',SEARCH/'opened.json',SEARCH/'result.json',SEARCH/'process.json',folder/'model.smt2',folder/'mapping.json',folder/'cases.json',folder/'result.json',folder/'opened.json',folder/'statistics.json']}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'status':'unknown','reason_unknown':'timeout','distinct_checks':1,'formula_reaudited':check,'returned_check_seconds':row['returned_check_seconds'],'solve_soft_overrun_seconds':row['soft_overrun_seconds'],'algorithm_seconds':r['algorithm_seconds'],'shared_seconds':process['seconds'],'source_solver_candidates':0,'no_candidate_stop_obeyed':True,'no_closed_solver_restart':True,'unused_budget_not_reassigned':True,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
