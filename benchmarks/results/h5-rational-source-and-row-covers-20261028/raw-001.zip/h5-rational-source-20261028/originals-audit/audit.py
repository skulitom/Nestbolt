"""Independent saved original-ring validation for every conversion fixture and certificate."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';OUT=BASE/'originals-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');plan=load(BASE/'plan.json');expected=[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])];summaries=[];inputs=[BASE/'plan.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5_legacy64_source_readback.py']
for name,failures in [('rational-source-fixtures/integer-00',20),('rational-source-fixtures/integer-01',48),('rational-source-fixtures/submicrometre-00',20),('relaxation-witness',68)]:
    folder=BASE/name;r=audit(job,load(folder/'candidate66.json'),plan['source_stocks'],plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected);saved=load(folder/'source-audit.json');assert all(saved[k]==v for k,v in r.items()) and not r['valid'] and r['pair_failures']==failures and r['stock_failures']==0 and r['cutouts']==90 and r['hole_vertices']==10026;write(OUT/(name.replace('/','-')+'.json'),r);summaries.append({'case':name,'originals':66,'pairs':1380,'stock_edges':264,'source_pair_failures':failures,'source_stock_failures':0,'holes':90,'hole_vertices':10026,'valid':False});inputs += [folder/'candidate66.json',folder/'source-audit.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'cases':summaries,'all_four_invalid_layouts_preserved':True,'new_valid_source66_count':0,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
