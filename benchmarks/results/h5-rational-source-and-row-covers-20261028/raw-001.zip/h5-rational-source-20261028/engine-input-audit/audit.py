"""Check Z3's parsed AST exactly, without invoking any satisfiability check."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,shutil,time
import z3
from h5_rational_formula_reader_20261028 import parse
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';OUT=BASE/'engine-input-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();assert load(BASE/'model/checks.json')['passed'] and load(BASE/'real-domain-audit/checks.json')['passed']
for n,h in load(BASE/'dependency/runtime-bindings.json').items():assert digest(ROOT/n)==h,n
text=(BASE/'model/model.smt2').read_text();raw=parse(text);expected=[r[1] for r in raw if r[0]=='assert'];decls={r[1]:r[3] for r in raw if r[0]=='declare-fun'};asts=z3.parse_smt2_string(text);assert len(asts)==len(expected);names={};nodes=0
ops={z3.Z3_OP_AND:'and',z3.Z3_OP_OR:'or',z3.Z3_OP_NOT:'not',z3.Z3_OP_IMPLIES:'=>',z3.Z3_OP_EQ:'=',z3.Z3_OP_LE:'<=',z3.Z3_OP_GE:'>=',z3.Z3_OP_ADD:'+',z3.Z3_OP_MUL:'*',z3.Z3_OP_UMINUS:'-'}
def tree(a):
    global nodes
    nodes+=1
    if z3.is_rational_value(a):
        n,d=a.numerator_as_long(),a.denominator_as_long();assert d==1;return str(n) if n>=0 else ['-',str(-n)]
    if z3.is_const(a) and a.decl().kind()==z3.Z3_OP_UNINTERPRETED:
        name=str(a.decl().name());sort='Bool' if z3.is_bool(a) else 'Real' if z3.is_real(a) else None;assert sort==decls[name];names[name]=sort;return name
    op=ops[a.decl().kind()];return [op,*[tree(c) for c in a.children()]]
for actual,want in zip(asts,expected):assert tree(actual)==want
assert names==decls;s=z3.SolverFor('QF_LRA');ds=s.param_descrs();available=[ds.get_name(i) for i in range(ds.size())];assert all(k in available for k in ['timeout','random_seed','threads']);s.set(timeout=15000,random_seed=0,threads=1);s.add(asts);assert len(s.assertions())==352
for actual,want in zip(s.assertions(),expected):assert tree(actual)==want
write(OUT/'parameters-reviewed.json',{'logic':'QF_LRA','timeout_ms_per_check_maximum':15000,'random_seed':0,'threads':1,'parameters_available':True,'no_check_called':True})
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'model/model.smt2',BASE/'model/mapping.json',BASE/'model/checks.json',BASE/'real-domain-audit/checks.json',BASE/'dependency/installed.json',BASE/'dependency/runtime-bindings.json',ROOT/'output/h5_rational_formula_reader_20261028.py']}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'z3_version':z3.get_version_string(),'assertions_verified_before_and_after_add':352,'AST_nodes_walked':nodes,'declared_variables_verified':len(decls),'exact_operator_and_constant_trees_match':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
