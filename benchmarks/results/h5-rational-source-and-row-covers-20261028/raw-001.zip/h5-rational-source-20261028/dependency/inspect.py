"""Read official package-index metadata before pinning a local experiment dependency."""
from pathlib import Path
from datetime import datetime,timezone
from urllib.request import urlopen
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';OUT=BASE/'dependency';OUT.mkdir(parents=True);shutil.copyfile(__file__,OUT/'inspect.py')
url='https://pypi.org/pypi/z3-solver/json'
with urlopen(url,timeout=30) as r:data=r.read()
(OUT/'pypi-project.json').write_bytes(data);j=json.loads(data);info=j['info'];wheels=[{k:u.get(k) for k in ['filename','size','url','digests','requires_python','upload_time_iso_8601','yanked']} for u in j['urls'] if u['filename'].endswith('win_amd64.whl')]
record={'utc':datetime.now(timezone.utc).isoformat(),'url':url,'name':info['name'],'version':info['version'],'license':info.get('license'),'license_expression':info.get('license_expression'),'project_urls':info.get('project_urls'),'requires_dist':info.get('requires_dist'),'windows_wheels':wheels,'solver_calls':0}
with (OUT/'index-review.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
