"""Read exact rational anchors separately from their float-converted original geometry."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rational-source-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    started=time.perf_counter();out=Path(sys.argv[1]).resolve();assert out.is_relative_to(BASE.resolve());plan=load(BASE/'plan.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');rows=load(BASE/'fixed41.json');modes=load(BASE/'modes.json');mp=load(out/'mapping.json');raw=load(out/'assignment-rational.json');values={k:v if isinstance(v,bool) else F(v) for k,v in raw.items()};poses=[];errors=[]
    for item in mp['items']:
        assert values[item['presence']] is True;chosen=[o['mode'] for o in item['options'] if values[o['selector']]];assert len(chosen)==1;m=modes[chosen[0]];x,y=values[item['x']],values[item['y']];assert isinstance(x,F) and isinstance(y,F);fx,fy=float(x),float(y);errors += [abs(F.from_float(fx)-x),abs(F.from_float(fy)-y)]
        rows.append({'part_id':item['family'],'copy_index':item['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],'translation':[fx/1000+m['source_translation_offset'][0],fy/1000+m['source_translation_offset'][1]],'mirrored':m['mirrored']}});poses.append({'family':item['family'],'copy_index':item['copy_index'],'mode':m['index'],'anchor_um_rational':[str(x),str(y)],'anchor_um_float':[fx,fy]})
    expected=[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])];assert len(rows)==len(expected)==66;result=audit(job,rows,plan['source_stocks'],plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected);assert result['cutouts']==90 and result['hole_vertices']==10026 and result['same_sheet_pairs']==1380
    write(out/'candidate66.json',rows);write(out/'selected-poses.json',poses);write(out/'source-audit.json',{**result,'seconds':time.perf_counter()-started,'candidate_sha256':digest(out/'candidate66.json'),'maximum_anchor_float_error_um_rational':str(max(errors)),'maximum_anchor_float_error_mm':float(max(errors)/1000),'exact_rational_formula_check_is_separate':True});print({k:v for k,v in result.items() if k not in ['pairs','stock']})
if __name__=='__main__':main()
