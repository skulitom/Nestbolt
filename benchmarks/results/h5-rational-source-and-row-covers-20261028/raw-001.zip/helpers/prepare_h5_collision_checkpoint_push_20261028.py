"""Create a fresh normal push guard for the reviewed collision-generation checkpoint."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='571738d8c229781092d8f8a3ebf1b77cef56604a'
source=(ROOT/'output/push_h5_lazy_source_checkpoints_20261028.py').read_text(encoding='utf-8')
changes={"output/h5-lazy-source-main-sync-20261028":"output/h5-collision-generation-main-sync-20261028","OLD='b699d1c1845828fe1bfaa675804b32fc4a894528';NEW='a0d6f9af9c1e577263e138c3b2993f2c17591ec7'":"OLD='a0d6f9af9c1e577263e138c3b2993f2c17591ec7';NEW='571738d8c229781092d8f8a3ebf1b77cef56604a'","['benchmarks/results/h5-mixed25-outer-covers-20261028','benchmarks/results/h5-mixed25-lazy-source-20261028']":"['benchmarks/results/h5-source-collision-generation-20261028']",'40748909850':'40753599821'}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
with (ROOT/'output/push_h5_collision_checkpoint_20261028.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'head':head,'prior_CI':40753599821,'normal_atomic_push_helper_prepared':True})
