"""Install only the verified local MIT wheel into a fresh experiment environment."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-rational-source-20261028/dependency';ENV=ROOT/'.cache/h5-z3-cpython-venv';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not ENV.exists();wheel=load(OUT/'wheel-checks.json');release=load(OUT/'upstream-release.json');assert wheel['version']=='5.3.2.0' and release['tag_name']=='z3-5.3.2';assert digest(ROOT/wheel['wheel_path'])==wheel['sha256'];notice=(OUT/'upstream-tag-LICENSE.txt').read_text(encoding='utf-8');assert 'MIT License' in notice and 'Copyright (c) Microsoft Corporation' in notice
assert notice.strip()==(ROOT/'output/h5-mode-collision-source-20261028/research/z3-LICENSE.txt').read_text(encoding='utf-8').strip()
steps=[('create-venv',[str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),'-m','venv',str(ENV)]),('install-wheel',[str(ENV/'Scripts/python.exe'),'-m','pip','install','--no-index','--no-deps','--disable-pip-version-check',str(ROOT/wheel['wheel_path'])])]
for name,cmd in steps:
    p=subprocess.run(cmd,cwd=ROOT,capture_output=True,timeout=90);(OUT/f'{name}-stdout.txt').write_bytes(p.stdout);(OUT/f'{name}-stderr.txt').write_bytes(p.stderr);assert p.returncode==0,(name,p.stderr.decode())
site=ENV/'Lib/site-packages';notice_path=site/'z3_solver-5.3.2.0.dist-info/LICENSE.upstream.txt';shutil.copyfile(OUT/'upstream-tag-LICENSE.txt',notice_path)
p=subprocess.run([str(ENV/'Scripts/python.exe'),'-c','import json,sys,z3; print(json.dumps({"python":sys.version,"z3_version":z3.get_version_string(),"z3_file":z3.__file__}))'],cwd=ROOT,capture_output=True,timeout=15);(OUT/'import-stdout.txt').write_bytes(p.stdout);(OUT/'import-stderr.txt').write_bytes(p.stderr);assert p.returncode==0;runtime=json.loads(p.stdout);assert runtime['z3_version']=='5.3.2'
files=[p for p in (site/'z3').rglob('*') if p.is_file() and p.suffix in ['.py','.dll','.pyd']]+[notice_path,site/'z3_solver-5.3.2.0.dist-info/METADATA'];inventory={p.relative_to(ROOT).as_posix():digest(p) for p in files};write(OUT/'runtime-bindings.json',inventory)
write(OUT/'installed.json',{'utc':datetime.now(timezone.utc).isoformat(),'environment':ENV.relative_to(ROOT).as_posix(),'wheel_sha256':wheel['sha256'],'wheel_bytes':wheel['bytes'],'upstream_tag':release['tag_name'],'upstream_license_sha256':digest(OUT/'upstream-tag-LICENSE.txt'),'wheel_contains_no_separate_license_file':True,'full_upstream_notice_preserved_locally':notice_path.relative_to(ROOT).as_posix(),'notice_source_url':'https://api.github.com/repos/Z3Prover/z3/contents/LICENSE.txt?ref=z3-5.3.2','installed_with_no_index_and_no_dependencies':True,'runtime':runtime,'runtime_files_hashed':len(files),'solver_calls':0,'production_dependency_changed':False});print(load(OUT/'installed.json'))
