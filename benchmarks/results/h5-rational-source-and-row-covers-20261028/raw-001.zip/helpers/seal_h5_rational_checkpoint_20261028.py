"""Preserve the closed real-arithmetic trial, SAT certificates and audited row study."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-rational-source-20261028';PUB=BASE/'publication'
NAME='h5-rational-source-and-row-covers-20261028';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='571738d8c229781092d8f8a3ebf1b77cef56604a' and not git('diff','HEAD','--name-only')
audits=['model','real-domain-audit','engine-input-audit','hint-audit','rational-source-fixtures','response-audit','relaxation-witness','relaxation-witness/cp-audit','relaxation-witness/engine-audit','originals-audit','row-cover-study/audit','row-cover-study/section-bound/audit']
assert all(load(BASE/a/'checks.json')['passed'] for a in audits)
search=load(BASE/'search/result.json');response=load(BASE/'response-audit/checks.json');witness=load(BASE/'relaxation-witness/checks.json');study=load(BASE/'row-cover-study/audit/checks.json');bound=load(BASE/'row-cover-study/section-bound/audit/checks.json')
assert search['closed'] and search['distinct_checks']==1 and search['reason']=='NO_CANDIDATE_UNKNOWN' and not search['source_full66_verified']
assert witness['source_pair_failures']==68 and witness['inactive_mode_cases']==90 and not witness['source_valid']
assert study['row_cover_components']==58 and study['all66_originals_accounted_once'] and bound['section_patterns_verified']==9114 and not bound['declared_cover_model_excluded']
prior=load(ROOT/'benchmarks/results/h5-source-collision-generation-20261028/publication-review.json')
production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main==head
receipt=load(ROOT/'output/h5-collision-generation-main-sync-20261028/receipt.json');assert receipt['new_main']==head and receipt['prior_main_all6_pass'] and receipt['normal_atomic_fast_forward']
jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6
passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==5 and live==['checks (windows-latest)']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts
    members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-collision-generation-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['inspect_h5_z3_dependency_20261028.py','download_h5_z3_wheel_20261028.py','install_h5_z3_dependency_20261028.py','h5_rational_formula_builder_20261028.py','h5_rational_formula_reader_20261028.py','h5_rational_z3_ast_20261028.py','prepare_h5_rational_model_20261028.py','audit_h5_rational_real_domains_20261028.py','audit_h5_rational_engine_input_20261028.py','prepare_h5_rational_hints_20261028.py','check_h5_rational_source_candidate_20261028.py','prepare_h5_rational_source_fixtures_20261028.py','run_h5_rational_generation_20261028.py','audit_h5_rational_closed_response_20261028.py','construct_h5_rational_relaxation_witness_20261028.py','audit_h5_relaxation_witness_cp_20261028.py','audit_h5_rational_witness_engine_20261028.py','audit_h5_rational_originals_20261028.py','study_h5_joint_row_covers_20261028.py','audit_h5_joint_row_cover_study_20261028.py','derive_h5_row_cover_section_bound_20261028.py','audit_h5_row_cover_section_bound_20261028.py','prepare_h5_collision_checkpoint_push_20261028.py','push_h5_collision_checkpoint_20261028.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_rational_archive_20261028.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and digest(q)==h,n
            assert '.cache' not in q.parts,('external dependency should be hash-bound, not implicitly republished',n)
            bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies={'model/checks.json':'model-audit.json','real-domain-audit/checks.json':'real-domain-audit.json','engine-input-audit/checks.json':'engine-input-audit.json','response-audit/checks.json':'response-audit.json','search/result.json':'search-result.json','relaxation-witness/checks.json':'satisfiable-relaxation-certificate.json','relaxation-witness/cp-audit/checks.json':'cp-certificate-audit.json','relaxation-witness/engine-audit/checks.json':'z3-certificate-audit.json','originals-audit/checks.json':'originals-audit.json','row-cover-study/audit/checks.json':'row-cover-audit.json','row-cover-study/section-bound/audit/checks.json':'section-bound-audit.json','row-cover-study/section-bound/audit/proof.json':'section-bound-proof.json','dependency/installed.json':'dependency-review.json'}
for a,b in copies.items():shutil.copyfile(BASE/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'previous_checkpoint_pushed':True,'prior_main_CI':40753599821,'prior_main_all6_pass':True,'main_CI':40758320213,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'production_dependencies_changed':False,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
next_action='The single Z3 QF_LRA sequence is CLOSED UNKNOWN after a timeout; do not rerun, reseed, extend or transfer its unused budget. Its50 real XY variables,78 Boolean variables,352 assertions and111 mode cases are fully audited. Returned15.579044s with0.579044s solve overrun;17.218299s algorithm17.460927s shared. A separate constructive exact assignment proves both this relaxation and the closed CP final relaxation satisfiable, but it has68 original-source collisions:90 mode-specific cases are inactive,21 cog/cog cases active. This is no full-layout success. Preserve all failures and the valid64. Geometry-only study shows a five-cog phase7 row at258.9mm pitch can use58 disjoint conservative hull-cover rectangles; three rows plus18 frames6 brackets12 inserts make39 movable blocks representing all51 first-sheet originals, retaining short15. Necessary cover area leaves65995.458514mm2 slack. One bounded LP plus exact rational independent audit of9114 section patterns gives2978.159550986526mm span within2987mm stock; only8.840449013474029mm slack, no feasibility proof. This bound assumes covers contained in the stated stock rectangle; any future different stock treatment needs a correctly scoped bound. Next construct and independently audit a compact whole-first-sheet model with all39 blocks mandatory, mode-independent cover nonoverlap, original IDs and hole preservation, honest partial positive/negative controls, legal modes and original-source stock checks. All36 orthogonal originals and all3 cog rows must move; do not freeze the old mixed26 core or silently restore integer-source cut assumptions. Cover bounds at stock edges must be explicit: source geometry is the final stock authority, and outward clearance covers can impose a declared conservative restriction if required inside the same rectangle. Retain exact source transforms and row internal gap evidence. Freeze one60s algorithm90s shared budget before any new packing solve, audit every returned assignment, then original66 and native/material only if truly valid. If geometry or stronger necessary bounds exclude the chosen covers, stop that construction and use a substantively different source-valid cover/formulation, not another seed. Common-line PIH remainsOFF. H2 original gate and22 reserved vectors remain unchanged. Main571738d8 contains the prior collision-generation checkpoint; CI40758320213 snapshot has5passes and Windows checks live. Wait all6 with fresh remote/live-run guards before normal atomic push. Production/README/release unchanged; H2/H5 open60%.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'independent_audit_groups':len(audits),'closed_packing_sequences':1,'distinct_symbolic_solver_checks':1,'source_solver_candidates':0,'both_closed_relaxations_constructively_satisfiable':True,'certificate_source_collisions':68,'source_valid66_count':0,'row_cover_components':58,'section_patterns_verified':9114,'section_bound_excludes_cover_model':False,'original_source_feasibility_excluded':False,'valid64_preserved':True,'remaining_necessary_allocations':444,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=f'''# Real arithmetic and compact cog-row covers — 2026-10-28

The real-arithmetic trial is closed after one timeout. A separate exact
certificate proves that both closed relaxations have satisfying assignments,
but that assignment has **68 physical collisions**. No valid full layout or
H5 completion follows. H2/H5 remain open at **60% milestone weight**.

## Pinned local dependency and formula

[Z3 5.3.2](https://github.com/Z3Prover/z3/releases/tag/z3-5.3.2) was installed
in an isolated local environment from the verified Windows wheel for
`z3-solver==5.3.2.0`. The wheel is 16,870,592 bytes with SHA-256
`ea23baa055caf4a470ee6335140dfd617f4082750161a1fdbf23d24259f385e3`.
The full upstream MIT notice, official metadata, installation receipt and
hashes of 23 runtime files are preserved. The wheel lacked a separate notice;
the verified upstream notice was copied into its local distribution directory.
No production dependency or lockfile changed. The archive records how to
reproduce this dependency; it does not republish the virtual environment.

The QF_LRA formula uses **50 real coordinates, 78 Boolean variables and 352
assertions**. It keeps all 25 remaining originals mandatory around the same
fixed 41 and preserves all **111 observed owner/mode cases**. Independent
reading verifies every formula field, legal mode, free-cell disjunction,
relative-cell condition and ordering constraint. The partial 56-part control
fails exactly ten mandatory assertions; a separate control-only formula
negating those ten presences passes. It is not a complete-layout witness.

An exact rational error bound verifies all **4,129 halfplanes in 1,138 cells
across 77 domains** for continuous coordinates in their declared bounds.
The source audit does not depend on integer coordinates. Z3's parsed assertion
trees are checked before and after adding them: **660,958 AST nodes** match
the independent reader. Seventy initial-value preferences leave assertions
unchanged. Separate conversion fixtures retain their expected 20, 48 and 20
collision failures, including a submicrometre rational displacement with a
maximum anchor conversion error of about **1.33e-13 mm**.

## Closed response and exact SAT certificate

One frozen sequence allows at most 60 seconds of total algorithm work,
90 seconds shared, and 15 seconds per symbolic check, with one thread and seed
zero. Its first check returns **UNKNOWN / timeout** after **15.579044 s**.
The **0.579044 s soft overrun** is preserved. Total time is **17.218299 s
algorithm / 17.460927 s shared**. The stop-after-no-candidate rule closes the
sequence immediately; unused time is not reassigned. No model assignment,
source candidate or native validation is produced by this solve.

A subsequent construction uses no search: retain the 15 control cog poses,
put the three brackets in legal mode 3, and the seven inserts in legal mode 10.
Those repeated poses satisfy all **352 assertions exactly**. Only **21 cog/cog
cases are active**; the other **90 cases** concern different selected modes
and therefore impose no separation. Substitution and ground simplification
confirm all Z3 assertions without a symbolic check. An independent assignment
reader also verifies **all 5,871 variables and 20,824 constraints** of the
closed CP relaxation using this same construction.

Thus both relaxations are demonstrably satisfiable despite their UNKNOWN
responses. This is a certificate about the relaxed constraints, not physical
packing. Original-source readback correctly rejects it for **68 collisions**.
All four diagnostic layouts retain **66 originals, 1,380 pair checks, 264 stock
edges, 90 holes and 10,026 hole vertices**, with no stock failures. No original
geometry is removed to improve those results.

## Geometry study for the next construction

The next approach would move the whole first sheet: **18 frames, six brackets,
12 inserts and three rigid rows of five cogs**. These 39 blocks represent all
51 originals on that sheet; the verified short-sheet 15 remain fixed. The old
26-part rectangular core would no longer be fixed. Original identities and
holes remain intact, and common-line part-in-hole placement remains off.

Each row uses the original phase-7-degree cogs at a **258.9 mm pitch**, with an
independently checked internal minimum gap of **0.230499 mm**. The convex hull
of the row, expanded by a 112-micrometre square and covered with 5 mm slabs,
needs **58 disjoint rectangles**. Independent original-vertex reconstruction
checks the hull and clearance-disc coverage. This is a conservative cover of
the originals, not a replacement for final source checks.

The declared covers total **4,375,673.541486 mm²** in a usable
**4,441,669 mm²** rectangle, leaving **65,995.458514 mm²**. A stronger bound
enumerates **9,114 horizontal-section patterns** across all 16 orthogonal
modes and the row profile. One bounded linear program proposes nonnegative
weights; exact rational normalization and an independent sweep/enumerator
verify a required span of at least **2,978.159551 mm**. Compared with the
2,987 mm rectangle, only **8.840449 mm** remains. Neither bound excludes this
cover model, and neither proves that it fits.

This section bound applies when the expanded covers themselves stay inside
that rectangle. A future model must state its stock treatment explicitly:
requiring all covers inside is a conservative restriction, while source stock
checks remain authoritative. The study has built no new packing model or
called a packing solver. Next steps are a complete serialized-model audit,
honest partial controls, one newly frozen budget and full original-source
validation before any native/material claim.

The previous collision-generation checkpoint was pushed normally and
atomically to main **571738d8** after all six prior checks passed.
[CI 40758320213](https://github.com/skulitom/Nestbolt/actions/runs/40758320213)
has five passing jobs and the Windows check still live in this snapshot.
This checkpoint waits for all six before a fresh guarded push. Production,
READMEs and upstream heads/releases are unchanged. The valid 64-part layout,
444 necessary allocations, original H2 gate and 22 unopened vectors remain
preserved. No new release qualifies.

Evidence: [formula audit]({NAME}/model-audit.json),
[real-domain proof checks]({NAME}/real-domain-audit.json),
[closed response]({NAME}/response-audit.json),
[SAT certificate]({NAME}/satisfiable-relaxation-certificate.json),
[CP certificate audit]({NAME}/cp-certificate-audit.json),
[independent original readback]({NAME}/originals-audit.json),
[row-cover audit]({NAME}/row-cover-audit.json),
[exact section bound]({NAME}/section-bound-audit.json),
[bound scope and proof]({NAME}/section-bound-proof.json),
[next step]({NAME}/next-step.json), [raw manifest]({NAME}/raw-manifest.json).
The verified archive holds {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in
{archive['archive_bytes']:,} compressed bytes, including all failed results,
formula and engine audits, dependency notices, source rings, certificates,
study data, helpers and recursively bound source inputs.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 real arithmetic and row-cover study, 2026-10-28:** [the evidence]({link})
closes one Z3 check as UNKNOWN/timeout at 15.579044 s, preserving its 0.579044 s
overrun. A separate exact assignment proves both closed relaxations satisfiable
but fails original-source validation with 68 collisions; 90 mode-specific cases
are inactive. All mandatory originals, formula fields, continuous halfplanes,
conversion fixtures and source rings are audited. A geometry-only alternative
uses three five-cog rows of 58 cover rectangles each and moves all 51 first-sheet
originals as 39 blocks. Exact verification of 9,114 section patterns leaves only
8.840449 mm above the necessary height bound; it proves neither fit nor exclusion.
No new packing model/solve follows yet. Next audit the complete movable-sheet
model, stock-bound scope and partial controls before one fixed-budget search.
The prior checkpoint is on main 571738d8; CI 40758320213 has five passes with
Windows checks live. Production/READMEs, valid 64, 444 necessary allocations,
original H2 gate and 22 unopened vectors remain unchanged. H2/H5 stay open at
60%; no new release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
