"""Pure Z3 AST translation for comparison with the independent SMT reader."""
import z3
OPS={z3.Z3_OP_AND:'and',z3.Z3_OP_OR:'or',z3.Z3_OP_NOT:'not',z3.Z3_OP_IMPLIES:'=>',z3.Z3_OP_EQ:'=',z3.Z3_OP_LE:'<=',z3.Z3_OP_GE:'>=',z3.Z3_OP_ADD:'+',z3.Z3_OP_MUL:'*',z3.Z3_OP_UMINUS:'-'}
def tree(a,decls):
    if z3.is_rational_value(a):
        n,d=a.numerator_as_long(),a.denominator_as_long();assert d==1;return str(n) if n>=0 else ['-',str(-n)]
    if z3.is_const(a) and a.decl().kind()==z3.Z3_OP_UNINTERPRETED:
        name=str(a.decl().name());sort='Bool' if z3.is_bool(a) else 'Real' if z3.is_real(a) else None;assert sort==decls[name];return name
    return [OPS[a.decl().kind()],*[tree(c,decls) for c in a.children()]]
