"""Pin and verify the official Windows wheel; inspect notices before installation."""
from pathlib import Path
from hashlib import sha256
from urllib.request import urlopen
import json,zipfile
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-rational-source-20261028/dependency';review=json.loads((OUT/'index-review.json').read_bytes());w=review['windows_wheels'][0]
assert review['name']=='z3-solver' and review['version']=='5.3.2.0' and review['license']=='MIT License' and review['project_urls']['Homepage']=='https://github.com/Z3Prover/z3' and not w['yanked']
assert w['filename']=='z3_solver-5.3.2.0-py3-none-win_amd64.whl' and w['digests']['sha256']=='ea23baa055caf4a470ee6335140dfd617f4082750161a1fdbf23d24259f385e3'
cache=ROOT/'.cache/h5-z3-wheels';cache.mkdir();path=cache/w['filename']
with urlopen(w['url'],timeout=60) as r:data=r.read()
assert len(data)==w['size'] and sha256(data).hexdigest()==w['digests']['sha256']
with path.open('xb') as f:f.write(data)
with zipfile.ZipFile(path) as z:
    assert z.testzip() is None;names=z.namelist();notices=[n for n in names if any(t in n.lower() for t in ['license','copying','notice']) and not n.endswith('/')];metadata=next(n for n in names if n.endswith('.dist-info/METADATA'))
    (OUT/'wheel-METADATA.txt').write_bytes(z.read(metadata))
    rows=[]
    for i,n in enumerate(notices):
        d=z.read(n);target=OUT/f'wheel-notice-{i:02d}.txt';target.write_bytes(d);rows.append({'member':n,'saved':target.name,'sha256':sha256(d).hexdigest(),'text':d.decode('utf-8')})
record={'version':'5.3.2.0','wheel_path':path.relative_to(ROOT).as_posix(),'source_url':w['url'],'bytes':len(data),'sha256':sha256(data).hexdigest(),'zip_crc_pass':True,'notices':[{k:v for k,v in r.items() if k!='text'} for r in rows],'solver_calls':0}
with (OUT/'wheel-checks.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
for row in rows:print(row['member']);print(row['text'])
