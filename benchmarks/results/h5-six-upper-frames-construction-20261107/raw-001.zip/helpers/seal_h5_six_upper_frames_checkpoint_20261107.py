"""Preserve the scope correction, full39-owner preflight and closed search."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-six-upper-frames-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-six-upper-frames-model-20261107';F=BASE/'response-audit';D=ROOT/'output/h5-six-upper-frames-source-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-movable-roof-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==57 and not front['source_valid66']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-six-moving-frames-source-20261107']+[ROOT/'output'/n for n in ['h5-six-moving-frames-source-preparation-process-20261107','h5-six-moving-frames-source-audit-process-20261107','h5-six-upper-frames-source-preparation-process-20261107','h5-six-upper-frames-source-audit-process-20261107','h5-six-upper-frames-initializer-process-20261107','h5-six-upper-frames-model-audit-process-20261107','h5-six-upper-frames-response-audit-process-20261107','h5-movable-roof-main-sync-20261107']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*six*moving*frames*20261107.py','*h5*six*upper*frames*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_six_upper_frames_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"archive,_=pack(ROOT,OUT,NAME,members)":"history=ROOT/'benchmarks/results/h5-mixed-rows-source-contacts-20261026.md';bindings[history.relative_to(ROOT).as_posix()]=digest(history);add('source-inputs/'+history.relative_to(ROOT).as_posix(),history)\narchive,_=pack(ROOT,OUT,NAME,members)"
}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
runtime={name:r['sha256'] for name,r in load(BASE/'audit/tool-provenance.json')['tool_files'].items()}
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(D/'audit/checks.json','source-domain-audit.json'),(D/'scope-correction.json','scope-correction.json'),(D/'audit/frame-clearance-controls.json','frame-clearance-controls.json'),(ROOT/'output/h5-six-moving-frames-source-20261107/audit/checks.json','unused-right-column-source-audit.json'),(BASE/'audit/checks.json','model-audit.json'),(BASE/'audit/physical-mode-controls.json','physical-mode-controls.json'),(BASE/'audit/derivative-controls.json','derivative-controls.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(F/'checks.json','response-audit.json'),(F/'mode-selection-controls.json','mode-selection-controls.json'),(F/'round-reconciliation.json','round-reconciliation.json'),(F/'round-01-collision-details.json','source-failures.json'),(BASE/'frame-constraint-diagnostic/checks.json','frame-constraint-diagnostic.json'),(BASE/'frame-constraint-diagnostic/records.json','frame-constraint-records.json'),(BASE/'search/process.json','closed-process.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json'),(ROOT/'output/h5-movable-roof-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'separately_pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'historical_mixed_rows_continuous_source_preflight_required','proposal':'Reconcile the October26 mixed-row frame construction: twelve quarter-turned frames in4columns/3rows followed by six unturned frames in3columns/2rows. Assess source-safe continuous domains and one original-source15-cog5-by-3 seed at the previously certified6.75-degree contact pitch, with the checked six-bracket/nine-insert short sheet. This would fix all18frames and permit33companions/cogs to move, with81parameters and528pairs.','historical_report':'benchmarks/results/h5-mixed-rows-source-contacts-20261026.md','history_sha256':digest(history),'not_claimed_new_frame_topology':True,'historical_result':'One finite4200-pose source-contact model returned UNKNOWN; its call remains closed and excludes no continuous layout.','reason':'The current six movable frames retain their orientations and15 frame-related pairs fail. A coordinated row reorientation changes the fixed obstacle arrangement instead of extending single-owner moves from the current candidates. The historical arrangement reduces the top envelope by100mm relative to the current mixed-roof source; this does not prove it can fit all companions.','requirements':['Read the historical source, audit and exact recipe before deriving any changed source geometry. Preserve the historical UNKNOWN result and its finite scope.','Reconstruct every original frame and short-sheet part, preserve holes and PIHoff, and independently check all source48 quantities, pairs and stock bounds for the proposed cog seed. If it fails, retain the failed preparation.','Prepare and certify the changed fixed-core domains before constructing any complete initializer; charge every consumed preparation process, including any failed attempt.','Use no optimized current or historical candidate. Independently audit all owner/angle/mode mappings, geometry and gradients before any new finite call contract. No older model/call may resume, repeat, reseed or receive a reset clock.'],'new_source_geometry_prepared':False,'new_complete_model_prepared':False,'new_optimizer_calls':0,'H5_complete':False})
report=f'''# Six upper-frame construction — 2026-11-07

The expanded source model and its independent audits pass, but the bounded
search still produces no valid full layout. Three distinct calls close with
**57 failing original pairs** in the best candidate and **31,268.077325 mm²**
overlap. Fixed-part and stock checks all pass. H2/H5 remain open at **60%**
completed milestone weight; no native call or allocation exclusion follows.

## Corrected frame identities

The preceding checkpoint called copies12–17 the upper four base frames plus
the roof. That was an indexing error: the source numbers columns before rows.
Copies12–15 form the right column. The actual top row is **3,7,11,15**, and the
roof is16,17. [The correction]({NAME}/scope-correction.json) derives these
identities independently from transformed original vertex heights.

The unused right-column source preparation and its [passing geometry audit]({NAME}/unused-right-column-source-audit.json)
remain intact. It opened no complete model or optimizer. Its complete
0.390410-second preparation is charged to the corrected construction.
The original proposal and historical report remain preserved.

## Source domains and complete model

Twelve base frames and fifteen short-sheet parts stay fixed. Six frames,
six brackets, twelve inserts and fifteen cogs give **39 moving originals,
93 parameters and 741 moving pairs**. Frame rotations retain all four legal
quarter turns, no mirroring, and original holes; filled outer collision
geometry keeps common-line part-in-hole placement disabled.

[Independent source checks]({NAME}/source-domain-audit.json) verify 44 atomic
cells, 27 exact support proofs, 141 owner options and 684 original-source
corner controls. Sixteen [frame-clearance supports]({NAME}/frame-clearance-controls.json)
certify at least0.114mm local offset. The21 source seeds need at most
4.242641nm projection; the48-part partial control stays valid. Complete source
preparation is4.881802s, including the unused preparation and inherited source
lineage. These conservative domains do not cover every legal placement.

One fresh initializer places the six source frames and fifteen cogs before
greedily placing all eighteen companions. It consumes no optimized ancestor.
[Model readback]({NAME}/model-audit.json) verifies all **8,262 trial scores,
141 mode bindings, 103 vectors and 372 central derivative samples**. It also
checks124 scalar gradient terms, three descents and eleven corruptions.
There are105 physical owner options and66 distinct single-owner neighbors;
[114 equivalence controls]({NAME}/physical-mode-controls.json) preserve
different frame orientations and effective domains. Canonical projection adds
at most1nm and the source48 control still passes. Both
[derivative step sizes]({NAME}/derivative-controls.json) pass.

The complete initializer has28 failing pairs and97,732.123265mm² original
overlap; it is not a full valid layout. Complete source and initializer
preparation costs **7.770826s**.

## Closed search and response replay

The declared finite pipeline opens at most three distinct physical vectors,
with16/14/14-second slices and preparation-inclusive60/90-second limits.
All39 centers and fifteen cog angles remain free within their audited bounds.
Later selected mode changes affect inserts; all frame orientations stay unchanged.

[Independent response replay]({NAME}/response-audit.json) verifies **131 mode
trials and362 retained points**, reconciling counters for440 recorded function
evaluations. Each candidate reconstructs all66 originals,1,380 same-sheet
pairs,264 stock edges,90 holes and10,026 hole vertices. The candidates fail
59,57 and58 pairs. The second is best; the worse third is retained.
[Its failures]({NAME}/source-failures.json) comprise54 positive intersections
and three clearance-only failures, all between moving parts.

Algorithm/shared totals are **55.224232/55.291532s**, including all preparation.
Slice overruns of0.025521,0.095053 and0.047487s remain explicit. The call limit
closes the pipeline; [all five search processes close]({NAME}/closed-process.json),
with94,920,704bytes peak aggregate committed memory. No closed call can resume.

[Read-only frame diagnostics]({NAME}/frame-constraint-diagnostic.json) inspect
every saved response. In the best one, the four top-row frames move0,5.690821,
16.502890 and17.014567mm; the roof frames move only0.001584 and0.001279mm.
All retain their orientations. The four top-row lower y bounds are active;
the two roof frames are interior in y. Fifteen frame-related failures total
14,309.265123mm², including three frame/frame overlaps totaling7,346.056628mm².
[These observations]({NAME}/frame-constraint-records.json) do not prove global
stationarity or infeasibility.

## Next source preflight and repository state

[The next preflight]({NAME}/next-step.json) revisits the historical
[October26 mixed-row arrangement](h5-mixed-rows-source-contacts-20261026.md):
twelve turned frames in four columns/three rows, followed by six unturned
frames in three columns/two rows. That topology is already documented; its
finite source-contact model returned UNKNOWN. Assessing continuous source
domains and a source-only fifteen-cog seed requires fresh geometry checks,
complete preparation accounting and a new complete model audit. No successor
source geometry, initializer or optimizer is prepared. No historical call resumes.

Four earlier fixed arrangements and440 allocations remain unresolved. Full66
source/native/material validity, production parity and the unchanged H5 matrix
remain required. H2 retains its original gate and reserved vectors.
[The prior checkpoints reached main]({NAME}/prior-main-push-receipt.json)
atbca9af73 with all52 protected remote files preserved. [CI at review]({NAME}/main-ci-at-review.json)
has four passing jobs and two native jobs running; this checkpoint waits for
the ordinary push gate. Product code, README and releases are unchanged.

[Raw evidence]({NAME}/raw-manifest.json), [source bindings]({NAME}/source-bindings.json)
and [pinned runtime files]({NAME}/runtime-bindings.json) retain the reproducible
inputs, failures and closed outcomes.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 six upper frames:** [source/model/response audits]({link}) correct the column-major frame indexing: the moving top row is3,7,11,15 plus roof16,17. The unused right-column source and its passing audit remain preserved; its0.390410s complete preparation is charged and it opened no model/optimizer. The corrected39-mover/93-parameter/741-pair model verifies44 atomic cells,27 exact supports,684 source corners,8,262 initializer trials,141 owner options and372 derivative samples. Three distinct calls and131 mode trials close at the declared limit;362 saved points and440 evaluation counters replay. The best candidate still fails57 original pairs with31,268.077325mm² overlap; fixed-part and stock checks pass. Complete preparation is7.770826s and algorithm/shared totals55.224232/55.291532s; all slice overruns remain and every process closes. Fifteen frame-related failures contribute14,309.265123mm²; frame orientations stay unchanged. Next reconcile the already documented October26 mixed4-by-3/3-by-2 frame arrangement and assess independently certified continuous domains and a source-only15-cog seed; its finite UNKNOWN call remains closed. No successor geometry or model is prepared. Four earlier arrangements and440 allocations remain; H2/H5 stay at60%. Prior checkpoints reached mainbca9af73; four CI jobs pass and two native checks remain live at review. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [six upper frames](../benchmarks/results/{NAME}.md).
The corrected top-row copies3,7,11,15 and roof copies16,17 give39 moving parts,
93 parameters and741 interactions. The unused right-column preparation is
preserved and charged. All8,262 initializer trials,141 owner options and372
derivative samples pass. Three calls close with57 failing pairs in the best
candidate and31,268.077325mm² overlap; fixed-part and stock checks pass.
All362 saved points replay and440 recorded evaluations reconcile. The complete
preparation is7.770826s; algorithm/shared totals are55.224232/55.291532s.
Every process closes. All frame orientations stay unchanged;15 frame-related
failures remain. No full66 witness, native call or allocation exclusion follows.
Next reconcile the historical October26 mixed4-by-3/3-by-2 frame arrangement
and assess continuous source domains and an original-source15-cog seed. Its
finite UNKNOWN call remains closed; no successor geometry/model is prepared.
Four earlier fixed arrangements and440 allocations remain. H2/H5 stay at60%
completed milestone weight. Mainbca9af73 preserves all52 protected remote files;
four CI jobs pass and two native checks are live at review. This checkpoint
awaits the ordinary push gate. Full66 source/native/material checks, production
parity and the unchanged H5 matrix remain required. Product code is unchanged;
this evidence-only checkpoint does not warrant another release.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
