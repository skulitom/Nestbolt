"""Independent scalar readback of the new39-owner model and angle schema."""
from itertools import combinations
def verify(model,library,modes,values):
    expected=[['frame',i] for i in [3,7,11,15,16,17]]+[['bracket',i] for i in range(6,12)]+[['insert',i] for i in range(11)]+[['insert',20]]+[['cog',i] for i in range(15)]
    assert library['identities']==expected and len(modes)==len(expected)
    angular=[i for i,p in enumerate(expected) if p[0]=='cog'];offset=2*len(expected);size=offset+len(angular)
    assert model['parameters']==library['continuous_parameters']==size==len(values)
    assert library['angle_coordinate_start']==offset and library['angle_owners']==angular
    assert model['families']==library['families'] and model['fixed_source_rows']==library['fixed_source_rows']
    assert len(model['owners'])==len(expected) and model['pairs']==library['pairs']==[list(p) for p in combinations(range(len(expected)),2)]
    bounds=[]
    for i,p in enumerate(expected):
        option=library['family_modes'][p[0]][modes[i]];assert option['mode']==modes[i]
        expected_owner={'owner':i,'identity':p,'mode':modes[i],'source_mode':option['source_mode'],'cell_index':option['cell_index'],'rotation_radians':option['rotation_radians'],'mirrored':option['mirrored'],'source_center':library['families'][p[0]]['source_center'],'angle_coordinate':offset+angular.index(i) if i in angular else None,'angle_scale_mm':library['angle_scale_mm'] if i in angular else None}
        assert model['owners'][i]==expected_owner;bounds.extend(option['center_bounds_mm'])
    bounds.extend(library['angle_bounds']);assert model['bounds']==bounds
    assert model['initial']==[float(min(hi,max(lo,v))) for v,(lo,hi) in zip(values,bounds)]
    assert model['objective_weights']=={'original_area':1,'clearance_area':1}
    fixed=[[r['part_id'],r['copy_index']] for r in model['fixed_source_rows']]
    assert len(fixed)==27 and sorted(fixed+expected)==sorted(library['all66_identities']) and not set(map(tuple,fixed))&set(map(tuple,expected))
    assert sorted(p[1] for p in fixed if p[0]=='frame')==[i for i in range(16) if i not in [3,7,11,15]]
    return True
