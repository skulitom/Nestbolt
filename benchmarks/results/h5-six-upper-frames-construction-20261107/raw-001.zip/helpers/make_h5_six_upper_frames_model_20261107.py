from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def convert(old,new,replacements):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in replacements:
        assert a in s,(old,a)
        s=s.replace(a,b)
    dest=ROOT/'output'/new
    if dest.exists():assert dest.read_text(encoding='utf-8')==s
    else:
        with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)

common=[('h5-movable-roof-source','h5-six-upper-frames-source'),('h5-movable-roof-model','h5-six-upper-frames-model'),('h5_movable_roof_readback','h5_six_upper_frames_readback')]
convert('h5_movable_roof_readback_20261107.py','h5_six_upper_frames_readback_20261107.py',[
    ('new35-owner','new39-owner'),
    ("[['frame',16],['frame',17]]","[['frame',i] for i in [3,7,11,15,16,17]]"),
    ('len(fixed)==31','len(fixed)==27'),
    ("==list(range(16))","==[i for i in range(16) if i not in [3,7,11,15]]")])
convert('prepare_h5_movable_roof_initializer_20261107.py','prepare_h5_six_upper_frames_initializer_20261107.py',common+[
    ('for35moving','for39moving'),('two movable roof-frame originals,35movers/85parameters/595pairs','six movable upper-frame originals,39movers/93parameters/741pairs'),
    ('both original holes','all six original holes'),('the17 unoptimized','the21 unoptimized'),('Initialize two frames','Initialize six frames'),('All35centers','All39centers'),
    ('len(placed)==17','len(placed)==21'),('len(placed)==35','len(placed)==39'),("'moving_originals':35","'moving_originals':39"),("'parameters':85","'parameters':93"),("'moving_pairs':595","'moving_pairs':741")])
convert('audit_h5_movable_roof_model_20261107.py','audit_h5_six_upper_frames_model_20261107.py',common+[
    ('h5-movable-roof-initializer','h5-six-upper-frames-initializer'),
    ('len(placed)==17','len(placed)==21'),('range(17)','range(21)'),('range(i+1,17)','range(i+1,21)'),('list(range(2,20))','list(range(6,24))'),
    ('70+i-20','78+i-24'),('if i>=20','if i>=24'),('own>=20','own>=24'),('70+own-20','78+own-24'),
    ('bindings==125 and vectors==91','bindings==141 and vectors==103'),('np.zeros(85)','np.zeros(93)'),('np.arange(85)','np.arange(93)'),('range(85)','range(93)'),("'coordinates':85","'coordinates':93"),("'samples':170","'samples':186"),
    ('len(keys)==62 and equivalent==14 and raw==90','len(keys)==66 and equivalent==18 and raw==102'),("'source_owner_options':125","'source_owner_options':141"),("'physical_owner_options':97","'physical_owner_options':105"),("'unique_single_owner_physical_neighbors':62","'unique_single_owner_physical_neighbors':66"),("'raw_current_equivalents':14","'raw_current_equivalents':18"),("'raw_alternatives':90","'raw_alternatives':102"),
    ("mm['owners'][20]['angle_coordinate']=71","mm['owners'][24]['angle_coordinate']=79"),("mm['parameters']=84","mm['parameters']=92"),
    ('125ownercompoundbindings/fullscores,91vectors,595pairs/85parameters including two movable frame owners','141ownercompoundbindings/fullscores,103vectors,741pairs/93parameters including six movable frame owners'),('170centralcoordinates at two steps (340samples)','186centralcoordinates at two steps (372samples)'),
    ("'independent_central_coordinates':170","'independent_central_coordinates':186"),("'independent_central_samples':340","'independent_central_samples':372"),("'frame_center_coordinates_verified':4","'frame_center_coordinates_verified':12")])
for phase in ['initializer','model_audit']:
    convert(f'run_h5_movable_roof_{phase}_20261107.py',f'run_h5_six_upper_frames_{phase}_20261107.py',[
        ('h5-movable-roof','h5-six-upper-frames'),('h5_movable_roof','h5_six_upper_frames')])
