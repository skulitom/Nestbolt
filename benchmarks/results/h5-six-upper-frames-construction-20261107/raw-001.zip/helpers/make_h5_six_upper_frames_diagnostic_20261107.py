from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/diagnose_h5_movable_roof_constraints_20261107.py').read_text(encoding='utf-8')
for a,b in [('h5-movable-roof-model','h5-six-upper-frames-model'),('in [16,17]','in [3,7,11,15,16,17]'),('len(frames)==2','len(frames)==6'),('actual roof-frame translations','actual six-upper-frame translations')]:
    assert a in s,a;s=s.replace(a,b)
with (ROOT/'output/diagnose_h5_six_upper_frames_constraints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
