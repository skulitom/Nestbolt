from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def convert(old,new,replacements):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in replacements:
        assert a in s,(old,a);s=s.replace(a,b)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
common=[('h5-movable-roof-model','h5-six-upper-frames-model'),('h5-movable-roof-source','h5-six-upper-frames-source'),('h5-movable-roof-initializer','h5-six-upper-frames-initializer'),('h5_movable_roof_readback','h5_six_upper_frames_readback'),('range(85)','range(93)')]
convert('run_h5_movable_roof_search_20261107.py','run_h5_six_upper_frames_search_20261107.py',common+[
    ("'parameters':85","'parameters':93"),('broader movable-roof model','broader six-upper-frames model'),('Two roof-frame originals','Six upper-frame originals'),('All35centers/15angles','All39centers/15angles'),('85parameters and595movingpairs','93parameters and741movingpairs'),('Only16baseframes','Only12baseframes'),('All35owners','All39owners'),('62distinct physicalneighbors and90raw alternatives','66distinct physicalneighbors and102raw alternatives'),('selected85coordinate','selected93coordinate'),
    ('Whole source+initializer wrapper costs are charged.','Whole source+initializer wrapper costs, including the unused right-column source preparation, are charged. The actual moving frame copies are3,7,11,15,16,17, verified independently from source vertex heights; no optimizer or companion initializer was prepared for the mistaken copies12..17 selection.')])
convert('audit_h5_movable_roof_response_20261107.py','audit_h5_six_upper_frames_response_20261107.py',common+[
    ('len(evaluated)+len(skipped)==90','len(evaluated)+len(skipped)==102'),("opened_optimizer['parameters']==85","opened_optimizer['parameters']==93"),('70+i-20','78+i-24'),('if i>=20','if i>=24'),('len(moving_pairs)==595','len(moving_pairs)==741'),('85coordinategradients','93coordinategradients'),('All595movingpairs','All741movingpairs')])
convert('run_h5_movable_roof_response_audit_20261107.py','run_h5_six_upper_frames_response_audit_20261107.py',[
    ('h5-movable-roof','h5-six-upper-frames'),('h5_movable_roof','h5_six_upper_frames')])
