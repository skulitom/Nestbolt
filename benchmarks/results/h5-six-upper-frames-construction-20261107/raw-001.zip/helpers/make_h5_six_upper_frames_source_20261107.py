from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def convert(old,new,changes):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in changes:
        assert a in s,(old,a);s=s.replace(a,b)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
common=[('h5-six-moving-frames-source','h5-six-upper-frames-source'),('in range(12,18)','in [3,7,11,15,16,17]')]
base_ids='[i for i in range(16) if i not in [3,7,11,15]]'
scope="""
wrong=ROOT/'output/h5-six-moving-frames-source-preparation-process-20261107/process.json';wrong_process=load(wrong);assert wrong_process['passed'] and wrong_process['closed']
correction_charge=wrong_process['complete_seconds'];reused_charge=prior['complete_preparation_seconds']+correction_charge
frame_y={}
for r in source['fixed_source_rows']:
    if r['part_id']!='frame' or r['copy_index']>=16:continue
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);frame_y[r['copy_index']]=min(x*s+y*c+t['translation'][1] for x,y in parts['frame']['geometry'][0]['outer'])
top=max(frame_y.values());top_ids=sorted(i for i,y in frame_y.items() if abs(y-top)<1e-9);assert top_ids==[3,7,11,15]
write(OUT/'scope-correction.json',{'source_frame_lower_y_mm':frame_y,'verified_upper_row_frame_copies':top_ids,'moving_frame_copies':top_ids+[16,17],'prior_proposed_copies':[12,13,14,15,16,17],'prior_scope_was_right_column_plus_roof':True,'prior_preparation_preserved':True,'prior_source_audit_geometrically_passed':True,'prior_optimizer_calls':0,'additional_preparation_seconds_charged':correction_charge,'explanation':'The source recipe numbers columns before rows. Preserve the prepared right-column source without opening a model; use actual top-row copies3,7,11,15 plus16,17 to investigate the observed lower-y limits.'})
"""
convert('prepare_h5_six_moving_frames_source_20261107.py','prepare_h5_six_upper_frames_source_20261107.py',common+[
 ("families=copy.deepcopy(source['families']);partitions=load(Q/'partitions.json')", "families=copy.deepcopy(source['families']);partitions=load(Q/'partitions.json')\n"+scope),
 ("inputs=[Path(__file__),JOB,Q/'partitions.json']", "inputs=[Path(__file__),JOB,Q/'partitions.json',wrong,ROOT/'output/h5-six-moving-frames-source-20261107/plan.json',ROOT/'output/h5-six-moving-frames-source-20261107/audit/checks.json']"),
 ("prior['complete_preparation_seconds'],'preparation_internal_target_seconds'", "reused_charge,'preparation_internal_target_seconds'"),
 ("prior['complete_preparation_seconds'],'library_sha256'", "reused_charge,'library_sha256'"),
 ('for i in range(12):\n    row=fixed[i];',f'for i in {base_ids}:\n    row=next(r for r in fixed if r["part_id"]=="frame" and r["copy_index"]==i);'),
 ("'frame_indices':list(range(12))",f"'frame_indices':{base_ids}"),
 ('original frame copies12..17','original upper-row frame copies3,7,11,15 androof16,17'),
 ('Keep12 base frames','The earlier source-only preparation selected copies12..17, which is the right column plus roof because source indices are column-major. Preserve its geometry/audit and charge that complete preparation, but open no model for it. Verify actual upper-row membership from transformed source vertices. Keep12 base frames')
])
audit_insert="""
wrong=ROOT/'output/h5-six-moving-frames-source-preparation-process-20261107/process.json';wrong_process=load(wrong);assert wrong_process['passed'] and wrong_process['closed'];correction=load(BASE/'scope-correction.json')
source_y={}
for row in source['fixed_source_rows']:
    if row['part_id']!='frame' or row['copy_index']>=16:continue
    t=row['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);source_y[row['copy_index']]=min(x*s+y*c+t['translation'][1] for x,y in parts['frame']['geometry'][0]['outer'])
upper_ids=sorted(i for i,y in source_y.items() if abs(y-max(source_y.values()))<1e-9)
assert upper_ids==[3,7,11,15] and correction['source_frame_lower_y_mm']=={str(i):y for i,y in source_y.items()} and correction['verified_upper_row_frame_copies']==upper_ids and correction['moving_frame_copies']==upper_ids+[16,17] and correction['additional_preparation_seconds_charged']==wrong_process['complete_seconds'] and correction['prior_optimizer_calls']==0
"""
convert('audit_h5_six_moving_frames_source_20261107.py','audit_h5_six_upper_frames_source_20261107.py',common+[
 ("[('base',range(12))]",f"[('base',{base_ids})]"),
 ("t=fixed[i]['transform'];", "t=next(r for r in fixed if r['part_id']=='frame' and r['copy_index']==i)['transform'];"),
 ("frame=parts['frame'];outer=", audit_insert+"\nframe=parts['frame'];outer="),
 ("charge=prior['complete_preparation_seconds']+process['complete_seconds']", "charge=prior['complete_preparation_seconds']+wrong_process['complete_seconds']+process['complete_seconds']"),
 ("inputs=[Path(__file__),JOB,Q/'partitions.json'", "inputs=[Path(__file__),JOB,wrong,BASE/'scope-correction.json',Q/'partitions.json'"),
 ("'moving_frame_copies_verified':list(range(12,18))", "'moving_frame_copies_verified':[3,7,11,15,16,17],'column_major_scope_correction_verified':True,'unused_prior_preparation_seconds_charged':wrong_process['complete_seconds']")
])
for phase in ['preparation','audit']:
    convert(f'run_h5_six_moving_frames_source_{phase}_20261107.py',f'run_h5_six_upper_frames_source_{phase}_20261107.py',[('h5-six-moving-frames-source','h5-six-upper-frames-source'),('h5_six_moving_frames_source','h5_six_upper_frames_source')])
