from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def convert(old,new,changes):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in changes:
        assert a in s,(old,a);s=s.replace(a,b)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
common=[('h5-movable-roof-source','h5-six-moving-frames-source'),("in [16,17]","in range(12,18)"),('fixed31','fixed27'),("'fixed_originals':31","'fixed_originals':27"),("'moving_originals':35","'moving_originals':39"),("'continuous_parameters':85","'continuous_parameters':93"),("'moving_pairs':595","'moving_pairs':741"),('source17-moving-seed.json','source21-moving-seed.json'),('range(16)','range(12)')]
convert('prepare_h5_movable_roof_source_20261107.py','prepare_h5_six_moving_frames_source_20261107.py',common+[
 ('freeing the two roof-frame originals','freeing six upper frame originals'),
 ('len(fixed)==31','len(fixed)==27'),
 ("len(ids)==35 and ids[:2]==[['frame',16],['frame',17]] and ids[2:8]", "len(ids)==39 and ids[:6]==[['frame',i] for i in range(12,18)] and ids[6:12]"),
 ("ids[20:]","ids[24:]"),('len(seeds)==17','len(seeds)==21'),("'seed_moving_poses':17","'seed_moving_poses':21"),
 ('original frame copies16/17','original frame copies12..17'),('Keep16 base frames','Keep12 base frames'),('outward-rounded16-frame base','outward-rounded12-frame base'),('Preserve two roof and15cog source poses','Preserve six frame and15cog source poses'),('All35 movers','All39 movers')
])
convert('audit_h5_movable_roof_source_20261107.py','audit_h5_six_moving_frames_source_20261107.py',common+[
 ("ids=[['frame',16],['frame',17]]", "ids=[['frame',i] for i in range(12,18)]"),
 ('combinations(range(35),2)','combinations(range(39),2)'),
 ("lib['continuous_parameters']==85 and lib['angle_coordinate_start']==70 and lib['angle_owners']==list(range(20,35))", "lib['continuous_parameters']==93 and lib['angle_coordinate_start']==78 and lib['angle_owners']==list(range(24,39))"),
 ('all35 owner bindings,17 nearest-cell source projections including two frames','all39 owner bindings,21 nearest-cell source projections including six frames'),
 ('both roof frames remain movable','all six upper frames remain movable'),
 ("'seed_moving_projections_verified':17,'moving_frame_copies_verified':[16,17]", "'seed_moving_projections_verified':21,'moving_frame_copies_verified':list(range(12,18))")
])
for phase in ['preparation','audit']:
    changes=[('h5-movable-roof-source','h5-six-moving-frames-source'),('h5_movable_roof_source','h5_six_moving_frames_source')]
    convert(f'run_h5_movable_roof_source_{phase}_20261107.py',f'run_h5_six_moving_frames_source_{phase}_20261107.py',changes)
