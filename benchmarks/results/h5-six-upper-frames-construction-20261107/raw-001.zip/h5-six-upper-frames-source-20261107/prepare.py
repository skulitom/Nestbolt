"""Source-only hard domains after freeing six upper frame originals."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
import json,math,time,copy,shutil
from h5_rectangular_cells_20261107 import lower,upper,serial,merged_free_cells,UNIT
from h5_direct_pose_geometry_tools_20261107 import clearance_outline,certify_clearance
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'output/h5-mixed-roof-source-20261107'
Q=ROOT/'output/h5-mixed-direct-pose-v2-20261107'
OUT=ROOT/'output/h5-six-upper-frames-source-20261107'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')

OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
source=load(SOURCE/'source-geometry.json');prior=load(SOURCE/'audit/checks.json')
assert prior['passed'] and prior['source_geometry_sha256']==digest(SOURCE/'source-geometry.json')
job=load(JOB);parts={p['id']:p for p in job['parts']}
fixed=[r for r in source['fixed_source_rows'] if not(r['part_id']=='frame' and r['copy_index'] in [3,7,11,15,16,17])]
families=copy.deepcopy(source['families']);partitions=load(Q/'partitions.json')

wrong=ROOT/'output/h5-six-moving-frames-source-preparation-process-20261107/process.json';wrong_process=load(wrong);assert wrong_process['passed'] and wrong_process['closed']
correction_charge=wrong_process['complete_seconds'];reused_charge=prior['complete_preparation_seconds']+correction_charge
frame_y={}
for r in source['fixed_source_rows']:
    if r['part_id']!='frame' or r['copy_index']>=16:continue
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);frame_y[r['copy_index']]=min(x*s+y*c+t['translation'][1] for x,y in parts['frame']['geometry'][0]['outer'])
top=max(frame_y.values());top_ids=sorted(i for i,y in frame_y.items() if abs(y-top)<1e-9);assert top_ids==[3,7,11,15]
write(OUT/'scope-correction.json',{'source_frame_lower_y_mm':frame_y,'verified_upper_row_frame_copies':top_ids,'moving_frame_copies':top_ids+[16,17],'prior_proposed_copies':[12,13,14,15,16,17],'prior_scope_was_right_column_plus_roof':True,'prior_preparation_preserved':True,'prior_source_audit_geometrically_passed':True,'prior_optimizer_calls':0,'additional_preparation_seconds_charged':correction_charge,'explanation':'The source recipe numbers columns before rows. Preserve the prepared right-column source without opening a model; use actual top-row copies3,7,11,15 plus16,17 to investigate the observed lower-y limits.'})

stocks=source['source_stocks'];required=source['required_pair_gap_mm'];guard=source['stock_guard_mm']
epsilon=F(1,UNIT);gap=F('.23');safe=[F(str(stocks['sheet-0'][0]))+F('.025'),F(str(stocks['sheet-0'][1]))+F('.025'),F(str(stocks['sheet-0'][2]))-F('.025'),F(str(stocks['sheet-0'][3]))-F('.025')]
inputs=[Path(__file__),JOB,Q/'partitions.json',wrong,ROOT/'output/h5-six-moving-frames-source-20261107/plan.json',ROOT/'output/h5-six-moving-frames-source-20261107/audit/checks.json']+[ROOT/'output'/n for n in ['h5_rectangular_cells_20261107.py','h5_direct_pose_geometry_tools_20261107.py','h5_legacy64_source_readback.py']]+[SOURCE/n for n in ['plan.json','source-geometry.json','source48-control.json','source48-checks.json','audit/checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'A broader source-only construction frees original upper-row frame copies3,7,11,15 androof16,17 along with6 brackets,12 inserts and15 continuously rotating cogs. The earlier source-only preparation selected copies12..17, which is the right column plus roof because source indices are column-major. Preserve its geometry/audit and charge that complete preparation, but open no model for it. Verify actual upper-row membership from transformed source vertices. Keep12 base frames and15 short-sheet originals fixed. Build source-safe rectangular center domains against only the outward-rounded12-frame base. Preserve every original quantity and hole; filled outer outlines enforce common-line PIHoff. Frame modes are original legal quarter turns without mirroring, and their new clearance contour is source rectangle plus0.115mm square, independently certified to contain a0.114mm offset. Preserve six frame and15cog source poses as a partial48 control, projecting each at most0.0001mm into a matching legal source cell. All39 movers remain free; this is not a completed initializer. No previous optimizer point, failed candidate, joint neighbor or closed call is consumed. Charge the complete original source lineage and all new preparation.','rounding_unit_mm':'1/1000000','rounding_unit_name':'nanometre','complete_reused_preparation_seconds':reused_charge,'preparation_internal_target_seconds':12,'preparation_process_cap_seconds':15,'algorithm_seconds':60,'shared_seconds':90,'memory_bytes':2**31,'source_optimizer_calls':0,'retry_permitted':False})
frame=parts['frame'];outer=frame['geometry'][0]['outer']
assert outer==[[0.,0.],[450.,0.],[450.,350.],[0.,350.]] and not frame['allow_mirror'] and frame['rotations']['degrees']==[0.,90.,180.,270.]
expanded=clearance_outline([outer],'.115');supports,minimum=certify_clearance(outer,expanded,'.114')
families['frame']={'original':outer,'clearance':expanded,'source_center':[225.,175.],'source_holes':frame['geometry'][0]['holes']}
partitions['frame']={'pieces':[outer],'construction':'exact convex source rectangle; no triangulation'}
write(OUT/'frame-clearance-supports.json',{'required_mm':'.114','square_halfwidth_mm':'.115','minimum_certified_gap_mm':minimum,'supports':supports})
write(OUT/'partitions.json',partitions)
check=audit(job,fixed,stocks,required,guard);assert check['valid'] and len(fixed)==27
write(OUT/'fixed27-source.json',fixed);write(OUT/'fixed27-checks.json',check)
vertices=[]
for i in [i for i in range(16) if i not in [3,7,11,15]]:
    row=next(r for r in fixed if r["part_id"]=="frame" and r["copy_index"]==i);assert row['part_id']=='frame' and row['copy_index']==i
    t=row['transform'];c,s=map(F,[math.cos(t['rotation_radians']),math.sin(t['rotation_radians'])]);tx,ty=map(F,t['translation']);assert not t['mirrored']
    vertices.extend([(F(x)*c-F(y)*s+tx,F(x)*s+F(y)*c+ty) for x,y in outer])
core=[lower(min(x for x,y in vertices)),lower(min(y for x,y in vertices)),upper(max(x for x,y in vertices)),upper(max(y for x,y in vertices))]
cores=[core];write(OUT/'fixed-core-boxes.json',[{'group':'base','frame_indices':[i for i in range(16) if i not in [3,7,11,15]],'outer_rectangle':serial(core),'source_vertices':[[str(x),str(y)] for x,y in vertices]}])
modes={};decompositions=[];certificates=[];proofcount=0;radius=source['source_radius_mm']
for family in ['frame','bracket','insert','cog']:
    modes[family]=[];px,py=families[family]['source_center']
    options=[(False,0.)] if family=='cog' else [(mir,math.radians(deg)) for mir in ([False,True] if parts[family]['allow_mirror'] else [False]) for deg in parts[family]['rotations']['degrees']]
    for source_mode,(mirror,angle) in enumerate(options):
        c,s=map(F,[math.cos(angle),math.sin(angle)]);sign=-1 if mirror else 1;local=[]
        if family=='cog':local=[[-upper(radius),-upper(radius),upper(radius),upper(radius)]]
        else:
            for piece in partitions[family]['pieces']:
                v=[(sign*(F(x)-F(px))*c-(F(y)-F(py))*s,sign*(F(x)-F(px))*s+(F(y)-F(py))*c) for x,y in piece]
                local.append([lower(min(x for x,y in v)),lower(min(y for x,y in v)),upper(max(x for x,y in v)),upper(max(y for x,y in v))])
        root=[safe[0]-min(r[0] for r in local)+epsilon,safe[1]-min(r[1] for r in local)+epsilon,safe[2]-max(r[2] for r in local)-epsilon,safe[3]-max(r[3] for r in local)-epsilon]
        blocked=[[core[0]-gap-r[2],core[1]-gap-r[3],core[2]+gap-r[0],core[3]+gap-r[1]] for core,r in product(cores,local)]
        cells,atomic=merged_free_cells(root,blocked);assert cells
        decompositions.append({'family':family,'source_mode':source_mode,'rotation_radians':angle,'mirrored':mirror,'local_piece_outer_boxes':list(map(serial,local)),'stock_center_root':serial(root),'forbidden_center_rectangles':list(map(serial,blocked)),'atomic_cells':atomic,'merged_cells':list(map(serial,cells)),'complete_for_conservative_rectangle_arrangement':True,'complete_for_original_free_space':False})
        for index,cell in enumerate(cells):
            bb=list(map(float,[cell[0]+epsilon,cell[1]+epsilon,cell[2]-epsilon,cell[3]-epsilon]));ff=list(map(F,bb))
            assert ff[0]<ff[2] and ff[1]<ff[3] and all(ff[k]>cell[k] for k in [0,1]) and all(ff[k]<cell[k] for k in [2,3]);proofs=[]
            for pi,piece in enumerate(local):
                moved=[ff[0]+piece[0],ff[1]+piece[1],ff[2]+piece[2],ff[3]+piece[3]];assert safe[0]<=moved[0]<moved[2]<=safe[2] and safe[1]<=moved[1]<moved[3]<=safe[3]
                distances=[core[0]-moved[2],core[1]-moved[3],moved[0]-core[2],moved[1]-core[3]];axis=max(range(4),key=lambda k:distances[k]);assert distances[axis]>=F('.22')
                proofs.append({'piece':pi,'core':0,'axis':axis,'exact_gap_mm':str(distances[axis])});proofcount+=1
            option={'mode':len(modes[family]),'source_mode':source_mode,'cell_index':index,'rotation_radians':angle,'mirrored':mirror,'continuous_rotation':family=='cog','center_bounds_mm':[[bb[0],bb[2]],[bb[1],bb[3]]],'rectangle_mm':bb};modes[family].append(option)
            certificates.append({'family':family,'compound_mode':option['mode'],'source_mode':source_mode,'cell_index':index,'piece_core_axis_supports':proofs})
used={(r['part_id'],r['copy_index']) for r in fixed}
ids=[[family,i] for family in ['frame','bracket','insert','cog'] for i in range(parts[family]['quantity']) if (family,i) not in used]
assert len(ids)==39 and ids[:6]==[['frame',i] for i in [3,7,11,15,16,17]] and ids[6:12]==[['bracket',i] for i in range(6,12)] and ids[24:]==[['cog',i] for i in range(15)]
partial=copy.deepcopy(load(SOURCE/'source48-control.json'));seeds=[]
for row in partial:
    identity=[row['part_id'],row['copy_index']]
    if identity not in ids:continue
    family=identity[0];assert family in ['frame','cog'];owner=ids.index(identity);t=row['transform'];theta=t['rotation_radians'];c,s=math.cos(theta),math.sin(theta);px,py=families[family]['source_center'];assert not t['mirrored']
    oldcenter=[px*c-py*s+t['translation'][0],px*s+py*c+t['translation'][1]]
    eligible=[m for m in modes[family] if family=='cog' or (not m['mirrored'] and abs(math.remainder(m['rotation_radians']-theta,math.tau))<1e-12)]
    choices=[]
    for mode in eligible:
        point=[min(max(oldcenter[k],mode['center_bounds_mm'][k][0]),mode['center_bounds_mm'][k][1]) for k in [0,1]]
        choices.append((sum((a-b)**2 for a,b in zip(point,oldcenter)),mode['mode'],point))
    distance,mi,point=min(choices);assert distance<.0001**2;t['translation']=[point[0]-(px*c-py*s),point[1]-(px*s+py*c)]
    available=[m['mode'] for m in eligible if all(m['center_bounds_mm'][k][0]<=point[k]<=m['center_bounds_mm'][k][1] for k in [0,1])];assert available
    seeds.append({'owner':owner,'identity':identity,'source_original_center':oldcenter,'center':point,'source_pose':t,'angle_radians':theta,'projection_distance_mm':math.sqrt(distance),'selected_projection_compound_mode':mi,'covering_compound_modes':available})
control=audit(job,partial,stocks,required,guard);assert control['valid'] and len(seeds)==21 and len(partial)==48
write(OUT/'source48-control.json',partial);write(OUT/'source48-checks.json',control);write(OUT/'source21-moving-seed.json',seeds)
write(OUT/'rectangle-decompositions.json',decompositions);write(OUT/'cell-support-certificates.json',certificates)
angle_owners=[i for i,(family,_) in enumerate(ids) if family=='cog'];angle_start=2*len(ids);parameters=angle_start+len(angle_owners)
library={'families':families,'family_modes':modes,'identities':ids,'pairs':list(combinations(range(len(ids)),2)),'fixed_source_rows':fixed,'all66_identities':source['all66_identities'],'source_stocks':stocks,'safe_source_stock_mm':list(map(float,safe)),'fixed_core_outer_rectangles_mm':[list(map(float,c)) for c in cores],'required_pair_gap_mm':required,'stock_guard_mm':guard,'angle_scale_mm':radius,'angle_bounds':[[-math.pi*radius,math.pi*radius] for _ in angle_owners],'continuous_parameters':parameters,'angle_coordinate_start':angle_start,'angle_owners':angle_owners,'source_moving_seed':seeds,'source_initialization_prepared':False,'complete_model_prepared':False}
write(OUT/'library.json',library);assert time.perf_counter()-started<12
result={'prepared':True,'seconds':time.perf_counter()-started,'fixed_originals':27,'fixed_source_valid':True,'moving_originals':39,'continuous_parameters':93,'continuous_cog_angles':15,'moving_pairs':741,'fixed_containing_boxes':1,'base_mode_arrangements':len(decompositions),'compound_modes_by_family':{f:len(v) for f,v in modes.items()},'owner_compound_options':sum(len(modes[f]) for f,_ in ids),'whole_cell_piece_core_supports':proofcount,'source_control_originals':48,'source_control_valid':True,'seed_moving_poses':21,'maximum_seed_projection_mm':max(s['projection_distance_mm'] for s in seeds),'remaining_unplaced_companions':18,'complete_reused_preparation_seconds':reused_charge,'library_sha256':digest(OUT/'library.json'),'source_optimizer_calls':0,'complete_initializer_prepared':False,'complete_model_prepared':False,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
