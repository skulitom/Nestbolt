"""Check authored LightBurn/lead workflows with actual downloaded Windows tools."""
from hashlib import sha256
from pathlib import Path
from copy import deepcopy
import json
import shutil
import subprocess
import sys
import traceback
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parents[1]
work=root/'output/preview-depth-published-feature-checks-20261016'
assert not work.exists()
work.mkdir()
download=root/'output/preview-depth-published-20261016'
proof=json.loads((root/'benchmarks/results/preview-depth-published-20261016/checks.json').read_bytes())
cli=download/'windows-extracted/nestbolt.exe'
bundle=download/'windows/nestbolt-windows-x64.mcpb'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
expected=next(r for r in proof['archives'] if r['platform']=='windows')
assert digest(cli)==expected['members']['nestbolt.exe']['sha256']
assert digest(bundle)==proof['MCPB_sha256']
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
product=source_digest()
assert product=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
fixtures=['lead-group.lbrn2','uncached-text.lbrn2','mixed-fixed.lbrn2']
inputs=work/'inputs';inputs.mkdir()
for name in fixtures:
    source=root/'crates/core/tests/fixtures'/name
    assert source.read_bytes().replace(b'\r\n',b'\n')==subprocess.check_output(['git','show','c36baa8145e9e7b51e5667f4e4eaa0242256fc6e:crates/core/tests/fixtures/'+name],cwd=root)
    shutil.copyfile(source,inputs/name)
request={'parts':[{'id':'lead-group-unit-1','quantity':2}],'sheets':[{'width_mm':150,'height_mm':100}],
    'spacing_mm':0.2,'edge_spacing_mm':1,'lead_in':{'kerf_mm':0.2}}
write(work/'request.json',request)
stages=[]
def run(label,args,success=True):
    completed=subprocess.run([str(cli),*map(str,args)],cwd=work,capture_output=True,timeout=120)
    (work/(label+'-stdout.log')).write_bytes(completed.stdout)
    (work/(label+'-stderr.log')).write_bytes(completed.stderr)
    stages.append({'label':label,'args':list(map(str,args)),'exit_code':completed.returncode})
    write(work/'progress.json',stages)
    assert (completed.returncode==0)==success,(label,completed.stderr.decode('utf-8',errors='replace'))
    return completed
try:
    for name,message in [('uncached-text.lbrn2','re-save text in LightBurn'),('mixed-fixed.lbrn2','group movable artwork separately')]:
        result=run(name,['import',inputs/name,'--output',work/(name+'.json')],False)
        assert message.encode() in result.stderr and not (work/(name+'.json')).exists()
    library=work/'library.json'
    run('import',['import',inputs/'lead-group.lbrn2','--output',library])
    run('nest',['nest','--library',library,'--request',work/'request.json','--out-dir',work/'nested',
        '--seconds','1','--repeatable','--time-limit','120'])
    report=load(work/'nested/report.json')
    assert report['validation']['valid']
    assert [report['lead_in'][k] for k in ['expected_contours','reserved_contours','flagged_contours']]==[10,8,2]
    result=run('validate',['validate','--library',library,'--request',work/'request.json','--layout',work/'nested/layout.json'])
    checked=json.loads(result.stdout)
    assert checked['valid'] and checked['lead_in']==report['lead_in']
    run('export',['export','--library',library,'--request',work/'request.json','--layout',work/'nested/layout.json','--out-dir',work/'exported'])
    assert len(report['files'])==3
    for name in report['files']:
        data=(work/'nested'/name).read_bytes()
        assert data==(work/'exported'/name).read_bytes()
        if name.endswith('.lbrn2'):
            assert b'<leadIn Value="0"/>' in data and b'LEADIN' not in data
        else:
            assert '-cuts.' in name and b'LEADIN' in data
    mcp=work/'mcp';mcp.mkdir()
    for name in ['mcp-client.mjs','zip.mjs']:
        source=root/'mcpb'/name
        assert source.read_bytes().replace(b'\r\n',b'\n')==subprocess.check_output(['git','show','c36baa8145e9e7b51e5667f4e4eaa0242256fc6e:mcpb/'+name],cwd=root)
        shutil.copyfile(source,work/name)
    shutil.copyfile(root/'output/check_downloaded_depth_features.mjs',work/'check-mcp.mjs')
    write(work/'mcp-config.json',{'work':str(mcp),'bundle':str(bundle),'fixtures':fixtures,'fixtures_dir':str(inputs),'request':request})
    with (work/'mcp-stdout.log').open('xb') as stdout,(work/'mcp-stderr.log').open('xb') as stderr:
        result=subprocess.run(['node',str(work/'check-mcp.mjs'),str(work/'mcp-config.json')],cwd=work,stdout=stdout,stderr=stderr,timeout=120)
    assert result.returncode==0,'Original MCP check failed; inspect its preserved logs'
    assert load(mcp/'checks.json')['all_checks_pass']
    # Independent XML-tree comparison: retain every group child, setting,
    # unknown element and fixed shape. Only the top-level group transform and
    # optional extra stock outline are outside this preservation comparison.
    def tree(node):
        return (node.tag,sorted(node.attrib.items()),(node.text or '').strip(),[tree(c) for c in node])
    original=ET.fromstring((inputs/'lead-group.lbrn2').read_bytes())
    group=original.find("Shape[@Type='Group']")
    expected_children=[tree(c) for c in group if c.tag!='XForm']
    other=[tree(c) for c in original if c.tag!='Shape']
    fixed=tree(original.find("Shape[@CutIndex='30']"))
    preservation=[]
    for surface,directory in [('CLI',work/'nested'),('MCPB',mcp/'workspace/nested')]:
        files=list(directory.glob('*.lbrn2'));assert len(files)==1
        document=ET.fromstring(files[0].read_bytes())
        assert document.attrib==original.attrib
        assert [tree(c) for c in document if c.tag!='Shape']==other
        groups=document.findall("Shape[@Type='Group']");assert len(groups)==2
        assert all(g.attrib==group.attrib and [tree(c) for c in g if c.tag!='XForm']==expected_children for g in groups)
        assert fixed in [tree(c) for c in document.findall("Shape[@CutIndex='30']")]
        layout=load(directory/'layout.json');assert len(layout['placements'])==2
        preservation.append({'surface':surface,'file':files[0].relative_to(work).as_posix(),'sha256':digest(files[0]),
            'copies':2,'group_children_exact':True,'settings_notes_unknown_exact':True,'fixed_shape_exact':True})
    assert all((inputs/n).read_bytes()==(root/'crates/core/tests/fixtures'/n).read_bytes() for n in fixtures)
    assert source_digest()==product
    write(work/'checks.json',{'all_checks_pass':True,'artifact_commit':proof['release_commit'],
        'cli_sha256':digest(cli),'MCPB_sha256':digest(bundle),'production_digest':product,
        'CLI_stages':stages,'MCPB_checks':load(mcp/'checks.json'),'XML_preservation':preservation,
        'authored_inputs_only':True,'held_out_geometry_read':False,'new_quality_measurement':False,
        'repeat_export_byte_identical_both_surfaces':True,'milestone_closed':False})
    shutil.copyfile(__file__,work/'check-features.py')
    print(json.dumps({'actual_downloaded_CLI_and_MCPB_features_pass':True,'lead_contours':[10,8,2],
        'preserved_editable_group_copies_per_surface':2,'clear_rejections_per_surface':2}))
except BaseException:
    write(work/'failure.json',{'error':traceback.format_exc(),'stages':stages})
    raise
