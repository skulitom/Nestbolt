"""Extend the qualified stage reader for choices, requested time and neutral rejections."""
from pathlib import Path
import ast
root=Path(__file__).resolve().parents[1]
def adapt(s):return s.replace('h5-balanced-stage-20261018','h5-productive-stage-20261018').replace('h5_balanced_stage','h5_productive_stage').replace('h5-balanced-group-pilot-20261018','h5-productive-exchange-pilot-20261018').replace('h5_balanced_group_pilot','h5_productive_exchange_pilot').replace('BALANCED_DIAG ','PRODUCTIVE_DIAG ')
text=adapt((root/'scripts/h5_balanced_stage.py').read_text(encoding='utf-8'))
text=text.replace('Observe retained proposal identities, repair stages and immediate effects of the rejected balanced-pair candidate.','Observe available pair choices, requested repair time and rejection stages of the productive-exchange candidate.')
text=text.replace('Read-only retained proposal item identities, receiver/source losses, immediate material and last-sheet extent, final rejection stage. One stderr trace per invocation.','Read-only source inventory and bounded pair choices, receiver/source requested time and actual duration, losses, immediate material/extent and rejection stage. One stderr trace per invocation.')
text=text.replace("'forbidden_incoming_orientation'}","'forbidden_incoming_orientation','neutral_inventory_rejected'}")
needle="        positive(t['before_material']);positive(t['before_last_extent'])";assert text.count(needle)==1
text=text.replace(needle,needle+'''
        source=t['available_source_items'];choices=t['pair_choices']
        assert isinstance(source,list) and all(type(i) is int and i>=0 for i in source)
        assert isinstance(choices,list) and len(choices)<=6
        inventory=Counter(source)
        for pair in choices:
            assert isinstance(pair,list) and len(pair)==2 and pair[0]==pair[1]
            assert type(pair[0]) is int and inventory[pair[0]]>=2
        for key in ['exchange_remaining','pair_phase_remaining']:
            assert type(t[key]) in [int,float] and math.isfinite(t[key])
        assert abs(t['pair_phase_remaining']-max(0,t['exchange_remaining'])*.5)<=1e-9
''')
needle="            assert len(p['incoming_ids'])==(2 if p['paired'] else 1)";assert text.count(needle)==1
text=text.replace(needle,needle+"\n            assert not (Counter(p['incoming_ids'])-inventory)\n            if p['paired']:assert p['incoming_ids'] in choices")
needle="            outcome=a['outcome']";assert text.count(needle)==1
text=text.replace(needle,'''
            for stage in ['receiver','source']:
                remaining=a[stage+'_remaining'];elapsed=a[stage+'_elapsed']
                if a[stage+'_initial_loss'] is None:
                    assert remaining is None and elapsed is None
                else:
                    assert type(remaining) in [int,float] and math.isfinite(remaining)
                    assert type(elapsed) in [int,float] and math.isfinite(elapsed) and elapsed>=0
            outcome=a['outcome']''')
needle="                if outcome=='accepted':assert a['after_material']<=t['before_material']";assert text.count(needle)==1
text=text.replace(needle,'''                if outcome=='accepted':
                    assert a['after_material']<=t['before_material']
                    if neutral(p):assert a['after_material']<t['before_material']
                elif outcome=='neutral_inventory_rejected':
                    assert neutral(p) and a['after_material']==t['before_material']''')
needle="        assert counts['accepted']==stats.get('directed_exchanges',0)";assert text.count(needle)==1
text=text.replace(needle,needle+"\n        assert counts['neutral_inventory_rejected']==stats.get('neutral_exchange_rejections',0)")
target=root/'scripts/h5_productive_stage.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
compile(text,str(target),'exec')
# Retain the existing committed measurement method, changing observations only.
def functions(s):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
old=functions((root/'scripts/h5_balanced_stage.py').read_text(encoding='utf-8'));new=functions(text)
assert old['run']==new['run'] and old['neutral']==new['neutral']
check=adapt((root/'output/check_h5_balanced_stage_reader.py').read_text(encoding='utf-8'))
check=check.replace("'return_frame_keeps_incumbent_when_roundoff_increases_charged_material']","'return_frame_keeps_incumbent_when_roundoff_increases_charged_material',\n             'productive_exchange_rejects_unchanged_inventory_without_material_gain',\n             'productive_exchange_keeps_same_inventory_when_material_decreases']")
needle="assert all(not a['neutral_inventory'] for a in summary['attempt_rows'] if a['proposal']['paired'] and a['outcome']=='accepted')";assert check.count(needle)==1
check=check.replace(needle,"assert any(a['neutral_inventory'] and a['outcome']=='accepted' and a['before_material']-a['after_material']>99.9 for a in summary['attempt_rows'])\nassert any(a['outcome']=='neutral_inventory_rejected' for a in summary['attempt_rows'])")
needle="# Multiset equality retains multiplicity";idx=check.index(needle)
extra='''neutral_trace=next(t for t in all_traces if any(a['outcome']=='neutral_inventory_rejected' for a in t['attempts']))
def rejects_trace(name,mutate):
    t=copy.deepcopy(neutral_trace);mutate(t)
    try:runner.check_traces([t])
    except AssertionError:return name
    raise AssertionError('Reader accepted '+name)
def neutral_attempt(t):return next(a for a in t['attempts'] if a['outcome']=='neutral_inventory_rejected')
def neutral_proposal(t):return t['proposals'][neutral_attempt(t)['proposal_index']]
rejected += [
    rejects('negative receiver duration',lambda t:modify_attempt(t,receiver_elapsed=-1)),
    rejects('nonfinite source allowance',lambda t:modify_attempt(t,source_remaining=float('nan'))),
    rejects('nonexistent pair choice',lambda t:t['pair_choices'].append([999999,999999])),
    rejects('incorrect phase allocation',lambda t:t.update(pair_phase_remaining=t['pair_phase_remaining']+1)),
    rejects_trace('neutral equal-material accepted',lambda t:neutral_attempt(t).update(outcome='accepted')),
    rejects_trace('neutral rejection with different returned inventory',lambda t:neutral_proposal(t)['returned_ids'].__setitem__(0,999999)),
]
'''
check=check[:idx]+extra+check[idx:]
path=root/'output/check_h5_productive_stage_reader.py';path.write_text(check,encoding='utf-8',newline='\n');compile(check,str(path),'exec')
print('Diagnostic runner retains its measurement method; reader covers six real tests and fourteen malformed traces')
