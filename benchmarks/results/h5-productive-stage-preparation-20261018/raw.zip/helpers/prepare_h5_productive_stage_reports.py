"""Prepare evidence sealing and verification without starting measurements."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def adapt(s):return s.replace('h5-balanced-stage','h5-productive-stage').replace('h5_balanced_stage','h5_productive_stage')
s=adapt((root/'output/seal_h5_balanced_stage.py').read_text(encoding='utf-8'))
s=s.replace('97 passed; 0 failed','101 passed; 0 failed').replace("len(reader['authored_test_traces'])==4","len(reader['authored_test_traces'])==6").replace("len(reader['malformed_records_rejected'])==8","len(reader['malformed_records_rejected'])==14").replace("'optimized_core_tests_passed':97","'optimized_core_tests_passed':101").replace("'authored_test_traces':4,'malformed_records_rejected':8","'authored_test_traces':6,'malformed_records_rejected':14")
s=s.replace("'seal_h5_productive_stage.py']","'seal_h5_productive_stage.py','prepare_h5_productive_stage_reports.py']")
s=s.replace("inventory={name:","files['helpers/prior-identity-prepare.py']=root/'output/prepare_h5_balanced_stage.py'\ninventory={name:")
start=s.index("doc='''");end=s.index("\n(out.parent",start)
s=s[:start]+'''doc='''+repr('''# Productive-exchange choices and repair allocations — preparation, 2026-10-18

The [rejected candidate](h5-productive-exchange-pilot-20261018.md) passed all
72 geometry/export checks but still failed four material comparisons. It
rejected 45 equal-inventory swaps with no material saving and accepted only
one paired exchange. Those counters cannot locate the other failures.

This separate observer records available source item identities, the bounded
pair choices, retained proposals, attempted receiver/source repairs, requested
remaining time, elapsed wall duration, initial/final collision loss, immediate
material/last-sheet extent, and the final rejection stage. Neutral rejection
is distinguished from failed repair and material/geometry guards. Logged
remaining time can be negative; that does not establish any minimum necessary
repair time. Logging can perturb deadlines and trajectories.

Inserted observations reverse to the exact original source text. All other
149 files, candidate settings, budgets and the production tree are unchanged.
All 101 optimized core tests, strict lint and observer build pass. Six existing
authored tests cover 2-for-3 exchanges, failed repair, disabled/expired calls,
strict material rejection, neutral rejection and useful same-inventory swaps.
The reader rejects fourteen malformed traces and checks four identity multisets.
Trace counts must agree with all five saved exchange counters.

The plan records four serial mechanical observations, both kerfs, seed zero,
60 seconds per search, physical CCD0 CPU 8. Independent validation, public
exports, immutable ZIPs and a filled-outer audit remain required. This is
diagnosis, not a quality rerun of the failed candidate. Original failures,
the full 13-job requirement and +1% limit remain. No held-out inputs or
integration; H2/H5 remain open and completed weight stays 60%.
''')+s[end:]
start=s.index("with (root/'BENCHMARKS.md')");end=s.index("print(json.dumps",start)
entry='''

## 2026-10-18 — Qualify productive-exchange choice and time observations

[The diagnostic copy](benchmarks/results/h5-productive-stage-preparation-20261018.md)
passes 101 optimized core tests, strict lint/build, six real authored traces,
fourteen malformed-record checks and four identity-multiset checks. It records
available source item types, bounded pair choices, retained proposals, repair
losses and requested/elapsed time, validated material/extent and rejection
stage. Neutral rejections are separate from unsuccessful repair.

The committed plan opens four serial seed-zero 60-second mechanical searches.
The original candidate decisions and budgets remain; logging can perturb wall
deadlines, so this is not an earlier-trajectory replay or quality comparison.
Production, original limits and all failed outcomes remain; H2/H5 stay open
at 60% completed weight.
'''
s=s[:start]+"with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\\n') as f:f.write("+repr(entry)+")\n"+s[end:]
path=root/'output/seal_h5_productive_stage.py';path.write_text(s,encoding='utf-8',newline='\n');compile(s,str(path),'exec')
s=adapt((root/'output/finish_h5_balanced_stage.py').read_text(encoding='utf-8'))
s=s.replace('# Balanced-pair identities and immediate effects','# Productive-exchange choices and repair allocations')
s=s.replace("    'original part types move between sheets, repair stages and immediate',","    'original part types are available and move between sheets, requested repair',\n    'time, elapsed duration, rejection stages and immediate',")
index=s.index("(out.parent/(out.name+'.md')).write_text")
extra='''allocation=[]
for row in result['records']:
    traces=row['diagnosis']['traces'];valid=[t for t in traces if not t['disabled_or_expired'] and not t['baseline_invalid']]
    selected=[a for a in attempts if (a['job'],a['kerf_mm'])==(row['job'],row['kerf_mm'])]
    repairs=[a for a in selected if a['source_remaining'] is not None]
    itemsets=[dict(Counter(t['available_source_items'])) for t in valid]
    pairsets=[t['pair_choices'] for t in valid]
    allocation.append({'job':row['job'],'kerf_mm':row['kerf_mm'],'source_inventories':itemsets,
        'pair_choices':pairsets,'neutral_rejections':sum(a['outcome']=='neutral_inventory_rejected' for a in selected),
        'source_repairs':len(repairs),'source_failures':sum(a['outcome']=='source_repair_failed' for a in selected),
        'source_nonpositive_allowances':sum(a['source_remaining']<=0 for a in repairs),
        'source_remaining_range':([min(a['source_remaining'] for a in repairs),max(a['source_remaining'] for a in repairs)] if repairs else None),
        'source_elapsed_total':sum(a['source_elapsed'] for a in repairs),
        'source_elapsed_max':max((a['source_elapsed'] for a in repairs),default=0),
        'outcomes':row['diagnosis']['outcomes']})
write(out/'observed-allocations.json',{'records':allocation,'wall_durations_not_minimum_repair_time':True,'quality_claim':False})
lines += ['## Source choices and repair time','',
    '| Job | Kerf mm | Source inventory by original item ID | Pair choices by item ID | Neutral rejections | Source failures / repairs | Requested source time range, s | Total source time, s |',
    '| --- | ---: | --- | --- | ---: | ---: | --- | ---: |']
for r in allocation:
    lines.append(f"| {r['job']} | {r['kerf_mm']} | {r['source_inventories']} | {r['pair_choices']} | {r['neutral_rejections']} | {r['source_failures']} / {r['source_repairs']} | {r['source_remaining_range']} | {r['source_elapsed_total']:.6f} |")
lines += ['', 'Item IDs denote original model items; repeated IDs represent interchangeable',
    'copies. Retained choices are not necessarily attempted. Requested remaining',
    'time is logged immediately before each separator call and can be negative.',
    'Elapsed time can slightly overrun a checked deadline. These observations',
    'do not prove the minimum time needed or feasibility of failed assignments.','']
'''
s=s[:index]+extra+s[index:]
path=root/'output/finish_h5_productive_stage.py';path.write_text(s,encoding='utf-8',newline='\n');compile(s,str(path),'exec')
s=adapt((root/'output/audit_h5_balanced_stage.py').read_text(encoding='utf-8'));path=root/'output/audit_h5_productive_stage.py';path.write_text(s,encoding='utf-8',newline='\n');compile(s,str(path),'exec')
print('Diagnostic sealing, outcome verification and independent outer audit prepared')
