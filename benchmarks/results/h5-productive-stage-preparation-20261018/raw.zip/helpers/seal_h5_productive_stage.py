from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-productive-stage-20261018'
out=root/'benchmarks/results/h5-productive-stage-preparation-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_productive_stage as runner
load,write,digest=runner.load,runner.write,runner.digest
build=load(probe/'build.json');plan=load(probe/'preparation.json');reader=load(probe/'authored-trace-reader/checks.json')
assert build['all_passed'] and digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert digest(probe/'workspace'/plan['changed_file'])==build['source_sha256']
assert '101 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert runner.prior.source_digest()==plan['production_digest']
for row in plan['source_files']:
    assert digest(Path(plan['old_source'])/row['path'])==row['sha256']
    if row['path']!=plan['changed_file']:assert digest(probe/'workspace'/row['path'])==row['sha256']
assert reader['all_checks_pass'] and len(reader['authored_test_traces'])==6
assert len(reader['malformed_records_rejected'])==14 and reader['identity_multiset_checks']==4
assert reader['reader_sha256']==digest(root/'scripts/h5_productive_stage.py')
out.mkdir(exist_ok=False)
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_productive_stage.py','build_h5_productive_stage.py',
             'prepare_h5_productive_stage_runner.py','check_h5_productive_stage_reader.py','seal_h5_productive_stage.py','prepare_h5_productive_stage_reports.py']:
    files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_productive_stage.py'
files['helpers/prior-identity-prepare.py']=root/'output/prepare_h5_balanced_stage.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
raw=out/'raw.zip'
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(raw) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        b=z.read(name);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
for name in ['preparation.json','build.json','instrumentation.patch']:shutil.copyfile(probe/name,out/name)
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(raw),'bytes':raw.stat().st_size,'members':inventory,'crc_and_every_member_verified':True})
write(out/'checks.json',{'optimized_core_tests_passed':101,'strict_lint_passed':True,'observer_build_passed':True,
    'authored_test_traces':6,'malformed_records_rejected':14,'identity_multiset_checks':4,
    'production_and_rejected_candidate_unchanged':True,'measured_search_started':False,'quality_claim':False,'H5_complete':False})
doc='# Productive-exchange choices and repair allocations — preparation, 2026-10-18\n\nThe [rejected candidate](h5-productive-exchange-pilot-20261018.md) passed all\n72 geometry/export checks but still failed four material comparisons. It\nrejected 45 equal-inventory swaps with no material saving and accepted only\none paired exchange. Those counters cannot locate the other failures.\n\nThis separate observer records available source item identities, the bounded\npair choices, retained proposals, attempted receiver/source repairs, requested\nremaining time, elapsed wall duration, initial/final collision loss, immediate\nmaterial/last-sheet extent, and the final rejection stage. Neutral rejection\nis distinguished from failed repair and material/geometry guards. Logged\nremaining time can be negative; that does not establish any minimum necessary\nrepair time. Logging can perturb deadlines and trajectories.\n\nInserted observations reverse to the exact original source text. All other\n149 files, candidate settings, budgets and the production tree are unchanged.\nAll 101 optimized core tests, strict lint and observer build pass. Six existing\nauthored tests cover 2-for-3 exchanges, failed repair, disabled/expired calls,\nstrict material rejection, neutral rejection and useful same-inventory swaps.\nThe reader rejects fourteen malformed traces and checks four identity multisets.\nTrace counts must agree with all five saved exchange counters.\n\nThe plan records four serial mechanical observations, both kerfs, seed zero,\n60 seconds per search, physical CCD0 CPU 8. Independent validation, public\nexports, immutable ZIPs and a filled-outer audit remain required. This is\ndiagnosis, not a quality rerun of the failed candidate. Original failures,\nthe full 13-job requirement and +1% limit remain. No held-out inputs or\nintegration; H2/H5 remain open and completed weight stays 60%.\n'
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-productive-stage-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n## 2026-10-18 — Qualify productive-exchange choice and time observations\n\n[The diagnostic copy](benchmarks/results/h5-productive-stage-preparation-20261018.md)\npasses 101 optimized core tests, strict lint/build, six real authored traces,\nfourteen malformed-record checks and four identity-multiset checks. It records\navailable source item types, bounded pair choices, retained proposals, repair\nlosses and requested/elapsed time, validated material/extent and rejection\nstage. Neutral rejections are separate from unsuccessful repair.\n\nThe committed plan opens four serial seed-zero 60-second mechanical searches.\nThe original candidate decisions and budgets remain; logging can perturb wall\ndeadlines, so this is not an earlier-trajectory replay or quality comparison.\nProduction, original limits and all failed outcomes remain; H2/H5 stay open\nat 60% completed weight.\n')
print(json.dumps({'sealed_members':len(inventory),'bytes':raw.stat().st_size}))
