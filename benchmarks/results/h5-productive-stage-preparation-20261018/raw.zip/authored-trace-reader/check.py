"""Check the diagnostic reader against existing authored tests and malformed traces."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-productive-stage-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_productive_stage as runner
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_passed']
out=probe/'authored-trace-reader';out.mkdir(exist_ok=False)
target=Path(load(probe/'preparation.json')['target'])
binaries=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
binary=binaries[0];rows=[];all_traces=[]
for name in ['balanced_pair_moves_two_incoming_and_three_returns',
             'balanced_pair_without_return_room_preserves_incumbent',
             'balanced_pair_disabled_or_expired_preserves_incumbent',
             'return_frame_keeps_incumbent_when_roundoff_increases_charged_material',
             'productive_exchange_rejects_unchanged_inventory_without_material_gain',
             'productive_exchange_keeps_same_inventory_when_material_decreases']:
    command=[str(binary),'--exact','sheets::vstrip::exchange::tests::'+name,'--nocapture']
    result=subprocess.run(command,cwd=probe/'workspace',capture_output=True,timeout=120)
    (out/(name+'-stdout.log')).write_bytes(result.stdout);(out/(name+'-stderr.log')).write_bytes(result.stderr)
    row={'test':name,'command':command,'exit_code':result.returncode};rows.append(row)
    assert result.returncode==0,(name,result.stderr.decode(errors='replace'))
    traces=[json.loads(line.removeprefix('PRODUCTIVE_DIAG ')) for line in result.stderr.decode().splitlines() if line.startswith('PRODUCTIVE_DIAG ')]
    summary=runner.check_traces(traces);all_traces+=traces
    row.update({k:v for k,v in summary.items() if k not in ['traces','attempt_rows']})
    runner.write(out/'progress.json',rows)
summary=runner.check_traces(all_traces)
assert summary['paired_accepted']>=4
assert any(a['neutral_inventory'] and a['outcome']=='accepted' and a['before_material']-a['after_material']>99.9 for a in summary['attempt_rows'])
assert any(a['outcome']=='neutral_inventory_rejected' for a in summary['attempt_rows'])
assert any(a['outcome']=='source_repair_failed' for a in summary['attempt_rows'])
assert any(a['outcome']=='material_guard_failed' and a['after_material']>a['before_material'] for a in summary['attempt_rows'])
accepted=next(t for t in all_traces if any(a['outcome']=='accepted' for a in t['attempts']))
def modify_attempt(t,**values):
    next(a for a in t['attempts'] if a['outcome']=='accepted').update(values)
def accepted_proposal(t):
    return t['proposals'][next(a for a in t['attempts'] if a['outcome']=='accepted')['proposal_index']]
def rejects(name,mutate,stats=None):
    t=copy.deepcopy(accepted);mutate(t)
    try:runner.check_traces([t],stats)
    except AssertionError:return name
    raise AssertionError('Reader accepted '+name)
rejected=[
    rejects('accepted material increase',lambda t:modify_attempt(t,after_material=t['before_material']+1)),
    rejects('accepted unresolved source repair',lambda t:modify_attempt(t,source_loss=1)),
    rejects('out-of-range proposal index',lambda t:modify_attempt(t,proposal_index=len(t['proposals']))),
    rejects('incomplete paired obstruction set',lambda t:accepted_proposal(t).update(blockers=4)),
    rejects('nonfinite last extent',lambda t:modify_attempt(t,after_last_extent=float('nan'))),
    rejects('two different incoming part types',lambda t:accepted_proposal(t)['incoming_ids'].__setitem__(1,999999)),
    rejects('inconsistent attempt counters',lambda t:None,{'directed_exchange_attempts':999999}),
    rejects('unfinished observation',lambda t:modify_attempt(t,outcome='unfinished')),
]
neutral_trace=next(t for t in all_traces if any(a['outcome']=='neutral_inventory_rejected' for a in t['attempts']))
def rejects_trace(name,mutate):
    t=copy.deepcopy(neutral_trace);mutate(t)
    try:runner.check_traces([t])
    except AssertionError:return name
    raise AssertionError('Reader accepted '+name)
def neutral_attempt(t):return next(a for a in t['attempts'] if a['outcome']=='neutral_inventory_rejected')
def neutral_proposal(t):return t['proposals'][neutral_attempt(t)['proposal_index']]
rejected += [
    rejects('negative receiver duration',lambda t:modify_attempt(t,receiver_elapsed=-1)),
    rejects('nonfinite source allowance',lambda t:modify_attempt(t,source_remaining=float('nan'))),
    rejects('nonexistent pair choice',lambda t:t['pair_choices'].append([999999,999999])),
    rejects('incorrect phase allocation',lambda t:t.update(pair_phase_remaining=t['pair_phase_remaining']+1)),
    rejects_trace('neutral equal-material accepted',lambda t:neutral_attempt(t).update(outcome='accepted')),
    rejects_trace('neutral rejection with different returned inventory',lambda t:neutral_proposal(t)['returned_ids'].__setitem__(0,999999)),
]
# Multiset equality retains multiplicity and ignores ordering; geometry alone
# is not used to merge distinct original item identities.
assert runner.neutral({'incoming_ids':[4,4],'returned_ids':[4,4]})
assert runner.neutral({'incoming_ids':[1,4],'returned_ids':[4,1]})
assert not runner.neutral({'incoming_ids':[4,4],'returned_ids':[4]})
assert not runner.neutral({'incoming_ids':[4,4],'returned_ids':[5,5]})
record={'all_checks_pass':True,'test_binary_sha256':digest(binary),
    'reader_sha256':digest(root/'scripts/h5_productive_stage.py'),
    'authored_test_traces':rows,'malformed_records_rejected':rejected,
    'identity_multiset_checks':4,'strict_material_rejection_observed':True,
    'source_repair_failure_observed':True,'measured_development_searches':0,'quality_claim':False}
runner.write(out/'checks.json',record);shutil.copyfile(__file__,out/'check.py')
print(json.dumps(record))
