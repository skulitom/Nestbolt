"""One exact-inventory CP-SAT feasibility attempt on the independently audited finite pose pool."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from datetime import datetime,timezone
import copy,gzip,json,os,shutil,time,traceback
import ortools
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-contact-cpsat-20261018';SOURCE=ROOT/'output/h5-contact-placement-selection-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(OUT/'environment.json')['ready'];plan=load(OUT/'plan.json');assert ortools.__version__==plan['ortools_version'];shutil.copyfile(__file__,OUT/'solve.py');start=time.perf_counter()
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'pid':os.getpid(),'ortools_version':ortools.__version__,'source_sha256':digest(Path(__file__))})
    try:
        for name,h in plan['source_hashes'].items():assert digest(SOURCE/name)==h
        pool=load(SOURCE/'candidates.json');job=load(SOURCE/'job.json');warm=load(SOURCE/'warm-indices.json');audit=load(SOURCE/'audit/checks.json');assert audit['complete'] and audit['candidates_checked']==len(pool)
        model=cp_model.CpModel();variables=[model.new_bool_var(f'p{i}') for i in range(len(pool))];cliques=[]
        with gzip.open(SOURCE/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                ids=json.loads(line);model.add_at_most_one(variables[i] for i in ids);cliques.append(ids)
        for part in job['parts']:
            ids=[i for i,p in enumerate(pool) if p['placement']['part_id']==part['id']];model.add(sum(variables[i] for i in ids)==part['quantity'])
        for i in warm:model.add_hint(variables[i],1)
        error=model.validate();assert not error,error;assert model.export_to_file(str(OUT/'model.pbtxt'))
        write(OUT/'model-checks.json',{'valid_model':True,'boolean_candidates':len(pool),'at_most_one_cliques':len(cliques),'required_counts':{p['id']:p['quantity'] for p in job['parts']},'required_parts':sum(p['quantity'] for p in job['parts']),'positive_nonbinding_hints':len(warm),'objective':'None: complete original inventory is required for any feasible solution.','partial_layout_not_feasible_for_this_model':True,'model_sha256':digest(OUT/'model.pbtxt'),'preparation_seconds':time.perf_counter()-start})
        solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=plan['solver_seconds'];solver.parameters.num_search_workers=plan['workers'];solver.parameters.random_seed=plan['seed'];solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
        (OUT/'parameters.txt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');print((OUT/'model-checks.json').read_text(encoding='utf-8'),flush=True)
        with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n',buffering=1) as log:
            solver.log_callback=lambda line:log.write(line+'\n');start=time.perf_counter();status=solver.solve(model);seconds=time.perf_counter()-start
        (OUT/'response.txt').write_text(solver.response_stats(),encoding='utf-8',newline='\n');feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE]
        record={'status':solver.status_name(status),'status_code':int(status),'has_solution':feasible,'seconds':seconds,'reported_wall_seconds':solver.wall_time,'conflicts':solver.num_conflicts,'branches':solver.num_branches,'full_original_inventory_required':True,'geometry_acceptance_pending':feasible,'new_native_searches':0,'H5_complete':False}
        if feasible:
            selected=[i for i,v in enumerate(variables) if solver.value(v)];chosen=set(selected);assert all(sum(i in chosen for i in c)<=1 for c in cliques);counts=Counter(pool[i]['placement']['part_id'] for i in selected);assert counts==Counter({p['id']:p['quantity'] for p in job['parts']})
            original=load(SOURCE/'solve/selected-layout.json');layout={'version':1,'units':'mm','sheets':original['sheets'],'placements':[]};copies=Counter()
            for i in selected:
                p=copy.deepcopy(pool[i]['placement']);p['copy_index']=copies[p['part_id']];copies[p['part_id']]+=1;layout['placements'].append(p)
            write(OUT/'selected-indices.json',selected);write(OUT/'selected-layout.json',layout);record['selected_parts']=len(selected);record['counts']=dict(counts)
        else:record['selected_parts']=0;record['interpretation']='No complete selection returned. UNKNOWN is not infeasibility; any INFEASIBLE status concerns only this finite pool.'
        assert all(digest(SOURCE/name)==h for name,h in plan['source_hashes'].items());write(OUT/'result.json',record);print(json.dumps(record),flush=True)
    except Exception as e:write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()
