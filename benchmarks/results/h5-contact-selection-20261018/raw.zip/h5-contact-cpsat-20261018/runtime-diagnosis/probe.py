import faulthandler
faulthandler.enable()
import ortools
from ortools.sat.python import cp_model
print('version',ortools.__version__,flush=True)
model=cp_model.CpModel();x=model.new_bool_var('x');y=model.new_bool_var('y');model.add(x+y==1)
print('model_validation',repr(model.validate()),flush=True)
solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=2.;solver.parameters.num_search_workers=1;solver.parameters.log_search_progress=True
print('before_solve',flush=True)
status=solver.solve(model)
print('after_solve',solver.status_name(status),solver.value(x),solver.value(y),flush=True)
