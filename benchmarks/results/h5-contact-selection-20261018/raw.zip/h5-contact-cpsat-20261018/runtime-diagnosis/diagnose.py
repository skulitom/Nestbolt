"""Observe native CP-SAT startup on a tiny independent model; never rerun the interrupted packing model."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,traceback
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-contact-cpsat-20261018/runtime-diagnosis';PY=ROOT/'.cache/h5-cpsat-venv/Scripts/python.exe'
OUT.mkdir();(OUT/'diagnose.py').write_bytes(Path(__file__).read_bytes())
probe='''import faulthandler
faulthandler.enable()
import ortools
from ortools.sat.python import cp_model
print('version',ortools.__version__,flush=True)
model=cp_model.CpModel();x=model.new_bool_var('x');y=model.new_bool_var('y');model.add(x+y==1)
print('model_validation',repr(model.validate()),flush=True)
solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=2.;solver.parameters.num_search_workers=1;solver.parameters.log_search_progress=True
print('before_solve',flush=True)
status=solver.solve(model)
print('after_solve',solver.status_name(status),solver.value(x),solver.value(y),flush=True)
'''
(OUT/'probe.py').write_text(probe,encoding='utf-8',newline='\n');record={'utc':datetime.now(timezone.utc).isoformat(),'original_packing_process_observed_terminal':True,'original_wrapper_exit':1,'original_solver_status_missing':True,'original_solver_log_empty':True,'new_packing_attempts':0,'command':[str(PY),'-X','faulthandler',str(OUT/'probe.py')]}
try:
    cp=subprocess.run(record['command'],capture_output=True,timeout=15);(OUT/'stdout.log').write_bytes(cp.stdout);(OUT/'stderr.log').write_bytes(cp.stderr);record['returncode']=cp.returncode;record['unsigned_windows_code']=hex(cp.returncode&0xffffffff)
except subprocess.TimeoutExpired as e:
    (OUT/'stdout.log').write_bytes(e.stdout or b'');(OUT/'stderr.log').write_bytes(e.stderr or b'');record['timeout_seconds']=15
with (OUT/'result.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record),flush=True);print((OUT/'stdout.log').read_text(encoding='utf-8',errors='replace')[-4000:]);print((OUT/'stderr.log').read_text(encoding='utf-8',errors='replace')[-4000:])
