"""Prepare a pinned, isolated CP-SAT feasibility diagnostic for the audited finite placement pool."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,sys,traceback
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-contact-cpsat-20261018';ENV=ROOT/'.cache/h5-cpsat-venv';PY=ENV/'Scripts/python.exe';digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();assert not ENV.exists();(OUT/'prepare.py').write_bytes(Path(__file__).read_bytes())
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'method':'Use the independently verified 8798 candidate poses and 17097 conflict cliques. Require exactly every original family quantity, including all 15 cogs; no partial objective or rounded area coefficients. Supply the known 63 selected positions only as nonbinding positive hints. Solve once with CP-SAT, seed 0, eight offline CCD1 workers and a 120-second cap. Preserve UNKNOWN, infeasibility, invalid model, timeout and all missing results. Any found selection requires independent original geometry and the frozen public CLI. A solver conclusion applies only to this finite pool, never the global polygon problem.',
    'source_root':'output/h5-contact-placement-selection-20261018','source_hashes':{name:digest(ROOT/'output/h5-contact-placement-selection-20261018'/name) for name in ['candidates.json','cliques.jsonl.gz','conflicts.jsonl.gz','warm-indices.json','job.json','conditional-target.json','audit/checks.json']},
    'ortools_version':'9.15.6755','python_cp311_windows_wheel_expected_sha256':'781fb09d6c9f46015291f706bd7c7e0815db1bec6e92c74716342fb7ea2d0532','solver_seconds':120.,'workers':8,'seed':0,
    'scope':'Offline feasibility construction only. No production dependency, native packing run, H5 quality run, threshold, quantity, stock or production budget change.',
    'primary_references':['https://developers.google.com/optimization/cp/cp_solver','https://developers.google.com/optimization/cp/cp_tasks','https://github.com/google/or-tools/blob/stable/LICENSE','https://pypi.org/project/ortools/9.15.6755/'],'H5_complete':False})
try:
    with (OUT/'environment-build.log').open('xb') as log:
        cp=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),'-m','venv',str(ENV)],stdout=log,stderr=subprocess.STDOUT);assert cp.returncode==0
        cp=subprocess.run([str(PY),'-m','pip','install','--no-input','--index-url','https://pypi.org/simple','--only-binary=:all:','--report',str(OUT/'pip-report.json'),'ortools==9.15.6755'],stdout=log,stderr=subprocess.STDOUT);assert cp.returncode==0
    report=json.loads((OUT/'pip-report.json').read_bytes());item=next(p for p in report['install'] if p['metadata']['name']=='ortools');assert item['download_info']['archive_info']['hashes']['sha256']=='781fb09d6c9f46015291f706bd7c7e0815db1bec6e92c74716342fb7ea2d0532'
    freeze=subprocess.check_output([str(PY),'-m','pip','freeze']);(OUT/'requirements.txt').write_bytes(freeze)
    write(OUT/'environment.json',{'ready':True,'python':str(PY),'ortools_wheel_hash_verified':True,'packages':[{k:p['metadata'].get(k) for k in ['name','version','license','license_expression']} for p in report['install']]});print(json.dumps({'ready':True,'ortools':'9.15.6755','isolated_environment':str(ENV)}),flush=True)
except Exception as e:write(OUT/'setup-failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
