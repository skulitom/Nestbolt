"""Independently inspect exact-inventory model bytes and any returned original-geometry witness."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,gzip,itertools,json,math,re,shutil,subprocess,sys,traceback
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-contact-cpsat-cpython-20261018';OLD=ROOT/'output/h5-contact-cpsat-20261018';SOURCE=ROOT/'output/h5-contact-placement-selection-20261018';OUT=RUN/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(RUN/'plan.json');result=load(RUN/'result.json');pool=load(SOURCE/'candidates.json');job=load(SOURCE/'job.json');warm=load(SOURCE/'warm-indices.json')
    try:
        for name,h in plan['source_hashes'].items():assert digest(SOURCE/name)==h
        assert source_digest()=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
        assert (RUN/'model.pbtxt').read_bytes()==(OLD/'model.pbtxt').read_bytes();assert (RUN/'requirements.txt').read_bytes()==(OLD/'requirements.txt').read_bytes()
        assert load(OLD/'runtime-diagnosis/result.json')['unsigned_windows_code']=='0xc0000005' and load(RUN/'probe/result.json')['succeeded']
        text=(RUN/'model.pbtxt').read_text(encoding='utf-8');var_pattern=r'variables\s*\{\s*name:\s*"p(\d+)"\s*domain:\s*\[0, 1\]\s*\}'
        variables=re.findall(var_pattern,text);assert list(map(int,variables))==list(range(len(pool)))
        amo_pattern=r'constraints\s*\{\s*at_most_one\s*\{\s*literals:\s*\[([^\]]*)\]\s*\}\s*\}'
        amo=re.findall(amo_pattern,text,re.S);arrays=lambda s:json.loads('['+s+']')
        with gzip.open(SOURCE/'cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[json.loads(line) for line in f]
        assert [arrays(s) for s in amo]==cliques
        linear_pattern=r'constraints\s*\{\s*linear\s*\{\s*vars:\s*\[([^\]]*)\]\s*coeffs:\s*\[([^\]]*)\]\s*domain:\s*\[([^\]]*)\]\s*\}\s*\}'
        linear=re.findall(linear_pattern,text,re.S);assert len(linear)==len(job['parts'])
        for (ids,coeffs,domain),part in zip(linear,job['parts']):
            expected=[i for i,p in enumerate(pool) if p['placement']['part_id']==part['id']];assert arrays(ids)==expected and arrays(coeffs)==[1]*len(expected) and arrays(domain)==[part['quantity']]*2
        hint_pattern=r'solution_hint\s*\{\s*vars:\s*\[([^\]]*)\]\s*values:\s*\[([^\]]*)\]\s*\}'
        hints=re.findall(hint_pattern,text,re.S);assert len(hints)==1 and arrays(hints[0][0])==warm and arrays(hints[0][1])==[1]*len(warm)
        remainder=text
        for pattern in [var_pattern,amo_pattern,linear_pattern,hint_pattern]:remainder=re.sub(pattern,'',remainder,flags=re.S)
        assert not remainder.strip(),remainder[:200]
        record={'complete':True,'model_matches_original_before_runtime_failure':True,'dependency_versions_unchanged':True,'variables':len(pool),'verified_conflict_cliques':len(cliques),'exact_original_family_count_constraints':len(linear),'positive_nonbinding_hints':len(warm),
            'no_partial_objective_or_extra_model_constraints':True,'solver_status':result['status'],'solver_seconds':result['seconds'],'returned_complete_selection':result['has_solution'],'complete_target_witness':False,
            'original_runtime_failure_preserved':True,'standard_cpython_probe_passed':True,'candidate_geometry_and_graph_audit_sha256':digest(SOURCE/'audit/checks.json'),'production_digest':source_digest(),'new_native_searches':0,'H5_complete':False}
        if result['has_solution']:
            assert result['status'] in ['OPTIMAL','FEASIBLE'];layout=load(RUN/'selected-layout.json');selected=load(RUN/'selected-indices.json');chosen=set(selected);assert len(chosen)==len(selected)==66 and all(sum(i in chosen for i in c)<=1 for c in cliques)
            parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];target=load(SOURCE/'conditional-target.json');counts=Counter();geoms=[];tops=Counter();rows=[]
            for i,p in zip(selected,layout['placements']):
                expected={**pool[i]['placement'],'copy_index':counts[p['part_id']]};counts[p['part_id']]+=1;assert p==expected;t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);points=[]
                for x,y in parts[p['part_id']]['geometry'][0]['outer']:
                    if t['mirrored']:x=-x
                    points.append((c*x-s*y+t['translation'][0],s*x+c*y+t['translation'][1]))
                g=Polygon(points);assert g.is_valid;geoms.append(g);a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7;tops[p['sheet_id']]=max(tops[p['sheet_id']],d+m['top']+edge)
            assert counts==Counter({p['id']:p['quantity'] for p in job['parts']}) and len({(p['part_id'],p['copy_index']) for p in layout['placements']})==66
            for i,j in itertools.combinations(range(66),2):
                if layout['placements'][i]['sheet_id']!=layout['placements'][j]['sheet_id']:continue
                d=geoms[i].distance(geoms[j]);ov=geoms[i].intersection(geoms[j]).area;assert d>=job['clearance']-1e-7 and ov<=1e-7;rows.append({'a':i,'b':j,'distance_mm':d,'overlap_mm2':ov})
            with gzip.open(OUT/'all-selected-pairs.jsonl.gz','wt',encoding='utf-8',newline='\n') as f:
                for row in rows:f.write(json.dumps(row)+'\n')
            cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';command=[str(cli),'validate','--library',str(SOURCE/'library.json'),'--request',str(SOURCE/'request.json'),'--layout',str(RUN/'selected-layout.json')]
            cp=subprocess.run(command,capture_output=True,timeout=60);(OUT/'public.json').write_bytes(cp.stdout);(OUT/'public.stderr').write_bytes(cp.stderr);write(OUT/'public-command.json',{'command':command,'exit_code':cp.returncode});report=json.loads(cp.stdout);assert cp.returncode==0 and report['valid'];material=stock['width']*(stock['height']+tops['sheet-1']);assert material<=target['target_material_mm2']+1e-6
            record.update({'complete_target_witness':True,'original_public_job_valid':True,'original_parts':66,'independent_filled_outer_pairs_checked':len(rows),'source_height_mm':tops['sheet-1'],'material_area_mm2':material,'target_material_mm2':target['target_material_mm2']})
        else:
            assert result['status'] in ['UNKNOWN','INFEASIBLE'] and not (RUN/'selected-layout.json').exists();record['interpretation']='No complete layout returned. Any infeasibility status applies only to this finite candidate model; UNKNOWN is not infeasibility.'
        write(OUT/'checks.json',record);print(json.dumps(record),flush=True)
    except Exception as e:write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()
