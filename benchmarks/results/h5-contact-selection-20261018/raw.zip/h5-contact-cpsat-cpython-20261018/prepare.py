"""Test the same pinned solver under installed standard CPython, preserving the Anaconda-based failure."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,traceback
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-contact-cpsat-20261018';OUT=ROOT/'output/h5-contact-cpsat-cpython-20261018';ENV=ROOT/'.cache/h5-cpsat-cpython-venv';PY=ENV/'Scripts/python.exe';BASE=Path('C:/Users/artem/AppData/Local/Programs/Python/Python313/python.exe')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();assert not ENV.exists();shutil.copyfile(__file__,OUT/'prepare.py');original=json.loads((OLD/'plan.json').read_bytes())
original.update({'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'runtime_change':'Fresh environment from installed standard CPython 3.13.9, keeping OR-Tools 9.15.6755 and every Python dependency version pinned to the failed environment. First run the identical two-variable model. Run the packing model only if the probe succeeds; require its exported model bytes to match the original.',
    'failure_preserved':str(OLD),'old_probe_result_sha256':digest(OLD/'runtime-diagnosis/result.json'),'base_python':str(BASE),'python_cp313_windows_wheel_expected_sha256':'caac1d48b967adb877da2abcaf82c28f0f908a7cc208a6a1bbe01bc69590816c'})
write(OUT/'plan.json',original)
try:
    with (OUT/'environment-build.log').open('xb') as log:
        cp=subprocess.run([str(BASE),'-m','venv',str(ENV)],stdout=log,stderr=subprocess.STDOUT);assert cp.returncode==0
        cp=subprocess.run([str(PY),'-m','pip','install','--no-input','--index-url','https://pypi.org/simple','--only-binary=:all:','--report',str(OUT/'pip-report.json'),'-r',str(OLD/'requirements.txt')],stdout=log,stderr=subprocess.STDOUT);assert cp.returncode==0
    report=json.loads((OUT/'pip-report.json').read_bytes());item=next(p for p in report['install'] if p['metadata']['name']=='ortools');assert item['download_info']['archive_info']['hashes']['sha256']=='caac1d48b967adb877da2abcaf82c28f0f908a7cc208a6a1bbe01bc69590816c'
    freeze=subprocess.check_output([str(PY),'-m','pip','freeze']);(OUT/'requirements.txt').write_bytes(freeze);assert freeze==(OLD/'requirements.txt').read_bytes()
    probe=OUT/'probe';probe.mkdir();shutil.copyfile(OLD/'runtime-diagnosis/probe.py',probe/'probe.py');cp=subprocess.run([str(PY),'-X','faulthandler',str(probe/'probe.py')],capture_output=True,timeout=15);(probe/'stdout.log').write_bytes(cp.stdout);(probe/'stderr.log').write_bytes(cp.stderr)
    write(probe/'result.json',{'returncode':cp.returncode,'unsigned_windows_code':hex(cp.returncode&0xffffffff),'same_probe_source':digest(probe/'probe.py')==digest(OLD/'runtime-diagnosis/probe.py'),'succeeded':cp.returncode==0 and b'after_solve OPTIMAL' in cp.stdout})
    ready=cp.returncode==0 and b'after_solve OPTIMAL' in cp.stdout;write(OUT/'environment.json',{'ready':ready,'python':str(PY),'same_dependency_versions':True,'ortools_wheel_hash_verified':True,'probe_passed':ready})
    if ready:
        source=(ROOT/'output/solve_h5_contact_cpsat.py').read_text(encoding='utf-8').replace("OUT=ROOT/'output/h5-contact-cpsat-20261018'","OUT=ROOT/'output/h5-contact-cpsat-cpython-20261018'")
        needle="assert model.export_to_file(str(OUT/'model.pbtxt'))";assert source.count(needle)==1
        source=source.replace(needle,needle+";assert digest(OUT/'model.pbtxt')==digest(ROOT/'output/h5-contact-cpsat-20261018/model.pbtxt')")
        target=ROOT/'output/solve_h5_contact_cpsat_cpython.py';assert not target.exists();target.write_text(source,encoding='utf-8',newline='\n')
    print(json.dumps({'environment_ready':ready,'probe_returncode':cp.returncode,'same_dependencies':True}),flush=True)
except Exception as e:write(OUT/'setup-failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
