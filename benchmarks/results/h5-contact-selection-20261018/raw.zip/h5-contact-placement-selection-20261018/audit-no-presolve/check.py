"""Check a changed solver configuration using the already audited immutable candidate model."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,itertools,json,math,shutil,subprocess,sys,traceback
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-contact-placement-selection-20261018'
assert len(sys.argv)==2 and sys.argv[1] in ['warm','no-presolve'];NAME=sys.argv[1];SOLVE=RUN/('solve-'+NAME);OUT=RUN/('audit-'+NAME)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'check.py');baseline=load(RUN/'audit/checks.json');opened=load(SOLVE/'opened.json');result=load(SOLVE/'result.json');layout=load(SOLVE/'selected-layout.json')
    try:
        assert baseline['complete'] and opened['input_hashes']==load(RUN/'solve/opened.json')['input_hashes']
        for p,h in opened['input_hashes'].items():assert digest(RUN/p)==h
        assert source_digest()==baseline['production_digest']=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
        assert load(SOLVE/'starting-solution.json')['full_starting_vector_accepted'] and load(SOLVE/'preflight.json')['equivalent_binary_model_verified']
        same=(SOLVE/'selected-layout.json').read_bytes()==(RUN/'solve/selected-layout.json').read_bytes()
        if same:
            record={**baseline,'reuse':'Whole candidate graph and selected original-layout checks reused from the completed audit. Model input hashes and selected layout bytes are exactly identical. No geometry or public CLI rerun.',
                'reused_files':{p.name:digest(p) for p in (RUN/'audit').iterdir() if p.is_file()},'solver_status':result['status'],'solver_seconds':result['seconds'],'has_solver_incumbent':result['has_incumbent'],'native_info':load(SOLVE/'native-info.json'),'selected_layout_bytes_unchanged':True}
        else:
            pool=load(RUN/'candidates.json');job=load(RUN/'job.json');parts={p['id']:p for p in job['parts']};indices=load(SOLVE/'selected-indices.json');counts=Counter();geoms=[]
            assert len(indices)==len(set(indices))==len(layout['placements'])
            for i,p in zip(indices,layout['placements']):
                expected={**pool[i]['placement'],'copy_index':counts[p['part_id']]};counts[p['part_id']]+=1;assert p==expected;t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);points=[]
                for x,y in parts[p['part_id']]['geometry'][0]['outer']:
                    if t['mirrored']:x=-x
                    points.append((c*x-s*y+t['translation'][0],s*x+c*y+t['translation'][1]))
                g=Polygon(points);assert g.is_valid;geoms.append(g)
            pairs=[]
            for i,j in itertools.combinations(range(len(indices)),2):
                if layout['placements'][i]['sheet_id']!=layout['placements'][j]['sheet_id']:continue
                d=geoms[i].distance(geoms[j]);ov=geoms[i].intersection(geoms[j]).area;assert d>=job['clearance']-1e-7 and ov<=1e-7;pairs.append({'a':i,'b':j,'distance_mm':d,'overlap_mm2':ov})
            missing=Counter({p['id']:p['quantity'] for p in job['parts']})-counts;assert dict(missing)==result['missing'];assert all(counts[k]<=p['quantity'] for k,p in parts.items()) and counts['frame']==parts['frame']['quantity']
            with gzip.open(OUT/'selected-pairs.jsonl.gz','wt',encoding='utf-8',newline='\n') as f:
                for p in pairs:f.write(json.dumps(p)+'\n')
            cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';command=[str(cli),'validate','--library',str(RUN/'library.json'),'--request',str(RUN/'request.json'),'--layout',str(SOLVE/'selected-layout.json')]
            cp=subprocess.run(command,capture_output=True,timeout=60);(OUT/'public.json').write_bytes(cp.stdout);(OUT/'public.stderr').write_bytes(cp.stderr);write(OUT/'public-command.json',{'command':command,'exit_code':cp.returncode});public=json.loads(cp.stdout);assert public['valid']==(not missing);codes=Counter(v['code'] for v in public['violations'])
            if missing:assert set(codes)=={'quantity'},codes
            record={'complete':True,'candidate_and_graph_audit_reused_sha256':digest(RUN/'audit/checks.json'),'all_candidate_stock_orientations_and_cliques_unchanged':True,'selected_layout_bytes_unchanged':False,'selected_pairs_checked':len(pairs),'selected_geometry_valid':True,'original_public_job_valid':public['valid'],'public_violation_codes':dict(codes),'missing':dict(missing),'complete_target_witness':not missing,'solver_status':result['status'],'solver_seconds':result['seconds'],'has_solver_incumbent':result['has_incumbent'],'native_info':load(SOLVE/'native-info.json'),'production_digest':source_digest(),'new_native_searches':0,'H5_complete':False}
        assert record['missing']==result['missing'];write(OUT/'checks.json',record);print(json.dumps({k:v for k,v in record.items() if k not in ['reused_files','native_info']}),flush=True)
    except Exception as e:write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()
