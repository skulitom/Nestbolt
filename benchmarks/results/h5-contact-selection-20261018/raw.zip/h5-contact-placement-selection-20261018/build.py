"""Build a new finite placement pool from sheet symmetry and original-outline contacts."""
from pathlib import Path
from hashlib import sha256
from collections import Counter,deque
from datetime import datetime,timezone
import copy,gzip,heapq,importlib.util,itertools,json,math,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import Polygon,box,mapping
from shapely.affinity import translate
from shapely.strtree import STRtree
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-saved-placement-selection-20261018';OUT=ROOT/'output/h5-contact-placement-selection-20261018'
CONTACTS_PER_FAMILY=900;GEN_SECONDS=120.;CLIQUE_SECONDS=30.;SOLVE_SECONDS=120.;TOL=1e-7
spec=importlib.util.spec_from_file_location('gap',ROOT/'output/diagnose_h5_concave_gaps.py');gap=importlib.util.module_from_spec(spec);spec.loader.exec_module(gap)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();job=load(OLD/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];height=load(OLD/'conditional-target.json')['required_used_height_mm'];prior=load(OLD/'candidates.json');warm=load(OLD/'selected-indices.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,
        'sources':{str(p.relative_to(ROOT)):digest(p) for p in [OLD/'candidates.json',OLD/'selected-indices.json',OLD/'selected-layout.json',OLD/'job.json',OLD/'conditional-target.json',Path(gap.__file__)]},
        'generation':'Retain all prior unrounded candidates. Add each candidate rotated 180 degrees about its own original target-sheet centre, preserving allowed rotations and never reflecting parts. Against each of the 63 selected prior placements and their half-turns, construct conservative original-outline Minkowski contact regions for each allowed quarter-turn/reflection template; cogs sample phases 0, 4.5, 9, 13.5 degrees. Retain all contact vertices plus intersections with the target-sheet translation domain. Candidate selection cycles over all queries for each family, taking spread boundary samples across the entire ordered vertex ring instead of only three low vertices, up to 900 new unique candidates per family. Validate every inserted pose against stock and its generating anchor. Keep unrounded source coordinates. Deduplication uses the previous rounded identity key only; discarded alternatives do not justify global claims.',
        'contact_generation_seconds_cap':GEN_SECONDS,'new_contacts_per_family_cap':CONTACTS_PER_FAMILY,'maximum_candidates':2*len(prior)+len(parts)*CONTACTS_PER_FAMILY,
        'conflict_model':'Actual filled-outer distances define pair conflicts at unchanged clearance. Compress edges into pairwise verified cliques, retaining all uncovered edges after 30 seconds. For binary variables this is exactly equivalent to the pair graph. Verify the saved partial as feasible. Select at most original family quantities, exactly all frames, and at least the known partial filled area; maximize covered area with a 120-second solve. Preserve timeout, incomplete inventory and any geometric failures.',
        'clique_compression_seconds_cap':CLIQUE_SECONDS,'solver_seconds_cap':SOLVE_SECONDS,'acceptance_tolerance_mm':TOL,
        'original_geometry_stock_quantity_and_targets_unchanged':True,'new_native_searches':0,'quality_runs':0,'production_budget_changed':False,'H5_complete':False})
    for name in ['job.json','library.json','request.json','conditional-target.json']:shutil.copyfile(OLD/name,OUT/name)
    try:
        originals={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};areas={k:g.area for k,g in originals.items()};pool=[];gs=[];keys={};omitted=Counter();mirror_of={}
        def add(p,source,anchor=None):
            p=copy.deepcopy(p);p.pop('copy_index',None);t=p['transform'];part=parts[p['part_id']];g=gap.pose(originals[p['part_id']],t)
            assert g.is_valid and not t['mirrored'] or (g.is_valid and part['allow_mirror'])
            if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else height
            if a<m['left']+edge-TOL or b<m['bottom']+edge-TOL or c>stock['width']-m['right']-edge+TOL or d>h-m['top']-edge+TOL:omitted['outside']+=1;return None
            if anchor is not None and (g.distance(gs[anchor])<job['clearance']-TOL or g.intersection(gs[anchor]).area>TOL):omitted['anchor_conflict']+=1;return None
            key=(p['part_id'],p['sheet_id'],t['mirrored'],round(t['rotation_radians']%math.tau,12),*(round(x,10) for x in t['translation']))
            if key in keys:omitted['duplicate']+=1;return keys[key]
            i=len(pool);keys[key]=i;pool.append({'index':i,'placement':p,'source':source,'filled_area_mm2':areas[p['part_id']]});gs.append(g);return i
        for i,p in enumerate(prior):assert add(p['placement'],{'kind':'prior-pool','index':i})==i
        for i,p in enumerate(prior):
            q=copy.deepcopy(p['placement']);t=q['transform'];h=stock['height'] if q['sheet_id']=='sheet-0' else height;t['rotation_radians']+=math.pi;t['translation']=[stock['width']-t['translation'][0],h-t['translation'][1]]
            j=add(q,{'kind':'half-turn','prior_index':i,'sheet_width_mm':stock['width'],'sheet_height_mm':h});assert j is not None;mirror_of[i]=j
        anchors=list(dict.fromkeys(warm+[mirror_of[i] for i in warm]));write(OUT/'warm-indices.json',warm);write(OUT/'anchor-indices.json',anchors)
        templates=[]
        for family,part in parts.items():
            angles=part['rotations']['degrees'] if part['rotations']['kind']=='list' else [0.,4.5,9.,13.5]
            for reflected in ([False,True] if part['allow_mirror'] else [False]):
                for angle in angles:
                    t={'rotation_radians':math.radians(angle),'translation':[0.,0.],'mirrored':reflected};g=gap.pose(originals[family],t);a,b,_,_=g.bounds;t['translation']=[-a,-b];g=translate(g,-a,-b)
                    # Keep mirror choices even when an outline happens to be symmetric.
                    templates.append({'id':len(templates),'part_id':family,'transform':t,'shape':g})
        write(OUT/'templates.json',[{k:v for k,v in t.items() if k!='shape'} for t in templates]);cache={};queries=[];byfamily={k:[] for k in parts};expired=False;genstart=time.perf_counter();(OUT/'obstacles').mkdir()
        for anchor in anchors:
            ag=gs[anchor];ax,ay=ag.bounds[:2];fixed=translate(ag,-ax,-ay);ap=pool[anchor]['placement'];h=stock['height'] if ap['sheet_id']=='sheet-0' else height
            for t in templates:
                if time.perf_counter()-genstart>=GEN_SECONDS:expired=True;break
                moving=t['shape'];w,ph=moving.bounds[2:];limits=[m['left']+edge,m['bottom']+edge,stock['width']-m['right']-edge-w,h-m['top']-edge-ph]
                if limits[0]>=limits[2] or limits[1]>=limits[3]:continue
                key=(fixed.wkb,moving.wkb)
                if key not in cache:
                    region=gap.obstacle(fixed,moving,job['clearance']);idx=len(cache);cache[key]=(idx,region);write(OUT/'obstacles'/f'{idx:04}.json',{'anchor':anchor,'template':t['id'],'shape':mapping(region)})
                oi,region=cache[key];world=translate(region,ax,ay);domain=box(*limits);line=world.boundary.intersection(domain);points=[]
                def vertices(g):
                    if g.is_empty:return
                    if g.geom_type=='Point':points.append((g.x,g.y))
                    elif g.geom_type in ['LineString','LinearRing']:points.extend(list(g.coords))
                    elif hasattr(g,'geoms'):
                        for piece in g.geoms:vertices(piece)
                vertices(line);points=sorted(set(points),key=lambda p:math.atan2(p[1]-ay,p[0]-ax))
                if not points:continue
                # Interleave evenly spread quantiles, retaining every point eventually.
                ordered=[];seen=set();length=len(points)
                for denominator in [4,8,16,32,64,128,256,512,1024]:
                    for k in range(denominator):
                        idx=k*length//denominator
                        if idx not in seen:seen.add(idx);ordered.append(idx)
                    if len(seen)==length:break
                ordered.extend(i for i in range(length) if i not in seen)
                q={'id':len(queries),'anchor':anchor,'template':t['id'],'obstacle':oi,'sheet_id':ap['sheet_id'],'points':points,'order':ordered};queries.append(q);byfamily[t['part_id']].append(q)
            if expired:break
        write(OUT/'contact-queries.json',queries);added=Counter();selected_contact_points=[]
        for family,qs in byfamily.items():
            pending=deque((q,0) for q in qs)
            while pending and added[family]<CONTACTS_PER_FAMILY:
                q,k=pending.popleft();point_index=q['order'][k];x,y=q['points'][point_index];t=templates[q['template']];transform=copy.deepcopy(t['transform']);transform['translation']=[transform['translation'][0]+x,transform['translation'][1]+y]
                before=len(pool);i=add({'part_id':family,'sheet_id':q['sheet_id'],'transform':transform},{'kind':'contact','query':q['id'],'point':point_index},q['anchor'])
                if len(pool)>before:added[family]+=1;selected_contact_points.append({'index':i,'query':q['id'],'point':point_index})
                if k+1<len(q['order']):pending.append((q,k+1))
        write(OUT/'candidates.json',pool);write(OUT/'selected-contact-points.json',selected_contact_points)
        generation={'candidates':len(pool),'prior_candidates':len(prior),'after_prior_and_symmetry':len(pool)-sum(added.values()),'anchors':len(anchors),'templates':len(templates),'queries':len(queries),'obstacles':len(cache),'contact_additions':dict(added),'generation_expired':expired,'generation_seconds':time.perf_counter()-genstart,'omitted':dict(omitted)}
        write(OUT/'generation.json',generation);print(json.dumps({'phase':'pool_built',**generation}),flush=True)
        n=len(pool);adj=[0]*n;edges=[];gsarray=np.asarray(gs,dtype=object);distance_checks=0
        for sheet in ['sheet-0','sheet-1']:
            ids=np.asarray([i for i,p in enumerate(pool) if p['placement']['sheet_id']==sheet]);selected_geoms=gsarray[ids];tree=STRtree(selected_geoms);pairs=tree.query(selected_geoms,predicate='dwithin',distance=job['clearance']+TOL);pairs=pairs[:,pairs[0]<pairs[1]];distance_checks+=pairs.shape[1]
            distances=shapely.distance(selected_geoms[pairs[0]],selected_geoms[pairs[1]]);pairs=pairs[:,distances<job['clearance']-TOL]
            for i,j in zip(ids[pairs[0]],ids[pairs[1]]):
                i,j=int(i),int(j);adj[i]|=1<<j;adj[j]|=1<<i;edges.append((i,j))
        edges.sort();assert len(edges)==sum(x.bit_count() for x in adj)//2;warmmask=sum(1<<i for i in warm);assert all(not(adj[i]&warmmask) for i in warm)
        with gzip.open(OUT/'conflicts.jsonl.gz','wt',encoding='utf-8',newline='\n') as f:
            for pair in edges:f.write(json.dumps(pair)+'\n')
        print(json.dumps({'phase':'graph_built','edges':len(edges),'seconds':time.perf_counter()-start}),flush=True)
        # Every emitted clique consists only of original conflict edges. Removing
        # its edges and retaining all residual pairs preserves the binary model.
        remaining=adj.copy();heap=[(-mask.bit_count(),i) for i,mask in enumerate(remaining) if mask];heapq.heapify(heap);cliques=[];cstart=time.perf_counter();covered=0
        while heap and time.perf_counter()-cstart<CLIQUE_SECONDS:
            degree,i=heapq.heappop(heap)
            if -degree!=remaining[i].bit_count():continue
            choices=remaining[i]
            if not choices:continue
            clique=[i];mask=1<<i
            while choices:
                sample=list(itertools.islice(bits(choices),16));j=max(sample,key=lambda v:((adj[v]&choices).bit_count(),-v));clique.append(j);mask|=1<<j;choices&=adj[j]
            assert len(clique)>=2 and all((mask^(1<<j))&~adj[j]==0 for j in clique)
            cliques.append(clique)
            for j in clique:
                oldcount=remaining[j].bit_count();remaining[j]&=~mask;newcount=remaining[j].bit_count();covered+=oldcount-newcount
                if newcount:heapq.heappush(heap,(-newcount,j))
        compressed=len(cliques);residual=0
        for i,mask in enumerate(remaining):
            for j in bits(mask&~((1<<(i+1))-1)):cliques.append([i,j]);residual+=1
        assert covered//2+residual==len(edges)
        with gzip.open(OUT/'cliques.jsonl.gz','wt',encoding='utf-8',newline='\n') as f:
            for clique in cliques:assert sum(i in warm for i in clique)<=1;f.write(json.dumps(clique)+'\n')
        matrix_nonzeros=sum(map(len,cliques))+2*n;areas=[p['filled_area_mm2'] for p in pool]
        model={'candidates':n,'conflict_edges':len(edges),'pair_distances_checked':distance_checks,'compressed_cliques':compressed,'residual_pair_constraints':residual,'all_conflict_constraints':len(cliques),'covered_edges':covered//2,
            'clique_compression_seconds':time.perf_counter()-cstart,'clique_compression_time_limit_reached':bool(heap),'all_edges_covered_exactly':True,'warm_certificate_valid':True,'matrix_nonzeros':matrix_nonzeros,
            'known_partial_area_mm2':sum(areas[i] for i in warm),'required_total_area_mm2':sum(areas0*parts[k]['quantity'] for k,areas0 in {k:g.area for k,g in originals.items()}.items()),'preparation_seconds':time.perf_counter()-start}
        write(OUT/'model.json',model);print(json.dumps({'phase':'model_ready',**model}),flush=True)
    except Exception as e:write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()
