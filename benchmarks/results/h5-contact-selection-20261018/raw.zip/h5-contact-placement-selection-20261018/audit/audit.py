"""Independently reconstruct the expanded pool and verify all conflicts, cliques and selected geometry."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,gzip,itertools,json,math,shutil,subprocess,sys,traceback
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-contact-placement-selection-20261018';OLD=ROOT/'output/h5-saved-placement-selection-20261018';OUT=RUN/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'scripts'));from h2_import_audit import source_digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(RUN/'plan.json');pool=load(RUN/'candidates.json');model=load(RUN/'model.json');result=load(RUN/'solve/result.json');job=load(RUN/'job.json');layout=load(RUN/'solve/selected-layout.json');selected=load(RUN/'solve/selected-indices.json')
    try:
        for p,h in plan['sources'].items():assert digest(ROOT/p)==h
        for p,h in load(RUN/'solve/opened.json')['input_hashes'].items():assert digest(RUN/p)==h
        assert source_digest()=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
        parts={p['id']:p for p in job['parts']};original={k:np.asarray(p['geometry'][0]['outer']) for k,p in parts.items()};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];height=load(RUN/'conditional-target.json')['required_used_height_mm']
        oldpool=load(OLD/'candidates.json');queries=load(RUN/'contact-queries.json');templates=load(RUN/'templates.json');geoms=[];bounds=[];sources=Counter();anchor_gaps=[]
        for i,p in enumerate(pool):
            assert p['index']==i;source=p['source'];kind=source['kind'];sources[kind]+=1
            if kind=='prior-pool':expected=oldpool[source['index']]['placement']
            elif kind=='half-turn':
                expected=copy.deepcopy(oldpool[source['prior_index']]['placement']);t=expected['transform'];t['rotation_radians']+=math.pi;h=stock['height'] if expected['sheet_id']=='sheet-0' else height;t['translation']=[stock['width']-t['translation'][0],h-t['translation'][1]]
            else:
                assert kind=='contact';q=queries[source['query']];template=templates[q['template']];t=copy.deepcopy(template['transform']);x,y=q['points'][source['point']];t['translation']=[t['translation'][0]+x,t['translation'][1]+y];expected={'part_id':template['part_id'],'sheet_id':q['sheet_id'],'transform':t}
            assert p['placement']==expected,i;placement=p['placement'];t=placement['transform'];part=parts[placement['part_id']];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mirror=-1. if t['mirrored'] else 1.
            vertices=original[placement['part_id']]@np.array([[mirror*c,mirror*s],[-s,c]])+np.asarray(t['translation']);g=Polygon(vertices);assert g.is_valid;geoms.append(g);bounds.append(g.bounds)
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            a,b,c,d=g.bounds;h=stock['height'] if placement['sheet_id']=='sheet-0' else height;assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
            if kind=='contact':
                anchor=queries[source['query']]['anchor'];assert anchor<i and pool[anchor]['placement']['sheet_id']==placement['sheet_id'];distance=g.distance(geoms[anchor]);assert distance>=job['clearance']-1e-7 and g.intersection(geoms[anchor]).area<=1e-7;anchor_gaps.append(distance)
        write(OUT/'candidate-checks.json',{'candidates':len(pool),'provenance':dict(sources),'all_source_transforms_exact':True,'all_individual_stock_and_orientation_checks_pass':True,'contact_anchor_distances':len(anchor_gaps),'minimum_anchor_distance_mm':min(anchor_gaps)})
        n=len(pool);actual=[0]*n;recorded=[0]*n;bounds=np.asarray(bounds);sheets=np.asarray([p['placement']['sheet_id'] for p in pool]);gs=np.asarray(geoms,dtype=object);pairs=0;near=0;edges=0
        # Independent exhaustive pair enumeration; no producer spatial index.
        for i,g in enumerate(geoms):
            js=np.arange(i+1,n);js=js[sheets[js]==sheets[i]];pairs+=len(js);dx=np.maximum(0,np.maximum(bounds[js,0]-bounds[i,2],bounds[i,0]-bounds[js,2]));dy=np.maximum(0,np.maximum(bounds[js,1]-bounds[i,3],bounds[i,1]-bounds[js,3]));js=js[np.hypot(dx,dy)<=job['clearance']+1e-7];near+=len(js);distances=shapely.distance(g,gs[js])
            for j in js[distances<job['clearance']-1e-7]:j=int(j);actual[i]|=1<<j;actual[j]|=1<<i;edges+=1
        with gzip.open(RUN/'conflicts.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                i,j=json.loads(line);assert i<j and not(recorded[i]&(1<<j));recorded[i]|=1<<j;recorded[j]|=1<<i
        assert actual==recorded and edges==model['conflict_edges'];uncovered=actual.copy();cliques=0
        with gzip.open(RUN/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                ids=json.loads(line);mask=sum(1<<i for i in ids);assert mask.bit_count()==len(ids)
                for i in ids:assert (mask^(1<<i))&~actual[i]==0;uncovered[i]&=~mask
                cliques+=1
        assert not any(uncovered) and cliques==model['all_conflict_constraints'];mask=sum(1<<i for i in selected);assert mask.bit_count()==len(selected) and all(not(actual[i]&mask) for i in selected)
        counts=Counter();selected_pairs=[];tops=Counter()
        assert len(layout['placements'])==len(selected)
        for i,p in zip(selected,layout['placements']):
            expected=copy.deepcopy(pool[i]['placement']);expected['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;assert p==expected;tops[p['sheet_id']]=max(tops[p['sheet_id']],geoms[i].bounds[3]+m['top']+edge)
        missing=Counter({p['id']:p['quantity'] for p in job['parts']})-counts;assert dict(missing)==result['missing'] and counts['frame']==parts['frame']['quantity'];assert all(counts[k]<=p['quantity'] for k,p in parts.items())
        for i,j in itertools.combinations(selected,2):
            if sheets[i]!=sheets[j]:continue
            a,b=geoms[i],geoms[j];distance=a.distance(b);overlap=a.intersection(b).area;assert distance>=job['clearance']-1e-7 and overlap<=1e-7;selected_pairs.append({'a':i,'b':j,'distance_mm':distance,'overlap_mm2':overlap})
        with gzip.open(OUT/'selected-pairs.jsonl.gz','wt',encoding='utf-8',newline='\n') as f:
            for p in selected_pairs:f.write(json.dumps(p)+'\n')
        cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
        command=[str(cli),'validate','--library',str(RUN/'library.json'),'--request',str(RUN/'request.json'),'--layout',str(RUN/'solve/selected-layout.json')];cp=subprocess.run(command,capture_output=True,timeout=60);(OUT/'public.json').write_bytes(cp.stdout);(OUT/'public.stderr').write_bytes(cp.stderr);write(OUT/'public-command.json',{'command':command,'exit_code':cp.returncode});public=json.loads(cp.stdout);assert public['valid']==(not missing)
        codes=Counter(v['code'] for v in public['violations'])
        if missing:assert set(codes)=={'quantity'},codes
        material=stock['width']*(stock['height']+tops['sheet-1']);assert material<=load(RUN/'conditional-target.json')['target_material_mm2']+1e-6
        checks={'complete':True,'candidate_provenance_exact':True,'candidates_checked':n,'candidate_sources':dict(sources),'contact_anchor_checks':len(anchor_gaps),'all_same_sheet_candidate_pairs_enumerated':pairs,'candidate_pairs_geometrically_checked':near,'conflict_edges_verified':edges,'equivalent_cliques_verified':cliques,
            'selected_pairs_checked':len(selected_pairs),'selected_geometry_valid':True,'original_public_job_valid':public['valid'],'public_violation_codes':dict(codes),'missing':dict(missing),'complete_target_witness':not missing,'source_height_mm':tops['sheet-1'],'material_at_original_full_first_sheet_mm2':material,
            'solver_status':result['status'],'solver_seconds':result['seconds'],'production_digest':source_digest(),'new_native_searches':0,'H5_complete':False}
        write(OUT/'checks.json',checks);print(json.dumps(checks),flush=True)
    except Exception as e:write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()
