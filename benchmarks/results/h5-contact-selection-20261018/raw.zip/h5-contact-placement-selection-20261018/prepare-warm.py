"""Prepare a changed-input diagnostic: pass the already verified partial as an explicit HiGHS incumbent."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-contact-placement-selection-20261018'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
source=ROOT/'output/solve_h5_contact_selection.py';s=source.read_text(encoding='utf-8')
old="        result=milp(c=-areas/total,integrality=np.ones(n),bounds=Bounds(0,1),constraints=LinearConstraint(matrix,np.asarray(lower),np.asarray(upper)),options={'time_limit':plan['solver_seconds_cap'],'mip_rel_gap':0.})"
new='''        from scipy.optimize._highspy import _core as hc
        from types import SimpleNamespace
        lp=hc.HighsLp();lp.num_col_=n;lp.num_row_=matrix.shape[0];lp.a_matrix_.num_col_=n;lp.a_matrix_.num_row_=matrix.shape[0]
        lp.a_matrix_.format_=hc.MatrixFormat.kColwise;lp.col_cost_=-areas/total;lp.col_lower_=np.zeros(n);lp.col_upper_=np.ones(n);lp.row_lower_=np.asarray(lower);lp.row_upper_=np.asarray(upper)
        lp.a_matrix_.start_=matrix.indptr;lp.a_matrix_.index_=matrix.indices;lp.a_matrix_.value_=matrix.data;lp.integrality_=[hc.HighsVarType.kInteger]*n
        highs=hc._Highs();assert highs.version()=='1.12.0'
        for key,value in [('time_limit',plan['solver_seconds_cap']),('mip_rel_gap',0.),('log_to_console',False),('log_file',str(OUT/'highs.log'))]:assert highs.setOptionValue(key,value)==hc.HighsStatus.kOk
        assert highs.passModel(lp)==hc.HighsStatus.kOk
        actual=highs.getModel().lp_
        for name,array in [('col_cost_',-areas/total),('col_lower_',np.zeros(n)),('col_upper_',np.ones(n)),('row_lower_',np.asarray(lower)),('row_upper_',np.asarray(upper))]:assert np.array_equal(getattr(actual,name),array)
        for name,array in [('start_',matrix.indptr),('index_',matrix.indices),('value_',matrix.data)]:assert np.array_equal(getattr(actual.a_matrix_,name),array)
        assert list(actual.integrality_)==[hc.HighsVarType.kInteger]*n
        assert highs.setSolution(n,np.arange(n,dtype=np.int32),w)==hc.HighsStatus.kOk
        supplied=highs.getSolution();assert supplied.value_valid and np.array_equal(supplied.col_value,w)
        assert highs.writeOptions(str(OUT/'highs-options.txt'))==hc.HighsStatus.kOk
        write(OUT/'starting-solution.json',{'indices':warm,'filled_area_mm2':float(areas[warm].sum()),'model_arrays_exact':True,'full_starting_vector_accepted':True,'highs_version':highs.version(),'prior_failed_result_sha256':digest(RUN/'solve/result.json')})
        started=time.perf_counter();run_status=highs.run();assert run_status!=hc.HighsStatus.kError
        native_status=highs.getModelStatus();info=highs.getInfo();solution=highs.getSolution();feasible=solution.value_valid and info.primal_solution_status==hc.SolutionStatus.kSolutionStatusFeasible
        finite=lambda value:float(value) if np.isfinite(value) else None
        result=SimpleNamespace(status=0 if native_status==hc.HighsModelStatus.kOptimal else (1 if native_status==hc.HighsModelStatus.kTimeLimit else 4),success=native_status==hc.HighsModelStatus.kOptimal,
            message=highs.modelStatusToString(native_status),x=np.asarray(solution.col_value) if feasible else None,fun=float(info.objective_function_value) if feasible else None,
            mip_gap=finite(info.mip_gap),mip_node_count=int(info.mip_node_count),mip_dual_bound=finite(info.mip_dual_bound))
        write(OUT/'native-info.json',{'run_status':str(run_status),'model_status':str(native_status),'primal_status':str(info.primal_solution_status),'run_seconds':highs.getRunTime(),
            'simplex_iterations':info.simplex_iteration_count,'ipm_iterations':info.ipm_iteration_count,'nodes':info.mip_node_count,'feasible':feasible})'''
assert s.count(old)==1;s=s.replace(old,new).replace("OUT=RUN/'solve'","OUT=RUN/'solve-warm'")
target=ROOT/'output/solve_h5_contact_selection_warm.py';assert not target.exists();target.write_text(s,encoding='utf-8',newline='\n')
audit=(ROOT/'output/audit_h5_contact_selection.py').read_text(encoding='utf-8');audit=audit.replace("OUT=RUN/'audit'","OUT=RUN/'audit-warm'").replace("RUN/'solve/","RUN/'solve-warm/")
audit_target=ROOT/'output/audit_h5_contact_selection_warm.py';assert not audit_target.exists();audit_target.write_text(audit,encoding='utf-8',newline='\n')
with (RUN/'warm-start-plan.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'prior_solver_status':json.loads((RUN/'solve/result.json').read_bytes()),
        'changed_input':'The full independently verified 63-part binary vector is supplied through the bundled HiGHS 1.12.0 setSolution API. The previous SciPy wrapper had no incumbent input and timed out without a feasible selection. This is a separate, explicitly changed-input mechanism test, not an extension or relabeling of that failure.',
        'same_candidate_pool_objective_binary_constraints_and_120_second_allowance':True,'same_HiGHS_core_and_search_defaults':True,'solver_log_added':True,
        'no_new_packing_or_native_quality_run':True,'original_source_sha256':digest(source),'new_solver_source_sha256':digest(target),'new_auditor_sha256':digest(audit_target),
        'installed_wrapper_sha256':digest(ROOT/'.cache/shop-venv/Lib/site-packages/scipy/optimize/_highspy/_highs_wrapper.py'),'installed_core_sha256':digest(ROOT/'.cache/shop-venv/Lib/site-packages/scipy/optimize/_highspy/_core.cp311-win_amd64.pyd')},f,indent=2);f.write('\n')
shutil.copyfile(__file__,RUN/'prepare-warm.py');print(json.dumps({'prepared':True,'provided_starting_parts':63,'unchanged_allowance_seconds':120}))
