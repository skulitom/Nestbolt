"""Verify the compressed finite model, then run its predeclared bounded selection once."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from datetime import datetime,timezone
import copy,gzip,json,os,shutil,time,traceback
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_array
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-contact-placement-selection-20261018';OUT=RUN/'solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');plan=load(RUN/'plan.json');model=load(RUN/'model.json');pool=load(RUN/'candidates.json');warm=load(RUN/'warm-indices.json');job=load(RUN/'job.json');n=len(pool);start=time.perf_counter()
    inputs={p.name:digest(p) for p in [RUN/'plan.json',RUN/'model.json',RUN/'candidates.json',RUN/'conflicts.jsonl.gz',RUN/'cliques.jsonl.gz',RUN/'warm-indices.json',RUN/'job.json']}
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'pid':os.getpid(),'input_hashes':inputs,'predeclared_seconds':plan['solver_seconds_cap'],'native_calls':0,'quality_runs':0})
    try:
        adjacency=[0]*n;edges=0
        with gzip.open(RUN/'conflicts.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                i,j=json.loads(line);assert i<j and not(adjacency[i]&(1<<j));adjacency[i]|=1<<j;adjacency[j]|=1<<i;edges+=1
        assert edges==model['conflict_edges'];uncovered=adjacency.copy();rowidx=[];colidx=[];data=[];lower=[];upper=[];clique_count=0;warmset=set(warm)
        with gzip.open(RUN/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                clique=json.loads(line);assert len(set(clique))==len(clique)>=2;mask=sum(1<<i for i in clique)
                for i in clique:assert ((mask^(1<<i))&~adjacency[i])==0;uncovered[i]&=~mask
                assert len(warmset.intersection(clique))<=1
                r=len(lower);rowidx.extend([r]*len(clique));colidx.extend(clique);data.extend([1.]*len(clique));lower.append(-np.inf);upper.append(1.);clique_count+=1
        assert not any(uncovered) and clique_count==model['all_conflict_constraints']
        for part in job['parts']:
            indices=[i for i,p in enumerate(pool) if p['placement']['part_id']==part['id']];r=len(lower);rowidx.extend([r]*len(indices));colidx.extend(indices);data.extend([1.]*len(indices));lower.append(float(part['quantity']) if part['id']=='frame' else 0.);upper.append(float(part['quantity']))
        areas=np.asarray([p['filled_area_mm2'] for p in pool]);total=model['required_total_area_mm2'];r=len(lower);rowidx.extend([r]*n);colidx.extend(range(n));data.extend((areas/total).tolist());lower.append((model['known_partial_area_mm2']-1e-6)/total);upper.append(np.inf)
        matrix=coo_array((np.asarray(data),(np.asarray(rowidx,dtype=np.int32),np.asarray(colidx,dtype=np.int32))),shape=(len(lower),n)).tocsc();matrix.indices=matrix.indices.astype(np.int32);matrix.indptr=matrix.indptr.astype(np.int32)
        w=np.zeros(n);w[warm]=1.;v=matrix@w;assert np.all(v>=np.asarray(lower)-1e-9) and np.all(v<=np.asarray(upper)+1e-9)
        write(OUT/'preflight.json',{'equivalent_binary_model_verified':True,'conflict_edges':edges,'cliques':clique_count,'constraints':len(lower),'matrix_nonzeros':matrix.nnz,'known_partial_feasible':True,'seconds':time.perf_counter()-start})
        print((OUT/'preflight.json').read_text(encoding='utf-8'),flush=True);started=time.perf_counter()
        result=milp(c=-areas/total,integrality=np.ones(n),bounds=Bounds(0,1),constraints=LinearConstraint(matrix,np.asarray(lower),np.asarray(upper)),options={'time_limit':plan['solver_seconds_cap'],'mip_rel_gap':0.})
        record={'status':int(result.status),'success':bool(result.success),'message':result.message,'seconds':time.perf_counter()-started,'has_incumbent':result.x is not None,
            'objective':None if result.fun is None else float(result.fun),'mip_gap':None if getattr(result,'mip_gap',None) is None else float(result.mip_gap),'mip_node_count':None if getattr(result,'mip_node_count',None) is None else int(result.mip_node_count),'mip_dual_bound':None if getattr(result,'mip_dual_bound',None) is None else float(result.mip_dual_bound)}
        if result.x is not None:
            x=np.rint(result.x);assert np.max(np.abs(x-result.x))<1e-6;v=matrix@x;assert np.all(v>=np.asarray(lower)-1e-8) and np.all(v<=np.asarray(upper)+1e-8);selected=np.flatnonzero(x).tolist();write(OUT/'solver-values.json',result.x.tolist())
        else:selected=warm
        selected_mask=sum(1<<i for i in selected);assert all(not(adjacency[i]&selected_mask) for i in selected)
        counts=Counter();original=load(ROOT/'output/h5-saved-placement-selection-20261018/selected-layout.json');layout={'version':1,'units':'mm','sheets':original['sheets'],'placements':[]}
        for i in selected:
            p=copy.deepcopy(pool[i]['placement']);p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;layout['placements'].append(p)
        missing=Counter({p['id']:p['quantity'] for p in job['parts']})-counts
        record.update({'selected_from':'MILP incumbent' if result.x is not None else 'unchanged known partial fallback','placed':dict(counts),'missing':dict(missing),'filled_area_mm2':float(areas[selected].sum()),'complete_original_inventory':not missing,'geometry_acceptance_pending':True,'inputs_unchanged':all(digest(RUN/p)==h for p,h in inputs.items())})
        assert record['inputs_unchanged'];write(OUT/'selected-indices.json',selected);write(OUT/'selected-layout.json',layout);write(OUT/'result.json',record);print(json.dumps(record),flush=True)
    except Exception as e:write(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()
