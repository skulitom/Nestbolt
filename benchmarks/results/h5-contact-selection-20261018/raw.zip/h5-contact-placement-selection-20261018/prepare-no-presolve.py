"""Prepare the single measured lever: disable expensive HiGHS presolve, retaining the verified incumbent."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-contact-placement-selection-20261018';digest=lambda p:sha256(p.read_bytes()).hexdigest()
prior=json.loads((RUN/'solve-warm/result.json').read_bytes());assert prior['status']==1 and prior['missing']=={'cog':3}
assert json.loads((RUN/'audit-warm/checks.json').read_bytes())['complete']
source=ROOT/'output/solve_h5_contact_selection_warm.py';s=source.read_text(encoding='utf-8');needle="('mip_rel_gap',0.),('log_to_console',False)";assert s.count(needle)==1
s=s.replace(needle,"('mip_rel_gap',0.),('presolve','off'),('log_to_console',False)").replace("OUT=RUN/'solve-warm'","OUT=RUN/'solve-no-presolve'")
target=ROOT/'output/solve_h5_contact_selection_no_presolve.py';assert not target.exists();target.write_text(s,encoding='utf-8',newline='\n')
with (RUN/'no-presolve-plan.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'evidence':'The preceding warm-start log records 79 seconds in presolve, first search line at 81.7 seconds, and nonzeros growing from 681124 to 1627667. It expires after 120 seconds before completing the root LP. Original log, timeout, incumbent and result remain unchanged.',
        'changed_setting':{'presolve':'off'},'unchanged':'Exact original candidate pool, objective, binary constraints, feasible start, all other HiGHS defaults and 120-second allowance. Native packing runtime and quality budgets are untouched.',
        'prior_result_sha256':digest(RUN/'solve-warm/result.json'),'prior_log_sha256':digest(RUN/'solve-warm/highs.log'),'old_source_sha256':digest(source),'new_source_sha256':digest(target),'new_native_searches':0,'H5_complete':False},f,indent=2);f.write('\n')
shutil.copyfile(__file__,RUN/'prepare-no-presolve.py');print(json.dumps({'prepared':True,'only_search_setting_changed':'presolve=off','same_feasible_start':True,'same_seconds':120}))
