"""Verify new fixed-core forbidden geometry, full outer coverage and original pose census."""
from collections import Counter,defaultdict
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product,combinations
import math,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import MultiPoint,box,shape as from_geojson
from shapely.affinity import translate
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from diagnose_h5_concave_gaps import convex_pieces
from audit_h5_outer_coordinate_domains import edges,contains_point
from build_h5_guarded_alternate_outer import ROOT,CORE,AREA,PREVIOUS,OUT as BASE,load,write,digest
OUT=BASE/'audit'

def minkowski(a,b):
    pa=convex_pieces(a);pb=convex_pieces(b);assert unary_union(pa).equals(a) and unary_union(pb).equals(b)
    return unary_union([MultiPoint([(x-u,y-v) for (x,y),(u,v) in product(list(p.exterior.coords)[:-1],list(q.exterior.coords)[:-1])]).convex_hull for p,q in product(pa,pb)]),len(pa)*len(pb)

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(BASE/'result.json');fixed=load(BASE/'fixed-core.json');byid=dict(zip(fixed['source_candidate_ids'],fixed['placements']));classes=plan['orientation_classes'];scale=plan['coordinate_units_per_mm'];coef=plan['coefficient_scale'];maxx,maxy=plan['coordinate_maxima'];eps=plan['outward_numerical_padding_mm'];step=plan['grid_cell_mm'];source=ROOT/'output/h5-skeleton-contact-selection-20261020';job=load(source/'job.json');target=load(source/'conditional-target.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];poolpath=ROOT/'output/h5-small-pair-joint-20261023/candidates.json';mppath=poolpath.with_name('mapping.json');pool=load(poolpath);mp=load(mppath);assert fixed==load(CORE/'fixed-core.json') and load(CORE/'audit/checks.json')['passed'] and len(byid)==33;assert plan['fixed_core']=='guarded-core5' and plan['new_part_separation_mm']==-.01 and plan['pair_overlap_allowance_units']==1
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'result.json',BASE/'fixed-core.json',poolpath,mppath,CORE/'audit/checks.json']},'method':'Match inherited inputs, obstacle caches and original query templates to committed evidence. Reconstruct all cached local Minkowski polygons using independent Cartesian convex-piece vertex differences; directly reconstruct each moved-cog obstacle in original global coordinates. Rebuild all24 complete forbidden unions from the new fixed placements, original stock translation domains and shrunken-exclusion subsets. Enumerate every intersecting50mm cell again and prove full-region hull coverage. Exact rational checks then cover every shifted hull plus the entire floor-quantization square, and all expanded hull vertices satisfy independently reconstructed outward integer inequalities. Census every saved bracket/insert pose against all33 new fixed original polygons and original stock/gap, then require an encoded floor-grid representative for every compatible pose. Check all compatible portions of the four prior small-part baselines without treating them as full inventory. No solver or accepted layout.'})
    manifests=[]
    for name in ['h5-occupied-area-relaxation-20261025','h5-direct-coordinate-domains-20261025','h5-outer-coordinate-relaxation-20261025']:
        p=ROOT/'benchmarks/results'/name/'raw-manifest.json';data=load(p);manifests.append((p,{r['path']:r['sha256'] for r in data['files']+data['aliases']}))
    provenance=[];seen=set()
    def committed(p,h):
        assert digest(p)==h
        if p in seen:return
        relative=p.relative_to(ROOT).as_posix();keys=['source-inputs/'+relative]
        if p.is_relative_to(ROOT/'output'):keys.append(p.relative_to(ROOT/'output').as_posix())
        for manifest,rows in manifests:
            for key in keys:
                if rows.get(key)==h:provenance.append({'source':relative,'sha256':h,'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':key});seen.add(p);return
        raise AssertionError(('missing committed source',relative))
    for n,h in plan['inputs'].items():committed(ROOT/n,h)
    committed(poolpath,digest(poolpath));committed(mppath,digest(mppath));expected=[(f,a,mir) for f in ['bracket','insert'] for mir in ([False,True] if parts[f]['allow_mirror'] else [False]) for a in parts[f]['rotations']['degrees']];assert [(o['family'],o['degrees'],o['mirrored']) for o in classes]==expected;transformerror=0.
    for o in classes:
        moving=shape(parts[o['family']],{'rotation_radians':math.radians(o['degrees']),'mirrored':o['mirrored'],'translation':[-v for v in o['original_zero_bounds_min']]});ideal=from_geojson(o['polygon']);assert unary_union([box(*b) for b in o['rectangular_components']]).equals(ideal);assert all(all(float(v*scale).is_integer() for v in b) for b in o['rectangular_components']);err=moving.hausdorff_distance(ideal);assert err<1e-9;transformerror=max(transformerror,err)
    gs={i:shape(parts[p['part_id']],p['transform']) for i,p in byid.items()};cache={};cachepairs=0;movedchecks=0;maxdirecterror=0.;domains=[];byquery=defaultdict(list);cellchecks=requiredvertices=expandedvertices=halfspacechecks=0;minerosion=math.inf
    for spec in plan['queries']:
        q=load(BASE/'queries'/f"{spec['index']:03d}.json");assert all(q[k]==v for k,v in spec.items());committed(ROOT/q['template_query'],q['template_query_sha256']);template=load(ROOT/q['template_query']);assert template['core_group']==5 and template['specification']==spec['orientation_class'] and template['sheet_id']==spec['sheet_id'];o=classes[spec['orientation_class']];moving=shape(parts[o['family']],{'rotation_radians':math.radians(o['degrees']),'mirrored':o['mirrored'],'translation':[0.,0.]});assert moving.equals(from_geojson(q['moving_original_zero_polygon']));expectedids=[i for i,p in byid.items() if p['sheet_id']==spec['sheet_id']];assert [r['fixed_candidate'] for r in q['obstacles']]==expectedids;obstacles=[]
        for ref in q['obstacles']:
            i=ref['fixed_candidate'];p=byid[i];cp=ROOT/ref['cache_source'];committed(cp,ref['cache_sha256']);stored=load(cp);assert stored['fixed_zero_transform']=={**p['transform'],'translation':[0.,0.]};assert stored['moving_zero_transform']=={'rotation_radians':math.radians(o['degrees']),'mirrored':o['mirrored'],'translation':[0.,0.]};assert ref['new_translation']==p['transform']['translation']
            if ref['cache'] not in cache:
                expected,count=minkowski(shape(parts[p['part_id']],stored['fixed_zero_transform']),moving);actual=from_geojson(stored['raw_geometry']);assert expected.equals(actual);cache[ref['cache']]=actual;cachepairs+=count
            translated=translate(cache[ref['cache']],*p['transform']['translation']);obstacles.append(translated)
            if i==fixed['changed_source_candidate']:
                direct,_=minkowski(gs[i],moving);hd=direct.hausdorff_distance(translated);area=direct.symmetric_difference(translated).area;assert hd<1e-7 and area<1e-4;maxdirecterror=max(maxdirecterror,hd);movedchecks+=1
        raw=unary_union(obstacles);assert raw.equals(from_geojson(q['raw_forbidden']));excluded=from_geojson(q['shrunken_forbidden']);assert excluded.difference(raw).is_empty;minerosion=min(minerosion,excluded.distance(raw.boundary));a,b,c,d=moving.bounds;height=stock['height'] if spec['sheet_id']=='sheet-0' else target['required_used_height_mm'];bounds=[m['left']+edge-eps-a,m['bottom']+edge-eps-b,stock['width']-m['right']-edge+eps-c,height-m['top']-edge+eps-d];assert bounds==q['translation_domain_bounds_mm'];region=box(*bounds).difference(excluded);assert region.equals(from_geojson(q['translation_region']));cells=[];hulls=[]
        if not region.is_empty:
            a,b,c,d=region.bounds
            for x in range(math.floor(a/step),math.floor(c/step)+1):
                for y in range(math.floor(b/step),math.floor(d/step)+1):
                    clipped=region.intersection(box(x*step,y*step,(x+1)*step,(y+1)*step))
                    if clipped.is_empty:continue
                    row=q['cell_hulls'][len(cells)];assert row['cell']==[x,y];h=from_geojson(row['hull']);assert h.is_valid and h.equals(h.convex_hull) and h.covers(clipped);cells.append([x,y]);hulls.append(h);cellchecks+=1
        assert len(cells)==len(q['cell_hulls'])==len(q['faces']);assert unary_union(hulls).equals(from_geojson(q['translation_outer_cover'])) and region.difference(unary_union(hulls)).is_empty
        for fi,(row,h) in enumerate(zip(q['faces'],hulls)):
            assert row['source_cell_hull']==fi and row['source_cell']==cells[fi];expanded=from_geojson(row['polygon']);es=edges(expanded);assert expanded.is_valid and expanded.equals(expanded.convex_hull);points=[(F(x),F(y)) for x,y in list(expanded.exterior.coords)[:-1]];assert all(a*x+b*y<=c for a,b,c,_,_ in es for x,y in points);sx,sy=map(F,o['original_zero_bounds_min']);required=[(F(x)+sx+dx,F(y)+sy+dy) for (x,y),(dx,dy) in product(list(h.exterior.coords)[:-1],[(F(-1,100),F(-1,100)),(F(-1,100),F(0)),(F(0),F(0)),(F(0),F(-1,100))])];assert all(a*x+b*y<=c for a,b,c,_,_ in es for x,y in required);requiredvertices+=len(required);expandedvertices+=len(points);assert len(es)==len(row['halfspaces'])
            for (a,b,c,p0,p1),hh in zip(es,row['halfspaces']):
                assert hh['edge']==[list(p0),list(p1)];A=round(a*coef);B=round(b*coef);err=abs(A-a*coef)*maxx+abs(B-b*coef)*maxy+1;upper=math.ceil(c*scale*coef+err);assert (A,B,upper)==(hh['a'],hh['b'],hh['upper']) and hh['rounding_error_bound']==[err.numerator,err.denominator];assert upper-err>=c*scale*coef;halfspacechecks+=1
            assert all(contains_point(row,x*scale,y*scale) and 0<=x*scale<=maxx and 0<=y*scale<=maxy for x,y in points+required);di=len(domains);domains.append({'query':spec['index'],'face':fi,'family':o['family'],'orientation_class':o['index'],'sheet_id':spec['sheet_id'],'coordinate_bounds':row['coordinate_bounds'],'halfspaces':[{k:hh[k] for k in ['a','b','upper']} for hh in row['halfspaces']]});byquery[spec['index']].append(di)
    assert len(cache)==36 and movedchecks==12 and cellchecks==len(domains)==864 and result['completed_queries']==24 and not load(BASE/'pending.json')
    ids=[i for i,p in enumerate(pool) if p['placement']['part_id'] in ['bracket','insert']];pgeoms=np.asarray([shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in ids],dtype=object);candidatebounds=shapely.bounds(pgeoms);valid=np.zeros(len(ids),dtype=bool);distancechecks=0;unionchecks=0
    for sheet in ['sheet-0','sheet-1']:
        ix=np.asarray([j for j,i in enumerate(ids) if pool[i]['placement']['sheet_id']==sheet],dtype=int);height=stock['height'] if sheet=='sheet-0' else target['required_used_height_mm'];b=candidatebounds[ix];bounded=(b[:,0]>=m['left']+edge)&(b[:,1]>=m['bottom']+edge)&(b[:,2]<=stock['width']-m['right']-edge)&(b[:,3]<=height-m['top']-edge);fg=[gs[i] for i,p in byid.items() if p['sheet_id']==sheet];compatible=np.ones(len(ix),dtype=bool)
        for g in fg:compatible&=shapely.distance(pgeoms[ix],g)>=job['clearance'];distancechecks+=len(ix)
        together=shapely.distance(pgeoms[ix],unary_union(fg))>=job['clearance'];assert np.array_equal(compatible,together);unionchecks+=len(ix);valid[ix]=bounded&compatible
    known=[];lookup={};maxposeerror=0.
    for j in np.flatnonzero(valid):
        i=ids[int(j)];p=pool[i]['placement'];t=p['transform'];o=next(o for o in classes if o['family']==p['part_id'] and o['mirrored']==t['mirrored'] and abs(math.remainder(t['rotation_radians']-math.radians(o['degrees']),math.tau))<1e-9);qi=2*o['index']+int(p['sheet_id']=='sheet-1');anchor=[F(v)+F(d) for v,d in zip(t['translation'],o['original_zero_bounds_min'])];x,y=[math.floor(v*100) for v in anchor];di=next((di for di in byquery[qi] if contains_point(domains[di],x,y)),None);assert di is not None,(i,qi,x,y);ideal=translate(from_geojson(o['polygon']),*[float(v) for v in anchor]);err=ideal.hausdorff_distance(pgeoms[j]);assert err<1e-8;maxposeerror=max(maxposeerror,err);row={'candidate':i,'query':qi,'domain':di,'class':o['index'],'sheet_id':p['sheet_id'],'x_units':x,'y_units':y};known.append(row);lookup[i]=row
    baselines=[];baselinepairs=0
    for seed in mp['mapped_seeds']:
        chosen=[i for i in seed['selected_variable_candidates'] if i in lookup];records=[lookup[i] for i in chosen]
        for a,b in combinations(records,2):
            if a['sheet_id']!=b['sheet_id']:continue
            for aa,bb in product(classes[a['class']]['rectangular_components'],classes[b['class']]['rectangular_components']):
                ax0,ay0,ax1,ay1=[round(v*100) for v in aa];bx0,by0,bx1,by1=[round(v*100) for v in bb];assert a['x_units']+ax1<=b['x_units']+bx0+1 or b['x_units']+bx1<=a['x_units']+ax0+1 or a['y_units']+ay1<=b['y_units']+by0+1 or b['y_units']+by1<=a['y_units']+ay0+1;baselinepairs+=1
        baselines.append({'source_core':seed['core_group'],'compatible_small_candidates':chosen,'partial_total_with_new_fixed_core':len(chosen)+33,'original_full_inventory_still_required':66})
    write(OUT/'integer-domains.json',domains);write(OUT/'selection.json',{'retained':list(range(len(domains))),'removed':[]});write(OUT/'known-pose-memberships.json',known);write(OUT/'baseline-subset-checks.json',baselines);write(OUT/'provenance.json',{'passed':True,'source_members_matching_committed_evidence':provenance});counts=Counter(d['family'] for d in domains);checks={'passed':True,'seconds':time.perf_counter()-start,'committed_input_template_and_cache_matches':len(provenance),'cached_local_obstacles_independently_reconstructed':len(cache),'cached_convex_piece_vertex_sums':cachepairs,'moved_cog_global_obstacles_independently_reconstructed':movedchecks,'maximum_moved_obstacle_hausdorff_error_mm':maxdirecterror,'all24_new_forbidden_unions_and_translation_regions_verified':True,'minimum_exclusion_inward_distance_mm':minerosion,'complete_grid_cells_and_outer_domains':cellchecks,'exact_required_quantization_vertices_covered':requiredvertices,'exact_expanded_vertices_encoded':expandedvertices,'outward_rational_halfspaces_verified':halfspacechecks,'original_orientation_reflection_cases':12,'maximum_orientation_transform_error_mm':transformerror,'saved_small_poses_censused':len(ids),'original_fixed_pair_distance_checks':distancechecks,'fixed_union_distance_crosschecks':unionchecks,'known_compatible_original_poses_with_grid_representatives':len(known),'maximum_known_pose_transform_error_mm':maxposeerror,'compatible_baseline_subset_totals':[b['partial_total_with_new_fixed_core'] for b in baselines],'baseline_cross_part_rectangle_pairs_checked':baselinepairs,'per_family_domains':dict(counts),'per_copy_domain_choices':counts['bracket']*12+counts['insert']*21,'all_original_counts_required':True,'relaxation_only':True,'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
