"""Independent rational disk, decomposition, Minkowski and rounding checks."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from math import gcd,floor,ceil
import json,shutil,time
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-disk-relaxation-prepared-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(ps):
    ps=sorted(set(map(tuple,ps)));chains=[]
    for points in [ps,ps[::-1]]:
        chain=[]
        for p in points:
            while len(chain)>1 and cross(chain[-2],chain[-1],p)<=0:chain.pop()
            chain.append(p)
        chains.append(chain[:-1])
    return chains[0]+chains[1]
def normals(ps):
    out=[]
    for a,b in zip(ps,ps[1:]+ps[:1]):
        nx,ny=b[1]-a[1],a[0]-b[0];g=gcd(abs(nx),abs(ny));out.append((nx//g,ny//g))
    return set(out)
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');geo=load(BASE/'geometry.json')
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    src=ROOT/'output/h5-coordinated-placement-selection-20261018';job=load(src/'job.json');target=load(src/'conditional-target.json');parts={p['id']:p for p in job['parts']};disk=load(ROOT/'output/h5-cog-center-capacity-20261020/disk.json');manifest=ROOT/'benchmarks/results/h5-cog-free-regions-and-continuous-capacity-20261020/raw-manifest.json';files=load(manifest)['files'];provenance=[]
    for p in [src/'job.json',src/'conditional-target.json',ROOT/'output/h5-cog-center-capacity-20261020/disk.json',ROOT/'output/h5-cog-center-capacity-20261020/audit/checks.json']:
        rows=[r for r in files if r['sha256']==digest(p)];assert rows,p;provenance.append({'source':p.relative_to(ROOT).as_posix(),'sha256':digest(p),'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'archive_member':rows[0]['path']})
    center=[F(*p) for p in disk['center']];vs=[[F(v) for v in p] for p in parts['cog']['geometry'][0]['outer']];winding=0;distances=[]
    for a,b in zip(vs,vs[1:]+vs[:1]):
        c=cross(a,b,center)
        if a[1]<=center[1]<b[1] and c>0:winding+=1
        if b[1]<=center[1]<a[1] and c<0:winding-=1
        v=[b[k]-a[k] for k in [0,1]];t=sum((center[k]-a[k])*v[k] for k in [0,1])/sum(z*z for z in v);t=max(F(0),min(F(1),t));distances.append(sum((center[k]-a[k]-t*v[k])**2 for k in [0,1]))
    assert winding and min(distances)==F(*disk['minimum_boundary_distance_squared']);R=disk['radius_units'];assert F(R,10000)**2<min(distances)
    poly=list(map(tuple,geo['polygon_units']));assert len(poly)==16 and set(hull(poly))==set(poly);assert all(x*x+y*y<R*R for x,y in poly);assert {(-x,-y) for x,y in poly}==set(poly)
    ns=list(map(tuple,geo['normals']));assert len(ns)==20 and set(ns)==normals(hull(poly))|{(-1,0),(1,0),(0,-1),(0,1)};assert geo['polygon_supports']==[max(a*x+b*y for x,y in poly) for a,b in ns]
    assert plan['required_counts']=={p['id']:p['quantity'] for p in job['parts']} and sum(plan['required_counts'].values())==66 and plan['fixed_parts']==0
    expected_classes={(p['id'],k,m) for p in job['parts'] if p['id']!='cog' for k in range(4) for m in ([False,True] if p['allow_mirror'] else [False])};assert {(c['family'],c['quarter_turn'],c['mirrored']) for c in geo['classes']}==expected_classes
    assert all(p['rotations']=={'kind':'list','degrees':[0.0,90.0,180.0,270.0]} for p in job['parts'] if p['id']!='cog');assert parts['cog']['rotations']=={'kind':'free'} and not parts['cog']['allow_mirror']
    S=10000;Q=100;thresholds=0;summed_vertices=0;matrices=[((1,0),(0,1)),((0,-1),(1,0)),((-1,0),(0,-1)),((0,1),(-1,0))]
    stock=job['stocks'][0];m=stock['margins'];edge=F(job['edge_clearance']);bounds=[[F(m['left'])+edge,F(m['bottom'])+edge,F(stock['width'])-F(m['right'])-edge,F(h)-F(m['top'])-edge] for h in [stock['height'],target['required_used_height_mm']]];assert bounds==[[F(*v) for v in b] for b in geo['stock_bounds_rational']]
    rebuilt_modes=[]
    for ci,c in enumerate(geo['classes']):
        assert c['index']==ci;matrix=matrices[c['quarter_turn']];pts=[]
        for v in parts[c['family']]['geometry'][0]['outer']:
            x,y=v;x=-x if c['mirrored'] else x;pts.append([matrix[0][0]*x+matrix[0][1]*y,matrix[1][0]*x+matrix[1][1]*y])
        lo=[min(p[k] for p in pts) for k in [0,1]];assert lo==c['original_zero_bounds_min'];expected=[[p[k]-lo[k] for k in [0,1]] for p in pts];assert expected==c['polygon'];shape=Polygon(expected);rects=[box(*r) for r in c['components']];assert shape.symmetric_difference(unary_union(rects)).area==0 and shape.area==sum(r.area for r in rects)
        w,h=shape.bounds[2:];assert [w,h]==[c['width'],c['height']];assert len(rects)==(2 if c['family']=='bracket' else 1)
        for ri,r in enumerate(c['components']):
            assert all(F(x).denominator==1 for x in r);x0,y0,x1,y1=map(int,r);corners=[(S*x,S*y) for x,y in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]];sums=[(a+x,b+y) for a,b in corners for x,y in poly];mh=hull(sums);summed_vertices+=len(sums);assert normals(mh)==set(ns)
            for ni,(a,b) in enumerate(ns):
                support=max(a*x+b*y for x,y in mh);lower=floor(F(support,100)-abs(a)-abs(b))-1;assert lower==c['cog_rect_separation_lower_units'][ri][ni];thresholds+=1
                # Every floor-grid relative anchor differs by <1 unit per axis.
                assert F(lower)<=F(support,100)-abs(a)-abs(b)
        for si,b in enumerate(bounds):
            bb=[floor(b[0]*100)-1,floor(b[1]*100)-1,ceil((b[2]-F(w))*100)+1,ceil((b[3]-F(h))*100)+1]
            if bb[0]<=bb[2] and bb[1]<=bb[3]:rebuilt_modes.append({'index':len(rebuilt_modes),'class':ci,'family':c['family'],'sheet':si,'coordinate_bounds':bb})
    assert rebuilt_modes==geo['modes'] and len(rebuilt_modes)==28
    cp=hull([(x+a,y+b) for x,y in poly for a,b in poly]);assert set(cp)=={(2*x,2*y) for x,y in poly};cns=normals(cp);assert {(r['a'],r['b']) for r in geo['cog_pair_separation']}==cns
    for r in geo['cog_pair_separation']:
        a,b=r['a'],r['b'];assert r['lower']==floor(F(max(a*x+b*y for x,y in cp),100)-abs(a)-abs(b))-1;thresholds+=1
    cb=[[floor((b[0]+F(R,S))*100)-1,floor((b[1]+F(R,S))*100)-1,ceil((b[2]-F(R,S))*100)+1,ceil((b[3]-F(R,S))*100)+1] for b in bounds];assert cb==geo['cog_center_bounds'];assert geo['coordinate_maxima']==[150000,300000]
    write(OUT/'provenance.json',{'source_members_matching_committed_evidence':provenance});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'committed_source_matches':len(provenance),'exact_cog_boundary_distances':len(distances),'all_angle_disk_radius_mm':R/S,'strictly_inscribed_polygon_vertices':16,'non_cog_orientation_reflection_cases':len(geo['classes']),'complete_original_rectangle_decompositions':len(geo['classes']),'minkowski_vertex_sums':summed_vertices+len(poly)**2,'exact_outward_separation_thresholds':thresholds,'stock_modes':len(geo['modes']),'cog_stock_modes':2,'all_parts_movable':True,'required_original_parts':66,'positive_clearance_dropped_only_for_relaxation':True,'floor_relative_error_bound_units_per_axis':1,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
if __name__=='__main__':main()
