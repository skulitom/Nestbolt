"""Check a preserved original partial layout against every new outer relation."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
from collections import Counter
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-global-disk-relaxation-prepared-20261025';OUT=BASE/'baseline-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();source=ROOT/'output/h5-latest-wide-joint-20261023/layout-audit/layout-final.json';manifest=ROOT/'benchmarks/results/h5-latest-wide-joint-progress-20261023/raw-manifest.json';matches=[r for r in load(manifest)['files'] if r['sha256']==digest(source)];assert matches;geo=load(BASE/'geometry.json');disk=load(ROOT/'output/h5-cog-center-capacity-20261020/disk.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};center=[float(F(*v)) for v in disk['center']];rows=[];maxerror=0
    write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [source,manifest,BASE/'plan.json',BASE/'geometry.json',BASE/'audit/checks.json',ROOT/'output/h5-cog-center-capacity-20261020/disk.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json']},'source_archive_member':matches[0]['path'],'scope':'Partial64 original-part sanity check only. It is not a feasible66-part model solution and is not used as a solver hint.'})
    for p in load(source)['placements']:
        f=p['part_id'];t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation'];mirror=-1 if t['mirrored'] else 1;sheet=int(p['sheet_id'].split('-')[1]);row={'family':f,'sheet':sheet}
        if f=='cog':
            xy=[mirror*center[0]*c-center[1]*s+tx,mirror*center[0]*s+center[1]*c+ty];bound=geo['cog_center_bounds'][sheet];row['class']=None;row['components']=[]
        else:
            k=round(t['rotation_radians']/(math.pi/2))%4;cl=next(o for o in geo['classes'] if o['family']==f and o['quarter_turn']==k and o['mirrored']==t['mirrored']);xy=[tx+cl['original_zero_bounds_min'][0],ty+cl['original_zero_bounds_min'][1]];q=next(q for q in geo['modes'] if q['class']==cl['index'] and q['sheet']==sheet);bound=q['coordinate_bounds'];row['class']=cl['index'];row['components']=[[int(v)*100 for v in r] for r in cl['components']]
            for v,e in zip(parts[f]['geometry'][0]['outer'],cl['polygon']):maxerror=max(maxerror,math.hypot(mirror*v[0]*c-v[1]*s+tx-(e[0]+xy[0]),mirror*v[0]*s+v[1]*c+ty-(e[1]+xy[1])))
        row['x'],row['y']=[math.floor(z*100) for z in xy];assert bound[0]<=row['x']<=bound[2] and bound[1]<=row['y']<=bound[3];rows.append(row)
    checks=Counter()
    for a,b in combinations(rows,2):
        if a['sheet']!=b['sheet']:continue
        if a['family']=='cog' and b['family']!='cog':a,b=b,a
        if b['family']!='cog':
            for aa,bb in product(a['components'],b['components']):
                assert a['x']+aa[2]<=b['x']+bb[0]+1 or b['x']+bb[2]<=a['x']+aa[0]+1 or a['y']+aa[3]<=b['y']+bb[1]+1 or b['y']+bb[3]<=a['y']+aa[1]+1;checks['rect-rect']+=1
        elif a['family']!='cog':
            thresholds=geo['classes'][a['class']]['cog_rect_separation_lower_units']
            for arm in range(len(a['components'])):
                assert any(nx*(b['x']-a['x'])+ny*(b['y']-a['y'])>=thresholds[arm][i] for i,(nx,ny) in enumerate(geo['normals']));checks['disk-rect']+=1
        else:
            assert any(r['a']*(b['x']-a['x'])+r['b']*(b['y']-a['y'])>=r['lower'] for r in geo['cog_pair_separation']);checks['disk-disk']+=1
    counts=Counter(r['family'] for r in rows);assert counts=={'frame':18,'bracket':10,'insert':21,'cog':15};assert maxerror<1e-9;write(OUT/'positions.json',rows);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'partial_counts':dict(counts),'parts':len(rows),'all_present_parts_have_outward_stock_representatives':True,'same_sheet_component_pair_checks':dict(checks),'maximum_exact_quarter_turn_transform_error_mm':maxerror,'missing_original_brackets':2,'full_model_solution':False,'solver_hint_used':False,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
if __name__=='__main__':main()
