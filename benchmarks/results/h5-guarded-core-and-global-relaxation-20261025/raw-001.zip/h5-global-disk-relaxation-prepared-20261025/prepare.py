"""Prepare a continuous outer relaxation with every original part movable."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime, timezone
import json, math, shutil, time
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-global-disk-relaxation-prepared-20261025'
SRC=ROOT/'output/h5-coordinated-placement-selection-20261018'
DISK=ROOT/'output/h5-cog-center-capacity-20261020'
MAN=ROOT/'benchmarks/results/h5-cog-free-regions-and-continuous-capacity-20261020/raw-manifest.json'
S=10000; Q=100
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rot(p,k,mirror):
    assert all(float(v).is_integer() for v in p)
    x,y=map(int,p);x=-x if mirror else x
    return [(x,y),(-y,x),(-x,-y),(y,-x)][k]
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[SRC/'job.json',SRC/'conditional-target.json',DISK/'disk.json',DISK/'audit/checks.json',MAN,ROOT/'output/h5-guarded-alternate-outer-20261025/solve/result.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_limit_seconds':120,'model_construction_limit_seconds':120,'independent_model_audit_limit_seconds':120,'solver_parameters':{'max_time_in_seconds':60,'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False},'maximum_solver_calls':1,'geometry_units_per_mm':S,'coordinate_units_per_mm':Q,'required_counts':{'frame':18,'bracket':12,'insert':21,'cog':15},'fixed_parts':0,'method':'All51 non-cog parts use their original filled outer quarter-turn geometry; both arms of each bracket are coupled. All15 freely rotating cogs are represented by the same axis-fixed16-gon strictly inside their independently certified rotation-invariant inscribed disks. Every part chooses either original stock domain, at the original second-sheet material cap. Floor anchors/centers to0.01mm and round all bounds/separating inequalities outward. Drop positive clearance. Use all edge normals of each exact convex-component Minkowski sum; no sampled poses, fixed frame set, fixed cog pose, hint, objective or missing-part allowance. Identical-copy ordering is the only symmetry constraint.','scope':'A necessary outer relaxation of the original filled-outline problem, with arbitrary cog angles. A positive outcome is diagnostic only: it lacks actual cog outlines/angles and original clearance and needs further original-shape/native checks. UNKNOWN proves nothing. A negative outcome needs full geometric/model audits. No call retry or extension; no production or H5 acceptance claim.'})
    start=time.perf_counter();job=load(SRC/'job.json');target=load(SRC/'conditional-target.json');disk=load(DISK/'disk.json');parts={p['id']:p for p in job['parts']};radius=disk['radius_units'];r=radius-2
    polygon=[[round(r*math.cos(2*math.pi*k/16)),round(r*math.sin(2*math.pi*k/16))] for k in range(16)]
    assert all(x*x+y*y<radius*radius for x,y in polygon)
    normals=[]
    for a,b in zip(polygon,polygon[1:]+polygon[:1]):
        x,y=b[1]-a[1],a[0]-b[0];g=math.gcd(abs(x),abs(y));normals.append([x//g,y//g])
    cog_normals=normals[:]
    normals=sorted(set(map(tuple,normals+[[1,0],[-1,0],[0,1],[0,-1]])))
    supports=[max(a*x+b*y for x,y in polygon) for a,b in normals]
    stock=job['stocks'][0];m=stock['margins'];edge=F(job['edge_clearance'])
    bounds=[[F(m['left'])+edge,F(m['bottom'])+edge,F(stock['width'])-F(m['right'])-edge,F(h)-F(m['top'])-edge] for h in [stock['height'],target['required_used_height_mm']]]
    classes=[];modes=[]
    for family in ['frame','bracket','insert']:
        p=parts[family];assert p['rotations']=={'kind':'list','degrees':[0.0,90.0,180.0,270.0]}
        base={'frame':[[0,0,450,350]],'bracket':[[0,0,300,75],[0,75,100,250]],'insert':[[0,0,180,110]]}[family]
        for mirror in ([False,True] if p['allow_mirror'] else [False]):
            for k in range(4):
                pts=[rot(v,k,mirror) for v in p['geometry'][0]['outer']];lo=[min(v[a] for v in pts) for a in [0,1]];poly=[[v[a]-lo[a] for a in [0,1]] for v in pts];rects=[]
                for x0,y0,x1,y1 in base:
                    corners=[rot(v,k,mirror) for v in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]]
                    rects.append([min(v[0] for v in corners)-lo[0],min(v[1] for v in corners)-lo[1],max(v[0] for v in corners)-lo[0],max(v[1] for v in corners)-lo[1]])
                w,h=max(v[0] for v in poly),max(v[1] for v in poly);ci=len(classes)
                thresholds=[]
                for x0,y0,x1,y1 in rects:
                    thresholds.append([math.floor(F(Q*(max(a*x+b*y for x,y in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)])*S+support),S)-abs(a)-abs(b))-1 for (a,b),support in zip(normals,supports)])
                classes.append({'index':ci,'family':family,'quarter_turn':k,'mirrored':mirror,'original_zero_bounds_min':lo,'polygon':poly,'components':rects,'width':w,'height':h,'cog_rect_separation_lower_units':thresholds})
                for sheet,b in enumerate(bounds):
                    bb=[math.floor(b[0]*Q)-1,math.floor(b[1]*Q)-1,math.ceil((b[2]-F(w))*Q)+1,math.ceil((b[3]-F(h))*Q)+1]
                    if bb[0]<=bb[2] and bb[1]<=bb[3]:modes.append({'index':len(modes),'class':ci,'family':family,'sheet':sheet,'coordinate_bounds':bb})
    center_bounds=[[math.floor((b[0]+F(radius,S))*Q)-1,math.floor((b[1]+F(radius,S))*Q)-1,math.ceil((b[2]-F(radius,S))*Q)+1,math.ceil((b[3]-F(radius,S))*Q)+1] for b in bounds]
    cog_pairs=[{'a':a,'b':b,'lower':math.floor(F(2*Q*max(a*x+b*y for x,y in polygon),S)-abs(a)-abs(b))-1} for a,b in cog_normals]
    write(OUT/'geometry.json',{'polygon_units':polygon,'normals':normals,'polygon_supports':supports,'cog_pair_separation':cog_pairs,'classes':classes,'modes':modes,'cog_center_bounds':center_bounds,'stock_bounds_rational':[[[v.numerator,v.denominator] for v in b] for b in bounds],'coordinate_maxima':[150000,300000]})
    elapsed=time.perf_counter()-start;assert elapsed<120
    write(OUT/'generation.json',{'seconds':elapsed,'classes':len(classes),'modes':len(modes),'non_cog_orientation_aliases':16,'polygon_vertices':16,'cog_rectangle_normals':len(normals),'cog_cog_normals':len(cog_normals),'fixed_parts':0,'required_total':66,'solver_calls':0,'H5_complete':False});print(load(OUT/'generation.json'),flush=True)
if __name__=='__main__':main()
