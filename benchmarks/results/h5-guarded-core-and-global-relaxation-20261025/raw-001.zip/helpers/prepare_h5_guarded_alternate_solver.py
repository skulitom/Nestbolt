"""Reuse the audited outer encoding for the newly reconstructed guarded core."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-guarded-alternate-outer-20261025';SOURCE=ROOT/'output/solve_h5_outer_coordinates.py';TARGET=ROOT/'output/solve_h5_guarded_alternate_outer.py'
s=SOURCE.read_text(encoding='utf-8');changes=[]
for old,new in [("h5-outer-coordinate-relaxation-20261025","h5-guarded-alternate-outer-20261025"),("'fixed_core':0","'fixed_core':'guarded-core5'"),("around fixed core0 via","around guarded-core5 via")]:
    count=s.count(old);assert count>0,(old,count);s=s.replace(old,new);changes.append({'old':old,'new':new,'occurrences':count})
assert 'fixed core0' not in s and "'fixed_core':0" not in s
with TARGET.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
shutil.copyfile(SOURCE,BASE/'core0-model-template.py')
with (BASE/'model-template-provenance.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'source':SOURCE.relative_to(ROOT).as_posix(),'source_sha256':sha256(SOURCE.read_bytes()).hexdigest(),'generated':TARGET.relative_to(ROOT).as_posix(),'generated_sha256':sha256(TARGET.read_bytes()).hexdigest(),'changes':changes,'scope':'Only the input root and fixed-arrangement metadata change. The full independent protobuf reconstruction checks every new variable, domain constraint, component-pair rule and parameter before the sole declared call.'},f,indent=2);f.write('\n')
print({'generated':str(TARGET),'substitution_groups':len(changes)})
