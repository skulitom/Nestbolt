"""Fresh full-original twelve-mover model, from independently audited source domains."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from math import gcd,floor
from collections import Counter
from itertools import product
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';REG=ROOT/'output/h5-expanded-cog-neighborhood-20261026';CAP=ROOT/'output/h5-expanded-second-sheet-capacity-20261026';OUT=ROOT/'output/h5-expanded-source-model-20261026';GEOM=ROOT/'output/h5-source-orientation-construction-20261025/geometry.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
LO=-2**63;HI=2**63-1
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def lin(model,terms,lo=LO,hi=HI,en=()):
    t=Counter()
    for v,c in terms:t[v]+=c
    ids=sorted(v for v,c in t.items() if c);p=model.constraints.add();p.linear.vars.extend(ids);p.linear.coeffs.extend(t[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en)
def var(model,name,lo=0,hi=1):
    i=len(model.variables);model.variables.add(name=name,domain=[lo,hi]);return i
def bounds(ds):return [min(d['coordinate_bounds'][i] for d in ds) if i<2 else max(d['coordinate_bounds'][i] for d in ds) for i in range(4)]
def area(ring):
    p=[(F(x),F(y)) for x,y in ring];return abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1])))/2
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    assert load(SOURCE/'audit/checks.json')['passed'] and load(CAP/'audit/checks.json')['passed']
    paths=[p for p in SOURCE.rglob('*.json')]+[REG/'fixed-originals.json',GEOM,JOB]+[CAP/n for n in ['plan.json','certificate.json','audit/plan.json','audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'required_originals':66,'moving_originals':12,'fixed_originals':54,'coordinate_units_per_mm':1000,'method':'Build every part/query/domain and all538 same-sheet pair modes from the fresh54-fixed source. Each of12 mandatory originals chooses one domain and integer anchor. Whole-query difference boxes simplify only provably tautological/impossible original face planes. Normalize remaining source inequalities exactly and share one-sided direction flags only within the same ordered physical pair; every flag implies its own plane and appears positively in face ORs. Add only two exact original filled-area necessary inequalities and the freshly audited second-sheet capacity2. Retain all nine repaired cog positions as advisory hints attached to their original copy IDs. No coordinate locks, copy-order symmetry, old fixed57 cuts, solver calls, retries or production qualification.'})
    spec=load(SOURCE/'plan.json');queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']};qb={i:bounds(q['domains']) for i,q in queries.items()};model=cp_model_pb2.CpModelProto();parts=[];coords=[];modes={};base_domains=0
    for part in spec['parts']:
        pi=part['part'];begin=len(model.constraints);vb=len(model.variables);ds=[d for qi in part['queries'] for d in queries[qi]['domains']];b=bounds(ds)
        sheet=var(model,f'p{pi}-sheet');choice=var(model,f'p{pi}-choice',0,len(ds)-1);x=var(model,f'p{pi}-x',b[0],b[2]);y=var(model,f'p{pi}-y',b[1],b[3]);pm=[];allflags=[];offset=0
        for qi in part['queries']:
            active=var(model,f'p{pi}-q{qi}');flags=[]
            for row,d in enumerate(queries[qi]['domains']):
                flag=var(model,f'p{pi}-q{qi}-d{row}');flags.append(flag);allflags.append((flag,offset+row));box=d['coordinate_bounds'];lin(model,[(x,1)],box[0],box[2],[flag]);lin(model,[(y,1)],box[1],box[3],[flag])
                for h in d['halfplanes']:lin(model,[(x,h['a']),(y,h['b'])],hi=h['bound'],en=[flag])
            lin(model,[(f,1) for f in flags]+[(active,-1)],0,0);m={'query':qi,'active':active,'domains':flags,'choice_offset':offset};pm.append(m);modes[pi,qi]=m;offset+=len(flags)
        lin(model,[(m['active'],1) for m in pm],1,1);lin(model,[(sheet,1)]+[(m['active'],-spec['queries'][m['query']]['sheet']) for m in pm],0,0);lin(model,[(choice,1)]+[(f,-i) for f,i in allflags],0,0)
        parts.append({'part':pi,'item':part['index'],'family':part['family'],'sheet':sheet,'choice':choice,'x':x,'y':y,'modes':pm,'variable_span':[vb,len(model.variables)],'constraint_span':[begin,len(model.constraints)]});coords.append({'part':pi,'x':x,'y':y});base_domains+=len(ds)
    base_variables=len(model.variables);base_constraints=len(model.constraints)
    charges={p['id']:floor(sum(area(g['outer']) for g in p['geometry'])*1000) for p in load(JOB)['parts']};stock=[floor((F(*b[2])-F(*b[0]))*(F(*b[3])-F(*b[1]))*1000) for b in load(GEOM)['stock_bounds_rational']];fixed=load(REG/'fixed-originals.json');fixed_area=[sum(charges[p['family']] for p in fixed if p['sheet']==s) for s in range(2)];assert fixed_area==spec['fixed_original_area_units_per_sheet'];total=sum(charges[p['family']] for p in parts);rule_begin=len(model.constraints)
    lin(model,[(p['sheet'],-charges[p['family']]) for p in parts],hi=stock[0]-fixed_area[0]-total);lin(model,[(p['sheet'],charges[p['family']]) for p in parts],hi=stock[1]-fixed_area[1]);cap=load(CAP/'certificate.json');lin(model,[(modes[p,19]['active'],1) for p in cap['applicable_moving_parts']],hi=cap['capacity'])
    write(OUT/'necessary-rules.json',{'filled_area_lower_units':charges,'stock_area_upper_units':stock,'fixed_area_lower_units':fixed_area,'moving_area_lower_units':total,'area_units_per_mm2':1000,'capacity_certificate_sha256':digest(CAP/'certificate.json'),'constraint_span':[rule_begin,len(model.constraints)],'proof':'Floor each original filled outer area*1000 independently. Disjoint filled shapes fit within the exact rational stock rectangle, so their integer lower-area sum cannot exceed floor(stock area*1000). Part-in-hole and common-line are off. Fresh geometric disk/bin proof supplies second-sheet cog capacity2.'})
    cache={};shared={};definitions=[];pairs=[];counts=Counter()
    for pair in load(SOURCE/'physical-pair-inventory.json'):
        ia,ib=pair['parts'];a,b=parts[ia],parts[ib]
        for mode in pair['same_sheet_modes']:
            qa,qbb=mode['query_a'],mode['query_b'];ma,mb=modes[ia,qa],modes[ib,qbb];begin=len(model.constraints);vb=len(model.variables);active=var(model,f'pair-{ia}-{ib}-{qa}-{qbb}');lin(model,[(active,1),(ma['active'],-1)],hi=0);lin(model,[(active,1),(mb['active'],-1)],hi=0);lin(model,[(active,1),(ma['active'],-1),(mb['active'],-1)],lo=-1)
            ba,bb=qb[qa],qb[qbb];box=[bb[0]-ba[2],bb[1]-ba[3],bb[2]-ba[0],bb[3]-ba[1]];lin(model,[(b['x'],1),(a['x'],-1)],box[0],box[2],[active]);lin(model,[(b['y'],1),(a['y'],-1)],box[1],box[3],[active]);case=mode['mutual_case']
            if case not in cache:cache[case]=load(SOURCE/'mutual'/f'{case:03d}.json')
            clauses=[]
            for face in cache[case]['faces']:
                extrema=[(min(h['a']*x+h['b']*y for x,y in product([box[0],box[2]],[box[1],box[3]])),max(h['a']*x+h['b']*y for x,y in product([box[0],box[2]],[box[1],box[3]]))) for h in face['outside_halfplanes']]
                if any(lo>=h['bound'] for h,(lo,hi) in zip(face['outside_halfplanes'],extrema)):counts['whole_box_tautological_faces']+=1;continue
                live=[i for i,(h,(lo,hi)) in enumerate(zip(face['outside_halfplanes'],extrema)) if hi>=h['bound']];directions=[]
                if not live:lin(model,[(active,1)],0,0);counts['impossible_faces']+=1
                elif len(live)==1:
                    h=face['outside_halfplanes'][live[0]];lin(model,[(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],lo=h['bound'],en=[active]);counts['singleton_faces']+=1
                else:
                    for edge in live:
                        h=face['outside_halfplanes'][edge];g=gcd(abs(h['a']),abs(h['b']));assert g>0;A,B,C=h['a']//g,h['b']//g,-(-h['bound']//g);key=(ia,ib,A,B,C)
                        if key not in shared:
                            flag=var(model,f'direction-{len(shared)}');shared[key]=flag;ci=len(model.constraints);lin(model,[(b['x'],A),(a['x'],-A),(b['y'],B),(a['y'],-B)],lo=C,en=[flag]);definitions.append({'flag':flag,'parts':[ia,ib],'a':A,'b':B,'bound':C,'constraint':ci})
                        directions.append({'edge':edge,'flag':shared[key]});counts['direction_uses']+=1
                    model.constraints.add().bool_or.literals.extend([-active-1]+sorted({d['flag'] for d in directions}));counts['disjunctive_faces']+=1
                clauses.append({'face':face['index'],'live_edges':live,'directions':directions})
            pairs.append({'parts':[ia,ib],'query_a':qa,'query_b':qbb,'mutual_case':case,'active':active,'difference_bounds':box,'clauses':clauses,'variable_span':[vb,len(model.variables)],'constraint_span':[begin,len(model.constraints)]})
    hints=[]
    for r in load(SOURCE/'audit/verified-partial-domain-membership.json'):
        p=next(p for p in parts if p['item']==r['item']);m=modes[p['part'],r['query']];row=r['matching_domains'][0]['row'];x,y=r['anchor_units1000'];values=[(p['sheet'],spec['queries'][r['query']]['sheet']),(p['choice'],m['choice_offset']+row),(m['active'],1),(m['domains'][row],1),(p['x'],x),(p['y'],y)]
        for v,n in values:model.solution_hint.vars.append(v);model.solution_hint.values.append(n)
        hints.append({'item':r['item'],'part':p['part'],'query':r['query'],'domain_row':row,'values':values})
    mapping={'parts':parts,'simultaneous_original_coordinates':coords,'source_pair_faces':pairs,'query_bounds':qb,'base_variables':base_variables,'base_constraints':base_constraints};write(OUT/'mapping.json',mapping);write(OUT/'shared-directions.json',definitions);write(OUT/'advisory-hints.json',hints);(OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n')
    result={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':len(model.solution_hint.vars),'base_domain_flags':base_domains,'base_variables':base_variables,'base_constraints':base_constraints,'shared_direction_flags':len(shared),'same_sheet_pair_modes':len(pairs),'required_originals':66,'moving_originals':12,'fixed_originals':54,'necessary_area_rules':2,'fresh_capacity_rules':1,'copy_symmetry_exclusions':0,'coordinate_locks':0,**counts,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
