"""Fresh second-sheet cog capacity from original collision geometry and new domains."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';OUT=ROOT/'output/h5-expanded-second-sheet-capacity-20261026';OUT.mkdir();shutil.copyfile(__file__,OUT/'certify.py');start=time.perf_counter()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(SOURCE/'audit/checks.json')['passed'];paths=[SOURCE/n for n in ['plan.json','profiles.json','queries/019.json','mutual/081.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Recompute a strictly interior258.082mm collision disk from all exact binary-rational vertices/segments of the unchanged original cog/cog Minkowski obstacle. Confirm origin interior by winding. Derive the entire new second-sheet anchor bounding box from every one of its32 inward domains. Partition its integer x range into two disjoint adjacent bins; each bin diagonal is shorter than the original required center separation. By pigeonhole at most two of the nine identical-profile moving cogs can select query19. This is a fresh certificate for the54-fixed source, not reuse of any fixed57 regional capacity. No solver.'})
raw=load(SOURCE/'mutual/081.json')['raw_forbidden'];assert raw['type']=='Polygon' and len(raw['coordinates'])==1;pts=[[F(x),F(y)] for x,y in raw['coordinates'][0]];radius=F(258082,1000);minimum=None;winding=0;segments=0
for a,b in zip(pts,pts[1:]):
    dx,dy=b[0]-a[0],b[1]-a[1];norm=dx*dx+dy*dy
    if not norm:continue
    t=max(F(0),min(F(1),-(a[0]*dx+a[1]*dy)/norm));x,y=a[0]+t*dx,a[1]+t*dy;d=x*x+y*y;minimum=d if minimum is None else min(minimum,d);segments+=1
    cross=dx*(-a[1])-dy*(-a[0])
    if a[1]<=0<b[1] and cross>0:winding+=1
    if b[1]<=0<a[1] and cross<0:winding-=1
assert winding in [-1,1] and minimum>radius*radius
domains=load(SOURCE/'queries/019.json')['domains'];bounds=[min(d['coordinate_bounds'][i] for d in domains) if i<2 else max(d['coordinate_bounds'][i] for d in domains) for i in range(4)];x0,y0,x1,y1=bounds;mid=(x0+x1)//2;bins=[[x0,y0,mid,y1],[mid+1,y0,x1,y1]];squared=[(b[2]-b[0])**2+(b[3]-b[1])**2 for b in bins];required=258082**2+1;assert max(squared)<required
spec=load(SOURCE/'plan.json');applicable=[p['part'] for p in spec['parts'] if p['family']=='cog'];assert len(applicable)==9 and all(p['profiles']==[9] and 19 in p['queries'] for p in spec['parts'] if p['part'] in applicable)
certificate={'source_query':19,'source_profile':9,'applicable_moving_parts':applicable,'source_domain_rows':len(domains),'coordinate_units_per_mm':1000,'original_collision_boundary_segments':segments,'origin_winding_number':winding,'minimum_exact_boundary_distance_squared_mm2':[minimum.numerator,minimum.denominator],'strict_collision_disk_radius_units':258082,'required_integer_squared_distance_units':required,'complete_anchor_bounds_units1000':bounds,'integer_partition_bins':bins,'bin_diagonal_squared_units':squared,'capacity':2,'physical_pair_proof_independent_of_fixed_placement':True,'source_domain_bounds_recomputed_for_fixed54':True}
write(OUT/'certificate.json',certificate);result={'seconds':time.perf_counter()-start,'capacity':2,'source_domains':len(domains),'applicable_cog_copies':len(applicable),'boundary_segments_checked':segments,'maximum_bin_squared_diagonal':max(squared),'required_squared_separation':required,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
