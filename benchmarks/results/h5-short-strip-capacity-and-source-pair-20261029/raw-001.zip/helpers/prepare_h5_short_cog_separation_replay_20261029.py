"""Prepare a fresh independent replay of the original all-angle pair certificate."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strip-capacity-short-core-20261029/cog-source-separation';BASE.mkdir()
s=(ROOT/'output/audit_h5_cog_pair_rotation_certificate.py').read_text(encoding='utf-8');s=s.replace("OUT=BASE/'audit'","OUT=ROOT/'output/h5-strip-capacity-short-core-20261029/cog-source-separation/legacy-replay'")
s=s.replace('and OUT not in p.parents','and BASE/\'audit\' not in p.parents')
name='audit_h5_short_cog_separation_legacy_replay_20261029.py';compile(s,name,'exec')
with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Independent certificate replay prepared; no solver or model changed.')
