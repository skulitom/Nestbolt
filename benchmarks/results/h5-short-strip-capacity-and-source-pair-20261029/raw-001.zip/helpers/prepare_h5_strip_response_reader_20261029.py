"""Specialize the closed-response reader while retaining prior frozen scripts."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent;s=(ROOT/'audit_h5_coarse_short_core_response_20261029.py').read_text(encoding='utf-8')
s=s.replace('h5-coarse-short-core-20261029','h5-strip-capacity-short-core-20261029').replace('check_h5_coarse_short_core_candidate_20261029','check_h5_strip_capacity_short_core_candidate_20261029')
start=s.index(",'preparation_failure':");end=s.index('})',start);s=s[:start]+s[end:]
s=s.replace("ROOT/'output/prepare_h5_coarse_short_core_scripts_20261029.py',ROOT/'output/finish_h5_coarse_short_core_scripts_20261029.py'","ROOT/'output/prepare_h5_strip_capacity_call_20261029.py',ROOT/'output/build_h5_strip_capacity_short_core_20261029.py'")
s=s.replace("'copy_orders':10,","'copy_orders':10,'translated_cog_strips':32,'global_piece_count':48,'cumulative_constraints':2,")
compile(s,'audit_h5_strip_capacity_short_core_response_20261029.py','exec')
with (ROOT/'audit_h5_strip_capacity_short_core_response_20261029.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Distinct response reader created; no search rerun.')
