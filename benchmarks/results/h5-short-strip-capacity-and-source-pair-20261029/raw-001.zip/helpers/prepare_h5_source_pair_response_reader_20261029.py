"""Keep the new closed result separate from all earlier response audits."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent;s=(ROOT/'audit_h5_strip_capacity_short_core_response_20261029.py').read_text(encoding='utf-8').replace('h5-strip-capacity-short-core-20261029','h5-source-pair-short-core-20261029').replace('check_h5_strip_capacity_short_core_candidate_20261029','check_h5_source_pair_short_core_candidate_20261029').replace('prepare_h5_strip_capacity_call_20261029','prepare_h5_source_pair_call_20261029').replace('build_h5_strip_capacity_short_core_20261029','build_h5_source_pair_short_core_20261029').replace("'cumulative_constraints':2,","'cumulative_constraints':2,'original_source_cog_x_separation_grid_units':2519,")
compile(s,'audit_h5_source_pair_short_core_response_20261029.py','exec')
with (ROOT/'audit_h5_source_pair_short_core_response_20261029.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Distinct response reader prepared.')
