"""Seal complete strip propagation and original-source pair studies."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
STRIP=ROOT/'output/h5-strip-capacity-short-core-20261029';BASE=ROOT/'output/h5-source-pair-short-core-20261029';SEP=STRIP/'cog-source-separation';PUB=BASE/'publication';NAME='h5-short-strip-capacity-and-source-pair-20261029';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='d876e6103847550920ccc0bdddef9656c3bb1ef9' and not git('diff','HEAD','--name-only')
responses=[]
for folder,ncts in [(STRIP,1619),(BASE,1620)]:
    model=load(folder/'model-audit/checks.json');r=load(folder/'response-audit/checks.json');assert model['passed'] and model['variables_verified']==1566 and model['constraints_verified']==ncts
    assert r['passed'] and r['status']=='UNKNOWN' and r['closed_solver_calls']==1 and r['incumbents']==r['assignments']==r['source_checker_calls']==r['native_calls']==0 and r['algorithm_seconds']<60 and r['shared_seconds']<90;responses.append(r)
assert load(STRIP/'preflight/audit/checks.json')['passed'] and load(SEP/'audit/checks.json')['passed'];replay=load(SEP/'legacy-replay/checks.json');assert replay['passed'] and replay['integer_capsule_edge_checks']==2307200 and replay['ordered_phase_pairs_verified']==518400
prior=load(ROOT/'benchmarks/results/h5-global-short-core-searches-20261029/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes'];up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert main=='d3b652b6400057aab92bc47f8121e8a339a88d2d' and ci['head_sha']==main and ci['status']=='in_progress' and len(jobs)==6
passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==5 and live==['checks (windows-latest)']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [STRIP,BASE]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_strip_capacity_bounds_20261029.py','audit_h5_strip_capacity_bounds_20261029.py','build_h5_strip_capacity_short_core_20261029.py','h5_strip_capacity_short_core_reader_20261029.py','audit_h5_strip_capacity_short_core_model_20261029.py','prepare_h5_strip_capacity_call_20261029.py','run_h5_strip_capacity_short_core_20261029.py','check_h5_strip_capacity_short_core_candidate_20261029.py','prepare_h5_strip_response_reader_20261029.py','audit_h5_strip_capacity_short_core_response_20261029.py','prepare_h5_short_cog_separation_replay_20261029.py','audit_h5_short_cog_separation_legacy_replay_20261029.py','prepare_h5_short_cog_source_separation_20261029.py','audit_h5_short_cog_source_separation_20261029.py','build_h5_source_pair_short_core_20261029.py','h5_source_pair_short_core_reader_20261029.py','audit_h5_source_pair_short_core_model_20261029.py','prepare_h5_source_pair_call_20261029.py','run_h5_source_pair_short_core_20261029.py','check_h5_source_pair_short_core_candidate_20261029.py','prepare_h5_source_pair_response_reader_20261029.py','audit_h5_source_pair_short_core_response_20261029.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_strip_source_pair_archive_20261029.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(STRIP,'preflight/bounds.json','capacity-bounds.json'),(STRIP,'preflight/audit/checks.json','capacity-bound-audit.json'),(STRIP,'preflight/audit/controls.json','capacity-controls.json'),(STRIP,'model/built.json','strip-model.json'),(STRIP,'model-audit/checks.json','strip-model-audit.json'),(STRIP,'response-audit/checks.json','strip-response-audit.json'),(SEP,'legacy-replay/checks.json','all-angle-replay-audit.json'),(SEP,'legacy-replay/necessity-proof.json','all-angle-necessity-proof.json'),(SEP,'bound.json','coarse-source-pair-bound.json'),(SEP,'audit/checks.json','coarse-source-pair-audit.json'),(SEP,'positive-source2-checks.json','positive-cog-pair-checks.json'),(SEP,'negative-source2-checks.json','negative-cog-pair-checks.json'),(BASE,'model/built.json','source-pair-model.json'),(BASE,'model-audit/checks.json','source-pair-model-audit.json'),(BASE,'response-audit/checks.json','source-pair-response-audit.json')]
for folder,a,b in copies:shutil.copyfile(folder/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json');write(OUT/'search-summary.json',responses)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40795603963,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':'Both calls are closed UNKNOWN with no assignments. Investigate stronger original-source projections across the current bracket/insert/cog modes. The prior output/h5-insert-order-projection-20261028 study provides121 directed reference-X distances and a three-insert condition, but its anchors are floored1um references, not the current100um normalized anchors. Before importing any bound, independently match each current source mode to its prior geometry, prove the full domain inclusion and derive conservative losses for changed rounding, reference offsets and possible order reversals. Preserve all four current insert quarter rotations and all13 original owners. Reject any bound whose mapping cannot be proved; do not use legacy constants unchanged. A future distinct model and every new table/order implication must pass complete source/positive/negative/protobuf audits before a declared call. Alternatively use a new original-source construction; do not repeat seeds or extend the four closed global core searches. A full66 source/native witness and the complete H5 matrix remain required.','legacy_projection_mapping_prepared':False,'new_model_created':False,'new_search_opened':False,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'audited_current_models':2,'closed_solver_calls':2,'statuses':['UNKNOWN','UNKNOWN'],'incumbents':0,'assignments':0,'source_checker_calls':0,'native_calls':0,'algorithm_and_shared_budgets_respected':True,'allocated_solve_overruns_preserved':True,'active_mode_envelopes_verified':36,'exact_envelope_corners_checked':576,'independent_capacity_control_slabs':113,'global_rectangle_pieces':48,'all_angle_cells_replayed':720,'all_angle_robust_segments_replayed':28840,'exact_capsule_edge_checks':2307200,'ordered_angle_pairs_replayed':518400,'source_cog_distance_um':254300,'rounded_cog_distance_lower_bound_um':254158,'necessary_ordered_cog_x_difference_um':251900,'positive_and_negative_cog_source_pairs_verified':True,'new_source_valid13':False,'new_source_valid66':False,'full_allocation_or_original_job_excluded':False,'valid64_preserved':True,'remaining_necessary_allocations':444,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
