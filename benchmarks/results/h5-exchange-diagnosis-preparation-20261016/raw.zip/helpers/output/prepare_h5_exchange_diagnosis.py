"""Copy the rejected H5 experiment and add diagnostic-only repair-stage traces."""
from pathlib import Path
from hashlib import sha256
import json, shutil, subprocess
ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'output/h5-early-exchange-probe/candidate'
OUT=ROOT/'output/h5-exchange-diagnosis'
WORK=OUT/'workspace'
TARGET=ROOT/'output/h5-exchange-diagnosis-target'
assert not OUT.exists() and not TARGET.exists()
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
files=[]
for p in sorted(OLD.rglob('*')):
    if p.is_file():
        name=p.relative_to(OLD).as_posix();dest=WORK/name
        dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
        files.append({'path':name,'sha256':digest(p)})
p=WORK/'crates/core/src/sheets/vstrip/exchange.rs';s=p.read_text(encoding='utf-8')
at='struct Proposal {'
extra='''// Diagnostic copy only: aggregate counters and emit once per invocation.
// Tracing may affect wall-clock search; these runs cannot establish quality.
#[derive(Default, serde::Serialize)]
struct ExchangeTrace {
    disabled_or_expired: bool,
    baseline_invalid: bool,
    receivers: usize,
    proposals: usize,
    expired_before_attempt: usize,
    attempts: Vec<ExchangeAttempt>,
}

#[derive(serde::Serialize)]
struct ExchangeAttempt {
    incoming_area: f32,
    victim_area: f32,
    blockers: usize,
    receiver_loss: Option<f32>,
    source_loss: Option<f32>,
    outcome: &'static str,
}

impl Drop for ExchangeTrace {
    fn drop(&mut self) {
        eprintln!("EXCHANGE_DIAG {}", serde_json::to_string(self).expect("diagnostic serialization"));
    }
}

'''
assert s.count(at)==1;s=s.replace(at,extra+at)
def replace(a,b):
    global s
    assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
replace('''        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            return Ok(0);
        }''','''        let mut trace = ExchangeTrace::default();
        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            trace.disabled_or_expired = true;
            return Ok(0);
        }''')
replace('''        if !baseline.valid {
            return Ok(0);
        }''','''        if !baseline.valid {
            trace.baseline_invalid = true;
            return Ok(0);
        }''')
replace('''                let candidates = proposals(''','''                trace.receivers += 1;
                let candidates = proposals(''')
replace('''                for proposal in candidates {
                    if self.clock.now() >= self.last_step(until) {
                        return Ok(0);
                    }''','''                trace.proposals += candidates.len();
                for proposal in candidates {
                    if self.clock.now() >= self.last_step(until) {
                        trace.expired_before_attempt += 1;
                        return Ok(0);
                    }''')
replace('''                    let victim = receiver.placed_items()[proposal.victim].item().clone();''','''                    let victim = receiver.placed_items()[proposal.victim].item().clone();
                    let index = trace.attempts.len();
                    trace.attempts.push(ExchangeAttempt {
                        incoming_area: incoming_item.area(), victim_area: victim.area(),
                        blockers: proposal.blockers, receiver_loss: None, source_loss: None,
                        outcome: "unfinished",
                    });''')
replace('''                    if receiver_tracker.total_loss() > 0.0 {
                        continue;
                    }''','''                    trace.attempts[index].receiver_loss = Some(receiver_tracker.total_loss());
                    if receiver_tracker.total_loss() > 0.0 {
                        trace.attempts[index].outcome = "receiver_repair_failed";
                        continue;
                    }''')
replace('''                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(until)
                    {
                        continue;
                    }''','''                    trace.attempts[index].source_loss = Some(source_tracker.total_loss());
                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(until)
                    {
                        trace.attempts[index].outcome = if source_tracker.total_loss() > 0.0 {
                            "source_repair_failed"
                        } else {
                            "expired_after_repairs"
                        };
                        continue;
                    }''')
replace('''                    if !report.valid {
                        self.stats.rejected_layouts += 1;''','''                    if !report.valid {
                        trace.attempts[index].outcome = "independent_geometry_failed";
                        self.stats.rejected_layouts += 1;''')
replace('''                    {
                        continue;
                    }
                    sep.layout = trial;''','''                    {
                        trace.attempts[index].outcome = if self.clock.now() >= until {
                            "expired_before_acceptance"
                        } else {
                            "material_guard_failed"
                        };
                        continue;
                    }
                    trace.attempts[index].outcome = "accepted";
                    sep.layout = trial;''')
p.write_text(s,encoding='utf-8',newline='\n')
assert all(digest(OLD/r['path'])==r['sha256'] for r in files)
write(OUT/'preparation.json',{'scope':__doc__,'old_source':str(OLD),'source_files':files,'changed_file':p.relative_to(WORK).as_posix(),'diagnostic_source_sha256':digest(p),'unique_target':str(TARGET),'behavior':'Counters and a single serialized trace per directed-exchange invocation; no changed proposal/repair/acceptance logic or budgets. Tracing can perturb wall time, so no quality comparisons.','planned_cases':{'jobs':['m-mechanical-large-plates','m-mechanical-panel-hardware'],'kerfs_mm':[0.2,1.5],'seed':0,'seconds':60,'serial_cpu':8},'measurement_prerequisite':'Depth-three H4 pilot terminal and sealed; diagnostic plan committed first','held_out_geometry_read':False,'production_unchanged':True,'measurement_started':False})
print(json.dumps({'files':len(files),'changed':str(p),'sha256':digest(p)}))
