"""Verify authored diagnostic traces and preserve the isolated observer build."""
from pathlib import Path
from hashlib import sha256
import json, shutil, subprocess, sys, zipfile
ROOT=Path(__file__).resolve().parents[1];PROBE=ROOT/'output/h5-exchange-diagnosis'
WORK=PROBE/'workspace';TARGET=ROOT/'output/h5-exchange-diagnosis-target'
OUT=ROOT/'benchmarks/results/h5-exchange-diagnosis-preparation-20261016'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
build=load(PROBE/'build.json');plan=load(PROBE/'preparation.json');assert build['all_passed']
checks=[]
for label,test,expected in [
    ('accepted','directed_exchange_returns_smaller_actual_obstruction','accepted'),
    ('source-failed','directed_exchange_failed_source_repair_leaves_layout_intact','source_repair_failed'),
    ('disabled','directed_exchange_expired_or_disabled_leaves_layout_intact',None),
]:
    command=[sys.executable,str(ROOT/'output/ccd1.py'),'cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',str(TARGET),test,'--','--nocapture']
    log=PROBE/('trace-'+label+'.log')
    with log.open('xb') as f:r=subprocess.run(command,cwd=WORK,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    assert r.returncode==0,label
    traces=[json.loads(line.removeprefix('EXCHANGE_DIAG ')) for line in log.read_text(encoding='utf-8').splitlines() if line.startswith('EXCHANGE_DIAG ')]
    assert traces,label
    if expected:assert any(a['outcome']==expected for t in traces for a in t['attempts']),label
    else:assert all(t['disabled_or_expired'] and not t['attempts'] for t in traces),label
    checks.append({'label':label,'command':command,'exit_code':r.returncode,'sha256':digest(log),'traces':traces})
write(PROBE/'trace-checks.json',{'all_passed':True,'checks':checks})
assert digest(WORK/plan['changed_file'])==build['source_sha256']
for r in plan['source_files']:
    assert digest(Path(plan['old_source'])/r['path'])==r['sha256']
    if r['path']!=plan['changed_file']:assert digest(WORK/r['path'])==r['sha256']
OUT.mkdir()
files={}
for p in PROBE.iterdir():
    if p.is_file():files['build/'+p.name]=p
for r in plan['source_files']:
    files['rejected/'+r['path']]=Path(plan['old_source'])/r['path']
    files['diagnostic/'+r['path']]=WORK/r['path']
for name in ['output/prepare_h5_exchange_diagnosis.py','output/build_h5_exchange_diagnosis.py','output/seal_h5_exchange_diagnosis.py','output/ccd1.py','scripts/h5_exchange_diagnosis.py']:
    files['helpers/'+name]=ROOT/name
inventory={n:{'sha256':digest(p),'bytes':p.stat().st_size} for n,p in files.items()}
archive=OUT/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,r in inventory.items():
        raw=z.read(name);assert len(raw)==r['bytes'] and sha256(raw).hexdigest()==r['sha256']
write(OUT/'integrity.json',{'sha256':digest(archive),'bytes':archive.stat().st_size,'members':inventory,'crc_and_every_member_verified':True})
for name in ['preparation.json','build.json','trace-checks.json']:shutil.copyfile(PROBE/name,OUT/name)
text='''# Directed-exchange repair diagnosis preparation — 2026-10-16

**The isolated diagnostic build and authored trace checks pass. No measured searches yet.**

The [rejected early-call pilot](h5-early-exchange-pilot-20261016.md) reached 179
proposals and accepted ten exchanges, but five of eight material pairs failed.
Its counters did not identify which repair or acceptance stage rejected a proposal.
This copy adds per-invocation reporting of receiver repair, source repair,
deadline, independent geometry and material-guard outcomes. Proposal generation,
repair logic, budgets and acceptance remain unchanged. Tracing may affect wall
time, so the diagnostic cannot establish performance or quality improvement.

Only the isolated exchange module changes. The prior candidate and production
sources retain their hashes. A unique build target prevents cross-workspace
cache reuse. All 82 optimized core tests, strict lint and observer build pass.
Three authored trace checks distinguish an accepted exchange, a failed source
repair and expired/disabled no-work behavior. Source before/after formatting,
both complete source copies, logs, exact binary and helpers remain archived.
CRC, every member size and every SHA-256 are verified.

[Build](h5-exchange-diagnosis-preparation-20261016/build.json),
[trace checks](h5-exchange-diagnosis-preparation-20261016/trace-checks.json),
[raw archive](h5-exchange-diagnosis-preparation-20261016/raw.zip),
[integrity](h5-exchange-diagnosis-preparation-20261016/integrity.json).

The planned diagnostic fixes the two mechanical jobs, both kerfs, seed 0 and
60 seconds, serially on physical CCD0 CPU 8. It waits for the H4 tree-depth
pilot to finish and be sealed, and for its own plan to be committed. Every
layout is independently validated and exported; all traces and failures stay.
No original failed result is replaced or rescored. No held-out geometry is read.
H5 remains open, the candidate is not integrated, and completion stays 45%.
'''
(OUT.parent/(OUT.name+'.md')).write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'members':len(inventory),'bytes':archive.stat().st_size,'sha256':digest(archive),'trace_checks':3}))
