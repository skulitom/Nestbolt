//! Isolated experiment: return a smaller actual obstruction while inserting a
//! last-sheet part, repair both sheets, then check the whole original job.
use super::*;
use jagua_rs::entities::Item;
use jagua_rs::geometry::geo_traits::TransformableFrom;

// Diagnostic copy only: aggregate counters and emit once per invocation.
// Tracing may affect wall-clock search; these runs cannot establish quality.
#[derive(Default, serde::Serialize)]
struct ExchangeTrace {
    disabled_or_expired: bool,
    baseline_invalid: bool,
    receivers: usize,
    proposals: usize,
    expired_before_attempt: usize,
    attempts: Vec<ExchangeAttempt>,
}

#[derive(serde::Serialize)]
struct ExchangeAttempt {
    incoming_area: f32,
    victim_area: f32,
    blockers: usize,
    receiver_loss: Option<f32>,
    source_loss: Option<f32>,
    outcome: &'static str,
}

impl Drop for ExchangeTrace {
    fn drop(&mut self) {
        eprintln!(
            "EXCHANGE_DIAG {}",
            serde_json::to_string(self).expect("diagnostic serialization")
        );
    }
}

struct Proposal {
    victim: PItemKey,
    incoming: DTransformation,
    blockers: usize,
    rank: usize,
    area: f32,
}

fn proposals(
    receiver: &JLayout,
    incoming: &Item,
    rng: &mut Xoshiro256PlusPlus,
    clock: &Clock,
    until: f64,
) -> Vec<Proposal> {
    let bounds = receiver.container().outer_cd().bbox();
    let mut buffer = incoming.shape_cd().as_ref().clone();
    let mut samples = Vec::new();
    // Anchors make an actual obstruction, rather than a merely nearby part,
    // the return candidate. Align bounding-box corners after snapping rotation.
    for p in receiver.placed_items().values() {
        let dt = convert_sample_to_closest_feasible(p.d_transf(), incoming);
        buffer.transform_from(incoming.shape_cd(), &dt.compose());
        let a = buffer.bbox();
        let b = p.shape().bbox();
        let (x, y) = dt.translation();
        samples.push(
            DTransformation::new(
                dt.rotation(),
                (x + b.x_min - a.x_min, y + b.y_min - a.y_min),
            )
            .with_reflection(dt.reflected),
        );
    }
    if let Some(sampler) = UniformBBoxSampler::new(bounds, incoming, bounds) {
        samples.extend((0..128).map(|_| sampler.sample(rng)));
    }
    let mut collector = BasicHazardCollector::new();
    let mut out: Vec<Proposal> = Vec::new();
    for dt in samples {
        if clock.now() >= until {
            break;
        }
        buffer.transform_from(incoming.shape_cd(), &dt.compose());
        collector.clear();
        receiver
            .cde()
            .collect_poly_collisions(&buffer, &NoFilter, &mut collector);
        crate::separate::charge(clock, incoming, 1);
        if collector.is_empty()
            || collector.len() > 3
            || collector
                .iter()
                .any(|(_, h)| !matches!(h, BasicHazardEntity::PlacedItem { .. }))
        {
            continue;
        }
        // Stable receiver placement order, independent of tree traversal order.
        for (rank, (key, p)) in receiver.placed_items().iter().enumerate() {
            if p.item().area() >= incoming.area()
                || !collector.iter().any(
                    |(_, h)| matches!(h, BasicHazardEntity::PlacedItem { pk, .. } if *pk == key),
                )
            {
                continue;
            }
            let proposal = Proposal {
                victim: key,
                incoming: dt,
                blockers: collector.len(),
                rank,
                area: p.item().area(),
            };
            if let Some(previous) = out.iter().position(|p| p.victim == key) {
                if out[previous].blockers <= proposal.blockers {
                    continue;
                }
                out.remove(previous);
            }
            out.push(proposal);
            out.sort_by(|a, b| {
                a.blockers
                    .cmp(&b.blockers)
                    .then(a.area.total_cmp(&b.area))
                    .then(a.rank.cmp(&b.rank))
            });
            out.truncate(6);
        }
    }
    out
}

impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search<'_, '_, F> {
    fn exchange_report(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        layout: &JLayout,
        shape: Shape,
    ) -> Result<Report> {
        let mut sheets = frozen.to_vec();
        sheets.extend(strip.split(layout, shape.sheets)?);
        let layout = self.model.to_layout(&sheets);
        let started = Instant::now();
        let report = validate(self.model.job, &layout)?;
        self.clock.validated(self.model.job, &layout);
        self.check_cost = self.check_cost.max(started.elapsed().as_secs_f64());
        Ok(report)
    }

    /// At most one exchange. The original separator is untouched until both
    /// repairs and the independent whole-job material/geometry guard pass.
    pub(super) fn directed_exchange(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
    ) -> Result<usize> {
        let mut trace = ExchangeTrace::default();
        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            trace.disabled_or_expired = true;
            return Ok(0);
        }
        let baseline = self.exchange_report(strip, frozen, &sep.layout, shape)?;
        if !baseline.valid {
            trace.baseline_invalid = true;
            return Ok(0);
        }
        let before = baseline.metrics.as_ref().expect("valid baseline");
        let single = strip.container(Shape {
            sheets: 1,
            last: self.model.full_width,
        })?;
        let last_container = strip.container(Shape {
            sheets: 1,
            last: shape.last,
        })?;
        let last_index = shape.sheets - 1;
        let last_offset = strip.start(last_index);
        let mut incoming_keys = strip.in_last(&sep.layout, shape);
        incoming_keys.sort_by(|&a, &b| {
            sep.layout.placed_items()[b]
                .item()
                .area()
                .total_cmp(&sep.layout.placed_items()[a].item().area())
        });
        let mut fill = vec![0.0_f32; last_index];
        for p in sep
            .layout
            .placed_items()
            .values()
            .filter(|p| !strip.is_blocker(p))
        {
            let i = strip.sheet_of(p.shape());
            if i < last_index {
                fill[i] += p.item().area();
            }
        }
        let mut targets: Vec<_> = (0..last_index).collect();
        targets.sort_by(|&a, &b| fill[a].total_cmp(&fill[b]));
        for incoming_key in incoming_keys {
            let incoming = &sep.layout.placed_items()[incoming_key];
            let incoming_item = incoming.item().clone();
            let incoming_old = shift(incoming.d_transf(), -last_offset);
            for &target in targets.iter().take(3) {
                if self.clock.now() >= self.last_step(until) {
                    return Ok(0);
                }
                let offset = strip.start(target);
                let mut receiver = JLayout::new(single.clone());
                let mut source = JLayout::new(last_container.clone());
                let mut changed_keys = Vec::new();
                for (key, p) in sep
                    .layout
                    .placed_items()
                    .iter()
                    .filter(|(_, p)| !strip.is_blocker(p))
                {
                    let i = strip.sheet_of(p.shape());
                    if i == target {
                        receiver.place_item(p.item(), shift(p.d_transf(), -offset));
                        changed_keys.push(key);
                    } else if i == last_index {
                        if key != incoming_key {
                            source.place_item(p.item(), shift(p.d_transf(), -last_offset));
                        }
                        changed_keys.push(key);
                    }
                }
                self.clock
                    .charge(Work::RegisteredItem, changed_keys.len() as f64);
                let proposal_until = self.last_step(until);
                trace.receivers += 1;
                let candidates = proposals(
                    &receiver,
                    &incoming_item,
                    &mut self.rng,
                    &self.clock,
                    proposal_until,
                );
                trace.proposals += candidates.len();
                for proposal in candidates {
                    if self.clock.now() >= self.last_step(until) {
                        trace.expired_before_attempt += 1;
                        return Ok(0);
                    }
                    self.stats.directed_exchange_attempts += 1;
                    let victim = receiver.placed_items()[proposal.victim].item().clone();
                    let index = trace.attempts.len();
                    trace.attempts.push(ExchangeAttempt {
                        incoming_area: incoming_item.area(),
                        victim_area: victim.area(),
                        blockers: proposal.blockers,
                        receiver_loss: None,
                        source_loss: None,
                        outcome: "unfinished",
                    });
                    let mut next_receiver = JLayout::from_snapshot(&receiver.save());
                    next_receiver.remove_item(proposal.victim);
                    next_receiver.place_item(&incoming_item, proposal.incoming);
                    let mut next_source = JLayout::from_snapshot(&source.save());
                    next_source.place_item(
                        &victim,
                        convert_sample_to_closest_feasible(incoming_old, &victim),
                    );
                    self.clock
                        .charge(Work::RegisteredItem, changed_keys.len() as f64);
                    let now = self.clock.now();
                    // Bound each pair so one hard proposal cannot consume all
                    // remaining opportunities. Each repair gets half the pair.
                    let pair_end = now + ((self.last_step(until) - now) * 0.5).min(0.4);
                    let middle = (now + pair_end) / 2.0;
                    let mut receiver_sep = Separator::new(
                        next_receiver,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    let (receiver_snapshot, receiver_tracker) =
                        receiver_sep.separate(&self.deadline(middle));
                    trace.attempts[index].receiver_loss = Some(receiver_tracker.total_loss());
                    if receiver_tracker.total_loss() > 0.0 {
                        trace.attempts[index].outcome = "receiver_repair_failed";
                        continue;
                    }
                    let mut source_sep = Separator::new(
                        next_source,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    let (source_snapshot, source_tracker) =
                        source_sep.separate(&self.deadline(pair_end));
                    trace.attempts[index].source_loss = Some(source_tracker.total_loss());
                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(until)
                    {
                        trace.attempts[index].outcome = if source_tracker.total_loss() > 0.0 {
                            "source_repair_failed"
                        } else {
                            "expired_after_repairs"
                        };
                        continue;
                    }
                    let mut trial = JLayout::from_snapshot(&sep.layout.save());
                    for &key in &changed_keys {
                        trial.remove_item(key);
                    }
                    for (snapshot, start) in
                        [(receiver_snapshot, offset), (source_snapshot, last_offset)]
                    {
                        for p in JLayout::from_snapshot(&snapshot).placed_items().values() {
                            trial.place_item(p.item(), shift(p.d_transf(), start));
                        }
                    }
                    self.clock.charge(
                        Work::RegisteredItem,
                        (sep.layout.placed_items().len() + changed_keys.len()) as f64,
                    );
                    let report = self.exchange_report(strip, frozen, &trial, shape)?;
                    if !report.valid {
                        trace.attempts[index].outcome = "independent_geometry_failed";
                        self.stats.rejected_layouts += 1;
                        continue;
                    }
                    let after = report.metrics.as_ref().expect("valid exchange");
                    if after.sheets_used > before.sheets_used
                        || after.material_area > before.material_area
                        || self.clock.now() >= until
                    {
                        trace.attempts[index].outcome = if self.clock.now() >= until {
                            "expired_before_acceptance"
                        } else {
                            "material_guard_failed"
                        };
                        continue;
                    }
                    trace.attempts[index].outcome = "accepted";
                    sep.layout = trial;
                    sep.rebuild();
                    self.stats.directed_exchanges += 1;
                    return Ok(1);
                }
            }
        }
        Ok(0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nestbolt_validator::job::{Margins, Part, Stock};
    use nestbolt_validator::{Polygon, Units};

    fn rectangle(id: &str, width: f64, height: f64) -> Part {
        Part {
            id: id.into(),
            quantity: 1,
            geometry: vec![Polygon {
                outer: vec![[0.0, 0.0], [width, 0.0], [width, height], [0.0, height]],
                holes: vec![],
            }],
            rotations: Rotations::List { degrees: vec![0.0] },
            allow_mirror: false,
            priority: 1.0,
        }
    }

    fn fixture() -> (Job, Layout) {
        let job = Job {
            version: 1,
            name: "authored exchange".into(),
            units: Units::Mm,
            parts: vec![
                rectangle("filler", 60.0, 94.0),
                rectangle("return", 30.0, 20.0),
                rectangle("incoming", 30.0, 85.0),
            ],
            stocks: vec![Stock {
                id: "stock".into(),
                width: 100.0,
                height: 100.0,
                count: None,
                margins: Margins::default(),
                outline: vec![],
                defects: vec![],
            }],
            clearance: 0.2,
            edge_clearance: 1.0,
            mode: Mode::All,
        };
        let layout = Layout {
            version: 1,
            units: Units::Mm,
            sheets: (0..2)
                .map(|i| Sheet {
                    id: format!("sheet-{i}"),
                    stock_id: "stock".into(),
                })
                .collect(),
            placements: [
                ("filler", 0, [2.0, 2.0]),
                ("return", 0, [64.0, 2.0]),
                ("incoming", 1, [2.0, 2.0]),
            ]
            .into_iter()
            .map(|(id, sheet, translation)| Placement {
                part_id: id.into(),
                copy_index: 0,
                sheet_id: format!("sheet-{sheet}"),
                transform: RigidTransform {
                    translation,
                    rotation_radians: 0.0,
                    mirrored: false,
                },
            })
            .collect(),
        };
        (job, layout)
    }

    fn fingerprint(layout: &JLayout) -> String {
        format!(
            "{:?}",
            layout
                .placed_items()
                .iter()
                .map(|(k, p)| (k, p.item().idx(), p.d_transf()))
                .collect::<Vec<_>>()
        )
    }

    fn exercise(
        job: &Job,
        layout: &Layout,
        seed: u64,
        enabled: bool,
        expired: bool,
        frozen_count: usize,
    ) -> (usize, Layout, Stats) {
        let validation = validate(job, layout).unwrap();
        assert!(validation.valid, "{:?}", validation.violations);
        let model = Model::new(job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut search = Search {
            model: &model,
            allow_exchange: enabled,
            rng: Xoshiro256PlusPlus::seed_from_u64(seed),
            clock: clock.clone(),
            best: (layout.clone(), validation, 0.0),
            history: vec![],
            stats: Stats::default(),
            progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
            check_cost: 0.0,
            check_every: 5.0,
        };
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(layout).unwrap();
        let (frozen, window) = sheets.split_at(frozen_count);
        let mut shape = Shape {
            sheets: window.len(),
            last: model.full_width,
        };
        let initial = strip.layout(window, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut sep = Separator::new(
            strip.layout(window, shape).unwrap(),
            seed,
            EXPLORE,
            search.clock.clone(),
        );
        sep.pin(blocker_index(&model));
        assert_eq!(sep.tracker.total_loss(), 0.0);
        // Compare the same f32 internal frame before/after the exchange. The
        // public-to-internal conversion predates this operation and has its own
        // tests; comparing to the authored f64 coordinates conflates the two.
        let mut before_sheets = frozen.to_vec();
        before_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let before_layout = model.to_layout(&before_sheets);
        let before_report = validate(job, &before_layout).unwrap();
        assert!(before_report.valid);
        let before_material = before_report.metrics.as_ref().unwrap().material_area;
        let original = fingerprint(&sep.layout);
        let until = if expired {
            0.0
        } else {
            search.clock.now() + 3.0
        };
        let moved = search
            .directed_exchange(&strip, frozen, &mut sep, shape, until)
            .unwrap();
        if moved == 0 {
            assert_eq!(
                fingerprint(&sep.layout),
                original,
                "failed proposal mutated the original state"
            );
        }
        let mut after_sheets = frozen.to_vec();
        after_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let after = model.to_layout(&after_sheets);
        for i in 0..frozen_count {
            let id = format!("sheet-{i}");
            let before_fixed: Vec<_> = before_layout
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            let after_fixed: Vec<_> = after
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            assert_eq!(
                serde_json::to_value(before_fixed).unwrap(),
                serde_json::to_value(after_fixed).unwrap()
            );
        }
        let report = validate(job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert!(report.metrics.as_ref().unwrap().material_area <= before_material);
        assert_eq!(sep.tracker.total_loss(), 0.0);
        eprintln!(
            "authored exchange seed={seed} enabled={enabled} expired={expired} frozen={frozen_count} moved={moved} attempts={} material_before={before_material:.9} material_after={:.9}",
            search.stats.directed_exchange_attempts,
            report.metrics.as_ref().unwrap().material_area
        );
        (moved, after, search.stats)
    }

    #[test]
    fn window_search_reaches_exchange_before_gap_filling() {
        let (mut job, mut layout) = fixture();
        // This small last-sheet part fits an earlier gap. A successful fill
        // must not bypass the exchange opportunity for the large incoming part.
        job.parts.push(rectangle("gap-part", 5.0, 5.0));
        layout.placements.push(Placement {
            part_id: "gap-part".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [36.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        for (enabled, budget) in [(true, 20.0), (false, 20.0), (true, 0.0)] {
            let report = validate(&job, &layout).unwrap();
            assert!(report.valid);
            let before_material = report.metrics.as_ref().unwrap().material_area;
            let model = Model::new(&job).unwrap();
            let clock = Clock::new(Timing::Work, 30.0);
            let mut search = Search {
                model: &model,
                allow_exchange: enabled,
                rng: Xoshiro256PlusPlus::seed_from_u64(0),
                clock,
                best: (layout.clone(), report, 0.0),
                history: vec![],
                stats: Stats::default(),
                progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
                check_cost: 0.0,
                check_every: 5.0,
            };
            search
                .window_search(model.sheets_of(&layout).unwrap(), budget, 0.2, 2)
                .unwrap();
            let checked = validate(&job, &search.best.0).unwrap();
            assert!(checked.valid);
            assert!(checked.metrics.as_ref().unwrap().material_area <= before_material);
            if enabled && budget > 0.0 {
                assert!(search.stats.directed_exchange_attempts > 0);
                assert!(search.stats.directed_exchanges > 0);
            } else {
                assert_eq!(search.stats.directed_exchange_attempts, 0);
                assert_eq!(search.stats.directed_exchanges, 0);
            }
            eprintln!(
                "window exchange enabled={enabled} budget={budget} attempts={} accepted={} valid={}",
                search.stats.directed_exchange_attempts,
                search.stats.directed_exchanges,
                checked.valid
            );
        }
    }

    #[test]
    fn directed_exchange_returns_smaller_actual_obstruction() {
        let (job, layout) = fixture();
        for seed in 0..5 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            assert_eq!(moved, 1, "seed {seed}, {stats:?}");
            assert_eq!(stats.directed_exchanges, 1);
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
            );
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
            );
        }
    }

    #[test]
    fn directed_exchange_expired_or_disabled_leaves_layout_intact() {
        let (job, layout) = fixture();
        for (enabled, expired) in [(true, true), (false, false)] {
            let (moved, _, stats) = exercise(&job, &layout, 0, enabled, expired, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.directed_exchange_attempts, 0);
        }
    }

    #[test]
    fn directed_exchange_refuses_larger_return_parts() {
        let (mut job, layout) = fixture();
        job.parts[2] = rectangle("incoming", 20.0, 10.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchange_attempts, 0);
    }

    #[test]
    fn directed_exchange_preserves_frozen_sheets_and_mirror_contract() {
        let (mut job, mut layout) = fixture();
        job.parts.push(rectangle("fixed", 20.0, 20.0));
        for p in &mut layout.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        let fixed = Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        };
        layout.placements.push(fixed.clone());
        job.parts[2].allow_mirror = true;
        let incoming = layout
            .placements
            .iter_mut()
            .find(|p| p.part_id == "incoming")
            .unwrap();
        incoming.transform.mirrored = true;
        incoming.transform.translation[0] += 30.0;
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 1);
        assert_eq!(moved, 1);
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "fixed" && p.sheet_id == "sheet-0")
        );
    }

    #[test]
    fn directed_exchange_failed_source_repair_leaves_layout_intact() {
        let (mut job, layout) = fixture();
        job.parts[1] = rectangle("return", 5.0, 90.0);
        job.parts[2] = rectangle("incoming", 30.0, 30.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert!(stats.directed_exchange_attempts > 0);
    }

    #[test]
    fn directed_exchange_respects_stock_defects() {
        let (mut job, layout) = fixture();
        job.edge_clearance = job.clearance;
        job.stocks[0].defects.push(Polygon {
            outer: vec![[96.0, 20.0], [98.0, 20.0], [98.0, 30.0], [96.0, 30.0]],
            holes: vec![],
        });
        let (moved, _, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
    }
}
