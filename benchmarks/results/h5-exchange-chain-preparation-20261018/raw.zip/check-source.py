"""Reconstruct candidate exactly and prove single-exchange behavior unchanged."""
from pathlib import Path
from hashlib import sha256
import ast,difflib,json,re,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-exchange-chain-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');assert load(out/'build.json')['all_checks_passed']
parent=Path(plan['old_probe'])/'candidate';rel=plan['changed_files'][0]
prior=(parent/rel).read_text(encoding='utf-8');current=(out/'candidate'/rel).read_text(encoding='utf-8')
old_runtime,old_tests=prior.split('#[cfg(test)]\nmod tests {',1);runtime,tests=current.split('#[cfg(test)]\nmod tests {',1)
a=runtime.index('// A successful flat exchange');b=runtime.index('impl<F:',a);helper=runtime[a:b];restored=runtime[:a]+runtime[b:]
a=restored.index('    pub(super) fn directed_exchange_chain(');b=restored.index('    /// At most one exchange.',a);wrapper=restored[a:b];restored=restored[:a]+restored[b:]
assert 'continue_exchanges(|| self.directed_exchange_once(strip, frozen, sep, shape, until))' in wrapper
assert '#[cfg(test)]' in wrapper and 'Ok(usize::from(' in wrapper
restored=restored.replace('fn directed_exchange_once(', 'pub(super) fn directed_exchange(').replace('Result<Option<bool>>','Result<usize>').replace('return Ok(None);','return Ok(0);').replace('return Ok(Some(after.material_area < before.material_area));','return Ok(1);').replace('        Ok(None)','        Ok(0)')
assert restored==old_runtime,'Original runtime must be exact after return-type adapter reversal'
assert tests.split('    fn chain_exercise(',1)[0].rstrip()==old_tests.rsplit('\n}',1)[0].rstrip()
caller=plan['changed_files'][1];a=(parent/caller).read_text(encoding='utf-8');b=(out/'candidate'/caller).read_text(encoding='utf-8')
assert b.replace('self.directed_exchange_chain(','self.directed_exchange(')==a
red=(out/'before-chain'/rel).read_text(encoding='utf-8');script=ast.parse((out/'apply.py').read_text(encoding='utf-8'))
implementation=next(ast.literal_eval(n.value) for n in script.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='implementation' for t in n.targets))
stub=(out/'stub.txt').read_text(encoding='utf-8');assert red.count(stub)==1
fresh=root/'output/h5-exchange-chain-reconstruction-20261018';shutil.copytree(out/'candidate',fresh)
(fresh/rel).write_text(red.replace(stub,implementation),encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
for row in plan['old_source_files']['candidate']:
 name=row['path'];assert digest(parent/name)==row['sha256'];assert (fresh/name).read_bytes()==(out/'candidate'/name).read_bytes()
 if name not in plan['changed_files']:assert digest(out/'candidate'/name)==row['sha256']
record={'all_checks_passed':True,'prior_tests_unchanged':137,'new_tests':4,'original_single_exchange_runtime_exact_after_return_adapter_reversal':True,'original_caller_exact_after_dispatch_rename':True,'all_formatted_reconstructed_files_exact':True,'reconstructed_files':len(plan['old_source_files']['candidate']),'unchanged_other_files':len(plan['old_source_files']['candidate'])-2,'maximum_exchanges_per_window':4,'original_absolute_deadline_preserved':True,'continues_only_after_strict_material_gain':True,'no_new_validation_or_geometry_work':True,'no_new_random_samples':True,'new_searches':0}
for name in ['reconstruction.json','source-checks.json']:(out/name).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
patch=''
for rel in plan['changed_files']:patch+=''.join(difflib.unified_diff((parent/rel).read_text(encoding='utf-8').splitlines(True),(out/'candidate'/rel).read_text(encoding='utf-8').splitlines(True),fromfile='free-return/'+rel,tofile='exchange-chain/'+rel))
(out/'candidate.patch').write_text(patch,encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'check-source.py');print(json.dumps(record))
