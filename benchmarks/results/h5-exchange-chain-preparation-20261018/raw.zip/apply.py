from pathlib import Path
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-exchange-chain-probe-20261018'
assert json.loads((out/'before-chain/checks.json').read_bytes())['expected_runtime_failure']
path=out/'candidate/crates/core/src/sheets/vstrip/exchange.rs';s=path.read_text(encoding='utf-8')
stub=(out/'stub.txt').read_text(encoding='utf-8')
implementation='''// A successful flat exchange remains accepted, but must end continuation.
fn continue_exchanges(mut step: impl FnMut() -> Result<Option<bool>>) -> Result<usize> {
    let mut accepted = 0;
    for _ in 0..4 {
        let Some(material_improved) = step()? else { break };
        accepted += 1;
        if !material_improved { break; }
    }
    Ok(accepted)
}

'''
assert s.count(stub)==1;s=s.replace(stub,implementation);path.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
shutil.copyfile(__file__,out/'apply.py')
print('Applied four-step continuation; per-step geometry, material guards and absolute deadline remain unchanged.')
