"""Preserve measurement/scoring; account for one gap-fill call after up to four exchanges."""
from pathlib import Path
from hashlib import sha256
import json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-exchange-chain-probe-20261018'
def adapt(s):return s.replace('h5-free-return','h5-exchange-chain').replace('h5_free_return','h5_exchange_chain').replace('Free-space-return','Exchange-continuation')
def save(name,s):compile(s,name,'exec');(root/'output'/name).write_text(s,encoding='utf-8',newline='\n')
s=adapt((root/'output/finish_h5_free_return_pilot.py').read_text(encoding='utf-8'))
start=s.index("    'The candidate searches at most 256");end=s.index("    'Four jobs, two kerfs",start)
s=s[:start]+'''    'The candidate continues after strict material improvements, accepting at',
    'most four exchanges in one window. Every attempt shares the original',
    'absolute deadline and retains all original geometry/material guards.',
    'Rejection or an accepted flat result stops the sequence. The qualified',
    'free-space return seed, proposal choices and per-attempt repairs remain.',
    '[Qualification](h5-exchange-chain-preparation-20261018.md) retains 141 passing',
    'tests: all 137 prior tests unchanged and four new regressions. Exact source',
    'reconstruction, public replay, authored geometry checks, lint and build pass.',
    'The old-behavior regression failures and preparation syntax failure remain.','',
'''+s[end:]
old="    if row['arm']=='candidate':assert calls==stats.get('directed_exchanges',0)"
new="    if row['arm']=='candidate':assert calls<=stats.get('directed_exchanges',0)<=4*calls"
assert s.count(old)==1;s=s.replace(old,new)
needle="    'These operation counts do not by themselves establish final material improvement.','']"
assert s.count(needle)==1;s=s.replace(needle,"    'One gap-fill call follows each window with one to four accepted exchanges.',\n"+needle)
save('finish_h5_exchange_chain_pilot.py',s)
save('audit_h5_exchange_chain.py',adapt((root/'output/audit_h5_free_return.py').read_text(encoding='utf-8')))
record={'parent_finisher':'output/finish_h5_free_return_pilot.py','parent_sha256':sha256((root/'output/finish_h5_free_return_pilot.py').read_bytes()).hexdigest(),'counter_assertion_before':old.strip(),'counter_assertion_after':new.strip(),'reason':'Gap filling still runs once after each accepted window; continuation may accept up to four exchanges in that window. All original counter values remain unchanged.','geometry_and_scoring_assertions_unchanged':True,'candidate_finisher_sha256':sha256((root/'output/finish_h5_exchange_chain_pilot.py').read_bytes()).hexdigest(),'new_searches':0}
(probe/'counter-audit-method.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(record))
