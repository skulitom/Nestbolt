"""Seal functional qualification before committing any development measurement plan."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-exchange-chain-probe-20261018';out=root/'benchmarks/results/h5-exchange-chain-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');source=load(probe/'reconstruction.json')
public=load(probe/'public-checks/checks.json');branch=load(probe/'branch-checks/checks.json');chain=load(probe/'chain-checks/checks.json')
assert all(x['all_checks_passed'] for x in [build,source,public,branch,chain])
assert '141 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert source['prior_tests_unchanged']==137 and source['unchanged_other_files']==154
assert source['original_single_exchange_runtime_exact_after_return_adapter_reversal'] and source['original_caller_exact_after_dispatch_rename']
red=load(probe/'before-chain/checks.json');assert red['expected_runtime_failure']
assert digest(probe/'before-chain/expected-failure.log')==red['log_sha256'] and digest(probe/'before-chain/authored-tests.exe')==red['binary_sha256']
syntax=load(probe/'preparation-syntax-failure/repair.json');assert digest(probe/'preparation-syntax-failure/exchange.rs')==syntax['failed_source_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
 for row in rows:
  assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
  if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for rel,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/rel)==expected
assert public['observer_outcomes']==10 and public['CLI_cross_checks']==4 and branch['actual_outcomes']==12 and branch['public_validations']==24
assert chain['new_chain_tests']==4 and chain['public_CLI_validations']==14
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json');assert digest(root/method['reference'])==method['reference_sha256'];assert digest(root/method['candidate_runner'])==method['runner_sha256']
assert method['scoring_measurement_and_PID_reuse_guard_unchanged']
counter=load(probe/'counter-audit-method.json');assert digest(root/'output/finish_h5_exchange_chain_pilot.py')==counter['candidate_finisher_sha256']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare','repair_preparation','check_red','apply','build','prepare_checks','check_source','check_witness','check_public','check_branch','check_harness','prepare_finish','seal','record_preparation']:
 filename={'repair_preparation':'repair_h5_exchange_chain_preparation.py'}.get(name,name+'_h5_exchange_chain.py')
 if name.startswith('check_') and name!='check_red':filename='check_h5_exchange_chain_'+name.removeprefix('check_')+'.py'
 if name=='check_red':filename='check_h5_exchange_chain_red.py'
 if name=='prepare_checks':filename='prepare_h5_exchange_chain_checks.py'
 if name=='prepare_finish':filename='prepare_h5_exchange_chain_finish.py'
 if name=='record_preparation':filename='record_h5_exchange_chain_preparation.py'
 files['helpers/'+filename]=root/'output'/filename
for name in ['finish_h5_exchange_chain_pilot.py','audit_h5_exchange_chain.py']:files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_exchange_chain_pilot.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(inventory)
 for n,row in inventory.items():
  b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_functional_checks_pass':True,'optimized_core_tests_passed':141,'prior_tests_unchanged':137,'new_tests':4,'expected_two_runtime_failures_preserved':True,'preparation_syntax_failure_preserved':True,'strict_lint_passed':True,'observer_build_passed':True,'single_exchange_guards_unchanged':True,'absolute_deadline_unchanged':True,'maximum_exchanges_per_window':4,'continues_only_after_strict_material_gain':True,'all_156_formatted_files_reconstruct_exactly':True,'unchanged_other_files':154,'actual_branch_outcomes':12,'branch_frozen_CLI_checks':24,'chain_witness_outcomes':7,'chain_witness_CLI_checks':14,'public_observer_outcomes':10,'public_CLI_cross_checks':4,'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,'pilot_harness_tests':5,'PID_reuse_guard_unchanged':True,'post_fill_counter_bound_updated_for_four_exchanges':True,'production_unchanged':True,'measurement_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','source-checks.json','reconstruction.json','candidate.patch','pilot-method.json','counter-audit-method.json']:shutil.copyfile(probe/name,out/name)
for sub,name in [('before-chain','expected-failure'),('public-checks','public-checks'),('branch-checks','branch-checks'),('chain-checks','chain-checks')]:shutil.copyfile(probe/sub/'checks.json',out/(name+'.json'))
doc='''# Exchange continuation — preparation, 2026-10-18

The [free-return observations](h5-free-return-observer-20261018.md) found that
neither of two accepted large-plate exchanges saved 0.1 mm of charged height.
The caller stopped after that first acceptance. This candidate allows up to
four successive exchanges under the same original absolute deadline. It continues
only after a strict material reduction, stopping on rejection or an accepted
flat result. Original per-step repair, geometry, material, orientation, inventory
and filled-hole guards remain. The preceding return-seed search remains unchanged.
This hypothesis does not resolve the observed panel repair failures by itself.

All 141 optimized core tests pass, including all 137 prior tests unchanged and
four new regressions. Those regressions first produce two expected runtime
failures against the one-step behavior; two preservation tests already pass.
The source, binary and logs remain. An earlier source assembly omitted a newline,
joining a new helper declaration to a comment; formatting rejected it before
compilation. The failed source/script and minimal newline repair are preserved.

New tests cover the four-step cap, stopping on no acceptance or a flat acceptance,
actual successive material improvements and deterministic replay, disabled,
expired and validation-expired operations, and failed repair with a frozen prefix.
Seven saved native outputs pass fourteen frozen-CLI validations and independent
filled-outer clearance checks. Twelve unchanged single-step branch outcomes pass
24 further frozen-CLI checks. Ten public outcomes and four public CLI comparisons
prove normal results unchanged except wall time and common-mode replay exact.

Strict lint and the experimental build pass. All 156 formatted source files
reconstruct exactly; 154 files are unchanged. Reversing the return-type adapter
restores the original single-exchange runtime exactly. Reversing the caller name
restores the original window caller exactly. No extra geometry validation or
random draw is introduced. Every attempt receives the same absolute deadline.

Five adversarial harness tests pass. Measurement, scoring, rotating arm order and
the process identity guard are AST-identical to the preceding pilot. The evidence
counter now requires one gap-fill call for each window of one to four accepted
exchanges; the underlying counter values and geometry/scoring checks are unchanged.

The next pilot must commit its plan before measuring four development jobs,
both kerfs and three seeds at matched 60-second budgets on eight physical CCD0
cores. No quality measurement has begun. H5 still requires every original limit
and the full 13-job evaluation. Production and release claims are unchanged.
**H2/H5 remain open; completed milestone weight is 60%.**

[Checks](h5-exchange-chain-preparation-20261018/checks.json),
[authored geometry](h5-exchange-chain-preparation-20261018/chain-checks.json),
[exact source reconstruction](h5-exchange-chain-preparation-20261018/reconstruction.json),
[raw evidence](h5-exchange-chain-preparation-20261018/raw.zip),
[archive integrity](h5-exchange-chain-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
print(json.dumps({'all_functional_checks_pass':True,'members':len(inventory),'archive_bytes':archive.stat().st_size,'new_quality_runs':0}))
