from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-exchange-chain-probe-20261018'
for stage in ['public','branch','harness']:
 s=(root/f'output/check_h5_free_return_{stage}.py').read_text(encoding='utf-8').replace('h5-free-return','h5-exchange-chain').replace('h5_free_return','h5_exchange_chain')
 compile(s,stage,'exec');(root/f'output/check_h5_exchange_chain_{stage}.py').write_text(s,encoding='utf-8',newline='\n')
s=(root/'output/build_h5_free_return.py').read_text(encoding='utf-8').replace('h5-free-return','h5-exchange-chain')
s=s.replace("'--','--nocapture'", "'--','--nocapture','--test-threads=1'")
(root/'output/build_h5_exchange_chain.py').write_text(s,encoding='utf-8',newline='\n')
ref=root/'scripts/h5_free_return_pilot.py';original=ref.read_text(encoding='utf-8')
s=original.replace('h5-free-return-probe','h5-exchange-chain-probe').replace('h5-free-return-preparation','h5-exchange-chain-preparation')
end=s.index('"""',3)+3
s='''"""Paired development pilot of bounded continuation after beneficial exchanges.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The baseline is the unchanged preview. This isolated candidate retains the
qualified free-space return initializer and adds up to four successive exchanges
within the original absolute exchange deadline. It continues only after a strict
material decrease, and stops on rejection or an accepted flat exchange. Every
step retains the independent geometry/material guards and filled-hole reservation.
137 existing tests and four new regressions qualify before measurement.
This descriptive pilot cannot close H5 or justify a comparative claim.
"""'''+s[end:]
s=s.replace('Isolated free-space-return candidate','Isolated exchange-continuation candidate')
needle="ROOT/'benchmarks/results/h5-contained-return-pilot-20261018/interpretation.json'"
assert s.count(needle)==1;s=s.replace(needle,needle+",\n                  ROOT/'benchmarks/results/h5-free-return-pilot-20261018/verification.json',\n                  ROOT/'benchmarks/results/h5-free-return-observer-20261018/source-review.json'")
s=s.replace("PROBE/'branch-checks/checks.json', PROBE/'seed-checks/checks.json'", "PROBE/'branch-checks/checks.json', PROBE/'chain-checks/checks.json'")
path=root/'scripts/h5_exchange_chain_pilot.py';assert not path.exists();compile(s,str(path),'exec');path.write_text(s,encoding='utf-8',newline='\n')
def fn(t,n):return next(x for x in ast.parse(t).body if isinstance(x,ast.FunctionDef) and x.name==n)
names=['blocks','summarize','case','measure','require_runner_stopped','require_measurements_finished']
for n in names:assert ast.dump(fn(s,n))==ast.dump(fn(original,n))
method={'reference':ref.relative_to(root).as_posix(),'reference_sha256':sha256(ref.read_bytes()).hexdigest(),'candidate_runner':path.relative_to(root).as_posix(),'runner_sha256':sha256(path.read_bytes()).hexdigest(),'identical_function_ASTs':names,'scoring_measurement_and_PID_reuse_guard_unchanged':True}
(probe/'pilot-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(method))
