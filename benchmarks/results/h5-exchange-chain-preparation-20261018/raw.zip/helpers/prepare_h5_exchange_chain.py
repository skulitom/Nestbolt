"""Prepare continuation after strictly beneficial exchanges under one fixed deadline."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, subprocess, sys
root=Path(__file__).resolve().parents[1]
old=root/'output/h5-free-return-probe-20261018';out=root/'output/h5-exchange-chain-probe-20261018'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert json.loads((root/'benchmarks/results/h5-free-return-observer-20261018/source-review.json').read_bytes())['lower_return_seed_witnesses']==0
out.mkdir()
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
original=path.read_text(encoding='utf-8');text=original
stub='''// A successful flat exchange remains accepted, but must end continuation.
fn continue_exchanges(mut step: impl FnMut() -> Result<Option<bool>>) -> Result<usize> {
    Ok(usize::from(step()?.is_some()))
}

'''
needle='impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search';assert text.count(needle)==1;text=text.replace(needle,stub+needle)
needle='''    /// At most one exchange. The original separator is untouched until both'''
wrappers='''    pub(super) fn directed_exchange_chain(
        &mut self, strip: &Strip, frozen: &[SPProblem], sep: &mut Separator,
        shape: Shape, until: f64,
    ) -> Result<usize> {
        // Each attempt receives the original absolute deadline. The already
        // validated material comparison supplies the continuation decision.
        continue_exchanges(|| self.directed_exchange_once(strip, frozen, sep, shape, until))
    }

    #[cfg(test)]
    fn directed_exchange(
        &mut self, strip: &Strip, frozen: &[SPProblem], sep: &mut Separator,
        shape: Shape, until: f64,
    ) -> Result<usize> {
        Ok(usize::from(self.directed_exchange_once(strip, frozen, sep, shape, until)?.is_some()))
    }

'''
assert text.count(needle)==1;text=text.replace(needle,wrappers+needle)
start=text.index(needle);end=text.index('\n}\n\n#[cfg(test)]',start)
body=text[start:end]
assert body.count('return Ok(0);')==2 and body.count('return Ok(1);')==1 and body.count('        Ok(0)')==1
body=body.replace('pub(super) fn directed_exchange(', 'fn directed_exchange_once(').replace('Result<usize>','Result<Option<bool>>').replace('return Ok(0);','return Ok(None);').replace('return Ok(1);','return Ok(Some(after.material_area < before.material_area));').replace('        Ok(0)','        Ok(None)')
text=text[:start]+body+text[end:]
caller=out/'candidate/crates/core/src/sheets/vstrip.rs';c=caller.read_text(encoding='utf-8');assert c.count('self.directed_exchange(')==1
caller.write_text(c.replace('self.directed_exchange(','self.directed_exchange_chain('),encoding='utf-8',newline='\n')
begin=original.index('    fn exercise(');end=original.index('\n    #[test]',begin)
helper=original[begin:end].replace('fn exercise(','fn chain_exercise(').replace('        expired: bool,','        budget: f64,').replace('''        let until = if expired {
            0.0
        } else {
            search.clock.now() + 3.0
        };''','''        let until = if budget <= 0.0 { 0.0 } else { search.clock.now() + budget };''').replace('.directed_exchange(','.directed_exchange_chain(')
a=helper.index('        eprintln!(');b=helper.index('        (moved, after, search.stats)',a)
helper=helper[:a]+'''        eprintln!("CHAIN_WITNESS {}",serde_json::json!({"job":job,"before":before_layout,"after":after,"seed":seed,"enabled":enabled,"budget":budget,"moved":moved,"work":search.clock.counts(),"until":until,"finished":search.clock.now()}));
'''+helper[b:]
tests='''
    // BEGIN exchange-chain tests
    fn chain_fixture() -> (Job, Layout) {
        let (mut job,mut layout)=fixture();
        job.name="Two successive source-height reductions".into();
        job.parts[0].quantity=2;job.parts[1].quantity=2;
        job.parts.push(rectangle("incoming-short",30.0,65.0));
        layout.sheets.push(Sheet{id:"sheet-2".into(),stock_id:"stock".into()});
        layout.placements[2].sheet_id="sheet-2".into();
        for index in 0..2 {let mut p=layout.placements[index].clone();p.copy_index=1;p.sheet_id="sheet-1".into();layout.placements.push(p);}
        layout.placements.push(Placement{part_id:"incoming-short".into(),copy_index:0,sheet_id:"sheet-2".into(),transform:RigidTransform{translation:[36.0,2.0],..Default::default()}});
        assert!(validate(&job,&layout).unwrap().valid);(job,layout)
    }

    #[test]
    fn exchange_chain_policy_stops_on_flat_failure_and_four_successes() {
        let mut calls=0;
        assert_eq!(continue_exchanges(||{calls+=1;Ok(Some(true))}).unwrap(),4);
        assert_eq!(calls,4);
        for (sequence,expected,counter) in [
            (vec![Some(false),Some(true)],1,1),
            (vec![Some(true),None,Some(true)],1,2),
            (vec![Some(true),Some(false),Some(true)],2,2),
            (vec![None,Some(true)],0,1),
        ] {
            let mut calls=0;
            let moved=continue_exchanges(||{let result=sequence[calls];calls+=1;Ok(result)}).unwrap();
            assert_eq!(moved,expected);assert_eq!(calls,counter);
        }
    }

    #[test]
    fn exchange_chain_accepts_successive_valid_gains_and_replays() {
        let (job,layout)=chain_fixture();
        let (once,one,_)=exercise(&job,&layout,0,true,false,0);assert_eq!(once,1);
        let (moved,after,stats)=chain_exercise(&job,&layout,0,true,3.0,0);
        assert!((2..=4).contains(&moved),"successive exchanges: {stats:?}");
        assert_eq!(stats.directed_exchanges,moved as u64);
        assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area < validate(&job,&one).unwrap().metrics.unwrap().material_area);
        let (again,replay,_)=chain_exercise(&job,&layout,0,true,3.0,0);
        assert_eq!(again,moved);assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(replay).unwrap());
    }

    #[test]
    fn exchange_chain_disabled_expired_and_validation_deadline_preserve_incumbent() {
        let (job,layout)=chain_fixture();
        let (_,baseline,_)=chain_exercise(&job,&layout,0,false,3.0,0);
        for (enabled,budget) in [(false,3.0),(true,0.0),(true,1e-12)] {
            let (moved,after,stats)=chain_exercise(&job,&layout,0,enabled,budget,0);
            assert_eq!(moved,0);assert_eq!(stats.directed_exchanges,0);
            assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(&baseline).unwrap());
        }
    }

    #[test]
    fn exchange_chain_failed_repair_preserves_frozen_and_active_sheets() {
        let (mut job,layout)=chain_fixture();
        job.parts[2]=rectangle("incoming",20.0,10.0);
        job.parts[3]=rectangle("incoming-short",20.0,10.0);
        let (moved,_,stats)=chain_exercise(&job,&layout,0,true,3.0,1);
        assert_eq!(moved,0);assert_eq!(stats.directed_exchanges,0);
    }
    // END exchange-chain tests
'''
pos=text.rindex('\n}');text=text[:pos]+'\n\n'+helper+tests+text[pos:];path.write_text(text,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),
 'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
 'changed_files':[rel,'crates/core/src/sheets/vstrip.rs'],'added_files':{},'production_digest':source_digest(),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),
 'target':str(root/'output/h5-exchange-chain-target-20261018'),'unchanged_prior_tests':137,'new_tests':4,'normal_mode_unchanged':True,'measured_search_started':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py');(out/'stub.txt').write_text(stub,encoding='utf-8',newline='\n')
print(json.dumps({'prepared':True,'prior_tests':137,'new_tests':4,'new_searches':0}))
