from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import ast,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];old=root/'output/h5-free-return-probe-20261018';out=root/'output/h5-exchange-chain-probe-20261018'
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
digest=lambda p:sha256(p.read_bytes()).hexdigest()
failed=out/'preparation-syntax-failure';failed.mkdir()
shutil.copyfile(root/'output/prepare_h5_exchange_chain.py',failed/'prepare.py');shutil.copyfile(path,failed/'exchange.rs')
s=path.read_text(encoding='utf-8');needle='// END free-return tests    fn chain_exercise('
assert s.count(needle)==1;s=s.replace(needle,'// END free-return tests\n\n    fn chain_exercise(')
path.write_text(s,encoding='utf-8',newline='\n')
p=root/'output/prepare_h5_exchange_chain.py';script=p.read_text(encoding='utf-8');needle='text[:pos]+helper+tests+text[pos:]';assert script.count(needle)==1
script=script.replace(needle,"text[:pos]+'\\n\\n'+helper+tests+text[pos:]");p.write_text(script,encoding='utf-8',newline='\n')
stub=next(ast.literal_eval(n.value) for n in ast.parse(script).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='stub' for t in n.targets))
(failed/'repair.json').write_text(json.dumps({'cause':'Missing newline joined new helper declaration to previous closing comment. cargo fmt rejected uncompiled source.','failed_source_sha256':digest(failed/'exchange.rs'),'failed_script_sha256':digest(failed/'prepare.py'),'repair':'Insert two newlines; no behavioral/test assertion changes.','compiled':False,'measured_searches':0},indent=2)+'\n',encoding='utf-8',newline='\n')
exec(compile(script[script.index("subprocess.run(['cargo','fmt'"):],str(p),'exec'))
shutil.copyfile(p,out/'prepare.py');shutil.copyfile(__file__,failed/'repair.py')
