from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parents[1];out=root/'benchmarks/results/h5-exchange-chain-preparation-20261018'
assert json.loads((out/'checks.json').read_bytes())['all_functional_checks_pass']
prior=(root/'BENCHMARKS.md').read_bytes();assert prior==subprocess.check_output(['git','show','HEAD:BENCHMARKS.md'],cwd=root)
note='''**N4 exchange-continuation preparation, 2026-10-18:** the [qualified isolated candidate](../benchmarks/results/h5-exchange-chain-preparation-20261018.md)
allows up to four exchanges under the original absolute deadline, continuing only
after a strict material gain. Rejection or an accepted flat result stops it. All
single-step guards and the preceding return initializer remain. All 141 optimized
tests pass, with 137 unchanged prior tests and four new regressions. The expected
two old-behavior failures and an earlier source assembly syntax failure remain.
Seven saved chain outputs pass fourteen frozen-CLI checks and independent geometry;
twelve original branch outcomes, 24 branch checks, ten public outcomes, four public
comparisons and five harness tests pass. Source reconstruction, lint and build pass.
The four-job matched pilot is ready to be planned; no new quality run has begun.
This does not resolve panel repair failures or earn H5 credit. H2/H5 remain open
at 60%; production and release claims are unchanged.
'''
def append(p,s):
 with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
append(root/'BENCHMARKS.md','\n\n## 2026-10-18 — Bounded exchange continuation qualification\n\n'+note.replace('../benchmarks/','benchmarks/'))
for name in ['docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']:append(root/name,'\n\n'+note)
p=root/'docs/STATUS.md';s=p.read_text(encoding='utf-8');at=s.index('**N4 free-space');s=s[:at]+note+'\n'+s[at:];p.write_text(s,encoding='utf-8',newline='\n')
append(root/'.gitattributes','\nbenchmarks/results/h5-exchange-chain-preparation-20261018/** -text -whitespace\nbenchmarks/results/h5-exchange-chain-pilot-20261018/** -text -whitespace\n')
assert (root/'BENCHMARKS.md').read_bytes().startswith(prior)
print('Recorded continuation qualification; no new quality claims.')
