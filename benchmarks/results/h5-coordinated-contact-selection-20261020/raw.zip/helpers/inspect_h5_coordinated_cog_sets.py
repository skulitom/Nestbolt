from pathlib import Path
from collections import Counter
import json,copy
import audit_h5_cog_lattices as audit
ROOT=audit.ROOT;RUN=ROOT/'output/h5-coordinated-placement-selection-20261018';load=audit.load;write=audit.write
def key(p):
    t=p['transform'];return (p['part_id'],p['sheet_id'],t['mirrored'],float(t['rotation_radians']).hex(),*(float(v).hex() for v in t['translation']))
def main():
    pool=load(RUN/'candidates.json');lookup={key(p['placement']):i for i,p in enumerate(pool)};sets={}
    for path in load(RUN/'plan.json')['layout_sources']:
        layout=load(ROOT/path);cogs=sorted(lookup[key(p)] for p in layout['placements'] if p['part_id']=='cog');assert len(cogs)==15 and len(set(cogs))==15
        sets.setdefault(tuple(cogs),[]).append(path)
    result={'distinct_full_cog_skeletons':len(sets),'union_cog_positions':len(set(i for ids in sets for i in ids)),'sets':[{'index':i,'candidates':list(ids),'sources':paths} for i,(ids,paths) in enumerate(sets.items())],'all_skeletons_have_all_fifteen_original_cogs':True,'scope':'Catalogue observation only. Other families are not fixed. No conditional solve or new feasibility claim.'};write(RUN/'cog-skeletons.json',result);print(json.dumps({k:v for k,v in result.items() if k!='sets'}))
if __name__=='__main__':main()
