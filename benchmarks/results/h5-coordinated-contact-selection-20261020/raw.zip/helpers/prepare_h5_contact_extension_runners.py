from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [
    ('solve_h5_insert_completion.py','solve_h5_contact_extension.py'),
    ('audit_h5_insert_completion_result.py','audit_h5_contact_extension_result.py')]:
    src=ROOT/'output'/source; dst=ROOT/'output'/target
    text=src.read_text(encoding='utf-8')
    assert text.count('h5-insert-completion-selection-20261018')==1
    text=text.replace('h5-insert-completion-selection-20261018','h5-skeleton-contact-selection-20261020')
    with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print('Prepared new-run wrappers; original runners and attempts preserved.')
