from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_coordinated_selection_result.py').read_text(encoding='utf-8').replace("RUN=ROOT/'output/h5-coordinated-placement-selection-20261018';OUT=RUN/'solve'","RUN=ROOT/'output/h5-cog-skeleton-selection-20261018';OUT=RUN")
s=s.replace("ids=load(OUT/'selected-indices.json');layout=", "ids=load(OUT/'selected-indices.json');mapping=load(OUT/'mapping.json');skeletons=load(OUT/'cog-skeletons.json')['sets'];si=result['selected_skeleton'];assert set(i for i in ids if pool[i]['placement']['part_id']=='cog')==set(skeletons[si]['candidates']);allowed={r['candidate']:r['compatible_skeletons'] for r in mapping['candidates']};assert all(i in skeletons[si]['candidates'] or si in allowed[i] for i in ids);layout=")
s=s.replace('Finite-pool infeasibility, if reported, does not prove unrestricted original geometry impossible.','Any infeasibility concerns only these four cog arrangements and the retained candidate pool, not the unrestricted original geometry.')
with (ROOT/'output/audit_h5_skeleton_selection_result.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared independent result audit for the four original cog arrangements.')
