from pathlib import Path
from hashlib import sha256
import json
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-cog-skeleton-selection-20261018';OUT=ROOT/'output/h5-insert-completion-selection-20261018';load=lambda p:json.loads(p.read_bytes())
def main():
    plan=load(OUT/'plan.json');old=text_format.Parse((SRC/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto());new=text_format.Parse((OUT/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto());pool=load(OUT/'candidates.json');mp=load(OUT/'mapping.json');ids=[r['var'] for r in mp['candidates'] if pool[r['candidate']]['placement']['part_id']=='insert'];ci=plan['changed_constraint_index'];assert list(new.constraints[ci].linear.vars)==ids and list(new.constraints[ci].linear.coeffs)==[1]*len(ids) and list(new.constraints[ci].linear.domain)==[13,21]
    for name,h in plan['input_hashes'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h
    assert list(new.objective.vars)==ids and list(new.objective.coeffs)==[-1]*len(ids) and new.objective.scaling_factor==-1. and new.objective.offset==0;values=load(OUT/'complete-hint.json');assert list(new.solution_hint.vars)==list(range(len(new.variables))) and list(new.solution_hint.values)==values
    for i,v in enumerate(values):assert any(a<=v<=b for a,b in zip(new.variables[i].domain[::2],new.variables[i].domain[1::2]))
    for c in new.constraints:
        assert not c.enforcement_literal;k=c.WhichOneof('constraint')
        if k=='at_most_one':assert sum(values[i] for i in c.at_most_one.literals)<=1
        elif k=='exactly_one':assert sum(values[i] for i in c.exactly_one.literals)==1
        elif k=='linear':
            v=sum(values[i]*a for i,a in zip(c.linear.vars,c.linear.coeffs));assert any(a<=v<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        else:raise AssertionError(k)
    assert sum(values[i] for i in ids)==13;changed=cp_model_pb2.CpModelProto();changed.CopyFrom(new);changed.ClearField('objective');changed.solution_hint.CopyFrom(old.solution_hint);changed.constraints[ci].linear.domain[:]=[21,21];assert changed.SerializeToString(deterministic=True)==old.SerializeToString(deterministic=True)
    params=text_format.Parse((OUT/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params.max_time_in_seconds==120 and params.num_search_workers==8 and params.random_seed==0
    result={'all_other_model_bytes_equivalent':True,'only_changes':['temporary insert construction domain 13..21','maximize original insert count','complete feasible original partial hint'],'all_hard_constraints_and_domains_satisfied_by_hint':True,'hint_inserts':13,'accepted_witness_requires_inserts':21,'original_stock_clearance_and_other_quantities_unchanged':True,'variables':len(new.variables),'constraints':len(new.constraints),'model_sha256':sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()}
    with (OUT/'model-audit.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result),flush=True)
if __name__=='__main__':main()
