from pathlib import Path
from collections import Counter,defaultdict
import json,math,itertools,subprocess,copy
import audit_h5_cog_lattices as audit
ROOT=audit.ROOT;RUN=ROOT/'output/h5-cog-skeleton-selection-20261018';OUT=RUN;load=audit.load;write=audit.write;digest=audit.digest
def main():
    result=load(OUT/'result.json');pool=load(RUN/'candidates.json');job=load(RUN/'job.json');parts={p['id']:p for p in job['parts']};modelaudit=load(OUT/'model-audit.json');assert result['model_sha256']==modelaudit['model_sha256']==digest(OUT/'model.pbtxt');check={'solver_status':result['status'],'solver_seconds':result['seconds'],'model_sha256':result['model_sha256'],'full_target_witness':False,'native_margin_qualified':False}
    if result['feasible']:
        ids=load(OUT/'selected-indices.json');mapping=load(OUT/'mapping.json');skeletons=load(OUT/'cog-skeletons.json')['sets'];si=result['selected_skeleton'];assert set(i for i in ids if pool[i]['placement']['part_id']=='cog')==set(skeletons[si]['candidates']);allowed={r['candidate']:r['compatible_skeletons'] for r in mapping['candidates']};assert all(i in skeletons[si]['candidates'] or si in allowed[i] for i in ids);layout=load(OUT/'selected-layout.json');assert len(ids)==len(set(ids))==len(layout['placements'])==66;counts=Counter();gs=defaultdict(list);tops=Counter();st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance'];target=load(RUN/'conditional-target.json')
        for i,p in zip(ids,layout['placements']):
            expected=copy.deepcopy(pool[i]['placement']);expected['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;assert p==expected;t=p['transform'];part=parts[p['part_id']];assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            g=audit.shape(part,t);assert g.is_valid;x0,y0,x1,y1=g.bounds;h=st['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7 and x1<=st['width']-m['right']-edge+1e-7 and y1<=h-m['top']-edge+1e-7;gs[p['sheet_id']].append(g);tops[p['sheet_id']]=max(tops[p['sheet_id']],y1+m['top']+edge)
        assert counts==Counter({p['id']:p['quantity'] for p in job['parts']});pairs=0;minimum=math.inf
        for group in gs.values():
            for a,b in itertools.combinations(group,2):pairs+=1;d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=job['clearance']-1e-7
        charged=st['width']*(st['height']+tops['sheet-1']);assert charged<=target['target_material_mm2']+1e-6;cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';cmd=[str(cli),'validate','--library',str(RUN/'library.json'),'--request',str(RUN/'request.json'),'--layout',str(OUT/'selected-layout.json')];r=subprocess.run(cmd,capture_output=True,timeout=60);(OUT/'public.json').write_bytes(r.stdout);(OUT/'public.stderr').write_bytes(r.stderr);write(OUT/'public-command.json',{'command':cmd,'exit_code':r.returncode});public=json.loads(r.stdout);assert r.returncode==0 and public['valid'];check.update(full_target_witness=True,original_parts=66,filled_outer_pairs=pairs,minimum_distance_mm=minimum,charged_material_mm2=charged,original_frozen_CLI_valid=True)
    else:assert result['status'] in ['UNKNOWN','INFEASIBLE'] and not (OUT/'selected-layout.json').exists();check['interpretation']='No complete selection returned. Any infeasibility concerns only these four cog arrangements and the retained candidate pool, not the unrestricted original geometry.'
    write(OUT/'result-audit.json',check);print(json.dumps(check),flush=True)
if __name__=='__main__':main()
