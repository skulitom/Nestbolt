"""Offline whole-job feasibility construction from repeated-part patterns.

This is an unbounded post-hoc diagnosis, not a solver, quality, or speed comparison.
It uses only four previously saved development jobs and original cutting requests.
"""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from datetime import datetime,timezone
import copy,gzip,importlib.util,itertools,json,math,shutil,subprocess,sys,traceback,zipfile
import shapely
from shapely.geometry import Polygon,LineString,box
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1]
PRIOR=ROOT/'benchmarks/results/h5-source-frontier-pilot-20261018'
OUT=ROOT/'output/h5-pattern-construction-20261018'
spec=importlib.util.spec_from_file_location('gap',ROOT/'output/diagnose_h5_concave_gaps.py')
gap=importlib.util.module_from_spec(spec);spec.loader.exec_module(gap)
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=gap.write


def transform(angle=0,x=0,y=0,mirrored=False):
    return {'rotation_radians':angle,'translation':[x,y],'mirrored':mirrored}


def pattern(name,members,shapes):
    geoms=[gap.pose(shapes[p['part_id']],p['transform']) for p in members]
    x0=min(p.bounds[0] for p in geoms);y0=min(p.bounds[1] for p in geoms)
    x1=max(p.bounds[2] for p in geoms);y1=max(p.bounds[3] for p in geoms)
    members=copy.deepcopy(members)
    for p in members:p['transform']['translation'][0]-=x0;p['transform']['translation'][1]-=y0
    return {'id':name,'members':members,'width':x1-x0,'height':y1-y0,'area':sum(p.area for p in geoms)}


def member(family,t=None):return {'part_id':family,'transform':t or transform()}


def pair_pattern(a,b,parts,shapes,clearance):
    fixed=shapes[a];best=None
    for t in gap.orientations(parts[b],transform()):
        moving=gap.pose(shapes[b],t)
        forbidden=gap.obstacle(fixed,moving,clearance)
        for poly in gap.polygons(forbidden):
            for x,y in list(poly.exterior.coords)[:-1]:
                placed=affine_transform(moving,[1,0,0,1,x,y])
                if not placed.disjoint(fixed) or placed.distance(fixed)<clearance:continue
                p=pattern(a+'+'+b,[member(a),member(b,{**t,'translation':[x,y]})],shapes)
                score=(p['width']*p['height'],max(p['width'],p['height']),p['height'],x,y,t['rotation_radians'],t['mirrored'])
                if best is None or score<best[0]:best=(score,p)
    assert best
    return best[1]


def catalog(job):
    parts={p['id']:p for p in job['parts']};shapes={p['id']:Polygon(p['geometry'][0]['outer']) for p in job['parts']}
    assert all(len(p['geometry'])==1 for p in job['parts'])
    rectangles=[k for k,p in shapes.items() if p.equals(box(*p.bounds))]
    assert len(rectangles)==2
    small,large=sorted(rectangles,key=lambda k:shapes[k].area)
    other=[k for k in shapes if k not in rectangles];assert len(other)==2
    corner,radial=sorted(other,key=lambda k:len(shapes[k].exterior.coords))
    assert len(shapes[corner].exterior.coords)==7
    g=job['clearance']+.001
    patterns={k:pattern(k,[member(k)],shapes) for k in parts}
    for a,b in [(corner,small),(corner,corner)]:
        p=pair_pattern(a,b,parts,shapes,g);patterns[p['id']]=p
    forbidden=gap.obstacle(shapes[radial],shapes[radial],g)
    reach=10*max(patterns[radial]['width'],patterns[radial]['height'])
    horizontal=forbidden.intersection(LineString([(-reach,0),(reach,0)]))
    dx=horizontal.bounds[2]+1e-5
    dy=max(forbidden.intersection(LineString([(v,-reach),(v,reach)])).bounds[3] for v in [dx/2,-dx/2])+1e-5
    assert dx>0 and dy>0
    group_specs=[]
    for n in [1,2,4,6,8,10,12,15]:
        for cols in range(1,min(5,n)+1):
            if math.ceil(n/cols)>3:continue
            group_specs.append((n,cols))
            for count in {n,parts[radial]['quantity']%n}:
                if not count:continue
                c=min(cols,count);name=f'{radial}-{count}x{c}'
                p=pattern(name,[member(radial,transform(x=(i%c+(i//c%2)/2)*dx,y=(i//c)*dy)) for i in range(count)],shapes)
                patterns[name]=p
    # Every compound and lattice patch is independently checked on filled outers.
    pairs=0
    for p in patterns.values():
        geoms=[gap.pose(shapes[m['part_id']],m['transform']) for m in p['members']]
        for a,b in itertools.combinations(geoms,2):
            pairs+=1;assert a.disjoint(b) and a.distance(b)>=job['clearance']
    return parts,shapes,patterns,{'large':large,'small':small,'corner':corner,'radial':radial,'group_specs':group_specs,
        'pitch_x':dx,'pitch_y':dy,'compound_pair_checks':pairs,'block_spacing':g}


def contains(a,b):return a[0]<=b[0]+1e-9 and a[1]<=b[1]+1e-9 and a[0]+a[2]>=b[0]+b[2]-1e-9 and a[1]+a[3]>=b[1]+b[3]-1e-9


def subtract(free,used):
    ux,uy,uw,uh=used;result=[]
    for x,y,w,h in free:
        if ux>=x+w-1e-9 or ux+uw<=x+1e-9 or uy>=y+h-1e-9 or uy+uh<=y+1e-9:
            result.append((x,y,w,h));continue
        if ux>x:result.append((x,y,ux-x,h))
        if ux+uw<x+w:result.append((ux+uw,y,x+w-ux-uw,h))
        if uy>y:result.append((x,y,w,uy-y))
        if uy+uh<y+h:result.append((x,uy+uh,w,y+h-uy-uh))
    result=list(dict.fromkeys(r for r in result if r[2]>1e-8 and r[3]>1e-8))
    return [r for i,r in enumerate(result) if not any(i!=j and contains(q,r) for j,q in enumerate(result))]


def frame_configs(unit,quantity,width,height,g):
    seen=set();configs=[]
    for ncols in range(1,8):
        for rotations in itertools.product([False,True],repeat=ncols):
            dims=[(unit['height'],unit['width']) if r else (unit['width'],unit['height']) for r in rotations]
            if sum(d[0]+g for d in dims)-g>width:continue
            capacities=[int((height+g)//(h+g)) for w,h in dims]
            if any(c==0 for c in capacities) or sum(capacities)<quantity or quantity<ncols:continue
            for method in ['left','right','balanced']:
                counts=[1]*ncols
                for _ in range(quantity-ncols):
                    available=[i for i in range(ncols) if counts[i]<capacities[i]]
                    if method=='left':i=available[0]
                    elif method=='right':i=available[-1]
                    else:i=min(available,key=lambda j:((counts[j]+1)*(dims[j][1]+g),j))
                    counts[i]+=1
                key=(rotations,tuple(counts))
                if key in seen:continue
                seen.add(key);placed=[];x=0
                for i,((w,h),count,rot) in enumerate(zip(dims,counts,rotations)):
                    for row in range(count):placed.append({'pattern':unit['id'],'bin':0,'x':x,'y':row*(h+g),'rotated':rot,'rect':[x,row*(h+g),w+g,h+g]})
                    x+=w+g
                free=[(0,0,width+g,height+g)]
                for p in placed:free=subtract(free,p['rect'])
                configs.append({'rotations':rotations,'counts':counts,'method':method,'placed':placed,'free':free})
    return configs


def inventory(parts,patterns,meta,corner_mode,group):
    remaining={k:v['quantity'] for k,v in parts.items()};remaining[meta['large']]=0;items=[]
    def add(name,count):
        for _ in range(count):items.append(name)
        for p in patterns[name]['members']:remaining[p['part_id']]-=count
    a,b=meta['corner'],meta['small']
    if corner_mode=='insert':add(a+'+'+b,min(remaining[a],remaining[b]))
    if corner_mode=='pair':add(a+'+'+a,remaining[a]//2)
    n,cols=group;family=meta['radial'];count=remaining[family]
    add(f'{family}-{n}x{min(cols,n)}',count//n)
    if count%n:add(f'{family}-{count%n}x{min(cols,count%n)}',1)
    for k,count in list(remaining.items()):
        if count:add(k,count)
    assert all(v==0 for v in remaining.values())
    return items


def pack(items,patterns,free,sort,fit,g):
    score=lambda p:({'area':p['width']*p['height'],'long':max(p['width'],p['height']),
                     'short':min(p['width'],p['height']),'filled':p['area']}[sort],p['width']*p['height'],p['id'])
    ordered=sorted(items,key=lambda n:score(patterns[n]),reverse=True)
    free=[list(f) for f in free];placed=[]
    for index,name in enumerate(ordered):
        p=patterns[name];best=None
        for b,rects in enumerate(free):
            for x,y,w,h in rects:
                for rot in [False,True]:
                    pw,ph=(p['height']+g,p['width']+g) if rot else (p['width']+g,p['height']+g)
                    if pw>w+1e-8 or ph>h+1e-8:continue
                    dw,dh=w-pw,h-ph
                    criterion={'short':(min(dw,dh),max(dw,dh)), 'area':(w*h-pw*ph,min(dw,dh)), 'bottom':(y+ph,x)}[fit]
                    rank=(b,*criterion,y,x,rot)
                    if best is None or rank<best[0]:best=(rank,{'pattern':name,'bin':b,'x':x,'y':y,'rotated':rot,'rect':[x,y,pw,ph]})
        if best is None:return placed,ordered[index:]
        q=best[1];placed.append(q);free[q['bin']]=subtract(free[q['bin']],q['rect'])
    return placed,[]


def layout_of(job,patterns,blocks):
    stock=job['stocks'][0];base=[stock['margins']['left']+job['edge_clearance']+1e-4,
        stock['margins']['bottom']+job['edge_clearance']+1e-4]
    counts=Counter();placements=[]
    for block in blocks:
        p=patterns[block['pattern']]
        for m in p['members']:
            t=copy.deepcopy(m['transform']);x,y=t['translation']
            if block['rotated']:
                t['rotation_radians']+=math.pi/2;x,y=p['height']-y,x
            t['translation']=[base[0]+block['x']+x,base[1]+block['y']+y]
            family=m['part_id'];placements.append({'part_id':family,'copy_index':counts[family],
                'sheet_id':f"sheet-{block['bin']}",'transform':t});counts[family]+=1
    return {'version':1,'units':'mm','sheets':[{'id':f'sheet-{i}','stock_id':stock['id']} for i in range(2)],'placements':placements}


def sanity():
    free=subtract([(0,0,10,10)],(0,0,5,5))
    assert all(not box(x,y,x+w,y+h).intersection(box(0,0,5,5)).area for x,y,w,h in free)
    p={'a':{'id':'a','width':5.,'height':5.,'area':25}}
    out,left=pack(['a']*4,p,[[(0,0,10,10)]],'area','short',0)
    assert len(out)==4 and not left
    assert all(not box(*[a['x'],a['y'],a['x']+5,a['y']+5]).intersection(box(b['x'],b['y'],b['x']+5,b['y']+5)).area for a,b in itertools.combinations(out,2))
    assert len(pack(['a']*5,p,[[(0,0,10,10)]],'area','short',0)[1])==1


def main():
    OUT.mkdir();sanity();production=gap.source_digest()
    assert production=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
    assert digest(gap.CLI)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    data=load(PRIOR/'results.json');rows=[r for r in data['records'] if r['arm']=='candidate' and r['seed']==0 and r['job'].startswith('m-mechanical')]
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'source_digest':production,'results_sha256':digest(PRIOR/'results.json'),
        'script_sha256':digest(Path(__file__)),'geometry_helper_sha256':digest(Path(gap.__file__)),
        'cases':[r['archive'] for r in rows],
        'method':'Four saved development jobs, no solver reruns. Detect largest and smaller rectangular part families and a six-vertex corner family from filled outer geometry. Enumerate mixed-quarter-turn columns placing all largest rectangles on sheet 0. Build single, corner+rectangle and corner+corner patterns from exact filled-outer Minkowski boundaries; also uniform staggered radial-part grids with groups 1,2,4,6,8,10,12,15, at most five columns and three rows. All pattern pairs must pass original clearance. Pack padded pattern rectangles into original first-sheet and saved conditional +1% last-sheet height using a deterministic free-rectangle heuristic, four sort orders and three placement scores. Try every enumerated combination until first complete layout for each job. Preserve every attempted block layout and all failures. Validate the first complete result through original public library/request and independent filled-outer, inventory, orientation and margin checks.',
        'limit_note':'Unbounded offline feasibility diagnosis on CCD1; no runtime budget, quality, speed or H5 claim. No rotation/kerf/hole/stock rule changes. Original normal medians are references from a retained rejected pilot, not a new matched evaluation.'}
    write(OUT/'plan.json',plan);shutil.copyfile(__file__,OUT/'construct.py');shutil.copyfile(gap.__file__,OUT/'geometry-helper.py')
    results=[]
    try:
        for row in rows:
            folder=OUT/Path(row['archive']).stem;folder.mkdir();archive=PRIOR/row['archive']
            assert digest(archive)==row['archive_sha256']
            with zipfile.ZipFile(archive) as z:
                for src,dest in [('library.json','library.json'),('request.json','request.json'),('nested/job.json','job.json'),('nested/layout.json','original.json')]:
                    (folder/dest).write_bytes(z.read(src))
            job=load(folder/'job.json');original=load(folder/'original.json');st=job['stocks'][0]
            assert len(job['stocks'])==1 and not st['outline'] and not st['defects']
            b=next(b for b in load(PRIOR/'final-boundaries.json')['records'] if b['archive']==row['archive'])
            write(folder/'conditional-target.json',b)
            parts,shapes,patterns,meta=catalog(job)
            write(folder/'patterns.json',patterns);write(folder/'pattern-metadata.json',meta)
            g=meta['block_spacing'];m=st['margins'];e=job['edge_clearance']
            width=st['width']-m['left']-m['right']-2*e-2e-4
            heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,b['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
            frames=frame_configs(patterns[meta['large']],parts[meta['large']]['quantity'],width,heights[0],g)
            assert frames;write(folder/'frame-configurations.json',frames)
            variants=[]
            for corner_mode in ['insert','pair','single']:
                for group in meta['group_specs']:
                    items=inventory(parts,patterns,meta,corner_mode,group)
                    area=sum((patterns[n]['width']+g)*(patterns[n]['height']+g) for n in items)+parts[meta['large']]['quantity']*(patterns[meta['large']]['width']+g)*(patterns[meta['large']]['height']+g)
                    variants.append({'corner_mode':corner_mode,'group':group,'items':items,'padded_area':area,
                        'area_possible':area<=(width+g)*sum(h+g for h in heights)})
            # Try densest macro inventories first. This is deterministic feasibility search.
            variants.sort(key=lambda v:(v['padded_area'],v['corner_mode'],v['group']))
            write(folder/'variants.json',variants)
            attempts=0;success=None;best_left=None;best=None
            print(json.dumps({'case':folder.name,'frame_configs':len(frames),'variants':len(variants),'area_possible':sum(v['area_possible'] for v in variants)}),flush=True)
            with gzip.open(folder/'attempts.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
                for vi,v in enumerate(variants):
                    if not v['area_possible']:continue
                    for fi,frame in enumerate(frames):
                        for sort,fit in itertools.product(['area','long','short','filled'],['short','area','bottom']):
                            placed,left=pack(v['items'],patterns,[frame['free'],[(0,0,width+g,heights[1]+g)]],sort,fit,g)
                            attempts+=1
                            rec={'attempt':attempts,'variant':vi,'frame_config':fi,'sort':sort,'fit':fit,'placed':placed,'left':left}
                            log.write(json.dumps(rec,separators=(',',':'))+'\n')
                            left_area=sum(patterns[n]['area'] for n in left)
                            if best_left is None or left_area<best_left:best_left=left_area;best=rec
                            if not left:
                                layout=layout_of(job,patterns,frame['placed']+placed)
                                moved={(p['part_id'],p['copy_index']) for p in original['placements']}
                                checked=gap.validate(folder,'constructed',layout,job,original,moved)
                                assert checked['metrics']['material_area']<=b['target_material_mm2']+1e-6
                                success={**rec,'checked':checked};write(folder/'success.json',success);break
                        if success:break
                    if success:break
            write(folder/'best-attempt.json',best)
            result={'case':folder.name,'attempts':attempts,'constructed_complete':success is not None,'best_unplaced_filled_area_mm2':best_left,
                'target_material_mm2':b['target_material_mm2'],'material_mm2':success['checked']['metrics']['material_area'] if success else None,
                'archive_sha256':row['archive_sha256'],'pattern_checks':meta['compound_pair_checks']}
            write(folder/'result.json',result);results.append(result);print(json.dumps(result),flush=True)
        assert gap.source_digest()==production and digest(PRIOR/'results.json')==plan['results_sha256']
        write(OUT/'results.json',{'complete':True,'cases':results,'original_results_and_production_unchanged':True,
            'new_solver_searches':0,'offline_geometric_search':True,'quality_claim':False,'H5_complete':False})
    except BaseException:
        write(OUT/'failure.json',{'error':traceback.format_exc(),'completed':results});raise


if __name__=='__main__':main()
