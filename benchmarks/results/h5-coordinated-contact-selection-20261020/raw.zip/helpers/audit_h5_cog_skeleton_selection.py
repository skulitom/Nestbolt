"""Direct-geometry conditional reduction and independent complete text-proto audit."""
from pathlib import Path
from collections import Counter
import json,gzip,re,math,itertools,copy,shutil
import numpy as np
import shapely
import audit_h5_cog_lattices as geometry
ROOT=geometry.ROOT;OUT=ROOT/'output/h5-cog-skeleton-selection-20261018';SRC=ROOT/'output/h5-coordinated-placement-selection-20261018';OLD=ROOT/'output/h5-contact-placement-selection-20261018';load=geometry.load;write=geometry.write;digest=geometry.digest
def main():
    plan=load(OUT/'plan.json');mp=load(OUT/'mapping.json');pool=load(OUT/'candidates.json');job=load(OUT/'job.json');sets=load(OUT/'cog-skeletons.json')['sets'];parts={p['id']:p for p in job['parts']};n=len(pool)
    for name,h in plan['input_hashes'].items():assert digest(ROOT/name)==h
    assert (OUT/'candidates.json').read_bytes()==(SRC/'candidates.json').read_bytes();geoms=np.asarray([geometry.shape(parts[p['placement']['part_id']],p['placement']['transform']) for p in pool],dtype=object);sheets=np.asarray([p['placement']['sheet_id'] for p in pool]);noncog=np.asarray([i for i,p in enumerate(pool) if p['placement']['part_id']!='cog']);allowed={int(i):[] for i in noncog};pairchecks=0
    for si,s in enumerate(sets):
        assert si==s['index'] and len(s['candidates'])==15 and all(pool[i]['placement']['part_id']=='cog' for i in s['candidates']);good=np.ones(len(noncog),dtype=bool)
        for i in s['candidates']:
            same=sheets[noncog]==sheets[i];ids=noncog[same];pairchecks+=len(ids);good[same]&=shapely.distance(geoms[i],geoms[ids])>=job['clearance']-1e-7
        for j in noncog[good]:allowed[int(j)].append(si)
        for i,j in itertools.combinations(s['candidates'],2):assert sheets[i]!=sheets[j] or (geoms[i].disjoint(geoms[j]) and geoms[i].distance(geoms[j])>=job['clearance']-1e-7)
    kept={i:ls for i,ls in allowed.items() if ls};assert [{'candidate':i,'var':vi+4,'compatible_skeletons':ls} for vi,(i,ls) in enumerate(kept.items())]==mp['candidates'];assert [i for i,ls in allowed.items() if not ls]==mp['excluded_non_cog_candidates'];assert mp['options']==[0,1,2,3]
    projected=set()
    for path in [OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']:
        with gzip.open(path,'rt',encoding='utf-8') as f:
            for line in f:
                ids=tuple(sorted(i for i in json.loads(line) if i in kept))
                if len(ids)>1:projected.add(ids)
    with gzip.open(OUT/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:assert [tuple(json.loads(line)) for line in f]==sorted(projected)
    text=(OUT/'model.pbtxt').read_text(encoding='utf-8');vp=r'variables\s*\{\s*name:\s*"(skeleton-\d+|p\d+)"\s*domain:\s*\[0, 1\]\s*\}';names=re.findall(vp,text);assert names==[f'skeleton-{i}' for i in range(4)]+[f'p{i}' for i in kept];vi={row['candidate']:row['var'] for row in mp['candidates']};parse=lambda s:json.loads('['+s+']')
    ep=r'constraints\s*\{\s*exactly_one\s*\{\s*literals:\s*\[([^\]]*)\]\s*\}\s*\}';assert [parse(s) for s in re.findall(ep,text,re.S)]==[[0,1,2,3]]
    ap=r'constraints\s*\{\s*at_most_one\s*\{\s*literals:\s*\[([^\]]*)\]\s*\}\s*\}';assert [parse(s) for s in re.findall(ap,text,re.S)]==[[vi[i] for i in ids] for ids in sorted(projected)]
    lp=r'constraints\s*\{\s*linear\s*\{\s*vars:\s*\[([^\]]*)\]\s*coeffs:\s*\[([^\]]*)\]\s*domain:\s*\[([^\]]*)\]\s*\}\s*\}';actual=Counter((tuple(zip(parse(a),parse(b))),tuple(parse(d))) for a,b,d in re.findall(lp,text,re.S));expected=Counter()
    for i,ls in kept.items():
        if len(ls)<4:expected[(tuple(sorted([(si,-1) for si in ls]+[(vi[i],1)])),(-9223372036854775808,0))]+=1
    for part in job['parts']:
        if part['id']=='cog':continue
        expected[(tuple((vi[i],1) for i in kept if pool[i]['placement']['part_id']==part['id']),(part['quantity'],part['quantity']))]+=1
    assert actual==expected;hp=r'solution_hint\s*\{\s*vars:\s*\[([^\]]*)\]\s*values:\s*\[([^\]]*)\]\s*\}';hints=re.findall(hp,text,re.S);want=[mp['warm_skeleton']]+[vi[i] for i in mp['warm_candidates'] if i in vi];assert len(hints)==1 and parse(hints[0][0])==want and parse(hints[0][1])==[1]*len(want)
    remainder=text
    for pattern in [vp,ep,ap,lp,hp]:remainder=re.sub(pattern,'',remainder,flags=re.S)
    assert not remainder.strip(),remainder[:200];warm=mp['warm_candidates'];assert set(i for i in warm if pool[i]['placement']['part_id']=='cog')==set(sets[mp['warm_skeleton']]['candidates'])
    for i,j in itertools.combinations(warm,2):assert sheets[i]!=sheets[j] or (geoms[i].disjoint(geoms[j]) and geoms[i].distance(geoms[j])>=job['clearance']-1e-7)
    counts=Counter(pool[i]['placement']['part_id'] for i in warm);assert counts==Counter(frame=18,bracket=12,cog=15,insert=13);result={'variables':len(names),'cliques':len(projected),'linear_constraints':sum(expected.values()),'direct_original_skeleton_compatibility_pairs':pairchecks,'retained_non_cog_positions':len(kept),'excluded_non_cog_positions':len(allowed)-len(kept),'all_conditional_compatibility_exact':True,'all_conflict_clique_projections_exact':True,'full_text_model_consumed_without_extra_constraints':True,'original_full_inventory_required_for_any_solution':True,'warm_hint_original_parts':len(warm),'warm_missing':{'insert':8},'model_sha256':digest(OUT/'model.pbtxt')};write(OUT/'model-audit.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':main()
