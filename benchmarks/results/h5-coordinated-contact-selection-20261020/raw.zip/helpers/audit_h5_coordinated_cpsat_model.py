from pathlib import Path
from hashlib import sha256
import json,gzip
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-coordinated-placement-selection-20261018';OLD=ROOT/'output/h5-contact-placement-selection-20261018';OUT=SRC/'solve';load=lambda p:json.loads(p.read_bytes())
def main():
    prepared=load(OUT/'prepared.json');pool=load(SRC/'candidates.json');job=load(SRC/'job.json');warm=load(SRC/'warm-indices.json');proto=text_format.Parse((OUT/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
    for name,h in prepared['input_hashes'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h
    assert len(proto.variables)==9059 and [(v.name,list(v.domain)) for v in proto.variables]==[(f'p{i}',[0,1]) for i in range(len(pool))];assert not proto.HasField('objective') and not proto.HasField('floating_point_objective')
    ci=0;counts=[]
    for path in [OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']:
        count=0
        with gzip.open(path,'rt',encoding='utf-8') as f:
            for line in f:
                c=proto.constraints[ci];ci+=1;count+=1;assert c.WhichOneof('constraint')=='at_most_one' and not c.enforcement_literal and list(c.at_most_one.literals)==json.loads(line)
        counts.append(count)
    for part in job['parts']:
        c=proto.constraints[ci];ci+=1;ids=[i for i,p in enumerate(pool) if p['placement']['part_id']==part['id']];assert c.WhichOneof('constraint')=='linear' and not c.enforcement_literal;assert list(c.linear.vars)==ids and list(c.linear.coeffs)==[1]*len(ids) and list(c.linear.domain)==[part['quantity']]*2
    assert ci==len(proto.constraints) and list(proto.solution_hint.vars)==warm and list(proto.solution_hint.values)==[1]*len(warm);assert not proto.assumptions and not proto.search_strategy
    params=text_format.Parse((OUT/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params.max_time_in_seconds==120 and params.num_search_workers==8 and params.random_seed==0
    result={'variables':len(proto.variables),'constraints':len(proto.constraints),'old_conflict_cliques':counts[0],'new_conflict_cliques':counts[1],'exact_original_family_counts_verified':True,'positive_hint_positions':len(warm),'no_objective_extra_constraints_or_assumptions':True,'seed':0,'workers':8,'seconds_limit':120,'model_sha256':sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()}
    with (OUT/'model-audit.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result),flush=True)
if __name__=='__main__':main()
