"""Optimize insert completion from a complete feasible partial assignment."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-cog-skeleton-selection-20261018';OUT=ROOT/'output/h5-insert-completion-selection-20261018';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(SRC/'result-audit.json')['solver_status']=='UNKNOWN';OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');pool=load(SRC/'candidates.json');mp=load(SRC/'mapping.json');proto=text_format.Parse((SRC/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto());insertvars=[r['var'] for r in mp['candidates'] if pool[r['candidate']]['placement']['part_id']=='insert'];matches=[i for i,c in enumerate(proto.constraints) if c.WhichOneof('constraint')=='linear' and list(c.linear.vars)==insertvars and list(c.linear.coeffs)==[1]*len(insertvars) and list(c.linear.domain)==[21,21]];assert len(matches)==1;ci=matches[0]
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':digest(Path(__file__)),'input_hashes':{str((SRC/n).relative_to(ROOT)):digest(SRC/n) for n in ['model.pbtxt','model-audit.json','result-audit.json','mapping.json','candidates.json','job.json']},'changed_constraint_index':ci,'method':'Preserve all original geometry, target, four cog arrangements, candidate positions, compatibility, frame/bracket requirements and clique constraints. For offline construction only, allow 13 through 21 original inserts and maximize their integer count. Supply the entire verified 58-part partial assignment, including all zero-valued candidates and the selected cog arrangement, as a complete feasible hint. This gives a valid incumbent and enables improvement search; earlier exact-66 feasibility runs had no complete feasible hint. All 15 cogs, 18 frames and 12 brackets remain mandatory. A result with fewer than 21 inserts remains an invalid original job and earns no gate credit; only 21 may become a full witness after original CLI and independent geometry validation. Record every incumbent, including the initial partial and all failures.','seconds_limit':120,'workers':8,'seed':0,'acceptance_required_inserts':21,'temporary_construction_minimum_inserts':13,'native_packing_calls':0,'quality_runs':0,'full_original_quantity_requirement_unchanged':True};write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','conditional-target.json','candidates.json','cog-skeletons.json','mapping.json','parameters.pbtxt']:shutil.copyfile(SRC/n,OUT/n)
    del proto.constraints[ci].linear.domain[:];proto.constraints[ci].linear.domain.extend([13,21]);proto.objective.vars.extend(insertvars);proto.objective.coeffs.extend([-1]*len(insertvars));proto.objective.scaling_factor=-1.
    values=[0]*len(proto.variables);values[mp['options'][mp['warm_skeleton']]]=1;warm=set(mp['warm_candidates'])
    for r in mp['candidates']:values[r['var']]=int(r['candidate'] in warm)
    proto.ClearField('solution_hint');proto.solution_hint.vars.extend(range(len(values)));proto.solution_hint.values.extend(values)
    # Every complete hint value satisfies every retained hard constraint.
    for c in proto.constraints:
        assert not c.enforcement_literal;kind=c.WhichOneof('constraint')
        if kind=='at_most_one':assert sum(values[i] for i in c.at_most_one.literals)<=1
        elif kind=='exactly_one':assert sum(values[i] for i in c.exactly_one.literals)==1
        elif kind=='linear':
            value=sum(values[i]*co for i,co in zip(c.linear.vars,c.linear.coeffs));assert any(a<=value<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        else:raise AssertionError(kind)
    assert sum(values[i] for i in insertvars)==13;model=cp_model.CpModel();assert model.proto.parse_text_format(text_format.MessageToString(proto));model.rebuild_constant_map();assert model.validate()=='';model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'complete-hint.json',values);write(OUT/'prepared.json',{'variables':len(proto.variables),'constraints':len(proto.constraints),'complete_feasible_hint_verified':True,'hint_inserts':13,'full_job_inserts_required':21,'changed_constraint_index':ci,'model_sha256':digest(OUT/'model.pbtxt')});print((OUT/'prepared.json').read_text(),flush=True)
if __name__=='__main__':main()
