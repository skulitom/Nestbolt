"""Actual free-region contacts against complete, fixed original cog groups."""
from pathlib import Path
from collections import Counter,deque
from datetime import datetime,timezone
import json,copy,math,time,shutil,traceback
from shapely.geometry import Polygon,box,mapping
from shapely.affinity import affine_transform
from shapely.ops import unary_union
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;SRC=ROOT/'output/h5-coordinated-placement-selection-20261018';OPT=ROOT/'output/h5-insert-completion-selection-20261018';OUT=ROOT/'output/h5-cog-skeleton-contacts-20261018';load=base.load;write=base.write;digest=base.digest;gap=base.gap
def key(p):
    t=p['transform'];return (p['part_id'],p['sheet_id'],t['mirrored'],float(t['rotation_radians']).hex(),*(float(v).hex() for v in t['translation']))
def main():
    assert load(OPT/'audit/checks.json')['incumbents'][-1]['missing']=={'insert':8};OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');prior=load(SRC/'candidates.json');sets=load(SRC/'cog-skeletons.json')['sets'];job=load(SRC/'job.json');target=load(SRC/'conditional-target.json');parts={p['id']:p for p in job['parts']};originals={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance'];plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':digest(Path(__file__)),'inputs':{str(p.relative_to(ROOT)):digest(p) for p in [SRC/'candidates.json',SRC/'cog-skeletons.json',SRC/'job.json',SRC/'conditional-target.json',SRC/'audit/checks.json',OPT/'audit/checks.json']},'generation_seconds_limit':120,'maximum_new_candidates_per_family':900,'construction_clearance_mm':.225,'boundary_epsilon_mm':.0001,'deduplication':'Preserve the entire old pool and all original unrounded coordinates. New pose identity uses exact binary64 hexadecimal angle and translation plus family, sheet and reflection; no tolerance merging.','method':'For each of four full original fifteen-cog arrangements, each original sheet and every permitted quarter-turn/reflection of frame, bracket and insert, subtract the union of conservative filled-outer cog exclusions from the unchanged target-stock translation box. Cache only exact zero-translation primitive obstacles, translating by the fixed original cog pose. Retain every polygon boundary/interior-ring vertex and a representative interior point. Cycle over all queries within each family and take successively spread angular quantiles of each ordered point ring, up to 900 new exact poses per family. Each retained pose must pass direct original-geometry checks against every cog on its sheet and original target bounds. Other families are not fixed. This is a finite geometry construction, not a full layout or a proof that an empty conservative region excludes all possibilities.','full_original_quantity_requirement_unchanged':True,'native_packing_calls':0,'quality_runs':0};write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','conditional-target.json','cog-skeletons.json']:shutil.copyfile(SRC/n,OUT/n)
    templates=[]
    for family in ['frame','bracket','insert']:
        part=parts[family];assert part['rotations']['kind']=='list'
        for mirror in ([False,True] if part['allow_mirror'] else [False]):
            for degrees in part['rotations']['degrees']:
                angle=math.radians(degrees);t=base.transform(angle,mirrored=mirror);g=gap.pose(originals[family],t);x0,y0,x1,y1=g.bounds;t['translation']=[-x0,-y0];templates.append({'id':len(templates),'part_id':family,'transform':t,'width':x1-x0,'height':y1-y0})
    write(OUT/'templates.json',templates);(OUT/'obstacles').mkdir();(OUT/'regions').mkdir();t0=time.perf_counter();cache={};queries=[];expired=False
    for skeleton in sets:
        for template in templates:
            moving=gap.pose(originals[template['part_id']],template['transform'])
            for sheet in ['sheet-0','sheet-1']:
                if time.perf_counter()-t0>=120:expired=True;break
                top=st['height'] if sheet=='sheet-0' else target['required_used_height_mm'];limits=[m['left']+edge+.0001,m['bottom']+edge+.0001,st['width']-m['right']-edge-.0001-template['width'],top-m['top']-edge-.0001-template['height']]
                if limits[0]>limits[2] or limits[1]>limits[3]:continue
                fixed=[i for i in skeleton['candidates'] if prior[i]['placement']['sheet_id']==sheet];terms=[];termmeta=[]
                for i in fixed:
                    t=prior[i]['placement']['transform'];zero={**t,'translation':[0.,0.]};ck=(float(t['rotation_radians']).hex(),t['mirrored'],template['id'])
                    if ck not in cache:
                        obstacle=gap.obstacle(gap.pose(originals['cog'],zero),moving,.225);oi=len(cache);cache[ck]=(oi,obstacle);write(OUT/'obstacles'/f'{oi}.json',{'cog_transform':zero,'template':template['id'],'geometry':mapping(obstacle)})
                    oi,obstacle=cache[ck];x,y=t['translation'];terms.append(affine_transform(obstacle,[1,0,0,1,x,y]));termmeta.append({'cog_candidate':i,'obstacle':oi,'translation':[x,y]})
                free=box(*limits).difference(unary_union(terms));points=[]
                for p in gap.polygons(free):
                    for ring in [p.exterior,*p.interiors]:points.extend(list(ring.coords)[:-1])
                    rp=p.representative_point();points.append((rp.x,rp.y))
                points=sorted(set(points),key=lambda p:(math.atan2(p[1]-top/2,p[0]-st['width']/2),p[0],p[1]));order=[];seen=set();length=len(points)
                for denominator in [4,8,16,32,64,128,256,512,1024]:
                    for k in range(denominator):
                        pi=k*length//denominator
                        if length and pi not in seen:seen.add(pi);order.append(pi)
                    if len(seen)==length:break
                order.extend(i for i in range(length) if i not in seen);q={'id':len(queries),'skeleton':skeleton['index'],'template':template['id'],'sheet_id':sheet,'fixed_cogs':fixed,'limits':limits,'terms':termmeta,'points':points,'order':order};write(OUT/'regions'/f'{q["id"]}.json',mapping(free));queries.append(q)
            if expired:break
        if expired:break
    write(OUT/'queries.json',queries);pool=copy.deepcopy(prior);keys={key(p['placement']):i for i,p in enumerate(pool)};selected=[];duplicates=0;rejected=[];added=Counter();pairchecks=0
    for family in ['frame','bracket','insert']:
        pending=deque((q,0) for q in queries if templates[q['template']]['part_id']==family and q['order'])
        while pending and added[family]<900:
            q,k=pending.popleft();pi=q['order'][k];x,y=q['points'][pi];template=templates[q['template']];t=copy.deepcopy(template['transform']);t['translation'][0]+=x;t['translation'][1]+=y;p={'part_id':family,'sheet_id':q['sheet_id'],'transform':t};identity=key(p)
            if identity in keys:duplicates+=1
            else:
                g=gap.pose(originals[family],t);x0,y0,x1,y1=g.bounds;top=st['height'] if q['sheet_id']=='sheet-0' else target['required_used_height_mm'];valid=x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7 and x1<=st['width']-m['right']-edge+1e-7 and y1<=top-m['top']-edge+1e-7;minimum=math.inf
                for i in q['fixed_cogs']:
                    fixed=gap.pose(originals['cog'],prior[i]['placement']['transform']);pairchecks+=1;d=g.distance(fixed);minimum=min(minimum,d);valid=valid and g.disjoint(fixed) and d>=job['clearance']-1e-7
                if valid:
                    i=len(pool);keys[identity]=i;source={'kind':'cog-skeleton-contact','query':q['id'],'point':pi};pool.append({'index':i,'placement':p,'source':source,'filled_area_mm2':originals[family].area});selected.append({'candidate':i,'query':q['id'],'point':pi,'minimum_cog_distance_mm':minimum if math.isfinite(minimum) else None});added[family]+=1
                else:rejected.append({'query':q['id'],'point':pi,'placement':p,'minimum_cog_distance_mm':minimum if math.isfinite(minimum) else None})
            if k+1<len(q['order']):pending.append((q,k+1))
    write(OUT/'candidates.json',pool);write(OUT/'selected-contacts.json',selected);write(OUT/'rejected-contacts.json',rejected);result={'seconds':time.perf_counter()-t0,'generation_expired':expired,'templates':len(templates),'queries':len(queries),'empty_queries':sum(not q['points'] for q in queries),'primitive_obstacles':len(cache),'all_query_points':sum(len(q['points']) for q in queries),'prior_candidates':len(prior),'new_candidates':len(pool)-len(prior),'new_by_family':dict(added),'exact_duplicate_contact_events':duplicates,'rejected_contact_events':len(rejected),'fixed_cog_pair_checks':pairchecks,'total_candidates':len(pool),'new_conflict_graph_built':False,'full_target_witness':False};write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
