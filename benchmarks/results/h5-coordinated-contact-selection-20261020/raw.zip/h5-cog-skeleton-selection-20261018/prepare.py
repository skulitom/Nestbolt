"""Condition the audited candidate graph on one of four actual full-cog arrangements."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,gzip,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-coordinated-placement-selection-20261018';OLD=ROOT/'output/h5-contact-placement-selection-20261018';OUT=ROOT/'output/h5-cog-skeleton-selection-20261018';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def key(p):
    t=p['transform'];return (p['part_id'],p['sheet_id'],t['mirrored'],float(t['rotation_radians']).hex(),*(float(v).hex() for v in t['translation']))
def main():
    assert load(SRC/'solve/result-audit.json')['solver_status']=='UNKNOWN';OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();pool=load(SRC/'candidates.json');sets=load(SRC/'cog-skeletons.json')['sets'];job=load(SRC/'job.json');assert len(sets)==4;assert load(SRC/'audit/checks.json')['complete'];sources=[SRC/n for n in ['plan.json','candidates.json','cog-skeletons.json','job.json','new-conflicts.jsonl.gz','new-cliques.jsonl.gz','audit/checks.json','solve/result-audit.json']]+[OLD/n for n in ['conflicts.jsonl.gz','cliques.jsonl.gz']]
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':digest(Path(__file__)),'input_hashes':{str(p.relative_to(ROOT)):digest(p) for p in sources},'method':'Select exactly one of the four original full fifteen-cog arrangements already present in the audited retained layouts. Keep all non-cog candidate positions compatible with at least one arrangement, and couple each position to its actual compatible arrangements. Project the old/new verified conflict cliques to non-cog candidates and deduplicate identical projected cliques; this preserves every conflict among retained non-cog positions. Require exactly all eighteen frames, twelve brackets and twenty-one inserts. The selected whole cog arrangement supplies all fifteen cogs. No frames, brackets or inserts are fixed. Hint the greatest-filled-area existing partial and its cog arrangement. This is a new restricted conditional construction, not a repeat of the unrestricted UNKNOWN solve and not an infeasibility proof for other cog positions.','seconds_limit':120,'workers':8,'seed':0,'native_packing_calls':0,'quality_runs':0,'objective':None};write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','conditional-target.json','candidates.json','cog-skeletons.json']:shutil.copyfile(SRC/n,OUT/n)
    adj=[0]*len(pool)
    for path in [OLD/'conflicts.jsonl.gz',SRC/'new-conflicts.jsonl.gz']:
        with gzip.open(path,'rt',encoding='utf-8') as f:
            for line in f:i,j=json.loads(line);adj[i]|=1<<j;adj[j]|=1<<i
    masks=[sum(1<<i for i in s['candidates']) for s in sets]
    for s,mask in zip(sets,masks):assert len(s['candidates'])==15 and all(pool[i]['placement']['part_id']=='cog' and not(adj[i]&mask) for i in s['candidates'])
    compatible={i:[si for si,mask in enumerate(masks) if not(adj[i]&mask)] for i,p in enumerate(pool) if p['placement']['part_id']!='cog'};retained={i:ss for i,ss in compatible.items() if ss};projected=set();input_cliques=0
    for path in [OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']:
        with gzip.open(path,'rt',encoding='utf-8') as f:
            for line in f:
                input_cliques+=1;ids=tuple(sorted(i for i in json.loads(line) if i in retained))
                if len(ids)>1:projected.add(ids)
    projected=sorted(projected);lookup={key(p['placement']):i for i,p in enumerate(pool)};warmchoices=[]
    for s in sets:
        for path in s['sources']:
            layout=load(ROOT/path);ids=[lookup[key(p)] for p in layout['placements']];area=sum(pool[i]['filled_area_mm2'] for i in ids);warmchoices.append((area,len(ids),path,s['index'],ids))
    warm=min(warmchoices,key=lambda r:(-r[0],-r[1],r[2]));assert all(i in retained and warm[3] in retained[i] for i in warm[4] if pool[i]['placement']['part_id']!='cog');model=cp_model.CpModel();options=[model.new_bool_var(f'skeleton-{i}') for i in range(4)];model.add_exactly_one(options);variables={i:model.new_bool_var(f'p{i}') for i in retained}
    for i,ss in retained.items():
        if len(ss)<4:model.add(variables[i]<=sum(options[s] for s in ss))
    for ids in projected:model.add_at_most_one(variables[i] for i in ids)
    for part in job['parts']:
        if part['id']=='cog':continue
        model.add(sum(v for i,v in variables.items() if pool[i]['placement']['part_id']==part['id'])==part['quantity'])
    model.add_hint(options[warm[3]],1)
    for i in warm[4]:
        if i in variables:model.add_hint(variables[i],1)
    assert model.validate()=='';model.export_to_file(str(OUT/'model.pbtxt'));solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=120;solver.parameters.num_search_workers=8;solver.parameters.random_seed=0;solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False;(OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    mapping={'options':[v.index for v in options],'candidates':[{'candidate':i,'var':v.index,'compatible_skeletons':retained[i]} for i,v in variables.items()],'excluded_non_cog_candidates':[i for i,ss in compatible.items() if not ss],'warm_source':warm[2],'warm_skeleton':warm[3],'warm_candidates':warm[4]};write(OUT/'mapping.json',mapping)
    with gzip.open(OUT/'projected-cliques.jsonl.gz','xt',encoding='utf-8',newline='\n') as f:
        for ids in projected:f.write(json.dumps(ids)+'\n')
    result={'skeletons':4,'union_cog_positions':len(set(i for s in sets for i in s['candidates'])),'retained_non_cog_positions':len(retained),'excluded_non_cog_positions':len(compatible)-len(retained),'original_cliques':input_cliques,'projected_cliques':len(projected),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'warm_original_parts':len(warm[4]),'warm_filled_area_mm2':warm[0],'seconds':time.perf_counter()-started,'model_sha256':digest(OUT/'model.pbtxt')};write(OUT/'prepared.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':main()
