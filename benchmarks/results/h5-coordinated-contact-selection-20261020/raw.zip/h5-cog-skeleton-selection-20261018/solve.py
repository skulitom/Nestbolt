from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,traceback
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog-skeleton-selection-20261018';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert not (OUT/'solver.log').exists();audit=load(OUT/'model-audit.json');assert audit['model_sha256']==sha256((OUT/'model.pbtxt').read_bytes()).hexdigest();shutil.copyfile(__file__,OUT/'solve.py');model=cp_model.CpModel();assert model.proto.parse_text_format((OUT/'model.pbtxt').read_text());model.rebuild_constant_map();assert model.validate()=='';solver=cp_model.CpSolver();assert solver.parameters.parse_text_format((OUT/'parameters.pbtxt').read_text());assert solver.parameters.max_time_in_seconds==120 and solver.parameters.num_search_workers==8 and solver.parameters.random_seed==0;write(OUT/'started.json',{'utc':datetime.now(timezone.utc).isoformat(),'model_sha256':audit['model_sha256']})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());t0=time.perf_counter();status=solver.solve(model);seconds=time.perf_counter()-t0
    feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE];result={'status':solver.status_name(status),'seconds':seconds,'feasible':feasible,'response_stats':solver.response_stats(),'model_sha256':audit['model_sha256']}
    if feasible:
        def value(i):return solver.value(model.get_int_var_from_proto_index(i))
        mp=load(OUT/'mapping.json');sets=load(OUT/'cog-skeletons.json')['sets'];pool=load(OUT/'candidates.json');si=next(i for i,v in enumerate(mp['options']) if value(v));ids=sorted(sets[si]['candidates']+[r['candidate'] for r in mp['candidates'] if value(r['var'])]);write(OUT/'selected-indices.json',ids);counts=Counter();placements=[]
        for i in ids:p=json.loads(json.dumps(pool[i]['placement']));p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
        previous=load(ROOT/'output/h5-contact-placement-selection-20261018/solve/selected-layout.json');write(OUT/'selected-layout.json',{'version':1,'units':'mm','sheets':previous['sheets'],'placements':placements});result['selected_skeleton']=si;result['counts']=dict(counts)
    write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
