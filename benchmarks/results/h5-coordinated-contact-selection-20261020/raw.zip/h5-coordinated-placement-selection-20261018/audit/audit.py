"""Independent source reconstruction and exhaustive added-pair verification."""
from pathlib import Path
from collections import Counter
import json,math,gzip,copy,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon
import audit_h5_cog_lattices as audit
ROOT=audit.ROOT;OLD=ROOT/'output/h5-contact-placement-selection-20261018';RUN=ROOT/'output/h5-coordinated-placement-selection-20261018';OUT=RUN/'audit';load=audit.load;write=audit.write;digest=audit.digest
def key(p):
    t=p['transform'];return (p['part_id'],p['sheet_id'],t['mirrored'],float(t['rotation_radians']).hex(),*(float(v).hex() for v in t['translation']))
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(RUN/'plan.json');pool=load(RUN/'candidates.json');old=load(OLD/'candidates.json');generation=load(RUN/'generation.json');job=load(RUN/'job.json');target=load(RUN/'conditional-target.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];n0=len(old);assert n0==8798 and pool[:n0]==old
    sealed={}
    for name,h in plan['sealed_manifests'].items():
        assert digest(ROOT/name)==h
        for row in load(ROOT/name)['files']:
            if row['path'].startswith('h5-'):sealed[row['path']]=row['sha256']
    for name,h in plan['sources'].items():assert digest(ROOT/name)==h==sealed[(ROOT/name).relative_to(ROOT/'output').as_posix()]
    for name in ['job.json','library.json','request.json','conditional-target.json','warm-indices.json']:assert (RUN/name).read_bytes()==(OLD/name).read_bytes()
    expected_events=[];keys={key(p['placement']):i for i,p in enumerate(old)};expected=copy.deepcopy(old)
    def consume(p,source):
        p=copy.deepcopy(p);p.pop('copy_index',None);k=key(p);added=k not in keys
        if added:
            i=len(expected);keys[k]=i;expected.append({'index':i,'placement':p,'source':source,'filled_area_mm2':Polygon(parts[p['part_id']]['geometry'][0]['outer']).area})
        expected_events.append({'source':source,'candidate_index':keys[k],'added':added})
    for name in plan['layout_sources']:
        for i,p in enumerate(load(ROOT/name)['placements']):consume(p,{'kind':'coordinated-layout','path':name,'placement':i})
    rows=ROOT/plan['frame_source'];patterns=load(rows/'patterns.json');frames=load(rows/'frames.json')
    for fi,frame in enumerate(frames):
        index=0
        for b in frame['placed']:
            p=patterns[b['pattern']]
            for member in p['members']:
                t=copy.deepcopy(member['transform']);x,y=t['translation']
                if b['rotated']:x,y=p['height']-y,x;t['rotation_radians']+=math.pi/2
                t['translation']=[m['left']+edge+.0001+b['x']+x,m['bottom']+edge+.0001+b['y']+y]
                consume({'part_id':member['part_id'],'sheet_id':f"sheet-{b['bin']}",'transform':t},{'kind':'row-frame','frame':fi,'placement':index});index+=1
    assert expected==pool and expected_events==load(RUN/'source-events.json') and len(expected_events)==1790;geoms=[];bounds=[];sheets=[]
    for i,p in enumerate(pool):
        assert p['index']==i;placement=p['placement'];part=parts[placement['part_id']];t=placement['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mirror=-1 if t['mirrored'] else 1;vertices=np.asarray(part['geometry'][0]['outer'])@np.array([[mirror*c,mirror*s],[-s,c]])+np.asarray(t['translation']);g=Polygon(vertices);assert g.is_valid;geoms.append(g);bounds.append(g.bounds);sheets.append(placement['sheet_id']);assert not t['mirrored'] or part['allow_mirror']
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
        x0,y0,x1,y1=g.bounds;top=stock['height'] if placement['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7 and x1<=stock['width']-m['right']-edge+1e-7 and y1<=top-m['top']-edge+1e-7
    n=len(pool);actual=[0]*n;recorded=[0]*n;full=[0]*n;gs=np.asarray(geoms,dtype=object);bounds=np.asarray(bounds);sheets=np.asarray(sheets);pairs=0;near=0;edges=0
    # Every earlier-index same-sheet pair for each newly appended candidate.
    for j in range(n0,n):
        ids=np.arange(j);ids=ids[sheets[ids]==sheets[j]];pairs+=len(ids);dx=np.maximum(0,np.maximum(bounds[ids,0]-bounds[j,2],bounds[j,0]-bounds[ids,2]));dy=np.maximum(0,np.maximum(bounds[ids,1]-bounds[j,3],bounds[j,1]-bounds[ids,3]));ids=ids[np.hypot(dx,dy)<=job['clearance']+1e-7];near+=len(ids);distances=shapely.distance(gs[j],gs[ids])
        for i in ids[distances<job['clearance']-1e-7]:i=int(i);actual[i]|=1<<j;actual[j]|=1<<i;edges+=1
    with gzip.open(RUN/'new-conflicts.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            i,j=json.loads(line);assert 0<=i<j<n and j>=n0 and not(recorded[i]&(1<<j));recorded[i]|=1<<j;recorded[j]|=1<<i
    assert actual==recorded and edges==generation['new_edges']==132531
    oldedges=0
    with gzip.open(OLD/'conflicts.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            i,j=json.loads(line);assert 0<=i<j<n0;full[i]|=1<<j;full[j]|=1<<i;oldedges+=1
    assert oldedges==load(OLD/'audit/checks.json')['conflict_edges_verified']==2517051
    full=[a|b for a,b in zip(full,actual)];uncovered=actual.copy();cliques=0
    with gzip.open(RUN/'new-cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            ids=json.loads(line);mask=sum(1<<i for i in ids);assert mask.bit_count()==len(ids)
            for i in ids:assert (mask^(1<<i))&~full[i]==0;uncovered[i]&=~mask
            cliques+=1
    assert not any(uncovered) and cliques==generation['new_clique_constraints'];warm=load(RUN/'warm-indices.json');mask=sum(1<<i for i in warm);assert len(warm)==mask.bit_count()==63 and all(not(full[i]&mask) for i in warm)
    counts=Counter(pool[i]['placement']['part_id'] for i in warm);required=Counter({p['id']:p['quantity'] for p in job['parts']});assert dict(required-counts)=={'cog':3}
    result={'complete':True,'candidates':n,'new_candidates':n-n0,'all_1790_source_events_and_exact_deduplication_reconstructed':True,'prior_candidates_and_original_inputs_unchanged':True,'old_graph_and_cliques_reused_under_sealed_hashes':True,'all_individual_original_stock_and_rotation_checks_pass':True,'same_sheet_added_candidate_pairs_enumerated':pairs,'new_pair_distances_checked':near,'new_conflict_edges_verified':edges,'new_cliques_verified':cliques,'all_new_edges_covered_without_false_edges':True,'old_partial_hint_conflict_free':True,'hint_missing':{'cog':3},'new_full_witness':False}
    write(OUT/'checks.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':main()
