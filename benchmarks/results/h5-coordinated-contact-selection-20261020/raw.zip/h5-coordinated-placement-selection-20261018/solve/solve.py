from pathlib import Path
from hashlib import sha256
from collections import Counter
from datetime import datetime,timezone
import json,time,shutil,traceback
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-coordinated-placement-selection-20261018';OUT=SRC/'solve';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert not (OUT/'solver.log').exists();audit=load(OUT/'model-audit.json');assert sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()==audit['model_sha256'];shutil.copyfile(__file__,OUT/'solve.py');model=cp_model.CpModel();assert model.proto.parse_text_format((OUT/'model.pbtxt').read_text());model.rebuild_constant_map();assert model.validate()=='';solver=cp_model.CpSolver();assert solver.parameters.parse_text_format((OUT/'parameters.pbtxt').read_text());write(OUT/'started.json',{'utc':datetime.now(timezone.utc).isoformat(),'model_sha256':audit['model_sha256'],'model_audit_sha256':sha256((OUT/'model-audit.json').read_bytes()).hexdigest()})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda msg:(log.write(msg+'\n'),log.flush());t0=time.perf_counter();status=solver.solve(model);seconds=time.perf_counter()-t0
    feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE];result={'status':solver.status_name(status),'seconds':seconds,'feasible':feasible,'response_stats':solver.response_stats(),'model_sha256':audit['model_sha256']}
    if feasible:
        pool=load(SRC/'candidates.json');selected=[i for i in range(len(pool)) if solver.value(model.get_int_var_from_proto_index(i))];write(OUT/'selected-indices.json',selected);counts=Counter();placements=[]
        for i in selected:
            p=json.loads(json.dumps(pool[i]['placement']));p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
        old=load(ROOT/'output/h5-contact-placement-selection-20261018/solve/selected-layout.json');write(OUT/'selected-layout.json',{'version':1,'units':'mm','sheets':old['sheets'],'placements':placements});result['counts']=dict(counts);result['selected']=len(selected)
    write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
