from pathlib import Path
from hashlib import sha256
import json,gzip,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-coordinated-placement-selection-20261018';OLD=ROOT/'output/h5-contact-placement-selection-20261018';OUT=SRC/'solve';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');check=load(SRC/'audit/checks.json');assert check['complete'] and check['candidates']==9059;pool=load(SRC/'candidates.json');job=load(SRC/'job.json');warm=load(SRC/'warm-indices.json');plan=load(SRC/'plan.json');model=cp_model.CpModel();variables=[model.new_bool_var(f'p{i}') for i in range(len(pool))];counts=[]
    for path in [OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']:
        count=0
        with gzip.open(path,'rt',encoding='utf-8') as f:
            for line in f:model.add_at_most_one(variables[i] for i in json.loads(line));count+=1
        counts.append(count)
    for part in job['parts']:model.add(sum(variables[i] for i,p in enumerate(pool) if p['placement']['part_id']==part['id'])==part['quantity'])
    for i in warm:model.add_hint(variables[i],1)
    assert model.validate()=='';model.export_to_file(str(OUT/'model.pbtxt'));solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=plan['selection_seconds_limit'];solver.parameters.num_search_workers=plan['selection_workers'];solver.parameters.random_seed=plan['selection_seed'];solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False;(OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    result={'variables':len(variables),'old_cliques':counts[0],'new_cliques':counts[1],'exact_original_quantities':{p['id']:p['quantity'] for p in job['parts']},'hints':len(warm),'objective':None,'model_sha256':digest(OUT/'model.pbtxt'),'input_hashes':{str(p.relative_to(ROOT)):digest(p) for p in [SRC/'candidates.json',SRC/'job.json',SRC/'warm-indices.json',SRC/'new-cliques.jsonl.gz',SRC/'audit/checks.json',OLD/'cliques.jsonl.gz']}};write(OUT/'prepared.json',result);print(json.dumps({k:v for k,v in result.items() if k!='input_hashes'}),flush=True)
if __name__=='__main__':main()
