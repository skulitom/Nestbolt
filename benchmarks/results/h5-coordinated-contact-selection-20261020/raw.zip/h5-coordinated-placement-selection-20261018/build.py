"""Extend the audited pool with exact retained coordinated poses and row frames."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,copy,gzip,heapq,itertools,time,shutil,traceback
import numpy as np
import shapely
from shapely.geometry import Polygon
from shapely.strtree import STRtree
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;OLD=ROOT/'output/h5-contact-placement-selection-20261018';ROWS=ROOT/'output/h5-five-row-shelves-20261018';OUT=ROOT/'output/h5-coordinated-placement-selection-20261018';load=base.load;write=base.write;digest=base.digest;TOL=1e-7
SOURCES=[ROOT/'output'/n for n in ['h5-aligned-aspect-backfill-20261018','h5-pocket-aspect-backfill-20261018','h5-five-row-backfill-20261018']]
def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit
def key(p):
    t=p['transform'];return (p['part_id'],p['sheet_id'],t['mirrored'],float(t['rotation_radians']).hex(),*(float(v).hex() for v in t['translation']))
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter();manifests=[ROOT/'benchmarks/results'/n/'raw-manifest.json' for n in ['h5-contact-selection-20261018','h5-aligned-pockets-and-rows-20261018']];sealed={}
    for path in manifests:
        for row in load(path)['files']:
            if row['path'].startswith('h5-'):sealed[row['path']]=row['sha256']
    layouts=[root/f'partial-{i:02d}'/'layout.json' for root in SOURCES for i in range(8)];inputs=[OLD/n for n in ['candidates.json','conflicts.jsonl.gz','cliques.jsonl.gz','warm-indices.json','job.json','library.json','request.json','conditional-target.json','audit/checks.json','model.json']]+layouts+[ROWS/n for n in ['frames.json','patterns.json','trace-audit.json']]+[root/'audit/checks.json' for root in SOURCES]
    hashes={str(p.relative_to(ROOT)):digest(p) for p in inputs}
    for p in inputs:assert hashes[str(p.relative_to(ROOT))]==sealed[p.relative_to(ROOT/'output').as_posix()],p
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':digest(Path(__file__)),'sources':hashes,'sealed_manifests':{str(p.relative_to(ROOT)):digest(p) for p in manifests},'layout_sources':[str(p.relative_to(ROOT)) for p in layouts],'frame_source':str(ROWS.relative_to(ROOT)),'original_pool_count':8798,'maximum_new_pose_events':24*66+24*18,'deduplication':'Keep every prior entry and original index. New poses strip copy_index only; identity is family, sheet, mirror flag and exact binary64 hexadecimal rotation/translation values. Do not round, normalize angles or discard near-equal coordinates. Log every new-source pose event including exact duplicate references.','graph':'Reuse the entire old independently audited 2,517,051-edge graph and its 17,097 cliques only under previously sealed byte hashes. Compute every new-old and new-new same-sheet conflict from filled outer geometry. Compress only the new edge coverage using full-graph verified cliques; already covered old edges may recur harmlessly. Retain every residual edge after the compression cap. Audit all new pairs by independent exhaustive enumeration before solving.','clique_seconds_limit':30,'selection_seconds_limit':120,'selection_seed':0,'selection_workers':8,'selection':'One exact original-inventory CP-SAT feasibility run. No objective, partial acceptance or fixed frame positions. The old valid 63-position partial is a nonbinding positive hint. The changed candidate pool, original stock, margins, rotations, quantities and target are frozen before that run.','acceptance_tolerance_mm':TOL,'native_packing_calls':0,'quality_runs':0,'scope':'Finite offline construction; UNKNOWN or finite-pool infeasibility is not unrestricted infeasibility. Native margins and full H5 qualification remain separate.'};write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','conditional-target.json','warm-indices.json']:shutil.copyfile(OLD/n,OUT/n)
    job=load(OLD/'job.json');target=load(OLD/'conditional-target.json');parts={p['id']:p for p in job['parts']};shapes={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];old=load(OLD/'candidates.json');assert len(old)==8798;pool=copy.deepcopy(old);keys={key(p['placement']):i for i,p in enumerate(pool)};assert len(keys)==len(old);events=[]
    def add(p,source):
        p=copy.deepcopy(p);p.pop('copy_index',None);k=key(p);added=k not in keys
        if added:
            i=len(pool);keys[k]=i;pool.append({'index':i,'placement':p,'source':source,'filled_area_mm2':shapes[p['part_id']].area})
        i=keys[k];events.append({'source':source,'candidate_index':i,'added':added})
    for path in layouts:
        for pi,p in enumerate(load(path)['placements']):add(p,{'kind':'coordinated-layout','path':str(path.relative_to(ROOT)),'placement':pi})
    patterns=load(ROWS/'patterns.json');frames=load(ROWS/'frames.json');assert len(frames)==24
    for fi,frame in enumerate(frames):
        for pi,p in enumerate(base.layout_of(job,patterns,frame['placed'])['placements']):add(p,{'kind':'row-frame','frame':fi,'placement':pi})
    assert len(events)<=plan['maximum_new_pose_events'];geoms=[]
    for i,p in enumerate(pool):
        assert p['index']==i;t=p['placement']['transform'];part=parts[p['placement']['part_id']];g=base.gap.pose(shapes[part['id']],t);assert g.is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
        a,b,c,d=g.bounds;h=stock['height'] if p['placement']['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert a>=m['left']+edge-TOL and b>=m['bottom']+edge-TOL and c<=stock['width']-m['right']-edge+TOL and d<=h-m['top']-edge+TOL;geoms.append(g)
    write(OUT/'candidates.json',pool);write(OUT/'source-events.json',events);n=len(pool);adj=[0]*n;oldedges=0
    with gzip.open(OLD/'conflicts.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            i,j=json.loads(line);assert 0<=i<j<8798 and not(adj[i]&(1<<j));adj[i]|=1<<j;adj[j]|=1<<i;oldedges+=1
    assert oldedges==2517051;newadj=[0]*n;newedges=[];distance_checks=0;gs=np.asarray(geoms,dtype=object)
    for sheet in ['sheet-0','sheet-1']:
        ids=np.asarray([i for i,p in enumerate(pool) if p['placement']['sheet_id']==sheet]);newids=ids[ids>=8798];tree=STRtree(gs[ids]);pairs=tree.query(gs[newids],predicate='dwithin',distance=job['clearance']+TOL);keep=ids[pairs[1]]<newids[pairs[0]];pairs=pairs[:,keep];a=ids[pairs[1]];b=newids[pairs[0]];distance_checks+=len(a);conflicts=shapely.distance(gs[a],gs[b])<job['clearance']-TOL
        for i,j in zip(a[conflicts],b[conflicts]):
            i,j=int(i),int(j);assert not(adj[i]&(1<<j));adj[i]|=1<<j;adj[j]|=1<<i;newadj[i]|=1<<j;newadj[j]|=1<<i;newedges.append((i,j))
    newedges.sort()
    with gzip.open(OUT/'new-conflicts.jsonl.gz','xt',encoding='utf-8',newline='\n') as f:
        for pair in newedges:f.write(json.dumps(pair)+'\n')
    warm=load(OUT/'warm-indices.json');wm=sum(1<<i for i in warm);assert len(warm)==63 and all(not(adj[i]&wm) for i in warm);remaining=newadj.copy();heap=[(-a.bit_count(),i) for i,a in enumerate(remaining) if a];heapq.heapify(heap);cliques=[];covered=0;t0=time.perf_counter()
    while heap and time.perf_counter()-t0<30:
        degree,i=heapq.heappop(heap)
        if -degree!=remaining[i].bit_count():continue
        choices=remaining[i]
        if not choices:continue
        clique=[i];mask=1<<i
        while choices:
            sample=list(itertools.islice(bits(choices),16));j=max(sample,key=lambda v:((adj[v]&choices).bit_count(),-v));clique.append(j);mask|=1<<j;choices&=adj[j]
        assert all((mask^(1<<j))&~adj[j]==0 for j in clique);cliques.append(clique)
        for j in clique:
            before=remaining[j].bit_count();remaining[j]&=~mask;after=remaining[j].bit_count();covered+=before-after
            if after:heapq.heappush(heap,(-after,j))
    compressed=len(cliques);residual=0
    for i,mask in enumerate(remaining):
        for j in bits(mask&~((1<<(i+1))-1)):cliques.append([i,j]);residual+=1
    assert covered//2+residual==len(newedges)
    with gzip.open(OUT/'new-cliques.jsonl.gz','xt',encoding='utf-8',newline='\n') as f:
        for clique in cliques:assert sum(i in warm for i in clique)<=1;f.write(json.dumps(clique)+'\n')
    result={'candidates':n,'original_candidates_retained_exact':len(old),'new_candidates':n-len(old),'new_by_family':dict(Counter(p['placement']['part_id'] for p in pool[8798:])),'source_events':len(events),'exact_duplicate_events':sum(not e['added'] for e in events),'old_edges_reused_under_sealed_hashes':oldedges,'new_edges':len(newedges),'new_pair_distances_checked':distance_checks,'new_compressed_cliques':compressed,'residual_pair_constraints':residual,'new_clique_constraints':len(cliques),'clique_seconds':time.perf_counter()-t0,'clique_limit_reached':bool(heap),'old_partial_hint_valid':True,'seconds':time.perf_counter()-started,'full_target_witness':False};write(OUT/'generation.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    import math
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
