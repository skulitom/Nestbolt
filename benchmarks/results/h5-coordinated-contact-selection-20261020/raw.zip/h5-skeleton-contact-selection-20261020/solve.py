from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,time,shutil,math,traceback
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-skeleton-contact-selection-20261020';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert not (OUT/'solver.log').exists();audit=load(OUT/'model-audit.json');assert sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()==audit['model_sha256'];shutil.copyfile(__file__,OUT/'solve.py');mp=load(OUT/'mapping.json');sets=load(OUT/'cog-skeletons.json')['sets'];pool=load(OUT/'candidates.json');model=cp_model.CpModel();assert model.proto.parse_text_format((OUT/'model.pbtxt').read_text());model.rebuild_constant_map();assert model.validate()=='';solver=cp_model.CpSolver();assert solver.parameters.parse_text_format((OUT/'parameters.pbtxt').read_text());write(OUT/'started.json',{'utc':datetime.now(timezone.utc).isoformat(),'model_sha256':audit['model_sha256']});records=[]
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            def v(i):return self.value(model.get_int_var_from_proto_index(i))
            si=next(i for i,var in enumerate(mp['options']) if v(var));ids=sorted(sets[si]['candidates']+[r['candidate'] for r in mp['candidates'] if v(r['var'])]);count=sum(pool[i]['placement']['part_id']=='insert' for i in ids)
            if records and count<=records[-1]['inserts']:return
            record={'index':len(records),'seconds':self.wall_time,'inserts':count,'objective':self.objective_value,'best_bound':self.best_objective_bound,'skeleton':si,'selected_indices':ids};records.append(record);write(OUT/f'incumbent-{record["index"]}.json',record);print(json.dumps({k:v for k,v in record.items() if k!='selected_indices'}),flush=True)
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());t0=time.perf_counter();status=solver.solve(model,Capture());seconds=time.perf_counter()-t0
    feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE];result={'status':solver.status_name(status),'seconds':seconds,'has_partial_solution':feasible,'incumbents':len(records),'response_stats':solver.response_stats(),'model_sha256':audit['model_sha256'],'full_target_witness':False}
    if feasible:
        assert records;best=records[-1];result.update(inserts=best['inserts'],missing_inserts=21-best['inserts'],best_bound=solver.best_objective_bound,selected_original_parts=len(best['selected_indices']),full_inventory_found=best['inserts']==21);counts=Counter();placements=[]
        for i in best['selected_indices']:p=json.loads(json.dumps(pool[i]['placement']));p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
        old=load(ROOT/'output/h5-contact-placement-selection-20261018/solve/selected-layout.json');write(OUT/'selected-layout.json',{'version':1,'units':'mm','sheets':old['sheets'],'placements':placements});write(OUT/'selected-indices.json',best['selected_indices'])
    write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
