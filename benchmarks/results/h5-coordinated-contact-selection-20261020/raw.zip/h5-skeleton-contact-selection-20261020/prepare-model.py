from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip, json, shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-skeleton-contact-selection-20261020'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f: json.dump(v,f,indent=2); f.write('\n')
def main():
    graph=load(OUT/'graph-audit.json'); assert graph['complete_clique_coverage_exact']
    shutil.copyfile(__file__,OUT/'prepare-model.py')
    pool=load(OUT/'candidates.json'); mp=load(OUT/'mapping.json'); job=load(OUT/'job.json')
    model=cp_model.CpModel(); options=[model.new_bool_var(f'skeleton-{i}') for i in range(4)]
    variables={r['candidate']:model.new_bool_var(f"p{r['candidate']}") for r in mp['candidates']}
    assert all(variables[r['candidate']].index==r['var'] for r in mp['candidates'])
    model.add_exactly_one(options)
    for r in mp['candidates']:
        if len(r['compatible_skeletons'])<4:
            model.add(variables[r['candidate']]<=sum(options[s] for s in r['compatible_skeletons']))
    with gzip.open(OUT/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f: model.add_at_most_one(variables[i] for i in json.loads(line))
    inserts=[]
    for part in job['parts']:
        if part['id']=='cog': continue
        family=[v for i,v in variables.items() if pool[i]['placement']['part_id']==part['id']]
        if part['id']=='insert': inserts=family; model.add_linear_constraint(sum(family),13,part['quantity'])
        else: model.add(sum(family)==part['quantity'])
    model.maximize(sum(inserts))
    warm=set(mp['warm_candidates'])
    for si,v in enumerate(options): model.add_hint(v,int(si==mp['warm_skeleton']))
    for i,v in variables.items(): model.add_hint(v,int(i in warm))
    assert model.validate()==''
    model.export_to_file(str(OUT/'model.pbtxt'))
    solver=cp_model.CpSolver()
    solver.parameters.max_time_in_seconds=120; solver.parameters.num_search_workers=8
    solver.parameters.random_seed=0; solver.parameters.log_search_progress=True; solver.parameters.log_to_stdout=False
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    write(OUT/'prepared.json',{'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),
        'objective':'maximize inserts, original target 21','hint_parts':len(warm),
        'model_sha256':sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()})
    print(json.dumps(load(OUT/'prepared.json')),flush=True)
if __name__=='__main__': main()
