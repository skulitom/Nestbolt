"""Consume every model field independently, including all zero/one hint values."""
from pathlib import Path
from collections import Counter
from hashlib import sha256
import gzip,json,re,shutil
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'output/h5-skeleton-contact-selection-20261020'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    shutil.copyfile(__file__,OUT/'audit-model.py')
    graph=load(OUT/'graph-audit.json'); assert graph['complete_clique_coverage_exact']
    assert sha256((OUT/'projected-cliques.jsonl.gz').read_bytes()).hexdigest()==graph['cliques_sha256']
    pool=load(OUT/'candidates.json'); mp=load(OUT/'mapping.json'); job=load(OUT/'job.json')
    vi={r['candidate']:r['var'] for r in mp['candidates']}; allowed={r['candidate']:r['compatible_skeletons'] for r in mp['candidates']}
    assert list(vi.values())==list(range(4,len(vi)+4))
    text=(OUT/'model.pbtxt').read_text(encoding='utf-8'); parse=lambda s:json.loads('['+s+']')
    vp=r'variables\s*\{\s*name:\s*"(skeleton-\d+|p\d+)"\s*domain:\s*\[0, 1\]\s*\}'
    assert re.findall(vp,text)==[f'skeleton-{i}' for i in range(4)]+[f'p{i}' for i in vi]
    ep=r'constraints\s*\{\s*exactly_one\s*\{\s*literals:\s*\[([^\]]*)\]\s*\}\s*\}'
    assert [parse(s) for s in re.findall(ep,text,re.S)]==[[0,1,2,3]]
    ap=r'constraints\s*\{\s*at_most_one\s*\{\s*literals:\s*\[([^\]]*)\]\s*\}\s*\}'
    with gzip.open(OUT/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:
        cliques=[json.loads(line) for line in f]
    assert [parse(s) for s in re.findall(ap,text,re.S)]==[[vi[i] for i in ids] for ids in cliques]
    lp=r'constraints\s*\{\s*linear\s*\{\s*vars:\s*\[([^\]]*)\]\s*coeffs:\s*\[([^\]]*)\]\s*domain:\s*\[([^\]]*)\]\s*\}\s*\}'
    actual=Counter((tuple(zip(parse(a),parse(b))),tuple(parse(d))) for a,b,d in re.findall(lp,text,re.S)); expected=Counter()
    for i,ls in allowed.items():
        if len(ls)<4:expected[(tuple(sorted([(si,-1) for si in ls]+[(vi[i],1)])),(-9223372036854775808,0))]+=1
    for part in job['parts']:
        if part['id']=='cog':continue
        domain=(13,part['quantity']) if part['id']=='insert' else (part['quantity'],part['quantity'])
        expected[(tuple((vi[i],1) for i in vi if pool[i]['placement']['part_id']==part['id']),domain)]+=1
    assert actual==expected
    hp=r'solution_hint\s*\{\s*vars:\s*\[([^\]]*)\]\s*values:\s*\[([^\]]*)\]\s*\}'
    hints=re.findall(hp,text,re.S); warm=set(mp['warm_candidates'])
    vals=[int(si==mp['warm_skeleton']) for si in range(4)]+[int(i in warm) for i in vi]
    assert len(hints)==1 and parse(hints[0][0])==list(range(len(vals))) and parse(hints[0][1])==vals
    assert sum(vals[:4])==1
    for terms,domain in expected:
        value=sum(vals[i]*c for i,c in terms); assert domain[0]<=value<=domain[1]
    assert all(sum(vals[vi[i]] for i in ids)<=1 for ids in cliques)
    op=r'objective\s*\{\s*vars:\s*\[([^\]]*)\]\s*scaling_factor:\s*(-?[0-9.]+)\s*coeffs:\s*\[([^\]]*)\]\s*\}'
    objectives=re.findall(op,text,re.S); insertvars=[vi[i] for i in vi if pool[i]['placement']['part_id']=='insert']
    assert len(objectives)==1
    a,s,c=objectives[0]; assert parse(a)==insertvars and float(s)==-1 and parse(c)==[-1]*len(insertvars)
    rest=text
    for pattern in [vp,ep,ap,lp,hp,op]:rest=re.sub(pattern,'',rest,flags=re.S)
    assert not rest.strip(),rest[:200]
    assert Counter(pool[i]['placement']['part_id'] for i in warm)==Counter(frame=18,bracket=12,cog=15,insert=13)
    checks={'variables':len(vals),'constraints':sum(expected.values())+len(cliques)+1,'all_fields_independently_verified':True,
        'complete_hint_feasible':True,'full_original_acceptance_requires_21_inserts':True,'hint_parts':58,'native_margin_qualified':False,
        'model_sha256':sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()}
    write(OUT/'model-audit.json',checks); print(json.dumps(checks),flush=True)
if __name__=='__main__':main()
