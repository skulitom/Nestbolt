"""Freeze a geometry-checked extension of the four cog-arrangement model."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import copy, gzip, heapq, itertools, json, math, shutil, time
import numpy as np
import shapely
from shapely.strtree import STRtree
from shapely.geometry import Polygon, Point, shape
import construct_h5_pattern_layouts as base
import audit_h5_cog_lattices as independent
ROOT=base.ROOT
CONTACT=ROOT/'output/h5-cog-skeleton-contacts-20261018'
PARENT=ROOT/'output/h5-cog-skeleton-selection-20261018'
OUT=ROOT/'output/h5-skeleton-contact-selection-20261020'
load=base.load; write=base.write; digest=base.digest

def lines(path):
    with gzip.open(path,'rt',encoding='utf-8') as f:
        for line in f: yield json.loads(line)

def bits(mask):
    while mask:
        bit=mask&-mask; yield bit.bit_length()-1; mask^=bit

def main():
    OUT.mkdir(); shutil.copyfile(__file__,OUT/'prepare-graph.py')
    started=time.perf_counter()
    sources=[CONTACT/n for n in ['plan.json','candidates.json','result.json','templates.json','queries.json','selected-contacts.json','rejected-contacts.json','job.json','conditional-target.json','cog-skeletons.json']]
    sources += [PARENT/n for n in ['mapping.json','candidates.json','projected-cliques.jsonl.gz','model-audit.json']]
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources},
        'method':'Retain every old non-cog pose compatible with a complete cog arrangement, plus every new compatible actual-outline contact. Select one of four unchanged 15-cog arrangements. Keep exactly 18 frames and 12 brackets; maximize inserts from 13 to the original 21. Require all 66 original parts before claiming feasibility. All four arrangements and all other placements remain selectable. A complete feasible 58-part hint is supplied. No native search, stock change, rounding or relaxed physical clearance.',
        'seconds_limit':120,'workers':8,'seed':0,'clique_seconds_limit':30,
        'acceptance_clearance_mm':.2,'acceptance_tolerance_mm':1e-7,
        'native_packing_calls':0,'quality_runs':0,
        'scope':'One new finite-pool construction, not a repeat of the prior model. Partial layouts do not pass the original job. UNKNOWN or a finite-pool bound does not establish unrestricted infeasibility.'})
    for n in ['job.json','library.json','request.json','conditional-target.json','candidates.json','cog-skeletons.json']:
        shutil.copyfile(CONTACT/n,OUT/n)
    prior=load(PARENT/'candidates.json'); pool=load(CONTACT/'candidates.json')
    assert len(prior)==9059 and pool[:9059]==prior and len(pool)==11319
    oldplan=load(CONTACT/'plan.json')
    for p,h in oldplan['inputs'].items(): assert digest(ROOT/p)==h
    job=load(OUT/'job.json'); target=load(OUT/'conditional-target.json')
    parts={p['id']:p for p in job['parts']}; originals={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()}
    geoms=np.asarray([base.gap.pose(originals[p['placement']['part_id']],p['placement']['transform']) for p in pool],dtype=object)
    auditgeoms=np.asarray([independent.shape(parts[p['placement']['part_id']],p['placement']['transform']) for p in pool],dtype=object)
    sheets=np.asarray([p['placement']['sheet_id'] for p in pool]); sets=load(OUT/'cog-skeletons.json')['sets']
    templates=load(CONTACT/'templates.json'); queries=load(CONTACT/'queries.json')
    contacts=load(CONTACT/'selected-contacts.json'); st=job['stocks'][0]; m=st['margins']; e=job['edge_clearance']
    checked=0
    for row in contacts:
        i=row['candidate']; q=queries[row['query']]; template=templates[q['template']]
        t=copy.deepcopy(template['transform']); x,y=q['points'][row['point']]
        t['translation'][0]+=x; t['translation'][1]+=y
        assert pool[i]['placement']=={'part_id':template['part_id'],'sheet_id':q['sheet_id'],'transform':t}
        assert shape(load(CONTACT/'regions'/f"{q['id']}.json")).distance(Point(x,y))<1e-9
        g=auditgeoms[i]; a,b,c,d=g.bounds; h=st['height'] if q['sheet_id']=='sheet-0' else target['required_used_height_mm']
        assert a>=m['left']+e-1e-7 and b>=m['bottom']+e-1e-7 and c<=st['width']-m['right']-e+1e-7 and d<=h-m['top']-e+1e-7
        part=parts[template['part_id']]
        assert not t['mirrored'] or part['allow_mirror']
        assert any(abs(math.remainder(t['rotation_radians']-math.radians(deg),math.tau))<1e-9 for deg in part['rotations']['degrees'])
        fixed=[j for j in sets[q['skeleton']]['candidates'] if sheets[j]==q['sheet_id']]
        assert fixed==q['fixed_cogs']
        distances=[g.distance(auditgeoms[j]) for j in fixed]; checked+=len(fixed)
        assert not distances or min(distances)>=job['clearance']-1e-7
        assert all(g.disjoint(auditgeoms[j]) for j in fixed)
        assert (not distances and row['minimum_cog_distance_mm'] is None) or abs(min(distances)-row['minimum_cog_distance_mm'])<1e-9
    assert [r['candidate'] for r in contacts]==list(range(9059,11319))
    assert not load(CONTACT/'rejected-contacts.json')
    noncog=np.asarray([i for i,p in enumerate(pool) if p['placement']['part_id']!='cog'])
    allowed={int(i):[] for i in noncog}; compatibility_checks=0
    for si,s in enumerate(sets):
        good=np.ones(len(noncog),dtype=bool)
        for j in s['candidates']:
            same=sheets[noncog]==sheets[j]; ids=noncog[same]; compatibility_checks+=len(ids)
            good[same]&=shapely.distance(auditgeoms[j],auditgeoms[ids])>=job['clearance']-1e-7
        for i in noncog[good]: allowed[int(i)].append(si)
    kept={i:ss for i,ss in allowed.items() if ss}; mp=load(PARENT/'mapping.json')
    assert {r['candidate']:r['compatible_skeletons'] for r in mp['candidates']}=={i:ss for i,ss in kept.items() if i<9059}
    assert all(i in kept for i in range(9059,11319))
    write(OUT/'contacts-audit.json',{'prior_prefix_exact':True,'new_contacts':len(contacts),'new_by_family':dict(Counter(pool[i]['placement']['part_id'] for i in range(9059,11319))),
        'original_contact_cog_pairs':checked,'all_skeleton_compatibility_pairs':compatibility_checks,'provenance_and_original_bounds_rotations_clearance_verified':True,
        'retained_positions':len(kept),'prior_retained_exact':True,'native_margin_qualified':False})
    adj=[0]*len(pool); newedges=[]; directchecks=0
    for sheet in ['sheet-0','sheet-1']:
        ids=np.asarray([i for i in kept if sheets[i]==sheet]); tree=STRtree(geoms[ids])
        pairs=tree.query(geoms[ids],predicate='dwithin',distance=job['clearance']+1e-7)
        pairs=pairs[:,pairs[0]<pairs[1]]; a=ids[pairs[0]]; b=ids[pairs[1]]; directchecks+=len(a)
        conflicts=shapely.distance(geoms[a],geoms[b])<job['clearance']-1e-7
        for i,j in zip(a[conflicts],b[conflicts]):
            i,j=int(i),int(j); adj[i]|=1<<j; adj[j]|=1<<i
            if j>=9059: newedges.append((i,j))
    oldcliques=list(lines(PARENT/'projected-cliques.jsonl.gz')); covered=[0]*len(pool)
    for clique in oldcliques:
        mask=sum(1<<i for i in clique)
        for i in clique:
            assert (mask^(1<<i))&~adj[i]==0
            covered[i]|=mask^(1<<i)
    for i in kept:
        if i<9059: assert adj[i]&((1<<9059)-1)==covered[i]
    remaining=[0]*len(pool)
    for i,j in newedges: remaining[i]|=1<<j; remaining[j]|=1<<i
    heap=[(-a.bit_count(),i) for i,a in enumerate(remaining) if a]; heapq.heapify(heap)
    newcliques=[]; t0=time.perf_counter()
    while heap and time.perf_counter()-t0<30:
        degree,i=heapq.heappop(heap)
        if -degree!=remaining[i].bit_count() or not remaining[i]: continue
        choices=remaining[i]; clique=[i]; mask=1<<i
        while choices:
            sample=list(itertools.islice(bits(choices),16))
            j=max(sample,key=lambda v:((adj[v]&choices).bit_count(),-v))
            clique.append(j); mask|=1<<j; choices&=adj[j]
        newcliques.append(sorted(clique))
        for j in clique:
            remaining[j]&=~mask
            if remaining[j]: heapq.heappush(heap,(-remaining[j].bit_count(),j))
    residual=0
    for i,mask in enumerate(remaining):
        for j in bits(mask&~((1<<(i+1))-1)): newcliques.append([i,j]); residual+=1
    for name,records in [('new-conflicts.jsonl.gz',sorted(newedges)),('projected-cliques.jsonl.gz',sorted(set(tuple(c) for c in oldcliques+newcliques)))]:
        with gzip.open(OUT/name,'xt',encoding='utf-8',newline='\n') as f:
            for record in records: f.write(json.dumps(record)+'\n')
    write(OUT/'mapping.json',{**mp,'candidates':[{'candidate':i,'var':vi+4,'compatible_skeletons':ss} for vi,(i,ss) in enumerate(kept.items())],
        'excluded_non_cog_candidates':[i for i,ss in allowed.items() if not ss]})
    # Independent exhaustive same-sheet enumeration of every added pair, with a
    # conservative bounding-box screen and scalar original-vertex distances.
    bounds=np.asarray([g.bounds for g in auditgeoms]); actual=set(); enumerated=0; measured=0
    for j in range(9059,len(pool)):
        ids=np.asarray([i for i in kept if i<j and sheets[i]==sheets[j]])
        enumerated+=len(ids); x0,y0,x1,y1=bounds[j]
        near=(bounds[ids,0]<=x1+.2)&(bounds[ids,2]>=x0-.2)&(bounds[ids,1]<=y1+.2)&(bounds[ids,3]>=y0-.2)
        for i in ids[near]:
            measured+=1
            if auditgeoms[int(i)].distance(auditgeoms[j])<job['clearance']-1e-7: actual.add((int(i),j))
    assert actual==set(newedges)
    coverage=[0]*len(pool)
    for clique in lines(OUT/'projected-cliques.jsonl.gz'):
        mask=sum(1<<i for i in clique)
        for i in clique:
            assert (mask^(1<<i))&~adj[i]==0
            coverage[i]|=mask^(1<<i)
    assert coverage==adj
    write(OUT/'graph-audit.json',{'all_new_pairs_enumerated':enumerated,'independent_distance_checks':measured,'new_conflicts':len(actual),
        'old_clique_coverage_exact':True,'complete_clique_coverage_exact':True,'no_false_conflicts':True,
        'cliques':sum(1 for _ in lines(OUT/'projected-cliques.jsonl.gz')),'residual_pair_constraints':residual,
        'construction_direct_distances':directchecks,'seconds':time.perf_counter()-started,
        'new_conflicts_sha256':digest(OUT/'new-conflicts.jsonl.gz'),'cliques_sha256':digest(OUT/'projected-cliques.jsonl.gz')})
    print(json.dumps(load(OUT/'graph-audit.json')),flush=True)

if __name__=='__main__': main()
