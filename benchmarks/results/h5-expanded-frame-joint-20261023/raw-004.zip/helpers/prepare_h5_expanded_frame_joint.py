"""Prepare a fresh 29-frame-group joint model, preserving all prior artifacts."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def put(name,s):
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
s=(ROOT/'output/build_h5_latest_wide_joint.py').read_text()
s=replace(s,'h5-latest-wide-pool-coverage-20261023','h5-expanded-frame-group-coverage-20261023')
s=replace(s,'h5-latest-wide-joint-20261023','h5-expanded-frame-joint-20261023')
s=replace(s,"'filter.json'","'group-filter.json'")
s=replace(s,'Fix only the exact 18 wide frames. Recompute every mutual cog/bracket/insert conflict from the complete 21,468-pose freshly filtered pool, preserving every source pose and both checked seeds.','Choose exactly one of the 29 checked complete 18-frame groups. Recompute every mutual cog/bracket/insert conflict from all 29,631 eligible poses, preserving the exact 64-part seed in group 26. Use independently checked per-pose group compatibility. All small families move together.')
s=replace(s,'Fresh adjacent same-family substitution only when N(replacement) minus removed is contained in N(removed). Certify every original neighbor and map both exact seeds.','Fresh adjacent same-family substitution only when N(replacement) minus removed is contained in N(removed), and replacement allows every frame group allowed by removed. Certify every original neighbor and compatible group, and map the exact 64-part seed.')
s=replace(s,"'hint_cases':416","'hint_cases':1508")
s=replace(s,'Compare 52 deterministic family/order/sheet choices for each of eight starts: both mapped seeds, and each seed with one of three non-frame families removed. Retain the highest original-area seed if no completion improves it. No prior hint or reduction is reused.','Compare 52 deterministic family/order/sheet choices for each of 29 frame groups, starting empty. Preserve the mapped 64-part seed if no fresh hint improves its original filled area. No prior reduction, graph or solver is reused.')
s=replace(s,'with exact fixed frames','with exactly one compatible complete frame group')
s=replace(s,";seed=max(mp['seeds'],key=lambda r:r['filled_area_mm2'])",'')
s=replace(s,"write(OUT/'mapping.json',{**mp,'seed_candidates':sorted(set(seed['selected_indices'])-set(mp['fixed_candidates'])),'new_candidates':[]})","write(OUT/'mapping.json',{**mp,'seed_candidates':sorted(set(mp['seed_indices'])-set(mp['frame_groups'][mp['seed_group']]['candidates'])),'new_candidates':[]})")
put('build_h5_expanded_frame_joint.py',s)
s=(ROOT/'output/reduce_h5_latest_wide_joint.py').read_text()
s=replace(s,'build_h5_latest_wide_joint','build_h5_expanded_frame_joint')
s=replace(s,'N(a) minus b contained in N(b).','N(a) minus b contained in N(b), and compatible-groups(b) a subset of compatible-groups(a).')
s=replace(s,'map both original seeds','map the exact original 64-part seed')
s=replace(s,"adj=read_graph(BASE/'adjacency.bin.gz',len(ids));local=","adj=read_graph(BASE/'adjacency.bin.gz',len(ids));allowed=[sum(1<<g for g in groups) for groups in mp['compatible_groups']];local=")
s=replace(s,"if (adj[b]>>a)&1 and not(adj[a]&~(adj[b]|(1<<b))):","if (adj[b]>>a)&1 and not(allowed[b]&~allowed[a]) and not(adj[a]&~(adj[b]|(1<<b))):")
s=replace(s,"replacements={r['removed']:r['replacement'] for r in removed};certificate=0","replacements={r['removed']:r['replacement'] for r in removed};certificate=groupcert=0")
s=replace(s,"for j in bits(adj[a]):","for g in mp['compatible_groups'][b]:\n            groupcert+=1;assert g in mp['compatible_groups'][a]\n        for j in bits(adj[a]):")
start=s.index("    area=load(ROOT/")
end=s.index('    remaining=projected.copy()',start)
s=s[:start]+'''    area=mp['area_weights'];seed_group=mp['seed_group'];fixed=mp['frame_groups'][seed_group]['candidates']
    original_small=sorted(set(mp['seed_indices'])-set(fixed));small=sorted(replacements.get(i,i) for i in original_small)
    chosen=[newlocal[i] for i in small];mask=sum(1<<j for j in chosen);counts=Counter(pool[i]['placement']['part_id'] for i in small)
    assert len(chosen)==46 and len(set(chosen))==46 and counts==Counter({'bracket':10,'cog':15,'insert':21})
    assert all(not(projected[j]&mask) for j in chosen) and all(seed_group in mp['compatible_groups'][local[i]] for i in small)
    best={'source':'mapped-original-64','frame_group':seed_group,'selected_small_candidates':small,'counts':dict(counts),'objective':sum(area[pool[i]['placement']['part_id']] for i in small)}
    assert best['objective']==1566740785
    write(OUT/'mapping.json',{**mp,'candidates':globals_kept,'compatible_groups':[mp['compatible_groups'][j] for j in kept],'seed_candidates':small,'mapped_seeds':[best]});write(OUT/'best-hint.json',best);write(OUT/'substitutions.json',removed)
''' +s[end:]
s=replace(s,"'both_seed_counts_and_full_graph_checked':True","'exact_64_seed_counts_group_and_full_graph_checked':True,'compatible_group_memberships_independently_certified':groupcert")
put('reduce_h5_expanded_frame_joint.py',s)
s=(ROOT/'output/seed_h5_latest_wide_joint.py').read_text()
s=replace(s,'build_h5_latest_wide_joint','build_h5_expanded_frame_joint')
s=replace(s,"weights=load(ROOT/'output/h5-group-choice-20261023/mapping.json')['area_weights']","weights=mp['area_weights']")
start=s.index('    starts=[');end=s.index('    inputs=[',start)
s=s[:start]+'''    cases=[(g,d,o) for g in range(len(mp['frame_groups'])) for d,o in orders];assert len(orders)==52 and len(cases)==1508
''' +s[end:]
s=replace(s,"'maximum_cases':416","'maximum_cases':1508")
s=replace(s,"'starts':starts","'frame_groups':list(range(len(mp['frame_groups'])))")
s=replace(s,'For both newly mapped original seeds, retain all small poses or remove each one of three families in turn.','Start empty for each of the 29 complete frame groups, respecting every small pose\'s compatible groups.')
s=replace(s,'This is a fresh bounded relocation census','This is a fresh bounded group-choice census')
s=replace(s,"for initial,description,order in cases:","for group,description,order in cases:")
s=replace(s,"chosen=initial['indices'].copy();counts=Counter(family[j] for j in chosen);mask=sum(1<<j for j in chosen)","chosen=[];counts=Counter();mask=0")
s=replace(s,"if counts[family[j]]>=caps[family[j]] or (mask>>j)&1 or adj[j]&mask:continue","if group not in mp['compatible_groups'][j] or counts[family[j]]>=caps[family[j]] or (mask>>j)&1 or adj[j]&mask:continue")
s=replace(s,"'source':'fresh-family-relocation','source_seed':initial['source_seed'],'remove_family':initial['remove_family']","'source':'fresh-frame-group-choice','frame_group':group")
s=replace(s,"assert len(chosen)==len(set(chosen))", "assert all(r['frame_group'] in mp['compatible_groups'][j] for j in chosen)\n        assert len(chosen)==len(set(chosen))")
s=replace(s,"[{'source_seed':s['source_seed'],'remove_family':s['remove_family'],'ordering':d} for s,d,o in cases[len(hints):]]","[{'frame_group':g,'ordering':d} for g,d,o in cases[len(hints):]]")
s=replace(s,"'planned_cases':416","'planned_cases':1508")
s=replace(s,"'pending_cases':416-len(hints)","'pending_cases':1508-len(hints)")
s=replace(s,"'every_result_full_graph_counts_score_checked'","'every_result_full_graph_group_counts_score_checked'")
# The method string above is single-quoted Python source.
s=replace(s,"pose's compatible groups.","pose compatible groups.")
put('seed_h5_expanded_frame_joint.py',s)
print('Prepared new graph, safe group-preserving reduction and bounded hints.')
