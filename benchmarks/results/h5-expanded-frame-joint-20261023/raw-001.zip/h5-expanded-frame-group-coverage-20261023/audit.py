"""Fresh frame-group compatibility over the complete accumulated pose pool."""
from collections import Counter
from datetime import datetime,timezone
from itertools import combinations
import copy,math,shutil,time
import numpy as np
import shapely
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_reflected_core_contacts import ROOT,SRC,OUT as BASE,load,write,digest
OLD=ROOT/'output/h5-group-choice-20261023';CENSUS=ROOT/'output/h5-whole-frame-census-20261020'
WIDE=ROOT/'output/h5-latest-wide-joint-20261023';OUT=ROOT/'output/h5-expanded-frame-group-coverage-20261023'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    layouts=[WIDE/'layout-audit/layout-final.json',ROOT/'output/h5-tall-frame-cog-subassembly-20261023/layout.json',ROOT/'output/h5-mixed-frame-cog-subassembly-20261023/layout.json']
    inputs=[BASE/n for n in ['candidates.json','audit/checks.json','layout-audit/checks.json']]+[CENSUS/'groups.json',OLD/'mapping.json',OLD/'graph-audit/checks.json',SRC/'candidates.json',SRC/'job.json',SRC/'conditional-target.json',WIDE/'mapping.json',WIDE/'layout-audit/checks.json']+layouts
    assert all(load(p)['passed'] for p in [BASE/'audit/checks.json',BASE/'layout-audit/checks.json',OLD/'graph-audit/checks.json',WIDE/'layout-audit/checks.json'])
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Preserve the complete current pose pool and exact old source prefix. Retain all 26 previously audited whole 18-frame sets, then append any distinct complete frame sets from the new wide, tall and mixed constructions by exact pose identity. Recheck every frame group, every original allowed transform and stock bound. Compute every small-pose/frame conflict using expanded original bounds and exact filled-outer distance, then derive compatibility with each entire frame group. Independently verify every membership by distance to the union of that group\'s 18 original polygons. Check that all earlier group-choice and latest wide-only candidates remain, and map the current 64-part seed exactly. No mutual small-pose graph, new geometry, contact generation or solver call occurs. A subsequent changed group-choice model still requires a fresh full graph, compatibility-preserving reduction and complete model/layout audits.', 'new_poses_generated':0,'solver_calls':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();pool=load(BASE/'candidates.json');oldpool=load(SRC/'candidates.json');assert pool[:len(oldpool)]==oldpool
    keys={identity(p['placement']):i for i,p in enumerate(pool)};groups=copy.deepcopy(load(CENSUS/'groups.json'));assert len(groups)==26 and [g['index'] for g in groups]==list(range(26));groupkeys={tuple(g['candidates']):g['index'] for g in groups};newsets=[]
    for path in layouts:
        ids=[]
        for p in load(path)['placements']:
            if p['part_id']!='frame':continue
            p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert pool[i]['placement']==p;ids.append(i)
        ids=sorted(ids);assert len(ids)==len(set(ids))==18;k=tuple(ids)
        if k not in groupkeys:groupkeys[k]=len(groups);groups.append({'index':len(groups),'candidates':ids,'sources':[path.relative_to(ROOT).as_posix()]})
        newsets.append({'source':path.relative_to(ROOT).as_posix(),'group':groupkeys[k]})
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];target=load(SRC/'conditional-target.json');gs=np.asarray([shape(parts[p['placement']['part_id']],p['placement']['transform']) for p in pool],dtype=object);bb=shapely.bounds(gs);sheets=np.asarray([p['placement']['sheet_id'] for p in pool])
    frames=sorted({i for g in groups for i in g['candidates']});small=[i for i,p in enumerate(pool) if p['placement']['part_id']!='frame'];framepairs=0;minimum=math.inf
    for i in frames+small:
        p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform'];a,b,c,d=bb[i];h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert gs[i].is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
    for group in groups:
        assert Counter(pool[i]['placement']['part_id'] for i in group['candidates'])==Counter(frame=18)
        for i,j in combinations(group['candidates'],2):
            if sheets[i]!=sheets[j]:continue
            framepairs+=1;d=gs[i].distance(gs[j]);minimum=min(minimum,d);assert gs[i].disjoint(gs[j]) and d>=clear-1e-7
    framearr=np.asarray(frames);filters=[];near=possible=0
    for i in small:
        js=framearr[sheets[framearr]==sheets[i]];possible+=len(js);dx=np.maximum(0,np.maximum(bb[js,0]-bb[i,2],bb[i,0]-bb[js,2]));dy=np.maximum(0,np.maximum(bb[js,1]-bb[i,3],bb[i,1]-bb[js,3]));js=js[np.hypot(dx,dy)<=clear+1e-7];near+=len(js);blocked=set(map(int,js[shapely.distance(gs[i],gs[js])<clear-1e-7]));compatible=[g['index'] for g in groups if blocked.isdisjoint(g['candidates'])]
        filters.append({'candidate':i,'frame_blockers':sorted(blocked),'compatible_groups':compatible})
    memberships=0;union_distances=0;sg=gs[small];ss=sheets[small]
    for group in groups:
        eligible=np.ones(len(small),dtype=bool)
        for sheet in ['sheet-0','sheet-1']:
            ff=[gs[i] for i in group['candidates'] if sheets[i]==sheet];indices=np.flatnonzero(ss==sheet)
            if ff:union=unary_union(ff);eligible[indices]=shapely.distance(sg[indices],union)>=clear-1e-7;union_distances+=len(indices)
        for r,ok in zip(filters,eligible):assert (group['index'] in r['compatible_groups'])==bool(ok);memberships+=1
    chosen=[r for r in filters if r['compatible_groups']];ids=[r['candidate'] for r in chosen];oldids=set(load(OLD/'mapping.json')['candidates']);wideids=set(load(WIDE/'mapping.json')['candidates']);assert oldids<=set(ids) and wideids<=set(ids)
    seed=[]
    for p in load(layouts[0])['placements']:seed.append(keys[identity(p)])
    seed=sorted(seed);seedframes=tuple(i for i in seed if pool[i]['placement']['part_id']=='frame');seedgroup=groupkeys[seedframes];compatible={r['candidate']:r['compatible_groups'] for r in chosen};assert len(seed)==64 and all(seedgroup in compatible[i] for i in seed if i not in seedframes)
    for i,j in combinations(seed,2):
        if sheets[i]==sheets[j]:assert gs[i].disjoint(gs[j]) and gs[i].distance(gs[j])>=clear-1e-7
    write(OUT/'groups.json',groups);write(OUT/'group-filter.json',filters);write(OUT/'mapping.json',{'source_pool':(BASE/'candidates.json').relative_to(ROOT).as_posix(),'candidates':ids,'compatible_groups':[r['compatible_groups'] for r in chosen],'frame_groups':groups,'seed_group':seedgroup,'seed_indices':seed,'area_weights':load(OLD/'mapping.json')['area_weights']})
    counts=lambda values:dict(Counter(pool[i]['placement']['part_id'] for i in values))
    check={'passed':True,'seconds':time.perf_counter()-start,'complete_pool_size':len(pool),'old_prefix_size':len(oldpool),'old_prefix_exact':True,'whole_frame_groups':len(groups),'new_frame_set_sources':newsets,'unique_frame_poses':len(frames),'within_group_frame_pairs':framepairs,'minimum_frame_gap_mm':minimum,'small_frame_pair_possibilities':possible,'small_frame_exact_distances':near,'union_distances':union_distances,'group_memberships_independently_verified':memberships,'retained_small_candidates':len(ids),'retained_by_family':counts(ids),'old_group_model_choices_preserved':len(oldids),'latest_wide_model_choices_preserved':len(wideids),'additional_to_old_group_model':len(set(ids)-oldids),'additional_to_latest_wide_model':len(set(ids)-wideids),'seed_group':seedgroup,'seed_count':64,'seed_geometry_and_compatibility_checked':True,'complete_mutual_graph_pending':True,'solver_calls':0,'new_poses_generated':0,'native_margin_qualified':False}
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
