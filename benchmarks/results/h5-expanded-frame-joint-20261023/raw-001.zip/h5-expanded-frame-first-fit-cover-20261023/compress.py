"""Fresh cheaper complete clique cover; no solver or continuation of old compression."""
from datetime import datetime,timezone
import gzip,heapq,json,shutil,time
from build_h5_expanded_frame_joint import ROOT,OUT as BASE,load,write,digest,read_graph
from build_h5_group_choice import save_rows
from census_h5_one_part_moves import bits
RED=BASE/'reduced';OUT=ROOT/'output/h5-expanded-frame-first-fit-cover-20261023'
def main():
    assert load(RED/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'compress.py')
    inputs=[RED/n for n in ['mapping.json','adjacency.bin.gz','checks.json','cliques.jsonl.gz']]+[ROOT/'output/h5-expanded-frame-implications-20261023'/n for n in ['plan.json','solve/result.json','solve/solver.log','solve/encoding-audit.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'compression_seconds':20,'method':'Start afresh from the complete audited reduced graph. Pop the highest remaining degree endpoint, then grow a valid clique using the least-index available common neighbor directly. Unlike the earlier greedy cover, do not score 16 alternatives at every extension. This changes the compression algorithm under the same 20-second allowance, rather than extending or resuming the earlier cover. Retain every residual edge. Independently reconstruct the entire original graph from the saved cover and validate the existing complete hint. No geometry generation, reduction, solver or production call occurs. Any later solve needs a separately declared changed-model plan and full protobuf reconstruction.','reason':'Both separate-edge and grouped-implication encodings return UNKNOWN before search; grouping syntax alone does not reduce the millions of underlying literals. A faster true clique cover may reduce them without weakening the graph.','solver_calls':0,'new_poses_generated':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    mp=load(RED/'mapping.json');adj=read_graph(RED/'adjacency.bin.gz',len(mp['candidates']));remaining=adj.copy();heap=[(-v.bit_count(),i) for i,v in enumerate(adj) if v];heapq.heapify(heap);cliques=[];covered=0;start=time.perf_counter()
    while heap and time.perf_counter()-start<20:
        degree,i=heapq.heappop(heap)
        if -degree!=remaining[i].bit_count() or not remaining[i]:continue
        choices=remaining[i];c=[i];mask=1<<i
        while choices:
            bit=choices&-choices;j=bit.bit_length()-1;c.append(j);mask|=bit;choices&=adj[j]
        assert all(not((mask^(1<<j))&~adj[j]) for j in c);cliques.append(sorted(c))
        for j in c:
            before=remaining[j].bit_count();remaining[j]&=~mask;covered+=before-remaining[j].bit_count()
            if remaining[j]:heapq.heappush(heap,(-remaining[j].bit_count(),j))
    elapsed=time.perf_counter()-start;residual=sum(v.bit_count() for v in remaining)//2;edges=sum(v.bit_count() for v in adj)//2;assert covered//2+residual==edges
    def rows():
        yield from cliques
        for i,v in enumerate(remaining):
            for j in bits(v&~((1<<(i+1))-1)):yield [i,j]
    save_rows(OUT/'cliques.jsonl.gz',rows());reconstructed=[0]*len(adj);rowcount=literalcount=0;hint=set(load(BASE/'hints/best-hint.json')['selected_small_candidates']);h=[int(i in hint) for i in mp['candidates']]
    with gzip.open(OUT/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            c=json.loads(line);assert c==sorted(set(c));mask=sum(1<<j for j in c);rowcount+=1;literalcount+=len(c);assert sum(h[j] for j in c)<=1
            for j in c:other=mask^(1<<j);assert not(other&~adj[j]);reconstructed[j]|=other
    assert reconstructed==adj and rowcount==len(cliques)+residual
    check={'passed':True,'compression_seconds':elapsed,'limit_reached':bool(heap),'original_candidates':len(adj),'original_edges':edges,'cliques':len(cliques),'residual_edges':residual,'total_constraints':rowcount,'total_literals':literalcount,'every_original_edge_independently_reconstructed':True,'original_64_hint_satisfies_all_constraints':True,'prior_cover_constraints':load(RED/'checks.json')['projected_cliques'],'source_graph_sha256':digest(RED/'adjacency.bin.gz'),'constraints_sha256':digest(OUT/'cliques.jsonl.gz'),'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False}
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
