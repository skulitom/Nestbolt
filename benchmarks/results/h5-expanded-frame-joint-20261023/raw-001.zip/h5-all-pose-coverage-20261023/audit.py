"""Check whether relaxing whole-frame-set selection exposes genuinely additional choices."""
from collections import Counter
from datetime import datetime,timezone
from itertools import combinations,product
import copy,math,shutil,time
from shapely.geometry import Polygon
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_expanded_frame_joint import ROOT,SRC,OUT as BASE,load,write,digest
OUT=ROOT/'output/h5-all-pose-coverage-20261023'
CURRENT=ROOT/'output/h5-expanded-frame-implications-20261023'

def main():
    audit=load(CURRENT/'layout-audit/checks.json');assert audit['passed'] and not audit['full_target_witness']
    best=max(audit['records'],key=lambda r:r['filled_area_mm2']);seedpath=CURRENT/'layout-audit'/f"layout-{best['incumbent']}.json"
    original=ROOT/'output/h5-latest-wide-joint-20261023/layout-audit/layout-final.json'
    # Preserve the original 64-part pose identity when a tie does not improve it.
    if best['filled_area_mm2']<=4401740.784069743+1e-6:seedpath=original
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');inputs=[BASE/n for n in ['plan.json','candidates.json','mapping.json','audit/checks.json','solve/model-audit.json','solve/result.json','layout-audit/checks.json']]+[CURRENT/n for n in ['plan.json','solve/encoding-audit.json','solve/model-audit.json','solve/result.json','layout-audit/checks.json']]+[SRC/'job.json',SRC/'conditional-target.json',seedpath]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Audit every pose in the complete accumulated source pool directly from original vertices, permitted transforms and target stock bounds. Do not require a whole frame group. Preserve every source entry and record any ineligible poses explicitly. Map the best original partial by exact pose identity and check all its geometry. Compare coverage with the just-completed 29-group model and count frame poses absent from its groups. Independently check integer filled-area ordering for all original 19*13*16*22 count combinations. This coverage audit does not build the enlarged mutual graph, make new poses, prove capacity or run a solver. A future model would allow each original frame pose individually under the original 18-frame cap, with all three smaller families free, requiring a fresh full graph and four-family reduction.','solver_calls':0,'new_poses_generated':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();pool=load(BASE/'candidates.json');mp=load(BASE/'mapping.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json');geoms={};filters=[];maxdistance=maxarea=0.
    for i,row in enumerate(pool):
        p=row['placement'];part=parts[p['part_id']];t=p['transform'];angle=t['rotation_radians'];c,s=math.cos(angle),math.sin(angle);mirror=-1 if t['mirrored'] else 1;x,y=t['translation']
        g=Polygon([(mirror*a*c-b*s+x,mirror*a*s+b*c+y) for a,b in part['geometry'][0]['outer']]);reference=shape(part,t);error=g.hausdorff_distance(reference);area=g.symmetric_difference(reference).area
        maxdistance=max(maxdistance,error);maxarea=max(maxarea,area);assert error<=1e-8 and area<=1e-6
        reasons=[]
        if not g.is_valid:reasons.append('invalid_geometry')
        if t['mirrored'] and not part['allow_mirror']:reasons.append('forbidden_mirror')
        if part['rotations']['kind']=='list' and not any(abs(math.remainder(angle-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees']):reasons.append('forbidden_rotation')
        if p['sheet_id'] not in ['sheet-0','sheet-1']:reasons.append('unknown_sheet')
        a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        if not(a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7):reasons.append('outside_original_target_stock')
        filters.append({'candidate':i,'accepted':not reasons,'reasons':reasons});geoms[i]=g
    ids=[r['candidate'] for r in filters if r['accepted']];old=set(mp['candidates']);frameids={i for g in mp['frame_groups'] for i in g['candidates']};assert old|frameids<=set(ids)
    keys={identity(p['placement']):i for i,p in enumerate(pool)};seed=[]
    for p in load(seedpath)['placements']:
        p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert pool[i]['placement']==p and i in ids;seed.append(i)
    assert len(seed)==len(set(seed));counts=Counter(pool[i]['placement']['part_id'] for i in seed);assert counts['frame']==18 and sum(counts.values())>=64
    pairs=0;minimum=math.inf
    for i,j in combinations(seed,2):
        if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
        pairs+=1;d=geoms[i].distance(geoms[j]);minimum=min(minimum,d);assert geoms[i].disjoint(geoms[j]) and d>=job['clearance']-1e-7
    families=['frame','bracket','cog','insert'];areas=[Polygon(parts[f]['geometry'][0]['outer']).area for f in families];weights=[round(a*1000) for a in areas];combinations_count=list(product(*(range(parts[f]['quantity']+1) for f in families)))
    assert len(combinations_count)==86944
    assert sorted(combinations_count,key=lambda c:sum(n*a for n,a in zip(c,areas)))==sorted(combinations_count,key=lambda c:sum(n*w for n,w in zip(c,weights)))
    area_weights=dict(zip(families,weights));write(OUT/'filter.json',filters);write(OUT/'mapping.json',{'source_pool':(BASE/'candidates.json').relative_to(ROOT).as_posix(),'candidates':ids,'seed_indices':sorted(seed),'seed_source':seedpath.relative_to(ROOT).as_posix(),'seed_source_sha256':digest(seedpath),'area_weights':area_weights,'family_caps':{f:parts[f]['quantity'] for f in families}})
    check={'passed':True,'seconds':time.perf_counter()-start,'complete_source_pool':len(pool),'every_original_pose_directly_reconstructed':True,'maximum_reconstruction_distance_mm':maxdistance,'maximum_reconstruction_area_mm2':maxarea,'eligible_candidates':len(ids),'rejected_candidates':len(pool)-len(ids),'eligible_by_family':dict(Counter(pool[i]['placement']['part_id'] for i in ids)),'previous_group_model_small_choices_preserved':len(old),'previous_group_frame_choices_preserved':len(frameids),'additional_individual_frame_choices':sum(pool[i]['placement']['part_id']=='frame' for i in ids if i not in frameids),'additional_small_choices':sum(pool[i]['placement']['part_id']!='frame' for i in ids if i not in old),'seed_counts':dict(counts),'seed_same_sheet_pairs':pairs,'seed_minimum_gap_mm':minimum,'integer_objective_orders_all_original_count_combinations':len(combinations_count),'complete_mutual_graph_pending':True,'solver_calls':0,'new_poses_generated':0,'native_margin_qualified':False}
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
