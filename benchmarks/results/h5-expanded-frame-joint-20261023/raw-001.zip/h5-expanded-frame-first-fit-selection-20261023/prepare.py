"""Declare one changed exact-cover model after both preserved presolve-only outcomes."""
from datetime import datetime,timezone
import shutil
from build_h5_expanded_frame_joint import ROOT,OUT as BASE,load,write,digest
FIRST=ROOT/'output/h5-expanded-frame-first-fit-cover-20261023'
PRIOR=ROOT/'output/h5-expanded-frame-implications-20261023'
OUT=ROOT/'output/h5-expanded-frame-first-fit-selection-20261023'
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
def put(name,s):
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def main():
    check=load(FIRST/'checks.json');assert check['passed'] and check['total_constraints']<check['prior_cover_constraints']/2 and check['residual_edges']==5257882
    assert load(PRIOR/'solve/result.json')['status']=='UNKNOWN'
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');inputs=[FIRST/n for n in ['plan.json','checks.json','cliques.jsonl.gz']]+[BASE/n for n in ['audit/checks.json','reduced/mapping.json','reduced/adjacency.bin.gz','reduced/checks.json','hints/best-hint.json','hints/checks.json']]+[PRIOR/n for n in ['plan.json','solve/result.json','solve/solver.log','layout-audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'reason':'The new first-fit algorithm uses the same 20-second compression allowance, reducing residual pairs from 12,129,254 to 5,257,882 and total cover literals to 12,144,883. Full graph reconstruction proves no edge added or omitted. This substantially changes the constraint workload rather than only its syntax. Compile the new larger cliques plus endpoint-aggregated residual implications, independently reconstruct all original edges and every protobuf field, and make one new bounded call. Preserve both previous UNKNOWN outcomes, the 73.635-second soft overrun, and all capped work. Do not increase any search allowance or change original geometry, quotas, objective, complete hint or group memberships.','solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'new_poses_generated':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    s=(ROOT/'output/solve_h5_expanded_frame_implications.py').read_text()
    s=replace(s,"OUT=ROOT/'output/h5-expanded-frame-implications-20261023/solve'","FIRST=ROOT/'output/h5-expanded-frame-first-fit-cover-20261023';OUT=ROOT/'output/h5-expanded-frame-first-fit-selection-20261023/solve'")
    s=replace(s,"RED/'cliques.jsonl.gz'","FIRST/'cliques.jsonl.gz'")
    put('solve_h5_expanded_frame_first_fit.py',s)
    s=(ROOT/'output/audit_h5_expanded_frame_implication_layouts.py').read_text()
    s=replace(s,"OUT=ROOT/'output/h5-expanded-frame-implications-20261023'","OUT=ROOT/'output/h5-expanded-frame-first-fit-selection-20261023'")
    s=replace(s,"old=ROOT/'output/h5-latest-wide-joint-20261023/layout-audit'","old=ROOT/'output/h5-expanded-frame-joint-20261023/layout-audit'")
    for name in ['layout','public','command']:s=replace(s,f"'{name}-final.json'",f"'{name}-hint.json'")
    put('audit_h5_expanded_frame_first_fit_layouts.py',s)
    print('Prepared one new first-fit-cover selection, keeping the original graph and all prior outcomes.')
if __name__=='__main__':main()
