"""One explicitly changed search strategy after three presolve-only outcomes."""
from datetime import datetime,timezone
import shutil
from build_h5_expanded_frame_joint import ROOT,load,write,digest
PRIOR=ROOT/'output/h5-expanded-frame-first-fit-selection-20261023'
OUT=ROOT/'output/h5-expanded-frame-direct-search-20261023'
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
def put(name,s):
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def main():
    assert load(PRIOR/'solve/result.json')['status']=='UNKNOWN' and 'Stopped after presolve.' in (PRIOR/'solve/solver.log').read_text()
    assert load(PRIOR/'solve/model-audit.json')['passed'] and load(PRIOR/'layout-audit/checks.json')['passed']
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inherited=load(PRIOR/'plan.json')['inputs'];inputs={**inherited,**{p.relative_to(ROOT).as_posix():digest(p) for p in [PRIOR/n for n in ['plan.json','solve/model.pb','solve/parameters.pbtxt','solve/result.json','solve/solver.log','solve/model-audit.json','layout-audit/checks.json']]}}
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'reason':'All three preceding encodings stopped after presolve without a search branch or incumbent. Keep the entire latest first-fit model byte-identical, independently reconstructed and fully geometry-audited, but change the search strategy explicitly by disabling CP model presolve. The same 60-second allowance can then reach search instead of repeating the observed preprocessing failure. This is one declared parameter intervention, not an unchanged retry or extension; all prior outcomes and overruns remain. Do not change any candidate, constraint, hint, objective, quota, group membership or geometry.','parameter_change':{'cp_model_presolve':False},'solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'new_poses_generated':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    s=(ROOT/'output/solve_h5_expanded_frame_first_fit.py').read_text()
    s=replace(s,"OUT=ROOT/'output/h5-expanded-frame-first-fit-selection-20261023/solve'","OUT=ROOT/'output/h5-expanded-frame-direct-search-20261023/solve'")
    s=replace(s,"    solver.parameters.log_search_progress=True;", "    solver.parameters.cp_model_presolve=False\n    assert digest(OUT/'model.pb')==digest(ROOT/'output/h5-expanded-frame-first-fit-selection-20261023/solve/model.pb')\n    solver.parameters.log_search_progress=True;")
    s=replace(s,"'complete_seed_verified':True,","'complete_seed_verified':True,'byte_identical_previous_model':True,'cp_model_presolve':False,")
    put('solve_h5_expanded_frame_direct.py',s)
    s=(ROOT/'output/audit_h5_expanded_frame_first_fit_layouts.py').read_text()
    s=replace(s,"OUT=ROOT/'output/h5-expanded-frame-first-fit-selection-20261023'","OUT=ROOT/'output/h5-expanded-frame-direct-search-20261023'")
    put('audit_h5_expanded_frame_direct_layouts.py',s)
    print('Prepared one explicit no-presolve strategy intervention with identical audited model and allowance.')
if __name__=='__main__':main()
