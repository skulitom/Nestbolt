"""Verify the explicit strategy intervention changes only CP model presolve."""
from pathlib import Path
from hashlib import sha256
import json,shutil
from google.protobuf import text_format
from ortools.sat import sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-expanded-frame-first-fit-selection-20261023/solve';OUT=ROOT/'output/h5-expanded-frame-direct-search-20261023'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
old=text_format.Parse((OLD/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
current=text_format.Parse((OUT/'solve/parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
expected=sat_parameters_pb2.SatParameters();expected.CopyFrom(old);expected.cp_model_presolve=False
assert current.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
assert current.max_time_in_seconds==60 and current.num_search_workers==8 and current.random_seed==0
assert digest(OLD/'model.pb')==digest(OUT/'solve/model.pb')
shutil.copyfile(__file__,OUT/'parameter-audit.py')
with (OUT/'parameter-delta-audit.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'passed':True,'model_byte_identical':True,'only_parameter_change':{'cp_model_presolve':False},'maximum_seconds':60,'workers':8,'random_seed':0,'source_model_sha256':digest(OLD/'model.pb'),'previous_parameters_sha256':digest(OLD/'parameters.pbtxt'),'current_parameters_sha256':digest(OUT/'solve/parameters.pbtxt')},f,indent=2);f.write('\n')
print('Exact model identity and single-parameter change verified.')
