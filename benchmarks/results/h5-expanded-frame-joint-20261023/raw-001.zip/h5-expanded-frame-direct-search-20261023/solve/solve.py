"""One 60-second joint small-family selection for the wider frame group; independently reconstruct the whole model."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
from hashlib import sha256
import gc,gzip,json,shutil,time,sys,ortools
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-expanded-frame-joint-20261023';RED=BASE/'reduced';HINT=BASE/'hints';FIRST=ROOT/'output/h5-expanded-frame-first-fit-cover-20261023';OUT=ROOT/'output/h5-expanded-frame-direct-search-20261023/solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(RED/'checks.json')['passed'] and load(HINT/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    pool=load(BASE/'candidates.json');mp=load(RED/'mapping.json');ids=mp['candidates'];n=len(ids);ng=len(mp['frame_groups'])
    def bits(mask):
        while mask:
            bit=mask&-mask;yield bit.bit_length()-1;mask^=bit
    def read_graph(path,n):
        width=(n+7)//8;result=[]
        with gzip.open(path,'rb') as f:
            for _ in range(n):
                data=f.read(width);assert len(data)==width;result.append(int.from_bytes(data,'little'))
            assert f.read(1)==b''
        return result
    compact_plan=load(OUT.parent/'plan.json')
    for p,h in compact_plan['inputs'].items():assert digest(ROOT/p)==h
    rows=[];forward=[0]*n;pair_rows=0
    with gzip.open(FIRST/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);assert len(row)>=2 and row==sorted(set(row)) and 0<=row[0]<=row[-1]<n
            if len(row)==2:i,j=row;forward[i]|=1<<j;pair_rows+=1
            else:rows.append(row)
    original_graph=read_graph(RED/'adjacency.bin.gz',n);reconstructed=[0]*n
    for row in rows:
        mask=sum(1<<j for j in row)
        for j in row:reconstructed[j]|=mask^(1<<j)
    for i,mask in enumerate(forward):
        assert not(mask&((1<<(i+1))-1));reconstructed[i]|=mask
        for j in bits(mask):reconstructed[j]|=1<<i
    assert reconstructed==original_graph and pair_rows==sum(m.bit_count() for m in forward)
    write(OUT/'encoding-audit.json',{'passed':True,'original_pair_rows':pair_rows,'retained_larger_cliques':len(rows),'implication_rows':sum(bool(v) for v in forward),'complete_original_graph_reconstructed':True,'edges':sum(v.bit_count() for v in reconstructed)//2,'original_graph_sha256':digest(RED/'adjacency.bin.gz'),'original_constraints_sha256':digest(FIRST/'cliques.jsonl.gz')})
    del reconstructed,original_graph
    area=mp['area_weights'];caps={'bracket':12,'cog':15,'insert':21}
    assert load(BASE/'audit/checks.json')['integer_objective_orders_all_original_count_combinations']==4576
    families={f:[j for j,i in enumerate(ids) if pool[i]['placement']['part_id']==f] for f in caps}
    weights=[area[pool[i]['placement']['part_id']] for i in ids];best=load(HINT/'best-hint.json');seed_ids=set(best['selected_small_candidates']);hint=[int(i in seed_ids) for i in ids]+[int(g==best['frame_group']) for g in range(ng)]
    low=sum(w*v for w,v in zip(weights,hint));high=sum(area[f]*caps[f] for f in caps)
    model=cp_model.CpModel();variables=[model.new_bool_var(f'p{i}') for i in ids]+[model.new_bool_var(f'group{g}') for g in range(ng)]
    for row in rows:model.add_at_most_one(variables[j] for j in row)
    for i,mask in enumerate(forward):
        if mask:model.add_bool_and(variables[j].Not() for j in bits(mask)).only_enforce_if(variables[i])
    model.add_exactly_one(variables[n:])
    for j,compatible in enumerate(mp['compatible_groups']):model.add_bool_or([variables[j].Not()]+[variables[n+g] for g in compatible])
    for f,js in families.items():model.add_linear_constraint(sum(variables[j] for j in js),0,caps[f])
    expr=sum(weights[j]*variables[j] for j in range(n));model.add_linear_constraint(expr,low,high);model.maximize(expr)
    for j,v in enumerate(hint):model.add_hint(variables[j],v)
    assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'))
    expected=cp_model_pb2.CpModelProto()
    for name in [f'p{i}' for i in ids]+[f'group{g}' for g in range(ng)]:v=expected.variables.add();v.name=name;v.domain.extend([0,1])
    for row in rows:expected.constraints.add().at_most_one.literals.extend(row)
    for i,mask in enumerate(forward):
        if mask:
            c=expected.constraints.add();c.enforcement_literal.append(i);c.bool_and.literals.extend(-j-1 for j in bits(mask))
    expected.constraints.add().exactly_one.literals.extend(range(n,n+ng))
    for j,compatible in enumerate(mp['compatible_groups']):expected.constraints.add().bool_or.literals.extend([-j-1]+[n+g for g in compatible])
    for f,js in families.items():
        c=expected.constraints.add().linear;c.vars.extend(js);c.coeffs.extend([1]*len(js));c.domain.extend([0,caps[f]])
    c=expected.constraints.add().linear;c.vars.extend(range(n));c.coeffs.extend(weights);c.domain.extend([low,high])
    expected.objective.vars.extend(range(n));expected.objective.coeffs.extend([-w for w in weights]);expected.objective.scaling_factor=-1
    expected.solution_hint.vars.extend(range(n+ng));expected.solution_hint.values.extend(hint)
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes())
    assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
    assert all(sum(hint[j] for j in row)<=1 for row in rows)
    hintmask=sum(1<<j for j in range(n) if hint[j]);assert all(not hint[i] or not(mask&hintmask) for i,mask in enumerate(forward))
    assert sum(hint[n:])==1 and all(not hint[j] or best['frame_group'] in mp['compatible_groups'][j] for j in range(n))
    assert low==best['objective'] and low>=1566740785 and high==1646740785
    assert {f:sum(hint[j] for j in js) for f,js in families.items()}==load(HINT/'best-hint.json')['counts']
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=60;solver.parameters.num_search_workers=8;solver.parameters.random_seed=0
    solver.parameters.cp_model_presolve=False
    assert digest(OUT/'model.pb')==digest(ROOT/'output/h5-expanded-frame-first-fit-selection-20261023/solve/model.pb')
    solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    write(OUT/'model-audit.json',{'passed':True,'all_protobuf_fields_independently_reconstructed':True,'complete_seed_verified':True,'byte_identical_previous_model':True,'cp_model_presolve':False,
      'variables':n+ng,'small_pose_variables':n,'frame_group_variables':ng,'constraints':len(actual.constraints),'seed_score':low,'full_score':high,
      'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'candidates.json',RED/'mapping.json',FIRST/'cliques.jsonl.gz',RED/'checks.json',RED/'best-hint.json',RED/'adjacency.bin.gz',RED/'substitutions.json',HINT/'best-hint.json',HINT/'checks.json',HINT/'plan.json',BASE/'audit/checks.json',BASE/'plan.json',OUT.parent/'plan.json',OUT/'encoding-audit.json']},
      'model_format':'binary protobuf (installed exporter documents all non-txt suffixes as binary)','ortools_version':ortools.__version__,'python_version':sys.version,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt')})
    records=[]
    def selected(value):
        groups=[g for g in range(ng) if value(variables[n+g])];assert len(groups)==1
        group=groups[0];return group,sorted(mp['frame_groups'][group]['candidates']+[i for j,i in enumerate(ids) if value(variables[j])])
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            group,chosen=selected(self.value);r={'index':len(records),'frame_group':group,'selected_indices':chosen,'counts':dict(Counter(pool[i]['placement']['part_id'] for i in chosen)),
              'seconds':self.wall_time,'objective':self.objective_value,'best_bound':self.best_objective_bound}
            write(OUT/f"incumbent-{r['index']}.json",r);records.append(r);print({k:v for k,v in r.items() if k!='selected_indices'},flush=True)
    # Independent copies are no longer needed after the complete model audit.
    del rows,forward,expected,actual
    gc.collect()
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'seconds_limit':60,'maximum_calls':1})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
        solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());start=time.perf_counter();status=solver.solve(model,Capture());seconds=time.perf_counter()-start
    r={'status':solver.status_name(status),'seconds':seconds,'incumbents':len(records),'best_bound':solver.best_objective_bound,'response_stats':solver.response_stats()}
    if status in [cp_model.FEASIBLE,cp_model.OPTIMAL]:
        group,chosen=selected(solver.value);write(OUT/'selected-indices.json',chosen);r.update(frame_group=group,counts=dict(Counter(pool[i]['placement']['part_id'] for i in chosen)),objective=solver.objective_value)
    write(OUT/'result.json',r);print(r,flush=True)
if __name__=='__main__':main()
