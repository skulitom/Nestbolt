"""Compile a changed, compact exact encoding after the preserved presolve-only result."""
from pathlib import Path
from datetime import datetime,timezone
import json,shutil
from build_h5_expanded_frame_joint import ROOT,OUT as SOURCE,load,write,digest
OUT=ROOT/'output/h5-expanded-frame-implications-20261023'
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)
def put(name,s):
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def main():
    result=load(SOURCE/'solve/result.json');assert result['status']=='UNKNOWN' and result['incumbents']==0
    assert 'Stopped after presolve.' in (SOURCE/'solve/solver.log').read_text()
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[SOURCE/n for n in ['plan.json','candidates.json','audit/checks.json','reduced/mapping.json','reduced/cliques.jsonl.gz','reduced/adjacency.bin.gz','reduced/checks.json','hints/best-hint.json','hints/checks.json','solve/result.json','solve/solver.log','layout-audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'reason':'The preceding exact model spent its single allowance in presolve and returned UNKNOWN with no search or incumbent. Its 12,129,254 residual edges were emitted as separate two-literal at-most-one constraints. The saved presolve log itself aggregates them into Boolean implications. Compile those same constraints directly as one enforced conjunction per lower-index endpoint: x_i implies every higher-index conflicting x_j is false. Retain all larger cliques. This changes the actual encoding before another bounded call; it does not increase the earlier allowance or discard any edge. Independently reconstruct all edge rows and every model field before solving. Original candidate set, group memberships, family caps, objective and complete 64-part hint are identical to the original model.','encoding':'Retain each original row of length >2 as an at-most-one. Aggregate all length-two rows by their lower endpoint into an enforced bool_and of negated upper endpoints. Verify the union of clique and implication edges is exactly the original reduced undirected graph, with no added or missing pair.','solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'new_poses_generated':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    s=(ROOT/'output/solve_h5_expanded_frame_joint.py').read_text()
    s=replace(s,"OUT=BASE/'solve'","OUT=ROOT/'output/h5-expanded-frame-implications-20261023/solve'")
    s=replace(s,"    with gzip.open(RED/'cliques.jsonl.gz','rt',encoding='utf-8') as f:rows=[json.loads(l) for l in f]",'''    from build_h5_expanded_frame_joint import read_graph
    from census_h5_one_part_moves import bits
    compact_plan=load(OUT.parent/'plan.json')
    for p,h in compact_plan['inputs'].items():assert digest(ROOT/p)==h
    rows=[];forward=[0]*n;pair_rows=0
    with gzip.open(RED/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);assert len(row)>=2 and row==sorted(set(row)) and 0<=row[0]<=row[-1]<n
            if len(row)==2:i,j=row;forward[i]|=1<<j;pair_rows+=1
            else:rows.append(row)
    original_graph=read_graph(RED/'adjacency.bin.gz',n);reconstructed=[0]*n
    for row in rows:
        mask=sum(1<<j for j in row)
        for j in row:reconstructed[j]|=mask^(1<<j)
    for i,mask in enumerate(forward):
        assert not(mask&((1<<(i+1))-1));reconstructed[i]|=mask
        for j in bits(mask):reconstructed[j]|=1<<i
    assert reconstructed==original_graph and pair_rows==sum(m.bit_count() for m in forward)
    write(OUT/'encoding-audit.json',{'passed':True,'original_pair_rows':pair_rows,'retained_larger_cliques':len(rows),'implication_rows':sum(bool(v) for v in forward),'complete_original_graph_reconstructed':True,'edges':sum(v.bit_count() for v in reconstructed)//2,'original_graph_sha256':digest(RED/'adjacency.bin.gz'),'original_constraints_sha256':digest(RED/'cliques.jsonl.gz')})
    del reconstructed,original_graph''')
    s=replace(s,"    model.add_exactly_one(variables[n:])","    for i,mask in enumerate(forward):\n        if mask:model.add_bool_and(variables[j].Not() for j in bits(mask)).only_enforce_if(variables[i])\n    model.add_exactly_one(variables[n:])")
    s=replace(s,"    expected.constraints.add().exactly_one", "    for i,mask in enumerate(forward):\n        if mask:\n            c=expected.constraints.add();c.enforcement_literal.append(i);c.bool_and.literals.extend(-j-1 for j in bits(mask))\n    expected.constraints.add().exactly_one")
    s=replace(s,"    assert sum(hint[n:])==1", "    hintmask=sum(1<<j for j in range(n) if hint[j]);assert all(not hint[i] or not(mask&hintmask) for i,mask in enumerate(forward))\n    assert sum(hint[n:])==1")
    s=replace(s,"BASE/'audit/checks.json',BASE/'plan.json'","BASE/'audit/checks.json',BASE/'plan.json',OUT.parent/'plan.json',OUT/'encoding-audit.json'")
    s=replace(s,'del rows,expected,actual','del rows,forward,expected,actual')
    # Do not import geometry-only dependencies in the solver's protobuf environment.
    s=replace(s,'    from build_h5_expanded_frame_joint import read_graph\n    from census_h5_one_part_moves import bits', '''    def bits(mask):
        while mask:
            bit=mask&-mask;yield bit.bit_length()-1;mask^=bit
    def read_graph(path,n):
        width=(n+7)//8;result=[]
        with gzip.open(path,'rb') as f:
            for _ in range(n):
                data=f.read(width);assert len(data)==width;result.append(int.from_bytes(data,'little'))
            assert f.read(1)==b''
        return result''')
    put('solve_h5_expanded_frame_implications.py',s)
    s=(ROOT/'output/audit_h5_expanded_frame_joint_layouts.py').read_text()
    s=replace(s,'from build_h5_expanded_frame_joint import OUT,read_graph','from build_h5_expanded_frame_joint import OUT as SOURCE,read_graph\nOUT=ROOT/\'output/h5-expanded-frame-implications-20261023\'')
    s=replace(s,"RED=OUT/'reduced'","RED=SOURCE/'reduced'")
    s=replace(s,"load(OUT/'candidates.json')","load(SOURCE/'candidates.json')")
    s=replace(s,"load(OUT/'audit/checks.json')","load(SOURCE/'audit/checks.json')")
    s=replace(s,"load(OUT/'hints/best-hint.json')","load(SOURCE/'hints/best-hint.json')")
    put('audit_h5_expanded_frame_implication_layouts.py',s)
    print('Declared and prepared compact exact encoding; old UNKNOWN run remains untouched.')
if __name__=='__main__':main()
