"""Fresh family-relocation hints from both retained best original partials."""
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction
from itertools import permutations
import shutil,time
from build_h5_expanded_frame_joint import ROOT,OUT as BASE,load,write,digest,read_graph
RED=BASE/'reduced';OUT=BASE/'hints'
def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(RED/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'seed.py')
    mp=load(RED/'mapping.json');pool=load(BASE/'candidates.json');ids=mp['candidates'];local={i:j for j,i in enumerate(ids)};adj=read_graph(RED/'adjacency.bin.gz',len(ids));weights=mp['area_weights'];caps={'bracket':12,'cog':15,'insert':21};family=[pool[i]['placement']['part_id'] for i in ids];poses=[pool[i]['placement'] for i in ids]
    orders=[]
    def coordinate(j,kind,reverse):
        p=poses[j];x,y=p['transform']['translation'];sheet=(p['sheet_id']=='sheet-1')^reverse
        if kind=='degree':return (adj[j].bit_count(),sheet,y,x,ids[j])
        return (sheet,-y if kind=='top-left' else y,-x if kind=='bottom-right' else x,ids[j])
    for f in permutations(caps):
        for kind in ['bottom-left','top-left','bottom-right','degree']:
            for reverse in [False,True]:
                rank={name:i for i,name in enumerate(f)};orders.append(({'families':list(f),'kind':kind,'last_sheet_first':reverse},sorted(range(len(ids)),key=lambda j:(rank[family[j]],coordinate(j,kind,reverse)))))
    for kind in ['area','degree-per-area']:
        for reverse in [False,True]:
            orders.append(({'kind':kind,'last_sheet_first':reverse},sorted(range(len(ids)),key=lambda j:((poses[j]['sheet_id']=='sheet-1')^reverse,-weights[family[j]] if kind=='area' else Fraction(adj[j].bit_count(),weights[family[j]]),adj[j].bit_count(),ids[j]))))
    cases=[(g,d,o) for g in range(len(mp['frame_groups'])) for d,o in orders];assert len(orders)==52 and len(cases)==1508
    inputs=[BASE/n for n in ['plan.json','candidates.json','audit/checks.json']]+[RED/n for n in ['mapping.json','adjacency.bin.gz','cliques.jsonl.gz','checks.json','substitutions.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_seconds':30,'maximum_cases':1508,'ordering_specs':[d for d,o in orders],'frame_groups':list(range(len(mp['frame_groups']))),'method':'Start empty for each of the 29 complete frame groups, respecting every small pose compatible groups. Greedily add compatible poses under each of 52 deterministic family/coordinate/sheet orders using the complete induced graph and original caps. Preserve all results and pending cases. Keep the best original-area mapped seed unless improved. This is a fresh bounded group-choice census, not a solver retry.'})
    best={**load(RED/'best-hint.json'),'source':'mapped-original-seed'};baseline=best['objective'];hints=[];start=time.perf_counter()
    for group,description,order in cases:
        if time.perf_counter()-start>=30:break
        chosen=[];counts=Counter();mask=0
        assert all(not(adj[j]&mask) for j in chosen)
        for j in order:
            if group not in mp['compatible_groups'][j] or counts[family[j]]>=caps[family[j]] or (mask>>j)&1 or adj[j]&mask:continue
            chosen.append(j);mask|=1<<j;counts[family[j]]+=1
            if counts==caps:break
        row={'index':len(hints),'source':'fresh-frame-group-choice','frame_group':group,'ordering':description,'selected_small_candidates':sorted(ids[j] for j in chosen),'counts':dict(counts),'objective':sum(weights[family[j]] for j in chosen)};hints.append(row)
        if row['objective']>best['objective']:best=row
    elapsed=time.perf_counter()-start
    for r in hints+[best]:
        chosen=[local[i] for i in r['selected_small_candidates']];mask=sum(1<<j for j in chosen);counts=Counter(family[j] for j in chosen)
        assert all(r['frame_group'] in mp['compatible_groups'][j] for j in chosen)
        assert len(chosen)==len(set(chosen)) and dict(counts)==r['counts'] and all(counts[f]<=caps[f] for f in caps) and all(not(adj[j]&mask) for j in chosen) and sum(weights[family[j]] for j in chosen)==r['objective']
    write(OUT/'hints.json',hints);write(OUT/'best-hint.json',best);write(OUT/'pending.json',[{'frame_group':g,'ordering':d} for g,d,o in cases[len(hints):]])
    checks={'passed':True,'seconds':elapsed,'planned_cases':1508,'completed_cases':len(hints),'pending_cases':1508-len(hints),'limit_reached':elapsed>=30,'every_result_full_graph_group_counts_score_checked':True,'best_original_seed_objective':baseline,'best_original_seed_preserved':best['objective']>=baseline,'best_hint':{k:v for k,v in best.items() if k!='selected_small_candidates'},'full_inventory_hint':best['counts']==caps,'original_CLI_acceptance_pending':True,'native_margin_qualified':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
