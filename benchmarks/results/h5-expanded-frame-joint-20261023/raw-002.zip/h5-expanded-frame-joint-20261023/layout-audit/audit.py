"""Audit the best starting hint and every returned wider-frame layout against original inputs."""
from collections import Counter,defaultdict
from itertools import combinations
import copy,math,shutil,subprocess,json
from audit_h5_cog_lattices import shape
from build_h5_group_choice import ROOT,SRC,load,write,digest,rows
from build_h5_expanded_frame_joint import OUT,read_graph
SEED=ROOT/'output/h5-group-choice-20261023';RED=OUT/'reduced'
def main():
    dst=OUT/'layout-audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');run=OUT/'solve'
    mp=load(RED/'mapping.json');pool=load(OUT/'candidates.json');result=load(run/'result.json');model=load(run/'model-audit.json')
    assert load(OUT/'audit/checks.json')['passed']
    for p,h in model['input_hashes'].items():assert digest(ROOT/p)==h
    assert digest(run/'model.pb')==model['model_sha256'] and digest(run/'parameters.pbtxt')==model['parameters_sha256']
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];target=load(SRC/'conditional-target.json');m=stock['margins'];edge=job['edge_clearance']
    old=ROOT/'output/h5-latest-wide-joint-20261023/layout-audit';original=load(old/'layout-final.json');cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    key=lambda l:json.dumps(l,sort_keys=True,separators=(',',':'))
    cache={key(original):{'layout':old/'layout-final.json','public':old/'public-final.json','command':old/'command-final.json'}}
    best=load(OUT/'hints/best-hint.json');seed=sorted(mp['frame_groups'][best['frame_group']]['candidates']+best['selected_small_candidates'])
    outcomes=[{'index':'hint','frame_group':best['frame_group'],'selected_indices':seed,'counts':dict(Counter(pool[i]['placement']['part_id'] for i in seed)),'objective':best['objective']}]
    outcomes += [load(run/f'incumbent-{i}.json') for i in range(result['incumbents'])]
    if (run/'selected-indices.json').exists():
        final=load(run/'selected-indices.json')
        if not outcomes or final!=outcomes[-1]['selected_indices']:outcomes.append({'index':'final','frame_group':result['frame_group'],'selected_indices':final,'counts':result['counts'],'objective':result['objective']})
    ids=mp['candidates'];local={i:j for j,i in enumerate(ids)};adj=read_graph(RED/'adjacency.bin.gz',len(ids));records=[];fresh=reused=0
    weights=mp['area_weights']
    source=ROOT/'output/h5-coordinated-placement-selection-20261018'
    assert load(source/'job.json')==job and load(source/'conditional-target.json')==target
    original_inputs={p.relative_to(ROOT).as_posix():digest(p) for p in [source/'job.json',source/'library.json',source/'request.json',source/'conditional-target.json',cli]}
    for r in outcomes:
        chosen=r['selected_indices'];fixed=set(mp['frame_groups'][r['frame_group']]['candidates']);sm=set(chosen)-fixed
        assert len(chosen)==len(set(chosen)) and fixed<=set(chosen) and sm<=local.keys()
        selected_local={local[i] for i in sm};mask=sum(1<<j for j in selected_local);assert all(not(adj[j]&mask) and r['frame_group'] in mp['compatible_groups'][j] for j in selected_local)
        assert sum(weights[pool[i]['placement']['part_id']] for i in sm)==r['objective']>=model['seed_score']
        counts=Counter();placements=[];gg=defaultdict(list);tops=Counter()
        for i in chosen:
            p=copy.deepcopy(pool[i]['placement']);part=parts[p['part_id']];t=p['transform'];p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            g=shape(part,t);a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
            assert g.is_valid and a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
            gg[p['sheet_id']].append(g);tops[p['sheet_id']]=max(tops[p['sheet_id']],d+m['top']+edge)
        assert dict(counts)==r['counts'] and counts['frame']==18 and counts['bracket']<=12 and counts['cog']<=15 and counts['insert']<=21
        pairs=0;minimum=math.inf
        for gs in gg.values():
            for a,b in combinations(gs,2):
                pairs+=1;distance=a.distance(b);minimum=min(minimum,distance);assert a.disjoint(b) and distance>=job['clearance']-1e-7
        layout={'version':1,'units':'mm','sheets':original['sheets'],'placements':placements};index=r['index'];p=dst/f'layout-{index}.json';write(p,layout)
        if key(layout) in cache:
            origin=cache[key(layout)];assert load(origin['layout'])==layout;public=load(origin['public']);code=load(origin['command'])['exit_code']
            write(dst/f'validation-reuse-{index}.json',{'rerun':False,'exact_layout_match':True,'source_files':{p.relative_to(ROOT).as_posix():digest(p) for p in origin.values()}})
            shutil.copyfile(origin['public'],dst/f'public-{index}.json');reused+=1;reuse=True
        else:
            source=ROOT/'output/h5-coordinated-placement-selection-20261018'
            cmd=[str(cli),'validate','--library',str(source/'library.json'),'--request',str(source/'request.json'),'--layout',str(p)]
            cp=subprocess.run(cmd,capture_output=True,timeout=60);code=cp.returncode;pp=dst/f'public-{index}.json';cc=dst/f'command-{index}.json'
            pp.write_bytes(cp.stdout);(dst/f'public-{index}.stderr').write_bytes(cp.stderr);write(cc,{'command':cmd,'exit_code':code});public=load(pp)
            cache[key(layout)]={'layout':p,'public':pp,'command':cc};fresh+=1;reuse=False
        missing={f:part['quantity']-counts[f] for f,part in parts.items() if counts[f]<part['quantity']}
        expected=[{'code':'quantity','message':f"part {f}: expected {parts[f]['quantity']}, found {counts[f]}"} for f in missing]
        assert sorted(public['violations'],key=lambda v:v['message'])==sorted(expected,key=lambda v:v['message']) and public['valid']==(not missing) and (code==0)==(not missing)
        material=stock['width']*(stock['height']+tops['sheet-1']);assert material<=target['target_material_mm2']+1e-6
        records.append({'incumbent':index,'frame_group':r['frame_group'],'counts':dict(counts),'missing':missing,'filled_area_mm2':sum(g.area for gs in gg.values() for g in gs),
          'material_mm2':material,'minimum_distance_mm':minimum,'geometry_pairs':pairs,'small_candidates_absent_previous_wide_model':sorted(sm-set(load(ROOT/'output/h5-latest-wide-joint-20261023/mapping.json')['candidates'])),
          'original_CLI_valid':public['valid'],'exact_CLI_reuse':reuse})
    check={'passed':True,'layouts_checked_including_hint':len(records),'all_returned_layouts_checked':len(records)-1,'records':records,'fresh_frozen_CLI_calls':fresh,'exact_CLI_results_reused':reused,
      'original_validation_input_hashes':original_inputs,'full_target_witness':any(r['original_CLI_valid'] for r in records),'native_margin_qualified':False,'native_packing_calls':0,'quality_runs':0}
    write(dst/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
