"""Independently rebuild original geometry, whole-group eligibility and every graph row."""
from collections import Counter
from itertools import combinations,product
import copy,math,shutil,time
import numpy as np
import shapely
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_expanded_frame_joint import ROOT,SRC,COVER,OUT,load,write,digest,read_graph

def main():
    dst=OUT/'audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');start=time.perf_counter()
    plan=load(OUT/'plan.json');mp=load(OUT/'mapping.json');coverage=load(COVER/'mapping.json');pool=load(OUT/'candidates.json')
    for p in [plan,load(COVER/'plan.json')]:
        for name,h in p['inputs'].items():assert digest(ROOT/name)==h
    assert pool==load(ROOT/coverage['source_pool'])
    for key in coverage:assert mp[key]==coverage[key]
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];target=load(SRC/'conditional-target.json')
    original=ROOT/'output/h5-coordinated-placement-selection-20261018'
    assert load(original/'job.json')==job and load(original/'conditional-target.json')==target
    groups=mp['frame_groups'];assert len(groups)==29 and [g['index'] for g in groups]==list(range(29))
    assert groups[:26]==load(ROOT/'output/h5-whole-frame-census-20261020/groups.json')
    gg=np.asarray([shape(parts[p['placement']['part_id']],p['placement']['transform']) for p in pool],dtype=object)
    bounds=shapely.bounds(gg);sheets=np.asarray([p['placement']['sheet_id'] for p in pool])
    frames=sorted({i for g in groups for i in g['candidates']});small=[i for i,p in enumerate(pool) if p['placement']['part_id']!='frame']
    for i in frames+small:
        p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform'];a,b,c,d=bounds[i]
        assert p['sheet_id'] in ['sheet-0','sheet-1'] and gg[i].is_valid and (not t['mirrored'] or part['allow_mirror'])
        h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
    framepairs=uniondistances=0;memberships={i:[] for i in small}
    for group in groups:
        fixed=group['candidates'];assert len(fixed)==len(set(fixed))==18 and Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18)
        for i,j in combinations(fixed,2):
            if sheets[i]!=sheets[j]:continue
            framepairs+=1;assert gg[i].disjoint(gg[j]) and gg[i].distance(gg[j])>=clear-1e-7
        for sheet in ['sheet-0','sheet-1']:
            fs=[gg[i] for i in fixed if sheets[i]==sheet];ss=[i for i in small if sheets[i]==sheet]
            if fs:
                union=unary_union(fs);ok=shapely.distance(gg[ss],union)>=clear-1e-7;uniondistances+=len(ss)
            else:ok=np.ones(len(ss),dtype=bool)
            for i,eligible in zip(ss,ok,strict=True):
                if eligible:memberships[i].append(group['index'])
    ids=[i for i in small if memberships[i]]
    assert ids==mp['candidates'] and [memberships[i] for i in ids]==mp['compatible_groups']
    assert all(r['compatible_groups']==memberships[r['candidate']] for r in load(COVER/'group-filter.json'))
    saved=read_graph(OUT/'adjacency.bin.gz',len(ids));expected=[0]*len(ids);gs=gg[ids];bb=bounds[ids];ss=sheets[ids];possible=near=0
    for i in range(len(ids)):
        js=np.arange(i+1,len(ids));js=js[ss[js]==ss[i]];possible+=len(js)
        dx=np.maximum(0,np.maximum(bb[js,0]-bb[i,2],bb[i,0]-bb[js,2]));dy=np.maximum(0,np.maximum(bb[js,1]-bb[i,3],bb[i,1]-bb[js,3]));js=js[np.hypot(dx,dy)<=clear+1e-7];near+=len(js)
        for j in js[shapely.distance(gs[i],gs[js])<clear-1e-7]:j=int(j);expected[i]|=1<<j;expected[j]|=1<<i
        if i and i%4000==0:print({'audit_rows':i,'seconds':time.perf_counter()-start},flush=True)
    assert expected==saved;edges=sum(a.bit_count() for a in expected)//2;result=load(OUT/'result.json');assert edges==result['conflicts'] and digest(OUT/'adjacency.bin.gz')==result['graph_sha256']
    layout=load(ROOT/'output/h5-latest-wide-joint-20261023/layout-audit/layout-final.json');keys={identity(p['placement']):i for i,p in enumerate(pool)};mapped=[]
    for p in layout['placements']:
        p=copy.deepcopy(p);p.pop('copy_index');i=keys[identity(p)];assert p==pool[i]['placement'];mapped.append(i)
    assert sorted(mapped)==mp['seed_indices'] and len(mapped)==len(set(mapped))==64
    group=mp['seed_group'];assert group==26 and sorted(i for i in mapped if pool[i]['placement']['part_id']=='frame')==groups[group]['candidates']
    local={i:j for j,i in enumerate(ids)};chosen=[local[i] for i in mapped if i in local];mask=sum(1<<j for j in chosen)
    assert all(not(saved[j]&mask) and group in mp['compatible_groups'][j] for j in chosen)
    assert mp['seed_candidates']==sorted(ids[j] for j in chosen)
    seedpairs=0
    for i,j in combinations(mapped,2):
        if sheets[i]!=sheets[j]:continue
        seedpairs+=1;assert gg[i].disjoint(gg[j]) and gg[i].distance(gg[j])>=clear-1e-7
    families=['bracket','cog','insert'];areas=[shape(parts[f],{'rotation_radians':0,'translation':[0,0],'mirrored':False}).area for f in families]
    weights=[mp['area_weights'][f] for f in families];assert weights==[round(a*1000) for a in areas]
    counts=list(product(range(13),range(16),range(22)))
    assert sorted(counts,key=lambda c:sum(n*a for n,a in zip(c,areas)))==sorted(counts,key=lambda c:sum(n*w for n,w in zip(c,weights)))
    check={'passed':True,'seconds':time.perf_counter()-start,'complete_source_pool_exact':True,'original_job_and_target_exact':True,'whole_frame_groups':len(groups),'distinct_used_frame_poses_checked':len(frames),'all_small_poses_checked':len(small),'within_group_frame_pairs':framepairs,'union_distances':uniondistances,'group_memberships_independently_verified':len(small)*len(groups),'retained_candidates':len(ids),'small_pair_possibilities':possible,'small_pair_exact_distances':near,'conflicts':edges,'every_binary_adjacency_row_independently_rebuilt':True,'exact_64_seed_identity_group_and_geometry_checked':True,'seed_same_sheet_pairs':seedpairs,'integer_objective_orders_all_original_count_combinations':len(counts),'native_margin_qualified':False}
    write(dst/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
