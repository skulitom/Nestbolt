"""Post-hoc fixed-neighbour geometry construction; not a benchmark or H5 run."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from datetime import datetime, timezone
import copy, itertools, json, math, shutil, subprocess, sys, traceback, zipfile
import numpy as np
import shapely
from shapely.geometry import Polygon, MultiPoint, box, mapping
from shapely.affinity import affine_transform
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parents[1]
PRIOR = ROOT / 'benchmarks/results/h5-source-frontier-pilot-20261018'
OUT = ROOT / 'output/h5-source-gap-diagnosis-20261018'
CLI = ROOT / 'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
EPS = 1e-4  # Positive construction margin, not an acceptance tolerance.
TOL = 1e-7
QUADS = 16
digest = lambda p: sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
sys.path.insert(0, str(ROOT / 'scripts'))
from h2_import_audit import source_digest


def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')


def pose(shape, t):
    c, s = math.cos(t['rotation_radians']), math.sin(t['rotation_radians'])
    m = -1 if t['mirrored'] else 1
    return affine_transform(shape, [m*c, -s, m*s, c, *t['translation']])


_piece_cache = {}


def convex_pieces(shape):
    key = shape.wkb
    if key in _piece_cache: return _piece_cache[key]
    if shape.equals(shape.convex_hull):
        pieces = [shape]
    else:
        pieces = list(shapely.constrained_delaunay_triangles(shape).geoms)
        assert pieces and unary_union(pieces).equals(shape)
        # Merge adjacent triangles only when their actual union is convex.
        # The exact coverage assertion below prevents any lost concave sliver.
        changed = True
        while changed:
            changed = False
            for i in range(len(pieces)):
                for j in range(i+1,len(pieces)):
                    if pieces[i].boundary.intersection(pieces[j].boundary).length == 0: continue
                    merged=pieces[i].union(pieces[j])
                    if merged.geom_type=='Polygon' and merged.equals(merged.convex_hull):
                        pieces[i]=merged;pieces.pop(j);changed=True;break
                if changed:break
        assert unary_union(pieces).equals(shape)
        assert all(p.equals(p.convex_hull) for p in pieces)
    _piece_cache[key]=pieces
    return pieces


def obstacle(fixed, moving, clearance):
    hulls=[]
    for fp in convex_pieces(fixed):
        a=np.asarray(fp.exterior.coords)[:-1]
        for mp in convex_pieces(moving):
            b=np.asarray(mp.exterior.coords)[:-1]
            hulls.append(MultiPoint((a[:,None,:]-b[None,:,:]).reshape(-1,2)).convex_hull)
    # Minkowski addition distributes over the exactly covering convex pieces.
    forbidden=unary_union(hulls)
    # Straight mitred joins over-approximate round clearance, including concave
    # part detail, without relying on a nominal polygonal arc segment angle.
    return forbidden.buffer(clearance+EPS,join_style='mitre',mitre_limit=5)


def regions(moving, fixed, stock, edge, clearance):
    assert not stock['outline'] and not stock['defects']
    x0, y0, x1, y1 = moving.bounds
    m = stock['margins']
    bounds = (m['left']+edge+EPS-x0, m['bottom']+edge+EPS-y0,
              stock['width']-m['right']-edge-EPS-x1,
              stock['height']-m['top']-edge-EPS-y1)
    if bounds[0] >= bounds[2] or bounds[1] >= bounds[3]:
        return Polygon()
    forbidden = unary_union([obstacle(p, moving, clearance) for p in fixed])
    return box(*bounds).difference(forbidden)


def polygons(geom):
    if geom.is_empty: return []
    if geom.geom_type == 'Polygon': return [geom]
    return [p for g in geom.geoms for p in polygons(g)] if hasattr(geom, 'geoms') else []


def orientations(part, old):
    r = part['rotations']
    if r['kind'] == 'list': angles = [math.radians(x) for x in r['degrees']]
    else:
        assert r['kind'] == 'free'
        # A finite diagnostic subset only; no exhaustive free-rotation claim.
        angles = [old['rotation_radians'], 0, math.pi/2, math.pi, 3*math.pi/2]
    seen = set()
    for mirrored in ([False, True] if part['allow_mirror'] else [False]):
        for angle in angles:
            key = (round(angle % math.tau, 12), mirrored)
            if key in seen: continue
            seen.add(key)
            yield {'rotation_radians': angle, 'mirrored': mirrored, 'translation': [0., 0.]}


def geometry_audit(job, layout, original, moved):
    parts = {p['id']: p for p in job['parts']}
    stocks = {p['id']: p for p in job['stocks']}
    sheets = {p['id']: stocks[p['stock_id']] for p in layout['sheets']}
    key = lambda p: (p['part_id'], p['copy_index'])
    original_poses = {key(p): p for p in original['placements']}
    assert Counter(p['part_id'] for p in layout['placements']) == Counter({p['id']:p['quantity'] for p in job['parts']})
    assert len({key(p) for p in layout['placements']}) == len(layout['placements'])
    assert layout['sheets'] == original['sheets']
    grouped = {}
    for p in layout['placements']:
        part = parts[p['part_id']]; t = p['transform']
        if key(p) not in moved: assert p == original_poses[key(p)]
        assert not t['mirrored'] or part['allow_mirror']
        if part['rotations']['kind'] == 'list':
            assert any(abs(math.remainder(t['rotation_radians']-math.radians(a), math.tau)) < 1e-9 for a in part['rotations']['degrees'])
        assert len(part['geometry']) == 1
        shape = pose(Polygon(part['geometry'][0]['outer']), t)
        assert shape.is_valid and shape.area > 0
        st = sheets[p['sheet_id']]; m = st['margins']; edge = job['edge_clearance']
        assert not st['outline'] and not st['defects']
        x0, y0, x1, y1 = shape.bounds
        assert x0 >= m['left']+edge-TOL and y0 >= m['bottom']+edge-TOL
        assert x1 <= st['width']-m['right']-edge+TOL and y1 <= st['height']-m['top']-edge+TOL
        grouped.setdefault(p['sheet_id'], []).append(shape)
    count = 0; minimum = math.inf
    for shapes in grouped.values():
        for a, b in itertools.combinations(shapes, 2):
            count += 1; assert a.disjoint(b)
            slack = a.distance(b)-job['clearance']; minimum = min(minimum, slack)
            assert slack >= -TOL, slack
    return {'filled_outer_pairs': count, 'minimum_clearance_slack_mm': minimum,
            'all_unselected_placements_exact': True, 'all_holes_reserved': True}


def validate(folder, name, layout, job, original, moved):
    path = folder/(name+'.json'); write(path, layout)
    command = [str(CLI), 'validate', '--library', str(folder/'library.json'),
               '--request', str(folder/'request.json'), '--layout', str(path)]
    r = subprocess.run(command, capture_output=True, timeout=60)
    (folder/(name+'-stdout.json')).write_bytes(r.stdout)
    (folder/(name+'-stderr.log')).write_bytes(r.stderr)
    write(folder/(name+'-command.json'), {'command': command, 'exit_code': r.returncode})
    report = json.loads(r.stdout)
    assert r.returncode == 0 and report['valid'], report
    audit = geometry_audit(job, layout, original, moved)
    write(folder/(name+'-audit.json'), audit)
    return {'metrics':report['metrics'], **audit}


def sanity():
    stock = {'width':100, 'height':100, 'margins':dict.fromkeys(['left','right','bottom','top'],0), 'outline':[], 'defects':[]}
    moving = box(0,0,1,1)
    fixed = [box(0,0,49,100), box(51,0,100,100)]
    free = regions(moving,fixed,stock,0,.2)
    assert not free.is_empty and 49.2 < free.bounds[0] < free.bounds[2] < 49.8
    placed = pose(moving,{'translation':list(free.representative_point().coords)[0], 'rotation_radians':0., 'mirrored':False})
    assert all(placed.distance(f) >= .2 for f in fixed)
    assert regions(box(0,0,2,2),fixed,stock,0,.2).is_empty
    assert regions(moving,[box(0,0,100,100)],stock,0,.2).is_empty
    concave=Polygon([(0,0),(80,0),(80,20),(20,20),(20,80),(0,80)])
    assert len(convex_pieces(concave))>1
    shaped_stock=dict(stock,width=80,height=80)
    assert not regions(box(0,0,30,30),[concave],shaped_stock,0,.2).is_empty
    assert regions(box(0,0,30,30),[concave.convex_hull],shaped_stock,0,.2).is_empty
    return {'narrow_gap_positive':True,'oversized_negative':True,'filled_outer_negative':True,'concave_gap_missed_by_hull':True}


def main():
    OUT.mkdir()
    assert digest(CLI) == '97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    production = source_digest()
    assert production == '8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
    results = load(PRIOR/'results.json')
    rows = [r for r in results['records'] if r['arm']=='candidate' and r['seed']==0 and r['job'].startswith('m-mechanical')]
    assert len(rows) == 4
    plan = {'opened_utc':datetime.now(timezone.utc).isoformat(), 'results_sha256':digest(PRIOR/'results.json'),
        'CLI_sha256':digest(CLI), 'production_digest':production, 'script_sha256':digest(Path(__file__)),
        'cases':[{'archive':r['archive'],'sha256':r['archive_sha256']} for r in rows],
        'method':'One deterministic greedy pass over original last-sheet copies above the saved conditional material target, by decreasing original top, then area, then id/index. Construct at most four moves into that lower prefix on the SAME sheet, with no neighbour changed. This is a post-hoc sequence, not runtime acceptance. Try permitted list rotations/mirrors; free parts use their original angle and four quadrants. Exactly cover each filled outer contour with convex pieces, verify their union and convexity, then subtract unions of pairwise Minkowski obstacles expanded by mitred clearance buffers from the legal rectangular translation domain. Select the first orientation with a positive-area region, and its lowest representative interior point. Only the selected part moves within its existing last sheet; every other pose stays exact. The placement domain limits the selected part to the saved conditional target height, while other parts may still cross that height. Full original stock and cutting settings remain the validation authority. Retain and validate each constructed layout. No source compaction, displacement, victim or hole use.',
        'construction_extra_margin_mm':EPS, 'acceptance_tolerance_mm':TOL, 'buffer_join_style':'mitre', 'buffer_mitre_limit':5,
        'scope':'Post-hoc geometry mechanism diagnosis on CCD1, not a runtime quality/speed comparison. Finite free angles, positive construction margin and one greedy pass can miss actual feasible regions; no-result is not an impossibility proof. This follows two retained fixed-earlier-sheet diagnoses with zero transfers; the four original layouts are reused unchanged. Lowering selected source copies tests a different move domain, without another solver run. No solver search or gate rerun.',
        'sanity':sanity(), 'shapely_version':shapely.__version__}
    write(OUT/'plan.json',plan); shutil.copyfile(__file__,OUT/'diagnose.py')
    records=[]
    try:
        for row in rows:
            archive=PRIOR/row['archive']; assert digest(archive)==row['archive_sha256']
            folder=OUT/Path(row['archive']).stem; folder.mkdir()
            with zipfile.ZipFile(archive) as z:
                assert z.testzip() is None
                for name in ['library.json','request.json','nested/job.json','nested/layout.json']:
                    (folder/('original.json' if name=='nested/layout.json' else Path(name).name)).write_bytes(z.read(name))
            job=load(folder/'job.json'); original=load(folder/'original.json'); layout=copy.deepcopy(original)
            assert digest(folder/'original.json')==row['layout_sha256']
            assert job['clearance']==row['kerf_mm'] and job['units']=='mm'
            baseline=validate(folder,'baseline',layout,job,original,set())
            assert baseline['metrics']==row['metrics']
            parts={p['id']:p for p in job['parts']}; shapes={k:Polygon(v['geometry'][0]['outer']) for k,v in parts.items()}
            assert all(len(p['geometry'])==1 for p in parts.values())
            source=row['metrics']['last_sheet_id']; ids=[s['id'] for s in layout['sheets']]
            assert source==ids[-1] and len(ids)==2
            stocks={s['id']:s for s in job['stocks']}; stock_by_sheet={s['id']:stocks[s['stock_id']] for s in layout['sheets']}
            order=sorted([i for i,p in enumerate(original['placements']) if p['sheet_id']==source],
                key=lambda i:(-pose(shapes[original['placements'][i]['part_id']],original['placements'][i]['transform']).bounds[3],
                              -shapes[original['placements'][i]['part_id']].area, original['placements'][i]['part_id'], original['placements'][i]['copy_index']))
            boundary=next(b for b in load(PRIOR/'final-boundaries.json')['records'] if b['archive']==row['archive'])
            assert boundary['layout_sha256']==row['layout_sha256']
            target_stock=copy.deepcopy(stock_by_sheet[source]); target_stock['height']=boundary['required_used_height_mm']
            order=[i for i in order if pose(shapes[original['placements'][i]['part_id']],original['placements'][i]['transform']).bounds[3] > boundary['required_outline_top_mm']+2e-6]
            write(folder/'conditional-target.json',boundary)
            moved=set(); attempts=[]; transfers=[]; last=baseline; cache={}
            for i in order:
                if len(moved)>=4:break
                p=layout['placements'][i]; family=p['part_id']; chosen=None
                for target in [source]:
                    fixed=[pose(shapes[q['part_id']],q['transform']) for j,q in enumerate(layout['placements']) if q['sheet_id']==target and j!=i]
                    for t in orientations(parts[family],p['transform']):
                        k=(len(moved),i,family,target,t['rotation_radians'],t['mirrored'])
                        if k not in cache:
                            local=pose(shapes[family],t)
                            free=regions(local,fixed,target_stock,job['edge_clearance'],job['clearance'])
                            pieces=polygons(free)
                            pts=sorted((list(g.representative_point().coords)[0] for g in pieces if g.area>0), key=lambda xy:(xy[1],xy[0]))
                            cache[k]=(free,pts)
                        free,pts=cache[k]
                        a={'part_id':family,'copy_index':p['copy_index'],'target':target,'rotation_radians':t['rotation_radians'],
                            'mirrored':t['mirrored'],'region_area_mm2':free.area,'region_count':len(polygons(free)),'earlier_source_moves':len(moved)}
                        attempts.append(a)
                        if pts:
                            t=copy.deepcopy(t);t['translation']=list(pts[0]); chosen=(target,t,a,free);break
                    if chosen:break
                if chosen:
                    target,t,a,free=chosen; before=copy.deepcopy(layout)
                    p['sheet_id']=target;p['transform']=t
                    key=(family,p['copy_index']);moved.add(key)
                    assert all(x==y for j,(x,y) in enumerate(zip(before['placements'],layout['placements'])) if j!=i)
                    name=f'transfer-{len(transfers)+1:03d}'
                    write(folder/(name+'-region.geojson'),mapping(free))
                    checked=validate(folder,name,layout,job,original,moved)
                    transfer={**a,'transform':t,'before_material_mm2':last['metrics']['material_area'],
                        'after_material_mm2':checked['metrics']['material_area'],'geometry':checked}
                    transfers.append(transfer);last=checked
                    write(folder/(name+'-result.json'),transfer)
                    print(json.dumps({'case':folder.name,'transfer':len(transfers),'part':key,'material_gain_mm2':transfer['before_material_mm2']-transfer['after_material_mm2']}),flush=True)
            write(folder/'attempts.json',attempts)
            record={'case':folder.name,'archive_sha256':digest(archive),'copies_crossing_target':len(order),'copies_considered':len({(a['part_id'],a['copy_index']) for a in attempts}),'orientation_attempts':len(attempts),
                'region_constructions':len(cache),'transfers':transfers,'before':baseline,'after':last,
                'material_gain_mm2':baseline['metrics']['material_area']-last['metrics']['material_area']}
            write(folder/'result.json',record);records.append(record)
            print(json.dumps({k:record[k] for k in ['case','copies_considered','orientation_attempts','region_constructions','material_gain_mm2']}),flush=True)
        assert source_digest()==production and digest(CLI)==plan['CLI_sha256']
        assert digest(PRIOR/'results.json')==plan['results_sha256']
        for r in rows:assert digest(PRIOR/r['archive'])==r['archive_sha256']
        write(OUT/'results.json',{'complete':True,'original_inputs_unchanged':True,'production_unchanged':True,'new_solver_searches':0,
            'posthoc_geometry_search':True,'cases':records,'quality_claim':False,'H5_complete':False})
    except BaseException:
        write(OUT/'failure.json',{'traceback':traceback.format_exc(),'completed':records});raise


if __name__=='__main__':main()
