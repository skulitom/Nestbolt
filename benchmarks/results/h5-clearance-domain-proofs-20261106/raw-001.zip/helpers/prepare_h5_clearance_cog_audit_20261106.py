from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_source_cog_cell_pruning_20261106.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106'","BASE=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'")
s=s.replace("FRONTIER=ROOT/'output/h5-first57-union-augmented-trees-20261106'","FRONTIER=ROOT/'output/h5-first57-cog-union-subdivision-20261106'")
s=s.replace("PROCESS=ROOT/'output/h5-first57-source-cog-cell-pruning-process-20261106'","PROCESS=ROOT/'output/h5-first57-clearance-cog-pruning-process-20261106'\nJOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'")
s=s.replace("inputs={Path(__file__),BASE/'plan.json'","inputs={Path(__file__),ROOT/'output/prepare_h5_clearance_cog_audit_20261106.py',ROOT/'output/audit_h5_source_cog_cell_pruning_20261106.py',JOB,FRONTIER/'plan.json',BASE/'plan.json'")
s=s.replace("assert len(prior)==39","assert len(prior)==28")
a="""selection=[r['source_selection']|{'augmentation_index':r['augmentation_index']}
           for r in load(AUG/'audit/stronger-model-candidates.json') if tuple(r['source_selection']['empty_sites']) in remaining]
assert len(selection)==39 and load(BASE/'plan.json')['selection']==selection"""
b="""selection=[r|{'subdivision_index':i} for i,r in enumerate(load(FRONTIER/'plan.json')['selection']) if tuple(r['empty_sites']) in remaining]
assert len(selection)==28 and load(BASE/'plan.json')['selection']==selection
job=load(JOB);radius_um=199
assert F(job['clearance'])>F(radius_um,1000)>0
assert load(BASE/'plan.json')['required_job_clearance_mm']==job['clearance'] and load(BASE/'plan.json')['clearance_diamond_radius_um']==radius_um"""
assert a in s;s=s.replace(a,b)
a="integer=load(BASE/'integer-source.json');D=int(integer['scaled_units_per_micrometre']);assert D>0"
b=a+"\nassert integer['clearance_diamond_radius_um']==radius_um and integer['required_job_clearance_mm']==job['clearance']\ndiamond=[(radius_um*D,0),(-radius_um*D,0),(0,radius_um*D),(0,-radius_um*D)]\nassert all(x*x+y*y==(radius_um*D)**2 for x,y in diamond)"
assert a in s;s=s.replace(a,b)
a="differences={(x-u,y-v) for (x,y),(u,v) in product(source_pieces[pi],product([r[0]*D,r[2]*D],[r[1]*D,r[3]*D]))}"
b="differences={(x-u+dx,y-v+dy) for (x,y),(u,v),(dx,dy) in product(source_pieces[pi],product([r[0]*D,r[2]*D],[r[1]*D,r[3]*D]),diamond)}"
assert a in s;s=s.replace(a,b)
a="""    inputs.update(paths);data,br,ins=map(load,paths);nodes=br['nodes']+ins['nodes'];offset=len(br['nodes'])"""
b=a+"""
    ppath=FRONTIER/f"choice-{row['subdivision_index']:02d}.json";inputs.add(ppath);parent=load(ppath)
    assert parent['empty_sites']==row['empty_sites']
    parent_nodes=set(parent['retained_bracket_nodes']+parent['retained_insert_nodes'])"""
assert a in s;s=s.replace(a,b)
a="""    for node,ci in zip(nodes,data['node_cells']):
        assert cellkeys[node['geometry'],*node['bounds_um']]==ci
        seen_cells.add(ci);relevance[ci]|=present"""
b="""    for ni,(node,ci) in enumerate(zip(nodes,data['node_cells'])):
        assert cellkeys[node['geometry'],*node['bounds_um']]==ci
        seen_cells.add(ci)
        if ni in parent_nodes:relevance[ci]|=present"""
assert a in s;s=s.replace(a,b)
s=s.replace("n=record['node'];assert n not in removed and 0<=n<len(nodes);removed.add(n)","n=record['node'];assert n not in removed and n in parent_nodes;removed.add(n)")
a="retained_br=sorted(set(range(offset))-removed);retained_ins=sorted(set(range(offset,len(nodes)))-removed)"
b="retained_br=sorted(set(parent['retained_bracket_nodes'])-removed);retained_ins=sorted(set(parent['retained_insert_nodes'])-removed)"
assert a in s;s=s.replace(a,b)
s=s.replace("{'pruning_index':choice,'source_selection':row","{'clearance_pruning_index':choice,'source_selection':row,'parent_union_removed_nodes':len(parent['additional_removed']),'combined_new_removed_nodes':len(removed)+len(parent['additional_removed'])")
s=s.replace("if r['certified_removed_nodes'] and not r['continuous_fixed29_choice_excluded']","if r['combined_new_removed_nodes'] and not r['continuous_fixed29_choice_excluded']")
s=s.replace("This is the exact Minkowski collision polygon.","This is the exact Minkowski sum of the source collision polygon and the closed199um L1 diamond. Each diamond vertex has Euclidean norm199um, so convexity bounds every diamond point by199um, strictly below the original job clearance0.2mm. Membership therefore proves source-body distance below required clearance, without assuming a zero-clearance collision.")
s=s.replace("Retained nodes equal the complete original domain minus only proved-impossible cells.","Retained nodes equal the separately certified parent union-pruned domains minus only the new clearance-impossible cells.")
s=s.replace("'new_fixed29_choices_excluded':len(removed_cases),'total_fixed29_choices_excluded':416+len(removed_cases)","'cases_with_stronger_combined_domains':sum(r['combined_new_removed_nodes']>0 for r in records),'required_job_clearance_mm':job['clearance'],'conservative_clearance_radius_um':radius_um,'zero_clearance_exclusion_claimed':False,'new_fixed29_choices_excluded':len(removed_cases),'total_fixed29_choices_excluded':427+len(removed_cases)")
with (O/'audit_h5_clearance_cog_pruning_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared independent source-clearance Minkowski and complete retained-domain audit.')
