from pathlib import Path
import json
O=Path(__file__).resolve().parent
source=O/'audit_h5_clearance_cog_pruning_20261106.py'
note={'scope':'Proof narrative correction only; numerical checks passed in the preserved first audit.',
    'original_audit':'output/h5-first57-clearance-cog-pruning-20261106/audit',
    'incorrect_phrase':'proving interior overlap for every anchor',
    'correct_claim':'proving source separation below the required clearance for every anchor',
    'reason':'The199um diamond expansion can contain anchors with a positive gap below0.199mm. It does not require zero-clearance overlap. The explicit zero_clearance_exclusion_claimed flag was already false.',
    'preparation_repeated':False,'numerical_inputs_and_checks_changed':False}
with (O/'h5-clearance-proof-scope-correction-20261106.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(note,f,indent=2);f.write('\n')
s=source.read_text(encoding='utf-8').replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'")
assert 'proving interior overlap for every anchor' in s
s=s.replace('proving interior overlap for every anchor','proving source separation below the required clearance for every anchor')
s=s.replace("inputs={Path(__file__),","inputs={Path(__file__),ROOT/'output/audit_h5_clearance_cog_pruning_20261106.py',ROOT/'output/prepare_h5_clearance_cog_audit_v2_20261106.py',ROOT/'output/h5-clearance-proof-scope-correction-20261106.json',")
with (O/'audit_h5_clearance_cog_pruning_v2_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print(note)
