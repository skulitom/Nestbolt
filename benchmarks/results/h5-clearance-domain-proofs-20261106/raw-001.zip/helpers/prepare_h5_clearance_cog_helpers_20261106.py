from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'prepare_h5_source_cog_cell_pruning_20261106.py').read_text(encoding='utf-8')
s=s.replace("OUT=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106'","OUT=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'")
s=s.replace("AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106';FRONTIER=ROOT/'output/h5-first57-union-augmented-trees-20261106'","AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106';FRONTIER=ROOT/'output/h5-first57-cog-union-subdivision-20261106'\nJOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'")
a="""selection=[r['source_selection']|{'augmentation_index':r['augmentation_index']}
           for r in load(AUG/'audit/stronger-model-candidates.json') if tuple(r['source_selection']['empty_sites']) in remaining]
assert len(selection)==39"""
b="""selection=[r|{'subdivision_index':i} for i,r in enumerate(load(FRONTIER/'plan.json')['selection']) if tuple(r['empty_sites']) in remaining]
assert len(selection)==28
job=load(JOB);radius_um=199
assert F(job['clearance'])>F(radius_um,1000)>0"""
assert a in s;s=s.replace(a,b)
s=s.replace("inputs=[Path(__file__),PIECES,","inputs=[Path(__file__),ROOT/'output/prepare_h5_clearance_cog_helpers_20261106.py',ROOT/'output/prepare_h5_source_cog_cell_pruning_20261106.py',JOB,FRONTIER/'plan.json',PIECES,")
a='+[INS/f"choice-{r[\'insert_choice_index\']:02d}.json" for r in selection]'
assert a in s;s=s.replace(a,a+'+[FRONTIER/f"choice-{r[\'subdivision_index\']:02d}.json" for r in selection]')
s=s.replace("'selection':selection,'scan_cutoff_seconds':25","'selection':selection,'required_job_clearance_mm':job['clearance'],'clearance_diamond_radius_um':radius_um,'zero_clearance_exclusion_claimed':False,'scan_cutoff_seconds':25")
start=s.index("    'method':");end=s.index('\ngeometry=load',start)
s=s[:start]+"""    'method':'Use the original job clearance0.2mm without changing it. Expand each exact source cog-piece/moving-inner-rectangle collision polygon by a closed L1 diamond of radius199 micrometres, strictly below the required clearance. That diamond lies inside the Euclidean radius199um disk, so every anchor in the expanded Minkowski sum has source-body distance at most0.199mm and cannot satisfy the job clearance. Exact integer hull and closed-cell corner proofs certify removals. Preserve all prior source-polygon/union removals and all unproved retained cells. These necessary domains apply to the required clearance; no new zero-clearance exclusion is claimed. Float bounds only prefilter exact proofs; incomplete scans remain safe. No placement/native call or full construction budget is claimed.',
    'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,'full_construction_budget_claimed':False})
""" + s[end:]
s=s.replace("'scaled_units_per_micrometre':str(D),'rotation_radians':angle","'scaled_units_per_micrometre':str(D),'clearance_diamond_radius_um':radius_um,'required_job_clearance_mm':job['clearance'],'rotation_radians':angle")
a="polygon=hull([(x-u,y-v) for x,y in p for u,v in corners]);assert len(polygon)>=3"
b="polygon=hull([(x-u+dx,y-v+dy) for x,y in p for u,v in corners for dx,dy in [(radius_um*D,0),(-radius_um*D,0),(0,radius_um*D),(0,-radius_um*D)]]);assert len(polygon)>=3"
assert a in s;s=s.replace(a,b)
a="""    present=((1<<15)-1)^sum(1<<i for i in row['empty_sites']);mapping=[]
    for node in br['nodes']+ins['nodes']:"""
b="""    present=((1<<15)-1)^sum(1<<i for i in row['empty_sites']);mapping=[]
    parent=load(FRONTIER/f"choice-{row['subdivision_index']:02d}.json")
    retained=set(parent['retained_bracket_nodes']+parent['retained_insert_nodes'])
    for ni,node in enumerate(br['nodes']+ins['nodes']):"""
assert a in s;s=s.replace(a,b)
a="        index=cell_by_key[key];cells[index]['relevant_site_bits']|=present;mapping.append(index)"
b="""        index=cell_by_key[key]
        if ni in retained:cells[index]['relevant_site_bits']|=present
        mapping.append(index)"""
assert a in s;s=s.replace(a,b)
a="""    omitted=set(row['empty_sites']);removed=[]
    for node,cell in enumerate(mapping):"""
b="""    omitted=set(row['empty_sites']);removed=[]
    parent=load(FRONTIER/f"choice-{row['subdivision_index']:02d}.json")
    parent_nodes=parent['retained_bracket_nodes']+parent['retained_insert_nodes']
    for node in parent_nodes:
        cell=mapping[node]"""
assert a in s;s=s.replace(a,b)
a="remove={r['node'] for r in removed};retained_br=sorted(set(range(offset))-remove);retained_ins=sorted(set(range(offset,len(mapping)))-remove)"
b="remove={r['node'] for r in removed};retained_br=sorted(set(parent['retained_bracket_nodes'])-remove);retained_ins=sorted(set(parent['retained_insert_nodes'])-remove)"
assert a in s;s=s.replace(a,b)
s=s.replace("'whole_arrangements_excluded':0,'remaining_fixed29_choices':39","'whole_arrangements_excluded':0,'remaining_fixed29_choices':28,'zero_clearance_exclusion_claimed':False")
with (O/'prepare_h5_clearance_cog_pruning_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_source_cog_cell_pruning_20261106.py').read_text(encoding='utf-8')
s=s.replace('source-cog-cell-pruning','clearance-cog-pruning').replace('prepare_h5_source_cog_cell_pruning','prepare_h5_clearance_cog_pruning')
with (O/'run_h5_clearance_cog_pruning_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared a distinct source-clearance proof at199um, below the original0.2mm job clearance.')
