from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-clearance-domain-proofs-20261106';OUT=ROOT/'benchmarks/results'/NAME
SUB=ROOT/'output/h5-first57-cog-union-subdivision-20261106';CLEAR=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'
BASE=ROOT/'output/h5-first57-clearance-cog-trees-20261106'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
sa=load(SUB/'audit/checks.json');ca=load(CLEAR/'audit-v2/checks.json');ta=load(BASE/'audit/checks.json')
assert all(a['passed'] for a in [sa,ca,ta])
assert sa['new_removed_node_occurrences']==5 and ca['removed_node_occurrences_verified']==45
assert ta['new_fixed29_choices_excluded']==0 and ta['remaining_fixed29_choices']==28
assert ta['tree_records_verified']==18942 and ta['total_joint_graph_witnesses']==9 and len(ta['budget_limited_cases'])==18
process_folders=[ROOT/'output'/f'h5-first57-{n}-process-20261106' for n in ['cog-union-subdivision','clearance-cog-pruning','clearance-cog-trees']]
processes=[load(p/'process.json') for p in process_folders]
assert all(p['closed'] and p['exit_code']==0 and not p['timeout'] and p['complete_process_cap_overrun_seconds']==0 for p in processes)
assert ta['case_complete_cap_overrun_seconds']==0 and sa['query_complete_cap_overrun_seconds']==0
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104','h5-source-polygons-and-joint-frontier-20261104','h5-mandatory-clique-exclusions-20261104','h5-full-frontier-proofs-20261106','h5-frontier-insert-exclusions-20261106','h5-deferred-conflict-tree-20261106','h5-optional-bracket-trees-20261106','h5-joint-optional-trees-20261106','h5-union-augmented-proofs-20261106','h5-source-cog-pruned-proofs-20261106']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for folder in [SUB,CLEAR,BASE]+process_folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_cog_union_subdivision*20261106.py','*h5_clearance_cog*20261106.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-clearance-proof-scope-correction-20261106.json','h5-clearance-domain-proofs-report-20261106.md']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(SUB/'audit/checks.json','union-subdivision-audit.json'),(CLEAR/'audit/checks.json','clearance-audit-v1.json'),(CLEAR/'audit-v2/checks.json','clearance-audit-v2.json'),(BASE/'audit/checks.json','tree-audit.json'),(BASE/'audit/remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(BASE/'audit/joint-graph-witnesses.json','joint-graph-witnesses.json'),(ROOT/'output/h5-clearance-proof-scope-correction-20261106.json','proof-scope-correction.json')]:
    shutil.copyfile(source,OUT/name)
write(OUT/'process-ledger.json',{'new_complete_preparation_seconds':sum(p['complete_process_seconds'] for p in processes),'processes':processes,
    'independent_audit_seconds':[sa['seconds'],ca['seconds'],ta['seconds']],'tree_limited_cases':18,'unchanged_case_not_repeated':True,
    'all_processes_closed':True,'case_complete_cap_overrun_seconds':0,'placement_solver_calls':0,'native_calls':0,'full_construction_60_90_budget_claimed':False})
write(OUT/'next-step.json',{'all_prior_processes_closed':True,'remaining_fixed29_choices':28,'total_fixed29_choices_excluded':427,
    'next_method':'Assess clearance-aware source-inner pair conflicts. Expand each exact component difference rectangle by a140 micrometre axis square. Every square vector has Euclidean length at most sqrt(2)*140 micrometres, strictly below the original200 micrometre clearance. Thus coverage of a complete closed relative-anchor box by the union of open expanded rectangles can prove required-clearance incompatibility even where zero-clearance conflicts are unproved. Independently verify the original job clearance, squared-norm bound, exact union coverage on every boundary/open-interval class, retention of all existing domains and edges, and every new edge. Freeze scan/process limits; partial scans assert only edge safety. Run no new tree until genuinely new constraints are verified, omit unchanged cases, preserve every open outcome, and distinguish required-clearance exclusions from zero-clearance proofs. Charge all consumed preparation before any construction budget claim.',
    'survivors':'output/h5-first57-clearance-cog-trees-20261106/audit/remaining-fixed29-choices.json',
    'retained_domains':'output/h5-first57-clearance-cog-pruning-20261106',
    'source_inner_geometry':'output/h5-first57-necessary-rectangles-20261104/geometry-domains.json',
    'union_predicate_audit':'output/h5-first57-union-conflict-probe-20261106/audit-v2',
    'new_pair_clearance_model_prepared':False,'whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'new_continuous_choices_excluded':0,'remaining_fixed29_choices':28,'total_fixed29_choices_excluded':427,'original_fixed29_choices':455,
    'union_removed_node_occurrences':5,'clearance_removed_node_occurrences':45,'genuinely_stronger_tree_cases':27,'unchanged_cases_not_repeated':1,
    'required_job_clearance_mm':0.2,'conservative_clearance_radius_um':199,'zero_clearance_exclusion_claimed':False,
    **{k:ta[k] for k in ['tree_records_verified','branch_cliques','closed_count_leaves','propagation_covers','propagation_removals','mandatory_support_pair_checks','clique_pair_checks','strict_source_inner_pair_evaluations']},
    'new_joint_graph_witnesses':9,'limited_joint_cases':18,'placement_solver_calls':0,'native_calls':0,
    'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-clearance-domain-proofs-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 union and clearance domains:** [independent source and tree audits]({link}) verify five node removals from exact polygon-union subdivision and 45 further removals using a 0.199 mm source-distance bound below the original 0.2 mm clearance. The combined domains strengthen 27 cases; the unchanged case is not rerun. Independent replay verifies 18,942 records and 564,916 ordered removals, with nine necessary graph witnesses and eighteen cutoff cases. No further whole arrangement is excluded: 28 remain, with 427 of 455 previously excluded. Complete preparations take 1.433914, 2.162237 and 18.790352 s; all complete-case/process caps pass. A versioned correction fixes the first clearance audit’s overlap wording; numerical checks were unchanged, and both versions remain preserved. Next assess exact clearance-aware pair conflicts using conservative square expansions of source-inner difference rectangles. No placement/native call or full construction budget is claimed. Full66 checks, 440 whole allocations and H2/H5 remain open at 60%; all prior processes stay closed.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8')
a='Latest H5 evidence: [original-source cog pruning](../benchmarks/results/h5-source-cog-pruned-proofs-20261106.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [union and clearance domains](../benchmarks/results/{NAME}.md).',1)
a='and 18 cutoff cases. Exact subdivision proofs for unions of source collision\npolygons are next. All prior calls and bounded processes stay closed.'
b='and 18 cutoff cases. Union subdivision and clearance-aware cog proofs remove\n50 more node occurrences across 27 cases, but exclude no further arrangement.\nThe new trees retain nine necessary graph witnesses and eighteen cutoff cases;\none unchanged case is carried forward. Exact clearance-aware pair conflicts\nare next. All prior calls and bounded processes stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
