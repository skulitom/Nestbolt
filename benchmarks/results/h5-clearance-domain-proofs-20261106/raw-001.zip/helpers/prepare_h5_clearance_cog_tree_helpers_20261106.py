from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'prepare_h5_cog_pruned_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-cog-pruned-trees-20261106','h5-first57-clearance-cog-trees-20261106')
s=s.replace("FRONTIER=ROOT/'output/h5-first57-union-augmented-trees-20261106'","FRONTIER=ROOT/'output/h5-first57-cog-pruned-trees-20261106'")
s=s.replace('h5-first57-source-cog-cell-pruning-20261106','h5-first57-clearance-cog-pruning-20261106')
s=s.replace("for b in [BR,INS,FRONTIER,AUG,PRUNE]:assert load(b/'audit/checks.json')['passed']","for b in [BR,INS,FRONTIER,AUG]:assert load(b/'audit/checks.json')['passed']\nassert load(PRUNE/'audit-v2/checks.json')['passed']")
s=s.replace("PRUNE/'audit/stronger-model-candidates.json'","PRUNE/'audit-v2/stronger-model-candidates.json'")
s=s.replace("{'pruning_index':r['pruning_index']}","{'clearance_pruning_index':r['clearance_pruning_index']}")
s=s.replace('len(selection)==39','len(selection)==27')
s=s.replace("row['pruning_index']","row['clearance_pruning_index']").replace("r['pruning_index']","r['clearance_pruning_index']")
s=s.replace("inputs=[Path(__file__),","inputs=[Path(__file__),ROOT/'output/prepare_h5_clearance_cog_tree_helpers_20261106.py',ROOT/'output/prepare_h5_cog_pruned_trees_20261106.py',PRUNE/'audit-v2/plan.json',PRUNE/'audit-v2/checks.json',")
s=s.replace("for b in [BR,INS,FRONTIER,AUG,PRUNE] for n","for b in [BR,INS,FRONTIER,AUG] for n")
start=s.index("    'method':");end=s.index('\nsummaries=[]',start)
s=s[:start]+"""    'required_job_clearance_mm':0.2,'conservative_clearance_radius_um':199,'zero_clearance_exclusion_claimed':False,
    'method':'Distinct necessary model on27 cases with strictly smaller independently certified domains. Preserve source-polygon union subdivision removals and remove only additional cells certified within199 micrometres of a present original cog, below the original200 micrometre required clearance. Retain all other cells, source aliases and previous pair conflict edges. Fresh0.70/0.75-second case caps,1500 nodes and50/55/65 global caps. Complete include/skip trees alone exclude fixed29/current cog poses at required0.2mm clearance. Open graph witnesses are not source placements. The unchanged28th case is not rerun. No prior bounded process is repeated or extended.'})
""" + s[end:]
with (O/'prepare_h5_clearance_cog_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_cog_pruned_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace('cog-pruned-trees','clearance-cog-trees').replace('prepare_h5_cog_pruned_trees','prepare_h5_clearance_cog_trees')
with (O/'run_h5_clearance_cog_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared a distinct27-case clearance-domain tree.')
