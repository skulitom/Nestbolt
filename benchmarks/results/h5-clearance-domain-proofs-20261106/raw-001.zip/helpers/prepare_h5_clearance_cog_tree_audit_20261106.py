from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_cog_pruned_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'output/h5-first57-cog-pruned-trees-20261106'","BASE=ROOT/'output/h5-first57-clearance-cog-trees-20261106'")
s=s.replace("FRONTIER=ROOT/'output/h5-first57-union-augmented-trees-20261106'","FRONTIER=ROOT/'output/h5-first57-cog-pruned-trees-20261106'")
s=s.replace('h5-first57-cog-pruned-trees-process-20261106','h5-first57-clearance-cog-trees-process-20261106')
s=s.replace("PRUNE=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106'","PRUNE=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'\nSUB=ROOT/'output/h5-first57-cog-union-subdivision-20261106'\nJOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'")
s=s.replace("inputs={Path(__file__),","inputs={Path(__file__),ROOT/'output/prepare_h5_clearance_cog_tree_audit_20261106.py',ROOT/'output/audit_h5_cog_pruned_trees_20261106.py',JOB,")
s=s.replace("PRUNE/'audit/stronger-model-candidates.json'","PRUNE/'audit-v2/stronger-model-candidates.json'")
s=s.replace("AUG/'audit',PRUNE/'audit']","AUG/'audit',PRUNE/'audit-v2',SUB/'audit']")
s=s.replace("for base in [BR,INS,FRONTIER,AUG,PRUNE]:","for base in [BR,INS,FRONTIER,AUG,SUB]:")
s=s.replace("process=load(PROCESS/'process.json')","inputs.add(PRUNE/'audit-v2/checks.json');assert load(PRUNE/'audit-v2/checks.json')['passed']\nprocess=load(PROCESS/'process.json')")
s=s.replace("{'pruning_index':r['pruning_index']}","{'clearance_pruning_index':r['clearance_pruning_index']}")
s=s.replace('len(selection)==39','len(selection)==27')
s=s.replace("row['pruning_index']","row['clearance_pruning_index']")
a="root_removals=0;root_corner_checks=0"
b="""root_removals=0;root_corner_checks=0;parent_union_removals=0
assert load(JOB)['clearance']==0.2
assert integer_source['required_job_clearance_mm']==0.2 and integer_source['clearance_diamond_radius_um']==199
assert 199<200
for x,y in [(199,0),(0,199),(-199,0),(0,-199)]:assert x*x+y*y==199**2<200**2
assert plan['required_job_clearance_mm']==0.2 and plan['conservative_clearance_radius_um']==199 and not plan['zero_clearance_exclusion_claimed']
"""
assert a in s;s=s.replace(a,b)
a="""    assert pruning['retained_bracket_nodes']==sorted(set(range(offset))-removed)
    assert pruning['retained_insert_nodes']==sorted(set(range(offset,len(nodes)))-removed)"""
b="""    parent_path=SUB/f"choice-{row['subdivision_index']:02d}.json";inputs.add(parent_path);parent=load(parent_path)
    assert parent['empty_sites']==row['empty_sites'] and parent['original_bracket_node_count']==offset
    parent_b=set(parent['retained_bracket_nodes']);parent_i=set(parent['retained_insert_nodes'])
    assert parent_b<=set(range(offset)) and parent_i<=set(range(offset,len(nodes)))
    assert removed<=parent_b|parent_i and removed
    assert pruning['retained_bracket_nodes']==sorted(parent_b-removed)
    assert pruning['retained_insert_nodes']==sorted(parent_i-removed)
    parent_union_removals+=len(parent['additional_removed'])"""
assert a in s;s=s.replace(a,b)
s=s.replace('assert len(prior)==39','assert len(prior)==28')
s=s.replace("'previous_fixed29_choices_excluded':416","'previous_fixed29_choices_excluded':427").replace("'total_fixed29_choices_excluded':416+len(removed)","'total_fixed29_choices_excluded':427+len(removed)")
s=s.replace("'original_source_root_removals_verified':root_removals,","'clearance_root_removals_verified':root_removals,'inherited_union_root_removals':parent_union_removals,'required_job_clearance_mm':0.2,'conservative_clearance_radius_um':199,'zero_clearance_exclusion_claimed':False,")
s=s.replace("Every root cover is the complete prior domain minus only independently certified original-source cog collisions. Every removed cell and present-site certificate is replayed with exact integer corner halfplanes, all other cells remain, and every case has a strictly smaller source-certified root domain.","Every root cover is the independently certified polygon-union parent domain minus only additional clearance-invalid cells. Exact integer corner halfplanes replay every removal. The independently audited Minkowski polygons add a199 micrometre L1 diamond, contained inside the199 micrometre Euclidean ball, strictly below the original200 micrometre requirement. Membership proves source separation below required clearance; it does not prove zero-clearance overlap. Every other parent cell remains, and each of27 cases has a strictly smaller certified domain.")
s=s.replace("at zero clearance, not whole allocations or changed placements.","at the original required0.2mm clearance, not at zero clearance and not whole allocations or changed placements.")
with (O/'audit_h5_clearance_cog_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared independent clearance-root and complete27-case tree replay.')
