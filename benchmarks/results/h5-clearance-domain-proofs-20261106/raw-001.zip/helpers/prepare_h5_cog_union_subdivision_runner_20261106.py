from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_source_cog_cell_pruning_20261106.py').read_text(encoding='utf-8')
s=s.replace('source-cog-cell-pruning','cog-union-subdivision').replace('prepare_h5_source_cog_cell_pruning','prepare_h5_cog_union_subdivision')
with (O/'run_h5_cog_union_subdivision_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
