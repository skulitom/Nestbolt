"""Certify whole anchor cells blocked by original convex cog pieces."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product
import json,time,shutil,math
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106';FRONTIER=ROOT/'output/h5-first57-cog-union-subdivision-20261106'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';PRE=ROOT/'output/h5-first57-direct-short9-20261104'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
    points=sorted(set(points));lower=[];upper=[]
    for p in points:
        while len(lower)>1 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
        lower.append(p)
    for p in reversed(points):
        while len(upper)>1 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
        upper.append(p)
    return lower[:-1]+upper[:-1]
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for b in [BR,INS,AUG,FRONTIER,SOURCE,PRE]:assert load(b/'audit/checks.json')['passed']
remaining={tuple(r['empty_sites']) for r in load(FRONTIER/'audit/remaining-fixed29-choices.json')}
selection=[r|{'subdivision_index':i} for i,r in enumerate(load(FRONTIER/'plan.json')['selection']) if tuple(r['empty_sites']) in remaining]
assert len(selection)==28
job=load(JOB);radius_um=199
assert F(job['clearance'])>F(radius_um,1000)>0
inputs=[Path(__file__),ROOT/'output/prepare_h5_clearance_cog_helpers_20261106.py',ROOT/'output/prepare_h5_source_cog_cell_pruning_20261106.py',JOB,FRONTIER/'plan.json',PIECES,PRE/'source-cog-sites.json',SOURCE/'geometry-domains.json',SOURCE/'audit/exact-source-partitions.json',
        FRONTIER/'audit/remaining-fixed29-choices.json',AUG/'audit/stronger-model-candidates.json']+[b/n for b in [BR,INS,AUG,FRONTIER,SOURCE,PRE] for n in ['audit/plan.json','audit/checks.json']]+[BR/f"choice-{r['choice_index']:02d}.json" for r in selection]+[INS/f"choice-{r['insert_choice_index']:02d}.json" for r in selection]+[FRONTIER/f"choice-{r['subdivision_index']:02d}.json" for r in selection]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'selection':selection,'required_job_clearance_mm':job['clearance'],'clearance_diamond_radius_um':radius_um,'zero_clearance_exclusion_claimed':False,'scan_cutoff_seconds':25,'preparation_cap_seconds':35,'maximum_process_seconds':45,
    'method':'Use the original job clearance0.2mm without changing it. Expand each exact source cog-piece/moving-inner-rectangle collision polygon by a closed L1 diamond of radius199 micrometres, strictly below the required clearance. That diamond lies inside the Euclidean radius199um disk, so every anchor in the expanded Minkowski sum has source-body distance at most0.199mm and cannot satisfy the job clearance. Exact integer hull and closed-cell corner proofs certify removals. Preserve all prior source-polygon/union removals and all unproved retained cells. These necessary domains apply to the required clearance; no new zero-clearance exclusion is claimed. Float bounds only prefilter exact proofs; incomplete scans remain safe. No placement/native call or full construction budget is claimed.',
    'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,'full_construction_budget_claimed':False})

geometry=load(SOURCE/'geometry-domains.json');canonical=load(PIECES)['cog'];sites=load(PRE/'source-cog-sites.json');assert len(sites)==15 and len(canonical)==21
angle=sites[0]['transform']['rotation_radians'];mirrored=sites[0]['transform']['mirrored'];c,s=F(math.cos(angle)),F(math.sin(angle));m=-1 if mirrored else 1
assert all(r['transform']['rotation_radians']==angle and r['transform']['mirrored']==mirrored for r in sites)
normalized=[[(1000*(m*F(x)*c-F(y)*s),1000*(m*F(x)*s+F(y)*c)) for x,y in p] for p in canonical]
translations=[[1000*F(v) for v in row['transform']['translation']] for row in sites]
denominators=[v.denominator for p in normalized for point in p for v in point]+[v.denominator for p in translations for v in p]
D=math.lcm(*denominators)
assert all((v*D).denominator==1 for p in normalized for point in p for v in point)
pieces=[[(int(x*D),int(y*D)) for x,y in p] for p in normalized]
shifts=[tuple(int(v*D) for v in t) for t in translations]
write(OUT/'integer-source.json',{'scaled_units_per_micrometre':str(D),'clearance_diamond_radius_um':radius_um,'required_job_clearance_mm':job['clearance'],'rotation_radians':angle,'mirrored':mirrored,
    'cosine_rational':str(c),'sine_rational':str(s),
    'normalized_cog_pieces':[[[str(x),str(y)] for x,y in p] for p in pieces],
    'sites':[{'site':i,'source':row,'translation_scaled':list(map(str,shifts[i]))} for i,row in enumerate(sites)]})
templates=[];exact=[]
for g in geometry:
    for ri,r in enumerate(g['inner_rectangles_um']):
        corners=list(product([r[0]*D,r[2]*D],[r[1]*D,r[3]*D]))
        for pi,p in enumerate(pieces):
            polygon=hull([(x-u+dx,y-v+dy) for x,y in p for u,v in corners for dx,dy in [(radius_um*D,0),(-radius_um*D,0),(0,radius_um*D),(0,-radius_um*D)]]);assert len(polygon)>=3
            exact.append(polygon)
            templates.append({'template':len(templates),'geometry':g['geometry'],'component':ri,'source_piece':pi,
                'vertices_scaled':[[str(x),str(y)] for x,y in polygon]})
write(OUT/'collision-polygons.json',templates)
cells=[];cell_by_key={};mappings=[]
for row in selection:
    br=load(BR/f"choice-{row['choice_index']:02d}.json");ins=load(INS/f"choice-{row['insert_choice_index']:02d}.json")
    assert br['empty_sites']==ins['empty_sites']==row['empty_sites']
    present=((1<<15)-1)^sum(1<<i for i in row['empty_sites']);mapping=[]
    parent=load(FRONTIER/f"choice-{row['subdivision_index']:02d}.json")
    retained=set(parent['retained_bracket_nodes']+parent['retained_insert_nodes'])
    for ni,node in enumerate(br['nodes']+ins['nodes']):
        key=(node['geometry'],*node['bounds_um'])
        if key not in cell_by_key:
            cell_by_key[key]=len(cells);cells.append({'cell':len(cells),'geometry':node['geometry'],'bounds_um':node['bounds_um'],'relevant_site_bits':0})
        index=cell_by_key[key]
        if ni in retained:cells[index]['relevant_site_bits']|=present
        mapping.append(index)
    mappings.append((len(br['nodes']),mapping))
write(OUT/'cells.json',cells)
by_geometry={g:np.array([i for i,row in enumerate(cells) if row['geometry']==g],dtype=np.int64) for g in range(10)}
bounds=np.array([row['bounds_um'] for row in cells],dtype=np.float64)
relevance=np.array([row['relevant_site_bits'] for row in cells],dtype=np.int64)
proofs=[];proof_by_cell_site={};scan_complete=True;checked=0;completed_template_sites=0
for template,poly in zip(templates,exact):
    indices=by_geometry[template['geometry']]
    local=[min(p[0] for p in poly)/D,min(p[1] for p in poly)/D,max(p[0] for p in poly)/D,max(p[1] for p in poly)/D]
    for site,shift in enumerate(shifts):
        if time.perf_counter()-started>=25:scan_complete=False;break
        dx,dy=shift[0]/D,shift[1]/D;v=bounds[indices]
        selected=(v[:,0]>=local[0]+dx-1e-6)&(v[:,1]>=local[1]+dy-1e-6)&(v[:,2]<=local[2]+dx+1e-6)&(v[:,3]<=local[3]+dy+1e-6)&((relevance[indices]&(1<<site))!=0)
        for index in indices[selected]:
            index=int(index)
            if (index,site) in proof_by_cell_site:continue
            if checked%32==0 and time.perf_counter()-started>=25:scan_complete=False;break
            checked+=1;a,b,z,w=cells[index]['bounds_um']
            corners=[(x*D-shift[0],y*D-shift[1]) for x,y in product([a,z],[b,w])]
            if all(cross(p,q,v)>0 for p,q in zip(poly,poly[1:]+poly[:1]) for v in corners):
                proof_by_cell_site[index,site]=len(proofs)
                proofs.append({'certificate':len(proofs),'cell':index,'site':site,'template':template['template']})
        if not scan_complete:break
        completed_template_sites+=1
    if not scan_complete:break
write(OUT/'certificates.json',proofs)
summaries=[]
for choice,(row,(offset,mapping)) in enumerate(zip(selection,mappings)):
    omitted=set(row['empty_sites']);removed=[]
    parent=load(FRONTIER/f"choice-{row['subdivision_index']:02d}.json")
    parent_nodes=parent['retained_bracket_nodes']+parent['retained_insert_nodes']
    for node in parent_nodes:
        cell=mapping[node]
        for site in range(15):
            if site not in omitted and (cell,site) in proof_by_cell_site:
                removed.append({'node':node,'certificate':proof_by_cell_site[cell,site]});break
    remove={r['node'] for r in removed};retained_br=sorted(set(parent['retained_bracket_nodes'])-remove);retained_ins=sorted(set(parent['retained_insert_nodes'])-remove)
    result={'source_selection':row,'empty_sites':row['empty_sites'],'original_bracket_node_count':offset,
        'node_cells':mapping,'removed':removed,'retained_bracket_nodes':retained_br,'retained_insert_nodes':retained_ins,
        'whole_arrangement_excluded':False}
    write(OUT/f'choice-{choice:02d}.json',result)
    summaries.append({'empty_sites':row['empty_sites'],'original_nodes':len(mapping),'certified_removed_nodes':len(remove),
        'remaining_bracket_nodes':len(retained_br),'remaining_insert_nodes':len(retained_ins)})
elapsed=time.perf_counter()-started
write(OUT/'checks.json',{'prepared':True,'seconds':elapsed,'choices':summaries,'exact_collision_polygons':len(templates),
    'unique_source_cells':len(cells),'source_collision_certificates':len(proofs),'candidate_corner_checks':checked,
    'completed_template_site_pairs':completed_template_sites,'reported_scan_complete':scan_complete,
    'removed_node_occurrences':sum(r['certified_removed_nodes'] for r in summaries),
    'cases_with_pruning':sum(r['certified_removed_nodes']>0 for r in summaries),'independent_audit_pending':True,
    'whole_arrangements_excluded':0,'remaining_fixed29_choices':28,'zero_clearance_exclusion_claimed':False,'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
assert elapsed<35
print({'seconds':elapsed,'polygons':len(templates),'source_cells':len(cells),'certificates':len(proofs),
    'removed_nodes':sum(r['certified_removed_nodes'] for r in summaries),'cases_with_pruning':sum(r['certified_removed_nodes']>0 for r in summaries),'scan_complete':scan_complete})
