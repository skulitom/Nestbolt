"""Bounded exact source-polygon union coverage over retained closed cells."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-cog-union-subdivision-20261106'
PRUNE=ROOT/'output/h5-first57-source-cog-cell-pruning-20261106';FRONTIER=ROOT/'output/h5-first57-cog-pruned-trees-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(PRUNE/'audit/checks.json')['passed'] and load(FRONTIER/'audit/checks.json')['passed']
remaining={tuple(r['empty_sites']) for r in load(FRONTIER/'audit/remaining-fixed29-choices.json')}
selection=[r['source_selection']|{'pruning_index':r['pruning_index']} for r in load(PRUNE/'audit/stronger-model-candidates.json') if tuple(r['source_selection']['empty_sites']) in remaining]
assert len(selection)==28
inputs=[Path(__file__),FRONTIER/'audit/remaining-fixed29-choices.json',PRUNE/'audit/stronger-model-candidates.json']+[b/n for b in [PRUNE,FRONTIER] for n in ['audit/plan.json','audit/checks.json']]+[PRUNE/n for n in ['integer-source.json','cells.json','collision-polygons.json']]+[PRUNE/f"choice-{r['pruning_index']:02d}.json" for r in selection]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'selection':selection,'maximum_subdivision_depth':8,'maximum_expanded_nodes_per_query':511,
    'query_search_cutoff_seconds':0.02,'query_complete_cap_seconds':0.05,'global_query_cutoff_seconds':25,
    'preparation_cap_seconds':35,'maximum_process_seconds':45,'repeat_permitted':False,
    'method':'For every retained source cell in28 arrangements, exactly enumerate all present-cog collision polygons whose closed bounding boxes meet the cell. Cache only identical cell/candidate-set queries. A leaf closes if its entire closed subbox lies strictly inside one certified source polygon. Otherwise an exact sample outside every candidate polygon leaves the whole root unresolved. If all samples are covered, bisect the longest axis at an exact integer-scaled interior coordinate. Both closed children exactly cover their parent. Only entirely closed trees remove a root cell. Depth/node/time limits and skipped siblings create explicit open leaves. Every unproved original cell is retained. No placement or whole-arrangement exclusion is claimed by preparation.'})
integer=load(PRUNE/'integer-source.json');D=int(integer['scaled_units_per_micrometre'])
cells=load(PRUNE/'cells.json');templates=load(PRUNE/'collision-polygons.json')
shifts=[tuple(map(int,r['translation_scaled'])) for r in integer['sites']]
world=[];by_geometry={g:[] for g in range(10)}
for t in templates:
    local=[tuple(map(int,p)) for p in t['vertices_scaled']]
    for site,(sx,sy) in enumerate(shifts):
        poly=[(x+sx,y+sy) for x,y in local]
        planes=[]
        for a,b in zip(poly,poly[1:]+poly[:1]):
            nx,ny=a[1]-b[1],b[0]-a[0];planes.append((nx,ny,-nx*a[0]-ny*a[1]))
        record={'polygon':len(world),'template':t['template'],'site':site,'geometry':t['geometry'],
                'bounds':(min(x for x,y in poly),min(y for x,y in poly),max(x for x,y in poly),max(y for x,y in poly)),
                'planes':planes}
        world.append(record);by_geometry[t['geometry']].append(record['polygon'])
def meets(a,b):return a[0]<=b[2] and b[0]<=a[2] and a[1]<=b[3] and b[1]<=a[3]
def box_inside(box,pi):
    return all(nx*(box[0] if nx>=0 else box[2])+ny*(box[1] if ny>=0 else box[3])+c>0 for nx,ny,c in world[pi]['planes'])
def point_inside(point,pi):return all(nx*point[0]+ny*point[1]+c>0 for nx,ny,c in world[pi]['planes'])
cell_candidates={};query_by_key={};queries=[];cases=[];expanded_total=0
for choice,row in enumerate(selection):
    data=load(PRUNE/f"choice-{row['pruning_index']:02d}.json");present=((1<<15)-1)^sum(1<<i for i in row['empty_sites'])
    references=[];additional=[]
    for node in data['retained_bracket_nodes']+data['retained_insert_nodes']:
        ci=data['node_cells'][node];cell=cells[ci];box=tuple(v*D for v in cell['bounds_um'])
        if ci not in cell_candidates:
            cell_candidates[ci]=tuple(pi for pi in by_geometry[cell['geometry']] if meets(box,world[pi]['bounds']))
        candidates=tuple(pi for pi in cell_candidates[ci] if present&(1<<world[pi]['site']))
        key=(ci,candidates)
        if key not in query_by_key:
            qi=len(queries);query_by_key[key]=qi;records=[];query_started=time.perf_counter();deadline=min(started+25,query_started+0.02)
            expanded=[0]
            def visit(bounds,depth,allowed,skip=False):
                index=len(records);record={'node':index};records.append(record)
                if skip:
                    record.update({'kind':'open','reason':'earlier_unproved_child'});return index,False
                if time.perf_counter()>=deadline or expanded[0]>=511:
                    record.update({'kind':'open','reason':'time_or_node_limit',
                        'query_elapsed':time.perf_counter()-query_started,'global_elapsed':time.perf_counter()-started});return index,False
                expanded[0]+=1
                allowed=[pi for pi in allowed if meets(bounds,world[pi]['bounds'])]
                for pi in allowed:
                    if box_inside(bounds,pi):record.update({'kind':'closed_source_polygon','polygon':pi});return index,True
                samples=[((bounds[0]+bounds[2])//2,(bounds[1]+bounds[3])//2)]+list(product([bounds[0],bounds[2]],[bounds[1],bounds[3]]))
                for point in samples:
                    if not any(point_inside(point,pi) for pi in allowed):
                        record.update({'kind':'open_source_inner_sample','point_scaled':list(map(str,point))});return index,False
                if depth>=8:
                    record.update({'kind':'open','reason':'depth_limit'});return index,False
                axis=max(range(2),key=lambda a:bounds[a+2]-bounds[a]);cut=(bounds[axis]+bounds[axis+2])//2
                if not bounds[axis]<cut<bounds[axis+2]:
                    record.update({'kind':'open','reason':'no_interior_split'});return index,False
                lo=list(bounds);hi=list(bounds);lo[axis+2]=cut;hi[axis]=cut
                left,lc=visit(tuple(lo),depth+1,allowed)
                right,rc=visit(tuple(hi),depth+1,allowed,skip=not lc)
                record.update({'kind':'split','axis':axis,'cut_scaled':str(cut),'left':left,'right':right})
                return index,lc and rc
            root,closed=visit(box,0,list(candidates))
            elapsed=time.perf_counter()-query_started;expanded_total+=expanded[0]
            queries.append({'query':qi,'source_cell':ci,'candidate_polygons':list(candidates),'root':root,'records':records,
                'expanded_nodes':expanded[0],'query_seconds':elapsed,'query_complete_cap_overrun_seconds':max(0,elapsed-0.05),
                'whole_closed_cell_covered':closed})
        qi=query_by_key[key];references.append({'node':node,'query':qi})
        if queries[qi]['whole_closed_cell_covered']:additional.append({'node':node,'query':qi})
    removed={r['node'] for r in additional}
    result={'source_selection':row,'empty_sites':row['empty_sites'],'original_bracket_node_count':data['original_bracket_node_count'],
        'node_queries':references,'additional_removed':additional,
        'retained_bracket_nodes':[n for n in data['retained_bracket_nodes'] if n not in removed],
        'retained_insert_nodes':[n for n in data['retained_insert_nodes'] if n not in removed],
        'whole_arrangement_excluded':False}
    write(OUT/f'choice-{choice:02d}.json',result)
    cases.append({'empty_sites':row['empty_sites'],'previously_retained_nodes':len(references),'new_removed_nodes':len(additional)})
    assert time.perf_counter()-started<35
write(OUT/'queries.json',queries)
elapsed=time.perf_counter()-started
write(OUT/'checks.json',{'prepared':True,'seconds':elapsed,'choices':cases,'world_source_polygons':len(world),
    'distinct_source_cells':len(cell_candidates),'cached_queries':len(queries),'expanded_nodes':expanded_total,
    'closed_cell_queries':sum(q['whole_closed_cell_covered'] for q in queries),
    'new_removed_node_occurrences':sum(r['new_removed_nodes'] for r in cases),
    'cases_with_new_pruning':sum(r['new_removed_nodes']>0 for r in cases),
    'query_complete_cap_overrun_seconds':sum(q['query_complete_cap_overrun_seconds'] for q in queries),
    'independent_audit_pending':True,'whole_arrangements_excluded':0,'remaining_fixed29_choices':28,
    'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
assert elapsed<35
print({'seconds':elapsed,'cached_queries':len(queries),'closed_cell_queries':sum(q['whole_closed_cell_covered'] for q in queries),
    'new_removed_nodes':sum(r['new_removed_nodes'] for r in cases),'cases_with_new_pruning':sum(r['new_removed_nodes']>0 for r in cases)})
