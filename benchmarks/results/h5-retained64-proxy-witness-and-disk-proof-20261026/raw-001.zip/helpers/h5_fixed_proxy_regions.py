"""Integer-lattice rectangle avoidance and exact source-capacity profiles."""
def translated(bounds,xy):return [bounds[k]+xy[k%2] for k in range(4)]
def overlaps(a,b):return max(a[0],b[0])<min(a[2],b[2]) and max(a[1],b[1])<min(a[3],b[3])
def profile(rectangles,axis):
    events={}
    for b in rectangles:
        lo,hi=b[axis],b[axis+2];d=b[3-axis]-b[1-axis]
        events[lo]=events.get(lo,0)+d;events[hi]=events.get(hi,0)-d
    points=sorted(events);active=0;result=[]
    for lo,hi in zip(points,points[1:]):
        active+=events[lo]
        if active:
            if result and result[-1][1]==lo and result[-1][2]==active:result[-1][1]=hi
            else:result.append([lo,hi,active])
    if points:active+=events[points[-1]]
    assert active==0
    return result
def complement(intervals,lo,hi):
    merged=[]
    for a,b in sorted((max(a,lo),min(b,hi)) for a,b in intervals if max(a,lo)<=min(b,hi)):
        if merged and a<=merged[-1][1]+1:merged[-1][1]=max(merged[-1][1],b)
        else:merged.append([a,b])
    result=[];start=lo
    for a,b in merged:
        if start<a:result.append([start,a-1])
        start=b+1
    if start<=hi:result.append([start,hi])
    return result
def coarse_regions(fixed,moving,domain):
    boxes=[]
    for f in fixed:
        for m in moving:
            b=[max(domain[0],f[0]-m[2]+1),max(domain[1],f[1]-m[3]+1),
               min(domain[2],f[2]-m[0]-1),min(domain[3],f[3]-m[1]-1)]
            if b[0]<=b[2] and b[1]<=b[3]:boxes.append(b)
    xs=sorted({domain[0],domain[2]+1}|{v for b in boxes for v in [b[0],b[2]+1]})
    cells=[]
    for a,b in zip(xs,xs[1:]):
        free=complement([[r[1],r[3]] for r in boxes if r[0]<=a<=r[2]],domain[1],domain[3])
        for c,d in free:cells.append([a,c,b-1,d])
    return boxes,cells
def capacity_ranges(fixed_profile,moving_rectangles,axis,capacity,lo,hi):
    moving=profile(moving_rectangles,axis);forbidden=[]
    for a,b,d in moving:
        for c,e,used in fixed_profile:
            if used+d>capacity:forbidden.append([c-b+1,e-a-1])
    return complement(forbidden,lo,hi)
def intersect_ranges(cells,xs,ys):
    result=[]
    for a,b,c,d in cells:
        for x,z in xs:
            if max(a,x)>min(c,z):continue
            for y,w in ys:
                if max(b,y)<=min(d,w):result.append([max(a,x),max(b,y),min(c,z),min(d,w)])
    return result
