"""Independent fixed-source mapping and complete integer-cell/capacity region audit."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import box
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-retained64-proxy-regions-20261026'
GEO=ROOT/'output/h5-allocation-geometry-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def disjoint(a,b):return a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
def raw_profile(rects,axis):
    points=sorted({v for b in rects for v in [b[axis],b[axis+2]]});rows=[]
    for a,b in zip(points,points[1:]):
        value=sum(r[3-axis]-r[1-axis] for r in rects if 2*r[axis]<=a+b<2*r[axis+2])
        if value:rows.append([a,b,value])
    return rows
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
fixed=load(BASE/'fixed64.json');variants=load(GEO/'variants.json');domains=load(GEO/'domains.json');stocks=load(GEO/'stocks.json')
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']}
old=load(ROOT/'output/h5-latest-wide-joint-20261023/layout-audit/layout-final.json')['placements']
short=load(ROOT/'output/h5-legacy64-sliding-geometry-20261026/short-repair/placements.json')
rows=[r for r in old if r['sheet_id']=='sheet-0']+short;by_key={(r['part_id'],r['copy_index']):r for r in rows}
assert len(fixed)==len(by_key)==64
center=load(ROOT/'output/h5-rotation-independent-geometry-20261026/original-cog-proof.json')['center']
reconstructed={name:[[],[]] for name in ['coarse','source','virtual']}
for f in fixed:
    row=by_key[f['family'],f['copy_index']];assert f['source_placement']==row
    t=row['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    points=[(x*sign*c-y*s+tx,x*sign*s+y*c+ty) for x,y in ([center] if f['family']=='cog' else parts[f['family']]['geometry'][0]['outer'])]
    xy=[math.floor(min(p[k] for p in points)*1000) for k in [0,1]];assert xy==f['anchor_um']
    v=variants[f['variant']];assert v['family']==f['family'] and f['sheet']==int(row['sheet_id'][-1])
    if f['family']!='cog':
        q=round(t['rotation_radians']/(math.pi/2))%4
        assert v['quarter_turn']==(q%2 if f['family'] in ['frame','insert'] else q) and v['mirrored']==t['mirrored']
    d=next(d for d in domains if d['variant']==v['id'] and d['sheet']==f['sheet']);assert d['allowed']
    assert all(d['bounds_um'][k]<=xy[k]<=d['bounds_um'][k+2] for k in [0,1])
    for kind,field in [('coarse','coarse_rectangles_um'),('source','source_capacity_rectangles_um'),('virtual','separation_capacity_rectangles_um')]:
        for b in v.get(field,[]):reconstructed[kind][f['sheet']].append({'original_index':f['original_index'],'bounds_um':[b[k]+xy[k%2] for k in range(4)]})
for kind,name in [('coarse','fixed-coarse.json'),('source','fixed-source-capacity.json'),('virtual','fixed-cog-only-capacity.json')]:
    want=load(BASE/name)
    for s in [0,1]:assert sorted(reconstructed[kind][s],key=lambda r:(r['original_index'],r['bounds_um']))==sorted(want[s],key=lambda r:(r['original_index'],r['bounds_um']))
pair_checks=0
for sheet in reconstructed['coarse']:
    for a,b in combinations(sheet,2):assert disjoint(a['bounds_um'],b['bounds_um']);pair_checks+=1
baseline=load(BASE/'baseline-capacities.json');slabs=0
for p in baseline:
    kind='source' if p['kind']=='source' else 'virtual';rects=[r['bounds_um'] for r in reconstructed[kind][p['sheet']]]
    rows0=raw_profile(rects,p['axis']);points=sorted({x for r in rows0+p['profile'] for x in r[:2]})
    for a,b in zip(points,points[1:]):
        expected=sum(r[2] for r in rows0 if 2*r[0]<=a+b<2*r[1]);actual=sum(r[2] for r in p['profile'] if 2*r[0]<=a+b<2*r[1])
        assert expected==actual<=p['capacity_um'];slabs+=1
    assert p['capacity_um']==stocks[p['sheet']]['capacity_um'][1-p['axis']]
    assert p['peak_demand_um']==max(r[2] for r in rows0)
allowed={tuple(r['short_counts']) for r in load(GEO/'allowed-allocations.json')}
choices=load(BASE/'missing-sheet-choices.json');assert len(choices)==4
for p in choices:
    assert p['short_counts']==[4+sum(p['missing_sheets']),2,3] and p['allowed']==(tuple(p['short_counts']) in allowed)
assert [p['missing_sheets'] for p in choices if p['allowed']]==[[0,0]]
regions=load(BASE/'bracket-regions.json');assert [r['variant'] for r in regions]==list(range(8))
coarse_first=[r['bounds_um'] for r in reconstructed['coarse'][0]];capacity_atoms=0;counts=[]
for result in regions:
    v=variants[result['variant']];d=next(d for d in domains if d['variant']==v['id'] and d['sheet']==0)['bounds_um'];assert result['domain_um']==d
    expected=[]
    for f in coarse_first:
        for m in v['coarse_rectangles_um']:
            b=[max(d[0],f[0]-m[2]+1),max(d[1],f[1]-m[3]+1),min(d[2],f[2]-m[0]-1),min(d[3],f[3]-m[1]-1)]
            if b[0]<=b[2] and b[1]<=b[3]:expected.append(b)
    assert result['forbidden_integer_boxes']==expected
    # A lattice rectangle [a,c]x[b,d] maps to unit cells [a,c+1]x[b,d+1].
    # Exact axis-aligned GEOS union/difference checks the entire integer lattice.
    wanted=box(d[0],d[1],d[2]+1,d[3]+1).difference(unary_union([box(a,b,c+1,e+1) for a,b,c,e in expected]))
    cells=result['coarse_free_cells'];actual=unary_union([box(a,b,c+1,e+1) for a,b,c,e in cells])
    assert wanted.equals(actual) and wanted.symmetric_difference(actual).is_empty
    ranges=result['single_bracket_capacity_ranges']
    for axis in [0,1]:
        p=next(p for p in baseline if p['sheet']==0 and p['kind']=='source' and p['axis']==axis)
        moving=raw_profile(v['source_capacity_rectangles_um'],axis)
        critical={d[axis],d[axis+2]+1}
        for a,b,_ in moving:
            for c,e,_ in p['profile']:
                for t in [c-a,c-b,e-a,e-b]:
                    for x in [t,t+1]:
                        if d[axis]<=x<=d[axis+2]+1:critical.add(x)
        for a,b in ranges[axis]:assert d[axis]<=a<=b<=d[axis+2];critical.update([a,b+1])
        points=sorted(critical)
        for a,b in zip(points,points[1:]):
            if a==b:continue
            valid=all(not(max(a+m[0],p0[0])<min(a+m[1],p0[1]) and m[2]+p0[2]>p['capacity_um']) for m in moving for p0 in p['profile'])
            assert valid==any(lo<=a<=hi for lo,hi in ranges[axis]);capacity_atoms+=1
    capacity_area=unary_union([box(x,y,z+1,w+1) for x,z in ranges[0] for y,w in ranges[1]])
    final=unary_union([box(a,b,c+1,e+1) for a,b,c,e in result['coarse_and_single_capacity_cells']])
    assert wanted.intersection(capacity_area).equals(final)
    counts.append({'variant':v['id'],'coarse_cells':len(cells),'coarse_and_capacity_cells':len(result['coarse_and_single_capacity_cells']),
                   'integer_anchor_count':sum((c-a+1)*(e-b+1) for a,b,c,e in result['coarse_and_single_capacity_cells'])})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'fixed_source_transforms_preserved':64,
    'repaired_short_transforms_preserved':9,'fixed_proxy_coarse_pairs_verified':pair_checks,
    'fixed_capacity_event_slabs_verified':slabs,'missing_brackets_forced_first_with_fixed64':True,
    'all8_coarse_integer_anchor_regions_verified':True,'single_capacity_anchor_atoms_verified':capacity_atoms,
    'mode_counts':counts,'two_bracket_fit_not_yet_proved':True,'no_source_fit_claimed':True,
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
