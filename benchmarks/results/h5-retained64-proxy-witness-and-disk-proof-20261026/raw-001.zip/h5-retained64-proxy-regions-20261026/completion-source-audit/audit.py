"""Original-ring readback of the necessary completion, with legacy failures separated."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-retained64-proxy-regions-20261026'
CON=BASE/'construction';OUT=BASE/'completion-source-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(CON/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
fixed=load(BASE/'fixed64.json');oldrows=load(CON/'all66-source-original-copy-labels.json');rows=load(CON/'all66-source-candidate.json');bijection=load(CON/'copy-bijection.json')
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');expected=[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])]
assert sorted((p['part_id'],p['copy_index']) for p in oldrows)==sorted(expected)
assert sorted((p['part_id'],p['copy_index']) for p in rows)==sorted(expected)
oldmap={(p['part_id'],p['copy_index']):p for p in oldrows};newmap={(p['part_id'],p['copy_index']):p for p in rows}
assert len(bijection)==66 and len({(p['family'],p['from_copy_index']) for p in bijection})==len({(p['family'],p['to_copy_index']) for p in bijection})==66
for r in bijection:
    a=oldmap[r['family'],r['from_copy_index']];b=newmap[r['family'],r['to_copy_index']]
    assert a['transform']==b['transform'] and a['sheet_id']==b['sheet_id'] and r['same_source_geometry']
for f in fixed:assert oldmap[f['family'],f['copy_index']]==f['source_placement']
added=[(r['family'],r['to_copy_index']) for r in bijection if r['family']=='bracket' and r['from_copy_index'] in [10,11]];assert len(added)==2
stocks={'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.4269023299994]}
guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05)
full=audit(job,rows,stocks,required,guard,expected);baseline=audit(job,[p for p in rows if (p['part_id'],p['copy_index']) not in added],stocks,required,guard)
write(OUT/'all66-source-readback.json',full);write(OUT/'retained64-current-guard-readback.json',baseline)
added_failures=[p for p in full['pairs'] if not p['passed'] and any(tuple(k) in added for k in p['keys'])]
physical=[p for p in full['pairs'] if p['intersection_area_mm2']>0]
assert not any(p['intersection_area_mm2']>0 for p in baseline['pairs'])
write(OUT/'added-bracket-source-failures.json',added_failures)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'all66_originals_present':True,
    'same_family_copy_bijection_verified':66,'existing_source_transforms_unchanged':64,
    'missing_bracket_copy_indices_original':[10,11],'missing_bracket_keys_canonical':[list(k) for k in added],
    'full_source_valid':full['valid'],'full_source_pair_failures':full['pair_failures'],
    'full_source_stock_failures':full['stock_failures'],'full_physical_intersection_pairs':len(physical),
    'retained64_current_guard_pair_failures':baseline['pair_failures'],
    'retained64_current_guard_stock_failures':baseline['stock_failures'],'retained64_physical_intersections':0,
    'new_bracket_pair_failures':len(added_failures),'all66_same_sheet_pairs':full['same_sheet_pairs'],
    'all66_stock_edges':full['stock_edges'],'all66_cutouts':full['cutouts'],'all66_hole_vertices':full['hole_vertices'],
    'required_source_gap_mm':required,'required_extra_stock_mm':guard,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
