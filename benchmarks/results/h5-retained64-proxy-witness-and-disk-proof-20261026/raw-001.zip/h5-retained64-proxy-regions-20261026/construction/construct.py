"""Deterministic finite two-bracket construction, without running a solver."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from h5_fixed_proxy_regions import translated,overlaps,profile
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-retained64-proxy-regions-20261026'
GEO=ROOT/'output/h5-allocation-geometry-20261026';OUT=BASE/'construction'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'audit-order-insensitive/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');start=time.perf_counter()
names=['fixed64.json','missing-originals.json','bracket-regions.json','baseline-capacities.json','fixed-source-capacity.json','audit-order-insensitive/checks.json']
inputs=[BASE/n for n in names]+[GEO/n for n in ['variants.json','stocks.json','originals.json']]+[ROOT/'output/h5_fixed_proxy_regions.py',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'construction_seconds':30,'solver_calls':0,'method':'Deterministically enumerate each verified missing-bracket integer cell center and four corners, then all unordered pose pairs. Require mutual coarse non-overlap and both combined source-capacity constraints against the fixed55 first originals. Stop at the first successful pair or the finite list/budget. Virtual cog-only capacities and the repaired short9 are unchanged. Add both missing bracket copies10/11 using their real source quarter-turn/mirror transforms. Preserve original-copy-labelled source placements; separately relabel identical copies by sheet/Y/X for the coupled model ordering, archiving the exact bijection. A positive is only a necessary-model construction, requiring independent verification of every serialized model constraint and all66 original rings. No solver retry or native acceptance.'})
fixed=load(BASE/'fixed64.json');variants=load(GEO/'variants.json');stocks=load(GEO/'stocks.json');regions=load(BASE/'bracket-regions.json')
candidate=[];seen=set()
for r in regions:
    for cell_index,(a,b,c,d) in enumerate(r['coarse_and_single_capacity_cells']):
        for x,y in [((a+c)//2,(b+d)//2),(a,b),(a,d),(c,b),(c,d)]:
            key=(r['variant'],x,y)
            if key in seen:continue
            seen.add(key);candidate.append({'variant':r['variant'],'anchor_um':[x,y],'cell_index':cell_index})
write(OUT/'finite-poses.json',candidate)
baseline=[r['bounds_um'] for r in load(BASE/'fixed-source-capacity.json')[0]]
coarse_rejected=capacity_rejected=attempts=0;chosen=None
for a,b in combinations(candidate,2):
    attempts+=1
    ra=[translated(r,a['anchor_um']) for r in variants[a['variant']]['coarse_rectangles_um']]
    rb=[translated(r,b['anchor_um']) for r in variants[b['variant']]['coarse_rectangles_um']]
    if any(overlaps(x,y) for x in ra for y in rb):coarse_rejected+=1;continue
    additional=[translated(r,p['anchor_um']) for p in [a,b] for r in variants[p['variant']]['source_capacity_rectangles_um']]
    profiles=[profile(baseline+additional,axis) for axis in [0,1]]
    if any(any(row[2]>stocks[0]['capacity_um'][1-axis] for row in ps) for axis,ps in enumerate(profiles)):
        capacity_rejected+=1;continue
    chosen=[a,b];write(OUT/'combined-source-capacities.json',profiles);break
    # Finite enumeration is deliberately not an exclusion of continuous source placements.
assert time.perf_counter()-start<30
if chosen:
    job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');br=next(p for p in job['parts'] if p['id']=='bracket')
    additions=[]
    for pose,copy in zip(chosen,[10,11]):
        v=variants[pose['variant']];angle=v['quarter_turn']*math.pi/2;c,s=math.cos(angle),math.sin(angle);mi=-1 if v['mirrored'] else 1
        points=[(mi*x*c-y*s,mi*x*s+y*c) for x,y in br['geometry'][0]['outer']]
        translation=[pose['anchor_um'][k]/1000-min(p[k] for p in points) for k in [0,1]]
        source={'part_id':'bracket','copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':v['mirrored'],'translation':translation}}
        additions.append({'original_index':18+copy,'family':'bracket','copy_index':copy,'sheet':0,**pose,'source_placement':source})
    all_originals=fixed+additions;assert len(all_originals)==66
    write(OUT/'chosen-pair.json',chosen);write(OUT/'all66-source-original-copy-labels.json',[p['source_placement'] for p in all_originals])
    canonical=[];bijection=[];source=[];originals=load(GEO/'originals.json');indices={(p['family'],p['copy_index']):p['index'] for p in originals}
    for family in ['frame','bracket','insert','cog']:
        rows=sorted((p for p in all_originals if p['family']==family),key=lambda p:(p['sheet'],p['anchor_um'][1],p['anchor_um'][0],p['variant'],p['copy_index']))
        for copy,p in enumerate(rows):
            index=indices[family,copy];canonical.append({'original_index':index,'family':family,'copy_index':copy,'sheet':p['sheet'],'variant':p['variant'],'anchor_um':p['anchor_um']})
            bijection.append({'family':family,'from_copy_index':p['copy_index'],'to_copy_index':copy,'same_source_geometry':True})
            source.append({**p['source_placement'],'copy_index':copy})
    write(OUT/'canonical-necessary-poses.json',canonical);write(OUT/'copy-bijection.json',bijection);write(OUT/'all66-source-candidate.json',source)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'finite_poses':len(candidate),'pairs_attempted':attempts,
    'coarse_rejected_pairs':coarse_rejected,'capacity_rejected_pairs':capacity_rejected,'constructed':chosen is not None,
    'all64_existing_source_transforms_unchanged':True,'both_missing_brackets_retained':True,
    'solver_calls':0,'native_calls':0,'full_source_fit_claimed':False,'H5_complete':False})
print(load(OUT/'result.json'))
