"""Verify a directly constructed assignment against all closed model constraints."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-retained64-proxy-regions-20261026'
CON=BASE/'construction';MODEL=ROOT/'output/h5-allocation-model-20261026';OUT=BASE/'completion-model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
assert digest(MODEL/'model.pb')==load(MODEL/'model-audit/checks.json')['model_sha256']
raw=cp_model_pb2.CpModelProto();raw.ParseFromString((MODEL/'model.pb').read_bytes());mp=load(MODEL/'mapping.json')
poses=load(CON/'canonical-necessary-poses.json');assert [p['original_index'] for p in poses]==list(range(66))
sol=[None]*len(raw.variables)
def assign(index,value):assert sol[index] is None;sol[index]=int(value)
for p,r in zip(poses,mp['originals']):
    assert p['original_index']==r['original_index']
    for index,value in zip(r['coordinate_indices'],p['anchor_um']):assign(index,value)
    assign(r['sheet_index'],p['sheet']);assign(r['key_index'],p['anchor_um'][1]+4000000*p['sheet'])
    for o in r['options']:assign(o['selector'],o['variant']==p['variant'] and o['sheet']==p['sheet'])
for r in mp['short_counts']:assign(r['variable'],sum(p['family']==r['family'] and p['sheet']==1 for p in poses))
assert len(sol)==609 and all(v is not None for v in sol)
for v,value in zip(raw.variables,sol):assert any(lo<=value<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]))
def expr(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
def literal(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
def present(c):return all(literal(v) for v in c.enforcement_literal)
intervals={i:(expr(c.interval.start),expr(c.interval.end),expr(c.interval.size),present(c)) for i,c in enumerate(raw.constraints) if c.WhichOneof('constraint')=='interval'}
pairs=events_checked=0
for i,ct in enumerate(raw.constraints):
    if not present(ct):continue
    kind=ct.WhichOneof('constraint')
    if kind=='linear':
        value=sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs));assert any(a<=value<=b for a,b in zip(ct.linear.domain[::2],ct.linear.domain[1::2]))
    elif kind=='exactly_one':assert sum(literal(v) for v in ct.exactly_one.literals)==1
    elif kind=='table':
        assert not ct.table.negated;row=tuple(expr(e) for e in ct.table.exprs);n=len(row)
        assert row in {tuple(ct.table.values[k:k+n]) for k in range(0,len(ct.table.values),n)}
    elif kind=='interval':a,b,size,on=intervals[i];assert a+size==b and size>0 and on
    elif kind=='no_overlap_2d':
        rects=[]
        for x,y in zip(ct.no_overlap_2d.x_intervals,ct.no_overlap_2d.y_intervals):
            assert intervals[x][3]==intervals[y][3]
            if intervals[x][3]:rects.append((*intervals[x][:2],*intervals[y][:2]))
        for a,b in combinations(rects,2):assert a[1]<=b[0] or b[1]<=a[0] or a[3]<=b[2] or b[3]<=a[2];pairs+=1
    elif kind=='cumulative':
        events={}
        for ix,dem in zip(ct.cumulative.intervals,ct.cumulative.demands):
            a,b,size,on=intervals[ix]
            if on:d=expr(dem);events[a]=events.get(a,0)+d;events[b]=events.get(b,0)-d
        amount=0;cap=expr(ct.cumulative.capacity)
        for point in sorted(events):amount+=events[point];assert 0<=amount<=cap;events_checked+=1
    else:raise AssertionError(kind)
write(OUT/'assignment.json',{v.name:value for v,value in zip(raw.variables,sol)})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_in_domain':609,
    'all_serialized_constraints_satisfied':len(raw.constraints),'all66_originals_required_and_assigned':True,
    'selected_optional_intervals':sum(v[3] for v in intervals.values()),'coarse_rectangle_pairs_checked':pairs,
    'cumulative_events_checked':events_checked,'short_counts_bracket_insert_cog':[sol[r['variable']] for r in mp['short_counts']],
    'closed_unknown_model_proved_feasible_by_construction':True,'model_sha256':digest(MODEL/'model.pb'),
    'source_geometry_validity_not_implied':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
