"""Map retained source64 to all-angle proxies and derive exact missing-bracket regions."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from h5_fixed_proxy_regions import translated,overlaps,profile,coarse_regions,capacity_ranges,intersect_ranges
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-allocation-geometry-20261026'
OUT=ROOT/'output/h5-retained64-proxy-regions-20261026';OLD=ROOT/'output/h5-latest-wide-joint-20261023/layout-audit/layout-final.json'
SHORT=ROOT/'output/h5-legacy64-sliding-geometry-20261026/short-repair/placements.json'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[OLD,SHORT,JOB,ROOT/'output/h5_fixed_proxy_regions.py']+[GEO/n for n in ['variants.json','domains.json','stocks.json','originals.json','allowed-allocations.json','audit/checks.json']]+[ROOT/'output/h5-rotation-independent-geometry-20261026/original-cog-proof.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'preparation_seconds':30,'solver_calls':0,'method':'Map55 first-sheet placements from the preserved64-source layout plus the verified repaired short9 into the independently proved quantization-safe allocation proxies. Do not change those source transforms or overwrite old evidence. Both missing bracket copies remain mandatory. Verify all fixed coarse pairs, source capacities, cog-only virtual capacities and stock domains. Determine which sheets the two remaining brackets may use from the full count table. For each legal first-sheet bracket mode, derive every forbidden integer anchor box from exact rectangle overlap inequalities; sweep X breakpoints and complement the union of inclusive Y intervals to obtain the complete coarse-free integer lattice cells. Independently derive single-bracket admissible X/Y ranges from exact baseline capacity profiles and intersect them with those cells. No solver or full-source acceptance is implied. Any two-bracket placement must also satisfy mutual geometry and combined capacities, and then actual source/native guards.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};variants=load(GEO/'variants.json');domains=load(GEO/'domains.json');stocks=load(GEO/'stocks.json');originals=load(GEO/'originals.json')
indices={(p['family'],p['copy_index']):p['index'] for p in originals}
rows=[p for p in load(OLD)['placements'] if p['sheet_id']=='sheet-0']+load(SHORT)
assert len(rows)==64 and len({(p['part_id'],p['copy_index']) for p in rows})==64
missing=[p for p in originals if (p['family'],p['copy_index']) not in {(p['part_id'],p['copy_index']) for p in rows}]
assert [(p['family'],p['copy_index']) for p in missing]==[('bracket',10),('bracket',11)]
center=load(ROOT/'output/h5-rotation-independent-geometry-20261026/original-cog-proof.json')['center']
fixed=[];coarse=[[],[]];source=[[],[]];virtual=[[],[]]
for row in rows:
    family=row['part_id'];t=row['transform'];angle=t['rotation_radians'];c,s=math.cos(angle),math.sin(angle);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];sheet=int(row['sheet_id'].split('-')[-1])
    if family=='cog':
        v=next(v for v in variants if v['family']=='cog');x,y=center;anchor=[x*c-y*s+tx,x*s+y*c+ty]
    else:
        q=round(angle/(math.pi/2))%4;assert abs(math.remainder(angle-q*math.pi/2,2*math.pi))<1e-12
        q=q%2 if family in ['frame','insert'] else q
        v=next(v for v in variants if v['family']==family and v['quarter_turn']==q and v['mirrored']==t['mirrored'])
        points=[(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in parts[family]['geometry'][0]['outer']]
        anchor=[min(p[k] for p in points) for k in [0,1]]
    xy=[math.floor(a*1000) for a in anchor];domain=next(d for d in domains if d['variant']==v['id'] and d['sheet']==sheet)
    assert domain['allowed'] and all(domain['bounds_um'][k]<=xy[k]<=domain['bounds_um'][k+2] for k in [0,1])
    record={'original_index':indices[family,row['copy_index']],'family':family,'copy_index':row['copy_index'],
            'sheet':sheet,'variant':v['id'],'anchor_um':xy,'source_placement':row};fixed.append(record)
    for field,bucket in [('coarse_rectangles_um',coarse),('source_capacity_rectangles_um',source),('separation_capacity_rectangles_um',virtual)]:
        for b in v.get(field,[]):bucket[sheet].append({'original_index':record['original_index'],'bounds_um':translated(b,xy)})
fixed.sort(key=lambda p:p['original_index']);pair_checks=0;capacity_checks=[]
for sheet in [0,1]:
    for a,b in combinations(coarse[sheet],2):assert not overlaps(a['bounds_um'],b['bounds_um']);pair_checks+=1
    for kind,bucket in [('source',source),('virtual_cog_only',virtual)]:
        for axis in [0,1]:
            ps=profile([r['bounds_um'] for r in bucket[sheet]],axis);capacity=stocks[sheet]['capacity_um'][1-axis]
            assert all(row[2]<=capacity for row in ps)
            capacity_checks.append({'sheet':sheet,'kind':kind,'axis':axis,'capacity_um':capacity,'profile':ps,'peak_demand_um':max(p[2] for p in ps)})
short_counts=[sum(p['sheet']==1 and p['family']==family for p in fixed) for family in ['bracket','insert','cog']]
allowed={tuple(r['short_counts']) for r in load(GEO/'allowed-allocations.json')};options=[]
for a in [0,1]:
    for b in [0,1]:
        counts=[short_counts[0]+a+b,*short_counts[1:]];options.append({'missing_sheets':[a,b],'short_counts':counts,'allowed':tuple(counts) in allowed})
assert [r['missing_sheets'] for r in options if r['allowed']]==[[0,0]]
write(OUT/'fixed64.json',fixed);write(OUT/'missing-originals.json',missing);write(OUT/'fixed-coarse.json',coarse)
write(OUT/'fixed-source-capacity.json',source);write(OUT/'fixed-cog-only-capacity.json',virtual)
write(OUT/'baseline-capacities.json',capacity_checks);write(OUT/'missing-sheet-choices.json',options)
fixed_first=[r['bounds_um'] for r in coarse[0]];baseprofiles={p['axis']:p['profile'] for p in capacity_checks if p['sheet']==0 and p['kind']=='source'}
results=[]
for v in variants:
    if v['family']!='bracket':continue
    d=next(d for d in domains if d['variant']==v['id'] and d['sheet']==0);domain=d['bounds_um']
    obstacles,cells=coarse_regions(fixed_first,v['coarse_rectangles_um'],domain)
    ranges=[capacity_ranges(baseprofiles[axis],v['source_capacity_rectangles_um'],axis,stocks[0]['capacity_um'][1-axis],domain[axis],domain[axis+2]) for axis in [0,1]]
    both=intersect_ranges(cells,*ranges)
    results.append({'variant':v['id'],'domain_um':domain,'forbidden_integer_boxes':obstacles,'coarse_free_cells':cells,
                    'single_bracket_capacity_ranges':ranges,'coarse_and_single_capacity_cells':both})
    assert time.perf_counter()-start<30
write(OUT/'bracket-regions.json',results)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'fixed_originals':64,'first_originals':55,'short_originals':9,
    'missing_required_brackets':[10,11],'missing_brackets_forced_first_with_fixed64':True,'fixed_coarse_pairs_checked':pair_checks,
    'source_and_virtual_capacity_profiles_checked':len(capacity_checks),'bracket_modes':8,
    'coarse_cells_by_mode':[len(r['coarse_free_cells']) for r in results],
    'single_capacity_cells_by_mode':[len(r['coarse_and_single_capacity_cells']) for r in results],
    'solver_calls':0,'native_calls':0,'full_source_fit_claimed':False,'H5_complete':False})
print(load(OUT/'prepared.json'))
