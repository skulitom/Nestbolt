"""Independent nearest-point arithmetic and complete cell-coverage certificate reader."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-retained64-proxy-regions-20261026'
GEO=ROOT/'output/h5-allocation-geometry-20261026';CERT=BASE/'disk-exclusion';OUT=CERT/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(CERT/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'audit-order-insensitive/checks.json')['passed'] and load(GEO/'audit/checks.json')['passed']
fixed={p['original_index']:p for p in load(BASE/'fixed64.json')};variants=load(GEO/'variants.json');regions=load(BASE/'bracket-regions.json');rows=load(CERT/'certificate.json')
expected={(r['variant'],i):b for r in regions for i,b in enumerate(r['coarse_free_cells'])}
assert len(expected)==len(rows)==26 and {(p['variant'],p['cell_index']) for p in rows}==set(expected)
r=variants[-1]['source_disk_radius_um'];assert r==109113;minimum=None;corners=0
for p in rows:
    cell=expected[p['variant'],p['cell_index']];assert p['cell_um']==cell
    cog=fixed[p['cog_original_index']];assert cog['family']=='cog' and cog['sheet']==0 and p['cog_center_um']==cog['anchor_um']
    rect=variants[p['variant']]['coarse_rectangles_um'][p['bracket_component']];assert p['bracket_rectangle_um']==rect
    positions=[[x,y] for x in [cell[0],cell[2]] for y in [cell[1],cell[3]]]
    assert [row['anchor_um'] for row in p['corners']]==positions
    values=[]
    for xy,row in zip(positions,p['corners']):
        near=[min(max(cog['anchor_um'][k],xy[k]+rect[k]),xy[k]+rect[k+2]) for k in [0,1]]
        distance=sum((cog['anchor_um'][k]-near[k])**2 for k in [0,1]);assert row['distance_squared_um2']==distance<r*r
        values.append(distance);corners+=1
    margin=r*r-max(values);assert margin==p['strict_squared_margin_um2']>0
    minimum=margin if minimum is None else min(minimum,margin)
choices=load(BASE/'missing-sheet-choices.json');assert len(choices)==4 and [p['missing_sheets'] for p in choices if p['allowed']]==[[0,0]]
lower=F(minimum,2*r*1000)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,
    'complete_integer_anchor_cells_verified':26,'bracket_modes_verified':8,'exact_corner_squared_distances_verified':corners,
    'minimum_strict_squared_margin_um2':minimum,'minimum_radial_penetration_lower_bound_mm_rational':[lower.numerator,lower.denominator],
    'convex_forbidden_region_covers_every_cell_anchor':True,'source_disk_valid_for_arbitrary_cog_rotations':True,
    'coarse_only_regions_suffice_without_capacity_restrictions':True,
    'short_count_frontier_excludes_extra_bracket':True,'fixed_position_obstruction_verified':True,
    'at_least_one_existing_non_cog_pose_or_cog_center_must_change':True,
    'unrestricted_exclusion_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
