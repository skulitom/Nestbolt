"""Exact all-angle mixed-family obstruction for every remaining bracket anchor cell."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-retained64-proxy-regions-20261026'
GEO=ROOT/'output/h5-allocation-geometry-20261026';OUT=BASE/'disk-exclusion'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter()
inputs=[BASE/n for n in ['fixed64.json','bracket-regions.json','missing-sheet-choices.json','audit-order-insensitive/checks.json']]+[GEO/n for n in ['variants.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'solver_calls':0,'method':'The complete coarse-free integer anchor regions have26 cells across8 legal bracket modes. For every cell, exhibit one fixed cog center and one source-contained bracket rectangle such that all4 anchor-cell corners have strictly less than109113um distance from that center to the translated rectangle. The forbidden anchor region is the convex Minkowski sum of the rectangle reflection and the open disk, so containment of all4 cell corners contains every anchor in that cell. The disk is source-contained for every real cog rotation after coordinate flooring. All26 cells are excluded even without the added source-capacity restrictions. The short count frontier independently prevents either missing bracket from joining the fixed4bracket/2insert/3cog short sheet. Thus no additional bracket can fit with these64 non-cog transforms/cog centers fixed, even with arbitrary cog angles. This is a fixed-position obstruction, not unrestricted whole-job impossibility. All source and quantization certificates remain unchanged.'})
fixed=load(BASE/'fixed64.json');variants=load(GEO/'variants.json');regions=load(BASE/'bracket-regions.json');radius=variants[-1]['source_disk_radius_um']
assert radius==109113 and load(BASE/'audit-order-insensitive/checks.json')['passed']
proof=[]
for result in regions:
    for cell_index,cell in enumerate(result['coarse_free_cells']):
        possibilities=[]
        for f in fixed:
            if f['family']!='cog' or f['sheet']!=0:continue
            cx,cy=f['anchor_um']
            for component,rect in enumerate(variants[result['variant']]['coarse_rectangles_um']):
                corners=[]
                for x in [cell[0],cell[2]]:
                    for y in [cell[1],cell[3]]:
                        dx=max(x+rect[0]-cx,0,cx-x-rect[2]);dy=max(y+rect[1]-cy,0,cy-y-rect[3])
                        corners.append({'anchor_um':[x,y],'distance_squared_um2':dx*dx+dy*dy})
                margin=radius*radius-max(c['distance_squared_um2'] for c in corners)
                if margin>0:possibilities.append({'variant':result['variant'],'cell_index':cell_index,'cell_um':cell,
                    'cog_original_index':f['original_index'],'cog_center_um':f['anchor_um'],'bracket_component':component,
                    'bracket_rectangle_um':rect,'corners':corners,'strict_squared_margin_um2':margin})
        assert possibilities,(result['variant'],cell_index)
        proof.append(max(possibilities,key=lambda p:p['strict_squared_margin_um2']))
assert len(proof)==26
write(OUT/'certificate.json',proof)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'all_coarse_free_cells_covered':26,'all8_bracket_modes_covered':True,
    'corner_distance_checks':4*len(proof),'source_disk_radius_um':radius,
    'minimum_strict_squared_margin_um2':min(p['strict_squared_margin_um2'] for p in proof),
    'one_additional_bracket_excluded_with_fixed64_positions':True,'arbitrary_cog_angles_allowed':True,
    'at_least_one_existing_non_cog_pose_or_cog_center_must_change':True,
    'unrestricted_whole_job_exclusion':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'result.json'))
