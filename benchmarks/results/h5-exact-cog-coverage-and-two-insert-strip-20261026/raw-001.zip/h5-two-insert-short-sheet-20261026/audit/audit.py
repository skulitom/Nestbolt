"""Read back every original vertex with a direct transform, independent of builder affinity."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-two-insert-short-sheet-20261026';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SRC=ROOT/'output/h5-source-orientation-construction-20261025';FIRST=ROOT/'output/h5-insert36-cog53-exchange-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Read back saved64-placement output. Apply the documented reflection-rotation-translation formula directly to every original outer and hole vertex; do not use builder affine-transform helper. Verify identities, allowed transforms, exact preservation of54 first-sheet placements plus restored cog53, full original filled-outer pair/stock checks and every cutout/vertex count. Verify the changed nine-part short allocation and two mandatory cogs; do not transfer the old fixed55 count bound. No native full-job validation on this partial.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(JOB);families={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(r['family'],r['copy']):i for i,r in enumerate(items)};placements=load(BASE/'partial64-placements.json');first=[p for p in load(FIRST/'first-sheet-placements.json') if ids[p['part_id'],p['copy_index']]!=36]+[load(FIRST/'replacement-insert.json')['original_cog_placement']];first.sort(key=lambda p:ids[p['part_id'],p['copy_index']]);short=load(BASE/'short-sheet-placements.json');assert placements==first+short and len(first)==55 and len(short)==9
assert Counter(p['part_id'] for p in short)=={'bracket':6,'insert':2,'cog':1};placed=[ids[p['part_id'],p['copy_index']] for p in placements];assert placed==load(BASE/'placed-identities.json') and sorted(placed+[63,64])==list(range(66)) and load(BASE/'mandatory-first-additions.json')==[63,64]
stock=[[float(F(*x)) for x in b] for b in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);polys={};edges=[];holes=vertices=0
for p in placements:
    item=ids[p['part_id'],p['copy_index']];f=families[p['part_id']];g=f['geometry'][0];t=p['transform'];angle=t['rotation_radians'];mi=-1 if t['mirrored'] else 1;c,s=math.cos(angle),math.sin(angle);tx,ty=t['translation'];assert not t['mirrored'] or f['allow_mirror'];assert f['rotations']['kind']=='free' or any(abs((math.degrees(angle)-d)%360)<1e-8 for d in f['rotations']['degrees'])
    def ring(points):return [(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in points]
    outer=ring(g['outer']);inside=[ring(h) for h in g.get('holes',[])];filled=Polygon(outer);full=Polygon(outer,inside);original=Polygon(g['outer'],g.get('holes',[]));assert filled.is_valid and full.is_valid and len(full.interiors)==len(inside) and abs(full.area-original.area)<1e-7;holes+=len(inside);vertices+=sum(len(h) for h in inside)
    for actual,expected in zip(full.interiors,inside):assert list(actual.coords)[:-1]==expected
    sheet=int(p['sheet_id'].split('-')[1]);assert sheet in [0,1];polys[item]=(sheet,filled);b=filled.bounds;st=stock[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;edges.append({'item':item,'extra_margins_mm':extra})
pairs=[]
for a,b in combinations(sorted(polys),2):
    sa,pa=polys[a];sb,pb=polys[b]
    if sa==sb:
        distance=pa.distance(pb);assert not pa.intersects(pb) and distance>gap;pairs.append({'items':[a,b],'sheet_id':f'sheet-{sa}','distance_mm':distance})
oldpairs=load(BASE/'original-pair-checks.json');oldedges=load(BASE/'original-stock-checks.json');assert len(pairs)==len(oldpairs)==1521 and len(edges)==len(oldedges)==64
for r,o in zip(pairs,oldpairs):assert r['items']==o['items'] and r['sheet_id']==o['sheet_id'] and abs(r['distance_mm']-o['distance_mm'])<1e-10
for r,o in zip(edges,oldedges):assert r['item']==o['item'] and all(abs(x-y)<1e-10 for x,y in zip(r['extra_margins_mm'],o['extra_margins_mm']))
assert load(BASE/'checks.json')['old_fixed55_bound_not_applied_after_allocation_change'] and load(BASE/'checks.json')['first_removed_insert']==36 and load(BASE/'checks.json')['first_restored_cog']==53
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_verified':64,'short_originals_verified':9,'original_pair_checks':1521,'stock_edges_checked':256,'original_cutouts_preserved':holes,'original_cutout_vertices_preserved':vertices,'first54_placements_unchanged_and_cog53_restored':True,'all66_identities_accounted_once':True,'mandatory_first_sheet_additions':[63,64],'independent_direct_vertex_transform':True,'original_geometry_pairs_and_stock_passed':True,'old_conditional_count_bound_not_applied':True,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
