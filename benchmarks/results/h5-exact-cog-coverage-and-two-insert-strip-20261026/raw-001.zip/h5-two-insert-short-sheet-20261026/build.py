"""Move insert36 to the strip; restore cog53 first and preserve all obligations."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from collections import Counter
from itertools import combinations
import copy,json,math,shutil,time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-six-bracket-short-sheet-20261026';EXCHANGE=ROOT/'output/h5-insert36-cog53-exchange-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-two-insert-short-sheet-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transform(g,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;return affine_transform(g,[mi*c,-s,mi*s,c,*t['translation']])
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[OLD/n for n in ['partial63-placements.json','short-sheet-placements.json','audit/checks.json']]+[EXCHANGE/'replacement-insert.json',SRC/'items.json',SRC/'geometry.json',JOB,ROOT/'output/h5-fixed55-cog-coverage-20261026/audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Change the first-sheet allocation explicitly: remove insert36 and restore original cog53 at its previously verified first-sheet pose. On the short sheet, replace its identical cog53 copy with mandatory cog65, and stack insert36 above insert37 with0.225mm gap. Preserve every other transform and original identity. The old checked55 <=8 bound does not apply after this allocation change; the new short sheet has9 originals. Verify all64 placed original filled outers and cutouts, all same-sheet pairs and all stock edges. Cogs63/64 remain mandatory first additions; no full-job native call.'})
assert load(OLD/'audit/checks.json')['passed'] and load(ROOT/'output/h5-fixed55-cog-coverage-20261026/audit/checks.json')['additional_original_cog_excluded']
job=load(JOB);families={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(r['family'],r['copy']):i for i,r in enumerate(items)};old=load(OLD/'partial63-placements.json');exchange=load(EXCHANGE/'replacement-insert.json');first=[p for p in old if p['sheet_id']=='sheet-0' and ids[p['part_id'],p['copy_index']]!=36];first.append(exchange['original_cog_placement']);first.sort(key=lambda p:ids[p['part_id'],p['copy_index']]);assert len(first)==55
short=copy.deepcopy(load(OLD/'short-sheet-placements.json'));old_short_cog=next(p for p in short if p['part_id']=='cog');assert ids[old_short_cog['part_id'],old_short_cog['copy_index']]==53;old_short_cog['copy_index']=items[65]['copy'];insert=copy.deepcopy(next(p for p in short if p['part_id']=='insert'));assert ids[insert['part_id'],insert['copy_index']]==37;insert['copy_index']=items[36]['copy'];insert['transform']['translation'][1]+=110.225;short.append(insert);assert len(short)==9
allp=first+short;placed=[ids[p['part_id'],p['copy_index']] for p in allp];assert len(set(placed))==64 and sorted(placed+[63,64])==list(range(66));stocks=[[float(F(*v)) for v in s] for s in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);polys={};edges=[];pairs=[];holes=vertices=0
for p in allp:
    item=ids[p['part_id'],p['copy_index']];f=families[p['part_id']];t=p['transform'];assert not t['mirrored'] or f['allow_mirror'];assert f['rotations']['kind']=='free' or any(abs(math.degrees(t['rotation_radians'])%360-d)<1e-8 for d in f['rotations']['degrees']);g=f['geometry'][0];poly=transform(Polygon(g['outer']),t);full=transform(Polygon(g['outer'],g.get('holes',[])),t);assert poly.is_valid and full.is_valid and len(full.interiors)==len(g.get('holes',[]));holes+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]));sheet=int(p['sheet_id'].split('-')[1]);polys[item]=(sheet,poly);b=poly.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;edges.append({'item':item,'extra_margins_mm':extra})
for a,b in combinations(sorted(polys),2):
    sa,pa=polys[a];sb,pb=polys[b]
    if sa==sb:
        d=pa.distance(pb);assert pa.intersection(pb).area==0 and d>gap;pairs.append({'items':[a,b],'sheet_id':f'sheet-{sa}','distance_mm':d})
write(OUT/'first-sheet-placements.json',first);write(OUT/'short-sheet-placements.json',short);write(OUT/'partial64-placements.json',allp);write(OUT/'placed-identities.json',placed);write(OUT/'mandatory-first-additions.json',[63,64]);write(OUT/'original-pair-checks.json',pairs);write(OUT/'original-stock-checks.json',edges)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_placed':64,'first_sheet_originals':55,'short_sheet_originals':9,'short_counts':dict(Counter(p['part_id'] for p in short)),'old_fixed55_bound_not_applied_after_allocation_change':True,'first_removed_insert':36,'first_restored_cog':53,'short_cog_identity':65,'mandatory_first_additions':[63,64],'all66_identities_accounted_once':True,'original_pair_checks':len(pairs),'stock_edge_checks':len(edges)*4,'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_original_pair_gap_mm':min(r['distance_mm'] for r in pairs),'required_native_pair_gap_mm':gap,'minimum_extra_stock_margin_mm':min(min(r['extra_margins_mm']) for r in edges),'solver_calls':0,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
