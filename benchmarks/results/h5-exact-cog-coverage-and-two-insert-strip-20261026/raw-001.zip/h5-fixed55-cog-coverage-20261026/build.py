"""Build a finite rectangle cover by conservative original-point collision disks."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon,Point
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first-three-cog-space-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-fixed55-cog-coverage-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ratio=lambda x:[x.numerator,x.denominator]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[BASE/n for n in ['plan.json','fixed-originals-and-obstacles.json','center-stock.json','result.json']]+[GEOM/'original-cog-proof.json',GEOM/'audit/checks.json',SRC/'geometry.json',JOB]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_limit_seconds':120,'maximum_nodes':50000,'fixed_originals':55,'method':'Cover the entire outward-rounded continuous center-stock rectangle by dyadic axis-aligned cells. A cell is certified when all four corners lie strictly inside one integer collision disk. Disk centers come from exact source outer/interior points (radius109.10mm), or fixed cog inscribed-disk centers (radius218.20mm). Round transformed centers to1micrometre; an independent rational Taylor-interval audit must prove the rounding/error budget and source membership. Grid source points seed the cover; deterministic nearest source-edge/interior points may complete it. Store every split, leaf and uncovered cell. Empty floating geometry alone is never accepted as proof.'})
assert load(BASE/'result.json')['free_components']==0 and load(GEOM/'audit/checks.json')['passed'];job=load(JOB);families={p['id']:p for p in job['parts']};fixed=load(BASE/'fixed-originals-and-obstacles.json');assert len(fixed)==55
circles=[];seen=set();owners={r['item']:r for r in fixed};source_polys={f:Polygon(p['geometry'][0]['outer']) for f,p in families.items()};source_points={}
for f,p in families.items():
    g=source_polys[f];points={tuple(map(F,xy)) for xy in p['geometry'][0]['outer']}
    if f!='cog':
        b=g.bounds
        for x in range(math.ceil(b[0]/25)*25,math.floor(b[2]/25)*25+1,25):
            for y in range(math.ceil(b[1]/25)*25,math.floor(b[3]/25)*25+1,25):
                if g.covers(Point(x,y)):points.add((F(x),F(y)))
    source_points[f]=sorted(points)
def add(item,point,kind='original-point'):
    key=(item,point,kind)
    if key in seen:return
    seen.add(key);p=owners[item]['placement'];t=p['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);mi=-1 if t['mirrored'] else 1;x,y=map(float,point);tx,ty=t['translation'];cx,cy=round((mi*x*c-y*s+tx)*1000),round((mi*x*s+y*c+ty)*1000);r=218200 if kind=='cog-inscribed-center' else 109100
    circles.append({'index':len(circles),'item':item,'kind':kind,'source_point_rational':[ratio(v) for v in point],'center_units1000':[cx,cy],'radius_units1000':r})
center=tuple(map(F,load(GEOM/'original-cog-proof.json')['center']))
for r in fixed:
    for p in source_points[r['family']]:add(r['item'],p)
    if r['family']=='cog':add(r['item'],center,'cog-inscribed-center')
def arrays():return np.asarray([r['center_units1000'] for r in circles],dtype=np.int64),np.asarray([r['radius_units1000']**2 for r in circles],dtype=np.int64)
xy,rsq=arrays();seed_count=len(circles);root=[math.floor(F(v)*1000) if i<2 else math.ceil(F(v)*1000) for i,v in enumerate(load(BASE/'center-stock.json')['bounds'])];nodes=[{'index':0,'bounds':root}];queue=[0];pending=[];leaves=0;dynamic=0
def candidate(b):
    dx=np.maximum(np.abs(xy[:,0]-b[0]),np.abs(xy[:,0]-b[2]));dy=np.maximum(np.abs(xy[:,1]-b[1]),np.abs(xy[:,1]-b[3]));scores=dx*dx+dy*dy-rsq;i=int(np.argmin(scores));return i,int(scores[i])
def add_near(b):
    nonlocal_dummy=None
    wx,wy=(b[0]+b[2])/2000,(b[1]+b[3])/2000;world=Point(wx,wy);ranked=sorted(fixed,key=lambda r:Polygon(r['filled_outer']['coordinates'][0]).distance(world))[:3]
    for r in ranked:
        t=r['placement']['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];sx=mi*((wx-tx)*c+(wy-ty)*s);sy=-(wx-tx)*s+(wy-ty)*c
        point=(F(round(sx*10**9),10**9),F(round(sy*10**9),10**9));g=source_polys[r['family']]
        if g.covers(Point(float(point[0]),float(point[1]))):add(r['item'],point);continue
        vertices=[tuple(map(F,p)) for p in families[r['family']]['geometry'][0]['outer']];best=None
        for p,q in zip(vertices,vertices[1:]+vertices[:1]):
            vx,vy=float(q[0]-p[0]),float(q[1]-p[1]);d=vx*vx+vy*vy;u=max(0.,min(1.,((sx-float(p[0]))*vx+(sy-float(p[1]))*vy)/d));u=F(round(u*10**9),10**9);v=(p[0]+u*(q[0]-p[0]),p[1]+u*(q[1]-p[1]));distance=(float(v[0])-sx)**2+(float(v[1])-sy)**2
            if best is None or distance<best[0]:best=(distance,v)
        add(r['item'],best[1])
while queue and len(nodes)<50000 and time.perf_counter()-start<120:
    index=queue.pop();node=nodes[index];b=node['bounds'];ci,score=candidate(b)
    if score>=0 and max(b[2]-b[0],b[3]-b[1])<=1000:
        before=len(circles);add_near(b);dynamic+=len(circles)-before;xy,rsq=arrays();ci,score=candidate(b)
    if score<0:node.update({'circle':ci,'strict_margin_squared_units':-score});leaves+=1;continue
    axis=0 if b[2]-b[0]>=b[3]-b[1] else 1;mid=(b[axis]+b[axis+2])//2
    if mid in [b[axis],b[axis+2]]:pending.append(index);continue
    left=list(b);right=list(b);left[axis+2]=mid;right[axis]=mid;children=[len(nodes),len(nodes)+1];node.update({'axis':axis,'split':mid,'children':children});nodes.extend([{'index':children[0],'bounds':left},{'index':children[1],'bounds':right}]);queue.extend(children)
pending+=queue;write(OUT/'circles.json',circles);write(OUT/'cover-tree.json',nodes);write(OUT/'pending-cells.json',[nodes[i] for i in pending]);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'root_bounds_units1000':root,'seed_circles':seed_count,'dynamic_circles':dynamic,'circles':len(circles),'nodes':len(nodes),'covered_leaves':leaves,'uncovered_cells':len(pending),'complete_cover':not pending,'used_circles':len({n['circle'] for n in nodes if 'circle' in n}),'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
