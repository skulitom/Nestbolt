"""Exact rational source membership, trig intervals and continuous cell coverage."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from collections import Counter
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed55-cog-coverage-20261026';SCREEN=ROOT/'output/h5-first-three-cog-space-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ratio=lambda x:[x.numerator,x.denominator]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def contains(vertices,p):
    winding=0
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        cr=cross(a,b,p)
        if cr==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]) and min(a[1],b[1])<=p[1]<=max(a[1],b[1]):return True
        if a[1]<=p[1]<b[1] and cr>0:winding+=1
        if b[1]<=p[1]<a[1] and cr<0:winding-=1
    return winding!=0
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently prove every used original point belongs to the filled source polygon using exact rational winding/boundary checks. Bound the sine/cosine of each exact stored binary angle by a59th-degree Taylor polynomial and |angle|^60/60! remainder, then prove the rounded collision-center error fits the reserved radius loss. Verify exact corner containment and complete binary rectangle partition of an outward-rounded all-angle center-stock domain. No Shapely or floating buffer result is used for acceptance.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for n,h in load(SCREEN/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEOM/'audit/checks.json')['passed'];geom=load(GEOM/'original-cog-proof.json');assert geom['original_inscribed_radius_units1000']==109115 and geom['all_angle_stock_support_radius_units1000']==139270
job=load(JOB);families={p['id']:p for p in job['parts']};owners={r['item']:r for r in load(SCREEN/'fixed-originals-and-obstacles.json')};circles=load(BASE/'circles.json');nodes=load(BASE/'cover-tree.json');used=sorted({n['circle'] for n in nodes if 'circle' in n});assert len(owners)==55
stock=[F(*v) for v in load(SRC/'geometry.json')['stock_bounds_rational'][0]];h=F(139270,1000);relax=F(1,50);bounds=[stock[0]-relax+h,stock[1]-relax+h,stock[2]+relax-h,stock[3]+relax-h];root=[math.floor(v*1000) if i<2 else math.ceil(v*1000) for i,v in enumerate(bounds)];assert nodes[0]['bounds']==root
trig={};certs=[]
for i in used:
    circle=circles[i];assert circle['index']==i;owner=owners[circle['item']];p=owner['placement'];t=p['transform'];a=F(t['rotation_radians']);x,y=[F(*v) for v in circle['source_point_rational']];family=families[p['part_id']];vertices=[tuple(map(F,v)) for v in family['geometry'][0]['outer']]
    if circle['kind']=='cog-inscribed-center':assert p['part_id']=='cog' and [x,y]==list(map(F,geom['center'])) and circle['radius_units1000']==218200;available=F(218230,1000)
    else:assert circle['kind']=='original-point' and contains(vertices,(x,y)) and circle['radius_units1000']==109100;available=F(109115,1000)
    if a not in trig:
        s=sum(((-1)**k*a**(2*k+1)/math.factorial(2*k+1) for k in range(30)),F(0));c=sum(((-1)**k*a**(2*k)/math.factorial(2*k) for k in range(30)),F(0));error=abs(a)**60/math.factorial(60);trig[a]=(s,c,error)
    s,c,error=trig[a];mi=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation']);mx=mi*x*c-y*s+tx;my=mi*x*s+y*c+ty;coordinate_error=(abs(x)+abs(y))*error;cx,cy=[F(v,1000) for v in circle['center_units1000']];ex=abs(mx-cx)+coordinate_error;ey=abs(my-cy)+coordinate_error;allowance=available-F(circle['radius_units1000'],1000);assert ex*ex+ey*ey<allowance*allowance
    certs.append({'circle':i,'item':circle['item'],'exact_source_membership':True,'transformed_center_error_squared_upper_mm2':ratio(ex*ex+ey*ey),'radius_loss_squared_mm2':ratio(allowance*allowance)})
visited=set();stack=[0];leaves=[];minimum=None
while stack:
    i=stack.pop();assert i not in visited;visited.add(i);n=nodes[i];assert n['index']==i;b=n['bounds'];assert b[0]<b[2] and b[1]<b[3]
    if 'children' in n:
        assert 'circle' not in n and n['axis'] in [0,1];axis=n['axis'];mid=n['split'];assert b[axis]<mid<b[axis+2];left=list(b);right=list(b);left[axis+2]=mid;right[axis]=mid;l,r=n['children'];assert nodes[l]['bounds']==left and nodes[r]['bounds']==right;stack.extend([l,r])
    else:
        c=circles[n['circle']];cx,cy=c['center_units1000'];margin=c['radius_units1000']**2-max((x-cx)**2+(y-cy)**2 for x in [b[0],b[2]] for y in [b[1],b[3]]);assert margin==n['strict_margin_squared_units'] and margin>0;leaves.append(i);minimum=margin if minimum is None else min(minimum,margin)
assert visited==set(range(len(nodes))) and load(BASE/'pending-cells.json')==[];result=load(BASE/'result.json');assert result['complete_cover'] and result['nodes']==len(nodes) and result['covered_leaves']==len(leaves) and result['used_circles']==len(used)
write(OUT/'exact-source-center-certificates.json',certs);write(OUT/'leaf-owner-counts.json',dict(Counter(circles[nodes[i]['circle']]['item'] for i in leaves)))
write(OUT/'necessity-proof.json',{'fixed_first_originals':sorted(owners),'additional_original_cog_excluded':True,'all_real_angles_and_continuous_centers':True,'statement':'Every original cog contains the independently certified109.115mm disk about its source center. Each used original source point belongs exactly to a fixed filled outer; each used fixed cog center has its own109.115mm inscribed disk. Exact rational Taylor bounds place the transformed source point/center within the reserved0.015/0.030mm radius loss of the saved1micrometre center. Hence the interior of each109.10/218.20mm integer collision disk consists only of forbidden new cog centers. Every corner of every cover leaf is strictly inside its assigned disk; convexity covers the entire continuous rectangle. The binary splits exactly partition the whole outward-relaxed center-stock rectangle derived from all-angle hull support. Thus no additional original cog fits while these55 placements remain fixed. This does not exclude arrangements that move any fixed original, nor allocations whose first additions contain no cog.','new_six_bracket_short_eight_branch_cannot_finish_with_first55_fixed':True,'full66_infeasibility_claimed':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'fixed_originals':55,'exact_used_source_points_or_disks':len(used),'distinct_angles_interval_bounded':len(trig),'partition_nodes':len(nodes),'covered_continuous_cells':len(leaves),'minimum_strict_corner_margin_squared_units':minimum,'uncovered_cells':0,'additional_original_cog_excluded':True,'all_real_angles_covered':True,'no_floating_geometry_for_acceptance':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
