"""Replay the three diagnostic maps and audit the full released-cog inventory."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon,box,shape
from shapely.affinity import affine_transform
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog-space-screen-audit-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';names=['h5-first-three-cog-space-20261026','h5-first-fourteen-cog-space-20261026','h5-released-twelve-cog-space-20261026']
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();paths=[p for n in names for p in (ROOT/'output'/n).rglob('*') if p.is_file()];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Replay each saved diagnostic disk-center map using original source geometry and independent affine transforms. Verify all owner identities, every source digest, every obstacle, stock rectangle and complete union/difference. These checks establish reproducible screens only; no floating-map negative becomes exact proof. Independently enumerate the final43 fixed first originals,14 mandatory first cogs, and9 fixed short originals, accounting for all66 exactly once.'})
job=load(JOB);families={r['id']:r for r in job['parts']};items=load(SRC/'items.json');ids={(r['family'],r['copy']):i for i,r in enumerate(items)};summaries=[]
for name,count in zip(names,[55,44,43]):
    base=ROOT/'output'/name
    for n,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    rows=load(base/'fixed-originals-and-obstacles.json');assert len(rows)==count and len({r['item'] for r in rows})==count;obs=[]
    for r in rows:
        p=r['placement'];assert ids[p['part_id'],p['copy_index']]==r['item'] and p['sheet_id']=='sheet-0';t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;g=affine_transform(Polygon(families[p['part_id']]['geometry'][0]['outer']),[mi*c,-s,mi*s,c,*t['translation']]);saved=shape(r['filled_outer']);assert g.hausdorff_distance(saved)<1e-10 and abs(g.area-saved.area)<1e-7
        # Recreate saved direct-transform operand to compare exactly with GEOS.
        ob=saved.buffer(109.10,quad_segs=32,join_style='round');assert ob.equals(shape(r['disk_obstacle']));obs.append(ob)
    st=[F(*v) for v in load(SRC/'geometry.json')['stock_bounds_rational'][0]];h=F(139270,1000);e=F(1,50);bounds=[float(st[0]-e+h),float(st[1]-e+h),float(st[2]+e-h),float(st[3]+e-h)];assert bounds==load(base/'center-stock.json')['bounds'];region=box(*bounds).difference(unary_union(obs));assert region.equals(shape(load(base/'free-center-region.json')));components=load(base/'components.json');assert unary_union([shape(r['geometry']) for r in components]).equals(region) and len(components)==load(base/'result.json')['free_components']
    assert load(base/'result.json')['screen_only'] and not load(base/'result.json')['formal_infeasibility_claimed'];summaries.append({'screen':name,'fixed_originals':count,'free_components':len(components),'free_area_mm2':region.area,'formal_negative_claimed':False})
write(OUT/'verified-screens.json',summaries)
latest=ROOT/'output/h5-two-insert-short-sheet-20261026';first=load(latest/'first-sheet-placements.json');short=load(latest/'short-sheet-placements.json');fixed=[ids[p['part_id'],p['copy_index']] for p in first if p['part_id']!='cog'];seeds=[{'item':ids[p['part_id'],p['copy_index']],'placement':p} for p in first if p['part_id']=='cog'];moving=sorted([r['item'] for r in seeds]+[63,64]);shortids=[ids[p['part_id'],p['copy_index']] for p in short];assert len(fixed)==43 and len(seeds)==12 and len(moving)==14 and len(shortids)==9 and sorted(fixed+moving+shortids)==list(range(66));assert all(items[i]['family']=='cog' for i in moving);assert fixed==[r['item'] for r in load(ROOT/'output/h5-released-twelve-cog-space-20261026/fixed-originals-and-obstacles.json')]
write(OUT/'next-neighborhood.json',{'fixed_first_originals':fixed,'fixed_first_count':43,'fixed_first_family_counts':dict(Counter(items[i]['family'] for i in fixed)),'mandatory_moving_first_cogs':moving,'moving_count':14,'prior_original_cog_poses_for_diagnostics_only':seeds,'fixed_short_originals':shortids,'fixed_short_placements':short,'all66_originals_accounted_once':True,'allowed_cog_rotations':'free, no mirror','all_moving_cogs_mandatory':True,'old_fixed55_count_bound_applies':False,'old_fixed55_collision_cover_applies':False,'next_action':'Construct independently audited all-angle necessary center domains against these43 fixed non-cog originals, strengthening the disk-only screen with original support where valid. Retain all components and boundary cases before any new bounded solver call. A positive necessary model still requires actual source angles and all14 mutual original cog clearances. If the43-fixed neighborhood is excluded, release/rearrange non-cog originals rather than retrying a closed call. Full66 native/material validation is required before production integration and H5 matrix.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'diagnostic_maps_replayed':3,'fixed_obstacles_replayed':142,'formal_screen_negatives_claimed':0,'new_fixed_first_originals':43,'new_mandatory_moving_first_cogs':14,'fixed_short_originals':9,'existing_cog_seeds':12,'all66_originals_accounted_once':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
