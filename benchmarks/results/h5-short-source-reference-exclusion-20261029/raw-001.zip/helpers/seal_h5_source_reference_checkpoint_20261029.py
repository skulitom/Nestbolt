"""Seal the qualified count exclusion, preserved failures and complete updated frontier."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-source-projection-short-core-20261029';SYNC=ROOT/'output/h5-source-pair-main-sync-20261029';PUB=BASE/'publication';NAME='h5-short-source-reference-exclusion-20261029';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='3e33dedbed809b2fdd3b97a8784b50a25732c3c0' and not git('diff','HEAD','--name-only')
for folder in ['preflight/legacy-replay','preflight-v2/audit','model-audit','response-audit-v2','source-necessity-audit','frontier-audit','next-short12-preflight']:assert load(BASE/folder/'checks.json')['passed']
response=load(BASE/'response-audit-v2/checks.json');qualified=load(BASE/'source-necessity-audit/checks.json');assert response['status']=='INFEASIBLE' and response['closed_solver_calls']==1 and response['total_cumulative_constraints']==3 and qualified['remaining_necessary_allocations']==441 and qualified['excluded_source_short_counts']==[5,6,2]
assert qualified['larger_counts_excluded_by_deletion']==[[5,6,2],[5,7,2],[5,8,2]] and not qualified['whole_job_excluded'];receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['normal_atomic_fast_forward'] and receipt['prior_main_all6_pass']
prior=load(ROOT/'benchmarks/results/h5-short-strip-capacity-and-source-pair-20261029/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes'];up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert main==head and ci['head_sha']==main and ci['status']=='in_progress' and len(jobs)==6;passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==4 and set(live)=={'checks (windows-latest)','checks (ubuntu-latest)'}
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [BASE,SYNC]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_source_projection_replay_20261029.py','audit_h5_source_projection_legacy_replay_20261029.py','prepare_h5_source_projection_mapping_20261029.py','repair_h5_source_projection_mapping_inputs_20261029.py','prepare_h5_source_projection_mapping_v2_20261029.py','audit_h5_source_projection_mapping_20261029.py','prepare_h5_source_pair_main_push_20261029.py','push_h5_source_pair_checkpoint_20261029.py','build_h5_source_projection_short_core_20261029.py','repair_h5_source_projection_model_count_20261029.py','build_h5_source_projection_short_core_v2_20261029.py','repair_h5_source_projection_domain_read_20261029.py','build_h5_source_projection_short_core_v3_20261029.py','h5_source_projection_short_core_reader_20261029.py','prepare_h5_projection_assignment_reader_20261029.py','audit_h5_source_projection_short_core_model_20261029.py','prepare_h5_source_projection_call_20261029.py','run_h5_source_projection_short_core_20261029.py','check_h5_source_projection_short_core_candidate_20261029.py','prepare_h5_source_projection_response_reader_20261029.py','audit_h5_source_projection_short_core_response_20261029.py','repair_h5_projection_response_metadata_20261029.py','audit_h5_source_projection_short_core_response_v2_20261029.py','qualify_h5_source_projection_exclusion_20261029.py','audit_h5_projection_frontier_update_20261029.py','prepare_h5_next_short12_inventory_20261029.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_source_reference_archive_20261029.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[('preflight/legacy-replay/checks.json','legacy-projection-replay.json'),('preflight-v2/audit/checks.json','source-mapping-audit.json'),('preflight-v2/reference-link.json','reference-link-proof.json'),('preflight-v2/controls.json','projection-controls.json'),('model-v3/built.json','model.json'),('model-audit/checks.json','model-audit.json'),('response-audit-v2/checks.json','response-audit.json'),('source-necessity-audit/necessity-proof.json','source-necessity-proof.json'),('source-necessity-audit/checks.json','source-necessity-audit.json'),('source-necessity-audit/updated-allocations.json','updated-allocations.json'),('source-necessity-audit/pareto-necessary-counts.json','pareto-necessary-counts.json'),('frontier-audit/checks.json','frontier-audit.json'),('next-short12-preflight/inventory.json','next-short12-inventory.json'),('next-short12-preflight/checks.json','next-short12-preflight.json')]
for a,b in copies:shutil.copyfile(BASE/a,OUT/b)
write(OUT/'preserved-failures.json',[load(BASE/n) for n in ['preflight/failure.json','model/failure.json','model-v2/failure.json','response-audit/metadata-count-correction.json']]);shutil.copyfile(SYNC/'receipt.json',OUT/'prior-main-push-receipt.json');shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40800774981,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':'The all-movable short5/6/2 allocation and containing5/7/2,5/8/2 rows are now excluded; do not reopen them or any closed call. The new audited frontier retains441 candidates and32 maxima. Use the prepared neighboring short5/5/2 inventory: insert0 moves to the first sheet, which now requires54 originals=18frames/7brackets/16inserts/13cogs. All12 short originals remain mandatory, all modes/anchors remain movable. Build a distinct model with precisely that bookkeeping slot forced absent on short, while preserving every other source-reference constraint and all66 global obligations. Independently audit the changed mandatory constraint, inactive-owner guards, complete identities and changed source controls before its sole declared60/90-second call. The positive source11 control now lacks only cog0. Candidate readback must explicitly require12 short originals and54 first originals, never silently omit insert0. A source12 result is not a full66 witness; first-sheet construction, original/native/material validation, production integration and the entire H5 matrix remain required.','short12_inventory_prepared':True,'new_short12_model_created':False,'new_short12_search_opened':False,'remaining_necessary_allocations':441,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'closed_solver_calls':1,'terminal_status':'INFEASIBLE','source_count_exclusion_qualified':True,'new_excluded_short_counts':[[5,6,2],[5,7,2],[5,8,2]],'previous_survivors':444,'remaining_necessary_allocations':441,'all4576_rows_preserved':True,'remaining_pareto_counts':32,'model_variables':1876,'model_constraints':1913,'new_reference_links':13,'new_pair_tables':78,'new_directed_pair_rows':156,'insert_interval_capacity':2,'positive_source11_control_passed_with_only_missing_requirements_disabled':True,'negative13_failed_constraints':102,'all_preparation_build_and_summary_failures_preserved':True,'incumbents':0,'assignments':0,'native_calls':0,'source_valid12_created':False,'source_valid66_created':False,'whole_job_excluded':False,'valid64_preserved':True,'next_short_originals':12,'next_first_originals':54,'next_all66_identities_verified':True,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');assert s.startswith('# Status — 2026-10-28\n');s=s.replace('# Status — 2026-10-28\n','# Status — 2026-10-29\n',1);marker='## v1.1 — real shop files\n';assert marker in s;s=s.replace(marker,marker+f'\nLatest H5 evidence: [three short-sheet count vectors are excluded](../benchmarks/results/{NAME}.md),\nleaving 441 necessary allocation candidates. The complete 66-part layout and\nH5 quality matrix remain unverified; the existing valid 64-part layout is preserved.\n',1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'remaining_necessary_allocations':441,'completion_percent':60})
