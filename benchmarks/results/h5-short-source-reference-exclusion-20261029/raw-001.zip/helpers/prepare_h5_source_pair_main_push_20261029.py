"""Prepare the guarded normal push after the preceding main CI passed."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent;s=(ROOT/'push_h5_fixed9_checkpoint_20261029.py').read_text(encoding='utf-8')
s=s.replace('h5-fixed9-main-sync-20261029','h5-source-pair-main-sync-20261029').replace("OLD='6b0a1d0b2e2f5abdcddf9a3fb73c27cdb0d8e641';NEW='d3b652b6400057aab92bc47f8121e8a339a88d2d'","OLD='d3b652b6400057aab92bc47f8121e8a339a88d2d';NEW='3e33dedbed809b2fdd3b97a8784b50a25732c3c0'").replace('40789500705','40795603963').replace('benchmarks/results/h5-fixed-ten-joint-cog-bound-20261029','benchmarks/results/h5-global-short-core-searches-20261029').replace('benchmarks/results/h5-fixed-nine-triple-and-global-short-preflight-20261029','benchmarks/results/h5-short-strip-capacity-and-source-pair-20261029')
compile(s,'push_h5_source_pair_checkpoint_20261029.py','exec')
with (ROOT/'push_h5_source_pair_checkpoint_20261029.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Guarded push prepared.')
