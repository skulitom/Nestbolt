"""Preserve the initial count assertion and build in a distinct output directory."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short-core-20261029';assert not (BASE/'model/model.pb').exists()
failure={'status':'failed_at_final_model_assertion','script':'output/build_h5_source_projection_short_core_20261029.py','suspected_cause':'The hand count included18 constraints for6 insert intervals; they add6 end-link equalities and6 interval constraints, hence12, before their single cumulative row. Expected total is1913 rather than1919. The corrected distinct build will record actual counts and model validation before asserting.','original_model_directory_preserved':True,'solver_calls':0,'native_calls':0}
with (BASE/'model/failure.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(failure,f,indent=2);f.write('\n')
s=(ROOT/'output/build_h5_source_projection_short_core_20261029.py').read_text(encoding='utf-8').replace("OUT=BASE/'model'","OUT=BASE/'model-v2'").replace('1919','1913')
needle="mp['insert_projection_capacity']=model.add_cumulative(intervals,[1]*6,2).index;assert"
replacement="mp['insert_projection_capacity']=model.add_cumulative(intervals,[1]*6,2).index;write(OUT/'construction-diagnostics.json',{'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'pair_tables':len(mp['projection_pairs']),'validation':model.validate()});assert"
assert needle in s;s=s.replace(needle,replacement);name='build_h5_source_projection_short_core_v2_20261029.py';compile(s,name,'exec')
with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Initial count assertion failure preserved; distinct model-v2 builder prepared.')
