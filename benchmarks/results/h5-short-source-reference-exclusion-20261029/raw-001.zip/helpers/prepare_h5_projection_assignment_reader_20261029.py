"""Add generic cumulative evaluation to the independent complete-assignment reader."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent;source=(ROOT/'h5_coarse_short_core_reader_20261029.py').read_text(encoding='utf-8');part=source[source.index('def violations('):];part=part.replace('failed=[];rectangle_pairs=rectangle_collisions=0;tables=0','failed=[];rectangle_pairs=rectangle_collisions=0;tables=0;capacities=[]')
needle='        else:raise AssertionError(kind)'
replacement="""        elif kind=='cumulative':
            events={}
            for interval,demand in zip(c.cumulative.intervals,c.cumulative.demands):
                item=p.constraints[interval];assert item.WhichOneof('constraint')=='interval'
                if not active(item):continue
                start,end,d=ev(item.interval.start),ev(item.interval.end),ev(demand);assert start<end and d>0;events[start]=events.get(start,0)+d;events[end]=events.get(end,0)-d
            live=peak=0
            for coordinate,delta in sorted(events.items()):live+=delta;peak=max(peak,live)
            assert live==0;capacity=ev(c.cumulative.capacity);ok=peak<=capacity;capacities.append({'constraint':ix,'capacity':capacity,'peak_demand':peak,'passed':ok})
        else:raise AssertionError(kind)"""
assert needle in part;part=part.replace(needle,replacement).replace("'orthogonal_piece_collisions':rectangle_collisions}","'orthogonal_piece_collisions':rectangle_collisions,'cumulative_checks':capacities}");target=ROOT/'h5_source_projection_short_core_reader_20261029.py';prior=target.read_text(encoding='utf-8');assert 'def violations(' not in prior;compile(prior+'\n'+part,str(target),'exec')
with target.open('a',encoding='utf-8',newline='\n') as f:f.write('\n'+part)
print('Complete independent assignment reader includes all cumulative constraints.')
