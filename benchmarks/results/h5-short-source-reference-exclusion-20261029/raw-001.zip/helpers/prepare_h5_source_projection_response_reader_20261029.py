"""Read the terminal infeasible response separately from source-scope qualification."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent;s=(ROOT/'audit_h5_source_pair_short_core_response_20261029.py').read_text(encoding='utf-8').replace('h5-source-pair-short-core-20261029','h5-source-projection-short-core-20261029').replace('check_h5_source_pair_short_core_candidate_20261029','check_h5_source_projection_short_core_candidate_20261029').replace('prepare_h5_source_pair_call_20261029','prepare_h5_source_projection_call_20261029').replace('build_h5_source_pair_short_core_20261029','build_h5_source_projection_short_core_v3_20261029').replace("MODEL=BASE/'model'","MODEL=BASE/'model-v3'").replace('cp_model_pb2.UNKNOWN','cp_model_pb2.INFEASIBLE').replace("=='UNKNOWN'","=='INFEASIBLE'").replace("'status':'UNKNOWN'","'status':'INFEASIBLE'")
s=s.replace("'original_source_cog_x_separation_grid_units':2519,","'original_source_cog_x_separation_grid_units':2519,'auxiliary_source_references':13,'directed_pair_tables':78,'insert_interval_capacity':2,")
name='audit_h5_source_projection_short_core_response_20261029.py';compile(s,name,'exec')
with (ROOT/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Distinct terminal response reader prepared; source necessity remains separately qualified.')
