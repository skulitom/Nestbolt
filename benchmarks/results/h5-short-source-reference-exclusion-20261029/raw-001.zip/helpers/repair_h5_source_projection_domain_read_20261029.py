"""Retain the invalid-domain build and copy domain vectors before Python indexing."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short-core-20261029';diagnostic=json.loads((BASE/'model-v2/construction-diagnostics.json').read_bytes());assert diagnostic['variables']==1876 and diagnostic['constraints']==1913 and 'has no domain' in diagnostic['validation']
failure={'status':'invalid_model_before_export_or_search','diagnostic':diagnostic,'cause':'The installed native proto domain vector returns0 for negative indexing, unlike a Python list. Reading xd[-1] and wd[-1] gave zero upper bounds for new insert-end variables. Convert both domain vectors to Python lists before using their endpoints.','original_builder_and_outputs_preserved':True,'solver_calls':0,'native_calls':0}
with (BASE/'model-v2/failure.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(failure,f,indent=2);f.write('\n')
s=(ROOT/'output/build_h5_source_projection_short_core_v2_20261029.py').read_text(encoding='utf-8').replace("OUT=BASE/'model-v2'","OUT=BASE/'model-v3'");a="xd=model.proto.variables[rx].domain;wd=model.proto.variables[width].domain";b="xd=list(model.proto.variables[rx].domain);wd=list(model.proto.variables[width].domain)";assert a in s;s=s.replace(a,b);name='build_h5_source_projection_short_core_v3_20261029.py';compile(s,name,'exec')
with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Invalid model preserved; distinct model-v3 builder prepared.')
