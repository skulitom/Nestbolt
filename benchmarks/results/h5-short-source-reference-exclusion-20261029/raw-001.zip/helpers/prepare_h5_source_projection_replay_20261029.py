"""Open only a new source-mapping preflight and replay the prior projection audit."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short-core-20261029';BASE.mkdir();(BASE/'preflight').mkdir()
s=(ROOT/'output/audit_h5_insert_order_projection_20261028.py').read_text(encoding='utf-8').replace("OUT=BASE/'audit'","OUT=ROOT/'output/h5-source-projection-short-core-20261029/preflight/legacy-replay'");name='audit_h5_source_projection_legacy_replay_20261029.py';compile(s,name,'exec')
with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('New mapping preflight and distinct legacy audit replay prepared.')
