"""Preserve the missing-file preparation failure and create a distinct corrected reader."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-projection-short-core-20261029';OUT=BASE/'preflight-v2';OUT.mkdir()
failure={'status':'failed_before_plan_write','missing_input':'output/h5-short13-necessary-geometry-20261028/audit/plan.json','cause':'The historical geometry audit has audit.py and checks.json but no separate plan.json. Its source preparation has plan.json. The initial preparation stopped while hashing inputs, before writing the new base plan or any geometry outputs.','preserved_script':'output/prepare_h5_source_projection_mapping_20261029.py','preserved_copy':'output/h5-source-projection-short-core-20261029/preflight/prepare.py','model_created':False,'solver_calls':0,'native_calls':0}
with (BASE/'preflight/failure.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(failure,f,indent=2);f.write('\n')
s=(ROOT/'output/prepare_h5_source_projection_mapping_20261029.py').read_text(encoding='utf-8').replace("OUT=BASE/'preflight'","OUT=BASE/'preflight-v2'").replace("OUT/'legacy-replay/","BASE/'preflight/legacy-replay/").replace("VARS/'audit/plan.json'","VARS/'plan.json',VARS/'audit/audit.py'")
name='prepare_h5_source_projection_mapping_v2_20261029.py';compile(s,name,'exec')
with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Failure preserved; distinct preflight-v2 reader prepared.')
