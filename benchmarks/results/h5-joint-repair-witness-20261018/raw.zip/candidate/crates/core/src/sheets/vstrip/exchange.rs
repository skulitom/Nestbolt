//! Isolated experiment: return complete actual obstruction sets while inserting
//! a last-sheet part, repair both sheets, then check the whole original job.
use super::*;
mod material_profile;
use jagua_rs::entities::Item;
use jagua_rs::geometry::geo_traits::TransformableFrom;
use material_profile::material_profile;

// In the rotated strip frame, rightmost extent is original sheet height.
// Reach boundary parts before larger interior parts; equal geometry/area ties
// retain their input order. This changes proposal order, never acceptance.
fn rank_incoming(layout: &JLayout, keys: &mut [PItemKey]) {
    keys.sort_by(|&a, &b| {
        let a = &layout.placed_items()[a];
        let b = &layout.placed_items()[b];
        b.shape()
            .bbox()
            .x_max
            .total_cmp(&a.shape().bbox().x_max)
            .then_with(|| b.item().area().total_cmp(&a.item().area()))
    });
}

// Priority selects which members are considered. The original area/stable
// order still defines the anchor and relative frame of each chosen pair.
fn preserve_pair_frames(pairs: &mut [Vec<PItemKey>], original_order: &[PItemKey]) {
    for pair in pairs {
        pair.sort_by_key(|key| {
            original_order
                .iter()
                .position(|old| old == key)
                .expect("source member")
        });
    }
}

// Reserve the first choice in the appropriate existing pair list for the
// two highest-ranked source members. Keep nearby alternatives, remove the
// equivalent pair in either anchor order, and retain the original six cap.
// The caller restores each selected pair's original member frame afterwards.
fn include_boundary_pair(
    layout: &JLayout,
    keys: &[PItemKey],
    same: &mut Vec<Vec<PItemKey>>,
    mixed: &mut Vec<Vec<PItemKey>>,
) {
    let [a, b, ..] = keys else {
        return;
    };
    let pairs = if std::sync::Arc::ptr_eq(
        layout.placed_items()[*a].item(),
        layout.placed_items()[*b].item(),
    ) {
        same
    } else {
        mixed
    };
    pairs.retain(|pair| !(pair.len() == 2 && pair.contains(a) && pair.contains(b)));
    pairs.insert(0, vec![*a, *b]);
    pairs.truncate(6);
}

struct Proposal {
    victims: Vec<PItemKey>,
    incoming: DTransformation,
    blockers: usize,
    rank: usize,
    area: f32,
}

// Conservative equality: exact bits and shared immutable model identity.
// Ignore placement keys and order, retain multiplicity. A false result does
// not prove changed geometry (e.g. -0 versus +0); true is conservative.
fn exact_physical_state(a: &JLayout, b: &JLayout) -> bool {
    use std::sync::Arc;
    if !Arc::ptr_eq(a.container().base_cde(), b.container().base_cde())
        || !Arc::ptr_eq(a.container().outer_orig(), b.container().outer_orig())
        || !Arc::ptr_eq(a.container().outer_cd(), b.container().outer_cd())
        || a.placed_items().len() != b.placed_items().len()
    {
        return false;
    }
    let keys = |layout: &JLayout| {
        let mut keys: Vec<_> = layout
            .placed_items()
            .values()
            .map(|p| {
                let dt = p.d_transf();
                let (x, y) = dt.translation();
                (
                    p.item().idx(),
                    Arc::as_ptr(p.item()) as usize,
                    [dt.rotation().to_bits(), x.to_bits(), y.to_bits()],
                    dt.reflected,
                )
            })
            .collect();
        keys.sort_unstable();
        keys
    };
    keys(a) == keys(b)
}

fn exchange_increases_material(before: &Metrics, after: &Metrics) -> bool {
    after.sheets_used > before.sheets_used || after.material_area > before.material_area
}

fn retain_proposal(out: &mut Vec<Proposal>, proposal: Proposal) {
    if let Some(previous) = out.iter().position(|p| p.victims == proposal.victims) {
        if out[previous].blockers <= proposal.blockers {
            return;
        }
        out.remove(previous);
    }
    out.push(proposal);
    out.sort_by(|a, b| {
        (a.blockers - a.victims.len())
            .cmp(&(b.blockers - b.victims.len()))
            .then(a.area.total_cmp(&b.area))
            .then(a.rank.cmp(&b.rank))
    });
    out.truncate(6);
}

fn proposals(
    receiver: &JLayout,
    incoming: &Item,
    rng: &mut Xoshiro256PlusPlus,
    clock: &Clock,
    until: f64,
) -> Vec<Proposal> {
    let bounds = receiver.container().outer_cd().bbox();
    let mut buffer = incoming.shape_cd().as_ref().clone();
    let mut samples = Vec::new();
    // Anchors make an actual obstruction, rather than a merely nearby part,
    // the return candidate. Align bounding-box corners after snapping rotation.
    for p in receiver.placed_items().values() {
        let dt = convert_sample_to_closest_feasible(p.d_transf(), incoming);
        buffer.transform_from(incoming.shape_cd(), &dt.compose());
        let a = buffer.bbox();
        let b = p.shape().bbox();
        let (x, y) = dt.translation();
        samples.push(
            DTransformation::new(
                dt.rotation(),
                (x + b.x_min - a.x_min, y + b.y_min - a.y_min),
            )
            .with_reflection(dt.reflected),
        );
    }
    if let Some(sampler) = UniformBBoxSampler::new(bounds, incoming, bounds) {
        samples.extend((0..128).map(|_| sampler.sample(rng)));
    }
    let mut collector = BasicHazardCollector::new();
    let mut out: Vec<Proposal> = Vec::new();
    for dt in samples {
        if clock.now() >= until {
            break;
        }
        buffer.transform_from(incoming.shape_cd(), &dt.compose());
        collector.clear();
        receiver
            .cde()
            .collect_poly_collisions(&buffer, &NoFilter, &mut collector);
        crate::separate::charge(clock, incoming, 1);
        if collector.is_empty()
            || collector.len() > 3
            || collector
                .iter()
                .any(|(_, h)| !matches!(h, BasicHazardEntity::PlacedItem { .. }))
        {
            continue;
        }
        // Moving every actual obstruction can leave a feasible receiver when
        // evicting only one leaves known collisions. Returned filled area can
        // increase while last-sheet height and material stay unchanged. Both
        // repairs and the whole-job material guard still control acceptance.
        // Keep the original smaller single-victim alternatives as a fallback.
        let blocked: Vec<_> = receiver
            .placed_items()
            .iter()
            .enumerate()
            .filter(|(_, (key, _))| {
                collector.iter().any(
                    |(_, h)| matches!(h, BasicHazardEntity::PlacedItem { pk, .. } if *pk == *key),
                )
            })
            .collect();
        let area: f32 = blocked.iter().map(|(_, (_, p))| p.item().area()).sum();
        if blocked.len() > 1 {
            retain_proposal(
                &mut out,
                Proposal {
                    victims: blocked.iter().map(|(_, (key, _))| *key).collect(),
                    incoming: dt,
                    blockers: collector.len(),
                    rank: blocked[0].0,
                    area,
                },
            );
        }
        // Stable receiver placement order, independent of tree traversal order.
        for (rank, (key, p)) in receiver.placed_items().iter().enumerate() {
            if p.item().area() >= incoming.area()
                || !collector.iter().any(
                    |(_, h)| matches!(h, BasicHazardEntity::PlacedItem { pk, .. } if *pk == key),
                )
            {
                continue;
            }
            let proposal = Proposal {
                victims: vec![key],
                incoming: dt,
                blockers: collector.len(),
                rank,
                area: p.item().area(),
            };
            retain_proposal(&mut out, proposal);
        }
    }
    out
}

// Bounds work is charged both for the original seed and any proposed shift.
// The existing separator and whole-job validator still decide feasibility.
fn return_group_bounds(
    victims: &[IncomingMember],
    poses: &[DTransformation],
    clock: &Clock,
) -> Option<Rect> {
    let mut x0 = f32::INFINITY;
    let mut y0 = f32::INFINITY;
    let mut x1 = f32::NEG_INFINITY;
    let mut y1 = f32::NEG_INFINITY;
    for ((_, item, _), pose) in victims.iter().zip(poses) {
        let mut shape = item.shape_cd().as_ref().clone();
        shape.transform_from(item.shape_cd(), &pose.compose());
        crate::separate::charge(clock, item, 1);
        let bounds = shape.bbox();
        if ![bounds.x_min, bounds.y_min, bounds.x_max, bounds.y_max]
            .into_iter()
            .all(f32::is_finite)
        {
            return None;
        }
        x0 = x0.min(bounds.x_min);
        y0 = y0.min(bounds.y_min);
        x1 = x1.max(bounds.x_max);
        y1 = y1.max(bounds.y_max);
    }
    Rect::try_new(x0, y0, x1, y1).ok()
}

// Shift a fitting return seed as a whole into the existing source box.
// Already contained, oversized, malformed or numerically uncontained results
// retain the original seed exactly. Translation leaves permissions intact;
// no random samples, deadline extensions or acceptance changes are introduced.
fn contain_return_group(
    victims: &[IncomingMember],
    poses: &mut [DTransformation],
    bounds: &Rect,
    clock: &Clock,
) -> bool {
    if victims.is_empty() || victims.len() > 3 || victims.len() != poses.len() {
        return false;
    }
    let Some(before) = return_group_bounds(victims, poses, clock) else {
        return false;
    };
    if before.x_max - before.x_min > bounds.x_max - bounds.x_min
        || before.y_max - before.y_min > bounds.y_max - bounds.y_min
    {
        return false;
    }
    let correction = |low: f32, high: f32, min: f32, max: f32| {
        // Place the seed just inside instead of exactly on a rounded edge.
        // The final box check remains exact; this is a real translation,
        // never a relaxed geometry tolerance. Limit it to half the free span.
        let scale = low
            .abs()
            .max(high.abs())
            .max(min.abs())
            .max(max.abs())
            .max(1.0);
        let room = ((max - min) - (high - low)).max(0.0);
        let inset = (4.0 * f32::EPSILON * scale).min(room * 0.5);
        if low < min {
            min - low + inset
        } else if high > max {
            max - high - inset
        } else {
            0.0
        }
    };
    let dx = correction(before.x_min, before.x_max, bounds.x_min, bounds.x_max);
    let dy = correction(before.y_min, before.y_max, bounds.y_min, bounds.y_max);
    if dx == 0.0 && dy == 0.0 {
        return false;
    }
    let shifted: Vec<_> = poses
        .iter()
        .map(|pose| {
            let (x, y) = pose.translation();
            DTransformation::new(pose.rotation(), (x + dx, y + dy)).with_reflection(pose.reflected)
        })
        .collect();
    let Some(after) = return_group_bounds(victims, &shifted, clock) else {
        return false;
    };
    if after.x_min < bounds.x_min
        || after.y_min < bounds.y_min
        || after.x_max > bounds.x_max
        || after.y_max > bounds.y_max
    {
        return false;
    }
    poses.copy_from_slice(&shifted);
    true
}

// Bounded free-space search changes only the return seed. Every candidate
// keeps the original orientation and whole item geometry. Collision proxies
// reserve hole interiors. No clear candidate means the original repair seed.
fn free_return_pose(
    source: &JLayout,
    item: &Item,
    fallback: DTransformation,
    clock: &Clock,
    until: f64,
) -> DTransformation {
    if clock.now() >= until || !item.allowed_orientations().allows(&fallback) {
        return fallback;
    }
    let bounds = source.container().outer_cd().bbox();
    let mut buffer = item.shape_cd().as_ref().clone();
    buffer.transform_from(item.shape_cd(), &fallback.compose());
    let initial = buffer.bbox();
    let mut best = if source.cde().detect_poly_collision(&buffer, &NoFilter) {
        None
    } else {
        Some((fallback, initial.x_max, initial.y_min))
    };
    crate::separate::charge(clock, item, 1);
    let width = initial.x_max - initial.x_min;
    let height = initial.y_max - initial.y_min;
    let scale = [
        bounds.x_min,
        bounds.x_max,
        bounds.y_min,
        bounds.y_max,
        initial.x_min,
        initial.x_max,
        initial.y_min,
        initial.y_max,
    ]
    .into_iter()
    .map(f32::abs)
    .fold(1.0_f32, f32::max);
    // Real inset, not a collision or material tolerance. Exact bounds and the
    // existing collision detector still decide whether a seed is usable.
    let inset = 4.0 * f32::EPSILON * scale;
    let x0 = bounds.x_min + inset;
    let x1 = bounds.x_max - width - inset;
    let y0 = bounds.y_min + inset;
    let y1 = bounds.y_max - height - inset;
    if ![x0, x1, y0, y1].iter().all(|v| v.is_finite()) || x1 < x0 || y1 < y0 {
        return fallback;
    }
    let mut samples = Vec::with_capacity(256);
    // A fixed 12 by 12 grid covers the entire source container. Up to 28
    // existing members also contribute four box-edge anchors each. The cap
    // bounds work independently of inventory size; input order breaks ties.
    for x in 0..12 {
        for y in 0..12 {
            samples.push((
                x0 + (x1 - x0) * x as f32 / 11.0,
                y0 + (y1 - y0) * y as f32 / 11.0,
            ));
        }
    }
    for p in source.placed_items().values().take(28) {
        let b = p.shape().bbox();
        samples.extend([
            (b.x_max + inset, b.y_min),
            (b.x_min - width - inset, b.y_min),
            (b.x_min, b.y_max + inset),
            (b.x_min, b.y_min - height - inset),
        ]);
    }
    clock.charge(Work::RectOperation, samples.len() as f64);
    let (dx, dy) = fallback.translation();
    for (x, y) in samples {
        if clock.now() >= until {
            break;
        }
        if x < x0 || x > x1 || y < y0 || y > y1 {
            continue;
        }
        let pose = DTransformation::new(
            fallback.rotation(),
            (dx + x - initial.x_min, dy + y - initial.y_min),
        )
        .with_reflection(fallback.reflected);
        buffer.transform_from(item.shape_cd(), &pose.compose());
        let b = buffer.bbox();
        crate::separate::charge(clock, item, 1);
        if b.x_min < bounds.x_min
            || b.x_max > bounds.x_max
            || b.y_min < bounds.y_min
            || b.y_max > bounds.y_max
            || best
                .as_ref()
                .is_some_and(|(_, bx, by)| (b.x_max, b.y_min) >= (*bx, *by))
        {
            continue;
        }
        if !source.cde().detect_poly_collision(&buffer, &NoFilter) {
            best = Some((pose, b.x_max, b.y_min));
        }
    }
    best.map_or(fallback, |b| b.0)
}

// Only choose the reciprocal frame when every returned part permits it. The
// separator can still move the parts independently; this is an initial pose.
fn return_group_poses(
    victims: &[(PItemKey, std::sync::Arc<Item>, DTransformation)],
    incoming_here: DTransformation,
    incoming_before: DTransformation,
) -> Vec<DTransformation> {
    let (from_x, from_y) = incoming_here.translation();
    let (to_x, to_y) = incoming_before.translation();
    let translated = || {
        victims
            .iter()
            .map(|(_, _, previous)| {
                let (x, y) = previous.translation();
                DTransformation::new(previous.rotation(), (x + to_x - from_x, y + to_y - from_y))
                    .with_reflection(previous.reflected)
            })
            .collect()
    };
    // Keep the previous arithmetic exactly when the two frames already agree.
    if incoming_here.rotation() == incoming_before.rotation()
        && incoming_here.reflected == incoming_before.reflected
    {
        return translated();
    }
    let frame = incoming_here
        .compose()
        .inverse()
        .transform(&incoming_before.compose());
    let aligned: Option<Vec<_>> = victims
        .iter()
        .map(|(_, victim, previous)| {
            let pose = previous.compose().transform(&frame).decompose();
            victim.allowed_orientations().allows(&pose).then_some(pose)
        })
        .collect();
    aligned.unwrap_or_else(translated)
}

type IncomingMember = (PItemKey, std::sync::Arc<Item>, DTransformation);

// Distribute a bounded set of nearby same-item pairs across original part types.
// The caller supplies stable decreasing-area order. Pointer identity keeps
// distinct original items separate even when their shapes or indices match.
fn incoming_pairs(layout: &JLayout, keys: &[PItemKey]) -> Vec<Vec<PItemKey>> {
    let mut groups: Vec<Vec<usize>> = Vec::new();
    for (index, &key) in keys.iter().enumerate() {
        let item = layout.placed_items()[key].item();
        if let Some(group) = groups.iter_mut().find(|group| {
            std::sync::Arc::ptr_eq(layout.placed_items()[keys[group[0]]].item(), item)
        }) {
            group.push(index);
        } else {
            groups.push(vec![index]);
        }
    }
    groups.retain(|group| group.len() >= 2);
    let mut anchors = Vec::new();
    for rank in 0..12 {
        for (group, members) in groups.iter().enumerate() {
            if let Some(&index) = members.get(rank) {
                anchors.push((group, index));
                if anchors.len() == 12 {
                    break;
                }
            }
        }
        if anchors.len() == 12 {
            break;
        }
    }
    let mut grouped_pairs = vec![Vec::new(); groups.len()];
    for (group, i) in anchors {
        let a = layout.placed_items()[keys[i]].shape().bbox();
        let mut neighbours: Vec<_> = groups[group]
            .iter()
            .filter_map(|&j| {
                if i == j {
                    return None;
                }
                let b = layout.placed_items()[keys[j]].shape().bbox();
                let dx = (a.x_min + a.x_max) - (b.x_min + b.x_max);
                let dy = (a.y_min + a.y_max) - (b.y_min + b.y_max);
                Some((dx * dx + dy * dy, j))
            })
            .collect();
        neighbours.sort_by(|a, b| a.0.total_cmp(&b.0).then(a.1.cmp(&b.1)));
        for (_, j) in neighbours.into_iter().take(2) {
            let pair = (i.min(j), i.max(j));
            if !grouped_pairs[group].contains(&pair) {
                grouped_pairs[group].push(pair);
            }
        }
    }
    let mut pairs = Vec::new();
    for rank in 0..24 {
        for group in &grouped_pairs {
            if let Some(&(a, b)) = group.get(rank) {
                pairs.push(vec![keys[a], keys[b]]);
                if pairs.len() == 6 {
                    return pairs;
                }
            }
        }
    }
    pairs
}

// Try nearby members of different original items, including singleton types.
// Input order is stable and area-ranked. Bounds match the existing selector.
fn mixed_incoming_pairs(layout: &JLayout, keys: &[PItemKey]) -> Vec<Vec<PItemKey>> {
    let mut pairs = Vec::new();
    let mut seen = Vec::new();
    for (i, &key) in keys.iter().enumerate().take(12) {
        let item = layout.placed_items()[key].item();
        let a = layout.placed_items()[key].shape().bbox();
        let mut neighbours: Vec<_> = keys
            .iter()
            .enumerate()
            .filter_map(|(j, &other)| {
                if i == j || std::sync::Arc::ptr_eq(item, layout.placed_items()[other].item()) {
                    return None;
                }
                let b = layout.placed_items()[other].shape().bbox();
                let dx = (a.x_min + a.x_max) - (b.x_min + b.x_max);
                let dy = (a.y_min + a.y_max) - (b.y_min + b.y_max);
                Some((dx * dx + dy * dy, j))
            })
            .collect();
        neighbours.sort_by(|a, b| a.0.total_cmp(&b.0).then(a.1.cmp(&b.1)));
        for (_, j) in neighbours.into_iter().take(2) {
            let pair = (i.min(j), i.max(j));
            if !seen.contains(&pair) {
                seen.push(pair);
                pairs.push(vec![keys[pair.0], keys[pair.1]]);
                if pairs.len() == 6 {
                    return pairs;
                }
            }
        }
    }
    pairs
}

fn same_original_inventory(a: &[IncomingMember], b: &[IncomingMember]) -> bool {
    a.len() == b.len()
        && a.iter().all(|(_, item, _)| {
            a.iter()
                .filter(|(_, other, _)| std::sync::Arc::ptr_eq(item, other))
                .count()
                == b.iter()
                    .filter(|(_, other, _)| std::sync::Arc::ptr_eq(item, other))
                    .count()
        })
}

// Incoming groups must preserve their relative transform and every member's
// permissions. An illegal mapped orientation rejects this proposal as a whole.
fn incoming_group_poses(
    members: &[IncomingMember],
    anchor: DTransformation,
) -> Option<Vec<DTransformation>> {
    let old = members.first()?.2;
    let same = old.rotation() == anchor.rotation() && old.reflected == anchor.reflected;
    let frame = old.compose().inverse().transform(&anchor.compose());
    let (ox, oy) = old.translation();
    let (nx, ny) = anchor.translation();
    members
        .iter()
        .enumerate()
        .map(|(i, (_, item, previous))| {
            let pose = if i == 0 {
                anchor
            } else if same {
                let (px, py) = previous.translation();
                DTransformation::new(previous.rotation(), (px + nx - ox, py + ny - oy))
                    .with_reflection(previous.reflected)
            } else {
                previous.compose().transform(&frame).decompose()
            };
            item.allowed_orientations().allows(&pose).then_some(pose)
        })
        .collect()
}

fn paired_proposals(
    receiver: &JLayout,
    incoming: &[IncomingMember],
    rng: &mut Xoshiro256PlusPlus,
    clock: &Clock,
    until: f64,
) -> Vec<Proposal> {
    debug_assert_eq!(incoming.len(), 2);
    let anchor = &incoming[0].1;
    let bounds = receiver.container().outer_cd().bbox();
    let mut samples = Vec::new();
    let mut buffer = anchor.shape_cd().as_ref().clone();
    for p in receiver.placed_items().values() {
        let dt = convert_sample_to_closest_feasible(p.d_transf(), anchor);
        buffer.transform_from(anchor.shape_cd(), &dt.compose());
        let a = buffer.bbox();
        let b = p.shape().bbox();
        let (x, y) = dt.translation();
        samples.push(
            DTransformation::new(
                dt.rotation(),
                (x + b.x_min - a.x_min, y + b.y_min - a.y_min),
            )
            .with_reflection(dt.reflected),
        );
    }
    if let Some(sampler) = UniformBBoxSampler::new(bounds, anchor, bounds) {
        samples.extend((0..128).map(|_| sampler.sample(rng)));
    }
    if !std::sync::Arc::ptr_eq(&incoming[0].1, &incoming[1].1) {
        for p in receiver.placed_items().values() {
            let dt = convert_sample_to_closest_feasible(p.d_transf(), anchor);
            let Some(poses) = incoming_group_poses(incoming, dt) else {
                continue;
            };
            let mut min_x = f32::INFINITY;
            let mut min_y = f32::INFINITY;
            for ((_, item, _), pose) in incoming.iter().zip(poses) {
                let mut shape = item.shape_cd().as_ref().clone();
                shape.transform_from(item.shape_cd(), &pose.compose());
                min_x = min_x.min(shape.bbox().x_min);
                min_y = min_y.min(shape.bbox().y_min);
                crate::separate::charge(clock, item, 1);
            }
            let b = p.shape().bbox();
            let (x, y) = dt.translation();
            samples.push(
                DTransformation::new(dt.rotation(), (x + b.x_min - min_x, y + b.y_min - min_y))
                    .with_reflection(dt.reflected),
            );
        }
    }
    let mut collector = BasicHazardCollector::new();
    let mut out = Vec::new();
    for sample in samples {
        if clock.now() >= until {
            break;
        }
        let Some(poses) = incoming_group_poses(incoming, sample) else {
            continue;
        };
        let mut collisions = Vec::new();
        let mut allowed = true;
        for ((_, item, _), pose) in incoming.iter().zip(&poses) {
            buffer = item.shape_cd().as_ref().clone();
            buffer.transform_from(item.shape_cd(), &pose.compose());
            collector.clear();
            receiver
                .cde()
                .collect_poly_collisions(&buffer, &NoFilter, &mut collector);
            crate::separate::charge(clock, item, 1);
            for (_, hazard) in collector.iter() {
                if let BasicHazardEntity::PlacedItem { pk, .. } = hazard {
                    if !collisions.contains(pk) {
                        collisions.push(*pk);
                    }
                } else {
                    allowed = false;
                }
            }
            if !allowed || collisions.len() > 3 {
                break;
            }
        }
        if !allowed || collisions.is_empty() || collisions.len() > 3 {
            continue;
        }
        // Keep the complete union of both incoming members' actual obstructions.
        let victims: Vec<_> = receiver
            .placed_items()
            .iter()
            .enumerate()
            .filter(|(_, (key, _))| collisions.contains(key))
            .collect();
        let area: f32 = victims.iter().map(|(_, (_, p))| p.item().area()).sum();
        retain_proposal(
            &mut out,
            Proposal {
                victims: victims.iter().map(|(_, (key, _))| *key).collect(),
                incoming: sample,
                blockers: victims.len(),
                rank: victims[0].0,
                area,
            },
        );
    }
    out
}

// A successful flat exchange remains accepted, but must end continuation.
fn continue_exchanges(mut step: impl FnMut() -> Result<Option<bool>>) -> Result<usize> {
    let mut accepted = 0;
    for _ in 0..4 {
        let Some(material_improved) = step()? else {
            break;
        };
        accepted += 1;
        if !material_improved {
            break;
        }
    }
    Ok(accepted)
}

// Both phases share the original four-acceptance window cap.
#[cfg(test)]
fn continue_remaining_exchanges(
    accepted: usize,
    mut step: impl FnMut() -> Result<Option<bool>>,
) -> Result<usize> {
    let mut extra = 0;
    for _ in accepted..4 {
        let Some(material_improved) = step()? else {
            break;
        };
        extra += 1;
        if !material_improved {
            break;
        }
    }
    Ok(extra)
}

fn source_repair_deadline(short: f64, phase: f64, extended: bool) -> f64 {
    if extended { phase } else { short }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ExchangePolicy {
    Short,
    Extended,
    AssignmentBridge,
}

// Stable original-part order gives equal inventories exactly equal areas,
// regardless of placement keys, copy order, internal orientation or reflection.
// Hole interiors remain reserved. This is an internal progress measure only.
fn assignment_source_area(strip: &Strip, layout: &JLayout, shape: Shape) -> f64 {
    let mut counts = vec![0_usize; strip.model.job.parts.len()];
    for p in layout
        .placed_items()
        .values()
        .filter(|p| !strip.is_blocker(p) && strip.sheet_of(p.shape()) == shape.sheets - 1)
    {
        counts[strip.model.part[p.item().idx()]] += 1;
    }
    strip
        .clock
        .charge(Work::RegisteredItem, layout.placed_items().len() as f64);
    let mut area = 0.0;
    for (part, count) in strip.model.job.parts.iter().zip(counts) {
        if count == 0 {
            continue;
        }
        let one = part
            .geometry
            .iter()
            .map(|g| crate::curves::signed_area(&g.outer).abs())
            .sum::<f64>();
        let vertices = part.geometry.iter().map(|g| g.outer.len()).sum::<usize>();
        strip.clock.charge(Work::TrackedVertex, vertices as f64);
        area += one * count as f64;
    }
    area
}

impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search<'_, '_, F> {
    fn exchange_layout(
        &self,
        strip: &Strip,
        frozen: &[SPProblem],
        layout: &JLayout,
        shape: Shape,
    ) -> Result<Layout> {
        let mut sheets = frozen.to_vec();
        sheets.extend(strip.split(layout, shape.sheets)?);
        Ok(self.model.to_layout(&sheets))
    }

    fn exchange_report(&mut self, layout: &Layout) -> Result<Report> {
        let started = Instant::now();
        let report = validate(self.model.job, layout)?;
        self.clock.validated(self.model.job, layout);
        self.check_cost = self.check_cost.max(started.elapsed().as_secs_f64());
        Ok(report)
    }

    pub(super) fn assignment_bridge_window(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        short_until: f64,
        until: f64,
    ) -> Result<usize> {
        let accepted = self.directed_exchange_chain(strip, frozen, sep, shape, short_until)?;
        let extra = self.assignment_bridge_chain(strip, frozen, sep, shape, until, accepted)?;
        Ok(accepted + extra)
    }

    fn assignment_bridge_chain(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
        accepted: usize,
    ) -> Result<usize> {
        if accepted >= 4
            || !self.allow_exchange
            || shape.sheets < 2
            || self.clock.now() >= self.last_step(until)
        {
            return Ok(0);
        }
        let mut checkpoint = (
            sep.layout.save(),
            sep.tracker.clone(),
            [
                self.stats.directed_exchanges,
                self.stats.paired_exchanges,
                self.stats.mixed_exchanges,
                self.stats.extended_exchanges,
            ],
        );
        self.clock
            .charge(Work::RegisteredItem, sep.layout.placed_items().len() as f64);
        let mut pending = 0_usize;
        let mut committed = 0_usize;
        let outcome = (|| -> Result<()> {
            for _ in accepted..4 {
                let Some(improved) = self.directed_exchange_policy(
                    strip,
                    frozen,
                    sep,
                    shape,
                    until,
                    ExchangePolicy::AssignmentBridge,
                )?
                else {
                    break;
                };
                pending += 1;
                self.stats.assignment_bridge_steps += 1;
                self.stats.assignment_bridge_flat_steps += u64::from(!improved);
                if improved {
                    committed += pending;
                    self.stats.assignment_bridge_committed += pending as u64;
                    pending = 0;
                    checkpoint = (
                        sep.layout.save(),
                        sep.tracker.clone(),
                        [
                            self.stats.directed_exchanges,
                            self.stats.paired_exchanges,
                            self.stats.mixed_exchanges,
                            self.stats.extended_exchanges,
                        ],
                    );
                    self.clock
                        .charge(Work::RegisteredItem, sep.layout.placed_items().len() as f64);
                }
            }
            Ok(())
        })();
        // The snapshot and tracker are kept together: stale placement keys
        // are never transferred to a separately rebuilt/re-keyed layout.
        // Keep attempts and provisional diagnostics, restore only committed
        // acceptance counts along with the last strictly improved incumbent.
        if pending > 0 {
            self.stats.assignment_bridge_rolled_back += pending as u64;
            self.stats.assignment_bridge_rollbacks += 1;
            sep.layout = JLayout::from_snapshot(&checkpoint.0);
            sep.tracker = checkpoint.1;
            self.clock
                .charge(Work::RegisteredItem, sep.layout.placed_items().len() as f64);
            [
                self.stats.directed_exchanges,
                self.stats.paired_exchanges,
                self.stats.mixed_exchanges,
                self.stats.extended_exchanges,
            ] = checkpoint.2;
        }
        outcome?;
        Ok(committed)
    }

    #[cfg(test)]
    pub(super) fn directed_exchange_window(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        short_until: f64,
        until: f64,
    ) -> Result<usize> {
        let accepted = self.directed_exchange_chain(strip, frozen, sep, shape, short_until)?;
        let extra = self.extend_exchange_chain(strip, frozen, sep, shape, until, accepted)?;
        Ok(accepted + extra)
    }

    #[cfg(test)]
    fn extend_exchange_chain(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
        accepted: usize,
    ) -> Result<usize> {
        continue_remaining_exchanges(accepted, || {
            self.directed_exchange_mode(strip, frozen, sep, shape, until, true)
        })
    }

    pub(super) fn directed_exchange_chain(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
    ) -> Result<usize> {
        // Each attempt receives the original absolute deadline. The already
        // validated material comparison supplies the continuation decision.
        continue_exchanges(|| self.directed_exchange_once(strip, frozen, sep, shape, until))
    }

    #[cfg(test)]
    fn directed_exchange(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
    ) -> Result<usize> {
        Ok(usize::from(
            self.directed_exchange_once(strip, frozen, sep, shape, until)?
                .is_some(),
        ))
    }

    fn directed_exchange_once(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
    ) -> Result<Option<bool>> {
        self.directed_exchange_mode(strip, frozen, sep, shape, until, false)
    }

    fn directed_exchange_mode(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
        extended: bool,
    ) -> Result<Option<bool>> {
        self.directed_exchange_policy(
            strip,
            frozen,
            sep,
            shape,
            until,
            if extended {
                ExchangePolicy::Extended
            } else {
                ExchangePolicy::Short
            },
        )
    }

    /// At most one exchange. The original separator is untouched until both
    /// repairs and the independent whole-job material/geometry guard pass.
    fn directed_exchange_policy(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
        policy: ExchangePolicy,
    ) -> Result<Option<bool>> {
        let extended = policy != ExchangePolicy::Short;
        let bridge = policy == ExchangePolicy::AssignmentBridge;
        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            return Ok(None);
        }
        let baseline_layout = self.exchange_layout(strip, frozen, &sep.layout, shape)?;
        let baseline = self.exchange_report(&baseline_layout)?;
        if !baseline.valid {
            return Ok(None);
        }
        let before = baseline.metrics.as_ref().expect("valid baseline");
        let baseline_profile = std::cell::OnceCell::new();
        let baseline_source_area = std::cell::OnceCell::new();
        let single = strip.container(Shape {
            sheets: 1,
            last: self.model.full_width,
        })?;
        let last_container = strip.container(Shape {
            sheets: 1,
            last: shape.last,
        })?;
        let last_index = shape.sheets - 1;
        let last_offset = strip.start(last_index);
        let mut incoming_keys = strip.in_last(&sep.layout, shape);
        let mut original_order = incoming_keys.clone();
        original_order.sort_by(|&a, &b| {
            sep.layout.placed_items()[b]
                .item()
                .area()
                .total_cmp(&sep.layout.placed_items()[a].item().area())
        });
        rank_incoming(&sep.layout, &mut incoming_keys);
        let mut fill = vec![0.0_f32; last_index];
        for p in sep
            .layout
            .placed_items()
            .values()
            .filter(|p| !strip.is_blocker(p))
        {
            let i = strip.sheet_of(p.shape());
            if i < last_index {
                fill[i] += p.item().area();
            }
        }
        let mut targets: Vec<_> = (0..last_index).collect();
        targets.sort_by(|&a, &b| fill[a].total_cmp(&fill[b]));
        let now = self.clock.now();
        let group_until = now + (self.last_step(until) - now).max(0.0) * 0.5;
        let mut same_pairs = incoming_pairs(&sep.layout, &incoming_keys);
        let mut mixed_pairs = mixed_incoming_pairs(&sep.layout, &incoming_keys);
        include_boundary_pair(
            &sep.layout,
            &incoming_keys,
            &mut same_pairs,
            &mut mixed_pairs,
        );
        preserve_pair_frames(&mut same_pairs, &original_order);
        preserve_pair_frames(&mut mixed_pairs, &original_order);
        let mut choices =
            Vec::with_capacity(same_pairs.len() + mixed_pairs.len() + incoming_keys.len());
        for index in 0..same_pairs.len().max(mixed_pairs.len()) {
            if let Some(pair) = same_pairs.get(index) {
                choices.push(pair.clone());
            }
            if let Some(pair) = mixed_pairs.get(index) {
                choices.push(pair.clone());
            }
        }
        choices.extend(incoming_keys.into_iter().map(|key| vec![key]));
        for selected in choices {
            let paired = selected.len() == 2;
            let exchange_until = if paired { group_until } else { until };
            if self.clock.now() >= self.last_step(exchange_until) {
                continue;
            }
            let incoming_key = selected[0];
            let members: Vec<_> = selected
                .iter()
                .map(|&key| {
                    let p = &sep.layout.placed_items()[key];
                    (key, p.item().clone(), shift(p.d_transf(), -last_offset))
                })
                .collect();
            let mixed = paired && !std::sync::Arc::ptr_eq(&members[0].1, &members[1].1);
            let incoming = &sep.layout.placed_items()[incoming_key];
            let incoming_item = incoming.item().clone();
            let incoming_old = shift(incoming.d_transf(), -last_offset);
            for &target in targets.iter().take(3) {
                if self.clock.now() >= self.last_step(exchange_until) {
                    break;
                }
                let offset = strip.start(target);
                let mut receiver = JLayout::new(single.clone());
                let mut source = JLayout::new(last_container.clone());
                let mut changed_keys = Vec::new();
                for (key, p) in sep
                    .layout
                    .placed_items()
                    .iter()
                    .filter(|(_, p)| !strip.is_blocker(p))
                {
                    let i = strip.sheet_of(p.shape());
                    if i == target {
                        receiver.place_item(p.item(), shift(p.d_transf(), -offset));
                        changed_keys.push(key);
                    } else if i == last_index {
                        if !selected.contains(&key) {
                            source.place_item(p.item(), shift(p.d_transf(), -last_offset));
                        }
                        changed_keys.push(key);
                    }
                }
                self.clock
                    .charge(Work::RegisteredItem, changed_keys.len() as f64);
                let proposal_until = self.last_step(exchange_until);
                let candidates = if paired {
                    paired_proposals(
                        &receiver,
                        &members,
                        &mut self.rng,
                        &self.clock,
                        proposal_until,
                    )
                } else {
                    proposals(
                        &receiver,
                        &incoming_item,
                        &mut self.rng,
                        &self.clock,
                        proposal_until,
                    )
                };
                for proposal in candidates {
                    if self.clock.now() >= self.last_step(exchange_until) {
                        break;
                    }
                    self.stats.directed_exchange_attempts += 1;
                    self.stats.extended_exchange_attempts += u64::from(extended);
                    self.stats.paired_exchange_attempts += u64::from(paired);
                    self.stats.mixed_exchange_attempts += u64::from(mixed);
                    let victims: Vec<_> = proposal
                        .victims
                        .iter()
                        .map(|&key| {
                            let p = &receiver.placed_items()[key];
                            (key, p.item().clone(), p.d_transf())
                        })
                        .collect();
                    let mut next_receiver = JLayout::from_snapshot(&receiver.save());
                    for &(key, _, _) in &victims {
                        next_receiver.remove_item(key);
                    }
                    if paired {
                        let Some(poses) = incoming_group_poses(&members, proposal.incoming) else {
                            continue;
                        };
                        for ((_, item, _), pose) in members.iter().zip(poses) {
                            next_receiver.place_item(item, pose);
                        }
                    } else {
                        next_receiver.place_item(&incoming_item, proposal.incoming);
                    }
                    let mut next_source = JLayout::from_snapshot(&source.save());
                    let mut returned = if victims.len() == 1 {
                        vec![convert_sample_to_closest_feasible(
                            incoming_old,
                            &victims[0].1,
                        )]
                    } else {
                        return_group_poses(&victims, proposal.incoming, incoming_old)
                    };
                    contain_return_group(
                        &victims,
                        &mut returned,
                        &last_container.outer_cd().bbox(),
                        &self.clock,
                    );
                    for ((_, victim, _), pose) in victims.iter().zip(returned) {
                        let pose = free_return_pose(
                            &next_source,
                            victim,
                            pose,
                            &self.clock,
                            self.last_step(exchange_until),
                        );
                        next_source.place_item(victim, pose);
                    }
                    self.clock
                        .charge(Work::RegisteredItem, changed_keys.len() as f64);
                    let now = self.clock.now();
                    // Bound each pair so one hard proposal cannot consume all
                    // remaining opportunities. Each repair gets half the pair.
                    let pair_end = now + ((self.last_step(exchange_until) - now) * 0.5).min(0.4);
                    let middle = (now + pair_end) / 2.0;
                    let mut receiver_sep = Separator::new(
                        next_receiver,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    let (receiver_snapshot, receiver_tracker) =
                        receiver_sep.separate(&self.deadline(middle));
                    if receiver_tracker.total_loss() > 0.0 {
                        continue;
                    }
                    let mut source_sep = Separator::new(
                        next_source,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    let source_until =
                        source_repair_deadline(pair_end, self.last_step(exchange_until), extended);
                    let (source_snapshot, source_tracker) =
                        source_sep.separate(&self.deadline(source_until));
                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(exchange_until)
                    {
                        continue;
                    }
                    let mut trial = JLayout::from_snapshot(&sep.layout.save());
                    for &key in &changed_keys {
                        trial.remove_item(key);
                    }
                    for (snapshot, start) in
                        [(receiver_snapshot, offset), (source_snapshot, last_offset)]
                    {
                        for p in JLayout::from_snapshot(&snapshot).placed_items().values() {
                            trial.place_item(p.item(), shift(p.d_transf(), start));
                        }
                    }
                    self.clock.charge(
                        Work::RegisteredItem,
                        (sep.layout.placed_items().len() + changed_keys.len()) as f64,
                    );
                    if exact_physical_state(&sep.layout, &trial) {
                        self.stats.neutral_exchange_rejections += 1;
                        self.stats.exact_state_exchange_rejections += 1;
                        continue;
                    }
                    let trial_layout = self.exchange_layout(strip, frozen, &trial, shape)?;
                    if same_original_inventory(&members, &victims) {
                        let original_profile = baseline_profile.get_or_init(|| {
                            let profile = material_profile(self.model.job, &baseline_layout);
                            self.clock.validated(self.model.job, &baseline_layout);
                            profile
                        });
                        let trial_profile = material_profile(self.model.job, &trial_layout);
                        self.clock.validated(self.model.job, &trial_layout);
                        if original_profile
                            .as_ref()
                            .is_some_and(|profile| trial_profile.as_ref() == Some(profile))
                        {
                            self.stats.neutral_exchange_rejections += 1;
                            self.stats.material_profile_exchange_rejections += 1;
                            continue;
                        }
                    }
                    let report = self.exchange_report(&trial_layout)?;
                    if !report.valid {
                        self.stats.rejected_layouts += 1;
                        continue;
                    }
                    let after = report.metrics.as_ref().expect("valid exchange");
                    if exchange_increases_material(before, after)
                        || self.clock.now() >= exchange_until
                    {
                        continue;
                    }
                    // Strict mode rejects flat material. Bridge mode may
                    // retain a validated flat step provisionally only when the
                    // canonical filled area on the last sheet strictly falls.
                    if extended && after.material_area >= before.material_area {
                        let area_improved = if bridge {
                            let initial = *baseline_source_area
                                .get_or_init(|| assignment_source_area(strip, &sep.layout, shape));
                            assignment_source_area(strip, &trial, shape) < initial
                        } else {
                            false
                        };
                        if !area_improved {
                            self.stats.extended_flat_rejections += 1;
                            self.stats.assignment_bridge_area_rejections += u64::from(bridge);
                            continue;
                        }
                    }
                    // Canonical area scans are charged work; they cannot let
                    // a proposal cross the original acceptance deadline.
                    if bridge && self.clock.now() >= exchange_until {
                        continue;
                    }
                    // Same inventory can still improve the geometry, but a
                    // flat material result must not consume the sole exchange.
                    if same_original_inventory(&members, &victims)
                        && after.material_area >= before.material_area
                    {
                        self.stats.neutral_exchange_rejections += 1;
                        continue;
                    }
                    sep.layout = trial;
                    sep.rebuild();
                    self.stats.directed_exchanges += 1;
                    self.stats.extended_exchanges += u64::from(extended);
                    self.stats.paired_exchanges += u64::from(paired);
                    self.stats.mixed_exchanges += u64::from(mixed);
                    return Ok(Some(after.material_area < before.material_area));
                }
            }
        }
        Ok(None)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nestbolt_validator::job::{Margins, Part, Stock};
    use nestbolt_validator::{Polygon, Units};

    // BEGIN exact-state observation tests
    #[test]
    fn exact_state_ignores_order_and_keys_but_retains_multiplicity() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let before = sheets[1].layout();
        let mut after = JLayout::new(before.container().clone());
        let parts: Vec<_> = before.placed_items().values().collect();
        let dummy = after.place_item(parts[0].item(), parts[0].d_transf());
        after.remove_item(dummy);
        for p in parts.iter().rev() {
            after.place_item(p.item(), p.d_transf());
        }
        assert!(exact_physical_state(
            before,
            &JLayout::from_snapshot(&before.save())
        ));
        assert!(exact_physical_state(before, &after));
        assert_ne!(
            before.placed_items().keys().collect::<Vec<_>>(),
            after.placed_items().keys().collect::<Vec<_>>()
        );
        let key = after.place_item(parts[0].item(), parts[0].d_transf());
        assert!(!exact_physical_state(before, &after));
        after.remove_item(key);
        let key = after.placed_items().keys().next().unwrap();
        after.remove_item(key);
        assert!(!exact_physical_state(before, &after));
    }

    #[test]
    fn exact_state_rejects_one_ulp_rotation_reflection_and_changed_distribution() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let before = sheets[1].layout();
        let (key, p) = before
            .placed_items()
            .iter()
            .find(|(_, p)| p.item().area() == 1350.0)
            .unwrap();
        let pose = p.d_transf();
        let (x, y) = pose.translation();
        for changed in [
            DTransformation::new(pose.rotation(), (f32::from_bits(x.to_bits() + 1), y))
                .with_reflection(pose.reflected),
            DTransformation::new(pose.rotation(), (x, f32::from_bits(y.to_bits() + 1)))
                .with_reflection(pose.reflected),
            DTransformation::new(pose.rotation() + 0.01, (x, y)).with_reflection(pose.reflected),
            DTransformation::new(pose.rotation(), (x, y)).with_reflection(!pose.reflected),
        ] {
            let mut after = JLayout::from_snapshot(&before.save());
            after.remove_item(key);
            after.place_item(p.item(), changed);
            assert!(!exact_physical_state(before, &after));
        }
        let mut after = JLayout::from_snapshot(&before.save());
        let same: Vec<_> = before
            .placed_items()
            .iter()
            .filter(|(_, q)| std::sync::Arc::ptr_eq(p.item(), q.item()))
            .collect();
        assert_eq!(same.len(), 2);
        after.remove_item(same[1].0);
        after.place_item(p.item(), pose);
        assert_eq!(before.placed_items().len(), after.placed_items().len());
        assert!(!exact_physical_state(before, &after));
    }

    #[test]
    fn exact_state_rejects_different_original_item_model_and_container() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let other_model = Model::new(&job).unwrap();
        let other_sheets = other_model.sheets_of(&layout).unwrap();
        let before = sheets[1].layout();
        let (key, p) = before.placed_items().iter().next().unwrap();
        let other = other_sheets[1]
            .layout()
            .placed_items()
            .values()
            .find(|q| q.item().idx() == p.item().idx())
            .unwrap();
        let mut after = JLayout::from_snapshot(&before.save());
        after.remove_item(key);
        after.place_item(other.item(), p.d_transf());
        assert!(!exact_physical_state(before, &after));
        let different = sheets[0]
            .layout()
            .placed_items()
            .values()
            .find(|q| q.item().idx() != p.item().idx())
            .unwrap();
        let mut after = JLayout::from_snapshot(&before.save());
        after.remove_item(key);
        after.place_item(different.item(), p.d_transf());
        assert!(!exact_physical_state(before, &after));
        let mut after = JLayout::new(other_sheets[1].layout().container().clone());
        for q in before.placed_items().values() {
            after.place_item(q.item(), q.d_transf());
        }
        assert!(!exact_physical_state(before, &after));
    }
    // END exact-state observation tests

    fn rectangle(id: &str, width: f64, height: f64) -> Part {
        Part {
            id: id.into(),
            quantity: 1,
            geometry: vec![Polygon {
                outer: vec![[0.0, 0.0], [width, 0.0], [width, height], [0.0, height]],
                holes: vec![],
            }],
            rotations: Rotations::List { degrees: vec![0.0] },
            allow_mirror: false,
            priority: 1.0,
        }
    }

    fn fixture() -> (Job, Layout) {
        let job = Job {
            version: 1,
            name: "authored exchange".into(),
            units: Units::Mm,
            parts: vec![
                rectangle("filler", 60.0, 94.0),
                rectangle("return", 30.0, 20.0),
                rectangle("incoming", 30.0, 85.0),
            ],
            stocks: vec![Stock {
                id: "stock".into(),
                width: 100.0,
                height: 100.0,
                count: None,
                margins: Margins::default(),
                outline: vec![],
                defects: vec![],
            }],
            clearance: 0.2,
            edge_clearance: 1.0,
            mode: Mode::All,
        };
        let layout = Layout {
            version: 1,
            units: Units::Mm,
            sheets: (0..2)
                .map(|i| Sheet {
                    id: format!("sheet-{i}"),
                    stock_id: "stock".into(),
                })
                .collect(),
            placements: [
                ("filler", 0, [2.0, 2.0]),
                ("return", 0, [64.0, 2.0]),
                ("incoming", 1, [2.0, 2.0]),
            ]
            .into_iter()
            .map(|(id, sheet, translation)| Placement {
                part_id: id.into(),
                copy_index: 0,
                sheet_id: format!("sheet-{sheet}"),
                transform: RigidTransform {
                    translation,
                    rotation_radians: 0.0,
                    mirrored: false,
                },
            })
            .collect(),
        };
        (job, layout)
    }

    fn fingerprint(layout: &JLayout) -> String {
        format!(
            "{:?}",
            layout
                .placed_items()
                .iter()
                .map(|(k, p)| (k, p.item().idx(), p.d_transf()))
                .collect::<Vec<_>>()
        )
    }

    fn exercise(
        job: &Job,
        layout: &Layout,
        seed: u64,
        enabled: bool,
        expired: bool,
        frozen_count: usize,
    ) -> (usize, Layout, Stats) {
        let validation = validate(job, layout).unwrap();
        assert!(validation.valid, "{:?}", validation.violations);
        let model = Model::new(job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut search = Search {
            model: &model,
            allow_exchange: enabled,
            rng: Xoshiro256PlusPlus::seed_from_u64(seed),
            clock: clock.clone(),
            best: (layout.clone(), validation, 0.0),
            history: vec![],
            stats: Stats::default(),
            progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
            check_cost: 0.0,
            check_every: 5.0,
        };
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(layout).unwrap();
        let (frozen, window) = sheets.split_at(frozen_count);
        let mut shape = Shape {
            sheets: window.len(),
            last: model.full_width,
        };
        let initial = strip.layout(window, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut sep = Separator::new(
            strip.layout(window, shape).unwrap(),
            seed,
            EXPLORE,
            search.clock.clone(),
        );
        sep.pin(blocker_index(&model));
        assert_eq!(sep.tracker.total_loss(), 0.0);
        // Compare the same f32 internal frame before/after the exchange. The
        // public-to-internal conversion predates this operation and has its own
        // tests; comparing to the authored f64 coordinates conflates the two.
        let mut before_sheets = frozen.to_vec();
        before_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let before_layout = model.to_layout(&before_sheets);
        let before_report = validate(job, &before_layout).unwrap();
        assert!(before_report.valid);
        let before_material = before_report.metrics.as_ref().unwrap().material_area;
        let original = fingerprint(&sep.layout);
        let until = if expired {
            0.0
        } else {
            search.clock.now() + 3.0
        };
        let moved = search
            .directed_exchange(&strip, frozen, &mut sep, shape, until)
            .unwrap();
        if moved == 0 {
            assert_eq!(
                fingerprint(&sep.layout),
                original,
                "failed proposal mutated the original state"
            );
        }
        let mut after_sheets = frozen.to_vec();
        after_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let after = model.to_layout(&after_sheets);
        for i in 0..frozen_count {
            let id = format!("sheet-{i}");
            let before_fixed: Vec<_> = before_layout
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            let after_fixed: Vec<_> = after
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            assert_eq!(
                serde_json::to_value(before_fixed).unwrap(),
                serde_json::to_value(after_fixed).unwrap()
            );
        }
        let report = validate(job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert!(report.metrics.as_ref().unwrap().material_area <= before_material);
        assert_eq!(sep.tracker.total_loss(), 0.0);
        eprintln!(
            "authored exchange seed={seed} enabled={enabled} expired={expired} frozen={frozen_count} moved={moved} attempts={} material_before={before_material:.9} material_after={:.9}",
            search.stats.directed_exchange_attempts,
            report.metrics.as_ref().unwrap().material_area
        );
        (moved, after, search.stats)
    }

    #[test]
    fn window_search_reaches_exchange_before_gap_filling() {
        let (mut job, mut layout) = fixture();
        // This small last-sheet part fits an earlier gap. A successful fill
        // must not bypass the exchange opportunity for the large incoming part.
        job.parts.push(rectangle("gap-part", 5.0, 5.0));
        layout.placements.push(Placement {
            part_id: "gap-part".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [36.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        for (enabled, budget) in [(true, 20.0), (false, 20.0), (true, 0.0)] {
            let report = validate(&job, &layout).unwrap();
            assert!(report.valid);
            let before_material = report.metrics.as_ref().unwrap().material_area;
            let model = Model::new(&job).unwrap();
            let clock = Clock::new(Timing::Work, 30.0);
            let mut search = Search {
                model: &model,
                allow_exchange: enabled,
                rng: Xoshiro256PlusPlus::seed_from_u64(0),
                clock,
                best: (layout.clone(), report, 0.0),
                history: vec![],
                stats: Stats::default(),
                progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
                check_cost: 0.0,
                check_every: 5.0,
            };
            search
                .window_search(model.sheets_of(&layout).unwrap(), budget, 0.2, 2)
                .unwrap();
            let checked = validate(&job, &search.best.0).unwrap();
            assert!(checked.valid);
            assert!(checked.metrics.as_ref().unwrap().material_area <= before_material);
            if enabled && budget > 0.0 {
                assert!(search.stats.directed_exchange_attempts > 0);
                assert!(search.stats.directed_exchanges > 0);
            } else {
                assert_eq!(search.stats.directed_exchange_attempts, 0);
                assert_eq!(search.stats.directed_exchanges, 0);
            }
            eprintln!(
                "window exchange enabled={enabled} budget={budget} attempts={} accepted={} valid={}",
                search.stats.directed_exchange_attempts,
                search.stats.directed_exchanges,
                checked.valid
            );
        }
    }

    #[test]
    fn directed_exchange_returns_smaller_actual_obstruction() {
        let (job, layout) = fixture();
        for seed in 0..5 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            assert_eq!(moved, 1, "seed {seed}, {stats:?}");
            assert_eq!(stats.directed_exchanges, 1);
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
            );
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
            );
        }
    }

    #[test]
    fn directed_exchange_expired_or_disabled_leaves_layout_intact() {
        let (job, layout) = fixture();
        for (enabled, expired) in [(true, true), (false, false)] {
            let (moved, _, stats) = exercise(&job, &layout, 0, enabled, expired, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.directed_exchange_attempts, 0);
        }
    }

    #[test]
    fn directed_exchange_rejects_returns_that_cannot_fit() {
        let (mut job, layout) = fixture();
        job.parts[2] = rectangle("incoming", 20.0, 10.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchanges, 0);
    }

    #[test]
    fn directed_exchange_preserves_frozen_sheets_and_mirror_contract() {
        let (mut job, mut layout) = fixture();
        job.parts.push(rectangle("fixed", 20.0, 20.0));
        for p in &mut layout.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        let fixed = Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        };
        layout.placements.push(fixed.clone());
        job.parts[2].allow_mirror = true;
        let incoming = layout
            .placements
            .iter_mut()
            .find(|p| p.part_id == "incoming")
            .unwrap();
        incoming.transform.mirrored = true;
        incoming.transform.translation[0] += 30.0;
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 1);
        assert_eq!(moved, 1);
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "fixed" && p.sheet_id == "sheet-0")
        );
    }

    #[test]
    fn directed_exchange_failed_source_repair_leaves_layout_intact() {
        let (mut job, layout) = fixture();
        job.parts[1] = rectangle("return", 5.0, 90.0);
        job.parts[2] = rectangle("incoming", 30.0, 30.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert!(stats.directed_exchange_attempts > 0);
    }

    #[test]
    fn directed_exchange_respects_stock_defects() {
        let (mut job, layout) = fixture();
        job.edge_clearance = job.clearance;
        job.stocks[0].defects.push(Polygon {
            outer: vec![[96.0, 20.0], [98.0, 20.0], [98.0, 30.0], [96.0, 30.0]],
            holes: vec![],
        });
        let (moved, _, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
    }

    fn obstruction_set_fixture(count: usize, return_height: f64) -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.parts[1] = rectangle("return", 30.0, return_height);
        job.parts[1].quantity = count as u32;
        let template = layout
            .placements
            .iter()
            .find(|p| p.part_id == "return")
            .unwrap()
            .clone();
        for copy in 1..count {
            let mut part = template.clone();
            part.copy_index = copy as u32;
            part.transform.translation[1] += copy as f64 * (return_height + 2.0);
            layout.placements.push(part);
        }
        (job, layout)
    }

    #[test]
    fn obstruction_set_moves_two_blockers_atomically() {
        let (job, layout) = obstruction_set_fixture(2, 20.0);
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            2
        );
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
        );
    }

    #[test]
    fn obstruction_set_moves_three_blockers_atomically() {
        let (job, layout) = obstruction_set_fixture(3, 20.0);
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            3
        );
    }

    #[test]
    fn complete_sets_can_return_equal_or_greater_area_at_the_same_material() {
        // The independently validated witness retains a 33 mm charged height:
        // a 2550/2700 mm2 incoming part can trade for three 900 mm2 squares.
        // Their relative positions fit in the otherwise empty return sheet.
        for incoming_width in [85.0, 90.0] {
            let (mut job, mut layout) = obstruction_set_fixture(3, 30.0);
            for part in &mut job.parts {
                for polygon in &mut part.geometry {
                    for point in &mut polygon.outer {
                        point.swap(0, 1);
                    }
                }
            }
            job.parts[2] = rectangle("incoming", incoming_width, 30.0);
            for part in &mut layout.placements {
                part.transform.translation.swap(0, 1);
            }
            let original = validate(&job, &layout).unwrap();
            assert!(original.valid);
            assert_eq!(original.metrics.unwrap().material_area, 13300.0);
            let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
            assert_eq!(moved, 1);
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
            );
        }
    }
    fn return_frame_witness() -> (Job, Layout) {
        let job = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../examples/return-frame-job.json"
        )))
        .unwrap();
        let layout = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../examples/return-frame-before.json"
        )))
        .unwrap();
        (job, layout)
    }

    fn witness_victims(
        receiver: &JLayout,
    ) -> Vec<(PItemKey, std::sync::Arc<Item>, DTransformation)> {
        receiver
            .placed_items()
            .iter()
            .filter(|(_, p)| p.item().external_id() == 2)
            .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
            .collect()
    }

    #[test]
    fn return_frame_rotates_into_the_vacated_gap_without_extra_material() {
        let (job, before) = return_frame_witness();
        let original = validate(&job, &before).unwrap();
        assert!(original.valid);
        assert_eq!(original.metrics.unwrap().material_area, 19500.0);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        let incoming = sheets[1]
            .layout()
            .placed_items()
            .values()
            .find(|p| p.item().external_id() == 3)
            .unwrap();
        let incoming_old = incoming.d_transf();
        let placed = RigidTransform {
            translation: [2.0, 64.0],
            rotation_radians: 0.0,
            mirrored: false,
        };
        let incoming_new = model.internal(incoming.item().idx(), &placed);
        let victims = witness_victims(sheets[0].layout());
        assert_eq!(victims.len(), 3);
        let poses = return_group_poses(&victims, incoming_new, incoming_old);
        let mut after = before.clone();
        let p = after
            .placements
            .iter_mut()
            .find(|p| p.part_id == "incoming")
            .unwrap();
        p.sheet_id = "sheet-0".into();
        p.transform = placed;
        for ((p, (_, item, _)), pose) in after
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "return")
            .zip(&victims)
            .zip(&poses)
        {
            assert!(item.allowed_orientations().allows(pose));
            p.sheet_id = "sheet-1".into();
            p.transform = model.external(item.idx(), pose);
        }
        let report = validate(&job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert_eq!(report.metrics.unwrap().material_area, 19500.0);
        let (fx, fy) = incoming_new.translation();
        let (tx, ty) = incoming_old.translation();
        for (p, (_, item, previous)) in after
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "return")
            .zip(&victims)
        {
            let (x, y) = previous.translation();
            let translated = DTransformation::new(previous.rotation(), (x + tx - fx, y + ty - fy))
                .with_reflection(previous.reflected);
            p.transform = model.external(item.idx(), &translated);
        }
        assert!(!validate(&job, &after).unwrap().valid);
    }

    #[test]
    fn return_frame_alternative_respects_strict_material_guard() {
        let (mut job, before) = return_frame_witness();
        job.parts[1] = rectangle("source-filler", 20.0, 94.0);
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 0);
        // A different pair can improve this fixture. The former +0.0007 mm2
        // single proposal must still fail the actual guard tested below.
        assert_eq!(moved, 1);
        assert!(stats.directed_exchange_attempts > 0);
        assert_eq!(stats.directed_exchanges, 1);
        let original = validate(&job, &before).unwrap().metrics.unwrap();
        let result = validate(&job, &after).unwrap().metrics.unwrap();
        assert!(result.material_area < original.material_area);
    }

    #[test]
    fn directed_exchange_transfers_incoming_with_valid_return_poses() {
        let (mut job, mut before) = return_frame_witness();
        // Keep the incoming part first in the area-ranked source list. A narrow
        // tall neighbour still obstructs the old translation-only return pose.
        job.parts[1] = rectangle("source-filler", 20.0, 94.0);
        // A separate fixed top strip controls this sheet's occupied height.
        // The exact three-piece rotated frame has a separate direct test;
        // search may find another valid obstruction set with lower material.
        job.parts.push(rectangle("ceiling", 94.0, 1.0));
        before.placements.push(Placement {
            part_id: "ceiling".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 97.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(stats.directed_exchanges, 1);
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
        );
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
        );
        let original = validate(&job, &before).unwrap().metrics.unwrap();
        let result = validate(&job, &after).unwrap().metrics.unwrap();
        assert!(result.material_area < original.material_area);
    }

    #[test]
    fn return_frame_preserves_permitted_reflection_and_relative_positions() {
        let (mut job, before) = return_frame_witness();
        job.parts[2].allow_mirror = true;
        job.parts[3].allow_mirror = true;
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        let mut victims = witness_victims(sheets[0].layout());
        for (i, (_, _, previous)) in victims.iter_mut().enumerate() {
            *previous = DTransformation::new(0.0, (12.0 + 6.0 * i as f32, 23.0));
        }
        let here = DTransformation::new(0.0, (10.0, 20.0));
        let old =
            DTransformation::new(std::f32::consts::FRAC_PI_2, (40.0, 50.0)).with_reflection(true);
        let poses = return_group_poses(&victims, here, old);
        // (x,y) relative to the old incoming frame maps to (y,x), then (40,50).
        for (i, (pose, (_, item, _))) in poses.iter().zip(&victims).enumerate() {
            assert!(pose.reflected && item.allowed_orientations().allows(pose));
            let (x, y) = pose.translation();
            assert!((x - 43.0).abs() < 0.0001);
            assert!((y - (52.0 + 6.0 * i as f32)).abs() < 0.0001);
            let matrix = pose.compose();
            let matrix = matrix.matrix();
            assert!(matrix[0][0].into_inner().abs() < 0.0001);
            assert!((matrix[0][1].into_inner() - 1.0).abs() < 0.0001);
            assert!((matrix[1][0].into_inner() - 1.0).abs() < 0.0001);
            assert!(matrix[1][1].into_inner().abs() < 0.0001);
        }
    }

    #[test]
    fn return_frame_falls_back_for_the_whole_group_if_any_orientation_is_forbidden() {
        let (job, before) = return_frame_witness();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        for reflected in [false, true] {
            let mut victims = witness_victims(sheets[0].layout());
            if !reflected {
                // Only the first member forbids the quarter-turn. All members
                // must retain the old translation, rather than deform the set.
                victims[0].1 = sheets[0]
                    .layout()
                    .placed_items()
                    .values()
                    .find(|p| p.item().external_id() == 0)
                    .unwrap()
                    .item()
                    .clone();
            }
            let here = DTransformation::new(3.0 * std::f32::consts::FRAC_PI_2, (10.0, 20.0));
            let old = DTransformation::new(
                if reflected {
                    std::f32::consts::FRAC_PI_2
                } else {
                    0.0
                },
                (40.0, 50.0),
            )
            .with_reflection(reflected);
            let poses = return_group_poses(&victims, here, old);
            for (pose, (_, item, previous)) in poses.iter().zip(&victims) {
                assert!(item.allowed_orientations().allows(pose));
                assert_eq!(pose.rotation(), previous.rotation());
                assert_eq!(pose.reflected, previous.reflected);
                let (x, y) = previous.translation();
                assert_eq!(pose.translation(), (x + 40.0 - 10.0, y + 50.0 - 20.0));
            }
        }
    }
    fn balanced_fixture() -> (Job, Layout) {
        (
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/balanced-group-job.json"
            )))
            .unwrap(),
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/balanced-group-before.json"
            )))
            .unwrap(),
        )
    }

    #[test]
    fn balanced_pair_moves_two_incoming_and_three_returns() {
        let (job, layout) = balanced_fixture();
        assert_eq!(
            validate(&job, &layout)
                .unwrap()
                .metrics
                .unwrap()
                .material_area,
            19700.0
        );
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            assert_eq!(moved, 1, "{stats:?}");
            assert_eq!(stats.paired_exchanges, 1);
            assert!(stats.paired_exchange_attempts > 0);
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
                    .count(),
                2
            );
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
        }
    }

    #[test]
    fn balanced_pair_disabled_or_expired_preserves_incumbent() {
        let (job, layout) = balanced_fixture();
        for (enabled, expired) in [(false, false), (true, true)] {
            let (moved, _, stats) = exercise(&job, &layout, 0, enabled, expired, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.paired_exchange_attempts, 0);
            assert_eq!(stats.paired_exchanges, 0);
        }
    }

    #[test]
    fn balanced_pair_preserves_frozen_prefix() {
        let (mut job, mut layout) = balanced_fixture();
        job.parts.push(rectangle("fixed", 10.0, 10.0));
        for p in &mut layout.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        layout.placements.push(Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 1);
        assert_eq!(moved, 1);
        assert_eq!(stats.paired_exchanges, 1);
    }

    #[test]
    fn balanced_pair_rejects_illegal_group_orientation() {
        let (mut job, layout) = balanced_fixture();
        for mirrors in [false, true] {
            job.parts
                .iter_mut()
                .find(|p| p.id == "incoming")
                .unwrap()
                .allow_mirror = mirrors;
            let model = Model::new(&job).unwrap();
            let sheets = model.sheets_of(&layout).unwrap();
            let source = sheets[1].layout();
            let members: Vec<_> = source
                .placed_items()
                .iter()
                .filter(|(_, p)| p.item().area() == 1350.0)
                .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
                .collect();
            assert_eq!(members.len(), 2);
            let old = members[0].2;
            let reflected =
                DTransformation::new(old.rotation(), (30.0, 3.0)).with_reflection(!old.reflected);
            if !mirrors {
                assert!(incoming_group_poses(&members, reflected).is_none());
            } else {
                let permitted = model.internal(
                    members[0].1.idx(),
                    &RigidTransform {
                        translation: [32.0, 2.0],
                        rotation_radians: 0.0,
                        mirrored: true,
                    },
                );
                assert!(permitted.reflected);
                assert!(incoming_group_poses(&members, permitted).is_some());
            }
            assert!(
                incoming_group_poses(
                    &members,
                    DTransformation::new(old.rotation() + std::f32::consts::FRAC_PI_2, (0.0, 0.0))
                        .with_reflection(old.reflected)
                )
                .is_none()
            );
            let shifted = incoming_group_poses(
                &members,
                DTransformation::new(old.rotation(), (3.0, 4.0)).with_reflection(old.reflected),
            )
            .unwrap();
            let old_delta = (
                members[1].2.translation().0 - members[0].2.translation().0,
                members[1].2.translation().1 - members[0].2.translation().1,
            );
            let new_delta = (
                shifted[1].translation().0 - shifted[0].translation().0,
                shifted[1].translation().1 - shifted[0].translation().1,
            );
            let scale = members
                .iter()
                .map(|(_, _, pose)| pose.translation().0.abs().max(pose.translation().1.abs()))
                .fold(1.0_f32, f32::max);
            let tolerance = 4.0 * f32::EPSILON * scale;
            assert!((old_delta.0 - new_delta.0).abs() <= tolerance);
            assert!((old_delta.1 - new_delta.1).abs() <= tolerance);
        }
    }

    #[test]
    fn balanced_pair_selection_is_unique_bounded_and_identity_safe() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let item = source
            .placed_items()
            .values()
            .find(|p| p.item().area() == 1350.0)
            .unwrap()
            .item();
        let mut many = JLayout::new(source.container().clone());
        let keys: Vec<_> = (0..20)
            .map(|i| many.place_item(item, DTransformation::new(0.0, (i as f32 * 32.0, 0.0))))
            .collect();
        let pairs = incoming_pairs(&many, &keys);
        assert_eq!(pairs.len(), 6);
        assert_eq!(pairs, incoming_pairs(&many, &keys));
        for (i, pair) in pairs.iter().enumerate() {
            assert_eq!(pair.len(), 2);
            assert_ne!(pair[0], pair[1]);
            assert!(!pairs[..i].contains(pair));
        }
        let other_model = Model::new(&job).unwrap();
        let other_sheets = other_model.sheets_of(&layout).unwrap();
        let other = other_sheets[1]
            .layout()
            .placed_items()
            .values()
            .find(|p| p.item().area() == 1350.0)
            .unwrap()
            .item();
        let key = many.place_item(other, DTransformation::new(0.0, (0.0, 47.0)));
        assert!(incoming_pairs(&many, &[keys[0], key]).is_empty());
    }

    #[test]
    fn unavailable_pair_falls_back_to_a_valid_single_exchange() {
        // Only one source part: pair selection cannot supply a candidate.
        let (job, layout) = fixture();
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(stats.paired_exchange_attempts, 0);
        assert_eq!(stats.paired_exchanges, 0);
        assert_eq!(stats.directed_exchanges, 1);
    }

    #[test]
    fn balanced_pair_without_return_room_preserves_incumbent() {
        let (mut job, mut layout) = balanced_fixture();
        let incoming = job.parts.iter_mut().find(|p| p.id == "incoming").unwrap();
        *incoming = rectangle("incoming", 30.0, 44.9);
        incoming.quantity = 2;
        for p in layout
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "incoming")
        {
            p.transform.translation[1] = if p.copy_index == 0 { 1.01 } else { 46.12 };
        }
        job.parts.push(rectangle("source-extra", 30.0, 7.7));
        layout.placements.push(Placement {
            part_id: "source-extra".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [2.0, 91.23],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        // The source fits 2*44.9 + 7.7 plus spacing. Three returned squares
        // plus that extra part need 98.3 mm in a 98 mm side band.
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0, "{stats:?}");
        assert_eq!(stats.directed_exchanges, 0);
        assert_eq!(stats.paired_exchanges, 0);
    }
    #[test]
    fn accepted_exchange_still_fills_a_known_gap() {
        let (job, layout) = gap_fixture();
        for (enabled, budget) in [(true, 20.0), (false, 20.0), (true, 0.0)] {
            let report = validate(&job, &layout).unwrap();
            assert!(report.valid);
            let before_material = report.metrics.as_ref().unwrap().material_area;
            let model = Model::new(&job).unwrap();
            let clock = Clock::new(Timing::Work, 30.0);
            let mut search = Search {
                model: &model,
                allow_exchange: enabled,
                rng: Xoshiro256PlusPlus::seed_from_u64(0),
                clock,
                best: (layout.clone(), report, 0.0),
                history: vec![],
                stats: Stats::default(),
                progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
                check_cost: 0.0,
                check_every: 5.0,
            };
            search
                .window_search(model.sheets_of(&layout).unwrap(), budget, 0.2, 2)
                .unwrap();
            let checked = validate(&job, &search.best.0).unwrap();
            assert!(checked.valid);
            assert!(checked.metrics.as_ref().unwrap().material_area <= before_material);
            if enabled && budget > 0.0 {
                assert!(search.stats.directed_exchange_attempts > 0);
                assert!(search.stats.directed_exchanges > 0);
                assert!(
                    search.stats.direct_insertions > 0,
                    "accepted exchange must retain gap filling: {:?}",
                    search.stats
                );
                assert!(search.stats.post_exchange_fill_calls > 0);
                assert!(search.stats.post_exchange_fill_moves > 0);
                // Later compression may relocate the same part again. Its
                // immediate fill result is covered by the direct test below.
            } else {
                assert_eq!(search.stats.directed_exchange_attempts, 0);
                assert_eq!(search.stats.directed_exchanges, 0);
                assert_eq!(search.stats.post_exchange_fill_calls, 0);
                assert_eq!(search.stats.post_exchange_fill_moves, 0);
            }
            eprintln!(
                "window exchange enabled={enabled} budget={budget} attempts={} accepted={} valid={}",
                search.stats.directed_exchange_attempts,
                search.stats.directed_exchanges,
                checked.valid
            );
        }
    }
    fn equal_inventory_fixture(taller_source: bool) -> (Job, Layout) {
        let (mut job, mut layout) = balanced_fixture();
        job.parts.retain(|p| p.id != "return");
        job.parts
            .iter_mut()
            .find(|p| p.id == "incoming")
            .unwrap()
            .quantity = 4;
        layout.placements.retain(|p| p.part_id != "return");
        for p in &mut layout.placements {
            if taller_source && p.part_id == "incoming" && p.copy_index == 1 {
                p.transform.translation[1] = 52.0;
            }
        }
        for (copy_index, y) in [(2, 2.0), (3, 49.0)] {
            layout.placements.push(Placement {
                part_id: "incoming".into(),
                copy_index,
                sheet_id: "sheet-0".into(),
                transform: RigidTransform {
                    translation: [2.0, y],
                    rotation_radians: 0.0,
                    mirrored: false,
                },
            });
        }
        if taller_source {
            // The validator credits the largest offcut on either sheet. Keep
            // the receiver taller so exchanging the pairs saves real material.
            job.parts.push(rectangle("ceiling", 94.0, 0.5));
            layout.placements.push(Placement {
                part_id: "ceiling".into(),
                copy_index: 0,
                sheet_id: "sheet-0".into(),
                transform: RigidTransform {
                    translation: [2.0, 98.0],
                    rotation_radians: 0.0,
                    mirrored: false,
                },
            });
        }
        (job, layout)
    }

    #[test]
    fn productive_exchange_requires_gain_for_changed_equal_inventory() {
        let (job, layout) = equal_inventory_fixture(false);
        for seed in 0..4 {
            let (_, canonical, _) = exercise(&job, &layout, seed, false, false, 0);
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            eprintln!(
                "PRODUCTIVE_WITNESS {}",
                serde_json::json!({
                    "case":"unchanged_inventory", "seed":seed, "job":&job,
                    "before":&layout, "after":&after, "moved":moved, "stats":&stats,
                })
            );
            assert_free_return_outcome(&job, &canonical, &after, moved, &stats, true, false);
            assert!(stats.paired_exchange_attempts > 0);
        }
    }

    #[test]
    fn productive_exchange_keeps_same_inventory_when_material_decreases() {
        let (job, layout) = equal_inventory_fixture(true);
        let before = validate(&job, &layout)
            .unwrap()
            .metrics
            .unwrap()
            .material_area;
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            eprintln!(
                "PRODUCTIVE_WITNESS {}",
                serde_json::json!({
                    "case":"same_inventory_improves", "seed":seed, "job":&job,
                    "before":&layout, "after":&after, "moved":moved, "stats":&stats,
                })
            );
            assert_eq!(
                moved, 1,
                "a same-inventory exchange that saves material must remain eligible: {stats:?}"
            );
            assert_eq!(stats.paired_exchanges, 1);
            let report = validate(&job, &after).unwrap();
            assert!(report.valid);
            assert!(before - report.metrics.unwrap().material_area > 99.9);
        }
    }

    #[test]
    fn productive_exchange_pair_selection_reaches_different_part_types() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let mut items: Vec<_> = model
            .instance
            .items
            .iter()
            .map(|(item, _)| item.clone())
            .collect();
        items.sort_by(|a, b| b.area().total_cmp(&a.area()));
        assert_eq!(items.len(), 3);
        let mut many = JLayout::new(sheets[0].layout().container().clone());
        let mut keys = Vec::new();
        for (family, item) in items.iter().enumerate() {
            for copy in 0..20 {
                keys.push(many.place_item(
                    item,
                    DTransformation::new(0.0, (copy as f32 * 500.0, family as f32 * 10000.0)),
                ));
            }
        }
        let pairs = incoming_pairs(&many, &keys);
        assert_eq!(pairs.len(), 6);
        assert_eq!(pairs, incoming_pairs(&many, &keys));
        let mut families: Vec<_> = pairs
            .iter()
            .map(|p| many.placed_items()[p[0]].item().idx())
            .collect();
        families.sort_unstable();
        families.dedup();
        assert_eq!(
            families.len(),
            3,
            "bounded pair choices must reach all three available part types"
        );
        for (index, pair) in pairs.iter().enumerate() {
            assert!(!pairs[..index].contains(pair));
            assert_eq!(pair.len(), 2);
            assert_ne!(pair[0], pair[1]);
            assert!(std::sync::Arc::ptr_eq(
                many.placed_items()[pair[0]].item(),
                many.placed_items()[pair[1]].item()
            ));
        }
    }
    fn mixed_fixture() -> (Job, Layout) {
        (
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/mixed-group-job.json"
            )))
            .unwrap(),
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/mixed-group-before.json"
            )))
            .unwrap(),
        )
    }

    #[test]
    fn mixed_pair_moves_different_parts_and_three_returns() {
        let (job, before) = mixed_fixture();
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &before, seed, true, false, 0);
            eprintln!(
                "MIXED_WITNESS {}",
                serde_json::json!({"case":"mixed_positive","seed":seed,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats})
            );
            assert_eq!(
                moved, 1,
                "different original parts must be eligible for the authored two-to-three exchange: {stats:?}"
            );
            assert_eq!(stats.paired_exchanges, 1);
            for id in ["short-incoming", "tall-incoming"] {
                assert!(
                    after
                        .placements
                        .iter()
                        .any(|p| p.part_id == id && p.sheet_id == "sheet-0")
                );
            }
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
        }
    }

    #[test]
    fn mixed_pair_disabled_or_expired_preserves_incumbent() {
        let (job, before) = mixed_fixture();
        for seed in 0..4 {
            for (enabled, expired) in [(false, false), (true, true)] {
                let (moved, _, stats) = exercise(&job, &before, seed, enabled, expired, 0);
                assert_eq!(moved, 0);
                assert_eq!(stats.directed_exchange_attempts, 0);
                assert_eq!(stats.directed_exchanges, 0);
            }
        }
    }

    #[test]
    fn mixed_pair_checks_each_members_rotation_and_reflection() {
        let (mut job, layout) = mixed_fixture();
        for permit_second in [false, true] {
            for part in &mut job.parts {
                if part.id == "short-incoming" || part.id == "tall-incoming" {
                    let permits = part.id == "short-incoming" || permit_second;
                    part.rotations = Rotations::List {
                        degrees: if permits { vec![0.0, 90.0] } else { vec![0.0] },
                    };
                    part.allow_mirror = permits;
                }
            }
            let model = Model::new(&job).unwrap();
            let sheets = model.sheets_of(&layout).unwrap();
            let mut members: Vec<_> = sheets[1]
                .layout()
                .placed_items()
                .iter()
                .filter(|(_, p)| p.item().area() < 2000.0)
                .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
                .collect();
            members.sort_by(|a, b| a.1.area().total_cmp(&b.1.area()));
            assert_eq!(members.len(), 2);
            assert!(!std::sync::Arc::ptr_eq(&members[0].1, &members[1].1));
            let old = members[0].2;
            let quarter =
                DTransformation::new(old.rotation() + std::f32::consts::FRAC_PI_2, (0.0, 0.0))
                    .with_reflection(old.reflected);
            assert_eq!(
                incoming_group_poses(&members, quarter).is_some(),
                permit_second
            );
            let reflected = model.internal(
                members[0].1.idx(),
                &RigidTransform {
                    translation: [32.0, 2.0],
                    rotation_radians: 0.0,
                    mirrored: true,
                },
            );
            assert_eq!(
                incoming_group_poses(&members, reflected).is_some(),
                permit_second
            );
            let translated = incoming_group_poses(
                &members,
                DTransformation::new(old.rotation(), (4.0, 5.0)).with_reflection(old.reflected),
            )
            .unwrap();
            let old_delta = (
                members[1].2.translation().0 - old.translation().0,
                members[1].2.translation().1 - old.translation().1,
            );
            let new_delta = (
                translated[1].translation().0 - translated[0].translation().0,
                translated[1].translation().1 - translated[0].translation().1,
            );
            assert!(
                (old_delta.0 - new_delta.0).abs() < 0.0001
                    && (old_delta.1 - new_delta.1).abs() < 0.0001
            );
        }
    }

    #[test]
    fn mixed_pair_selection_is_bounded_unique_and_reaches_singletons() {
        let (job, layout) = mixed_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let mut keys: Vec<_> = source.placed_items().keys().collect();
        keys.sort_by(|a, b| {
            source.placed_items()[*b]
                .item()
                .area()
                .total_cmp(&source.placed_items()[*a].item().area())
        });
        let pairs = mixed_incoming_pairs(source, &keys);
        assert_eq!(pairs.len(), 3);
        assert_eq!(pairs, mixed_incoming_pairs(source, &keys));
        assert!(pairs.iter().any(|p| p.contains(&keys[0])));
        assert!(
            pairs
                .iter()
                .any(|p| p.contains(&keys[1]) && p.contains(&keys[2]))
        );
        for (i, pair) in pairs.iter().enumerate() {
            assert_ne!(pair[0], pair[1]);
            assert!(!pairs[..i].contains(pair));
            assert!(!std::sync::Arc::ptr_eq(
                source.placed_items()[pair[0]].item(),
                source.placed_items()[pair[1]].item()
            ));
        }
        let mut many = JLayout::new(source.container().clone());
        let mut many_keys = Vec::new();
        for (family, key) in keys.iter().enumerate() {
            for copy in 0..20 {
                many_keys.push(many.place_item(
                    source.placed_items()[*key].item(),
                    DTransformation::new(0.0, (copy as f32 * 500.0, family as f32 * 10000.0)),
                ));
            }
        }
        let pairs = mixed_incoming_pairs(&many, &many_keys);
        assert_eq!(pairs.len(), 6);
        assert_eq!(pairs, mixed_incoming_pairs(&many, &many_keys));
        for (i, pair) in pairs.iter().enumerate() {
            assert!(!pairs[..i].contains(pair));
        }
        assert!(mixed_incoming_pairs(&many, &many_keys[..20]).is_empty());
    }

    #[test]
    fn mixed_pair_preserves_a_frozen_sheet() {
        let (mut job, mut before) = mixed_fixture();
        for p in &mut before.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        before.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        job.parts.push(rectangle("fixed", 20.0, 20.0));
        before.placements.push(Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 1);
        eprintln!(
            "MIXED_WITNESS {}",
            serde_json::json!({"case":"mixed_frozen","seed":0,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats})
        );
        assert_eq!(moved, 1);
        assert_eq!(stats.mixed_exchanges, 1);
        for id in ["short-incoming", "tall-incoming"] {
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == id && p.sheet_id == "sheet-1")
            );
        }
    }

    #[test]
    fn mixed_pair_failed_return_room_preserves_incumbent() {
        let (mut job, mut before) = mixed_fixture();
        *job.parts
            .iter_mut()
            .find(|p| p.id == "short-incoming")
            .unwrap() = rectangle("short-incoming", 30.0, 39.9);
        *job.parts
            .iter_mut()
            .find(|p| p.id == "tall-incoming")
            .unwrap() = rectangle("tall-incoming", 30.0, 49.9);
        for p in &mut before.placements {
            if p.part_id == "short-incoming" {
                p.transform.translation[1] = 1.01;
            }
            if p.part_id == "tall-incoming" {
                p.transform.translation[1] = 41.12;
            }
        }
        job.parts.push(rectangle("source-extra", 30.0, 7.7));
        before.placements.push(Placement {
            part_id: "source-extra".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [2.0, 91.23],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 0);
        eprintln!(
            "MIXED_WITNESS {}",
            serde_json::json!({"case":"mixed_no_return_room","seed":0,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats})
        );
        assert_eq!(moved, 0);
        assert_eq!(stats.mixed_exchanges, 0);
        assert!(stats.directed_exchange_attempts > 0);
    }
    fn larger_return_fixture() -> (Job, Layout) {
        (
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/larger-return-job.json"
            )))
            .unwrap(),
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/larger-return-before.json"
            )))
            .unwrap(),
        )
    }

    #[test]
    fn larger_return_moves_both_incoming_with_strict_material_guard() {
        let (job, before) = larger_return_fixture();
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &before, seed, true, false, 0);
            eprintln!(
                "LARGER_RETURN_WITNESS {}",
                serde_json::json!({"case":"larger_positive","seed":seed,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats})
            );
            assert_eq!(
                moved, 1,
                "larger return area must not exclude a valid material-nonincreasing pair exchange: {stats:?}"
            );
            assert_eq!(stats.mixed_exchanges, 1);
            assert_eq!(stats.paired_exchanges, 1);
            for id in ["short-incoming", "tall-incoming"] {
                assert!(
                    after
                        .placements
                        .iter()
                        .any(|p| p.part_id == id && p.sheet_id == "sheet-0")
                );
            }
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
        }
    }

    #[test]
    fn larger_return_disabled_or_expired_preserves_incumbent() {
        let (job, before) = larger_return_fixture();
        for seed in 0..4 {
            for (enabled, expired) in [(false, false), (true, true)] {
                let (moved, _, stats) = exercise(&job, &before, seed, enabled, expired, 0);
                assert_eq!(moved, 0);
                assert_eq!(stats.directed_exchange_attempts, 0);
                assert_eq!(stats.directed_exchanges, 0);
            }
        }
    }

    #[test]
    fn larger_return_failed_room_preserves_incumbent() {
        let (mut job, mut before) = larger_return_fixture();
        *job.parts
            .iter_mut()
            .find(|p| p.id == "short-incoming")
            .unwrap() = rectangle("short-incoming", 30.0, 39.9);
        *job.parts
            .iter_mut()
            .find(|p| p.id == "tall-incoming")
            .unwrap() = rectangle("tall-incoming", 30.0, 49.9);
        for p in &mut before.placements {
            if p.part_id == "short-incoming" {
                p.transform.translation[1] = 1.01;
            }
            if p.part_id == "tall-incoming" {
                p.transform.translation[1] = 41.12;
            }
        }
        job.parts.push(rectangle("source-extra", 30.0, 7.7));
        before.placements.push(Placement {
            part_id: "source-extra".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [2.0, 91.23],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 0);
        eprintln!(
            "LARGER_RETURN_WITNESS {}",
            serde_json::json!({"case":"larger_no_return_room","seed":0,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats})
        );
        assert_eq!(moved, 0);
        assert_eq!(stats.mixed_exchanges, 0);
        assert!(stats.directed_exchange_attempts > 0);
    }
    #[test]
    fn larger_return_preserves_a_frozen_sheet() {
        let (mut job, mut before) = larger_return_fixture();
        for p in &mut before.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        before.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        job.parts.push(rectangle("fixed", 20.0, 20.0));
        before.placements.push(Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 1);
        eprintln!(
            "LARGER_RETURN_WITNESS {}",
            serde_json::json!({"case":"larger_frozen","seed":0,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats})
        );
        assert_eq!(moved, 1);
        assert_eq!(stats.mixed_exchanges, 1);
        for id in ["short-incoming", "tall-incoming"] {
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == id && p.sheet_id == "sheet-1")
            );
        }
    }
    fn gap_fixture() -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        // This small last-sheet part fits an earlier gap. A successful fill
        // must not bypass the exchange opportunity for the large incoming part.
        job.parts.push(rectangle("gap-part", 5.0, 5.0));
        layout.placements.push(Placement {
            part_id: "gap-part".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [36.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        (job, layout)
    }

    #[test]
    fn exchange_material_guard_rejects_even_one_ulp_and_extra_sheets() {
        let (job, layout) = fixture();
        let before = validate(&job, &layout).unwrap().metrics.unwrap();
        let mut after = before.clone();
        assert!(!exchange_increases_material(&before, &after));
        for material in [
            before.material_area + 0.0007,
            f64::from_bits(before.material_area.to_bits() + 1),
        ] {
            after.material_area = material;
            assert!(exchange_increases_material(&before, &after));
            after.sheets_used = before.sheets_used - 1;
            assert!(exchange_increases_material(&before, &after));
            after.sheets_used = before.sheets_used;
        }
        after.material_area = before.material_area - 1.0;
        assert!(!exchange_increases_material(&before, &after));
        after.sheets_used += 1;
        assert!(exchange_increases_material(&before, &after));
    }

    #[test]
    fn gap_fill_moves_known_part_immediately_after_exchange() {
        let (job, layout) = gap_fixture();
        let (exchanged, after_exchange, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(exchanged, 1);
        assert!(
            after_exchange
                .placements
                .iter()
                .any(|p| p.part_id == "gap-part" && p.sheet_id == "sheet-1")
        );
        let report = validate(&job, &after_exchange).unwrap();
        assert!(report.valid);
        let model = Model::new(&job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut search = Search {
            model: &model,
            allow_exchange: true,
            rng: Xoshiro256PlusPlus::seed_from_u64(0),
            clock: clock.clone(),
            best: (after_exchange.clone(), report, 0.0),
            history: vec![],
            stats: Stats::default(),
            progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
            check_cost: 0.0,
            check_every: 5.0,
        };
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(&after_exchange).unwrap();
        let mut shape = Shape {
            sheets: sheets.len(),
            last: model.full_width,
        };
        let initial = strip.layout(&sheets, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut sep = Separator::new(
            strip.layout(&sheets, shape).unwrap(),
            0,
            EXPLORE,
            search.clock.clone(),
        );
        sep.pin(blocker_index(&model));
        let before = model.to_layout(&strip.split(&sep.layout, shape.sheets).unwrap());
        let before_report = validate(&job, &before).unwrap();
        assert!(before_report.valid);
        assert_eq!(search.fill_gaps(&strip, &mut sep, shape), 1);
        assert_eq!(search.stats.direct_insertions, 1);
        let after = model.to_layout(&strip.split(&sep.layout, shape.sheets).unwrap());
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "gap-part" && p.sheet_id == "sheet-0")
        );
        let checked = validate(&job, &after).unwrap();
        assert!(checked.valid);
        assert!(
            checked.metrics.unwrap().material_area <= before_report.metrics.unwrap().material_area
        );
        assert_eq!(sep.tracker.total_loss(), 0.0);
        eprintln!(
            "DIRECT_FILL_WITNESS {}",
            serde_json::json!({"job":job,"before":before,"after":after})
        );
    }
    #[test]
    fn exact_duplicate_guard_allows_only_gain_and_preserves_disabled_boundaries() {
        let (job, layout) = equal_inventory_fixture(false);
        for seed in 0..4 {
            let (_, canonical, _) = exercise(&job, &layout, seed, false, false, 0);
            for (enabled, expired) in [(true, false), (false, false), (true, true)] {
                let (moved, after, stats) = exercise(&job, &layout, seed, enabled, expired, 0);
                eprintln!(
                    "EXACT_REJECT_WITNESS {}",
                    serde_json::json!({
                        "job":&job,"before":&layout,"after":&after,"seed":seed,
                        "enabled":enabled,"expired":expired,"moved":moved,"stats":&stats
                    })
                );
                assert_free_return_outcome(
                    &job, &canonical, &after, moved, &stats, enabled, expired,
                );
                if enabled && !expired {
                    assert!(
                        stats.exact_state_exchange_rejections <= stats.neutral_exchange_rejections
                    );
                } else {
                    assert_eq!(stats.exact_state_exchange_rejections, 0);
                    assert_eq!(stats.directed_exchange_attempts, 0);
                }
            }
        }
    }
    #[test]
    fn material_profile_guard_allows_only_gain_and_preserves_disabled_boundaries() {
        let (job, layout) = equal_inventory_fixture(false);
        for seed in 0..4 {
            let (_, canonical, _) = exercise(&job, &layout, seed, false, false, 0);
            for (enabled, expired) in [(true, false), (false, false), (true, true)] {
                let (moved, after, stats) = exercise(&job, &layout, seed, enabled, expired, 0);
                eprintln!(
                    "PROFILE_REJECT_WITNESS {}",
                    serde_json::json!({
                    "job":&job,"before":&layout,"after":&after,"seed":seed,
                    "enabled":enabled,"expired":expired,"moved":moved,"stats":&stats})
                );
                assert_free_return_outcome(
                    &job, &canonical, &after, moved, &stats, enabled, expired,
                );
                if enabled && !expired {
                    assert!(
                        stats.material_profile_exchange_rejections > 0,
                        "Changed poses with proven unchanged charged material must reject early: {stats:?}"
                    );
                    assert!(
                        stats.material_profile_exchange_rejections
                            + stats.exact_state_exchange_rejections
                            <= stats.neutral_exchange_rejections
                    );
                } else {
                    assert_eq!(stats.material_profile_exchange_rejections, 0);
                    assert_eq!(stats.directed_exchange_attempts, 0);
                }
            }
        }
    }
    // BEGIN boundary-priority tests
    fn boundary_priority_fixture() -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.name = "Boundary priority witness".into();
        job.parts = vec![
            rectangle("anchor", 94.0, 94.0),
            rectangle("large", 40.0, 20.0),
            rectangle("wide", 20.0, 5.0),
            rectangle("small", 5.0, 5.0),
        ];
        job.parts[1].quantity = 2;
        job.parts[3].quantity = 2;
        layout.placements = [
            ("anchor", 0, 0, [2.0, 2.0]),
            ("large", 0, 1, [2.0, 10.0]),
            ("large", 1, 1, [47.0, 10.0]),
            ("wide", 0, 1, [2.0, 80.0]),
            ("small", 0, 1, [40.0, 80.0]),
            ("small", 1, 1, [50.0, 80.0]),
        ]
        .into_iter()
        .map(|(id, copy_index, sheet, translation)| Placement {
            part_id: id.into(),
            copy_index,
            sheet_id: format!("sheet-{sheet}"),
            transform: RigidTransform {
                translation,
                ..Default::default()
            },
        })
        .collect();
        assert!(validate(&job, &layout).unwrap().valid);
        (job, layout)
    }

    #[test]
    fn boundary_priority_prefers_high_small_parts_over_low_large_parts() {
        let (job, layout) = boundary_priority_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let mut keys: Vec<_> = source.placed_items().keys().collect();
        let before = keys.clone();
        rank_incoming(source, &mut keys);
        let names: Vec<_> = keys
            .iter()
            .map(|k| {
                job.parts[model.part[source.placed_items()[*k].item().idx()]]
                    .id
                    .as_str()
            })
            .collect();
        eprintln!(
            "BOUNDARY_ORDER_WITNESS {}",
            serde_json::json!({"job":job,"layout":layout,"names":names})
        );
        assert_eq!(
            names,
            vec!["wide", "small", "small", "large", "large"],
            "Boundary parts must precede larger interior parts"
        );
        let mut a = before;
        let mut b = keys;
        a.sort();
        b.sort();
        assert_eq!(a, b);
    }

    #[test]
    fn boundary_priority_preserves_equal_extent_area_ties() {
        let (job, layout) = boundary_priority_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let mut keys: Vec<_> = source
            .placed_items()
            .iter()
            .filter(|(_, p)| job.parts[model.part[p.item().idx()]].id == "small")
            .map(|(k, _)| k)
            .collect();
        assert_eq!(keys.len(), 2);
        keys.reverse();
        let before = keys.clone();
        let a = &source.placed_items()[keys[0]];
        let b = &source.placed_items()[keys[1]];
        assert_eq!(a.shape().bbox().x_max, b.shape().bbox().x_max);
        assert_eq!(a.item().area(), b.item().area());
        rank_incoming(source, &mut keys);
        assert_eq!(
            keys, before,
            "Equal boundary/area ties must retain their input order"
        );
    }

    #[test]
    fn boundary_priority_pair_choices_start_with_the_high_family() {
        let (job, layout) = boundary_priority_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let mut keys: Vec<_> = source.placed_items().keys().collect();
        rank_incoming(source, &mut keys);
        let pairs = incoming_pairs(source, &keys);
        assert!(!pairs.is_empty() && pairs.len() <= 6);
        let first: Vec<_> = pairs[0]
            .iter()
            .map(|k| {
                job.parts[model.part[source.placed_items()[*k].item().idx()]]
                    .id
                    .as_str()
            })
            .collect();
        assert_eq!(
            first,
            vec!["small", "small"],
            "Boundary family must enter the bounded pair choices first"
        );
        let mixed = mixed_incoming_pairs(source, &keys);
        assert!(!mixed.is_empty() && mixed.len() <= 6);
        assert!(
            mixed[0].iter().any(
                |k| job.parts[model.part[source.placed_items()[*k].item().idx()]].id == "wide"
            )
        );
    }
    // END boundary-priority tests
    // BEGIN boundary-pair tests
    fn boundary_pair_fixture(mixed: bool) -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.name = "Boundary pair with closer lower neighbours".into();
        job.parts = vec![rectangle("anchor", 94.0, 94.0), rectangle("a", 5.0, 5.0)];
        job.parts[1].quantity = if mixed { 3 } else { 6 };
        let members = if mixed {
            let mut b = rectangle("b", 5.0, 5.0);
            b.quantity = 3;
            job.parts.push(b);
            [
                ("a", 0, [10.0, 80.0]),
                ("b", 0, [70.0, 80.0]),
                ("b", 1, [10.0, 74.0]),
                ("b", 2, [10.0, 68.0]),
                ("a", 1, [70.0, 74.0]),
                ("a", 2, [70.0, 68.0]),
            ]
        } else {
            [
                ("a", 0, [10.0, 80.0]),
                ("a", 1, [70.0, 80.0]),
                ("a", 2, [10.0, 74.0]),
                ("a", 3, [10.0, 68.0]),
                ("a", 4, [70.0, 74.0]),
                ("a", 5, [70.0, 68.0]),
            ]
        };
        layout.placements = vec![Placement {
            part_id: "anchor".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                ..Default::default()
            },
        }];
        layout
            .placements
            .extend(
                members
                    .into_iter()
                    .map(|(id, copy_index, translation)| Placement {
                        part_id: id.into(),
                        copy_index,
                        sheet_id: "sheet-1".into(),
                        transform: RigidTransform {
                            translation,
                            ..Default::default()
                        },
                    }),
            );
        assert!(validate(&job, &layout).unwrap().valid);
        (job, layout)
    }

    fn boundary_pair_contains(pair: &[PItemKey], a: PItemKey, b: PItemKey) -> bool {
        pair.len() == 2 && pair.contains(&a) && pair.contains(&b)
    }

    fn boundary_pair_witness(mixed: bool) {
        let (job, layout) = boundary_pair_fixture(mixed);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let mut keys: Vec<_> = source.placed_items().keys().collect();
        rank_incoming(source, &mut keys);
        assert_eq!(
            source.placed_items()[keys[0]].shape().bbox().x_max,
            source.placed_items()[keys[1]].shape().bbox().x_max
        );
        let mut same = incoming_pairs(source, &keys);
        let mut other = mixed_incoming_pairs(source, &keys);
        let before_same = same.clone();
        let before_mixed = other.clone();
        assert!(
            !same
                .iter()
                .chain(&other)
                .any(|p| boundary_pair_contains(p, keys[0], keys[1])),
            "Fixture must expose the existing missing upper pair"
        );
        include_boundary_pair(source, &keys, &mut same, &mut other);
        assert!(same.len() <= 6 && other.len() <= 6);
        let selected = if mixed {
            assert_eq!(same, before_same);
            &other
        } else {
            assert_eq!(other, before_mixed);
            &same
        };
        assert_eq!(
            selected[0],
            vec![keys[0], keys[1]],
            "Both highest members must enter the appropriate pair list first"
        );
        assert_eq!(
            selected
                .iter()
                .filter(|p| boundary_pair_contains(p, keys[0], keys[1]))
                .count(),
            1
        );
        let poses:Vec<_>=selected[0].iter().map(|key| {
            let p=&source.placed_items()[*key];let item=p.item().idx();
            serde_json::json!({"part_id":job.parts[model.part[item]].id,"transform":model.external(item,&p.d_transf())})
        }).collect();
        eprintln!(
            "BOUNDARY_PAIR_WITNESS {}",
            serde_json::json!({"job":job,"layout":model.to_layout(&sheets),"mixed":mixed,"selected":poses})
        );
    }

    #[test]
    fn boundary_pair_same_item_reaches_both_highest_despite_nearby_lower_parts() {
        boundary_pair_witness(false);
    }

    #[test]
    fn boundary_pair_mixed_items_reach_both_highest_despite_nearby_lower_parts() {
        boundary_pair_witness(true);
    }

    #[test]
    fn boundary_pair_deduplicates_and_retains_caps_alternatives_and_anchor() {
        let (job, layout) = boundary_pair_fixture(false);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let mut keys: Vec<_> = source.placed_items().keys().collect();
        rank_incoming(source, &mut keys);
        let mut same = incoming_pairs(source, &keys);
        let mut mixed = Vec::new();
        assert_eq!(same.len(), 6);
        same[2] = vec![keys[1], keys[0]];
        let alternatives: Vec<_> = same
            .iter()
            .filter(|p| !boundary_pair_contains(p, keys[0], keys[1]))
            .cloned()
            .collect();
        include_boundary_pair(source, &keys, &mut same, &mut mixed);
        assert_eq!(
            same[0],
            vec![keys[0], keys[1]],
            "Existing reversed upper pair must be promoted without duplication"
        );
        assert_eq!(same.len(), 6);
        assert_eq!(&same[1..], alternatives.as_slice());
        assert!(mixed.is_empty());
        let mut original = keys.clone();
        original.reverse();
        preserve_pair_frames(&mut same, &original);
        assert_eq!(
            same[0],
            vec![keys[1], keys[0]],
            "Original pair anchor order must survive selection priority"
        );
        let mut seen = Vec::new();
        for pair in same {
            let mut key = pair.clone();
            key.sort();
            assert!(!seen.contains(&key));
            seen.push(key);
        }
    }

    #[test]
    fn boundary_pair_empty_or_single_source_keeps_empty_choices() {
        let (job, layout) = boundary_pair_fixture(false);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let key = source.placed_items().keys().next().unwrap();
        for keys in [vec![], vec![key]] {
            let mut same = Vec::new();
            let mut mixed = Vec::new();
            include_boundary_pair(source, &keys, &mut same, &mut mixed);
            assert!(same.is_empty() && mixed.is_empty());
        }
    }
    // END boundary-pair tests
    // BEGIN contained-return tests
    fn return_seed_members(source: &JLayout) -> Vec<IncomingMember> {
        source
            .placed_items()
            .iter()
            .take(2)
            .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
            .collect()
    }

    fn return_seed_bounds(members: &[IncomingMember], poses: &[DTransformation]) -> Rect {
        assert_eq!(members.len(), poses.len());
        assert!(!members.is_empty());
        let mut x0 = f32::INFINITY;
        let mut y0 = f32::INFINITY;
        let mut x1 = f32::NEG_INFINITY;
        let mut y1 = f32::NEG_INFINITY;
        for ((_, item, _), pose) in members.iter().zip(poses) {
            let mut shape = item.shape_cd().as_ref().clone();
            shape.transform_from(item.shape_cd(), &pose.compose());
            let b = shape.bbox();
            x0 = x0.min(b.x_min);
            y0 = y0.min(b.y_min);
            x1 = x1.max(b.x_max);
            y1 = y1.max(b.y_max);
        }
        Rect::try_new(x0, y0, x1, y1).unwrap()
    }

    fn return_seed_pose_bits(poses: &[DTransformation]) -> Vec<([u32; 3], bool)> {
        poses
            .iter()
            .map(|p| {
                let (x, y) = p.translation();
                (
                    [p.rotation().to_bits(), x.to_bits(), y.to_bits()],
                    p.reflected,
                )
            })
            .collect()
    }

    #[test]
    fn contained_return_moves_fitting_group_inside_and_charges_all_transforms() {
        let (job, layout) = boundary_pair_fixture(false);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let members = return_seed_members(sheets[1].layout());
        let mut poses = vec![
            DTransformation::new(0.0, (20.0, 120.0)),
            DTransformation::new(0.0, (50.0, 120.0)),
        ];
        let before = poses.clone();
        let bounds = Rect::try_new(0.0, 0.0, 100.0, 100.0).unwrap();
        assert!(return_seed_bounds(&members, &poses).y_max > bounds.y_max);
        let clock = Clock::new(Timing::Work, 120.0);
        assert!(
            contain_return_group(&members, &mut poses, &bounds, &clock),
            "Fitting returned group must be moved inside"
        );
        let b = return_seed_bounds(&members, &poses);
        assert!(
            b.x_min >= bounds.x_min
                && b.y_min >= bounds.y_min
                && b.x_max <= bounds.x_max
                && b.y_max <= bounds.y_max
        );
        for (old, new) in before.iter().zip(&poses) {
            assert_eq!(old.rotation().to_bits(), new.rotation().to_bits());
            assert_eq!(old.reflected, new.reflected);
            assert_eq!(old.translation().0.to_bits(), new.translation().0.to_bits());
        }
        assert_eq!(poses[1].translation().0 - poses[0].translation().0, 30.0);
        assert_eq!(poses[1].translation().1, poses[0].translation().1);
        assert_eq!(
            clock.counts().evaluations,
            4.0,
            "Both original and proposed member bounds must be charged"
        );
        assert!(clock.counts().evaluated_vertices > 0.0 && clock.work() > 0.0);
        eprintln!(
            "CONTAINED_RETURN_WITNESS {}",
            serde_json::json!({"job":job,
            "source_layout":model.to_layout(&sheets),"bounds":[bounds.x_min,bounds.y_min,bounds.x_max,bounds.y_max],
            "before":members.iter().zip(&before).map(|((_,item,_),p)|serde_json::json!({"part_id":job.parts[model.part[item.idx()]].id,"transform":model.external(item.idx(),p)})).collect::<Vec<_>>(),
            "after":members.iter().zip(&poses).map(|((_,item,_),p)|serde_json::json!({"part_id":job.parts[model.part[item.idx()]].id,"transform":model.external(item.idx(),p)})).collect::<Vec<_>>(),
            "work":clock.counts()})
        );
    }

    #[test]
    fn contained_return_empty_contained_and_oversized_groups_are_bitwise_unchanged() {
        let (job, layout) = boundary_pair_fixture(false);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let members = return_seed_members(sheets[1].layout());
        let original = vec![
            DTransformation::new(0.0, (20.0, 30.0)),
            DTransformation::new(0.0, (50.0, 30.0)),
        ];
        for bounds in [
            Rect::try_new(0.0, 0.0, 100.0, 100.0).unwrap(),
            Rect::try_new(0.0, 0.0, 1.0, 1.0).unwrap(),
        ] {
            let mut poses = original.clone();
            let clock = Clock::new(Timing::Work, 120.0);
            assert!(!contain_return_group(&members, &mut poses, &bounds, &clock));
            assert_eq!(
                return_seed_pose_bits(&poses),
                return_seed_pose_bits(&original)
            );
        }
        let mut empty = vec![];
        let bounds = Rect::try_new(0.0, 0.0, 100.0, 100.0).unwrap();
        let clock = Clock::new(Timing::Work, 120.0);
        assert!(!contain_return_group(&[], &mut empty, &bounds, &clock));
        assert!(empty.is_empty());
        assert_eq!(clock.work(), 0.0);
    }

    #[test]
    fn contained_return_preserves_mixed_member_orientations_and_reflection() {
        let (mut job, layout) = boundary_pair_fixture(true);
        for part in &mut job.parts {
            part.allow_mirror = true;
            part.rotations = Rotations::List {
                degrees: vec![0.0, 90.0, 180.0, 270.0],
            };
        }
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let members = return_seed_members(sheets[1].layout());
        assert!(!std::sync::Arc::ptr_eq(&members[0].1, &members[1].1));
        let mut poses = vec![
            DTransformation::new(0.0, (-30.0, 20.0)).with_reflection(true),
            DTransformation::new(std::f32::consts::FRAC_PI_2, (-30.0, 50.0)),
        ];
        assert!(
            members
                .iter()
                .zip(&poses)
                .all(|((_, item, _), p)| item.allowed_orientations().allows(p))
        );
        let before = poses.clone();
        let bounds = Rect::try_new(0.0, 0.0, 100.0, 100.0).unwrap();
        let clock = Clock::new(Timing::Work, 120.0);
        assert!(
            contain_return_group(&members, &mut poses, &bounds, &clock),
            "Permitted mixed group must keep its orientations while translating"
        );
        let b = return_seed_bounds(&members, &poses);
        assert!(b.x_min >= 0.0 && b.y_min >= 0.0 && b.x_max <= 100.0 && b.y_max <= 100.0);
        for ((old, new), (_, item, _)) in before.iter().zip(&poses).zip(&members) {
            assert_eq!(old.rotation().to_bits(), new.rotation().to_bits());
            assert_eq!(old.reflected, new.reflected);
            assert_eq!(old.translation().1.to_bits(), new.translation().1.to_bits());
            assert!(item.allowed_orientations().allows(new));
        }
        assert_eq!(poses[0].translation().0, poses[1].translation().0);
        assert_eq!(poses[1].translation().1 - poses[0].translation().1, 30.0);
    }
    // END contained-return tests
    // BEGIN free-return tests
    // These equal-inventory fixtures can improve after lower free-space seeds.
    // Compare against the exact internal incumbent, not authored f64 positions.
    fn assert_free_return_outcome(
        job: &Job,
        before: &Layout,
        after: &Layout,
        moved: usize,
        stats: &Stats,
        enabled: bool,
        expired: bool,
    ) {
        let canonical = before;
        let baseline = validate(job, canonical).unwrap();
        let result = validate(job, after).unwrap();
        assert!(baseline.valid && result.valid);
        assert!(moved <= 1);
        assert_eq!(moved as u64, stats.directed_exchanges);
        if moved == 0 {
            assert_eq!(
                serde_json::to_value(after).unwrap(),
                serde_json::to_value(canonical).unwrap()
            );
        } else {
            assert!(enabled && !expired);
            let a = baseline.metrics.unwrap();
            let b = result.metrics.unwrap();
            assert!(
                b.sheets_used <= a.sheets_used && b.material_area < a.material_area,
                "Every accepted replacement needs strict material improvement"
            );
        }
        if !enabled || expired {
            assert_eq!(moved, 0);
            assert_eq!(stats.directed_exchange_attempts, 0);
        }
    }

    fn free_return_public(model: &Model, before: &Layout, source: &JLayout, sheet: &str) -> Layout {
        let mut after = before.clone();
        after.placements.retain(|p| p.sheet_id != sheet);
        let mut copies = std::collections::BTreeMap::<String, u32>::new();
        for p in &after.placements {
            *copies.entry(p.part_id.clone()).or_default() += 1;
        }
        for p in source.placed_items().values() {
            let id = model.job.parts[model.part[p.item().idx()]].id.clone();
            let copy = copies.entry(id.clone()).or_default();
            after.placements.push(Placement {
                part_id: id,
                copy_index: *copy,
                sheet_id: sheet.into(),
                transform: model.external(p.item().idx(), &p.d_transf()),
            });
            *copy += 1;
        }
        after
    }

    #[test]
    fn free_return_finds_lower_clear_positions_sequentially_and_preserves_inventory() {
        let (job, layout) = boundary_pair_fixture(false);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let original = sheets[1].layout();
        let members = return_seed_members(original);
        let mut source = JLayout::from_snapshot(&original.save());
        for (key, _, _) in &members {
            source.remove_item(*key);
        }
        let clock = Clock::new(Timing::Work, 120.0);
        let mut poses = vec![];
        for (_, item, seed) in &members {
            let pose = free_return_pose(&source, item, *seed, &clock, 10.0);
            assert!(
                pose.translation().0 < seed.translation().0 - 20.0,
                "Returned part must use a lower clear space"
            );
            assert_eq!(pose.rotation().to_bits(), seed.rotation().to_bits());
            assert_eq!(pose.reflected, seed.reflected);
            let mut shape = item.shape_cd().as_ref().clone();
            shape.transform_from(item.shape_cd(), &pose.compose());
            assert!(!source.cde().detect_poly_collision(&shape, &NoFilter));
            source.place_item(item, pose);
            poses.push(pose);
        }
        assert_eq!(source.placed_items().len(), original.placed_items().len());
        assert!(clock.counts().evaluations > 2.0 && clock.counts().evaluations <= 514.0);
        assert!(clock.counts().evaluated_vertices > 0.0);
        let after = free_return_public(&model, &model.to_layout(&sheets), &source, "sheet-1");
        assert!(validate(&job, &after).unwrap().valid);
        let replay_clock = Clock::new(Timing::Work, 120.0);
        let mut replay = JLayout::from_snapshot(&original.save());
        for (key, _, _) in &members {
            replay.remove_item(*key);
        }
        for ((_, item, seed), expected) in members.iter().zip(&poses) {
            let actual = free_return_pose(&replay, item, *seed, &replay_clock, 10.0);
            assert_eq!(
                return_seed_pose_bits(&[actual]),
                return_seed_pose_bits(&[*expected])
            );
            replay.place_item(item, actual);
        }
        assert_eq!(clock.work(), replay_clock.work());
        eprintln!(
            "FREE_RETURN_WITNESS {}",
            serde_json::json!({"job":job,"before":model.to_layout(&sheets),"after":after,"work":clock.counts()})
        );
    }

    #[test]
    fn free_return_preserves_permitted_mixed_rotations_and_mirrors() {
        let (mut job, layout) = boundary_pair_fixture(true);
        for part in &mut job.parts {
            part.allow_mirror = true;
            part.rotations = Rotations::List {
                degrees: vec![0.0, 90.0, 180.0, 270.0],
            };
        }
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let members = return_seed_members(sheets[1].layout());
        assert!(!std::sync::Arc::ptr_eq(&members[0].1, &members[1].1));
        let mut source = JLayout::from_snapshot(&sheets[1].layout().save());
        for (key, _, _) in &members {
            source.remove_item(*key);
        }
        let clock = Clock::new(Timing::Work, 120.0);
        for (index, (_, item, seed)) in members.iter().enumerate() {
            let seed = DTransformation::new(
                index as f32 * std::f32::consts::FRAC_PI_2,
                seed.translation(),
            )
            .with_reflection(index == 0);
            assert!(item.allowed_orientations().allows(&seed));
            let pose = free_return_pose(&source, item, seed, &clock, 10.0);
            assert!(
                pose.translation().0 < seed.translation().0 - 20.0,
                "Mixed return must find lower space"
            );
            assert_eq!(pose.rotation().to_bits(), seed.rotation().to_bits());
            assert_eq!(pose.reflected, seed.reflected);
            assert!(item.allowed_orientations().allows(&pose));
            source.place_item(item, pose);
        }
        let after = free_return_public(&model, &model.to_layout(&sheets), &source, "sheet-1");
        assert!(validate(&job, &after).unwrap().valid);
        eprintln!(
            "FREE_RETURN_WITNESS {}",
            serde_json::json!({"job":job,"before":model.to_layout(&sheets),"after":after,"work":clock.counts()})
        );
    }

    #[test]
    fn free_return_expired_and_mid_search_deadlines_keep_every_fallback() {
        let (job, layout) = boundary_pair_fixture(false);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let original = sheets[1].layout();
        let members = return_seed_members(original);
        for until in [0.0, 1e-12] {
            let clock = Clock::new(Timing::Work, 120.0);
            let mut source = JLayout::from_snapshot(&original.save());
            for (key, _, _) in &members {
                source.remove_item(*key);
            }
            for (_, item, seed) in &members {
                let pose = free_return_pose(&source, item, *seed, &clock, until);
                assert_eq!(
                    return_seed_pose_bits(&[pose]),
                    return_seed_pose_bits(&[*seed])
                );
                source.place_item(item, pose);
            }
            assert_eq!(source.placed_items().len(), original.placed_items().len());
            assert_eq!(
                clock.counts().evaluations,
                if until == 0.0 { 0.0 } else { 1.0 }
            );
            let after = free_return_public(&model, &model.to_layout(&sheets), &source, "sheet-1");
            assert!(validate(&job, &after).unwrap().valid);
        }
    }

    #[test]
    fn free_return_reserves_holes_and_keeps_unplaceable_seed_exact() {
        let (mut job, mut layout) = fixture();
        job.parts = vec![
            rectangle("frame", 94.0, 94.0),
            rectangle("return", 5.0, 5.0),
        ];
        job.parts[0].geometry[0].holes.push(vec![
            [20.0, 20.0],
            [20.0, 70.0],
            [70.0, 70.0],
            [70.0, 20.0],
        ]);
        layout.placements.truncate(2);
        layout.placements[0].part_id = "frame".into();
        layout.placements[1].sheet_id = "sheet-1".into();
        assert!(validate(&job, &layout).unwrap().valid);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[0].layout();
        let item = sheets[1]
            .layout()
            .placed_items()
            .values()
            .next()
            .unwrap()
            .item();
        let fallback = model.internal(
            item.idx(),
            &RigidTransform {
                translation: [40.0, 40.0],
                ..Default::default()
            },
        );
        let mut shape = item.shape_cd().as_ref().clone();
        shape.transform_from(item.shape_cd(), &fallback.compose());
        assert!(
            source.cde().detect_poly_collision(&shape, &NoFilter),
            "Hole interiors stay reserved"
        );
        let clock = Clock::new(Timing::Work, 120.0);
        let pose = free_return_pose(source, item, fallback, &clock, 10.0);
        assert_eq!(
            return_seed_pose_bits(&[pose]),
            return_seed_pose_bits(&[fallback])
        );
        assert!(clock.counts().evaluations > 1.0 && clock.counts().evaluations <= 257.0);
    }
    // END free-return tests

    fn chain_exercise(
        job: &Job,
        layout: &Layout,
        seed: u64,
        enabled: bool,
        budget: f64,
        frozen_count: usize,
    ) -> (usize, Layout, Stats) {
        let validation = validate(job, layout).unwrap();
        assert!(validation.valid, "{:?}", validation.violations);
        let model = Model::new(job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut search = Search {
            model: &model,
            allow_exchange: enabled,
            rng: Xoshiro256PlusPlus::seed_from_u64(seed),
            clock: clock.clone(),
            best: (layout.clone(), validation, 0.0),
            history: vec![],
            stats: Stats::default(),
            progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
            check_cost: 0.0,
            check_every: 5.0,
        };
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(layout).unwrap();
        let (frozen, window) = sheets.split_at(frozen_count);
        let mut shape = Shape {
            sheets: window.len(),
            last: model.full_width,
        };
        let initial = strip.layout(window, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut sep = Separator::new(
            strip.layout(window, shape).unwrap(),
            seed,
            EXPLORE,
            search.clock.clone(),
        );
        sep.pin(blocker_index(&model));
        assert_eq!(sep.tracker.total_loss(), 0.0);
        // Compare the same f32 internal frame before/after the exchange. The
        // public-to-internal conversion predates this operation and has its own
        // tests; comparing to the authored f64 coordinates conflates the two.
        let mut before_sheets = frozen.to_vec();
        before_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let before_layout = model.to_layout(&before_sheets);
        let before_report = validate(job, &before_layout).unwrap();
        assert!(before_report.valid);
        let before_material = before_report.metrics.as_ref().unwrap().material_area;
        let original = fingerprint(&sep.layout);
        let until = if budget <= 0.0 {
            0.0
        } else {
            search.clock.now() + budget
        };
        let moved = search
            .directed_exchange_chain(&strip, frozen, &mut sep, shape, until)
            .unwrap();
        if moved == 0 {
            assert_eq!(
                fingerprint(&sep.layout),
                original,
                "failed proposal mutated the original state"
            );
        }
        let mut after_sheets = frozen.to_vec();
        after_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let after = model.to_layout(&after_sheets);
        for i in 0..frozen_count {
            let id = format!("sheet-{i}");
            let before_fixed: Vec<_> = before_layout
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            let after_fixed: Vec<_> = after
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            assert_eq!(
                serde_json::to_value(before_fixed).unwrap(),
                serde_json::to_value(after_fixed).unwrap()
            );
        }
        let report = validate(job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert!(report.metrics.as_ref().unwrap().material_area <= before_material);
        assert_eq!(sep.tracker.total_loss(), 0.0);
        eprintln!(
            "CHAIN_WITNESS {}",
            serde_json::json!({"job":job,"before":before_layout,"after":after,"seed":seed,"enabled":enabled,"budget":budget,"moved":moved,"work":search.clock.counts(),"until":until,"finished":search.clock.now()})
        );
        (moved, after, search.stats)
    }

    // BEGIN exchange-chain tests
    fn chain_fixture() -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.name = "Two successive source-height reductions".into();
        job.parts[0].quantity = 2;
        job.parts[1].quantity = 2;
        job.parts.push(rectangle("incoming-short", 30.0, 65.0));
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        layout.placements[2].sheet_id = "sheet-2".into();
        for index in 0..2 {
            let mut p = layout.placements[index].clone();
            p.copy_index = 1;
            p.sheet_id = "sheet-1".into();
            layout.placements.push(p);
        }
        layout.placements.push(Placement {
            part_id: "incoming-short".into(),
            copy_index: 0,
            sheet_id: "sheet-2".into(),
            transform: RigidTransform {
                translation: [36.0, 2.0],
                ..Default::default()
            },
        });
        assert!(validate(&job, &layout).unwrap().valid);
        (job, layout)
    }

    #[test]
    fn exchange_chain_policy_stops_on_flat_failure_and_four_successes() {
        let mut calls = 0;
        assert_eq!(
            continue_exchanges(|| {
                calls += 1;
                Ok(Some(true))
            })
            .unwrap(),
            4
        );
        assert_eq!(calls, 4);
        for (sequence, expected, counter) in [
            (vec![Some(false), Some(true)], 1, 1),
            (vec![Some(true), None, Some(true)], 1, 2),
            (vec![Some(true), Some(false), Some(true)], 2, 2),
            (vec![None, Some(true)], 0, 1),
        ] {
            let mut calls = 0;
            let moved = continue_exchanges(|| {
                let result = sequence[calls];
                calls += 1;
                Ok(result)
            })
            .unwrap();
            assert_eq!(moved, expected);
            assert_eq!(calls, counter);
        }
    }

    #[test]
    fn exchange_chain_accepts_successive_valid_gains_and_replays() {
        let (job, layout) = chain_fixture();
        let (once, one, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(once, 1);
        let (moved, after, stats) = chain_exercise(&job, &layout, 0, true, 3.0, 0);
        assert!((2..=4).contains(&moved), "successive exchanges: {stats:?}");
        assert_eq!(stats.directed_exchanges, moved as u64);
        assert!(
            validate(&job, &after)
                .unwrap()
                .metrics
                .unwrap()
                .material_area
                < validate(&job, &one).unwrap().metrics.unwrap().material_area
        );
        let (again, replay, _) = chain_exercise(&job, &layout, 0, true, 3.0, 0);
        assert_eq!(again, moved);
        assert_eq!(
            serde_json::to_value(after).unwrap(),
            serde_json::to_value(replay).unwrap()
        );
    }

    #[test]
    fn exchange_chain_disabled_expired_and_validation_deadline_preserve_incumbent() {
        let (job, layout) = chain_fixture();
        let (_, baseline, _) = chain_exercise(&job, &layout, 0, false, 3.0, 0);
        for (enabled, budget) in [(false, 3.0), (true, 0.0), (true, 1e-12)] {
            let (moved, after, stats) = chain_exercise(&job, &layout, 0, enabled, budget, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.directed_exchanges, 0);
            assert_eq!(
                serde_json::to_value(after).unwrap(),
                serde_json::to_value(&baseline).unwrap()
            );
        }
    }

    #[test]
    fn exchange_chain_failed_repair_preserves_frozen_and_active_sheets() {
        let (mut job, layout) = chain_fixture();
        job.parts[2] = rectangle("incoming", 20.0, 10.0);
        job.parts[3] = rectangle("incoming-short", 20.0, 10.0);
        let (moved, _, stats) = chain_exercise(&job, &layout, 0, true, 3.0, 1);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchanges, 0);
    }
    // END exchange-chain tests

    fn extended_exercise(
        job: &Job,
        layout: &Layout,
        seed: u64,
        enabled: bool,
        phase: (f64, f64, u8),
        frozen_count: usize,
    ) -> (usize, Layout, Stats) {
        let (short_budget, budget, mode) = phase;
        let validation = validate(job, layout).unwrap();
        assert!(validation.valid, "{:?}", validation.violations);
        let model = Model::new(job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut search = Search {
            model: &model,
            allow_exchange: enabled,
            rng: Xoshiro256PlusPlus::seed_from_u64(seed),
            clock: clock.clone(),
            best: (layout.clone(), validation, 0.0),
            history: vec![],
            stats: Stats::default(),
            progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
            check_cost: 0.0,
            check_every: 5.0,
        };
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(layout).unwrap();
        let (frozen, window) = sheets.split_at(frozen_count);
        let mut shape = Shape {
            sheets: window.len(),
            last: model.full_width,
        };
        let initial = strip.layout(window, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut sep = Separator::new(
            strip.layout(window, shape).unwrap(),
            seed,
            EXPLORE,
            search.clock.clone(),
        );
        sep.pin(blocker_index(&model));
        assert_eq!(sep.tracker.total_loss(), 0.0);
        // Compare the same f32 internal frame before/after the exchange. The
        // public-to-internal conversion predates this operation and has its own
        // tests; comparing to the authored f64 coordinates conflates the two.
        let mut before_sheets = frozen.to_vec();
        before_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let before_layout = model.to_layout(&before_sheets);
        let before_report = validate(job, &before_layout).unwrap();
        assert!(before_report.valid);
        let before_material = before_report.metrics.as_ref().unwrap().material_area;
        let original = fingerprint(&sep.layout);
        let until = if budget <= 0.0 {
            0.0
        } else {
            search.clock.now() + budget
        };
        let short_until = if short_budget <= 0.0 {
            0.0
        } else {
            search.clock.now() + short_budget
        };
        let mut fast_layout = None;
        let moved = match mode {
            0 => search
                .directed_exchange_window(&strip, frozen, &mut sep, shape, short_until, until)
                .unwrap(),
            1 => usize::from(
                search
                    .directed_exchange_mode(&strip, frozen, &mut sep, shape, until, true)
                    .unwrap()
                    .is_some(),
            ),
            2 => {
                let accepted = search
                    .directed_exchange_chain(&strip, frozen, &mut sep, shape, short_until)
                    .unwrap();
                assert!(accepted > 0);
                let fingerprint_before = fingerprint(&sep.layout);
                fast_layout = Some(
                    search
                        .exchange_layout(&strip, frozen, &sep.layout, shape)
                        .unwrap(),
                );
                let expired = search.clock.now();
                let extra = search
                    .extend_exchange_chain(&strip, frozen, &mut sep, shape, expired, accepted)
                    .unwrap();
                assert_eq!(extra, 0);
                assert_eq!(fingerprint(&sep.layout), fingerprint_before);
                accepted
            }
            _ => unreachable!(),
        };
        if moved == 0 {
            assert_eq!(
                fingerprint(&sep.layout),
                original,
                "failed proposal mutated the original state"
            );
        }
        let mut after_sheets = frozen.to_vec();
        after_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let after = model.to_layout(&after_sheets);
        for i in 0..frozen_count {
            let id = format!("sheet-{i}");
            let before_fixed: Vec<_> = before_layout
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            let after_fixed: Vec<_> = after
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            assert_eq!(
                serde_json::to_value(before_fixed).unwrap(),
                serde_json::to_value(after_fixed).unwrap()
            );
        }
        let report = validate(job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert!(report.metrics.as_ref().unwrap().material_area <= before_material);
        assert_eq!(sep.tracker.total_loss(), 0.0);
        eprintln!(
            "EXTENDED_REPAIR_WITNESS {}",
            serde_json::json!({"job":job,"before":before_layout,"after":after,"seed":seed,"enabled":enabled,"budget":budget,"short_budget":short_budget,"mode":mode,"fast_layout":fast_layout,"stats":search.stats,"moved":moved,"work":search.clock.counts(),"until":until,"finished":search.clock.now()})
        );
        (moved, after, search.stats)
    }

    // BEGIN extended-repair tests
    #[test]
    fn extended_repair_shares_four_acceptance_cap_and_stops_after_no_move() {
        for accepted in 0..=4 {
            let mut calls = 0;
            let extra = continue_remaining_exchanges(accepted, || {
                calls += 1;
                Ok(Some(true))
            })
            .unwrap();
            assert_eq!(extra, 4 - accepted, "Remaining allowance must be usable");
            assert_eq!(calls, 4 - accepted);
        }
        let mut calls = 0;
        assert_eq!(
            continue_remaining_exchanges(1, || {
                calls += 1;
                Ok(None)
            })
            .unwrap(),
            0
        );
        assert_eq!(calls, 1);
    }

    fn extended_frozen_fixture() -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.parts.push(rectangle("fixed", 10.0, 94.0));
        for p in &mut layout.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        layout.placements.push(Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                ..Default::default()
            },
        });
        (job, layout)
    }

    #[test]
    fn extended_repair_actual_whole_job_gain_preserves_frozen_sheet_and_replays() {
        let (job, layout) = extended_frozen_fixture();
        let (_, baseline, _) = extended_exercise(&job, &layout, 0, false, (0.0, 3.0, 1), 1);
        let (moved, after, stats) = extended_exercise(&job, &layout, 0, true, (0.0, 3.0, 1), 1);
        assert_eq!(moved, 1);
        assert_eq!(stats.extended_exchanges, 1);
        assert!(stats.extended_exchange_attempts > 0);
        assert!(
            validate(&job, &after)
                .unwrap()
                .metrics
                .unwrap()
                .material_area
                < validate(&job, &baseline)
                    .unwrap()
                    .metrics
                    .unwrap()
                    .material_area
        );
        let (again, replay, _) = extended_exercise(&job, &layout, 0, true, (0.0, 3.0, 1), 1);
        assert_eq!(again, moved);
        assert_eq!(
            serde_json::to_value(after).unwrap(),
            serde_json::to_value(replay).unwrap()
        );
    }

    #[test]
    fn extended_repair_rejects_actual_flat_swap_and_requires_strict_gain() {
        let (job, layout) = larger_return_fixture();
        let (_, baseline, _) = extended_exercise(&job, &layout, 0, false, (0.0, 3.0, 1), 0);
        let (moved, after, stats) = extended_exercise(&job, &layout, 0, true, (0.0, 3.0, 1), 0);
        assert!(
            stats.extended_flat_rejections > 0,
            "Actual flat tail proposal must be rejected"
        );
        if moved > 0 {
            assert!(
                validate(&job, &after)
                    .unwrap()
                    .metrics
                    .unwrap()
                    .material_area
                    < validate(&job, &baseline)
                        .unwrap()
                        .metrics
                        .unwrap()
                        .material_area
            );
        } else {
            assert_eq!(
                serde_json::to_value(after).unwrap(),
                serde_json::to_value(baseline).unwrap()
            );
        }
    }

    #[test]
    fn extended_repair_expired_tail_preserves_successful_fast_incumbent_exactly() {
        let (job, layout) = fixture();
        let (moved, _, stats) = extended_exercise(&job, &layout, 0, true, (3.0, 3.0, 2), 0);
        assert!(moved > 0);
        assert_eq!(stats.extended_exchange_attempts, 0);
        assert_eq!(stats.extended_exchanges, 0);
    }

    #[test]
    fn extended_repair_disabled_deadline_and_failed_source_keep_incumbents() {
        let (job, layout) = chain_fixture();
        for (enabled, phase) in [
            (false, (1.2, 5.4, 0)),
            (true, (0.0, 0.0, 0)),
            (true, (1e-12, 1e-12, 0)),
            (true, (0.0, 0.0, 1)),
        ] {
            let (moved, _, stats) = extended_exercise(&job, &layout, 0, enabled, phase, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.extended_exchanges, 0);
        }
        let (mut job, layout) = fixture();
        job.parts[1] = rectangle("return", 5.0, 90.0);
        job.parts[2] = rectangle("incoming", 30.0, 30.0);
        let (moved, _, stats) = extended_exercise(&job, &layout, 0, true, (1.2, 3.0, 0), 0);
        assert_eq!(moved, 0);
        assert_eq!(stats.extended_exchanges, 0);
    }

    #[test]
    fn extended_repair_preserves_fast_opportunities_and_only_improves_afterward() {
        for ((job, layout), seed) in [(larger_return_fixture(), 3), (mixed_fixture(), 0)] {
            let (fast, baseline, _) = chain_exercise(&job, &layout, seed, true, 3.0, 0);
            assert!(fast > 0);
            let (moved, after, stats) =
                extended_exercise(&job, &layout, seed, true, (3.0, 5.0, 0), 0);
            assert!((fast..=4).contains(&moved));
            assert_eq!(stats.directed_exchanges, moved as u64);
            assert_eq!(stats.extended_exchanges, (moved - fast) as u64);
            if moved > fast {
                assert!(
                    validate(&job, &after)
                        .unwrap()
                        .metrics
                        .unwrap()
                        .material_area
                        < validate(&job, &baseline)
                            .unwrap()
                            .metrics
                            .unwrap()
                            .material_area
                );
            } else {
                assert_eq!(
                    serde_json::to_value(after).unwrap(),
                    serde_json::to_value(baseline).unwrap()
                );
            }
        }
    }
    // END extended-repair tests
    #[test]
    fn extended_repair_source_can_clear_after_short_slice_has_elapsed() {
        let (mut job, mut layout) = fixture();
        job.name = "Authored source repair after elapsed short slice".into();
        job.parts = vec![rectangle("tile", 17.0, 17.0)];
        job.parts[0].quantity = 25;
        layout.sheets.truncate(1);
        layout.placements.clear();
        for row in 0..5 {
            for col in 0..5 {
                layout.placements.push(Placement {
                    part_id: "tile".into(),
                    copy_index: row * 5 + col,
                    sheet_id: "sheet-0".into(),
                    transform: RigidTransform {
                        translation: [2.0 + 16.0 * f64::from(col), 2.0 + 16.0 * f64::from(row)],
                        ..Default::default()
                    },
                });
            }
        }
        assert!(
            !validate(&job, &layout).unwrap().valid,
            "This is an overlapping proposed source, not an accepted layout"
        );
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let clock = Clock::new(Timing::Work, 60.0);
        let mut source = Separator::new(
            JLayout::from_snapshot(&sheets[0].layout().save()),
            0,
            EXPLORE,
            clock.clone(),
        );
        assert!(source.tracker.total_loss() > 0.0);
        let now = clock.now();
        let former_source = now + 0.4;
        let full_until = now + 3.0;
        let source_until = source_repair_deadline(former_source, full_until, true);
        // Explicitly simulate prior receiver work consuming the short slice.
        // This charged delay is a policy fixture, never a timing measurement.
        clock.charge(Work::Evaluation, 300_000.0);
        let started = clock.now();
        assert!(started > former_source && started < full_until);
        let (snapshot, tracker) = source.separate(&crate::clock::Deadline {
            clock: clock.clone(),
            at: source_until,
        });
        assert_eq!(
            tracker.total_loss(),
            0.0,
            "Remaining phase must permit actual source repair"
        );
        assert!(
            clock.now() < full_until,
            "Repair must finish before the shared phase ends"
        );
        let repaired = JLayout::from_snapshot(&snapshot);
        let after = free_return_public(&model, &model.to_layout(&sheets), &repaired, "sheet-0");
        let report = validate(&job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        eprintln!(
            "CONTINUOUS_REPAIR_WITNESS {}",
            serde_json::json!({"job":job,"before":layout,"after":after,"source_started":started,"former_source_until":former_source,"full_until":full_until,"source_until":source_until,"finished":clock.now(),"simulated_prior_evaluations":300000,"work":clock.counts()})
        );
    }
    fn assignment_bridge_manual_exercise(
        job: &Job,
        layout: &Layout,
        seed: u64,
        enabled: bool,
        budget: f64,
        frozen_count: usize,
    ) -> (usize, Layout, Stats, Vec<(bool, f64, f64)>) {
        let validation = validate(job, layout).unwrap();
        assert!(validation.valid, "{:?}", validation.violations);
        let model = Model::new(job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut search = Search {
            model: &model,
            allow_exchange: enabled,
            rng: Xoshiro256PlusPlus::seed_from_u64(seed),
            clock: clock.clone(),
            best: (layout.clone(), validation, 0.0),
            history: vec![],
            stats: Stats::default(),
            progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
            check_cost: 0.0,
            check_every: 5.0,
        };
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(layout).unwrap();
        let (frozen, window) = sheets.split_at(frozen_count);
        let mut shape = Shape {
            sheets: window.len(),
            last: model.full_width,
        };
        let initial = strip.layout(window, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut sep = Separator::new(
            strip.layout(window, shape).unwrap(),
            seed,
            EXPLORE,
            search.clock.clone(),
        );
        sep.pin(blocker_index(&model));
        assert_eq!(sep.tracker.total_loss(), 0.0);
        // Compare the same f32 internal frame before/after the exchange. The
        // public-to-internal conversion predates this operation and has its own
        // tests; comparing to the authored f64 coordinates conflates the two.
        let mut before_sheets = frozen.to_vec();
        before_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let before_layout = model.to_layout(&before_sheets);
        let before_report = validate(job, &before_layout).unwrap();
        assert!(before_report.valid);
        let before_material = before_report.metrics.as_ref().unwrap().material_area;
        let original = fingerprint(&sep.layout);
        let until = if budget <= 0.0 {
            0.0
        } else {
            search.clock.now() + budget
        };
        let source_id = format!("sheet-{}", sheets.len() - 1);
        let mut steps = vec![];
        let mut moved = 0;
        let mut step_before = before_layout.clone();
        for step in 0..3 {
            let improved = search
                .directed_exchange_once(&strip, frozen, &mut sep, shape, until)
                .unwrap()
                .expect("Existing per-step rule must admit all three authored exchanges");
            let step_after = search
                .exchange_layout(&strip, frozen, &sep.layout, shape)
                .unwrap();
            let report = validate(job, &step_after).unwrap();
            assert!(report.valid);
            let material = report.metrics.unwrap().material_area;
            let area = assignment_bridge_public_area(job, &step_after, &source_id);
            steps.push((improved, material, area));
            moved += 1;
            eprintln!(
                "BRIDGE_STEP_WITNESS {}",
                serde_json::json!({"job":job,"seed":seed,
                "step":step,"before":step_before,"after":step_after,"source_sheet":source_id,
                "material_improved":improved,"material":material,"source_filled_area":area,
                "until":until,"finished":search.clock.now(),"stats":search.stats})
            );
            step_before = step_after;
        }
        if moved == 0 {
            assert_eq!(
                fingerprint(&sep.layout),
                original,
                "failed proposal mutated the original state"
            );
        }
        let mut after_sheets = frozen.to_vec();
        after_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let after = model.to_layout(&after_sheets);
        for i in 0..frozen_count {
            let id = format!("sheet-{i}");
            let before_fixed: Vec<_> = before_layout
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            let after_fixed: Vec<_> = after
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            assert_eq!(
                serde_json::to_value(before_fixed).unwrap(),
                serde_json::to_value(after_fixed).unwrap()
            );
        }
        let report = validate(job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert!(report.metrics.as_ref().unwrap().material_area <= before_material);
        assert_eq!(sep.tracker.total_loss(), 0.0);
        eprintln!(
            "BRIDGE_MANUAL_WITNESS {}",
            serde_json::json!({"job":job,"before":before_layout,"after":after,"seed":seed,"enabled":enabled,"budget":budget,"moved":moved,"work":search.clock.counts(),"until":until,"finished":search.clock.now()})
        );
        (moved, after, search.stats, steps)
    }

    // BEGIN assignment-bridge witness tests
    fn assignment_bridge_public_area(job: &Job, layout: &Layout, sheet: &str) -> f64 {
        layout
            .placements
            .iter()
            .filter(|p| p.sheet_id == sheet)
            .map(|p| {
                let part = job.parts.iter().find(|part| part.id == p.part_id).unwrap();
                part.geometry
                    .iter()
                    .map(|g| crate::curves::signed_area(&g.outer).abs())
                    .sum::<f64>()
            })
            .sum()
    }

    fn assignment_bridge_fixture() -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.name = "Three equal height owners require two material-flat assignments".into();
        for part in &mut job.parts {
            part.quantity = 3;
        }
        layout.sheets = (0..4)
            .map(|i| Sheet {
                id: format!("sheet-{i}"),
                stock_id: "stock".into(),
            })
            .collect();
        layout.placements.clear();
        for i in 0..3 {
            for (id, translation) in [("filler", [2.0, 2.0]), ("return", [64.0, 2.0])] {
                layout.placements.push(Placement {
                    part_id: id.into(),
                    copy_index: i,
                    sheet_id: format!("sheet-{i}"),
                    transform: RigidTransform {
                        translation,
                        ..Default::default()
                    },
                });
            }
            layout.placements.push(Placement {
                part_id: "incoming".into(),
                copy_index: i,
                sheet_id: "sheet-3".into(),
                transform: RigidTransform {
                    translation: [2.0 + 32.0 * i as f64, 2.0],
                    ..Default::default()
                },
            });
        }
        assert!(validate(&job, &layout).unwrap().valid);
        (job, layout)
    }

    #[test]
    fn assignment_bridge_existing_steps_cross_two_flat_states_before_a_gain() {
        let (job, layout) = assignment_bridge_fixture();
        let original_area = assignment_bridge_public_area(&job, &layout, "sheet-3");
        let (moved, after, stats, steps) =
            assignment_bridge_manual_exercise(&job, &layout, 0, true, 12.0, 0);
        assert_eq!(moved, 3);
        assert_eq!(stats.directed_exchanges, 3);
        assert_eq!(
            steps.iter().map(|s| s.0).collect::<Vec<_>>(),
            vec![false, false, true]
        );
        assert_eq!(steps[0].1, steps[1].1);
        assert!(steps[2].1 < steps[1].1);
        assert!(original_area > steps[0].2 && steps[0].2 > steps[1].2 && steps[1].2 > steps[2].2);
        let (_, old, old_stats) = extended_exercise(&job, &layout, 0, true, (3.0, 12.0, 0), 0);
        assert!(
            validate(&job, &old).unwrap().metrics.unwrap().material_area
                > validate(&job, &after)
                    .unwrap()
                    .metrics
                    .unwrap()
                    .material_area,
            "The retained short-plus-strict-tail policy must expose the authored bridge gap: {old_stats:?}"
        );
    }
    // END assignment-bridge witness tests
    fn assignment_bridge_exercise(
        job: &Job,
        layout: &Layout,
        seed: u64,
        enabled: bool,
        phase: (f64, f64, u8),
        frozen_count: usize,
    ) -> (usize, Layout, Stats) {
        let (short_budget, budget, mode) = phase;
        let validation = validate(job, layout).unwrap();
        assert!(validation.valid, "{:?}", validation.violations);
        let model = Model::new(job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut search = Search {
            model: &model,
            allow_exchange: enabled,
            rng: Xoshiro256PlusPlus::seed_from_u64(seed),
            clock: clock.clone(),
            best: (layout.clone(), validation, 0.0),
            history: vec![],
            stats: Stats::default(),
            progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
            check_cost: 0.0,
            check_every: 5.0,
        };
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(layout).unwrap();
        let (frozen, window) = sheets.split_at(frozen_count);
        let mut shape = Shape {
            sheets: window.len(),
            last: model.full_width,
        };
        let initial = strip.layout(window, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut sep = Separator::new(
            strip.layout(window, shape).unwrap(),
            seed,
            EXPLORE,
            search.clock.clone(),
        );
        sep.pin(blocker_index(&model));
        assert_eq!(sep.tracker.total_loss(), 0.0);
        // Compare the same f32 internal frame before/after the exchange. The
        // public-to-internal conversion predates this operation and has its own
        // tests; comparing to the authored f64 coordinates conflates the two.
        let mut before_sheets = frozen.to_vec();
        before_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let before_layout = model.to_layout(&before_sheets);
        let before_report = validate(job, &before_layout).unwrap();
        assert!(before_report.valid);
        let before_material = before_report.metrics.as_ref().unwrap().material_area;
        let original = fingerprint(&sep.layout);
        let until = if budget <= 0.0 {
            0.0
        } else {
            search.clock.now() + budget
        };
        let short_until = if short_budget <= 0.0 {
            0.0
        } else {
            search.clock.now() + short_budget
        };
        let mut fast_layout = None;
        let moved = match mode {
            0 => search
                .assignment_bridge_window(&strip, frozen, &mut sep, shape, short_until, until)
                .unwrap(),
            1 => search
                .assignment_bridge_chain(&strip, frozen, &mut sep, shape, until, 0)
                .unwrap(),
            3 => search
                .assignment_bridge_chain(&strip, frozen, &mut sep, shape, until, 3)
                .unwrap(),
            2 => {
                let accepted = search
                    .directed_exchange_chain(&strip, frozen, &mut sep, shape, short_until)
                    .unwrap();
                assert!(accepted > 0);
                let fingerprint_before = fingerprint(&sep.layout);
                fast_layout = Some(
                    search
                        .exchange_layout(&strip, frozen, &sep.layout, shape)
                        .unwrap(),
                );
                let expired = search.clock.now();
                let extra = search
                    .assignment_bridge_chain(&strip, frozen, &mut sep, shape, expired, accepted)
                    .unwrap();
                assert_eq!(extra, 0);
                assert_eq!(fingerprint(&sep.layout), fingerprint_before);
                accepted
            }
            _ => unreachable!(),
        };
        if moved == 0 {
            assert_eq!(
                fingerprint(&sep.layout),
                original,
                "failed proposal mutated the original state"
            );
        }
        let mut after_sheets = frozen.to_vec();
        after_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let after = model.to_layout(&after_sheets);
        for i in 0..frozen_count {
            let id = format!("sheet-{i}");
            let before_fixed: Vec<_> = before_layout
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            let after_fixed: Vec<_> = after
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            assert_eq!(
                serde_json::to_value(before_fixed).unwrap(),
                serde_json::to_value(after_fixed).unwrap()
            );
        }
        let report = validate(job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert!(report.metrics.as_ref().unwrap().material_area <= before_material);
        assert_eq!(sep.tracker.total_loss(), 0.0);
        eprintln!(
            "BRIDGE_RESULT_WITNESS {}",
            serde_json::json!({"job":job,"before":before_layout,"after":after,"seed":seed,"enabled":enabled,"budget":budget,"short_budget":short_budget,"mode":mode,"fast_layout":fast_layout,"stats":search.stats,"moved":moved,"work":search.clock.counts(),"until":until,"finished":search.clock.now()})
        );
        (moved, after, search.stats)
    }

    // BEGIN assignment-bridge new policy tests
    #[test]
    fn assignment_bridge_new_canonical_area_reserves_holes_and_ignores_keys() {
        let (mut job, layout) = assignment_bridge_fixture();
        job.parts[2].geometry[0].holes =
            vec![vec![[5.0, 5.0], [5.0, 80.0], [25.0, 80.0], [25.0, 5.0]]];
        let model = Model::new(&job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(&layout).unwrap();
        let shape = Shape {
            sheets: 4,
            last: model.full_width,
        };
        let native = strip.layout(&sheets, shape).unwrap();
        let mut reverse = JLayout::new(native.container().clone());
        let items: Vec<_> = native.placed_items().values().collect();
        for item in items.into_iter().rev() {
            reverse.place_item(item.item(), item.d_transf());
        }
        assert_eq!(
            assignment_source_area(&strip, &native, shape),
            7650.0,
            "Filled source area must include hole interiors"
        );
        assert_eq!(
            assignment_source_area(&strip, &native, shape),
            assignment_source_area(&strip, &reverse, shape)
        );
    }

    #[test]
    fn assignment_bridge_new_window_crosses_flat_steps_and_replays() {
        let (job, layout) = assignment_bridge_fixture();
        let (moved, after, stats) =
            assignment_bridge_exercise(&job, &layout, 0, true, (3.0, 12.0, 0), 0);
        assert_eq!(moved, 3, "Whole window must cross the remaining flat state");
        assert_eq!(stats.directed_exchanges, 3);
        assert!(stats.assignment_bridge_flat_steps > 0);
        assert_eq!(stats.assignment_bridge_committed, 2);
        assert_eq!(stats.assignment_bridge_rolled_back, 0);
        assert!(
            validate(&job, &after)
                .unwrap()
                .metrics
                .unwrap()
                .material_area
                < 33000.0
        );
        let (again, replay, replay_stats) =
            assignment_bridge_exercise(&job, &layout, 0, true, (3.0, 12.0, 0), 0);
        assert_eq!(again, moved);
        assert_eq!(
            serde_json::to_value(after).unwrap(),
            serde_json::to_value(replay).unwrap()
        );
        assert_eq!(
            serde_json::to_value(stats).unwrap(),
            serde_json::to_value(replay_stats).unwrap()
        );
    }

    #[test]
    fn assignment_bridge_new_tail_commits_only_after_final_material_gain() {
        let (job, layout) = assignment_bridge_fixture();
        let (moved, after, stats) =
            assignment_bridge_exercise(&job, &layout, 0, true, (0.0, 12.0, 1), 0);
        assert_eq!(moved, 3, "Tail must bridge two flat states");
        assert_eq!(stats.assignment_bridge_flat_steps, 2);
        assert_eq!(stats.assignment_bridge_steps, 3);
        assert_eq!(stats.assignment_bridge_committed, 3);
        assert_eq!(stats.assignment_bridge_rolled_back, 0);
        assert!(
            validate(&job, &after)
                .unwrap()
                .metrics
                .unwrap()
                .material_area
                < 33000.0
        );
    }

    #[test]
    fn assignment_bridge_new_no_final_gain_restores_active_and_frozen_layouts() {
        let (job, layout) = assignment_bridge_fixture();
        let (moved, _, stats) =
            assignment_bridge_exercise(&job, &layout, 0, true, (0.0, 12.0, 1), 1);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchanges, 0);
        assert!(
            stats.assignment_bridge_flat_steps > 0,
            "Actual flat steps must be tried before rollback"
        );
        assert_eq!(
            stats.assignment_bridge_steps,
            stats.assignment_bridge_rolled_back
        );
        assert_eq!(stats.assignment_bridge_committed, 0);
        assert_eq!(stats.assignment_bridge_rollbacks, 1);
    }

    #[test]
    fn assignment_bridge_new_disabled_expired_and_fast_expiry_keep_incumbents() {
        let (job, layout) = assignment_bridge_fixture();
        let (_, baseline, _) =
            assignment_bridge_exercise(&job, &layout, 0, false, (0.0, 12.0, 1), 0);
        for (enabled, budget) in [(false, 12.0), (true, 0.0), (true, 1e-12)] {
            let (moved, after, stats) =
                assignment_bridge_exercise(&job, &layout, 0, enabled, (0.0, budget, 1), 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.assignment_bridge_steps, 0);
            assert_eq!(
                serde_json::to_value(after).unwrap(),
                serde_json::to_value(&baseline).unwrap()
            );
        }
        let (moved, _, stats) =
            assignment_bridge_exercise(&job, &layout, 0, true, (3.0, 12.0, 2), 0);
        assert_eq!(moved, 1);
        assert_eq!(stats.assignment_bridge_steps, 0);
    }

    #[test]
    fn assignment_bridge_new_last_available_slot_cannot_publish_a_flat_step() {
        let (job, layout) = assignment_bridge_fixture();
        let (moved, _, stats) =
            assignment_bridge_exercise(&job, &layout, 0, true, (0.0, 12.0, 3), 0);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchanges, 0);
        assert_eq!(
            stats.assignment_bridge_steps, 1,
            "One remaining slot must admit one provisional flat step"
        );
        assert_eq!(stats.assignment_bridge_flat_steps, 1);
        assert_eq!(stats.assignment_bridge_rolled_back, 1);
        assert_eq!(stats.assignment_bridge_committed, 0);
    }

    #[test]
    fn assignment_bridge_new_keeps_the_prior_fast_opportunities() {
        for ((job, layout), seed) in [(larger_return_fixture(), 3), (mixed_fixture(), 0)] {
            let (fast, baseline, _) = chain_exercise(&job, &layout, seed, true, 3.0, 0);
            assert!(fast > 0);
            let (moved, after, stats) =
                assignment_bridge_exercise(&job, &layout, seed, true, (3.0, 5.0, 0), 0);
            assert!((fast..=4).contains(&moved));
            assert_eq!(stats.directed_exchanges, moved as u64);
            assert_eq!(stats.assignment_bridge_committed, (moved - fast) as u64);
            assert_eq!(
                stats.assignment_bridge_steps,
                stats.assignment_bridge_committed + stats.assignment_bridge_rolled_back
            );
            if moved > fast {
                assert!(
                    validate(&job, &after)
                        .unwrap()
                        .metrics
                        .unwrap()
                        .material_area
                        < validate(&job, &baseline)
                            .unwrap()
                            .metrics
                            .unwrap()
                            .material_area
                );
            } else {
                assert_eq!(
                    serde_json::to_value(after).unwrap(),
                    serde_json::to_value(baseline).unwrap()
                );
            }
        }
    }
    // END assignment-bridge new policy tests

    // BEGIN joint-repair witness: original runtime, authored overlapping proposal
    #[test]
    fn joint_repair_existing_separator_can_change_the_source_assignment() {
        let (mut job, mut layout) = fixture();
        job.name = "Joint window permits an extra source member to migrate".into();
        job.parts = vec![
            rectangle("prefix", 96.0, 94.0),
            rectangle("filler", 20.0, 94.0),
            rectangle("return", 60.0, 85.0),
            rectangle("incoming", 30.0, 94.0),
            rectangle("extra", 40.0, 50.0),
        ];
        layout.sheets = (0..3)
            .map(|i| Sheet {
                id: format!("sheet-{i}"),
                stock_id: "stock".into(),
            })
            .collect();
        layout.placements = [
            ("prefix", 0, [2.0, 2.0]),
            ("filler", 1, [78.0, 2.0]),
            ("return", 1, [2.0, 2.0]),
            ("incoming", 2, [2.0, 2.0]),
            ("extra", 2, [34.0, 2.0]),
        ]
        .into_iter()
        .map(|(id, sheet, translation)| Placement {
            part_id: id.into(),
            copy_index: 0,
            sheet_id: format!("sheet-{sheet}"),
            transform: RigidTransform {
                translation,
                ..Default::default()
            },
        })
        .collect();
        assert!(validate(&job, &layout).unwrap().valid);
        let mut proposed = layout.clone();
        for p in &mut proposed.placements {
            if p.part_id == "incoming" {
                p.sheet_id = "sheet-1".into();
            }
            if p.part_id == "return" {
                p.sheet_id = "sheet-2".into();
            }
        }
        assert!(!validate(&job, &proposed).unwrap().valid);
        // Two unrotated rectangles can avoid overlap only by separation along
        // at least one axis. Even the full usable sheet is too small on both
        // axes for this source inventory; its cropped prefix is no larger.
        let usable = 100.0 - 2.0 * job.edge_clearance;
        assert!(60.0 + 40.0 + job.clearance > usable);
        assert!(85.0 + 50.0 + job.clearance > usable);
        let mut authored = proposed.clone();
        authored
            .placements
            .iter_mut()
            .find(|p| p.part_id == "extra")
            .unwrap()
            .sheet_id = "sheet-1".into();
        let hand_report = validate(&job, &authored).unwrap();
        assert!(hand_report.valid);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let proposed_sheets = model.sheets_of(&proposed).unwrap();
        let clock = Clock::new(Timing::Work, 60.0);
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock: clock.clone(),
            containers: Default::default(),
        };
        let (frozen, window) = sheets.split_at(1);
        let mut shape = Shape {
            sheets: window.len(),
            last: model.full_width,
        };
        let initial = strip.layout(window, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut before_sheets = frozen.to_vec();
        before_sheets.extend(strip.split(&initial, shape.sheets).unwrap());
        let before = model.to_layout(&before_sheets);
        let before_report = validate(&job, &before).unwrap();
        assert!(before_report.valid);
        let seed = strip.layout(&proposed_sheets[1..], shape).unwrap();
        let mut seed_sheets = frozen.to_vec();
        seed_sheets.extend(strip.split(&seed, shape.sheets).unwrap());
        let proposed_public = model.to_layout(&seed_sheets);
        let mut source = JLayout::new(
            strip
                .container(Shape {
                    sheets: 1,
                    last: shape.last,
                })
                .unwrap(),
        );
        for p in seed
            .placed_items()
            .values()
            .filter(|p| !strip.is_blocker(p) && strip.sheet_of(p.shape()) == 1)
        {
            source.place_item(p.item(), shift(p.d_transf(), -strip.start(1)));
        }
        assert_eq!(source.placed_items().len(), 2);
        let source_clock = Clock::new(Timing::Work, 60.0);
        let mut source_sep = Separator::new(source, 0, EXPLORE, source_clock.clone());
        let source_start = source_clock.now();
        let source_until = source_start + 12.0;
        let (source_snapshot, source_tracker) = source_sep.separate(&crate::clock::Deadline {
            clock: source_clock.clone(),
            at: source_until,
        });
        let source_after = free_return_public(
            &model,
            &proposed_public,
            &JLayout::from_snapshot(&source_snapshot),
            "sheet-2",
        );
        let source_report = validate(&job, &source_after).unwrap();
        eprintln!(
            "JOINT_REPAIR_SOURCE_WITNESS {}",
            serde_json::json!({"job":job,"before":before,"proposal":proposed_public,
            "after":source_after,"loss":source_tracker.total_loss(),"started":source_start,"until":source_until,
            "finished":source_clock.now(),"work":source_clock.counts(),"valid":source_report.valid})
        );
        assert!(source_tracker.total_loss() > 0.0 && !source_report.valid);
        let mut joint = Separator::new(seed, 0, EXPLORE, clock.clone());
        joint.pin(blocker_index(&model));
        joint.region = Rect::try_new(0.0, 0.0, strip.width(shape), strip.height()).ok();
        assert!(joint.tracker.total_loss() > 0.0);
        let joint_start = clock.now();
        let until = joint_start + 12.0;
        let (snapshot, tracker) = joint.separate(&crate::clock::Deadline {
            clock: clock.clone(),
            at: until,
        });
        let mut after_sheets = frozen.to_vec();
        after_sheets.extend(
            strip
                .split(&JLayout::from_snapshot(&snapshot), shape.sheets)
                .unwrap(),
        );
        let after = model.to_layout(&after_sheets);
        let report = validate(&job, &after).unwrap();
        eprintln!(
            "JOINT_REPAIR_WITNESS {}",
            serde_json::json!({"job":job,"before":before,"proposal":proposed_public,
            "authored_feasible":authored,"after":after,"loss":tracker.total_loss(),"started":joint_start,
            "until":until,"finished":clock.now(),"work":clock.counts(),"valid":report.valid,"metrics":report.metrics,
            "source_only_loss":source_tracker.total_loss(),"fixed_prefix_sheets":1,"seed":0})
        );
        assert_eq!(
            tracker.total_loss(),
            0.0,
            "Joint repair must find an actual valid rearrangement"
        );
        assert!(report.valid && clock.now() < until);
        assert!(
            report.metrics.unwrap().material_area < before_report.metrics.unwrap().material_area,
            "A valid return to the original arrangement does not prove useful joint repair"
        );
        assert_eq!(
            after
                .placements
                .iter()
                .find(|p| p.part_id == "extra")
                .unwrap()
                .sheet_id,
            "sheet-1"
        );
        assert_eq!(
            serde_json::to_value(
                before
                    .placements
                    .iter()
                    .filter(|p| p.sheet_id == "sheet-0")
                    .collect::<Vec<_>>()
            )
            .unwrap(),
            serde_json::to_value(
                after
                    .placements
                    .iter()
                    .filter(|p| p.sheet_id == "sheet-0")
                    .collect::<Vec<_>>()
            )
            .unwrap()
        );
    }
    // END joint-repair witness
}
