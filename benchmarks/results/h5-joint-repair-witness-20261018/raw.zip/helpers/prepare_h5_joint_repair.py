"""Author one joint-window repair witness without changing runtime policy."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, shutil, subprocess, sys
root=Path(__file__).resolve().parents[1]
old=root/'output/h5-assignment-bridge-probe-20261018'
out=root/'output/h5-joint-repair-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(root/'benchmarks/results/h5-assignment-bridge-pilot-20261018/verification.json')['all_original_archives_verified']
assert load(root/'benchmarks/results/h5-assignment-bridge-pilot-20261018/interpretation.json')['failed_material_pairs']==4
assert load(old/'build.json')['all_checks_passed']
out.mkdir()
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
original=path.read_text(encoding='utf-8')
tests=r'''
    // BEGIN joint-repair witness: original runtime, authored overlapping proposal
    #[test]
    fn joint_repair_existing_separator_can_change_the_source_assignment() {
        let (mut job,mut layout)=fixture();
        job.name="Joint window permits an extra source member to migrate".into();
        job.parts=vec![rectangle("prefix",96.0,94.0),rectangle("filler",20.0,94.0),
            rectangle("return",60.0,85.0),rectangle("incoming",30.0,94.0),rectangle("extra",40.0,50.0)];
        layout.sheets=(0..3).map(|i|Sheet{id:format!("sheet-{i}"),stock_id:"stock".into()}).collect();
        layout.placements=[("prefix",0,[2.0,2.0]),("filler",1,[78.0,2.0]),("return",1,[2.0,2.0]),
            ("incoming",2,[2.0,2.0]),("extra",2,[34.0,2.0])].into_iter().map(|(id,sheet,translation)|Placement {
                part_id:id.into(),copy_index:0,sheet_id:format!("sheet-{sheet}"),
                transform:RigidTransform{translation,..Default::default()}}).collect();
        assert!(validate(&job,&layout).unwrap().valid);
        let mut proposed=layout.clone();
        for p in &mut proposed.placements {
            if p.part_id=="incoming" {p.sheet_id="sheet-1".into();}
            if p.part_id=="return" {p.sheet_id="sheet-2".into();}
        }
        assert!(!validate(&job,&proposed).unwrap().valid);
        // Two unrotated rectangles can avoid overlap only by separation along
        // at least one axis. Even the full usable sheet is too small on both
        // axes for this source inventory; its cropped prefix is no larger.
        let usable=100.0-2.0*job.edge_clearance;
        assert!(60.0+40.0+job.clearance>usable);
        assert!(85.0+50.0+job.clearance>usable);
        let mut authored=proposed.clone();
        authored.placements.iter_mut().find(|p|p.part_id=="extra").unwrap().sheet_id="sheet-1".into();
        let hand_report=validate(&job,&authored).unwrap();assert!(hand_report.valid);
        let model=Model::new(&job).unwrap();
        let sheets=model.sheets_of(&layout).unwrap();
        let proposed_sheets=model.sheets_of(&proposed).unwrap();
        let clock=Clock::new(Timing::Work,60.0);
        let strip=Strip{model:&model,gap:2.0,clock:clock.clone(),containers:Default::default()};
        let (frozen,window)=sheets.split_at(1);
        let mut shape=Shape{sheets:window.len(),last:model.full_width};
        let initial=strip.layout(window,shape).unwrap();shape.last=strip.fit_last(&initial,shape);
        let mut before_sheets=frozen.to_vec();before_sheets.extend(strip.split(&initial,shape.sheets).unwrap());
        let before=model.to_layout(&before_sheets);
        let before_report=validate(&job,&before).unwrap();assert!(before_report.valid);
        let seed=strip.layout(&proposed_sheets[1..],shape).unwrap();
        let mut seed_sheets=frozen.to_vec();seed_sheets.extend(strip.split(&seed,shape.sheets).unwrap());
        let proposed_public=model.to_layout(&seed_sheets);
        let mut source=JLayout::new(strip.container(Shape{sheets:1,last:shape.last}).unwrap());
        for p in seed.placed_items().values().filter(|p|!strip.is_blocker(p) && strip.sheet_of(p.shape())==1) {
            source.place_item(p.item(),shift(p.d_transf(),-strip.start(1)));
        }
        assert_eq!(source.placed_items().len(),2);
        let source_clock=Clock::new(Timing::Work,60.0);
        let mut source_sep=Separator::new(source,0,EXPLORE,source_clock.clone());
        let source_start=source_clock.now();let source_until=source_start+12.0;
        let (source_snapshot,source_tracker)=source_sep.separate(&crate::clock::Deadline{clock:source_clock.clone(),at:source_until});
        let source_after=free_return_public(&model,&proposed_public,&JLayout::from_snapshot(&source_snapshot),"sheet-2");
        let source_report=validate(&job,&source_after).unwrap();
        eprintln!("JOINT_REPAIR_SOURCE_WITNESS {}",serde_json::json!({"job":job,"before":before,"proposal":proposed_public,
            "after":source_after,"loss":source_tracker.total_loss(),"started":source_start,"until":source_until,
            "finished":source_clock.now(),"work":source_clock.counts(),"valid":source_report.valid}));
        assert!(source_tracker.total_loss()>0.0 && !source_report.valid);
        let mut joint=Separator::new(seed,0,EXPLORE,clock.clone());
        joint.pin(blocker_index(&model));joint.region=Rect::try_new(0.0,0.0,strip.width(shape),strip.height()).ok();
        assert!(joint.tracker.total_loss()>0.0);
        let joint_start=clock.now();let until=joint_start+12.0;
        let (snapshot,tracker)=joint.separate(&crate::clock::Deadline{clock:clock.clone(),at:until});
        let mut after_sheets=frozen.to_vec();
        after_sheets.extend(strip.split(&JLayout::from_snapshot(&snapshot),shape.sheets).unwrap());
        let after=model.to_layout(&after_sheets);
        let report=validate(&job,&after).unwrap();
        eprintln!("JOINT_REPAIR_WITNESS {}",serde_json::json!({"job":job,"before":before,"proposal":proposed_public,
            "authored_feasible":authored,"after":after,"loss":tracker.total_loss(),"started":joint_start,
            "until":until,"finished":clock.now(),"work":clock.counts(),"valid":report.valid,"metrics":report.metrics,
            "source_only_loss":source_tracker.total_loss(),"fixed_prefix_sheets":1,"seed":0}));
        assert_eq!(tracker.total_loss(),0.0,"Joint repair must find an actual valid rearrangement");
        assert!(report.valid && clock.now()<until);
        assert!(report.metrics.unwrap().material_area<before_report.metrics.unwrap().material_area,
            "A valid return to the original arrangement does not prove useful joint repair");
        assert_eq!(after.placements.iter().find(|p|p.part_id=="extra").unwrap().sheet_id,"sheet-1");
        assert_eq!(serde_json::to_value(before.placements.iter().filter(|p|p.sheet_id=="sheet-0").collect::<Vec<_>>()).unwrap(),
            serde_json::to_value(after.placements.iter().filter(|p|p.sheet_id=="sheet-0").collect::<Vec<_>>()).unwrap());
    }
    // END joint-repair witness
'''
pos=original.rindex('\n}')
path.write_text(original[:pos]+'\n'+tests+original[pos:],encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
current=path.read_text(encoding='utf-8');assert current.startswith(original[:pos])
assert current.split('#[cfg(test)]\nmod tests',1)[0]==original.split('#[cfg(test)]\nmod tests',1)[0]
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),
 'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
 'changed_files':[rel],'production_digest':source_digest(),'target':str(root/'output/h5-joint-repair-target-20261018'),
 'unchanged_prior_tests':156,'initial_new_tests':1,'all_runtime_unchanged':True,'benchmark_searches':0,
 'functional_fixture_seed':0,'functional_work_allowance_per_repair':12.0,
 'claims':'Constructed overlapping proposal, not a proposal selected by the current exchange policy; tests existing separator behavior only. No quality, wall-time or policy integration claim.'}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'prepared':True,'unchanged_prior_tests':156,'new_witness_tests':1,'runtime_unchanged':True}))
