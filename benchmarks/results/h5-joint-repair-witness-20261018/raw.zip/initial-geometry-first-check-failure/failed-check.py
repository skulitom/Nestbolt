"""Audit all saved authored joint-repair outcomes, including invalid proposals."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json, math, shutil, subprocess, sys
from shapely.geometry import Polygon
import shapely
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-repair-probe-20261018'
out=probe/'initial-geometry';out.mkdir()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
checks=load(probe/'initial-witness/checks.json');log_path=probe/'initial-witness/witness.log'
assert digest(log_path)==checks['log_sha256']
lines=log_path.read_text(encoding='utf-8').splitlines()
rows=[json.loads(s.split('JOINT_REPAIR_WITNESS ',1)[1]) for s in lines if 'JOINT_REPAIR_WITNESS ' in s]
sources=[json.loads(s.split('JOINT_REPAIR_SOURCE_WITNESS ',1)[1]) for s in lines if 'JOINT_REPAIR_SOURCE_WITNESS ' in s]
assert len(rows)==len(sources)==1
r=rows[0];source=sources[0]
for k in ['job','before','proposal']:assert r[k]==source[k]
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
assert digest(cli)==expected
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
write(out/'witness.json',r);write(out/'source-witness.json',source);write(out/'job.json',r['job'])
parts={p['id']:p for p in r['job']['parts']};stock=r['job']['stocks'][0]
assert len(r['job']['stocks'])==1 and not stock['outline'] and not stock['defects']
assert r['job']['units']=='mm' and all(p['rotations']=={'kind':'list','degrees':[0.0]} and not p['allow_mirror'] for p in parts.values())
records={};pairs=0;clearance=r['job']['clearance'];e=r['job']['edge_clearance']
saved={'before':r['before'],'proposal':r['proposal'],'authored_feasible':r['authored_feasible'],
       'source_after':source['after'],'after':r['after']}
for kind,layout in saved.items():
 write(out/(kind+'.json'),layout)
 args=[str(cli),'validate','--job',str(out/'job.json'),'--layout',str(out/(kind+'.json'))]
 result=subprocess.run(args,capture_output=True,timeout=60)
 (out/(kind+'-stdout.json')).write_bytes(result.stdout);(out/(kind+'-stderr.log')).write_bytes(result.stderr)
 write(out/(kind+'-command.json'),{'command':args,'exit_code':result.returncode})
 report=json.loads(result.stdout)
 assert Counter(p['part_id'] for p in layout['placements'])==Counter({p['id']:p['quantity'] for p in parts.values()})
 assert len({(p['part_id'],p['copy_index']) for p in layout['placements']})==len(layout['placements'])
 assert [p for p in layout['placements'] if p['sheet_id']=='sheet-0']==[p for p in r['before']['placements'] if p['sheet_id']=='sheet-0']
 assert all(not p['transform']['mirrored'] and abs(p['transform']['rotation_radians'])<=1e-12 for p in layout['placements'])
 if kind in ['before','authored_feasible']:
  assert report['valid'] and result.returncode==0
 elif kind in ['proposal','source_after']:
  assert not report['valid'] and result.returncode!=0
 else:
  assert report['valid']==r['valid'] and (result.returncode==0)==r['valid']
 if report['valid']:
  shapes=[]
  for p in layout['placements']:
   t=p['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians'])
   def tr(v):return(c*v[0]-s*v[1]+t['translation'][0],s*v[0]+c*v[1]+t['translation'][1])
   for g in parts[p['part_id']]['geometry']:
    polygon=Polygon([tr(v) for v in g['outer']]);assert polygon.is_valid
    x0,y0,x1,y1=polygon.bounds;m=stock['margins']
    assert x0+1e-7>=m['left']+e and y0+1e-7>=m['bottom']+e
    assert x1-1e-7<=stock['width']-m['right']-e and y1-1e-7<=stock['height']-m['top']-e
    for sheet,other in shapes:
     if sheet==p['sheet_id']:
      pairs+=1;assert polygon.disjoint(other) and polygon.distance(other)+1e-7>=clearance
    shapes.append((p['sheet_id'],polygon))
 records[kind]={'valid':report['valid'],'metrics':report.get('metrics'),'CLI_exit_code':result.returncode,
                'layout_sha256':digest(out/(kind+'.json'))}
assert not source['valid'] and source['loss']>0 and r['source_only_loss']==source['loss']
def size(part):
 points=parts[part]['geometry'][0]['outer'];return [max(p[i] for p in points)-min(p[i] for p in points) for i in [0,1]]
source_members=[p['part_id'] for p in r['proposal']['placements'] if p['sheet_id']=='sheet-2']
assert set(source_members)=={'return','extra'}
width,height=(sum(size(p)[i] for p in source_members)+clearance for i in [0,1])
m=stock['margins'];usable_width=stock['width']-m['left']-m['right']-2*e;usable_height=stock['height']-m['top']-m['bottom']-2*e
assert width>usable_width and height>usable_height
# Verify exact axis-aligned rectangles: the two-axis argument is not valid for
# arbitrary nonrectangular outlines or extra rotations.
for p in source_members:
 points=parts[p]['geometry'][0]['outer'];w,h=size(p)
 assert points==[[0.0,0.0],[w,0.0],[w,h],[0.0,h]] and not parts[p]['geometry'][0]['holes']
before=records['before']['metrics']['material_area']
hand=records['authored_feasible']['metrics']['material_area'];assert hand<before
actual=records['after']['metrics']['material_area'] if records['after']['valid'] else None
useful=actual is not None and actual<before and r['finished']<r['until'] and r['loss']==0
if checks['witness_passed']:assert useful
old=Path(load(probe/'preparation.json')['old_probe']);rel='crates/core/src/sheets/vstrip/exchange.rs'
previous=(old/'candidate'/rel).read_text(encoding='utf-8');current=(probe/'candidate'/rel).read_text(encoding='utf-8')
assert current.startswith(previous[:previous.rindex('\n}')])
plan=load(probe/'preparation.json');unchanged=0
for arm,files in plan['old_source_files'].items():
 assert {p.relative_to(probe/arm).as_posix() for p in (probe/arm).rglob('*') if p.is_file()}=={p['path'] for p in files}
 for f in files:
  assert digest(old/arm/f['path'])==f['sha256']
  if arm!='candidate' or f['path']!=rel:assert digest(probe/arm/f['path'])==f['sha256'];unchanged+=1
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
record={'all_saved_outcome_checks_passed':True,'actual_useful_joint_repair_observed':useful,
 'public_CLI_checks':len(records),'valid_outputs':sum(x['valid'] for x in records.values()),'filled_outer_pairs':pairs,
 'shapely_version':shapely.__version__,'CLI_sha256':expected,'native_log_sha256':checks['log_sha256'],
 'all_runtime_and_156_prior_test_bodies_unchanged':True,'prior_tests_rerun':False,
 'unchanged_other_source_files_both_arms':unchanged,'production_unchanged':True,'benchmark_searches':0,
 'source_assignment_impossibility':{'members':source_members,'width_sum_with_clearance_mm':width,
     'height_sum_with_clearance_mm':height,'full_sheet_usable_width_mm':usable_width,'full_sheet_usable_height_mm':usable_height,
     'scope':'Exactly these two axis-aligned rectangles on this source sheet. No global job infeasibility claim.'},
 'before_material_mm2':before,'authored_material_mm2':hand,'actual_material_mm2':actual,
 'records':records,'quality_claim':False}
write(out/'checks.json',record);shutil.copyfile(__file__,out/'check.py')
print(json.dumps({k:record[k] for k in ['all_saved_outcome_checks_passed','actual_useful_joint_repair_observed','public_CLI_checks','valid_outputs','filled_outer_pairs','before_material_mm2','authored_material_mm2','actual_material_mm2']}))
