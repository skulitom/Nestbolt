from pathlib import Path
R=Path(__file__).resolve().parent
s=(R/'extract_h5_selected_domain_core.py').read_text(encoding='utf-8')
s=s.replace('output/h5-original-domain-conflicts-20261025','output/h5-convex-domain-conflicts-20261025')
s=s.replace("BASE/'integer-conflict-proof/audit/checks.json'","BASE/'selection-audit/checks.json'")
with (R/'extract_h5_convex_domain_core.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
