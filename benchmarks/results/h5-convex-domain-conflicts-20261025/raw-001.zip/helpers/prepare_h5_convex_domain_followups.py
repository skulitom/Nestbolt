"""Prepare a distinct complete convex-table master and its follow-up checks."""
from pathlib import Path
R=Path(__file__).resolve().parent
OLD="output/h5-original-domain-conflicts-20261025"
NEW="output/h5-convex-domain-conflicts-20261025"
def save(name,s):
    with (R/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for src,dst in [('prepare_h5_domain_conflict_groups.py','prepare_h5_convex_domain_groups.py'),('audit_h5_domain_conflict_groups.py','audit_h5_convex_domain_groups.py')]:
    s=(R/src).read_text(encoding='utf-8');assert OLD in s;save(dst,s.replace(OLD,NEW))
s=(R/'solve_h5_three_region_master.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'"+OLD+"'","OLD=ROOT/'"+OLD+"';BASE=ROOT/'"+NEW+"'")
s=s.replace("NEW=ROOT/'output/h5-three-region-master-20261025';OUT=NEW/'solve'","OUT=BASE/'solve'")
s=s.replace("BASE/'three-cog-certificate/","OLD/'three-cog-certificate/")
s=s.replace('all23,481,818 physical pair exclusions','all independently audited whole-box and whole-convex-domain pair exclusions')
s=s.replace('Add only the independently certified','Retain the independently certified')
s=s.replace('Preserve the complete previously audited necessary master','Build a distinct necessary master using the complete independently audited convex-domain conflict table')
s=s.replace('the proved global three-cog occupancy exclusion','the complete refined pair table and proved global three-cog occupancy exclusion')
save('solve_h5_convex_domain_master.py',s)
s=(R/'audit_h5_three_region_selection.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'"+OLD+"'","OLD=ROOT/'"+OLD+"';BASE=ROOT/'"+NEW+"'")
s=s.replace("NEW=ROOT/'output/h5-three-region-master-20261025';OUT=NEW/'selection-audit'","NEW=BASE;OUT=NEW/'selection-audit'")
s=s.replace("BASE/'three-cog-certificate/","OLD/'three-cog-certificate/")
s=s.replace("BASE/'cores'","OLD/'cores'")
s=s.replace("'all_previous_box_exclusions_satisfied'","'all_previous_box_and_convex_exclusions_satisfied'")
save('audit_h5_convex_domain_selection.py',s)
s=(R/'solve_h5_selected_anchors.py').read_text(encoding='utf-8').replace(OLD,NEW)
save('solve_h5_convex_domain_anchors.py',s)
print('Prepared distinct convex-table grouping, master, selection and anchor helpers; no solver call.')
