"""Create a distinct master incorporating the proved three-region exclusion."""
from pathlib import Path
R=Path(__file__).resolve().parent
def change(s,a,b):
    assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
s=(R/'solve_h5_domain_selection.py').read_text(encoding='utf-8')
s=change(s,'from audit_h5_domain_selection_model import verify','from audit_h5_three_region_master import verify')
s=change(s,"OUT=BASE/'solve'","NEW=ROOT/'output/h5-three-region-master-20261025';OUT=NEW/'solve'")
s=change(s,"assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'groups/audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')",
    "assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'groups/audit/checks.json')['passed'] and load(BASE/'three-cog-certificate/audit/checks.json')['passed'];OUT.mkdir(parents=True);shutil.copyfile(__file__,OUT/'solve.py')\n    certificate=load(BASE/'three-cog-certificate/certificate.json')")
s=change(s,"ROOT/'output/audit_h5_domain_selection_model.py'","ROOT/'output/audit_h5_three_region_master.py',BASE/'three-cog-certificate/certificate.json',BASE/'three-cog-certificate/audit/checks.json',ROOT/'benchmarks/results/h5-original-domain-conflicts-20261025/raw-manifest.json'")
start=s.index("        'method':'");end=s.index("})\n",start)
s=s[:start]+"        'method':'Preserve the complete previously audited necessary master with all9776 domain choices,46 queries, original66 counts, original sheet charges and all23,481,818 physical pair exclusions. Add only the independently certified global three-region occupancy exclusion: for each of the12/2/29-domain groups, an occupied Boolean is exactly whether at least one of all six mandatory moving cogs selects a domain in that group; at least one region must stay unoccupied. This excludes696 impossible region triples for any cog-copy assignment, without removing a whole original or substituting a cog hull. Independently audit every preserved constraint and the three occupancy truth tables before one distinct60-second/eight-worker/seed-zero call. Previous calls remain closed. A feasible master result still needs full original-coordinate feasibility, original polygon checks and native validation.'"+s[end:]
s=change(s,"    mapping={'parts':parts,'groups':details};write(OUT/'mapping.json',mapping);assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb'))",'''    occupancies=[]
    for g in certificate['groups']:
        flag=var(f"region-{g['name']}-occupied",0,1);selectors=[]
        for p in parts:
            if p['part'] not in certificate['applicable_moving_cog_parts']:continue
            q=next(m for m in p['modes'] if m['query']==g['query']);selectors.extend(q['domains'][i] for i in g['domain_rows'])
        linear([(v,1) for v in selectors]+[(flag,-1)],0,cp_model.INT_MAX)
        linear([(v,1) for v in selectors]+[(flag,-6)],cp_model.INT_MIN,0)
        occupancies.append({'name':g['name'],'occupied':flag,'selectors':selectors})
    model.add_bool_or([vs[g['occupied']].Not() for g in occupancies])
    mapping={'parts':parts,'groups':details,'region_occupancies':occupancies};write(OUT/'mapping.json',mapping);assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb'))''')
s=change(s,'verify(actual,spec,queries,census,groups,aux,orders)','verify(actual,spec,queries,census,groups,aux,orders,certificate)')
s=change(s,"'scope':'Complete original-angle/inward-domain/fixed57-source construction only. A feasible domain assignment has no anchor witness yet; a negative is not unrestricted impossibility.'",
    "'scope':'Complete original-angle/inward-domain/fixed57-source construction with the proved global three-cog occupancy exclusion. A feasible domain assignment has no anchor witness yet; a negative is not unrestricted impossibility.'")
with (R/'solve_h5_three_region_master.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared the distinct three-region master and preserved the previous master unchanged.')
