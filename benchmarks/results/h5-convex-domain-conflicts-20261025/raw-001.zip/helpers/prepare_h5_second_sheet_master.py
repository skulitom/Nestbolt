from pathlib import Path
R=Path(__file__).resolve().parent
def save(n,s):
    with (R/n).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'solve_h5_convex_domain_master.py').read_text(encoding='utf-8')
s=s.replace('from audit_h5_three_region_master import verify','from audit_h5_second_sheet_master import verify\nfrom itertools import combinations')
s=s.replace("OUT=BASE/'solve'","NEW=ROOT/'output/h5-second-sheet-capacity-master-20261025';OUT=NEW/'solve';PROOF=BASE/'second-sheet-pair-proofs/audit'")
s=s.replace("    certificate=load(OLD/'three-cog-certificate/certificate.json')","    assert load(PROOF/'checks.json')['passed']\n    pair_exclusions=load(PROOF/'certified-pair-exclusions.json');capacity=load(PROOF/'capacity-certificate.json')\n    certificate=load(OLD/'three-cog-certificate/certificate.json')")
s=s.replace("ROOT/'output/audit_h5_three_region_master.py'","ROOT/'output/audit_h5_second_sheet_master.py',PROOF/'checks.json',PROOF/'certified-pair-exclusions.json',PROOF/'capacity-certificate.json'")
s=s.replace('Independently audit every preserved constraint','Add all32 independently replayed ordered query19 domain-pair exclusions across all15 physical cog pairs (480 clauses), plus the independently proved global at-most-two query19 occupancy bound. All six cogs remain mandatory. These extra constraints apply to the declared fixed-source integer construction. Independently audit every preserved constraint')
needle="    mapping={'parts':parts,'groups':details,'region_occupancies':occupancies};"
insert="""    for i,j in combinations(capacity['applicable_parts'],2):
        a=next(q for q in parts[i]['modes'] if q['query']==19);b=next(q for q in parts[j]['modes'] if q['query']==19)
        for ra,rb in pair_exclusions['domain_row_pairs']:model.add_bool_or([vs[a['domains'][ra]].Not(),vs[b['domains'][rb]].Not()])
    linear([(next(q for q in parts[i]['modes'] if q['query']==19)['active'],1) for i in capacity['applicable_parts']],cp_model.INT_MIN,2)
"""
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
s=s.replace('groups,aux,orders,certificate);','groups,aux,orders,certificate,pair_exclusions,capacity);')
save('solve_h5_second_sheet_master.py',s)
s=(R/'audit_h5_convex_domain_selection.py').read_text(encoding='utf-8').replace("NEW=BASE;OUT=NEW/'selection-audit'","NEW=ROOT/'output/h5-second-sheet-capacity-master-20261025';OUT=NEW/'selection-audit';PROOF=BASE/'second-sheet-pair-proofs/audit'")
s=s.replace("SOURCE/'plan.json',OLD/'three-cog", "SOURCE/'plan.json',PROOF/'checks.json',PROOF/'certified-pair-exclusions.json',PROOF/'capacity-certificate.json',OLD/'three-cog")
needle="    cert=load(OLD/'three-cog-certificate/certificate.json');occupancy=[]"
insert="""    assert load(PROOF/'checks.json')['passed'];cap=load(PROOF/'capacity-certificate.json');ex=load(PROOF/'certified-pair-exclusions.json')
    selected_cogs=[p for p in parts if p['part'] in cap['applicable_parts'] and p['query']==19];assert len(selected_cogs)<=2
    for a,b in combinations(selected_cogs,2):assert [a['domain_row'],b['domain_row']] not in ex['domain_row_pairs']
    write(OUT/'second-sheet-check.json',{'passed':True,'selected_second_sheet_cogs':len(selected_cogs),'capacity':2,'all_exact_pair_exclusions_satisfied':True})
"""
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
save('audit_h5_second_sheet_selection.py',s)
s=(R/'solve_h5_selected_anchors.py').read_text(encoding='utf-8').replace('output/h5-original-domain-conflicts-20261025','output/h5-second-sheet-capacity-master-20261025')
save('solve_h5_second_sheet_anchors.py',s)
print('Prepared distinct second-sheet capacity master and its independent checks; no call.')
