from pathlib import Path
R=Path(__file__).resolve().parent
for src,dst in [('prove_h5_selected_domain_conflict.py','prove_h5_convex_selected_conflict.py'),('audit_h5_selected_domain_proof.py','audit_h5_convex_selected_proof.py')]:
    s=(R/src).read_text(encoding='utf-8').replace('output/h5-original-domain-conflicts-20261025','output/h5-convex-domain-conflicts-20261025')
    with (R/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
