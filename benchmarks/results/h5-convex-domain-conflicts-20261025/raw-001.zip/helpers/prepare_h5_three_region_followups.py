"""Adapt generic selected-domain audits for the distinct new master output."""
from pathlib import Path
R=Path(__file__).resolve().parent
def change(s,a,b):
    assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
s=(R/'audit_h5_selected_original_domains.py').read_text(encoding='utf-8')
s=change(s,"OUT=BASE/'selection-audit'","NEW=ROOT/'output/h5-three-region-master-20261025';OUT=NEW/'selection-audit'")
s=s.replace("BASE/'solve/", "NEW/'solve/")
s=change(s,"inputs=[BASE/n for n in ['plan.json','audit/checks.json','groups/audit/checks.json','solve/plan.json','solve/model-audit.json','solve/result.json','solve/selection.json']]+[SOURCE/'plan.json']",
    "inputs=[(NEW if n.startswith('solve/') else BASE)/n for n in ['plan.json','audit/checks.json','groups/audit/checks.json','solve/plan.json','solve/model-audit.json','solve/result.json','solve/selection.json']]+[SOURCE/'plan.json',BASE/'three-cog-certificate/certificate.json',BASE/'three-cog-certificate/audit/checks.json']")
s=change(s,"    aux=load(ROOT/'output/h5-source-orientation-construction-20261025/propagation.json');areas=",'''    cert=load(BASE/'three-cog-certificate/certificate.json');occupancy=[]
    for g in cert['groups']:
        owners=[p['part'] for p in parts if p['part'] in cert['applicable_moving_cog_parts'] and p['query']==g['query'] and p['domain_row'] in g['domain_rows']]
        occupancy.append({'region':g['name'],'occupied':bool(owners),'parts':owners})
    assert not all(g['occupied'] for g in occupancy);write(OUT/'occupancy-check.json',occupancy)
    aux=load(ROOT/'output/h5-source-orientation-construction-20261025/propagation.json');areas=''')
s=change(s,"'all_previous_box_exclusions_satisfied':True,","'all_previous_box_exclusions_satisfied':True,'certified_three_region_exclusion_satisfied':True,")
with (R/'audit_h5_three_region_selection.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'solve_h5_selected_anchors.py').read_text(encoding='utf-8')
s=change(s,"BASE=ROOT/'output/h5-original-domain-conflicts-20261025'","BASE=ROOT/'output/h5-three-region-master-20261025'")
with (R/'solve_h5_three_region_anchors.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'extract_h5_selected_domain_core.py').read_text(encoding='utf-8')
s=change(s,"BASE=ROOT/'output/h5-original-domain-conflicts-20261025'","BASE=ROOT/'output/h5-three-region-master-20261025'")
s=change(s,"BASE/'integer-conflict-proof/audit/checks.json'","BASE/'selection-audit/checks.json'")
with (R/'extract_h5_three_region_core.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared distinct selection, coordinate, and optional core helpers; no solve.')
