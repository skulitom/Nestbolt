"""One bounded necessary-domain compatibility call, with full independent oracle."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time,traceback,sys
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
from audit_h5_second_sheet_master import verify
from itertools import combinations

ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-original-domain-conflicts-20261025';BASE=ROOT/'output/h5-convex-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';NEW=ROOT/'output/h5-second-sheet-capacity-master-20261025';OUT=NEW/'solve';PROOF=BASE/'second-sheet-pair-proofs/audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'groups/audit/checks.json')['passed'] and load(OLD/'three-cog-certificate/audit/checks.json')['passed'];OUT.mkdir(parents=True);shutil.copyfile(__file__,OUT/'solve.py')
    assert load(PROOF/'checks.json')['passed']
    pair_exclusions=load(PROOF/'certified-pair-exclusions.json');capacity=load(PROOF/'capacity-certificate.json')
    certificate=load(OLD/'three-cog-certificate/certificate.json')
    spec=load(SOURCE/'plan.json');queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']};census=load(BASE/'plan.json')
    groups={c['index']:load(BASE/'groups'/f"{c['index']:03d}.json") for c in census['cases']};aux=load(ROOT/'output/h5-source-orientation-construction-20261025/propagation.json')
    orders=load(SOURCE/'support-construction/atlas.json')['copy_x_order_pairs'];params={'max_time_in_seconds':60,'num_search_workers':8,'random_seed':0,
        'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
    inputs=[BASE/'plan.json',BASE/'audit/checks.json',BASE/'groups/plan.json',BASE/'groups/result.json',BASE/'groups/audit/checks.json',SOURCE/'plan.json',
        SOURCE/'support-construction/atlas.json',ROOT/'output/h5-source-orientation-construction-20261025/propagation.json',ROOT/'output/audit_h5_second_sheet_master.py',PROOF/'checks.json',PROOF/'certified-pair-exclusions.json',PROOF/'capacity-certificate.json',OLD/'three-cog-certificate/certificate.json',OLD/'three-cog-certificate/audit/checks.json',ROOT/'benchmarks/results/h5-original-domain-conflicts-20261025/raw-manifest.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'query_hashes':{str(i):digest(SOURCE/'queries'/f'{i:03d}.json') for i in queries},'group_hashes':{str(i):digest(BASE/'groups'/f'{i:03d}.json') for i in groups},
        'construction_limit_seconds':120,'independent_audit_limit_seconds':120,'parameters':params,'maximum_solver_calls':1,
        'method':'Build a distinct necessary master using the complete independently audited convex-domain conflict table with all9776 domain choices,46 queries, original66 counts, original sheet charges and all independently audited whole-box and whole-convex-domain pair exclusions. Retain the independently certified global three-region occupancy exclusion: for each of the12/2/29-domain groups, an occupied Boolean is exactly whether at least one of all six mandatory moving cogs selects a domain in that group; at least one region must stay unoccupied. This excludes696 impossible region triples for any cog-copy assignment, without removing a whole original or substituting a cog hull. Add all32 independently replayed ordered query19 domain-pair exclusions across all15 physical cog pairs (480 clauses), plus the independently proved global at-most-two query19 occupancy bound. All six cogs remain mandatory. These extra constraints apply to the declared fixed-source integer construction. Independently audit every preserved constraint and the three occupancy truth tables before one distinct60-second/eight-worker/seed-zero call. Previous calls remain closed. A feasible master result still needs full original-coordinate feasibility, original polygon checks and native validation.'})
    start=time.perf_counter();model=cp_model.CpModel();vs=[]
    def var(name,lo,hi):
        v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi):model.add_linear_constraint(sum(vs[i]*coef for i,coef in terms),lo,hi)
    parts=[]
    for pi,item in enumerate(spec['parts']):
        sheet=var(f'part{pi}-sheet',0,1);modes=[];allvars=[]
        for qi in item['queries']:
            active=var(f'part{pi}-query{qi}-active',0,1);ds=[]
            for face in queries[qi]['domains']:
                v=var(f"part{pi}-query{qi}-face{face['index']}",0,1);ds.append(v);allvars.append(v)
            linear([(d,1) for d in ds]+[(active,-1)],0,0);modes.append({'query':qi,'active':active,'domains':ds})
        model.add_exactly_one([vs[m['active']] for m in modes]);linear([(sheet,1)]+[(m['active'],-spec['queries'][m['query']]['sheet']) for m in modes],0,0)
        choice=var(f'part{pi}-choice-index',0,len(allvars)-1);linear([(choice,1)]+[(v,-i) for i,v in enumerate(allvars)],0,0)
        parts.append({'part':pi,'item':item['index'],'family':item['family'],'sheet':sheet,'choice':choice,'modes':modes})
    charges=[aux['part_areas'][p['family']]['lower_units'] for p in parts]
    linear([(p['sheet'],-c) for p,c in zip(parts,charges)],cp_model.INT_MIN,aux['sheet_capacities'][0]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][0]-sum(charges))
    linear([(p['sheet'],c) for p,c in zip(parts,charges)],cp_model.INT_MIN,aux['sheet_capacities'][1]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][1])
    for i,j in orders:linear([(parts[i]['choice'],1),(parts[j]['choice'],-1)],cp_model.INT_MIN,0)
    details=[]
    for pair in census['physical_pair_case_uses']:
        i,j=pair['parts'];a,b=parts[i],parts[j]
        for caseid in pair['cases']:
            row=groups[caseid];case=row['case'];qa=next(m for m in a['modes'] if m['query']==case['query_a']);qb=next(m for m in b['modes'] if m['query']==case['query_b'])
            for group in row['groups']:
                if not group['conflicts_per_a_row']:continue
                da=[qa['domains'][k] for k in group['rows_a']];data=bytes.fromhex(group['forbidden_b_hex'])
                forbidden=[qb['domains'][k] for k in range(case['rows_b']) if data[k//8]&(1<<(7-k%8))]
                assert len(forbidden)==group['conflicts_per_a_row']
                if len(da)==1:flag=da[0]
                else:
                    flag=var(f"pair{i}-{j}-case{caseid}-group{group['group']}",0,1);linear([(v,1) for v in da]+[(flag,-1)],0,0)
                if len(forbidden)==len(qb['domains']):model.add_bool_or([vs[flag].Not(),vs[qb['active']].Not()])
                else:model.add_at_most_one([vs[flag]]+[vs[v] for v in forbidden])
                details.append({'parts':[i,j],'case':caseid,'group':group['group'],'flag':flag})
    occupancies=[]
    for g in certificate['groups']:
        flag=var(f"region-{g['name']}-occupied",0,1);selectors=[]
        for p in parts:
            if p['part'] not in certificate['applicable_moving_cog_parts']:continue
            q=next(m for m in p['modes'] if m['query']==g['query']);selectors.extend(q['domains'][i] for i in g['domain_rows'])
        linear([(v,1) for v in selectors]+[(flag,-1)],0,cp_model.INT_MAX)
        linear([(v,1) for v in selectors]+[(flag,-6)],cp_model.INT_MIN,0)
        occupancies.append({'name':g['name'],'occupied':flag,'selectors':selectors})
    model.add_bool_or([vs[g['occupied']].Not() for g in occupancies])
    for i,j in combinations(capacity['applicable_parts'],2):
        a=next(q for q in parts[i]['modes'] if q['query']==19);b=next(q for q in parts[j]['modes'] if q['query']==19)
        for ra,rb in pair_exclusions['domain_row_pairs']:model.add_bool_or([vs[a['domains'][ra]].Not(),vs[b['domains'][rb]].Not()])
    linear([(next(q for q in parts[i]['modes'] if q['query']==19)['active'],1) for i in capacity['applicable_parts']],cp_model.INT_MIN,2)
    mapping={'parts':parts,'groups':details,'region_occupancies':occupancies};write(OUT/'mapping.json',mapping);assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb'))
    buildtime=time.perf_counter()-start;assert buildtime<120;start=time.perf_counter();actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes())
    expected,stats=verify(actual,spec,queries,census,groups,aux,orders,certificate,pair_exclusions,capacity);assert expected==mapping
    solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');at=time.perf_counter()-start;assert at<120
    write(OUT/'model-audit.json',{'passed':True,'construction_seconds':buildtime,'audit_seconds':at,**stats,'model_sha256':digest(OUT/'model.pb'),
        'parameters_sha256':digest(OUT/'parameters.pbtxt'),'python':sys.version,'ortools':ortools.__version__});print(load(OUT/'model-audit.json'),flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':60,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();code=solver.solve(model);elapsed=time.perf_counter()-start
    feasible=code in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    if feasible:
        selected=[]
        for p in parts:
            modes=[m for m in p['modes'] if solver.value(vs[m['active']])];assert len(modes)==1;m=modes[0]
            ds=[i for i,v in enumerate(m['domains']) if solver.value(vs[v])];assert len(ds)==1;q=spec['queries'][m['query']]
            selected.append({'part':p['part'],'item':p['item'],'family':p['family'],'query':m['query'],'domain_row':ds[0],
                'domain_index':queries[m['query']]['domains'][ds[0]]['index'],'profile':q['profile'],'sheet':q['sheet'],'choice_index':solver.value(vs[p['choice']])})
        write(OUT/'selection.json',{'fixed_items':spec['fixed_items'],'movable_parts':selected,'required_originals':66})
    result={'status':solver.status_name(code),'seconds':elapsed,'solver_calls':1,'has_necessary_domain_candidate':feasible,'response_stats':solver.response_stats(),
        'scope':'Complete original-angle/inward-domain/fixed57-source construction with the complete refined pair table and proved global three-cog occupancy exclusion. A feasible domain assignment has no anchor witness yet; a negative is not unrestricted impossibility.',
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
