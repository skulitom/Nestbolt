"""Bounded assumption-core diagnostic, preserving the complete original model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,shutil,time,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-convex-domain-conflicts-20261025';SRC=BASE/'anchor-solve';OUT=BASE/'domain-core'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(SRC/'model-audit.json')['passed'] and load(SRC/'result.json')['status']=='INFEASIBLE'
    OUT.mkdir();shutil.copyfile(__file__,OUT/'extract.py');mapping=load(SRC/'mapping.json');selected=load(BASE/'solve/selection.json')['movable_parts']
    old=cp_model_pb2.CpModelProto();old.ParseFromString((SRC/'model.pb').read_bytes());params={'max_time_in_seconds':10,'num_search_workers':1,'random_seed':0,
        'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
    inputs=[SRC/n for n in ['model.pb','mapping.json','model-audit.json','result.json']]+[BASE/'solve/selection.json',BASE/'selection-audit/checks.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'construction_and_audit_limit_seconds':120,'maximum_solver_calls':1,'parameters':params,
        'method':'Diagnostic extraction of a sufficient selected-domain assumption core, not a packing retry. Gate each selected domain bound/halfplane by its own assumption selector; gate every original mutual separation piece by both relevant selectors. Unselected parts have free global anchors and no active pair conditions, which is a relaxation used only to explain infeasibility. Retain all original inequalities and every exact bounds-filtering proof from the independently audited coordinate model. Prove the entire transformed protobuf is exactly this conditional relaxation, including all9 initial assumptions, before one10-second/single-worker/seed-zero call. Any returned core is solver-derived and is not an independent mathematical unsatisfiability certificate; a future model may use the verified source-model negative/full tuple, while a smaller core requires its own direct validation. No partial layout, native acceptance or H5 claim.'})
    start=time.perf_counter();direction_parts={}
    for pair in mapping['pairs']:
        for face in pair['faces']:
            for d in face['directions']:assert d not in direction_parts;direction_parts[d]=pair['parts']
    model=cp_model.CpModel();vs=[]
    for i,v in enumerate(old.variables):
        lo,hi=(0,1500000 if i%2==0 else 3000000) if i<18 else tuple(v.domain)
        nv=model.new_int_var(lo,hi,v.name);assert nv.index==i;vs.append(nv)
    assumptions=[]
    for i in range(9):
        v=model.new_bool_var(f'selected-domain-part{i}');assert v.index==len(vs);vs.append(v);assumptions.append(v.index)
    for i in range(18):model.add_linear_constraint(vs[i],old.variables[i].domain[0],old.variables[i].domain[1]).only_enforce_if(vs[assumptions[i//2]])
    selectors=[]
    for c in old.constraints:
        kind=c.WhichOneof('constraint')
        if kind=='linear':
            owners=sorted({i//2 for i in c.linear.vars if i<18});assert len(owners) in [1,2]
            en=list(c.enforcement_literal)+[assumptions[i] for i in owners]
            model.add_linear_constraint(sum(vs[i]*coef for i,coef in zip(c.linear.vars,c.linear.coeffs)),c.linear.domain[0],c.linear.domain[1]).only_enforce_if([vs[i] for i in en])
        else:
            assert kind=='bool_or' and c.bool_or.literals
            owners=direction_parts[c.bool_or.literals[0]];assert all(direction_parts[i]==owners for i in c.bool_or.literals)
            model.add_bool_or([vs[i] for i in c.bool_or.literals]+[vs[assumptions[i]].Not() for i in owners])
        selectors.append(owners)
    model.add_assumptions([vs[i] for i in assumptions]);assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb'))
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());expected=cp_model_pb2.CpModelProto()
    for i,v in enumerate(old.variables):
        target=expected.variables.add();target.CopyFrom(v)
        if i<18:target.domain[:]=[0,1500000 if i%2==0 else 3000000]
    for i in range(9):expected.variables.add(name=f'selected-domain-part{i}',domain=[0,1])
    for i in range(18):
        c=expected.constraints.add();c.enforcement_literal.append(len(old.variables)+i//2);c.linear.vars.append(i);c.linear.coeffs.append(1);c.linear.domain.extend(old.variables[i].domain)
    inward_count=load(SRC/'model-audit.json')['inward_domain_halfplanes'];domain_owners=[]
    for p in mapping['parts']:
        qpath=ROOT/'output/h5-full-original-joint-prepared-20261025/queries'/f"{p['query']:03d}.json";face=load(qpath)['domains'][p['domain_row']]
        domain_owners.extend([[p['part']]]*len(face['halfplanes']))
    source_pairs=[]
    for pair in mapping['pairs']:
        for face in pair['faces']:
            if face['always_separated']:continue
            source_pairs.extend([pair['parts']]*(len(face['directions'])+1))
    owners=domain_owners+source_pairs;assert len(domain_owners)==inward_count and owners==selectors and len(owners)==len(old.constraints)
    for oldc,parts in zip(old.constraints,owners):
        c=expected.constraints.add();c.CopyFrom(oldc)
        if c.WhichOneof('constraint')=='linear':c.enforcement_literal.extend(len(old.variables)+i for i in parts)
        else:c.bool_or.literals.extend(-len(old.variables)-i-1 for i in parts)
    expected.assumptions.extend(range(len(old.variables),len(old.variables)+9));assert expected==actual
    solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');elapsed=time.perf_counter()-start;assert elapsed<120
    write(OUT/'model-audit.json',{'passed':True,'seconds':elapsed,'variables':len(actual.variables),'constraints':len(actual.constraints),'assumptions':9,
        'all_source_constraints_preserved_with_exact_conditional_guards':True,'independent_source_mapping_guard_check':True,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt')})
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':10})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();code=solver.solve(model);seconds=time.perf_counter()-start
    core=[]
    if code==cp_model.INFEASIBLE:
        literals=list(solver.sufficient_assumptions_for_infeasibility());assert literals and len(literals)==len(set(literals)) and set(literals)<=set(assumptions)
        core=sorted(assumptions.index(i) for i in literals);write(OUT/'core.json',{'assumption_literals':literals,'parts':core,'selected_domains':[selected[i] for i in core],
            'solver_derived':True,'independent_core_validation_pending':True})
    result={'status':solver.status_name(code),'seconds':seconds,'solver_calls':1,'core_parts':core,'core_items':[selected[i]['item'] for i in core],
        'core_is_solver_derived':True,'independent_core_validation_pending':bool(core),'response_stats':solver.response_stats(),
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
