"""Exact integer interval proof with explicit selected-domain dependencies."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time,traceback

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-convex-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'integer-conflict-proof'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();selected=load(BASE/'solve/selection.json')['movable_parts'];spec=load(SOURCE/'plan.json')
    inputs=[BASE/'solve/selection.json',BASE/'selection-audit/checks.json',BASE/'anchor-solve/model-audit.json',BASE/'anchor-solve/result.json',SOURCE/'plan.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'proof_limit_seconds':60,'maximum_passes':1000,'maximum_bound_updates':100000,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Independent exact-integer interval proof, not a solver retry. Begin from selected convex-domain/stock bounds and every inward halfplane. For every complete same-sheet full-original forbidden piece, eliminate an outside direction only when its exact interval maximum is below the certified bound. If one direction remains, it becomes a mandatory linear inequality; if none remains, the selected domains conflict. Propagate each mandatory linear inequality using exact floor/ceiling arithmetic, tracking which selected-domain assumptions justify each lower/upper bound. Retain every update and reason. A contradiction gives a verifiable subset of selected domains that cannot coexist; a fixed point/cap is not a proof. No native or packing solve.'})
    bounds=[];deps=[];inward=[];clauses=[]
    for p in selected:
        q=spec['queries'][p['query']];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];f,s=d['coordinate_bounds'],q['anchor_bounds_units1000'];i=p['part']
        bounds.extend([[max(f[0],s[0]),min(f[2],s[2])],[max(f[1],s[1]),min(f[3],s[3])]]);deps.extend([[{i},{i}],[{i},{i}]])
        for n,h in enumerate(d['halfplanes']):inward.append({'part':i,'edge':n,'terms':[[2*i,h['a']],[2*i+1,h['b']]],'bound':h['bound']})
    lookup={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']}
    for a,b in combinations(selected,2):
        if a['sheet']!=b['sheet']:continue
        case=lookup[(a['profile'],b['profile'])];row=load(SOURCE/'mutual'/f'{case:03d}.json');i,j=a['part'],b['part']
        for f in row['faces']:
            edges=[{'terms':[[2*j,h['a']],[2*i,-h['a']],[2*j+1,h['b']],[2*i+1,-h['b']]],'bound':h['bound']} for h in f['outside_halfplanes']]
            clauses.append({'parts':[i,j],'case':case,'face':f['index'],'edges':edges})
    write(OUT/'rules.json',{'initial_bounds':bounds,'inward':inward,'clauses':clauses});events=[];contradiction=None;passes=0
    def extrema(terms,maximum):
        value=0;why=set()
        for v,c in terms:
            if not c:continue
            side=int((c>0)==maximum);value+=c*bounds[v][side];why.update(deps[v][side])
        return value,why
    def enforce(terms,limit,why,reason):
        nonlocal contradiction
        for v,c in terms:
            if not c:continue
            others=[(w,k) for w,k in terms if w!=v];lowest,d=extrema(others,False);rhs=limit-lowest
            side=1 if c>0 else 0;new=rhs//c if c>0 else -((-rhs)//c)
            if (side==1 and new<bounds[v][1]) or (side==0 and new>bounds[v][0]):
                nd=set(why)|d;events.append({'kind':'bound','reason':reason,'variable':v,'side':side,'old':bounds[v][side],'new':new,'dependencies':sorted(nd)})
                bounds[v][side]=new;deps[v][side]=nd
                if bounds[v][0]>bounds[v][1]:
                    contradiction={'kind':'empty_integer_interval','variable':v,'interval':bounds[v].copy(),'core_parts':sorted(deps[v][0]|deps[v][1])};return
    status='CAP'
    for passindex in range(1000):
        if time.perf_counter()-start>=60 or len(events)>=100000:break
        passes+=1;before=len(events)
        for n,r in enumerate(inward):
            enforce(r['terms'],r['bound'],{r['part']},{'kind':'inward','rule':n})
            if contradiction:break
        if contradiction:status='CONTRADICTION';break
        for n,r in enumerate(clauses):
            live=[];why=set(r['parts']);always=False
            for e,h in enumerate(r['edges']):
                low,_=extrema(h['terms'],False)
                if low>=h['bound']:always=True;break
                high,d=extrema(h['terms'],True)
                if high>=h['bound']:live.append(e)
                else:why.update(d)
            if always:continue
            if not live:
                contradiction={'kind':'empty_separation_disjunction','clause':n,'core_parts':sorted(why)};events.append({'kind':'empty_clause','clause':n,'dependencies':sorted(why)});break
            if len(live)==1:
                e=live[0];h=r['edges'][e];enforce([[v,-c] for v,c in h['terms']],-h['bound'],why,{'kind':'unit','clause':n,'edge':e})
                if contradiction:break
        if contradiction:status='CONTRADICTION';break
        if len(events)==before:status='FIXED_POINT';break
    write(OUT/'events.json',events);write(OUT/'final-bounds.json',bounds)
    if contradiction:
        contradiction['selected_domain_core']=[selected[i] for i in contradiction['core_parts']];write(OUT/'contradiction.json',contradiction)
    result={'status':status,'seconds':time.perf_counter()-start,'passes':passes,'bound_updates':sum(e['kind']=='bound' for e in events),'inward_rules':len(inward),
        'complete_forbidden_piece_clauses':len(clauses),'selected_domain_core_parts':contradiction['core_parts'] if contradiction else [],
        'selected_combination_excluded':contradiction is not None,'independent_replay_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
