"""Bounded exact interval proofs for every still-open second-sheet cog pair."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil,traceback
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-convex-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'second-sheet-pair-proofs'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rules_for(rows,domains,query,mutual):
    bounds=[];inward=[]
    for i,row in enumerate(rows):
        d=domains[row];a,b=d['coordinate_bounds'],query['anchor_bounds_units1000']
        bounds.extend([[max(a[0],b[0]),min(a[2],b[2])],[max(a[1],b[1]),min(a[3],b[3])]])
        for h in d['halfplanes']:inward.append({'terms':[[2*i,h['a']],[2*i+1,h['b']]],'bound':h['bound']})
    clauses=[{'face':f['index'],'edges':[{'terms':[[2,h['a']],[0,-h['a']],[3,h['b']],[1,-h['b']]],'bound':h['bound']} for h in f['outside_halfplanes']]} for f in mutual['faces']]
    return {'initial_bounds':bounds,'inward':inward,'clauses':clauses}
def prove(rules,deadline):
    bounds=[b.copy() for b in rules['initial_bounds']];events=[];contradiction=None;passes=0
    def extreme(terms,maximum):return sum(c*bounds[v][int((c>0)==maximum)] for v,c in terms if c)
    def enforce(terms,limit,reason):
        nonlocal contradiction
        for v,c in terms:
            if not c:continue
            rhs=limit-extreme([(w,k) for w,k in terms if w!=v],False);side=int(c>0);new=rhs//c if c>0 else -((-rhs)//c)
            if (side and new<bounds[v][1]) or (not side and new>bounds[v][0]):
                events.append({'kind':'bound','reason':reason,'variable':v,'side':side,'old':bounds[v][side],'new':new});bounds[v][side]=new
                if bounds[v][0]>bounds[v][1]:contradiction={'kind':'empty_interval','variable':v,'interval':bounds[v].copy()};return
    status='CAP'
    for pi in range(1000):
        if time.perf_counter()>=deadline or len(events)>=100000:break
        before=len(events);passes+=1
        for i,h in enumerate(rules['inward']):
            enforce(h['terms'],h['bound'],{'kind':'inward','rule':i})
            if contradiction:break
        if contradiction:status='CONTRADICTION';break
        for i,clause in enumerate(rules['clauses']):
            live=[];always=False
            for e,h in enumerate(clause['edges']):
                if extreme(h['terms'],False)>=h['bound']:always=True;break
                if extreme(h['terms'],True)>=h['bound']:live.append(e)
            if always:continue
            if not live:
                contradiction={'kind':'empty_clause','clause':i};events.append({'kind':'empty_clause','clause':i});break
            if len(live)==1:
                e=live[0];h=clause['edges'][e];enforce([[v,-c] for v,c in h['terms']],-h['bound'],{'kind':'unit','clause':i,'edge':e})
                if contradiction:break
        if contradiction:status='CONTRADICTION';break
        if len(events)==before:status='FIXED_POINT';break
    return {'status':status,'passes':passes,'events':events,'final_bounds':bounds,'contradiction':contradiction}
def main():
    OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();deadline=start+60
    assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'integer-conflict-proof/audit/checks.json')['passed']
    paths=[BASE/'cases/163.json',BASE/'cases/163.bin',BASE/'audit/checks.json',BASE/'integer-conflict-proof/audit/checks.json',SOURCE/'queries/019.json',SOURCE/'mutual/081.json',SOURCE/'plan.json']
    meta=load(paths[0]);bits=paths[1].read_bytes();assert digest(paths[1])==meta['packed_sha256'];domains=load(paths[4])['domains'];mutual=load(paths[5]);spec=load(paths[6]);query=spec['queries'][19]
    assert meta['rows_a']==meta['rows_b']==len(domains)==32 and query['profile']==9 and query['sheet']==1
    pairs=[[i,j] for i in range(32) for j in range(32) if not bits[(i*32+j)//8]&(1<<(7-(i*32+j)%8))];assert len(pairs)==51
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_proof_limit_seconds':60,'maximum_passes_per_pair':1000,'maximum_updates_per_pair':100000,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'query':19,'mutual_case':81,'pairs':pairs,'maximum_solver_calls':0,
        'method':'Check all51 ordered second-sheet cog-domain pairs not excluded by the complete raw-original table. Rebuild both complete inward integer domains and every full-original guarded forbidden-piece disjunction. Exact floor/ceiling interval deductions may certify a contradiction; a fixed point or cap remains unproved. Every event and all pending pairs are retained. Independent replay is required before adding any exclusion. This excludes only the declared constructive integer-domain model with its original fixed source and guards; it is not an unrestricted geometric impossibility claim. All six cog copies remain mandatory.'})
    rows=[];pending=[]
    for i,pair in enumerate(pairs):
        if time.perf_counter()>=deadline:pending=pairs[i:];break
        rules=rules_for(pair,domains,query,mutual);t=time.perf_counter();proof=prove(rules,deadline);proof.update({'domain_rows':pair,'domain_indices':[domains[d]['index'] for d in pair],'seconds':time.perf_counter()-t})
        write(OUT/'cases'/f'{i:03d}.json',proof);rows.append({k:v for k,v in proof.items() if k not in ['events','final_bounds','contradiction']})
        if proof['status']=='CAP':pending=pairs[i+1:];break
    write(OUT/'summary.json',rows);write(OUT/'pending-pairs.json',pending)
    result={'seconds':time.perf_counter()-start,'planned_pairs':51,'completed_pairs':len(rows),'pending_pairs':len(pending),
        'proved_conflicts':sum(r['status']=='CONTRADICTION' for r in rows),'fixed_points':sum(r['status']=='FIXED_POINT' for r in rows),'capped_pairs':sum(r['status']=='CAP' for r in rows),
        'independent_replay_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
