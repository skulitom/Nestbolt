"""Independent replay of all pair proofs and an exact two-cog capacity bound."""
from pathlib import Path
from fractions import Fraction
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil,traceback,math
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-convex-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';PROOF=BASE/'second-sheet-pair-proofs';OUT=PROOF/'audit';OLD=ROOT/'output/h5-original-domain-conflicts-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(PROOF/'plan.json');result=load(PROOF/'result.json');summaries=load(PROOF/'summary.json')
    inputs=[p for p in PROOF.rglob('*') if p.is_file() and OUT not in p.parents]+[OLD/'three-cog-certificate/certificate.json',OLD/'three-cog-certificate/audit/checks.json',SOURCE/'plan.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Rebuild every integer inward inequality and original forbidden-piece disjunction directly from source. Replay every event with rational ceiling/floor and verify each update against the preceding bounds; a unit inference must have exactly one possible separating direction. Independently verify every final contradiction. Fixed points remain non-proofs. Separately prove a global at-most-two bound for query19 using all32 whole domain boxes and the previously exact-rational certified258.082mm raw original no-fit disk: three sorted integer x coordinates have an adjacent gap at most floor(total_width/2); even that gap combined with the maximum full y range is too short to separate two cogs. No solver inference is used for this bound.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    sourceplan=load(SOURCE/'plan.json');q=sourceplan['queries'][19];domains=load(SOURCE/'queries/019.json')['domains'];mutual=load(SOURCE/'mutual/081.json')
    assert q['profile']==9 and q['sheet']==1 and mutual['case']['profile_a']==mutual['case']['profile_b']==9
    data=(BASE/'cases/163.bin').read_bytes();meta=load(BASE/'cases/163.json');assert digest(BASE/'cases/163.bin')==meta['packed_sha256']
    pairs=[[i,j] for i in range(32) for j in range(32) if not data[(i*32+j)//8]&(128>>((i*32+j)%8))];assert pairs==plan['pairs'] and len(pairs)==51
    assert len(summaries)==result['completed_pairs']==51 and not load(PROOF/'pending-pairs.json')
    exclusions=[];events_total=0
    for index,rows in enumerate(pairs):
        assert time.perf_counter()-start<120
        proof=load(PROOF/'cases'/f'{index:03d}.json');assert proof['domain_rows']==rows and proof['domain_indices']==[domains[r]['index'] for r in rows]
        assert summaries[index]=={k:v for k,v in proof.items() if k not in ['events','final_bounds','contradiction']}
        bounds=[];inward=[];clauses=[]
        for part,row in enumerate(rows):
            a=domains[row]['coordinate_bounds'];b=q['anchor_bounds_units1000'];bounds += [[max(a[0],b[0]),min(a[2],b[2])],[max(a[1],b[1]),min(a[3],b[3])]]
            inward += [([(2*part,h['a']),(2*part+1,h['b'])],h['bound']) for h in domains[row]['halfplanes']]
        for face in mutual['faces']:
            clauses.append([([(2,h['a']),(0,-h['a']),(3,h['b']),(1,-h['b'])],h['bound']) for h in face['outside_halfplanes']])
        def limits(terms):
            values=[(c*bounds[v][0],c*bounds[v][1]) for v,c in terms]
            return sum(min(v) for v in values),sum(max(v) for v in values)
        empty=None
        for ei,event in enumerate(proof['events']):
            if event['kind']=='empty_clause':
                assert all(limits(t)[1]<bound for t,bound in clauses[event['clause']]);empty={'kind':'empty_clause','clause':event['clause']};assert ei==len(proof['events'])-1;continue
            reason=event['reason']
            if reason['kind']=='inward':terms,limit=inward[reason['rule']]
            else:
                clause=clauses[reason['clause']];possible=[e for e,(t,b) in enumerate(clause) if limits(t)[1]>=b];assert possible==[reason['edge']]
                t,b=clause[possible[0]];terms=[(v,-c) for v,c in t];limit=-b
            v=event['variable'];c=next(c for w,c in terms if w==v);minimum=limits([(w,k) for w,k in terms if w!=v])[0]
            value=Fraction(limit-minimum,c);side=1 if c>0 else 0;new=math.floor(value) if c>0 else math.ceil(value)
            assert event['side']==side and event['new']==new and event['old']==bounds[v][side]
            assert new<bounds[v][1] if side else new>bounds[v][0]
            bounds[v][side]=new
            if bounds[v][0]>bounds[v][1]:empty={'kind':'empty_interval','variable':v,'interval':bounds[v].copy()};assert ei==len(proof['events'])-1
        assert bounds==proof['final_bounds'];events_total+=len(proof['events'])
        if proof['status']=='CONTRADICTION':assert empty==proof['contradiction'] and empty;exclusions.append(rows)
        else:assert proof['status']=='FIXED_POINT' and empty is None and proof['contradiction'] is None
    assert len(exclusions)==result['proved_conflicts']==32 and len(pairs)-len(exclusions)==result['fixed_points']==19
    cert=load(OLD/'three-cog-certificate/certificate.json');assert load(OLD/'three-cog-certificate/audit/checks.json')['passed']
    assert digest(SOURCE/'mutual/081.json')==cert['raw_no_fit_sha256'];radius=cert['strict_inner_disk_radius_units']
    box=[min(d['coordinate_bounds'][i] for d in domains) if i<2 else max(d['coordinate_bounds'][i] for d in domains) for i in range(4)]
    width,height=box[2]-box[0],box[3]-box[1];gap=width//2;maximum=gap*gap+height*height;required=radius*radius+1;assert maximum<required
    cogs=[p for p in sourceplan['parts'] if p['family']=='cog'];assert len(cogs)==6 and all(p['profiles']==[9] and p['queries']==[18,19] for p in cogs)
    capacity={'query':19,'profile':9,'sheet':1,'whole_all32_domain_box_units1000':box,'width_units':width,'height_units':height,
        'three_centres_force_adjacent_x_gap_at_most_units':gap,'adjacent_pair_maximum_squared_distance_units':maximum,
        'raw_original_required_squared_distance_units':required,'strict_shortfall_units':required-maximum,'maximum_cog_occupancy':2,
        'applicable_parts':[p['part'] for p in cogs],'disk_certificate_sha256':digest(OLD/'three-cog-certificate/certificate.json'),
        'proof':'Order any three integer x coordinates. The two adjacent gaps sum to at most the whole width, so one is at most floor(width/2). Its y gap is no greater than the whole height. The resulting squared distance is strictly below the independently certified original-cog requirement. Therefore at most two of all six cogs may select query19.'}
    write(OUT/'certified-pair-exclusions.json',{'query':19,'domain_row_pairs':exclusions,'scope':'Original fixed-source guarded integer construction; all mandatory cog-copy pairings.'})
    write(OUT/'capacity-certificate.json',capacity)
    checks={'passed':True,'seconds':time.perf_counter()-start,'all51_ordered_pair_traces_replayed':True,'exact_integer_events_verified':events_total,
        'certified_new_ordered_pair_exclusions':len(exclusions),'nonproof_fixed_points_preserved':19,'solver_independent':True,
        'global_second_sheet_cog_capacity':2,'all32_domains_and_all_six_cogs_covered':True,'capacity_strict_squared_distance_shortfall_units':required-maximum,
        'source_radius_previously_independently_verified':True,'no_solver_calls':True,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
