"""Prepare source-conservative row displacement domains for a hybrid full-sheet model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,math,shutil,time
from shapely.geometry import shape,box,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
from h5_source_convex_cells_20261028 import encode,selected_cell
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-transfer43-source-20261028';OUT=ROOT/'output/h5-hybrid43-source-20261028';INTRINSIC=ROOT/'output/h5-oblique24-source-20261028/obstacles/00-00.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'relative').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(OLD/'response-audit/checks.json')['passed'] and load(OLD/'search/result.json')['closed']
assert load(OLD/'compact-source-study/audit/checks.json')['source_control_valid']
inputs=[OLD/n for n in ['plan.json','modes.json','blocks43.json','short12.json','negative.json','negative-source66.json','geometry-audit-verified/plan.json','geometry-audit-verified/checks.json','source-bridge-audit/plan.json','source-bridge-audit/checks.json','row-identity-audit/plan.json','row-identity-audit/checks.json','response-audit/checks.json','search/result.json','compact-source-study/plan.json','compact-source-study/audit/plan.json','compact-source-study/audit/checks.json','compact-source-study/selected-poses.json','compact-source-study/source61.json']]
inputs += [INTRINSIC,ROOT/'output/h5-free23-source-regions-20261028/audit/plan.json',ROOT/'output/h5-free23-source-regions-20261028/audit/checks.json',ROOT/'output/h5_source_convex_cells_20261028.py']
plan=load(OLD/'plan.json');plan.update({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Hybrid full43-block model: preserve audited source modes, stock bounds and all66 identities. Keep row-versus-orthogonal and orthogonal-versus-orthogonal cover separation using three complete rectangle groups, each with one cog row plus every orthogonal part. Replace only row-to-row cover separation with three source-conservative displacement domains. Derive each domain from the union of original single-cog configuration obstacles translated by every cog-pair offset. Add1nm around the saved obstacle to dominate floating offset roundoff. Restrict relative coordinates only by their existing stock bounds. Encode exact Fraction inward halfplanes. Check original-source61 positive control and full66 collision negative control before one fresh60s/90s solve. No old search is restarted.','positive_control':'61 originals:18frames17inserts14cogs on first sheet, exact original short12. Only5brackets absent from control; all43 blocks mandatory in target.','hybrid_collision_groups':[[40,'all-orthogonal'],[41,'all-orthogonal'],[42,'all-orthogonal']],'row_pairs':[[40,41],[40,42],[41,42]],'source_obstacle_extra_buffer_mm':1e-6,'relative_halfplane_coordinate_bounds_um':[1600000,3100000]})
write(OUT/'plan.json',plan)
for name in ['modes.json','blocks43.json','short12.json','negative.json','negative-source66.json']:shutil.copyfile(OLD/name,OUT/name)
shutil.copyfile(OLD/'compact-source-study/selected-poses.json',OUT/'control.json');shutil.copyfile(OLD/'compact-source-study/source61.json',OUT/'control-source61.json')
modes=load(OUT/'modes.json');obstacle=shape(load(INTRINSIC)).buffer(1e-6,quad_segs=16);write(OUT/'expanded-cog-obstacle.json',mapping(obstacle));summaries=[]
def limits(m):
    a,b,c,d=m['source_bounds_mm'];return [math.ceil(6513-a*1000),math.ceil(6513-b*1000),math.floor(1493487-c*1000),math.floor(2993487-d*1000)]
for ai,bi in [(12,12),(12,13)]:
    a,b=modes[ai],modes[bi];key=f"{a['row_size']}-{b['row_size']}";terms=[];shifts=set()
    for u,v in product(a['source_instances'],b['source_instances']):
        raw=[u['translation'][k]-v['translation'][k] for k in [0,1]];shift=[round(w,9) for w in raw];terms.append({'left':u['relative_copy'],'right':v['relative_copy'],'raw_shift_mm':raw,'shift_mm':shift});shifts.add(tuple(shift))
    forbidden=unary_union([translate(obstacle,x,y) for x,y in sorted(shifts)]);aa,bb=limits(a),limits(b);bounds=[bb[0]-aa[2],bb[1]-aa[3],bb[2]-aa[0],bb[3]-aa[1]]
    allowed=box(*(v/1000 for v in bounds)).difference(forbidden);encoded=encode(allowed);encoded.update({'modes':[ai,bi],'relative_bounds_um':bounds,'offset_pairs':terms,'unique_shifts_mm':sorted(shifts),'forbidden_geometry':mapping(forbidden)})
    write(OUT/'relative'/f'{key}.json',encoded);summaries.append({'key':key,'source_pairs':len(terms),'unique_shifts':len(shifts),'cells':len(encoded['cells']),'planes':sum(len(c['halfplanes']) for c in encoded['cells']),'relative_bounds_um':bounds})
controls={p['block']:p for p in load(OUT/'control.json')};checks=[]
for left,right in plan['row_pairs']:
    a,b=controls[left],controls[right];key=f"{modes[a['mode']]['row_size']}-{modes[b['mode']]['row_size']}";d=[b['anchor_um'][k]-a['anchor_um'][k] for k in [0,1]];cell=selected_cell(load(OUT/'relative'/f'{key}.json')['cells'],*d);assert cell is not None
    checks.append({'blocks':[left,right],'key':key,'delta_um':d,'selected_cell':cell})
write(OUT/'control-row-cells.json',checks);write(OUT/'regions-summary.json',summaries)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'region_types':2,'source_pairs_by_type':[25,20],'target_row_source_pairs':65,'positive_control_row_pairs':3,'convex_cells_by_type':[r['cells'] for r in summaries],'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
