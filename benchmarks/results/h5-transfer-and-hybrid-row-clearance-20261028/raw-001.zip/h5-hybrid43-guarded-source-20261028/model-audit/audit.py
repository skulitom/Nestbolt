"""Audit all original and replacement constraints and positive/negative controls."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_transfer43_cp_reader_20261028 import inspect as inspect_old
from h5_hybrid43_cp_reader_20261028 import inspect,violations
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-hybrid43-guarded-source-20261028';OLD=ROOT/'output/h5-transfer43-source-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,BASE/'geometry-audit',MODEL,OLD/'model-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model/model.pb').read_bytes());oldmp=load(OLD/'model/mapping.json');oldcheck,_=inspect_old(old,oldmp,load(OLD/'blocks43.json'),load(OLD/'modes.json'),load(OLD/'control.json'),load(OLD/'negative.json'),load(OLD/'model/partial-hints.json'),load(OLD/'model/partial-control-assignment.json'),load(OLD/'model/negative-assignment.json'));write(OUT/'base-model-recheck.json',oldcheck)
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');sol=load(MODEL/'partial-control-assignment.json');bad=load(MODEL/'negative-assignment.json');built=load(MODEL/'built.json');assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256'];relative={key:load(BASE/'relative'/f'{key}.json') for key in ['5-5','5-4']}
checked,disabled=inspect(p,mp,old,oldmp,load(BASE/'modes.json'),relative,load(BASE/'control.json'),load(BASE/'negative.json'),load(MODEL/'partial-hints.json'),sol,bad)
fail=violations(p,sol);assert fail['failed_constraints']==[{'constraint':ix,'kind':'linear'} for ix in disabled] and fail['cover_collisions']==0;write(OUT/'partial-target-rejections.json',fail)
partial=cp_model_pb2.CpModelProto();partial.CopyFrom(p)
for ix in disabled:partial.constraints[ix].linear.domain[:]=[0,0]
valid=evaluate(partial,sol,0);assert not violations(partial,sol)['failed_constraints'];write(OUT/'partial-control-check.json',valid);(OUT/'partial-control-model.pb').write_bytes(partial.SerializeToString())
for ix in disabled:partial.constraints[ix].linear.domain[:]=[1,1]
assert partial.SerializeToString()==p.SerializeToString()
negative=violations(p,bad);expected={ix for group in mp['collision_groups'] for ix in group['constraints']}|{r['choice'] for r in mp['row_pairs']};assert {r['constraint'] for r in negative['failed_constraints']}==expected and negative['cover_collisions']>0;write(OUT/'negative-target-rejections.json',negative)
# The same61 source poses fail the old model specifically at conservative row covers.
base_sol=sol[:len(old.variables)];base_failure=violations(old,base_sol);base_failed={r['constraint'] for r in base_failure['failed_constraints']};assert base_failure['cover_collisions']==61 and set(disabled)|{oldmp['no_overlap_2d']}<=base_failed and base_failed<=set(disabled)|{oldmp[k] for k in ['no_overlap_2d','x_cumulative','y_cumulative']};write(OUT/'old-model-control61-rejections.json',base_failure)
inputs=[BASE/'plan.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',MODEL/'plan.json',MODEL/'model.pb',MODEL/'mapping.json',MODEL/'partial-hints.json',MODEL/'partial-control-assignment.json',MODEL/'negative-assignment.json',OLD/'model/model.pb',OLD/'model/mapping.json',ROOT/'output/h5_hybrid43_cp_reader_20261028.py',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{**checked,'seconds':time.perf_counter()-start,'control_originals':61,'control_rejected_by_exactly5_mandatory_constraints':True,'partial_model_only5_presence_changes':True,'control_cover_pair_visits':valid['expanded_pairs'],'old_model_false_cover_collisions':61,'negative_rejected_by_all9_cover_constraints_and3_row_choices':True,'negative_cover_collision_visits':negative['cover_collisions'],'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
