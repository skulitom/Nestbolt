"""Exercise wrong-size mode rejection and verify only identical-row symmetry."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from h5_transfer43_source_bridge_20261028 import reconstruct
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-hybrid43-guarded-source-20261028';OUT=BASE/'row-identity-audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();blocks=load(BASE/'blocks43.json');modes=load(BASE/'modes.json');mp=load(BASE/'model/mapping.json');job=load(JOB);short=load(BASE/'short12.json');rowblocks=[i for i,b in enumerate(blocks) if b['family']=='cog-row'];assert [blocks[i]['row_size'] for i in rowblocks]==[5,5,4];rejected=[]
for i in rowblocks:
    right=[m['id'] for m in modes if m['family']=='cog-row' and len(m['source_instances'])==blocks[i]['row_size']];wrong=[m['id'] for m in modes if m['family']=='cog-row' and len(m['source_instances'])!=blocks[i]['row_size']];assert len(right)==len(wrong)==1 and [o['mode'] for o in mp['items'][i]['options']]==right
    for mi in wrong:
        try:reconstruct(job,blocks,modes,[{'block':i,'mode':mi,'anchor_um':[7000,7000]}],short)
        except AssertionError:rejected.append({'block':i,'originals_required':blocks[i]['row_size'],'wrong_mode':mi,'wrong_mode_originals':len(modes[mi]['source_instances'])})
        else:raise AssertionError('wrong-size mode accepted')
roworders=[r for r in mp['orders'] if r['left'] in rowblocks or r['right'] in rowblocks];assert len(roworders)==1 and (roworders[0]['left'],roworders[0]['right'],roworders[0]['axis'])==(rowblocks[0],rowblocks[1],'y')
complete,error=reconstruct(job,blocks,modes,load(BASE/'negative.json'),short);keys={(r['part_id'],r['copy_index']) for r in complete};expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};assert len(complete)==len(keys)==66 and keys==expected and len(rejected)==3
inputs=[JOB,BASE/'plan.json',BASE/'blocks43.json',BASE/'modes.json',BASE/'short12.json',BASE/'negative.json',BASE/'model/mapping.json',BASE/'model-audit/checks.json',ROOT/'output/h5_transfer43_source_bridge_20261028.py'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'wrong_size_modes_rejected':rejected,'only_identical_five_cog_rows_ordered':True,'four_cog_row_has_no_symmetry_order':True,'all66_originals_accounted_once':True,'maximum_transform_offset_error_mm':error,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
