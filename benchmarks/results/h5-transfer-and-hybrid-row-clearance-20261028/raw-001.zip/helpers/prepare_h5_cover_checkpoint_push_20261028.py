"""Prepare a fresh guarded push for two audited cover-model checkpoints."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='608fecf12c287805fddcd8e64b9db7fef4950b70'
source=(ROOT/'output/push_h5_rational_checkpoint_20261028.py').read_text(encoding='utf-8')
changes={
 'output/h5-rational-main-sync-20261028':'output/h5-cover-checkpoints-main-sync-20261028',
 "OLD='571738d8c229781092d8f8a3ebf1b77cef56604a';NEW='75ee537cdd9855c40216eccd5b011817ea91378e'":"OLD='75ee537cdd9855c40216eccd5b011817ea91378e';NEW='608fecf12c287805fddcd8e64b9db7fef4950b70'",
 "['benchmarks/results/h5-rational-source-and-row-covers-20261028']":"['benchmarks/results/h5-joint-sheet-and-union-covers-20261028','benchmarks/results/h5-union-cover-resolution-and-transfer-20261028']",
 '40758320213':'40764537562'
}
for old,new in changes.items():
 assert old in source,old
 source=source.replace(old,new)
with (ROOT/'output/push_h5_cover_checkpoints_20261028.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'head':head,'prior_CI':40764537562,'guard_prepared':True})
