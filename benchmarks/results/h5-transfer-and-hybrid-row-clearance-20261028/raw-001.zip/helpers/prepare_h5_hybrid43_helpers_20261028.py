"""Adapt new unopened hybrid helpers; record provenance and preserve closed originals."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-hybrid43-source-20261028/helper-generation';OUT.mkdir()
digest=lambda p:sha256(p.read_bytes()).hexdigest();rows=[]
names=['audit_h5_transfer43_source_bridge_20261028.py','audit_h5_transfer43_row_identities_20261028.py','check_h5_transfer43_candidate_20261028.py','run_h5_transfer43_model_20261028.py','audit_h5_transfer43_response_20261028.py']
for name in names:
    source=ROOT/'output'/name;target=ROOT/'output'/name.replace('transfer43','hybrid43');text=source.read_text(encoding='utf-8');changes=[('output/h5-transfer43-source-20261028','output/h5-hybrid43-source-20261028')]
    if 'source_bridge' in name:changes.append(('control-source52','control-source61'))
    if name.startswith('run_'):
        changes += [('check_h5_transfer43_candidate_20261028.py','check_h5_hybrid43_candidate_20261028.py'),("BASE/'row-identity-audit']","BASE/'row-identity-audit',BASE/'geometry-audit']"),("inputs=[BASE/'row-identity-audit/plan.json'","inputs=[BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',ROOT/'output/h5_hybrid43_cp_reader_20261028.py',BASE/'row-identity-audit/plan.json'")]
    if 'response_' in name:
        changes += [('from h5_transfer43_cp_reader_20261028 import inspect,violations','from h5_hybrid43_cp_reader_20261028 import inspect,violations'),("BASE/'row-identity-audit']","BASE/'row-identity-audit',BASE/'geometry-audit']"),
        ("model_check,_=inspect(p,mp,load(BASE/'blocks43.json'),load(BASE/'modes.json'),load(BASE/'control.json'),load(BASE/'negative.json'),load(MODEL/'partial-hints.json'),load(MODEL/'partial-control-assignment.json'),load(MODEL/'negative-assignment.json'))", "oldbase=ROOT/'output/h5-transfer43-source-20261028';old=cp_model_pb2.CpModelProto();old.ParseFromString((oldbase/'model/model.pb').read_bytes());model_check,_=inspect(p,mp,old,load(oldbase/'model/mapping.json'),load(BASE/'modes.json'),{k:load(BASE/'relative'/f'{k}.json') for k in ['5-5','5-4']},load(BASE/'control.json'),load(BASE/'negative.json'),load(MODEL/'partial-hints.json'),load(MODEL/'partial-control-assignment.json'),load(MODEL/'negative-assignment.json'))"),
        ("checked['expanded_pairs']==285390","checked['expanded_pairs']==119631"),
        ("'cover_pairs_per_complete_assignment':285390","'cover_pair_visits_per_complete_assignment':119631,'row_pairs_covered_by_source_displacement_constraints':3"),
        ("inputs=[BASE/'row-identity-audit/plan.json'","inputs=[BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',BASE/'row-identity-audit/plan.json'"),('output/h5_transfer43_cp_reader_20261028.py','output/h5_hybrid43_cp_reader_20261028.py')]
    for a,b in changes:
        assert a in text,(name,a);text=text.replace(a,b)
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
    rows.append({'source':source.relative_to(ROOT).as_posix(),'source_sha256':digest(source),'target':target.relative_to(ROOT).as_posix(),'target_sha256':digest(target),'changes':changes})
with (OUT/'generation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(rows,f,indent=2);f.write('\n')
print({'new_helpers':len(rows),'closed_helpers_unchanged':True})
