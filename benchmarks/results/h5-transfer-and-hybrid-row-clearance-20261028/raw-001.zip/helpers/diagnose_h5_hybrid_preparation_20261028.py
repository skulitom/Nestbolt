"""Record actual failed outcomes and locate control rejection without a solver."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time
from shapely.geometry import shape,Point
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-hybrid43-source-20261028';DIRECT=ROOT/'output/h5-hybrid43-direct-source-20261028';OLD=ROOT/'output/h5-transfer43-source-20261028';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
control={p['block']:p for p in load(BASE/'control.json')};records=[]
for left,right in [(40,41),(40,42),(41,42)]:
    key='5-5' if right==41 else '5-4';data=load(BASE/'relative'/f'{key}.json');delta=[control[right]['anchor_um'][k]-control[left]['anchor_um'][k] for k in [0,1]];point=Point(*(v/1000 for v in delta));region=shape(data['domain_geometry']);forbidden=shape(data['forbidden_geometry']);selected=[i for i,c in enumerate(data['cells']) if all(a*delta[0]+b*delta[1]>=c for a,b,c in c['halfplanes'])]
    records.append({'blocks':[left,right],'delta_um':delta,'cells':len(data['cells']),'inside_domain':region.covers(point),'inside_forbidden':forbidden.covers(point),'distance_to_free_region_mm':region.distance(point),'selected_cells':selected})
write(BASE/'failure-diagnosis.json',{'utc':datetime.now(timezone.utc).isoformat(),'closed':True,'preparation_completed_regions':2,'error':'AssertionError: selected_cell is None for the positive control','operator_terminated':False,'stop_guard_refused_because_process_already_finished':True,'control_originals_source_valid':61,'row_checks':records,'solver_calls':0,'native_calls':0,'H5_complete':False})
write(DIRECT/'failure-diagnosis.json',{'utc':datetime.now(timezone.utc).isoformat(),'closed':True,'error':'FileNotFoundError for prior preparation-termination.json','cause':'Dependent preparation was incorrectly started after the termination guard returned failure. The prior process completed naturally with a control assertion failure; no termination receipt exists.','plan_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(records)
