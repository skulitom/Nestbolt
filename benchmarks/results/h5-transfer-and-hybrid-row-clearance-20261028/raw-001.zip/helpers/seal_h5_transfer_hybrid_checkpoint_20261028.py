"""Archive closed43-block trials, exact controls and the guarded main push receipt."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
FIRST=ROOT/'output/h5-transfer43-source-20261028';BASE=ROOT/'output/h5-hybrid43-guarded-source-20261028';PUB=BASE/'publication';NAME='h5-transfer-and-hybrid-row-clearance-20261028';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='608fecf12c287805fddcd8e64b9db7fef4950b70' and not git('diff','HEAD','--name-only')
results=[]
for folder in [FIRST,BASE]:
    for a in ['model-audit','source-bridge-audit','row-identity-audit','response-audit']:assert load(folder/a/'checks.json')['passed']
    r=load(folder/'search/result.json');assert r['closed'] and r['solver_calls']==1 and r['status']=='UNKNOWN' and not r['has_solution'];results.append(r)
assert load(FIRST/'geometry-audit-verified/checks.json')['passed'] and load(BASE/'geometry-audit/checks.json')['passed']
compact=load(FIRST/'compact-source-study/audit/checks.json');assert compact['passed'] and compact['source_control_valid'] and compact['cover_collisions']==61 and compact['only_row_cover_collisions']
prior=load(ROOT/'benchmarks/results/h5-union-cover-resolution-and-transfer-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main==head;jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6;passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];failed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']!='success'];assert not failed
receipt=load(ROOT/'output/h5-cover-checkpoints-main-sync-20261028/receipt.json');assert receipt['new_main']==head and receipt['prior_main_all6_pass'] and receipt['normal_atomic_fast_forward']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [FIRST,BASE,ROOT/'output/h5-hybrid43-source-20261028',ROOT/'output/h5-hybrid43-direct-source-20261028',ROOT/'output/h5-hybrid43-tight-source-20261028',ROOT/'output/h5-hybrid43-direct-helper-generation-20261028',ROOT/'output/h5-hybrid43-tight-helper-generation-20261028',ROOT/'output/h5-hybrid43-guarded-helper-generation-20261028',ROOT/'output/h5-cover-checkpoints-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=set()
for pattern in ['*transfer43*20261028.py','*hybrid43*20261028.py','*compact_transfer*20261028.py']:
    helpers.update((ROOT/'output').glob(pattern))
helpers.update(ROOT/'output'/n for n in ['prepare_h5_cover_checkpoint_push_20261028.py','push_h5_cover_checkpoints_20261028.py','prepare_h5_direct_hybrid_helpers_20261028.py','prepare_h5_tight_hybrid_helpers_20261028.py','prepare_h5_guarded_hybrid_helpers_20261028.py','diagnose_h5_hybrid_preparation_20261028.py','diagnose_h5_tight_obstacle_20261028.py','h5_source_triangle_cells_20261028.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_transfer_hybrid_archive_20261028.py',Path(__file__).name])
for p in helpers:add('helpers/'+p.name,p)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for folder,prefix,ga in [(FIRST,'cover43','geometry-audit-verified'),(BASE,'hybrid43','geometry-audit')]:
    for a,b in [(ga+'/checks.json','geometry-audit.json'),('model-audit/checks.json','model-audit.json'),('source-bridge-audit/checks.json','source-bridge-audit.json'),('row-identity-audit/checks.json','row-identity-audit.json'),('response-audit/checks.json','response-audit.json'),('search/result.json','search-result.json')]:shutil.copyfile(folder/a,OUT/(prefix+'-'+b))
shutil.copyfile(FIRST/'compact-source-study/audit/checks.json',OUT/'compact-source61-audit.json');shutil.copyfile(FIRST/'compact-source-study/source61.json',OUT/'compact-source61.json');shutil.copyfile(BASE/'model-audit/old-model-control61-rejections.json',OUT/'old-cover-control61-rejections.json');shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json');shutil.copyfile(ROOT/'output/h5-cover-checkpoints-main-sync-20261028/receipt.json',OUT/'main-push-receipt.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'main_CI':40771628220,'main_all6_pass':len(passed)==6,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_all6_passes':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':(BASE/'next-step-text.txt').read_text(encoding='utf-8'),'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'closed_packing_sequences':2,'solver_calls':2,'complete_candidates':0,'source_valid66_count':0,'source61_valid':True,'source61_missing_brackets':5,'cover_false_collisions_diagnosed':61,'hybrid_all903_block_pairs_covered':True,'all43_blocks_mandatory_in_both_models':True,'valid64_preserved':True,'remaining_necessary_allocations':444,'actual_or_global_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
