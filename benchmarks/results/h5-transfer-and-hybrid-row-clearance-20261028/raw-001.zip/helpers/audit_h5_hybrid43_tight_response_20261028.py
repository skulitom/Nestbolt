"""Audit the sole closed whole-sheet response and every returned complete assignment."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from h5_hybrid43_cp_reader_20261028 import inspect,violations
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-hybrid43-tight-source-20261028';MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'response-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,MODEL,BASE/'model-audit',BASE/'source-bridge-audit',BASE/'row-identity-audit',BASE/'geometry-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
opened=load(SEARCH/'opened.json')
for n,h in opened['inputs'].items():assert digest(ROOT/n)==h,n
budget=load(SEARCH/'budget.json');process=load(SEARCH/'process.json');result=load(SEARCH/'result.json');ma=load(BASE/'model-audit/checks.json');assert ma['passed'] and process['exit_code']==0 and not process['timeout'] and process['closed'] and process['seconds']<90
assert result['closed'] and result['solver_calls']==budget['maximum_calls']==opened['maximum_calls']==1 and budget['algorithm_seconds']==opened['algorithm_seconds']==60 and budget['shared_seconds']==opened['shared_seconds']==90 and not budget['retry_permitted']
assert digest(SEARCH/'model.pb')==digest(MODEL/'model.pb')==ma['model_sha256']==opened['model_sha256']
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert 0<params.max_time_in_seconds<=60 and params.max_time_in_seconds==opened['parameters']['max_time_in_seconds']==result['allocated_solve_seconds'] and params.num_search_workers==4 and params.random_seed==0 and list(params.ignore_subsolvers)==['fj'] and params.log_search_progress and not params.log_to_stdout
assert {f.name for f,v in params.ListFields()}==set(opened['parameters'])
p=cp_model_pb2.CpModelProto();p.ParseFromString((SEARCH/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');oldbase=ROOT/'output/h5-transfer43-source-20261028';old=cp_model_pb2.CpModelProto();old.ParseFromString((oldbase/'model/model.pb').read_bytes());model_check,_=inspect(p,mp,old,load(oldbase/'model/mapping.json'),load(BASE/'modes.json'),{k:load(BASE/'relative'/f'{k}.json') for k in ['5-5','5-4']},load(BASE/'control.json'),load(BASE/'negative.json'),load(MODEL/'partial-hints.json'),load(MODEL/'partial-control-assignment.json'),load(MODEL/'negative-assignment.json'));write(OUT/'model-recheck.json',model_check)
r=cp_model_pb2.CpSolverResponse();r.ParseFromString((SEARCH/'response.pb').read_bytes());status=cp_model_pb2.CpSolverStatus.Name(r.status);assert status==result['status'] and status in ['UNKNOWN','FEASIBLE','OPTIMAL','INFEASIBLE'] and not p.HasField('objective')
assert r.wall_time==result['solver_wall_seconds'] and r.num_branches==result['returned_response_branches'] and r.num_conflicts==result['returned_response_conflicts'] and bool(r.solution)==result['has_solution']==(status in ['FEASIBLE','OPTIMAL']) and r.objective_value==r.best_objective_bound==0
log=(SEARCH/'solver.log').read_text(encoding='utf-8');assert f'status: {status}' in log;printed=Decimal(re.search(r'^walltime: ([0-9.e+-]+)$',log,re.M).group(1));assert abs(printed-Decimal(str(r.wall_time)))<=Decimal(5).scaleb(printed.as_tuple().exponent-1)+Decimal('1e-12')
assert result['returned_solve_soft_overrun_seconds']==max(0.,result['returned_solve_seconds']-result['allocated_solve_seconds']) and result['algorithm_soft_overrun_seconds']==max(0.,result['algorithm_seconds']-60) and result['returned_solve_seconds']<=result['algorithm_seconds']<=process['seconds']
checks=[];incumbents=[]
def validate(values):
    checked=evaluate(p,values,0);assert checked['expanded_pairs']==119631 and all(values[item['presence']]==1 for item in mp['items']) and not violations(p,values)['failed_constraints'];return checked
for i,path in enumerate(sorted((SEARCH/'incumbents').glob('*.json'))):
    saved=load(path);assert saved['sequence']==i and 0<=saved['solver_wall_seconds']<=r.wall_time;checks.append(validate(saved['values']));incumbents.append(saved)
assert len(incumbents)==result['incumbents_recorded']
if r.solution:
    sol=list(r.solution);assert sol==load(SEARCH/'assignment.json');checks.append(validate(sol));source=load(SEARCH/'source-response/checks.json');assert source['passed'] and source['originals']==66 and source['holes']==90 and source['hole_vertices']==10026 and source['source_valid']==result['source_full66_verified']
else:assert not (SEARCH/'assignment.json').exists() and not (SEARCH/'source-response').exists() and not result['source_full66_verified'] and not checks
write(OUT/'assignment-checks.json',checks)
inputs=[BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',BASE/'row-identity-audit/plan.json',BASE/'row-identity-audit/checks.json',BASE/'plan.json',MODEL/'plan.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json',BASE/'source-bridge-audit/plan.json',BASE/'source-bridge-audit/checks.json',ROOT/'output/h5_hybrid43_cp_reader_20261028.py',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py']+[p for p in SEARCH.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'status':status,'model_variables_reverified':len(p.variables),'model_constraints_reverified':len(p.constraints),'incumbents_verified':len(incumbents),'assignments_verified':len(checks),'all43_blocks_mandatory':True,'movable_first_sheet_originals':54,'fixed_short_originals':12,'cover_components_per_complete_assignment':756,'cover_pair_visits_per_complete_assignment':119631,'row_pairs_covered_by_source_displacement_constraints':3,'has_complete_candidate':bool(r.solution),'source_full66_verified':result['source_full66_verified'],'allocated_solve_seconds':result['allocated_solve_seconds'],'solver_wall_seconds':r.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],'returned_solve_soft_overrun_seconds':result['returned_solve_soft_overrun_seconds'],'algorithm_seconds':result['algorithm_seconds'],'algorithm_soft_overrun_seconds':result['algorithm_soft_overrun_seconds'],'shared_seconds':process['seconds'],'returned_response_branches':r.num_branches,'returned_response_conflicts':r.num_conflicts,'no_closed_search_restarted':True,'actual_or_global_infeasibility_claimed':False,'solver_calls':1,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
