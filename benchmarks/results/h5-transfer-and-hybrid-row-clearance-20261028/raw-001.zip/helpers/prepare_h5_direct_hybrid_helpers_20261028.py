"""Copy unopened hybrid scripts after preserving an interrupted geometry preparation."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-hybrid43-direct-helper-generation-20261028';OUT.mkdir();digest=lambda p:sha256(p.read_bytes()).hexdigest();records=[]
sources=['prepare_h5_hybrid43_regions_20261028.py','audit_h5_hybrid43_regions_20261028.py','build_h5_hybrid43_model_20261028.py','audit_h5_hybrid43_model_20261028.py','audit_h5_hybrid43_source_bridge_20261028.py','audit_h5_hybrid43_row_identities_20261028.py','check_h5_hybrid43_candidate_20261028.py','run_h5_hybrid43_model_20261028.py','audit_h5_hybrid43_response_20261028.py']
for name in sources:
    source=ROOT/'output'/name;target=ROOT/'output'/name.replace('hybrid43','hybrid43_direct');s=source.read_text(encoding='utf-8');changes=[('output/h5-hybrid43-source-20261028','output/h5-hybrid43-direct-source-20261028')]
    if name.startswith('prepare_'):
        changes += [("shape(load(INTRINSIC)).buffer(1e-6,quad_segs=16)","shape(load(INTRINSIC))"),('Add1nm around the saved obstacle to dominate floating offset roundoff.','Use the existing obstacle directly; independently prove every actual pair offset is covered despite rounded construction shifts.'),("'source_obstacle_extra_buffer_mm':1e-6","'source_obstacle_extra_buffer_mm':0.0"),("inputs += [INTRINSIC", "inputs += [ROOT/'output/h5-hybrid43-source-20261028/preparation-termination.json',ROOT/'output/h5-hybrid43-source-20261028/plan.json',INTRINSIC")]
    if name=='audit_h5_hybrid43_regions_20261028.py':changes += [('expanded.equals(intrinsic.buffer(1e-6,quad_segs=16))','expanded.equals(intrinsic)')]
    if name.startswith('run_'):changes += [('check_h5_hybrid43_candidate_20261028.py','check_h5_hybrid43_direct_candidate_20261028.py')]
    for a,b in changes:
        assert a in s,(name,a);s=s.replace(a,b)
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':source.relative_to(ROOT).as_posix(),'source_sha256':digest(source),'target':target.relative_to(ROOT).as_posix(),'target_sha256':digest(target),'changes':changes})
with (OUT/'generation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(records,f,indent=2);f.write('\n')
print({'new_helpers':len(records),'prior_preparation_preserved':True})
