"""Fresh source-clearance preparation following independently diagnosed legacy padding."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-hybrid43-tight-helper-generation-20261028';OUT.mkdir();digest=lambda p:sha256(p.read_bytes()).hexdigest();records=[]
make='''
def make_obstacle():
    import shapely
    from shapely.geometry import Polygon,MultiPoint
    job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='cog');co,si=math.cos(math.radians(7)),math.sin(math.radians(7));g=Polygon([(x*co-y*si,x*si+y*co) for x,y in part['geometry'][0]['outer']]);triangles=list(shapely.constrained_delaunay_triangles(g).geoms);assert unary_union(triangles).equals(g)
    sums=[MultiPoint([(u[0]-v[0],u[1]-v[1]) for u in list(a.exterior.coords)[:-1] for v in list(b.exterior.coords)[:-1]]).convex_hull for a,b in product(triangles,triangles)];raw=unary_union(sums)
    return raw.buffer(plan['required_source_gap_mm']/math.cos(math.pi/64)+1e-7,join_style='mitre',mitre_limit=5)
'''
names=['prepare_h5_hybrid43_regions_20261028.py','audit_h5_hybrid43_regions_20261028.py','build_h5_hybrid43_model_20261028.py','audit_h5_hybrid43_model_20261028.py','audit_h5_hybrid43_source_bridge_20261028.py','audit_h5_hybrid43_row_identities_20261028.py','check_h5_hybrid43_candidate_20261028.py','run_h5_hybrid43_model_20261028.py','audit_h5_hybrid43_response_20261028.py']
for name in names:
    source=ROOT/'output'/name;target=ROOT/'output'/name.replace('hybrid43','hybrid43_tight');s=source.read_text(encoding='utf-8');changes=[('output/h5-hybrid43-source-20261028','output/h5-hybrid43-tight-source-20261028')]
    if name.startswith('prepare_'):
        changes += [('from h5_source_convex_cells_20261028 import encode,selected_cell','from h5_source_triangle_cells_20261028 import encode,selected_cell'),("modes=load(OUT/'modes.json');obstacle=shape(load(INTRINSIC)).buffer(1e-6,quad_segs=16)",make+"\nmodes=load(OUT/'modes.json');obstacle=make_obstacle()"),('Add1nm around the saved obstacle to dominate floating offset roundoff.','Recompute original cog-pair Minkowski geometry and conservatively buffer only the required clearance; independently prove every actual offset. Use complete constrained triangles without greedy merging, preserving the failed padded preparation.'),("'source_obstacle_extra_buffer_mm':1e-6","'source_obstacle_extra_buffer_mm':None,'source_obstacle_method':'mitre buffer at required_gap/cos(pi/64)+1e-7; independent round-buffer containment proof'"),("inputs += [INTRINSIC","inputs += [ROOT/'output/h5-hybrid43-source-20261028/failure-diagnosis.json',ROOT/'output/h5-hybrid43-source-20261028/plan.json',ROOT/'output/h5-hybrid43-direct-source-20261028/failure-diagnosis.json',ROOT/'output/h5_source_triangle_cells_20261028.py',INTRINSIC")]
    if name=='audit_h5_hybrid43_regions_20261028.py':
        changes += [("intrinsic=shape(load(ROOT/'output/h5-oblique24-source-20261028/obstacles/00-00.json'));expanded=shape(load(BASE/'expanded-cog-obstacle.json'));assert intrinsic.covers(required) and expanded.equals(intrinsic.buffer(1e-6,quad_segs=16))","expanded=shape(load(BASE/'expanded-cog-obstacle.json'));assert expanded.covers(required) and expanded.equals(unary_union(hulls).buffer(plan['required_source_gap_mm']/math.cos(math.pi/64)+1e-7,join_style='mitre',mitre_limit=5))")]
    if name.startswith('run_'):changes += [('check_h5_hybrid43_candidate_20261028.py','check_h5_hybrid43_tight_candidate_20261028.py')]
    for a,b in changes:
        assert a in s,(name,a);s=s.replace(a,b)
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':source.relative_to(ROOT).as_posix(),'source_sha256':digest(source),'target':target.relative_to(ROOT).as_posix(),'target_sha256':digest(target),'changes':changes})
with (OUT/'generation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(records,f,indent=2);f.write('\n')
print({'new_helpers':len(records),'closed_preparations_preserved':True})
