"""Replace row-row cover tests by complete conservative source displacement cells."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-hybrid43-tight-source-20261028';OLD=ROOT/'output/h5-transfer43-source-20261028';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();assert load(BASE/'geometry-audit/checks.json')['passed']
for n,h in load(BASE/'geometry-audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h
old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model/model.pb').read_bytes());mapping=load(OLD/'model/mapping.json');modes=load(BASE/'modes.json');items=mapping['items'];control={r['block']:r for r in load(BASE/'control.json')};negative={r['block']:r for r in load(BASE/'negative.json')};groups=[]
for row in [40,41,42]:
    xs=[];ys=[];widths=[];heights=[]
    for item in items:
        if item['source_block']['family']=='cog-row' and item['index']!=row:continue
        for option in item['options']:
            for component,(a,b,c,d) in zip(option['components'],modes[option['mode']]['cover_rectangles_um']):xs.append(component['x_interval']);ys.append(component['y_interval']);widths.append(c-a);heights.append(d-b)
    groups.append({'row':row,'xs':xs,'ys':ys,'widths':widths,'heights':heights})
replaced=[mapping[k] for k in ['no_overlap_2d','x_cumulative','y_cumulative']]
for ix in replaced:old.constraints[ix].Clear()
group=groups[0];old.constraints[replaced[0]].no_overlap_2d.x_intervals.extend(group['xs']);old.constraints[replaced[0]].no_overlap_2d.y_intervals.extend(group['ys'])
for ix,ints,demands,cap in [(replaced[1],group['xs'],group['heights'],2987202),(replaced[2],group['ys'],group['widths'],1487202)]:
    ct=old.constraints[ix].cumulative;ct.intervals.extend(ints);ct.capacity.offset=cap
    for d in demands:ct.demands.add(offset=d)
old.ClearField('solution_hint');model=cp_model.CpModel();assert model.proto.parse_text_format(text_format.MessageToString(old));group['constraints']=replaced
for group in groups[1:]:
    xs=[model.get_interval_var_from_proto_index(i) for i in group['xs']];ys=[model.get_interval_var_from_proto_index(i) for i in group['ys']]
    group['constraints']=[model.add_no_overlap_2d(xs,ys).index,model.add_cumulative(xs,group['heights'],2987202).index,model.add_cumulative(ys,group['widths'],1487202).index]
values={};bad={};hints={}
for item in items:
    i=item['index'];known=control.get(i);values[item['presence']]=int(known is not None);bad[item['presence']]=1;hints[item['presence']]=1
    for axis,j in [('x',0),('y',1)]:
        values[item[axis]]=known['anchor_um'][j] if known else 0;bad[item[axis]]=negative[i]['anchor_um'][j]
        if known:hints[item[axis]]=values[item[axis]]
    for option in item['options']:
        values[option['selector']]=int(known is not None and known['mode']==option['mode']);bad[option['selector']]=int(negative[i]['mode']==option['mode'])
        if known:hints[option['selector']]=values[option['selector']]
pairs=[]
for left,right in [(40,41),(40,42),(41,42)]:
    a,b=items[left],items[right];key=f"{a['source_block']['row_size']}-{b['source_block']['row_size']}";data=load(BASE/'relative'/f'{key}.json');dx=model.get_int_var_from_proto_index(b['x'])-model.get_int_var_from_proto_index(a['x']);dy=model.get_int_var_from_proto_index(b['y'])-model.get_int_var_from_proto_index(a['y']);delta=[control[right]['anchor_um'][j]-control[left]['anchor_um'][j] for j in [0,1]];selected=next(k for k,c in enumerate(data['cells']) if all(aa*delta[0]+bb*delta[1]>=cc for aa,bb,cc in c['halfplanes']));selectors=[];planes=[]
    for k,cell in enumerate(data['cells']):
        s=model.new_bool_var(f'row_pair_{left}_{right}_cell_{k}');selectors.append(s.index);values[s.index]=int(k==selected);bad[s.index]=0;hints[s.index]=values[s.index];indices=[]
        for aa,bb,cc in cell['halfplanes']:
            ct=model.add(aa*dx+bb*dy>=cc);ct.only_enforce_if(s);indices.append(ct.index)
        planes.append(indices)
    choice=model.add(sum(model.get_int_var_from_proto_index(i) for i in selectors)==1)
    pairs.append({'left':left,'right':right,'region':key,'selectors':selectors,'plane_constraints':planes,'choice':choice.index})
for i,v in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(i),v)
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'items':items,'orders':mapping['orders'],'collision_groups':groups,'row_pairs':pairs,'replaced_base_constraints':replaced,'base_variable_count':len(old.variables),'base_constraint_count':len(old.constraints),'control_disabled_mandatory_constraints':[i['mandatory'] for i in items if i['index'] not in control]})
write(OUT/'partial-control-assignment.json',[values[i] for i in range(len(model.proto.variables))]);write(OUT/'negative-assignment.json',[bad[i] for i in range(len(model.proto.variables))]);write(OUT/'partial-hints.json',{str(k):v for k,v in hints.items()})
inputs=[BASE/n for n in ['plan.json','modes.json','blocks43.json','short12.json','control.json','negative.json','geometry-audit/plan.json','geometry-audit/checks.json']]+list((BASE/'relative').glob('*.json'))+[OLD/n for n in ['model/model.pb','model/mapping.json','model-audit/plan.json','model-audit/checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'mandatory_blocks':43,'originals':66,'collision_groups':3,'row_pairs':3,'row_pair_cell_selectors':sum(len(p['selectors']) for p in pairs),'hints':len(hints),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0});print(load(OUT/'built.json'))
