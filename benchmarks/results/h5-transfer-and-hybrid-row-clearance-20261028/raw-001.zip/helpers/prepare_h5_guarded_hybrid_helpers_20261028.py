"""Fresh guarded obstacle variant after preserving an exact-boundary audit failure."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-hybrid43-guarded-helper-generation-20261028';OUT.mkdir();digest=lambda p:sha256(p.read_bytes()).hexdigest();records=[]
names=['prepare_h5_hybrid43_tight_regions_20261028.py','audit_h5_hybrid43_tight_regions_20261028.py','build_h5_hybrid43_tight_model_20261028.py','audit_h5_hybrid43_tight_model_20261028.py','audit_h5_hybrid43_tight_source_bridge_20261028.py','audit_h5_hybrid43_tight_row_identities_20261028.py','check_h5_hybrid43_tight_candidate_20261028.py','run_h5_hybrid43_tight_model_20261028.py','audit_h5_hybrid43_tight_response_20261028.py']
for name in names:
    source=ROOT/'output'/name;target=ROOT/'output'/name.replace('hybrid43_tight','hybrid43_guarded');s=source.read_text(encoding='utf-8');changes=[('output/h5-hybrid43-tight-source-20261028','output/h5-hybrid43-guarded-source-20261028')]
    if name.startswith('prepare_'):
        changes += [("return raw.buffer(plan['required_source_gap_mm']/math.cos(math.pi/64)+1e-7,join_style='mitre'","return raw.buffer(plan['required_source_gap_mm']/math.cos(math.pi/64)+1.1e-6,join_style='mitre'"),("'mitre buffer at required_gap/cos(pi/64)+1e-7; independent round-buffer containment proof'","'mitre buffer at required_gap/cos(pi/64)+1.1e-6; independent round-buffer containment at required_gap/cos(pi/64)+1e-7'"),("inputs += [ROOT/", "inputs += [ROOT/'output/h5-hybrid43-tight-source-20261028/failure-diagnosis.json',ROOT/'output/h5-hybrid43-tight-source-20261028/plan.json',ROOT/")]
    if name.startswith('audit_') and 'regions' in name:
        changes += [("unary_union(hulls).buffer(plan['required_source_gap_mm']/math.cos(math.pi/64)+1e-7,join_style='mitre'","unary_union(hulls).buffer(plan['required_source_gap_mm']/math.cos(math.pi/64)+1.1e-6,join_style='mitre'")]
    if name.startswith('run_'):changes += [('check_h5_hybrid43_tight_candidate_20261028.py','check_h5_hybrid43_guarded_candidate_20261028.py')]
    for a,b in changes:
        assert a in s,(name,a);s=s.replace(a,b)
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':source.relative_to(ROOT).as_posix(),'source_sha256':digest(source),'target':target.relative_to(ROOT).as_posix(),'target_sha256':digest(target),'changes':changes})
with (OUT/'generation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(records,f,indent=2);f.write('\n')
print({'new_helpers':len(records),'closed_preparations_preserved':True})
