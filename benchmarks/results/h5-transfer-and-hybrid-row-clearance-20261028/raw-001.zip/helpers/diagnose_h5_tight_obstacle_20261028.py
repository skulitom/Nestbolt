"""Measure the failed exact containment assertion and test a1nm scalar guard."""
from pathlib import Path
from itertools import product
from datetime import datetime,timezone
import json,math
import shapely
from shapely.geometry import Polygon,MultiPoint,shape,mapping
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-hybrid43-tight-source-20261028';load=lambda p:json.loads(p.read_bytes());job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='cog');co,si=math.cos(math.radians(7)),math.sin(math.radians(7));g=Polygon([(x*co-y*si,x*si+y*co) for x,y in part['geometry'][0]['outer']]);tt=list(shapely.constrained_delaunay_triangles(g).geoms);raw=unary_union([MultiPoint([(u[0]-v[0],u[1]-v[1]) for u in list(a.exterior.coords)[:-1] for v in list(b.exterior.coords)[:-1]]).convex_hull for a,b in product(tt,tt)]);radius=load(BASE/'plan.json')['required_source_gap_mm']/math.cos(math.pi/64)+1e-7;required=raw.buffer(radius,quad_segs=16);saved=shape(load(BASE/'expanded-cog-obstacle.json'));difference=required.difference(saved);guarded=raw.buffer(radius+1e-6,join_style='mitre',mitre_limit=5)
result={'utc':datetime.now(timezone.utc).isoformat(),'preparation_completed':True,'audit_passed':False,'failure':'Saved mitre obstacle did not exactly cover independent round-buffer required geometry.','expected_mitre_geometry_equal':saved.equals(raw.buffer(radius,join_style='mitre',mitre_limit=5)),'required_outside_saved_area_mm2':difference.area,'guarded_mitre_contains_required':guarded.covers(required),'guarded_radius_extra_mm':1e-6,'all_original_clearance_requirements_unchanged':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
for name,value in [('failure-diagnosis.json',result),('required-outside-saved.json',mapping(difference))]:
    with (BASE/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(result)
