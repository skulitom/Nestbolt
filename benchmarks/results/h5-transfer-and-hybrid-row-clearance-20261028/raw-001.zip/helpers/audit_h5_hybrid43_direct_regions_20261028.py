"""Independent source hulls, all pair offsets and conservative halfplane proof."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,shape,box
from shapely.affinity import translate
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-hybrid43-direct-source-20261028';OLD=ROOT/'output/h5-transfer43-source-20261028';OUT=BASE/'geometry-audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
for name in ['modes.json','blocks43.json','short12.json','negative.json','negative-source66.json']:assert (BASE/name).read_bytes()==(OLD/name).read_bytes()
modes=load(BASE/'modes.json');job=load(JOB);cog=next(p for p in job['parts'] if p['id']=='cog');angle=math.radians(7);co,si=math.cos(angle),math.sin(angle);g=Polygon([(x*co-y*si,x*si+y*co) for x,y in cog['geometry'][0]['outer']]);pieces=list(shapely.constrained_delaunay_triangles(g).geoms);assert unary_union(pieces).equals(g) and all(p.equals(p.convex_hull) for p in pieces)
hulls=[MultiPoint([(u[0]-v[0],u[1]-v[1]) for u in list(a.exterior.coords)[:-1] for v in list(b.exterior.coords)[:-1]]).convex_hull for a,b in product(pieces,pieces)]
required=unary_union(hulls).buffer(plan['required_source_gap_mm']/math.cos(math.pi/64)+1e-7,quad_segs=16)
intrinsic=shape(load(ROOT/'output/h5-oblique24-source-20261028/obstacles/00-00.json'));expanded=shape(load(BASE/'expanded-cog-obstacle.json'));assert intrinsic.covers(required) and expanded.equals(intrinsic)
counts={'types':0,'pair_offsets':0,'cells':0,'planes':0};type_checks=[]
for key,ai,bi in [('5-5',12,12),('5-4',12,13)]:
    d=load(BASE/'relative'/f'{key}.json');a,b=modes[ai],modes[bi];assert d['modes']==[ai,bi];actual={}
    for u,v in product(a['source_instances'],b['source_instances']):
        assert u['angle']==v['angle']==angle and not u['mirrored'] and not v['mirrored'];delta=[u['translation'][k]-v['translation'][k] for k in [0,1]];actual[(u['relative_copy'],v['relative_copy'])]=delta
    assert len(d['offset_pairs'])==len(actual)
    forbidden=shape(d['forbidden_geometry']);shifts=set()
    for r in d['offset_pairs']:
        delta=actual.pop((r['left'],r['right']));assert r['raw_shift_mm']==delta and r['shift_mm']==[round(x,9) for x in delta];shifts.add(tuple(r['shift_mm']))
        # Required geometry is translated by the actual source offsets, not the rounded construction offsets.
        assert forbidden.covers(translate(required,*delta));counts['pair_offsets']+=1
    assert not actual and sorted(shifts)==[tuple(v) for v in d['unique_shifts_mm']] and forbidden.equals(unary_union([translate(expanded,*v) for v in shifts]))
    def limits(m):
        x0,y0,x1,y1=m['source_bounds_mm'];return [math.ceil(6513-x0*1000),math.ceil(6513-y0*1000),math.floor(1493487-x1*1000),math.floor(2993487-y1*1000)]
    aa,bb=limits(a),limits(b);bounds=[bb[0]-aa[2],bb[1]-aa[3],bb[2]-aa[0],bb[3]-aa[1]];assert bounds==d['relative_bounds_um'] and max(abs(bounds[0]),abs(bounds[2]))<1600000 and max(abs(bounds[1]),abs(bounds[3]))<3100000
    domain=shape(d['domain_geometry']);assert domain.equals(box(*(v/1000 for v in bounds)).difference(forbidden));polys=[]
    for cell in d['cells']:
        p=shape(cell['geometry']);assert p.is_valid and not p.interiors and p.equals(p.convex_hull);polys.append(p);vv=[tuple(F(str(x)) for x in pt) for pt in list(p.exterior.coords)[:-1]];assert len(vv)==len(cell['halfplanes']) and sum(u[0]*v[1]-u[1]*v[0] for u,v in zip(vv,vv[1:]+vv[:1]))>0
        for (u,v),(aa,bb,cc) in zip(zip(vv,vv[1:]+vv[:1]),cell['halfplanes']):
            nx,ny=u[1]-v[1],v[0]-u[0];norm=max(abs(nx),abs(ny));nx/=norm;ny/=norm;assert all(nx*(w[0]-u[0])+ny*(w[1]-u[1])>=0 for w in vv)
            assert aa==round(nx*10**9) and bb==round(ny*10**9);target=10**12*(nx*u[0]+ny*u[1]);error=abs(aa-10**9*nx)*1600000+abs(bb-10**9*ny)*3100000;assert F(cc)>target+error and F(cc-1)<=target+error+1;counts['planes']+=1
        counts['cells']+=1
    assert unary_union(polys).equals(domain);counts['types']+=1;type_checks.append({'key':key,'offset_pairs':len(d['offset_pairs']),'cells':len(polys),'original_clearance_contained':True})
controls={p['block']:p for p in load(BASE/'control.json')}
for r in load(BASE/'control-row-cells.json'):
    a,b=[controls[k] for k in r['blocks']];delta=[b['anchor_um'][k]-a['anchor_um'][k] for k in [0,1]];assert delta==r['delta_um'];data=load(BASE/'relative'/f"{r['key']}.json");cell=data['cells'][r['selected_cell']];assert all(a*delta[0]+b*delta[1]>=c for a,b,c in cell['halfplanes'])
    assert not any(all(ca*0+cb*0>=cc for ca,cb,cc in c['halfplanes']) for c in data['cells'])
expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};positive=audit(job,load(BASE/'control-source61.json'),plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],expected-{('bracket',i) for i in range(7,12)});negative=audit(job,load(BASE/'negative-source66.json'),plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],expected);assert positive['valid'] and not negative['valid'] and positive['same_sheet_pairs']==1242 and negative['pair_failures']==982
write(OUT/'control-source-audit.json',positive);write(OUT/'negative-source-audit.json',negative);write(OUT/'types.json',type_checks)
inputs=[BASE/'plan.json',BASE/'prepared.json',BASE/'expanded-cog-obstacle.json',BASE/'control-row-cells.json',BASE/'control-source61.json',BASE/'negative-source66.json',JOB,ROOT/'output/h5_legacy64_source_readback.py']+list((BASE/'relative').glob('*.json'))
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'independent_source_triangles':len(pieces),'independent_minkowski_hulls':len(hulls),**counts,'target_row_pairs_covered':65,'all_integer_halfplanes_proved_conservative':True,'all_source_modes_and_identities_preserved':True,'positive_source_originals':61,'positive_source_pairs':1242,'positive_source_collisions':0,'positive_source_stock_failures':0,'negative_full66_collisions':982,'zero_displacement_rejected_for_both_types':True,'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
