"""Prepare the new short12/first54 allocation and legal5/5/4 source-row modes."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,math,shutil
from shapely.geometry import Polygon,mapping
from shapely.ops import unary_union
from h5_outer_cover_geometry_20261028 import square_expand,slab_cover,rectangle_union
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-joint39-slab10-source-20261028';PREFLIGHT=OLD/'short12-transfer-preflight';BASE=ROOT/'output/h5-transfer43-source-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
BASE.mkdir();shutil.copyfile(__file__,BASE/'prepare.py');assert load(OLD/'search/result.json')['closed'] and load(OLD/'response-audit/checks.json')['passed'] and load(PREFLIGHT/'audit/checks.json')['passed'];prior=load(OLD/'plan.json');blocks=load(PREFLIGHT/'first43-blocks.json');short=load(PREFLIGHT/'short12.json');modes=load(OLD/'modes.json');modes[-1]['row_size']=5;job=load(JOB);part=next(p for p in job['parts'] if p['id']=='cog');instances=modes[-1]['source_instances'][:4];sources=[];expanded=[]
for r in instances:
    c,s=math.cos(r['angle']),math.sin(r['angle']);x,y=r['translation'];outer=[(c*a-s*b+x,s*a+c*b+y) for a,b in part['geometry'][0]['outer']];sources.append(Polygon(outer));expanded.append(square_expand(outer,.112))
joined=unary_union(expanded);rects,slabs=slab_cover(joined,10000);covered=rectangle_union(rects);assert covered.covers(joined)
modes.append({'id':len(modes),'family':'cog-row','row_size':4,'source_instances':instances,'source_bounds_mm':list(unary_union(sources).bounds),'cover_rectangles_um':rects});write(BASE/'row4-geometry.json',{'source_union':mapping(unary_union(sources)),'expanded_union':mapping(joined),'cover':mapping(covered),'slabs':slabs})
write(BASE/'modes.json',modes);write(BASE/'blocks43.json',blocks);write(BASE/'short12.json',short)
oldblocks=load(OLD/'blocks39.json');oldcontrol=load(OLD/'control.json');control=[]
for family in ['bracket','frame','insert']:
    poses=sorted([p for p in oldcontrol if oldblocks[p['block']]['family']==family],key=lambda p:tuple(p['anchor_um']));owners=[i for i,b in enumerate(blocks) if b['family']==family]
    for i,p in zip(owners,poses):control.append({'block':i,'mode':p['mode'],'anchor_um':p['anchor_um']})
rowowners=[i for i,b in enumerate(blocks) if b['family']=='cog-row'];rowmodes=[next(m for m in modes if m['family']=='cog-row' and m['row_size']==blocks[i]['row_size']) for i in rowowners];xs=[6700,86700,6700];ys=[2160000];separations=[]
for j in range(1,3):
    lower=[]
    for i in range(j):
        dx=xs[j]-xs[i];needed=max(a[3]-b[1] for a in rowmodes[i]['cover_rectangles_um'] for b in rowmodes[j]['cover_rectangles_um'] if a[0]<b[2]+dx and b[0]+dx<a[2]);lower.append(ys[i]+needed+1);separations.append({'lower_row':i,'upper_row':j,'dx_um':dx,'required_dy_um':needed})
    ys.append(max(lower))
for i,m,x,y in zip(rowowners,rowmodes,xs,ys):control.append({'block':i,'mode':m['id'],'anchor_um':[x,y]})
write(BASE/'control.json',control);write(BASE/'control-row-separations.json',{'rows':rowowners,'x_um':xs,'y_um':ys,'pair_requirements':separations})
def allowed(m,b):return m['family']==b['family'] and (b['family']!='cog-row' or m['row_size']==b['row_size']==len(b['copy_indices']))
negative=[{'block':i,'mode':next(m['id'] for m in modes if allowed(m,b)),'anchor_um':[7000,7000]} for i,b in enumerate(blocks)];write(BASE/'negative.json',negative)
def source_rows(poses):
    rows=list(short)
    for p in poses:
        b=blocks[p['block']];m=modes[p['mode']];assert allowed(m,b);x,y=[v/1000 for v in p['anchor_um']]
        specs=m['source_instances'] if b['family']=='cog-row' else [{'part_id':b['family'],'angle':m['angle'],'mirrored':m['mirrored'],'translation':m['source_translation_offset']}];copies=b['copy_indices'] if b['family']=='cog-row' else [b['copy_index']]
        for r,copy in zip(specs,copies):rows.append({'part_id':r['part_id'],'copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':r['angle'],'mirrored':r['mirrored'],'translation':[x+r['translation'][0],y+r['translation'][1]]}})
    return rows
write(BASE/'control-source52.json',source_rows(control));write(BASE/'negative-source66.json',source_rows(negative))
inputs=[JOB,OLD/'plan.json',OLD/'modes.json',OLD/'blocks39.json',OLD/'control.json',OLD/'response-audit/plan.json',OLD/'response-audit/checks.json',PREFLIGHT/'plan.json',PREFLIGHT/'audit/plan.json',PREFLIGHT/'audit/checks.json',PREFLIGHT/'first43-blocks.json',PREFLIGHT/'short12.json',ROOT/'output/h5_outer_cover_geometry_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
plan={k:prior[k] for k in ['common_line_part_in_hole','source_stock_guard_um','cover_bounds_um','cover_bounds_method','source_stocks','required_source_gap_mm','native_stock_guard_mm','solver_seconds','shared_seconds','workers','random_seed','ignore_subsolvers','maximum_solver_calls','retry_permitted','source_and_native_required_for_full66','H5_complete']}
plan.update({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New actual allocation with original short12 preserved and all54 first-sheet originals movable as43 mandatory blocks. Eighteen frames,five brackets,seventeen inserts and14cogs remain. Cog row sizes5/5/4 have different legal modes, identical phase7 and258.9mm internal pitch,112um square expansion and10mm vertical slabs. Reuse5-cog geometry unchanged; derive new4-cog cover. The two5-cog rows alone may have Y symmetry;4-cog relative order remains unrestricted. All original source/native/material criteria are unchanged. No previous closed trial is restarted.',
    'target_originals':66,'movable_originals':54,'mandatory_blocks':43,'fixed_short_originals':12,'row_sizes':[5,5,4],'mode_subset':'frame0/90;all8 bracket quarter/mirror;insert0/90;fixed source phase7 rows of exact matching size',
    'positive_control':'26 relabelled orthogonal originals plus14 cogs plus short12 =52 originals.14 originals (2brackets12inserts) absent only from the control. The old core is never fixed in the target model.',
    'negative_control':'All43 blocks at anchor7000,7000um with legal matching modes, all66 original identities and legal stock positions. Collisions must be rejected.',
    'algorithm_seconds':60,'old_hull_height_certificate_applies':False,'source_identity_count_must_match_row_mode':True,'different_row_sizes_not_symmetry_equivalent':True})
write(BASE/'plan.json',plan);write(BASE/'prepared.json',{'modes':len(modes),'row5_components':len(modes[-2]['cover_rectangles_um']),'row4_components':len(rects),'mandatory_blocks':43,'movable_originals':54,'fixed_short_originals':12,'target_originals':66,'control_blocks':len(control),'control_originals':52,'control_missing_originals':14,'control_row_anchors_um':list(zip(xs,ys)),'solver_calls':0,'H5_complete':False});print(load(BASE/'prepared.json'))
