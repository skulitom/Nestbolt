"""One deterministic original-source61 control diagnoses row-cover false collisions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon
from h5_transfer43_source_bridge_20261028 import reconstruct
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-transfer43-source-20261028';OUT=BASE/'compact-source-study';SOURCE=ROOT/'output/h5-oblique64-source-20261028/source64.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'study.py');started=time.perf_counter();assert load(BASE/'search/result.json')['closed'] and load(BASE/'response-audit/checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');blocks=load(BASE/'blocks43.json');plan=load(BASE/'plan.json')
inputs=[JOB,SOURCE,BASE/'plan.json',BASE/'modes.json',BASE/'blocks43.json',BASE/'short12.json',BASE/'response-audit/checks.json',BASE/'search/result.json',ROOT/'output/h5_transfer43_source_bridge_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'One deterministic geometry-only diagnostic. Reuse the18-frame11-insert core from preserved source64, relabelling identical families to the new allocation. Set source cog rows5/5/4 at bboxX97925/177925/97925um, bboxY2107875/2354875/2601875um (247mm row separation). Put the other6 inserts in a horizontal row atY2882050um and X6525+j*180225um. Every54-first-sheet original remains mandatory in the actual goal; this61-part control omits only5 brackets. Validate the actual source geometry and classify every cover collision by owner pair. No optimizer, model mutation or solver call. A valid source control may still be rejected by conservative row-to-row covers; this is the hypothesis being checked.','control_originals':61,'missing_originals':[{'family':'bracket','copy_index':i} for i in range(7,12)],'row_x_um':[97925,177925,97925],'row_y_um':[2107875,2354875,2601875],'packing_solver_calls':0})
core=[r for r in load(SOURCE) if r['sheet_id']=='sheet-0' and (r['part_id']=='frame' or r['part_id']=='insert' and 5<=r['copy_index']<=15)];assert len(core)==29 and sum(r['part_id']=='frame' for r in core)==18
byfamily={'frame':[],'insert':[]};core_checks=[]
for r in core:
    t=r['transform'];family=r['part_id'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation'];g=Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in parts[family]['geometry'][0]['outer']]);anchor=[round(g.bounds[k]*1000) for k in [0,1]];q=round(a/(math.pi/2))%2;m=next(m for m in modes if m['family']==family and m['quarter']==q and not m['mirrored']);assert max(abs(anchor[k]/1000-g.bounds[k]) for k in [0,1])<1e-9
    byfamily[family].append({'mode':m['id'],'anchor_um':anchor});core_checks.append({'original_key':[family,r['copy_index']],'new_mode':m['id'],'anchor_um':anchor})
insert_mode=next(m['id'] for m in modes if m['family']=='insert' and m['quarter']==0)
byfamily['insert'] += [{'mode':insert_mode,'anchor_um':[6525+j*180225,2882050]} for j in range(6)]
poses=[]
for family in ['frame','insert']:
    candidates=sorted(byfamily[family],key=lambda p:(p['anchor_um'][0],p['anchor_um'][1],p['mode']));owners=[i for i,b in enumerate(blocks) if b['family']==family];assert len(candidates)==len(owners)
    poses.extend({'block':i,**p} for i,p in zip(owners,candidates))
for i,x,y in zip([i for i,b in enumerate(blocks) if b['family']=='cog-row'],[97925,177925,97925],[2107875,2354875,2601875]):
    mode=next(m['id'] for m in modes if m['family']=='cog-row' and m['row_size']==blocks[i]['row_size']);poses.append({'block':i,'mode':mode,'anchor_um':[x,y]})
rows,error=reconstruct(job,blocks,modes,poses,load(BASE/'short12.json'));expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}-{('bracket',i) for i in range(7,12)};checked=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],expected);assert len(rows)==61
write(OUT/'selected-poses.json',poses);write(OUT/'source61.json',rows);write(OUT/'source61-audit.json',checked);write(OUT/'core-pose-bindings.json',core_checks)
rectangles=[]
for p in poses:
    x,y=p['anchor_um'];rectangles.extend({'block':p['block'],'rectangle':[a+x,b+y,c+x,d+y]} for a,b,c,d in modes[p['mode']]['cover_rectangles_um'])
collisions=[]
for a,b in combinations(rectangles,2):
    p,q=a['rectangle'],b['rectangle']
    if not(p[2]<=q[0] or q[2]<=p[0] or p[3]<=q[1] or q[3]<=p[1]):collisions.append({'blocks':[a['block'],b['block']],'rectangles':[p,q],'both_rows':all(blocks[i]['family']=='cog-row' for i in [a['block'],b['block']])})
write(OUT/'cover-collisions.json',collisions);result={'seconds':time.perf_counter()-started,'source_originals':61,'missing_originals':5,'source_valid':checked['valid'],'source_pair_failures':checked['pair_failures'],'source_stock_failures':checked['stock_failures'],'source_pairs':checked['same_sheet_pairs'],'source_holes':checked['cutouts'],'source_hole_vertices':checked['hole_vertices'],'minimum_source_gap_mm':checked['minimum_pair_gap_mm'],'minimum_extra_stock_mm':checked['minimum_extra_stock_mm'],'cover_components':len(rectangles),'cover_pairs':len(rectangles)*(len(rectangles)-1)//2,'cover_collisions':len(collisions),'all_cover_collisions_between_rows':all(r['both_rows'] for r in collisions),'cover_collision_owner_pairs':sorted(set(tuple(r['blocks']) for r in collisions)),'maximum_transform_offset_error_mm':error,'all66_target_originals_still_required':True,'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'result.json',result);print(result)
