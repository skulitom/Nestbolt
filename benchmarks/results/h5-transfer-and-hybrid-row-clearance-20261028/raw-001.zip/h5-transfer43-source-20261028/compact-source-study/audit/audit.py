"""Independent saved-source/cover comparison for the61-part diagnostic."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-transfer43-source-20261028';STUDY=BASE/'compact-source-study';OUT=STUDY/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for n,h in load(STUDY/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');plan=load(BASE/'plan.json');rows=load(STUDY/'source61.json');blocks=load(BASE/'blocks43.json');modes=load(BASE/'modes.json');poses=load(STUDY/'selected-poses.json');expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}-{('bracket',i) for i in range(7,12)}
r=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],expected);assert r==load(STUDY/'source61-audit.json') and len(rows)==61;assert [p for p in rows if p['sheet_id']=='sheet-1']==load(BASE/'short12.json')
rects=[]
for p in poses:
    b=blocks[p['block']];m=modes[p['mode']];x,y=p['anchor_um'];assert b['family']==m['family'] and (b['family']!='cog-row' or b['row_size']==m['row_size']==len(b['copy_indices'])==len(m['source_instances']));specs=m['source_instances'] if b['family']=='cog-row' else [{'part_id':b['family'],'angle':m['angle'],'mirrored':m['mirrored'],'translation':m['source_translation_offset']}];copies=b['copy_indices'] if b['family']=='cog-row' else [b['copy_index']]
    for s,copy in zip(specs,copies):
        actual=next(v for v in rows if v['part_id']==s['part_id'] and v['copy_index']==copy);assert actual['sheet_id']=='sheet-0' and actual['transform']['rotation_radians']==s['angle'] and actual['transform']['mirrored']==s['mirrored'] and max(abs(a-b) for a,b in zip(actual['transform']['translation'],[x/1000+s['translation'][0],y/1000+s['translation'][1]]))<1e-9
    rects.extend((p['block'],[a+x,b+y,c+x,d+y]) for a,b,c,d in m['cover_rectangles_um'])
collisions=[];cross_other=0
for (ai,a),(bi,b) in combinations(rects,2):
    if min(a[2],b[2])>max(a[0],b[0]) and min(a[3],b[3])>max(a[1],b[1]):
        both=blocks[ai]['family']==blocks[bi]['family']=='cog-row';collisions.append({'blocks':[ai,bi],'rectangles':[a,b],'both_rows':both});cross_other+=not both
assert collisions==load(STUDY/'cover-collisions.json');saved=load(STUDY/'result.json');assert saved['source_valid']==r['valid'] and saved['cover_collisions']==len(collisions) and saved['all_cover_collisions_between_rows']==(cross_other==0)
for family in ['frame','insert']:
    group=[p for p in poses if blocks[p['block']]['family']==family];assert [p['anchor_um'][0] for p in group]==sorted(p['anchor_um'][0] for p in group)
rowposes=[p for p in poses if blocks[p['block']]['family']=='cog-row'];assert [p['anchor_um'] for p in rowposes]==[[97925,2107875],[177925,2354875],[97925,2601875]]
inputs=[STUDY/n for n in ['plan.json','selected-poses.json','source61.json','source61-audit.json','core-pose-bindings.json','cover-collisions.json','result.json']];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});result={'passed':True,'seconds':time.perf_counter()-started,'source_control_valid':r['valid'],'source_originals':61,'missing_originals':5,'source_pairs':r['same_sheet_pairs'],'source_holes':r['cutouts'],'source_hole_vertices':r['hole_vertices'],'minimum_source_gap_mm':r['minimum_pair_gap_mm'],'minimum_extra_stock_mm':r['minimum_extra_stock_mm'],'cover_components':len(rects),'cover_pairs':len(rects)*(len(rects)-1)//2,'cover_collisions':len(collisions),'row_to_other_cover_collisions':cross_other,'only_row_cover_collisions':cross_other==0 and bool(collisions),'all66_originals_still_mandatory':True,'new_full66_layout':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
