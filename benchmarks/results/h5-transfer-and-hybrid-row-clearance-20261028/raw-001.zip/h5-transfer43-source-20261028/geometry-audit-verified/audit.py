"""Original-source and exact cover audit for differently sized cog rows."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import combinations
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,box,shape
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-transfer43-source-20261028';OUT=BASE/'geometry-audit-verified';OLD=ROOT/'output/h5-joint39-slab10-source-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');oldmodes=load(OLD/'modes.json');blocks=load(BASE/'blocks43.json');short=load(BASE/'short12.json');assert modes[:12]==oldmodes[:12]
m5=dict(modes[12]);assert m5.pop('row_size')==5 and m5==oldmodes[12];assert modes[13]['source_instances']==modes[12]['source_instances'][:4]
assert len(modes)==14 and Counter(m['family'] for m in modes)=={'frame':2,'bracket':8,'insert':2,'cog-row':2}
keys=[(r['part_id'],r['copy_index']) for r in short]
for b in blocks:keys.extend([('cog',i) for i in b['copy_indices']] if b['family']=='cog-row' else [(b['family'],b['copy_index'])])
assert len(keys)==len(set(keys))==66 and set(keys)=={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])} and short==load(OLD/'short12-transfer-preflight/short12.json')
radius=plan['required_source_gap_mm']/2/math.cos(math.pi/64)+1e-7;mode_checks=[];pairs=0;triangle_hulls=0
for m in modes:
    rects=m['cover_rectangles_um'];cover=unary_union([box(a/1000,b/1000,c/1000,d/1000) for a,b,c,d in rects]);sources=[];instances=m['source_instances'] if m['family']=='cog-row' else [{'part_id':m['family'],'angle':m['angle'],'mirrored':m['mirrored'],'translation':m['source_translation_offset']}]
    if m['family']=='cog-row':assert len(instances)==m['row_size'] in [4,5]
    for r in instances:
        p=parts[r['part_id']];c,s=math.cos(r['angle']),math.sin(r['angle']);sign=-1 if r['mirrored'] else 1;x,y=r['translation'];g=Polygon([(sign*a*c-b*s+x,sign*a*s+b*c+y) for a,b in p['geometry'][0]['outer']]);assert cover.covers(g.buffer(radius,quad_segs=16));sources.append(g)
        if m['family']=='cog-row':
            tris=list(shapely.constrained_delaunay_triangles(g).geoms);assert unary_union(tris).equals(g)
            for t in tris:
                hull=MultiPoint([(a+dx,b+dy) for a,b in list(t.exterior.coords)[:-1] for dx in [-.112,.112] for dy in [-.112,.112]]).convex_hull;assert cover.covers(hull);triangle_hulls+=1
    source=unary_union(sources);assert max(abs(a-b) for a,b in zip(source.bounds,m['source_bounds_mm']))<1e-9
    for a,b in combinations(rects,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];pairs+=1
    internal=min((a.distance(b) for a,b in combinations(sources,2)),default=None)
    if internal is not None:assert internal>=plan['required_source_gap_mm']
    for axis in [0,1]:
        low=math.ceil(6513-m['source_bounds_mm'][axis]*1000);high=math.floor([1493487,2993487][axis]-m['source_bounds_mm'][axis+2]*1000);assert low+min(r[axis] for r in rects)>=6399 and high+max(r[axis+2] for r in rects)<=[1493601,2993601][axis]
    mode_checks.append({'mode':m['id'],'family':m['family'],'source_originals':len(sources),'cover_components':len(rects),'minimum_internal_source_gap_mm':internal,'clearance_coverage_and_stock_envelope_valid':True})
write(OUT/'mode-checks.json',mode_checks);cases=[]
for filename,valid,count in [('control-source52',True,52),('negative-source66',False,66)]:
    rows=load(BASE/(filename+'.json'));r=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows]);write(OUT/(filename+'.json'),r);assert r['valid']==valid and len(rows)==count and r['stock_failures']==0;cases.append({'name':filename,'originals':count,'source_pairs':r['same_sheet_pairs'],'collisions':r['pair_failures'],'holes':r['cutouts'],'hole_vertices':r['hole_vertices']})
control=load(BASE/'control.json');rectangles=[]
for p in control:
    b=blocks[p['block']];m=modes[p['mode']];assert m['family']==b['family'] and (b['family']!='cog-row' or m['row_size']==b['row_size']==len(b['copy_indices']));x,y=p['anchor_um'];rectangles.extend([[a+x,b+y,c+x,d+y] for a,b,c,d in m['cover_rectangles_um']])
for a,b in combinations(rectangles,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
proof=load(BASE/'control-row-separations.json');rowposes=[p for p in control if blocks[p['block']]['family']=='cog-row'];assert [p['anchor_um'][0] for p in rowposes]==proof['x_um'] and [p['anchor_um'][1] for p in rowposes]==proof['y_um']
for r in proof['pair_requirements']:
    a=rowposes[r['lower_row']];b=rowposes[r['upper_row']];dx=b['anchor_um'][0]-a['anchor_um'][0];need=max(x[3]-y[1] for x in modes[a['mode']]['cover_rectangles_um'] for y in modes[b['mode']]['cover_rectangles_um'] if max(x[0],y[0]+dx)<min(x[2],y[2]+dx));assert need==r['required_dy_um'] and b['anchor_um'][1]-a['anchor_um'][1]>need
def legal(m,b):return m['family']==b['family'] and (b['family']!='cog-row' or len(m['source_instances'])==b['row_size']==len(b['copy_indices']))
areas=[];components=[];options=0
for b in blocks:
    ms=[m for m in modes if legal(m,b)];assert ms;aa=[sum((c-a)*(d-bb) for a,bb,c,d in m['cover_rectangles_um']) for m in ms];assert min(aa)==max(aa);areas.append(aa[0]);components.append(len(ms[0]['cover_rectangles_um']));options+=len(ms)
area=sum(areas);assert area<1487202*2987202;active=sum(components);control_components=len(rectangles)
write(OUT/'necessary-area.json',{'cover_area_um2':area,'cover_envelope_area_um2':1487202*2987202,'slack_um2':1487202*2987202-area,'no_feasibility_claim':True})
inputs=[BASE/n for n in ['plan.json','modes.json','blocks43.json','short12.json','row4-geometry.json','control.json','control-source52.json','control-row-separations.json','negative.json','negative-source66.json']]+[OLD/'modes.json',ROOT/'output/h5_legacy64_source_readback.py'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'passed':True,'seconds':time.perf_counter()-started,'modes_verified':len(modes),'row_triangle_square_hulls':triangle_hulls,'same_owner_rectangle_pairs':pairs,'all66_originals_accounted_once':True,'movable_originals':54,'mandatory_blocks':43,'fixed_short_originals':12,'legal_mode_options':options,'row5_geometry_unchanged':True,'row4_mode_distinct':True,'control_originals':52,'control_blocks':len(control),'control_missing_originals':14,'control_missing_blocks':14,'control_cover_components':control_components,'control_cover_pairs':control_components*(control_components-1)//2,'complete_cover_components':active,'complete_cover_pairs':active*(active-1)//2,'source_cases':cases,'cover_bounds_um':plan['cover_bounds_um'],'x_capacity_um':2987202,'y_capacity_um':1487202,'necessary_area_slack_mm2':(1487202*2987202-area)/1e6,'old_hull_section_certificate_not_used':True,'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
