"""One complete source-only initializer for39moving original parts."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,time,math,shutil
import numpy as np
from h5_hard_cell_compound_modes_20261107 import canonical_library,family_classes,physical_key
from h5_movable_roof_model_20261107 import compile_model,Objective,owner_shapes,pair_energy,source_rows
from h5_six_unturned_readback_20261107 import verify
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-six-unturned-source-20261107';OUT=ROOT/'output/h5-six-unturned-model-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');source=load(SOURCE/'library.json');checked=load(SOURCE/'audit/checks.json')
assert checked['passed'] and checked['library_sha256']==digest(SOURCE/'library.json')
inputs=[Path(__file__),JOB]+[ROOT/'output'/n for n in ['h5_hard_cell_compound_modes_20261107.py','h5_movable_roof_model_20261107.py','h5_six_unturned_readback_20261107.py','h5_hard_cell_vector_model_20261107.py','h5_vector_boundary_gradient_20261107.py','h5_mixed_direct_pose_20261107.py','h5_direct_pose_model_20261107.py','h5_legacy64_source_readback.py']]+[SOURCE/n for n in ['plan.json','library.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'One fresh-source initializer for a joint six-unturned-frame case,39movers/93parameters/741pairs. All six frame seeds are unturned, distinct as a physical orientation multiset from all three closed six-upper-frame calls; this is not a continuous-coordinate restart. The fresh source constructor recomputes every geometric quantity from the original JOB and frozen normal metrics. Canonicalize only exact filled-outline aliases with identical effective hard rectangles. Preserve frame quarter-turn modes and all six original holes. Reproject the21 unoptimized source seeds only if common alias bounds require nanometre cuts, using a matching legal angle and at most0.0001mm displacement. Initialize six frames and15cogs first, then greedily place6brackets and12inserts on every certified compound mode9x9grid, ranked by actual original-plus-clearance overlap thenmode,Y,X. Preserve all8262trial scores and choices. No fixed-roof optimizer result or previous companion initializer consumed. All39centers and15cogangles remain free. Sourcecheck complete66 and stock; no native or optimizer call.','grid_fractions':[i/8 for i in range(9)],'candidate_cap':10000,'complete_prior_preparation_seconds':checked['complete_preparation_seconds'],'preparation_internal_target_seconds':20,'preparation_process_cap_seconds':25,'algorithm_seconds':60,'shared_seconds':90,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
lib,groups=canonical_library(source);classes=family_classes(lib)
assert classes['frame']==[0,1,0,1] and len(set(classes['bracket']))==9 and classes['insert']==[0,1,0,1] and classes['cog']==[0]
write(OUT/'library.json',lib);write(OUT/'compound-domain-groups.json',groups);write(OUT/'compound-classes.json',classes)
values=np.zeros(lib['continuous_parameters']);modes=[0]*len(lib['identities']);placed=[];seed_records=[]
for seed in lib['source_moving_seed']:
    i=seed['owner'];family=seed['identity'][0];theta=seed['angle_radians'];eligible=[o for o in lib['family_modes'][family] if family=='cog' or (not o['mirrored'] and abs(math.remainder(o['rotation_radians']-theta,math.tau))<1e-12)];choices=[]
    for option in eligible:
        point=[min(hi,max(lo,seed['center'][k])) for k,(lo,hi) in enumerate(option['center_bounds_mm'])];choices.append((sum((a-b)**2 for a,b in zip(point,seed['center'])),option['mode'],point))
    squared,mi,point=min(choices);assert squared<.0001**2;modes[i]=mi;values[2*i:2*i+2]=point
    if family=='cog':values[lib['angle_coordinate_start']+lib['angle_owners'].index(i)]=theta*lib['angle_scale_mm']
    placed.append(owner_shapes(lib,family,mi,point,theta));seed_records.append({'owner':i,'identity':seed['identity'],'source_center':seed['center'],'center':point,'mode':mi,'angle_radians':theta,'projection_distance_mm':math.sqrt(squared)})
assert len(placed)==21;write(OUT/'canonical-seed-projections.json',seed_records)
candidates={}
for family in ['bracket','insert']:
    candidates[family]=[]
    for option in lib['family_modes'][family]:
        bb=option['center_bounds_mm'];points={(bb[0][0]+xi/8*(bb[0][1]-bb[0][0]),bb[1][0]+yi/8*(bb[1][1]-bb[1][0])) for xi,yi in product(range(9),repeat=2)}
        candidates[family].append({'mode':option['mode'],'centers':[list(p) for p in sorted(points,key=lambda p:(p[1],p[0]))]})
write(OUT/'compound-candidates.json',candidates);records=[];count=0
for i,(family,identity) in enumerate(lib['identities']):
    if family not in ['bracket','insert']:continue
    trials=[]
    for option in candidates[family]:
        for point in option['centers']:
            score=pair_energy(owner_shapes(lib,family,option['mode'],point),placed);trials.append({'mode':option['mode'],'center':point,'score_mm2':score});count+=1
    chosen=min(trials,key=lambda r:(r['score_mm2'],r['mode'],r['center'][1],r['center'][0]));modes[i]=chosen['mode'];values[2*i:2*i+2]=chosen['center'];placed.append(owner_shapes(lib,family,modes[i],chosen['center']));records.append({'owner':i,'identity':[family,identity],'candidates':trials,'selected':chosen});assert time.perf_counter()-started<20
assert count==8262 and len(placed)==39 and modes[:6]==[0]*6
write(OUT/'initializer-trials.json',records);model=compile_model(lib,modes,values);assert verify(model,lib,modes,values)
write(OUT/'initial-mode-values.json',{'modes':modes,'values':values.tolist(),'physical_key':list(physical_key(lib,classes,modes))});write(OUT/'model.json',model)
rows=source_rows(model,values);check=audit(load(JOB),rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));assert check['stock_failures']==0
write(OUT/'seed-source66.json',rows);write(OUT/'seed-source-checks.json',check);value,g,details=Objective(model).evaluate(values,True);write(OUT/'initial-objective.json',{'energy_mm2':value,'gradient':g.tolist(),**details})
assert time.perf_counter()-started<20
checks={'passed':True,'seconds':time.perf_counter()-started,'candidate_trials':count,'source_owner_compound_options':sum(len(lib['family_modes'][f]) for f,_ in lib['identities']),'physical_owner_compound_options':sum(len(set(classes[f])) for f,_ in lib['identities']),'moving_originals':39,'continuous_angles':15,'parameters':93,'moving_pairs':741,'maximum_canonical_seed_projection_nanometres':max(s['projection_distance_mm'] for s in seed_records)*1e6,'initial_objective_mm2':value,'initial_original_overlap_mm2':details['original_overlap_area_mm2'],'source_pair_failures':check['pair_failures'],'source_stock_failures':check['stock_failures'],'source_valid66':check['valid'],'complete_prior_preparation_seconds':checked['complete_preparation_seconds'],'library_sha256':digest(OUT/'library.json'),'model_sha256':digest(OUT/'model.json'),'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
