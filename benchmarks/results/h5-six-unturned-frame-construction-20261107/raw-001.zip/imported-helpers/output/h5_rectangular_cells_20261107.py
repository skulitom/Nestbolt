"""Exact conservative rectangle arrangements, in nanometres (1e-6 mm)."""
from fractions import Fraction as F
import math
UNIT=10**6
def lower(v):return F(math.floor(F(v)*UNIT),UNIT)
def upper(v):return F(math.ceil(F(v)*UNIT),UNIT)
def serial(rect):return [str(v) for v in rect]
def merged_free_cells(root,forbidden):
    xs=sorted({root[0],root[2]}|{v for r in forbidden for v in [r[0],r[2]] if root[0]<v<root[2]});ys=sorted({root[1],root[3]}|{v for r in forbidden for v in [r[1],r[3]] if root[1]<v<root[3]});runs=[];atomic=[]
    for y0,y1 in zip(ys,ys[1:]):
        opened=None
        for x0,x1 in zip(xs,xs[1:]):
            x,y=(x0+x1)/2,(y0+y1)/2;free=not any(a<x<c and b<y<d for a,b,c,d in forbidden);atomic.append({'bounds':serial([x0,y0,x1,y1]),'retained':free})
            if free and opened is None:opened=x0
            if opened is not None and (not free or x1==root[2]):runs.append([opened,y0,x0 if not free else x1,y1]);opened=None
    merged=[]
    for r in runs:
        old=next((a for a in merged if a[0]==r[0] and a[2]==r[2] and a[3]==r[1]),None)
        if old is not None:old[3]=r[3]
        else:merged.append(r.copy())
    return sorted(merged,key=lambda r:(r[1],r[0],r[3],r[2])),atomic
