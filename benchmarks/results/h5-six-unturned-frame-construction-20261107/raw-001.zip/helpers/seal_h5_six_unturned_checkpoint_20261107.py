"""Seal fresh joint-orientation source construction, its closed call and audits."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-six-unturned-frame-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-six-unturned-model-20261107';F=BASE/'response-audit';D=ROOT/'output/h5-six-unturned-source-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-four-row-necessary-cover-exclusion-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==1 and front['source_pair_failures']==58",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-four-row-necessary-main-sync-20261107']+[ROOT/'output'/f'h5-six-unturned-{s}-process-20261107' for s in ['source','source-audit','initializer','model-audit','response-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*six_unturned*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_six_unturned_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
copies=[(D/'plan.json','fresh-source-plan.json'),(D/'benchmark-target.json','benchmark-target.json'),(D/'audit/checks.json','source-audit.json'),(D/'closed-orientation-comparison.json','orientation-comparison.json'),(D/'source48-control.json','source48-control.json'),(D/'source48-checks.json','source48-checks.json'),(BASE/'plan.json','initializer-plan.json'),(BASE/'audit/checks.json','model-audit.json'),(BASE/'audit/derivative-controls.json','derivative-controls.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(BASE/'search/plan.json','closed-search-plan.json'),(BASE/'search/result.json','closed-search-result.json'),(BASE/'search/process.json','closed-process.json'),(BASE/'search/closed-orientation-comparison.json','closed-physical-vector.json'),(F/'checks.json','response-audit.json'),(F/'round-00-collision-details.json','source-failures.json'),(BASE/'frame-constraint-diagnostic/checks.json','frame-constraints.json'),(BASE/'frame-constraint-diagnostic/records.json','frame-constraint-records.json'),(ROOT/'output/h5-four-row-necessary-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for stage in ['source','source-audit','initializer','model-audit','response-audit']:copies.append((ROOT/'output'/f'h5-six-unturned-{stage}-process-20261107/process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
runtime={n:r['sha256'] for n,r in load(BASE/'audit/tool-provenance.json')['tool_files'].items()}
for n,h in runtime.items():assert n.startswith('.cache/') and digest(ROOT/n)==h
write(OUT/'runtime-bindings.json',runtime)
sa=load(OUT/'source-audit.json');ma=load(OUT/'model-audit.json');frames=load(OUT/'frame-constraints.json');receipt=load(OUT/'prior-main-push-receipt.json')
ci=json.loads(subprocess.check_output(['gh','run','view','42402787576','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']==receipt['new_main']=='a45826d315434c357fa855da0be08162eabf94f3';write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'checks.json',{**front,**archive,'passed':True,'external_evidence_references':len(external),'source_bindings':len(bindings),'response_audit_source_bindings':front['source_bindings'],'pinned_runtime_files':len(runtime)})
write(OUT/'next-step.json',{'status':'joint_orientation_call_closed_invalid','finding':'The new all-six-unturned frame class is structurally distinct from the earlier four-turned/two-unturned calls. Fresh source/model audits pass, but its sole bounded continuous call fails58 source pairs. Nine failures involve movable frames; the other49 do not. Four frame centers move less than0.149mm, while two move30.899mm and34.195mm. The candidate is not globally stationary or a proof of infeasibility.','proposal':'Before another continuous call, audit the complete seven orientation-count classes of six identical quarter-turn frame rectangles. Map every historically searched class and its exact full mode/domain/objective scope, keeping failed searches distinct from exclusions. Investigate a source-derived arrangement for an untested joint class, with structural space/capacity checks and a valid partial control before building any new complete model. Do not use this closed optimized point as a new seed or resume its bounded pipeline.','constraints':['Every previous closed call and mathematical key stays closed. This additional93-parameter physical vector is now closed. Different copy labels, continuous coordinates or angles do not make a new problem.','The fresh source pipeline recomputed geometry from original JOB and frozen normal acceptance metrics; its complete1.5307265999726951s source process and2.9147848000284284s initializer total4.4455114000011235s. Older failures and their original cumulative preparation charges remain unchanged.','The exact fixed48 four-row exclusion remains valid for that fixed core only. Four earlier arrangements and440 whole-job allocation candidates remain unresolved.','Full66 source/native/material validity, product integration, UI/CLI/MCP parity and original H5 jobs/two-kerf matrix remain required. H2 retains its original denominator and the22 reserved vectors remain unopened.'],'optimizer_calls_open':0,'source_valid66':False,'any_allocation_excluded':False,'H5_complete':False})
report=f'''# Six-unturned-frame construction — 2026-11-07

One new joint frame-orientation case completes its bounded search but remains
invalid: **58 original-source pairs fail**, with **zero stock failures**.
All preparation, model and response audits pass. This call is closed; it does
not prove an allocation impossible or improve the preserved valid64 result.
H2/H5 remain open at **60% completed milestone weight**.

[The orientation comparison]({NAME}/orientation-comparison.json) distinguishes
six unturned movable frames from the earlier three calls, which all used four
turned and two unturned frames. Identical-copy relabelling cannot equate these
orientation multisets. The previous finite single-owner pipeline is not resumed.
Only twelve base frames and fifteen short-sheet originals remain fixed; all
**39 moving centers and 15 cog angles** are free: **93 parameters and 741 pairs**.

[Fresh construction]({NAME}/fresh-source-plan.json) recomputes every numeric
geometry input from the original job and [unchanged normal-mode acceptance
metrics]({NAME}/benchmark-target.json). It reads no cached family geometry,
clearance contour, source placement, initializer or optimized vector. The old
optimizer-opened records supply only the closed orientation comparison.
Historical failed outputs and their original preparation charges are preserved.
This independently executable construction measures its complete work rather
than inheriting numeric outputs from those pipelines.

[Independent source audit]({NAME}/source-audit.json) verifies **25 original convex
pieces, 9,360 exact clearance supports, 17 mode arrangements, 44 atomic cells,
27 whole-cell supports and 80 distinct family corner controls**, bound to all
141 owner/mode options. Original holes and all 66 identities are retained.
The all-angle cog radius and every domain protect the fixed source and stock.
The [48-part control]({NAME}/source48-control.json) passes
[original-source checks]({NAME}/source48-checks.json). Six brackets and twelve
inserts remain unplaced at that stage; it is not a full layout.

[Initializer preparation]({NAME}/initializer-plan.json) scores all **8,262 declared
source-grid trials**, retaining every choice. [Complete model readback]({NAME}/model-audit.json)
checks **141 owner/mode bindings and full scores, 103 dynamic vectors, 126 scalar
gradient terms, 372 finite-difference samples, 114 mode-equivalence controls,
three descent controls and eleven deliberate corruptions**. The
[derivative]({NAME}/derivative-controls.json) and
[negative]({NAME}/negative-controls.json) controls pass.
The complete initial state fails 28 source pairs, with all stock checks passing.

[The frozen search]({NAME}/closed-search-plan.json) makes exactly **one** L-BFGS-B
call for the distinct [physical vector]({NAME}/closed-physical-vector.json).
There are no discrete neighbor trials, retries, weight changes or clock resets.
The original-plus-clearance overlap objective falls from **{ma['initial_objective_mm2']:.6f}**
to **{front['best_objective_mm2']:.6f} mm²**, but that score is not source validity.
[Independent response readback]({NAME}/response-audit.json) verifies all
**334 saved improving points**, their 93-coordinate gradients and counters for
**421 function evaluations**. It independently reconstructs all 66 source parts,
**1,380 same-sheet pairs, 264 stock edges and 90 holes / 10,026 hole vertices**.
[The failed candidate]({NAME}/source-failures.json) has **52 positive-area
intersections and six clearance-only failures**. All fixed/fixed and fixed/moving
pairs pass. Remaining original overlap is **{front['total_original_overlap_mm2']:.6f} mm²**.

[Source preparation]({NAME}/source-process.json) takes **1.530727 s** and
[initializer preparation]({NAME}/initializer-process.json) **2.914785 s**:
**{front['complete_preparation_seconds']:.6f} s** in total.
The closed call retains its **{front['optimizer_slice_overruns_seconds'][0]:.6f} s** returned
soft slice overrun. Algorithm time including preparation is
**{front['algorithm_seconds']:.6f} s**; complete shared time is
**{front['shared_seconds']:.6f} s**, within the original 60/90-second limits.
[The Job Object]({NAME}/closed-process.json) closes all five processes, with
peak committed memory 93,683,712 bytes under 2 GiB. Source, model and response
audits run separately under the same CPU/thread/memory controls; all are terminal.

[Frame diagnostics]({NAME}/frame-constraint-records.json) inspect the closed point
without changing it. Four frame centers move less than 0.149 mm; the other two
move **30.899455 and 34.195261 mm**. Nine failed pairs involve moving frames,
with **{frames['best_frame_overlap_mm2']:.6f} mm²** overlap. Not every frame is at
its lower-y bound. These observations neither establish global stationarity
nor exclude other placements.

[Next]({NAME}/next-step.json), audit the seven possible orientation-count classes
for six interchangeable quarter-turn frames and the exact scope of previous
calls, then require a source-derived arrangement and structural space checks
before any new model. The current call remains closed. Four earlier arrangements,
440 whole-job allocations, full66/native/material validity, product integration,
surface parity and the original H5 matrix remain unresolved.

[Both previous checkpoints reached main a45826d3 normally]({NAME}/prior-main-push-receipt.json)
after all six checks passed, with all 52 protected files intact. Fresh main CI
has **{success} passed / {live} live jobs** in [this snapshot]({NAME}/main-ci-at-review.json).
Product code, README and releases are unchanged.

[Archive checks]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve every input and outcome.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 six-unturned frame case:** [fresh-source construction and complete audits]({{link}}) verify a joint six-unturned orientation class, distinct from the three earlier four-turned/two-unturned calls. All numeric geometry is recomputed from original JOB and frozen normal metrics: 25 convex pieces, 9,360 clearance supports, 17 arrangements, 141 owner/mode bindings and a valid48 control. All 8,262 initializer choices and 372 finite-difference samples replay. One new 93-parameter call closes after 421 evaluations; all 334 saved points replay. The candidate remains invalid with 58 source failures (52 overlaps, six clearance-only), zero stock failures and no fixed-source conflicts. Preparation is 4.445511 s; algorithm/shared times 56.279557/56.371925 s preserve the 0.088762 s returned slice overrun. No old call resumes, no allocation is excluded, and valid64 stays best. Next audit all seven frame orientation-count classes before any new structural construction. Four earlier arrangements and 440 allocations remain; H2/H5 stay open at 60%. The preceding two checkpoints reached main a45826d3 with all six prior checks passing and 52 protected files retained; fresh CI has {success} passed/{live} live jobs. No product or release change.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [six-unturned-frame construction](../benchmarks/results/{NAME}.md).
A joint six-unturned moving-frame case differs from all three earlier
four-turned/two-unturned calls. Fresh source and model audits pass, including
9,360 clearance supports, all 8,262 initializer choices and 372 derivative
samples. Its sole bounded call still fails 58 original-source pairs, with
zero stock failures. All 334 saved points and the full66 readback replay.
The 56.279557 s algorithm / 56.371925 s shared time includes 4.445511 s fresh
preparation and retains the 0.088762 s returned slice overrun. The call is closed;
no old pipeline resumes, no allocation is excluded and valid64 remains best.
Next audit all seven frame orientation-count classes and their historical
scope before another structural construction. The exact fixed48 four-row
exclusion remains valid for that fixed core. Four earlier arrangements and
440 allocations remain unresolved. H2/H5 stay open at 60%. Both preceding
checkpoints reached main a45826d3 after all six prior checks passed; fresh CI
has {success} passed / {live} live jobs at review. Product and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
