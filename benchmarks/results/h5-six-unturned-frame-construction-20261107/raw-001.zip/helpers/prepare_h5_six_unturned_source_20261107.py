"""Fresh original-only source geometry for a joint six-unturned-frame case."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from statistics import median
from itertools import combinations, product
import json, math, time, os
import shapely
from shapely.geometry import Polygon
from h5_exact_convex_partition_tools_20261029 import merge_exact
from h5_direct_pose_geometry_tools_20261107 import clearance_outline, certify_clearance
from h5_rectangular_cells_20261107 import lower, upper, serial, merged_free_cells, UNIT
from h5_legacy64_source_readback import audit
from h5_checked_affinity_20261107 import affinity_mask

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-six-unturned-source-20261107'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
BENCH=ROOT/'benchmarks/results/h5-source-frontier-pilot-20261018/results.json'
OLD=ROOT/'output/h5-six-upper-frames-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def deadline():assert time.perf_counter()-started<18,'Preparation cap reached; no model or optimizer may run.'
def normalized(family,index,angle,xy,sheet='sheet-0'):
    c,s=math.cos(angle),math.sin(angle);vertices=[(x*c-y*s,x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']]
    return {'part_id':family,'copy_index':index,'sheet_id':sheet,'transform':{'rotation_radians':angle,'mirrored':False,'translation':[xy[k]-min(v[k] for v in vertices) for k in range(2)]}}

OUT.mkdir();started=time.perf_counter()
assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
hist=[OLD/'search'/f'round-{k:02d}'/'optimizer-opened.json' for k in range(3)]
helpers=['h5_exact_convex_partition_tools_20261029.py','h5_direct_pose_geometry_tools_20261107.py','h5_rectangular_cells_20261107.py','h5_legacy64_source_readback.py','h5_checked_affinity_20261107.py']
inputs=[Path(__file__),JOB,BENCH]+[ROOT/'output'/n for n in helpers]+hist
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Prepare a joint change to all six upper frame orientations: six unturned movable frames above twelve fixed turned base frames, with six brackets, twelve inserts and fifteen continuously rotating cogs also free. The prior three six-upper-frame calls all used four turned plus two unturned movable frames; the orientation multiset differs even under identical-copy permutations. The old finite single-owner pipeline stays closed. Reconstruct all numerical geometry from the original JOB and only frozen normal material metrics; no saved pose, family library, clearance outline, initializer, optimized vector or cached objective is consumed. Fresh source partitions, square clearance outlines and rational supports, original-sized base/roof and short6/9 modules, whole-cell hard domains. Derive one four-row cog seed and gap-bisector phase from fresh source vertices and pitches. Source geometry only: no companion initializer, complete model or optimizer is opened.','historical_comparison_only':['old optimizer-opened records contain orientation keys and no optimized coordinate vectors'],'source_inputs_only':[JOB.relative_to(ROOT).as_posix(),BENCH.relative_to(ROOT).as_posix()],'preparation_internal_cap_seconds':18,'preparation_process_cap_seconds':20,'algorithm_seconds':60,'shared_seconds':90,'memory_bytes':2**31,'source_check_reserve_seconds':4,'charge_entire_process_if_consumed':True,'inherited_numeric_preparation_seconds':0,'reason_no_inherited_numeric_charge':'This new joint-orientation source constructor reads no previous numeric construction output. It recomputes every needed quantity from source and measures the full process; prior failures and their original lineages remain preserved separately.','optimizer_calls':0,'retry_permitted':False})
old=[]
for p in hist:
    opened=load(p);key=opened['physical_key'];assert len(key)==39 and key[:6]==[1,1,1,1,0,0]
    old.append({'path':p.relative_to(ROOT).as_posix(),'sha256':digest(p),'physical_key':key,'frame_physical_multiset':[0,0,1,1,1,1]})
write(OUT/'closed-orientation-comparison.json',{'prior_calls':old,'proposed_frame_physical_multiset':[0]*6,'permutation_cannot_identify_frame_multisets':True,'prior_pipeline_resumed':False,'complete_new_physical_key_not_yet_prepared':True})
job=load(JOB);assert digest(JOB)=='2aede6286cf59186781a67a2c355f305aad2d50e735bbfa6cad5ea7dd2ffc6bb';parts={p['id']:p for p in job['parts']}
stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];lo=[m['left']+edge,m['bottom']+edge];hi=[stock['width']-m['right']-edge,stock['height']-m['top']-edge]
normal=[r for r in load(BENCH)['records'] if r['job']==job['name'] and r['kerf_mm']==.2 and r['arm']=='normal'];assert len(normal)==3 and {r['seed'] for r in normal}=={0,1,2} and all(r['status']=='valid' for r in normal)
normal_area=median(r['metrics']['material_area'] for r in normal);target=normal_area*1.01;short_height=(target-stock['width']*stock['height'])/stock['width']
stocks={'sheet-0':lo+hi,'sheet-1':lo+[hi[0],short_height-m['top']-edge]};guard=max(stock['width'],stock['height'])*32*2**-23;required=(job['clearance']+guard)/math.cos(.05)
gap=math.ceil((required+.01)*100)/100;reserve=.025;origin=[v+reserve for v in lo];safe=[lo[0]+reserve,lo[1]+reserve,hi[0]-reserve,hi[1]-reserve];assert gap==.23
write(OUT/'benchmark-target.json',{'normal_median_material_mm2':normal_area,'unchanged_multiplier':1.01,'target_material_mm2':target,'short_used_height_limit_mm':short_height,'source_stocks':stocks,'normal_records':[{'seed':r['seed'],'archive':r['archive'],'archive_sha256':r['archive_sha256'],'material_mm2':r['metrics']['material_area']} for r in normal],'scope':'Unchanged acceptance metrics only; no archived placements consumed.'})
families={};partitions={};supports={}
for family in ['frame','bracket','insert','cog']:
    original=parts[family]['geometry'][0]['outer'];triangles=list(shapely.constrained_delaunay_triangles(Polygon(original)).geoms);pieces,merges=merge_exact(triangles)
    assert shapely.union_all([Polygon(p) for p in pieces]).equals(Polygon(original))
    expanded=clearance_outline(pieces,'.115');proofs,minimum=certify_clearance(original,expanded,'.114');center=[float((min(F(p[k]) for p in original)+max(F(p[k]) for p in original))/2) for k in range(2)]
    families[family]={'original':original,'clearance':expanded,'source_center':center,'source_holes':parts[family]['geometry'][0]['holes']}
    partitions[family]={'pieces':pieces,'triangle_count':len(triangles),'exact_merges':merges};supports[family]={'proofs':proofs,'minimum_certified_gap_mm':minimum};deadline()
frame=parts['frame']['geometry'][0]['outer'];fw=max(p[0] for p in frame)-min(p[0] for p in frame);fh=max(p[1] for p in frame)-min(p[1] for p in frame);assert (fw,fh)==(450,350)
base=[normalized('frame',3*c+r,math.pi/2,[origin[0]+c*(fh+gap),origin[1]+r*(fw+gap)]) for c in range(4) for r in range(3)]
base_top=origin[1]+3*fw+2*gap;roof_bottom=base_top+gap
roof=[normalized('frame',12+2*c+r,0.,[origin[0]+c*(fw+gap),roof_bottom+r*(fh+gap)]) for c in range(3) for r in range(2)]
roof_top=roof_bottom+2*fh+gap
br=parts['bracket']['geometry'][0]['outer'];arm,stem=br[2][1],br[3][0];insert=parts['insert']['geometry'][0]['outer'];iw=max(p[0] for p in insert)-min(p[0] for p in insert);ih=max(p[1] for p in insert)-min(p[1] for p in insert);mw,mh=2*arm+iw+2*gap,2*stem+ih+2*gap;short=[]
for n in range(3):
    x=origin[0]+n*(mw+gap);y=origin[1]
    short.extend([{'part_id':'bracket','copy_index':2*n,'sheet_id':'sheet-1','transform':{'rotation_radians':3*math.pi/2,'mirrored':False,'translation':[x,y+mh]}},{'part_id':'bracket','copy_index':2*n+1,'sheet_id':'sheet-1','transform':{'rotation_radians':math.pi/2,'mirrored':False,'translation':[x+mw,y]}},normalized('insert',11+n,0.,[x+arm+gap,y+stem+gap],'sheet-1')])
right=origin[0]+3*(mw+gap)
for n in range(4):short.append(normalized('insert',14+n,math.pi/2,[right+n*(ih+gap),origin[1]],'sheet-1'))
for n in range(2):short.append(normalized('insert',18+n,0.,[right+n*(iw+gap),origin[1]+iw+gap],'sheet-1'))
fixed=base+short;fixedcheck=audit(job,fixed,stocks,required,guard);assert fixedcheck['valid'] and len(fixed)==27
write(OUT/'fixed27-source.json',fixed);write(OUT/'fixed27-checks.json',fixedcheck)
vertices=[]
for row in base:
    t=row['transform'];c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));tx,ty=map(F,t['translation'])
    vertices.extend([(F(x)*c-F(y)*s+tx,F(x)*s+F(y)*c+ty) for x,y in frame])
core=[lower(min(x for x,y in vertices)),lower(min(y for x,y in vertices)),upper(max(x for x,y in vertices)),upper(max(y for x,y in vertices))]
center=families['cog']['source_center'];cv=families['cog']['original'];radius=math.ceil(max(math.dist(p,center) for p in cv)*1e6)/1e6+.000001
epsilon=F(1,UNIT);fsafe=list(map(lambda x:F(str(x)),safe));modes={};decompositions=[];certificates=[]
for family in ['frame','bracket','insert','cog']:
    modes[family]=[];px,py=families[family]['source_center'];options=[(False,0.)] if family=='cog' else [(mir,math.radians(deg)) for mir in ([False,True] if parts[family]['allow_mirror'] else [False]) for deg in parts[family]['rotations']['degrees']]
    for source_mode,(mirror,angle) in enumerate(options):
        c,s=F(math.cos(angle)),F(math.sin(angle));sign=-1 if mirror else 1;local=[]
        if family=='cog':local=[[-upper(radius),-upper(radius),upper(radius),upper(radius)]]
        else:
            for piece in partitions[family]['pieces']:
                vv=[(sign*(F(x)-F(px))*c-(F(y)-F(py))*s,sign*(F(x)-F(px))*s+(F(y)-F(py))*c) for x,y in piece]
                local.append([lower(min(x for x,y in vv)),lower(min(y for x,y in vv)),upper(max(x for x,y in vv)),upper(max(y for x,y in vv))])
        root=[fsafe[0]-min(r[0] for r in local)+epsilon,fsafe[1]-min(r[1] for r in local)+epsilon,fsafe[2]-max(r[2] for r in local)-epsilon,fsafe[3]-max(r[3] for r in local)-epsilon]
        forbidden=[[core[0]-F(str(gap))-r[2],core[1]-F(str(gap))-r[3],core[2]+F(str(gap))-r[0],core[3]+F(str(gap))-r[1]] for r in local];cells,atomic=merged_free_cells(root,forbidden);assert cells
        decompositions.append({'family':family,'source_mode':source_mode,'rotation_radians':angle,'mirrored':mirror,'local_piece_outer_boxes':list(map(serial,local)),'stock_center_root':serial(root),'forbidden_center_rectangles':list(map(serial,forbidden)),'atomic_cells':atomic,'merged_cells':list(map(serial,cells))})
        for cell_index,cell in enumerate(cells):
            bb=list(map(float,[cell[0]+epsilon,cell[1]+epsilon,cell[2]-epsilon,cell[3]-epsilon]));ff=list(map(F,bb));assert ff[0]<ff[2] and ff[1]<ff[3] and all(ff[k]>cell[k] for k in [0,1]) and all(ff[k]<cell[k] for k in [2,3]);proofs=[]
            for pi,piece in enumerate(local):
                moved=[ff[0]+piece[0],ff[1]+piece[1],ff[2]+piece[2],ff[3]+piece[3]];assert fsafe[0]<=moved[0]<moved[2]<=fsafe[2] and fsafe[1]<=moved[1]<moved[3]<=fsafe[3]
                distances=[core[0]-moved[2],core[1]-moved[3],moved[0]-core[2],moved[1]-core[3]];axis=max(range(4),key=lambda k:distances[k]);assert distances[axis]>=F('.22');proofs.append({'piece':pi,'axis':axis,'exact_gap_mm':str(distances[axis])})
            mode=len(modes[family]);modes[family].append({'mode':mode,'source_mode':source_mode,'cell_index':cell_index,'rotation_radians':angle,'mirrored':mirror,'continuous_rotation':family=='cog','center_bounds_mm':[[bb[0],bb[2]],[bb[1],bb[3]]],'rectangle_mm':bb});certificates.append({'family':family,'mode':mode,'supports':proofs})
    deadline()
used={(r['part_id'],r['copy_index']) for r in fixed};ids=[[family,i] for family in ['frame','bracket','insert','cog'] for i in range(parts[family]['quantity']) if (family,i) not in used]
assert ids[:6]==[['frame',i] for i in range(12,18)] and len(ids)==39
# Fresh four-row source seed; no old numerical center or angle file is read.
root=[F(str(safe[0]))+F(radius)+2*epsilon,F(str(roof_top))+F(str(gap))+F(radius)+2*epsilon,F(str(safe[2]))-F(radius)-2*epsilon,F(str(safe[3]))-F(radius)-2*epsilon]
dx=2*(root[2]-root[0])/7;dy=(root[3]-root[1])/3
angles=[math.atan2(y-center[1],x-center[0]) for x,y in cv];period=math.tau/20
assert len(cv)==80 and max(abs(math.remainder(angles[4*k+j]-angles[j]-k*period,math.tau)) for k in range(20) for j in range(4))<1e-9
contact=(math.remainder(math.atan2(float(dy),float(dx/2)),period)+math.remainder(math.atan2(float(dy),-float(dx/2)),period))/2
phase=math.remainder(contact-(angles[2]+angles[5])/2,period);c,s=math.cos(phase),math.sin(phase);cogs=[];centers=[]
for row,count in enumerate([4,4,4,3]):
    for col in range(count):
        p=[root[0]+dx*(F(col)+F(row%2,2)),root[1]+dy*row];xy=list(map(float,p));index=len(cogs);centers.append({'copy_index':index,'exact_center':list(map(str,p))})
        cogs.append({'part_id':'cog','copy_index':index,'sheet_id':'sheet-0','transform':{'rotation_radians':phase,'mirrored':False,'translation':[xy[0]-(center[0]*c-center[1]*s),xy[1]-(center[0]*s+center[1]*c)]}})
partial=fixed+roof+cogs;seeds=[]
for row in partial:
    identity=[row['part_id'],row['copy_index']]
    if identity not in ids:continue
    owner=ids.index(identity);family=identity[0];t=row['transform'];theta=t['rotation_radians'];c,s=math.cos(theta),math.sin(theta);px,py=families[family]['source_center'];old=[px*c-py*s+t['translation'][0],px*s+py*c+t['translation'][1]]
    options=[m for m in modes[family] if family=='cog' or (not m['mirrored'] and abs(math.remainder(m['rotation_radians']-theta,math.tau))<1e-12)];choices=[]
    for m0 in options:
        point=[min(hi0,max(lo0,old[k])) for k,(lo0,hi0) in enumerate(m0['center_bounds_mm'])];choices.append((sum((x-y)**2 for x,y in zip(old,point)),m0['mode'],point))
    distance,mi,point=min(choices);assert distance<.0001**2;t['translation']=[point[0]-(px*c-py*s),point[1]-(px*s+py*c)]
    seeds.append({'owner':owner,'identity':identity,'center':point,'angle_radians':theta,'source_pose':t,'projection_distance_mm':math.sqrt(distance),'selected_mode':mi})
check=audit(job,partial,stocks,required,guard);assert check['valid'] and len(partial)==48 and len(seeds)==21
angular=[i for i,(family,_) in enumerate(ids) if family=='cog'];allids=[[p['id'],i] for p in job['parts'] for i in range(p['quantity'])]
lib={'families':families,'family_modes':modes,'identities':ids,'pairs':list(combinations(range(39),2)),'fixed_source_rows':fixed,'all66_identities':allids,'source_stocks':stocks,'safe_source_stock_mm':safe,'fixed_core_outer_rectangles_mm':[list(map(float,core))],'required_pair_gap_mm':required,'stock_guard_mm':guard,'angle_scale_mm':radius,'angle_bounds':[[-math.pi*radius,math.pi*radius] for _ in angular],'continuous_parameters':93,'angle_coordinate_start':78,'angle_owners':angular,'source_moving_seed':seeds,'source_initialization_prepared':False,'complete_model_prepared':False}
for name,value in [('library.json',lib),('partitions.json',partitions),('clearance-supports.json',supports),('fixed-core-box.json',{'outer_rectangle':serial(core),'source_vertices':[[str(x),str(y)] for x,y in vertices]}),('rectangle-decompositions.json',decompositions),('cell-support-certificates.json',certificates),('source48-control.json',partial),('source48-checks.json',check),('source21-seeds.json',seeds),('source-phase.json',{'exact_center_root':serial(root),'exact_dx':str(dx),'exact_dy':str(dy),'phase_radians':phase,'phase_degrees':math.degrees(phase),'exact_symmetry_assumed':False,'centers':centers}),('source-recipe.json',{'base_columns':4,'base_rows':3,'upper_columns':3,'upper_rows':2,'upper_rotations_radians':[0.]*6,'gap_mm':gap,'source_reserve_mm':reserve,'base_top_mm':base_top,'roof_bottom_mm':roof_bottom,'roof_top_mm':roof_top,'module_width_mm':mw,'module_height_mm':mh,'cog_radius_mm':radius})]:write(OUT/name,value)
deadline();write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'fresh_source_geometry_only':True,'fixed_originals':27,'moving_originals':39,'parameters':93,'continuous_angles':15,'pairs':741,'legal_owner_compound_options':sum(len(modes[f]) for f,_ in ids),'source48_valid':True,'source48_minimum_gap_mm':check['minimum_pair_gap_mm'],'new_frame_orientation_multiset_differs_from_all_three_old_calls':True,'source_clearance_supports':sum(len(v['proofs']) for v in supports.values()),'independent_audit_pending':True,'complete_initializer_prepared':False,'complete_model_prepared':False,'source_valid66':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
