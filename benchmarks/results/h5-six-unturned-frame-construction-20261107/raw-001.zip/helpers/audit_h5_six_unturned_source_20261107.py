"""Independent source, rational domain and joint-orientation readback."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
from statistics import median
import json, math, time
from h5_legacy64_source_readback import audit

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-six-unturned-source-20261107';OUT=BASE/'audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';BENCH=ROOT/'benchmarks/results/h5-source-frontier-pilot-20261018/results.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();EPS=Q(1,10**6)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))/2
def rational(p):return [tuple(map(Q,v)) for v in p]
def ccw(p):
    p=rational(p);return p if area(p)>0 else p[::-1]
def edges(p):
    out={}
    for a,b in zip(p,p[1:]+p[:1]):
        key=tuple(sorted((a,b)));out[key]=out.get(key,0)+(1 if a<b else -1)
    return out
def winding(p,ring):return sum(1 if a[1]<=p[1]<b[1] and cross(a,b,p)>0 else -1 if b[1]<=p[1]<a[1] and cross(a,b,p)<0 else 0 for a,b in zip(ring,ring[1:]+ring[:1]))
def down(v):return Q(math.floor(v*10**6),10**6)
def up(v):return Q(math.ceil(v*10**6),10**6)
def contained(a,b):return b[0]<=a[0] and b[1]<=a[1] and a[2]<=b[2] and a[3]<=b[3]
def separated(a,b):return a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
def rarea(r):return (r[2]-r[0])*(r[3]-r[1])
def vertices(part,t,exact=False):
    cast=Q if exact else float;c,s=cast(math.cos(t['rotation_radians'])),cast(math.sin(t['rotation_radians']));m=-1 if t['mirrored'] else 1;tx,ty=map(cast,t['translation'])
    return [(m*cast(x)*c-cast(y)*s+tx,m*cast(x)*s+cast(y)*c+ty) for x,y in part['geometry'][0]['outer']]

OUT.mkdir();start=time.perf_counter();lib=load(BASE/'library.json');job=load(JOB);parts={p['id']:p for p in job['parts']};plan=load(BASE/'plan.json')
paths=[Path(__file__),JOB,BENCH,ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5-six-unturned-source-process-20261107/process.json']+[p for p in BASE.iterdir() if p.is_file()]
bindings={p.relative_to(ROOT).as_posix():digest(p) for p in paths}
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h;bindings[name]=h
write(OUT/'plan.json',{'inputs':bindings,'method':'Independent original benchmark/inventory readback, exact convex-piece winding cancellation and every clearance support, original recipe/source poses, all rational hard-domain atomic and merged cells, stock/core supports and family corner controls. Verify that all six unturned moving frames differ as a multiset from every historical six-upper-frame optimizer call; identical copy relabelling cannot remove that difference. Reconstruct the source cog phase using normalized vertex vectors, and the four-row centers from original stock, frame dimensions and source radius. No producer function or saved optimized vector is used.','optimizer_calls':0,'retry_permitted':False})
st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance'];lo=[m['left']+edge,m['bottom']+edge];hi=[st['width']-m['right']-edge,st['height']-m['top']-edge]
normal=[r for r in load(BENCH)['records'] if r['job']==job['name'] and r['kerf_mm']==.2 and r['arm']=='normal'];assert len(normal)==3 and {r['seed'] for r in normal}=={0,1,2} and all(r['status']=='valid' for r in normal)
target=median(r['metrics']['material_area'] for r in normal)*1.01;height=(target-st['width']*st['height'])/st['width'];stocks={'sheet-0':lo+hi,'sheet-1':lo+[hi[0],height-m['top']-edge]}
guard=max(st['width'],st['height'])*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);gap=math.ceil((required+.01)*100)/100
assert lib['source_stocks']==stocks and lib['stock_guard_mm']==guard and lib['required_pair_gap_mm']==required and load(BASE/'benchmark-target.json')['target_material_mm2']==target
safe=[Q(str(stocks['sheet-0'][0]))+Q('.025'),Q(str(stocks['sheet-0'][1]))+Q('.025'),Q(str(stocks['sheet-0'][2]))-Q('.025'),Q(str(stocks['sheet-0'][3]))-Q('.025')];assert list(map(float,safe))==lib['safe_source_stock_mm']
partitions=load(BASE/'partitions.json');supports=load(BASE/'clearance-supports.json');support_count=0;partition_count=0
for family,f in lib['families'].items():
    source=parts[family]['geometry'][0];assert f['original']==source['outer'] and f['source_holes']==source['holes'];outer=ccw(f['original']);expanded=ccw(f['clearance'])
    center=[float((min(p[k] for p in outer)+max(p[k] for p in outer))/2) for k in range(2)];assert center==f['source_center']
    net={};pieces=[ccw(p) for p in partitions[family]['pieces']]
    for p in pieces:
        assert area(p)>0 and all(cross(a,b,v)>=0 for a,b in zip(p,p[1:]+p[:1]) for v in p)
        for e,n in edges(p).items():net[e]=net.get(e,0)+n
    assert {e:n for e,n in net.items() if n}=={e:n for e,n in edges(outer).items() if n}
    assert sum(area(p) for p in pieces)==area(outer);partition_count+=len(pieces);assert winding(outer[0],expanded)!=0
    normals=supports[family]['proofs'];assert {(p['source_edge'],p['expanded_edge']) for p in normals}==set(product(range(len(outer)),range(len(expanded)))) and len(normals)==len(outer)*len(expanded)
    minimum=math.inf
    for proof in normals:
        i,j=proof['source_edge'],proof['expanded_edge'];nx,ny=map(Q,proof['normal']);norm=nx*nx+ny*ny
        distance=min(x*nx+y*ny for x,y in [expanded[j],expanded[(j+1)%len(expanded)]])-max(x*nx+y*ny for x,y in [outer[i],outer[(i+1)%len(outer)]])
        assert norm>0 and distance>0 and distance**2>=Q('.114')**2*norm;minimum=min(minimum,float(distance)/math.sqrt(float(norm)))
    assert abs(minimum-supports[family]['minimum_certified_gap_mm'])<1e-14;support_count+=len(normals)
fixed=load(BASE/'fixed27-source.json');assert fixed==lib['fixed_source_rows'] and len(fixed)==27
assert audit(job,fixed,stocks,required,guard)==load(BASE/'fixed27-checks.json') and load(BASE/'fixed27-checks.json')['valid']
base=[r for r in fixed if r['part_id']=='frame'];assert len(base)==12 and [r['copy_index'] for r in base]==list(range(12))
ox,oy=map(float,safe[:2]);fw,fh=450.,350.;assert parts['frame']['geometry'][0]['outer']==[[0.,0.],[450.,0.],[450.,350.],[0.,350.]]
for row in base:
    i=row['copy_index'];v=vertices(parts['frame'],row['transform']);assert row['transform']['rotation_radians']==math.pi/2 and not row['transform']['mirrored']
    assert abs(min(x for x,y in v)-(ox+(i//3)*(fh+gap)))<1e-10 and abs(min(y for x,y in v)-(oy+(i%3)*(fw+gap)))<1e-10
vv=[p for row in base for p in vertices(parts['frame'],row['transform'],True)];core=[down(min(x for x,y in vv)),down(min(y for x,y in vv)),up(max(x for x,y in vv)),up(max(y for x,y in vv))]
assert list(map(Q,load(BASE/'fixed-core-box.json')['outer_rectangle']))==core and lib['fixed_core_outer_rectangles_mm']==[list(map(float,core))]
for row in base:assert all(core[0]<=x<=core[2] and core[1]<=y<=core[3] for x,y in vertices(parts['frame'],row['transform']))
allids=[[p['id'],i] for p in job['parts'] for i in range(p['quantity'])];fixedids=[[r['part_id'],r['copy_index']] for r in fixed];ids=lib['identities']
assert sorted(fixedids+ids)==sorted(allids) and len({tuple(i) for i in fixedids+ids})==66 and lib['all66_identities']==allids
assert ids[:6]==[['frame',i] for i in range(12,18)] and ids[6:12]==[['bracket',i] for i in range(6,12)] and ids[12:24]==[['insert',i] for i in range(11)]+[['insert',20]] and ids[24:]==[['cog',i] for i in range(15)]
assert lib['pairs']==[list(p) for p in combinations(range(39),2)] and lib['continuous_parameters']==93 and lib['angle_coordinate_start']==78 and lib['angle_owners']==list(range(24,39))
radius=lib['angle_scale_mm'];center=lib['families']['cog']['source_center'];cog=parts['cog']['geometry'][0]['outer'];expected_radius=math.ceil(max(math.dist(p,center) for p in cog)*1e6)/1e6+.000001
assert radius==expected_radius and Q(radius)**2>max(sum((Q(p[k])-Q(center[k]))**2 for k in range(2)) for p in cog)
assert lib['angle_bounds']==[[-math.pi*radius,math.pi*radius] for _ in range(15)]
decompositions=load(BASE/'rectangle-decompositions.json');certificates=load(BASE/'cell-support-certificates.json');mode_count=atom_count=proof_count=0;corner_records=[]
for family in ['frame','bracket','insert','cog']:
    options=[(False,0.)] if family=='cog' else [(mirror,math.radians(deg)) for mirror in ([False,True] if parts[family]['allow_mirror'] else [False]) for deg in parts[family]['rotations']['degrees']];expected_modes=[];px,py=lib['families'][family]['source_center']
    for source_mode,(mirror,angle) in enumerate(options):
        c,s=Q(math.cos(angle)),Q(math.sin(angle));sign=-1 if mirror else 1;local=[]
        if family=='cog':local=[[-up(Q(radius)),-up(Q(radius)),up(Q(radius)),up(Q(radius))]]
        else:
            for piece in partitions[family]['pieces']:
                p=[(sign*(Q(x)-Q(px))*c-(Q(y)-Q(py))*s,sign*(Q(x)-Q(px))*s+(Q(y)-Q(py))*c) for x,y in piece];local.append([down(min(x for x,y in p)),down(min(y for x,y in p)),up(max(x for x,y in p)),up(max(y for x,y in p))])
        root=[safe[0]-min(r[0] for r in local)+EPS,safe[1]-min(r[1] for r in local)+EPS,safe[2]-max(r[2] for r in local)-EPS,safe[3]-max(r[3] for r in local)-EPS]
        forbidden=[[core[0]-Q(str(gap))-r[2],core[1]-Q(str(gap))-r[3],core[2]+Q(str(gap))-r[0],core[3]+Q(str(gap))-r[1]] for r in local]
        d=next(d for d in decompositions if d['family']==family and d['source_mode']==source_mode);assert list(map(Q,d['stock_center_root']))==root and [list(map(Q,r)) for r in d['local_piece_outer_boxes']]==local and [list(map(Q,r)) for r in d['forbidden_center_rectangles']]==forbidden
        axes=[sorted({root[k],root[k+2]}|{r[j] for r in forbidden for j in [k,k+2] if root[k]<r[j]<root[k+2]}) for k in range(2)];atoms={}
        for x0,x1 in zip(axes[0],axes[0][1:]):
            for y0,y1 in zip(axes[1],axes[1][1:]):atoms[x0,y0,x1,y1]=not any(r[0]<(x0+x1)/2<r[2] and r[1]<(y0+y1)/2<r[3] for r in forbidden)
        assert atoms=={tuple(map(Q,r['bounds'])):r['retained'] for r in d['atomic_cells']};atom_count+=len(atoms)
        cells=[list(map(Q,r)) for r in d['merged_cells']];assert all(contained(r,root) and all(separated(r,b) for b in forbidden) for r in cells) and all(separated(a,b) for a,b in combinations(cells,2))
        assert sum(rarea(r) for r in cells)==sum(rarea(r) for r,keep in atoms.items() if keep)
        for atom,keep in atoms.items():
            if keep:assert sum(contained(atom,r) for r in cells)==1
        for cell_index,cell in enumerate(cells):
            bb=list(map(float,[cell[0]+EPS,cell[1]+EPS,cell[2]-EPS,cell[3]-EPS]));ff=list(map(Q,bb));assert all(ff[k]>cell[k] for k in [0,1]) and all(ff[k]<cell[k] for k in [2,3])
            mi=len(expected_modes);mode={'mode':mi,'source_mode':source_mode,'cell_index':cell_index,'rotation_radians':angle,'mirrored':mirror,'continuous_rotation':family=='cog','center_bounds_mm':[[bb[0],bb[2]],[bb[1],bb[3]]],'rectangle_mm':bb};expected_modes.append(mode);proofs=[]
            for pi,piece in enumerate(local):
                moved=[ff[0]+piece[0],ff[1]+piece[1],ff[2]+piece[2],ff[3]+piece[3]];assert contained(moved,safe);ds=[core[0]-moved[2],core[1]-moved[3],moved[0]-core[2],moved[1]-core[3]];axis=max(range(4),key=lambda k:ds[k]);assert ds[axis]>=Q('.22');proofs.append({'piece':pi,'axis':axis,'exact_gap_mm':str(ds[axis])});proof_count+=1
            assert next(r for r in certificates if r['family']==family and r['mode']==mi)=={'family':family,'mode':mi,'supports':proofs}
            identity=next(i for f,i in ids if f==family)
            for point in product(*mode['center_bounds_mm']):
                for theta in ([-math.pi/3,0.,math.pi/4] if family=='cog' else [angle]):
                    cc,ss=math.cos(theta),math.sin(theta);sg=-1 if mirror else 1;row={'part_id':family,'copy_index':identity,'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':mirror,'translation':[point[0]-(sg*px*cc-py*ss),point[1]-(sg*px*ss+py*cc)]}}
                    result=audit(job,fixed+[row],stocks,required,guard);assert result['valid'];corner_records.append({'family':family,'mode':mi,'center':point,'angle':theta,'minimum_gap_mm':result['minimum_pair_gap_mm']})
    assert expected_modes==lib['family_modes'][family];mode_count+=len(options)
assert mode_count==len(decompositions)==17 and len(corner_records)==80
partial=load(BASE/'source48-control.json');seeds=load(BASE/'source21-seeds.json');assert seeds==lib['source_moving_seed'] and len(seeds)==21
assert audit(job,partial,stocks,required,guard)==load(BASE/'source48-checks.json') and load(BASE/'source48-checks.json')['valid']
roof=[r for r in partial if r['part_id']=='frame' and r['copy_index']>=12];assert len(roof)==6 and all(r['transform']['rotation_radians']==0. and not r['transform']['mirrored'] for r in roof)
for r in roof:
    i=r['copy_index']-12;v=vertices(parts['frame'],r['transform']);assert abs(min(x for x,y in v)-(ox+(i//2)*(fw+gap)))<.0001 and abs(min(y for x,y in v)-(oy+3*(fw+gap)+(i%2)*(fh+gap)))<.0001
recipe=load(BASE/'source-recipe.json');roof_top=oy+3*(fw+gap)+2*fh+gap;assert abs(recipe['roof_top_mm']-roof_top)<1e-10
seedroot=[Q(str(float(safe[0])))+Q(radius)+2*EPS,Q(str(recipe['roof_top_mm']))+Q(str(gap))+Q(radius)+2*EPS,Q(str(float(safe[2])))-Q(radius)-2*EPS,Q(str(float(safe[3])))-Q(radius)-2*EPS]
dx=2*(seedroot[2]-seedroot[0])/7;dy=(seedroot[3]-seedroot[1])/3;phaseinfo=load(BASE/'source-phase.json');assert list(map(Q,phaseinfo['exact_center_root']))==seedroot and Q(phaseinfo['exact_dx'])==dx and Q(phaseinfo['exact_dy'])==dy
vectors=[(cog[i][0]-center[0],cog[i][1]-center[1]) for i in [2,5]];unit=[(x/math.hypot(x,y),y/math.hypot(x,y)) for x,y in vectors];gapaxis=math.atan2(sum(y for x,y in unit),sum(x for x,y in unit));period=math.tau/20
contact=sum(math.remainder(math.atan2(float(dy),sign*float(dx/2)),period) for sign in [1,-1])/2;phase=math.remainder(contact-gapaxis,period);assert abs(phase-phaseinfo['phase_radians'])<1e-14
assert len(phaseinfo['centers'])==15
for record in phaseinfo['centers']:
    i=record['copy_index'];row,col=divmod(i,4);xy=[seedroot[0]+dx*(Q(col)+Q(row%2,2)),seedroot[1]+dy*row];assert list(map(Q,record['exact_center']))==xy
    saved=next(s for s in seeds if s['identity']==['cog',i]);assert max(abs(saved['center'][k]-float(xy[k])) for k in range(2))<.0001 and abs(saved['angle_radians']-phase)<1e-14
for seed in seeds:
    family=seed['identity'][0];owner=seed['owner'];assert ids[owner]==seed['identity'] and seed['projection_distance_mm']<.0001
    mode=lib['family_modes'][family][seed['selected_mode']];assert all(a<=seed['center'][k]<=b for k,(a,b) in enumerate(mode['center_bounds_mm']))
    row=next(r for r in partial if [r['part_id'],r['copy_index']]==seed['identity']);assert row['transform']==seed['source_pose']
comparison=load(BASE/'closed-orientation-comparison.json');assert comparison['proposed_frame_physical_multiset']==[0]*6 and len(comparison['prior_calls'])==3
for rec in comparison['prior_calls']:
    p=ROOT/rec['path'];assert digest(p)==rec['sha256'];saved=load(p);assert saved['physical_key']==rec['physical_key'] and sorted(saved['physical_key'][:6])==rec['frame_physical_multiset']==[0,0,1,1,1,1]
    assert sorted(saved['physical_key'][:6])!=[0]*6
process=load(ROOT/'output/h5-six-unturned-source-process-20261107/process.json');assert process['passed'] and process['closed']
write(OUT/'source-bindings.json',bindings);write(OUT/'corner-controls.json',corner_records)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'fresh_source_numeric_inputs_verified':True,'original_convex_pieces_verified':partition_count,'exact_clearance_supports_verified':support_count,'mode_arrangements_verified':mode_count,'atomic_cells_verified':atom_count,'whole_cell_piece_supports_verified':proof_count,'unique_family_corner_controls':len(corner_records),'owner_compound_bindings':sum(len(lib['family_modes'][f]) for f,i in ids),'moving_originals':39,'parameters':93,'moving_pairs':741,'six_unturned_frame_multiset_differs_from_all_three_closed_calls':True,'source48_valid':True,'all66_identities_preserved':True,'complete_preparation_seconds':process['complete_seconds'],'library_sha256':digest(BASE/'library.json'),'complete_initializer_prepared':False,'complete_model_prepared':False,'source_valid66':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
