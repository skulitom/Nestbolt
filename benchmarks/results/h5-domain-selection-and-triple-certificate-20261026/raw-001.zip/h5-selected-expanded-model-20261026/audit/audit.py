"""Independently verify the exact selected-domain restriction of the full source model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-selected-expanded-model-20261026';PARENT=ROOT/'output/h5-projected-expanded-model-20261026';SELECT=ROOT/'output/h5-expanded-domain-master-search-20261026/selection-audit';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Verify committed full projected parent and immutable necessary-master readback. Independently map each selected original/query/domain to its parent selector and reconstruct all12 appended equalities. Confirm every old variable/constraint remains unchanged and only advisory hints are removed; restoring hints and removing the12 equalities recovers the entire parent. Verify exact source domain indices and actual solver import/export. No solver; negative scope is only this selected tuple.'})
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    for n,h in load(SELECT/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    known=load(ROOT/'benchmarks/results/h5-projected-source-and-fresh-conflicts-20261026/raw-manifest.json');hashes={r['sha256'] for r in known['files']+known['aliases']};assert digest(PARENT/'model.pb') in hashes and digest(PARENT/'audit/checks.json') in hashes and load(PARENT/'audit/checks.json')['passed'] and load(SELECT/'checks.json')['passed'];parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model.pb').read_bytes());child=cp_model_pb2.CpModelProto();child.ParseFromString((BASE/'model.pb').read_bytes());assert len(parent.variables)==223086 and len(parent.constraints)==289916
    assert (BASE/'mapping.json').read_bytes()==(PARENT/'mapping.json').read_bytes();mapping=load(PARENT/'mapping.json');selected=load(SELECT/'verified-domain-selection.json');spec=load(SOURCE/'plan.json');records=[];assert len(selected['movable_parts'])==12 and selected['fixed_items']==spec['fixed_items']
    for i,s in enumerate(selected['movable_parts']):
        assert s['part']==i and s['item']==spec['parts'][i]['index'];p=mapping['parts'][i];m=next(m for m in p['modes'] if m['query']==s['query']);d=load(SOURCE/'queries'/f"{s['query']:03d}.json")['domains'][s['domain_row']];assert d['index']==s['domain_index'];flag=m['domains'][s['domain_row']];ci=len(parent.constraints)+i;c=cp_model_pb2.ConstraintProto();c.linear.vars.append(flag);c.linear.coeffs.append(1);c.linear.domain.extend([1,1]);assert child.constraints[ci]==c;records.append({'part':i,'item':s['item'],'query':s['query'],'domain_row':s['domain_row'],'domain_index':s['domain_index'],'flag':flag,'constraint':ci})
    assert records==load(BASE/'selected-domains.json') and child.variables==parent.variables and child.constraints[:289916]==parent.constraints and len(child.constraints)==289928 and not child.HasField('solution_hint');restored=cp_model_pb2.CpModelProto();restored.CopyFrom(child);del restored.constraints[289916:];restored.solution_hint.CopyFrom(parent.solution_hint);assert restored==parent
    real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'solver-import-roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert actual==child and digest(BASE/'model.pb')==load(BASE/'result.json')['model_sha256'];checks={'passed':True,'seconds':time.perf_counter()-start,'variables':223086,'constraints':289928,'hints':0,'complete_parent_restored_exactly':True,'exact_selected_domain_subproblem_verified':True,'all_original_full_guarded_source_clauses_retained':True,'selected_domain_equalities':12,'free_original_coordinate_variables':24,'coordinate_values_fixed':0,'actual_solver_import_export_verified':True,'required_originals':66,'moving_originals':12,'fixed_originals':54,'same_sheet_pair_modes':538,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
