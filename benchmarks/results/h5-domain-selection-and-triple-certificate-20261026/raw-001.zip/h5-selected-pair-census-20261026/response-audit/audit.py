"""Read back the complete closed pair census and every source-pair witness."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-selected-pair-census-20261026';RUN=BASE/'search';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify all model/source hashes, actual solver models and parameters, complete declared inventory and one closed call per pair, every response/status/timing and every returned variable and active constraint. Independently check four returned source coordinates against the original domains, all original inside planes and every guarded no-fit face OR. Positives are individual two-part witnesses only; they cannot be combined or establish full layout/native acceptance. No new solver calls.'})
for plan in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(plan)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];budget=load(RUN/'budget.json');proc=load(RUN/'process.json');census=load(RUN/'census.json');rows=load(BASE/'inventory.json');assert budget['shared_seconds']==60 and budget['deadline_perf_counter']==budget['start_perf_counter']+60 and budget['maximum_calls']==46 and budget['per_pair_solver_seconds']==1;assert not proc['timeout'] and proc['exit_code']==0 and proc['seconds']<=60;assert not census['pending_pairs'] and len(census['results'])==census['solver_calls']==46 and len(list(RUN.rglob('opened.json')))==46;checked=inside=faces=variables=0;verified=[]
for r,result in zip(rows,census['results']):
    i=r['index'];folder=RUN/f'{i:03d}';saved=load(folder/'result.json');opened=load(folder/'opened.json');assert saved==result and opened['maximum_calls']==saved['solver_calls']==1 and opened['pair']==i==saved['pair'];assert saved['parts']==[r['a']['part'],r['b']['part']];model=cp_model_pb2.CpModelProto();model.ParseFromString((folder/'model.pb').read_bytes());expected=cp_model_pb2.CpModelProto();expected.ParseFromString((BASE/'models'/f'{i:03d}.pb').read_bytes());assert model==expected and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=1,num_search_workers=1,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'];response=cp_model_pb2.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert cp_model_pb2.CpSolverStatus.Name(response.status)==saved['status'];assert abs(response.wall_time-saved['seconds'])<.1 and saved['seconds']<=saved['stage_seconds'];assert saved['solver_soft_overshoot_seconds']==max(0,saved['seconds']-1);assert saved['status']=='OPTIMAL';s=list(response.solution);assert len(s)==len(model.variables) and s[:4]==saved['original_coordinates_units1000']
    for v,n in zip(model.variables,s):assert any(lo<=n<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]));variables+=1
    for c in model.constraints:
        if not all(s[v] if v>=0 else not s[-v-1] for v in c.enforcement_literal):continue
        kind=c.WhichOneof('constraint')
        if kind=='linear':n=sum(s[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=n<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        else:assert kind=='bool_or' and any(s[v] if v>=0 else not s[-v-1] for v in c.bool_or.literals)
        checked+=1
    for offset,p in [(0,r['a']),(2,r['b'])]:
        d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];x,y=s[offset:offset+2];assert d['index']==p['domain_index'] and d['coordinate_bounds'][0]<=x<=d['coordinate_bounds'][2] and d['coordinate_bounds'][1]<=y<=d['coordinate_bounds'][3]
        for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];inside+=1
    dx,dy=s[2]-s[0],s[3]-s[1]
    for f in load(SOURCE/'mutual'/f"{r['mutual_case']:03d}.json")['faces']:assert any(h['a']*dx+h['b']*dy>=h['bound'] for h in f['outside_halfplanes']);faces+=1
    verified.append({'pair':i,'parts':saved['parts'],'status':saved['status'],'coordinates_units1000':s[:4],'source_pair_feasible':True})
write(OUT/'verified-pair-witnesses.json',verified);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':46,'complete_inventory_verified':True,'all46_source_pairs_have_verified_witnesses':True,'actual_shared_seconds':proc['seconds'],'max_solver_seconds':max(r['seconds'] for r in census['results']),'sum_solver_seconds':sum(r['seconds'] for r in census['results']),'soft_limit_overruns':sum(r['solver_soft_overshoot_seconds']>0 for r in census['results']),'all_variables_checked':variables,'active_constraints_checked':checked,'source_inside_planes_checked':inside,'source_guarded_face_clauses_checked':faces,'new_pair_exclusions':0,'full_target_witness':False,'native_validation_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
