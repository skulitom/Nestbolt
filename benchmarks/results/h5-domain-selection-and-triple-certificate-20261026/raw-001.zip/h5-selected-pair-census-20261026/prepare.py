"""Prepare each distinct same-sheet pair from the closed selected tuple, without solving."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';SELECT=ROOT/'output/h5-expanded-domain-master-search-20261026/selection-audit';OUT=ROOT/'output/h5-selected-pair-census-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();spec=load(SOURCE/'plan.json');selected=load(SELECT/'verified-domain-selection.json');assert load(SELECT/'checks.json')['passed'];parts=selected['movable_parts'];pairs=[(a,b) for a,b in combinations(parts,2) if a['sheet']==b['sheet']];assert len(pairs)==46
paths=[SOURCE/'plan.json',SOURCE/'audit/checks.json',SELECT/'checks.json',SELECT/'verified-domain-selection.json',ROOT/'output/h5-selected-expanded-search-20261026/search-audit-repaired/checks.json']+[SOURCE/'queries'/f'{q:03d}.json' for q in sorted({p['query'] for p in parts})]+[SOURCE/'mutual'/f"{c['index']:03d}.json" for c in spec['mutual_cases'] if any((c['profile_a'],c['profile_b'])==(a['profile'],b['profile']) for a,b in pairs)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Complete diagnostic census of46 distinct same-sheet physical pairs in the independently read-back INFEASIBLE selected tuple. Each pair has exactly four free integer coordinates inside the two original selected source domains and every original full guarded no-fit face clause for this ordered profile pair. Other moving parts omitted: this is a relaxation of the selected full-source model. A negative excludes only the two stored physical part/query/domain choices; a positive proves only source-pair feasibility. No native/full packing claim. Independently audit all models before calls. At most one call per listed pair,1second each,one worker,seed0,60seconds shared including imports/readback; no retry/extension/reseed. All prior calls closed.'})
records=[]
for index,(a,b) in enumerate(pairs):
    model=cp_model_pb2.CpModelProto()
    def variable(name,lo,hi):
        i=len(model.variables);v=model.variables.add();v.name=name;v.domain.extend([lo,hi]);return i
    def linear(terms,lo=-2**63,hi=2**63-1,enforced=None):
        c=model.constraints.add();terms=sorted((v,k) for v,k in terms if k);c.linear.vars.extend(v for v,k in terms);c.linear.coeffs.extend(k for v,k in terms);c.linear.domain.extend([lo,hi]);
        if enforced is not None:c.enforcement_literal.append(enforced)
    domains=[]
    for p in (a,b):
        q=spec['queries'][p['query']];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];assert d['index']==p['domain_index'];bounds=d['coordinate_bounds'];qb=q['anchor_bounds_units1000'];bounds=[max(bounds[0],qb[0]),max(bounds[1],qb[1]),min(bounds[2],qb[2]),min(bounds[3],qb[3])];x=variable(f"p{p['part']}-x",bounds[0],bounds[2]);y=variable(f"p{p['part']}-y",bounds[1],bounds[3]);domains.append((x,y,d))
        for h in d['halfplanes']:linear([(x,h['a']),(y,h['b'])],hi=h['bound'])
    case=next(c['index'] for c in spec['mutual_cases'] if (c['profile_a'],c['profile_b'])==(a['profile'],b['profile']));faces=load(SOURCE/'mutual'/f'{case:03d}.json')['faces'];planes=0
    for f in faces:
        flags=[]
        for j,h in enumerate(f['outside_halfplanes']):
            flag=variable(f"f{f['index']}-edge{j}",0,1);flags.append(flag);linear([(0,-h['a']),(1,-h['b']),(2,h['a']),(3,h['b'])],lo=h['bound'],enforced=flag);planes+=1
        c=model.constraints.add();c.bool_or.literals.extend(flags)
    p=OUT/'models'/f'{index:03d}.pb';p.write_bytes(model.SerializeToString());(p.with_suffix('.pbtxt')).write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');records.append({'index':index,'a':a,'b':b,'mutual_case':case,'faces':len(faces),'planes':planes,'variables':len(model.variables),'constraints':len(model.constraints),'model_sha256':digest(p)})
write(OUT/'inventory.json',records);write(OUT/'prepared.json',{'models':len(records),'seconds':time.perf_counter()-start,'solver_calls':0});print(load(OUT/'prepared.json'))
