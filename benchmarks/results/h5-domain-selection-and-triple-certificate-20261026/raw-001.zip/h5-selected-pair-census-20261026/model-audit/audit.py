"""Independent reconstruction of all selected-pair source models; no solver."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-selected-pair-census-20261026';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';SELECT=ROOT/'output/h5-expanded-domain-master-search-20261026/selection-audit';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Check all input hashes and committed source membership; independently reconstruct every variable and constraint from selected domains and every original no-fit face. Verify the complete46-pair inventory, actual solver import/export and absence of unexamined model fields. Models are two-part relaxations, not complete layouts. No solver.'})
known=set()
for name in ['h5-expanded-cog-neighborhood-20261026','h5-projected-source-and-fresh-conflicts-20261026']:
    m=load(ROOT/'benchmarks/results'/name/'raw-manifest.json');known.update(r['sha256'] for r in m['files']+m['aliases'])
for n,h in load(BASE/'plan.json')['inputs'].items():
    assert digest(ROOT/n)==h,n
    if 'h5-expanded-cog-joint-prepared-20261026/' in n:assert h in known,n
assert load(SOURCE/'audit/checks.json')['passed'] and load(SELECT/'checks.json')['passed'];assert load(ROOT/'output/h5-selected-expanded-search-20261026/search-audit-repaired/checks.json')['terminal_status']=='INFEASIBLE'
spec=load(SOURCE/'plan.json');parts=load(SELECT/'verified-domain-selection.json')['movable_parts'];pairs=[(a,b) for a,b in combinations(parts,2) if a['sheet']==b['sheet']];rows=load(BASE/'inventory.json');assert len(rows)==len(pairs)==46;checks=[]
for i,(r,(a,b)) in enumerate(zip(rows,pairs)):
    assert r['index']==i and r['a']==a and r['b']==b;expected=cp_model_pb2.CpModelProto()
    for p in [a,b]:
        d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];assert d['index']==p['domain_index'];q=spec['queries'][p['query']]['anchor_bounds_units1000'];z=d['coordinate_bounds'];offset=len(expected.variables)
        for axis in range(2):expected.variables.add(name=f"p{p['part']}-{'xy'[axis]}",domain=[max(q[axis],z[axis]),min(q[axis+2],z[axis+2])])
        for h in d['halfplanes']:
            t=[(offset,h['a']),(offset+1,h['b'])];t=[(v,k) for v,k in t if k];expected.constraints.add().linear.CopyFrom(cp_model_pb2.LinearConstraintProto(vars=[v for v,k in t],coeffs=[k for v,k in t],domain=[-2**63,h['bound']]))
    case=next(c['index'] for c in spec['mutual_cases'] if [c['profile_a'],c['profile_b']]==[a['profile'],b['profile']]);assert case==r['mutual_case'];faces=load(SOURCE/'mutual'/f'{case:03d}.json')['faces'];count=0
    for f in faces:
        flags=[]
        for j,h in enumerate(f['outside_halfplanes']):
            flag=len(expected.variables);flags.append(flag);expected.variables.add(name=f"f{f['index']}-edge{j}",domain=[0,1]);c=expected.constraints.add(enforcement_literal=[flag]);coeff=[-h['a'],-h['b'],h['a'],h['b']];c.linear.vars.extend(k for k in range(4) if coeff[k]);c.linear.coeffs.extend(v for v in coeff if v);c.linear.domain.extend([h['bound'],2**63-1]);count+=1
        expected.constraints.add().bool_or.literals.extend(flags)
    saved=cp_model_pb2.CpModelProto();saved.ParseFromString((BASE/'models'/f'{i:03d}.pb').read_bytes());assert saved==expected;assert len(saved.variables)==r['variables'] and len(saved.constraints)==r['constraints'] and count==r['planes'] and len(faces)==r['faces'];assert digest(BASE/'models'/f'{i:03d}.pb')==r['model_sha256']
    actual=cp_model.CpModel();assert actual.proto.parse_text_format((BASE/'models'/f'{i:03d}.pbtxt').read_text()) and actual.validate()=='';out=OUT/f'{i:03d}-roundtrip.pb';assert actual.export_to_file(str(out));roundtrip=cp_model_pb2.CpModelProto();roundtrip.ParseFromString(out.read_bytes());assert roundtrip==saved;checks.append({'pair':i,'parts':[a['part'],b['part']],'variables':r['variables'],'constraints':r['constraints'],'passed':True})
write(OUT/'pairs.json',checks);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'models':46,'all_variables_constraints_reconstructed':True,'all_full_guarded_source_faces_preserved':True,'actual_import_export_verified':True,'only_declared_selected_pair_scope':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
