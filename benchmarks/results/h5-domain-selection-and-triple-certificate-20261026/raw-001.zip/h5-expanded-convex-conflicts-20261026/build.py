"""Refine every unmarked box pair with complete convex-domain difference hulls."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import shape

ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-expanded-domain-conflicts-20261026';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';OUT=ROOT/'output/h5-expanded-convex-conflicts-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(OLD/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    spec=load(OLD/'plan.json');oldresult=load(OLD/'result.json');queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in load(SOURCE/'plan.json')['queries']}
    arrays={};nverts={}
    for qi,row in queries.items():
        lists=[list(shape(d['inset_face']).exterior.coords)[:-1] for d in row['domains']];count=max(map(len,lists));assert count>=3
        arrays[qi]=np.array([v+[v[0]]*(count-len(v)) for v in lists],dtype=float);nverts[qi]=count
    remaining=oldresult['complete_domain_pair_census']-oldresult['certified_conflicts'];assert remaining==5489250
    inputs=[OLD/'plan.json',OLD/'result.json',OLD/'audit/checks.json',SOURCE/'plan.json',ROOT/'benchmarks/results/h5-projected-source-and-fresh-conflicts-20261026/raw-manifest.json',
        ROOT/'benchmarks/results/h5-projected-source-and-fresh-conflicts-20261026/fresh-conflict-audit.json']
    plan={**spec,'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'construction_limit_seconds':360,'maximum_refined_pairs':5500000,'old_box_conflicts_retained':oldresult['certified_conflicts'],'unmarked_pairs_planned':remaining,
        'convex_difference_padding_mm':.00001,'maximum_batch_pairs':2048,'maximum_batch_vertex_pairs':131072,
        'query_maximum_vertices':nverts,'source_case_hashes':{str(c['index']):{'metadata':digest(OLD/'cases'/f"{c['index']:03d}.json"),'packed':digest(OLD/'cases'/f"{c['index']:03d}.bin")} for c in spec['cases']},
        'source_core_hashes':{str(i):digest(OLD/'cores'/f'{i:03d}.json') for i in range(82)},
        'method':'Retain every certified box conflict bit. Test ALL5,489,250 remaining unique domain pairs by forming the convex hull of every B-vertex minus A-vertex of the actual inward allowed faces, then pad that whole hull outward by0.00001mm. Mark a new conflict only when the entire padded convex difference is strictly contained in the independently certified inset original no-fit core. This is a whole-polytope containment test, not corner sampling. Process complete prelisted164-case census in bounded vector batches, preserving all counts, exact source hashes, pending cases and any time cap. A false bit is not evidence of anchor feasibility. No solver call.'}
    write(OUT/'plan.json',plan);start=time.perf_counter();deadline=start+360;cores={}
    for i in range(82):
        core=shape(load(OLD/'cores'/f'{i:03d}.json')['core']);shapely.prepare(core);cores[i]=core
    summary=[];tested=added=0
    for case in spec['cases']:
        if time.perf_counter()>=deadline:break
        index=case['index'];meta=load(OLD/'cases'/f'{index:03d}.json');raw=(OLD/'cases'/f'{index:03d}.bin').read_bytes()
        flags=np.unpackbits(np.frombuffer(raw,dtype=np.uint8),bitorder='big')[:case['domain_pairs']].reshape(case['rows_a'],case['rows_b']).astype(bool)
        ai,bi=np.nonzero(~flags);a,b=arrays[case['query_a']],arrays[case['query_b']];batch=max(1,min(2048,131072//(a.shape[1]*b.shape[1])));checked=found=0
        for lo in range(0,len(ai),batch):
            if time.perf_counter()>=deadline:break
            ia,ib=ai[lo:lo+batch],bi[lo:lo+batch]
            differences=(b[ib,None,:,:]-a[ia,:,None,:]).reshape(len(ia),-1,2)
            hulls=shapely.convex_hull(shapely.multipoints(differences));padded=shapely.buffer(hulls,.00001,join_style='mitre')
            good=shapely.contains_properly(cores[case['mutual_case']],padded)
            assert not np.any(shapely.is_empty(padded));flags[ia[good],ib[good]]=True;checked+=len(ia);found+=int(np.count_nonzero(good))
        blob=np.packbits(flags.reshape(-1),bitorder='big').tobytes();path=OUT/'cases'/f'{index:03d}.bin'
        with path.open('xb') as f:f.write(blob)
        complete=checked==len(ai)
        row={**meta,'packed_bytes':len(blob),'packed_sha256':digest(path),'conflicts':int(np.count_nonzero(flags)),
            'source_box_conflicts':meta['conflicts'],'unmarked_pairs_planned':len(ai),'unmarked_pairs_tested':checked,'new_convex_conflicts':found,
            'unmarked_pairs_remaining':len(ai)-checked,'complete_convex_refinement':complete}
        assert row['conflicts']==meta['conflicts']+found;write(OUT/'cases'/f'{index:03d}.json',row)
        summary.append({k:v for k,v in row.items() if not k.startswith('domain_indices')});tested+=checked;added+=found
        if len(summary)%10==0:print({'cases':len(summary),'remaining_pairs_tested':tested,'new_conflicts':added,'seconds':time.perf_counter()-start},flush=True)
        if not complete:break
    pending=[{**c,'unmarked_pairs_tested':summary[c['index']]['unmarked_pairs_tested'] if c['index']<len(summary) else 0} for c in spec['cases'] if c['index']>=len(summary) or not summary[c['index']]['complete_convex_refinement']]
    write(OUT/'pending-cases.json',pending);write(OUT/'case-summary.json',summary)
    result={'seconds':time.perf_counter()-start,'complete_domain_pair_census':spec['complete_domain_pair_census'],'old_box_conflicts_retained':oldresult['certified_conflicts'],
        'unmarked_pairs_planned':remaining,'unmarked_pairs_tested':tested,'new_convex_conflicts':added,'certified_conflicts':oldresult['certified_conflicts']+added,
        'refinement_pairs_remaining':remaining-tested,'completed_cases':sum(r['complete_convex_refinement'] for r in summary),'pending_cases':len(pending),
        'independent_audit_pending':True,'not_marked_is_not_feasibility_proof':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
