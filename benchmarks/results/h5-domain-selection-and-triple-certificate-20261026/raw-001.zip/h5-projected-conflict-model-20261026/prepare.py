"""Append only the freshly proved54-fixed domain conflicts to the full projected model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-projected-expanded-model-20261026';CONFLICTS=ROOT/'output/h5-expanded-domain-conflicts-20261026';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';OUT=ROOT/'output/h5-projected-conflict-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed'] and load(CONFLICTS/'audit/checks.json')['passed'] and load(CONFLICTS/'groups/audit/checks.json')['passed']
    names=['plan.json','model.pb','mapping.json','result.json','audit/checks.json','shared-directions.json','projections.json','replacements.json','necessary-rules.json','advisory-hints.json'];paths=[PARENT/n for n in names]+[CONFLICTS/n for n in ['plan.json','result.json','audit/checks.json','groups/result.json','groups/audit/checks.json']]+[SOURCE/'plan.json']+sorted((CONFLICTS/'groups').glob('[0-9][0-9][0-9].json'))+sorted((CONFLICTS/'cases').glob('*'))+sorted((SOURCE/'queries').glob('*.json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Keep the complete audited223086-variable/289916-constraint one-sided signed-projection parent and all54 hints. Append only the freshly54-fixed independently certified3,948,295 unique whole-domain collision exclusions, representing25,189,075 physical uses over538 modes. A group Boolean equals the sum of its mutually exclusive A-domain flags; add at-most-one with marked B-domain selectors, or OR(not group,not B mode) if all B rows conflict. All mandatory originals, source planes, projection equalities, area/capacity constraints and exact coordinate domains remain. False table bits imply no feasible-anchor claim. No old fixed57 table or geometry/witness restriction is added. Audit complete parent retention, every bit/group mapping and actual import before any new separately bounded call.'})
    model=cp_model_pb2.CpModelProto();model.ParseFromString((PARENT/'model.pb').read_bytes());assert len(model.variables)==223086 and len(model.constraints)==289916;mapping=load(PARENT/'mapping.json');spec=load(CONFLICTS/'plan.json');groups={c['index']:load(CONFLICTS/'groups'/f"{c['index']:03d}.json") for c in spec['cases']};details=[];literals=physical=0
    for pair in spec['physical_pair_case_uses']:
        i,j=pair['parts'];a,b=[mapping['parts'][k] for k in [i,j]]
        for caseid in pair['cases']:
            row=groups[caseid];case=row['case'];qa=next(m for m in a['modes'] if m['query']==case['query_a']);qb=next(m for m in b['modes'] if m['query']==case['query_b']);assert len(qa['domains'])==case['rows_a'] and len(qb['domains'])==case['rows_b']
            for group in row['groups']:
                if not group['conflicts_per_a_row']:continue
                start_constraint=len(model.constraints);da=[qa['domains'][k] for k in group['rows_a']];raw=bytes.fromhex(group['forbidden_b_hex']);forbidden=[qb['domains'][k] for k in range(case['rows_b']) if raw[k//8]&(1<<(7-k%8))];assert len(forbidden)==group['conflicts_per_a_row'];physical+=len(da)*len(forbidden)
                if len(da)==1:flag=da[0]
                else:
                    flag=len(model.variables);model.variables.add(name=f"fresh-pair{i}-{j}-case{caseid}-group{group['group']}",domain=[0,1]);terms=sorted([(v,1) for v in da]+[(flag,-1)]);c=model.constraints.add();c.linear.vars.extend(v for v,n in terms);c.linear.coeffs.extend(n for v,n in terms);c.linear.domain.extend([0,0])
                c=model.constraints.add()
                if len(forbidden)==len(qb['domains']):c.bool_or.literals.extend([-flag-1,-qb['active']-1]);literals+=2
                else:c.at_most_one.literals.extend([flag]+forbidden);literals+=1+len(forbidden)
                details.append({'parts':[i,j],'case':caseid,'group':group['group'],'flag':flag,'constraint_span':[start_constraint,len(model.constraints)]})
    assert len(model.variables)==227096 and len(model.constraints)==298613 and len(details)==4687 and literals==1099261 and physical==25189075
    mapping['fresh_domain_conflict_groups']=details;write(OUT/'mapping.json',mapping)
    for name in ['shared-directions.json','projections.json','replacements.json','necessary-rules.json','advisory-hints.json']:shutil.copyfile(PARENT/name,OUT/name)
    write(OUT/'transformation.json',{'retained_parent_variables':223086,'retained_parent_constraints':289916,'appended_conflict_auxiliaries':4010,'appended_conflict_constraints':8697,'nonzero_physical_groups':4687,'mutual_exclusion_literals':literals,'unique_proven_domain_conflicts':3948295,'physical_proven_domain_conflicts':physical,'physical_pair_modes':538,'all_parent_area_capacity_and_source_constraints_retained':True,'hints_retained':54,'new_geometry_exclusions':0})
    (OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');result={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':54,'fresh_conflict_auxiliaries':4010,'fresh_conflict_constraints':8697,'nonzero_physical_groups':len(details),'unique_proven_domain_conflicts':3948295,'physical_proven_domain_conflicts':physical,'model_sha256':digest(OUT/'model.pb'),'required_originals':66,'moving_originals':12,'fixed_originals':54,'same_sheet_pair_modes':538,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
