"""Reconstruct every fresh conflict clause and preserve the complete projected parent."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
from collections import Counter
import json,time,shutil,traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-projected-conflict-model-20261026';PARENT=ROOT/'output/h5-projected-expanded-model-20261026';CONFLICTS=ROOT/'output/h5-expanded-domain-conflicts-20261026';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Verify parent, all fresh matrix/group/source inputs against committed evidence. Reconstruct all164 matrices bit-for-bit as integer rows, independently check every group partition and complete66-pair/538-mode inventory. Reconstruct every appended group variable/equation and exclusion with exact source domain order. Remove appended variables/constraints to restore the full parent proto. Verify unchanged hints/other fields and actual solver import/export. No solver.'})
    manifest=load(ROOT/'benchmarks/results/h5-projected-source-and-fresh-conflicts-20261026/raw-manifest.json');known={r['sha256'] for r in manifest['files']+manifest['aliases']}
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h and h in known,n
    for n,h in load(PARENT/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    assert load(PARENT/'audit/checks.json')['passed'] and load(CONFLICTS/'audit/checks.json')['all_exclusions_covered_by_whole_original_obstacle'] and load(CONFLICTS/'groups/audit/checks.json')['passed']
    parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model.pb').read_bytes());child=cp_model_pb2.CpModelProto();child.ParseFromString((BASE/'model.pb').read_bytes());nv,nc=len(parent.variables),len(parent.constraints);assert (nv,nc)==(223086,289916)
    pm=load(PARENT/'mapping.json');cm=load(BASE/'mapping.json');assert {k:v for k,v in cm.items() if k!='fresh_domain_conflict_groups'}==pm
    for n in ['shared-directions.json','projections.json','replacements.json','necessary-rules.json','advisory-hints.json']:assert (BASE/n).read_bytes()==(PARENT/n).read_bytes()
    spec=load(SOURCE/'plan.json');cp=load(CONFLICTS/'plan.json');wanted=sorted({(qa,qb) for a,b in combinations(spec['parts'],2) for qa,qb in product(a['queries'],b['queries']) if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']});assert wanted==[(c['query_a'],c['query_b']) for c in cp['cases']] and len(wanted)==164;ci={pair:i for i,pair in enumerate(wanted)};inventory=[]
    for a,b in combinations(spec['parts'],2):inventory.append({'parts':[a['part'],b['part']],'cases':[ci[(qa,qb)] for qa,qb in product(a['queries'],b['queries']) if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']]})
    assert inventory==cp['physical_pair_case_uses'] and len(inventory)==66 and sum(len(p['cases']) for p in inventory)==538;groups={};bitcount=unique=0
    for case in cp['cases']:
        i=case['index'];r=load(CONFLICTS/'groups'/f'{i:03d}.json');meta=load(CONFLICTS/'cases'/f'{i:03d}.json');blob=(CONFLICTS/'cases'/f'{i:03d}.bin').read_bytes();assert r['case']==case and sha256(blob).hexdigest()==r['source_packed_sha256']==meta['packed_sha256'];assert r['source_metadata_sha256']==digest(CONFLICTS/'cases'/f'{i:03d}.json')
        n=case['domain_pairs'];pad=len(blob)*8-n;whole=int.from_bytes(blob,'big');assert whole&((1<<pad)-1)==0;whole>>=pad;mask=(1<<case['rows_b'])-1;seen=[];rowcount=0
        for g in r['groups']:
            encoded=bytes.fromhex(g['forbidden_b_hex']);bits=int.from_bytes(encoded,'big');padding=len(encoded)*8-case['rows_b'];assert bits&((1<<padding)-1)==0;bits>>=padding;assert bits.bit_count()==g['conflicts_per_a_row']
            for a in g['rows_a']:assert ((whole>>((case['rows_a']-1-a)*case['rows_b']))&mask)==bits;seen.append(a)
            rowcount+=len(g['rows_a'])*bits.bit_count()
        assert sorted(seen)==list(range(case['rows_a'])) and rowcount==meta['conflicts'];bitcount+=n;unique+=rowcount
        for side in ['a','b']:
            query=load(SOURCE/'queries'/f"{case['query_'+side]:03d}.json");assert len(query['domains'])==case['rows_'+side] and [d['index'] for d in query['domains']]==meta['domain_indices_'+side]
        groups[i]=r
    assert bitcount==9437545 and unique==3948295;v=nv;c=nc;details=[];physical=literals=0
    for pair in inventory:
        ia,ib=pair['parts'];a,b=pm['parts'][ia],pm['parts'][ib]
        for caseid in pair['cases']:
            row=groups[caseid];case=row['case'];qa=next(m for m in a['modes'] if m['query']==case['query_a']);qb=next(m for m in b['modes'] if m['query']==case['query_b']);assert len(qa['domains'])==case['rows_a'] and len(qb['domains'])==case['rows_b']
            for g in row['groups']:
                if not g['conflicts_per_a_row']:continue
                begin=c;aflags=[qa['domains'][i] for i in g['rows_a']];raw=bytes.fromhex(g['forbidden_b_hex']);bits=int.from_bytes(raw,'big')>>(len(raw)*8-case['rows_b']);forbidden=[qb['domains'][i] for i in range(case['rows_b']) if bits&(1<<(case['rows_b']-1-i))];assert len(forbidden)==g['conflicts_per_a_row'];physical+=len(aflags)*len(forbidden)
                if len(aflags)>1:
                    flag=v;assert child.variables[v]==cp_model_pb2.IntegerVariableProto(name=f"fresh-pair{ia}-{ib}-case{caseid}-group{g['group']}",domain=[0,1]);v+=1;terms={q:1 for q in aflags};assert len(terms)==len(aflags);terms[flag]=-1;ids=sorted(terms);eq=cp_model_pb2.ConstraintProto();eq.linear.vars.extend(ids);eq.linear.coeffs.extend(terms[i] for i in ids);eq.linear.domain.extend([0,0]);assert child.constraints[c]==eq;c+=1
                else:flag=aflags[0]
                constraint=cp_model_pb2.ConstraintProto()
                if len(forbidden)==len(qb['domains']):constraint.bool_or.literals.extend([-flag-1,-qb['active']-1]);literals+=2
                else:constraint.at_most_one.literals.extend([flag]+forbidden);literals+=len(forbidden)+1
                assert child.constraints[c]==constraint;c+=1;details.append({'parts':[ia,ib],'case':caseid,'group':g['group'],'flag':flag,'constraint_span':[begin,c]})
    assert details==cm['fresh_domain_conflict_groups'] and len(details)==4687 and physical==25189075 and literals==1099261 and v==len(child.variables)==227096 and c==len(child.constraints)==298613
    assert child.variables[:nv]==parent.variables and child.constraints[:nc]==parent.constraints and child.solution_hint==parent.solution_hint and len(child.solution_hint.vars)==54;restored=cp_model_pb2.CpModelProto();restored.CopyFrom(child);del restored.variables[nv:];del restored.constraints[nc:];assert restored==parent
    write(OUT/'equivalence-proof.json',{'complete_parent_retained':True,'physical_reason':'Each marked domain pair has its entire outward-padded difference rectangle strictly inside an independently reconstructed original collision obstacle. Its simultaneous selection cannot satisfy the retained original guarded pair clauses. Thus every appended physical exclusion is already necessary for the full parent.','group_encoding':'One mandatory A original selects exactly one domain across all its modes; a subset sum of those mutually exclusive domain flags is Boolean. Each B original also selects exactly one domain, so at-most-one(group,marked B flags) is exactly every recorded A-group/B-row pairwise exclusion, without adding restrictions between any co-selectable B flags. For all-B conflicts the B-mode flag equals its domain sum, so OR(not group,not B active) is equivalent.','reverse':'Dropping only appended variables/constraints restores the complete parent proto, including all fields and54 hints.','scope':'Same physical feasible projection within the source12-mover/54-fixed finite-angle/inward-grid construction. No unmarked pair is claimed feasible and no old fixed57 conditional exclusion is used.'})
    real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'solver-import-roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert actual==child and digest(BASE/'model.pb')==load(BASE/'result.json')['model_sha256']
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_inputs_verified':len(load(BASE/'plan.json')['inputs']),'variables':v,'constraints':c,'hints':54,'complete_parent_retained':True,'complete_parent_restored_exactly':True,'every_fresh_conflict_group_verified':True,'all_fresh_matrix_bits_replayed':bitcount,'unique_conflicts_verified':unique,'physical_conflicts_verified':physical,'fresh_auxiliaries':v-nv,'fresh_constraints':c-nc,'physical_nonzero_groups':len(details),'mutual_exclusion_literals':literals,'actual_solver_import_export_verified':True,'required_originals':66,'moving_originals':12,'fixed_originals':54,'same_sheet_pair_modes':538,'original_anchor_variables':24,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
