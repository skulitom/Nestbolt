"""Independent whole-model reconstruction of the fresh necessary domain master."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,time,shutil,traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-expanded-domain-master-20261026';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';CONFLICTS=ROOT/'output/h5-expanded-convex-conflicts-20261026';RULES=ROOT/'output/h5-projected-expanded-model-20261026/necessary-rules.json';CAP=ROOT/'output/h5-expanded-second-sheet-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Verify fresh refined collision/audit/symmetry hash chains and committed source/capacity/area inputs. Reconstruct every variable, part/query/domain/choice equation, two necessary area rules, fresh capacity, precisely nine certified family orders, and every refined conflict group. Verify complete physical pair inventory, every domain flag mapping and sorted advisory hint. Reject all unexamined fields/constraints and compare actual solver import/export. Necessary master only: no coordinate or layout feasibility is asserted.'})
    known=set()
    for name in ['h5-projected-source-and-fresh-conflicts-20261026','h5-expanded-source-search-20261026','h5-expanded-cog-neighborhood-20261026']:
        m=load(ROOT/'benchmarks/results'/name/'raw-manifest.json');known.update(r['sha256'] for r in m['files']+m['aliases'])
    for n,h in load(BASE/'plan.json')['inputs'].items():
        assert digest(ROOT/n)==h,n
        if 'h5-expanded-convex-conflicts-20261026/' not in n:assert h in known,n
    for p,key in [(CONFLICTS/'audit/plan.json','input_hashes'),(CONFLICTS/'groups/audit/plan.json','input_hashes'),(CONFLICTS/'copy-symmetry/plan.json','inputs')]:
        for n,h in load(p)[key].items():assert digest(ROOT/n)==h,n
    assert all(load(p)['passed'] for p in [CONFLICTS/'audit/checks.json',CONFLICTS/'groups/audit/checks.json',CONFLICTS/'copy-symmetry/checks.json',CAP/'audit/checks.json']);spec=load(SOURCE/'plan.json');mapping=load(BASE/'mapping.json');model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'model.pb').read_bytes());assert {f.name for f,v in model.ListFields()}=={'variables','constraints','solution_hint'};vc=cc=0
    def variable(index,name,lo=0,hi=1):
        nonlocal vc
        assert index==vc and model.variables[index]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]);vc+=1
    def linear(terms,lo=-2**63,hi=2**63-1):
        nonlocal cc
        coeff={}
        for v,n in terms:coeff[v]=coeff.get(v,0)+n
        ids=sorted(i for i in coeff if coeff[i]);c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(ids);c.linear.coeffs.extend(coeff[i] for i in ids);c.linear.domain.extend([lo,hi]);assert model.constraints[cc]==c,cc;cc+=1
    queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']};parts=mapping['parts'];assert len(parts)==12 and len(spec['fixed_items'])==54 and sorted(spec['fixed_items']+[p['index'] for p in spec['parts']])==list(range(66));modes={}
    for original,p in zip(spec['parts'],parts):
        pi=original['part'];assert p['part']==pi and p['item']==original['index'] and p['family']==original['family'];variable(p['sheet'],f'p{pi}-sheet');total=sum(len(queries[q]['domains']) for q in original['queries']);variable(p['choice'],f'p{pi}-choice',0,total-1);assert [m['query'] for m in p['modes']]==original['queries'];flat=[];offset=0
        for m in p['modes']:
            qi=m['query'];assert m['choice_offset']==offset and len(m['domains'])==len(queries[qi]['domains']);variable(m['active'],f'p{pi}-q{qi}')
            for row,flag in enumerate(m['domains']):variable(flag,f'p{pi}-q{qi}-d{row}');flat.append((flag,offset+row))
            linear([(f,1) for f in m['domains']]+[(m['active'],-1)],0,0);modes[pi,qi]=m;offset+=len(m['domains'])
        linear([(m['active'],1) for m in p['modes']],1,1);linear([(p['sheet'],1)]+[(m['active'],-spec['queries'][m['query']]['sheet']) for m in p['modes']],0,0);linear([(p['choice'],1)]+[(f,-i) for f,i in flat],0,0)
    assert (vc,cc)==(12764,88);rules=load(RULES);charges=rules['filled_area_lower_units'];total=sum(charges[p['family']] for p in parts);assert rules['fixed_area_lower_units']==spec['fixed_original_area_units_per_sheet'];linear([(p['sheet'],-charges[p['family']]) for p in parts],hi=rules['stock_area_upper_units'][0]-rules['fixed_area_lower_units'][0]-total);linear([(p['sheet'],charges[p['family']]) for p in parts],hi=rules['stock_area_upper_units'][1]-rules['fixed_area_lower_units'][1]);cap=load(CAP/'certificate.json');assert digest(CAP/'certificate.json')==rules['capacity_certificate_sha256'];linear([(modes[i,19]['active'],1) for i in cap['applicable_moving_parts']],hi=2)
    orders=[[0,1]]+[[i,i+1] for i in range(3,11)];assert orders==mapping['choice_order_pairs']==load(CONFLICTS/'copy-symmetry/checks.json')['proposed_choice_order_pairs']
    for i,j in orders:assert spec['parts'][i]['family']==spec['parts'][j]['family'] and spec['parts'][i]['queries']==spec['parts'][j]['queries'] and spec['parts'][i]['profiles']==spec['parts'][j]['profiles'];linear([(parts[i]['choice'],1),(parts[j]['choice'],-1)],hi=0)
    cp=load(CONFLICTS/'plan.json');ci={(c['query_a'],c['query_b']):c['index'] for c in cp['cases']};inventory=[{'parts':[a['part'],b['part']],'cases':[ci[qa,qb] for qa,qb in product(a['queries'],b['queries']) if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']]} for a,b in combinations(spec['parts'],2)];assert inventory==cp['physical_pair_case_uses'] and len(inventory)==66 and sum(len(p['cases']) for p in inventory)==538
    groups={c['index']:load(CONFLICTS/'groups'/f"{c['index']:03d}.json") for c in cp['cases']};details=[];literals=physical=0
    for pair in inventory:
        ia,ib=pair['parts']
        for caseid in pair['cases']:
            row=groups[caseid];case=row['case'];qa,qb=modes[ia,case['query_a']],modes[ib,case['query_b']];assert len(qa['domains'])==case['rows_a'] and len(qb['domains'])==case['rows_b']
            for g in row['groups']:
                if not g['conflicts_per_a_row']:continue
                begin=cc;aa=[qa['domains'][i] for i in g['rows_a']];raw=bytes.fromhex(g['forbidden_b_hex']);value=int.from_bytes(raw,'big')>>(len(raw)*8-case['rows_b']);bb=[qb['domains'][i] for i in range(case['rows_b']) if value&(1<<(case['rows_b']-1-i))];assert len(bb)==g['conflicts_per_a_row'];physical+=len(aa)*len(bb)
                if len(aa)>1:flag=vc;variable(flag,f'group-{ia}-{ib}-{caseid}-{g["group"]}');linear([(f,1) for f in aa]+[(flag,-1)],0,0)
                else:flag=aa[0]
                c=cp_model_pb2.ConstraintProto()
                if len(bb)==len(qb['domains']):c.bool_or.literals.extend([-flag-1,-qb['active']-1]);literals+=2
                else:c.at_most_one.literals.extend([flag]+bb);literals+=1+len(bb)
                assert model.constraints[cc]==c;cc+=1;details.append({'parts':[ia,ib],'case':caseid,'group':g['group'],'flag':flag,'constraint_span':[begin,cc]})
    assert details==mapping['groups'] and vc==len(model.variables)==17039 and cc==len(model.constraints)==9793 and physical==25543004 and literals==1255748
    originals=load(SOURCE/'audit/verified-partial-domain-membership.json');sorted_hints=sorted(originals,key=lambda r:((0 if r['query']==18 else len(queries[18]['domains']))+min(m['row'] for m in r['matching_domains']),r['anchor_units1000'],r['item']));hint_records=[];values=[]
    for pi,r in zip(range(3,12),sorted_hints):
        p=parts[pi];row=min(d['row'] for d in r['matching_domains']);m=modes[pi,r['query']];choice=m['choice_offset']+row;vs=[[p['sheet'],spec['queries'][r['query']]['sheet']],[p['choice'],choice],[m['active'],1],[m['domains'][row],1]];values+=vs;hint_records.append({'source_partial_item':r['item'],'assigned_part':pi,'assigned_item':p['item'],'query':r['query'],'domain_row':row,'choice_index':choice,'values':vs})
    assert hint_records==load(BASE/'advisory-hints.json') and [v for v,n in values]==list(model.solution_hint.vars) and [n for v,n in values]==list(model.solution_hint.values) and len(values)==36
    real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'solver-import-roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert actual==model and digest(BASE/'model.pb')==load(BASE/'result.json')['model_sha256']
    checks={'passed':True,'seconds':time.perf_counter()-start,'variables':vc,'constraints':cc,'hints':36,'required_originals':66,'moving_originals':12,'fixed_originals':54,'domain_flags':12688,'query_modes':52,'physical_pairs':66,'same_sheet_pair_modes':538,'physical_conflict_uses_verified':physical,'mutual_exclusion_literals':literals,'every_variable_and_constraint_reconstructed':True,'certified_family_orders_only_in_necessary_master':9,'actual_solver_import_export_verified':True,'no_coordinate_feasibility_claim':True,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
