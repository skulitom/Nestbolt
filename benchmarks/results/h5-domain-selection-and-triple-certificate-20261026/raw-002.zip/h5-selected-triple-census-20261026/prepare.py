"""Exact shared-coordinate conjunctions of the audited pair models, no solving."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PAIR=ROOT/'output/h5-selected-pair-census-20261026';OUT=ROOT/'output/h5-selected-triple-census-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PAIR/'model-audit/checks.json')['passed'] and load(PAIR/'response-audit/checks.json')['all46_source_pairs_have_verified_witnesses'];rows=load(PAIR/'inventory.json');lookup={(r['a']['part'],r['b']['part']):r for r in rows};parts={p['part']:p for r in rows for p in [r['a'],r['b']]};triples=[t for t in combinations(sorted(parts),3) if len({parts[i]['sheet'] for i in t})==1];assert len(triples)==120
paths=[PAIR/'inventory.json',PAIR/'model-audit/checks.json',PAIR/'response-audit/checks.json']+list((PAIR/'models').glob('*.pb'));write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'All120 same-sheet triples from the exact closed12-domain selection. Conjoin the three independently audited full-source pair models, identifying only the repeated original x/y variables; preserve every parent constraint and give each parent auxiliary a separate variable. Coordinates stay in the original selected domains. All other originals are omitted, making each model a relaxation of that particular full-source domain tuple. Negative scope is only the listed three physical item/query/domain choices. Pair witnesses do not combine automatically. Independent whole-model mapping/import audit required before at most one call per triple,0.25seconds each,one worker,seed0,60seconds shared. No retry/reseed/extension. No unrestricted/native/material claim.'});inventory=[]
for i,triple in enumerate(triples):
    model=cp_model_pb2.CpModelProto();coord={};links=[]
    for pi in triple:
        r=next(r for r in rows if pi in [r['a']['part'],r['b']['part']]);p=cp_model_pb2.CpModelProto();p.ParseFromString((PAIR/'models'/f"{r['index']:03d}.pb").read_bytes());offset=0 if r['a']['part']==pi else 2
        for axis in range(2):coord[pi,axis]=len(model.variables);model.variables.add().CopyFrom(p.variables[offset+axis])
    for aa,bb in combinations(triple,2):
        r=lookup[aa,bb];parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PAIR/'models'/f"{r['index']:03d}.pb").read_bytes());mapping=[coord[aa,0],coord[aa,1],coord[bb,0],coord[bb,1]]
        for v in parent.variables[4:]:
            mapping.append(len(model.variables));copy=model.variables.add();copy.CopyFrom(v);copy.name=f"pair{r['index']}-"+v.name
        begin=len(model.constraints)
        def literal(v):return mapping[v] if v>=0 else -mapping[-v-1]-1
        for c in parent.constraints:
            copy=model.constraints.add();copy.CopyFrom(c);copy.enforcement_literal[:]=[literal(v) for v in c.enforcement_literal];kind=c.WhichOneof('constraint')
            if kind=='linear':copy.linear.vars[:]=[mapping[v] for v in c.linear.vars]
            else:assert kind=='bool_or';copy.bool_or.literals[:]=[literal(v) for v in c.bool_or.literals]
        links.append({'pair':r['index'],'variables':mapping,'constraints':[begin,len(model.constraints)]})
    path=OUT/'models'/f'{i:03d}.pb';path.write_bytes(model.SerializeToString());path.with_suffix('.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');inventory.append({'index':i,'parts':list(triple),'selection':[parts[p] for p in triple],'parent_pairs':links,'variables':len(model.variables),'constraints':len(model.constraints),'model_sha256':digest(path)})
write(OUT/'inventory.json',inventory);write(OUT/'prepared.json',{'models':120,'seconds':time.perf_counter()-start,'solver_calls':0});print(load(OUT/'prepared.json'))
