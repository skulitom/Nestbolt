"""Readback for120 closed triple subproblems; retain negatives and all timeouts."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-selected-triple-census-20261026';RUN=BASE/'search';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify whole source/model chains, actual solver models/parameters, complete declared120-triple inventory, exactly one closed call per triple, response statuses and elapsed budgets. For every positive check every variable and active constraint, all original selected domain planes and all three source pair face disjunctions directly. Retain UNKNOWN without exclusions. INFEASIBLE is the saved solver conclusion for only that fixed three-item/query/domain subproblem, not a general geometric impossibility or formal unsatisfiability certificate. No new solver/native calls.'})
for plan in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(plan)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];budget=load(RUN/'budget.json');proc=load(RUN/'process.json');census=load(RUN/'census.json');rows=load(BASE/'inventory.json');assert budget['shared_seconds']==60 and budget['deadline_perf_counter']==budget['start_perf_counter']+60 and budget['maximum_calls']==120 and budget['per_pair_solver_seconds']==.25;assert not proc['timeout'] and proc['exit_code']==0 and proc['seconds']<=60;assert not census['pending_pairs'] and len(census['results'])==census['solver_calls']==120 and len(list(RUN.rglob('opened.json')))==120;spec=load(SOURCE/'plan.json');checked=inside=faces=variables=0;verified=[];negatives=[];unknown=[]
for r,result in zip(rows,census['results']):
    i=r['index'];folder=RUN/f'{i:03d}';saved=load(folder/'result.json');opened=load(folder/'opened.json');assert saved==result and opened['maximum_calls']==saved['solver_calls']==1 and opened['pair']==i==saved['pair'];assert saved['parts']==r['parts'];model=cp_model_pb2.CpModelProto();model.ParseFromString((folder/'model.pb').read_bytes());expected=cp_model_pb2.CpModelProto();expected.ParseFromString((BASE/'models'/f'{i:03d}.pb').read_bytes());assert model==expected and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=.25,num_search_workers=1,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'];response=cp_model_pb2.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert cp_model_pb2.CpSolverStatus.Name(response.status)==saved['status'];assert abs(response.wall_time-saved['seconds'])<.1 and saved['seconds']<=saved['stage_seconds'];assert saved['solver_soft_overshoot_seconds']==max(0,saved['seconds']-.25);s=list(response.solution)
    if saved['status'] in ['UNKNOWN','INFEASIBLE']:
        assert not s and saved['original_coordinates_units1000'] is None
        (negatives if saved['status']=='INFEASIBLE' else unknown).append({'triple':i,'selection':r['selection'],'model_sha256':digest(folder/'model.pb'),'response_sha256':digest(folder/'response.pb'),'status':saved['status'],'scope':'Only these three physical item/query/domain choices under the original full source guards.'});continue
    assert saved['status'] in ['OPTIMAL','FEASIBLE'];assert len(s)==len(model.variables) and s[:6]==saved['original_coordinates_units1000']
    for v,n in zip(model.variables,s):assert any(lo<=n<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]));variables+=1
    for c in model.constraints:
        if not all(s[v] if v>=0 else not s[-v-1] for v in c.enforcement_literal):continue
        kind=c.WhichOneof('constraint')
        if kind=='linear':n=sum(s[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=n<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        else:assert kind=='bool_or' and any(s[v] if v>=0 else not s[-v-1] for v in c.bool_or.literals)
        checked+=1
    for j,p in enumerate(r['selection']):
        d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];x,y=s[2*j:2*j+2];assert d['index']==p['domain_index'] and d['coordinate_bounds'][0]<=x<=d['coordinate_bounds'][2] and d['coordinate_bounds'][1]<=y<=d['coordinate_bounds'][3]
        for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];inside+=1
    for (ia,a),(ib,b) in combinations(enumerate(r['selection']),2):
        case=next(c['index'] for c in spec['mutual_cases'] if [c['profile_a'],c['profile_b']]==[a['profile'],b['profile']]);dx,dy=s[2*ib]-s[2*ia],s[2*ib+1]-s[2*ia+1]
        for f in load(SOURCE/'mutual'/f'{case:03d}.json')['faces']:assert any(h['a']*dx+h['b']*dy>=h['bound'] for h in f['outside_halfplanes']);faces+=1
    verified.append({'triple':i,'selection':r['selection'],'status':saved['status'],'coordinates_units1000':s[:6],'three_part_source_feasible':True})
assert len(verified)+len(negatives)+len(unknown)==120;assert {s:sum(r['status']==s for r in census['results']) for s in census['counts']}==census['counts'];write(OUT/'verified-triple-witnesses.json',verified);write(OUT/'conditional-negative-triples.json',negatives);write(OUT/'unresolved-triples.json',unknown);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':120,'complete_inventory_verified':True,'positive_source_triples_verified':len(verified),'conditional_infeasible_triples':len(negatives),'unknown_triples':len(unknown),'actual_shared_seconds':proc['seconds'],'max_solver_seconds':max(r['seconds'] for r in census['results']),'sum_solver_seconds':sum(r['seconds'] for r in census['results']),'soft_limit_overruns':sum(r['solver_soft_overshoot_seconds']>0 for r in census['results']),'max_soft_limit_overrun_seconds':max(r['solver_soft_overshoot_seconds'] for r in census['results']),'all_positive_variables_checked':variables,'active_constraints_checked':checked,'source_inside_planes_checked':inside,'source_guarded_face_clauses_checked':faces,'formal_unsat_certificate_claimed':False,'full_target_witness':False,'native_validation_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
