"""Verify every triple is exactly three audited pair models with shared coordinates."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-selected-triple-census-20261026';PAIR=ROOT/'output/h5-selected-pair-census-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently verify complete120-triple inventory, exact repeated-coordinate variable domains, exhaustive disjoint auxiliary mappings and each entire parent constraint restored after inverse mapping. Reject all unexamined fields, constraints and variables; verify real import/export. This establishes exact conjunction of independently audited source pairs with common original coordinates. No solver or full-layout claim.'})
for plan in [BASE/'plan.json',PAIR/'plan.json',PAIR/'model-audit/plan.json']:
    for n,h in load(plan)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PAIR/'model-audit/checks.json')['passed'] and load(PAIR/'response-audit/checks.json')['all46_source_pairs_have_verified_witnesses'];pr=load(PAIR/'inventory.json');lookup={(r['a']['part'],r['b']['part']):r for r in pr};parts={p['part']:p for r in pr for p in [r['a'],r['b']]};expected=[list(t) for t in combinations(sorted(parts),3) if len({parts[i]['sheet'] for i in t})==1];rows=load(BASE/'inventory.json');assert len(rows)==120 and [r['parts'] for r in rows]==expected;verified=[]
for i,r in enumerate(rows):
    assert r['index']==i and r['selection']==[parts[p] for p in r['parts']];model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'models'/f'{i:03d}.pb').read_bytes());assert {f.name for f,v in model.ListFields()}=={'variables','constraints'};vc=6;cc=0;parents=[lookup[a,b] for a,b in combinations(r['parts'],2)];assert [z['pair'] for z in r['parent_pairs']]==[p['index'] for p in parents]
    for link,p in zip(r['parent_pairs'],parents):
        parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PAIR/'models'/f"{p['index']:03d}.pb").read_bytes());a,b=r['parts'].index(p['a']['part']),r['parts'].index(p['b']['part']);want=[2*a,2*a+1,2*b,2*b+1]+list(range(vc,vc+len(parent.variables)-4));assert link['variables']==want and link['constraints']==[cc,cc+len(parent.constraints)];inverse={v:k for k,v in enumerate(want)}
        for old,new in enumerate(want):
            var=cp_model_pb2.IntegerVariableProto();var.CopyFrom(model.variables[new]);
            if old>=4:assert var.name==f"pair{p['index']}-"+parent.variables[old].name;var.name=parent.variables[old].name
            assert var==parent.variables[old]
        def literal(v):return inverse[v] if v>=0 else -inverse[-v-1]-1
        for offset,source in enumerate(parent.constraints):
            c=cp_model_pb2.ConstraintProto();c.CopyFrom(model.constraints[cc+offset]);c.enforcement_literal[:]=[literal(v) for v in c.enforcement_literal];kind=c.WhichOneof('constraint')
            if kind=='linear':c.linear.vars[:]=[inverse[v] for v in c.linear.vars]
            else:assert kind=='bool_or';c.bool_or.literals[:]=[literal(v) for v in c.bool_or.literals]
            assert c==source
        vc+=len(parent.variables)-4;cc+=len(parent.constraints)
    assert vc==len(model.variables)==r['variables'] and cc==len(model.constraints)==r['constraints'];assert digest(BASE/'models'/f'{i:03d}.pb')==r['model_sha256'];actual=cp_model.CpModel();assert actual.proto.parse_text_format((BASE/'models'/f'{i:03d}.pbtxt').read_text()) and actual.validate()=='';path=OUT/f'{i:03d}-roundtrip.pb';assert actual.export_to_file(str(path));p=cp_model_pb2.CpModelProto();p.ParseFromString(path.read_bytes());assert p==model;verified.append({'triple':i,'parts':r['parts'],'passed':True,'parents_restored':3})
write(OUT/'triples.json',verified);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'models':120,'complete_same_sheet_triple_inventory':True,'parent_pair_models_restored_exactly':360,'six_original_coordinates_shared_correctly':True,'all_constraints_variables_accounted':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
