"""Create the separately bounded fresh-conflict runner and complete readback audit."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('run_h5_projected_expanded_search.py','run_h5_projected_conflict_search.py'),('audit_h5_projected_expanded_search.py','audit_h5_projected_conflict_search.py')]:
    dest=ROOT/'output'/target;assert not dest.exists();s=(ROOT/'output'/source).read_text()
    for a,b in [('h5-projected-expanded-search-20261026','h5-projected-conflict-search-20261026'),('h5-projected-expanded-model-20261026','h5-projected-conflict-model-20261026'),('223086','227096'),('289916','298613')]:assert a in s;s=s.replace(a,b)
    if source.startswith('run_'):
        old="checks['complete_parent_restored_exactly'] and checks['exact_two_way_parent_projection_verified']";assert old in s;s=s.replace(old,"checks['complete_parent_retained'] and checks['every_fresh_conflict_group_verified']")
        old='One distinct exact projection formulation replaces201575 shared-flag coordinate definitions with unary signed thresholds and8185 exactly defined integer projections. Independent two-way elimination restores the full12-mover parent.';assert old in s;s=s.replace(old,'One distinct fresh-conflict formulation retains the complete projected parent and appends4010 auxiliaries/8697 constraints for3,948,295 newly certified54-fixed domain conflicts. Independent bitwise and whole-model verification covers all25,189,075 physical conflict uses and every full original source clause.')
        old='One distinct exact signed-projection representation of the complete12-mover/54-fixed full-original source model; all parent source constraints and base variables retain their exact feasible projection.';assert old in s;s=s.replace(old,'One distinct full12-mover/54-fixed projected source formulation adds only fresh independently certified whole-domain conflicts. All parent constraints/variables/hints and physical feasible placements remain; no old fixed57 table or witness lock.')
    else:
        old="else:assert kind=='bool_or' and any(truth(v) for v in c.bool_or.literals)";assert old in s;s=s.replace(old,"elif kind=='at_most_one':assert sum(bool(truth(v)) for v in c.at_most_one.literals)<=1\n            else:assert kind=='bool_or' and any(truth(v) for v in c.bool_or.literals)")
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    print(dest)
