"""Certify every added conflict with exact outward vertex boxes and whole hulls."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import shape

ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-original-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';BASE=ROOT/'output/h5-convex-domain-conflicts-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
Q=1000000
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(BASE/'result.json')
    assert result['completed_cases']==164 and not load(BASE/'pending-cases.json') and result['refinement_pairs_remaining']==0
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':240,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(BASE.rglob('*')) if p.is_file() and OUT not in p.parents},
        'method':'Preserve all old certified conflict bits and independently verify every newly excluded pair. Quantize every actual inset-face vertex with exact Fraction arithmetic into an enclosing integer nanometre box, padded by one extra unit on all sides. For a new exclusion, form the complete hull of all four corners of every B-vertex-box minus A-vertex-box, a different enclosing construction from the builder floating difference plus miter buffer. Whole-hull strict containment in the committed independently verified original no-fit core certifies the whole convex domain pair. Verify all source hashes against the committed manifest, matrix dimensions, domain ordering, complete scan/pending counts, padding and added-bit counts. Unmarked entries are not asserted feasible; no solver call.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    manifest=load(ROOT/'benchmarks/results/h5-original-domain-conflicts-20261025/raw-manifest.json');certified={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    assert load(OLD/'audit/checks.json')['passed'];cores={};arrays={};enclosures=[];vertexchecks=0
    assert F(math.ulp(3001.0))<F(1,Q)
    for i in range(82):
        p=OLD/'cores'/f'{i:03d}.json';assert digest(p)==plan['source_core_hashes'][str(i)]==certified[p.relative_to(ROOT/'output').as_posix()]
        g=shape(load(p)['core']);shapely.prepare(g);cores[i]=g
    spec=load(SOURCE/'plan.json')
    for q in spec['queries']:
        p=SOURCE/'queries'/f"{q['index']:03d}.json";assert digest(p)==plan['query_hashes'][str(q['index'])]==certified['source-inputs/'+p.relative_to(ROOT).as_posix()]
        rows=load(p)['domains'];values=[]
        for row in rows:
            vertices=list(shape(row['inset_face']).exterior.coords)[:-1];bounds=[]
            for x,y in vertices:
                fx,fy=F(x)*Q,F(y)*Q;b=[math.floor(fx)-1,math.floor(fy)-1,math.ceil(fx)+1,math.ceil(fy)+1]
                assert b[0]+1<=fx<=b[2]-1 and b[1]+1<=fy<=b[3]-1;bounds.append(b);vertexchecks+=1
            values.append(bounds)
        width=max(map(len,values));arrays[q['index']]=np.array([v+[v[0]]*(width-len(v)) for v in values],dtype=np.int64)
        enclosures.append({'query':q['index'],'domain_indices':[r['index'] for r in rows],'vertex_bounds_units1000000':values})
    write(OUT/'vertex-enclosures.json',enclosures);newtotal=oldtotal=tested=0;checks=[]
    for c in plan['cases']:
        assert time.perf_counter()-start<240
        i=c['index'];meta=load(BASE/'cases'/f'{i:03d}.json');oldmeta=load(OLD/'cases'/f'{i:03d}.json');p=BASE/'cases'/f'{i:03d}.bin';op=OLD/'cases'/f'{i:03d}.bin'
        assert digest(OLD/'cases'/f'{i:03d}.json')==plan['source_case_hashes'][str(i)]['metadata'] and digest(op)==plan['source_case_hashes'][str(i)]['packed']
        assert digest(p)==meta['packed_sha256'] and p.stat().st_size==meta['packed_bytes']==(c['domain_pairs']+7)//8
        def decode(path):
            bits=np.unpackbits(np.frombuffer(path.read_bytes(),dtype=np.uint8),bitorder='big');assert not np.any(bits[c['domain_pairs']:]);return bits[:c['domain_pairs']].reshape(c['rows_a'],c['rows_b']).astype(bool)
        flags,old=decode(p),decode(op);assert not np.any(old & ~flags)
        for key in ['domain_indices_a','domain_indices_b','rows_a','rows_b','query_a','query_b','mutual_case']:assert meta[key]==oldmeta[key]
        assert all(meta[k]==v for k,v in c.items()) and meta['complete_convex_refinement']
        expected=c['domain_pairs']-int(np.count_nonzero(old));assert meta['unmarked_pairs_planned']==meta['unmarked_pairs_tested']==expected and meta['unmarked_pairs_remaining']==0
        ai,bi=np.nonzero(flags & ~old);assert len(ai)==meta['new_convex_conflicts'] and int(np.count_nonzero(flags))==meta['conflicts']==oldmeta['conflicts']+len(ai)
        a,b=arrays[c['query_a']],arrays[c['query_b']];batch=max(1,min(2048,131072//(4*a.shape[1]*b.shape[1])))
        for lo in range(0,len(ai),batch):
            assert time.perf_counter()-start<240
            av,bv=a[ai[lo:lo+batch]],b[bi[lo:lo+batch]]
            lx=bv[:,None,:,0]-av[:,:,None,2];ly=bv[:,None,:,1]-av[:,:,None,3]
            hx=bv[:,None,:,2]-av[:,:,None,0];hy=bv[:,None,:,3]-av[:,:,None,1]
            # Every exact vertex difference is at least two nanometres inside
            # its rectangle, more than the floating conversion ULP bound.
            corners=np.stack([np.stack([lx,ly],axis=-1),np.stack([lx,hy],axis=-1),np.stack([hx,hy],axis=-1),np.stack([hx,ly],axis=-1)],axis=-2).reshape(len(av),-1,2)
            assert np.max(np.abs(corners))<3001000000
            hulls=shapely.convex_hull(shapely.multipoints(corners/Q));assert not np.any(shapely.is_empty(hulls))
            assert np.all(shapely.contains_properly(cores[c['mutual_case']],hulls)),('new conflict failed independent whole-hull enclosure',i,lo)
        row={'case':i,'retained_original_box_conflicts':int(np.count_nonzero(old)),'new_whole_convex_conflicts_verified':len(ai),
            'all_added_pairs_have_complete_enclosing_hull_inside_original_core':True,'unmarked_pairs_scanned_by_builder':expected}
        write(OUT/'cases'/f'{i:03d}.json',row);checks.append(row);newtotal+=len(ai);oldtotal+=int(np.count_nonzero(old));tested+=expected
        if len(checks)%20==0:print({'cases_audited':len(checks),'new_conflicts_verified':newtotal,'seconds':time.perf_counter()-start},flush=True)
    assert newtotal==result['new_convex_conflicts'] and oldtotal==result['old_box_conflicts_retained'] and tested==result['unmarked_pairs_tested']==2996279
    summary={'passed':True,'seconds':time.perf_counter()-start,'complete_cases':164,'retained_original_box_conflicts':oldtotal,
        'new_whole_convex_conflicts_verified':newtotal,'total_certified_conflicts':oldtotal+newtotal,'previously_unmarked_pairs_scanned':tested,
        'exact_outward_vertex_boxes_checked':vertexchecks,'committed_core_and_query_files_verified':102,'all_added_conflicts_verified_with_independent_whole_hull_enclosures':True,
        'all_old_exclusions_preserved':True,'matrix_shapes_order_hashes_and_padding_verified':True,'pending_cases':0,
        'unmarked_pairs_not_claimed_feasible':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',summary);print(summary,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
