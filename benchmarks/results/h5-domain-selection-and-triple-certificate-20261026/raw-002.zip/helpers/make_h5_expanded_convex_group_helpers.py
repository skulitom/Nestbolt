"""Lossless grouping of the newly refined54-fixed matrices."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('prepare_h5_expanded_conflict_groups.py','prepare_h5_expanded_convex_groups.py'),('audit_h5_expanded_conflict_groups.py','audit_h5_expanded_convex_groups.py')]:
    dest=ROOT/'output'/target;assert not dest.exists();s=(ROOT/'output'/source).read_text();assert 'h5-expanded-domain-conflicts-20261026' in s;s=s.replace('h5-expanded-domain-conflicts-20261026','h5-expanded-convex-conflicts-20261026')
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    print(dest)
