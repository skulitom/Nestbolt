"""Prepare a complete fresh convex-domain refinement; old fixed57 bits are not used."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('build_h5_convex_domain_conflicts.py','build_h5_expanded_convex_conflicts.py'),('audit_h5_convex_domain_conflicts.py','audit_h5_expanded_convex_conflicts.py')]:
    dest=ROOT/'output'/target;assert not dest.exists();s=(ROOT/'output'/source).read_text()
    changes=[('h5-original-domain-conflicts-20261025','h5-expanded-domain-conflicts-20261026'),('h5-full-original-joint-prepared-20261025','h5-expanded-cog-joint-prepared-20261026'),('h5-convex-domain-conflicts-20261025','h5-expanded-convex-conflicts-20261026'),('benchmarks/results/h5-expanded-domain-conflicts-20261026/raw-manifest.json','benchmarks/results/h5-projected-source-and-fresh-conflicts-20261026/raw-manifest.json'),('output/h5-three-region-master-20261025/selection-audit/checks.json','benchmarks/results/h5-projected-source-and-fresh-conflicts-20261026/fresh-conflict-audit.json'),('2996279','5489250'),('2,996,279','5,489,250'),('3100000','5500000'),('240','360')]
    for a,b in changes:s=s.replace(a,b)
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    print(dest)
