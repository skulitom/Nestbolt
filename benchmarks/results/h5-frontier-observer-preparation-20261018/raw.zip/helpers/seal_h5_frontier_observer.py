"""Seal the focused observation build before its two diagnostic searches."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-frontier-observer-20261018'
out=root/'benchmarks/results/h5-frontier-observer-preparation-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_frontier_observer as runner
load,write,digest=runner.load,runner.write,runner.digest
build=load(probe/'build.json');plan=load(probe/'preparation.json');reader=load(probe/'authored-trace-reader/checks.json')
assert build['all_passed'] and digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert '123 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
source=load(probe/'reconstruction.json');assert source['all_formatted_files_exact'] and len(source['files'])==156
assert source['unchanged_other_files']==155 and source['all_123_original_tests_unchanged']
assert runner.prior.source_digest()==plan['production_digest']
for rel,expected in build['observed_sources'].items():assert digest(probe/'workspace'/rel)==expected
assert reader['all_checks_pass'] and len(reader['authored_test_traces'])==16
assert len(reader['malformed_records_rejected'])==16 and reader['reader_sha256']==digest(root/'scripts/h5_frontier_observer.py')
assert reader['parent_profile_branch_witnesses_exact']==12 and reader['actual_profile_branch_counters_exact']
assert reader['frozen_CLI_baseline_checks']==reader['actual_invocations']>0
assert digest(probe/'authored-tests.exe')==reader['test_binary_sha256']
method=load(probe/'runner-method.json');assert method['measurement_function_AST_exact'] and method['runner_sha256']==reader['reader_sha256']
assert digest(root/method['reference'])==method['reference_sha256']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_frontier_observer.py','build_h5_frontier_observer.py','prepare_h5_frontier_runner.py',
    'frontier_reader.py','check_h5_frontier_reader.py','check_h5_frontier_source.py','seal_h5_frontier_observer.py','record_h5_frontier_preparation.py']:
    files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_frontier_observer.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for n,row in inventory.items():
        b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_qualified':True,'optimized_core_tests_passed':123,'original_tests_unchanged':123,
    'strict_lint_passed':True,'observer_build_passed':True,'authored_test_cases':16,'malformed_records_rejected':16,
    'frozen_CLI_baseline_checks':reader['frozen_CLI_baseline_checks'],'baseline_metrics_exact':True,
    'parent_profile_branch_witnesses_exact':12,'actual_profile_branch_counters_exact':True,
    'exact_parent_reconstruction':True,'unchanged_other_files':155,'production_unchanged':True,'measured_search_started':False,'H5_complete':False}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','reconstruction.json','instrumentation.patch','runner-method.json']:shutil.copyfile(probe/name,out/name)
shutil.copyfile(probe/'authored-trace-reader/checks.json',out/'reader-checks.json')
doc=f'''# Height-setting part coverage — observation preparation, 2026-10-18

The [material-profile pilot](h5-material-profile-pilot-20261018.md) validates
72 outcomes but fails five of eight material comparisons. It rejects 46
trials by exact material profile and three by exact internal state. Six older
neutral panel pairs leave both height-setting inserts in place. None of the
16 attempts in those older diagnostics selects an insert. That old coverage
cannot be attributed to the new candidate, which reaches more proposals.

This isolated observer starts from the rejected material-profile candidate.
It records the validated public baseline and job, source and credited sheets,
original part names for all choices, visited choices, actual returned members
and terminal outcomes. Part names come from the model's explicit original
index map. A drop logger emits each valid-baseline invocation on return.
Every decision, budget, original test and work charge is unchanged; exact
recorded substitutions reproduce every formatted source byte. Logging can
perturb wall deadlines, so this diagnoses coverage and makes no quality or
speed claim. No new selection policy is installed.

All 123 existing optimized tests, strict lint and observer build pass.
Sixteen authored test cases qualify the reader; it rejects sixteen malformed
observations. All {reader['frozen_CLI_baseline_checks']} captured baselines independently validate with
the frozen public CLI and reproduce their metrics exactly. Twelve actual
profile-branch witnesses match the unobserved parent's saved records exactly,
and their aggregated counters equal the corresponding logged attempts.
All 156 formatted files reconstruct exactly; 155 remain unchanged.

The two diagnostic searches retain panel hardware, both kerfs, seed zero,
60 seconds, serial physical CCD0 CPU 8 and the original 20-minute session
cap. The measurement function is AST-identical to the preceding two-case
diagnostic, and the existing per-case validation/export method is reused.
The plan will be committed before running. The failed pilot remains the
quality evidence. Production and held-out geometry remain untouched;
H2/H5 remain open and completed milestone weight is 60%.

[Checks](h5-frontier-observer-preparation-20261018/checks.json),
[reader](h5-frontier-observer-preparation-20261018/reader-checks.json),
[source reconstruction](h5-frontier-observer-preparation-20261018/reconstruction.json),
[archive integrity](h5-frontier-observer-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-frontier-observer-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'all_qualified':True,'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size}))
