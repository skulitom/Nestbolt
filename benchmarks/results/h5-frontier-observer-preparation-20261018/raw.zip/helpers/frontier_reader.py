def check_traces(traces, stats=None):
    assert isinstance(traces,list)
    rows=[];visits=[];outcomes=Counter()
    allowed={'forbidden_incoming_orientation','receiver_repair_failed','source_repair_or_expiry',
        'exact_state_rejected','material_profile_rejected','independent_geometry_failed',
        'material_guard_or_expiry','neutral_inventory_rejected','accepted'}
    for trace in traces:
        assert set(trace)=={'baseline','choices','visits','attempts'}
        base=trace['baseline'];assert set(base)=={'job','layout','metrics','source_sheet'}
        job,layout,metrics=base['job'],base['layout'],base['metrics']
        assert isinstance(job,dict) and isinstance(layout,dict) and isinstance(metrics,dict)
        assert type(metrics['material_area']) in [int,float] and math.isfinite(metrics['material_area']) and metrics['material_area']>0
        names={p['id'] for p in job['parts']};assert len(names)==len(job['parts'])
        sheets={s['id'] for s in layout['sheets']};assert len(sheets)==len(layout['sheets'])
        assert base['source_sheet'] in sheets and metrics['last_sheet_id'] in sheets
        assert len({(p['part_id'],p['copy_index']) for p in layout['placements']})==len(layout['placements'])
        assert all(p['part_id'] in names and p['sheet_id'] in sheets for p in layout['placements'])
        inventory=Counter(p['part_id'] for p in layout['placements'] if p['sheet_id']==base['source_sheet'])
        assert inventory
        choices=trace['choices'];assert isinstance(choices,list) and choices
        single=Counter()
        for choice in choices:
            assert isinstance(choice,list) and 1<=len(choice)<=2
            assert all(type(name) is str and name in names for name in choice)
            assert not Counter(choice)-inventory
            if len(choice)==1:single.update(choice)
        assert single==inventory
        assert sum(len(c)==2 for c in choices)<=12
        seen={};last_index=-1
        for visit in trace['visits']:
            assert set(visit)=={'choice_index','target_sheet','retained_proposals'}
            i=visit['choice_index'];target=visit['target_sheet'];retained=visit['retained_proposals']
            assert type(i) is int and 0<=i<len(choices) and i>=last_index
            assert target in sheets and target!=base['source_sheet']
            assert type(retained) is int and 0<=retained<=6
            key=(i,target);assert key not in seen;seen[key]=(len(seen),retained);last_index=i
            visits.append(dict(visit,incoming=choices[i]))
        counts=Counter();last_visit=-1;accepted=0
        for index,attempt in enumerate(trace['attempts']):
            assert set(attempt)=={'choice_index','target_sheet','returned','outcome'}
            i=attempt['choice_index'];assert type(i) is int and 0<=i<len(choices)
            key=(i,attempt['target_sheet']);assert key in seen
            ordinal,retained=seen[key];assert ordinal>=last_visit;last_visit=ordinal
            counts[key]+=1;assert counts[key]<=retained
            returned=attempt['returned'];assert isinstance(returned,list) and 1<=len(returned)<=3
            target_inventory=Counter(p['part_id'] for p in layout['placements'] if p['sheet_id']==key[1])
            assert all(type(name) is str and name in names for name in returned)
            assert not Counter(returned)-target_inventory
            outcome=attempt['outcome'];assert outcome in allowed
            if outcome in ['exact_state_rejected','material_profile_rejected','neutral_inventory_rejected']:
                assert Counter(choices[i])==Counter(returned)
            if outcome=='accepted':
                accepted+=1;assert accepted<=1 and index==len(trace['attempts'])-1
            outcomes[outcome]+=1
            rows.append(dict(attempt,incoming=choices[i]))
    paired=[r for r in rows if len(r['incoming'])==2]
    mixed=[r for r in paired if len(set(r['incoming']))==2]
    counters={'directed_exchange_attempts':len(rows),'directed_exchanges':outcomes['accepted'],
        'paired_exchange_attempts':len(paired),'paired_exchanges':sum(r['outcome']=='accepted' for r in paired),
        'mixed_exchange_attempts':len(mixed),'mixed_exchanges':sum(r['outcome']=='accepted' for r in mixed),
        'neutral_exchange_rejections':sum(outcomes[k] for k in ['exact_state_rejected','material_profile_rejected','neutral_inventory_rejected']),
        'exact_state_exchange_rejections':outcomes['exact_state_rejected'],
        'material_profile_exchange_rejections':outcomes['material_profile_rejected']}
    if stats is not None:
        for key,value in counters.items():assert type(stats.get(key,0)) is int and stats.get(key,0)==value,(key,stats.get(key),value)
    return {'invocations':len(traces),'attempts':len(rows),'outcomes':dict(outcomes),
        'paired_attempts':len(paired),'mixed_attempts':len(mixed),'counters':counters,
        'attempt_rows':rows,'visit_rows':visits,'traces':traces}


def parse_log(log):
    return [json.loads(line.removeprefix('FRONTIER_DIAG ')) for line in log.splitlines() if line.startswith('FRONTIER_DIAG ')]


def read_trace(archive, record):
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        case=json.loads(z.read('case.json'))
        for name,expected in case['artifacts'].items():assert prior.sha256(z.read(name)).hexdigest()==expected
        traces=parse_log(z.read('search-stderr.log').decode('utf-8'))
    assert traces,'No baseline observation from the two-sheet diagnostic'
    return check_traces(traces,record.get('stats') if record['status']=='valid' else None)


