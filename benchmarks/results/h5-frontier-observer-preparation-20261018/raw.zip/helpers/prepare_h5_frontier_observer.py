"""Observe actual exchange choice coverage without changing a decision."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import difflib,json,shutil,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-frontier-observer-20261018'
old=root/'output/h5-material-profile-probe-20261018/candidate';work=out/'workspace'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(root/'benchmarks/results/h5-material-profile-pilot-20261018/verification.json')['valid']==72
out.mkdir();shutil.copytree(old,work)
rel='crates/core/src/sheets/vstrip/exchange.rs';path=work/rel
original=path.read_text(encoding='utf-8');text=original;changes=[]
def replace(before,after):
    global text
    assert text.count(before)==1,(before,text.count(before));text=text.replace(before,after);changes.append((before,after))
helper='''#[derive(serde::Serialize)]
struct FrontierTrace {
    baseline: serde_json::Value,
    choices: Vec<Vec<String>>,
    visits: Vec<serde_json::Value>,
    attempts: Vec<serde_json::Value>,
}

impl Drop for FrontierTrace {
    fn drop(&mut self) {
        eprintln!("FRONTIER_DIAG {}", serde_json::to_string(self).expect("frontier diagnostic serialization"));
    }
}

'''
replace('struct Proposal {',helper+'struct Proposal {')
replace('''        for selected in choices {
''','''        let mut trace = FrontierTrace {
            baseline: serde_json::json!({"job": self.model.job, "layout": baseline_layout,
                "metrics": before, "source_sheet": format!("sheet-{}", frozen.len() + last_index)}),
            choices: choices.iter().map(|choice| choice.iter().map(|key| {
                let item = sep.layout.placed_items()[*key].item().idx();
                self.model.job.parts[self.model.part[item]].id.clone()
            }).collect()).collect(),
            visits: Vec::new(), attempts: Vec::new(),
        };
        for (choice_index, selected) in choices.into_iter().enumerate() {
''')
replace('''                for proposal in candidates {
''','''                trace.visits.push(serde_json::json!({"choice_index":choice_index,
                    "target_sheet":format!("sheet-{}", frozen.len() + target),
                    "retained_proposals":candidates.len()}));
                for proposal in candidates {
''')
replace('''                    let mut next_receiver = JLayout::from_snapshot(&receiver.save());
''','''                    let attempt_index = trace.attempts.len();
                    trace.attempts.push(serde_json::json!({"choice_index":choice_index,
                        "target_sheet":format!("sheet-{}", frozen.len() + target),
                        "returned":victims.iter().map(|(_,item,_)| self.model.job.parts[self.model.part[item.idx()]].id.as_str()).collect::<Vec<_>>(),
                        "outcome":"pending"}));
                    let mut next_receiver = JLayout::from_snapshot(&receiver.save());
''')
replace('''                        let Some(poses) = incoming_group_poses(&members, proposal.incoming) else {
                            continue;
''','''                        let Some(poses) = incoming_group_poses(&members, proposal.incoming) else {
                            trace.attempts[attempt_index]["outcome"] = serde_json::json!("forbidden_incoming_orientation");
                            continue;
''')
replace('''                    if receiver_tracker.total_loss() > 0.0 {
                        continue;
''','''                    if receiver_tracker.total_loss() > 0.0 {
                        trace.attempts[attempt_index]["outcome"] = serde_json::json!("receiver_repair_failed");
                        continue;
''')
replace('''                        || self.clock.now() >= self.last_step(exchange_until)
                    {
                        continue;
''','''                        || self.clock.now() >= self.last_step(exchange_until)
                    {
                        trace.attempts[attempt_index]["outcome"] = serde_json::json!("source_repair_or_expiry");
                        continue;
''')
replace('''                        self.stats.exact_state_exchange_rejections += 1;
                        continue;
''','''                        self.stats.exact_state_exchange_rejections += 1;
                        trace.attempts[attempt_index]["outcome"] = serde_json::json!("exact_state_rejected");
                        continue;
''')
replace('''                            self.stats.material_profile_exchange_rejections += 1;
                            continue;
''','''                            self.stats.material_profile_exchange_rejections += 1;
                            trace.attempts[attempt_index]["outcome"] = serde_json::json!("material_profile_rejected");
                            continue;
''')
replace('''                        self.stats.rejected_layouts += 1;
                        continue;
''','''                        self.stats.rejected_layouts += 1;
                        trace.attempts[attempt_index]["outcome"] = serde_json::json!("independent_geometry_failed");
                        continue;
''')
replace('''                        || self.clock.now() >= exchange_until
                    {
                        continue;
''','''                        || self.clock.now() >= exchange_until
                    {
                        trace.attempts[attempt_index]["outcome"] = serde_json::json!("material_guard_or_expiry");
                        continue;
''')
replace('''                        && after.material_area >= before.material_area
                    {
                        self.stats.neutral_exchange_rejections += 1;
                        continue;
''','''                        && after.material_area >= before.material_area
                    {
                        self.stats.neutral_exchange_rejections += 1;
                        trace.attempts[attempt_index]["outcome"] = serde_json::json!("neutral_inventory_rejected");
                        continue;
''')
replace('''                    self.stats.mixed_exchanges += u64::from(mixed);
                    return Ok(1);
''','''                    self.stats.mixed_exchanges += u64::from(mixed);
                    trace.attempts[attempt_index]["outcome"] = serde_json::json!("accepted");
                    return Ok(1);
''')
reverse=text
for before,after in reversed(changes):assert reverse.count(after)==1;reverse=reverse.replace(after,before)
assert reverse==original
assert text.split('#[cfg(test)]',1)[1]==original.split('#[cfg(test)]',1)[1]
path.write_text(text,encoding='utf-8',newline='\n')
(out/'substitutions.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='material-profile/'+rel,tofile='frontier-observer/'+rel)),encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_source':str(old),
    'source_files':[{'path':p.relative_to(old).as_posix(),'sha256':digest(p)} for p in sorted(old.rglob('*')) if p.is_file()],
    'changed_file':rel,'changed_files':[rel],'production_digest':source_digest(),
    'target':str(root/'output/h5-frontier-observer-target-20261018'),
    'all_123_prior_tests_unchanged':True,'exact_preformat_reversal':True,
    'decisions_budgets_work_charges_unchanged':True,'trace_overhead_can_change_wall_trajectory':True,'measured_search_started':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
s=(root/'output/build_h5_exact_state.py').read_text(encoding='utf-8').replace('h5-exact-state','h5-frontier-observer')
(root/'output/build_h5_frontier_observer.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'isolated_observer_prepared':True,'source_files':len(plan['source_files']),'changed_files':1,'prior_tests_unchanged':123,'measurements_started':False}))
