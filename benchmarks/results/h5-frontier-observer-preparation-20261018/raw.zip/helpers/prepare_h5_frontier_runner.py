"""Keep the preceding two-case diagnostic protocol with a focused new reader."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];out=root/'output/h5-frontier-observer-20261018'
ref=root/'scripts/h5_exact_state.py';s=ref.read_text(encoding='utf-8')
s=s.replace('import h5_larger_return_pilot as prior','import h5_material_profile_pilot as prior')
s=s.replace('h5_larger_return_pilot.py','h5_material_profile_pilot.py').replace('h5-larger-return-pilot','h5-material-profile-pilot')
s=s.replace('h5-exact-state','h5-frontier-observer')
start=s.index('"""');end=s.index('"""',start+3)+3
s='''"""Observe whether exchange choices reach the parts setting charged sheet height.

Two diagnostic-only searches: panel hardware, both kerfs, seed 0, 60 seconds,
serial physical CCD0 CPU 8. The original search decisions, budgets and work
charges remain. Logging overhead can change wall trajectories. No quality
or speed comparison, integration or held-out geometry access.
"""'''+s[end:]
start=s.index('def neutral(');end=s.index('def run(out):',start)
s=s[:start]+(root/'output/frontier_reader.py').read_text(encoding='utf-8')+s[end:]
start=s.index("        'source_change':");end=s.index("\n        'interpretation':",start)
s=s[:start]+"        'source_change':'Record the validated public baseline/job, credited and source sheet, original part names for every choice, visited choices and actual attempted members with terminal outcome. All inserted observations reverse exactly; no decision or work charge changes.',"+s[end:]
path=root/'scripts/h5_frontier_observer.py';assert not path.exists();compile(s,str(path),'exec')
path.write_text(s,encoding='utf-8',newline='\n')
def fn(text,name):return next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
assert ast.dump(fn(s,'run'))==ast.dump(fn(ref.read_text(encoding='utf-8'),'run'))
method={'reference':ref.relative_to(root).as_posix(),'reference_sha256':sha256(ref.read_bytes()).hexdigest(),
    'measurement_function_AST_exact':True,'case_method_reused_unchanged':True,'runner_sha256':sha256(path.read_bytes()).hexdigest()}
(out/'runner-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(root/'output/check_h5_exact_state_source.py').read_text(encoding='utf-8').replace('h5-exact-state','h5-frontier-observer').replace("out/'changes.json'","out/'substitutions.json'")
s=s.replace("'all_113_original_tests_unchanged':True,'added_exact_state_tests':3", "'all_123_original_tests_unchanged':True,'added_tests':0")
(root/'output/check_h5_frontier_source.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(method))
