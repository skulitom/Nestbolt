"""Fresh original-source checks of all fixed-row positive and full negative controls."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from h5_transfer43_source_bridge_20261028 import reconstruct
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-cog-rows-20261028';STUDY=ROOT/'output/h5-bracket-row-clearance-20261028';OUT=BASE/'source-bridge-audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(BASE/'plan.json');fixed=load(BASE/'fixed-rows.json');job=load(JOB);control=load(BASE/'control.json');cases=[('source61',control,True)]+[(f"source62-mode{w['mode']}",control+[w['pose']],True) for w in load(STUDY/'witness-summary.json')]+[('negative66',load(BASE/'negative.json'),False)];records=[]
for name,poses,valid in cases:
    assert [p for p in poses if p['block']>=40]==fixed;rows,error=reconstruct(job,load(BASE/'blocks43.json'),load(BASE/'modes.json'),poses,load(BASE/'short12.json'));expected=[(r['part_id'],r['copy_index']) for r in rows] if valid else [(p['id'],i) for p in job['parts'] for i in range(p['quantity'])];checked=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],expected);assert checked['valid']==valid and checked['stock_failures']==0 and len(rows)==(61 if name=='source61' else 62 if valid else 66)
    if name in ['source61','negative66']:
        saved=load(BASE/('control-source61.json' if valid else 'negative-source66.json'));assert len(rows)==len(saved);position_error=0
        for a,b in zip(rows,saved):
            assert all(a[k]==b[k] for k in ['part_id','copy_index','sheet_id']) and a['transform']['mirrored']==b['transform']['mirrored'] and a['transform']['rotation_radians']==b['transform']['rotation_radians'];position_error=max(position_error,max(abs(x-y) for x,y in zip(a['transform']['translation'],b['transform']['translation'])))
        assert position_error<1e-9
    write(OUT/(name+'-source.json'),rows);write(OUT/(name+'-checks.json'),checked);records.append({'case':name,'originals':len(rows),'valid':valid,'source_collisions':checked['pair_failures'],'stock_failures':checked['stock_failures'],'same_sheet_pairs':checked['same_sheet_pairs'],'holes':checked['cutouts'],'hole_vertices':checked['hole_vertices'],'maximum_offset_error_mm':error,'all_fixed_rows_match':True})
assert records[-1]['source_collisions']==780 and records[-1]['holes']==90 and records[-1]['hole_vertices']==10026
inputs=[BASE/n for n in ['plan.json','fixed-rows.json','blocks43.json','modes.json','short12.json','control.json','negative.json','control-source61.json','negative-source66.json']]+[JOB,STUDY/'audit/plan.json',STUDY/'audit/checks.json',STUDY/'witness-summary.json',ROOT/'output/h5_transfer43_source_bridge_20261028.py',ROOT/'output/h5_legacy64_source_readback.py'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'positive_controls_verified':9,'full_negative_controls_verified':1,'cases':records,'all66_negative_identities_preserved':True,'all_fixed_cog_poses_verified':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
