"""Verify every model field, all ancestor stages and all fixed-row controls."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_fixed_cog_rows_ancestor_reader_20261028 import inspect_ancestors
from h5_fixed_cog_rows_cp_reader_20261028 import inspect,control_values,violations
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-cog-rows-20261028';OLD=ROOT/'output/h5-row-bracket-capacity-20261028';STUDY=ROOT/'output/h5-bracket-row-clearance-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();assert load(BASE/'source-bridge-audit/checks.json')['passed']
for folder in [BASE,MODEL,BASE/'geometry-audit',BASE/'capacity-audit',BASE/'source-bridge-audit',OLD/'model-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
old,oldmp,ancestors=inspect_ancestors(ROOT);write(OUT/'ancestor-model-rechecks.json',ancestors);p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');relative={k:load(BASE/'relative'/f'{k}.json') for k in ['5-5','5-4']};typed={(ri,mi):load(BASE/'row-bracket'/f'{ri:02d}-{mi:02d}.json') for ri in [12,13] for mi in range(2,10)};control=load(BASE/'control.json');negative=load(BASE/'negative.json');checked,disabled=inspect(p,mp,old,oldmp,load(BASE/'fixed-rows.json'),relative,typed,control,negative,load(MODEL/'partial-hints.json'),load(MODEL/'partial-control-assignment.json'),load(MODEL/'negative-assignment.json'));built=load(MODEL/'built.json');assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256']
def partial_check(values,absent):
    copy=cp_model_pb2.CpModelProto();copy.CopyFrom(p)
    for ix in absent:copy.constraints[ix].linear.domain[:]=[0,0]
    result=evaluate(copy,values,0);assert not violations(copy,values)['failed_constraints']
    for ix in absent:copy.constraints[ix].linear.domain[:]=[1,1]
    assert copy.SerializeToString()==p.SerializeToString();return result
cases=[('source61',control,True)]+[(f"source62-mode{w['mode']}",control+[w['pose']],True) for w in load(STUDY/'witness-summary.json')]+[('negative66',negative,False)];records=[]
for name,poses,valid in cases:
    values=control_values(p,mp,relative,typed,poses);known={r['block'] for r in poses};absent=[i['mandatory'] for i in mp['items'] if i['index'] not in known];failed=violations(p,values)
    if valid:
        assert failed['failed_constraints']==[{'constraint':ix,'kind':'linear'} for ix in absent] and failed['cover_collisions']==0;result=partial_check(values,absent);assert result['expanded_pairs']==(111931 if name=='source61' else 112002);assert len(absent)==(5 if name=='source61' else 4)
    else:
        expected={ix for g in mp['collision_groups'] for ix in g['constraints']}|{mp['source_x_cumulative'],mp['source_y_cumulative']};assert len(expected)==14 and {r['constraint'] for r in failed['failed_constraints']}==expected and failed['cover_collisions']>0 and not absent;result=None
    if name=='source61':assert values==load(MODEL/'partial-control-assignment.json') and absent==disabled
    elif not valid:assert values==load(MODEL/'negative-assignment.json')
    for r in mp['fixed_row_equalities']:assert values[mp['items'][r['block']][r['axis']]]==r['value_um']
    records.append({'name':name,'partial_control_valid':valid,'missing_mandatory':len(absent),'failed_constraints':failed['failed_constraints'],'cover_pairs_checked':failed['cover_pairs_checked'],'cover_collisions':failed['cover_collisions'],'fixed_anchor_constraints_satisfied':6,'evaluation':result})
write(OUT/'control-checks.json',records);inputs=[BASE/n for n in ['plan.json','fixed-rows.json','geometry-audit/plan.json','geometry-audit/checks.json','capacity-audit/plan.json','capacity-audit/checks.json','source-bridge-audit/plan.json','source-bridge-audit/checks.json','modes.json','blocks43.json','control.json','negative.json']]+[MODEL/n for n in ['plan.json','model.pb','mapping.json','partial-hints.json','partial-control-assignment.json','negative-assignment.json']]+[OLD/n for n in ['model/plan.json','model/model.pb','model/mapping.json','model-audit/plan.json','model-audit/checks.json']]+[STUDY/'witness-summary.json',ROOT/'output/h5_fixed_cog_rows_cp_reader_20261028.py',ROOT/'output/h5_fixed_cog_rows_ancestor_reader_20261028.py',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{**checked,'seconds':time.perf_counter()-started,'all4_ancestor_models_fully_reverified':True,'primary_source61_rejects_only5_missing_brackets':True,'all8_source62_controls_reject_only4_missing_brackets':True,'negative66_rejected_by14_collision_constraints':True,'negative_cover_collision_visits':records[-1]['cover_collisions'],'all_controls_satisfy6_fixed_row_equalities':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
