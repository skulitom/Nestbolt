"""Add six row-anchor equalities, preserving every old constraint and variable."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
from h5_row_bracket_cp_reader_20261028 import control_values
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-cog-rows-20261028';OLD=ROOT/'output/h5-row-bracket-capacity-20261028';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
for folder in [BASE,BASE/'geometry-audit',BASE/'capacity-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter();old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model/model.pb').read_bytes());old.ClearField('solution_hint');model=cp_model.CpModel();assert model.proto.parse_text_format(text_format.MessageToString(old));mp=load(OLD/'model/mapping.json');equalities=[]
for row in load(BASE/'fixed-rows.json'):
    item=mp['items'][row['block']]
    for axis,value in zip(['x','y'],row['anchor_um']):
        ix=model.add(model.get_int_var_from_proto_index(item[axis])==value).index;equalities.append({'block':row['block'],'axis':axis,'value_um':value,'constraint':ix})
mp['fixed_row_equalities']=equalities;mp['fixed_base_variable_count']=len(old.variables);mp['fixed_base_constraint_count']=len(old.constraints);relative={k:load(BASE/'relative'/f'{k}.json') for k in ['5-5','5-4']};typed={(ri,mi):load(BASE/'row-bracket'/f'{ri:02d}-{mi:02d}.json') for ri in [12,13] for mi in range(2,10)};control=load(BASE/'control.json');negative=load(BASE/'negative.json');sol=control_values(old,mp,relative,typed,control);bad=control_values(old,mp,relative,typed,negative);known={r['block'] for r in control};hints={}
for item in mp['items']:
    hints[item['presence']]=1
    if item['index'] in known:
        for key in ['x','y']:hints[item[key]]=sol[item[key]]
        for o in item['options']:hints[o['selector']]=sol[o['selector']]
for pair in mp['row_pairs']:
    if pair['left'] in known and pair['right'] in known:
        for s in pair['selectors']:hints[s]=sol[s]
for pair in mp['row_bracket_pairs']:
    if pair['row'] in known and pair['bracket'] in known:
        for o in pair['options']:
            for s in o['cells']:hints[s]=sol[s]
for ix,value in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(ix),value)
mp['control_disabled_mandatory_constraints']=[i['mandatory'] for i in mp['items'] if i['index'] not in known]
assert model.validate()=='' and len(model.proto.variables)==7932 and len(model.proto.constraints)==35021 and len(equalities)==6 and len(mp['control_disabled_mandatory_constraints'])==5;assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',mp);write(OUT/'partial-control-assignment.json',sol);write(OUT/'negative-assignment.json',bad);write(OUT/'partial-hints.json',{str(k):v for k,v in hints.items()})
inputs=[BASE/n for n in ['plan.json','geometry-audit/plan.json','geometry-audit/checks.json','capacity-audit/plan.json','capacity-audit/checks.json','fixed-rows.json','control.json','negative.json']]+[OLD/n for n in ['model/plan.json','model/model.pb','model/mapping.json','model-audit/plan.json','model-audit/checks.json']];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0});write(OUT/'built.json',{'seconds':time.perf_counter()-started,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'previous_constraints':len(old.constraints),'extra_variables':0,'added_anchor_equalities':6,'mandatory_blocks':43,'movable_orthogonal_blocks':40,'fixed_cog_row_blocks':3,'fixed_first_sheet_cogs':14,'fixed_short_originals':12,'target_originals':66,'partial_control_originals':61,'partial_hints':len(hints),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
