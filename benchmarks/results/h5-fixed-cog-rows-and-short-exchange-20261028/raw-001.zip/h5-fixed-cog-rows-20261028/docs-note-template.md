

**N4 fixed cog rows and short-sheet exchange preflight, 2026-10-28:** [the evidence]({link})
preserves all 7,932 variables and 35,015 prior constraints, adding only six
anchor equalities for fourteen cogs. All forty orthogonal blocks remain
movable and all66 originals mandatory. Full model/ancestor, source, identity
and control audits pass; source61 and all eight source62 witnesses fail only
their missing-bracket requirements. The full negative has780 source collisions
and is rejected by14 model constraints. The sole60/90-second call closes
UNKNOWN: search begins at6.25s, algorithm60.054484s, shared60.147361s, with
the0.054484s algorithm overrun retained. No candidate or infeasibility follows.
The next allocation review discards6brackets/4inserts/2cogs under the existing
ordered-projection proof. The surviving5brackets/6inserts/2cogs allocation has
an explicit first-sheet complement of18frames/7brackets/15inserts/13cogs.
Six fixed11 exchange variants from a validated short12 pass source and all66
identity accounting. No new short13, free-region preparation or construction
call exists yet; that audited finite geometry study is next. Both prior
checkpoints reached main83f3f51f after all six previous CI jobs passed. Its
CI40783629977 has four passes and both platform checks running at the snapshot,
so this checkpoint queues. Production, READMEs, valid64,444 necessary survivors
and H2's original gate/22 unopened vectors are unchanged. H2/H5 remain open
at60%; no native result or new release qualifies.
