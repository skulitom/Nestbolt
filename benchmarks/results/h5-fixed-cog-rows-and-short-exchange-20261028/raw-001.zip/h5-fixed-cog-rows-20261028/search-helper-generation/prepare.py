"""Create fresh frozen search helpers for the six-equality conditional model."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-cog-rows-20261028';OUT=BASE/'search-helper-generation';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
for folder in ['model-audit','source-bridge-audit','row-identity-audit','capacity-audit']:assert load(BASE/folder/'checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');records=[]
for oldname,newname in [('run_h5_row_capacity_model_20261028.py','run_h5_fixed_cog_rows_model_20261028.py'),('audit_h5_row_capacity_response_20261028.py','audit_h5_fixed_cog_rows_response_20261028.py')]:
    original=ROOT/'output'/oldname;source=original.read_text(encoding='utf-8').replace('output/h5-row-bracket-capacity-20261028','output/h5-fixed-cog-rows-20261028').replace('h5_row_capacity_cp_reader_20261028','h5_fixed_cog_rows_cp_reader_20261028').replace('check_h5_row_capacity_candidate_20261028','check_h5_fixed_cog_rows_candidate_20261028')
    source=source.replace("inputs=[BASE/'capacity-audit/plan.json'","inputs=[BASE/'fixed-rows.json',BASE/'capacity-audit/plan.json'")
    if oldname.startswith('audit_'):
        source=source.replace('from h5_fixed_cog_rows_cp_reader_20261028 import inspect,violations','from h5_fixed_cog_rows_cp_reader_20261028 import inspect,violations\nfrom h5_fixed_cog_rows_ancestor_reader_20261028 import inspect_ancestors')
        line=next(l for l in source.splitlines() if l.startswith('p=cp_model_pb2.CpModelProto();'))
        replacement="p=cp_model_pb2.CpModelProto();p.ParseFromString((SEARCH/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');old,oldmp,ancestors=inspect_ancestors(ROOT);write(OUT/'ancestor-model-rechecks.json',ancestors);model_check,_=inspect(p,mp,old,oldmp,load(BASE/'fixed-rows.json'),{k:load(BASE/'relative'/f'{k}.json') for k in ['5-5','5-4']},{(ri,mi):load(BASE/'row-bracket'/f'{ri:02d}-{mi:02d}.json') for ri in [12,13] for mi in range(2,10)},load(BASE/'control.json'),load(BASE/'negative.json'),load(MODEL/'partial-hints.json'),load(MODEL/'partial-control-assignment.json'),load(MODEL/'negative-assignment.json'));write(OUT/'model-recheck.json',model_check)"
        source=source.replace(line,replacement).replace("'movable_first_sheet_originals':54","'movable_first_sheet_originals':40,'fixed_first_sheet_cogs':14").replace("'prior_model_fields_preserved':True","'prior_variables_and_constraints_preserved':True,'six_row_anchor_equalities_verified':True")
        source=source.replace("ROOT/'output/h5_fixed_cog_rows_cp_reader_20261028.py'","ROOT/'output/h5_fixed_cog_rows_ancestor_reader_20261028.py',ROOT/'output/h5_fixed_cog_rows_cp_reader_20261028.py'")
    target=ROOT/'output'/newname
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
    compile(source,str(target),'exec');records.append({'source':original.relative_to(ROOT).as_posix(),'source_sha256':digest(original),'generated':target.relative_to(ROOT).as_posix(),'generated_sha256':digest(target)})
with (OUT/'generation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(records,f,indent=2);f.write('\n')
print({'helpers_prepared':len(records),'solver_calls':0})
