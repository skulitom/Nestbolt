"""Prepare a new guarded normal push for both verified queued checkpoints."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head.startswith('83f3f51f')
assert subprocess.check_output(['git','log','-1','--format=%s'],cwd=ROOT,text=True).strip()=='Audit source capacities and reject ineffective domain reductions'
source=(ROOT/'output/push_h5_bracket_bound_checkpoint_20261028.py').read_text(encoding='utf-8')
changes={
 'output/h5-bracket-bound-main-sync-20261028':'output/h5-row-capacity-main-sync-20261028',
 "OLD='608fecf12c287805fddcd8e64b9db7fef4950b70';NEW='0d6dc0fa2e10c5505dd50ecae56d5f99963ecc58'":f"OLD='0d6dc0fa2e10c5505dd50ecae56d5f99963ecc58';NEW='{head}'",
 "['benchmarks/results/h5-transfer-and-hybrid-row-clearance-20261028','benchmarks/results/h5-bracket-source-regions-and-fixed-layout-bound-20261028']":"['benchmarks/results/h5-movable-row-bracket-and-capacity-20261028','benchmarks/results/h5-row-bracket-capacity-and-domain-studies-20261028']",
 '40771628220':'40777420353'
}
for old,new in changes.items():
    assert old in source,old
    source=source.replace(old,new)
with (ROOT/'output/push_h5_row_capacity_checkpoint_20261028.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'head':head,'prior_CI':40777420353,'guard_prepared':True})
