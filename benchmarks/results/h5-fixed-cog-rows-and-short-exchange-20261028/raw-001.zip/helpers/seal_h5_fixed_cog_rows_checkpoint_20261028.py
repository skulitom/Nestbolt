"""Seal the closed conditional search and the new allocation inventory preflight."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-fixed-cog-rows-20261028';PUB=BASE/'publication';NAME='h5-fixed-cog-rows-and-short-exchange-20261028';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='83f3f51f7767d6ddd1e2eb34968d1502bb0ae3d8' and not git('diff','HEAD','--name-only')
for a in ['geometry-audit','capacity-audit','model-audit','source-bridge-audit','row-identity-audit','response-audit','short-exchange-preflight']:assert load(BASE/a/'checks.json')['passed']
response=load(BASE/'search/result.json');assert response['closed'] and response['solver_calls']==1 and response['status']=='UNKNOWN' and not response['has_solution'];model=load(BASE/'model-audit/checks.json');assert model['old_variables_and_constraints_byte_identical'] and model['only6_row_anchor_equalities_added'] and model['all4_ancestor_models_fully_reverified'];exchange=load(BASE/'short-exchange-preflight/checks.json');assert exchange['fixed11_variants_source_valid']==6 and exchange['all66_identities_accounted_in_all6_variants'] and not exchange['new_short13_created'] and not exchange['geometry_prepared'] and not exchange['construction_opened']
prior=load(ROOT/'benchmarks/results/h5-row-bracket-capacity-and-domain-studies-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes'];up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up);assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];assert main==head;jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6;passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==4 and set(live)=={'checks (windows-latest)','checks (ubuntu-latest)'}
SYNC=ROOT/'output/h5-row-capacity-main-sync-20261028';receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['prior_main_all6_pass'] and receipt['normal_atomic_fast_forward']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [BASE,SYNC]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=set((ROOT/'output').glob('*fixed_cog_rows*20261028.py'));helpers.update(ROOT/'output'/n for n in ['prepare_h5_short_two_cog_exchange_preflight_20261028.py','prepare_h5_row_capacity_push_20261028.py','push_h5_row_capacity_checkpoint_20261028.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_fixed_cog_rows_archive_20261028.py',Path(__file__).name])
for p in helpers:add('helpers/'+p.name,p)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for a,b in [('fixed-rows.json','fixed-row-anchors.json'),('model/built.json','model-built.json'),('model-audit/checks.json','model-audit.json'),('model-audit/control-checks.json','model-controls.json'),('source-bridge-audit/checks.json','source-bridge-audit.json'),('row-identity-audit/checks.json','row-identity-audit.json'),('response-audit/checks.json','response-audit.json'),('search/result.json','search-result.json'),('short-exchange-preflight/checks.json','exchange-preflight.json'),('short-exchange-preflight/allocation-review.json','allocation-review.json'),('short-exchange-preflight/case-summary.json','exchange-cases.json'),('short-exchange-preflight/plan.json','exchange-plan.json')]:shutil.copyfile(BASE/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json');shutil.copyfile(SYNC/'receipt.json',OUT/'prior-push-receipt.json');write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40783629977,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':(BASE/'next-step-text.txt').read_text(encoding='utf-8'),'completion_percent':60,'H2_complete':False,'H5_complete':False});write(OUT/'checks.json',{'passed':True,'full_target_originals':66,'mandatory_blocks':43,'movable_orthogonal_first_sheet_blocks':40,'fixed_first_sheet_cogs':14,'fixed_short_originals':12,'closed_solver_calls':1,'solver_status':'UNKNOWN','source_valid66_count':0,'actual_or_global_infeasibility_claimed':False,'new_allocation_short_counts':[5,6,2],'new_allocation_first_counts':[18,7,15,13],'source_valid_fixed11_variants':6,'new_short13_created':False,'exchange_geometry_prepared':False,'exchange_construction_opened':False,'valid64_preserved':True,'remaining_necessary_allocations':444,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
