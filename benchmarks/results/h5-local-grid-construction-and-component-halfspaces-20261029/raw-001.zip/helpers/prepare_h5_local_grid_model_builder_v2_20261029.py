"""Prepare a distinct local-grid source model, preserving the audited owner coupling."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/build_h5_rigid_rectangle_model_20261029.py').read_text(encoding='utf-8')
body=old[old.index('def linear('):old.index('elapsed=time.perf_counter()-started')]
for a,b in [('outward_offsets_um','outward_offsets_grid'),('MIN,-226','MIN,-3'),('_um\'','_grid\''),("'rectangle_gap_grid':226","'rectangle_gap_grid':3"),("'position_units_per_mm':1000","'position_units_per_mm':10,'world_origin_mm':[0,2100],'forbidden_site_pairs':forbidden")]:
    assert a in body,a
    body=body.replace(a,b)
needle='unary_plane_count=mask_links=0'
body=body.replace(needle,"""allowed=load(BASE/'allowed-empty-site-pairs.json');forbidden=[]
for a,b in combinations(range(15),2):
    if [a,b] not in allowed:forbidden.append({'empty_sites':[a,b],'constraint':linear({empty[a]:1,empty[b]:1},cp_model.INT_MIN,1)})
assert len(forbidden)==70
"""+needle)
header='''"""Local0.1mm-grid construction with audited source implications and all35 site choices."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';PRE=BASE;RID=BASE;OUT=BASE/'model';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
assert load(BASE/'geometry-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');unary=load(BASE/'unary-templates.json');model=cp_model.CpModel()
'''
footer='''elapsed=time.perf_counter()-started
charges={'source_valid_short11_shared_seconds':load(SHORT/'response-audit/checks.json')['shared_seconds_including_preparation'],'fixed_first_sheet_preparation_seconds':load(FIRST/'checks.json')['seconds'],'cog_site_selection_preparation_seconds':load(SLOTS/'checks.json')['seconds'],'site_mask_region_preparation_seconds':load(PRIOR/'checks.json')['seconds'],'source_rigid_rectangle_preparation_seconds':load(PRIOR/'rigid-rectangle-preflight/checks.json')['seconds'],'source_mask_integer_preparation_seconds':load(PRIOR/'integer-preparation/checks.json')['seconds'],'accessible_area_bound_seconds':load(PRIOR/'accessible-area-bound/checks.json')['seconds'],'connected_capacity_bound_seconds':load(PRIOR/'connected-capacity-bound/checks.json')['seconds'],'local_grid_preparation_seconds':load(BASE/'checks.json')['seconds'],'cp_model_build_seconds':elapsed};write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',FIRST/'checks.json',SLOTS/'checks.json',SHORT/'response-audit/plan.json',SHORT/'response-audit/checks.json']+[BASE/n for n in ['plan.json','checks.json','family-modes.json','unary-templates.json','mode-rectangles.json','instances.json','inventory.json','components.json','component-pairs.json','allowed-empty-site-pairs.json']]+[PRIOR/n for n in ['plan.json','checks.json','rigid-rectangle-preflight/checks.json','integer-preparation/checks.json','accessible-area-bound/checks.json','connected-capacity-bound/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Build all13 original owners, all80 source-mode options and35 audited surviving empty-site pairs in one model. Local0.1mm-grid positions use the exact audited source hull implications.20 outward component rectangles remain rigidly attached to their owners through mode equalities. All183 different-owner pairs require0.3mm axis clearance. Same-family X order remains. No objective or hints. Independently audit every field before one60/90-second call; earlier calls remain closed.','algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'source_validation_reserve_seconds':4,'retry_permitted':False,'solver_calls':0})
result={'passed':True,'seconds':elapsed,'preparation_seconds_charged':sum(charges.values()),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'original_moving_parts':13,'source_mode_selectors':80,'empty_site_selectors':15,'retained_empty_site_pairs':35,'forbidden_site_pair_constraints':70,'unary_region_selectors':sum(len(o['unary_regions']) for o in owners),'unary_integer_planes':unary_plane_count,'empty_site_mask_implications':mask_links,'rigid_components':len(components),'rigid_component_coordinate_links':coordinate_links,'different_owner_rectangle_pairs':len(separations),'rectangle_direction_selectors':4*len(separations),'same_family_order_constraints':len(symmetry),'model_sha256':digest(OUT/'model.pb'),'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
'''
text=header+body+footer;p=ROOT/'output/build_h5_local_grid_model_20261029.py';compile(text,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print({'prepared':p.name,'previous_closed_models_unchanged':True})
