from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_rigid_rectangle_model_20261029.py').read_text(encoding='utf-8')
changes=[
("BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';PRE=BASE/'integer-preparation';MODEL=BASE/'rigid-model';OUT=BASE/'rigid-model-audit';RID=BASE/'rigid-rectangle-preflight'", "BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';PRE=BASE;MODEL=BASE/'model';OUT=BASE/'model-audit';RID=BASE"),
('integer-audit','geometry-audit'),("RID/'audit-v3/", "RID/'geometry-audit/"),
("templates=load(PRE/'pair-templates.json');groups=load(PRE/'owner-pairs.json');",''),
('11638','8336'),('63132','43571'),("mapping['position_units_per_mm']==1000","mapping['position_units_per_mm']==10 and mapping['world_origin_mm']==[0,2100]"),
("_um'","_grid'"),('==226','==3'),('MIN,-226','MIN,-3'),
('10826','7524'),('10830','7528'),('10906','7604'),('10910','7608'),
("source=unary[gid]['regions'][ri]", "source=next(r for r in unary[gid]['regions'] if r['region']==ri)"),
('10705','7403'),('43721','30208'),('17686','11568'),
("'pair-templates.json','owner-pairs.json'", "'allowed-empty-site-pairs.json'"),
("'all105_empty_site_pairs_represented':True", "'all35_remaining_empty_site_pairs_represented':True,'forbidden_site_pairs_verified':70")
]
for a,b in changes:
    assert a in s,a
    s=s.replace(a,b)
needle='assert len(list(combinations(empty,2)))==105'
replacement="""assert len(list(combinations(empty,2)))==105
allowed=load(BASE/'allowed-empty-site-pairs.json');expected_forbidden=[list(pair) for pair in combinations(range(15),2) if list(pair) not in allowed]
assert len(allowed)==35 and len(expected_forbidden)==70
assert [r['empty_sites'] for r in mapping['forbidden_site_pairs']]==expected_forbidden
for r in mapping['forbidden_site_pairs']:
    a,b=r['empty_sites'];linear(r['constraint'],{empty[a]:1,empty[b]:1},MIN,1)"""
assert needle in s;s=s.replace(needle,replacement)
p=ROOT/'output/audit_h5_local_grid_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'all_fields_and_indices_checked':True})
