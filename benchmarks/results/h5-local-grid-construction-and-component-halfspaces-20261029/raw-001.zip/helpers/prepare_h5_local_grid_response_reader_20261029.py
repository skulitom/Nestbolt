from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_area_cut_response_20261029.py').read_text(encoding='utf-8')
changes=[('h5-first55-cog-site-masks-20261029','h5-first55-local-grid-regions-20261029'),('area-cut-model','model'),('area-cut-search','search'),('area-cut-response-audit','response-audit'),('len(model.variables)==11638 and len(model.constraints)==63201','len(model.variables)==8336 and len(model.constraints)==43571'),("result['returned_response_branches']==32584", "result['returned_response_branches']==33140"),("result['returned_response_conflicts']==246", "result['returned_response_conflicts']==770"),("'max_lp':          0            0       1        19  10'052           0", "'max_lp':          0            9       0         0  12'829           0"),("'default_lp':          0            0       0         0   1'680           0", "'default_lp':          0            0       0         0      19           0"),("'max_lp_adjust_statistic':1,'max_lp_overflow_statistic':19,'max_lp_bad_statistic':10052,'default_lp_bad_statistic':1680", "'max_lp_cut_equal_propagations':9,'max_lp_overflow_statistic':0,'max_lp_bad_statistic':12829,'default_lp_bad_statistic':19")]
for a,b in changes:
    assert a in s,a
    s=s.replace(a,b)
p=ROOT/'output/audit_h5_local_grid_response_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'zero_overflow_and_retained_bad_counters_recorded':True})
