from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('check_h5_rigid_rectangle_candidate_20261029.py','check_h5_local_grid_candidate_20261029.py'),('run_h5_rigid_rectangle_model_20261029.py','run_h5_local_grid_model_20261029.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8')
    for a,b in [('h5-first55-cog-site-masks-20261029','h5-first55-local-grid-regions-20261029'),('rigid-model','model'),('rigid-search','search'),('integer-audit','geometry-audit'),('check_h5_rigid_rectangle_candidate_20261029.py','check_h5_local_grid_candidate_20261029.py')]:s=s.replace(a,b)
    if src.startswith('check_'):
        a="xy=[values[v]/1000 for v in owner['positions']]";b="xy=[values[v]/mapping['position_units_per_mm']+mapping['world_origin_mm'][k] for k,v in enumerate(owner['positions'])]"
        assert a in s;s=s.replace(a,b)
    p=ROOT/'output'/dst;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':2,'maximum_calls':1,'original_source66_readback_with_world_origin':True})
