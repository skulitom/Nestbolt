"""Seal the local-grid construction, closed response and exact component halfspace certificates."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SYNC=ROOT/'output/h5-cog-site-main-sync-20261029';PUB=BASE/'publication';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
NAME='h5-local-grid-construction-and-component-halfspaces-20261029';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,v):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(v)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='8ba6a6db886d0431316c4742d95fffc03e2a8ca5' and not git('diff','HEAD','--name-only')
for n in ['geometry-audit','model-audit','response-audit','component-halfspace-bound/audit']:assert load(BASE/n/'checks.json')['passed'],n
response=load(BASE/'response-audit/checks.json');assert response['closed_solver_calls']==1 and response['solver_status']=='UNKNOWN' and response['assignments']==0 and response['branches']==33140 and response['conflicts']==770 and response['solve_slice_overrun_seconds']>0 and response['overall_algorithm_shared_overruns_seconds']==0 and not response['infeasibility_proven'] and not response['any_allocation_excluded']
assert load(BASE/'component-halfspace-bound/audit/checks.json')['restricted_pairs_remaining']==29
assert digest(SHORT/'search/source-response/candidate-source11.json')=='8b7fa5f6ad765aab6fdba1a586c29d8cac2cce607ed1d7fcd0fb6938c4eeada0'
assert digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
prior=load(ROOT/'benchmarks/results/h5-cog-site-mask-and-rigid-component-searches-20261029/publication-review.json')
production=source_digest();readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert production==prior['production_digest'] and readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert load(PUB/'main.json')['commit']['sha']==ci['head_sha']==head and ci['id']==40827161407
assert len(jobs)==6 and sum(j['conclusion']=='success' for j in jobs)==4 and all(j['status']!='completed' or j['conclusion']=='success' for j in jobs)
receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['normal_atomic_fast_forward'] and receipt['prior_main_all6_pass']
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json';assert sum(r['excluded_by'] is None for r in load(frontier))==440
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(name,path):
    assert path.is_file() and '.claude' not in path.parts
    members[name]=path
    if path.name in ['plan.json','opened.json'] or path.suffix=='.py':queue.append(path)
for folder in [BASE,SLOTS,SYNC]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=set()
for pattern in ['*h5_local_grid*20261029.py','*h5_component_halfspace*20261029.py']:
    helpers.update((ROOT/'output').glob(pattern))
helpers.update(ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','ccd1.py','plot_h5_cog_site_accessible_area_20261029.py','push_h5_cog_site_checkpoint_20261029.py','verify_h5_local_grid_archive_20261029.py',Path(__file__).name])
for p in sorted(helpers):add('helpers/'+p.name,p)
while queue:
    path=queue.pop()
    if path in seen:continue
    seen.add(path)
    if path.name in ['plan.json','opened.json']:
        for name,h in load(path).get('inputs',{}).items():
            p=ROOT/name;assert p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts) and digest(p)==h,name
            bindings[name]=h;add('source-inputs/'+name,p)
    elif path.suffix=='.py':
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    p=ROOT/folder/(module+'.py')
                    if p.is_file():add('imported-helpers/'+folder+'/'+p.name,p)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(BASE/'checks.json','geometry-preparation.json'),(BASE/'geometry-audit/checks.json','geometry-audit.json'),(BASE/'model-audit/checks.json','model-audit.json'),(BASE/'model/preparation-charges.json','preparation-charges.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/lp-diagnostics.txt','lp-diagnostics.txt'),(BASE/'component-halfspace-bound/checks.json','component-halfspace-preparation.json'),(BASE/'component-halfspace-bound/audit/checks.json','component-halfspace-audit.json'),(BASE/'component-halfspace-bound/all35-halfspace-bounds.json','all35-halfspace-bounds.json'),(BASE/'component-halfspace-bound/source-inner-rectangles.json','source-inner-rectangles.json'),(BASE/'component-halfspace-bound/audit/allowed-empty-site-pairs.json','allowed-empty-site-pairs.json'),(BASE/'accessible-area-view/accessible-area.png','accessible-area.png'),(BASE/'preparation-corrections.json','preparation-corrections.json'),(BASE/'next-step.json','next-step.json'),(SYNC/'receipt.json','prior-main-push-receipt.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40827161407,'main_all6_pass':False,'successful_jobs_at_snapshot':4,'normal_push_requires_all6_and_fresh_head_and_live_run_checks':True,'unchanged_frontier_path':frontier.relative_to(ROOT).as_posix(),'unchanged_frontier_sha256':digest(frontier),'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'closed_new_solver_calls':1,'solver_status':'UNKNOWN','source_assignments':0,'variables':8336,'constraints':43571,'solve_slice_overrun_seconds':response['solve_slice_overrun_seconds'],'overall_algorithm_shared_overruns_seconds':0,'exact_integer_plane_implications':4559,'maximum_integer_plane_activity':239205000,'contained_source_rectangle_corners_verified':64,'source_region_component_assignments_verified':2358,'strengthened_halfspace_certificates':8,'additional_restricted_pairs_excluded':6,'restricted_site_pairs_excluded':76,'restricted_site_pairs_remaining':29,'source_valid_short11_preserved':True,'valid64_preserved':True,'first55_constructed':False,'source_valid66_created':False,'new_allocation_exclusions':0,'remaining_candidates':440,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8');old='Latest H5 evidence: [cog-site masks, rigid components and occupied-area bounds](../benchmarks/results/h5-cog-site-mask-and-rigid-component-searches-20261029.md).';new=f'Latest H5 evidence: [local-coordinate construction and component halfspace bounds](../benchmarks/results/{NAME}.md).';assert content.count(old)==1
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(content.replace(old,new,1))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'closed_calls':1,'source_valid66':False,'restricted_site_pairs_remaining':29,'remaining_candidates':440,'completion_percent':60})
