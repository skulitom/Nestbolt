"""Diagnostic view of source cog sites and conservative bracket occupancy covers."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';OUT=BASE/'accessible-area-view'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SITES=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight/source-cog-sites.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
OUT.mkdir();shutil.copyfile(__file__,OUT/'plot.py')
shape=next(p for p in load(JOB)['parts'] if p['id']=='cog')['geometry'][0]['outer'];sites=load(SITES)
groups={int(k):int(v,16) for k,v in load(PRIOR/'accessible-area-bound/family-mask-covers.json')['bracket'].items()}
fig,axes=plt.subplots(2,1,figsize=(12,13),constrained_layout=True)
for ax,empty in zip(axes,[[10,13],[10,12]]):
    mask=sum(1<<i for i in empty);bits=0
    for required,v in groups.items():
        if required&~mask==0:bits|=v
    cells=np.array([bool(bits>>i&1) for i in range(15000)],dtype=float).reshape(100,150)
    ax.imshow(np.ma.masked_where(cells==0,cells),extent=[0,1500,2000,3000],origin='lower',cmap='Greens',vmin=0,vmax=1,alpha=.30,interpolation='none')
    for i,row in enumerate(sites):
        t=row['transform'];angle=t['rotation_radians'];c,s=math.cos(angle),math.sin(angle);tx,ty=t['translation'];points=[]
        for x,y in shape:
            if t['mirrored']:x=-x
            points.append([c*x-s*y+tx,s*x+c*y+ty])
        removed=i in empty
        ax.add_patch(Polygon(points,closed=True,facecolor='none' if removed else '#334155',edgecolor='#b45309' if removed else '#0f172a',linewidth=1.4,linestyle='--' if removed else '-'))
        ax.text(sum(x for x,y in points)/len(points),sum(y for x,y in points)/len(points),str(i),ha='center',va='center',color='#92400e' if removed else 'white',fontsize=11,fontweight='bold')
    ax.axhline(2107.65,color='#b91c1c',lw=1.2)
    ax.set_xlim(0,1500);ax.set_ylim(2080,3000);ax.set_aspect('equal');ax.set_xlabel('Source X (mm)');ax.set_ylabel('Source Y (mm)');ax.set_title(f'Empty cog sites {empty}; green = conservative whole-bracket occupancy cover')
    ax.grid(alpha=.15)
fig.suptitle('Diagnostic source geometry — no bracket placement or full-layout feasibility claimed',fontsize=14)
fig.savefig(OUT/'accessible-area.png',dpi=140);plt.close(fig)
inputs=[Path(__file__),JOB,SITES,PRIOR/'accessible-area-bound/plan.json',PRIOR/'accessible-area-bound/audit/plan.json',PRIOR/'accessible-area-bound/audit/checks.json',PRIOR/'accessible-area-bound/family-mask-covers.json']
with (OUT/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'diagnostic_only':True,'selected_empty_pairs':[[10,13],[10,12]],'solver_calls':0},f,indent=2);f.write('\n')
print({'image':str(OUT/'accessible-area.png'),'diagnostic_only':True})
