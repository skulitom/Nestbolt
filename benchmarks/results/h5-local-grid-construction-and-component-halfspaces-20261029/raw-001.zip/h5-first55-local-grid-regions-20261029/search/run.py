"""One declared 60/90-second CP-SAT source construction on a micrometre grid."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, shutil, subprocess, sys, time

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-first55-local-grid-regions-20261029'
MODEL = BASE / 'model'
OUT = BASE / 'search'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def child(started):
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2
    from ortools.sat.python import cp_model
    from h5_source_projection_short_core_reader_20261029 import violations
    audit_checks = load(BASE / 'model-audit/checks.json')
    assert audit_checks['passed']
    for folder in [BASE, MODEL, BASE / 'model-audit', BASE / 'geometry-audit']:
        for name, expected in load(folder / 'plan.json')['inputs'].items():
            assert digest(ROOT / name) == expected, name
    model = cp_model.CpModel()
    assert model.proto.parse_text_format((MODEL / 'model.pbtxt').read_text()) and model.validate() == ''
    assert model.export_to_file(str(OUT / 'model.pb')) and digest(OUT / 'model.pb') == audit_checks['model_sha256']
    remaining = 60-(time.perf_counter()-started)-4
    assert remaining > 0
    solver = cp_model.CpSolver()
    parameters = {'max_time_in_seconds': remaining, 'num_search_workers': 4, 'random_seed': 0,
                  'log_search_progress': True, 'log_to_stdout': False, 'ignore_subsolvers': ['fj']}
    for name, value in parameters.items():
        if isinstance(value, list):
            getattr(solver.parameters, name).extend(value)
        else:
            setattr(solver.parameters, name, value)
    (OUT / 'parameters.pbtxt').write_text(str(solver.parameters), encoding='utf-8', newline='\n')
    inputs = [Path(__file__), ROOT / 'output/h5_source_projection_short_core_reader_20261029.py',
              ROOT / 'output/check_h5_local_grid_candidate_20261029.py', ROOT / 'output/h5_legacy64_source_readback.py',
              BASE / 'plan.json', MODEL / 'plan.json', MODEL / 'model.pb', MODEL / 'mapping.json', BASE / 'inventory.json',
              BASE / 'model-audit/plan.json', BASE / 'model-audit/checks.json', BASE / 'geometry-audit/plan.json', BASE / 'geometry-audit/checks.json']
    write(OUT / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
                              'model_sha256': audit_checks['model_sha256'], 'parameters': parameters,
                              'maximum_calls': 1, 'algorithm_seconds': 60, 'shared_seconds': 90,
                              'source_validation_reserve_seconds': 4, 'retry_permitted': False,
                              'preparation_seconds_charged': load(MODEL / 'checks.json')['preparation_seconds_charged']})
    class Capture(cp_model.CpSolverSolutionCallback):
        def __init__(self):
            super().__init__()
            self.count = 0
        def on_solution_callback(self):
            write(OUT / 'incumbents' / f'{self.count:03d}.json', {'sequence': self.count, 'solver_wall_seconds': self.wall_time,
                  'values': [self.value(model.get_int_var_from_proto_index(i)) for i in range(len(model.proto.variables))]})
            self.count += 1
    capture = Capture()
    with (OUT / 'solver.log').open('x', encoding='utf-8', newline='\n') as f:
        solver.log_callback = lambda value: (f.write(value+'\n'), f.flush())
        begin = time.perf_counter()
        status = solver.solve(model, capture)
        solve = time.perf_counter()-begin
    response = text_format.Parse(str(solver.response_proto), cp_model_pb2.CpSolverResponse())
    (OUT / 'response.pb').write_bytes(response.SerializeToString())
    source_valid = False
    source_checks = 0
    if response.solution:
        values = list(response.solution)
        write(OUT / 'assignment.json', values)
        proto = cp_model_pb2.CpModelProto()
        proto.ParseFromString((OUT / 'model.pb').read_bytes())
        checked = violations(proto, values)
        assert not checked['failed_constraints']
        write(OUT / 'assignment-check.json', checked)
        checker = subprocess.run([str(ROOT / '.cache/shop-venv/Scripts/python.exe'), str(ROOT / 'output/check_h5_local_grid_candidate_20261029.py'), str(started)],
                                 cwd=ROOT, capture_output=True, timeout=max(.01, 90-(time.perf_counter()-started)))
        (OUT / 'source-check-stdout.txt').write_bytes(checker.stdout)
        (OUT / 'source-check-stderr.txt').write_bytes(checker.stderr)
        assert checker.returncode == 0, checker.stderr.decode(errors='replace')
        source_valid = load(OUT / 'source-response/checks.json')['source_valid66']
        source_checks = 1
    algorithm = time.perf_counter()-started
    write(OUT / 'result.json', {'closed': True, 'solver_calls': 1, 'status': solver.status_name(status),
                              'returned_solve_seconds': solve, 'solver_wall_seconds': response.wall_time,
                              'allocated_solve_seconds': remaining, 'returned_solve_overrun_seconds': max(0., solve-remaining),
                              'returned_response_branches': response.num_branches, 'returned_response_conflicts': response.num_conflicts,
                              'has_assignment': bool(response.solution), 'incumbents_recorded': capture.count,
                              'algorithm_seconds_including_preparation': algorithm, 'algorithm_overrun_seconds': max(0., algorithm-60),
                              'preparation_seconds_charged': load(MODEL / 'checks.json')['preparation_seconds_charged'],
                              'source_checker_calls': source_checks, 'source_valid66': source_valid,
                              'any_allocation_excluded': False, 'native_calls': 0, 'H5_complete': False})

def main():
    assert load(BASE / 'model-audit/checks.json')['passed']
    OUT.mkdir()
    (OUT / 'incumbents').mkdir()
    shutil.copyfile(__file__, OUT / 'run.py')
    charge = load(MODEL / 'checks.json')['preparation_seconds_charged']
    start = time.perf_counter()-charge
    write(OUT / 'budget.json', {'utc': datetime.now(timezone.utc).isoformat(), 'algorithm_seconds': 60, 'shared_seconds': 90,
                              'maximum_calls': 1, 'retry_permitted': False, 'source_validation_reserve_seconds': 4,
                              'preparation_seconds_charged': charge})
    try:
        process = subprocess.run([str(ROOT / '.cache/h5-cpsat-cpython-venv/Scripts/python.exe'), str(Path(__file__)), '--child', str(start)],
                                 cwd=ROOT, capture_output=True, timeout=max(.01, 90-(time.perf_counter()-start)))
        (OUT / 'stdout.txt').write_bytes(process.stdout)
        (OUT / 'stderr.txt').write_bytes(process.stderr)
        summary = {'seconds_including_preparation': time.perf_counter()-start, 'exit_code': process.returncode, 'timeout': False, 'closed': True}
    except subprocess.TimeoutExpired as error:
        (OUT / 'stdout.txt').write_bytes(error.stdout or b'')
        (OUT / 'stderr.txt').write_bytes(error.stderr or b'')
        summary = {'seconds_including_preparation': time.perf_counter()-start, 'timeout': True, 'closed': True}
    write(OUT / 'process.json', summary)
    print(summary, flush=True)
    print(load(OUT / 'result.json') if (OUT / 'result.json').exists() else 'No final result; this call remains closed.', flush=True)

if __name__ == '__main__':
    child(float(sys.argv[2])) if '--child' in sys.argv else main()
