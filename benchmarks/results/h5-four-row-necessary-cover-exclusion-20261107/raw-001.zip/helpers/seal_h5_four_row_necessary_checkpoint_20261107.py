"""Seal the full-stock necessary-cover exclusion of the fixed four-row core."""
from pathlib import Path
import json, shutil, subprocess
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-four-row-necessary-cover-exclusion-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-four-row-necessary-cover-20261107';F=BASE/'audit';D=BASE",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-four-row-contact-phase-and-companion-spaces-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['maximum_brackets']==4 and front['fixed48_core_cannot_extend_to_full66'] and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-four-row-necessary-cover-process-20261107',ROOT/'output/h5-four-row-necessary-cover-audit-process-20261107']",
"['*h5*mixed*mode*20261107.py']":"['*h5*four_row*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_four_row_necessary_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(ROOT/'output/h5-screened-source-preflight-20261107/runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(BASE/'plan.json','source-cover-plan.json'),(BASE/'checks.json','preparation.json'),(BASE/'summary.json','mode-census.json'),(F/'plan.json','audit-plan.json'),(F/'checks.json','independent-audit.json'),(F/'capacity.json','capacity.json'),(F/'class-cover-controls.json','class-cover-controls.json'),(F/'source-containment.json','source-containment.json'),(ROOT/'output/h5-four-row-necessary-cover-process-20261107/process.json','preparation-process.json'),(ROOT/'output/h5-four-row-necessary-cover-audit-process-20261107/process.json','audit-process.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
capacity=load(F/'capacity.json');process=load(OUT/'preparation-process.json');auditprocess=load(OUT/'audit-process.json')
ci=json.loads(subprocess.check_output(['gh','run','view','42399328273','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='bf239548117594ce78bae7b588fc1e8508ffc74e'
write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'checks.json',{'passed':True,**archive,'source_bindings':len(bindings),'external_evidence_references':len(external),'pinned_runtime_files':len(runtime),**front})
write(OUT/'next-step.json',{'status':'fixed_four_row_core_excluded','finding':'The valid 48-part core cannot extend to the intended full66 arrangement. All original bracket modes over the full physical first sheet have a certified necessary cover; its occupied envelope allows at most four brackets, but6 are required. This is independent of insert placement and is not restricted to the earlier constructive center cells.','proposal':'Return to the unresolved construction frontier. Completing this allocation requires changing at least one fixed frame/cog placement or moving an identity between sheets. Prefer a source-derived change to the occupied-core arrangement or a still-unresolved allocation, with a new structural feasibility check before any bounded placement selection. Preserve the valid48 reference and the original source/native/material acceptance requirements.','constraints':['No retry, seed/offset/angle sweep or objective-weight reset of any closed call. All25 mathematical keys remain closed.','The proof excludes only this exact fixed48 core under the existing filled-outline/no-hole-rider source semantics; four earlier fixed arrangements and440 whole-job allocation candidates remain unresolved.','If this preparation lineage is consumed, retain45.35631989967078s complete source preparation, including the failed serialization. Do not discard preparation costs or substitute this narrow proof for full66/native/material checks.','H2/H5 remain open at 60% completed milestone weight. No release is justified by an evidence-only exclusion.'],'optimizer_calls':0,'solver_calls':0,'remaining_earlier_arrangements':4,'remaining_whole_job_allocations':440,'H5_complete':False})
report=f'''# Four-row necessary-cover exclusion — 2026-11-07

The valid 48-part core cannot be completed to its intended 66-part layout.
A full-sheet necessary cover for every allowed bracket orientation permits
at most **four brackets**, while **six are required**. This excludes the exact
fixed core, including positions outside the earlier conservative construction.
It does not exclude moving the core or changing the sheet allocation. H2/H5
remain open at **60% completed milestone weight**.

[The source construction]({NAME}/source-cover-plan.json) begins with original
filled outlines, matching the existing no-hole-rider source validator. Holes
remain unchanged. It places **468 rectangles strictly inside the 18 fixed frames
and 15 fixed cogs**. Each bracket mode has two contained component rectangles.
Pairs of contained rectangles define exact open forbidden center rectangles.
The stock domain covers the complete physical first sheet, rounded outward;
no earlier constructive strip or center-cell restriction is imported.

[Independent readback]({NAME}/independent-audit.json) verifies all contained
rectangles with rational arithmetic, including **1e-6 mm inward padding**.
It checks the 21 convex cog pieces against the original outline by oriented
boundary cancellation, and verifies the exact two-rectangle bracket decomposition.
The arithmetic error bound is below **5.821e-11 mm**, smaller than the padding.
[Containment records]({NAME}/source-containment.json) preserve every source owner.
Zero clearance enlarges the feasible space and is used only for this exclusion.

Every obstacle endpoint partitions each axis into individual boundary points
and intervening open intervals. The producer labels their Cartesian classes
by slice assignment; the independent audit instead uses four signed rectangle
corners and two cumulative sums. All **3,707,540 continuous classes** match.
These are exhaustive regions, not sampled placement points. Boundary, corner,
overlapping-obstacle and outside-source negative controls pass.
[All eight allowed modes]({NAME}/mode-census.json) are included. Only two modes
retain space: **3,564 classes**, covered by **six closed rectangles**. Closing
the component boundaries only enlarges the cover.
[Class and cover checks]({NAME}/class-cover-controls.json) verify every retained
class and preserve all isolated boundary classes.

[The rational occupied-envelope bound]({NAME}/capacity.json) contains every
possible bracket in that necessary cover within
**[{capacity['envelope_mm'][0]:.6f}, {capacity['envelope_mm'][1]:.6f}]
to [{capacity['envelope_mm'][2]:.6f}, {capacity['envelope_mm'][3]:.6f}] mm**.
Its area is **{capacity['envelope_area_mm2']:.6f} mm²**. Each filled original bracket
occupies 40,000 mm²; **39,999 mm²** is a conservative lower bound after the
explicit transform and rounding allowance. Five brackets already exceed the
envelope, so at most four fit. Six are required before even considering the
twelve remaining inserts. The exact fixed48 core therefore cannot extend to
this full 66-part allocation. Four earlier arrangements and all 440 whole-job
allocation candidates remain unresolved.

[Preparation]({NAME}/preparation-process.json) closes in **{process['complete_seconds']:.6f} s**,
for **{front['complete_preparation_seconds_if_consumed']:.6f} s** retained preparation
if this lineage is consumed. [Independent audit]({NAME}/audit-process.json)
closes in **{auditprocess['complete_seconds']:.6f} s**. Both use CCD1, one numerical
thread and the verified 2 GiB Job Object controls; all child processes close.
No optimizer or solver runs and no closed mathematical key is reopened.

[Next]({NAME}/next-step.json), change the fixed arrangement or investigate an
unresolved allocation before another placement selection. Keep the valid48
reference and failed full66 results. Product integration, full66 source/native
validation, surface parity and the original H5 matrix remain required.

Main remains bf239548 with **{success} passed / {live} live jobs** in
[this snapshot]({NAME}/main-ci-at-review.json). The previous phase checkpoint is
committed locally as b6d43a8e. Product code, README and releases are unchanged.

[Archive checks]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the complete proof inputs.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 full-stock four-row exclusion:** [independent necessary-cover proof]({{link}}) verifies 468 source-contained rectangles, all eight allowed bracket orientations and 3,707,540 continuous boundary/interval classes over the entire physical first sheet. Exactly 3,564 retained classes have six closed covering rectangles. Their 168935.817519 mm2 occupied envelope permits at most four filled original brackets at a conservative 39999 mm2 each ; six are required. The valid 48-part fixed core therefore cannot extend to the intended 66-part allocation, including positions outside earlier conservative cells. This excludes no earlier arrangement or whole-job allocation. The 2.304900 s preparation retains 45.356320 s total if consumed; independent audit closes in 0.828098 s. No optimizer/solver runs, all 25 keys stay closed, and four earlier arrangements plus 440 allocations remain. H2/H5 remain open at 60%. Main bf239548 has {success} passed / {live} live CI jobs at review; product and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [full-stock four-row exclusion](../benchmarks/results/{NAME}.md).
The valid 48-part core cannot extend to its intended full 66-part allocation. A necessary
cover spans the full physical first sheet and all eight allowed bracket orientations.
Independent rational containment and event/count checks verify 468 inner source
rectangles and 3,707,540 boundary/interval classes. Their occupied envelope holds
at most four original brackets, versus six required. This rules out the exact fixed core,
including placements outside the earlier conservative construction. It does
not exclude moving the core, four earlier arrangements or 440 whole allocations.
Next change the fixed arrangement or investigate an unresolved allocation.
Preparation totals 45.356320 s if consumed; the failed serialization is retained.
No optimizer/solver runs; all 25 mathematical keys stay closed. H2/H5 remain open
at 60%. Main bf239548 has {success} passed / {live} live jobs at review; the earlier
phase checkpoint is committed locally as b6d43a8e. Product and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
