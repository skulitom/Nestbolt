"""Source-necessary continuous bracket cover for the fixed four-row core."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from collections import Counter
from itertools import product
import json, math, os, time
import numpy as np
from h5_checked_affinity_20261107 import affinity_mask

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'output/h5-four-row-necessary-cover-20261107'
PHASE = ROOT/'output/h5-four-row-contact-phase-20261107'
LIB = ROOT/'output/h5-bracket-augmented-model-20261107/library.json'
JOB = ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PIECES = ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
PAD = F(1, 10**6)

def write(p, v):
    with p.open('x', encoding='utf-8', newline='\n') as f: json.dump(v, f, indent=2, allow_nan=False); f.write('\n')

def cross(a,b,c): return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p): return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))/2
def transform(p,t):
    c,s = F(math.cos(t['rotation_radians'])), F(math.sin(t['rotation_radians']))
    sign = -1 if t['mirrored'] else 1; tx,ty = map(F,t['translation'])
    q = [(sign*F(x)*c-F(y)*s+tx, sign*F(x)*s+F(y)*c+ty) for x,y in p]
    return q if area(q)>0 else q[::-1]
def contains(p,r):
    return all(cross(a,b,v)>0 for a,b in zip(p,p[1:]+p[:1]) for v in product([r[0],r[2]],[r[1],r[3]]))
def expanded(r): return [F(v,1000)+(-PAD if k<2 else PAD) for k,v in enumerate(r)]
def inward(r): return [math.ceil((r[k]+2*PAD)*1000) if k<2 else math.floor((r[k]-2*PAD)*1000) for k in range(4)]
def inner_orthogonal(p):
    r = inward([min(x for x,y in p),min(y for x,y in p),max(x for x,y in p),max(y for x,y in p)])
    assert contains(p,expanded(r)); return r
def section(p,y):
    xs=[]
    for a,b in zip(p,p[1:]+p[:1]):
        if a[1]==b[1]:
            if y==a[1]:xs.extend([a[0],b[0]])
        elif min(a[1],b[1])<=y<=max(a[1],b[1]):xs.append(a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]))
    return min(xs),max(xs)
def edges(p):
    result=Counter()
    for a,b in zip(p,p[1:]+p[:1]):
        a,b=tuple(a),tuple(b)
        if a<b:result[(a,b)]+=1
        else:result[(b,a)]-=1
    return result
def classes(cuts):
    out=np.empty(2*len(cuts)-1,dtype=np.int64);out[::2]=2*cuts;out[1::2]=cuts[:-1]+cuts[1:];return out
def deadline(): assert time.perf_counter()-began<18, 'Declared preparation cap reached; no audited exclusion.'

OUT.mkdir();began=time.perf_counter()
assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
assert load(PHASE/'audit/checks.json')['passed']
lib=load(LIB);job=load(JOB);parts={p['id']:p for p in job['parts']};core=load(PHASE/'fixed33-and-cogs15.json');canonical=load(PIECES)
inputs=[Path(__file__),LIB,JOB,PIECES,PHASE/'fixed33-and-cogs15.json',PHASE/'audit/checks.json',ROOT/'output/h5-four-row-companion-spaces-v2-20261107/audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'All eight allowed original bracket orientations over the full physical first sheet. Source-contained inner rectangles for the eighteen fixed frames and fifteen fixed cogs induce exact open forbidden center rectangles with the two source-contained bracket components. Integer axis arrangements include every boundary point and open interval. Their complement is a necessary outer cover at zero clearance, never a sufficient placement domain. No constructive center bounds, optimizer or saved optimized initializer are used. Exact source piece containment and full cover require independent audit before exclusion.','source_semantics':'Filled original outlines as required by the existing no-hole-rider source validator. Original holes remain unchanged.','preparation_cap_seconds':18,'process_cap_seconds':20,'maximum_classes_per_mode':40000000,'memory_bytes':2**31,'rounding_padding_mm':1e-6,'complete_prior_preparation_seconds':load(inputs[-1])['complete_preparation_seconds_if_consumed'],'charge_process_if_consumed':True,'optimizer_calls':0,'solver_calls':0,'retry_permitted':False})
# Cog pieces are convex and their oriented boundaries exactly cancel to the
# original boundary. Winding-number addition therefore verifies their cover.
sumedges=Counter()
for piece in canonical['cog']:
    p=[tuple(map(F,v)) for v in piece];assert area(p)>0 and all(cross(a,b,c)>=0 for a,b,c in zip(p,p[1:]+p[:1],p[2:]+p[:2]))
    sumedges.update(edges(piece))
assert {k:v for k,v in sumedges.items() if v}=={k:v for k,v in edges(parts['cog']['geometry'][0]['outer']).items() if v}
assert canonical['bracket']==[[[0,0],[300,0],[300,75],[0,75]],[[0,75],[100,75],[100,250],[0,250]]]
assert parts['bracket']['geometry'][0]['outer']==[[0.,0.],[300.,0.],[300.,75.],[100.,75.],[100.,250.],[0.,250.]]
first=next(r for r in core if r['part_id']=='cog');angle=first['transform']['rotation_radians']
local_pose={'rotation_radians':angle,'mirrored':False,'translation':[0.,0.]}
local_pieces=[transform(p,local_pose) for p in canonical['cog']];candidates=[]
for pi,p in enumerate(local_pieces):
    ys=sorted({v[1] for v in p});sections={y:section(p,y) for y in ys}
    for i,a in enumerate(ys):
        for b in ys[i+1:]:
            r=inward([max(sections[a][0],sections[b][0]),a,min(sections[a][1],sections[b][1]),b])
            if r[0]<r[2] and r[1]<r[3] and contains(p,expanded(r)):candidates.append({'piece':pi,'bounds_um':r})
    deadline()
unique={tuple(r['bounds_um']):r for r in candidates};retained=[]
for r in sorted(unique.values(),key=lambda r:-(r['bounds_um'][2]-r['bounds_um'][0])*(r['bounds_um'][3]-r['bounds_um'][1])):
    a,b,c,d=r['bounds_um']
    if not any(q['bounds_um'][0]<=a and q['bounds_um'][1]<=b and c<=q['bounds_um'][2] and d<=q['bounds_um'][3] for q in retained):retained.append(r)
obstacle_sources=[]
for owner,row in enumerate(core):
    if row['sheet_id']!='sheet-0':continue
    if row['part_id']=='frame':
        p=transform(parts['frame']['geometry'][0]['outer'],row['transform']);r=inner_orthogonal(p)
        obstacle_sources.append({'owner':owner,'identity':[row['part_id'],row['copy_index']],'piece':0,'bounds_um':r})
    else:
        assert row['part_id']=='cog' and row['transform']['rotation_radians']==angle and not row['transform']['mirrored']
        pieces=[transform(p,row['transform']) for p in canonical['cog']];shift=list(map(F,row['transform']['translation']))
        for rec in retained:
            r=inward([F(v,1000)+shift[k%2] for k,v in enumerate(rec['bounds_um'])]);assert contains(pieces[rec['piece']],expanded(r))
            obstacle_sources.append({'owner':owner,'identity':[row['part_id'],row['copy_index']],'piece':rec['piece'],'bounds_um':r})
    deadline()
write(OUT/'local-cog-rectangles.json',retained);write(OUT/'source-inner-rectangles.json',obstacle_sources)
assert parts['bracket']['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]} and parts['bracket']['allow_mirror']
modes={m['source_mode']:m for m in lib['family_modes']['bracket']};assert set(modes)==set(range(8))
stock=list(map(F,lib['source_stocks']['sheet-0']));cx,cy=lib['families']['bracket']['source_center'];records=[];envelopes=[]
for mode,record in sorted(modes.items()):
    theta=record['rotation_radians'];cs,sn=math.cos(theta),math.sin(theta);sign=-1 if record['mirrored'] else 1
    pose={'rotation_radians':theta,'mirrored':record['mirrored'],'translation':[-(sign*cx*cs-cy*sn),-(sign*cx*sn+cy*cs)]}
    components=[inner_orthogonal(transform(p,pose)) for p in canonical['bracket']];outer=transform(parts['bracket']['geometry'][0]['outer'],pose)
    lo=[min(v[k] for v in outer) for k in range(2)];hi=[max(v[k] for v in outer) for k in range(2)]
    exact_domain=[stock[0]-lo[0]-PAD,stock[1]-lo[1]-PAD,stock[2]-hi[0]+PAD,stock[3]-hi[1]+PAD]
    domain=[math.floor(v*1000) if k<2 else math.ceil(v*1000) for k,v in enumerate(exact_domain)];obstacles=[]
    for i,source in enumerate(obstacle_sources):
        u,v,w,z=source['bounds_um']
        for k,(a,b,c,d) in enumerate(components):
            r=[u-c,v-d,w-a,z-b]
            if r[0]>=domain[2] or r[2]<=domain[0] or r[1]>=domain[3] or r[3]<=domain[1]:continue
            obstacles.append({'source':i,'component':k,'bounds_um':r})
    xs=np.array(sorted({domain[0],domain[2]}|{v for o in obstacles for v in o['bounds_um'][::2] if domain[0]<=v<=domain[2]}),dtype=np.int64)
    ys=np.array(sorted({domain[1],domain[3]}|{v for o in obstacles for v in o['bounds_um'][1::2] if domain[1]<=v<=domain[3]}),dtype=np.int64)
    xx,yy=classes(xs),classes(ys);assert len(xx)*len(yy)<=40000000
    blocked=np.zeros((len(yy),len(xx)),dtype=np.bool_)
    for o in obstacles:
        a,b,c,d=o['bounds_um'];xa,xb=np.searchsorted(xx,[2*a,2*c],side='left');ya,yb=np.searchsorted(yy,[2*b,2*d],side='left')
        xa=int(np.searchsorted(xx,2*a,side='right'));ya=int(np.searchsorted(yy,2*b,side='right'));blocked[ya:yb,xa:xb]=True
    np.savez_compressed(OUT/f'mode-{mode:02d}-classes.npz',xcuts_um=xs,ycuts_um=ys,blocked=blocked)
    boxes=[];active={}
    def close(key,span):
        xa,xb=key;ya,yb=span;boxes.append([int(xs[xa//2]),int(ys[ya//2]),int(xs[(xb+1)//2]),int(ys[(yb+1)//2]),xa,ya,xb,yb])
    for yi,row in enumerate(blocked):
        starts=np.r_[0,np.flatnonzero(row[1:]!=row[:-1])+1];ends=np.r_[starts[1:]-1,len(row)-1];current={}
        for xa,xb in zip(starts.tolist(),ends.tolist()):
            if row[xa]:continue
            key=(xa,xb);current[key]=[active[key][0] if key in active else yi,yi]
        for key,span in active.items():
            if key not in current:close(key,span)
        active=current
    for key,span in active.items():close(key,span)
    boxes.sort();bounds=[min(r[0] for r in boxes),min(r[1] for r in boxes),max(r[2] for r in boxes),max(r[3] for r in boxes)] if boxes else None
    envelope=[F(bounds[k],1000)+lo[k]-PAD for k in range(2)]+[F(bounds[k+2],1000)+hi[k]+PAD for k in range(2)] if boxes else None
    if envelope:envelopes.append(envelope)
    output={'mode':mode,'source_pose_at_center_zero':pose,'inner_components_um':components,'exact_outer_bounds_mm':list(map(str,lo+hi)),'exact_stock_center_domain_mm':list(map(str,exact_domain)),'outward_stock_center_domain_um':domain,'obstacles':obstacles,'cover':boxes,'cover_bounds_um':bounds,'occupied_envelope_mm':list(map(str,envelope)) if envelope else None}
    write(OUT/f'mode-{mode:02d}.json',output)
    records.append({'mode':mode,'obstacles':len(obstacles),'classes':int(blocked.size),'unblocked_classes':int(np.count_nonzero(~blocked)),'cover_boxes':len(boxes),'cover_bounds_um':bounds})
    deadline()
combined=[min(r[k] for r in envelopes) for k in range(2)]+[max(r[k] for r in envelopes) for k in range(2,4)] if envelopes else None
envelope_area=(combined[2]-combined[0])*(combined[3]-combined[1]) if combined else F(0)
write(OUT/'summary.json',records)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'source_inner_rectangles':len(obstacle_sources),'local_cog_rectangles':len(retained),'legal_bracket_modes':8,'all_classes':sum(r['classes'] for r in records),'unblocked_classes':sum(r['unblocked_classes'] for r in records),'cover_boxes':sum(r['cover_boxes'] for r in records),'combined_occupied_envelope_mm':list(map(str,combined)) if combined else None,'envelope_area_mm2':float(envelope_area),'provisional_capacity_at_39999mm2':int(envelope_area//39999),'required_brackets':6,'independent_audit_pending':True,'fixed_core_excluded':False,'whole_allocations_excluded':0,'optimizer_calls':0,'solver_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
