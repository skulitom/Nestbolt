"""Independent rational containment and continuous class-count proof readback."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from bisect import bisect_left, bisect_right
import json, math, time
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-four-row-necessary-cover-20261107';OUT=BASE/'audit'
PHASE=ROOT/'output/h5-four-row-contact-phase-20261107'
LIB=ROOT/'output/h5-bracket-augmented-model-20261107/library.json'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
PAD=Q(1,10**6)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def determinant(a,b):return a[0]*b[1]-a[1]*b[0]
def signed_area(p):return sum(determinant(a,b) for a,b in zip(p,p[1:]+p[:1]))/2
def posed(vertices,pose):
    c,s=Q(math.cos(pose['rotation_radians'])),Q(math.sin(pose['rotation_radians']));m=-1 if pose['mirrored'] else 1
    matrix=((m*c,-s),(m*s,c));translation=list(map(Q,pose['translation']))
    result=[tuple(sum(matrix[k][j]*Q(v[j]) for j in range(2))+translation[k] for k in range(2)) for v in vertices]
    return result if signed_area(result)>0 else result[::-1]
def strict_containment(p,r):
    corners=[(Q(x,1000)+sx*PAD,Q(y,1000)+sy*PAD) for x,sx in [(r[0],-1),(r[2],1)] for y,sy in [(r[1],-1),(r[3],1)]]
    return all(determinant((b[0]-a[0],b[1]-a[1]),(v[0]-a[0],v[1]-a[1]))>0 for a,b in zip(p,p[1:]+p[:1]) for v in corners)
def boundary(p):
    result={}
    for a,b in zip(p,p[1:]+p[:1]):
        a,b=tuple(map(Q,a)),tuple(map(Q,b));key=tuple(sorted((a,b)))
        result[key]=result.get(key,0)+(1 if a<b else -1)
    return result
def axis_classes(cuts):
    return [v for i,x in enumerate(cuts) for v in ([2*int(x),int(x+cuts[i+1])] if i+1<len(cuts) else [2*int(x)])]
def count_obstacles(xx,yy,rects):
    diff=np.zeros((len(yy)+1,len(xx)+1),dtype=np.int32)
    for a,b,c,d in rects:
        i,j=bisect_right(xx,2*a),bisect_left(xx,2*c);k,l=bisect_right(yy,2*b),bisect_left(yy,2*d)
        diff[k,i]+=1;diff[l,i]-=1;diff[k,j]-=1;diff[l,j]+=1
    return np.cumsum(np.cumsum(diff,axis=0,dtype=np.int32),axis=1,dtype=np.int32)[:-1,:-1]

OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');prepared=load(BASE/'checks.json')
paths=[Path(__file__),LIB,JOB,PIECES,PHASE/'fixed33-and-cogs15.json',PHASE/'audit/checks.json',ROOT/'output/h5-four-row-necessary-cover-process-20261107/process.json']+[p for p in BASE.iterdir() if p.is_file()]
bindings={p.relative_to(ROOT).as_posix():digest(p) for p in paths}
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h;bindings[name]=h
write(OUT/'plan.json',{'inputs':bindings,'method':'Independent exact-rational source decomposition/containment readback. Reconstruct all physical stock domains and open forbidden rectangles. Independently accumulate rectangle counts by four signed corners and two prefix sums, rather than producer slice assignment, over every boundary/interval Cartesian class. Verify retained covers contain every unblocked class and none of the blocked classes. Bound all possible original bracket occupancy using exact interval sums and rounding pads; the area lower bound applies to filled outlines in the existing no-hole-rider validator. No geometry library, solver or optimizer is used.','scope':'Only the exact fixed48 core and all eight declared original bracket modes on the physical first sheet; moving any fixed geometry or using another sheet allocation is not excluded.','audit_cap_seconds':15,'optimizer_calls':0,'solver_calls':0,'retry_permitted':False})
lib=load(LIB);job=load(JOB);parts={p['id']:p for p in job['parts']};canonical=load(PIECES);core=load(PHASE/'fixed33-and-cogs15.json')
assert load(PHASE/'audit/checks.json')['passed'] and len(core)==48 and len([r for r in core if r['sheet_id']=='sheet-0'])==33
# Winding cancellation plus convex positive orientation gives exact source cover.
net={}
for p0 in canonical['cog']:
    p=[tuple(map(Q,v)) for v in p0];assert signed_area(p)>0
    assert all(determinant((b[0]-a[0],b[1]-a[1]),(v[0]-a[0],v[1]-a[1]))>=0 for a,b in zip(p,p[1:]+p[:1]) for v in p)
    for edge,n in boundary(p).items():net[edge]=net.get(edge,0)+n
assert {k:v for k,v in net.items() if v}=={k:v for k,v in boundary(parts['cog']['geometry'][0]['outer']).items() if v}
assert canonical['bracket']==[[[0,0],[300,0],[300,75],[0,75]],[[0,75],[100,75],[100,250],[0,250]]]
assert parts['bracket']['geometry'][0]['outer']==[[0.,0.],[300.,0.],[300.,75.],[100.,75.],[100.,250.],[0.,250.]]
# Floating evaluations use fewer than64 operations with magnitudes below8192.
# Every certified inner rectangle stays1e-6mm inside every relevant exact edge.
rounding_bound=Q(64*8192,2**53-64);assert rounding_bound<PAD
sources=load(BASE/'source-inner-rectangles.json');containment=[];source_shapes={}
for i,row in enumerate(core):
    if row['sheet_id']!='sheet-0':continue
    pieces=canonical['cog'] if row['part_id']=='cog' else [parts[row['part_id']]['geometry'][0]['outer']]
    source_shapes[i]=[posed(p,row['transform']) for p in pieces]
    assert all(abs(value)<4096 for polygon in source_shapes[i] for vertex in polygon for value in vertex)
for source in sources:
    owner=source['owner'];row=core[owner];assert source['identity']==[row['part_id'],row['copy_index']] and row['sheet_id']=='sheet-0'
    r=source['bounds_um'];assert r[0]<r[2] and r[1]<r[3]
    assert strict_containment(source_shapes[owner][source['piece']],r)
    containment.append({'owner':owner,'piece':source['piece'],'strict_padding_verified':True})
assert len(sources)==468 and len({r['owner'] for r in sources})==33
# These controls specifically retain open-rectangle edges and their corner points.
grid=[0,1,2,3,4];fixture=count_obstacles(grid,grid,[(0,0,2,2)])
assert fixture.tolist()==[[0,0,0,0,0],[0,1,1,1,0],[0,1,1,1,0],[0,1,1,1,0],[0,0,0,0,0]]
overlap=count_obstacles(grid,grid,[(0,0,2,2),(0,0,2,2)]);assert np.array_equal(overlap,2*fixture)
assert not strict_containment(source_shapes[sources[0]['owner']][sources[0]['piece']],[-1000,-1000,10000000,10000000])
assert parts['bracket']['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]} and parts['bracket']['allow_mirror']
allowed={(math.radians(deg),mirror) for deg in parts['bracket']['rotations']['degrees'] for mirror in [False,True]};seen=set();records=[];envelopes=[];maxdet=Q(0)
stock=list(map(Q,lib['source_stocks']['sheet-0']));total=0;retained_count=0
for mode in range(8):
    data=load(BASE/f'mode-{mode:02d}.json');pose=data['source_pose_at_center_zero'];assert data['mode']==mode
    angle=pose['rotation_radians'];seen.add((angle,pose['mirrored']));assert (angle,pose['mirrored']) in allowed
    c,s=Q(math.cos(angle)),Q(math.sin(angle));maxdet=max(maxdet,abs(c*c+s*s-1));assert maxdet<Q(1,2**40)
    outer=posed(parts['bracket']['geometry'][0]['outer'],pose);components=[posed(p,pose) for p in canonical['bracket']]
    assert len(components)==len(data['inner_components_um'])==2
    for polygon,rect in zip(components,data['inner_components_um']):assert strict_containment(polygon,rect)
    low=[min(p[k] for p in outer) for k in range(2)];high=[max(p[k] for p in outer) for k in range(2)]
    assert list(map(Q,data['exact_outer_bounds_mm']))==low+high
    full=[stock[0]-low[0]-PAD,stock[1]-low[1]-PAD,stock[2]-high[0]+PAD,stock[3]-high[1]+PAD];assert list(map(Q,data['exact_stock_center_domain_mm']))==full
    domain=[math.floor(v*1000) if k<2 else math.ceil(v*1000) for k,v in enumerate(full)];assert data['outward_stock_center_domain_um']==domain
    assert all(abs(value)<4096 for value in stock+low+high+[Q(v,1000) for v in domain])
    expected=[]
    for i,source in enumerate(sources):
        fixed=source['bounds_um']
        for k,moving in enumerate(data['inner_components_um']):
            rect=[fixed[0]-moving[2],fixed[1]-moving[3],fixed[2]-moving[0],fixed[3]-moving[1]]
            if rect[0]<domain[2] and rect[2]>domain[0] and rect[1]<domain[3] and rect[3]>domain[1]:expected.append({'source':i,'component':k,'bounds_um':rect})
    assert expected==data['obstacles']
    xs=sorted({domain[0],domain[2]}|{o['bounds_um'][k] for o in expected for k in [0,2] if domain[0]<=o['bounds_um'][k]<=domain[2]})
    ys=sorted({domain[1],domain[3]}|{o['bounds_um'][k] for o in expected for k in [1,3] if domain[1]<=o['bounds_um'][k]<=domain[3]})
    xx,yy=axis_classes(xs),axis_classes(ys);counts=count_obstacles(xx,yy,[o['bounds_um'] for o in expected]);assert np.min(counts)>=0
    with np.load(BASE/f'mode-{mode:02d}-classes.npz',allow_pickle=False) as saved:
        assert saved['xcuts_um'].tolist()==xs and saved['ycuts_um'].tolist()==ys
        assert np.array_equal(saved['blocked'],counts>0)
    covered=np.zeros(counts.shape,dtype=np.bool_)
    for a,b,c0,d,xa,ya,xb,yb in data['cover']:
        assert 0<=xa<=xb<len(xx) and 0<=ya<=yb<len(yy)
        assert [a,b,c0,d]==[xs[xa//2],ys[ya//2],xs[(xb+1)//2],ys[(yb+1)//2]]
        assert np.all(counts[ya:yb+1,xa:xb+1]==0);covered[ya:yb+1,xa:xb+1]=True
    assert np.array_equal(covered,counts==0)
    bounds=[min(r[0] for r in data['cover']),min(r[1] for r in data['cover']),max(r[2] for r in data['cover']),max(r[3] for r in data['cover'])] if data['cover'] else None
    assert bounds==data['cover_bounds_um']
    env=[Q(bounds[k],1000)+low[k]-PAD for k in range(2)]+[Q(bounds[k+2],1000)+high[k]+PAD for k in range(2)] if bounds else None
    assert (list(map(Q,data['occupied_envelope_mm'])) if data['occupied_envelope_mm'] else None)==env
    if env:envelopes.append(env)
    count=int(np.count_nonzero(covered));total+=counts.size;retained_count+=count
    records.append({'mode':mode,'all_continuous_classes':int(counts.size),'retained_classes':count,'cover_boxes':len(data['cover']),'all_counts_and_cover_verified':True})
assert seen==allowed and total==prepared['all_classes']==3707540 and retained_count==prepared['unblocked_classes']==3564
combined=[min(r[k] for r in envelopes) for k in range(2)]+[max(r[k] for r in envelopes) for k in range(2,4)]
assert combined==list(map(Q,prepared['combined_occupied_envelope_mm']))
area=(combined[2]-combined[0])*(combined[3]-combined[1]);original=signed_area([tuple(map(Q,p)) for p in parts['bracket']['geometry'][0]['outer']]);assert original==40000
error=6*(2*4096*PAD+PAD*PAD)+original*maxdet;assert original-error>39999
capacity=int(area//39999);assert capacity==4 and capacity<6
process=load(ROOT/'output/h5-four-row-necessary-cover-process-20261107/process.json');assert process['passed'] and process['closed']
charge=plan['complete_prior_preparation_seconds']+process['complete_seconds']
write(OUT/'source-bindings.json',bindings);write(OUT/'source-containment.json',containment);write(OUT/'class-cover-controls.json',records)
write(OUT/'capacity.json',{'passed':True,'scope':'The exact fixed48 core, filled original outlines and all eight allowed original bracket orientations on the complete physical first sheet. No claim for moving the core or changing the allocation.','exact_envelope_mm':list(map(str,combined)),'envelope_mm':list(map(float,combined)),'exact_envelope_area_mm2':str(area),'envelope_area_mm2':float(area),'bracket_original_filled_area_mm2':40000,'conservative_bracket_area_lower_bound_mm2':39999,'rounding_allowance_mm':1e-6,'operation_error_bound_mm':float(rounding_bound),'area_error_bound_mm2':float(error),'maximum_brackets':capacity,'required_brackets':6,'fixed48_core_cannot_extend_to_full66':True,'whole_allocations_excluded':0,'earlier_arrangements_excluded':0})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source_rectangles_verified':len(sources),'cog_convex_pieces_verified':len(canonical['cog']),'legal_bracket_modes_verified':8,'continuous_classes_verified':total,'retained_classes_verified':retained_count,'cover_boxes_verified':sum(r['cover_boxes'] for r in records),'boundary_and_corner_controls_passed':True,'overlap_count_control_passed':True,'outside_source_negative_control_passed':True,'maximum_brackets':capacity,'required_brackets':6,'fixed48_core_cannot_extend_to_full66':True,'complete_preparation_seconds_if_consumed':charge,'whole_allocations_excluded':0,'earlier_arrangements_excluded':0,'optimizer_calls':0,'solver_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
