"""Bounded continuous-source relaxation trees; open leaves never exclude a case."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-deferred-conflict-tree-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';AC=ROOT/'output/h5-first57-frontier-clique-consistency-20261104'
INS=ROOT/'output/h5-first57-frontier-insert-bounds-20261106';FRONTIER=ROOT/'output/h5-first57-frontier-joint-distributions-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';HELPER=ROOT/'output/prepare_h5_local_conflict_covers_20261104.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def members(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask-=bit
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
selection=load(FRONTIER/'audit/deferred-large-distributions.json');assert len(selection)==5
for base in [BR,AC,INS,FRONTIER]:assert load(base/'audit/checks.json')['passed']
geometry=load(SOURCE/'geometry-domains.json')
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='conflict'];assert len(functions)==1
exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
inputs=[Path(__file__),HELPER,SOURCE/'geometry-domains.json',FRONTIER/'audit/deferred-large-distributions.json']+[b/n for b in [BR,AC,INS,FRONTIER] for n in ['audit/plan.json','audit/checks.json']]+[BR/f"choice-{r['choice_index']:02d}.json" for r in selection]+[AC/f"choice-{r['consistency_index']:02d}.json" for r in selection]+[INS/f"choice-{r['insert_choice_index']:02d}.json" for r in selection]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'For all five deferred choices, preserve the complete necessary bracket domains and retained insert cells. Exact source-inner conflicts define a necessary compatibility graph. Repeatedly remove bracket nodes with no support in another mandatory group and insert nodes with no support in a mandatory bracket group. A verified insert conflict-clique cover below the remaining required count closes a leaf. Otherwise branch over every node of a mandatory bracket domain. Once bracket domains are singleton, branch on including or excluding an insert node. Every child domain is determined from its parent. Eight pairwise-compatible selected insert nodes only produce an unresolved graph witness, never a source placement. Time/expansion limits produce explicit open leaves. Only an independently verified tree with all leaves closed excludes a continuous choice.',
    'per_choice_seconds':6,'maximum_expanded_nodes_per_choice':25000,'preparation_cap_seconds':35,'maximum_process_seconds':45,
    'stop_case_after_first_relaxation_witness':True,'placement_solver_calls':0,'native_calls':0,'repeat_permitted':False})
summaries=[]
for choice,row in enumerate(selection):
    case_started=time.perf_counter();deadline=min(started+34,case_started+6)
    br=load(BR/f"choice-{row['choice_index']:02d}.json");ac=load(AC/f"choice-{row['consistency_index']:02d}.json");ins=load(INS/f"choice-{row['insert_choice_index']:02d}.json")
    assert br['empty_sites']==ac['empty_sites']==ins['empty_sites']==row['empty_sites']
    offset=len(br['nodes']);nodes=br['nodes']+ins['nodes'];bg=ac['remaining_cliques']
    insert_nodes=[offset+n for n in ins['retained']];eligible=sorted({n for g in bg for n in g}|set(insert_nodes))
    universe=sum(1<<n for n in eligible);compatible={n:0 for n in eligible}
    for k,a in enumerate(eligible):
        for b in eligible[k+1:]:
            if conflict(nodes[a],nodes[b]) is None:
                compatible[a]|=1<<b;compatible[b]|=1<<a
    conflicting={n:universe&~compatible[n] for n in eligible}
    records=[];witness=None;expanded=0
    def cover(mask,need):
        vertices=list(members(mask))
        orders=[vertices,sorted(vertices,key=lambda n:((conflicting[n]&mask).bit_count(),n)),
                sorted(vertices,key=lambda n:(-(conflicting[n]&mask).bit_count(),n))]
        best=None
        for order in orders:
            groups=[]
            for v in order:
                possible=[i for i,g in enumerate(groups) if g&~conflicting[v]==0]
                if possible:
                    i=max(possible,key=lambda i:(groups[i].bit_count(),-i));groups[i]|=1<<v
                else:groups.append(1<<v)
            if best is None or len(groups)<len(best):best=groups
            if len(best)<need:break
        return [list(members(g)) for g in best]
    def visit(domains,available,chosen):
        nonlocal_placeholder=None
        global expanded,witness
        index=len(records);record={'node':index,'bracket_removals':[],'insert_removals':[]};records.append(record)
        if witness is not None:
            record.update({'kind':'open','reason':'earlier_relaxation_witness'});return index
        if time.perf_counter()>=deadline or expanded>=25000:
            record.update({'kind':'open','reason':'time_or_expansion_limit'});return index
        expanded+=1;domains=list(domains)
        while all(domains):
            changed=False
            for own in range(8):
                for node in list(members(domains[own])):
                    for other in range(8):
                        if own!=other and not domains[other]&compatible[node]:
                            record['bracket_removals'].append([node,own,other]);domains[own]&=~(1<<node);changed=True;break
                    if not domains[own]:break
                if not all(domains):break
            if not changed:break
        if not all(domains):
            record['kind']='closed_empty_bracket';return index
        for node in list(members(available)):
            for group,domain in enumerate(domains):
                if not domain&compatible[node]:
                    record['insert_removals'].append([node,group]);available&=~(1<<node);break
        need=8-len(chosen)
        if need==0:
            assert all(d.bit_count()==1 for d in domains)
            witness={'bracket_nodes':[next(members(d)) for d in domains],'insert_nodes':chosen}
            record.update({'kind':'open_graph_witness','witness':witness});return index
        groups=cover(available,need)
        if len(groups)<need:
            record.update({'kind':'closed_insert_cover','cover':groups});return index
        candidates=[i for i,d in enumerate(domains) if d.bit_count()>1]
        if candidates:
            group=min(candidates,key=lambda i:(domains[i].bit_count(),i));values=list(members(domains[group]))
            record.update({'kind':'branch_bracket','group':group,'children':[]})
            for value in values:
                child=list(domains);child[group]=1<<value
                record['children'].append({'value':value,'node':visit(child,available,list(chosen))})
        else:
            values=list(members(available));assert values
            value=max(values,key=lambda v:((conflicting[v]&available).bit_count(),-v))
            record.update({'kind':'branch_insert','value':value,'include':visit(domains,available&compatible[value],chosen+[value]),
                           'exclude':visit(domains,available&~(1<<value),list(chosen))})
        return index
    root_domains=[sum(1<<n for n in g) for g in bg];root_available=sum(1<<n for n in insert_nodes)
    root=visit(root_domains,root_available,[])
    open_nodes=[r['node'] for r in records if r['kind'] in ['open','open_graph_witness']]
    result={'source_selection':row,'empty_sites':row['empty_sites'],'original_bracket_node_count':offset,
        'root':root,'records':records,'expanded_nodes':expanded,'open_nodes':open_nodes,'relaxation_witness':witness,
        'case_seconds':time.perf_counter()-case_started,'diagnostic_excluded':not open_nodes}
    write(OUT/f'choice-{choice:02d}.json',result)
    summary={k:v for k,v in result.items() if k not in ['records','relaxation_witness','open_nodes','source_selection']}|{'records':len(records),'open_leaves':len(open_nodes),'has_relaxation_witness':witness is not None}
    summaries.append(summary);print(summary,flush=True);assert time.perf_counter()-started<35
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':summaries,'independent_tree_audit_pending':True,
    'source_valid66':False,'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
