from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_frontier_joint_distributions_20261106.py').read_text(encoding='utf-8').replace('frontier-joint-distributions','deferred-conflict-tree').replace('prepare_h5_frontier_joint_distributions','prepare_h5_deferred_conflict_tree').replace('35','45')
with (O/'run_h5_deferred_conflict_tree_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
