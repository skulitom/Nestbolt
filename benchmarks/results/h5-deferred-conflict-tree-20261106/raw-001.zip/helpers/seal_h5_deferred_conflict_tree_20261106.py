from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-deferred-conflict-tree-20261106';OUT=ROOT/'benchmarks/results'/NAME
BASE=ROOT/'output/h5-first57-deferred-conflict-tree-20261106'
PROCESS=ROOT/'output/h5-first57-deferred-conflict-tree-process-20261106'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
audit=load(BASE/'audit/checks.json')
assert audit['passed'] and audit['new_fixed29_choices_excluded']==4 and audit['remaining_fixed29_choices']==68
assert audit['tree_records_verified']==79 and audit['strict_source_inner_pair_evaluations']==17340
process=load(PROCESS/'process.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104','h5-source-polygons-and-joint-frontier-20261104','h5-mandatory-clique-exclusions-20261104','h5-full-frontier-proofs-20261106','h5-frontier-insert-exclusions-20261106']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for folder in [BASE,PROCESS]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_deferred_conflict_tree*20261106.py','*h5_deferred_tree_runner*20261106.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-deferred-conflict-tree-report-20261106.md','prepare_h5_local_conflict_covers_20261104.py']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(BASE/'audit/checks.json','tree-audit.json'),(BASE/'audit/remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(BASE/'audit/necessary-graph-witnesses.json','necessary-graph-witnesses.json')]:
    shutil.copyfile(source,OUT/name)
write(OUT/'process-ledger.json',{'complete_preparation_seconds':process['complete_process_seconds'],'processes':[process],
    'independent_audit_seconds':audit['seconds'],'placement_solver_calls':0,'native_calls':0})
write(OUT/'next-step.json',{'all_prior_placement_calls_closed':True,'current_tree_process_closed':True,
    'remaining_fixed29_choices':68,'total_fixed29_choices_excluded':387,'larger_bracket_clique_bound_choices':67,
    'necessary_graph_witness_choice':[4,9,14],
    'next_method':'Assess an optional-clique proof tree for the 67 remaining complete bracket covers with clique bound above eight. At each node bound the independent bracket count by a source-certified conflict-clique partition. Branch on one complete clique: choose each of its cells exactly once, retaining compatible cells, or skip the whole clique. This partitions every possible independent eight-bracket selection. Stop at the first necessary graph witness, retain every open branch and enforce fresh frozen time/node limits. Independently reconstruct every branch and verify every leaf before any continuous exclusion. This is a new complete-cover method for previously unprocessed cases, not a rerun of the five mandatory-clique trees or any closed placement call.',
    'survivors':'output/h5-first57-deferred-conflict-tree-20261106/audit/remaining-fixed29-choices.json',
    'bracket_geometry':'output/h5-first57-full-frontier-cliques-20261104','new_proof_prepared':False,
    'whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'new_continuous_choices_excluded':4,'remaining_fixed29_choices':68,'total_fixed29_choices_excluded':387,'original_fixed29_choices':455,
    'tree_records_verified':79,'bracket_removals_verified':3729,'insert_removals_verified':183,
    'strict_source_inner_pair_evaluations':17340,'necessary_graph_witnesses':1,'placement_solver_calls':0,'native_calls':0,
    'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-deferred-conflict-tree-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 complete deferred proof trees:** [independent integer tree replay]({link}) verifies 79 records, 3,729 bracket removals, 183 insert removals and 17,340 source-inner pair evaluations. Complete branch contradictions exclude four fixed29/cog choices: [2,5,10], [3,5,10], [5,7,10] and [5,8,10]. The frontier is now 68 (387 of 455 excluded). The fifth case [4,9,14] retains a necessary-graph witness and 13 open leaves; it is not a source placement or an exclusion. Complete preparation takes 0.467354 s, with no overrun, placement solver or native call. Next assess optional-clique proof trees on the 67 broader bracket covers; all current bounded processes stay closed. Full66 checks, 440 whole allocations and H2/H5 remain open at 60%. Main 8a765828 has four passing checks and two native checks still running at report preparation; the next normal push waits for all six and the aggregate result.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [frontier insert exclusions](../benchmarks/results/h5-frontier-insert-exclusions-20261106.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [complete deferred proof trees](../benchmarks/results/{NAME}.md).',1)
a='proofs exclude another 15, leaving 72 choices (383 of 455 excluded). Five larger\nmandatory-clique cases remain deferred for a compact proof tree; 67 have larger\nbracket-clique bounds. All prior calls stay closed.'
b='proofs exclude another 15. Complete proof trees exclude four more, leaving\n68 choices (387 of 455 excluded). Case [4,9,14] has an unresolved necessary-graph\nwitness; 67 have larger bracket-clique bounds for a new optional-clique proof.\nAll prior calls and bounded processes stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
