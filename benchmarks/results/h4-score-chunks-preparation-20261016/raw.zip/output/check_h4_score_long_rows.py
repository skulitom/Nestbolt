"""Prove the existing equivalence cases exercise more than one eight-pair chunk."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root=Path(__file__).resolve().parents[1]
out=root/'output/h4-score-granularity-probe'
score=out/'workspace/crates/core/src/separate/score.rs'
assert json.loads((out/'bounded-tests-v1.json').read_bytes())['exit_code']==0
with zipfile.ZipFile(out/'score-v1-before-coverage.zip','x',zipfile.ZIP_DEFLATED) as z:
    z.write(score,'score.rs')
    for name in ['plan.json','bounded-tests-v1.json','bounded-tests-v1.log']:
        z.write(out/name,name)
old=score.read_text(encoding='utf-8')
needle='        let mut rng = Xoshiro256PlusPlus::seed_from_u64(17);'
assert old.count(needle)==1
new=old.replace(needle,'''        let pole_counts: Vec<_> = shapes.iter().map(|s| s.surrogate().poles.len()).collect();
        eprintln!("equivalence fixture pole counts: {pole_counts:?}");
        assert!(pole_counts.iter().any(|&n| n > 8), "fixture must exercise within-row checks");
'''+needle)
assert old.split('#[cfg(test)]')[0]==new.split('#[cfg(test)]')[0]
score.write_text(new,encoding='utf-8',newline='\n')
(out/'coverage-v2-plan.json').write_text(json.dumps({'candidate_sha256':sha256(score.read_bytes()).hexdigest(),
    'production_score_bytes_unchanged_from_v1':True,'scope':__doc__},indent=2)+'\n',encoding='utf-8',newline='\n')
command=[sys.executable,str(root/'output/ccd1.py'),'cargo','test','-p','nestbolt-core','--lib','bounded',
         '--locked','--target-dir',str(root/'output/h4-score-granularity-target'),'--','--nocapture']
with (out/'bounded-tests-v2.log').open('xb') as stream:
    result=subprocess.run(command,cwd=out/'workspace',stdout=stream,stderr=subprocess.STDOUT)
(out/'bounded-tests-v2.json').write_text(json.dumps({'command':command,'exit_code':result.returncode},indent=2)+'\n',encoding='utf-8',newline='\n')
print((out/'bounded-tests-v2.log').read_text(encoding='utf-8',errors='replace')[-2500:])
raise SystemExit(result.returncode)
