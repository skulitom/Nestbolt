"""Isolate one score-loop experiment without touching the running preview."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h4-score-granularity-probe'
WORK=OUT/'workspace'
assert not WORK.exists()
names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
names=[n for n in names if n.startswith(('crates/','.cargo/')) or n in
       ['Cargo.toml','Cargo.lock','rust-toolchain.toml','LICENSE','THIRD_PARTY_NOTICES','examples/validation-job.json']]
baseline=[]
for name in names:
    source,target=ROOT/name,WORK/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    baseline.append({'path':name,'sha256':sha256(source.read_bytes()).hexdigest()})
score=WORK/'crates/core/src/separate/score.rs'
text=score.read_text(encoding='utf-8')
start=text.index('    for p in &a.surrogate().poles {')
end=text.index('    Some(finish(sum))',start)
old=text[start:end]
new='''    for p in &a.surrogate().poles {
        for chunk in b.surrogate().poles.chunks(8) {
            for q in chunk {
                let penetration = (p.radius + q.radius) - p.center.distance_to(&q.center);
                let decayed = if penetration >= epsilon {
                    penetration
                } else {
                    squared / (-penetration + 2.0 * epsilon)
                };
                sum += decayed * p.radius.min(q.radius);
            }
            // The same exact lower bound, checked before finishing a long row.
            // Pole order, final arithmetic and strict tie handling are unchanged.
            if previous + finish(sum) > bound {
                return None;
            }
        }
    }
'''
score.write_text(text[:start]+new+text[end:],encoding='utf-8',newline='\n')
(OUT/'original-score-loop.txt').write_text(old,encoding='utf-8',newline='\n')
plan={'scope':__doc__,'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    'production_baseline':'0a9fb440560bf96f5a81bd05e3f50d7df01238b3',
    'hypothesis':'Existing profiles identify pole-pair scoring cost. Checking the unchanged monotone partial score every eight pairs may avoid work within long rows. Extra checks may also cost time; no speed or quality gain is presumed.',
    'lever':'Bound-check granularity only, eight pole pairs per chunk instead of a whole row',
    'unchanged':['geometry','pole accumulation order','accepted score arithmetic','ties','infinite-bound path','work charges','budgets','defaults','dependencies'],
    'baseline_files':baseline,'candidate_file':'crates/core/src/separate/score.rs',
    'candidate_sha256':sha256(score.read_bytes()).hexdigest(),'integrated':False,
    'measured_search_started':False,'held_out_geometry_read':False,
    'preceding_result':'Chrome integrated-preview subset +1.0462165709058668%, failed +1% limit; original matrix continues.'}
(OUT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'copied_files':len(baseline),'changed_file':plan['candidate_file'],'candidate_sha256':plan['candidate_sha256']}))
