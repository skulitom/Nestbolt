"""Finish build metadata after a console-encoding error, without rerunning builds."""
from hashlib import sha256
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h4-score-granularity-probe'
WORK=OUT/'workspace'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v): p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')

assert not (OUT/'build-v3.json').exists()
write(OUT/'metadata-finalization-failure.json',{
    'scope':__doc__,'build_commands_rerun':False,'measurement_started':False,
    'original_helper':'output/build_h4_score_granularity.py',
    'failure':'After saving the successful bundle-v3 command record, printing its Unicode check mark through cp1252 raised UnicodeEncodeError in run(), line 47. The final build-v3.json was not reached.',
    'secondary_attempt':'Preparation sealer stopped at missing build-v3.json before creating its destination; the measurement prepare command did not run.',
    'retained':['build-v3-progress.json','bundle-v3.log','output/build_h4_score_granularity.py'],
    'resolution':'Validate the eight saved command records and log hashes, all original source guards, and existing build outputs; create only the missing final metadata.'})
records=json.loads((OUT/'build-v3-progress.json').read_bytes())
assert [r['label'] for r in records]==['format-v3','bounded-release-v3','clippy-v3','cli-v3','wasm-v3','bindings-v3','types-v3','bundle-v3']
for row in records:
    assert row['exit_code']==0 and digest(OUT/(row['label']+'.log'))==row['log_sha256']
plan=json.loads((OUT/'plan.json').read_bytes())
for row in plan['baseline_files']:
    assert digest(ROOT/row['path'])==row['sha256'],row['path']
    if row['path']!='crates/core/src/separate/score.rs': assert digest(WORK/row['path'])==row['sha256'],row['path']
assert (WORK/'web/dist/bench.html').is_file() and (WORK/'web/dist/index.html').is_file()
assert (WORK/'web/dist/assets').is_dir()
write(OUT/'build-v3.json',{'commands':records,'all_passed':True,'root_baseline_unchanged':True,
    'candidate_score_sha256':digest(WORK/'crates/core/src/separate/score.rs'),
    'cli_sha256':digest(OUT/'nestbolt-score-chunks8.exe'),
    'wasm_sha256':digest(WORK/'web/src/pkg/nestbolt_wasm_bg.wasm'),
    'dist':{p.relative_to(WORK/'web/dist').as_posix():digest(p) for p in sorted((WORK/'web/dist').rglob('*')) if p.is_file()},
    'performance_claim':False,'held_out_geometry_read':False,'metadata_finalization':'Recovered without any command rerun; see metadata-finalization-failure.json'})
print('Verified all eight saved stages; completed metadata without rerunning them.')
