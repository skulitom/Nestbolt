"""Check and build the isolated eight-pair bound candidate on CCD1 only."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h4-score-granularity-probe'
WORK=OUT/'workspace'
TARGET=ROOT/'output/h4-score-granularity-target'

def digest(p): return sha256(p.read_bytes()).hexdigest()
def write(p,v): p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')

assert json.loads((OUT/'bounded-tests-v2.json').read_bytes())['exit_code']==0
with zipfile.ZipFile(OUT/'score-v2-before-format.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in [WORK/'crates/core/src/separate/score.rs',OUT/'coverage-v2-plan.json',OUT/'bounded-tests-v2.json',OUT/'bounded-tests-v2.log']:
        z.write(p,p.name)

names=subprocess.check_output(['git','ls-files','-z','--','web'],cwd=ROOT).decode().split('\0')
for name in filter(None,names):
    source,target=ROOT/name,WORK/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
modules=WORK/'web/node_modules'
assert not modules.exists()
subprocess.run(['powershell','-NoProfile','-Command',
    "New-Item -ItemType Junction -Path '"+str(modules)+"' -Target '"+str(ROOT/'web/node_modules')+"' | Out-Null"],check=True)
notices=WORK/'web/public/THIRD_PARTY_NOTICES.txt'
notices.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(ROOT/'web/public/THIRD_PARTY_NOTICES.txt',notices)
records=[]
def run(label,command,cwd=WORK):
    log=OUT/(label+'.log')
    full=[sys.executable,str(ROOT/'output/ccd1.py'),*map(str,command)]
    started=datetime.now(timezone.utc).isoformat()
    with log.open('xb') as stream:
        result=subprocess.run(full,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
    record={'label':label,'command':full,'cwd':str(cwd),'exit_code':result.returncode,
            'started':started,'finished':datetime.now(timezone.utc).isoformat(),'log_sha256':digest(log)}
    records.append(record)
    write(OUT/'build-v3-progress.json',records)
    print(label,result.returncode,log.read_text(encoding='utf-8',errors='replace')[-1100:],flush=True)
    assert result.returncode==0,label

run('format-v3',['cargo','fmt','--all'])
write(OUT/'formatted-v3-plan.json',{'score_sha256':digest(WORK/'crates/core/src/separate/score.rs'),
      'root_source_untouched':True,'target':str(TARGET),'scope':__doc__})
run('bounded-release-v3',['cargo','test','--locked','--release','-p','nestbolt-core','--lib','bounded',
      '--target-dir',TARGET,'--','--nocapture'])
run('clippy-v3',['cargo','clippy','--locked','-p','nestbolt-core','--lib','--target-dir',TARGET,'--','-D','warnings'])
run('cli-v3',['cargo','build','--locked','--release','-p','nestbolt-cli','--target-dir',TARGET])
shutil.copyfile(TARGET/'release/nestbolt.exe',OUT/'nestbolt-score-chunks8.exe')
run('wasm-v3',['cargo','build','--locked','--release','-p','nestbolt-wasm','--target','wasm32-unknown-unknown','--target-dir',TARGET])
run('bindings-v3',['wasm-bindgen','--target','web','--out-dir',WORK/'web/src/pkg',TARGET/'wasm32-unknown-unknown/release/nestbolt_wasm.wasm'])
run('types-v3',['node',ROOT/'web/node_modules/typescript/bin/tsc','--noEmit'],WORK/'web')
run('bundle-v3',['node',ROOT/'web/node_modules/vite/bin/vite.js','build'],WORK/'web')
plan=json.loads((OUT/'plan.json').read_bytes())
for row in plan['baseline_files']:
    assert digest(ROOT/row['path'])==row['sha256'],row['path']
    if row['path']!='crates/core/src/separate/score.rs':
        assert digest(WORK/row['path'])==row['sha256'],row['path']
write(OUT/'build-v3.json',{'commands':records,'all_passed':True,'root_baseline_unchanged':True,
    'candidate_score_sha256':digest(WORK/'crates/core/src/separate/score.rs'),
    'cli_sha256':digest(OUT/'nestbolt-score-chunks8.exe'),
    'wasm_sha256':digest(WORK/'web/src/pkg/nestbolt_wasm_bg.wasm'),
    'dist':{p.relative_to(WORK/'web/dist').as_posix():digest(p) for p in sorted((WORK/'web/dist').rglob('*')) if p.is_file()},
    'performance_claim':False,'held_out_geometry_read':False})
print('Isolated candidate built; no performance claim.',flush=True)
