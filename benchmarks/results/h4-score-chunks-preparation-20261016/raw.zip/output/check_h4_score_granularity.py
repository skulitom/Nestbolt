"""Run existing score-bit/evaluator tests in a fresh isolated CCD1 target."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
out=root/'output/h4-score-granularity-probe'
target=root/'output/h4-score-granularity-target'
assert not target.exists(), 'Use a fresh target; keep any earlier build evidence'
command=[sys.executable,str(root/'output/ccd1.py'),'cargo','test','-p','nestbolt-core','--lib','bounded',
         '--locked','--target-dir',str(target),'--','--nocapture']
started=datetime.now(timezone.utc).isoformat()
with (out/'bounded-tests-v1.log').open('xb') as stream:
    result=subprocess.run(command,cwd=out/'workspace',stdout=stream,stderr=subprocess.STDOUT)
record={'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),
        'exit_code':result.returncode,'scope':'Functional score/evaluator equivalence only; not performance evidence'}
(out/'bounded-tests-v1.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print((out/'bounded-tests-v1.log').read_text(encoding='utf-8',errors='replace')[-5000:])
raise SystemExit(result.returncode)
