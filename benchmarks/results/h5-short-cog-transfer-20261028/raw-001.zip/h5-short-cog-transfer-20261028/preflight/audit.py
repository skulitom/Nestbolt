"""Independent original-ring samples for all declared short-transfer modes and obstacles."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,Point,shape
from shapely.affinity import translate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-cog-transfer-20261028';OUT=BASE/'preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
assert load(BASE/'prepared.json')['passed'];job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');shapes=[];required=plan['required_pair_gap_mm']
for i,m in enumerate(modes):
    c,s=math.cos(m['angle']),math.sin(m['angle']);vertices=[(-x if m['mirrored'] else x,y) for x,y in parts[m['family']]['geometry'][0]['outer']];u,v=m['source_translation_offset'];g=Polygon([(x*c-y*s+u,x*s+y*c+v) for x,y in vertices]);assert g.is_valid and g.equals_exact(shape(m['geometry']),1e-10);shapes.append(g)
assert len(modes)==46 and [m['family'] for m in modes]==['cog']*36+['bracket']*8+['insert']*2
assert [m['angle'] for m in modes[:36]]==[math.radians(d) for d in plan['cog_phases_degrees']]
assert {(m['angle'],m['mirrored']) for m in modes[36:44]}=={(q*math.pi/2,b) for q in range(4) for b in [False,True]}
pairs=load(BASE/'obstacle-pairs.json');expected={(b,c) for b in range(36,44) for c in range(36)}|{(b,i) for b in range(36,44) for i in [44,45]}|{(c,i) for c in range(36) for i in [44,45]}|{(i,j) for i in [44,45] for j in [44,45]};assert {tuple(p) for p in pairs}==expected
samples=[]
for i,j in pairs:
    obs=shape(load(BASE/'obstacles'/f'{i:02d}-{j:02d}.json'));assert obs.is_valid
    for xy in [(-500,-400),(-280,0),(-130,95),(0,0),(130,-95),(280,0),(500,400),(0,320),(0,-320)]:
        gap=shapes[i].distance(translate(shapes[j],*xy));inside=obs.covers(Point(*xy))
        if not inside:assert gap>required
        if gap<=required:assert inside
        samples.append({'modes':[i,j],'delta':xy,'source_gap_mm':gap,'inside':bool(inside)})
write(OUT/'pair-samples.json',samples)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_modes':len(modes),'direct_source_pair_samples':len(samples),'moving_pair_obstacles':len(pairs),'fixed9_source_valid':load(BASE/'fixed9-source-readback.json')['valid'],'free_region_source_samples':load(BASE/'prepared.json')['free_region_source_samples'],'source_boundary_readback_still_required_for_candidate':True,'search_opened':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
