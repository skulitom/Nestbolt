"""Prepare original-source translation regions for a different short-sheet allocation."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,mapping,box
from shapely.affinity import translate
from shapely.ops import unary_union
import diagnose_h5_concave_gaps as geom
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-short-cog-transfer-20261028';BASE=ROOT/'output/h5-oblique64-source-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'free').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();deadline=start+120
job=load(JOB);parts={p['id']:p for p in job['parts']};rows=load(BASE/'source64.json');assert load(BASE/'audit/checks.json')['passed']
fixed=[r for r in rows if r['sheet_id']=='sheet-1' and ((r['part_id']=='bracket' and r['copy_index']<6) or (r['part_id']=='insert' and r['copy_index']<3))];assert len(fixed)==9
required=.21170867250963943;guard=3000*32*2**-23;geom.EPS=.0126;stocks={'sheet-1':[6.5,6.5,1493.5,319.4269023299994]}
readback=audit(job,fixed,stocks,required,guard);assert readback['valid'];write(OUT/'fixed9-source-readback.json',readback);write(OUT/'fixed9.json',fixed)
phases=[7.]+[i*.5 for i in range(36) if i*.5!=7.]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [JOB,BASE/'source64.json',BASE/'audit/checks.json',ROOT/'output/h5-global-short-frontier-20261026/audit/checks.json',Path(geom.__file__),ROOT/'output/h5_legacy64_source_readback.py']},
 'preparation_seconds':120,'search_seconds':60,'shared_search_seconds':90,'maximum_runs':1,'retry_permitted':False,'required_pair_gap_mm':required,'stock_guard_mm':guard,'construction_extra_mm':geom.EPS,'cog_phases_degrees':phases,
 'method':'Retain the first three audited short-sheet bracket-pair/insert groups (six brackets and three inserts). Seek one original cog, one bracket and two inserts in the remaining original stock using exact source-polygon configuration obstacles with conservative mitred buffers. This changes the allocation to7 brackets,5 inserts,1 cog if successful. Cog phases are the declared36 finite angles, bracket modes are all8 permitted quarter-turn/mirror choices, and inserts have both permitted outer classes. Enumerate each bracket free-region ring vertex plus representative, then each cog free-region vertex plus representative, and then each first-insert free-region vertex plus representative; require a positive-area legal region for the second insert and validate all13 original outlines. Include the existing lower-left bracket anchor first when legal. All other initial configurations arise deterministically from these declared geometry vertices; no numerical optimizer or random restart. Cap20,000 bracket/cog pose combinations and60 seconds. Empty conservative regions or exhausted finite candidates are not source infeasibility. This is a short-sheet construction diagnostic, not a whole66 or H5 runtime run. All unplaced originals remain mandatory; no native call.'})
def original(family,a,mir,offset=(0.,0.)):
    c,s=math.cos(a),math.sin(a);m=-1 if mir else 1;tx,ty=offset
    return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[family]['geometry'][0]['outer']])
modes=[];shapes=[]
for family,angles,mirrors in [('cog',[math.radians(p) for p in phases],[False]),('bracket',[q*math.pi/2 for q in range(4)],[False,True]),('insert',[0.,math.pi/2],[False])]:
    for mir in mirrors:
        for a in angles:
            g=original(family,a,mir);c,s=math.cos(a),math.sin(a)
            off=[-139.723742*c+139.723742*s,-139.723742*s-139.723742*c] if family=='cog' else [-g.bounds[0],-g.bounds[1]]
            g=original(family,a,mir,off);shapes.append(g);modes.append({'index':len(modes),'family':family,'angle':a,'mirrored':mir,'source_translation_offset':off,'geometry':mapping(g)})
cache={};free_samples=[]
for i,g in enumerate(shapes):
    assert time.perf_counter()<deadline; b=g.bounds;legal=box(6.5+geom.EPS-b[0],6.5+geom.EPS-b[1],1493.5-geom.EPS-b[2],319.4269023299994-geom.EPS-b[3]);obstacles=[]
    for r in fixed:
        t=r['transform'];key=(r['part_id'],t['rotation_radians'],t['mirrored'],i)
        if key not in cache:cache[key]=geom.obstacle(original(r['part_id'],t['rotation_radians'],t['mirrored']),g,required)
        obstacles.append(translate(cache[key],*t['translation']))
    free=legal.difference(unary_union(obstacles));assert free.is_valid;write(OUT/'free'/f'{i:02d}.json',mapping(free))
    for p in geom.polygons(free):
        xy=list(p.representative_point().coords)[0];placed=translate(g,*xy);bound=placed.bounds;extra=min(bound[0]-6.5,bound[1]-6.5,1493.5-bound[2],319.4269023299994-bound[3]);gaps=[placed.distance(original(r['part_id'],r['transform']['rotation_radians'],r['transform']['mirrored'],r['transform']['translation'])) for r in fixed]
        assert extra>guard and min(gaps)>required;free_samples.append({'mode':i,'anchor':xy,'minimum_gap_mm':min(gaps),'minimum_stock_extra_mm':extra})
pairs=sorted({(b,c) for b in range(36,44) for c in range(36)}|{(b,i) for b in range(36,44) for i in [44,45]}|{(c,i) for c in range(36) for i in [44,45]}|{(i,j) for i in [44,45] for j in [44,45]})
for i,j in pairs:
    assert time.perf_counter()<deadline;obstacle=geom.obstacle(shapes[i],shapes[j],required);assert obstacle.is_valid;write(OUT/'obstacles'/f'{i:02d}-{j:02d}.json',mapping(obstacle))
write(OUT/'modes.json',modes);write(OUT/'free-samples.json',free_samples);write(OUT/'obstacle-pairs.json',pairs)
write(OUT/'prepared.json',{'passed':True,'seconds':time.perf_counter()-start,'source_modes':46,'fixed9_valid':True,'free_region_source_samples':len(free_samples),'moving_pair_obstacles':len(pairs),'fixed_obstacle_types':len(cache),'source_preflight_pending':True,'search_opened':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
