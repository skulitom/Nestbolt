"""Replay the declared finite construction and read each resulting12-part prefix from source."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from shapely.geometry import shape,Point
from shapely.affinity import translate
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-cog-transfer-20261028';SEARCH=BASE/'search';OUT=BASE/'result-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(SEARCH/'result.json');process=load(SEARCH/'process.json')
for n,h in load(SEARCH/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'preflight/checks.json')['passed'] and result['status']=='FINITE_CANDIDATES_EXHAUSTED' and result['closed'] and not result['source_valid_short13'] and result['search_seconds']<60 and process['seconds']<90 and process['exit_code']==0 and not process['timeout']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'method':'Replay only the closed finite geometry enumeration; independently verify complete bracket/cog candidate accounting, every one-insert prefix against original rings and every declared second-insert region being empty. Retain the first source-valid12-part prefix as a different supported allocation7bracket/4insert/1cog; this does not satisfy the attempted7/5/1 count or full66 target. No new candidate policy, phase, source, guard, solver or native call.'})
modes=load(BASE/'modes.json');free=[shape(load(BASE/'free'/f'{i:02d}.json')) for i in range(46)];obs={(i,j):shape(load(BASE/'obstacles'/f'{i:02d}-{j:02d}.json')) for i,j in load(BASE/'obstacle-pairs.json')};fixed=load(BASE/'fixed9.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');attempts=load(SEARCH/'attempts.json');stocks={'sheet-1':[6.5,6.5,1493.5,319.4269023299994]}
def polygons(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    return [p for item in getattr(g,'geoms',[]) for p in polygons(item)]
def points(g,reverse=False,preferred=None):
    coords=set()
    for p in polygons(g):
        coords.add(tuple(p.representative_point().coords)[0]);coords.update(list(p.exterior.coords)[:-1])
        for ring in p.interiors:coords.update(list(ring.coords)[:-1])
    pts=sorted(coords,key=lambda xy:(xy[0],xy[1]),reverse=reverse)
    if preferred is not None and g.covers(Point(*preferred)):pts=[tuple(preferred)]+[xy for xy in pts if xy!=tuple(preferred)]
    return pts
def placement(mi,xy,copy):
    m=modes[mi];return {'part_id':m['family'],'copy_index':copy,'sheet_id':'sheet-1','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[xy[k]+m['source_translation_offset'][k] for k in range(2)]}}
brackets=cogs=trials=queries=pair_checks=stock_checks=0;prefixes=[];first=None;min_gap=float('inf');min_stock=float('inf')
for b in [43,41,36,37,38,39,40,42]:
    for bx in points(free[b],preferred=[998.55,6.525] if b==43 else None):
        brackets+=1;insert_free={i:free[i].difference(translate(obs[b,i],*bx)) for i in [44,45]}
        for c in range(36):
            region=free[c].difference(translate(obs[b,c],*bx))
            for cx in points(region,reverse=True):
                r=attempts[cogs];assert r['bracket_mode']==b and r['cog_mode']==c and r['bracket_anchor']==list(bx) and r['cog_anchor']==list(cx);cogs+=1
                ready={i:insert_free[i].difference(translate(obs[c,i],*cx)) for i in [44,45]}
                assert all(abs(ready[i].area-r['insert_free_area_mm2'][str(i)])<1e-8 for i in [44,45])
                for i in [44,45]:
                    for ix in points(ready[i]):
                        trials+=1;rows=fixed+[placement(b,bx,6),placement(c,cx,14),placement(i,ix,3)]
                        expected=[('bracket',k) for k in range(7)]+[('insert',k) for k in range(4)]+[('cog',14)]
                        read=audit(job,rows,stocks,plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected)
                        if not read['valid']:write(OUT/f'failed-prefix-{trials}.json',read)
                        assert read['valid'];pair_checks+=read['same_sheet_pairs'];stock_checks+=read['stock_edges'];min_gap=min(min_gap,read['minimum_pair_gap_mm']);min_stock=min(min_stock,read['minimum_extra_stock_mm'])
                        prefixes.append({'attempt':cogs-1,'insert_mode':i,'insert_anchor':ix,'valid':True,'minimum_pair_gap_mm':read['minimum_pair_gap_mm'],'minimum_extra_stock_mm':read['minimum_extra_stock_mm']})
                        if first is None:first=rows;write(OUT/'source12.json',rows);write(OUT/'source12-readback.json',read)
                        for j in [44,45]:
                            queries+=1;last=ready[j].difference(translate(obs[i,j],*ix));assert not polygons(last)
assert brackets==result['bracket_poses']==47 and cogs==len(attempts)==result['bracket_cog_combinations']==115 and trials==result['first_insert_trials']==635 and queries==result['second_insert_region_queries']==1270
assert load(SEARCH/'rejected-source-candidates.json')==[]
write(OUT/'prefix-readbacks.json',prefixes)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'bracket_poses_replayed':brackets,'bracket_cog_poses_replayed':cogs,'source_valid12_part_prefixes':trials,'direct_source_pair_checks':pair_checks,'direct_stock_edge_checks':stock_checks,'minimum_prefix_pair_gap_mm':min_gap,'minimum_prefix_stock_extra_mm':min_stock,'empty_second_insert_regions_replayed':queries,'source13_witness':False,'retained_source12_counts':{'bracket':7,'insert':4,'cog':1},'all66_still_mandatory':True,'full66_witness':False,'empty_conservative_regions_are_not_infeasibility_proofs':True,'closed_search_not_restarted':True,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
