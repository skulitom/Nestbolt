"""Reconcile the audited12-part short prefix with unchanged originals on the first sheet."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-cog-transfer-20261028';OUT=BASE/'inventory';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'readback.py');start=time.perf_counter()
assert load(BASE/'result-audit/checks.json')['passed'];short=load(BASE/'result-audit/source12.json');prior=load(ROOT/'output/h5-oblique64-source-20261028/source64.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');plan=load(BASE/'plan.json')
first=[r for r in prior if r['sheet_id']=='sheet-0' and not (r['part_id']=='cog' and r['copy_index']==14)];rows=first+short
actual={(r['part_id'],r['copy_index']) for r in rows};expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};missing=sorted(expected-actual)
assert len(first)==50 and len(rows)==len(actual)==62 and missing==[('bracket',7),('bracket',10),('bracket',11),('insert',4)]
read=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.4269023299994]},plan['required_pair_gap_mm'],plan['stock_guard_mm'],actual);assert read['valid']
write(OUT/'source62.json',rows);write(OUT/'source62-readback.json',read);write(OUT/'mandatory-missing-originals.json',missing)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source62_summary':{k:v for k,v in read.items() if k not in ['pairs','stock']},'unchanged_first_sheet_originals':50,'short_sheet_counts':{'bracket':7,'insert':4,'cog':1},'all15_cogs_accounted':True,'mandatory_missing_originals':missing,'better_part_count_than_prior64_claimed':False,'full66_witness':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
