"""One finite source-anchor enumeration for7 brackets,5 inserts and1 cog on the short sheet."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-cog-transfer-20261028';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
class Budget(Exception):pass
def child():
    from shapely.geometry import shape,Point
    from shapely.affinity import translate
    from h5_legacy64_source_readback import audit
    assert load(BASE/'preflight/checks.json')['passed'];plan=load(BASE/'plan.json');modes=load(BASE/'modes.json');fixed=load(BASE/'fixed9.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');free=[shape(load(BASE/'free'/f'{i:02d}.json')) for i in range(46)];obs={(i,j):shape(load(BASE/'obstacles'/f'{i:02d}-{j:02d}.json')) for i,j in load(BASE/'obstacle-pairs.json')}
    start=time.perf_counter();deadline=start+60;attempts=[];br_poses=cog_poses=insert_trials=second_queries=0;candidate=None;status='FINITE_CANDIDATES_EXHAUSTED';failed_candidates=[]
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'search_seconds':60,'maximum_bracket_cog_combinations':20000,'random_restarts':0,'native_calls':0})
    def budget():
        if time.perf_counter()>=deadline:raise Budget()
    def polygons(g):
        if g.is_empty:return []
        if g.geom_type=='Polygon':return [g]
        return [p for v in getattr(g,'geoms',[]) for p in polygons(v)]
    def points(g,reverse=False,preferred=None):
        coords=[]
        for p in polygons(g):
            coords.append(tuple(p.representative_point().coords)[0]);coords.extend(list(p.exterior.coords)[:-1])
            for ring in p.interiors:coords.extend(list(ring.coords)[:-1])
        result=sorted(set(coords),key=lambda xy:(xy[0],xy[1]),reverse=reverse)
        if preferred is not None and g.covers(Point(*preferred)):result=[tuple(preferred)]+[p for p in result if p!=tuple(preferred)]
        return result
    def placement(mi,xy,copy):
        m=modes[mi];return {'part_id':m['family'],'copy_index':copy,'sheet_id':'sheet-1','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[xy[k]+m['source_translation_offset'][k] for k in range(2)]}}
    try:
        for b in [43,41,36,37,38,39,40,42]:
            for bx in points(free[b],preferred=[998.55,6.525] if b==43 else None):
                budget();br_poses+=1;insert_free={i:free[i].difference(translate(obs[b,i],*bx)) for i in [44,45]}
                for c in range(36):
                    budget();cgfree=free[c].difference(translate(obs[b,c],*bx))
                    if cgfree.is_empty:continue
                    for cx in points(cgfree,reverse=True):
                        budget();cog_poses+=1
                        if cog_poses>20000:status='POSE_CAP';raise Budget()
                        ready={i:insert_free[i].difference(translate(obs[c,i],*cx)) for i in [44,45]};attempts.append({'bracket_mode':b,'bracket_anchor':bx,'cog_mode':c,'cog_anchor':cx,'insert_free_area_mm2':{i:ready[i].area for i in [44,45]}})
                        for i in [44,45]:
                            for ix in points(ready[i]):
                                budget();insert_trials+=1
                                for j in [44,45]:
                                    budget();second_queries+=1;last=ready[j].difference(translate(obs[i,j],*ix));polys=polygons(last)
                                    if not polys:continue
                                    jx=tuple(max(polys,key=lambda p:p.area).representative_point().coords)[0]
                                    moving=[placement(b,bx,6),placement(c,cx,14),placement(i,ix,3),placement(j,jx,4)]
                                    rows=fixed+moving;expected=[('bracket',k) for k in range(7)]+[('insert',k) for k in range(5)]+[('cog',14)];read=audit(job,rows,{'sheet-1':[6.5,6.5,1493.5,319.4269023299994]},plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected)
                                    if read['valid']:
                                        candidate={'placements':rows,'moving':moving,'readback':read};status='SOURCE_VALID_SHORT13';break
                                    failed_candidates.append({'placements':rows,'readback':read})
                                if candidate:break
                            if candidate:break
                        if candidate:break
                    if candidate:break
                if candidate:break
            if candidate:break
    except Budget:
        if status!='POSE_CAP':status='TIME_LIMIT'
    elapsed=time.perf_counter()-start
    write(OUT/'attempts.json',attempts);write(OUT/'rejected-source-candidates.json',failed_candidates)
    if candidate:
        write(OUT/'source13.json',candidate['placements']);write(OUT/'source13-readback.json',candidate['readback']);write(OUT/'moving4.json',candidate['moving'])
    write(OUT/'result.json',{'status':status,'closed':True,'search_seconds':elapsed,'bracket_poses':br_poses,'bracket_cog_combinations':cog_poses,'first_insert_trials':insert_trials,'second_insert_region_queries':second_queries,'rejected_source_candidates':len(failed_candidates),'source_valid_short13':candidate is not None,'all66_still_mandatory':True,'full66_witness':False,'infeasibility_claimed':False,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');inputs={p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents};write(OUT/'plan.json',{'inputs':inputs,'search_seconds':60,'shared_seconds':90,'maximum_runs':1,'retry_permitted':False});start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90);(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed result; run closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
