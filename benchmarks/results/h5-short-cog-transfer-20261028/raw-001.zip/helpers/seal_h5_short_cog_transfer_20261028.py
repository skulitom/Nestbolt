"""Archive the closed short-sheet allocation diagnostic and completed prior-main CI."""
from pathlib import Path
from datetime import datetime,timezone
import json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-short-cog-transfer-20261028';BASE=ROOT/'output'/NAME;OUT=ROOT/'benchmarks/results'/NAME;PUB=BASE/'publication';OLDPUB=ROOT/'output/h5-oblique-publication-20261028';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='9851517e7b72f5b45e00e4359fac0d483fb26b19';assert not git('diff','HEAD','--name-only')
assert all(load(BASE/p)['passed'] for p in ['preflight/checks.json','result-audit/checks.json','inventory/checks.json'])
assert load(BASE/'search/result.json')['status']=='FINITE_CANDIDATES_EXHAUSTED'
prior=load(ROOT/'benchmarks/results/h5-oblique-source-construction-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={p:digest(ROOT/p) for p in prior['current_readmes']};assert readmes==prior['current_readmes']
up=[load(PUB/f'upstream-{i}.json') for i in range(4)];upstream={'sparrow_head':up[0]['sha'],'studio_head':up[1]['sha'],'sparrow_release':up[2]['tag_name'],'studio_latest_release':[r['tag_name'] for r in up[3]]};assert all(upstream[k]==prior[k] for k in upstream)
ci=load(OLDPUB/'ci-final-run.json');jobs=load(OLDPUB/'ci-final-jobs.json');assert ci['head_sha']=='f4f6f1fe473ae3c5da129c63441e6306980294b6' and ci['id']==40668367016 and ci['status']=='completed' and ci['conclusion']=='success' and len(jobs['jobs'])==6 and all(j['conclusion']=='success' for j in jobs['jobs'])
OUT.mkdir();members={};queue=[];bindings={}
for p in BASE.rglob('*'):
    if p.is_file():
        members[BASE.name+'/'+p.relative_to(BASE).as_posix()]=p
        if p.name=='plan.json':queue.append(p)
seen=set()
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;members['source-inputs/'+n]=q
        if q.name=='plan.json':queue.append(q)
for n in ['prepare_h5_short_cog_transfer.py','audit_h5_short_cog_transfer_preflight.py','run_h5_short_cog_transfer.py','audit_h5_short_cog_transfer_result.py','readback_h5_short_cog_transfer_inventory.py','diagnose_h5_concave_gaps.py','h5_legacy64_source_readback.py','pack_h5_evidence_archive.py','ccd1.py']:members['helpers/'+n]=ROOT/'output'/n
members['helpers/'+Path(__file__).name]=Path(__file__)
members['prior-main/ci-run.json']=OLDPUB/'ci-final-run.json';members['prior-main/ci-jobs.json']=OLDPUB/'ci-final-jobs.json'
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for p,n in [(BASE/'prepared.json','prepared.json'),(BASE/'preflight/checks.json','preflight-checks.json'),(BASE/'search/result.json','search-result.json'),(BASE/'search/process.json','search-process.json'),(BASE/'result-audit/checks.json','replay-checks.json'),(BASE/'result-audit/source12.json','short-source12.json'),(BASE/'inventory/checks.json','inventory-checks.json'),(BASE/'inventory/mandatory-missing-originals.json','mandatory-missing-originals.json'),(OLDPUB/'ci-final-run.json','prior-main-ci-run.json'),(OLDPUB/'ci-final-jobs.json','prior-main-ci-jobs.json')]:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'production_digest':production,'current_readmes':readmes,**upstream,'upstream_heads_and_releases_unchanged':True,'prior_main_all6_checks_pass':True,'prior_main_sha':ci['head_sha'],'prior_main_CI':ci['id'],'normal_main_push_pending':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'release_qualified':False})
write(OUT/'checks.json',{'passed':True,'source_modes_checked':46,'source_obstacle_samples':3420,'bracket_cog_poses_replayed':115,'valid_source12_prefixes':635,'source_pair_checks':41910,'stock_edge_checks':30480,'empty_second_insert_regions_replayed':1270,'source13_target_achieved':False,'source62_inventory_valid':True,'full66_witness':False,'closed_search_not_restarted':True,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
write(OUT/'next-step.json',{'action':'Main f4f6f1fe now passes all6 jobs in40668367016. Commit this evidence-only checkpoint with the already queued9851517e, then check remote main/working branch remainf4f6f1fe and no main check is live before a normal atomic fast-forward of both refs. Capture the new main CI handle and preserve it. The source64 layout remains the best count among these two latest constructions. A different short-sheet allocation7 brackets/4 inserts/1 cog is independently source-valid; it creates a whole62-part source layout with bracket copies7,10,11 and insert4 explicitly mandatory. The attempted7 brackets/5 inserts/1 cog with six brackets/three inserts fixed exhausts its declared finite geometry candidates; no unrestricted impossibility is proved and this call is closed. A useful genuinely different next investigation is the small necessary feasibility problem for7 brackets,5 inserts,1 cog with ALL13 source placements free, all8 bracket modes, both insert classes and all real cog angles, using audited source-inner geometry/support constraints. Its prior whole-short projection/area frontier still survives, so do not claim it excluded. Audit all constraints before one bounded call. A necessary assignment still requires actual-source reconstruction; a valid exclusion must cover all modes/angles and cannot be inferred from the finite construction failure. Do not rerun closed fixed-neighbor enumerations or carry old first-sheet fixed-position exclusions into new poses. Keep all66 originals, source guards, PIH off, stock/material target and H2 gate unchanged.22 reserved vectors remain unopened; no release qualifies.','completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Short-sheet cog transfer — 2026-10-28

The proposed short-sheet allocation of **seven brackets, five inserts and one
cog** was not constructed. The bounded finite enumeration is closed; its failure
does not prove the allocation impossible. It does independently validate a
different allocation with **seven brackets, four inserts and one cog**, which
can support further structural work. Neither result closes H5.

## Construction and independent readback

Nine original placements remain fixed: three bracket-pair/insert groups from
the source-valid short sheet. The remaining one bracket, one cog and two inserts
are mandatory. Preparation uses all8 allowed bracket modes,36 finite cog phases
and both insert outer classes, with380 moving-pair configuration obstacles.
Every obstacle derives from the original filled source outlines and a
conservative mitred clearance buffer. The46 free-region representative checks
pass. Independent preflight verifies all46 source modes and3,420 direct pair
samples before the construction call.

The declared search enumerates legal-region vertices and representative points:
47 bracket poses,115 bracket/cog combinations,635 first-insert poses and1,270
second-insert region checks. It exhausts those candidates in0.152079 seconds,
0.565650 shared seconds, below60/90 limits. No second-insert region with positive
area remains. There is no source13 candidate, retry, restart or native call.
This is a diagnostic construction, not a timed H5 quality run. The finite
angles, anchor selection and conservative buffer prevent any unrestricted
infeasibility claim.

The independent reader replays the entire declared enumeration. All635
12-part prefixes pass original-ring readback:41,910 source-pair checks and
30,480 stock-edge checks, with minimum gap0.2243086725mm and extra stock0.0126mm.
These exceed the unchanged required0.2117086725mm gap and0.0114440918mm stock
guard. The first source-valid prefix is retained in full; original cog copy14
moves to the short sheet without any geometry or quantity change.

Reconciliation with the unchanged50 first-sheet originals gives a valid
62-part inventory:18 frames,9 brackets,20 inserts and all15 cogs. All1,291
source pairs,248 stock edges,80 holes and8,806 hole vertices pass. Bracket
copies7/10/11 and insert4 remain explicitly mandatory. This is not a better
part count than the earlier valid64 and is not a complete66-part witness.

## Main CI and next action

The reconciled main head `f4f6f1fe` now
[passes all six jobs](https://github.com/skulitom/Nestbolt/actions/runs/40668367016),
including the formerly pending Windows checks. This allows the next normal main
push after checking the remote refs and live runs again. The queued checkpoints
change evidence and documentation only; production, READMEs and upstream
Sparrow/Studio heads and releases remain unchanged.

The next structural question is whether the13-part short allocation can fit
when all its placements are free. Its existing necessary projection/area
frontier survives. A new bounded necessary model must cover all bracket modes,
insert classes and real cog angles before any exclusion could be claimed.
An assignment would still need source reconstruction and independent validation.
H2/H5 remain open at **60% completed milestone weight**. All22 reserved H2 vectors
remain unopened, and no new release qualifies.

[Preflight]({NAME}/preflight-checks.json),
[closed search]({NAME}/search-result.json),
[independent replay]({NAME}/replay-checks.json),
[retained short12]({NAME}/short-source12.json),
[full inventory checks]({NAME}/inventory-checks.json),
[main CI]({NAME}/prior-main-ci-jobs.json),
[next step]({NAME}/next-step.json),
[complete archive]({NAME}/raw-manifest.json).
The byte-verified archive contains{archive['archive_members']} canonical files
and{archive['verified_aliases']} identical-content aliases,
totalling{archive['archive_bytes']:,} compressed bytes.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 short-sheet cog transfer, 2026-10-28:** [the evidence]({link})
tests7 brackets/5 inserts/1 cog while retaining three existing bracket-pair/insert
groups. The finite source construction exhausts47 bracket poses,115 cog-pair
poses and1,270 second-insert checks in0.152079 search/0.565650 shared seconds;
it finds no13-part witness and is closed. All635 prefixes with only one added
insert independently pass41,910 source pairs and30,480 stock edges. The retained
7-bracket/4-insert/1-cog prefix yields a valid62-part whole inventory, with three
brackets and one insert still mandatory; it does not improve the prior64 count.
No infeasibility, native pass or H5 credit is claimed. Next free all13 short
placements in a source-supported necessary model rather than repeat the fixed
construction. Mainf4f6f1fe now passes all six CI jobs, enabling the next normal
push after a fresh remote/live-run check. Production, READMEs and upstream
releases remain unchanged. H2/H5 stay open at60%;22 reserved vectors are unopened
and no release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'completion_percent':60})
