"""Exact necessary relative-position projections for the two surviving domains."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
from math import lcm, floor, ceil
from hashlib import sha256
from datetime import datetime, timezone
import json, shutil, time
ROOT=Path(__file__).resolve().parents[1]
COUNT=ROOT/'output/h5-first55-relative-bracket-filtered-20261104'
PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
OUT=ROOT/'output/h5-surviving-relative-projections-20261104'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,separators=(',',':'));f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def convex(points):
    points=sorted(set(points));sides=[]
    for seq in [points,points[::-1]]:
        side=[]
        for p in seq:
            while len(side)>1 and cross(side[-2],side[-1],p)<=0:side.pop()
            side.append(p)
        sides.append(side[:-1])
    return sides[0]+sides[1]
def clip(poly,axis,bound,lower):
    result=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ai=a[axis]>=bound if lower else a[axis]<=bound
        bi=b[axis]>=bound if lower else b[axis]<=bound
        if ai:result.append(a)
        if ai!=bi:
            t=F(bound-a[axis],b[axis]-a[axis]);result.append(tuple(a[k]+t*(b[k]-a[k]) for k in [0,1]))
    return result
def project(hull,rects):
    xmin=min(p[0] for p in hull);xmax=max(p[0] for p in hull)
    ymin=min(p[1] for p in hull);ymax=max(p[1] for p in hull)
    cuts=sorted({xmin,xmax}|{r[k] for r in rects for k in [0,2] if xmin<r[k]<xmax})
    projections=[];cells=0
    for left,right in zip(cuts,cuts[1:]):
        intervals=sorted((r[1],r[3]) for r in rects if r[0]<=left<right<=r[2]);merged=[]
        for bottom,top in intervals:
            if not merged or bottom>merged[-1][1]:merged.append([bottom,top])
            else:merged[-1][1]=max(merged[-1][1],top)
        bands=[];cursor=ymin
        for bottom,top in merged:
            if top<ymin:continue
            if bottom>ymax:break
            if bottom>=cursor:bands.append((cursor,min(bottom,ymax)))
            cursor=max(cursor,top)
        if cursor<=ymax:bands.append((cursor,ymax))
        slab=clip(clip(hull,0,left,True),0,right,False)
        for bottom,top in bands:
            if bottom>top:continue
            cell=clip(clip(slab,1,bottom,True),1,top,False)
            if cell:
                cells+=1;projections.append([min(p[k] for p in cell) for k in [0,1]]+[max(p[k] for p in cell) for k in [0,1]])
    if not projections:return None,cells
    return [floor(min(p[k] for p in projections)) for k in [0,1]]+[ceil(max(p[k] for p in projections)) for k in [2,3]],cells
# Analytic controls exercise full exclusion, two-component survival and slanted edges.
assert project([(0,0),(10,0),(10,10),(0,10)],[[-1,-1,11,11]])==(None,0)
assert project([(0,0),(10,0),(10,10),(0,10)],[[3,-1,7,11]])[0]==[0,0,10,10]
assert project([(0,5),(5,0),(10,5),(5,10)],[[-1,-1,11,4]])[0]==[0,4,10,10]
assert load(COUNT/'audit/checks.json')['passed'] and load(GEN/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
inputs=[Path(__file__),FIRST/'plan.json',PRIOR/'integer-preparation/unary-templates.json',GEN/'source-inner-rectangles.json',GEN/'audit/plan.json',GEN/'audit/checks.json']+[COUNT/n for n in ['plan.json','all-filtered-bounds.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For both remaining bracket group0 domains, form exact convex hulls of all source translation vertex differences B-A. Remove interiors of closed forbidden relative rectangles inset one integer unit from the strictly forbidden original rectangle-pair gap regions. Split at every forbidden X edge, subtract unioned Y intervals, and clip source relative hulls to every complementary closed rectangle. Their outward integer projection bounds are necessary constraints on every pair of owner coordinates. Retain unprocessed pairs with their original interval differences. A projection box is not a feasible placement. Independently verify every result by hull containment and edge/box intersection enumeration before any count proof uses it.','gap_mm':'149/1000','discovery_stop_seconds':35,'complete_preparation_target_seconds':60,'shared_process_cap_seconds':90,'packing_solver_calls':0,'native_calls':0,'analytic_controls_passed':3})
rows=load(COUNT/'all-filtered-bounds.json');uses={}
for row in rows:
    assert row['empty_sites'] in [[5,10],[10,11]]
    for gi,g in enumerate(row['groups']):
        counts=[d[gi] for d in row['remaining_distributions']]
        if g['family']!='bracket' or max(counts)<3:continue
        keys=tuple(sorted(set(tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi)))
        uses.setdefault(keys,[]).append({'empty_sites':row['empty_sites'],'group':gi,'counts':counts})
keys=sorted(set(k for ks in uses for k in ks));idx={k:i for i,k in enumerate(keys)}
domains=[{'nodes':[idx[k] for k in ks],'uses':us} for ks,us in sorted(uses.items(),key=lambda r:(len(r[0]),r[0]))]
unary={(t['geometry'],r['region']):r for t in load(PRIOR/'integer-preparation/unary-templates.json') for r in t['regions']};inner=load(GEN/'source-inner-rectangles.json');nodes=[];hulls=[];pieces=[]
for family,mode,gid,ri in keys:
    h=[tuple(map(F,p)) for p in unary[(gid,ri)]['hull_vertices']];ps=[list(map(F,r)) for r in inner[family][mode]];assert len(ps)==2
    hulls.append(h);pieces.append(ps);nodes.append({'key':[family,mode,gid,ri],'hull_vertices_mm':[[str(v) for v in p] for p in h],'contained_rectangles_mm':[[str(v) for v in r] for r in ps]})
gap=F(149,1000);assert 2*gap*gap<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2
unit=lcm(gap.denominator,*(v.denominator for h in hulls for p in h for v in p),*(v.denominator for ps in pieces for r in ps for v in r));q=int(gap*unit)
ih=[[(int(x*unit),int(y*unit)) for x,y in h] for h in hulls];ip=[[[int(v*unit) for v in r] for r in ps] for ps in pieces]
ib=[[min(p[0] for p in h),min(p[1] for p in h),max(p[0] for p in h),max(p[1] for p in h)] for h in ih]
needed=sorted({p for d in domains for p in combinations_with_replacement(d['nodes'],2)})
axis=[];projected=[];processed=0;cells=0
for a,b in needed:
    if time.perf_counter()-started>=35:break
    A,B=ib[a],ib[b];bad=None
    for ai,r in enumerate(ip[a]):
        for bi,s in enumerate(ip[b]):
            maxima=[B[2]+s[0]-A[0]-r[2],A[2]+r[0]-B[0]-s[2],B[3]+s[1]-A[1]-r[3],A[3]+r[1]-B[1]-s[3]]
            if max(maxima)<q:bad={'nodes':[a,b],'pieces':[ai,bi],'maximum_gaps_units':maxima};break
        if bad:break
    if bad:axis.append(bad)
    else:
        h=convex([(p[0]-r[0],p[1]-r[1]) for p in ih[b] for r in ih[a]])
        rects=[[r[0]-s[2]-q+1,r[1]-s[3]-q+1,r[2]-s[0]+q-1,r[3]-s[1]+q-1] for r in ip[a] for s in ip[b]]
        assert all(r[0]<r[2] and r[1]<r[3] for r in rects)
        bounds,n=project(h,rects);cells+=n
        projected.append({'nodes':[a,b],'relative_hull_units':h,'necessary_difference_bounds_units':bounds,'complement_cells':n})
    processed+=1
fallback=[]
for a,b in needed[processed:]:
    A,B=ib[a],ib[b];fallback.append({'nodes':[a,b],'necessary_difference_bounds_units':[B[0]-A[2],B[1]-A[3],B[2]-A[0],B[3]-A[1]]})
compute=time.perf_counter()-started
for name,data in [('nodes.json',nodes),('domains.json',domains),('axis-certificates.json',axis),('projections.json',projected),('fallback.json',fallback)]:write(OUT/name,data)
elapsed=time.perf_counter()-started
checks={'passed':True,'discovery_seconds':compute,'seconds_including_evidence_serialization':elapsed,'rational_unit_denominator':str(unit),'source_options':len(nodes),'source_domains':len(domains),'initial_option_pairs':len(needed),'processed_option_pairs':processed,'scan_complete':processed==len(needed),'axis_exclusions':len(axis),'relative_hull_exclusions_pending_audit':sum(p['necessary_difference_bounds_units'] is None for p in projected),'nonempty_projections':sum(p['necessary_difference_bounds_units'] is not None for p in projected),'complement_cells':cells,'unprocessed_pairs_retained':len(fallback),'independent_audit_required':True,'any_placement_proven':False,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
