"""Independently audit all relative projections by exact box/edge intersections."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
COUNT=ROOT/'output/h5-first55-relative-bracket-filtered-20261104';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
BASE=ROOT/'output/h5-surviving-relative-projections-20261104';PROCESS=ROOT/'output/h5-surviving-relative-projections-process-20261104';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,separators=(',',':'));f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json']:queue.append(z)
assert load(COUNT/'audit/checks.json')['passed'] and load(GEN/'audit/checks.json')['passed']
checks=load(BASE/'checks.json');nodes=load(BASE/'nodes.json');keys=[tuple(n['key']) for n in nodes];assert keys==sorted(set(keys));idx={k:i for i,k in enumerate(keys)};uses={}
for row in load(COUNT/'all-filtered-bounds.json'):
    for gi,g in enumerate(row['groups']):
        counts=[d[gi] for d in row['remaining_distributions']]
        if g['family']!='bracket' or max(counts)<3:continue
        ks=tuple(sorted(set(tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi)))
        uses.setdefault(ks,[]).append({'empty_sites':row['empty_sites'],'group':gi,'counts':counts})
assert set(keys)==set(k for ks in uses for k in ks)
domains=[{'nodes':[idx[k] for k in ks],'uses':us} for ks,us in sorted(uses.items(),key=lambda r:(len(r[0]),r[0]))];assert domains==load(BASE/'domains.json')
unit=int(checks['rational_unit_denominator']);gap=F(load(BASE/'plan.json')['gap_mm']);assert unit>0 and gap==F(149,1000) and 2*gap*gap<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2
assert (gap*unit).denominator==1;q=int(gap*unit)
unary={(t['geometry'],r['region']):r for t in load(PRIOR/'integer-preparation/unary-templates.json') for r in t['regions']};inner=load(GEN/'source-inner-rectangles.json');hulls=[];pieces=[];bounds=[]
for n in nodes:
    family,mode,gid,ri=n['key'];h=[list(map(F,p)) for p in unary[(gid,ri)]['hull_vertices']];ps=[list(map(F,r)) for r in inner[family][mode]]
    assert [list(map(F,p)) for p in n['hull_vertices_mm']]==h and [list(map(F,r)) for r in n['contained_rectangles_mm']]==ps and len(ps)==2
    assert all((v*unit).denominator==1 for p in h+ps for v in p)
    hs=[tuple(int(v*unit) for v in p) for p in h];hulls.append(hs);pieces.append([[int(v*unit) for v in p] for p in ps]);bounds.append([min(p[0] for p in hs),min(p[1] for p in hs),max(p[0] for p in hs),max(p[1] for p in hs)])
needed={t for d in domains for t in combinations_with_replacement(d['nodes'],2)};covered=set();excluded=set();axis=load(BASE/'axis-certificates.json');retained=[]
for cert in axis:
    a,b=cert['nodes'];ai,bi=cert['pieces'];assert (a,b) in needed and (a,b) not in covered
    A,B=bounds[a],bounds[b];r,s=pieces[a][ai],pieces[b][bi];v=[B[2]+s[0]-A[0]-r[2],A[2]+r[0]-B[0]-s[2],B[3]+s[1]-A[1]-r[3],A[3]+r[1]-B[3]-s[1]+s[3]-s[3]]
    v[3]=A[3]+r[1]-B[1]-s[3]
    assert v==cert['maximum_gaps_units'] and all(x<q for x in v);covered.add((a,b));excluded.add((a,b))
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def intersection_vertices(h,box):
    left,bottom,right,top=box;inside=lambda p:left<=p[0]<=right and bottom<=p[1]<=top
    result={p for p in h if inside(p)}
    for p in [(left,bottom),(right,bottom),(right,top),(left,top)]:
        if all(cross(a,b,p)>=0 for a,b in zip(h,h[1:]+h[:1])):result.add(p)
    for a,b in zip(h,h[1:]+h[:1]):
        for axis,cuts in [(0,[left,right]),(1,[bottom,top])]:
            if a[axis]==b[axis]:continue
            for cut in cuts:
                if min(a[axis],b[axis])<=cut<=max(a[axis],b[axis]):
                    t=F(cut-a[axis],b[axis]-a[axis]);p=tuple(a[k]+t*(b[k]-a[k]) for k in [0,1])
                    if inside(p):result.add(p)
    return result
projected=load(BASE/'projections.json');grid_cells=intersection_count=vertex_differences=tightened=relative_exclusions=0
for index,cert in enumerate(projected):
    a,b=cert['nodes'];assert (a,b) in needed and (a,b) not in covered;covered.add((a,b))
    points={(B[0]-A[0],B[1]-A[1]) for A in hulls[a] for B in hulls[b]};h=[tuple(p) for p in cert['relative_hull_units']]
    assert len(h)>=3 and len(set(h))==len(h) and all(p in points for p in h)
    for k,p in enumerate(h):assert cross(p,h[(k+1)%len(h)],h[(k+2)%len(h)])>0
    for A,B in zip(h,h[1:]+h[:1]):assert all(cross(A,B,p)>=0 for p in points)
    vertex_differences+=len(points);rects=[[A[0]-B[2]-q+1,A[1]-B[3]-q+1,A[2]-B[0]+q-1,A[3]-B[1]+q-1] for A in pieces[a] for B in pieces[b]]
    assert all(r[0]<r[2] and r[1]<r[3] for r in rects)
    limits=[min(p[k] for p in h) for k in [0,1]]+[max(p[k] for p in h) for k in [0,1]]
    xs=sorted({limits[0],limits[2]}|{r[k] for r in rects for k in [0,2] if limits[0]<r[k]<limits[2]})
    ys=sorted({limits[1],limits[3]}|{r[k] for r in rects for k in [1,3] if limits[1]<r[k]<limits[3]})
    recorded=cert['necessary_difference_bounds_units'];A,B=bounds[a],bounds[b];original=[B[0]-A[2],B[1]-A[3],B[2]-A[0],B[3]-A[1]]
    if recorded is not None:
        assert len(recorded)==4 and all(isinstance(v,int) for v in recorded)
        assert all(original[k]<=recorded[k]<=recorded[k+2]<=original[k+2] for k in [0,1])
        if recorded!=original:tightened+=1
    found=False
    for left,right in zip(xs,xs[1:]):
        for bottom,top in zip(ys,ys[1:]):
            grid_cells+=1
            if any(r[0]<=left<right<=r[2] and r[1]<=bottom<top<=r[3] for r in rects):continue
            pts=intersection_vertices(h,[left,bottom,right,top]);intersection_count+=1
            if pts:
                found=True;assert recorded is not None,('false exclusion',a,b)
                assert all(recorded[k]<=p[k]<=recorded[k+2] for p in pts for k in [0,1]),('unsafe projection',a,b)
    if recorded is None:
        assert not found;excluded.add((a,b));relative_exclusions+=1
    else:retained.append({'nodes':[a,b],'necessary_difference_bounds_units':recorded})
    if index%2000==0:
        with (OUT/'progress.json').open('w',encoding='utf-8',newline='\n') as f:json.dump({'pairs_verified':index+1,'total':len(projected),'seconds':time.perf_counter()-started},f);f.write('\n')
for cert in load(BASE/'fallback.json'):
    a,b=cert['nodes'];assert (a,b) in needed and (a,b) not in covered;covered.add((a,b));A,B=bounds[a],bounds[b]
    assert cert['necessary_difference_bounds_units']==[B[0]-A[2],B[1]-A[3],B[2]-A[0],B[3]-A[1]];retained.append(cert)
assert covered==needed and len(needed)==checks['initial_option_pairs'] and len(excluded)==checks['axis_exclusions']+checks['relative_hull_exclusions_pending_audit']
assert checks['source_options']==len(nodes) and checks['source_domains']==len(domains) and checks['processed_option_pairs']==len(axis)+len(projected)
assert checks['scan_complete']==(checks['unprocessed_pairs_retained']==0) and len(retained)==checks['nonempty_projections']+checks['unprocessed_pairs_retained']
process=load(PROCESS/'process.json');opened=load(PROCESS/'opened.json');assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['preparation_target_overrun_seconds']==process['complete_process_cap_overrun_seconds']==0
assert opened['script_sha256']==digest(ROOT/opened['script']) and opened['maximum_calls']==1 and not opened['retry_permitted']
assert process['complete_process_seconds']>=checks['seconds_including_evidence_serialization']>=checks['discovery_seconds']
retained.sort(key=lambda r:r['nodes']);assert {tuple(r['nodes']) for r in retained}==needed-excluded
write(OUT/'retained-pairs.json',[r['nodes'] for r in retained]);write(OUT/'difference-bounds.json',retained);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','nodes.json','domains.json','axis-certificates.json','projections.json','fallback.json']]+[PROCESS/n for n in ['opened.json','process.json','stdout.txt','stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'independent_method':'Rebuild source hulls and contained rectangles. Prove each recorded relative hull is convex, consists of genuine source differences, and contains every source difference. Independently partition its bounding rectangle at every forbidden X and Y edge. Discard a closed cell only when one inset strictly forbidden source rectangle covers it entirely. Otherwise enumerate all polygon/box intersection vertices using source vertices, box corners and edge intersections, rather than producer polygon clipping. Every remaining vertex must fit the recorded necessary projection; excluded pairs require all such intersections empty. Retain exact coverage of every option pair.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_options_verified':len(nodes),'source_domains_verified':len(domains),'option_pairs_verified':len(needed),'axis_exclusions_verified':len(axis),'relative_exclusions_verified':relative_exclusions,'necessary_pairs_remaining':len(retained),'tightened_difference_boxes_verified':tightened,'independent_grid_cells_verified':grid_cells,'exact_polygon_box_intersections':intersection_count,'source_vertex_differences_verified':vertex_differences,'complete_process_seconds':process['complete_process_seconds'],'any_placement_proven':False,'capacity_proof_pending':True,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
