"""Prepare a genuinely movable rigid cog packet; no solver or capacity reuse."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from copy import deepcopy
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1]
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight'
SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
OUT=ROOT/'output/h5-translated-cog-packet-preflight-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
assert load(FIRST/'audit/checks.json')['passed'] and load(SLOTS/'audit/checks.json')['passed']
spec=load(FIRST/'plan.json');job=load(JOB);parts={p['id']:p for p in job['parts']};sites=load(SLOTS/'source-cog-sites.json');inventory=load(SLOTS/'inventory.json')
levels=sorted({r['transform']['translation'][1] for r in sites});rows=[[i for i,r in enumerate(sites) if r['transform']['translation'][1]==y] for y in levels]
assert len(rows)==3 and all(len(r)==5 for r in rows)
empty=sorted(min(r,key=lambda i:(sites[i]['transform']['translation'][0],i)) for r in rows[-2:]);occupied=[i for i in range(15) if i not in empty]
cogs=[];world=[]
for site,identity in zip(occupied,inventory['required_cog13_identities']):
    row=deepcopy(sites[site]);row['copy_index']=identity[1];assert identity[0]=='cog';cogs.append(row)
    t=row['transform'];angle=t['rotation_radians'];c,s=F(math.cos(angle)),F(math.sin(angle));mirror=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    vertices=[(mirror*F(x)*c-F(y)*s+tx,mirror*F(x)*s+F(y)*c+ty) for x,y in parts['cog']['geometry'][0]['outer']]
    world.extend(vertices)
packet_box=[min(p[k] for p in world) for k in [0,1]]+[max(p[k] for p in world) for k in [0,1]]
# This fixed-core separation allows safe movement above the fixed29 bounding line.
stock=list(map(F,spec['construction_stock']));extra=F('0.025');epsilon=F('0.000001');grid=100
safe_box=[stock[0]+extra,stock[1]+extra,stock[2]-extra,stock[3]-extra]
shift=[[math.ceil((safe_box[k]-packet_box[k]+epsilon)*grid),math.floor((safe_box[k+2]-packet_box[k+2]-epsilon)*grid)] for k in [0,1]]
assert all(lo<=hi for lo,hi in shift)
original_modes=load(FIRST/'family-modes.json');modes={}
for family in ['bracket','insert']:
    modes[family]=[]
    for m in original_modes[family]:
        relative=[[F(bounds[0])-F(shift[k][1],grid),F(bounds[1])-F(shift[k][0],grid)] for k,bounds in enumerate(m['lower_left_bounds'])]
        modes[family].append({**m,'relative_lower_left_bounds_mm':[[str(x) for x in b] for b in relative]})
fixed=load(FIRST/'fixed29.json');short=load(SHORT);expected=[tuple(r) for r in inventory['full66_identities'] if tuple(r) not in set(map(tuple,inventory['moving13_orthogonal_identities']))]
assert len(expected)==53 and len(cogs)==13 and len(fixed)==29 and len(short)==11
controls=[]
for index,(sx,sy) in enumerate(product(*shift)):
    moved=deepcopy(cogs)
    for r in moved:r['transform']['translation']=[r['transform']['translation'][0]+sx/grid,r['transform']['translation'][1]+sy/grid]
    source=fixed+moved+short;check=audit(job,source,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
    write(OUT/f'corner-{index}-source53.json',source);write(OUT/f'corner-{index}-source-checks.json',check)
    assert check['valid'] and check['originals']==53 and check['same_sheet_pairs']==916 and check['cutouts']==63 and check['hole_vertices']==6732
    controls.append({'shift_grid':[sx,sy],'source':f'corner-{index}-source53.json','source_checks':f'corner-{index}-source-checks.json','minimum_source_gap_mm':check['minimum_pair_gap_mm'],'minimum_extra_stock_mm':check['minimum_extra_stock_mm']})
write(OUT/'packet-source13.json',cogs);write(OUT/'inventory.json',inventory);write(OUT/'family-modes.json',modes)
write(OUT/'translation-domain.json',{'empty_sites':empty,'occupied_sites':occupied,'selection_rule':'Remove the leftmost cog in each of the two rows farthest from the fixed frame block. Select directly from source poses; no count table is read.','source_packet_bounds_mm':[str(v) for v in packet_box],'safe_world_bounds_mm':[str(v) for v in safe_box],'shift_grid_units_per_mm':grid,'shift_bounds_grid':shift,'shift_bounds_mm':[[str(F(v,grid)) for v in b] for b in shift],'inward_rounding_reserve_mm':str(epsilon),'all_cogs_share_one_translation':True,'cog_rotations_unchanged':True,'fixed29_and_short11_unchanged':True})
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT]+[FIRST/n for n in ['plan.json','fixed29.json','family-modes.json','geometry-library.json','audit/plan.json','audit/checks.json']]+[SLOTS/n for n in ['plan.json','source-cog-sites.json','inventory.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New positive construction: move all13 original selected cogs by one shared X/Y translation while independently placing all7 brackets and6 inserts relative to the packet. Fixed29 and the source-valid short11 remain exact. Derive an inward0.01mm-grid packet translation rectangle directly from exact rational source affine transforms, construction stock and1e-6mm reserve. Expand each orthogonal mover relative-coordinate domain by the full opposite packet shift; later require its world coordinate plus packet shift to satisfy the original stock bound. Audit all source controls and all input identities before regenerating new no-fit regions over these enlarged relative domains. Previous fixed-cog source domains, capacity exclusions, grid statuses and closed calls are not transferred.','grid_units_per_mm':grid,'full_job_originals':66,'fixed_first_originals':29,'moving_cogs':13,'independent_orthogonal_movers':13,'fixed_short_originals':11,'shared_packet_translation_variables':2,'future_algorithm_seconds':60,'future_shared_seconds':90,'future_maximum_calls':1,'retry_permitted':False,'source_valid66_required_before_native':True,'new_model_created':False,'search_opened':False})
checks={'passed':True,'seconds_including_source_controls':time.perf_counter()-started,'selected_empty_sites':empty,'shift_bounds_grid':shift,'partial53_controls_verified':len(controls),'original_pairs_checked':sum(load(OUT/c['source_checks'])['same_sheet_pairs'] for c in controls),'source_controls':controls,'source_mode_options':80,'changed_relative_domains':12,'count_capacity_tables_used':False,'independent_audit_required':True,'new_source_regions_required':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',checks);print({k:v for k,v in checks.items() if k!='source_controls'})
