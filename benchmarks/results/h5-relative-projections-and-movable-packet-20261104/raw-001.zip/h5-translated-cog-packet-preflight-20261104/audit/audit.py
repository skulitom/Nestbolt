"""Audit a movable packet over the whole translation rectangle and all controls."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
from copy import deepcopy
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-translated-cog-packet-preflight-20261104';PROCESS=ROOT/'output/h5-translated-cog-packet-preflight-process-20261104';OUT=BASE/'audit'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json']:queue.append(z)
assert load(FIRST/'audit/checks.json')['passed'] and load(SLOTS/'audit/checks.json')['passed']
spec=load(FIRST/'plan.json');job=load(JOB);parts={p['id']:p for p in job['parts']};domain=load(BASE/'translation-domain.json');inventory=load(BASE/'inventory.json');assert inventory==load(SLOTS/'inventory.json')
sites=load(SLOTS/'source-cog-sites.json');levels=sorted(set(r['transform']['translation'][1] for r in sites));rows=[[i for i,r in enumerate(sites) if r['transform']['translation'][1]==y] for y in levels]
empty=sorted(sorted(row,key=lambda i:(sites[i]['transform']['translation'][0],i))[0] for row in rows[-2:]);assert domain['empty_sites']==empty==[5,10]
occupied=[i for i in range(15) if i not in empty];assert domain['occupied_sites']==occupied
cogs=load(BASE/'packet-source13.json');assert len(cogs)==13
for row,slot,identity in zip(cogs,occupied,inventory['required_cog13_identities']):
    expected=deepcopy(sites[slot]);expected['copy_index']=identity[1];assert row==expected and identity[0]=='cog'
def exact_vertices(row):
    t=row['transform'];cosine=F(math.cos(t['rotation_radians']));sine=F(math.sin(t['rotation_radians']));tx,ty=map(F,t['translation']);sign=-1 if t['mirrored'] else 1
    return [(tx+F(x)*sign*cosine-F(y)*sine,ty+F(x)*sign*sine+F(y)*cosine) for x,y in parts[row['part_id']]['geometry'][0]['outer']]
vertices=[p for r in cogs for p in exact_vertices(r)];box=[min(p[k] for p in vertices) for k in [0,1]]+[max(p[k] for p in vertices) for k in [0,1]]
assert list(map(F,domain['source_packet_bounds_mm']))==box
stock=list(map(F,spec['construction_stock']));extra=F('0.025');safe=[stock[0]+extra,stock[1]+extra,stock[2]-extra,stock[3]-extra];assert list(map(F,domain['safe_world_bounds_mm']))==safe
grid=domain['shift_grid_units_per_mm'];assert grid==100;shift=domain['shift_bounds_grid'];epsilon=F(domain['inward_rounding_reserve_mm']);assert epsilon==F(1,1000000)
for k,(lo,hi) in enumerate(shift):
    assert lo<=hi and F(lo,grid)>=safe[k]-box[k]+epsilon>F(lo-1,grid)
    assert F(hi,grid)<=safe[k+2]-box[k+2]-epsilon<F(hi+1,grid)
    assert [F(v,grid) for v in [lo,hi]]==list(map(F,domain['shift_bounds_mm'][k]))
fixed=load(FIRST/'fixed29.json');short=load(SHORT);fixed_top=max(p[1] for r in fixed for p in exact_vertices(r))
continuous_vertical_clearance=box[1]+F(shift[1][0],grid)-fixed_top
assert continuous_vertical_clearance>F(spec['required_pair_gap_mm'])
assert min(safe[0]-F(spec['source_stocks']['sheet-0'][0]),safe[1]-F(spec['source_stocks']['sheet-0'][1]),F(spec['source_stocks']['sheet-0'][2])-safe[2],F(spec['source_stocks']['sheet-0'][3])-safe[3])>F(spec['stock_guard_mm'])
# Rigid translation leaves every cog/cog difference unchanged; fixed cores lie below the separating line.
base_modes=load(FIRST/'family-modes.json');modes=load(BASE/'family-modes.json');assert set(modes)=={'bracket','insert'};mode_checks=0
for family,opts in modes.items():
    assert len(opts)==len(base_modes[family])
    for m,original in zip(opts,base_modes[family]):
        assert {k:v for k,v in m.items() if k!='relative_lower_left_bounds_mm'}==original
        for axis,(lo,hi) in enumerate(m['relative_lower_left_bounds_mm']):
            assert F(lo)==F(original['lower_left_bounds'][axis][0])-F(shift[axis][1],grid)
            assert F(hi)==F(original['lower_left_bounds'][axis][1])-F(shift[axis][0],grid)
        mode_checks+=1
full={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};missing=set(map(tuple,inventory['moving13_orthogonal_identities']));expected=full-missing
assert len(full)==66 and len(missing)==13 and len(expected)==53 and full==set(map(tuple,inventory['full66_identities']))
pair_count=edges=holes=hole_vertices=0;minimum_gap=float('inf');minimum_stock=float('inf')
for ci,(sx,sy) in enumerate(product(*shift)):
    source=load(BASE/f'corner-{ci}-source53.json');previous=load(BASE/f'corner-{ci}-source-checks.json');moved=deepcopy(cogs)
    for r in moved:
        r['transform']['translation'][0]+=sx/grid;r['transform']['translation'][1]+=sy/grid
    assert source==fixed+moved+short and {(r['part_id'],r['copy_index']) for r in source}==expected and len(source)==53
    shapes=[];local_holes=local_vertices=0;local_min_stock=float('inf')
    for row in source:
        t=row['transform'];part=parts[row['part_id']];assert not t['mirrored'] or part['allow_mirror'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);sign=-1 if t['mirrored'] else 1
        assert part['rotations']['kind']=='free' or any(abs(math.remainder(a-math.radians(v),math.tau))<1e-12 for v in part['rotations']['degrees'])
        def ring(poly):return [(sign*x*c-y*s+t['translation'][0],sign*x*s+y*c+t['translation'][1]) for x,y in poly]
        g=part['geometry'][0];outer=Polygon(ring(g['outer']));full_shape=Polygon(ring(g['outer']),[ring(h) for h in g.get('holes',[])])
        assert outer.is_valid and full_shape.is_valid and abs(full_shape.area-Polygon(g['outer'],g.get('holes',[])).area)<1e-6
        b=outer.bounds;st=spec['source_stocks'][row['sheet_id']];margins=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(margins)>spec['stock_guard_mm'];local_min_stock=min(local_min_stock,*margins);edges+=4
        local_holes+=len(g.get('holes',[]));local_vertices+=sum(len(h) for h in g.get('holes',[]));shapes.append((row['sheet_id'],outer))
    local_pairs=0;local_min_gap=float('inf')
    for (sa,a),(sb,b) in combinations(shapes,2):
        if sa!=sb:continue
        distance=a.distance(b);assert a.disjoint(b) and distance>spec['required_pair_gap_mm'];local_pairs+=1;local_min_gap=min(local_min_gap,distance)
    assert previous['valid'] and previous['same_sheet_pairs']==local_pairs==916 and previous['cutouts']==local_holes==63 and previous['hole_vertices']==local_vertices==6732
    assert abs(previous['minimum_pair_gap_mm']-local_min_gap)<1e-12 and abs(previous['minimum_extra_stock_mm']-local_min_stock)<1e-12
    pair_count+=local_pairs;holes+=local_holes;hole_vertices+=local_vertices;minimum_gap=min(minimum_gap,local_min_gap);minimum_stock=min(minimum_stock,local_min_stock)
process=load(PROCESS/'process.json');opened=load(PROCESS/'opened.json');checks=load(BASE/'checks.json')
assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['preparation_target_overrun_seconds']==process['complete_process_cap_overrun_seconds']==0
assert process['complete_process_seconds']>=checks['seconds_including_source_controls'] and opened['script_sha256']==digest(ROOT/opened['script']) and opened['maximum_calls']==1 and not opened['retry_permitted']
inputs=[Path(__file__)]+[p for p in BASE.glob('*.json')]+[PROCESS/n for n in ['opened.json','process.json','stdout.txt','stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'independent_method':'Rebuild all original affine vertices with exact rational arithmetic; derive packet extrema, verify inward grid rounding against both nearest excluded grid points, and prove continuous stock containment and fixed-core vertical separation across the entire shift rectangle. Source identity/mode equality and a common translation preserve all internal cog geometry. Independently rebuild filled polygons and holes for all four corner controls and check every pair, stock edge and original identity. Verify the expanded orthogonal relative domains contain every world-bound placement under every permitted packet shift. New source-relative no-fit regions and world-coordinate model constraints remain mandatory.'})
write(OUT/'source-bindings.json',bindings)
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'partial53_controls_verified':4,'original_pairs_verified':pair_count,'stock_edges_verified':edges,'holes_verified':holes,'hole_vertices_verified':hole_vertices,'minimum_source_gap_mm':minimum_gap,'minimum_extra_stock_mm':minimum_stock,'shift_bounds_grid':shift,'full_continuous_translation_rectangle_verified':True,'continuous_fixed_core_vertical_clearance_mm':float(continuous_vertical_clearance),'source_modes_verified':mode_checks,'full66_identity_partition_verified':True,'complete_preparation_process_seconds':process['complete_process_seconds'],'previous_fixed_cog_exclusions_transferred':False,'source_valid66':False,'new_source_regions_required':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
