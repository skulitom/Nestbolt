"""Independently audit source bounds, exact Floyd proofs and complete count coverage."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,combinations_with_replacement
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];COUNT=ROOT/'output/h5-first55-relative-bracket-filtered-20261104';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';BASE=ROOT/'output/h5-colored-bracket-count-domains-20261104';PROCESS=ROOT/'output/h5-colored-bracket-count-process-20261104';OUT=BASE/'audit'
PAIR=ROOT/'output/h5-surviving-relative-projections-20261104';PAIR_PROCESS=ROOT/'output/h5-surviving-relative-projections-process-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json']:queue.append(z)
assert load(COUNT/'audit/checks.json')['passed'] and load(GEN/'audit/checks.json')['passed']
nodes=load(BASE/'nodes.json');domains=load(BASE/'domains.json');checks=load(BASE/'checks.json');rows=load(COUNT/'all-filtered-bounds.json')
unary={(t['geometry'],r['region']):r for t in load(PRIOR/'integer-preparation/unary-templates.json') for r in t['regions']};inner=load(GEN/'source-inner-rectangles.json')
keys=[tuple(n['key']) for n in nodes];assert keys==sorted(set(keys));key_index={k:i for i,k in enumerate(keys)};bounds=[];pieces=[]
unit=int(checks['rational_unit_denominator']);assert unit>0;gap=F(load(BASE/'plan.json')['gap_mm']);assert gap==F(149,1000) and 2*gap*gap<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2;q=gap*unit;assert q.denominator==1;q=int(q)
for n in nodes:
    family,mode,gid,ri=n['key'];assert family=='bracket'
    hull=[list(map(F,p)) for p in unary[(gid,ri)]['hull_vertices']];b=[min(p[0] for p in hull),min(p[1] for p in hull),max(p[0] for p in hull),max(p[1] for p in hull)];ps=[list(map(F,r)) for r in inner[family][mode]]
    assert list(map(F,n['translation_bounds_mm']))==b and [list(map(F,r)) for r in n['contained_rectangles_mm']]==ps and len(ps)==2
    assert all((v*unit).denominator==1 for v in b) and all((v*unit).denominator==1 for r in ps for v in r)
    bounds.append([int(v*unit) for v in b]);pieces.append([[int(v*unit) for v in r] for r in ps])
uses={}
for row in rows:
    for gi,g in enumerate(row['groups']):
        counts=[d[gi] for d in row['remaining_distributions']]
        if g['family']!='bracket' or max(counts)<3:continue
        source_keys=tuple(sorted(set(tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi)))
        if 42<=len(source_keys)<=200:uses.setdefault(source_keys,[]).append({'empty_sites':row['empty_sites'],'group':gi,'counts':counts})
assert len(uses)==len(domains);used=set()
for d,(ks,us) in zip(domains,sorted(uses.items(),key=lambda r:(len(r[0]),r[0]))):
    assert d['nodes']==[key_index[k] for k in ks] and d['uses']==us and d['targets']==sorted(set(c for u in us for c in u['counts'] if c>=3));used.update(d['nodes'])
assert used==set(range(len(nodes)))
needed={t for d in domains for t in combinations_with_replacement(d['nodes'],2)};bad=set()
for cert in load(BASE/'pair-certificates.json'):
    a,b=cert['nodes'];ai,bi=cert['pieces'];assert (a,b) in needed and (a,b) not in bad
    A,B=bounds[a],bounds[b];r,s=pieces[a][ai],pieces[b][bi];maxima=[B[2]+s[0]-A[0]-r[2],A[2]+r[0]-B[0]-s[2],B[3]+s[1]-A[1]-r[3],A[3]+r[1]-B[1]-s[3]]
    assert maxima==cert['maximum_gaps_units'] and all(v<q for v in maxima);bad.add((a,b))
assert load(PAIR/'audit/checks.json')['passed'] and [n['key'] for n in nodes]==[n['key'] for n in load(PAIR/'nodes.json')]
extra_bad={tuple(r['nodes']) for r in load(PAIR/'projections.json') if r['necessary_difference_bounds_units'] is None};assert not extra_bad&bad and extra_bad<=needed
assert checks['relative_pair_exclusions_used']==len(extra_bad);bad.update(extra_bad)
compatible=needed-bad;assert sorted(compatible)==[tuple(t) for t in load(BASE/'compatible-pairs.json')]==[tuple(t) for t in load(PAIR/'audit/retained-pairs.json')]
difference_bounds={tuple(r['nodes']):r['necessary_difference_bounds_units'] for r in load(PAIR/'audit/difference-bounds.json')};assert set(difference_bounds)==compatible
assert checks['coupled_difference_projections_used']==len(difference_bounds) and unit==int(load(PAIR/'checks.json')['rational_unit_denominator'])

def close_sparse(matrix):
    d=[r[:] for r in matrix]
    for k in range(len(d)):
        for i in range(len(d)):
            for j in range(len(d)):
                if d[i][k] is not None and d[k][j] is not None:
                    v=d[i][k]+d[k][j]
                    if d[i][j] is None or v<d[i][j]:d[i][j]=v
    assert all(v is not None for r in d for v in r);return d
def close_dense(matrix):
    d=[r[:] for r in matrix];size=len(d)
    for k in range(size):
        dk=d[k]
        for i in range(size):
            row=d[i];ik=row[k]
            for j in range(size):
                v=ik+dk[j]
                if v<row[j]:row[j]=v
    return d
trees=leaves=splits=branches=0
def verify(proof,matrices,clauses):
    global trees,leaves,splits,branches
    trees+=1
    if 'negative_cycle_axis' in proof:
        assert set(proof)=={'negative_cycle_axis','index'} and proof['negative_cycle_axis'] in [0,1]
        matrix=matrices[proof['negative_cycle_axis']];i=proof['index'];assert 0<=i<len(matrix) and matrix[i][i]<0
        leaves+=1;return
    if 'contradiction_clause' in proof:
        assert set(proof)=={'contradiction_clause'}
        for axis,a,b,c in clauses[proof['contradiction_clause']]:assert matrices[axis][b][a]+c<0
        leaves+=1;return
    assert set(proof)=={'split_clause','children'};clause=clauses[proof['split_clause']]
    possible=[di for di,(axis,a,b,c) in enumerate(clause) if matrices[axis][b][a]+c>=0]
    assert possible and possible==[r['direction'] for r in proof['children']];splits+=1
    for child in proof['children']:
        assert set(child)=={'direction','proof'};axis,a,b,c=clause[child['direction']];proposed=[r[:] for r in matrices[axis]];proposed[a][b]=min(proposed[a][b],c);closed=close_dense(proposed);assert all(closed[i][i]>=0 for i in range(len(closed)))
        updated=matrices[:];updated[axis]=closed;branches+=1;verify(child['proof'],updated,clauses)
certs=load(BASE/'prefix-certificates.json');excluded=set()
for index,cert in enumerate(certs):
    whole=tuple(cert['nodes']);assert whole==tuple(sorted(whole)) and 2<=len(whole)<=7 and whole not in excluded;size=len(whole)+1;origin=size-1;matrices=[]
    for axis in [0,1]:
        d=[[0 if i==j else None for j in range(size)] for i in range(size)]
        for i,n in enumerate(whole):d[i][origin]=bounds[n][axis+2];d[origin][i]=-bounds[n][axis]
        for a in range(len(whole)):
            for b in range(a+1,len(whole)):
                box=difference_bounds[(whole[a],whole[b])]
                d[b][a]=box[axis+2];d[a][b]=-box[axis]
        matrices.append(close_sparse(d))
    ps=[(o,r) for o,n in enumerate(whole) for r in pieces[n]];clauses=[]
    for k,(a,A) in enumerate(ps):
        for b,B in ps[k+1:]:
            if a!=b:clauses.append([(0,a,b,B[0]-A[2]-q),(0,b,a,A[0]-B[2]-q),(1,a,b,B[1]-A[3]-q),(1,b,a,A[1]-B[3]-q)])
    assert len(clauses)==2*len(whole)*(len(whole)-1);verify(cert['proof'],matrices,clauses);excluded.add(whole)
    if index%10000==0:
        with (OUT/'progress.json').open('w',encoding='utf-8',newline='\n') as f:json.dump({'certificates_verified':index+1,'total':len(certs),'seconds':time.perf_counter()-started},f);f.write('\n')
coverage_nodes=color_covers=0
capacities=load(BASE/'multiplicity-bounds.json');graph=load(BASE/'graph-nodes.json');expected_graph=[];max_target=max(t for d in domains for t in d['targets'])
assert len(capacities)==len(nodes)
for ni,(b,ps,cert) in enumerate(zip(bounds,pieces,capacities)):
    bins=[]
    for r in ps:
        xsize=r[2]-r[0]+q;ysize=r[3]-r[1]+q;assert xsize>0 and ysize>0
        nx=(b[2]-b[0])//xsize+1;ny=(b[3]-b[1])//ysize+1
        assert (nx-1)*xsize<=b[2]-b[0]<nx*xsize and (ny-1)*ysize<=b[3]-b[1]<ny*ysize
        bins.append(nx*ny)
    cap=min(max_target,min(bins)) if (ni,ni) in compatible else 1
    assert cert=={'node':ni,'rectangle_bin_counts':bins,'maximum_relevant_copies':cap}
    expected_graph.extend({'node':ni,'copy':k} for k in range(cap))
assert graph==expected_graph and len(graph)==checks['graph_vertices']
def adjacent(a,b):return a!=b and tuple(sorted((graph[a]['node'],graph[b]['node']))) in compatible
def cover(prefix,choices,target,proof):
    global coverage_nodes,color_covers
    coverage_nodes+=1;whole=tuple(sorted(graph[v]['node'] for v in prefix))
    if 'geometric_prefix' in proof:
        assert set(proof)=={'geometric_prefix'} and tuple(proof['geometric_prefix'])==whole and whole in excluded;return
    assert set(proof)=={'branches','terminal_colors'} and len(prefix)<target
    remaining=set(choices)
    for child in proof['branches']:
        assert set(child)=={'vertex','proof'};v=child['vertex'];assert v in remaining
        cover(prefix+(v,),{u for u in remaining if adjacent(u,v)},target,child['proof']);remaining.remove(v)
    colors=proof['terminal_colors'];flat=[v for c in colors for v in c]
    assert len(flat)==len(set(flat)) and set(flat)==remaining and all(c for c in colors)
    for c in colors:assert all(not adjacent(a,b) for a,b in combinations(c,2))
    assert len(prefix)+len(colors)<target;color_covers+=1
proved=[];witnesses=0
for di,d in enumerate(domains):
    assert [r['target'] for r in d['results']]==d['targets'][:len(d['results'])]
    for r in d['results']:
        assert r['status'] in ['excluded','relaxed','unknown']
        if r['status']=='excluded':
            cover((),{i for i,n in enumerate(graph) if n['node'] in d['nodes']},r['target'],r['graph_cover']);assert r is d['results'][-1] and d['maximum_brackets_proven_pending_audit']==r['target']-1
            proved.append({'domain':di,'nodes':d['nodes'],'uses':d['uses'],'maximum_brackets':r['target']-1})
        elif r['status']=='relaxed':
            w=r['necessary_interval_witness'];whole=w['nodes'];xy=w['positions_units'];assert len(whole)==len(xy)==r['target'] and whole==sorted(whole) and all(n in d['nodes'] for n in whole)
            for n,p in zip(whole,xy):assert all(bounds[n][k]<=p[k]<=bounds[n][k+2] for k in [0,1])
            for a in range(len(whole)):
                for b in range(a+1,len(whole)):
                    box=difference_bounds[(whole[a],whole[b])]
                    assert all(box[k]<=xy[b][k]-xy[a][k]<=box[k+2] for k in [0,1])
            placed=[(o,[v+xy[o][k%2] for k,v in enumerate(rect)]) for o,n in enumerate(whole) for rect in pieces[n]]
            for k,(a,A) in enumerate(placed):
                for b,B in placed[k+1:]:
                    if a!=b:assert max(B[0]-A[2],A[0]-B[2],B[1]-A[3],A[1]-B[3])>=q
            witnesses+=1
    assert ('maximum_brackets_proven_pending_audit' in d)==any(r['status']=='excluded' for r in d['results'])
process=load(PROCESS/'process.json');opened=load(PROCESS/'opened.json');assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['complete_process_cap_overrun_seconds']==0
assert opened['relative_pair_preparation_seconds_charged']==checks['relative_pair_preparation_seconds_charged']==load(PAIR_PROCESS/'process.json')['complete_process_seconds']
assert opened['script_sha256']==digest(ROOT/opened['script']) and opened['maximum_calls']==1 and not opened['retry_permitted']
assert checks['seconds_including_evidence_serialization']>=checks['discovery_seconds'] and process['complete_process_seconds']>=checks['seconds_including_evidence_serialization']
assert process['preparation_target_overrun_seconds']==max(0,process['complete_process_seconds']-60)
write(OUT/'capacity-bounds.json',proved);write(OUT/'source-bindings.json',bindings)
inputs=[PAIR/n for n in ['plan.json','checks.json','nodes.json','projections.json','audit/plan.json','audit/checks.json','audit/retained-pairs.json','audit/difference-bounds.json']]+[PAIR_PROCESS/'process.json']+[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','nodes.json','domains.json','pair-certificates.json','compatible-pairs.json','prefix-certificates.json','multiplicity-bounds.json','graph-nodes.json']]+[PROCESS/n for n in ['opened.json','process.json','stdout.txt','stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'independent_method':'Reconstruct every source hull interval and rectangle; bind all necessary relative-difference projections to their independent source audit; add them to sparse original coordinate bounds, compute full Floyd closure, and check every initial negative-cycle certificate; bind every strengthened pair exclusion to the independent relative-hull cover audit; verify exact rational integer scaling and each pair exclusion, audit complete disjunction trees using full Floyd-Warshall closure rather than incremental producer closure, and independently check all graph branches and terminal proper colorings. Reconstruct the original anchor bin multiplicity bounds and expanded graph. Every possible original multiset induces a clique; each terminal proper coloring limits its extension size. A complete count cover must either contain a verified geometric prefix exclusion or a proper coloring with too few colors to reach the demanded multiplicity. Check include and exclude coverage without trusting producer adjacency lists or coloring order. Preserve the measured full-process preparation overrun.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_nodes_verified':len(nodes),'source_domains_verified':len(domains),'pair_exclusions_verified':len(bad),'complete_prefix_trees_verified':len(excluded),'tree_nodes_verified':trees,'contradiction_leaves_verified':leaves,'complete_split_nodes_verified':splits,'rational_closed_branches_verified':branches,'complete_count_coverage_prefixes_verified':coverage_nodes,'capacity_bounds_verified':len(proved),'relaxed_interval_witnesses_verified':witnesses,'complete_process_seconds':process['complete_process_seconds'],'preparation_target_overrun_seconds':process['preparation_target_overrun_seconds'],'shared_process_cap_overrun_seconds':0,'sixty_second_preparation_pass':process['preparation_target_overrun_seconds']==0,'certified_subset_subsumption_verified':False,'multiplicity_bins_verified':len(capacities),'graph_vertices_verified':len(graph),'proper_coloring_covers_verified':color_covers,'coupled_difference_boxes_verified':len(difference_bounds),'relative_pair_exclusions_verified':len(extra_bad),'relative_pair_preparation_seconds_charged':opened['relative_pair_preparation_seconds_charged'],'any_placement_proven':False,'count_distribution_application_pending':True,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
