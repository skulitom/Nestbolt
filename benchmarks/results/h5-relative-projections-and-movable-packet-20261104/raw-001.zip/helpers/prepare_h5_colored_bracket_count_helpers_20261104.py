"""Fresh finite graph-color count proof, with independently checkable covers."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
old='h5-projected-bracket-count-domains-20261104';new='h5-colored-bracket-count-domains-20261104'
pold='h5-projected-bracket-count-process-20261104';pnew='h5-colored-bracket-count-process-20261104'
s=(ROOT/'output/bound_h5_projected_bracket_counts_20261104.py').read_text(encoding='utf-8').replace(old,new)
s=s.replace('Reconstruct both remaining source bracket domains directly.', 'Fresh graph-color proof for both remaining source bracket domains. Bound each source option multiplicity by partitioning its anchor bounding rectangle into half-open bins whose widths/heights equal a contained rectangle size plus the necessary directional gap. At most one identical-mode part fits each bin. Expand each option into that many graph vertices, capped by the largest target. Any original placement induces a graph clique. A proper coloring of a remaining candidate subgraph upper-bounds the number of additional parts. Branch include/exclude with complete coloring coverage certificates, and use necessary projected coordinate disjunction proofs only for included prefixes. Import no previous count-search certificates.')
start=s.index('def search(prefix,choices,target):');end=s.index('compute=time.perf_counter()-started',start)
s=s[:start]+'''capacities=[];graph_nodes=[];max_target=max(t for d in domains for t in d['targets'])
for ni,(b,ps) in enumerate(zip(ib,ip)):
    bin_counts=[]
    for r in ps:
        w=r[2]-r[0]+q;h=r[3]-r[1]+q;assert w>0 and h>0
        bin_counts.append(((b[2]-b[0])//w+1)*((b[3]-b[1])//h+1))
    cap=min(max_target,min(bin_counts)) if (ni,ni) in compatible else 1
    capacities.append({'node':ni,'rectangle_bin_counts':bin_counts,'maximum_relevant_copies':cap})
    graph_nodes.extend({'node':ni,'copy':k} for k in range(cap))
adj=[set() for _ in graph_nodes]
for a in range(len(graph_nodes)):
    for b in range(a+1,len(graph_nodes)):
        x,y=graph_nodes[a]['node'],graph_nodes[b]['node']
        if tuple(sorted((x,y))) in compatible:adj[a].add(b);adj[b].add(a)
color_calls=color_prunes=0
def coloring(vertices):
    global color_calls
    color_calls+=1;classes=[]
    for v in sorted(vertices,key=lambda v:(-len(adj[v]&vertices),v)):
        for c in classes:
            if not adj[v].intersection(c):c.append(v);break
        else:classes.append([v])
    return classes
def search(prefix,choices,target):
    global prefix_calls,timed_out,color_prunes
    prefix_calls+=1
    if time.perf_counter()-started>=40:timed_out=True;return 'unknown',None
    whole=tuple(sorted(graph_nodes[v]['node'] for v in prefix))
    if len(whole)>=2:
        if whole in negative:return 'excluded',{'geometric_prefix':list(whole)}
        if whole not in positive:
            status,evidence=disjunction(*matrices_and_clauses(whole))
            if status=='excluded':negative[whole]=evidence;return status,{'geometric_prefix':list(whole)}
            if status=='unknown':return status,None
            positive[whole]=evidence
        if len(whole)==target:return 'relaxed',{'nodes':list(whole),'positions_units':positive[whole]}
    branches=[];remaining=set(choices)
    while True:
        if time.perf_counter()-started>=40:timed_out=True;return 'unknown',{'completed_branches':branches}
        colors=coloring(remaining)
        if len(prefix)+len(colors)<target:
            color_prunes+=1;return 'excluded',{'branches':branches,'terminal_colors':colors}
        v=colors[-1][-1]
        status,evidence=search(prefix+(v,),remaining&adj[v],target)
        if status!='excluded':return status,evidence
        branches.append({'vertex':v,'proof':evidence});remaining.remove(v)
for d in domains:
    choices={i for i,n in enumerate(graph_nodes) if n['node'] in d['nodes']}
    for target in d['targets']:
        before=prefix_calls;status,witness=search((),choices,target);r={'target':target,'status':status,'prefixes_visited':prefix_calls-before}
        if status=='excluded':r['graph_cover']=witness;d['maximum_brackets_proven_pending_audit']=target-1
        elif status=='relaxed':r['necessary_interval_witness']=witness
        elif witness:r['partial_trace']=witness
        d['results'].append(r)
        if status=='excluded' or timed_out:break
    if timed_out:break
write(OUT/'multiplicity-bounds.json',capacities);write(OUT/'graph-nodes.json',graph_nodes)
''' +s[end:]
s=s.replace("'certified_subset_subsumption_enabled':True", "'certified_subset_subsumption_enabled':False,'graph_coloring_enabled':True,'graph_vertices':len(graph_nodes),'coloring_calls':color_calls,'coloring_prunes':color_prunes")
save('bound_h5_colored_bracket_counts_20261104.py',s)
s=(ROOT/'output/run_h5_projected_bracket_counts_20261104.py').read_text(encoding='utf-8').replace(pold,pnew).replace('bound_h5_projected_bracket_counts_20261104.py','bound_h5_colored_bracket_counts_20261104.py')
save('run_h5_colored_bracket_counts_20261104.py',s)
s=(ROOT/'output/audit_h5_projected_bracket_counts_20261104.py').read_text(encoding='utf-8').replace(old,new).replace(pold,pnew)
start=s.index('coverage_nodes=0');end=s.index('proved=[];witnesses=0',start)
s=s[:start]+'''coverage_nodes=color_covers=0
capacities=load(BASE/'multiplicity-bounds.json');graph=load(BASE/'graph-nodes.json');expected_graph=[];max_target=max(t for d in domains for t in d['targets'])
assert len(capacities)==len(nodes)
for ni,(b,ps,cert) in enumerate(zip(bounds,pieces,capacities)):
    bins=[]
    for r in ps:
        xsize=r[2]-r[0]+q;ysize=r[3]-r[1]+q;assert xsize>0 and ysize>0
        nx=(b[2]-b[0])//xsize+1;ny=(b[3]-b[1])//ysize+1
        assert (nx-1)*xsize<=b[2]-b[0]<nx*xsize and (ny-1)*ysize<=b[3]-b[1]<ny*ysize
        bins.append(nx*ny)
    cap=min(max_target,min(bins)) if (ni,ni) in compatible else 1
    assert cert=={'node':ni,'rectangle_bin_counts':bins,'maximum_relevant_copies':cap}
    expected_graph.extend({'node':ni,'copy':k} for k in range(cap))
assert graph==expected_graph and len(graph)==checks['graph_vertices']
def adjacent(a,b):return a!=b and tuple(sorted((graph[a]['node'],graph[b]['node']))) in compatible
def cover(prefix,choices,target,proof):
    global coverage_nodes,color_covers
    coverage_nodes+=1;whole=tuple(sorted(graph[v]['node'] for v in prefix))
    if 'geometric_prefix' in proof:
        assert set(proof)=={'geometric_prefix'} and tuple(proof['geometric_prefix'])==whole and whole in excluded;return
    assert set(proof)=={'branches','terminal_colors'} and len(prefix)<target
    remaining=set(choices)
    for child in proof['branches']:
        assert set(child)=={'vertex','proof'};v=child['vertex'];assert v in remaining
        cover(prefix+(v,),{u for u in remaining if adjacent(u,v)},target,child['proof']);remaining.remove(v)
    colors=proof['terminal_colors'];flat=[v for c in colors for v in c]
    assert len(flat)==len(set(flat)) and set(flat)==remaining and all(c for c in colors)
    for c in colors:assert all(not adjacent(a,b) for a,b in combinations(c,2))
    assert len(prefix)+len(colors)<target;color_covers+=1
''' +s[end:]
s=s.replace("cover((),d['nodes'],r['target']);", "cover((),{i for i,n in enumerate(graph) if n['node'] in d['nodes']},r['target'],r['graph_cover']);")
s=s.replace("'prefix-certificates.json']", "'prefix-certificates.json','multiplicity-bounds.json','graph-nodes.json']")
s=s.replace("'certified_subset_subsumption_verified':True", "'certified_subset_subsumption_verified':False,'multiplicity_bins_verified':len(capacities),'graph_vertices_verified':len(graph),'proper_coloring_covers_verified':color_covers")
s=s.replace('and independently enumerate every canonical count prefix.', 'and independently check all graph branches and terminal proper colorings. Reconstruct the original anchor bin multiplicity bounds and expanded graph. Every possible original multiset induces a clique; each terminal proper coloring limits its extension size.')
s=s.replace('A complete count cover must contain a verified excluded submultiset before reaching the demanded multiplicity. Enumerate every submultiset independently to check subsumption coverage.', 'A complete count cover must either contain a verified geometric prefix exclusion or a proper coloring with too few colors to reach the demanded multiplicity. Check include and exclude coverage without trusting producer adjacency lists or coloring order.')
save('audit_h5_colored_bracket_counts_20261104.py',s)
