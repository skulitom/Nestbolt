"""Generate a fresh count proof with necessary coupled-difference projections."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
replacements={
 'h5-relative-bracket-count-domains-20261104':'h5-projected-bracket-count-domains-20261104',
 'h5-relative-bracket-count-process-20261104':'h5-projected-bracket-count-process-20261104',
 'h5-first55-higher-bracket-filtered-20261104':'h5-first55-relative-bracket-filtered-20261104',
 'h5-relative-bracket-pair-domains-20261104':'h5-surviving-relative-projections-20261104',
 'h5-relative-bracket-pair-process-20261104':'h5-surviving-relative-projections-process-20261104',
 "[r for r in load(COUNT/'all-filtered-bounds.json') if r['empty_sites']==[13,14]]":"load(COUNT/'all-filtered-bounds.json')",
 "'relative-certificates.json'":"'projections.json'",
 "{tuple(r['nodes']) for r in load(PAIR/'projections.json')}":"{tuple(r['nodes']) for r in load(PAIR/'projections.json') if r['necessary_difference_bounds_units'] is None}",
 "'audit/retained-pairs.json']":"'audit/retained-pairs.json','audit/difference-bounds.json']",
}
def transform(s):
    for a,b in replacements.items():s=s.replace(a,b)
    return s
s=transform((ROOT/'output/bound_h5_relative_bracket_counts_20261104.py').read_text(encoding='utf-8'))
s=s.replace('Reconstruct the complete source bracket domain for empty cog sites13/14 directly.', 'Reconstruct both remaining source bracket domains directly. Add independently audited necessary relative-difference projection intervals to every initial difference-bound matrix, retaining source X/Y coupling in the projections. Close all initial matrices and record negative-cycle certificates before the rectangle disjunction search.')
s=s.replace('unit=lcm(gap.denominator,*(v.denominator for b in bounds for v in b),*(v.denominator for ps in pieces for r in ps for v in r));q=int(gap*unit)',"unit=int(load(PAIR/'checks.json')['rational_unit_denominator']);assert all((v*unit).denominator==1 for b in bounds for v in b) and all((v*unit).denominator==1 for ps in pieces for r in ps for v in r);q=int(gap*unit)")
s=s.replace('compatible=relative_retained\nprefix_calls=',"compatible=relative_retained\ndifference_bounds={tuple(r['nodes']):r['necessary_difference_bounds_units'] for r in load(PAIR/'audit/difference-bounds.json')};assert set(difference_bounds)==compatible\nprefix_calls=")
anchor='    clauses=[]\n    for k,(a,A) in enumerate(ps):'
insert='''    for axis in [0,1]:
        matrix=matrices[axis]
        for a in range(len(whole)):
            for b in range(a+1,len(whole)):
                box=difference_bounds[(whole[a],whole[b])]
                matrix[b][a]=min(matrix[b][a],box[axis+2]);matrix[a][b]=min(matrix[a][b],-box[axis])
        for k in range(size):
            for i in range(size):
                for j in range(size):matrix[i][j]=min(matrix[i][j],matrix[i][k]+matrix[k][j])
    clauses=[]
    for k,(a,A) in enumerate(ps):'''
assert anchor in s;s=s.replace(anchor,insert)
s=s.replace('    chosen=None\n',"    for axis,matrix in enumerate(matrices):\n        for i in range(len(matrix)):\n            if matrix[i][i]<0:return 'excluded',{'negative_cycle_axis':axis,'index':i}\n    chosen=None\n",1)
s=s.replace("'previous_search_certificates_imported':False", "'previous_search_certificates_imported':False,'coupled_difference_projections_used':len(difference_bounds)")
save('bound_h5_projected_bracket_counts_20261104.py',s)
s=transform((ROOT/'output/run_h5_relative_bracket_counts_20261104.py').read_text(encoding='utf-8')).replace('bound_h5_relative_bracket_counts_20261104.py','bound_h5_projected_bracket_counts_20261104.py')
save('run_h5_projected_bracket_counts_20261104.py',s)
s=transform((ROOT/'output/audit_h5_relative_bracket_counts_20261104.py').read_text(encoding='utf-8'))
s=s.replace('def close_sparse(matrix):',"difference_bounds={tuple(r['nodes']):r['necessary_difference_bounds_units'] for r in load(PAIR/'audit/difference-bounds.json')};assert set(difference_bounds)==compatible\nassert checks['coupled_difference_projections_used']==len(difference_bounds) and unit==int(load(PAIR/'checks.json')['rational_unit_denominator'])\n\ndef close_sparse(matrix):")
s=s.replace('    trees+=1\n',"    trees+=1\n    if 'negative_cycle_axis' in proof:\n        assert set(proof)=={'negative_cycle_axis','index'} and proof['negative_cycle_axis'] in [0,1]\n        matrix=matrices[proof['negative_cycle_axis']];i=proof['index'];assert 0<=i<len(matrix) and matrix[i][i]<0\n        leaves+=1;return\n",1)
anchor='        matrices.append(close_sparse(d))'
insert='''        for a in range(len(whole)):
            for b in range(a+1,len(whole)):
                box=difference_bounds[(whole[a],whole[b])]
                d[b][a]=box[axis+2];d[a][b]=-box[axis]
        matrices.append(close_sparse(d))'''
assert anchor in s;s=s.replace(anchor,insert)
anchor="            placed=[(o,[v+xy[o][k%2] for k,v in enumerate(rect)]) for o,n in enumerate(whole) for rect in pieces[n]]"
insert='''            for a in range(len(whole)):
                for b in range(a+1,len(whole)):
                    box=difference_bounds[(whole[a],whole[b])]
                    assert all(box[k]<=xy[b][k]-xy[a][k]<=box[k+2] for k in [0,1])
'''+anchor
assert anchor in s;s=s.replace(anchor,insert)
s=s.replace('Reconstruct every source hull interval and rectangle;', 'Reconstruct every source hull interval and rectangle; bind all necessary relative-difference projections to their independent source audit; add them to sparse original coordinate bounds, compute full Floyd closure, and check every initial negative-cycle certificate;')
s=s.replace("'certified_subset_subsumption_verified':True", "'certified_subset_subsumption_verified':True,'coupled_difference_boxes_verified':len(difference_bounds)")
save('audit_h5_projected_bracket_counts_20261104.py',s)
