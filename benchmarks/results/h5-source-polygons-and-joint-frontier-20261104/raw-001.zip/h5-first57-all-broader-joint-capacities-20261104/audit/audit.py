"""Independent exact area and finite occupancy convolution for continuous domains."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-all-broader-joint-capacities-20261104';OUT=BASE/'audit'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
BR=ROOT/'output/h5-first57-necessary-mask-cover-20261104';INS=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
HELPER=ROOT/'output/audit_h5_first57_reachable_area_20261104.py'
CAP=ROOT/'output/h5-first57-component-area-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,SOURCE/'audit',BR/'audit',INS/'audit']:
    for p,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
for base in [SOURCE,BR,INS]:assert load(base/'audit/checks.json')['passed']
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='exact_area'];assert len(functions)==1
scope={};exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'),scope);exact_area=scope['exact_area']
geometries=load(SOURCE/'geometry-domains.json')
sources=load(SOURCE/'world-cog-inner-rectangles.json')+load(SOURCE/'fixed-core-inner-rectangles.json')
covers=[load((BR if gid<8 else INS)/f'geometry-{gid:02d}-cover.json') for gid in range(10)]
minima={}
for g in geometries:
    family=g['aliases'][0][0];rects=g['inner_rectangles_um']
    assert all(f==family for f,m in g['aliases'])
    for index,a in enumerate(rects):
        for b in rects[index+1:]:assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
    area=sum((c-a)*(d-b) for a,b,c,d in rects);minima[family]=min(area,minima.get(family,area))
assert minima==load(BASE/'source-area-minima.json')
records=[];total_groups=total_boxes=0;actual=load(BASE/'all-choices.json');assert len(actual)==259
assert load(CAP/'audit/checks.json')['passed']
for p,h in load(CAP/'audit/plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
retained=load(CAP/'audit/retained-choices.json')
selected=[r['empty_sites'] for r in retained]
assert len(selected)==len(set(map(tuple,selected)))==259
for index,empty in enumerate(selected):
    expected={(g,i) for g,cover in enumerate(covers) for i,row in enumerate(cover) if row[0]&~sum(1<<i for i in empty)==0}
    claim=load(BASE/f'choice-{index:02d}.json')
    assert claim['index']==index and claim['empty_sites']==empty and claim['eligible_anchor_boxes']==len(expected)
    seen=set();verified=[];state=[[False]*9 for _ in range(9)];state[0][0]=True
    for group in claim['groups']:
        assignments=[tuple(v) for v in group['anchor_boxes']]
        assert assignments and len(set(assignments))==len(assignments) and not seen.intersection(assignments) and set(assignments)<=expected
        seen.update(assignments);reachable=[];families=set()
        for gid,ri in assignments:
            families.add(geometries[gid]['aliases'][0][0]);_,x,y,z,w,*_=covers[gid][ri]
            for a,b,c,d in geometries[gid]['inner_rectangles_um']:reachable.append((x+a,y+b,z+c,w+d))
        reachable=sorted(set(reachable))
        area,stats=exact_area(reachable,[r['bounds_um'] for r in sources if r['site_bit'] not in empty])
        assert area==group['reachable_area_um2'] and sorted(families)==group['families']
        allowed=[]
        for b in range(9):
            for i in range(9):
                if b and 'bracket' not in families or i and 'insert' not in families:continue
                if b*minima['bracket']+i*minima['insert']<=area:allowed.append([b,i])
        assert allowed==group['allowed_count_pairs']
        next_state=[[False]*9 for _ in range(9)]
        for b in range(9):
            for i in range(9):
                next_state[b][i]=any(x<=b and y<=i and state[b-x][i-y] for x,y in allowed)
        state=next_state
        verified.append({'anchor_boxes':len(assignments),'families':sorted(families),'exact_area_um2':area,'allowed_count_pairs':allowed,'sweep':stats})
    assert seen==expected
    totals=[[b,i] for b in range(9) for i in range(9) if state[b][i]]
    excluded=not state[8][8]
    assert claim['reachable_total_pairs']==totals and claim['diagnostic_excluded']==excluded
    assert actual[index]=={k:v for k,v in claim.items() if k not in ['groups','reachable_total_pairs']}|{'group_count':len(verified),'group_areas_um2':[g['exact_area_um2'] for g in verified]}
    records.append({'empty_sites':empty,'excluded':excluded,'groups':verified,'reachable_total_pairs':totals})
    total_boxes+=len(expected);total_groups+=len(verified)
write(OUT/'verified-choices.json',records)
inputs=[Path(__file__),CAP/'audit/plan.json',CAP/'audit/checks.json',CAP/'audit/retained-choices.json',HELPER,BASE/'plan.json',BASE/'checks.json',BASE/'source-area-minima.json',BASE/'all-choices.json']+[BASE/f'choice-{i:02d}.json' for i in range(259)]+[base/n for base in [SOURCE,BR,INS] for n in ['audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Each original moving body has a legal mode and an anchor in the certified full-stock continuous cover. Assign it to one eligible box and its recorded group. All its source-contained rectangles are in that group swept-body region and outside the fixed inner obstacles. Their interiors are disjoint from every other original moving body, including other families. Thus assigned b/i counts satisfy the exact group area inequality. Each family requires eight copies. Independent complete finite convolution enumerates every necessary count distribution over the groups. If (8,8) is absent the fixed29 plus selected12 cog-pose construction is continuously impossible, even at zero clearance. This does not exclude changed edge placements, different cog poses, or a whole job allocation.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'choices_verified':259,'exact_group_areas':total_groups,'anchor_boxes_assigned_once':total_boxes,
    'joint_count_distributions_exhaustive':True,'source_area_minima_um2':minima,'new_site_choices_excluded':sum(r['excluded'] for r in records),
    'remaining_site_choices':[r['empty_sites'] for r in records if not r['excluded']],'continuous_source_necessary_bound':True,'fixed29_scope_only':True,
    'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
