"""Exact rational source-support proof for every rounded ranked-stock placement hull."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint
from h5_exact_convex_partition_tools_20261029 import hull,area
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-ranked-stock-source-polygons-20261104';OUT=BASE/'source-region-audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104';JOINT=ROOT/'output/h5-first57-all-broader-joint-capacities-20261104'
PARTITION=ROOT/'output/h5-first57-necessary-rectangles-20261104/audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def transform(vertices,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));sign=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
    return [(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in vertices]
def floats(points):return np.asarray([[float(x),float(y)] for x,y in points])
def nofit(fixed,moving):return MultiPoint((floats(fixed)[:,None,:]-floats(moving)[None,:,:]).reshape(-1,2)).convex_hull
def proposal(nfp,shape):
    segment=list(shapely.shortest_line(nfp,shape).coords)
    if len(segment)!=2:return None
    dx,dy=segment[1][0]-segment[0][0],segment[1][1]-segment[0][1];length=math.hypot(dx,dy)
    return [dx/length,dy/length] if length else None
def support(region,moving,fixed,n):
    if n is None:return False,None
    nx,ny=map(F,n);gap=min(x*nx+y*ny for x,y in region)+min(x*nx+y*ny for x,y in moving)-max(x*nx+y*ny for x,y in fixed)
    norm=nx*nx+ny*ny
    return gap>0 and gap*gap>=F('0.23')**2*norm,float(gap)/math.sqrt(float(norm))
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,PRE/'audit',MOV/'audit',JOINT/'audit',PARTITION]:
    for p,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
for base in [PRE,MOV,JOINT]:assert load(base/'audit/checks.json')['passed']
assert load(PARTITION/'checks.json')['passed'] and load(PARTITION/'checks.json')['exact_source_partitions']==3
for name in ['family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','inventory.json']:assert digest(BASE/name)==digest(MOV/name)
assert digest(BASE/'fixed29.json')==digest(PRE/'fixed29.json')
ranked=sorted((-sum(g['exact_area_um2'] for g in r['groups']),r['empty_sites']) for r in load(JOINT/'audit/verified-choices.json') if not r['excluded'])
selected_area,empty=ranked[0];assert empty==[0,4,14]
assert load(BASE/'selection.json')=={'omitted_cog_sites':empty,'required_brackets':8,'required_inserts':8,'joint_reachable_area_um2':-selected_area}
parts={p['id']:p for p in load(JOB)['parts']};canonical=load(PIECES);modes=load(BASE/'family-modes.json')
fixed=load(PRE/'fixed29.json');cogs=[(i,r) for i,r in enumerate(load(PRE/'source-cog-sites.json')) if i not in empty]
sources=[]
for i,row in enumerate(fixed):
    outer=transform(parts[row['part_id']]['geometry'][0]['outer'],row['transform'])
    sources.append({'kind':'fixed','fixed_owner':i,'identity':[row['part_id'],row['copy_index']],'transform':row['transform'],'outer':outer,'hull':hull(outer),'pieces':[outer]})
for site,row in cogs:
    outer=transform(parts['cog']['geometry'][0]['outer'],row['transform']);pieces=[transform(p,row['transform']) for p in canonical['cog']]
    sources.append({'kind':'cog','site':site,'identity':[row['part_id'],row['copy_index']],'transform':row['transform'],'outer':outer,'hull':hull(outer),'pieces':pieces})
saved=load(BASE/'original-source-pieces.json');assert len(saved)==len(sources)==41
for index,(stored,source) in enumerate(zip(saved,sources)):
    assert stored['source']==index and len(stored['pieces'])==len(source['pieces'])
    assert {k:v for k,v in stored.items() if k not in ['pieces','source']}=={k:v for k,v in source.items() if k not in ['outer','hull','pieces']}
    assert all(len(a)==len(b) and max(abs(float(x)-z) for v,w in zip(a,b) for x,z in zip(w,v))<1e-9 for a,b in zip(stored['pieces'],source['pieces']))
mode_data={};full_nf={};piece_nf={}
for family,items in modes.items():
    for m in items:
        key=(family,m['mode']);t={'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':m['translation_from_lower_left']}
        pieces=[transform(p,t) for p in canonical[family]]
        mode_data[key]={'mode':m,'pieces':pieces}
        for si,source in enumerate(sources):
            for pi,piece in enumerate(pieces):full_nf[key,si,pi]=nofit(source['hull'],piece)
proofs=[];disabled=[];rounded_geometries=[];summaries=[];minimum=math.inf;fallbacks=0;total_regions=0
for gid in range(10):
    data=load(BASE/'geometries'/f'{gid:02d}.json');eligible=[(key,value) for key,value in mode_data.items() if value['mode']['normalized_geometry']==gid]
    aliases=[[key[0],key[1]] for key,value in eligible]
    assert data['geometry']==gid and data['aliases']==aliases and data['representative']==aliases[0]
    expected_domain=[min(v['mode']['integer_lower_left_bounds'][0][0] for k,v in eligible)/100,min(v['mode']['integer_lower_left_bounds'][1][0] for k,v in eligible)/100,
                     max(v['mode']['integer_lower_left_bounds'][0][1] for k,v in eligible)/100,max(v['mode']['integer_lower_left_bounds'][1][1] for k,v in eligible)/100]
    assert data['domain_mm']==expected_domain
    rounded_records=[];before=len(proofs)
    for ri,r in enumerate(data['regions']):
        assert r['region']==ri
        rounded=hull([tuple(F(round(v,9)) for v in vertex) for vertex in r['vertices']])
        if len(rounded)<3 or area(rounded)<=0:
            disabled.append([gid,ri]);continue
        shape=Polygon([(float(x),float(y)) for x,y in rounded]);assert shape.is_valid and shape.area>0
        rounded_records.append({'region':ri,'vertices_exact':[[str(x),str(y)] for x,y in rounded]})
        for key,moving in eligible:
            for si,source in enumerate(sources):
                for pi,piece in enumerate(moving['pieces']):
                    n=proposal(full_nf[key,si,pi],shape);valid,gap=support(rounded,piece,source['hull'],n)
                    if valid:
                        proofs.append([gid,ri,key[0],key[1],si,pi,-1,*n]);minimum=min(minimum,gap)
                    else:
                        fallbacks+=1
                        for ci,cp in enumerate(source['pieces']):
                            cache=(key,si,pi,ci)
                            if cache not in piece_nf:piece_nf[cache]=nofit(cp,piece)
                            normal=proposal(piece_nf[cache],shape);accepted,small_gap=support(rounded,piece,cp,normal)
                            if not accepted:
                                failure={'geometry':gid,'region':ri,'mode':list(key),'fixed_source':si,'moving_piece':pi,'fixed_piece':ci,'normal':normal,'gap_mm':small_gap}
                                write(OUT/'failed-source-proof.json',failure);raise AssertionError(failure)
                            proofs.append([gid,ri,key[0],key[1],si,pi,ci,*normal]);minimum=min(minimum,small_gap)
    rounded_geometries.append({'geometry':gid,'regions':rounded_records})
    summary={'geometry':gid,'raw_regions':len(data['regions']),'certified_rounded_regions':len(rounded_records),'exact_source_supports':len(proofs)-before}
    summaries.append(summary);total_regions+=len(data['regions']);print(summary,flush=True)
control=fixed+[r for i,r in cogs];spec=load(PRE/'plan.json')
checked=audit(load(JOB),control,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in control])
assert checked['valid'] and checked['same_sheet_pairs']==820 and checked['stock_edges']==164 and checked['cutouts']==41 and checked['hole_vertices']==3814
inventory=load(PRE/'inventory.json');instances=load(BASE/'instances.json')
assert [r['identity'] for r in instances]==inventory['moving16_orthogonal_identities'] and sum(r['mode_count'] for r in instances)==96
assert sorted([[r['part_id'],r['copy_index']] for r in fixed]+[r['identity'] for r in instances]+inventory['required_cog12_identities']+inventory['short9_identities'])==sorted(inventory['full66_identities'])
for name,value in [('source-support-certificates.json',proofs),('rounded-geometries.json',rounded_geometries),('disabled-rounded-regions.json',disabled),('geometry-verification.json',summaries),('fixed-source41-checks.json',checked)]:write(OUT/name,value)
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,PIECES]+[BASE/n for n in ['plan.json','checks.json','original-source-pieces.json','family-modes.json','mode-rectangles.json','instances.json','inventory.json','selection.json','fixed29.json']]+[BASE/'geometries'/f'{gid:02d}.json' for gid in range(10)]+[PRE/n for n in ['plan.json','fixed29.json','source-cog-sites.json','inventory.json']]+[MOV/n for n in ['audit/plan.json','audit/checks.json']]+[JOINT/n for n in ['audit/plan.json','audit/checks.json','audit/verified-choices.json']]+[PARTITION/n for n in ['plan.json','checks.json','exact-source-partitions.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Every source vertex is transformed using exact fractions of its original binary64 coordinates, saved sine/cosine coefficients and translation. Original convex partitions are independently certified by exact area/boundary cancellation. For every convex placement hull rounded to9 decimals, every legal source-mode alias and every moving component, exact rational support inequalities prove0.23mm Euclidean separation from each fixed original. Whole-source hull certificates are preferred; otherwise all original convex pieces are certified individually. Floating shortest lines propose normals only; all acceptance uses exact arithmetic and squared norms. Domain union only expands alias choice; independently certified original mode-stock bounds must still be enforced in the model. The fixed41 controls and full66 inventory are separately reread. No completeness or continuous exclusion is claimed.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'original_fixed_sources_verified':41,'original_fixed_convex_pieces':281,'legal_source_modes_verified':12,'geometry_domains_verified':10,
    'rounded_regions_reviewed':total_regions,'disabled_degenerate_regions':len(disabled),'exact_original_source_supports':len(proofs),'whole_hull_fallbacks':fallbacks,
    'minimum_certified_source_gap_mm':minimum,'fixed_source41_valid':True,'full66_identity_partition_preserved':True,
    'full_physical_stock_domains':True,'all_source_mode_aliases_verified':True,'old_strip_domains_used':False,'old_rectangle_obstacles_used':False,
    'global_coverage_claimed':False,'model_prepared':False,'source_valid66':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
