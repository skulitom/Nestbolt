"""Inward integer halfplanes for newly certified full-world-coordinate source hulls."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-full-stock-polygon-integer-20261104'
REG=ROOT/'output/h5-first57-full-stock-source-polygons-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(REG/'source-region-audit/checks.json')['passed']
assert load(REG/'source-region-audit/disabled-rounded-regions.json')==[]
inputs=[Path(__file__)]+[REG/n for n in ['plan.json','checks.json','source-region-audit/plan.json','source-region-audit/checks.json','source-region-audit/rounded-geometries.json','source-region-audit/disabled-rounded-regions.json','family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','inventory.json','fixed29.json','selection.json']]
grid=100;scale=10**9;envelope=[F(1500),F(3000)];eps=F('0.0000001')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Convert each newly certified rounded convex source hull to inward integer halfplanes over absolute world coordinates. Bound coefficient rounding using |x|<=1500mm and |y|<=3000mm, rather than any old local top strip. Normals are rounded at1e9 scale and reduced by their exact gcd. The integer RHS is rounded inward after subtracting the full exact normal-error bound and1e-7mm inset. Keep all legal original mode aliases; a shared geometry-region selector may imply any separately certified alias, with original mode-specific stock bounds still explicit. Independently audit all coefficient implications and source-copy bytes before modeling.',
    'world_origin_mm':[0,0],'grid_units_per_mm':grid,'normal_scale':scale,'absolute_coordinate_envelope_mm':[1500,3000],'plane_inset_mm':str(eps),
    'preparation_cap_seconds':10,'maximum_process_seconds':20,'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'solver_calls':0})
modes=load(REG/'family-modes.json')
for items in modes.values():
    for m in items:
        for axis,(lo,hi) in enumerate(m['integer_lower_left_bounds']):assert max(abs(lo),abs(hi))<=envelope[axis]*grid
regions=[];plane_count=0;max_error=F(0);max_activity=0
for g in load(REG/'source-region-audit/rounded-geometries.json'):
    for source in g['regions']:
        vertices=[tuple(map(F,v)) for v in source['vertices_exact']];planes=[]
        for edge,(a,b) in enumerate(zip(vertices,vertices[1:]+vertices[:1])):
            dx,dy=b[0]-a[0],b[1]-a[1];den=max(abs(dx),abs(dy));assert den>0
            normal=[dy/den,-dx/den];raw=[round(v*scale) for v in normal]
            error=sum(abs(v-F(c,scale))*limit for v,c,limit in zip(normal,raw,envelope))
            rhs=sum(v*x for v,x in zip(normal,a));divisor=math.gcd(*map(abs,raw));assert divisor>0
            coefficients=[c//divisor for c in raw];upper=math.floor((rhs-error-eps)*scale*grid)//divisor
            activity=sum(abs(c)*int(limit*grid) for c,limit in zip(coefficients,envelope))
            assert activity<2**53 and abs(upper)<2**53
            planes.append({'edge':edge,'coefficients':coefficients,'upper':upper,'unreduced_coefficients':raw,'divisor':divisor,
                           'exact_infinity_normal':list(map(str,normal)),'rounding_error_bound_mm':str(error)})
            plane_count+=1;max_error=max(max_error,error);max_activity=max(max_activity,activity)
        regions.append({'geometry':g['geometry'],'source_region':source['region'],'vertices_exact':source['vertices_exact'],'planes':planes})
write(OUT/'regions.json',regions)
for name in ['family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','inventory.json','fixed29.json','selection.json']:shutil.copyfile(REG/name,OUT/name)
checks={'prepared':True,'seconds':time.perf_counter()-started,'regions':len(regions),'integer_planes':plane_count,'maximum_normal_error_mm':float(max_error),
    'maximum_integer_activity':max_activity,'full_stock_absolute_coordinate_envelope':True,'source_mode_aliases':12,'moving_originals':16,
    'independent_integer_audit_pending':True,'model_prepared':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
assert checks['seconds']<10
write(OUT/'checks.json',checks);print(checks)
