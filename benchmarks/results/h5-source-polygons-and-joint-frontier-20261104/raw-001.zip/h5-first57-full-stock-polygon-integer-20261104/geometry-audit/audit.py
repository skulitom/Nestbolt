"""Independent exact arithmetic proof that every integer plane implies its source edge."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import combinations
import json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-full-stock-polygon-integer-20261104';OUT=BASE/'geometry-audit'
REG=ROOT/'output/h5-first57-full-stock-source-polygons-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,REG/'source-region-audit']:
    for p,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
assert load(REG/'source-region-audit/checks.json')['passed'] and load(REG/'source-region-audit/disabled-rounded-regions.json')==[]
for name in ['family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','inventory.json','fixed29.json','selection.json']:assert digest(BASE/name)==digest(REG/name)
plan=load(BASE/'plan.json');assert plan['world_origin_mm']==[0,0] and plan['absolute_coordinate_envelope_mm']==[1500,3000] and plan['normal_scale']==10**9 and plan['grid_units_per_mm']==100
scale=plan['normal_scale'];grid=100;limits=list(map(F,plan['absolute_coordinate_envelope_mm']));eps=F(plan['plane_inset_mm']);assert eps==F('0.0000001')
modes=load(BASE/'family-modes.json')
for items in modes.values():
    for m in items:
        for axis,(lo,hi) in enumerate(m['integer_lower_left_bounds']):assert -limits[axis]*grid<=lo<=hi<=limits[axis]*grid
expected=[(g['geometry'],r) for g in load(REG/'source-region-audit/rounded-geometries.json') for r in g['regions']]
records=load(BASE/'regions.json');assert len(records)==len(expected)==178
planes=0;maximum_error=F(0);minimum_inset=None;maximum_activity=0
for actual,(gid,source) in zip(records,expected):
    assert actual['geometry']==gid and actual['source_region']==source['region'] and actual['vertices_exact']==source['vertices_exact']
    vertices=[tuple(map(F,v)) for v in source['vertices_exact']]
    assert len(actual['planes'])==len(vertices)
    for index,(a,b,p) in enumerate(zip(vertices,vertices[1:]+vertices[:1],actual['planes'])):
        normal=[b[1]-a[1],a[0]-b[0]];den=max(map(abs,normal));normal=[v/den for v in normal]
        assert p['edge']==index and list(map(F,p['exact_infinity_normal']))==normal
        raw=p['unreduced_coefficients'];assert raw==[round(v*scale) for v in normal]
        divisor=p['divisor'];assert divisor==math.gcd(*map(abs,raw)) and divisor>0 and p['coefficients']==[v//divisor for v in raw]
        differences=[v-F(c,scale) for v,c in zip(normal,raw)]
        # Independently attain the maximum normal error at a corner of the complete coordinate box.
        error=max(sum(d*v for d,v in zip(differences,corner)) for corner in [(x,y) for x in [-limits[0],limits[0]] for y in [-limits[1],limits[1]]])
        assert F(p['rounding_error_bound_mm'])==error
        rhs=sum(n*v for n,v in zip(normal,a))
        assert p['upper']==math.floor((rhs-error-eps)*scale*grid)//divisor
        implied=F(p['upper']*divisor,scale*grid)+error
        inset=rhs-implied;assert inset>=eps
        assert all(sum(n*x for n,x in zip(normal,v))<=rhs for v in vertices)
        activity=sum(abs(c)*int(limit*grid) for c,limit in zip(p['coefficients'],limits));assert activity<2**53 and abs(p['upper'])<2**53
        planes+=1;maximum_error=max(maximum_error,error);maximum_activity=max(maximum_activity,activity);minimum_inset=inset if minimum_inset is None else min(minimum_inset,inset)
components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json')
pairs=[(a['component'],b['component']) for a,b in combinations(components,2) if a['owner']!=b['owner']]
assert len(components)==24 and len(groups)==16 and len(pairs)==268
for g in groups:assert len(g['components'])==len({components[i]['owner'] for i in g['components']})==16
minimum_pair_cover=min(sum(a in g['components'] and b in g['components'] for g in groups) for a,b in pairs);assert minimum_pair_cover==4
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','regions.json','family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','inventory.json','fixed29.json','selection.json']]+[REG/n for n in ['source-region-audit/plan.json','source-region-audit/checks.json','source-region-audit/rounded-geometries.json','source-region-audit/disabled-rounded-regions.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'For every source edge, maximize the exact normal-rounding error independently over all four corners of the full absolute world-coordinate envelope. The stored integer inequality implies raw_normal*position<=rounded_RHS; adding the certified error proves the original exact edge inequality with at least1e-7mm inward reserve. Every original stock domain lies inside the envelope. All source hulls, mode aliases, rigid outer components and pair groups remain byte-identical to certified sources; every268 moving-component pair is covered at least four times. No old local strip bounds are used.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'regions_verified':178,'integer_planes_verified':planes,'maximum_normal_error_mm':float(maximum_error),'minimum_implied_inset_mm':float(minimum_inset),
    'maximum_integer_activity':maximum_activity,'absolute_world_envelope_mm':[1500,3000],'all_source_aliases_preserved':True,'rigid_components':24,'moving_component_pairs':268,'pair_groups':16,'minimum_pair_coverage':minimum_pair_cover,
    'old_strip_domains_used':False,'model_prepared':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
