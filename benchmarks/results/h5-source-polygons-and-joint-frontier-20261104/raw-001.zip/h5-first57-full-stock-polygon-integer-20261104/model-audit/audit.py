from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-full-stock-polygon-integer-20261104';MODEL=BASE/'model';OUT=BASE/'model-audit'
EDGE=ROOT/'output/h5-first57-disjoint-movers-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63);MAX=2**63-1
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for folder in [BASE,MODEL,BASE/'geometry-audit']:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(BASE/'geometry-audit/checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes())
assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints'}
mapping=load(MODEL/'mapping.json');modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');regions=load(BASE/'regions.json')
rectangles=load(BASE/'mode-rectangles.json');raw_components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json')
assert mapping['position_units_per_mm']==100 and mapping['world_origin_mm']==[0,0] and mapping['rectangle_gap_grid']==23 and mapping['full_physical_stock']
assert mapping['omitted_cog_sites']==[5,11,14] and mapping['required_family_counts']=={'bracket':8,'insert':8}
assert len(mapping['owners'])==len(instances)==16
used_v=set();used_c=set()
def variable(i,name,domain):
    assert i not in used_v;used_v.add(i);v=p.variables[i]
    assert {f.name for f,x in v.ListFields()}=={'name','domain'} and v.name==name and list(v.domain)==domain
def linear(i,co,lo,hi,guard=None):
    assert i not in used_c;used_c.add(i);c=p.constraints[i]
    assert {f.name for f,x in c.ListFields()}=={'linear'}|({'enforcement_literal'} if guard is not None else set())
    assert list(c.enforcement_literal)==([] if guard is None else [guard])
    expected={k:v for k,v in co.items() if v}
    assert len(c.linear.vars)==len(expected) and dict(zip(c.linear.vars,c.linear.coeffs))==expected
    assert list(c.linear.domain)==[lo,hi]
def expr(actual,index,offset=0):
    assert list(actual.vars)==[index] and list(actual.coeffs)==[1] and actual.offset==offset
mode_count=0
for i,(o,instance) in enumerate(zip(mapping['owners'],instances)):
    assert o['owner']==i and o['identity']==instance['identity'] and o['positions']==[2*i,2*i+1]
    fm=modes[o['identity'][0]]
    for axis in [0,1]:
        variable(o['positions'][axis],f'owner_{i}_axis_{axis}',[min(m['integer_lower_left_bounds'][axis][0] for m in fm),max(m['integer_lower_left_bounds'][axis][1] for m in fm)])
    assert len(o['modes'])==len(fm)
    for actual,source in zip(o['modes'],fm):
        assert {k:v for k,v in actual.items() if k not in ['selector','stock_constraints']}==source
        selector=actual['selector'];variable(selector,f'mode_{i}_{source["mode"]}',[0,1])
        assert len(actual['stock_constraints'])==2
        for axis,(lo,hi) in enumerate(source['integer_lower_left_bounds']):linear(actual['stock_constraints'][axis],{o['positions'][axis]:1},lo,hi,selector)
        mode_count+=1
    linear(o['one_mode_constraint'],{m['selector']:1 for m in o['modes']},1,1)
region_count=0;plane_count=0;geometry_links=0;counts={'bracket':0,'insert':0}
for o in mapping['owners']:
    family=o['identity'][0];assert o['assigned_group'] is None;counts[family]+=1
    gids=sorted({m['normalized_geometry'] for m in modes[family]})
    expected=[i for i,r in enumerate(regions) if r['geometry'] in gids]
    assert [r['region'] for r in o['regions']]==expected
    for r in o['regions']:
        ri=r['region'];source=regions[ri];v=r['selector']
        variable(v,f'region_{o["owner"]}_{ri}',[0,1])
        assert len(r['constraints'])==len(source['planes'])
        for ct,plane in zip(r['constraints'],source['planes']):
            linear(ct,{o['positions'][0]:plane['coefficients'][0],o['positions'][1]:plane['coefficients'][1]},MIN,plane['upper'],v)
            plane_count+=1
        region_count+=1
    assert [g['geometry'] for g in o['region_geometry_constraints']]==gids
    for row in o['region_geometry_constraints']:
        gid=row['geometry']
        co={r['selector']:1 for r in o['regions'] if regions[r['region']]['geometry']==gid}
        for m in o['modes']:
            if m['normalized_geometry']==gid:co[m['selector']]=-1
        linear(row['constraint'],co,0,0);geometry_links+=1
assert counts=={'bracket':8,'insert':8}
assert len(mapping['components'])==len(raw_components)==24
links=0
for actual,raw in zip(mapping['components'],raw_components):
    for k,v in raw.items():assert actual[k]==v
    owner=mapping['owners'][raw['owner']];family=owner['identity'][0];piece=raw['piece'];coords=actual['coordinates']
    assert len(coords)==4
    for k,v in enumerate(coords):
        axis=k%2
        lo=min(m['integer_lower_left_bounds'][axis][0]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        hi=max(m['integer_lower_left_bounds'][axis][1]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        variable(v,f'component_{raw["component"]}_edge_{k}',[lo,hi])
    assert len(actual['mode_links'])==len(owner['modes'])
    for link,m in zip(actual['mode_links'],owner['modes']):
        offsets=rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid']
        assert link['mode']==m['mode'] and link['selector']==m['selector'] and link['offsets']==offsets and len(link['constraints'])==4
        for k,(ct,value) in enumerate(zip(link['constraints'],offsets)):linear(ct,{coords[k]:1,owner['positions'][k%2]:-1},value,value,m['selector']);links+=1
    assert len(actual['sizes'])==len(actual['size_links'])==len(actual['interval_constraints'])==2
    for axis in [0,1]:
        possible=[rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis+2]-rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis]+23 for m in owner['modes']]
        size=actual['sizes'][axis];variable(size,f'component_{raw["component"]}_size_{axis}',[min(possible),max(possible)])
        linear(actual['size_links'][axis],{size:1,coords[axis+2]:-1,coords[axis]:1},23,23)
        index=actual['interval_constraints'][axis];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
        assert {f.name for f,v in ct.ListFields()}=={'name','interval'} and ct.name==f'component_{raw["component"]}_interval_{axis}'
        expr(ct.interval.start,coords[axis]);expr(ct.interval.size,size);expr(ct.interval.end,coords[axis+2],23)
assert len(mapping['packing_groups'])==len(groups)==16
for actual,g in zip(mapping['packing_groups'],groups):
    assert {k:v for k,v in actual.items() if k!='constraint'}==g
    index=actual['constraint'];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
    assert {f.name for f,v in ct.ListFields()}=={'no_overlap_2d'}
    assert list(ct.no_overlap_2d.x_intervals)==[mapping['components'][i]['interval_constraints'][0] for i in g['components']]
    assert list(ct.no_overlap_2d.y_intervals)==[mapping['components'][i]['interval_constraints'][1] for i in g['components']]
expected_symmetry=[]
for family,group in [('bracket',None),('insert',None)]:
    peers=sorted((o for o in mapping['owners'] if o['identity'][0]==family and o['assigned_group']==group),key=lambda o:o['identity'][1])
    expected_symmetry.extend((family,group,a['owner'],b['owner']) for a,b in zip(peers,peers[1:]))
assert [(s['family'],s['group'],*s['owners']) for s in mapping['symmetry_constraints']]==expected_symmetry
for s in mapping['symmetry_constraints']:
    a,b=s['owners'];linear(s['constraint'],{2*a:1,2*b:-1},MIN,0)
assert used_v==set(range(len(p.variables))) and used_c==set(range(len(p.constraints)))
ledger=load(MODEL/'final-preparation-charges.json')
for name,h in ledger['inputs'].items():assert digest(ROOT/name)==h
expected={k:v for k,v in load(EDGE/'model-factorized/final-preparation-charges.json')['charges'].items() if k!='model_complete_process_seconds'}
processes={
    'necessary_source_bodies_complete_process_seconds':'h5-first57-necessary-rectangles-process-20261104',
    'necessary_full_stock_cover_complete_process_seconds':'h5-first57-necessary-mask-cover-process-20261104',
    'necessary_component_capacities_complete_process_seconds':'h5-first57-component-area-process-20261104',
    'broader_joint_capacities_complete_process_seconds':'h5-first57-broader-joint-capacities-process-20261104',
    'failed_direct_insert_control_complete_process_seconds':'h5-first57-broader-insert-pocket-process-20261104',
    'full_stock_source_polygons_complete_process_seconds':'h5-first57-full-stock-source-polygons-process-20261104',
    'full_stock_polygon_integer_complete_process_seconds':'h5-first57-full-stock-polygon-integer-process-20261104',
    'model_complete_process_seconds':'h5-first57-full-stock-polygon-model-process-20261104'}
for key,folder in processes.items():
    record=load(ROOT/'output'/folder/'process.json');assert record['exit_code']==0 and not record['timeout'] and record['closed']
    expected[key]=record['complete_process_seconds']
assert ledger['charges']==expected and ledger['preparation_seconds_charged']==sum(expected.values())
internal=load(MODEL/'preparation-charges.json');t=internal.pop('model_internal_seconds_pending_complete_process_charge')
assert internal=={k:v for k,v in expected.items() if k!='model_complete_process_seconds'} and t==ledger['internal_model_seconds_replaced'] and t<expected['model_complete_process_seconds']
assert ledger['algorithm_seconds']==60 and ledger['shared_seconds']==90 and ledger['source_validation_reserve_seconds']==4 and ledger['maximum_calls']==1 and not ledger['retry_permitted']
assert len(p.variables)==1696 and len(p.constraints)==6470 and mode_count==96 and links==640 and region_count==1424 and plane_count==5416 and geometry_links==80
inputs=[Path(__file__),ROOT/'output/prepare_h5_full_stock_polygon_model_helpers_20261104.py',ROOT/'output/audit_h5_broader_positive_model_20261104.py',EDGE/'model-factorized/final-preparation-charges.json']+[ROOT/'output'/folder/'process.json' for folder in processes.values()]+[BASE/n for n in ['plan.json','geometry-audit/plan.json','geometry-audit/checks.json','regions.json','family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','selection.json']]+[MODEL/n for n in ['plan.json','checks.json','model.pb','model.pbtxt','mapping.json','preparation-charges.json','final-preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Every proto variable and constraint is independently reconstructed. Each owner has exactly one original legal mode and exactly one region shared by aliases of that normalized geometry. All677 independently inward-rounded halfplanes are applied per owner, with original mode stock bounds retained. Every alias is separately source-certified. All24 source-covering components are linked rigidly to their owner; sixteen groups preserve all268 moving component pairs. All8 bracket and8 insert copies remain freely movable, with only same-family X ordering. Source proof, full inventory and complete preparation ledger remain mandatory before one call.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'all_model_fields_exhaustively_verified':True,'variables_verified':len(used_v),'constraints_verified':len(used_c),
    'legal_mode_selectors_verified':mode_count,'positive_region_selectors_verified':region_count,'integer_plane_constraints_verified':plane_count,'geometry_alias_equations_verified':geometry_links,'rigid_coordinate_links_verified':links,'global_moving_groups_verified':16,
    'fixed_obstacle_intervals':0,'required_family_counts':{'bracket':8,'insert':8},'symmetry_rows_within_family':14,'all66_inventory_geometry_audited':True,
    'preparation_seconds_charged':ledger['preparation_seconds_charged'],'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),
    'maximum_calls':1,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
