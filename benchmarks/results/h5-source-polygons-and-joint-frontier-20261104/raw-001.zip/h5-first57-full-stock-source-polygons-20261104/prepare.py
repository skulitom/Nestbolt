"""Fresh original-source Minkowski obstacles for the complete physical stock."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import merge_exact
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-full-stock-source-polygons-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104'
JOINT=ROOT/'output/h5-first57-broader-joint-capacities-20261104';PARTITION=ROOT/'output/h5-first57-necessary-rectangles-20261104/audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def transformed(vertices,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    return [(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in vertices]
def polygonal(g):
    if g.is_empty:return Polygon()
    if g.geom_type=='Polygon':return g
    if not hasattr(g,'geoms'):return Polygon()
    children=[polygonal(p) for p in g.geoms]
    return unary_union([p for p in children if not p.is_empty])
OUT.mkdir();(OUT/'geometries').mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',JOB,PIECES]+[PRE/n for n in ['plan.json','audit/plan.json','audit/checks.json','fixed29.json','source-cog-sites.json','inventory.json']]+[MOV/n for n in ['audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json']]+[JOINT/n for n in ['audit/plan.json','audit/checks.json','audit/verified-choices.json']]+[PARTITION/n for n in ['plan.json','checks.json','exact-source-partitions.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New full-stock original-source polygon construction. Select the nonexcluded broad cog choice with largest independently exact joint reachable area, lexicographic tie break. For every distinct moving filled geometry, transform original canonical convex pieces and form Minkowski no-fit hulls against every fixed29 original and all12 selected original cog poses. Inflate each no-fit hull with a0.231mm half-width square. Subtract the union from the full physical mode-anchor domain, using the union of inward stock domains for equivalent source-mode aliases. Decompose polygonal free space into constrained triangles and exact-convex merges. Exact rational source-separation certification for every rounded region and every mode alias is required before integer conversion. Mode-specific original stock bounds remain explicit later. No old strip, rectangle band obstacle, positive regions or model response is consumed.',
    'fixed_originals':29,'cog_originals':12,'moving_originals':16,'square_half_width_mm':0.231,'required_certified_source_gap_mm':0.23,
    'preparation_cap_seconds':25,'maximum_process_seconds':35,'old_strip_domains_used':False,'old_rectangle_obstacles_used':False,'solver_calls':0,'native_calls':0})
for base in [PRE,MOV,JOINT]:assert load(base/'audit/checks.json')['passed']
assert load(PARTITION/'checks.json')['passed']
candidates=[r for r in load(JOINT/'audit/verified-choices.json') if not r['excluded']]
chosen=min(candidates,key=lambda r:(-sum(g['exact_area_um2'] for g in r['groups']),r['empty_sites']))
empty=chosen['empty_sites'];assert empty==[5,11,14]
parts={p['id']:p for p in load(JOB)['parts']};canonical=load(PIECES);modes=load(MOV/'family-modes.json')
fixed=load(PRE/'fixed29.json')
cogs=[{'site':i,'source':r} for i,r in enumerate(load(PRE/'source-cog-sites.json')) if i not in empty]
sources=[]
for i,row in enumerate(fixed):
    sources.append({'source':i,'kind':'fixed','fixed_owner':i,'identity':[row['part_id'],row['copy_index']],'transform':row['transform'],
                    'pieces':[transformed(parts[row['part_id']]['geometry'][0]['outer'],row['transform'])]})
for row in cogs:
    source=row['source']
    sources.append({'source':len(sources),'kind':'cog','site':row['site'],'identity':[source['part_id'],source['copy_index']],'transform':source['transform'],
                    'pieces':[transformed(p,source['transform']) for p in canonical['cog']]})
assert len(sources)==41
write(OUT/'original-source-pieces.json',sources)
square=np.asarray([[-.231,-.231],[.231,-.231],[.231,.231],[-.231,.231]])
summaries=[]
for gid in range(10):
    aliases=[(family,m) for family,items in modes.items() for m in items if m['normalized_geometry']==gid]
    assert aliases
    family,representative=aliases[0]
    t={'rotation_radians':representative['rotation_radians'],'mirrored':representative['mirrored'],'translation':representative['translation_from_lower_left']}
    moving=[transformed(p,t) for p in canonical[family]]
    domain=[min(m['integer_lower_left_bounds'][0][0] for f,m in aliases)/100,min(m['integer_lower_left_bounds'][1][0] for f,m in aliases)/100,
            max(m['integer_lower_left_bounds'][0][1] for f,m in aliases)/100,max(m['integer_lower_left_bounds'][1][1] for f,m in aliases)/100]
    obstacles=[]
    for source in sources:
        pieces=[]
        for c in source['pieces']:
            for a in moving:
                points=(np.asarray(c)[:,None,:]-np.asarray(a)[None,:,:]).reshape(-1,2)
                pieces.append(MultiPoint((points[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
        obstacles.append(unary_union(pieces))
    free=polygonal(box(*domain).difference(unary_union(obstacles)))
    triangles=[p for p in shapely.constrained_delaunay_triangles(free).geoms if p.area>0]
    assert all(p.geom_type=='Polygon' and len(p.exterior.coords)==4 for p in triangles)
    convex,merges=merge_exact(triangles) if triangles else ([],0)
    polygons=[Polygon(p) for p in convex]
    error=unary_union(polygons).symmetric_difference(free).area if polygons else free.area
    assert error<1e-6,(gid,error)
    record={'geometry':gid,'aliases':[[f,m['mode']] for f,m in aliases],'representative':[family,representative['mode']],'domain_mm':domain,
            'free_area_mm2':free.area,'triangles':len(triangles),'exact_convex_merges':merges,'diagnostic_coverage_error_mm2':error,
            'regions':[{'region':i,'vertices':v} for i,v in enumerate(convex)]}
    write(OUT/'geometries'/f'{gid:02d}.json',record)
    write(OUT/'geometries'/f'{gid:02d}-obstacles.json',[{'source':i,'geometry':mapping(p)} for i,p in enumerate(obstacles)])
    summary={k:v for k,v in record.items() if k!='regions'}|{'regions':len(convex)}
    summaries.append(summary);print(summary,flush=True);assert time.perf_counter()-started<25
for name in ['family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','inventory.json']:shutil.copyfile(MOV/name,OUT/name)
shutil.copyfile(PRE/'fixed29.json',OUT/'fixed29.json')
write(OUT/'selection.json',{'omitted_cog_sites':empty,'required_brackets':8,'required_inserts':8,'joint_reachable_area_um2':sum(g['exact_area_um2'] for g in chosen['groups'])})
write(OUT/'geometry-summaries.json',summaries)
checks={'prepared':True,'seconds':time.perf_counter()-started,'fixed_source_originals':41,'source_convex_pieces':sum(len(r['pieces']) for r in sources),
    'source_mode_aliases':12,'geometry_domains':10,'convex_regions':sum(r['regions'] for r in summaries),'full_physical_stock':True,
    'old_strip_domains_used':False,'old_rectangle_band_obstacles_used':False,'independent_exact_source_audit_pending':True,
    'source_valid66':False,'continuous_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
