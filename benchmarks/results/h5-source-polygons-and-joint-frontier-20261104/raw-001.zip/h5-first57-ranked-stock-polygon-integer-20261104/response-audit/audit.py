"""Independently verify the closed INFEASIBLE response and complete stage ledger."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-first57-ranked-stock-polygon-integer-20261104'
MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
roots=[BASE/'plan.json',MODEL/'plan.json',BASE/'geometry-audit/plan.json',BASE/'model-audit/plan.json',SEARCH/'opened.json',MODEL/'final-preparation-charges.json',
    ROOT/'output/h5-disjoint-assignment-reader-controls-20261104/plan.json',
    ROOT/'output/h5-first57-ranked-stock-polygon-model-process-20261104/opened.json',
    ROOT/'output/h5-first57-ranked-stock-polygon-integer-process-20261104/opened.json',
    ROOT/'output/h5-first57-ranked-stock-source-polygons-process-20261104/opened.json',
    ROOT/'output/h5-first57-broader-insert-pocket-process-20261104/opened.json',
    ROOT/'output/h5-first57-all-broader-joint-capacities-process-20261104/opened.json']
queue=list(roots);seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p);v=load(p)
    if not isinstance(v,dict):continue
    refs=dict(v.get('inputs',{}))
    if 'script' in v and 'script_sha256' in v:refs[v['script']]=v['script_sha256']
    for name,expected in refs.items():
        q=ROOT/name
        assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts)
        assert digest(q)==expected,name
        bindings[name]=expected
        if q.suffix=='.json':queue.append(q)
for folder in ['geometry-audit','model-audit']:assert load(BASE/folder/'checks.json')['passed']
assert load(ROOT/'output/h5-first57-disjoint-obstacles-20261104/audit/checks.json')['passed']
assert load(ROOT/'output/h5-disjoint-assignment-reader-controls-20261104/checks.json')['passed']
opened,result,process,budget=[load(SEARCH/n) for n in ['opened.json','result.json','process.json','budget.json']]
ledger=load(MODEL/'final-preparation-charges.json');charges=ledger['charges']
expected={
    'fixed_source_mode_geometry_preparation_seconds':load(ROOT/'output/h5-first55-after-source-valid11-20261029/checks.json')['seconds'],
    'source_cog_site_preparation_seconds':load(ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight/checks.json')['seconds'],
    'source_rectangle_preparation_seconds':load(ROOT/'output/h5-first55-cog-site-masks-20261029/rigid-rectangle-preflight/checks.json')['seconds']}
for folder,key in [
    ('h5-first57-direct-short9-process-20261104','direct_short9_and_inventory_complete_process_seconds'),
    ('h5-first57-disjoint-obstacles-process-20261104','disjoint_source_obstacles_complete_process_seconds'),
    ('h5-first57-disjoint-movers-process-20261104','full_stock_movers_complete_process_seconds'),
    ('h5-first57-necessary-rectangles-process-20261104','necessary_source_bodies_complete_process_seconds'),
    ('h5-first57-necessary-mask-cover-process-20261104','necessary_full_stock_cover_complete_process_seconds'),
    ('h5-first57-component-area-process-20261104','necessary_component_capacities_complete_process_seconds'),
    ('h5-first57-all-broader-joint-capacities-process-20261104','all_broader_joint_capacities_complete_process_seconds'),
    ('h5-first57-broader-insert-pocket-process-20261104','failed_direct_insert_control_complete_process_seconds'),
    ('h5-first57-ranked-stock-source-polygons-process-20261104','ranked_stock_source_polygons_complete_process_seconds'),
    ('h5-first57-ranked-stock-polygon-integer-process-20261104','ranked_stock_polygon_integer_complete_process_seconds'),
    ('h5-first57-ranked-stock-polygon-model-process-20261104','model_complete_process_seconds')]:
    p=load(ROOT/'output'/folder/'process.json');assert p['exit_code']==0 and not p['timeout'] and p['closed'];expected[key]=p['complete_process_seconds']
assert charges==expected
charge=sum(charges.values())
assert charge==ledger['preparation_seconds_charged']==opened['preparation_seconds_charged']==budget['preparation_seconds_charged']==result['preparation_seconds_charged']
assert ledger['internal_model_seconds_replaced']==load(MODEL/'preparation-charges.json')['model_internal_seconds_pending_complete_process_charge']<charges['model_complete_process_seconds']
for data in [load(MODEL/'plan.json'),ledger,opened,budget]:
    assert data['algorithm_seconds']==60 and data['shared_seconds']==90 and data['source_validation_reserve_seconds']==4
for data in [load(MODEL/'plan.json'),opened,budget]:
    assert data['maximum_calls']==1 and not data['retry_permitted']
assert digest(MODEL/'model.pb')==digest(SEARCH/'model.pb')==opened['model_sha256']==load(BASE/'model-audit/checks.json')['model_sha256']
model=cp_model_pb2.CpModelProto();model.ParseFromString((SEARCH/'model.pb').read_bytes())
assert {f.name for f,v in model.ListFields()}=={'variables','constraints'}
assert len(model.variables)==1448 and len(model.constraints)==5422
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes())
assert response.status==cp_model_pb2.INFEASIBLE and result['status']=='INFEASIBLE'
assert not response.solution and not response.additional_solutions
assert not list((SEARCH/'incumbents').iterdir()) and result['incumbents_recorded']==0
assert not (SEARCH/'assignment.json').exists() and not (SEARCH/'source-response').exists()
parameters=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
assert {f.name for f,v in parameters.ListFields()}=={'max_time_in_seconds','num_search_workers','random_seed','log_search_progress','log_to_stdout','ignore_subsolvers'}
assert parameters.max_time_in_seconds==opened['parameters']['max_time_in_seconds']==result['allocated_solve_seconds']
assert 0<parameters.max_time_in_seconds<60-charge-4
assert parameters.num_search_workers==4 and parameters.random_seed==0 and parameters.log_search_progress and not parameters.log_to_stdout
assert list(parameters.ignore_subsolvers)==['fj']
assert response.num_branches==result['returned_response_branches'] and response.num_conflicts==result['returned_response_conflicts']
assert response.wall_time==result['solver_wall_seconds']<=result['returned_solve_seconds']
assert result['returned_solve_overrun_seconds']==max(0,result['returned_solve_seconds']-result['allocated_solve_seconds'])
assert result['algorithm_overrun_seconds']==max(0,result['algorithm_seconds_including_preparation']-60)
assert process['seconds_including_preparation']>=result['algorithm_seconds_including_preparation']>=charge+result['returned_solve_seconds']
assert result['closed'] and result['solver_calls']==1 and not result['has_assignment']
assert result['source_checker_calls']==result['native_calls']==0
assert not any(result[k] for k in ['source_valid66','any_allocation_excluded','H5_complete'])
assert process['closed'] and process['exit_code']==0 and not process['timeout']
assert (SEARCH/'stderr.txt').read_text()==''
assert response.num_branches==20878 and response.num_conflicts==4888
assert 'Starting search at ' in (SEARCH/'solver.log').read_text()
assert 'Stopped after presolve.' not in (SEARCH/'solver.log').read_text()
assert load(BASE/'geometry-audit/checks.json')['all_source_aliases_preserved']
assert load(ROOT/'output/h5-first57-ranked-stock-source-polygons-20261104/source-region-audit/checks.json')['fixed_source41_valid']
assert load(ROOT/'output/h5-first57-broader-insert-pocket-20261104/audit/checks.json')['failed_control_preserved']
assert not load(ROOT/'output/h5-first57-broader-insert-pocket-20261104/audit/checks.json')['fixed30_use_permitted']
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),MODEL/'final-preparation-charges.json',
    BASE/'model-audit/checks.json',BASE/'model-audit/plan.json']+roots+[SEARCH/n for n in ['budget.json','result.json','process.json','response.pb','parameters.pbtxt','model.pb','solver.log','stdout.txt','stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_input_bindings_verified':len(bindings),'closed_solver_calls':1,
    'solver_status':'INFEASIBLE','model_variables':1448,'model_constraints':5422,'assignments':0,'incumbents':0,
    'stopped_after_presolve':False,'branches':response.num_branches,'conflicts':response.num_conflicts,'preparation_seconds_charged':charge,
    'returned_solve_seconds':result['returned_solve_seconds'],'allocated_solve_seconds':result['allocated_solve_seconds'],
    'solve_slice_overrun_seconds':result['returned_solve_overrun_seconds'],
    'algorithm_seconds_including_preparation':result['algorithm_seconds_including_preparation'],
    'shared_seconds_including_preparation':process['seconds_including_preparation'],
    'algorithm_overrun_seconds':result['algorithm_overrun_seconds'],'shared_overrun_seconds':max(0,process['seconds_including_preparation']-90),
    'source_valid66':False,'any_allocation_excluded':False,'remaining_candidates':440,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
