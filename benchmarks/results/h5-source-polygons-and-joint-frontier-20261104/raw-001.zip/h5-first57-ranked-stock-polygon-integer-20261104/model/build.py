from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-ranked-stock-polygon-integer-20261104';OUT=BASE/'model'
EDGE=ROOT/'output/h5-first57-disjoint-movers-20261104';PRE=ROOT/'output/h5-first57-direct-short9-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'geometry-audit/checks.json')['passed']
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'build.py')
modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');rectangles=load(BASE/'mode-rectangles.json')
raw_components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json');regions=load(BASE/'regions.json')
model=cp_model.CpModel()
def var(i):return model.get_int_var_from_proto_index(i)
def linear(co,lo,hi,guard=None):
    ct=model.add_linear_constraint(sum(v*var(i) for i,v in co.items() if v),lo,hi)
    if guard is not None:ct.only_enforce_if(var(guard))
    return ct.index
owners=[]
for index,instance in enumerate(instances):
    fm=modes[instance['identity'][0]];xy=[]
    for axis in [0,1]:xy.append(model.new_int_var(min(m['integer_lower_left_bounds'][axis][0] for m in fm),max(m['integer_lower_left_bounds'][axis][1] for m in fm),f'owner_{index}_axis_{axis}').index)
    owners.append({'owner':index,'identity':instance['identity'],'positions':xy,'modes':[]})
for owner in owners:
    for m in modes[owner['identity'][0]]:
        selector=model.new_bool_var(f'mode_{owner["owner"]}_{m["mode"]}').index
        saved={**m,'selector':selector,'stock_constraints':[linear({owner['positions'][k]:1},a,b,selector) for k,(a,b) in enumerate(m['integer_lower_left_bounds'])]}
        owner['modes'].append(saved)
    owner['one_mode_constraint']=linear({m['selector']:1 for m in owner['modes']},1,1)
# One region per normalized geometry; original mode selectors remain separate.
for owner in owners:
    geometry_ids=sorted({m['normalized_geometry'] for m in owner['modes']})
    owner['assigned_group']=None;owner['regions']=[]
    for ri,r in enumerate(regions):
        if r['geometry'] not in geometry_ids:continue
        selector=model.new_bool_var(f'region_{owner["owner"]}_{ri}').index
        cts=[linear(dict(zip(owner['positions'],p['coefficients'])),cp_model.INT_MIN,p['upper'],selector) for p in r['planes']]
        owner['regions'].append({'region':ri,'selector':selector,'constraints':cts})
    owner['region_geometry_constraints']=[]
    for gid in geometry_ids:
        co={r['selector']:1 for r in owner['regions'] if regions[r['region']]['geometry']==gid}
        co.update({m['selector']:-1 for m in owner['modes'] if m['normalized_geometry']==gid})
        owner['region_geometry_constraints'].append({'geometry':gid,'constraint':linear(co,0,0)})
components=[];intervals_x=[];intervals_y=[];gap=23;coordinate_links=0
for raw in raw_components:
    owner=owners[raw['owner']];family=owner['identity'][0];piece=raw['piece'];coords=[]
    for k in range(4):
        axis=k%2;fm=owner['modes']
        lo=min(m['integer_lower_left_bounds'][axis][0]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in fm)
        hi=max(m['integer_lower_left_bounds'][axis][1]+rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in fm)
        coords.append(model.new_int_var(lo,hi,f'component_{raw["component"]}_edge_{k}').index)
    saved={**raw,'coordinates':coords,'mode_links':[],'sizes':[],'size_links':[],'interval_constraints':[]}
    for m in owner['modes']:
        offsets=rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid']
        links=[linear({coords[k]:1,owner['positions'][k%2]:-1},value,value,m['selector']) for k,value in enumerate(offsets)]
        saved['mode_links'].append({'mode':m['mode'],'selector':m['selector'],'offsets':offsets,'constraints':links});coordinate_links+=4
    for axis in [0,1]:
        possible=[rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis+2]-rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][axis]+gap for m in owner['modes']]
        size=model.new_int_var(min(possible),max(possible),f'component_{raw["component"]}_size_{axis}').index
        saved['sizes'].append(size);saved['size_links'].append(linear({size:1,coords[axis+2]:-1,coords[axis]:1},gap,gap))
        interval=model.new_interval_var(var(coords[axis]),var(size),var(coords[axis+2])+gap,f'component_{raw["component"]}_interval_{axis}')
        saved['interval_constraints'].append(interval.index)
        (intervals_x if axis==0 else intervals_y).append(interval)
    components.append(saved)
packing=[]
for g in groups:
    ct=model.add_no_overlap_2d([intervals_x[i] for i in g['components']],[intervals_y[i] for i in g['components']])
    packing.append({**g,'constraint':ct.index})
symmetry=[]
for family,group in [('bracket',None),('insert',None)]:
    peers=sorted((o for o in owners if o['identity'][0]==family and o['assigned_group']==group),key=lambda o:o['identity'][1])
    for a,b in zip(peers,peers[1:]):
        symmetry.append({'family':family,'group':group,'owners':[a['owner'],b['owner']],'constraint':linear({a['positions'][0]:1,b['positions'][0]:-1},cp_model.INT_MIN,0)})
validation=model.validate();write(OUT/'validation.json',{'validation':validation});assert not validation
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
mapping={'owners':owners,'components':components,'packing_groups':packing,'symmetry_constraints':symmetry,'position_units_per_mm':100,
    'world_origin_mm':[0,0],'rectangle_gap_grid':23,'full_physical_stock':True,'omitted_cog_sites':[0,4,14],'required_family_counts':{'bracket':8,'insert':8}}
write(OUT/'mapping.json',mapping)
elapsed=time.perf_counter()-started
inherited=load(EDGE/'model-factorized/final-preparation-charges.json')['charges']
charges={k:v for k,v in inherited.items() if k!='model_complete_process_seconds'}
processes={
    'necessary_source_bodies_complete_process_seconds':'h5-first57-necessary-rectangles-process-20261104',
    'necessary_full_stock_cover_complete_process_seconds':'h5-first57-necessary-mask-cover-process-20261104',
    'necessary_component_capacities_complete_process_seconds':'h5-first57-component-area-process-20261104',
    'all_broader_joint_capacities_complete_process_seconds':'h5-first57-all-broader-joint-capacities-process-20261104',
    'failed_direct_insert_control_complete_process_seconds':'h5-first57-broader-insert-pocket-process-20261104',
    'ranked_stock_source_polygons_complete_process_seconds':'h5-first57-ranked-stock-source-polygons-process-20261104',
    'ranked_stock_polygon_integer_complete_process_seconds':'h5-first57-ranked-stock-polygon-integer-process-20261104'}
for name,folder in processes.items():
    record=load(ROOT/'output'/folder/'process.json');assert record['exit_code']==0 and not record['timeout'];charges[name]=record['complete_process_seconds']
charges['model_internal_seconds_pending_complete_process_charge']=elapsed
write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),ROOT/'output/prepare_h5_ranked_stock_polygon_helpers_20261104.py',ROOT/'output/build_h5_broader_positive_model_20261104.py',EDGE/'model-factorized/final-preparation-charges.json']+[ROOT/'output'/folder/'process.json' for folder in processes.values()]+[BASE/n for n in ['plan.json','checks.json','geometry-audit/plan.json','geometry-audit/checks.json','regions.json','family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','fixed29.json','selection.json']]+[PRE/'inventory.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Fresh ranked-stock original-source polygon construction with all8 brackets and8 inserts movable and12 cog poses excluding0,4,14. Every owner selects exactly one original legal mode and one region for its normalized geometry. All original mode stock constraints remain explicit. Each region applies every independently audited inward integer halfplane. Alias sharing is valid only because every region was separately certified against every original source mode. All24 component rectangles remain rigidly linked and16 moving-pair groups cover every268 different-owner component pair. Same-family X ordering only relabels identical copies. The ledger includes upstream selection, failed insert control, fresh source polygons, integer preparation and complete model build. No closed model response, assignment, old positive rectangle regions or hints are consumed.',
    'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False})
checks={'passed':True,'seconds':elapsed,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),
    'owners':16,'legal_mode_selectors':96,'region_selectors':sum(len(o['regions']) for o in owners),'rigid_components':24,'coordinate_links':coordinate_links,
    'global_pair_groups':len(groups),'fixed_obstacle_intervals':0,'same_group_symmetry_rows':len(symmetry),'required_family_counts':{'bracket':8,'insert':8},
    'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'provisional_preparation_seconds':sum(charges.values()),
    'complete_process_charge_pending':True,'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
assert elapsed<15
write(OUT/'checks.json',checks);print(checks)
