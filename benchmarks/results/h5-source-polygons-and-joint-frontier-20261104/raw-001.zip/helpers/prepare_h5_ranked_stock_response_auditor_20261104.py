from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_full_stock_polygon_response_20261104.py').read_text(encoding='utf-8')
s=s.replace('full-stock','ranked-stock').replace('full_stock','ranked_stock')
s=s.replace('h5-first57-broader-joint-capacities','h5-first57-all-broader-joint-capacities').replace('broader_joint_capacities_complete_process_seconds','all_broader_joint_capacities_complete_process_seconds')
s=s.replace("'ranked_stock_movers_complete_process_seconds'","'full_stock_movers_complete_process_seconds'")
s=s.replace("'necessary_ranked_stock_cover_complete_process_seconds'","'necessary_full_stock_cover_complete_process_seconds'")
s=s.replace('1696','1448').replace('6470','5422').replace('14524','20878').replace('1196','4888')
with (O/'audit_h5_ranked_stock_polygon_response_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Independent response reader for the distinct maximum joint-area arrangement written.')
