from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-source-polygons-and-joint-frontier-20261104';OUT=ROOT/'benchmarks/results'/NAME
FIRST=ROOT/'output/h5-first57-full-stock-polygon-integer-20261104'
RANKED=ROOT/'output/h5-first57-ranked-stock-polygon-integer-20261104'
JOINT=ROOT/'output/h5-first57-all-broader-joint-capacities-20261104'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
for base in [FIRST,RANKED]:
    for name in ['geometry-audit','model-audit','response-audit']:assert load(base/name/'checks.json')['passed']
    r=load(base/'response-audit/checks.json')
    assert r['solver_status']=='INFEASIBLE' and r['closed_solver_calls']==1 and r['assignments']==0
    assert r['solve_slice_overrun_seconds']==r['algorithm_overrun_seconds']==r['shared_overrun_seconds']==0
joint=load(JOINT/'audit/checks.json');assert joint['passed'] and joint['choices_verified']==259 and joint['new_site_choices_excluded']==0
ranked=sorted((-sum(g['exact_area_um2'] for g in r['groups']),r['empty_sites']) for r in load(JOINT/'audit/verified-choices.json'))
assert ranked[0]==(-564121597558,[0,4,14])
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
folders=[FIRST,RANKED,JOINT,ROOT/'output/h5-first57-all-broader-joint-capacities-process-20261104']
for label in ['full-stock','ranked-stock']:
    folders.extend(ROOT/'output'/f'h5-first57-{label}-{suffix}-20261104' for suffix in ['source-polygons','source-polygons-process','polygon-integer-process','polygon-model-process'])
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_full_stock*20261104.py','*h5_ranked_stock*20261104.py','*h5_all_broader_joint*20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,
    'prepare_h5_source_polygon_runner_20261104.py','prepare_h5_polygon_integer_runner_20261104.py',
    'prepare_h5_broader_joint_capacities_20261104.py','audit_h5_broader_joint_capacities_20261104.py','run_h5_broader_joint_capacities_20261104.py',
    'h5-source-polygons-and-joint-frontier-report-20261104.md']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for label,base,source in [('first',FIRST,ROOT/'output/h5-first57-full-stock-source-polygons-20261104'),('ranked',RANKED,ROOT/'output/h5-first57-ranked-stock-source-polygons-20261104')]:
    for src,name in [(source/'source-region-audit/checks.json','source-audit'),(base/'geometry-audit/checks.json','integer-audit'),(base/'model-audit/checks.json','model-audit'),(base/'response-audit/checks.json','response-audit'),(base/'model/final-preparation-charges.json','preparation-charges'),(base/'search/result.json','closed-result')]:
        shutil.copyfile(src,OUT/f'{label}-{name}.json')
shutil.copyfile(JOINT/'audit/checks.json',OUT/'all-joint-audit.json')
shutil.copyfile(ROOT/'output/h5-first57-all-broader-joint-capacities-process-20261104/process.json',OUT/'all-joint-process.json')
write(OUT/'next-step.json',{'closed_calls_must_not_be_repeated':True,
    'closed_models':[{'omitted_sites':load(b/'selection.json')['omitted_cog_sites'],'model_sha256':load(b/'model-audit/checks.json')['model_sha256'],'status':'INFEASIBLE'} for b in [FIRST,RANKED]],
    'continuous_exclusions':0,'fixed29_choices_remaining':259,'whole_allocation_candidates':440,
    'next_method':'Derive certified local conflict bounds over the existing exact continuous necessary anchor-box cover. Each node must carry a complete source-contained inner body and cover every legal mode/anchor. Two nodes may be declared incompatible only when exact coordinate inequalities prove some pair of inner source rectangles overlaps strictly for every pair of anchors in the two closed boxes. Self-incompatibility must be proved before treating a node as unit capacity; subdividing large boxes must preserve complete closed-domain coverage. Any clique-cover, weighted occupancy or finite graph bound must retain an independently replayable exact certificate and all bracket/insert counts. A failed graph bound is not a packing witness or continuous exclusion. Changed fixed/cog geometry requires new coverage and source proofs. All current model calls stay closed; no reseeds or extensions.',
    'source_cover':'output/h5-first57-necessary-mask-cover-20261104','source_inner_bodies':'output/h5-first57-necessary-rectangles-20261104',
    'local_conflict_bound_prepared':False,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'distinct_source_polygon_constructions':2,'source_regions':[178,147],'source_supports':[18136,14874],'integer_planes':[677,546],
    'model_sizes':[[1696,6470],[1448,5422]],'closed_solver_calls':2,'solver_statuses':['INFEASIBLE','INFEASIBLE'],'assignments':0,
    'all_joint_choices_verified':259,'exact_joint_group_areas':690,'joint_anchor_boxes_assigned_once':39235,'joint_choices_excluded':0,
    'overruns_seconds':0,'continuous_exclusions':0,'whole_allocation_candidates':440,'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-source-polygons-and-joint-frontier-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 original-source polygons and joint frontier:** [independent audits]({link}) certify 178/147 fresh full-stock source regions and every field of two distinct shared-alias models for omitted cog sites [5,11,14] and [0,4,14]. Both sole calls close grid-INFEASIBLE without placements or overruns; preparation-inclusive algorithm/shared totals are 26.449704/26.514206 s and 52.151574/52.211289 s. All259 broader joint area/count bounds also pass exact replay: 690 areas and39,235 anchor-box assignments, no additional exclusion. The largest total joint area selects [0,4,14]; its complete26.682578 s selection preparation is charged. No continuous infeasibility follows from either positive model. Next assess exact local conflict bounds over the continuous necessary anchor cover. All259 broader choices,440 allocations,full66 checks and H2/H5 remain open at60%. All prior calls stay closed.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [broader fixed-core construction](../benchmarks/results/h5-broader-core-positive-construction-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [source polygons and joint frontier](../benchmarks/results/{NAME}.md).',1)
a='The broader fixed29 frontier remains 259 choices. Original-source polygon\nobstacles, with fresh full-stock proofs, are next to assess. All prior calls stay closed.'
b='Two fresh original-source polygon models also close grid-INFEASIBLE without\noverruns. Joint bounds verify all 259 broader choices and exclude none; the\nlargest joint-area choice [0,4,14] has its own audited closed polygon call.\nThe broader fixed29 frontier remains 259 choices. Exact local conflict bounds\nover the continuous necessary anchor cover are next to assess. All prior calls stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
