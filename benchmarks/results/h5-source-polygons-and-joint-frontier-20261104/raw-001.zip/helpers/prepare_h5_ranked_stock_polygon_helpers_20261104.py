from pathlib import Path
O=Path(__file__).resolve().parent
names=[
    'prepare_h5_full_stock_source_polygons_20261104.py',
    'run_h5_full_stock_source_polygons_20261104.py',
    'audit_h5_full_stock_source_polygons_20261104.py',
    'prepare_h5_full_stock_polygon_integer_20261104.py',
    'run_h5_full_stock_polygon_integer_20261104.py',
    'audit_h5_full_stock_polygon_integer_20261104.py',
    'build_h5_full_stock_polygon_model_20261104.py',
    'run_h5_full_stock_polygon_model_build_20261104.py',
    'finalize_h5_full_stock_polygon_budget_20261104.py',
    'audit_h5_full_stock_polygon_model_20261104.py',
    'check_h5_full_stock_polygon_candidate_20261104.py',
    'run_h5_full_stock_polygon_model_20261104.py']
for old in names:
    s=(O/old).read_text(encoding='utf-8')
    s=s.replace('full-stock','ranked-stock').replace('full_stock','ranked_stock')
    s=s.replace('h5-first57-broader-joint-capacities','h5-first57-all-broader-joint-capacities')
    s=s.replace('broader_joint_capacities_complete_process_seconds','all_broader_joint_capacities_complete_process_seconds')
    s=s.replace('[5,11,14]','[0,4,14]').replace('excluding5,11,14','excluding0,4,14')
    s=s.replace('prepare_h5_ranked_stock_polygon_model_helpers_20261104.py','prepare_h5_ranked_stock_polygon_helpers_20261104.py')
    # Key names inherited from the fixed full-stock mover ledger stay unchanged.
    s=s.replace("'ranked_stock_movers_complete_process_seconds'","'full_stock_movers_complete_process_seconds'")
    s=s.replace("'necessary_ranked_stock_cover_complete_process_seconds'","'necessary_full_stock_cover_complete_process_seconds'")
    if old=='audit_h5_full_stock_polygon_integer_20261104.py':
        s=s.replace("len(records)==len(expected)==178","len(records)==len(expected)>0").replace("'regions_verified':178","'regions_verified':len(records)")
    if old=='audit_h5_full_stock_polygon_model_20261104.py':
        s=s.replace("len(p.variables)==1696 and len(p.constraints)==6470 and mode_count==96 and links==640 and region_count==1424 and plane_count==5416 and geometry_links==80",
                    "len(p.variables)==272+8*len(regions) and len(p.constraints)==1054+8*sum(len(r['planes']) for r in regions) and mode_count==96 and links==640 and region_count==8*len(regions) and plane_count==8*sum(len(r['planes']) for r in regions) and geometry_links==80")
    if old=='prepare_h5_full_stock_source_polygons_20261104.py':
        s=s.replace('Select the nonexcluded broad cog choice with largest independently exact joint reachable area','Select from all259 surviving broad cog choices by largest independently exact joint reachable area')
    new=old.replace('full_stock','ranked_stock')
    with (O/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared distinct ranked choice [0,4,14], fresh source proofs, and full shared-alias model pipeline.')
