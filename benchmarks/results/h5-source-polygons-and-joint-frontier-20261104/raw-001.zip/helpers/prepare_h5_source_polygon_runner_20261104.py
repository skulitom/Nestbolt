from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_edge_single_choice_regions_20261104.py').read_text(encoding='utf-8').replace('h5-first57-edge-single-choice-regions-process','h5-first57-full-stock-source-polygons-process').replace('prepare_h5_edge_single_choice_regions','prepare_h5_full_stock_source_polygons')
with (O/'run_h5_full_stock_source_polygons_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
