from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_first57_top_insert_row_20261104.py').read_text(encoding='utf-8').replace('h5-first57-top-insert-row-process','h5-first57-full-stock-polygon-integer-process').replace('prepare_h5_first57_top_insert_row','prepare_h5_full_stock_polygon_integer')
with (O/'run_h5_full_stock_polygon_integer_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
