from pathlib import Path
O=Path(__file__).resolve().parent
for old,new in [
    ('prepare_h5_broader_joint_capacities_20261104.py','prepare_h5_all_broader_joint_capacities_20261104.py'),
    ('audit_h5_broader_joint_capacities_20261104.py','audit_h5_all_broader_joint_capacities_20261104.py'),
    ('run_h5_broader_joint_capacities_20261104.py','run_h5_all_broader_joint_capacities_20261104.py')]:
    s=(O/old).read_text(encoding='utf-8')
    s=s.replace('h5-first57-broader-joint-capacities','h5-first57-all-broader-joint-capacities')
    s=s.replace('prepare_h5_broader_joint_capacities_20261104.py','prepare_h5_all_broader_joint_capacities_20261104.py')
    s=s.replace('both largest-capacity fixed29 cog selections','all259 surviving fixed29 cog selections')
    s=s.replace('For each of the two largest-capacity three-empty cog choices','For each of all259 surviving three-empty cog choices')
    s=s.replace('No prior bracket capacity result is used.','The prior exact bracket-only capacity proof selects all259 survivors from455; no prior positive construction or solver response is used.')
    s=s.replace("largest=max(r['bracket_capacity'] for r in retained)\nselected=[r['empty_sites'] for r in retained if r['bracket_capacity']==largest]\nassert largest==12 and selected==[[5,11,13],[5,11,14]]","selected=[r['empty_sites'] for r in retained]\nassert len(selected)==len(set(map(tuple,selected)))==259")
    s=s.replace('len(actual)==2','len(actual)==259').replace('range(2)]+','range(259)]+')
    s=s.replace("'choices':2","'choices':259").replace("'choices_verified':2","'choices_verified':259")
    s=s.replace("'preparation_cap_seconds':25,'maximum_process_seconds':35","'preparation_cap_seconds':35,'maximum_process_seconds':45")
    s=s.replace('time.perf_counter()-started<25','time.perf_counter()-started<35')
    if old.startswith('run_'):
        s=s.replace('35','45')
    with (O/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared exhaustive joint bounds for all259 existing fixed29 survivors; no placement solver.')
