from pathlib import Path
O=Path(__file__).resolve().parent
def save(name,s):
    with (O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def common(s):
    return s.replace('h5-first57-broader-positive-regions','h5-first57-full-stock-polygon-integer').replace('h5-first57-broader-positive-model-process','h5-first57-full-stock-polygon-model-process').replace("BASE/'audit","BASE/'geometry-audit").replace("BASE / 'audit","BASE / 'geometry-audit").replace("'audit/","'geometry-audit/")
process_old="'broader_positive_regions_complete_process_seconds':'h5-first57-full-stock-polygon-integer-process-20261104'"
process_new="'full_stock_source_polygons_complete_process_seconds':'h5-first57-full-stock-source-polygons-process-20261104',\n    'full_stock_polygon_integer_complete_process_seconds':'h5-first57-full-stock-polygon-integer-process-20261104'"
s=common((O/'build_h5_broader_positive_model_20261104.py').read_text(encoding='utf-8'))
s=s.replace(process_old,process_new)
start=s.index('# All original bracket')
end=s.index('components=[];',start)
s=s[:start]+'''# One region per normalized geometry; original mode selectors remain separate.
for owner in owners:
    geometry_ids=sorted({m['normalized_geometry'] for m in owner['modes']})
    owner['assigned_group']=None;owner['regions']=[]
    for ri,r in enumerate(regions):
        if r['geometry'] not in geometry_ids:continue
        selector=model.new_bool_var(f'region_{owner["owner"]}_{ri}').index
        cts=[linear(dict(zip(owner['positions'],p['coefficients'])),cp_model.INT_MIN,p['upper'],selector) for p in r['planes']]
        owner['regions'].append({'region':ri,'selector':selector,'constraints':cts})
    owner['region_geometry_constraints']=[]
    for gid in geometry_ids:
        co={r['selector']:1 for r in owner['regions'] if regions[r['region']]['geometry']==gid}
        co.update({m['selector']:-1 for m in owner['modes'] if m['normalized_geometry']==gid})
        owner['region_geometry_constraints'].append({'geometry':gid,'constraint':linear(co,0,0)})
'''+s[end:]
s=s.replace("ROOT/'output/prepare_h5_broader_model_helpers_20261104.py',ROOT/'output/build_h5_first57_edge_model_20261104.py'","ROOT/'output/prepare_h5_full_stock_polygon_model_helpers_20261104.py',ROOT/'output/build_h5_broader_positive_model_20261104.py'")
a=s.index("'method':");b=s.index("\n    'algorithm_seconds'",a)
s=s[:a]+"""'method':'Fresh full-stock original-source polygon construction with all8 brackets and8 inserts movable and12 cog poses excluding5,11,14. Every owner selects exactly one original legal mode and one region for its normalized geometry. All original mode stock constraints remain explicit. Each region applies every independently audited inward integer halfplane. Alias sharing is valid only because every region was separately certified against every original source mode. All24 component rectangles remain rigidly linked and16 moving-pair groups cover every268 different-owner component pair. Same-family X ordering only relabels identical copies. The ledger includes upstream selection, failed insert control, fresh source polygons, integer preparation and complete model build. No closed model response, assignment, old positive rectangle regions or hints are consumed.',"""+s[b:]
save('build_h5_full_stock_polygon_model_20261104.py',s)

s=common((O/'audit_h5_broader_positive_model_20261104.py').read_text(encoding='utf-8')).replace(process_old,process_new)
a=s.index('region_count=0;');b=s.index("assert counts==",a)
s=s[:a]+'''region_count=0;plane_count=0;geometry_links=0;counts={'bracket':0,'insert':0}
for o in mapping['owners']:
    family=o['identity'][0];assert o['assigned_group'] is None;counts[family]+=1
    gids=sorted({m['normalized_geometry'] for m in modes[family]})
    expected=[i for i,r in enumerate(regions) if r['geometry'] in gids]
    assert [r['region'] for r in o['regions']]==expected
    for r in o['regions']:
        ri=r['region'];source=regions[ri];v=r['selector']
        variable(v,f'region_{o["owner"]}_{ri}',[0,1])
        assert len(r['constraints'])==len(source['planes'])
        for ct,plane in zip(r['constraints'],source['planes']):
            linear(ct,{o['positions'][0]:plane['coefficients'][0],o['positions'][1]:plane['coefficients'][1]},MIN,plane['upper'],v)
            plane_count+=1
        region_count+=1
    assert [g['geometry'] for g in o['region_geometry_constraints']]==gids
    for row in o['region_geometry_constraints']:
        gid=row['geometry']
        co={r['selector']:1 for r in o['regions'] if regions[r['region']]['geometry']==gid}
        for m in o['modes']:
            if m['normalized_geometry']==gid:co[m['selector']]=-1
        linear(row['constraint'],co,0,0);geometry_links+=1
'''+s[b:]
s=s.replace("len(p.variables)==7672 and len(p.constraints)==15870 and mode_count==96 and links==640 and region_count==7400","len(p.variables)==1696 and len(p.constraints)==6470 and mode_count==96 and links==640 and region_count==1424 and plane_count==5416 and geometry_links==80")
s=s.replace("ROOT/'output/prepare_h5_broader_model_auditor_20261104.py',ROOT/'output/audit_h5_first57_edge_model_20261104.py'","ROOT/'output/prepare_h5_full_stock_polygon_model_helpers_20261104.py',ROOT/'output/audit_h5_broader_positive_model_20261104.py'")
s=s.replace("Each owner has exactly one legal mode and exactly one positive region for that mode. Region bounds imply separation from every fixed source.","Each owner has exactly one original legal mode and exactly one region shared by aliases of that normalized geometry. All677 independently inward-rounded halfplanes are applied per owner, with original mode stock bounds retained. Every alias is separately source-certified.")
s=s.replace("'positive_region_selectors_verified':region_count,","'positive_region_selectors_verified':region_count,'integer_plane_constraints_verified':plane_count,'geometry_alias_equations_verified':geometry_links,")
save('audit_h5_full_stock_polygon_model_20261104.py',s)

for old,new in [
    ('run_h5_broader_positive_model_build_20261104.py','run_h5_full_stock_polygon_model_build_20261104.py'),
    ('finalize_h5_broader_positive_budget_20261104.py','finalize_h5_full_stock_polygon_budget_20261104.py'),
    ('check_h5_broader_positive_candidate_20261104.py','check_h5_full_stock_polygon_candidate_20261104.py'),
    ('run_h5_broader_positive_model_20261104.py','run_h5_full_stock_polygon_model_20261104.py')]:
    s=common((O/old).read_text(encoding='utf-8'))
    s=s.replace('build_h5_broader_positive_model_20261104.py','build_h5_full_stock_polygon_model_20261104.py')
    s=s.replace('check_h5_broader_positive_candidate_20261104.py','check_h5_full_stock_polygon_candidate_20261104.py')
    save(new,s)
print('Fresh polygon model builder, exhaustive auditor, single-call runner and source66 reader written.')
