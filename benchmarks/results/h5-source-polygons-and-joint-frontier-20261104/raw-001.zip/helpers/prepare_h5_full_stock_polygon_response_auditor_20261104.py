from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_broader_positive_response_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-broader-positive-regions','h5-first57-full-stock-polygon-integer').replace('h5-first57-broader-positive-model-process','h5-first57-full-stock-polygon-model-process')
s=s.replace("BASE/'audit","BASE/'geometry-audit").replace("['audit','model-audit']","['geometry-audit','model-audit']")
s=s.replace("ROOT/'output/h5-first57-full-stock-polygon-integer-process-20261104/opened.json',","ROOT/'output/h5-first57-full-stock-polygon-integer-process-20261104/opened.json',\n    ROOT/'output/h5-first57-full-stock-source-polygons-process-20261104/opened.json',")
s=s.replace("('h5-first57-full-stock-polygon-integer-process-20261104','broader_positive_regions_complete_process_seconds'),","('h5-first57-full-stock-source-polygons-process-20261104','full_stock_source_polygons_complete_process_seconds'),\n    ('h5-first57-full-stock-polygon-integer-process-20261104','full_stock_polygon_integer_complete_process_seconds'),")
s=s.replace('7672','1696').replace('15870','6470').replace('59063','14524').replace('3721','1196')
s=s.replace("assert load(BASE/'geometry-audit/checks.json')['source_valid41'] and load(BASE/'geometry-audit/checks.json')['remaining_movers']==16","assert load(BASE/'geometry-audit/checks.json')['all_source_aliases_preserved']\nassert load(ROOT/'output/h5-first57-full-stock-source-polygons-20261104/source-region-audit/checks.json')['fixed_source41_valid']")
with (O/'audit_h5_full_stock_polygon_response_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Independent polygon response and recursive input/ledger auditor written.')
