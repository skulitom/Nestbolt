"""Independent protobuf reader for every old and added source-strip constraint."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_seeded_lazy_source_model import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-strip-model-20261026';OUT=BASE/'model-audit'
STRIPS=ROOT/'output/h5-cog-source-strips-20261026';GEO=ROOT/'output/h5-global-source-cells-20261026'
PRIOR=ROOT/'output/h5-seeded-lazy-source-cuts-20261026/search/round-00'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
proto=cp_model_pb2.CpModelProto();proto.ParseFromString((BASE/'model.pb').read_bytes())
old=cp_model_pb2.CpModelProto();old.ParseFromString((PRIOR/'model.pb').read_bytes())
prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(proto);del prefix.constraints[len(old.constraints):]
assert prefix==old and prefix.SerializeToString()==old.SerializeToString()
ds=load(GEO/'domains.json');mapping=load(BASE/'mapping.json')
original=verify(prefix,ds,load(GEO/'pairs.json'),load(GEO/'inner-rectangles/rectangles.json'),
    load(GEO/'inner-rectangles/identical-source-groups.json'),load(PRIOR/'request.json')['pair_indices'],mapping)
rects=load(STRIPS/'rectangles.json');sm=load(BASE/'strip-mapping.json');ci=sm['base_constraints']
assert ci==len(old.constraints)==13246 and len(rects)==len(sm['rectangles'])==781
xs=[];ys=[]
def expr(e,var,offset):assert dict(zip(e.vars,e.coeffs))==({var:1} if var is not None else {}) and e.offset==offset
for k,(r,rec) in enumerate(zip(rects,sm['rectangles'])):
    assert rec=={'rectangle_index':k,'interval_indices':[ci,ci+1]}
    for axis,field in [(0,'width_um'),(1,'height_um')]:
        ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='interval' and not ct.enforcement_literal
        assert ct.name==f'source_strip_{"xy"[axis]}_{k}'
        var=mapping['coordinate_indices'][r['part_index']][axis];b=r['bounds_um'][axis];length=r[field]
        expr(ct.interval.start,var,b);expr(ct.interval.size,None,length);expr(ct.interval.end,var,b+length)
        (xs if axis==0 else ys).append(ci);ci+=1
assert sm['no_overlap_2d_constraint']==ci
ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='no_overlap_2d' and not ct.enforcement_literal
assert list(ct.no_overlap_2d.x_intervals)==xs and list(ct.no_overlap_2d.y_intervals)==ys;ci+=1
assert sm['cumulative_constraint_indices']==[ci,ci+1]
for intervals,field,capacity in [(xs,'height_um',2987000),(ys,'width_um',1487000)]:
    ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='cumulative' and not ct.enforcement_literal
    assert list(ct.cumulative.intervals)==intervals and len(ct.cumulative.demands)==len(rects)
    expr(ct.cumulative.capacity,None,capacity)
    for demand,r in zip(ct.cumulative.demands,rects):expr(demand,None,r[field])
    ci+=1
assert ci==len(proto.constraints)==14811 and len(proto.variables)==3880
write(OUT/'checks.json',{**original,'passed':True,'seconds':time.perf_counter()-start,
    'all57_required':True,'prior_model_preserved_byte_exact':True,'prior_constraints_verified':13246,
    'constraints_verified':ci,'added_constraints_verified':1565,'added_rectangles_verified':781,
    'cog_strips_verified':728,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
