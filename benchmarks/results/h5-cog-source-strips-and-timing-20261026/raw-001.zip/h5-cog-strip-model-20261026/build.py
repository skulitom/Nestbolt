"""Strengthen the closed seeded model with independently verified source strips."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog-strip-model-20261026'
STRIPS=ROOT/'output/h5-cog-source-strips-20261026'
PRIOR=ROOT/'output/h5-seeded-lazy-source-cuts-20261026/search/round-00'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(STRIPS/'source-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
inputs={p.relative_to(ROOT).as_posix():digest(p) for p in STRIPS.rglob('*') if p.is_file()}
for p in [PRIOR/'model.pb',PRIOR/'model.pbtxt',PRIOR/'mapping.json',
          PRIOR/'model-checks.json',ROOT/'output/h5-seeded-lazy-source-cuts-20261026/result-audit/checks.json']:
    inputs[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,
    'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'retry_permitted':False,
    'all57_first_originals_required':True,'all9_short_originals_fixed':True,'fixed_first_originals':0,
    'method':'The previous seeded call remains CLOSED. Construct a different model by retaining every serialized prior constraint and adding a second necessary NoOverlap2D and two cumulative constraints on781 disjoint source-contained rectangles, including728 cog strips. The prior65-rectangle system and38 detailed source-pair disjunctions remain. Thus the new model strictly strengthens the old necessary geometry and excludes its direct invalid witness. Preserve90 non-cog hints and entire-stock domains; no position is fixed. One new60-second solve within90 shared seconds. Any returned66-part candidate must be independently read from original source rings before a native check. UNKNOWN, infeasible finite subset, or invalid source assignment do not imply unrestricted impossibility or H5 success.'})
model=cp_model.CpModel();assert model.proto.parse_text_format((PRIOR/'model.pbtxt').read_text(encoding='utf-8'))
mapping=load(PRIOR/'mapping.json');base_count=len(model.proto.constraints)
assert base_count==13246 and len(model.proto.variables)==3880
rects=load(STRIPS/'rectangles.json');xi=[];yi=[];new=[]
for k,r in enumerate(rects):
    idx=r['part_index'];xv,yv=[model.get_int_var_from_proto_index(v) for v in mapping['coordinate_indices'][idx]]
    x=model.new_fixed_size_interval_var(xv+r['bounds_um'][0],r['width_um'],f'source_strip_x_{k}')
    y=model.new_fixed_size_interval_var(yv+r['bounds_um'][1],r['height_um'],f'source_strip_y_{k}')
    xi.append(x);yi.append(y);new.append({'rectangle_index':k,'interval_indices':[x.index,y.index]})
overlap=model.add_no_overlap_2d(xi,yi)
cx=model.add_cumulative(xi,[r['height_um'] for r in rects],2987000)
cy=model.add_cumulative(yi,[r['width_um'] for r in rects],1487000)
assert model.validate()==''
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',mapping)
write(OUT/'strip-mapping.json',{'base_constraints':base_count,'rectangles':new,
      'no_overlap_2d_constraint':overlap.index,'cumulative_constraint_indices':[cx.index,cy.index]})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),
    'constraints':len(model.proto.constraints),'prior_constraints_unchanged':base_count,
    'additional_constraints':len(model.proto.constraints)-base_count,'additional_rectangles':len(rects),
    'cog_strips':728,'whole_stock_coordinate_variables':114,'hints':90,'all57_required':True,
    'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
