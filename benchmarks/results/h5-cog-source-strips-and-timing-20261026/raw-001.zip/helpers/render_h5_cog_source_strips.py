"""Render the verified strip coverage from the original cog source ring."""
from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-source-strips-20261026'
load=lambda p:json.loads(p.read_bytes())
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json')
outer=next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer']
modes=load(ROOT/'output/h5-legacy57-sliding-source-20261026/modes.json')
strips=load(BASE/'mode-strips.json');summary=load(BASE/'prepared.json')['mode_summary']
fig,axes=plt.subplots(1,2,figsize=(9,5))
fig.subplots_adjust(left=.08,right=.98,bottom=.19,top=.81,wspace=.25)
for ax,entry in zip(axes,summary):
    m=modes[entry['mode']];c,s=math.cos(m['angle']),math.sin(m['angle']);tx,ty=m['source_translation_offset']
    points=[(x*c-y*s+tx,x*s+y*c+ty) for x,y in outer]
    ax.add_patch(Polygon(points,facecolor='#dce5ec',edgecolor='#233848',linewidth=1))
    for r in strips[str(entry['mode'])]:
        x,y,z,w=[v/1000 for v in r['bounds_um']]
        ax.add_patch(Rectangle((x,y),z-x,w-y,facecolor='#187b91',edgecolor='white',linewidth=.3))
    ax.set(xlim=(-145,145),ylim=(-145,145),aspect='equal',xlabel='mm',ylabel='mm',
           title=f"Source mode {entry['mode']}: {entry['strips']} strips\n{entry['source_area_fraction']:.1%} of filled outline")
    ax.spines[['top','right']].set_visible(False)
fig.suptitle('Cog geometry used by the stronger necessary model',fontsize=13,y=.96)
fig.text(.5,.055,'Blue: verified source-contained strips. Pale: remaining outline.\nHoles stay reserved with part-in-hole off.',ha='center',fontsize=9)
fig.savefig(BASE/'source-strips.png',dpi=150)
print('Saved source strip coverage figure.')
