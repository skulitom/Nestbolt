"""Verify source strips from original rings and inspect the known necessary witness."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json, math, shutil, time
from shapely.geometry import Polygon,box
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-cog-source-strips-20261026';OUT=BASE/'source-audit'
GEO=ROOT/'output/h5-global-source-cells-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json')
parts={p['id']:p for p in job['parts']};ds=load(GEO/'domains.json')
modes=load(ROOT/'output/h5-legacy57-sliding-source-20261026/modes.json')
records=load(BASE/'rectangles.json');old=load(GEO/'inner-rectangles/rectangles.json')
assert [r for r in records if r['family']!='cog']==[r for r in old if r['family']!='cog']
owned={};source={};corner_checks=0
for r in records:
    i=r['part_index'];d=ds[i];m=modes[d['mode']]
    assert r['original']==d['original'] and r['family']==d['family'] and r['mode']==d['mode']
    if i not in source:
        c,s=math.cos(m['angle']),math.sin(m['angle']);mi=-1 if m['mirrored'] else 1;tx,ty=m['source_translation_offset']
        source[i]=Polygon([(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in parts[d['family']]['geometry'][0]['outer']])
    b=r['bounds_um'];assert all(type(v) is int for v in b)
    assert r['width_um']==b[2]-b[0]>0 and r['height_um']==b[3]-b[1]>0
    rect=box(*[v/1000 for v in b]);assert source[i].covers(rect) and rect.difference(source[i]).is_empty
    owned.setdefault(i,[]).append(rect);corner_checks+=4
assert set(owned)==set(range(57))
same_pairs=0
for i,rects in owned.items():
    if ds[i]['family']=='cog':assert len(rects)>=32
    for a,b in combinations(rects,2):assert a.disjoint(b);same_pairs+=1
anchors=load(ROOT/'output/h5-constructed-necessary-source-seed-20261026/anchors-um.json')
overlaps=[];part_pairs=set();pair_checks=0
for (ri,a),(rj,b) in combinations(enumerate(records),2):
    if a['part_index']==b['part_index']:continue
    ai=anchors[a['part_index']];bi=anchors[b['part_index']]
    aa=[a['bounds_um'][k]+ai[k%2] for k in range(4)]
    bb=[b['bounds_um'][k]+bi[k%2] for k in range(4)]
    pair_checks+=1
    if min(aa[2],bb[2])>max(aa[0],bb[0]) and min(aa[3],bb[3])>max(aa[1],bb[1]):
        overlaps.append([ri,rj]);part_pairs.add(tuple(sorted([a['original'],b['original']])))
assert overlaps
areas={family:sum(r['width_um']*r['height_um'] for r in records if r['family']==family)/1e6 for family in parts}
write(OUT/'known-witness-strip-overlaps.json',{'rectangle_pairs':overlaps,'original_pairs':sorted(part_pairs)})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_verified':57,
    'rectangles_verified':len(records),'cog_rectangles_verified':sum(r['family']=='cog' for r in records),
    'same_original_disjoint_pairs_verified':same_pairs,'source_contains_whole_rectangles':True,
    'corner_count':corner_checks,'non_cog_rectangles_unchanged':True,'area_by_family_mm2':areas,
    'known_witness_cross_original_rectangle_pairs_checked':pair_checks,
    'known_witness_rectangle_overlaps':len(overlaps),'known_witness_original_pairs':len(part_pairs),
    'old_necessary_witness_rejected_by_new_geometry':True,
    'original_outer_filled_for_part_in_hole_off':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
