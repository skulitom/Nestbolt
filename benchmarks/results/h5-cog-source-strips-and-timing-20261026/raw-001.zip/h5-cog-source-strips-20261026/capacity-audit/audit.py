"""Independently sum every active source strip on every witness event slab."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-source-strips-20261026'
OUT=BASE/'capacity-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
paths=[BASE/'rectangles.json',BASE/'known-witness-strip-capacity.json',
       ROOT/'output/h5-constructed-necessary-source-seed-20261026/anchors-um.json']
rects,data,anchors=map(load,paths);checked=[]
for axis,field,cap in [(0,'height_um',2987000),(1,'width_um',1487000)]:
    intervals=[(r['bounds_um'][axis]+anchors[r['part_index']][axis],
                r['bounds_um'][axis+2]+anchors[r['part_index']][axis],r[field]) for r in rects]
    endpoints=sorted({x for lo,hi,d in intervals for x in [lo,hi]});bad=[];peak=0
    for a,b in zip(endpoints,endpoints[1:]):
        middle_twice=a+b
        demand=sum(d for lo,hi,d in intervals if 2*lo<=middle_twice<2*hi)
        peak=max(peak,demand)
        if demand>cap:bad.append({'from_um':a,'to_um':b,'demand_um':demand,'excess_um':demand-cap})
    assert data['xy'[axis]]=={'capacity_um':cap,'peak_demand_um':peak,'violating_intervals':bad,'events_checked':len(endpoints)}
    checked.append({'axis':'xy'[axis],'slabs_checked':len(endpoints)-1,'violating_slabs':len(bad),
                    'peak_demand_um':peak,'capacity_um':cap})
assert all(v['violating_slabs'] for v in checked)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,
    'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'axes':checked,
    'known_invalid_witness_rejected_by_both_cumulative_constraints':True,
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
