"""Construct disjoint integer rectangles within each actual transformed cog outline."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, math, shutil, time
from shapely.geometry import shape, LineString, box
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-cog-source-strips-20261026'
GEO=ROOT/'output/h5-global-source-cells-20261026'
MODES=ROOT/'output/h5-legacy57-sliding-source-20261026/modes.json'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[GEO/'domains.json',GEO/'inner-rectangles/rectangles.json',MODES,
        ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',
        ROOT/'output/h5-constructed-necessary-source-seed-20261026/anchors-um.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),
    'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'slices_per_source_mode':32,'preparation_budget_seconds':30,'solver_calls':0,
    'method':'Intersect horizontal source sections at every polygon-vertex height within each of32 uniform integer-micrometre Y bands and both band edges. Retain all common X intervals, round inward by1 micrometre, and directly require each rectangle covered by the actual transformed source filled outer polygon. Same-original bands are separated by2 micrometres. Keep the old65-rectangle model intact and propose an additional NoOverlap2D/cumulative system containing all53 non-cog rectangles and the new disjoint cog strips. All originals and full-stock coordinate domains remain mandatory. The strips are necessary occupied subsets, not complete source footprints. Independently verify original-ring containment and disjointness before solving.'})
ds=load(GEO/'domains.json');modes=load(MODES);old=load(GEO/'inner-rectangles/rectangles.json')
records=[r for r in old if r['family']!='cog'];by_mode={};mode_summary=[]
for mid in sorted({d['mode'] for d in ds if d['family']=='cog'}):
    g=shape(modes[mid]['geometry']);xmin,ymin,xmax,ymax=g.bounds
    low=math.ceil(ymin*1000);high=math.floor(ymax*1000)
    bounds=[low+(high-low)*i//32 for i in range(33)];strips=[]
    for band in range(32):
        lo,hi=bounds[band]+1,bounds[band+1]-1
        assert lo<hi
        knots=sorted({lo/1000,hi/1000,*[y for x,y in g.exterior.coords if lo/1000<y<hi/1000]})
        common=LineString([(xmin-1,0),(xmax+1,0)])
        for y in knots:
            section=g.intersection(LineString([(xmin-1,y),(xmax+1,y)]))
            def intervals(v):
                if v.geom_type=='LineString':
                    a,_,b,_=v.bounds
                    if a<b:yield LineString([(a,0),(b,0)])
                elif hasattr(v,'geoms'):
                    for child in v.geoms:yield from intervals(child)
            from shapely.ops import unary_union
            common=common.intersection(unary_union(list(intervals(section))))
        for piece in intervals(common):
            a,_,b,_=piece.bounds;left=math.ceil(a*1000)+1;right=math.floor(b*1000)-1
            if left>=right:continue
            r=box(left/1000,lo/1000,right/1000,hi/1000)
            assert g.covers(r) and r.difference(g).is_empty
            strips.append({'component':len(strips),'band':band,'bounds_um':[left,lo,right,hi],
                           'width_um':right-left,'height_um':hi-lo,'section_knots_checked':len(knots)})
    assert strips and time.perf_counter()-start<30
    by_mode[mid]=strips
    area=sum(r['width_um']*r['height_um'] for r in strips)/1e6
    mode_summary.append({'mode':mid,'strips':len(strips),'source_filled_outer_area_mm2':g.area,
                         'strip_area_mm2':area,'source_area_fraction':area/g.area})
for i,d in enumerate(ds):
    if d['family']=='cog':
        for r in by_mode[d['mode']]:records.append({'part_index':i,'original':d['original'],
            'family':d['family'],'mode':d['mode'],**r})
assert len({r['part_index'] for r in records})==57
write(OUT/'rectangles.json',records);write(OUT/'mode-strips.json',by_mode)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'all57_originals_represented':True,
    'non_cog_rectangles':53,'cog_rectangles':len(records)-53,'rectangles':len(records),
    'total_source_contained_area_mm2':sum(r['width_um']*r['height_um'] for r in records)/1e6,
    'old65_rectangle_area_mm2':sum(r['width_um']*r['height_um'] for r in old)/1e6,
    'mode_summary':mode_summary,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
