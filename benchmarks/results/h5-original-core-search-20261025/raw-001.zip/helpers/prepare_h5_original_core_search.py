from pathlib import Path
R=Path(__file__).resolve().parent
OLD='output/h5-full-cog-coordinates-20261025/shared-search';NEW='output/h5-original-core-search-20261025/shared-search'
CORE="ROOT/'output/h5-full-cog-coordinates-20261025/original-core-relaxation'"
def save(n,s):
    with (R/n).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'audit_h5_full_cog_master.py').read_text(encoding='utf-8')
s=s.replace('from audit_h5_cog_capacity_master import verify as verify_base','from audit_h5_added_guarded_pairs_master import verify as verify_base')
s=s.replace('regional,atlas,mutual):','regional,atlas,mutual,added):').replace('certificate,pairs,capacity,regional);','certificate,pairs,capacity,regional,added);')
s=s.replace('complete_original_cog_faces_per_pair','complete_necessary_original_core_faces_per_pair').replace('retained_full_original_pieces_per_pair','retained_necessary_original_core_pieces_per_pair').replace('original_cog_separation_direction_variables','necessary_original_core_direction_variables')
s=s.replace("'all_other_original_part_coordinates_still_require_validation':True","'full_guarded_original_coordinates_for_all_parts_still_required':True")
save('audit_h5_original_core_master.py',s)
s=(R/'solve_h5_full_cog_master.py').read_text(encoding='utf-8').replace(OLD,NEW).replace('from audit_h5_full_cog_master import verify','from audit_h5_original_core_master import verify')
old="    fullpath=ROOT/'output/h5-full-cog-coordinates-20261025';assert load(fullpath/'audit/checks.json')['passed'];atlas=load(fullpath/'atlas.json');mutual=load(SOURCE/'mutual/081.json')"
new="    fullpath=ROOT/'output/h5-original-core-search-20261025';corepath="+CORE+";assert load(fullpath/'audit/checks.json')['passed'] and load(corepath/'audit/checks.json')['passed'];atlas=load(fullpath/'atlas.json');mutual=load(corepath/'pieces.json');added=load(fullpath/'added-pairs.json')"
assert old in s;s=s.replace(old,new)
s=s.replace("ROOT/'output/audit_h5_full_cog_master.py',fullpath/'atlas.json',fullpath/'audit/checks.json',SOURCE/'mutual/081.json'","ROOT/'output/audit_h5_original_core_master.py',fullpath/'atlas.json',fullpath/'audit/checks.json',corepath/'pieces.json',corepath/'audit/checks.json',fullpath/'added-pairs.json'")
needle='    cog_positions=[]'
extra="""    for i,j in combinations(regional['applicable_cog_parts'],2):
        for row in added['pairs']:
            a=next(q for q in parts[i]['modes'] if q['query']==row['query']);b=next(q for q in parts[j]['modes'] if q['query']==row['query']);ia,ib=row['domain_rows']
            model.add_bool_or([vs[a['domains'][ia]].Not(),vs[b['domains'][ib]].Not()])
"""
assert s.count(needle)==1;s=s.replace(needle,extra+needle)
s=s.replace('certificate,pair_exclusions,capacity,regional,atlas,mutual);','certificate,pair_exclusions,capacity,regional,atlas,mutual,added);')
s=s.replace("'max_time_in_seconds':60","'max_time_in_seconds':45").replace("-time.perf_counter()-0.25","-time.perf_counter()-2.0").replace("params['max_time_in_seconds']=min(60,remaining)","params['max_time_in_seconds']=min(45,remaining)")
a=s.index("        'method':'");b=s.index("'})",a)
s=s[:a]+"        'method':'Keep every original mandatory part, domain choice, area charge, prior pair and occupancy constraint. Add all130 new nonduplicate guarded cog-domain exclusions across all15 physical pairs. Bind12 simultaneous cog anchors to selected complete inward domains and explicit query boxes. For each same-sheet pair require separation outside every piece of the complete previously certified RAW ORIGINAL cog collision core, using independently audited NECESSARY rounding (floor exact edge bound minus error). This preserves tooth geometry but is a preliminary relaxation, not positive-clearance acceptance. Independently reconstruct every protobuf field before at most one45-second master call inside a parent60-second pipeline, reserving2 seconds for solver shutdown and time for complete guarded-coordinate validation. No retries, seed changes or extension of previous runs. Any positive still needs the full guarded66-original and native/H5 checks."+s[b:]
s=s.replace('A feasible assignment has full-original cog anchors but still requires full-coordinate validation of all remaining originals','A feasible assignment has necessary original-core cog anchors only and still requires full guarded-coordinate validation of every original')
save('solve_h5_original_core_master.py',s)
s=(R/'audit_h5_full_cog_selection.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace("    write(OUT/'plan.json',","    inputs.extend([ROOT/'output/h5-original-core-search-20261025/added-pairs.json',"+CORE+"/'pieces.json',"+CORE+"/'audit/checks.json'])\n    write(OUT/'plan.json',")
s=s.replace("mutual=load(SOURCE/'mutual/081.json');inside=piecechecks=0","mutual=load("+CORE+"/'pieces.json');inside=piecechecks=0")
s=s.replace("write(OUT/'full-original-cog-check.json'","write(OUT/'necessary-original-core-check.json'").replace("'complete_original_forbidden_piece_checks'","'complete_necessary_core_piece_checks'")
needle="    positions=load(NEW/'solve/necessary-cog-positions.json');"
extra="""    added=load(ROOT/'output/h5-original-core-search-20261025/added-pairs.json');new_checks=0
    for a,b in combinations([p for p in parts if p['family']=='cog'],2):
        for row in added['pairs']:
            assert not (a['query']==b['query']==row['query'] and [a['domain_row'],b['domain_row']]==row['domain_rows']);new_checks+=1
    write(OUT/'new-guarded-pairs-check.json',{'passed':True,'physical_clauses_checked':new_checks})
"""
assert needle in s;s=s.replace(needle,extra+needle)
save('audit_h5_original_core_selection.py',s)
s=(R/'solve_h5_full_cog_anchors.py').read_text(encoding='utf-8').replace(OLD,NEW).replace('full-original-cog-check.json','necessary-original-core-check.json').replace("-time.perf_counter()-0.25","-time.perf_counter()-2.0")
s=s.replace("inputs=[BASE/'selection-audit/necessary-original-core-check.json'","inputs=[BASE/'selection-audit/new-guarded-pairs-check.json',BASE/'selection-audit/necessary-original-core-check.json'")
save('solve_h5_original_core_anchors.py',s)
s=(R/'run_h5_full_cog_search.py').read_text(encoding='utf-8').replace("BASE=ROOT/'output/h5-full-cog-coordinates-20261025'","BASE=ROOT/'output/h5-original-core-search-20261025'")
s=s.replace('solve_h5_full_cog_master.py','solve_h5_original_core_master.py').replace('audit_h5_full_cog_selection.py','audit_h5_original_core_selection.py').replace('solve_h5_full_cog_anchors.py','solve_h5_original_core_anchors.py')
s=s.replace("'maximum_master_solver_calls':1","'master_solver_cap_seconds':45,'solver_shutdown_reserve_seconds':2,'maximum_master_solver_calls':1")
s=s.replace("BASE/'atlas.json',BASE/'audit/checks.json'","BASE/'atlas.json',BASE/'audit/checks.json',BASE/'added-pairs.json'")
s=s.replace('timeout=remaining+2','timeout=max(0.01,remaining)')
s=s.replace('every full-original cog collision piece','every necessarily rounded original-cog core piece and all new guarded domain-pair exclusions')
s=s.replace('at most one master call','at most one master call capped at45 seconds with2 seconds shutdown reserve')
save('run_h5_original_core_search.py',s)
print('Prepared original-outline core pipeline: master <=45s, total shared60s,2s shutdown reserve.')
