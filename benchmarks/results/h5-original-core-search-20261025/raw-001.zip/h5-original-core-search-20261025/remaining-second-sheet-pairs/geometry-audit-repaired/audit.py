"""Rebuild each two-cog witness from the original job polygons and fixed source."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,shape,Point
from shapely.affinity import affine_transform,translate
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-original-core-search-20261025/remaining-second-sheet-pairs'
SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
FIXED=ROOT/'output/h5-guarded-source-adjustment-20261025/audit/adjusted-fixed-originals.json'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
OUT=BASE/'geometry-audit-repaired'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    paths=[BASE/'audit/checks.json',BASE/'audit/verified-pair-witnesses.json',SOURCE/'profiles.json',SOURCE/'plan.json',SOURCE/'mutual/081.json',SRC/'geometry.json',SRC/'items.json',FIXED,JOB,
        BASE/'geometry-audit/audit.py',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/failure-record.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},
        'method':'Rebuild each of the five two-cog candidates from the original job outer polygon and the exact source-angle transform. Compare the profile reconstruction, all moving/fixed same-sheet pairs, the mutual original pair, full raw/guarded no-fit polygons and all eight moving stock edges. Keep the unchanged native clearance and stock guards. This checks only two moving originals against the previously audited fixed57; seven mandatory moving originals remain absent, so it cannot qualify a full layout or trigger native validation.'})
    assert load(paths[0])['passed'];witnesses=load(paths[1]);profile=load(paths[2])[9];spec=load(paths[3]);mutual=load(paths[4]);job=load(JOB);fixed=load(FIXED)
    family=next(p for p in job['parts'] if p['id']=='cog');original=Polygon(family['geometry'][0]['outer'])
    stocks=[[float(Fraction(*v)) for v in b] for b in load(SRC/'geometry.json')['stock_bounds_rational']]
    guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05)
    records=[];allgaps=[];allmargins=[];maxerror=0
    assert len(fixed)==57 and len(witnesses)==5
    for w in witnesses:
        moving=[];polygons=[]
        for p in w['positions']:
            assert p['sheet']==1 and p['profile']==9
            x,y=p['x_units']/1000,p['y_units']/1000;angle=profile['rotation_radians'];assert not profile['mirrored']
            c,s=math.cos(angle),math.sin(angle);cx,cy=profile['original_center'];tx=x-c*cx+s*cy;ty=y-s*cx-c*cy
            poly=affine_transform(original,[c,-s,s,c,tx,ty]);expected=translate(shape(profile['geometry']),x,y)
            error=poly.hausdorff_distance(expected);assert error<1e-7;maxerror=max(maxerror,error)
            polygons.append(poly);b=poly.bounds;stock=stocks[1];margins=[b[0]-stock[0],b[1]-stock[1],stock[2]-b[2],stock[3]-b[3]]
            assert min(margins)>=guard;allmargins.extend(margins)
            moving.append({'part':p['part'],'item':spec['parts'][p['part']]['index'],'transform':{'rotation_radians':angle,'translation':[tx,ty],'mirrored':False},'extra_stock_margins_mm':margins,'reconstruction_error_mm':error})
        pairchecks=[]
        for i,poly in enumerate(polygons):
            for f in fixed:
                if f['sheet']!=1:continue
                other=shape(f['geometry']);gap=poly.distance(other);area=poly.intersection(other).area
                assert area==0 and gap>=required;allgaps.append(gap)
                pairchecks.append({'moving_part':moving[i]['part'],'fixed_item':f['item'],'gap_mm':gap,'intersection_area_mm2':area})
        gap=polygons[0].distance(polygons[1]);area=polygons[0].intersection(polygons[1]).area
        assert area==0 and gap>=required;allgaps.append(gap)
        a,b=w['positions'];delta=Point((b['x_units']-a['x_units'])/1000,(b['y_units']-a['y_units'])/1000)
        assert not shape(mutual['raw_forbidden']).covers(delta) and not shape(mutual['expanded_forbidden']).covers(delta)
        records.append({'case':w['case'],'domain_rows':w['domain_rows'],'moving_originals':moving,'moving_fixed_checks':pairchecks,'mutual_original_gap_mm':gap,'mutual_overlap_area_mm2':area,'outside_raw_and_guarded_no_fit_regions':True})
    write(OUT/'witness-checks.json',records)
    checks={'passed':True,'seconds':time.perf_counter()-start,'verified_two_cog_witnesses':5,'same_sheet_pair_checks':len(allgaps),'moving_stock_edge_checks':len(allmargins),
        'native_pair_guard_mm':required,'native_stock_guard_mm':guard,'minimum_original_gap_mm':min(allgaps),'minimum_extra_stock_margin_mm':min(allmargins),
        'maximum_original_profile_reconstruction_error_mm':maxerror,'all_original_shapes_and_source_angles_preserved':True,
        'prior_failed_audit_preserved':True,'repair':'Original item metadata uses index, not item; corrected the output identifier lookup. Geometry, witnesses, guards and solver records unchanged.',
        'seven_mandatory_moving_originals_not_in_these_subproblem_witnesses':True,'no_native_call':True,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    assert checks['seconds']<60;write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
