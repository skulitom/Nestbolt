"""One bounded diagnostic of all remaining second-sheet cog-domain pairs."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product
import json, time, shutil, sys, traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
from audit_h5_selected_anchor_model import verify

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-original-core-search-20261025'
SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
GUARDED=ROOT/'output/h5-full-cog-coordinates-20261025/guarded-cog-pairs'
PRIOR=ROOT/'output/h5-convex-domain-conflicts-20261025/second-sheet-pair-proofs/audit'
OUT=BASE/'remaining-second-sheet-pairs'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');start=time.perf_counter();deadline=start+60
    paths=[SOURCE/'plan.json',SOURCE/'queries/019.json',SOURCE/'mutual/081.json',SOURCE/'audit/checks.json',
        GUARDED/'cases/163.bin',GUARDED/'cases/163.json',GUARDED/'audit/checks.json',
        PRIOR/'certified-pair-exclusions.json',PRIOR/'checks.json',BASE/'search-audit/checks.json',ROOT/'output/audit_h5_selected_anchor_model.py']
    assert all(load(p)['passed'] for p in [paths[3],paths[6],paths[8],paths[9]])
    spec=load(paths[0]);query=load(paths[1]);mutual=load(paths[2]);domains=query['domains']
    raw=paths[4].read_bytes();assert digest(paths[4])==load(paths[5])['packed_sha256']
    old=load(paths[7])['domain_row_pairs']
    pairs=[[i,j] for i,j in product(range(32),repeat=2) if not raw[(i*32+j)//8]&(128>>((i*32+j)%8)) and [i,j] not in old]
    assert len(pairs)==15 and len(domains)==32
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':60,'per_pair_solver_cap_seconds':2,
        'maximum_solver_calls':15,'workers':8,'random_seed':0,'pairs':pairs,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},
        'method':'Examine all15 ordered query19 pairs remaining after the complete guarded conflict table and exact interval exclusions. Each two-cog diagnostic keeps both complete selected inward domains and all61 original guarded forbidden pieces. Exact rectangle projections may remove only unreachable outside edges or whole pieces already always separated. Reconstruct every model field with the independent selected-anchor oracle before at most one2-second/eight-worker/seed-zero call per pair, all construction/audits/solves sharing60 seconds with2 seconds reserved for shutdown. Retain UNKNOWN and every unvisited pair. Negative solver results alone are not independent certificates. A positive is only a two-cog subproblem witness: the other seven moving originals are not modeled and all66 originals remain required for H5. No acceptance, retry, extension or seed change.'})
    summaries=[];pending=[]
    for index,rows in enumerate(pairs):
        if time.perf_counter()>=deadline-2:pending=pairs[index:];break
        case=OUT/f'{index:03d}';case.mkdir();began=time.perf_counter();model=cp_model.CpModel();vs=[]
        def var(name,lo,hi):
            v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
        def linear(terms,lo,hi,en=()):
            c=model.add_linear_constraint(sum(vs[i]*a for i,a in terms),lo,hi)
            if en:c.only_enforce_if([vs[i] for i in en])
        selected=[];parts=[]
        for part,row in zip([3,4],rows):
            face=domains[row];a=face['coordinate_bounds'];b=spec['queries'][19]['anchor_bounds_units1000']
            box=[max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3])]
            p={'part':part,'query':19,'profile':9,'sheet':1,'domain_row':row,'domain_index':face['index']};selected.append(p)
            x=var(f'part{part}-x',box[0],box[2]);y=var(f'part{part}-y',box[1],box[3])
            for h in face['halfplanes']:linear([(x,h['a']),(y,h['b'])],cp_model.INT_MIN,h['bound'])
            parts.append({**p,'x':x,'y':y,'coordinate_bounds':box})
        a,b=parts;ba,bb=a['coordinate_bounds'],b['coordinate_bounds']
        rect=[bb[0]-ba[2],bb[1]-ba[3],bb[2]-ba[0],bb[3]-ba[1]];records=[]
        for face in mutual['faces']:
            edges=[]
            for ei,h in enumerate(face['outside_halfplanes']):
                values=[h['a']*x+h['b']*y for x,y in product([rect[0],rect[2]],[rect[1],rect[3]])]
                edges.append({'edge':ei,'minimum_projection':min(values),'maximum_projection':max(values),'always':min(values)>=h['bound'],'possible':max(values)>=h['bound']})
            dirs=[];always=any(e['always'] for e in edges)
            if not always:
                for e in edges:
                    if not e['possible']:continue
                    h=face['outside_halfplanes'][e['edge']];d=var(f"pair3-4-face{face['index']}-edge{e['edge']}",0,1);dirs.append(d)
                    linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],cp_model.INT_MAX,[d])
                model.add_bool_or([vs[d] for d in dirs])
            records.append({'face':face['index'],'edges':edges,'always_separated':always,'directions':dirs})
        mapping={'parts':parts,'pairs':[{'parts':[3,4],'case':81,'difference_bounds':rect,'faces':records}]}
        write(case/'mapping.json',mapping);write(case/'selected.json',selected)
        assert model.validate()=='' and model.export_to_file(str(case/'model.pb'))
        actual=cp_model_pb2.CpModelProto();actual.ParseFromString((case/'model.pb').read_bytes())
        expected,stats=verify(actual,spec,selected,{19:query},{81:mutual});assert expected==mapping
        # The generic oracle checks the exact model, but its descriptive counts refer to a nine-part caller.
        for key in ['mandatory_moving_originals','fixed_originals','required_originals']:stats.pop(key)
        stats.update({'modeled_original_cogs':2,'unmodeled_moving_originals':7,'source_fixed_originals':57,'H5_required_originals':66,'partial_diagnostic_only':True})
        remaining=deadline-time.perf_counter()-2
        if remaining<=0:pending=pairs[index:];write(case/'not-opened.json',{'shared_budget_exhausted':True});break
        solver=cp_model.CpSolver();params={'max_time_in_seconds':min(2,remaining),'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
        for k,v in params.items():setattr(solver.parameters,k,v)
        (case/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
        write(case/'model-audit.json',{'passed':True,**stats,'construction_and_audit_seconds':time.perf_counter()-began,'model_sha256':digest(case/'model.pb'),'parameters_sha256':digest(case/'parameters.pbtxt')})
        write(case/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':params['max_time_in_seconds']})
        with (case/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
            solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());solve_start=time.perf_counter();code=solver.solve(model);elapsed=time.perf_counter()-solve_start
        positive=code in [cp_model.OPTIMAL,cp_model.FEASIBLE]
        if positive:write(case/'positions.json',[{**p,'x_units':solver.value(vs[p['x']]),'y_units':solver.value(vs[p['y']])} for p in parts])
        result={'domain_rows':rows,'status':solver.status_name(code),'seconds':elapsed,'solver_calls':1,'has_two_cog_candidate':positive,'response_stats':solver.response_stats()}
        write(case/'result.json',result);summaries.append({k:v for k,v in result.items() if k!='response_stats'});print(summaries[-1],flush=True)
    write(OUT/'summary.json',summaries);write(OUT/'pending-pairs.json',pending)
    result={'seconds':time.perf_counter()-start,'planned_pairs':len(pairs),'completed_pairs':len(summaries),'pending_pairs':len(pending),
        'feasible_pairs':sum(r['has_two_cog_candidate'] for r in summaries),'infeasible_pairs':sum(r['status']=='INFEASIBLE' for r in summaries),
        'unknown_pairs':sum(r['status']=='UNKNOWN' for r in summaries),'solver_calls':len(summaries),'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
