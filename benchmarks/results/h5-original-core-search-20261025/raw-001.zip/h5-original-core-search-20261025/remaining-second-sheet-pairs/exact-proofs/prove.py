"""Bounded exact integer branch-and-interval certificates, with no solver calls."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,traceback
from prove_h5_second_sheet_domain_pairs import rules_for,prove
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-original-core-search-20261025/remaining-second-sheet-pairs'
SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
OUT=BASE/'exact-proofs'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();deadline=start+60
    inputs=[BASE/'plan.json',BASE/'result.json',BASE/'summary.json',SOURCE/'plan.json',SOURCE/'queries/019.json',SOURCE/'mutual/081.json',ROOT/'output/prove_h5_second_sheet_domain_pairs.py']
    cases=[(i,r['domain_rows']) for i,r in enumerate(load(BASE/'summary.json')) if r['status']=='INFEASIBLE']
    assert len(cases)==10
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_proof_seconds':60,'maximum_total_nodes':4000,'maximum_total_events':1000000,
        'maximum_passes_per_node':1000,'maximum_events_per_node':100000,'solver_calls':0,'cases':[{'case':i,'domain_rows':r} for i,r in cases],
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'For each of the ten solver-negative remaining query19 pairs, rebuild all source inward and full original guarded outside inequalities. Apply exact integer interval deductions. At a fixed point split its widest remaining integer interval at its midpoint into two disjoint children covering the full parent interval. Retain every event, split, contradiction, cap and pending node. Only a fully independently replayed tree with every leaf contradictory can certify a pair exclusion. Calls from previous runs remain closed; this is a new finite proof procedure, with no solver call and no unrestricted impossibility claim.'})
    domains=load(SOURCE/'queries/019.json')['domains'];query=load(SOURCE/'plan.json')['queries'][19];mutual=load(SOURCE/'mutual/081.json')
    total_nodes=total_events=0;summaries=[];pending_cases=[]
    for ci,(index,rows) in enumerate(cases):
        if time.perf_counter()>=deadline or total_nodes>=4000 or total_events>=1000000:pending_cases=cases[ci:];break
        dest=OUT/f'{index:03d}';dest.mkdir();rules=rules_for(rows,domains,query,mutual)
        nodes=[{'index':0,'initial_bounds':rules['initial_bounds']}];stack=[0];witnesses=[]
        while stack and time.perf_counter()<deadline and total_nodes<4000 and total_events<1000000:
            ni=stack.pop();node=nodes[ni];trace=prove({**rules,'initial_bounds':node['initial_bounds']},deadline)
            node['trace']=trace;total_nodes+=1;total_events+=len(trace['events'])
            if trace['status']=='FIXED_POINT':
                bounds=trace['final_bounds'];v=max(range(4),key=lambda v:bounds[v][1]-bounds[v][0]);lo,hi=bounds[v]
                if lo==hi:node['integer_witness']=[b[0] for b in bounds];witnesses.append(ni)
                else:
                    mid=(lo+hi)//2;children=[]
                    for side in [0,1]:
                        child=[b.copy() for b in bounds];child[v][1 if side==0 else 0]=mid if side==0 else mid+1
                        children.append(len(nodes));nodes.append({'index':len(nodes),'initial_bounds':child})
                    node['split']={'variable':v,'midpoint':mid,'children':children};stack.extend(reversed(children))
            elif trace['status']=='CAP':break
        closed=bool(nodes) and all('trace' in n and (n['trace']['status']=='CONTRADICTION' or 'split' in n) for n in nodes) and not witnesses
        write(dest/'tree.json',{'domain_rows':rows,'rules_initial_bounds':rules['initial_bounds'],'nodes':nodes,'pending_stack':stack,'integer_witness_nodes':witnesses})
        row={'case':index,'domain_rows':rows,'nodes':len(nodes),'visited_nodes':sum('trace' in n for n in nodes),
            'events':sum(len(n['trace']['events']) for n in nodes if 'trace' in n),'contradictory_leaves':sum(n.get('trace',{}).get('status')=='CONTRADICTION' for n in nodes),
            'branch_nodes':sum('split' in n for n in nodes),'complete_contradiction_tree':closed,'independent_replay_pending':True}
        summaries.append(row);write(dest/'result.json',row);print(row,flush=True)
        if not closed:pending_cases=cases[ci+1:];break
    write(OUT/'summary.json',summaries);write(OUT/'pending-cases.json',pending_cases)
    result={'seconds':time.perf_counter()-start,'planned_cases':10,'visited_cases':len(summaries),'complete_contradiction_trees':sum(r['complete_contradiction_tree'] for r in summaries),
        'pending_cases':len(pending_cases),'visited_nodes':total_nodes,'events':total_events,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
