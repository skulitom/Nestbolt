"""Independent model/witness checks and complete integer proof-tree replay."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction
from hashlib import sha256
from itertools import product
import json,math,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from audit_h5_selected_anchor_model import verify
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-original-core-search-20261025/remaining-second-sheet-pairs'
SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},
        'method':'Reconstruct every two-cog model and all rectangle reductions independently from source. Check actual parameters, statuses and exact integer positive witnesses against every source inward and all61 full guarded forbidden pieces. For each negative tree rebuild source rules independently, replay each bound update with rational floor/ceiling, verify each unit clause and contradiction, and verify that every binary split covers its full predecessor interval without gaps. Traverse all children with no orphan or reused node. Classify all1024 ordered domain pairs using prior independently certified exclusions, the new trees, and the five verified positive witnesses. This is only the fixed-source guarded integer subproblem, not full66-original acceptance.'})
    for path in [BASE/'plan.json',BASE/'exact-proofs/plan.json']:
        for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h
    spec=load(SOURCE/'plan.json');query=load(SOURCE/'queries/019.json');domains=query['domains'];mutual=load(SOURCE/'mutual/081.json')
    pairs=load(BASE/'plan.json')['pairs'];summary=load(BASE/'summary.json');result=load(BASE/'result.json')
    assert result['seconds']<=60 and len(pairs)==len(summary)==result['completed_pairs']==15 and not load(BASE/'pending-pairs.json')
    witnesses=[];negatives=[];events_total=nodes_total=leaves_total=splits_total=planes_total=pieces_total=0
    for index,rows in enumerate(pairs):
        case=BASE/f'{index:03d}';r=load(case/'result.json');a=load(case/'model-audit.json')
        assert a['passed'] and digest(case/'model.pb')==a['model_sha256'] and digest(case/'parameters.pbtxt')==a['parameters_sha256']
        actual=cp_model_pb2.CpModelProto();actual.ParseFromString((case/'model.pb').read_bytes())
        selected=load(case/'selected.json');expected,stats=verify(actual,spec,selected,{19:query},{81:mutual});assert expected==load(case/'mapping.json')
        assert [p['domain_row'] for p in selected]==rows and [p['part'] for p in selected]==[3,4]
        params=text_format.Parse((case/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
        assert params.max_time_in_seconds==load(case/'opened.json')['seconds_limit']==2 and params.num_search_workers==8 and params.random_seed==0
        assert r['solver_calls']==1 and r['domain_rows']==rows and r['seconds']<2
        assert summary[index]=={k:v for k,v in r.items() if k!='response_stats'}
        if r['has_two_cog_candidate']:
            assert r['status'] in ['OPTIMAL','FEASIBLE'];positions=load(case/'positions.json')
            for p,row in zip(positions,rows):
                assert isinstance(p['x_units'],int) and isinstance(p['y_units'],int)
                d=domains[row];b=d['coordinate_bounds'];s=spec['queries'][19]['anchor_bounds_units1000'];x,y=p['x_units'],p['y_units']
                assert max(b[0],s[0])<=x<=min(b[2],s[2]) and max(b[1],s[1])<=y<=min(b[3],s[3])
                for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];planes_total+=1
            dx=positions[1]['x_units']-positions[0]['x_units'];dy=positions[1]['y_units']-positions[0]['y_units']
            for f in mutual['faces']:
                assert any(h['a']*dx+h['b']*dy>=h['bound'] for h in f['outside_halfplanes']);pieces_total+=1
            witnesses.append({'case':index,'domain_rows':rows,'positions':positions})
            continue
        assert r['status']=='INFEASIBLE' and not (case/'positions.json').exists()
        tree=load(BASE/'exact-proofs'/f'{index:03d}'/'tree.json');tr=load(BASE/'exact-proofs'/f'{index:03d}'/'result.json')
        assert tree['domain_rows']==rows and tr['complete_contradiction_tree'] and not tree['pending_stack'] and not tree['integer_witness_nodes']
        initial=[];inward=[];clauses=[]
        for part,row in enumerate(rows):
            d=domains[row];b=d['coordinate_bounds'];s=spec['queries'][19]['anchor_bounds_units1000']
            initial.extend([[max(b[0],s[0]),min(b[2],s[2])],[max(b[1],s[1]),min(b[3],s[3])]])
            inward.extend([([(2*part,h['a']),(2*part+1,h['b'])],h['bound']) for h in d['halfplanes']])
        for f in mutual['faces']:clauses.append([([(2,h['a']),(0,-h['a']),(3,h['b']),(1,-h['b'])],h['bound']) for h in f['outside_halfplanes']])
        assert tree['rules_initial_bounds']==initial;nodes=tree['nodes'];stack=[(0,initial)];visited=set();leaf_count=split_count=event_count=0
        while stack:
            ni,required=stack.pop();assert ni not in visited;visited.add(ni);node=nodes[ni]
            assert node['index']==ni and node['initial_bounds']==required
            bounds=[b.copy() for b in required];trace=node['trace'];empty=None
            def limits(terms):
                values=[(c*bounds[v][0],c*bounds[v][1]) for v,c in terms]
                return sum(min(v) for v in values),sum(max(v) for v in values)
            for ei,event in enumerate(trace['events']):
                if event['kind']=='empty_clause':
                    assert all(limits(t)[1]<b for t,b in clauses[event['clause']]);empty={'kind':'empty_clause','clause':event['clause']}
                    assert ei==len(trace['events'])-1;continue
                assert event['kind']=='bound';reason=event['reason']
                if reason['kind']=='inward':terms,limit=inward[reason['rule']]
                else:
                    assert reason['kind']=='unit';clause=clauses[reason['clause']]
                    live=[i for i,(t,b) in enumerate(clause) if limits(t)[1]>=b];assert live==[reason['edge']]
                    terms,limit=clause[live[0]];terms=[(v,-c) for v,c in terms];limit=-limit
                v=event['variable'];c=next(c for w,c in terms if w==v);minimum=limits([(w,k) for w,k in terms if w!=v])[0]
                rational=Fraction(limit-minimum,c);side=1 if c>0 else 0;new=math.floor(rational) if c>0 else math.ceil(rational)
                assert event['side']==side and event['new']==new and event['old']==bounds[v][side]
                assert (new<bounds[v][1] if side else new>bounds[v][0]);bounds[v][side]=new
                if bounds[v][0]>bounds[v][1]:
                    empty={'kind':'empty_interval','variable':v,'interval':bounds[v].copy()};assert ei==len(trace['events'])-1
            event_count+=len(trace['events']);assert bounds==trace['final_bounds']
            if trace['status']=='CONTRADICTION':
                assert empty and empty==trace['contradiction'] and 'split' not in node;leaf_count+=1
            else:
                assert trace['status']=='FIXED_POINT' and empty is None and trace['contradiction'] is None
                split=node['split'];v=split['variable'];mid=split['midpoint'];children=split['children']
                assert len(children)==2 and children[0]!=children[1] and bounds[v][0]<=mid<bounds[v][1]
                left=[b.copy() for b in bounds];right=[b.copy() for b in bounds];left[v][1]=mid;right[v][0]=mid+1
                stack.extend([(children[0],left),(children[1],right)]);split_count+=1
        assert visited==set(range(len(nodes))) and leaf_count==split_count+1
        assert len(nodes)==tr['nodes']==tr['visited_nodes'] and event_count==tr['events'] and leaf_count==tr['contradictory_leaves'] and split_count==tr['branch_nodes']
        nodes_total+=len(nodes);events_total+=event_count;leaves_total+=leaf_count;splits_total+=split_count;negatives.append(rows)
    assert len(witnesses)==5 and len(negatives)==10
    proof_result=load(BASE/'exact-proofs/result.json');assert proof_result['seconds']<=60 and proof_result['visited_nodes']==nodes_total and proof_result['events']==events_total
    guarded=ROOT/'output/h5-full-cog-coordinates-20261025/guarded-cog-pairs/cases/163.bin';data=guarded.read_bytes()
    prior=load(ROOT/'output/h5-convex-domain-conflicts-20261025/second-sheet-pair-proofs/audit/certified-pair-exclusions.json')['domain_row_pairs']
    all_negative={(i,j) for i,j in product(range(32),repeat=2) if data[(i*32+j)//8]&(128>>((i*32+j)%8))}|set(map(tuple,prior))|set(map(tuple,negatives))
    all_positive={tuple(w['domain_rows']) for w in witnesses}
    assert len(all_negative)==1019 and not all_negative&all_positive and len(all_negative|all_positive)==1024
    write(OUT/'certified-new-exclusions.json',{'query':19,'domain_row_pairs':negatives,'scope':'Complete source guarded integer construction only; independently replayed binary interval trees.'})
    write(OUT/'verified-pair-witnesses.json',witnesses)
    write(OUT/'complete-pair-classification.json',{'query':19,'domain_count':32,'total_ordered_pairs':1024,'excluded_pairs':sorted(all_negative),'feasible_pairs':sorted(all_positive),'complete':True,'other_moving_originals_not_modeled':7})
    checks={'passed':True,'seconds':time.perf_counter()-start,'models_reconstructed':15,'actual_solver_calls':15,'all_calls_within_declared2_seconds':True,
        'five_exact_integer_pair_witnesses_verified':True,'positive_inward_halfplanes_checked':planes_total,'positive_full_guarded_piece_clauses_checked':pieces_total,
        'independent_negative_trees':10,'proof_nodes':nodes_total,'proof_events':events_total,'contradiction_leaves':leaves_total,'complete_binary_splits':splits_total,
        'all1024_domain_pairs_classified':True,'excluded_pairs':1019,'feasible_pairs':5,'new_nonduplicate_exclusions':10,'physical_clauses_across_all15_cog_pairs':150,
        'second_sheet_global_capacity_two_is_tight_for_this_subproblem':True,'no_solver_negative_used_without_independent_proof':True,
        'partial_diagnostic_only':True,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    assert checks['seconds']<120;write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
