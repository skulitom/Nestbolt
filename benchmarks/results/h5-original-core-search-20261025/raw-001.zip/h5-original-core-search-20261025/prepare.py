"""Exact projection inventory for the verified original-outline necessary core."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';PREV=ROOT/'output/h5-full-cog-coordinates-20261025';CORE=PREV/'original-core-relaxation';OUT=ROOT/'output/h5-original-core-search-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(CORE/'audit/checks.json')['passed'] and load(PREV/'guarded-cog-pairs/audit/checks.json')['passed']
    paths=[SOURCE/'plan.json',SOURCE/'queries/018.json',SOURCE/'queries/019.json',CORE/'pieces.json',CORE/'audit/checks.json',PREV/'guarded-cog-pairs/prior-interval-overlap.json',ROOT/'benchmarks/results/h5-full-cog-coordinates-20261025/raw-manifest.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_and_audit_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},
        'method':'Prepare all71 original collision-core pieces with their independently verified NECESSARY outside inequalities. Retain every piece except one proven always separated over both complete same-sheet anchor ranges; omit an edge only if its integer projection cannot reach the necessary bound on either sheet. Independently enumerate all four corners for every edge. Explicit active-query anchor boxes will guard each reduction. Preserve all130 newly certified nonduplicate guarded pair exclusions. Positive master results still require every original guarded collision/stock/native check.'})
    manifest=load(paths[-1]);known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    for p in paths[:4]:
        key='source-inputs/'+p.relative_to(ROOT).as_posix() if SOURCE in p.parents else p.relative_to(ROOT/'output').as_posix();assert digest(p)==known[key]
    data=load(CORE/'pieces.json');bounds={};diff={}
    for q in [18,19]:
        domains=load(SOURCE/'queries'/f'{q:03d}.json')['domains'];b=[min(d['coordinate_bounds'][k] for d in domains) if k<2 else max(d['coordinate_bounds'][k] for d in domains) for k in range(4)]
        bounds[str(q)]=b;diff[str(q)]=[b[0]-b[2],b[1]-b[3],b[2]-b[0],b[3]-b[1]]
    faces=[];checks=0
    for f in data['faces']:
        edges=[]
        for k,h in enumerate(f['outside_halfplanes']):
            values={q:[sum(min(c*lo,c*hi) for c,lo,hi in [(h['a'],r[0],r[2]),(h['b'],r[1],r[3])]),sum(max(c*lo,c*hi) for c,lo,hi in [(h['a'],r[0],r[2]),(h['b'],r[1],r[3])])] for q,r in diff.items()}
            for q,r in diff.items():
                corners=[h['a']*x+h['b']*y for x,y in product([r[0],r[2]],[r[1],r[3]])];assert [min(corners),max(corners)]==values[q];checks+=4
            edges.append({'edge':k,'sheet_query_projection_bounds':values,'always':all(v[0]>=h['bound'] for v in values.values()),'possible':any(v[1]>=h['bound'] for v in values.values())})
        always=any(e['always'] for e in edges);faces.append({'face':f['index'],'edges':edges,'always_separated':always,'possible_edges':[] if always else [e['edge'] for e in edges if e['possible']]})
    atlas={'queries':[18,19],'profile':9,'mutual_case':81,'query_anchor_bounds':bounds,'same_sheet_difference_bounds':diff,'faces':faces,'source_core_pieces_sha256':digest(CORE/'pieces.json'),'necessary_core_relaxation_only':True}
    write(OUT/'atlas.json',atlas);overlap=load(paths[5]);new=[{'query':r['query'],'domain_rows':pair} for r in overlap['cases'] for pair in r['new_ordered_pairs']]
    assert len(new)==130 and len({(r['query'],*r['domain_rows']) for r in new})==130;write(OUT/'added-pairs.json',{'pairs':new,'source_overlap_sha256':digest(paths[5])})
    result={'seconds':time.perf_counter()-start,'original_core_pieces':len(faces),'retained_core_pieces_per_pair':sum(not f['always_separated'] for f in faces),
        'retained_directions_per_pair':sum(len(f['possible_edges']) for f in faces),'exact_corner_projections_checked':checks,'additional_ordered_pairs':130,'physical_new_pair_clauses':1950,
        'solver_calls':0,'full_guarded_validation_still_required':True,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);(OUT/'audit').mkdir();write(OUT/'audit/checks.json',{'passed':True,**result});print(result,flush=True)
if __name__=='__main__':main()
