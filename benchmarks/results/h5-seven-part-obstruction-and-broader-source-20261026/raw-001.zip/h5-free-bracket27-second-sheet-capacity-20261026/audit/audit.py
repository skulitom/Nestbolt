"""Independent disk containment and integer-bin capacity verification; no solver."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil,traceback
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free-bracket27-second-sheet-capacity-20261026';SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    paths=[BASE/n for n in ['plan.json','certificate.json','result.json']]+[SOURCE/n for n in ['plan.json','queries/019.json','mutual/081.json','audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Independent exact-rational endpoint/projection/cross-product checks prove every raw boundary segment strictly outside the asserted disk. Independent positive-ray parity proves origin interior. Recompute all domain bounds and exact disjoint integer-bin coverage. Verify fresh audited source provenance and committed unchanged raw pair geometry and all nine identical-profile copies. No solver.'})
    manifest=load(ROOT/'benchmarks/results/h5-expanded-cog-neighborhood-20261026/raw-manifest.json');known={r['sha256'] for r in manifest['files']+manifest['aliases']}
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    for n,h in load(SOURCE/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    assert digest(SOURCE/'mutual/081.json') in known
    assert load(SOURCE/'audit/checks.json')['passed'];c=load(BASE/'certificate.json');raw=load(SOURCE/'mutual/081.json')['raw_forbidden'];assert raw['type']=='Polygon' and len(raw['coordinates'])==1
    points=[tuple(F(v) for v in p) for p in raw['coordinates'][0]];assert points[0]==points[-1];radius=F(258082,1000);r2=radius**2;crossings=0;distances=[];segments=0
    for a,b in zip(points,points[1:]):
        if a==b:continue
        segments+=1;u=(b[0]-a[0],b[1]-a[1]);length=u[0]**2+u[1]**2;aa=a[0]**2+a[1]**2;bb=b[0]**2+b[1]**2;assert aa>r2 and bb>r2
        dot=a[0]*u[0]+a[1]*u[1]
        if -length<dot<0:
            cross=a[0]*b[1]-a[1]*b[0];assert cross**2>r2*length;distances.append(cross**2/length)
        else:distances.append(min(aa,bb))
        if (a[1]>0)!=(b[1]>0):
            x=a[0]-a[1]*(b[0]-a[0])/(b[1]-a[1]);assert x!=0;crossings+=int(x>0)
    assert crossings%2==1 and segments==c['original_collision_boundary_segments']==228
    minimum=min(distances);assert [minimum.numerator,minimum.denominator]==c['minimum_exact_boundary_distance_squared_mm2']
    rows=load(SOURCE/'queries/019.json')['domains'];xs=[v for d in rows for v in [d['coordinate_bounds'][0],d['coordinate_bounds'][2]]];ys=[v for d in rows for v in [d['coordinate_bounds'][1],d['coordinate_bounds'][3]]];bounds=[min(xs),min(ys),max(xs),max(ys)];assert bounds==c['complete_anchor_bounds_units1000']
    left,right=c['integer_partition_bins'];assert left[:2]==bounds[:2] and right[2:]==bounds[2:] and left[3]==right[3] and left[1]==right[1] and left[2]+1==right[0]
    required=258082**2+1;diagonals=[(b[2]-b[0])**2+(b[3]-b[1])**2 for b in [left,right]];assert max(diagonals)<required and diagonals==c['bin_diagonal_squared_units'] and required==c['required_integer_squared_distance_units']
    spec=load(SOURCE/'plan.json');parts=[p for p in spec['parts'] if 19 in p['queries']];assert [p['part'] for p in parts]==c['applicable_moving_parts']==list(range(4,13));assert all(p['family']=='cog' and p['profiles']==[9] and p['queries']==[18,19] for p in parts)
    assert len(rows)==c['source_domain_rows']==32 and c['capacity']==2 and c['strict_collision_disk_radius_units']==258082
    checks={'passed':True,'seconds':time.perf_counter()-start,'fresh_source_and_committed_pair_inputs_verified':True,'boundary_segments_independently_checked':segments,'positive_ray_crossings':crossings,'strict_disk_containment_verified':True,'source_domain_rows':32,'integer_bins_cover_without_gaps_or_overlap':True,'maximum_bin_squared_diagonal':max(diagonals),'required_squared_separation':required,'capacity':2,'applicable_moving_cogs':9,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
