"""Verify the new physical fixed set and free regions broaden both earlier arrangements."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from shapely.geometry import shape
ROOT=Path(__file__).resolve().parents[1];NEW=ROOT/'output/h5-free-bracket27-fixed-regions-20261026';OLD54=ROOT/'output/h5-expanded-cog-neighborhood-20261026';OLD59=ROOT/'output/h5-partial59-fixed-regions-20261026';OUT=NEW/'scope-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();paths=[p for folder in [NEW,OLD54,OLD59] for p in [folder/'plan.json',folder/'fixed-originals.json',folder/'audit/checks.json']+list((folder/'queries').glob('*.json'))];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Verify new53 fixed originals are exactly old54 minus bracket27, and also a subset of the focused59 set with all shared transforms unchanged. Verify every old free query is contained in the corresponding new free query up to recorded numerical geometry differences. This establishes the physical-region broadening; it does not assert nesting between differently triangulated inward integer domain sets or transfer any prior conditional exclusion.'})
fixed={r['item']:r for r in load(NEW/'fixed-originals.json')};old54={r['item']:r for r in load(OLD54/'fixed-originals.json')};old59={r['item']:r for r in load(OLD59/'fixed-originals.json')};assert set(fixed)==set(old54)-{27} and set(fixed)<set(old59) and set(old59)-set(fixed)=={50,56,57,62,64,65}
for i,r in fixed.items():
    for earlier in [old54,old59]:
        for field in ['family','sheet','style','transform']:assert r[field]==earlier[i][field]
newplan=load(NEW/'plan.json');assert [p['index'] for p in newplan['parts']]==[27,28,29,50,53,54,56,57,58,61,62,64,65];rows=[]
for earlier in [OLD54,OLD59]:
    assert load(earlier/'audit/checks.json')['passed']
    for q in newplan['queries']:
        name=f"{q['index']:03d}.json";a=shape(load(earlier/'queries'/name)['free_region']);b=shape(load(NEW/'queries'/name)['free_region']);miss=a.difference(b);assert miss.area<1e-6;rows.append({'earlier':earlier.name,'query':q['index'],'old_region_not_covered_area_mm2':miss.area,'old_region_empty':a.is_empty,'new_region_empty':b.is_empty})
assert load(NEW/'audit/checks.json')['passed'];write(OUT/'query-containment-checks.json',rows);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'new_fixed_originals':53,'new_moving_originals':13,'required_originals':66,'exact_old54_fixed_subset_difference':[27],'exact_focused59_additional_releases':[50,56,57,62,64,65],'all_common_transforms_unchanged':True,'physical_free_region_containment_checks':len(rows),'maximum_old_region_not_covered_area_mm2':max(r['old_region_not_covered_area_mm2'] for r in rows),'integer_domain_set_nesting_claimed':False,'old_conditional_exclusions_transferred':0,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
