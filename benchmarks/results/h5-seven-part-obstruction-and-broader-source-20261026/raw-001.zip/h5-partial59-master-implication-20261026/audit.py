"""Verify the exact scope of the necessary-master negative, without another solve."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-partial59-joint-prepared-20261026';FULL=ROOT/'output/h5-partial59-source-model-20261026';MASTER=ROOT/'output/h5-partial59-domain-master-20261026';CONFLICT=ROOT/'output/h5-partial59-domain-conflicts-20261026';SEARCH=ROOT/'output/h5-partial59-domain-master-search-20261026';OUT=ROOT/'output/h5-partial59-master-implication-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();paths=[SOURCE/'plan.json',SOURCE/'audit/checks.json',FULL/'mapping.json',FULL/'necessary-rules.json',FULL/'audit/checks.json',MASTER/'plan.json',MASTER/'mapping.json',MASTER/'audit/checks.json',CONFLICT/'audit/checks.json',CONFLICT/'groups/audit/checks.json',CONFLICT/'copy-symmetry/checks.json',SEARCH/'selection-audit/checks.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Verify that every full-source solution would map to a necessary-master assignment: same original identities, exact source query/domain order, same fresh original area rules, all certified raw collision exclusions, and independently verified within-family sorting. The solver negative is read back, not retried or promoted to an unrestricted continuous proof.'})
assert all(load(p)['passed'] for p in paths if p.name=='checks.json');assert load(SEARCH/'selection-audit/checks.json')['terminal_status']=='INFEASIBLE';full=load(FULL/'mapping.json')['parts'];master=load(MASTER/'mapping.json');spec=load(SOURCE/'plan.json');mapped=0
for a,b,p in zip(full,master['parts'],spec['parts']):
    assert (a['part'],a['item'],a['family'])==(b['part'],b['item'],b['family'])==(p['part'],p['index'],p['family'])
    for x,y in zip(a['modes'],b['modes']):assert x['query']==y['query'] and x['choice_offset']==y['choice_offset'] and len(x['domains'])==len(y['domains']);mapped+=len(x['domains'])
assert len(full)==len(master['parts'])==13-6 and mapped==6763 and len(spec['fixed_items'])==59
assert load(FULL/'necessary-rules.json')['fixed_area_lower_units']==spec['fixed_original_area_units_per_sheet'];assert load(MASTER/'plan.json')['inputs'][(FULL/'necessary-rules.json').relative_to(ROOT).as_posix()]==digest(FULL/'necessary-rules.json')
sym=load(CONFLICT/'copy-symmetry/checks.json');assert sym['asymmetric_query_pairs']==0 and sym['proposed_choice_order_pairs']==master['choice_order_pairs']==[[0,1],[1,2],[3,4],[4,5],[5,6]]
assert load(CONFLICT/'audit/checks.json')['all_exclusions_covered_by_whole_original_obstacle'] and load(CONFLICT/'groups/audit/checks.json')['unique_conflicts_preserved']==2369711
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'mandatory_originals':66,'fixed_originals':59,'moving_originals':7,'source_domain_selectors_mapped':mapped,'same_source_domain_and_identity_order':True,'same_fresh_original_area_rules':True,'raw_original_conflicts_are_necessary':True,'family_sorting_preserves_necessary_master':True,'full_source_positive_would_imply_master_positive':True,'master_status':'INFEASIBLE','finite59_fixed_source_construction_excluded':True,'formal_UNSAT_certificate':False,'continuous_or_unrestricted_impossibility_claim':False,'new_solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
