from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for kind in ['prepare','audit']:
    s=(ROOT/'output'/f'{kind}_h5_expanded_domain_master.py').read_text(encoding='utf-8')
    for a,b in [('h5-expanded-domain-master-20261026','h5-partial59-domain-master-20261026'),('h5-expanded-cog-joint-prepared-20261026','h5-partial59-joint-prepared-20261026'),('h5-expanded-convex-conflicts-20261026','h5-partial59-domain-conflicts-20261026'),('h5-projected-expanded-model-20261026','h5-partial59-source-model-20261026')]:s=s.replace(a,b)
    s=s.replace(";CAP=ROOT/'output/h5-expanded-second-sheet-capacity-20261026'",'').replace(",CAP/'audit/checks.json'",'').replace("+[CAP/'certificate.json',CAP/'audit/checks.json']",'')
    start=s.index(";cap=load(CAP/'certificate.json')");end=s.index(';orders=',start) if kind=='prepare' else s.index('\n',start);s=s[:start]+s[end:]
    s=s.replace('range(3,12)','range(3,7)').replace('len(parts)==12','len(parts)==7').replace("len(spec['fixed_items'])==54","len(spec['fixed_items'])==59")
    s=s.replace('17039','7937').replace('9793','2514').replace('1255748','232752').replace('25543004','11983416').replace('12688','6763').replace('4275','1104').replace("'query_modes':52","'query_modes':56").replace('(12764,88)','(6833,77)').replace('==538','==588').replace(':538',':588').replace('len(inventory)==66','len(inventory)==21').replace("'physical_pairs':66","'physical_pairs':21")
    s=s.replace("'hints':36","'hints':16").replace('len(values)==36','len(values)==16').replace("'moving_originals':12","'moving_originals':7").replace("'fixed_originals':54","'fixed_originals':59").replace("'certified_family_orders_only_in_necessary_master':9","'certified_family_orders_only_in_necessary_master':5")
    s=s.replace('all twelve movers','all seven movers').replace('12 selecting fresh54-fixed','7 selecting fresh59-fixed').replace('fresh second-sheet cog capacity2 and every newly refined whole-domain conflict group','every newly verified raw-original whole-domain conflict group, with no inherited capacity').replace('the two bracket and nine cog copies','the three bracket and four cog copies').replace('the nine verified partial-domain hints','the four verified partial-domain hints').replace('fresh refined collision/audit/symmetry hash chains and committed source/capacity/area inputs','fresh raw collision/audit/symmetry hash chains and independently audited source/area inputs').replace('fresh capacity, precisely nine certified family orders','no capacity, precisely five certified family orders').replace('every refined conflict group','every raw-original conflict group')
    if kind=='audit':
        start=s.index('    known=set()');end=s.index('    for p,key in',start)
        s=s[:start]+"    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n\n    assert load(RULES.parent/'audit/checks.json')['passed']\n    for n,h in load(RULES.parent/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n\n"+s[end:]
        s=s.replace('orders=[[0,1]]+[[i,i+1] for i in range(3,11)]','orders=[[0,1],[1,2],[3,4],[4,5],[5,6]]')
    s=s.replace("+[CAP/'certificate.json']",'')
    assert 'CAP/' not in s
    compile(s,kind,'exec')
    with (ROOT/'output'/f'{kind}_h5_partial59_domain_master.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
