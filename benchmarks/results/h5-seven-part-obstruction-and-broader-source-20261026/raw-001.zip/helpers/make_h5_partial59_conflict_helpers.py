"""Fresh raw-original conflicts for the new59-fixed domain geometry only."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for kind in ['build','audit']:
    s=(ROOT/'output'/f'{kind}_h5_expanded_domain_conflicts.py').read_text(encoding='utf-8')
    s=s.replace('h5-expanded-cog-joint-prepared-20261026','h5-partial59-joint-prepared-20261026').replace('h5-expanded-domain-conflicts-20261026','h5-partial59-domain-conflicts-20261026')
    s=s.replace('==164','==146').replace('==66','==21').replace('==538','==588').replace(':164',':146').replace(':66',':21').replace(':538',':588')
    s=s.replace('the12 mandatory originals','the7 mandatory originals').replace('All164 unique query pairs and their538 physical uses','All146 unique query pairs and their588 physical uses').replace('full164-case/538-use/66-physical-pair','full146-case/588-use/21-physical-pair')
    s=s.replace("dtype=np.int64)","dtype=np.int64).reshape(-1,4)")
    if kind=='audit':
        s=s.replace("certified={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}","certified={r['sha256'] for r in manifest['files']+manifest['aliases']};fresh=load(SOURCE/'audit/plan.json')['inputs'];assert load(SOURCE/'audit/checks.json')['passed']\n    for n,h in fresh.items():assert digest(ROOT/n)==h,n")
        s=s.replace("plan['query_hashes'][str(i)]==certified[p.relative_to(ROOT/'output').as_posix()]", "plan['query_hashes'][str(i)]==fresh[p.relative_to(ROOT).as_posix()]")
        s=s.replace("assert digest(p)==plan['mutual_hashes'][str(c['index'])]==certified[p.relative_to(ROOT/'output').as_posix()]", "assert digest(p)==plan['mutual_hashes'][str(c['index'])] and digest(p) in certified")
        s=s.replace('Verify source hashes against the committed previous manifest','Verify new query hashes against their independent fresh domain audit and unchanged mutual geometry against committed hashes').replace("'committed_source_query_and_mutual_files_verified':102","'fresh_queries_and_committed_mutual_files_verified':102")
    compile(s,kind,'exec')
    with (ROOT/'output'/f'{kind}_h5_partial59_domain_conflicts.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
