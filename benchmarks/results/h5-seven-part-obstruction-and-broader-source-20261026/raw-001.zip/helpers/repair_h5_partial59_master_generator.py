from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
old=ROOT/'output/make_h5_partial59_master_helpers.py';s=old.read_text(encoding='utf-8')
s=s.replace("    assert 'CAP/' not in s", "    s=s.replace(\"+[CAP/'certificate.json']\",'')\n    assert 'CAP/' not in s")
with (ROOT/'output/make_h5_partial59_master_helpers_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
out=ROOT/'output/h5-partial59-master-generator-failure-20261026';out.mkdir()
with (out/'failure-record.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'error':'Generator assertion caught a remaining old capacity path before any generated model helper was written. Subsequent prepare/audit commands failed because those files did not exist.','cause':'Earlier replacement removed one list element, leaving a singleton capacity-certificate input list.','repair':'Fresh generator removes that stale singleton input as well; no capacity or conditional exclusion is carried over. Original generator retained.','models_built':0,'solver_calls':0},f,indent=2);f.write('\n')
