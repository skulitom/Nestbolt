from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for kind in ['certify','audit']:
    s=(ROOT/'output'/f'{kind}_h5_expanded_second_sheet_capacity.py').read_text(encoding='utf-8')
    s=s.replace('h5-expanded-cog-joint-prepared-20261026','h5-free-bracket27-joint-prepared-20261026').replace('h5-expanded-second-sheet-capacity-20261026','h5-free-bracket27-second-sheet-capacity-20261026').replace('the54-fixed source','the53-fixed source').replace('source_domain_bounds_recomputed_for_fixed54','source_domain_bounds_recomputed_for_fixed53').replace('list(range(3,12))','list(range(4,13))')
    if kind=='audit':
        s=s.replace("for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h and h in known,n", "for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n\n    for n,h in load(SOURCE/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n\n    assert digest(SOURCE/'mutual/081.json') in known")
        s=s.replace('Verify committed source provenance','Verify fresh audited source provenance and committed unchanged raw pair geometry').replace("'committed_source_inputs_verified':True","'fresh_source_and_committed_pair_inputs_verified':True")
    compile(s,kind,'exec')
    with (ROOT/'output'/f'{kind}_h5_free_bracket27_second_sheet_capacity.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
