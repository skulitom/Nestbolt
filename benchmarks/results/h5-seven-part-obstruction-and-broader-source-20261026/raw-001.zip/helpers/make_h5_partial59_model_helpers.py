from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for kind in ['prepare','audit']:
    s=(ROOT/'output'/f'{kind}_h5_partial61_source_model.py').read_text(encoding='utf-8')
    s=s.replace('h5-partial61-','h5-partial59-').replace('five-mover','seven-mover').replace('fresh61-fixed','fresh59-fixed').replace('5 mandatory originals','7 mandatory originals').replace('of5 physical originals','of7 physical originals').replace('fixed61 and these5','fixed59 and these7').replace('and61 unchanged fixed','and59 unchanged fixed').replace('three previous cog positions','four previous cog positions').replace('all115 nonempty','all294 nonempty').replace('all10 physical pairs/115','all21 physical pairs/294')
    s=s.replace("'moving_originals':5","'moving_originals':7").replace("'fixed_originals':61","'fixed_originals':59").replace("'hints':18","'hints':24").replace("'original_anchor_variables':10","'original_anchor_variables':14").replace("'physical_pairs':10","'physical_pairs':21").replace("'same_sheet_pair_modes':115","'same_sheet_pair_modes':294")
    s=s.replace("len(spec['parts'])==5","len(spec['parts'])==7").replace("len(spec['fixed_items'])==61","len(spec['fixed_items'])==59").replace("len(mapping['source_pair_faces'])==115","len(mapping['source_pair_faces'])==294").replace('len(hint_pairs)==18','len(hint_pairs)==24')
    compile(s,kind,'exec')
    with (ROOT/'output'/f'{kind}_h5_partial59_source_model.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
