from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('prepare_h5_expanded_conflict_groups.py','prepare_h5_partial59_conflict_groups.py'),('audit_h5_expanded_conflict_groups.py','audit_h5_partial59_conflict_groups.py'),('audit_h5_expanded_master_copy_symmetry.py','audit_h5_partial59_master_copy_symmetry.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    s=s.replace('h5-expanded-domain-conflicts-20261026','h5-partial59-domain-conflicts-20261026').replace('h5-expanded-convex-conflicts-20261026','h5-partial59-domain-conflicts-20261026').replace('h5-expanded-cog-joint-prepared-20261026','h5-partial59-joint-prepared-20261026').replace('h5-projected-expanded-model-20261026','h5-partial59-source-model-20261026')
    s=s.replace('all538','all588').replace(':164',':146').replace('==66','==21').replace('==538','==588').replace(':66',':21').replace(':538',':588').replace("{'bracket':[0,1],'cog':list(range(3,12))}","{'bracket':[0,1,2],'cog':list(range(3,7))}")
    s=s.replace('the two bracket copies','the three bracket copies').replace('the nine cogs','the four cogs').replace('Original area charges and second-sheet cog capacity depend only on family/sheet.','Original area charges depend only on family/sheet. No inherited capacity is used.').replace("'family_sheet_cog_capacity_invariant':True","'no_capacity_transferred':True")
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
