"""Exact bitwise replay of conflict grouping and its Boolean equivalence."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time,traceback

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-expanded-domain-conflicts-20261026';GROUP=BASE/'groups';OUT=GROUP/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();spec=load(BASE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(GROUP.glob('*.json'))},
        'method':'Independently decode each complete row-major source matrix as an exact integer and compare every A row to its grouped B-bit pattern. Verify row partitions, all zero padding, counts, hashes and all538 physical case uses. Given a mandatory part selects exactly one domain, each A group sum is Boolean; at-most-one of that flag and its incompatible B selectors is precisely all original pairwise exclusions. If all B rows are incompatible, its query-active flag gives the same constraint. Validate the complete Boolean truth table, including both inactive cases. No additional geometric exclusions.'})
    assert load(BASE/'audit/checks.json')['passed'];counts=Counter(c for r in spec['physical_pair_case_uses'] for c in r['cases']);summaries=[]
    for c in spec['cases']:
        row=load(GROUP/f"{c['index']:03d}.json");meta=BASE/'cases'/f"{c['index']:03d}.json";binary=BASE/'cases'/f"{c['index']:03d}.bin"
        assert row['case']==c and row['source_metadata_sha256']==digest(meta) and row['source_packed_sha256']==digest(binary)
        data=binary.read_bytes();pad=len(data)*8-c['domain_pairs'];value=int.from_bytes(data,'big');assert value&((1<<pad)-1)==0;value>>=pad
        mask=(1<<c['rows_b'])-1;seen=[];represented=0;nonzero=aux=lits=0
        for gi,g in enumerate(row['groups']):
            assert g['group']==gi and g['rows_a'];encoded=bytes.fromhex(g['forbidden_b_hex']);n=int.from_bytes(encoded,'big');p=len(encoded)*8-c['rows_b']
            assert n&((1<<p)-1)==0;n>>=p;assert n.bit_count()==g['conflicts_per_a_row']
            for i in g['rows_a']:
                assert 0<=i<c['rows_a'] and ((value>>((c['rows_a']-1-i)*c['rows_b']))&mask)==n;seen.append(i)
            represented+=len(g['rows_a'])*n.bit_count()
            if n:
                nonzero+=1;aux+=len(g['rows_a'])>1;lits+=2 if n.bit_count()==c['rows_b'] else 1+n.bit_count()
                for a in [0,1]:
                    for b in [0,1]:assert (a+b<=1)==(not (a and b))
        assert sorted(seen)==list(range(c['rows_a'])) and represented==load(meta)['conflicts']
        summaries.append({'case':c['index'],'groups':len(row['groups']),'nonzero_groups':nonzero,'physical_uses':counts[c['index']],
            'group_auxiliaries_per_use':aux,'at_most_one_literals_per_use':lits,'source_conflicts':represented})
    assert summaries==load(GROUP/'summary.json');r=load(GROUP/'result.json')
    for key,val in {'unique_groups':sum(c['groups'] for c in summaries),'unique_nonzero_groups':sum(c['nonzero_groups'] for c in summaries),
        'physical_nonzero_group_uses':sum(c['nonzero_groups']*c['physical_uses'] for c in summaries),
        'physical_group_auxiliaries':sum(c['group_auxiliaries_per_use']*c['physical_uses'] for c in summaries),
        'physical_at_most_one_literals':sum(c['at_most_one_literals_per_use']*c['physical_uses'] for c in summaries),
        'represented_unique_conflicts':sum(c['source_conflicts'] for c in summaries),'represented_physical_conflicts':sum(c['source_conflicts']*c['physical_uses'] for c in summaries)}.items():assert r[key]==val
    result={'passed':True,'seconds':time.perf_counter()-start,'complete_query_pair_cases':164,'whole_domain_pairs_preserved':spec['complete_domain_pair_census'],
        'unique_conflicts_preserved':r['represented_unique_conflicts'],'physical_conflicts_preserved':r['represented_physical_conflicts'],'physical_group_constraints':r['physical_nonzero_group_uses'],
        'all_row_partitions_exact':True,'all_bits_and_padding_reconstructed_independently':True,'group_boolean_truth_tables_verified':True,'no_new_geometry_exclusions':True,'H5_complete':False}
    assert result['seconds']<60;write(OUT/'checks.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
