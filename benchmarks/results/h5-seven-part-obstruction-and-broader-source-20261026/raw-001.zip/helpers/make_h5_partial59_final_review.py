from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_partial59_checkpoint.py').read_text(encoding='utf-8').replace('h5-partial59-source-review-20261026','h5-partial59-final-review-20261026')
with (ROOT/'output/review_h5_partial59_final.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
