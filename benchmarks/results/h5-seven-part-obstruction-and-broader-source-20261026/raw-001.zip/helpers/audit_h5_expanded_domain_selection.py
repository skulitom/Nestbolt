"""Read back a necessary-master result and every selected incompatibility bit."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-expanded-domain-master-search-20261026';RUN=BASE/'shared-search';PREP=ROOT/'output/h5-expanded-domain-master-20261026';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';CONFLICTS=ROOT/'output/h5-expanded-convex-conflicts-20261026';OUT=BASE/'selection-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();paths=[p for p in RUN.rglob('*') if p.is_file()]+[PREP/n for n in ['model.pb','mapping.json','audit/checks.json']]+[CONFLICTS/'plan.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Verify the single closed necessary-master call, actual model/parameters/response and timing. Evaluate all returned variables and constraints. Independently reconstruct every selected original/domain/query/sheet/choice, exact original-area charges and copy ordering; read each selected same-sheet pair bit directly from the certified refined matrices. A compatible selection has no anchor or physical-layout witness.'})
    for p in [RUN/'plan.json',RUN/'solve/plan.json',PREP/'plan.json',PREP/'audit/plan.json']:
        for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
    run=load(RUN/'result.json');solved=load(RUN/'solve/result.json');budget=load(RUN/'budget.json');opened=load(RUN/'solve/opened.json');ma=load(RUN/'solve/model-audit.json');assert ma['passed'] and ma['necessary_master_only'];assert run['status']=='MASTER_'+solved['status'] and run['stage']['exit_code']==0 and solved['solver_calls']==run['solver_calls_opened']==1
    model=cp_model_pb2.CpModelProto();model.ParseFromString((RUN/'solve/model.pb').read_bytes());expected=cp_model_pb2.CpModelProto();expected.ParseFromString((PREP/'model.pb').read_bytes());assert model==expected and digest(RUN/'solve/model.pb')==ma['model_sha256']==opened['model_sha256'];assert len(model.variables)==17039 and len(model.constraints)==9793 and len(model.solution_hint.vars)==36
    params=text_format.Parse((RUN/'solve/parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert digest(RUN/'solve/parameters.pbtxt')==ma['parameters_sha256'];assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=min(20,ma['remaining_shared_budget_at_parameter_set']),num_search_workers=8,random_seed=0,cp_model_presolve=True,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and params.max_time_in_seconds==opened['seconds_limit'];assert budget['shared_seconds']==30 and budget['solver_cap_seconds']==20 and budget['solver_shutdown_reserve_seconds']==5 and budget['deadline_perf_counter']==budget['start_perf_counter']+30;assert solved['seconds']+ma['preparation_seconds']<=run['stage']['seconds']<=run['elapsed_seconds']
    response=cp_model_pb2.CpSolverResponse();response.ParseFromString((RUN/'solve/response.pb').read_bytes());assert cp_model_pb2.CpSolverStatus.Name(response.status)==solved['status'] and abs(response.wall_time-solved['seconds'])<1;positive=solved['status'] in ['OPTIMAL','FEASIBLE'];assert positive==solved['has_necessary_domain_candidate'];checked=pairs=0
    if positive:
        solution=list(response.solution);assert len(solution)==len(model.variables)
        def truth(v):return bool(solution[v]) if v>=0 else not bool(solution[-v-1])
        for v,n in zip(model.variables,solution):assert any(lo<=n<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]))
        for c in model.constraints:
            assert not c.enforcement_literal;kind=c.WhichOneof('constraint')
            if kind=='linear':n=sum(solution[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=n<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
            elif kind=='at_most_one':assert sum(truth(v) for v in c.at_most_one.literals)<=1
            else:assert kind=='bool_or' and any(truth(v) for v in c.bool_or.literals)
            checked+=1
        selected=load(RUN/'solve/selection.json');spec=load(SOURCE/'plan.json');mapping=load(PREP/'mapping.json');parts=selected['movable_parts'];assert len(parts)==12 and selected['required_originals']==66 and selected['fixed_items']==spec['fixed_items'] and sorted(selected['fixed_items']+[p['item'] for p in parts])==list(range(66))
        for original,p,m in zip(spec['parts'],parts,mapping['parts']):
            assert p['part']==original['part'] and p['item']==original['index'] and p['family']==original['family'] and p['query'] in original['queries'];q=spec['queries'][p['query']];assert q['profile']==p['profile'] and q['sheet']==p['sheet']==solution[m['sheet']];mode=next(z for z in m['modes'] if z['query']==p['query']);assert solution[mode['active']]==solution[mode['domains'][p['domain_row']]]==1 and p['choice_index']==solution[m['choice']]==mode['choice_offset']+p['domain_row'];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];assert d['index']==p['domain_index']
        for a,b in mapping['choice_order_pairs']:assert parts[a]['choice_index']<=parts[b]['choice_index']
        rules=load(ROOT/'output/h5-projected-expanded-model-20261026/necessary-rules.json');areas=rules['fixed_area_lower_units'].copy()
        for p in parts:areas[p['sheet']]+=rules['filled_area_lower_units'][p['family']]
        assert all(a<=b for a,b in zip(areas,rules['stock_area_upper_units'])) and sum(p['family']=='cog' and p['sheet']==1 for p in parts)<=2
        census=load(CONFLICTS/'plan.json');cases={(c['query_a'],c['query_b']):c for c in census['cases']};pair_rows=[]
        for a,b in combinations(parts,2):
            if a['sheet']!=b['sheet']:continue
            c=cases[a['query'],b['query']];p=CONFLICTS/'cases'/f"{c['index']:03d}.bin";meta=load(CONFLICTS/'cases'/f"{c['index']:03d}.json");assert digest(p)==meta['packed_sha256'];raw=p.read_bytes();bit=a['domain_row']*c['rows_b']+b['domain_row'];assert not(raw[bit//8]&(1<<(7-bit%8)));pair_rows.append({'parts':[a['part'],b['part']],'case':c['index'],'rows':[a['domain_row'],b['domain_row']],'flat_bit':bit,'certified_conflict':False});pairs+=1
        write(OUT/'selected-pair-bits.json',pair_rows);write(OUT/'selected-area-checks.json',{'lower_area_units_per_sheet':areas,'upper_stock_area_units':rules['stock_area_upper_units'],'passed':True});write(OUT/'verified-domain-selection.json',selected)
    else:assert solved['status'] in ['UNKNOWN','INFEASIBLE'] and not response.solution and not (RUN/'solve/selection.json').exists()
    checks={'passed':True,'seconds':time.perf_counter()-start,'terminal_status':solved['status'],'necessary_domain_candidate':positive,'solver_calls':1,'actual_solver_seconds':solved['seconds'],'declared_solver_seconds':params.max_time_in_seconds,'solver_soft_limit_overshoot_seconds':max(0,solved['seconds']-params.max_time_in_seconds),'actual_shared_seconds':run['elapsed_seconds'],'shared_budget_honored':run['elapsed_seconds']<=30,'required_originals':66,'moving_originals':12,'fixed_originals':54,'actual_model_matches_independent_audit':True,'response_proto_status_verified':True,'returned_constraints_checked':checked,'selected_pair_bits_checked':pairs,'certified_conflict_bits_selected':0,'compatible_domains_are_not_coordinate_feasibility':True,'completed_call_closed_no_retry':True,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
