from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for kind in ['run','audit']:
    s=(ROOT/'output'/f'{kind}_h5_partial61_source_search.py').read_text(encoding='utf-8')
    s=s.replace('h5-partial61-','h5-partial59-').replace('22545','88210').replace('39619','121712').replace('==115','==294').replace(':115',':294').replace('==5','==7')
    s=s.replace('len(actual.solution_hint.vars)==18','len(actual.solution_hint.vars)==24').replace("'hints':18","'hints':24").replace("'moving_originals':5","'moving_originals':7").replace("'fixed_originals':61","'fixed_originals':59").replace("'original_anchor_variables':10","'original_anchor_variables':14")
    s=s.replace('five-mover','seven-mover').replace('fixes61','fixes59').replace('brackets28/29 plus cogs53/54/61','brackets27/28/29 plus cogs53/54/58/61').replace('all10 physical pairs and115','all21 physical pairs and294').replace('other115 empty-query','other294 empty-query').replace('Three cog positions supply18','Four cog positions supply24').replace('finite61-fixed','finite59-fixed')
    compile(s,kind,'exec')
    with (ROOT/'output'/f'{kind}_h5_partial59_source_search.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
