from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-focused-checkpoint-queue-20261026';OUT.mkdir()
def call(args):return subprocess.check_output(args,cwd=ROOT).decode().strip()
ci=json.loads(call(['gh','run','view','40267513191','--json','databaseId,status,conclusion,headSha,jobs,url']))
head=call(['git','rev-parse','HEAD']);main=call(['git','rev-parse','origin/main'])
assert main==ci['headSha']=='679e97e0d7fca4798ba2a1d690c044d72b8f72e2' and head.startswith('fec3cd72') and call(['git','rev-list','--left-right','--count','origin/main...HEAD']).split()==['0','1'] and not call(['git','diff','HEAD','--name-only'])
record={'utc':datetime.now(timezone.utc).isoformat(),'queued_head':head,'main_head':main,'queued_commits':1,'main_ci_id':ci['databaseId'],'main_ci_status':ci['status'],'main_ci_conclusion':ci['conclusion'],'passed_jobs':sum(j['conclusion']=='success' for j in ci['jobs']),'action':'Preserve current live CI. Normally fast-forward main with the verified queued commit once current checks finish and remote ancestry is rechecked. No force push.','next_step':'benchmarks/results/h5-focused-partial-obstruction-20261026/next-step.json','H5_complete':False}
for name,value in [('ci-observation.json',ci),('queue.json',record)]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(record)
