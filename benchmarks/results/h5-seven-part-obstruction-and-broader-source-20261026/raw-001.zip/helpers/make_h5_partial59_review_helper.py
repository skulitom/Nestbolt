from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_partial61_checkpoint_repaired.py').read_text(encoding='utf-8').replace('h5-partial61-checkpoint-review-repaired-20261026','h5-partial59-source-review-20261026')
s=s.replace("assert head==main=='679e97e0d7fca4798ba2a1d690c044d72b8f72e2'", "assert head=='fec3cd72205e16d3522a181bf4f29680b9e768e5' and main=='679e97e0d7fca4798ba2a1d690c044d72b8f72e2'").replace("'--commit',head", "'--commit',main")
compile(s,'review','exec')
with (ROOT/'output/review_h5_partial59_checkpoint.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
