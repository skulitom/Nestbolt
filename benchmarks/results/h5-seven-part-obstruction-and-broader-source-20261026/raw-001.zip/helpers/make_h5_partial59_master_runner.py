from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('run_h5_expanded_domain_master.py','run_h5_partial59_domain_master.py'),('audit_h5_expanded_domain_selection.py','audit_h5_partial59_domain_selection.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in [('h5-expanded-domain-master','h5-partial59-domain-master'),('h5-expanded-cog-joint-prepared','h5-partial59-joint-prepared'),('h5-expanded-convex-conflicts','h5-partial59-domain-conflicts'),('h5-projected-expanded-model','h5-partial59-source-model')]:s=s.replace(a,b)
    s=s.replace('17039','7937').replace('9793','2514').replace('==36','==16').replace("'hints':36","'hints':16").replace('==5418','==1326').replace('==12','==7').replace("'moving_originals':12","'moving_originals':7").replace("'fixed_originals':54","'fixed_originals':59").replace(':538',':588')
    s=s.replace('12 mandatory domain choices','7 mandatory domain choices').replace('complete fresh refined conflicts','complete fresh raw-original conflicts').replace('fresh capacity2 and independently certified copy ordering','independently certified copy ordering and no inherited capacity').replace('12 movers in54-fixed','7 movers in59-fixed').replace('certified refined matrices','certified raw-original matrices')
    s=s.replace(" and sum(p['family']=='cog' and p['sheet']==1 for p in parts)<=2",'')
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
