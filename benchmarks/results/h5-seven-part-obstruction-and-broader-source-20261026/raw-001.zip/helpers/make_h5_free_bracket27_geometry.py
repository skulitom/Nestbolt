"""Broaden both earlier source constructions: old54 fixed minus upper-right bracket27."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ids='[27,28,29,50,53,54,56,57,58,61,62,64,65]'
for kind in ['build','audit']:
    s=(ROOT/'output'/f'{kind}_h5_partial59_fixed_regions.py').read_text(encoding='utf-8')
    s=s.replace('h5-partial59-fixed-regions-20261026','h5-free-bracket27-fixed-regions-20261026').replace('prior-four-cog-membership','prior-ten-part-membership')
    s=s.replace('len(fixed)==59','len(fixed)==53').replace("len(plan['parts'])==7","len(plan['parts'])==13").replace('[0,1,2,3,4,5,6]','list(range(13))').replace('[27,28,29,53,54,58,61]',ids).replace('{27,28,29,53,54,58,61}','set('+ids+')')
    s=s.replace("'fixed_originals':59","'fixed_originals':53").replace("'mandatory_moving_originals':7","'mandatory_moving_originals':13").replace("'moving_originals':7","'moving_originals':13").replace("'unused_profile_for_movers':8,'unused_queries_for_movers':[16,17]","'unused_profiles_for_movers':[],'unused_queries_for_movers':[]")
    s=s.replace('focused59-released-original','free-bracket27-original').replace('seven-mover regions with59','thirteen-mover regions with53').replace('all59','all53').replace('fix59','fix53').replace('brackets27/28/29 and cogs53/54/58/61','brackets27/28/29, insert50 and all nine cogs53/54/56/57/58/61/62/64/65').replace('insert profile8 and queries16/17 are computed but unused by the seven movers.','all ten profiles and twenty queries are used.').replace('any54-fixed,57-fixed,61-fixed or62-fixed','any54-fixed,57-fixed,59-fixed,61-fixed or62-fixed')
    s=s.replace('all four prior cog anchors','all ten prior moving anchors').replace('len(membership)==4','len(membership)==10').replace('len(fixedpairs)==1261','len(fixedpairs)==1056').replace("'original_fixed_stock_edges':236","'original_fixed_stock_edges':212").replace("'four_prior_cog_anchors_inside'","'ten_prior_moving_anchors_inside'").replace("(50 if q['sheet']==0 else 9)","(46 if q['sheet']==0 else 7)")
    if kind=='build':
        s=s.replace('if item in [27,53,54,58,61]:continue','if item not in oldfixed or item==27:continue')
        s=s.replace("if r['item'] in [53,54,58,61]","if r['item'] in [50,53,54,56,57,58,61,62,64,65]")
        s=s.replace('Distinct focused construction:','Distinct broader construction, superseding the original54-fixed and focused59-fixed restrictions:')
    else:s=s.replace('if i not in [27,53,54,58,61]','if i in oldfixed and i!=27')
    compile(s,kind,'exec')
    with (ROOT/'output'/f'{kind}_h5_free_bracket27_fixed_regions.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for kind in ['build','audit']:
    s=(ROOT/'output'/f'{kind}_h5_partial59_joint_domains.py').read_text(encoding='utf-8')
    s=s.replace('h5-partial59-fixed-regions','h5-free-bracket27-fixed-regions').replace('h5-partial59-joint-prepared','h5-free-bracket27-joint-prepared').replace('prior-four-cog-membership','prior-ten-part-membership')
    s=s.replace('len(parts)==7','len(parts)==13').replace("len(spec['parts'])==7","len(spec['parts'])==13").replace("len(spec['fixed_items'])==59","len(spec['fixed_items'])==53").replace("'fixed_originals':59","'fixed_originals':53").replace("'mandatory_moving_originals':7","'mandatory_moving_originals':13").replace("'moving_originals':7","'moving_originals':13")
    s=s.replace("{'bracket':3,'cog':4}","{'bracket':3,'insert':1,'cog':9}").replace('[3811701744,349788154]','[3641713590,249662718]').replace('len(physical)==21','len(physical)==78').replace('len(inventory)==21','len(inventory)==78').replace("'physical_pairs':21","'physical_pairs':78").replace('==588','==954').replace(':588',':954').replace('len(witness)==4','len(witness)==10').replace('all4_prior_cog_anchors_representable','all10_prior_moving_anchors_representable')
    s=s.replace('len(pairs)==73','len(pairs)==82').replace('len(desired)==73','len(desired)==82').replace("'unused_profile_queries':[16,17]","'unused_profile_queries':[]").replace("spec['unused_profile_queries']==[16,17]","spec['unused_profile_queries']==[]")
    s=s.replace('73 are used and9 are explicitly unused','all82 are used').replace('new59-fixed','new53-fixed').replace('7 mandatory movers','13 mandatory movers').replace('complete21 physical pair inventory for7 movers','complete78 physical pair inventory for13 movers').replace('full21 physical pair/588 mode','full78 physical pair/954 mode').replace('four-cog partial','ten-part partial').replace('No old fixed54, fixed61 or fixed62','No old fixed54, fixed59, fixed61 or fixed62').replace('no_old_fixed54_fixed61_or_fixed62_conditional_exclusion_transferred','no_old_fixed54_fixed59_fixed61_or_fixed62_conditional_exclusion_transferred')
    compile(s,kind,'exec')
    with (ROOT/'output'/f'{kind}_h5_free_bracket27_joint_domains.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
