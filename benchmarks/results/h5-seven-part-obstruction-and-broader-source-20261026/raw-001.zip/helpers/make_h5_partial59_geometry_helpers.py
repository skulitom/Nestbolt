"""Release upper-right bracket27/cog58 in a separately audited original construction."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(n,s):
    compile(s,n,'exec')
    with (ROOT/'output'/n).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for kind in ['build','audit']:
    s=(ROOT/'output'/f'{kind}_h5_partial61_fixed_regions.py').read_text(encoding='utf-8')
    s=s.replace('h5-partial61-fixed-regions-20261026','h5-partial59-fixed-regions-20261026').replace('prior-three-cog-membership','prior-four-cog-membership')
    s=s.replace('[53,54,61]','[27,53,54,58,61]').replace('{28,29,53,54,61}','{27,28,29,53,54,58,61}').replace('[28,29,53,54,61]','[27,28,29,53,54,58,61]')
    s=s.replace('len(fixed)==61','len(fixed)==59').replace("len(plan['parts'])==5","len(plan['parts'])==7").replace('[0,1,2,3,4]','[0,1,2,3,4,5,6]').replace("'fixed_originals':61","'fixed_originals':59").replace("'mandatory_moving_originals':5","'mandatory_moving_originals':7").replace("'moving_originals':5","'moving_originals':7")
    s=s.replace('four-mover regions with61','seven-mover regions with59').replace('all61','all59').replace('fix61','fix59').replace('brackets28/29 and cogs53/54/61','brackets27/28/29 and cogs53/54/58/61').replace('unused by the four movers','unused by the seven movers').replace('any54-fixed or57-fixed','any54-fixed,57-fixed,61-fixed or62-fixed')
    s=s.replace('all three prior cog anchors','all four prior cog anchors').replace('len(membership)==3','len(membership)==4').replace('len(fixedpairs)==1362','len(fixedpairs)==1261').replace("'original_fixed_stock_edges':244","'original_fixed_stock_edges':236").replace("'three_prior_cog_anchors_inside'","'four_prior_cog_anchors_inside'").replace("(52 if q['sheet']==0 else 9)","(50 if q['sheet']==0 else 9)")
    if kind=='build':
        old="moving=[{**next(p for p in spec['parts'] if p['index']==item),'part':i} for i,item in enumerate([27,28,29,53,54,58,61])]"
        new="moving=[]\nfor i,item in enumerate([27,28,29,53,54,58,61]):\n    proto=next(p for p in spec['parts'] if p['family']==items[item]['family']);r={**proto,**items[item],'part':i,'queries':proto['queries'],'profiles':proto['profiles'],'previous_source_allowed_modes':items[item]['allowed_modes'],'allowed_modes':proto['allowed_modes'],'group':'focused59-released-original','fixed_representative_class':None,'source_index':None};moving.append(r)\nassert families['bracket']['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]} and families['bracket']['allow_mirror']"
        assert old in s;s=s.replace(old,new)
        s=s.replace("if r['item'] in [27,53,54,58,61]","if r['item'] in [53,54,58,61]")
        s=s.replace('All66 originals remain mandatory.','All66 originals remain mandatory. Bracket27 is explicitly released from its old single-source orientation restriction to all four job-approved quarter turns and both mirror states, matching the other two brackets; prior source mode IDs are retained separately.')
    else:
        insertion="\nfor p in plan['parts']:\n    template=next(r for r in source['parts'] if r['family']==p['family']);assert p['copy']==items[p['index']]['copy'] and p['family']==items[p['index']]['family'] and p['queries']==template['queries'] and p['profiles']==template['profiles'] and p['allowed_modes']==template['allowed_modes'] and p['previous_source_allowed_modes']==items[p['index']]['allowed_modes']\nassert family['bracket']['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]} and family['bracket']['allow_mirror'];assert set((profiles[i]['quarter_turn'],profiles[i]['mirrored']) for i in range(8))==set((q,m) for q in range(4) for m in [False,True])\n"
        s=s.replace('for r in fixed:\n    i=',insertion+'for r in fixed:\n    i=',1)
    save(f'{kind}_h5_partial59_fixed_regions.py',s)
for kind in ['build','audit']:
    s=(ROOT/'output'/f'{kind}_h5_partial61_joint_domains.py').read_text(encoding='utf-8')
    s=s.replace('h5-partial61-','h5-partial59-').replace('prior-three-cog-membership','prior-four-cog-membership')
    s=s.replace('len(parts)==5','len(parts)==7').replace("len(spec['parts'])==5","len(spec['parts'])==7").replace("len(spec['fixed_items'])==61","len(spec['fixed_items'])==59").replace("'fixed_originals':61","'fixed_originals':59").replace("'mandatory_moving_originals':5","'mandatory_moving_originals':7").replace("'moving_originals':5","'moving_originals':7")
    s=s.replace("{'bracket':2,'cog':3}","{'bracket':3,'cog':4}").replace('[3901764462,349788154]','[3811701744,349788154]').replace('len(physical)==10','len(physical)==21').replace('len(inventory)==10','len(inventory)==21').replace("'physical_pairs':10","'physical_pairs':21").replace('==230','==588').replace(':230',':588').replace('len(witness)==3','len(witness)==4').replace('all3_prior_cog','all4_prior_cog')
    s=s.replace('new61-fixed','new59-fixed').replace('5 mandatory movers','7 mandatory movers').replace('complete10 physical pair inventory for5 movers','complete21 physical pair inventory for7 movers').replace('full10 physical pair/230 mode','full21 physical pair/588 mode').replace('three-cog partial','four-cog partial').replace('No old fixed54 or fixed62','No old fixed54, fixed61 or fixed62').replace('no_old_fixed54_or_fixed62_conditional_exclusion_transferred','no_old_fixed54_fixed61_or_fixed62_conditional_exclusion_transferred')
    save(f'{kind}_h5_partial59_joint_domains.py',s)
