"""Build fresh inward domains for13 mandatory movers; reuse unchanged audited pair geometry."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
import json,math,shutil,time,traceback
from shapely.geometry import shape,mapping
from shapely.ops import unary_union
from build_h5_strong_pair_domains import convex_faces
from build_h5_full_original_joint_domains import inequalities
ROOT=Path(__file__).resolve().parents[1];REG=ROOT/'output/h5-free-bracket27-fixed-regions-20261026';OLD=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';EPS=.000001
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();(OUT/'queries').mkdir();(OUT/'mutual').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240
    assert load(REG/'audit/checks.json')['passed'] and load(OLD/'audit/checks.json')['passed']
    spec=load(REG/'plan.json');profiles=load(REG/'profiles.json');parts=spec['parts'];queries=spec['queries'];assert profiles==load(OLD/'profiles.json') and len(parts)==13 and len(queries)==20
    pairs=sorted({(a,b) for x,y in combinations(parts,2) for a,b in product(x['profiles'],y['profiles'])});mutual=load(OLD/'plan.json')['mutual_cases'];assert len(pairs)==82 and len(mutual)==82 and set(pairs)<=set((c['profile_a'],c['profile_b']) for c in mutual)
    paths=[REG/n for n in ['plan.json','profiles.json','fixed-originals.json','audit/checks.json','prior-ten-part-membership.json']]+sorted((REG/'queries').glob('*.json'))+[OLD/'plan.json',OLD/'profiles.json',OLD/'audit/checks.json']+sorted((OLD/'mutual').glob('*.json'))+[ROOT/'output'/n for n in ['build_h5_full_original_joint_domains.py','build_h5_strong_pair_domains.py']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'construction_limit_seconds':240,'maximum_convex_faces':200000,'per_geometry_merge_attempt_limit':10000,'coordinate_units_per_mm':1000,'normal_coefficient_scale':10000000,'coordinate_maxima':[1500000,3000000],'allowed_face_inset_mm':EPS,'forbidden_face_square_padding_mm':EPS,'construction_clearance_mm':.2125,'clearance_envelope_extra_mm':.0001,'parts':parts,'queries':queries,'mutual_cases':mutual,'used_mutual_cases':[c['index'] for c in mutual if (c['profile_a'],c['profile_b']) in pairs],'unused_profile_queries':[],'fixed_items':spec['fixed_items'],'fixed_original_area_units_per_sheet':spec['fixed_original_area_units_per_sheet'],'required_original_counts':spec['required_original_counts'],'required_originals':66,'fixed_originals':53,'mandatory_moving_originals':13,'method':'Recompute every inward integer allowed domain from the new53-fixed free regions, with the same1e-6mm convex-face inset and exact coefficient-error bounds on the1micrometre grid. Retain discarded faces, missing raw union geometry and caps. The10 source profiles, source angles and pair guard are unchanged. Retain all82 historical pair cases with unchanged IDs;all82 are used, so copy the previously independently verified full-original mutual obstacles and outside clauses byte-for-byte rather than recomputing them. Derive the complete78 physical pair inventory for13 movers and all active same-sheet query pairs. No old fixed54, fixed59, fixed61 or fixed62 domain conflicts, capacities, area-region inequalities, no-goods or witness locks are reused. Check representability of the independently repaired ten-part partial; do not hide missing domains. No solver call.'})
    write(OUT/'profiles.json',profiles);qsummary=[];domains_by_query={};total=0
    for q in queries:
        if time.perf_counter()>=deadline or total>=200000:break
        path=REG/'queries'/f"{q['index']:03d}.json";region=shape(load(path)['free_region']);faces,merge=convex_faces(region,deadline);raw_union=unary_union(faces);missing=region.difference(raw_union);domains=[];discarded=[]
        for i,raw in enumerate(faces):
            inset=raw.buffer(-EPS,join_style='mitre')
            if inset.is_empty:discarded.append({'index':i,'raw_face':mapping(raw),'reason':'empty conservative inset'});continue
            assert inset.geom_type=='Polygon' and inset.equals(inset.convex_hull) and region.covers(inset)
            a,b,c,d=inset.bounds;bounds=[math.ceil(F(a)*1000),math.ceil(F(b)*1000),math.floor(F(c)*1000),math.floor(F(d)*1000)]
            if bounds[0]>bounds[2] or bounds[1]>bounds[3]:discarded.append({'index':i,'raw_face':mapping(raw),'inset_face':mapping(inset),'coordinate_bounds':bounds,'reason':'empty inward grid bounding box'});continue
            assert 0<=bounds[0]<=bounds[2]<=1500000 and 0<=bounds[1]<=bounds[3]<=3000000
            domains.append({'index':i,'raw_face':mapping(raw),'inset_face':mapping(inset),'coordinate_bounds':bounds,'halfplanes':inequalities(inset,True)})
        assert len(domains)+len(discarded)==len(faces);total+=len(faces);domains_by_query[q['index']]=domains
        write(OUT/'queries'/f"{q['index']:03d}.json",{'query':q,'source_query_sha256':digest(path),'raw_union_covers_whole_region':raw_union.covers(region),'raw_uncovered_geometry':mapping(missing),'raw_uncovered_area_mm2':missing.area,'raw_faces':len(faces),'merge':merge,'domains':domains,'discarded_faces':discarded})
        qsummary.append({'query':q['index'],'raw_faces':len(faces),'domains':len(domains),'discarded_faces':len(discarded),'raw_uncovered_area_mm2':missing.area,'raw_whole_region_coverage':raw_union.covers(region),**merge})
    write(OUT/'pending-queries.json',queries[len(qsummary):]);msummary=[]
    if len(qsummary)==20:
        for case in mutual:
            p=OLD/'mutual'/f"{case['index']:03d}.json";r=load(p);assert r['case']==case and r['complete_forbidden_covered'];shutil.copyfile(p,OUT/'mutual'/p.name);msummary.append({**case,'faces':len(r['faces']),'outside_halfplanes':sum(len(f['outside_halfplanes']) for f in r['faces']),'source_sha256':digest(p),'reused_byte_for_byte':True})
    write(OUT/'pending-mutual.json',mutual[len(msummary):]);write(OUT/'query-summary.json',qsummary);write(OUT/'mutual-summary.json',msummary)
    physical=[]
    for a,b in combinations(parts,2):
        modes=[]
        for qa,qb in product(a['queries'],b['queries']):
            x,y=queries[qa],queries[qb]
            if x['sheet']==y['sheet']:modes.append({'query_a':qa,'query_b':qb,'mutual_case':next(c['index'] for c in mutual if (c['profile_a'],c['profile_b'])==(x['profile'],y['profile']))})
        physical.append({'parts':[a['part'],b['part']],'items':[a['index'],b['index']],'same_sheet_modes':modes})
    assert len(physical)==78;write(OUT/'physical-pair-inventory.json',physical);witnesschecks=[]
    if len(qsummary)==20:
        for r in load(REG/'prior-ten-part-membership.json'):
            qi=r['query'];x,y=r['anchor_units1000'];matches=[]
            for row,d in enumerate(domains_by_query[qi]):
                b=d['coordinate_bounds']
                if b[0]<=x<=b[2] and b[1]<=y<=b[3] and all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes']):matches.append({'row':row,'domain_index':d['index']})
            witnesschecks.append({'item':r['item'],'query':qi,'anchor_units1000':r['anchor_units1000'],'matching_domains':matches})
        write(OUT/'repaired-partial-domain-membership.json',witnesschecks)
    result={'seconds':time.perf_counter()-start,'queries_planned':20,'queries_completed':len(qsummary),'queries_pending':20-len(qsummary),'allowed_raw_faces':total,'allowed_domains':sum(r['domains'] for r in qsummary),'discarded_allowed_faces':sum(r['discarded_faces'] for r in qsummary),'raw_queries_with_uncovered_area':sum(r['raw_uncovered_area_mm2']>0 for r in qsummary),'mutual_cases_reused':len(msummary),'mutual_cases_pending':82-len(msummary),'forbidden_convex_faces':sum(r['faces'] for r in msummary),'outside_halfplanes':sum(r['outside_halfplanes'] for r in msummary),'physical_pairs':78,'physical_same_sheet_query_pair_modes':sum(len(r['same_sheet_modes']) for r in physical),'repaired_partial_anchors_without_domain':[r['item'] for r in witnesschecks if not r['matching_domains']],'required_originals':66,'moving_originals':13,'fixed_originals':53,'merge_cap_geometries':sum(r['merge_cap_reached'] for r in qsummary),'merge_time_geometries':sum(r['merge_time_reached'] for r in qsummary),'face_cap_reached':total>=200000,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
