"""One separately declared bounded call for the audited twelve-original model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,sys,subprocess,traceback
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-partial59-source-search-20261026';RUN=BASE/'shared-search';PREP=ROOT/'output/h5-partial59-source-model-20261026';SOURCE=ROOT/'output/h5-partial59-joint-prepared-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    OUT=RUN/'solve';OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');start=time.perf_counter()
    import ortools
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2,sat_parameters_pb2
    from ortools.sat.python import cp_model
    checks=load(PREP/'audit/checks.json');assert checks['passed'] and checks['every_variable_and_constraint_independently_reconstructed'] and checks['no_old_capacity_transferred']
    for n,h in load(PREP/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    for n,h in load(PREP/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    paths=[p for p in PREP.rglob('*') if p.is_file()]+[SOURCE/'plan.json',RUN/'budget.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'maximum_solver_calls':1,'workers':8,'random_seed':0,'solver_cap_seconds':45,'shutdown_reserve_seconds':10,'method':'One distinct seven-mover search fixes59 verified originals from the64-part partial and moves original brackets27/28/29 plus cogs53/54/58/61. All66 originals remain mandatory. Fresh inward domains, all21 physical pairs and294 nonempty same-sheet modes preserve original shapes and guarded spacing. The other294 empty-query modes are impossible because their selectors are forced false. Two exact original-area inequalities are freshly reconstructed. No prior capacity or conditional exclusion is transferred. Four cog positions supply24 advisory hints. One45second solver call inside60seconds shared import/search/readback,8workers,seed0,10seconds reserve. Every previous call remains closed. No retry, reseed, extension or production qualification.'})
    expected=cp_model_pb2.CpModelProto();expected.ParseFromString((PREP/'model.pb').read_bytes());model=cp_model.CpModel();assert model.proto.parse_text_format((PREP/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'model.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());assert actual==expected
    mapping=load(PREP/'mapping.json');assert len(mapping['parts'])==7 and len(mapping['source_pair_faces'])==294 and len(actual.variables)==88210 and len(actual.constraints)==121712 and len(actual.solution_hint.vars)==24
    remaining=load(RUN/'budget.json')['deadline_perf_counter']-time.perf_counter()-10;assert remaining>0
    params={'max_time_in_seconds':min(45,remaining),'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False};solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params);(OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    audit={'passed':True,'preparation_seconds':time.perf_counter()-start,'variables':88210,'constraints':121712,'hints':24,'required_originals':66,'moving_originals':7,'fixed_originals':59,'original_anchor_variables':14,'complete_source_pair_mode_uses':294,'all_original_full_guarded_source_clauses_retained':True,'actual_import_export_matches_independent_audit':True,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'remaining_shared_budget_at_parameter_set':remaining,'shutdown_reserve_seconds':10,'python':sys.version,'ortools':ortools.__version__};write(OUT/'model-audit.json',audit);print(audit,flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':params['max_time_in_seconds'],'model_sha256':audit['model_sha256']})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();code=solver.solve(model);elapsed=time.perf_counter()-start
    response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(OUT/'response.pb').write_bytes(response.SerializeToString());positive=code in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    if positive:
        def value(i):return response.solution[i]
        selected=[];spec=load(SOURCE/'plan.json')
        for p in mapping['parts']:
            ms=[m for m in p['modes'] if value(m['active'])];assert len(ms)==1;m=ms[0];ds=[i for i,v in enumerate(m['domains']) if value(v)];assert len(ds)==1;q=spec['queries'][m['query']];d=load(SOURCE/'queries'/f"{m['query']:03d}.json")['domains'][ds[0]]
            selected.append({'part':p['part'],'item':p['item'],'family':p['family'],'query':m['query'],'domain_row':ds[0],'domain_index':d['index'],'profile':q['profile'],'sheet':q['sheet'],'choice_index':value(p['choice'])})
        write(OUT/'selection.json',{'fixed_items':spec['fixed_items'],'movable_parts':selected,'required_originals':66});write(OUT/'original-positions.json',[{'part':p['part'],'x_units':value(p['x']),'y_units':value(p['y'])} for p in mapping['simultaneous_original_coordinates']])
    result={'status':solver.status_name(code),'seconds':elapsed,'solver_calls':1,'has_full_guarded_source_candidate':positive,'response_stats':solver.response_stats(),'scope':'One distinct seven-mover search fixes59 verified originals from the64-part partial and moves original brackets27/28/29 plus cogs53/54/58/61. All66 originals remain mandatory. Fresh inward domains, all21 physical pairs and294 nonempty same-sheet modes preserve original shapes and guarded spacing. The other294 empty-query modes are impossible because their selectors are forced false. Two exact original-area inequalities are freshly reconstructed. No prior capacity or conditional exclusion is transferred. Four cog positions supply24 advisory hints. One45second solver call inside60seconds shared import/search/readback,8workers,seed0,10seconds reserve. Every previous call remains closed. No retry, reseed, extension or production qualification. A negative only excludes this finite59-fixed construction.','full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
def main():
    BASE.mkdir();RUN.mkdir();shutil.copyfile(__file__,RUN/'run.py');start=time.perf_counter();deadline=start+60;assert load(PREP/'audit/checks.json')['passed']
    write(RUN/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':60,'start_perf_counter':start,'deadline_perf_counter':deadline,'solver_cap_seconds':45,'solver_shutdown_reserve_seconds':10,'maximum_solver_calls':1,'workers':8,'random_seed':0,'previous_calls_remain_closed':True})
    write(RUN/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [PREP/'audit/checks.json',Path(__file__)]},'method':'One distinct seven-mover search fixes59 verified originals from the64-part partial and moves original brackets27/28/29 plus cogs53/54/58/61. All66 originals remain mandatory. Fresh inward domains, all21 physical pairs and294 nonempty same-sheet modes preserve original shapes and guarded spacing. The other294 empty-query modes are impossible because their selectors are forced false. Two exact original-area inequalities are freshly reconstructed. No prior capacity or conditional exclusion is transferred. Four cog positions supply24 advisory hints. One45second solver call inside60seconds shared import/search/readback,8workers,seed0,10seconds reserve. Every previous call remains closed. No retry, reseed, extension or production qualification.'})
    began=time.perf_counter();record={}
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=max(.01,deadline-time.perf_counter()));record={'seconds':time.perf_counter()-began,'exit_code':p.returncode};(RUN/'master-stdout.txt').write_bytes(p.stdout);(RUN/'master-stderr.txt').write_bytes(p.stderr);write(RUN/'master-process.json',record);print(p.stdout.decode(errors='replace'),flush=True);status='MASTER_'+load(RUN/'solve/result.json')['status'] if p.returncode==0 else 'STAGE_FAILED'
    except subprocess.TimeoutExpired as e:
        (RUN/'master-stdout.txt').write_bytes(e.stdout or b'');(RUN/'master-stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-began,'timeout':True};status='SHARED_BUDGET_PROCESS_TIMEOUT'
    result={'status':status,'elapsed_seconds':time.perf_counter()-start,'shared_budget_seconds':60,'stage':record,'solver_calls_opened':int((RUN/'solve/opened.json').exists()),'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(RUN/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:child() if '--child' in sys.argv else main()
    except Exception:
        folder=RUN/'solve' if '--child' in sys.argv else RUN
        if folder.exists():(folder/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
