"""Independent inward-domain proof and complete reused-profile-pair verification."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
from collections import Counter
import json,math,shutil,time,traceback
from shapely.geometry import shape
from shapely.ops import unary_union
from audit_h5_full_original_joint_domains import check_planes
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-partial59-joint-prepared-20261026';REG=ROOT/'output/h5-partial59-fixed-regions-20261026';OLD=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();spec=load(BASE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [x for x in BASE.rglob('*') if x.is_file() and OUT not in x.parents]+[ROOT/'output/audit_h5_full_original_joint_domains.py']},'method':'Use the independently audited new59-fixed region/inventory chain. Verify every raw allowed face,1e-6mm inset, discard, inward integer bound and independently implemented rational coefficient-error inequality. Reused82 mutual obstacles are checked byte-for-byte against committed sources with their prior independent full-original triangle/clearance proof; independently re-evaluate every outside-plane rounding. Reconstruct the full21 physical pair/588 mode inventory and all repaired partial domain matches. No old fixed54, fixed61 or fixed62 conditional table/capacity/area exclusion is transferred. No solver or production qualification.'})
    for n,h in spec['inputs'].items():assert digest(ROOT/n)==h,n
    for n,h in load(REG/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    assert load(REG/'audit/checks.json')['passed']
    known=set()
    for name in ['h5-full-original-joint-20261025','h5-source-area-and-direction-sharing-20261026']:
        m=load(ROOT/'benchmarks/results'/name/'raw-manifest.json');known.update(r['sha256'] for r in m['files']+m['aliases'])
    oldcheck=load(OLD/'audit/checks.json');assert oldcheck['passed'] and oldcheck['every_independent_whole_forbidden_region_covered'] and digest(OLD/'audit/checks.json') in known
    profiles=load(BASE/'profiles.json');assert profiles==load(OLD/'profiles.json')==load(REG/'profiles.json') and digest(OLD/'profiles.json') in known
    assert spec['parts']==load(REG/'plan.json')['parts'] and spec['queries']==load(REG/'plan.json')['queries']
    assert len(spec['parts'])==7 and spec['fixed_items']==[r['item'] for r in load(REG/'fixed-originals.json')] and len(spec['fixed_items'])==59
    assert Counter(p['family'] for p in spec['parts'])=={'bracket':3,'cog':4}
    fixed=load(REG/'fixed-originals.json');assert Counter(r['family'] for r in fixed)+Counter(p['family'] for p in spec['parts'])==Counter(spec['required_original_counts'])
    assert spec['fixed_original_area_units_per_sheet']==load(REG/'plan.json')['fixed_original_area_units_per_sheet']==[3811701744,349788154]
    assert not load(BASE/'pending-queries.json') and not load(BASE/'pending-mutual.json');qchecks=[];inside=0;domains={}
    for q in spec['queries']:
        qi=q['index'];p=REG/'queries'/f'{qi:03d}.json';r=load(BASE/'queries'/p.name);region=shape(load(p)['free_region']);assert r['query']==q and r['source_query_sha256']==digest(p)
        rows=r['domains']+r['discarded_faces'];assert sorted(x['index'] for x in rows)==list(range(r['raw_faces']));union=unary_union([shape(x['raw_face']) for x in rows]);missing=region.difference(union);assert missing.equals(shape(r['raw_uncovered_geometry'])) and missing.area==r['raw_uncovered_area_mm2'] and union.covers(region)==r['raw_union_covers_whole_region']
        for d in rows:
            raw=shape(d['raw_face']);assert raw.is_valid and raw.equals(raw.convex_hull);inset=raw.buffer(-.000001,join_style='mitre')
            if inset.is_empty:assert d['reason']=='empty conservative inset';continue
            assert shape(d['inset_face']).equals_exact(inset,0) and inset.equals(inset.convex_hull) and region.covers(inset)
            b=list(map(F,inset.bounds));want=[math.ceil(b[0]*1000),math.ceil(b[1]*1000),math.floor(b[2]*1000),math.floor(b[3]*1000)];assert want==d['coordinate_bounds']
            if want[0]>want[2] or want[1]>want[3]:assert d['reason']=='empty inward grid bounding box';continue
            assert 'reason' not in d and 0<=want[0]<=want[2]<=1500000 and 0<=want[1]<=want[3]<=3000000;inside+=check_planes(inset,d['halfplanes'],True)
        domains[qi]=r['domains'];qchecks.append({'query':qi,'raw_faces':len(rows),'domains':len(r['domains']),'discarded':len(r['discarded_faces']),'raw_uncovered_area_mm2':missing.area})
    desired=sorted({(a,b) for p,q in combinations(spec['parts'],2) for a,b in product(p['profiles'],q['profiles'])});expected=load(OLD/'plan.json')['mutual_cases'];assert expected==spec['mutual_cases'] and len(expected)==82 and len(desired)==73;assert [c['index'] for c in expected if (c['profile_a'],c['profile_b']) in desired]==spec['used_mutual_cases'];assert spec['unused_profile_queries']==[16,17]
    outside=faces=0;provenance=[]
    for c in expected:
        old=OLD/'mutual'/f"{c['index']:03d}.json";new=BASE/'mutual'/old.name;assert new.read_bytes()==old.read_bytes() and digest(old) in known;data=load(new);assert data['case']==c and data['complete_forbidden_covered']
        for f in data['faces']:outside+=check_planes(shape(f['expanded_face']),f['outside_halfplanes'],False);faces+=1
        provenance.append({'case':c['index'],'sha256':digest(new),'prior_independent_geometry_proof_reused':True,'outside_plane_rounding_rechecked':True})
    inventory=[]
    for p,q in combinations(spec['parts'],2):
        modes=[]
        for a,b in product(p['queries'],q['queries']):
            qa,qb=spec['queries'][a],spec['queries'][b]
            if qa['sheet']==qb['sheet']:modes.append({'query_a':a,'query_b':b,'mutual_case':next(c['index'] for c in expected if (c['profile_a'],c['profile_b'])==(qa['profile'],qb['profile']))})
        inventory.append({'parts':[p['part'],q['part']],'items':[p['index'],q['index']],'same_sheet_modes':modes})
    assert inventory==load(BASE/'physical-pair-inventory.json') and len(inventory)==21 and sum(len(r['same_sheet_modes']) for r in inventory)==588
    witness=[]
    for r in load(REG/'prior-four-cog-membership.json'):
        qi=r['query'];x,y=r['anchor_units1000'];matches=[]
        for row,d in enumerate(domains[qi]):
            b=d['coordinate_bounds']
            if b[0]<=x<=b[2] and b[1]<=y<=b[3] and all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes']):matches.append({'row':row,'domain_index':d['index']})
        assert matches;witness.append({'item':r['item'],'query':qi,'anchor_units1000':r['anchor_units1000'],'matching_domains':matches})
    assert witness==load(BASE/'repaired-partial-domain-membership.json') and len(witness)==4
    write(OUT/'query-checks.json',qchecks);write(OUT/'mutual-provenance.json',provenance);write(OUT/'verified-partial-domain-membership.json',witness)
    checks={'passed':True,'seconds':time.perf_counter()-start,'required_originals':66,'moving_originals':7,'fixed_originals':59,'full_original_profiles':10,'all20_fresh_queries_verified':True,'raw_allowed_faces':sum(r['raw_faces'] for r in qchecks),'accepted_inward_domains':sum(r['domains'] for r in qchecks),'recorded_discarded_faces':sum(r['discarded'] for r in qchecks),'inward_halfplanes_verified':inside,'reused_mutual_cases_verified_against_committed_bytes':len(provenance),'forbidden_convex_faces':faces,'outward_halfplanes_reverified':outside,'physical_pairs':21,'same_sheet_query_pair_modes':588,'all4_prior_cog_anchors_representable':True,'no_old_fixed54_fixed61_or_fixed62_conditional_exclusion_transferred':True,'all_counts_source_angles_original_shapes_and_native_guards_retained':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
