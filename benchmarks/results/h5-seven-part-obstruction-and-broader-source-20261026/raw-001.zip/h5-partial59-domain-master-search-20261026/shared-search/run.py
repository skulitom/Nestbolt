"""One bounded necessary-master call; no coordinate or native feasibility assertion."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,sys,subprocess,traceback
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-partial59-domain-master-search-20261026';RUN=BASE/'shared-search';PREP=ROOT/'output/h5-partial59-domain-master-20261026';SOURCE=ROOT/'output/h5-partial59-joint-prepared-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    OUT=RUN/'solve';OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');start=time.perf_counter()
    import ortools
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2,sat_parameters_pb2
    from ortools.sat.python import cp_model
    assert load(PREP/'audit/checks.json')['every_variable_and_constraint_reconstructed']
    for plan in [PREP/'plan.json',PREP/'audit/plan.json']:
        for n,h in load(plan)['inputs'].items():assert digest(ROOT/n)==h,n
    paths=[p for p in PREP.rglob('*') if p.is_file()]+[SOURCE/'plan.json',RUN/'budget.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'One necessary domain-only master call: all66 originals,7 mandatory domain choices, complete fresh raw-original conflicts, two exact area rules, independently certified copy ordering and no inherited capacity. No coordinates or full source face planes are represented. A positive needs a separate original-coordinate construction and full geometry/native validation. At most20solver seconds within30shared loading/import/search seconds, five seconds reserved for shutdown. All prior calls remain closed; no retry or reseed. Offline preparation is not production qualification.'})
    expected=cp_model_pb2.CpModelProto();expected.ParseFromString((PREP/'model.pb').read_bytes());model=cp_model.CpModel();assert model.proto.parse_text_format((PREP/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'model.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());assert actual==expected and len(actual.variables)==7937 and len(actual.constraints)==2514 and len(actual.solution_hint.vars)==16
    mapping=load(PREP/'mapping.json');assert len(mapping['parts'])==7 and len(mapping['groups'])==1326;remaining=load(RUN/'budget.json')['deadline_perf_counter']-time.perf_counter()-5;assert remaining>0;params={'max_time_in_seconds':min(20,remaining),'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False};solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params);(OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');audit={'passed':True,'preparation_seconds':time.perf_counter()-start,'variables':7937,'constraints':2514,'hints':16,'required_originals':66,'moving_originals':7,'fixed_originals':59,'original_anchor_variables':0,'domain_conflict_pair_mode_uses':588,'necessary_master_only':True,'actual_import_export_matches_independent_audit':True,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'remaining_shared_budget_at_parameter_set':remaining,'shutdown_reserve_seconds':5,'python':sys.version,'ortools':ortools.__version__};write(OUT/'model-audit.json',audit);print(audit,flush=True);write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':params['max_time_in_seconds'],'model_sha256':audit['model_sha256']})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();code=solver.solve(model);elapsed=time.perf_counter()-start
    response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(OUT/'response.pb').write_bytes(response.SerializeToString());positive=code in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    if positive:
        selected=[];spec=load(SOURCE/'plan.json')
        for p in mapping['parts']:
            modes=[m for m in p['modes'] if response.solution[m['active']]];assert len(modes)==1;m=modes[0];ds=[i for i,v in enumerate(m['domains']) if response.solution[v]];assert len(ds)==1;q=spec['queries'][m['query']];d=load(SOURCE/'queries'/f"{m['query']:03d}.json")['domains'][ds[0]];selected.append({'part':p['part'],'item':p['item'],'family':p['family'],'query':m['query'],'domain_row':ds[0],'domain_index':d['index'],'profile':q['profile'],'sheet':q['sheet'],'choice_index':response.solution[p['choice']]})
        write(OUT/'selection.json',{'fixed_items':spec['fixed_items'],'movable_parts':selected,'required_originals':66})
    result={'status':solver.status_name(code),'seconds':elapsed,'solver_calls':1,'has_necessary_domain_candidate':positive,'response_stats':solver.response_stats(),'scope':'Necessary domain-only master for all66 originals,7 movers in59-fixed fresh domains. A positive has no coordinate witness; negative is conditional on this finite source construction and not unrestricted packing impossibility.','full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
def main():
    BASE.mkdir();RUN.mkdir();shutil.copyfile(__file__,RUN/'run.py');start=time.perf_counter();deadline=start+30;assert load(PREP/'audit/checks.json')['passed'];write(RUN/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':30,'start_perf_counter':start,'deadline_perf_counter':deadline,'solver_cap_seconds':20,'solver_shutdown_reserve_seconds':5,'maximum_solver_calls':1,'workers':8,'random_seed':0,'previous_calls_remain_closed':True});write(RUN/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [PREP/'audit/checks.json',Path(__file__)]},'method':'One necessary-master call, at most20solver seconds within30shared seconds with5seconds reserved for shutdown. No original-coordinate feasibility or native validation claim. No restart/extension/reseed.'});began=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=max(.01,deadline-time.perf_counter()));record={'seconds':time.perf_counter()-began,'exit_code':p.returncode};(RUN/'master-stdout.txt').write_bytes(p.stdout);(RUN/'master-stderr.txt').write_bytes(p.stderr);write(RUN/'master-process.json',record);print(p.stdout.decode(errors='replace'),flush=True);status='MASTER_'+load(RUN/'solve/result.json')['status'] if p.returncode==0 else 'STAGE_FAILED'
    except subprocess.TimeoutExpired as e:
        (RUN/'master-stdout.txt').write_bytes(e.stdout or b'');(RUN/'master-stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-began,'timeout':True};status='SHARED_BUDGET_PROCESS_TIMEOUT'
    result={'status':status,'elapsed_seconds':time.perf_counter()-start,'shared_budget_seconds':30,'stage':record,'solver_calls_opened':int((RUN/'solve/opened.json').exists()),'necessary_master_only':True,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(RUN/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:child() if '--child' in sys.argv else main()
    except Exception:
        folder=RUN/'solve' if '--child' in sys.argv else RUN
        if folder.exists():(folder/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
