"""Complete domain-box conflict census using strictly interior original NFPs."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations,product
import json,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import shape,mapping

ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-partial59-joint-prepared-20261026';OUT=ROOT/'output/h5-partial59-domain-conflicts-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(SOURCE/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'cases').mkdir();(OUT/'cores').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    spec=load(SOURCE/'plan.json');queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']}
    mutual={(r['profile_a'],r['profile_b']):r['index'] for r in spec['mutual_cases']}
    tuples=sorted({(qa,qb) for a,b in combinations(spec['parts'],2) for qa,qb in product(a['queries'],b['queries']) if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']})
    cases=[]
    for i,(qa,qb) in enumerate(tuples):
        a,b=spec['queries'][qa],spec['queries'][qb];na,nb=len(queries[qa]['domains']),len(queries[qb]['domains'])
        cases.append({'index':i,'query_a':qa,'query_b':qb,'sheet':a['sheet'],'mutual_case':mutual[(a['profile'],b['profile'])],
                      'rows_a':na,'rows_b':nb,'domain_pairs':na*nb})
    caseindex={(r['query_a'],r['query_b']):r['index'] for r in cases};uses=[]
    for a,b in combinations(spec['parts'],2):
        ids=[caseindex[(qa,qb)] for qa,qb in product(a['queries'],b['queries']) if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']]
        uses.append({'parts':[a['part'],b['part']],'cases':ids})
    assert len(cases)==146 and len(uses)==21 and sum(len(r['cases']) for r in uses)==588
    count=sum(r['domain_pairs'] for r in cases);assert count<=25000000
    inputs=[SOURCE/'plan.json',SOURCE/'audit/checks.json',ROOT/'benchmarks/results/h5-expanded-cog-neighborhood-20261026/raw-manifest.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'query_hashes':{str(i):digest(SOURCE/'queries'/f'{i:03d}.json') for i in queries},
        'mutual_hashes':{str(r['index']):digest(SOURCE/'mutual'/f"{r['index']:03d}.json") for r in spec['mutual_cases']},
        'construction_limit_seconds':240,'maximum_domain_pairs':25000000,'coordinate_units_per_mm':1000,
        'difference_rectangle_padding_units':1,'raw_forbidden_inset_mm':.0001,'required_verified_inset_mm':.00009,
        'cases':cases,'physical_pair_case_uses':uses,'complete_domain_pair_census':count,
        'method':'For every same-sheet allowed query/domain pair needed by the7 mandatory originals, form the whole signed anchorB-anchorA bounding rectangle. Expand each integer difference bound by1 grid unit before floating conversion. Certify conflict only when the complete rectangle is strictly contained in an explicitly inset raw original collision region. No sampled corner-only proof, clearance-envelope substitute, convex cog hull restriction or inferred conflict for untested pairs. All146 unique query pairs and their588 physical uses are listed before construction. Store row-major big-endian packed bits with explicit tested rows, domain order, hashes and pending records. A marked bit forbids only these two specific full-original convex domains from simultaneous selection. No solver call.'})
    start=time.perf_counter();deadline=start+240;cores={};corechecks=[]
    for case in spec['mutual_cases']:
        assert time.perf_counter()<deadline
        row=load(SOURCE/'mutual'/f"{case['index']:03d}.json");raw=shape(row['raw_forbidden']);core=raw.buffer(-.0001,join_style='mitre').intersection(raw)
        assert not core.is_empty and raw.covers(core);margin=raw.boundary.distance(core);assert margin>=.00009
        write(OUT/'cores'/f"{case['index']:03d}.json",{'case':case,'core':mapping(core),'verified_raw_boundary_margin_mm':margin,'raw_original_sha256':digest(SOURCE/'mutual'/f"{case['index']:03d}.json")})
        shapely.prepare(core);cores[case['index']]=core;corechecks.append({'case':case['index'],'boundary_margin_mm':margin})
    summary=[];tested=conflicts=0
    for case in cases:
        if time.perf_counter()>=deadline:break
        da=queries[case['query_a']]['domains'];db=queries[case['query_b']]['domains'];a=np.array([r['coordinate_bounds'] for r in da],dtype=np.int64).reshape(-1,4);b=np.array([r['coordinate_bounds'] for r in db],dtype=np.int64).reshape(-1,4)
        blocks=[];rows=0;found=0
        for offset in range(0,len(a),32):
            if time.perf_counter()>=deadline:break
            aa=a[offset:offset+32];bounds=[b[None,:,0]-aa[:,None,2]-1,b[None,:,1]-aa[:,None,3]-1,b[None,:,2]-aa[:,None,0]+1,b[None,:,3]-aa[:,None,1]+1]
            rectangles=shapely.box(*[v/1000 for v in bounds]);flags=shapely.contains_properly(cores[case['mutual_case']],rectangles)
            assert flags.shape==(len(aa),len(b));blocks.append(flags);rows+=len(aa);found+=int(np.count_nonzero(flags))
        bits=np.concatenate(blocks,axis=0).reshape(-1) if blocks else np.array([],dtype=bool)
        binary=np.packbits(bits,bitorder='big').tobytes();path=OUT/'cases'/f"{case['index']:03d}.bin"
        with path.open('xb') as f:f.write(binary)
        row={**case,'tested_rows_a':rows,'tested_domain_pairs':rows*len(b),'conflicts':found,'remaining_rows_a':len(a)-rows,
            'domain_indices_a':[r['index'] for r in da],'domain_indices_b':[r['index'] for r in db],'packed_bit_order':'big','packed_layout':'row-major A then B',
            'packed_bytes':len(binary),'packed_sha256':digest(path)}
        write(OUT/'cases'/f"{case['index']:03d}.json",row);summary.append({k:v for k,v in row.items() if not k.startswith('domain_indices')})
        tested+=rows*len(b);conflicts+=found
        if len(summary)%20==0:print({'cases':len(summary),'tested_pairs':tested,'conflicts':conflicts,'seconds':time.perf_counter()-start},flush=True)
        if rows<len(a):break
    pending=[{**c,'first_untested_row_a':summary[c['index']]['tested_rows_a'] if c['index']<len(summary) else 0} for c in cases if c['index']>=len(summary) or summary[c['index']]['remaining_rows_a']]
    write(OUT/'pending-cases.json',pending);write(OUT/'case-summary.json',summary);write(OUT/'core-checks.json',corechecks)
    result={'seconds':time.perf_counter()-start,'unique_query_pair_cases':len(cases),'physical_part_pairs':21,'physical_query_pair_uses':588,
        'complete_domain_pair_census':count,'tested_domain_pairs':tested,'certified_conflicts':conflicts,'remaining_domain_pairs':count-tested,
        'completed_cases':sum(r['remaining_rows_a']==0 for r in summary),'pending_cases':len(pending),'raw_original_cores':len(cores),
        'minimum_verified_raw_inset_mm':min(r['boundary_margin_mm'] for r in corechecks),'independent_audit_pending':True,
        'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
