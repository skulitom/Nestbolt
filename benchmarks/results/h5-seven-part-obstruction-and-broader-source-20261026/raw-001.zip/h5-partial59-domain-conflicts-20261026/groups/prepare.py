"""Lossless compression of identical conflict rows for Boolean propagation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time,traceback
import numpy as np

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-partial59-domain-conflicts-20261026';OUT=BASE/'groups'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();spec=load(BASE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_limit_seconds':60,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'result.json',BASE/'audit/checks.json']},
        'method':'Losslessly group identical B-conflict bit rows for each complete query pair. Preserve every A row, including rows with no conflict. For a physical pair, selected A rows in a group are already mutually exclusive because one mandatory original chooses one domain. Their sum can therefore equal one Boolean group flag; an at-most-one constraint over that flag and all incompatible B-domain selectors is exactly the recorded binary conflicts. If every B row is forbidden, use its query-active flag instead. No additional geometry exclusion, solver call or pair omission.'})
    counts=Counter(i for p in spec['physical_pair_case_uses'] for i in p['cases']);summaries=[]
    for case in spec['cases']:
        metadata=load(BASE/'cases'/f"{case['index']:03d}.json");binary=BASE/'cases'/f"{case['index']:03d}.bin";assert digest(binary)==metadata['packed_sha256']
        bits=np.unpackbits(np.frombuffer(binary.read_bytes(),dtype=np.uint8),bitorder='big')[:case['domain_pairs']].reshape(case['rows_a'],case['rows_b'])
        groups={}
        for i,row in enumerate(bits):
            key=np.packbits(row,bitorder='big').tobytes()
            if key not in groups:groups[key]=[]
            groups[key].append(i)
        records=[{'group':j,'rows_a':rows,'forbidden_b_hex':key.hex(),'conflicts_per_a_row':sum(byte.bit_count() for byte in key)} for j,(key,rows) in enumerate(groups.items())]
        assert sum(len(r['rows_a'])*r['conflicts_per_a_row'] for r in records)==metadata['conflicts']
        nonzero=[r for r in records if r['conflicts_per_a_row']];lits=sum(2 if r['conflicts_per_a_row']==case['rows_b'] else 1+r['conflicts_per_a_row'] for r in nonzero)
        write(OUT/f"{case['index']:03d}.json",{'case':case,'source_metadata_sha256':digest(BASE/'cases'/f"{case['index']:03d}.json"),'source_packed_sha256':digest(binary),'groups':records})
        summaries.append({'case':case['index'],'groups':len(records),'nonzero_groups':len(nonzero),'physical_uses':counts[case['index']],
            'group_auxiliaries_per_use':sum(len(r['rows_a'])>1 for r in nonzero),'at_most_one_literals_per_use':lits,
            'source_conflicts':metadata['conflicts']})
    result={'seconds':time.perf_counter()-start,'complete_cases':len(summaries),'unique_groups':sum(r['groups'] for r in summaries),
        'unique_nonzero_groups':sum(r['nonzero_groups'] for r in summaries),'physical_nonzero_group_uses':sum(r['physical_uses']*r['nonzero_groups'] for r in summaries),
        'physical_group_auxiliaries':sum(r['physical_uses']*r['group_auxiliaries_per_use'] for r in summaries),
        'physical_at_most_one_literals':sum(r['physical_uses']*r['at_most_one_literals_per_use'] for r in summaries),
        'represented_unique_conflicts':sum(r['source_conflicts'] for r in summaries),'represented_physical_conflicts':sum(r['physical_uses']*r['source_conflicts'] for r in summaries),
        'independent_audit_pending':True,'solver_calls':0,'H5_complete':False}
    write(OUT/'summary.json',summaries);write(OUT/'result.json',result);assert result['seconds']<60;print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
