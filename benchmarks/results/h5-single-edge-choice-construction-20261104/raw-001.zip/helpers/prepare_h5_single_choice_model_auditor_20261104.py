"""Keep the independent proto reader; replace obstacle assertions with region/count proofs."""
from pathlib import Path
O=Path(__file__).resolve().parent
old=(O/'audit_h5_first57_edge_model_20261104.py').read_text(encoding='utf-8')
prefix='''from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-single-choice-regions-20261104';MODEL=BASE/'model';OUT=BASE/'model-audit'
EDGE=ROOT/'output/h5-first57-edge-companion-v2-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63);MAX=2**63-1
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for folder in [BASE,MODEL,BASE/'audit']:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(BASE/'audit/checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes())
assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints'}
mapping=load(MODEL/'mapping.json');modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');regions=load(BASE/'regions.json')
rectangles=load(BASE/'mode-rectangles.json');raw_components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json')
assert mapping['position_units_per_mm']==100 and mapping['world_origin_mm']==[0,0] and mapping['rectangle_gap_grid']==23 and mapping['full_physical_stock']
assert mapping['omitted_cog_sites']==[4,5,10] and mapping['bracket_group_counts']==[5,1]
assert len(mapping['owners'])==len(instances)==12
'''
owners=old[old.index('used_v=set();used_c=set()'):old.index("empty=mapping['empty_site_selectors']")]
region='''region_count=0;counts=[0,0]
for o in mapping['owners']:
    family=o['identity'][0]
    group=(1 if o['identity']==['bracket',9] else 0) if family=='bracket' else None
    assert o['assigned_group']==group
    if family=='bracket':counts[group]+=1
    expected=[i for i,r in enumerate(regions) if r['family']==family and r['group']==group]
    assert [r['region'] for r in o['regions']]==expected
    for r in o['regions']:
        ri=r['region'];source=regions[ri];v=r['selector']
        variable(v,f'region_{o["owner"]}_{ri}',[0,1])
        a,b,c,d=source['bounds_grid'];assert len(r['constraints'])==2
        linear(r['constraints'][0],{o['positions'][0]:1},a,c,v)
        linear(r['constraints'][1],{o['positions'][1]:1},b,d,v)
        region_count+=1
    assert len(o['region_mode_constraints'])==len(o['modes'])
    for m,ct in zip(o['modes'],o['region_mode_constraints']):
        co={r['selector']:1 for r in o['regions'] if regions[r['region']]['mode']==m['mode']}
        co[m['selector']]=-1;linear(ct,co,0,0)
assert counts==[5,1]
'''
components=old[old.index("assert len(mapping['components'])"):old.index("by_mask={r['mask']")]
end='''assert len(mapping['packing_groups'])==len(groups)==8
for actual,g in zip(mapping['packing_groups'],groups):
    assert {k:v for k,v in actual.items() if k!='constraint'}==g
    index=actual['constraint'];assert index not in used_c;used_c.add(index);ct=p.constraints[index]
    assert {f.name for f,v in ct.ListFields()}=={'no_overlap_2d'}
    assert list(ct.no_overlap_2d.x_intervals)==[mapping['components'][i]['interval_constraints'][0] for i in g['components']]
    assert list(ct.no_overlap_2d.y_intervals)==[mapping['components'][i]['interval_constraints'][1] for i in g['components']]
expected_symmetry=[]
for family,group in [('bracket',0),('insert',None)]:
    peers=sorted((o for o in mapping['owners'] if o['identity'][0]==family and o['assigned_group']==group),key=lambda o:o['identity'][1])
    expected_symmetry.extend((family,group,a['owner'],b['owner']) for a,b in zip(peers,peers[1:]))
assert [(s['family'],s['group'],*s['owners']) for s in mapping['symmetry_constraints']]==expected_symmetry
for s in mapping['symmetry_constraints']:
    a,b=s['owners'];linear(s['constraint'],{2*a:1,2*b:-1},MIN,0)
assert used_v==set(range(len(p.variables))) and used_c==set(range(len(p.constraints)))
ledger=load(MODEL/'final-preparation-charges.json')
for name,h in ledger['inputs'].items():assert digest(ROOT/name)==h
expected={k:v for k,v in load(EDGE/'model/final-preparation-charges.json')['charges'].items() if k!='model_complete_process_seconds'}
processes={
    'necessary_source_bodies_complete_process_seconds':'h5-first57-necessary-rectangles-process-20261104',
    'fresh_fixed33_inner_bodies_complete_process_seconds':'h5-first57-edge-necessary-necessary-rectangles-process-20261104',
    'fixed33_necessary_bracket_cover_complete_process_seconds':'h5-first57-edge-necessary-necessary-mask-cover-process-20261104',
    'fixed33_necessary_bracket_capacities_complete_process_seconds':'h5-first57-edge-necessary-component-area-v2-process-20261104',
    'positive_single_choice_regions_complete_process_seconds':'h5-first57-edge-single-choice-regions-process-20261104',
    'model_complete_process_seconds':'h5-first57-edge-single-choice-model-process-20261104'}
for key,folder in processes.items():
    record=load(ROOT/'output'/folder/'process.json');assert record['exit_code']==0 and not record['timeout'] and record['closed']
    expected[key]=record['complete_process_seconds']
assert ledger['charges']==expected and ledger['preparation_seconds_charged']==sum(expected.values())
internal=load(MODEL/'preparation-charges.json');t=internal.pop('model_internal_seconds_pending_complete_process_charge')
assert internal=={k:v for k,v in expected.items() if k!='model_complete_process_seconds'} and t==ledger['internal_model_seconds_replaced'] and t<expected['model_complete_process_seconds']
assert ledger['algorithm_seconds']==60 and ledger['shared_seconds']==90 and ledger['source_validation_reserve_seconds']==4 and ledger['maximum_calls']==1 and not ledger['retry_permitted']
assert len(p.variables)==3111 and len(p.constraints)==6611 and mode_count==72 and links==480 and region_count==2907
inputs=[Path(__file__),ROOT/'output/prepare_h5_single_choice_model_auditor_20261104.py',ROOT/'output/audit_h5_first57_edge_model_20261104.py',EDGE/'model/final-preparation-charges.json']+[ROOT/'output'/folder/'process.json' for folder in processes.values()]+[BASE/n for n in ['plan.json','audit/plan.json','audit/checks.json','regions.json','family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','group-counts.json']]+[MODEL/n for n in ['plan.json','checks.json','model.pb','model.pbtxt','mapping.json','preparation-charges.json','final-preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Every proto variable and constraint is independently reconstructed. Each owner has exactly one legal mode and exactly one positive region for that mode. Region bounds imply separation from every fixed source. All18 source-covering components are linked rigidly to their owner; eight groups preserve all147 moving component pairs. Identical bracket copies are relabelled into necessary groups of five and one, with no cross-group symmetry ordering. Source proof, full inventory and complete preparation ledger remain mandatory before one call.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'all_model_fields_exhaustively_verified':True,'variables_verified':len(used_v),'constraints_verified':len(used_c),
    'legal_mode_selectors_verified':mode_count,'positive_region_selectors_verified':region_count,'rigid_coordinate_links_verified':links,'global_moving_groups_verified':8,
    'fixed_obstacle_intervals':0,'mandatory_bracket_group_counts':[5,1],'symmetry_rows_within_group':9,'all66_inventory_geometry_audited':True,
    'preparation_seconds_charged':ledger['preparation_seconds_charged'],'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),
    'maximum_calls':1,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
'''
with (O/'audit_h5_edge_single_choice_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+owners+region+components+end)
print('Prepared independent exhaustive model auditor.')
