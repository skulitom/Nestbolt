from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_first57_edge_response_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-edge-companion-v2-20261104','h5-first57-edge-single-choice-regions-20261104')
# The inherited companion geometry/process remains a real source dependency.
s=s.replace("'h5-first57-edge-single-choice-regions-process-20261104'","'h5-first57-edge-companion-v2-process-20261104'")
s=s.replace('h5-first57-edge-model-process-20261104','h5-first57-edge-single-choice-model-process-20261104')
a='assert charges==expected'
b='''for folder,key in [
    ('h5-first57-necessary-rectangles-process-20261104','necessary_source_bodies_complete_process_seconds'),
    ('h5-first57-edge-necessary-necessary-rectangles-process-20261104','fresh_fixed33_inner_bodies_complete_process_seconds'),
    ('h5-first57-edge-necessary-necessary-mask-cover-process-20261104','fixed33_necessary_bracket_cover_complete_process_seconds'),
    ('h5-first57-edge-necessary-component-area-v2-process-20261104','fixed33_necessary_bracket_capacities_complete_process_seconds'),
    ('h5-first57-edge-single-choice-regions-process-20261104','positive_single_choice_regions_complete_process_seconds')]:
    p=load(ROOT/'output'/folder/'process.json');assert p['exit_code']==0 and not p['timeout'] and p['closed']
    expected[key]=p['complete_process_seconds']
assert charges==expected'''
assert a in s;s=s.replace(a,b)
s=s.replace('==250','==3111').replace('==18918','==6611').replace("'model_variables':250","'model_variables':3111").replace("'model_constraints':18918","'model_constraints':6611")
s=s.replace('UNKNOWN','INFEASIBLE')
s=s.replace('response.num_branches==4234 and response.num_conflicts==623','response.num_branches==33983 and response.num_conflicts==422')
s=s.replace("assert 'Starting search at 6.63s' in (SEARCH/'solver.log').read_text()","assert 'Starting search at ' in (SEARCH/'solver.log').read_text()")
s=s.replace("'search_started_after_solver_seconds':6.63,","")
s=s.replace("assert load(BASE/'audit/checks.json')['prior_unverified_cover_failure_preserved']","assert load(BASE/'audit/checks.json')['mandatory_bracket_counts']==[5,1]")
with (O/'audit_h5_edge_single_choice_response_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared independent closed-response auditor; no continuous infeasibility inference.')
