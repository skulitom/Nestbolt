"""Seal the independently audited unary-region construction and its sole closed call."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-single-edge-choice-construction-20261104';OUT=ROOT/'benchmarks/results'/NAME
BASE=ROOT/'output/h5-first57-edge-single-choice-regions-20261104'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
for folder in ['audit','model-audit','response-audit']:assert load(BASE/folder/'checks.json')['passed']
response=load(BASE/'response-audit/checks.json')
assert response['closed_solver_calls']==1 and response['solver_status']=='INFEASIBLE' and response['assignments']==0 and response['solve_slice_overrun_seconds']==response['algorithm_overrun_seconds']==response['shared_overrun_seconds']==0
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')]
setup=setup.replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for name in ['h5-first57-edge-single-choice-regions-20261104','h5-first57-edge-single-choice-regions-process-20261104','h5-first57-edge-single-choice-model-process-20261104']:
    folder=ROOT/'output'/name
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*single_choice*20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-single-edge-choice-report-20261104.md']:add('helpers/'+name,ROOT/'output'/name)
old_cap=ROOT/'output/h5-first57-component-area-20261104'
for name in ['audit/plan.json','audit/checks.json','audit/retained-choices.json']:add('next-method-inputs/'+name,old_cap/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(BASE/'audit/checks.json','region-audit.json'),(BASE/'model-audit/checks.json','model-audit.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'source-checks.json','source45-checks.json'),(BASE/'model/final-preparation-charges.json','preparation-charges.json'),(BASE/'search/result.json','closed-result.json')]:shutil.copyfile(source,OUT/name)
choices=load(old_cap/'audit/retained-choices.json');maximum=max(r['bracket_capacity'] for r in choices);highest=[r for r in choices if r['bracket_capacity']==maximum]
assert maximum==12 and [r['empty_sites'] for r in highest]==[[5,11,13],[5,11,14]]
write(OUT/'next-step.json',{'closed_call_must_not_be_repeated':True,'closed_model_sha256':response and load(BASE/'model-audit/checks.json')['model_sha256'],'closed_status':'INFEASIBLE','continuous_exclusion':False,
    'fixed33_continuous_choices_remaining':1,'fixed29_continuous_choices_remaining':259,'largest_bracket_capacity_choices':highest,
    'next_method':'Release the two fixed edge brackets and two fixed adjoining inserts, returning to the audited fixed29 and sixteen original movers. Compare joint eight-bracket/eight-insert source-body capacities for the two largest existing bracket-capacity choices, [5,11,13] and [5,11,14], without claiming that the capacity upper bounds are attainable or excluding unexamined choices. A new positive region/count construction must rebuild source-safe unary regions for the selected pose set and retain all sixteen originals. Charge the complete upstream necessary-body, cover and component-capacity preparation used to select the candidates, plus every new stage, before a separately audited frozen60/90-second call. Do not restart any old all-choice or fixed33 model.',
    'new_broader_model_prepared':False,'remaining_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'positive_integer_cells':215479371,'positive_construction_regions':519,
    'model_variables':3111,'model_constraints':6611,'closed_solver_calls':1,'solver_status':'INFEASIBLE','assignments':0,'charged_preparation_seconds':response['preparation_seconds_charged'],
    'algorithm_seconds_including_preparation':response['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':response['shared_seconds_including_preparation'],'overruns_seconds':0,
    'new_continuous_exclusions':0,'whole_allocation_candidates':440,'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-single-edge-choice-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 single edge-choice construction:** [independent source/model/response audits]({link}) verify 215,479,371 integer arrangement cells, 519 positive placement regions and every field of a 3,111-variable / 6,611-constraint model. The necessary five/one bracket split is enforced with all twelve originals retained. Its sole call closes grid-INFEASIBLE in 1.941110 s, with no assignment. Complete preparation is 15.811935 s; algorithm/shared totals 18.618379/18.694793 s pass with zero overruns. This is not a continuous-source exclusion and the call remains closed. Next compare joint bracket/insert bounds for the two largest-capacity broader fixed29 choices before a genuinely different construction. The broader 259 choices, all 440 allocations, full66 validation and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [shelf and edge capacity proofs](../benchmarks/results/h5-shelf-and-edge-capacity-proofs-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [single edge-choice construction](../benchmarks/results/{NAME}.md).',1)
a='choice open. The broader fixed29 frontier remains 259 choices. A new positive\nconstruction and fully charged model remain to develop; all prior calls stay closed.'
b='choice open. Its new positive-region model closes grid-INFEASIBLE without a\nplacement or overrun. The broader fixed29 frontier remains 259 choices; joint\nbracket/insert bounds for its two largest-capacity choices are next to assess.\nAll prior calls stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
