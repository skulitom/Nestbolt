"""Reuse audited rigid-component plumbing; replace obstacle packing by region/count geometry."""
from pathlib import Path
O=Path(__file__).resolve().parent
old=(O/'build_h5_first57_edge_model_20261104.py').read_text(encoding='utf-8')
prefix='''from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-single-choice-regions-20261104';OUT=BASE/'model'
EDGE=ROOT/'output/h5-first57-edge-companion-v2-20261104';PRE=ROOT/'output/h5-first57-direct-short9-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
assert load(BASE/'audit/checks.json')['passed']
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'build.py')
modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');rectangles=load(BASE/'mode-rectangles.json')
raw_components=load(BASE/'components.json');groups=load(BASE/'pair-cover-groups.json');regions=load(BASE/'regions.json')
'''
owners=old[old.index('model=cp_model.CpModel()'):old.index('empty=[model.new_bool_var')]
regioncode='''# Identical bracket copies can be relabelled: reserve copy9 for the one-body group.
for owner in owners:
    family=owner['identity'][0]
    group=(1 if owner['identity']==['bracket',9] else 0) if family=='bracket' else None
    owner['assigned_group']=group;owner['regions']=[]
    for ri,r in enumerate(regions):
        if r['family']!=family or r['group']!=group:continue
        selector=model.new_bool_var(f'region_{owner["owner"]}_{ri}').index
        a,b,c,d=r['bounds_grid']
        cts=[linear({owner['positions'][axis]:1},lo,hi,selector) for axis,lo,hi in [(0,a,c),(1,b,d)]]
        owner['regions'].append({'region':ri,'selector':selector,'constraints':cts})
    owner['region_mode_constraints']=[]
    for m in owner['modes']:
        co={r['selector']:1 for r in owner['regions'] if regions[r['region']]['mode']==m['mode']}
        co[m['selector']]=-1
        owner['region_mode_constraints'].append(linear(co,0,0))
'''
components=old[old.index('components=[];intervals_x=[]'):old.index('fixed_x=[];fixed_y=[]')]
end='''packing=[]
for g in groups:
    ct=model.add_no_overlap_2d([intervals_x[i] for i in g['components']],[intervals_y[i] for i in g['components']])
    packing.append({**g,'constraint':ct.index})
symmetry=[]
for family,group in [('bracket',0),('insert',None)]:
    peers=sorted((o for o in owners if o['identity'][0]==family and o['assigned_group']==group),key=lambda o:o['identity'][1])
    for a,b in zip(peers,peers[1:]):
        symmetry.append({'family':family,'group':group,'owners':[a['owner'],b['owner']],'constraint':linear({a['positions'][0]:1,b['positions'][0]:-1},cp_model.INT_MIN,0)})
validation=model.validate();write(OUT/'validation.json',{'validation':validation});assert not validation
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
mapping={'owners':owners,'components':components,'packing_groups':packing,'symmetry_constraints':symmetry,'position_units_per_mm':100,
    'world_origin_mm':[0,0],'rectangle_gap_grid':23,'full_physical_stock':True,'omitted_cog_sites':[4,5,10],'bracket_group_counts':[5,1]}
write(OUT/'mapping.json',mapping)
elapsed=time.perf_counter()-started
inherited=load(EDGE/'model/final-preparation-charges.json')['charges']
charges={k:v for k,v in inherited.items() if k!='model_complete_process_seconds'}
processes={
    'necessary_source_bodies_complete_process_seconds':'h5-first57-necessary-rectangles-process-20261104',
    'fresh_fixed33_inner_bodies_complete_process_seconds':'h5-first57-edge-necessary-necessary-rectangles-process-20261104',
    'fixed33_necessary_bracket_cover_complete_process_seconds':'h5-first57-edge-necessary-necessary-mask-cover-process-20261104',
    'fixed33_necessary_bracket_capacities_complete_process_seconds':'h5-first57-edge-necessary-component-area-v2-process-20261104',
    'positive_single_choice_regions_complete_process_seconds':'h5-first57-edge-single-choice-regions-process-20261104'}
for name,folder in processes.items():
    record=load(ROOT/'output'/folder/'process.json');assert record['exit_code']==0 and not record['timeout'];charges[name]=record['complete_process_seconds']
charges['model_internal_seconds_pending_complete_process_charge']=elapsed
write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),ROOT/'output/prepare_h5_single_choice_model_builder_20261104.py',ROOT/'output/build_h5_first57_edge_model_20261104.py',EDGE/'model/final-preparation-charges.json']+[ROOT/'output'/folder/'process.json' for folder in processes.values()]+[BASE/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','regions.json','family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','fixed33.json','group-counts.json']]+[PRE/'inventory.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New single-selection region model. Original fixed33 and twelve cog poses excluding4,5,10 are certified fixed obstacles. Each original mover selects one freshly certified positive anchor rectangle and its original mode. Bracket copy9 is assigned to the one-capacity group; the other five identical copies to the five-capacity group, a pure relabelling of necessary counts. X ordering is only within a group/family. Eight global moving-rectangle groups cover all147 different-owner component pairs; no fixed-obstacle interval remains because every unary region is independently safe against all fixed sources. All stock/mode constraints and rigid rectangle links remain explicit. No previous solver call or old solution is used.',
    'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False})
checks={'passed':True,'seconds':elapsed,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),
    'owners':12,'legal_mode_selectors':72,'region_selectors':sum(len(o['regions']) for o in owners),'rigid_components':18,'coordinate_links':coordinate_links,
    'global_pair_groups':len(groups),'fixed_obstacle_intervals':0,'same_group_symmetry_rows':len(symmetry),'bracket_counts':[5,1],
    'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'provisional_preparation_seconds':sum(charges.values()),
    'complete_process_charge_pending':True,'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
assert elapsed<15
write(OUT/'checks.json',checks);print(checks)
'''
with (O/'build_h5_edge_single_choice_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+owners+regioncode+components+end)
wrapper=(O/'run_h5_first57_edge_model_build_20261104.py').read_text(encoding='utf-8').replace('h5-first57-edge-model-process','h5-first57-edge-single-choice-model-process').replace('build_h5_first57_edge_model','build_h5_edge_single_choice_model')
with (O/'run_h5_edge_single_choice_model_build_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(wrapper)
finalizer=(O/'finalize_h5_first57_edge_budget_20261104.py').read_text(encoding='utf-8').replace('h5-first57-edge-companion-v2','h5-first57-edge-single-choice-regions').replace('h5-first57-edge-model-process','h5-first57-edge-single-choice-model-process')
with (O/'finalize_h5_edge_single_choice_budget_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(finalizer)
print('Created distinct positive-region model builder with necessary five/one assignment.')
