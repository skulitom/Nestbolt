"""Freeze the sole call and all66 original-source reader before execution."""
from pathlib import Path
O=Path(__file__).resolve().parent
for old,new in [('check_h5_first57_edge_candidate_20261104.py','check_h5_edge_single_choice_candidate_20261104.py'),('run_h5_first57_edge_model_20261104.py','run_h5_edge_single_choice_model_20261104.py')]:
    s=(O/old).read_text(encoding='utf-8').replace('h5-first57-edge-companion-v2','h5-first57-edge-single-choice-regions')
    s=s.replace('check_h5_first57_edge_candidate_20261104.py','check_h5_edge_single_choice_candidate_20261104.py')
    s=s.replace("BASE/'selection.json'","BASE/'group-counts.json'")
    s=s.replace("BASE/'inventory.json'","ROOT/'output/h5-first57-direct-short9-20261104/inventory.json'")
    s=s.replace("BASE / 'inventory.json'","ROOT/'output/h5-first57-direct-short9-20261104/inventory.json'")
    if old.startswith('check'):
        a="empty=[i for i,s in enumerate(mapping['empty_site_selectors']) if values[s]==1];occupied=[i for i in range(15) if i not in empty]"
        b="empty=mapping['omitted_cog_sites'];assert empty==[4,5,10];occupied=[i for i in range(15) if i not in empty]"
        assert a in s;s=s.replace(a,b)
    with (O/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Frozen one-call runner and original66 source reader.')
