from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_first57_necessary_rectangles_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-necessary-rectangles-process','h5-first57-edge-single-choice-regions-process').replace('prepare_h5_first57_necessary_rectangles','prepare_h5_edge_single_choice_regions')
with (O/'run_h5_edge_single_choice_regions_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
