"""Reconstruct all66 source originals from the new grouped model assignment."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from copy import deepcopy
import json,sys,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-single-choice-regions-20261104';SEARCH=BASE/'search';OUT=SEARCH/'source-response'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=float(sys.argv[1]);OUT.mkdir()
values=load(SEARCH/'assignment.json');mapping=load(BASE/'model/mapping.json');inventory=load(ROOT/'output/h5-first57-direct-short9-20261104/inventory.json')
rows=load(BASE/'fixed33.json')+load(PRE/'short9-source.json');selected=[]
for owner in mapping['owners']:
    chosen=[m for m in owner['modes'] if values[m['selector']]==1];assert len(chosen)==1;m=chosen[0]
    xy=[values[v]/mapping['position_units_per_mm']+mapping['world_origin_mm'][k] for k,v in enumerate(owner['positions'])]
    rows.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0',
        'transform':{'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':[xy[k]+m['translation_from_lower_left'][k] for k in [0,1]]}})
    selected.append({'identity':owner['identity'],'mode':m['mode'],'lower_left_mm':xy})
empty=mapping['omitted_cog_sites'];assert empty==[4,5,10];occupied=[i for i in range(15) if i not in empty]
assert len(empty)==3 and len(occupied)==12
sites=load(PRE/'source-cog-sites.json')
for site,identity in zip(occupied,inventory['required_cog12_identities']):
    r=deepcopy(sites[site]);r['part_id'],r['copy_index']=identity;rows.append(r)
spec=load(PRE/'plan.json');job=load(JOB)
check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],list(map(tuple,inventory['full66_identities'])))
assert len(rows)==66 and check['same_sheet_pairs']==1632 and check['stock_edges']==264 and check['cutouts']==90 and check['hole_vertices']==10026
write(OUT/'candidate-source66.json',rows);write(OUT/'original-source-checks.json',check);write(OUT/'selected-modes.json',selected)
write(OUT/'selected-sites.json',{'empty':empty,'occupied':occupied})
inputs=[Path(__file__),BASE/'fixed33.json',BASE/'group-counts.json',ROOT/'output/h5_legacy64_source_readback.py',JOB,BASE/'model/mapping.json',ROOT/'output/h5-first57-direct-short9-20261104/inventory.json',SEARCH/'assignment.json',SEARCH/'assignment-check.json']+[PRE/n for n in ['plan.json','fixed29.json','short9-source.json','source-cog-sites.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'source_valid66':check['valid'],'originals':66,'same_sheet_pairs':1632,'stock_edges':264,'cutouts':90,'hole_vertices':10026,
    'pair_failures':check['pair_failures'],'stock_failures':check['stock_failures'],'source_checker_calls':1,
    'algorithm_seconds_including_preparation':time.perf_counter()-started,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
