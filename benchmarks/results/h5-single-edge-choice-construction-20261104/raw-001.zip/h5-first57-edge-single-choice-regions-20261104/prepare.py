"""Positive integer-anchor regions for the sole necessary fixed33 cog selection."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-edge-single-choice-regions-20261104'
EDGE=ROOT/'output/h5-first57-edge-companion-v2-20261104';PRE=ROOT/'output/h5-first57-direct-short9-20261104'
NEC=ROOT/'output/h5-first57-edge-necessary-necessary-mask-cover-20261104';CAP=ROOT/'output/h5-first57-edge-necessary-component-area-v2-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),JOB,ROOT/'output/h5_legacy64_source_readback.py']+[EDGE/n for n in ['plan.json','audit/plan.json','audit/checks.json','source-cover-obstacles.json','family-modes.json','mode-rectangles.json','fixed33.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','selection.json']]+[PRE/n for n in ['plan.json','inventory.json','source-cog-sites.json']]+[NEC/n for n in ['audit/plan.json','audit/checks.json']]+[NEC/f'geometry-{gid:02d}-cover.json' for gid in range(8)]+[CAP/n for n in ['audit/plan.json','audit/checks.json','audit/retained-choices.json','choice-004.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Distinct positive construction for fixed33 and occupied cog sites excluding4,5,10. Use all original source-covering fixed rectangles and full-stock mode bounds. Expand moving outer component right/top by0.23mm, as already done for fixed rectangles. Every forbidden open anchor rectangle induces an exact interval of integer0.01mm anchors. Partition all integer domains at those transition coordinates, mark occupied cells, and cover free cells by boxes. Intersect bracket regions with the independently certified two necessary bracket groups, preserving their mandatory five/one counts. No positive grid infeasibility will exclude continuous originals. Fresh independent event-count safety and group-assignment audits are required before any model.',
    'coordinate_units_per_mm':100,'moving_right_top_extension_grid':23,'fixed_source_covers_already_expanded':True,'omitted_cog_sites':[4,5,10],
    'preparation_cap_seconds':25,'maximum_process_seconds':35,'maximum_cells_per_mode':40000000,'solver_calls':0,'native_calls':0})
for base in [EDGE,NEC,CAP]:assert load(base/'audit/checks.json')['passed']
assert load(CAP/'audit/retained-choices.json')==[{'index':4,'empty_sites':[5],'bracket_capacity':6,'group_capacities':[5,1]}]
modes=load(EDGE/'family-modes.json');rects=load(EDGE/'mode-rectangles.json')
obstacles=[r for r in load(EDGE/'source-cover-obstacles.json') if r['site_bit'] not in [4,5,10]]
assert {r['site_bit'] for r in obstacles}==set(range(16))-{4,5,10}
write(OUT/'active-source-cover-obstacles.json',obstacles)
fixed=load(EDGE/'fixed33.json');sites=load(PRE/'source-cog-sites.json')
control=fixed+[r for i,r in enumerate(sites) if i not in [4,5,10]]
spec=load(PRE/'plan.json')
checked=audit(load(JOB),control,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in control])
assert len(control)==45 and checked['valid']
write(OUT/'source45.json',control);write(OUT/'source-checks.json',checked)
groups=load(CAP/'choice-004.json')['groups'];assert [g['capacity'] for g in groups]==[5,1]
necessary=[load(NEC/f'geometry-{gid:02d}-cover.json') for gid in range(8)]
summaries=[];regions=[]
for family in ['bracket','insert']:
    for mode in modes[family]:
        mi=mode['mode'];tag=f'{family}-{mi:02d}';domain=mode['integer_lower_left_bounds']
        dx,dy=domain;forbidden=[]
        for oi,obs in enumerate(obstacles):
            u,v,w,z=obs['bounds_grid']
            for comp in rects[family][mi]['rectangles']:
                a,b,c,d=comp['outward_offsets_grid'];c+=23;d+=23
                # A < integer_anchor < C is the half-open integer interval [A+1,C).
                bounds=[max(dx[0],u-c+1),max(dy[0],v-d+1),min(dx[1]+1,w-a),min(dy[1]+1,z-b)]
                if bounds[0]<bounds[2] and bounds[1]<bounds[3]:forbidden.append({'obstacle':oi,'piece':comp['piece'],'integer_bounds_half_open':bounds})
        xs=np.array(sorted({dx[0],dx[1]+1}|{r['integer_bounds_half_open'][k] for r in forbidden for k in [0,2]}),dtype=np.int64)
        ys=np.array(sorted({dy[0],dy[1]+1}|{r['integer_bounds_half_open'][k] for r in forbidden for k in [1,3]}),dtype=np.int64)
        assert (len(xs)-1)*(len(ys)-1)<=40000000
        blocked=np.zeros((len(ys)-1,len(xs)-1),dtype=np.bool_)
        ix={int(v):i for i,v in enumerate(xs)};iy={int(v):i for i,v in enumerate(ys)}
        for r in forbidden:
            a,b,c,d=r['integer_bounds_half_open'];blocked[iy[b]:iy[d],ix[a]:ix[c]]=True
        np.savez_compressed(OUT/f'{tag}-classes.npz',xcuts_grid=xs,ycuts_grid=ys,blocked=blocked)
        boxes=[];active={}
        def close(key,span):
            xa,xb=key;ya,yb=span
            boxes.append([int(xs[xa]),int(ys[ya]),int(xs[xb])-1,int(ys[yb])-1,xa,ya,xb,yb])
        for yi,row in enumerate(blocked):
            changes=np.flatnonzero(np.diff(np.r_[False,~row,False])).tolist()
            current={}
            for xa,xb in zip(changes[::2],changes[1::2]):
                key=(xa,xb);current[key]=[active[key][0] if key in active else yi,yi+1]
            for key,span in active.items():
                if key not in current:close(key,span)
            active=current
        for key,span in active.items():close(key,span)
        boxes.sort();mode_regions=[]
        if family=='insert':
            for bi,box in enumerate(boxes):mode_regions.append({'family':family,'mode':mi,'group':None,'positive_box':bi,'necessary_box':None,'bounds_grid':box[:4]})
        else:
            gid=mode['normalized_geometry']
            for group_index,group in enumerate(groups):
                for ngid,ni in group['anchor_boxes']:
                    if ngid!=gid:continue
                    mask,a,b,c,d,*_=necessary[gid][ni];assert mask&~(1<<5)==0
                    inner=[-(-a//10),-(-b//10),c//10,d//10]
                    for bi,box in enumerate(boxes):
                        intersection=[max(box[0],inner[0]),max(box[1],inner[1]),min(box[2],inner[2]),min(box[3],inner[3])]
                        if intersection[0]<=intersection[2] and intersection[1]<=intersection[3]:mode_regions.append({'family':family,'mode':mi,'group':group_index,'positive_box':bi,'necessary_box':[gid,ni],'bounds_grid':intersection})
        write(OUT/f'{tag}-forbidden.json',forbidden);write(OUT/f'{tag}-free-boxes.json',boxes);write(OUT/f'{tag}-regions.json',mode_regions)
        regions.extend(mode_regions)
        summary={'family':family,'mode':mi,'forbidden_rectangles':len(forbidden),'cells':int(blocked.size),'free_cells':int((~blocked).sum()),'free_boxes':len(boxes),'construction_regions':len(mode_regions)}
        summaries.append(summary);print(summary,flush=True);assert time.perf_counter()-started<25
for name in ['family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','fixed33.json']:shutil.copyfile(EDGE/name,OUT/name)
write(OUT/'regions.json',regions);write(OUT/'mode-summaries.json',summaries)
write(OUT/'group-counts.json',{'required_brackets':6,'required_inserts':6,'bracket_group_counts':[5,1],'omitted_cog_sites':[4,5,10]})
checks={'prepared':True,'seconds':time.perf_counter()-started,'active_source_cover_obstacles':len(obstacles),'legal_modes':12,
    'all_integer_cells':sum(r['cells'] for r in summaries),'positive_free_boxes':sum(r['free_boxes'] for r in summaries),'construction_regions':len(regions),
    'bracket_regions_per_group':[sum(r['family']=='bracket' and r['group']==g for r in regions) for g in [0,1]],'insert_regions':sum(r['family']=='insert' for r in regions),
    'source_valid45':True,'source_valid66':False,'independent_positive_region_audit_pending':True,'continuous_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
