"""Independent event-count readback of every new positive anchor region."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,time,shutil,math
import numpy as np
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-single-choice-regions-20261104';OUT=BASE/'audit'
EDGE=ROOT/'output/h5-first57-edge-companion-v2-20261104';PRE=ROOT/'output/h5-first57-direct-short9-20261104'
NEC=ROOT/'output/h5-first57-edge-necessary-necessary-mask-cover-20261104';CAP=ROOT/'output/h5-first57-edge-necessary-component-area-v2-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,EDGE/'audit',NEC/'audit',CAP/'audit']:
    for p,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
for base in [EDGE,NEC,CAP]:assert load(base/'audit/checks.json')['passed']
for n in ['family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','fixed33.json']:assert digest(BASE/n)==digest(EDGE/n),n
obstacles=[r for r in load(EDGE/'source-cover-obstacles.json') if r['site_bit'] not in [4,5,10]]
assert obstacles==load(BASE/'active-source-cover-obstacles.json') and len(obstacles)==5255
rows=load(EDGE/'fixed33.json')+[r for i,r in enumerate(load(PRE/'source-cog-sites.json')) if i not in [4,5,10]]
spec=load(PRE/'plan.json')
source_check=audit(load(JOB),rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows])
assert source_check['valid'] and source_check==load(BASE/'source-checks.json') and rows==load(BASE/'source45.json') and len(rows)==45
inventory=load(PRE/'inventory.json');fixed=load(EDGE/'fixed33.json');remaining=load(EDGE/'selection.json')['remaining_moving12_identities']
assert sorted([[r['part_id'],r['copy_index']] for r in fixed]+remaining+inventory['required_cog12_identities']+inventory['short9_identities'])==sorted(inventory['full66_identities'])
assert load(CAP/'audit/retained-choices.json')==[{'index':4,'empty_sites':[5],'bracket_capacity':6,'group_capacities':[5,1]}]
groups=load(CAP/'choice-004.json')['groups'];necessary=[load(NEC/f'geometry-{g:02d}-cover.json') for g in range(8)]
group_boxes={}
for gi,g in enumerate(groups):
    for identity in g['anchor_boxes']:
        key=tuple(identity);assert key not in group_boxes;group_boxes[key]=gi
expected_necessary={(gid,ri) for gid,cover in enumerate(necessary) for ri,row in enumerate(cover) if row[0]&~(1<<5)==0}
assert set(group_boxes)==expected_necessary
modes=load(BASE/'family-modes.json');rects=load(BASE/'mode-rectangles.json');all_regions=[];summaries=[]
for family in ['bracket','insert']:
    for mode in modes[family]:
        mi=mode['mode'];tag=f'{family}-{mi:02d}';dx,dy=mode['integer_lower_left_bounds'];expected=[]
        for oi,obs in enumerate(obstacles):
            for comp in rects[family][mi]['rectangles']:
                a,b,c,d=comp['outward_offsets_grid'];u,v,w,z=obs['bounds_grid']
                open_bounds=(u-c-23,v-d-23,w-a,z-b)
                x0=max(dx[0],open_bounds[0]+1);x1=min(dx[1]+1,open_bounds[2])
                y0=max(dy[0],open_bounds[1]+1);y1=min(dy[1]+1,open_bounds[3])
                if x0<x1 and y0<y1:expected.append({'obstacle':oi,'piece':comp['piece'],'integer_bounds_half_open':[x0,y0,x1,y1]})
        assert expected==load(BASE/f'{tag}-forbidden.json')
        xs=sorted({dx[0],dx[1]+1}|{r['integer_bounds_half_open'][k] for r in expected for k in [0,2]})
        ys=sorted({dy[0],dy[1]+1}|{r['integer_bounds_half_open'][k] for r in expected for k in [1,3]})
        with np.load(BASE/f'{tag}-classes.npz',allow_pickle=False) as data:
            assert set(data.files)=={'xcuts_grid','ycuts_grid','blocked'}
            assert data['xcuts_grid'].dtype==data['ycuts_grid'].dtype==np.dtype('int64')
            assert data['xcuts_grid'].tolist()==xs and data['ycuts_grid'].tolist()==ys
            blocked=data['blocked'];assert blocked.dtype==np.dtype('bool') and blocked.shape==(len(ys)-1,len(xs)-1)
        ix={v:i for i,v in enumerate(xs)};iy={v:i for i,v in enumerate(ys)}
        counts=np.zeros((len(ys),len(xs)),dtype=np.int32)
        for r in expected:
            a,b,c,d=r['integer_bounds_half_open'];xa,xb,ya,yb=ix[a],ix[c],iy[b],iy[d]
            counts[ya,xa]+=1;counts[ya,xb]-=1;counts[yb,xa]-=1;counts[yb,xb]+=1
        np.cumsum(counts,axis=0,out=counts);np.cumsum(counts,axis=1,out=counts)
        assert counts.min()>=0 and counts.max()<=len(expected) and np.array_equal(counts[:-1,:-1]>0,blocked)
        del counts
        boxes=load(BASE/f'{tag}-free-boxes.json');covered=np.zeros(blocked.shape,dtype=np.uint8)
        for row in boxes:
            a,b,c,d,xa,ya,xb,yb=row
            assert all(type(v) is int for v in row) and 0<=xa<xb<len(xs) and 0<=ya<yb<len(ys)
            assert [a,b,c,d]==[xs[xa],ys[ya],xs[xb]-1,ys[yb]-1]
            assert a<=c and b<=d and not blocked[ya:yb,xa:xb].any()
            covered[ya:yb,xa:xb]+=1
        assert np.array_equal(covered,(~blocked).astype(np.uint8))
        # Rebuild intersections with exact rational units, independently of the preparation's division.
        expected_regions=[]
        if family=='insert':
            expected_regions=[{'family':family,'mode':mi,'group':None,'positive_box':i,'necessary_box':None,'bounds_grid':r[:4]} for i,r in enumerate(boxes)]
        else:
            gid=mode['normalized_geometry']
            for gi,g in enumerate(groups):
                for ngid,ni in g['anchor_boxes']:
                    if ngid!=gid:continue
                    bounds=necessary[gid][ni][1:5]
                    integer=[math.ceil(F(bounds[k],10)) if k<2 else math.floor(F(bounds[k],10)) for k in range(4)]
                    for bi,p in enumerate(boxes):
                        r=[max(p[0],integer[0]),max(p[1],integer[1]),min(p[2],integer[2]),min(p[3],integer[3])]
                        if r[0]<=r[2] and r[1]<=r[3]:expected_regions.append({'family':family,'mode':mi,'group':gi,'positive_box':bi,'necessary_box':[gid,ni],'bounds_grid':r})
        assert expected_regions==load(BASE/f'{tag}-regions.json');all_regions.extend(expected_regions)
        summary={'family':family,'mode':mi,'forbidden_rectangles':len(expected),'cells':int(blocked.size),'free_cells':int((~blocked).sum()),'free_boxes':len(boxes),'construction_regions':len(expected_regions)}
        summaries.append(summary);print(summary,flush=True)
assert summaries==load(BASE/'mode-summaries.json') and all_regions==load(BASE/'regions.json')
assert load(BASE/'group-counts.json')=={'required_brackets':6,'required_inserts':6,'bracket_group_counts':[5,1],'omitted_cog_sites':[4,5,10]}
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[BASE/n for n in ['plan.json','checks.json','active-source-cover-obstacles.json','source45.json','source-checks.json','regions.json','mode-summaries.json','group-counts.json','family-modes.json','mode-rectangles.json']]+[base/n for base in [EDGE,NEC,CAP] for n in ['audit/plan.json','audit/checks.json']]+[BASE/f'{family}-{m["mode"]:02d}-{suffix}' for family in ['bracket','insert'] for m in modes[family] for suffix in ['classes.npz','forbidden.json','free-boxes.json','regions.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'All fixed/moving source-covering rectangles and full-stock mode bounds are identical to the earlier exact audited geometry. Their right/top expansions imply at least0.23mm source gap when disjoint. For each component/fixed rectangle pair, every integer anchor causing overlap lies in the reconstructed forbidden half-open integer rectangle. Independent count events reproduce all blocked cells, and every free integer cell appears once in the positive box cover. Every construction region is either such a box or its exact intersection with an audited necessary bracket group. The separate necessary capacities imply group counts five/one. Pairwise moving-body separation remains to be modeled; these regions alone do not certify a complete layout. No continuous exclusion or negative grid status is inferred.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'active_source_cover_obstacles':5255,'legal_modes_verified':12,
    'integer_cells_independently_verified':sum(s['cells'] for s in summaries),'positive_free_boxes':sum(s['free_boxes'] for s in summaries),'construction_regions':len(all_regions),
    'bracket_regions_per_group':[sum(r['family']=='bracket' and r['group']==g for r in all_regions) for g in [0,1]],'insert_regions':sum(r['family']=='insert' for r in all_regions),
    'mandatory_bracket_counts':[5,1],'source_valid45':True,'full66_identity_partition_preserved':True,'source_valid66':False,'model_prepared':False,'continuous_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
