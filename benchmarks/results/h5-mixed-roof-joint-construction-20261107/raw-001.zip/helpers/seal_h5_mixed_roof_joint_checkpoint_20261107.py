"""Preserve expanded source-neighbor preflight, all closed calls and main sync."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-mixed-roof-joint-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-mixed-roof-joint-search-20261107';F=BASE/'response-audit';D=ROOT/'output/h5-mixed-roof-joint-neighbors-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-mixed-roof-continuous-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==49 and not front['source_valid66']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D]+[ROOT/'output'/n for n in ['h5-mixed-roof-joint-neighbors-preparation-process-20261107','h5-mixed-roof-joint-neighbors-audit-process-20261107','h5-mixed-roof-joint-response-audit-process-20261107','h5-mixed-roof-main-sync-20261107']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*mixed*roof*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_mixed_roof_joint_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"
}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
M=ROOT/'output/h5-mixed-roof-continuous-model-20261107';runtime={n:r['sha256'] for n,r in load(M/'audit-v2/tool-provenance.json')['tool_files'].items()}
for n,h in runtime.items():assert n.startswith('.cache/') and digest(ROOT/n)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(D/'audit/checks.json','neighbor-audit.json'),(D/'checks.json','neighbor-preparation.json'),(F/'checks.json','response-audit.json'),(F/'mode-selection-controls.json','mode-selection-controls.json'),(F/'round-reconciliation.json','round-reconciliation.json'),(F/f"round-{front['best_global_round']:02d}-collision-details.json",'source-failures.json'),(BASE/'process.json','closed-process.json'),(ROOT/'output/h5-mixed-roof-main-sync-20261107/receipt.json','prior-main-push-receipt.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'separately_pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
next_step={'status':'movable_roof_source_preflight_required','proposal':'Assess a broader source model that frees both roof frames as well as all33 current movers. Keep only the16 base frames and15 short-sheet originals fixed.','reason':'Allsix called vectors in the present fixed-roof geometry remain source-invalid. The joint selection included bracket/cog cell moves but did not choose one; changing the actual roof positions/orientations would change the available free space instead of repeating fixed-roof local calls. Improvement is unproven.','proposed_inventory':{'fixed_originals':31,'moving_originals':35,'moving_pairs':595,'center_parameters':70,'continuous_cog_angles':15,'continuous_parameters':85,'moving_frame_copies':[16,17]},'requirements':['Reconstruct the exact original frame450x350mm outer geometry and its hole, with legal rotations0/90/180/270 and no mirroring. Preserve original identities and forbid part-in-hole in common-line mode.','Build and independently certify new hard source-safe cells against only the16-frame base for every moving family, including all legal roof-frame orientations; derive every count and index from the new35-owner schema. Old33-owner/81-parameter verifiers are incompatible.','Prepare original and clearance frame outlines and independent gradients, stock corners, full595-pair scores, source66 replay and corruption controls before any optimization.','Use only unoptimized source geometry/initialization and charge all consumed preparation. No optimized candidate, source-only label, different objective or changed owner count authorizes a reset of a closed call.','Preserve both fixed-roof closed pipelines and all earlier outcomes. No new source domains, initializer, complete model or optimizer call currently exists for movable roof frames.'],'new_source_geometry_prepared':False,'new_complete_model_prepared':False,'new_optimizer_calls':0,'H5_complete':False}
write(OUT/'next-step.json',next_step)
ne=load(D/'audit/checks.json');selections=load(F/'mode-selection-controls.json');owners=load(M/'library.json')['identities'];selected=[' and '.join(f'{owners[i][0]} {owners[i][1]} (mode {mi})' for i,mi in r['selected_changes']) for r in selections]
report=f'''# Mixed frame roof: joint cell choices — 2026-11-07

The expanded search closes after **three new physical vectors and 17,001
proposal scores**. Its best candidate, from call1, remains invalid with
**49 failing original pairs** and **42,163.183280 mm²** total overlap. Every
fixed-part and stock check passes. The third candidate is worse and is preserved.
No native validation, allocation exclusion or H5 credit follows. H2/H5 remain
open at **60% completed milestone weight**.

## Expanded source neighborhood

The geometry, unoptimized initializer, 33 movers, 81 parameters and all fifteen
continuous cog angles come from the preceding independently checked
[continuous construction](h5-mixed-roof-continuous-construction-20261107.md).
This expansion adds joint bracket/insert and bracket/cog cell choices. It retains
both distinct cog regions and each cog's actual current continuous angle.

Every round considers **159 single-owner, 3,888 bracket/insert and 1,620
bracket/cog choices**, totaling 5,667 distinct physical vectors. Only changed
owners move to their nearest point within the new certified cells. Exact pair
corrections replace the old mutual interaction once, avoiding double counting.
The rule orders full scores rounded to 1e-6 mm², then owner/mode.

[Independent preflight]({NAME}/neighbor-audit.json) reconstructs every polygon
and sums all 1,056 original-plus-clearance pair terms for **5,668 full scores**.
It uses no cached interaction deltas. Every center, physical key, distinct choice
and rank is checked; maximum score difference is **6.1118044e-10 mm²**.
Complete neighbor preparation takes **0.801021 s**, bringing consumed source
and initializer preparation to **13.055456 s**. The 84.446407-second exhaustive
audit is validation only and does not initialize the search.

The lowest initial joint proposal matches a previously closed vector and is
excluded. All three vectors called by the preceding pipeline stay excluded;
no optimized predecessor coordinates are used. The new calls select changes
{'; then '.join(selected)}. The first changes a bracket and insert together; the later two
change one insert each. No bracket/cog joint proposal is selected.

## Closed execution and independent replay

Each new call is limited to thirteen seconds, within preparation-inclusive
60/90-second algorithm/shared limits, and each physical vector is called once.
[Independent response readback]({NAME}/response-audit.json) replays all
**{front['mode_trials_verified']:,} proposals, {front['saved_points_verified']} retained points and
{front['function_evaluations']} evaluation counters**, including every selection,
closed-vector exclusion, bound, gradient and model. The full-objective oracle
does not reuse the fast delta calculation.

All three candidates reconstruct all 66 originals, 1,380 same-sheet pairs,
264 stock edges, 90 holes and 10,026 hole vertices. The successive candidates
fail 51, 49 and 49 pairs. [The best candidate's original failures]({NAME}/source-failures.json)
remain explicit. The last candidate has 42,340.612008 mm² overlap and does not
replace the better second candidate.

The declared three-call limit closes the pipeline. Algorithm/shared totals are
**{front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s**, including all
preparation. All slice overruns are preserved in the response audit, with no
overall overrun. [All five search processes close]({NAME}/closed-process.json),
with peak aggregate committed memory **109,060,096 bytes**. None of the six
calls across the two fixed-roof pipelines may resume, repeat or receive a
reset clock. These heuristic failures do not prove a continuous layout impossible.

## Next geometry and repository

[The next source preflight]({NAME}/next-step.json) proposes freeing the two
roof frames while retaining the sixteen base frames and fifteen short-sheet
parts. This would give 35 movers, 85 continuous parameters and 595 moving pairs.
The original frame is a 450×350 mm rectangle with a hole, permits quarter turns,
and forbids mirroring. New frame/source domains, gradients, stock bounds,
inventory mapping and a complete model need independent verification first.
No new geometry or call is prepared; improvement remains unproven.

Four earlier fixed arrangements and 440 whole allocations remain unresolved.
Full66 source/native/material checks, production parity and the unchanged H5
matrix remain required. H2 retains its original gate and reserved vectors.
Production, README and releases are unchanged; no release qualifies.

[The two previous checkpoints reached main 61ae8141]({NAME}/prior-main-push-receipt.json)
after all six prior CI jobs and the aggregate run passed, using an ordinary
atomic fast-forward and preserving all 52 remote files. [Fresh main CI]({NAME}/main-ci-at-review.json)
is running. This new checkpoint awaits the ordinary push gate.
[Raw evidence]({NAME}/raw-manifest.json), [source bindings]({NAME}/source-bindings.json)
and [six pinned runtime files]({NAME}/runtime-bindings.json) preserve the complete
evidence chain without bundling installed vendor runtimes.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 mixed-roof joint choices:** [independent neighbor/model/response audits]({{link}}) verify all 5,667 distinct choices: 159 singles, 3,888 bracket/insert and 1,620 bracket/cog joint moves, retaining actual cog angles. All 5,668 initial full scores agree within 6.12e-10 mm². The best initial joint vector is already closed and remains excluded. Three new calls and 17,001 proposal scores close at the declared limit; {front["saved_points_verified"]} retained points and {front["function_evaluations"]} evaluations replay. Call 1 remains best with 49 failing pairs and 42,163.183280 mm² overlap; all fixed-part and stock checks pass. The worse third candidate is preserved. Complete preparation is 13.055456 s and algorithm/shared totals are {front["algorithm_seconds"]:.6f}/{front["shared_seconds"]:.6f} s. All slice overruns are retained and all processes close. No native call or allocation exclusion follows. Next assess a source model freeing both roof frames, with 35 movers, 85 parameters and 595 pairs against newly certified base-only hard domains; no new geometry or model is prepared. All six current fixed-roof calls stay closed. Four earlier fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%. The previous two checkpoints reached main 61ae8141 normally after all six prior checks passed, preserving 52 remote files; fresh CI is running. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [mixed-roof joint choices](../benchmarks/results/{NAME}.md).
The expanded model includes 159 single-owner, 3,888 bracket/insert and 1,620
bracket/cog choices. Independent full scoring verifies every initial proposal.
Three new calls and 17,001 scores close with 49 failing original pairs and
42,163.183280 mm² overlap in the best candidate. Every fixed-part and stock
check passes. All {front['saved_points_verified']} retained points and {front['function_evaluations']} evaluations replay; the worse
third candidate is preserved. Algorithm/shared totals are {front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s
including 13.055456 s preparation. All processes close and slice overruns remain
recorded. No full66 witness, native call or allocation exclusion follows.
Next assess freeing the two roof frames, yielding 35 movers, 85 parameters and
595 moving pairs. New source domains, model and initializer require independent
verification; none is prepared. All six fixed-roof calls remain closed.
Four earlier fixed arrangements and 440 allocations remain; H2/H5 stay open
at 60% completed milestone weight. Main 61ae8141 now includes both preceding
checkpoints after all six prior checks passed, preserving all 52 remote files.
Fresh CI is running; this checkpoint awaits the ordinary push gate. Full66
source/native/material checks, production parity and the unchanged H5 matrix
remain required. No release qualifies.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
