from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def transform(old,new,replacements):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in replacements:
        assert a in s,(old,a);s=s.replace(a,b)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
transform('h5_joint_cell_neighbors_20261107.py','h5_mixed_roof_joint_neighbors_20261107.py',[
 ('Single-owner and bracket/insert joint compound neighbors','Single-owner, bracket/insert and bracket/cog joint compound neighbors'),
 ('h5_hard_cell_direct_model_20261107','h5_hard_cell_vector_model_20261107'),
 ("library['identities'][:18]","library['identities']"),
 ("shape=owner_shapes(library,family,mi,center)","angle=values[66+i-18]/library['angle_scale_mm'] if family=='cog' else 0.;shape=owner_shapes(library,family,mi,center,angle)"),
 ("o['family']=='insert'","o['family'] in ['insert','cog']"),
 ('len(records)==1374','len(records)==5667')
])
common=[('h5-hard-cell-direct-model-20261107','h5-mixed-roof-continuous-model-20261107'),('h5-joint-cell-neighbors','h5-mixed-roof-joint-neighbors'),('h5_joint_cell_neighbors','h5_mixed_roof_joint_neighbors'),("BASE/'audit/","BASE/'audit-v2/"),('h5_hard_cell_direct_model_20261107','h5_hard_cell_vector_model_20261107')]
transform('prepare_h5_joint_cell_neighbors_20261107.py','prepare_h5_mixed_roof_joint_neighbors_20261107.py',common+[
 ('All 78 unique single-owner and 1296 bracket/insert two-owner physical compound neighbors.','All159 unique single-owner,3888 bracket/insert and1620 bracket/cog two-owner physical compound neighbors. Both cog cells are distinct; use each cog current continuous angle without changing it. No optimized predecessor values are consumed.'),
 ("'single_neighbors':78,'joint_neighbors':1296","'single_neighbors':159,'joint_neighbors':5508,'bracket_insert_joint_neighbors':3888,'bracket_cog_joint_neighbors':1620")
])
# Independent oracle sums every transformed pair; it does not reuse delta scores.
auditcommon=[r for r in common if r[0] not in ['h5_joint_cell_neighbors','h5_hard_cell_direct_model_20261107']]
transform('audit_h5_joint_cell_neighbors_20261107.py','audit_h5_mixed_roof_joint_neighbors_20261107.py',auditcommon+[
 ("lib['identities'][:18]","lib['identities']"),('for j in range(6,18)','for j in range(6,33)'),
 ('len(expected)==1374','len(expected)==5667'),
 ("'single_neighbors_verified':78,'joint_neighbors_verified':1296","'single_neighbors_verified':159,'joint_neighbors_verified':5508,'bracket_insert_joint_neighbors_verified':3888,'bracket_cog_joint_neighbors_verified':1620")
])
for phase in ['preparation','audit']:
    pairs=[('h5-joint-cell-neighbors','h5-mixed-roof-joint-neighbors'),('h5_joint_cell_neighbors','h5_mixed_roof_joint_neighbors')]
    if phase=='audit':pairs.append("unused") if False else pairs.append(('20261107.py\', 90)', '20261107.py\', 180)'))
    transform(f'run_h5_joint_cell_neighbors_{phase}_20261107.py',f'run_h5_mixed_roof_joint_neighbors_{phase}_20261107.py',pairs)
