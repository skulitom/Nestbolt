from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
common=[
 ('h5-hard-cell-direct-model-20261107','h5-mixed-roof-continuous-model-20261107'),
 ('h5-three-column-hard-cells-v2-20261107','h5-mixed-roof-hard-cells-20261107'),
 ('h5-joint-cell-search-20261107','h5-mixed-roof-joint-search-20261107'),
 ('h5-joint-cell-neighbors','h5-mixed-roof-joint-neighbors'),
 ("BASE/'audit/","BASE/'audit-v2/"),
 ("'audit/plan.json','audit/checks.json','audit/optimizer-controls.json','audit/tool-provenance.json','audit/physical-mode-controls.json'","'audit-v2/plan.json','audit-v2/checks.json','audit-v2/optimizer-controls.json','audit-v2/tool-provenance.json','audit-v2/physical-mode-controls.json'")
]
def transform(old,new,changes):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in common+changes:
        assert a in s,(old,a);s=s.replace(a,b)
    return s
runner=transform('run_h5_joint_cell_search_20261107.py','unused',[
 ('h5_joint_cell_neighbors','h5_mixed_roof_joint_neighbors'),
 ('h5-hard-cell-initializer-process-20261107/prepare.json','h5-mixed-roof-initializer-process-20261107/process.json'),
 ("'optimizer_slice_seconds':[14,14,14]","'optimizer_slice_seconds':[13,13,13]"),
 ('all 78 single and 1296 bracket/insert joint neighbors','all159 singles,3888 bracket/insert and1620 bracket/cog joint neighbors'),
])
start=runner.index("'method':'One finite expanded")
end=runner.index('});controls=',start)
method='One bounded expanded compound-neighborhood search over the changed mixed-frame-roof source geometry. At each round choose among all159 single-owner,3888 bracket/insert and1620 bracket/cog physical neighbors by full score rounded to1e-6 square mm then owner/mode. Preserve every current continuous cog angle, changing only selected cells and their clamped centers. Consume the prepared source-only neighbor table at roundzero; later rounds recompute at the current globalbest. Exclude all three vectors called by the preceding closed single-owner mixed-roof search and every new called vector. No optimized ancestor point initializes this search. The whole source/initializer charge12.254435799783096s plus the entire new neighbor preparation process are charged. At most three new vectors, thirteen seconds each, no restart, extension, weight change or closed-vector repeat. All33 centers and15angles remain free within certified harddomains. Verify each selected model and all66 originalsource parts after every call. Stop at validity, declared count, no unvisited neighbor, time or inconsistency. Preserve every result and overrun. No local outcome excludes an allocation.'
runner=runner[:start]+"'method':"+repr(method)+runner[end:]
with (ROOT/'output/run_h5_mixed_roof_joint_search_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(runner)
audit=transform('audit_h5_joint_cell_response_20261107.py','unused',[
 ("lib['identities'][:18]","lib['identities']"),('for j in range(6,18)','for j in range(6,33)'),
 ('==1374','==5667'),
 ("'single_owner_neighbors':78,'bracket_insert_joint_neighbors':1296","'single_owner_neighbors':159,'bracket_insert_joint_neighbors':3888,'bracket_cog_joint_neighbors':1620"),
 ('all 78 single-owner and 1296 joint bracket/insert proposals','all159 single-owner,3888 bracket/insert and1620 bracket/cog proposals'),
 ("result['status']=='MAXIMUM_CALLS' and calls==3 and not result['source_valid66']", "result['status'] in ['MAXIMUM_CALLS','ALGORITHM_TIME_STOP_AFTER_SOURCE_CHECK'] and calls==3 and not result['source_valid66'] and (result['status']=='MAXIMUM_CALLS' or result['rounds'][-1]['algorithm_seconds_including_preparation']>=56)")
])
with (ROOT/'output/audit_h5_mixed_roof_joint_response_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(audit)
wrapper=(ROOT/'output/run_h5_joint_cell_response_audit_20261107.py').read_text(encoding='utf-8')
wrapper=wrapper.replace('h5-joint-cell-response-audit-process','h5-mixed-roof-joint-response-audit-process').replace('audit_h5_joint_cell_response','audit_h5_mixed_roof_joint_response')
assert any(f', {seconds})' in wrapper or f',{seconds})' in wrapper for seconds in [90,150,180,240,300])
for seconds in [90,150,180,240,300]:
    wrapper=wrapper.replace(f', {seconds})',', 360)').replace(f',{seconds})',',360)')
with (ROOT/'output/run_h5_mixed_roof_joint_response_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(wrapper)
