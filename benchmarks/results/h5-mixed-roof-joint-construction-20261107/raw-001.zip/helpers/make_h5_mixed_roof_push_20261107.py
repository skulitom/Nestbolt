from pathlib import Path
root=Path(__file__).resolve().parent
s=(root/'push_h5_joint_cell_checkpoints_20261107.py').read_text(encoding='utf-8')
replacements=[('h5-joint-cell-main-sync-20261107','h5-mixed-roof-main-sync-20261107'),('c3af6112def6722a7b542d21afd776e605c001e5','6b81bf9dec163dcf8efa70b45ffce5a5ca8ce00d'),('42356841307','42359844894'),('h5-hard-cell-continuous-construction-20261107','h5-mixed-roof-contact-construction-20261107'),('h5-joint-cell-vector-construction-20261107','h5-mixed-roof-continuous-construction-20261107')]
for a,b in replacements:
    assert a in s;s=s.replace(a,b)
with (root/'push_h5_mixed_roof_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
