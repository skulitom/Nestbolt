"""Exhaustive independent full-objective replay of every joint proposal."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,time,shutil,math
import numpy as np
from shapely.geometry import Polygon
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-roof-continuous-model-20261107';PREP=ROOT/'output/h5-mixed-roof-joint-neighbors-20261107';OUT=PREP/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');lib=load(BASE/'library.json');initial=load(BASE/'initial-mode-values.json');modes=initial['modes'];values=np.asarray(initial['values']);classes=family_classes(lib);records=load(PREP/'neighbors.json');options={}
for i,(family,_) in enumerate(lib['identities']):
    seen={classes[family][modes[i]]};options[i]=[]
    for mi,c in enumerate(classes[family]):
        if c not in seen:options[i].append(mi);seen.add(c)
expected={((i,mi),) for i,opts in options.items() for mi in opts}
expected|={((i,mi),(j,mj)) for i in range(6) for mi in options[i] for j in range(6,33) for mj in options[j]}
assert len(expected)==5667 and expected=={tuple(map(tuple,r['changes'])) for r in records}
assert records==sorted(records,key=lambda r:(round(r['score_mm2'],6),tuple(map(tuple,r['changes']))))
def shapes(chosen,point):
    out=[]
    for i,(family,_) in enumerate(lib['identities']):
        mode=lib['family_modes'][family][chosen[i]];angle=point[66+i-18]/lib['angle_scale_mm'] if family=='cog' else mode['rotation_radians'];c,s=math.cos(angle),math.sin(angle);m=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];cx,cy=point[2*i:2*i+2]
        out.append([Polygon([(m*(x-px)*c-(y-py)*s+cx,m*(x-px)*s+(y-py)*c+cy) for x,y in lib['families'][family][kind]]) for kind in ['original','clearance']])
    return out
def score(chosen,point):
    polygons=shapes(chosen,point)
    # Independent full sum: no cached delta or interaction correction.
    return sum(polygons[i][k].intersection(polygons[j][k]).area for i in range(33) for j in range(i+1,33) for k in [0,1])
energy=score(modes,values);checks=load(PREP/'checks.json');assert abs(energy-checks['baseline_objective_mm2'])<1e-6
errors=[];keys=set()
for index,row in enumerate(records):
    chosen=modes.copy();point=values.copy()
    for (i,mi),center in zip(row['changes'],row['centers']):
        chosen[i]=mi;bb=lib['family_modes'][lib['identities'][i][0]][mi]['center_bounds_mm'];expected_center=[min(hi,max(lo,float(values[2*i+k]))) for k,(lo,hi) in enumerate(bb)];assert center==expected_center;point[2*i:2*i+2]=center
    key=physical_key(lib,classes,chosen);assert list(key)==row['physical_key'] and key not in keys;keys.add(key)
    actual=score(chosen,point);error=abs(actual-row['score_mm2']);assert error<1e-6,(index,actual,row['score_mm2']);errors.append(error)
write(OUT/'full-score-errors.json',errors)
for field,size in [('best_single',1),('best_joint',2)]:assert checks[field]==next(r for r in records if len(r['changes'])==size)
process=load(ROOT/'output/h5-mixed-roof-joint-neighbors-preparation-process-20261107/process.json');assert process['passed'] and process['closed'];charge=load(BASE/'audit-v2/checks.json')['complete_preparation_seconds']+process['complete_seconds']
inputs=[Path(__file__),BASE/'library.json',BASE/'initial-mode-values.json',BASE/'audit-v2/checks.json',PREP/'plan.json',PREP/'neighbors.json',PREP/'checks.json',ROOT/'output/h5-mixed-roof-joint-neighbors-preparation-process-20261107/process.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Enumerate all unique expected single and two-owner vectors, independently transform every original and clearance outline and sum all 528 pair energies. No delta function used by this audit.','optimizer_calls':0})
result={'passed':True,'seconds':time.perf_counter()-start,'single_neighbors_verified':159,'joint_neighbors_verified':5508,'bracket_insert_joint_neighbors_verified':3888,'bracket_cog_joint_neighbors_verified':1620,'full_scores_verified':len(records)+1,'pair_terms_per_full_score':1056,'maximum_absolute_score_difference_mm2':max(errors),'all_centers_and_physical_keys_verified':True,'best_single_objective_mm2':checks['best_single']['score_mm2'],'best_joint_objective_mm2':checks['best_joint']['score_mm2'],'complete_preparation_seconds':charge,'new_optimizer_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',result);print(result)
