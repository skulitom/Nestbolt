from pathlib import Path
from hashlib import sha256
import json,time,shutil
from h5_mixed_roof_joint_neighbors_20261107 import neighbors
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-mixed-roof-joint-neighbors-20261107';BASE=ROOT/'output/h5-mixed-roof-continuous-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),BASE/'library.json',BASE/'model.json',BASE/'initial-mode-values.json',BASE/'audit-v2/checks.json']+[ROOT/'output'/n for n in ['h5_mixed_roof_joint_neighbors_20261107.py','h5_hard_cell_vector_model_20261107.py','h5_hard_cell_compound_modes_20261107.py','h5_mixed_direct_pose_20261107.py']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'scope':'One source-only initial point. All159 unique single-owner,3888 bracket/insert and1620 bracket/cog two-owner physical compound neighbors. Both cog cells are distinct; use each cog current continuous angle without changing it. No optimized predecessor values are consumed. Clamp only changed owners to their new effective hard bounds. Exact pair-additive correction, ties rounded to 1e-6 square mm then owner/mode. No optimization or iterative construction.','prior_source_preparation_seconds':load(BASE/'audit-v2/checks.json')['complete_preparation_seconds'],'cap_seconds':30,'memory_bytes':2**31,'retry_permitted':False,'source_optimizer_calls':0})
lib=load(BASE/'library.json');initial=load(BASE/'initial-mode-values.json');energy,records=neighbors(lib,initial['modes'],initial['values'])
write(OUT/'neighbors.json',records);single=min((r for r in records if len(r['changes'])==1),key=lambda r:(round(r['score_mm2'],6),r['changes']));joint=min((r for r in records if len(r['changes'])==2),key=lambda r:(round(r['score_mm2'],6),r['changes']))
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'source_only_initial_point':True,'prior_optimized_point_consumed':False,'baseline_objective_mm2':energy,'single_neighbors':159,'joint_neighbors':5508,'bracket_insert_joint_neighbors':3888,'bracket_cog_joint_neighbors':1620,'unique_physical_neighbors':len(records),'best_single':single,'best_joint':joint,'source_optimizer_calls':0,'full_source_check_for_proposals':False,'source_valid66':False,'H5_complete':False});print({'neighbors':len(records),'baseline':energy,'best_single':single['score_mm2'],'best_joint':joint['score_mm2']})
