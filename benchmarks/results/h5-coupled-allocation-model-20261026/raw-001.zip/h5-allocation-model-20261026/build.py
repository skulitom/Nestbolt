"""Coupled optional source geometry; every original chooses exactly one sheet and mode."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
import json,math,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-allocation-geometry-20261026'
OUT=ROOT/'output/h5-allocation-model-20261026';AREA=ROOT/'output/h5-global-short-frontier-20261026/area-proof.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(GEO/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
inputs={p.relative_to(ROOT).as_posix():digest(p) for p in GEO.rglob('*') if p.is_file()}
inputs[AREA.relative_to(ROOT).as_posix()]=digest(AREA)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,
    'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'retry_permitted':False,
    'ignore_subsolvers':['fj'],'objective':None,'hints':False,'all66_originals_required':True,
    'method':'A new coupled allocation model, not a retry of any fixed-allocation call. Each original selects exactly one allowed sheet/geometry variant, with shared whole-stock X/Y anchors, a linked sheet bit and a sheet/Y key ordered among identical copies. All454 short count rows remain in a linked table. Two additional necessary filled-source area constraints use downward-rounded source areas and original target stock areas, not proxy areas. Optional source-contained coarse rectangles provide per-sheet NoOverlap2D. Separate source-capacity constraints use all non-cog rectangles plus16 all-angle cog inner-disk strips. Separate virtual-disk capacity constraints include cogs ONLY. No actual cog angle is selected by this necessary model; every real angle is covered. Independently verify the entire serialized model before one60-second solve within90 shared seconds; exclude fj. A necessary assignment is not a source/native witness. No unchanged retry or source-target relaxation is permitted.'})
vs=load(GEO/'variants.json');ds=load(GEO/'domains.json');originals=load(GEO/'originals.json');stocks=load(GEO/'stocks.json');allocations=load(GEO/'allowed-allocations.json')
areas={k:math.floor(F(*v)*1000000) for k,v in load(AREA)['filled_source_areas_rational'].items()}
area_caps=[]
for stock in stocks:
    b=[F(*v) for v in stock['target_bounds_rational']];area_caps.append(math.floor((b[2]-b[0])*(b[3]-b[1])*1000000))
model=cp_model.CpModel();records=[];coordinates=[];sheet_bits=[];keys=[];option_vars={}
for original in originals:
    i=original['index'];family=original['family'];allowed=[d for d in ds if d['allowed'] and vs[d['variant']]['family']==family]
    xv=model.new_int_var(min(d['bounds_um'][0] for d in allowed),max(d['bounds_um'][2] for d in allowed),f'x_{i}')
    yv=model.new_int_var(min(d['bounds_um'][1] for d in allowed),max(d['bounds_um'][3] for d in allowed),f'y_{i}')
    sheet=model.new_bool_var(f'sheet_{i}');key=model.new_int_var(0,8000000,f'key_{i}')
    options=[model.new_bool_var(f'option_{i}_{d["variant"]}_{d["sheet"]}') for d in allowed]
    choice=model.add_exactly_one(options);saved=[]
    for d,z in zip(allowed,options):
        b=d['bounds_um'];cts=[model.add(xv>=b[0]),model.add(yv>=b[1]),model.add(xv<=b[2]),model.add(yv<=b[3])]
        for ct in cts:ct.only_enforce_if(z)
        rec={'variant':d['variant'],'sheet':d['sheet'],'selector':z.index,'stock_constraints':[ct.index for ct in cts]};saved.append(rec);option_vars[i,d['variant'],d['sheet']]=z
    linked=model.add(sheet==sum(z for d,z in zip(allowed,options) if d['sheet']==1))
    key_ct=model.add(key==yv+4000000*sheet)
    records.append({'original_index':i,'coordinate_indices':[xv.index,yv.index],'sheet_index':sheet.index,'key_index':key.index,
                    'options':saved,'exactly_one_constraint':choice.index,'sheet_constraint':linked.index,'key_constraint':key_ct.index})
    coordinates.append([xv,yv]);sheet_bits.append(sheet);keys.append(key)
symmetry=[]
for family in ['frame','bracket','insert','cog']:
    ids=[p['index'] for p in originals if p['family']==family]
    for a,b in zip(ids,ids[1:]):ct=model.add(keys[a]<=keys[b]);symmetry.append({'originals':[a,b],'constraint':ct.index})
count_vars=[];count_records=[]
for family in ['bracket','insert','cog']:
    ids=[p['index'] for p in originals if p['family']==family];v=model.new_int_var(0,len(ids),f'short_{family}')
    ct=model.add(v==sum(sheet_bits[i] for i in ids));count_vars.append(v);count_records.append({'family':family,'variable':v.index,'constraint':ct.index})
table=model.add_allowed_assignments(count_vars,[r['short_counts'] for r in allocations])
weighted=sum(areas[p['family']]*sheet_bits[p['index']] for p in originals)
total=sum(areas[p['family']] for p in originals)
area_constraints=[model.add(weighted>=total-area_caps[0]).index,model.add(weighted<=area_caps[1]).index]
rect_records=[];coarse=[[],[]];source=[[],[]];separation=[[],[]]
for record,original in zip(records,originals):
    i=original['index']
    for option in record['options']:
        v=vs[option['variant']];s=option['sheet'];z=option_vars[i,v['id'],s]
        groups=[('coarse',v['coarse_rectangles_um'])]
        if original['family']=='cog':groups += [('source',v['source_capacity_rectangles_um']),('separation',v['separation_capacity_rectangles_um'])]
        for kind,rs in groups:
            for component,b in enumerate(rs):
                k=len(rect_records)
                xi=model.new_optional_fixed_size_interval_var(coordinates[i][0]+b[0],b[2]-b[0],z,f'{kind}_x_{k}')
                yi=model.new_optional_fixed_size_interval_var(coordinates[i][1]+b[1],b[3]-b[1],z,f'{kind}_y_{k}')
                rect_records.append({'original_index':i,'variant':v['id'],'sheet':s,'kind':kind,'component':component,
                    'presence':z.index,'bounds_um':b,'interval_indices':[xi.index,yi.index]})
                entry=(xi,yi,b)
                if kind=='coarse':
                    coarse[s].append(entry)
                    if original['family']!='cog':source[s].append(entry)
                elif kind=='source':source[s].append(entry)
                else:separation[s].append(entry)
sheet_records=[]
for s,stock in enumerate(stocks):
    no=model.add_no_overlap_2d([r[0] for r in coarse[s]],[r[1] for r in coarse[s]])
    caps=[]
    for kind,rows in [('source',source[s]),('separation',separation[s])]:
        for axis in [0,1]:
            ct=model.add_cumulative([r[axis] for r in rows],[r[2][3-axis]-r[2][1-axis] for r in rows],stock['capacity_um'][1-axis])
            caps.append({'kind':kind,'axis':axis,'constraint':ct.index})
    sheet_records.append({'sheet':s,'no_overlap_constraint':no.index,'cumulative':caps})
assert model.validate()==''
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'originals':records,'symmetry':symmetry,'short_counts':count_records,'count_table_constraint':table.index,
    'source_area_constraints':area_constraints,'rectangles':rect_records,'sheets':sheet_records})
write(OUT/'source-area-coefficients.json',{'area_um2_downward':areas,'stock_area_um2_downward':area_caps,'total_original_area_um2_downward':total})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),
    'originals':66,'exactly_one_options':sum(len(r['options']) for r in records),'optional_rectangles':len(rect_records),
    'coarse_rectangles_by_sheet':list(map(len,coarse)),'source_capacity_rectangles_by_sheet':list(map(len,source)),
    'cog_only_virtual_rectangles_by_sheet':list(map(len,separation)),'short_count_vectors':454,
    'source_area_constraints':2,'all66_required':True,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
