"""Independent complete protobuf audit of coupled options, counts and optional capacity."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,math,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-allocation-model-20261026'
GEO=ROOT/'output/h5-allocation-geometry-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
proto=cp_model_pb2.CpModelProto();proto.ParseFromString((BASE/'model.pb').read_bytes())
assert not proto.HasField('objective') and not proto.HasField('floating_point_objective') and not proto.solution_hint.vars
vs=load(GEO/'variants.json');ds=load(GEO/'domains.json');originals=load(GEO/'originals.json');stocks=load(GEO/'stocks.json');allocations=load(GEO/'allowed-allocations.json');mp=load(BASE/'mapping.json')
assert len(mp['originals'])==len(originals)==66
vi=ci=0;LOW=-9223372036854775808;HIGH=9223372036854775807
def variable(index,name,domain):
    global vi
    assert index==vi;v=proto.variables[vi];assert v.name==name and list(v.domain)==domain;vi+=1
def linear(index,coeffs,domain,enforcement=[]):
    global ci
    assert index==ci;ct=proto.constraints[ci]
    assert ct.WhichOneof('constraint')=='linear' and list(ct.enforcement_literal)==enforcement
    assert dict(zip(ct.linear.vars,ct.linear.coeffs))=={k:v for k,v in coeffs.items() if v} and list(ct.linear.domain)==domain;ci+=1
for original,record in zip(originals,mp['originals']):
    i=original['index'];assert record['original_index']==i
    allowed=[d for d in ds if d['allowed'] and vs[d['variant']]['family']==original['family']]
    x,y=record['coordinate_indices'];s=record['sheet_index'];key=record['key_index']
    variable(x,f'x_{i}',[min(d['bounds_um'][0] for d in allowed),max(d['bounds_um'][2] for d in allowed)])
    variable(y,f'y_{i}',[min(d['bounds_um'][1] for d in allowed),max(d['bounds_um'][3] for d in allowed)])
    variable(s,f'sheet_{i}',[0,1]);variable(key,f'key_{i}',[0,8000000])
    assert len(record['options'])==len(allowed)
    for d,o in zip(allowed,record['options']):
        assert o['variant']==d['variant'] and o['sheet']==d['sheet']
        variable(o['selector'],f'option_{i}_{d["variant"]}_{d["sheet"]}',[0,1])
    assert record['exactly_one_constraint']==ci;ct=proto.constraints[ci]
    assert ct.WhichOneof('constraint')=='exactly_one' and not ct.enforcement_literal
    assert list(ct.exactly_one.literals)==[o['selector'] for o in record['options']];ci+=1
    for d,o in zip(allowed,record['options']):
        b=d['bounds_um'];assert len(o['stock_constraints'])==4
        for n,var,bounds in [(0,x,[b[0],HIGH]),(1,y,[b[1],HIGH]),(2,x,[LOW,b[2]]),(3,y,[LOW,b[3]])]:
            linear(o['stock_constraints'][n],{var:1},bounds,[o['selector']])
    linear(record['sheet_constraint'],{s:1,**{o['selector']:-1 for o in record['options'] if o['sheet']==1}},[0,0])
    linear(record['key_constraint'],{key:1,y:-1,s:-4000000},[0,0])
expected_order=[]
for family in ['frame','bracket','insert','cog']:
    ids=[p['index'] for p in originals if p['family']==family];expected_order.extend(zip(ids,ids[1:]))
assert len(expected_order)==len(mp['symmetry'])==62
for (a,b),rec in zip(expected_order,mp['symmetry']):
    assert rec['originals']==[a,b];linear(rec['constraint'],{mp['originals'][a]['key_index']:1,mp['originals'][b]['key_index']:-1},[LOW,0])
assert len(mp['short_counts'])==3
for family,rec in zip(['bracket','insert','cog'],mp['short_counts']):
    ids=[p['index'] for p in originals if p['family']==family];assert rec['family']==family
    variable(rec['variable'],f'short_{family}',[0,len(ids)])
    linear(rec['constraint'],{rec['variable']:1,**{mp['originals'][i]['sheet_index']:-1 for i in ids}},[0,0])
assert vi==len(proto.variables)==609 and mp['count_table_constraint']==ci
ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='table' and not ct.enforcement_literal and not ct.table.negated
assert not ct.table.vars and len(ct.table.exprs)==3
for expr,rec in zip(ct.table.exprs,mp['short_counts']):assert list(expr.vars)==[rec['variable']] and list(expr.coeffs)==[1] and expr.offset==0
assert list(ct.table.values)==[n for row in allocations for n in row['short_counts']];ci+=1
areas={k:math.floor(F(*v)*1000000) for k,v in load(ROOT/'output/h5-global-short-frontier-20261026/area-proof.json')['filled_source_areas_rational'].items()}
caps=[]
for stock in stocks:
    b=[F(*r) for r in stock['target_bounds_rational']];caps.append(math.floor((b[2]-b[0])*(b[3]-b[1])*1000000))
total=sum(areas[p['family']] for p in originals)
assert load(BASE/'source-area-coefficients.json')=={'area_um2_downward':areas,'stock_area_um2_downward':caps,'total_original_area_um2_downward':total}
weighted={r['sheet_index']:areas[p['family']] for p,r in zip(originals,mp['originals'])}
assert len(mp['source_area_constraints'])==2
linear(mp['source_area_constraints'][0],weighted,[total-caps[0],HIGH]);linear(mp['source_area_constraints'][1],weighted,[LOW,caps[1]])
def expr(e,var,offset):assert dict(zip(e.vars,e.coeffs))==({var:1} if var is not None else {}) and e.offset==offset
coarse=[[],[]];source=[[],[]];virtual=[[],[]];ri=0
for original,record in zip(originals,mp['originals']):
    for option in record['options']:
        v=vs[option['variant']];s=option['sheet'];z=option['selector']
        groups=[('coarse',v['coarse_rectangles_um'])]
        if original['family']=='cog':groups += [('source',v['source_capacity_rectangles_um']),('separation',v['separation_capacity_rectangles_um'])]
        for kind,rows in groups:
            for component,b in enumerate(rows):
                rec=mp['rectangles'][ri]
                assert rec=={'original_index':original['index'],'variant':v['id'],'sheet':s,'kind':kind,'component':component,
                    'presence':z,'bounds_um':b,'interval_indices':[ci,ci+1]}
                indices=[ci,ci+1]
                for axis in [0,1]:
                    ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='interval' and list(ct.enforcement_literal)==[z]
                    assert ct.name==f'{kind}_{"xy"[axis]}_{ri}'
                    var=record['coordinate_indices'][axis];expr(ct.interval.start,var,b[axis]);expr(ct.interval.size,None,b[axis+2]-b[axis]);expr(ct.interval.end,var,b[axis+2]);ci+=1
                row=(indices,b)
                if kind=='coarse':
                    coarse[s].append(row)
                    if original['family']!='cog':source[s].append(row)
                elif kind=='source':assert original['family']=='cog';source[s].append(row)
                else:assert original['family']=='cog';virtual[s].append(row)
                ri+=1
assert ri==len(mp['rectangles'])==1686
assert len(mp['sheets'])==2
for s,record in enumerate(mp['sheets']):
    assert record['sheet']==s and record['no_overlap_constraint']==ci
    ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='no_overlap_2d' and not ct.enforcement_literal
    assert list(ct.no_overlap_2d.x_intervals)==[r[0][0] for r in coarse[s]] and list(ct.no_overlap_2d.y_intervals)==[r[0][1] for r in coarse[s]];ci+=1
    assert len(record['cumulative'])==4
    for k,(kind,rows,axis) in enumerate((kind,rows,axis) for kind,rows in [('source',source[s]),('separation',virtual[s])] for axis in [0,1]):
        assert record['cumulative'][k]=={'kind':kind,'axis':axis,'constraint':ci}
        ct=proto.constraints[ci];assert ct.WhichOneof('constraint')=='cumulative' and not ct.enforcement_literal
        assert list(ct.cumulative.intervals)==[r[0][axis] for r in rows] and len(ct.cumulative.demands)==len(rows)
        for demand,(_,b) in zip(ct.cumulative.demands,rows):expr(demand,None,b[3-axis]-b[1-axis])
        expr(ct.cumulative.capacity,None,stocks[s]['capacity_um'][1-axis]);ci+=1
assert ci==len(proto.constraints)==5016
area_excluded=[]
for a in allocations:
    b,i,c=a['short_counts'];short=areas['bracket']*b+areas['insert']*i+areas['cog']*c
    if total-short>caps[0] or short>caps[1]:area_excluded.append(a['short_counts'])
write(OUT/'source-area-excluded-count-vectors.json',area_excluded)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':vi,'constraints_verified':ci,
    'all66_required':True,'exactly_one_sheet_variant_choices_verified':342,'stock_guard_constraints_verified':1368,
    'optional_rectangles_verified':ri,'optional_interval_constraints_verified':2*ri,'equivalent_copy_orders_verified':62,
    'linked_short_count_vectors_verified':454,'additional_source_area_constraints_verified':2,
    'count_vectors_excluded_by_source_area':len(area_excluded),'per_sheet_source_only_nonoverlap_verified':True,
    'source_capacity_constraints_verified':4,'cog_only_virtual_capacity_constraints_verified':4,
    'virtual_disks_never_mixed_with_other_families':True,'no_fixed_short_allocation':True,
    'all_real_cog_rotations_retained':True,'no_objective_or_hints':True,'model_sha256':digest(BASE/'model.pb'),
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
