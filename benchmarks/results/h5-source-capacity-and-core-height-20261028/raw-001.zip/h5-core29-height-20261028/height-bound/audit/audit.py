"""Independent exhaustive pattern and exact original-source containment reader."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,math,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-core29-height-20261028';BOUND=BASE/'height-bound';OUT=BOUND/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
for n,h in load(BOUND/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};containment=[];crosses=0
for family,w,h in [('frame',450000,350000),('insert',180000,110000)]:
    assert set(map(tuple,parts[family]['geometry'][0]['outer']))=={(0,0),(w/1000,0),(w/1000,h/1000),(0,h/1000)}
    assert set(parts[family]['rotations']['degrees'])=={0,90,180,270}
    for q in range(4):
        c,s=math.cos(q*math.pi/2),math.sin(q*math.pi/2);points=[(x*c-y*s,x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']]
        lo=[min(p[k] for p in points) for k in [0,1]];v=[tuple(F(str(p[k]-lo[k])) for k in [0,1]) for p in points]
        ww,hh=(w,h) if q%2==0 else (h,w);corners=[(F(2,1000),F(2,1000)),(F(ww-2,1000),F(2,1000)),(F(ww-2,1000),F(hh-2,1000)),(F(2,1000),F(hh-2,1000))]
        area=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(v,v[1:]+v[:1]));assert area>0
        for a,b in zip(v,v[1:]+v[:1]):
            for p in corners:assert (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])>0;crosses+=1
        containment.append({'family':family,'quarter':q,'inner_width_um':ww-4,'inner_height_um':hh-4,'exact_halfplane_checks':16})
rows=load(BOUND/'patterns.json');saved={tuple(r['counts']):r for r in rows};assert len(saved)==len(rows)
expected={};W=1487000
for frames_wide in range(19):
    for frames_tall in range(19-frames_wide):
        for inserts_wide in range(12):
            for inserts_tall in range(12-inserts_wide):
                counts=(frames_wide,frames_tall,inserts_wide,inserts_tall);width=449996*counts[0]+349996*counts[1]+179996*counts[2]+109996*counts[3]
                if width>W:continue
                weight=9*counts[0]+7*counts[1]+2*counts[2]+counts[3];assert weight<=28
                expected[counts]={'counts':list(counts),'width_um':width,'weight':weight}
assert expected==saved and max(r['weight'] for r in rows)==28
b=load(BOUND/'bound.json');assert b['widths_um']==[449996,349996,179996,109996] and b['heights_um']==[349996,449996,109996,179996] and b['weights']==[9,7,2,1]
frame=min(349996*9,449996*7);insert=min(109996*2,179996);span=F(18*frame+11*insert,28);top=span+6500
assert b['frame_weighted_height_um']==frame and b['insert_weighted_height_um']==insert and b['feasible_section_patterns']==len(rows)
assert b['core_span_lower_um']==[span.numerator,span.denominator] and b['core_top_lower_um']==[top.numerator,top.denominator]
assert b['core_span_lower_mm']==float(span/1000) and b['core_top_lower_mm']==float(top/1000)
current=F(str(load(BASE/'source-audit/checks.json')['actual_core_top_mm']))*1000
assert b['maximum_further_height_reduction_mm']==float((current-top)/1000)
write(OUT/'source-containment.json',containment)
write(OUT/'checks.json',{'passed':True,'source_quarter_turn_modes_verified':8,'exact_source_halfplane_tests':crosses,
    'feasible_section_patterns_verified':len(rows),'maximum_pattern_weight_verified':28,'arbitrary_independent_positions_covered':True,
    'source_frame_count':18,'source_insert_count':11,'core_span_lower_mm':float(span/1000),'core_top_lower_mm':float(top/1000),
    'maximum_further_height_reduction_mm':float((current-top)/1000),'does_not_prove_full66_infeasibility':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
