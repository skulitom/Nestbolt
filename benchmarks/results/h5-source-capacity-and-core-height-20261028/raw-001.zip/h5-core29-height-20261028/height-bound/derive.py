"""Exact section-weight lower bound for every placement of this rectangular core."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-core29-height-20261028';OUT=BASE/'height-bound'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'derive.py')
inputs=[ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',BASE/'source-audit/checks.json',BASE/'plan.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Exact analytic lower bound, no optimization or solver. For all legal quarter-turn rectangular frame/insert outers, use a contained rectangle inset2um per side. At any horizontal section, enumerate every possible orientation count pattern of these rectangles fitting the1487000um stock width, respecting total18-frame/11-insert caps. Assign integer section weights9,7,2,1 to widths449996,349996,179996,109996um. Verify every feasible pattern has weight at most28. Integrate the section-weight bound overY; each frame contributes at least min(349996*9,449996*7) and each insert at least min(109996*2,179996*1) weightedum. Divide the total by28 for a lower bound on core span, then add the6.5mm stock bottom for a conservative original-core-top bound. Independently verify source containment, complete pattern coverage, all rational arithmetic and applicability to arbitrary independent positions and all quarter-turn modes. This bound applies only to the same18-frame/11-insert core; it excludes no full66 layout or short-sheet count.'})
widths=[449996,349996,179996,109996];heights=[349996,449996,109996,179996];weights=[9,7,2,1];W=1487000;patterns=[]
for counts in product(*(range(W//w+1) for w in widths)):
    if counts[0]+counts[1]>18 or counts[2]+counts[3]>11:continue
    occupied=sum(n*w for n,w in zip(counts,widths))
    if occupied<=W:
        weight=sum(n*w for n,w in zip(counts,weights));assert weight<=28;patterns.append({'counts':list(counts),'width_um':occupied,'weight':weight})
frame=min(heights[0]*weights[0],heights[1]*weights[1]);insert=min(heights[2]*weights[2],heights[3]*weights[3]);span=F(18*frame+11*insert,28);top=F(6500)+span
current=F(str(load(BASE/'source-audit/checks.json')['actual_core_top_mm']))*1000
write(OUT/'patterns.json',patterns)
write(OUT/'bound.json',{'widths_um':widths,'heights_um':heights,'weights':weights,'maximum_pattern_weight':28,'feasible_section_patterns':len(patterns),
    'frame_weighted_height_um':frame,'insert_weighted_height_um':insert,'core_span_lower_um':[span.numerator,span.denominator],
    'core_top_lower_um':[top.numerator,top.denominator],'core_span_lower_mm':float(span/1000),'core_top_lower_mm':float(top/1000),
    'current_source_core_top_mm':float(current/1000),'maximum_further_height_reduction_mm':float((current-top)/1000),
    'arbitrary_positions_and_all_quarter_turns':True,'source_quantity_scope':[18,11],'full66_exclusion_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'bound.json'))
