"""Compact all original rectangular core parts with independent positions/orientations."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-core29-height-20261028';OUT=BASE/'model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter();assert load(BASE/'prepared.json')['source_control_valid']
inputs=[BASE/'plan.json',BASE/'modes.json',BASE/'control.json',BASE/'control-source29.json',BASE/'control-source-readback.json',BASE/'prepared.json',BASE/'short14.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
model=cp_model.CpModel();modes=load(BASE/'modes.json');control=load(BASE/'control.json');pad=112;left=6513;right=1493487;maximum=2107650;width=right-left+2*pad
area=18*(450000+2*pad)*(350000+2*pad)+11*(180000+2*pad)*(110000+2*pad);lower=(area+width-1)//width+left-2*pad
top=model.new_int_var(lower,maximum,'core_top_um');items=[];xints=[];yints=[];ws=[];hs=[];hints={top.index:maximum}
for i,r in enumerate(control):
    family=r['family'];x=model.new_int_var(left,right,f'x_{i}');y=model.new_int_var(left,maximum,f'y_{i}');opts=[];hints[x.index],hints[y.index]=r['anchor_um']
    for mode in [m for m in modes if m['family']==family]:
        mi=mode['index'];select=model.new_bool_var(f'mode_{i}_{mi}');w,h=mode['width_um'],mode['height_um'];xe=model.add(x+w<=right);xe.only_enforce_if(select)
        ye=model.add(y+h<=top);ye.only_enforce_if(select)
        ix=model.new_optional_fixed_size_interval_var(x-pad,w+2*pad,select,f'expanded_x_{i}_{mi}');iy=model.new_optional_fixed_size_interval_var(y-pad,h+2*pad,select,f'expanded_y_{i}_{mi}')
        xints.append(ix);yints.append(iy);ws.append(w+2*pad);hs.append(h+2*pad)
        opts.append({'mode':mi,'selector':select.index,'x_bound':xe.index,'top_bound':ye.index,'x_interval':ix.index,'y_interval':iy.index});hints[select.index]=int(r['mode']==mi)
    choice=model.add_exactly_one(model.get_int_var_from_proto_index(o['selector']) for o in opts)
    items.append({'index':i,'family':family,'copy_index':r['copy_index'],'x':x.index,'y':y.index,'options':opts,'choice':choice.index})
no_overlap=model.add_no_overlap_2d(xints,yints);xc=model.add_cumulative(xints,hs,top-left+2*pad);yc=model.add_cumulative(yints,ws,width)
ordering=[]
for family in ['frame','insert']:
    group=[r for r in items if r['family']==family]
    for a,b in zip(group,group[1:]):
        ct=model.add(model.get_int_var_from_proto_index(a['x'])<=model.get_int_var_from_proto_index(b['x']));ordering.append({'left':a['index'],'right':b['index'],'constraint':ct.index})
model.minimize(top)
for ix,value in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(ix),value)
assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));assert model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'items':items,'top_variable':top.index,'expanded_width_um':width,'expanded_area_um2':area,'area_lower_top_um':lower,
    'no_overlap_2d':no_overlap.index,'x_cumulative':xc.index,'y_cumulative':yc.index,'orders':ordering})
write(OUT/'control-assignment.json',{str(k):v for k,v in sorted(hints.items())})
write(OUT/'built.json',{'seconds':time.perf_counter()-started,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),
    'mandatory_originals':29,'independent_anchor_coordinates':58,'legal_mode_options':58,'all_variables_hinted':len(hints)==len(model.proto.variables),
    'initial_top_um':maximum,'area_lower_top_um':lower,'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
