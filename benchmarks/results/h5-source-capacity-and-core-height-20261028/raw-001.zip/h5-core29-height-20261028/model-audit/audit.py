"""Independent original-rectangle, complete model and full-control audit."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-core29-height-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for plan in [load(BASE/'plan.json'),load(MODEL/'plan.json')]:
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={r['id']:r for r in job['parts']};modes=load(BASE/'modes.json');control=load(BASE/'control.json')
assert len(modes)==4
for i,m in enumerate(modes):
    family='frame' if i<2 else 'insert';q=i%2;w,h=(450000,350000) if family=='frame' else (180000,110000)
    assert set(map(tuple,parts[family]['geometry'][0]['outer']))=={(0,0),(w/1000,0),(w/1000,h/1000),(0,h/1000)}
    assert m['index']==i and m['family']==family and m['quarter']==q and m['angle']==q*math.pi/2 and not m['mirrored']
    assert 90*q in parts[family]['rotations']['degrees']
    c,s=math.cos(m['angle']),math.sin(m['angle']);raw=[(x*c-y*s,x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']]
    off=[-min(v[k] for v in raw) for k in [0,1]];assert off==m['source_translation_offset']
    vertices=[[x+off[0],y+off[1]] for x,y in raw];assert vertices==m['source_outer']
    ww,hh=(w,h) if q==0 else (h,w);assert m['width_um']==ww and m['height_um']==hh
    assert all(-.00005<=x<=ww/1000+.00005 and -.00005<=y<=hh/1000+.00005 for x,y in vertices)
assert .224-2*.00005>.21170867250963943 and .013-.00005>.011444091796875
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');built=load(MODEL/'built.json')
assert {f.name for f,v in p.ListFields()}=={'variables','constraints','objective','solution_hint'}
assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256']
pad=112;left=6513;right=1493487;maximum=2107650;width=right-left+2*pad;area=18*450224*350224+11*180224*110224;lower=(area+width-1)//width+left-2*pad
assert (mp['expanded_width_um'],mp['expanded_area_um2'],mp['area_lower_top_um'])==(width,area,lower)
seenvars=set();seencts=set();MIN=-9223372036854775808;MAX=9223372036854775807
def var(ix,name,domain):
    assert ix not in seenvars;seenvars.add(ix);v=p.variables[ix];assert v.name==name and list(v.domain)==domain
    assert {f.name for f,z in v.ListFields()}=={'name','domain'}
def linear(ix,coeffs,lo=MIN,hi=MAX,on=None):
    assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='linear'
    assert {f.name for f,z in ct.ListFields()}<= {'linear','enforcement_literal'} and list(ct.enforcement_literal)==([] if on is None else [on])
    assert dict(zip(ct.linear.vars,ct.linear.coeffs))==coeffs and len(ct.linear.vars)==len(coeffs) and list(ct.linear.domain)==[lo,hi]
def expr(e,variable,offset):
    assert e.offset==offset and list(e.vars)==([] if variable is None else [variable]) and list(e.coeffs)==([] if variable is None else [1])
    assert {f.name for f,z in e.ListFields()}<= {'vars','coeffs','offset'}
top=mp['top_variable'];var(top,'core_top_um',[lower,maximum]);expectedhints={top:maximum};allx=[];ally=[];demw=[];demh=[]
expected=[('frame',i,[0,1]) for i in range(18)]+[('insert',i,[2,3]) for i in range(5,16)]
assert len(mp['items'])==len(control)==29
for i,(item,(family,copy,allowed),hint) in enumerate(zip(mp['items'],expected,control)):
    assert (item['index'],item['family'],item['copy_index'])==(i,family,copy) and (hint['family'],hint['copy_index'])==(family,copy)
    x,y=item['x'],item['y'];var(x,f'x_{i}',[left,right]);var(y,f'y_{i}',[left,maximum]);expectedhints[x],expectedhints[y]=hint['anchor_um']
    assert [o['mode'] for o in item['options']]==allowed
    for o in item['options']:
        mi=o['mode'];m=modes[mi];sv=o['selector'];var(sv,f'mode_{i}_{mi}',[0,1]);expectedhints[sv]=int(hint['mode']==mi);w,h=m['width_um'],m['height_um']
        linear(o['x_bound'],{x:1},hi=right-w,on=sv);linear(o['top_bound'],{y:1,top:-1},hi=-h,on=sv)
        for axis,variable,size,key in [('x',x,w,'x_interval'),('y',y,h,'y_interval')]:
            ix=o[key];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix]
            assert {f.name for f,z in ct.ListFields()}=={'name','enforcement_literal','interval'} and ct.name==f'expanded_{axis}_{i}_{mi}' and list(ct.enforcement_literal)==[sv]
            expr(ct.interval.start,variable,-pad);expr(ct.interval.size,None,size+2*pad);expr(ct.interval.end,variable,size+pad)
        allx.append(o['x_interval']);ally.append(o['y_interval']);demw.append(w+2*pad);demh.append(h+2*pad)
    ix=item['choice'];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix]
    assert {f.name for f,z in ct.ListFields()}=={'exactly_one'} and list(ct.exactly_one.literals)==[o['selector'] for o in item['options']]
ix=mp['no_overlap_2d'];seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,z in ct.ListFields()}=={'no_overlap_2d'}
assert list(ct.no_overlap_2d.x_intervals)==allx and list(ct.no_overlap_2d.y_intervals)==ally
for key,intervals,demands,variable,offset in [('x_cumulative',allx,demh,top,-left+2*pad),('y_cumulative',ally,demw,None,width)]:
    ix=mp[key];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,z in ct.ListFields()}=={'cumulative'}
    assert list(ct.cumulative.intervals)==intervals and len(ct.cumulative.demands)==len(demands);expr(ct.cumulative.capacity,variable,offset)
    for e,d in zip(ct.cumulative.demands,demands):expr(e,None,d)
expectedorders=[(a,b) for f in ['frame','insert'] for group in [[r for r in mp['items'] if r['family']==f]] for a,b in zip(group,group[1:])]
assert len(mp['orders'])==len(expectedorders)==27
for row,(a,b) in zip(mp['orders'],expectedorders):
    assert (row['left'],row['right'])==(a['index'],b['index']);linear(row['constraint'],{a['x']:1,b['x']:-1},hi=0)
assert seenvars==set(range(len(p.variables))) and seencts==set(range(len(p.constraints)))
assert list(p.objective.vars)==[top] and list(p.objective.coeffs)==[1] and p.objective.offset==0 and p.objective.scaling_factor==1
assert {f.name for f,z in p.objective.ListFields()}=={'vars','coeffs','scaling_factor'}
assert len(p.solution_hint.vars)==len(set(p.solution_hint.vars))==len(p.variables)
assert expectedhints==dict(zip(p.solution_hint.vars,p.solution_hint.values))=={int(k):v for k,v in load(MODEL/'control-assignment.json').items()}
sol=expectedhints
def ev(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
def present(ct):return all(sol[v]==1 for v in ct.enforcement_literal)
active=[];pairs=0
for v,x in zip(p.variables,[sol[i] for i in range(len(p.variables))]):assert v.domain[0]<=x<=v.domain[-1]
for ct in p.constraints:
    if not present(ct):continue
    kind=ct.WhichOneof('constraint')
    if kind=='linear':
        value=sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs));assert ct.linear.domain[0]<=value<=ct.linear.domain[-1]
    elif kind=='exactly_one':assert sum(sol[v] for v in ct.exactly_one.literals)==1
    elif kind=='interval':assert ev(ct.interval.start)+ev(ct.interval.size)==ev(ct.interval.end) and ev(ct.interval.size)>0
    elif kind=='no_overlap_2d':
        for xx,yy in zip(ct.no_overlap_2d.x_intervals,ct.no_overlap_2d.y_intervals):
            a,b=p.constraints[xx],p.constraints[yy];assert present(a)==present(b)
            if present(a):active.append([ev(a.interval.start),ev(b.interval.start),ev(a.interval.end),ev(b.interval.end)])
        for a,b in combinations(active,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];pairs+=1
    elif kind=='cumulative':
        events={}
        for ix,e in zip(ct.cumulative.intervals,ct.cumulative.demands):
            c=p.constraints[ix]
            if not present(c):continue
            begin,end,amount=ev(c.interval.start),ev(c.interval.end),ev(e);events[begin]=events.get(begin,0)+amount;events[end]=events.get(end,0)-amount
        running=0
        for where,delta in sorted(events.items()):running+=delta;assert 0<=running<=ev(ct.cumulative.capacity)
        assert running==0
    else:raise AssertionError(kind)
assert len(active)==29 and pairs==406
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'original_rectangular_modes_verified':4,'true_source_gap_lower_bound_mm':.2239,
    'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'mandatory_originals':29,'independent_anchor_coordinates':58,
    'full_control_values_verified':len(sol),'full_control_expanded_pairs_verified':pairs,'area_lower_top_um':lower,'initial_top_um':maximum,
    'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'plan_sha256':digest(BASE/'plan.json'),
    'constructive_core_only':True,'full66_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
