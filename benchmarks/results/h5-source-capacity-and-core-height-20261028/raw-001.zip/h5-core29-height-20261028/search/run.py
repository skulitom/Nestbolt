"""One bounded core-height call, preserving every incumbent and the full response."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-core29-height-20261028';MODEL=BASE/'model';OUT=BASE/'search'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2
    from ortools.sat.python import cp_model
    audit=load(BASE/'model-audit/checks.json');assert audit['passed'];assert digest(BASE/'plan.json')==audit['plan_sha256'] and digest(MODEL/'mapping.json')==audit['mapping_sha256']
    for path in [BASE/'plan.json',MODEL/'plan.json']:
        for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
    model=cp_model.CpModel();assert model.proto.parse_text_format((MODEL/'model.pbtxt').read_text()) and model.validate()==''
    assert model.export_to_file(str(OUT/'model.pb')) and digest(OUT/'model.pb')==audit['model_sha256']
    solver=cp_model.CpSolver();params={'max_time_in_seconds':60.,'num_search_workers':4,'random_seed':0,'log_search_progress':True,'log_to_stdout':False,'ignore_subsolvers':['fj']}
    for k,v in params.items():
        if isinstance(v,list):getattr(solver.parameters,k).extend(v)
        else:setattr(solver.parameters,k,v)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'model_sha256':audit['model_sha256'],'model_audit_sha256':digest(BASE/'model-audit/checks.json'),
        'maximum_calls':1,'solver_seconds':60,'shared_seconds':90,'parameters':params})
    class Capture(cp_model.CpSolverSolutionCallback):
        def __init__(self):super().__init__();self.count=0
        def on_solution_callback(self):
            write(OUT/'incumbents'/f'{self.count:03d}.json',{'sequence':self.count,'solver_wall_seconds':self.wall_time,'top_um':self.objective_value,
                'bound_um':self.best_objective_bound,'values':[self.value(model.get_int_var_from_proto_index(i)) for i in range(117)]});self.count+=1
    capture=Capture()
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
        solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());started=time.perf_counter();status=solver.solve(model,capture);elapsed=time.perf_counter()-started
    response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(OUT/'response.pb').write_bytes(response.SerializeToString())
    if response.solution:write(OUT/'assignment.json',list(response.solution))
    write(OUT/'result.json',{'status':solver.status_name(status),'returned_solve_seconds':elapsed,'solver_wall_seconds':response.wall_time,
        'returned_response_branches':response.num_branches,'returned_response_conflicts':response.num_conflicts,'has_solution':bool(response.solution),
        'top_um':response.objective_value,'bound_um':response.best_objective_bound,'incumbents_recorded':capture.count,
        'returned_soft_overrun_seconds':max(0.,elapsed-60),'solver_soft_overrun_seconds':max(0.,response.wall_time-60),
        'solver_calls':1,'closed':True,'source_core_verified':False,'full66_exclusion_claimed':False,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();(OUT/'incumbents').mkdir();shutil.copyfile(__file__,OUT/'run.py');started=time.perf_counter()
    write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':90,'solver_seconds':60,'maximum_calls':1,'retry_permitted':False})
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=max(.01,90-(time.perf_counter()-started)))
        (OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);process={'seconds':time.perf_counter()-started,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds':time.perf_counter()-started,'timeout':True}
    write(OUT/'process.json',process);print(process);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final response; call remains closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
