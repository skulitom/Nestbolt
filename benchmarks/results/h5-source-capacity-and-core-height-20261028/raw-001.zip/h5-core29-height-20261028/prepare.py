"""Prepare all-rectangle core compaction, preserving original identities and guards."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-core29-height-20261028';OLD=ROOT/'output/h5-free23-source-regions-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[OLD/'fixed43.json',OLD/'control-clear/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',
    ROOT/'output/h5-free23-capacity-20261028/response-audit/checks.json',ROOT/'output/build_h5_mixed_rows_core.py',
    ROOT/'output/build_h5_central_notch_frame_core.py',ROOT/'output/build_h5_staggered_frame_bracket_core_repaired.py']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New constructive core-height optimization after both23-mover calls closed UNKNOWN. Existing records include fixed mixed-row and staggered frame patterns; do not repeat those finite constructions. Instead let all18 frame and11 side-insert originals move independently, choosing0/90degree legal modes, and minimize their maximum upperY within the existing2107.65mm height. No cog or bracket is dropped from the final obligation: this is only a candidate replacement for the29-part core, and the23 remaining first-sheet movers still need a new complete construction. The14 short originals stay exact. The current source core supplies a complete positive control and full hint after harmless identical-copy X relabeling. Model full original rectangular filled outers, padded112um on every side for224um axis separation; original source bounds differ from nominal rectangles by at most0.00005mm, so resulting true pair clearance is at least0.2239mm, above0.21170867250963943. Stock anchor bounds6513..1493487um retain the native guard. Any returned source core must be read independently and all owner-dependent regions rebuilt before reuse. No prior search is resumed; no full66 or native claim follows from a compact core alone.',
    'solver_seconds':60,'shared_process_seconds':90,'maximum_calls':1,'retry_permitted':False,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],
    'pad_um':112,'source_bbox_tolerance_mm':.00005,'anchor_left_um':6513,'anchor_right_um':1493487,'maximum_top_um':2107650})
job=load(inputs[2]);parts={p['id']:p for p in job['parts']};fixed=load(OLD/'fixed43.json');old=[r for r in fixed if r['sheet_id']=='sheet-0'];modes=[]
for family,w,h in [('frame',450000,350000),('insert',180000,110000)]:
    for quarter in [0,1]:
        angle=quarter*math.pi/2;c,s=math.cos(angle),math.sin(angle);ring=[(x*c-y*s,x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']]
        offset=[-min(p[k] for p in ring) for k in [0,1]];points=[(x+offset[0],y+offset[1]) for x,y in ring];g=Polygon(points)
        ww,hh=(w,h) if quarter==0 else (h,w)
        assert len(points)==4 and max(abs(a-b) for a,b in zip(g.bounds,[0,0,ww/1000,hh/1000]))<.00005
        modes.append({'index':len(modes),'family':family,'quarter':quarter,'angle':angle,'mirrored':False,'source_translation_offset':offset,'width_um':ww,'height_um':hh,'source_outer':points})
control=[];rows=[]
for family,ids in [('frame',list(range(18))),('insert',list(range(5,16)))]:
    group=[]
    for r in old:
        if r['part_id']!=family:continue
        t=r['transform'];assert not t['mirrored'];mm=[m for m in modes if m['family']==family and abs(m['angle']-t['rotation_radians'])<1e-12];assert len(mm)==1;m=mm[0]
        xy=[round((t['translation'][k]-m['source_translation_offset'][k])*1000) for k in [0,1]];group.append({'mode':m['index'],'anchor_um':xy})
    assert len(group)==len(ids)
    for copy,r in zip(ids,sorted(group,key=lambda r:r['anchor_um'])):
        m=modes[r['mode']];control.append({**r,'family':family,'copy_index':copy})
        rows.append({'part_id':family,'copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],'mirrored':False,
            'translation':[r['anchor_um'][k]/1000+m['source_translation_offset'][k] for k in [0,1]]}})
expected={('frame',i) for i in range(18)}|{('insert',i) for i in range(5,16)}
readback=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5]},.21170867250963943,.011444091796875,expected);assert readback['valid']
write(OUT/'modes.json',modes);write(OUT/'control.json',control);write(OUT/'control-source29.json',rows);write(OUT/'control-source-readback.json',readback)
write(OUT/'short14.json',[r for r in fixed if r['sheet_id']=='sheet-1'])
top=max(r['anchor_um'][1]+modes[r['mode']]['height_um'] for r in control);assert top==2107650
write(OUT/'prepared.json',{'source_modes':4,'mandatory_core_originals':29,'source_control_valid':True,'initial_top_um':top,
    'source_control_pairs':readback['same_sheet_pairs'],'minimum_pair_gap_mm':readback['minimum_pair_gap_mm'],
    'minimum_extra_stock_mm':readback['minimum_extra_stock_mm'],'remaining_first_sheet_originals':23,'unchanged_short_originals':14,
    'full66_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
