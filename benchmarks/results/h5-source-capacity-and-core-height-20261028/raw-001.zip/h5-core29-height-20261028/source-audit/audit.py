"""Read the optimized core and unchanged short sheet from the original source rings."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math,shutil
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-core29-height-20261028';OUT=BASE/'source-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');response=load(BASE/'response-audit/checks.json');assert response['passed'] and response['has_source_core_candidate']
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};rows=load(BASE/'response-audit/source43.json')
assert [r for r in rows if r['sheet_id']=='sheet-1']==load(BASE/'short14.json') and len(rows)==43
missing={('cog',i) for i in range(15)}|{('bracket',i) for i in range(7,12)}|{('insert',i) for i in range(18,21)}
expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}-missing
readback=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},.21170867250963943,.011444091796875,expected)
write(OUT/'source-readback.json',readback);assert readback['valid'];first=[]
for r in rows:
    if r['sheet_id']!='sheet-0':continue
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation']
    g=Polygon([(x*c-y*s+tx,x*s+y*c+ty) for x,y in parts[r['part_id']]['geometry'][0]['outer']]);first.append(g)
top=max(g.bounds[3] for g in first);assert abs(top-response['top_mm'])<1e-9
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'response-audit/checks.json',BASE/'response-audit/source43.json',BASE/'short14.json']}})
write(OUT/'checks.json',{'passed':True,'source_originals':43,'core_originals':29,'unchanged_short_originals':14,'source_pairs_verified':readback['same_sheet_pairs'],
    'source_stock_edges':readback['stock_edges'],'original_holes':readback['cutouts'],'hole_vertices':readback['hole_vertices'],
    'minimum_pair_gap_mm':readback['minimum_pair_gap_mm'],'minimum_extra_stock_mm':readback['minimum_extra_stock_mm'],'actual_core_top_mm':top,
    'core_top_improvement_mm':2107.65-top,'first_mode_counts':dict(Counter(r['part_id']+'@'+str(round(math.degrees(r['transform']['rotation_radians']))) for r in rows if r['sheet_id']=='sheet-0')),
    'unplaced_originals':[list(k) for k in sorted(missing)],'previous_source64_preserved':True,'full66_witness':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
