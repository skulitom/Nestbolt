"""Exact source-edge containment and capacity-necessity audit."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free23-capacity-20261028';OLD=ROOT/'output/h5-free23-source-regions-20261028';OUT=BASE/'geometry-audit-corrected'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');audit_started=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(OLD/'modes.json');mode_rows=load(BASE/'mode-rectangles.json')
def source(part,angle,mirrored,offset):
    c,s=math.cos(angle),math.sin(angle);sign=-1 if mirrored else 1
    raw=[(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in part['geometry'][0]['outer']]
    return [tuple(F(str(v)) for v in xy) for xy in raw],Polygon(raw)
def segment_hits(a,b,r):
    lo,hi=F(0),F(1)
    for axis in [0,1]:
        delta=b[axis]-a[axis]
        if delta==0:
            if not r[axis]<=a[axis]<=r[axis+2]:return False
        else:
            u,v=sorted([(r[axis]-a[axis])/delta,(r[axis+2]-a[axis])/delta]);lo=max(lo,u);hi=min(hi,v)
            if lo>hi:return False
    return True
def inside(point,vertices):
    x,y=point;result=False
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        if (a[1]>y)!=(b[1]>y):
            crossing=a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1])
            if x<crossing:result=not result
    return result
edge_checks=rectangles=disjoint_checks=0
def verify(vertices,poly,rects):
    global edge_checks,rectangles,disjoint_checks
    for rr in rects:
        assert all(isinstance(v,int) for v in rr) and rr[0]<rr[2] and rr[1]<rr[3];r=[F(v,1000) for v in rr]
        assert inside(r[:2],vertices)
        for a,b in zip(vertices,vertices[1:]+vertices[:1]):assert not segment_hits(a,b,r);edge_checks+=1
        assert poly.contains(box(*map(float,r)));rectangles+=1
    for a,b in combinations(rects,2):
        assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];disjoint_checks+=1
assert len(mode_rows)==len(modes)==11
for mode,row in zip(modes,mode_rows):
    assert row['mode']==mode['index'] and row['family']==mode['family'];vertices,poly=source(parts[mode['family']],mode['angle'],mode['mirrored'],mode['source_translation_offset'])
    verify(vertices,poly,row['rectangles_um']);area=sum((r[2]-r[0])*(r[3]-r[1]) for r in row['rectangles_um'])/1e6
    assert area==row['contained_area_mm2'] and poly.area==row['source_filled_area_mm2'] and area/poly.area==row['area_fraction']
fixed=load(OLD/'fixed43.json');first=[r for r in fixed if r['sheet_id']=='sheet-0'];fr=load(BASE/'fixed-rectangles.json');assert len(fr)==len(first)==29
for r,saved in zip(first,fr):
    assert saved['key']==[r['part_id'],r['copy_index']];t=r['transform'];vertices,poly=source(parts[r['part_id']],t['rotation_radians'],t['mirrored'],t['translation'])
    verify(vertices,poly,[saved['rectangle_um']])
assert job['stocks'][0]['width']==1500 and job['stocks'][0]['height']==3000 and job['edge_clearance']==1.5
assert all(v==5 for v in job['stocks'][0]['margins'].values())
components=[r['rectangle_um'] for r in fr]
for r in load(OLD/'control-clear/moving19.json'):
    x,y=r['anchor_um'];components += [[a+x,b+y,c+x,d+y] for a,b,c,d in mode_rows[r['mode']]['rectangles_um']]
sweeps=[]
for axis,capacity in [(0,2987000),(1,1487000)]:
    events={}
    for r in components:
        start,end=r[axis],r[axis+2];demand=r[3-axis]-r[1-axis]
        events[start]=events.get(start,0)+demand;events[end]=events.get(end,0)-demand
    current=maximum=0;states=[]
    for where,delta in sorted(events.items()):current+=delta;maximum=max(maximum,current);assert 0<=current<=capacity;states.append([where,current])
    assert current==0;sweeps.append({'axis':axis,'capacity_um':capacity,'maximum_demand_um':maximum,'slack_um':capacity-maximum,'events':states})
write(OUT/'partial-control-sweeps.json',sweeps)
write(OUT/'necessity-proof.json',{'statement':'For any valid placement of the original filled polygons, each active contained rectangle lies inside its original and the stock. Rectangles from distinct parts cannot overlap because the originals are disjoint; rectangles within each original have disjoint interiors by the exact integer comparisons. At any open vertical section the active rectangle heights are disjoint Y intervals inside the stock height, so their sum is at most2987000um. The horizontal-section argument similarly gives1487000um. Half-open scheduling endpoints preserve this necessary bound. Optional mode rectangles are active only for the unique selected legal mode. Constant rectangles for29 fixed first-sheet originals obey the same bound. No extra separation or bounding-box assumption is added.',
    'local_containment_basis':'Original transformed vertex coordinates represented exactly as decimal Fractions. Each rectangle lower-left point passes exact ray parity, and no source boundary segment intersects the closed rectangle by exact parametric clipping. Connectedness therefore places the whole rectangle strictly inside the original filled polygon.',
    'source_holes_reserved':True,'new_constraints_necessary_for_original_parts':True,'full_source_model_remains_constructive_subset':True})
inputs=[BASE/'plan.json',BASE/'mode-rectangles.json',BASE/'fixed-rectangles.json',BASE/'prepared.json',BASE/'cog-grid-inventory.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-audit_started,'source_modes_verified':11,'fixed_originals_verified':29,
    'exact_contained_rectangles_verified':rectangles,'exact_source_segment_checks':edge_checks,'same_mode_rectangle_pair_checks':disjoint_checks,
    'cog_contained_rectangles':len(mode_rows[0]['rectangles_um']),'cog_area_fraction':mode_rows[0]['area_fraction'],
    'partial_control_components':len(components),'partial_control_capacity_slack_um':[s['slack_um'] for s in sweeps],
    'capacity_width_um':1487000,'capacity_height_um':2987000,'new_constraints_necessary':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
