"""Derive disjoint rectangles contained in original filled source modes."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon,box
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-free23-source-regions-20261028';OUT=ROOT/'output/h5-free23-capacity-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[OLD/'plan.json',OLD/'modes.json',OLD/'fixed43.json',OLD/'audit/checks.json',OLD/'model-audit/checks.json',OLD/'response-audit/checks.json',
    OLD/'control-clear/moving19.json',OLD/'control-clear/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Prepare a separately audited capacity-strengthened model after the independent-coordinate call closed UNKNOWN. Keep every original variable, mode, mandatory part, source no-fit constraint and hint unchanged. Add only necessary cumulative X/Y capacities derived from disjoint source-contained rectangles. For the phase7 cog use5mm grid cells, inset2micrometres, retain only full cells covered by the original filled polygon, then merge adjacent cells horizontally and vertically only after checking each merged rectangle remains covered. For brackets use their exact two source rectangles, transform and round inward2micrometres; for inserts and fixed frames use their original full rectangle with the same inward rounding. Retain the full cell inventory. Independently prove rectangle containment using exact rational source-edge/rectangle separation and point-in-polygon, and prove component interiors are disjoint. Include all29 fixed first-sheet originals and all23 mandatory movers; short14 is unchanged and outside these first-sheet capacities. Cumulative capacities are the original usable stock width1487000 and height2987000 micrometres, with no extra gap demand. No source angle or count is excluded by the new valid capacity constraints. No optimization in preparation; the old call remains closed.'})
job=load(inputs[-1]);parts={p['id']:p for p in job['parts']};modes=load(OLD/'modes.json');fixed=load(OLD/'fixed43.json')
def ring(points,angle,mirrored,offset):
    c,s=math.cos(angle),math.sin(angle);sign=-1 if mirrored else 1
    return [(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in points]
def inside_bounds(poly):
    x0,y0,x1,y1=poly.bounds;r=[math.ceil(x0*1000)+2,math.ceil(y0*1000)+2,math.floor(x1*1000)-2,math.floor(y1*1000)-2]
    assert r[2]>r[0] and r[3]>r[1] and poly.covers(box(*[v/1000 for v in r]));return r
inventory=[];mode_rows=[]
for mode in modes:
    family=mode['family'];a,mir,offset=mode['angle'],mode['mirrored'],mode['source_translation_offset'];original=Polygon(ring(parts[family]['geometry'][0]['outer'],a,mir,offset))
    if family=='cog':
        x0,y0,x1,y1=original.bounds;rects=[];row_ranges={}
        for yi in range(math.floor(y0/5),math.ceil(y1/5)):
            accepted=[]
            for xi in range(math.floor(x0/5),math.ceil(x1/5)):
                r=[xi*5000+2,yi*5000+2,(xi+1)*5000-2,(yi+1)*5000-2];covered=original.covers(box(*[v/1000 for v in r]))
                inventory.append({'x_cell':xi,'y_cell':yi,'contained':covered})
                if covered:accepted.append(xi)
            groups=[]
            for xi in accepted:
                if groups and xi==groups[-1][-1]+1:groups[-1].append(xi)
                else:groups.append([xi])
            for group in groups:
                r=[group[0]*5000+2,yi*5000+2,(group[-1]+1)*5000-2,(yi+1)*5000-2]
                assert original.covers(box(*[v/1000 for v in r]));key=(r[0],r[2])
                if key in row_ranges and row_ranges[key][1]==yi-1:
                    index,_=row_ranges[key];merged=[r[0],rects[index][1],r[2],r[3]]
                    assert original.covers(box(*[v/1000 for v in merged]));rects[index]=merged;row_ranges[key]=(index,yi)
                else:rects.append(r);row_ranges[key]=(len(rects)-1,yi)
    elif family=='bracket':
        source_rects=[[(0,0),(300,0),(300,75),(0,75)],[(0,75),(100,75),(100,250),(0,250)]]
        rects=[inside_bounds(Polygon(ring(v,a,mir,offset))) for v in source_rects]
    else:assert family=='insert';rects=[inside_bounds(original)]
    assert all(original.covers(box(*[v/1000 for v in r])) for r in rects)
    area=sum((r[2]-r[0])*(r[3]-r[1]) for r in rects)/1e6
    mode_rows.append({'mode':mode['index'],'family':family,'rectangles_um':rects,'source_filled_area_mm2':original.area,'contained_area_mm2':area,'area_fraction':area/original.area})
fixed_rows=[]
for r in fixed:
    if r['sheet_id']!='sheet-0':continue
    t=r['transform'];g=Polygon(ring(parts[r['part_id']]['geometry'][0]['outer'],t['rotation_radians'],t['mirrored'],t['translation']))
    assert g.equals(g.convex_hull) and len(g.exterior.coords)==5
    fixed_rows.append({'key':[r['part_id'],r['copy_index']],'rectangle_um':inside_bounds(g)})
assert len(fixed_rows)==29
write(OUT/'cog-grid-inventory.json',inventory);write(OUT/'mode-rectangles.json',mode_rows);write(OUT/'fixed-rectangles.json',fixed_rows)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'source_modes':11,'local_rectangles':sum(len(r['rectangles_um']) for r in mode_rows),
    'cog_grid_cells_considered':len(inventory),'cog_grid_cells_contained':sum(r['contained'] for r in inventory),'cog_rectangles':len(mode_rows[0]['rectangles_um']),
    'cog_contained_area_mm2':mode_rows[0]['contained_area_mm2'],'cog_area_fraction':mode_rows[0]['area_fraction'],'fixed_first_sheet_rectangles':29,
    'capacity_width_um':1487000,'capacity_height_um':2987000,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
