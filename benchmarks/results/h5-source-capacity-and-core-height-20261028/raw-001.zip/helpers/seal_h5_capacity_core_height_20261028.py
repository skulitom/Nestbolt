"""Seal source-capacity search, core compaction and the exact core-height bound."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-source-capacity-and-core-height-20261028';OUT=ROOT/'benchmarks/results'/NAME
CAP=ROOT/'output/h5-free23-capacity-20261028';CORE=ROOT/'output/h5-core29-height-20261028';PUB=CORE/'publication'
STAG=ROOT/'output/h5-staggered-frame-bracket-core-repaired-20261026'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='d71c9c85257ba1500139e6bff62937f21fcfbf89' and not git('diff','HEAD','--name-only')
ca=load(CAP/'geometry-audit-corrected/checks.json');cm=load(CAP/'model-audit/checks.json');cr=load(CAP/'response-audit/checks.json')
km=load(CORE/'model-audit/checks.json');kr=load(CORE/'response-audit/checks.json');ks=load(CORE/'source-audit/checks.json');bound=load(CORE/'height-bound/audit/checks.json')
assert all(r['passed'] for r in [ca,cm,cr,km,kr,ks,bound]);assert ca['seconds']>=0 and cr['status']=='UNKNOWN' and kr['status']=='FEASIBLE'
assert kr['top_mm']==2107.633 and ks['source_originals']==43 and bound['maximum_further_height_reduction_mm']<5.444
prior=load(ROOT/'benchmarks/results/h5-independent-source-placement-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest']
readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],
    'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==prior[k] for k in up);assert load(PUB/'main.json')['commit']['sha']==head
jobs=load(PUB/'main-ci-jobs.json')['jobs'];passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed']
assert len(jobs)==6 and len(passed)==5 and live==['checks (windows-latest)']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [CAP,CORE,ROOT/'output/h5-free23-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_free23_capacity_rectangles_20261028.py','audit_h5_free23_capacity_rectangles_20261028.py',
    'audit_h5_free23_capacity_rectangles_corrected_20261028.py','build_h5_free23_capacity_model_20261028.py','audit_h5_free23_capacity_model_20261028.py',
    'run_h5_free23_capacity_model_20261028.py','audit_h5_free23_capacity_response_20261028.py','prepare_h5_core29_height_20261028.py',
    'build_h5_core29_height_model_20261028.py','audit_h5_core29_height_model_20261028.py','run_h5_core29_height_model_20261028.py',
    'audit_h5_core29_height_response_20261028.py','audit_h5_core29_height_source_20261028.py','derive_h5_core29_height_bound_20261028.py',
    'audit_h5_core29_height_bound_20261028.py','h5_rectangle_cp_evaluator_20261028.py','push_free23_checkpoint_20261028.py',
    'pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
nextinputs=[STAG/'plan.json',STAG/'placements.json',STAG/'audit/checks.json',STAG/'audit/next-neighborhood.json',
    ROOT/'benchmarks/results/h5-staggered-frame-core-and-joint-contacts-20261026/next-step.json']
for p in nextinputs:
    n=p.relative_to(ROOT).as_posix();bindings[n]=digest(p);add('source-inputs/'+n,p)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for f in ['output','scripts']:
                    q=ROOT/f/(module+'.py')
                    if q.is_file():add('imported-helpers/'+f+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(CAP/'geometry-audit-corrected/checks.json','capacity-geometry-audit.json'),(CAP/'geometry-audit/timing-erratum.json','retained-timing-erratum.json'),
    (CAP/'geometry-audit-corrected/necessity-proof.json','capacity-necessity-proof.json'),(CAP/'model-audit/checks.json','capacity-model-audit.json'),
    (CAP/'response-audit/checks.json','capacity-response-audit.json'),(CORE/'model-audit/checks.json','core-model-audit.json'),
    (CORE/'response-audit/checks.json','core-response-audit.json'),(CORE/'source-audit/checks.json','core-source-audit.json'),
    (CORE/'response-audit/source43.json','source43.json'),(CORE/'height-bound/bound.json','height-bound.json'),
    (CORE/'height-bound/patterns.json','height-section-patterns.json'),(CORE/'height-bound/audit/checks.json','height-bound-audit.json'),
    (STAG/'audit/next-neighborhood.json','next-staggered-neighborhood.json'),(PUB/'main-ci-jobs.json','prior-main-ci.json')]
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,
    'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,
    'main_CI':40728382102,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_main_check':True,
    'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'capacity_status':'UNKNOWN','core_height_status':'FEASIBLE','core_top_improvement_mm':.017,
    'exact_core_top_lower_mm':bound['core_top_lower_mm'],'maximum_further_core_height_reduction_mm':bound['maximum_further_height_reduction_mm'],
    'source43_valid':True,'previous_source64_preserved':True,'remaining_necessary_allocations':444,'full66_witness':False,
    'actual_or_global_infeasibility_claimed':False,'solver_calls':2,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='The free23 source-capacity call is CLOSED UNKNOWN (95682 returned branches,2890conflicts); preserve0.1047265s returned soft overrun. The separate core29 height call is CLOSED FEASIBLE with9 audited incumbents, only0.017mm lower (top2107.633), and0.0416797s returned soft overrun. Original-source43 readback passes, but it is not an improved full partial count and the old valid64 remains best. The exact214-pattern section-weight certificate covers arbitrary positions/allquarter-turns of the same18-frame/11-insert core and bounds its top below by2102.189571mm: height compaction alone has at most5.443429mm left. Do not run another height-only search or rebuild every owner region merely for a17um improvement. Instead revisit the already source-valid staggered fixed26/short15 arrangement in output/h5-staggered-frame-bracket-core-repaired-20261026/placements.json, with the archived next-neighborhood identifying all25 remaining originals (3 brackets,7 inserts,15 cogs). Its old2000-pose call was only a finite-pool exclusion and stays closed. Revalidate the actual original source core and unchanged target, then apply a materially different independently positioned source formulation to that arrangement, rebuilding every owner-dependent free region; intrinsic obstacles/cells may be reused only with exact mode/gap/hash agreement. Preserve all25 mandatory movers and actual short6/9 allocation. Consider the audited phase7 mode as a constructive subset rather than repeating the old four-phase finite pool. Audit original-source conservatism, new capacity rectangles and a valid partial control before declaring one bounded search. No native/full H5 matrix until all66 actual originals pass. Keep444 necessary allocations, H2 and22 reserved vectors unchanged. Main d71c9c85 has five passing jobs and Windowslive; wait for allsix and fresh remote guards before a normal checkpoint push. No release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Source capacity and core-height limits — 2026-10-28

The source-capacity search closes **UNKNOWN**. A separate search that moves all
18 frames and 11 side inserts lowers their top by only **0.017 mm**. More
usefully, a new exact source bound proves that this same core can be shortened
by at most another **5.443429 mm**, even with arbitrary positions and all legal
quarter turns. The next construction will change the core composition.
H2/H5 remain open at **60% completed milestone weight**; no full layout exists.

## Necessary source-capacity constraints

The phase7 cog has 92 disjoint contained rectangles, covering 88.223258% of its
filled area. All bracket and insert modes and the 29 fixed first-sheet originals
also have contained rectangles. Independent exact-rational edge checks verify
**139 local/fixed rectangles, 7,580 source-edge checks and 4,194 internal pair
checks**. Integrating disjoint sections proves the two stock-capacity constraints
are necessary for any valid source placement. No extra spacing is demanded.

The model preserves all **58,151 prior variables, 210,518 constraints and 24,203
hints exactly**, then adds 2,990 optional intervals and two cumulative capacities.
All 23 movers remain mandatory and independently positioned. Every addition,
presence literal, demand and capacity is read back. The positive partial control
passes with 1,414 active components and both cumulative sweeps.

The first geometry audit's timer was accidentally overwritten by an interval
coordinate; its negative elapsed duration is invalid and retained with an
erratum. The corrected reader repeats the checks into a separate folder and
records 0.113605 seconds. No solver call is repeated for this repair.

The sole 60-second, four-worker capacity call returns **UNKNOWN**, with 95,682
returned branches and 2,890 conflicts. Solver time is 60.084770 s; returned time
60.104726 s; shared time 61.620649 s. The 0.104726-second returned soft overrun is
preserved. No assignment or infeasibility claim follows.

## Independent frame/insert core compaction

Existing records already contain fixed mixed-row and staggered frame patterns.
This new model instead moves every one of the 18 frames and 11 side inserts
independently, allows 0°/90° orientations and minimizes their maximum upper Y.
All original filled outers are rectangular. Padding each model rectangle by
112 µm guarantees at least 0.2239 mm actual source separation, accounting for
the recorded source-bound tolerance. Stock and native guards remain unchanged.

All **117 variables, 291 constraints and the complete valid control** are
independently audited, including 406 expanded rectangle pairs. The sole bounded
call returns **FEASIBLE**, retaining nine incumbents, in 60.040218 solver seconds
and 60.853029 shared seconds. Its returned soft overrun is 0.041680 s. Every
incumbent and final assignment passes the saved-model evaluator. The result is
not an optimum; its solver bound remains 2,061.659 mm.

The new actual core top is **2,107.633 mm**, only **0.017 mm** below the previous
2,107.65 mm. All frames stay unturned and all eleven inserts stay at 90°.
Combined with the unchanged short14, the source43 readback verifies **497 pairs,
172 stock edges and 57 holes / 4,830 hole vertices**. Minimum pair clearance is
0.224 mm and minimum extra stock clearance is 0.013 mm. All 23 remaining originals
are explicitly unplaced. The earlier valid64 remains the best partial layout.

## Exact bound on further height reduction

For each frame/insert quarter turn, take a rectangle inset 2 µm per side.
The independent reader proves containment using 128 exact source halfplane
tests across all eight modes. At a horizontal section, inner widths
449,996 / 349,996 / 179,996 / 109,996 µm receive weights **9 / 7 / 2 / 1**.
Every one of the **214 feasible section-count patterns** fitting the original
1,487,000 µm usable width has total weight at most 28. A separate nested-loop
enumeration verifies the complete pattern set and all quantity caps.

Integrating these section weights over height yields a core-span lower bound
of **14,669,827 / 7 µm**, or **2,095.689571 mm**. Adding the conservative stock
bottom gives an original-core-top lower bound of **2,102.189571 mm**. Relative
to the newly verified top, at most **5.443429 mm** of further height reduction
is possible. This bound covers arbitrary independent positions and all legal
quarter turns of this same 18-frame/11-insert core. It is not a full66 exclusion
and does not rule out beneficial changes to the shape of the remaining space.

Another height-only call is not justified by these results. The next step is
to revalidate the previously source-valid staggered core with brackets embedded
beside frames, then use a new independent-coordinate formulation for all its
25 remaining originals. Its old 2,000-pose finite-pool exclusion stays closed;
owner-dependent geometry must be rebuilt. All 444 necessary short-count
candidates, original quantities, material target and guards remain unchanged.

At publication review, five jobs pass and the Windows check is still running in
[main CI 40728382102](https://github.com/skulitom/Nestbolt/actions/runs/40728382102).
A normal push waits for all six plus fresh remote guards. Production, READMEs
and upstream heads/releases are unchanged. All 22 reserved H2 vectors remain
unopened. No new release qualifies.

[Capacity necessity]({NAME}/capacity-necessity-proof.json),
[capacity response]({NAME}/capacity-response-audit.json),
[core response]({NAME}/core-response-audit.json),
[source readback]({NAME}/core-source-audit.json),
[exact height bound]({NAME}/height-bound-audit.json),
[next construction]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The archive preserves {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including both closed calls, every incumbent, the invalid
timer record, corrected checks, source inputs, complete models and all patterns.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 source capacity and core-height bound, 2026-10-28:** [the evidence]({link})
verifies source-contained rectangles and adds necessary X/Y capacities without
changing the prior independent-position constraints. The sole call closes
UNKNOWN. A separate 29-part core-height call is FEASIBLE, with nine audited
incumbents, but lowers the core by only 0.017 mm. Original source43 passes 497
pairs and all 57 holes. An exact 214-pattern section-weight certificate covers
arbitrary positions and all quarter turns of the same 18-frame/11-insert core:
its top is at least 2,102.189571 mm, allowing at most another 5.443429 mm reduction.
Both calls stay closed, including their soft overruns; the invalid first audit
timer and corrected check are preserved. Next change the core composition using
the source-valid staggered arrangement and a new independent-coordinate model,
rebuilding owner-dependent geometry. The best valid64 and 444-count frontier
remain unchanged. Main d71c9c85 has five passing jobs and Windows live; wait for
all six before pushing. Production, READMEs and upstream releases are unchanged.
H2/H5 remain open at 60%; all 22 reserved vectors remain unopened and no release
qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'bound_source_inputs':len(bindings),'completion_percent':60,'main_windows_live_at_review':True})
