"""Guarded16-turned/two-wide frame core with a central opening and unchanged short15."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SRC=ROOT/'output/h5-source-orientation-construction-20261025';SHORT=ROOT/'output/h5-nine-insert-short-sheet-20261026';OUT=ROOT/'output/h5-central-notch-frame-core-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[JOB,SRC/'items.json',SRC/'geometry.json',SHORT/'short-sheet-placements.json',SHORT/'audit/checks.json',ROOT/'output/h5-fixed36-source-selection-20261026/original-readback/checks.json',ROOT/'output/h5-wide-frame-group-20261023/prior-frame-census.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Move all18 frame originals into four rows of four quarter-turned350x450 frames, followed by two unturned450x350 frames at opposite stock edges. Use0.225mm pair gaps and0.025mm extra stock margin. The two final frames create a central586.5x349.55mm guarded container, without asserting that all remaining parts fit. Preserve the checked15-original short sheet exactly. Historical frame groups8/21 already use sixteen turned and two unturned frames, so no first-ever orientation claim. This new central-opening placement is a construction for the changed short allocation; prior finite pool optima/exclusions do not transfer. All33 remaining originals stay explicit obligations.'})
job=load(JOB);families={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};frames=[];origin=6.525;spacing=.225
for row in range(4):
    for col in range(4):
        x=origin+col*(350+spacing);y=origin+row*(450+spacing);frames.append({'part_id':'frame','copy_index':len(frames),'sheet_id':'sheet-0','transform':{'rotation_radians':math.pi/2,'mirrored':False,'translation':[x+350,y]}})
upper=origin+4*450+4*spacing
for x in [origin,1493.475-450]:frames.append({'part_id':'frame','copy_index':len(frames),'sheet_id':'sheet-0','transform':{'rotation_radians':0.,'mirrored':False,'translation':[x,upper]}})
placements=frames+load(SHORT/'short-sheet-placements.json');placed=[ids[p['part_id'],p['copy_index']] for p in placements];remaining=sorted(set(range(66))-set(placed));assert len(frames)==18 and len(placements)==33 and len(remaining)==33 and len(set(placed))==33;stocks=[[float(F(*v)) for v in row] for row in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);shapes=[];holes=verts=0
for p in placements:
    t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;g=families[p['part_id']]['geometry'][0];filled=affine_transform(Polygon(g['outer']),[mi*co,-si,mi*si,co,*t['translation']]);full=affine_transform(Polygon(g['outer'],g.get('holes',[])),[mi*co,-si,mi*si,co,*t['translation']]);assert filled.is_valid and full.is_valid;holes+=len(full.interiors);verts+=sum(len(h) for h in g.get('holes',[]));sheet=int(p['sheet_id'].split('-')[1]);b=filled.bounds;st=stocks[sheet];assert min(b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3])>guard;shapes.append((sheet,filled))
pairs=0;minimum=math.inf
for (a,p),(b,q) in combinations(shapes,2):
    if a==b:d=p.distance(q);assert p.disjoint(q) and d>gap;pairs+=1;minimum=min(minimum,d)
container={'lower_left_mm':[456.75,upper+.225],'width_mm':586.5,'height_mm':349.55,'pair_gap_mm':.225,'proposed_bracket_originals':[18,19,20,23],'other_remaining_originals':[i for i in remaining if i not in [18,19,20,23]],'purpose':'Try all four bracket originals in the guarded opening. A bounded integer-grid positive is useful only after full original-geometry readback; a negative is not a global first-sheet exclusion.'}
write(OUT/'frame-placements.json',frames);write(OUT/'partial33-placements.json',placements);write(OUT/'mandatory-remaining-originals.json',remaining);write(OUT/'notch-container.json',container);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'frames':18,'turned_frames':16,'wide_frames':2,'short_originals':15,'originals_placed':33,'remaining_originals':33,'same_sheet_pairs':pairs,'stock_edge_checks':132,'cutouts_preserved':holes,'cutout_vertices_preserved':verts,'minimum_pair_gap_mm':minimum,'all66_identities_accounted_once':True,'previous_finite_limits_not_transferred':True,'not_a_partial_count_improvement':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
