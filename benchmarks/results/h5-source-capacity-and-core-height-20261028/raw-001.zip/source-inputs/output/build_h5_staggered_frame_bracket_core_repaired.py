"""Recover the narrow frame-side strip with three original brackets and five inserts."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-staggered-frame-bracket-core-repaired-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SRC=ROOT/'output/h5-source-orientation-construction-20261025';OLD=ROOT/'output/h5-central-nine-insert-core-20261026';SHORT=ROOT/'output/h5-nine-insert-short-sheet-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[JOB,SRC/'items.json',SRC/'geometry.json',OLD/'placements.json',OLD/'audit/checks.json',SHORT/'short-sheet-placements.json',SHORT/'audit/checks.json',ROOT/'output/h5-original-cog-phase-lattice-20261026/wheel-audit/checks.json'];assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Construct a different source core, not another phase/pitch solver. Keep all fifteen short-sheet originals. Retain the first three columns of four turned frames. In the rightmost column, place four turned frames at row spacing560.45mm, creating three110mm-high guarded gaps. Place a90-degree bracket along the right stock side at each gap, with its75mm stem in the unused strip and its250x100 foot in the gap. Put one180x110 insert in the remaining left portion of each gap. Put the two unturned frames adjacent at the left above the first three columns, then two110x180 inserts in the150mm-wide opening to their right. This fixes18 frames, three brackets and five inserts on the first sheet, fifteen originals on the short sheet, and retains all remaining three brackets, seven inserts and fifteen cogs as mandatory. The highest fixed insert rises10.45mm above the old core, while filled first-sheet demand remaining falls40800mm2. No full layout or material improvement claim. No solver/native call. Rebuild every owner-dependent domain before using this new core. No former phase, domain, finite-pool or seed feasibility conclusion transfers.','construction_gap_mm':.225,'extra_stock_mm':.025,'maximum_seconds':30,'bracket_originals':[18,19,20],'insert_originals':[38,39,40,41,42]})
items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};job=load(JOB);parts={p['id']:p for p in job['parts']};placements=[];anchors=[]
def add(original,angle,x,y,description):
    family=items[original]['family'];raw=parts[family]['geometry'][0]['outer'];co,si=math.cos(angle),math.sin(angle);px=min(co*u-si*v for u,v in raw);py=min(si*u+co*v for u,v in raw)
    p={'part_id':family,'copy_index':items[original]['copy'],'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':False,'translation':[x-px,y-py]}};placements.append(p);anchors.append({'original':original,'lower_left_mm':[x,y],'angle_radians':angle,'role':description})
for row in range(4):
    for col in range(4):
        x=6.525+col*350.225;y=6.525+row*(560.45 if col==3 else 450.225);add(4*row+col,math.pi/2,x,y,'right staggered frame' if col==3 else 'unchanged frame grid')
for original,x in [(16,6.525),(17,456.75)]:add(original,0.,x,1807.425,'adjacent upper frame')
for k,original in enumerate([18,19,20]):
    y=456.75+k*560.45;add(original,math.pi/2,1243.475,y,'side-strip bracket');add(38+k,0.,1057.2,y,'insert beside bracket foot')
for k,original in enumerate([41,42]):add(original,math.pi/2,906.975,1807.65+k*180.225,'vertical insert beside upper frames')
first=list(placements);short=load(SHORT/'short-sheet-placements.json');placements+=short;placed=[ids[p['part_id'],p['copy_index']] for p in placements];remaining=sorted(set(range(66))-set(placed));assert len(set(placed))==len(placements)==41 and len(first)==26 and remaining==[23,24,27]+list(range(43,50))+list(range(51,66))
stocks=[[float(F(*v)) for v in row] for row in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);shapes={};edges=[];holes=vertices=0
for p in placements:
    original=ids[p['part_id'],p['copy_index']];t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);g=parts[p['part_id']]['geometry'][0];mi=-1 if t['mirrored'] else 1;a=[mi*co,-si,mi*si,co,*t['translation']];filled=affine_transform(Polygon(g['outer']),a);full=affine_transform(Polygon(g['outer'],g.get('holes',[])),a);assert filled.is_valid and full.is_valid;sheet=int(p['sheet_id'].split('-')[1]);b=filled.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;shapes[original]=(sheet,filled);edges.append({'original':original,'bounds_mm':b,'extra_margins_mm':extra});holes+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]))
pairs=[]
for i,j in combinations(sorted(shapes),2):
    sa,a=shapes[i];sb,b=shapes[j]
    if sa==sb:d=a.distance(b);assert a.disjoint(b) and d>required,(i,j,d);pairs.append({'originals':[i,j],'distance_mm':d})
old_first=[p for p in load(OLD/'placements.json') if p['sheet_id']=='sheet-0'];new_area=sum(Polygon(parts[p['part_id']]['geometry'][0]['outer']).area for p in first);old_area=sum(Polygon(parts[p['part_id']]['geometry'][0]['outer']).area for p in old_first);assert new_area-old_area==40800.
write(OUT/'placements.json',placements);write(OUT/'first-sheet-placements.json',first);write(OUT/'anchors.json',anchors);write(OUT/'mandatory-remaining-originals.json',remaining);write(OUT/'pairs.json',pairs);write(OUT/'stock-edges.json',edges)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_placed':41,'first_originals':26,'short_originals':15,'first_counts':dict(Counter(p['part_id'] for p in first)),'mandatory_remaining_counts':dict(Counter(items[i]['family'] for i in remaining)),'all66_originals_accounted_once':True,'same_sheet_pairs':len(pairs),'stock_edge_checks':164,'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_pair_gap_mm':min(p['distance_mm'] for p in pairs),'minimum_extra_stock_mm':min(min(p['extra_margins_mm']) for p in edges),'previous_first_filled_area_mm2':old_area,'new_first_filled_area_mm2':new_area,'remaining_first_filled_demand_reduction_mm2':40800,'highest_fixed_first_y_mm':max(g.bounds[3] for s,g in shapes.values() if s==0),'highest_old_first_y_mm':2157.425,'old64_partial_preserved':True,'old_domains_or_exclusions_transferred':False,'independent_readback_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
