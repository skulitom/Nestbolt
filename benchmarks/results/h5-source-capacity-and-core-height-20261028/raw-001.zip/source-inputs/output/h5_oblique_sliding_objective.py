"""Continuous source-obstacle penalty; no optimization or file mutation on import."""
from pathlib import Path
import json
import numpy as np
import shapely
from shapely.geometry import shape
from shapely.affinity import affine_transform
class SlidingObjective:
    def __init__(self,base):
        self.base=Path(base);load=lambda p:json.loads(p.read_bytes());self.modes=load(self.base/'modes.json');self.moving=load(self.base/'moving.json');self.mode_count=len(self.modes);self.free=np.asarray([shape(load(self.base/'free'/f'{i:02d}.json')) for i in range(self.mode_count)],dtype=object);saved={(i,j):shape(load(self.base/'obstacles'/f'{i:02d}-{j:02d}.json')) for i in range(self.mode_count) for j in range(i,self.mode_count)};self.obstacles=np.asarray([saved[i,j] if i<=j else affine_transform(saved[j,i],[-1,0,0,-1,0,0]) for i in range(self.mode_count) for j in range(self.mode_count)],dtype=object);self.boundaries=shapely.boundary(self.obstacles);self.left,self.right=np.triu_indices(len(self.moving),1)
    def evaluate(self,flat,modes):
        xy=np.asarray(flat,dtype=float).reshape(-1,2);modes=np.asarray(modes,dtype=int);delta=xy[self.right]-xy[self.left];points=shapely.points(delta);indices=modes[self.left]*self.mode_count+modes[self.right];inside=shapely.contains(self.obstacles[indices],points);gradient=np.zeros_like(xy);pair_cost=0.;max_pair=0.
        if np.any(inside):
            nearest=shapely.get_coordinates(shapely.get_point(shapely.shortest_line(points[inside],self.boundaries[indices[inside]]),1));difference=delta[inside]-nearest;pair_cost=float(np.sum(difference*difference));max_pair=float(np.max(np.linalg.norm(difference,axis=1)));np.add.at(gradient,self.right[inside],2*difference);np.add.at(gradient,self.left[inside],-2*difference)
        anchors=shapely.points(xy);outside=~shapely.covers(self.free[modes],anchors);fixed_cost=0.;max_fixed=0.
        if np.any(outside):
            nearest=shapely.get_coordinates(shapely.get_point(shapely.shortest_line(anchors[outside],self.free[modes[outside]]),1));difference=xy[outside]-nearest;fixed_cost=float(np.sum(difference*difference));max_fixed=float(np.max(np.linalg.norm(difference,axis=1)));gradient[outside]+=8*difference
        return pair_cost+4*fixed_cost,gradient.reshape(-1),{'pair_penalty_mm2':pair_cost,'fixed_penalty_mm2':fixed_cost,'overlapping_configuration_pairs':int(np.sum(inside)),'anchors_outside_free_regions':int(np.sum(outside)),'maximum_pair_depth_mm':max_pair,'maximum_fixed_depth_mm':max_fixed}
    def placements(self,flat,modes):
        rows=[]
        for item,mi,xy in zip(self.moving,modes,np.asarray(flat).reshape(-1,2)):
            mode=self.modes[int(mi)];assert mi in item['allowed_modes'];rows.append({'part_id':item['family'],'copy_index':item['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['angle'],'mirrored':mode['mirrored'],'translation':[float(xy[k]+mode['source_translation_offset'][k]) for k in range(2)]}})
        return rows
