"""New mixed-row frame transforms, with the verified fifteen-part short sheet."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,math,shutil
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-mixed-rows-core-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SRC=ROOT/'output/h5-source-orientation-construction-20261025';SHORT=ROOT/'output/h5-nine-insert-short-sheet-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py')
inputs=[JOB,SRC/'items.json',SHORT/'short-sheet-placements.json',SHORT/'audit/checks.json',ROOT/'output/h5-paired-strip-joint-model-20261026/response-audit/checks.json']
assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Twelve quarter-turned frames in four columns by three rows, followed by six unturned frames in three columns by two rows. Preserve the fifteen-part short sheet exactly. All six remaining brackets, twelve inserts and fifteen cogs stay mandatory on the first sheet. This changes the paired-strip frame core and reduces its top; it is not claimed to be a globally new frame topology or a better partial layout. Compare against the historical twenty-nine frame groups. Independently verify the current core before generating actual-source joint contacts. No old geometric exclusions transfer. No solver or native call.','construction_gap_mm':.225,'extra_stock_mm':.025})
job=load(JOB);parts={p['id']:p for p in job['parts']};items=load(SRC/'items.json');rows=[]
for i in range(18):
    if i<12:r,c=divmod(i,4);a=math.pi/2;x=6.525+c*350.225;y=6.525+r*450.225
    else:r,c=divmod(i-12,3);a=0.;x=6.525+c*450.225;y=1357.2+r*350.225
    cs,sn=math.cos(a),math.sin(a);g=affine_transform(Polygon(parts['frame']['geometry'][0]['outer']),[cs,-sn,sn,cs,0,0]);b=g.bounds
    rows.append({'part_id':'frame','copy_index':items[i]['copy'],'sheet_id':'sheet-0','transform':{'rotation_radians':a,'mirrored':False,'translation':[x-b[0],y-b[1]]}})
short=load(SHORT/'short-sheet-placements.json');allrows=rows+short;ids={(p['family'],p['copy']):i for i,p in enumerate(items)};remaining=sorted(set(range(66))-{ids[p['part_id'],p['copy_index']] for p in allrows})
write(OUT/'first-sheet-placements.json',rows);write(OUT/'placements.json',allrows);write(OUT/'mandatory-remaining-originals.json',remaining)
write(OUT/'result.json',{'first_originals':18,'short_originals':15,'mandatory_moving_counts':dict(Counter(items[i]['family'] for i in remaining)),'highest_fixed_first_y_mm':2057.425,'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'result.json'))
