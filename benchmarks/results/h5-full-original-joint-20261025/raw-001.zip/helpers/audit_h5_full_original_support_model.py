"""Independent protobuf oracle for the complete constructive original model."""
from collections import Counter
from itertools import combinations,product
from ortools.sat import cp_model_pb2

def verify(actual,spec,queries,atlas,aux):
    vi=ci=domains=modes=inside=outside=componentpairs=supportvars=0
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]),(vi,name)
        vi+=1;return vi-1
    def linear(terms,lo,hi,en=()):
        nonlocal ci
        sums=Counter()
        for i,c in terms:sums[i]+=c
        ids=sorted(i for i,c in sums.items() if c);p=cp_model_pb2.ConstraintProto()
        p.enforcement_literal.extend(en);p.linear.vars.extend(ids);p.linear.coeffs.extend(sums[i] for i in ids);p.linear.domain.extend([lo,hi])
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    def boolean(kind,lits):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();getattr(p,kind).literals.extend(lits)
        assert actual.constraints[ci]==p,(ci,kind);ci+=1
    parts=[]
    for i,item in enumerate(spec['parts']):
        prefix=f'part{i}';x=var(prefix+'-x',0,1500000);y=var(prefix+'-y',0,3000000);sheet=var(prefix+'-sheet',0,1);options=[]
        for qi in item['queries']:
            q=spec['queries'][qi];tag=prefix+f'-query{qi}';active=var(tag+'-active',0,1);ds=[]
            bounds=q['anchor_bounds_units1000'];linear([(x,1)],bounds[0],bounds[2],[active]);linear([(y,1)],bounds[1],bounds[3],[active])
            for face in queries[qi]['domains']:
                d=var(tag+f"-face{face['index']}",0,1);ds.append(d);b=face['coordinate_bounds']
                linear([(x,1)],b[0],b[2],[d]);linear([(y,1)],b[1],b[3],[d])
                for h in face['halfplanes']:
                    assert h['sense']=='le';linear([(x,h['a']),(y,h['b'])],-2**63,h['bound'],[d]);inside+=1
            linear([(d,1) for d in ds]+[(active,-1)],0,0)
            options.append({'query':qi,'profile':q['profile'],'sheet':q['sheet'],'active':active,'domains':ds});domains+=len(ds);modes+=1
        assert sorted(spec['queries'][m['query']]['mode'] for m in options)==item['allowed_modes']
        boolean('exactly_one',[m['active'] for m in options]);linear([(sheet,1)]+[(m['active'],-1) for m in options if m['sheet']],0,0)
        components=[]
        for arm in range(2 if item['family']=='bracket' else 1):
            supports=[]
            for n,(nx,ny) in enumerate(atlas['normals']):
                from fractions import Fraction as F
                import math
                vals=[math.ceil(1000*max(nx*F(px)+ny*F(py) for px,py in atlas['profiles'][m['profile']]['components'][arm])) for m in options]
                assert vals==[atlas['profiles'][m['profile']]['supports'][arm][n] for m in options]
                v=var(prefix+f'-component{arm}-support{n}',min(vals),max(vals));supportvars+=1
                linear([(v,1)]+[(m['active'],-val) for m,val in zip(options,vals)],0,0);supports.append(v)
            components.append(supports)
        parts.append({'part':i,'item':item['index'],'family':item['family'],'x':x,'y':y,'sheet':sheet,'modes':options,'components':components})
    assert len(parts)==9 and [p['item'] for p in parts]==[28,29,50,54,57,58,62,64,65]
    charges=[aux['part_areas'][p['family']]['lower_units'] for p in parts]
    linear([(p['sheet'],-c) for p,c in zip(parts,charges)],-2**63,aux['sheet_capacities'][0]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][0]-sum(charges))
    linear([(p['sheet'],c) for p,c in zip(parts,charges)],-2**63,aux['sheet_capacities'][1]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][1])
    pairs=[]
    for i,j in combinations(range(9),2):
        a,b=parts[i],parts[j];prefix=f'pair{i}-{j}';different=var(prefix+'-different-sheet',0,1)
        boolean('bool_xor',[a['sheet'],b['sheet'],-different-1])
        for sa,sb in product([0,1],repeat=2):assert [d for d in [0,1] if (sa+sb+1-d)%2]==[int(sa!=sb)]
        ps=[]
        for ai,bi in product(range(len(a['components'])),range(len(b['components']))):
            dirs=[];componentpairs+=1
            for n,(nx,ny) in enumerate(atlas['normals']):
                d=var(prefix+f'-components{ai}-{bi}-normal{n}',0,1);dirs.append(d);opp=atlas['opposites'][n]
                norm=math.isqrt(nx*nx+ny*ny);norm+=norm*norm<nx*nx+ny*ny;gap=math.ceil(F(17,80)*1000*norm)
                assert gap==atlas['clearance_projection_units'][n]
                linear([(b['x'],nx),(a['x'],-nx),(b['y'],ny),(a['y'],-ny),(a['components'][ai][n],-1),(b['components'][bi][opp],-1)],gap,2**63-1,[d]);outside+=1
            boolean('bool_or',[different]+dirs);ps.append({'components':[ai,bi],'directions':dirs})
        pairs.append({'parts':[i,j],'different_sheet':different,'component_pairs':ps})
    assert atlas['copy_x_order_pairs']==[[0,1],[3,4],[4,5],[5,6],[6,7],[7,8]]
    for i,j in atlas['copy_x_order_pairs']:
        assert all(spec['parts'][i][k]==spec['parts'][j][k] for k in ['family','queries','profiles','allowed_modes'])
        linear([(parts[i]['x'],1),(parts[j]['x'],-1)],-2**63,0)
    assert len(pairs)==36
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');assert not extra.ListFields()
    return {'parts':parts,'pairs':pairs},{'variables':vi,'constraints':ci,'fixed_originals':57,'mandatory_moving_originals':9,'required_originals':66,
        'mode_options':modes,'allowed_convex_domains':domains,'support_variables':supportvars,'inward_allowed_halfplanes':inside,
        'physical_pairs':36,'cross_part_convex_component_pairs':componentpairs,'sufficient_outside_halfplanes':outside,
        'original_area_constraints':2,'hints':0,'objectives':0,'optional_original_parts':0,'copy_order_constraints':6,
        'every_permitted_mode_retained':True,'same_sheet_xor_truth_tables_checked':True,'all_component_pairs_have_sufficient_clearance':True,'copy_order_permutation_certificate_checked':True}
