from itertools import combinations
from ortools.sat.python import cp_model

def build(spec,queries,mutual,aux,cuts,orders):
    model=cp_model.CpModel();vs=[]
    def var(name,lo,hi):
        v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi,en=()):
        c=model.add_linear_constraint(sum(vs[i]*coef for i,coef in terms),lo,hi)
        if en:c.only_enforce_if([vs[i] for i in en])
    parts=[]
    for pi,item in enumerate(spec['parts']):
        prefix=f'part{pi}';x=var(prefix+'-x',0,1500000);y=var(prefix+'-y',0,3000000);sheet=var(prefix+'-sheet',0,1);modes=[]
        for qi in item['queries']:
            q=spec['queries'][qi];tag=prefix+f'-query{qi}';active=var(tag+'-active',0,1);ds=[];bounds=q['anchor_bounds_units1000']
            linear([(x,1)],bounds[0],bounds[2],[active]);linear([(y,1)],bounds[1],bounds[3],[active])
            for face in queries[qi]['domains']:
                d=var(tag+f"-face{face['index']}",0,1);ds.append(d);b=face['coordinate_bounds']
                linear([(x,1)],b[0],b[2],[d]);linear([(y,1)],b[1],b[3],[d])
                for h in face['halfplanes']:linear([(x,h['a']),(y,h['b'])],cp_model.INT_MIN,h['bound'],[d])
            linear([(d,1) for d in ds]+[(active,-1)],0,0)
            modes.append({'query':qi,'profile':q['profile'],'sheet':q['sheet'],'active':active,'domains':ds})
        model.add_exactly_one([vs[m['active']] for m in modes]);linear([(sheet,1)]+[(m['active'],-m['sheet']) for m in modes],0,0)
        flags=[]
        for profile in item['profiles']:
            v=var(prefix+f'-profile{profile}',0,1);linear([(v,1)]+[(m['active'],-1) for m in modes if m['profile']==profile],0,0)
            flags.append({'profile':profile,'active':v})
        parts.append({'part':pi,'item':item['index'],'family':item['family'],'x':x,'y':y,'sheet':sheet,'modes':modes,'profiles':flags})
    charges=[aux['part_areas'][p['family']]['lower_units'] for p in parts]
    linear([(p['sheet'],-charge) for p,charge in zip(parts,charges)],cp_model.INT_MIN,aux['sheet_capacities'][0]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][0]-sum(charges))
    linear([(p['sheet'],charge) for p,charge in zip(parts,charges)],cp_model.INT_MIN,aux['sheet_capacities'][1]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][1])
    pairs=[]
    for a,b in combinations(parts,2):
        v=var(f"pair{a['part']}-{b['part']}-different-sheet",0,1)
        model.add_bool_xor([vs[a['sheet']],vs[b['sheet']],vs[v].Not()])
        pairs.append({'parts':[a['part'],b['part']],'different_sheet':v})
    for i,j in orders:linear([(parts[i]['x'],1),(parts[j]['x'],-1)],cp_model.INT_MIN,0)
    pmap={tuple(p['parts']):p for p in pairs};details=[]
    for number,(i,j,case,fi) in enumerate(cuts):
        a,b=parts[i],parts[j];row=mutual[case];face=row['faces'][fi];assert face['index']==fi
        pa=next(p for p in a['profiles'] if p['profile']==row['case']['profile_a'])
        pb=next(p for p in b['profiles'] if p['profile']==row['case']['profile_b']);dirs=[]
        for n,h in enumerate(face['outside_halfplanes']):
            d=var(f'cut{number}-edge{n}',0,1);dirs.append(d)
            linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],cp_model.INT_MAX,[d])
        model.add_bool_or([vs[pmap[(i,j)]['different_sheet']],vs[pa['active']].Not(),vs[pb['active']].Not()]+[vs[d] for d in dirs])
        details.append({'key':[i,j,case,fi],'directions':dirs})
    return model,vs,{'parts':parts,'pairs':pairs,'cuts':details}
