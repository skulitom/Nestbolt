"""Independent protobuf oracle for the complete constructive original model."""
from collections import Counter
from itertools import combinations,product
from ortools.sat import cp_model_pb2

def verify(actual,spec,queries,mutual,aux):
    vi=ci=domains=modes=inside=outside=forbidden=cases=profiles=0
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]),(vi,name)
        vi+=1;return vi-1
    def linear(terms,lo,hi,en=()):
        nonlocal ci
        sums=Counter()
        for i,c in terms:sums[i]+=c
        ids=sorted(i for i,c in sums.items() if c);p=cp_model_pb2.ConstraintProto()
        p.enforcement_literal.extend(en);p.linear.vars.extend(ids);p.linear.coeffs.extend(sums[i] for i in ids);p.linear.domain.extend([lo,hi])
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    def boolean(kind,lits):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();getattr(p,kind).literals.extend(lits)
        assert actual.constraints[ci]==p,(ci,kind);ci+=1
    parts=[]
    for i,item in enumerate(spec['parts']):
        prefix=f'part{i}';x=var(prefix+'-x',0,1500000);y=var(prefix+'-y',0,3000000);sheet=var(prefix+'-sheet',0,1);options=[]
        for qi in item['queries']:
            q=spec['queries'][qi];tag=prefix+f'-query{qi}';active=var(tag+'-active',0,1);ds=[]
            bounds=q['anchor_bounds_units1000'];linear([(x,1)],bounds[0],bounds[2],[active]);linear([(y,1)],bounds[1],bounds[3],[active])
            for face in queries[qi]['domains']:
                d=var(tag+f"-face{face['index']}",0,1);ds.append(d);b=face['coordinate_bounds']
                linear([(x,1)],b[0],b[2],[d]);linear([(y,1)],b[1],b[3],[d])
                for h in face['halfplanes']:
                    assert h['sense']=='le';linear([(x,h['a']),(y,h['b'])],-2**63,h['bound'],[d]);inside+=1
            linear([(d,1) for d in ds]+[(active,-1)],0,0)
            options.append({'query':qi,'profile':q['profile'],'sheet':q['sheet'],'active':active,'domains':ds});domains+=len(ds);modes+=1
        assert sorted(spec['queries'][m['query']]['mode'] for m in options)==item['allowed_modes']
        boolean('exactly_one',[m['active'] for m in options]);linear([(sheet,1)]+[(m['active'],-1) for m in options if m['sheet']],0,0)
        flags=[]
        for profile in item['profiles']:
            v=var(prefix+f'-profile{profile}',0,1);linear([(v,1)]+[(m['active'],-1) for m in options if m['profile']==profile],0,0)
            flags.append({'profile':profile,'active':v});profiles+=1
        parts.append({'part':i,'item':item['index'],'family':item['family'],'x':x,'y':y,'sheet':sheet,'modes':options,'profiles':flags})
    assert len(parts)==9 and [p['item'] for p in parts]==[28,29,50,54,57,58,62,64,65]
    charges=[aux['part_areas'][p['family']]['lower_units'] for p in parts]
    linear([(p['sheet'],-c) for p,c in zip(parts,charges)],-2**63,aux['sheet_capacities'][0]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][0]-sum(charges))
    linear([(p['sheet'],c) for p,c in zip(parts,charges)],-2**63,aux['sheet_capacities'][1]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][1])
    cache={(r['profile_a'],r['profile_b']):r['index'] for r in spec['mutual_cases']};pairs=[]
    for i,j in combinations(range(9),2):
        a,b=parts[i],parts[j];prefix=f'pair{i}-{j}';different=var(prefix+'-different-sheet',0,1)
        boolean('bool_xor',[a['sheet'],b['sheet'],-different-1])
        for sa,sb in product([0,1],repeat=2):assert [d for d in [0,1] if (sa+sb+1-d)%2]==[int(sa!=sb)]
        used=[]
        for pa,pb in product(a['profiles'],b['profiles']):
            case=cache[(pa['profile'],pb['profile'])];row=mutual[case];faces=[];cases+=1
            for face in row['faces']:
                dirs=[];forbidden+=1
                for hi,h in enumerate(face['outside_halfplanes']):
                    assert h['sense']=='ge';v=var(prefix+f"-case{case}-face{face['index']}-edge{hi}",0,1);dirs.append(v)
                    linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],2**63-1,[v]);outside+=1
                boolean('bool_or',[different,-pa['active']-1,-pb['active']-1]+dirs)
                faces.append({'face':face['index'],'directions':dirs})
            used.append({'case':case,'profile_a':pa['profile'],'profile_b':pb['profile'],'faces':faces})
        pairs.append({'parts':[i,j],'different_sheet':different,'cases':used})
    assert len(pairs)==36
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');assert not extra.ListFields()
    return {'parts':parts,'pairs':pairs},{'variables':vi,'constraints':ci,'fixed_originals':57,'mandatory_moving_originals':9,'required_originals':66,
        'mode_options':modes,'allowed_convex_domains':domains,'profile_flags':profiles,'inward_allowed_halfplanes':inside,
        'physical_pairs':36,'ordered_profile_pair_uses':cases,'forbidden_piece_disjunctions':forbidden,'sufficient_outside_halfplanes':outside,
        'original_area_constraints':2,'hints':0,'objectives':0,'optional_original_parts':0,'copy_order_constraints':0,
        'every_permitted_mode_retained':True,'same_sheet_xor_truth_tables_checked':True,'all_forbidden_pieces_required_for_active_profile_pair':True}
