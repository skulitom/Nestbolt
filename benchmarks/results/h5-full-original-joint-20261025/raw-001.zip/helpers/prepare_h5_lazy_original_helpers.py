"""Prepare a distinct bounded constraint-generation experiment."""
from pathlib import Path
R=Path(__file__).resolve().parent
original=(R/'solve_h5_full_original_joint.py').read_text(encoding='utf-8')
body=original[original.index('    start=time.perf_counter();model='):original.index('    cache={(c[')]
body=body.replace('start=time.perf_counter();model=','model=')
suffix='''    pairs=[]
    for a,b in combinations(parts,2):
        v=var(f"pair{a['part']}-{b['part']}-different-sheet",0,1)
        model.add_bool_xor([vs[a['sheet']],vs[b['sheet']],vs[v].Not()])
        pairs.append({'parts':[a['part'],b['part']],'different_sheet':v})
    for i,j in orders:linear([(parts[i]['x'],1),(parts[j]['x'],-1)],cp_model.INT_MIN,0)
    pmap={tuple(p['parts']):p for p in pairs};details=[]
    for number,(i,j,case,fi) in enumerate(cuts):
        a,b=parts[i],parts[j];row=mutual[case];face=row['faces'][fi];assert face['index']==fi
        pa=next(p for p in a['profiles'] if p['profile']==row['case']['profile_a'])
        pb=next(p for p in b['profiles'] if p['profile']==row['case']['profile_b']);dirs=[]
        for n,h in enumerate(face['outside_halfplanes']):
            d=var(f'cut{number}-edge{n}',0,1);dirs.append(d)
            linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],cp_model.INT_MAX,[d])
        model.add_bool_or([vs[pmap[(i,j)]['different_sheet']],vs[pa['active']].Not(),vs[pb['active']].Not()]+[vs[d] for d in dirs])
        details.append({'key':[i,j,case,fi],'directions':dirs})
    return model,vs,{'parts':parts,'pairs':pairs,'cuts':details}
'''
builder='from itertools import combinations\nfrom ortools.sat.python import cp_model\n\ndef build(spec,queries,mutual,aux,cuts,orders):\n'+body+suffix
with (R/'build_h5_lazy_original_model.py').open('x',encoding='utf-8',newline='\n') as f:f.write(builder)
s=(R/'audit_h5_full_original_joint_model.py').read_text(encoding='utf-8')
s=s[:s.index('    cache={(r[')]
s=s.replace('verify(actual,spec,queries,mutual,aux):','verify(actual,spec,queries,mutual,aux,cuts,orders):')
s+='''    pairs=[]
    for i,j in combinations(range(9),2):
        a,b=parts[i],parts[j];v=var(f'pair{i}-{j}-different-sheet',0,1)
        boolean('bool_xor',[a['sheet'],b['sheet'],-v-1]);pairs.append({'parts':[i,j],'different_sheet':v})
    assert orders==[[0,1],[3,4],[4,5],[5,6],[6,7],[7,8]]
    for i,j in orders:
        assert all(spec['parts'][i][k]==spec['parts'][j][k] for k in ['family','queries','profiles','allowed_modes'])
        linear([(parts[i]['x'],1),(parts[j]['x'],-1)],-2**63,0)
    pairmap={tuple(p['parts']):p for p in pairs};details=[]
    assert len(cuts)==len(set(tuple(k) for k in cuts))
    for number,(i,j,case,fi) in enumerate(cuts):
        assert i<j;a,b=parts[i],parts[j];r=mutual[case];face=r['faces'][fi];assert face['index']==fi
        pa=next(p for p in a['profiles'] if p['profile']==r['case']['profile_a'])
        pb=next(p for p in b['profiles'] if p['profile']==r['case']['profile_b']);dirs=[]
        for n,h in enumerate(face['outside_halfplanes']):
            assert h['sense']=='ge';v=var(f'cut{number}-edge{n}',0,1);dirs.append(v);outside+=1
            linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],2**63-1,[v])
        boolean('bool_or',[pairmap[(i,j)]['different_sheet'],-pa['active']-1,-pb['active']-1]+dirs)
        details.append({'key':[i,j,case,fi],'directions':dirs})
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');assert not extra.ListFields()
    return {'parts':parts,'pairs':pairs,'cuts':details},{'variables':vi,'constraints':ci,'fixed_originals':57,'mandatory_moving_originals':9,
        'required_originals':66,'mode_options':modes,'allowed_convex_domains':domains,'inward_allowed_halfplanes':inside,
        'physical_pairs':36,'active_forbidden_piece_cuts':len(cuts),'sufficient_outside_halfplanes':outside,'original_area_constraints':2,
        'copy_order_constraints':6,'hints':0,'objectives':0,'optional_original_parts':0,'all_remaining_collision_pieces_checked_on_every_candidate':False}
'''
with (R/'audit_h5_lazy_original_model.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared complete base model and independent oracle; no solve.')
