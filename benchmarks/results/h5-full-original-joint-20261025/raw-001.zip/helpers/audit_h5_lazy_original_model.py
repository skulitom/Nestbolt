"""Independent protobuf oracle for the complete constructive original model."""
from collections import Counter
from itertools import combinations,product
from ortools.sat import cp_model_pb2

def verify(actual,spec,queries,mutual,aux,cuts,orders):
    vi=ci=domains=modes=inside=outside=forbidden=cases=profiles=0
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]),(vi,name)
        vi+=1;return vi-1
    def linear(terms,lo,hi,en=()):
        nonlocal ci
        sums=Counter()
        for i,c in terms:sums[i]+=c
        ids=sorted(i for i,c in sums.items() if c);p=cp_model_pb2.ConstraintProto()
        p.enforcement_literal.extend(en);p.linear.vars.extend(ids);p.linear.coeffs.extend(sums[i] for i in ids);p.linear.domain.extend([lo,hi])
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    def boolean(kind,lits):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();getattr(p,kind).literals.extend(lits)
        assert actual.constraints[ci]==p,(ci,kind);ci+=1
    parts=[]
    for i,item in enumerate(spec['parts']):
        prefix=f'part{i}';x=var(prefix+'-x',0,1500000);y=var(prefix+'-y',0,3000000);sheet=var(prefix+'-sheet',0,1);options=[]
        for qi in item['queries']:
            q=spec['queries'][qi];tag=prefix+f'-query{qi}';active=var(tag+'-active',0,1);ds=[]
            bounds=q['anchor_bounds_units1000'];linear([(x,1)],bounds[0],bounds[2],[active]);linear([(y,1)],bounds[1],bounds[3],[active])
            for face in queries[qi]['domains']:
                d=var(tag+f"-face{face['index']}",0,1);ds.append(d);b=face['coordinate_bounds']
                linear([(x,1)],b[0],b[2],[d]);linear([(y,1)],b[1],b[3],[d])
                for h in face['halfplanes']:
                    assert h['sense']=='le';linear([(x,h['a']),(y,h['b'])],-2**63,h['bound'],[d]);inside+=1
            linear([(d,1) for d in ds]+[(active,-1)],0,0)
            options.append({'query':qi,'profile':q['profile'],'sheet':q['sheet'],'active':active,'domains':ds});domains+=len(ds);modes+=1
        assert sorted(spec['queries'][m['query']]['mode'] for m in options)==item['allowed_modes']
        boolean('exactly_one',[m['active'] for m in options]);linear([(sheet,1)]+[(m['active'],-1) for m in options if m['sheet']],0,0)
        flags=[]
        for profile in item['profiles']:
            v=var(prefix+f'-profile{profile}',0,1);linear([(v,1)]+[(m['active'],-1) for m in options if m['profile']==profile],0,0)
            flags.append({'profile':profile,'active':v});profiles+=1
        parts.append({'part':i,'item':item['index'],'family':item['family'],'x':x,'y':y,'sheet':sheet,'modes':options,'profiles':flags})
    assert len(parts)==9 and [p['item'] for p in parts]==[28,29,50,54,57,58,62,64,65]
    charges=[aux['part_areas'][p['family']]['lower_units'] for p in parts]
    linear([(p['sheet'],-c) for p,c in zip(parts,charges)],-2**63,aux['sheet_capacities'][0]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][0]-sum(charges))
    linear([(p['sheet'],c) for p,c in zip(parts,charges)],-2**63,aux['sheet_capacities'][1]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][1])
    pairs=[]
    for i,j in combinations(range(9),2):
        a,b=parts[i],parts[j];v=var(f'pair{i}-{j}-different-sheet',0,1)
        boolean('bool_xor',[a['sheet'],b['sheet'],-v-1]);pairs.append({'parts':[i,j],'different_sheet':v})
    assert orders==[[0,1],[3,4],[4,5],[5,6],[6,7],[7,8]]
    for i,j in orders:
        assert all(spec['parts'][i][k]==spec['parts'][j][k] for k in ['family','queries','profiles','allowed_modes'])
        linear([(parts[i]['x'],1),(parts[j]['x'],-1)],-2**63,0)
    pairmap={tuple(p['parts']):p for p in pairs};details=[]
    assert len(cuts)==len(set(tuple(k) for k in cuts))
    for number,(i,j,case,fi) in enumerate(cuts):
        assert i<j;a,b=parts[i],parts[j];r=mutual[case];face=r['faces'][fi];assert face['index']==fi
        pa=next(p for p in a['profiles'] if p['profile']==r['case']['profile_a'])
        pb=next(p for p in b['profiles'] if p['profile']==r['case']['profile_b']);dirs=[]
        for n,h in enumerate(face['outside_halfplanes']):
            assert h['sense']=='ge';v=var(f'cut{number}-edge{n}',0,1);dirs.append(v);outside+=1
            linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],2**63-1,[v])
        boolean('bool_or',[pairmap[(i,j)]['different_sheet'],-pa['active']-1,-pb['active']-1]+dirs)
        details.append({'key':[i,j,case,fi],'directions':dirs})
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');assert not extra.ListFields()
    return {'parts':parts,'pairs':pairs,'cuts':details},{'variables':vi,'constraints':ci,'fixed_originals':57,'mandatory_moving_originals':9,
        'required_originals':66,'mode_options':modes,'allowed_convex_domains':domains,'inward_allowed_halfplanes':inside,
        'physical_pairs':36,'active_forbidden_piece_cuts':len(cuts),'sufficient_outside_halfplanes':outside,'original_area_constraints':2,
        'copy_order_constraints':6,'hints':0,'objectives':0,'optional_original_parts':0,'all_remaining_collision_pieces_checked_on_every_candidate':False}
