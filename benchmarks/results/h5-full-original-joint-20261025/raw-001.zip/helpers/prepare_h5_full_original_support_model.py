"""Write a distinct audited projection model; do not modify or retry prior model."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def replace(s,old,new):
    assert s.count(old)==1,(old,s.count(old));return s.replace(old,new)
def between(s,a,b,new):
    assert s.count(a)==s.count(b)==1;lo=s.index(a);hi=s.index(b,lo);return s[:lo]+new+s[hi:]

s=(ROOT/'solve_h5_full_original_joint.py').read_text(encoding='utf-8')
s=replace(s,'from audit_h5_full_original_joint_model import verify','from audit_h5_full_original_support_model import verify')
s=replace(s,"OUT=BASE/'solve'","SUP=BASE/'support-construction';OUT=SUP/'solve'")
s=replace(s,"assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')","assert load(BASE/'audit/checks.json')['passed'] and load(SUP/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')")
s=replace(s,"mutual={q['index']:load(BASE/'mutual'/f\"{q['index']:03d}.json\") for q in spec['mutual_cases']}","atlas=load(SUP/'atlas.json')")
s=replace(s,"ROOT/'output/audit_h5_full_original_joint_model.py'","ROOT/'output/audit_h5_full_original_support_model.py',SUP/'plan.json',SUP/'atlas.json',SUP/'audit/checks.json'")
s=replace(s,",'mutual_hashes':{str(i):digest(BASE/'mutual'/f'{i:03d}.json') for i in mutual}","")
lo=s.index("        'method':'");hi=s.index("})\n",lo)
s=s[:lo]+"        'method':'Retain all9 mandatory full-original identities and every full-original inward free-region query on the1-micrometre grid. For moving-to-moving collision only, cover each cog by its certified40-vertex original convex hull; every bracket remains two exact arms. Use44 integer projection directions, exact upward support ceilings and sufficient0.2125mm separation with upward Euclidean-normal bounds. Both original sheet area charges remain required. Add6 x-order inequalities only within two independently certified exchangeable copy groups. This removes equivalent labels, while the cog hull is an explicit constructive restriction. All variables, constraints, parameters and copy orders are independently audited before one distinct60-second/eight-worker/seed-zero call. The preceding full-NFP UNKNOWN call remains closed. A candidate requires complete66-original geometry and native validation; no negative here establishes unrestricted impossibility.'"+s[hi:]
s=between(s,'        flags=[]\n','    charges=', '''        components=[]
        for arm in range(2 if item['family']=='bracket' else 1):
            supports=[]
            for n in range(len(atlas['normals'])):
                vals=[atlas['profiles'][m['profile']]['supports'][arm][n] for m in modes]
                v=var(prefix+f'-component{arm}-support{n}',min(vals),max(vals))
                linear([(v,1)]+[(m['active'],-val) for m,val in zip(modes,vals)],0,0);supports.append(v)
            components.append(supports)
        parts.append({'part':pi,'item':item['index'],'family':item['family'],'x':x,'y':y,'sheet':sheet,'modes':modes,'components':components})
''')
s=between(s,'    cache={(c[','    mapping=', '''    pairs=[]
    for a,b in combinations(parts,2):
        prefix=f"pair{a['part']}-{b['part']}";different=var(prefix+'-different-sheet',0,1)
        model.add_bool_xor([vs[a['sheet']],vs[b['sheet']],vs[different].Not()]);component_pairs=[]
        for ai,bi in product(range(len(a['components'])),range(len(b['components']))):
            dirs=[]
            for n,(nx,ny) in enumerate(atlas['normals']):
                d=var(prefix+f'-components{ai}-{bi}-normal{n}',0,1);dirs.append(d);opp=atlas['opposites'][n]
                linear([(b['x'],nx),(a['x'],-nx),(b['y'],ny),(a['y'],-ny),(a['components'][ai][n],-1),(b['components'][bi][opp],-1)],
                       atlas['clearance_projection_units'][n],cp_model.INT_MAX,[d])
            model.add_bool_or([vs[different]]+[vs[d] for d in dirs]);component_pairs.append({'components':[ai,bi],'directions':dirs})
        pairs.append({'parts':[a['part'],b['part']],'different_sheet':different,'component_pairs':component_pairs})
    for i,j in atlas['copy_x_order_pairs']:linear([(parts[i]['x'],1),(parts[j]['x'],-1)],cp_model.INT_MIN,0)
''')
s=replace(s,'verify(actual,spec,queries,mutual,aux)','verify(actual,spec,queries,atlas,aux)')
s=replace(s,"'Adjusted57-fixed/9-mandatory-original source-angle/inward-grid constructive neighborhood. Conditional negatives; UNKNOWN unresolved. A positive requires independent66-original geometry and native validation, then production-budget integration and all13 jobs at both kerfs.'","'Adjusted57-fixed/9-mandatory-original source-angle/inward-grid construction with conservative full cog hulls only for moving pairs and permutation-safe copy orders. Conditional negatives; UNKNOWN unresolved. A positive requires independent66-original geometry and native validation, production-budget integration and all13 jobs at both kerfs.'")
with (ROOT/'solve_h5_full_original_supports.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)

s=(ROOT/'audit_h5_full_original_joint_model.py').read_text(encoding='utf-8')
s=replace(s,'verify(actual,spec,queries,mutual,aux)','verify(actual,spec,queries,atlas,aux)')
s=replace(s,'vi=ci=domains=modes=inside=outside=forbidden=cases=profiles=0','vi=ci=domains=modes=inside=outside=componentpairs=supportvars=0')
s=between(s,'        flags=[]\n','    assert len(parts)', '''        components=[]
        for arm in range(2 if item['family']=='bracket' else 1):
            supports=[]
            for n,(nx,ny) in enumerate(atlas['normals']):
                from fractions import Fraction as F
                import math
                vals=[math.ceil(1000*max(nx*F(px)+ny*F(py) for px,py in atlas['profiles'][m['profile']]['components'][arm])) for m in options]
                assert vals==[atlas['profiles'][m['profile']]['supports'][arm][n] for m in options]
                v=var(prefix+f'-component{arm}-support{n}',min(vals),max(vals));supportvars+=1
                linear([(v,1)]+[(m['active'],-val) for m,val in zip(options,vals)],0,0);supports.append(v)
            components.append(supports)
        parts.append({'part':i,'item':item['index'],'family':item['family'],'x':x,'y':y,'sheet':sheet,'modes':options,'components':components})
''')
s=between(s,'    cache={(r[','    assert len(pairs)', '''    pairs=[]
    for i,j in combinations(range(9),2):
        a,b=parts[i],parts[j];prefix=f'pair{i}-{j}';different=var(prefix+'-different-sheet',0,1)
        boolean('bool_xor',[a['sheet'],b['sheet'],-different-1])
        for sa,sb in product([0,1],repeat=2):assert [d for d in [0,1] if (sa+sb+1-d)%2]==[int(sa!=sb)]
        ps=[]
        for ai,bi in product(range(len(a['components'])),range(len(b['components']))):
            dirs=[];componentpairs+=1
            for n,(nx,ny) in enumerate(atlas['normals']):
                d=var(prefix+f'-components{ai}-{bi}-normal{n}',0,1);dirs.append(d);opp=atlas['opposites'][n]
                norm=math.isqrt(nx*nx+ny*ny);norm+=norm*norm<nx*nx+ny*ny;gap=math.ceil(F(17,80)*1000*norm)
                assert gap==atlas['clearance_projection_units'][n]
                linear([(b['x'],nx),(a['x'],-nx),(b['y'],ny),(a['y'],-ny),(a['components'][ai][n],-1),(b['components'][bi][opp],-1)],gap,2**63-1,[d]);outside+=1
            boolean('bool_or',[different]+dirs);ps.append({'components':[ai,bi],'directions':dirs})
        pairs.append({'parts':[i,j],'different_sheet':different,'component_pairs':ps})
    assert atlas['copy_x_order_pairs']==[[0,1],[3,4],[4,5],[5,6],[6,7],[7,8]]
    for i,j in atlas['copy_x_order_pairs']:
        assert all(spec['parts'][i][k]==spec['parts'][j][k] for k in ['family','queries','profiles','allowed_modes'])
        linear([(parts[i]['x'],1),(parts[j]['x'],-1)],-2**63,0)
''')
s=replace(s,"'profile_flags':profiles,","'support_variables':supportvars,")
s=replace(s,"'ordered_profile_pair_uses':cases,'forbidden_piece_disjunctions':forbidden,","'cross_part_convex_component_pairs':componentpairs,")
s=replace(s,"'copy_order_constraints':0","'copy_order_constraints':6")
s=replace(s,"'all_forbidden_pieces_required_for_active_profile_pair':True","'all_component_pairs_have_sufficient_clearance':True,'copy_order_permutation_certificate_checked':True")
with (ROOT/'audit_h5_full_original_support_model.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Wrote two distinct projection-model helpers; no solver call.')
