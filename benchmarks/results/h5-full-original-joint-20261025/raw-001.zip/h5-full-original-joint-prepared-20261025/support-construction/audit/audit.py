"""Independent containment, rational projection and interchangeability audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time,traceback
from shapely.geometry import shape,Polygon
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-original-joint-prepared-20261025';SRC=BASE/'support-construction';OUT=SRC/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [SRC/'plan.json',SRC/'atlas.json',SRC/'result.json',BASE/'plan.json',BASE/'profiles.json']},
        'method':'Check actual component union equality for every non-cog original and exact rational convex-hull containment of every80 original cog vertex. Check every normal has its opposite, every rational component support ceiling, every upward Euclidean-normal bound and required0.2125mm gap. Verify identical query/profile/family inventories and original single-family quantity semantics for each exchangeable copy group; x ordering permits sorting any feasible assignment by swapping only copy labels, without changing occupied shapes, modes, sheet areas, fixed collisions or pair conditions.'})
    for n,h in load(SRC/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
    atlas=load(SRC/'atlas.json');profiles=load(BASE/'profiles.json');spec=load(BASE/'plan.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json')
    families={p['id']:p for p in job['parts']};containment=supports=0
    assert atlas['coordinate_units_per_mm']==1000 and len(atlas['profiles'])==10
    for p,g in zip(atlas['profiles'],profiles):
        assert p['profile']==g['index'] and p['family']==g['family'];pieces=[Polygon(v) for v in p['components']]
        assert all(x.is_valid and x.equals(x.convex_hull) and x.exterior.is_ccw for x in pieces)
        full=shape(g['geometry']);union=unary_union(pieces);assert union.covers(full)
        if g['family']!='cog':assert union.equals(full)
        else:
            assert len(pieces)==1 and len(g['vertices'])==80 and len(p['components'][0])==40 and union.equals(full.convex_hull)
            vertices=[list(map(F,v)) for v in p['components'][0]]
            for a,b in zip(vertices,vertices[1:]+vertices[:1]):
                nx,ny=b[1]-a[1],a[0]-b[0];c=nx*a[0]+ny*a[1]
                for x,y in g['vertices']:assert nx*F(x)+ny*F(y)<=c;containment+=1
        for i,vertices in enumerate(p['components']):
            for n,(nx,ny) in enumerate(atlas['normals']):
                val=1000*max(nx*F(x)+ny*F(y) for x,y in vertices);saved=p['supports'][i][n]
                assert saved==math.ceil(val) and F(saved)>=val and F(saved)-val<1;supports+=1
    for i,(nx,ny) in enumerate(atlas['normals']):
        assert (nx or ny) and atlas['normals'][atlas['opposites'][i]]==[-nx,-ny]
        norm=math.isqrt(nx*nx+ny*ny);norm+=norm*norm<nx*nx+ny*ny
        assert norm*norm>=nx*nx+ny*ny
        gap=atlas['clearance_projection_units'][i];assert gap==math.ceil(F(17,80)*1000*norm)
        assert F(gap,1000)**2>=F(17,80)**2*(nx*nx+ny*ny)
    assert atlas['interchangeable_part_groups']==[[0,1],[3,4,5,6,7,8]]
    expected=[]
    for group in atlas['interchangeable_part_groups']:
        first=spec['parts'][group[0]];family=families[first['family']]
        assert all(all(spec['parts'][i][k]==first[k] for k in ['family','queries','profiles','allowed_modes']) for i in group)
        assert len({spec['parts'][i]['copy'] for i in group})==len(group)
        assert all(0<=spec['parts'][i]['copy']<family['quantity'] for i in group)
        expected.extend([[a,b] for a,b in zip(group,group[1:])])
    assert atlas['copy_x_order_pairs']==expected
    result={'passed':True,'seconds':time.perf_counter()-start,'all10_original_profiles_covered':True,'non_cog_component_union_exact':True,
        'all80_cog_vertices_inside40_vertex_hull':True,'exact_cog_vertex_halfplane_checks':containment,'rational_support_ceilings':supports,
        'integer_normal_count':len(atlas['normals']),'opposite_normal_and_clearance_checks':len(atlas['normals']),
        'exchangeable_copy_groups':atlas['interchangeable_part_groups'],'permutation_safe_x_order_constraints':len(expected),
        'full_original_counts_shapes_and_area_charges_preserved':True,'constructive_cog_hull_restriction_explicit':True,'H5_complete':False}
    assert result['seconds']<60;write(OUT/'checks.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
