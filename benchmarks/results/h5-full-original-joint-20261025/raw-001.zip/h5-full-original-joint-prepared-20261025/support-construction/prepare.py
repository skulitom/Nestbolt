"""Conservative whole-cog projection construction and permutation certificate."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time,traceback
from shapely.geometry import shape,Polygon
from shapely.geometry.polygon import orient
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'support-construction'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[BASE/'plan.json',BASE/'profiles.json',BASE/'audit/checks.json',BASE/'solve/result.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_limit_seconds':60,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'coordinate_units_per_mm':1000,'clearance_mm_rational':[17,80],
        'method':'Retain all previously audited full-original fixed-obstacle free regions and all66 original identities. Replace only moving-to-moving cog collision geometry with its containing40-vertex convex hull. Every L bracket remains the exact union of two rectangles. Generate integer projection directions from component edges and their opposites. Exact rational support maxima round up, and the Euclidean norm rounds up before the required0.2125mm separation. This is a sufficient constructive subset, not a necessary condition or an impossibility proof. Certify that the two free brackets and six free cogs respectively have identical families, query lists, profile inventories and constraints; x-coordinate ordering only removes equivalent permutations within these groups. No source-index-specific location is retained for these mandatory moving copies. No solver call during preparation.'})
    start=time.perf_counter();profiles=load(BASE/'profiles.json');spec=load(BASE/'plan.json');components=[];normals=set()
    for p in profiles:
        g=shape(p['geometry'])
        if p['family']=='bracket':
            def transform(x,y):
                if p['mirrored']:x=-x
                for _ in range(p['quarter_turn']):x,y=-y,x
                return [x-p['rotated_original_min'][0],y-p['rotated_original_min'][1]]
            raw=[[(0,0),(300,0),(300,75),(0,75)],[(0,75),(100,75),(100,250),(0,250)]]
            ps=[orient(Polygon([transform(x,y) for x,y in r]),sign=1) for r in raw];assert unary_union(ps).equals(g)
        else:ps=[orient(g.convex_hull,sign=1)]
        assert unary_union(ps).covers(g)
        vs=[[list(pt) for pt in list(poly.exterior.coords)[:-1]] for poly in ps]
        for pts in vs:
            for a,b in zip(pts,pts[1:]+pts[:1]):
                nx,ny=F(b[1])-F(a[1]),F(a[0])-F(b[0]);unit=max(abs(nx),abs(ny));nx,ny=round(nx/unit*10**7),round(ny/unit*10**7)
                d=math.gcd(abs(nx),abs(ny));nx//=d;ny//=d;normals.add((nx,ny));normals.add((-nx,-ny))
        components.append({'profile':p['index'],'family':p['family'],'components':vs,'whole_original_covered':True,
                           'original_area_mm2':g.area,'containing_component_union_area_mm2':unary_union(ps).area})
    normals=sorted(normals);opposites=[normals.index((-x,-y)) for x,y in normals];gaps=[]
    for nx,ny in normals:
        n=math.isqrt(nx*nx+ny*ny)
        if n*n<nx*nx+ny*ny:n+=1
        gaps.append(math.ceil(F(17,80)*1000*n))
    for p in components:p['supports']=[[math.ceil(1000*max(nx*F(x)+ny*F(y) for x,y in vs)) for nx,ny in normals] for vs in p['components']]
    groups=[[0,1],[3,4,5,6,7,8]];orders=[]
    for group in groups:
        first=spec['parts'][group[0]]
        for i in group:
            r=spec['parts'][i];assert all(r[k]==first[k] for k in ['family','queries','profiles','allowed_modes'])
        orders.extend([[a,b] for a,b in zip(group,group[1:])])
    atlas={'coordinate_units_per_mm':1000,'normals':normals,'opposites':opposites,'clearance_projection_units':gaps,'profiles':components,
           'interchangeable_part_groups':groups,'copy_x_order_pairs':orders}
    write(OUT/'atlas.json',atlas);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'profiles':len(components),
        'convex_components':sum(len(p['components']) for p in components),'normal_count':len(normals),'safe_copy_order_constraints':len(orders),
        'full_original_fixed_regions_reused':20,'fixed_originals':57,'mandatory_moving_originals':9,'solver_calls':0,'independent_audit_pending':True,'H5_complete':False})
    assert time.perf_counter()-start<60;print(load(OUT/'result.json'),flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
