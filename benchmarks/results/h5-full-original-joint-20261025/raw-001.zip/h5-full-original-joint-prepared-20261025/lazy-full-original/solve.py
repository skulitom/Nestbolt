"""Bounded complete-original separation generation with preserved proposals."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time,traceback,sys
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
from build_h5_lazy_original_model import build
from audit_h5_lazy_original_model import verify

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'lazy-full-original'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'support-construction/audit/checks.json')['passed']
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    spec=load(BASE/'plan.json');aux=load(ROOT/'output/h5-source-orientation-construction-20261025/propagation.json')
    queries={q['index']:load(BASE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']}
    mutual={q['index']:load(BASE/'mutual'/f"{q['index']:03d}.json") for q in spec['mutual_cases']}
    atlas=load(BASE/'support-construction/atlas.json');orders=atlas['copy_x_order_pairs']
    cache={(r['profile_a'],r['profile_b']):r['index'] for r in spec['mutual_cases']}
    inputs=[BASE/n for n in ['plan.json','profiles.json','audit/checks.json','support-construction/audit/checks.json','support-construction/atlas.json','solve/result.json','support-construction/solve/result.json']]
    inputs += [ROOT/'output'/n for n in ['build_h5_lazy_original_model.py','audit_h5_lazy_original_model.py','h5-source-orientation-construction-20261025/propagation.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'query_hashes':{str(i):digest(BASE/'queries'/f'{i:03d}.json') for i in queries},'mutual_hashes':{str(i):digest(BASE/'mutual'/f'{i:03d}.json') for i in mutual},
        'combined_construction_audit_solve_candidate_check_limit_seconds':60,'maximum_iterations_and_solver_calls':12,'workers':8,'random_seed':0,
        'method':'New constraint-generation formulation, not a retry of either closed call. Begin with all9 mandatory originals, exact original fixed-obstacle inward domains, original area charges, all36 pair sheet flags and certified6 copy orders. Do not restrict moving cogs to convex hulls. After each feasible relaxed proposal, independently evaluate EVERY original mutual forbidden face for each same-sheet pair at its selected profiles using exact integers. Add every violated face as its complete sufficient outside disjunction, gated by both profiles and shared sheet, then rebuild and independently audit the entire next protobuf. Preserve all relaxed proposals, failures, added cuts, model bytes and parameters. No hints/objective/optional copies. Stop at first full model candidate, INFEASIBLE, UNKNOWN, twelve calls or the shared60-second wall budget, including construction/audits and all calls. No budget extension. A candidate still needs independent actual66-original geometry and native validation; negatives remain finite source-angle/inward-grid/fixed-source conditional.'})
    start=time.perf_counter();cuts=[];rounds=[];status='BUDGET_EXHAUSTED';full=None;pending=[]
    for iteration in range(12):
        if time.perf_counter()-start>=60:break
        dest=OUT/f'round-{iteration:02d}';dest.mkdir();write(dest/'active-cuts.json',cuts)
        bstart=time.perf_counter();model,vs,mapping=build(spec,queries,mutual,aux,cuts,orders)
        assert model.validate()=='' and model.export_to_file(str(dest/'model.pb'))
        actual=cp_model_pb2.CpModelProto();actual.ParseFromString((dest/'model.pb').read_bytes());expected,stats=verify(actual,spec,queries,mutual,aux,cuts,orders);assert expected==mapping
        elapsed=time.perf_counter()-start;remaining=60-elapsed-.01
        if remaining<=0:
            write(dest/'not-opened.json',{'reason':'shared construction/audit/solve budget consumed','elapsed_seconds':elapsed});status='BUDGET_EXHAUSTED';break
        params={'max_time_in_seconds':remaining,'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
        solver=cp_model.CpSolver()
        for k,v in params.items():setattr(solver.parameters,k,v)
        assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
        (dest/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
        write(dest/'model-audit.json',{'passed':True,**stats,'construction_and_audit_seconds':time.perf_counter()-bstart,'model_sha256':digest(dest/'model.pb'),
            'parameters_sha256':digest(dest/'parameters.pbtxt'),'parameters':params,'python':sys.version,'ortools':ortools.__version__})
        write(dest/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'elapsed_shared_budget_seconds':time.perf_counter()-start,'solver_limit_seconds':remaining})
        with (dest/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
            solver.log_callback=lambda msg:(log.write(msg+'\n'),log.flush())
            t=time.perf_counter();code=solver.solve(model);seconds=time.perf_counter()-t
        result={'iteration':iteration,'status':solver.status_name(code),'seconds':seconds,'active_cuts':len(cuts),'response_stats':solver.response_stats()}
        write(dest/'solver-result.json',result);rounds.append(result)
        if code not in [cp_model.OPTIMAL,cp_model.FEASIBLE]:status=solver.status_name(code);break
        proposals=[]
        for p in mapping['parts']:
            selected=[m for m in p['modes'] if solver.value(vs[m['active']])];assert len(selected)==1;m=selected[0]
            selected_ds=[j for j,v in enumerate(m['domains']) if solver.value(vs[v])];assert len(selected_ds)==1
            face=queries[m['query']]['domains'][selected_ds[0]];x=solver.value(vs[p['x']]);y=solver.value(vs[p['y']]);q=spec['queries'][m['query']]
            for bounds in [face['coordinate_bounds'],q['anchor_bounds_units1000']]:assert bounds[0]<=x<=bounds[2] and bounds[1]<=y<=bounds[3]
            assert all(h['a']*x+h['b']*y<=h['bound'] for h in face['halfplanes'])
            proposals.append({'part':p['part'],'item':p['item'],'family':p['family'],'query':m['query'],'profile':m['profile'],'sheet':solver.value(vs[p['sheet']]),
                'domain_index':face['index'],'x_units':x,'y_units':y})
        for i,j in orders:assert proposals[i]['x_units']<=proposals[j]['x_units']
        area=[spec['fixed_original_area_units_per_sheet'][s]+sum(aux['part_areas'][p['family']]['lower_units'] for p in proposals if p['sheet']==s) for s in [0,1]]
        assert all(area[s]<=aux['sheet_capacities'][s]['upper_area_units'] for s in [0,1])
        positions={'fixed_items':spec['fixed_items'],'coordinate_units_per_mm':1000,'movable_parts':proposals,'required_originals':66}
        write(dest/'proposal.json',positions);violations=[];pairchecks=[];faceschecked=0
        for a,b in combinations(proposals,2):
            if a['sheet']!=b['sheet']:continue
            case=cache[(a['profile'],b['profile'])];dx=b['x_units']-a['x_units'];dy=b['y_units']-a['y_units'];failed=[]
            for face in mutual[case]['faces']:
                faceschecked+=1
                if not any(h['a']*dx+h['b']*dy>=h['bound'] for h in face['outside_halfplanes']):
                    key=[a['part'],b['part'],case,face['index']];assert key not in cuts;violations.append(key);failed.append(face['index'])
            pairchecks.append({'parts':[a['part'],b['part']],'case':case,'all_faces_checked':len(mutual[case]['faces']),'violated_faces':failed})
        write(dest/'complete-candidate-check.json',{'passed_all_active_constraints':True,'selected_original_domains_checked':9,'area_units_per_sheet':area,
            'same_sheet_pairs_checked':len(pairchecks),'whole_forbidden_faces_checked':faceschecked,'pair_checks':pairchecks,'new_violations':violations,
            'full_original_model_candidate':not violations})
        print({'iteration':iteration,'status':result['status'],'new_forbidden_faces':len(violations),'elapsed_seconds':time.perf_counter()-start},flush=True)
        if not violations:full=positions;status='FULL_ORIGINAL_MODEL_CANDIDATE';break
        pending=violations
        if iteration==11:status='ITERATION_CAP';break
        if time.perf_counter()-start>=60:status='BUDGET_EXHAUSTED';break
        cuts.extend(violations);pending=[]
    if full:write(OUT/'positions.json',full)
    write(OUT/'pending-cuts.json',pending);write(OUT/'final-active-cuts.json',cuts)
    result={'status':status,'seconds':time.perf_counter()-start,'maximum_shared_budget_seconds':60,'solver_calls':len(rounds),'maximum_solver_calls':12,
        'active_cuts':len(cuts),'pending_cuts':len(pending),'rounds':rounds,'has_full_original_model_candidate':full is not None,
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print({k:v for k,v in result.items() if k!='rounds'},flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
