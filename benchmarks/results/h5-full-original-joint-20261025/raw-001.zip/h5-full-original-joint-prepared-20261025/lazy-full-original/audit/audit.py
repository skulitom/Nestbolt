"""Replay every lazy proposal and constraint addition independently of the search."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,shutil,time,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from audit_h5_lazy_original_model import verify

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-original-joint-prepared-20261025';RUN=BASE/'lazy-full-original';OUT=RUN/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();spec=load(BASE/'plan.json');plan=load(RUN/'plan.json');result=load(RUN/'result.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(RUN.rglob('*')) if p.is_file() and OUT not in p.parents},
        'method':'Independently replay every retained model protobuf, parameter limit, complete original mode/domain proposal and all same-sheet full-original forbidden faces. Reconstruct the exact sequence of violated-face constraints from previous proposals and verify no repeated cut or retry. Count every call, pending face and budget overrun. A relaxed proposal is never a full target. Full model candidates still need original geometry and native validation.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    queries={q['index']:load(BASE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']};mutual={q['index']:load(BASE/'mutual'/f"{q['index']:03d}.json") for q in spec['mutual_cases']}
    for i in queries:assert digest(BASE/'queries'/f'{i:03d}.json')==plan['query_hashes'][str(i)]
    for i in mutual:assert digest(BASE/'mutual'/f'{i:03d}.json')==plan['mutual_hashes'][str(i)]
    aux=load(ROOT/'output/h5-source-orientation-construction-20261025/propagation.json');orders=load(BASE/'support-construction/atlas.json')['copy_x_order_pairs']
    cases={(r['profile_a'],r['profile_b']):r['index'] for r in spec['mutual_cases']};expectedcuts=[];checks=[];totalfaces=proposals=0;lastviolations=[]
    dirs=sorted(RUN.glob('round-*'));calls=0
    for rd in dirs:
        assert time.perf_counter()-start<120
        cuts=load(rd/'active-cuts.json');assert cuts==expectedcuts
        actual=cp_model_pb2.CpModelProto();actual.ParseFromString((rd/'model.pb').read_bytes());mapping,stats=verify(actual,spec,queries,mutual,aux,cuts,orders)
        if (rd/'not-opened.json').exists():assert rd==dirs[-1];break
        audit=load(rd/'model-audit.json');assert audit['passed'] and all(audit[k]==v for k,v in stats.items())
        assert digest(rd/'model.pb')==audit['model_sha256'] and digest(rd/'parameters.pbtxt')==audit['parameters_sha256']
        params=text_format.Parse((rd/'parameters.pbtxt').read_text(encoding='utf-8'),sat_parameters_pb2.SatParameters())
        assert params==sat_parameters_pb2.SatParameters(**audit['parameters'])
        assert params.num_search_workers==8 and params.random_seed==0 and params.max_time_in_seconds<=60
        opened=load(rd/'opened.json');assert params.max_time_in_seconds==opened['solver_limit_seconds']
        assert opened['elapsed_shared_budget_seconds']+params.max_time_in_seconds<60.02
        solved=load(rd/'solver-result.json');assert solved==result['rounds'][calls];calls+=1
        row={'iteration':solved['iteration'],'status':solved['status'],'variables':stats['variables'],'constraints':stats['constraints'],'active_cuts':len(cuts),'seconds':solved['seconds']}
        if solved['status'] not in ['OPTIMAL','FEASIBLE']:
            assert rd==dirs[-1] and not (rd/'proposal.json').exists();checks.append(row);break
        positions=load(rd/'proposal.json');ps=positions['movable_parts'];assert len(ps)==9 and positions['fixed_items']==spec['fixed_items'] and positions['required_originals']==66
        for i,p in enumerate(ps):
            item=spec['parts'][i];assert p['part']==i and p['item']==item['index'] and p['family']==item['family'] and p['query'] in item['queries']
            q=spec['queries'][p['query']];assert q['profile']==p['profile'] and q['sheet']==p['sheet']
            face=next(d for d in queries[q['index']]['domains'] if d['index']==p['domain_index']);x,y=p['x_units'],p['y_units']
            assert type(x)==type(y)==int
            for b in [face['coordinate_bounds'],q['anchor_bounds_units1000']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
            assert all(h['a']*x+h['b']*y<=h['bound'] for h in face['halfplanes'])
        for i,j in orders:assert ps[i]['x_units']<=ps[j]['x_units']
        areas=[spec['fixed_original_area_units_per_sheet'][s]+sum(aux['part_areas'][p['family']]['lower_units'] for p in ps if p['sheet']==s) for s in [0,1]]
        assert all(areas[s]<=aux['sheet_capacities'][s]['upper_area_units'] for s in [0,1])
        violated=[];pairchecks=[];faces=0
        for a,b in combinations(ps,2):
            if a['sheet']!=b['sheet']:continue
            case=cases[(a['profile'],b['profile'])];dx=b['x_units']-a['x_units'];dy=b['y_units']-a['y_units'];fail=[]
            for f in mutual[case]['faces']:
                faces+=1
                if all(h['a']*dx+h['b']*dy<h['bound'] for h in f['outside_halfplanes']):
                    key=[a['part'],b['part'],case,f['index']];assert key not in cuts;fail.append(f['index']);violated.append(key)
            pairchecks.append({'parts':[a['part'],b['part']],'case':case,'all_faces_checked':len(mutual[case]['faces']),'violated_faces':fail})
        recorded=load(rd/'complete-candidate-check.json')
        assert recorded=={'passed_all_active_constraints':True,'selected_original_domains_checked':9,'area_units_per_sheet':areas,'same_sheet_pairs_checked':len(pairchecks),
            'whole_forbidden_faces_checked':faces,'pair_checks':pairchecks,'new_violations':violated,'full_original_model_candidate':not violated}
        if not violated:assert rd==dirs[-1] and load(RUN/'positions.json')==positions and result['has_full_original_model_candidate']
        proposals+=1;totalfaces+=faces;row.update({'all_forbidden_faces_checked':faces,'new_violated_faces':len(violated)});checks.append(row)
        lastviolations=violated
        if rd!=dirs[-1]:expectedcuts.extend(violated)
    assert calls==result['solver_calls']<=12 and len(result['rounds'])==calls
    assert result['has_full_original_model_candidate']==(RUN/'positions.json').exists()
    finalcuts=load(RUN/'final-active-cuts.json');pending=load(RUN/'pending-cuts.json')
    assert (finalcuts==expectedcuts and pending in [[],lastviolations]) or (finalcuts==expectedcuts+lastviolations and not pending)
    assert len(finalcuts)==result['active_cuts'] and len(pending)==result['pending_cuts']
    summary={'passed':True,'seconds':time.perf_counter()-start,'solver_calls_replayed':calls,'complete_original_proposals_replayed':proposals,
        'full_original_forbidden_faces_checked':totalfaces,'new_active_face_cuts':len(finalcuts),'pending_face_cuts':len(pending),
        'every_model_variable_and_constraint_rechecked':True,'all_shared_budget_limits_verified':True,'soft_wall_budget_overrun_seconds':max(0,result['seconds']-60),
        'no_completed_search_retried':True,'terminal_status':result['status'],'has_full_original_model_candidate':result['has_full_original_model_candidate'],
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'round-checks.json',checks);write(OUT/'checks.json',summary);print(summary,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
