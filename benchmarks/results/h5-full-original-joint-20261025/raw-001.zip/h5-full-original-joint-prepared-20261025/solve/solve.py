"""One declared full-original joint construction on adjusted source poses."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations,product
import json,shutil,sys,time,traceback
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
from audit_h5_full_original_joint_model import verify

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'solve'
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    spec=load(BASE/'plan.json');aux=load(SRC/'propagation.json')
    queries={q['index']:load(BASE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']}
    mutual={q['index']:load(BASE/'mutual'/f"{q['index']:03d}.json") for q in spec['mutual_cases']}
    params={'max_time_in_seconds':60,'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,
            'log_search_progress':True,'log_to_stdout':False}
    inputs=[BASE/n for n in ['plan.json','result.json','audit/checks.json','profiles.json']]+[SRC/'propagation.json',ROOT/'output/audit_h5_full_original_joint_model.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'query_hashes':{str(i):digest(BASE/'queries'/f'{i:03d}.json') for i in queries},'mutual_hashes':{str(i):digest(BASE/'mutual'/f'{i:03d}.json') for i in mutual},
        'parameters':params,'maximum_solver_calls':1,'construction_limit_seconds':120,'independent_model_audit_limit_seconds':120,
        'fixed_originals':57,'mandatory_moving_originals':9,'required_originals':66,'objective':None,'hints':None,
        'method':'All9 mandatory full original shapes select one complete conservative inward allowed domain on the1-micrometre anchor grid, with all recorded modes/sheets retained. Both original sheet area charges remain required. Every one of36 physical moving-part pairs chooses different sheets or avoids every expanded convex piece of its selected full-original mutual collision region, using sufficient outward-rounded integer halfplanes for anchorB-anchorA. All80 cog vertices are retained at the source angle. No convex disk proxy, optional part, sampled pose list, copy ordering, objective or hint. Every protobuf variable and constraint is independently reconstructed before one60-second/eight-worker/seed-zero call. A candidate needs full66-original geometry and native validation; a negative is conditional on this finite source-angle/grid/fixed-source construction and does not prove unrestricted impossibility.'})
    start=time.perf_counter();model=cp_model.CpModel();vs=[]
    def var(name,lo,hi):
        v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi,en=()):
        c=model.add_linear_constraint(sum(vs[i]*coef for i,coef in terms),lo,hi)
        if en:c.only_enforce_if([vs[i] for i in en])
    parts=[]
    for pi,item in enumerate(spec['parts']):
        prefix=f'part{pi}';x=var(prefix+'-x',0,1500000);y=var(prefix+'-y',0,3000000);sheet=var(prefix+'-sheet',0,1);modes=[]
        for qi in item['queries']:
            q=spec['queries'][qi];tag=prefix+f'-query{qi}';active=var(tag+'-active',0,1);ds=[];bounds=q['anchor_bounds_units1000']
            linear([(x,1)],bounds[0],bounds[2],[active]);linear([(y,1)],bounds[1],bounds[3],[active])
            for face in queries[qi]['domains']:
                d=var(tag+f"-face{face['index']}",0,1);ds.append(d);b=face['coordinate_bounds']
                linear([(x,1)],b[0],b[2],[d]);linear([(y,1)],b[1],b[3],[d])
                for h in face['halfplanes']:linear([(x,h['a']),(y,h['b'])],cp_model.INT_MIN,h['bound'],[d])
            linear([(d,1) for d in ds]+[(active,-1)],0,0)
            modes.append({'query':qi,'profile':q['profile'],'sheet':q['sheet'],'active':active,'domains':ds})
        model.add_exactly_one([vs[m['active']] for m in modes]);linear([(sheet,1)]+[(m['active'],-m['sheet']) for m in modes],0,0)
        flags=[]
        for profile in item['profiles']:
            v=var(prefix+f'-profile{profile}',0,1);linear([(v,1)]+[(m['active'],-1) for m in modes if m['profile']==profile],0,0)
            flags.append({'profile':profile,'active':v})
        parts.append({'part':pi,'item':item['index'],'family':item['family'],'x':x,'y':y,'sheet':sheet,'modes':modes,'profiles':flags})
    charges=[aux['part_areas'][p['family']]['lower_units'] for p in parts]
    linear([(p['sheet'],-charge) for p,charge in zip(parts,charges)],cp_model.INT_MIN,aux['sheet_capacities'][0]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][0]-sum(charges))
    linear([(p['sheet'],charge) for p,charge in zip(parts,charges)],cp_model.INT_MIN,aux['sheet_capacities'][1]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][1])
    cache={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']};pairs=[]
    for a,b in combinations(parts,2):
        prefix=f"pair{a['part']}-{b['part']}";different=var(prefix+'-different-sheet',0,1)
        model.add_bool_xor([vs[a['sheet']],vs[b['sheet']],vs[different].Not()]);cases=[]
        for pa,pb in product(a['profiles'],b['profiles']):
            case=cache[(pa['profile'],pb['profile'])];faces=[]
            for face in mutual[case]['faces']:
                ds=[]
                for hi,h in enumerate(face['outside_halfplanes']):
                    d=var(prefix+f"-case{case}-face{face['index']}-edge{hi}",0,1);ds.append(d)
                    linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],cp_model.INT_MAX,[d])
                model.add_bool_or([vs[different],vs[pa['active']].Not(),vs[pb['active']].Not()]+[vs[d] for d in ds])
                faces.append({'face':face['index'],'directions':ds})
            cases.append({'case':case,'profile_a':pa['profile'],'profile_b':pb['profile'],'faces':faces})
        pairs.append({'parts':[a['part'],b['part']],'different_sheet':different,'cases':cases})
    mapping={'parts':parts,'pairs':pairs};write(OUT/'mapping.json',mapping)
    assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));buildtime=time.perf_counter()-start;assert buildtime<120
    start=time.perf_counter();actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes())
    expected,stats=verify(actual,spec,queries,mutual,aux);assert expected==mapping
    solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');audittime=time.perf_counter()-start;assert audittime<120
    write(OUT/'model-audit.json',{'passed':True,'construction_seconds':buildtime,'audit_seconds':audittime,**stats,
        'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'python':sys.version,'ortools':ortools.__version__})
    print(load(OUT/'model-audit.json'),flush=True)
    def positions(value):
        rows=[]
        for p in parts:
            chosen=[m for m in p['modes'] if value(vs[m['active']])];assert len(chosen)==1;m=chosen[0]
            ds=[i for i,v in enumerate(m['domains']) if value(vs[v])];assert len(ds)==1
            rows.append({'part':p['part'],'item':p['item'],'family':p['family'],'query':m['query'],'profile':m['profile'],
                'domain_index':queries[m['query']]['domains'][ds[0]]['index'],'x_units':value(vs[p['x']]),'y_units':value(vs[p['y']]),'sheet':value(vs[p['sheet']])})
        return {'fixed_items':spec['fixed_items'],'coordinate_units_per_mm':1000,'movable_parts':rows,'required_originals':66}
    records=[]
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            write(OUT/f'incumbent-{len(records)}.json',positions(self.value));records.append({'index':len(records),'seconds':self.wall_time});print(records[-1],flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':60,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda msg:(log.write(msg+'\n'),log.flush())
        start=time.perf_counter();status=solver.solve(model,Capture());elapsed=time.perf_counter()-start
    feasible=status in [cp_model.FEASIBLE,cp_model.OPTIMAL]
    if feasible:write(OUT/'positions.json',positions(solver.value))
    result={'status':solver.status_name(status),'seconds':elapsed,'solver_calls':1,'incumbents':records,'has_full_original_model_candidate':feasible,
        'response_stats':solver.response_stats(),'scope':'Adjusted57-fixed/9-mandatory-original source-angle/inward-grid constructive neighborhood. Conditional negatives; UNKNOWN unresolved. A positive requires independent66-original geometry and native validation, then production-budget integration and all13 jobs at both kerfs.',
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
