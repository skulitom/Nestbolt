"""Preserve the closed hard-cell construction and all consumed source evidence."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8')
prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-hard-cell-continuous-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-hard-cell-direct-model-20261107';F=BASE/'response-audit';D=ROOT/'output/h5-three-column-hard-cells-v2-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-six-bracket-continuous-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==30 and not front['source_valid66']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D]+[ROOT/'output'/n for n in ['h5-three-column-hard-cells-20261107','h5-three-column-hard-cells-preparation-process-20261107','h5-three-column-hard-cells-preparation-v2-process-20261107','h5-three-column-hard-cells-audit-process-20261107','h5-hard-cell-initializer-process-20261107','h5-hard-cell-model-audit-process-20261107','h5-hard-cell-response-audit-process-20261107','h5-six-bracket-cog-main-sync-20261107']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*hard*cell*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_hard_cell_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"
}
for old,new in changes.items():
    assert old in prefix,old
    prefix=prefix.replace(old,new)
exec(prefix)
copies=[(D/'audit/checks.json','source-audit.json'),(D/'audit/unit-label-correction.json','unit-label-correction.json'),(BASE/'audit/checks.json','model-audit.json'),(F/'checks.json','response-audit.json'),(F/'mode-selection-controls.json','mode-selection-controls.json'),(F/'round-reconciliation.json','round-reconciliation.json'),(F/'round-02-collision-details.json','source-failures.json'),(BASE/'search/process.json','closed-search-process.json'),(ROOT/'output/h5-six-bracket-cog-main-sync-20261107/receipt.json','prior-main-push-receipt.json'),(ROOT/'output/h5-hard-cell-main-ci-at-review-20261107.json','main-ci-at-review.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'investigate_before_new_model','proposal':'Measure a vectorized exact boundary integral and assess joint bracket/insert compound-cell transitions.','reason':'Single-owner choices still leave 30 source pair failures; a new seed alone does not justify repeating a closed call.','required':['Compare all boundary-integral fields against the current scalar reference, including shared boundaries, disconnected clips and finite differences.','Measure fixed validation cases before claiming faster evaluation.','If joint changes are pursued, derive and independently verify exact pair-additive scoring and freeze complete preparation and call limits before any optimization.'],'optimizer_calls':0,'successor_model_prepared':False,'closed_calls_remain_closed':True,'optimized_candidate_may_be_reused_with_reset_clock':False})
report=f'''# Hard-cell continuous construction — 2026-11-07

The construction closes at its three-call limit with **30 failing source pairs**:
28 positive overlaps and two clearance-only failures. Total original overlap is
**18,638.988042 mm²**. All fixed-part clearances and stock checks pass. Reduced
objective is not a valid layout. H2/H5 remain open at **60% completed milestone
weight**; four fixed arrangements and 440 whole allocations remain unresolved.
No native validation or allocation exclusion follows.

## Source-certified domains

The new model frees eleven side-strip inserts, retaining 33 movers: six brackets,
twelve inserts and fifteen cogs with continuous angles. Eighteen three-column
frames and fifteen short-sheet originals stay fixed. There are 81 continuous
parameters and 528 moving pairs; the historical short allocation is six brackets,
nine inserts and no cogs.

[Independent source readback]({NAME}/source-audit.json) checks 13 base orientation
arrangements, 45 atomic cells, 17 compound orientation/cell options, 147 owner
bindings and 708 original-source corner controls. Exact whole-cell support
proofs protect fixed frames with a minimum certified axis gap of 0.230001 mm.
These conservative rectangular cells do not claim complete free-space coverage.
The 59-part source control remains valid, with 1,051 pair checks, 236 stock edges,
71 holes and 7,708 hole vertices. It does not provide a full66 placement.

The first source preparation fails because inward-rounded cells exclude seed
centers by a few nanometres. A versioned correction projects 26 source-derived
centers to their nearest legal cells, by at most **4.242641 nanometres**; all
partial source geometry is then rechecked. Both preparations remain charged.
[A separate unit-label correction]({NAME}/unit-label-correction.json) preserves
the producer's mistaken micrometre wording; geometry and numerical bytes are
unchanged. Complete consumed source preparation is **4.512212 s**.

## Compound modes and deterministic initialization

Physical equivalence requires the same exact nominal filled outline and the
same effective cell rectangle. Orientation aliases use the explicit intersection
of their nearly equal source bounds. Different corner, side and top cells remain
distinct. This conservatively yields 111 physical owner options from 147 source
bindings, with 78 distinct single-owner neighbors; it does not broaden domains.

One deterministic initializer retains source-derived cog positions and angles,
then places brackets and inserts using 9×9 cell grids and legal source seed
centers. All cogs and side inserts remain movable. [The model audit]({NAME}/model-audit.json)
replays **10,932 trials**, 147 full scores, 115 dynamic vectors, 56 scalar/batched
gradient controls, 162 central derivatives, three descent controls, 137 compound
equivalence controls and eleven corruptions. All pass. The initial candidate
has 14 failing source pairs and 39,222.720379 mm² overlap; it is not source-valid.
Complete preparation, including the failed source stage, is **9.121196 s**.

## Closed search and independent replay

The frozen pipeline permits three distinct compound vectors with optimizer
slices of 16, 12 and 12 seconds. Later calls choose the lowest-scoring unvisited
single-owner neighbor of the best retained candidate; proposals may initially
increase the objective. All calls stop on time without a numerical return.
The pipeline stops at its declared call limit and cannot be extended.

| Call | Failed source pairs | Original overlap (mm²) | Objective (mm²) |
|---|---:|---:|---:|
| 0 | 30 | 20,635.026684 | 42,089.950117 |
| 1 | 29 | 18,773.127855 | 38,316.302155 |
| 2 | 30 | 18,638.988042 | 38,064.063464 |

[Response replay]({NAME}/response-audit.json) verifies **155 mode trials, 256
retained points and 289 evaluation counters**. Each call reconstructs all 66
original parts and checks 1,380 same-sheet pairs, 264 stock edges, 90 holes and
10,026 hole vertices. [The pair-by-pair failures]({NAME}/source-failures.json)
are retained. Every fixed–fixed and fixed–moving check passes in all three calls.

Preparation-inclusive algorithm/shared totals are **52.616504/52.686635 s**.
Slice overruns of 0.005838, 0.140486 and 0.092327 s are recorded; the overall
60/90-second limits pass. Peak aggregate committed memory is 94,507,008 bytes,
and [all five search processes close]({NAME}/closed-search-process.json).
The separate complete response audit takes 39.551456 s. All prior calls remain
closed; neither local failure nor bounded search excludes an allocation.

## Next investigation and repository state

[The next investigation]({NAME}/next-step.json) measures vectorized exact
boundary integration and assesses joint bracket/insert compound-cell choices.
It requires independent numerical controls and a frozen new scope before any
new optimization. No successor model or optimizer call is prepared. Consumed
preparation must be charged; optimized candidates cannot restart their clocks.

[The previous two checkpoints reached main c3af6112]({NAME}/prior-main-push-receipt.json)
after all six prior CI jobs and the aggregate run passed, preserving 52 remote
files. [Fresh main CI is still running at review]({NAME}/main-ci-at-review.json).
Production, README, releases and H2 reserved vectors are unchanged. Full66
source/native/material checks, production parity and the unchanged full H5
matrix remain necessary; no release qualifies.

[Raw manifest]({NAME}/raw-manifest.json) and [source bindings]({NAME}/source-bindings.json)
preserve new bytes and exact references to the previously verified archive graph.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 hard-cell continuous construction:** [independent source/model/response audits]({link}) verify 17 compound domains, 27 exact whole-cell support proofs, 147 owner bindings and 708 original-source corner controls. A preserved source preparation failure is corrected by projections of at most 4.242641 nanometres; the mistaken micrometre label is separately corrected without changing numerical bytes. The 33-mover/81-parameter model frees eleven side inserts and protects all fixed parts with hard bounds. One initializer replays 10,932 trials; compound equivalence preserves different cells. Three distinct calls and 155 mode trials close at the declared limit; 256 retained points and 289 evaluation counters replay. The final candidate still fails 30 source pairs, with 18,638.988042 mm² overlap; every fixed-part and stock check passes. Complete preparation is 9.121196 s and algorithm/shared totals are 52.616504/52.686635 s. All slice overruns are preserved and all processes close. No native call or exclusion follows. Next measure exact boundary-integration speed and assess joint bracket/insert cell changes; no successor model or call is prepared. Four fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%. Both previous checkpoints reached main c3af6112 after all six prior checks passed; fresh CI is live. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md'
    append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [hard-cell continuous construction](../benchmarks/results/{NAME}.md).
All fixed-part clearances and stock checks pass, but the final candidate still
fails 30 source pairs with 18,638.988042 mm² overlap. The source-certified cells
free eleven side inserts, leaving 33 movers and fifteen continuous cog angles.
Independent audits replay the complete initializer, compound-domain equivalence,
three bounded calls, 155 mode trials and 256 retained points. Preparation-inclusive
algorithm/shared totals are 52.616504/52.686635 s. Every process is closed.
The next investigation measures exact boundary-integration speed and assesses
joint bracket/insert cell choices; no successor model or call is prepared.
Four fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%
completed milestone weight. Main c3af6112 includes the previous two checkpoints;
its CI is still running at review. Full66 source/native/material checks,
production parity and the unchanged H5 matrix remain required. No release qualifies.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n')
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
