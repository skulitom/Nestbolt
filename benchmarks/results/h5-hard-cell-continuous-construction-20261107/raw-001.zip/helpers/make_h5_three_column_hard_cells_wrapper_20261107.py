from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_direct_pose_audit_20261107.py').read_text(encoding='utf-8').replace('h5-direct-pose-audit-process-20261107','h5-three-column-hard-cells-preparation-process-20261107').replace("stages=[('audit','audit_h5_direct_pose_model_20261107.py',90)]","stages=[('prepare','prepare_h5_three_column_hard_cells_20261107.py',15)]")
with (ROOT/'output/run_h5_three_column_hard_cells_preparation_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
