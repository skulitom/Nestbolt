from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/h5_six_bracket_cog_direct_model_20261107.py').read_text(encoding='utf-8')
changes={'len(modes)==22 and len(values)==59':'len(modes)==33 and len(values)==81','44+i-7':'66+i-18',"'parameters':59":"'parameters':81",'np.zeros(59)':'np.zeros(81)',"'mode':mi,'rotation_radians'":"'mode':mi,'source_mode':mode['source_mode'],'cell_index':mode['cell_index'],'rotation_radians'"}
for before,after in changes.items():assert before in s,before;s=s.replace(before,after)
with (ROOT/'output/h5_hard_cell_direct_model_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
