"""Safe rectangular source-center cells with all side-strip inserts movable."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product,combinations
import json,math,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];PREVIOUS=ROOT/'output/h5-six-bracket-cog-source-20261107';Q=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=ROOT/'output/h5-three-column-hard-cells-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();UNIT=10**6
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def lower(v):return F(math.floor(F(v)*UNIT),UNIT)
def upper(v):return F(math.ceil(F(v)*UNIT),UNIT)
def serial(rect):return [str(v) for v in rect]
def merged_free_cells(root,forbidden):
    xs=sorted({root[0],root[2]}|{v for r in forbidden for v in [r[0],r[2]] if root[0]<v<root[2]});ys=sorted({root[1],root[3]}|{v for r in forbidden for v in [r[1],r[3]] if root[1]<v<root[3]});runs=[];atomic=[]
    for y0,y1 in zip(ys,ys[1:]):
        opened=None
        for x0,x1 in zip(xs,xs[1:]):
            x,y=(x0+x1)/2,(y0+y1)/2;free=not any(a<x<c and b<y<d for a,b,c,d in forbidden);atomic.append({'bounds':serial([x0,y0,x1,y1]),'retained':free})
            if free and opened is None:opened=x0
            if opened is not None and (not free or x1==root[2]):
                runs.append([opened,y0,x0 if not free else x1,y1]);opened=None
    merged=[]
    for r in runs:
        old=next((a for a in merged if a[0]==r[0] and a[2]==r[2] and a[3]==r[1]),None)
        if old is not None:old[3]=r[3]
        else:merged.append(r.copy())
    return sorted(merged,key=lambda r:(r[1],r[0],r[3],r[2])),atomic
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');priorcheck=load(PREVIOUS/'audit/checks.json');old=load(PREVIOUS/'library.json');assert priorcheck['passed'] and priorcheck['library_sha256']==digest(PREVIOUS/'library.json');charge=priorcheck['complete_preparation_seconds'];job=load(JOB);parts={p['id']:p for p in job['parts']};partitions=load(Q/'partitions.json');inputs=[Path(__file__),JOB,ROOT/'output/h5_legacy64_source_readback.py',Q/'partitions.json']+[PREVIOUS/n for n in ['plan.json','library.json','audit/checks.json','seed59-source.json','seed59-checks.json','source-contact-pitches.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New hard-domain source scope frees all11side-strip inserts. Retain18three-column sourceframes and15shortsheet originals asfixed33;move6brackets,12inserts,15continuouscogs jointly. Historical broader/soft-domain calls remainclosed. From actualframevertices construct a rational outwardmicrometre boundingrectangle. For eachsource legal mode bound eachoriginalconvexpiece outward to micrometres;forcogs use the checked all-angle circumscribing square. Derive forbidden center rectangles expandedby.23square clearance and exact sourceboundingstockroot. Exactaxis grid decomposition and deterministic horizontal/vertical merging produce safe rectanglecells; inset eachcell one micrometre before binaryfloatserialization. Everywholecell/sourcepiece must have an exact at-least.22mm axis support gap from the containingframe rectangle and lieinside stock. Conservatively restricted domains only,no completenessclaim. Each orientation/cell becomes a distinct compound option; identical local orientation doesnotmake domains interchangeable. Retain source-derived59part control with26movable initial poses,sevencompanionsstillunplaced. No completeinitializer/model/optimizer/nativecall.','complete_reused_source_preparation_seconds':charge,'previous_optimizer_candidate_consumed':False,'preparation_internal_target_seconds':12,'preparation_process_cap_seconds':15,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
fixed=[r for r in old['fixed_source_rows'] if r['part_id']=='frame' or r['sheet_id']=='sheet-1'];assert len(fixed)==33;stocks=old['source_stocks'];required=old['required_pair_gap_mm'];guard=old['stock_guard_mm'];fixedcheck=audit(job,fixed,stocks,required,guard);assert fixedcheck['valid'];write(OUT/'fixed33-source.json',fixed);write(OUT/'fixed33-checks.json',fixedcheck);vertices=[]
for row in fixed:
    if row['part_id']!='frame':continue
    t=row['transform'];assert t['rotation_radians']==0 and not t['mirrored'];vertices.extend([(F(x)+F(t['translation'][0]),F(y)+F(t['translation'][1])) for x,y in parts['frame']['geometry'][0]['outer']])
core=[lower(min(p[0] for p in vertices)),lower(min(p[1] for p in vertices)),upper(max(p[0] for p in vertices)),upper(max(p[1] for p in vertices))];safe=[F(str(stocks['sheet-0'][0]))+F('.025'),F(str(stocks['sheet-0'][1]))+F('.025'),F(str(stocks['sheet-0'][2]))-F('.025'),F(str(stocks['sheet-0'][3]))-F('.025')];gap=F('.23');epsilon=F(1,UNIT);families=old['families'];modes={};certificates=[];decompositions=[];radius=old['angle_scale_mm'];proofcount=0
for family in ['bracket','insert','cog']:
    modes[family]=[];px,py=families[family]['source_center']
    for base in old['family_modes'][family]:
        angle=base['rotation_radians'];c,s=math.cos(angle),math.sin(angle);sign=-1 if base['mirrored'] else 1
        if family=='cog':local=[[-upper(radius),-upper(radius),upper(radius),upper(radius)]]
        else:
            local=[]
            for piece in partitions[family]['pieces']:
                v=[(sign*(F(x)-F(px))*F(c)-(F(y)-F(py))*F(s),sign*(F(x)-F(px))*F(s)+(F(y)-F(py))*F(c)) for x,y in piece];local.append([lower(min(p[0] for p in v)),lower(min(p[1] for p in v)),upper(max(p[0] for p in v)),upper(max(p[1] for p in v))])
        root=[safe[0]-min(r[0] for r in local)+epsilon,safe[1]-min(r[1] for r in local)+epsilon,safe[2]-max(r[2] for r in local)-epsilon,safe[3]-max(r[3] for r in local)-epsilon];forbidden=[[core[0]-gap-r[2],core[1]-gap-r[3],core[2]+gap-r[0],core[3]+gap-r[1]] for r in local];cells,atomic=merged_free_cells(root,forbidden);assert cells
        decompositions.append({'family':family,'source_mode':base['mode'],'local_piece_outer_boxes':list(map(serial,local)),'stock_center_root':serial(root),'forbidden_center_rectangles':list(map(serial,forbidden)),'atomic_cells':atomic,'merged_cells':list(map(serial,cells)),'complete_for_conservative_rectangle_arrangement':True,'complete_for_original_free_space':False})
        for index,cell in enumerate(cells):
            inward=[cell[0]+epsilon,cell[1]+epsilon,cell[2]-epsilon,cell[3]-epsilon];assert inward[0]<inward[2] and inward[1]<inward[3];bb=list(map(float,inward));ff=list(map(F,bb));assert all(ff[k]>cell[k] for k in [0,1]) and all(ff[k]<cell[k] for k in [2,3]);proofs=[]
            for piece in local:
                lowerx,lowery,upperx,uppery=ff[0]+piece[0],ff[1]+piece[1],ff[2]+piece[2],ff[3]+piece[3];gaps=[core[0]-upperx,core[1]-uppery,lowerx-core[2],lowery-core[3]];best=max(range(4),key=lambda k:gaps[k]);assert gaps[best]>=F('.22') and safe[0]<=lowerx<=upperx<=safe[2] and safe[1]<=lowery<=uppery<=safe[3];proofs.append({'axis':best,'exact_gap_mm':str(gaps[best])});proofcount+=1
            option={'mode':len(modes[family]),'source_mode':base['mode'],'cell_index':index,'rotation_radians':angle,'mirrored':base['mirrored'],'continuous_rotation':family=='cog','center_bounds_mm':[[bb[0],bb[2]],[bb[1],bb[3]]],'rectangle_mm':bb};modes[family].append(option);certificates.append({'family':family,'compound_mode':option['mode'],'source_mode':base['mode'],'cell_index':index,'piece_axis_supports':proofs})
used={(r['part_id'],r['copy_index']) for r in fixed};ids=[[family,i] for family in ['bracket','insert','cog'] for i in range(parts[family]['quantity']) if (family,i) not in used];assert ids==[['bracket',i] for i in range(6,12)]+[['insert',i] for i in range(11)]+[['insert',20]]+[['cog',i] for i in range(15)];partial=load(PREVIOUS/'seed59-source.json');control=audit(job,partial,stocks,required,guard);assert control==load(PREVIOUS/'seed59-checks.json') and control['valid'];seed=[]
for row in partial:
    key=(row['part_id'],row['copy_index'])
    if key in used:continue
    owner=ids.index(list(key));t=row['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;px,py=families[key[0]]['source_center'];center=[sign*px*c-py*s+t['translation'][0],sign*px*s+py*c+t['translation'][1]];available=[m['mode'] for m in modes[key[0]] if (key[0]=='cog' or (m['rotation_radians']==t['rotation_radians'] and m['mirrored']==t['mirrored'])) and all(m['center_bounds_mm'][k][0]<=center[k]<=m['center_bounds_mm'][k][1] for k in [0,1])];assert available;seed.append({'owner':owner,'identity':list(key),'source_pose':t,'center':center,'angle_radians':t['rotation_radians'],'covering_compound_modes':available})
assert len(seed)==26;write(OUT/'source59-control.json',partial);write(OUT/'source59-checks.json',control);write(OUT/'source26-moving-seed.json',seed);write(OUT/'rectangle-decompositions.json',decompositions);write(OUT/'cell-support-certificates.json',certificates);write(OUT/'fixed-frame-containing-box.json',{'core_outer_rectangle':serial(core),'safe_source_stock':serial(safe),'original_frame_count':18,'source_frame_vertices':len(vertices)})
library={'families':families,'family_modes':modes,'identities':ids,'pairs':list(combinations(range(33),2)),'fixed_source_rows':fixed,'all66_identities':old['all66_identities'],'source_stocks':stocks,'safe_source_stock_mm':list(map(float,safe)),'fixed_frame_outer_rectangle_mm':list(map(float,core)),'required_pair_gap_mm':required,'stock_guard_mm':guard,'angle_scale_mm':radius,'angle_bounds':[[-math.pi*radius,math.pi*radius] for _ in range(15)],'continuous_parameters':81,'angle_coordinate_start':66,'first_cog_owner':18,'source_moving_seed':seed,'source_initialization_prepared':False,'complete_model_prepared':False};write(OUT/'library.json',library);assert time.perf_counter()-start<12;checks={'passed':True,'seconds':time.perf_counter()-start,'fixed_originals':33,'fixed_source_valid':True,'moving_originals':33,'continuous_cog_angles':15,'continuous_parameters':81,'moving_pairs':528,'compound_modes_by_family':{f:len(v) for f,v in modes.items()},'owner_compound_mode_options':sum(len(modes[f]) for f,_ in ids),'whole_cell_piece_support_proofs':proofcount,'source59_control_valid':True,'source_moving_seed_poses':26,'remaining_unplaced_companions':7,'complete_reused_source_preparation_seconds':charge,'source_initializer_prepared':False,'complete_model_prepared':False,'optimizer_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False,'library_sha256':digest(OUT/'library.json')};write(OUT/'checks.json',checks);print(checks)
