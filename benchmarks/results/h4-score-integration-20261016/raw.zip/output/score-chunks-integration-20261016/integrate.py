"""Integrate only the proven score-bound candidate after all active probes finish."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import psutil

ROOT=Path(__file__).resolve().parents[1]
PROBE=ROOT/'output/h4-score-granularity-probe'
OUT=ROOT/'output/score-chunks-integration-20261016'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')

sys.stdout.reconfigure(encoding='utf-8',errors='replace')
sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest

assert load(ROOT/'benchmarks/results/h4-score-chunks-probe-20261016/results.json')['summary']['passes_subset']
assert load(ROOT/'benchmarks/results/h4-score-chunks-probe-20261016/verification.json')['original_records_verified']
pilot=load(ROOT/'benchmarks/results/h5-exchange-pilot-v2-20261016/results.json')
assert pilot['guards_unchanged'] and pilot['summary']['all_valid']
assert all(r.get('stats',{}).get('directed_exchange_attempts',0)==0 for r in pilot['records'])
for name,runner in [('h4-preview-development-20261016','h4_preview_matrix.py'),
    ('h4-score-chunks-probe-20261016','h4_score_chunks_probe.py'),
    ('h5-exchange-pilot-v2-20261016','h5_exchange_pilot_v2.py'),
    ('h5-exchange-path-20261016','h5_exchange_path_diagnostic.py')]:
    folder=ROOT/'benchmarks/results'/name
    assert load(folder/'results.json')['guards_unchanged']
    pid=load(folder/'opened.json')['pid']
    assert not psutil.pid_exists(pid) or not any(runner in p for p in psutil.Process(pid).cmdline()),name

assert not OUT.exists()
OUT.mkdir()
source=PROBE/'workspace/crates/core/src/separate/score.rs'
destination=ROOT/'crates/core/src/separate/score.rs'
preparation=load(PROBE/'plan.json')
for row in preparation['baseline_files']:assert digest(ROOT/row['path'])==row['sha256'],row['path']
assert digest(source)==load(PROBE/'build-v3.json')['candidate_score_sha256']
old_digest=source_digest()
shutil.copyfile(destination,OUT/'baseline-score.rs')
shutil.copyfile(source,destination)
assert subprocess.check_output(['git','diff','--name-only','--','crates','web/src','Cargo.toml','Cargo.lock'],cwd=ROOT,text=True).splitlines()==['crates/core/src/separate/score.rs']
plan={'scope':__doc__,'previous_product_digest':old_digest,'new_product_digest':source_digest(),
    'candidate_score_sha256':digest(destination),'source_change':'Eight-pair exact-bound checks and explicit existing-test chunk coverage',
    'H5_exchange_integrated':False,'reason':'All 24 exchange candidates recorded zero proposal attempts and all four mechanical/kerf medians still fail the original material limit.',
    'prior_failures_preserved':True,'held_out_geometry_read':False,'release_still_pending':True}
write(OUT/'plan.json',plan)

records=[]
def run(label,command):
    log=OUT/(label+'.log')
    full=[sys.executable,'-X','utf8',str(ROOT/'output/ccd1.py'),*map(str,command)]
    env={**os.environ,'PYTHONIOENCODING':'utf-8'}
    started=datetime.now(timezone.utc).isoformat()
    with log.open('xb') as stream:
        result=subprocess.run(full,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
    records.append({'label':label,'command':full,'started':started,'finished':datetime.now(timezone.utc).isoformat(),
        'exit_code':result.returncode,'log_sha256':digest(log)})
    write(OUT/'progress.json',records)
    print(label,result.returncode,log.read_text(encoding='utf-8',errors='replace')[-1600:],flush=True)
    assert result.returncode==0,label

run('format',['cargo','fmt','--all','--check'])
run('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'])
run('workspace-tests',['cargo','test','--workspace','--locked'])
run('optimized-scores',['cargo','test','--release','--locked','-p','nestbolt-core','--lib','bounded','--','--nocapture'])
run('optimized-cli',['cargo','test','--release','--locked','-p','nestbolt-cli','--test','features'])
run('native-build',['cargo','build','--release','--locked','-p','nestbolt-cli','-p','nestbolt-mcp'])
run('web-build-tests',[sys.executable,'-X','utf8','scripts/build_web.py','--test'])
run('notices',[sys.executable,'scripts/notices.py','--check'])
run('schemas',[sys.executable,'scripts/schemas.py','--check'])
run('packaging-tests',['node','--test','mcpb/mcpb.test.mjs'])
run('bundle',['node','mcpb/build.mjs','--binary',ROOT/'target/release/nestbolt-mcp.exe','--out',OUT/'bundle'])
run('verify-bundle',['node','mcpb/verify.mjs',OUT/'bundle/nestbolt-windows-x64.mcpb'])
assert source_digest()==plan['new_product_digest']
write(OUT/'results.json',{'all_checks_passed':True,'commands':records,'product_digest':source_digest(),
    'cli_sha256':digest(ROOT/'target/release/nestbolt.exe'),
    'mcp_sha256':digest(ROOT/'target/release/nestbolt-mcp.exe'),
    'wasm_sha256':digest(ROOT/'web/src/pkg/nestbolt_wasm_bg.wasm'),
    'candidate_score_sha256':digest(destination),'H5_exchange_integrated':False,'release_still_pending':True})
print('Score candidate integrated and checked; final full comparison and scale remain.',flush=True)
