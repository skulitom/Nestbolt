"""Independent exact original-vertex containment and whole-cell collision audit."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-eight-cog-vertices-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-cog-hull-stock-20261108';CENTERS=ROOT/'output/h5-eight-core-centers-20261108';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';G=ROOT/'output/h5-free-cog-geometry-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit',CENTERS/'audit',G/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'vertices.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently reconstruct all original source vertex coordinates with rational transform coefficients for every actual fixed cog. Verify their saved outward intervals contain1um-padded coordinates. The previously certified109mm source inner disk has winding1 and strict edge distance; the source is a valid simple filled body. For each excluded continuous center cell, check all16 center/vertex interval corner distances strictly below109mm. No producer max-distance formula or union-of-vertex sampling is used. Every prior cell is either retained or has a valid witness. Hull139mm only clips stock, never supplies a collision disk.'})
part=next(p for p in load(JOB)['parts'] if p['id']=='cog');geo=load(G/'geometry.json');assert min(Q(r['segment_distance_squared']) for r in geo['source_disk_edge_certificates'])>109**2 and load(G/'audit/checks.json')['source_winding_number']==1;domain=load(OLD/'hull-support.json')['necessary_stock_center_domain_um'];geometries={r['key']:r for r in load(CENTERS/'geometries.json')};vertices={r['key']:r['fixed_source_vertex_intervals'] for r in load(BASE/'vertices.json')};cases=load(OLD/'audit/remaining-cases.json');saved={r['key']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==len(vertices)==8;cache={};assignments=0;results=[];h=2500
for case in cases:
    key=case['key'];rows={r['copy_index']:r for r in geometries[key]['source_fixed_first32'] if r['part_id']=='cog'};fixed=vertices[key];assert len(fixed)==1120 and {(v['copy_index'],v['vertex']) for v in fixed}==set(product(range(14),range(80)))
    for vertex in fixed:
        t=rows[vertex['copy_index']]['transform'];posekey=json.dumps(t,sort_keys=True)
        if posekey not in cache:
            assert not t['mirrored'];cs,sn=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));tx,ty=map(Q,t['translation']);matrix=((cs,-sn),(sn,cs));cache[posekey]=[tuple(sum(matrix[k][j]*Q(p[j]) for j in range(2))+(tx,ty)[k] for k in range(2)) for p in part['geometry'][0]['outer']]
        point=cache[posekey][vertex['vertex']];a,b,c,d=vertex['interval_um'];pad=Q(1,1000);assert Q(a,1000)<=point[0]-pad and point[0]+pad<=Q(c,1000) and Q(b,1000)<=point[1]-pad and point[1]+pad<=Q(d,1000) and c-a<=3 and d-b<=3;assignments+=1
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:old=z['remaining_center_cells'];ys,xs=np.nonzero(old)
    with np.load(BASE/(key+'.npz'),allow_pickle=False) as z:
        assert np.array_equal(z['source_y'],ys) and np.array_equal(z['source_x'],xs);witness=z['vertex_witness'];assert witness.shape==xs.shape and np.all((witness>=-1)&(witness<len(fixed)));remaining=old.copy();remaining[ys,xs]=witness<0;assert np.array_equal(z['remaining_center_cells'],remaining)
    for i in np.unique(witness[witness>=0]):
        take=witness==i;sx,sy=xs[take],ys[take];l=np.maximum(sx*h,domain[0]);r=np.minimum((sx+1)*h,domain[2]);b=np.maximum(sy*h,domain[1]);u=np.minimum((sy+1)*h,domain[3]);a,c,d,e=fixed[int(i)]['interval_um']
        for x,y in product([l,r],[b,u]):
            for vx,vy in product([a,d],[c,e]):assert np.all((x-vx)**2+(y-vy)**2<109000**2)
    row={'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'input_center_cells':len(xs),'vertex_collision_cells_excluded':int((witness>=0).sum()),'remaining_center_cells':int((witness<0).sum()),'provisional_exact_first32_excluded':not bool((witness<0).any())};assert row==saved[key];results.append({**row,'exact_first32_excluded':not bool((witness<0).any())})
process=load(ROOT/'output/h5-eight-cog-vertices-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_first32_excluded']];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':8,'source_vertex_assignments_verified':assignments,'unique_source_poses_verified':len(cache),'unique_source_vertices_verified':len(cache)*80,'continuous_center_cells_verified':sum(r['input_center_cells'] for r in results),'vertex_collision_cells_excluded':sum(r['vertex_collision_cells_excluded'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'exact_first32_cases_excluded':8-len(remaining),'exact_first32_cases_remaining':len(remaining),'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
