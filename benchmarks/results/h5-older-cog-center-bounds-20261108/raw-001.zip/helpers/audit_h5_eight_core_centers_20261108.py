"""Independent original-source and complete cell-witness audit for the older cores."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-eight-core-centers-20261108';OUT=BASE/'audit';SCOPE=ROOT/'output/h5-eight-core-scope-20261108';M=ROOT/'output/h5-one-three-covers-20261107';G=ROOT/'output/h5-free-cog-geometry-v2-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,SCOPE,M/'audit',G/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),JOB,BASE/'geometries.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconstruct actual fixed first32 source poses for each changed world with rational pose coefficients. Verify allframe inner rectangles directly by expanded corner containment, and allfixedcog disk assignments by exact segment-distance certificates cached only for byte-identical source poses. Recheck the universal109mm source disk and necessary stock-center domain. Every full-stock gridcell is accounted for: outside-stock cells or complete4corner frame/disk collision witnesses may be removed; all other cells stay. Reconcile every reason/witness and retained array, with no producer mask or old17site world reused. This is a complete continuous-cell outer cover at all exact rigid source angles.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};geo=load(G/'geometry.json');source_center=list(map(Q,geo['source_center']));assert min(Q(r['segment_distance_squared']) for r in geo['source_disk_edge_certificates'])>109**2;scopes={f"t{r['turned_frames']}-{r['case']}":r for r in load(SCOPE/'remaining-core-scopes.json')};geometries=load(BASE/'geometries.json');saved={r['key']:r for r in load(BASE/'case-results.json')};assert len(scopes)==len(geometries)==len(saved)==8
stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];domain=[stock[0]+109000,stock[1]+109000,stock[2]-109000,stock[3]-109000];h=2500;ny,nx=1200,600;xx=np.arange(nx)*h;yy=np.arange(ny)*h;stockmask=(xx[None,:]+h>domain[0])&(xx[None,:]<=domain[2])&(yy[:,None]+h>domain[1])&(yy[:,None]<=domain[3]);cache={};frame_checks=0;cog_checks=0;results=[]
for geometry in geometries:
    key=geometry['key'];scope=scopes[key];rows=scope['source_fixed_first32'];assert geometry['source_fixed_first32']==rows and len(rows)==32 and geometry['stock_center_domain_um']==domain and geometry['cell_step_um']==h;lookup={(r['part_id'],r['copy_index']):r for r in rows};frames=geometry['frame_inner_rectangles'];assert len(frames)==18 and {r['site_bit'] for r in frames}=={16}
    for frame in frames:
        row=lookup[tuple(frame['identity'])];t=row['transform'];assert not t['mirrored'];c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));tx,ty=map(Q,t['translation']);p=[(Q(x)*c-Q(y)*s+tx,Q(x)*s+Q(y)*c+ty) for x,y in parts['frame']['geometry'][0]['outer']]
        if sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))<0:p=p[::-1]
        l,b,r,u=map(lambda z:Q(z,1000),frame['bounds_um']);pad=Q(1,10**6);corners=list(product([l-pad,r+pad],[b-pad,u+pad]));assert all(cross(a,b,q)>0 for a,b in zip(p,p[1:]+p[:1]) for q in corners);frame_checks+=1
    disks={r['copy_index']:r for r in geometry['fixed_cog_disks']};assert set(disks)==set(range(14))
    for copy,rowdisk in disks.items():
        row=lookup['cog',copy];t=row['transform'];assert not t['mirrored'];posekey=json.dumps(t,sort_keys=True)
        if posekey not in cache:
            c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));tx,ty=map(Q,t['translation']);center=(source_center[0]*c-source_center[1]*s+tx,source_center[0]*s+source_center[1]*c+ty);p=[(Q(x)*c-Q(y)*s+tx,Q(x)*s+Q(y)*c+ty) for x,y in parts['cog']['geometry'][0]['outer']]
            for a,b in zip(p,p[1:]+p[:1]):
                e=[b[k]-a[k] for k in range(2)];v=[center[k]-a[k] for k in range(2)];u=min(Q(1),max(Q(0),sum(v[k]*e[k] for k in range(2))/sum(z*z for z in e)));assert sum((v[k]-u*e[k])**2 for k in range(2))>Q(108991,1000)**2
            cache[posekey]=(center,c*c+s*s)
        center,det=cache[posekey];a,b,c,d=rowdisk['center_interval_um'];assert Q(a,1000)<=center[0]<=Q(c,1000) and Q(b,1000)<=center[1]<=Q(d,1000) and c-a<=1 and d-b<=1 and Q(rowdisk['matrix_determinant'])==det>0 and rowdisk['radius_um']==108990;cog_checks+=1
    with np.load(BASE/(key+'.npz'),allow_pickle=False) as z:
        reason=z['reason'];witness=z['witness'];remaining=z['remaining_center_cells'];assert reason.shape==witness.shape==remaining.shape==(ny,nx) and set(np.unique(reason))<={0,1,2,3};assert np.array_equal(reason==1,~stockmask) and np.array_equal(remaining,reason==0)
        for kind in [2,3]:
            for index in np.unique(witness[reason==kind]):
                sy,sx=np.nonzero((reason==kind)&(witness==index));l=np.maximum(sx*h,domain[0]);r=np.minimum((sx+1)*h,domain[2]);b=np.maximum(sy*h,domain[1]);t=np.minimum((sy+1)*h,domain[3]);worst=np.zeros(len(sx),dtype=np.int64)
                if kind==2:
                    assert 0<=index<18;a,c,d,e=frames[int(index)]['bounds_um']
                    for x,y in product([l,r],[b,t]):worst=np.maximum(worst,(x-np.clip(x,a,d))**2+(y-np.clip(y,c,e))**2)
                    assert np.all(worst<109000**2)
                else:
                    assert int(index) in disks;a,c,d,e=disks[int(index)]['center_interval_um']
                    for x,y in product([l,r],[b,t]):
                        for cx,cy in product([a,d],[c,e]):worst=np.maximum(worst,(x-cx)**2+(y-cy)**2)
                    assert np.all(worst<217990**2)
    record={'key':key,'turned_frames':scope['turned_frames'],'case':scope['case'],'continuous_stock_grid_cells':ny*nx,'stock_excluded_cells':int((reason==1).sum()),'frame_excluded_cells':int((reason==2).sum()),'fixed_cog_excluded_cells':int((reason==3).sum()),'remaining_center_cells':int(remaining.sum()),'provisional_exact_first32_excluded':not bool(remaining.any())};assert record==saved[key];results.append({**record,'exact_first32_excluded':not bool(remaining.any())})
process=load(ROOT/'output/h5-eight-core-centers-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_first32_excluded']];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'changed_source_worlds_verified':2,'cases_verified':8,'actual_source_frame_rectangles_verified':frame_checks,'fixed_cog_pose_assignments_verified':cog_checks,'unique_fixed_cog_poses_verified':len(cache),'source_cog_segment_checks':80*len(cache),'continuous_full_stock_cells_verified':8*ny*nx,'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'exact_first32_cases_excluded':8-len(remaining),'exact_first32_cases_remaining':len(remaining),'old17site_world_masks_reused':False,'all_exact_rigid_source_angles_covered':True,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
