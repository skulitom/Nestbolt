"""Independent supporting-halfplane proof and complete stock-cell readback."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-hull-stock-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-eight-core-centers-20261108';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';M=ROOT/'output/h5-one-three-covers-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'hull-support.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Without rerunning the producer hull algorithm, verify every hull vertex is an original source vertex, every turn strictly convex, every original point inside every directed hull halfplane, and the centered support disk inside each halfplane. This proves equality with the source convex hull. Verify the original stock is a convex rectangle without defects; containment of source in stock therefore implies hull containment, at every rigid angle. The resulting disk is a stock-support tool ONLY, not body occupancy or a collision disk. Independently map every retained half-open center cell against the necessary rectangle using its interval endpoints; replay every mask and exclusion.'})
job=load(JOB);part=next(p for p in job['parts'] if p['id']=='cog');points=[tuple(map(Q,p)) for p in part['geometry'][0]['outer']];record=load(BASE/'hull-support.json');hull=[tuple(map(Q,p)) for p in record['source_hull_vertices']];center=tuple(map(Q,record['source_center']));radius=record['support_radius_mm'];assert len(set(hull))==len(hull) and set(hull)<=set(points);distances=[]
for i,(a,b) in enumerate(zip(hull,hull[1:]+hull[:1])):
    assert cross(a,b,hull[(i+2)%len(hull)])>0 and all(cross(a,b,p)>=0 for p in points);value=cross(a,b,center);assert value>0;d=value*value/sum((b[k]-a[k])**2 for k in range(2));assert d==Q(record['edge_support_distance_squared_mm2'][i]) and d>=radius**2;distances.append(d)
assert min(distances)==Q(record['minimum_edge_support_distance_squared_mm2']) and min(distances)<(radius+1)**2;assert record['convex_stock_support_only'] and record['not_a_filled_body_disk'];assert len(job['stocks'])==1 and job['stocks'][0]['outline']==job['stocks'][0]['defects']==[] and job['stocks'][0]['width']==1500 and job['stocks'][0]['height']==3000
stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];domain=[stock[0]+radius*1000,stock[1]+radius*1000,stock[2]-radius*1000,stock[3]-radius*1000];assert record['necessary_stock_center_domain_um']==domain;cases=load(OLD/'audit/remaining-cases.json');saved={r['key']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==8;results=[]
for case in cases:
    with np.load(OLD/(case['key']+'.npz'),allow_pickle=False) as z:old=z['remaining_center_cells'];ys,xs=np.nonzero(old)
    good=(xs*2500<=domain[2])&((xs+1)*2500>domain[0])&(ys*2500<=domain[3])&((ys+1)*2500>domain[1]);remaining=np.zeros_like(old);remaining[ys[good],xs[good]]=True
    with np.load(BASE/(case['key']+'.npz'),allow_pickle=False) as z:assert np.array_equal(z['remaining_center_cells'],remaining)
    row={'key':case['key'],'turned_frames':case['turned_frames'],'case':case['case'],'input_center_cells':len(xs),'stock_support_cells_excluded':int((~good).sum()),'remaining_center_cells':int(good.sum()),'provisional_exact_first32_excluded':not bool(good.any())};assert row==saved[case['key']];results.append({**row,'exact_first32_excluded':not bool(good.any())})
process=load(ROOT/'output/h5-cog-hull-stock-process-20261108/process.json');assert process['passed'] and process['closed'];total=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_first32_excluded']];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source_hull_vertices_verified':len(hull),'original_vertex_halfplane_checks':len(points)*len(hull),'universal_source_stock_support_radius_mm':radius,'used_only_for_convex_stock_containment':True,'cases_verified':8,'continuous_center_cells_verified':sum(r['input_center_cells'] for r in results),'stock_support_cells_excluded':sum(r['stock_support_cells_excluded'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'exact_first32_cases_excluded':8-len(remaining),'exact_first32_cases_remaining':len(remaining),'complete_preparation_seconds_if_consumed':total,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
