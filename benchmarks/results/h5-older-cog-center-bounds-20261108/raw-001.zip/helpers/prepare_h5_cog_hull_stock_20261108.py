"""Source convex-hull support gives a stock-only all-angle center constraint."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from math import isqrt
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog-hull-stock-20261108';OLD=ROOT/'output/h5-eight-core-centers-20261108';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';G=ROOT/'output/h5-free-cog-geometry-v2-20261107';M=ROOT/'output/h5-one-three-covers-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/remaining-cases.json');assert len(cases)==8 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),JOB,G/'geometry.json',G/'audit/checks.json',OLD/'audit/checks.json',OLD/'audit/remaining-cases.json',M/'stock-cover.json']+[OLD/(r['key']+'.npz') for r in cases]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Construct the exact rational convex hull of the original cog vertices and a centered disk contained in that hull. Any rigid source polygon fitting convex rectangular stock has its entire convex hull in stock, so its center must stay at least this hull support radius inside each stock edge at every angle. This is ONLY a stock support bound: the hull disk is not contained in the concave cog body and must not be used for part collisions, cog occupied area or hole filling. Intersect the complete current continuous center-cell covers with the stronger necessary stock-center rectangle; preserve all intersecting cells.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':10,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
part=next(p for p in load(JOB)['parts'] if p['id']=='cog');points=sorted(set(tuple(map(Q,p)) for p in part['geometry'][0]['outer']));center=tuple(map(Q,load(G/'geometry.json')['source_center']));lower=[];upper=[]
for p in points:
    while len(lower)>1 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
    lower.append(p)
for p in points[::-1]:
    while len(upper)>1 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
    upper.append(p)
hull=lower[:-1]+upper[:-1];edges=[]
for a,b in zip(hull,hull[1:]+hull[:1]):
    value=cross(a,b,center);assert value>0;length=sum((b[k]-a[k])**2 for k in range(2));edges.append(value*value/length)
minimum=min(edges);radius_mm=isqrt(minimum.numerator//minimum.denominator);assert 109<radius_mm<141 and Q(radius_mm)**2<=minimum;radius=radius_mm*1000;stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];domain=[stock[0]+radius,stock[1]+radius,stock[2]-radius,stock[3]-radius];write(OUT/'hull-support.json',{'source_center':[str(z) for z in center],'source_hull_vertices':[[str(z) for z in p] for p in hull],'edge_support_distance_squared_mm2':[str(z) for z in edges],'support_radius_mm':radius_mm,'minimum_edge_support_distance_squared_mm2':str(minimum),'necessary_stock_center_domain_um':domain,'convex_stock_support_only':True,'not_a_filled_body_disk':True})
h=2500;ny,nx=1200,600;xx=np.arange(nx)*h;yy=np.arange(ny)*h;intersects=(xx[None,:]+h>domain[0])&(xx[None,:]<=domain[2])&(yy[:,None]+h>domain[1])&(yy[:,None]<=domain[3]);results=[]
for case in cases:
    with np.load(OLD/(case['key']+'.npz'),allow_pickle=False) as z:old=z['remaining_center_cells']
    remaining=old&intersects;np.savez_compressed(OUT/(case['key']+'.npz'),remaining_center_cells=remaining);results.append({'key':case['key'],'turned_frames':case['turned_frames'],'case':case['case'],'input_center_cells':int(old.sum()),'stock_support_cells_excluded':int((old&~remaining).sum()),'remaining_center_cells':int(remaining.sum()),'provisional_exact_first32_excluded':not bool(remaining.any())})
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'source_hull_vertices':len(hull),'source_stock_support_radius_mm':radius_mm,'cases':8,'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
