"""Whole-source-body area conservation for the eight changed fixed worlds."""
from pathlib import Path
from hashlib import sha256
from math import isqrt
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-eight-cog-complement-20261108';OLD=ROOT/'output/h5-eight-cog-vertices-20261108';M=ROOT/'output/h5-one-three-covers-20261107';SCOPE=ROOT/'output/h5-eight-core-scope-20261108';G=ROOT/'output/h5-free-cog-complement-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/remaining-cases.json');assert len(cases)==8 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),OLD/'audit/checks.json',OLD/'audit/remaining-cases.json',M/'audit/checks.json',M/'stock-cover.json',SCOPE/'checks.json',SCOPE/'remaining-core-scopes.json',G/'source-outer-bound.json',G/'audit/checks.json']+[p for r in cases for p in [OLD/(r['key']+'.npz'),M/f"turned-{r['turned_frames']}"/(r['case']+'-capacity.json')]]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Build fresh world/case-specific outer covers of stock minus(U union F), where U is the complete union of all original bracket/insert component envelopes and F is mandatory fixed-source inner area. Any valid last cog has area at least50000mm2, cannot overlap F, and lies within140.001mm of its continuous center. Count complete circular neighborhoods of every surviving2.5mm center cell against the complement outer raster. At least50000 minus outside_upper of the cog must occupy R=U minus F. Subtract that compulsory occupancy from the independently certified area(R) upper and compare all necessary companion inventories. Current17-site masks are never reused.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
h=2500;ny,nx=1200,600;record=load(G/'source-outer-bound.json');radius=record['source_outer_radius_um'];assert radius==140001 and record['source_filled_area_lower_mm2']==50000;stripes=[]
for dy in range(-58,59):
    q=radius*radius-(h*max(abs(dy)-1,0))**2
    if q>=0:stripes.append([dy,isqrt(q)//h+1])
write(OUT/'kernel-stripes.json',{'step_um':h,'source_outer_radius_um':radius,'horizontal_stripes':stripes,'covered_target_cells':sum(2*w+1 for _,w in stripes),'minimum_distance_outer_cover':True});sb=load(M/'stock-cover.json')['outward_stock_rectangle_um'];xs=np.arange(nx)*h;ys=np.arange(ny)*h;stock=(ys[:,None]+h>sb[1])&(ys[:,None]<sb[3])&(xs[None,:]+h>sb[0])&(xs[None,:]<sb[2]);scopes={f"t{r['turned_frames']}-{r['case']}":r for r in load(SCOPE/'remaining-core-scopes.json')};results=[]
def inside(rects):
    diff=np.zeros((ny+1,nx+1),dtype=np.int32)
    for l,b,r,t in rects:
        xa,ya,xb,yb=-((-l)//h),-((-b)//h),r//h,t//h;xa,xb=max(0,min(nx,xa)),max(0,min(nx,xb));ya,yb=max(0,min(ny,ya)),max(0,min(ny,yb))
        if xa<xb and ya<yb:diff[ya,xa]+=1;diff[yb,xa]-=1;diff[ya,xb]-=1;diff[yb,xb]+=1
    return diff.cumsum(0,dtype=np.int32).cumsum(1,dtype=np.int32)[:-1,:-1]>0
for case in cases:
    key=case['key'];scope=scopes[key];data=load(M/f"turned-{case['turned_frames']}"/(case['case']+'-capacity.json'));assert data['omitted_sites']==scope['omitted_sites'];upper=data['combined_area_upper_um2'];assert upper==scope['first_companion_area_upper_um2'];required=scope['first_companion_area_required_at_least_um2'];outer=stock&~inside(data['combined_regions_um']+data['fixed_inner_obstacles_um']);prefix=np.pad(outer.cumsum(1,dtype=np.int32),((0,0),(1,0)))
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:domain=z['remaining_center_cells'];yy,xx=np.nonzero(domain)
    counts=np.zeros(len(xx),dtype=np.int32)
    for dy,w in stripes:
        y=yy+dy;valid=(y>=0)&(y<ny);counts[valid]+=prefix[y[valid],np.minimum(nx,xx[valid]+w+1)]-prefix[y[valid],np.maximum(0,xx[valid]-w)]
    outside=counts.astype(np.int64)*h*h;forced=np.maximum(0,50000*10**6-outside);allowed=upper-forced>=required;remaining=domain.copy();remaining[yy,xx]=allowed;np.savez_compressed(OUT/(key+'.npz'),complement_outer_cells=outer,source_y=yy,source_x=xx,outside_area_upper_um2=outside,forced_companion_overlap_lower_um2=forced,remaining_center_cells=remaining)
    results.append({'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':scope['omitted_sites'],'input_center_cells':len(xx),'pruned_center_cells':int((~allowed).sum()),'remaining_center_cells':int(allowed.sum()),'first_companion_upper_um2':upper,'required_first_companion_um2':required,'maximum_outside_cog_area_upper_um2':int(outside.max()),'minimum_forced_companion_overlap_um2':int(forced.min()),'minimum_area_deficit_um2':int((required-upper+forced).min()),'provisional_exact_first32_excluded':not bool(allowed.any())})
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':8,'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
