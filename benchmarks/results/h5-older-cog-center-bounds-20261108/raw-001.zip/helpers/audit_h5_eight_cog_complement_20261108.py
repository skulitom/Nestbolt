"""Independent changed-world complement raster and direct circle-stencil audit."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-eight-cog-complement-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-eight-cog-vertices-20261108';M=ROOT/'output/h5-one-three-covers-20261107';SCOPE=ROOT/'output/h5-eight-core-scope-20261108';G=ROOT/'output/h5-free-cog-complement-20261108';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit',M/'audit',SCOPE,G/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'kernel-stripes.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Bind the original-source and actual first32 scope audits for each changed world. Recheck all80 exact source vertex radii. Reconstruct each fresh complement outer mask via direct cell-edge tests and rectangle slice union, independently of producer difference arrays. Derive all circular-kernel cells via rectangle minimum distances and directly count every continuous center neighborhood, independently of prefix sums. Reconcile source identities, all necessary inventories, all area thresholds and every survivor. No native/timed/full-layout claim.'})
source=load(G/'source-outer-bound.json');radius=source['source_outer_radius_um'];assert radius==140001 and source['source_filled_area_lower_mm2']==50000;part=next(p for p in load(JOB)['parts'] if p['id']=='cog');center=list(map(Q,source['source_center']));assert len(source['source_vertex_squared_radii_mm2'])==80
for point,saved in zip(part['geometry'][0]['outer'],source['source_vertex_squared_radii_mm2']):assert sum((Q(point[k])-center[k])**2 for k in range(2))==Q(saved)<Q(radius,1000)**2
h=2500;ny,nx=1200,600;kernel=np.zeros((117,117),dtype=bool)
for dy in range(-58,59):
    for dx in range(-58,59):
        minimum=min((x-min(h,max(0,x)))**2+(y-min(h,max(0,y)))**2 for x in [dx*h,(dx+1)*h] for y in [dy*h,(dy+1)*h]);kernel[dy+58,dx+58]=minimum<=radius**2
savedkernel=load(BASE/'kernel-stripes.json');reconstructed=np.zeros_like(kernel)
for dy,w in savedkernel['horizontal_stripes']:reconstructed[dy+58,58-w:59+w]=True
assert np.array_equal(reconstructed,kernel) and int(kernel.sum())==savedkernel['covered_target_cells'];assert not kernel[0].any() and not kernel[-1].any() and not kernel[:,0].any() and not kernel[:,-1].any();assert kernel[58,58] and kernel[58,115] and not kernel[58,116] and not kernel[115,115]
def count(outer,y,x):
    y0,y1=max(0,y-58),min(ny,y+59);x0,x1=max(0,x-58),min(nx,x+59);return np.count_nonzero(outer[y0:y1,x0:x1]&kernel[y0-y+58:y1-y+58,x0-x+58:x1-x+58])
fixture=np.zeros((ny,nx),dtype=bool);fixture[0,0]=True;assert count(fixture,0,0)==1 and count(fixture,ny-1,nx-1)==0 and count(fixture,0,57)==1 and count(fixture,0,58)==0
left=np.arange(nx)*h;right=left+h;bottom=np.arange(ny)*h;top=bottom+h;sb=load(M/'stock-cover.json')['outward_stock_rectangle_um'];stock=(top[:,None]>sb[1])&(bottom[:,None]<sb[3])&(right[None,:]>sb[0])&(left[None,:]<sb[2]);cases=load(OLD/'audit/remaining-cases.json');scopes={f"t{r['turned_frames']}-{r['case']}":r for r in load(SCOPE/'remaining-core-scopes.json')};saved={r['key']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==8;results=[]
for case in cases:
    key=case['key'];scope=scopes[key];data=load(M/f"turned-{case['turned_frames']}"/(case['case']+'-capacity.json'));assert data['omitted_sites']==scope['omitted_sites'];upper=data['combined_area_upper_um2'];assert upper==scope['first_companion_area_upper_um2'];required=min(r['first_companion_area_lower_um2'] for r in scope['necessary_splits_if_last_cog_first']);assert required==scope['first_companion_area_required_at_least_um2'];inside=np.zeros((ny,nx),dtype=bool)
    for l,b,r,t in data['combined_regions_um']+data['fixed_inner_obstacles_um']:
        xx=np.flatnonzero((left>=l)&(right<=r));yy=np.flatnonzero((bottom>=b)&(top<=t))
        if len(xx) and len(yy):inside[yy[0]:yy[-1]+1,xx[0]:xx[-1]+1]=True
    outer=stock&~inside
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:domain=z['remaining_center_cells'];yy,xx=np.nonzero(domain)
    outside=np.array([count(outer,int(y),int(x))*h*h for y,x in zip(yy,xx)],dtype=np.int64);forced=np.maximum(0,50000*10**6-outside);allowed=forced<=upper-required;remaining=domain.copy();remaining[yy,xx]=allowed
    with np.load(BASE/(key+'.npz'),allow_pickle=False) as z:
        for name,value in [('complement_outer_cells',outer),('source_y',yy),('source_x',xx),('outside_area_upper_um2',outside),('forced_companion_overlap_lower_um2',forced),('remaining_center_cells',remaining)]:assert np.array_equal(z[name],value),(key,name)
    row={'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':scope['omitted_sites'],'input_center_cells':len(xx),'pruned_center_cells':int((~allowed).sum()),'remaining_center_cells':int(allowed.sum()),'first_companion_upper_um2':upper,'required_first_companion_um2':required,'maximum_outside_cog_area_upper_um2':int(outside.max()),'minimum_forced_companion_overlap_um2':int(forced.min()),'minimum_area_deficit_um2':int((required-upper+forced).min()),'provisional_exact_first32_excluded':not bool(allowed.any())};assert row==saved[key];results.append({**row,'exact_first32_excluded':not bool(allowed.any())})
process=load(ROOT/'output/h5-eight-cog-complement-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_first32_excluded']];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':8,'changed_worlds_verified':2,'original_vertex_radius_checks':80,'circular_kernel_cells_verified':int(kernel.size),'circular_kernel_cells_retained':int(kernel.sum()),'continuous_center_cells_verified':sum(r['input_center_cells'] for r in results),'center_cells_excluded':sum(r['pruned_center_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'exact_first32_cases_excluded':8-len(remaining),'exact_first32_cases_remaining':len(remaining),'all_exact_rigid_source_angles_covered':True,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
