"""Exact integer cell areas tighten circular complement conservation."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-three-cog-exact-complement-20261108';OLD=ROOT/'output/h5-eight-cog-complement-20261108';M=ROOT/'output/h5-one-three-covers-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/remaining-cases.json');assert len(cases)==3 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),OLD/'audit/checks.json',OLD/'audit/remaining-cases.json',OLD/'kernel-stripes.json',M/'stock-cover.json',M/'audit/checks.json']+[p for r in cases for p in [OLD/(r['key']+'.npz'),M/f"turned-{r['turned_frames']}"/(r['case']+'-capacity.json')]]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For the three remaining changed-world cores, replace whole-cell complement overestimates by exact integer areas of each2.5mm cell in outward stock minus(U union F). Sweep horizontal slabs split at every rectangle and grid boundary, merge active x intervals, and accumulate exact clipped union area per cell. Keep the previously certified circular outer neighborhood for every continuous center cell: summing its exact complement areas remains an outside-area upper bound. Subtract compulsory source cog occupancy from the unchanged companion-area bound. No angle sampling, exact-layout claim, optimizer or timer reset.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
h=2500;ny,nx=1200,600;sb=load(M/'stock-cover.json')['outward_stock_rectangle_um'];xx=np.arange(nx,dtype=np.int64)*h;yy=np.arange(ny,dtype=np.int64)*h;stockwidth=np.maximum(0,np.minimum(xx+h,sb[2])-np.maximum(xx,sb[0]));stockheight=np.maximum(0,np.minimum(yy+h,sb[3])-np.maximum(yy,sb[1]));stockarea=stockheight[:,None]*stockwidth[None,:];stripes=load(OLD/'kernel-stripes.json')['horizontal_stripes'];results=[]
for case in cases:
    key=case['key'];data=load(M/f"turned-{case['turned_frames']}"/(case['case']+'-capacity.json'));rects=[(max(l,sb[0]),max(b,sb[1]),min(r,sb[2]),min(t,sb[3])) for l,b,r,t in data['combined_regions_um']+data['fixed_inner_obstacles_um']];rects=[r for r in rects if r[0]<r[2] and r[1]<r[3]];cuts=sorted({sb[1],sb[3],*[v for r in rects for v in (r[1],r[3])],*[int(v) for v in yy if sb[1]<v<sb[3]]});covered=np.zeros((ny,nx),dtype=np.int64)
    for bottom,top in zip(cuts,cuts[1:]):
        intervals=sorted((l,r) for l,b,r,t in rects if b<=bottom and t>=top);merged=[]
        for l,r in intervals:
            if merged and l<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],r)
            else:merged.append([l,r])
        widths=np.zeros(nx,dtype=np.int64)
        for l,r in merged:widths+=np.maximum(0,np.minimum(xx+h,r)-np.maximum(xx,l))
        covered[bottom//h]+=widths*(top-bottom)
    outside_cells=stockarea-covered;assert np.all((outside_cells>=0)&(outside_cells<=h*h));prefix=np.pad(outside_cells.cumsum(1,dtype=np.int64),((0,0),(1,0)))
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:domain=z['remaining_center_cells'];ys,xs=np.nonzero(domain);chosen=domain[z['source_y'],z['source_x']];previous=z['outside_area_upper_um2'][chosen];assert np.all(outside_cells<=z['complement_outer_cells'].astype(np.int64)*h*h)
    outside=np.zeros(len(xs),dtype=np.int64)
    for dy,w in stripes:
        y=ys+dy;valid=(y>=0)&(y<ny);outside[valid]+=prefix[y[valid],np.minimum(nx,xs[valid]+w+1)]-prefix[y[valid],np.maximum(0,xs[valid]-w)]
    assert np.all(outside<=previous);forced=np.maximum(0,50000*10**6-outside);upper=case['first_companion_upper_um2'];required=case['required_first_companion_um2'];allowed=upper-forced>=required;remaining=domain.copy();remaining[ys,xs]=allowed;np.savez_compressed(OUT/(key+'.npz'),complement_cell_area_um2=outside_cells,source_y=ys,source_x=xs,outside_area_upper_um2=outside,forced_companion_overlap_lower_um2=forced,remaining_center_cells=remaining)
    results.append({'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'omitted_sites':case['omitted_sites'],'input_center_cells':len(xs),'pruned_center_cells':int((~allowed).sum()),'remaining_center_cells':int(allowed.sum()),'first_companion_upper_um2':upper,'required_first_companion_um2':required,'maximum_outside_cog_area_upper_um2':int(outside.max()),'minimum_forced_companion_overlap_um2':int(forced.min()),'minimum_area_deficit_um2':int((required-upper+forced).min()),'provisional_exact_first32_excluded':not bool(allowed.any())})
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':3,'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
