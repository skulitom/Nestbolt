"""Seal complete free-angle covers and five newly excluded older fixed cores."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
stage_names=['eight-core-centers','cog-hull-stock','eight-cog-vertices','eight-cog-complement','three-cog-exact-complement']
process_names=[v+s for v in stage_names for s in ['', '-audit']]
process_paths=[ROOT/'output'/('h5-'+n+'-process-20261108') for n in process_names]
s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-older-cog-center-bounds-20261108'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-three-cog-exact-complement-20261108';F=BASE/'audit';D=ROOT/'output/h5-eight-core-scope-20261108'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-free-cog-complement-closure-20261108'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['cases_verified']==3 and front['exact_first32_cases_remaining']==3 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[ROOT/'output'/('h5-'+n+'-20261108') for n in stage_names]+process_paths",
"['*h5*mixed*mode*20261107.py']":"['*h5_eight_core_centers*20261108.py','*h5_cog_hull_stock*20261108.py','*h5_eight_cog*20261108.py','*h5_three_cog_exact*20261108.py','*h5_older_cog_bounds*20261108.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_older_cog_bounds_checkpoint_20261108.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
total=front['complete_preparation_seconds_if_consumed'];copies=[];process_table=[]
for name in stage_names:
    folder=ROOT/'output'/('h5-'+name+'-20261108');assert load(folder/'audit/checks.json')['passed'];copies.extend([(folder/'plan.json',name+'-plan.json'),(folder/'audit/checks.json',name+'-audit.json'),(folder/'audit/case-results.json',name+'-cases.json')])
copies.extend([(ROOT/'output/h5-cog-hull-stock-20261108/hull-support.json','source-stock-hull-support.json'),(F/'remaining-cases.json','remaining-older-core-cases.json')])
for name,folder in zip(process_names,process_paths):
    r=load(folder/'process.json');assert r['passed'] and r['closed'] and r['job']['active_processes']==0;copies.append((folder/'process.json',name+'-process.json'));process_table.append({'stage':name,'seconds':r['complete_seconds'],'cap_seconds':r['job']['maximum_ms']/1000,'closed':True,'active_processes':0})
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'process-summary.json',process_table)
scopes=load(D/'remaining-core-scopes.json');frontier={f"t{r['turned_frames']}-{r['case']}":{'key':f"t{r['turned_frames']}-{r['case']}",'turned_frames':r['turned_frames'],'case':r['case'],'omitted_sites':r['omitted_sites'],'exact_first32_excluded':False,'source_fixed_first32':r['source_fixed_first32']} for r in scopes};assert len(frontier)==8
for name in stage_names:
    rows=load(ROOT/'output'/('h5-'+name+'-20261108')/'audit/case-results.json');assert {r['key'] for r in rows}=={k for k,v in frontier.items() if not v['exact_first32_excluded']}
    for r in rows:
        v=frontier[r['key']];v['remaining_continuous_center_cells']=r['remaining_center_cells']
        if r['exact_first32_excluded']:v['exact_first32_excluded']=True;v['first_excluding_stage']=name
assert sum(r['exact_first32_excluded'] for r in frontier.values())==5;write(OUT/'older-eight-core-frontier.json',list(frontier.values()))
runtime=load(PARENT/'runtime-bindings.json')
for n,h in runtime.items():assert n.startswith('.cache/') and digest(ROOT/n)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42528251097','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='916859b2bd967d63c005275aeb6149be11fb15cd' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs']);write(OUT/'main-ci-at-review.json',ci)
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'older_first32_initial_cases':8,'older_first32_cases_excluded':5,'older_first32_cases_remaining':3,'older_remaining_continuous_center_cells':3706,'closed_current_family_cases':680,'all_inherited_failures_preserved':True})
write(OUT/'next-step.json',{'status':'five_older_fixed_cores_excluded_three_remain','proposal':'Preserve the complete3706 continuous2.5mm cells for t3-omit-03-07 (2883), t3-omit-03-15 (580), and t3-omit-14-15 (243). These are necessary covers, not feasible source poses. Investigate additional original-source collision/support or coupled companion inventory bounds for these exact fixed worlds. The source hull support139mm may constrain convex stock and can underpin a separately proved support-point argument at sufficiently long frame edges, but is NOT a filled body disk and may never be used directly for collision or occupied area. A proposed finite-frame support proof must use the certified140.001mm outer radius to guarantee the source support vertex stays between the frame endpoints, then independently verify all continuous-cell witnesses. Repeated joint-area refinement alone cannot exclude omit-03-07: its495456.515617mm2 companion upper exceeds435979mm2 plus the entire50062.718938mm2 cog. No closed process/model may reopen. This lineage exceeds60seconds; any eventual timed constructor needs genuinely independent numeric recomputation from originals and a separate preflight.','remaining_cases':3,'remaining_continuous_center_cells':3706,'consumed_preparation_seconds':total,'optimizer_allowed_from_current_lineage':False,'earlier_arrangements_remaining':4,'whole_allocation_candidates_remaining':440,'optimizer_calls':0,'H5_complete':False})
rows=load(F/'case-results.json');table='\n'.join(f"| {r['key']} | {r['remaining_center_cells']:,} | {r['maximum_outside_cog_area_upper_um2']/1e6:.6f} |" for r in rows)
process_rows='\n'.join(f"| {r['stage']} | {r['seconds']:.6f} | {r['cap_seconds']:.0f} |" for r in process_table)
report=f'''# Five older fixed cog cores excluded — 2026-11-08

**Five of the eight older one-/three-turned exact first32 cores are now excluded.
Three remain, with complete continuous center covers containing 3,706 cells.**
All 680 cores in the separately recorded five-column family remain closed.
These results condition on the actual eighteen fixed frames and fourteen fixed
cogs; they exclude no whole allocation or orientation class. H2/H5 stay open at
**60% completed milestone weight**, and the valid64 result remains best.

[Fresh covers for both changed source worlds]({NAME}/eight-core-centers-plan.json)
partition the full stock into 2.5 mm cells. Each entire cell is either retained
or excluded by a necessary stock bound or a complete frame/cog collision witness.
They use frame bit16 and actual original source poses, without reusing the closed
seventeen-site masks. [Independent source readback]({NAME}/eight-core-centers-audit.json)
checks 144 frame rectangles, 112 cog assignments, 31 unique source poses and all
5,760,000 stock cells. Initially **76,511** center cells remain across eight cases.

[A stronger convex-stock support bound]({NAME}/source-stock-hull-support.json)
proves the original cog's convex hull contains a centered **139 mm** disk.
If the source cog fits rectangular stock, its convex hull fits too. This yields
a stronger necessary distance from every stock edge at every exact rigid angle.
[An independent half-plane proof]({NAME}/cog-hull-stock-audit.json) checks all
40 hull vertices and 3,200 original-point half-plane relations, then removes
**15,649** cells. The hull disk is used **only for convex-stock containment**;
it is not filled source material and supplies no collision or occupied-area disk.

[Actual tooth-vertex witnesses]({NAME}/eight-cog-vertices-plan.json) use the
certified **109 mm source inner disk** instead. If that disk strictly contains
any original fixed cog vertex, the filled source bodies overlap. Every actual
fixed-source vertex is enclosed by outward integer-micrometer intervals with
additional 1 µm padding. [Independent readback]({NAME}/eight-cog-vertices-audit.json)
checks all **8,960** vertex assignments and all sixteen corner-pair distances
for each excluded center cell. It removes **26,101** cells, leaving **34,761**.

[Full-body conservation in each changed world]({NAME}/eight-cog-complement-plan.json)
uses the entire source cog area lower **50,000 mm²** and source outer radius
**140.001 mm**. Let `U` be the complete bracket/insert component-envelope union
and `F` the mandatory fixed-source inner union. Companion bodies must fit in
`R = U minus F`. A valid cog is disjoint from `F`, so its area outside `R` is
bounded by its circular neighborhood in stock outside `U union F`. The remaining
cog area necessarily occupies `R` and reduces space available to companions.

Each continuous center cell gets a complete circular outer neighborhood, not
a sample center or chosen angle. [Independent direct stencil counting]({NAME}/eight-cog-complement-audit.json)
checks every fresh world-specific complement mask and all **34,761** queries.
It excludes **30,206** cells and five full cores: all four one-turned cases and
three-turned `omit-07-14`. The smallest deficit among these five is
**3,479.355659 mm²**. [All eight identities and first exclusion stages]({NAME}/older-eight-core-frontier.json)
reconcile with the original scope and source poses.

[Exact complement cell areas]({NAME}/three-cog-exact-complement-plan.json)
tighten the remaining three cases. A horizontal rectangle-union sweep replaces
whole-cell overestimates with exact integer areas. [The independent audit]({NAME}/three-cog-exact-complement-audit.json)
uses a vertical sweep with signed endpoint events, checking **2,160,000** cell
areas, then directly sums all **4,555** weighted circular neighborhoods. It
removes another **849** cells; all three cases remain unexcluded.

| Fixed core | Remaining continuous cells | Maximum cog area outside companion region (mm² upper) |
|---|---:|---:|
{table}

[The remaining covers]({NAME}/remaining-older-core-cases.json) are necessary
conditions, not feasible poses or layouts. Further joint-area refinement alone
cannot exclude `omit-03-07`: its companion-area upper exceeds the required
companion lower plus the entire cog body. [Next work]({NAME}/next-step.json)
must use additional source collision/support or coupled inventory constraints.

| Bounded stage | Complete process (s) | Process cap (s) |
|---|---:|---:|
{process_rows}

[All ten processes close]({NAME}/process-summary.json) with zero live children,
unchanged CCD1/thread controls and a 2 GiB Windows Job limit. The stock-hull
producer's actual wrapper cap was 40 s; that receipt governs rather than its
internal plan's 10 s description. Consumed preparation is **{total:.6f} s**,
including all inherited failed work. This exhausted numeric lineage cannot open
an optimizer or reset its timer. No timed H5 acceptance is claimed.

Four earlier arrangements and 440 whole-job allocations remain. Full66
source/native/material acceptance, product integration, parity and the H5 matrix
remain open. Product, README and release state are unchanged.

[All six checks on main916859b2 passed]({NAME}/main-ci-at-review.json).
This checkpoint and the preceding 680-core closure await the ordinary main push.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-08 H5 older cog-center bounds:** [complete changed-world source proofs]({{link}}) exclude five of eight older exact first32 cores and preserve three with3706 continuous2.5mm center cells. Fresh full-stock covers verify5760000 cells; original convex-hull stock support139mm removes15649, and actual source tooth vertices with the109mm moving inner disk remove26101. Full-body conservation against fresh companion-complement masks excludes30206 cells and five cores, minimum deficit3479.355659mm². Independent orthogonal signed-event sweeps verify2160000 exact complement cell areas and remove849 more center cells. Remaining: t3-omit-03-07 (2883), t3-omit-03-15 (580), t3-omit-14-15 (243). No whole allocation/class is excluded. All680 separately recorded current-family cores remain closed. Ten processes close; consumed preparation {total:.6f}s is already over60s and cannot reset or open an optimizer. Four earlier arrangements and440 allocations remain; valid64 stays best and H2/H5 stay open at60%. All six prior main916859b2 CI checks pass; the two evidence checkpoints await ordinary push. Product and releases unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';content=p.read_text(encoding='utf-8');a=content.index('Latest H5 evidence:');b=content.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [older cog-center bounds](../benchmarks/results/{NAME}.md).
Five of eight older exact first32 cores are now excluded at all source cog angles.
Three remain with complete continuous covers: t3-omit-03-07 (2,883 cells),
t3-omit-03-15 (580), and t3-omit-14-15 (243). Source stock support, actual tooth
vertices, full-body conservation and independently verified exact complement
cell areas tighten these changed framebit16 worlds. The hull support disk is
used only for convex-stock containment, never as filled collision material.
All 680 separately recorded five-column family cores remain closed.
No whole allocation or orientation class is excluded. These covers are necessary
conditions, not feasible layouts. All ten bounded processes close; consumed
preparation is {total:.6f} s. No optimizer or timer reset is permitted.
Four earlier arrangements and 440 whole-job allocations remain; valid64 stays
best, H2/H5 stay open at 60%. All six prior main916859b2 checks passed; this and
the preceding closure checkpoint await the ordinary push gate.
Product and releases are unchanged.
'''
p.write_text(content[:a]+intro+content[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings),'consumed_preparation_seconds':total,'older_fixed_cores_excluded':5,'older_fixed_cores_remaining':3})
