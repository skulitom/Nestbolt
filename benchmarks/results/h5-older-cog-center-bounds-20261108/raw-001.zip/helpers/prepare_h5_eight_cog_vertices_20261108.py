"""Complete tooth-vertex collision witnesses against a moving source inner disk."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-eight-cog-vertices-20261108';OLD=ROOT/'output/h5-cog-hull-stock-20261108';CENTERS=ROOT/'output/h5-eight-core-centers-20261108';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';G=ROOT/'output/h5-free-cog-geometry-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/remaining-cases.json');assert len(cases)==8 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),JOB,OLD/'audit/checks.json',OLD/'audit/remaining-cases.json',OLD/'hull-support.json',CENTERS/'geometries.json',CENTERS/'audit/checks.json',G/'geometry.json',G/'audit/checks.json']+[OLD/(r['key']+'.npz') for r in cases]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'At every exact rigid angle the moving original cog contains its centered109mm disk. If that disk strictly contains any actual fixed source-cog outer vertex, the two source bodies overlap: a filled simple polygon has positive interior area arbitrarily near its vertex. Reconstruct all80 original vertices of each actual fixed cog, with outward integer-micrometer intervals plus1um padding. Remove a continuous center cell only when all corners of its stock-clipped closure are less than109mm from all corners of a fixed-vertex interval. Retain every other cell. The139mm hull support is used ONLY to clip the necessary stock-center domain, never for collision or occupied area.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
part=next(p for p in load(JOB)['parts'] if p['id']=='cog');assert len(part['geometry'][0]['outer'])==80;assert load(G/'geometry.json')['exact_rigid_area_lower_mm2']==50000;domain=load(OLD/'hull-support.json')['necessary_stock_center_domain_um'];geometries={r['key']:r for r in load(CENTERS/'geometries.json')};results=[];vertices=[];cache={};h=2500
for case in cases:
    key=case['key'];geometry=geometries[key];fixed=[]
    for row in geometry['source_fixed_first32']:
        if row['part_id']!='cog':continue
        t=row['transform'];posekey=json.dumps(t,sort_keys=True)
        if posekey not in cache:
            assert not t['mirrored'];c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));tx,ty=map(Q,t['translation']);posed=[(Q(x)*c-Q(y)*s+tx,Q(x)*s+Q(y)*c+ty) for x,y in part['geometry'][0]['outer']];cache[posekey]=[[math.floor(z*1000)-1 for z in p]+[math.ceil(z*1000)+1 for z in p] for p in posed]
        for i,interval in enumerate(cache[posekey]):fixed.append({'copy_index':row['copy_index'],'vertex':i,'interval_um':interval})
    assert len(fixed)==1120
    with np.load(OLD/(key+'.npz'),allow_pickle=False) as z:old=z['remaining_center_cells'];ys,xs=np.nonzero(old)
    l=np.maximum(xs*h,domain[0]);r=np.minimum((xs+1)*h,domain[2]);b=np.maximum(ys*h,domain[1]);u=np.minimum((ys+1)*h,domain[3]);witness=np.full(len(xs),-1,dtype=np.int16)
    for i,vertex in enumerate(fixed):
        a,c,d,e=vertex['interval_um'];dx=np.maximum(np.abs(l-d),np.abs(r-a));dy=np.maximum(np.abs(b-e),np.abs(u-c));bad=(witness<0)&(dx*dx+dy*dy<109000**2);witness[bad]=i
    remaining=old.copy();remaining[ys,xs]=witness<0;np.savez_compressed(OUT/(key+'.npz'),source_y=ys,source_x=xs,vertex_witness=witness,remaining_center_cells=remaining);vertices.append({'key':key,'fixed_source_vertex_intervals':fixed});results.append({'key':key,'turned_frames':case['turned_frames'],'case':case['case'],'input_center_cells':len(xs),'vertex_collision_cells_excluded':int((witness>=0).sum()),'remaining_center_cells':int((witness<0).sum()),'provisional_exact_first32_excluded':not bool((witness<0).any())})
write(OUT/'vertices.json',vertices);write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':8,'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
