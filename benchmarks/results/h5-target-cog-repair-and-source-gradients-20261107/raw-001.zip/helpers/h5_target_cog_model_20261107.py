"""Fixed physical pose model: cog2 at7.25degrees, every translation free."""
from pathlib import Path
from fractions import Fraction as F
import copy,json
import numpy as np
from h5_cog_physical_union_distance_v2_20261107 import Objective
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-target-cog-model-20261107';T=ROOT/'output/h5-target-cog-source-20261107';M=ROOT/'output/h5-mixed-mode-union-20261107'
load=lambda p:json.loads(p.read_bytes())

def pack():
    with np.load(M/'search/round-00/selected-arrays.npz',allow_pickle=False) as z:a={k:z[k].copy() for k in z.files}
    meta=load(M/'search/round-00/selected-mapping.json');affected=load(T/'affected-pairs.json');ids={p['pair'] for p in affected};templates=load(T/'templates.json')
    offset=max(i for g in meta['groups'] for i in g['source_region_indices'])+1
    for g in meta['groups']:
        keep=np.array([i not in ids for i in g['pairs']]);pre=f'g{g["group"]}_'
        for k in ['owners','matrix','offset']:a[pre+k]=a[pre+k][keep]
        g['pairs']=[p for p,ok in zip(g['pairs'],keep) if ok]
    for t in templates:
        gi=t['template']+4;rr=t['regions'];nv=max(len(r['vertices_mm']) for r in rr);n=len(rr);starts=np.zeros((n,nv,2));ends=starts.copy();valid=np.zeros((n,nv),dtype=bool);normals=starts.copy();upper=np.full((n,nv),np.inf)
        for ri,r in enumerate(rr):
            v=[tuple(map(F,p)) for p in r['vertices_mm']];count=len(v);xy=np.asarray(v,dtype=float);starts[ri,:count]=xy;ends[ri,:count]=np.roll(xy,-1,axis=0);valid[ri,:count]=True
            for j,(p,q) in enumerate(zip(v,v[1:]+v[:1])):
                nx,ny=q[1]-p[1],p[0]-q[0];length=np.hypot(float(nx),float(ny));assert length>0;normals[ri,j]=[float(nx)/length,float(ny)/length];upper[ri,j]=float(nx*p[0]+ny*p[1])/length
        pairs=[p for p in affected if p['template']==t['template']];pre=f'g{gi}_'
        a.update({pre+'starts':starts,pre+'ends':ends,pre+'valid':valid,pre+'normals':normals,pre+'upper':upper,pre+'owners':np.array([p['ordered_owners'] for p in pairs],dtype=np.int64),pre+'matrix':np.tile(np.eye(2),(len(pairs),1,1)),pre+'offset':np.zeros((len(pairs),2))})
        meta['groups'].append({'group':gi,'class':'target_cog_direct','source_namespace':'target7.25-original-source','source_template':t['template'],'source_region_indices':list(range(offset,offset+n)),'source_region_signs':[1]*n,'pairs':[p['pair'] for p in pairs]});offset+=n
    meta['owners']=load(T/'owners.json');a['bounds']=np.asarray([b for o in meta['owners'] for b in o['position_bounds_grid']],dtype=float)/100;a['initial']=np.asarray(load(T/'initial-values-mm.json'))
    assert np.all(a['initial']>=a['bounds'][:,0]) and np.all(a['initial']<=a['bounds'][:,1])
    return a,meta

def readback(a,meta,old,oldmeta,owners,values,templates,affected):
    """Independently enumerate retained and direct rows, vertices and padding."""
    assert meta['owners']==owners and len(owners)==28
    assert a['initial'].tolist()==values and a['bounds'].tolist()==[[x/100 for x in b] for o in owners for b in o['position_bounds_grid']]
    assert np.all(a['initial']>=a['bounds'][:,0]) and np.all(a['initial']<=a['bounds'][:,1])
    keys={'initial','bounds'};ids={p['pair'] for p in affected};covered=[];expected_groups=[]
    for k in ['orth_axis','orth_positive','orth_negative','orth_upper']:
        assert np.array_equal(a[k],old[k]) and a[k].shape==(268,4);keys.add(k)
    for g in oldmeta['groups']:
        pre=f'g{g["group"]}_';indices=[i for i,p in enumerate(g['pairs']) if p not in ids];expected=copy.deepcopy(g);expected['pairs']=[g['pairs'][i] for i in indices];expected_groups.append(expected);covered+=expected['pairs']
        for k in ['starts','ends','valid','normals','upper']:assert np.array_equal(a[pre+k],old[pre+k]);keys.add(pre+k)
        for k in ['owners','matrix','offset']:assert np.array_equal(a[pre+k],old[pre+k][indices]);keys.add(pre+k)
    offset=max(i for g in oldmeta['groups'] for i in g['source_region_indices'])+1
    for t in templates:
        gi=t['template']+4;pre=f'g{gi}_';rr=t['regions'];nv=max(len(r['vertices_mm']) for r in rr);n=len(rr);pp=[p for p in affected if p['template']==t['template']]
        expected_groups.append({'group':gi,'class':'target_cog_direct','source_namespace':'target7.25-original-source','source_template':t['template'],'source_region_indices':list(range(offset,offset+n)),'source_region_signs':[1]*n,'pairs':[p['pair'] for p in pp]});offset+=n;covered.extend(p['pair'] for p in pp)
        assert a[pre+'owners'].tolist()==[p['ordered_owners'] for p in pp] and np.array_equal(a[pre+'matrix'],np.tile(np.eye(2),(len(pp),1,1))) and np.array_equal(a[pre+'offset'],np.zeros((len(pp),2)))
        for k in ['starts','ends','normals']:assert a[pre+k].shape==(n,nv,2)
        for k in ['valid','upper']:assert a[pre+k].shape==(n,nv)
        for ri,r in enumerate(rr):
            v=[tuple(map(F,p)) for p in r['vertices_mm']];count=len(v);expected=np.array(v,dtype=float)
            assert np.array_equal(a[pre+'starts'][ri,:count],expected) and np.array_equal(a[pre+'ends'][ri,:count],expected[list(range(1,count))+[0]])
            assert a[pre+'valid'][ri].tolist()==[True]*count+[False]*(nv-count)
            for k in ['starts','ends','normals']:assert np.all(a[pre+k][ri,count:]==0)
            assert np.all(np.isposinf(a[pre+'upper'][ri,count:]))
            for j,(p,q) in enumerate(zip(v,v[1:]+v[:1])):
                nx,ny=q[1]-p[1],p[0]-q[0];length=np.hypot(float(nx),float(ny))
                assert a[pre+'normals'][ri,j].tolist()==[float(nx)/length,float(ny)/length] and a[pre+'upper'][ri,j]==float(nx*p[0]+ny*p[1])/length
        keys.update(pre+k for k in ['owners','matrix','offset','starts','ends','normals','valid','upper'])
    assert meta['groups']==expected_groups and sorted(covered)==list(range(258)) and set(a)==keys
    return True

def source_rows(meta,values,fixed):
    rows=list(fixed)
    for o in meta['owners']:
        i=o['owner'];rows.append({'part_id':o['identity'][0],'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':o['rotation_radians'],'mirrored':o['mirrored'],'translation':[float(values[2*i+k])+[0,2100][k]+o['translation_from_lower_left'][k] for k in [0,1]]}})
    return rows
