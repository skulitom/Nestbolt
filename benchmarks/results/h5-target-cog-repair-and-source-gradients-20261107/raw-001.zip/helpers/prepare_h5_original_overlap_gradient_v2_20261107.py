"""Preserve initial shared-edge failure; version a symmetric central convention."""
from pathlib import Path
from hashlib import sha256
import json
R=Path(__file__).resolve().parents[1];kernel=R/'output/h5_original_overlap_gradient_20261107.py';audit=R/'output/audit_h5_original_overlap_gradient_20261107.py';newkernel=R/'output/h5_original_overlap_gradient_v2_20261107.py';newaudit=R/'output/audit_h5_original_overlap_gradient_v2_20261107.py'
s=kernel.read_text();old="""        for segment in line_parts(line.intersection(b)):
            values=[float((np.asarray(x)-p)@edge/den) for x in segment.coords];lo=max(0.,min(values));hi=min(1.,max(values))
            if hi<=lo:continue
            d=(hi-lo)*edge;normal=np.array([d[1],-d[0]]);mid=np.asarray(p)+(hi+lo)/2*edge;relative=mid-pivot;gradient[:2]+=normal;gradient[2]+=float(np.array([-relative[1],relative[0]])@normal);segments+=1
""";new="""        # Shared boundary contributes half of the two one-sided conventions.
        # This matches symmetric coordinate differences, not a smooth derivative.
        for geometry,weight in [(line.intersection(b),1.),(line.intersection(b.boundary),-.5)]:
            for segment in line_parts(geometry):
                values=[float((np.asarray(x)-p)@edge/den) for x in segment.coords];lo=max(0.,min(values));hi=min(1.,max(values))
                if hi<=lo:continue
                d=weight*(hi-lo)*edge;normal=np.array([d[1],-d[0]]);mid=np.asarray(p)+(hi+lo)/2*edge;relative=mid-pivot;gradient[:2]+=normal;gradient[2]+=float(np.array([-relative[1],relative[0]])@normal);segments+=weight==1.
"""
assert s.count(old)==1;s=s.replace(old,new);s=s.replace('This is a heuristic overlap objective, not a clearance/stock validity test.','At shared boundaries a half-weight symmetric convention is used and reported.\n+It is not a unique classical derivative and requires directional controls.\n+This is a heuristic overlap objective, not a clearance/stock validity test.')
with newkernel.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=audit.read_text().replace('h5_original_overlap_gradient_20261107','h5_original_overlap_gradient_v2_20261107').replace('h5-original-overlap-gradient-20261107','h5-original-overlap-gradient-v2-20261107')
s=s.replace("metadata['coincident_boundary_length_mm']<1e-8", "metadata['coincident_boundary_length_mm']>0")
s=s.replace('Verify analytic rigid translation/rotation derivatives of actual filled-original-outline overlap by clipped boundary integration.', 'Verify rigid translation/rotation boundary gradients of actual filled-original-outline overlap. Shared edges use an explicitly nonsmooth half-weight symmetric convention,checked against central differences; this is not a unique classical derivative.')
s=s.replace("'analytic':float(gradient[coordinate])", "'symmetric_boundary_gradient':float(gradient[coordinate])")
s=s.replace("'translation_derivatives':56,'angular_derivatives':12", "'translation_central_comparisons':56,'angular_central_comparisons':12,'shared_boundary_pairs':2,'unique_classical_derivative_claimed':False")
s=s.replace("inputs=[Path(__file__),", "inputs=[RFILE for RFILE in [ROOT/'output/h5-original-overlap-gradient-20261107/plan.json',ROOT/'output/h5-original-overlap-gradient-process-20261107/process.json',ROOT/'output/h5-original-overlap-shared-edges-20261107/checks.json']]+[Path(__file__),")
with newaudit.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
source=R/'output/run_h5_original_overlap_gradient_20261107.py';newrunner=R/'output/run_h5_original_overlap_gradient_v2_20261107.py'
with newrunner.open('x',encoding='utf-8',newline='\n') as f:f.write(source.read_text().replace('h5-original-overlap-gradient-process-20261107','h5-original-overlap-gradient-v2-process-20261107').replace('audit_h5_original_overlap_gradient_20261107.py','audit_h5_original_overlap_gradient_v2_20261107.py'))
record={'reason':'The original candidate has two pairs with coincident source edges,total double-counted shared boundary length12.23882732053562mm. The original smoothness assertion correctly failed before derivative controls. Preserve all bytes; a new kernel explicitly uses half-weight shared segments for symmetric central differences and reports nonsmoothness. No optimizer/model preparation was opened or repeated.','inputs':{p.relative_to(R).as_posix():sha256(p.read_bytes()).hexdigest() for p in [kernel,audit,newkernel,newaudit,newrunner,R/'output/h5-original-overlap-gradient-process-20261107/process.json',R/'output/h5-original-overlap-shared-edges-20261107/checks.json']},'source_model_changed':False,'source_candidate_changed':False,'optimizer_calls':0,'unique_classical_derivative_claimed':False}
with (R/'output/h5-original-overlap-gradient-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
