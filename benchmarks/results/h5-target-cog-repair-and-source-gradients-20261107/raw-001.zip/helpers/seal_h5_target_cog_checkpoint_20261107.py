"""Seal focused repair, original-source failure and direct overlap controls."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
replacements={"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-target-cog-repair-and-source-gradients-20261107'","BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-target-cog-model-20261107';F=ROOT/'output/h5-target-cog-checkpoint-20261107';D=ROOT/'output/h5-original-overlap-gradient-v2-20261107'","PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-two-phase-geometry-and-angular-variations-20261107'","folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,F,D]+[ROOT/'output'/n for n in ['h5-target-cog-source-20261107','h5-target-cog-source-process-20261107','h5-target-cog-model-process-20261107','h5-target-cog-response-audit-process-20261107','h5-original-overlap-gradient-20261107','h5-original-overlap-shared-edges-20261107','h5-original-overlap-gradient-process-20261107','h5-original-overlap-gradient-v2-process-20261107','h5-two-phase-main-sync-20261107']]","['*h5*mixed*mode*20261107.py']":"['*h5*target*cog*20261107.py','*h5*original*overlap*20261107.py']","'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_target_cog_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"}
for old,new in replacements.items():assert old in prefix,old;prefix=prefix.replace(old,new)
needle="for name,h in load(F/'source-bindings.json').items():";assert needle in prefix
prefix=prefix.replace(needle,"for n in ['h5-target-cog-search-preparation-20261107.json','h5-original-overlap-gradient-correction-20261107.json']:add('corrections-and-preflight/'+n,ROOT/'output'/n)\n"+needle)
exec(prefix)
T=ROOT/'output/h5-target-cog-source-20261107'
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(T/'audit/checks.json','source-geometry-audit.json'),(ROOT/'output/h5-target-cog-source-process-20261107/process.json','source-process.json'),(BASE/'audit/checks.json','model-audit.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(BASE/'audit/target-pair-derivatives.json','target-pair-controls.json'),(ROOT/'output/h5-target-cog-model-process-20261107/process.json','model-process.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/collision-details.json','source-failures.json'),(BASE/'search/process.json','closed-repair-process.json'),(D/'checks.json','direct-gradient-audit.json'),(D/'derivative-controls.json','direct-gradient-controls.json'),(D/'objective-disagreement.json','objective-disagreement.json'),(ROOT/'output/h5-original-overlap-gradient-correction-20261107.json','gradient-correction.json'),(ROOT/'output/h5-original-overlap-shared-edges-20261107/shared-pairs.json','shared-edge-pairs.json'),(ROOT/'output/h5-original-overlap-gradient-process-20261107/process.json','failed-gradient-audit-process.json'),(ROOT/'output/h5-original-overlap-gradient-v2-process-20261107/process.json','corrected-gradient-audit-process.json'),(ROOT/'output/h5-two-phase-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Focused cog repair and original overlap gradients — 2026-11-07

The new, independently certified cog-2 rotation repair closes with **39
overlapping original pairs and no stock failures**. Its distance penalty falls
slightly, but actual summed original overlap increases by **24.569391 mm²**.
The result remains invalid and the call stays closed. A separate direct
original-outline gradient kernel now passes **68 coordinate controls**, with
explicit handling of two nonsmooth shared-edge pairs. A new continuous pose
model still needs clearance, stock and directional controls before any call.
H2/H5 remain open at **60% completed milestone weight**; four fixed arrangements
and 440 whole allocations remain. No exclusion or release follows.

## New source geometry and complete model

[Independent source readback]({NAME}/source-geometry-audit.json) proves seven
new interaction templates for original cog 2 at **7.25°**, against the seven
other selected poses. All **27 affected original pairs** use explicit ordered
owner couplings, including reversal of the original owner pair [16,17].
All **627 retained regions and 9,961 exact rational source supports** pass.
The minimum certified source gap is **0.225999998 mm**. No symmetry assumption
is substituted for the mixed-angle pair geometry.

The audit independently reconstructs original convex partitions, all source
poses, hard stock bounds and relative domains. Its 18 positive source cases
cover **8,898 pairs, 2,864 stock edges, 872 holes and 73,924 hole vertices**.
The selected full66 seed exactly reproduces the earlier angular probe and
remains invalid with39 pair failures. [Complete source preparation]({NAME}/source-process.json)
takes **2.553191 s**; its separate audit takes **4.124464 s**. Both process trees
close normally.

[The complete model audit]({NAME}/model-audit.json) retains every unaffected
**231 cog interaction and 268 orthogonal component interaction** byte for byte,
and substitutes all27 newly certified couplings. Every original pair ID occurs
exactly once. All28 translations remain independently free; only cog2's
selected physical rotation changes. Fresh region identifiers are disjoint
from retained identifiers, and all direct couplings use their actual owners.

Controls verify **1,254 exact rational projections**, 168 full-objective
derivatives and [54 target-pair derivatives]({NAME}/target-pair-controls.json),
including the reversed pair. All [nine deliberately corrupted copies]({NAME}/negative-controls.json)
are rejected. Original seed replay and pinned SciPy tool hashes pass.
[Model preparation/audit]({NAME}/model-process.json) take **0.336995 / 3.243953 s**.
A draft PowerShell quoting error occurred before any wrapper or preparation
executed; it is recorded in the helper-preparation provenance. No model or
optimizer was repeated.

## Closed repair and independent full-source replay

One L-BFGS-B call is frozen for this never-optimized physical mode vector,
with the existing 60/90-second and2GiB caps and four-second source reserve.
Its allocated slice is **10.358150 s**; it returns after **0.169260 s**.
[Response replay]({NAME}/response-audit.json) checks **20 improving records,
21 evaluations and18 iterations**, all258 cog terms and268 component terms.
Numerical convergence is preserved as a numerical result only.

The best distance penalty changes from **16,523.673066 to16,523.194675 mm²**.
Independent reconstruction checks all **66 originals,1,632 same-sheet pairs,
264 stock edges,90 holes and10,026 hole vertices**. All39 failing pairs have
positive overlap; no stock edge fails. [Their original-source details]({NAME}/source-failures.json)
remain preserved. No native validator or LightBurn check is invoked for this
invalid candidate.

Complete charged preparation is **44.925865 s**, including the complete prior
candidate/angular-probe lineage and both new preparations. Algorithm/shared
totals are **45.907375 /45.975123 s**, with no overrun. [All five processes
close]({NAME}/closed-repair-process.json); peak committed memory is
**95,109,120 bytes**. No restart, reseed or extension is permitted.

## Direct original-outline gradient controls

[The measured objective disagreement]({NAME}/objective-disagreement.json)
compares this exact seed/result: actual summed pairwise overlap rises from
**41,077.609274 to41,102.178665 mm²** while the distance penalty falls by
**0.478391 mm²**. Pairwise areas can double-count. This local result shows that
the model's improving direction need not improve actual overlap; it is not a
global statement about either objective or any allocation.

The new kernel integrates rigid boundary velocity over each original outer
edge segment lying inside the other filled original. Filled outers preserve
the noPIH rule; holes remain unchanged in source output and validation.
For a directed segment, outward-normal times length is (dy,-dx); a rigid
rotation's velocity is linear, so its midpoint integrates the segment exactly.
This is a heuristic area gradient, not a clearance or stock proof.

[The original audit fails its smoothness assertion]({NAME}/failed-gradient-audit-process.json)
before numerical derivative controls. [Two actual source pairs]({NAME}/shared-edge-pairs.json)
have coincident boundaries, with **12.238827 mm** summed shared length counted
once for each owner. The failure and original helper bytes are preserved.
[The versioned correction]({NAME}/gradient-correction.json) explicitly
half-weights shared segments and reports nonsmoothness. It claims a symmetric
central convention, **not a unique classical derivative**.

[The corrected independent audit]({NAME}/direct-gradient-audit.json) compares
[56 translation and12 legal cog-angle central differences]({NAME}/direct-gradient-controls.json)
against separately transformed original source polygons, with maximum
absolute discrepancy **0.000011096** in the relevant area-per-coordinate
units. Five synthetic controls cover partial overlap, reversed ring direction,
strict containment, disjoint shapes and coincident boundaries. The corrected
audit takes **0.514220 s** including its [closed process]({NAME}/corrected-gradient-audit-process.json).
This verification does not prepare or authorize an unaudited search model.

## Next work and publication state

[The next task]({NAME}/next-step.json) is a distinct continuous original-outline
pose model with28 independent translations and12 permitted cog angles.
It must define and independently check clearance/contact behavior, stock/core
handling, pose scaling, nonsmooth directional behavior and every coupling.
The complete consumed candidate charge is **45.975123 s** before new algorithm
preparation and runtime. Verification outputs are not free algorithm data.
Every returned candidate still needs full66 source validation before native,
material, H5-matrix or production-parity claims. All closed calls remain closed.

The [previous two checkpoints reached main9118d6cb]({NAME}/prior-main-push-receipt.json)
normally after all six prior-main CI jobs passed, preserving52 remote files.
Its [current CI snapshot]({NAME}/main-ci-at-review.json) has four successful
jobs and two native jobs still running; no live run was cancelled. This new
checkpoint will use the same ordinary fast-forward gate after CI completes.
Production code, README and releases remain unchanged.

[Raw evidence]({NAME}/raw-manifest.json) contains {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes.
[Historical references]({NAME}/external-evidence.json) and [input bindings]({NAME}/source-bindings.json)
retain the complete consumed lineage and all failures. Independent archive
readback is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 focused cog repair and direct source gradients:** [independent source/model/response audits]({link}) verify seven new source templates,627 regions,9,961 exact supports and all27 affected original pairs,including one reversed owner pair. The other231 cog interactions and268 component terms remain unchanged. Model controls pass1,254 exact projections,222 derivatives and nine corruption checks. The sole new fixed7.25-degree call converges numerically after21 evaluations,but all66-original replay still finds39 overlaps and no stock failures. Algorithm/shared totals are45.907375/45.975123 s including44.925865 s preparation; all processes close with no overrun. The model penalty falls0.478391 mm² while actual summed overlap increases24.569391 mm². A new direct original-outline boundary kernel passes68 central-coordinate comparisons after a preserved smoothness failure identifies two shared-edge pairs; its explicit symmetric convention does not claim a unique derivative there. Next prepare clearance,stock and directional controls for a distinct continuous-angle original-outline model; no new model or call is opened. Four fixed arrangements and440 allocations remain,H2/H5 stay open at60%,and every closed call stays closed. Main9118d6cb retains four passed CI jobs and two live native jobs at review. Production,README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
path=ROOT/'docs/STATUS.md';s=path.read_text(encoding='utf-8');begin=s.index('Latest H5 evidence:');end=s.index('\nThe earlier fixed 13-cog construction',begin)
intro=f'''Latest H5 evidence: [focused cog repair and direct source gradients](../benchmarks/results/{NAME}.md).
The fresh7.25° cog geometry and complete translation model pass independent
source,projection,derivative and corruption controls. Its sole bounded repair
still fails39 original pairs,with all stock edges passing. Numerical convergence
does not establish a valid layout. Complete algorithm/shared totals are
45.907375/45.975123 s,with no overrun and all processes closed.
The model penalty decreases while actual overlap increases24.569391 mm².
A new original-outline boundary kernel passes56 translation and12 angular
central comparisons; two shared-edge pairs require an explicitly nonsmooth
symmetric convention. The initial failed smoothness audit remains preserved.
Next build and audit clearance,stock and directional behavior for a distinct
continuous-angle pose model. No such model or optimizer is opened yet.
Four fixed arrangements and440 allocations remain; H2/H5 stay open at60%.
Full source/native/material validation,production parity and the unchanged
H5 matrix remain required. Prior checkpoints reached main9118d6cb normally,
preserving52 remote files. Four current CI jobs pass; two native jobs are live
at review. The next ordinary push waits for completion. No release qualifies.
'''
path.write_text(s[:begin]+intro+s[end:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
