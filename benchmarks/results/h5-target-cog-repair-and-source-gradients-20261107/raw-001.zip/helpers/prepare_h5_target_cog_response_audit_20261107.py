"""Derive a new replay auditor from known pure audit mechanics; no old call."""
from pathlib import Path
R=Path(__file__).resolve().parents[1];src=R/'output/audit_h5_cog_physical_union_distance_v2_response_20261107.py';dst=R/'output/audit_h5_target_cog_response_20261107.py';s=src.read_text()
s=s.replace('h5-cog-physical-union-distance-v2-20261107','h5-target-cog-model-20261107').replace('h5-cog-physical-union-distance-v2-preparation-process-20261107','h5-target-cog-model-process-20261107')
s=s.replace("assert len(incumbents)==r['incumbents']==43 and r['evaluations']==45 and r['numerical_result']['iterations']==42", "assert len(incumbents)==r['incumbents']>0 and r['evaluations']==21 and r['numerical_result']['iterations']==18")
s=s.replace("<=45 and np.all", "<=21 and np.all").replace("source['pair_failures']==38", "source['pair_failures']==39")
s=s.replace("'improving_points_verified':43,'function_evaluations':45,'iterations':42,'initial_objective_mm2':controls['initial_source_objective']", "'improving_points_verified':len(incumbents),'function_evaluations':21,'iterations':18,'initial_objective_mm2':load(BASE/'audit/checks.json')['initial_objective_mm2']")
s=s.replace("'source_pair_failures':38", "'source_pair_failures':39")
old='Replay all43 strictly improving objective/gradient records, the best model distances and fixed original modes/stock bounds, then independently reconstruct/recheck all66 actual source contours. Reconcile one corrected physical-union optimizer call,45evaluations,42iterations, complete input charges, caps and process closure. Preserve convergence as a numerical event only: the best candidate still fails38 source pairs and excludes no larger domain.'
new='Replay every strictly improving objective/gradient record,all258pair distances and268orthogonal terms,then independently reconstruct/recheck all66original contours including cog2 at7.25degrees. Reconcile one new fixed-vector call,21evaluations,18iterations,complete preparation charges,caps and descendant closure. Preserve convergence as numerical only:the candidate still fails39source pairs and excludes no allocation. No source optimizer is repeated.'
assert old in s;s=s.replace(old,new)
needle="inputs=[Path(__file__),"
insert="assert charges['complete_original_candidate_and_angular_probe']==load(ROOT/'output/h5-target-cog-source-20261107/plan.json')['complete_consumed_candidate_and_probe_seconds']\nassert charges['complete_new_target_source_preparation']==load(ROOT/'output/h5-target-cog-source-process-20261107/prepare.json')['complete_seconds']\nassert charges['complete_new_array_preparation']==load(ROOT/'output/h5-target-cog-model-process-20261107/prepare.json')['complete_seconds']\nassert meta['owners']==load(ROOT/'output/h5-target-cog-source-20261107/owners.json')\n"
assert needle in s;s=s.replace(needle,insert+needle)
with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
