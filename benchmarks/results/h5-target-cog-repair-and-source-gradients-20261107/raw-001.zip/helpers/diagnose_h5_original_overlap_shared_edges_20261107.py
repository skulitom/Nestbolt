from pathlib import Path
from hashlib import sha256
import json
from h5_original_overlap_gradient_20261107 import original_area_and_gradient
R=Path(__file__).resolve().parents[1];B=R/'output/h5-target-cog-model-20261107';O=R/'output/h5-original-overlap-shared-edges-20261107';O.mkdir();load=lambda p:json.loads(p.read_bytes());job=R/'output/h5-coordinated-placement-selection-20261018/job.json';rows=load(B/'search/candidate-source66.json');moving=[tuple(o['identity']) for o in load(B/'mapping.json')['owners']];angular=[k for k in moving if k[0]=='cog'];energy,g,records,meta=original_area_and_gradient(load(job),rows,moving,angular);shared=[r for r in records if any(d['coincident_boundary_length_mm']>1e-8 for d in r['derivatives'])]
for name,data in [('shared-pairs.json',shared),('checks.json',{'passed':True,'area_mm2':energy,'overlap_pairs':len(records),'shared_boundary_pairs':len(shared),**meta,'original_audit_expected_smooth':False,'original_failure_preserved':True,'optimizer_calls':0})]:
    with (O/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(data,f,indent=2);f.write('\n')
print(load(O/'checks.json'))
