"""Fresh exact-source interaction regions for original cog2 at7.25degrees."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil,copy
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import hull,merge_exact,area
from h5_two_phase_source_tools_20261107 import affine,exterior,nfp,support
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-target-cog-source-20261107';M=ROOT/'output/h5-mixed-mode-union-20261107';A=ROOT/'output/h5-original-cog-angular-variations-20261107';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(M/'response-audit/checks.json')['passed'] and load(A/'audit/checks.json')['passed']
inputs=[Path(__file__),ROOT/'output/h5_two_phase_source_tools_20261107.py',ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,PIECES,ROOT/'output/h5-two-phase-checkpoint-20261107/next-step.json']+[M/n for n in ['search/result.json','search/process.json','search/round-00/selected-arrays.npz','search/round-00/selected-mapping.json','library.json','response-audit/plan.json','response-audit/checks.json']]+[A/n for n in ['plan.json','probe-modes.json','best-local-variation.json','03-source66.json','03-checks.json','audit/plan.json','audit/checks.json']]+[FIRST/n for n in ['plan.json','fixed29.json','short9-source.json']]+[I/'inventory.json',ROOT/'output/h5-original-cog-angular-variations-process-20261107/process.json']
charge=load(M/'search/process.json')['seconds_including_preparation']+load(ROOT/'output/h5-original-cog-angular-variations-process-20261107/process.json')['complete_seconds']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Change only original cog2 selected source phase to7.25degrees,as chosen by the frozen actual-source angular diagnostic. Retain every other selected physical mode. Prepare seven new direct source templates with targetowner17 asA and each distinct other selected pose asB,over full signed relative hard-stock domains. Source-certify every retained rounded convex region using exact rational support separation against original convex pieces. All27 affected interactions are explicitly mapped,including reversed original cogowner order. No reflection shortcut or all7degree/7-16degree solve is reused. Unaffected231coginteractions and268orthocomponentpairs remain required. All28originaltranslations remain free for a future one-call repair.',
    'target_owner':17,'target_identity':['cog',2],'target_degrees':7.25,'world_origin_mm':[0,2100],'certified_gap_mm':'.225','square_halfwidth_mm':.226,'stock_reserve_mm':'.025','inward_reserve_mm':'.000001','preparation_target_seconds':10,'complete_process_cap_seconds':12,'independent_audit_cap_seconds':90,'complete_consumed_candidate_and_probe_seconds':charge,'future_algorithm_seconds':60,'future_shared_seconds':90,'source_reserve_seconds':4,'memory_bytes':2**31,'future_optimizer_calls':1,'retry_permitted':False,'optimizer_calls':0})
job=load(JOB);parts={p['id']:p for p in job['parts']};canonical=load(PIECES);spec=load(FIRST/'plan.json');fixed=load(FIRST/'fixed29.json');short=load(FIRST/'short9-source.json');old=load(M/'search/round-00/selected-mapping.json');owners=copy.deepcopy(old['owners']);best=load(A/'best-local-variation.json');seed=load(A/best['source_file']);probe=next(m for m in load(A/'probe-modes.json') if m['angle_degrees']==7.25);assert best['owner']==17 and best['identity']==['cog',2]
target=owners[17];target.update({'mode':1,'rotation_radians':probe['rotation_radians'],'mirrored':False,'translation_from_lower_left':probe['translation_from_lower_left']})
stock=list(map(F,spec['construction_stock']));safe=[stock[0]+F(1,40),stock[1]+F(1,40),stock[2]-F(1,40),stock[3]-F(1,40)];eps=F(1,1000000)
outer=affine(parts['cog']['geometry'][0]['outer'],target);bounds=[min(v[k] for v in outer) for k in [0,1]]+[max(v[k] for v in outer) for k in [0,1]];world=[[math.ceil((safe[k]-bounds[k]+eps)*100),math.floor((safe[k+2]-bounds[k+2]-eps)*100)] for k in [0,1]]
assert world==probe['world_lower_left_grid_bounds'];target['position_bounds_grid']=[[lo-[0,210000][k],hi-[0,210000][k]] for k,(lo,hi) in enumerate(world)]
positions=load(M/'search/result.json')['final_values_mm'];positions[34:36]=[best['lower_left_after_mm'][0],best['lower_left_after_mm'][1]-2100]
by_identity={(r['part_id'],r['copy_index']):r for r in seed}
for o in owners:
    i=o['owner'];expected={'rotation_radians':o['rotation_radians'],'mirrored':o['mirrored'],'translation':[positions[2*i+k]+[0,2100][k]+o['translation_from_lower_left'][k] for k in [0,1]]}
    assert by_identity[tuple(o['identity'])]['transform']==expected
seed_checks=audit(job,seed,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],list(map(tuple,load(I/'inventory.json')['full66_identities'])));assert seed_checks==load(A/best['checks_file']) and not seed_checks['valid'] and seed_checks['pair_failures']==39
write(OUT/'seed-source66.json',seed);write(OUT/'seed-source-checks.json',seed_checks);write(OUT/'owners.json',owners);write(OUT/'initial-values-mm.json',positions)
unique={}
for o in owners:
    if o['owner']!=17:unique.setdefault((o['identity'][0],o['mode']),o)
keys=sorted(unique);assert keys==[('bracket',0),('bracket',1),('bracket',5),('cog',0),('insert',0),('insert',1),('insert',2)]
controls=[]
def source_pose(owner,xy):
    return {'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':owner['rotation_radians'],'mirrored':owner['mirrored'],'translation':[xy[k]/100+[0,2100][k]+owner['translation_from_lower_left'][k] for k in [0,1]]}}
for corner,xy in enumerate(product(*target['position_bounds_grid'])):
    rows=fixed+[source_pose(target,xy)]+short;check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows]);assert check['valid'];stem=f'target-corner-{corner}';write(OUT/(stem+'-source.json'),rows);write(OUT/(stem+'-checks.json'),check);controls.append({'kind':'target_corner','corner':corner,'position_grid':xy,'source':stem+'-source.json','checks':stem+'-checks.json'})
def source_geometry(owner):
    family=owner['identity'][0];v=affine(parts[family]['geometry'][0]['outer'],owner)
    return {'outer':v,'hull':hull(v),'pieces':[affine(p,owner) for p in canonical[family]]}
ga=source_geometry(target);square=np.array([[-.226,-.226],[.226,-.226],[.226,.226],[-.226,.226]]);templates=[];proofs=[];disabled=[];minimum_gap=math.inf
for ti,key in enumerate(keys):
    other=unique[key];gb=source_geometry(other);aa,bb=target['position_bounds_grid'],other['position_bounds_grid'];relative=[[bb[k][0]-aa[k][1],bb[k][1]-aa[k][0]] for k in [0,1]];domain=[F(relative[0][0],100),F(relative[1][0],100),F(relative[0][1],100),F(relative[1][1],100)];pieces=[]
    for ap,bp in product(ga['pieces'],gb['pieces']):
        diff=(np.asarray(ap,dtype=float)[:,None,:]-np.asarray(bp,dtype=float)[None,:,:]).reshape(-1,2);pieces.append(MultiPoint((diff[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
    inflated=unary_union(pieces);envelope=inflated.convex_hull;h=hull([tuple(map(F,p)) for p in envelope.exterior.coords[:-1]]);raw=[]
    for a,b in zip(h,h[1:]+h[:1]):
        region=exterior(domain,a,b)
        if region is not None:raw.append(('convex_exterior_halfplane',region))
    pockets=envelope.difference(inflated).intersection(box(*map(float,domain)));triangles=[p for p in shapely.constrained_delaunay_triangles(pockets).geoms if p.area>0];merged,merges=merge_exact(triangles) if triangles else ([],0);raw.extend(('concave_pocket',p) for p in merged)
    regions=[];cache={};before=len(proofs)
    for raw_id,(kind,vertices) in enumerate(raw):
        v=hull([tuple(F(round(x,9)) for x in p) for p in vertices])
        if len(v)<3 or area(v)<=0:disabled.append({'template':ti,'raw_region':raw_id,'reason':'degenerate_after_rounding'});continue
        shape=Polygon([(float(x),float(y)) for x,y in v]);assert shape.is_valid;tasks=[(-1,-1)];local=[]
        while tasks:
            ai,bi=tasks.pop();ap=ga['hull'] if ai==-1 else ga['pieces'][ai];bp=gb['hull'] if bi==-1 else gb['pieces'][bi]
            if (ai,bi) not in cache:cache[ai,bi]=nfp(ap,bp)
            result=support(v,shape,bp,ap,cache[ai,bi])
            if result:
                normal,gap=result;minimum_gap=min(minimum_gap,gap);local.append({'template':ti,'region':len(regions),'a_piece':ai,'b_piece':bi,'normal':normal,'gap_lower_mm':gap})
            elif bi==-1:tasks.extend((-1,j) for j in range(len(gb['pieces'])))
            elif ai==-1:tasks.extend((j,bi) for j in range(len(ga['pieces'])))
            else:raise AssertionError(('unsafe rounded source region',ti,raw_id,ai,bi))
        regions.append({'region':len(regions),'raw_region':raw_id,'kind':kind,'vertices_mm':[[str(x),str(y)] for x,y in v]});proofs.extend(local)
    assert regions;templates.append({'template':ti,'target_owner':17,'other_family':key[0],'other_source_mode':key[1],'other_representative_owner':other['owner'],'other_source_pose':other,'relative_grid_bounds':relative,'domain_mm':[str(x) for x in domain],'relative_coordinate':'lower_left_other_minus_lower_left_target','regions':regions,'raw_regions':len(raw),'pocket_triangles':len(triangles),'exact_merges':merges,'source_supports':len(proofs)-before})
    for direction in [0,1]:
        xy_a=[b[direction]+(1 if direction==0 else -1) for b in aa];xy_b=[b[1-direction]+(-1 if direction==0 else 1) for b in bb]
        rows=fixed+[source_pose(target,xy_a),source_pose(other,xy_b)]+short;check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows]);assert check['valid'];delta=[F(xy_b[k]-xy_a[k],100) for k in [0,1]]
        containing=[]
        for r in regions:
            v=[tuple(map(F,p)) for p in r['vertices_mm']]
            if all((b[0]-a[0])*(delta[1]-a[1])-(b[1]-a[1])*(delta[0]-a[0])>=0 for a,b in zip(v,v[1:]+v[:1])):containing.append(r['region'])
        assert containing;stem=f'pair-{ti}-{direction}';write(OUT/(stem+'-source.json'),rows);write(OUT/(stem+'-checks.json'),check);controls.append({'kind':'pair_interior','template':ti,'direction':direction,'position_grid':[xy_a,xy_b],'relative_mm':[str(x) for x in delta],'containing_regions':containing,'source':stem+'-source.json','checks':stem+'-checks.json'})
    assert time.perf_counter()-started<10
original_pairs=load(M/'library.json')['pairs'];affected=[];unchanged=[]
for p in original_pairs:
    if 17 not in p['owners']:unchanged.append(p);continue
    other_index=next(i for i in p['owners'] if i!=17);o=owners[other_index];ti=keys.index((o['identity'][0],o['mode']));affected.append({'pair':p['pair'],'original_owners':p['owners'],'ordered_owners':[17,other_index],'template':ti,'order_reversed':p['owners']!=[17,other_index]})
assert len(affected)==27 and len(unchanged)==231 and len({p['pair'] for p in affected+unchanged})==258
for name,data in [('templates.json',templates),('source-supports.json',proofs),('disabled-regions.json',disabled),('controls.json',controls),('affected-pairs.json',affected),('unaffected-pairs.json',unchanged),('target-domain.json',{'safe_world_bounds_mm':[str(x) for x in safe],'exact_normalized_source_bounds_mm':[str(x) for x in bounds],'target_world_grid_bounds':world,'target_local_grid_bounds':target['position_bounds_grid'],'target_physical_source_mode':target})]:write(OUT/name,data)
result={'passed':True,'seconds_including_serialization':time.perf_counter()-started,'target_identity':['cog',2],'target_degrees':7.25,'moving_originals':28,'distinct_new_source_templates':7,'affected_original_pairs':27,'unaffected_cog_pairs':231,'reversed_order_pairs':sum(p['order_reversed'] for p in affected),'new_source_regions':sum(len(t['regions']) for t in templates),'exact_source_supports':len(proofs),'disabled_degenerate_regions':len(disabled),'minimum_certified_source_gap_mm':minimum_gap,'target_corner_controls':4,'ordered_pair_interior_controls':14,'seed_source_pair_failures':39,'source_valid66':False,'new_model_created':False,'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
