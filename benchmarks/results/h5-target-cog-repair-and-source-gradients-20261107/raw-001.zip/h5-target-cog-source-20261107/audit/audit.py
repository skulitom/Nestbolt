"""Independent source partition, domain, support and affected-pair audit."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from itertools import product
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil,copy
from h5_exact_convex_partition_tools_20261029 import hull,area,cross
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-target-cog-source-20261107';OUT=BASE/'audit';M=ROOT/'output/h5-mixed-mode-union-20261107';A=ROOT/'output/h5-original-cog-angular-variations-20261107';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';PROCESS=ROOT/'output/h5-target-cog-source-process-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');job=load(JOB);parts={p['id']:p for p in job['parts']};canonical=load(PIECES);spec=load(FIRST/'plan.json');old=load(M/'search/round-00/selected-mapping.json');owners=load(BASE/'owners.json');best=load(A/'best-local-variation.json');probe=next(m for m in load(A/'probe-modes.json') if m['angle_degrees']==7.25);positions=load(BASE/'initial-values-mm.json')
assert best['identity']==['cog',2] and best['owner']==17 and best['angle_degrees']==7.25 and parts['cog']['rotations']['kind']=='free'
fixed=load(FIRST/'fixed29.json');short=load(FIRST/'short9-source.json');stock=list(map(F,spec['construction_stock']));safe=[stock[0]+F(1,40),stock[1]+F(1,40),stock[2]-F(1,40),stock[3]-F(1,40)];eps=F(1,1000000)
def affine(points,m):
    c,s=map(F,[math.cos(m['rotation_radians']),math.sin(m['rotation_radians'])]);sign=-1 if m['mirrored'] else 1;tx,ty=map(F,m.get('translation_from_lower_left',m.get('translation')))
    return [(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in points]
partition=[]
for family in ['bracket','insert','cog']:
    outer=[tuple(map(F,p)) for p in parts[family]['geometry'][0]['outer']];pieces=[[tuple(map(F,p)) for p in q] for q in canonical[family]]
    if area(outer)<0:outer.reverse()
    for p in pieces:
        if area(p)<0:p.reverse()
        assert area(p)>0 and area(p)==area(hull(p)) and all(cross(a,b,c)>=0 for a,b,c in zip(p,p[1:]+p[:1],p[2:]+p[:2]))
    vertices=set(outer)|{v for p in pieces for v in p}
    def boundaries(polys):
        edges=Counter()
        for p in polys:
            for a,b in zip(p,p[1:]+p[:1]):
                points=sorted(v for v in vertices if cross(a,b,v)==0 and all(min(a[k],b[k])<=v[k]<=max(a[k],b[k]) for k in [0,1]))
                if a>b:points.reverse()
                assert points[0]==a and points[-1]==b
                for u,v in zip(points,points[1:]):edges[min(u,v),max(u,v)]+=1 if u<v else -1
        return {k:v for k,v in edges.items() if v}
    assert boundaries(pieces)==boundaries([outer]) and sum(area(p) for p in pieces)==area(outer)
    partition.append({'family':family,'pieces':len(pieces),'source_area_mm2':str(area(outer)),'exact_partition_passed':True})
write(OUT/'exact-source-partition.json',partition)
assert len(owners)==28 and all(o['owner']==i for i,o in enumerate(owners))
for i,(o,previous) in enumerate(zip(owners,old['owners'])):
    if i!=17:assert o==previous
    else:
        expected=copy.deepcopy(previous);expected.update({'mode':1,'rotation_radians':probe['rotation_radians'],'mirrored':False,'translation_from_lower_left':probe['translation_from_lower_left'],'position_bounds_grid':[[lo-[0,210000][k],hi-[0,210000][k]] for k,(lo,hi) in enumerate(probe['world_lower_left_grid_bounds'])]});assert o==expected
    family=o['identity'][0];outer=affine(parts[family]['geometry'][0]['outer'],o);b=[min(v[k] for v in outer) for k in [0,1]]+[max(v[k] for v in outer) for k in [0,1]]
    for k,(lo,hi) in enumerate(o['position_bounds_grid']):
        world_lo,world_hi=lo+[0,210000][k],hi+[0,210000][k]
        assert F(world_lo-1,100)<safe[k]-b[k]+eps<=F(world_lo,100) and F(world_hi,100)<=safe[k+2]-b[k+2]-eps<F(world_hi+1,100)
target=owners[17];assert target['rotation_radians']==math.radians(7.25);c,s=math.cos(target['rotation_radians']),math.sin(target['rotation_radians']);rot=[(x*c-y*s,x*s+y*c) for x,y in parts['cog']['geometry'][0]['outer']];assert target['translation_from_lower_left']==[-min(x for x,y in rot),-min(y for x,y in rot)]
original_positions=load(M/'search/result.json')['final_values_mm'];expected_positions=original_positions.copy();expected_positions[34:36]=[best['lower_left_after_mm'][0],best['lower_left_after_mm'][1]-2100];assert positions==expected_positions
def source_row(owner,xy):
    return {'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':owner['rotation_radians'],'mirrored':owner['mirrored'],'translation':[xy[k]/100+[0,2100][k]+owner['translation_from_lower_left'][k] for k in [0,1]]}}
seed=fixed+short
for o in owners:
    i=o['owner'];seed.append({'part_id':o['identity'][0],'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':o['rotation_radians'],'mirrored':o['mirrored'],'translation':[positions[2*i+k]+[0,2100][k]+o['translation_from_lower_left'][k] for k in [0,1]]}})
assert seed==load(BASE/'seed-source66.json')==load(A/best['source_file'])
ids=list(map(tuple,load(I/'inventory.json')['full66_identities']));seed_check=audit(job,seed,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],ids);assert seed_check==load(BASE/'seed-source-checks.json')==load(A/best['checks_file']) and seed_check['pair_failures']==39 and seed_check['stock_failures']==0
core_top=max(v[1] for r in fixed for v in affine(parts[r['part_id']]['geometry'][0]['outer'],r['transform']));assert safe[1]-core_top>F(spec['required_pair_gap_mm'])
target_vertices=affine(parts['cog']['geometry'][0]['outer'],target);target_bounds=[min(v[k] for v in target_vertices) for k in [0,1]]+[max(v[k] for v in target_vertices) for k in [0,1]]
assert load(BASE/'target-domain.json')=={'safe_world_bounds_mm':[str(v) for v in safe],'exact_normalized_source_bounds_mm':[str(v) for v in target_bounds],'target_world_grid_bounds':probe['world_lower_left_grid_bounds'],'target_local_grid_bounds':target['position_bounds_grid'],'target_physical_source_mode':target}
unique={}
for o in owners:
    if o['owner']!=17:unique.setdefault((o['identity'][0],o['mode']),o)
keys=sorted(unique);templates=load(BASE/'templates.json');proofs=load(BASE/'source-supports.json');proof_map={}
for p in proofs:proof_map.setdefault((p['template'],p['region']),[]).append(p)
def geometry(o):
    family=o['identity'][0];v=affine(parts[family]['geometry'][0]['outer'],o)
    return {'hull':hull(v),'pieces':[affine(p,o) for p in canonical[family]]}
ga=geometry(target);minimum_gap=math.inf;regions_checked=proofs_checked=0
assert len(templates)==len(keys)==7
for ti,(t,key) in enumerate(zip(templates,keys)):
    other=unique[key];gb=geometry(other);aa,bb=target['position_bounds_grid'],other['position_bounds_grid'];relative=[[bb[k][0]-aa[k][1],bb[k][1]-aa[k][0]] for k in [0,1]]
    assert t['template']==ti and t['target_owner']==17 and (t['other_family'],t['other_source_mode'])==key and t['other_representative_owner']==other['owner'] and t['other_source_pose']==other
    assert t['relative_grid_bounds']==relative and t['domain_mm']==[str(F(relative[0][0],100)),str(F(relative[1][0],100)),str(F(relative[0][1],100)),str(F(relative[1][1],100))] and t['relative_coordinate']=='lower_left_other_minus_lower_left_target'
    before=proofs_checked
    for ri,r in enumerate(t['regions']):
        assert r['region']==ri;v=[tuple(map(F,p)) for p in r['vertices_mm']];assert v==hull(v) and area(v)>0;coverage=set()
        for p in proof_map[ti,ri]:
            ai,bi=p['a_piece'],p['b_piece'];ap=ga['hull'] if ai==-1 else ga['pieces'][ai];bp=gb['hull'] if bi==-1 else gb['pieces'][bi];nx,ny=map(F,p['normal']);norm=nx*nx+ny*ny;assert norm>0
            gap=min(x*nx+y*ny for x,y in v)+min(x*nx+y*ny for x,y in bp)-max(x*nx+y*ny for x,y in ap);assert gap>0 and gap*gap>=F('.225')**2*norm
            actual=float(gap)/math.sqrt(float(norm));assert actual==p['gap_lower_mm'];minimum_gap=min(minimum_gap,actual);coverage.update(product(range(len(ga['pieces'])) if ai==-1 else [ai],range(len(gb['pieces'])) if bi==-1 else [bi]));proofs_checked+=1
        assert coverage==set(product(range(len(ga['pieces'])),range(len(gb['pieces']))));regions_checked+=1
    assert proofs_checked-before==t['source_supports']
assert proofs_checked==len(proofs)
controls=load(BASE/'controls.json');assert len(controls)==18;counts={'positive_source_pairs':0,'positive_stock_edges':0,'positive_holes':0,'positive_hole_vertices':0};minimum_source=math.inf;ci=0
for corner,xy in enumerate(product(*target['position_bounds_grid'])):
    control=controls[ci];ci+=1;assert control['kind']=='target_corner' and control['corner']==corner and control['position_grid']==list(xy)
    rows=fixed+[source_row(target,xy)]+short;assert rows==load(BASE/control['source'])
for ti,t in enumerate(templates):
    other=unique[keys[ti]];aa,bb=target['position_bounds_grid'],other['position_bounds_grid']
    for direction in [0,1]:
        control=controls[ci];ci+=1;assert control['kind']=='pair_interior' and control['template']==ti and control['direction']==direction
        xa=[b[direction]+(1 if direction==0 else -1) for b in aa];xb=[b[1-direction]+(-1 if direction==0 else 1) for b in bb];assert control['position_grid']==[xa,xb]
        rows=fixed+[source_row(target,xa),source_row(other,xb)]+short;assert rows==load(BASE/control['source']);delta=[F(xb[k]-xa[k],100) for k in [0,1]];assert control['relative_mm']==[str(v) for v in delta]
        found=[r['region'] for r in t['regions'] for v in [[tuple(map(F,p)) for p in r['vertices_mm']]] if all(cross(a,b,delta)>=0 for a,b in zip(v,v[1:]+v[:1]))];assert found==control['containing_regions'] and found
for control in controls:
    rows=load(BASE/control['source']);result=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows]);assert result==load(BASE/control['checks']) and result['valid'];minimum_source=min(minimum_source,result['minimum_pair_gap_mm'])
    for key,field in [('positive_source_pairs','same_sheet_pairs'),('positive_stock_edges','stock_edges'),('positive_holes','cutouts'),('positive_hole_vertices','hole_vertices')]:counts[key]+=result[field]
original_pairs=load(M/'library.json')['pairs'];affected=[];unaffected=[]
for p in original_pairs:
    if 17 not in p['owners']:unaffected.append(p);continue
    oi=next(i for i in p['owners'] if i!=17);o=owners[oi];affected.append({'pair':p['pair'],'original_owners':p['owners'],'ordered_owners':[17,oi],'template':keys.index((o['identity'][0],o['mode'])),'order_reversed':p['owners']!=[17,oi]})
assert affected==load(BASE/'affected-pairs.json') and unaffected==load(BASE/'unaffected-pairs.json') and len(affected)==27 and len(unaffected)==231
assert sum(p['order_reversed'] for p in affected)==1 and next(p for p in affected if p['order_reversed'])['original_owners']==[16,17]
assert sorted(p['pair'] for p in affected+unaffected)==list(range(258))
summary=load(BASE/'checks.json');prep=load(PROCESS/'prepare.json');assert prep['passed'] and prep['job']['closed'] and prep['job']['active_processes']==0 and prep['complete_seconds']<12 and summary['seconds_including_serialization']<10
assert summary['new_source_regions']==regions_checked and summary['exact_source_supports']==proofs_checked and summary['minimum_certified_source_gap_mm']==minimum_gap
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,PIECES]+list(BASE.glob('*.json'))+[M/n for n in ['library.json','search/result.json','search/round-00/selected-mapping.json']]+[A/n for n in ['best-local-variation.json','probe-modes.json','03-source66.json','03-checks.json']]+[FIRST/n for n in ['plan.json','fixed29.json','short9-source.json']]+[I/'inventory.json']+[PROCESS/n for n in ['opened.json','prepare.json','prepare-job.json','prepare-stderr.txt']]
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    d=load(p)
    if not isinstance(d,dict):continue
    for name,h in {**d.get('inputs',{}),**d.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert digest(z)==h;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independent exact source partition,affine mode/domain and support-gap verification. Retain27unchanged physical poses and check the target7.25degree original explicitly. Reconstruct all18positive source controls,including both signed pair-domain directions,plus the still-invalid66partseed. Require exact region membership for interior controls and full convex-piece support coverage for every new region. Read back27affected/231unaffectedpair identities and the single reversed original[16,17]order. No solver or validlayout claim.'})
result={'passed':True,'seconds':time.perf_counter()-start,'source_bindings':len(bindings),'source_partitions':3,'moving_originals':28,'unchanged_physical_modes':27,'new_source_templates':7,'source_regions':regions_checked,'exact_source_supports':proofs_checked,'minimum_certified_source_gap_mm':minimum_gap,'positive_source_controls':18,**counts,'minimum_positive_source_gap_mm':minimum_source,'affected_pairs':27,'unaffected_cog_pairs':231,'reversed_owner_pairs':1,'seed_originals':66,'seed_pairs':1632,'seed_holes':90,'seed_hole_vertices':10026,'seed_pair_failures':39,'source_valid66':False,'complete_source_preparation_seconds':prep['complete_seconds'],'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
