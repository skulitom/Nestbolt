from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil,copy
import numpy as np
from h5_target_cog_model_20261107 import ROOT,BASE,T,M,load,readback,source_rows,Objective
from h5_cog_union_distance_20261107 import nearest_regions
from h5_legacy64_source_readback import audit
OUT=BASE/'audit';digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');assert load(T/'audit/checks.json')['passed']
with np.load(BASE/'source-arrays.npz',allow_pickle=False) as z:arrays={k:z[k] for k in z.files}
with np.load(M/'search/round-00/selected-arrays.npz',allow_pickle=False) as z:old={k:z[k] for k in z.files}
meta=load(BASE/'mapping.json');oldmeta=load(M/'search/round-00/selected-mapping.json');owners=load(T/'owners.json');values=load(T/'initial-values-mm.json');templates=load(T/'templates.json');affected=load(T/'affected-pairs.json')
assert readback(arrays,meta,old,oldmeta,owners,values,templates,affected)
assert [p['original_owners'] for p in affected if p['order_reversed']]==[[16,17]]
first=ROOT/'output/h5-first57-direct-short9-20261104';fixed=load(first/'fixed29.json')+load(first/'short9-source.json');rows=source_rows(meta,values,fixed);seed=load(T/'seed-source66.json');key=lambda r:(r['part_id'],r['copy_index']);assert sorted(rows,key=key)==sorted(seed,key=key)
spec=load(first/'plan.json');job=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';inventory=ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json';source=audit(load(job),rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],list(map(tuple,load(inventory)['full66_identities'])))
assert source==load(T/'seed-source-checks.json') and not source['valid'] and source['pair_failures']==39 and source['stock_failures']==0;write(OUT/'seed-source-checks.json',source)
def exact_projection(point,v):
    if all((q[0]-p[0])*(point[1]-p[1])-(q[1]-p[1])*(point[0]-p[0])>=0 for p,q in zip(v,v[1:]+v[:1])):return point,F(0)
    choices=[]
    for p,q in zip(v,v[1:]+v[:1]):
        edge=[q[k]-p[k] for k in [0,1]];den=sum(x*x for x in edge);t=max(F(0),min(F(1),sum((point[k]-p[k])*edge[k] for k in [0,1])/den));near=tuple(p[k]+t*edge[k] for k in [0,1]);choices.append((sum((point[k]-near[k])**2 for k in [0,1]),near))
    distance,near=min(choices);return near,distance
projections=0;maximum_projection_error=0.
for t in templates:
    pre=f'g{t["template"]+4}_';points=[(F(0),F(0)),(F(23333,100),F(-18425,100))];q,d=nearest_regions(np.asarray(points,dtype=float),*[arrays[pre+k] for k in ['starts','ends','valid','normals','upper']])
    for ri,r in enumerate(t['regions']):
        v=[tuple(map(F,p)) for p in r['vertices_mm']]
        for pi,point in enumerate(points):
            expected,distance=exact_projection(point,v);error=float(np.max(np.abs(q[pi,ri]-np.array(expected,dtype=float))));assert error<1e-8 and abs(d[pi,ri]-float(distance))<1e-7+1e-12*float(distance);maximum_projection_error=max(maximum_projection_error,error);projections+=1
assert projections==1254
obj=Objective(arrays,meta);initial,initial_gradient=obj.evaluate(values);derivatives=[]
for phase in range(3):
    point=np.array(values)+.037*np.sin(np.arange(56)*2**.5+.2+phase);energy,g=obj.evaluate(point);errors=[];h=1e-4
    for i in range(56):
        plus=point.copy();minus=point.copy();plus[i]+=h;minus[i]-=h;observed=(obj.evaluate(plus)[0]-obj.evaluate(minus)[0])/(2*h);error=abs(observed-g[i]);assert error<.003+1e-6*abs(g[i]),(phase,i,observed,g[i]);errors.append(error)
    assert np.max(np.abs(g.reshape(28,2).sum(axis=0)))<1e-8 and obj.evaluate(point-1e-7*g)[0]<energy
    derivatives.append({'phase':phase,'coordinates':56,'maximum_error':max(errors),'energy_mm2':energy,'translation_invariant_gradient':True})
write(OUT/'derivative-controls.json',derivatives)
# Isolate every target interaction, including the reversed [16,17] pair.
target_derivatives=[]
for group in meta['groups'][4:]:
    gi=group['group'];pre=f'g{gi}_';pairs=arrays[pre+'owners'];points=np.array(values).reshape(28,2)
    for li,pair_id in enumerate(group['pairs']):
        oi,oj=map(int,pairs[li]);delta=points[oj]-points[oi];region_arrays=[arrays[pre+k] for k in ['starts','ends','valid','normals','upper']]
        q,d=nearest_regions(delta[None,:],*region_arrays);best=int(np.argmin(d[0]));gradient=2*(delta-q[0,best]);errors=[]
        for k in [0,1]:
            plus=delta.copy();minus=delta.copy();plus[k]+=1e-4;minus[k]-=1e-4;dp=nearest_regions(plus[None,:],*region_arrays)[1].min();dm=nearest_regions(minus[None,:],*region_arrays)[1].min();err=abs((dp-dm)/2e-4-gradient[k]);assert err<.003+1e-6*abs(gradient[k]);errors.append(float(err))
        target_derivatives.append({'pair':pair_id,'owners':[oi,oj],'coordinates':2,'maximum_error':max(errors),'owner17_gradient_is_negative_relative_gradient':True})
assert len(target_derivatives)==27;write(OUT/'target-pair-derivatives.json',target_derivatives)
corruptions=[]
for kind in ['stock','pose','old_pair','target_order','target_matrix','target_offset','target_vertex','target_id','rectangle']:
    a={k:v.copy() for k,v in arrays.items()};m=copy.deepcopy(meta)
    if kind=='stock':a['bounds'][34,0]+=1
    elif kind=='pose':m['owners'][17]['rotation_radians']+=.01
    elif kind=='old_pair':a['g0_owners'][0]=a['g0_owners'][0][::-1]
    elif kind=='target_order':a['g7_owners'][0]=a['g7_owners'][0][::-1]
    elif kind=='target_matrix':a['g7_matrix'][0,0,0]=-1
    elif kind=='target_offset':a['g7_offset'][0,0]+=1
    elif kind=='target_vertex':a['g4_starts'][0,0,0]+=1
    elif kind=='target_id':m['groups'][4]['pairs'][0]=0
    else:a['orth_upper'][0,0]+=1
    caught=False
    try:readback(a,m,old,oldmeta,owners,values,templates,affected)
    except AssertionError:caught=True
    assert caught,kind;corruptions.append({'corruption':kind,'rejected':True})
write(OUT/'negative-controls.json',corruptions)
controls=load(M/'audit/optimizer-controls.json');provenance=load(M/'audit/tool-provenance.json');assert controls['passed']
for name,record in provenance['tool_files'].items():assert digest(ROOT/name)==record['sha256']
write(OUT/'optimizer-controls.json',controls);write(OUT/'tool-provenance.json',provenance)
inputs=[Path(__file__),ROOT/'output/h5_target_cog_model_20261107.py',ROOT/'output/h5_cog_physical_union_distance_v2_20261107.py',ROOT/'output/h5_cog_union_distance_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',job,inventory]+[BASE/n for n in ['plan.json','source-arrays.npz','mapping.json','checks.json','source-preparation-charges.json']]+[T/n for n in ['plan.json','owners.json','initial-values-mm.json','templates.json','affected-pairs.json','seed-source66.json','seed-source-checks.json','audit/plan.json','audit/checks.json']]+[M/n for n in ['search/round-00/selected-arrays.npz','search/round-00/selected-mapping.json','audit/optimizer-controls.json','audit/tool-provenance.json']]+[first/n for n in ['plan.json','fixed29.json','short9-source.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently read every old retained array/row and every fresh region/edge/padding/coupling,258pair IDs,28poses and hard bounds. Reconstruct the exact selected original-source seed; replay all66source checks. Compare1254 exact rational projections,168whole-model derivatives and54relative pair derivatives, including reversed owner16/17. Reject9deliberate corruptions and verify all pinned optimizer tool hashes. No source optimizer call.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'moving_originals':28,'retained_cog_pairs':231,'new_cog_pairs':27,'orthogonal_component_pairs':268,'new_source_regions':627,'exact_projection_comparisons':projections,'maximum_projection_error_mm':maximum_projection_error,'analytic_derivatives':168,'target_pair_derivatives':54,'reversed_owner_pairs':1,'negative_controls':len(corruptions),'initial_objective_mm2':initial,'source_arrays_sha256':digest(BASE/'source-arrays.npz'),'mapping_sha256':digest(BASE/'mapping.json'),'seed_source_pair_failures':39,'source_valid66':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
