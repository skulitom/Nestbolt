from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
from h5_target_cog_model_20261107 import ROOT,BASE,T,M,load,pack
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
BASE.mkdir();start=time.perf_counter();shutil.copyfile(__file__,BASE/'prepare.py');assert load(T/'audit/checks.json')['passed']
a,m=pack();np.savez_compressed(BASE/'source-arrays.npz',**a);write(BASE/'mapping.json',m)
charges={'complete_original_candidate_and_angular_probe':load(T/'plan.json')['complete_consumed_candidate_and_probe_seconds'],'complete_new_target_source_preparation':load(ROOT/'output/h5-target-cog-source-process-20261107/prepare.json')['complete_seconds']};write(BASE/'source-preparation-charges.json',charges)
inputs=[Path(__file__),ROOT/'output/h5_target_cog_model_20261107.py',ROOT/'output/h5_cog_physical_union_distance_v2_20261107.py',ROOT/'output/h5_cog_union_distance_20261107.py',ROOT/'output/h5-target-cog-source-process-20261107/prepare.json']+[T/n for n in ['plan.json','owners.json','initial-values-mm.json','templates.json','affected-pairs.json','unaffected-pairs.json','seed-source66.json','checks.json','audit/plan.json','audit/checks.json']]+[M/n for n in ['search/round-00/selected-arrays.npz','search/round-00/selected-mapping.json','audit/optimizer-controls.json','audit/tool-provenance.json']]
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'One fixed new physical vector: original cog2 at7.25degrees, all27 other selected modes unchanged; all28translations free. Retain every unaffected231 pair row and268orthogonal component terms exactly. Replace all27 target rows by seven independently source-certified direct templates; preserve all258pair IDs and explicitly reverse the original [16,17] row. Old region indices remain unchanged; fresh region indices use a disjoint namespace. No free consumption of the closed7/16degree model. Audit arrays, derivatives, original source seed and tool bytes before a single frozen bounded call.','source_preparation_seconds':sum(charges.values()),'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'maximum_optimizer_calls':1,'retry_permitted':False,'optimizer_calls':0})
write(BASE/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'moving_originals':28,'cog_interactions':258,'retained_cog_interactions':231,'new_cog_interactions':27,'new_source_regions':627,'orthogonal_component_interactions':268,'source_arrays_sha256':digest(BASE/'source-arrays.npz'),'mapping_sha256':digest(BASE/'mapping.json'),'optimizer_calls':0,'source_valid66':False,'H5_complete':False});print(load(BASE/'checks.json'))
