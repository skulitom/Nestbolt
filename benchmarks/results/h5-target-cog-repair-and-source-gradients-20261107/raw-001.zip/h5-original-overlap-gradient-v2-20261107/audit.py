from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import math,json,time,copy,shutil
import numpy as np
from shapely.geometry import Polygon
from h5_original_overlap_gradient_v2_20261107 import original_area_and_gradient,moving_boundary_gradient,pose_polygon
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-original-overlap-gradient-v2-20261107';BASE=ROOT/'output/h5-target-cog-model-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';digest=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');assert load(BASE/'response-audit/checks.json')['passed']
inputs=[RFILE for RFILE in [ROOT/'output/h5-original-overlap-gradient-20261107/plan.json',ROOT/'output/h5-original-overlap-gradient-process-20261107/process.json',ROOT/'output/h5-original-overlap-shared-edges-20261107/checks.json']]+[Path(__file__),ROOT/'output/h5_original_overlap_gradient_v2_20261107.py',JOB]+[BASE/n for n in ['mapping.json','search/candidate-source66.json','search/original-source-checks.json','search/process.json','response-audit/plan.json','response-audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Verify rigid translation/rotation boundary gradients of actual filled-original-outline overlap. Shared edges use an explicitly nonsmooth half-weight symmetric convention,checked against central differences; this is not a unique classical derivative. Original cutouts remain in source files but filled outers enforce noPIH, matching the source checker. Independently compare68 central differences across28 moving translations and12 permitted continuous cog angles,with all66 original outlines and same-sheet pairs. Verify nonoverlap/containment/reversal controls and signal shared-boundary nondifferentiability. This is a verification-only kernel audit,not an optimizer,clearance model,source-safe-region proof or valid candidate. Future geometry preparation and kernel evaluations must be charged in the future algorithm; no audit outputs may be consumed as free preprocessing.','optimizer_calls':0,'time_cap_seconds':90,'memory_bytes':2**31,'new_search_model_prepared':False})
job=load(JOB);rows=load(BASE/'search/candidate-source66.json');owners=load(BASE/'mapping.json')['owners'];moving=[tuple(o['identity']) for o in owners];angular=[k for k in moving if k[0]=='cog'];assert len(moving)==28 and len(angular)==12
energy,gradient,records,metadata=original_area_and_gradient(job,rows,moving,angular);source=load(BASE/'search/original-source-checks.json');expected=sum(r['intersection_area_mm2'] for r in source['pairs']);assert abs(energy-expected)<1e-8 and len(records)==source['pair_failures']==39 and metadata['coincident_boundary_length_mm']>0
write(OUT/'pair-derivatives.json',records);write(OUT/'gradient.json',{'summed_pairwise_area_mm2':energy,'moving':moving,'angular':angular,'gradient':gradient.tolist(),**metadata})
parts={p['id']:p for p in job['parts']};shapes=[pose_polygon(parts[r['part_id']],r['transform']) for r in rows];positions={(r['part_id'],r['copy_index']):i for i,r in enumerate(rows)}
# Independent numerical readback evaluates only changed-original pair areas;
# every other term cancels. No derivative code is used here.
controls=[]
for coordinate in range(68):
    identity=moving[coordinate//2] if coordinate<56 else angular[coordinate-56];index=positions[identity];step=1e-4 if coordinate<56 else 1e-6;areas=[]
    for direction in [1,-1]:
        pose=copy.deepcopy(rows[index]['transform'])
        if coordinate<56:pose['translation'][coordinate%2]+=direction*step
        else:pose['rotation_radians']+=direction*step
        c,s=math.cos(pose['rotation_radians']),math.sin(pose['rotation_radians']);mirror=-1 if pose['mirrored'] else 1;tx,ty=pose['translation'];polygon=Polygon([(mirror*x*c-y*s+tx,mirror*x*s+y*c+ty) for x,y in parts[identity[0]]['geometry'][0]['outer']]);areas.append(sum(polygon.intersection(other).area for j,other in enumerate(shapes) if j!=index and rows[j]['sheet_id']==rows[index]['sheet_id']))
    observed=(areas[0]-areas[1])/(2*step);error=abs(observed-gradient[coordinate]);limit=.002+2e-6*abs(gradient[coordinate]);assert error<limit,(coordinate,identity,observed,gradient[coordinate],error,limit);controls.append({'coordinate':coordinate,'identity':identity,'kind':'translation_mm' if coordinate<56 else 'rotation_radians_about_source_origin','central_difference':observed,'symmetric_boundary_gradient':float(gradient[coordinate]),'absolute_error':error,'absolute_limit':limit})
write(OUT/'derivative-controls.json',controls)
a=Polygon([(0,0),(4,0),(4,3),(0,3)]);b=Polygon([(1.3,-1),(6,-1),(6,2.1),(1.3,2.1)]);g,n,c=moving_boundary_gradient(a,b,[0,0]);assert np.allclose(g[:2],[2.1,-2.7]) and c==0
g2,_,_=moving_boundary_gradient(Polygon(list(a.exterior.coords)[::-1]),b,[0,0]);assert np.allclose(g,g2)
inside=Polygon([(1,1),(2,1),(2,2),(1,2)]);gi,_,_=moving_boundary_gradient(inside,a,[0,0]);assert np.max(np.abs(gi))<1e-12
far=Polygon([(10,10),(12,10),(12,12),(10,12)]);gf,n,c=moving_boundary_gradient(a,far,[0,0]);assert np.all(gf==0) and n==0 and c==0
_,_,shared=moving_boundary_gradient(a,a,[0,0]);assert shared==14
write(OUT/'synthetic-controls.json',{'partial_overlap_translation_gradient':g.tolist(),'reversed_ring_equal':True,'strict_containment_zero_gradient':True,'disjoint_zero_gradient':True,'shared_boundary_length_detected_mm':shared,'warning':'Coincident boundaries have one-sided/nondifferentiable behavior; the helper reports them rather than certifying a unique derivative.'})
seed=load(ROOT/'output/h5-target-cog-source-20261107/seed-source-checks.json');before=sum(r['intersection_area_mm2'] for r in seed['pairs']);surrogate=load(BASE/'response-audit/checks.json');write(OUT/'objective-disagreement.json',{'source_area_before_mm2':before,'source_area_after_mm2':energy,'source_area_change_mm2':energy-before,'model_penalty_before_mm2':surrogate['initial_objective_mm2'],'model_penalty_after_mm2':surrogate['best_objective_mm2'],'model_penalty_change_mm2':surrogate['best_objective_mm2']-surrogate['initial_objective_mm2'],'scope':'One closed invalid candidate repair only. Both are nonnegative local penalties; lower model distance need not imply lower summed source overlap. No allocation exclusion or global convergence claim.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'originals':66,'source_overlap_pairs':39,'translation_central_comparisons':56,'angular_central_comparisons':12,'shared_boundary_pairs':2,'unique_classical_derivative_claimed':False,'maximum_derivative_error':max(c['absolute_error'] for c in controls),'maximum_scaled_derivative_error':max(c['absolute_error']/c['absolute_limit'] for c in controls),'summed_pairwise_area_mm2':energy,'synthetic_controls':5,'source_valid66':False,'optimizer_calls':0,'new_search_model_prepared':False,'H5_complete':False});print(load(OUT/'checks.json'))
