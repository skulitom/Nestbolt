"""Read-only family failures, boundary obstruction and residual flat terms."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,time
import numpy as np
from shapely.affinity import translate
from h5_bracket_augmented_objective_20261107 import Objective
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';P=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'outcome-diagnostic';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();checked=load(BASE/'response-audit/checks.json');assert checked['passed'] and checked['best_original']['epoch']==2
inputs=[Path(__file__)]+[BASE/n for n in ['response-audit/checks.json','response-audit/epoch-02/original-source-checks.json','search/epoch-02/response.json','search/epoch-02/model.json']]+[A/'objective-identity.json',A/'response-audit/checks.json',N/'response-audit/checks.json',P/'response-audit/checks.json',B/'regions.json',R/'response-audit/checks.json',W/'response-audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read-only composition of source failures, hard-bound descent obstruction and every positive original/clearance pair gradient in the closed original-area winner. Test only flat pair terms with the earlier fixed±.001/.1/1/5mm feasible translation probes. Compare prior audited outcomes without attributing a causal improvement. No candidate change, new initializer, search or allocation exclusion.','gradient_zero_tolerance':1e-7,'translation_steps_mm':[.001,.1,1.,5.],'optimizer_calls':0})
response=load(BASE/'search/epoch-02/response.json');assert all(v['auxiliary_bracket_depth_mm2']==0 for v in response['source_readbacks'].values());model=load(BASE/'search/epoch-02/model.json');x=response['winners']['original']['values'];gradient=response['winners']['original']['gradient'];source=load(BASE/'response-audit/epoch-02/original-source-checks.json');obj=Objective(model,load(B/'regions.json'),load(A/'objective-identity.json'));shapes=obj.geometry(x);groups=defaultdict(lambda:{'pair_failures':0,'positive_intersections':0,'overlap_mm2':0.})
for pair in source['pairs']:
    if pair['passed']:continue
    group=groups['/'.join(sorted(k[0] for k in pair['keys']))];group['pair_failures']+=1;group['positive_intersections']+=int(pair['intersection_area_mm2']>0);group['overlap_mm2']+=pair['intersection_area_mm2']
owners=[]
for i,o in enumerate(model['owners']):
    axes=[]
    for k in [2*i,2*i+1]:
        lo,hi=model['bounds'][k];bound='lower' if abs(x[k]-lo)<1e-7 else 'upper' if abs(x[k]-hi)<1e-7 else None;gg=gradient[k]
        axes.append({'axis':'x' if k%2==0 else 'y','bound':bound,'gradient':gg,'negative_gradient_blocked':bool((bound=='lower' and gg>1e-8) or (bound=='upper' and gg< -1e-8))})
    owners.append({'owner':i,'identity':o['identity'],'mode':o['mode'],'axes':axes})
positive=[];flat=[]
for index,(i,j) in enumerate(model['pairs']):
    areas=[shapes[k][i][1].intersection(shapes[k][j][1]).area for k in [0,1]];loss=sum(areas)
    if loss<=0:continue
    available=[];gradients=[]
    for own,other in [(i,j),(j,i)]:
        gg=np.zeros(3)
        for k in [0,1]:gg+=moving_boundary_gradient(shapes[k][own][1],shapes[k][other][1],x[2*own:2*own+2])[0]
        gradients.append(gg.tolist());available.extend(gg[:2]);o=model['owners'][own]
        if o['angle_coordinate'] is not None:available.append(gg[2]/o['angle_scale_mm'])
    record={'pair_index':index,'owners':[i,j],'identities':[model['owners'][i]['identity'],model['owners'][j]['identity']],'original_overlap_mm2':areas[0],'pair_area_loss_mm2':loss,'scalar_pair_gradients':gradients,'available_coordinate_gradient_zero':bool(max(abs(z) for z in available)<1e-7)}
    if record['available_coordinate_gradient_zero']:
        probes=[]
        for own,other in [(i,j),(j,i)]:
            for axis in [0,1]:
                k=2*own+axis
                for h in [.001,.1,1.,5.]:
                    for sign in [-1,1]:
                        delta=h*sign
                        if not model['bounds'][k][0]<=x[k]+delta<=model['bounds'][k][1]:continue
                        moved=sum(translate(shapes[level][own][1],xoff=delta if axis==0 else 0,yoff=delta if axis==1 else 0).intersection(shapes[level][other][1]).area for level in [0,1])
                        probes.append({'owner':own,'axis':axis,'delta_mm':delta,'pair_area_loss_mm2':moved,'change_mm2':moved-loss})
        record['probes']=probes;record['all_feasible_probes_flat']=bool(probes) and all(abs(p['change_mm2'])<1e-7 for p in probes);flat.append(record)
    positive.append(record)
comparisons=[]
for name,parent in [('prior_weighted',W),('prior_conditional_relocation',R),('prior_augmented',A),('prior_augmented_conditional',N),('prior_adaptive_augmented',P)]:
    prior=load(parent/'response-audit/checks.json');comparisons.append({'prior':name,'prior_pair_failures':prior.get('source_pair_failures',prior.get('best_original_pair_failures',prior.get('best_original',{}).get('pair_failures'))),'current_pair_failures':source['pair_failures'],'prior_original_overlap_mm2':prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'current_original_overlap_mm2':checked['best_original']['score_mm2'],'overlap_change_mm2':checked['best_original']['score_mm2']-prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'comparable_bounded_experiment':False,'packing_improvement_claimed':False})
assert sum(r['pair_failures'] for r in groups.values())==source['pair_failures'] and abs(sum(r['overlap_mm2'] for r in groups.values())-checked['best_original']['score_mm2'])<1e-7
cogs=[o for o in owners if o['identity'][0]=='cog']
write(OUT/'family-failures.json',dict(groups));write(OUT/'owner-bound-controls.json',owners);write(OUT/'positive-pair-gradients.json',positive);write(OUT/'flat-pair-probes.json',flat);write(OUT/'prior-comparisons.json',comparisons)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_pair_failures':source['pair_failures'],'original_overlap_mm2':checked['best_original']['score_mm2'],'positive_area_pairs':len(positive),'flat_available_pair_gradient_count':len(flat),'flat_pairs_with_all_probes_flat':sum(r['all_feasible_probes_flat'] for r in flat),'bounded_translation_probes':sum(len(r['probes']) for r in flat),'auxiliary_bracket_depth_mm2':response['source_readbacks']['original']['auxiliary_bracket_depth_mm2'],'bracket_bracket_source_failures':groups.get('bracket/bracket',{}).get('pair_failures',0),'cog_lower_y_bounds_active':sum(o['axes'][1]['bound']=='lower' for o in cogs),'cog_lower_y_negative_gradient_blocked':sum(o['axes'][1]['bound']=='lower' and o['axes'][1]['negative_gradient_blocked'] for o in cogs),'optimizer_calls':0,'candidate_changed':False,'any_allocation_excluded':False,'H5_complete':False})
print(load(OUT/'checks.json'))


from h5_augmented_selection_readback_20261107 import independent_classes
from math import comb
lib=load(A/'library.json');classes=independent_classes(lib);coverage=[];bindings={}
for label,initial_path,trial_path in [('original_source',A/'initial-state.json',N/'center-trials.json'),('runtime_1',BASE/'search/epoch-01/opened.json',BASE/'search/epoch-01/center-trials.json'),('runtime_2',BASE/'search/epoch-02/opened.json',BASE/'search/epoch-02/center-trials.json')]:
    context=load(initial_path);modes=context.get('modes',context.get('incoming_modes'));trials=load(trial_path);assert len(trials)==6396;rows=[]
    for i,(family,_) in enumerate(lib['identities']):
        current_class=classes[family][modes[i]];own=[r for r in trials if r['owner']==i];current_trials=[r for r in own if classes[family][r['mode']]==current_class]
        assert len(current_trials)==0
        if family=='cog':assert len(own)==0
        rows.append({'owner':i,'identity':lib['identities'][i],'current_mode':modes[i],'current_physical_class':current_class,'physical_mode_classes':len(set(classes[family])),'actual_nominal_center_trials':len(own),'current_class_center_trials':0})
    coverage.append({'context':label,'owners':rows,'current_mode_owners_omitted_from_center_grid':33,'cog_owners_with_no_center_grid':15,'nominal_existing_trials':6396})
    for path in [initial_path,trial_path]:bindings[path.relative_to(ROOT).as_posix()]=digest(path)
counts=[len(set(classes[f])) for f,_ in lib['identities']];changed=[v-1 for v in counts];all_options=sum(counts);new_trials=sum(counts)*82;all_pairs=sum(counts[i]*counts[j] for i in range(33) for j in range(i+1,33));physical_keys=1+sum(changed)+sum(changed[i]*changed[j] for i in range(33) for j in range(i+1,33))
assert all_options==111 and new_trials==9102 and all_pairs==5799 and physical_keys==2854
write(OUT/'neighborhood-coverage.json',{'passed':True,'inputs':bindings,'contexts':coverage,'prospective_counts_only':{'physical_owner_mode_options_including_current':all_options,'nominal_center_trials_including_current':new_trials,'additional_current_mode_center_trials':33*82,'raw_current_single_joint_proposals':1+all_options+all_pairs,'distinct_physical_mode_vectors':physical_keys},'interpretation':'The existing selector only tests physically changed bracket/insert modes. It never tests fixed-grid relocation of the current mode for any owner, including all15cogs; their centers move only through local continuous optimization. A possible broader selector could include current physical modes while preserving angles and all domains. Many raw placements would alias the same problem key, so a complete per-key minimum and the closed-key exclusion must be applied before any single call. These are coverage/count observations only: no broader geometry scores, selected state or search have been prepared.','optimizer_calls':0,'candidate_changed':False,'new_initializer_prepared':False,'closed_pipeline_resumed':False})
