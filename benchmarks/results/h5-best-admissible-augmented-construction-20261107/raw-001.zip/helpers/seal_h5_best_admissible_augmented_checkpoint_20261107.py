"""Archive merged admissibility, three closed calls and neighborhood coverage."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-best-admissible-augmented-construction-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';F=BASE/'response-audit';D=BASE/'audit'",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-adaptive-augmented-construction-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['best_original']['pair_failures']==53 and not front['source_valid66']",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/n for n in ['h5-best-admissible-augmented-preparation-process-20261107','h5-best-admissible-augmented-audit-process-20261107','h5-best-admissible-augmented-response-audit-process-20261107','h5-adaptive-augmented-main-sync-20261107']]",
    "['*h5*mixed*mode*20261107.py']":"['*h5*best*admissible*20261107.py','h5_augmented_admissible*20261107.py','run_h5_adaptive_augmented_search_20261107.py','audit_h5_adaptive_augmented_response_20261107.py','prepare_h5_adaptive_augmented_push_20261107.py','push_h5_adaptive_augmented_checkpoints_20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_best_admissible_augmented_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(D/'checks.json','preflight-audit.json'),(D/'choice-policy-controls.json','choice-policy-controls.json'),(D/'policy-stop-controls.json','policy-stop-controls.json'),(D/'inherited-controls.json','inherited-controls.json'),(D/'selected-model-controls.json','selected-model-controls.json'),(BASE/'selection.json','initial-selection.json'),(F/'checks.json','response-audit.json'),(F/'epoch-reconciliation.json','epoch-reconciliation.json'),(F/'epoch-02/original-source-checks.json','best-original-source-checks.json'),(F/'epoch-01-merged-choice.json','runtime-choice-01.json'),(F/'epoch-02-merged-choice.json','runtime-choice-02.json'),(BASE/'search/process.json','closed-search-process.json'),(BASE/'search/result.json','closed-search-result.json'),(BASE/'outcome-diagnostic/checks.json','outcome-diagnostic.json'),(BASE/'outcome-diagnostic/family-failures.json','family-failures.json'),(BASE/'outcome-diagnostic/prior-comparisons.json','prior-comparisons.json'),(BASE/'outcome-diagnostic/neighborhood-coverage.json','neighborhood-coverage.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json'),(ROOT/'output/h5-adaptive-augmented-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for epoch in [0,1,2]:copies.append((BASE/f'search/epoch-{epoch:02d}/closed-problem.json',f'closed-problem-{epoch:02d}.json'))
for stage in ['preparation','audit','response-audit']:copies.append((ROOT/'output'/f'h5-best-admissible-augmented-{stage}-process-20261107'/'process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'current_mode_relocation_coverage_preflight_required','finding':'Merged single/joint acceptance reaches its declared three-call limit. Both runtime choices are single-owner changes. Best original overlap falls to20445.49284040936mm2 but53source pairs still fail; earlier epoch1 has46failures with more overlap. The selector never explicitly tests a fixed-grid relocation in an owner current physical mode, including all15cogs. Their centers currently move only through local continuous optimization. This finite neighborhood omission is verified in source and both runtime contexts, not a feasibility proof.',
    'proposal':'Assess a separately versioned source-grid neighborhood that includes each owner current physical mode as well as changed modes, retaining cog angles at their incoming values for grid scoring and all continuous angles in optimization. Reconcile source geometry and the complete proposal pool before considering a new call. The current finite pipeline and its winners remain closed and cannot seed a successor.',
    'requirements':['Begin only from original unoptimized A/W source coordinates, existing source weights and the same fixed9x9grid plus clamped controls. Reuse existing audited source trial data only with its full consumed preparation cost. All14closed objective/physical-mode/weight keys must be excluded.','The prospective finite counts are111physical owner-mode options,9102nominal centers and5911raw current/single/joint proposals. Many raw placements alias the same one of2854physical-mode vectors. These are counts only, not prepared geometry or a successful selector.','Verify every current-mode domain and source shape, all528area pairs and15unweighted coefficient1 auxiliary terms. Score each mutual pair once. Independently reconstruct every new center/proposal score and preserve exact coordinate aliases.','Group raw proposals by the existing complete objective/physical-mode/weight identity. Select the deterministic minimum complete score per eligible key before choosing a strict improvement. Different coordinates alone never authorize another call. Retain the best-single/joint diagnostics and clear raw-vs-key coverage.','Version and validate deadline stops for the larger pool; preserve incomplete evidence and return no chosen candidate when interrupted. Do not assume old batch duration fits. Keep bounded area-only weight updates, full dynamic model readback and all three local winner streams.','Charge the full18.187212999444455seconds of consumed source/model/selector preparation plus all added work. Freeze a new finite60/90-second contract with a source reserve before measurement; no extension, retry or reseed of any closed key.','No optimizer may open until complete source/model/selection preflight passes and an admissible strict improvement exists. Full66source validity is required before native validation, material claims or H5 credit.'],
    'source_only_preparation_seconds_before_new_work':18.187212999444455,'closed_augmented_problems':7,'closed_prior_weighted_problems':7,'new_neighborhood_prepared':False,'new_source_state_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
ci=load(BASE/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs']);diag=load(BASE/'outcome-diagnostic/checks.json')
report=f'''# Best admissible augmented construction — 2026-11-07

The revised selector accepts the best strict-improving admissible single or
joint change. Its finite pipeline closes at **three distinct calls**. The best
original-overlap candidate reaches **20,445.492840 mm²**, but still fails
**53 source-pair checks**. Earlier epoch 1 has fewer failures (46) and more
overlap (28,711.709644 mm²). Against the preceding adaptive result, overlap is
lower and failing pairs are higher; no overall packing improvement or full
validity is claimed. H2/H5 remain open at **60%**.

## Independent policy and source preflight

[Three complete choice contexts]({NAME}/choice-policy-controls.json) replay
**8,562 independent full-score readbacks**: the new source pool and both prior
adaptive runtime rounds. Their accepted changes have respectively two, two
and one owner. The previously stopped single is accepted by the revised policy
only as a validation case; it never seeds the new search. Maximum saved-score
error is 5.821e-11 mm². [Policy stop controls]({NAME}/policy-stop-controls.json)
reject an incomplete pool and accept nothing when all choices are closed or
there is no strict improvement. Separate single/joint rankings remain visible.

All eleven previous keys are excluded. Three proposals in the original source
pool have closed identities; the new initializer uses owners 6 and 17 in mode 2,
reconstructed from the unchanged original A/W values and raw source centers.
Its augmented score is 217,105.498152 mm², with 76,364.670862 mm² original overlap.
[Fresh model readback]({NAME}/selected-model-controls.json) verifies all
81 coordinates, 528 weighted original/clearance pairs, 15 coefficient-1
auxiliary terms and every legal domain. All cog angles remain continuous.
Scalar score error is 2.911e-11 mm²; 152 directed gradient terms agree within
5.685e-14 mm under the existing documented nonsmooth conventions.

[The tested deadline helper and weight rule remain unchanged]({NAME}/inherited-controls.json).
All seven deadline controls and the bounded area-only update evidence are
retained. Source preparation is **18.187213 s**, including every previously
consumed stage and the new complete **0.564015 s** wrapper. The new independent
preflight wrapper closes in **1.475245 s**. No failed preflight or correction
is hidden, and no historical optimized candidate supplies a starting point.

## Closed finite pipeline

The controller preserves the three-call maximum, 8 s slices, selection deadline
at 52 s, source reserve boundary at 54 s and preparation-inclusive 60/90 s
limits. Runtime weights still use only the preceding augmented winner's area
losses. The minimum full augmented score among admissible one-owner and
two-owner proposals must improve the current score by more than 1e-6 mm².
All dynamic models are read back before their sole call.

[Both runtime decisions]({NAME}/runtime-choice-01.json) are [single-owner changes]({NAME}/runtime-choice-02.json):
owner 10 moves first to mode 1 and later to mode 0 under a new weight vector.
These are distinct complete objective/physical-mode/weight keys. The same
physical mode with different coordinates would not permit a repeated call.

| Epoch | Optimizer evaluations | Saved improvements | Best original overlap (mm²) | Its failed source pairs |
| --- | ---: | ---: | ---: | ---: |
| 0 | 113 | 93 | 39,195.692136 | 54 |
| 1 | 113 | 95 | 28,711.709644 | 46 |
| 2 | 99 | 86 | 20,445.492840 | 53 |

The last epoch has three distinct winners. Its augmented winner has
20,466.995065 mm² overlap and 51 failing pairs; its unweighted-area winner has
20,455.056285 mm² overlap and 51 failures. Its original-area winner above has
53 failures. These differences remain visible in [the complete epoch replay]({NAME}/epoch-reconciliation.json).

[Response verification]({NAME}/response-audit.json) reconstructs every
**{front['total_evaluation_records_verified']} evaluation record**, **{front['saved_points_verified']}
saved point**, both 528-coefficient updates, **12,792 runtime center trials**
and **5,708 full proposals**. All **18,500 runtime scores** are independently
reconstructed, and the merged choice is verified against the independent
minimum. All nine full66 winner outputs are read back, each covering 1,380
same-sheet pairs, 264 stock edges, 90 holes and 10,026 hole vertices. Fixed-part
and stock checks pass; no complete layout is valid.

Preparation-inclusive algorithm/shared totals are **53.219783/53.302369 s**.
Slice overruns are **0.048691, 0.028279 and 0.045614 s**, preserved within the
overall contract. [All five search processes close]({NAME}/closed-search-process.json)
with 121,098,240 bytes peak aggregate committed memory. The three
[new]({NAME}/closed-problem-00.json) [problem]({NAME}/closed-problem-01.json)
[keys]({NAME}/closed-problem-02.json) and all eleven earlier keys are closed.
The maximum-call stop cannot be extended; no native call or allocation
exclusion follows.

## Remaining geometry and missing neighborhood coverage

[Read-only outcome diagnosis]({NAME}/outcome-diagnostic.json) records
{diag['positive_area_pairs']} positive original/clearance pair terms,
{diag['flat_available_pair_gradient_count']} flat available pair gradients,
{diag['bracket_bracket_source_failures']} bracket/bracket failures and
{diag['cog_lower_y_negative_gradient_blocked']} cogs with lower-y descent blocked.
[Family composition]({NAME}/family-failures.json),
[full source failures]({NAME}/best-original-source-checks.json) and
[prior comparisons]({NAME}/prior-comparisons.json) preserve the negative results.

[Neighborhood coverage]({NAME}/neighborhood-coverage.json) verifies a limitation
in the original source and both runtime pools: **none of the 33 owners has
fixed-grid center trials in its current physical mode**, and all 15 cogs have
no such center trials at all. Their centers currently move only through local
continuous optimization. This identifies an omitted finite neighborhood;
it is not a proof that another placement exists.

[Next]({NAME}/next-step.json), preflight including current physical modes in
the source-grid relocation pool, while retaining incoming cog angles for grid
scoring and continuous angles in optimization. The prospective counts are
111 physical owner-mode options, 9,102 nominal centers and 5,911 raw proposals,
but only 2,854 distinct physical-mode vectors. Multiple coordinate candidates
can share a key, so complete per-key minima and all fourteen closed-key
exclusions must precede any new call. No broader geometry, model, selected
state or search is prepared. Existing optimized winners remain validation only.
Four earlier arrangements and all 440 allocation candidates remain unresolved.

The previous two checkpoints reached main **a69021b6** through an ordinary
atomic push after all six preceding jobs and their aggregate passed,
preserving 52 protected files. [The receipt]({NAME}/prior-main-push-receipt.json)
is retained. [At review]({NAME}/main-ci-at-review.json), its fresh CI has
{success} passed jobs and {live} live jobs; this checkpoint awaits the ordinary
push gate. Product code, README claims and releases are unchanged.

[Archive verification]({NAME}/archive-checks.json),
[manifest]({NAME}/raw-manifest.json), [source bindings]({NAME}/source-bindings.json),
[historical references]({NAME}/external-evidence.json) and
[runtime pins]({NAME}/runtime-bindings.json) preserve complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 best admissible augmented construction:** [independent policy, model and response audits]({link}) verify accepting the best strict-improving single or joint choice. Three validation contexts re-rank 8,562 independent score readbacks; the previously stopped single remains validation-only. A new original-source initializer excludes all eleven closed keys and retains all 528 area pairs, 15 coefficient-1 auxiliary terms, 81 coordinates and legal domains. Three new keys close after 325 optimizer evaluations; all 328 records, 274 saved points, 12,792 runtime centers, 5,708 proposals, 1,056 updated coefficients and nine full66 outputs replay. Both runtime choices are single-owner changes. Best original overlap is 20,445.492840 mm² with 53 failed pairs; an earlier epoch has 46 failed pairs and more overlap. Fixed-part and stock checks pass. Lower overlap does not establish packing validity or overall improvement. Complete preparation is 18.187213 s and algorithm/shared totals are 53.219783/53.302369 s; all processes close and three slice overruns remain. A read-only coverage check proves that the current physical mode has no fixed-grid relocation trials for any owner, including all 15 cogs. Next preflight the broader current-mode pool with complete per-key minima, independent geometry and deadline controls; no successor is prepared and different coordinates cannot reopen a closed key. All fourteen keys and the current pipeline remain closed. No native call or allocation exclusion follows. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. Prior checkpoints reached main a69021b6 normally, preserving 52 files; four fresh CI jobs pass and two remain live at review. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [best admissible augmented construction](../benchmarks/results/{NAME}.md).
The revised policy accepts the best strict-improving single or joint choice.
Three contexts re-rank 8,562 independent scores, and a new original-source
initializer excludes every prior closed key. Three distinct calls close at
the frozen maximum. All 328 evaluation records, 274 saved points, 12,792 runtime
centers, 5,708 full proposals and nine full66 winner outputs replay. Both
runtime choices are single-owner changes. Best original overlap falls to
20,445.492840 mm² but still fails 53 pairs; earlier epoch 1 has 46 failures and
more overlap. Fixed-part and stock checks pass. No valid packing is established.
Complete preparation is 18.187213 s; algorithm/shared totals are
53.219783/53.302369 s, with all descendants closed and slice overruns retained.
Current physical modes have no explicit fixed-grid relocation trials for any
owner, including all 15 cogs. Next preflight including those modes, preserving
all geometry and complete per-key minima. No broader successor is prepared.
All fourteen keys and this finite pipeline remain closed; no native validation
or allocation exclusion follows. Four earlier arrangements and 440 allocations
remain; H2/H5 stay at 60%. Prior checkpoints reached main a69021b6 normally,
preserving 52 files. Four fresh jobs pass and two native jobs remain live at
review; this checkpoint awaits the ordinary push gate. Product code, README
and releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
