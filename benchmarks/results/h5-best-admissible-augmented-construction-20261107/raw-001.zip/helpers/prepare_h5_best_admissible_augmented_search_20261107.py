"""Version the bounded controller and complete replay for merged admissibility."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
runner=(ROOT/'output/run_h5_adaptive_augmented_search_20261107.py').read_text(encoding='utf-8')
oldblock="""            singles=[r for r in records if not r['excluded'] and len(r['changes'])==1];joints=[r for r in records if not r['excluded'] and len(r['changes'])==2]
            single=min(singles,key=rank) if singles else None;joint=min(joints,key=rank) if joints else None;baseline=records[0]['augmented_objective_mm2'];improves=single is not None and joint is not None and joint['augmented_objective_mm2']<min(single['augmented_objective_mm2'],baseline)-1e-6
            write(folder/'selection.json',{'best_single':single,'best_joint':joint,'current_score':baseline,'joint_improves_current_and_single':improves})
            if not improves:stop='NO_IMPROVING_JOINT';break
            modes,model,point=apply_neighbor(lib,modes,incoming,weights,identity,joint);incoming=point.tolist()"""
newblock="""            selection=choose(records);write(folder/'selection.json',selection)
            if not selection['strictly_improves_current']:stop='NO_IMPROVING_ADMISSIBLE';break
            chosen=selection['accepted_choice'];modes,model,point=apply_neighbor(lib,modes,incoming,weights,identity,chosen);incoming=point.tolist()"""
changes={
    "BASE=ROOT/'output/h5-adaptive-augmented-preflight-20261107'":"BASE=ROOT/'output/h5-best-admissible-augmented-preflight-20261107'",
    '    from h5_weighted_original_model_20261107 import update_weights':'    from h5_weighted_original_model_20261107 import update_weights\n    from h5_augmented_admissible_choice_20261107 import choose',
    oldblock:newblock,
    "checked['joint_improves_current_and_single']":"checked['strictly_improves_current']",
    "'audit/deadline-controls.json','audit/selected-model-controls.json','audit/weight-update-controls.json'":"'audit/inherited-controls.json','audit/selected-model-controls.json','audit/choice-policy-controls.json','audit/policy-stop-controls.json'",
    "['h5_augmented_deadline_neighbors_20261107.py','h5_bracket_augmented_objective_20261107.py'":"['h5_augmented_admissible_choice_20261107.py','h5_augmented_admissible_readback_20261107.py','h5_augmented_deadline_neighbors_20261107.py','h5_bracket_augmented_objective_20261107.py'",
    'independently audited new original-source joint':'independently audited new original-source admissible choice',
    'Exclude all nine prior identities':'Exclude all eleven prior identities',
    'a joint must strictly improve current and best admissible single by1e-6':'accept the minimum augmented score among all admissible single and joint choices only if it strictly improves current by1e-6; retain both separate rankings and reject incomplete pools',
}
for a,b in changes.items():assert a in runner,a;runner=runner.replace(a,b)
audit=(ROOT/'output/audit_h5_adaptive_augmented_response_20261107.py').read_text(encoding='utf-8')
old="""        selection=verify_selection(lib,modes,incoming,weights,identity,regions,visited,records,aliases,trials,selections,OUT/f'epoch-{epoch:02d}-selection');assert selection==load(folder/'selection.json');centers+=len(trials);proposals+=len(records)"""
new="""        legacy=verify_selection(lib,modes,incoming,weights,identity,regions,visited,records,aliases,trials,selections,OUT/f'epoch-{epoch:02d}-selection');selection=load(folder/'selection.json')
        assert all(selection[k]==v for k,v in legacy.items())
        merged=verify_choice(records,load(OUT/f'epoch-{epoch:02d}-selection/proposal-score-controls.json'),selection);write(OUT/f'epoch-{epoch:02d}-merged-choice.json',merged);centers+=len(trials);proposals+=len(records)"""
changes={
    "BASE=ROOT/'output/h5-adaptive-augmented-preflight-20261107'":"BASE=ROOT/'output/h5-best-admissible-augmented-preflight-20261107'",
    'from h5_bracket_augmented_reference_20261107 import Reference':'from h5_bracket_augmented_reference_20261107 import Reference\nfrom h5_augmented_admissible_readback_20261107 import verify_choice',
    "['h5_adaptive_augmented_epoch_readback_20261107.py','h5_augmented_selection_readback_20261107.py'":"['h5_augmented_admissible_readback_20261107.py','h5_adaptive_augmented_epoch_readback_20261107.py','h5_augmented_selection_readback_20261107.py'",
    'len(old_closed)==9':'len(old_closed)==11',
    "len(old_closed)==result['historical_closed_keys']==9":"len(old_closed)==result['historical_closed_keys']==11",
    old:new,
    "if not selection['joint_improves_current_and_single']:":"if not selection['strictly_improves_current']:",
    "joint=selection['best_joint']":"joint=selection['accepted_choice']",
    'NO_IMPROVING_JOINT':'NO_IMPROVING_ADMISSIBLE',
    "'prior_closed_keys':9":"'prior_closed_keys':11",
}
for a,b in changes.items():assert a in audit,a;audit=audit.replace(a,b)
stage=(ROOT/'output/run_h5_best_admissible_augmented_stage_20261107.py').read_text(encoding='utf-8')
stage=stage.replace('stage=sys.argv[1]',"stage='response-audit'").replace("{'preparation':('prepare_h5_best_admissible_augmented_20261107.py',20),'audit':('audit_h5_best_admissible_augmented_20261107.py',60)}","{'response-audit':('audit_h5_best_admissible_augmented_response_20261107.py',900)}")
outputs={'run_h5_best_admissible_augmented_search_20261107.py':runner,'audit_h5_best_admissible_augmented_response_20261107.py':audit,'run_h5_best_admissible_augmented_response_stage_20261107.py':stage}
for name,source in outputs.items():compile(source,name,'exec');assert not (ROOT/'output'/name).exists()
for name,source in outputs.items():
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(source)
