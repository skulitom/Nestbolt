"""Read-only outcome and neighborhood coverage for the closed merged policy."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/diagnose_h5_adaptive_augmented_outcome_20261107.py').read_text(encoding='utf-8');source=source[:source.index("selection=load(BASE/'search/epoch-02/selection.json')")]
changes={
    "BASE=ROOT/'output/h5-adaptive-augmented-preflight-20261107'":"BASE=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';P=ROOT/'output/h5-adaptive-augmented-preflight-20261107'",
    "checked['best_original']['epoch']==1":"checked['best_original']['epoch']==2",
    'epoch-01':'epoch-02',
    "('prior_augmented_conditional',N)]":"('prior_augmented_conditional',N),('prior_adaptive_augmented',P)]",
    "N/'response-audit/checks.json',B/":"N/'response-audit/checks.json',P/'response-audit/checks.json',B/",
    "prior.get('source_pair_failures',prior.get('best_original_pair_failures'))":"prior.get('source_pair_failures',prior.get('best_original_pair_failures',prior.get('best_original',{}).get('pair_failures')))",
    "prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2'))":"prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2')))",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
source+='''
from h5_augmented_selection_readback_20261107 import independent_classes
from math import comb
lib=load(A/'library.json');classes=independent_classes(lib);coverage=[];bindings={}
for label,initial_path,trial_path in [('original_source',A/'initial-state.json',N/'center-trials.json'),('runtime_1',BASE/'search/epoch-01/opened.json',BASE/'search/epoch-01/center-trials.json'),('runtime_2',BASE/'search/epoch-02/opened.json',BASE/'search/epoch-02/center-trials.json')]:
    context=load(initial_path);modes=context.get('modes',context.get('incoming_modes'));trials=load(trial_path);assert len(trials)==6396;rows=[]
    for i,(family,_) in enumerate(lib['identities']):
        current_class=classes[family][modes[i]];own=[r for r in trials if r['owner']==i];current_trials=[r for r in own if classes[family][r['mode']]==current_class]
        assert len(current_trials)==0
        if family=='cog':assert len(own)==0
        rows.append({'owner':i,'identity':lib['identities'][i],'current_mode':modes[i],'current_physical_class':current_class,'physical_mode_classes':len(set(classes[family])),'actual_nominal_center_trials':len(own),'current_class_center_trials':0})
    coverage.append({'context':label,'owners':rows,'current_mode_owners_omitted_from_center_grid':33,'cog_owners_with_no_center_grid':15,'nominal_existing_trials':6396})
    for path in [initial_path,trial_path]:bindings[path.relative_to(ROOT).as_posix()]=digest(path)
counts=[len(set(classes[f])) for f,_ in lib['identities']];changed=[v-1 for v in counts];all_options=sum(counts);new_trials=sum(counts)*82;all_pairs=sum(counts[i]*counts[j] for i in range(33) for j in range(i+1,33));physical_keys=1+sum(changed)+sum(changed[i]*changed[j] for i in range(33) for j in range(i+1,33))
assert all_options==111 and new_trials==9102 and all_pairs==5799 and physical_keys==2854
write(OUT/'neighborhood-coverage.json',{'passed':True,'inputs':bindings,'contexts':coverage,'prospective_counts_only':{'physical_owner_mode_options_including_current':all_options,'nominal_center_trials_including_current':new_trials,'additional_current_mode_center_trials':33*82,'raw_current_single_joint_proposals':1+all_options+all_pairs,'distinct_physical_mode_vectors':physical_keys},'interpretation':'The existing selector only tests physically changed bracket/insert modes. It never tests fixed-grid relocation of the current mode for any owner, including all15cogs; their centers move only through local continuous optimization. A possible broader selector could include current physical modes while preserving angles and all domains. Many raw placements would alias the same problem key, so a complete per-key minimum and the closed-key exclusion must be applied before any single call. These are coverage/count observations only: no broader geometry scores, selected state or search have been prepared.','optimizer_calls':0,'candidate_changed':False,'new_initializer_prepared':False,'closed_pipeline_resumed':False})
'''
with (ROOT/'output/diagnose_h5_best_admissible_augmented_outcome_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
