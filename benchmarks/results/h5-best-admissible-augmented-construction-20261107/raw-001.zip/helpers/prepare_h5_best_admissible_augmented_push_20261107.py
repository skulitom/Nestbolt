"""Prepare the next ordinary push against the current main CI and exact refs."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/push_h5_adaptive_augmented_checkpoints_20261107.py').read_text(encoding='utf-8')
changes={
    'h5-adaptive-augmented-main-sync-20261107':'h5-best-admissible-augmented-main-sync-20261107',
    '193660c4e7b0840d32f870c6246341f580a3bcf3':'a69021b6f67de0cf1c01cbf3f2d33209d5cca4b9',
    '42374123784':'42377560004',
    "prefixes=('benchmarks/results/h5-augmented-conditional-construction-20261107','benchmarks/results/h5-adaptive-augmented-construction-20261107')":"prefixes=('benchmarks/results/h5-best-admissible-augmented-construction-20261107',)",
    "['h5-augmented-conditional-construction-20261107','h5-adaptive-augmented-construction-20261107']":"['h5-best-admissible-augmented-construction-20261107']",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
with (ROOT/'output/push_h5_best_admissible_augmented_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
