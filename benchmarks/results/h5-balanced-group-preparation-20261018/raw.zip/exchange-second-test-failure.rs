//! Isolated experiment: return complete actual obstruction sets while inserting
//! a last-sheet part, repair both sheets, then check the whole original job.
use super::*;
use jagua_rs::entities::Item;
use jagua_rs::geometry::geo_traits::TransformableFrom;

struct Proposal {
    victims: Vec<PItemKey>,
    incoming: DTransformation,
    blockers: usize,
    rank: usize,
    area: f32,
}

fn retain_proposal(out: &mut Vec<Proposal>, proposal: Proposal) {
    if let Some(previous) = out.iter().position(|p| p.victims == proposal.victims) {
        if out[previous].blockers <= proposal.blockers {
            return;
        }
        out.remove(previous);
    }
    out.push(proposal);
    out.sort_by(|a, b| {
        (a.blockers - a.victims.len())
            .cmp(&(b.blockers - b.victims.len()))
            .then(a.area.total_cmp(&b.area))
            .then(a.rank.cmp(&b.rank))
    });
    out.truncate(6);
}

fn proposals(
    receiver: &JLayout,
    incoming: &Item,
    rng: &mut Xoshiro256PlusPlus,
    clock: &Clock,
    until: f64,
) -> Vec<Proposal> {
    let bounds = receiver.container().outer_cd().bbox();
    let mut buffer = incoming.shape_cd().as_ref().clone();
    let mut samples = Vec::new();
    // Anchors make an actual obstruction, rather than a merely nearby part,
    // the return candidate. Align bounding-box corners after snapping rotation.
    for p in receiver.placed_items().values() {
        let dt = convert_sample_to_closest_feasible(p.d_transf(), incoming);
        buffer.transform_from(incoming.shape_cd(), &dt.compose());
        let a = buffer.bbox();
        let b = p.shape().bbox();
        let (x, y) = dt.translation();
        samples.push(
            DTransformation::new(
                dt.rotation(),
                (x + b.x_min - a.x_min, y + b.y_min - a.y_min),
            )
            .with_reflection(dt.reflected),
        );
    }
    if let Some(sampler) = UniformBBoxSampler::new(bounds, incoming, bounds) {
        samples.extend((0..128).map(|_| sampler.sample(rng)));
    }
    let mut collector = BasicHazardCollector::new();
    let mut out: Vec<Proposal> = Vec::new();
    for dt in samples {
        if clock.now() >= until {
            break;
        }
        buffer.transform_from(incoming.shape_cd(), &dt.compose());
        collector.clear();
        receiver
            .cde()
            .collect_poly_collisions(&buffer, &NoFilter, &mut collector);
        crate::separate::charge(clock, incoming, 1);
        if collector.is_empty()
            || collector.len() > 3
            || collector
                .iter()
                .any(|(_, h)| !matches!(h, BasicHazardEntity::PlacedItem { .. }))
        {
            continue;
        }
        // Moving every actual obstruction can leave a feasible receiver when
        // evicting only one leaves known collisions. Returned filled area can
        // increase while last-sheet height and material stay unchanged. Both
        // repairs and the whole-job material guard still control acceptance.
        // Keep the original smaller single-victim alternatives as a fallback.
        let blocked: Vec<_> = receiver
            .placed_items()
            .iter()
            .enumerate()
            .filter(|(_, (key, _))| {
                collector.iter().any(
                    |(_, h)| matches!(h, BasicHazardEntity::PlacedItem { pk, .. } if *pk == *key),
                )
            })
            .collect();
        let area: f32 = blocked.iter().map(|(_, (_, p))| p.item().area()).sum();
        if blocked.len() > 1 {
            retain_proposal(
                &mut out,
                Proposal {
                    victims: blocked.iter().map(|(_, (key, _))| *key).collect(),
                    incoming: dt,
                    blockers: collector.len(),
                    rank: blocked[0].0,
                    area,
                },
            );
        }
        // Stable receiver placement order, independent of tree traversal order.
        for (rank, (key, p)) in receiver.placed_items().iter().enumerate() {
            if p.item().area() >= incoming.area()
                || !collector.iter().any(
                    |(_, h)| matches!(h, BasicHazardEntity::PlacedItem { pk, .. } if *pk == key),
                )
            {
                continue;
            }
            let proposal = Proposal {
                victims: vec![key],
                incoming: dt,
                blockers: collector.len(),
                rank,
                area: p.item().area(),
            };
            retain_proposal(&mut out, proposal);
        }
    }
    out
}

// Only choose the reciprocal frame when every returned part permits it. The
// separator can still move the parts independently; this is an initial pose.
fn return_group_poses(
    victims: &[(PItemKey, std::sync::Arc<Item>, DTransformation)],
    incoming_here: DTransformation,
    incoming_before: DTransformation,
) -> Vec<DTransformation> {
    let (from_x, from_y) = incoming_here.translation();
    let (to_x, to_y) = incoming_before.translation();
    let translated = || {
        victims
            .iter()
            .map(|(_, _, previous)| {
                let (x, y) = previous.translation();
                DTransformation::new(previous.rotation(), (x + to_x - from_x, y + to_y - from_y))
                    .with_reflection(previous.reflected)
            })
            .collect()
    };
    // Keep the previous arithmetic exactly when the two frames already agree.
    if incoming_here.rotation() == incoming_before.rotation()
        && incoming_here.reflected == incoming_before.reflected
    {
        return translated();
    }
    let frame = incoming_here
        .compose()
        .inverse()
        .transform(&incoming_before.compose());
    let aligned: Option<Vec<_>> = victims
        .iter()
        .map(|(_, victim, previous)| {
            let pose = previous.compose().transform(&frame).decompose();
            victim.allowed_orientations().allows(&pose).then_some(pose)
        })
        .collect();
    aligned.unwrap_or_else(translated)
}

type IncomingMember = (PItemKey, std::sync::Arc<Item>, DTransformation);

// Try nearby copies of the same original part. Stable input order breaks ties;
// at most twelve anchors, two neighbours each and six distinct pairs are kept.
fn incoming_pairs(layout: &JLayout, keys: &[PItemKey]) -> Vec<Vec<PItemKey>> {
    let mut pairs = Vec::new();
    let mut seen = Vec::new();
    for (i, &key) in keys.iter().enumerate().take(12) {
        let a = &layout.placed_items()[key];
        let ba = a.shape().bbox();
        let mut neighbours: Vec<_> = keys
            .iter()
            .enumerate()
            .filter_map(|(j, &other)| {
                let b = &layout.placed_items()[other];
                if i == j || !std::sync::Arc::ptr_eq(a.item(), b.item()) {
                    return None;
                }
                let bb = b.shape().bbox();
                let dx = (ba.x_min + ba.x_max) - (bb.x_min + bb.x_max);
                let dy = (ba.y_min + ba.y_max) - (bb.y_min + bb.y_max);
                Some((dx * dx + dy * dy, j))
            })
            .collect();
        neighbours.sort_by(|a, b| a.0.total_cmp(&b.0).then(a.1.cmp(&b.1)));
        for (_, j) in neighbours.into_iter().take(2) {
            let pair = (i.min(j), i.max(j));
            if seen.contains(&pair) {
                continue;
            }
            seen.push(pair);
            pairs.push(vec![keys[pair.0], keys[pair.1]]);
            if pairs.len() == 6 {
                return pairs;
            }
        }
    }
    pairs
}

// Incoming groups must preserve their relative transform and every member's
// permissions. An illegal mapped orientation rejects this proposal as a whole.
fn incoming_group_poses(
    members: &[IncomingMember],
    anchor: DTransformation,
) -> Option<Vec<DTransformation>> {
    let old = members.first()?.2;
    let same = old.rotation() == anchor.rotation() && old.reflected == anchor.reflected;
    let frame = old.compose().inverse().transform(&anchor.compose());
    let (ox, oy) = old.translation();
    let (nx, ny) = anchor.translation();
    members
        .iter()
        .enumerate()
        .map(|(i, (_, item, previous))| {
            let pose = if i == 0 {
                anchor
            } else if same {
                let (px, py) = previous.translation();
                DTransformation::new(previous.rotation(), (px + nx - ox, py + ny - oy))
                    .with_reflection(previous.reflected)
            } else {
                previous.compose().transform(&frame).decompose()
            };
            item.allowed_orientations().allows(&pose).then_some(pose)
        })
        .collect()
}

fn paired_proposals(
    receiver: &JLayout,
    incoming: &[IncomingMember],
    rng: &mut Xoshiro256PlusPlus,
    clock: &Clock,
    until: f64,
) -> Vec<Proposal> {
    debug_assert_eq!(incoming.len(), 2);
    let anchor = &incoming[0].1;
    let bounds = receiver.container().outer_cd().bbox();
    let mut samples = Vec::new();
    let mut buffer = anchor.shape_cd().as_ref().clone();
    for p in receiver.placed_items().values() {
        let dt = convert_sample_to_closest_feasible(p.d_transf(), anchor);
        buffer.transform_from(anchor.shape_cd(), &dt.compose());
        let a = buffer.bbox();
        let b = p.shape().bbox();
        let (x, y) = dt.translation();
        samples.push(
            DTransformation::new(
                dt.rotation(),
                (x + b.x_min - a.x_min, y + b.y_min - a.y_min),
            )
            .with_reflection(dt.reflected),
        );
    }
    if let Some(sampler) = UniformBBoxSampler::new(bounds, anchor, bounds) {
        samples.extend((0..128).map(|_| sampler.sample(rng)));
    }
    let incoming_area: f32 = incoming.iter().map(|(_, item, _)| item.area()).sum();
    let mut collector = BasicHazardCollector::new();
    let mut out = Vec::new();
    for sample in samples {
        if clock.now() >= until {
            break;
        }
        let Some(poses) = incoming_group_poses(incoming, sample) else {
            continue;
        };
        let mut collisions = Vec::new();
        let mut allowed = true;
        for ((_, item, _), pose) in incoming.iter().zip(&poses) {
            buffer = item.shape_cd().as_ref().clone();
            buffer.transform_from(item.shape_cd(), &pose.compose());
            collector.clear();
            receiver
                .cde()
                .collect_poly_collisions(&buffer, &NoFilter, &mut collector);
            crate::separate::charge(clock, item, 1);
            for (_, hazard) in collector.iter() {
                if let BasicHazardEntity::PlacedItem { pk, .. } = hazard {
                    if !collisions.contains(pk) {
                        collisions.push(*pk);
                    }
                } else {
                    allowed = false;
                }
            }
            if !allowed || collisions.len() > 3 {
                break;
            }
        }
        if !allowed || collisions.is_empty() || collisions.len() > 3 {
            continue;
        }
        // Keep the complete union of both incoming members' actual obstructions.
        let victims: Vec<_> = receiver
            .placed_items()
            .iter()
            .enumerate()
            .filter(|(_, (key, _))| collisions.contains(key))
            .collect();
        let area: f32 = victims.iter().map(|(_, (_, p))| p.item().area()).sum();
        if area > incoming_area {
            continue;
        }
        retain_proposal(
            &mut out,
            Proposal {
                victims: victims.iter().map(|(_, (key, _))| *key).collect(),
                incoming: sample,
                blockers: victims.len(),
                rank: victims[0].0,
                area,
            },
        );
    }
    out
}

impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search<'_, '_, F> {
    fn exchange_report(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        layout: &JLayout,
        shape: Shape,
    ) -> Result<Report> {
        let mut sheets = frozen.to_vec();
        sheets.extend(strip.split(layout, shape.sheets)?);
        let layout = self.model.to_layout(&sheets);
        let started = Instant::now();
        let report = validate(self.model.job, &layout)?;
        self.clock.validated(self.model.job, &layout);
        self.check_cost = self.check_cost.max(started.elapsed().as_secs_f64());
        Ok(report)
    }

    /// At most one exchange. The original separator is untouched until both
    /// repairs and the independent whole-job material/geometry guard pass.
    pub(super) fn directed_exchange(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
    ) -> Result<usize> {
        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            return Ok(0);
        }
        let baseline = self.exchange_report(strip, frozen, &sep.layout, shape)?;
        if !baseline.valid {
            return Ok(0);
        }
        let before = baseline.metrics.as_ref().expect("valid baseline");
        let single = strip.container(Shape {
            sheets: 1,
            last: self.model.full_width,
        })?;
        let last_container = strip.container(Shape {
            sheets: 1,
            last: shape.last,
        })?;
        let last_index = shape.sheets - 1;
        let last_offset = strip.start(last_index);
        let mut incoming_keys = strip.in_last(&sep.layout, shape);
        incoming_keys.sort_by(|&a, &b| {
            sep.layout.placed_items()[b]
                .item()
                .area()
                .total_cmp(&sep.layout.placed_items()[a].item().area())
        });
        let mut fill = vec![0.0_f32; last_index];
        for p in sep
            .layout
            .placed_items()
            .values()
            .filter(|p| !strip.is_blocker(p))
        {
            let i = strip.sheet_of(p.shape());
            if i < last_index {
                fill[i] += p.item().area();
            }
        }
        let mut targets: Vec<_> = (0..last_index).collect();
        targets.sort_by(|&a, &b| fill[a].total_cmp(&fill[b]));
        let now = self.clock.now();
        let group_until = now + (self.last_step(until) - now).max(0.0) * 0.5;
        let mut choices = incoming_pairs(&sep.layout, &incoming_keys);
        choices.extend(incoming_keys.into_iter().map(|key| vec![key]));
        for selected in choices {
            let paired = selected.len() == 2;
            let exchange_until = if paired { group_until } else { until };
            if self.clock.now() >= self.last_step(exchange_until) {
                continue;
            }
            let incoming_key = selected[0];
            let members: Vec<_> = selected
                .iter()
                .map(|&key| {
                    let p = &sep.layout.placed_items()[key];
                    (key, p.item().clone(), shift(p.d_transf(), -last_offset))
                })
                .collect();
            let incoming = &sep.layout.placed_items()[incoming_key];
            let incoming_item = incoming.item().clone();
            let incoming_old = shift(incoming.d_transf(), -last_offset);
            for &target in targets.iter().take(3) {
                if self.clock.now() >= self.last_step(exchange_until) {
                    break;
                }
                let offset = strip.start(target);
                let mut receiver = JLayout::new(single.clone());
                let mut source = JLayout::new(last_container.clone());
                let mut changed_keys = Vec::new();
                for (key, p) in sep
                    .layout
                    .placed_items()
                    .iter()
                    .filter(|(_, p)| !strip.is_blocker(p))
                {
                    let i = strip.sheet_of(p.shape());
                    if i == target {
                        receiver.place_item(p.item(), shift(p.d_transf(), -offset));
                        changed_keys.push(key);
                    } else if i == last_index {
                        if !selected.contains(&key) {
                            source.place_item(p.item(), shift(p.d_transf(), -last_offset));
                        }
                        changed_keys.push(key);
                    }
                }
                self.clock
                    .charge(Work::RegisteredItem, changed_keys.len() as f64);
                let proposal_until = self.last_step(exchange_until);
                let candidates = if paired {
                    paired_proposals(
                        &receiver,
                        &members,
                        &mut self.rng,
                        &self.clock,
                        proposal_until,
                    )
                } else {
                    proposals(
                        &receiver,
                        &incoming_item,
                        &mut self.rng,
                        &self.clock,
                        proposal_until,
                    )
                };
                for proposal in candidates {
                    if self.clock.now() >= self.last_step(exchange_until) {
                        break;
                    }
                    self.stats.directed_exchange_attempts += 1;
                    self.stats.paired_exchange_attempts += u64::from(paired);
                    let victims: Vec<_> = proposal
                        .victims
                        .iter()
                        .map(|&key| {
                            let p = &receiver.placed_items()[key];
                            (key, p.item().clone(), p.d_transf())
                        })
                        .collect();
                    let mut next_receiver = JLayout::from_snapshot(&receiver.save());
                    for &(key, _, _) in &victims {
                        next_receiver.remove_item(key);
                    }
                    if paired {
                        let Some(poses) = incoming_group_poses(&members, proposal.incoming) else {
                            continue;
                        };
                        for ((_, item, _), pose) in members.iter().zip(poses) {
                            next_receiver.place_item(item, pose);
                        }
                    } else {
                        next_receiver.place_item(&incoming_item, proposal.incoming);
                    }
                    let mut next_source = JLayout::from_snapshot(&source.save());
                    let returned = if victims.len() == 1 {
                        vec![convert_sample_to_closest_feasible(
                            incoming_old,
                            &victims[0].1,
                        )]
                    } else {
                        return_group_poses(&victims, proposal.incoming, incoming_old)
                    };
                    for ((_, victim, _), pose) in victims.iter().zip(returned) {
                        next_source.place_item(victim, pose);
                    }
                    self.clock
                        .charge(Work::RegisteredItem, changed_keys.len() as f64);
                    let now = self.clock.now();
                    // Bound each pair so one hard proposal cannot consume all
                    // remaining opportunities. Each repair gets half the pair.
                    let pair_end = now + ((self.last_step(exchange_until) - now) * 0.5).min(0.4);
                    let middle = (now + pair_end) / 2.0;
                    let mut receiver_sep = Separator::new(
                        next_receiver,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    let (receiver_snapshot, receiver_tracker) =
                        receiver_sep.separate(&self.deadline(middle));
                    if receiver_tracker.total_loss() > 0.0 {
                        continue;
                    }
                    let mut source_sep = Separator::new(
                        next_source,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    let (source_snapshot, source_tracker) =
                        source_sep.separate(&self.deadline(pair_end));
                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(exchange_until)
                    {
                        continue;
                    }
                    let mut trial = JLayout::from_snapshot(&sep.layout.save());
                    for &key in &changed_keys {
                        trial.remove_item(key);
                    }
                    for (snapshot, start) in
                        [(receiver_snapshot, offset), (source_snapshot, last_offset)]
                    {
                        for p in JLayout::from_snapshot(&snapshot).placed_items().values() {
                            trial.place_item(p.item(), shift(p.d_transf(), start));
                        }
                    }
                    self.clock.charge(
                        Work::RegisteredItem,
                        (sep.layout.placed_items().len() + changed_keys.len()) as f64,
                    );
                    let report = self.exchange_report(strip, frozen, &trial, shape)?;
                    if !report.valid {
                        self.stats.rejected_layouts += 1;
                        continue;
                    }
                    let after = report.metrics.as_ref().expect("valid exchange");
                    if after.sheets_used > before.sheets_used
                        || after.material_area > before.material_area
                        || self.clock.now() >= exchange_until
                    {
                        continue;
                    }
                    sep.layout = trial;
                    sep.rebuild();
                    self.stats.directed_exchanges += 1;
                    self.stats.paired_exchanges += u64::from(paired);
                    return Ok(1);
                }
            }
        }
        Ok(0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nestbolt_validator::job::{Margins, Part, Stock};
    use nestbolt_validator::{Polygon, Units};

    fn rectangle(id: &str, width: f64, height: f64) -> Part {
        Part {
            id: id.into(),
            quantity: 1,
            geometry: vec![Polygon {
                outer: vec![[0.0, 0.0], [width, 0.0], [width, height], [0.0, height]],
                holes: vec![],
            }],
            rotations: Rotations::List { degrees: vec![0.0] },
            allow_mirror: false,
            priority: 1.0,
        }
    }

    fn fixture() -> (Job, Layout) {
        let job = Job {
            version: 1,
            name: "authored exchange".into(),
            units: Units::Mm,
            parts: vec![
                rectangle("filler", 60.0, 94.0),
                rectangle("return", 30.0, 20.0),
                rectangle("incoming", 30.0, 85.0),
            ],
            stocks: vec![Stock {
                id: "stock".into(),
                width: 100.0,
                height: 100.0,
                count: None,
                margins: Margins::default(),
                outline: vec![],
                defects: vec![],
            }],
            clearance: 0.2,
            edge_clearance: 1.0,
            mode: Mode::All,
        };
        let layout = Layout {
            version: 1,
            units: Units::Mm,
            sheets: (0..2)
                .map(|i| Sheet {
                    id: format!("sheet-{i}"),
                    stock_id: "stock".into(),
                })
                .collect(),
            placements: [
                ("filler", 0, [2.0, 2.0]),
                ("return", 0, [64.0, 2.0]),
                ("incoming", 1, [2.0, 2.0]),
            ]
            .into_iter()
            .map(|(id, sheet, translation)| Placement {
                part_id: id.into(),
                copy_index: 0,
                sheet_id: format!("sheet-{sheet}"),
                transform: RigidTransform {
                    translation,
                    rotation_radians: 0.0,
                    mirrored: false,
                },
            })
            .collect(),
        };
        (job, layout)
    }

    fn fingerprint(layout: &JLayout) -> String {
        format!(
            "{:?}",
            layout
                .placed_items()
                .iter()
                .map(|(k, p)| (k, p.item().idx(), p.d_transf()))
                .collect::<Vec<_>>()
        )
    }

    fn exercise(
        job: &Job,
        layout: &Layout,
        seed: u64,
        enabled: bool,
        expired: bool,
        frozen_count: usize,
    ) -> (usize, Layout, Stats) {
        let validation = validate(job, layout).unwrap();
        assert!(validation.valid, "{:?}", validation.violations);
        let model = Model::new(job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut search = Search {
            model: &model,
            allow_exchange: enabled,
            rng: Xoshiro256PlusPlus::seed_from_u64(seed),
            clock: clock.clone(),
            best: (layout.clone(), validation, 0.0),
            history: vec![],
            stats: Stats::default(),
            progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
            check_cost: 0.0,
            check_every: 5.0,
        };
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(layout).unwrap();
        let (frozen, window) = sheets.split_at(frozen_count);
        let mut shape = Shape {
            sheets: window.len(),
            last: model.full_width,
        };
        let initial = strip.layout(window, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut sep = Separator::new(
            strip.layout(window, shape).unwrap(),
            seed,
            EXPLORE,
            search.clock.clone(),
        );
        sep.pin(blocker_index(&model));
        assert_eq!(sep.tracker.total_loss(), 0.0);
        // Compare the same f32 internal frame before/after the exchange. The
        // public-to-internal conversion predates this operation and has its own
        // tests; comparing to the authored f64 coordinates conflates the two.
        let mut before_sheets = frozen.to_vec();
        before_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let before_layout = model.to_layout(&before_sheets);
        let before_report = validate(job, &before_layout).unwrap();
        assert!(before_report.valid);
        let before_material = before_report.metrics.as_ref().unwrap().material_area;
        let original = fingerprint(&sep.layout);
        let until = if expired {
            0.0
        } else {
            search.clock.now() + 3.0
        };
        let moved = search
            .directed_exchange(&strip, frozen, &mut sep, shape, until)
            .unwrap();
        if moved == 0 {
            assert_eq!(
                fingerprint(&sep.layout),
                original,
                "failed proposal mutated the original state"
            );
        }
        let mut after_sheets = frozen.to_vec();
        after_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let after = model.to_layout(&after_sheets);
        for i in 0..frozen_count {
            let id = format!("sheet-{i}");
            let before_fixed: Vec<_> = before_layout
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            let after_fixed: Vec<_> = after
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            assert_eq!(
                serde_json::to_value(before_fixed).unwrap(),
                serde_json::to_value(after_fixed).unwrap()
            );
        }
        let report = validate(job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert!(report.metrics.as_ref().unwrap().material_area <= before_material);
        assert_eq!(sep.tracker.total_loss(), 0.0);
        eprintln!(
            "authored exchange seed={seed} enabled={enabled} expired={expired} frozen={frozen_count} moved={moved} attempts={} material_before={before_material:.9} material_after={:.9}",
            search.stats.directed_exchange_attempts,
            report.metrics.as_ref().unwrap().material_area
        );
        (moved, after, search.stats)
    }

    #[test]
    fn window_search_reaches_exchange_before_gap_filling() {
        let (mut job, mut layout) = fixture();
        // This small last-sheet part fits an earlier gap. A successful fill
        // must not bypass the exchange opportunity for the large incoming part.
        job.parts.push(rectangle("gap-part", 5.0, 5.0));
        layout.placements.push(Placement {
            part_id: "gap-part".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [36.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        for (enabled, budget) in [(true, 20.0), (false, 20.0), (true, 0.0)] {
            let report = validate(&job, &layout).unwrap();
            assert!(report.valid);
            let before_material = report.metrics.as_ref().unwrap().material_area;
            let model = Model::new(&job).unwrap();
            let clock = Clock::new(Timing::Work, 30.0);
            let mut search = Search {
                model: &model,
                allow_exchange: enabled,
                rng: Xoshiro256PlusPlus::seed_from_u64(0),
                clock,
                best: (layout.clone(), report, 0.0),
                history: vec![],
                stats: Stats::default(),
                progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
                check_cost: 0.0,
                check_every: 5.0,
            };
            search
                .window_search(model.sheets_of(&layout).unwrap(), budget, 0.2, 2)
                .unwrap();
            let checked = validate(&job, &search.best.0).unwrap();
            assert!(checked.valid);
            assert!(checked.metrics.as_ref().unwrap().material_area <= before_material);
            if enabled && budget > 0.0 {
                assert!(search.stats.directed_exchange_attempts > 0);
                assert!(search.stats.directed_exchanges > 0);
            } else {
                assert_eq!(search.stats.directed_exchange_attempts, 0);
                assert_eq!(search.stats.directed_exchanges, 0);
            }
            eprintln!(
                "window exchange enabled={enabled} budget={budget} attempts={} accepted={} valid={}",
                search.stats.directed_exchange_attempts,
                search.stats.directed_exchanges,
                checked.valid
            );
        }
    }

    #[test]
    fn directed_exchange_returns_smaller_actual_obstruction() {
        let (job, layout) = fixture();
        for seed in 0..5 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            assert_eq!(moved, 1, "seed {seed}, {stats:?}");
            assert_eq!(stats.directed_exchanges, 1);
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
            );
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
            );
        }
    }

    #[test]
    fn directed_exchange_expired_or_disabled_leaves_layout_intact() {
        let (job, layout) = fixture();
        for (enabled, expired) in [(true, true), (false, false)] {
            let (moved, _, stats) = exercise(&job, &layout, 0, enabled, expired, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.directed_exchange_attempts, 0);
        }
    }

    #[test]
    fn directed_exchange_rejects_returns_that_cannot_fit() {
        let (mut job, layout) = fixture();
        job.parts[2] = rectangle("incoming", 20.0, 10.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchanges, 0);
    }

    #[test]
    fn directed_exchange_preserves_frozen_sheets_and_mirror_contract() {
        let (mut job, mut layout) = fixture();
        job.parts.push(rectangle("fixed", 20.0, 20.0));
        for p in &mut layout.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        let fixed = Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        };
        layout.placements.push(fixed.clone());
        job.parts[2].allow_mirror = true;
        let incoming = layout
            .placements
            .iter_mut()
            .find(|p| p.part_id == "incoming")
            .unwrap();
        incoming.transform.mirrored = true;
        incoming.transform.translation[0] += 30.0;
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 1);
        assert_eq!(moved, 1);
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "fixed" && p.sheet_id == "sheet-0")
        );
    }

    #[test]
    fn directed_exchange_failed_source_repair_leaves_layout_intact() {
        let (mut job, layout) = fixture();
        job.parts[1] = rectangle("return", 5.0, 90.0);
        job.parts[2] = rectangle("incoming", 30.0, 30.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert!(stats.directed_exchange_attempts > 0);
    }

    #[test]
    fn directed_exchange_respects_stock_defects() {
        let (mut job, layout) = fixture();
        job.edge_clearance = job.clearance;
        job.stocks[0].defects.push(Polygon {
            outer: vec![[96.0, 20.0], [98.0, 20.0], [98.0, 30.0], [96.0, 30.0]],
            holes: vec![],
        });
        let (moved, _, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
    }

    fn obstruction_set_fixture(count: usize, return_height: f64) -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.parts[1] = rectangle("return", 30.0, return_height);
        job.parts[1].quantity = count as u32;
        let template = layout
            .placements
            .iter()
            .find(|p| p.part_id == "return")
            .unwrap()
            .clone();
        for copy in 1..count {
            let mut part = template.clone();
            part.copy_index = copy as u32;
            part.transform.translation[1] += copy as f64 * (return_height + 2.0);
            layout.placements.push(part);
        }
        (job, layout)
    }

    #[test]
    fn obstruction_set_moves_two_blockers_atomically() {
        let (job, layout) = obstruction_set_fixture(2, 20.0);
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            2
        );
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
        );
    }

    #[test]
    fn obstruction_set_moves_three_blockers_atomically() {
        let (job, layout) = obstruction_set_fixture(3, 20.0);
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            3
        );
    }

    #[test]
    fn complete_sets_can_return_equal_or_greater_area_at_the_same_material() {
        // The independently validated witness retains a 33 mm charged height:
        // a 2550/2700 mm2 incoming part can trade for three 900 mm2 squares.
        // Their relative positions fit in the otherwise empty return sheet.
        for incoming_width in [85.0, 90.0] {
            let (mut job, mut layout) = obstruction_set_fixture(3, 30.0);
            for part in &mut job.parts {
                for polygon in &mut part.geometry {
                    for point in &mut polygon.outer {
                        point.swap(0, 1);
                    }
                }
            }
            job.parts[2] = rectangle("incoming", incoming_width, 30.0);
            for part in &mut layout.placements {
                part.transform.translation.swap(0, 1);
            }
            let original = validate(&job, &layout).unwrap();
            assert!(original.valid);
            assert_eq!(original.metrics.unwrap().material_area, 13300.0);
            let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
            assert_eq!(moved, 1);
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
            );
        }
    }
    fn return_frame_witness() -> (Job, Layout) {
        let job = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../examples/return-frame-job.json"
        )))
        .unwrap();
        let layout = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../examples/return-frame-before.json"
        )))
        .unwrap();
        (job, layout)
    }

    fn witness_victims(
        receiver: &JLayout,
    ) -> Vec<(PItemKey, std::sync::Arc<Item>, DTransformation)> {
        receiver
            .placed_items()
            .iter()
            .filter(|(_, p)| p.item().external_id() == 2)
            .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
            .collect()
    }

    #[test]
    fn return_frame_rotates_into_the_vacated_gap_without_extra_material() {
        let (job, before) = return_frame_witness();
        let original = validate(&job, &before).unwrap();
        assert!(original.valid);
        assert_eq!(original.metrics.unwrap().material_area, 19500.0);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        let incoming = sheets[1]
            .layout()
            .placed_items()
            .values()
            .find(|p| p.item().external_id() == 3)
            .unwrap();
        let incoming_old = incoming.d_transf();
        let placed = RigidTransform {
            translation: [2.0, 64.0],
            rotation_radians: 0.0,
            mirrored: false,
        };
        let incoming_new = model.internal(incoming.item().idx(), &placed);
        let victims = witness_victims(sheets[0].layout());
        assert_eq!(victims.len(), 3);
        let poses = return_group_poses(&victims, incoming_new, incoming_old);
        let mut after = before.clone();
        let p = after
            .placements
            .iter_mut()
            .find(|p| p.part_id == "incoming")
            .unwrap();
        p.sheet_id = "sheet-0".into();
        p.transform = placed;
        for ((p, (_, item, _)), pose) in after
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "return")
            .zip(&victims)
            .zip(&poses)
        {
            assert!(item.allowed_orientations().allows(pose));
            p.sheet_id = "sheet-1".into();
            p.transform = model.external(item.idx(), pose);
        }
        let report = validate(&job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert_eq!(report.metrics.unwrap().material_area, 19500.0);
        let (fx, fy) = incoming_new.translation();
        let (tx, ty) = incoming_old.translation();
        for (p, (_, item, previous)) in after
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "return")
            .zip(&victims)
        {
            let (x, y) = previous.translation();
            let translated = DTransformation::new(previous.rotation(), (x + tx - fx, y + ty - fy))
                .with_reflection(previous.reflected);
            p.transform = model.external(item.idx(), &translated);
        }
        assert!(!validate(&job, &after).unwrap().valid);
    }

    #[test]
    fn return_frame_keeps_incumbent_when_roundoff_increases_charged_material() {
        let (mut job, before) = return_frame_witness();
        job.parts[1] = rectangle("source-filler", 20.0, 94.0);
        let (moved, _, stats) = exercise(&job, &before, 0, true, false, 0);
        // This exact authored attempt repairs both sheets but raises charged
        // material by 0.0007 mm2. The strict guard must retain the incumbent;
        // exercise also requires exact internal-state preservation on failure.
        assert_eq!(moved, 0);
        assert!(stats.directed_exchange_attempts > 0);
        assert_eq!(stats.directed_exchanges, 0);
    }

    #[test]
    fn directed_exchange_uses_the_rotated_return_gap() {
        let (mut job, mut before) = return_frame_witness();
        // Keep the incoming part first in the area-ranked source list. A narrow
        // tall neighbour still obstructs the old translation-only return pose.
        job.parts[1] = rectangle("source-filler", 20.0, 94.0);
        // A separate fixed top strip controls this sheet's occupied height.
        // It isolates successful frame use from the original fixture's strict
        // floating-point material rejection, which has its own test above.
        job.parts.push(rectangle("ceiling", 94.0, 1.0));
        before.placements.push(Placement {
            part_id: "ceiling".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 97.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(stats.directed_exchanges, 1);
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
        );
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            3
        );
    }

    #[test]
    fn return_frame_preserves_permitted_reflection_and_relative_positions() {
        let (mut job, before) = return_frame_witness();
        job.parts[2].allow_mirror = true;
        job.parts[3].allow_mirror = true;
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        let mut victims = witness_victims(sheets[0].layout());
        for (i, (_, _, previous)) in victims.iter_mut().enumerate() {
            *previous = DTransformation::new(0.0, (12.0 + 6.0 * i as f32, 23.0));
        }
        let here = DTransformation::new(0.0, (10.0, 20.0));
        let old =
            DTransformation::new(std::f32::consts::FRAC_PI_2, (40.0, 50.0)).with_reflection(true);
        let poses = return_group_poses(&victims, here, old);
        // (x,y) relative to the old incoming frame maps to (y,x), then (40,50).
        for (i, (pose, (_, item, _))) in poses.iter().zip(&victims).enumerate() {
            assert!(pose.reflected && item.allowed_orientations().allows(pose));
            let (x, y) = pose.translation();
            assert!((x - 43.0).abs() < 0.0001);
            assert!((y - (52.0 + 6.0 * i as f32)).abs() < 0.0001);
            let matrix = pose.compose();
            let matrix = matrix.matrix();
            assert!(matrix[0][0].into_inner().abs() < 0.0001);
            assert!((matrix[0][1].into_inner() - 1.0).abs() < 0.0001);
            assert!((matrix[1][0].into_inner() - 1.0).abs() < 0.0001);
            assert!(matrix[1][1].into_inner().abs() < 0.0001);
        }
    }

    #[test]
    fn return_frame_falls_back_for_the_whole_group_if_any_orientation_is_forbidden() {
        let (job, before) = return_frame_witness();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        for reflected in [false, true] {
            let mut victims = witness_victims(sheets[0].layout());
            if !reflected {
                // Only the first member forbids the quarter-turn. All members
                // must retain the old translation, rather than deform the set.
                victims[0].1 = sheets[0]
                    .layout()
                    .placed_items()
                    .values()
                    .find(|p| p.item().external_id() == 0)
                    .unwrap()
                    .item()
                    .clone();
            }
            let here = DTransformation::new(3.0 * std::f32::consts::FRAC_PI_2, (10.0, 20.0));
            let old = DTransformation::new(
                if reflected {
                    std::f32::consts::FRAC_PI_2
                } else {
                    0.0
                },
                (40.0, 50.0),
            )
            .with_reflection(reflected);
            let poses = return_group_poses(&victims, here, old);
            for (pose, (_, item, previous)) in poses.iter().zip(&victims) {
                assert!(item.allowed_orientations().allows(pose));
                assert_eq!(pose.rotation(), previous.rotation());
                assert_eq!(pose.reflected, previous.reflected);
                let (x, y) = previous.translation();
                assert_eq!(pose.translation(), (x + 40.0 - 10.0, y + 50.0 - 20.0));
            }
        }
    }
    fn balanced_fixture() -> (Job, Layout) {
        (
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/balanced-group-job.json"
            )))
            .unwrap(),
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/balanced-group-before.json"
            )))
            .unwrap(),
        )
    }

    #[test]
    fn balanced_pair_moves_two_incoming_and_three_returns() {
        let (job, layout) = balanced_fixture();
        assert_eq!(
            validate(&job, &layout)
                .unwrap()
                .metrics
                .unwrap()
                .material_area,
            19700.0
        );
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            assert_eq!(moved, 1, "{stats:?}");
            assert_eq!(stats.paired_exchanges, 1);
            assert!(stats.paired_exchange_attempts > 0);
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
                    .count(),
                2
            );
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
        }
    }

    #[test]
    fn balanced_pair_disabled_or_expired_preserves_incumbent() {
        let (job, layout) = balanced_fixture();
        for (enabled, expired) in [(false, false), (true, true)] {
            let (moved, _, stats) = exercise(&job, &layout, 0, enabled, expired, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.paired_exchange_attempts, 0);
            assert_eq!(stats.paired_exchanges, 0);
        }
    }

    #[test]
    fn balanced_pair_preserves_frozen_prefix() {
        let (mut job, mut layout) = balanced_fixture();
        job.parts.push(rectangle("fixed", 10.0, 10.0));
        for p in &mut layout.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        layout.placements.push(Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 1);
        assert_eq!(moved, 1);
        assert_eq!(stats.paired_exchanges, 1);
    }

    #[test]
    fn balanced_pair_rejects_illegal_group_orientation() {
        let (mut job, layout) = balanced_fixture();
        for mirrors in [false, true] {
            job.parts
                .iter_mut()
                .find(|p| p.id == "incoming")
                .unwrap()
                .allow_mirror = mirrors;
            let model = Model::new(&job).unwrap();
            let sheets = model.sheets_of(&layout).unwrap();
            let source = sheets[1].layout();
            let members: Vec<_> = source
                .placed_items()
                .iter()
                .filter(|(_, p)| p.item().area() == 1350.0)
                .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
                .collect();
            assert_eq!(members.len(), 2);
            let old = members[0].2;
            let reflected =
                DTransformation::new(old.rotation(), (30.0, 3.0)).with_reflection(!old.reflected);
            if !mirrors {
                assert!(incoming_group_poses(&members, reflected).is_none());
            } else {
                let permitted = convert_sample_to_closest_feasible(reflected, &members[0].1);
                assert!(permitted.reflected);
                assert!(incoming_group_poses(&members, permitted).is_some());
            }
            assert!(
                incoming_group_poses(
                    &members,
                    DTransformation::new(old.rotation() + std::f32::consts::FRAC_PI_2, (0.0, 0.0))
                        .with_reflection(old.reflected)
                )
                .is_none()
            );
            let shifted = incoming_group_poses(
                &members,
                DTransformation::new(old.rotation(), (3.0, 4.0)).with_reflection(old.reflected),
            )
            .unwrap();
            let old_delta = (
                members[1].2.translation().0 - members[0].2.translation().0,
                members[1].2.translation().1 - members[0].2.translation().1,
            );
            let new_delta = (
                shifted[1].translation().0 - shifted[0].translation().0,
                shifted[1].translation().1 - shifted[0].translation().1,
            );
            let scale = members
                .iter()
                .map(|(_, _, pose)| pose.translation().0.abs().max(pose.translation().1.abs()))
                .fold(1.0_f32, f32::max);
            let tolerance = 4.0 * f32::EPSILON * scale;
            assert!((old_delta.0 - new_delta.0).abs() <= tolerance);
            assert!((old_delta.1 - new_delta.1).abs() <= tolerance);
        }
    }

    #[test]
    fn balanced_pair_selection_is_unique_bounded_and_identity_safe() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let item = source
            .placed_items()
            .values()
            .find(|p| p.item().area() == 1350.0)
            .unwrap()
            .item();
        let mut many = JLayout::new(source.container().clone());
        let keys: Vec<_> = (0..20)
            .map(|i| many.place_item(item, DTransformation::new(0.0, (i as f32 * 32.0, 0.0))))
            .collect();
        let pairs = incoming_pairs(&many, &keys);
        assert_eq!(pairs.len(), 6);
        assert_eq!(pairs, incoming_pairs(&many, &keys));
        for (i, pair) in pairs.iter().enumerate() {
            assert_eq!(pair.len(), 2);
            assert_ne!(pair[0], pair[1]);
            assert!(!pairs[..i].contains(pair));
        }
        let other_model = Model::new(&job).unwrap();
        let other_sheets = other_model.sheets_of(&layout).unwrap();
        let other = other_sheets[1]
            .layout()
            .placed_items()
            .values()
            .find(|p| p.item().area() == 1350.0)
            .unwrap()
            .item();
        let key = many.place_item(other, DTransformation::new(0.0, (0.0, 47.0)));
        assert!(incoming_pairs(&many, &[keys[0], key]).is_empty());
    }

    #[test]
    fn balanced_pair_falls_back_to_a_valid_single_exchange() {
        let (mut job, layout) = balanced_fixture();
        let incoming = job.parts.iter_mut().find(|p| p.id == "incoming").unwrap();
        let quantity = incoming.quantity;
        *incoming = rectangle("incoming", 30.0, 20.0);
        incoming.quantity = quantity;
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(stats.paired_exchange_attempts, 0);
        assert_eq!(stats.paired_exchanges, 0);
        assert_eq!(stats.directed_exchanges, 1);
    }

    #[test]
    fn balanced_pair_without_return_room_preserves_incumbent() {
        let (mut job, mut layout) = balanced_fixture();
        let incoming = job.parts.iter_mut().find(|p| p.id == "incoming").unwrap();
        *incoming = rectangle("incoming", 30.0, 44.9);
        incoming.quantity = 2;
        for p in layout
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "incoming")
        {
            p.transform.translation[1] = if p.copy_index == 0 { 1.01 } else { 46.12 };
        }
        job.parts.push(rectangle("source-extra", 30.0, 7.7));
        layout.placements.push(Placement {
            part_id: "source-extra".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [2.0, 91.23],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        // The source fits 2*44.9 + 7.7 plus spacing. Three returned squares
        // plus that extra part need 98.3 mm in a 98 mm side band.
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0, "{stats:?}");
        assert_eq!(stats.directed_exchanges, 0);
        assert_eq!(stats.paired_exchanges, 0);
    }
}
