    fn balanced_fixture() -> (Job, Layout) {
        (
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/balanced-group-job.json"
            )))
            .unwrap(),
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/balanced-group-before.json"
            )))
            .unwrap(),
        )
    }

    #[test]
    fn balanced_pair_moves_two_incoming_and_three_returns() {
        let (job, layout) = balanced_fixture();
        assert_eq!(
            validate(&job, &layout)
                .unwrap()
                .metrics
                .unwrap()
                .material_area,
            19700.0
        );
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            assert_eq!(moved, 1, "{stats:?}");
            assert_eq!(stats.paired_exchanges, 1);
            assert!(stats.paired_exchange_attempts > 0);
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
                    .count(),
                2
            );
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
        }
    }

    #[test]
    fn balanced_pair_disabled_or_expired_preserves_incumbent() {
        let (job, layout) = balanced_fixture();
        for (enabled, expired) in [(false, false), (true, true)] {
            let (moved, _, stats) = exercise(&job, &layout, 0, enabled, expired, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.paired_exchange_attempts, 0);
            assert_eq!(stats.paired_exchanges, 0);
        }
    }

    #[test]
    fn balanced_pair_preserves_frozen_prefix() {
        let (mut job, mut layout) = balanced_fixture();
        job.parts.push(rectangle("fixed", 10.0, 10.0));
        for p in &mut layout.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        layout.placements.push(Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 1);
        assert_eq!(moved, 1);
        assert_eq!(stats.paired_exchanges, 1);
    }

    #[test]
    fn balanced_pair_rejects_illegal_group_orientation() {
        let (mut job, layout) = balanced_fixture();
        for mirrors in [false, true] {
            job.parts
                .iter_mut()
                .find(|p| p.id == "incoming")
                .unwrap()
                .allow_mirror = mirrors;
            let model = Model::new(&job).unwrap();
            let sheets = model.sheets_of(&layout).unwrap();
            let source = sheets[1].layout();
            let members: Vec<_> = source
                .placed_items()
                .iter()
                .filter(|(_, p)| p.item().area() == 1350.0)
                .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
                .collect();
            assert_eq!(members.len(), 2);
            let old = members[0].2;
            let reflected =
                DTransformation::new(old.rotation(), (30.0, 3.0)).with_reflection(!old.reflected);
            if !mirrors {
                assert!(incoming_group_poses(&members, reflected).is_none());
            } else {
                let permitted = model.internal(members[0].1.idx(), &RigidTransform {
                    translation: [32.0, 2.0], rotation_radians: 0.0, mirrored: true,
                });
                assert!(permitted.reflected);
                assert!(incoming_group_poses(&members, permitted).is_some());
            }
            assert!(
                incoming_group_poses(
                    &members,
                    DTransformation::new(old.rotation() + std::f32::consts::FRAC_PI_2, (0.0, 0.0))
                        .with_reflection(old.reflected)
                )
                .is_none()
            );
            let shifted = incoming_group_poses(
                &members,
                DTransformation::new(old.rotation(), (3.0, 4.0)).with_reflection(old.reflected),
            )
            .unwrap();
            let old_delta = (
                members[1].2.translation().0 - members[0].2.translation().0,
                members[1].2.translation().1 - members[0].2.translation().1,
            );
            let new_delta = (
                shifted[1].translation().0 - shifted[0].translation().0,
                shifted[1].translation().1 - shifted[0].translation().1,
            );
            let scale = members
                .iter()
                .map(|(_, _, pose)| pose.translation().0.abs().max(pose.translation().1.abs()))
                .fold(1.0_f32, f32::max);
            let tolerance = 4.0 * f32::EPSILON * scale;
            assert!((old_delta.0 - new_delta.0).abs() <= tolerance);
            assert!((old_delta.1 - new_delta.1).abs() <= tolerance);
        }
    }

    #[test]
    fn balanced_pair_selection_is_unique_bounded_and_identity_safe() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let item = source
            .placed_items()
            .values()
            .find(|p| p.item().area() == 1350.0)
            .unwrap()
            .item();
        let mut many = JLayout::new(source.container().clone());
        let keys: Vec<_> = (0..20)
            .map(|i| many.place_item(item, DTransformation::new(0.0, (i as f32 * 32.0, 0.0))))
            .collect();
        let pairs = incoming_pairs(&many, &keys);
        assert_eq!(pairs.len(), 6);
        assert_eq!(pairs, incoming_pairs(&many, &keys));
        for (i, pair) in pairs.iter().enumerate() {
            assert_eq!(pair.len(), 2);
            assert_ne!(pair[0], pair[1]);
            assert!(!pairs[..i].contains(pair));
        }
        let other_model = Model::new(&job).unwrap();
        let other_sheets = other_model.sheets_of(&layout).unwrap();
        let other = other_sheets[1]
            .layout()
            .placed_items()
            .values()
            .find(|p| p.item().area() == 1350.0)
            .unwrap()
            .item();
        let key = many.place_item(other, DTransformation::new(0.0, (0.0, 47.0)));
        assert!(incoming_pairs(&many, &[keys[0], key]).is_empty());
    }

    #[test]
    fn balanced_pair_falls_back_to_a_valid_single_exchange() {
        let (mut job, layout) = balanced_fixture();
        let incoming = job.parts.iter_mut().find(|p| p.id == "incoming").unwrap();
        let quantity = incoming.quantity;
        *incoming = rectangle("incoming", 30.0, 20.0);
        incoming.quantity = quantity;
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(stats.paired_exchange_attempts, 0);
        assert_eq!(stats.paired_exchanges, 0);
        assert_eq!(stats.directed_exchanges, 1);
    }

    #[test]
    fn balanced_pair_without_return_room_preserves_incumbent() {
        let (mut job, mut layout) = balanced_fixture();
        let incoming = job.parts.iter_mut().find(|p| p.id == "incoming").unwrap();
        *incoming = rectangle("incoming", 30.0, 44.9);
        incoming.quantity = 2;
        for p in layout
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "incoming")
        {
            p.transform.translation[1] = if p.copy_index == 0 { 1.01 } else { 46.12 };
        }
        job.parts.push(rectangle("source-extra", 30.0, 7.7));
        layout.placements.push(Placement {
            part_id: "source-extra".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [2.0, 91.23],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        // The source fits 2*44.9 + 7.7 plus spacing. Three returned squares
        // plus that extra part need 98.3 mm in a 98 mm side band.
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0, "{stats:?}");
        assert_eq!(stats.directed_exchanges, 0);
        assert_eq!(stats.paired_exchanges, 0);
    }
