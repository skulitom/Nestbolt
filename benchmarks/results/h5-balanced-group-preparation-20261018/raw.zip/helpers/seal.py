from pathlib import Path
from hashlib import sha256
import difflib,json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-balanced-group-probe-20261018'
out=root/'benchmarks/results/h5-balanced-group-preparation-20261018'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build-v2.json');public=load(probe/'public-checks/checks.json')
assert build['all_checks_passed'] and public['all_checks_passed']
assert '97 passed; 0 failed' in (probe/'core-tests-v3.log').read_text(encoding='utf-8')
review=load(probe/'test-review/review.json')
assert review['independent_fallback_validation_passed'] and review['runtime_prefix_exact']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for name,expected in plan['added_files'].items():assert digest(probe/'candidate'/name)==expected
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8')
assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
before=(Path(plan['old_probe'])/'candidate'/plan['changed_files'][0]).read_text(encoding='utf-8')
after=(probe/'candidate'/plan['changed_files'][0]).read_text(encoding='utf-8')
assert after[after.index('#[cfg(test)]'):].startswith(before[before.index('#[cfg(test)]'):].rsplit('\n}',1)[0])
start='                    if source_tracker.total_loss() > 0.0'
acceptance=after[after.index(start):after.index('#[cfg(test)]')]
acceptance=acceptance.replace('exchange_until','until').replace('                    self.stats.paired_exchanges += u64::from(paired);\n','')
assert acceptance==before[before.index(start):before.index('#[cfg(test)]')]
for snippet in ['.min(0.4);','let middle = (now + pair_end) / 2.0;']:
    assert before.count(snippet)==after.count(snippet)==1
assert (probe/'candidate/crates/core/src/sheets/vstrip.rs').read_bytes()==(Path(plan['old_probe'])/'candidate/crates/core/src/sheets/vstrip.rs').read_bytes()
(probe/'candidate-final.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='return-frame-candidate',tofile='balanced-pair-candidate')),encoding='utf-8',newline='\n')
out.mkdir()
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_balanced_group.py','build_h5_balanced_group.py','build_h5_balanced_group_v2.py','build_h5_balanced_group_v3.py','balanced_group_helper.rs','balanced_group_tests.rs',
             'balanced_group_tests-initial-failures.rs','prepare_balanced_group_test_repairs.py','validate_balanced_group_fallback.py',
             'prepare_balanced_group_mirror_check.py',
             'prepare_balanced_group_checks.py','check_h5_balanced_group_public.py','check_h5_balanced_group_harness.py']:
    files['helpers/'+name]=root/'output'/name
files['helpers/seal.py']=Path(__file__);files['helpers/pilot.py']=root/'scripts/h5_balanced_group_pilot.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(archive),'bytes':archive.stat().st_size,'members':inventory,'all_members_and_crc_verified':True})
write(out/'checks.json',{'all_functional_checks_pass':True,'optimized_core_passed':97,'all_90_previous_tests_retained':True,
    'new_balanced_pair_tests':7,'strict_lint_pass':True,'public_observer_outcomes':10,'public_CLI_cross_checks':4,
    'initial_test_failures_preserved_and_reviewed':True,'unexpected_fallback_independently_validated':True,
    'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,'pilot_harness_tests':5,
    'whole_post_repair_acceptance_logic_unchanged':True,'pair_phase_has_stricter_deadline':True,
    'original_outer_exchange_budget_unchanged':True,'production_files_unchanged':True,'binaries':build['binaries'],
    'measured_search_started':False,'H5_complete':False,'integrated':False,'completed_weight_percent':60})
for name in ['preparation.json','build-v2.json','candidate.patch','candidate-final.patch','pilot-method.json']:shutil.copyfile(probe/name,out/name)
doc='''# Balanced incoming-pair preparation — 2026-10-18

The isolated candidate passes 97 optimized core tests, including all 90 prior
tests, strict lint, ten authored observer outcomes, four public CLI comparisons
and five adversarial paired-harness checks. Normal output is exact apart from
elapsed wall time; common fixed-work replays agree. Production is unchanged.

The candidate tries two nearby copies of the same original part together.
It considers at most twelve anchors, two nearest neighbours per anchor and six
distinct pairs in stable order. Incoming members preserve relative transforms;
every mapped orientation must be permitted. Each proposal returns the complete
union of actual obstructions, at most three parts, whose original combined area
is no greater than that of the incoming pair. It never takes a partial union.

Pair attempts share at most half the existing exchange window. Single-incoming
choices follow in the remaining window. Existing pair-repair caps, whole-job
geometry/material checks, incumbent preservation and the outer shared ten-percent
budget/1.2-second cap stay. Pair attempts and acceptances have omitted-zero
counters. The failed source-reuse experiment is not included.

Seven new tests cover the previously independently validated two-to-three witness,
disabled/expired operation, frozen-sheet preservation, group orientation and
relative transforms, bounded unique identity-safe pair selection, valid single
fallback and failure with an unchanged incumbent. All old strict-material/defect/reflection tests
remain. The fixture files are exact copies of the saved authored witness.

The initial run passed 94 tests and failed two new test assumptions. The tests
had used public angles in the rotated internal frame and expected a valid
single exchange to fail. Original sources/logs remain. The latter layout passes
the public CLI validator at unchanged material. Corrected orientation checks
use the internal frame; the old rejection case remains as a positive fallback
test, alongside a new constrained source-return case. Runtime code is unchanged
by these repairs. A second retained run passed 96 tests and exposed a further
test assumption: the nearest-pose sampler may choose an unmirrored pose. The
final test supplies an explicit permitted public mirrored transform through
the existing Model conversion. The internal f32 consistency check does not change
the independent geometry or material thresholds.

The subsequent 72-outcome pilot retains four jobs, two kerfs, three seeds,
three rotating sequential arms, 60-second searches and eight physical CCD0
cores. Its block, scoring, case and measurement functions remain AST-identical
to the previous pilot. A functioning authored case does not demonstrate real
job improvement. The +1% material limit and full 13-job H5 requirement remain.
No held-out access or integration; H2/H5 remain open at 60%.
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-balanced-group-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''

## 2026-10-18 — Qualify balanced incoming-pair exchanges

[The isolated candidate](benchmarks/results/h5-balanced-group-preparation-20261018.md)
passes 97 optimized core tests (all 90 prior tests plus seven new), strict lint,
ten authored observer outcomes, four public CLI comparisons and five paired
harness checks. The authored two-to-three exchange passes with exact quantities
and independent validity/material checks. Normal output stays exact and common
fixed-work replay passes. Every source/binary/archive member verifies.

The two original new-test failures are retained. One confused public and
internal angles; the other admitted a valid single exchange, independently
confirmed by the public CLI. Test-only repairs preserve that positive fallback
and add a constrained rejection case; runtime code is unchanged by the repairs.

Two nearby copies may move together against their complete obstruction union,
using at most half the existing exchange window before the single-part path.
Orientation, quantity, repair, material, deadline and incumbent guards remain.
The original outer budget and failed prior results stay unchanged. The paired
pilot keeps the original scoring and +1% limit; no benchmark claim, production
integration, reserved-input access or H5 credit. H2/H5 remain open at 60%.
''')
print(json.dumps({'sealed':str(out),'members':len(inventory),'bytes':archive.stat().st_size}))
