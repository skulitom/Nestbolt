from pathlib import Path
from hashlib import sha256
import json,subprocess,shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-balanced-group-probe-20261018';out=probe/'test-review'
before=(probe/'exchange-first-test-failure.rs').read_text(encoding='utf-8').split('#[cfg(test)]',1)[0]
after=(probe/'candidate/crates/core/src/sheets/vstrip/exchange.rs').read_text(encoding='utf-8').split('#[cfg(test)]',1)[0]
assert before==after,'Runtime changed during test-only repairs'
command=[str(root/'target/release/nestbolt.exe'),'validate','--job',str(out/'fallback-job.json'),'--layout',str(out/'fallback-layout.json')]
r=subprocess.run(command,capture_output=True,timeout=30)
(out/'validate-stdout.json').write_bytes(r.stdout);(out/'validate-stderr.log').write_bytes(r.stderr)
(out/'validate-command.json').write_text(json.dumps({'command':command,'exit_code':r.returncode},indent=2)+'\n',encoding='utf-8',newline='\n')
report=json.loads(r.stdout);assert r.returncode==0 and report['valid']
assert abs(report['metrics']['material_area']-19699.9994)<1e-6
p=out/'review.json';review=json.loads(p.read_bytes())
review['independent_fallback_validation_pending']=False
review['independent_fallback_validation_passed']=True
review['runtime_prefix_exact']=True
review['CLI_sha256']=sha256((root/'target/release/nestbolt.exe').read_bytes()).hexdigest()
p.write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'validate.py')
print(json.dumps({'valid':True,'material':report['metrics']['material_area'],'runtime_prefix_exact':True}))
