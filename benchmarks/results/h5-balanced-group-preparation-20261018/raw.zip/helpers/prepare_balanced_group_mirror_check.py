from pathlib import Path
import json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-balanced-group-probe-20261018'
source=(probe/'candidate/crates/core/src/sheets/vstrip/exchange.rs').read_text(encoding='utf-8')
tests=source[source.index('    fn balanced_fixture()'):source.rindex('\n}')]
(root/'output/balanced_group_tests.rs').write_text(tests+'\n',encoding='utf-8',newline='\n')
review_path=probe/'test-review/review.json';review=json.loads(review_path.read_bytes())
review['second_full_tests']={'passed':96,'failed':1}
review['second_orientation_review']='The closest-feasible sampler need not retain a requested reflection. Use Model.internal on an explicit permitted public mirrored transform to exercise the group reflection mapping.'
review_path.write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(root/'output/build_h5_balanced_group.py').read_text(encoding='utf-8')
s=s.replace("(label+'.log')","(label+'-v3.log')").replace("'progress.json'","'progress-v3.json'").replace("'build-failure.json'","'build-failure-v3.json'")
(root/'output/build_h5_balanced_group_v3.py').write_text(s,encoding='utf-8',newline='\n')
assert source.split('#[cfg(test)]',1)[0]==(probe/'exchange-first-test-failure.rs').read_text(encoding='utf-8').split('#[cfg(test)]',1)[0]
print('Prepared an explicit permitted mirrored test transform; runtime remains unchanged.')
