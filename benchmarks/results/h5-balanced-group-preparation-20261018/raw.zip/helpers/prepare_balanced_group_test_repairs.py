from pathlib import Path
import json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-balanced-group-probe-20261018'
source=(probe/'candidate/crates/core/src/sheets/vstrip/exchange.rs').read_text(encoding='utf-8')
tests=source[source.index('    fn balanced_fixture()'):source.rindex('\n}')]
(root/'output/balanced_group_tests.rs').write_text(tests+'\n',encoding='utf-8',newline='\n')
p=root/'output/prepare_h5_balanced_group.py';s=p.read_text(encoding='utf-8').replace("'new_tests':6","'new_tests':7")
p.write_text(s,encoding='utf-8',newline='\n')
plan=json.loads((probe/'preparation.json').read_bytes());plan['new_tests']=7
plan['test_review']='Two original test failures preserved. Correct orientation expectations to the Model strip frame; retain the unexpectedly valid original rejection case as a single-exchange fallback test; add a genuinely constrained source-return fixture. Runtime code unchanged.'
(probe/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(root/'output/build_h5_balanced_group.py').read_text(encoding='utf-8')
s=s.replace("(label+'.log')","(label+'-v2.log')").replace("'progress.json'","'progress-v2.json'").replace("'build-failure.json'","'build-failure-v2.json'")
(root/'output/build_h5_balanced_group_v2.py').write_text(s,encoding='utf-8',newline='\n')
log=(probe/'new-test-diagnosis.log').read_text(encoding='utf-8')
out=probe/'test-review';out.mkdir()
for label,name in [('BALANCED_REJECTION_JOB ','fallback-job.json'),('BALANCED_REJECTION_LAYOUT ','fallback-layout.json')]:
    data=json.loads(next(line.removeprefix(label) for line in log.splitlines() if line.startswith(label)))
    (out/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
review={'original_full_tests':{'passed':94,'failed':2},'diagnostic_tests':{'passed':4,'failed':2},
    'orientation_evidence':'The Model rotates public sheet coordinates by -90 degrees. The saved source transforms and permitted rotations are 4.712389 radians; zero was not a permitted internal translation anchor.',
    'fallback_evidence':'The original small-incoming case makes one valid single-part exchange, no paired attempt, at unchanged internal material 19699.9994 mm2. It is retained as a positive fallback test.',
    'new_rejection_fixture':'Two 30x44.9 incoming parts and one 30x7.7 extra fit beside the source filler. The selected three 30x30 returns plus extra need 98.3 mm including clearance in a 98 mm side band.',
    'runtime_code_changed':False,'initial_failures_preserved':True,'current_new_tests':7,
    'independent_fallback_validation_pending':True}
(out/'review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Preserved failed test assumptions; prepared corrected tests and a separate rejection fixture.')
