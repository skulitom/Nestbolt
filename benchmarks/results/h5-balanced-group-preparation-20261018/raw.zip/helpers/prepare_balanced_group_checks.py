from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-balanced-group-probe-20261018'
for src,dst in [('check_h5_return_frame_public.py','check_h5_balanced_group_public.py'),('check_h5_return_frame_harness.py','check_h5_balanced_group_harness.py')]:
    s=(root/'output'/src).read_text(encoding='utf-8').replace('h5-return-frame-probe-20261017','h5-balanced-group-probe-20261018').replace('h5_return_frame_pilot','h5_balanced_group_pilot')
    p=root/'output'/dst;assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
reference=root/'scripts/h5_return_reuse_pilot.py';original=reference.read_text(encoding='utf-8');s=original
s=s.replace('h5-return-reuse-probe-20261018','h5-balanced-group-probe-20261018').replace('h5-return-reuse-preparation-20261018','h5-balanced-group-preparation-20261018')
s=s.replace('The candidate retains the best compatible return-sheet separator across repeated assignments within one exchange call, keeping',
            'The candidate first tries two nearby copies against their complete obstruction group within half the existing exchange window, keeping')
s=s.replace('Isolated compatible return-repair reuse candidate','Isolated balanced incoming-pair candidate')
s=s.replace("    paths.extend([ROOT/'benchmarks/results/h5-return-capacity-diagnosis-20261017/verification.json',", "    paths.extend([ROOT/'benchmarks/results/h5-return-reuse-stage-diagnosis-20261018/verification.json',\n                  ROOT/'benchmarks/results/h5-balanced-exchange-witness-20261017/checks.json',\n                  ROOT/'benchmarks/results/h5-return-capacity-diagnosis-20261017/verification.json',")
s=s.replace("'previous_failed_pilot': 'benchmarks/results/h5-return-frame-pilot-20261017/results.json'", "'previous_failed_pilot': 'benchmarks/results/h5-return-reuse-pilot-20261018/results.json'")
s=s.replace("diagnostic = ROOT/'benchmarks/results/h5-complete-stage-diagnosis-20261017'", "diagnostic = ROOT/'benchmarks/results/h5-return-reuse-stage-diagnosis-20261018'")
s=s.replace("'h5_complete_stage_diagnosis.py' in arg", "'h5_return_reuse_stage_diagnosis.py' in arg")
names=['blocks','summarize','case','measure']
def body(t,name):return ast.dump(next(n for n in ast.parse(t).body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False)
for name in names:assert body(s,name)==body(original,name)
p=root/'scripts/h5_balanced_group_pilot.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
record={'reference':reference.relative_to(root).as_posix(),'reference_sha256':sha256(reference.read_bytes()).hexdigest(),
    'runner':p.relative_to(root).as_posix(),'runner_sha256':sha256(p.read_bytes()).hexdigest(),'unchanged_function_AST':names,
    'thresholds_geometry_and_budgets_unchanged':True,'prerequisites':'Verified failed reuse pilot and repair-stage traces, independent balanced-group witness and completed H4 recovery/scale.'}
(probe/'pilot-method.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
