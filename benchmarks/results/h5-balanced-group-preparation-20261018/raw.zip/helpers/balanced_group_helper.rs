type IncomingMember = (PItemKey, std::sync::Arc<Item>, DTransformation);

// Try nearby copies of the same original part. Stable input order breaks ties;
// at most twelve anchors, two neighbours each and six distinct pairs are kept.
fn incoming_pairs(layout: &JLayout, keys: &[PItemKey]) -> Vec<Vec<PItemKey>> {
    let mut pairs = Vec::new();
    let mut seen = Vec::new();
    for (i, &key) in keys.iter().enumerate().take(12) {
        let a = &layout.placed_items()[key];
        let ba = a.shape().bbox();
        let mut neighbours: Vec<_> = keys.iter().enumerate().filter_map(|(j, &other)| {
            let b = &layout.placed_items()[other];
            if i == j || !std::sync::Arc::ptr_eq(a.item(), b.item()) { return None; }
            let bb = b.shape().bbox();
            let dx = (ba.x_min + ba.x_max) - (bb.x_min + bb.x_max);
            let dy = (ba.y_min + ba.y_max) - (bb.y_min + bb.y_max);
            Some((dx * dx + dy * dy, j))
        }).collect();
        neighbours.sort_by(|a, b| a.0.total_cmp(&b.0).then(a.1.cmp(&b.1)));
        for (_, j) in neighbours.into_iter().take(2) {
            let pair = (i.min(j), i.max(j));
            if seen.contains(&pair) { continue; }
            seen.push(pair);
            pairs.push(vec![keys[pair.0], keys[pair.1]]);
            if pairs.len() == 6 { return pairs; }
        }
    }
    pairs
}

// Incoming groups must preserve their relative transform and every member's
// permissions. An illegal mapped orientation rejects this proposal as a whole.
fn incoming_group_poses(members: &[IncomingMember], anchor: DTransformation) -> Option<Vec<DTransformation>> {
    let old = members.first()?.2;
    let same = old.rotation() == anchor.rotation() && old.reflected == anchor.reflected;
    let frame = old.compose().inverse().transform(&anchor.compose());
    let (ox, oy) = old.translation();
    let (nx, ny) = anchor.translation();
    members.iter().enumerate().map(|(i, (_, item, previous))| {
        let pose = if i == 0 { anchor } else if same {
            let (px, py) = previous.translation();
            DTransformation::new(previous.rotation(), (px + nx - ox, py + ny - oy)).with_reflection(previous.reflected)
        } else {
            previous.compose().transform(&frame).decompose()
        };
        item.allowed_orientations().allows(&pose).then_some(pose)
    }).collect()
}

fn paired_proposals(receiver: &JLayout, incoming: &[IncomingMember], rng: &mut Xoshiro256PlusPlus,
                    clock: &Clock, until: f64) -> Vec<Proposal> {
    debug_assert_eq!(incoming.len(), 2);
    let anchor = &incoming[0].1;
    let bounds = receiver.container().outer_cd().bbox();
    let mut samples = Vec::new();
    let mut buffer = anchor.shape_cd().as_ref().clone();
    for p in receiver.placed_items().values() {
        let dt = convert_sample_to_closest_feasible(p.d_transf(), anchor);
        buffer.transform_from(anchor.shape_cd(), &dt.compose());
        let a = buffer.bbox(); let b = p.shape().bbox(); let (x, y) = dt.translation();
        samples.push(DTransformation::new(dt.rotation(), (x + b.x_min - a.x_min, y + b.y_min - a.y_min)).with_reflection(dt.reflected));
    }
    if let Some(sampler) = UniformBBoxSampler::new(bounds, anchor, bounds) {
        samples.extend((0..128).map(|_| sampler.sample(rng)));
    }
    let incoming_area: f32 = incoming.iter().map(|(_, item, _)| item.area()).sum();
    let mut collector = BasicHazardCollector::new();
    let mut out = Vec::new();
    for sample in samples {
        if clock.now() >= until { break; }
        let Some(poses) = incoming_group_poses(incoming, sample) else { continue; };
        let mut collisions = Vec::new();
        let mut allowed = true;
        for ((_, item, _), pose) in incoming.iter().zip(&poses) {
            buffer = item.shape_cd().as_ref().clone();
            buffer.transform_from(item.shape_cd(), &pose.compose());
            collector.clear();
            receiver.cde().collect_poly_collisions(&buffer, &NoFilter, &mut collector);
            crate::separate::charge(clock, item, 1);
            for (_, hazard) in collector.iter() {
                if let BasicHazardEntity::PlacedItem { pk, .. } = hazard {
                    if !collisions.contains(pk) { collisions.push(*pk); }
                } else { allowed = false; }
            }
            if !allowed || collisions.len() > 3 { break; }
        }
        if !allowed || collisions.is_empty() || collisions.len() > 3 { continue; }
        // Keep the complete union of both incoming members' actual obstructions.
        let victims: Vec<_> = receiver.placed_items().iter().enumerate()
            .filter(|(_, (key, _))| collisions.contains(key)).collect();
        let area: f32 = victims.iter().map(|(_, (_, p))| p.item().area()).sum();
        if area > incoming_area { continue; }
        retain_proposal(&mut out, Proposal {
            victims: victims.iter().map(|(_, (key, _))| *key).collect(),
            incoming: sample, blockers: victims.len(), rank: victims[0].0, area,
        });
    }
    out
}
