"""Isolate bounded exchanges of two nearby copies for a complete obstruction group."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib,json,shutil,sys
root=Path(__file__).resolve().parents[1]
out=root/'output/h5-balanced-group-probe-20261018';out.mkdir()
old=root/'output/h5-return-frame-probe-20261017'
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
before=path.read_text(encoding='utf-8');text=before
assert digest(path)=='17e9c64a28399e42c1212357b93058bf1ea5a4f3d91206432e53adf401a8d912'
def replace(a,b):
    global text
    assert text.count(a)==1,a;text=text.replace(a,b)
marker="impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search<'_, '_, F> {"
replace(marker,(root/'output/balanced_group_helper.rs').read_text(encoding='utf-8')+'\n'+marker)
replace('''        for incoming_key in incoming_keys {
            let incoming =''','''        let now = self.clock.now();
        let group_until = now + (self.last_step(until) - now).max(0.0) * 0.5;
        let mut choices = incoming_pairs(&sep.layout, &incoming_keys);
        choices.extend(incoming_keys.into_iter().map(|key| vec![key]));
        for selected in choices {
            let paired = selected.len() == 2;
            let exchange_until = if paired { group_until } else { until };
            if self.clock.now() >= self.last_step(exchange_until) { continue; }
            let incoming_key = selected[0];
            let members: Vec<_> = selected.iter().map(|&key| {
                let p = &sep.layout.placed_items()[key];
                (key, p.item().clone(), shift(p.d_transf(), -last_offset))
            }).collect();
            let incoming =''')
# All per-proposal checks share the selected phase deadline; the original
# whole-call/early-call bounds stay in place. Expired pair work reaches singles.
start=text.index('        for selected in choices {');end=text.index('\n#[cfg(test)]',start)
body=text[start:end]
body=body.replace('self.last_step(until)','self.last_step(exchange_until)').replace('self.clock.now() >= until','self.clock.now() >= exchange_until')
body=body.replace('''                    return Ok(0);
                }
                let offset''','''                    break;
                }
                let offset''')
body=body.replace('''                        return Ok(0);
                    }
                    self.stats.directed_exchange_attempts''','''                        break;
                    }
                    self.stats.directed_exchange_attempts''')
text=text[:start]+body+text[end:]
replace('                        if key != incoming_key {','                        if !selected.contains(&key) {')
replace('''                let candidates = proposals(
                    &receiver,
                    &incoming_item,
                    &mut self.rng,
                    &self.clock,
                    proposal_until,
                );''','''                let candidates = if paired {
                    paired_proposals(&receiver, &members, &mut self.rng, &self.clock, proposal_until)
                } else {
                    proposals(&receiver, &incoming_item, &mut self.rng, &self.clock, proposal_until)
                };''')
replace('''                    self.stats.directed_exchange_attempts += 1;''','''                    self.stats.directed_exchange_attempts += 1;
                    self.stats.paired_exchange_attempts += u64::from(paired);''')
replace('''                    next_receiver.place_item(&incoming_item, proposal.incoming);''','''                    if paired {
                        let Some(poses) = incoming_group_poses(&members, proposal.incoming) else { continue; };
                        for ((_, item, _), pose) in members.iter().zip(poses) {
                            next_receiver.place_item(item, pose);
                        }
                    } else {
                        next_receiver.place_item(&incoming_item, proposal.incoming);
                    }''')
replace('''                    self.stats.directed_exchanges += 1;''','''                    self.stats.directed_exchanges += 1;
                    self.stats.paired_exchanges += u64::from(paired);''')
closing=text.rindex('\n}')
text=text[:closing]+'\n'+(root/'output/balanced_group_tests.rs').read_text(encoding='utf-8')+text[closing:]
path.write_text(text,encoding='utf-8',newline='\n')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='return-frame-candidate',tofile='balanced-pair-candidate')),encoding='utf-8',newline='\n')
stats='crates/core/src/sheets.rs';p=out/'candidate'/stats;s=p.read_text(encoding='utf-8');needle='    pub directed_exchanges: u64,';assert s.count(needle)==1
p.write_text(s.replace(needle,needle+'\n    #[serde(skip_serializing_if = "is_zero")]\n    pub paired_exchange_attempts: u64,\n    #[serde(skip_serializing_if = "is_zero")]\n    pub paired_exchanges: u64,'),encoding='utf-8',newline='\n')
added={}
for source,name in [('job.json','balanced-group-job.json'),('before.json','balanced-group-before.json')]:
    target=out/'candidate/examples'/name
    shutil.copyfile(root/'benchmarks/results/h5-balanced-exchange-witness-20261017'/source,target)
    added[target.relative_to(out/'candidate').as_posix()]=digest(target)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'scope':__doc__,'old_probe':str(old),'changed_files':[rel,stats],
    'added_files':added,'production_digest':source_digest(),
    'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
    'target':str(root/'output/h5-balanced-group-target-20261018'),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),
    'policy':'Two nearby copies of the same original Item; at most twelve anchors, two neighbours each, six unique pairs. Full actual obstruction union of at most three parts, returned original area no greater than combined incoming area. Preserve permitted relative incoming transforms; reciprocal return mapping and both repair/whole-job guards remain. Pairs share at most half the existing exchange window, followed by the original single-incoming choices. Original ten-percent/1.2-second outer bound unchanged. No cache-reuse candidate changes included.',
    'new_tests':7,'all_90_existing_tests_retained':True,'measured_search_started':False,'H5_complete':False,'integrated':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'prepare.py')
build=(root/'output/build_h5_return_reuse.py').read_text(encoding='utf-8').replace('h5-return-reuse-probe-20261018','h5-balanced-group-probe-20261018')
build=build.replace("    assert digest(out/'baseline-observer.exe')==plan['baseline_observer_sha256']", "    for name,expected in plan['added_files'].items():assert digest(out/'candidate'/name)==expected\n    assert digest(out/'baseline-observer.exe')==plan['baseline_observer_sha256']")
(root/'output/build_h5_balanced_group.py').write_text(build,encoding='utf-8',newline='\n')
print(json.dumps({'prepared':str(out),'new_tests':7,'production_digest':plan['production_digest']}))
