//! Isolated experiment: return complete actual obstruction sets while inserting
//! a last-sheet part, repair both sheets, then check the whole original job.
use super::*;
use jagua_rs::entities::Item;
use jagua_rs::geometry::geo_traits::TransformableFrom;

// Diagnostic copy: aggregate observations only; no decision or budget changes.
#[derive(Default, serde::Serialize)]
struct ExchangeTrace {
    disabled_or_expired: bool,
    baseline_invalid: bool,
    proposals: usize,
    expired_before_attempt: usize,
    samplings: Vec<SamplingTrace>,
    attempts: Vec<AttemptTrace>,
}
#[derive(Default, serde::Serialize)]
struct SamplingTrace {
    incoming_area: f32,
    samples: usize,
    examined: usize,
    collision_free: usize,
    over_three_collisions: usize,
    non_item_collision: usize,
    multi_eligible_smaller: usize,
    multi_eligible_not_smaller: usize,
    smallest_not_smaller_area_ratio: Option<f32>,
    retained_victim_counts: Vec<usize>,
    retained_blocker_counts: Vec<usize>,
}
#[derive(serde::Serialize)]
struct AttemptTrace {
    incoming_area: f32,
    returned_area: f32,
    victims: usize,
    blockers: usize,
    receiver_loss: Option<f32>,
    source_loss: Option<f32>,
    receiver_initial_loss: Option<f32>,
    source_initial_loss: Option<f32>,
    source_fresh_loss: Option<f32>,
    source_reused: Option<bool>,
    source_initial_weighted_loss: Option<f32>,
    source_best_weighted_loss: Option<f32>,
    source_elapsed_seconds: Option<f64>,
    source_available_budget: Option<f64>,
    source_inventory: Option<Vec<usize>>,
    before_material: f64,
    after_material: Option<f64>,
    frame: serde_json::Value,
    outcome: &'static str,
}
impl Drop for ExchangeTrace {
    fn drop(&mut self) {
        eprintln!(
            "OBSTRUCTION_DIAG {}",
            serde_json::to_string(self).expect("diagnostic serialization")
        );
    }
}

fn observed_pose(pose: DTransformation) -> serde_json::Value {
    serde_json::json!({"rotation":pose.rotation(),"reflected":pose.reflected,"translation":pose.translation()})
}

fn observed_return_frame(
    victims: &[(PItemKey, std::sync::Arc<Item>, DTransformation)],
    here: DTransformation,
    old: DTransformation,
    actual: &[DTransformation],
) -> serde_json::Value {
    let same = here.rotation() == old.rotation() && here.reflected == old.reflected;
    let frame = here.compose().inverse().transform(&old.compose());
    let hypothetical: Vec<_> = victims
        .iter()
        .map(|(_, item, previous)| {
            let pose = previous.compose().transform(&frame).decompose();
            (pose, item.allowed_orientations().allows(&pose))
        })
        .collect();
    let mode = if victims.len() == 1 {
        "single"
    } else if same {
        "same_frame_translation"
    } else if hypothetical.iter().all(|(_, allowed)| *allowed) {
        "reciprocal"
    } else {
        "forbidden_translation"
    };
    let members: Vec<_> = victims.iter().zip(actual).zip(hypothetical).map(|(((_,item,previous),actual),(hypothetical,allowed))| {
        serde_json::json!({"external_id":item.external_id(),"previous":observed_pose(*previous),
            "hypothetical":observed_pose(hypothetical),"hypothetical_allowed":allowed,
            "actual":observed_pose(*actual),"actual_allowed":item.allowed_orientations().allows(actual)})
    }).collect();
    serde_json::json!({"mode":mode,"incoming_before":observed_pose(old),"incoming_here":observed_pose(here),"members":members})
}

struct Proposal {
    victims: Vec<PItemKey>,
    incoming: DTransformation,
    blockers: usize,
    rank: usize,
    area: f32,
}

fn retain_proposal(out: &mut Vec<Proposal>, proposal: Proposal) {
    if let Some(previous) = out.iter().position(|p| p.victims == proposal.victims) {
        if out[previous].blockers <= proposal.blockers {
            return;
        }
        out.remove(previous);
    }
    out.push(proposal);
    out.sort_by(|a, b| {
        (a.blockers - a.victims.len())
            .cmp(&(b.blockers - b.victims.len()))
            .then(a.area.total_cmp(&b.area))
            .then(a.rank.cmp(&b.rank))
    });
    out.truncate(6);
}

fn proposals(
    receiver: &JLayout,
    incoming: &Item,
    rng: &mut Xoshiro256PlusPlus,
    clock: &Clock,
    until: f64,
    trace: &mut ExchangeTrace,
) -> Vec<Proposal> {
    let mut sampling = SamplingTrace {
        incoming_area: incoming.area(),
        ..Default::default()
    };
    let bounds = receiver.container().outer_cd().bbox();
    let mut buffer = incoming.shape_cd().as_ref().clone();
    let mut samples = Vec::new();
    // Anchors make an actual obstruction, rather than a merely nearby part,
    // the return candidate. Align bounding-box corners after snapping rotation.
    for p in receiver.placed_items().values() {
        let dt = convert_sample_to_closest_feasible(p.d_transf(), incoming);
        buffer.transform_from(incoming.shape_cd(), &dt.compose());
        let a = buffer.bbox();
        let b = p.shape().bbox();
        let (x, y) = dt.translation();
        samples.push(
            DTransformation::new(
                dt.rotation(),
                (x + b.x_min - a.x_min, y + b.y_min - a.y_min),
            )
            .with_reflection(dt.reflected),
        );
    }
    if let Some(sampler) = UniformBBoxSampler::new(bounds, incoming, bounds) {
        samples.extend((0..128).map(|_| sampler.sample(rng)));
    }
    let mut collector = BasicHazardCollector::new();
    let mut out: Vec<Proposal> = Vec::new();
    sampling.samples = samples.len();
    for dt in samples {
        if clock.now() >= until {
            break;
        }
        buffer.transform_from(incoming.shape_cd(), &dt.compose());
        collector.clear();
        receiver
            .cde()
            .collect_poly_collisions(&buffer, &NoFilter, &mut collector);
        crate::separate::charge(clock, incoming, 1);
        sampling.examined += 1;
        sampling.collision_free += usize::from(collector.is_empty());
        sampling.over_three_collisions += usize::from(collector.len() > 3);
        sampling.non_item_collision += usize::from(
            collector
                .iter()
                .any(|(_, h)| !matches!(h, BasicHazardEntity::PlacedItem { .. })),
        );
        if collector.is_empty()
            || collector.len() > 3
            || collector
                .iter()
                .any(|(_, h)| !matches!(h, BasicHazardEntity::PlacedItem { .. }))
        {
            continue;
        }
        // Moving every actual obstruction can leave a feasible receiver when
        // evicting only one leaves known collisions. Returned filled area can
        // increase while last-sheet height and material stay unchanged. Both
        // repairs and the whole-job material guard still control acceptance.
        // Keep the original smaller single-victim alternatives as a fallback.
        let blocked: Vec<_> = receiver
            .placed_items()
            .iter()
            .enumerate()
            .filter(|(_, (key, _))| {
                collector.iter().any(
                    |(_, h)| matches!(h, BasicHazardEntity::PlacedItem { pk, .. } if *pk == *key),
                )
            })
            .collect();
        let area: f32 = blocked.iter().map(|(_, (_, p))| p.item().area()).sum();
        if blocked.len() > 1 {
            if area < incoming.area() {
                sampling.multi_eligible_smaller += 1;
            } else {
                sampling.multi_eligible_not_smaller += 1;
                let ratio = area / incoming.area();
                sampling.smallest_not_smaller_area_ratio = Some(
                    sampling
                        .smallest_not_smaller_area_ratio
                        .map_or(ratio, |old| old.min(ratio)),
                );
            }
        }
        if blocked.len() > 1 {
            retain_proposal(
                &mut out,
                Proposal {
                    victims: blocked.iter().map(|(_, (key, _))| *key).collect(),
                    incoming: dt,
                    blockers: collector.len(),
                    rank: blocked[0].0,
                    area,
                },
            );
        }
        // Stable receiver placement order, independent of tree traversal order.
        for (rank, (key, p)) in receiver.placed_items().iter().enumerate() {
            if p.item().area() >= incoming.area()
                || !collector.iter().any(
                    |(_, h)| matches!(h, BasicHazardEntity::PlacedItem { pk, .. } if *pk == key),
                )
            {
                continue;
            }
            let proposal = Proposal {
                victims: vec![key],
                incoming: dt,
                blockers: collector.len(),
                rank,
                area: p.item().area(),
            };
            retain_proposal(&mut out, proposal);
        }
    }
    sampling.retained_victim_counts = out.iter().map(|p| p.victims.len()).collect();
    sampling.retained_blocker_counts = out.iter().map(|p| p.blockers).collect();
    trace.samplings.push(sampling);
    out
}

// Only choose the reciprocal frame when every returned part permits it. The
// separator can still move the parts independently; this is an initial pose.
fn return_group_poses(
    victims: &[(PItemKey, std::sync::Arc<Item>, DTransformation)],
    incoming_here: DTransformation,
    incoming_before: DTransformation,
) -> Vec<DTransformation> {
    let (from_x, from_y) = incoming_here.translation();
    let (to_x, to_y) = incoming_before.translation();
    let translated = || {
        victims
            .iter()
            .map(|(_, _, previous)| {
                let (x, y) = previous.translation();
                DTransformation::new(previous.rotation(), (x + to_x - from_x, y + to_y - from_y))
                    .with_reflection(previous.reflected)
            })
            .collect()
    };
    // Keep the previous arithmetic exactly when the two frames already agree.
    if incoming_here.rotation() == incoming_before.rotation()
        && incoming_here.reflected == incoming_before.reflected
    {
        return translated();
    }
    let frame = incoming_here
        .compose()
        .inverse()
        .transform(&incoming_before.compose());
    let aligned: Option<Vec<_>> = victims
        .iter()
        .map(|(_, victim, previous)| {
            let pose = previous.compose().transform(&frame).decompose();
            victim.allowed_orientations().allows(&pose).then_some(pose)
        })
        .collect();
    aligned.unwrap_or_else(translated)
}

// A cache lives only within one directed_exchange invocation. Exact shared
// static-container and Item identities bind geometry, defects and permissions;
// equal counts make identical copies interchangeable. Placement keys are not
// identities, and positions deliberately do not define an assignment.
fn same_return_assignment(a: &JLayout, b: &JLayout) -> bool {
    if !std::sync::Arc::ptr_eq(a.container().base_cde(), b.container().base_cde())
        || a.placed_items().len() != b.placed_items().len()
    {
        return false;
    }
    let members = |layout: &JLayout| {
        let mut items: Vec<_> = layout
            .placed_items()
            .values()
            .map(|p| p.item().clone())
            .collect();
        items.sort_by_key(|item| item.idx());
        items
    };
    members(a)
        .iter()
        .zip(members(b))
        .all(|(a, b)| std::sync::Arc::ptr_eq(a, &b))
}

fn resume_return_repair(saved: &mut Option<Separator>, fresh: Separator) -> (Separator, bool) {
    if let Some(previous) = saved.take()
        && previous.pinned.is_none()
        && previous.region.is_none()
        && fresh.pinned.is_none()
        && fresh.region.is_none()
        && same_return_assignment(&previous.layout, &fresh.layout)
        && previous
            .layout
            .placed_items()
            .values()
            .all(|p| p.item().allowed_orientations().allows(&p.d_transf()))
        && previous.tracker.total_loss() <= fresh.tracker.total_loss()
    {
        // The whole separator retains its matching tracker, weights and RNG.
        // Both separators share this invocation's clock and EXPLORE settings.
        (previous, true)
    } else {
        (fresh, false)
    }
}

fn remember_return_repair(
    saved: &mut Option<Separator>,
    mut separator: Separator,
    snapshot: &LayoutSnapshot,
    tracker: &crate::separate::Tracker,
) {
    // separate() returns its best snapshot, which need not be its current
    // mutable state. Restore both positions and tracker indices together;
    // rollback preserves guided-search weights and charges the registrations.
    separator.rollback(snapshot, Some(tracker));
    *saved = Some(separator);
}

impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search<'_, '_, F> {
    fn exchange_report(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        layout: &JLayout,
        shape: Shape,
    ) -> Result<Report> {
        let mut sheets = frozen.to_vec();
        sheets.extend(strip.split(layout, shape.sheets)?);
        let layout = self.model.to_layout(&sheets);
        let started = Instant::now();
        let report = validate(self.model.job, &layout)?;
        self.clock.validated(self.model.job, &layout);
        self.check_cost = self.check_cost.max(started.elapsed().as_secs_f64());
        Ok(report)
    }

    /// At most one exchange. The original separator is untouched until both
    /// repairs and the independent whole-job material/geometry guard pass.
    pub(super) fn directed_exchange(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
    ) -> Result<usize> {
        let mut trace = ExchangeTrace::default();
        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            trace.disabled_or_expired = true;
            return Ok(0);
        }
        let baseline = self.exchange_report(strip, frozen, &sep.layout, shape)?;
        if !baseline.valid {
            trace.baseline_invalid = true;
            return Ok(0);
        }
        let before = baseline.metrics.as_ref().expect("valid baseline");
        let single = strip.container(Shape {
            sheets: 1,
            last: self.model.full_width,
        })?;
        let last_container = strip.container(Shape {
            sheets: 1,
            last: shape.last,
        })?;
        let mut saved_source_repair = None;
        let last_index = shape.sheets - 1;
        let last_offset = strip.start(last_index);
        let mut incoming_keys = strip.in_last(&sep.layout, shape);
        incoming_keys.sort_by(|&a, &b| {
            sep.layout.placed_items()[b]
                .item()
                .area()
                .total_cmp(&sep.layout.placed_items()[a].item().area())
        });
        let mut fill = vec![0.0_f32; last_index];
        for p in sep
            .layout
            .placed_items()
            .values()
            .filter(|p| !strip.is_blocker(p))
        {
            let i = strip.sheet_of(p.shape());
            if i < last_index {
                fill[i] += p.item().area();
            }
        }
        let mut targets: Vec<_> = (0..last_index).collect();
        targets.sort_by(|&a, &b| fill[a].total_cmp(&fill[b]));
        for incoming_key in incoming_keys {
            let incoming = &sep.layout.placed_items()[incoming_key];
            let incoming_item = incoming.item().clone();
            let incoming_old = shift(incoming.d_transf(), -last_offset);
            for &target in targets.iter().take(3) {
                if self.clock.now() >= self.last_step(until) {
                    return Ok(0);
                }
                let offset = strip.start(target);
                let mut receiver = JLayout::new(single.clone());
                let mut source = JLayout::new(last_container.clone());
                let mut changed_keys = Vec::new();
                for (key, p) in sep
                    .layout
                    .placed_items()
                    .iter()
                    .filter(|(_, p)| !strip.is_blocker(p))
                {
                    let i = strip.sheet_of(p.shape());
                    if i == target {
                        receiver.place_item(p.item(), shift(p.d_transf(), -offset));
                        changed_keys.push(key);
                    } else if i == last_index {
                        if key != incoming_key {
                            source.place_item(p.item(), shift(p.d_transf(), -last_offset));
                        }
                        changed_keys.push(key);
                    }
                }
                self.clock
                    .charge(Work::RegisteredItem, changed_keys.len() as f64);
                let proposal_until = self.last_step(until);
                let candidates = proposals(
                    &receiver,
                    &incoming_item,
                    &mut self.rng,
                    &self.clock,
                    proposal_until,
                    &mut trace,
                );
                trace.proposals += candidates.len();
                for proposal in candidates {
                    if self.clock.now() >= self.last_step(until) {
                        trace.expired_before_attempt += 1;
                        return Ok(0);
                    }
                    self.stats.directed_exchange_attempts += 1;
                    let index = trace.attempts.len();
                    trace.attempts.push(AttemptTrace {
                        incoming_area: incoming_item.area(),
                        returned_area: proposal.area,
                        victims: proposal.victims.len(),
                        blockers: proposal.blockers,
                        receiver_loss: None,
                        source_loss: None,
                        outcome: "unfinished",
                        receiver_initial_loss: None,
                        source_initial_loss: None,
                        source_fresh_loss: None,
                        source_reused: None,
                        source_initial_weighted_loss: None,
                        source_best_weighted_loss: None,
                        source_elapsed_seconds: None,
                        source_available_budget: None,
                        source_inventory: None,
                        before_material: before.material_area,
                        after_material: None,
                        frame: serde_json::Value::Null,
                    });
                    let victims: Vec<_> = proposal
                        .victims
                        .iter()
                        .map(|&key| {
                            let p = &receiver.placed_items()[key];
                            (key, p.item().clone(), p.d_transf())
                        })
                        .collect();
                    let mut next_receiver = JLayout::from_snapshot(&receiver.save());
                    for &(key, _, _) in &victims {
                        next_receiver.remove_item(key);
                    }
                    next_receiver.place_item(&incoming_item, proposal.incoming);
                    let mut next_source = JLayout::from_snapshot(&source.save());
                    let returned = if victims.len() == 1 {
                        vec![convert_sample_to_closest_feasible(
                            incoming_old,
                            &victims[0].1,
                        )]
                    } else {
                        return_group_poses(&victims, proposal.incoming, incoming_old)
                    };
                    trace.attempts[index].frame =
                        observed_return_frame(&victims, proposal.incoming, incoming_old, &returned);
                    for ((_, victim, _), pose) in victims.iter().zip(returned) {
                        next_source.place_item(victim, pose);
                    }
                    self.clock
                        .charge(Work::RegisteredItem, changed_keys.len() as f64);
                    let now = self.clock.now();
                    // Bound each pair so one hard proposal cannot consume all
                    // remaining opportunities. Each repair gets half the pair.
                    let pair_end = now + ((self.last_step(until) - now) * 0.5).min(0.4);
                    let middle = (now + pair_end) / 2.0;
                    let mut receiver_sep = Separator::new(
                        next_receiver,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    trace.attempts[index].receiver_initial_loss =
                        Some(receiver_sep.tracker.total_loss());
                    let (receiver_snapshot, receiver_tracker) =
                        receiver_sep.separate(&self.deadline(middle));
                    trace.attempts[index].receiver_loss = Some(receiver_tracker.total_loss());
                    if receiver_tracker.total_loss() > 0.0 {
                        trace.attempts[index].outcome = "receiver_repair_failed";
                        continue;
                    }
                    let fresh_source = Separator::new(
                        next_source,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    trace.attempts[index].source_fresh_loss =
                        Some(fresh_source.tracker.total_loss());
                    let (mut source_sep, reused) =
                        resume_return_repair(&mut saved_source_repair, fresh_source);
                    self.stats.directed_source_reuses += u64::from(reused);
                    trace.attempts[index].source_reused = Some(reused);
                    let mut inventory: Vec<_> = source_sep
                        .layout
                        .placed_items()
                        .values()
                        .map(|p| p.item().idx())
                        .collect();
                    inventory.sort_unstable();
                    trace.attempts[index].source_inventory = Some(inventory);
                    trace.attempts[index].source_initial_weighted_loss =
                        Some(source_sep.tracker.total_weighted_loss());
                    trace.attempts[index].source_available_budget =
                        Some(pair_end - self.clock.now());
                    let source_started = Instant::now();
                    trace.attempts[index].source_initial_loss =
                        Some(source_sep.tracker.total_loss());
                    let (source_snapshot, source_tracker) =
                        source_sep.separate(&self.deadline(pair_end));
                    trace.attempts[index].source_elapsed_seconds =
                        Some(source_started.elapsed().as_secs_f64());
                    trace.attempts[index].source_best_weighted_loss =
                        Some(source_tracker.total_weighted_loss());
                    remember_return_repair(
                        &mut saved_source_repair,
                        source_sep,
                        &source_snapshot,
                        &source_tracker,
                    );
                    trace.attempts[index].source_loss = Some(source_tracker.total_loss());
                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(until)
                    {
                        trace.attempts[index].outcome = if source_tracker.total_loss() > 0.0 {
                            "source_repair_failed"
                        } else {
                            "expired_after_repairs"
                        };
                        continue;
                    }
                    let mut trial = JLayout::from_snapshot(&sep.layout.save());
                    for &key in &changed_keys {
                        trial.remove_item(key);
                    }
                    for (snapshot, start) in
                        [(receiver_snapshot, offset), (source_snapshot, last_offset)]
                    {
                        for p in JLayout::from_snapshot(&snapshot).placed_items().values() {
                            trial.place_item(p.item(), shift(p.d_transf(), start));
                        }
                    }
                    self.clock.charge(
                        Work::RegisteredItem,
                        (sep.layout.placed_items().len() + changed_keys.len()) as f64,
                    );
                    let report = self.exchange_report(strip, frozen, &trial, shape)?;
                    if !report.valid {
                        trace.attempts[index].outcome = "independent_geometry_failed";
                        self.stats.rejected_layouts += 1;
                        continue;
                    }
                    let after = report.metrics.as_ref().expect("valid exchange");
                    trace.attempts[index].after_material = Some(after.material_area);
                    if after.sheets_used > before.sheets_used
                        || after.material_area > before.material_area
                        || self.clock.now() >= until
                    {
                        trace.attempts[index].outcome = if self.clock.now() >= until {
                            "expired_before_acceptance"
                        } else {
                            "material_guard_failed"
                        };
                        continue;
                    }
                    trace.attempts[index].outcome = "accepted";
                    sep.layout = trial;
                    sep.rebuild();
                    self.stats.directed_exchanges += 1;
                    return Ok(1);
                }
            }
        }
        Ok(0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nestbolt_validator::job::{Margins, Part, Stock};
    use nestbolt_validator::{Polygon, Units};

    fn rectangle(id: &str, width: f64, height: f64) -> Part {
        Part {
            id: id.into(),
            quantity: 1,
            geometry: vec![Polygon {
                outer: vec![[0.0, 0.0], [width, 0.0], [width, height], [0.0, height]],
                holes: vec![],
            }],
            rotations: Rotations::List { degrees: vec![0.0] },
            allow_mirror: false,
            priority: 1.0,
        }
    }

    fn fixture() -> (Job, Layout) {
        let job = Job {
            version: 1,
            name: "authored exchange".into(),
            units: Units::Mm,
            parts: vec![
                rectangle("filler", 60.0, 94.0),
                rectangle("return", 30.0, 20.0),
                rectangle("incoming", 30.0, 85.0),
            ],
            stocks: vec![Stock {
                id: "stock".into(),
                width: 100.0,
                height: 100.0,
                count: None,
                margins: Margins::default(),
                outline: vec![],
                defects: vec![],
            }],
            clearance: 0.2,
            edge_clearance: 1.0,
            mode: Mode::All,
        };
        let layout = Layout {
            version: 1,
            units: Units::Mm,
            sheets: (0..2)
                .map(|i| Sheet {
                    id: format!("sheet-{i}"),
                    stock_id: "stock".into(),
                })
                .collect(),
            placements: [
                ("filler", 0, [2.0, 2.0]),
                ("return", 0, [64.0, 2.0]),
                ("incoming", 1, [2.0, 2.0]),
            ]
            .into_iter()
            .map(|(id, sheet, translation)| Placement {
                part_id: id.into(),
                copy_index: 0,
                sheet_id: format!("sheet-{sheet}"),
                transform: RigidTransform {
                    translation,
                    rotation_radians: 0.0,
                    mirrored: false,
                },
            })
            .collect(),
        };
        (job, layout)
    }

    fn fingerprint(layout: &JLayout) -> String {
        format!(
            "{:?}",
            layout
                .placed_items()
                .iter()
                .map(|(k, p)| (k, p.item().idx(), p.d_transf()))
                .collect::<Vec<_>>()
        )
    }

    fn exercise(
        job: &Job,
        layout: &Layout,
        seed: u64,
        enabled: bool,
        expired: bool,
        frozen_count: usize,
    ) -> (usize, Layout, Stats) {
        let validation = validate(job, layout).unwrap();
        assert!(validation.valid, "{:?}", validation.violations);
        let model = Model::new(job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut search = Search {
            model: &model,
            allow_exchange: enabled,
            rng: Xoshiro256PlusPlus::seed_from_u64(seed),
            clock: clock.clone(),
            best: (layout.clone(), validation, 0.0),
            history: vec![],
            stats: Stats::default(),
            progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
            check_cost: 0.0,
            check_every: 5.0,
        };
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(layout).unwrap();
        let (frozen, window) = sheets.split_at(frozen_count);
        let mut shape = Shape {
            sheets: window.len(),
            last: model.full_width,
        };
        let initial = strip.layout(window, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut sep = Separator::new(
            strip.layout(window, shape).unwrap(),
            seed,
            EXPLORE,
            search.clock.clone(),
        );
        sep.pin(blocker_index(&model));
        assert_eq!(sep.tracker.total_loss(), 0.0);
        // Compare the same f32 internal frame before/after the exchange. The
        // public-to-internal conversion predates this operation and has its own
        // tests; comparing to the authored f64 coordinates conflates the two.
        let mut before_sheets = frozen.to_vec();
        before_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let before_layout = model.to_layout(&before_sheets);
        let before_report = validate(job, &before_layout).unwrap();
        assert!(before_report.valid);
        let before_material = before_report.metrics.as_ref().unwrap().material_area;
        let original = fingerprint(&sep.layout);
        let until = if expired {
            0.0
        } else {
            search.clock.now() + 3.0
        };
        let moved = search
            .directed_exchange(&strip, frozen, &mut sep, shape, until)
            .unwrap();
        if moved == 0 {
            assert_eq!(
                fingerprint(&sep.layout),
                original,
                "failed proposal mutated the original state"
            );
        }
        let mut after_sheets = frozen.to_vec();
        after_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let after = model.to_layout(&after_sheets);
        for i in 0..frozen_count {
            let id = format!("sheet-{i}");
            let before_fixed: Vec<_> = before_layout
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            let after_fixed: Vec<_> = after
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            assert_eq!(
                serde_json::to_value(before_fixed).unwrap(),
                serde_json::to_value(after_fixed).unwrap()
            );
        }
        let report = validate(job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert!(report.metrics.as_ref().unwrap().material_area <= before_material);
        assert_eq!(sep.tracker.total_loss(), 0.0);
        eprintln!(
            "authored exchange seed={seed} enabled={enabled} expired={expired} frozen={frozen_count} moved={moved} attempts={} material_before={before_material:.9} material_after={:.9}",
            search.stats.directed_exchange_attempts,
            report.metrics.as_ref().unwrap().material_area
        );
        (moved, after, search.stats)
    }

    #[test]
    fn window_search_reaches_exchange_before_gap_filling() {
        let (mut job, mut layout) = fixture();
        // This small last-sheet part fits an earlier gap. A successful fill
        // must not bypass the exchange opportunity for the large incoming part.
        job.parts.push(rectangle("gap-part", 5.0, 5.0));
        layout.placements.push(Placement {
            part_id: "gap-part".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [36.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        for (enabled, budget) in [(true, 20.0), (false, 20.0), (true, 0.0)] {
            let report = validate(&job, &layout).unwrap();
            assert!(report.valid);
            let before_material = report.metrics.as_ref().unwrap().material_area;
            let model = Model::new(&job).unwrap();
            let clock = Clock::new(Timing::Work, 30.0);
            let mut search = Search {
                model: &model,
                allow_exchange: enabled,
                rng: Xoshiro256PlusPlus::seed_from_u64(0),
                clock,
                best: (layout.clone(), report, 0.0),
                history: vec![],
                stats: Stats::default(),
                progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
                check_cost: 0.0,
                check_every: 5.0,
            };
            search
                .window_search(model.sheets_of(&layout).unwrap(), budget, 0.2, 2)
                .unwrap();
            let checked = validate(&job, &search.best.0).unwrap();
            assert!(checked.valid);
            assert!(checked.metrics.as_ref().unwrap().material_area <= before_material);
            if enabled && budget > 0.0 {
                assert!(search.stats.directed_exchange_attempts > 0);
                assert!(search.stats.directed_exchanges > 0);
            } else {
                assert_eq!(search.stats.directed_exchange_attempts, 0);
                assert_eq!(search.stats.directed_exchanges, 0);
            }
            eprintln!(
                "window exchange enabled={enabled} budget={budget} attempts={} accepted={} valid={}",
                search.stats.directed_exchange_attempts,
                search.stats.directed_exchanges,
                checked.valid
            );
        }
    }

    #[test]
    fn directed_exchange_returns_smaller_actual_obstruction() {
        let (job, layout) = fixture();
        for seed in 0..5 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            assert_eq!(moved, 1, "seed {seed}, {stats:?}");
            assert_eq!(stats.directed_exchanges, 1);
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
            );
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
            );
        }
    }

    #[test]
    fn directed_exchange_expired_or_disabled_leaves_layout_intact() {
        let (job, layout) = fixture();
        for (enabled, expired) in [(true, true), (false, false)] {
            let (moved, _, stats) = exercise(&job, &layout, 0, enabled, expired, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.directed_exchange_attempts, 0);
        }
    }

    #[test]
    fn directed_exchange_rejects_returns_that_cannot_fit() {
        let (mut job, layout) = fixture();
        job.parts[2] = rectangle("incoming", 20.0, 10.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchanges, 0);
    }

    #[test]
    fn directed_exchange_preserves_frozen_sheets_and_mirror_contract() {
        let (mut job, mut layout) = fixture();
        job.parts.push(rectangle("fixed", 20.0, 20.0));
        for p in &mut layout.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        let fixed = Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        };
        layout.placements.push(fixed.clone());
        job.parts[2].allow_mirror = true;
        let incoming = layout
            .placements
            .iter_mut()
            .find(|p| p.part_id == "incoming")
            .unwrap();
        incoming.transform.mirrored = true;
        incoming.transform.translation[0] += 30.0;
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 1);
        assert_eq!(moved, 1);
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "fixed" && p.sheet_id == "sheet-0")
        );
    }

    #[test]
    fn directed_exchange_failed_source_repair_leaves_layout_intact() {
        let (mut job, layout) = fixture();
        job.parts[1] = rectangle("return", 5.0, 90.0);
        job.parts[2] = rectangle("incoming", 30.0, 30.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert!(stats.directed_exchange_attempts > 0);
    }

    #[test]
    fn directed_exchange_respects_stock_defects() {
        let (mut job, layout) = fixture();
        job.edge_clearance = job.clearance;
        job.stocks[0].defects.push(Polygon {
            outer: vec![[96.0, 20.0], [98.0, 20.0], [98.0, 30.0], [96.0, 30.0]],
            holes: vec![],
        });
        let (moved, _, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
    }

    fn obstruction_set_fixture(count: usize, return_height: f64) -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.parts[1] = rectangle("return", 30.0, return_height);
        job.parts[1].quantity = count as u32;
        let template = layout
            .placements
            .iter()
            .find(|p| p.part_id == "return")
            .unwrap()
            .clone();
        for copy in 1..count {
            let mut part = template.clone();
            part.copy_index = copy as u32;
            part.transform.translation[1] += copy as f64 * (return_height + 2.0);
            layout.placements.push(part);
        }
        (job, layout)
    }

    #[test]
    fn obstruction_set_moves_two_blockers_atomically() {
        let (job, layout) = obstruction_set_fixture(2, 20.0);
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            2
        );
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
        );
    }

    #[test]
    fn obstruction_set_moves_three_blockers_atomically() {
        let (job, layout) = obstruction_set_fixture(3, 20.0);
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            3
        );
    }

    #[test]
    fn complete_sets_can_return_equal_or_greater_area_at_the_same_material() {
        // The independently validated witness retains a 33 mm charged height:
        // a 2550/2700 mm2 incoming part can trade for three 900 mm2 squares.
        // Their relative positions fit in the otherwise empty return sheet.
        for incoming_width in [85.0, 90.0] {
            let (mut job, mut layout) = obstruction_set_fixture(3, 30.0);
            for part in &mut job.parts {
                for polygon in &mut part.geometry {
                    for point in &mut polygon.outer {
                        point.swap(0, 1);
                    }
                }
            }
            job.parts[2] = rectangle("incoming", incoming_width, 30.0);
            for part in &mut layout.placements {
                part.transform.translation.swap(0, 1);
            }
            let original = validate(&job, &layout).unwrap();
            assert!(original.valid);
            assert_eq!(original.metrics.unwrap().material_area, 13300.0);
            let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
            assert_eq!(moved, 1);
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
            );
        }
    }
    fn return_frame_witness() -> (Job, Layout) {
        let job = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../examples/return-frame-job.json"
        )))
        .unwrap();
        let layout = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../examples/return-frame-before.json"
        )))
        .unwrap();
        (job, layout)
    }

    fn witness_victims(
        receiver: &JLayout,
    ) -> Vec<(PItemKey, std::sync::Arc<Item>, DTransformation)> {
        receiver
            .placed_items()
            .iter()
            .filter(|(_, p)| p.item().external_id() == 2)
            .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
            .collect()
    }

    #[test]
    fn return_frame_rotates_into_the_vacated_gap_without_extra_material() {
        let (job, before) = return_frame_witness();
        let original = validate(&job, &before).unwrap();
        assert!(original.valid);
        assert_eq!(original.metrics.unwrap().material_area, 19500.0);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        let incoming = sheets[1]
            .layout()
            .placed_items()
            .values()
            .find(|p| p.item().external_id() == 3)
            .unwrap();
        let incoming_old = incoming.d_transf();
        let placed = RigidTransform {
            translation: [2.0, 64.0],
            rotation_radians: 0.0,
            mirrored: false,
        };
        let incoming_new = model.internal(incoming.item().idx(), &placed);
        let victims = witness_victims(sheets[0].layout());
        assert_eq!(victims.len(), 3);
        let poses = return_group_poses(&victims, incoming_new, incoming_old);
        let mut after = before.clone();
        let p = after
            .placements
            .iter_mut()
            .find(|p| p.part_id == "incoming")
            .unwrap();
        p.sheet_id = "sheet-0".into();
        p.transform = placed;
        for ((p, (_, item, _)), pose) in after
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "return")
            .zip(&victims)
            .zip(&poses)
        {
            assert!(item.allowed_orientations().allows(pose));
            p.sheet_id = "sheet-1".into();
            p.transform = model.external(item.idx(), pose);
        }
        let report = validate(&job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert_eq!(report.metrics.unwrap().material_area, 19500.0);
        let (fx, fy) = incoming_new.translation();
        let (tx, ty) = incoming_old.translation();
        for (p, (_, item, previous)) in after
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "return")
            .zip(&victims)
        {
            let (x, y) = previous.translation();
            let translated = DTransformation::new(previous.rotation(), (x + tx - fx, y + ty - fy))
                .with_reflection(previous.reflected);
            p.transform = model.external(item.idx(), &translated);
        }
        assert!(!validate(&job, &after).unwrap().valid);
    }

    #[test]
    fn return_frame_keeps_incumbent_when_roundoff_increases_charged_material() {
        let (mut job, before) = return_frame_witness();
        job.parts[1] = rectangle("source-filler", 20.0, 94.0);
        let (moved, _, stats) = exercise(&job, &before, 0, true, false, 0);
        // This exact authored attempt repairs both sheets but raises charged
        // material by 0.0007 mm2. The strict guard must retain the incumbent;
        // exercise also requires exact internal-state preservation on failure.
        assert_eq!(moved, 0);
        assert!(stats.directed_exchange_attempts > 0);
        assert_eq!(stats.directed_exchanges, 0);
    }

    #[test]
    fn directed_exchange_uses_the_rotated_return_gap() {
        let (mut job, mut before) = return_frame_witness();
        // Keep the incoming part first in the area-ranked source list. A narrow
        // tall neighbour still obstructs the old translation-only return pose.
        job.parts[1] = rectangle("source-filler", 20.0, 94.0);
        // A separate fixed top strip controls this sheet's occupied height.
        // It isolates successful frame use from the original fixture's strict
        // floating-point material rejection, which has its own test above.
        job.parts.push(rectangle("ceiling", 94.0, 1.0));
        before.placements.push(Placement {
            part_id: "ceiling".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 97.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(stats.directed_exchanges, 1);
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
        );
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            3
        );
    }

    #[test]
    fn return_frame_preserves_permitted_reflection_and_relative_positions() {
        let (mut job, before) = return_frame_witness();
        job.parts[2].allow_mirror = true;
        job.parts[3].allow_mirror = true;
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        let mut victims = witness_victims(sheets[0].layout());
        for (i, (_, _, previous)) in victims.iter_mut().enumerate() {
            *previous = DTransformation::new(0.0, (12.0 + 6.0 * i as f32, 23.0));
        }
        let here = DTransformation::new(0.0, (10.0, 20.0));
        let old =
            DTransformation::new(std::f32::consts::FRAC_PI_2, (40.0, 50.0)).with_reflection(true);
        let poses = return_group_poses(&victims, here, old);
        // (x,y) relative to the old incoming frame maps to (y,x), then (40,50).
        for (i, (pose, (_, item, _))) in poses.iter().zip(&victims).enumerate() {
            assert!(pose.reflected && item.allowed_orientations().allows(pose));
            let (x, y) = pose.translation();
            assert!((x - 43.0).abs() < 0.0001);
            assert!((y - (52.0 + 6.0 * i as f32)).abs() < 0.0001);
            let matrix = pose.compose();
            let matrix = matrix.matrix();
            assert!(matrix[0][0].into_inner().abs() < 0.0001);
            assert!((matrix[0][1].into_inner() - 1.0).abs() < 0.0001);
            assert!((matrix[1][0].into_inner() - 1.0).abs() < 0.0001);
            assert!(matrix[1][1].into_inner().abs() < 0.0001);
        }
    }

    #[test]
    fn return_frame_falls_back_for_the_whole_group_if_any_orientation_is_forbidden() {
        let (job, before) = return_frame_witness();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        for reflected in [false, true] {
            let mut victims = witness_victims(sheets[0].layout());
            if !reflected {
                // Only the first member forbids the quarter-turn. All members
                // must retain the old translation, rather than deform the set.
                victims[0].1 = sheets[0]
                    .layout()
                    .placed_items()
                    .values()
                    .find(|p| p.item().external_id() == 0)
                    .unwrap()
                    .item()
                    .clone();
            }
            let here = DTransformation::new(3.0 * std::f32::consts::FRAC_PI_2, (10.0, 20.0));
            let old = DTransformation::new(
                if reflected {
                    std::f32::consts::FRAC_PI_2
                } else {
                    0.0
                },
                (40.0, 50.0),
            )
            .with_reflection(reflected);
            let poses = return_group_poses(&victims, here, old);
            for (pose, (_, item, previous)) in poses.iter().zip(&victims) {
                assert!(item.allowed_orientations().allows(pose));
                assert_eq!(pose.rotation(), previous.rotation());
                assert_eq!(pose.reflected, previous.reflected);
                let (x, y) = previous.translation();
                assert_eq!(pose.translation(), (x + 40.0 - 10.0, y + 50.0 - 20.0));
            }
        }
    }
    fn return_repair_layout(model: &Model<'_>, container: &Container, overlap: bool) -> JLayout {
        let item = &model.instance.items[1].0;
        let mut layout = JLayout::new(container.clone());
        for (x, y) in [(25.0, 25.0), (if overlap { 25.0 } else { 65.0 }, 25.0)] {
            let pose = convert_sample_to_closest_feasible(DTransformation::new(0.0, (x, y)), item);
            assert!(item.allowed_orientations().allows(&pose));
            layout.place_item(item, pose);
        }
        layout
    }

    #[test]
    fn return_reuse_restores_best_geometry_tracker_keys_and_rng() {
        let (job, _) = fixture();
        let model = Model::new(&job).unwrap();
        let sheet = model.empty_sheet().unwrap();
        let container = sheet.layout().container();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut source = Separator::new(
            return_repair_layout(&model, container, false),
            7,
            EXPLORE,
            clock.clone(),
        );
        assert_eq!(source.tracker.total_loss(), 0.0);
        let snapshot = source.layout.save();
        let tracker = source.tracker.clone();
        let fingerprint_before = fingerprint(&source.layout);
        let keys: Vec<_> = source.layout.placed_items().keys().collect();
        let pose = source.layout.placed_items()[keys[0]].d_transf();
        let moved = source.move_item(keys[1], pose);
        assert_ne!(keys[1], moved);
        assert!(source.tracker.total_loss() > 0.0);
        let expected_rng = source.rng.clone().next_u64();
        let mut saved = None;
        remember_return_repair(&mut saved, source, &snapshot, &tracker);
        let fresh = Separator::new(
            return_repair_layout(&model, container, true),
            999,
            EXPLORE,
            clock,
        );
        let (mut resumed, reused) = resume_return_repair(&mut saved, fresh);
        assert!(reused && saved.is_none());
        assert_eq!(fingerprint(&resumed.layout), fingerprint_before);
        assert_eq!(resumed.rng.next_u64(), expected_rng);
        let rebuilt = crate::separate::Tracker::new(&resumed.layout);
        assert_eq!(resumed.tracker.total_loss(), rebuilt.total_loss());
        for key in resumed.layout.placed_items().keys() {
            assert_eq!(resumed.tracker.loss(key), rebuilt.loss(key));
        }
    }

    #[test]
    fn return_reuse_rejects_changed_counts_and_part_membership() {
        let (job, _) = fixture();
        let model = Model::new(&job).unwrap();
        let sheet = model.empty_sheet().unwrap();
        let container = sheet.layout().container();
        let baseline = return_repair_layout(&model, container, false);
        for replace in [false, true] {
            let mut changed = JLayout::from_snapshot(&baseline.save());
            let key = changed.placed_items().keys().next().unwrap();
            let pose = changed.remove_item(key).d_transf();
            if replace {
                changed.place_item(&model.instance.items[2].0, pose);
            }
            let clock = Clock::new(Timing::Work, 30.0);
            let mut saved = Some(Separator::new(
                JLayout::from_snapshot(&baseline.save()),
                0,
                EXPLORE,
                clock.clone(),
            ));
            let expected = fingerprint(&changed);
            let (actual, reused) =
                resume_return_repair(&mut saved, Separator::new(changed, 1, EXPLORE, clock));
            assert!(!reused && saved.is_none());
            assert_eq!(fingerprint(&actual.layout), expected);
        }
    }

    #[test]
    fn return_reuse_rejects_changed_geometry_or_orientation_object() {
        let (job, _) = fixture();
        let model = Model::new(&job).unwrap();
        let sheet = model.empty_sheet().unwrap();
        let container = sheet.layout().container();
        for geometry in [false, true] {
            let mut other_job = job.clone();
            if geometry {
                other_job.parts[1] = rectangle("return", 25.0, 15.0);
            } else {
                other_job.parts[1].allow_mirror = true;
            }
            let other = Model::new(&other_job).unwrap();
            // Reuse the exact same static container and item index; only the
            // original item object (geometry/permissions) is different.
            assert_eq!(
                model.instance.items[1].0.idx(),
                other.instance.items[1].0.idx()
            );
            assert!(!same_return_assignment(
                &return_repair_layout(&model, container, false),
                &return_repair_layout(&other, container, false)
            ));
        }
    }

    #[test]
    fn return_reuse_requires_the_exact_static_container() {
        let (job, _) = fixture();
        let model = Model::new(&job).unwrap();
        let a = model.empty_sheet().unwrap();
        let b = model.empty_sheet().unwrap();
        assert_eq!(
            a.layout().container().outer_cd().vertices(),
            b.layout().container().outer_cd().vertices()
        );
        assert!(!same_return_assignment(
            &return_repair_layout(&model, a.layout().container(), false),
            &return_repair_layout(&model, b.layout().container(), false)
        ));
    }

    #[test]
    fn return_reuse_prefers_a_better_fresh_start_and_rejects_forbidden_saved_pose() {
        let (job, _) = fixture();
        let model = Model::new(&job).unwrap();
        let sheet = model.empty_sheet().unwrap();
        let container = sheet.layout().container();
        for forbidden in [false, true] {
            let clock = Clock::new(Timing::Work, 30.0);
            let mut previous = Separator::new(
                return_repair_layout(&model, container, !forbidden),
                0,
                EXPLORE,
                clock.clone(),
            );
            if forbidden {
                let key = previous.layout.placed_items().keys().next().unwrap();
                let pose = previous.layout.placed_items()[key].d_transf();
                previous.move_item(
                    key,
                    DTransformation::new(pose.rotation() + 0.123, pose.translation()),
                );
            }
            let fresh = Separator::new(
                return_repair_layout(&model, container, forbidden),
                1,
                EXPLORE,
                clock,
            );
            let expected = fingerprint(&fresh.layout);
            let mut saved = Some(previous);
            let (actual, reused) = resume_return_repair(&mut saved, fresh);
            assert!(!reused && saved.is_none());
            assert_eq!(fingerprint(&actual.layout), expected);
        }
    }

    #[test]
    fn reused_return_repairs_still_reject_material_increase_and_preserve_incumbent() {
        let (mut job, before) = return_frame_witness();
        job.parts[1] = rectangle("source-filler", 20.0, 94.0);
        let (moved, _, stats) = exercise(&job, &before, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchanges, 0);
        assert!(
            stats.directed_source_reuses > 0,
            "authored execution must exercise actual cache reuse"
        );
    }
}
