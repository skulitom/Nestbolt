from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1]
probe=root/'output/h5-return-reuse-stage-diagnosis-20261018'
out=root/'benchmarks/results/h5-return-reuse-stage-preparation-20261018'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
build=load(probe/'build.json');plan=load(probe/'preparation.json')
assert build['all_passed'] and digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert digest(probe/'workspace'/plan['changed_file'])==build['source_sha256']
assert '96 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for row in plan['source_files']:
    assert digest(Path(plan['old_source'])/row['path'])==row['sha256']
    if row['path']!=plan['changed_file']:assert digest(probe/'workspace'/row['path'])==row['sha256']
reader=load(probe/'authored-trace-reader/checks.json')
assert reader['all_checks_pass'] and reader['actual_reuse_traces_checked'] and reader['cross_attempt_restoration_checked']
assert len(reader['authored_test_traces'])==3 and len(reader['malformed_records_rejected'])==12
assert reader['reader_sha256']==digest(root/'scripts/h5_return_reuse_stage_diagnosis.py')
out.mkdir()
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_return_reuse_stage_drivers.py','prepare_h5_return_reuse_stage_diagnosis.py',
             'build_h5_return_reuse_stage_diagnosis.py','return_reuse_trace_snippet.py',
             'prepare_return_reuse_stage_runner.py','prepare_return_reuse_reader_checks.py','check_return_reuse_stage_reader.py',
             'prepare_return_reuse_stage_drivers-original-syntax-failure.py',
             'prepare_h5_return_reuse_stage_diagnosis-original-syntax-failure.py']:
    files['helpers/'+name]=root/'output'/name
files['helpers/seal.py']=Path(__file__)
files['diagnostic-runner.py']=root/'scripts/h5_return_reuse_stage_diagnosis.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
raw=out/'raw.zip'
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(raw) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
for name in ['preparation.json','build.json','instrumentation.patch']:shutil.copyfile(probe/name,out/name)
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(raw),'bytes':raw.stat().st_size,
    'members':inventory,'crc_and_every_member_verified':True})
write(out/'checks.json',{'optimized_core_tests_passed':96,'strict_lint_passed':True,
    'instrumented_observer_build_passed':True,'old_candidate_and_production_unchanged':True,
    'authored_reader_traces':3,'malformed_records_rejected':12,'cross_attempt_state_checked':True,
    'diagnostic_only':True,'quality_claim':False,'measured_search_started':False,
    'completed_weight_percent':60,'H5_complete':False})
doc='''# Source-repair reuse diagnostic preparation — 2026-10-18

The isolated observer passes all 96 optimized core tests, strict lint and its
build. Three authored tests yield real traces: a successful reciprocal exchange,
strict material rejection and actual reuse with an unchanged incumbent. The
reader rejects twelve malformed cases, including mismatched inventories,
restored losses, reuse counts and cross-invocation reuse. It retains the prior
frame/pose/material checks and their tolerances.

New observations identify fresh versus resumed source repairs, their original
item inventory, initial/final unweighted and weighted loss, available budget,
elapsed repair time and receiver/source/final-acceptance stages. Across reuse,
the reader verifies that inventory and restored loss match the previous saved
source state in the same invocation. Fresh states must match their fresh loss;
resumed states may not start worse than the fresh alternative. Counters must
match the actual traces. A repaired source still requires whole-job validation.

Reversing instrumentation restores exact original text before formatting. All
147 other source files, the rejected candidate and production are unchanged.
The observer retains proposals, work charges, repair budgets and acceptance
rules. Logging can perturb wall deadlines, so this is diagnostic evidence only.
The two original preparation-generator quoting errors are preserved; both
occurred before workspace creation or any measured search.

The preceding 72-outcome pilot retains six failed material pairs, 11 accepted
exchanges from 73 attempts and 37 reuse events. Four serial observations will
use the two mechanical jobs, both kerfs, seed zero, 60 seconds and physical
CCD0 CPU 8 after the plan is committed. No quality rerun, reserved-input access,
integration, changed limit or H5 credit. H2/H5 remain open at 60%.
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-return-reuse-stage-diagnosis-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''

## 2026-10-18 — Prepare source-repair reuse observations

[The isolated observer](benchmarks/results/h5-return-reuse-stage-preparation-20261018.md)
passes 96 optimized core tests, strict lint and its build. Three real authored
traces and twelve malformed-record checks qualify the reader, including
same-call inventory/loss restoration, worse-than-fresh rejection and exact
reuse counters. The original strict material rejection remains intact.

Four serial, seed-zero, 60-second observations on the mechanical jobs and both
kerfs will locate fresh/resumed source repair and final acceptance failures.
No proposals, repair budgets, work charges or acceptance rules change. Source,
binary and archive members verify. The two preparation-generator quoting
errors are retained. No quality rerun, production integration, reserved-input
access or milestone credit. H2/H5 remain open at 60%.
''')
print(json.dumps({'sealed':str(out),'members':len(inventory),'bytes':raw.stat().st_size}))
