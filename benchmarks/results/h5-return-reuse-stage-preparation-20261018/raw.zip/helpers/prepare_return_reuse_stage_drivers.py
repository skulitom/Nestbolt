from pathlib import Path
from hashlib import sha256

root=Path(__file__).resolve().parents[1]
old=root/'output/prepare_h5_return_frame_stage_diagnosis.py'
text=old.read_text(encoding='utf-8')
text=text.replace('h5-return-frame-stage-diagnosis-20261017','h5-return-reuse-stage-diagnosis-20261018')
text=text.replace('h5-return-frame-stage-target-20261017','h5-return-reuse-stage-target-20261018')
text=text.replace('h5-return-frame-probe-20261017','h5-return-reuse-probe-20261018')
candidate=root/'output/h5-return-reuse-probe-20261018/candidate/crates/core/src/sheets/vstrip/exchange.rs'
text=text.replace('17e9c64a28399e42c1212357b93058bf1ea5a4f3d91206432e53adf401a8d912',sha256(candidate.read_bytes()).hexdigest())
text=text.replace('"""Instrument the rejected complete-set experiment without changing its decisions."""',
                  '"""Observe the rejected repair-reuse experiment without changing decisions or budgets."""')
text=text.replace('    source_initial_loss: Option<f32>,','''    source_initial_loss: Option<f32>,
    source_fresh_loss: Option<f32>,
    source_reused: Option<bool>,
    source_initial_weighted_loss: Option<f32>,
    source_best_weighted_loss: Option<f32>,
    source_elapsed_seconds: Option<f64>,
    source_available_budget: Option<f64>,
    source_inventory: Option<Vec<usize>>,''')
text=text.replace('                        receiver_initial_loss: None, source_initial_loss: None,','''                        receiver_initial_loss: None, source_initial_loss: None,
                        source_fresh_loss: None, source_reused: None,
                        source_initial_weighted_loss: None, source_best_weighted_loss: None,
                        source_elapsed_seconds: None, source_available_budget: None,
                        source_inventory: None,''')
extra=r"""
replace('                    let (mut source_sep, reused) =',
        '                    trace.attempts[index].source_fresh_loss = Some(fresh_source.tracker.total_loss());\n                    let (mut source_sep, reused) =')
replace('                    self.stats.directed_source_reuses += u64::from(reused);',
        '''                    self.stats.directed_source_reuses += u64::from(reused);
                    trace.attempts[index].source_reused = Some(reused);
                    let mut inventory: Vec<_> = source_sep.layout.placed_items().values().map(|p| p.item().idx()).collect();
                    inventory.sort_unstable();
                    trace.attempts[index].source_inventory = Some(inventory);
                    trace.attempts[index].source_initial_weighted_loss = Some(source_sep.tracker.total_weighted_loss());
                    trace.attempts[index].source_available_budget = Some(pair_end - self.clock.now());
                    let source_started = Instant::now();''')
replace('                    remember_return_repair(',
        '''                    trace.attempts[index].source_elapsed_seconds = Some(source_started.elapsed().as_secs_f64());
                    trace.attempts[index].source_best_weighted_loss = Some(source_tracker.total_weighted_loss());
                    remember_return_repair(''')
"""
# Preserve newline escapes inside the generated Python string literals.
assert text.count('reverse=text')==1
text=text.replace('reverse=text',extra+'\nreverse=text')
text=text.replace("'return-frame-original',tofile='diagnostic-only'", "'return-reuse-original',tofile='diagnostic-only'")
text=text.replace('Observe reciprocal-frame legality/fallback, actual poses, initial/final repair losses and independently validated material rejection.',
                  'Observe source reuse, fresh/resumed losses, source inventory, repair duration/budget, receiver/source stages and independently validated material rejection.')
(root/'output/prepare_h5_return_reuse_stage_diagnosis.py').write_text(text,encoding='utf-8',newline='\n')
build=(root/'output/build_h5_return_frame_stage_diagnosis.py').read_text(encoding='utf-8')
build=build.replace('h5-return-frame-stage-diagnosis-20261017','h5-return-reuse-stage-diagnosis-20261018')
build=build.replace('h5-return-frame-stage-target-20261017','h5-return-reuse-stage-target-20261018')
(root/'output/build_h5_return_reuse_stage_diagnosis.py').write_text(build,encoding='utf-8',newline='\n')
print('Prepared isolated reuse-stage instrumentation and build drivers.')
