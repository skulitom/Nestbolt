def check_reuse_attempt(attempt):
    fields=['source_fresh_loss','source_initial_weighted_loss','source_best_weighted_loss',
            'source_elapsed_seconds','source_available_budget','source_inventory','source_reused']
    if attempt['outcome']=='receiver_repair_failed':
        assert all(attempt[k] is None for k in fields)
        assert attempt['source_initial_loss'] is None and attempt['source_loss'] is None
        return
    assert isinstance(attempt['source_reused'],bool)
    for key in fields[:5]:
        value=attempt[key]
        assert isinstance(value,(float,int)) and not isinstance(value,bool) and math.isfinite(value)
        if key!='source_available_budget':assert value>=0
    inventory=attempt['source_inventory']
    assert isinstance(inventory,list) and inventory==sorted(inventory) and inventory
    assert all(type(i) is int and i>=0 for i in inventory)
    assert attempt['receiver_loss']==0
    assert attempt['source_initial_loss'] is not None and attempt['source_loss'] is not None
    if attempt['source_reused']:
        assert attempt['source_initial_loss']<=attempt['source_fresh_loss']
    else:
        assert attempt['source_initial_loss']==attempt['source_fresh_loss']
    if attempt['outcome']=='source_repair_failed':assert attempt['source_loss']>0


def check_reuse_sequence(traces,stats=None):
    reuses=0
    for trace in traces:
        previous=None
        for attempt in trace['attempts']:
            check_frame_attempt(attempt)
            check_reuse_attempt(attempt)
            if attempt['source_reused'] is None:continue
            if attempt['source_reused']:
                assert previous is not None, 'Reuse cannot cross invocation boundary'
                assert attempt['source_inventory']==previous['source_inventory']
                assert attempt['source_initial_loss']==previous['source_loss']
                reuses+=1
            previous=attempt
    if stats is not None:assert reuses==stats.get('directed_source_reuses',0)
    return reuses

