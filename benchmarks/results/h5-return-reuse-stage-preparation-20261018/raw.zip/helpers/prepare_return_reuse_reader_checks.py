from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/check_return_frame_stage_reader.py').read_text(encoding='utf-8')
s=s.replace('Capture two existing authored tests','Capture three existing authored tests')
s=s.replace('h5-return-frame-stage-diagnosis-20261017','h5-return-reuse-stage-diagnosis-20261018').replace('h5_return_frame_stage_diagnosis','h5_return_reuse_stage_diagnosis')
s=s.replace("binary=binaries[0];rows=[];attempts=[]", "binary=binaries[0];rows=[];attempts=[];all_traces=[]")
s=s.replace("'return_frame_keeps_incumbent_when_roundoff_increases_charged_material']:","'return_frame_keeps_incumbent_when_roundoff_increases_charged_material',\n             'reused_return_repairs_still_reject_material_increase_and_preserve_incumbent']:")
s=s.replace('    assert traces\n','    assert traces\n    runner.check_reuse_sequence(traces)\n    all_traces.extend(traces)\n')
extra="""
reused=next(a for a in attempts if a['source_reused'] is True)
def rejects_reuse(name,mutate):
    value=copy.deepcopy(reused);mutate(value)
    try:runner.check_reuse_attempt(value)
    except AssertionError:return name
    raise AssertionError('Trace reader accepted '+name)
rejected += [rejects_reuse('invalid reuse flag',lambda a:a.update(source_reused='true')),
             rejects_reuse('resumed loss worse than fresh',lambda a:a.update(source_initial_loss=a['source_fresh_loss']+1)),
             rejects_reuse('nonfinite weighted loss',lambda a:a.update(source_initial_weighted_loss=float('nan')))]
selected=next(t for t in all_traces if any(a['source_reused'] is True for a in t['attempts']))
def rejects_sequence(name,mutate,stats=None):
    value=copy.deepcopy([selected]);mutate(value)
    try:runner.check_reuse_sequence(value,stats)
    except AssertionError:return name
    raise AssertionError('Trace reader accepted '+name)
def reuse_index(value):return next(i for i,a in enumerate(value[0]['attempts']) if a['source_reused'] is True)
def missing_predecessor(value):value[0]['attempts']=value[0]['attempts'][reuse_index(value):]
def wrong_inventory(value):
    a=value[0]['attempts'][reuse_index(value)];a['source_inventory'].append(max(a['source_inventory'])+1)
def wrong_previous_loss(value):
    index=reuse_index(value)
    previous=next(a for a in reversed(value[0]['attempts'][:index]) if a['source_reused'] is not None)
    previous['source_loss']+=1
rejected += [rejects_sequence('reuse without same-call predecessor',missing_predecessor),
             rejects_sequence('different cached inventory',wrong_inventory),
             rejects_sequence('mismatched restored loss',wrong_previous_loss),
             rejects_sequence('inconsistent reuse counter',lambda value:None,{'directed_source_reuses':1000000})]
assert len(rejected)==12
"""
s=s.replace("record={'all_checks_pass':True",extra+"\nrecord={'all_checks_pass':True")
s=s.replace("'measured_development_searches':0,'quality_claim':False}","'actual_reuse_traces_checked':True,'cross_attempt_restoration_checked':True,\n        'measured_development_searches':0,'quality_claim':False}")
p=root/'output/check_return_reuse_stage_reader.py';compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
print('Prepared three authored trace checks and twelve malformed-record checks.')
