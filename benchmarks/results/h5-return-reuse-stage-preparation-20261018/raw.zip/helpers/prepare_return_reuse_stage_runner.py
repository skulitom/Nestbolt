from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'scripts/h5_return_frame_stage_diagnosis.py').read_text(encoding='utf-8')
s=s.replace('h5_return_frame_pilot','h5_return_reuse_pilot').replace('h5-return-frame-pilot-20261017','h5-return-reuse-pilot-20261018')
s=s.replace('h5-return-frame-stage-diagnosis-20261017','h5-return-reuse-stage-diagnosis-20261018')
s=s.replace('Observe frame legality, returned poses, repair losses and material rejection in the rejected return-frame candidate.',
            'Observe repair reuse, loss continuity and rejection stages in the rejected source-repair reuse candidate.')
s=s.replace('def read_trace(archive, record):',(root/'output/return_reuse_trace_snippet.py').read_text(encoding='utf-8')+'\ndef read_trace(archive, record):')
s=s.replace("    assert traces, 'Expected at least one recorded invocation'", "    assert traces, 'Expected at least one recorded invocation'\n    reuses=check_reuse_sequence(traces,record.get('stats') if record['status']=='valid' else None)")
s=s.replace("        'proposals':sum(t['proposals'] for t in traces), 'traces':traces}",
            "        'source_reuses':reuses,\n        'outcomes_by_reuse':{str(reused):dict(Counter(a['outcome'] for a in attempts if a['source_reused'] is reused)) for reused in [False,True,None]},\n        'proposals':sum(t['proposals'] for t in traces), 'traces':traces}")
s=s.replace("'source_change':'Previous sampling/repair stages plus incoming/victim/actual/hypothetical poses, per-member orientation legality, frame/fallback mode, initial/final losses and independent before/after material; one stderr trace per exchange invocation.'",
            "'source_change':'Read-only observations of fresh/resumed source losses, original item inventory, weighted losses, repair duration/budget and receiver/source/final acceptance stages; one stderr trace per invocation. Prior frame observations remain.'")
s=s.replace("    (prepare if args.action=='prepare' else run)(out)","    psutil.Process().cpu_affinity(list(range(16,32)))\n    (prepare if args.action=='prepare' else run)(out)")
p=root/'scripts/h5_return_reuse_stage_diagnosis.py';assert not p.exists()
compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
print('Prepared four-case diagnostic with reuse and cross-attempt state checks.')
