"""Independent explicit-set reconstruction of every zero/one/two-core exchange."""
from collections import Counter
from itertools import combinations
import gzip, json, shutil
from reduce_h5_free_cog_pool import ROOT, SRC, OLD, OUT as PARENT, load, write, digest
from census_h5_two_part_moves import OUT

def main():
    shutil.copyfile(__file__, OUT / 'audit.py')
    for p, h in load(OUT / 'plan.json')['inputs'].items():
        assert digest(ROOT / p) == h
    result = load(OUT / 'result.json')
    assert result['enumeration_complete'], 'Partial enumeration must not receive an exhaustive certificate.'
    pool = load(SRC / 'candidates.json')
    family = [p['placement']['part_id'] for p in pool]
    kept = set(load(PARENT / 'kept-candidates.json'))
    core = {i for i in load(PARENT / 'seed-indices.json') if family[i] != 'insert'}
    inserts = {i for i in kept if family[i] == 'insert'}
    cliques = []
    for p in [OLD / 'cliques.jsonl.gz', SRC / 'new-cliques.jsonl.gz']:
        with gzip.open(p, 'rt', encoding='utf-8') as f:
            cliques.extend(set(json.loads(line)) for line in f)
    neighbors = {i: set() for i in kept}
    for clique in cliques:
        selected = clique & kept
        for i in selected:
            neighbors[i].update(selected - {i})
    assert all(not(neighbors[i] & core) for i in core)
    def available(chosen):
        return frozenset(inserts - set().union(*(neighbors[i] for i in chosen)))
    expected = {((), ()): available(core)}
    outsiders = sorted(kept - inserts - core)
    for b in sorted(core):
        rest = core - {b}
        for a in outsiders:
            if family[a] == family[b] and not(neighbors[a] & rest):
                expected[((b,), (a,))] = available(rest | {a})
    double_count = 0
    for b, c in combinations(sorted(core), 2):
        rest = core - {b, c}
        allowed = [a for a in outsiders if not(neighbors[a] & rest)]
        wanted = Counter([family[b], family[c]])
        for a, d in combinations(allowed, 2):
            if Counter([family[a], family[d]]) != wanted or d in neighbors[a]:
                continue
            expected[((b, c), (a, d))] = available(rest | {a, d})
            double_count += 1
    observed = {}
    bounds = []
    sets = set()
    entries = 0
    for row in load(OUT / 'neighborhoods.json'):
        aset = frozenset(row['insert_candidates'])
        assert len(aset) == len(row['insert_candidates']) and aset not in sets
        sets.add(aset)
        for move in row['moves']:
            key = (tuple(move['removed']), tuple(move['added']))
            assert key not in observed
            assert expected[key] == aset
            observed[key] = aset
        covered = set()
        for group in row['cover']:
            ns = set(group['candidates'])
            assert ns and len(ns) == len(group['candidates']) and ns <= aset and not(ns & covered)
            if group['source_clique'] is None:
                assert len(ns) == 1
            else:
                assert ns <= cliques[group['source_clique']]
            covered |= ns
            entries += 1
        assert covered == aset and len(row['cover']) == row['certified_insert_upper_bound']
        bounds.append(len(row['cover']))
    assert observed == expected
    assert double_count == result['feasible_exact_two_replacements']
    assert len(expected) == result['all_moves_including_zero_and_one']
    assert len(bounds) == result['distinct_insert_sets']
    assert {str(k): v for k, v in Counter(bounds).items()} == result['cover_bound_histogram']
    assert max(bounds) == result['maximum_cover_bound']
    assert sum(b > 13 for b in bounds) == result['groups_not_ruled_out_for_improvement']
    assert sum(b >= 21 for b in bounds) == result['groups_not_ruled_out_for_full21']
    check = {'all_zero_one_two_moves_independently_enumerated': True,
             'exact_two_moves': double_count, 'all_moves': len(expected),
             'distinct_insert_sets': len(bounds), 'cover_entries_verified': entries,
             'maximum_certified_cover_bound': max(bounds),
             'any_improvement_ruled_out': max(bounds) <= 13,
             'full21_ruled_out': max(bounds) < 21,
             'scope': 'Only the finite two-core-move neighborhood about the saved mapped seed.',
             'unrestricted_impossibility_claimed': False, 'full_target_witness': False}
    write(OUT / 'audit.json', check)
    print(json.dumps(check), flush=True)

if __name__ == '__main__':
    main()
