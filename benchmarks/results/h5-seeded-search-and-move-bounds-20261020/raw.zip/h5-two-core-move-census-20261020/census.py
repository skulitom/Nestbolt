"""Exhaustive two-core replacement census within the audited retained pose pool."""
from collections import Counter
from datetime import datetime, timezone
from itertools import combinations
import gzip, json, shutil, time
from reduce_h5_free_cog_pool import ROOT, SRC, OLD, OUT as PARENT, load, write, digest
from census_h5_one_part_moves import bits

ONE = ROOT / 'output/h5-one-core-move-census-20261020'
OUT = ROOT / 'output/h5-two-core-move-census-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'census.py')
    sources = [PARENT / n for n in ['kept-candidates.json', 'seed-indices.json']]
    sources += [ONE / n for n in ['audit.json', 'neighborhoods.json']]
    sources += [SRC / 'candidates.json', OLD / 'cliques.jsonl.gz', SRC / 'new-cliques.jsonl.gz']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'method': 'Enumerate every pair of removed core poses and every compatible pair of different retained non-core poses with matching family counts. All other 43 core poses remain fixed; all insert positions remain free. Include previously audited zero/one-move cases. Deduplicate by exact available insert set and verify clique covers independently.',
        'limits': {'enumeration_seconds': 60, 'candidate_pairs': 2000000},
        'if_limit_reached': 'Preserve partial enumeration without an exhaustive neighborhood claim. No retry.',
        'scope': 'Original finite retained pool and mapped seed only. Two replacements may cross families. This is not continuous-placement impossibility or original-job acceptance.',
        'solver_calls': 0, 'native_packing_calls': 0, 'quality_runs': 0})
    pool = load(SRC / 'candidates.json')
    family = [p['placement']['part_id'] for p in pool]
    kept = set(load(PARENT / 'kept-candidates.json'))
    core = {i for i in load(PARENT / 'seed-indices.json') if family[i] != 'insert'}
    inserts = {i for i in kept if family[i] == 'insert'}
    candidates = sorted(kept - core - inserts)
    adjacency = [0] * len(pool)
    clique_masks = []
    for path in [OLD / 'cliques.jsonl.gz', SRC / 'new-cliques.jsonl.gz']:
        with gzip.open(path, 'rt', encoding='utf-8') as f:
            for line in f:
                group = json.loads(line)
                mask = sum(1 << i for i in group)
                clique_masks.append(mask)
                for i in group:
                    adjacency[i] |= mask ^ (1 << i)
    coremask = sum(1 << i for i in core)
    insmask = sum(1 << i for i in inserts)
    blockers = {i: adjacency[i] & coremask for i in candidates}
    candidates = [i for i in candidates if blockers[i].bit_count() <= 2]
    groups = {}
    for row in load(ONE / 'neighborhoods.json'):
        mask = sum(1 << i for i in row['insert_candidates'])
        groups[mask] = []
        for move in row['replacements']:
            groups[mask].append({'removed': [] if move is None else [move[0]],
                                 'added': [] if move is None else [move[1]]})
    start = time.perf_counter()
    tested = 0
    feasible = 0
    removal_pairs = 0
    complete = True
    for removed in combinations(sorted(core), 2):
        removedmask = sum(1 << i for i in removed)
        wanted = sorted(family[i] for i in removed)
        eligible = [i for i in candidates if family[i] in wanted and not(blockers[i] & ~removedmask)]
        blocked = 0
        for i in core - set(removed):
            blocked |= adjacency[i]
        for a, b in combinations(eligible, 2):
            if time.perf_counter() - start >= 60 or tested >= 2000000:
                complete = False
                break
            tested += 1
            if sorted([family[a], family[b]]) != wanted or adjacency[a] & (1 << b):
                continue
            available = insmask & ~(blocked | adjacency[a] | adjacency[b])
            groups.setdefault(available, []).append({'removed': list(removed), 'added': [a, b]})
            feasible += 1
        if not complete:
            break
        removal_pairs += 1
    enumeration_seconds = time.perf_counter() - start
    projected = {}
    for ci, mask in enumerate(clique_masks):
        cut = mask & insmask
        if cut.bit_count() > 1:
            projected.setdefault(cut, ci)
    records = []
    for index, (available, moves) in enumerate(sorted(groups.items())):
        options = {}
        for mask, ci in projected.items():
            cut = mask & available
            if cut.bit_count() > 1:
                options.setdefault(cut, ci)
        remaining = available
        cover = []
        while remaining:
            best = max(options, key=lambda mask: ((mask & remaining).bit_count(), -options[mask]), default=0)
            cut = best & remaining
            ci = options[best] if cut.bit_count() > 1 else None
            if ci is None:
                cut = remaining & -remaining
            cover.append({'source_clique': ci, 'candidates': list(bits(cut))})
            remaining &= ~cut
        records.append({'index': index, 'insert_candidates': list(bits(available)), 'moves': moves,
                        'cover': cover, 'certified_insert_upper_bound': len(cover)})
    write(OUT / 'neighborhoods.json', records)
    result = {'enumeration_complete': complete, 'enumeration_seconds': enumeration_seconds,
              'total_seconds': time.perf_counter() - start, 'removal_pairs_completed': removal_pairs,
              'candidate_pairs_tested': tested, 'feasible_exact_two_replacements': feasible,
              'all_moves_including_zero_and_one': sum(len(r['moves']) for r in records),
              'distinct_insert_sets': len(records),
              'cover_bound_histogram': dict(Counter(r['certified_insert_upper_bound'] for r in records)),
              'groups_not_ruled_out_for_improvement': sum(len(r['cover']) > 13 for r in records),
              'groups_not_ruled_out_for_full21': sum(len(r['cover']) >= 21 for r in records),
              'maximum_cover_bound': max(len(r['cover']) for r in records),
              'full_target_witness': False}
    write(OUT / 'result.json', result)
    print(json.dumps(result), flush=True)

if __name__ == '__main__':
    main()
