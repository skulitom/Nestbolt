"""Independent explicit-set enumeration and clique-cover verification."""
from pathlib import Path
import gzip,json,shutil
from reduce_h5_free_cog_pool import ROOT,SRC,OLD,OUT as PARENT,load,write,digest
OUT=ROOT/'output/h5-one-core-move-census-20261020'
def main():
    shutil.copyfile(__file__,OUT/'audit.py')
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');kept=set(load(PARENT/'kept-candidates.json'));seed=load(PARENT/'seed-indices.json')
    core={i for i in seed if pool[i]['placement']['part_id']!='insert'}
    inserts={i for i in kept if pool[i]['placement']['part_id']=='insert'}
    cliques=[]
    for path in [OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']:
        with gzip.open(path,'rt',encoding='utf-8') as f:cliques.extend(set(json.loads(l)) for l in f)
    blockers={i:set() for i in kept-inserts};blocked_inserts={i:set() for i in kept-inserts}
    for clique in cliques:
        selected=clique&core;cut=clique&inserts
        for i in clique&blockers.keys():
            blockers[i].update(selected-{i});blocked_inserts[i].update(cut)
    expected={None:frozenset(inserts-set().union(*(blocked_inserts[i] for i in core)))}
    for b in sorted(core):
        remainder=core-{b};blocked=set().union(*(blocked_inserts[i] for i in remainder))
        for a in kept-core-inserts:
            if pool[a]['placement']['part_id']!=pool[b]['placement']['part_id']:continue
            if blockers[a]&remainder:continue
            expected[(b,a)]=frozenset(inserts-blocked-blocked_inserts[a])
    observed={};cover_entries=0
    for row in load(OUT/'neighborhoods.json'):
        available=set(row['insert_candidates']);covered=set()
        assert len(available)==len(row['insert_candidates'])
        for move in row['replacements']:
            key=None if move is None else tuple(move)
            assert key not in observed and expected[key]==available;observed[key]=frozenset(available)
        for group in row['cover']:
            nodes=set(group['candidates']);assert nodes and nodes<=available and not(nodes&covered)
            if group['source_clique'] is None:assert len(nodes)==1
            else:assert nodes<=cliques[group['source_clique']]
            covered.update(nodes);cover_entries+=1
        assert covered==available and len(row['cover'])==row['certified_insert_upper_bound']
        assert row['can_improve_not_ruled_out']==(len(row['cover'])>13)
        assert row['full_21_not_ruled_out']==(len(row['cover'])>=21)
    assert observed==expected
    result=load(OUT/'result.json');assert len(expected)-1==result['feasible_single_replacements']
    check={'all_feasible_single_replacements_independently_enumerated':True,'single_replacements':len(expected)-1,
        'no_change_included':True,'all_available_insert_sets_exact':True,'clique_cover_entries_verified':cover_entries,
        'maximum_certified_cover_bound':result['maximum_cover_bound'],
        'full21_ruled_out_in_entire_one_core_move_neighborhood':result['groups_not_ruled_out_for_full21']==0,
        'unrestricted_impossibility_claimed':False,'full_target_witness':False}
    write(OUT/'audit.json',check);print(json.dumps(check),flush=True)
if __name__=='__main__':main()
