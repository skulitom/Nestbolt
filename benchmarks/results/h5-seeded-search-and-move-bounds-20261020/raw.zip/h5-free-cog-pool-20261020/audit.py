"""Check every free-cog-pool substitution with explicit sets and validate its seed."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import gzip,json,copy,math,shutil,subprocess
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT,SRC,OLD,SEED,OUT,load,write,digest
def main():
    shutil.copyfile(__file__,OUT/'audit.py')
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');substitutions=load(OUT/'substitutions.json');kept=set(load(OUT/'kept-candidates.json'))
    removed={r['removed'] for r in substitutions};assert kept|removed==set(range(len(pool))) and not kept&removed
    needed={i for r in substitutions for i in [r['removed'],r['kept']]};owners={i:[] for i in needed};cliques=[]
    for path in [OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']:
        with gzip.open(path,'rt',encoding='utf-8') as f:
            for line in f:
                c=set(json.loads(line));ci=len(cliques);cliques.append(c)
                for i in c&needed:owners[i].append(ci)
    neighborhoods={}
    def neighbors(i):
        if i not in neighborhoods:neighborhoods[i]=set().union(*(cliques[j] for j in owners[i]))-{i}
        return neighborhoods[i]
    for r in substitutions:
        a,b=r['kept'],r['removed'];assert a in kept and b in removed
        assert pool[a]['placement']['part_id']==pool[b]['placement']['part_id']==r['family']
        assert a in neighbors(b) and b in neighbors(a)
        assert neighbors(a)-{b}<=neighbors(b)-{a}
    seed=load(OUT/'seed-indices.json');assert len(seed)==len(set(seed))==58 and set(seed)<=kept
    assert all(len(c&set(seed))<=1 for c in cliques)
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance']
    target=load(SRC/'conditional-target.json');counts=Counter();placements=[];geoms=defaultdict(list);tops=Counter()
    for i in seed:
        p=copy.deepcopy(pool[i]['placement']);part=parts[p['part_id']];t=p['transform']
        assert not t['mirrored'] or part['allow_mirror']
        if part['rotations']['kind']=='list':
            assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
        p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
        g=shape(part,t);x0,y0,x1,y1=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        assert g.is_valid and x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7
        assert x1<=stock['width']-m['right']-edge+1e-7 and y1<=h-m['top']-edge+1e-7
        geoms[p['sheet_id']].append(g);tops[p['sheet_id']]=max(tops[p['sheet_id']],y1+m['top']+edge)
    assert counts=={'frame':18,'bracket':12,'cog':15,'insert':13}
    pairs=0;minimum=math.inf
    for gs in geoms.values():
        for a,b in combinations(gs,2):
            pairs+=1;d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=job['clearance']-1e-7
    material=stock['width']*(stock['height']+tops['sheet-1']);assert material<=target['target_material_mm2']+1e-6
    sheets=load(SEED/'selected-layout.json')['sheets'];path=OUT/'seed-layout.json'
    write(path,{'version':1,'units':'mm','sheets':sheets,'placements':placements})
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    cmd=[str(cli),'validate','--library',str(SRC/'library.json'),'--request',str(SRC/'request.json'),'--layout',str(path)]
    cp=subprocess.run(cmd,capture_output=True,timeout=60);(OUT/'seed-public.json').write_bytes(cp.stdout)
    (OUT/'seed-public.stderr').write_bytes(cp.stderr);write(OUT/'seed-command.json',{'command':cmd,'exit_code':cp.returncode})
    public=json.loads(cp.stdout);assert not public['valid'] and cp.returncode!=0
    assert public['violations']==[{'code':'quantity','message':'part insert: expected 21, found 13'}]
    check={'all_substitutions_verified_with_sets':True,'substitutions_checked':len(substitutions),
        'all_dominators_are_final_survivors':True,'all_original_families_in_conflict_neighborhoods':True,
        'mapped_seed_geometry_checked':True,'seed_pairs':pairs,'minimum_distance_mm':minimum,
        'charged_material_mm2':material,'original_CLI_quantity_only_failure':True,
        'full_target_witness':False,'native_margin_qualified':False}
    write(OUT/'audit.json',check);print(json.dumps(check),flush=True)
if __name__=='__main__':main()
