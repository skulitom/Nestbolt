"""Build and independently reconstruct a whole-part model with movable cogs."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import gzip,json,shutil
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT,SRC,OLD,OUT,load,write,digest
def main():
    shutil.copyfile(__file__,OUT/'prepare-model.py')
    assert load(OUT/'audit.json')['all_substitutions_verified_with_sets']
    inputs=[OUT/n for n in ['plan.json','result.json','audit.json','kept-candidates.json','substitutions.json',
        'seed-indices.json','seed-layout.json','seed-public.json','seed-command.json']]
    inputs += [SRC/n for n in ['candidates.json','job.json','new-cliques.jsonl.gz','conditional-target.json']]
    inputs += [OLD/'cliques.jsonl.gz']
    write(OUT/'model-plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'seconds_limit':60,'workers':8,'seed':0,
        'method':'Use every certified surviving pose from the fully audited 9059-pose pool. Cogs are independent original poses, not fixed macros. Require exactly 18 frames,12 brackets and15 cogs; maximize inserts between the valid seed count13 and original cap21. Preserve every original conflict. No artificial old-frame exclusions or uncomputed extra-contact edges. Give all variables a complete feasible hint. One solver call, no retry.',
        'scope':'The lower insert bound comes from a physical partial; original acceptance still requires all21. A restricted optimum is not an unrestricted geometric upper bound.',
        'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');ids=load(OUT/'kept-candidates.json');local={i:j for j,i in enumerate(ids)}
    cliques=[]
    for path in [OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']:
        with gzip.open(path,'rt',encoding='utf-8') as f:cliques.extend(set(json.loads(l)) for l in f)
    rows=sorted({tuple(sorted(c&local.keys())) for c in cliques if len(c&local.keys())>1})
    model=cp_model.CpModel();variables=[model.new_bool_var(f'p{i}') for i in ids]
    for row in rows:model.add_at_most_one(variables[local[i]] for i in row)
    families={f:[j for j,i in enumerate(ids) if pool[i]['placement']['part_id']==f] for f in ['frame','bracket','cog','insert']}
    for f,count in [('frame',18),('bracket',12),('cog',15)]:model.add(sum(variables[j] for j in families[f])==count)
    model.add_linear_constraint(sum(variables[j] for j in families['insert']),13,21)
    model.maximize(sum(variables[j] for j in families['insert']))
    chosen=set(load(OUT/'seed-indices.json'));hint=[int(i in chosen) for i in ids]
    for j,value in enumerate(hint):model.add_hint(variables[j],value)
    assert model.validate()=='';model.export_to_file(str(OUT/'model.pbtxt'))
    expected=cp_model_pb2.CpModelProto()
    for i in ids:v=expected.variables.add();v.name=f'p{i}';v.domain.extend([0,1])
    # Derive variable-index cliques independently from the original source rows.
    projected=set()
    for group in cliques:
        literals=tuple(sorted(local[i] for i in group if i in local))
        if len(literals)>1:projected.add(literals)
    for literals in sorted(projected):expected.constraints.add().at_most_one.literals.extend(literals)
    for f,lo,hi in [('frame',18,18),('bracket',12,12),('cog',15,15),('insert',13,21)]:
        c=expected.constraints.add().linear;c.vars.extend(families[f]);c.coeffs.extend([1]*len(families[f]));c.domain.extend([lo,hi])
    expected.objective.vars.extend(families['insert']);expected.objective.coeffs.extend([-1]*len(families['insert']));expected.objective.scaling_factor=-1
    expected.solution_hint.vars.extend(range(len(ids)));expected.solution_hint.values.extend(hint)
    actual=text_format.Parse((OUT/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
    assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
    for c in expected.constraints:
        if c.WhichOneof('constraint')=='at_most_one':assert sum(hint[j] for j in c.at_most_one.literals)<=1
        else:
            value=sum(co*hint[j] for j,co in zip(c.linear.vars,c.linear.coeffs))
            assert c.linear.domain[0]<=value<=c.linear.domain[1]
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=60;solver.parameters.num_search_workers=8
    solver.parameters.random_seed=0;solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    write(OUT/'complete-hint.json',hint)
    write(OUT/'model-audit.json',{'all_model_fields_independently_reconstructed':True,'variables':len(ids),
        'cliques':len(projected),'constraints':len(expected.constraints),'family_variables':{f:len(v) for f,v in families.items()},
        'complete_hint_exactly_feasible':True,'seed_insert_count':13,'all_four_families_movable':True,
        'model_sha256':digest(OUT/'model.pbtxt'),'parameters_sha256':digest(OUT/'parameters.pbtxt')})
    print((OUT/'model-audit.json').read_text(),flush=True)
if __name__=='__main__':main()
