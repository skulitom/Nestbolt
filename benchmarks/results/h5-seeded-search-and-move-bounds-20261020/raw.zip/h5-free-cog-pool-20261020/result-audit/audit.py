"""Audit every returned full-pool selection in original geometry."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import copy,json,math,shutil,subprocess,gzip
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT,SRC,OLD,SEED,OUT as PARENT,load,write,digest
RUN=PARENT/'solve';OUT=PARENT/'result-audit'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    for p,h in load(PARENT/'model-plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    target=load(SRC/'conditional-target.json');stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance']
    sheets=load(PARENT/'seed-layout.json')['sheets'];kept=set(load(PARENT/'kept-candidates.json'));cliques=[]
    for path in [OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']:
        with gzip.open(path,'rt',encoding='utf-8') as f:cliques.extend(set(json.loads(l)) for l in f)
    result=load(RUN/'result.json');records=[];fresh=0;reused=0
    outcomes=[load(RUN/f'incumbent-{i}.json') for i in range(result['incumbents'])]
    if result['feasible']:
        final=load(RUN/'selected-indices.json')
        if not outcomes or final!=outcomes[-1]['selected_indices']:
            outcomes.append({'index':'final','selected_indices':final,'inserts':result['inserts']})
    else:assert not outcomes and not (RUN/'selected-indices.json').exists()
    seed=load(PARENT/'seed-indices.json')
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    for r in outcomes:
        ids=r['selected_indices'];assert len(ids)==len(set(ids)) and set(ids)<=kept
        assert all(len(c&set(ids))<=1 for c in cliques)
        counts=Counter();placements=[];geometries=defaultdict(list);tops=Counter()
        for i in ids:
            p=copy.deepcopy(pool[i]['placement']);part=parts[p['part_id']];t=p['transform']
            p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':
                assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            g=shape(part,t);x0,y0,x1,y1=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
            assert g.is_valid and x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7
            assert x1<=stock['width']-m['right']-edge+1e-7 and y1<=h-m['top']-edge+1e-7
            geometries[p['sheet_id']].append(g);tops[p['sheet_id']]=max(tops[p['sheet_id']],y1+m['top']+edge)
        assert counts==Counter(frame=18,bracket=12,cog=15,insert=r['inserts']) and 13<=r['inserts']<=21
        pairs=0;minimum=math.inf
        for gs in geometries.values():
            for a,b in combinations(gs,2):
                pairs+=1;distance=a.distance(b);minimum=min(minimum,distance)
                assert a.disjoint(b) and distance>=job['clearance']-1e-7
        key=r['index'];path=OUT/f'layout-{key}.json'
        layout={'version':1,'units':'mm','sheets':sheets,'placements':placements};write(path,layout)
        material=stock['width']*(stock['height']+tops['sheet-1']);assert material<=target['target_material_mm2']+1e-6
        if ids==seed:
            assert layout==load(PARENT/'seed-layout.json')
            public=load(PARENT/'seed-public.json');returncode=load(PARENT/'seed-command.json')['exit_code'];reused+=1
            write(OUT/f'validation-reuse-{key}.json',{'rerun':False,'exact_seed_layout_match':True,
                'source_files':{str((PARENT/n).relative_to(ROOT)):digest(PARENT/n) for n in ['seed-layout.json','seed-public.json','seed-command.json']}})
            shutil.copyfile(PARENT/'seed-public.json',OUT/f'public-{key}.json')
        else:
            cmd=[str(cli),'validate','--library',str(SRC/'library.json'),'--request',str(SRC/'request.json'),'--layout',str(path)]
            cp=subprocess.run(cmd,capture_output=True,timeout=60);returncode=cp.returncode;fresh+=1
            (OUT/f'public-{key}.json').write_bytes(cp.stdout);(OUT/f'public-{key}.stderr').write_bytes(cp.stderr)
            write(OUT/f'command-{key}.json',{'command':cmd,'exit_code':cp.returncode});public=json.loads(cp.stdout)
        missing=21-r['inserts'];assert public['valid']==(missing==0)
        if missing:assert returncode!=0 and public['violations']==[{'code':'quantity','message':f"part insert: expected 21, found {r['inserts']}"}]
        else:assert returncode==0 and not public['violations']
        records.append({'incumbent':key,'inserts':r['inserts'],'missing_inserts':missing,'pairs':pairs,
            'minimum_distance_mm':minimum,'charged_material_mm2':material,
            'filled_area_mm2':sum(g.area for gs in geometries.values() for g in gs),
            'original_CLI_valid':public['valid'],'exact_seed_validation_reused':ids==seed})
    check={'status':result['status'],'seconds':result['seconds'],'all_returned_layouts_checked':len(records),
        'records':records,'fresh_frozen_CLI_calls':fresh,'reused_frozen_CLI_results':reused,
        'improved_on_seed':any(r['inserts']>13 for r in records),'full_target_witness':any(r['original_CLI_valid'] for r in records),
        'native_margin_qualified':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',check);print(json.dumps(check),flush=True)
if __name__=='__main__':main()
