from datetime import datetime,timezone
import json,shutil,time,traceback
from ortools.sat.python import cp_model
from reduce_h5_free_cog_pool import SRC,OUT as ROOT,load,write,digest
OUT=ROOT/'solve'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');audit=load(ROOT/'model-audit.json')
    assert audit['all_model_fields_independently_reconstructed']
    assert digest(ROOT/'model.pbtxt')==audit['model_sha256']
    assert digest(ROOT/'parameters.pbtxt')==audit['parameters_sha256']
    pool=load(SRC/'candidates.json');ids=load(ROOT/'kept-candidates.json');model=cp_model.CpModel()
    assert model.proto.parse_text_format((ROOT/'model.pbtxt').read_text());model.rebuild_constant_map();assert model.validate()==''
    solver=cp_model.CpSolver();assert solver.parameters.parse_text_format((ROOT/'parameters.pbtxt').read_text())
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'seconds_limit':60,'seed_inserts':13})
    records=[]
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            chosen=[i for j,i in enumerate(ids) if self.value(model.get_int_var_from_proto_index(j))]
            count=sum(pool[i]['placement']['part_id']=='insert' for i in chosen)
            r={'index':len(records),'selected_indices':chosen,'inserts':count,'seconds':self.wall_time,
                'objective':self.objective_value,'best_bound':self.best_objective_bound}
            assert count==r['objective'];write(OUT/f"incumbent-{r['index']}.json",r);records.append(r)
            print(json.dumps({k:v for k,v in r.items() if k!='selected_indices'}),flush=True)
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush())
        start=time.perf_counter();status=solver.solve(model,Capture());seconds=time.perf_counter()-start
    feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    result={'status':solver.status_name(status),'seconds':seconds,'feasible':feasible,'incumbents':len(records),
        'response_stats':solver.response_stats(),'seed_inserts':13,'full_target_witness':False,'native_margin_qualified':False}
    if feasible:
        chosen=[i for j,i in enumerate(ids) if solver.value(model.get_int_var_from_proto_index(j))]
        count=sum(pool[i]['placement']['part_id']=='insert' for i in chosen);assert count>=13
        write(OUT/'selected-indices.json',chosen)
        result.update(inserts=count,missing_inserts=21-count,best_bound=solver.best_objective_bound,
            improved_on_seed=count>13,full_inventory_candidate=count==21)
    write(OUT/'result.json',result);print(json.dumps({k:v for k,v in result.items() if k!='response_stats'}),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
