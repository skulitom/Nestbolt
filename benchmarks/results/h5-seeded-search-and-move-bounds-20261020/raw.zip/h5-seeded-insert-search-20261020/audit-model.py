"""Reconstruct the complete integer models and verify complete starting hints."""
import gzip,json,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from prepare_h5_seeded_insert_search import ROOT,SRC,RED,JOINT,SEED,CAP,OUT,load,write,digest
def main():
    shutil.copyfile(__file__,OUT/'audit-model.py')
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');mp={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    with gzip.open(CAP/'area-cuts.jsonl.gz','rt',encoding='utf-8') as f:areas=[json.loads(l) for l in f]
    cogs=load(SRC/'cog-skeletons.json')['sets'];checks=[]
    for prepared in load(OUT/'prepared.json'):
        case=prepared['case'];dest=OUT/f'case-{case}';mapping=load(dest/'mapping.json')
        assert digest(dest/'model.pbtxt')==prepared['model_sha256']
        ids=sorted(set(load(RED/f'case-{case}/kept-candidates.json'))|
            {i for i,r in mp.items() if pool[i]['placement']['part_id']=='insert' and case in r['compatible_skeletons']})
        assert ids==mapping['candidates'] and mapping['fixed_cog_candidates']==cogs[case]['candidates']
        assert all(case in mp[i]['compatible_skeletons'] for i in ids)
        local={i:j for j,i in enumerate(ids)};rows=sorted({tuple(sorted(c&local.keys())) for c in cliques if len(c&local.keys())>1})
        expected=cp_model_pb2.CpModelProto()
        for i in ids:v=expected.variables.add();v.name=f'p{i}';v.domain.extend([0,1])
        for row in rows:expected.constraints.add().at_most_one.literals.extend(local[i] for i in row)
        families={f:[j for j,i in enumerate(ids) if pool[i]['placement']['part_id']==f] for f in ['frame','bracket','insert']}
        minimum=load(SEED/'checks.json')['cases'][case]['seed_inserts'];assert mapping['minimum_inserts']==minimum
        for family,lo,hi in [('frame',18,18),('bracket',12,12),('insert',minimum,21)]:
            c=expected.constraints.add().linear;c.vars.extend(families[family]);c.coeffs.extend([1]*len(families[family]));c.domain.extend([lo,hi])
        active=[]
        for group in load(JOINT/f'case-{case}/mapping.json')['excluded_frame_sets']:
            terms=[local[i] for i in group if i in local]
            if len(terms)<=17:continue
            active.append(group);c=expected.constraints.add().linear;c.vars.extend(terms);c.coeffs.extend([1]*len(terms));c.domain.extend([-(2**63),17])
        assert active==mapping['active_excluded_frame_sets']
        area_rows=load(dest/'area-rows.json');assert len(area_rows)==len(areas)==58
        original_var_to_local={mp[i]['var']:j for j,i in enumerate(ids)}
        for index,(area,saved) in enumerate(zip(areas,area_rows)):
            constant=0;terms=[]
            for oldvar,coef in zip(area['indices'],area['coeffs']):
                if oldvar<4:
                    if oldvar==case:constant+=coef
                elif oldvar in original_var_to_local:terms.append((original_var_to_local[oldvar],coef))
            terms.sort();rhs=area['rhs']-constant
            assert saved=={'source_row':index,'indices':[j for j,c in terms],'coeffs':[c for j,c in terms],
                'fixed_cog_area':constant,'rhs':rhs,'tautology':not terms}
            if not terms:assert rhs>=0;continue
            c=expected.constraints.add().linear;c.vars.extend(j for j,coef in terms);c.coeffs.extend(coef for j,coef in terms);c.domain.extend([-(2**63),rhs])
        expected.objective.vars.extend(families['insert']);expected.objective.coeffs.extend([-1]*len(families['insert']));expected.objective.scaling_factor=-1
        chosen=set(load(SEED/f'case-{case}-selected-indices.json'));hint=[int(i in chosen) for i in ids]
        assert load(dest/'complete-hint.json')==hint and chosen-set(cogs[case]['candidates'])<=set(ids)
        expected.solution_hint.vars.extend(range(len(ids)));expected.solution_hint.values.extend(hint)
        for c in expected.constraints:
            kind=c.WhichOneof('constraint')
            if kind=='at_most_one':assert sum(hint[j] for j in c.at_most_one.literals)<=1
            else:
                value=sum(co*hint[j] for j,co in zip(c.linear.vars,c.linear.coeffs))
                assert c.linear.domain[0]<=value<=c.linear.domain[1]
        actual=text_format.Parse((dest/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
        assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
        checks.append({'case':case,'variables':len(ids),'constraints':len(expected.constraints),
            'model_reconstructed_in_full':True,'all_area_rows_exactly_substituted':True,
            'complete_hint_exactly_feasible':True,'seed_inserts':minimum})
    write(OUT/'model-audit.json',{'all_four_models_exact':True,'cases':checks,'full_target_witness':False})
    print(json.dumps(checks),flush=True)
if __name__=='__main__':main()
