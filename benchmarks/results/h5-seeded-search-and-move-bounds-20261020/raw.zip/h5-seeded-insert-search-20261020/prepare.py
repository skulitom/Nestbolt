"""Reduced whole-part selection with actual insert objective and complete hints."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import gzip,json,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
RED=ROOT/'output/h5-dominated-pose-reduction-20261020'
JOINT=ROOT/'output/h5-reduced-joint-frames-brackets-20261020'
SEED=ROOT/'output/h5-certified-partial-seeds-20261020'
CAP=ROOT/'output/h5-area-capacities-20261020'
OUT=ROOT/'output/h5-seeded-insert-search-20261020'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[SRC/n for n in ['job.json','candidates.json','mapping.json','cog-skeletons.json',
        'projected-cliques.jsonl.gz','audit/checks.json','conditional-target.json']]
    inputs += [RED/'audit.json',SEED/'checks.json',CAP/'preparation.json',CAP/'area-cuts.jsonl.gz']
    for i in range(4):inputs += [RED/f'case-{i}/kept-candidates.json',JOINT/f'case-{i}/mapping.json',
        SEED/f'case-{i}-selected-indices.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'cases':[0,1,2,3],'seconds_per_case':30,'workers':8,'seed':0,
        'method':'Fix one complete original cog arrangement. Retain the independently certified frame/bracket survivors and ALL compatible original insert poses. Select exactly 18 frames and 12 brackets; maximize actual whole inserts between the already verified case seed count and the original cap 21. Preserve every original projected conflict and old frame exclusion. Add the 58 previously audited necessary local-area capacities after substituting the fixed cog choice and absent candidates. Give every variable a complete feasible zero/one hint from the 12,12,13,13-insert partials. One bounded call per case; retain every returned incumbent, including unchanged seeds. No suffix retry.',
        'seed_scope':'The lower insert count is an optimization bound from a known feasible partial, not a changed full-job requirement. Only all 21 inserts can count toward original job acceptance.',
        'acceptance':'A full 66-copy candidate still requires independent original geometry, frozen CLI, native margins and unchanged full H5 material/cutting gates. Restricted search failure is not global impossibility.',
        'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');mapping={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    with gzip.open(CAP/'area-cuts.jsonl.gz','rt',encoding='utf-8') as f:areas=[json.loads(l) for l in f]
    cogs=load(SRC/'cog-skeletons.json')['sets'];seeds=load(SEED/'checks.json')['cases'];prepared=[]
    for case in range(4):
        dest=OUT/f'case-{case}';dest.mkdir()
        retained=set(load(RED/f'case-{case}/kept-candidates.json'))
        ins={i for i,r in mapping.items() if pool[i]['placement']['part_id']=='insert' and case in r['compatible_skeletons']}
        ids=sorted(retained|ins);local={i:j for j,i in enumerate(ids)}
        rows=sorted({tuple(sorted(c&local.keys())) for c in cliques if len(c&local.keys())>1})
        exclusions=load(JOINT/f'case-{case}/mapping.json')['excluded_frame_sets']
        seed=set(load(SEED/f'case-{case}-selected-indices.json'))
        assert seed-set(cogs[case]['candidates'])<=set(ids)
        hint=[int(i in seed) for i in ids];minimum=seeds[case]['seed_inserts']
        model=cp_model.CpModel();variables=[model.new_bool_var(f'p{i}') for i in ids]
        for row in rows:
            assert len(set(row)&seed)<=1
            model.add_at_most_one(variables[local[i]] for i in row)
        for family,count in [('frame',18),('bracket',12)]:
            familyvars=[j for j,i in enumerate(ids) if pool[i]['placement']['part_id']==family]
            assert sum(hint[j] for j in familyvars)==count
            model.add(sum(variables[j] for j in familyvars)==count)
        insertvars=[local[i] for i in sorted(ins)];assert sum(hint[j] for j in insertvars)==minimum
        model.add_linear_constraint(sum(variables[j] for j in insertvars),minimum,21)
        active_exclusions=[]
        for group in exclusions:
            terms=[local[i] for i in group if i in local]
            if len(terms)<=17:continue
            assert sum(hint[j] for j in terms)<=17
            model.add(sum(variables[j] for j in terms)<=17);active_exclusions.append(group)
        translated=[]
        for index,area in enumerate(areas):
            coeff=dict(zip(area['indices'],area['coeffs']));constant=coeff.get(case,0)
            terms=[(j,coeff[mapping[i]['var']]) for j,i in enumerate(ids) if mapping[i]['var'] in coeff]
            rhs=area['rhs']-constant;assert sum(c*hint[j] for j,c in terms)<=rhs
            if terms:model.add(sum(c*variables[j] for j,c in terms)<=rhs)
            else:assert rhs>=0
            translated.append({'source_row':index,'indices':[j for j,c in terms],'coeffs':[c for j,c in terms],
                'fixed_cog_area':constant,'rhs':rhs,'tautology':not terms})
        model.maximize(sum(variables[j] for j in insertvars))
        for j,v in enumerate(variables):model.add_hint(v,hint[j])
        assert model.validate()=='';model.export_to_file(str(dest/'model.pbtxt'))
        write(dest/'mapping.json',{'case':case,'candidates':ids,'fixed_cog_candidates':cogs[case]['candidates'],
            'minimum_inserts':minimum,'active_excluded_frame_sets':active_exclusions})
        write(dest/'area-rows.json',translated);write(dest/'complete-hint.json',hint)
        solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=30;solver.parameters.num_search_workers=8
        solver.parameters.random_seed=0;solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
        (dest/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
        prepared.append({'case':case,'variables':len(ids),'frame_bracket_variables':len(retained),'insert_variables':len(ins),
            'cliques':len(rows),'area_rows':len(translated),'minimum_inserts':minimum,
            'complete_hint_feasible':True,'model_sha256':digest(dest/'model.pbtxt'),
            'parameters_sha256':digest(dest/'parameters.pbtxt')})
    write(OUT/'prepared.json',prepared);print(json.dumps(prepared),flush=True)
if __name__=='__main__':main()
