"""Check all returned integer layouts; reuse exact unchanged validation evidence."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import copy,json,math,shutil,subprocess,gzip
from audit_h5_cog_lattices import shape,load,write,digest
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
RUN=ROOT/'output/h5-seeded-insert-search-20261020';OUT=RUN/'result-audit'
OLD=ROOT/'output/h5-substituted-insert-completion-20261020'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    for p,h in load(RUN/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json')
    cogs=load(SRC/'cog-skeletons.json')['sets'];sheets=load(SRC/'selected-layout.json')['sheets']
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    records=[];cases=[];fresh=0;reused=0;cached={}
    manifest=load(ROOT/'benchmarks/results/h5-dominated-poses-and-seeds-20261020/raw-manifest.json')
    hashes={r['path']:r['sha256'] for r in manifest['files']}
    for row in load(OLD/'result-audit/checks.json')['records']:
        case=row['case'];key=row['incumbent']
        ids=load(OLD/f'case-{case}/selected-indices.json')
        parent=OLD/f'result-audit/case-{case}'
        paths=[parent/f'layout-{key}.json',parent/f'public-{key}.json',parent/f'command-{key}.json']
        for p in paths:
            name=OLD.name+'/'+p.relative_to(OLD).as_posix();assert digest(p)==hashes[name]
        cached[tuple(ids)]=paths
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    for result in load(RUN/'results.json'):
        case=result['case'];source=RUN/f'case-{case}';dest=OUT/f'case-{case}';dest.mkdir()
        mp=load(source/'mapping.json');local={i:j for j,i in enumerate(mp['candidates'])}
        outcomes=[load(source/f'incumbent-{i}.json') for i in range(result['incumbents'])]
        if result['feasible']:
            final=load(source/'selected-indices.json')
            if not outcomes or final!=outcomes[-1]['selected_indices']:
                outcomes.append({'index':'final','selected_indices':final,'inserts':result['inserts']})
        else:
            assert not outcomes and not (source/'selected-indices.json').exists()
            cases.append({'case':case,'status':result['status'],'returned_layout':False});continue
        last=mp['minimum_inserts']
        for record in outcomes:
            ids=record['selected_indices'];chosen=set(ids);assert len(chosen)==len(ids)
            assert set(mp['fixed_cog_candidates'])==set(cogs[case]['candidates'])
            assert set(mp['fixed_cog_candidates'])<=chosen and chosen-set(mp['fixed_cog_candidates'])<=set(local)
            assert all(len(c&chosen)<=1 for c in cliques)
            assert last<=record['inserts']<=21;last=record['inserts']
            for group in mp['active_excluded_frame_sets']:assert len(set(group)&chosen)<=17
            present={local[i] for i in chosen if i in local}
            for row in load(source/'area-rows.json'):
                assert sum(c for j,c in zip(row['indices'],row['coeffs']) if j in present)<=row['rhs']
            counts=Counter();placements=[];geoms=defaultdict(list);tops=Counter()
            for i in ids:
                p=copy.deepcopy(pool[i]['placement']);part=parts[p['part_id']];t=p['transform']
                p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
                assert not t['mirrored'] or part['allow_mirror']
                if part['rotations']['kind']=='list':
                    assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
                g=shape(part,t);x0,y0,x1,y1=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
                assert g.is_valid and x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7
                assert x1<=stock['width']-m['right']-edge+1e-7 and y1<=h-m['top']-edge+1e-7
                geoms[p['sheet_id']].append(g);tops[p['sheet_id']]=max(tops[p['sheet_id']],y1+m['top']+edge)
            assert counts==Counter(frame=18,bracket=12,cog=15,insert=record['inserts'])
            minimum=math.inf;pairs=0
            for gs in geoms.values():
                for a,b in combinations(gs,2):
                    pairs+=1;distance=a.distance(b);minimum=min(minimum,distance)
                    assert a.disjoint(b) and distance>=job['clearance']-1e-7
            key=record['index'];path=dest/f'layout-{key}.json'
            layout={'version':1,'units':'mm','sheets':sheets,'placements':placements};write(path,layout)
            material=stock['width']*(stock['height']+tops['sheet-1']);assert material<=target['target_material_mm2']+1e-6
            if tuple(ids) in cached:
                previous_layout,previous_public,previous_command=cached[tuple(ids)]
                assert load(previous_layout)==layout
                public=load(previous_public);returncode=load(previous_command)['exit_code'];reused+=1
                write(dest/f'validation-reuse-{key}.json',{'rerun':False,'exact_layout_match':True,
                    'source_files':{str(p.relative_to(ROOT)):digest(p) for p in cached[tuple(ids)]}})
                shutil.copyfile(previous_public,dest/f'public-{key}.json')
            else:
                cmd=[str(cli),'validate','--library',str(SRC/'library.json'),'--request',str(SRC/'request.json'),'--layout',str(path)]
                cp=subprocess.run(cmd,capture_output=True,timeout=60);returncode=cp.returncode;fresh+=1
                (dest/f'public-{key}.json').write_bytes(cp.stdout);(dest/f'public-{key}.stderr').write_bytes(cp.stderr)
                write(dest/f'command-{key}.json',{'command':cmd,'exit_code':cp.returncode});public=json.loads(cp.stdout)
            missing=21-record['inserts'];assert public['valid']==(missing==0)
            if missing:
                assert returncode!=0 and public['violations']==[{'code':'quantity','message':f"part insert: expected 21, found {record['inserts']}"}]
            else:assert returncode==0 and not public['violations']
            records.append({'case':case,'incumbent':key,'inserts':record['inserts'],'missing_inserts':missing,
                'pairs':pairs,'minimum_distance_mm':minimum,'charged_material_mm2':material,
                'filled_area_mm2':sum(g.area for gs in geoms.values() for g in gs),
                'original_CLI_valid':public['valid'],'reused_prior_exact_validation':tuple(ids) in cached})
        assert result['inserts']==last and result['best_bound']>=last
        cases.append({'case':case,'status':result['status'],'seconds':result['seconds'],'inserts':last,
            'seed_inserts':mp['minimum_inserts'],'improved_on_case_seed':last>mp['minimum_inserts'],
            'solver_upper_bound':result['best_bound']})
    check={'all_returned_layouts_checked':len(records),'records':records,'cases':cases,
        'fresh_frozen_CLI_calls':fresh,'reused_exact_frozen_CLI_results':reused,
        'best_insert_count':max((r['inserts'] for r in records),default=0),
        'full_target_witness':any(r['original_CLI_valid'] for r in records),'native_margin_qualified':False,
        'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',check);print(json.dumps({k:v for k,v in check.items() if k!='records'}),flush=True)
if __name__=='__main__':main()
