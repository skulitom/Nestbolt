"""One declared feasibility search for 14 inserts with three to six core moves."""
from datetime import datetime, timezone
import json, shutil, time, traceback
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT, SRC, OUT as PARENT, load, write, digest

OUT = ROOT / 'output/h5-three-six-core-escape-20261020'
CENSUS = ROOT / 'output/h5-two-core-move-census-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'probe.py')
    audit = load(CENSUS / 'audit.json')
    assert audit['all_zero_one_two_moves_independently_enumerated'] and audit['any_improvement_ruled_out']
    sources = [PARENT / n for n in ['model.pbtxt', 'model-audit.json', 'kept-candidates.json', 'seed-indices.json']]
    sources += [CENSUS / 'audit.json', SRC / 'candidates.json']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'seconds_limit': 30, 'workers': 8, 'seed': 0,
        'method': 'Change the audited free-cog model to feasibility for at least 14 and at most 21 inserts, retaining 39 to 42 of the 45 seed core poses (three to six replacements). Keep every original family count and conflict. Remove the original objective and hint; the 13-insert seed is not a feasible hint for this target. One solve, no retry.',
        'reason': 'Independent exhaustive zero/one/two-core census proves that improving beyond 13 requires at least three changed core poses within this retained pool. Capping the remaining neighborhood at six moves is a construction restriction, not a global bound.',
        'scope': 'Only the finite retained pool around the mapped seed; a timeout or infeasibility does not exclude larger moves or new continuous positions.',
        'native_packing_calls': 0, 'quality_runs': 0})
    parent = text_format.Parse((PARENT / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
    assert digest(PARENT / 'model.pbtxt') == load(PARENT / 'model-audit.json')['model_sha256']
    ids = load(PARENT / 'kept-candidates.json')
    pool = load(SRC / 'candidates.json')
    core = {i for i in load(PARENT / 'seed-indices.json') if pool[i]['placement']['part_id'] != 'insert'}
    model = cp_model.CpModel()
    assert model.proto.parse_text_format((PARENT / 'model.pbtxt').read_text())
    model.rebuild_constant_map()
    model.clear_objective()
    model.clear_hints()
    insert_constraint = len(parent.constraints) - 1
    assert list(parent.constraints[insert_constraint].linear.domain) == [13, 21]
    model.proto.constraints[insert_constraint].linear.domain[0] = 14
    core_vars = [model.get_int_var_from_proto_index(j) for j, i in enumerate(ids) if i in core]
    model.add_linear_constraint(sum(core_vars), 39, 42)
    assert model.validate() == ''
    model.export_to_file(str(OUT / 'model.pbtxt'))
    expected = cp_model_pb2.CpModelProto()
    expected.CopyFrom(parent)
    expected.ClearField('objective')
    expected.ClearField('solution_hint')
    expected.constraints[insert_constraint].linear.domain[0] = 14
    c = expected.constraints.add().linear
    c.vars.extend(j for j, i in enumerate(ids) if i in core)
    c.coeffs.extend([1] * 45)
    c.domain.extend([39, 42])
    actual = text_format.Parse((OUT / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
    assert actual.SerializeToString(deterministic=True) == expected.SerializeToString(deterministic=True)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 30
    solver.parameters.num_search_workers = 8
    solver.parameters.random_seed = 0
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = False
    (OUT / 'parameters.pbtxt').write_text(str(solver.parameters), encoding='utf-8', newline='\n')
    write(OUT / 'model-audit.json', {
        'entire_model_exactly_reconstructed_against_audited_parent': True,
        'variables': len(ids), 'constraints': len(actual.constraints),
        'insert_bounds': [14, 21], 'retained_seed_core_bounds': [39, 42],
        'objective_present': actual.HasField('objective'),
        'hint_present': actual.HasField('solution_hint'),
        'model_sha256': digest(OUT / 'model.pbtxt')})
    callbacks = []
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            chosen = [i for j, i in enumerate(ids) if self.value(model.get_int_var_from_proto_index(j))]
            r = {'index': len(callbacks), 'selected_indices': chosen, 'seconds': self.wall_time,
                 'inserts': sum(pool[i]['placement']['part_id'] == 'insert' for i in chosen),
                 'changed_core_poses': 45 - len(core & set(chosen))}
            assert 14 <= r['inserts'] <= 21 and 3 <= r['changed_core_poses'] <= 6
            write(OUT / f"incumbent-{r['index']}.json", r)
            callbacks.append(r)
            print(json.dumps({k: v for k, v in r.items() if k != 'selected_indices'}), flush=True)
    write(OUT / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'seconds_limit': 30})
    with (OUT / 'solver.log').open('x', encoding='utf-8', newline='\n') as log:
        solver.log_callback = lambda s: (log.write(s + '\n'), log.flush())
        start = time.perf_counter()
        status = solver.solve(model, Capture())
        seconds = time.perf_counter() - start
    feasible = status in [cp_model.FEASIBLE, cp_model.OPTIMAL]
    result = {'status': solver.status_name(status), 'seconds': seconds, 'incumbents': len(callbacks),
              'feasible': feasible, 'response_stats': solver.response_stats(),
              'original_geometry_audited': False, 'full_target_witness': False,
              'native_margin_qualified': False, 'unrestricted_impossibility_claimed': False}
    if feasible:
        chosen = [i for j, i in enumerate(ids) if solver.value(model.get_int_var_from_proto_index(j))]
        write(OUT / 'selected-indices.json', chosen)
        result['inserts'] = sum(pool[i]['placement']['part_id'] == 'insert' for i in chosen)
        result['changed_core_poses'] = 45 - len(core & set(chosen))
    else:
        assert not callbacks
    write(OUT / 'result.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'response_stats'}), flush=True)

if __name__ == '__main__':
    try:
        main()
    except BaseException:
        if OUT.exists():
            (OUT / 'failure.txt').write_text(traceback.format_exc(), encoding='utf-8', newline='\n')
        raise
