"""Audit the strengthened necessary-model response and every returned constraint."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-balanced-union-search-20261026';MODEL=ROOT/'output/h5-balanced-union-master-20261026';DATA=ROOT/'output/h5-aligned-cog-band-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for folder in [BASE,MODEL] for p in folder.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify the sole actual model/parameter/response and shared time. For a positive, independently check all692 variable domains and104 constraints including exact reifications and the OR, all mandatory family counts, all63 band sums and the excluded profile pattern. Preserve actual allocation; it is not a coordinate or full-job witness. No retry.'})
for path in [BASE/'plan.json',MODEL/'plan.json',MODEL/'audit/plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(MODEL/'audit/checks.json')['passed'];proc=load(BASE/'process.json');budget=load(BASE/'budget.json');opened=load(BASE/'opened.json');r=load(BASE/'result.json');assert proc['exit_code']==0 and not proc['timeout'] and proc['seconds']<=30 and budget['shared_seconds']==30 and budget['solver_cap_seconds']==20 and budget['workers']==4 and budget['seed']==0 and budget['shutdown_reserve_seconds']==5 and budget['maximum_solver_calls']==opened['maximum_solver_calls']==r['solver_calls']==1
m=cp_model_pb2.CpModelProto();m.ParseFromString((BASE/'model.pb').read_bytes());e=cp_model_pb2.CpModelProto();e.ParseFromString((MODEL/'model.pb').read_bytes());assert m==e and digest(BASE/'model.pb')==opened['model_sha256'];params=text_format.Parse((BASE/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=min(20,opened['remaining_shared_seconds']),num_search_workers=4,random_seed=0,cp_model_presolve=True,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(BASE/'parameters.pbtxt')==opened['parameters_sha256'] and params.max_time_in_seconds==opened['solver_seconds_limit'];response=cp_model_pb2.CpSolverResponse();response.ParseFromString((BASE/'response.pb').read_bytes());assert cp_model_pb2.CpSolverStatus.Name(response.status)==r['status'] and abs(response.wall_time-r['seconds'])<.1 and r['seconds']<proc['seconds'] and r['solver_soft_overrun_seconds']==max(0,r['seconds']-params.max_time_in_seconds)
positive=r['status'] in ['OPTIMAL','FEASIBLE'];assert positive==r['has_necessary_allocation'];mapping=load(MODEL/'mapping.json');counts=load(DATA/'plan.json')['required_original_counts'];checked=active=0;totals=None
if positive:
    sol=list(response.solution);assert len(sol)==692
    for v,n in zip(m.variables,sol):assert any(lo<=n<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]))
    def truth(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
    for c in m.constraints:
        checked+=1
        if not all(truth(v) for v in c.enforcement_literal):continue
        active+=1
        if c.WhichOneof('constraint')=='linear':n=sum(sol[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=n<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        else:assert c.WhichOneof('constraint')=='bool_or' and any(truth(v) for v in c.bool_or.literals)
    allocation=[{**row,'count':sol[row['variable']]} for row in mapping if sol[row['variable']]];assert allocation==load(BASE/'allocation.json');assert all(sum(row['count'] for row in allocation if row['family']==f)==n for f,n in counts.items());bands=[sum(row['count']*row['demands'][j] for row in allocation) for j in range(63)];assert all(a<=b for a,b in zip(bands,load(DATA/'band-capacities.json')));totals={i:sum(row['count'] for row in allocation if row['profile']==i) for i in range(11)};assert tuple(totals[i] for i in [4,5,6,10])!=(1,2,1,1);assert (totals[0]+totals[4],totals[2]+totals[6],totals[3]+totals[5],totals[10])!=(1,1,2,1);assert (totals[0]+totals[4],totals[2]+totals[6],totals[1]+totals[7],totals[3]+totals[5],totals[8])!=(1,1,1,1,1);assert (totals[0]+totals[4],totals[2]+totals[6],totals[1]+totals[7],totals[3]+totals[5])!=(1,1,1,1);write(OUT/'verified-allocation.json',allocation);write(OUT/'profile-totals.json',totals);write(OUT/'band-loads.json',bands)
else:assert r['status'] in ['UNKNOWN','INFEASIBLE'] and not response.solution and not (BASE/'allocation.json').exists()
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':r['status'],'necessary_allocation':positive,'returned_constraints_checked':checked,'active_constraints_checked':active,'profile_totals':totals,'solver_calls':1,'solver_seconds':r['seconds'],'shared_seconds':proc['seconds'],'shared_budget_honored':True,'soft_overrun_seconds':r['solver_soft_overrun_seconds'],'all_calls_closed':True,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
