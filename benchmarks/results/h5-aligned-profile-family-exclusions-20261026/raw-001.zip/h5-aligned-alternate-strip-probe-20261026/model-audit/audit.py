"""Independently reconstruct every model variable and retained source clause."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-aligned-alternate-strip-probe-20261026';SOURCE=ROOT/'output/h5-aligned-alternate-strip-source-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently reconstruct18 exact stock-bound coordinate variables per pattern and all36 original pair clauses. Evaluate each source plane on all four difference-box corners to verify only whole-box tautologies and impossible edges are removed. Reconstruct every remaining singleton, one-sided edge implication and OR; require exact inventory, whole proto fields and actual solver import/export. No source face omitted without proof, no coordinate locks or copy ordering. Verify the one predeclared orientation patterns and budgets. No solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');rows=load(BASE/'inventory.json');assert len(rows)==1;checks=[]
for index,row in enumerate(rows):
    assert row['index']==index and row['parts']==list(range(9)) and row['originals']==[p['item'] for p in spec['parts']] and row['profile_pattern']==spec['orientation_patterns'][index] and row['solver_seconds']==45.0;pattern=row['profile_pattern'];model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'models'/f'{index:03d}.pb').read_bytes());assert {f.name for f,v in model.ListFields()}=={'variables','constraints'};bounds=[spec['anchor_bounds_units1000'][str(p)] for p in pattern];vc=cc=0;maps=[];counts={'tautological_faces':0,'singleton_faces':0,'impossible_faces':0,'disjunctive_faces':0}
    for pi,b in enumerate(bounds):
        for axis in [0,1]:assert model.variables[vc]==cp_model_pb2.IntegerVariableProto(name=f"p{pi}-{'xy'[axis]}",domain=[b[axis],b[axis+2]]);vc+=1
    def check_linear(a,b,h,flag=None):
        global cc
        terms={2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']};ids=sorted(v for v,k in terms.items() if k);c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(ids);c.linear.coeffs.extend(terms[v] for v in ids);c.linear.domain.extend([h['bound'],2**63-1])
        if flag is not None:c.enforcement_literal.append(flag)
        assert model.constraints[cc]==c,(index,cc);cc+=1
    for a,b in combinations(range(9),2):
        case=next(c['index'] for c in spec['mutual_cases'] if (c['profile_a'],c['profile_b'])==(pattern[a],pattern[b]));ba,bb=bounds[a],bounds[b];box=[bb[0]-ba[2],bb[1]-ba[3],bb[2]-ba[0],bb[3]-ba[1]];corners=list(product([box[0],box[2]],[box[1],box[3]]));records=[]
        for face in load(SOURCE/'mutual'/f'{case:03d}.json')['faces']:
            planes=face['outside_halfplanes'];ranges=[[h['a']*x+h['b']*y for x,y in corners] for h in planes]
            if any(min(r)>=h['bound'] for h,r in zip(planes,ranges)):counts['tautological_faces']+=1;records.append({'face':face['index'],'tautological':True});continue
            live=[i for i,(h,r) in enumerate(zip(planes,ranges)) if max(r)>=h['bound']];flags=[]
            if len(live)==1:check_linear(a,b,planes[live[0]]);counts['singleton_faces']+=1
            else:
                for edge in live:
                    assert model.variables[vc]==cp_model_pb2.IntegerVariableProto(name=f'p{a}-{b}-f{face["index"]}-e{edge}',domain=[0,1]);flags.append(vc);check_linear(a,b,planes[edge],vc);vc+=1
                c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend(flags);assert model.constraints[cc]==c;cc+=1;counts['disjunctive_faces' if live else 'impossible_faces']+=1
            records.append({'face':face['index'],'live_edges':live,'flags':flags})
        maps.append({'parts':[a,b],'case':case,'difference_bounds':box,'faces':records})
    assert maps==load(BASE/'models'/f'{index:03d}-mapping.json') and vc==row['variables']==len(model.variables) and cc==row['constraints']==len(model.constraints) and all(row[k]==v for k,v in counts.items());assert digest(BASE/'models'/f'{index:03d}.pb')==row['model_sha256'];real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models'/f'{index:03d}.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/f'{index:03d}-roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/f'{index:03d}-roundtrip.pb').read_bytes());assert actual==model;checks.append({'pattern':index,'variables':vc,'constraints':cc,'all36_original_pairs_preserved':True,**counts,'passed':True})
write(OUT/'patterns.json',checks);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'models':1,'all_original_variables_constraints_reconstructed':True,'every_source_pair_face_accounted_for':True,'actual_import_export_verified':True,'coordinate_locks':0,'copy_order_constraints':0,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
