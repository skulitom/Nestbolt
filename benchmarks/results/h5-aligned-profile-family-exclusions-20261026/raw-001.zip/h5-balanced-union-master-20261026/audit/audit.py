"""Check both complete source rejections cover every balanced bracket/insert assignment."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,permutations,combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-balanced-union-master-20261026';PARENT=ROOT/'output/h5-balanced-exclusion-master-20261026';DATA=ROOT/'output/h5-aligned-cog-band-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently verify both actual model/response pairs, full source domains and every74-mode pair map for insert8 and10. Exhaustively relabel16 mirror combinations times24 identical bracket permutations into each source model (768 cases), with cog-only x ordering. Check insert domain exhaustiveness from every parent cell. Restore parent fields exactly, reconstruct4 group-count reifications and OR, enumerate10000 count/flag cases and verify actual solver import/export. No solve or unrestricted-packing claim.'})
spec=load(BASE/'plan.json')
for n,h in spec['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'audit/checks.json')['passed'];mapping=load(BASE/'mapping.json');assert mapping==load(PARENT/'mapping.json')
assert {r['profile'] for r in mapping if r['family']=='insert'}=={8,10}
assert {r['profile'] for r in mapping if r['family']=='cog'}=={9}
assert {r['profile'] for r in mapping if r['family']=='bracket'}==set(range(8))
assert [p['insert_profile'] for p in spec['proofs']]==[8,10]
checked=0;proof_rows=[];groups=[[0,4],[2,6],[1,7],[3,5]]
for proof in spec['proofs']:
    source=ROOT/proof['source'];probe=ROOT/proof['probe'];insert=proof['insert_profile']
    for p in [source/'audit/checks.json',probe/'model-audit/checks.json',probe/'response-audit/checks.json']:assert load(p)['passed']
    s=load(source/'plan.json');allowed=groups+[[insert]]+[[9]]*4;assert s['allowed_profiles']==allowed
    assert load(source/'profiles.json')==load(ROOT/'output/h5-aligned-cog-profiles-20261026/profiles.json')
    assert [p['item'] for p in s['parts']]==[21,22,25,26,37,53,63,64,65]
    assert all(p['family']=='bracket' for p in s['parts'][:4]) and len({p['copy'] for p in s['parts'][:4]})==4
    assert all(p['family']=='cog' for p in s['parts'][5:]) and len({p['copy'] for p in s['parts'][5:]})==4
    closed=proto(probe/'search/000/model.pb');assert closed==proto(probe/'models/000.pb')
    response=cp_model_pb2.CpSolverResponse();response.ParseFromString((probe/'search/000/response.pb').read_bytes());assert response.status==cp_model_pb2.INFEASIBLE and not response.solution
    for i,options in enumerate(allowed):
        for axis in range(2):assert list(closed.variables[2*i+axis].domain)==[min(s['anchor_bounds_units1000'][str(p)][axis] for p in options),max(s['anchor_bounds_units1000'][str(p)][axis+2] for p in options)]
        for p in options:assert s['anchor_bounds_units1000'][str(p)][1::2]==load(DATA/'profiles'/f'{p:03d}.json')['y_bounds_units1000']
    maps=load(probe/'models/000-mapping.json');assert len(maps)==74
    assert {(tuple(r['parts']),tuple(r['profiles'])) for r in maps}=={((a,b),(pa,pb)) for a,b in combinations(range(9),2) for pa,pb in product(allowed[a],allowed[b])}
    for selected in product(*groups):
        for perm in permutations(range(4)):
            assigned=[selected[i] for i in perm];back=[]
            for group in groups:
                candidates=[i for i,p in enumerate(assigned) if p in group];assert len(candidates)==1;back.extend(candidates)
            assert sorted(back)==list(range(4)) and [assigned[i] for i in back]==list(selected);checked+=1
    proof_rows.append({'insert_profile':insert,'closed_status':'INFEASIBLE','source_modes':74,'model_sha256':digest(probe/'search/000/model.pb'),'response_sha256':digest(probe/'search/000/response.pb')})
assert checked==768
m=proto(BASE/'model.pb');old=proto(PARENT/'model.pb');assert len(m.variables)==692 and len(m.constraints)==104
restored=cp_model_pb2.CpModelProto();restored.CopyFrom(m);del restored.variables[688:];del restored.constraints[95:];assert restored==old
rows=[]
for j,group in enumerate(groups):
    flag=688+j;name='-'.join(map(str,group));assert m.variables[flag]==cp_model_pb2.IntegerVariableProto(name=f'excluded-balanced-any-insert-{name}',domain=[0,1]);ids=[r['variable'] for r in mapping if r['profile'] in group]
    for k,(lit,dom) in enumerate([(flag,[1,1]),(-flag-1,[-2**63,0,2,2**63-1])]):
        c=cp_model_pb2.ConstraintProto();c.enforcement_literal.append(lit);c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend(dom);assert c==m.constraints[95+2*j+k]
    rows.append({'profiles':group,'count':1,'flag':flag,'cell_variables':ids})
assert rows==load(BASE/'exclusion.json');c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-689,-690,-691,-692]);assert c==m.constraints[103];cases=0
for totals in product(range(5),repeat=4):
    exists=False
    for bits in product([0,1],repeat=4):
        valid=not all(bits)
        for j,(value,bit) in enumerate(zip(totals,bits)):
            dom=list(m.constraints[95+2*j+(0 if bit else 1)].linear.domain);valid &= any(lo<=value<=hi for lo,hi in zip(dom[::2],dom[1::2]))
        exists |= valid;cases+=1
    assert exists==(totals!=(1,1,1,1))
assert cases==10000
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'source-proof-cover.json',proof_rows)
write(OUT/'implication.json',{'statement':'The four aggregate equalities consume all4 brackets. Nonnegative cell counts exclude any other bracket type. The sole insert has exactly the two allowed profiles8/10; each case has its own full-stock74-mode source rejection with all36 physical pairs and matching original geometry. Relabel identical copies into that source, order only cogs by x and obtain contradiction. This excludes balanced bracket counts at the fixed aligned cog angle under the same guarded-source integer grid, not other counts/angles or native continuous layouts.','all_originals_retained':True,'insert_choices_exhaustive':[8,10]})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':692,'constraints':104,'exact_parent_restoration_verified':True,'source_negative_responses_verified':2,'profile_assignment_permutations_checked':checked,'source_modes_checked':148,'source_physical_pairs_checked':72,'count_flag_cases_checked':cases,'actual_import_export_verified':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
