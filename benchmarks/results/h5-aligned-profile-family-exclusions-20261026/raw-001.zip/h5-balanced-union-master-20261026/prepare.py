"""Exclude balanced bracket counts using both independently rejected insert choices."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-balanced-exclusion-master-20261026';OUT=ROOT/'output/h5-balanced-union-master-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed']
paths=[PARENT/'model.pb',PARENT/'mapping.json',PARENT/'audit/checks.json'];proofs=[]
for stem,insert in [('h5-balanced-group',8),('h5-balanced-horizontal',10)]:
    source=ROOT/'output'/f'{stem}-strip-source-20261026';probe=ROOT/'output'/f'{stem}-shared-probe-20261026'
    assert load(probe/'response-audit/checks.json')['passed'] and load(probe/'search/000/result.json')['status']=='INFEASIBLE'
    paths.extend(source/n for n in ['plan.json','profiles.json','audit/checks.json'])
    paths.extend(probe/n for n in ['models/000.pb','models/000-mapping.json','model-audit/checks.json','response-audit/checks.json','search/000/model.pb','search/000/response.pb','search/000/result.json'])
    proofs.append({'source':source.relative_to(ROOT).as_posix(),'probe':probe.relative_to(ROOT).as_posix(),'insert_profile':insert})
m=cp_model_pb2.CpModelProto();m.ParseFromString((PARENT/'model.pb').read_bytes());assert len(m.variables)==688 and len(m.constraints)==95
mapping=load(PARENT/'mapping.json');groups=[[0,4],[2,6],[1,7],[3,5]]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'proofs':proofs,'excluded_group_counts':[{'profiles':g,'count':1} for g in groups],'method':'Preserve all688 parent variables and95 constraints. Exclude one bracket in each of four orientation types independently of insert orientation: the two separate74-mode full-coordinate models reject both allowed insert choices8 and10. Four cogs retain aligned profile9. The original4/1/4 counts force all other bracket counts to zero and the sole insert to one of8/10. Relabel identical family copies into the appropriate rejected model. Four exact equality flags and not-all clause, independently audited including the exhaustive two-case cover and real import. One20second necessary capacity call within30shared seconds is allowed after audit; this is not a continuous/native impossibility theorem.'})
rows=[]
for group in groups:
    flag=len(m.variables);name='-'.join(map(str,group));m.variables.add(name=f'excluded-balanced-any-insert-{name}',domain=[0,1]);ids=[r['variable'] for r in mapping if r['profile'] in group]
    for lit,dom in [(flag,[1,1]),(-flag-1,[-2**63,0,2,2**63-1])]:
        c=m.constraints.add();c.enforcement_literal.append(lit);c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend(dom)
    rows.append({'profiles':group,'count':1,'flag':flag,'cell_variables':ids})
m.constraints.add().bool_or.literals.extend(-r['flag']-1 for r in rows)
shutil.copyfile(PARENT/'mapping.json',OUT/'mapping.json');write(OUT/'exclusion.json',rows);(OUT/'model.pb').write_bytes(m.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
