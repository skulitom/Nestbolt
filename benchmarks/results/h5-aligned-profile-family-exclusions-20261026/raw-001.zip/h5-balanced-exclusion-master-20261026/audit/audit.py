"""Independently verify the balanced-family projection and complete master extension."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product, permutations, combinations
import json, shutil, time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-balanced-exclusion-master-20261026'
PARENT=ROOT/'output/h5-group-exclusion-master-20261026'
SOURCE=ROOT/'output/h5-balanced-group-strip-source-20261026'
PROBE=ROOT/'output/h5-balanced-group-shared-probe-20261026'
DATA=ROOT/'output/h5-aligned-cog-band-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify actual74-mode source model/negative response and exact profiles, all full stock domains and36 pair maps. Enumerate16 mirror choices times24 bracket identity permutations, with unique assignment to each of four distinct type slots and no bracket sorting. Check complete equal-family identity coverage and cog-only symmetry. Independently reconstruct five count reifications and their not-all clause, enumerate40000 truth assignments, restore the parent proto exactly, and import/export the actual new model. No solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for p in [PARENT/'audit/checks.json',SOURCE/'audit/checks.json',PROBE/'model-audit/checks.json',PROBE/'response-audit/checks.json']:assert load(p)['passed']
s=load(SOURCE/'plan.json');allowed=[[0,4],[2,6],[1,7],[3,5],[8],[9],[9],[9],[9]]
assert s['allowed_profiles']==allowed
assert load(SOURCE/'profiles.json')==load(ROOT/'output/h5-aligned-cog-profiles-20261026/profiles.json')
closed=proto(PROBE/'search/000/model.pb');assert closed==proto(PROBE/'models/000.pb')
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((PROBE/'search/000/response.pb').read_bytes())
assert response.status==cp_model_pb2.INFEASIBLE and not response.solution
assert [p['item'] for p in s['parts']]==[21,22,25,26,37,53,63,64,65]
assert all(p['family']=='bracket' for p in s['parts'][:4]) and len({p['copy'] for p in s['parts'][:4]})==4
assert all(p['family']=='cog' for p in s['parts'][5:]) and len({p['copy'] for p in s['parts'][5:]})==4
for i,options in enumerate(allowed):
    for axis in range(2):assert list(closed.variables[2*i+axis].domain)==[min(s['anchor_bounds_units1000'][str(p)][axis] for p in options),max(s['anchor_bounds_units1000'][str(p)][axis+2] for p in options)]
    for p in options:assert s['anchor_bounds_units1000'][str(p)][1::2]==load(DATA/'profiles'/f'{p:03d}.json')['y_bounds_units1000']
maps=load(PROBE/'models/000-mapping.json')
assert len(maps)==74 and sorted({tuple(r['parts']) for r in maps})==list(combinations(range(9),2))
assert {(tuple(r['parts']),tuple(r['profiles'])) for r in maps}=={((a,b),(pa,pb)) for a,b in combinations(range(9),2) for pa,pb in product(allowed[a],allowed[b])}
permutations_checked=0;examples=[]
for selected in product(*allowed[:4]):
    for perm in permutations(range(4)):
        assigned=[selected[i] for i in perm];back=[]
        for group in allowed[:4]:
            candidates=[i for i,p in enumerate(assigned) if p in group];assert len(candidates)==1;back.extend(candidates)
        assert sorted(back)==list(range(4));relabelled=[assigned[i] for i in back]
        assert relabelled==list(selected);permutations_checked+=1
        if perm==(0,1,2,3):examples.append({'source_profiles':list(selected),'canonical_profiles':relabelled})
assert permutations_checked==384
m=proto(BASE/'model.pb');old=proto(PARENT/'model.pb')
assert len(m.variables)==688 and len(m.constraints)==95
assert m.variables[:683]==old.variables[:] and m.constraints[:84]==old.constraints[:]
restored=cp_model_pb2.CpModelProto();restored.CopyFrom(m);del restored.variables[683:];del restored.constraints[84:];assert restored==old
mapping=load(BASE/'mapping.json');assert mapping==load(PARENT/'mapping.json');groups=[[0,4],[2,6],[1,7],[3,5],[8]];rows=[]
for j,group in enumerate(groups):
    flag=683+j;name='-'.join(map(str,group));assert m.variables[flag]==cp_model_pb2.IntegerVariableProto(name=f'excluded-balanced-group{name}-count1',domain=[0,1])
    ids=[r['variable'] for r in mapping if r['profile'] in group]
    for k,(lit,domain) in enumerate([(flag,[1,1]),(-flag-1,[-2**63,0,2,2**63-1])]):
        c=cp_model_pb2.ConstraintProto();c.enforcement_literal.append(lit);c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend(domain);assert c==m.constraints[84+2*j+k]
    rows.append({'profiles':group,'count':1,'flag':flag,'cell_variables':ids})
assert rows==load(BASE/'exclusion.json');c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-684,-685,-686,-687,-688]);assert c==m.constraints[94]
cases=0
for totals in product(range(5),range(5),range(5),range(5),range(2)):
    exists=False
    for bits in product([0,1],repeat=5):
        valid=not all(bits)
        for j,(value,bit) in enumerate(zip(totals,bits)):
            dom=list(m.constraints[84+2*j+(0 if bit else 1)].linear.domain);valid &= any(lo<=value<=hi for lo,hi in zip(dom[::2],dom[1::2]))
        exists |= valid;cases+=1
    assert exists==(totals!=(1,1,1,1,1))
assert cases==40000
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'group-permutation-examples.json',examples)
write(OUT/'implication.json',{'statement':'Five aggregate equalities consume all4 brackets and the sole insert; nonnegative remaining cell counts must be zero. Identical original copies can be relabelled uniquely into the four bracket type slots, without ordering bracket positions/profiles. Identical cogs can be relabelled by x. Full stock domains and every orientation/pair face are present in the independently audited source model. A matching guarded-source integer-coordinate witness contradicts its closed INFEASIBLE response. Only this fixed cog angle, native-guarded source representation and micrometre anchor grid are covered.','all_originals_retained':True,'no_other_profile_group_counts_excluded':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':688,'constraints':95,'exact_parent_restoration_verified':True,'profile_assignment_permutations_checked':384,'source_modes_checked':74,'source_physical_pairs_checked':36,'count_flag_cases_checked':cases,'actual_import_export_verified':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
