"""Audit source-profile group projection, exact count logic and unchanged parent."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,permutations,combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-group-exclusion-master-20261026';PARENT=ROOT/'output/h5-profile-exclusion-master-20261026';SOURCE=ROOT/'output/h5-profile-group-strip-source-20261026';PROBE=ROOT/'output/h5-profile-group-shared-probe-20261026';DATA=ROOT/'output/h5-aligned-cog-band-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify the actual74-mode source model and closed negative response, exact profile inventory and full stock domains. Enumerate16 bracket option tuples times24 identity permutations and relabel each into the required groups; sort only the identical3/5 slots and cog copies. Verify all group stock choices and36 physical pair coverage, and rely on the independently reconstructed shared source clauses for coordinate equivalence. Reconstruct four exact group-count reifications and not-all clause, enumerate4000 truth cases, restore parent proto exactly and check actual solver import. No solve.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'audit/checks.json')['passed'] and load(SOURCE/'audit/checks.json')['passed'] and load(PROBE/'model-audit/checks.json')['passed'] and load(PROBE/'response-audit/checks.json')['passed'];s=load(SOURCE/'plan.json');allowed=[[0,4],[2,6],[3,5],[3,5],[10],[9],[9],[9],[9]];assert s['allowed_profiles']==allowed and load(SOURCE/'profiles.json')==load(ROOT/'output/h5-aligned-cog-profiles-20261026/profiles.json');closed=proto(PROBE/'search/000/model.pb');assert closed==proto(PROBE/'models/000.pb');response=cp_model_pb2.CpSolverResponse();response.ParseFromString((PROBE/'search/000/response.pb').read_bytes());assert response.status==cp_model_pb2.INFEASIBLE and not response.solution
for i,options in enumerate(allowed):
    for axis in range(2):assert list(closed.variables[2*i+axis].domain)==[min(s['anchor_bounds_units1000'][str(p)][axis] for p in options),max(s['anchor_bounds_units1000'][str(p)][axis+2] for p in options)]
    for p in options:assert s['anchor_bounds_units1000'][str(p)][1::2]==load(DATA/'profiles'/f'{p:03d}.json')['y_bounds_units1000']
maps=load(PROBE/'models/000-mapping.json');assert len(maps)==74 and sorted({tuple(r['parts']) for r in maps})==list(combinations(range(9),2));permutations_checked=0;examples=[]
for selected in product(*allowed[:4]):
    for perm in permutations(range(4)):
        assigned=[selected[i] for i in perm];left=list(range(4));back=[]
        for group in [[0,4],[2,6]]:
            i=next(i for i in left if assigned[i] in group);back.append(i);left.remove(i)
        back.extend(sorted(left,key=lambda i:assigned[i]));result=[assigned[i] for i in back];assert all(result[i] in allowed[i] for i in range(4)) and result[2]<=result[3];permutations_checked+=1
        if perm==(0,1,2,3):examples.append({'source_profiles':list(selected),'canonical_profiles':result})
assert permutations_checked==384
m=proto(BASE/'model.pb');old=proto(PARENT/'model.pb');assert len(m.variables)==683 and len(m.constraints)==84 and m.variables[:679]==old.variables[:] and m.constraints[:75]==old.constraints[:];restored=cp_model_pb2.CpModelProto();restored.CopyFrom(m);del restored.variables[679:];del restored.constraints[75:];assert restored==old;mapping=load(BASE/'mapping.json');assert mapping==load(PARENT/'mapping.json');groups=[([0,4],1),([2,6],1),([3,5],2),([10],1)];rows=[]
for j,(group,count) in enumerate(groups):
    flag=679+j;name='-'.join(map(str,group));assert m.variables[flag]==cp_model_pb2.IntegerVariableProto(name=f'excluded-group{name}-count{count}',domain=[0,1]);ids=[r['variable'] for r in mapping if r['profile'] in group]
    for k,(lit,domain) in enumerate([(flag,[count,count]),(-flag-1,[-2**63,count-1,count+1,2**63-1])]):
        c=cp_model_pb2.ConstraintProto();c.enforcement_literal.append(lit);c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend(domain);assert c==m.constraints[75+2*j+k]
    rows.append({'profiles':group,'count':count,'flag':flag,'cell_variables':ids})
assert rows==load(BASE/'exclusion.json');c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-680,-681,-682,-683]);assert c==m.constraints[83];cases=0
for totals in product(range(5),range(5),range(5),range(2)):
    exists=False
    for bits in product([0,1],repeat=4):
        valid=not all(bits)
        for j,(value,bit) in enumerate(zip(totals,bits)):
            dom=list(m.constraints[75+2*j+(0 if bit else 1)].linear.domain);valid &= any(lo<=value<=hi for lo,hi in zip(dom[::2],dom[1::2]))
        exists |= valid;cases+=1
    assert exists==(totals!=(1,2,1,1) if False else totals!=(1,1,2,1))
assert cases==4000;real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'group-permutation-examples.json',examples);write(OUT/'implication.json',{'statement':'If the four excluded aggregate counts hold, all brackets belong to the declared0/4,2/6,3/5 slots and the sole insert is10; family totals and nonnegative cell counts force all other bracket/insert profiles to zero. Relabel identical copies into those slots, sort the two3/5 copies by profile and the four cog copies by x. Any source-coordinate witness would satisfy the independently audited shared-plane74-mode source model, contradicting its closed INFEASIBLE response. This is restricted to the same fixed cog angle, native-guarded source representation and integer anchor grid.','all_originals_retained':True,'no_other_profile_group_counts_excluded':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':683,'constraints':84,'exact_parent_restoration_verified':True,'profile_assignment_permutations_checked':384,'source_modes_checked':74,'source_physical_pairs_checked':36,'count_flag_cases_checked':4000,'actual_import_export_verified':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
