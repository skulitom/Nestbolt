from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('run_h5_profile_exclusion_master.py','run_h5_group_exclusion_master.py'),('audit_h5_profile_exclusion_response.py','audit_h5_group_exclusion_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-profile-exclusion-master-20261026','h5-group-exclusion-master-20261026').replace('h5-profile-exclusion-search-20261026','h5-group-exclusion-search-20261026').replace('679-variable/75-constraint','683-variable/84-constraint').replace('all679 variable domains and75 constraints','all683 variable domains and84 constraints').replace('len(sol)==679','len(sol)==683')
    if src.startswith('audit'):
        old="assert tuple(totals[i] for i in [4,5,6,10])!=(1,2,1,1);";assert old in s;s=s.replace(old,old+"assert (totals[0]+totals[4],totals[2]+totals[6],totals[3]+totals[5],totals[10])!=(1,1,2,1);")
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
