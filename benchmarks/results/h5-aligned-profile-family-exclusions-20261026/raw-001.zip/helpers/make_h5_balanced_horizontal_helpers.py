"""Prepare the remaining balanced bracket family with the horizontal insert."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('build_h5_balanced_group_strip.py','build_h5_balanced_horizontal_strip.py'),('audit_h5_balanced_group_geometry.py','audit_h5_balanced_horizontal_geometry.py'),('prepare_h5_balanced_group_shared_model.py','prepare_h5_balanced_horizontal_shared_model.py'),('audit_h5_balanced_group_shared_model.py','audit_h5_balanced_horizontal_shared_model.py'),('run_h5_balanced_group_probe.py','run_h5_balanced_horizontal_probe.py'),('audit_h5_balanced_group_response.py','audit_h5_balanced_horizontal_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8')
    s=s.replace('h5-balanced-group-strip-source-20261026','h5-balanced-horizontal-strip-source-20261026').replace('h5-balanced-group-shared-probe-20261026','h5-balanced-horizontal-shared-probe-20261026').replace('[[0,4],[2,6],[1,7],[3,5],[8],[9],[9],[9],[9]]','[[0,4],[2,6],[1,7],[3,5],[10],[9],[9],[9],[9]]')
    if src.startswith('build'):
        old="ROOT/'output/h5-profile-group-strip-source-20261026']:";assert old in s
        s=s.replace(old,"ROOT/'output/h5-profile-group-strip-source-20261026',ROOT/'output/h5-balanced-group-strip-source-20261026']:")
        s=s.replace('h5-group-exclusion-search-20261026','h5-balanced-exclusion-search-20261026').replace('[[0,4],[2,6],[1,7],[3,5],[8]]','[[0,4],[2,6],[1,7],[3,5],[10]]').replace("{'profiles':[8],'count':1}","{'profiles':[10],'count':1}").replace('Insert8 and','Insert10 and')
    elif 'geometry' in src:
        s=s.replace("'h5-group-exclusion-search']","'h5-balanced-group-strip','h5-balanced-exclusion-search']")
    elif 'response' in src:
        assert 'selected.extend([8]+[9]*4)' in s;s=s.replace('selected.extend([8]+[9]*4)','selected.extend([10]+[9]*4)')
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
