from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_alternate_strip_probe.py').read_text(encoding='utf-8').replace('h5-aligned-alternate-strip-probe-20261026','h5-profile-group-shared-probe-20261026')
with (ROOT/'output/run_h5_profile_group_probe.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_all_bracket_strip_response.py').read_text(encoding='utf-8')
changes=[('h5-all-bracket-strip-probe-20261026','h5-profile-group-shared-probe-20261026'),('h5-all-bracket-strip-source-20261026','h5-profile-group-strip-source-20261026'),('range(8)','range(9)'),('sol[:16]','sol[:18]'),("chosen=[p for p,v in enumerate(flags[str(i)]) if sol[v]]","chosen=[int(p) for p,v in flags[str(i)].items() if sol[v]]"),('selected.extend([9]*4);assert selected[:4]==sorted(selected[:4]) and sol[8:16:2]==sorted(sol[8:16:2])','selected.extend([10]+[9]*4);assert selected[2]<=selected[3] and sol[10:18:2]==sorted(sol[10:18:2])'),('[28,29,37]','[28,29]'),('eight-part composition','nine-part profile-group composition')]
for a,b in changes:assert a in s,a;s=s.replace(a,b)
compile(s,'audit_h5_profile_group_response.py','exec')
with (ROOT/'output/audit_h5_profile_group_response.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
