from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_aligned_cog_band_model.py').read_text(encoding='utf-8').replace('h5-aligned-cog-band-model-20261026','h5-profile-exclusion-master-20261026').replace('h5-aligned-cog-band-search-20261026','h5-profile-exclusion-search-20261026').replace('675-variable/66-constraint','679-variable/75-constraint').replace('One necessary band-capacity call','One necessary band-capacity call after an audited exact profile-count exclusion')
compile(s,'run_h5_profile_exclusion_master.py','exec')
with (ROOT/'output/run_h5_profile_exclusion_master.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
