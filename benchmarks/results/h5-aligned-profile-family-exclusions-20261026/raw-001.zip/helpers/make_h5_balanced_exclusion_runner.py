from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('run_h5_group_exclusion_master.py','run_h5_balanced_exclusion_master.py'),('audit_h5_group_exclusion_response.py','audit_h5_balanced_exclusion_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-group-exclusion-master-20261026','h5-balanced-exclusion-master-20261026').replace('h5-group-exclusion-search-20261026','h5-balanced-exclusion-search-20261026').replace('683-variable/84-constraint','688-variable/95-constraint').replace('all683 variable domains and84 constraints','all688 variable domains and95 constraints').replace('len(sol)==683','len(sol)==688')
    if src.startswith('audit'):
        old="assert (totals[0]+totals[4],totals[2]+totals[6],totals[3]+totals[5],totals[10])!=(1,1,2,1);";assert old in s
        s=s.replace(old,old+"assert (totals[0]+totals[4],totals[2]+totals[6],totals[1]+totals[7],totals[3]+totals[5],totals[8])!=(1,1,1,1,1);")
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
