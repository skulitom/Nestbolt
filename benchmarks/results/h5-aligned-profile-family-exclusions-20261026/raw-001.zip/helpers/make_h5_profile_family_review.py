from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_aligned_cog_checkpoint.py').read_text(encoding='utf-8')
s=s.replace('h5-aligned-cog-checkpoint-review-20261026','h5-profile-family-checkpoint-review-20261026').replace('68f82c021a0ab29cc83870ac6e738ec604d56a7b','88e1dc19c23eb9c5aa01b57d9537d66d87a841fb').replace('81cc41866306a639fa09f0db9590bb411c0c987e','88e1dc19c23eb9c5aa01b57d9537d66d87a841fb')
compile(s,'review_h5_profile_family_checkpoint.py','exec')
with (ROOT/'output/review_h5_profile_family_checkpoint.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
