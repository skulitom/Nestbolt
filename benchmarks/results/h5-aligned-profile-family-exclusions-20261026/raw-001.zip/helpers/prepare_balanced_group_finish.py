from pathlib import Path
root=Path(__file__).resolve().parents[1]
old=(root/'output/finish_h5_return_reuse_pilot.py').read_text(encoding='utf-8')
s=old[:old.index('reuse_rows=[]')]
s=s.replace('h5_return_reuse_pilot','h5_balanced_group_pilot').replace('h5-return-reuse-pilot-20261018','h5-balanced-group-pilot-20261018')
body=r'''
pair_rows=[]
for row in result['records']:
    stats=row.get('stats',{})
    attempted=stats.get('paired_exchange_attempts',0);accepted=stats.get('paired_exchanges',0)
    assert type(attempted) is int and type(accepted) is int
    assert 0<=accepted<=attempted<=stats.get('directed_exchange_attempts',0)
    assert accepted<=stats.get('directed_exchanges',0)
    if row['arm']!='candidate':assert attempted==accepted==0
    pair_rows.append({k:row[k] for k in ['job','kerf_mm','seed','arm']} |
        {'attempted_pairs':attempted,'accepted_pairs':accepted,
         'all_attempts':stats.get('directed_exchange_attempts',0),'all_accepted':stats.get('directed_exchanges',0)})
counters={'attempted_pairs':sum(r['attempted_pairs'] for r in pair_rows),
          'accepted_pairs':sum(r['accepted_pairs'] for r in pair_rows),'records':pair_rows}
write(OUT/'pair-counters.json',counters)
lines=['# Balanced incoming-pair pilot — 2026-10-18','',
    f"**{sum(r['status']=='valid' for r in result['records'])}/{len(result['records'])} outcomes validate.**",
    'This four-job pilot does not complete H5. Every original limit and the',
    'complete 13-job requirement remain.','',
    '[Committed plan](h5-balanced-group-pilot-20261018/plan.json),',
    '[all results](h5-balanced-group-pilot-20261018/results.json),',
    '[archive verification](h5-balanced-group-pilot-20261018/verification.json),',
    '[pair counters](h5-balanced-group-pilot-20261018/pair-counters.json).','',
    '## Method','',
    'The candidate tries two nearby copies of the same part against their',
    'complete obstruction union of at most three parts. Returned original area',
    'may not exceed the pair’s area; permitted incoming relative transforms stay.',
    'Pairs use at most half the existing exchange window, followed by the old',
    'single-part path. Both sheets must repair, and independent whole-job',
    'geometry/material/deadline checks still govern acceptance. The outer',
    'ten-percent/1.2-second limit, normal mode and production are unchanged.',
    'The [preparation](h5-balanced-group-preparation-20261018.md) retains all',
    '97 passing tests, strict lint, public checks and original test failures.','',
    'Four jobs, two kerfs, seeds 0–2 and three arms produce 72 outcomes. Ordinary',
    'baseline, common baseline and common candidate run sequentially on the same',
    'physical CCD0 core in rotating order; at most eight blocks run together.',
    'Each search gets 60 seconds. Frozen geometry, quantities, stock and rotations',
    'are unchanged. Block, score, case and measurement methods are AST-identical',
    'to the preceding pilot. Every outcome requires independent validation and',
    'public export; common mode must reserve hole interiors.',
    f"The session took {result['wall_seconds']/60:.3f} minutes.",'',
    '## Three-seed medians','',
    'Positive material differences are worse. The unchanged limit is +1% against',
    'ordinary mode. Exchange counts sum all three seeds; an accepted exchange',
    'alone does not establish better final material use.','',
    '| Job | Kerf mm | Baseline vs ordinary | Candidate vs ordinary | Candidate vs baseline | Cut saving | All accepted / attempted | Pair accepted / attempted | Within +1% |',
    '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
for pair in summary['pairs']:
    if not pair['complete']:
        lines.append(f"| {pair['job']} | {pair['kerf_mm']} | incomplete | incomplete | incomplete | incomplete | incomplete | incomplete | no |")
        continue
    c=pair['arms']['candidate']
    rows=[r for r in pair_rows if r['arm']=='candidate' and (r['job'],r['kerf_mm'])==(pair['job'],pair['kerf_mm'])]
    lines.append(f"| {pair['job']} | {pair['kerf_mm']} | {pair['baseline_vs_normal_percent']:+.6f}% | {pair['candidate_vs_normal_percent']:+.6f}% | {pair['candidate_vs_baseline_percent']:+.6f}% | {c['cut_savings_median_percent']:.6f}% | {c['exchanges']} / {c['exchange_attempts']} | {sum(r['accepted_pairs'] for r in rows)} / {sum(r['attempted_pairs'] for r in rows)} | {'yes' if pair['candidate_within_original_material_limit'] else 'NO'} |")
lines += ['', '## Evidence and limits','',
    'Every attempt retains its original ZIP. CRC, member/layout hashes, counters',
    'and independent metrics are verified; the summary is recomputed from every',
    'record. A failed or incomplete arm cannot yield a passing median. All source,',
    'binary, runner, data and environment guards remain unchanged.',
    'The prior failed pilots, source-repair traces and authored witnesses remain.',
    'No gate change, production integration or held-out access follows from this',
    'diagnostic alone. H2/H5 remain open; completed weight is 60%.','']
(OUT.parent/(OUT.name+'.md')).write_text('\n'.join(lines),encoding='utf-8',newline='\n')
print(json.dumps({'all_valid':summary['all_valid'],'paired_attempts':counters['attempted_pairs'],
    'paired_accepted':counters['accepted_pairs'],'pairs':[{k:v for k,v in p.items() if k not in ['arms','per_seed']} for p in summary['pairs']]}))
'''
p=root/'output/finish_h5_balanced_group_pilot.py';compile(s+body,str(p),'exec');p.write_text(s+body,encoding='utf-8',newline='\n')
s=(root/'output/audit_h5_return_reuse_reserved_holes.py').read_text(encoding='utf-8').replace('h5-return-reuse-pilot-20261018','h5-balanced-group-pilot-20261018')
(root/'output/audit_h5_balanced_group_reserved_holes.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared archive verification, paired counters and independent filled-outer audit.')
