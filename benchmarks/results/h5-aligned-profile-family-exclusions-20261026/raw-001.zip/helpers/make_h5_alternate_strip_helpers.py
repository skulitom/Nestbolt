"""Fresh coordinate pattern selected by the audited profile-exclusion master."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
paths=[('h5-aligned-nine-strip-source-20261026','h5-aligned-alternate-strip-source-20261026'),('h5-aligned-nine-strip-probe-20261026','h5-aligned-alternate-strip-probe-20261026')]
for src,dst in [('build_h5_aligned_nine_strip.py','build_h5_alternate_strip.py'),('audit_h5_aligned_nine_strip_geometry.py','audit_h5_alternate_strip_geometry.py'),('prepare_h5_aligned_nine_strip_model.py','prepare_h5_alternate_strip_model.py'),('audit_h5_aligned_nine_strip_model.py','audit_h5_alternate_strip_model.py'),('run_h5_aligned_nine_strip_probe.py','run_h5_alternate_strip_probe.py'),('audit_h5_aligned_nine_strip_response.py','audit_h5_alternate_strip_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8')
    for a,b in paths:s=s.replace(a,b)
    if src.startswith('build'):
        assert 'h5-aligned-cog-band-search-20261026' in s;s=s.replace('h5-aligned-cog-band-search-20261026','h5-profile-exclusion-search-20261026');assert '[4,5,5,6,10,9,9,9,9]' in s;s=s.replace('[4,5,5,6,10,9,9,9,9]','[0,2,5,5,10,9,9,9,9]').replace('Profiles4/5/5/6/10/9/9/9/9','Profiles0/2/5/5/10/9/9/9/9')
    if 'geometry' in src:
        assert '[4,5,5,6,10,9,9,9,9]' in s;s=s.replace('[4,5,5,6,10,9,9,9,9]','[0,2,5,5,10,9,9,9,9]');s=s.replace("'h5-aligned-cog-band-search'","'h5-profile-exclusion-search'")
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
