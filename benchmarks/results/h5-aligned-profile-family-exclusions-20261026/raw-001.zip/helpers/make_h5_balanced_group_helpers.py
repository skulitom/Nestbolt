"""Prepare the newly selected balanced profile-count family, preserving all prior results."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
paths=[('h5-profile-group-strip-source-20261026','h5-balanced-group-strip-source-20261026'),('h5-profile-group-shared-probe-20261026','h5-balanced-group-shared-probe-20261026')]
old_allowed='[[0,4],[2,6],[3,5],[3,5],[10],[9],[9],[9],[9]]';new_allowed='[[0,4],[2,6],[1,7],[3,5],[8],[9],[9],[9],[9]]'
for src,dst in [('build_h5_profile_group_strip.py','build_h5_balanced_group_strip.py'),('audit_h5_profile_group_geometry.py','audit_h5_balanced_group_geometry.py'),('prepare_h5_profile_group_shared_model.py','prepare_h5_balanced_group_shared_model.py'),('audit_h5_profile_group_shared_model.py','audit_h5_balanced_group_shared_model.py'),('run_h5_profile_group_probe.py','run_h5_balanced_group_probe.py'),('audit_h5_profile_group_response.py','audit_h5_balanced_group_response.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8')
    for a,b in paths:s=s.replace(a,b)
    s=s.replace(old_allowed,new_allowed)
    if src.startswith('build'):
        s=s.replace("assert len(keys)==30","assert len(keys)==42")
        s=s.replace("ROOT/'output/h5-aligned-alternate-strip-source-20261026']","ROOT/'output/h5-aligned-alternate-strip-source-20261026',ROOT/'output/h5-profile-group-strip-source-20261026']")
        old="inputs.append(ROOT/'output/h5-aligned-alternate-strip-probe-20261026/response-audit/checks.json');assert load(inputs[-1])['passed'];"
        new="inputs.append(ROOT/'output/h5-group-exclusion-search-20261026/audit/checks.json');assert load(inputs[-1])['passed'];inputs.append(ROOT/'output/h5-group-exclusion-search-20261026/allocation.json');allocation=load(inputs[-1]);totals={p:sum(r['count'] for r in allocation if r['profile']==p) for p in range(11)};assert all(sum(totals[p] for p in group)==1 for group in [[0,4],[2,6],[1,7],[3,5],[8]]) and totals[9]==4;"
        assert old in s;s=s.replace(old,new)
        old="[{'profiles':[0,4],'count':1},{'profiles':[2,6],'count':1},{'profiles':[3,5],'count':2},{'profiles':[10],'count':1}]";new="[{'profiles':[0,4],'count':1},{'profiles':[2,6],'count':1},{'profiles':[1,7],'count':1},{'profiles':[3,5],'count':1},{'profiles':[8],'count':1}]";assert old in s;s=s.replace(old,new)
        s=s.replace('one bracket from0/4, one from2/6 and two from3/5. Insert10','one bracket each from0/4,2/6,1/7,3/5. Insert8').replace('all30 cases','all42 cases').replace("'pair_cases':30","'pair_cases':42")
    elif 'geometry' in src:
        s=s.replace("['h5-aligned-alternate-strip']","['h5-aligned-alternate-strip','h5-profile-group-strip','h5-group-exclusion-search']").replace('len(needed)==30','len(needed)==42')
    elif src.startswith('prepare'):
        line="linear({**{flags[2][p]:p for p in allowed[2]},**{flags[3][p]:-p for p in allowed[3]}},-2**63,0)\n";assert line in s;s=s.replace(line,'');s=s.replace('len(m.constraints)==24','len(m.constraints)==23').replace('Only the two identical3/5-slot bracket copies are profile-ordered; the four cog copies are x-ordered.','Only the four identical cog copies are x-ordered; bracket type slots are not ordered.')
    elif 'shared_model' in src:
        line="assert allowed[2]==allowed[3]==[3,5];linear({flags[2][3]:3,flags[2][5]:5,flags[3][3]:-3,flags[3][5]:-5},-2**63,0)\n";assert line in s;s=s.replace(line,'');s=s.replace('vi==26 and ci==24','vi==26 and ci==23').replace('Only identical3/5-copy order and cog x order are allowed.','Only cog x ordering is added; the four bracket type slots have different allowed profiles.')
    elif 'response' in src:
        old='selected.extend([10]+[9]*4);assert selected[2]<=selected[3] and sol[10:18:2]==sorted(sol[10:18:2])';new='selected.extend([8]+[9]*4);assert all(selected[i] in s["allowed_profiles"][i] for i in range(9)) and sol[10:18:2]==sorted(sol[10:18:2])';assert old in s;s=s.replace(old,new)
    compile(s,dst,'exec')
    with (ROOT/'output'/dst).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
