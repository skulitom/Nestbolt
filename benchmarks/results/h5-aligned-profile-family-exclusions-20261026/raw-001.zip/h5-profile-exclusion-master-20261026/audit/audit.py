"""Prove the conditional profile-count projection and exact parent preservation."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,combinations,permutations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-profile-exclusion-master-20261026';PARENT=ROOT/'output/h5-aligned-cog-band-model-20261026';SOURCE=ROOT/'output/h5-aligned-nine-strip-source-20261026';PROBE=ROOT/'output/h5-aligned-nine-strip-probe-20261026';DATA=ROOT/'output/h5-aligned-cog-band-capacity-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify the actual closed fixed-pattern source model/negative response, all18 free stock-coordinate domains, all36 pair mappings and the exact current profiles. Enumerate all24 bracket-copy permutations to show a matching orientation multiset can be relabelled into the failed source pattern without changing complete family geometry, stock or guards. Family count equalities force all other bracket/insert profiles to zero when the four excluded counts hold. Reconstruct all four reifications and not-all clause; enumerate4000 count/flag cases. Restore the original entire parent proto exactly and verify actual import/export. Scope only the fixed-angle guarded-source/grid representation.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'audit/checks.json')['passed'] and load(SOURCE/'audit/checks.json')['passed'] and load(PROBE/'model-audit/checks.json')['passed'] and load(PROBE/'response-audit/checks.json')['passed'];source=load(SOURCE/'plan.json');pattern=[4,5,5,6,10,9,9,9,9];assert source['orientation_patterns']==[pattern];profiles=load(SOURCE/'profiles.json');assert profiles==load(ROOT/'output/h5-aligned-cog-profiles-20261026/profiles.json')
closed=proto(PROBE/'search/000/model.pb');assert closed==proto(PROBE/'models/000.pb');response=cp_model_pb2.CpSolverResponse();response.ParseFromString((PROBE/'search/000/response.pb').read_bytes());assert response.status==cp_model_pb2.INFEASIBLE and not response.solution
for i,p in enumerate(pattern):
    b=source['anchor_bounds_units1000'][str(p)]
    for axis in [0,1]:assert closed.variables[2*i+axis]==cp_model_pb2.IntegerVariableProto(name=f'p{i}-'+('xy'[axis]),domain=[b[axis],b[axis+2]])
    assert b[1::2]==load(DATA/'profiles'/f'{p:03d}.json')['y_bounds_units1000']
pairs=load(PROBE/'models/000-mapping.json');assert [r['parts'] for r in pairs]==[list(p) for p in combinations(range(9),2)];assert len(pairs)==36
parts=source['parts'];assert [p['family'] for p in parts]==['bracket']*4+['insert']+['cog']*4 and len(set(p['item'] for p in parts))==9;assert len({p['copy'] for p in parts[:4]})==4 and len({p['copy'] for p in parts[5:]})==4
assignments=[]
for perm in permutations(range(4)):
    assigned=[pattern[i] for i in perm];remaining=list(range(4));back=[]
    for want in pattern[:4]:
        i=next(i for i in remaining if assigned[i]==want);back.append(i);remaining.remove(i)
    assert [assigned[i] for i in back]==pattern[:4];assignments.append({'permutation':list(perm),'assigned_profiles':assigned,'relabel_to_source':back})
assert len(assignments)==24 and len({tuple(r['assigned_profiles']) for r in assignments})==12
old=proto(PARENT/'model.pb');m=proto(BASE/'model.pb');assert len(m.variables)==679 and len(m.constraints)==75 and m.variables[:675]==old.variables[:] and m.constraints[:66]==old.constraints[:];restored=cp_model_pb2.CpModelProto();restored.CopyFrom(m);del restored.variables[675:];del restored.constraints[66:];assert restored==old
mapping=load(BASE/'mapping.json');assert mapping==load(PARENT/'mapping.json');targets=[(4,1),(5,2),(6,1),(10,1)];rows=[]
for j,(p,count) in enumerate(targets):
    flag=675+j;assert m.variables[flag]==cp_model_pb2.IntegerVariableProto(name=f'excluded-profile{p}-count{count}',domain=[0,1]);ids=[r['variable'] for r in mapping if r['profile']==p]
    for k,(lit,domain) in enumerate([(flag,[count,count]),(-flag-1,[-2**63,count-1,count+1,2**63-1])]):
        c=cp_model_pb2.ConstraintProto();c.enforcement_literal.append(lit);c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend(domain);assert c==m.constraints[66+2*j+k]
    rows.append({'profile':p,'count':count,'flag':flag,'cell_variables':ids})
assert rows==load(BASE/'exclusion.json');c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-676,-677,-678,-679]);assert c==m.constraints[74];cases=0
for totals in product(range(5),range(5),range(5),range(2)):
    legal_flags=[]
    for bits in product([0,1],repeat=4):
        valid=True
        for j,(value,bit) in enumerate(zip(totals,bits)):
            constraint=m.constraints[66+2*j+(0 if bit else 1)];domain=list(constraint.linear.domain);valid &= any(lo<=value<=hi for lo,hi in zip(domain[::2],domain[1::2]))
        valid &= not all(bits)
        if valid:legal_flags.append(bits)
        cases+=1
    assert bool(legal_flags)==(totals!=(1,2,1,1))
assert cases==4000
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'copy-permutations.json',assignments);write(OUT/'implication.json',{'statement':'A guarded-source/grid placement with p4=1,p5=2,p6=1 and p10=1 has no other bracket or insert profiles because nonnegative family totals are4/1/4. Relabel its identical bracket copies into4/5/5/6 and its identical cog copies arbitrarily into the four9 slots. This gives exactly the audited full-stock source coordinate model, whose sole call returned INFEASIBLE. Therefore no placement in this source representation has all four profile counts. This does not transfer to another cog angle, source guard, continuous off-grid coordinates or unrestricted original packing.','source_pairs':36,'free_original_coordinates':18,'no_coordinate_locks':True,'parent_band_coefficients_unchanged':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':679,'constraints':75,'exact_parent_restoration_verified':True,'source_coordinate_domains_checked':18,'source_pair_mappings_checked':36,'copy_permutations_checked':24,'unique_profile_assignments':12,'count_flag_cases_checked':4000,'actual_import_export_verified':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
