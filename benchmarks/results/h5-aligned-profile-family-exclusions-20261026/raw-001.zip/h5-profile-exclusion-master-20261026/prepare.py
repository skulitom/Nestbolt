"""Exclude exactly one independently rejected nine-part profile-count pattern."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-aligned-cog-band-model-20261026';SOURCE=ROOT/'output/h5-aligned-nine-strip-source-20261026';PROBE=ROOT/'output/h5-aligned-nine-strip-probe-20261026';OUT=ROOT/'output/h5-profile-exclusion-master-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed'] and load(PROBE/'response-audit/checks.json')['passed'] and load(PROBE/'search/000/result.json')['status']=='INFEASIBLE';model=cp_model_pb2.CpModelProto();model.ParseFromString((PARENT/'model.pb').read_bytes());assert len(model.variables)==675 and len(model.constraints)==66;mapping=load(PARENT/'mapping.json');targets=[(4,1),(5,2),(6,1),(10,1)];paths=[PARENT/'model.pb',PARENT/'mapping.json',PARENT/'audit/checks.json',SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',PROBE/'models/000.pb',PROBE/'model-audit/checks.json',PROBE/'response-audit/checks.json',PROBE/'search/000/model.pb',PROBE/'search/000/response.pb',PROBE/'search/000/result.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'required_original_counts':{'bracket':4,'insert':1,'cog':4},'excluded_profile_counts':dict(targets),'mandatory_originals':[p['item'] for p in load(SOURCE/'plan.json')['parts']],'method':'Preserve the exact675-variable/66-constraint aligned-angle necessary band parent. Exclude only bracket-profile counts p4=1,p5=2,p6=1 and insert-profile p10=1 together: four exact reified profile-count equalities plus a not-all clause. Their conjunction fixes the complete orientation multiset because all other profile counts are nonnegative and family sums are4/1/4. Identical complete original family copies can be relabelled into the independently rejected source pattern4/5/5/6/10/9/9/9/9; all source coordinates were free inside the same stock domains and all36 pair clauses were retained. The exclusion is conditional on this exact guarded source/grid/cog-angle model, not raw unrestricted packing. Independent source/permutation, truth-table, parent-restoration and real-import audit before one new20second call in30shared seconds. No original part is dropped.'})
rows=[]
for profile,count in targets:
    v=len(model.variables);model.variables.add(name=f'excluded-profile{profile}-count{count}',domain=[0,1]);ids=[r['variable'] for r in mapping if r['profile']==profile]
    for lit,domain in [(v,[count,count]),(-v-1,[-2**63,count-1,count+1,2**63-1])]:
        c=model.constraints.add();c.enforcement_literal.append(lit);c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend(domain)
    rows.append({'profile':profile,'count':count,'flag':v,'cell_variables':ids})
model.constraints.add().bool_or.literals.extend(-r['flag']-1 for r in rows);shutil.copyfile(PARENT/'mapping.json',OUT/'mapping.json');write(OUT/'exclusion.json',rows);(OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');write(OUT/'result.json',{'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'extra_flags':4,'extra_constraints':9,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'result.json'))
