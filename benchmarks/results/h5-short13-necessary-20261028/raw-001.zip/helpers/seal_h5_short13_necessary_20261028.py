"""Archive the audited all-free short13 model, its UNKNOWN result and prior-main push."""
from pathlib import Path
from datetime import datetime,timezone
import json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-short13-necessary-20261028';OUT=ROOT/'benchmarks/results'/NAME;GEO=ROOT/'output/h5-short13-necessary-geometry-20261028';MODEL=ROOT/'output/h5-short13-necessary-model-20261028';PUB=MODEL/'publication';SYNC=ROOT/'output/h5-short-cog-main-sync-20261028';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='390fb2d30ba4637a59577b81f38952920f7c06dc' and not git('diff','HEAD','--name-only')
assert all(load(p)['passed'] for p in [GEO/'audit/checks.json',GEO/'known-prefix-audit/checks.json',MODEL/'model-audit/checks.json',MODEL/'response-audit/checks.json'])
assert load(MODEL/'search/result.json')['status']=='UNKNOWN' and not load(MODEL/'search/result.json')['has_solution']
old=load(ROOT/'benchmarks/results/h5-short-cog-transfer-20261028/publication-review.json');production=source_digest();assert production==old['production_digest'];readmes={p:digest(ROOT/p) for p in old['current_readmes']};assert readmes==old['current_readmes']
upstream={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(upstream[k]==old[k] for k in upstream)
receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['prior_main_all6_pass'] and receipt['normal_atomic_fast_forward'];jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6 and sum(j['conclusion']=='success' for j in jobs)==4 and sum(j['status']=='in_progress' for j in jobs)==2
OUT.mkdir();members={};queue=[];bindings={}
for folder in [GEO,MODEL,SYNC]:
    for p in folder.rglob('*'):
        if p.is_file():
            members[folder.name+'/'+p.relative_to(folder).as_posix()]=p
            if p.name=='plan.json':queue.append(p)
seen=set()
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;members['source-inputs/'+n]=q
        if q.name=='plan.json':queue.append(q)
for n in ['prepare_h5_short13_necessary_geometry.py','audit_h5_short13_necessary_geometry.py','build_h5_short13_necessary_model.py','audit_h5_short13_necessary_model.py','run_h5_short13_necessary_model.py','audit_h5_short13_necessary_response.py','audit_h5_short13_known_prefixes.py','pack_h5_evidence_archive.py','ccd1.py']:
    members['helpers/'+n]=ROOT/'output'/n
for n in ['fixed9.json','modes.json','search/attempts.json','result-audit/checks.json','result-audit/prefix-readbacks.json']:
    p=ROOT/'output/h5-short-cog-transfer-20261028'/n;members['known-source-prefix-inputs/'+n]=p;bindings[p.relative_to(ROOT).as_posix()]=digest(p)
members['helpers/'+Path(__file__).name]=Path(__file__);archive,manifest=pack(ROOT,OUT,NAME,members)
write(OUT/'source-bindings.json',bindings)
for p,n in [(GEO/'prepared.json','geometry-prepared.json'),(GEO/'audit/checks.json','geometry-checks.json'),(GEO/'known-prefix-audit/checks.json','known-prefix-checks.json'),(MODEL/'built.json','model-built.json'),(MODEL/'model-audit/checks.json','model-checks.json'),(MODEL/'search/result.json','solver-result.json'),(MODEL/'response-audit/checks.json','response-checks.json'),(SYNC/'receipt.json','prior-main-push.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')]:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'production_digest':production,'current_readmes':readmes,**upstream,'upstream_heads_and_releases_unchanged':True,'main_CI':40676201231,'main_CI_four_pass_two_running':True,'no_main_push_before_all6_pass':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'geometry_audit_passed':True,'model_audit_passed':True,'response_audit_passed':True,'known_source_prefix_audit_passed':True,'source_support_clauses_checked_against_known_prefixes':238125,'source_valid_prefix_false_rejections':0,'variables_verified':12197,'constraints_verified':15458,'all13_positions_free':True,'all_real_cog_angles_retained':True,'status':'UNKNOWN','necessary_assignment':False,'short_7_5_1_exclusion':False,'full66_witness':False,'solver_calls':1,'closed':True,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
write(OUT/'next-step.json',{'action':'Main390fb2d3 is pushed to both main and codex/v1-1-shop-files after priorf4f6f1fe passed all6 checks. Preserve new mainCI40676201231: four jobs pass, Ubuntu/Windows checks are still running at this checkpoint. Commit this evidence-only checkpoint locally and do not push another main head until all6 new jobs pass. The all-free7-bracket/5-insert/1-cog necessary model has12197 variables/15458 constraints and includes complete source inner, edge and closed-corner necessities for every allowed mode and every real cog angle. Its sole60-second call is closed UNKNOWN after2869712 branches,39823 conflicts,60.102096 returned/62.228226 shared seconds; keep the0.102096 soft overrun. No assignment or count exclusion exists. Do not rerun, reseed or extend this model. All635 previously valid source12 prefixes satisfy the new mixed necessities and whole-stock domains. A concrete next structural investigation is exact projection of the audited mixed forbidden regions across each complete short-stock relative-Y domain, deriving certified per-mode horizontal separations and testing whether they strengthen the existing whole-short allocation/profile frontier; preserve possible boundary coordinates and all real angles. Do not open another feasibility run for merely cosmetic changes or treat the fixed-source finite enumeration as impossibility. Alternatively construct a genuinely different complete66 source layout. The best audited latest count remains source64 with two missing brackets; source62 after the cog transfer is an alternate arrangement only. Keep every original mandatory, the guards/material target/PIH-off rule unchanged, and reserve native validation for a full source-valid66. H2 retains the explicit original-gate decision;22 reserved vectors are unopened; no release qualifies.','completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# All-free short-sheet13 necessities — 2026-10-28

The short-sheet allocation of **seven brackets, five inserts and one cog** remains
unresolved when all13 original positions are free. The sole bounded necessary
solve returns **UNKNOWN**, with no assignment and no infeasibility result.
The earlier fixed-neighbor construction failure therefore remains a limited
construction result; it has not been promoted into an exclusion or H5 credit.

## Geometry and complete model audit

The model covers all8 allowed bracket modes, both insert outer classes and
every real cog angle. It reuses audited source-contained rectangles and the
quantization-safe cog disk, plus actual original-vertex flat-edge and corner
support. The convex hull supplies support directions only; no filled cog hull
or mixed-family virtual disk is used for collision.

All24 prior bracket components are reproduced exactly, and the generic rectangle
theorems are extended to the two insert outer classes. Independent arithmetic
checks verify26 source components,312 Minkowski facets with9,984 exact point
inequalities,52 edge strips and312 closed corner boxes. Strict integer complements
of closed boxes preserve their boundary semantics. Complete outward-rounded
stock domains and source variants are unchanged.

Every one of the12,197 variables and15,458 constraints is independently read from
the serialized model. All13 anchors are free. Mandatory exactly-one mode choices,
195 optional source rectangles, source-only cumulative limits and2,670 mixed
separation clauses are checked. The clauses comprise178 inner-octagon,
356 source-edge and2,136 source-corner necessities. Ordering only relabels
identical copies. There are no fixed poses, hints, objectives or assumptions.

As a separate consistency check, all635 previously source-valid12-part prefixes
pass the new mixed necessities and stock domains:7,620 quantized poses and
238,125 mixed clauses, with zero false rejections. These prefixes lack the fifth
insert; this does not make them assignments to the full13-part model.

## Closed solver result

One CP-SAT call uses four workers, the60-second setting and90-second shared cap,
with `fj` excluded. It returns UNKNOWN after2,869,712 branches and39,823 conflicts.
Solver wall time is60.096943 seconds; returned call time60.102096 seconds;
shared process time62.228226 seconds. The small solver/return soft overruns are
retained. The independent response reader verifies the model hash, parameters,
logs, counters, status and absence of an assignment. The call is closed without
retry, reseeding or extension.

There is no source13 reconstruction, native validation, short-count exclusion,
full66 witness or H5 completion. Next investigate a stronger structural projection
of these source-supported regions across the complete short-sheet Y domains,
or a genuinely different full source construction. Boundary coordinates and
all allowed rotations must remain covered.

## Publication

Both previous checkpoints are on main at `390fb2d3`, normally fast-forwarded
after `f4f6f1fe` passed all six jobs. The new
[main CI40676201231](https://github.com/skulitom/Nestbolt/actions/runs/40676201231)
has four successful jobs and the Ubuntu/Windows checks still running at this
checkpoint. Preserve that run and defer the next main push until all six pass.
Production, READMEs and Sparrow/Studio heads and releases remain unchanged.
H2/H5 remain open at **60% completed milestone weight**; all22 reserved H2 vectors
remain unopened, and no new release qualifies.

[Geometry]({NAME}/geometry-checks.json),
[full model]({NAME}/model-checks.json),
[closed result]({NAME}/solver-result.json),
[response audit]({NAME}/response-checks.json),
[known-prefix checks]({NAME}/known-prefix-checks.json),
[main push]({NAME}/prior-main-push.json),
[next step]({NAME}/next-step.json),
[complete byte-verified archive]({NAME}/raw-manifest.json).
The archive contains{archive['archive_members']} canonical files and
{archive['verified_aliases']} exact-byte aliases in{archive['archive_bytes']:,}
compressed bytes, including all source inputs, scripts, protobufs and raw logs.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 all-free short13 necessities, 2026-10-28:** [the evidence]({link})
frees every position for7 brackets/5 inserts/1 cog, covering all allowed modes
and all real cog angles. Exact source inner/edge/corner geometry, all12,197
variables and15,458 constraints pass independent audits. All635 known valid
source12 prefixes satisfy238,125 mixed rules and7,620 stock domains. The sole
60-second solver call closes UNKNOWN after2,869,712 branches/39,823 conflicts,
60.102096 returned/62.228226 shared seconds; small soft overruns are retained.
No assignment, source13 witness, count exclusion or native/H5 pass exists, and
the call will not be retried or extended. Next seek a stronger exact structural
projection or different complete source construction. Main390fb2d3 contains both
prior checkpoints; its newCI40676201231 has four passing jobs and two live checks.
Preserve it until all six pass before the next main push. Production, READMEs
and upstream releases are unchanged. H2/H5 stay open at60%;22 reserved vectors
remain unopened and no new release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'completion_percent':60})
