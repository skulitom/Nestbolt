"""Read and verify every variable and constraint in the13-original necessary model."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short13-necessary-model-20261028';GEO=ROOT/'output/h5-short13-necessary-geometry-20261028';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
p=cp_model_pb2.CpModelProto();p.ParseFromString((BASE/'model.pb').read_bytes());assert not p.HasField('objective') and not p.HasField('floating_point_objective') and not p.solution_hint.vars and not p.assumptions and not p.search_strategy
vs={v['id']:v for v in load(GEO/'variants.json')};ds=load(GEO/'domains.json');stock=load(GEO/'stock.json');components=load(GEO/'components.json');mp=load(BASE/'mapping.json');vi=ci=0;LOW=-9223372036854775808;HIGH=9223372036854775807
def variable(index,name,domain):
    global vi
    assert index==vi and p.variables[vi].name==name and list(p.variables[vi].domain)==domain;vi+=1
def linear(index,coeffs,domain,enforcement=[]):
    global ci
    assert index==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='linear' and list(ct.enforcement_literal)==enforcement and dict(zip(ct.linear.vars,ct.linear.coeffs))=={k:v for k,v in coeffs.items() if v} and list(ct.linear.domain)==domain;ci+=1
def expr(e,var,offset):assert dict(zip(e.vars,e.coeffs))==({var:1} if var is not None else {}) and e.offset==offset
families=['bracket']*7+['insert']*5+['cog'];assert len(mp['items'])==13
for i,(family,rec) in enumerate(zip(families,mp['items'])):
    assert rec['index']==i and rec['family']==family;allowed=[d for d in ds if vs[d['variant']]['family']==family];x,y=rec['coordinates'];variable(x,f'x_{i}',[min(d['bounds_um'][0] for d in allowed),max(d['bounds_um'][2] for d in allowed)]);variable(y,f'y_{i}',[min(d['bounds_um'][1] for d in allowed),max(d['bounds_um'][3] for d in allowed)]);assert len(rec['options'])==len(allowed)
    for d,o in zip(allowed,rec['options']):assert d['variant']==o['variant'];variable(o['selector'],f'option_{i}_{d["variant"]}',[0,1])
    assert rec['exactly_one_constraint']==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='exactly_one' and not ct.enforcement_literal and list(ct.exactly_one.literals)==[o['selector'] for o in rec['options']];ci+=1
    for d,o in zip(allowed,rec['options']):
        b=d['bounds_um'];assert len(o['stock_constraints'])==4
        for n,var,domain in [(0,x,[b[0],HIGH]),(1,y,[b[1],HIGH]),(2,x,[LOW,b[2]]),(3,y,[LOW,b[3]])]:linear(o['stock_constraints'][n],{var:1},domain,[o['selector']])
assert vi==93
order=list(zip(range(6),range(1,7)))+list(zip(range(7,11),range(8,12)));assert len(mp['symmetry'])==10
for (a,b),rec in zip(order,mp['symmetry']):assert rec['items']==[a,b];linear(rec['constraint'],{mp['items'][a]['coordinates'][1]:1,mp['items'][b]['coordinates'][1]:-1},[LOW,0])
ri=0;coarse=[];capacity=[]
for rec in mp['items']:
    i=rec['index']
    for opt in rec['options']:
        v=vs[opt['variant']];z=opt['selector'];groups=[('coarse',v['coarse_rectangles_um'])]
        if rec['family']=='cog':groups.append(('source',v['source_capacity_rectangles_um']))
        for kind,rs in groups:
            for component,b in enumerate(rs):
                saved=mp['rectangles'][ri];assert saved=={'item':i,'variant':v['id'],'kind':kind,'component':component,'bounds_um':b,'presence':z,'intervals':[ci,ci+1]};indices=[ci,ci+1]
                for axis in [0,1]:
                    ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='interval' and list(ct.enforcement_literal)==[z] and ct.name==f'{kind}_{"xy"[axis]}_{ri}';var=rec['coordinates'][axis];expr(ct.interval.start,var,b[axis]);expr(ct.interval.size,None,b[axis+2]-b[axis]);expr(ct.interval.end,var,b[axis+2]);ci+=1
                if kind=='coarse':coarse.append((indices,b))
                if kind=='source' or rec['family']!='cog':capacity.append((indices,b))
                ri+=1
assert ri==len(mp['rectangles'])==195 and vi==93
assert mp['no_overlap']==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='no_overlap_2d' and not ct.enforcement_literal and list(ct.no_overlap_2d.x_intervals)==[r[0][0] for r in coarse] and list(ct.no_overlap_2d.y_intervals)==[r[0][1] for r in coarse];ci+=1
assert len(mp['cumulative'])==2
for axis in [0,1]:
    assert mp['cumulative'][axis]==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='cumulative' and not ct.enforcement_literal and list(ct.cumulative.intervals)==[r[0][axis] for r in capacity] and len(ct.cumulative.demands)==len(capacity)
    for demand,(_,b) in zip(ct.cumulative.demands,capacity):expr(demand,None,b[3-axis]-b[1-axis])
    expr(ct.cumulative.capacity,None,stock['capacity_um'][1-axis]);ci+=1
si=0;cg=mp['items'][12]['coordinates'];kind_counts={}
for rec in mp['items'][:-1]:
    i=rec['index'];xy=rec['coordinates']
    for opt in rec['options']:
        for comp in [q for q in components if q['variant']==opt['variant']]:
            for fi,forbidden in enumerate(comp['forbidden']):
                saved=mp['separations'][si];assert saved['item']==i and saved['variant']==opt['variant'] and saved['component']==comp['component'] and saved['forbidden']==fi;assert len(saved['facet_variables'])==len(saved['facet_constraints'])==len(forbidden['faces']);kind_counts[forbidden['kind']]=kind_counts.get(forbidden['kind'],0)+1
                for facet,(nx,ny,rhs) in enumerate(forbidden['faces']):
                    z=saved['facet_variables'][facet];variable(z,f'face_{si}_{facet}',[0,1]);linear(saved['facet_constraints'][facet],{cg[0]:nx,cg[1]:ny,xy[0]:-nx,xy[1]:-ny},[LOW,rhs],[z])
                assert saved['or_constraint']==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='bool_or' and list(ct.enforcement_literal)==[opt['selector']] and list(ct.bool_or.literals)==saved['facet_variables'];ci+=1;si+=1
assert si==len(mp['separations'])==2670 and vi==len(p.variables)==12197 and ci==len(p.constraints)==15458
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':vi,'constraints_verified':ci,'mandatory_originals':13,'all13_required':True,'source_rectangles_verified':ri,'mixed_separation_clauses_verified':si,'mixed_clause_kinds':kind_counts,'all_bracket_modes_and_insert_classes_verified':True,'all_real_cog_angles_retained':True,'all13_positions_free':True,'same_family_orders_only_relabel_identical_copies':True,'source_only_cumulative_constraints':2,'virtual_mixed_family_disks':False,'no_objective_hints_or_assumptions':True,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
