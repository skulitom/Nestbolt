"""One all-free13-original necessary short-sheet model; every real cog angle is retained."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-short13-necessary-geometry-20261028';OUT=ROOT/'output/h5-short13-necessary-model-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(GEO/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in GEO.rglob('*') if p.is_file()},'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'retry_permitted':False,'ignore_subsolvers':['fj'],'objective':None,'hints':False,'all13_subproblem_originals_required':True,'method':'Free all13 anchors for7 brackets,5 inserts,1 cog on the entire original short sheet, using audited outward quantization-safe domains. Exactly one of all8 bracket modes or both insert outer classes is mandatory for each original; cog source inner/support necessities cover all real angles without choosing one. Optional source-contained rectangles and separate source-only cumulative constraints are supplemented by every inner-octagon, actual-vertex edge-strip and closed actual-vertex corner-box separation for all12 noncogs against the cog. Same-family Y ordering only renames identical copies. No objective, advisory hints, fixed original pose, virtual mixed-family disk or first-sheet exclusion. Audit the full serialized model before one60-second call within90 shared seconds. A positive necessary assignment requires source reconstruction; failure/UNKNOWN is not infeasibility. This subproblem is not a full66 source/native/H5 witness.'})
vs={v['id']:v for v in load(GEO/'variants.json')};ds=load(GEO/'domains.json');stock=load(GEO/'stock.json');components=load(GEO/'components.json');model=cp_model.CpModel();records=[];coords=[];flags={}
families=['bracket']*7+['insert']*5+['cog']
for i,family in enumerate(families):
    allowed=[d for d in ds if vs[d['variant']]['family']==family];x=model.new_int_var(min(d['bounds_um'][0] for d in allowed),max(d['bounds_um'][2] for d in allowed),f'x_{i}');y=model.new_int_var(min(d['bounds_um'][1] for d in allowed),max(d['bounds_um'][3] for d in allowed),f'y_{i}');zs=[model.new_bool_var(f'option_{i}_{d["variant"]}') for d in allowed];choice=model.add_exactly_one(zs);options=[]
    for d,z in zip(allowed,zs):
        b=d['bounds_um'];cs=[model.add(x>=b[0]),model.add(y>=b[1]),model.add(x<=b[2]),model.add(y<=b[3])]
        for ct in cs:ct.only_enforce_if(z)
        options.append({'variant':d['variant'],'selector':z.index,'stock_constraints':[ct.index for ct in cs]});flags[i,d['variant']]=z
    records.append({'index':i,'family':family,'coordinates':[x.index,y.index],'options':options,'exactly_one_constraint':choice.index});coords.append([x,y])
symmetry=[]
for ids in [list(range(7)),list(range(7,12))]:
    for a,b in zip(ids,ids[1:]):symmetry.append({'items':[a,b],'constraint':model.add(coords[a][1]<=coords[b][1]).index})
rectangles=[];coarse=[];capacity=[]
for rec in records:
    i=rec['index']
    for opt in rec['options']:
        v=vs[opt['variant']];z=flags[i,v['id']];groups=[('coarse',v['coarse_rectangles_um'])]
        if rec['family']=='cog':groups.append(('source',v['source_capacity_rectangles_um']))
        for kind,rs in groups:
            for component,b in enumerate(rs):
                k=len(rectangles);xi=model.new_optional_fixed_size_interval_var(coords[i][0]+b[0],b[2]-b[0],z,f'{kind}_x_{k}');yi=model.new_optional_fixed_size_interval_var(coords[i][1]+b[1],b[3]-b[1],z,f'{kind}_y_{k}')
                rectangles.append({'item':i,'variant':v['id'],'kind':kind,'component':component,'bounds_um':b,'presence':z.index,'intervals':[xi.index,yi.index]});entry=(xi,yi,b)
                if kind=='coarse':coarse.append(entry)
                if kind=='source' or rec['family']!='cog':capacity.append(entry)
no=model.add_no_overlap_2d([r[0] for r in coarse],[r[1] for r in coarse]);caps=[]
for axis in [0,1]:caps.append(model.add_cumulative([r[axis] for r in capacity],[r[2][3-axis]-r[2][1-axis] for r in capacity],stock['capacity_um'][1-axis]).index)
separations=[]
for rec in records[:-1]:
    i=rec['index']
    for opt in rec['options']:
        for comp in [q for q in components if q['variant']==opt['variant']]:
            for fi,forbidden in enumerate(comp['forbidden']):
                k=len(separations);zs=[];cs=[]
                for facet,(nx,ny,rhs) in enumerate(forbidden['faces']):
                    z=model.new_bool_var(f'face_{k}_{facet}');ct=model.add(nx*(coords[12][0]-coords[i][0])+ny*(coords[12][1]-coords[i][1])<=rhs);ct.only_enforce_if(z);zs.append(z);cs.append(ct.index)
                ct=model.add_bool_or(zs);ct.only_enforce_if(flags[i,opt['variant']]);separations.append({'item':i,'variant':opt['variant'],'component':comp['component'],'forbidden':fi,'facet_variables':[z.index for z in zs],'facet_constraints':cs,'or_constraint':ct.index})
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'items':records,'symmetry':symmetry,'rectangles':rectangles,'no_overlap':no.index,'cumulative':caps,'separations':separations})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'mandatory_originals':13,'noncog_options':66,'cog_all_angle_option':1,'optional_source_rectangles':len(rectangles),'mixed_separation_clauses':len(separations),'all13_required':True,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
