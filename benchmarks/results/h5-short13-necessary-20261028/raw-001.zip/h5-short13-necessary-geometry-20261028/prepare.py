"""All-angle source necessities for all thirteen free originals on the short sheet."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-short13-necessary-geometry-20261028';ALLOC=ROOT/'output/h5-allocation-geometry-20261026';OCT=ROOT/'output/h5-mixed-octagon-geometry-20261026';EDGE=ROOT/'output/h5-cog-flat-edge-support-20261026';CORNER=ROOT/'output/h5-cog-corner-support-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
    points=sorted(set(points));lo=[];hi=[]
    for group,seq in [(lo,points),(hi,points[::-1])]:
        for p in seq:
            while len(group)>1 and cross(group[-2],group[-1],p)<=0:group.pop()
            group.append(p)
    return lo[:-1]+hi[:-1]
def box_faces(b,closed=False):
    x,y,xx,yy=b;eps=1 if closed else 0;return [[1,0,x-eps],[-1,0,-xx-eps],[0,1,y-eps],[0,-1,-yy-eps]]
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[ALLOC/n for n in ['variants.json','domains.json','stocks.json','originals.json','audit/checks.json']]+[OCT/n for n in ['octagon.json','forbidden-polygons.json','audit/checks.json']]+[EDGE/n for n in ['support-proof.json','moving-bracket-support-strips.json','audit/checks.json','audit/necessity-proof.json']]+[CORNER/n for n in ['proof.json','moving-corner-boxes.json','audit/checks.json','audit/necessity-proof.json']]+[ROOT/'output/h5-short-cog-transfer-20261028/result-audit/checks.json']
assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Prepare the necessary subproblem7 brackets/5 inserts/1 cog with every anchor free on the original short-stock domain. Reuse audited quantization-safe source rectangles, all-angle cog inner disk, original-vertex flat-edge and corner-support theorems. Extend their generic rectangle construction to both insert outer classes. Original quarter-turn/mirror variants and outward-rounded stock domains remain complete. The convex hull supplies support directions only; it is never substituted as filled cog geometry. Strict polygon/strip interiors are forbidden with boundary contact retained; certified CLOSED corner boxes require strict outside integer inequalities. No actual cog angle is selected. No fixed first-sheet pose or old fixed49/51 exclusion transfers. This preparation is not a source layout or solver result.'})
vs=load(ALLOC/'variants.json');ds=load(ALLOC/'domains.json');stocks=load(ALLOC/'stocks.json');octagon=load(OCT/'octagon.json')['vertices_um'];edge=load(EDGE/'support-proof.json');corner=load(CORNER/'proof.json');h=edge['rounded_center_support_lower_um'];L=edge['support_vertex_transverse_upper_um'];R=corner['rounded_vertex_radius_strict_upper_um'];pairs=corner['rounded_simultaneous_support_pairs_um'];records=[]
oldpoly={(p['variant'],p['component']):p for p in load(OCT/'forbidden-polygons.json')};oldstrip={(p['variant'],p['component']):p for p in load(EDGE/'moving-bracket-support-strips.json')};oldcorner={(p['variant'],p['component']):p for p in load(CORNER/'moving-corner-boxes.json')}
for v in vs[:10]:
    assert v['family'] in ['bracket','insert']
    for component,b in enumerate(v['coarse_rectangles_um']):
        x,y,xx,yy=b;w=xx-x;height=yy-y;assert min(w,height)>max(edge['rectangle_minimum_axial_width_strict_um'],edge['rectangle_minimum_transverse_width_strict_um'])
        vertices=hull([(a-u,c-t) for a in [x,xx] for c in [y,yy] for u,t in octagon]);faces=[]
        for p,q in zip(vertices,vertices[1:]+vertices[:1]):
            nx,ny=p[1]-q[1],q[0]-p[0];rhs=nx*p[0]+ny*p[1];d=math.gcd(abs(nx),abs(ny));assert rhs%d==0;faces.append([nx//d,ny//d,rhs//d])
        strips=[[x-h,y+L,xx+h,yy-L],[x+L,y-h,xx-L,yy+h]];boxes=[]
        for pi,(px,py) in enumerate(pairs):
            dx,dy=max(0,R-w),max(0,R-height)
            if dx>px or dy>py:continue
            for sx,sy in [(1,1),(-1,1),(-1,-1),(1,-1)]:
                cx=x if sx==1 else xx;cy=y if sy==1 else yy;xb=sorted([cx-sx*dx,cx-sx*px]);yb=sorted([cy-sy*dy,cy-sy*py]);boxes.append({'support_pair':pi,'signs':[sx,sy],'corner_um':[cx,cy],'offset_range_um':[dx,dy,px,py],'closed_forbidden_box_um':[xb[0],yb[0],xb[1],yb[1]]})
        if v['family']=='bracket':
            assert vertices==[tuple(p) for p in oldpoly[v['id'],component]['vertices_um']] and faces==oldpoly[v['id'],component]['inward_faces']
            assert strips==oldstrip[v['id'],component]['strict_forbidden_relative_center_strips_um'] and boxes==oldcorner[v['id'],component]['corner_boxes']
        forbidden=[{'kind':'inner_octagon','faces':faces}]+[{'kind':'source_edge_strip','box':b,'faces':box_faces(b)} for b in strips]+[{'kind':'source_corner_box','box':r['closed_forbidden_box_um'],'faces':box_faces(r['closed_forbidden_box_um'],True)} for r in boxes]
        records.append({'variant':v['id'],'family':v['family'],'component':component,'source_rectangle_um':b,'octagon_vertices_um':vertices,'edge_strips_um':strips,'corner_boxes':boxes,'forbidden':forbidden})
write(OUT/'components.json',records);write(OUT/'variants.json',[v for v in vs if v['family'] in ['bracket','insert','cog']]);write(OUT/'domains.json',[d for d in ds if d['allowed'] and d['sheet']==1 and vs[d['variant']]['family'] in ['bracket','insert','cog']]);write(OUT/'stock.json',stocks[1]);write(OUT/'source-proofs.json',{'edge':edge,'corner':corner,'octagon':load(OCT/'octagon.json')})
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'noncog_source_components':len(records),'old_bracket_components_exactly_reproduced':24,'insert_components_extended':2,'forbidden_polygons':len(records),'source_edge_strips':sum(len(r['edge_strips_um']) for r in records),'source_corner_boxes':sum(len(r['corner_boxes']) for r in records),'all_real_cog_angles':True,'no_source_geometry_approximation_as_feasibility':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
