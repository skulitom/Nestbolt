"""Check the new all-angle necessities against every635 previously source-valid prefix."""
from pathlib import Path
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-short13-necessary-geometry-20261028';SRC=ROOT/'output/h5-short-cog-transfer-20261028';OUT=GEO/'known-prefix-audit';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();assert load(SRC/'result-audit/checks.json')['passed'] and load(GEO/'audit/checks.json')['passed']
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};fixed=load(SRC/'fixed9.json');attempts=load(SRC/'search/attempts.json');prefixes=load(SRC/'result-audit/prefix-readbacks.json');modes=load(SRC/'modes.json');vs=load(GEO/'variants.json');domains={d['variant']:d['bounds_um'] for d in load(GEO/'domains.json')};components=load(GEO/'components.json');checks=[];clauses=0
def row(mi,xy,copy):
    m=modes[mi];return {'part_id':m['family'],'copy_index':copy,'sheet_id':'sheet-1','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[xy[k]+m['source_translation_offset'][k] for k in range(2)]}}
def quant(r):
    t=r['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];family=r['part_id']
    if family=='cog':v=12;x=139.723742*c-139.723742*s+tx;y=139.723742*s+139.723742*c+ty
    else:
        q=round(a/(math.pi/2))%4
        if family=='insert':q%=2
        v=next(v['id'] for v in vs if v['family']==family and v['quarter_turn']==q and v['mirrored']==t['mirrored']);pts=[(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[family]['geometry'][0]['outer']];x=min(p[0] for p in pts);y=min(p[1] for p in pts)
    xy=[math.floor(x*1000),math.floor(y*1000)];b=domains[v];assert b[0]<=xy[0]<=b[2] and b[1]<=xy[1]<=b[3];return v,xy
for index,prefix in enumerate(prefixes):
    a=attempts[prefix['attempt']];rows=fixed+[row(a['bracket_mode'],a['bracket_anchor'],6),row(a['cog_mode'],a['cog_anchor'],14),row(prefix['insert_mode'],prefix['insert_anchor'],3)];poses=[quant(r) for r in rows];cx,cy=next(xy for v,xy in poses if v==12);count=0
    for v,(x,y) in poses:
        if v==12:continue
        dx,dy=cx-x,cy-y
        for component in [r for r in components if r['variant']==v]:
            for forbidden in component['forbidden']:
                assert any(nx*dx+ny*dy<=rhs for nx,ny,rhs in forbidden['faces']),(index,v,dx,dy,forbidden['kind']);count+=1
    clauses+=count;checks.append({'prefix':index,'passed':True,'quantized_originals':len(poses),'mixed_clauses':count})
write(OUT/'prefixes.json',checks);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'previously_source_valid_prefixes':len(prefixes),'quantized_original_poses_checked':12*len(prefixes),'source_support_clauses_checked':clauses,'stock_domains_checked':12*len(prefixes),'false_rejections':0,'new_solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
