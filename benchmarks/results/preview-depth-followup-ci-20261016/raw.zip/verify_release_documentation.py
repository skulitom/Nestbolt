from pathlib import Path
from hashlib import sha256
import json
import re
import subprocess
import zipfile
root=Path(__file__).resolve().parents[1]
def check_file(path,row):
    data=path.read_bytes()
    assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256'],path
for folder in ['preview-depth-published-20261016','preview-depth-publication-audit-20261016']:
    base=root/'benchmarks/results'/folder
    inventory=json.loads((base/'integrity.json').read_bytes())
    for name,row in inventory.items():check_file(base/name,row)
base=root/'benchmarks/results/preview-depth-published-features-20261016'
integrity=json.loads((base/'integrity.json').read_bytes())
check_file(base/integrity['archive'],integrity)
with zipfile.ZipFile(base/integrity['archive']) as z:
    assert z.testzip() is None and set(z.namelist())==set(integrity['members'])
    for name,row in integrity['members'].items():
        data=z.read(name)
        assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256'],name
assert (root/'BENCHMARKS.md').read_bytes().startswith(subprocess.check_output(['git','show','HEAD:BENCHMARKS.md'],cwd=root))
subprocess.run(['git','diff','--exit-code','c36baa8145e9e7b51e5667f4e4eaa0242256fc6e','--','crates','web/src','Cargo.toml','Cargo.lock','web/package.json','web/package-lock.json'],cwd=root,check=True)
files=['README.md','docs/STATUS.md','docs/RELEASE_READINESS.md','mcpb/PUBLISHING.md',
    'benchmarks/results/preview-depth-published-20261016.md','benchmarks/results/preview-depth-published-features-20261016.md']
links=0
for rel in files:
    path=root/rel
    for target in re.findall(r'\]\(([^\s)]+)\)',path.read_text(encoding='utf-8')):
        if '://' in target or target.startswith('#'):continue
        assert (path.parent/target.split('#')[0]).exists(),(rel,target)
        links+=1
print(json.dumps({'documentation_links_checked':links,'publication_inventories_and_feature_archive_verified':True,
    'benchmark_history_append_only':True,'released_product_source_unchanged':True}))
