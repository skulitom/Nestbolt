"""Observe the existing one-second Firefox lead test under concurrent CI-like load."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json
import subprocess
root=Path(__file__).resolve().parents[1]
out=root/'output/preview-c36-firefox-diagnostic-20261016'
out.mkdir(exist_ok=False)
command=['node','node_modules/@playwright/test/cli.js','test','tests/features.spec.ts',
    '--grep','^lead allowances expose flags', '--project','firefox','--repeat-each','16',
    '--workers','8','--output',str(out/'test-results'),'--trace','retain-on-failure']
plan={'purpose':'Diagnose missing lead report from existing c36baa8 main CI; preserve all sixteen functional observations, not a quality benchmark or replacement of failed CI.',
    'started_at':datetime.now(timezone.utc).isoformat(),'command':command,'source_test_sha256':sha256((root/'web/tests/features.spec.ts').read_bytes()).hexdigest(),
    'test_source_unchanged':True,'one_second_budget_unchanged':True,'affinity':'CCD1 logical 16-31 inherited from wrapper'}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
    result=subprocess.run(command,cwd=root/'web',stdout=stdout,stderr=stderr,timeout=360)
(out/'completed.json').write_text(json.dumps({'exit_code':result.returncode,'ended_at':datetime.now(timezone.utc).isoformat()},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'exit_code':result.returncode,'evidence':str(out)}))
