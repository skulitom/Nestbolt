from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'output/diagnose_published_firefox_leads.py').read_text(encoding='utf-8')
source=source.replace('preview-c36-firefox-diagnostic-20261016','preview-c36-firefox-selected-diagnostic-20261016')
source=source.replace("'--grep','^lead allowances expose flags'","'--grep','lead allowances expose flags'")
exec(compile(source,__file__,'exec'))
