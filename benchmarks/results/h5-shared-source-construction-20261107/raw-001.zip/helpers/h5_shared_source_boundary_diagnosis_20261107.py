"""Diagnostic snippet appended after the closed outcome and family checks."""
import cProfile,pstats,shapely
from h5_cross_pair_boundary_gradient_20261107 import boundary_gradients
from h5_bbox_boundary_diagnostic_20261107 import screened_boundary_gradients
from shapely.geometry import Polygon

E=BASE/'search/epoch-01';first_call=load(BASE/'search/epoch-00/optimizer-opened.json');call=load(E/'optimizer-opened.json');opened=load(E/'opened.json');result=load(BASE/'search/result.json')
runtime_paths=[Path(__file__),ROOT/'output/h5_bbox_boundary_diagnostic_20261107.py',ROOT/'output/h5_cross_pair_boundary_gradient_20261107.py']+[E/n for n in ['response.json','model.json','opened.json','optimizer-opened.json']]+[BASE/'search/epoch-00/optimizer-opened.json',BASE/'search/result.json',BASE/'response-audit/checks.json']
write(OUT/'runtime-cost-plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in runtime_paths},'method':'Reconcile complete runtime costs and profile nine exact re-evaluations of three independently checked closed winners. Separately compare existing complete boundary kernel to strict disjoint-box edge filtering on each of four closed states and both geometry levels. Fixed dense/screened/screened/dense order, including all array construction/bounds/filtering and integrations. Require exact gradients/counts/coincidence per directed pair; empty, containment, coincident and touching synthetic cases also checked. This is a diagnostic kernel only; no changed objective, source initializer, optimizer or reopened problem.','validation_only':True,'optimizer_calls':0})
prof=cProfile.Profile();prof.enable()
for repeat in range(3):
    for label,r in response['winners'].items():
        score,g,info=obj.evaluate(r['values'],True)
        assert score==r['augmented_objective_mm2'] and np.array_equal(g,r['gradient'])
prof.disable();prof.dump_stats(str(OUT/'objective-profile.prof'));stats=pstats.Stats(prof)
profile=[]
for (filename,line,name),(primitive,total,self_seconds,cumulative,callers) in stats.stats.items():
    profile.append({'file':filename,'line':line,'name':name,'primitive_calls':primitive,'total_calls':total,'self_seconds':self_seconds,'cumulative_seconds':cumulative})
profile.sort(key=lambda r:(-r['self_seconds'],r['file'],r['line']))
write(OUT/'objective-profile.json',{'diagnostic_only':True,'profiled_evaluations':9,'profiler_overhead_included':True,'total_seconds':stats.total_tt,'functions':profile})
controls=[]
for label,point in [('initial',model['initial'])]+[(label,r['values']) for label,r in response['winners'].items()]:
    for level,entries in enumerate(obj.geometry(point)):
        shapes=np.asarray([e[1] for e in entries],dtype=object);areas=shapely.area(shapely.intersection(shapes[obj.left],shapes[obj.right]))
        vertices=[];lines=[];others=[];pivots=[]
        for index in np.flatnonzero(areas>0):
            i,j=model['pairs'][index]
            for own,other in [(i,j),(j,i)]:
                v,poly,ll,pivot=entries[own];vertices.append(v);lines.append(ll);others.append(entries[other][1]);pivots.append(pivot)
        observed=[];times=[]
        for kind in ['dense','screened','screened','dense']:
            before=time.perf_counter();out=(boundary_gradients if kind=='dense' else screened_boundary_gradients)(vertices,lines,others,pivots)
            times.append(time.perf_counter()-before);observed.append(out)
        assert all(all(np.array_equal(a,b) for a,b in zip(observed[0],out)) for out in observed[1:])
        counts={};screened_boundary_gradients(vertices,lines,others,pivots,counts)
        controls.append({'state':label,'level':level,'directed_pairs':len(vertices),**counts,'all_four_outputs_exact':True,'ABBA_complete_kernel_seconds':times})
write(OUT/'boundary-box-controls.json',controls)
def args_for(vertices,other):
    v=np.asarray(vertices,dtype=float).reshape((-1,2));ll=shapely.linestrings(np.stack((v,np.roll(v,-1,axis=0)),axis=1)) if len(v) else np.empty(0,dtype=object)
    return [v],[ll],[other],[[0.,0.]]
square=[[0.,0.],[2.,0.],[2.,2.],[0.,2.]]
cases=[('no_pairs',([],[],[],[])),('no_edges',args_for([],Polygon(square))),('identical',args_for(square,Polygon(square))),('contained',args_for(square,Polygon([[-1,-1],[3,-1],[3,3],[-1,3]]))),('disjoint',args_for(square,Polygon([[3,0],[5,0],[5,2],[3,2]]))),('corner_touch',args_for(square,Polygon([[2,2],[4,2],[4,4],[2,4]]))),('shared_edge',args_for(square,Polygon([[2,0],[4,0],[4,2],[2,2]]))),('zero_length_edge',args_for([[0,0]]+square,Polygon(square)))]
synthetic=[]
for name,args in cases:
    before=boundary_gradients(*args);after=screened_boundary_gradients(*args);assert all(np.array_equal(a,b) for a,b in zip(before,after))
    synthetic.append({'case':name,'exact':True})
write(OUT/'boundary-policy-controls.json',synthetic)
dense=[sum(r['ABBA_complete_kernel_seconds'][i] for r in controls) for i in [0,3]];screened=[sum(r['ABBA_complete_kernel_seconds'][i] for r in controls) for i in [1,2]]
write(OUT/'runtime-costs.json',{'passed':True,'runtime_weight_selection_output_model_interval_seconds':call['algorithm_seconds_including_preparation']-opened['algorithm_seconds_including_preparation'],'first_call_startup_after_preparation_seconds':first_call['algorithm_seconds_including_preparation']-result['complete_preparation_seconds'],'optimizer_allocations_seconds':[first_call['allocated_seconds'],call['allocated_seconds']],'boundary_contexts':len(controls),'directed_pairs':sum(r['directed_pairs'] for r in controls),'total_edges':sum(r['total_edges'] for r in controls),'retained_edges':sum(r['retained_edges'] for r in controls),'omitted_edges':sum(r['omitted_edges'] for r in controls),'dense_aggregate_seconds':dense,'screened_aggregate_seconds':screened,'synthetic_boundary_cases':len(synthetic),'profiled_objective_evaluations':9,'full_objective_speedup_claimed':False,'new_objective_prepared':False,'new_source_state_prepared':False,'optimizer_calls':0,'closed_search_resumed':False,'H5_complete':False})
print(load(OUT/'runtime-costs.json'))
