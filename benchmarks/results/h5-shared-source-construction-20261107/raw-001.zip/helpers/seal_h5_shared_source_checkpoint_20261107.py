"""Archive the shared-selector source construction and independent closed replay."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-shared-source-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-shared-source-preflight-20261107';F=BASE/'response-audit';D=BASE/'outcome-diagnostic'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-shared-geometry-preflight-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==2 and front['best_original']['pair_failures']==54 and not front['source_valid66'] and front['independent_runtime_full_scores']==15013",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/f'h5-shared-source-{stage}-process-20261107' for stage in ['preparation','audit','response-audit','diagnosis']]+[ROOT/'output/h5-tiered-source-main-sync-20261107']",
"['*h5*mixed*mode*20261107.py']":"['*h5*shared*source*20261107.py','h5_bbox_boundary_diagnostic_20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_shared_source_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json','runtime-cost-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(BASE/'audit/checks.json','source-preflight-audit.json'),(BASE/'audit/selected-model-controls.json','source-model-controls.json'),(BASE/'audit/initializer-source-controls.json','initializer-source-controls.json'),(BASE/'audit/inherited-source-domains.json','inherited-source-domains.json'),(BASE/'audit/cache-rejection-controls.json','source-cache-controls.json'),(BASE/'audit/deadline-controls.json','source-deadline-controls.json'),(BASE/'source-cache-bindings.json','source-cache-bindings.json'),(BASE/'model-and-source-costs.json','source-costs.json'),(F/'checks.json','response-audit.json'),(F/'epoch-reconciliation.json','epoch-reconciliation.json'),(F/'epoch-01/original-source-checks.json','best-original-source-checks.json'),(F/'epoch-01-selection/checks.json','runtime-selection-audit.json'),(BASE/'search/plan.json','search-plan.json'),(BASE/'search/budget-assessment.json','budget-assessment.json'),(BASE/'search/result.json','closed-search-result.json'),(BASE/'search/process.json','closed-search-process.json'),(D/'checks.json','outcome-diagnostic.json'),(D/'family-failures.json','family-failures.json'),(D/'runtime-costs.json','runtime-costs.json'),(D/'boundary-box-controls.json','boundary-box-controls.json'),(D/'boundary-policy-controls.json','boundary-policy-controls.json'),(D/'objective-profile.json','objective-profile.json'),(BASE/'search/main-ci-at-review.json','main-ci-at-review.json'),(ROOT/'output/h5-tiered-source-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for stage in ['preparation','audit','response-audit','diagnosis']:copies.append((ROOT/'output'/f'h5-shared-source-{stage}-process-20261107'/'process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
closed=load(BASE/'closed-problems.json')+[load(BASE/f'search/epoch-{e:02d}/closed-problem.json') for e in [0,1]];assert len(closed)==len({r['key'] for r in closed})==23;write(OUT/'closed-problems.json',closed)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
prep=load(OUT/'source-preflight-audit.json');model=load(OUT/'source-model-controls.json');diag=load(OUT/'outcome-diagnostic.json');cost=load(OUT/'runtime-costs.json');process=load(OUT/'closed-search-process.json');selection=load(OUT/'runtime-selection-audit.json');ci=load(OUT/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
assert all(r['passed'] for r in [prep,model,diag,cost,selection])
dense=sum(cost['dense_aggregate_seconds'])/2;screened=sum(cost['screened_aggregate_seconds'])/2
write(OUT/'next-step.json',{'status':'complete_screened_gradient_objective_preflight_required',
'finding':'The shared selector supplies both full four-second optimizer calls inside the existing limits. All evaluations, weights, full runtime scores and six source outputs independently replay, but the original-area winner still has54failed pairs. Read-only profiling and an exact boundary-box kernel diagnostic now expose gradient work; kernel-only timings are not a whole-objective or packing result.',
'proposal':'Version the complete augmented objective to use the strict disjoint-box boundary kernel only after reviewing the retained profile and kernel measurements. Independently verify all original and clearance scores, all81gradient coordinates, positive terms, clipped/coincident counts, auxiliary terms and all three winner streams across original source and closed runtime contexts, including touching/coincident/empty and nonsmooth controls. Measure complete evaluation plus construction costs before any new initializer or finite search. Do not infer a whole-objective saving from kernel timing.',
'requirements':['All23closed objective/physical-mode/weight keys and previous finite pipeline limits remain closed. Code changes or a faster gradient cannot reopen a problem.','Preserve exact original/clearance geometry,528weighted areas,15auxiliary terms,33movers/15angles, coincident-boundary convention, strict1e-6selector improvement, stable sequence/ties and fullsource validation. Omit only strictly disjoint edge/polygon boxes; retain touching and nonfinite-bound cases.','Any future initializer uses only original unoptimized A/W data after exact payload/context checks. Retain39.04916139948182s preparation plus every new source cost. No optimized or validation seed.','Prove complete objective/model equivalence and measure full source/output/startup/optimizer costs before freezing a fresh finite60/90s2GiB attempt; no new objective, initializer or search is prepared by this checkpoint.','H5 still requires full66source validity, native/material evidence, production parity and its original matrix. Four fixed arrangements and440allocation candidates remain unresolved.'],
'closed_problem_keys':23,'source_only_preparation_seconds_before_new_work':front['complete_preparation_seconds'],'diagnostic_boundary_kernel_prepared':True,'complete_screened_objective_prepared':False,'new_source_state_prepared':False,'new_search_contract_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
report=f'''# Shared-selector source construction — 2026-11-07

The fresh finite attempt completes **both four-second optimizer calls** within
the existing budget. Its best original-area candidate still fails **54 source
pairs**, with **{front['best_original']['score_mm2']:,.6f} mm² overlap**. All stock
checks pass. There is no valid full66 layout, native/material result or allocation
exclusion. H2/H5 remain open at **60% completed milestone weight**.

[Source preflight]({NAME}/source-preflight-audit.json) binds the original A/W
payloads and full context, updates exclusions under all twenty-one prior closures,
and reconstructs all 5,911 first-center proposals and 2,854 key minima. Eight
matching closed keys exclude 697 proposals; 99 changed exclusion flags remain
recorded. Ten stale-context/payload rejections, four new key-deadline controls and
three no-candidate policies pass, with unchanged earlier controls inherited.
[Original source domains]({NAME}/inherited-source-domains.json) remain bound.

[The selected model]({NAME}/source-model-controls.json) changes owners
{model['changes']} at source centers {model['source_centers']}. Its 81 coordinates,
33 movers, 15 angles, 528 weighted areas and 15 auxiliary terms read back.
Independent scalar-gradient error is {model['maximum_scalar_gradient_error_mm']:.3e}
across {model['directed_scalar_gradient_terms']} directed terms. The initializer
retains all [66 original parts]({NAME}/initializer-source-controls.json), with 38
failed pairs. No optimized or validation state seeds this model.

The [preparation process]({NAME}/preparation-process.json) adds
{prep['new_source_preparation_seconds']:.6f} s to the retained 37.680691 s, for
**{front['complete_preparation_seconds']:.6f} s**. The [budget estimate]({NAME}/budget-assessment.json)
includes measured model/source costs, prior complete serialization and the prior
3.136244 s first-call startup, plus the observed shared-selector upper time. It
does not guarantee runtime. [The frozen search contract]({NAME}/search-plan.json)
keeps the complete primary tier, two calls maximum, a 52 s selection cutoff and
54 s call boundary to reserve full source checks. Each runtime invocation builds
fresh geometry and shares only exact immutable rows within that invocation.

[Runtime replay]({NAME}/runtime-selection-audit.json) independently checks all
9,102 center scores, 5,911 proposals, 2,854 minima, closure flags, ranks and strict
choice. The full weight/selection/output/model interval is
**{cost['runtime_weight_selection_output_model_interval_seconds']:.6f} s**.
Both call allocations are {cost['optimizer_allocations_seconds']} s.
[Response replay]({NAME}/response-audit.json) verifies all
**{front['total_evaluation_records_verified']} records**, **{front['saved_points_verified']}
saved points**, 528 updated weights and six complete source outputs. The three
winner streams coincide in the first epoch and select three distinct points in
the second. Their original/augmented/unweighted scores and outputs remain separate.
Original-area overlap is lower than the previous attempt but the failed-pair count
is higher (54 versus 51); these different initializers and timed trajectories do
not isolate a causal packing improvement.

Algorithm/shared totals are **{front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s**.
Slice overruns {front['slice_overruns_seconds']} are preserved. All
[five search processes close]({NAME}/closed-search-process.json), with peak memory
{process['job']['peak_job_committed_memory']:,} bytes. Limits remain 60/90 s and 2 GiB.
Twenty-three exact problem keys now remain closed.

[Residual diagnosis]({NAME}/outcome-diagnostic.json) records {diag['positive_area_pairs']}
positive area pairs, {diag['flat_available_pair_gradient_count']} flat available
pair gradients, {diag['bracket_bracket_source_failures']} bracket/bracket failures
and {diag['cog_lower_y_negative_gradient_blocked']} cogs blocked at their lower-y
bound. [Family failures]({NAME}/family-failures.json) remain explicit.

A read-only [profile]({NAME}/objective-profile.json) covers nine exact evaluations
of the three independently audited final winners, with profiler overhead included.
A separate [boundary-kernel diagnostic]({NAME}/boundary-box-controls.json) tests
strict disjoint-box edge filtering across four closed states and both geometry
levels. All gradients, clipped-segment counts and coincident lengths match exactly
in all four dense/screened/screened/dense outputs for each context. Touching boxes
are retained; eight [empty, contained, coincident and touching controls]({NAME}/boundary-policy-controls.json)
also match. Of {cost['total_edges']:,} directed edges, {cost['omitted_edges']:,} have
strictly disjoint boxes. The two aggregate [kernel timing]({NAME}/runtime-costs.json)
means are {dense:.6f} s dense and {screened:.6f} s screened, including kernel input
arrays, bounds, masks and integration. They exclude full objective geometry,
area/auxiliary work and optimizer orchestration. No whole-objective speedup is
claimed; no replacement objective or successor search is prepared.

[Next]({NAME}/next-step.json), independently verify a complete objective using
that kernel, then measure its full costs before any new source initialization.
Four fixed arrangements and all 440 allocation candidates remain unresolved.

The preceding source checkpoints reached main **ddf2310d** after all six prior
checks passed, preserving 52 files; [the receipt]({NAME}/prior-main-push-receipt.json)
is retained. [Current CI]({NAME}/main-ci-at-review.json) has {success} passed and
{live} live jobs at review. This checkpoint and the shared-selector preflight await
the next ordinary push gate. Product code, README and releases are unchanged.

[Archive checks]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical evidence]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the evidence graph.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 shared-selector source construction:** [complete source, runtime and response evidence]({{link}}) verifies a fresh original-source model under21closures,5911primary proposals and2854keys. Full preparation is {front["complete_preparation_seconds"]:.6f}s. Both four-second calls finish within53.529241/53.633280s algorithm/shared totals; the candidate remains invalid with54failed pairs and24134.380631mm² original overlap. All{front["total_evaluation_records_verified"]}records,{front["saved_points_verified"]}saved points,528updated weights,15013runtime scores and six66part outputs replay, including three distinct second-epoch winners. All23keys remain closed. Read-only boundary filtering preserves exact gradients/counts/coincidence across eight runtime contexts and eight synthetic cases; aggregate kernel means are {dense:.6f}s dense/{screened:.6f}s screened, not a whole-objective claim. Next verify the complete objective and full budget before any fresh source model/search. Four arrangements and440allocations remain; H2/H5 stay at60%. Main ddf2310d has{success}passed/{live}live jobs at review. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [shared-selector source construction](../benchmarks/results/{NAME}.md).
The new source initializer and full {front['complete_preparation_seconds']:.6f} s preparation charge pass
independent readback. Both four-second calls finish inside the finite budget;
the best original-area candidate remains invalid with 54 failed pairs and
24,134.380631 mm² overlap. All {front['total_evaluation_records_verified']} records, {front['saved_points_verified']} saved points, 528 updated
weights, 15,013 runtime scores and six full66 outputs replay. The second epoch's
three winner streams remain distinct. All 23 exact problem keys remain closed.
A read-only boundary filter preserves gradients/counts/coincidence in eight
runtime contexts and eight synthetic cases. Kernel means are {dense:.6f}/{screened:.6f} s
dense/screened; next verify full-objective equivalence and costs before any new
initializer or search. Four arrangements and 440 allocations remain; H2/H5 stay
at 60%. Main ddf2310d has {success} passed / {live} live CI jobs at review. Product code,
README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
