"""Freeze a new primary-only search after the independently checked source preflight."""
from pathlib import Path
import ast,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
load=lambda p:json.loads(p.read_bytes())
base=OUT/'h5-shared-source-preflight-20261107'
checked=load(base/'audit/checks.json');assert checked['passed'] and checked['closed_keys']==21
text=(OUT/'run_h5_tiered_source_search_20261107.py').read_text(encoding='utf-8')
changes=[
    ('h5-tiered-source-preflight-20261107','h5-shared-source-preflight-20261107'),
    ("K=ROOT/'benchmarks/results/h5-tiered-selector-preflight-20261107';","K=ROOT/'benchmarks/results/h5-shared-geometry-preflight-20261107';Q=ROOT/'benchmarks/results/h5-tiered-selector-preflight-20261107';Z=ROOT/'output/h5-tiered-source-preflight-20261107';"),
    ('h5_tiered_selection_20261107','h5_shared_geometry_selection_20261107'),
    ('h5_tiered_neighbors_20261107','h5_shared_geometry_neighbors_20261107'),
    ('audit_h5_tiered_source_response_20261107','audit_h5_shared_source_response_20261107'),
    ('run_h5_tiered_source_response_stage_20261107','run_h5_shared_source_response_stage_20261107'),
    ('all19closed','all21closed'),
    ("'timings.json','cost-profile.json','archive-checks.json'","'timings.json','geometry-reuse-controls.json','changed-context-controls.json','archive-checks.json'"),
    ("inputs=[Path(__file__),JOB]","inputs=[Path(__file__),JOB,Q/'cost-profile.json',Z/'outcome-diagnostic/runtime-costs.json']"),
    ("profile=load(K/'cost-profile.json')","profile=load(Q/'cost-profile.json')"),
    ("r['context']=='runtime' and r['kind']=='primary'","r['context'] in ['runtime','latest_runtime'] and r['tier']=='primary' and r['kind']=='shared'"),
    ("+1.\n    assert planned<60","+load(Z/'outcome-diagnostic/runtime-costs.json')['first_call_startup_after_preparation_seconds']\n    assert planned<60"),
    ("'unmeasured_startup_planning_allowance_seconds':1.","'prior_complete_first_call_startup_observed_seconds':load(Z/'outcome-diagnostic/runtime-costs.json')['first_call_startup_after_preparation_seconds'],'serialization_reference':'Earlier runtime primary outputs are unchanged in shared-selector equivalence controls; reuse its complete serialization observation, not a new measurement.'"),
    ('Runtime geometry always recalculates with cached_trials=None.','Runtime geometry recalculates with cached_trials=None, sharing exact immutable raw center rows only within this invocation. Nominal mode, angle and centers remain exact keys; no changed-context reuse or quantization.'),
]
for before,after in changes:
    assert before in text,before
    text=text.replace(before,after)
ast.parse(text)
with (OUT/'run_h5_shared_source_search_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
cost=load(base/'model-and-source-costs.json');timings=load(ROOT/'benchmarks/results/h5-shared-geometry-preflight-20261107/timings.json')
selector=max(r['selector_and_grouping_seconds'] for r in timings if r['context'] in ['runtime','latest_runtime'] and r['tier']=='primary' and r['kind']=='shared')
profile=load(ROOT/'benchmarks/results/h5-tiered-selector-preflight-20261107/cost-profile.json')
serial=next(r for r in profile['profiles'] if r['context']=='runtime-uncached')['serialization']['wall_seconds']
startup=load(OUT/'h5-tiered-source-preflight-20261107/outcome-diagnostic/runtime-costs.json')['first_call_startup_after_preparation_seconds']
planned=checked['complete_preparation_seconds']+8+selector+serial+2*(cost['model_construction_verification_and_serialization_seconds']+3*cost['source_output_and_validation_seconds'])+startup
assert planned<60
print({'preparation_seconds':checked['complete_preparation_seconds'],'selector_observed_upper_seconds':selector,'prior_serialization_seconds':serial,'prior_startup_seconds':startup,'planned_algorithm_seconds':planned,'estimate_guarantees_two_full_slices':False,'search_opened':False})
