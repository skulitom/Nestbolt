"""Replay complete adaptive selection, every evaluation and all source winners."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,time
import numpy as np
from h5_adaptive_augmented_epoch_readback_20261107 import audit_epoch
from h5_tiered_primary_selection_readback_20261107 import verify_selection,independent_classes
from h5_bracket_augmented_reference_20261107 import Reference
from h5_bracket_augmented_objective_20261107 import compile_model
from h5_bracket_augmented_readback_20261107 import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-shared-source-preflight-20261107';S=BASE/'search';OUT=BASE/'response-audit';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def independent_update(before,losses):
    peak=max(losses);out=[]
    for w,a in zip(before,losses):
        if a==0:v=float(F(w)*F(.95))
        else:r=float(F(a)/F(peak));scaled=float(F(.8)*F(r));factor=float(F(1.2)+F(scaled));v=float(F(w)*F(factor))
        out.append(min(64.,max(1.,v)))
    return out
OUT.mkdir();started=time.perf_counter();plan=load(S/'plan.json');result=load(S/'result.json');initial=load(BASE/'selected-state.json');lib=load(A/'library.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');reference=Reference(lib);classes=independent_classes(lib)
inputs=[Path(__file__),S/'budget-assessment.json']+[ROOT/'output'/n for n in ['h5_tiered_primary_key_readback_20261107.py','h5_adaptive_augmented_epoch_readback_20261107.py','h5_tiered_primary_selection_readback_20261107.py','h5_bracket_augmented_reference_20261107.py','h5_bracket_augmented_readback_20261107.py','h5_indexed_two_center_neighbors_20261107.py']]+[S/n for n in ['plan.json','result.json','process.json','job.json','supervisor-opened.json']]+[BASE/n for n in ['plan.json','selected-state.json','selected-model.json','closed-problems.json','audit/plan.json','audit/checks.json']]
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
modes=initial['modes'];values=initial['values'];weights=initial['pair_weights'];old_closed={r['key'] for r in load(BASE/'closed-problems.json')};visited=set(old_closed);assert len(old_closed)==21
epochs=[];summaries=[];best_original=best_unweighted=valid_witness=None;updates=centers=proposals=partial=0;overruns=[]
for epoch,folder in enumerate(sorted(S.glob('epoch-*'))):
    opened=load(folder/'opened.json');assert opened['epoch']==epoch and not opened['runtime_neighbor_cache_used'] and opened['incoming_values']==values and opened['incoming_modes']==modes and opened['weights_before_update']==weights and opened['visited_keys']==sorted(visited);inputs.append(folder/'opened.json');incoming=list(values)
    if epoch:
        transition=load(folder/'weight-transition.json');previous=compile_model(lib,modes,incoming,weights,identity);_,_,details=reference.evaluate(previous,incoming)
        assert transition['before']==weights and transition['source']=='previous_epoch_augmented_best' and transition['auxiliary_excluded_from_weight_update']
        assert np.max(np.abs(np.array(details['pair_losses_mm2'])-transition['pair_losses_mm2']))<1e-7
        assert independent_update(weights,transition['pair_losses_mm2'])==transition['after'];weights=transition['after'];updates+=1;inputs.append(folder/'weight-transition.json')
        if (folder/'incomplete-primary.json').exists():
            from h5_tiered_neighbors_20261107 import primary
            saved=load(folder/'incomplete-primary.json');captured=saved['partial']
            assert saved['status']=='NO_COMPLETE_PRIMARY' and saved['completed_tier'] is None and saved['selected_proposal'] is None and saved['optimizer_calls']==0 and result['status']=='PRIMARY_SELECTION_DEADLINE'
            pool=primary(lib,modes,incoming,weights,identity,regions,visited,deadline=time.perf_counter()+60,cached_trials=None);full=(pool.primary,pool.aliases,pool.trials,pool.selections)
            selection,groups,minima=verify_selection(lib,modes,incoming,weights,identity,regions,visited,*full,OUT/f'epoch-{epoch:02d}-partial-reference');partial+=1
            if captured['status']=='SELECTION_DEADLINE':
                assert not captured['primary_complete'] and captured['primary_records']==[]
                for field,rows in zip(['records','aliases','trials','selections'],full):assert captured[field]==rows[:len(captured[field])]
            else:
                assert captured['status']=='KEY_SELECTION_DEADLINE' and saved['primary']['records']==full[0]
                assert captured['group_members']==({} if captured['checkpoints']==1 else groups) and captured['key_minima']==([] if captured['checkpoints']<3 else minima)
                for field,rows in zip(['aliases','trials','selections'],full[1:]):assert saved[field]==rows
            assert captured['observed']>=captured['deadline'] and captured['overrun_seconds']==captured['observed']-captured['deadline'] and not (folder/'optimizer-opened.json').exists();inputs.append(folder/'incomplete-primary.json');break
        records=load(folder/'neighbors.json');aliases=load(folder/'owner-aliases.json');trials=load(folder/'center-trials.json');selections=load(folder/'center-selections.json')
        selection,groups,minima=verify_selection(lib,modes,incoming,weights,identity,regions,visited,records,aliases,trials,selections,OUT/f'epoch-{epoch:02d}-selection');centers+=len(trials);proposals+=len(records)
        tier=load(folder/'selection-tier.json');assert tier=={'completed_tier':'primary','raw_proposals':5911,'distinct_keys':2854,'extension_attempted':False,'selected_proposal':selection['accepted_choice']}
        inputs+=[folder/n for n in ['neighbors.json','owner-aliases.json','center-trials.json','center-selections.json','selection-tier.json']]
        assert selection==load(folder/'selection.json') and groups==load(folder/'group-members.json') and minima==load(folder/'key-minima.json')
        inputs+=[folder/n for n in ['selection.json','group-members.json','key-minima.json']]
        if not selection['strictly_improves_current']:
            assert result['status']=='NO_IMPROVING_ADMISSIBLE' and not (folder/'optimizer-opened.json').exists();break
        joint=selection['accepted_choice']
        for (i,mi),center in zip(joint['changes'],joint['centers']):modes=modes.copy();modes[i]=mi;incoming[2*i:2*i+2]=center
    if not (folder/'optimizer-opened.json').exists():assert result['status']=='TIME_STOP_BEFORE_CALL';break
    model=load(folder/'model.json');assert verify(model,lib,modes,incoming,weights,identity)
    if epoch==0:assert model==load(BASE/'selected-model.json')
    physical=[classes[f][mi] for (f,_),mi in zip(lib['identities'],modes)];key=sha256(json.dumps({'physical':physical,'weights':weights,'objective_identity':identity},sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest();assert key not in visited
    state={'modes':modes,'values':incoming,'pair_weights':weights,'key':key};checked=audit_epoch(folder,OUT/f'epoch-{epoch:02d}',lib,state,identity,regions,visited);visited.add(key);epochs.append(checked);response=load(folder/'response.json');call=load(folder/'optimizer-opened.json')
    assert response['key']==key and response['allocated_seconds']==call['allocated_seconds']<=4 and response['slice_overrun_seconds']==max(0.,response['returned_seconds']-response['allocated_seconds']) and response['complete_preparation_seconds']==plan['complete_preparation_seconds'];overruns.append(response['slice_overrun_seconds'])
    inputs+=[p for p in folder.rglob('*') if p.is_file()]
    for label,field in [('original','original_overlap_area_mm2'),('unweighted','unweighted_objective_mm2')]:
        r=response['winners'][label];candidate={'epoch':epoch,'label':label,'metric':field,'score_mm2':r[field],'pair_failures':checked['readbacks'][label]['pair_failures'],'source_valid66':checked['readbacks'][label]['source_valid66']}
        if label=='original' and (best_original is None or candidate['score_mm2']<best_original['score_mm2']):best_original=candidate
        if label=='unweighted' and (best_unweighted is None or candidate['score_mm2']<best_unweighted['score_mm2']):best_unweighted=candidate
    if checked['valid_witness'] is not None:valid_witness={'epoch':epoch,**checked['valid_witness']}
    summary={'epoch':epoch,'key':key,'status':response['status'],'function_evaluations':response['function_evaluations'],'saved_points':response['saved_points'],'source_readbacks':response['source_readbacks'],'minimum_weight':min(weights),'maximum_weight':max(weights)};summaries.append(summary);values=response['winners']['augmented']['values']
    print({'epoch_replayed':epoch,'evaluations':checked['records'],'original_source_failures':checked['readbacks']['original']['pair_failures']},flush=True)
assert result['closed'] and len(epochs)==result['optimizer_calls']==result['unique_new_keys']==len(visited)-len(old_closed)<=2 and len(old_closed)==result['historical_closed_keys']==21
assert updates==result['weight_updates'] and centers==result['complete_runtime_centers'] and proposals==result['complete_runtime_proposals'] and summaries==result['epochs'] and best_original==result['best_original'] and best_unweighted==result['best_unweighted'] and valid_witness==result['valid_witness']
assert result['source_valid66']==(valid_witness is not None) and not result['runtime_neighbor_cache_used'] and not result['old_calls_resumed'] and result['native_calls']==0 and not result['any_allocation_excluded'] and not result['H5_complete']
assert result['status'] in ['MAXIMUM_EPOCHS','TIME_STOP_BEFORE_EPOCH','TIME_STOP_AFTER_SOURCE_CHECK','TIME_STOP_BEFORE_CALL','PRIMARY_SELECTION_DEADLINE','NO_IMPROVING_ADMISSIBLE','SOURCE_VALID_CANDIDATE']
if result['status']=='MAXIMUM_EPOCHS':assert len(epochs)==2
if result['status']=='SOURCE_VALID_CANDIDATE':assert valid_witness is not None
if result['status'] in ['PRIMARY_SELECTION_DEADLINE']:assert partial==1
if result['status']=='TIME_STOP_BEFORE_EPOCH':assert result['algorithm_seconds_including_preparation']>=52
if result['status'] in ['TIME_STOP_AFTER_SOURCE_CHECK','TIME_STOP_BEFORE_CALL']:assert result['algorithm_seconds_including_preparation']>=54
process=load(S/'process.json');job=load(S/'job.json');assert process['job']==job and process['closed'] and job['closed'] and process['exit_code']==job['error_code']==job['reason_code']==job['active_processes']==0 and job['peak_job_committed_memory']<2**31
assert result['algorithm_seconds_including_preparation']<=process['seconds_including_preparation']<90 and result['algorithm_seconds_including_preparation']<60 and result['algorithm_overrun_seconds']==0
assert result['complete_preparation_seconds']==plan['complete_preparation_seconds']==load(BASE/'audit/checks.json')['complete_preparation_seconds']
assert plan['neighborhood_tier']==result['neighborhood_tier']=='primary' and plan['extension_attempts']==result['extension_attempts']==0
assert plan['maximum_optimizer_calls']==2 and plan['optimizer_slice_seconds']==4 and plan['source_reserve_boundary_seconds']==54 and plan['selection_boundary_seconds']==52 and plan['algorithm_seconds']==60 and plan['shared_seconds']==90
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Verify every dynamic field and bounded source-only weight update independently. Completely reconstruct every runtime center/proposal score, retained ranking and strict improvement; preserve partial-stop evidence if present. Replay every evaluation and gradient plus scalar source score, all three strict winner streams, every full66 original output and winner scalar gradient. Reconcile global original/unweighted winners, distinct keys, closed calls, source-only preparation, limits and descendant closure. No optimization.'})
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in data.get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings);write(OUT/'epoch-reconciliation.json',epochs)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_bindings':len(bindings),'closed_optimizer_calls':len(epochs),'prior_closed_keys':21,'new_closed_keys':len(epochs),'complete_runtime_center_trials_verified':centers,'complete_runtime_proposals_verified':proposals,'independent_runtime_full_scores':centers+proposals,'partial_selections_verified':partial,'weight_updates_verified':updates,'weight_coefficients_verified':528*updates,'total_evaluation_records_verified':sum(r['records'] for r in epochs),'optimizer_evaluations':sum(r['function_evaluations'] for r in epochs),'saved_points_verified':sum(r['saved_points'] for r in epochs),'source66_readbacks':len(epochs)*3,'distinct_winners_per_epoch':[r['distinct_winners'] for r in epochs],'max_independent_score_error_mm2':max(r['score_error'] for r in epochs),'max_independent_original_error_mm2':max(r['original_error'] for r in epochs),'max_winner_scalar_gradient_error_mm':max(r['gradient_error'] for r in epochs),'best_original':best_original,'best_unweighted':best_unweighted,'source_valid66':valid_witness is not None,'complete_preparation_seconds':plan['complete_preparation_seconds'],'algorithm_seconds':result['algorithm_seconds_including_preparation'],'shared_seconds':process['seconds_including_preparation'],'slice_overruns_seconds':overruns,'all_descendants_closed':True,'runtime_neighbor_cache_used':False,'old_calls_resumed':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False})
print(load(OUT/'checks.json'))
