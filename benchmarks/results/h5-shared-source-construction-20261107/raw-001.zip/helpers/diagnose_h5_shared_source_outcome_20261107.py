"""Read-only family failures, boundary obstruction and residual flat terms."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,time
import numpy as np
from shapely.affinity import translate
from h5_bracket_augmented_objective_20261107 import Objective
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-shared-source-preflight-20261107';V=ROOT/'output/h5-two-center-preflight-20261107';X=ROOT/'output/h5-indexed-source-preflight-20261107';Z=ROOT/'output/h5-tiered-source-preflight-20261107';U=ROOT/'output/h5-current-mode-relocation-preflight-20261107';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';P=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'outcome-diagnostic';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();checked=load(BASE/'response-audit/checks.json');assert checked['passed'] and checked['best_original']['epoch']==1
inputs=[Path(__file__)]+[BASE/n for n in ['response-audit/checks.json','response-audit/epoch-01/original-source-checks.json','search/epoch-01/response.json','search/epoch-01/model.json']]+[A/'objective-identity.json',A/'response-audit/checks.json',N/'response-audit/checks.json',P/'response-audit/checks.json',B/'regions.json',R/'response-audit/checks.json',W/'response-audit/checks.json',Q/'response-audit/checks.json',U/'response-audit/checks.json',V/'response-audit/checks.json',X/'response-audit/checks.json',Z/'response-audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read-only composition of source failures, hard-bound descent obstruction and every positive original/clearance pair gradient in the closed original-area winner. Test only flat pair terms with the earlier fixed±.001/.1/1/5mm feasible translation probes. Compare prior audited outcomes without attributing a causal improvement. No candidate change, new initializer, search or allocation exclusion.','gradient_zero_tolerance':1e-7,'translation_steps_mm':[.001,.1,1.,5.],'optimizer_calls':0})
response=load(BASE/'search/epoch-01/response.json');assert all(v['auxiliary_bracket_depth_mm2']==0 for v in response['source_readbacks'].values());model=load(BASE/'search/epoch-01/model.json');x=response['winners']['original']['values'];gradient=response['winners']['original']['gradient'];source=load(BASE/'response-audit/epoch-01/original-source-checks.json');obj=Objective(model,load(B/'regions.json'),load(A/'objective-identity.json'));shapes=obj.geometry(x);groups=defaultdict(lambda:{'pair_failures':0,'positive_intersections':0,'overlap_mm2':0.})
for pair in source['pairs']:
    if pair['passed']:continue
    group=groups['/'.join(sorted(k[0] for k in pair['keys']))];group['pair_failures']+=1;group['positive_intersections']+=int(pair['intersection_area_mm2']>0);group['overlap_mm2']+=pair['intersection_area_mm2']
owners=[]
for i,o in enumerate(model['owners']):
    axes=[]
    for k in [2*i,2*i+1]:
        lo,hi=model['bounds'][k];bound='lower' if abs(x[k]-lo)<1e-7 else 'upper' if abs(x[k]-hi)<1e-7 else None;gg=gradient[k]
        axes.append({'axis':'x' if k%2==0 else 'y','bound':bound,'gradient':gg,'negative_gradient_blocked':bool((bound=='lower' and gg>1e-8) or (bound=='upper' and gg< -1e-8))})
    owners.append({'owner':i,'identity':o['identity'],'mode':o['mode'],'axes':axes})
positive=[];flat=[]
for index,(i,j) in enumerate(model['pairs']):
    areas=[shapes[k][i][1].intersection(shapes[k][j][1]).area for k in [0,1]];loss=sum(areas)
    if loss<=0:continue
    available=[];gradients=[]
    for own,other in [(i,j),(j,i)]:
        gg=np.zeros(3)
        for k in [0,1]:gg+=moving_boundary_gradient(shapes[k][own][1],shapes[k][other][1],x[2*own:2*own+2])[0]
        gradients.append(gg.tolist());available.extend(gg[:2]);o=model['owners'][own]
        if o['angle_coordinate'] is not None:available.append(gg[2]/o['angle_scale_mm'])
    record={'pair_index':index,'owners':[i,j],'identities':[model['owners'][i]['identity'],model['owners'][j]['identity']],'original_overlap_mm2':areas[0],'pair_area_loss_mm2':loss,'scalar_pair_gradients':gradients,'available_coordinate_gradient_zero':bool(max(abs(z) for z in available)<1e-7)}
    if record['available_coordinate_gradient_zero']:
        probes=[]
        for own,other in [(i,j),(j,i)]:
            for axis in [0,1]:
                k=2*own+axis
                for h in [.001,.1,1.,5.]:
                    for sign in [-1,1]:
                        delta=h*sign
                        if not model['bounds'][k][0]<=x[k]+delta<=model['bounds'][k][1]:continue
                        moved=sum(translate(shapes[level][own][1],xoff=delta if axis==0 else 0,yoff=delta if axis==1 else 0).intersection(shapes[level][other][1]).area for level in [0,1])
                        probes.append({'owner':own,'axis':axis,'delta_mm':delta,'pair_area_loss_mm2':moved,'change_mm2':moved-loss})
        record['probes']=probes;record['all_feasible_probes_flat']=bool(probes) and all(abs(p['change_mm2'])<1e-7 for p in probes);flat.append(record)
    positive.append(record)
comparisons=[]
for name,parent in [('prior_weighted',W),('prior_conditional_relocation',R),('prior_augmented',A),('prior_augmented_conditional',N),('prior_adaptive_augmented',P),('prior_best_admissible',Q),('prior_current_mode',U),('prior_two_center',V),('prior_indexed_source',X),('prior_tiered_source',Z)]:
    prior=load(parent/'response-audit/checks.json');comparisons.append({'prior':name,'prior_pair_failures':prior.get('source_pair_failures',prior.get('best_original_pair_failures',prior.get('best_original',{}).get('pair_failures'))),'current_pair_failures':source['pair_failures'],'prior_original_overlap_mm2':prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'current_original_overlap_mm2':checked['best_original']['score_mm2'],'overlap_change_mm2':checked['best_original']['score_mm2']-prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'comparable_bounded_experiment':False,'packing_improvement_claimed':False})
assert sum(r['pair_failures'] for r in groups.values())==source['pair_failures'] and abs(sum(r['overlap_mm2'] for r in groups.values())-checked['best_original']['score_mm2'])<1e-7
cogs=[o for o in owners if o['identity'][0]=='cog']
write(OUT/'family-failures.json',dict(groups));write(OUT/'owner-bound-controls.json',owners);write(OUT/'positive-pair-gradients.json',positive);write(OUT/'flat-pair-probes.json',flat);write(OUT/'prior-comparisons.json',comparisons)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_pair_failures':source['pair_failures'],'original_overlap_mm2':checked['best_original']['score_mm2'],'positive_area_pairs':len(positive),'flat_available_pair_gradient_count':len(flat),'flat_pairs_with_all_probes_flat':sum(r['all_feasible_probes_flat'] for r in flat),'bounded_translation_probes':sum(len(r['probes']) for r in flat),'auxiliary_bracket_depth_mm2':response['source_readbacks']['original']['auxiliary_bracket_depth_mm2'],'bracket_bracket_source_failures':groups.get('bracket/bracket',{}).get('pair_failures',0),'cog_lower_y_bounds_active':sum(o['axes'][1]['bound']=='lower' for o in cogs),'cog_lower_y_negative_gradient_blocked':sum(o['axes'][1]['bound']=='lower' and o['axes'][1]['negative_gradient_blocked'] for o in cogs),'optimizer_calls':0,'candidate_changed':False,'any_allocation_excluded':False,'H5_complete':False})
print(load(OUT/'checks.json'))





"""Diagnostic snippet appended after the closed outcome and family checks."""
import cProfile,pstats,shapely
from h5_cross_pair_boundary_gradient_20261107 import boundary_gradients
from h5_bbox_boundary_diagnostic_20261107 import screened_boundary_gradients
from shapely.geometry import Polygon

E=BASE/'search/epoch-01';first_call=load(BASE/'search/epoch-00/optimizer-opened.json');call=load(E/'optimizer-opened.json');opened=load(E/'opened.json');result=load(BASE/'search/result.json')
runtime_paths=[Path(__file__),ROOT/'output/h5_bbox_boundary_diagnostic_20261107.py',ROOT/'output/h5_cross_pair_boundary_gradient_20261107.py']+[E/n for n in ['response.json','model.json','opened.json','optimizer-opened.json']]+[BASE/'search/epoch-00/optimizer-opened.json',BASE/'search/result.json',BASE/'response-audit/checks.json']
write(OUT/'runtime-cost-plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in runtime_paths},'method':'Reconcile complete runtime costs and profile nine exact re-evaluations of three independently checked closed winners. Separately compare existing complete boundary kernel to strict disjoint-box edge filtering on each of four closed states and both geometry levels. Fixed dense/screened/screened/dense order, including all array construction/bounds/filtering and integrations. Require exact gradients/counts/coincidence per directed pair; empty, containment, coincident and touching synthetic cases also checked. This is a diagnostic kernel only; no changed objective, source initializer, optimizer or reopened problem.','validation_only':True,'optimizer_calls':0})
prof=cProfile.Profile();prof.enable()
for repeat in range(3):
    for label,r in response['winners'].items():
        score,g,info=obj.evaluate(r['values'],True)
        assert score==r['augmented_objective_mm2'] and np.array_equal(g,r['gradient'])
prof.disable();prof.dump_stats(str(OUT/'objective-profile.prof'));stats=pstats.Stats(prof)
profile=[]
for (filename,line,name),(primitive,total,self_seconds,cumulative,callers) in stats.stats.items():
    profile.append({'file':filename,'line':line,'name':name,'primitive_calls':primitive,'total_calls':total,'self_seconds':self_seconds,'cumulative_seconds':cumulative})
profile.sort(key=lambda r:(-r['self_seconds'],r['file'],r['line']))
write(OUT/'objective-profile.json',{'diagnostic_only':True,'profiled_evaluations':9,'profiler_overhead_included':True,'total_seconds':stats.total_tt,'functions':profile})
controls=[]
for label,point in [('initial',model['initial'])]+[(label,r['values']) for label,r in response['winners'].items()]:
    for level,entries in enumerate(obj.geometry(point)):
        shapes=np.asarray([e[1] for e in entries],dtype=object);areas=shapely.area(shapely.intersection(shapes[obj.left],shapes[obj.right]))
        vertices=[];lines=[];others=[];pivots=[]
        for index in np.flatnonzero(areas>0):
            i,j=model['pairs'][index]
            for own,other in [(i,j),(j,i)]:
                v,poly,ll,pivot=entries[own];vertices.append(v);lines.append(ll);others.append(entries[other][1]);pivots.append(pivot)
        observed=[];times=[]
        for kind in ['dense','screened','screened','dense']:
            before=time.perf_counter();out=(boundary_gradients if kind=='dense' else screened_boundary_gradients)(vertices,lines,others,pivots)
            times.append(time.perf_counter()-before);observed.append(out)
        assert all(all(np.array_equal(a,b) for a,b in zip(observed[0],out)) for out in observed[1:])
        counts={};screened_boundary_gradients(vertices,lines,others,pivots,counts)
        controls.append({'state':label,'level':level,'directed_pairs':len(vertices),**counts,'all_four_outputs_exact':True,'ABBA_complete_kernel_seconds':times})
write(OUT/'boundary-box-controls.json',controls)
def args_for(vertices,other):
    v=np.asarray(vertices,dtype=float).reshape((-1,2));ll=shapely.linestrings(np.stack((v,np.roll(v,-1,axis=0)),axis=1)) if len(v) else np.empty(0,dtype=object)
    return [v],[ll],[other],[[0.,0.]]
square=[[0.,0.],[2.,0.],[2.,2.],[0.,2.]]
cases=[('no_pairs',([],[],[],[])),('no_edges',args_for([],Polygon(square))),('identical',args_for(square,Polygon(square))),('contained',args_for(square,Polygon([[-1,-1],[3,-1],[3,3],[-1,3]]))),('disjoint',args_for(square,Polygon([[3,0],[5,0],[5,2],[3,2]]))),('corner_touch',args_for(square,Polygon([[2,2],[4,2],[4,4],[2,4]]))),('shared_edge',args_for(square,Polygon([[2,0],[4,0],[4,2],[2,2]]))),('zero_length_edge',args_for([[0,0]]+square,Polygon(square)))]
synthetic=[]
for name,args in cases:
    before=boundary_gradients(*args);after=screened_boundary_gradients(*args);assert all(np.array_equal(a,b) for a,b in zip(before,after))
    synthetic.append({'case':name,'exact':True})
write(OUT/'boundary-policy-controls.json',synthetic)
dense=[sum(r['ABBA_complete_kernel_seconds'][i] for r in controls) for i in [0,3]];screened=[sum(r['ABBA_complete_kernel_seconds'][i] for r in controls) for i in [1,2]]
write(OUT/'runtime-costs.json',{'passed':True,'runtime_weight_selection_output_model_interval_seconds':call['algorithm_seconds_including_preparation']-opened['algorithm_seconds_including_preparation'],'first_call_startup_after_preparation_seconds':first_call['algorithm_seconds_including_preparation']-result['complete_preparation_seconds'],'optimizer_allocations_seconds':[first_call['allocated_seconds'],call['allocated_seconds']],'boundary_contexts':len(controls),'directed_pairs':sum(r['directed_pairs'] for r in controls),'total_edges':sum(r['total_edges'] for r in controls),'retained_edges':sum(r['retained_edges'] for r in controls),'omitted_edges':sum(r['omitted_edges'] for r in controls),'dense_aggregate_seconds':dense,'screened_aggregate_seconds':screened,'synthetic_boundary_cases':len(synthetic),'profiled_objective_evaluations':9,'full_objective_speedup_claimed':False,'new_objective_prepared':False,'new_source_state_prepared':False,'optimizer_calls':0,'closed_search_resumed':False,'H5_complete':False})
print(load(OUT/'runtime-costs.json'))
