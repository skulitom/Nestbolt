from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
text=(OUT/'diagnose_h5_tiered_source_outcome_20261107.py').read_text(encoding='utf-8')
text=text[:text.index('# Read-only costs and an exact empty-intersection screen')]
text=text.replace('h5-tiered-source-preflight-20261107','h5-shared-source-preflight-20261107')
text=text.replace("X=ROOT/'output/h5-indexed-source-preflight-20261107';","X=ROOT/'output/h5-indexed-source-preflight-20261107';Z=ROOT/'output/h5-tiered-source-preflight-20261107';")
text=text.replace("X/'response-audit/checks.json']","X/'response-audit/checks.json',Z/'response-audit/checks.json']")
text=text.replace("('prior_indexed_source',X)]","('prior_indexed_source',X),('prior_tiered_source',Z)]")
text+='\n'+(OUT/'h5_shared_source_boundary_diagnosis_20261107.py').read_text(encoding='utf-8')
ast.parse(text)
with (OUT/'diagnose_h5_shared_source_outcome_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
text=(OUT/'run_h5_tiered_source_diagnosis_stage_20261107.py').read_text(encoding='utf-8').replace('h5_tiered_source','h5_shared_source').replace('h5-tiered-source','h5-shared-source')
ast.parse(text)
with (OUT/'run_h5_shared_source_diagnosis_stage_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print('Prepared bounded read-only outcome and boundary-kernel diagnosis.')
