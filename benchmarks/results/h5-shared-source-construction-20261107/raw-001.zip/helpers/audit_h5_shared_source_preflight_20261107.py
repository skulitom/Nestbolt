"""Independently reconcile original-source reuse, closure and fresh model."""
from pathlib import Path
from hashlib import sha256
import copy,json,time
import numpy as np
from h5_indexed_source_cache_20261107 import NAMES,restore,rebind,ClosureDeadline
from h5_tiered_key_choice_20261107 import choose,KeySelectionDeadline
from h5_tiered_primary_key_readback_20261107 import reconstruct_choice
from h5_augmented_selection_score_reference_20261107 import FullScore
from h5_bracket_augmented_reference_20261107 import Reference
from h5_bracket_augmented_objective_20261107 import Objective
from h5_bracket_augmented_readback_20261107 import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-shared-source-preflight-20261107';OUT=BASE/'audit';V=ROOT/'output/h5-two-center-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';P=ROOT/'benchmarks/results/h5-shared-geometry-preflight-20261107'
X=ROOT/'output/h5-tiered-source-preflight-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();plan=load(BASE/'plan.json');prepared=load(BASE/'checks.json');assert prepared['prepared']
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
paths=[Path(__file__),X/'audit/deadline-controls.json',P/'deadline-controls.json',BASE/'model-and-source-costs.json',BASE/'initializer-source66.json',BASE/'initializer-source-checks.json']+[BASE/n for n in ['plan.json','checks.json','source-cache-bindings.json','closed-problems.json','selection.json','group-members.json','key-minima.json','runtime-bindings.json']+list(NAMES)]+[ROOT/'output/h5-shared-source-preparation-process-20261107'/n for n in ['opened.json','process.json']]
paths += [BASE/n for n in ['selected-model.json','selected-state.json'] if (BASE/n).is_file()]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Hash and context bind complete original-source cache, then independently derive first-center membership from exact source center selections. Verify every raw field remains identical except the21-key exclusion flags, reuse the independently reconstructed full source scores with their exact immutable bindings, and independently rebuild every key minimum/selection. Reconstruct the selected model from original A/W state plus selected source centers and independently verify all fields, full source score and scalar gradient. Check six stale contexts, four changed payloads, four new primary key deadlines with inherited unchanged closure/tier deadline evidence and three no-candidate policy cases. All controls are validation-only; no optimization.'})
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');args=[lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions]
old=load(V/'neighbors.json');records=load(BASE/'neighbors.json');closed=load(BASE/'closed-problems.json');expected=load(X/'closed-problems.json')+[load(X/f'search/epoch-{e:02d}/closed-problem.json') for e in [0,1]];assert closed==expected==load(P/'closed-problems.json');keys={r['key'] for r in closed};assert len(keys)==len(closed)==21
payloads={n:(V/n).read_bytes() for n in NAMES};source_audit_plan=load(V/'audit/plan.json');hashes={n:source_audit_plan['inputs'][(V/n).relative_to(ROOT).as_posix()] for n in NAMES};context=load(V/'cache-context.json')['context'];cache_bindings=load(BASE/'source-cache-bindings.json');assert cache_bindings['payload_sha256']==hashes and cache_bindings['source_context']==context
restored=restore(payloads,hashes,context,*args);assert restored[0]==old
for n,values in zip(NAMES[1:],restored[1:]):assert (BASE/n).read_bytes()==(V/n).read_bytes() and values==load(BASE/n)
centers={(r['owner'],r['mode']):r['selected'][0]['center'] for r in restored[3]}
old=[r for r in old if all(c==centers[i,m] for (i,m),c in zip(r['changes'],r['centers']))]
assert len(old)==5911 and [r['sequence'] for r in old]==[r['sequence'] for r in records]
sequences={r['sequence'] for r in old}
flags_changed=[];score_controls=[r for r in load(V/'audit/selection-replay/proposal-score-controls.json') if r['sequence'] in sequences];assert len(old)==len(records)==len(score_controls)==5911
maximum=0.
for a,b,oracle in zip(old,records,score_controls):
    expected_row=a.copy();expected_row['excluded']=a['key'] in keys;expected_row['exclusion_reason']='closed_objective_problem' if expected_row['excluded'] else None;assert b==expected_row
    if a['excluded']!=b['excluded']:flags_changed.append(b['sequence'])
    assert b['key']==sha256(json.dumps({'physical':b['physical_key'],'weights':initial['pair_weights'],'objective_identity':identity},sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    for field in ['augmented_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2','unweighted_objective_mm2']:
        error=abs(b[field]-oracle[field]);maximum=max(maximum,error);assert error<1e-6
selection,groups,minima,controls,near=reconstruct_choice(records,score_controls)
assert selection==load(BASE/'selection.json') and groups==load(BASE/'group-members.json') and minima==load(BASE/'key-minima.json')
write(OUT/'key-minimum-controls.json',controls);write(OUT/'numerical-ties.json',near);write(OUT/'changed-exclusion-sequences.json',flags_changed)
domains=load(V/'audit/inherited-source-domains.json');assert domains['passed'];write(OUT/'inherited-source-domains.json',{'passed':True,'original_source_pool_unchanged':True,'controls':domains['controls'],'inputs':{(V/n).relative_to(ROOT).as_posix():digest(V/n) for n in ['audit/inherited-source-domains.json','audit/selection-replay/checks.json','audit/selection-replay/proposal-score-controls.json','audit/selected-model-controls.json','audit/owner-mode-model-controls.json','audit/deadline-controls.json']}});paths.append(OUT/'inherited-source-domains.json')
model_controls=None;chosen=selection['accepted_choice']
if chosen is not None:
    modes=initial['modes'].copy();values=initial['values'].copy()
    for (i,mi),center in zip(chosen['changes'],chosen['centers']):modes[i]=mi;values[2*i:2*i+2]=center
    model=load(BASE/'selected-model.json');state=load(BASE/'selected-state.json');assert state=={'modes':modes,'values':values,'pair_weights':initial['pair_weights'],'key':chosen['key'],'objective_identity':identity} and chosen['key'] not in keys
    assert verify(model,lib,modes,values,initial['pair_weights'],identity)
    score=FullScore(lib,initial['pair_weights'],regions)(modes,values);actual,gradient,details=Objective(model,regions,identity).evaluate(values,True);rv,rg,rd=Reference(lib).evaluate(model,values,True,details['auxiliary_terms'])
    assert abs(actual-score['augmented_objective_mm2'])<1e-6 and abs(actual-rv)<1e-6 and abs(actual-chosen['augmented_objective_mm2'])<1e-6 and np.max(np.abs(gradient-rg))<1e-6
    from h5_mixed_direct_pose_20261107 import source_rows
    from h5_legacy64_source_readback import audit as source_audit
    rows=load(BASE/'initializer-source66.json');assert rows==source_rows(model,values)
    checked=source_audit(load(JOB),rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])))
    assert checked==load(BASE/'initializer-source-checks.json') and checked['originals']==66 and checked['stock_failures']==0
    write(OUT/'initializer-source-controls.json',{'passed':True,'originals':66,'same_sheet_pairs':checked['same_sheet_pairs'],'stock_edges':checked['stock_edges'],'cutouts':checked['cutouts'],'hole_vertices':checked['hole_vertices'],'pair_failures':checked['pair_failures'],'source_valid66':checked['valid']})
    model_controls={'passed':True,'parameters':81,'movers':33,'continuous_angles':15,'weighted_pairs':528,'auxiliary_pairs':15,'changes':chosen['changes'],'source_centers':chosen['centers'],'key':chosen['key'],'augmented_objective_mm2':actual,'original_overlap_mm2':details['original_overlap_area_mm2'],'maximum_scalar_gradient_error_mm':float(np.max(np.abs(gradient-rg))),'independent_full_score_error_mm2':abs(actual-score['augmented_objective_mm2']),'directed_scalar_gradient_terms':rd['directed_scalar_gradient_terms'],'optimized_ancestor_consumed':False};write(OUT/'selected-model-controls.json',model_controls)
else:assert not (BASE/'selected-state.json').exists() and not (BASE/'selected-model.json').exists()
mutations=[]
for kind,index in [('coordinates',2),('modes',1),('weights',3),('library',0),('identity',4),('regions',5)]:
    varied=copy.deepcopy(args)
    if kind=='coordinates':varied[index][0]+=1
    elif kind=='modes':varied[index][0]=(varied[index][0]+1)%10
    elif kind=='weights':varied[index][0]+=.25
    elif kind=='library':varied[index]['stock_guard_mm']+=.001
    elif kind=='identity':varied[index]['version']+='-stale'
    else:varied[index]['policy']['coefficient']=2.
    try:restore(payloads,hashes,context,*varied)
    except AssertionError:mutations.append({'case':kind,'rejected':True})
    else:raise AssertionError('Stale source context accepted')
for name in NAMES:
    varied=payloads.copy();varied[name]=varied[name]+b' '
    try:restore(varied,hashes,context,*args)
    except AssertionError:mutations.append({'case':name,'rejected':True,'mutation':'changed exact payload bytes'})
    else:raise AssertionError('Changed source payload accepted')
write(OUT/'cache-rejection-controls.json',{'passed':True,'controls':mutations})
class Clock:
    def __init__(self,stop):self.stop=stop;self.calls=0
    def __call__(self):self.calls+=1;return 1. if self.calls>=self.stop else 0.
deadlines=[]
for stop in [1,2,3,4]:
    timer=Clock(stop)
    try:choose(records,'primary',deadline=1.,clock=timer)
    except KeySelectionDeadline as exc:
        e=exc.evidence;assert not e['complete'] and e['selected_proposal'] is None and e['optimizer_calls']==0 and timer.calls==stop and e['group_members']==({} if stop==1 else groups) and e['key_minima']==([] if stop<3 else minima);write(OUT/f'key-deadline-{stop}.json',e);deadlines.append({'kind':'key','stop':stop,'groups':len(e['group_members']),'minima':len(e['key_minima']),'selected_proposal':None})
    else:raise AssertionError('Key deadline failed')
write(OUT/'deadline-controls.json',{'passed':True,'controls':deadlines,'inherited_closure_and_tier_deadlines':{'indexed_source_audit':digest(X/'audit/deadline-controls.json'),'tier_preflight':digest(P/'deadline-controls.json')}})
allclosed=copy.deepcopy(records)
for r in allclosed:r['excluded']=True;r['exclusion_reason']='closed_objective_problem'
c,_,_=choose(allclosed,'primary',deadline=time.perf_counter()+5);assert c['accepted_choice'] is None and c['best_admissible'] is None
zero=copy.deepcopy(records);zero[0]['augmented_objective_mm2']=selection['best_admissible']['augmented_objective_mm2'];c,_,_=choose(zero,'primary',deadline=time.perf_counter()+5);assert c['accepted_choice'] is None
try:choose(records[:-1],'primary',deadline=time.perf_counter()+5)
except AssertionError:pass
else:raise AssertionError('Partial pool selected')
write(OUT/'policy-controls.json',{'passed':True,'all_closed_no_candidate':True,'zero_margin_no_candidate':True,'partial_pool_rejected':True})
prep=load(ROOT/'output/h5-shared-source-preparation-process-20261107/process.json');assert prep['passed'] and prep['closed'] and prep['job']['active_processes']==0
prior=load(X/'audit/checks.json')['complete_preparation_seconds'];assert prior==plan['complete_prior_preparation_seconds']==37.6806913993787;charge=prior+prep['complete_seconds']
queue=paths.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in {**data.get('inputs',{}),**data.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings)
summary={'passed':True,'seconds':time.perf_counter()-start,'source_bindings':len(bindings),'unchanged_source_center_trials':9102,'source_raw_records_verified':len(records),'reused_independent_source_scores':15013,'key_minima_rebuilt':len(minima),'closed_keys':21,'excluded_keys':selection['excluded_keys'],'excluded_raw_proposals':selection['excluded_raw_proposals'],'exclusion_flags_changed':len(flags_changed),'maximum_reused_score_error_mm2':maximum,'numerical_tie_cases_retained':len(near),'fresh_selected_model_verified':model_controls is not None,'strictly_improves_current':chosen is not None,'cache_rejections':len(mutations),'deadline_controls':len(deadlines),'policy_controls':3,'source_domain_controls':domains['controls'],'new_source_preparation_seconds':prep['complete_seconds'],'complete_preparation_seconds':charge,'optimized_ancestor_consumed':False,'validation_outputs_used_as_seed':False,'runtime_geometry_cache_permitted':False,'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',summary);print(summary)
