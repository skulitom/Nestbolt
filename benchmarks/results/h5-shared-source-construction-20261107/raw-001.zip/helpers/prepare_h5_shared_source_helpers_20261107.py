"""Version the fresh source preparation and readbacks without altering old evidence."""
from pathlib import Path
import ast

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output'

def version(old,new,changes):
    text=(OUT/old).read_text(encoding='utf-8')
    for before,after in changes:
        assert before in text,(old,before)
        text=text.replace(before,after)
    ast.parse(text)
    with (OUT/new).open('x',encoding='utf-8',newline='\n') as f:f.write(text)

common=[
    ('h5-tiered-source-preflight-20261107','h5-shared-source-preflight-20261107'),
    ('h5-tiered-selector-preflight-20261107','h5-shared-geometry-preflight-20261107'),
    ('h5-indexed-source-preflight-20261107','h5-tiered-source-preflight-20261107'),
    ('audit_h5_tiered_source_preflight_20261107.py','audit_h5_shared_source_preflight_20261107.py'),
    ('h5-tiered-source-preparation-process-20261107','h5-shared-source-preparation-process-20261107'),
    ("[load(X/'search/epoch-00/closed-problem.json')]","[load(X/f'search/epoch-{e:02d}/closed-problem.json') for e in [0,1]]"),
    ('all19closed','all21closed'),
    ("'closed_keys':19","'closed_keys':21"),
    ('==19','==21'),
]
version('prepare_h5_tiered_source_preflight_20261107.py','prepare_h5_shared_source_preflight_20261107.py',
    [p for p in common if p[0]!='h5-tiered-source-preparation-process-20261107']+[
    ("X/'search/epoch-00/closed-problem.json',P/'cost-profile.json'","X/'search/epoch-00/closed-problem.json',X/'search/epoch-01/closed-problem.json',P/'timings.json',P/'geometry-reuse-controls.json',P/'changed-context-controls.json',P/'twenty-one-key-control.json'"),
    ("'h5_tiered_key_choice_20261107.py',","'h5_shared_geometry_neighbors_20261107.py','h5_shared_geometry_selection_20261107.py','h5_tiered_key_choice_20261107.py',"),
])
version('audit_h5_tiered_source_preflight_20261107.py','audit_h5_shared_source_preflight_20261107.py',
    [p for p in common if p[0] not in ['all19closed','audit_h5_tiered_source_preflight_20261107.py']]+[
    ('the19-key','the21-key'),('36.02814369951375','37.6806913993787'),
])
version('run_h5_tiered_source_stage_20261107.py','run_h5_shared_source_stage_20261107.py',[
    ('h5_tiered_source','h5_shared_source'),('h5-tiered-source','h5-shared-source'),
])
version('audit_h5_tiered_source_response_20261107.py','audit_h5_shared_source_response_20261107.py',[
    ('h5-tiered-source-preflight-20261107','h5-shared-source-preflight-20261107'),
    ('==19','==21'),("'prior_closed_keys':19","'prior_closed_keys':21"),
])
version('run_h5_tiered_source_response_stage_20261107.py','run_h5_shared_source_response_stage_20261107.py',[
    ('h5_tiered_source','h5_shared_source'),('h5-tiered-source','h5-shared-source'),
])
print('Prepared five new source/audit helpers. No source process or search opened.')
