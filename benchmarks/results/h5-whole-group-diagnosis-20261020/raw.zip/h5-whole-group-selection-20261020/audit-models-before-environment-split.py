"""Independent protobuf reconstruction and original geometry checks before solving."""
from pathlib import Path
from itertools import combinations
from datetime import datetime,timezone
from collections import Counter
import gzip,json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from audit_h5_cog_lattices import shape,load,digest,write
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
CENSUS=ROOT/'output/h5-whole-frame-census-20261020';OUT=ROOT/'output/h5-whole-group-selection-20261020'
def main():
    shutil.copyfile(__file__,OUT/'audit-models.py');start=time.perf_counter()
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    mp=load(SRC/'mapping.json');available={r['candidate']:r['compatible_skeletons'] for r in mp['candidates']}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:original=[set(json.loads(l)) for l in f]
    groups=load(CENSUS/'groups.json');cogs=load(SRC/'cog-skeletons.json')['sets']
    warm=set(load(SRC/'selected-indices.json'));geo={};pairs=0;rows_total=0
    def g(i):
        if i not in geo:
            p=pool[i]['placement'];geo[i]=shape(parts[p['part_id']],p['transform'])
        return geo[i]
    def compatible(a,b):
        if pool[a]['placement']['sheet_id']!=pool[b]['placement']['sheet_id']:return True
        nonlocal pairs
        pairs+=1;return g(a).disjoint(g(b)) and g(a).distance(g(b))>=job['clearance']-1e-7
    records=[]
    for row in load(OUT/'prepared.json'):
        dest=OUT/f"case-{row['case']}";m=load(dest/'mapping.json')
        assert digest(dest/'model.pbtxt')==row['model_sha256']
        assert digest(dest/'parameters.pbtxt')==row['parameters_sha256']
        fixed=set(groups[m['frame_group']]['candidates']+cogs[m['cog_group']]['candidates'])
        assert sorted(fixed)==m['fixed_candidates']
        assert Counter(pool[i]['placement']['part_id'] for i in fixed)=={'frame':18,'cog':15}
        assert all(compatible(a,b) for a,b in combinations(sorted(fixed),2))
        blocked=set()
        for clique in original:
            assert len(clique&fixed)<=1
            if clique&fixed:blocked.update(clique-fixed)
        ids=sorted(i for i,options in available.items() if pool[i]['placement']['part_id'] in ['bracket','insert']
                   and m['cog_group'] in options and i not in blocked)
        assert ids==m['candidates']
        # Recheck original filled-outer clearance for every survivor against every fixed part.
        assert all(compatible(a,b) for a in ids for b in sorted(fixed))
        local={i:j for j,i in enumerate(ids)}
        projected=sorted({tuple(sorted(c&local.keys())) for c in original if len(c&local.keys())>1})
        with gzip.open(dest/'cliques.jsonl.gz','rt',encoding='utf-8') as f:assert projected==[tuple(json.loads(l)) for l in f]
        proto=text_format.Parse((dest/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
        expected=cp_model_pb2.CpModelProto()
        for i in ids:
            v=expected.variables.add();v.name=f'p{i}';v.domain.extend([0,1])
        for clique in projected:
            c=expected.constraints.add();c.at_most_one.literals.extend(local[i] for i in clique)
        br=[local[i] for i in ids if pool[i]['placement']['part_id']=='bracket']
        ins=[local[i] for i in ids if pool[i]['placement']['part_id']=='insert']
        c=expected.constraints.add().linear;c.vars.extend(br);c.coeffs.extend([1]*len(br));c.domain.extend([12,12])
        c=expected.constraints.add().linear;c.vars.extend(ins);c.coeffs.extend([1]*len(ins));c.domain.extend([-(2**63),21])
        expected.objective.vars.extend(ins);expected.objective.coeffs.extend([-1]*len(ins));expected.objective.scaling_factor=-1
        should_hint=fixed<=warm and warm-fixed<=local.keys()
        assert m['complete_hint']==should_hint
        if should_hint:
            expected.solution_hint.vars.extend(range(len(ids)))
            expected.solution_hint.values.extend(int(i in warm) for i in ids)
            assert Counter(pool[i]['placement']['part_id'] for i in warm-fixed)=={'bracket':12,'insert':13}
            assert all(len(set(c)&warm)<=1 for c in projected)
        assert proto.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True),row['case']
        rows_total+=len(projected);records.append({'case':row['case'],'variables':len(ids),'cliques':len(projected),
            'model_exactly_reconstructed':True,'complete_hint':should_hint,'model_sha256':row['model_sha256']})
    check={'verified_utc':datetime.now(timezone.utc).isoformat(),'seconds':time.perf_counter()-start,
        'all_six_models_reconstructed_in_full':True,'original_filled_outer_pairs_checked':pairs,
        'source_conflict_clique_projection_exact':True,'total_projected_cliques':rows_total,'cases':records,
        'full_target_witness':False,'native_margin_qualified':False}
    write(OUT/'model-audit.json',check);print(json.dumps(check),flush=True)
if __name__=='__main__':main()
