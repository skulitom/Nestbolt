"""Reconstruct branching and quota propagation independently with explicit sets."""
from pathlib import Path
from collections import Counter
import gzip,json,shutil
import numpy as np
import solve_h5_area_relaxations as base
ROOT=base.ROOT;RUN=ROOT/'output/h5-lp-guided-diving-20261020'
SRC=ROOT/'output/h5-skeleton-contact-selection-20261020';CAP=base.OUT
CASES=ROOT/'output/h5-area-cog-conditioned-20261020'
load=base.load;write=base.write;digest=base.digest
def main():
    OUT=RUN/'audit';OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    plan=load(RUN/'plan.json');result=load(RUN/'result.json');trace=load(RUN/'trace.json')
    for p,h in plan['inputs'].items():assert digest(ROOT/p)==h
    mp=load(SRC/'mapping.json');pool=load(SRC/'candidates.json');job=load(SRC/'job.json')
    vi={r['candidate']:r['var'] for r in mp['candidates']};inverse={v:i for i,v in vi.items()}
    families={f:{v for v,i in inverse.items() if pool[i]['placement']['part_id']==f} for f in ['frame','bracket','insert']}
    quotas={p['id']:p['quantity'] for p in job['parts'] if p['id']!='cog'}
    cliques=[];owners={v:[] for v in inverse}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            group={vi[i] for i in json.loads(line)};ci=len(cliques);cliques.append(group)
            for v in group:owners[v].append(ci)
    def propagate(selected,excluded):
        selected=set(selected);excluded=set(excluded)
        while True:
            if selected&excluded:return selected,excluded,'selected-and-excluded'
            before=(set(selected),set(excluded))
            for v in selected:
                for ci in owners[v]:excluded.update(cliques[ci]-{v})
            if selected&excluded:return selected,excluded,'selected-conflict'
            for f,group in families.items():
                count=len(selected&group);available=group-selected-excluded;need=quotas[f]-count
                if need<0:return selected,excluded,'over-quantity-'+f
                if len(available)<need:return selected,excluded,'insufficient-available-'+f
                if need==0:excluded.update(available)
                elif len(available)==need:selected.update(available)
            if before==(selected,excluded):return selected,excluded,None
    def branch(x,selected,excluded):
        for f,group in families.items():
            if len(selected&group)<quotas[f]:
                return min(group-selected-excluded,key=lambda v:(-float(x[v]),v))
        return None
    obj=load(CAP/'objective.json');ub=base.rows(CAP/'inequalities.jsonl.gz')+base.rows(CAP/'area-cuts.jsonl.gz')
    eq=base.rows(CAP/'equalities.jsonl.gz');change=load(RUN/'model-change.json')['only_row_rhs_change']
    assert ub[change['row']]['kind']=='minimum-inserts' and ub[change['row']]['rhs']==change['before']==-13 and change['after']==-21
    ub[change['row']]['rhs']=-21
    A=base.matrix(ub,len(obj));E=base.matrix(eq,len(obj));b=np.array([r['rhs'] for r in ub]);d=np.array([r['rhs'] for r in eq])
    stacks=[]
    for si in range(4):
        excluded={r['var'] for r in mp['candidates'] if si not in r['compatible_skeletons']}
        selected,excluded,error=propagate(set(),excluded);assert error is None
        assert sorted(excluded)==load(RUN/'prepared.json')['root_exclusions'][si]
        x=np.load(CASES/f'case-{si}/solution.npz')['x'];v=branch(x,selected,excluded)
        root={'case':si,'parent':f'root-{si}','ones':sorted(selected),'zeros':sorted(excluded)}
        stacks.append([{**root,'decision':[v,0]},{**root,'decision':[v,1]}])
    turn=0;lp_calls=0;optimal=0;max_ineq=0.;max_eq=0.;max_bound=0.;counts=Counter();all_frames=[]
    for index,saved in enumerate(trace):
        while not stacks[turn%4]:turn+=1
        si=turn%4;turn+=1;expected=stacks[si].pop()
        path=RUN/'nodes'/f'{index:04d}';state=load(path/'state.json');record=load(path/'result.json')
        assert record==saved and state['node']==saved['node']==index and state['case']==si
        assert state['parent']==expected['parent'] and state['decision']==expected['decision']
        assert state['parent_ones']==expected['ones'] and state['parent_zeros']==expected['zeros']
        selected=set(expected['ones']);excluded=set(expected['zeros']);v,value=expected['decision']
        (selected if value else excluded).add(v)
        selected,excluded,error=propagate(selected,excluded)
        assert sorted(selected)==state['fixed_ones'] and sorted(excluded)==state['fixed_zeros'] and state['propagation_error']==error
        assert state['basis_reused']==isinstance(expected['parent'],int)
        counts[record['status']]+=1;all_frames.append({f:len(selected&group) for f,group in families.items()})
        if error:
            assert record['status']=='propagation-rejection' and record['reason']==error
            assert not (path/'solution.npz').exists();continue
        lp_calls+=1
        assert record['selected_counts']=={f:count for f,count in all_frames[-1].items() if count}
        assert record['cumulative_solver_after']>=record['cumulative_solver_before']
        assert 0<record['LP_allowance_seconds']<=10
        if record['status']=='HighsModelStatus.kOptimal':
            optimal+=1;x=np.load(path/'solution.npz')['x']
            assert len(x)==len(obj) and all(abs(x[j]-int(si==j))<1e-7 for j in range(4))
            lower=np.zeros(len(obj));upper=np.ones(len(obj));lower[list(selected)]=1;upper[list(excluded)]=0
            max_ineq=max(max_ineq,float(np.max(A@x-b)));max_eq=max(max_eq,float(np.max(abs(E@x-d))))
            max_bound=max(max_bound,float(np.max(lower-x)),float(np.max(x-upper)))
            assert abs(-np.dot(obj,x)-record['objective_inserts'])<1e-6
            fractional=int(np.count_nonzero((x>1e-7)&(x<1-1e-7)))
            assert fractional==record['fractional_variables'] and fractional>0
            split=branch(x,selected,excluded);assert split==record['next_branch_variable']
            child={'case':si,'parent':index,'ones':sorted(selected),'zeros':sorted(excluded)}
            stacks[si].extend([{**child,'decision':[split,0]},{**child,'decision':[split,1]}])
        else:
            assert record['status'] in ['HighsModelStatus.kInfeasible','HighsModelStatus.kTimeLimit']
            assert not (path/'solution.npz').exists()
    frontier=[node for stack in stacks for node in stack]
    assert frontier==load(RUN/'frontier.json') and len(frontier)==result['unvisited_frontier']
    assert len(trace)==result['visited_nodes'] and lp_calls==result['LP_calls']
    assert max_ineq<1e-5 and max_eq<1e-5 and max_bound<1e-6
    assert result['improved_partials']==0 and not list((RUN/'partials').iterdir()) and not result['full_inventory_candidate']
    initial=load(RUN/'initial-partial.json')
    assert initial['indices']==load(SRC/'selected-indices.json') and initial['filled_area_mm2']==result['best_filled_area_mm2']
    depth={si:max(r['frame'] for r,s in zip(all_frames,trace) if s['case']==si) for si in range(4)}
    check={'all_visited_states_and_decisions_verified':True,'set_based_clique_quota_propagation_exact':True,
        'round_robin_depth_first_order_verified':True,'saved_fractional_primal_vectors_checked':optimal,
        'statuses':dict(counts),'LP_calls':lp_calls,'basis_reused_calls':sum(r.get('basis_reused',False) for r in trace),
        'maximum_inequality_violation':max_ineq,'maximum_equality_violation':max_eq,'maximum_fixed_bound_violation':max_bound,
        'maximum_selected_frames_by_case':depth,'any_bracket_or_insert_branch_reached':any(r['bracket'] or r['insert'] for r in all_frames),
        'unvisited_frontier_preserved':len(frontier),'seconds':result['seconds'],'no_improved_partial':True,
        'initial_partial_exactly_preserved':True,'full_target_witness':False,'native_packing_calls':0,'quality_runs':0,
        'interpretation':'Restricted LP infeasibility reports are preserved, not promoted to independently certified unrestricted infeasibility. The unfinished frontier remains unsearched; no suffix retry.'}
    write(OUT/'checks.json',check);print(json.dumps(check),flush=True)
if __name__=='__main__':main()
