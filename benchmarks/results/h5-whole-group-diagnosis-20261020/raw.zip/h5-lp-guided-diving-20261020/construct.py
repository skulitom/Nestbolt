"""Bounded binary diving over original poses, retaining each branch and LP state."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import copy,gzip,json,math,shutil,time
import numpy as np
from scipy.sparse import vstack,csr_matrix,csc_matrix
from scipy.optimize._highspy import _core as high
import solve_h5_area_relaxations as base
ROOT=base.ROOT;CAP=base.OUT;SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
CASES=ROOT/'output/h5-area-cog-conditioned-20261020'
OUT=ROOT/'output/h5-lp-guided-diving-20261020'
load=base.load;write=base.write;digest=base.digest

def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py')
    inputs=[CAP/n for n in ['plan.json','preparation.json','translation-audit.json','result-audit.json',
        'inequalities.jsonl.gz','equalities.jsonl.gz','area-cuts.jsonl.gz','objective.json']]
    inputs += [SRC/n for n in ['job.json','candidates.json','mapping.json','cog-skeletons.json','projected-cliques.jsonl.gz',
        'selected-indices.json','audit/checks.json','conditional-target.json']]
    inputs += [CASES/f'case-{s}/solution.npz' for s in range(4)]
    inputs += [ROOT/'output/h5-highs-basis-probe-20261020/checks.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'global_search_seconds_limit':120,'per_LP_seconds_limit':10,'maximum_visited_nodes':512,
        'workers':8,'seed':0,'case_order':[0,1,2,3],
        'method':'Round-robin depth-first binary diving over the four complete original cog arrangements. Reuse each saved fractional root without solving it again. Require exactly 21 inserts, 18 frames and 12 brackets. At each node propagate original conflict cliques and family quotas, record all fixed variables, and solve only the changed restricted LP. Preserve the parent basis for child reoptimization. Branch on the highest-valued still-available pose in the first unfinished family: frame, bracket, insert; ties use variable index. Visit the one branch before the zero branch. Save every LP and every propagation rejection; no suffix retry.',
        'acceptance':'A fractional solution is never a layout. An integral candidate must satisfy every original model row exactly before independent original-geometry and frozen-CLI checks. Save any larger filled-area physical partial separately, without original quantity credit. Infeasible or expired restricted branches do not prove the unrestricted job impossible.',
        'solver':'Existing SciPy embedded HiGHS 1.12.0; no package installation or product dependency change.',
        'basis_probe':str(inputs[-1].relative_to(ROOT)),
        'API_reference':'https://ergo-code.github.io/HiGHS/dev/guide/further/#Hot-start',
        'native_packing_calls':0,'quality_runs':0})
    for name,h in load(CAP/'preparation.json')['prepared_hashes'].items():assert digest(CAP/name)==h
    assert load(CAP/'result-audit.json')['exact_certificates_independently_reconstructed']==6
    job=load(SRC/'job.json');pool=load(SRC/'candidates.json');mp=load(SRC/'mapping.json');sets=load(SRC/'cog-skeletons.json')['sets']
    inverse={r['var']:r['candidate'] for r in mp['candidates']};vi={v:k for k,v in inverse.items()}
    obj=load(CAP/'objective.json');n=len(obj);allvars=np.arange(n,dtype=np.int32)
    ub=base.rows(CAP/'inequalities.jsonl.gz')+base.rows(CAP/'area-cuts.jsonl.gz');eq=base.rows(CAP/'equalities.jsonl.gz')
    changed=[]
    for ri,row in enumerate(ub):
        if row['kind']=='minimum-inserts':
            assert row['rhs']==-13;row['rhs']=-21;changed.append(ri)
    assert len(changed)==1
    A=base.matrix(ub,n);E=base.matrix(eq,n);matrix=vstack([A,E],format='csr')
    b=np.asarray([r['rhs'] for r in ub],dtype=float);d=np.asarray([r['rhs'] for r in eq],dtype=float)
    rowlo=np.r_[np.full(len(ub),-high.kHighsInf),d];rowhi=np.r_[b,d]
    costs=np.asarray(obj,dtype=float);family={v:pool[i]['placement']['part_id'] for v,i in inverse.items()}
    order=['frame','bracket','insert'];quotas={p['id']:p['quantity'] for p in job['parts'] if p['id']!='cog'}
    masks={f:sum(1<<v for v in inverse if family[v]==f) for f in order}
    adjacent=[0]*n;cliques=[]
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            vs=[vi[i] for i in json.loads(line)];mask=sum(1<<v for v in vs);cliques.append(vs)
            for v in vs:adjacent[v]|=mask^(1<<v)
    write(OUT/'model-change.json',{'parent_model':str(CAP.relative_to(ROOT)),'only_row_rhs_change':{'row':changed[0],'before':-13,'after':-21},
        'variables':n,'inequalities':len(ub),'equalities':len(eq),'cliques':len(cliques),'family_quotas':quotas})
    original=high.HighsLp();original.num_col_=n;original.num_row_=len(rowhi)
    original.col_cost_=costs;original.col_lower_=np.zeros(n);original.col_upper_=np.ones(n)
    original.row_lower_=rowlo;original.row_upper_=rowhi
    original.a_matrix_.format_=high.MatrixFormat.kRowwise
    original.a_matrix_.start_=matrix.indptr.astype(np.int32);original.a_matrix_.index_=matrix.indices.astype(np.int32)
    original.a_matrix_.value_=matrix.data
    (OUT/'nodes').mkdir();(OUT/'partials').mkdir()
    initial=load(SRC/'selected-indices.json')
    best_area=sum(pool[i]['filled_area_mm2'] for i in initial);partials=[]
    write(OUT/'initial-partial.json',{'indices':initial,'filled_area_mm2':best_area,'missing':{'insert':8}})

    def propagate(ones,zeros):
        while True:
            if ones&zeros:return ones,zeros,'selected-and-excluded'
            before=(ones,zeros)
            for v in bits(ones):zeros|=adjacent[v]
            if ones&zeros:return ones,zeros,'selected-conflict'
            for f in order:
                selected=(ones&masks[f]).bit_count();available=masks[f]&~zeros&~ones;needed=quotas[f]-selected
                if needed<0:return ones,zeros,'over-quantity-'+f
                if available.bit_count()<needed:return ones,zeros,'insufficient-available-'+f
                if needed==0:zeros|=available
                elif available.bit_count()==needed:ones|=available
            if before==(ones,zeros):return ones,zeros,None

    def branch(x,ones,zeros):
        for f in order:
            if (ones&masks[f]).bit_count()<quotas[f]:
                available=list(bits(masks[f]&~ones&~zeros))
                assert available
                return max(available,key=lambda v:(float(x[v]),-v))
        return None

    def save_partial(si,ones,node_id):
        nonlocal best_area
        ids=sorted(sets[si]['candidates']+[inverse[v] for v in bits(ones)])
        area=sum(pool[i]['filled_area_mm2'] for i in ids)
        if area<=best_area+1e-6:return
        counts=Counter(pool[i]['placement']['part_id'] for i in ids)
        record={'index':len(partials),'node':node_id,'case':si,'indices':ids,'counts':dict(counts),'filled_area_mm2':area,
            'full_inventory_candidate':all(counts[p['id']]==p['quantity'] for p in job['parts'])}
        write(OUT/'partials'/f"{record['index']}.json",record);partials.append(record);best_area=area

    contexts=[]
    for si in range(4):
        h=high._Highs()
        for key,value in [('output_flag',False),('threads',8),('random_seed',0),('solver','simplex'),
                          ('log_file',str(OUT/f'case-{si}.log'))]:
            assert h.setOptionValue(key,value)==high.HighsStatus.kOk
        assert h.passModel(original)==high.HighsStatus.kOk
        passed=h.getLp()
        assert np.array_equal(passed.col_cost_,costs) and np.array_equal(passed.row_lower_,rowlo) and np.array_equal(passed.row_upper_,rowhi)
        sm=passed.a_matrix_
        actual=(csr_matrix if sm.format_==high.MatrixFormat.kRowwise else csc_matrix)((sm.value_,sm.index_,sm.start_),shape=matrix.shape)
        assert (actual.tocsr()!=matrix).nnz==0
        x=np.load(CASES/f'case-{si}/solution.npz')['x']
        assert np.max(A@x-b)<1e-5 and np.max(abs(E@x-d))<1e-5
        zeros=sum(1<<r['var'] for r in mp['candidates'] if si not in r['compatible_skeletons'])
        ones,zeros,error=propagate(0,zeros);assert error is None
        v=branch(x,ones,zeros);assert v is not None
        root={'case':si,'parent':f'root-{si}','ones':ones,'zeros':zeros,'basis':None}
        stack=[{**root,'decision':[v,0]},{**root,'decision':[v,1]}]
        contexts.append({'solver':h,'stack':stack,'root_zeros':list(bits(zeros))})
    write(OUT/'prepared.json',{'all_four_solver_models_exact':True,'source_fractional_roots_feasible':True,
        'highs_version':contexts[0]['solver'].version(),'root_exclusions':[c['root_zeros'] for c in contexts]})
    started=time.perf_counter();visited=0;solved=0;records=[];full=False;turn=0;time_expired=False
    while visited<512 and any(c['stack'] for c in contexts):
        remaining=120-(time.perf_counter()-started)
        if remaining<=0:time_expired=True;break
        si=turn%4;turn+=1;context=contexts[si]
        if not context['stack']:continue
        node=context['stack'].pop();node_id=visited;visited+=1
        path=OUT/'nodes'/f'{node_id:04d}';path.mkdir()
        v,value=node['decision'];ones=node['ones']|((1<<v) if value else 0);zeros=node['zeros']|((1<<v) if not value else 0)
        ones,zeros,error=propagate(ones,zeros)
        state={'node':node_id,'case':si,'parent':node['parent'],'decision':[v,value],
            'parent_ones':list(bits(node['ones'])),'parent_zeros':list(bits(node['zeros'])),
            'fixed_ones':list(bits(ones)),'fixed_zeros':list(bits(zeros)),'propagation_error':error,
            'basis_reused':node['basis'] is not None}
        write(path/'state.json',state)
        if error:
            record={'node':node_id,'case':si,'status':'propagation-rejection','reason':error}
            write(path/'result.json',record);records.append(record);continue
        save_partial(si,ones,node_id)
        lower=np.zeros(n);upper=np.ones(n)
        for j in range(4):lower[j]=upper[j]=int(j==si)
        lower[list(bits(ones))]=1;upper[list(bits(zeros))]=0
        h=context['solver'];assert h.changeColsBounds(n,allvars,lower,upper)==high.HighsStatus.kOk
        if node['basis'] is not None:assert h.setBasis(node['basis'])==high.HighsStatus.kOk
        allowance=min(10.,max(.001,120-(time.perf_counter()-started)))
        clock_before=h.getRunTime();assert h.setOptionValue('time_limit',clock_before+allowance)==high.HighsStatus.kOk
        node_started=time.perf_counter();run_status=h.run();duration=time.perf_counter()-node_started;solved+=1
        status=h.getModelStatus();info=h.getInfo();solution=h.getSolution()
        record={'node':node_id,'case':si,'status':str(status),'run_status':str(run_status),'seconds':duration,
            'LP_allowance_seconds':allowance,'cumulative_solver_before':clock_before,'cumulative_solver_after':h.getRunTime(),
            'simplex_iterations':info.simplex_iteration_count,'selected_counts':dict(Counter(family[v] for v in bits(ones))),
            'basis_reused':node['basis'] is not None}
        if status==high.HighsModelStatus.kOptimal:
            x=np.asarray(solution.col_value,dtype=float)
            np.savez_compressed(path/'solution.npz',x=x,row_dual=np.asarray(solution.row_dual,dtype=float))
            assert np.max(A@x-b)<1e-5 and np.max(abs(E@x-d))<1e-5 and np.max(lower-x)<1e-6 and np.max(x-upper)<1e-6
            record['objective_inserts']=-float(costs@x)
            fractional=np.flatnonzero((x>1e-7)&(x<1-1e-7));record['fractional_variables']=len(fractional)
            if not len(fractional):
                rounded=np.rint(x).astype(np.int64)
                assert np.all(A@rounded<=b) and np.all(E@rounded==d)
                complete=sum(1<<v for v in inverse if rounded[v])
                assert all(not(adjacent[v]&complete) for v in bits(complete))
                save_partial(si,complete,node_id);full=True
                record['integral_candidate']=True
            else:
                split=branch(x,ones,zeros);assert split is not None
                child={'case':si,'parent':node_id,'ones':ones,'zeros':zeros,'basis':h.getBasis()}
                assert child['basis'].valid
                context['stack'].extend([{**child,'decision':[split,0]},{**child,'decision':[split,1]}])
                record['next_branch_variable']=split
        write(path/'result.json',record);records.append(record)
        if solved%8==0 or full:print(json.dumps({'visited':visited,'LPs':solved,'seconds':time.perf_counter()-started,
            'best_filled_area_mm2':best_area,'improved_partials':len(partials),'full_candidate':full}),flush=True)
        if full:break
    elapsed=time.perf_counter()-started
    frontier=[{'case':si,'parent':s['parent'],'decision':s['decision'],'ones':list(bits(s['ones'])),'zeros':list(bits(s['zeros']))}
        for si,c in enumerate(contexts) for s in c['stack']]
    write(OUT/'frontier.json',frontier);write(OUT/'trace.json',records)
    result={'seconds':elapsed,'visited_nodes':visited,'LP_calls':solved,'case_nodes':dict(Counter(r['case'] for r in records)),
        'time_limit_reached':time_expired or elapsed>=120,'node_limit_reached':visited>=512,'unvisited_frontier':len(frontier),
        'improved_partials':len(partials),'best_filled_area_mm2':best_area,'full_inventory_candidate':full,
        'full_target_witness':False,'native_margin_qualified':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        import traceback
        if OUT.exists() and not (OUT/'failure.txt').exists():
            (OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
