from pathlib import Path
import json,time
import numpy as np
from scipy.optimize._highspy import _core as high
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-highs-basis-probe-20261020'
OUT.mkdir()
h=high._Highs()
assert h.setOptionValue('output_flag',False)==high.HighsStatus.kOk
lp=high.HighsLp();lp.num_col_=2;lp.num_row_=1
lp.col_cost_=np.array([-1.,-1.]);lp.col_lower_=np.zeros(2);lp.col_upper_=np.ones(2)
lp.row_lower_=np.array([-high.kHighsInf]);lp.row_upper_=np.array([1.5])
lp.a_matrix_.format_=high.MatrixFormat.kRowwise
lp.a_matrix_.start_=np.array([0,2],dtype=np.int32)
lp.a_matrix_.index_=np.array([0,1],dtype=np.int32);lp.a_matrix_.value_=np.ones(2)
assert h.passModel(lp)==high.HighsStatus.kOk
records=[]
for upper in [1.,0.,1.]:
    assert h.changeColsBounds(1,np.array([0],dtype=np.int32),np.array([0.]),np.array([upper]))==high.HighsStatus.kOk
    before=h.getRunTime();started=time.perf_counter()
    assert h.run()==high.HighsStatus.kOk
    records.append({'x0_upper':upper,'objective':h.getInfo().objective_function_value,
        'x':list(h.getSolution().col_value),'basis_valid':h.getBasis().valid,
        'runtime_before':before,'runtime_after':h.getRunTime(),'wall':time.perf_counter()-started})
    assert abs(h.getInfo().objective_function_value-(-1 if upper==0 else -1.5))<1e-9
assert all(r['basis_valid'] and r['runtime_after']>=r['runtime_before'] for r in records)
with (OUT/'checks.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'highs_version':h.version(),'method':'embedded SciPy HiGHS, exact tiny LP; change bounds and retain basis','records':records},f,indent=2);f.write('\n')
print(json.dumps(records))
