"""Review retained whole-frame groups against the four existing cog groups."""
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime, timezone
from itertools import combinations
import json, gzip, shutil, time
from audit_h5_cog_lattices import shape, load, digest, write
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
COORD=ROOT/'output/h5-coordinated-placement-selection-20261018'
OUT=ROOT/'output/h5-whole-frame-census-20261020'

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'census.py');started=time.perf_counter()
    inputs=[COORD/'source-events.json',COORD/'plan.json',COORD/'audit/checks.json',
        SRC/'job.json',SRC/'candidates.json',SRC/'mapping.json',SRC/'cog-skeletons.json',
        SRC/'projected-cliques.jsonl.gz',SRC/'conditional-target.json',SRC/'selected-indices.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'method':'Enumerate every complete 18-frame set in the retained source events, deduplicating exact candidate indices. Check original filled-outer geometry and all frame/cog group pairs. For each compatible pair, count surviving bracket/insert candidates after original conflict-clique exclusions. No placement generation or solver run.',
        'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    mapping={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    raw=defaultdict(list);events=load(COORD/'source-events.json')
    for e in events:
        i=e['candidate_index'];p=pool[i]['placement'];s=e['source']
        if p['part_id']!='frame':continue
        key=s['path'] if s['kind']=='coordinated-layout' else 'row-frame:'+str(s['frame'])
        raw[key].append(i)
    unique={};rejected=[]
    for key,indices in raw.items():
        if len(indices)!=18 or len(set(indices))!=18:
            rejected.append({'source':key,'count':len(indices),'distinct':len(set(indices))});continue
        unique.setdefault(tuple(sorted(indices)),[]).append(key)
    groups=[{'index':j,'candidates':list(indices),'sources':sources}
            for j,(indices,sources) in enumerate(unique.items())]
    geoms={}
    def geom(i):
        if i not in geoms:
            p=pool[i]['placement'];geoms[i]=shape(parts[p['part_id']],p['transform'])
        return geoms[i]
    def same(i,j):return pool[i]['placement']['sheet_id']==pool[j]['placement']['sheet_id']
    clearance=job['clearance'];tol=1e-7
    stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance']
    target=load(SRC/'conditional-target.json')['required_used_height_mm']
    internal=0;cross=0;min_distance=float('inf')
    for g in groups:
        for i in g['candidates']:
            p=pool[i]['placement'];assert p['part_id']=='frame'
            x0,y0,x1,y1=geom(i).bounds
            top=stock['height'] if p['sheet_id']=='sheet-0' else target
            assert x0>=m['left']+edge-tol and y0>=m['bottom']+edge-tol
            assert x1<=stock['width']-m['right']-edge+tol and y1<=top-m['top']-edge+tol
        for a,b in combinations(g['candidates'],2):
            if same(a,b):
                internal+=1;distance=geom(a).distance(geom(b));min_distance=min(min_distance,distance)
                assert geom(a).intersection(geom(b)).area<1e-7 and distance>=clearance-tol
    cogsets=load(SRC/'cog-skeletons.json')['sets'];pair_results=[]
    for g in groups:
        for cog in cogsets:
            conflicts=[]
            for a in g['candidates']:
                for b in cog['candidates']:
                    if same(a,b):
                        cross+=1
                        if not geom(a).disjoint(geom(b)) or geom(a).distance(geom(b))<clearance-tol:
                            conflicts.append([a,b])
            from_mapping=all(i in mapping and cog['index'] in mapping[i]['compatible_skeletons'] for i in g['candidates'])
            assert from_mapping==(not conflicts)
            pair_results.append({'frame_group':g['index'],'cog_group':cog['index'],
                'compatible':not conflicts,'conflicting_pairs':conflicts})
    frame_ids=set(i for g in groups for i in g['candidates'])
    neighbors={i:set() for i in frame_ids}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            members=set(json.loads(line))
            for i in members&frame_ids:neighbors[i].update(members-{i})
    viable=[]
    for pair in pair_results:
        if not pair['compatible']:continue
        fixed=groups[pair['frame_group']]['candidates'];cog=pair['cog_group']
        excluded=set().union(*(neighbors[i] for i in fixed))
        remaining={family:[i for i,r in mapping.items() if pool[i]['placement']['part_id']==family
            and cog in r['compatible_skeletons'] and i not in excluded] for family in ['bracket','insert']}
        row={'frame_group':pair['frame_group'],'cog_group':cog,'remaining_candidates':remaining,
             'counts':{f:len(v) for f,v in remaining.items()}}
        row['passes_trivial_quantity_check']=all(row['counts'][f]>=parts[f]['quantity'] for f in remaining)
        viable.append(row)
    warm=load(SRC/'selected-indices.json')
    warm_frames=sorted(i for i in warm if pool[i]['placement']['part_id']=='frame')
    warm_matches=[g['index'] for g in groups if g['candidates']==warm_frames]
    write(OUT/'groups.json',groups);write(OUT/'pairs.json',pair_results);write(OUT/'remaining.json',viable)
    check={'seconds':time.perf_counter()-started,'source_event_groups':len(raw),
        'complete_source_frame_groups':sum(len(g['sources']) for g in groups),'distinct_complete_frame_groups':len(groups),
        'incomplete_source_groups':rejected,'within_frame_pairs_checked':internal,
        'minimum_frame_distance_mm':min_distance,'frame_cog_pairs_checked':cross,
        'group_combinations':len(pair_results),'compatible_group_combinations':len(viable),
        'compatible_combinations_passing_quantity_count':sum(r['passes_trivial_quantity_check'] for r in viable),
        'warm_frame_group_indices':warm_matches,'geometry_and_existing_compatibility_map_agree':True,
        'full_target_witness':False,'native_margin_qualified':False,'solver_runs':0,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',check);print(json.dumps(check),flush=True)
if __name__=='__main__':main()
