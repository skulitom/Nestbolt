"""One bounded complete four-part model with exact16-gon/rectangle separation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
from itertools import combinations,product
import json,shutil,sys,time,traceback
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
from audit_h5_strong_pair_model import verify

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strong-pair-convex-domains-recovered-20261025'
PRIOR=ROOT/'output/h5-pair-core-relocation-regions-20261025';SRC=ROOT/'output/h5-source-orientation-construction-20261025'
OUT=BASE/'solve';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    spec=load(BASE/'plan.json');cases=spec['cases'];atlas=load(BASE/'support-atlas.json');aux=load(SRC/'propagation.json');hints=load(SRC/'hint-poses.json')
    queries={q['index']:load(BASE/'queries'/f"{q['index']:04d}.json") for q in spec['queries']}
    previous={c['case']:load(PRIOR/'cases'/f"{c['case']:03d}.json") for c in cases}
    params={'max_time_in_seconds':60,'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,
            'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
    inputs=[BASE/n for n in ['plan.json','result.json','audit/checks.json','support-atlas.json']]
    inputs += [SRC/'propagation.json',SRC/'hint-poses.json',ROOT/'output/audit_h5_strong_pair_model.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'domain_query_hashes':{str(q):digest(BASE/'queries'/f'{q:04d}.json') for q in queries},
          'prior_case_hashes':{str(c['case']):digest(PRIOR/'cases'/f"{c['case']:03d}.json") for c in cases},
          'construction_limit_seconds':120,'independent_model_audit_limit_seconds':120,'parameters':params,'maximum_solver_calls':1,
          'required_counts':{'frame':18,'bracket':12,'insert':21,'cog':15},'fixed_parts_per_case':62,'mandatory_movable_parts':4,
          'cases':207,'allocations':286,'objective':None,'hints':None,
          'method':'Select one of all207 surviving cases and one of its286 allocations. Every one of four mandatory physical parts chooses a complete convex domain of the appropriate role/mode in that case. Apply all audited outward rational integer halfplanes and bounds. Its sheet and exact component support values share that chosen mode. For every cross-part convex-component pair on the same sheet require at least one of all20 audited edge-normal separations, with the exact100:1 geometry/anchor scale. Two bracket arms share one anchor and mode; each restored frame or cog has one convex proxy component. The cog is the full certified floor-safe16-gon, not the prior five rectangles. Original area charges retained. No copy ordering, objective, unplaced allowance or nonbinding hint. Full protobuf oracle before one60-second/eight-worker/seed-zero call. A result remains conditional proxy geometry, not H5 acceptance.'})
    for c in cases:
        remaining=[h for h in hints if h['item'] not in c['released_items']]
        count=Counter(h['family'] for h in remaining);count.update(c['families']);count['bracket']+=2
        assert len(remaining)==62 and count=={'frame':18,'bracket':12,'insert':21,'cog':15}
    start=time.perf_counter();model=cp_model.CpModel();vs=[];loinf=cp_model.INT_MIN;hiinf=cp_model.INT_MAX
    def var(name,lo,hi):
        v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi,en=()):
        c=model.add_linear_constraint(sum(vs[i]*coef for i,coef in terms),lo,hi)
        if en:c.only_enforce_if([vs[v] for v in en])
    active={c['case']:var(f"case{c['case']}-active",0,1) for c in cases};model.add_exactly_one([vs[v] for v in active.values()])
    allocations=[]
    for c in cases:
        enabled=[]
        for j,record in enumerate(c['allocations']):
            a=record['value'];v=var(f"case{c['case']}-allocation{j}",0,1);enabled.append(v);charge=[]
            for sheet in [0,1]:
                value=previous[c['case']]['base_original_area_units'][sheet]+a['brackets_per_sheet'][sheet]*aux['part_areas']['bracket']['lower_units']
                value+=sum(aux['part_areas'][c['families'][k]]['lower_units'] for k in [0,1] if a['restored_sheets'][k]==sheet)
                assert value<=aux['sheet_capacities'][sheet]['upper_area_units'];charge.append(value)
            allocations.append({'case':c['case'],'allocation':j,'prior_allocation':record['prior_allocation'],'active':v,'value':a,'charges':charge})
        linear([(v,1) for v in enabled]+[(active[c['case']],-1)],0,0)
    parts=[]
    for pi,role in enumerate(['bracket','bracket','restored0','restored1']):
        name=f'part{pi}';x=var(name+'-x',0,150000);y=var(name+'-y',0,300000);sheet=var(name+'-sheet',0,1);modes=[]
        for c in cases:
            enabled=[]
            for q in spec['queries']:
                if q['case']!=c['case'] or q['role']!=role:continue
                tag=name+f"-q{q['index']}";v=var(tag+'-active',0,1);domains=[]
                for face in queries[q['index']]['domains']:
                    chosen=var(tag+f"-domain{face['index']}",0,1);domains.append(chosen);bounds=face['coordinate_bounds']
                    linear([(x,1)],bounds[0],bounds[2],[chosen]);linear([(y,1)],bounds[1],bounds[3],[chosen])
                    for row in face['halfplanes']:linear([(x,row['a']),(y,row['b'])],loinf,row['upper'],[chosen])
                linear([(d,1) for d in domains]+[(v,-1)],0,0);enabled.append(v)
                modes.append({'case':c['case'],'query':q['index'],'active':v,'domains':domains,'sheet':q['sheet'],'moving_proxy':q['moving_proxy']})
            linear([(v,1) for v in enabled]+[(active[c['case']],-1)],0,0)
        linear([(sheet,1)]+[(m['active'],-m['sheet']) for m in modes],0,0);components=[]
        for arm in range(2 if pi<2 else 1):
            support=[]
            for n in range(20):
                values=[atlas['proxies'][m['moving_proxy']]['supports'][arm][n] for m in modes]
                v=var(name+f'-component{arm}-support{n}',min(values),max(values))
                linear([(v,1)]+[(m['active'],-value) for m,value in zip(modes,values)],0,0);support.append(v)
            components.append(support)
        parts.append({'index':pi,'role':role,'x':x,'y':y,'sheet':sheet,'modes':modes,'components':components})
    for k in [0,1]:linear([(parts[k+2]['sheet'],1)]+[(a['active'],-a['value']['restored_sheets'][k]) for a in allocations],0,0)
    linear([(parts[0]['sheet'],1),(parts[1]['sheet'],1)]+[(a['active'],-a['value']['brackets_per_sheet'][1]) for a in allocations],0,0)
    for sheet in [0,1]:linear([(a['active'],a['charges'][sheet]) for a in allocations],loinf,aux['sheet_capacities'][sheet]['upper_area_units'])
    pairs=[]
    for a,b in combinations(parts,2):
        prefix=f"pair{a['index']}-{b['index']}";different=var(prefix+'-different-sheet',0,1)
        model.add_bool_xor([vs[a['sheet']],vs[b['sheet']],vs[different].Not()]);component_pairs=[]
        for ai,bi in product(range(len(a['components'])),range(len(b['components']))):
            directions=[]
            for n,(nx,ny) in enumerate(atlas['normals']):
                selected=var(prefix+f'-components{ai}-{bi}-normal{n}',0,1);directions.append(selected)
                opposite=atlas['opposite_normal_indices'][n]
                terms=[(b['x'],100*nx),(a['x'],-100*nx),(b['y'],100*ny),(a['y'],-100*ny),
                       (a['components'][ai][n],-1),(b['components'][bi][opposite],-1)]
                linear(terms,0,hiinf,[selected])
            model.add_bool_or([vs[different]]+[vs[v] for v in directions])
            component_pairs.append({'components':[ai,bi],'directions':directions})
        pairs.append({'parts':[a['index'],b['index']],'different_sheet':different,'component_pairs':component_pairs})
    mapping={'cases':active,'allocations':allocations,'parts':parts,'pairs':pairs}
    assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));write(OUT/'mapping.json',mapping)
    construction_seconds=time.perf_counter()-start;assert construction_seconds<120
    print({'construction_seconds':construction_seconds,'variables':len(vs)},flush=True)
    start=time.perf_counter();actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes())
    oracle,stats=verify(actual,spec,queries,previous,atlas,aux);assert oracle==mapping
    solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    audit_seconds=time.perf_counter()-start;assert audit_seconds<120
    write(OUT/'model-audit.json',{'passed':True,'construction_seconds':construction_seconds,'audit_seconds':audit_seconds,
          'all_variables_constraints_and_parameters_independently_reconstructed':True,**stats,
          'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),
          'python':sys.version,'ortools':ortools.__version__});print(load(OUT/'model-audit.json'),flush=True)
    def positions(value):
        chosen=[a for a in allocations if value(vs[a['active']])];assert len(chosen)==1;a=chosen[0];rows=[]
        for p in parts:
            modes=[m for m in p['modes'] if value(vs[m['active']])];assert len(modes)==1;m=modes[0]
            ds=[i for i,v in enumerate(m['domains']) if value(vs[v])];assert len(ds)==1 and m['case']==a['case']
            q=spec['queries'][m['query']]
            rows.append({'part':p['index'],'role':p['role'],'case':a['case'],'query':m['query'],'domain':ds[0],
                         'prior_query':q['prior_query'],'region_query':q['region_query'],'moving_proxy':m['moving_proxy'],
                         'x_units':value(vs[p['x']]),'y_units':value(vs[p['y']]),'sheet':value(vs[p['sheet']]),
                         'family':q['family'],'mode':q['mode'],'class':q['class']})
        c=next(c for c in cases if c['case']==a['case'])
        return {'case':a['case'],'allocation':a['allocation'],'prior_allocation':a['prior_allocation'],'released_items':c['released_items'],'movable_parts':rows}
    records=[]
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            p=positions(self.value);write(OUT/f'incumbent-{len(records)}.json',p)
            records.append({'index':len(records),'seconds':self.wall_time,'case':p['case']});print(records[-1],flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':60,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda message:(log.write(message+'\n'),log.flush())
        start=time.perf_counter();status=solver.solve(model,Capture());elapsed=time.perf_counter()-start
    feasible=status in [cp_model.FEASIBLE,cp_model.OPTIMAL]
    if feasible:write(OUT/'positions.json',positions(solver.value))
    result={'status':solver.status_name(status),'seconds':elapsed,'solver_calls':1,'incumbents':records,
            'has_full_stronger_proxy_solution':feasible,'response_stats':solver.response_stats(),
            'scope':'All207 surviving two-core cases and286 allocations, with62 fixed originals and four mandatory movable parts. Outward domains and exact floor-safe16-gon/rectangle mutual separation. Negative is conditional on this finite neighborhood inventory; UNKNOWN is unresolved. Positive still requires original outlines/angles, native margins, production budget and full H5 matrix.',
            'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
