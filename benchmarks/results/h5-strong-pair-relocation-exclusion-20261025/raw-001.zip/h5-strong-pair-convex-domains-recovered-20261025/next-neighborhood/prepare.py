"""Bind the next larger construction to observed conflict owners and full counts."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-strong-pair-convex-domains-recovered-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
PRIOR=ROOT/'output/h5-pair-core-relocation-regions-20261025';OUT=BASE/'next-neighborhood'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[BASE/'solve/result.json',BASE/'solve/model-audit.json',GEO/'selected-anchor-conflicts.json',GEO/'audit/checks.json',
        PRIOR/'solve/positions.json',SRC/'items.json',SRC/'hint-poses.json',SRC/'propagation.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
      'method':'Form one distinct construction neighborhood from the two previously moved originals plus EVERY fixed original owner in the certified collision list. Preserve every original count and both missing brackets. No search or widening of completed two-core cases. Preparation only; all positions and allowed sheets of the released originals will be free in any later model, with their source orientation inventory and arbitrary cog angles represented by the certified proxy.'})
assert load(BASE/'solve/result.json')['status']=='INFEASIBLE' and load(BASE/'solve/model-audit.json')['passed']
solution=load(PRIOR/'solve/positions.json');conflicts=load(GEO/'selected-anchor-conflicts.json')
items=load(SRC/'items.json');hints=load(SRC/'hint-poses.json');aux=load(SRC/'propagation.json')
conflict_owners=sorted({r['fixed_item'] for r in conflicts});released=sorted(set(solution['released_items'])|set(conflict_owners))
additional=[i['index'] for i in items if i['source_index'] is None];remaining=[h for h in hints if h['item'] not in released]
restored=[items[i] for i in released];movable=restored+[items[i] for i in additional]
assert released==[50,54,57,58,62,64,65] and len(remaining)==57 and len(movable)==9
count=Counter(h['family'] for h in remaining);count.update(i['family'] for i in movable)
assert count=={'frame':18,'bracket':12,'insert':21,'cog':15} and Counter(i['family'] for i in restored)=={'cog':6,'insert':1}
basearea=[sum(aux['part_areas'][h['family']]['lower_units'] for h in remaining if h['sheet']==s) for s in [0,1]]
record={'previous_released_items':solution['released_items'],'certified_fixed_conflict_owners':conflict_owners,
        'released_original_items':released,'released_original_parts':[{'item':i['index'],'family':i['family'],'copy':i['copy'],
            'source_index':i['source_index'],'allowed_modes':i['allowed_modes'],'fixed_representative_class':i['fixed_representative_class']} for i in restored],
        'additional_mandatory_bracket_items':additional,'fixed_original_items':[h['item'] for h in remaining],
        'fixed_original_parts':57,'mandatory_movable_original_parts':9,'required_original_counts':dict(count),
        'fixed_original_area_units_per_sheet':basearea,'every_certified_conflict_owner_released':True,
        'moving_insert_needs_its_audited_floor_safe_proxy_and_fixed_obstacle_caches':True,
        'fresh_domains_required':'Start from complete original stock anchor domains for all nine movable originals; the earlier two-core free cells cannot constrain this larger neighborhood.',
        'positions_and_sheets_not_fixed_by_census':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
write(OUT/'census.json',record);print(record)
SYNC=BASE/'source-sync';SYNC.mkdir()
r=subprocess.run(['gh','run','view','40233299884','--json','status,conclusion,jobs,headSha,url'],cwd=ROOT,capture_output=True)
(SYNC/'ci.stderr.txt').write_bytes(r.stderr);assert r.returncode==0,r.stderr.decode(errors='replace')
ci=json.loads(r.stdout);assert ci['headSha']=='247e823a9feef2bf906e27204981b957dc55cdfc' and ci['status']=='completed' and ci['conclusion']=='success'
assert len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs'])
write(SYNC/'completed-main-ci.json',ci)
write(SYNC/'snapshot.json',{'utc':datetime.now(timezone.utc).isoformat(),'run_id':40233299884,'status':'completed','conclusion':'success','successful_jobs':6,
      'normal_main_push_now_ready':True,'push_performed_yet':False,'same_run_not_restarted':True})
