"""Complete outward convex domains and exact convex-component support data."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from collections import defaultdict
from itertools import combinations,product
import heapq,json,math,shutil,time,traceback
import shapely
from shapely.geometry import Polygon,MultiPoint,shape,mapping
from shapely.geometry.polygon import orient
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1]
REG=ROOT/'output/h5-original-fixed-pair-regions-recovered-20261025'
GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
OLD=ROOT/'output/h5-strong-pair-convex-domains-20261025'
OUT=ROOT/'output/h5-strong-pair-convex-domains-recovered-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
COEFF=10**7;EPS=.001;MAXX=150000;MAXY=300000

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def polygons(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    assert g.geom_type=='MultiPolygon',g.geom_type
    return list(g.geoms)

def convex_faces(region,deadline):
    triangles=[t for p in polygons(region) for t in shapely.constrained_delaunay_triangles(p).geoms]
    faces={i:t for i,t in enumerate(triangles)};edgeowners=defaultdict(list);neighbors={i:set() for i in faces}
    for i,t in faces.items():
        pts=list(t.exterior.coords)
        for a,b in zip(pts,pts[1:]):edgeowners[tuple(sorted([a,b]))].append(i)
    queue=[]
    for ids in edgeowners.values():
        for a,b in combinations(ids,2):neighbors[a].add(b);neighbors[b].add(a);heapq.heappush(queue,(min(a,b),max(a,b)))
    attempts=merges=0
    while queue and attempts<10000 and time.perf_counter()<deadline:
        a,b=heapq.heappop(queue)
        if a not in faces or b not in faces or b not in neighbors[a]:continue
        attempts+=1;combined=faces[a].union(faces[b])
        if combined.geom_type!='Polygon' or not combined.equals(combined.convex_hull):continue
        adjacent=(neighbors[a]|neighbors[b])-{a,b};faces[a]=combined;del faces[b];merges+=1;neighbors[a]=adjacent
        for k in adjacent:neighbors[k].discard(b);neighbors[k].add(a);heapq.heappush(queue,(min(a,k),max(a,k)))
        del neighbors[b]
    output=[faces[i] for i in sorted(faces)]
    assert all(p.equals(p.convex_hull) and p.area>0 for p in output)
    return output,{'triangles':len(triangles),'merge_attempts':attempts,'merges':merges,
                   'merge_cap_reached':bool(queue) and attempts>=10000,
                   'merge_time_reached':bool(queue) and time.perf_counter()>=deadline,
                   'all_unmerged_faces_retained':True}

def halfplanes(poly):
    xy=list(orient(poly,sign=1).exterior.coords);rows=[]
    for p,q in zip(xy,xy[1:]):
        x,y=map(F,p);u,v=map(F,q);a=v-y;b=x-u
        if a==b==0:continue
        scale=max(abs(a),abs(b));a/=scale;b/=scale;c=a*x+b*y
        A=round(a*COEFF);B=round(b*COEFF)
        error=abs(A-a*COEFF)*MAXX+abs(B-b*COEFF)*MAXY+1
        upper=math.ceil(c*100*COEFF+error)
        assert (A or B) and max(abs(A)*MAXX+abs(B)*MAXY,abs(upper))<2**60
        rows.append({'edge':[list(p),list(q)],'a':A,'b':B,'upper':upper,'rounding_error_bound':[error.numerator,error.denominator]})
    assert len(rows)>=3;return rows

def support_atlas(moving):
    specs=[];normals=set()
    for m in moving:
        components=([m['vertices_units10000']] if m['family']=='cog' else
                    [[[r[0]*100,r[1]*100],[r[2]*100,r[1]*100],[r[2]*100,r[3]*100],[r[0]*100,r[3]*100]] for r in m['components_units100']])
        for pts in components:
            for a,b in zip(pts,pts[1:]+pts[:1]):
                nx,ny=b[1]-a[1],a[0]-b[0];div=math.gcd(abs(nx),abs(ny));assert div;normals.add((nx//div,ny//div))
        specs.append({'moving_proxy':m['index'],'family':m['family'],'class':m['class'],'components':components})
    normals=sorted(normals);assert len(normals)==20 and all((-a,-b) in normals for a,b in normals)
    for s in specs:s['supports']=[[max(nx*x+ny*y for x,y in pts) for nx,ny in normals] for pts in s['components']]
    return {'geometry_units_per_mm':10000,'coordinate_units_per_mm':100,'geometry_units_per_coordinate_unit':100,
            'normals':[list(n) for n in normals],'opposite_normal_indices':[normals.index((-a,-b)) for a,b in normals],
            'proxies':specs,'meaning':'For different physical parts on the same sheet, require at least one normal n with100*n dot(anchorB-anchorA) >= supportA(n)+supportB(-n), independently for each pair of convex components. These are exact integer projections of floor-safe proxies; touching is allowed. Both bracket arms share one anchor/mode. No same-part pair constraint.'}

def main():
    assert load(REG/'audit/checks.json')['passed'] and load(GEO/'audit/checks.json')['passed']
    OUT.mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    rawcases=load(REG/'audit/surviving-neighborhoods.json');cases=[]
    for c in rawcases:cases.append({'case':c['case'],'released_items':c['released_items'],'families':c['families'],
          'allocations':[{'prior_allocation':a['prior_allocation'],'value':a['allocation']} for a in c['allocations'] if not a['excluded_by_empty_role']]})
    assert len(cases)==207 and sum(len(c['allocations']) for c in cases)==286
    caseby={c['case']:c for c in cases};queries=[]
    for q in load(REG/'plan.json')['queries']:
        if q['case'] not in caseby:continue
        allowed=any(a['value']['brackets_per_sheet'][q['sheet']]>0 if q['role']=='bracket' else a['value']['restored_sheets'][int(q['role'][-1])]==q['sheet'] for a in caseby[q['case']]['allocations'])
        if allowed:queries.append({**q,'index':len(queries),'region_query':q['index']})
    inputs=[REG/n for n in ['plan.json','audit/plan.json','audit/checks.json','audit/surviving-neighborhoods.json']]
    inputs += [GEO/n for n in ['moving-proxies.json','audit/checks.json']]+[SRC/'propagation.json',SRC/'hint-poses.json',SRC/'items.json',
               ROOT/'benchmarks/results/h5-original-outline-collision-regions-20261025/raw-manifest.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'construction_limit_seconds':60,'original_total_construction_limit_seconds':120,'first_failed_phase_charged_seconds':60,'completed_queries_reused_unchanged':40,'maximum_domains':200000,'per_query_merge_attempt_limit':10000,
          'coordinate_units_per_mm':100,'coefficient_scale':COEFF,'coordinate_maxima':[MAXX,MAXY],
          'extra_convex_cover_square_padding_mm':EPS,'cases':cases,'queries':queries,
          'region_cover_hashes':{str(q['region_query']):digest(REG/'audit/covers'/f"{q['region_query']:04d}.json") for q in queries},
          'required_original_counts':{'frame':18,'bracket':12,'insert':21,'cog':15},'fixed_parts_per_case':62,'mandatory_movable_parts':4,
          'method':'Use every eligible role/mode of all207 surviving cases and286 allocations. Triangulate each positively padded source polygon; merge only convex adjacent face unions, retaining every unmerged face on a merge cap. Expand each convex face by a0.001mm square and require their union to cover the entire source region. This also absorbs numerical triangulation slivers without dropping source boundary points. Derive normalized rational edge halfplanes from stored binary-float vertices, round coefficients at1e7, add the exact worst-case coefficient error over the full coordinate bounds plus one, and ceil the upper bound. Integer bounding intervals round outward. These domains cover all prior admissible integer anchors; no extra floor-anchor shift or candidate sample is used. Prepare exact integer support data for the stronger16-gon and coupled rectangle components; all convex pair edge normals must be independently audited before a new model. Preserve pending queries and all merge caps. No solver call.'})
    assert queries==load(OLD/'plan.json')['queries'] and cases==load(OLD/'plan.json')['cases']
    for name in ['plan.json','failure.txt','build.py']:shutil.copyfile(OLD/name,OUT/('original-'+name))
    shutil.copyfile(ROOT/'output/h5-strong-domain-recovery-plan.json',OUT/'recovery-plan.json')
    shutil.copyfile(OLD/'support-atlas.json',OUT/'support-atlas.json')
    start=time.perf_counter();deadline=start+60
    records=[];total=0;pending=[]
    for i in range(40):
        source=OLD/'queries'/f'{i:04d}.json';target=OUT/'queries'/f'{i:04d}.json';shutil.copyfile(source,target);assert digest(source)==digest(target)
        old=load(target);assert old['query']==queries[i];total+=len(old['domains']);records.append({'query':i,'case':old['query']['case'],'domains':len(old['domains']),**old['merge']})
    for q in queries[40:]:
        if time.perf_counter()>=deadline or total>=200000:pending=queries[len(records):];break
        path=REG/'audit/covers'/f"{q['region_query']:04d}.json";record=load(path);region=shape(record['cover'])
        faces,merge=convex_faces(region,deadline);rows=[];expanded_shapes=[]
        for i,p in enumerate(faces):
            points=list(p.exterior.coords)[:-1]
            expanded=orient(MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product(points,[(-EPS,-EPS),(-EPS,EPS),(EPS,EPS),(EPS,-EPS)])]).convex_hull,sign=1)
            a,b,c,d=expanded.bounds;bounds=[math.floor(F(a)*100),math.floor(F(b)*100),math.ceil(F(c)*100),math.ceil(F(d)*100)]
            assert 0<=bounds[0]<=bounds[2]<=MAXX and 0<=bounds[1]<=bounds[3]<=MAXY
            rows.append({'index':i,'raw_face':mapping(p),'expanded_convex_face':mapping(expanded),'coordinate_bounds':bounds,'halfplanes':halfplanes(expanded)})
            expanded_shapes.append(expanded)
        cover=unary_union(expanded_shapes);assert region.is_empty or cover.covers(region)
        total+=len(rows)
        write(OUT/'queries'/f"{q['index']:04d}.json",{'query':q,'source_cover':path.relative_to(ROOT).as_posix(),
              'source_cover_sha256':digest(path),'source_empty':region.is_empty,'merge':merge,'domains':rows})
        records.append({'query':q['index'],'case':q['case'],'domains':len(rows),**merge})
        if len(records)%400==0:print({'queries_completed':len(records),'domains':total,'seconds':time.perf_counter()-start},flush=True)
    write(OUT/'pending.json',pending);write(OUT/'query-summary.json',records)
    result={'seconds':time.perf_counter()-start,'queries_planned':len(queries),'queries_completed':len(records),'queries_pending':len(pending),
            'cases':207,'allocations':286,'completed_queries_reused_unchanged':40,'queries_newly_completed':len(records)-40,'first_failed_phase_charged_seconds':60,'total_domains':total,'domain_cap_reached':total>=200000,
            'merge_cap_queries':sum(r['merge_cap_reached'] for r in records),'merge_time_queries':sum(r['merge_time_reached'] for r in records),
            'all_unmerged_faces_retained':True,'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
