"""Correct vacuous empty-set coverage without repeating completed domain queries."""
from pathlib import Path
from datetime import datetime
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-strong-pair-convex-domains-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(OLD/'plan.json');done=sorted((OLD/'queries').glob('*.json'));assert len(done)==40
assert [p.name for p in done]==[f'{i:04d}.json' for i in range(40)]
query=plan['queries'][40];cover=load(ROOT/'output/h5-original-fixed-pair-regions-recovered-20261025/audit/covers'/f"{query['region_query']:04d}.json")
assert cover['empty'] and cover['cover']['type']=='GeometryCollection'
wall=(OLD/'failure.txt').stat().st_mtime-datetime.fromisoformat(plan['utc']).timestamp();assert 0<wall<10
source=ROOT/'output/build_h5_strong_pair_domains.py';target=ROOT/'output/build_h5_strong_pair_domains_recovered.py'
text=source.read_text(encoding='utf-8')
changes=[
 ("OUT=ROOT/'output/h5-strong-pair-convex-domains-20261025'","OLD=ROOT/'output/h5-strong-pair-convex-domains-20261025'\nOUT=ROOT/'output/h5-strong-pair-convex-domains-recovered-20261025'"),
 ("'construction_limit_seconds':120","'construction_limit_seconds':60,'original_total_construction_limit_seconds':120,'first_failed_phase_charged_seconds':60,'completed_queries_reused_unchanged':40"),
 ("    start=time.perf_counter();deadline=start+120\n    write(OUT/'support-atlas.json',support_atlas(load(GEO/'moving-proxies.json')))\n    records=[];total=0;pending=[]\n    for q in queries:",
  "    assert queries==load(OLD/'plan.json')['queries'] and cases==load(OLD/'plan.json')['cases']\n    for name in ['plan.json','failure.txt','build.py']:shutil.copyfile(OLD/name,OUT/('original-'+name))\n    shutil.copyfile(ROOT/'output/h5-strong-domain-recovery-plan.json',OUT/'recovery-plan.json')\n    shutil.copyfile(OLD/'support-atlas.json',OUT/'support-atlas.json')\n    start=time.perf_counter();deadline=start+60\n    records=[];total=0;pending=[]\n    for i in range(40):\n        source=OLD/'queries'/f'{i:04d}.json';target=OUT/'queries'/f'{i:04d}.json';shutil.copyfile(source,target);assert digest(source)==digest(target)\n        old=load(target);assert old['query']==queries[i];total+=len(old['domains']);records.append({'query':i,'case':old['query']['case'],'domains':len(old['domains']),**old['merge']})\n    for q in queries[40:]:"),
 ("cover=unary_union(expanded_shapes);assert cover.covers(region)","cover=unary_union(expanded_shapes);assert region.is_empty or cover.covers(region)"),
 ("'cases':207,'allocations':286,'total_domains':total", "'cases':207,'allocations':286,'completed_queries_reused_unchanged':40,'queries_newly_completed':len(records)-40,'first_failed_phase_charged_seconds':60,'total_domains':total")]
for old,new in changes:
    assert text.count(old)==1,(old,text.count(old));text=text.replace(old,new)
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
record={'original_source':source.relative_to(ROOT).as_posix(),'original_source_sha256':digest(source),
        'corrected_source':target.relative_to(ROOT).as_posix(),'corrected_source_sha256':digest(target),
        'original_plan':(OLD/'plan.json').relative_to(ROOT).as_posix(),'original_plan_sha256':digest(OLD/'plan.json'),
        'original_failure':(OLD/'failure.txt').relative_to(ROOT).as_posix(),'original_failure_sha256':digest(OLD/'failure.txt'),
        'completed_queries':40,'completed_query_hashes':{p.name:digest(p) for p in done},
        'failed_query':query,'wall_seconds_plan_to_failure':wall,'original_limit_seconds':120,
        'failed_phase_conservative_charge_seconds':60,'remaining_query_limit_seconds':60,
        'reason':'The input region is empty and its correct domain union is empty. GEOS covers(empty,empty) returns false, so the guard must explicitly accept the vacuous empty-set coverage. No nonempty-region calculation or constraint changes. Preserve all40 completed queries and the support atlas byte-identically, and compute only unfinished queries under the remaining budget. No cap or solver retry.',
        'changes':[{'old':a,'new':b} for a,b in changes]}
with (ROOT/'output/h5-strong-domain-recovery-plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print({k:record[k] for k in ['completed_queries','wall_seconds_plan_to_failure','remaining_query_limit_seconds']})
