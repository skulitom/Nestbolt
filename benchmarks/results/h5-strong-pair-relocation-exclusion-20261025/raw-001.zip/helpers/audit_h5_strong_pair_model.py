"""Independent full protobuf reconstruction for stronger joint separation."""
from collections import Counter
from itertools import combinations,product
from ortools.sat import cp_model_pb2

def verify(actual,spec,queries,previous,atlas,aux):
    vi=ci=domain_count=mode_count=plane_count=component_pairs=0
    def vcheck(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]),(vi,name)
        vi+=1;return vi-1
    def lcheck(terms,lo,hi,en=()):
        nonlocal ci
        merged=Counter()
        for v,c in terms:merged[v]+=c
        ids=sorted(v for v,c in merged.items() if c);expected=cp_model_pb2.ConstraintProto()
        expected.enforcement_literal.extend(en);expected.linear.vars.extend(ids)
        expected.linear.coeffs.extend(merged[v] for v in ids);expected.linear.domain.extend([lo,hi])
        assert actual.constraints[ci]==expected,(ci,actual.constraints[ci],expected);ci+=1
    def bcheck(kind,literals):
        nonlocal ci
        expected=cp_model_pb2.ConstraintProto();getattr(expected,kind).literals.extend(literals)
        assert actual.constraints[ci]==expected,(ci,kind);ci+=1
    active={c['case']:vcheck(f"case{c['case']}-active",0,1) for c in spec['cases']}
    bcheck('exactly_one',list(active.values()));allocations=[]
    for c in spec['cases']:
        enabled=[]
        for j,record in enumerate(c['allocations']):
            a=record['value'];v=vcheck(f"case{c['case']}-allocation{j}",0,1);enabled.append(v);charges=[]
            for s in [0,1]:
                charge=previous[c['case']]['base_original_area_units'][s]+aux['part_areas']['bracket']['lower_units']*a['brackets_per_sheet'][s]
                for k,destination in enumerate(a['restored_sheets']):
                    if destination==s:charge+=aux['part_areas'][c['families'][k]]['lower_units']
                assert charge<=aux['sheet_capacities'][s]['upper_area_units'];charges.append(charge)
            allocations.append({'case':c['case'],'allocation':j,'prior_allocation':record['prior_allocation'],'active':v,'value':a,'charges':charges})
        lcheck([(v,1) for v in enabled]+[(active[c['case']],-1)],0,0)
    assert len(active)==207 and len(allocations)==286
    parts=[]
    for pi in range(4):
        role='bracket' if pi<2 else f'restored{pi-2}';name=f'part{pi}'
        x=vcheck(name+'-x',0,150000);y=vcheck(name+'-y',0,300000);sheet=vcheck(name+'-sheet',0,1);modes=[]
        for c in spec['cases']:
            chosen_modes=[]
            for q in spec['queries']:
                if q['case']!=c['case'] or q['role']!=role:continue
                prefix=name+f"-q{q['index']}";chosen=vcheck(prefix+'-active',0,1);domain_vars=[]
                for face in queries[q['index']]['domains']:
                    v=vcheck(prefix+f"-domain{face['index']}",0,1);domain_vars.append(v);bounds=face['coordinate_bounds']
                    lcheck([(x,1)],bounds[0],bounds[2],[v]);lcheck([(y,1)],bounds[1],bounds[3],[v])
                    for row in face['halfplanes']:
                        lcheck([(x,row['a']),(y,row['b'])],-2**63,row['upper'],[v]);plane_count+=1
                lcheck([(v,1) for v in domain_vars]+[(chosen,-1)],0,0);chosen_modes.append(chosen)
                mode_count+=1;domain_count+=len(domain_vars)
                modes.append({'case':c['case'],'query':q['index'],'active':chosen,'domains':domain_vars,'sheet':q['sheet'],'moving_proxy':q['moving_proxy']})
            lcheck([(v,1) for v in chosen_modes]+[(active[c['case']],-1)],0,0)
        lcheck([(sheet,1)]+[(m['active'],-1) for m in modes if m['sheet']==1],0,0);components=[]
        for component in range([2,2,1,1][pi]):
            supports=[]
            for n in range(len(atlas['normals'])):
                vals=[atlas['proxies'][m['moving_proxy']]['supports'][component][n] for m in modes]
                v=vcheck(name+f'-component{component}-support{n}',min(vals),max(vals))
                terms=[(v,1)]
                for m in modes:
                    polygon=atlas['proxies'][m['moving_proxy']]['components'][component];nx,ny=atlas['normals'][n]
                    value=max(nx*px+ny*py for px,py in polygon)
                    assert value==atlas['proxies'][m['moving_proxy']]['supports'][component][n]
                    terms.append((m['active'],-value))
                lcheck(terms,0,0);supports.append(v)
            components.append(supports)
        parts.append({'index':pi,'role':role,'x':x,'y':y,'sheet':sheet,'modes':modes,'components':components})
    for k in [0,1]:lcheck([(parts[2+k]['sheet'],1)]+[(a['active'],-a['value']['restored_sheets'][k]) for a in allocations],0,0)
    lcheck([(parts[0]['sheet'],1),(parts[1]['sheet'],1)]+[(a['active'],-a['value']['brackets_per_sheet'][1]) for a in allocations],0,0)
    for s in [0,1]:lcheck([(a['active'],a['charges'][s]) for a in allocations],-2**63,aux['sheet_capacities'][s]['upper_area_units'])
    pairs=[]
    for i,j in combinations(range(4),2):
        a,b=parts[i],parts[j];prefix=f'pair{i}-{j}';different=vcheck(prefix+'-different-sheet',0,1)
        bcheck('bool_xor',[a['sheet'],b['sheet'],-different-1])
        for sa,sb in product([0,1],repeat=2):
            values=[d for d in [0,1] if (sa+sb+(1-d))%2==1];assert values==[int(sa!=sb)]
        ps=[]
        for ai in range(len(a['components'])):
            for bi in range(len(b['components'])):
                ds=[];component_pairs+=1
                for n,(nx,ny) in enumerate(atlas['normals']):
                    d=vcheck(prefix+f'-components{ai}-{bi}-normal{n}',0,1);ds.append(d)
                    opposite=next(k for k,(x,y) in enumerate(atlas['normals']) if x==-nx and y==-ny)
                    assert atlas['opposite_normal_indices'][n]==opposite
                    # Anchor coordinates use0.01mm; shape vertices use0.0001mm.
                    # Project the exact convex Minkowski separation at scale100.
                    lcheck([(b['x'],nx*100),(a['x'],-nx*100),(b['y'],ny*100),(a['y'],-ny*100),
                            (a['components'][ai][n],-1),(b['components'][bi][opposite],-1)],0,2**63-1,[d])
                bcheck('bool_or',[different]+ds);ps.append({'components':[ai,bi],'directions':ds})
        pairs.append({'parts':[i,j],'different_sheet':different,'component_pairs':ps})
    assert component_pairs==13 and len(pairs)==6
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');assert not extra.ListFields()
    return {'cases':active,'allocations':allocations,'parts':parts,'pairs':pairs},{
        'variables':vi,'constraints':ci,'cases':207,'allocations':286,'original_required_parts_per_case':66,
        'fixed_original_parts_per_case':62,'mandatory_movable_parts':4,'role_mode_options':mode_count,
        'complete_convex_domain_options':domain_count,'reified_outward_halfplanes':plane_count,
        'physical_part_pairs':6,'cross_part_convex_component_pairs':13,'separation_normals_per_pair':20,
        'exact_projection_disjunctions':260,'support_variables':120,'sheet_xor_truth_tables_checked':True,
        'both_bracket_arms_share_anchor_and_mode':True,'strong_floor_safe_cog16gon_used_directly':True,
        'old_five_rectangle_cog_collision_constraints_used':False,'same_part_pair_constraints':0,
        'original_area_capacity_constraints':2,'hints':0,'objectives':0,'copy_order_constraints':0,
        'no_optional_original_parts':True}
