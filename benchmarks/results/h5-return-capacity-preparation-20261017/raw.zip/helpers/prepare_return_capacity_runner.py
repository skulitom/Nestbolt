from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'scripts/h5_return_frame_stage_diagnosis.py').read_text(encoding='utf-8')
s=s.replace('h5-return-frame-stage-diagnosis-20261017','h5-return-capacity-diagnosis-20261017')
s=s.replace('Observe frame legality, returned poses, repair losses and material rejection', 'Observe shortened-container capacity, complete initial/repaired geometry, frame legality and repair stages')
s=s.replace("'source_change':'Previous sampling/repair stages plus incoming/victim/actual/hypothetical poses, per-member orientation legality, frame/fallback mode, initial/final losses and independent before/after material; one stderr trace per exchange invocation.'", "'source_change':'Previous frame/stage records plus source/receiver contexts, actual collision-container polygons, every part identity/internal/public pose and collision polygon, and complete initial and returned-best-snapshot repair layouts. Captures can consume wall time; policy, charges and repair caps unchanged.'")
extra='''
def check_capacity_trace(trace):
    def polygon(points):
        assert isinstance(points,list) and len(points)>=3
        assert all(len(p)==2 and all(isinstance(v,(int,float)) and math.isfinite(v) for v in p) for p in points)
        twice=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(points,points[1:]+points[:1]))
        assert abs(twice)>0
    def layout(value):
        polygon(value['container'])
        keys=[]
        for item in value['items']:
            keys.append(item['key'])
            assert isinstance(item['key'],str) and item['key']
            for field in ['external_id','item_index']:assert isinstance(item[field],int) and item[field]>=0
            assert math.isfinite(item['area_hint']) and item['area_hint']>0
            polygon(item['polygon'])
            pose=item['pose'];public=item['public_transform']
            assert isinstance(pose['reflected'],bool) and isinstance(public['mirrored'],bool)
            assert len(pose['translation'])==len(public['translation'])==2
            assert all(math.isfinite(v) for v in [pose['rotation'],*pose['translation'],public['rotation_radians'],*public['translation']])
        assert len(keys)==len(set(keys))
        return Counter((item['item_index'],item['external_id']) for item in value['items'])
    for context in trace['contexts']:
        layout(context['source_after_removal']);layout(context['receiver_before_removal'])
        assert context['shape_last']>0 and context['full_width']>=context['shape_last']
        assert 0<=context['target_index']<context['last_index'] and context['frozen_sheets']>=0
    for attempt in trace['attempts']:
        check_frame_attempt(attempt)
        assert isinstance(attempt['context_index'],int) and 0<=attempt['context_index']<len(trace['contexts'])
        context=trace['contexts'][attempt['context_index']]
        incoming=context['incoming'];identity=(incoming['item_index'],incoming['external_id'])
        assert incoming['pose']==attempt['frame']['incoming_before']
        source=layout(context['source_after_removal']);receiver=layout(context['receiver_before_removal'])
        original={item['key']:item for item in context['receiver_before_removal']['items']}
        members=attempt['frame']['members']
        assert len({m['receiver_key'] for m in members})==len(members)
        for member in members:
            previous=original[member['receiver_key']]
            assert previous['pose']==member['previous'] and previous['external_id']==member['external_id']
            item=(previous['item_index'],previous['external_id'])
            receiver[item]-=1;source[item]+=1
        receiver[identity]+=1
        receiver=+receiver
        for name,expected,boundary in [('source',source,context['source_after_removal']['container']),('receiver',receiver,context['receiver_before_removal']['container'])]:
            initial=attempt[name+'_initial'];repaired=attempt[name+'_repaired']
            assert layout(initial)==expected and initial['container']==boundary
            assert (repaired is None)==(attempt[name+'_loss'] is None)
            if repaired is not None:
                assert layout(repaired)==expected and repaired['container']==boundary


'''
assert s.count('def read_trace(')==1
s=s.replace('def read_trace(',extra+'def read_trace(')
s=s.replace("    attempts = [a for t in traces for a in t['attempts']]", "    for trace in traces:check_capacity_trace(trace)\n    attempts = [a for t in traces for a in t['attempts']]")
p=root/'scripts/h5_return_capacity_diagnosis.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
s=(root/'output/check_return_frame_stage_reader.py').read_text(encoding='utf-8').replace('h5-return-frame-stage','h5-return-capacity').replace('h5_return_frame_stage','h5_return_capacity')
s=s.replace('rows=[];attempts=[]','rows=[];attempts=[];all_traces=[]')
s=s.replace('    assert traces\n','    assert traces\n    for trace in traces:runner.check_capacity_trace(trace)\n    all_traces+=traces\n')
extra='''
accepted_trace=next(t for t in all_traces if any(a['outcome']=='accepted' for a in t['attempts']))
def rejects_capacity(name,mutate):
    value=copy.deepcopy(accepted_trace);mutate(value)
    try:runner.check_capacity_trace(value)
    except (AssertionError,KeyError,IndexError):return name
    raise AssertionError('Capacity reader accepted '+name)
rejected += [
    rejects_capacity('missing context',lambda t:t.update(contexts=[])),
    rejects_capacity('wrong initial source membership',lambda t:t['attempts'][0]['source_initial']['items'][0].update(external_id=999)),
    rejects_capacity('nonfinite saved polygon',lambda t:t['attempts'][0]['source_initial']['items'][0]['polygon'][0].__setitem__(0,float('nan'))),
    rejects_capacity('missing returned repair snapshot',lambda t:t['attempts'][0].update(source_repaired=None)),
    rejects_capacity('wrong original victim identity',lambda t:t['attempts'][0]['frame']['members'][0].update(receiver_key='missing')),
    rejects_capacity('changed repair container',lambda t:t['attempts'][0]['source_repaired']['container'][0].__setitem__(0,999))]
'''
s=s.replace("record={'all_checks_pass':True",extra+"\nrecord={'all_checks_pass':True")
p=root/'output/check_return_capacity_reader.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
print('Prepared capacity-aware runner and authored trace qualification with eleven malformed-record checks.')
