"""Qualify independent geometry calculations with exact analytic coordinates."""
from pathlib import Path
from hashlib import sha256
import copy,json
import audit_h5_return_capacity as audit
root=Path(__file__).resolve().parents[1]
stock={'width':10,'height':10,'margins':dict(left=0,right=0,top=0,bottom=0)}
job={'stocks':[stock],'edge_clearance':0,'parts':[{'id':'triangle','geometry':[{'outer':[[0,0],[4,0],[0,2]],'holes':[]}]}]}
item={'external_id':0,'area_hint':999,'polygon':[[7,8],[7,4],[5,8]],
      'public_transform':{'translation':[7,8],'rotation_radians':audit.math.pi/2,'mirrored':True}}
value={'container':[[0,0],[10,0],[10,10],[0,10]],'items':[item]}
inside=audit.analyze_layout(value,job)
for key in ['search_collision_polygons','original_filled_outer_rings_vs_full_stock']:
    assert abs(inside[key]['sum_part_area_mm2']-4)<1e-12
    assert inside[key]['outside_area_sum_mm2']==inside[key]['pair_intersection_sum_mm2']==0
outside=copy.deepcopy(value);outside['items'][0]['public_transform']['translation'][0]=12
outside['items'][0]['polygon']=[[12,8],[12,4],[10,8]]
checked=audit.analyze_layout(outside,job)
for key in ['search_collision_polygons','original_filled_outer_rings_vs_full_stock']:
    assert abs(checked[key]['outside_area_sum_mm2']-4)<1e-12
job['parts'][0]['geometry'][0]['outer']=[[0,0],[10,0],[10,8],[0,8]]
value['items']=[{'external_id':0,'polygon':[[0,y],[10,y],[10,y+8],[0,y+8]],
    'public_transform':{'translation':[0,y],'rotation_radians':0,'mirrored':False}} for y in [0,2]]
overfull=audit.analyze_layout(value,job)
for key in ['search_collision_polygons','original_filled_outer_rings_vs_full_stock']:
    assert overfull[key]['sum_part_area_mm2']==160
    assert overfull[key]['area_excess_mm2']==60
    assert overfull[key]['pair_intersection_sum_mm2']==60
    assert overfull[key]['outside_area_sum_mm2']==0
record={'all_checks_pass':True,'checks':['mirrored quarter-turn with analytic triangle vertices','original area independent of area hint','whole outside triangle','overfull area bound and exact overlap'],
        'audit_sha256':sha256(Path(audit.__file__).read_bytes()).hexdigest(),'shapely_version':audit.shapely.__version__,
        'new_searches':0,'inside':inside,'outside':checked,'overfull':overfull}
(root/'output/h5-return-capacity-diagnosis-20261017/independent-audit-checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['inside','outside','overfull']}))
