from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/seal_h5_return_frame_stage_preparation.py').read_text(encoding='utf-8')
s=s.replace('h5-return-frame-stage','h5-return-capacity').replace('h5_return_frame_stage','h5_return_capacity').replace('build_h5_return_frame_stage','build_h5_return_capacity')
s=s.replace('prepare_return_frame_diagnostic_driver.py','prepare_return_capacity_drivers.py')
s=s.replace("for name in ['prepare_return_frame_stage_runner.py','prepare_return_frame_stage_records.py',\n             'check_return_frame_trace_snippet.py','check_return_frame_stage_reader.py']:","for name in ['prepare_return_capacity_runner.py','prepare_return_capacity_records.py',\n             'audit_h5_return_capacity.py','check_return_capacity_reader.py']:")
s=s.replace("'malformed_records_rejected':5", "'malformed_records_rejected':11")
start=s.index("(out.parent/(out.name+'.md')).write_text(");end=s.index("with (root/'.gitattributes')",start)
doc='''# Return-sheet capacity diagnostic preparation — 2026-10-17

An isolated observer of the rejected return-frame candidate passes 90 optimized
core tests, strict lint and its build. All prior frame/stage observations remain.
It records the actual shortened collision-container boundary and every source
and receiver item, with identity, internal/public poses and transformed collision
polygon. Initial placements and returned best repair snapshots are recorded
separately. Incoming/target contexts identify the precise membership change.

Two existing authored tests qualify the extended reader, including successful
exchange and strict rejection of a 0.0007 mm² material increase. Eleven malformed
records are rejected, including missing contexts/snapshots, changed identities
or boundaries, nonfinite geometry, forbidden poses and invalid acceptance.

Instrumentation is reversible to the exact rejected source before formatting;
the other 147 files and production are unchanged. No proposal policy, work
charge or repair cap changes. Geometry capture and snapshot reconstruction can
consume wall time and perturb deadlines, so this is not a quality comparison.

After committing the plan, observe only four serial 60-second seed-zero cases:
both mechanical development jobs and kerfs, physical CCD0 CPU 8. An independent
Shapely audit will compare summed collision-polygon area with the shortened
container, original filled outer area with full usable physical stock, and
saved initial/repaired overlap and outside area. A bound below one does not
establish feasibility; an overfull shortened assignment does not establish
global impossibility. Preserve every outcome. H2/H5 remain open at 60%.
'''
s=s[:start]+"(out.parent/(out.name+'.md')).write_text("+repr(doc)+",encoding='utf-8',newline='\\n')\n"+s[end:]
start=s.index("with (root/'BENCHMARKS.md')");end=s.index('print(json.dumps(',start)
note='''

## 2026-10-17 — Prepare complete return-sheet capacity observations

[The isolated capacity observer](benchmarks/results/h5-return-capacity-preparation-20261017.md)
passes 90 optimized tests, strict lint, build and two authored trace captures.
Eleven malformed-record mutations are rejected. The original rejected candidate
and production remain unchanged; instrumentation is exactly reversible before
formatting. All source, binary, log and archive members are verified.

Four committed-plan serial diagnostics will capture actual shortened boundaries,
all source/receiver parts and initial/best repaired geometry. Independent area,
overlap and outside checks will distinguish an overfull assignment from a poor
placement without assuming full stock is available in a compressed search sheet.
Capture overhead can perturb deadlines. No repeated quality pilot, relaxed
limit, reserved-input access or H5 credit. H2/H5 remain open at 60%.
'''
s=s[:start]+"with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\\n') as f:f.write("+repr(note)+")\n"+s[end:]
p=root/'output/seal_h5_return_capacity_preparation.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
s=(root/'output/finish_h5_return_frame_stage_diagnosis.py').read_text(encoding='utf-8').replace('h5_return_frame_stage','h5_return_capacity').replace('h5-return-frame-stage','h5-return-capacity').replace('Return-frame legality and repair diagnosis','Return-sheet capacity and repair diagnosis')
p=root/'output/finish_h5_return_capacity_diagnosis.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
print('Prepared capacity evidence sealing and full archive/trace verification.')
