from pathlib import Path
from hashlib import sha256
import json
import shutil
import subprocess
import sys
import zipfile
root=Path(__file__).resolve().parents[1]
probe=root/'output/h5-return-capacity-diagnosis-20261017'
out=root/'benchmarks/results/h5-return-capacity-preparation-20261017'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
build=load(probe/'build.json');assert build['all_passed']
assert digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert '90 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
plan=load(probe/'preparation.json')
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for row in plan['source_files']:
    assert digest(Path(plan['old_source'])/row['path'])==row['sha256']
    if row['path']!=plan['changed_file']:assert digest(probe/'workspace'/row['path'])==row['sha256']
reader=load(probe/'authored-trace-reader/checks.json');assert reader['all_checks_pass']
assert reader['reader_sha256']==digest(root/'scripts/h5_return_capacity_diagnosis.py')
audit=load(probe/'independent-audit-checks.json');assert audit['all_checks_pass']
assert audit['audit_sha256']==digest(root/'output/audit_h5_return_capacity.py')
out.mkdir(exist_ok=False)
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
files['build-driver.py']=root/'output/build_h5_return_capacity_diagnosis.py'
files['seal-driver.py']=Path(__file__)
files['driver-preparation.py']=root/'output/prepare_return_capacity_drivers.py'
for name in ['prepare_return_capacity_runner.py','prepare_return_capacity_records.py',
             'audit_h5_return_capacity.py','check_return_capacity_audit.py','check_return_capacity_reader.py']:
    files['helpers/'+name]=root/'output'/name
files['diagnostic-runner.py']=root/'scripts/h5_return_capacity_diagnosis.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
raw=out/'raw.zip'
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(raw) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
for name in ['preparation.json','build.json','instrumentation.patch']:
    shutil.copyfile(probe/name,out/name)
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(raw),'bytes':raw.stat().st_size,
    'members':inventory,'crc_and_every_member_verified':True})
write(out/'checks.json',{'optimized_core_tests_passed':90,'strict_lint_passed':True,
    'instrumented_observer_build_passed':True,'old_candidate_and_production_unchanged':True,
    'diagnostic_only':True,'quality_claim':False,'measured_search_started':False,
    'authored_reader_traces':2,'malformed_records_rejected':11,'analytic_geometry_audit_checks_passed':True,
    'completed_weight_percent':60,'H5_complete':False})
(out.parent/(out.name+'.md')).write_text('# Return-sheet capacity diagnostic preparation — 2026-10-17\n\nAn isolated observer of the rejected return-frame candidate passes 90 optimized\ncore tests, strict lint and its build. All prior frame/stage observations remain.\nIt records the actual shortened collision-container boundary and every source\nand receiver item, with identity, internal/public poses and transformed collision\npolygon. Initial placements and returned best repair snapshots are recorded\nseparately. Incoming/target contexts identify the precise membership change.\n\nTwo existing authored tests qualify the extended reader, including successful\nexchange and strict rejection of a 0.0007 mm² material increase. Eleven malformed\nrecords are rejected, including missing contexts/snapshots, changed identities\nor boundaries, nonfinite geometry, forbidden poses and invalid acceptance.\n\nInstrumentation is reversible to the exact rejected source before formatting;\nthe other 147 files and production are unchanged. No proposal policy, work\ncharge or repair cap changes. Geometry capture and snapshot reconstruction can\nconsume wall time and perturb deadlines, so this is not a quality comparison.\n\nAfter committing the plan, observe only four serial 60-second seed-zero cases:\nboth mechanical development jobs and kerfs, physical CCD0 CPU 8. An independent\nShapely audit will compare summed collision-polygon area with the shortened\ncontainer, original filled outer area with full usable physical stock, and\nsaved initial/repaired overlap and outside area. A bound below one does not\nestablish feasibility; an overfull shortened assignment does not establish\nglobal impossibility. Preserve every outcome. H2/H5 remain open at 60%.\n',encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in ['h5-return-capacity-preparation-20261017','h5-return-capacity-diagnosis-20261017']:
        f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n## 2026-10-17 — Prepare complete return-sheet capacity observations\n\n[The isolated capacity observer](benchmarks/results/h5-return-capacity-preparation-20261017.md)\npasses 90 optimized tests, strict lint, build and two authored trace captures.\nEleven malformed-record mutations are rejected. The original rejected candidate\nand production remain unchanged; instrumentation is exactly reversible before\nformatting. All source, binary, log and archive members are verified.\n\nFour committed-plan serial diagnostics will capture actual shortened boundaries,\nall source/receiver parts and initial/best repaired geometry. Independent area,\noverlap and outside checks will distinguish an overfull assignment from a poor\nplacement without assuming full stock is available in a compressed search sheet.\nCapture overhead can perturb deadlines. No repeated quality pilot, relaxed\nlimit, reserved-input access or H5 credit. H2/H5 remain open at 60%.\n')
print(json.dumps({'sealed':str(out),'members':len(inventory),'bytes':raw.stat().st_size}))
