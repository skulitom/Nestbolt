"""Build and check diagnostic-only H5 observer on CCD1, without measurements."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, subprocess, sys, traceback
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-return-capacity-diagnosis-20261017'
WORK=OUT/'workspace';TARGET=ROOT/'output/h5-return-capacity-target-20261017'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(OUT/'preparation.json');records=[]
shutil.copyfile(WORK/plan['changed_file'],OUT/'exchange-before-format.rs')
write(OUT/'build-opened.json',{'utc':datetime.now(timezone.utc).isoformat()})
def guards():
    sys.path.insert(0,str(ROOT/'scripts'))
    from h2_import_audit import source_digest
    assert source_digest()==plan['production_digest']
    for r in plan['source_files']:
        assert digest(Path(plan['old_source'])/r['path'])==r['sha256']
        if r['path']!=plan['changed_file']:assert digest(WORK/r['path'])==r['sha256']
def run(label,args):
    guards();started=datetime.now(timezone.utc).isoformat();command=[sys.executable,str(ROOT/'output/ccd1.py'),*map(str,args)]
    with (OUT/(label+'.log')).open('xb') as log:
        p=subprocess.run(command,cwd=WORK,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    row={'label':label,'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'log_sha256':digest(OUT/(label+'.log'))}
    records.append(row);write(OUT/'progress.json',records);print(json.dumps(row),flush=True)
    assert p.returncode==0,label
try:
    run('format',['cargo','fmt','--all'])
    run('core-tests',['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',TARGET])
    run('clippy',['cargo','clippy','--locked','-p','nestbolt-core','--lib','--example','exchange_probe','--target-dir',TARGET,'--','-D','warnings'])
    run('observer',['cargo','build','--release','--locked','-p','nestbolt-core','--example','exchange_probe','--target-dir',TARGET])
    guards();shutil.copyfile(TARGET/'release/examples/exchange_probe.exe',OUT/'exchange-diagnosis.exe')
    write(OUT/'build.json',{'all_passed':True,'stages':records,'source_sha256':digest(WORK/plan['changed_file']),'binary_sha256':digest(OUT/'exchange-diagnosis.exe'),'prior_experiment_unchanged':True,'production_unchanged':True,'measured_search_started':False})
except BaseException:
    write(OUT/'build-failure.json',{'error':traceback.format_exc(),'stages':records});raise
