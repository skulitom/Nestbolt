"""Derive reversible geometry-only instrumentation from the qualified frame trace."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/prepare_h5_return_frame_stage_diagnosis.py').read_text(encoding='utf-8')
s=s.replace('h5-return-frame-stage-diagnosis-20261017','h5-return-capacity-diagnosis-20261017').replace('h5-return-frame-stage-target-20261017','h5-return-capacity-target-20261017')
s=s.replace("'purpose':'Observe reciprocal-frame legality/fallback, actual poses, initial/final repair losses and independently validated material rejection. No quality inference or changed search decisions.'", "'purpose':'Observe complete source/receiver collision polygons, actual shortened containers, initial and repaired snapshots, identity and public poses, with prior frame/stage observations. Instrumentation overhead may perturb deadlines; no quality or global infeasibility claim.'")
extra=r'''
replace('    attempts: Vec<AttemptTrace>,', '    attempts: Vec<AttemptTrace>,\n    contexts: Vec<serde_json::Value>,')
replace('    frame: serde_json::Value,', '''+'"""'+'''    frame: serde_json::Value,
    context_index: usize,
    receiver_initial: serde_json::Value,
    source_initial: serde_json::Value,
    receiver_repaired: Option<serde_json::Value>,
    source_repaired: Option<serde_json::Value>,'''+ '"""'+''')
replace('                        frame: serde_json::Value::Null,', '''+'"""'+'''                        frame: serde_json::Value::Null,
                        context_index,
                        receiver_initial: serde_json::Value::Null,
                        source_initial: serde_json::Value::Null,
                        receiver_repaired: None, source_repaired: None,'''+ '"""'+''')
replace('                let proposal_until = self.last_step(until);', '''+'"""'+'''                let context_index = trace.contexts.len();
                trace.contexts.push(serde_json::json!({
                    "source_after_removal":observed_layout(&source, self.model),
                    "receiver_before_removal":observed_layout(&receiver, self.model),
                    "incoming":{"external_id":incoming_item.external_id(), "item_index":incoming_item.idx(),
                        "area_hint":incoming_item.area(), "pose":observed_pose(incoming_old),
                        "public_transform":self.model.external(incoming_item.idx(), &incoming_old)},
                    "target_index":target, "last_index":last_index, "frozen_sheets":frozen.len(),
                    "shape_last":shape.last, "full_width":self.model.full_width
                }));
                let proposal_until = self.last_step(until);'''+ '"""'+''')
replace('                    let now = self.clock.now();', '''+'"""'+'''                    trace.attempts[index].receiver_initial = observed_layout(&next_receiver, self.model);
                    trace.attempts[index].source_initial = observed_layout(&next_source, self.model);
                    let now = self.clock.now();'''+ '"""'+''')
replace('                    trace.attempts[index].receiver_loss = Some(receiver_tracker.total_loss());', '''+'"""'+'''                    trace.attempts[index].receiver_repaired = Some(observed_layout(&JLayout::from_snapshot(&receiver_snapshot), self.model));
                    trace.attempts[index].receiver_loss = Some(receiver_tracker.total_loss());'''+ '"""'+''')
replace('                    trace.attempts[index].source_loss = Some(source_tracker.total_loss());', '''+'"""'+'''                    trace.attempts[index].source_repaired = Some(observed_layout(&JLayout::from_snapshot(&source_snapshot), self.model));
                    trace.attempts[index].source_loss = Some(source_tracker.total_loss());'''+ '"""'+''')
replace('map(|(((_,item,previous),actual),(hypothetical,allowed))| {', 'map(|(((key,item,previous),actual),(hypothetical,allowed))| {')
replace('serde_json::json!({"external_id":item.external_id(),"previous":observed_pose(*previous),', 'serde_json::json!({"receiver_key":format!("{key:?}"),"external_id":item.external_id(),"previous":observed_pose(*previous),')
layout_helper=r'''+'"""'+'''
fn observed_layout(layout: &JLayout, model: &Model<'_>) -> serde_json::Value {
    let container = layout.container().outer_cd();
    let boundary: Vec<_> = container.vertices().iter().map(|p| [p.x(),p.y()]).collect();
    let items: Vec<_> = layout.placed_items().iter().map(|(key,p)| {
        let polygon: Vec<_> = p.shape().vertices().iter().map(|v| [v.x(),v.y()]).collect();
        serde_json::json!({"key":format!("{key:?}"), "item_index":p.item().idx(),
            "external_id":p.item().external_id(), "pose":observed_pose(p.d_transf()),
            "public_transform":model.external(p.item().idx(), &p.d_transf()),
            "area_hint":p.item().area(), "polygon":polygon})
    }).collect();
    serde_json::json!({"container":boundary,"items":items})
}

'''+ '"""'+'''
replace('struct Proposal {',layout_helper+'struct Proposal {')

'''
assert s.count('reverse=text')==1
s=s.replace('reverse=text',extra+'reverse=text')
p=root/'output/prepare_h5_return_capacity_diagnosis.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
s=(root/'output/build_h5_return_frame_stage_diagnosis.py').read_text(encoding='utf-8').replace('h5-return-frame-stage','h5-return-capacity')
p=root/'output/build_h5_return_capacity_diagnosis.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
print('Prepared reversible capacity-observer drivers; no candidate decisions changed.')
