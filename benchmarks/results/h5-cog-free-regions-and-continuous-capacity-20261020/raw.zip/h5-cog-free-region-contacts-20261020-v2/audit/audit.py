"""Independently check all sampled cog poses, old filters and complete pair graph."""
from collections import deque
import gzip, json, math, shutil, time
import numpy as np
import shapely
from shapely.geometry import shape as read_shape
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT, SRC as ORIGINAL, load, write, digest

SOURCE = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
RUN = ROOT / 'output/h5-cog-free-region-contacts-20261020-v2'
OUT = RUN / 'audit'

def polygons(g):
    if g.is_empty:
        return []
    if g.geom_type == 'Polygon':
        return [g]
    return [p for child in g.geoms for p in polygons(child)] if hasattr(g, 'geoms') else []

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'audit.py')
    start = time.perf_counter()
    plan = load(RUN / 'plan.json')
    for p, h in plan['inputs'].items():
        assert digest(ROOT / p) == h
    pool = load(RUN / 'candidates.json')
    source = load(SOURCE / 'candidates.json')
    assert len(source) == 9299 and pool[:9299] == source
    job = load(ORIGINAL / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    target = load(ORIGINAL / 'conditional-target.json')
    stock = job['stocks'][0]
    m, edge, clearance = stock['margins'], job['edge_clearance'], job['clearance']
    mp = load(RUN / 'mapping.json')
    fixed = mp['fixed_non_cog_candidates']
    fixed_geometry = {i: shape(parts[pool[i]['placement']['part_id']], pool[i]['placement']['transform']) for i in fixed}
    geometry = {}
    filtering_pairs = 0
    expected_filter = []
    eligible = []
    for i, p in enumerate(source):
        if p['placement']['part_id'] != 'cog':
            continue
        g = shape(parts['cog'], p['placement']['transform'])
        blockers = []
        for j in fixed:
            if p['placement']['sheet_id'] != pool[j]['placement']['sheet_id']:
                continue
            filtering_pairs += 1
            if g.distance(fixed_geometry[j]) < clearance - 1e-7:
                blockers.append(j)
        expected_filter.append({'candidate': i, 'fixed_blockers': blockers})
        if not blockers:
            eligible.append(i)
            geometry[i] = g
    assert expected_filter == load(RUN / 'old-cog-filter.json')
    assert eligible == mp['original_eligible_cogs']
    queries = [load(p) for p in sorted((RUN / 'regions').glob('query-*.json'))]
    assert [(q['sheet_id'], q['phase_degrees']) for q in queries] == [
        (sheet, phase) for sheet in ['sheet-0', 'sheet-1'] for phase in plan['phases_degrees']]
    for qi, q in enumerate(queries):
        assert q['index'] == qi and q['rotation_radians'] == math.radians(q['phase_degrees'])
        region = read_shape(q['region'])
        assert region.is_valid and q['region_empty'] == region.is_empty and abs(q['region_area'] - region.area) < 1e-6
        expected_proposals = []
        seen = set()
        for pi, p in enumerate(polygons(region)):
            point = p.representative_point()
            generated = [{'kind': 'representative', 'polygon': pi, 'point': [point.x, point.y]}]
            for ri, ring in enumerate([p.exterior] + list(p.interiors)):
                coords = list(ring.coords)[:-1]
                for vi in range(len(coords)):
                    a, b = coords[vi], coords[(vi + 1) % len(coords)]
                    generated.append({'kind': 'vertex', 'polygon': pi, 'ring': ri, 'vertex': vi, 'point': list(a)})
                    generated.append({'kind': 'edge-midpoint', 'polygon': pi, 'ring': ri, 'vertex': vi,
                                      'point': [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]})
            for point in generated:
                identity = tuple(float(v).hex() for v in point['point'])
                if identity not in seen:
                    expected_proposals.append(point)
                    seen.add(identity)
        assert expected_proposals == q['proposals']
    expected_order = []
    pending = deque((q['index'], 0) for q in queries if q['proposals'])
    while pending:
        qi, pi = pending.popleft()
        expected_order.append((qi, pi))
        if pi + 1 < len(queries[qi]['proposals']):
            pending.append((qi, pi + 1))
    events = load(RUN / 'source-events.json')
    assert [(e['query'], e['proposal']) for e in events] == expected_order
    assert load(RUN / 'pending-queries.json') == []
    new = []
    new_fixed_pairs = 0
    for e in events:
        q = queries[e['query']]
        proposal = q['proposals'][e['proposal']]
        p = {'part_id': 'cog', 'sheet_id': q['sheet_id'],
             'transform': {'rotation_radians': q['rotation_radians'], 'translation': proposal['point'], 'mirrored': False}}
        assert e.get('reason') != 'original_geometry_rejection'
        i = e['candidate']
        assert pool[i]['placement'] == p
        if e['added']:
            assert i == len(source) + len(new)
            assert pool[i]['source'] == {'kind': 'cog-free-region-contact', 'query': e['query'], 'proposal': e['proposal']}
            new.append(i)
        else:
            assert e['reason'] == 'exact_duplicate' and (i in eligible or i in new)
        g = shape(parts['cog'], p['transform'])
        x0, y0, x1, y1 = g.bounds
        height = stock['height'] if q['sheet_id'] == 'sheet-0' else target['required_used_height_mm']
        assert g.is_valid and not p['transform']['mirrored'] and parts['cog']['rotations']['kind'] == 'free'
        assert x0 >= m['left'] + edge - 1e-7 and y0 >= m['bottom'] + edge - 1e-7
        assert x1 <= stock['width'] - m['right'] - edge + 1e-7 and y1 <= height - m['top'] - edge + 1e-7
        for j in fixed:
            if q['sheet_id'] == pool[j]['placement']['sheet_id']:
                new_fixed_pairs += 1
                assert g.disjoint(fixed_geometry[j]) and g.distance(fixed_geometry[j]) >= clearance - 1e-7
        geometry[i] = g
    assert new == mp['new_cog_candidates']
    ids = mp['candidates']
    assert ids == sorted(eligible + new)
    gs = np.asarray([geometry[i] for i in ids], dtype=object)
    bounds = shapely.bounds(gs)
    sheets = np.asarray([pool[i]['placement']['sheet_id'] for i in ids])
    adjacency = [0] * len(ids)
    exact_edges = set()
    all_pairs = near_pairs = 0
    for i in range(len(ids)):
        js = np.arange(i + 1, len(ids))
        js = js[sheets[js] == sheets[i]]
        all_pairs += len(js)
        dx = np.maximum(0, np.maximum(bounds[js, 0] - bounds[i, 2], bounds[i, 0] - bounds[js, 2]))
        dy = np.maximum(0, np.maximum(bounds[js, 1] - bounds[i, 3], bounds[i, 1] - bounds[js, 3]))
        js = js[np.hypot(dx, dy) <= clearance + 1e-7]
        near_pairs += len(js)
        for j in js[shapely.distance(gs[i], gs[js]) < clearance - 1e-7]:
            j = int(j)
            exact_edges.add((i, j))
            adjacency[i] |= 1 << j
            adjacency[j] |= 1 << i
    with gzip.open(RUN / 'conflicts.jsonl.gz', 'rt', encoding='utf-8') as f:
        saved = [tuple(json.loads(line)) for line in f]
    assert len(saved) == len(exact_edges) and set(saved) == exact_edges
    covered = [0] * len(ids)
    with gzip.open(RUN / 'cliques.jsonl.gz', 'rt', encoding='utf-8') as f:
        cliques = [json.loads(line) for line in f]
    for c in cliques:
        assert len(c) == len(set(c)) and all(0 <= i < len(ids) for i in c)
        mask = sum(1 << i for i in c)
        for i in c:
            others = mask ^ (1 << i)
            assert not(others & ~adjacency[i])
            covered[i] |= others
    assert covered == adjacency
    seed = {ids.index(i) for i in mp['seed_cog_candidates']}
    assert len(seed) == 9
    sm = sum(1 << i for i in seed)
    assert all(not(adjacency[i] & sm) for i in seed)
    check = {'all_old_candidates_preserved_exactly': True, 'all_original_cog_filters_exact': True,
             'original_cog_fixed_pairs_checked': filtering_pairs,
             'regions_and_sampling_orders_reconstructed': len(queries), 'all_declared_samples_processed': len(events),
             'new_cog_poses_checked': len(new), 'sampled_cog_fixed_pairs_checked': new_fixed_pairs,
             'all_cog_pairs_exhaustively_examined': all_pairs, 'near_pair_distances_checked': near_pairs,
             'exact_conflicts': len(exact_edges), 'all_cliques_pairwise_valid_and_complete': True,
             'cliques': len(cliques), 'known_nine_cog_seed_preserved': True,
             'seconds': time.perf_counter() - start, 'full_target_witness': False,
             'unrestricted_impossibility_claimed': False}
    write(OUT / 'checks.json', check)
    print(json.dumps(check), flush=True)

if __name__ == '__main__':
    main()
