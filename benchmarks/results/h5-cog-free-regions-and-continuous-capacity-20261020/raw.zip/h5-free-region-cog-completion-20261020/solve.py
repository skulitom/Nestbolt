"""One audited cog-only completion solve using all retained free-region contacts."""
from datetime import datetime, timezone
import gzip, json, shutil, time
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT, load, write, digest

SRC = ROOT / 'output/h5-cog-free-region-contacts-20261020-v2'
OUT = ROOT / 'output/h5-free-region-cog-completion-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'solve.py')
    sources = [SRC / n for n in ['plan.json', 'candidates.json', 'mapping.json', 'cliques.jsonl.gz', 'audit/checks.json']]
    assert load(SRC / 'audit/checks.json')['all_cliques_pairwise_valid_and_complete']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'seconds_limit': 20, 'workers': 8, 'seed': 0,
        'method': 'Hold all51 audited non-cog poses fixed. Select from all608 compatible original and437 new cog poses, preserving the full pair graph through883 audited cliques. Maximize cog count from the valid nine-cog seed through the unchanged required15. Reconstruct every model field and complete feasible hint before one bounded solve; no retry.',
        'scope': 'Only this fixed non-cog arrangement and finite cog pool. Any shortage remains an original-job failure; even a finite optimum is not unrestricted geometric impossibility.',
        'native_packing_calls': 0, 'quality_runs': 0})
    mapping = load(SRC / 'mapping.json')
    ids = mapping['candidates']
    fixed = mapping['fixed_non_cog_candidates']
    seed = set(mapping['seed_cog_candidates'])
    with gzip.open(SRC / 'cliques.jsonl.gz', 'rt', encoding='utf-8') as f:
        source_rows = [json.loads(line) for line in f]
    rows = sorted({tuple(sorted(row)) for row in source_rows})
    model = cp_model.CpModel()
    variables = [model.new_bool_var(f'p{i}') for i in ids]
    for row in rows:
        model.add_at_most_one(variables[j] for j in row)
    model.add_linear_constraint(sum(variables), 9, 15)
    model.maximize(sum(variables))
    hint = [int(i in seed) for i in ids]
    assert sum(hint) == 9
    for j, value in enumerate(hint):
        model.add_hint(variables[j], value)
    assert model.validate() == ''
    model.export_to_file(str(OUT / 'model.pbtxt'))
    expected = cp_model_pb2.CpModelProto()
    for i in ids:
        v = expected.variables.add()
        v.name = f'p{i}'
        v.domain.extend([0, 1])
    for row in sorted(set(tuple(sorted(set(c))) for c in source_rows)):
        expected.constraints.add().at_most_one.literals.extend(row)
    c = expected.constraints.add().linear
    c.vars.extend(range(len(ids)))
    c.coeffs.extend([1] * len(ids))
    c.domain.extend([9, 15])
    expected.objective.vars.extend(range(len(ids)))
    expected.objective.coeffs.extend([-1] * len(ids))
    expected.objective.scaling_factor = -1
    expected.solution_hint.vars.extend(range(len(ids)))
    expected.solution_hint.values.extend(hint)
    actual = text_format.Parse((OUT / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
    assert actual.SerializeToString(deterministic=True) == expected.SerializeToString(deterministic=True)
    assert all(sum(hint[j] for j in c.at_most_one.literals) <= 1
               for c in actual.constraints if c.WhichOneof('constraint') == 'at_most_one')
    write(OUT / 'mapping.json', {'candidates': ids, 'fixed_non_cog_candidates': fixed, 'complete_hint': hint})
    write(OUT / 'model-audit.json', {
        'all_model_fields_independently_reconstructed': True, 'complete_hint_exactly_feasible': True,
        'variables': len(ids), 'constraints': len(actual.constraints),
        'model_sha256': digest(OUT / 'model.pbtxt')})
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 20
    solver.parameters.num_search_workers = 8
    solver.parameters.random_seed = 0
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = False
    (OUT / 'parameters.pbtxt').write_text(str(solver.parameters), encoding='utf-8', newline='\n')
    records = []
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            cogs = [i for j, i in enumerate(ids) if self.value(variables[j])]
            r = {'index': len(records), 'selected_indices': sorted(fixed + cogs),
                 'cogs': len(cogs), 'seconds': self.wall_time,
                 'objective': self.objective_value, 'best_bound': self.best_objective_bound}
            assert r['cogs'] == r['objective']
            write(OUT / f"incumbent-{r['index']}.json", r)
            records.append(r)
            print(json.dumps({k: v for k, v in r.items() if k != 'selected_indices'}), flush=True)
    write(OUT / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'seconds_limit': 20})
    with (OUT / 'solver.log').open('x', encoding='utf-8', newline='\n') as log:
        solver.log_callback = lambda s: (log.write(s + '\n'), log.flush())
        start = time.perf_counter()
        status = solver.solve(model, Capture())
        seconds = time.perf_counter() - start
    feasible = status in [cp_model.FEASIBLE, cp_model.OPTIMAL]
    result = {'status': solver.status_name(status), 'seconds': seconds, 'incumbents': len(records),
              'feasible': feasible, 'response_stats': solver.response_stats(),
              'full_target_witness': False, 'native_margin_qualified': False}
    if feasible:
        cogs = [i for j, i in enumerate(ids) if solver.value(variables[j])]
        write(OUT / 'selected-indices.json', sorted(fixed + cogs))
        result.update(cogs=len(cogs), missing_cogs=15 - len(cogs),
                      best_bound=solver.best_objective_bound, full_inventory_candidate=len(cogs) == 15)
    else:
        assert not records
    write(OUT / 'result.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'response_stats'}), flush=True)

if __name__ == '__main__':
    main()
