"""Audit every cog completion and a separate clique-cover upper certificate."""
from collections import Counter, defaultdict
from itertools import combinations
import copy, gzip, json, math, shutil, subprocess
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT, SRC as ORIGINAL, load, write, digest
from census_h5_one_part_moves import bits

POOL = ROOT / 'output/h5-cog-free-region-contacts-20261020-v2'
JOINT = ROOT / 'output/h5-joint-full-frame-small-search-20261020'
RUN = ROOT / 'output/h5-free-region-cog-completion-20261020'
OUT = RUN / 'audit'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'audit.py')
    for p, h in load(RUN / 'plan.json')['inputs'].items():
        assert digest(ROOT / p) == h
    pool = load(POOL / 'candidates.json')
    job = load(ORIGINAL / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    stock = job['stocks'][0]
    m, edge = stock['margins'], job['edge_clearance']
    target = load(ORIGINAL / 'conditional-target.json')
    mapping = load(RUN / 'mapping.json')
    ids = mapping['candidates']
    local = {i: j for j, i in enumerate(ids)}
    fixed = set(mapping['fixed_non_cog_candidates'])
    allowed = set(ids) | fixed
    with gzip.open(POOL / 'cliques.jsonl.gz', 'rt', encoding='utf-8') as f:
        cliques = [set(json.loads(line)) for line in f]
    seed = load(JOINT / 'selected-indices.json')
    old_layout = load(JOINT / 'audit/layout-final.json')
    result = load(RUN / 'result.json')
    outcomes = [load(RUN / f'incumbent-{i}.json') for i in range(result['incumbents'])]
    if result['feasible']:
        final = load(RUN / 'selected-indices.json')
        if not outcomes or outcomes[-1]['selected_indices'] != final:
            outcomes.append({'index': 'final', 'selected_indices': final, 'cogs': result['cogs']})
    else:
        assert not outcomes
    cli = ROOT / 'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli) == '97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    records = []
    fresh = reused = 0
    for r in outcomes:
        chosen = set(r['selected_indices'])
        assert len(chosen) == len(r['selected_indices']) and fixed <= chosen <= allowed
        selected_local = {local[i] for i in chosen - fixed}
        assert all(len(c & selected_local) <= 1 for c in cliques)
        counts = Counter()
        placements = []
        geoms = defaultdict(list)
        tops = Counter()
        for i in r['selected_indices']:
            p = copy.deepcopy(pool[i]['placement'])
            part, t = parts[p['part_id']], p['transform']
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind'] == 'list':
                assert any(abs(math.remainder(t['rotation_radians'] - math.radians(a), math.tau)) < 1e-9
                           for a in part['rotations']['degrees'])
            p['copy_index'] = counts[p['part_id']]
            counts[p['part_id']] += 1
            placements.append(p)
            g = shape(part, t)
            x0, y0, x1, y1 = g.bounds
            height = stock['height'] if p['sheet_id'] == 'sheet-0' else target['required_used_height_mm']
            assert g.is_valid and x0 >= m['left'] + edge - 1e-7 and y0 >= m['bottom'] + edge - 1e-7
            assert x1 <= stock['width'] - m['right'] - edge + 1e-7 and y1 <= height - m['top'] - edge + 1e-7
            geoms[p['sheet_id']].append(g)
            tops[p['sheet_id']] = max(tops[p['sheet_id']], y1 + m['top'] + edge)
        assert counts == Counter(frame=18, bracket=12, insert=21, cog=r['cogs']) and 9 <= r['cogs'] <= 15
        minimum = math.inf
        pairs = 0
        for gs in geoms.values():
            for a, b in combinations(gs, 2):
                pairs += 1
                minimum = min(minimum, a.distance(b))
                assert a.disjoint(b) and a.distance(b) >= job['clearance'] - 1e-7
        key = r['index']
        layout = {'version': 1, 'units': 'mm', 'sheets': old_layout['sheets'], 'placements': placements}
        path = OUT / f'layout-{key}.json'
        write(path, layout)
        if r['selected_indices'] == seed:
            assert layout == old_layout
            public = load(JOINT / 'audit/public-final.json')
            code = load(JOINT / 'audit/command-final.json')['exit_code']
            write(OUT / f'validation-reuse-{key}.json', {
                'rerun': False, 'exact_layout_match': True,
                'source_files': {str((JOINT / n).relative_to(ROOT)): digest(JOINT / n)
                                 for n in ['audit/layout-final.json', 'audit/public-final.json', 'audit/command-final.json']}})
            shutil.copyfile(JOINT / 'audit/public-final.json', OUT / f'public-{key}.json')
            reused += 1
        else:
            cmd = [str(cli), 'validate', '--library', str(ORIGINAL / 'library.json'),
                   '--request', str(ORIGINAL / 'request.json'), '--layout', str(path)]
            cp = subprocess.run(cmd, capture_output=True, timeout=60)
            code = cp.returncode
            (OUT / f'public-{key}.json').write_bytes(cp.stdout)
            (OUT / f'public-{key}.stderr').write_bytes(cp.stderr)
            write(OUT / f'command-{key}.json', {'command': cmd, 'exit_code': code})
            public = json.loads(cp.stdout)
            fresh += 1
        assert public['valid'] == (r['cogs'] == 15)
        if r['cogs'] < 15:
            assert code != 0 and public['violations'] == [
                {'code': 'quantity', 'message': f"part cog: expected 15, found {r['cogs']}"}]
        else:
            assert code == 0 and not public['violations']
        material = stock['width'] * (stock['height'] + tops['sheet-1'])
        assert material <= target['target_material_mm2'] + 1e-6
        records.append({'incumbent': key, 'cogs': r['cogs'], 'missing_cogs': 15 - r['cogs'],
                        'new_contact_cogs_used': sum(i >= 9299 for i in chosen),
                        'pairs': pairs, 'minimum_distance_mm': minimum, 'charged_material_mm2': material,
                        'filled_area_mm2': sum(g.area for gs in geoms.values() for g in gs),
                        'original_CLI_valid': public['valid'], 'exact_seed_result_reused': r['selected_indices'] == seed})
    options = {}
    for ci, c in enumerate(cliques):
        options.setdefault(sum(1 << i for i in c), ci)
    remaining = (1 << len(ids)) - 1
    cover = []
    while remaining:
        best = max(options, key=lambda mask: ((mask & remaining).bit_count(), -options[mask]), default=0)
        covered = best & remaining
        ci = options[best] if covered.bit_count() > 1 else None
        if ci is None:
            covered = remaining & -remaining
        cover.append({'source_clique': ci, 'local_candidates': list(bits(covered))})
        remaining &= ~covered
    seen = set()
    for row in cover:
        vertices = set(row['local_candidates'])
        assert vertices and not(vertices & seen)
        if row['source_clique'] is None:
            assert len(vertices) == 1
        else:
            assert vertices <= cliques[row['source_clique']]
        seen |= vertices
    assert seen == set(range(len(ids)))
    write(OUT / 'clique-cover.json', cover)
    best_count = max((r['cogs'] for r in records), default=0)
    check = {'all_returned_layouts_checked': len(records), 'records': records,
             'fresh_frozen_CLI_calls': fresh, 'reused_frozen_CLI_results': reused,
             'best_cog_count': best_count, 'independently_verified_clique_cover_bound': len(cover),
             'finite_pool_optimum_independently_certified': best_count == len(cover),
             'original_15_cogs_ruled_out_by_cover': len(cover) < 15,
             'scope': 'Only these1045 cog poses with the51 non-cog poses fixed.',
             'full_target_witness': any(r['original_CLI_valid'] for r in records),
             'native_margin_qualified': False, 'native_packing_calls': 0, 'quality_runs': 0}
    write(OUT / 'checks.json', check)
    print(json.dumps({k: v for k, v in check.items() if k != 'records'}), flush=True)

if __name__ == '__main__':
    main()
