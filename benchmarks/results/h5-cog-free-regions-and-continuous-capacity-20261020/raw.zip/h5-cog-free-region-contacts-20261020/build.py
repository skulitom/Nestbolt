"""Generate cog-only contacts in free translation regions of the latest full non-cog set."""
from collections import Counter, deque
from datetime import datetime, timezone
import copy, gzip, heapq, itertools, json, math, shutil, time, traceback
import numpy as np
import shapely
from shapely.geometry import mapping
from shapely.strtree import STRtree
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT, SRC as ORIGINAL, load, write, digest
from census_h5_one_part_moves import bits

POOL = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
JOINT = ROOT / 'output/h5-joint-full-frame-small-search-20261020'
OUT = ROOT / 'output/h5-cog-free-region-contacts-20261020'
SECONDS = 120
MAX_NEW = 2000

def identity(p):
    t = p['transform']
    return (p['part_id'], p['sheet_id'], t['mirrored'],
            float(t['rotation_radians']).hex(), *(float(x).hex() for x in t['translation']))

def proposals(region):
    result = []
    seen = set()
    for pi, poly in enumerate(gap.polygons(region)):
        pt = poly.representative_point()
        raw = [{'kind': 'representative', 'polygon': pi, 'point': [pt.x, pt.y]}]
        for ri, ring in enumerate([poly.exterior] + list(poly.interiors)):
            coords = list(ring.coords)[:-1]
            for vi, (a, b) in enumerate(zip(coords, coords[1:] + coords[:1])):
                raw.append({'kind': 'vertex', 'polygon': pi, 'ring': ri, 'vertex': vi, 'point': list(a)})
                raw.append({'kind': 'edge-midpoint', 'polygon': pi, 'ring': ri, 'vertex': vi,
                            'point': [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]})
        for r in raw:
            key = tuple(float(x).hex() for x in r['point'])
            if key not in seen:
                seen.add(key)
                result.append(r)
    return result

def main():
    OUT.mkdir()
    (OUT / 'regions').mkdir()
    shutil.copyfile(__file__, OUT / 'build.py')
    sources = [POOL / 'candidates.json', JOINT / 'selected-indices.json', JOINT / 'audit/checks.json',
               ORIGINAL / 'job.json', ORIGINAL / 'conditional-target.json', Path(gap.__file__)]
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'generation_seconds_limit': SECONDS, 'maximum_new_cogs': MAX_NEW,
        'phases_degrees': [0.0, 4.5, 9.0, 13.5],
        'generation': 'Fix all51 non-cog poses of the audited joint final. Preserve the entire old9299-pose pool/indexes and retain every original cog pose compatible with those51. For each declared phase on each target sheet, construct original-outline conservative Minkowski free translation regions using the audited helper. Retain each polygon representative point plus every outer/hole boundary vertex and edge midpoint. Exact transform deduplication only. Cycle over query point lists round-robin until the2000-new-pose or120-second limit; keep unfinished queries and all tested events. Boundaries are a finite construction, never an exhaustive free-rotation proof.',
        'geometry': 'Original filled outer outlines; unchanged stock, edge margins, clearance and target used height. Helper EPS0.0001 is a positive construction margin, not a changed acceptance tolerance or native-margin qualification.',
        'graph': 'Conditional on the51 fixed non-cog poses. Compute every same-sheet retained-cog pair from original filled geometry. Compress only verified cliques for at most10 seconds and retain every remaining edge. Independently check every candidate and every pair before solving.',
        'clique_seconds_limit': 10, 'selection_seconds_limit': 20,
        'selection': 'One cog-only model maximizing9..15 cogs, retaining the known nine-cog seed. Eight workers, seed0, no retry; all15 only becomes a candidate after original geometry/CLI checks.',
        'scope': 'This graph is not reusable with different non-cog positions. Partial cogs fail original quantities; absence of a candidate does not prove unrestricted impossibility.',
        'native_packing_calls': 0, 'quality_runs': 0})
    start = time.perf_counter()
    pool = copy.deepcopy(load(POOL / 'candidates.json'))
    old_count = len(pool)
    assert old_count == 9299
    job = load(ORIGINAL / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    target = load(ORIGINAL / 'conditional-target.json')
    stock = job['stocks'][0]
    selected = set(load(JOINT / 'selected-indices.json'))
    fixed = {i for i in selected if pool[i]['placement']['part_id'] != 'cog'}
    seed = selected - fixed
    assert len(fixed) == 51 and len(seed) == 9
    assert Counter(pool[i]['placement']['part_id'] for i in fixed) == Counter(frame=18, bracket=12, insert=21)
    geometry = {i: shape(parts[pool[i]['placement']['part_id']], pool[i]['placement']['transform'])
                for i in fixed | {i for i, p in enumerate(pool) if p['placement']['part_id'] == 'cog'}}
    fixed_here = {sheet: sorted(i for i in fixed if pool[i]['placement']['sheet_id'] == sheet)
                  for sheet in ['sheet-0', 'sheet-1']}
    eligible_old = []
    old_filter = []
    for i, p in enumerate(pool):
        if p['placement']['part_id'] != 'cog':
            continue
        blockers = [j for j in fixed_here[p['placement']['sheet_id']]
                    if geometry[i].distance(geometry[j]) < job['clearance'] - 1e-7]
        old_filter.append({'candidate': i, 'fixed_blockers': blockers})
        if not blockers:
            eligible_old.append(i)
    assert seed <= set(eligible_old)
    keys = {identity(p['placement']): i for i, p in enumerate(pool)}
    assert len(keys) == len(pool)
    queries = []
    generation_expired = False
    for sheet in ['sheet-0', 'sheet-1']:
        this_stock = copy.deepcopy(stock)
        if sheet == 'sheet-1':
            this_stock['height'] = target['required_used_height_mm']
        for angle_degrees in [0.0, 4.5, 9.0, 13.5]:
            if time.perf_counter() - start >= SECONDS:
                generation_expired = True
                break
            angle = math.radians(angle_degrees)
            moving = shape(parts['cog'], {'rotation_radians': angle, 'translation': [0, 0], 'mirrored': False})
            region_start = time.perf_counter()
            region = gap.regions(moving, [geometry[i] for i in fixed_here[sheet]],
                                 this_stock, job['edge_clearance'], job['clearance'])
            query = {'index': len(queries), 'sheet_id': sheet, 'phase_degrees': angle_degrees,
                     'rotation_radians': angle, 'region_seconds': time.perf_counter() - region_start,
                     'region_empty': region.is_empty, 'region_area': region.area,
                     'region': mapping(region), 'proposals': proposals(region)}
            write(OUT / 'regions' / f"query-{query['index']}.json", query)
            queries.append(query)
            print(json.dumps({k: query[k] for k in ['index', 'sheet_id', 'phase_degrees', 'region_seconds', 'region_empty']}
                             | {'proposals': len(query['proposals'])}), flush=True)
        if generation_expired:
            break
    queue = deque((q['index'], 0) for q in queries if q['proposals'])
    events = []
    added = []
    while queue and len(added) < MAX_NEW:
        if time.perf_counter() - start >= SECONDS:
            generation_expired = True
            break
        qi, pi = queue.popleft()
        q = queries[qi]
        proposal = q['proposals'][pi]
        p = {'part_id': 'cog', 'sheet_id': q['sheet_id'],
             'transform': {'rotation_radians': q['rotation_radians'],
                           'translation': proposal['point'], 'mirrored': False}}
        g = shape(parts['cog'], p['transform'])
        a, b, c, d = g.bounds
        m, edge = stock['margins'], job['edge_clearance']
        height = stock['height'] if q['sheet_id'] == 'sheet-0' else target['required_used_height_mm']
        outside = a < m['left'] + edge - 1e-7 or b < m['bottom'] + edge - 1e-7
        outside |= c > stock['width'] - m['right'] - edge + 1e-7 or d > height - m['top'] - edge + 1e-7
        blockers = [j for j in fixed_here[q['sheet_id']] if g.distance(geometry[j]) < job['clearance'] - 1e-7]
        event = {'query': qi, 'proposal': pi}
        if outside or blockers:
            event.update(added=False, reason='original_geometry_rejection', outside=bool(outside), blockers=blockers)
        elif identity(p) in keys:
            i = keys[identity(p)]
            assert i in eligible_old or i in added
            event.update(added=False, reason='exact_duplicate', candidate=i)
        else:
            i = len(pool)
            keys[identity(p)] = i
            pool.append({'index': i, 'placement': p,
                         'source': {'kind': 'cog-free-region-contact', 'query': qi, 'proposal': pi},
                         'filled_area_mm2': g.area})
            geometry[i] = g
            added.append(i)
            event.update(added=True, candidate=i)
        events.append(event)
        if pi + 1 < len(q['proposals']):
            queue.append((qi, pi + 1))
    generation_seconds = time.perf_counter() - start
    ids = sorted(eligible_old + added)
    write(OUT / 'candidates.json', pool)
    write(OUT / 'old-cog-filter.json', old_filter)
    write(OUT / 'source-events.json', events)
    write(OUT / 'pending-queries.json', list(queue))
    write(OUT / 'mapping.json', {'candidates': ids, 'fixed_non_cog_candidates': sorted(fixed),
                               'original_eligible_cogs': eligible_old, 'new_cog_candidates': added,
                               'seed_cog_candidates': sorted(seed)})
    # Build the entire retained cog graph; no uncomputed fixed-part or free-insert edges are inferred.
    gs = np.asarray([geometry[i] for i in ids], dtype=object)
    adjacency = [0] * len(ids)
    edges = []
    near = 0
    for sheet in ['sheet-0', 'sheet-1']:
        local = np.asarray([j for j, i in enumerate(ids) if pool[i]['placement']['sheet_id'] == sheet], dtype=int)
        if not len(local):
            continue
        tree = STRtree(gs[local])
        pairs = tree.query(gs[local], predicate='dwithin', distance=job['clearance'] + 1e-7)
        a, b = local[pairs[0]], local[pairs[1]]
        take = a < b
        a, b = a[take], b[take]
        near += len(a)
        take = shapely.distance(gs[a], gs[b]) < job['clearance'] - 1e-7
        for i, j in zip(a[take], b[take]):
            i, j = int(i), int(j)
            edges.append((i, j))
            adjacency[i] |= 1 << j
            adjacency[j] |= 1 << i
    remaining = adjacency.copy()
    heap = [(-a.bit_count(), i) for i, a in enumerate(remaining) if a]
    heapq.heapify(heap)
    cliques = []
    covered = 0
    compress_start = time.perf_counter()
    while heap and time.perf_counter() - compress_start < 10:
        degree, i = heapq.heappop(heap)
        if -degree != remaining[i].bit_count() or not remaining[i]:
            continue
        choices = remaining[i]
        clique = [i]
        mask = 1 << i
        while choices:
            sample = list(itertools.islice(bits(choices), 16))
            j = max(sample, key=lambda v: ((adjacency[v] & choices).bit_count(), -v))
            clique.append(j)
            mask |= 1 << j
            choices &= adjacency[j]
        assert all(not((mask ^ (1 << j)) & ~adjacency[j]) for j in clique)
        cliques.append(clique)
        for j in clique:
            before = remaining[j].bit_count()
            remaining[j] &= ~mask
            covered += before - remaining[j].bit_count()
            if remaining[j]:
                heapq.heappush(heap, (-remaining[j].bit_count(), j))
    compressed = len(cliques)
    residual = 0
    for i, mask in enumerate(remaining):
        for j in bits(mask & ~((1 << (i + 1)) - 1)):
            cliques.append([i, j])
            residual += 1
    assert covered // 2 + residual == len(edges)
    for name, rows in [('conflicts.jsonl.gz', sorted(edges)), ('cliques.jsonl.gz', cliques)]:
        with gzip.open(OUT / name, 'xt', encoding='utf-8', newline='\n') as f:
            for row in rows:
                f.write(json.dumps(row) + '\n')
    seed_locals = {ids.index(i) for i in seed}
    seedmask = sum(1 << i for i in seed_locals)
    assert all(not(adjacency[i] & seedmask) for i in seed_locals)
    result = {'original_pool_preserved': old_count, 'original_cogs_filtered': len(old_filter),
              'original_eligible_cogs': len(eligible_old), 'new_cog_poses': len(added),
              'total_cog_choices': len(ids), 'regions_completed': len(queries), 'declared_regions': 8,
              'generation_seconds': generation_seconds, 'generation_time_limit_reached': generation_expired,
              'new_pose_limit_reached': len(added) >= MAX_NEW, 'pending_queries': len(queue),
              'events': len(events), 'event_outcomes': dict(Counter(e.get('reason', 'added') for e in events)),
              'conflict_edges': len(edges), 'near_pair_distances': near,
              'compressed_cliques': compressed, 'residual_pair_constraints': residual,
              'clique_limit_reached': bool(heap), 'seed_cogs_preserved': len(seed),
              'total_seconds': time.perf_counter() - start, 'full_target_witness': False}
    write(OUT / 'generation.json', result)
    print(json.dumps(result), flush=True)

if __name__ == '__main__':
    try:
        main()
    except BaseException:
        if OUT.exists() and not (OUT / 'failure.txt').exists():
            (OUT / 'failure.txt').write_text(traceback.format_exc(), encoding='utf-8', newline='\n')
        raise
