"""Exhaustive independent choice replay and selected full model readback."""
from pathlib import Path
from hashlib import sha256
import json,time,os
import numpy as np
from h5_augmented_selection_readback_20261107 import verify_selection
from h5_bracket_augmented_objective_20261107 import Objective
from h5_bracket_augmented_readback_20261107 import verify
from h5_bracket_augmented_reference_20261107 import Reference
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-augmented-conditional-neighbors-20261107';OUT=BASE/'audit';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();plan=load(BASE/'plan.json');assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
for name,h in load(BASE/'runtime-bindings.json').items():assert digest(ROOT/name)==h,name
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');closed=load(BASE/'closed-problems.json');prior=load(A/'closed-prior-problems.json');new=load(A/'search/closed-problem.json')
assert closed[:7]==prior and closed[7]=={'key':new['key'],'objective':identity['version'],'source':'output/h5-bracket-augmented-model-20261107/search/closed-problem.json'} and new['closed']
assert plan['grid_fractions']==[i/8 for i in range(9)] and plan['score_tolerance_mm2']==1e-6
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','neighbors.json','owner-aliases.json','center-trials.json','center-selections.json','closed-problems.json','selection.json']]+[ROOT/'output/h5-augmented-conditional-neighbors-preparation-process-20261107/process.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently reconstruct all original source pairs, all rational auxiliary losses and numerical reductions for every6396center and2854proposal score. Verify all147mode/domain mappings, closed keys, complete deterministic recorded ranks and independent minimum margins under predeclared1e-6. Reconstruct selected81-coordinate model and scalar source gradient if joint prerequisite passes. No optimizer.'})
result=verify_selection(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,{r['key'] for r in closed},load(BASE/'neighbors.json'),load(BASE/'owner-aliases.json'),load(BASE/'center-trials.json'),load(BASE/'center-selections.json'),OUT/'selection-replay')
assert result==load(BASE/'selection.json')
selected_controls=None
if result['joint_improves_current_and_single']:
    row=result['best_joint'];modes=initial['modes'].copy();point=initial['values'].copy()
    for (i,mi),center in zip(row['changes'],row['centers']):modes[i]=mi;point[2*i:2*i+2]=center
    state=load(BASE/'selected-state.json');model=load(BASE/'selected-model.json')
    assert state=={'modes':modes,'values':point,'pair_weights':initial['pair_weights'],'key':row['key'],'objective_identity':identity}
    assert verify(model,lib,modes,point,initial['pair_weights'],identity)
    value,g,d=Objective(model,regions,identity).evaluate(point,True);rv,rg,rd=Reference(lib).evaluate(model,point,True,d['auxiliary_terms'])
    assert abs(value-row['augmented_objective_mm2'])<1e-6 and abs(value-rv)<1e-6 and np.max(np.abs(g-rg))<1e-6
    assert model['bounds']==[b for o in model['owners'] for b in lib['family_modes'][o['identity'][0]][o['mode']]['center_bounds_mm']]+lib['angle_bounds']
    selected_controls={'passed':True,'parameters':81,'moving_owners':33,'all_area_pairs':528,'all_auxiliary_pairs':15,'selected_changes':row['changes'],'augmented_objective_mm2':value,'weighted_area_objective_mm2':d['weighted_area_objective_mm2'],'auxiliary_bracket_depth_mm2':d['auxiliary_bracket_depth_mm2'],'original_overlap_mm2':d['original_overlap_area_mm2'],'independent_scalar_score_error_mm2':abs(value-rv),'independent_scalar_gradient_error_mm':float(np.max(np.abs(g-rg))),'scalar_directed_gradient_terms':rd['directed_scalar_gradient_terms'],'shared_boundary_length_mm':rd['coincident_boundary_length_mm'],'gradient_interpretation':'existing selected boundary and nearest-feature conventions; not a blanket smooth derivative claim','optimized_ancestor_consumed':False}
    write(OUT/'selected-model-controls.json',selected_controls)
else:assert not (BASE/'selected-model.json').exists() and not (BASE/'selected-state.json').exists()
prep=load(ROOT/'output/h5-augmented-conditional-neighbors-preparation-process-20261107/process.json');assert prep['passed'] and prep['closed'] and prep['job']['active_processes']==0
charge=plan['complete_prior_preparation_seconds']+prep['complete_seconds'];replay=load(OUT/'selection-replay/checks.json')
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,**{k:v for k,v in replay.items() if k!='passed'},'selected_model_checked':selected_controls is not None,'complete_preparation_seconds':charge,'new_selector_preparation_seconds':prep['complete_seconds'],'old_computed_selections_consumed':False,'optimized_ancestor_consumed':False,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
