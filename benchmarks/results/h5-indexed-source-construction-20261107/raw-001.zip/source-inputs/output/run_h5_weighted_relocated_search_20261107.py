"""One finite guided pipeline with new coefficient vectors and original scoring."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,subprocess,sys,os,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107';SOURCE=ROOT/'output/h5-mixed-rows-continuous-model-20261107';OUT=BASE/'search';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PY=ROOT/'.cache/shop-venv/Scripts/python.exe';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def problem_key(physical,weights):return sha256(json.dumps({'physical':list(physical),'weights':weights},separators=(',',':'),allow_nan=False).encode()).hexdigest()

def child(started):
    import numpy as np,scipy
    from scipy.optimize import minimize
    from h5_cross_pair_weighted_model_20261107 import compile_model,Objective,update_weights
    from h5_weighted_relocated_neighbors_20261107 import neighbors,rank,apply_neighbor
    from h5_weighted_original_readback_20261107 import verify
    from h5_mixed_direct_pose_20261107 import source_rows
    from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
    from h5_legacy64_source_readback import audit
    assert scipy.__version__=='1.17.1';plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
    for name,r in load(W/'audit-v2/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==r['sha256']
    for name,h in load(BASE/'runtime-bindings.json').items():assert digest(ROOT/name)==h
    lib=load(W/'library.json');initial=load(BASE/'selected-state.json');classes=family_classes(lib);job=load(JOB);options=load(W/'audit-v2/optimizer-controls.json')['options'];modes=initial['modes'];values=initial['values'];weights=initial['pair_weights'];old_closed={r['key'] for r in load(BASE/'closed-weighted-problems.json')};visited=set(old_closed);summaries=[];global_best=None;valid_witness=None;total_trials=0;total_centers=0;stop='MAXIMUM_EPOCHS';calls=0;valid=False
    for epoch in range(plan['maximum_optimizer_calls']):
        if time.perf_counter()-started>=56:stop='TIME_STOP_BEFORE_EPOCH';break
        folder=OUT/f'epoch-{epoch:02d}';folder.mkdir();(folder/'points').mkdir();incoming=values.copy();incoming_modes=modes.copy();write(folder/'opened.json',{'epoch':epoch,'incoming_values':incoming,'incoming_modes':incoming_modes,'weights_before_update':weights,'visited_weighted_problems':sorted(visited),'algorithm_seconds_including_preparation':time.perf_counter()-started})
        if epoch:
            previous=compile_model(lib,modes,values,weights);losses=Objective(previous).pair_losses(values).tolist();updated=update_weights(weights,losses);write(folder/'weight-transition.json',{'before':weights,'pair_losses_mm2':losses,'after':updated,'source':'previous_epoch_weighted_best'});weights=updated
            records,aliases,center_trials,center_selections=neighbors(lib,modes,incoming,weights,visited)
            write(folder/'neighbors.json',records);write(folder/'owner-aliases.json',aliases);write(folder/'center-trials.json',center_trials);write(folder/'center-selections.json',center_selections);total_trials+=len(records);total_centers+=len(center_trials)
            eligible_single=[r for r in records if not r['excluded'] and len(r['changes'])==1];eligible_joint=[r for r in records if not r['excluded'] and len(r['changes'])==2]
            single=min(eligible_single,key=rank) if eligible_single else None;joint=min(eligible_joint,key=rank) if eligible_joint else None;baseline=records[0]['weighted_objective_mm2'];improves=single is not None and joint is not None and joint['weighted_objective_mm2']<min(single['weighted_objective_mm2'],baseline)-1e-6
            write(folder/'selection.json',{'best_single':single,'best_joint':joint,'current_score':baseline,'joint_improves_current_and_single':improves})
            if time.perf_counter()-started>=56:stop='TIME_STOP_AFTER_SELECTION';break
            if not improves:stop='NO_IMPROVING_JOINT_RELOCATION';break
            selection=joint;write(folder/'selected-mode.json',selection);modes,model,selected_point=apply_neighbor(lib,modes,incoming,weights,selection);incoming=selected_point.tolist()
        else:
            model=compile_model(lib,modes,values,weights);assert model==load(BASE/'selected-model.json') and initial['key'] not in visited
        assert verify(model,lib,modes,incoming,weights) and any(w!=1 for w in weights);key=problem_key(physical_key(lib,classes,modes),weights);assert key not in visited;allocated=min(10.,56-(time.perf_counter()-started))
        if allocated<=0:stop='TIME_STOP_BEFORE_CALL';break
        write(folder/'model.json',model);assert verify(load(folder/'model.json'),lib,modes,incoming,weights);obj=Objective(model);point=np.asarray(model['initial']);energy,g,details=obj.evaluate(point,True);bounds=np.asarray(model['bounds'])
        def row(sequence,evaluation,x,value,gradient,d,improved_weighted,improved_unweighted):return {'sequence':sequence,'evaluation':evaluation,'values':x.tolist(),'weighted_objective_mm2':value,'unweighted_objective_mm2':d['unweighted_objective_mm2'],'gradient':gradient.tolist(),'improved_weighted':improved_weighted,'improved_unweighted':improved_unweighted}
        first=row(0,0,point,energy,g,details,True,True);write(folder/'points/00000.json',first);state={'evaluations':0,'saved':1,'weighted':first,'unweighted':first};calls+=1;visited.add(key);write(folder/'optimizer-opened.json',{'method':'L-BFGS-B','options':options,'analytic_jacobian':True,'parameters':81,'allocated_seconds':allocated,'key':key,'model_sha256':digest(folder/'model.json'),'uniform_weight_problem':False,'maximum_calls_for_weighted_problem':1,'retry_permitted':False,'algorithm_seconds_including_preparation':time.perf_counter()-started})
        class Deadline(Exception):pass
        def function(x):
            if time.perf_counter()>=deadline:raise Deadline()
            value,gradient,d=obj.evaluate(x,True);state['evaluations']+=1;iw=value<state['weighted']['weighted_objective_mm2'];iu=d['unweighted_objective_mm2']<state['unweighted']['unweighted_objective_mm2']
            if iw or iu:
                r=row(state['saved'],state['evaluations'],x,value,gradient,d,iw,iu);write(folder/'points'/f'{state["saved"]:05d}.json',r);state['saved']+=1
                if iw:state['weighted']=r
                if iu:state['unweighted']=r
            return value,gradient
        def callback(x):
            if state['unweighted']['unweighted_objective_mm2']<=1e-16:raise StopIteration()
        before=time.perf_counter();deadline=before+allocated;numerical=None
        try:
            r=minimize(function,point,jac=True,bounds=bounds,method='L-BFGS-B',callback=callback,options=options);status='RETURNED';numerical={'success':bool(r.success),'status':int(r.status),'message':str(r.message),'iterations':int(r.nit),'function_evaluations':int(r.nfev),'objective_mm2':float(r.fun),'values':r.x.tolist()}
        except Deadline:status='TIME_STOP'
        elapsed=time.perf_counter()-before;readbacks={}
        for label in ['weighted','unweighted']:
            selected=state[label];x=selected['values'];value,gradient,d=obj.evaluate(x,True);assert value==selected['weighted_objective_mm2'] and d['unweighted_objective_mm2']==selected['unweighted_objective_mm2'] and np.array_equal(gradient,selected['gradient']) and np.all(np.asarray(x)>=bounds[:,0]) and np.all(np.asarray(x)<=bounds[:,1]);rows=source_rows(model,x);write(folder/(label+'-source66.json'),rows);checked=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));write(folder/(label+'-source-checks.json'),checked);assert checked['stock_failures']==0 and checked['originals']==66;readbacks[label]={'unweighted_objective_mm2':d['unweighted_objective_mm2'],'original_overlap_mm2':d['original_overlap_area_mm2'],'pair_failures':checked['pair_failures'],'source_valid66':checked['valid']};valid=valid or checked['valid']
        for label in ['weighted','unweighted']:
            if readbacks[label]['source_valid66'] and valid_witness is None:valid_witness={'epoch':epoch,'label':label,'modes':modes,'values':state[label]['values'],'source66_path':(folder/(label+'-source66.json')).relative_to(ROOT).as_posix()}
        candidate={'epoch':epoch,'modes':modes,'values':state['unweighted']['values'],'unweighted_objective_mm2':state['unweighted']['unweighted_objective_mm2'],'source_pair_failures':readbacks['unweighted']['pair_failures'],'source_valid66':readbacks['unweighted']['source_valid66']}
        if global_best is None or candidate['unweighted_objective_mm2']<global_best['unweighted_objective_mm2'] or candidate['source_valid66']:global_best=candidate
        write(folder/'response.json',{'closed':True,'key':key,'status':status,'numerical_result':numerical,'allocated_seconds':allocated,'returned_seconds':elapsed,'slice_overrun_seconds':max(0.,elapsed-allocated),'evaluations':state['evaluations'],'saved_points':state['saved'],'weighted_best':state['weighted'],'unweighted_best':state['unweighted'],'source_readbacks':readbacks,'global_best':global_best,'algorithm_seconds_including_preparation':time.perf_counter()-started});summaries.append({'epoch':epoch,'key':key,'minimum_weight':min(weights),'maximum_weight':max(weights),'status':status,'weighted_best_unweighted_objective_mm2':state['weighted']['unweighted_objective_mm2'],'best_unweighted_objective_mm2':state['unweighted']['unweighted_objective_mm2'],'source_pair_failures':readbacks['unweighted']['pair_failures'],'source_valid66':valid});print(summaries[-1],flush=True);values=state['weighted']['values']
        if valid:stop='SOURCE_VALID_CANDIDATE';break
        if time.perf_counter()-started>=56:stop='TIME_STOP_AFTER_SOURCE_CHECK';break
    elapsed=time.perf_counter()-started;write(OUT/'result.json',{'closed':True,'status':stop,'optimizer_calls':calls,'unique_weighted_problems':len(visited)-len(old_closed),'historical_closed_keys':len(old_closed),'center_trials':total_centers,'mode_trials':total_trials,'epochs':summaries,'best_global_unweighted':global_best,'source_valid66':valid,'valid_witness':valid_witness,'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'native_calls':0,'uniform_weight_calls':0,'old_calls_resumed':False,'any_allocation_excluded':False,'H5_complete':False,'retry_permitted':False});print(load(OUT/'result.json'))

def main():
    checked=load(BASE/'audit-v2/checks.json');assert checked['passed'] and checked['joint_strictly_improves_single'] and checked['central_samples']==162;OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');charge=checked['complete_preparation_seconds'];started=time.perf_counter()-charge
    files=[Path(__file__),JOB]+[ROOT/'output'/n for n in ['h5_weighted_relocated_neighbors_20261107.py','h5_weighted_joint_neighbors_20261107.py','h5_cross_pair_weighted_model_20261107.py','h5_cross_pair_boundary_gradient_20261107.py','h5_weighted_original_model_20261107.py','h5_weighted_original_readback_20261107.py','h5_hard_cell_compound_modes_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py','h5-weighted-relocated-neighbors-preparation-process-20261107/process.json']]+[BASE/n for n in ['plan.json','checks.json','selected-state.json','selected-model.json','selection.json','neighbors.json','center-trials.json','center-selections.json','closed-weighted-problems.json','audit-v2/plan.json','audit-v2/checks.json','runtime-bindings.json']]+[W/n for n in ['library.json','audit-v2/optimizer-controls.json','audit-v2/tool-provenance.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'complete_preparation_seconds':charge,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'maximum_optimizer_calls':3,'optimizer_slice_seconds':10,'blas_threads':1,'method':'One finite new joint/conditional-relocation pipeline from the independently audited selected source-grid state. Include all consumed original, negative joint and new relocation preparation. Exclude all four historical weighted coefficient/physical keys and each new key after one call. Initial selected joint strictly improves both source initializer and best single. At later epochs update bounded weights from previous weighted winner; evaluate fixed9x9grid plus clamped center for each physically changed owner-mode against all32other originals; keep exact center aliases. Score all current/single/two-owner choices with complete528pair sums and the changed mutual interaction once. New joint must improve both current and best admissible single by>1e-6mm2; otherwise stop. At most three10s calls, shortened to remaining56s reserve boundary. Track/save both weighted and unweighted incumbents; independently read both full66 winners after each call. Stop on validity, finite count, reserve time, no improving new joint, or inconsistency. No grid refinement, closed-call restart, optimized predecessor seed or native call.','retry_permitted':False,'restarts':0})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE);cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'complete_preparation_seconds':charge,'memory_bytes':2**31,'retry_permitted':False});env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1');r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(Path(__file__)),'--child',str(started)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env);(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0;write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'retry_permitted':False});print(load(OUT/'process.json'));print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed result; pipeline remains closed.')
if __name__=='__main__':
    if '--child' in sys.argv:child(float(sys.argv[2]))
    else:main()
