"""Freeze the merged choice policy and reconstruct a new original-source state."""
from pathlib import Path
from hashlib import sha256
import json,time,os,copy
from h5_augmented_admissible_choice_20261107 import choose
from h5_bracket_augmented_neighbors_20261107 import apply_neighbor
from h5_bracket_augmented_objective_20261107 import Objective
from h5_bracket_augmented_readback_20261107 import verify
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';P=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
parent=ROOT/'benchmarks/results/h5-adaptive-augmented-construction-20261107';assert load(parent/'archive-checks.json')['passed'] and load(P/'response-audit/checks.json')['passed']
inputs=[Path(__file__),parent/'next-step.json',parent/'archive-checks.json']+[ROOT/'output'/n for n in ['h5_augmented_admissible_choice_20261107.py','h5_augmented_admissible_readback_20261107.py','audit_h5_best_admissible_augmented_20261107.py','h5_augmented_deadline_neighbors_20261107.py','h5_bracket_augmented_neighbors_20261107.py','h5_bracket_augmented_readback_20261107.py']]+[P/n for n in ['plan.json','neighbors.json','closed-problems.json','audit/checks.json','audit/deadline-controls.json','audit/weight-update-controls.json','search/epoch-00/closed-problem.json','search/epoch-01/closed-problem.json','response-audit/checks.json','runtime-bindings.json']]+[N/n for n in ['audit/checks.json','audit/selection-replay/proposal-score-controls.json']]+[A/n for n in ['library.json','initial-state.json','objective-identity.json']]+[B/'regions.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Select the minimum complete augmented score among all admissible one-owner and two-owner source proposals, preserving separate single/joint diagnostics. Require a strict1e-6 improvement over current source. Reject incomplete pools. Expand all prior closed identities to11keys and reconstruct a new source state from unchanged original A/W values plus its raw proposal. All6396original centers and2854complete scores remain charged; no old optimized or stopping candidate seeds this preparation. Deadline helper, model, objective and weight update are unchanged.',
    'complete_prior_preparation_seconds':load(P/'audit/checks.json')['complete_preparation_seconds'],'closed_keys':11,'score_tolerance_mm2':1e-6,'strict_improvement_mm2':1e-6,'ranking':'Unrounded augmented score then full mode vector; independent complete source scores verify minima within1e-6, with any numerical rank difference preserved. Auxiliary terms stay unweighted at coefficient1.',
    'validation_cases':['new original-source pool','prior adaptive runtime epoch1','prior adaptive stopping epoch2'],'validation_only_policy_controls':['all choices closed','no strict improvement','incomplete pool rejected'],'preparation_cap_seconds':20,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
identity=load(A/'objective-identity.json');closed=load(P/'closed-problems.json')
for epoch in [0,1]:
    p=P/f'search/epoch-{epoch:02d}/closed-problem.json';r=load(p);assert r['closed'] and not r['retry_permitted'];closed.append({'key':r['key'],'objective':identity['version'],'source':p.relative_to(ROOT).as_posix()})
keys={r['key'] for r in closed};assert len(closed)==len(keys)==11;write(OUT/'closed-problems.json',closed)
records=copy.deepcopy(load(P/'neighbors.json'))
for row in records:row['excluded']=row['key'] in keys;row['exclusion_reason']='closed_objective_problem' if row['excluded'] else None
write(OUT/'neighbors.json',records);selection=choose(records);write(OUT/'selection.json',selection)
chosen=selection['accepted_choice']
if chosen is not None:
    lib=load(A/'library.json');initial=load(A/'initial-state.json');modes,model,values=apply_neighbor(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,chosen)
    assert verify(model,lib,modes,values,initial['pair_weights'],identity) and chosen['key'] not in keys
    assert abs(Objective(model,load(B/'regions.json'),identity).score(values)-chosen['augmented_objective_mm2'])<1e-6
    write(OUT/'selected-model.json',model);write(OUT/'selected-state.json',{'modes':modes,'values':values.tolist(),'pair_weights':initial['pair_weights'],'key':chosen['key'],'objective_identity':identity})
runtime=load(P/'runtime-bindings.json')
for name,h in runtime.items():assert digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'source_proposals_reused':2854,'source_center_trials_reused':6396,'closed_keys':11,'excluded_choices':sum(r['excluded'] for r in records),'strictly_improves_current':chosen is not None,'accepted_changed_owners':None if chosen is None else len(chosen['changes']),'accepted_score_mm2':None if chosen is None else chosen['augmented_objective_mm2'],'optimizer_calls':0,'optimized_ancestor_consumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
