"""Independently replay every broader center/proposal and complete key minimum."""
from pathlib import Path
from hashlib import sha256
import json,time,copy,os
import numpy as np
from h5_current_mode_relocations_20261107 import neighbors,SelectionDeadline
from h5_current_mode_key_choice_20261107 import choose,KeySelectionDeadline
from h5_current_mode_selection_readback_20261107 import verify_selection
from h5_current_mode_source_domains_20261107 import verify_domains
from h5_augmented_selection_score_reference_20261107 import FullScore
from h5_bracket_augmented_reference_20261107 import Reference
from h5_bracket_augmented_objective_20261107 import Objective,compile_model
from h5_bracket_augmented_readback_20261107 import verify
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107';OUT=BASE/'audit';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();plan=load(BASE/'plan.json');assert load(BASE/'checks.json')['prepared']
assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
for name,h in load(BASE/'runtime-bindings.json').items():assert digest(ROOT/name)==h,name
inputs=[Path(__file__),JOB]+[BASE/n for n in ['plan.json','checks.json','neighbors.json','owner-aliases.json','center-trials.json','center-selections.json','closed-problems.json','selection.json','group-members.json','key-minima.json','runtime-bindings.json']]+[ROOT/'output/h5-current-mode-relocation-preparation-process-20261107'/n for n in ['process.json','opened.json']]
inputs += [BASE/n for n in ['selected-model.json','selected-state.json'] if (BASE/n).is_file()]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently reconstruct all9102nominal original-source center scores and5911complete proposals, all2854key minima and strict ranking. Read every owner-mode model and source grid placement with holes, stock and fixed parts. Rebuild the fresh selected model and scalar gradient. Validate six synthetic neighborhood deadlines, one real deadline, four key-grouping deadlines, all-closed/no-margin/partial-pool policy controls. Validation outputs never seed search. No optimizer.'})
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');closed=load(BASE/'closed-problems.json');expected=load(Q/'closed-problems.json')
for epoch in [0,1,2]:
    path=Q/f'search/epoch-{epoch:02d}/closed-problem.json';row=load(path);assert row['closed'] and not row['retry_permitted'];expected.append({'key':row['key'],'objective':identity['version'],'source':path.relative_to(ROOT).as_posix()})
assert closed==expected and len(closed)==14;keys={r['key'] for r in closed};assert len(keys)==14
records=load(BASE/'neighbors.json');aliases=load(BASE/'owner-aliases.json');trials=load(BASE/'center-trials.json');selections=load(BASE/'center-selections.json');selected=load(BASE/'selection.json');groups=load(BASE/'group-members.json');minima=load(BASE/'key-minima.json')
replay=verify_selection(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys,records,aliases,trials,selections,OUT/'selection-replay');assert replay==(selected,groups,minima)
print({'complete_scores_and_key_minima_verified':True},flush=True)
domains=verify_domains(load(JOB),lib,initial['modes'],initial['values'],trials,OUT/'source-domains')
model_rows=[]
for control in selections:
    owner,mode=control['owner'],control['mode'];modes=initial['modes'].copy();values=initial['values'].copy();modes[owner]=mode;values[2*owner:2*owner+2]=control['selected']['center'];model=compile_model(lib,modes,values,initial['pair_weights'],identity)
    assert verify(model,lib,modes,values,initial['pair_weights'],identity)
    model_rows.append({'owner':owner,'mode':mode,'model_sha256':sha256(json.dumps(model,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest(),'selected_center':control['selected']['center'],'bounds':model['bounds'],'parameters':model['parameters'],'passed':True})
assert len(model_rows)==111;write(OUT/'owner-mode-model-controls.json',model_rows)
chosen=selected['accepted_choice'];model_controls=None
if chosen is not None:
    modes=initial['modes'].copy();point=initial['values'].copy()
    for (i,mi),center in zip(chosen['changes'],chosen['centers']):modes[i]=mi;point[2*i:2*i+2]=center
    model=load(BASE/'selected-model.json');state=load(BASE/'selected-state.json');weights=initial['pair_weights'];assert state=={'modes':modes,'values':point,'pair_weights':weights,'key':chosen['key'],'objective_identity':identity}
    assert verify(model,lib,modes,point,weights,identity) and chosen['key'] not in keys
    score=FullScore(lib,weights,regions)(modes,point);assert abs(score['augmented_objective_mm2']-chosen['augmented_objective_mm2'])<1e-6
    value,g,d=Objective(model,regions,identity).evaluate(point,True);rv,rg,rd=Reference(lib).evaluate(model,point,True,d['auxiliary_terms']);assert abs(value-rv)<1e-6 and np.max(np.abs(g-rg))<1e-6
    model_controls={'passed':True,'parameters':81,'moving_owners':33,'all_area_pairs':528,'all_auxiliary_pairs':15,'owner_replacements':chosen['changes'],'physical_mode_changes':[[i,a,b] for i,(a,b) in enumerate(zip(records[0]['physical_key'],chosen['physical_key'])) if a!=b],'key':chosen['key'],'augmented_objective_mm2':value,'original_overlap_mm2':d['original_overlap_area_mm2'],'maximum_scalar_gradient_error_mm':float(np.max(np.abs(g-rg))),'independent_score_error_mm2':abs(value-rv),'scalar_directed_gradient_terms':rd['directed_scalar_gradient_terms'],'gradient_interpretation':'Existing selected source-boundary/nearest-feature conventions; no blanket smoothness guarantee.','optimized_ancestor_consumed':False};write(OUT/'selected-model-controls.json',model_controls)
else:assert not (BASE/'selected-model.json').exists() and not (BASE/'selected-state.json').exists()

class Clock:
    def __init__(self,stop):self.stop=stop;self.calls=0
    def __call__(self):self.calls+=1;return 1. if self.calls>=self.stop else 0.

def check_prefix(evidence):
    assert evidence['complete'] is False and evidence['status']=='SELECTION_DEADLINE' and evidence['selected_proposal'] is None and evidence['optimizer_calls']==0
    for field,full in zip(['records','aliases','trials','selections'],[records,aliases,trials,selections]):assert evidence[field]==full[:len(evidence[field])]
    assert len(evidence['trials'])%82==0 and len(evidence['selections'])==len(evidence['trials'])//82
    assert evidence['observed']>=evidence['deadline'] and evidence['overrun_seconds']==evidence['observed']-evidence['deadline']
deadline_controls=[]
for expiry in plan['deadline_controls']['neighborhood_expiry_checkpoints']:
    timer=Clock(expiry);before=time.perf_counter()
    try:neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys,deadline=1.,clock=timer)
    except SelectionDeadline as exc:
        evidence=exc.evidence;check_prefix(evidence);assert timer.calls==expiry;write(OUT/f'neighborhood-deadline-{expiry:04d}.json',evidence)
        deadline_controls.append({'expiry_checkpoint':expiry,'stage':evidence['stage'],'preserved_trials':len(evidence['trials']),'preserved_proposals':len(evidence['records']),'seconds':time.perf_counter()-before,'selected_proposal':None})
    else:raise AssertionError('Partial neighborhood returned normally')
    print(deadline_controls[-1],flush=True)
before=time.perf_counter();deadline=before+plan['deadline_controls']['real_neighborhood_seconds']
try:neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys,deadline=deadline)
except SelectionDeadline as exc:
    evidence=exc.evidence;check_prefix(evidence);write(OUT/'neighborhood-deadline-real.json',evidence);real={'stage':evidence['stage'],'elapsed_seconds':time.perf_counter()-before,'requested_seconds':.05,'observed_overrun_seconds':evidence['overrun_seconds'],'preserved_trials':len(evidence['trials']),'preserved_proposals':len(evidence['records']),'selected_proposal':None}
else:raise AssertionError('Real partial neighborhood returned normally')
key_controls=[]
for expiry in plan['deadline_controls']['key_choice_expiry_checkpoints']:
    timer=Clock(expiry)
    try:choose(records,deadline=1.,clock=timer)
    except KeySelectionDeadline as exc:
        evidence=exc.evidence;assert evidence['complete'] is False and evidence['status']=='KEY_SELECTION_DEADLINE' and evidence['selected_proposal'] is None and evidence['optimizer_calls']==0 and timer.calls==expiry
        assert evidence['group_members']==({} if expiry==1 else groups) and evidence['key_minima']==([] if expiry<3 else minima)
        write(OUT/f'key-deadline-{expiry}.json',evidence);key_controls.append({'expiry_checkpoint':expiry,'stage':evidence['stage'],'preserved_keys':len(evidence['group_members']),'preserved_minima':len(evidence['key_minima']),'selected_proposal':None})
    else:raise AssertionError('Partial key grouping returned normally')
write(OUT/'deadline-controls.json',{'passed':True,'neighborhood_synthetic_cases':deadline_controls,'neighborhood_real_case':real,'key_choice_cases':key_controls,'cooperative_limit':'Stops between complete geometry batches, proposals or grouping stages; one in-progress stage may overrun and is recorded. Windows Job is the outer process/time/memory bound. Interrupted output is retained and never selected.','validation_only':True,'optimizer_calls':0})
policies=[];allclosed=copy.deepcopy(records)
for row in allclosed:row['excluded']=True;row['exclusion_reason']='closed_objective_problem'
choice,_,_=choose(allclosed,time.perf_counter()+5);assert choice['accepted_choice'] is None and choice['best_admissible'] is None;policies.append({'case':'all_closed','accepted':False})
noimprovement=copy.deepcopy(records);noimprovement[0]['augmented_objective_mm2']=selected['best_admissible']['augmented_objective_mm2'];choice,_,_=choose(noimprovement,time.perf_counter()+5);assert not choice['strictly_improves_current'] and choice['accepted_choice'] is None;policies.append({'case':'zero_strict_margin','accepted':False})
try:choose(records[:-1],time.perf_counter()+5)
except AssertionError:policies.append({'case':'partial_pool','rejected':True})
else:raise AssertionError('Partial proposal pool must never be selected')
write(OUT/'policy-stop-controls.json',{'passed':True,'controls':policies,'validation_only':True,'optimizer_calls':0})
prep=load(ROOT/'output/h5-current-mode-relocation-preparation-process-20261107/process.json');assert prep['passed'] and prep['closed'] and prep['job']['active_processes']==0;charge=plan['complete_prior_preparation_seconds']+prep['complete_seconds'];assert plan['complete_prior_preparation_seconds']==load(Q/'audit/checks.json')['complete_preparation_seconds']
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in {**data.get('inputs',{}),**data.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json','plan-v2.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings);score_checks=load(OUT/'selection-replay/checks.json')
summary={'passed':True,'seconds':time.perf_counter()-start,'source_bindings':len(bindings),'independent_full_scores':score_checks['independent_full_scores'],'center_trials':len(trials),'raw_proposals':len(records),'key_minima':len(minima),'owner_mode_models_verified':len(model_rows),'closed_keys':14,'excluded_keys':selected['excluded_keys'],'excluded_raw_proposals':selected['excluded_raw_proposals'],'maximum_component_score_error_mm2':score_checks['maximum_component_score_error_mm2'],'source_domain_controls':domains,'strictly_improves_current':chosen is not None,'fresh_selected_model_readback':model_controls is not None,'policy_stop_controls':len(policies),'deadline_controls':len(deadline_controls)+len(key_controls)+1,'new_source_preparation_seconds':prep['complete_seconds'],'complete_preparation_seconds':charge,'optimized_ancestor_consumed':False,'validation_outputs_used_as_seed':False,'optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',summary);print(summary)
