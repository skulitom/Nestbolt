"""Freeze and compute source-only conditional choices for the augmented loss."""
from pathlib import Path
from hashlib import sha256
import json,time,os
from h5_bracket_augmented_neighbors_20261107 import neighbors,rank,apply_neighbor
from h5_bracket_augmented_objective_20261107 import Objective
from h5_bracket_augmented_readback_20261107 import verify
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';OUT=ROOT/'output/h5-augmented-conditional-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();assert affinity_mask()==4294901760
assert all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
assert load(A/'audit-v2/checks.json')['passed'];parent=ROOT/'benchmarks/results/h5-bracket-augmented-construction-20261107';assert load(parent/'archive-checks.json')['passed']
grid=ROOT/'output/h5-mixed-rows-continuous-model-20261107/plan.json';assert load(grid)['grid_fractions']==[i/8 for i in range(9)]
inputs=[Path(__file__),grid,parent/'next-step.json',parent/'archive-checks.json']+[ROOT/'output'/n for n in ['h5_bracket_augmented_neighbors_20261107.py','h5_augmented_selection_score_reference_20261107.py','h5_augmented_selection_readback_20261107.py','audit_h5_augmented_neighbors_20261107.py','h5_bracket_augmented_objective_20261107.py','h5_bracket_augmented_readback_20261107.py','h5_weighted_relocated_neighbors_20261107.py','h5_weighted_joint_neighbors_20261107.py','h5_relocated_selection_readback_20261107.py','h5_checked_affinity_20261107.py']]+[A/n for n in ['library.json','initial-state.json','model.json','objective-identity.json','plan.json','audit-v2/checks.json','closed-prior-problems.json','search/closed-problem.json']]+[B/'regions.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Use unchanged unoptimized A/W initializer, same81coordinates,528area pairs,15auxiliary pairs, positive weights and hard domains. Reuse earlier conditional-grid/joint algorithms as code references only; no old selection scores, selected centers or optimized state is consumed. For each physically changed owner mode score fixed9x9source grid plus clamped center against all other originals under the full augmented objective. Then score current,78single,2775joint alternatives, replacing the mutual area AND auxiliary pair once. Preserve every trial and domain alias. No optimizer in preparation.',
    'grid_fractions':[i/8 for i in range(9)],'nominal_center_trials':6396,'maximum_centers_per_owner_mode':82,'proposals':2854,'score_tolerance_mm2':1e-6,'strict_joint_improvement_mm2':1e-6,
    'ranking':'Producer uses unrounded augmented score thenXY/local index for centers, full mode vector for proposals. Score=dot of full528weighted area losses plus sequential sum of15auxiliary losses in original pair order. Independent audit reconstructs complete geometry, binary64 depth projections and reductions, also checking scalar/rational scores. It reproduces recorded ranking exactly and requires selected independent score within predeclared1e-6 of the independent minimum; any differently ordered near tie is retained explicitly. Strict joint-improvement prerequisite must hold independently.',
    'complete_prior_preparation_seconds':load(A/'audit-v2/checks.json')['complete_preparation_seconds'],'previous_J_R_computed_selection_outputs_consumed':False,'optimized_ancestor_consumed':False,'preparation_cap_seconds':20,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');region_data=load(B/'regions.json');closed=load(A/'closed-prior-problems.json');new=load(A/'search/closed-problem.json');assert new['closed']
closed=closed+[{'key':new['key'],'objective':identity['version'],'source':'output/h5-bracket-augmented-model-20261107/search/closed-problem.json'}];assert len({r['key'] for r in closed})==8
write(OUT/'closed-problems.json',closed)
records,aliases,trials,selections=neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,region_data,{r['key'] for r in closed})
assert records[0]['key']==new['key'] and records[0]['excluded']
write(OUT/'neighbors.json',records);write(OUT/'owner-aliases.json',aliases);write(OUT/'center-trials.json',trials);write(OUT/'center-selections.json',selections)
single=min((r for r in records if len(r['changes'])==1 and not r['excluded']),key=rank);joint=min((r for r in records if len(r['changes'])==2 and not r['excluded']),key=rank);baseline=records[0]['augmented_objective_mm2'];improves=joint['augmented_objective_mm2']<min(single['augmented_objective_mm2'],baseline)-1e-6
write(OUT/'selection.json',{'best_single':single,'best_joint':joint,'current_score':baseline,'joint_improves_current_and_single':improves})
if improves:
    modes,model,values=apply_neighbor(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,joint)
    assert verify(model,lib,modes,values,initial['pair_weights'],identity)
    assert abs(Objective(model,region_data,identity).score(values)-joint['augmented_objective_mm2'])<1e-6
    write(OUT/'selected-model.json',model);write(OUT/'selected-state.json',{'modes':modes,'values':values.tolist(),'pair_weights':initial['pair_weights'],'key':joint['key'],'objective_identity':identity})
runtime=load(A/'runtime-bindings.json')
for name,h in runtime.items():assert digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'center_trials':len(trials),'unique_centers':sum(s['unique_centers'] for s in selections),'center_aliases':sum(t['duplicate_of'] is not None for t in trials),'proposals':len(records),'owner_alias_bindings':len(aliases),'closed_keys':len(closed),'excluded_choices':sum(r['excluded'] for r in records),'best_single_score_mm2':single['augmented_objective_mm2'],'best_joint_score_mm2':joint['augmented_objective_mm2'],'joint_improves_current_and_single':improves,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
