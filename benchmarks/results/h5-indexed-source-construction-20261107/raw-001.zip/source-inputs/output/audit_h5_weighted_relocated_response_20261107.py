"""Replay weighted state transitions, both incumbent measures and source poses."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,time,math,shutil
import numpy as np
from shapely.geometry import Polygon
from h5_cross_pair_weighted_model_20261107 import compile_model,Objective
from h5_relocated_selection_readback_20261107 import verify_selection
from h5_weighted_original_readback_20261107 import verify
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107';S=BASE/'search';OUT=BASE/'response-audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def key_for(modes,weights):return sha256(json.dumps({'physical':list(physical_key(lib,classes,modes)),'weights':weights},separators=(',',':'),allow_nan=False).encode()).hexdigest()
def independent_rows(model,x):
    rows=lib['fixed_source_rows'].copy()
    for i,o in enumerate(model['owners']):
        family=o['identity'][0];mode=lib['family_modes'][family][o['mode']];theta=x[66+i-18]/lib['angle_scale_mm'] if i>=18 else mode['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];rows.append({'part_id':family,'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':mode['mirrored'],'translation':[x[2*i]-(sign*px*c-py*s),x[2*i+1]-(sign*px*s+py*c)]}})
    return rows
def independent_losses(model,x):
    rows=independent_rows(model,x)[33:];polys=[]
    for row in rows:
        t=row['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);sign=-1 if t['mirrored'] else 1;tx,ty=t['translation'];polys.append([Polygon([(sign*a*c-b*s+tx,sign*a*s+b*c+ty) for a,b in lib['families'][row['part_id']][kind]]) for kind in ['original','clearance']])
    return [sum(polys[i][k].intersection(polys[j][k]).area for k in [0,1]) for i,j in lib['pairs']]
def independent_update(before,losses):
    peak=max(losses);out=[]
    for w,a in zip(before,losses):
        if a==0:v=float(F(w)*F(.95))
        else:r=float(F(a)/F(peak));scaled=float(F(.8)*F(r));factor=float(F(1.2)+F(scaled));v=float(F(w)*F(factor))
        out.append(min(64.,max(1.,v)))
    return out
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');lib=load(W/'library.json');classes=family_classes(lib);state=load(BASE/'selected-state.json');modes=state['modes'];values=state['values'];weights=state['pair_weights'];plan=load(S/'plan.json');result=load(S/'result.json');process=load(S/'process.json');jobprocess=load(S/'job.json');job=load(JOB);fixedids={(r['part_id'],r['copy_index']) for r in lib['fixed_source_rows']};options=load(W/'audit-v2/optimizer-controls.json')['options'];old_closed={r['key'] for r in load(BASE/'closed-weighted-problems.json')};visited=set(old_closed);center_total=0;points=evals=trials_total=calls=updates=0;global_best=None;valid_witness=None;checks=[];overruns=[];inputs=[Path(__file__),JOB]+[ROOT/'output'/n for n in ['h5_weighted_original_model_20261107.py','h5_weighted_original_readback_20261107.py','h5_hard_cell_compound_modes_20261107.py','h5_legacy64_source_readback.py']]+[BASE/n for n in ['plan.json','plan-v2.json','selected-state.json','selected-model.json','closed-weighted-problems.json','audit-v2/plan.json','audit-v2/checks.json']]+[W/n for n in ['library.json','audit-v2/optimizer-controls.json','audit-v2/tool-provenance.json']]+[ROOT/'output/h5_relocated_selection_readback_20261107.py']+[S/n for n in ['plan.json','result.json','process.json','job.json','supervisor-opened.json']]
for epoch,folder in enumerate(sorted(S.glob('epoch-*'))):
    opened=load(folder/'opened.json');assert opened['epoch']==epoch and opened['incoming_values']==values and opened['incoming_modes']==modes and opened['weights_before_update']==weights and opened['visited_weighted_problems']==sorted(visited);incoming=values;incoming_modes=modes;inputs.append(folder/'opened.json')
    if epoch:
        transition=load(folder/'weight-transition.json');previous=compile_model(lib,modes,values,weights);losses=independent_losses(previous,values);assert np.max(np.abs(np.asarray(losses)-transition['pair_losses_mm2']))<1e-7 and transition['before']==weights and transition['source']=='previous_epoch_weighted_best';assert independent_update(weights,transition['pair_losses_mm2'])==transition['after'];weights=transition['after'];updates+=1;inputs.append(folder/'weight-transition.json')
        records=load(folder/'neighbors.json');aliases=load(folder/'owner-aliases.json');centers=load(folder/'center-trials.json');selections=load(folder/'center-selections.json');selection=verify_selection(lib,modes,incoming,weights,classes,visited,records,aliases,centers,selections,OUT/f'epoch-{epoch:02d}-selection')
        assert selection==load(folder/'selection.json');trials_total+=len(records);center_total+=len(centers);inputs+=[folder/n for n in ['neighbors.json','owner-aliases.json','center-trials.json','center-selections.json','selection.json']]
        if result['status']=='TIME_STOP_AFTER_SELECTION' and not (folder/'optimizer-opened.json').exists():assert result['algorithm_seconds_including_preparation']>=56;break
        if not selection['joint_improves_current_and_single']:assert result['status']=='NO_IMPROVING_JOINT_RELOCATION' and not (folder/'optimizer-opened.json').exists();break
        selected=selection['best_joint'];assert selected==load(folder/'selected-mode.json');modes=selected['modes'];incoming=incoming.copy()
        for (i,mi),center in zip(selected['changes'],selected['centers']):incoming[2*i:2*i+2]=center
        model=compile_model(lib,modes,incoming,weights);inputs.append(folder/'selected-mode.json')
    else:model=compile_model(lib,modes,values,weights)
    if not (folder/'optimizer-opened.json').exists():
        assert result['status']=='TIME_STOP_BEFORE_CALL';break
    assert model==load(folder/'model.json') and verify(model,lib,modes,incoming,weights) and any(w!=1 for w in weights);key=key_for(modes,weights);assert key not in visited;visited.add(key);opened_call=load(folder/'optimizer-opened.json');assert opened_call['key']==key and opened_call['model_sha256']==digest(folder/'model.json') and opened_call['options']==options and opened_call['parameters']==81 and opened_call['analytic_jacobian'] and not opened_call['uniform_weight_problem'];response=load(folder/'response.json');assert response['closed'] and response['key']==key and response['status'] in ['TIME_STOP','RETURNED'] and (response['numerical_result'] is None)==(response['status']=='TIME_STOP');obj=Objective(model);bounds=np.asarray(model['bounds']);saved=sorted((folder/'points').glob('*.json'));assert len(saved)==response['saved_points'];bestw=bestu=None;last_eval=-1
    for sequence,p in enumerate(saved):
        r=load(p);x=np.asarray(r['values']);energy,g,details=obj.evaluate(x,True);assert r['sequence']==sequence and last_eval<r['evaluation']<=response['evaluations'] and energy==r['weighted_objective_mm2'] and details['unweighted_objective_mm2']==r['unweighted_objective_mm2'] and np.array_equal(g,r['gradient']) and np.all(x>=bounds[:,0]) and np.all(x<=bounds[:,1]);iw=bestw is None or energy<bestw['weighted_objective_mm2'];iu=bestu is None or details['unweighted_objective_mm2']<bestu['unweighted_objective_mm2'];assert (iw or iu) and r['improved_weighted']==iw and r['improved_unweighted']==iu
        if sequence==0:assert r['values']==model['initial'] and r['evaluation']==0
        if iw:bestw=r
        if iu:bestu=r
        last_eval=r['evaluation']
    assert bestw==response['weighted_best'] and bestu==response['unweighted_best'];points+=len(saved);evals+=response['evaluations'];calls+=1;assert response['allocated_seconds']==opened_call['allocated_seconds']<=10 and response['slice_overrun_seconds']==max(0.,response['returned_seconds']-response['allocated_seconds']);overruns.append(response['slice_overrun_seconds']);local={}
    for label,record in [('weighted',bestw),('unweighted',bestu)]:
        rows=independent_rows(model,record['values']);assert rows==load(folder/(label+'-source66.json'));source=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));assert source==load(folder/(label+'-source-checks.json')) and source['originals']==66 and source['same_sheet_pairs']==1380 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026 and source['stock_failures']==0;assert all(p['passed'] for p in source['pairs'] if any(tuple(k) in fixedids for k in p['keys']));losses=independent_losses(model,record['values']);original=sum(p['intersection_area_mm2'] for p in source['pairs']);readback={'unweighted_objective_mm2':record['unweighted_objective_mm2'],'original_overlap_mm2':Objective(model).evaluate(record['values'],True)[2]['original_overlap_area_mm2'],'pair_failures':source['pair_failures'],'source_valid66':source['valid']};assert readback==response['source_readbacks'][label] and abs(sum(losses)-record['unweighted_objective_mm2'])<1e-7 and abs(original-readback['original_overlap_mm2'])<1e-7;local[label]={'source_pair_failures':source['pair_failures'],'positive_intersections':sum(p['intersection_area_mm2']>0 for p in source['pairs'] if not p['passed']),'original_overlap_mm2':original,'source_valid66':source['valid']};write(OUT/f'epoch-{epoch:02d}-{label}-source-checks.json',source)
        if source['valid'] and valid_witness is None:valid_witness={'epoch':epoch,'label':label,'modes':modes,'values':record['values'],'source66_path':(folder/(label+'-source66.json')).relative_to(ROOT).as_posix()}
    candidate={'epoch':epoch,'modes':modes,'values':bestu['values'],'unweighted_objective_mm2':bestu['unweighted_objective_mm2'],'source_pair_failures':local['unweighted']['source_pair_failures'],'source_valid66':local['unweighted']['source_valid66']}
    if global_best is None or candidate['unweighted_objective_mm2']<global_best['unweighted_objective_mm2'] or candidate['source_valid66']:global_best=candidate
    assert global_best==response['global_best'];checks.append({'epoch':epoch,'key':key,'minimum_weight':min(weights),'maximum_weight':max(weights),'saved_points':len(saved),'function_evaluations':response['evaluations'],'weighted_and_unweighted_winners_differ':bestw['values']!=bestu['values'],'source_readbacks':local});values=bestw['values'];inputs+=saved+[folder/n for n in ['model.json','optimizer-opened.json','response.json','weighted-source66.json','weighted-source-checks.json','unweighted-source66.json','unweighted-source-checks.json']]
assert calls==result['optimizer_calls']==result['unique_weighted_problems']==len(visited)-len(old_closed)<=3 and center_total==result['center_trials'] and result['historical_closed_keys']==len(old_closed)==4 and trials_total==result['mode_trials'] and global_best==result['best_global_unweighted'] and valid_witness==result['valid_witness'] and result['source_valid66']==(valid_witness is not None);assert result['uniform_weight_calls']==result['native_calls']==0 and not result['old_calls_resumed'] and not result['any_allocation_excluded'] and not result['H5_complete'];assert result['status'] in ['MAXIMUM_EPOCHS','SOURCE_VALID_CANDIDATE','TIME_STOP_BEFORE_EPOCH','TIME_STOP_AFTER_SELECTION','TIME_STOP_BEFORE_CALL','TIME_STOP_AFTER_SOURCE_CHECK','NO_IMPROVING_JOINT_RELOCATION']
if result['status']=='MAXIMUM_EPOCHS':assert calls==3
if result['status']=='SOURCE_VALID_CANDIDATE':assert valid_witness is not None
assert process['exit_code']==jobprocess['error_code']==jobprocess['reason_code']==jobprocess['active_processes']==0 and process['job']==jobprocess and jobprocess['closed'] and jobprocess['peak_job_committed_memory']<2**31 and result['algorithm_seconds_including_preparation']<=process['seconds_including_preparation']<60 and result['algorithm_overrun_seconds']==0;assert plan['complete_preparation_seconds']==load(BASE/'audit-v2/checks.json')['complete_preparation_seconds']
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in data.get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings);write(OUT/'epoch-reconciliation.json',checks);write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Replay every weighted update using binary64 operations independently rounded from exact rational arithmetic, every nominal grid/control center trial and distinct one/two-owner physical/coefficient proposal, dynamic model and weighted full score. Recompute every saved objective/gradient and both independent incumbent measures. Reconstruct and independently validate both full66 winners after every call, including every fixed/moving pair and stock edge. Verify global unweighted accounting, separate valid witness, all stops, timings, complete preparation, distinct problems and closure. Verification only, no optimizer/native call.'})
best=checks[global_best['epoch']]['source_readbacks']['unweighted'];summary={'passed':True,'seconds':time.perf_counter()-started,'source_bindings':len(bindings),'closed_optimizer_calls':calls,'unique_weighted_problems':len(visited)-len(old_closed),'historical_closed_keys':len(old_closed),'runtime_center_trials_verified':center_total,'weight_update_vectors':updates,'weight_update_coefficients_verified':updates*528,'mode_trials_verified':trials_total,'saved_points_verified':points,'function_evaluations':evals,'source66_readbacks':calls*2,'epochs_with_different_incumbents':sum(r['weighted_and_unweighted_winners_differ'] for r in checks),'best_global_epoch':global_best['epoch'],'best_unweighted_objective_mm2':global_best['unweighted_objective_mm2'],**best,'complete_preparation_seconds':plan['complete_preparation_seconds'],'algorithm_seconds':result['algorithm_seconds_including_preparation'],'shared_seconds':process['seconds_including_preparation'],'slice_overruns_seconds':overruns,'all_descendants_closed':True,'uniform_weight_calls':0,'old_calls_resumed':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',summary);print(summary)
