"""One new objective identity on the unchanged, unoptimized source initializer."""
from pathlib import Path
from hashlib import sha256
import json,time,shutil,os
from h5_bracket_augmented_objective_20261107 import VERSION,compile_model,Objective,problem_key
from h5_bracket_augmented_readback_20261107 import verify
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-bracket-augmented-model-20261107'
W=ROOT/'output/h5-weighted-mixed-rows-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();assert affinity_mask()==4294901760
assert all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
assert load(B/'audit-v2/checks.json')['passed'] and load(W/'audit-v2/checks.json')['passed']
code_names=['h5_bracket_augmented_objective_20261107.py','h5_bracket_collision_depth_20261107.py','h5_cross_pair_weighted_model_20261107.py','h5_cross_pair_boundary_gradient_20261107.py','h5_weighted_original_model_20261107.py','h5_movable_roof_model_20261107.py','h5_hard_cell_vector_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_direct_pose_model_20261107.py']
inputs=[Path(__file__)]+[ROOT/'output'/n for n in code_names+['h5_bracket_augmented_readback_20261107.py','h5_bracket_augmented_reference_20261107.py','audit_h5_bracket_augmented_model_20261107.py','h5_hard_cell_compound_modes_20261107.py','h5_checked_affinity_20261107.py']]
inputs += [W/n for n in ['plan.json','library.json','model.json','initial-state.json','audit-v2/checks.json','audit-v2/optimizer-controls.json','audit-v2/tool-provenance.json']]
inputs += [B/n for n in ['plan.json','plan-v2.json','regions.json','audit-v2/checks.json']]
inputs += [R/'closed-weighted-problems.json']+[R/f'search/epoch-{i:02d}/response.json' for i in range(3)]
parent=ROOT/'benchmarks/results/h5-bracket-collision-depth-preflight-20261107';inputs += [parent/'next-step.json',parent/'archive-checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Prepare exactly one separately versioned augmented model from W original unoptimized state, retaining all source identities, hard domains and original positive weights. Add fixed coefficient1 bracket depth. No mode selection, new initializer, optimizer or saved optimized state consumed. Preserve7 closed area-only weighted keys and distinguish the entire new objective identity in closure keys.',
    'complete_prior_preparation_seconds':load(parent/'checks.json')['complete_source_preparation_seconds_before_new_model'],'score_tolerance_mm2':1e-6,'scalar_gradient_tolerance_mm':1e-6,'central_steps':[1e-5,1e-6],'central_absolute_tolerance':.02,'central_relative_tolerance':3e-6,'central_interpretation':'Unique nearest-feature cases only for depth; area shared-boundary cases are marked symmetric-convention controls, not unique derivatives.','parameters':81,'pair_terms':528,'auxiliary_pair_terms':15,'all_legal_owner_modes_to_check':147,'optimizer_calls':0,'preparation_cap_seconds':20,'memory_bytes':2**31,'retry_permitted':False})
lib=load(W/'library.json');initial=load(W/'initial-state.json');regions=load(B/'regions.json')
identity={'version':VERSION,'area_terms':'all528_weighted_original_plus_clearance_areas','auxiliary_policy':regions['policy'],'regions_sha256':digest(B/'regions.json'),'code_sha256':{n:digest(ROOT/'output'/n) for n in code_names}}
model=compile_model(lib,initial['modes'],initial['values'],initial['pair_weights'],identity)
assert verify(model,lib,initial['modes'],initial['values'],initial['pair_weights'],identity)
assert {k:v for k,v in model.items() if k!='supplementary_objective'}==load(W/'model.json')
value,g,info=Objective(model,regions,identity).evaluate(model['initial'],True)
assert abs(value-Objective(model,regions,identity).score(model['initial']))<1e-6
old=load(R/'closed-weighted-problems.json');assert len(old)==4
closed=[{'key':r['key'],'objective':'area_only_weighted','source':'output/h5-bracket-augmented-model-20261107/plan.json'} for r in old]
for i in range(3):
    r=load(R/f'search/epoch-{i:02d}/response.json');assert r['closed'];closed.append({'key':r['key'],'objective':'area_only_weighted','source':(R/f'search/epoch-{i:02d}/response.json').relative_to(ROOT).as_posix()})
assert len({r['key'] for r in closed})==7
key=problem_key(physical_key(lib,family_classes(lib),initial['modes']),initial['pair_weights'],identity)
assert key not in {r['key'] for r in closed}
for name in ['library.json','initial-state.json']:shutil.copyfile(W/name,OUT/name)
write(OUT/'objective-identity.json',identity);write(OUT/'model.json',model);write(OUT/'closed-prior-problems.json',closed)
write(OUT/'initial-objective.json',{'augmented_objective_mm2':value,'gradient':g.tolist(),**info})
runtime=load(B/'runtime-bindings.json')
for name,h in runtime.items():assert digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'parameters':81,'source_movers':33,'exact_area_pairs':528,'auxiliary_pairs':15,'initial_augmented_objective_mm2':value,'new_problem_key':key,'preserved_closed_area_only_problems':7,'complete_prior_preparation_seconds':load(OUT/'plan.json')['complete_prior_preparation_seconds'],'model_sha256':digest(OUT/'model.json'),'initial_state_unchanged':digest(OUT/'initial-state.json')==digest(W/'initial-state.json'),'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
