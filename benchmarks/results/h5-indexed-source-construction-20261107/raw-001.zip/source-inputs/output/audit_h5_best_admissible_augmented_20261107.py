"""Verify merged ranking on full source readbacks and a new original initializer."""
from pathlib import Path
from hashlib import sha256
import json,time,copy,os
import numpy as np
from h5_augmented_admissible_choice_20261107 import choose
from h5_augmented_admissible_readback_20261107 import verify_choice
from h5_augmented_selection_readback_20261107 import independent_classes
from h5_augmented_selection_score_reference_20261107 import FullScore
from h5_bracket_augmented_reference_20261107 import Reference
from h5_bracket_augmented_objective_20261107 import Objective
from h5_bracket_augmented_readback_20261107 import verify
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';OUT=BASE/'audit';P=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();plan=load(BASE/'plan.json');assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
for name,h in load(BASE/'runtime-bindings.json').items():assert digest(ROOT/name)==h,name
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','neighbors.json','closed-problems.json','selection.json','runtime-bindings.json']]+[ROOT/'output/h5-best-admissible-augmented-preparation-process-20261107/process.json']
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');classes=independent_classes(lib);closed=load(BASE/'closed-problems.json');expected=load(P/'closed-problems.json')
for epoch in [0,1]:
    path=P/f'search/epoch-{epoch:02d}/closed-problem.json';r=load(path);assert r['closed'];expected.append({'key':r['key'],'objective':identity['version'],'source':path.relative_to(ROOT).as_posix()})
assert closed==expected and len(closed)==11;keys={r['key'] for r in closed};assert len(keys)==11
records=load(BASE/'neighbors.json');old=load(P/'neighbors.json');changed=[]
for previous,row in zip(old,records):
    expected=copy.deepcopy(previous);expected['excluded']=row['key'] in keys;expected['exclusion_reason']='closed_objective_problem' if expected['excluded'] else None;assert row==expected
    if row!=previous:changed.append(row['sequence'])
    physical=[classes[f][mi] for (f,_),mi in zip(lib['identities'],row['modes'])];key=sha256(json.dumps({'physical':physical,'weights':initial['pair_weights'],'objective_identity':identity},sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    assert physical==row['physical_key'] and key==row['key']
assert changed==[load(P/'selection.json')['best_joint']['sequence']] and sum(r['excluded'] for r in records)==3
selected=load(BASE/'selection.json');assert selected==choose(records)
checks=[{'case':'new_original_source',**verify_choice(records,load(N/'audit/selection-replay/proposal-score-controls.json'),selected),'selection':selected}]
for epoch in [1,2]:
    raw=P/f'search/epoch-{epoch:02d}';audited=P/f'response-audit/epoch-{epoch:02d}-selection';assert load(audited/'checks.json')['passed'];rows=load(raw/'neighbors.json');selection=choose(rows)
    checks.append({'case':f'prior_runtime_{epoch}','validation_only':True,**verify_choice(rows,load(audited/'proposal-score-controls.json'),selection),'selection':selection})
    inputs+=[raw/'neighbors.json',raw/'selection.json',audited/'checks.json',audited/'proposal-score-controls.json']
assert checks[1]['accepted_changed_owners']==2 and checks[1]['joint_only_rule_would_accept']
assert checks[2]['accepted_changed_owners']==1 and not checks[2]['joint_only_rule_would_accept']
write(OUT/'choice-policy-controls.json',checks)
controls=[];allclosed=copy.deepcopy(records)
for row in allclosed:row['excluded']=True;row['exclusion_reason']='closed_objective_problem'
r=choose(allclosed);assert r['accepted_choice'] is None and r['best_admissible'] is None;controls.append({'case':'all_closed','accepted':False})
noimprovement=copy.deepcopy(records);noimprovement[0]['augmented_objective_mm2']=selected['best_admissible']['augmented_objective_mm2'];r=choose(noimprovement);assert not r['strictly_improves_current'] and r['accepted_choice'] is None;controls.append({'case':'zero_strict_margin','accepted':False})
try:choose(records[:-1])
except AssertionError:controls.append({'case':'partial_pool','rejected':True})
else:raise AssertionError('Partial pool must never be selected')
write(OUT/'policy-stop-controls.json',{'passed':True,'controls':controls,'scope':'Policy-only synthetic score/closure controls, not source geometry or successor seeds.','optimizer_calls':0})
prior_plan=load(P/'plan.json');unchanged=['h5_augmented_deadline_neighbors_20261107.py','h5_bracket_augmented_readback_20261107.py']
for name in unchanged:assert digest(ROOT/'output'/name)==prior_plan['inputs']['output/'+name]
assert load(P/'audit/deadline-controls.json')['passed'] and load(P/'audit/weight-update-controls.json')['passed']
write(OUT/'inherited-controls.json',{'passed':True,'unchanged_deadline_helper':digest(ROOT/'output/h5_augmented_deadline_neighbors_20261107.py'),'prior_deadline_cases':7,'prior_complete_selector_preserved':True,'area_weight_policy_unchanged':True,'auxiliary_coefficient':1.,'no_new_deadline_or_weight_tuning':True})
model_controls=None
chosen=selected['accepted_choice']
if chosen is not None:
    modes=initial['modes'].copy();point=initial['values'].copy()
    for (i,mi),center in zip(chosen['changes'],chosen['centers']):modes[i]=mi;point[2*i:2*i+2]=center
    model=load(BASE/'selected-model.json');state=load(BASE/'selected-state.json');weights=initial['pair_weights'];assert state=={'modes':modes,'values':point,'pair_weights':weights,'key':chosen['key'],'objective_identity':identity}
    assert verify(model,lib,modes,point,weights,identity) and chosen['key'] not in keys;score=FullScore(lib,weights,regions)(modes,point);assert abs(score['augmented_objective_mm2']-chosen['augmented_objective_mm2'])<1e-6
    value,g,d=Objective(model,regions,identity).evaluate(point,True);rv,rg,rd=Reference(lib).evaluate(model,point,True,d['auxiliary_terms']);assert abs(value-rv)<1e-6 and np.max(np.abs(g-rg))<1e-6
    model_controls={'passed':True,'parameters':81,'moving_owners':33,'all_area_pairs':528,'all_auxiliary_pairs':15,'chosen_changes':chosen['changes'],'key':chosen['key'],'augmented_objective_mm2':value,'original_overlap_mm2':d['original_overlap_area_mm2'],'maximum_scalar_gradient_error_mm':float(np.max(np.abs(g-rg))),'independent_score_error_mm2':abs(value-rv),'scalar_directed_gradient_terms':rd['directed_scalar_gradient_terms'],'gradient_interpretation':'Existing selected source-boundary/nearest-feature conventions; no blanket smoothness guarantee.','optimized_ancestor_consumed':False};write(OUT/'selected-model-controls.json',model_controls);inputs+=[BASE/'selected-model.json',BASE/'selected-state.json']
else:assert not (BASE/'selected-model.json').exists() and not (BASE/'selected-state.json').exists()
prep=load(ROOT/'output/h5-best-admissible-augmented-preparation-process-20261107/process.json');assert prep['passed'] and prep['closed'] and prep['job']['active_processes']==0;charge=plan['complete_prior_preparation_seconds']+prep['complete_seconds'];assert plan['complete_prior_preparation_seconds']==load(P/'audit/checks.json')['complete_preparation_seconds']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently check all source identities and expanded closure flags, re-rank complete independent score readbacks for new source and two prior dynamic cases, verify strict margins and preserved single/joint diagnostics. Stopped historical choices are validation only. Check all-closed, no-improvement and partial-list stops. Reconstruct new original-source model and scalar scores/gradient; bind inherited deadline and weight controls. No optimizer.'})
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in data.get('inputs',{}).items():
        z=ROOT/name;assert digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json','plan-v2.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings);summary={'passed':True,'seconds':time.perf_counter()-start,'source_bindings':len(bindings),'independent_full_score_readbacks_reranked':sum(r['full_scores_verified'] for r in checks),'choice_contexts':len(checks),'accepted_changed_owner_counts':[r['accepted_changed_owners'] for r in checks],'maximum_saved_score_error_mm2':max(r['maximum_score_error_mm2'] for r in checks),'closed_keys':11,'excluded_source_choices':3,'strictly_improves_current':chosen is not None,'fresh_selected_model_readback':model_controls is not None,'policy_stop_controls':3,'inherited_deadline_controls':7,'new_source_preparation_seconds':prep['complete_seconds'],'complete_preparation_seconds':charge,'optimized_ancestor_consumed':False,'validation_outputs_used_as_seed':False,'optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',summary);print(summary)
