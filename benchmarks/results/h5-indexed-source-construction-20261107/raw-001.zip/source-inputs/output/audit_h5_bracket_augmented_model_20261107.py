"""Read back the full new objective, every owner mode and combined derivatives."""
from pathlib import Path
from hashlib import sha256
import json,time,copy,math
import numpy as np
from h5_bracket_augmented_objective_20261107 import compile_model,Objective,problem_key
from h5_bracket_augmented_readback_20261107 import verify
from h5_bracket_augmented_reference_20261107 import Reference
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'audit'
B=ROOT/'output/h5-bracket-collision-depth-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();plan=load(BASE/'plan.json')
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
lib=load(BASE/'library.json');initial=load(BASE/'initial-state.json');identity=load(BASE/'objective-identity.json');regions=load(B/'regions.json');model=load(BASE/'model.json')
assert lib==load(W/'library.json') and initial==load(W/'initial-state.json')
assert identity['regions_sha256']==digest(B/'regions.json') and identity['auxiliary_policy']==regions['policy']
expected_names={'h5_bracket_augmented_objective_20261107.py','h5_bracket_collision_depth_20261107.py','h5_cross_pair_weighted_model_20261107.py','h5_cross_pair_boundary_gradient_20261107.py','h5_weighted_original_model_20261107.py','h5_movable_roof_model_20261107.py','h5_hard_cell_vector_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_direct_pose_model_20261107.py'}
assert set(identity)=={'version','area_terms','auxiliary_policy','regions_sha256','code_sha256'} and set(identity['code_sha256'])==expected_names
for name,h in identity['code_sha256'].items():assert digest(ROOT/'output'/name)==h
assert verify(model,lib,initial['modes'],initial['values'],initial['pair_weights'],identity)
assert {k:v for k,v in model.items() if k!='supplementary_objective'}==load(W/'model.json')
reference=Reference(lib);obj=Objective(model,regions,identity);value,g,info=obj.evaluate(model['initial'],True)
assert load(BASE/'initial-objective.json')=={'augmented_objective_mm2':value,'gradient':g.tolist(),**info}
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),BASE/'plan.json',BASE/'model.json',BASE/'objective-identity.json',BASE/'initial-state.json',BASE/'initial-objective.json',BASE/'closed-prior-problems.json',ROOT/'output/h5-bracket-augmented-model-preparation-process-20261107/process.json',R/'search/epoch-02/model.json',R/'search/epoch-02/response.json']},'method':'Independently read every model field and identity. Rebuild scalar original/clearance polygons and rational bracket boundaries for all147legal owner options. Check full scalar gradients in two fixed validation cases and combined central samples at both predeclared step sizes. Validate closure-key objective binding and deliberate corruptions. No optimization or candidate selection.'})
scores=[];max_score_error=0.
for i,(family,_) in enumerate(lib['identities']):
    for mode in lib['family_modes'][family]:
        modes=initial['modes'].copy();modes[i]=mode['mode'];m=compile_model(lib,modes,initial['values'],initial['pair_weights'],identity)
        assert verify(m,lib,modes,initial['values'],initial['pair_weights'],identity)
        scalar,_,d=reference.evaluate(m,m['initial']);got=Objective(m,regions,identity).score(m['initial']);err=abs(got-scalar);max_score_error=max(max_score_error,err);assert err<plan['score_tolerance_mm2']
        scores.append({'owner':i,'mode':mode['mode'],'augmented_mm2':got,'independent_mm2':scalar,'auxiliary_mm2':d['auxiliary_bracket_depth_mm2'],'error_mm2':err})
assert len(scores)==147;write(OUT/'all-owner-mode-scores.json',scores)
flat=load(R/'search/epoch-02/model.json');flat_x=load(R/'search/epoch-02/response.json')['unweighted_best']['values'];flat_modes=[o['mode'] for o in flat['owners']]
flat_model=compile_model(lib,flat_modes,flat_x,flat['pair_weights'],identity)
cases=[('source_initializer',model,model['initial']),('closed_flat_validation_only',flat_model,flat_x)]
gradient_records=[];central=[];max_scalar_error=max_central_error=0.;scalar_terms=0
for label,m,x in cases:
    obj=Objective(m,regions,identity);value,g,d=obj.evaluate(x,True);independent,gg,dd=reference.evaluate(m,x,True,d['auxiliary_terms'])
    assert abs(value-independent)<plan['score_tolerance_mm2'];error=float(np.max(np.abs(g-gg)));max_scalar_error=max(max_scalar_error,error);assert error<plan['scalar_gradient_tolerance_mm']
    scalar_terms+=dd['directed_scalar_gradient_terms'];assert all(t['distinct_closest_points']<=1 for t in dd['auxiliary_terms'])
    gradient_records.append({'case':label,'augmented_mm2':value,'independent_mm2':independent,'max_scalar_gradient_error':error,'shared_boundary_length_mm':dd['coincident_boundary_length_mm'],'scalar_directed_terms':dd['directed_scalar_gradient_terms'],'auxiliary_nearest_features_unique':True,'classification':'symmetric_shared_boundary_convention' if dd['coincident_boundary_length_mm'] else 'no_shared_boundary'})
    for h in plan['central_steps']:
        for k in range(81):
            xp=np.array(x);xm=np.array(x);xp[k]+=h;xm[k]-=h
            gp=(obj.score(xp)-obj.score(xm))/(2*h);err=abs(gp-g[k]);tolerance=plan['central_absolute_tolerance']+plan['central_relative_tolerance']*abs(g[k])
            assert err<tolerance,(label,h,k,err,tolerance)
            max_central_error=max(max_central_error,err);central.append({'case':label,'step':h,'coordinate':k,'analytic':float(g[k]),'central':gp,'error':err,'tolerance':tolerance})
write(OUT/'scalar-gradient-controls.json',gradient_records);write(OUT/'central-controls.json',central)
negative=[]
def corrupt(label,edit):
    bad=copy.deepcopy(model);edit(bad)
    try:verify(bad,lib,initial['modes'],initial['values'],initial['pair_weights'],identity)
    except AssertionError:negative.append(label)
    else:raise AssertionError('accepted corruption: '+label)
corrupt('missing_auxiliary_pair',lambda m:m['supplementary_objective']['pair_indices'].pop())
corrupt('changed_coefficient',lambda m:m['supplementary_objective']['identity']['auxiliary_policy'].__setitem__('coefficient',2))
corrupt('wrong_regions_digest',lambda m:m['supplementary_objective']['identity'].__setitem__('regions_sha256','0'*64))
corrupt('wrong_identity_digest',lambda m:m['supplementary_objective'].__setitem__('identity_sha256','0'*64))
corrupt('missing_area_pair',lambda m:m['pairs'].pop())
corrupt('changed_hard_bound',lambda m:m['bounds'][0].__setitem__(0,m['bounds'][0][0]-1))
corrupt('wrong_source_center',lambda m:m['owners'][0].__setitem__('source_center',[0,0]))
corrupt('zero_weight',lambda m:m['pair_weights'].__setitem__(0,0))
corrupt('wrong_initial_coordinate',lambda m:m['initial'].__setitem__(0,m['initial'][0]+1))
write(OUT/'negative-controls.json',negative)
physical=list(physical_key(lib,family_classes(lib),initial['modes']));key=sha256(json.dumps({'physical':physical,'weights':initial['pair_weights'],'objective_identity':identity},sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert key==problem_key(physical,initial['pair_weights'],identity)==load(BASE/'checks.json')['new_problem_key']
oldkeys=load(BASE/'closed-prior-problems.json');assert len(oldkeys)==len({r['key'] for r in oldkeys})==7 and key not in {r['key'] for r in oldkeys}
base_key=sha256(json.dumps({'physical':physical,'weights':initial['pair_weights']},separators=(',',':')).encode()).hexdigest()
assert base_key in {r['key'] for r in oldkeys} and base_key!=key
write(OUT/'closure-controls.json',{'new_objective_key':key,'old_area_only_key':base_key,'old_area_only_key_remains_closed':True,'prior_keys':oldkeys,'new_objective_explicitly_distinguished':True})
options=load(W/'audit-v2/optimizer-controls.json');assert options['passed'] and options['source_optimizer_calls']==0
write(OUT/'optimizer-controls.json',options)
prep=load(ROOT/'output/h5-bracket-augmented-model-preparation-process-20261107/process.json');assert prep['passed'] and prep['closed'] and prep['job']['active_processes']==0
charge=plan['complete_prior_preparation_seconds']+prep['complete_seconds']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'model_sha256':digest(BASE/'model.json'),'objective_identity_sha256':model['supplementary_objective']['identity_sha256'],'parameters':81,'movers':33,'original_pairs':528,'auxiliary_pairs':15,'legal_owner_mode_scores':len(scores),'max_score_error_mm2':max_score_error,'scalar_directed_gradient_terms':scalar_terms,'scalar_combined_gradient_coordinates':162,'max_scalar_gradient_error_mm':max_scalar_error,'central_samples':len(central),'max_central_error':max_central_error,'corruptions_rejected':len(negative),'prior_closed_keys_preserved':7,'complete_preparation_seconds':charge,'source_initializer_only':True,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
