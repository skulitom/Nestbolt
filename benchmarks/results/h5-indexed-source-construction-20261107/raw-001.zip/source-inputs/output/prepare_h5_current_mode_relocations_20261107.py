"""Freeze and compute the broader source-only center neighborhood and key minima."""
from pathlib import Path
from hashlib import sha256
import json,time,os
from h5_current_mode_relocations_20261107 import neighbors,apply_neighbor,SelectionDeadline
from h5_current_mode_key_choice_20261107 import choose,KeySelectionDeadline
from h5_bracket_augmented_readback_20261107 import verify
from h5_bracket_augmented_objective_20261107 import Objective
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-current-mode-relocation-preflight-20261107';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
parent=ROOT/'benchmarks/results/h5-best-admissible-augmented-construction-20261107';assert load(parent/'archive-checks.json')['passed'] and load(Q/'response-audit/checks.json')['passed']
inputs=[Path(__file__),parent/'next-step.json',parent/'archive-checks.json']+[ROOT/'output'/n for n in ['h5_current_mode_relocations_20261107.py','h5_current_mode_key_choice_20261107.py','h5_current_mode_selection_readback_20261107.py','h5_current_mode_key_readback_20261107.py','h5_current_mode_source_domains_20261107.py','audit_h5_current_mode_relocations_20261107.py','h5_bracket_augmented_objective_20261107.py','h5_bracket_augmented_readback_20261107.py']]+[Q/n for n in ['plan.json','closed-problems.json','audit/checks.json','response-audit/checks.json','search/epoch-00/closed-problem.json','search/epoch-01/closed-problem.json','search/epoch-02/closed-problem.json','outcome-diagnostic/neighborhood-coverage.json','runtime-bindings.json']]+[A/n for n in ['library.json','initial-state.json','objective-identity.json']]+[B/'regions.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Include every owner current physical mode first, followed by canonical changed classes, preserving all original A/W source coordinates, angles, weights and hard domains. Recompute every fixed9x9source-grid/clamped trial under the complete528area+15coefficient1auxiliary objective. Score5911raw current/single/joint proposals, replacing mutual pairs once. Retain every raw placement and coordinate alias. Group by the existing complete objective/physical-mode/weight key; record one deterministic minimum per key, exclude all14closed keys, then require strict baseline improvement. Different coordinates never create new optimizer keys. No optimized ancestor or saved stopping candidate is used.',
    'complete_prior_preparation_seconds':load(Q/'audit/checks.json')['complete_preparation_seconds'],'prior_lineage_cost_retained_despite_full_score_recomputation':True,'physical_owner_mode_options':111,'nominal_center_trials':9102,'raw_proposals':5911,'distinct_physical_vectors':2854,'expected_key_size_histogram':{'1':2775,'33':78,'562':1},'closed_keys':14,'grid_fractions':[i/8 for i in range(9)],'score_tolerance_mm2':1e-6,'strict_improvement_mm2':1e-6,
    'ranking':'Centers: unrounded augmented score,XY,local index. Proposals and key minima: unrounded augmented score, full mode vector, number of owner replacements, ordered owner/mode pairs, ordered centers, raw sequence. Score uses complete weighted-area dot and sequential15-term auxiliary sum. Independent full geometry verifies every score and minimum within1e-6; any numerical ranking disagreement is retained.',
    'deadline_seconds_from_preparation_start':28,'preparation_cap_seconds':30,'memory_bytes':2**31,'deadline_controls':{'neighborhood_expiry_checkpoints':[1,4,225,226,3000,6136],'key_choice_expiry_checkpoints':[1,2,3,4],'real_neighborhood_seconds':.05,'partial_policy':'Preserve partial output and select no candidate.'},'optimizer_calls':0,'retry_permitted':False})
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');closed=load(Q/'closed-problems.json')
for epoch in [0,1,2]:
    path=Q/f'search/epoch-{epoch:02d}/closed-problem.json';r=load(path);assert r['closed'] and not r['retry_permitted'];closed.append({'key':r['key'],'objective':identity['version'],'source':path.relative_to(ROOT).as_posix()})
keys={r['key'] for r in closed};assert len(closed)==len(keys)==14;write(OUT/'closed-problems.json',closed)
try:
    records,aliases,trials,selections=neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys,deadline=start+28)
except SelectionDeadline as exc:
    write(OUT/'partial-neighborhood.json',exc.evidence);write(OUT/'checks.json',{'prepared':False,'status':'NEIGHBORHOOD_DEADLINE','seconds':time.perf_counter()-start,'optimizer_calls':0,'H5_complete':False});raise SystemExit(0)
for name,value in [('neighbors.json',records),('owner-aliases.json',aliases),('center-trials.json',trials),('center-selections.json',selections)]:write(OUT/name,value)
try:selection,groups,minima=choose(records,deadline=start+28)
except KeySelectionDeadline as exc:
    write(OUT/'partial-key-selection.json',exc.evidence);write(OUT/'checks.json',{'prepared':False,'status':'KEY_SELECTION_DEADLINE','seconds':time.perf_counter()-start,'optimizer_calls':0,'H5_complete':False});raise SystemExit(0)
write(OUT/'selection.json',selection);write(OUT/'group-members.json',groups);write(OUT/'key-minima.json',minima)
chosen=selection['accepted_choice']
if chosen is not None:
    modes,model,values=apply_neighbor(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,chosen)
    assert verify(model,lib,modes,values,initial['pair_weights'],identity) and chosen['key'] not in keys and abs(Objective(model,regions,identity).score(values)-chosen['augmented_objective_mm2'])<1e-6
    write(OUT/'selected-model.json',model);write(OUT/'selected-state.json',{'modes':modes,'values':values.tolist(),'pair_weights':initial['pair_weights'],'key':chosen['key'],'objective_identity':identity})
runtime=load(Q/'runtime-bindings.json')
for name,h in runtime.items():assert digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'physical_owner_mode_options':len(selections),'center_trials':len(trials),'unique_centers':sum(r['unique_centers'] for r in selections),'center_aliases':sum(r['duplicate_of'] is not None for r in trials),'raw_proposals':len(records),'distinct_keys':len(groups),'closed_keys':len(keys),'excluded_keys':selection['excluded_keys'],'excluded_raw_proposals':selection['excluded_raw_proposals'],'strictly_improves_current':chosen is not None,'accepted_owner_replacements':None if chosen is None else len(chosen['changes']),'accepted_score_mm2':None if chosen is None else chosen['augmented_objective_mm2'],'optimizer_calls':0,'optimized_ancestor_consumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
