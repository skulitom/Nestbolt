"""Restore only hash-bound original-source records, then update closure flags."""
from hashlib import sha256
import json,math,time
from h5_indexed_two_center_neighbors_20261107 import cache_context
NAMES=('neighbors.json','owner-aliases.json','center-trials.json','center-selections.json')
def restore(payloads,expected_sha,context,library,modes,values,weights,identity,regions):
    assert set(payloads)==set(expected_sha)==set(NAMES)
    assert context==cache_context(library,modes,values,weights,identity,regions)
    for name in NAMES:assert sha256(payloads[name]).hexdigest()==expected_sha[name],name
    result=tuple(json.loads(payloads[name]) for name in NAMES)
    assert len(result[0])==23419 and len(result[2])==9102 and len(result[3])==111
    return result
class ClosureDeadline(Exception):
    def __init__(self,evidence):self.evidence=evidence;super().__init__('Source closure rebinding stopped at deadline')
def rebind(records,closed_keys,deadline,clock=time.perf_counter):
    assert math.isfinite(deadline) and len(records)==23419
    result=[];checks=0
    def checkpoint(stage):
        nonlocal checks
        checks+=1;observed=clock()
        if observed>=deadline:raise ClosureDeadline({'complete':False,'status':'CLOSURE_DEADLINE','stage':stage,'checkpoints':checks,'deadline':deadline,'observed':observed,'overrun_seconds':observed-deadline,'records':result,'selected_proposal':None,'optimizer_calls':0})
    checkpoint('before-rebinding')
    for i,row in enumerate(records):
        if i%128==0:checkpoint('before-batch')
        assert row['sequence']==i
        row=row.copy();row['excluded']=row['key'] in closed_keys;row['exclusion_reason']='closed_objective_problem' if row['excluded'] else None;result.append(row)
    checkpoint('complete')
    return result
