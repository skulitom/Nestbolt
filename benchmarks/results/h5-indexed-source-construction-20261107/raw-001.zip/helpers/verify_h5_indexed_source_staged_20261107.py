"""Verify the exact staged evidence bytes and preserve unrelated main files."""
from pathlib import Path
from hashlib import sha256
import subprocess,json
ROOT=Path(__file__).resolve().parents[1];NAME='h5-indexed-source-construction-20261107'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
paths=git('diff','--cached','--name-only').decode().splitlines()
allowed={'.gitattributes','BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md'}
prefix='benchmarks/results/'+NAME
assert paths and all(p in allowed or p.startswith(prefix) for p in paths)
count=0
for name in paths:
    if not name.startswith(prefix):continue
    staged=git('show',':'+name);disk=(ROOT/name).read_bytes()
    assert staged==disk,name
    count+=1
protected=json.loads((ROOT/'output/h5-resume-reconciliation-20261106/remote-files.json').read_bytes())
for path,h in protected.items():assert git('rev-parse',':'+path).decode().strip()==h,path
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']:
    before=git('show','HEAD:'+name).decode().replace('\r\n','\n');after=git('show',':'+name).decode().replace('\r\n','\n');assert after.startswith(before),name
assert not git('diff','--name-only').strip()
checks=json.loads(git('show',':'+prefix+'/archive-checks.json'));assert checks['passed']
result={'passed':True,'staged_paths':len(paths),'exact_evidence_files':count,'protected_files_preserved':len(protected),'append_only_histories':3,'archive_passed':True,'optimizer_calls':0}
with (ROOT/'output/h5-indexed-source-staged-checks-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
print(result)
