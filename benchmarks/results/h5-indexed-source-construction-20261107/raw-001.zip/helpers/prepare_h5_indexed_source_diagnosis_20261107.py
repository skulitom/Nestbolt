"""Version residual diagnosis for the single closed call and partial selector."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/diagnose_h5_two_center_outcome_20261107.py').read_text(encoding='utf-8');s=s[:s.index('# Recorded runtime data only')]
changes={
    "BASE=ROOT/'output/h5-two-center-preflight-20261107'":"BASE=ROOT/'output/h5-indexed-source-preflight-20261107';V=ROOT/'output/h5-two-center-preflight-20261107'",
    "checked['best_original']['epoch']==1":"checked['best_original']['epoch']==0",
    'epoch-01':'epoch-00',
    "assert all(v['auxiliary_bracket_depth_mm2']==0 for v in response['source_readbacks'].values());":"assert all(v['auxiliary_bracket_depth_mm2']>=0 for v in response['source_readbacks'].values());",
    "U/'response-audit/checks.json']":"U/'response-audit/checks.json',V/'response-audit/checks.json']",
    "('prior_current_mode',U)]":"('prior_current_mode',U),('prior_two_center',V)]",
}
for a,b in changes.items():assert a in s,a;s=s.replace(a,b)
s+='\n'+(ROOT/'output/h5_indexed_partial_coverage_20261107.py').read_text(encoding='utf-8')
compile(s,'diagnose_h5_indexed_source_outcome_20261107.py','exec')
with (ROOT/'output/diagnose_h5_indexed_source_outcome_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Residual and complete validation-only partial-pool diagnosis prepared.')
