"""Read-only family failures, boundary obstruction and residual flat terms."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,time
import numpy as np
from shapely.affinity import translate
from h5_bracket_augmented_objective_20261107 import Objective
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-indexed-source-preflight-20261107';V=ROOT/'output/h5-two-center-preflight-20261107';U=ROOT/'output/h5-current-mode-relocation-preflight-20261107';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';P=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'outcome-diagnostic';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();checked=load(BASE/'response-audit/checks.json');assert checked['passed'] and checked['best_original']['epoch']==0
inputs=[Path(__file__)]+[BASE/n for n in ['response-audit/checks.json','response-audit/epoch-00/original-source-checks.json','search/epoch-00/response.json','search/epoch-00/model.json']]+[A/'objective-identity.json',A/'response-audit/checks.json',N/'response-audit/checks.json',P/'response-audit/checks.json',B/'regions.json',R/'response-audit/checks.json',W/'response-audit/checks.json',Q/'response-audit/checks.json',U/'response-audit/checks.json',V/'response-audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read-only composition of source failures, hard-bound descent obstruction and every positive original/clearance pair gradient in the closed original-area winner. Test only flat pair terms with the earlier fixed±.001/.1/1/5mm feasible translation probes. Compare prior audited outcomes without attributing a causal improvement. No candidate change, new initializer, search or allocation exclusion.','gradient_zero_tolerance':1e-7,'translation_steps_mm':[.001,.1,1.,5.],'optimizer_calls':0})
response=load(BASE/'search/epoch-00/response.json');assert all(v['auxiliary_bracket_depth_mm2']>=0 for v in response['source_readbacks'].values());model=load(BASE/'search/epoch-00/model.json');x=response['winners']['original']['values'];gradient=response['winners']['original']['gradient'];source=load(BASE/'response-audit/epoch-00/original-source-checks.json');obj=Objective(model,load(B/'regions.json'),load(A/'objective-identity.json'));shapes=obj.geometry(x);groups=defaultdict(lambda:{'pair_failures':0,'positive_intersections':0,'overlap_mm2':0.})
for pair in source['pairs']:
    if pair['passed']:continue
    group=groups['/'.join(sorted(k[0] for k in pair['keys']))];group['pair_failures']+=1;group['positive_intersections']+=int(pair['intersection_area_mm2']>0);group['overlap_mm2']+=pair['intersection_area_mm2']
owners=[]
for i,o in enumerate(model['owners']):
    axes=[]
    for k in [2*i,2*i+1]:
        lo,hi=model['bounds'][k];bound='lower' if abs(x[k]-lo)<1e-7 else 'upper' if abs(x[k]-hi)<1e-7 else None;gg=gradient[k]
        axes.append({'axis':'x' if k%2==0 else 'y','bound':bound,'gradient':gg,'negative_gradient_blocked':bool((bound=='lower' and gg>1e-8) or (bound=='upper' and gg< -1e-8))})
    owners.append({'owner':i,'identity':o['identity'],'mode':o['mode'],'axes':axes})
positive=[];flat=[]
for index,(i,j) in enumerate(model['pairs']):
    areas=[shapes[k][i][1].intersection(shapes[k][j][1]).area for k in [0,1]];loss=sum(areas)
    if loss<=0:continue
    available=[];gradients=[]
    for own,other in [(i,j),(j,i)]:
        gg=np.zeros(3)
        for k in [0,1]:gg+=moving_boundary_gradient(shapes[k][own][1],shapes[k][other][1],x[2*own:2*own+2])[0]
        gradients.append(gg.tolist());available.extend(gg[:2]);o=model['owners'][own]
        if o['angle_coordinate'] is not None:available.append(gg[2]/o['angle_scale_mm'])
    record={'pair_index':index,'owners':[i,j],'identities':[model['owners'][i]['identity'],model['owners'][j]['identity']],'original_overlap_mm2':areas[0],'pair_area_loss_mm2':loss,'scalar_pair_gradients':gradients,'available_coordinate_gradient_zero':bool(max(abs(z) for z in available)<1e-7)}
    if record['available_coordinate_gradient_zero']:
        probes=[]
        for own,other in [(i,j),(j,i)]:
            for axis in [0,1]:
                k=2*own+axis
                for h in [.001,.1,1.,5.]:
                    for sign in [-1,1]:
                        delta=h*sign
                        if not model['bounds'][k][0]<=x[k]+delta<=model['bounds'][k][1]:continue
                        moved=sum(translate(shapes[level][own][1],xoff=delta if axis==0 else 0,yoff=delta if axis==1 else 0).intersection(shapes[level][other][1]).area for level in [0,1])
                        probes.append({'owner':own,'axis':axis,'delta_mm':delta,'pair_area_loss_mm2':moved,'change_mm2':moved-loss})
        record['probes']=probes;record['all_feasible_probes_flat']=bool(probes) and all(abs(p['change_mm2'])<1e-7 for p in probes);flat.append(record)
    positive.append(record)
comparisons=[]
for name,parent in [('prior_weighted',W),('prior_conditional_relocation',R),('prior_augmented',A),('prior_augmented_conditional',N),('prior_adaptive_augmented',P),('prior_best_admissible',Q),('prior_current_mode',U),('prior_two_center',V)]:
    prior=load(parent/'response-audit/checks.json');comparisons.append({'prior':name,'prior_pair_failures':prior.get('source_pair_failures',prior.get('best_original_pair_failures',prior.get('best_original',{}).get('pair_failures'))),'current_pair_failures':source['pair_failures'],'prior_original_overlap_mm2':prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'current_original_overlap_mm2':checked['best_original']['score_mm2'],'overlap_change_mm2':checked['best_original']['score_mm2']-prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'comparable_bounded_experiment':False,'packing_improvement_claimed':False})
assert sum(r['pair_failures'] for r in groups.values())==source['pair_failures'] and abs(sum(r['overlap_mm2'] for r in groups.values())-checked['best_original']['score_mm2'])<1e-7
cogs=[o for o in owners if o['identity'][0]=='cog']
write(OUT/'family-failures.json',dict(groups));write(OUT/'owner-bound-controls.json',owners);write(OUT/'positive-pair-gradients.json',positive);write(OUT/'flat-pair-probes.json',flat);write(OUT/'prior-comparisons.json',comparisons)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_pair_failures':source['pair_failures'],'original_overlap_mm2':checked['best_original']['score_mm2'],'positive_area_pairs':len(positive),'flat_available_pair_gradient_count':len(flat),'flat_pairs_with_all_probes_flat':sum(r['all_feasible_probes_flat'] for r in flat),'bounded_translation_probes':sum(len(r['probes']) for r in flat),'auxiliary_bracket_depth_mm2':response['source_readbacks']['original']['auxiliary_bracket_depth_mm2'],'bracket_bracket_source_failures':groups.get('bracket/bracket',{}).get('pair_failures',0),'cog_lower_y_bounds_active':sum(o['axes'][1]['bound']=='lower' for o in cogs),'cog_lower_y_negative_gradient_blocked':sum(o['axes'][1]['bound']=='lower' and o['axes'][1]['negative_gradient_blocked'] for o in cogs),'optimizer_calls':0,'candidate_changed':False,'any_allocation_excluded':False,'H5_complete':False})
print(load(OUT/'checks.json'))




# Executed only after complete independent response/partial-pool replay passes.
from collections import Counter
from h5_indexed_two_center_neighbors_20261107 import neighbors
E=BASE/'search/epoch-01';RUNTIME_AUDIT=BASE/'response-audit/epoch-01-partial-reference'
assert load(BASE/'search/result.json')['status']=='SELECTION_DEADLINE' and load(RUNTIME_AUDIT/'checks.json')['passed'] and not (E/'optimizer-opened.json').exists()
opened=load(E/'opened.json');partial=load(E/'partial-selection.json');weights=load(E/'weight-transition.json')['after'];lib=load(A/'library.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json')
before=time.perf_counter();full=neighbors(lib,opened['incoming_modes'],opened['incoming_values'],weights,identity,regions,set(opened['visited_keys']),deadline=before+45,cached_trials=None);elapsed=time.perf_counter()-before
records,aliases,trials,selections=full
for name,rows in zip(['records','aliases','trials','selections'],full):assert partial[name]==rows[:len(partial[name])]
assert len(records)==23419 and len(trials)==9102 and len(selections)==111
oracle=load(RUNTIME_AUDIT/'proposal-score-controls.json');assert len(oracle)==len(records)
max_error=0.
for row,control in zip(records,oracle):
    assert row['sequence']==control['sequence']
    for field in ['augmented_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2','unweighted_objective_mm2']:
        error=abs(row[field]-control[field]);assert error<1e-6;max_error=max(max_error,error)
scores={r['sequence']:r['augmented_objective_mm2'] for r in oracle};centers={(r['owner'],r['mode']):[tuple(p['center']) for p in r['selected']] for r in selections};primary=[];old_groups={};groups={};ranks={}
def ordering(r):return r['augmented_objective_mm2'],r['modes'],len(r['changes']),r['changes'],r['centers'],r['sequence']
for row in records:
    rank=[centers[i,mi].index(tuple(c)) for (i,mi),c in zip(row['changes'],row['centers'])];ranks[row['sequence']]=rank;groups.setdefault(row['key'],[]).append(row)
    if all(v==0 for v in rank):primary.append(row);old_groups.setdefault(row['key'],[]).append(row)
assert len(primary)==5911 and len(old_groups)==len(groups)==2854 and Counter(map(len,old_groups.values()))=={562:1,33:78,1:2775}
comparisons=[]
for key,rows in sorted(groups.items()):
    old=min(old_groups[key],key=ordering);new=min(rows,key=ordering);delta=scores[old['sequence']]-scores[new['sequence']]
    assert abs(scores[old['sequence']]-min(scores[r['sequence']] for r in old_groups[key]))<1e-6 and abs(scores[new['sequence']]-min(scores[r['sequence']] for r in rows))<1e-6 and delta>=-1e-6
    comparisons.append({'key':key,'one_center_sequence':old['sequence'],'two_center_sequence':new['sequence'],'excluded':new['excluded'],'independent_improvement_mm2':delta,'strictly_improved':delta>1e-6})
assert [min(groups[k],key=ordering) for k in sorted(groups)]==load(RUNTIME_AUDIT/'key-minima.json')
old_best=min((r for r in primary if not r['excluded']),key=ordering);new_best=min((r for r in records if not r['excluded']),key=ordering)
delta=scores[old_best['sequence']]-scores[new_best['sequence']];assert delta>=-1e-6
write(OUT/'validation-full-neighbors.json',records);write(OUT/'validation-first-center-neighbors.json',primary);write(OUT/'validation-key-improvements.json',comparisons)
summary={'passed':True,'runtime_geometry_cache_used':False,'partial_trials':len(partial['trials']),'partial_proposals':len(partial['records']),'all_complete_source_centers_captured':len(partial['trials'])==9102,'partial_deadline_overrun_seconds':partial['overrun_seconds'],'partial_candidate_selected':False,'full_selector_validation_seconds':elapsed,'complete_validation_proposals':len(records),'primary_center_subset_proposals':len(primary),'same_context_key_minima':len(groups),'eligible_key_minima_strictly_improved':sum(r['strictly_improved'] and not r['excluded'] for r in comparisons),'validation_only_primary_best_sequence':old_best['sequence'],'validation_only_full_best_sequence':new_best['sequence'],'validation_best_placement_changed':(old_best['changes'],old_best['centers'])!=(new_best['changes'],new_best['centers']),'independent_best_eligible_improvement_mm2':delta,'validation_full_best_center_ranks':ranks[new_best['sequence']],'max_full_score_error_mm2':max_error,'same_runtime_state_weights_exclusions':True,'optimizer_calls':0,'closed_search_resumed':False,'new_source_state_prepared':False,'validation_outputs_used_as_seed':False,'H5_complete':False}
paths=[Path(__file__),ROOT/'output/h5_indexed_two_center_neighbors_20261107.py']+[E/n for n in ['opened.json','partial-selection.json','weight-transition.json']]+[RUNTIME_AUDIT/n for n in ['checks.json','proposal-score-controls.json','key-minima.json']]+[BASE/n for n in ['response-audit/checks.json','search/result.json']]+[A/'library.json',A/'objective-identity.json',B/'regions.json']
write(OUT/'partial-coverage-plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Validation-only complete selector recomputation of the closed partial runtime context, exact captured-prefix comparison, complete independent score reconciliation and comparison to the exact first-center subset under identical context/keys. No optimizer, selected runtime candidate, successor source seed or resume.'})
write(OUT/'partial-coverage-and-time.json',summary);print(summary)
