"""Freeze a new finite contract on the verified unoptimized18-exclusion choice."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_two_center_search_20261107.py').read_text(encoding='utf-8')
changes={
    "BASE=ROOT/'output/h5-two-center-preflight-20261107'":"BASE=ROOT/'output/h5-indexed-source-preflight-20261107';K=ROOT/'benchmarks/results/h5-selector-equivalence-20261107'",
    'from h5_two_center_neighbors_20261107 import':'from h5_indexed_two_center_neighbors_20261107 import',
    "'audit_h5_two_center_response_20261107.py'":"'audit_h5_indexed_source_response_20261107.py'",
    "'run_h5_two_center_response_stage_20261107.py'":"'run_h5_indexed_source_response_stage_20261107.py'",
    "'h5_two_center_neighbors_20261107.py'":"'h5_indexed_two_center_neighbors_20261107.py','h5_indexed_source_cache_20261107.py'",
    "'audit/selection-replay/checks.json','audit/inherited-source-domains.json','audit/cache-controls.json','coverage-audit/checks.json','audit/policy-stop-controls.json'":"'audit/inherited-source-domains.json','audit/cache-rejection-controls.json','audit/policy-controls.json','source-cache-bindings.json'",
    "]+[A/n for n in ['library.json'":"]+[K/n for n in ['plan.json','equivalence-audit.json','cache-controls.json','deadline-controls.json','timings.json','archive-checks.json']]+[A/n for n in ['library.json'",
}
for a,b in changes.items():assert a in s,a;s=s.replace(a,b)
method='One fresh finite adaptive pipeline from the independently verified original A/W source initializer under all18closed identities. All36.02814369951375seconds of inherited and new original-source preparation are charged. The immutable original-source score pool was hash/context checked and only closure flags changed; no runtime or optimized state seeded this initializer. Use the separately verified indexed selector: same9x9plusclamped centers,111physical owner/mode options, two distinct centers,9102nominal trials,23419raw proposals and2854complete key minima. Runtime geometry always recalculates fully with cached_trials=None; only complete problem digests may be reused locally inside one unchanged weight/identity invocation. Keep528weighted original/clearance terms,15coefficient1bracket terms, continuous15cog angles and the existing bounded area-only weight update. Allow at most two4second calls, each shortened at54seconds for source checks; selection/grouping stop at52seconds. The observed9.681174800149165second runtime selector mean (two validation samples, before output/group/model/source cost) does not guarantee a second call, and the count/time ceilings never extend. Every complete problem key closes after its sole call; coordinates and faster code cannot reopen any prior key. Rebuild every dynamic model and retain every evaluation and all augmented/original/unweighted strict winners. Source-check all three full66outputs after each call. Preserve all partial evidence with no selected candidate; stop on finite count, time, no improvement, valid source or inconsistency.60/90second preparation-inclusive algorithm/shared limits,2GiBverifiedJobv4, no restart/reseed/grid refinement/native call.'
s,n=re.subn(r"'method':'One finite adaptive augmented pipeline[^']*'","'method':"+repr(method),s);assert n==1
compile(s,'run_h5_indexed_source_search_20261107.py','exec')
with (ROOT/'output/run_h5_indexed_source_search_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
a=(ROOT/'output/audit_h5_two_center_response_20261107.py').read_text(encoding='utf-8')
for old,new in {
    "BASE=ROOT/'output/h5-two-center-preflight-20261107'":"BASE=ROOT/'output/h5-indexed-source-preflight-20261107'",
    'h5_two_center_neighbors_20261107':'h5_indexed_two_center_neighbors_20261107',
    'len(old_closed)==16':'len(old_closed)==18',
    "result['historical_closed_keys']==16":"result['historical_closed_keys']==18",
    "'prior_closed_keys':16":"'prior_closed_keys':18",
    "'plan-v2.json','inherited-source-domains.json'":"'plan-v2.json','inherited-source-domains.json','source-cache-bindings.json'",
}.items():assert old in a,old;a=a.replace(old,new)
compile(a,'audit_h5_indexed_source_response_20261107.py','exec')
with (ROOT/'output/audit_h5_indexed_source_response_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(a)
t=(ROOT/'output/run_h5_two_center_response_stage_20261107.py').read_text(encoding='utf-8').replace('audit_h5_two_center_response_20261107.py','audit_h5_indexed_source_response_20261107.py').replace("f'h5-two-center-{stage}-process-20261107'","f'h5-indexed-source-{stage}-process-20261107'")
compile(t,'run_h5_indexed_source_response_stage_20261107.py','exec')
with (ROOT/'output/run_h5_indexed_source_response_stage_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(t)
print('New finite search, complete response audit and audit stage compiled; no optimizer executed.')
