"""Archive original-source rebinding, closed indexed search and partial replay."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-indexed-source-construction-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-indexed-source-preflight-20261107';F=BASE/'response-audit';D=BASE/'outcome-diagnostic'",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-selector-equivalence-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==1 and front['best_original']['pair_failures']==55 and front['partial_selections_verified']==1 and not front['source_valid66']",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/f'h5-indexed-source-{stage}-process-20261107' for stage in ['preparation','audit','response-audit','diagnosis']]+[ROOT/'output/h5-selector-equivalence-main-sync-20261107']",
    "['*h5*mixed*mode*20261107.py']":"['*h5*indexed*source*20261107.py','h5_indexed_partial_coverage_20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_indexed_source_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json','partial-coverage-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(BASE/'audit/checks.json','source-preflight-audit.json'),(BASE/'audit/selected-model-controls.json','source-model-controls.json'),(BASE/'audit/cache-rejection-controls.json','source-cache-controls.json'),(BASE/'audit/deadline-controls.json','source-deadline-controls.json'),(BASE/'source-cache-bindings.json','source-cache-bindings.json'),(BASE/'audit/inherited-source-domains.json','inherited-source-domains.json'),(F/'checks.json','response-audit.json'),(F/'epoch-reconciliation.json','epoch-reconciliation.json'),(F/'epoch-00/original-source-checks.json','best-original-source-checks.json'),(F/'epoch-01-partial-reference/checks.json','partial-selection-audit.json'),(BASE/'search/plan.json','search-plan.json'),(BASE/'search/result.json','closed-search-result.json'),(BASE/'search/process.json','closed-search-process.json'),(D/'checks.json','outcome-diagnostic.json'),(D/'family-failures.json','family-failures.json'),(D/'prior-comparisons.json','prior-comparisons.json'),(D/'partial-coverage-and-time.json','partial-coverage-and-time.json'),(BASE/'search/main-ci-at-review.json','main-ci-at-review.json'),(ROOT/'output/h5-selector-equivalence-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for stage in ['preparation','audit','response-audit','diagnosis']:copies.append((ROOT/'output'/f'h5-indexed-source-{stage}-process-20261107'/'process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
closed=load(BASE/'closed-problems.json');closed.append(load(BASE/'search/epoch-00/closed-problem.json'));assert len(closed)==len({r['key'] for r in closed})==19;write(OUT/'closed-problems.json',closed)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
prep=load(BASE/'audit/checks.json');model=load(BASE/'audit/selected-model-controls.json');diag=load(D/'checks.json');coverage=load(D/'partial-coverage-and-time.json');partial=load(BASE/'search/epoch-01/partial-selection.json');replay=load(F/'epoch-01-partial-reference/checks.json');result=load(BASE/'search/result.json');ci=load(BASE/'search/main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
assert all(r['passed'] for r in [prep,model,diag,coverage,replay]) and result['status']=='SELECTION_DEADLINE'
write(OUT/'next-step.json',{'status':'complete_primary_tier_feasibility_preflight_required','finding':'The indexed full two-center pipeline spends its remaining selection time producing all9102centers but only15454of23419raw proposals. It correctly selects nothing from the incomplete pool and closes after one invalid55-pair-failure candidate. Complete validation-only replay compares the exact5911first-center subset against the full pool under the same state/weights/exclusions; its benefit is recorded without a packing claim.',
    'proposal':'Assess a separately versioned tiered selector: first finish and independently verify the complete5911first-center neighborhood and all2854key minima, then optionally evaluate the complete second-center extension when a separately frozen deadline allows. A partial extension must be retained and discarded for selection; only a declared, fully completed tier may supply a choice. This is a prospective new finite neighborhood policy, not a relaxation or continuation of the current closed full-pool contract. No tiered implementation, source state or search is prepared.',
    'requirements':['Retain original objectives, weighted528area terms,15coefficient1auxiliary terms, all33movers/15continuousangles,9x9plusclamped source centers, physical aliasing, full raw evidence, strict1e-6improvement and complete objective/physical-mode/weight closure. All19closed keys and prior finite pipelines remain closed.','Use only original unoptimized A/W source data for any future initializer. Retain the full36.02814369951375s source-preparation charge and add new work. Current optimized and partial/full validation records remain validation-only. Exact hash/context checks govern any unchanged original-source score reuse; changed runtime geometry must always recalculate.','Before any call, prove complete tier membership, full independent scores/key minima, stable tie ordering, no stale-cache crossover, deadline/partial evidence behavior, selection only from a completed tier, and inability to continue any old key. Measure complete runtime/output/model/source cost and freeze a new finite60/90scontract without extending closed counts or deadlines.','First assess whether the primary tier supplies useful budget under the recorded validation contexts. If it cannot, report that result and do not force a search. Lower surrogate energy or faster selection is not a material-validity result.','Require full66source validity, native/material evidence, production parity and the original H5matrix before milestone credit. Four earlier arrangements and all440allocations remain unresolved.'],
    'closed_problem_keys':19,'source_only_preparation_seconds_before_new_work':front['complete_preparation_seconds'],'tiered_selector_prepared':False,'new_source_state_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
placement='changes' if coverage['validation_best_placement_changed'] else 'does not change'
report=f'''# Indexed source construction — 2026-11-07

The fresh bounded pipeline closes after **one optimizer call** because runtime
selection reaches its declared deadline. Its candidate has **37,449.298292 mm²
original overlap and 55 failing source pairs**. Fixed-part and stock checks pass,
but no full66 valid layout is established. H2/H5 remain open at **60% completed
milestone weight**. No second candidate, native call or allocation exclusion follows.

## Original-source reconstruction and complete preparation

[Source preflight]({NAME}/source-preflight-audit.json) restores the previously audited
23,419 original-source proposals only after exact payload hashes and the complete
geometry/state/weights/identity/regions context match. All geometric and score
fields stay identical; only closure flags change for all eighteen existing keys.
Six matching keys now exclude 2,451 proposals, with 130 flags changed from the
preceding source pool. All 2,854 minima are independently reconstructed against
the original full-score readbacks, retaining six numerical ties within 1e-6 mm².

The [fresh model]({NAME}/source-model-controls.json) changes owners **{model['changes']}**
at source centers **{model['source_centers']}**. All 81 coordinates, 33 movers,
15 continuous angles, 528 weighted pairs and 15 auxiliary terms read back.
Its augmented score is {model['augmented_objective_mm2']:.6f} mm², original overlap
{model['original_overlap_mm2']:.6f} mm² and independent scalar-gradient error
{model['maximum_scalar_gradient_error_mm']:.3e} mm across 148 directed terms.
No optimized or validation state seeds this model.

[Ten cache rejection controls]({NAME}/source-cache-controls.json),
[ten closure/grouping deadline cases]({NAME}/source-deadline-controls.json) and
three no-candidate policy cases pass. [Inherited source domains]({NAME}/inherited-source-domains.json)
remain bound, including 163,836 fixed-pair checks, 36,408 stock edges, 18,841
cutouts and 2,394,464 hole vertices. This reuses verified original-source evidence;
changed runtime geometry still recalculates fully.

The complete [new preparation process]({NAME}/preparation-process.json) takes
**{prep['new_source_preparation_seconds']:.6f} s**. Its entire cost adds to the retained
33.769462 s, giving **{prep['complete_preparation_seconds']:.6f} s**. The separate
[source audit]({NAME}/audit-process.json) also closes normally. No preparation
cost is removed because the selector implementation is faster.

## Closed finite search and partial-selection replay

[The frozen contract]({NAME}/search-plan.json) allows at most two 4 s calls,
shortened at 54 s for source checks, with selection/grouping stopping at 52 s.
The preparation-inclusive algorithm/shared limits stay 60/90 s with a verified
2 GiB Windows Job. The second call is a ceiling, not a promise.

[Response replay]({NAME}/response-audit.json) verifies **{front['total_evaluation_records_verified']}
evaluation records**, **{front['saved_points_verified']} saved points**, all **528 updated
weights**, and three coincident full66 winner outputs. Every output retains all
66 originals, 1,380 same-sheet pairs, 264 stock edges, 90 cutouts and 10,026 hole
vertices. [The 55 failures]({NAME}/best-original-source-checks.json) remain explicit.
Auxiliary bracket depth is {diag['auxiliary_bracket_depth_mm2']:.9f} mm².

Runtime scoring completes all **9,102 centers** and **15,454 of 23,419 proposals**
before its deadline. The observed cooperative overrun is
{partial['overrun_seconds']:.9f} s; partial serialization is also included in the
overall totals. No candidate is selected from this incomplete pool, and the second
optimizer never opens. [Independent partial replay]({NAME}/partial-selection-audit.json)
reconstructs the full reference solely for validation, verifies all **32,521 full
scores** and 2,854 key minima, and proves the captured data is its exact prefix.
This does not resume the search or make the validation winner available as a seed.

Algorithm/shared totals are **{front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s**.
The one optimizer slice overrun is {front['slice_overruns_seconds'][0]:.6f} s; both
overall limits hold. [All five search processes close]({NAME}/closed-search-process.json),
with peak committed memory {load(BASE/'search/process.json')['job']['peak_job_committed_memory']:,} bytes.
The [complete response audit]({NAME}/response-audit-process.json) closes in
{load(OUT/'response-audit-process.json')['complete_seconds']:.6f} s. The new problem
identity joins the [nineteen closed keys]({NAME}/closed-problems.json).

## Validation-only coverage and next hypothesis

[Read-only complete-pool diagnosis]({NAME}/partial-coverage-and-time.json) reproduces
the captured prefix and all independent full scores. Its full selector time is
{coverage['full_selector_validation_seconds']:.6f} s before output/group/model/source
work. The exact first-center subset has 5,911 proposals and all 2,854 keys.
Under identical runtime state, weights and exclusions, second-center combinations
improve {coverage['eligible_key_minima_strictly_improved']} eligible key minima. The best
eligible placement **{placement}**, with independently verified score decrease
**{coverage['independent_best_eligible_improvement_mm2']:.6f} mm²**. This is not a packing result.

[Residual geometry]({NAME}/outcome-diagnostic.json) records {diag['positive_area_pairs']}
positive area terms, {diag['flat_available_pair_gradient_count']} flat available gradients,
{diag['bracket_bracket_source_failures']} bracket/bracket failures and
{diag['cog_lower_y_negative_gradient_blocked']} cogs blocked at their lower-y bound.
[Family failures]({NAME}/family-failures.json) and [historical comparisons]({NAME}/prior-comparisons.json)
are preserved without a causal improvement claim.

[Next]({NAME}/next-step.json), assess a complete first-center tier followed by an
optional complete second-center extension. An incomplete extension must never
supply a candidate. Any such policy needs separate complete membership/score/key,
deadline and timing preflight; no implementation, initializer or search is prepared.
The current full-pool contract and every earlier call remain closed. Four earlier
arrangements and all 440 allocation candidates remain unresolved.

The preceding two checkpoints reached main **38e7b1d7** through an ordinary atomic
push after all six previous CI jobs passed, preserving 52 protected files.
[The receipt]({NAME}/prior-main-push-receipt.json) and [fresh main CI]({NAME}/main-ci-at-review.json)
are retained ({success} passed jobs, {live} live jobs at review). Product code,
README claims and releases remain unchanged. This checkpoint awaits the next
ordinary push gate.

[Archive verification]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the evidence graph.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 indexed source construction:** [complete source/response/partial-pool audits]({{link}}) verify exact reuse of 23,419 original-source records under eighteen exclusions, all 2,854 key minima and a fresh original-source model. Full preparation is 36.028144 s. The finite search closes after one four-second call with 37,449.298292 mm² original overlap and 55 failed pairs. Runtime selection reaches its deadline after all 9,102 centers and 15,454 proposals, chooses nothing and opens no second call. All {front["total_evaluation_records_verified"]} evaluation records, {front["saved_points_verified"]} saved points, 528 updated weights and three full66 outputs replay; complete validation-only partial-pool reconstruction checks 32,521 full scores and the exact saved prefix. Algorithm/shared totals are {front["algorithm_seconds"]:.6f}/{front["shared_seconds"]:.6f} s with all processes closed. Nineteen keys stay closed. Same-context first-center comparison records that the best eligible placement {placement} with second-center combinations; no packing gain is claimed. Next assess separately verified complete primary/optional extension tiers; no new tiered selector or source state is prepared. Four arrangements and 440 allocations remain; H2/H5 stay at 60%. The preceding checkpoints reached main 38e7b1d7 after all six checks passed, preserving 52 files. Fresh CI has {success} passed and {live} live jobs at review. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [indexed source construction](../benchmarks/results/{NAME}.md).
Original-source records are hash/context verified and regrouped under eighteen
exclusions; the fresh model and full 36.028144 s preparation charge pass readback.
One bounded call closes with 37,449.298292 mm² original overlap and 55 failed pairs.
Runtime selection stops after all 9,102 centers and 15,454 proposals, with no
selected candidate or second call. Independent replay verifies {front['total_evaluation_records_verified']} evaluation
records, {front['saved_points_verified']} saved points, 528 updated weights, three full66 outputs and the full
32,521-score validation reference for the exact partial prefix. Algorithm/shared
totals are {front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s; all processes close. Nineteen keys remain closed.
The same-context best eligible placement {placement} with second centers.
Next assess complete primary/optional extension tiers with separate score/key,
deadline and timing preflight. No tiered selector or new source state is prepared.
Four arrangements and 440 allocations remain; H2/H5 stay at 60%. The preceding
checkpoints reached main 38e7b1d7 after all six checks passed, preserving 52 files.
Fresh CI has {success} passed and {live} live jobs at review; this checkpoint awaits the next
ordinary push gate. Product code, README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
