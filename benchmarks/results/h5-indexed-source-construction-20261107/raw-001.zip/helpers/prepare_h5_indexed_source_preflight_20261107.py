"""Fresh original-source choice under all18closed keys, with exact source reuse."""
from pathlib import Path
from hashlib import sha256
import json,time,shutil,os
from h5_indexed_source_cache_20261107 import NAMES,restore,rebind,ClosureDeadline
from h5_indexed_two_center_neighbors_20261107 import apply_neighbor
from h5_two_center_key_choice_20261107 import choose,KeySelectionDeadline
from h5_bracket_augmented_readback_20261107 import verify
from h5_bracket_augmented_objective_20261107 import Objective
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-indexed-source-preflight-20261107';V=ROOT/'output/h5-two-center-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';P=ROOT/'benchmarks/results/h5-selector-equivalence-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
assert load(P/'archive-checks.json')['passed'] and load(P/'equivalence-audit.json')['passed'] and load(V/'audit/checks.json')['passed']
paths=[Path(__file__),P/'next-step.json',P/'archive-checks.json',P/'equivalence-audit.json',P/'closed-problems.json']+[ROOT/'output'/n for n in ['h5_indexed_source_cache_20261107.py','h5_indexed_two_center_neighbors_20261107.py','h5_two_center_key_choice_20261107.py','h5_two_center_key_readback_20261107.py','audit_h5_indexed_source_preflight_20261107.py','h5_bracket_augmented_objective_20261107.py','h5_bracket_augmented_readback_20261107.py']]+[V/n for n in ['audit/plan.json','audit/checks.json','audit/inherited-source-domains.json','audit/selection-replay/checks.json','audit/selection-replay/proposal-score-controls.json','cache-context.json','runtime-bindings.json','closed-problems.json','search/epoch-00/closed-problem.json','search/epoch-01/closed-problem.json']+list(NAMES)]+[A/n for n in ['library.json','initial-state.json','objective-identity.json']]+[B/'regions.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Restore the complete immutable independently audited original A/W source pool only after exact payload hashes from its audit plan and full geometry/state/weights/identity/regions context agree. Preserve all geometric fields and raw scores; change only exclusion flags for all18closed objective keys. Regroup complete2854key minima and require strict1e-6improvement. Reconstruct the new selected model from original A/W coordinates and the recorded source replacement centers, never from runtime or optimized states. Retain the full original source preparation charge and add the entire new bounded preparation process. This is original-source score reuse, not permission to cache changed runtime geometry.','complete_prior_preparation_seconds':load(V/'audit/checks.json')['complete_preparation_seconds'],'source_pool_reuse_charged_in_full':True,'deadline_seconds_from_preparation_start':20,'preparation_cap_seconds':22,'memory_bytes':2**31,'closed_keys':18,'nominal_center_trials':9102,'raw_proposals':23419,'physical_vectors':2854,'source_cache_mutation_controls':['coordinates','modes','weights','library','identity','regions','neighbors.json','owner-aliases.json','center-trials.json','center-selections.json'],'closure_deadline_checkpoints':[1,2,3,95,185],'key_deadline_checkpoints':[1,2,3,4],'strict_improvement_mm2':1e-6,'optimizer_calls':0,'retry_permitted':False})
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');closed=load(P/'closed-problems.json');expected=load(V/'closed-problems.json')+[load(V/f'search/epoch-{e:02d}/closed-problem.json') for e in [0,1]]
assert closed==expected and len(closed)==len({r['key'] for r in closed})==18;keys={r['key'] for r in closed};write(OUT/'closed-problems.json',closed)
audit_plan=load(V/'audit/plan.json');hashes={name:audit_plan['inputs'][(V/name).relative_to(ROOT).as_posix()] for name in NAMES};context=load(V/'cache-context.json')['context'];payloads={name:(V/name).read_bytes() for name in NAMES}
source_records,aliases,trials,selections=restore(payloads,hashes,context,lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions)
write(OUT/'source-cache-bindings.json',{'source_context':context,'payload_sha256':hashes,'original_source_only':True,'prior_complete_preparation_seconds':load(V/'audit/checks.json')['complete_preparation_seconds'],'runtime_geometry_cache_permitted':False,'inputs':{(V/n).relative_to(ROOT).as_posix():digest(V/n) for n in ['audit/plan.json','audit/selection-replay/checks.json','cache-context.json']+list(NAMES)}})
try:records=rebind(source_records,keys,deadline=start+20)
except ClosureDeadline as exc:
    write(OUT/'partial-closure.json',exc.evidence);write(OUT/'checks.json',{'prepared':False,'status':'CLOSURE_DEADLINE','seconds':time.perf_counter()-start,'optimizer_calls':0});raise SystemExit(0)
write(OUT/'neighbors.json',records)
for name in NAMES[1:]:shutil.copyfile(V/name,OUT/name)
try:selection,groups,minima=choose(records,deadline=start+20)
except KeySelectionDeadline as exc:
    write(OUT/'partial-key-selection.json',exc.evidence);write(OUT/'checks.json',{'prepared':False,'status':'KEY_SELECTION_DEADLINE','seconds':time.perf_counter()-start,'optimizer_calls':0});raise SystemExit(0)
write(OUT/'selection.json',selection);write(OUT/'group-members.json',groups);write(OUT/'key-minima.json',minima)
chosen=selection['accepted_choice']
if chosen is not None:
    modes,model,values=apply_neighbor(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,chosen)
    assert verify(model,lib,modes,values,initial['pair_weights'],identity) and chosen['key'] not in keys and abs(Objective(model,regions,identity).score(values)-chosen['augmented_objective_mm2'])<1e-6
    write(OUT/'selected-model.json',model);write(OUT/'selected-state.json',{'modes':modes,'values':values.tolist(),'pair_weights':initial['pair_weights'],'key':chosen['key'],'objective_identity':identity})
runtime=load(V/'runtime-bindings.json')
for name,h in runtime.items():assert digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'source_context':context,'source_records_reused':len(records),'unchanged_center_trials':len(trials),'physical_owner_mode_choices':len(selections),'key_minima':len(minima),'closed_keys':len(keys),'excluded_keys':selection['excluded_keys'],'excluded_raw_proposals':selection['excluded_raw_proposals'],'strictly_improves_current':chosen is not None,'selected_changes':None if chosen is None else chosen['changes'],'selected_key':None if chosen is None else chosen['key'],'selected_augmented_mm2':None if chosen is None else chosen['augmented_objective_mm2'],'optimizer_calls':0,'optimized_ancestor_consumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
