"""Pin the next checkpoint push to main38e7b1d7 and its complete CI gate."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/push_h5_selector_equivalence_checkpoints_20261107.py').read_text(encoding='utf-8')
changes={
    'h5-selector-equivalence-main-sync-20261107':'h5-indexed-source-main-sync-20261107',
    '8dc996845c2dfa02bd3eea23aa8e7cd6241211ca':'38e7b1d7e7416d9c14c87bc1bf0feb931d2d478d',
    '42383126925':'42386344218',
    "prefixes=('benchmarks/results/h5-two-center-construction-20261107','benchmarks/results/h5-selector-equivalence-20261107')":"prefixes=('benchmarks/results/h5-indexed-source-construction-20261107',)",
    "['h5-two-center-construction-20261107','h5-selector-equivalence-20261107']":"['h5-indexed-source-construction-20261107']",
}
for a,b in changes.items():assert a in s,a;s=s.replace(a,b)
compile(s,'push_h5_indexed_source_checkpoints_20261107.py','exec')
with (ROOT/'output/push_h5_indexed_source_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/verify_h5_selector_equivalence_staged_20261107.py').read_text(encoding='utf-8').replace("NAME='h5-selector-equivalence-20261107'","NAME='h5-indexed-source-construction-20261107'").replace('h5-selector-equivalence-staged-checks-20261107.json','h5-indexed-source-staged-checks-20261107.json')
compile(s,'verify_h5_indexed_source_staged_20261107.py','exec')
with (ROOT/'output/verify_h5_indexed_source_staged_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('New pinned push and staged-byte verifier prepared; neither executed.')
