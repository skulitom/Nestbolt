# Executed only after complete independent response/partial-pool replay passes.
from collections import Counter
from h5_indexed_two_center_neighbors_20261107 import neighbors
E=BASE/'search/epoch-01';RUNTIME_AUDIT=BASE/'response-audit/epoch-01-partial-reference'
assert load(BASE/'search/result.json')['status']=='SELECTION_DEADLINE' and load(RUNTIME_AUDIT/'checks.json')['passed'] and not (E/'optimizer-opened.json').exists()
opened=load(E/'opened.json');partial=load(E/'partial-selection.json');weights=load(E/'weight-transition.json')['after'];lib=load(A/'library.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json')
before=time.perf_counter();full=neighbors(lib,opened['incoming_modes'],opened['incoming_values'],weights,identity,regions,set(opened['visited_keys']),deadline=before+45,cached_trials=None);elapsed=time.perf_counter()-before
records,aliases,trials,selections=full
for name,rows in zip(['records','aliases','trials','selections'],full):assert partial[name]==rows[:len(partial[name])]
assert len(records)==23419 and len(trials)==9102 and len(selections)==111
oracle=load(RUNTIME_AUDIT/'proposal-score-controls.json');assert len(oracle)==len(records)
max_error=0.
for row,control in zip(records,oracle):
    assert row['sequence']==control['sequence']
    for field in ['augmented_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2','unweighted_objective_mm2']:
        error=abs(row[field]-control[field]);assert error<1e-6;max_error=max(max_error,error)
scores={r['sequence']:r['augmented_objective_mm2'] for r in oracle};centers={(r['owner'],r['mode']):[tuple(p['center']) for p in r['selected']] for r in selections};primary=[];old_groups={};groups={};ranks={}
def ordering(r):return r['augmented_objective_mm2'],r['modes'],len(r['changes']),r['changes'],r['centers'],r['sequence']
for row in records:
    rank=[centers[i,mi].index(tuple(c)) for (i,mi),c in zip(row['changes'],row['centers'])];ranks[row['sequence']]=rank;groups.setdefault(row['key'],[]).append(row)
    if all(v==0 for v in rank):primary.append(row);old_groups.setdefault(row['key'],[]).append(row)
assert len(primary)==5911 and len(old_groups)==len(groups)==2854 and Counter(map(len,old_groups.values()))=={562:1,33:78,1:2775}
comparisons=[]
for key,rows in sorted(groups.items()):
    old=min(old_groups[key],key=ordering);new=min(rows,key=ordering);delta=scores[old['sequence']]-scores[new['sequence']]
    assert abs(scores[old['sequence']]-min(scores[r['sequence']] for r in old_groups[key]))<1e-6 and abs(scores[new['sequence']]-min(scores[r['sequence']] for r in rows))<1e-6 and delta>=-1e-6
    comparisons.append({'key':key,'one_center_sequence':old['sequence'],'two_center_sequence':new['sequence'],'excluded':new['excluded'],'independent_improvement_mm2':delta,'strictly_improved':delta>1e-6})
assert [min(groups[k],key=ordering) for k in sorted(groups)]==load(RUNTIME_AUDIT/'key-minima.json')
old_best=min((r for r in primary if not r['excluded']),key=ordering);new_best=min((r for r in records if not r['excluded']),key=ordering)
delta=scores[old_best['sequence']]-scores[new_best['sequence']];assert delta>=-1e-6
write(OUT/'validation-full-neighbors.json',records);write(OUT/'validation-first-center-neighbors.json',primary);write(OUT/'validation-key-improvements.json',comparisons)
summary={'passed':True,'runtime_geometry_cache_used':False,'partial_trials':len(partial['trials']),'partial_proposals':len(partial['records']),'all_complete_source_centers_captured':len(partial['trials'])==9102,'partial_deadline_overrun_seconds':partial['overrun_seconds'],'partial_candidate_selected':False,'full_selector_validation_seconds':elapsed,'complete_validation_proposals':len(records),'primary_center_subset_proposals':len(primary),'same_context_key_minima':len(groups),'eligible_key_minima_strictly_improved':sum(r['strictly_improved'] and not r['excluded'] for r in comparisons),'validation_only_primary_best_sequence':old_best['sequence'],'validation_only_full_best_sequence':new_best['sequence'],'validation_best_placement_changed':(old_best['changes'],old_best['centers'])!=(new_best['changes'],new_best['centers']),'independent_best_eligible_improvement_mm2':delta,'validation_full_best_center_ranks':ranks[new_best['sequence']],'max_full_score_error_mm2':max_error,'same_runtime_state_weights_exclusions':True,'optimizer_calls':0,'closed_search_resumed':False,'new_source_state_prepared':False,'validation_outputs_used_as_seed':False,'H5_complete':False}
paths=[Path(__file__),ROOT/'output/h5_indexed_two_center_neighbors_20261107.py']+[E/n for n in ['opened.json','partial-selection.json','weight-transition.json']]+[RUNTIME_AUDIT/n for n in ['checks.json','proposal-score-controls.json','key-minima.json']]+[BASE/n for n in ['response-audit/checks.json','search/result.json']]+[A/'library.json',A/'objective-identity.json',B/'regions.json']
write(OUT/'partial-coverage-plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Validation-only complete selector recomputation of the closed partial runtime context, exact captured-prefix comparison, complete independent score reconciliation and comparison to the exact first-center subset under identical context/keys. No optimizer, selected runtime candidate, successor source seed or resume.'})
write(OUT/'partial-coverage-and-time.json',summary);print(summary)
