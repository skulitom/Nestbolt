"""Scalar original-source areas and independent rational bracket boundaries."""
import math
from fractions import Fraction as F
from itertools import product
import numpy as np
from shapely.geometry import Polygon
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient

def source_rows(library,model,x):
    rows=list(library['fixed_source_rows'])
    for i,owner in enumerate(model['owners']):
        family,copy_index=library['identities'][i];mode=library['family_modes'][family][owner['mode']]
        angle=x[66+i-18]/library['angle_scale_mm'] if i>=18 else mode['rotation_radians']
        c,s=math.cos(angle),math.sin(angle);m=-1 if mode['mirrored'] else 1
        px,py=library['families'][family]['source_center']
        rows.append({'part_id':family,'copy_index':copy_index,'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':mode['mirrored'],'translation':[x[2*i]-(m*px*c-py*s),x[2*i+1]-(m*px*s+py*c)]}})
    return rows

def alternative_rectangles(mode):
    c,s=[(1,0),(0,1),(-1,0),(0,-1)][[0.,math.pi/2,math.pi,3*math.pi/2].index(mode['rotation_radians'])]
    rectangles=[]
    for a,b,d,e in [(0,0,100,250),(100,0,300,75)]:
        vertices=[]
        for x,y in [(a,b),(d,b),(d,e),(a,e)]:
            x=F(x-150)*(-1 if mode['mirrored'] else 1);y=F(y-125)
            vertices.append((c*x-s*y,s*x+c*y))
        rectangles.append((min(v[0] for v in vertices),min(v[1] for v in vertices),max(v[0] for v in vertices),max(v[1] for v in vertices)))
    return rectangles

def reference_regions(library):
    result={};modes=library['family_modes']['bracket']
    for i,j in product(range(10),repeat=2):
        rectangles=[(a[0]-b[2],a[1]-b[3],a[2]-b[0],a[3]-b[1]) for a in alternative_rectangles(modes[i]) for b in alternative_rectangles(modes[j])]
        xs=sorted({r[k] for r in rectangles for k in [0,2]});ys=sorted({r[k] for r in rectangles for k in [1,3]})
        occupied={(a,b) for a in range(len(xs)-1) for b in range(len(ys)-1) if any(r[0]<(xs[a]+xs[a+1])/2<r[2] and r[1]<(ys[b]+ys[b+1])/2<r[3] for r in rectangles)}
        segments=[]
        for a,b in sorted(occupied):
            if (a-1,b) not in occupied:segments.append(((xs[a],ys[b]),(xs[a],ys[b+1])))
            if (a+1,b) not in occupied:segments.append(((xs[a+1],ys[b]),(xs[a+1],ys[b+1])))
            if (a,b-1) not in occupied:segments.append(((xs[a],ys[b]),(xs[a+1],ys[b])))
            if (a,b+1) not in occupied:segments.append(((xs[a],ys[b+1]),(xs[a+1],ys[b+1])))
        result[i,j]=(rectangles,segments)
    return result

class Reference:
    def __init__(self,library):
        self.library=library;self.regions=reference_regions(library)

    def auxiliary(self,model,x,selected=None):
        total=F(0);g=np.zeros(81);records=[]
        chosen={r['pair_index']:r for r in selected} if selected is not None else {}
        for index,(i,j) in enumerate(model['pairs']):
            if i>=6 or j>=6:continue
            a,b=model['owners'][i]['mode'],model['owners'][j]['mode'];rectangles,segments=self.regions[a,b]
            t=tuple(F(float(x[2*j+k])-float(x[2*i+k])) for k in [0,1])
            if not any(r[0]<t[0]<r[2] and r[1]<t[1]<r[3] for r in rectangles):
                records.append({'pair_index':index,'value':0.,'distinct_closest_points':0});continue
            candidates=[]
            for p,q in segments:
                nearest=tuple(min(max(t[k],min(p[k],q[k])),max(p[k],q[k])) for k in [0,1])
                candidates.append((sum((t[k]-nearest[k])**2 for k in [0,1]),nearest))
            minimum=min(d for d,q in candidates);qs=sorted({q for d,q in candidates if d==minimum});q=qs[0]
            if index in chosen:
                actual=tuple(F(v) for v in chosen[index]['closest'])
                q=min(qs,key=lambda v:sum((v[k]-actual[k])**2 for k in [0,1]))
                assert max(abs(q[k]-actual[k]) for k in [0,1])<F(5e-7)
            gg=np.array([float(2*(t[k]-q[k])) for k in [0,1]])
            g[2*i:2*i+2]-=gg;g[2*j:2*j+2]+=gg;total+=minimum
            records.append({'pair_index':index,'value':float(minimum),'distinct_closest_points':len(qs)})
        return float(total),g,records

    def evaluate(self,model,x,gradient=False,selected=None):
        library=self.library;rows=source_rows(library,model,x)[33:];polys=[]
        for row in rows:
            t=row['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
            polys.append([Polygon([(m*a*c-b*s+tx,m*a*s+b*c+ty) for a,b in library['families'][row['part_id']][kind]]) for kind in ['original','clearance']])
        original=clearance=weighted=0.;g=np.zeros(81);losses=[];shared=0.;directed=0
        for index,(i,j) in enumerate(library['pairs']):
            area=[polys[i][k].intersection(polys[j][k]).area for k in [0,1]];loss=sum(area);weight=model['pair_weights'][index]
            original+=area[0];clearance+=area[1];weighted+=weight*loss;losses.append(loss)
            if gradient:
                for k in [0,1]:
                    if not area[k]:continue
                    for own,other in [(i,j),(j,i)]:
                        gg,_,common=moving_boundary_gradient(polys[own][k],polys[other][k],x[2*own:2*own+2]);shared+=common;directed+=1
                        g[2*own:2*own+2]+=weight*gg[:2]
                        if own>=18:g[66+own-18]+=weight*gg[2]/library['angle_scale_mm']
        aux,auxg,auxrecords=self.auxiliary(model,x,selected)
        return weighted+aux,g+auxg,{'original_overlap_area_mm2':original,'clearance_overlap_area_mm2':clearance,'unweighted_objective_mm2':original+clearance,'weighted_area_objective_mm2':weighted,'auxiliary_bracket_depth_mm2':aux,'pair_losses_mm2':losses,'auxiliary_terms':auxrecords,'coincident_boundary_length_mm':shared,'directed_scalar_gradient_terms':directed}
