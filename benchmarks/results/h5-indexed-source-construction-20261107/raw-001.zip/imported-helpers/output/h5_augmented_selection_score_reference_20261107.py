"""Independent full source scores with explicit reduction and depth arithmetic."""
import math
import numpy as np
from shapely.geometry import Polygon
from h5_bracket_augmented_reference_20261107 import Reference

class FullScore:
    def __init__(self,library,weights,region_data):
        self.library=library;self.weights=weights;self.data=region_data;self.reference=Reference(library)
        self.calls=0;self.max_scalar_reduction_error=0.;self.max_rational_auxiliary_error=0.

    def __call__(self,modes,point):
        lib=self.library;shapes=[]
        for i,(family,_) in enumerate(lib['identities']):
            mode=lib['family_modes'][family][modes[i]];theta=float(point[66+i-18])/lib['angle_scale_mm'] if i>=18 else mode['rotation_radians']
            c,s=math.cos(theta),math.sin(theta);m=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];tx=float(point[2*i])-(m*px*c-py*s);ty=float(point[2*i+1])-(m*px*s+py*c)
            shapes.append([Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in lib['families'][family][kind]]) for kind in ['original','clearance']])
        losses=[sum(shapes[i][k].intersection(shapes[j][k]).area for k in [0,1]) for i,j in lib['pairs']]
        weighted=float(np.dot(self.weights,losses));scalar=sum(w*a for w,a in zip(self.weights,losses));reduction_error=abs(weighted-scalar);assert reduction_error<1e-6
        self.max_scalar_reduction_error=max(self.max_scalar_reduction_error,reduction_error)
        # Reconstruct each binary64 projection using scalar operations, separate
        # from the vector kernel, and verify against alternative rational cells.
        extra=[]
        for i in range(6):
            for j in range(i+1,6):
                tx=float(point[2*j])-float(point[2*i]);ty=float(point[2*j+1])-float(point[2*i+1]);rectangles,_=self.reference.regions[modes[i],modes[j]]
                if not any(r[0]<tx<r[2] and r[1]<ty<r[3] for r in rectangles):extra.append(0.);continue
                distances=[]
                for a,b in self.data['regions'][f'{modes[i]}:{modes[j]}']['segments']:
                    ex=float(b[0]-a[0]);ey=float(b[1]-a[1]);dx=float(tx-a[0]);dy=float(ty-a[1])
                    denominator=float(ex*ex+ey*ey);numerator=float(dx*ex+dy*ey);fraction=min(1.,max(0.,float(numerator/denominator)))
                    qx=float(a[0]+fraction*ex);qy=float(a[1]+fraction*ey);rx=float(tx-qx);ry=float(ty-qy);distances.append(float(rx*rx+ry*ry))
                extra.append(min(distances))
        auxiliary=sum(extra)
        miniature={'pairs':lib['pairs'],'owners':[{'mode':mi} for mi in modes]}
        rational,_,_=self.reference.auxiliary(miniature,point);aux_error=abs(auxiliary-rational);assert aux_error<1e-6
        self.max_rational_auxiliary_error=max(self.max_rational_auxiliary_error,aux_error);self.calls+=1
        return {'augmented_objective_mm2':weighted+auxiliary,'weighted_area_objective_mm2':weighted,'auxiliary_bracket_depth_mm2':auxiliary,'unweighted_objective_mm2':float(np.sum(losses)),'independent_scalar_augmented_mm2':scalar+rational}
