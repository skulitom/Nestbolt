"""Reconstruct grid geometry directly from original job rings and fixed placements."""
import math,json
import numpy as np
import shapely
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit

def verify_domains(job,lib,modes,values,trials,out):
    def write(name,value):
        with (out/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
    out.mkdir();parts={p['id']:p for p in job['parts']};fixed=lib['fixed_source_rows'];fixed_check=audit(job,fixed,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in fixed]);assert fixed_check['valid'];write('fixed-source-checks.json',fixed_check)
    def polygon(part,angle,mirrored,tx,ty):
        c,s=math.cos(angle),math.sin(angle);sign=-1 if mirrored else 1;g=part['geometry'][0];assert len(part['geometry'])==1
        assert not mirrored or part['allow_mirror'];assert part['rotations']['kind']=='free' or any(abs(math.remainder(angle-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees'])
        def ring(points):return [(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in points]
        filled=Polygon(ring(g['outer']));full=Polygon(ring(g['outer']),[ring(h) for h in g.get('holes',[])])
        assert filled.is_valid and full.is_valid and abs(filled.area-Polygon(g['outer']).area)<1e-6 and abs(full.area-Polygon(g['outer'],g.get('holes',[])).area)<1e-6
        return filled,len(g.get('holes',[])),sum(len(h) for h in g.get('holes',[]))
    same=[r for r in fixed if r['sheet_id']=='sheet-0'];fixed_shapes=[]
    for row in same:
        t=row['transform'];fixed_shapes.append(polygon(parts[row['part_id']],t['rotation_radians'],t['mirrored'],*t['translation'])[0])
    fixed_shapes=np.asarray(fixed_shapes,dtype=object);controls=[];cache={};stock=lib['source_stocks']['sheet-0'];failures=[];unique=0;holes=vertices=0
    for row in trials:
        i,mi=row['owner'],row['mode'];family,copy_index=lib['identities'][i];part=parts[family];mode=lib['family_modes'][family][mi];assert part['geometry'][0]['outer']==lib['families'][family]['original'] and 0<=copy_index<part['quantity']
        key=(i,mi,tuple(row['center']))
        if key not in cache:
            angle=values[66+i-18]/lib['angle_scale_mm'] if family=='cog' else mode['rotation_radians'];c,s=math.cos(angle),math.sin(angle);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];cx,cy=row['center'];tx=cx-(sign*px*c-py*s);ty=cy-(sign*px*s+py*c)
            shape,h,v=polygon(part,angle,mode['mirrored'],tx,ty);bb=shape.bounds;extra=[bb[0]-stock[0],bb[1]-stock[1],stock[2]-bb[2],stock[3]-bb[3]]
            distances=shapely.distance(shape,fixed_shapes).tolist();disjoint=shapely.disjoint(shape,fixed_shapes).tolist();passed=min(extra)>lib['stock_guard_mm'] and all(ok and d>lib['required_pair_gap_mm'] for ok,d in zip(disjoint,distances))
            cache[key]={'stock_extra_mm':extra,'fixed_pair_distances_mm':distances,'fixed_disjoint':disjoint,'passed':bool(passed),'holes':h,'hole_vertices':v};unique+=1;holes+=h;vertices+=v
        control={'sequence':row['sequence'],'owner':i,'mode':mi,'center':row['center'],**cache[key]};controls.append(control)
        if not control['passed']:failures.append(row['sequence'])
        if len(controls)%1000==0:print({'source_grid_domains_checked':len(controls)},flush=True)
    write('grid-source-checks.json',controls);result={'passed':not failures,'nominal_centers':len(trials),'unique_source_geometries':unique,'same_sheet_fixed_originals':len(same),'nominal_fixed_pair_checks':len(trials)*len(same),'unique_fixed_pair_checks':unique*len(same),'nominal_stock_edges':4*len(trials),'unique_holes_checked':holes,'unique_hole_vertices_checked':vertices,'minimum_fixed_gap_mm':min(min(r['fixed_pair_distances_mm']) for r in controls),'minimum_extra_stock_mm':min(min(r['stock_extra_mm']) for r in controls),'failed_sequences':failures};write('checks.json',result);assert result['passed'];return result
