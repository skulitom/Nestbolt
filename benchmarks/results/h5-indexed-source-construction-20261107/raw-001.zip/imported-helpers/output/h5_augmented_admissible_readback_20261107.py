"""Read the merged choice against every independently reconstructed full score."""

def verify_choice(records,independent_rows,selection):
    assert len(records)==len(independent_rows)==2854
    scores={r['sequence']:r['augmented_objective_mm2'] for r in independent_rows}
    assert set(scores)==set(range(2854));errors=[]
    for sequence,row in enumerate(records):
        assert row['sequence']==sequence
        error=abs(row['augmented_objective_mm2']-scores[sequence]);assert error<1e-6;errors.append(error)
    by_count={count:[r for r in records if len(r['changes'])==count and not r['excluded']] for count in [1,2]}
    named={}
    for count,name in [(1,'best_single'),(2,'best_joint')]:
        rows=sorted(by_count[count],key=lambda r:(r['augmented_objective_mm2'],tuple(r['modes'])))
        named[name]=rows[0] if rows else None;assert selection[name]==named[name]
    all_rows=[row for row in records[1:] if len(row['changes']) in [1,2] and not row['excluded']]
    best=sorted(all_rows,key=lambda r:(r['augmented_objective_mm2'],tuple(r['modes'])))[0] if all_rows else None
    reference=sorted(all_rows,key=lambda r:(scores[r['sequence']],tuple(r['modes'])))[0] if all_rows else None
    baseline=records[0]['augmented_objective_mm2'];improves=best is not None and baseline-best['augmented_objective_mm2']>1e-6
    single,joint=named['best_single'],named['best_joint'];joint_improves=single is not None and joint is not None and min(single['augmented_objective_mm2'],baseline)-joint['augmented_objective_mm2']>1e-6
    assert selection['current_score']==baseline and selection['best_admissible']==best and selection['strictly_improves_current']==improves and selection['accepted_choice']==(best if improves else None) and selection['joint_improves_current_and_single']==joint_improves
    gap=None if best is None else scores[best['sequence']]-scores[reference['sequence']]
    if best is not None:assert gap<=1e-6
    if improves:assert scores[0]-scores[best['sequence']]>1e-6
    return {'passed':True,'full_scores_verified':len(scores),'maximum_score_error_mm2':max(errors),'producer_sequence':None if best is None else best['sequence'],'independent_sequence':None if reference is None else reference['sequence'],'independent_rank_gap_mm2':gap,'accepted_changed_owners':None if not improves else len(best['changes']),'strictly_improves_current':improves,'joint_only_rule_would_accept':joint_improves}
