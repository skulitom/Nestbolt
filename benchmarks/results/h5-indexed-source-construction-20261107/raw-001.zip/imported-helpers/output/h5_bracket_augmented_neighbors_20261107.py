"""Conditional source-grid centers and joint choices under the full objective."""
from itertools import combinations,product
import numpy as np
import shapely
from h5_bracket_augmented_objective_20261107 import compile_model,Objective,problem_key
from h5_bracket_collision_depth_20261107 import Auxiliary
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
from h5_mixed_direct_pose_20261107 import owner_shapes

def rank(row):return row['augmented_objective_mm2'],row['modes']

def apply_neighbor(library,modes,values,weights,identity,record):
    chosen=modes.copy();point=np.asarray(values).copy()
    for (i,mi),center in zip(record['changes'],record['centers']):chosen[i]=mi;point[2*i:2*i+2]=center
    assert chosen==record['modes']
    model=compile_model(library,chosen,point,weights,identity)
    return chosen,model,np.asarray(model['initial'])

def neighbors(library,modes,values,weights,identity,region_data,closed_keys):
    model=compile_model(library,modes,values,weights,identity);point=np.asarray(model['initial']);objective=Objective(model,region_data,identity)
    entries=objective.geometry(point,False);classes=family_classes(library);count=len(modes);pairs=model['pairs'];bracket_pairs=[(i,j) for i,j in pairs if i<6 and j<6]
    shapes=[[level[i][1] for level in entries] for i in range(count)];base=np.zeros((count,count));base_aux=np.zeros((count,count));regions=objective.auxiliary.regions
    def depth(i,mi,ci,j,mj,cj):
        if i>=6 or j>=6:return 0.
        if i>j:i,j,mi,mj,ci,cj=j,i,mj,mi,cj,ci
        return regions[f'{mi}:{mj}'].evaluate(np.asarray(cj)-np.asarray(ci))[0]
    for level in range(2):
        ps=np.asarray([s[level] for s in shapes],dtype=object);areas=shapely.area(shapely.intersection(ps[[i for i,j in pairs]],ps[[j for i,j in pairs]]))
        for (i,j),a in zip(pairs,areas):base[i,j]+=a;base[j,i]+=a
    for i,j in bracket_pairs:base_aux[i,j]=base_aux[j,i]=depth(i,modes[i],point[2*i:2*i+2],j,modes[j],point[2*j:2*j+2])
    baseline=np.asarray([base[i,j] for i,j in pairs]);aux_indices={p:k for k,p in enumerate(bracket_pairs)};baseline_aux=[base_aux[i,j] for i,j in bracket_pairs]
    options={};aliases=[];trials=[];selections=[]
    for i,(family,_) in enumerate(library['identities']):
        options[i]=[];seen={classes[family][modes[i]]:modes[i]}
        for mode in library['family_modes'][family]:
            mi=mode['mode'];cls=classes[family][mi]
            if cls in seen:aliases.append({'owner':i,'mode':mi,'class':cls,'representative':seen[cls],'kind':'current' if cls==classes[family][modes[i]] else 'alias'});continue
            seen[cls]=mi;bb=mode['center_bounds_mm'];clamped=[min(hi,max(lo,float(point[2*i+k]))) for k,(lo,hi) in enumerate(bb)]
            centers=[clamped]+[[bb[0][0]+xi/8*(bb[0][1]-bb[0][0]),bb[1][0]+yi/8*(bb[1][1]-bb[1][0])] for yi in range(9) for xi in range(9)]
            unique=[];indices={};origin=[]
            for center in centers:
                key=tuple(center)
                if key not in indices:indices[key]=len(unique);unique.append(center)
                origin.append(indices[key])
            angle=point[model['owners'][i]['angle_coordinate']]/library['angle_scale_mm'] if family=='cog' else 0.
            candidate_shapes=[owner_shapes(library,family,mi,c,angle) for c in unique];losses=np.zeros((len(unique),count));auxiliary=np.zeros_like(losses)
            for level in range(2):
                left=np.asarray([s[level] for s in candidate_shapes],dtype=object);right=np.asarray([s[level] for s in shapes],dtype=object);losses+=shapely.area(shapely.intersection(left[:,None],right[None,:]))
            losses[:,i]=0.
            if i<6:
                for k,center in enumerate(unique):
                    for j in range(6):
                        if i!=j:auxiliary[k,j]=depth(i,mi,center,j,modes[j],point[2*j:2*j+2])
            affected=[(k,b if a==i else a) for k,(a,b) in enumerate(pairs) if i in (a,b)];scores=[]
            for loss,extra in zip(losses,auxiliary):
                full=baseline.copy();full_aux=baseline_aux.copy()
                for pair,other in affected:
                    full[pair]=loss[other]
                    if i<6 and other<6:full_aux[aux_indices[tuple(sorted((i,other)))]]=extra[other]
                weighted=float(np.dot(weights,full));aux=float(sum(full_aux));scores.append((weighted+aux,weighted,aux))
            first={};start=len(trials)
            for local,(center,idx) in enumerate(zip(centers,origin)):
                duplicate=first.get(idx);first.setdefault(idx,len(trials));total,weighted,aux=scores[idx]
                trials.append({'sequence':len(trials),'owner':i,'mode':mi,'local_index':local,'kind':'clamped' if local==0 else 'grid','grid_index':None if local==0 else [(local-1)%9,(local-1)//9],'center':center,'unique_index':idx,'duplicate_of':duplicate,'augmented_objective_mm2':total,'weighted_area_objective_mm2':weighted,'auxiliary_bracket_depth_mm2':aux})
            selected=min(trials[start:],key=lambda r:(r['augmented_objective_mm2'],r['center'],r['local_index']));idx=selected['unique_index']
            selections.append({'owner':i,'mode':mi,'nominal_trials':len(centers),'unique_centers':len(unique),'selected':selected})
            options[i].append({'owner':i,'mode':mi,'class':cls,'center':unique[idx],'shape':candidate_shapes[idx],'losses':losses[idx],'auxiliary':auxiliary[idx]});aliases.append({'owner':i,'mode':mi,'class':cls,'representative':mi,'kind':'new_physical_choice'})
    records=[]
    def emit(selected):
        chosen=modes.copy();matrix=base.copy();aux_matrix=base_aux.copy()
        for opt in selected:
            i=opt['owner'];chosen[i]=opt['mode'];matrix[i]=opt['losses'];matrix[:,i]=opt['losses'];aux_matrix[i]=opt['auxiliary'];aux_matrix[:,i]=opt['auxiliary']
        if len(selected)==2:
            a,b=selected;i,j=a['owner'],b['owner'];loss=sum(x.intersection(y).area for x,y in zip(a['shape'],b['shape']));matrix[i,j]=matrix[j,i]=loss
            extra=depth(i,a['mode'],a['center'],j,b['mode'],b['center']);aux_matrix[i,j]=aux_matrix[j,i]=extra
        losses=np.asarray([matrix[i,j] for i,j in pairs]);aux=float(sum(aux_matrix[i,j] for i,j in bracket_pairs));weighted=float(np.dot(weights,losses));physical=list(physical_key(library,classes,chosen));key=problem_key(physical,weights,identity)
        records.append({'sequence':len(records),'changes':[[o['owner'],o['mode']] for o in selected],'centers':[o['center'] for o in selected],'modes':chosen,'physical_key':physical,'key':key,'augmented_objective_mm2':weighted+aux,'weighted_area_objective_mm2':weighted,'auxiliary_bracket_depth_mm2':aux,'unweighted_objective_mm2':float(np.sum(losses)),'excluded':key in closed_keys,'exclusion_reason':'closed_objective_problem' if key in closed_keys else None})
    emit([])
    for i in range(count):
        for option in options[i]:emit([option])
    for i,j in combinations(range(count),2):
        for a,b in product(options[i],options[j]):emit([a,b])
    assert len(records)==2854 and len(trials)==6396 and len(selections)==78 and len({r['key'] for r in records})==2854
    return records,aliases,trials,selections
