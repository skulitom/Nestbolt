"""Accept the best strictly improving admissible one- or two-owner proposal."""
import math

def choose(records):
    assert len(records)==2854 and [r['sequence'] for r in records]==list(range(2854))
    assert len({r['key'] for r in records})==2854 and records[0]['changes']==[]
    assert all(math.isfinite(r['augmented_objective_mm2']) for r in records)
    rank=lambda r:(r['augmented_objective_mm2'],r['modes'])
    singles=[r for r in records if len(r['changes'])==1 and not r['excluded']]
    joints=[r for r in records if len(r['changes'])==2 and not r['excluded']]
    single=min(singles,key=rank) if singles else None
    joint=min(joints,key=rank) if joints else None
    best=min(singles+joints,key=rank) if singles or joints else None
    baseline=records[0]['augmented_objective_mm2']
    improves=best is not None and best['augmented_objective_mm2']<baseline-1e-6
    joint_improves=single is not None and joint is not None and joint['augmented_objective_mm2']<min(single['augmented_objective_mm2'],baseline)-1e-6
    return {'best_single':single,'best_joint':joint,'current_score':baseline,'joint_improves_current_and_single':joint_improves,'best_admissible':best,'strictly_improves_current':improves,'accepted_choice':best if improves else None}
