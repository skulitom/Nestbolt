"""Runtime selection replay using independently transformed full source pairs."""
from hashlib import sha256
from itertools import combinations,product
import json,math
import numpy as np
from shapely.geometry import Polygon

def verify_selection(lib,modes,values,weights,classes,closed,records,aliases,trials,selections,out):
    def write(name,data):
        with (out/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(data,f,indent=2,allow_nan=False);f.write('\n')
    out.mkdir();maximum_reduction_error=0.;full_calls=0
    def score(chosen,point):
        nonlocal maximum_reduction_error,full_calls
        ps=[]
        for i,(family,_) in enumerate(lib['identities']):
            mode=lib['family_modes'][family][chosen[i]];angle=point[66+i-18]/lib['angle_scale_mm'] if i>=18 else mode['rotation_radians'];c,s=math.cos(angle),math.sin(angle);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];tx=point[2*i]-(sign*px*c-py*s);ty=point[2*i+1]-(sign*px*s+py*c);ps.append([Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in lib['families'][family][kind]]) for kind in ['original','clearance']])
        losses=[sum(ps[i][k].intersection(ps[j][k]).area for k in [0,1]) for i,j in combinations(range(33),2)];dot=float(np.dot(weights,losses));scalar=sum(w*a for w,a in zip(weights,losses));error=abs(dot-scalar);assert error<1e-6;maximum_reduction_error=max(maximum_reduction_error,error);full_calls+=1;return dot
    options={};expected_aliases=[]
    for i,(family,_) in enumerate(lib['identities']):
        seen={classes[family][modes[i]]:modes[i]};options[i]=[]
        for mi,cls in enumerate(classes[family]):
            if cls in seen:kind='current' if cls==classes[family][modes[i]] else 'alias';rep=seen[cls]
            else:kind='new_physical_choice';rep=mi;seen[cls]=mi;options[i].append(mi)
            expected_aliases.append({'owner':i,'mode':mi,'class':cls,'representative':rep,'kind':kind})
    assert aliases==expected_aliases and len(trials)==6396 and len(selections)==78
    expected={()}|{((i,m),) for i in range(33) for m in options[i]}|{((i,m),(j,n)) for i,j in combinations(range(33),2) for m,n in product(options[i],options[j])};assert len(records)==len(expected)==2854 and expected=={tuple(map(tuple,r['changes'])) for r in records}
    assert [(r['owner'],r['mode']) for r in selections]==[(i,m) for i in range(33) for m in options[i]]
    errors=[];center_results=[];chosen_centers={};unique_count=0;aliases_count=0;position=0
    for selection in selections:
        i,mi=selection['owner'],selection['mode'];rows=trials[position:position+82];assert len(rows)==82;position+=82;bb=lib['family_modes'][lib['identities'][i][0]][mi]['center_bounds_mm'];clamped=[min(hi,max(lo,values[2*i+k])) for k,(lo,hi) in enumerate(bb)];centers=[clamped]+[[bb[0][0]+xi/8*(bb[0][1]-bb[0][0]),bb[1][0]+yi/8*(bb[1][1]-bb[1][0])] for yi in range(9) for xi in range(9)];first={};ordinal={};independent={}
        for local,row in enumerate(rows):
            assert row['sequence']==position-82+local and row['owner']==i and row['mode']==mi and row['local_index']==local and row['center']==centers[local] and row['kind']==('clamped' if local==0 else 'grid') and row['grid_index']==(None if local==0 else [(local-1)%9,(local-1)//9]);key=tuple(row['center']);duplicate=first.get(key)
            if key not in first:ordinal[key]=len(first);first[key]=row['sequence'];unique_count+=1
            else:aliases_count+=1
            assert row['duplicate_of']==duplicate and row['unique_index']==ordinal[key] and all(lo<=x<=hi for x,(lo,hi) in zip(row['center'],bb));chosen=modes.copy();chosen[i]=mi;point=values.copy();point[2*i:2*i+2]=row['center'];actual=score(chosen,point);error=abs(actual-row['weighted_objective_mm2']);assert error<1e-6;errors.append(error);independent[row['sequence']]=actual;center_results.append({'sequence':row['sequence'],'independent_score':actual,'error':error})
            if row['sequence']%1000==0:print({'selection_audit':out.name,'center_scores':row['sequence']+1},flush=True)
        best=min(rows,key=lambda r:(r['weighted_objective_mm2'],r['center'],r['local_index']));reference=min(rows,key=lambda r:(independent[r['sequence']],r['center'],r['local_index']));assert selection['selected']==best and best['sequence']==reference['sequence'] and selection['unique_centers']==len(first) and selection['nominal_trials']==82;chosen_centers[i,mi]=best['center']
    assert position==6396;write('center-score-controls.json',center_results)
    keys=set();proposal_results=[];independent={}
    for sequence,row in enumerate(records):
        chosen=modes.copy();point=values.copy();assert row['sequence']==sequence
        for (i,mi),center in zip(row['changes'],row['centers']):assert center==chosen_centers[i,mi];chosen[i]=mi;point[2*i:2*i+2]=center
        physical=[classes[f][mi] for (f,_),mi in zip(lib['identities'],chosen)];key=sha256(json.dumps({'physical':physical,'weights':weights},separators=(',',':'),allow_nan=False).encode()).hexdigest();assert key not in keys and row['physical_key']==physical and row['modes']==chosen and row['key']==key and row['excluded']==(key in closed) and row['exclusion_reason']==('closed_weighted_problem' if key in closed else None);keys.add(key);actual=score(chosen,point);error=abs(actual-row['weighted_objective_mm2']);assert error<1e-6;errors.append(error);independent[sequence]=actual;proposal_results.append({'sequence':sequence,'independent_score':actual,'error':error})
        if sequence%1000==0:print({'selection_audit':out.name,'proposal_scores':sequence+1},flush=True)
    write('proposal-score-controls.json',proposal_results)
    best=[]
    for size in [1,2]:
        eligible=[r for r in records if not r['excluded'] and len(r['changes'])==size]
        selected=min(eligible,key=lambda r:(r['weighted_objective_mm2'],r['modes'])) if eligible else None;reference=min(eligible,key=lambda r:(independent[r['sequence']],r['modes'])) if eligible else None;assert selected==reference;best.append(selected)
    single,joint=best;baseline=records[0]['weighted_objective_mm2'];improves=single is not None and joint is not None and joint['weighted_objective_mm2']<min(single['weighted_objective_mm2'],baseline)-1e-6
    result={'best_single':single,'best_joint':joint,'current_score':baseline,'joint_improves_current_and_single':improves};write('checks.json',{'passed':True,'center_trials':6396,'unique_centers':unique_count,'center_aliases':aliases_count,'proposals':2854,'independent_full_scores':full_calls,'maximum_score_error':max(errors),'maximum_scalar_reduction_difference':maximum_reduction_error,'closed_keys':len(closed),'improves':improves});return result
