"""All one/two-owner physical choices with complete weighted pair sums."""
from hashlib import sha256
from itertools import combinations,product
import json
import numpy as np
import shapely
from h5_cross_pair_weighted_model_20261107 import compile_model,Objective
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
from h5_mixed_direct_pose_20261107 import owner_shapes

def problem_key(physical,weights):
    return sha256(json.dumps({'physical':list(physical),'weights':list(weights)},separators=(',',':'),allow_nan=False).encode()).hexdigest()

def neighbors(library,modes,values,weights,closed_keys):
    model=compile_model(library,modes,values,weights);point=np.asarray(model['initial']);entries=Objective(model).geometry(point,False);classes=family_classes(library);count=len(modes);pairs=model['pairs'];shapes=[[level[i][1] for level in entries] for i in range(count)]
    base=np.zeros((count,count))
    for kind in range(2):
        ps=np.asarray([s[kind] for s in shapes],dtype=object);areas=shapely.area(shapely.intersection(ps[[i for i,j in pairs]],ps[[j for i,j in pairs]]))
        for (i,j),a in zip(pairs,areas):base[i,j]+=a;base[j,i]+=a
    options={};aliases=[]
    for i,(family,_) in enumerate(library['identities']):
        options[i]=[];seen={classes[family][modes[i]]:modes[i]}
        for mode in library['family_modes'][family]:
            mi=mode['mode'];cls=classes[family][mi]
            if cls in seen:aliases.append({'owner':i,'mode':mi,'class':cls,'representative':seen[cls],'kind':'current' if cls==classes[family][modes[i]] else 'alias'});continue
            seen[cls]=mi;bb=np.asarray(mode['center_bounds_mm']);center=np.clip(point[2*i:2*i+2],bb[:,0],bb[:,1]);angle=point[model['owners'][i]['angle_coordinate']]/library['angle_scale_mm'] if family=='cog' else 0.;shape=owner_shapes(library,family,mi,center,angle);losses=np.zeros(count)
            for kind in range(2):losses+=shapely.area(shapely.intersection(shape[kind],np.asarray([s[kind] for s in shapes],dtype=object)))
            losses[i]=0.;options[i].append({'owner':i,'mode':mi,'class':cls,'center':center.tolist(),'shape':shape,'losses':losses});aliases.append({'owner':i,'mode':mi,'class':cls,'representative':mi,'kind':'new_physical_choice'})
    records=[]
    def emit(selected):
        chosen=modes.copy();matrix=base.copy()
        for opt in selected:
            i=opt['owner'];chosen[i]=opt['mode'];matrix[i]=opt['losses'];matrix[:,i]=opt['losses']
        if len(selected)==2:
            a,b=selected;i,j=a['owner'],b['owner'];loss=sum(x.intersection(y).area for x,y in zip(a['shape'],b['shape']));matrix[i,j]=matrix[j,i]=loss
        losses=np.asarray([matrix[i,j] for i,j in pairs]);physical=list(physical_key(library,classes,chosen));key=problem_key(physical,weights)
        records.append({'sequence':len(records),'changes':[[o['owner'],o['mode']] for o in selected],'centers':[o['center'] for o in selected],'modes':chosen,'physical_key':physical,'key':key,'weighted_objective_mm2':float(np.dot(weights,losses)),'unweighted_objective_mm2':float(np.sum(losses)),'excluded':key in closed_keys,'exclusion_reason':'closed_weighted_problem' if key in closed_keys else None})
    emit([])
    for i in range(count):
        for option in options[i]:emit([option])
    for i,j in combinations(range(count),2):
        for a,b in product(options[i],options[j]):emit([a,b])
    assert len({r['key'] for r in records})==len(records)
    return records,aliases

def rank(record):return record['weighted_objective_mm2'],record['modes']

def apply_neighbor(library,modes,values,weights,record):
    changed=modes.copy();point=np.asarray(values).copy()
    for (i,mi),center in zip(record['changes'],record['centers']):changed[i]=mi;point[2*i:2*i+2]=center
    assert changed==record['modes'];model=compile_model(library,changed,point,weights)
    return changed,model,np.asarray(model['initial'])
