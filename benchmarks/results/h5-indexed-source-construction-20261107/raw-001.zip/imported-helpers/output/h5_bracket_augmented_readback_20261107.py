"""Independent full schema, domain and objective-identity readback."""
import json
from hashlib import sha256
from h5_weighted_original_readback_20261107 import verify as original_verify

def verify(model,library,modes,values,weights,identity):
    assert set(model)=={'families','owners','pairs','fixed_source_rows','parameters','bounds','initial','objective_weights','pair_weights','weight_policy','supplementary_objective'}
    base={k:v for k,v in model.items() if k!='supplementary_objective'}
    assert original_verify(base,library,modes,values,weights)
    meta=model['supplementary_objective']
    expected_pairs=[k for k,(i,j) in enumerate(library['pairs']) if i<6 and j<6]
    assert len(expected_pairs)==15
    assert set(meta)=={'identity','identity_sha256','pair_indices'}
    assert meta['identity']==identity
    expected_hash=sha256(json.dumps(identity,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    assert meta['identity_sha256']==expected_hash and meta['pair_indices']==expected_pairs
    assert identity['version']=='weighted-original-clearance-plus-bracket-depth-v1-20261107'
    assert identity['area_terms']=='all528_weighted_original_plus_clearance_areas'
    assert identity['auxiliary_policy']['coefficient']==1.
    assert identity['auxiliary_policy']['existing_pair_weights_and_updates']=='unchanged_area_losses_only'
    return True
