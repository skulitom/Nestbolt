"""Complete source reconstruction of conditional choices and ranking margins."""
from hashlib import sha256
from itertools import combinations,product
from fractions import Fraction as F
import json,math
from h5_augmented_selection_score_reference_20261107 import FullScore
from h5_current_mode_key_readback_20261107 import reconstruct_choice

def independent_classes(lib):
    classes={}
    for family,modes in lib['family_modes'].items():
        seen=[];classes[family]=[]
        for mode in modes:
            if family=='cog':edges=('continuous-cog',)
            else:
                turns=round(mode['rotation_radians']/(math.pi/2))%4;cx,cy=map(F,lib['families'][family]['source_center']);sign=-1 if mode['mirrored'] else 1;points=[]
                for x,y in lib['families'][family]['original']:
                    x=sign*(F(x)-cx);y=F(y)-cy
                    for _ in range(turns):x,y=-y,x
                    points.append((x,y))
                edges=tuple(sorted(tuple(sorted([p,q])) for p,q in zip(points,points[1:]+points[:1])))
            key=(edges,tuple(F(v) for row in mode['center_bounds_mm'] for v in row))
            if key not in seen:seen.append(key)
            classes[family].append(seen.index(key))
    return classes

def verify_selection(lib,modes,values,weights,identity,region_data,closed,records,aliases,trials,selections,out):
    def write(name,v):
        with (out/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
    out.mkdir();classes=independent_classes(lib);assert classes=={'bracket':list(range(10)),'insert':[0,1,2,0,1,2],'cog':[0]}
    score=FullScore(lib,weights,region_data);options={};expected_aliases=[];tolerance=1e-6;score_errors=[];near_ties=[]
    def check_fields(row,actual):
        fields=['augmented_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2']
        if 'unweighted_objective_mm2' in row:fields.append('unweighted_objective_mm2')
        for field in fields:
            error=abs(row[field]-actual[field]);assert error<tolerance,(field,row['sequence'],error);score_errors.append(error)
        assert abs(row['augmented_objective_mm2']-actual['independent_scalar_augmented_mm2'])<tolerance
    for i,(family,_) in enumerate(lib['identities']):
        options[i]=[];seen={}
        order=[modes[i]]+[mi for mi in range(len(classes[family])) if mi!=modes[i]]
        for mi in order:
            cls=classes[family][mi]
            if cls in seen:kind='alias';representative=seen[cls]
            else:kind='current_physical_choice' if cls==classes[family][modes[i]] else 'new_physical_choice';representative=mi;seen[cls]=mi;options[i].append(mi)
            expected_aliases.append({'owner':i,'mode':mi,'class':cls,'representative':representative,'kind':kind})
    assert aliases==expected_aliases and len(aliases)==147
    expected={()}|{((i,mi),) for i in range(33) for mi in options[i]}|{((i,mi),(j,mj)) for i,j in combinations(range(33),2) for mi,mj in product(options[i],options[j])}
    assert len(records)==len(expected)==5911 and expected=={tuple(map(tuple,r['changes'])) for r in records}
    assert len(trials)==9102 and len(selections)==111 and [(r['owner'],r['mode']) for r in selections]==[(i,mi) for i in range(33) for mi in options[i]]
    chosen_centers={};center_results=[];unique_count=0;alias_count=0;position=0
    for selection in selections:
        i,mi=selection['owner'],selection['mode'];rows=trials[position:position+82];bb=lib['family_modes'][lib['identities'][i][0]][mi]['center_bounds_mm']
        centers=[[min(hi,max(lo,values[2*i+k])) for k,(lo,hi) in enumerate(bb)]]+[[bb[0][0]+xi/8*(bb[0][1]-bb[0][0]),bb[1][0]+yi/8*(bb[1][1]-bb[1][0])] for yi in range(9) for xi in range(9)]
        first={};ordinal={};independent={}
        for local,row in enumerate(rows):
            assert row['sequence']==position+local and row['owner']==i and row['mode']==mi and row['local_index']==local and row['center']==centers[local] and row['kind']==('clamped' if local==0 else 'grid') and row['grid_index']==(None if local==0 else [(local-1)%9,(local-1)//9])
            key=tuple(row['center']);duplicate=first.get(key)
            if key not in first:ordinal[key]=len(first);first[key]=row['sequence'];unique_count+=1
            else:alias_count+=1
            assert row['duplicate_of']==duplicate and row['unique_index']==ordinal[key] and all(lo<=v<=hi for v,(lo,hi) in zip(row['center'],bb))
            chosen=modes.copy();chosen[i]=mi;point=values.copy();point[2*i:2*i+2]=row['center'];actual=score(chosen,point);check_fields(row,actual);independent[row['sequence']]=actual['augmented_objective_mm2'];center_results.append({'sequence':row['sequence'],**actual})
            if row['sequence']%500==0:print({'center_scores_checked':row['sequence']+1},flush=True)
        best=min(rows,key=lambda r:(r['augmented_objective_mm2'],r['center'],r['local_index']));oracle=min(rows,key=lambda r:(independent[r['sequence']],r['center'],r['local_index']))
        assert selection['selected']==best and selection['nominal_trials']==82 and selection['unique_centers']==len(first)
        # Frozen before scoring: reproduce exact recorded ranking; independently
        # require the selected point to minimize within the same1e-6 score error.
        # Any differently ordered numerical tie remains explicit in evidence.
        gap=independent[best['sequence']]-independent[oracle['sequence']];assert gap<=tolerance
        if best['sequence']!=oracle['sequence']:near_ties.append({'kind':'center','owner':i,'mode':mi,'recorded_sequence':best['sequence'],'independent_sequence':oracle['sequence'],'independent_score_gap_mm2':gap})
        chosen_centers[i,mi]=best['center'];position+=82
    write('center-score-controls.json',center_results)
    keys=set();proposal_results=[];independent={};family_counts={}
    for sequence,row in enumerate(records):
        chosen=modes.copy();point=values.copy();assert row['sequence']==sequence
        assert len(row['changes'])==len(row['centers'])
        for (i,mi),center in zip(row['changes'],row['centers']):assert center==chosen_centers[i,mi];chosen[i]=mi;point[2*i:2*i+2]=center
        physical=[classes[f][mi] for (f,_),mi in zip(lib['identities'],chosen)];key=sha256(json.dumps({'physical':physical,'weights':weights,'objective_identity':identity},sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        assert row['physical_key']==physical and row['modes']==chosen and row['key']==key and row['excluded']==(key in closed) and row['exclusion_reason']==('closed_objective_problem' if key in closed else None);keys.add(key)
        actual=score(chosen,point);check_fields(row,actual);independent[sequence]=actual['augmented_objective_mm2'];proposal_results.append({'sequence':sequence,**actual})
        if len(row['changes'])==2:
            family='/'.join(lib['identities'][i][0] for i,_ in row['changes']);family_counts[family]=family_counts.get(family,0)+1
        if sequence%500==0:print({'proposal_scores_checked':sequence+1},flush=True)
    assert len(keys)==2854 and family_counts=={'bracket/bracket':1500,'bracket/insert':2160,'bracket/cog':900,'insert/insert':594,'insert/cog':540,'cog/cog':105}
    write('proposal-score-controls.json',proposal_results)
    result,groups,minima,controls,key_near=reconstruct_choice(records,proposal_results);near_ties.extend(key_near)
    write('group-members.json',groups);write('key-minima.json',minima);write('key-ranking-controls.json',controls);write('near-tie-rankings.json',near_ties)
    write('checks.json',{'passed':True,'owner_aliases_verified':len(aliases),'center_trials':9102,'unique_centers':unique_count,'center_aliases':alias_count,'physical_owner_mode_choices':111,'raw_proposals':5911,'distinct_keys':len(groups),'key_size_histogram':{'1':2775,'33':78,'562':1},'joint_family_counts':family_counts,'independent_full_scores':score.calls,'maximum_component_score_error_mm2':max(score_errors),'maximum_scalar_reduction_error_mm2':score.max_scalar_reduction_error,'maximum_rational_auxiliary_error_mm2':score.max_rational_auxiliary_error,'different_numerical_rankings_within_predeclared_tolerance':len(near_ties),'closed_keys':len(closed),'excluded_keys':result['excluded_keys'],'excluded_raw_proposals':result['excluded_raw_proposals'],'strictly_improves_current':result['strictly_improves_current']})
    return result,groups,minima
