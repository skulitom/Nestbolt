"""Conditional fixed-grid owner relocation followed by complete joint scoring."""
from itertools import combinations,product
import numpy as np
import shapely
from h5_cross_pair_weighted_model_20261107 import compile_model,Objective
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
from h5_mixed_direct_pose_20261107 import owner_shapes
from h5_weighted_joint_neighbors_20261107 import problem_key,rank,apply_neighbor

def neighbors(library,modes,values,weights,closed_keys):
    model=compile_model(library,modes,values,weights);point=np.asarray(model['initial']);entries=Objective(model).geometry(point,False);classes=family_classes(library);count=len(modes);pairs=model['pairs'];shapes=[[level[i][1] for level in entries] for i in range(count)];base=np.zeros((count,count))
    for kind in range(2):
        ps=np.asarray([s[kind] for s in shapes],dtype=object);areas=shapely.area(shapely.intersection(ps[[i for i,j in pairs]],ps[[j for i,j in pairs]]))
        for (i,j),a in zip(pairs,areas):base[i,j]+=a;base[j,i]+=a
    baseline=np.asarray([base[i,j] for i,j in pairs]);options={};aliases=[];trials=[];selections=[]
    for i,(family,_) in enumerate(library['identities']):
        options[i]=[];seen={classes[family][modes[i]]:modes[i]}
        for mode in library['family_modes'][family]:
            mi=mode['mode'];cls=classes[family][mi]
            if cls in seen:aliases.append({'owner':i,'mode':mi,'class':cls,'representative':seen[cls],'kind':'current' if cls==classes[family][modes[i]] else 'alias'});continue
            seen[cls]=mi;bb=mode['center_bounds_mm'];clamped=[min(hi,max(lo,float(point[2*i+k]))) for k,(lo,hi) in enumerate(bb)];centers=[clamped]+[[bb[0][0]+xi/8*(bb[0][1]-bb[0][0]),bb[1][0]+yi/8*(bb[1][1]-bb[1][0])] for yi in range(9) for xi in range(9)]
            unique=[];indices={};origin=[]
            for center in centers:
                key=tuple(center)
                if key not in indices:indices[key]=len(unique);unique.append(center)
                origin.append(indices[key])
            angle=point[model['owners'][i]['angle_coordinate']]/library['angle_scale_mm'] if family=='cog' else 0.;candidate_shapes=[owner_shapes(library,family,mi,center,angle) for center in unique];losses=np.zeros((len(unique),count))
            for kind in range(2):
                left=np.asarray([s[kind] for s in candidate_shapes],dtype=object);right=np.asarray([s[kind] for s in shapes],dtype=object);losses+=shapely.area(shapely.intersection(left[:,None],right[None,:]))
            losses[:,i]=0.;scores=[]
            affected=[(p,b if a==i else a) for p,(a,b) in enumerate(pairs) if i in (a,b)]
            for loss in losses:
                full=baseline.copy()
                for pair,other in affected:full[pair]=loss[other]
                scores.append(float(np.dot(weights,full)))
            first={};start=len(trials)
            for local,(center,unique_index) in enumerate(zip(centers,origin)):
                duplicate=first.get(unique_index);first.setdefault(unique_index,len(trials));trials.append({'sequence':len(trials),'owner':i,'mode':mi,'local_index':local,'kind':'clamped' if local==0 else 'grid','grid_index':None if local==0 else [(local-1)%9,(local-1)//9],'center':center,'unique_index':unique_index,'duplicate_of':duplicate,'weighted_objective_mm2':scores[unique_index]})
            selected=min(trials[start:],key=lambda r:(r['weighted_objective_mm2'],r['center'],r['local_index']));idx=selected['unique_index'];center=unique[idx]
            selections.append({'owner':i,'mode':mi,'nominal_trials':len(centers),'unique_centers':len(unique),'selected':selected});options[i].append({'owner':i,'mode':mi,'class':cls,'center':center,'shape':candidate_shapes[idx],'losses':losses[idx]});aliases.append({'owner':i,'mode':mi,'class':cls,'representative':mi,'kind':'new_physical_choice'})
    records=[]
    def emit(selected):
        chosen=modes.copy();matrix=base.copy()
        for opt in selected:
            i=opt['owner'];chosen[i]=opt['mode'];matrix[i]=opt['losses'];matrix[:,i]=opt['losses']
        if len(selected)==2:
            a,b=selected;i,j=a['owner'],b['owner'];loss=sum(x.intersection(y).area for x,y in zip(a['shape'],b['shape']));matrix[i,j]=matrix[j,i]=loss
        losses=np.asarray([matrix[i,j] for i,j in pairs]);physical=list(physical_key(library,classes,chosen));key=problem_key(physical,weights)
        records.append({'sequence':len(records),'changes':[[o['owner'],o['mode']] for o in selected],'centers':[o['center'] for o in selected],'modes':chosen,'physical_key':physical,'key':key,'weighted_objective_mm2':float(np.dot(weights,losses)),'unweighted_objective_mm2':float(np.sum(losses)),'excluded':key in closed_keys,'exclusion_reason':'closed_weighted_problem' if key in closed_keys else None})
    emit([])
    for i in range(count):
        for option in options[i]:emit([option])
    for i,j in combinations(range(count),2):
        for a,b in product(options[i],options[j]):emit([a,b])
    assert len(records)==2854 and len(trials)==6396 and len(selections)==78 and len({r['key'] for r in records})==len(records)
    return records,aliases,trials,selections
