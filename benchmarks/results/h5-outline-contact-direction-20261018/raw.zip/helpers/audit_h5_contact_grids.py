from pathlib import Path
from hashlib import sha256
import json,math,itertools
from shapely.geometry import Polygon,Point,LineString,shape
from shapely.ops import nearest_points,unary_union
import audit_h5_cog_lattices as core
ROOT=core.ROOT;DIRECT=ROOT/'output/h5-contact-direction-20261018';SCAN=ROOT/'output/h5-minimum-contact-grids-20261018';load=core.load;write=core.write
def audit_pattern(part,p,angles,pitch,n,cols,cx,cy):
    raw=[]
    for i in range(n):
        row,col=divmod(i,cols);theta=angles[(row+col)%2];c,s=math.cos(theta),math.sin(theta);raw.append({'rotation_radians':theta,'translation':[col*pitch-c*cx+s*cy,row*pitch-s*cx-c*cy],'mirrored':False})
    gs=[core.shape(part,t) for t in raw];x0=min(g.bounds[0] for g in gs);y0=min(g.bounds[1] for g in gs)
    for t,m in zip(raw,p['members']):t['translation'][0]-=x0;t['translation'][1]-=y0;assert m=={'part_id':'cog','transform':t}
    assert len(p['members'])==n;actual=[core.shape(part,m['transform']) for m in p['members']];minimum=math.inf;checks=0
    for a,b in itertools.combinations(actual,2):checks+=1;d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=.2
    assert abs(max(g.bounds[2] for g in actual)-p['width'])<1e-9 and abs(max(g.bounds[3] for g in actual)-p['height'])<1e-9
    return checks,minimum
def main():
    job=load(SCAN/'job.json');part=next(p for p in job['parts'] if p['id']=='cog');poly=Polygon(part['geometry'][0]['outer']);cx,cy=poly.centroid.coords[0];dplan=load(DIRECT/'plan.json');assert core.digest(ROOT/dplan['source_pairs'])==dplan['source_pairs_sha256'] and core.digest(ROOT/dplan['source_job'])==dplan['job_sha256'];source=load(DIRECT/'source-pairs.json');dp=load(DIRECT/'patterns.json');directpairs=0;directmin=math.inf
    for r,pair in zip(load(DIRECT/'result.json')['cases'],source):
        centers=[core.shape(part,m['transform']).centroid.coords[0] for m in pair['members']];u=[centers[1][i]-centers[0][i] for i in [0,1]];assert max(abs(a-b) for a,b in zip(u,r['contact_vector']))<1e-9
        assert abs(r['pitch_mm']-(math.hypot(*u)+.03))<1e-9;count,d=audit_pattern(part,dp[f"directed-pair-{r['source_pair']}"],r['angles_radians'],r['pitch_mm'],15,5,cx,cy);directpairs+=count;directmin=min(directmin,d)
    plan=load(SCAN/'plan.json');phases=load(SCAN/'phases.json');patterns=load(SCAN/'patterns.json');assert [r['phase'] for r in phases]==plan['relative_phases_degrees'];pairs=0;minimum=math.inf;closest_error=0.
    for r in phases:
        forbidden=shape(load(SCAN/'obstacles'/f"{r['phase']}.json"));outer=unary_union([p.exterior for p in [forbidden] if p.geom_type=='Polygon']) if forbidden.geom_type=='Polygon' else unary_union([p.exterior for p in forbidden.geoms]);point=nearest_points(Point(0,0),outer)[1];err=abs(point.distance(Point(0,0))-r['closest_distance_mm']);closest_error=max(closest_error,err);assert err<1e-9
        ux,uy=r['closest_contact'];assert outer.distance(Point(ux,uy))<1e-9;aa,bb=r['boundary_segment'];t=r['segment_fraction'];assert 0<=t<=1 and max(abs(aa[i]+t*(bb[i]-aa[i])-r['closest_contact'][i]) for i in [0,1])<1e-12
        assert abs(math.atan2(uy,ux)-r['alignment_radians'])<1e-12;align=r['alignment_radians'];c,s=math.cos(align),math.sin(align);ext=[]
        # Independent ray intersection in the original obstacle coordinates,
        # rather than rotating the entire saved polygon as the producer does.
        for dx,dy in [(c,s),(-s,c)]:
            cross=forbidden.intersection(LineString([(-1000*dx,-1000*dy),(1000*dx,1000*dy)]));lines=[cross] if cross.geom_type=='LineString' else list(cross.geoms);ts=[x*dx+y*dy for line in lines for x,y in line.coords];ext.extend([min(ts),max(ts)])
        assert max(abs(a-b) for a,b in zip(ext,r['axis_extents_mm']))<1e-8;assert abs(max(map(abs,ext))+.0001-r['pitch_mm'])<1e-8
        assert r['angles_radians']==[-align,math.radians(r['phase'])-align]
        for name,(n,cols) in zip(r['patterns'],plan['grids']):
            count,d=audit_pattern(part,patterns[name],r['angles_radians'],r['pitch_mm'],n,cols,cx,cy);pairs+=count;minimum=min(minimum,d)
    assert pairs==load(SCAN/'result.json')['pair_checks'];selected=load(SCAN/'selection.json')
    for r,(n,cols) in zip(selected,plan['grids']):
        best=min((p for p in patterns.values() if p['construction']['count']==n and p['construction']['columns']==cols and not p['construction']['violations']),key=lambda p:(p['width']*p['height'],p['id']));assert r['pattern']==best['id']
    olddir=ROOT/'output/h5-cog-lattices-20261018';oldgen=load(olddir/'generation.json');oldpattern=load(olddir/'patterns.json')[oldgen['best'][0]['patterns'][0]];oldarea=oldpattern['width']*oldpattern['height'];newarea=selected[0]['area_mm2'];result={'saved_pair_probe_pairs':directpairs,'saved_pair_probe_minimum_distance_mm':directmin,'scanned_phases':len(phases),'scanned_components':len(patterns),'scanned_pair_checks':pairs,'scanned_minimum_distance_mm':minimum,'all_transforms_reconstructed_exact':True,'maximum_independent_nearest_boundary_distance_error_mm':closest_error,'all_axis_pitches_verified_with_original_obstacle_rays':True,'old_15_cog_rectangle_area_mm2':oldarea,'new_15_cog_rectangle_area_mm2':newarea,'rectangle_area_reduction_percent':100*(1-newarea/oldarea),'full_target_witness':False,'native_margin_qualification_not_claimed':True};write(SCAN/'audit.json',result);print(json.dumps(result))
if __name__=='__main__':main()
