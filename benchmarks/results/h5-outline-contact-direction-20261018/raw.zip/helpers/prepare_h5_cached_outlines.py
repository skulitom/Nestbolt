from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1];original=ROOT/'output/h5-ragged-outline-beam-20261018';p=original/'audit-recovered/recipe-0-command.json';v=json.loads(p.read_bytes());shutil.copyfile(p,p.with_name('recipe-0-command-assumed-exit.json'));v['exit_code']=None;v['exit_code_note']='The original failed auditor did not save the validator return code. The first recovery metadata assumed 1; that assumption is preserved separately and superseded here. The original stdout/stderr and their hashes are unchanged.';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(ROOT/'output/construct_h5_ragged_outlines.py').read_text(encoding='utf-8')
def replace(a,b):
    global s
    assert s.count(a)==1,a;s=s.replace(a,b)
replace('import construct_h5_outline_beam as beam','from shapely.affinity import affine_transform\nfrom shapely.geometry import mapping\nfrom shapely.ops import unary_union\nimport construct_h5_outline_beam as beam')
replace("OUT=ROOT/'output/h5-ragged-outline-beam-20261018'","OUT=ROOT/'output/h5-ragged-outline-cached-20261018'")
replace('class Placer(beam.Placement):','''class Placer(beam.Placement):
    def forbidden(self,fixed,moving):
        key=(fixed,moving)
        if not hasattr(self,'primitive_cache'):
            self.primitive_cache={};self.primitive_keys=[];self.constructions=[];self.primitive_seconds=0.;self.union_seconds=0.
        if key not in self.obstacles:
            shapes=[];terms=[]
            for a in self.templates[fixed]['members']:
                for b in self.templates[moving]['members']:
                    ta,tb=a['transform'],b['transform'];primitive=(a['part_id'],ta['rotation_radians'],ta['mirrored'],b['part_id'],tb['rotation_radians'],tb['mirrored'])
                    if primitive not in self.primitive_cache:
                        t0=time.perf_counter();ga=gap.pose(self.shapes[a['part_id']],{**ta,'translation':[0.,0.]});gb=gap.pose(self.shapes[b['part_id']],{**tb,'translation':[0.,0.]});obstacle=gap.obstacle(ga,gb,self.clearance);self.primitive_seconds+=time.perf_counter()-t0;index=len(self.primitive_keys);self.primitive_keys.append(primitive);self.primitive_cache[primitive]=(index,obstacle)
                    index,obstacle=self.primitive_cache[primitive];dx=ta['translation'][0]-tb['translation'][0];dy=ta['translation'][1]-tb['translation'][1];shapes.append(affine_transform(obstacle,[1,0,0,1,dx,dy]));terms.append({'primitive':index,'translation':[dx,dy]})
            t0=time.perf_counter();self.obstacles[key]=unary_union(shapes);self.union_seconds+=time.perf_counter()-t0;self.constructions.append({'fixed':fixed,'moving':moving,'terms':terms})
        return self.obstacles[key]
''')
replace("    write(OUT/'plan.json',plan)","    plan['cache_change']='Build each pairwise Minkowski obstacle once from the original primitive outlines with their exact unrounded rotation/reflection and zero translation. Translate it by fixed-member translation minus moving-member translation, then union all compound member pairs. The geometric identity (A+a)-(B+b)=(A-B)+(a-b) preserves the ideal exclusion set; every admitted addition still passes direct original-outline distance and stock checks. No orientation rounding, cap, recipe, order or beam change. This controls repeated primitive geometry work; no native-speed claim.'\n    plan['prior_plan_sha256']=base.digest(ROOT/'output/h5-ragged-outline-beam-20261018/plan.json')\n    write(OUT/'plan.json',plan)")
replace("    write(OUT/'results.json',", "    write(OUT/'primitive-obstacles.json',[{'id':i,'key':list(k),'geometry':mapping(placer.primitive_cache[k][1])} for i,k in enumerate(placer.primitive_keys)])\n    write(OUT/'compound-obstacle-provenance.json',placer.constructions)\n    write(OUT/'cache-metrics.json',{'primitives':len(placer.primitive_keys),'compound_obstacles':len(placer.constructions),'compound_pair_terms':sum(len(c['terms']) for c in placer.constructions),'primitive_seconds':placer.primitive_seconds,'union_seconds':placer.union_seconds})\n    write(OUT/'results.json',")
dest=ROOT/'output/construct_h5_cached_outlines.py';assert not dest.exists();dest.write_text(s,encoding='utf-8',newline='\n')
a=(ROOT/'output/audit_h5_ragged_outlines.py').read_text(encoding='utf-8').replace('h5-ragged-outline-beam-20261018','h5-ragged-outline-cached-20261018')
old="else:assert not public['valid'] and public['violations'] and all(v['code']=='quantity' for v in public['violations'])"
new="""else:
                    assert not public['valid'] and public['violations'] and all(v['code'] in ['quantity','empty_sheet'] for v in public['violations'])
                    empty=[sheet['id'] for sheet in layout['sheets'] if not any(p['sheet_id']==sheet['id'] for p in layout['placements'])]
                    assert sorted(v['message'] for v in public['violations'] if v['code']=='empty_sheet')==sorted('sheet '+s+' has no placements' for s in empty)
                record['public_violation_codes']=[v['code'] for v in public['violations']]"""
assert a.count(old)==1;a=a.replace(old,new);dest=ROOT/'output/audit_h5_cached_outlines.py';assert not dest.exists();dest.write_text(a,encoding='utf-8',newline='\n');print('Prepared primitive-translation cache; preserved all search limits and the audit metadata correction.')
