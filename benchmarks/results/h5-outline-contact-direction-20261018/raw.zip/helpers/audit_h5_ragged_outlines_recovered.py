"""Independent source/identity/filled-outer checks for retained outline results."""
from pathlib import Path
from collections import Counter
from hashlib import sha256
import json,math,itertools,gzip,subprocess
from shapely.geometry import Polygon
import audit_h5_cog_lattices as core
ROOT=core.ROOT;RUN=ROOT/'output/h5-ragged-outline-beam-20261018';OUT=RUN/'audit-recovered';load=core.load;write=core.write;shape=core.shape
def main():
    OUT.mkdir();plan=load(RUN/'plan.json');job=load(RUN/'job.json');parts={p['id']:p for p in job['parts']};required=Counter({k:p['quantity'] for k,p in parts.items()});templates=load(RUN/'templates.json');patterns=load(RUN/'patterns.json');source={**load(ROOT/'output/h5-cog-lattices-20261018/all-patterns.json'),**load(ROOT/'output/h5-ragged-pockets-20261018/components.json')}
    for name,h in plan['inputs'].items():assert core.digest(ROOT/name)==h
    for name,p in patterns.items():assert p==source[name]
    templatepairs=0
    for t in templates:
        original=patterns[t['id']];assert len(t['members'])==len(original['members']);theta=t['members'][0]['transform']['rotation_radians']-original['members'][0]['transform']['rotation_radians'];step=15 if len(original['members'])==1 and parts[original['members'][0]['part_id']]['rotations']['kind']=='free' else 90;assert abs(theta/math.radians(step)-round(theta/math.radians(step)))<1e-9
        c,s=math.cos(theta),math.sin(theta);expected=[]
        for m in original['members']:
            x,y=m['transform']['translation'];expected.append({'part_id':m['part_id'],'transform':{'rotation_radians':m['transform']['rotation_radians']+theta,'translation':[c*x-s*y,s*x+c*y],'mirrored':m['transform']['mirrored']}})
        geoms=[shape(parts[m['part_id']],m['transform']) for m in expected];x0=min(g.bounds[0] for g in geoms);y0=min(g.bounds[1] for g in geoms)
        for a,b in zip(expected,t['members']):
            a['transform']['translation'][0]-=x0;a['transform']['translation'][1]-=y0;assert a['part_id']==b['part_id'] and a['transform']['mirrored']==b['transform']['mirrored'];assert abs(a['transform']['rotation_radians']-b['transform']['rotation_radians'])<1e-12;assert max(abs(x-y) for x,y in zip(a['transform']['translation'],b['transform']['translation']))<1e-9
        geoms=[shape(parts[m['part_id']],m['transform']) for m in t['members']]
        for a,b in itertools.combinations(geoms,2):templatepairs+=1;assert a.disjoint(b) and a.distance(b)>=job['clearance']-1e-7
    st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];target=load(RUN/'conditional-target.json');results=load(RUN/'results.json');records=[];pairs=0;cache={};roots=0;events=0
    for result in results['recipes']:
        folder=RUN/f"recipe-{result['recipe']}";recipe=load(folder/'recipe.json');assert Counter(z['part_id'] for n,qty in recipe['recipe'].items() for _ in range(qty) for z in patterns[n]['members'])==required
        nodes={}
        with gzip.open(folder/'candidates.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                r=json.loads(line)
                if r['kind']=='root':
                    assert Counter(z['part_id'] for n in r['order'] for z in patterns[n]['members'])==required;nodes[r['id']]=None;roots+=1
                elif r['kind']=='candidate':assert r['parent'] in nodes;nodes[r['id']]=(r['parent'],r['block'],r['valid']);events+=1
                elif r['kind']=='beam':assert all(nodes[i][2] for i in r['ids'])
        states=[(run['mode'],load(folder/(run['mode']+'-state.json')),load(folder/(run['mode']+'-layout.json'))) for run in result['runs']];states.append(('best',load(folder/'best-state.json')['state'],load(folder/'best-layout.json')))
        for label,state,layout in states:
            chain=[];i=state['id']
            while nodes[i] is not None:
                parent,block,valid=nodes[i];assert valid;chain.append(block);i=parent
            assert chain[::-1]==state['placed'];expected=[];counts=Counter()
            for block in state['placed']:
                for member in templates[block['template']]['members']:
                    t=json.loads(json.dumps(member['transform']));t['translation'][0]+=block['x']+m['left']+e+1e-4;t['translation'][1]+=block['y']+m['bottom']+e+1e-4;k=member['part_id'];expected.append({'part_id':k,'copy_index':counts[k],'sheet_id':f"sheet-{block['sheet']}",'transform':t});counts[k]+=1
            assert expected==layout['placements'] and layout['sheets']==load(RUN/'original.json')['sheets'];assert not (counts-required)
            key=sha256(json.dumps(layout,sort_keys=True).encode()).hexdigest()
            if key not in cache:
                gs={};tops={};seen=set();minimum=math.inf;lpairs=0
                for p in layout['placements']:
                    ident=(p['part_id'],p['copy_index']);assert ident not in seen;seen.add(ident);part=parts[p['part_id']];t=p['transform'];assert not t['mirrored'] or part['allow_mirror']
                    if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
                    g=shape(part,t);x0,y0,x1,y1=g.bounds;top=st['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm'];assert g.is_valid and x0>=m['left']+e-1e-7 and y0>=m['bottom']+e-1e-7 and x1<=st['width']-m['right']-e+1e-7 and y1<=top-m['top']-e+1e-7;gs.setdefault(p['sheet_id'],[]).append(g);tops[p['sheet_id']]=max(y1,tops.get(p['sheet_id'],0))
                for shapes in gs.values():
                    for a,b in itertools.combinations(shapes,2):lpairs+=1;d=a.distance(b);minimum=min(minimum,d);assert a.disjoint(b) and d>=job['clearance']-1e-7
                charged=st['width']*(st['height']+tops.get('sheet-1',0)+m['top']+e);assert charged<=target['target_material_mm2']+1e-6
                cache[key]={'pairs':lpairs,'minimum_distance_mm':minimum,'charged_material_mm2':charged,'placed':sum(counts.values()),'missing':dict(required-counts)};pairs+=lpairs
            record={'recipe':result['recipe'],'label':label,'layout_hash':key,**cache[key]};records.append(record)
            if label=='best':
                assert record['missing']==result['missing'] and record['placed']==result['placed_count'];cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert core.digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';cmd=[str(cli),'validate','--library',str(RUN/'library.json'),'--request',str(RUN/'request.json'),'--layout',str(folder/'best-layout.json')];r=None
                if result['recipe']==0:
                    recovery=load(RUN/'audit/failure.json');assert core.digest(folder/'best-layout.json')==recovery['layout_sha256'];stdout=(RUN/'audit/recipe-0-stdout.json').read_bytes();stderr=(RUN/'audit/recipe-0-stderr.log').read_bytes();assert sha256(stdout).hexdigest()==recovery['stdout_sha256'] and sha256(stderr).hexdigest()==recovery['stderr_sha256'];exit_code=1
                else:
                    r=subprocess.run(cmd,capture_output=True,timeout=60);stdout,stderr,exit_code=r.stdout,r.stderr,r.returncode
                (OUT/f"recipe-{result['recipe']}-stdout.json").write_bytes(stdout);(OUT/f"recipe-{result['recipe']}-stderr.log").write_bytes(stderr);public=json.loads(stdout)
                if result['full_witness']:assert public['valid']
                else:
                    assert not public['valid'] and public['violations'] and all(v['code'] in ['quantity','empty_sheet'] for v in public['violations'])
                    empty=[sheet['id'] for sheet in layout['sheets'] if not any(p['sheet_id']==sheet['id'] for p in layout['placements'])]
                    assert sorted(v['message'] for v in public['violations'] if v['code']=='empty_sheet')==sorted('sheet '+s+' has no placements' for s in empty)
                record['public_violation_codes']=[v['code'] for v in public['violations']]
                write(OUT/f"recipe-{result['recipe']}-command.json",{'command':cmd,'exit_code':exit_code,'reused_original_recipe_zero_result':result['recipe']==0})
    checks={'templates':len(templates),'template_pairs':templatepairs,'all_template_provenance_verified':True,'all_saved_states_reconstructed_from_candidate_parents':True,'original_full_inventory_root_orders':roots,'candidate_events_preserved':events,'rejected_candidate_geometry_not_exhaustively_audited':True,'unique_retained_layouts':len(cache),'retained_filled_outer_pairs':pairs,'retained_layouts':records,'all_original_targets_and_orientations_verified':True,'complete_witness':results['full_witness']};write(OUT/'checks.json',checks);print(json.dumps({k:v for k,v in checks.items() if k!='retained_layouts'}))
if __name__=='__main__':main()
