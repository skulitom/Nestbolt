from pathlib import Path
import json,math,time,itertools
from shapely.geometry import shape,Polygon
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;RUN=ROOT/'output/h5-ragged-outline-cached-20261018';OLD=ROOT/'output/h5-ragged-outline-beam-20261018';load=base.load;write=base.write;gap=base.gap
def main():
    t0=time.perf_counter();plan=load(RUN/'plan.json');oldplan=load(OLD/'plan.json');assert plan['prior_plan_sha256']==base.digest(OLD/'plan.json')
    for k in ['seconds_per_recipe','recipe_count','beam_width','contacts_per_template','family_orders','construction_clearance_mm','inputs']:assert plan[k]==oldplan[k]
    for n in ['patterns.json','templates.json','domain.json','job.json','library.json','request.json','conditional-target.json']:assert (RUN/n).read_bytes()==(OLD/n).read_bytes()
    job=load(RUN/'job.json');shapes={p['id']:Polygon(p['geometry'][0]['outer']) for p in job['parts']};cached=load(RUN/'primitive-obstacles.json');keys={};max_distance=0.;max_area=0.
    for row in cached:
        k=row['key'];assert tuple(k) not in keys;keys[tuple(k)]=row['id'];assert row['id']==len(keys)-1;a=gap.pose(shapes[k[0]],base.transform(k[1],mirrored=k[2]));b=gap.pose(shapes[k[3]],base.transform(k[4],mirrored=k[5]));actual=shape(row['geometry']);expected=gap.obstacle(a,b,.22);distance=actual.hausdorff_distance(expected);area=actual.symmetric_difference(expected).area;max_distance=max(max_distance,distance);max_area=max(max_area,area);assert distance<=1e-9 and area<=1e-7
    templates=load(RUN/'templates.json');provenance=load(RUN/'compound-obstacle-provenance.json');pairs=0;seen=set()
    for r in provenance:
        key=(r['fixed'],r['moving']);assert key not in seen;seen.add(key);expected=[]
        for a,b in itertools.product(templates[r['fixed']]['members'],templates[r['moving']]['members']):
            ta,tb=a['transform'],b['transform'];primitive=(a['part_id'],ta['rotation_radians'],ta['mirrored'],b['part_id'],tb['rotation_radians'],tb['mirrored']);expected.append({'primitive':keys[primitive],'translation':[ta['translation'][0]-tb['translation'][0],ta['translation'][1]-tb['translation'][1]]});pairs+=1
        assert expected==r['terms']
    result={'seconds':time.perf_counter()-t0,'all_search_controls_and_input_bytes_unchanged':True,'primitive_obstacles_recomputed':len(cached),'maximum_hausdorff_difference_mm':max_distance,'maximum_symmetric_difference_area_mm2':max_area,'compound_pair_translations_verified':pairs,'compound_obstacles':len(provenance),'no_rotation_rounding':True,'geometric_identity':'Minkowski difference of translated primitives equals zero-translation difference shifted by fixed translation minus moving translation. Buffering commutes with translation. Compound exclusion is the union of all member-pair exclusions.','union_outputs_not_separately_serialized':True,'final_admission_geometry_checked_separately':True};write(RUN/'cache-audit.json',result);print(json.dumps(result))
if __name__=='__main__':main()
