from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_cached_outlines.py').read_text(encoding='utf-8').replace('h5-ragged-outline-cached-20261018','h5-ragged-outline-adaptive-20261018').replace("'original_full_inventory_root_orders'","'original_full_inventory_root_inventories'")
old="assert chain[::-1]==state['placed'];expected=[];counts=Counter()"
new="assert chain[::-1]==state['placed'];assert Counter({k:v for k,v in state['remaining'].items() if v})==Counter(recipe['recipe'])-Counter(templates[b['template']]['id'] for b in state['placed']);expected=[];counts=Counter()"
assert s.count(old)==1;s=s.replace(old,new);p=ROOT/'output/audit_h5_adaptive_outlines.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
s=(ROOT/'output/audit_h5_primitive_cache.py').read_text(encoding='utf-8').replace("RUN=ROOT/'output/h5-ragged-outline-cached-20261018';OLD=ROOT/'output/h5-ragged-outline-beam-20261018'","RUN=ROOT/'output/h5-ragged-outline-adaptive-20261018';OLD=ROOT/'output/h5-ragged-outline-cached-20261018'")
s=s.replace("assert plan['prior_plan_sha256']==base.digest(OLD/'plan.json')","assert plan['preloaded_cache_sha256']==base.digest(OLD/'primitive-obstacles.json');assert load(RUN/'primitive-obstacles.json')[:len(load(OLD/'primitive-obstacles.json'))]==load(OLD/'primitive-obstacles.json')")
s=s.replace("['seconds_per_recipe','recipe_count','beam_width','contacts_per_template','family_orders','construction_clearance_mm','inputs']","['seconds_per_recipe','recipe_count','contacts_per_template','construction_clearance_mm']").replace("'all_search_controls_and_input_bytes_unchanged'","'same_per_recipe_cap_contacts_clearance_and_geometry' ")
p=ROOT/'output/audit_h5_adaptive_cache.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n');print('Prepared original-inventory, parent-chain, geometry and primitive-cache audits.')
