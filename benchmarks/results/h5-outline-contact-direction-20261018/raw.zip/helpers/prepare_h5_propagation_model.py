from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];s=(ROOT/'output/solve_h5_ragged_normal.py').read_text(encoding='utf-8')
def replace(a,b):
    global s
    assert s.count(a)==1,a;s=s.replace(a,b)
replace("OUT=ROOT/'output/h5-ragged-normal-cpsat-20261018'","OUT=ROOT/'output/h5-ragged-propagation-cpsat-20261018'")
replace("    write(OUT/'plan.json',plan)","    plan['propagation_baseline_model_sha256']=digest(ROOT/'output/h5-ragged-normal-cpsat-20261018/model.pbtxt')\n    plan['controlled_parameter_changes']={n:{'before':False,'after':True} for n in ['use_timetabling_in_no_overlap_2d','use_energetic_reasoning_in_no_overlap_2d','use_area_energetic_reasoning_in_no_overlap_2d']}\n    plan['propagation_scope']='One predeclared mechanism test on the byte-identical saved model. Only these three propagation flags change; original inventory, integer domains, targets, seed, workers and 120-second limit remain exact. Preserve all prior UNKNOWN outcomes. No parameter sweep or increased allowance.'\n    write(OUT/'plan.json',plan)")
replace("    with (OUT/'solver.log').open", "    assert digest(OUT/'model.pbtxt')==plan['propagation_baseline_model_sha256']\n    (OUT/'parameters-before.txt').write_text(str(solver.parameters),encoding='utf-8',newline='\\n')\n    for flag in plan['controlled_parameter_changes']:\n        assert getattr(solver.parameters,flag)==False\n        setattr(solver.parameters,flag,True)\n    (OUT/'parameters-after.txt').write_text(str(solver.parameters),encoding='utf-8',newline='\\n')\n    with (OUT/'solver.log').open")
p=ROOT/'output/solve_h5_ragged_propagation.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n');print('Prepared controlled three-flag propagation change with exact model hash guard.')
