from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-minimum-contact-grids-20261018';OLD=ROOT/'output/h5-cog-lattices-20261018';load=lambda p:json.loads(p.read_bytes());job=load(RUN/'job.json');cog=next(p for p in job['parts'] if p['id']=='cog');old=load(OLD/'patterns.json')[load(OLD/'generation.json')['best'][0]['patterns'][0]];new=load(RUN/'patterns.json')[load(RUN/'selection.json')[0]['pattern']];audit=load(RUN/'audit.json')
fig,axes=plt.subplots(1,2,figsize=(14,6.5));fig.subplots_adjust(top=.79,bottom=.16,wspace=.12)
for ax,p,title,color in zip(axes,[old,new],['Earlier sampled-angle group','Group aligned to actual contact'],['#8e9fae','#d88b45']):
    for m in p['members']:
        t=m['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);x,y=t['translation'];ax.add_patch(Polygon([(a*c-b*s+x,a*s+b*c+y) for a,b in cog['geometry'][0]['outer']],facecolor=color,edgecolor='#263641',linewidth=.5))
    ax.add_patch(Rectangle((0,0),p['width'],p['height'],fill=False,linestyle='--',edgecolor='#3f505e'));ax.set_xlim(-20,1400);ax.set_ylim(-20,850);ax.set_aspect('equal');ax.set_title(title+f"\n{p['width']:.2f} × {p['height']:.2f} mm",fontsize=12);ax.set_xlabel('mm');ax.tick_params(labelsize=9)
fig.suptitle('A tighter cog group from the actual contact direction',fontsize=17,y=.96);fig.text(.5,.875,f"Same fifteen original cogs · {audit['rectangle_area_reduction_percent']:.2f}% smaller bounding area · verified minimum gap {audit['scanned_minimum_distance_mm']:.4f} mm",ha='center',fontsize=11)
fig.text(.5,.045,'This verifies a component. A complete 66-part target layout and native qualification are still required.',ha='center',fontsize=11);fig.savefig(RUN/'comparison.png',dpi=160,bbox_inches='tight');plt.close(fig)
