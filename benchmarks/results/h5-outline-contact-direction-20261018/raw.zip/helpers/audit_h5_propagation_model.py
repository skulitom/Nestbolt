from pathlib import Path
from hashlib import sha256
import json
from google.protobuf import text_format
from ortools.sat import sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-ragged-normal-cpsat-20261018';OUT=ROOT/'output/h5-ragged-propagation-cpsat-20261018';load=lambda p:json.loads(p.read_bytes())
def main():
    plan=load(OUT/'plan.json');assert (BASE/'model.pbtxt').read_bytes()==(OUT/'model.pbtxt').read_bytes()
    for n in ['patterns.json','mapping.json','normal-coordinates.json','job.json','library.json','request.json','conditional-target.json']:assert (BASE/n).read_bytes()==(OUT/n).read_bytes(),n
    before=text_format.Parse((OUT/'parameters-before.txt').read_text(encoding='utf-8'),sat_parameters_pb2.SatParameters());after=text_format.Parse((OUT/'parameters-after.txt').read_text(encoding='utf-8'),sat_parameters_pb2.SatParameters());expected=sat_parameters_pb2.SatParameters(max_time_in_seconds=120,num_search_workers=8,random_seed=0,log_search_progress=True,log_to_stdout=False);assert before==expected
    differences={}
    for d in before.DESCRIPTOR.fields:
        a,b=getattr(before,d.name),getattr(after,d.name)
        if a!=b:differences[d.name]={'before':a,'after':b}
    assert differences==plan['controlled_parameter_changes']
    for name in differences:expected.__setattr__(name,True)
    assert expected==after
    result={'model_bytes_exact':True,'all_input_bytes_exact':True,'only_three_declared_parameter_changes':differences,'seed_workers_time_limit_exact':True,'baseline_model_audit':load(BASE/'model-audit.json'),'model_sha256':sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()}
    with (OUT/'model-audit.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k!='baseline_model_audit'}))
if __name__=='__main__':main()
