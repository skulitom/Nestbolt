from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-ragged-outline-beam-20261018';old=ROOT/'output/audit_h5_ragged_outlines.py';folder=RUN/'audit';shutil.copyfile(old,folder/'failed-audit.py')
failure={'exit_code':1,'failure':'AssertionError at incomplete public-result check: expected quantity-only violations, but recipe 0 also correctly reports empty_sheet for its empty second sheet. Geometry checks had passed; the packing result is still incomplete and invalid as a whole job.','script_sha256':sha256(old.read_bytes()).hexdigest(),'layout_sha256':sha256((RUN/'recipe-0/best-layout.json').read_bytes()).hexdigest(),'stdout_sha256':sha256((folder/'recipe-0-stdout.json').read_bytes()).hexdigest(),'stderr_sha256':sha256((folder/'recipe-0-stderr.log').read_bytes()).hexdigest(),'repair':'Use a fresh audit directory, retain the original failed audit and public output. Reuse the exact recipe-0 validation output under the same layout/CLI hashes; validate remaining best partials once. Record missing quantities and empty sheets as real whole-job failures, with no geometry tolerance change.'}
with (folder/'failure.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(failure,f,indent=2);f.write('\n')
s=old.read_text(encoding='utf-8');s=s.replace("OUT=RUN/'audit'","OUT=RUN/'audit-recovered'")
a="r=subprocess.run(cmd,capture_output=True,timeout=60);(OUT/f\"recipe-{result['recipe']}-stdout.json\").write_bytes(r.stdout);(OUT/f\"recipe-{result['recipe']}-stderr.log\").write_bytes(r.stderr);public=json.loads(r.stdout)"
b="""r=None
                if result['recipe']==0:
                    recovery=load(RUN/'audit/failure.json');assert core.digest(folder/'best-layout.json')==recovery['layout_sha256'];stdout=(RUN/'audit/recipe-0-stdout.json').read_bytes();stderr=(RUN/'audit/recipe-0-stderr.log').read_bytes();assert sha256(stdout).hexdigest()==recovery['stdout_sha256'] and sha256(stderr).hexdigest()==recovery['stderr_sha256'];exit_code=1
                else:
                    r=subprocess.run(cmd,capture_output=True,timeout=60);stdout,stderr,exit_code=r.stdout,r.stderr,r.returncode
                (OUT/f"recipe-{result['recipe']}-stdout.json").write_bytes(stdout);(OUT/f"recipe-{result['recipe']}-stderr.log").write_bytes(stderr);public=json.loads(stdout)"""
assert s.count(a)==1;s=s.replace(a,b)
a="else:assert not public['valid'] and public['violations'] and all(v['code']=='quantity' for v in public['violations'])"
b="""else:
                    assert not public['valid'] and public['violations'] and all(v['code'] in ['quantity','empty_sheet'] for v in public['violations'])
                    empty=[sheet['id'] for sheet in layout['sheets'] if not any(p['sheet_id']==sheet['id'] for p in layout['placements'])]
                    assert sorted(v['message'] for v in public['violations'] if v['code']=='empty_sheet')==sorted('sheet '+s+' has no placements' for s in empty)
                record['public_violation_codes']=[v['code'] for v in public['violations']]"""
assert s.count(a)==1;s=s.replace(a,b).replace("'exit_code':r.returncode","'exit_code':exit_code,'reused_original_recipe_zero_result':result['recipe']==0")
p=ROOT/'output/audit_h5_ragged_outlines_recovered.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n');print('Preserved failed quantity-only audit; prepared exact-output recovery.')
