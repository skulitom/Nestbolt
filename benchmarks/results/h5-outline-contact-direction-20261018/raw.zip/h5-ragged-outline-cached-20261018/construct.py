"""Construct original jobs using actual outlines of verified ragged components."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import json,gzip,copy,time,math,itertools,shutil,traceback
from shapely.affinity import affine_transform
from shapely.geometry import mapping
from shapely.ops import unary_union
import construct_h5_outline_beam as beam
base=beam.base;gap=beam.gap;ROOT=base.ROOT;load=base.load;write=base.write
SRC=ROOT/'output/h5-ragged-pockets-20261018';PROP=ROOT/'output/h5-ragged-propagation-cpsat-20261018';OUT=ROOT/'output/h5-ragged-outline-cached-20261018'
class Placer(beam.Placement):
    def forbidden(self,fixed,moving):
        key=(fixed,moving)
        if not hasattr(self,'primitive_cache'):
            self.primitive_cache={};self.primitive_keys=[];self.constructions=[];self.primitive_seconds=0.;self.union_seconds=0.
        if key not in self.obstacles:
            shapes=[];terms=[]
            for a in self.templates[fixed]['members']:
                for b in self.templates[moving]['members']:
                    ta,tb=a['transform'],b['transform'];primitive=(a['part_id'],ta['rotation_radians'],ta['mirrored'],b['part_id'],tb['rotation_radians'],tb['mirrored'])
                    if primitive not in self.primitive_cache:
                        t0=time.perf_counter();ga=gap.pose(self.shapes[a['part_id']],{**ta,'translation':[0.,0.]});gb=gap.pose(self.shapes[b['part_id']],{**tb,'translation':[0.,0.]});obstacle=gap.obstacle(ga,gb,self.clearance);self.primitive_seconds+=time.perf_counter()-t0;index=len(self.primitive_keys);self.primitive_keys.append(primitive);self.primitive_cache[primitive]=(index,obstacle)
                    index,obstacle=self.primitive_cache[primitive];dx=ta['translation'][0]-tb['translation'][0];dy=ta['translation'][1]-tb['translation'][1];shapes.append(affine_transform(obstacle,[1,0,0,1,dx,dy]));terms.append({'primitive':index,'translation':[dx,dy]})
            t0=time.perf_counter();self.obstacles[key]=unary_union(shapes);self.union_seconds+=time.perf_counter()-t0;self.constructions.append({'fixed':fixed,'moving':moving,'terms':terms})
        return self.obstacles[key]

    def choose(self,states):
        ordered=sorted(states,key=lambda s:(s['score'],s['id']));bucket_width=self.width*self.heights[1]/4;buckets={}
        for s in ordered:
            # Retain distinct orientations of the leading rigid cog group as
            # well as different second-sheet allocations.
            key=(s['placed'][0]['template'],min(3,int(s['areas'][1]/bucket_width)))
            if key not in buckets:buckets[key]=s
        kept=sorted(buckets.values(),key=lambda s:(s['score'],s['id']))[:8];ids={s['id'] for s in kept}
        for s in ordered:
            if len(kept)==8:break
            if s['id'] not in ids:kept.append(s);ids.add(s['id'])
        return kept
def main():
    assert load(PROP/'result.json')['status']=='UNKNOWN'
    OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');job=load(SRC/'job.json');recipes=load(SRC/'selected-recipes.json');prior=load(ROOT/'output/h5-cog-lattices-20261018/all-patterns.json');components=load(SRC/'components.json');allp={**prior,**components};patterns={n:allp[n] for n in sorted(set().union(*(r['recipe'] for r in recipes)))}
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'inputs':{str(p.relative_to(ROOT)):base.digest(p) for p in [SRC/'job.json',SRC/'selected-recipes.json',SRC/'components.json',ROOT/'output/h5-cog-lattices-20261018/all-patterns.json',PROP/'result.json']},
          'seconds_per_recipe':20,'recipe_count':6,'beam_width':8,'contacts_per_template':3,'family_orders':['frame-first','mixed-first','cog-first'],'construction_clearance_mm':.22,
          'method':'Keep the leading filled ragged component rigid, but place it and all remaining original components using unions of actual filled-outer Minkowski exclusions, not their enclosing rectangles. Include all six recipes, including both earlier rectangle-area exclusions. Preserve four quarter-turn group orientations and second-sheet-area diversity in an eight-state beam. Original single cogs use finite 15-degree angles; other components use allowed quarter turns. Inspect three lowest distinct contacts per orientation and sheet, with direct physical checks on each addition. For each recipe try the three declared family orders until all finish, a full witness appears, or its independent twenty-second cap expires. No unused time is transferred to another recipe. Retain every candidate, beam, partial and timeout. This is a finite offline construction, not runtime qualification or an infeasibility proof.',
          'no_native_packing_or_quality_runs':True}
    plan['cache_change']='Build each pairwise Minkowski obstacle once from the original primitive outlines with their exact unrounded rotation/reflection and zero translation. Translate it by fixed-member translation minus moving-member translation, then union all compound member pairs. The geometric identity (A+a)-(B+b)=(A-B)+(a-b) preserves the ideal exclusion set; every admitted addition still passes direct original-outline distance and stock checks. No orientation rounding, cap, recipe, order or beam change. This controls repeated primitive geometry work; no native-speed claim.'
    plan['prior_plan_sha256']=base.digest(ROOT/'output/h5-ragged-outline-beam-20261018/plan.json')
    write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(SRC/n,OUT/n)
    write(OUT/'patterns.json',patterns);target=load(SRC/'conditional-target.json');st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];width=st['width']-m['left']-m['right']-2*e-2e-4;heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,target['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
    placer=Placer(job,patterns,width,heights);placer.clearance=.22;write(OUT/'templates.json',[{k:v for k,v in t.items() if k!='outer_geometries'} for t in placer.templates]);write(OUT/'domain.json',{'width':width,'heights':heights});results=[];next_id=0;overall=None
    for ri,recipe in enumerate(recipes):
        folder=OUT/f'recipe-{ri}';folder.mkdir();write(folder/'recipe.json',recipe);t0=time.perf_counter();deadline=t0+20;expired=False;runs=[];best=None;success=None;candidates=0
        with gzip.open(folder/'candidates.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
            def emit(r):log.write(json.dumps(r,separators=(',',':'))+'\n')
            for mode in plan['family_orders']:
                if time.perf_counter()>=deadline:expired=True;break
                first=recipe['id'];remaining=Counter(recipe['recipe']);remaining[first]-=1
                family_order={'frame-first':['frame','mix','cog','insert'],'mixed-first':['mix','frame','cog','insert'],'cog-first':['cog','frame','mix','insert']}[mode]
                def rank(n):
                    kind='mix' if n.startswith('mix-') else n;return (family_order.index(kind),-patterns[n]['area'],n)
                order=[first]+sorted([n for n,qty in remaining.items() for _ in range(qty)],key=rank);next_id+=1;root={'id':next_id,'placed':[],'score':(0,0,0),'areas':[0,0],'tops':[0,0]};states=[root];emit({'kind':'root','id':root['id'],'order':order,'mode':mode});reached=0;run_best=root
                for depth,name in enumerate(order):
                    children=[]
                    for parent in states:
                        for tid,sheet in itertools.product(placer.by_name[name],[0,1]):
                            if time.perf_counter()>=deadline:expired=True;break
                            points=placer.positions(parent,tid,sheet)
                            if not points:emit({'kind':'empty','parent':parent['id'],'template':tid,'sheet':sheet,'depth':depth})
                            for x,y in points:
                                b={'template':tid,'x':x,'y':y,'sheet':sheet};valid=placer.valid_addition(parent,b);next_id+=1;candidates+=1;child={'id':next_id,'placed':parent['placed']+[b]};child['score']=placer.score(child);emit({'kind':'candidate','id':child['id'],'parent':parent['id'],'block':b,'valid':valid,'score':child['score'],'depth':depth})
                                if valid:children.append(child)
                            if expired:break
                        if expired:break
                    if not children:break
                    states=placer.choose(children);reached=depth+1;run_best=min(states,key=lambda s:(s['score'],s['id']));emit({'kind':'beam','depth':depth,'ids':[s['id'] for s in states]})
                    for child in states:
                        if best is None or (-sum(child['areas']),child['score'])<(-sum(best['state']['areas']),best['state']['score']):best={'state':child,'mode':mode,'remaining':order[depth+1:]}
                    if expired:break
                layout=placer.layout(run_best);write(folder/(mode+'-layout.json'),layout);write(folder/(mode+'-state.json'),run_best)
                run={'mode':mode,'placed_patterns':reached,'required_patterns':len(order),'placed_parts':len(layout['placements']),'expired':expired};runs.append(run);emit({'kind':'run_end',**run})
                if reached==len(order):
                    for n in ['library.json','request.json']:shutil.copyfile(OUT/n,folder/n)
                    success=gap.validate(folder,'complete',layout,job,load(OUT/'original.json'),{(p['part_id'],p['copy_index']) for p in layout['placements']});assert success['metrics']['material_area']<=target['target_material_mm2']+1e-6;break
                if expired:break
        assert best is not None;layout=placer.layout(best['state']);write(folder/'best-state.json',best);write(folder/'best-layout.json',layout);counts=Counter(p['part_id'] for p in layout['placements']);missing=Counter({p['id']:p['quantity'] for p in job['parts']})-counts
        result={'recipe':ri,'component':recipe['id'],'seconds':time.perf_counter()-t0,'expired':expired,'runs':runs,'candidates':candidates,'placed_count':len(layout['placements']),'filled_area':sum(best['state']['areas']),'missing':dict(missing),'full_witness':success is not None,'validation':success};write(folder/'result.json',result);results.append(result);print(json.dumps(result),flush=True)
        if overall is None or result['filled_area']>overall['filled_area']:overall=result
        if success:break
    write(OUT/'primitive-obstacles.json',[{'id':i,'key':list(k),'geometry':mapping(placer.primitive_cache[k][1])} for i,k in enumerate(placer.primitive_keys)])
    write(OUT/'compound-obstacle-provenance.json',placer.constructions)
    write(OUT/'cache-metrics.json',{'primitives':len(placer.primitive_keys),'compound_obstacles':len(placer.constructions),'compound_pair_terms':sum(len(c['terms']) for c in placer.constructions),'primitive_seconds':placer.primitive_seconds,'union_seconds':placer.union_seconds})
    write(OUT/'results.json',{'recipes':results,'best':overall,'full_witness':any(r['full_witness'] for r in results),'relative_obstacles':len(placer.obstacles),'producer_addition_pair_checks':placer.pair_checks,'candidate_geometry_not_independently_exhaustive':True})
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
