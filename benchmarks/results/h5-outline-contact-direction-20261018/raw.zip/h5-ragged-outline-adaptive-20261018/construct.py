"""Bounded adaptive inventory ordering with audited primitive exclusion cache."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import json,gzip,copy,time,itertools,shutil,traceback
from shapely.geometry import shape,mapping
import construct_h5_cached_outlines as cached
base=cached.base;gap=cached.gap;ROOT=base.ROOT;load=base.load;write=base.write
SRC=ROOT/'output/h5-ragged-pockets-20261018';PRIOR=ROOT/'output/h5-ragged-outline-cached-20261018';OUT=ROOT/'output/h5-ragged-outline-adaptive-20261018'
class Placer(cached.Placer):
    def choose(self,states):
        ordered=sorted(states,key=lambda s:(s['score'],-sum(s['areas']),s['id']));unique=[];seen=set()
        for s in ordered:
            key=(tuple(sorted((n,q) for n,q in s['remaining'].items() if q)),tuple(sorted((b['template'],b['sheet'],round(b['x'],6),round(b['y'],6)) for b in s['placed'])))
            if key not in seen:seen.add(key);unique.append(s)
        buckets={}
        for s in unique:
            key=(s['placed'][0]['template'],self.templates[s['placed'][-1]['template']]['id'])
            if key not in buckets:buckets[key]=s
        selected=sorted(buckets.values(),key=lambda s:(s['score'],-sum(s['areas']),s['id']))[:16];ids={s['id'] for s in selected}
        for s in unique:
            if len(selected)==16:break
            if s['id'] not in ids:selected.append(s);ids.add(s['id'])
        return selected
def main():
    assert not load(PRIOR/'results.json')['full_witness'] and load(PRIOR/'cache-audit.json')['maximum_hausdorff_difference_mm']==0
    OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');job=load(SRC/'job.json');recipes=load(SRC/'selected-recipes.json');patterns=load(PRIOR/'patterns.json');target=load(SRC/'conditional-target.json');st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];width=st['width']-m['left']-m['right']-2*e-2e-4;heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,target['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'inputs':{str(p.relative_to(ROOT)):base.digest(p) for p in [SRC/'job.json',SRC/'selected-recipes.json',SRC/'components.json',PRIOR/'patterns.json',PRIOR/'primitive-obstacles.json',PRIOR/'cache-audit.json']},'seconds_per_recipe':20,'recipe_count':6,'beam_width':16,'contacts_per_template':3,'construction_clearance_mm':.22,'preloaded_cache_sha256':base.digest(PRIOR/'primitive-obstacles.json'),
          'method':'Same six complete recipes and original targets. Place the verified rigid cog group first, then branch over every remaining component kind at every depth. Enumerate kinds by decreasing filled area. Each child consumes one available pattern. Keep sixteen states, retaining distinct leading-group orientations and last component kinds, ranked by original prefix-waste score. Deduplicate equal remaining inventories and template/sheet/positions rounded only for identity to six decimals; retained coordinates remain unrounded. Reuse the already independently audited primitive obstacle cache; compute any unseen exact-angle key with the same method. Each recipe has its own twenty-second search ceiling after cache loading, with no transferred time. Direct original-outline checks remain mandatory for every admission. This is finite offline construction, not a quality or native-speed claim.'}
    write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(SRC/n,OUT/n)
    write(OUT/'patterns.json',patterns);t0=time.perf_counter();placer=Placer(job,patterns,width,heights);placer.clearance=.22;placer.primitive_cache={};placer.primitive_keys=[]
    for row in load(PRIOR/'primitive-obstacles.json'):
        k=tuple(row['key']);assert row['id']==len(placer.primitive_keys);placer.primitive_keys.append(k);placer.primitive_cache[k]=(row['id'],shape(row['geometry']))
    placer.constructions=[];placer.primitive_seconds=0.;placer.union_seconds=0.;preload=time.perf_counter()-t0;write(OUT/'templates.json',[{k:v for k,v in t.items() if k!='outer_geometries'} for t in placer.templates]);write(OUT/'domain.json',{'width':width,'heights':heights});results=[];next_id=0;overall=None
    for ri,recipe in enumerate(recipes):
        folder=OUT/f'recipe-{ri}';folder.mkdir();write(folder/'recipe.json',recipe);t0=time.perf_counter();deadline=t0+20;expired=False;success=None;candidates=0;next_id+=1;root={'id':next_id,'placed':[],'remaining':dict(recipe['recipe']),'score':(0,0,0),'areas':[0,0],'tops':[0,0]};states=[root];best=root;reached=0;total=sum(recipe['recipe'].values())
        with gzip.open(folder/'candidates.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
            def emit(r):log.write(json.dumps(r,separators=(',',':'))+'\n')
            emit({'kind':'root','id':root['id'],'order':[n for n,qty in recipe['recipe'].items() for _ in range(qty)],'note':'Expanded inventory only; actual choice is adaptive.'})
            for depth in range(total):
                children=[]
                for parent in states:
                    names=[recipe['id']] if depth==0 else sorted([n for n,qty in parent['remaining'].items() if qty],key=lambda n:(-patterns[n]['area'],n))
                    for name in names:
                        for tid,sheet in itertools.product(placer.by_name[name],[0,1]):
                            if time.perf_counter()>=deadline:expired=True;break
                            points=placer.positions(parent,tid,sheet)
                            if not points:emit({'kind':'empty','parent':parent['id'],'pattern':name,'template':tid,'sheet':sheet,'depth':depth})
                            for x,y in points:
                                b={'template':tid,'x':x,'y':y,'sheet':sheet};valid=placer.valid_addition(parent,b);next_id+=1;candidates+=1;left=dict(parent['remaining']);left[name]-=1;child={'id':next_id,'placed':parent['placed']+[b],'remaining':left};child['score']=placer.score(child);emit({'kind':'candidate','id':child['id'],'parent':parent['id'],'pattern':name,'block':b,'valid':valid,'score':child['score'],'depth':depth})
                                if valid:children.append(child)
                            if expired:break
                        if expired:break
                    if expired:break
                if not children:break
                states=placer.choose(children);reached=depth+1;emit({'kind':'beam','depth':depth,'ids':[s['id'] for s in states]})
                for child in states:
                    if (-sum(child['areas']),child['score'])<(-sum(best['areas']),best['score']):best=child
                if reached==total:
                    full=min(states,key=lambda s:(s['score'],s['id']));layout=placer.layout(full)
                    for n in ['library.json','request.json']:shutil.copyfile(OUT/n,folder/n)
                    success=gap.validate(folder,'complete',layout,job,load(OUT/'original.json'),{(p['part_id'],p['copy_index']) for p in layout['placements']});assert success['metrics']['material_area']<=target['target_material_mm2']+1e-6;best=full;break
                if expired:break
        assert best['placed'];layout=placer.layout(best);write(folder/'adaptive-layout.json',layout);write(folder/'adaptive-state.json',best);write(folder/'best-state.json',{'state':best,'remaining':best['remaining']});write(folder/'best-layout.json',layout);counts=Counter(p['part_id'] for p in layout['placements']);missing=Counter({p['id']:p['quantity'] for p in job['parts']})-counts
        result={'recipe':ri,'component':recipe['id'],'seconds':time.perf_counter()-t0,'expired':expired,'runs':[{'mode':'adaptive','placed_patterns':len(best['placed']),'required_patterns':total,'placed_parts':len(layout['placements']),'expired':expired}],'depth_reached':reached,'candidates':candidates,'placed_count':len(layout['placements']),'filled_area':sum(best['areas']),'missing':dict(missing),'full_witness':success is not None,'validation':success};write(folder/'result.json',result);results.append(result);print(json.dumps(result),flush=True)
        if overall is None or result['filled_area']>overall['filled_area']:overall=result
        if success:break
    write(OUT/'primitive-obstacles.json',[{'id':i,'key':list(k),'geometry':mapping(placer.primitive_cache[k][1])} for i,k in enumerate(placer.primitive_keys)]);write(OUT/'compound-obstacle-provenance.json',placer.constructions);write(OUT/'cache-metrics.json',{'preload_seconds':preload,'preloaded_primitives':len(load(PRIOR/'primitive-obstacles.json')),'final_primitives':len(placer.primitive_keys),'new_primitive_seconds':placer.primitive_seconds,'union_seconds':placer.union_seconds})
    write(OUT/'results.json',{'recipes':results,'best':overall,'full_witness':any(r['full_witness'] for r in results),'relative_obstacles':len(placer.obstacles),'producer_addition_pair_checks':placer.pair_checks,'candidate_geometry_not_independently_exhaustive':True})
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
