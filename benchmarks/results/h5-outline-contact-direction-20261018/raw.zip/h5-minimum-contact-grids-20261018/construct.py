"""Finite phase scan with continuous contact direction from actual NFP segments."""
from pathlib import Path
from datetime import datetime,timezone
import json,math,itertools,time,shutil,traceback
from shapely.geometry import Polygon,LineString,mapping
from shapely.affinity import affine_transform
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;gap=base.gap;load=base.load;write=base.write;JOB=ROOT/'output/h5-ragged-cogs-20261018/job.json';OUT=ROOT/'output/h5-minimum-contact-grids-20261018'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');job=load(JOB);parts={p['id']:p for p in job['parts']};shapes={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};cog=shapes['cog'];cx,cy=cog.centroid.coords[0];centered=affine_transform(cog,[1,0,0,1,-cx,-cy]);phases=[i/2 for i in range(36)];grids=[[15,5],[15,4],[12,4],[10,5],[9,3],[6,3],[5,5],[3,3],[1,1]]
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'job_sha256':base.digest(JOB),'relative_phases_degrees':phases,'grids':grids,'construction_clearance_mm':.225,'pitch_increment_mm':.0001,'seconds_limit':120,
          'method':'For each of 36 declared relative phases at half-degree increments, form the actual centred filled-outer Minkowski obstacle with conservative 0.225 mm spacing. Project the origin onto every exterior boundary segment and choose the closest point by norm and deterministic coordinates. Align that actual contact vector to the horizontal axis by rotating both original orientations. Derive a uniform square pitch from the largest magnitude of all four axis intersections of the rotated obstacle, plus 0.0001 mm. Construct nine finite checkerboard patches, including two different 15-cog aspects. Verify every pair of every patch on original outlines; reject any violation. No rotational symmetry is assumed. This scans relative phases, not held-out data, and is only component geometry, not a full target witness or native qualification.'}
    write(OUT/'plan.json',plan);shutil.copyfile(JOB,OUT/'job.json');(OUT/'obstacles').mkdir();patterns={};results=[];t0=time.perf_counter();expired=False;checks=0
    for phase in phases:
        if time.perf_counter()-t0>=120:expired=True;break
        theta=math.radians(phase);moving=gap.pose(centered,base.transform(theta));forbidden=gap.obstacle(centered,moving,.225);write(OUT/'obstacles'/f'{phase}.json',mapping(forbidden));candidates=[]
        for poly in gap.polygons(forbidden):
            vs=list(poly.exterior.coords)
            for ai,bi in zip(vs,vs[1:]):
                ax,ay=ai;bx,by=bi;dx,dy=bx-ax,by-ay;length2=dx*dx+dy*dy
                if length2==0:continue
                t=min(1.,max(0.,-(ax*dx+ay*dy)/length2));x,y=ax+t*dx,ay+t*dy;candidates.append((math.hypot(x,y),x,y,ai,bi,t))
        distance,ux,uy,start,end,fraction=min(candidates);align=math.atan2(uy,ux);c,s=math.cos(-align),math.sin(-align);rotated=affine_transform(forbidden,[c,-s,s,c,0,0]);h=rotated.intersection(LineString([(-1000,0),(1000,0)]));v=rotated.intersection(LineString([(0,-1000),(0,1000)]));pitch=max(abs(h.bounds[0]),abs(h.bounds[2]),abs(v.bounds[1]),abs(v.bounds[3]))+.0001;angles=[-align,theta-align];names=[];invalid=[];minimum=math.inf
        for n,cols in grids:
            members=[]
            for i in range(n):
                row,col=divmod(i,cols);angle=angles[(row+col)%2];c,s=math.cos(angle),math.sin(angle);members.append(base.member('cog',base.transform(angle,col*pitch-c*cx+s*cy,row*pitch-s*cx-c*cy)))
            p=base.pattern(f'phase-{phase}-n{n}-c{cols}',members,shapes);gs=[gap.pose(cog,m['transform']) for m in p['members']];bad=[];localmin=math.inf
            for i,j in itertools.combinations(range(n),2):
                checks+=1;d=gs[i].distance(gs[j]);localmin=min(localmin,d);minimum=min(minimum,d)
                if not gs[i].disjoint(gs[j]) or d<job['clearance']:bad.append({'pair':[i,j],'distance':d,'overlap_area':gs[i].intersection(gs[j]).area})
            p['construction']={'phase':phase,'count':n,'columns':cols,'violations':bad,'minimum_distance_mm':localmin if math.isfinite(localmin) else None};patterns[p['id']]=p;names.append(p['id']);invalid.extend(bad)
        results.append({'phase':phase,'closest_contact':[ux,uy],'closest_distance_mm':distance,'boundary_segment':[start,end],'segment_fraction':fraction,'alignment_radians':align,'angles_radians':angles,'axis_extents_mm':[h.bounds[0],h.bounds[2],v.bounds[1],v.bounds[3]],'pitch_mm':pitch,'patterns':names,'minimum_distance_mm':minimum,'valid':not invalid,'violations':invalid})
    selected=[]
    for n,cols in grids:
        choices=[p for p in patterns.values() if p['construction']['count']==n and p['construction']['columns']==cols and not p['construction']['violations']];p=min(choices,key=lambda p:(p['width']*p['height'],p['id']));selected.append({'pattern':p['id'],'count':n,'columns':cols,'width_mm':p['width'],'height_mm':p['height'],'area_mm2':p['width']*p['height'],'phase':p['construction']['phase']})
    write(OUT/'patterns.json',patterns);write(OUT/'phases.json',results);write(OUT/'selection.json',selected);result={'seconds':time.perf_counter()-t0,'expired':expired,'phases':len(results),'components':len(patterns),'pair_checks':checks,'valid_components':sum(not p['construction']['violations'] for p in patterns.values()),'selected':selected,'full_target_witness':False};write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
