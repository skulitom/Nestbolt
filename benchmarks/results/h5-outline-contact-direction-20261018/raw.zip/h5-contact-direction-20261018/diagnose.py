"""Lift saved actual two-cog contacts into square grids without axis sampling."""
from pathlib import Path
from datetime import datetime,timezone
import json,math,itertools,shutil
from shapely.geometry import Polygon
import construct_h5_pattern_layouts as base
ROOT=base.ROOT;gap=base.gap;load=base.load;write=base.write
SRC=ROOT/'output/h5-radial-angle-diagnosis-20261018/m-mechanical-large-plates-k0.2-s0-candidate/patterns.json';JOB=ROOT/'output/h5-ragged-cogs-20261018/job.json';OUT=ROOT/'output/h5-contact-direction-20261018'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'diagnose.py');pairs=load(SRC);job=load(JOB);parts={p['id']:p for p in job['parts']};shapes={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};cog=shapes['cog'];cx,cy=cog.centroid.coords[0]
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),'source_pairs_sha256':base.digest(SRC),'job_sha256':base.digest(JOB),'source_pairs':str(SRC.relative_to(ROOT)),'source_job':str(JOB.relative_to(ROOT)),'pair_count':3,'grid_columns':5,'grid_rows':3,'extra_center_distance_mm':.03,
          'hypothesis':'The earlier checkerboard offsets alternate between the two parity classes, whereas a saved tight contact has a directed centre-to-centre vector with nonzero vertical component. Align that actual vector to the x axis by rotating both original cog orientations together. Use its length plus a fixed 0.03 mm construction increment as both square-grid pitches. Alternate the two orientations by row+column parity. This does not assume quarter-turn symmetry: verify every pair on original filled outlines and reject any violation. Only a valid component, never a full 66-part target witness, can result. Test exactly the three previously saved pairs, without contact optimization or solver calls.'}
    assert len(pairs)==3;write(OUT/'plan.json',plan);shutil.copyfile(SRC,OUT/'source-pairs.json');shutil.copyfile(JOB,OUT/'job.json');results=[];patterns={}
    for pi,pair in enumerate(pairs):
        assert len(pair['members'])==2 and all(m['part_id']=='cog' and not m['transform']['mirrored'] for m in pair['members']);centers=[]
        for m in pair['members']:
            t=m['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);centers.append([c*cx-s*cy+t['translation'][0],s*cx+c*cy+t['translation'][1]])
        ux,uy=centers[1][0]-centers[0][0],centers[1][1]-centers[0][1];length=math.hypot(ux,uy);align=math.atan2(uy,ux);pitch=length+.03;angles=[m['transform']['rotation_radians']-align for m in pair['members']];members=[]
        for row in range(3):
            for col in range(5):
                theta=angles[(row+col)%2];c,s=math.cos(theta),math.sin(theta);members.append(base.member('cog',base.transform(theta,col*pitch-c*cx+s*cy,row*pitch-s*cx-c*cy)))
        p=base.pattern(f'directed-pair-{pi}',members,shapes);actual=[gap.pose(cog,m['transform']) for m in p['members']];bad=[];minimum=math.inf
        for i,j in itertools.combinations(range(15),2):
            d=actual[i].distance(actual[j]);minimum=min(minimum,d)
            if not actual[i].disjoint(actual[j]) or d<job['clearance']:bad.append({'pair':[i,j],'distance':d,'overlap_area':actual[i].intersection(actual[j]).area})
        patterns[p['id']]=p;results.append({'source_pair':pi,'contact_vector':[ux,uy],'contact_distance':length,'alignment_radians':align,'angles_radians':angles,'pitch_mm':pitch,'width_mm':p['width'],'height_mm':p['height'],'bounding_area_mm2':p['width']*p['height'],'pair_checks':105,'minimum_distance_mm':minimum,'violations':bad,'valid':not bad})
    write(OUT/'patterns.json',patterns);write(OUT/'result.json',{'cases':results,'full_target_witness':False,'native_packing_calls':0});print(json.dumps(results),flush=True)
if __name__=='__main__':main()
