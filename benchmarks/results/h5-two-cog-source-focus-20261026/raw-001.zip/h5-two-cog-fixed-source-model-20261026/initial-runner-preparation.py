"""Create a distinct one-shot runner for the audited two-cog focus."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];src=ROOT/'output/run_h5_bounded_source_search.py';dest=ROOT/'output/run_h5_two_cog_fixed_source_search.py'
s=src.read_text(encoding='utf-8')
changes={
    'h5-bounded-source-search-20261026':'h5-two-cog-fixed-source-search-20261026',
    'h5-bounded-source-model-20261026':'h5-two-cog-fixed-source-model-20261026',
    "checked['all_original_full_guarded_source_clauses_equivalent']":"checked['all_original_full_guarded_pair_clauses_areas_counts_and_domains_retained']",
    "'transformation.json'":"'restriction.json'",
    '376363':'382735',
    "'mandatory_moving_originals':9,'fixed_originals':57":"'mandatory_moving_originals':5,'fixed_originals':61,'fixed_cog_coordinate_pairs':4",
    'One distinct complete-source-clause model, with all394 pair modes, exact four-corner bound simplification, proved original domain/capacity exclusions and 72 advisory hints.':'One distinct focus of the complete-source-clause model: all parent variables/constraints/hints are unchanged, eight coordinate equalities fix original cogs54/57/58/62, and6364 independently proved empty conditional domain flags are forbidden. Original cogs64/65, both brackets and insert remain mandatory and movable.',
    'All66 originals mandatory; nine movable in original inward integer domains/recorded angles and57 fixed.':'All66 originals mandatory; five movable in original inward integer domains/recorded angles and61 fixed. No single-cog conditional exclusion is used.',
    'a negative remains conditional on the original source-angle/inward-grid/fixed-57 construction.':'a negative remains conditional on the parent copy ordering, original source angles/inward domains and fixed61; it is not a global packing impossibility proof.',
    'The prior full181160-variable call remains closed; this formulation adds all proved domain/capacity exclusions, copy ordering, exact bounds and advisory six-cog hints derived since that call.':'All prior calls remain closed. This is a new five-mover focus, not a continuation, retry or reseed of a completed call.',
    'Full original guarded pair relations, all66 originals mandatory, nine moving with source angles/inward integer domains,57 fixed.':'Full original guarded pair relations, all66 originals mandatory, five moving with source angles/inward integer domains and61 fixed, with all parent constructive restrictions retained.',
    'One distinct full source-clause model using exact corner simplification and all proved original-domain/capacity constraints.':'One distinct two-cog focus after the complete region census and exact parent/restraint audit. Keep all66 originals, five movers and61 fixed originals; retain every parent source clause. No single-cog exclusion or completed solver is reused.',
}
for a,b in changes.items():assert a in s,a;s=s.replace(a,b)
compile(s,str(dest),'exec')
with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
out=ROOT/'output/h5-two-cog-fixed-source-model-20261026/runner-preparation.json'
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dest.relative_to(ROOT).as_posix(),'target_sha256':sha256(dest.read_bytes()).hexdigest(),'replacements':changes,'maximum_solver_calls':1,'solver_cap_seconds':45,'shared_import_audit_search_seconds':60,'shutdown_reserve_seconds':10},f,indent=2);f.write('\n')
print({'runner_prepared':str(dest),'solver_calls':0})
