"""Prepare the distinct two-second-sheet-cog region census, no search replay."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-two-cog-regions-20261026'
OUT.mkdir();records=[]
common={
    "PART=int(sys.argv[1]);assert PART in [4,7,8]":"PART=7;RELEASED=[7,8]",
    'h5-focused-other-regions-20261026':'h5-two-cog-regions-20261026',
    "f'release-{PART}'":"'release-7-8'",
    "[spec['parts'][2],spec['parts'][PART]]":"[spec['parts'][i] for i in [0,1,2,7,8]]",
    "list(range(16,20))":"list(range(20))",
    "p['part']!=PART":"p['part'] not in RELEASED",
    "len(six)==5":"len(six)==4",
    "'released_cog_part':PART":"'released_cog_parts':RELEASED",
    "'five_fixed_cog_positions'":"'four_fixed_cog_positions'",
    "moving_part=2 if q['family']=='insert' else PART":"moving_part=0 if q['family']=='bracket' else 2 if q['family']=='insert' else PART",
    "'released_cog_still_must_be_placed'":"'both_released_cogs_still_must_be_placed'",
    "'released_cog_still_required'":"'both_released_cogs_still_required'",
    "'all_exclusions_conditional_on_five_fixed_witness_poses'":"'all_exclusions_conditional_on_four_fixed_witness_poses'",
    "'conditional_on_five_fixed_positions'":"'conditional_on_four_fixed_positions'",
}
for kind in ['prove','audit']:
    src=ROOT/'output'/f'{kind}_h5_focused_other_regions.py';s=src.read_text(encoding='utf-8');changes={}
    for a,b in common.items():
        if a in s:s=s.replace(a,b);changes[a]=b
    if kind=='prove':
        a="'planned_queries':4";assert a in s;s=s.replace(a,"'planned_queries':20")
        begin=s.index("        'method':");end=s.index("})\n    completed",begin)
        s=s[:begin]+"        'method':'Distinct complete source-region census with original cogs64/65 both released and original cogs54/57/58/62 plus57 source originals fixed. Both brackets28/29,insert50 and both released cogs are mandatory (five movers,61 fixed originals). All20 original queries and3523 inward domains are examined with exact rational clipping, unchanged source orientations and full guarded clauses. Both released cogs follow all four retained cog indices, so their moving-versus-fixed source clauses and domains are identical and represented once; they remain two separate mandatory parts in any model. Bracket copy domains are likewise identical. Preserve all boundaries, lines and points and correct original pair direction. Never reuse single-cog conditional exclusions. Offline60-second preparation is not production qualification. No solver/native call.'"+s[end:]
    else:
        a="plan['released_cog_part']==PART";assert a in s;s=s.replace(a,"plan['released_cog_parts']==RELEASED")
        a="==result['planned_domains']==1105";assert a in s;s=s.replace(a,"==result['planned_domains']==3523")
        a="assert sum(s['planned_domains'] for s in summaries if s['family']=='insert')==338";assert a in s;s=s.replace(a,"assert sum(s['planned_domains'] for s in summaries if s['family']=='bracket')==2418 and sum(s['planned_domains'] for s in summaries if s['family']=='insert')==338")
        s=s.replace('all1105_insert_and_cog_domains_examined','all3523_original_domains_examined').replace('all4_queries_and1105_original_domains_replayed','all20_queries_and3523_original_domains_replayed')
        s=s.replace('Residuals are complete conditional original insert/cog regions with five cogs fixed. Source pair direction is preserved. They do not place both brackets, the insert and the released cog together or establish a66-original target layout.','Residuals are complete conditional original bracket/insert/cog regions with four cogs fixed and original cogs64/65 released. Both released cogs have identical source domains and original pair direction against the four earlier fixed cogs. Both remain separate mandatory parts. These regions do not establish simultaneous placement of the five movers or a66-original target.')
        s=s.replace('Empty real domains certify no insert/cog anchor only with the five selected cog poses fixed','Empty real domains certify no corresponding original-part anchor only with the four selected cog poses fixed')
    s=s.replace('conditional on six verified cog poses','conditional on four verified cog poses')
    dest=ROOT/'output'/f'{kind}_h5_two_cog_regions.py'
    compile(s,str(dest),'exec')
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dest.relative_to(ROOT).as_posix(),'target_sha256':sha256(dest.read_bytes()).hexdigest(),'common_replacements':changes})
with (OUT/'helper-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'helpers':records,'released_parts':[7,8],'released_originals':[64,65],'mandatory_originals':66,'distinct_preparation':True,'solver_calls':0},f,indent=2);f.write('\n')
with (OUT/'budget.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':60,'deadline_perf_counter':time.perf_counter()+60,'solver_calls':0,'offline_not_production_qualification':True},f,indent=2);f.write('\n')
print({'prepared':str(OUT),'helpers':2},flush=True)
