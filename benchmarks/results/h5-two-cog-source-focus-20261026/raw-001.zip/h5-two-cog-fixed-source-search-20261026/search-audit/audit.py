"""Read the one closed focused call; do not rerun a negative search."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-two-cog-fixed-source-search-20261026';RUN=BASE/'shared-search';PREP=ROOT/'output/h5-two-cog-fixed-source-model-20261026';OUT=BASE/'search-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in RUN.rglob('*') if p.is_file()},'method':'Read the single completed focused search, verify exact audited model/input hashes, all parameters, sole-opened-call record, elapsed budget and absence of any positive candidate. Preserve the INFEASIBLE response as a solver negative for this conditional constructive model; no independent negative proof or unrestricted impossibility is claimed. No solver/native invocation.'})
    for p in [RUN/'plan.json',RUN/'solve/plan.json',PREP/'audit/plan.json']:
        for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h
    audited=load(PREP/'audit/checks.json');assert audited['passed'] and audited['exact_parent_restored']
    result=load(RUN/'result.json');solved=load(RUN/'solve/result.json');actual=load(RUN/'solve/model-audit.json');opened=load(RUN/'solve/opened.json');budget=load(RUN/'budget.json')
    assert actual['passed'] and actual['mandatory_moving_originals']==5 and actual['fixed_originals']==61 and actual['fixed_cog_coordinate_pairs']==4 and actual['required_originals']==66
    assert digest(RUN/'solve/model.pb')==digest(PREP/'model.pb')==audited['model_sha256']==actual['model_sha256']==opened['model_sha256']
    assert digest(RUN/'solve/parameters.pbtxt')==actual['parameters_sha256']
    params=text_format.Parse((RUN/'solve/parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());expected=sat_parameters_pb2.SatParameters(max_time_in_seconds=min(45,actual['remaining_shared_budget_at_parameter_set']),num_search_workers=8,random_seed=0,cp_model_presolve=True,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False);assert params==expected and params.max_time_in_seconds==opened['seconds_limit']
    assert budget['shared_seconds']==60 and budget['solver_cap_seconds']==45 and budget['solver_shutdown_reserve_seconds']==10 and budget['deadline_perf_counter']==budget['start_perf_counter']+60
    assert result['solver_calls_opened']==solved['solver_calls']==opened['maximum_solver_calls']==1 and result['stage']['exit_code']==0 and result['status']=='MASTER_INFEASIBLE' and solved['status']=='INFEASIBLE'
    assert not solved['has_full_guarded_source_candidate'] and not (RUN/'solve/selection.json').exists() and not (RUN/'solve/original-positions.json').exists()
    assert solved['seconds']+actual['loading_seconds']+actual['audit_seconds']<=result['stage']['seconds']<=result['elapsed_seconds']<60 and solved['seconds']<45
    checks={'passed':True,'seconds':time.perf_counter()-start,'terminal_status':solved['status'],'actual_solver_seconds':solved['seconds'],'actual_shared_seconds':result['elapsed_seconds'],'shared_budget_seconds':60,'solver_cap_seconds':45,'all_parameters_and_actual_model_verified':True,'solver_calls':1,'completed_call_closed_no_retry':True,'mandatory_moving_originals':5,'fixed_originals':61,'required_originals':66,'all_parent_source_clauses_and_constructive_restrictions_retained':True,'independent_negative_proof_claimed':False,'unrestricted_impossibility_claimed':False,'full_guarded_source_candidate':False,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
