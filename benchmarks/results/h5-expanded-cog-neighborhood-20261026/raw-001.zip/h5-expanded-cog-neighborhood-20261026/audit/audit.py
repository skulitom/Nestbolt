"""Independent 54-fixed inventory, sequential obstacle subtraction and partial readback."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from collections import Counter
from itertools import combinations,product
import json,time,shutil,math,traceback
from shapely.geometry import shape,Polygon,Point,box
from shapely.affinity import affine_transform,translate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-expanded-cog-neighborhood-20261026';OLD=ROOT/'output/h5-guarded-source-adjustment-20261025/original-regions';SRC=ROOT/'output/h5-source-orientation-construction-20261025';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in list(BASE.glob('*.json'))+list((BASE/'queries').glob('*.json'))+[JOB]},'method':'Verify every immutable input against committed source archives and all reused obstacle/profile bytes against the prior independent100-obstacle audit. Reconstruct exact66 identity/copy/shape inventory and all54 unchanged fixed transforms from original polygons, including cutouts; independently recalculate fixed area charges. Rebuild each of20 new free regions by sequentially subtracting translated cached obstacles in reverse owner order, rather than subtracting their union. Verify stock bounds, source-relative comparisons, recorded9 prior anchor memberships and the actual63-original partial against all native pair/stock guards. Preserve any prior anchor excluded by constructive clearance or grid; this is not full target qualification. No solver or native call.'})
    known=set()
    for name in ['h5-guarded-source-adjustment-20261025','h5-full-original-joint-20261025','h5-one-sided-conflict-propagation-20261026','h5-source-area-and-direction-sharing-20261026']:
        m=load(ROOT/'benchmarks/results'/name/'raw-manifest.json');known.update(r['sha256'] for r in m['files']+m['aliases'])
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h and h in known,n
    assert digest(JOB) in known
    audited=load(OLD/'audit/plan.json')['input_hashes'];oldcheck=load(OLD/'audit/checks.json');assert oldcheck['passed'] and oldcheck['all100_obstacles_verified'] and oldcheck['certified_envelope_contains_radius_mm']==.2125
    for p in [OLD/'profiles.json',OLD/'clearance-envelope.json']+sorted((OLD/'obstacles').glob('*.json')):assert digest(p)==audited[p.relative_to(ROOT).as_posix()],p
    result=load(BASE/'result.json');assert result['queries_completed']==20 and not load(BASE/'pending-queries.json')
    profiles=load(BASE/'profiles.json');assert profiles==load(OLD/'profiles.json')
    items=load(SRC/'items.json');parts=plan['parts'];oldfixed=load(OLD/'adjusted-fixed-originals.json');fixed=load(BASE/'fixed-originals.json');released=load(BASE/'released-originals.json');release={53,56,61}
    assert fixed==[r for r in oldfixed if r['item'] not in release] and released==[r for r in oldfixed if r['item'] in release]
    assert len(fixed)==54 and len(parts)==12 and [p['part'] for p in parts]==list(range(12)) and [p['index'] for p in parts]==sorted(p['index'] for p in parts)
    assert set(p['index'] for p in parts)|{r['item'] for r in fixed}==set(range(66)) and set(p['index'] for p in parts).isdisjoint(r['item'] for r in fixed)
    assert Counter([r['family'] for r in fixed]+[p['family'] for p in parts])==plan['required_original_counts']=={'frame':18,'bracket':12,'insert':21,'cog':15}
    job=load(JOB);families={r['id']:r for r in job['parts']};areas=load(SRC/'propagation.json')['part_areas'];stockq=load(SRC/'geometry.json')['stock_bounds_rational'];stocks=[[float(F(*v)) for v in s] for s in stockq];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05)
    assert job['clearance']==.2 and plan['construction_clearance_mm']==.2125 and plan['extra_stock_margin_mm']==.0125 and plan['clearance_envelope_extra_mm']==.0001
    for p in parts:
        original=items[p['index']];assert p['family']==original['family'] and p['copy']==original['copy'] and p['allowed_modes']==original['allowed_modes']
        assert p['queries']==[q['index'] for q in plan['queries'] if q['family']==p['family'] and q['mode'] in p['allowed_modes']]
    expectedareas=[sum(areas[r['family']]['lower_units'] for r in fixed if r['sheet']==s) for s in [0,1]];assert expectedareas==plan['fixed_original_area_units_per_sheet']==[3681713590,249662718]
    records=[];reconstruction=0.;holecount=holevertices=0
    def polygon(family,t,holes=False):
        g=families[family]['geometry'][0];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
        return affine_transform(Polygon(g['outer'],g.get('holes',[]) if holes else []),[m*c,-s,m*s,c,*t['translation']])
    for r in fixed+released:
        assert r['family']==items[r['item']]['family'];p=polygon(r['family'],r['transform']);error=p.hausdorff_distance(shape(r['geometry']));assert error<1e-7;reconstruction=max(reconstruction,error)
        cut=polygon(r['family'],r['transform'],True);g=families[r['family']]['geometry'][0];assert cut.is_valid and len(cut.interiors)==len(g.get('holes',[]));holecount+=len(cut.interiors);holevertices+=sum(len(h) for h in g.get('holes',[]))
        records.append({'item':r['item'],'family':r['family'],'sheet':r['sheet'],'poly':p,'fixed':r['item'] not in release})
    local={(c['fixed_style'],c['moving_profile']):shape(load(OLD/'obstacles'/f"{c['index']:03d}.json")['expanded_forbidden']) for c in plan['cache_cases']};assert len(local)==100
    qchecks=[];regions={};summary=load(BASE/'query-summary.json')
    for q in plan['queries']:
        i=q['index'];row=load(BASE/'queries'/f'{i:03d}.json');assert row['query']==q
        profile=profiles[q['profile']];st=[F(*v) for v in stockq[q['sheet']]];b=[F(v) for v in profile['bounds']];extra=F(1,80);cont=[st[0]-b[0]+extra,st[1]-b[1]+extra,st[2]-b[2]-extra,st[3]-b[3]-extra];assert [[v.numerator,v.denominator] for v in cont]==q['continuous_bounds_rational'];bounds=[math.ceil(cont[0]*1000),math.ceil(cont[1]*1000),math.floor(cont[2]*1000),math.floor(cont[3]*1000)];assert bounds==q['anchor_bounds_units1000']
        owners=[r for r in fixed if r['sheet']==q['sheet']];assert row['fixed_items']==[r['item'] for r in owners] and len(owners)==(47 if q['sheet']==0 else 7)
        stock=box(*(v/1000 for v in bounds));assert shape(row['original_stock_anchor_rectangle']).equals(stock);free=stock
        for r in reversed(owners):free=free.difference(translate(local[(r['style'],q['profile'])],*r['transform']['translation']))
        saved=shape(row['free_region']);regions[i]=saved;hd=free.hausdorff_distance(saved);sd=free.symmetric_difference(saved).area;assert saved.is_valid and free.is_empty==saved.is_empty==row['empty'] and hd<1e-6 and sd<1e-4 and stock.covers(saved),(i,hd,sd)
        oldregion=shape(load(OLD/'queries'/f'{i:03d}.json')['free_region']);lost=oldregion.difference(saved);added=saved.difference(oldregion);assert lost.area==row['old_region_lost_area_mm2']==summary[i]['old_region_lost_area_mm2'] and saved.covers(oldregion)==row['old_free_region_exactly_covered'];assert added.area==row['additional_free_area_mm2']
        if q['sheet']==1:assert saved.equals(oldregion) and lost.is_empty and added.is_empty
        qchecks.append({'query':i,'sheet':q['sheet'],'fixed_originals':len(owners),'sequential_subtraction_hausdorff_error_mm':hd,'sequential_subtraction_symmetric_difference_mm2':sd,'old_region_exactly_covered':saved.covers(oldregion),'old_region_lost_geometry_type':lost.geom_type,'old_region_lost_area_mm2':lost.area,'additional_anchor_area_mm2':added.area})
    anchors=load(BASE/'prior-partial-anchor-membership.json');assert len(anchors)==9
    witness=load(ROOT/'output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic/audit/six-cog-positions.json')
    for r in witness:
        p=profiles[r['profile']];x,y=r['x_units']/1000,r['y_units']/1000;c,s=math.cos(p['rotation_radians']),math.sin(p['rotation_radians']);cx,cy=p['original_center'];t={'rotation_radians':p['rotation_radians'],'mirrored':False,'translation':[x-c*cx+s*cy,y-s*cx-c*cy]};poly=polygon('cog',t);assert poly.hausdorff_distance(translate(shape(p['geometry']),x,y))<1e-7;records.append({'item':r['item'],'family':'cog','sheet':r['sheet'],'poly':poly,'fixed':False})
    for a in anchors:
        region=regions[a['query']];assert region.covers(Point(a['anchor_mm']))==a['continuous_anchor_in_free_region'];units=a['grid_anchor_units1000'];assert region.covers(Point(units[0]/1000,units[1]/1000))==a['grid_anchor_in_free_region']
        for n in a.get('local_3x3_grid_membership',[]):u=n['anchor_units1000'];assert region.covers(Point(u[0]/1000,u[1]/1000))==n['in_free_region']
    assert len(records)==63 and set(r['item'] for r in records)==set(range(66))-{28,29,50}
    pairs=[];stockchecks=[]
    for a,b in combinations(records,2):
        if a['sheet']!=b['sheet']:continue
        distance=a['poly'].distance(b['poly']);overlap=a['poly'].intersection(b['poly']).area;assert overlap==0 and distance>gap,(a['item'],b['item'],distance)
        pairs.append({'items':[a['item'],b['item']],'gap_mm':distance,'intersection_mm2':overlap,'both_retained_fixed':a['fixed'] and b['fixed']})
    for r in records:
        b=r['poly'].bounds;st=stocks[r['sheet']];margins=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(margins)>guard;stockchecks.append({'item':r['item'],'margins_mm':margins})
    write(OUT/'query-checks.json',qchecks);write(OUT/'prior63-pair-checks.json',pairs);write(OUT/'prior63-stock-checks.json',stockchecks)
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_input_files_verified':len(plan['inputs'])+1,'fixed_originals':54,'mandatory_moving_originals':12,'required_originals':66,'source_profiles_unchanged':10,'previously_independently_certified_obstacles_reused':100,'free_queries_independently_rebuilt':20,'old_free_queries_exactly_covered':sum(r['old_region_exactly_covered'] for r in qchecks),'maximum_old_region_lost_area_mm2':max(r['old_region_lost_area_mm2'] for r in qchecks),'maximum_sequential_free_region_hausdorff_error_mm':max(r['sequential_subtraction_hausdorff_error_mm'] for r in qchecks),'maximum_original_reconstruction_error_mm':reconstruction,'retained_fixed_pair_checks':sum(p['both_retained_fixed'] for p in pairs),'prior63_original_pair_checks':len(pairs),'prior63_stock_edges_checked':4*len(stockchecks),'minimum_prior63_pair_gap_mm':min(p['gap_mm'] for p in pairs),'native_guarded_pair_gap_mm':gap,'old63_partial_original_geometry_still_valid':True,'original_source_anchors_outside_constructive_regions':[a['item'] for a in anchors if not a['continuous_anchor_in_free_region']],'nearest_grid_anchors_outside_constructive_regions':[a['item'] for a in anchors if not a['grid_anchor_in_free_region']],'all54_fixed_transforms_unchanged':True,'fixed_area_charges_recomputed':True,'no_old_fixed57_conditional_exclusions_carried_over':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
