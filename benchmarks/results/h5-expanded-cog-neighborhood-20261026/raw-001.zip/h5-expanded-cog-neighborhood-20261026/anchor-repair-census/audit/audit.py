"""Independent complete local census and actual63-original geometry validation."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
from collections import Counter
import json,math,time,shutil,traceback
from shapely.geometry import Polygon,Point,shape
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-expanded-cog-neighborhood-20261026';RUN=BASE/'anchor-repair-census';OUT=RUN/'audit';SRC=ROOT/'output/h5-source-orientation-construction-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in list(RUN.glob('*')) if p.is_file()},'additional_inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [JOB,SRC/'items.json',SRC/'geometry.json']},'method':'Read every candidate/pair/triple and independently evaluate all raw integer source planes, point membership and exact ranking. Reconstruct all63 original filled-outer and cutout polygons from job vertices and selected integer anchors/unchanged54 transforms. Check all same-sheet distances, intersections, stock edges, counts/copies and all22 selected cog-pair source relations. Preserve the original item53 anchor exclusion and record only the three local grid adjustments. No solver/native call or complete66-part target claim.'})
    for n,h in load(RUN/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    assert load(BASE/'audit/checks.json')['passed'];source=load(SOURCE/'mutual/081.json');points=load(RUN/'point-checks.json');pairs=load(RUN/'source-pair-checks.json');triples=load(RUN/'complete729-triples.json');membership={r['item']:r for r in load(BASE/'prior-partial-anchor-membership.json')};region=shape(load(BASE/'queries/018.json')['free_region'])
    lookup={};inequalities=0
    for r in pairs:
        a,b=r['anchors_units1000'];dx,dy=[v-u for u,v in zip(a,b)];assert r['difference_units1000']==[dx,dy];slacks=[]
        for face in source['faces']:
            vals=[h['a']*dx+h['b']*dy-h['bound'] for h in face['outside_halfplanes']];slacks.append(max(vals));inequalities+=len(vals)
        bad=[i for i,v in enumerate(slacks) if v<0];assert bad==r['failed_faces'] and r['passed']==(not bad) and min(slacks)==r['minimum_best_edge_slack']
        key=tuple(r['items'])+(tuple(a),tuple(b));assert key not in lookup;lookup[key]=not bad
    assert len(pairs)==358 and inequalities==973760
    eligible={};costs={};bykey={}
    for p in points:
        item,k=p['item'],p['candidate_index'];m=membership[item];expected=m['local_3x3_grid_membership'][k]['anchor_units1000'];assert p['xy']==expected
        inside=region.covers(Point(expected[0]/1000,expected[1]/1000));conflicts=[]
        for w in membership.values():
            if w['kind']!='existing six-cog witness' or w['query']!=18:continue
            a,b=sorted([(item,expected),(w['item'],w['grid_anchor_units1000'])]);key=(a[0],b[0],tuple(a[1]),tuple(b[1]));assert key in lookup
            if not lookup[key]:conflicts.append(w['item'])
        assert inside==p['inside_free_region'] and sorted(conflicts)==sorted(p['conflicting_witness_items']);eligible[(item,k)]=inside and not conflicts;assert p['eligible']==eligible[(item,k)]
        cost=sum((F(u,1000)-F(v))**2 for u,v in zip(expected,m['anchor_mm']));assert [cost.numerator,cost.denominator]==p['squared_shift_mm2_rational'];costs[(item,k)]=cost;bykey[(item,k)]=p
    assert set(bykey)==set(product([53,56,61],range(9)));feasible=[]
    for indices,row in zip(product(range(9),repeat=3),triples):
        assert list(indices)==row['indices'];chosen=[bykey[(i,k)] for i,k in zip([53,56,61],indices)];badp=[p['item'] for p in chosen if not eligible[(p['item'],p['candidate_index'])]];badpairs=[]
        for a,b in combinations(chosen,2):
            if not lookup[(a['item'],b['item'],tuple(a['xy']),tuple(b['xy']))]:badpairs.append([a['item'],b['item']])
        ok=not badp and not badpairs;cost=sum(costs[(i,k)] for i,k in zip([53,56,61],indices));assert row['passed']==ok and row['invalid_point_items']==badp and row['invalid_pairs']==badpairs and row['total_squared_shift_mm2_rational']==[cost.numerator,cost.denominator]
        if ok:feasible.append((cost,indices))
    assert len(triples)==729 and len(feasible)==54
    chosen=load(RUN/'selected-nine-cog-anchors.json');best=min(feasible);assert chosen['selected_candidate_indices']==list(best[1]) and chosen['total_squared_shift_mm2_rational']==[best[0].numerator,best[0].denominator]
    anchors={r['item']:r for r in chosen['positions']};assert set(anchors)=={53,54,56,57,58,61,62,64,65}
    for item,r in anchors.items():
        if item in [53,56,61]:assert r['xy']==bykey[(item,best[1][[53,56,61].index(item)])]['xy']
        else:assert r['xy']==membership[item]['grid_anchor_units1000']
    job=load(JOB);families={r['id']:r for r in job['parts']};items=load(SRC/'items.json');profile=load(BASE/'profiles.json')[9];fixed={r['item']:r for r in load(BASE/'fixed-originals.json')};stocks=[[float(F(*v)) for v in b] for b in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);geos={};records=[];placements=[];holes=hole_vertices=0
    for i in sorted(set(fixed)|set(anchors)):
        family=items[i]['family'];g=families[family]['geometry'][0]
        if i in fixed:t=fixed[i]['transform'];sheet=fixed[i]['sheet']
        else:
            r=anchors[i];sheet=r['sheet'];x,y=[u/1000 for u in r['xy']];c,s=math.cos(profile['rotation_radians']),math.sin(profile['rotation_radians']);cx,cy=profile['original_center'];t={'rotation_radians':profile['rotation_radians'],'mirrored':False,'translation':[x-c*cx+s*cy,y-s*cx-c*cy]}
        c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;matrix=[m*c,-s,m*s,c,*t['translation']];poly=affine_transform(Polygon(g['outer']),matrix);cut=affine_transform(Polygon(g['outer'],g.get('holes',[])),matrix);assert poly.is_valid and cut.is_valid and len(cut.interiors)==len(g.get('holes',[])) and cut.exterior.equals(poly.exterior)
        if i in fixed:assert poly.hausdorff_distance(shape(fixed[i]['geometry']))<1e-7
        geos[i]=poly;records.append({'item':i,'family':family,'copy':items[i]['copy'],'sheet':sheet,'fixed':i in fixed});placements.append({'part_id':family,'copy_index':items[i]['copy'],'sheet_id':f'sheet-{sheet}','transform':t});holes+=len(cut.interiors);hole_vertices+=sum(len(h) for h in g.get('holes',[]))
    assert len(records)==63 and set(geos)==set(range(66))-{28,29,50} and Counter(r['family'] for r in records)=={'frame':18,'bracket':10,'insert':20,'cog':15}
    allpairs=[];stockchecks=[];sourcepairs=0
    for a,b in combinations(records,2):
        if a['sheet']!=b['sheet']:continue
        distance=geos[a['item']].distance(geos[b['item']]);overlap=geos[a['item']].intersection(geos[b['item']]).area;assert overlap==0 and distance>gap,(a['item'],b['item'],distance);allpairs.append({'items':[a['item'],b['item']],'distance_mm':distance,'intersection_mm2':overlap})
        if a['item'] in anchors and b['item'] in anchors:
            aa,bb=anchors[a['item']],anchors[b['item']];assert lookup[(a['item'],b['item'],tuple(aa['xy']),tuple(bb['xy']))];sourcepairs+=1
    for r in records:
        b=geos[r['item']].bounds;st=stocks[r['sheet']];margins=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(margins)>guard;stockchecks.append({'item':r['item'],'extra_margins_mm':margins})
    assert sourcepairs==22 and len(allpairs)==1467
    shifts=[{'item':i,'from_anchor_mm':membership[i]['anchor_mm'],'to_anchor_units1000':anchors[i]['xy'],'shift_mm':[u/1000-v for u,v in zip(anchors[i]['xy'],membership[i]['anchor_mm'])]} for i in [53,56,61]]
    write(OUT/'verified-nine-cog-anchors.json',chosen);write(OUT/'partial63-placements.json',placements);write(OUT/'original-pair-checks.json',allpairs);write(OUT/'original-stock-checks.json',stockchecks);write(OUT/'three-anchor-shifts.json',shifts)
    checks={'passed':True,'seconds':time.perf_counter()-start,'candidate_points_verified':27,'all729_triples_verified':True,'feasible_partial_triples':54,'exact_minimum_shift_ranking_verified':True,'source_pair_rows_verified':len(pairs),'source_inequalities_verified':inequalities,'selected_source_cog_pairs_verified':sourcepairs,'original_parts_in_partial':63,'fixed_originals':54,'moving_cog_originals':9,'missing_required_originals':[28,29,50],'original_cutouts_preserved':holes,'original_cutout_vertices_preserved':hole_vertices,'original_pair_checks':len(allpairs),'stock_edges_checked':4*len(stockchecks),'minimum_pair_gap_mm':min(r['distance_mm'] for r in allpairs),'native_guarded_pair_gap_mm':gap,'maximum_anchor_axis_shift_mm':max(abs(x) for r in shifts for x in r['shift_mm']),'original_item53_constructive_exclusion_preserved':True,'all_fixed54_transforms_unchanged':True,'all_previous_six_witness_positions_unchanged':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
