"""Complete the declared3x3 grid census for the three released source anchors."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,combinations
from fractions import Fraction as F
import json,time,shutil,traceback
from shapely.geometry import shape,Point
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-expanded-cog-neighborhood-20261026';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';WIT=ROOT/'output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic/audit/six-cog-positions.json';OUT=BASE/'anchor-repair-census'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'census.py');start=time.perf_counter();assert load(BASE/'audit/checks.json')['passed']
    inputs=[BASE/n for n in ['plan.json','profiles.json','fixed-originals.json','released-originals.json','prior-partial-anchor-membership.json','audit/checks.json','queries/018.json']]+[SOURCE/'mutual/081.json',WIT]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_limit_seconds':60,'released_original_items':[53,56,61],'candidate_points_per_original':9,'complete_combinations':729,'method':'Inspect only the nine declared nearest-grid-plus/minus1micrometre points for each released cog. Keep the six prior witness cog anchors fixed for this partial representability check. Independently evaluate each point against the expanded54-fixed free region and every same-sheet full original cog/cog source clause; precompute every candidate-pair relation, then enumerate all729 triples. If any passes, select minimum exact squared shift from the original continuous source anchors. Preserve every rejected point/pair/triple. This is a63-original partial missing two brackets and one insert; all12 movers remain mandatory in future complete searches. No solver, native call, broader search, production or target acceptance.'})
    profile=load(BASE/'profiles.json')[9];spec=load(BASE/'plan.json');assert all(p['profiles']==[9] for p in spec['parts'] if p['family']=='cog');source=load(SOURCE/'mutual/081.json');assert source['case']=={'index':81,'profile_a':9,'profile_b':9};faces=source['faces'];region=shape(load(BASE/'queries/018.json')['free_region'])
    fixed=[{'item':r['item'],'sheet':r['sheet'],'xy':[r['x_units'],r['y_units']]} for r in load(WIT)];membership=load(BASE/'prior-partial-anchor-membership.json');candidates={};point_rows=[];pair_rows=[];face_tests=inequality_tests=0
    def pair(a,b):
        nonlocal face_tests,inequality_tests
        if a['item']>b['item']:a,b=b,a
        x,y=[v-u for u,v in zip(a['xy'],b['xy'])];fail=[];slacks=[]
        for i,f in enumerate(faces):
            values=[h['a']*x+h['b']*y-h['bound'] for h in f['outside_halfplanes']];slacks.append(max(values));face_tests+=1;inequality_tests+=len(values)
            if max(values)<0:fail.append(i)
        return {'items':[a['item'],b['item']],'anchors_units1000':[a['xy'],b['xy']],'difference_units1000':[x,y],'failed_faces':fail,'minimum_best_edge_slack':min(slacks),'passed':not fail}
    for a,b in combinations(fixed,2):
        if a['sheet']==b['sheet']:
            r=pair(a,b);assert r['passed'];r['kind']='retained witness pair';pair_rows.append(r)
    for item in [53,56,61]:
        m=next(r for r in membership if r['item']==item);rows=[]
        for index,c in enumerate(m['local_3x3_grid_membership']):
            units=c['anchor_units1000'];inside=region.covers(Point(units[0]/1000,units[1]/1000));assert inside==c['in_free_region'];p={'item':item,'sheet':0,'xy':units,'candidate_index':index};conflicts=[]
            for a in fixed:
                if a['sheet']!=0:continue
                r=pair(p,a);r.update({'kind':'candidate versus retained witness','candidate_item':item,'candidate_index':index});pair_rows.append(r)
                if not r['passed']:conflicts.append(a['item'])
            shift=sum((F(u,1000)-F(x))**2 for u,x in zip(units,m['anchor_mm']));p.update({'inside_free_region':inside,'conflicting_witness_items':conflicts,'eligible':inside and not conflicts,'squared_shift_mm2_rational':[shift.numerator,shift.denominator]});rows.append(p);point_rows.append(p)
        candidates[item]=rows
    compat={}
    for ia,ib in combinations([53,56,61],2):
        for a,b in product(candidates[ia],candidates[ib]):
            r=pair(a,b);r.update({'kind':'released-candidate pair','candidate_indices':[a['candidate_index'],b['candidate_index']]});pair_rows.append(r);compat[(ia,a['candidate_index'],ib,b['candidate_index'])]=r['passed']
    triples=[];feasible=[]
    for indices in product(range(9),repeat=3):
        selected=[candidates[i][k] for i,k in zip([53,56,61],indices)];invalid_points=[r['item'] for r in selected if not r['eligible']];invalid_pairs=[[a['item'],b['item']] for a,b in combinations(selected,2) if not compat[(a['item'],a['candidate_index'],b['item'],b['candidate_index'])]];cost=sum(F(*r['squared_shift_mm2_rational']) for r in selected);ok=not invalid_points and not invalid_pairs
        triples.append({'indices':list(indices),'invalid_point_items':invalid_points,'invalid_pairs':invalid_pairs,'passed':ok,'total_squared_shift_mm2_rational':[cost.numerator,cost.denominator]})
        if ok:feasible.append((cost,indices,selected))
    assert len(triples)==729 and len(point_rows)==27 and len(compat)==243 and time.perf_counter()-start<60
    write(OUT/'point-checks.json',point_rows);write(OUT/'source-pair-checks.json',pair_rows);write(OUT/'complete729-triples.json',triples)
    if feasible:
        cost,indices,selected=min(feasible,key=lambda r:(r[0],r[1]));positions=sorted(fixed+[{'item':p['item'],'sheet':0,'xy':p['xy']} for p in selected],key=lambda p:p['item']);write(OUT/'selected-nine-cog-anchors.json',{'positions':positions,'selected_candidate_indices':list(indices),'total_squared_shift_mm2_rational':[cost.numerator,cost.denominator],'originals_in_partial':63,'missing_originals':[28,29,50],'not_a_full_target':True})
    result={'seconds':time.perf_counter()-start,'candidate_points_checked':len(point_rows),'eligible_points_by_item':{str(i):sum(r['eligible'] for r in rows) for i,rows in candidates.items()},'source_pairs_checked':len(pair_rows),'source_faces_checked':face_tests,'source_inequalities_checked':inequality_tests,'complete_triples_checked':len(triples),'feasible_partial_triples':len(feasible),'has_source_guarded63_partial_proposal':bool(feasible),'independent_original_geometry_audit_pending':bool(feasible),'all_original_solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
