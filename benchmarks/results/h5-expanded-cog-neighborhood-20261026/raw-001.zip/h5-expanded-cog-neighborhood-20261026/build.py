"""Fresh full-original free regions after releasing three neighboring fixed cogs."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
from itertools import combinations,product
import json,copy,shutil,time,math,traceback
from shapely.geometry import shape,mapping,box,Point
from shapely.affinity import translate
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-guarded-source-adjustment-20261025/original-regions';JOINT=ROOT/'output/h5-full-original-joint-prepared-20261025';SRC=ROOT/'output/h5-source-orientation-construction-20261025';OUT=ROOT/'output/h5-expanded-cog-neighborhood-20261026';RELEASE=[53,56,61]
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def vertices(g):
    if g.is_empty:return 0
    if g.geom_type=='Polygon':return len(g.exterior.coords)+sum(len(r.coords) for r in g.interiors)
    if hasattr(g,'geoms'):return sum(vertices(x) for x in g.geoms)
    return len(g.coords)
def main():
    OUT.mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+120
    assert load(OLD/'audit/checks.json')['passed']
    original=load(JOINT/'plan.json');oldfixed=load(OLD/'adjusted-fixed-originals.json');fixed=[r for r in oldfixed if r['item'] not in RELEASE];released=[r for r in oldfixed if r['item'] in RELEASE];items=load(SRC/'items.json');profiles=load(OLD/'profiles.json');queries=load(OLD/'plan.json')['queries'];aux=load(SRC/'propagation.json')
    assert len(fixed)==54 and len(released)==3 and all(r['sheet']==0 and r['family']=='cog' and r['transform']['rotation_radians']==profiles[9]['rotation_radians'] and not r['transform']['mirrored'] for r in released)
    byitem={r['index']:copy.deepcopy(r) for r in original['parts']}
    for r in released:byitem[r['item']]={**items[r['item']],'queries':[18,19],'profiles':[9]}
    parts=[]
    for item in sorted(byitem):parts.append({**byitem[item],'part':len(parts)})
    assert len(parts)==12 and set(byitem).isdisjoint({r['item'] for r in fixed}) and set(byitem)|{r['item'] for r in fixed}==set(range(66))
    assert Counter([r['family'] for r in fixed]+[r['family'] for r in parts])==original['required_original_counts']
    profilepairs=sorted({(a,b) for x,y in combinations(parts,2) for a,b in product(x['profiles'],y['profiles'])});mutual=[{'index':i,'profile_a':a,'profile_b':b} for i,(a,b) in enumerate(profilepairs)];assert mutual==original['mutual_cases']
    areas=[sum(aux['part_areas'][r['family']]['lower_units'] for r in fixed if r['sheet']==s) for s in [0,1]]
    paths=[OLD/n for n in ['plan.json','profiles.json','adjusted-fixed-originals.json','clearance-envelope.json','audit/checks.json']]+[JOINT/'plan.json',SRC/'items.json',SRC/'propagation.json',SRC/'geometry.json',ROOT/'output/h5-fixed-source-neighborhood-review-20261026/result.json',ROOT/'output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic/audit/six-cog-positions.json']+sorted((OLD/'obstacles').glob('*.json'))+sorted((OLD/'queries').glob('*.json'))
    plan={'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'construction_limit_seconds':120,'maximum_total_region_vertices':1000000,'released_fixed_items':RELEASE,'parts':parts,'queries':queries,'mutual_cases':mutual,'fixed_items':[r['item'] for r in fixed],'fixed_original_area_units_per_sheet':areas,'required_original_counts':original['required_original_counts'],'fixed_originals':54,'mandatory_moving_originals':12,'required_originals':66,'anchor_units_per_mm':1000,'original_clearance_mm':.2,'construction_clearance_mm':.2125,'clearance_envelope_extra_mm':.0001,'extra_stock_margin_mm':.0125,'cache_cases':load(OLD/'plan.json')['cache_cases'],'invalidated_fixed57_certificates':['old free regions and inward domains','old domain-conflict matrices','old regional cog capacities and occupancy exclusions','old source-region area capacities','old fixed-witness exclusions and source no-goods'],'method':'Release original cogs53/56/61 without changing their source angle or the other54 fixed transforms. All10 original profiles and100 previously independently certified polygonal obstacles remain exactly reusable because shape/orientation/clearance are unchanged. Subtract their translated envelopes for only the54 retained fixed originals from each of the20 unchanged stock anchor rectangles. Retain the whole free region without outward padding. Recompute all inventories and fixed area charges. Compare old free-region containment and inspect prior63-original continuous/nearest-grid anchor representability explicitly, preserving exclusions rather than asserting every old pose satisfies the stronger moving construction margins. No solver, accepted full layout, reuse of fixed57 conditional exclusions or claim of unrestricted coverage.'}
    write(OUT/'plan.json',plan);write(OUT/'profiles.json',profiles);write(OUT/'fixed-originals.json',fixed);write(OUT/'released-originals.json',released);shutil.copyfile(OLD/'clearance-envelope.json',OUT/'clearance-envelope.json')
    local={}
    for c in plan['cache_cases']:
        p=OLD/'obstacles'/f"{c['index']:03d}.json";row=load(p);assert all(row[k]==v for k,v in c.items());local[(c['fixed_style'],c['moving_profile'])]=shape(row['expanded_forbidden'])
    records=[];regions={};total=0
    for q in queries:
        if time.perf_counter()>=deadline or total>=1000000:break
        stock=box(*(v/1000 for v in q['anchor_bounds_units1000']));owners=[r for r in fixed if r['sheet']==q['sheet']];obstacles=unary_union([translate(local[(r['style'],q['profile'])],*r['transform']['translation']) for r in owners]);free=stock.difference(obstacles);assert free.is_valid;regions[q['index']]=free;oldregion=shape(load(OLD/'queries'/f"{q['index']:03d}.json")['free_region']);lost=oldregion.difference(free);added=free.difference(oldregion);n=vertices(free);total+=n
        write(OUT/'queries'/f"{q['index']:03d}.json",{'query':q,'fixed_items':[r['item'] for r in owners],'original_stock_anchor_rectangle':mapping(stock),'expanded_forbidden_union':mapping(obstacles),'free_region':mapping(free),'empty':free.is_empty,'geometry_type':free.geom_type,'area_mm2':free.area,'vertices':n,'old_free_region_exactly_covered':free.covers(oldregion),'old_region_lost_area_mm2':lost.area,'old_region_lost_geometry':mapping(lost),'additional_free_area_mm2':added.area})
        records.append({'query':q['index'],'family':q['family'],'sheet':q['sheet'],'fixed_obstacles':len(owners),'empty':free.is_empty,'free_area_mm2':free.area,'additional_free_area_mm2':added.area,'old_region_lost_area_mm2':lost.area,'old_free_region_exactly_covered':free.covers(oldregion),'vertices':n})
    write(OUT/'pending-queries.json',queries[len(records):]);write(OUT/'query-summary.json',records)
    prior=[]
    if len(records)==20:
        witness=load(ROOT/'output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic/audit/six-cog-positions.json')
        for r in witness:
            xy=[r['x_units']/1000,r['y_units']/1000];prior.append({'item':r['item'],'query':r['query'],'kind':'existing six-cog witness','anchor_mm':xy,'continuous_anchor_in_free_region':regions[r['query']].covers(Point(xy)),'grid_anchor_units1000':[r['x_units'],r['y_units']],'grid_anchor_in_free_region':regions[r['query']].covers(Point(xy))})
        center=profiles[9]['original_center'];angle=profiles[9]['rotation_radians'];c,s=math.cos(angle),math.sin(angle)
        for r in released:
            tx,ty=r['transform']['translation'];xy=[tx+c*center[0]-s*center[1],ty+s*center[0]+c*center[1]];grid=[round(v*1000) for v in xy];region=regions[18];near=[]
            for dx,dy in product([-1,0,1],repeat=2):
                units=[grid[0]+dx,grid[1]+dy];near.append({'anchor_units1000':units,'in_free_region':region.covers(Point(units[0]/1000,units[1]/1000))})
            prior.append({'item':r['item'],'query':18,'kind':'released original source pose','anchor_mm':xy,'continuous_anchor_in_free_region':region.covers(Point(xy)),'grid_anchor_units1000':grid,'grid_anchor_in_free_region':region.covers(Point(grid[0]/1000,grid[1]/1000)),'local_3x3_grid_membership':near})
        write(OUT/'prior-partial-anchor-membership.json',sorted(prior,key=lambda r:r['item']))
    result={'seconds':time.perf_counter()-start,'required_originals':66,'fixed_originals':54,'mandatory_moving_originals':12,'moving_counts':dict(Counter(r['family'] for r in parts)),'released_original_items':RELEASE,'source_profiles_reused':10,'certified_obstacle_files_reused':100,'queries_planned':20,'queries_completed':len(records),'queries_pending':20-len(records),'total_region_vertices':total,'fixed_original_area_units_per_sheet':areas,'original_source_partial_anchor_checks':len(prior),'prior_continuous_anchors_outside_constructive_free_regions':[r['item'] for r in prior if not r['continuous_anchor_in_free_region']],'prior_nearest_grid_anchors_outside_constructive_free_regions':[r['item'] for r in prior if not r['grid_anchor_in_free_region']],'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
