"""Independent actual-outline, inward-domain and outward-separation audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product,combinations
from collections import Counter
import json,math,shutil,time,traceback
import shapely
from shapely.geometry import shape,mapping,MultiPoint,Polygon
from shapely.geometry.polygon import orient
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-original-joint-prepared-20261025'
SOURCE=ROOT/'output/h5-guarded-source-adjustment-20261025';REG=SOURCE/'original-regions';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def triangles(poly):
    ts=list(shapely.constrained_delaunay_triangles(poly).geoms)
    assert ts and unary_union(ts).equals(poly);return ts
def check_planes(poly,rows,inside):
    pts=list(orient(poly,sign=1).exterior.coords);expected=[]
    for p,q in zip(pts,pts[1:]):
        x,y=map(F,p);u,v=map(F,q);a,b=v-y,x-u
        if not a and not b:continue
        norm=max(abs(a),abs(b));a/=norm;b/=norm;c=a*x+b*y
        A,B=round(a*10**7),round(b*10**7)
        err=abs(F(A)-a*10**7)*1500000+abs(F(B)-b*10**7)*3000000+1
        val=c*1000*10**7-err if inside else c*1000*10**7+err
        bound=math.floor(val) if inside else math.ceil(val)
        assert (F(bound)+err<=c*1000*10**7) if inside else (F(bound)-err>=c*1000*10**7)
        assert max(abs(bound),2*(abs(A)*1500000+abs(B)*3000000))<2**60
        expected.append({'edge':[list(p),list(q)],'a':A,'b':B,'bound':bound,'sense':'le' if inside else 'ge',
                         'coefficient_error_bound':[err.numerator,err.denominator]})
    assert expected==rows
    return len(rows)

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');spec=load(BASE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':180,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(BASE.rglob('*.json')) if OUT not in p.parents},
        'method':'Audit original source hashes against the committed prior evidence manifest; reconstruct all9 mandatory original identities, modes, sheets, counts and area charges. Check every raw allowed face, conservative inset, recorded discard, inward grid bound and exact rational halfplane coefficient-error rounding. Reconstruct all82 mutual full-original Minkowski obstacles from unmerged triangle pairs, and independently expand each raw-obstacle triangle by the whole certified128-gon envelope. Check every expanded forbidden convex face covers its raw face, their union covers the whole obstacle, and every outside inequality has exact sufficient outward rounding over the whole signed difference-coordinate domain. A constructive positive still requires original66-part geometry and native validation; negatives remain finite-angle/grid/region conditional.'})
    start=time.perf_counter()
    for n,h in spec['inputs'].items():assert digest(ROOT/n)==h
    manifest=load(ROOT/'benchmarks/results/h5-guarded-source-adjustment-20261025/raw-manifest.json')
    # Canonical and alias entries both retain their own byte size and hash.
    certified={r['path']:r['sha256'] for r in manifest['files']}
    for r in manifest.get('aliases',[]):certified[r['path']]=r['sha256']
    provenance=0
    for p in [REG/'plan.json',REG/'profiles.json',REG/'adjusted-fixed-originals.json',REG/'audit/checks.json',REG/'clearance-envelope.json',SOURCE/'audit/checks.json']+[REG/'queries'/f'{i:03d}.json' for i in range(20)]:
        assert certified[p.relative_to(ROOT/'output').as_posix()]==digest(p);provenance+=1
    assert load(SOURCE/'audit/checks.json')['passed'] and load(REG/'audit/checks.json')['passed']
    result=load(BASE/'result.json');assert result['queries_completed']==20 and result['mutual_cases_completed']==82
    assert not load(BASE/'pending-queries.json') and not load(BASE/'pending-mutual.json')
    profiles=load(BASE/'profiles.json');assert profiles==load(REG/'profiles.json') and profiles[9]['original_vertex_count']==80
    old=load(ROOT/'output/h5-conflict-owner-neighborhood-20261025/plan.json');fixed=load(REG/'adjusted-fixed-originals.json')
    assert spec['fixed_items']==old['fixed_items']==[r['item'] for r in fixed] and len(fixed)==57
    assert [p['index'] for p in spec['parts']]==[28,29,50,54,57,58,62,64,65]
    assert spec['queries']==load(REG/'plan.json')['queries']
    for i,(p,o) in enumerate(zip(spec['parts'],old['movable_parts'])):
        assert {k:p[k] for k in o}==o and p['part']==i
        qs=[q['index'] for q in spec['queries'] if q['family']==p['family'] and q['mode'] in p['allowed_modes']]
        assert p['queries']==qs and sorted(spec['queries'][q]['mode'] for q in qs)==p['allowed_modes']
        assert p['profiles']==sorted({spec['queries'][q]['profile'] for q in qs})
    assert Counter(r['family'] for r in fixed)+Counter(p['family'] for p in spec['parts'])==Counter(spec['required_original_counts'])
    aux=load(ROOT/'output/h5-source-orientation-construction-20261025/propagation.json')
    area=[sum(aux['part_areas'][r['family']]['lower_units'] for r in fixed if r['sheet']==s) for s in range(2)]
    assert area==spec['fixed_original_area_units_per_sheet']==[3831901744,249662718]
    assert sum(area)+sum(aux['part_areas'][p['family']]['lower_units'] for p in spec['parts'])==4481740770
    want=sorted({(a,b) for p,q in combinations(spec['parts'],2) for a,b in product(p['profiles'],q['profiles'])})
    assert spec['mutual_cases']==[{'index':i,'profile_a':a,'profile_b':b} for i,(a,b) in enumerate(want)] and len(want)==82
    qchecks=[];inside_count=0
    for q in spec['queries']:
        assert time.perf_counter()-start<180
        p=REG/'queries'/f"{q['index']:03d}.json";r=load(BASE/'queries'/p.name);src=load(p);region=shape(src['free_region'])
        assert r['query']==q and r['source_query_sha256']==spec['original_query_hashes'][str(q['index'])]==digest(p)
        rows=r['domains']+r['discarded_faces'];assert sorted(x['index'] for x in rows)==list(range(r['raw_faces']))
        raw_union=unary_union([shape(x['raw_face']) for x in rows]);missing=region.difference(raw_union)
        assert missing.equals(shape(r['raw_uncovered_geometry'])) and missing.area==r['raw_uncovered_area_mm2']
        assert raw_union.covers(region)==r['raw_union_covers_whole_region']
        for x in rows:
            raw=shape(x['raw_face']);assert raw.is_valid and raw.equals(raw.convex_hull)
            inset=raw.buffer(-.000001,join_style='mitre')
            if inset.is_empty:assert x['reason']=='empty conservative inset';continue
            assert shape(x['inset_face']).equals_exact(inset,0) and region.covers(inset) and inset.equals(inset.convex_hull)
            b=list(map(F,inset.bounds));bounds=[math.ceil(b[0]*1000),math.ceil(b[1]*1000),math.floor(b[2]*1000),math.floor(b[3]*1000)]
            assert bounds==x['coordinate_bounds']
            if bounds[0]>bounds[2] or bounds[1]>bounds[3]:assert x['reason']=='empty inward grid bounding box';continue
            assert 'reason' not in x and 0<=bounds[0]<=bounds[2]<=1500000 and 0<=bounds[1]<=bounds[3]<=3000000
            inside_count+=check_planes(inset,x['halfplanes'],True)
        qchecks.append({'query':q['index'],'raw_faces':len(rows),'domains':len(r['domains']),'discards':len(r['discarded_faces']),
                        'raw_whole_region_covered':raw_union.covers(region),'raw_uncovered_area_mm2':missing.area})
    write(OUT/'query-checks.json',qchecks)
    kv=load(REG/'clearance-envelope.json')['vertices'];K=Polygon(kv);assert len(kv)==128 and K.equals(K.convex_hull)
    rational=[list(map(F,v)) for v in kv]
    for a,b in zip(rational,rational[1:]+rational[:1]):
        nx,ny=b[1]-a[1],a[0]-b[0];c=nx*a[0]+ny*a[1]
        assert c>0 and c*c>=F(17,80)**2*(nx*nx+ny*ny)
        assert all(nx*x+ny*y<=c for x,y in rational)
    ts={p['index']:triangles(shape(p['geometry'])) for p in profiles};checks=[];outside_count=rawhulls=exphulls=0
    for case in spec['mutual_cases']:
        assert time.perf_counter()-start<180
        r=load(BASE/'mutual'/f"{case['index']:03d}.json");assert r['case']==case
        sums=[MultiPoint([(x-u,y-v) for x,y in list(a.exterior.coords)[:-1] for u,v in list(b.exterior.coords)[:-1]]).convex_hull for a,b in product(ts[case['profile_a']],ts[case['profile_b']])]
        raw=unary_union(sums);saved=shape(r['raw_forbidden']);hd=raw.hausdorff_distance(saved);ad=raw.symmetric_difference(saved).area
        assert hd<1e-7 and ad<1e-4
        expanded=[MultiPoint([(x+kx,y+ky) for x,y in list(t.exterior.coords)[:-1] for kx,ky in kv]).convex_hull for t in triangles(raw)]
        full=unary_union(expanded);stored=shape(r['expanded_forbidden']);ehd=full.hausdorff_distance(stored);ead=full.symmetric_difference(stored).area
        assert ehd<1e-7 and ead<1e-4 and stored.covers(saved)
        padded=[]
        assert [x['index'] for x in r['faces']]==list(range(len(r['faces'])))
        for face in r['faces']:
            f=shape(face['raw_face']);g=shape(face['expanded_face']);assert f.equals(f.convex_hull) and g.equals(g.convex_hull) and g.covers(f)
            expected=MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product(list(f.exterior.coords)[:-1],[(-.000001,-.000001),(-.000001,.000001),(.000001,.000001),(.000001,-.000001)])]).convex_hull
            assert g.equals(expected);outside_count+=check_planes(g,face['outside_halfplanes'],False);padded.append(g)
        union=unary_union(padded);assert union.covers(stored) and r['complete_forbidden_covered']
        # Independent reconstruction's floating error stays far below the explicit square pad.
        assert union.covers(full),(case,'independent full obstacle coverage')
        rawhulls+=len(sums);exphulls+=len(expanded)
        checks.append({**case,'raw_triangle_pair_hulls':len(sums),'expanded_triangle_hulls':len(expanded),'forbidden_faces':len(padded),
                       'raw_hausdorff_error_mm':hd,'expanded_hausdorff_error_mm':ehd,'complete_independent_obstacle_covered':True})
        if len(checks)%20==0:print({'mutual_audited':len(checks),'seconds':time.perf_counter()-start},flush=True)
    write(OUT/'mutual-checks.json',checks)
    summary={'passed':True,'seconds':time.perf_counter()-start,'committed_source_files_verified':provenance,'mandatory_moving_originals':9,'fixed_originals':57,
        'required_originals':66,'complete_query_count':20,'raw_allowed_faces':sum(q['raw_faces'] for q in qchecks),'accepted_allowed_domains':sum(q['domains'] for q in qchecks),
        'recorded_discarded_faces':sum(q['discards'] for q in qchecks),'allowed_inward_halfplanes':inside_count,'mutual_profile_cases':82,'physical_part_pairs':36,
        'raw_triangle_pair_hulls':rawhulls,'expanded_triangle_hulls':exphulls,'forbidden_convex_faces':sum(c['forbidden_faces'] for c in checks),
        'sufficient_outside_halfplanes':outside_count,'maximum_raw_hausdorff_error_mm':max(c['raw_hausdorff_error_mm'] for c in checks),
        'maximum_expanded_hausdorff_error_mm':max(c['expanded_hausdorff_error_mm'] for c in checks),'every_independent_whole_forbidden_region_covered':True,
        'all_original_counts_and_area_charges_preserved':True,'all_allowed_domain_bounds_round_inward':True,'all_signed_difference_separations_round_outward':True,
        'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',summary);print(summary,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
