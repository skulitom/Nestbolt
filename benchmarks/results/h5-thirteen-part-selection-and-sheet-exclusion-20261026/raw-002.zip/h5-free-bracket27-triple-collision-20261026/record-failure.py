"""Record why the former box certificate is not applicable to the fresh selection."""
from pathlib import Path
from hashlib import sha256
from math import isqrt
import json,shutil
from shapely.geometry import shape,box
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';RAW=ROOT/'output/h5-free-bracket27-domain-conflicts-20261026';BASE=ROOT/'output/h5-free-bracket27-triple-collision-20261026';OLD=ROOT/'output/h5-selected-triple-collision-certificate-20261026'
load=lambda p:json.loads(p.read_bytes());assert not (BASE/'certificate.json').exists() and not (BASE/'audit/checks.json').exists()
ib=load(SOURCE/'queries/016.json')['domains'][0]['coordinate_bounds'];cb=load(SOURCE/'queries/018.json')['domains'][3]['coordinate_bounds'];required=258082**2+1;delta=required-(cb[3]-cb[1])**2;sep=isqrt(delta)+(isqrt(delta)**2<delta);left=[cb[0],cb[1],cb[2]-sep,cb[3]];right=[cb[0]+sep,cb[1],cb[2],cb[3]];mid=(ib[0]+ib[2])//2;halves=[[ib[0],ib[1],mid,ib[3]],[mid+1,ib[1],ib[2],ib[3]]];core=shape(load(RAW/'cores/080.json')['core']);rows=[]
for side,(a,b) in enumerate(zip(halves,[left,right])):
    d=[b[0]-a[2],b[1]-a[3],b[2]-a[0],b[3]-a[1]];g=box(*(v/1000 for v in d));rows.append({'side':side,'difference_box_units':d,'whole_box_in_core':core.contains(g),'outside_core_area_mm2':g.difference(core).area})
assert not all(r['whole_box_in_core'] for r in rows);prior=load(OLD/'certificate.json');record={'passed':True,'builder_failure':'Whole-difference-box containment assertion failed. No certificate was written.','audit_failure':'Dependent auditor could not read the absent certificate. No passing audit exists.','fresh_insert_box':ib,'prior_insert_box':prior['insert_box_units1000'],'fresh_cog_box':cb,'prior_cog_box':prior['cog_box_units1000'],'current_box_checks':rows,'old_certificate_not_transferred':True,'conclusion':'The previous box proof does not establish this fresh tuple is impossible. This is not evidence of feasibility. Proceed to a separately audited exact-coordinate subproblem.','new_exclusions':0,'solver_calls':0}
with (BASE/'failure-record.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
shutil.copyfile(__file__,BASE/'record-failure.py');print(record)
