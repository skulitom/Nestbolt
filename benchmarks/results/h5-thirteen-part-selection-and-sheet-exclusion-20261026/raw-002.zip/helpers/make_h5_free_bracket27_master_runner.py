from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('run_h5_partial59_domain_master.py','run_h5_free_bracket27_domain_master.py'),('audit_h5_partial59_domain_selection.py','audit_h5_free_bracket27_domain_selection.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-partial59-','h5-free-bracket27-')
    s=s.replace('7937','21093').replace('2514','13536').replace('==16','==40').replace("'hints':16","'hints':40").replace('==1326','==7206').replace('==7','==13').replace("'moving_originals':7","'moving_originals':13").replace("'fixed_originals':59","'fixed_originals':53").replace(':588',':954')
    s=s.replace('7 mandatory domain choices','13 mandatory domain choices').replace('independently certified copy ordering and no inherited capacity','independently certified copy ordering and freshly rederived capacity2').replace('7 movers in59-fixed','13 movers in53-fixed')
    if old.startswith('audit'):
        s=s.replace("assert all(a<=b for a,b in zip(areas,rules['stock_area_upper_units']))", "assert all(a<=b for a,b in zip(areas,rules['stock_area_upper_units'])) and sum(p['family']=='cog' and p['sheet']==1 for p in parts)<=2")
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
