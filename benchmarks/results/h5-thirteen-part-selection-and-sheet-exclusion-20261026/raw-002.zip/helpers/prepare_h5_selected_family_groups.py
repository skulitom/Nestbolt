"""Only9 pair and36 triple subproblems changed by the new insert-domain choice."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';SELECT=ROOT/'output/h5-conditional-domain-master-search-20261026/selection-audit';PRIOR=ROOT/'output/h5-expanded-domain-master-search-20261026/selection-audit';OUT=ROOT/'output/h5-selected-family-groups-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();spec=load(SOURCE/'plan.json');selection=load(SELECT/'verified-domain-selection.json');parts=selection['movable_parts'];old=load(PRIOR/'verified-domain-selection.json')['movable_parts'];assert [i for i,(a,b) in enumerate(zip(parts,old)) if a!=b]==[2] and parts[2]['query']==16 and parts[2]['domain_row']==15;subsets=[[0, 3, 4, 5, 6, 7, 8, 9], [0, 1, 3, 4, 5, 6, 7, 8, 9], [2, 3, 4, 5, 6, 7, 8, 9], [0, 2, 3, 4, 5, 6, 7, 8, 9]];assert len(subsets)==4;paths=[SOURCE/'plan.json',SOURCE/'audit/checks.json',SELECT/'checks.json',SELECT/'verified-domain-selection.json',PRIOR/'verified-domain-selection.json',ROOT/'output/h5-conditional-selected-search-20261026/search-audit/checks.json']+[SOURCE/'queries'/f'{q:03d}.json' for q in sorted({p['query'] for p in parts})]+list((SOURCE/'mutual').glob('*.json'));write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Four distinct first-sheet coordinate subproblems for the latest verified domains: seven cogs with one bracket; seven cogs with both brackets; seven cogs with the insert; seven cogs with one bracket and the insert. Keep all full source domains and guarded pair clauses within each group. No smaller closed call is repeated. Each group is a relaxation of the new selected full-source tuple; positive witnesses do not establish a full layout. At most one call per group,8solver seconds,one worker,seed0,60seconds shared and5seconds reserved. All past calls closed; no retry/reseed/extension. Audit exact models before calls.'});records=[]
for index,subset in enumerate(subsets):
    model=cp_model_pb2.CpModelProto();domains=[]
    for pi in subset:
        p=parts[pi];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];qb=spec['queries'][p['query']]['anchor_bounds_units1000'];db=d['coordinate_bounds'];assert d['index']==p['domain_index'];domains.append(d)
        for axis in range(2):model.variables.add(name=f'p{pi}-'+('xy'[axis]),domain=[max(qb[axis],db[axis]),min(qb[axis+2],db[axis+2])])
    def linear(terms,lo=-2**63,hi=2**63-1,flag=None):
        c=model.constraints.add();terms=sorted((v,a) for v,a in terms if a);c.linear.vars.extend(v for v,a in terms);c.linear.coeffs.extend(a for v,a in terms);c.linear.domain.extend([lo,hi]);
        if flag is not None:c.enforcement_literal.append(flag)
    for j,d in enumerate(domains):
        for h in d['halfplanes']:linear([(2*j,h['a']),(2*j+1,h['b'])],hi=h['bound'])
    pair_records=[]
    for ia,ib in combinations(range(len(subset)),2):
        a,b=parts[subset[ia]],parts[subset[ib]];case=next(c['index'] for c in spec['mutual_cases'] if [c['profile_a'],c['profile_b']]==[a['profile'],b['profile']]);faces=load(SOURCE/'mutual'/f'{case:03d}.json')['faces'];pair_records.append({'local':[ia,ib],'parts':[a['part'],b['part']],'case':case,'source_faces':len(faces)})
        for face in faces:
            flags=[]
            for edge,h in enumerate(face['outside_halfplanes']):
                flag=len(model.variables);flags.append(flag);model.variables.add(name=f'p{ia}-{ib}-f{face["index"]}-e{edge}',domain=[0,1]);linear([(2*ia,-h['a']),(2*ia+1,-h['b']),(2*ib,h['a']),(2*ib+1,h['b'])],lo=h['bound'],flag=flag)
            model.constraints.add().bool_or.literals.extend(flags)
    path=OUT/'models'/f'{index:03d}.pb';path.write_bytes(model.SerializeToString());path.with_suffix('.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');records.append({'index':index,'parts':subset,'selection':[parts[p] for p in subset],'pair_faces':pair_records,'variables':len(model.variables),'constraints':len(model.constraints),'solver_seconds':8.0,'model_sha256':digest(path)})
write(OUT/'inventory.json',records);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'models':4,'new_family_coordinate_groups':4,'previous_subset_calls_not_reopened':True,'solver_calls':0});print(load(OUT/'prepared.json'))
