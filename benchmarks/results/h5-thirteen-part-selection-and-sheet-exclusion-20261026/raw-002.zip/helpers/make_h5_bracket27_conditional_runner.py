"""Prepare a fresh bounded conditional-master run and readback."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('run_h5_free_bracket27_domain_master_repaired.py','run_h5_bracket27_conditional_master.py'),('audit_h5_free_bracket27_domain_selection_repaired.py','audit_h5_bracket27_conditional_selection.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-free-bracket27-domain-master-search-repaired-20261026','h5-bracket27-conditional-master-search-20261026').replace('h5-free-bracket27-domain-master-20261026','h5-bracket27-conditional-master-20261026').replace('13536','13537')
    s=s.replace('One necessary domain-only master call:', 'One distinct necessary domain-only master call with the audited finite-source first-sheet exclusion:')
    s=s.replace('two exact area rules, independently certified copy ordering','two exact area rules, one scoped solver-derived first-sheet exclusion, independently certified copy ordering')
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
