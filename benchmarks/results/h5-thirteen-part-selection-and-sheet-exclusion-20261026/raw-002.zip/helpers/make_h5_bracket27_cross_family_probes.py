"""Prepare three distinct tests of the current selected first-sheet domains."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
oldbase='h5-bracket27-three-bracket-probe-20261026'
newbase='h5-bracket27-cross-family-probes-20261026'
subsets='[[0,1,2,3],[0,1,2,4,5],[3,4,5,6,7,8,9,10]]'
method=('Three new selected-domain source-coordinate subproblems in the 53-fixed construction: '
        'three brackets plus insert; three brackets plus the two bottom cogs; insert plus all '
        'seven first-sheet cogs. All parts are mandatory and retain every original domain plane '
        'and guarded pair-face disjunction. These differ from every closed prior subproblem. '
        'Exactly one call per model, eight seconds each, one worker, seed0, within60 shared seconds. '
        'Negative conclusions are scoped to the selected item/query/domain conjunction; positives '
        'are partial witnesses only. Complete independent reconstruction and solver import audit '
        'must pass before calls. All prior calls remain closed.')
for old,new in [
    ('prepare_h5_bracket27_three_bracket_probe.py','prepare_h5_bracket27_cross_family_probes.py'),
    ('audit_h5_bracket27_three_bracket_probe.py','audit_h5_bracket27_cross_family_probes.py'),
    ('run_h5_bracket27_three_bracket_probe.py','run_h5_bracket27_cross_family_probes.py'),
    ('audit_h5_bracket27_three_bracket_responses.py','audit_h5_bracket27_cross_family_responses.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace(oldbase,newbase)
    s=s[s.index('\n')+1:]
    s='"""'+method+'"""\n'+s
    s=s.replace('[[0,1,2]]',subsets)
    s=s.replace('len(subsets)==1','len(subsets)==3').replace('len(rows)==1','len(rows)==3')
    for field in ['models','new_family_coordinate_groups','complete_family_groups','closed_calls']:
        s=s.replace(repr(field)+':1',repr(field)+':3')
    if old.startswith('prepare') or old=='audit_h5_bracket27_three_bracket_probe.py':
        s=re.sub(r"'method':'[^']*'", "'method':"+repr(method),s,count=1)
    if old.startswith('run'):
        s=s.replace("'shared_seconds':60,'maximum_calls':1", "'shared_seconds':60,'maximum_calls':3")
    if old=='audit_h5_bracket27_three_bracket_responses.py':
        s=s.replace("budget['maximum_calls']==1","budget['maximum_calls']==3")
        s=s.replace("len(census['results'])==census['solver_calls']==1", "len(census['results'])==census['solver_calls']==3")
        s=s.replace("len(list(RUN.rglob('opened.json')))==1", "len(list(RUN.rglob('opened.json')))==3")
        s=s.replace('len(verified)+len(negatives)+len(unknown)==1','len(verified)+len(negatives)+len(unknown)==3')
        s=s.replace('complete declared single three-bracket inventory','complete declared three-group cross-family inventory').replace('one closed call per triple','one closed call per group')
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
