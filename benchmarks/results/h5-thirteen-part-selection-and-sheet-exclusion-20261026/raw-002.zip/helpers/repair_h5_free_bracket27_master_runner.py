"""Repair only a generated pre-search count assertion; no first solver call was opened."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];FAILED=ROOT/'output/h5-free-bracket27-domain-master-search-20261026';PREP=ROOT/'output/h5-free-bracket27-domain-master-20261026'
load=lambda p:json.loads(p.read_bytes())
r=load(FAILED/'shared-search/result.json');assert r['status']=='STAGE_FAILED' and r['solver_calls_opened']==0 and not list(FAILED.rglob('opened.json')) and not list(FAILED.rglob('response.pb'))
assert len(load(PREP/'mapping.json')['groups'])==7206 and load(PREP/'audit/checks.json')['passed'];assert (FAILED/'shared-search/solve/model.pb').read_bytes()==(PREP/'model.pb').read_bytes()
for old,new in [('run_h5_free_bracket27_domain_master.py','run_h5_free_bracket27_domain_master_repaired.py'),('audit_h5_free_bracket27_domain_selection.py','audit_h5_free_bracket27_domain_selection_repaired.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-free-bracket27-domain-master-search-20261026','h5-free-bracket27-domain-master-search-repaired-20261026').replace("len(mapping['groups'])==13206","len(mapping['groups'])==7206")
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (FAILED/'failure-audit.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'passed':True,'failure':'Generated pre-search assertion accidentally changed7206 to13206 while replacing part count7 with13.','actual_audited_groups':7206,'model_import_bytes_unchanged':True,'model_sha256':sha256((PREP/'model.pb').read_bytes()).hexdigest(),'opened_markers':0,'responses':0,'solver_calls':0,'repair':'Correct this assertion in a new helper/output directory. Keep all original model bytes, parameters and budgets. Only the separately declared first solver call may proceed.'},f,indent=2);f.write('\n')
