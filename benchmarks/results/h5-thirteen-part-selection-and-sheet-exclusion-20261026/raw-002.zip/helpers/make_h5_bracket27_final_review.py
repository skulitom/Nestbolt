"""Review current main after the two-checkpoint normal push."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_bracket27_source.py').read_text(encoding='utf-8').replace('h5-bracket27-source-review-20261026','h5-bracket27-final-review-20261026').replace('679e97e0d7fca4798ba2a1d690c044d72b8f72e2','c22d3e39e315b040b3afc694acae3e1beca685f8')
with (ROOT/'output/review_h5_bracket27_final.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
