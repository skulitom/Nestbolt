"""Re-prove a suspected insert/two-cog obstruction from fresh domains, without solving."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for kind in ['certify','audit']:
    s=(ROOT/'output'/f'{kind}_h5_selected_triple_collision.py').read_text(encoding='utf-8')
    s=s.replace('h5-expanded-cog-joint-prepared-20261026','h5-free-bracket27-joint-prepared-20261026').replace('h5-expanded-second-sheet-capacity-20261026','h5-free-bracket27-second-sheet-capacity-20261026').replace('h5-expanded-domain-conflicts-20261026','h5-free-bracket27-domain-conflicts-20261026').replace('h5-selected-triple-collision-certificate-20261026','h5-free-bracket27-triple-collision-20261026').replace('list(range(3,12))','list(range(4,13))').replace('ip==[2]','ip==[3]').replace("]==[2]","]==[3]")
    if kind=='certify':
        s=s.replace("TRIPLE=ROOT/'output/h5-selected-triple-census-20261026/response-audit'", "SELECT=ROOT/'output/h5-free-bracket27-domain-master-search-repaired-20261026/selection-audit'")
        start=s.index("negative=load(TRIPLE/");end=s.index("assert [p['query'] for p in sel]",start)
        s=s[:start]+"assert load(SELECT/'checks.json')['passed'] and load(SELECT/'checks.json')['necessary_domain_candidate'];sel=[p for p in load(SELECT/'verified-domain-selection.json')['movable_parts'] if p['item'] in [50,53,54]];"+s[end:]
        s=s.replace("[TRIPLE/'conditional-negative-triples.json',TRIPLE/'checks.json']","[SELECT/'verified-domain-selection.json',SELECT/'checks.json']")
        s=s.replace('Replace the selected triple solver negative by a whole-box raw-geometry certificate','Check the current insert/two-cog selection with a fresh whole-box raw-geometry certificate')
    else:
        s=s.replace("'h5-projected-source-and-fresh-conflicts-20261026']", "'h5-projected-source-and-fresh-conflicts-20261026','h5-seven-part-obstruction-and-broader-source-20261026']")
    compile(s,kind,'exec')
    with (ROOT/'output'/f'{kind}_h5_free_bracket27_triple_collision.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
