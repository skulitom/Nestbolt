"""Test two new conjunctions after separately feasible component checks."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
method=('Two new source-coordinate conjunctions under the unchanged current53-fixed geometry: '
        'parts0..5 combines the three brackets, insert and two bottom cogs, whose bracket/insert '
        'and bracket/two-cog subsets passed separately; parts0/1/2/4..10 combines all three '
        'brackets with the seven first-sheet cogs. These exact conjunctions have not been solved. '
        'Preserve all original selected-domain inequalities and every guarded pair face. '
        'One8second call per model,one worker,seed0,inside60 shared seconds. No retry of the '
        'closed insert/seven-cog UNKNOWN or any previous call. Subset evidence only, never '
        'a full-job result or unrestricted geometry proof.')
for old,new in [
    ('prepare_h5_bracket27_cross_family_probes.py','prepare_h5_bracket27_coupled_group_probes.py'),
    ('audit_h5_bracket27_cross_family_probes.py','audit_h5_bracket27_coupled_group_probes.py'),
    ('run_h5_bracket27_cross_family_probes.py','run_h5_bracket27_coupled_group_probes.py'),
    ('audit_h5_bracket27_cross_family_responses.py','audit_h5_bracket27_coupled_group_responses.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-bracket27-cross-family-probes-20261026','h5-bracket27-coupled-group-probes-20261026')
    s='"""'+method+'"""\n'+s[s.index('\n')+1:]
    s=s.replace('[[0,1,2,3],[0,1,2,4,5],[3,4,5,6,7,8,9,10]]','[[0,1,2,3,4,5],[0,1,2,4,5,6,7,8,9,10]]')
    s=s.replace('len(subsets)==3','len(subsets)==2').replace('len(rows)==3','len(rows)==2')
    for field in ['models','new_family_coordinate_groups','complete_family_groups','closed_calls']:
        s=s.replace(repr(field)+':3',repr(field)+':2')
    if old.startswith('prepare') or old=='audit_h5_bracket27_cross_family_probes.py':
        s=re.sub(r"'method':'[^']*'", "'method':"+repr(method),s,count=1)
    if old.startswith('prepare'):
        s=s.replace("SOURCE/'audit/checks.json',", "SOURCE/'audit/checks.json',ROOT/'output/h5-bracket27-cross-family-probes-20261026/response-audit/checks.json',ROOT/'output/h5-bracket27-cross-family-probes-20261026/response-audit/verified-subset-witnesses.json',")
    if old.startswith('run'):
        s=s.replace("'shared_seconds':60,'maximum_calls':3", "'shared_seconds':60,'maximum_calls':2")
    if old=='audit_h5_bracket27_cross_family_responses.py':
        s=s.replace("budget['maximum_calls']==3","budget['maximum_calls']==2")
        s=s.replace("len(census['results'])==census['solver_calls']==3", "len(census['results'])==census['solver_calls']==2")
        s=s.replace("len(list(RUN.rglob('opened.json')))==3", "len(list(RUN.rglob('opened.json')))==2")
        s=s.replace('len(verified)+len(negatives)+len(unknown)==3','len(verified)+len(negatives)+len(unknown)==2')
        s=s.replace('complete declared three-group cross-family inventory','complete declared two-group coupled inventory')
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
