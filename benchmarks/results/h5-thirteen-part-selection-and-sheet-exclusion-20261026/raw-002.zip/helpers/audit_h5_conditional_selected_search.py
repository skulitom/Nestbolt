"""Read back the single closed expanded-source call; never reopen the solver."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-conditional-selected-search-20261026';RUN=BASE/'shared-search';PREP=ROOT/'output/h5-conditional-selected-model-20261026';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';OUT=BASE/'search-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert (RUN/'result.json').exists();OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();paths=[p for p in RUN.rglob('*') if p.is_file()]+[PREP/n for n in ['model.pb','mapping.json','audit/checks.json']]+[ROOT/'output/h5-projected-expanded-model-20261026/necessary-rules.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Verify the actual solver model and parameters, immutable audited sources, one closed call, response proto/status and complete elapsed budget. If positive, evaluate every returned model variable/constraint plus each selected original identity/domain/halfplane, every full original same-sheet pair clause, original area and fresh capacity. Preserve negatives and timing overruns without acceptance claims. No solver/native call.'})
    for plan in [RUN/'plan.json',RUN/'solve/plan.json',PREP/'plan.json',PREP/'audit/plan.json']:
        for n,h in load(plan)['inputs'].items():assert digest(ROOT/n)==h,n
    budget=load(RUN/'budget.json');run=load(RUN/'result.json');solved=load(RUN/'solve/result.json');opened=load(RUN/'solve/opened.json');ma=load(RUN/'solve/model-audit.json');pa=load(PREP/'audit/checks.json');assert ma['passed'] and pa['passed']
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((RUN/'solve/model.pb').read_bytes());expected=cp_model_pb2.CpModelProto();expected.ParseFromString((PREP/'model.pb').read_bytes());assert actual==expected and digest(RUN/'solve/model.pb')==ma['model_sha256']==opened['model_sha256']==pa['model_sha256'];assert len(actual.variables)==223086 and len(actual.constraints)==289928 and len(actual.solution_hint.vars)==0
    params=text_format.Parse((RUN/'solve/parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert digest(RUN/'solve/parameters.pbtxt')==ma['parameters_sha256'];want={'max_time_in_seconds':min(45,ma['remaining_shared_budget_at_parameter_set']),'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False};assert params==sat_parameters_pb2.SatParameters(**want) and params.max_time_in_seconds==opened['seconds_limit']
    assert budget['shared_seconds']==60 and budget['solver_cap_seconds']==45 and budget['solver_shutdown_reserve_seconds']==10 and budget['maximum_solver_calls']==1 and budget['deadline_perf_counter']==budget['start_perf_counter']+60
    assert run['stage']['exit_code']==0 and solved['solver_calls']==run['solver_calls_opened']==1 and run['status']=='MASTER_'+solved['status'];assert solved['seconds']+ma['preparation_seconds']<=run['stage']['seconds']<=run['elapsed_seconds'];assert len(list(RUN.rglob('opened.json')))==1
    response=cp_model_pb2.CpSolverResponse();response.ParseFromString((RUN/'solve/response.pb').read_bytes());assert cp_model_pb2.CpSolverStatus.Name(response.status)==solved['status'];assert abs(response.wall_time-solved['seconds'])<1
    positive=solved['status'] in ['OPTIMAL','FEASIBLE'];assert positive==solved['has_full_guarded_source_candidate'];checked_constraints=inside=faces=planes=same_pairs=0
    if positive:
        solution=list(response.solution);assert len(solution)==len(actual.variables)
        for v,n in zip(actual.variables,solution):assert any(lo<=n<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]))
        def truth(v):return solution[v] if v>=0 else not solution[-v-1]
        for c in actual.constraints:
            if not all(truth(v) for v in c.enforcement_literal):continue
            kind=c.WhichOneof('constraint')
            if kind=='linear':n=sum(solution[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=n<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
            else:assert kind=='bool_or' and any(truth(v) for v in c.bool_or.literals)
            checked_constraints+=1
        mapping=load(PREP/'mapping.json');spec=load(SOURCE/'plan.json');selected=load(RUN/'solve/selection.json');parts=selected['movable_parts'];positions=load(RUN/'solve/original-positions.json');assert len(parts)==len(positions)==12 and selected['fixed_items']==spec['fixed_items'] and selected['required_originals']==66
        for original,p,xy,m in zip(spec['parts'],parts,positions,mapping['parts']):
            pi=original['part'];assert p['part']==xy['part']==pi and p['item']==original['index'] and p['family']==original['family'] and p['query'] in original['queries'];q=spec['queries'][p['query']];assert q['sheet']==p['sheet']==solution[m['sheet']] and q['profile']==p['profile'];mode=next(z for z in m['modes'] if z['query']==p['query']);assert solution[mode['active']]==solution[mode['domains'][p['domain_row']]]==1;assert solution[m['choice']]==p['choice_index']==mode['choice_offset']+p['domain_row'];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];assert d['index']==p['domain_index'];x,y=xy['x_units'],xy['y_units'];assert x==solution[m['x']] and y==solution[m['y']]
            for b in [q['anchor_bounds_units1000'],d['coordinate_bounds']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
            for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];inside+=1
        pair_checks=[]
        for a,b in combinations(parts,2):
            if a['sheet']!=b['sheet']:continue
            case=next(c['index'] for c in spec['mutual_cases'] if (c['profile_a'],c['profile_b'])==(a['profile'],b['profile']));dx=positions[b['part']]['x_units']-positions[a['part']]['x_units'];dy=positions[b['part']]['y_units']-positions[a['part']]['y_units'];data=load(SOURCE/'mutual'/f'{case:03d}.json');count=0
            for face in data['faces']:assert any(h['a']*dx+h['b']*dy>=h['bound'] for h in face['outside_halfplanes']);faces+=1;planes+=len(face['outside_halfplanes']);count+=1
            pair_checks.append({'parts':[a['part'],b['part']],'case':case,'source_faces':count,'passed':True});same_pairs+=1
        rules=load(ROOT/'output/h5-projected-expanded-model-20261026/necessary-rules.json');areas=rules['fixed_area_lower_units'].copy()
        for p in parts:areas[p['sheet']]+=rules['filled_area_lower_units'][p['family']]
        assert all(a<=b for a,b in zip(areas,rules['stock_area_upper_units']));assert sum(p['family']=='cog' and p['sheet']==1 for p in parts)<=2
        write(OUT/'source-pair-checks.json',pair_checks);write(OUT/'verified-original-positions.json',[{**p,**xy} for p,xy in zip(parts,positions)]);write(OUT/'area-checks.json',{'original_lower_area_units':areas,'stock_upper_area_units':rules['stock_area_upper_units'],'passed':True})
    else:assert solved['status'] in ['UNKNOWN','INFEASIBLE'] and not response.solution and not (RUN/'solve/selection.json').exists() and not (RUN/'solve/original-positions.json').exists()
    checks={'passed':True,'seconds':time.perf_counter()-start,'terminal_status':solved['status'],'full_guarded_source_candidate':positive,'solver_calls':1,'actual_solver_seconds':solved['seconds'],'declared_solver_seconds':params.max_time_in_seconds,'solver_soft_limit_overshoot_seconds':max(0,solved['seconds']-params.max_time_in_seconds),'actual_shared_seconds':run['elapsed_seconds'],'shared_budget_honored':run['elapsed_seconds']<=60,'shared_overrun_seconds':max(0,run['elapsed_seconds']-60),'required_originals':66,'moving_originals':12,'fixed_originals':54,'actual_model_matches_independent_audit':True,'response_proto_status_verified':True,'full_source_pair_modes_in_verified_model':538,'selected_active_constraints_checked':checked_constraints,'same_sheet_original_pairs_checked':same_pairs,'source_inward_halfplanes_checked':inside,'source_full_guarded_clauses_checked':faces,'source_outside_inequalities_checked':planes,'candidate_passes_all_original_source_clauses':positive,'completed_call_closed_no_retry':True,'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
