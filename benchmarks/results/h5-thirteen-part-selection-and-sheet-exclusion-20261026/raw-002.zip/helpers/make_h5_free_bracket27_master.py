"""A new13-mover necessary master with fresh capacity and original insert hint."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for kind in ['prepare','audit']:
    s=(ROOT/'output'/f'{kind}_h5_partial59_domain_master.py').read_text(encoding='utf-8').replace('h5-partial59-','h5-free-bracket27-')
    s=s.replace(";OUT=", ";CAP=ROOT/'output/h5-free-bracket27-second-sheet-capacity-20261026';OUT=",1)
    s=s.replace("CONFLICTS/'copy-symmetry/checks.json']", "CONFLICTS/'copy-symmetry/checks.json',CAP/'audit/checks.json']")
    s=s.replace('all seven movers','all thirteen movers').replace('7 selecting fresh59-fixed','13 selecting fresh53-fixed').replace('with no inherited capacity','with the independently rederived current second-sheet capacity2').replace('three bracket and four cog copies','three bracket and nine cog copies').replace('Sort the four verified partial-domain hints into that order','Retain insert50 hint on part3 and sort only the nine cog hints into the verified order').replace('no capacity, precisely five certified family orders','fresh capacity2, precisely ten certified family orders')
    s=s.replace('7937','21093').replace('2514','13536').replace('232752','1641171').replace('11983416','37378521').replace('6763','14789').replace('1104','6210').replace("'query_modes':56","'query_modes':68").replace('(6833,77)','(14883,107)').replace('==588','==954').replace(':588',':954').replace('len(inventory)==21','len(inventory)==78').replace("'physical_pairs':21","'physical_pairs':78")
    s=s.replace("'hints':16","'hints':40").replace('len(values)==16','len(values)==40').replace("'moving_originals':7","'moving_originals':13").replace("'fixed_originals':59","'fixed_originals':53").replace("'certified_family_orders_only_in_necessary_master':5","'certified_family_orders_only_in_necessary_master':10").replace('len(parts)==7','len(parts)==13').replace("len(spec['fixed_items'])==59","len(spec['fixed_items'])==53")
    if kind=='prepare':
        s=s.replace('+[RULES]+','+[RULES,CAP/\'certificate.json\',CAP/\'audit/plan.json\',CAP/\'audit/checks.json\']+')
        s=s.replace(";orders=load(CONFLICTS/", ";cap=load(CAP/'certificate.json');assert cap['applicable_moving_parts']==list(range(4,13));lin([(modes[i,19]['active'],1) for i in cap['applicable_moving_parts']],hi=cap['capacity']);orders=load(CONFLICTS/")
        start=s.index('    source_hints=[]');end=s.index("        p=parts[pi];",start)
        s=s[:start]+'''    original_hints=load(SOURCE/'audit/verified-partial-domain-membership.json');source_hints=[]
    for r in original_hints:
        source_part=next(p for p in parts if p['item']==r['item']);qi=r['query'];row=r['matching_domains'][0]['row'];source_hints.append({**r,'domain_row':row,'choice_index':modes[source_part['part'],qi]['choice_offset']+row})
    insert=next(r for r in source_hints if r['item']==50);cogs=sorted([r for r in source_hints if r['item']!=50],key=lambda r:(r['choice_index'],r['anchor_units1000'],r['item']));assert len(cogs)==9;hints=[]
    for pi,r in [(3,insert)]+list(zip(range(4,13),cogs)):
'''+s[end:]
    else:
        s=s.replace("    orders=[[0,1],[1,2],[3,4],[4,5],[5,6]]", "    cap=load(CAP/'certificate.json');assert cap['applicable_moving_parts']==list(range(4,13)) and cap['capacity']==2\n    for n,h in load(CAP/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n\n    linear([(modes[i,19]['active'],1) for i in cap['applicable_moving_parts']],hi=2)\n    orders=[[0,1],[1,2]]+[[i,i+1] for i in range(4,12)]")
        start=s.index("    originals=load(SOURCE/'audit/verified-partial-domain-membership.json')");end=s.index("        p=parts[pi];",start)
        s=s[:start]+'''    originals=load(SOURCE/'audit/verified-partial-domain-membership.json');insert=next(r for r in originals if r['item']==50);cogs=[r for r in originals if r['item']!=50];assert len(cogs)==9
    sorted_hints=sorted(cogs,key=lambda r:((0 if r['query']==18 else len(queries[18]['domains']))+min(m['row'] for m in r['matching_domains']),r['anchor_units1000'],r['item']));hint_records=[];values=[]
    for pi,r in [(3,insert)]+list(zip(range(4,13),sorted_hints)):
'''+s[end:]
    compile(s,kind,'exec')
    with (ROOT/'output'/f'{kind}_h5_free_bracket27_domain_master.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
