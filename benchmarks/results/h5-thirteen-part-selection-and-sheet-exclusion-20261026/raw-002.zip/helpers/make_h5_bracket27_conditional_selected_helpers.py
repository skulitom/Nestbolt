"""A new exact coordinate model for the changed insert-domain selection."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('prepare_h5_free_bracket27_selected_model.py','prepare_h5_bracket27_conditional_selected_model.py'),('audit_h5_free_bracket27_selected_model.py','audit_h5_bracket27_conditional_selected_model.py'),('run_h5_free_bracket27_selected_search.py','run_h5_bracket27_conditional_selected_search.py'),('audit_h5_free_bracket27_selected_search.py','audit_h5_bracket27_conditional_selected_search.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-free-bracket27-domain-master-search-repaired-20261026','h5-bracket27-conditional-master-search-20261026').replace('h5-free-bracket27-selected-model-20261026','h5-bracket27-conditional-selected-model-20261026').replace('h5-free-bracket27-selected-search-20261026','h5-bracket27-conditional-selected-search-20261026')
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
