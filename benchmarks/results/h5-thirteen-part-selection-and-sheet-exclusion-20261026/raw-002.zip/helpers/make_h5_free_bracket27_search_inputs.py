"""Fresh full source, raw conflicts and lossless necessary-master prerequisites."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(n,s):
    compile(s,n,'exec')
    with (ROOT/'output'/n).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for kind in ['prepare','audit']:
    s=(ROOT/'output'/f'{kind}_h5_partial59_source_model.py').read_text(encoding='utf-8').replace('h5-partial59-','h5-free-bracket27-')
    s=s.replace('seven-mover','thirteen-mover').replace('fresh59-fixed','fresh53-fixed').replace('7 mandatory originals','13 mandatory originals').replace('of7 physical originals','of13 physical originals').replace('fixed59 and these7','fixed53 and these13').replace('and59 unchanged fixed','and53 unchanged fixed').replace('four previous cog positions','ten previous moving positions').replace('all294 nonempty','all954 nonempty').replace('all21 physical pairs/294','all78 physical pairs/954')
    s=s.replace("'moving_originals':7","'moving_originals':13").replace("'fixed_originals':59","'fixed_originals':53").replace("'hints':24","'hints':60").replace("'original_anchor_variables':14","'original_anchor_variables':26").replace("'physical_pairs':21","'physical_pairs':78").replace("'same_sheet_pair_modes':294","'same_sheet_pair_modes':954").replace("len(spec['parts'])==7","len(spec['parts'])==13").replace("len(spec['fixed_items'])==59","len(spec['fixed_items'])==53").replace("len(mapping['source_pair_faces'])==294","len(mapping['source_pair_faces'])==954").replace('len(hint_pairs)==24','len(hint_pairs)==60')
    save(f'{kind}_h5_free_bracket27_source_model.py',s)
for kind in ['build','audit']:
    s=(ROOT/'output'/f'{kind}_h5_partial59_domain_conflicts.py').read_text(encoding='utf-8').replace('h5-partial59-','h5-free-bracket27-')
    s=s.replace('==146','==164').replace(':146',':164').replace('==21','==78').replace(':21',':78').replace('==588','==954').replace(':588',':954').replace('the7 mandatory originals','the13 mandatory originals').replace('All146 unique query pairs and their588 physical uses','All164 unique query pairs and their954 physical uses').replace('full146-case/588-use/21-physical-pair','full164-case/954-use/78-physical-pair')
    save(f'{kind}_h5_free_bracket27_domain_conflicts.py',s)
for old,new in [('prepare_h5_partial59_conflict_groups.py','prepare_h5_free_bracket27_conflict_groups.py'),('audit_h5_partial59_conflict_groups.py','audit_h5_free_bracket27_conflict_groups.py'),('audit_h5_partial59_master_copy_symmetry.py','audit_h5_free_bracket27_master_copy_symmetry.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-partial59-','h5-free-bracket27-').replace('all588','all954').replace(':146',':164').replace('==21','==78').replace('==588','==954').replace(':21',':78').replace(':588',':954').replace("'cog':list(range(3,7))","'cog':list(range(4,13))").replace('the four cogs','the nine cogs')
    save(new,s)
