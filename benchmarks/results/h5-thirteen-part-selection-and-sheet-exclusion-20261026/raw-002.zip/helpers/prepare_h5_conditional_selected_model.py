"""Exact full-source coordinate subproblem for the newly verified necessary selection."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-projected-expanded-model-20261026';SELECT=ROOT/'output/h5-conditional-domain-master-search-20261026/selection-audit';OUT=ROOT/'output/h5-conditional-selected-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed'] and load(SELECT/'checks.json')['passed'] and load(SELECT/'checks.json')['necessary_domain_candidate'];paths=[PARENT/n for n in ['model.pb','mapping.json','audit/checks.json','necessary-rules.json']]+[SELECT/n for n in ['checks.json','plan.json','verified-domain-selection.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Retain the full223086-variable/289916-constraint original projected source model. Append exactly12 equalities selecting the twelve domains from the independently verified necessary master. All24 integer coordinates remain free inside those chosen domains and every original source plane remains. Clear only the54 advisory hints, which refer to a different selection. This is an exact coordinate subproblem for this particular domain tuple, not a new unrestricted12-part search. A negative excludes only this stored tuple; a positive needs source/original-geometry/native validation. No solver.'})
model=cp_model_pb2.CpModelProto();model.ParseFromString((PARENT/'model.pb').read_bytes());mapping=load(PARENT/'mapping.json');selected=load(SELECT/'verified-domain-selection.json');records=[]
for s in selected['movable_parts']:
    p=mapping['parts'][s['part']];assert p['item']==s['item'];m=next(m for m in p['modes'] if m['query']==s['query']);flag=m['domains'][s['domain_row']];ci=len(model.constraints);c=model.constraints.add();c.linear.vars.append(flag);c.linear.coeffs.append(1);c.linear.domain.extend([1,1]);records.append({'part':s['part'],'item':s['item'],'query':s['query'],'domain_row':s['domain_row'],'domain_index':s['domain_index'],'flag':flag,'constraint':ci})
assert len(records)==12;model.ClearField('solution_hint');shutil.copyfile(PARENT/'mapping.json',OUT/'mapping.json');write(OUT/'selected-domains.json',records);(OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');r={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':len(model.solution_hint.vars),'selected_domain_equalities':12,'required_originals':66,'moving_originals':12,'fixed_originals':54,'free_original_coordinate_variables':24,'coordinate_values_fixed':0,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',r);print(r,flush=True)
