"""Create new review and push helpers; retain all previous receipts."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_partial59_final.py').read_text(encoding='utf-8')
s=s.replace('h5-partial59-final-review-20261026','h5-bracket27-source-review-20261026').replace('fec3cd72205e16d3522a181bf4f29680b9e768e5','c22d3e39e315b040b3afc694acae3e1beca685f8')
with (ROOT/'output/review_h5_bracket27_source.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/push_h5_conditional_selection_checkpoint.py').read_text(encoding='utf-8')
s=s.replace('h5-conditional-selection-main-sync-20261026','h5-broader-source-main-sync-20261026').replace('40264589776','40267513191')
s=s.replace('679e97e0d7fca4798ba2a1d690c044d72b8f72e2','c22d3e39e315b040b3afc694acae3e1beca685f8').replace('b8535505cbe17167056041765648fd4770a8320b','679e97e0d7fca4798ba2a1d690c044d72b8f72e2')
s=s.replace("['0','1']","['0','2']").replace("'pushed_commits':1","'pushed_commits':2")
with (ROOT/'output/push_h5_broader_source_checkpoint.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
