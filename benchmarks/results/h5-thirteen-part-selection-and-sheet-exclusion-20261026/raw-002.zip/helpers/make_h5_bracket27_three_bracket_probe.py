"""One new three-bracket coordinate subproblem, with original domains and all pair faces."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
method='One distinct source-coordinate subproblem contains all three selected brackets, parts0/1/2 (originals27/28/29), in the new53-fixed construction. All use query0 row11. Preserve every original domain plane, integer bound and full guarded pair-face disjunction. No old two-bracket or other closed subproblem is repeated. One8second call,one worker,seed0,inside60shared seconds. Any negative is only for this selected three-part source conjunction; a positive is only a subset witness. Independently audit complete model and actual import first. All prior calls remain closed.'
for old,new in [('prepare_h5_selected_family_groups.py','prepare_h5_bracket27_three_bracket_probe.py'),('audit_h5_selected_family_groups.py','audit_h5_bracket27_three_bracket_probe.py'),('run_h5_selected_family_groups.py','run_h5_bracket27_three_bracket_probe.py'),('audit_h5_selected_family_responses.py','audit_h5_bracket27_three_bracket_responses.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-selected-family-groups-20261026','h5-bracket27-three-bracket-probe-20261026').replace('h5-expanded-cog-joint-prepared-20261026','h5-free-bracket27-joint-prepared-20261026').replace('h5-conditional-domain-master-search-20261026','h5-free-bracket27-domain-master-search-repaired-20261026').replace('h5-conditional-selected-search-20261026','h5-free-bracket27-selected-search-20261026')
    s=s.replace(";PRIOR=ROOT/'output/h5-expanded-domain-master-search-20261026/selection-audit'",'')
    s=s.replace('[[0, 3, 4, 5, 6, 7, 8, 9], [0, 1, 3, 4, 5, 6, 7, 8, 9], [2, 3, 4, 5, 6, 7, 8, 9], [0, 2, 3, 4, 5, 6, 7, 8, 9]]','[[0,1,2]]')
    s=re.sub(r'==4\b','==1',s)
    for field in ['maximum_calls','models','new_family_coordinate_groups','complete_family_groups','closed_calls']:s=s.replace("'"+field+"':4","'"+field+"':1")
    if old.startswith('prepare'):
        a=s.index(';old=load(PRIOR/');b=s.index(';subsets=',a);s=s[:a]+s[b:]
        s=s.replace(",PRIOR/'verified-domain-selection.json'",'');s=re.sub(r"'method':'[^']*'", "'method':"+repr(method),s,count=1)
    elif old=='audit_h5_selected_family_groups.py':
        a=s.index(';prior=load(PRIOR/');b=s.index(';spec=load(SOURCE/',a);s=s[:a]+s[b:]
        s=s.replace('h5-domain-selection-and-triple-certificate-20261026/raw-manifest.json','h5-seven-part-obstruction-and-broader-source-20261026/raw-manifest.json');s=re.sub(r"'method':'[^']*'", "'method':"+repr('Independently reconstruct the one declared three-bracket coordinate model from all current original domain planes and guarded pair faces. Verify immutable source and selection hashes, exact variable and constraint inventory, and actual solver import/export. No prior closed subproblem is repeated.'),s,count=1)
    elif old.startswith('audit'):
        s=s.replace('complete declared four-group inventory','complete declared single three-bracket inventory').replace('Readback forfour closed family coordinate groups','Readback forone closed three-bracket coordinate group')
    compile(s,new,'exec')
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
