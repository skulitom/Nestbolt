"""Independent complete reconstruction and changed-subset inventory audit."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-selected-family-groups-20261026';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';SELECT=ROOT/'output/h5-conditional-domain-master-search-20261026/selection-audit';PRIOR=ROOT/'output/h5-expanded-domain-master-search-20261026/selection-audit';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify source/selection hashes and committed original inputs. Compare all twelve old/new choices; exactly insert part2 changes. Reconstruct the complete four-group inventory, every variable/constraint from original domain planes and full pair-face disjunctions, and exact actual import/export. Each group is a distinct larger coordinate conjunction; no earlier pair or triple call is repeated. No solver.'});known=set();manifest=load(ROOT/'benchmarks/results/h5-domain-selection-and-triple-certificate-20261026/raw-manifest.json');known.update(r['sha256'] for r in manifest['files']+manifest['aliases'])
for n,h in load(BASE/'plan.json')['inputs'].items():
    assert digest(ROOT/n)==h,n
    if 'h5-expanded-cog-joint-prepared-20261026/' in n:assert h in known,n
assert load(SELECT/'checks.json')['passed'];parts=load(SELECT/'verified-domain-selection.json')['movable_parts'];prior=load(PRIOR/'verified-domain-selection.json')['movable_parts'];assert [i for i,(a,b) in enumerate(zip(parts,prior)) if a!=b]==[2];spec=load(SOURCE/'plan.json');expected=[[0, 3, 4, 5, 6, 7, 8, 9], [0, 1, 3, 4, 5, 6, 7, 8, 9], [2, 3, 4, 5, 6, 7, 8, 9], [0, 2, 3, 4, 5, 6, 7, 8, 9]];rows=load(BASE/'inventory.json');assert len(rows)==4 and [r['parts'] for r in rows]==expected;checks=[]
for i,r in enumerate(rows):
    assert r['index']==i and r['selection']==[parts[p] for p in r['parts']] and r['solver_seconds']==8.0;model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'models'/f'{i:03d}.pb').read_bytes());assert {f.name for f,v in model.ListFields()}=={'variables','constraints'};vc=cc=0;ds=[]
    for p in r['selection']:
        q=spec['queries'][p['query']];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];assert d['index']==p['domain_index'];ds.append(d)
        for axis in [0,1]:assert model.variables[vc]==cp_model_pb2.IntegerVariableProto(name=f"p{p['part']}-{'xy'[axis]}",domain=[max(q['anchor_bounds_units1000'][axis],d['coordinate_bounds'][axis]),min(q['anchor_bounds_units1000'][axis+2],d['coordinate_bounds'][axis+2])]);vc+=1
    def check_linear(coefs,low,high,enforcement=None):
        nonlocal_dummy=None
        global cc
        c=cp_model_pb2.ConstraintProto();ids=sorted(v for v,a in coefs.items() if a);c.linear.vars.extend(ids);c.linear.coeffs.extend(coefs[v] for v in ids);c.linear.domain.extend([low,high])
        if enforcement is not None:c.enforcement_literal.append(enforcement)
        assert model.constraints[cc]==c,(i,cc);cc+=1
    for j,d in enumerate(ds):
        for h in d['halfplanes']:check_linear({2*j:h['a'],2*j+1:h['b']},-2**63,h['bound'])
    pair_records=[]
    for ia,ib in combinations(range(len(ds)),2):
        a,b=r['selection'][ia],r['selection'][ib];case=next(z['index'] for z in spec['mutual_cases'] if (z['profile_a'],z['profile_b'])==(a['profile'],b['profile']));faces=load(SOURCE/'mutual'/f'{case:03d}.json')['faces'];pair_records.append({'local':[ia,ib],'parts':[a['part'],b['part']],'case':case,'source_faces':len(faces)})
        for face in faces:
            flags=[]
            for edge,h in enumerate(face['outside_halfplanes']):
                assert model.variables[vc]==cp_model_pb2.IntegerVariableProto(name=f'p{ia}-{ib}-f{face["index"]}-e{edge}',domain=[0,1]);flag=vc;flags.append(flag);vc+=1;check_linear({2*ia:-h['a'],2*ia+1:-h['b'],2*ib:h['a'],2*ib+1:h['b']},h['bound'],2**63-1,flag)
            c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend(flags);assert model.constraints[cc]==c;cc+=1
    assert pair_records==r['pair_faces'] and vc==r['variables']==len(model.variables) and cc==r['constraints']==len(model.constraints);assert digest(BASE/'models'/f'{i:03d}.pb')==r['model_sha256'];real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models'/f'{i:03d}.pbtxt').read_text()) and real.validate()=='';p=OUT/f'{i:03d}-roundtrip.pb';assert real.export_to_file(str(p));actual=cp_model_pb2.CpModelProto();actual.ParseFromString(p.read_bytes());assert actual==model;checks.append({'subset':i,'parts':r['parts'],'passed':True})
write(OUT/'subsets.json',checks);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'complete_family_groups':4,'all_original_variables_constraints_reconstructed':True,'all_full_source_pair_faces_preserved':True,'only_changed_subsets_scheduled':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
