"""Append exactly one audited finite-source first-sheet exclusion."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-bracket27-conditional-master-20261026';PARENT=ROOT/'output/h5-free-bracket27-domain-master-20261026';CERT=ROOT/'output/h5-bracket27-sheet-separation-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed'] and load(CERT/'checks.json')['finite_source_first_sheet_tuple_excluded']
paths=[PARENT/n for n in ['model.pb','mapping.json','plan.json','audit/checks.json','audit/plan.json']]+[p for p in CERT.iterdir() if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Retain the entire audited current necessary domain master, all fresh raw conflicts, area/capacity rules, family orders and advisory hints. Append one Boolean clause excluding exactly the eleven first-sheet choices justified by the sheet-separation audit. This solver-negative-derived exclusion is valid only for the audited conservative finite source model; it is not a raw-geometry capacity theorem. No second-sheet choices are fixed. Audit complete parent equality and all selector mappings before one separately bounded call. Previous calls stay closed.'})
model=cp_model_pb2.CpModelProto();model.ParseFromString((PARENT/'model.pb').read_bytes());mapping=load(PARENT/'mapping.json');selection=load(CERT/'conditional-exclusion.json')['selection'];rows=[]
for p in selection:
    m=mapping['parts'][p['part']];assert m['item']==p['item'] and m['family']==p['family'];mode=next(q for q in m['modes'] if q['query']==p['query']);rows.append({**p,'selector':mode['domains'][p['domain_row']]})
assert len(rows)==11;index=len(model.constraints);model.constraints.add().bool_or.literals.extend(-p['selector']-1 for p in rows)
write(OUT/'exclusion-mapping.json',{'constraint':index,'selection':rows,'certificate_sha256':digest(CERT/'conditional-exclusion.json')});shutil.copyfile(PARENT/'mapping.json',OUT/'mapping.json');(OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n')
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':len(model.solution_hint.vars),'added_constraints':1,'model_sha256':digest(OUT/'model.pb'),'finite_source_necessary_master_only':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
