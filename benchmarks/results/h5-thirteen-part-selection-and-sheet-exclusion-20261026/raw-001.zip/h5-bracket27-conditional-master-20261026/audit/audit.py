"""Check the whole parent, all eleven selector mappings and the exact exclusion."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bracket27-conditional-master-20261026';PARENT=ROOT/'output/h5-free-bracket27-domain-master-20261026';CERT=ROOT/'output/h5-bracket27-sheet-separation-20261026';SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Independently map every physical original/query/domain in the audited first-sheet exclusion to its necessary-master selector. Verify immutable input chains, all2048 Boolean assignments, and byte-for-byte whole-parent restoration after removing only the appended clause. Original family ordering remains justified: the full source has identical domains and original pair profiles for interchangeable copies, and the excluded physical tuple is impossible for any valid source realization. Check actual solver import/export. No solver call or raw-geometry impossibility assertion.'})
for p in [BASE/'plan.json',CERT/'plan.json',PARENT/'plan.json',PARENT/'audit/plan.json']:
    for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(CERT/'checks.json')['passed'] and load(CERT/'checks.json')['finite_source_first_sheet_tuple_excluded'] and load(PARENT/'audit/checks.json')['every_variable_and_constraint_reconstructed']
mapping=load(BASE/'mapping.json');assert mapping==load(PARENT/'mapping.json');spec=load(SOURCE/'plan.json');selection=load(CERT/'conditional-exclusion.json')['selection'];flags=[];rows=[]
assert [p['part'] for p in selection]==list(range(11))
for p in selection:
    original=spec['parts'][p['part']];m=mapping['parts'][p['part']];assert original['index']==p['item']==m['item'] and original['family']==p['family']==m['family'];q=spec['queries'][p['query']];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];assert p['sheet']==q['sheet']==0 and p['profile']==q['profile'] and p['domain_index']==d['index'];mode=next(v for v in m['modes'] if v['query']==p['query']);flag=mode['domains'][p['domain_row']];flags.append(flag);rows.append({**p,'selector':flag})
assert len(set(flags))==11;model=proto(BASE/'model.pb');parent=proto(PARENT/'model.pb');assert len(model.variables)==21093 and len(model.constraints)==13537 and len(model.solution_hint.vars)==40;expected=cp_model_pb2.ConstraintProto();expected.bool_or.literals.extend(-v-1 for v in flags);assert model.constraints[-1]==expected;trim=cp_model_pb2.CpModelProto();trim.CopyFrom(model);del trim.constraints[-1];assert trim==parent
assert load(BASE/'exclusion-mapping.json')=={'constraint':13536,'selection':rows,'certificate_sha256':digest(CERT/'conditional-exclusion.json')}
for family in ['bracket','cog']:
    copies=[p for p in spec['parts'] if p['family']==family]
    assert copies
    assert all(p['queries']==copies[0]['queries'] and p['profiles']==copies[0]['profiles'] for p in copies)
truth_cases=0
for assignment in product([0,1],repeat=11):assert any(not v for v in assignment)==(sum(assignment)<11);truth_cases+=1
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'solver-import-roundtrip.pb'));assert proto(OUT/'solver-import-roundtrip.pb')==model
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':21093,'constraints':13537,'hints':40,'every_variable_and_constraint_reconstructed':True,'whole_parent_retained_exactly':True,'conditional_exclusion_selector_mappings':11,'boolean_truth_cases':truth_cases,'second_sheet_domain_choices_unrestricted':True,'source_copy_domains_identical':True,'actual_import_export_verified':True,'solver_negative_exclusion_scope':'Audited53-fixed finite source only; not unrestricted raw geometry.','solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
