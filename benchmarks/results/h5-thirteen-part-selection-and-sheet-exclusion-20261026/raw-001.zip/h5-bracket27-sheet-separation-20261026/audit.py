"""Derive a first-sheet-only conditional exclusion without another solver call."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-bracket27-sheet-separation-20261026'
SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';FULL=ROOT/'output/h5-free-bracket27-source-model-20261026';SELECTED=ROOT/'output/h5-free-bracket27-selected-model-20261026';RUN=ROOT/'output/h5-free-bracket27-selected-search-20261026'
SELECTION=ROOT/'output/h5-free-bracket27-domain-master-search-repaired-20261026/selection-audit/verified-domain-selection.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
def refs(c):
    ids={v if v>=0 else -v-1 for v in c.enforcement_literal};kind=c.WhichOneof('constraint')
    if kind=='linear':ids.update(c.linear.vars)
    else:
        assert kind=='bool_or';ids.update(v if v>=0 else -v-1 for v in c.bool_or.literals)
    return ids
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
paths=[SELECTION]+[FULL/n for n in ['plan.json','model.pb','mapping.json','necessary-rules.json','shared-directions.json','audit/plan.json','audit/checks.json','audit/projection-proof.json']]+[SELECTED/n for n in ['plan.json','model.pb','audit/plan.json','audit/checks.json']]+[RUN/n for n in ['search-audit/plan.json','search-audit/checks.json','shared-search/solve/response.pb']]+[SOURCE/n for n in ['plan.json','audit/plan.json','audit/checks.json','audit/verified-partial-domain-membership.json','queries/019.json','mutual/081.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Use the already closed INFEASIBLE selected13-domain full source model, without solving again. Independently verify that its two selected second-sheet domains have a simultaneous original-clause witness, that area rules depend only on sheets, and every geometric constraint belongs to one physical part or pair. The verified source projection allows arbitrary valid source anchors to extend to model flags. Any first11 source witness could therefore combine with the checked second-sheet witness to satisfy the full selected model, contradicting its recorded negative. Derive only this finite-source first-sheet tuple exclusion; no raw continuous geometry or formal UNSAT certificate is claimed.'})
for folder in [FULL,SELECTED,SOURCE]:
    assert load(folder/'audit/checks.json')['passed']
    for path in [folder/'plan.json',folder/'audit/plan.json']:
        for n,h in load(path).get('inputs',{}).items():assert digest(ROOT/n)==h,n
for n,h in load(RUN/'search-audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
neg=load(RUN/'search-audit/checks.json');assert neg['passed'] and neg['terminal_status']=='INFEASIBLE' and neg['completed_call_closed_no_retry']
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((RUN/'shared-search/solve/response.pb').read_bytes());assert response.status==cp_model_pb2.INFEASIBLE and not response.solution
spec=load(SOURCE/'plan.json');chosen=load(SELECTION)['movable_parts'];assert [p['part'] for p in chosen]==list(range(13)) and [p['sheet'] for p in chosen]==[0]*11+[1]*2
model=proto(FULL/'model.pb');selected=proto(SELECTED/'model.pb');mapping=load(FULL/'mapping.json');parts=mapping['parts'];assert len(model.constraints)==351276 and len(selected.constraints)==351289
for i,p in enumerate(chosen):
    m=next(m for m in parts[i]['modes'] if m['query']==p['query']);c=cp_model_pb2.ConstraintProto();c.linear.vars.append(m['domains'][p['domain_row']]);c.linear.coeffs.append(1);c.linear.domain.extend([1,1]);assert selected.constraints[len(model.constraints)+i]==c
del selected.constraints[len(model.constraints):];selected.solution_hint.CopyFrom(model.solution_hint);assert selected==model
base_constraints=0
for p in parts:
    allowed=set(range(*p['variable_span']))
    for c in model.constraints[slice(*p['constraint_span'])]:assert refs(c)<=allowed;base_constraints+=1
assert base_constraints==mapping['base_constraints']
rules=load(FULL/'necessary-rules.json');sheet_values={p['sheet']:chosen[p['part']]['sheet'] for p in parts}
for c in model.constraints[slice(*rules['constraint_span'])]:
    assert not c.enforcement_literal and set(c.linear.vars)<=sheet_values.keys();value=sum(sheet_values[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=value<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
defs=load(FULL/'shared-directions.json');by_pair={}
for d in defs:by_pair.setdefault(tuple(d['parts']),set()).add(d['flag'])
active=[];geometric_constraints=0
for pair in mapping['source_pair_faces']:
    ia,ib=pair['parts'];allowed=set(range(*parts[ia]['variable_span']))|set(range(*parts[ib]['variable_span']))|{pair['active']}|by_pair.get((ia,ib),set())
    for c in model.constraints[slice(*pair['constraint_span'])]:assert refs(c)<=allowed;geometric_constraints+=1
    if (chosen[ia]['query'],chosen[ib]['query'])==(pair['query_a'],pair['query_b']):
        assert chosen[ia]['sheet']==chosen[ib]['sheet'];active.append(pair)
assert len(active)==56 and sum(p['parts'][0]<11 and p['parts'][1]<11 for p in active)==55 and [p['parts'] for p in active if p['parts'][0]>=11]==[[11,12]]
assert base_constraints+2+geometric_constraints==len(model.constraints)
assert load(FULL/'audit/checks.json')['one_sided_existential_projection_verified']
hints=load(SOURCE/'audit/verified-partial-domain-membership.json');anchors={};planes=faces=0
for p in chosen[11:]:
    h=next(h for h in hints if h['item']==p['item']);assert h['query']==p['query'] and any(d['row']==p['domain_row'] and d['domain_index']==p['domain_index'] for d in h['matching_domains']);x,y=h['anchor_units1000'];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];q=spec['queries'][p['query']]
    for b in [d['coordinate_bounds'],q['anchor_bounds_units1000']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
    for plane in d['halfplanes']:assert plane['a']*x+plane['b']*y<=plane['bound'];planes+=1
    anchors[p['part']]=[x,y]
dx,dy=[anchors[12][axis]-anchors[11][axis] for axis in [0,1]]
pair=next(p for p in active if p['parts']==[11,12]);assert pair['mutual_case']==81
for f in load(SOURCE/'mutual/081.json')['faces']:assert any(h['a']*dx+h['b']*dy>=h['bound'] for h in f['outside_halfplanes']);faces+=1
write(OUT/'second-sheet-witness.json',{'selection':chosen[11:],'anchors_units1000':anchors,'inside_planes_checked':planes,'full_guarded_pair_faces_checked':faces})
write(OUT/'conditional-exclusion.json',{'selection':chosen[:11],'excluded_conjunction':'All eleven listed physical item/query/domain choices simultaneously. Other part choices are unrestricted.','source_sha256':digest(SOURCE/'plan.json'),'negative_selected_model_sha256':digest(SELECTED/'model.pb'),'negative_response_sha256':digest(RUN/'shared-search/solve/response.pb'),'reason':'A first-sheet witness plus the verified independent second-sheet witness would satisfy every selected13-source clause. The recorded selected13 solver result is INFEASIBLE.','finite_source_scope_only':True,'raw_geometry_impossibility_claimed':False,'formal_unsat_certificate_claimed':False})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'full_model_parent_reconstruction_verified':True,'all_constraints_partitioned':len(model.constraints),'base_part_constraints':base_constraints,'pair_constraints':geometric_constraints,'constant_area_rules':2,'active_first_sheet_pairs':55,'active_second_sheet_pairs':1,'active_cross_sheet_pairs':0,'second_sheet_source_witness_verified':True,'second_sheet_inside_planes':planes,'second_sheet_full_pair_faces':faces,'finite_source_first_sheet_tuple_excluded':True,'excluded_moving_parts':11,'new_solver_calls':0,'formal_unsat_certificate_claimed':False,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
