"""Necessary domain-selection master for all thirteen movers; no anchor feasibility claim."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';CONFLICTS=ROOT/'output/h5-free-bracket27-domain-conflicts-20261026';RULES=ROOT/'output/h5-free-bracket27-source-model-20261026/necessary-rules.json';CAP=ROOT/'output/h5-free-bracket27-second-sheet-capacity-20261026';OUT=ROOT/'output/h5-free-bracket27-domain-master-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert all(load(p)['passed'] for p in [CONFLICTS/'audit/checks.json',CONFLICTS/'groups/audit/checks.json',CONFLICTS/'copy-symmetry/checks.json',CAP/'audit/checks.json'])
    paths=[SOURCE/n for n in ['plan.json','audit/checks.json','audit/verified-partial-domain-membership.json']]+[RULES,CAP/'certificate.json',CAP/'audit/plan.json',CAP/'audit/checks.json']+[CONFLICTS/n for n in ['plan.json','result.json','audit/checks.json','groups/result.json','groups/audit/checks.json','copy-symmetry/plan.json','copy-symmetry/checks.json']]+sorted((SOURCE/'queries').glob('*.json'))+sorted((CONFLICTS/'groups').glob('[0-9][0-9][0-9].json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Build a necessary Boolean master for all66 originals,13 selecting fresh53-fixed domains. Exactly one domain/query per mover, exact family/sheet original lower-area rules, every newly verified raw-original whole-domain conflict group, with the independently rederived current second-sheet capacity2. Verified transpose symmetry permits flattened-choice ordering of the three bracket and nine cog copies ONLY in this necessary master. Retain insert50 hint on part3 and sort only the nine cog hints into the verified order; hints remain advisory. Omit coordinates and original outside-plane constraints intentionally: a feasible master proves no anchor or physical layout. No old fixed57 cuts or solver call. Independent complete model reconstruction/import is required before one bounded necessary-master call.'})
    spec=load(SOURCE/'plan.json');queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']};model=cp_model_pb2.CpModelProto();parts=[];modes={}
    def var(name,lo=0,hi=1):i=len(model.variables);model.variables.add(name=name,domain=[lo,hi]);return i
    def lin(terms,lo=-2**63,hi=2**63-1):
        t=Counter()
        for v,c in terms:t[v]+=c
        ids=sorted(i for i in t if t[i]);c=model.constraints.add();c.linear.vars.extend(ids);c.linear.coeffs.extend(t[i] for i in ids);c.linear.domain.extend([lo,hi])
    for original in spec['parts']:
        pi=original['part'];sheet=var(f'p{pi}-sheet');total=sum(len(queries[q]['domains']) for q in original['queries']);choice=var(f'p{pi}-choice',0,total-1);pm=[];flat=[];offset=0
        for qi in original['queries']:
            active=var(f'p{pi}-q{qi}');flags=[var(f'p{pi}-q{qi}-d{i}') for i in range(len(queries[qi]['domains']))];lin([(f,1) for f in flags]+[(active,-1)],0,0);m={'query':qi,'active':active,'domains':flags,'choice_offset':offset};pm.append(m);modes[pi,qi]=m;flat.extend((f,offset+i) for i,f in enumerate(flags));offset+=len(flags)
        lin([(m['active'],1) for m in pm],1,1);lin([(sheet,1)]+[(m['active'],-spec['queries'][m['query']]['sheet']) for m in pm],0,0);lin([(choice,1)]+[(f,-i) for f,i in flat],0,0);parts.append({'part':pi,'item':original['index'],'family':original['family'],'sheet':sheet,'choice':choice,'modes':pm})
    rules=load(RULES);charges=rules['filled_area_lower_units'];total=sum(charges[p['family']] for p in parts);lin([(p['sheet'],-charges[p['family']]) for p in parts],hi=rules['stock_area_upper_units'][0]-rules['fixed_area_lower_units'][0]-total);lin([(p['sheet'],charges[p['family']]) for p in parts],hi=rules['stock_area_upper_units'][1]-rules['fixed_area_lower_units'][1]);cap=load(CAP/'certificate.json');assert cap['applicable_moving_parts']==list(range(4,13));lin([(modes[i,19]['active'],1) for i in cap['applicable_moving_parts']],hi=cap['capacity']);orders=load(CONFLICTS/'copy-symmetry/checks.json')['proposed_choice_order_pairs']
    for i,j in orders:lin([(parts[i]['choice'],1),(parts[j]['choice'],-1)],hi=0)
    details=[];literals=0;cp=load(CONFLICTS/'plan.json');groups={c['index']:load(CONFLICTS/'groups'/f"{c['index']:03d}.json") for c in cp['cases']}
    for pair in cp['physical_pair_case_uses']:
        ia,ib=pair['parts']
        for caseid in pair['cases']:
            row=groups[caseid];c=row['case'];qa,qb=modes[ia,c['query_a']],modes[ib,c['query_b']]
            for g in row['groups']:
                if not g['conflicts_per_a_row']:continue
                start_constraints=len(model.constraints);aa=[qa['domains'][i] for i in g['rows_a']];raw=bytes.fromhex(g['forbidden_b_hex']);bb=[qb['domains'][i] for i in range(c['rows_b']) if raw[i//8]&(1<<(7-i%8))];assert len(bb)==g['conflicts_per_a_row']
                if len(aa)==1:flag=aa[0]
                else:flag=var(f'group-{ia}-{ib}-{caseid}-{g["group"]}');lin([(f,1) for f in aa]+[(flag,-1)],0,0)
                constraint=model.constraints.add()
                if len(bb)==len(qb['domains']):constraint.bool_or.literals.extend([-flag-1,-qb['active']-1]);literals+=2
                else:constraint.at_most_one.literals.extend([flag]+bb);literals+=1+len(bb)
                details.append({'parts':[ia,ib],'case':caseid,'group':g['group'],'flag':flag,'constraint_span':[start_constraints,len(model.constraints)]})
    original_hints=load(SOURCE/'audit/verified-partial-domain-membership.json');source_hints=[]
    for r in original_hints:
        source_part=next(p for p in parts if p['item']==r['item']);qi=r['query'];row=r['matching_domains'][0]['row'];source_hints.append({**r,'domain_row':row,'choice_index':modes[source_part['part'],qi]['choice_offset']+row})
    insert=next(r for r in source_hints if r['item']==50);cogs=sorted([r for r in source_hints if r['item']!=50],key=lambda r:(r['choice_index'],r['anchor_units1000'],r['item']));assert len(cogs)==9;hints=[]
    for pi,r in [(3,insert)]+list(zip(range(4,13),cogs)):
        p=parts[pi];m=modes[pi,r['query']];values=[(p['sheet'],spec['queries'][r['query']]['sheet']),(p['choice'],r['choice_index']),(m['active'],1),(m['domains'][r['domain_row']],1)]
        for v,n in values:model.solution_hint.vars.append(v);model.solution_hint.values.append(n)
        hints.append({'source_partial_item':r['item'],'assigned_part':pi,'assigned_item':p['item'],'query':r['query'],'domain_row':r['domain_row'],'choice_index':r['choice_index'],'values':values})
    write(OUT/'mapping.json',{'parts':parts,'groups':details,'choice_order_pairs':orders});write(OUT/'advisory-hints.json',hints);(OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n');assert len(model.variables)==21093 and len(model.constraints)==13536 and literals==1641171
    result={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':len(model.solution_hint.vars),'domain_flags':14789,'query_modes':68,'fresh_conflict_auxiliaries':6210,'nonzero_physical_groups':len(details),'mutual_exclusion_literals':literals,'required_originals':66,'moving_originals':13,'fixed_originals':53,'original_coordinate_variables':0,'same_sheet_query_pair_modes':954,'verified_family_choice_order_constraints':len(orders),'scope':'Necessary master only; no anchor/layout feasibility.','model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
