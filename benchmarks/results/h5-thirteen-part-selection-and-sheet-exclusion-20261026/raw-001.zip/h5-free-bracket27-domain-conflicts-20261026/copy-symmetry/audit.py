"""Verify interchangeable copies in a necessary Boolean domain-selection master only."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,time,shutil,traceback
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free-bracket27-domain-conflicts-20261026';SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';OUT=BASE/'copy-symmetry'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();paths=[BASE/n for n in ['plan.json','result.json','audit/checks.json','groups/result.json','groups/audit/checks.json']]+[SOURCE/'plan.json',ROOT/'output/h5-free-bracket27-source-model-20261026/necessary-rules.json']+sorted((BASE/'cases').glob('*'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'For a proposed necessary domain-only master, verify that the three bracket copies have identical query/profile choices and the nine cogs have identical choices. Check every within-family query-pair conflict matrix equals the transpose of its reversed query pair, bit-for-bit, and that all cross-family physical uses exist independently of copy ID. Original area charges depend only on family/sheet. No inherited capacity is used. Therefore sorting flattened domain choices within each interchangeable family preserves this necessary master. This audit does NOT impose or assert label symmetry of the full coordinate-plane model and does NOT claim any anchor/layout feasibility.'})
    assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'groups/audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');census=load(BASE/'plan.json');byquery={(c['query_a'],c['query_b']):c for c in census['cases']};arrays={}
    for c in census['cases']:
        data=(BASE/'cases'/f"{c['index']:03d}.bin").read_bytes();meta=load(BASE/'cases'/f"{c['index']:03d}.json");assert sha256(data).hexdigest()==meta['packed_sha256'];a=np.unpackbits(np.frombuffer(data,dtype=np.uint8),bitorder='big');assert not np.any(a[c['domain_pairs']:]);arrays[c['index']]=a[:c['domain_pairs']].reshape(c['rows_a'],c['rows_b'])
    families={'bracket':[0,1,2],'cog':list(range(4,13))};rows=[];mismatches=[];bits=0;orders=[]
    for family,ids in families.items():
        parts=[spec['parts'][i] for i in ids];assert all(p['family']==family and p['queries']==parts[0]['queries'] and p['profiles']==parts[0]['profiles'] for p in parts);orders.extend([[a,b] for a,b in zip(ids,ids[1:])])
        for qa,qb in product(parts[0]['queries'],repeat=2):
            if spec['queries'][qa]['sheet']!=spec['queries'][qb]['sheet']:continue
            c,d=byquery[qa,qb],byquery[qb,qa];a,b=arrays[c['index']],arrays[d['index']].T;assert a.shape==b.shape;n=int(np.count_nonzero(a!=b));bits+=a.size;row={'family':family,'queries':[qa,qb],'cases':[c['index'],d['index']],'compared_bits':int(a.size),'mismatches':n};rows.append(row)
            if n:mismatches.append(row)
    expected=[]
    for i,a in enumerate(spec['parts']):
        for b in spec['parts'][i+1:]:expected.append({'parts':[a['part'],b['part']],'cases':[byquery[qa,qb]['index'] for qa,qb in product(a['queries'],b['queries']) if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']]})
    assert expected==census['physical_pair_case_uses'] and len(expected)==78 and sum(len(r['cases']) for r in expected)==954
    rules=load(ROOT/'output/h5-free-bracket27-source-model-20261026/necessary-rules.json');assert rules['filled_area_lower_units']['bracket']==40000000 and rules['filled_area_lower_units']['cog']==50062718
    write(OUT/'matrix-transpose-checks.json',rows);write(OUT/'mismatches.json',mismatches);checks={'passed':not mismatches,'seconds':time.perf_counter()-start,'scope':'Necessary domain-only master; not full coordinate-plane model or actual layout.','interchangeable_bracket_parts':families['bracket'],'interchangeable_cog_parts':families['cog'],'transpose_cases_checked':len(rows),'matrix_bits_compared':bits,'asymmetric_query_pairs':len(mismatches),'physical_pair_inventory_verified':78,'physical_query_modes_verified':954,'family_sheet_area_charges_invariant':True,'no_capacity_transferred':True,'proposed_choice_order_pairs':orders,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
