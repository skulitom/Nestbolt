"""Whole-rectangle verification of the complete original collision bit tables."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product,combinations
import json,math,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import shape,MultiPoint
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';BASE=ROOT/'output/h5-free-bracket27-domain-conflicts-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();(OUT/'cases').mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    plan=load(BASE/'plan.json');spec=load(SOURCE/'plan.json');result=load(BASE/'result.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':240,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(BASE.rglob('*')) if p.is_file() and OUT not in p.parents},
        'method':'Verify new query hashes against their independent fresh domain audit and unchanged mutual geometry against committed hashes, reconstruct all82 raw original Minkowski obstacles independently from unmerged triangle pairs, and prove every stored inset core is strictly inside this independent raw geometry. Reconstruct the full164-case/954-use/78-physical-pair census. Decode every packed matrix bit with exact row order and zero trailing padding. Re-evaluate the stated whole-rectangle inset criterion for every tested domain pair; for every marked exclusion also prove the whole outward-padded difference rectangle is strictly inside the independent raw original obstacle. The polygon predicate checks the whole rectangle, not only its corners. Verify1-micrometre outward integer padding dominates every possible float conversion error. No untested pair is called incompatible; no solver call.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    manifest=load(ROOT/'benchmarks/results/h5-expanded-cog-neighborhood-20261026/raw-manifest.json')
    certified={r['sha256'] for r in manifest['files']+manifest['aliases']};fresh=load(SOURCE/'audit/plan.json')['inputs'];assert load(SOURCE/'audit/checks.json')['passed']
    for n,h in fresh.items():assert digest(ROOT/n)==h,n
    queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']}
    for i in queries:
        p=SOURCE/'queries'/f'{i:03d}.json';assert digest(p)==plan['query_hashes'][str(i)]==fresh[p.relative_to(ROOT).as_posix()]
    profiles=load(SOURCE/'profiles.json');ts={}
    for p in profiles:
        g=shape(p['geometry']);triangles=list(shapely.constrained_delaunay_triangles(g).geoms);assert unary_union(triangles).equals(g);ts[p['index']]=triangles
    raws={};cores={};rawchecks=[];hulls=0
    for c in spec['mutual_cases']:
        assert time.perf_counter()-start<240
        p=SOURCE/'mutual'/f"{c['index']:03d}.json";assert digest(p)==plan['mutual_hashes'][str(c['index'])] and digest(p) in certified
        pieces=[MultiPoint([(x-u,y-v) for x,y in list(a.exterior.coords)[:-1] for u,v in list(b.exterior.coords)[:-1]]).convex_hull for a,b in product(ts[c['profile_a']],ts[c['profile_b']])]
        raw=unary_union(pieces);stored=shape(load(p)['raw_forbidden']);error=raw.hausdorff_distance(stored);assert error<1e-7 and raw.symmetric_difference(stored).area<1e-4
        row=load(BASE/'cores'/f"{c['index']:03d}.json");core=shape(row['core']);assert row['case']==c and row['raw_original_sha256']==digest(p)
        assert core.equals_exact(stored.buffer(-.0001,join_style='mitre').intersection(stored),0)
        assert raw.contains_properly(core);margin=raw.boundary.distance(core);assert margin>=.00009
        shapely.prepare(raw);shapely.prepare(core);raws[c['index']]=raw;cores[c['index']]=core;hulls+=len(pieces)
        rawchecks.append({'case':c['index'],'unmerged_triangle_pair_hulls':len(pieces),'raw_hausdorff_error_mm':error,'independent_interior_margin_mm':margin})
    write(OUT/'raw-checks.json',rawchecks)
    wanted=sorted({(qa,qb) for a,b in combinations(spec['parts'],2) for qa,qb in product(a['queries'],b['queries']) if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']})
    assert wanted==[(c['query_a'],c['query_b']) for c in plan['cases']] and len(wanted)==164
    ci={t:i for i,t in enumerate(wanted)};uses=[];mc={(r['profile_a'],r['profile_b']):r['index'] for r in spec['mutual_cases']}
    for a,b in combinations(spec['parts'],2):uses.append({'parts':[a['part'],b['part']],'cases':[ci[(qa,qb)] for qa,qb in product(a['queries'],b['queries']) if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']]})
    assert uses==plan['physical_pair_case_uses'] and sum(len(r['cases']) for r in uses)==954
    assert result['remaining_domain_pairs']==0 and not load(BASE/'pending-cases.json')
    # All coordinate differences plus the one-unit guard stay below3001mm.
    # IEEE754 nearest rounding error is at most one ULP, far below1/1000mm.
    assert F(math.ulp(3001.0))<F(1,1000) and plan['difference_rectangle_padding_units']==1
    checks=[];tested=excluded=0
    for c in plan['cases']:
        assert time.perf_counter()-start<240
        row=load(BASE/'cases'/f"{c['index']:03d}.json");assert all(row[k]==v for k,v in c.items())
        a,b=queries[c['query_a']]['domains'],queries[c['query_b']]['domains'];qa,qb=spec['queries'][c['query_a']],spec['queries'][c['query_b']]
        assert qa['sheet']==qb['sheet']==c['sheet'] and mc[(qa['profile'],qb['profile'])]==c['mutual_case']
        assert [r['index'] for r in a]==row['domain_indices_a'] and [r['index'] for r in b]==row['domain_indices_b']
        assert c['rows_a']==len(a)==row['tested_rows_a'] and c['rows_b']==len(b) and row['remaining_rows_a']==0 and row['tested_domain_pairs']==len(a)*len(b)
        binary=BASE/'cases'/f"{c['index']:03d}.bin";assert digest(binary)==row['packed_sha256'] and binary.stat().st_size==row['packed_bytes']==(len(a)*len(b)+7)//8
        flags=np.unpackbits(np.frombuffer(binary.read_bytes(),dtype=np.uint8),bitorder='big');assert not np.any(flags[len(a)*len(b):]);flags=flags[:len(a)*len(b)].reshape(len(a),len(b))
        aa=np.array([r['coordinate_bounds'] for r in a],dtype=np.int64).reshape(-1,4);bb=np.array([r['coordinate_bounds'] for r in b],dtype=np.int64).reshape(-1,4);count=0
        for offset in range(0,len(a),32):
            assert time.perf_counter()-start<240
            left=aa[offset:offset+32]
            lo=bb[None,:,:2]-left[:,None,2:]-1;hi=bb[None,:,2:]-left[:,None,:2]+1
            assert np.all(lo<hi) and np.max(np.abs(lo))<=3000001 and np.max(np.abs(hi))<=3000001
            boxes=shapely.box(lo[:,:,0]/1000,lo[:,:,1]/1000,hi[:,:,0]/1000,hi[:,:,1]/1000)
            marked=flags[offset:offset+len(left)].astype(bool)
            expected=shapely.contains_properly(cores[c['mutual_case']],boxes);assert np.array_equal(expected,marked)
            if np.any(marked):assert np.all(shapely.contains_properly(raws[c['mutual_case']],boxes[marked]))
            count+=int(np.count_nonzero(marked))
        assert count==row['conflicts'];tested+=len(a)*len(b);excluded+=count
        check={'case':c['index'],'whole_domain_pair_rectangles_checked':len(a)*len(b),'strict_original_collision_exclusions':count,'all_packed_bits_reproduced':True,
            'every_exclusion_inside_independent_raw_original':True};write(OUT/'cases'/f"{c['index']:03d}.json",check);checks.append(check)
        if len(checks)%40==0:print({'cases_audited':len(checks),'pairs_audited':tested,'seconds':time.perf_counter()-start},flush=True)
    assert tested==result['tested_domain_pairs']==plan['complete_domain_pair_census'] and excluded==result['certified_conflicts']
    summary={'passed':True,'seconds':time.perf_counter()-start,'fresh_queries_and_committed_mutual_files_verified':102,'raw_original_triangle_pair_hulls':hulls,
        'maximum_independent_raw_error_mm':max(r['raw_hausdorff_error_mm'] for r in rawchecks),'minimum_independent_raw_interior_margin_mm':min(r['independent_interior_margin_mm'] for r in rawchecks),
        'complete_query_pair_cases':164,'physical_part_pairs':78,'physical_query_pair_uses':954,'whole_domain_pair_rectangles_checked':tested,'strict_original_collision_exclusions':excluded,
        'all_packed_bits_and_padding_verified':True,'all_exclusions_covered_by_whole_original_obstacle':True,'all_integer_difference_rectangles_padded_outward':True,
        'pending_cases':0,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',summary);print(summary,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
