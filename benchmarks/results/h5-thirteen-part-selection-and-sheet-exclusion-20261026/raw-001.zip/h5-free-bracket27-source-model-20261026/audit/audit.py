"""Independently reconstruct every constraint and variable from audited source geometry."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction
from math import gcd,ceil,floor
from itertools import combinations,product
from collections import Counter
import json,time,shutil,traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free-bracket27-source-model-20261026';SOURCE=ROOT/'output/h5-free-bracket27-joint-prepared-20261026';REG=ROOT/'output/h5-free-bracket27-fixed-regions-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Verify all fresh source hashes and independent domain audit. Reconstruct every variable, every mandatory domain/mode/sheet/choice equation, every bound/inside plane, both exact original-area inequalities without any inherited capacity, all78 physical pairs/954 nonempty query modes, every full source face with independent signed-interval extrema, normalized one-sided direction and OR. Check entire model fields, all original-copy advisory hints and real solver import/export. No builder helpers or solver call.'})
    committed=0
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n;committed+=1
    for n,h in load(SOURCE/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');mapping=load(BASE/'mapping.json');rules=load(BASE/'necessary-rules.json');parts=mapping['parts'];assert len(parts)==len(spec['parts'])==13 and len(spec['fixed_items'])==53 and sorted(spec['fixed_items']+[p['index'] for p in spec['parts']])==list(range(66))
    model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'model.pb').read_bytes());assert {f.name for f,v in model.ListFields()}=={'variables','constraints','solution_hint'};vc=cc=0
    def variable(index,name,lo=0,hi=1):
        nonlocal vc
        assert index==vc,(index,vc);v=model.variables[index];assert v==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]);vc+=1
    def linear(terms,lo=-2**63,hi=2**63-1,en=()):
        nonlocal cc
        t={}
        for v,c in terms:t[v]=t.get(v,0)+c
        ids=sorted(i for i in t if t[i]);c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(ids);c.linear.coeffs.extend(t[i] for i in ids);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(en);assert model.constraints[cc]==c,('constraint',cc);cc+=1
    def clause(literals):
        nonlocal cc
        c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend(literals);assert model.constraints[cc]==c,cc;cc+=1
    queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']};boxes={}
    for qi,q in queries.items():
        if not q['domains']:continue
        boxes[qi]=[min(d['coordinate_bounds'][0] for d in q['domains']),min(d['coordinate_bounds'][1] for d in q['domains']),max(d['coordinate_bounds'][2] for d in q['domains']),max(d['coordinate_bounds'][3] for d in q['domains'])]
    assert {int(k):v for k,v in mapping['query_bounds'].items()}==boxes;modes={};domain_count=0
    for original,p in zip(spec['parts'],parts):
        pi=original['part'];assert p['part']==pi and p['item']==original['index'] and p['family']==original['family'] and p['variable_span'][0]==vc and p['constraint_span'][0]==cc
        b=[min(boxes[q][0] for q in original['queries'] if q in boxes),min(boxes[q][1] for q in original['queries'] if q in boxes),max(boxes[q][2] for q in original['queries'] if q in boxes),max(boxes[q][3] for q in original['queries'] if q in boxes)];total=sum(len(queries[q]['domains']) for q in original['queries'] if q in boxes);variable(p['sheet'],f'p{pi}-sheet');variable(p['choice'],f'p{pi}-choice',0,total-1);variable(p['x'],f'p{pi}-x',b[0],b[2]);variable(p['y'],f'p{pi}-y',b[1],b[3]);offset=0;allflags=[]
        assert [m['query'] for m in p['modes']]==original['queries']
        for m in p['modes']:
            qi=m['query'];assert m['choice_offset']==offset;variable(m['active'],f'p{pi}-q{qi}');ds=queries[qi]['domains'];assert len(ds)==len(m['domains']);modes[pi,qi]=m
            for row,(d,flag) in enumerate(zip(ds,m['domains'])):
                variable(flag,f'p{pi}-q{qi}-d{row}');allflags.append((flag,offset+row));b=d['coordinate_bounds'];linear([(p['x'],1)],b[0],b[2],[flag]);linear([(p['y'],1)],b[1],b[3],[flag])
                for h in d['halfplanes']:assert h['sense']=='le';linear([(p['x'],h['a']),(p['y'],h['b'])],hi=h['bound'],en=[flag])
            linear([(f,1) for f in m['domains']]+[(m['active'],-1)],0,0);offset+=len(ds);domain_count+=len(ds)
        linear([(m['active'],1) for m in p['modes']],1,1);linear([(p['sheet'],1)]+[(m['active'],-spec['queries'][m['query']]['sheet']) for m in p['modes']],0,0);linear([(p['choice'],1)]+[(f,-i) for f,i in allflags],0,0)
        assert p['variable_span'][1]==vc and p['constraint_span'][1]==cc
    assert vc==mapping['base_variables'] and cc==mapping['base_constraints'] and mapping['simultaneous_original_coordinates']==[{'part':p['part'],'x':p['x'],'y':p['y']} for p in parts]
    job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');charges={}
    for p in job['parts']:
        area=Fraction(0)
        for g in p['geometry']:
            points=[tuple(Fraction(v) for v in xy) for xy in g['outer']];twice=Fraction(0)
            for i,(x,y) in enumerate(points):nx,ny=points[(i+1)%len(points)];twice+=x*ny-y*nx
            area+=abs(twice)/2
        charges[p['id']]=floor(area*1000)
    geom=load(ROOT/'output/h5-source-orientation-construction-20261025/geometry.json');caps=[]
    for box in geom['stock_bounds_rational']:
        x0,y0,x1,y1=[Fraction(*p) for p in box];caps.append(floor(1000*(x1-x0)*(y1-y0)))
    fixed=load(REG/'fixed-originals.json');fixed_area=[sum(charges[p['family']] for p in fixed if p['sheet']==s) for s in (0,1)];total=sum(charges[p['family']] for p in parts);assert charges==rules['filled_area_lower_units'] and caps==rules['stock_area_upper_units'] and fixed_area==rules['fixed_area_lower_units']==spec['fixed_original_area_units_per_sheet'] and total==rules['moving_area_lower_units']
    assert rules['constraint_span']==[cc,cc+2];linear([(p['sheet'],-charges[p['family']]) for p in parts],hi=caps[0]-fixed_area[0]-total);linear([(p['sheet'],charges[p['family']]) for p in parts],hi=caps[1]-fixed_area[1])
    inventory=[]
    for a,b in combinations(spec['parts'],2):
        for qa,qb in product(a['queries'],b['queries']):
            if qa in boxes and qb in boxes and spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']:
                case=next(c['index'] for c in spec['mutual_cases'] if (c['profile_a'],c['profile_b'])==(spec['queries'][qa]['profile'],spec['queries'][qb]['profile']));inventory.append((a['part'],b['part'],qa,qb,case))
    assert len(inventory)==len(mapping['source_pair_faces'])==954;cache={};shared={};defs=[];counts=Counter();source_faces=0
    for want,pair in zip(inventory,mapping['source_pair_faces']):
        ia,ib,qa,qb,case=want;assert pair['parts']==[ia,ib] and pair['query_a']==qa and pair['query_b']==qb and pair['mutual_case']==case and pair['variable_span'][0]==vc and pair['constraint_span'][0]==cc;a,b=parts[ia],parts[ib];active=pair['active'];variable(active,f'pair-{ia}-{ib}-{qa}-{qb}');ma,mb=modes[ia,qa]['active'],modes[ib,qb]['active'];linear([(active,1),(ma,-1)],hi=0);linear([(active,1),(mb,-1)],hi=0);linear([(active,1),(ma,-1),(mb,-1)],lo=-1)
        ba,bb=boxes[qa],boxes[qb];box=[bb[0]-ba[2],bb[1]-ba[3],bb[2]-ba[0],bb[3]-ba[1]];assert box==pair['difference_bounds'];linear([(b['x'],1),(a['x'],-1)],box[0],box[2],[active]);linear([(b['y'],1),(a['y'],-1)],box[1],box[3],[active])
        if case not in cache:cache[case]=load(SOURCE/'mutual'/f'{case:03d}.json')
        clauses=[]
        for face in cache[case]['faces']:
            source_faces+=1;intervals=[]
            for h in face['outside_halfplanes']:
                lower=h['a']*box[0 if h['a']>=0 else 2]+h['b']*box[1 if h['b']>=0 else 3];upper=h['a']*box[2 if h['a']>=0 else 0]+h['b']*box[3 if h['b']>=0 else 1];intervals.append((lower,upper))
            if any(z[0]>=h['bound'] for z,h in zip(intervals,face['outside_halfplanes'])):counts['whole_box_tautological_faces']+=1;continue
            live=[i for i,z in enumerate(intervals) if z[1]>=face['outside_halfplanes'][i]['bound']];directions=[]
            if not live:linear([(active,1)],0,0);counts['impossible_faces']+=1
            elif len(live)==1:
                h=face['outside_halfplanes'][live[0]];linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],lo=h['bound'],en=[active]);counts['singleton_faces']+=1
            else:
                for edge in live:
                    h=face['outside_halfplanes'][edge];g=gcd(h['a'],h['b']);assert g>0;A,B,C=h['a']//g,h['b']//g,ceil(Fraction(h['bound'],g));key=(ia,ib,A,B,C)
                    if key not in shared:
                        flag=vc;variable(flag,f'direction-{len(shared)}');shared[key]=flag;defs.append({'flag':flag,'parts':[ia,ib],'a':A,'b':B,'bound':C,'constraint':cc});linear([(b['x'],A),(a['x'],-A),(b['y'],B),(a['y'],-B)],lo=C,en=[flag])
                    directions.append({'edge':edge,'flag':shared[key]});counts['direction_uses']+=1
                clause([-active-1]+sorted(set(d['flag'] for d in directions)));counts['disjunctive_faces']+=1
            clauses.append({'face':face['index'],'live_edges':live,'directions':directions})
        assert clauses==pair['clauses'] and pair['constraint_span'][1]==cc and pair['variable_span'][1]==vc
    assert vc==len(model.variables) and cc==len(model.constraints) and defs==load(BASE/'shared-directions.json');hint_pairs=[];hint_records=[]
    for r in load(SOURCE/'audit/verified-partial-domain-membership.json'):
        p=next(p for p in parts if p['item']==r['item']);m=modes[p['part'],r['query']];row=min(v['row'] for v in r['matching_domains']);x,y=r['anchor_units1000'];d=queries[r['query']]['domains'][row];assert all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes']);values=[[p['sheet'],spec['queries'][r['query']]['sheet']],[p['choice'],m['choice_offset']+row],[m['active'],1],[m['domains'][row],1],[p['x'],x],[p['y'],y]];hint_pairs+=values;hint_records.append({'item':r['item'],'part':p['part'],'query':r['query'],'domain_row':row,'values':values})
    assert hint_records==load(BASE/'advisory-hints.json') and [v for v,n in hint_pairs]==list(model.solution_hint.vars) and [n for v,n in hint_pairs]==list(model.solution_hint.values) and len(hint_pairs)==60
    flags=set(shared.values());positive_or=Counter();en=Counter()
    for c in model.constraints:
        for v in c.enforcement_literal:
            if (v if v>=0 else -v-1) in flags:assert v in flags and list(c.enforcement_literal)==[v];en[v]+=1
        kind=c.WhichOneof('constraint');assert kind in ['linear','bool_or']
        if kind=='linear':assert not flags.intersection(c.linear.vars)
        else:
            for v in c.bool_or.literals:
                if (v if v>=0 else -v-1) in flags:assert v in flags;positive_or[v]+=1
    assert set(en)==set(positive_or)==flags and all(n==1 for n in en.values());assert digest(BASE/'model.pb')==load(BASE/'result.json')['model_sha256']
    for key,n in counts.items():assert load(BASE/'result.json')[key]==n
    actual=cp_model.CpModel();assert actual.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and actual.validate()=='' and actual.export_to_file(str(OUT/'solver-import-roundtrip.pb'));readback=cp_model_pb2.CpModelProto();readback.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert readback==model
    write(OUT/'projection-proof.json',{'mandatory_inventory':'Exactly one query and domain is selected for each of13 physical originals. The fixed53 and these13 partition all66 original item IDs. Every active domain enforces original stock/fixed-obstacle source halfplanes on its own anchor.','full_pair_relations':'All unordered physical pairs have every nonempty same-sheet query combination; empty-query flags are forced false. Active is exactly the conjunction of the two modes. Signed intervals remove only necessarily true faces or impossible edges over the whole implied difference box. Remaining singleton and OR clauses cover every original forbidden face.','shared_flag_projection':'Each true shared flag implies precisely its normalized source plane. Active face ORs therefore imply an actual outside edge. Conversely any anchors satisfying all original clauses can assign every shared flag to actual plane truth. Identical planes are shared only within one ordered physical pair. No complement definition or mode activation is needed for that existential assignment.','scope':'Finite source orientations, conservative inward integer domains and53 unchanged fixed poses; no unrestricted-packing or production-budget guarantee. Hints are advisory. No old fixed57 exclusions, copy-order cuts or witness locks.'})
    checks={'passed':True,'seconds':time.perf_counter()-start,'fresh_source_inputs_verified':committed,'variables':vc,'constraints':cc,'hints':60,'required_originals':66,'moving_originals':13,'fixed_originals':53,'base_domain_flags':domain_count,'original_anchor_variables':26,'physical_pairs':78,'same_sheet_pair_modes':954,'original_forbidden_face_uses':source_faces,'shared_direction_flags':len(shared),'positive_direction_OR_uses':sum(positive_or.values()),**counts,'every_variable_and_constraint_independently_reconstructed':True,'all_original_full_guarded_source_clauses_retained':True,'one_sided_existential_projection_verified':True,'no_old_capacity_transferred':True,'necessary_area_rules':2,'actual_solver_import_export_verified':True,'copy_symmetry_exclusions':0,'coordinate_locks':0,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
