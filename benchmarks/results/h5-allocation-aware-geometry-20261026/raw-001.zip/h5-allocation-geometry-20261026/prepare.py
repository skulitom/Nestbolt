"""Necessary two-sheet geometry with variable allocations and all real cog rotations."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-allocation-geometry-20261026'
OLD=ROOT/'output/h5-rotation-independent-geometry-20261026'
FRONT=ROOT/'output/h5-global-short-frontier-20261026'
SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026/profiles.json'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
CERT=ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def disk_strips(radius,count=16):
    levels=[-radius+2*radius*k//count for k in range(count+1)];rects=[]
    for lo,hi in zip(levels,levels[1:]):
        a,b=lo+1,hi-1;reach=math.isqrt(radius*radius-max(a*a,b*b))-1
        assert reach>0 and a<b
        rects.append([-reach,a,reach,b])
    return rects
assert load(OLD/'audit/checks.json')['passed'] and load(FRONT/'audit/checks.json')['passed'] and load(CERT)['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[JOB,SOURCE,CERT]+[OLD/n for n in ['profiles.json','original-cog-proof.json','audit/checks.json','audit/necessity-proof.json']]+[FRONT/n for n in ['allocations.json','audit/checks.json','plan.json','area-proof.json','cog-spacing.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'solver_calls':0,'preparation_seconds':30,'originals_required':66,'fixed_short_sheet':False,
    'method':'Prepare a coupled allocation model from source-only necessities. Keep all454 surviving short count vectors, not only32 Pareto vectors. Allow all8 bracket quarter-turn/mirror outlines, both rectangular insert/frame outlines, and every real cog angle via the audited rotation-independent quantization-safe disk. Non-cog inner rectangles retain2-micrometre insets for coordinate flooring. Keep the original material target, relaxing necessary stock bounds outward by0.020mm and short top to319.42699mm only for mathematical necessity, never for source acceptance. Derive16 horizontal inner-disk strips for cog/non-cog capacity and separate16 virtual separation-disk strips from the audited254297um cog-center separation. Virtual strips constrain cog/cog capacity ONLY and are never treated as source-contained against other families. No original is omitted; all frames stay first because their minimum350mm height exceeds short height. A necessary positive cannot be accepted without choosing actual source angles and full66 original geometry/native validation.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};old=load(OLD/'profiles.json');source={p['index']:p for p in load(SOURCE)}
proof=load(OLD/'original-cog-proof.json');r=proof['quantization_safe_radius_units1000'];h=proof['all_angle_stock_support_radius_units1000'];D=load(CERT)['rounded_center_separation_units1000'];v=D//2
assert r==109113 and h==139270 and D==254297 and 2*v<=D and v<h
stocks=[]
for top in [F(2993.5),F('319.42699')]:
    raw=[F('6.5'),F('6.5'),F('1493.5'),top];relaxed=[raw[0]-F('.02'),raw[1]-F('.02'),raw[2]+F('.02'),raw[3]+F('.02')]
    stocks.append({'target_bounds_rational':[[x.numerator,x.denominator] for x in raw],
                   'relaxed_bounds_rational':[[x.numerator,x.denominator] for x in relaxed],
                   'capacity_um':[math.ceil((relaxed[2]-relaxed[0])*1000),math.ceil((relaxed[3]-relaxed[1])*1000)]})
variants=[]
for p in old:
    if p['family']=='cog':continue
    s=source[p['index']]
    variants.append({'id':len(variants),'family':p['family'],'source_profile':p['index'],
        'quarter_turn':s['quarter_turn'],'mirrored':s['mirrored'],
        'anchor':'oriented lower-left','original_bounds_um':[round(x*1000) for x in p['original_bounds']],
        'coarse_rectangles_um':p['rectangles_units1000'],'source_capacity_rectangles_um':p['rectangles_units1000']})
assert len(variants)==10
for quarter,w,hh in [(0,450000,350000),(1,350000,450000)]:
    variants.append({'id':len(variants),'family':'frame','quarter_turn':quarter,'mirrored':False,
        'anchor':'oriented lower-left','original_bounds_um':[0,0,w,hh],
        'coarse_rectangles_um':[[2,2,w-2,hh-2]],'source_capacity_rectangles_um':[[2,2,w-2,hh-2]]})
variants.append({'id':len(variants),'family':'cog','quarter_turn':None,'mirrored':False,
    'anchor':'source center','all_real_angles':True,'coarse_rectangles_um':[[-76500,-76500,76500,76500]],
    'source_capacity_rectangles_um':disk_strips(r),'separation_capacity_rectangles_um':disk_strips(v),
    'source_disk_radius_um':r,'stock_support_radius_um':h,'rounded_center_separation_um':D,
    'separation_disk_radius_um':v,'separation_strips_are_not_source_contained':True})
domains=[]
for variant in variants:
    for sheet,stock in enumerate(stocks):
        s=[F(*x)*1000 for x in stock['relaxed_bounds_rational']]
        if variant['family']=='cog':bounds=[math.floor(s[0]+h),math.floor(s[1]+h),math.floor(s[2]-h),math.floor(s[3]-h)]
        else:
            b=variant['original_bounds_um'];bounds=[math.floor(s[0]-b[0]),math.floor(s[1]-b[1]),math.floor(s[2]-b[2]),math.floor(s[3]-b[3])]
        allowed=bounds[0]<=bounds[2] and bounds[1]<=bounds[3]
        domains.append({'variant':variant['id'],'sheet':sheet,'bounds_um':bounds,'allowed':allowed})
allocations=[r for r in load(FRONT/'allocations.json') if r['excluded_by'] is None]
assert len(allocations)==454 and len({tuple(r['short_counts']) for r in allocations})==454
originals=[{'index':i,'family':family,'copy_index':copy} for i,(family,copy) in enumerate((family,copy) for family in ['frame','bracket','insert','cog'] for copy in range(parts[family]['quantity']))]
assert len(originals)==66 and all(not d['allowed'] for d in domains if d['sheet']==1 and variants[d['variant']]['family']=='frame')
write(OUT/'stocks.json',stocks);write(OUT/'variants.json',variants);write(OUT/'domains.json',domains)
write(OUT/'allowed-allocations.json',allocations);write(OUT/'originals.json',originals)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'originals':66,'geometry_variants':len(variants),
    'source_variant_sheet_domains':len(domains),'allowed_variant_sheet_domains':sum(d['allowed'] for d in domains),
    'short_count_vectors':454,'fixed_short_sheet':False,'all_real_cog_angles':True,
    'source_cog_disk_radius_um':r,'virtual_cog_separation_radius_um':v,
    'source_disk_strip_area_mm2':sum((b[2]-b[0])*(b[3]-b[1]) for b in variants[-1]['source_capacity_rectangles_um'])/1e6,
    'virtual_disk_strip_area_mm2':sum((b[2]-b[0])*(b[3]-b[1]) for b in variants[-1]['separation_capacity_rectangles_um'])/1e6,
    'solver_calls':0,'native_calls':0,'full_source_fit_claimed':False,'H5_complete':False})
print(load(OUT/'prepared.json'))
