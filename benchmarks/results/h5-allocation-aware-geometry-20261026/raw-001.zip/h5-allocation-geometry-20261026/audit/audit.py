"""Exact-grid non-cog and exact-integer disk audit for allocation-aware necessities."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-allocation-geometry-20261026';OUT=BASE/'audit'
OLD=ROOT/'output/h5-rotation-independent-geometry-20261026';FRONT=ROOT/'output/h5-global-short-frontier-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def turn(x,y,q):return [(x,y),(-y,x),(-x,-y),(y,-x)][q]
def inside(x,y,ring):
    odd=False
    for (a,b),(c,d) in zip(ring,ring[1:]+ring[:1]):
        if (b>y)!=(d>y) and x<F(c-a,d-b)*(y-b)+a:odd=not odd
    return odd
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']}
variants=load(BASE/'variants.json');stocks=load(BASE/'stocks.json');domains=load(BASE/'domains.json')
originals=load(BASE/'originals.json');allocations=load(BASE/'allowed-allocations.json')
assert len(originals)==66 and sorted((r['family'],r['copy_index']) for r in originals)==sorted((p['id'],i) for p in job['parts'] for i in range(p['quantity']))
assert [r['index'] for r in originals]==list(range(66))
assert len(variants)==13 and [r['id'] for r in variants]==list(range(13))
assert len(domains)==26 and {(d['variant'],d['sheet']) for d in domains}=={(i,s) for i in range(13) for s in [0,1]}
cell_checks=rects=0;mode_sets={};disk_corners=0
for v in variants:
    if v['family']=='cog':continue
    q=v['quarter_turn'];mi=-1 if v['mirrored'] else 1;p=parts[v['family']]
    assert q*90 in p['rotations']['degrees'] and (not v['mirrored'] or p['allow_mirror'])
    ring=[turn(F(x)*mi,F(y),q) for x,y in p['geometry'][0]['outer']]
    low=[min(p[k] for p in ring) for k in [0,1]]
    scaled=[[(p[k]-low[k])*1000 for k in [0,1]] for p in ring]
    assert all(t.denominator==1 for p in scaled for t in p)
    ring=[tuple(map(int,p)) for p in scaled]
    assert all(a==c or b==d for (a,b),(c,d) in zip(ring,ring[1:]+ring[:1]))
    bounds=[min(p[k] for p in ring) for k in [0,1]]+[max(p[k] for p in ring) for k in [0,1]]
    assert bounds==v['original_bounds_um']
    assert v['source_capacity_rectangles_um']==v['coarse_rectangles_um']
    for b in v['coarse_rectangles_um']:
        assert all(type(t) is int for t in b) and b[0]<b[2] and b[1]<b[3]
        expanded=[b[0]-1,b[1]-1,b[2]+1,b[3]+1]
        xs=sorted({expanded[0],expanded[2]}|{p[0] for p in ring if expanded[0]<p[0]<expanded[2]})
        ys=sorted({expanded[1],expanded[3]}|{p[1] for p in ring if expanded[1]<p[1]<expanded[3]})
        for a,c in zip(xs,xs[1:]):
            for b0,d in zip(ys,ys[1:]):assert inside(F(a+c,2),F(b0+d,2),ring);cell_checks+=1
        rects+=1
    for a,b in combinations(v['coarse_rectangles_um'],2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
    mode_sets.setdefault(v['family'],set()).add((q,v['mirrored']))
assert mode_sets['bracket']=={(q,m) for q in range(4) for m in [False,True]}
assert mode_sets['insert']==mode_sets['frame']=={(0,False),(1,False)}
for family in ['frame','insert']:
    raw=parts[family]['geometry'][0]['outer']
    bounds=[min(p[k] for p in raw) for k in [0,1]]+[max(p[k] for p in raw) for k in [0,1]]
    assert set(map(tuple,raw))=={(bounds[a],bounds[b]) for a in [0,2] for b in [1,3]}
    # Half-turns have identical filled rectangular outer geometry; holes stay reserved.
proof=load(OLD/'original-cog-proof.json');cert=load(ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json')
v=variants[-1];assert v['family']=='cog' and parts['cog']['rotations']['kind']=='free' and v['all_real_angles']
r=proof['quantization_safe_radius_units1000'];h=proof['all_angle_stock_support_radius_units1000'];D=cert['rounded_center_separation_units1000'];virtual=v['separation_disk_radius_um']
assert v['source_disk_radius_um']==r and v['stock_support_radius_um']==h and v['rounded_center_separation_um']==D
assert 2*virtual<=D and virtual<h and v['separation_strips_are_not_source_contained']
for field,radius in [('coarse_rectangles_um',r),('source_capacity_rectangles_um',r),('separation_capacity_rectangles_um',virtual)]:
    rows=v[field]
    assert len(rows)==(1 if field=='coarse_rectangles_um' else 16)
    for a,b,c,d in rows:
        assert all(type(t) is int for t in [a,b,c,d]) and a<c and b<d
        for x in [a,c]:
            for y in [b,d]:assert x*x+y*y<=radius*radius;disk_corners+=1
    for a,b in combinations(rows,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
stock_domain_checks=0;virtual_edge_checks=0
for s,stock in enumerate(stocks):
    raw=list(map(lambda r:F(*r),stock['target_bounds_rational']));relaxed=list(map(lambda r:F(*r),stock['relaxed_bounds_rational']))
    assert raw==[F('6.5'),F('6.5'),F('1493.5'),F('2993.5') if s==0 else F('319.42699')]
    assert relaxed==[raw[0]-F('.02'),raw[1]-F('.02'),raw[2]+F('.02'),raw[3]+F('.02')]
    assert stock['capacity_um']==[math.ceil((relaxed[2]-relaxed[0])*1000),math.ceil((relaxed[3]-relaxed[1])*1000)]
for d in domains:
    v=variants[d['variant']];s=[F(*x)*1000 for x in stocks[d['sheet']]['relaxed_bounds_rational']]
    if v['family']=='cog':wanted=[math.floor(s[0]+h),math.floor(s[1]+h),math.floor(s[2]-h),math.floor(s[3]-h)]
    else:
        b=v['original_bounds_um'];wanted=[math.floor(s[0]-b[0]),math.floor(s[1]-b[1]),math.floor(s[2]-b[2]),math.floor(s[3]-b[3])]
    assert d['bounds_um']==wanted and d['allowed']==(wanted[0]<=wanted[2] and wanted[1]<=wanted[3]);stock_domain_checks+=4
    if v['family']=='frame' and d['sheet']==1:assert not d['allowed']
    if v['family']=='cog':
        assert wanted[0]-virtual>=s[0] and wanted[1]-virtual>=s[1] and wanted[2]+virtual<=s[2] and wanted[3]+virtual<=s[3];virtual_edge_checks+=4
expected=[r for r in load(FRONT/'allocations.json') if r['excluded_by'] is None]
assert allocations==expected and len(allocations)==454
for a in allocations:
    b,i,c=a['short_counts'];assert a['first_counts']==[18,12-b,21-i,15-c]
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'all66_originals_verified':True,
    'source_geometry_variants_verified':13,'all_bracket_orientations_verified':8,
    'frame_insert_half_turn_outer_equivalence_verified':True,'exact_quantization_safe_non_cog_rectangles':rects,
    'exact_grid_cells_checked':cell_checks,'all_angle_disk_integer_corners_checked':disk_corners,
    'source_disk_strips':16,'virtual_separation_disk_strips':16,
    'virtual_disks_nonoverlap_for_cogs_from_certified_center_distance':True,
    'virtual_disks_not_a_mixed_family_collision_proxy':True,'virtual_disk_stock_edges_checked':virtual_edge_checks,
    'domain_endpoints_verified':stock_domain_checks,'allowed_domains':sum(d['allowed'] for d in domains),
    'short_allocations_verified':454,'complementary_first_counts_verified':454,
    'actual_source_short_top_mm':319.4269023299994,'outward_necessary_short_top_mm':319.42699,
    'necessary_stock_relaxation_mm':0.020,'all_cog_angles_continuous':True,
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
