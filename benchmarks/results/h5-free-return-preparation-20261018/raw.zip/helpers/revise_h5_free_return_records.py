from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-free-return-probe-20261018'
p=root/'scripts/h5_free_return_pilot.py';s=p.read_text(encoding='utf-8')
a='All 133 prior tests and four new regressions qualify before measurement.'
b='130 prior tests stay exact; three formerly neutral fixtures now require strict\nimprovement or exact retention. Four new regressions also qualify before measurement.'
assert s.count(a)==1;s=s.replace(a,b);p.write_text(s,encoding='utf-8',newline='\n')
method=json.loads((probe/'pilot-method.json').read_bytes());ref=(root/method['reference']).read_text(encoding='utf-8')
def fn(t,n):return next(x for x in ast.parse(t).body if isinstance(x,ast.FunctionDef) and x.name==n)
for n in method['identical_function_ASTs']:assert ast.dump(fn(s,n))==ast.dump(fn(ref,n))
method['runner_sha256']=sha256(p.read_bytes()).hexdigest();(probe/'pilot-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'runner_sha256':method['runner_sha256'],'scoring_and_measurement_unchanged':True}))
