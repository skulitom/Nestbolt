"""Adapt only paths and rationale; retain the original pilot scoring and process guards."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-free-return-probe-20261018'
ref=root/'scripts/h5_contained_return_pilot.py';original=ref.read_text(encoding='utf-8')
s=original.replace('h5-contained-return-probe','h5-free-return-probe').replace('h5-contained-return-preparation','h5-free-return-preparation')
end=s.index('"""',3)+3
s='''"""Paired development pilot of bounded free-space return initialization.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The baseline is the unchanged preview. The isolated candidate searches at
most 256 translations per returned part against the current source layout,
including earlier returns. It keeps each member's orientation and reflection,
charges transformed geometry, checks the shared deadline, and retains the
previous contained seed if no clear placement exists. Filled holes remain
reserved. Existing choices, repairs and exact acceptance are unchanged.
All 133 prior tests and four new regressions qualify before measurement.
This descriptive pilot cannot close H5 or justify a comparative claim.
"""'''+s[end:]
s=s.replace('Isolated contained-return candidate','Isolated free-space-return candidate')
needle="ROOT/'benchmarks/results/h5-boundary-pair-pilot-20261018/source-review.json'"
assert s.count(needle)==1;s=s.replace(needle,needle+",\n                  ROOT/'benchmarks/results/h5-contained-return-pilot-20261018/verification.json',\n                  ROOT/'benchmarks/results/h5-contained-return-pilot-20261018/interpretation.json'")
path=root/'scripts/h5_free_return_pilot.py';assert not path.exists();compile(s,str(path),'exec');path.write_text(s,encoding='utf-8',newline='\n')
def fn(t,n):return next(x for x in ast.parse(t).body if isinstance(x,ast.FunctionDef) and x.name==n)
names=['blocks','summarize','case','measure','require_runner_stopped','require_measurements_finished']
for n in names:assert ast.dump(fn(s,n))==ast.dump(fn(original,n))
method={'reference':ref.relative_to(root).as_posix(),'reference_sha256':sha256(ref.read_bytes()).hexdigest(),
 'candidate_runner':path.relative_to(root).as_posix(),'runner_sha256':sha256(path.read_bytes()).hexdigest(),
 'identical_function_ASTs':names,'scoring_measurement_and_PID_reuse_guard_unchanged':True}
(probe/'pilot-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
for stage in ['public','branch','harness']:
 s=(root/f'output/check_h5_contained_return_{stage}.py').read_text(encoding='utf-8').replace('h5-contained-return','h5-free-return').replace('h5_contained_return','h5_free_return')
 compile(s,stage,'exec');(root/f'output/check_h5_free_return_{stage}.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(method))
