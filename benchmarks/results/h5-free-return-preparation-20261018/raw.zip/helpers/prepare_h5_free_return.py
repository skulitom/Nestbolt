"""Prepare a bounded free-space return-seed experiment, with old-behavior regressions."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, subprocess, sys
root=Path(__file__).resolve().parents[1]
old=root/'output/h5-contained-return-probe-20261018';out=root/'output/h5-free-return-probe-20261018'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert json.loads((root/'benchmarks/results/h5-contained-return-pilot-20261018/interpretation.json').read_bytes())['failed_material_pairs']==5
out.mkdir()
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
original=path.read_text(encoding='utf-8');text=original
stub='''// Bounded free-space search changes only the return seed.
fn free_return_pose(
    _source: &JLayout,
    _item: &Item,
    fallback: DTransformation,
    _clock: &Clock,
    _until: f64,
) -> DTransformation {
    fallback
}

'''
needle='// Only choose the reciprocal frame';assert text.count(needle)==1;text=text.replace(needle,stub+needle)
needle='''                    for ((_, victim, _), pose) in victims.iter().zip(returned) {
                        next_source.place_item(victim, pose);'''
replacement='''                    for ((_, victim, _), pose) in victims.iter().zip(returned) {
                        let pose = free_return_pose(&next_source, victim, pose, &self.clock, self.last_step(exchange_until));
                        next_source.place_item(victim, pose);'''
assert text.count(needle)==1;text=text.replace(needle,replacement)
tests='''
    // BEGIN free-return tests
    fn free_return_public(model: &Model, before: &Layout, source: &JLayout, sheet: &str) -> Layout {
        let mut after=before.clone();after.placements.retain(|p|p.sheet_id!=sheet);
        let mut copies=std::collections::BTreeMap::<String,u32>::new();
        for p in &after.placements { *copies.entry(p.part_id.clone()).or_default()+=1; }
        for p in source.placed_items().values() {
            let id=model.job.parts[model.part[p.item().idx()]].id.clone();
            let copy=copies.entry(id.clone()).or_default();
            after.placements.push(Placement { part_id:id,copy_index:*copy,sheet_id:sheet.into(),transform:model.external(p.item().idx(),&p.d_transf()) });*copy+=1;
        }
        after
    }

    #[test]
    fn free_return_finds_lower_clear_positions_sequentially_and_preserves_inventory() {
        let (job,layout)=boundary_pair_fixture(false);let model=Model::new(&job).unwrap();
        let sheets=model.sheets_of(&layout).unwrap();let original=sheets[1].layout();
        let members=return_seed_members(original);let mut source=JLayout::from_snapshot(&original.save());
        for (key,_,_) in &members { source.remove_item(*key); }
        let clock=Clock::new(Timing::Work,120.0);let mut poses=vec![];
        for (_,item,seed) in &members {
            let pose=free_return_pose(&source,item,*seed,&clock,10.0);
            assert!(pose.translation().0<seed.translation().0-20.0,"Returned part must use a lower clear space");
            assert_eq!(pose.rotation().to_bits(),seed.rotation().to_bits());assert_eq!(pose.reflected,seed.reflected);
            let mut shape=item.shape_cd().as_ref().clone();shape.transform_from(item.shape_cd(),&pose.compose());
            assert!(!source.cde().detect_poly_collision(&shape,&NoFilter));
            source.place_item(item,pose);poses.push(pose);
        }
        assert_eq!(source.placed_items().len(),original.placed_items().len());
        assert!(clock.counts().evaluations>2.0 && clock.counts().evaluations<=514.0);
        assert!(clock.counts().evaluated_vertices>0.0);
        let after=free_return_public(&model,&model.to_layout(&sheets),&source,"sheet-1");
        assert!(validate(&job,&after).unwrap().valid);
        let replay_clock=Clock::new(Timing::Work,120.0);let mut replay=JLayout::from_snapshot(&original.save());
        for (key,_,_) in &members { replay.remove_item(*key); }
        for ((_,item,seed),expected) in members.iter().zip(&poses) {
            let actual=free_return_pose(&replay,item,*seed,&replay_clock,10.0);
            assert_eq!(return_seed_pose_bits(&[actual]),return_seed_pose_bits(&[*expected]));replay.place_item(item,actual);
        }
        assert_eq!(clock.work(),replay_clock.work());
        eprintln!("FREE_RETURN_WITNESS {}",serde_json::json!({"job":job,"before":model.to_layout(&sheets),"after":after,"work":clock.counts()}));
    }

    #[test]
    fn free_return_preserves_permitted_mixed_rotations_and_mirrors() {
        let (mut job,layout)=boundary_pair_fixture(true);
        for part in &mut job.parts { part.allow_mirror=true;part.rotations=Rotations::List{degrees:vec![0.0,90.0,180.0,270.0]}; }
        let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
        let members=return_seed_members(sheets[1].layout());assert!(!std::sync::Arc::ptr_eq(&members[0].1,&members[1].1));
        let mut source=JLayout::from_snapshot(&sheets[1].layout().save());for (key,_,_) in &members {source.remove_item(*key);}
        let clock=Clock::new(Timing::Work,120.0);
        for (index,(_,item,seed)) in members.iter().enumerate() {
            let seed=DTransformation::new(index as f32*std::f32::consts::FRAC_PI_2,seed.translation()).with_reflection(index==0);
            assert!(item.allowed_orientations().allows(&seed));
            let pose=free_return_pose(&source,item,seed,&clock,10.0);
            assert!(pose.translation().0<seed.translation().0-20.0,"Mixed return must find lower space");
            assert_eq!(pose.rotation().to_bits(),seed.rotation().to_bits());assert_eq!(pose.reflected,seed.reflected);
            assert!(item.allowed_orientations().allows(&pose));source.place_item(item,pose);
        }
        let after=free_return_public(&model,&model.to_layout(&sheets),&source,"sheet-1");assert!(validate(&job,&after).unwrap().valid);
        eprintln!("FREE_RETURN_WITNESS {}",serde_json::json!({"job":job,"before":model.to_layout(&sheets),"after":after,"work":clock.counts()}));
    }

    #[test]
    fn free_return_expired_and_mid_search_deadlines_keep_every_fallback() {
        let (job,layout)=boundary_pair_fixture(false);let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
        let original=sheets[1].layout();let members=return_seed_members(original);
        for until in [0.0,1e-12] {
            let clock=Clock::new(Timing::Work,120.0);let mut source=JLayout::from_snapshot(&original.save());
            for (key,_,_) in &members {source.remove_item(*key);}
            for (_,item,seed) in &members {
                let pose=free_return_pose(&source,item,*seed,&clock,until);
                assert_eq!(return_seed_pose_bits(&[pose]),return_seed_pose_bits(&[*seed]));source.place_item(item,pose);
            }
            assert_eq!(source.placed_items().len(),original.placed_items().len());
            assert_eq!(clock.counts().evaluations,if until==0.0 {0.0}else{1.0});
            let after=free_return_public(&model,&model.to_layout(&sheets),&source,"sheet-1");assert!(validate(&job,&after).unwrap().valid);
        }
    }

    #[test]
    fn free_return_reserves_holes_and_keeps_unplaceable_seed_exact() {
        let (mut job,mut layout)=fixture();job.parts=vec![rectangle("frame",94.0,94.0),rectangle("return",5.0,5.0)];
        job.parts[0].geometry[0].holes.push(vec![[20.0,20.0],[20.0,70.0],[70.0,70.0],[70.0,20.0]]);
        layout.placements.truncate(2);layout.placements[0].part_id="frame".into();layout.placements[1].sheet_id="sheet-1".into();
        assert!(validate(&job,&layout).unwrap().valid);let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
        let source=sheets[0].layout();let item=sheets[1].layout().placed_items().values().next().unwrap().item();
        let fallback=model.internal(item.idx(),&RigidTransform{translation:[40.0,40.0],..Default::default()});
        let mut shape=item.shape_cd().as_ref().clone();shape.transform_from(item.shape_cd(),&fallback.compose());
        assert!(source.cde().detect_poly_collision(&shape,&NoFilter),"Hole interiors stay reserved");
        let clock=Clock::new(Timing::Work,120.0);let pose=free_return_pose(source,item,fallback,&clock,10.0);
        assert_eq!(return_seed_pose_bits(&[pose]),return_seed_pose_bits(&[fallback]));
        assert!(clock.counts().evaluations>1.0 && clock.counts().evaluations<=257.0);
    }
    // END free-return tests
'''
pos=text.rindex('\n}');text=text[:pos]+tests+text[pos:];path.write_text(text,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),
 'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
 'changed_files':[rel],'added_files':{},'production_digest':source_digest(),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),
 'target':str(root/'output/h5-free-return-target-20261018'),'unchanged_prior_tests':133,'new_tests':4,'normal_mode_unchanged':True,'measured_search_started':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py');(out/'stub.txt').write_text(stub,encoding='utf-8',newline='\n')
print(json.dumps({'prepared':True,'prior_tests':133,'new_tests':4,'new_searches':0}))
