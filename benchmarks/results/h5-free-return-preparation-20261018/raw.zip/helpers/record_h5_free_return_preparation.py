from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parents[1];out=root/'benchmarks/results/h5-free-return-preparation-20261018'
assert json.loads((out/'checks.json').read_bytes())['all_functional_checks_pass']
prior=(root/'BENCHMARKS.md').read_bytes();assert prior==subprocess.check_output(['git','show','HEAD:BENCHMARKS.md'],cwd=root)
note='''**N4 free-space return preparation, 2026-10-18:** the [isolated candidate](../benchmarks/results/h5-free-return-preparation-20261018.md)
tries at most 256 translations per returned part against the source and earlier
returns, keeping each orientation and reflection. It checks filled-hole collision
geometry, charges work, observes the shared deadline, and always retains every
part with the previous seed as fallback. Original choices, repairs and strict
acceptance remain. All 137 optimized tests pass: 130 prior tests are unchanged,
three former no-improvement expectations now require strict material reduction
or exact incumbent retention, and four new regressions retain their expected
old-behavior failures. The first implementation's three failures remain with six
independent CLI checks proving the new authored improvement; runtime guards remain.
Four new frozen-CLI checks and independent filled-outer checks qualify two authored
outputs; 12 original branch outcomes, 24 branch validations, 10 public outcomes,
four public comparisons and five adversarial harness tests pass. Exact source
reconstruction, lint and build pass. The same matched pilot is ready to be planned;
no quality measurement has begun and no integration or H5 credit is earned.
H2/H5 remain open at 60%.
'''
def append(p,s):
 with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
append(root/'BENCHMARKS.md','\n\n## 2026-10-18 — Free-space return initialization qualification\n\n'+note.replace('../benchmarks/','benchmarks/'))
for name in ['docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']:append(root/name,'\n\n'+note)
p=root/'docs/STATUS.md';s=p.read_text(encoding='utf-8');at=s.index('**N4 contained-return');s=s[:at]+note+'\n'+s[at:];p.write_text(s,encoding='utf-8',newline='\n')
append(root/'.gitattributes','\nbenchmarks/results/h5-free-return-preparation-20261018/** -text -whitespace\nbenchmarks/results/h5-free-return-pilot-20261018/** -text -whitespace\n')
assert (root/'BENCHMARKS.md').read_bytes().startswith(prior)
print('Recorded qualified free-space return preparation; production and gate weights unchanged.')
