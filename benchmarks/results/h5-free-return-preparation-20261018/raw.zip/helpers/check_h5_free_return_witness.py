"""Independently validate the two saved authored free-space outputs, without a new search."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,subprocess
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-free-return-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_checks_passed'];out=probe/'seed-checks';out.mkdir()
log=(probe/'core-tests.log').read_text(encoding='utf-8');assert '137 passed; 0 failed' in log
rows=[json.loads(line.removeprefix('FREE_RETURN_WITNESS ')) for line in log.splitlines() if line.startswith('FREE_RETURN_WITNESS ')]
assert len(rows)==2
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
records=[]
for i,row in enumerate(rows):
 folder=out/f'case-{i}';folder.mkdir();write(folder/'witness.json',row);write(folder/'job.json',row['job'])
 parts={p['id']:p for p in row['job']['parts']};metrics=[];pairs=0
 for kind in ['before','after']:
  write(folder/(kind+'.json'),row[kind]);args=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/(kind+'.json'))]
  r=subprocess.run(args,capture_output=True,timeout=60);(folder/(kind+'-stdout.json')).write_bytes(r.stdout);(folder/(kind+'-stderr.log')).write_bytes(r.stderr)
  write(folder/(kind+'-command.json'),{'command':args,'exit_code':r.returncode});assert r.returncode==0
  value=json.loads(r.stdout);assert value['valid'];metrics.append(value['metrics'])
  shapes=[]
  for placement in row[kind]['placements']:
   t=placement['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
   def tr(p):return (m*c*p[0]-s*p[1]+t['translation'][0],m*s*p[0]+c*p[1]+t['translation'][1])
   for g in parts[placement['part_id']]['geometry']:
    shape=Polygon([tr(p) for p in g['outer']]);assert shape.is_valid
    for sheet,other in shapes:
     if sheet==placement['sheet_id']:
      assert not shape.intersects(other) and shape.distance(other)+1e-7>=row['job']['clearance'];pairs+=1
    shapes.append((placement['sheet_id'],shape))
 assert metrics[1]['material_area']<metrics[0]['material_area']
 assert 2<row['work']['evaluations']<=514 and row['work']['evaluated_vertices']>0
 records.append({'fixture':row['job']['name'],'both_layouts_valid':True,'filled_outer_pairs':pairs,
                 'authored_material_before':metrics[0]['material_area'],'authored_material_after':metrics[1]['material_area'],'work':row['work']})
target=Path(load(probe/'preparation.json')['target']);bins=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1
shutil.copyfile(bins[0],out/'authored-tests.exe');shutil.copyfile(__file__,out/'check.py')
checks={'all_checks_passed':True,'new_seed_tests':4,'saved_public_outcomes':2,'public_CLI_validations':4,
 'independent_filled_outer_pairs':sum(r['filled_outer_pairs'] for r in records),'records':records,
 'CLI_sha256':expected,'test_binary_sha256':digest(bins[0]),'core_log_sha256':digest(probe/'core-tests.log'),
 'tests_reused_from_full_build':True,'new_searches':0,'quality_claim':False,
 'limits':'Authored fixtures only; native tests also cover exact orientation/reflection, work caps, deterministic replay, expired/mid-search deadlines and unplaceable filled-hole fallback. These do not establish development quality.'}
write(out/'checks.json',checks);print(json.dumps(checks))
