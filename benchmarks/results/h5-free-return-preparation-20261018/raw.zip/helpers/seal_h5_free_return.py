"""Seal all functional evidence before the proposed 72-outcome quality pilot."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-free-return-probe-20261018';out=root/'benchmarks/results/h5-free-return-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');source=load(probe/'reconstruction.json')
public=load(probe/'public-checks/checks.json');branch=load(probe/'branch-checks/checks.json');seed=load(probe/'seed-checks/checks.json')
assert all(x['all_checks_passed'] for x in [build,source,public,branch,seed])
assert '137 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert source['all_133_prior_tests_accounted'] and source['prior_tests_unchanged']==130 and source['prior_expectations_revised']==3
assert source['other_runtime_exact'] and source['unchanged_other_files']==155
regressions=load(probe/'failed-neutral-assumptions/checks.json');assert regressions['all_checks_passed'] and regressions['CLI_checks']==6
assert digest(probe/'failed-neutral-assumptions/core-tests.log')==regressions['failure_log_sha256']
assert digest(probe/'failed-neutral-assumptions/authored-tests.exe')==regressions['failure_binary_sha256']
assert digest(probe/'failed-neutral-assumptions'/plan['changed_files'][0])==regressions['failure_source_sha256']
oracle=load(probe/'canonical-oracle-repair.json');assert oracle['runtime_unchanged']
assert digest(probe/'failed-canonical-oracle/core-tests.log')==oracle['failure_log_sha256']
assert digest(probe/'failed-canonical-oracle/authored-tests.exe')==oracle['failure_binary_sha256']
assert digest(probe/'failed-canonical-oracle'/plan['changed_files'][0])==oracle['failure_source_sha256']
red=load(probe/'before-free-return/checks.json');assert red['expected_runtime_failure']
assert digest(probe/'before-free-return/expected-failure.log')==red['log_sha256'];assert digest(probe/'before-free-return/authored-tests.exe')==red['binary_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
 for row in rows:
  assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
  if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for rel,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/rel)==expected
assert public['observer_outcomes']==10 and public['CLI_cross_checks']==4 and branch['actual_outcomes']==12 and branch['public_validations']==24
assert seed['new_seed_tests']==4 and seed['public_CLI_validations']==4
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json');assert digest(root/method['reference'])==method['reference_sha256'];assert digest(root/method['candidate_runner'])==method['runner_sha256']
assert method['scoring_measurement_and_PID_reuse_guard_unchanged']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
helpers=['prepare','check_red','apply','build','prepare_checks','check_source','check_witness','check_public','check_branch','check_harness','seal','record_preparation']
for name in ['prepare_h5_free_return.py','check_h5_free_return_red.py','apply_h5_free_return.py','build_h5_free_return.py','prepare_h5_free_return_checks.py','check_h5_free_return_source.py','check_h5_free_return_witness.py','check_h5_free_return_public.py','check_h5_free_return_branch.py','check_h5_free_return_harness.py','seal_h5_free_return.py','record_h5_free_return_preparation.py']:
 files['helpers/'+name]=root/'output'/name
for name in ['diagnose_h5_free_return_regressions.py','update_h5_free_return_expectations.py','revise_h5_free_return_records.py','repair_h5_free_return_canonical.py','repair_h5_free_return_branch_capture.py']:files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_free_return_pilot.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(inventory)
 for n,row in inventory.items():
  b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_functional_checks_pass':True,'optimized_core_tests_passed':137,'prior_tests_unchanged':130,'prior_expectations_revised':3,'new_tests':4,
 'three_obsolete_expectation_failures_preserved':True,'failed_outcomes_independently_validated':6,
 'expected_four_failures_preserved':True,'strict_lint_passed':True,'observer_build_passed':True,
 'only_return_initialization_changes':True,'existing_choices_repairs_acceptance_unchanged':True,
 'shared_deadline_checks_and_work_charges':True,'maximum_candidate_translations_per_member':256,
 'all_156_formatted_files_reconstruct_exactly':True,'unchanged_other_files':155,'actual_branch_outcomes':12,
 'branch_frozen_CLI_checks':24,'seed_witness_CLI_checks':4,'public_observer_outcomes':10,'public_CLI_cross_checks':4,
 'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,'pilot_harness_tests':5,'PID_reuse_guard_unchanged':True,
 'production_unchanged':True,'measurement_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','source-checks.json','reconstruction.json','candidate.patch','pilot-method.json','test-expectation-update.json','canonical-oracle-repair.json']:shutil.copyfile(probe/name,out/name)
shutil.copyfile(probe/'failed-neutral-assumptions/checks.json',out/'revised-expectations.json')
for sub,name in [('before-free-return','expected-failure'),('public-checks','public-checks'),('branch-checks','branch-checks'),('seed-checks','seed-checks')]:shutil.copyfile(probe/sub/'checks.json',out/(name+'.json'))
doc='''# Free-space return initialization — preparation, 2026-10-18

The [contained-return pilot](h5-contained-return-pilot-20261018.md) fails five
material pairs. Box containment alone does not look for a lower collision-free
position. This candidate adds a bounded translation search for each returned
part against the source layout, including returns already placed in this attempt.

At most 256 translations use a 12×12 grid and four bounding-box edge anchors for
each of the first 28 source members in existing order. Exact collision checks
reserve filled holes. Each original orientation and reflection stays unchanged.
Clear seeds are ordered by occupied height and then horizontal position; the old
contained seed remains if no clear placement exists. The original seed and every
transformed candidate are charged. Shared deadline checks bound the search, and
every return is still registered even when that deadline has elapsed. The original
repair allocation, proposal choices and strict whole-job material/geometry
acceptance remain. A finite grid is a heuristic, not a feasibility proof.

All 137 optimized tests pass: 130 prior tests are unchanged, three prior fixture
expectations are revised, and four regressions are new. Those four first fail
against the previous behavior; their original source, binary and log remain.
The first implementation passes 134 tests but improves three formerly neutral
fixtures, breaking their no-move expectation. Six frozen-CLI validations prove
the preserved failed outputs valid, reducing authored material from 19,700 to
19,600.0558 mm². Only those three expectations change: an accepted move now must
strictly reduce material against the internal incumbent, while a rejected,
disabled or expired operation must preserve it exactly. Standalone exact-state
and material-profile predicate tests and all runtime acceptance code remain
unchanged. Exact-state rejection is no longer required to occur in this fixture;
its unchanged predicate tests and reconstructed runtime support that guard.
The first revised oracle used a direct model conversion and failed two exact
no-op checks because it omitted the existing strip split/rejoin. Its binary,
source and log remain. The corrected oracle uses the actual disabled operation;
no numerical tolerance or runtime change is introduced.
New checks cover sequential clear returns,
exact inventory, replay/work counts, permitted mixed rotations and mirrors,
expired and mid-search deadlines, and unplaceable returns with reserved holes.
Two saved authored output layouts and their inputs pass four frozen-CLI checks
and independent original filled-outer clearance checks; no test was rerun to
obtain those saved witnesses. Twelve active/disabled/expired outcomes pass 24 frozen
CLI validations: four active cases strictly improve, and all eight disabled or
expired cases preserve their exact internal incumbents. One profile-witness JSON
line was interleaved in the parallel full-test log. That original log and failed
reader remain; only the authored profile test was repeated using the same binary
with separate output streams. No quality run was repeated.
Ten public outcomes and four CLI comparisons preserve normal
results exactly except wall time and reproduce common-mode results deterministically.

Strict lint and the experimental executable build pass. All 156 formatted source
files reconstruct exactly; 155 files and all other runtime blocks are unchanged.
Five adversarial pilot-harness tests pass. Measurement, scoring, ordering and the
previously qualified process-identity guard are AST-identical to the prior pilot.

The next pilot must commit its plan before measuring the same four development
jobs, both kerfs and three seeds at matched 60-second budgets on eight physical
CCD0 cores. No quality measurement has begun. Success would still require the
full original 13-job H5 gate. Production, reserved inputs, release and README
claims are unchanged. **H2/H5 remain open; completed milestone weight is 60%.**

[Checks](h5-free-return-preparation-20261018/checks.json),
[original failures](h5-free-return-preparation-20261018/expected-failure.json),
[reviewed fixture expectations](h5-free-return-preparation-20261018/revised-expectations.json),
[independent authored outputs](h5-free-return-preparation-20261018/seed-checks.json),
[exact source reconstruction](h5-free-return-preparation-20261018/reconstruction.json),
[raw evidence](h5-free-return-preparation-20261018/raw.zip),
[member hashes and archive integrity](h5-free-return-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
print(json.dumps({'all_functional_checks_pass':True,'members':len(inventory),'archive_bytes':archive.stat().st_size,'new_quality_runs':0}))
