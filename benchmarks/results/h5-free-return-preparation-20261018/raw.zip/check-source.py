"""Reconstruct exactly from the saved no-op source and independently isolate the runtime delta."""
from pathlib import Path
from hashlib import sha256
import ast,difflib,json,re,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-free-return-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');assert load(out/'build.json')['all_checks_passed']
rel=plan['changed_files'][0];parent=Path(plan['old_probe'])/'candidate'
prior=(parent/rel).read_text(encoding='utf-8');current=(out/'candidate'/rel).read_text(encoding='utf-8')
old_runtime,old_tests=prior.split('#[cfg(test)]',1);runtime,tests=current.split('#[cfg(test)]',1)
start=runtime.index('// Bounded free-space search changes only');end=runtime.index('// Only choose the reciprocal frame',start)
helper=runtime[start:end];restored=runtime[:start]+runtime[end:]
start=restored.index('                        let pose = free_return_pose(');end=restored.index('                        next_source.place_item(victim, pose);',start)
call=restored[start:end]
assert re.sub(r'\s+','',call)=='letpose=free_return_pose(&next_source,victim,pose,&self.clock,self.last_step(exchange_until),);'
restored=restored[:start]+restored[end:];assert restored==old_runtime
red=(out/'before-free-return'/rel).read_text(encoding='utf-8')
assert red.split('#[cfg(test)]',1)[1].split('    // BEGIN free-return tests',1)[0].rstrip()==old_tests.rsplit('\n}',1)[0].rstrip()
assert helper.count('crate::separate::charge(clock, item, 1)')==2 and '.rng' not in helper
fresh=root/'output/h5-free-return-reconstruction-20261018';shutil.copytree(out/'candidate',fresh)
script=ast.parse((root/'output/apply_h5_free_return.py').read_text(encoding='utf-8'))
implementation=next(ast.literal_eval(n.value) for n in script.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='implementation' for t in n.targets))
stub=(out/'stub.txt').read_text(encoding='utf-8')
assert red.count(stub)==1;(fresh/rel).write_text(red.replace(stub,implementation),encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
revised=(fresh/rel).read_text(encoding='utf-8');update=load(out/'test-expectation-update.json')
assert revised==(out/'failed-neutral-assumptions'/rel).read_text(encoding='utf-8')
for i,(a,b) in enumerate(update['replacements']):
 assert revised.count(a)==(2 if i==1 else 1);revised=revised.replace(a,b)
needle='    // BEGIN free-return tests';assert revised.count(needle)==1;revised=revised.replace(needle,needle+update['helper'])
(fresh/rel).write_text(revised,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
revised=(fresh/rel).read_text(encoding='utf-8');assert revised==(out/'failed-canonical-oracle'/rel).read_text(encoding='utf-8')
for a,b in load(out/'canonical-oracle-repair.json')['replacements']:
 assert revised.count(a)==1;revised=revised.replace(a,b)
(fresh/rel).write_text(revised,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
for row in plan['old_source_files']['candidate']:
 name=row['path'];assert digest(parent/name)==row['sha256'];assert (fresh/name).read_bytes()==(out/'candidate'/name).read_bytes()
 if name!=rel:assert digest(out/'candidate'/name)==row['sha256']
record={'all_checks_passed':True,'all_133_prior_tests_accounted':True,'prior_tests_unchanged':130,'prior_expectations_revised':3,'other_runtime_exact':True,
 'all_formatted_reconstructed_files_exact':True,'reconstructed_files':len(plan['old_source_files']['candidate']),
 'unchanged_other_files':len(plan['old_source_files']['candidate'])-1,'only_return_initialization_changes':True,
 'existing_generators_caps_budgets_repairs_acceptance_unchanged':True,'new_geometry_work_charged':True,
 'fixed_orientations_and_reflection':True,'deadline_checked_before_each_evaluation':True,'no_new_random_samples':True,'new_searches':0}
for name,value in [('reconstruction.json',record),('source-checks.json',{'all_checks_passed':True,'changed_runtime_files':[rel],
 'original_candidate_file_sha256':digest(parent/rel),'candidate_file_sha256':digest(out/'candidate'/rel),'all_other_candidate_files_unchanged':True,
 'prior_tests_unchanged':130,'prior_expectations_revised':3,'new_tests':4,'new_searches':0})]:
 (out/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(prior.splitlines(True),current.splitlines(True),fromfile='contained-return/'+rel,tofile='free-return/'+rel)),encoding='utf-8',newline='\n')
(out/'qualified-helpers.rs').write_text(helper,encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'check-source.py');print(json.dumps(record))
