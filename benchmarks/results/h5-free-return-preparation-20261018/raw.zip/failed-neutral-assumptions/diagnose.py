"""Preserve the failed build and independently check the three formerly neutral outcomes."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-free-return-probe-20261018';out=probe/'failed-neutral-assumptions';out.mkdir()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');rel=plan['changed_files'][0];dst=out/rel;dst.parent.mkdir(parents=True);shutil.copyfile(probe/'candidate'/rel,dst)
for name in ['format.log','core-tests.log','progress.json','build-failure.json']:shutil.copyfile(probe/name,out/name)
bins=list((Path(plan['target'])/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1;shutil.copyfile(bins[0],out/'authored-tests.exe')
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
records=[]
for prefix in ['EXACT_REJECT_WITNESS','PROFILE_REJECT_WITNESS','PRODUCTIVE_WITNESS']:
 rows=[json.loads(line[len(prefix)+1:]) for line in (out/'core-tests.log').read_text(encoding='utf-8').splitlines() if line.startswith(prefix+' ')]
 rows=[row for row in rows if row['seed']==0 and row.get('case','unchanged_inventory')=='unchanged_inventory']
 assert len(rows)==1;row=rows[0];folder=out/prefix;folder.mkdir();write(folder/'witness.json',row);write(folder/'job.json',row['job']);metrics=[]
 for name in ['before','after']:
  write(folder/(name+'.json'),row[name]);args=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/(name+'.json'))]
  result=subprocess.run(args,capture_output=True,timeout=60);(folder/(name+'-stdout.json')).write_bytes(result.stdout);(folder/(name+'-stderr.log')).write_bytes(result.stderr)
  write(folder/(name+'-command.json'),{'command':args,'exit_code':result.returncode});assert result.returncode==0
  value=json.loads(result.stdout);assert value['valid'];metrics.append(value['metrics'])
 assert row['moved']==row['stats']['directed_exchanges']==1
 assert metrics[1]['sheets_used']==metrics[0]['sheets_used'] and metrics[1]['material_area']<metrics[0]['material_area']-50.0
 records.append({'prefix':prefix,'before':metrics[0]['material_area'],'after':metrics[1]['material_area'],'valid':True,'strict_material_reduction':True,'stats':row['stats']})
record={'all_checks_passed':True,'reason':'Three previous end-to-end fixtures assume their unchanged item inventory cannot become more compact. Free-space returns now produce a valid strict material improvement, so moved=0 is no longer the invariant. Preserve old failures and revise only these expectations to require strict improvement for acceptance and exact incumbent retention otherwise; keep disabled/expired and standalone predicate tests.',
 'CLI_checks':6,'CLI_sha256':expected,'failure_log_sha256':digest(out/'core-tests.log'),'failure_binary_sha256':digest(out/'authored-tests.exe'),'failure_source_sha256':digest(dst),'records':records,'new_searches':0}
write(out/'checks.json',record);shutil.copyfile(__file__,out/'diagnose.py')
for name in ['format.log','core-tests.log','progress.json','build-failure.json']:assert digest(out/name)==digest(probe/name);(probe/name).unlink()
print(json.dumps(record))
