// Bounded free-space search changes only the return seed. Every candidate
// keeps the original orientation and whole item geometry. Collision proxies
// reserve hole interiors. No clear candidate means the original repair seed.
fn free_return_pose(
    source: &JLayout,
    item: &Item,
    fallback: DTransformation,
    clock: &Clock,
    until: f64,
) -> DTransformation {
    if clock.now() >= until || !item.allowed_orientations().allows(&fallback) {
        return fallback;
    }
    let bounds = source.container().outer_cd().bbox();
    let mut buffer = item.shape_cd().as_ref().clone();
    buffer.transform_from(item.shape_cd(), &fallback.compose());
    let initial = buffer.bbox();
    let mut best = if source.cde().detect_poly_collision(&buffer, &NoFilter) {
        None
    } else {
        Some((fallback, initial.x_max, initial.y_min))
    };
    crate::separate::charge(clock, item, 1);
    let width = initial.x_max - initial.x_min;
    let height = initial.y_max - initial.y_min;
    let scale = [
        bounds.x_min,
        bounds.x_max,
        bounds.y_min,
        bounds.y_max,
        initial.x_min,
        initial.x_max,
        initial.y_min,
        initial.y_max,
    ]
    .into_iter()
    .map(f32::abs)
    .fold(1.0_f32, f32::max);
    // Real inset, not a collision or material tolerance. Exact bounds and the
    // existing collision detector still decide whether a seed is usable.
    let inset = 4.0 * f32::EPSILON * scale;
    let x0 = bounds.x_min + inset;
    let x1 = bounds.x_max - width - inset;
    let y0 = bounds.y_min + inset;
    let y1 = bounds.y_max - height - inset;
    if ![x0, x1, y0, y1].iter().all(|v| v.is_finite()) || x1 < x0 || y1 < y0 {
        return fallback;
    }
    let mut samples = Vec::with_capacity(256);
    // A fixed 12 by 12 grid covers the entire source container. Up to 28
    // existing members also contribute four box-edge anchors each. The cap
    // bounds work independently of inventory size; input order breaks ties.
    for x in 0..12 {
        for y in 0..12 {
            samples.push((
                x0 + (x1 - x0) * x as f32 / 11.0,
                y0 + (y1 - y0) * y as f32 / 11.0,
            ));
        }
    }
    for p in source.placed_items().values().take(28) {
        let b = p.shape().bbox();
        samples.extend([
            (b.x_max + inset, b.y_min),
            (b.x_min - width - inset, b.y_min),
            (b.x_min, b.y_max + inset),
            (b.x_min, b.y_min - height - inset),
        ]);
    }
    clock.charge(Work::RectOperation, samples.len() as f64);
    let (dx, dy) = fallback.translation();
    for (x, y) in samples {
        if clock.now() >= until {
            break;
        }
        if x < x0 || x > x1 || y < y0 || y > y1 {
            continue;
        }
        let pose = DTransformation::new(
            fallback.rotation(),
            (dx + x - initial.x_min, dy + y - initial.y_min),
        )
        .with_reflection(fallback.reflected);
        buffer.transform_from(item.shape_cd(), &pose.compose());
        let b = buffer.bbox();
        crate::separate::charge(clock, item, 1);
        if b.x_min < bounds.x_min
            || b.x_max > bounds.x_max
            || b.y_min < bounds.y_min
            || b.y_max > bounds.y_max
            || best
                .as_ref()
                .is_some_and(|(_, bx, by)| (b.x_max, b.y_min) >= (*bx, *by))
        {
            continue;
        }
        if !source.cde().detect_poly_collision(&buffer, &NoFilter) {
            best = Some((pose, b.x_max, b.y_min));
        }
    }
    best.map_or(fallback, |b| b.0)
}

