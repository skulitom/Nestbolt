"""Retain the combined-log parsing failure and capture the authored test on separate streams."""
from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-free-return-probe-20261018';out=probe/'branch-reader-failure';out.mkdir()
p=root/'output/check_h5_free_return_branch.py';shutil.copyfile(p,out/'failed-reader.py')
bad=[]
for number,line in enumerate((probe/'core-tests.log').read_text(encoding='utf-8').splitlines(),1):
 if line.startswith('PROFILE_REJECT_WITNESS '):
  try:json.loads(line.removeprefix('PROFILE_REJECT_WITNESS '))
  except json.JSONDecodeError as e:bad.append({'line':number,'error':str(e),'sha256':sha256(line.encode()).hexdigest()})
assert bad
record={'original_core_log_sha256':sha256((probe/'core-tests.log').read_bytes()).hexdigest(),'invalid_combined_log_records':bad,
 'repair':'Do not edit or reconstruct interleaved JSON. Re-execute only the authored profile guard test using the already qualified binary, with stdout and stderr captured separately. This is not a quality rerun.'}
(out/'checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not any((probe/'branch-checks').iterdir());(probe/'branch-checks').rmdir()
s=p.read_text(encoding='utf-8');start=s.index("log=(probe/'core-tests.log')");end=s.index('assert len(rows)==12',start)
s=s[:start]+'''command=[str(binary),'--exact','sheets::vstrip::exchange::tests::material_profile_guard_allows_only_gain_and_preserves_disabled_boundaries','--nocapture']
r=subprocess.run(command,capture_output=True,timeout=120)
(out/'stdout.log').write_bytes(r.stdout);(out/'stderr.log').write_bytes(r.stderr);write(out/'command.json',{'command':command,'exit_code':r.returncode})
assert r.returncode==0 and '1 passed; 0 failed' in r.stdout.decode()
rows=[json.loads(line.removeprefix('PROFILE_REJECT_WITNESS ')) for line in r.stderr.decode().splitlines() if line.startswith('PROFILE_REJECT_WITNESS ')]
'''+s[end:]
p.write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'repair.py');print(json.dumps(record))
