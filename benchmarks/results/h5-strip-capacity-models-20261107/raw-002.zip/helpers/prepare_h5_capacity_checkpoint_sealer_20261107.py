"""Prepare a new evidence checkpoint without modifying any closed producer."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/seal_h5_exact_circle_forest_20261107.py').read_text(encoding='utf-8')
start=old[:old.index('inventory_ast=')]
start=start.replace("NAME='h5-exact-circle-forest-20261107'", "NAME='h5-strip-capacity-models-20261107'")
a=start.index("B=ROOT/");b=start.index('load=lambda')
start=start[:a]+"B=ROOT/'output/h5-capacity-sat-batch-20261107';F=B/'audit';P=ROOT/'output/h5-strip-capacity-probe-20261107';S=ROOT/'output/h5-strip-capacity-set-20261107'\n"+start[b:]
a=start.index('front=')
start=start[:a]+"""front=load(F/'checks.json');probe=load(P/'audit/checks.json');source=load(S/'audit/checks.json');controls=load(ROOT/'output/h5-weighted-capacity-controls-20261107/checks.json')
assert front['passed'] and front['remaining_fixed29_choices']==4 and front['accepted_proofs']==0 and front['limited_calls']==4
assert probe['passed'] and probe['independently_certified_capacity_constraints']==4
assert source['passed'] and source['source_necessary_inequalities']==16 and source['cases_with_genuine_new_source_information']==4
assert controls['passed']
inspection=load(ROOT/'output/h5-capacity-limited-prefixes-20261107/checks.json');assert inspection['passed'] and inspection['complete_prefix_candidates']==0 and len(inspection['inspections'])==4
"""
inventory=old[old.index('inventory_ast='):old.index('folders=')]
inventory=inventory.replace('seal_h5_polygon_clearance_proofs_20261107.py','seal_h5_exact_circle_forest_20261107.py').replace("PARENTS.append(ROOT/'benchmarks/results/h5-polygon-clearance-proofs-20261107')", "PARENTS.append(ROOT/'benchmarks/results/h5-exact-circle-forest-20261107')")
# The preceding sealer derives its inventory by executing an AST slice itself.
# Copy that entire derivation through its previous-parent append, then add it.
inventory=old[old.index('inventory_ast='):old.index('walker=')]+"PARENTS.append(ROOT/'benchmarks/results/h5-exact-circle-forest-20261107')\n"+old[old.index('walker='):old.index('folders=')]
body="""folders=[B,P,S]+[ROOT/'output'/n for n in ['h5-strip-capacity-probe-process-20261107','h5-strip-capacity-set-process-20261107','h5-weighted-capacity-controls-20261107','h5-capacity-limited-prefixes-20261107']]
for row in load(B/'plan.json')['selection']:folders.extend(ROOT/'output'/row[key] for key in ['model','call','result_audit'])
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*capacity*20261107.py']:
    for p in (ROOT/'output').glob(pattern):
        if p.is_file():add('helpers/'+p.name,p)
for name in ['ccd1.py','pack_h5_evidence_archive.py',walker.name,'seal_h5_exact_circle_forest_20261107.py','seal_h5_polygon_clearance_proofs_20261107.py']:
    add('helpers/'+name,ROOT/'output'/name)
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(F/'checks.json','frontier-audit.json'),(F/'case-results.json','case-results.json'),(F/'remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(F/'remaining-source-graphs.json','remaining-source-graphs.json'),(F/'next-step.json','next-step.json'),(B/'process.json','batch-process.json'),(P/'audit/checks.json','first-capacity-audit.json'),(S/'audit/checks.json','capacity-set-audit.json'),(S/'audit/capacity-constraints.json','capacity-constraints.json'),(ROOT/'output/h5-weighted-capacity-controls-20261107/checks.json','encoding-controls.json'),(ROOT/'output/h5-capacity-limited-prefixes-20261107/checks.json','stream-inspection.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
"""
report='''# Source strip capacities and weighted models — 2026-11-07

Sixteen independently verified strip-capacity inequalities add geometric
information beyond the pairwise conflict models. Every strengthened model
passes a full audit, but **all four bounded calls stop at the proof-size limit**.
No further fixed arrangement or whole allocation is excluded and no placement
is produced. The frontier remains **four of 455 fixed arrangements**, with 451
excluded at original 0.2 mm clearance and 427 even at zero clearance. All 440
whole allocations remain; H2/H5 stay open at **60% completed milestone weight**.

## Necessary constraints involving multiple parts

A certified source-inner rectangle crosses a common horizontal line for every
anchor in a closed cell when its highest possible bottom is at or below that
line and its lowest possible top is at or above it. Its whole possible horizontal
extent must also lie inside one strip [L,U]. At most one component per cell is
used. For k selected parts, their disjoint line intervals of widths w_i require
at least the original 200 micrometre clearance between adjacent intervals:

`sum(w_i + 200) <= U - L + 200`.

The vertical construction is symmetric. Downward division by a fixed positive
quantum yields a weaker necessary integer inequality. No validator tolerance or
increased clearance is used, and the argument covers every closed anchor cell.

[The first probe audit]({NAME}/first-capacity-audit.json) checks 9,054 source
members and 76 nonconflicting pairs in four selected counterexamples. Each
selection obeys all graph pair clauses but violates its source strip bound.
These are **partial counterexamples to pair clauses alone**, not full-model
witnesses or valid placements. The complete preparation/audit processes take
0.692667/0.368121 seconds.

[The deterministic capacity set]({NAME}/capacity-set-audit.json) retains those
four bounds and adds three source-certified inequalities per case. Candidate
lines and strips are frozen before preparation; a deterministic overlap-aware
selection chooses diverse bounds. All **19,589 source members and 16 inequalities**
pass independent geometric readback. Complete preparation/audit processes take
1.503837/0.447901 seconds. [The exact constraints]({NAME}/capacity-constraints.json)
preserve original cell indices, source weights and strip definitions.

## Weighted Boolean encoding

Cells with the same weight are grouped only inside an already verified complete
conflict clique. Each class has an explicit OR variable. Since at most one cell
in the full clique can be selected, the class weighted sum equals the original
selected-cell weighted sum. Dividing all weights by their gcd and flooring the
bound is exact for that integer sum.

An acyclic prefix circuit represents `Y[i,j] = (weighted prefix i >= j)` by
`previous[j] OR (selector[i] AND previous[j-weight[i]])`. A final negative unit
forbids threshold bound+1. Every local gate truth table, source class, clause,
variable index and final unit is checked independently; all original pair
conflicts and both eight-part family requirements are preserved.

[Exhaustive small controls]({NAME}/encoding-controls.json) cover 121 weight
vectors, 14,930 selector/bound assignments and 216,260 exact weighted-prefix
checks. [The complete research-model audit]({NAME}/frontier-audit.json) verifies
659 weight classes, 77,267 weighted gates, 2,968,117 total clauses, all 15,208,033
original graph conflicts and all 33,803,472 graph pairs. Source cell-capacity
proofs cover all 16,267 cells. Every case includes new source information; the
closed earlier models are not called again.

## Four closed limited results

[The batch]({NAME}/batch-process.json) closes in **138.118836 seconds**.
Each call preserves the frozen 60-second search, one-million-conflict, 64 MiB
proof and 2 GiB aggregate-memory limits, complete process limits and Windows
Job Object descendant closure. [All four results]({NAME}/case-results.json)
stop at the proof-byte cap, with no accepted proof, assignment or active child.
The first [read-only stream inspections]({NAME}/stream-inspection.json) find
no complete prefix ending in an added empty clause; all streams retain their
truncated endings. No checker call or exclusion follows. These calls remain
closed and will not be repeated, reseeded or extended.

The remaining empty-site triples are [0,5,10], [5,10,11], [10,11,12] and
[11,12,13]. [The next constructive hypothesis]({NAME}/next-step.json) frees
12 cog positions with the validated nine-part small sheet. The earlier
[independent-row constructions](h5-expanded-joint-and-staged-row-constructions-20261104.md)
used 13 cogs with an 11-part small sheet. Their closed results do not establish
this new source domain. Fresh stock/core domains, mover/row and row/row regions,
source identity controls and complete preparation charges must precede a new
bounded construction. No full66 source/native/material validation, 60/90-second
construction claim or production integration is asserted here.

Production, READMEs and release assets remain unchanged. All failed and limited
bytes are preserved. [The manifest]({NAME}/raw-manifest.json) contains
{archive['archive_members']} new canonical members in {archive['archive_parts']}
ZIP parts, totaling {archive['archive_bytes']:,} bytes.
[Historical references]({NAME}/external-evidence.json) and
[source bindings]({NAME}/source-bindings.json) retain the earlier evidence.
Independent archive verification is required before commit.
'''
tail="report=f"+repr(report)+"\nwith OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\\n') as f:f.write(report)\n"
note="\n\n**2026-11-07 H5 source strip capacities:** [independent geometry and weighted-model audits]({link}) verify 16 necessary multi-part inequalities over 19,589 source members. Four partial selections prove information absent from pair clauses alone; they are not full-model witnesses. Exhaustive weighted-prefix controls and full audits verify 659 weight classes, 77,267 weighted gates and 2,968,117 clauses while preserving all 15,208,033 graph conflicts. Four fresh bounded calls stop at their 64 MiB proof caps; the complete batch closes in 138.118836 s, with no complete contradiction prefix, exclusion or placement. Four of 455 fixed arrangements and all 440 whole allocations remain. The next constructive hypothesis uses 12 movable cogs with the source-valid nine-part small sheet, distinct from earlier closed 13-cog/short11 models; fresh source domains and interactions must be audited before another construction. Every closed call stays closed. H2/H5 remain open at 60%; no new release is warranted.\n"
tail+='note='+repr(note)+"\nfor name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))\n"
tail+="""p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8')
a='Latest H5 evidence: [exact circular clearance and factored conflicts](../benchmarks/results/h5-exact-circle-forest-20261107.md).';assert s.count(a)==1
s=s.replace(a,f'Latest H5 evidence: [source strip capacities and weighted models](../benchmarks/results/{NAME}.md).',1)
a='add 15 conflicts. Four new factored models\\nstill reach their proof-size limits, so these calls add no exclusion.';assert s.count(a)==1
s=s.replace(a,'add 15 conflicts. Sixteen further source strip-capacity inequalities now pass\\nindependent audits. Four weighted models still reach their proof-size limits,\\nso these calls add no exclusion. The next constructive hypothesis frees twelve\\ncogs with the validated nine-part small sheet.',1)
with p.open('w',encoding='utf-8',newline='\\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\\nbenchmarks/results/{NAME}/** -text -whitespace\\n')
print({'sealed':True,**archive,'remaining':4})
"""
with (ROOT/'output/seal_h5_capacity_models_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(start+inventory+body+tail)
s=(ROOT/'output/verify_h5_exact_circle_forest_20261107.py').read_text(encoding='utf-8').replace('h5-exact-circle-forest-20261107','h5-strip-capacity-models-20261107')
with (ROOT/'output/verify_h5_capacity_models_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':True,'sealed':False})
