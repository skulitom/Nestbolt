"""First read-only complete-prefix inspection of the four new limited streams."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-capacity-limited-prefixes-20261107';OUT.mkdir()
OLD=ROOT/'output/h5-unresolved-proof-prefixes-20261107';EXE=OLD/'prefix-parser.exe';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(OLD/'checks.json')['passed'] and digest(EXE)==load(OLD/'checks.json')['parser_sha256']
rows=[];inputs={p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,OLD/'checks.json',ROOT/'output/h5-capacity-sat-batch-20261107/audit/remaining-source-graphs.json']}
for row in load(ROOT/'output/h5-capacity-sat-batch-20261107/audit/remaining-source-graphs.json'):
    folder=ROOT/row['call'];process=load(folder/'process.json');assert process['closed'] and process['job']['active_processes']==0 and process['limit_reason']=='proof-byte-limit'
    raw=folder/'proof.drat.bin';before=digest(raw);t=time.perf_counter();r=subprocess.run([str(EXE),str(raw)],capture_output=True,timeout=20,check=True)
    parsed=json.loads(r.stdout);assert digest(raw)==before
    rows.append({'graph_index':row['refinement_index'],'empty_sites':row['empty_sites'],'source':raw.relative_to(ROOT).as_posix(),'source_sha256':before,'source_bytes':raw.stat().st_size,'seconds':time.perf_counter()-t,**parsed,'certificate_verified':False,'research_calls':0,'checker_calls':0})
    inputs[raw.relative_to(ROOT).as_posix()]=before;inputs[(folder/'process.json').relative_to(ROOT).as_posix()]=digest(folder/'process.json')
for name,value in [('plan.json',{'inputs':inputs,'first_inspection_only':True,'no_search_or_checker_call':True}),('checks.json',{'passed':True,'inspections':rows,'complete_prefix_candidates':sum(bool(r['first_empty_end']) for r in rows),'research_calls':0,'checker_calls':0,'syntactic_prefix_is_not_a_proof':True})]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(rows)
