from pathlib import Path
import runpy,sys
p=Path(__file__).resolve().parent/'audit_h5_capacity_sat_model_20261107.py'
sys.argv=[str(p),'16']
runpy.run_path(str(p),run_name='__main__')
