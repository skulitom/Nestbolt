from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-capacity-sat-batch-20261107';OUT.mkdir();SOURCE=ROOT/'output/h5-strip-capacity-set-20261107/audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(SOURCE/'checks.json')['passed'] and load(SOURCE/'checks.json')['cases_with_genuine_new_source_information']==4
assert load(ROOT/'output/h5-weighted-capacity-controls-20261107/checks.json')['passed']
keys=['prepare_h5_clique_sat_model_20261107.py','audit_h5_clique_sat_model_20261107.py','solve_h5_clique_sat_20261107.py','run_h5_clique_sat_20261107.py','audit_h5_clique_sat_result_20261107.py'];templates={k:(ROOT/'output'/k).read_text(encoding='utf-8') for k in keys[2:]};rows=[]
for item in load(SOURCE/'capacity-constraints.json'):
    index=item['refinement_index'];model=f'h5-capacity-sat-{index:02d}-model-20261107';call=f'h5-capacity-sat-{index:02d}-call-20261107';audit=f'h5-capacity-sat-{index:02d}-result-audit-20261107'
    renamed={k:k.replace('_20261107.py',f'_capacity_{index:02d}_20261107.py') for k in keys};scripts={}
    for k in keys:
        if k in keys[:2]:
            common='prepare_h5_capacity_sat_model_20261107.py' if k==keys[0] else 'audit_h5_capacity_sat_model_20261107.py'
            text=f"from pathlib import Path\nimport runpy,sys\np=Path(__file__).resolve().parent/{common!r}\nsys.argv=[str(p),{str(index)!r}]\nrunpy.run_path(str(p),run_name='__main__')\n"
        else:
            text=templates[k].replace('h5-first57-clique-sat-model-20261107',model).replace('h5-first57-clique-sat-call-20261107',call).replace('h5-first57-clique-sat-result-audit-20261107',audit)
            for before,after in renamed.items():text=text.replace(before,after)
            if k.startswith('solve_'):
                text=text.replace("'proof_bytes':(OUT/'proof.drat.bin').stat().st_size", "'proof_bytes_before_solver_destruction':(OUT/'proof.drat.bin').stat().st_size")
                text=text.replace("write('result.json',result);print(result)","result.update({'proof_bytes':(OUT/'proof.drat.bin').stat().st_size,'proof_sha256_after_solver_destruction':sha256((OUT/'proof.drat.bin').read_bytes()).hexdigest()})\nwrite('result.json',result);print(result)")
            if k==keys[-1]:text=text.replace('h5-first57-frontier-refined-trees-20261106/audit/remaining-fixed29-choices.json','h5-forest-sat-batch-20261107/audit/remaining-fixed29-choices.json')
        p=ROOT/'output'/renamed[k];compile(text,str(p),'exec')
        with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
        scripts[k]={'path':p.relative_to(ROOT).as_posix(),'sha256':digest(p)}
    gc=load(ROOT/item['graph']/'checks.json');rows.append({'graph_index':index,'empty_sites':item['empty_sites'],'compact_nodes':gc['compact_nodes'],'source_capacity_inequalities':4,'graph':item['graph'],'model':model,'call':call,'result_audit':audit,'scripts':scripts})
rows.sort(key=lambda r:(r['compact_nodes'],r['graph_index']))
inputs=[Path(__file__),SOURCE/'plan.json',SOURCE/'checks.json',SOURCE/'capacity-constraints.json',ROOT/'output/prepare_h5_capacity_sat_model_20261107.py',ROOT/'output/audit_h5_capacity_sat_model_20261107.py',ROOT/'output/prepare_h5_capacity_audit_template_20261107.py',ROOT/'output/h5-weighted-capacity-controls-20261107/plan.json',ROOT/'output/h5-weighted-capacity-controls-20261107/checks.json',ROOT/'output/h5-forest-sat-batch-20261107/audit/remaining-fixed29-choices.json']+[ROOT/'output'/k for k in keys[2:]]
plan={'utc':datetime.now(timezone.utc).isoformat(),'selection':rows,'cases':4,'baseline_fixed29_choices':4,'baseline_required_clearance_exclusions':451,'frozen_per_case_search_seconds':60,'frozen_conflict_budget':1000000,'frozen_binary_proof_bytes':67108864,'frozen_job_committed_memory_bytes':2147483648,'one_call_per_new_capacity_model':True,'retry_permitted':False,'stage_caps_seconds':{'prepare':120,'model_audit':120,'call':100,'result_audit':90},'global_batch_seconds':1200,'full_job_construction_budget_claimed':False,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'source_novelty':'Four independently proved source strip capacities per case; at least one has a certified graph-independent violating partial selection and therefore adds information absent from pair clauses. No prior search is repeated or given larger limits.'}
with (OUT/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(plan,f,indent=2);f.write('\n')
runner=(ROOT/'output/run_h5_clique_sat_batch_20261107.py').read_text(encoding='utf-8').replace('h5-first57-clique-sat-batch-20261107','h5-capacity-sat-batch-20261107')
with (ROOT/'output/run_h5_capacity_sat_batch_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(runner)
print({'prepared':True,'cases':4,'order':[r['empty_sites'] for r in rows]})
