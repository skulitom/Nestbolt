from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/audit_h5_clique_sat_model_forest_21_20261107.py').read_text(encoding='utf-8')
text=old.replace('import json,time','import json,time,sys,math\nfrom functools import reduce').replace("OUT=ROOT/'output/h5-forest-sat-21-model-20261107'","INDEX=int(sys.argv[1]);OUT=ROOT/f'output/h5-capacity-sat-{INDEX:02d}-model-20261107'")
block='''    assert top==checks['base_variable_top']
    source=ROOT/plan['capacity_source'];assert load(source/'checks.json')['passed']
    original=next(r for r in load(source/'capacity-constraints.json') if r['refinement_index']==INDEX)
    assert original['graph']==plan['graph'] and original['genuine_new_source_constraint_counterexample']==plan['genuine_new_source_information']
    caps=load(OUT/'capacities.json');assert len(caps)==len(original['constraints'])==4
    covers=load(G/'root-covers.json');capacity_gate_count=capacity_truth_rows=capacity_class_count=capacity_clause_count=0
    for cap,source_constraint in zip(caps,original['constraints']):
        before_counter=counter;assert cap['index']==source_constraint['index'] and cap['source_constraint']==source_constraint
        weights={t['node']:t['weight'] for t in source_constraint['terms']};assert len(weights)==len(source_constraint['terms']) and all(w>0 for w in weights.values())
        divisor=reduce(math.gcd,weights.values());bound=source_constraint['maximum']//divisor
        assert divisor==cap['divisor'] and bound==cap['scaled_bound'] and all(w%divisor==0 for w in weights.values())
        expected=[]
        for family,cover_groups in enumerate(covers):
            for ci,cells in enumerate(cover_groups):
                grouped={}
                for cell in cells:
                    if cell in weights:grouped.setdefault(weights[cell],[]).append(cell)
                for weight,ids in sorted(grouped.items()):expected.append((family,ci,weight,ids))
        assert len(cap['classes'])==len(expected);all_class_members=[]
        for actual,(family,ci,weight,ids) in zip(cap['classes'],expected):
            top+=1;assert actual=={'family':family,'clique':ci,'weight':weight,'scaled_weight':weight//divisor,'cells':ids,'variable':top}
            all_class_members.extend(ids)
            for cell in ids:assert clause()==[-(cell+1),top]
            assert clause()==[-top]+[cell+1 for cell in ids];capacity_class_count+=1
        assert sorted(all_class_members)==sorted(weights) and top==cap['class_variable_top']
        # Every full clique was already checked above, so a weighted OR class
        # represents exactly its selected member count on graph-independent sets.
        weighted_gates=load(OUT/f"capacity-{cap['index']:02d}-gates.json");position=0;prev={0:True};prefix_weight=0
        for i,term in enumerate(cap['classes'],1):
            x,w=term['variable'],term['scaled_weight'];prefix_weight+=w;current={0:True}
            for j in range(1,min(prefix_weight,bound+1)+1):
                top+=1;y=top;a=prev.get(j,False);b=True if j<=w else prev[j-w]
                assert b is not False
                assert weighted_gates[position]=={'i':i,'j':j,'weight':w,'x':x,'a':a,'b':b,'y':y};position+=1
                local=[clause() for _ in range(4-int(a is False)-int(b is True))];variables=sorted({v for v in [a,b,x,y] if type(v) is int})
                assert all(0<v<=y for v in variables) and all(set(map(abs,c))<=set(variables) for c in local)
                for values in product([False,True],repeat=len(variables)):
                    assignment=dict(zip(variables,values));val=lambda v:v if type(v) is bool else assignment[v]
                    satisfied=all(any(assignment[abs(l)]==(l>0) for l in c) for c in local)
                    assert satisfied==(val(y)==(val(a) or(val(x) and val(b))));capacity_truth_rows+=1
                current[j]=y
            prev=current
        final=prev.get(bound+1,False);assert final==cap['final'] and position==len(weighted_gates)==cap['gate_count']
        if final is not False:assert clause()==[-final]
        assert counter-before_counter==cap['clauses'];capacity_clause_count+=cap['clauses'];capacity_gate_count+=position
    assert capacity_gate_count==checks['weighted_threshold_gates'] and capacity_clause_count==checks['capacity_clauses'] and capacity_class_count==checks['capacity_classes']
'''
needle="    assert f.read()==''";assert text.count(needle)==1;text=text.replace(needle,block+needle)
needle="'acyclic_threshold_gates':len(gates)";assert text.count(needle)==1;text=text.replace(needle,"'weighted_capacity_inequalities':len(caps),'weighted_capacity_classes':capacity_class_count,'weighted_threshold_gates':capacity_gate_count,'weighted_truth_table_rows':capacity_truth_rows,'weighted_capacity_clauses':capacity_clause_count,"+needle)
text=text.replace('A valid continuous completion induces a satisfying assignment;', 'Source common-line strip inequalities are necessary for every continuous completion. Complete conflict cliques permit at most1 selected cell, so each exact OR class weighted sum equals its original cell weighted sum. GCD division with a floored bound is exact for the integer class sum. Independently checked weighted prefix gates and a negative final threshold enforce every source bound. A valid continuous completion induces a satisfying assignment;')
p=ROOT/'output/audit_h5_capacity_sat_model_20261107.py';compile(text,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print('Prepared independent capacity model audit.')
