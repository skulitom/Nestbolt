from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from functools import reduce
import json,time,sys,math
from h5_sat_encoding_20261107 import threshold
from h5_sat_forest_encoding_20261107 import forest
from h5_weighted_capacity_encoding_20261107 import atmost
ROOT=Path(__file__).resolve().parents[1];INDEX=int(sys.argv[1]);OUT=ROOT/f'output/h5-capacity-sat-{INDEX:02d}-model-20261107';SOURCE=ROOT/'output/h5-strip-capacity-set-20261107/audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();start=time.perf_counter();OUT.mkdir()
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(SOURCE/'checks.json')['passed'];constraints=next(r for r in load(SOURCE/'capacity-constraints.json') if r['refinement_index']==INDEX);G=ROOT/constraints['graph'];gc=load(G/'checks.json');nodes=load(G/'nodes.json');covers=load(G/'root-covers.json');n=len(nodes)
assert load(ROOT/'output/h5-weighted-capacity-controls-20261107/checks.json')['passed'] and len(constraints['constraints'])==4
paths=[Path(__file__),SOURCE/'plan.json',SOURCE/'checks.json',SOURCE/'capacity-constraints.json',G/'checks.json',G/'nodes.json',G/'conflicts.bin',G/'root-covers.json',G.parent/'audit/plan.json',G.parent/'audit/checks.json',ROOT/'output/h5-first57-necessary-rectangles-20261104/geometry-domains.json']+[ROOT/'output'/p for p in ['h5_sat_encoding_20261107.py','h5_sat_forest_encoding_20261107.py','h5_weighted_capacity_encoding_20261107.py','h5-weighted-capacity-controls-20261107/plan.json','h5-weighted-capacity-controls-20261107/checks.json','h5-sat-forest-controls-20261107/checks.json','h5-sat-controls-v2-20261107/checks.json','h5-windows-job-controls-v4-20261107/checks.json','h5-windows-job-external-stop-20261107/checks.json']]
write('plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'graph':G.relative_to(ROOT).as_posix(),'source_selection':gc['source_selection'],'capacity_source':SOURCE.relative_to(ROOT).as_posix(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Keep the exact factored pair model and at least8 selected cells per family. Add four source-necessary common-line strip capacities. Within each complete conflict clique, group capacity members by equal source weight and use an exact OR selector for each class. At most1 original cell per clique makes the class weighted sum exactly the original weighted sum on independent sets. Divide all positive weights by their gcd and floor the bound, then use explicit acyclic weighted prefix thresholds to forbid total>=bound+1. Every source bound and every class/gate/clause needs an independent audit before one fresh call.','genuine_new_source_information':constraints['genuine_new_source_constraint_counterexample'],'previous_graph_calls_closed':True,'maximum_model_preparation_seconds':120,'maximum_model_audit_seconds':120,'solver_call_count':1,'solver_search_seconds':60,'solver_conflict_budget':1000000,'solver_complete_process_seconds':90,'native_job_hard_wall_ms':85000,'solver_aggregate_committed_memory_bytes':2147483648,'binary_proof_byte_limit':67108864,'checker_seconds':60,'checker_complete_process_seconds':70,'retry_permitted':False,'required_job_clearance_mm':.2,'full_construction_60_or_90_second_claim':False,'prior_consumed_preparation_stays_charged':True})
raw=(G/'conflicts.bin').read_bytes();rb=gc['row_bytes'];assert digest(G/'conflicts.bin')==gc['conflict_bytes_sha256'];rows=[int.from_bytes(raw[i*rb:(i+1)*rb],'little') for i in range(n)];edges=sum((r>>(i+1)).bit_count() for i,r in enumerate(rows))
tree,blocks,factored,top,implications=forest(n,rows);forest_top=top;groups=[];families=[];gates=[];extras=[]
for family in [0,1]:
    selected=[]
    for index,cells in enumerate(covers[family]):
        top+=1;var=top;selected.append(var);groups.append({'family':family,'index':index,'variable':var,'compact_nodes':cells})
        extras.extend([[-(i+1),var] for i in cells]);extras.append([-var]+[i+1 for i in cells])
    families.append({'family':family,'group_variables':selected})
group_top=top
for family in [0,1]:
    cs,gs,top,final=threshold(families[family]['group_variables'],8,top);extras.extend(cs);families[family].update({'final':final,'gate_count':len(gs),'threshold_clause_count':len(cs)});gates.extend(dict(g,family=family) for g in gs)
base_top=top;capacity_records=[];capacity_clauses=[];weighted_gate_count=0
for constraint in constraints['constraints']:
    weights={t['node']:t['weight'] for t in constraint['terms']};divisor=reduce(math.gcd,weights.values());bound=constraint['maximum']//divisor;classes=[];before=len(capacity_clauses)
    for family,family_groups in enumerate(covers):
        for ci,cells in enumerate(family_groups):
            grouped={}
            for i in cells:
                if i in weights:grouped.setdefault(weights[i],[]).append(i)
            for weight,ids in sorted(grouped.items()):
                top+=1;classes.append({'family':family,'clique':ci,'weight':weight,'scaled_weight':weight//divisor,'cells':ids,'variable':top})
                capacity_clauses.extend([[-(i+1),top] for i in ids]);capacity_clauses.append([-top]+[i+1 for i in ids])
    class_top=top;cs,gs,top,final=atmost([c['variable'] for c in classes],[c['scaled_weight'] for c in classes],bound,top);capacity_clauses.extend(cs);weighted_gate_count+=len(gs)
    write(f"capacity-{constraint['index']:02d}-gates.json",gs)
    capacity_records.append({'index':constraint['index'],'source_constraint':constraint,'divisor':divisor,'scaled_bound':bound,'classes':classes,'class_variable_top':class_top,'gate_count':len(gs),'final':final,'clauses':len(capacity_clauses)-before})
for name,value in [('forest.json',tree),('neighbor-blocks.json',blocks),('groups.json',groups),('families.json',families),('threshold-gates.json',gates),('capacities.json',capacity_records)]:write(name,value)
all_clauses=factored+extras+capacity_clauses
with (OUT/'model.cnf').open('x',encoding='utf-8',newline='\n') as f:
    f.write(f'p cnf {top} {len(all_clauses)}\n')
    for c in all_clauses:f.write(' '.join(map(str,c))+' 0\n')
elapsed=time.perf_counter()-start;assert elapsed<120
checks={'passed':True,'nodes':n,'group_variables':len(groups),'family_group_counts':list(map(len,covers)),'group_variable_top':group_top,'base_variable_top':base_top,'variables':top,'threshold_gates':len(gates),'weighted_threshold_gates':weighted_gate_count,'capacity_inequalities':len(capacity_records),'capacity_classes':sum(len(r['classes']) for r in capacity_records),'capacity_clauses':len(capacity_clauses),'original_graph_edges':edges,'forest_variables':forest_top-n,'forest_nodes':len(tree),'forest_implication_clauses':implications,'neighbor_block_clauses':sum(len(r['segments']) for r in blocks),'conflict_clauses':len(factored),'additional_clauses':len(extras)+len(capacity_clauses),'clauses':len(all_clauses),'model_bytes':(OUT/'model.cnf').stat().st_size,'model_sha256':digest(OUT/'model.cnf'),'complete_preparation_seconds':elapsed,'solver_calls':0}
write('checks.json',checks);print(checks)
