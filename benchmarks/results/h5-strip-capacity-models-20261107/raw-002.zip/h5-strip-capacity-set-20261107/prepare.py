"""Add a small diverse set of independently checkable source strip inequalities."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-strip-capacity-set-20261107';PROBE=ROOT/'output/h5-strip-capacity-probe-20261107';SRC=ROOT/'output/h5-first57-necessary-rectangles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');assert load(PROBE/'audit/checks.json')['passed']
certified=load(PROBE/'audit/capacity-constraints.json');assert len(certified)==4;geom=load(SRC/'geometry-domains.json')
inputs=[Path(__file__),PROBE/'audit/plan.json',PROBE/'audit/checks.json',PROBE/'audit/capacity-constraints.json',SRC/'geometry-domains.json']
for row in certified:inputs.extend([ROOT/row['source_certificate'],ROOT/row['graph']/'nodes.json',ROOT/row['graph']/'root-covers.json',ROOT/row['graph']/'checks.json'])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':certified,'constraints_per_case':4,'new_line_grid':'16 equally spaced rational lines spanning the minimum lower through maximum upper guaranteed source bands, both axes; doubled coordinate uses floor of rational grid.','new_strips':'Full source extent, left/right halves, three thirds; exact integer endpoints.','quantum_um':1000,'gap_um':200,'ranking':'Keep the previously certified pair-graph counterexample constraint. Then greedily maximize (source clique upper/bound)*(1-maximum Jaccard member overlap with selected constraints), tie-break by stored candidate ordinal. All comparisons exact rational.','per_case_seconds':15,'preparation_seconds':70,'maximum_process_seconds':80,'repeat_permitted':False,'SAT_calls':0,'method':'Construct additional source-necessary capacity inequalities at distinct fixed lines/strips, without repeating the previous greedy witness search. A complete source conflict-clique partition supplies only a cheap redundancy bound. Every selected inequality must be independently checked against source members; the existing audited counterexample proves actual new information beyond pair clauses for every case.'})
results=[]
for row in certified:
    case_start=time.perf_counter();nodes=load(ROOT/row['graph']/'nodes.json');covers=load(ROOT/row['graph']/'root-covers.json');clique={i:(f,g) for f,groups in enumerate(covers) for g,group in enumerate(groups) for i in group}
    old=load(ROOT/row['source_certificate']);mandatory={k:old[k] for k in ['axis','line_doubled_um','strip_um','members','gap_um']};mandatory.update({'quantum_um':1000,'maximum':old['quantized_capacity'],'source':'previous-independent-counterexample','counterexample':row['pair_graph_counterexample']})
    selected=[mandatory];pool=[];seen={tuple((m['node'],(m['width_um']+200)//1000) for m in mandatory['members'])+(('bound',mandatory['maximum']),)};orders=[]
    for axis in [0,1]:
        other=1-axis;components=[]
        for ni,node in enumerate(nodes):
            a=node['bounds_um']
            for ri,r in enumerate(geom[node['geometry']]['inner_rectangles_um']):
                lo,hi=a[other+2]+r[other],a[other]+r[other+2]
                if lo<=hi:components.append((ni,ri,lo,hi,a[axis]+r[axis],a[axis+2]+r[axis+2],r[axis+2]-r[axis]))
        lower=min(c[2] for c in components);upper=max(c[3] for c in components);lines=sorted({2*lower+(2*(upper-lower)*k)//15 for k in range(16)})
        lo=min(c[4] for c in components);hi=max(c[5] for c in components);mid=(lo+hi)//2;third1=lo+(hi-lo)//3;third2=lo+2*(hi-lo)//3;strips=[(lo,hi),(lo,mid),(mid,hi),(lo,third1),(third1,third2),(third2,hi)]
        orders.append({'axis':axis,'line_doubled_um':lines,'strips_um':strips})
        for line in lines:
            for left,right in strips:
                assert time.perf_counter()-case_start<15 and time.perf_counter()-start<70
                members={}
                for ni,ri,a,b,x0,x1,width in components:
                    if 2*a<=line<=2*b and left<=x0 and x1<=right:
                        if ni not in members or (width,-ri)>(members[ni]['width_um'],-members[ni]['component']):members[ni]={'node':ni,'component':ri,'width_um':width,'extent_um':[x0,x1]}
                if len(members)<3:continue
                bound=(right-left+200)//1000;terms=tuple((i,(members[i]['width_um']+200)//1000) for i in sorted(members));key=terms+(('bound',bound),)
                if key in seen:continue
                seen.add(key);maxima={}
                for i,weight in terms:maxima[clique[i]]=max(maxima.get(clique[i],0),weight)
                upper_bound=sum(maxima.values())
                if upper_bound<=bound:continue
                pool.append({'axis':axis,'line_doubled_um':line,'strip_um':[left,right],'gap_um':200,'quantum_um':1000,'maximum':bound,'members':[members[i] for i in sorted(members)],'source':'new-fixed-grid-capacity','clique_upper':upper_bound,'candidate_ordinal':len(pool)})
    remaining=list(range(len(pool)))
    while len(selected)<4 and remaining:
        sets=[{m['node'] for m in c['members']} for c in selected]
        def score(i):
            c=pool[i];current={m['node'] for m in c['members']};overlap=max(F(len(current&s),len(current|s)) for s in sets)
            return F(c['clique_upper'],c['maximum'])*(1-overlap),-i
        best=max(remaining,key=score);remaining.remove(best);selected.append(pool[best])
    assert len(selected)==4
    record={'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'graph':row['graph'],'constraints':selected,'candidate_grid':orders,'nontrivial_new_candidates':len(pool),'seconds':time.perf_counter()-case_start,'independent_audit_pending':True}
    write(OUT/f"choice-{row['refinement_index']:02d}.json",record);results.append({k:record[k] for k in ['refinement_index','empty_sites','graph','nontrivial_new_candidates','seconds']});print(json.dumps(results[-1]),flush=True)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'choices':results,'constraints':16,'new_fixed_grid_constraints':12,'carried_pair_counterexample_constraints':4,'SAT_calls':0,'H5_complete':False})
