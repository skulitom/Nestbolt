"""Bounded new source-capacity probe; no SAT or placement call."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
import json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-strip-capacity-probe-20261107'
G=ROOT/'output/h5-exact-circle-graphs-20261107';FRONT=ROOT/'output/h5-forest-sat-batch-20261107/audit';SRC=ROOT/'output/h5-first57-necessary-rectangles-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(G/'audit/checks.json')['passed'] and load(FRONT/'checks.json')['passed']
selection=sorted(load(FRONT/'remaining-source-graphs.json'),key=lambda r:r['refinement_index']);assert len(selection)==4
geom=load(SRC/'geometry-domains.json');assert F(1,5)<=F(load(JOB)['clearance']);gap=200
inputs=[Path(__file__),G/'audit/plan.json',G/'audit/checks.json',FRONT/'checks.json',FRONT/'remaining-source-graphs.json',SRC/'geometry-domains.json',SRC/'audit/plan.json',SRC/'audit/checks.json',JOB]
for row in selection:inputs.extend(ROOT/row['graph']/name for name in ['nodes.json','conflicts.bin','checks.json'])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':selection,'line_candidates':'All distinct guaranteed-band endpoints and adjacent interval midpoints, represented in doubled micrometres. Rank by eligible component count descending then coordinate; retain first64 per axis.','axes':[0,1],'max_lines_per_axis':64,'strip_widths_um':[200000,300000,400000,600000,800000,1000000],'strip_left_step_um':100000,'include_full_span':True,'source_gap_um':gap,'greedy_orders':['width descending, current pool conflict degree ascending, node','width/(degree+1) descending, node','extent midpoint ascending, width descending, node'],'maximum_selected_per_family':8,'first_witness_per_case':True,'case_search_seconds':10,'case_complete_seconds':12,'global_search_seconds':45,'preparation_seconds':55,'maximum_process_seconds':65,'quantum_candidates_descending_um':[1000,200,100,10,1],'repeat_permitted':False,'SAT_calls':0,'native_validation_calls':0,'method':'Every selected source-inner rectangle crosses a common line for EVERY anchor in its closed cell and lies wholly inside one strip along that line. Use at most one eligible component per node. Pairwise source clearance implies disjoint intervals with at least200um gaps, hence sum(width+200)<=strip_span+200. Deterministic greedy graph-independent selections seek a certificate that this source capacity is not implied by pair clauses alone. This is a partial necessary-graph selection, never a placement or a full-model SAT claim. Failed/cutoff scans prove no absence.'})
results=[]
for row in selection:
    case_start=time.perf_counter();folder=OUT/f"choice-{row['refinement_index']:02d}";folder.mkdir();source=ROOT/row['graph'];nodes=load(source/'nodes.json');n=len(nodes);gc=load(source/'checks.json');raw=(source/'conflicts.bin').read_bytes();rb=gc['row_bytes'];assert digest(source/'conflicts.bin')==gc['conflict_bytes_sha256']
    graph=[int.from_bytes(raw[i*rb:(i+1)*rb],'little') for i in range(n)];families=[r['family'] for r in nodes];family_masks=[sum(1<<i for i,f in enumerate(families) if f==v) for v in [0,1]]
    deadline=min(case_start+10,started+45);found=None;considered=greedy_runs=0;axis_plans=[];limited=False
    for axis in [0,1]:
        transverse=1-axis;components=[]
        for ni,node in enumerate(nodes):
            a=node['bounds_um']
            for ri,r in enumerate(geom[node['geometry']]['inner_rectangles_um']):
                low=a[transverse+2]+r[transverse];high=a[transverse]+r[transverse+2]
                if low<=high:components.append([ni,ri,low,high,a[axis]+r[axis],a[axis+2]+r[axis+2],r[axis+2]-r[axis]])
        array=np.array(components,dtype=np.int64);ends=sorted(set(array[:,2].tolist()+array[:,3].tolist()));lines=sorted(set([2*v for v in ends]+[a+b for a,b in zip(ends,ends[1:])]))
        ranked=sorted(((int(np.count_nonzero((2*array[:,2]<=line)&(line<=2*array[:,3]))),line) for line in lines),key=lambda x:(-x[0],x[1]))[:64]
        low=int(np.min(array[:,4]));high=int(np.max(array[:,5]));strips=[(low,high)]
        for width in [200000,300000,400000,600000,800000,1000000]:
            if width>high-low:continue
            lefts=sorted(set(list(range(low,high-width+1,100000))+[high-width]));strips.extend((left,left+width) for left in lefts)
        axis_plans.append({'axis':axis,'component_count':len(components),'candidate_line_count':len(lines),'ranked_lines_doubled_um':ranked,'strips_um':strips})
        for eligible_count,line in ranked:
            if time.perf_counter()>=deadline:limited=True;break
            eligible=array[(2*array[:,2]<=line)&(line<=2*array[:,3])]
            for left,right in strips:
                if time.perf_counter()>=deadline:limited=True;break
                members={}
                for item in eligible[(left<=eligible[:,4])&(eligible[:,5]<=right)]:
                    ni,ri,lo,hi,x0,x1,width=map(int,item)
                    if ni not in members or (width,-ri)>(members[ni]['width_um'],-members[ni]['component']):members[ni]={'node':ni,'component':ri,'width_um':width,'extent_um':[x0,x1]}
                if len(members)<3:continue
                considered+=1;pool=sum(1<<i for i in members);degrees={i:(graph[i]&pool).bit_count()-1 for i in members};capacity=right-left+gap
                orders=[sorted(members,key=lambda i:(-members[i]['width_um'],degrees[i],i)),sorted(members,key=lambda i:(-F(members[i]['width_um'],degrees[i]+1),i)),sorted(members,key=lambda i:(sum(members[i]['extent_um']),-members[i]['width_um'],i))]
                for oi,order in enumerate(orders):
                    greedy_runs+=1;available=pool;selected=[];counts=[0,0];weight=0
                    for i in order:
                        if not(available>>i&1):continue
                        selected.append(i);counts[families[i]]+=1;weight+=members[i]['width_um']+gap;available&=~graph[i]
                        if counts[families[i]]==8:available&=~family_masks[families[i]]
                        if weight>capacity:
                            quantum=next(q for q in [1000,200,100,10,1] if sum((members[j]['width_um']+gap)//q for j in selected)>capacity//q)
                            found={'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'graph':row['graph'],'axis':axis,'line_doubled_um':line,'strip_um':[left,right],'gap_um':gap,'members':[members[i] for i in sorted(members)],'selected_nodes':selected,'selected_family_counts':counts,'selected_weight_um':weight,'capacity_um':capacity,'strict_excess_um':weight-capacity,'greedy_order':oi,'quantum_um':quantum,'quantized_capacity':capacity//quantum,'quantized_selected_weight':sum((members[j]['width_um']+gap)//quantum for j in selected),'source_valid_placement':False,'full_model_witness':False}
                            break
                    if found:break
                if found:break
            if found or limited:break
        if found or limited:break
    elapsed=time.perf_counter()-case_start;write(folder/'candidate-order.json',axis_plans)
    if found:write(folder/'capacity-certificate.json',found)
    result={'refinement_index':row['refinement_index'],'empty_sites':row['empty_sites'],'source_selection':row['source_selection'],'graph':row['graph'],'capacity_witness_found':found is not None,'constraints_considered':considered,'greedy_passes':greedy_runs,'limited':limited,'case_seconds':elapsed,'case_complete_cap_overrun_seconds':max(0,elapsed-12),'SAT_calls':0,'whole_arrangements_excluded':0}
    write(folder/'checks.json',result);results.append(result);print(json.dumps(result),flush=True);assert elapsed<12 and time.perf_counter()-started<55
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':results,'capacity_witnesses':sum(r['capacity_witness_found'] for r in results),'total_greedy_passes':sum(r['greedy_passes'] for r in results),'SAT_calls':0,'native_validation_calls':0,'independent_audit_pending':True,'H5_complete':False})
