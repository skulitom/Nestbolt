"""Independent vertical-prefix certificate of the five-millimetre refinement."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free-cog-fine-grid-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-free-cog-area-grid-20261107';AREA=ROOT/'output/h5-three-empty-areas-20261107';G=ROOT/'output/h5-free-cog-geometry-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit',G/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'kernel-stripes.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Verify all80 rational source segment distances and certified winding/simplicity justify a109mm disk for every exact rigid angle. Rebuild every companion raster by direct cell-edge predicates and rectangle slice assignment. Index each five-millimetre cell into its unique audited ten-millimetre parent, preventing excluded cells from returning. Derive compulsory offsets by all16 corner-pair distances, and independently compute every count with vertical prefix sums and column shifts, distinct from horizontal producer stripes. Direct sparse controls verify orientation and zero boundaries. Reconcile all152 full arrays and every case threshold. This covers continuous cells, not sampled center placements.'})
geo=load(G/'geometry.json');assert len(geo['source_disk_edge_certificates'])==80 and all(Q(r['segment_distance_squared'])>11881 for r in geo['source_disk_edge_certificates']);assert load(G/'audit/checks.json')['source_winding_number']==1
h=5000;ny,nx=600,300;radius=109000;left=np.arange(nx)*h;right=left+h;bottom=np.arange(ny)*h;top=bottom+h
def raster(rects,inside):
    a=np.zeros((ny,nx),dtype=bool)
    for l,b,r,t in rects:
        xx=np.flatnonzero((left>=l)&(right<=r) if inside else (right>l)&(left<r));yy=np.flatnonzero((bottom>=b)&(top<=t) if inside else (top>b)&(bottom<t))
        if len(xx) and len(yy):a[yy[0]:yy[-1]+1,xx[0]:xx[-1]+1]=True
    return a
corners=list(product([0,h],repeat=2));offsets=[]
for dx in range(-21,22):
    for dy in range(-21,22):
        if max((a-c-dx*h)**2+(b-d-dy*h)**2 for a,b in corners for c,d in corners)<=radius**2:offsets.append((dy,dx))
savedkernel=load(BASE/'kernel-stripes.json');expected={(dy,dx) for dy,w in savedkernel['horizontal_stripes'] for dx in range(-w,w+1)};assert set(offsets)==expected and len(offsets)==savedkernel['covered_target_cells'];assert (23*h)**2>radius**2
columns=[]
for dx in sorted({x for _,x in offsets}):
    ys=[y for y,x in offsets if x==dx];assert ys==list(range(min(ys),max(ys)+1)) and min(ys)==-max(ys);columns.append((dx,max(ys)))
def occupancy(region):
    prefix=np.concatenate([np.zeros((1,nx),dtype=np.int64),np.cumsum(region,axis=0,dtype=np.int64)],axis=0);out=np.zeros((ny,nx),dtype=np.int64);y=np.arange(ny)
    for dx,w in columns:
        sums=prefix[np.minimum(ny,y+w+1),:]-prefix[np.maximum(0,y-w),:];out[:,max(0,-dx):min(nx,nx-dx)]+=sums[:,max(0,dx):min(nx,nx+dx)]
    return out
fixture=np.zeros((ny,nx),dtype=bool);points=[(0,0),(2,3),(41,56),(ny-1,nx-1)]
for y,x in points:fixture[y,x]=True
control=occupancy(fixture)
for y,x in [(0,0),(5,10),(30,40),(ny-1,nx-1),(ny-1,0),(0,nx-1)]:assert control[y,x]==sum((py-y,px-x) in expected for py,px in points)
cases=load(OLD/'audit/remaining-cases.json');saved={r['case']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==38;results=[]
for case in cases:
    name=case['case'];data=load(AREA/(name+'-capacity.json'));region=raster(data['combined_regions_um'],True)&~raster(data['fixed_inner_obstacles_um'],False)
    with np.load(OLD/(name+'.npz'),allow_pickle=False) as z:domain=z['remaining_center_cells'][np.arange(ny)[:,None]//2,np.arange(nx)[None,:]//2]
    assert domain.sum()==case['remaining_center_grid_cells']*4;counts=occupancy(region);upper=data['combined_area_upper_um2'];assert upper==case['first_companion_upper_um2'];required=case['minimum_required_first_companion_um2'];remaining=domain&(counts*h*h<=upper-required)
    with np.load(BASE/(name+'.npz'),allow_pickle=False) as z:
        for key,value in [('companion_inner_cells',region),('center_domain_cells',domain),('forced_occupied_cell_counts',counts),('remaining_center_cells',remaining)]:assert np.array_equal(z[key],value),(name,key)
    record={'case':name,'omitted_sites':case['omitted_sites'],'first_companion_upper_um2':upper,'minimum_required_first_companion_um2':required,'companion_inner_grid_cells':int(region.sum()),'necessary_center_grid_cells':int(domain.sum()),'pruned_center_grid_cells':int((domain&~remaining).sum()),'remaining_center_grid_cells':int(remaining.sum()),'minimum_forced_companion_overlap_um2':int(counts[domain].min())*h*h,'provisional_exact_first32_excluded':not bool(remaining.any())};assert saved[name]==record;results.append({**record,'exact_first32_excluded':not bool(remaining.any())})
process=load(ROOT/'output/h5-free-cog-fine-grid-process-20261108/process.json');assert process['passed'] and process['closed'];total=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_first32_excluded']]
write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':38,'full_arrays_verified':152,'source_disk_radius_mm':109,'continuous_child_cells_verified':sum(r['necessary_center_grid_cells'] for r in results),'center_cells_excluded':sum(r['pruned_center_grid_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_grid_cells'] for r in results),'additional_exact_first32_cases_excluded':38-len(remaining),'exact_first32_cases_remaining':len(remaining),'all_exact_rigid_source_angles_covered':True,'complete_preparation_seconds_if_consumed':total,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
