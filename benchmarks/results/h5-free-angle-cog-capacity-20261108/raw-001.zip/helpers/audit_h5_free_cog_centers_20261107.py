"""Independent direct-rectangle mask and exact continuous cover readback."""
from pathlib import Path
from hashlib import sha256
from bisect import bisect_left,bisect_right
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free-cog-centers-20261107';OUT=BASE/'audit';G=ROOT/'output/h5-free-cog-geometry-v2-20261107';M=ROOT/'output/h5-five-column-covers-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,G/'audit',M/'mask-audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'classes.npz',BASE/'center-cover.json',BASE/'cases.json',BASE/'checks.json']:
    bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconcile original-source disk/inner-square, source-contained fixed rectangles and all inherited bindings. Reconstruct the whole necessary center domain and forbidden rectangles independently. Directly OR each forbidden rectangle into the full point/interval mask (no producer prefix sums). Verify every class and exact-once closed cover, and independently select each of237 omitted-triple case covers. Retain nonempty necessary domains without claiming a valid pose; all exact rigid source cog angles are covered.'})
inner=load(G/'audit/universal-inner-square.json');assert inner['every_exact_rigid_source_angle_covered'] and inner['bounds_relative_to_center_um']==[-76000,-76000,76000,76000];stock=load(M/'stock-cover.json')['outward_stock_rectangle_um'];domain=[stock[0]+76000,stock[1]+76000,stock[2]-76000,stock[3]-76000];data=load(BASE/'center-cover.json');assert data['domain_um']==domain;sources=load(M/'turned-4/source-inner-rectangles.json');obstacles=[]
for i,r in enumerate(sources):
    l,b,u,v=r['bounds_um'];q=[l-76000,b-76000,u+76000,v+76000]
    if max(q[0],domain[0])<min(q[2],domain[2]) and max(q[1],domain[1])<min(q[3],domain[3]):obstacles.append({'source':i,'bit':r['site_bit'],'bounds_um':q})
assert obstacles==data['obstacles']
xs=sorted({domain[0],domain[2]}|{o['bounds_um'][k] for o in obstacles for k in [0,2] if domain[0]<=o['bounds_um'][k]<=domain[2]});ys=sorted({domain[1],domain[3]}|{o['bounds_um'][k] for o in obstacles for k in [1,3] if domain[1]<=o['bounds_um'][k]<=domain[3]})
def axis(cuts):
    out=[]
    for i in range(len(cuts)-1):out.extend([2*cuts[i],cuts[i]+cuts[i+1]])
    return out+[2*cuts[-1]]
xx,yy=axis(xs),axis(ys);mask=np.zeros((len(yy),len(xx)),dtype=np.uint32)
for o in obstacles:
    l,b,r,t=o['bounds_um'];xa,xb=bisect_right(xx,2*l),bisect_left(xx,2*r);ya,yb=bisect_right(yy,2*b),bisect_left(yy,2*t);mask[ya:yb,xa:xb]|=1<<o['bit']
with np.load(BASE/'classes.npz',allow_pickle=False) as z:assert z['xcuts_um'].tolist()==xs and z['ycuts_um'].tolist()==ys and np.array_equal(z['mask'],mask)
# Independent retained-label test by removing the first three bits.
rest=mask.copy()
for _ in range(3):rest&=rest-np.uint32(1)
legal=(rest==0)&((mask&(1<<17))==0);covered=np.zeros(mask.shape,dtype=bool)
for label,l,b,r,t,xa,ya,xb,yb in data['cover']:
    assert [l,b,r,t]==[xs[xa//2],ys[ya//2],xs[(xb+1)//2],ys[(yb+1)//2]] and np.all(mask[ya:yb+1,xa:xb+1]==label) and np.all(legal[ya:yb+1,xa:xb+1]) and not np.any(covered[ya:yb+1,xa:xb+1]);covered[ya:yb+1,xa:xb+1]=True
assert np.array_equal(covered,legal)
def valid(n):return not(n&(1<<17)) and len([i for i in range(17) if n&(1<<i)])<=3
assert valid(1<<16) and not valid(1<<17) and valid(7) and not valid(15)
assert (bisect_right([0,1,2,3,4],0),bisect_left([0,1,2,3,4],4))==(1,4)
expected={r['case']:r for r in load(G/'audit/remaining-first32-cases.json')};cases=load(BASE/'cases.json');assert {r['case'] for r in cases}==set(expected) and len(cases)==237;results=[]
for r in cases:
    omitted=set(r['omitted_sites']);assert r['omitted_sites']==expected[r['case']]['omitted_sites'];selected=[i for i,c in enumerate(data['cover']) if {j for j in range(18) if c[0]&(1<<j)}<=omitted];assert selected==r['center_cover_indices'];results.append({'case':r['case'],'omitted_sites':r['omitted_sites'],'center_cover_indices':selected,'necessary_center_domain_empty':not selected,'source_feasibility_claimed':False})
process=load(ROOT/'output/h5-free-cog-centers-process-20261107/process.json');assert process['passed'] and process['closed'];total=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source_inner_obstacles_verified':len(obstacles),'continuous_center_classes_verified':int(mask.size),'retained_center_classes_verified':int(legal.sum()),'closed_cover_boxes_verified':len(data['cover']),'first32_cases_verified':237,'empty_necessary_center_domains':sum(r['necessary_center_domain_empty'] for r in results),'nonempty_necessary_center_domains':sum(not r['necessary_center_domain_empty'] for r in results),'every_exact_rigid_source_angle_covered':True,'source_feasible_pose_claimed':False,'complete_preparation_seconds_if_consumed':total,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
