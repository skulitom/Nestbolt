"""Seal the original-source free-angle proofs and complete conditional frontier."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
process_names=['geometry-20261107','geometry-v2-20261107','geometry-audit-20261107','centers-20261107','centers-audit-20261107','area-grid-20261107','area-grid-audit-20261108','fine-grid-20261108','fine-grid-audit-20261108','disk-domain-20261108','disk-domain-audit-20261108','quarter-grid-20261108','quarter-grid-audit-20261108']
process_paths=[ROOT/'output'/('h5-free-cog-'+n.rsplit('-',1)[0]+'-process-'+n.rsplit('-',1)[1]) for n in process_names]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-free-angle-cog-capacity-20261108'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-free-cog-quarter-grid-20261108';F=BASE/'audit';D=ROOT/'output/h5-free-cog-geometry-v2-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-three-empty-cog-capacity-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['exact_first32_cases_remaining']==19 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-free-cog-geometry-20261107',ROOT/'output/h5-free-cog-centers-20261107',ROOT/'output/h5-free-cog-area-grid-20261107',ROOT/'output/h5-free-cog-fine-grid-20261108',ROOT/'output/h5-free-cog-disk-domain-20261108',ROOT/'output/h5-three-empty-main-sync-20261107']+process_paths",
"['*h5*mixed*mode*20261107.py']":"['*h5_free_cog*2026110[78].py','*h5_free_angle*20261108.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_free_angle_checkpoint_20261108.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
total=front['complete_preparation_seconds_if_consumed'];copies=[(D/'plan.json','geometry-plan.json'),(D/'geometry.json','source-cog-geometry.json'),(D/'audit/checks.json','geometry-audit.json'),(D/'audit/capacity-results.json','short-cog-capacities.json'),(D/'whole-part-splits.json','short-cog-inventories.json'),(ROOT/'output/h5-three-empty-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
stage_folders={'center-cover':ROOT/'output/h5-free-cog-centers-20261107','coarse-area':ROOT/'output/h5-free-cog-area-grid-20261107','fine-area':ROOT/'output/h5-free-cog-fine-grid-20261108','disk-domain':ROOT/'output/h5-free-cog-disk-domain-20261108','quarter-area':BASE}
for label,folder in stage_folders.items():
    assert load(folder/'audit/checks.json')['passed'];copies.extend([(folder/'plan.json',label+'-plan.json'),(folder/'audit/checks.json',label+'-audit.json'),(folder/'audit/case-results.json',label+'-cases.json')])
copies.append((F/'remaining-cases.json','remaining-first32-cases.json'))
process_table=[]
for name,folder in zip(process_names,process_paths):
    r=load(folder/'process.json');assert r['closed'] and r['job']['active_processes']==0
    if name=='geometry-20261107':assert not r['passed'] and r['job']['root_exit_code']==1
    else:assert r['passed']
    copies.append((folder/'process.json',name+'-process.json'));process_table.append({'stage':name,'seconds':r['complete_seconds'],'passed':r['passed'],'active_processes':0})
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'process-summary.json',process_table)
prior=load(PARENT/'fixed32-capacities.json');frontier={r['case']:{'case':r['case'],'omitted_sites':r['omitted_sites'],'exact_first32_excluded':r['exact_first32_excluded_even_last_cog_free'],'first_excluding_stage':'prior-inventory' if r['exact_first32_excluded_even_last_cog_free'] else None,'remaining_continuous_center_cells':None} for r in prior};assert len(frontier)==680 and sum(r['exact_first32_excluded'] for r in frontier.values())==443
counts={}
for label in ['coarse-area','fine-area','disk-domain','quarter-area']:
    rows=load(stage_folders[label]/'audit/case-results.json');unresolved={k for k,v in frontier.items() if not v['exact_first32_excluded']};assert {r['case'] for r in rows}==unresolved;count=0
    for r in rows:
        item=frontier[r['case']];assert item['omitted_sites']==r['omitted_sites']
        if r['exact_first32_excluded']:item['exact_first32_excluded']=True;item['first_excluding_stage']=label;count+=1
        item['remaining_continuous_center_cells']=r.get('remaining_center_cells',r.get('remaining_center_grid_cells'))
    counts[label]=count
assert counts=={'coarse-area':199,'fine-area':3,'disk-domain':11,'quarter-area':5};assert sum(r['exact_first32_excluded'] for r in frontier.values())==661
assert {k for k,v in frontier.items() if not v['exact_first32_excluded']}=={r['case'] for r in load(F/'remaining-cases.json')}
write(OUT/'fixed-core-frontier.json',list(frontier.values()))
runtime=load(PARENT/'runtime-bindings.json')
for n,h in runtime.items():assert n.startswith('.cache/') and digest(ROOT/n)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42413174617','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='cc38001e0dd53f2f7703023aefb2109123c43923' and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs']);write(OUT/'main-ci-at-review.json',ci)
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'all680_frontier_identities_reconciled':True,'prior_exact_first32_exclusions':443,'additional_exact_first32_exclusions':218,'total_exact_first32_exclusions':661,'exact_first32_cases_remaining':19,'preserved_failed_preparations_in_this_checkpoint':1,'failed_preparation_seconds_in_this_checkpoint':process_table[0]['seconds'],'inherited_failed_preparation_seconds_retained':6.62785069970414,'complete_preparation_seconds_if_consumed':total})
write(OUT/'next-step.json',{'status':'nineteen_exact_first32_cores_unexcluded','proposal':'Apply the already certified stock/frame/fixed-cog disk witnesses to the new2.5mm surviving cells, with exact source/pose equality checks and complete boundary coverage; these cells currently inherit only the coarser5mm disk pruning. Preserve all remaining cells. Inspect which source boundary or companion inventory controls each survivor before any finer area proof or angle-aware source silhouette cover. The current bounds cover every exact rigid source angle; survivors are not placements. A complete candidate still needs all original holes/identities, full source/native/material readback and then the full H5 matrix. This charged research lineage is already over60seconds and must not open an optimizer or reset its timer. Any eventual bounded constructor must recompute its numerical input independently from original sources and receive a new preflight; old model/optimizer calls remain closed.','remaining_first32_cases':19,'remaining_center_cells_2_5mm':25407,'last_source_cog_must_be_on_first':True,'numerical_candidate_geometry_predicates_required':True,'native_all_angle_libm_guarantee_claimed':False,'consumed_preparation_seconds':total,'optimizer_allowed_from_current_charged_lineage':False,'complete_model_prepared':False,'earlier_arrangements_remaining':4,'whole_allocation_candidates_remaining':440,'optimizer_calls':0,'H5_complete':False})
table='\n'.join('| '+r['stage']+' | '+f"{r['seconds']:.6f}"+' | '+('Pass' if r['passed'] else 'Failure preserved')+' |' for r in process_table)
report=f'''# Free-angle cog capacity: nineteen fixed cores remain — 2026-11-08

**Independent continuous geometry proofs exclude another 218 of the 237
unresolved exact first32 arrangements.** Together with the prior 443 exclusions,
**661 of the original 680 fixed cores are excluded; nineteen remain**. Their
last cog and all brackets/inserts were free to move. These are conditional
proofs for the eighteen fixed frames and fourteen fixed cogs, not exclusions of
whole allocations or orientation classes. H2/H5 stay open at **60% completed
milestone weight**; the valid 64-part result remains best.

[Original-source geometry]({NAME}/geometry-plan.json) establishes that every
rigid pose of the remaining cog has the same filled outer area. Exact rational
source vertices give **50,062.71893798297 mm²**. The symbolic shoelace polynomial
is source area times `c²+s²`; translation terms cancel and exact rotations have
`c²+s²=1`. [Independent triangle-fan, winding and segment checks]({NAME}/geometry-audit.json)
verify all eighty vertices, 3,080 nonadjacent edge pairs and a centered disk
contained in the cog for every angle.

The first disk helper used an overly restrictive infinite-edge-line condition
and stopped on an assertion. [Its complete 0.184916 s process]({NAME}/geometry-20261107-process.json)
and raw source are preserved. The corrected stage uses distance to the actual
segments; no result from the failed stage was treated as a certificate.

[The source certificate]({NAME}/source-cog-geometry.json) distinguishes exact
rigid geometry from native floating-point behavior. It also supplies explicit
determinant, coordinate and vertex-error predicates for future native candidates.
It does not claim an unproved all-angle `sin_cos` accuracy guarantee. No full
native layout is accepted by these research proofs.

A conservative **50,000 mm²** cog body leaves at most **415,326.048858 mm²** for
short-sheet companions, wherever that cog is placed or rotated. [All original
whole-part inventories]({NAME}/short-cog-inventories.json) still force at least
**495,777 mm²** of brackets/inserts onto the first sheet. [Every one of the 680
cores fails with the last source cog on the short sheet]({NAME}/short-cog-capacities.json).
Thus each previously unresolved completion requires that cog on the first sheet.

[The necessary center cover]({NAME}/center-cover-plan.json) uses a fixed-axis
152 mm square inside the universal cog disk, source-contained fixed obstacles,
and the physical stock. [Direct-mask readback]({NAME}/center-cover-audit.json)
verifies **817,047 continuous point/interval classes**, **521,391 retained
classes** and **463 closed cover boxes**. All 237 cases initially have nonempty
necessary center domains. No sampled angle or feasible-pose claim is involved.

[The first coupled-area proof]({NAME}/coarse-area-plan.json) covers each necessary
center with a continuous 10 mm cell. Any cog in that cell must occupy a common
set of companion-region cells inside its 108 mm disk. Their areas are subtracted
from the independently certified companion-area upper bound. Worst corner-pair
distances make the bound valid at every point in the center cell.

[Independent direct raster and integer shift sums]({NAME}/coarse-area-audit.json)
replay all **948 arrays**, separately from the producer convolution. They exclude
**217,298 of 245,909 center cells** and **199 fixed cores**, leaving 38. The
calculation had completed before the user pause; resume audited its saved output
without rerunning the preparation.

| Verified refinement | Input cores | Newly excluded | Remaining |
|---|---:|---:|---:|
| 10 mm continuous occupancy bound | 237 | 199 | 38 |
| 5 mm occupancy, 109 mm source disk | 38 | 3 | 35 |
| Stock/frame/fixed-cog disk witnesses | 35 | 11 | 24 |
| 2.5 mm continuous occupancy bound | 24 | 5 | 19 |

[The 5 mm refinement]({NAME}/fine-area-audit.json) checks all eighty rational
segment distances justify a **109 mm** disk, then subdivides only surviving
parent cells. Independent vertical-prefix sums replay the producer's horizontal
stripes and all 152 arrays. No excluded parent cell returns.

[Disk-domain witnesses]({NAME}/disk-domain-audit.json) independently check
**1,360 fixed-source segment distances**, seventeen conservative fixed-cog disks
and eighteen frame rectangles. Every rejected cell has a complete stock, frame
or cog witness. This removes 25,019 stock cells, 5,809 frame cells and 756 cog
cells, leaving 34,551 cells across twenty-four cores.

[The 2.5 mm refinement]({NAME}/quarter-area-audit.json) independently verifies
96 arrays and all **138,204 child cells**. It excludes 112,797 cells and five
more cores. [Nineteen cases and 25,407 necessary center cells remain]({NAME}/remaining-first32-cases.json).
They are not placements. [The full 680-case frontier]({NAME}/fixed-core-frontier.json)
reconciles every identity and its first excluding stage, without conflating
these cases with four earlier unresolved arrangements or 440 whole-job allocations.

| Bounded stage | Complete process (s) | Outcome |
|---|---:|---|
{table}

[All process receipts]({NAME}/process-summary.json) close with zero live children
under unchanged CCD1/thread and 2 GiB Windows Job controls. Complete consumed
preparation is **{total:.6f} s**, including the new failure and all inherited
failed work. This research lineage exceeds 60 seconds and may not open an
optimizer or reset its timer. It is not a timed H5 pass.

[Next]({NAME}/next-step.json), apply the existing disk-domain witnesses to the
new 2.5 mm cells, then inspect the controlling geometry and inventories of any
survivors. Preserve complete continuous coverage. Any future timed constructor
must recompute numerical input independently from original sources and pass a
new preflight. Full66 source/native/material acceptance, integration, parity and
the H5 matrix remain open.

[The prior three checkpoints reached main]({NAME}/prior-main-push-receipt.json)
and [all six checks on cc38001e pass]({NAME}/main-ci-at-review.json). This evidence
checkpoint awaits its ordinary fast-forward push. Product code, README and
releases remain unchanged.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-08 H5 free-angle cog capacity:** [independent source and continuous-cell proofs]({{link}}) prove a conservative 50,000 mm² source cog body at every rigid pose, excluding all 680 first32 cores when the last cog is on the short sheet. A source-disk center cover verifies 817,047 continuous classes and 463 boxes. Coupled occupied-area bounds exclude 199 further cores at 10 mm; a 109 mm disk and 5 mm refinement exclude three; complete stock/frame/cog witnesses exclude eleven; a 2.5 mm refinement excludes five. All arrays and witnesses replay independently. Together with the prior 443 exclusions, 661 of the 680 exact cores are excluded and nineteen remain with 25,407 necessary center cells. No survivor is a placement, and no whole allocation or orientation class is excluded. The failed infinite-line disk test and its 0.184916 s are preserved. Exact rigid source proofs are distinguished from native floating-point predicates; no all-angle libm guarantee or native acceptance is claimed. Consumed preparation is {total:.6f} s; no optimizer or timed-gate pass is allowed from this exhausted lineage. Next apply existing disk witnesses to the finer cells. Four earlier arrangements and 440 allocations remain, valid64 stays best, H2/H5 stay open at 60%. All six checks on main cc38001e pass; this checkpoint awaits its ordinary push. Product and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';content=p.read_text(encoding='utf-8');a=content.index('Latest H5 evidence:');b=content.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [free-angle cog capacity](../benchmarks/results/{NAME}.md).
Original-source area and disk proofs cover every rigid cog angle. They exclude
the last cog from the short sheet for all 680 exact first32 cores. Complete
continuous center covers, coupled occupancy bounds and disk witnesses exclude
another 218 of the prior 237 unresolved cores. A total of 661 are now excluded;
nineteen remain with 25,407 necessary 2.5 mm center cells, without a placement.
All source certificates, cell arrays and exclusions were independently checked.
The failed first disk helper and its runtime are preserved. Native floating-point
predicates remain separate from the exact source theorem. Consumed preparation
is {total:.6f} s: this lineage may not reset its timer or open an optimizer.
Next apply existing disk witnesses to the finer cells. Four earlier arrangements
and 440 whole-job allocations remain; valid64 stays best. H2/H5 remain open at
60%. All six checks on main cc38001e pass; this checkpoint awaits an ordinary push.
Product and releases are unchanged.
'''
content=content[:a]+intro+content[b:];assert content.startswith('# Status — 2026-11-07');content=content.replace('# Status — 2026-11-07','# Status — 2026-11-08',1);p.write_text(content,encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings),'consumed_preparation_seconds':total,'remaining_first32_cases':19})
