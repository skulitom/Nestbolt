"""Complete necessary centers for a source cog at every legal rigid angle."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-free-cog-centers-20261107';G=ROOT/'output/h5-free-cog-geometry-v2-20261107';M=ROOT/'output/h5-five-column-covers-v2-20261107';SOURCE=ROOT/'output/h5-three-empty-sources-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();assert load(G/'audit/checks.json')['passed'] and load(M/'mask-audit/checks.json')['passed'];inputs=[Path(__file__),G/'audit/checks.json',G/'audit/universal-inner-square.json',G/'audit/remaining-first32-cases.json',M/'mask-audit/checks.json',M/'stock-cover.json',M/'turned-4/source-inner-rectangles.json',SOURCE/'canonical-source.json',SOURCE/'cases.json',SOURCE/'audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'A source cog at any rigid angle contains a fixed world-axis152mm square around its transformed original center. Use its Minkowski sum with every independently certified fixed source inner rectangle to forbid center interiors. The full physical stock domain follows from that contained square. Build continuous point/interval masks with17anonymous cog bits and mandatory framebit17. Extract complete<=3empty-bit covers and case-specific covers for237unresolved first32 cores. This necessary cover ignores much of the cog and all clearances: surviving centers are not source-valid placements. No angle sampling, optimizer or timed-gate claim.','inherited_numeric_preparation_seconds':load(G/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
inner=load(G/'audit/universal-inner-square.json')['bounds_relative_to_center_um'];assert inner==[-76000,-76000,76000,76000];sb=load(M/'stock-cover.json')['outward_stock_rectangle_um'];d=[sb[0]-inner[0],sb[1]-inner[1],sb[2]-inner[2],sb[3]-inner[3]];sources=load(M/'turned-4/source-inner-rectangles.json');obs=[]
for i,r in enumerate(sources):
    a,b,c,e=r['bounds_um'];q=[a-inner[2],b-inner[3],c-inner[0],e-inner[1]]
    if q[0]<d[2] and q[2]>d[0] and q[1]<d[3] and q[3]>d[1]:obs.append({'source':i,'bit':r['site_bit'],'bounds_um':q})
xs=sorted({d[0],d[2]}|{r['bounds_um'][k] for r in obs for k in [0,2] if d[0]<=r['bounds_um'][k]<=d[2]});ys=sorted({d[1],d[3]}|{r['bounds_um'][k] for r in obs for k in [1,3] if d[1]<=r['bounds_um'][k]<=d[3]})
def axis(v):return np.array([x for i,a in enumerate(v) for x in ([2*a,a+v[i+1]] if i+1<len(v) else [2*a])],dtype=np.int64)
xx,yy=axis(xs),axis(ys);mask=np.zeros((len(yy),len(xx)),dtype=np.uint32)
for bit in range(18):
    diff=np.zeros((len(yy)+1,len(xx)+1),dtype=np.int32)
    for o in obs:
        if o['bit']!=bit:continue
        a,b,c,e=o['bounds_um'];i,j=np.searchsorted(xx,2*a,side='right'),np.searchsorted(xx,2*c,side='left');k,l=np.searchsorted(yy,2*b,side='right'),np.searchsorted(yy,2*e,side='left');diff[k,i]+=1;diff[l,i]-=1;diff[k,j]-=1;diff[l,j]+=1
    values=diff.cumsum(0,dtype=np.int32).cumsum(1,dtype=np.int32)[:-1,:-1];assert values.min()>=0;mask|=(values>0).astype(np.uint32)<<bit
lookup=np.array([not(z&(1<<17)) and z.bit_count()<=3 for z in range(1<<18)],dtype=np.bool_);legal=lookup[mask];sentinel=1<<18;labels=np.where(legal,mask,sentinel);active={};covers=[]
for y,row in enumerate(labels):
    breaks=np.flatnonzero(np.r_[True,row[1:]!=row[:-1],True]);now={}
    for a,b in zip(breaks,breaks[1:]):
        label=int(row[a]);a=int(a);b=int(b)-1
        if label==sentinel:continue
        key=(label,a,b);start=active.pop(key,y);now[key]=start
    for (label,a,b),start in active.items():covers.append([label,xs[a//2],ys[start//2],xs[(b+1)//2],ys[y//2],a,start,b,y-1])
    active=now
for (label,a,b),start in active.items():covers.append([label,xs[a//2],ys[start//2],xs[(b+1)//2],ys[-1],a,start,b,len(yy)-1])
np.savez_compressed(OUT/'classes.npz',xcuts_um=np.array(xs,dtype=np.int64),ycuts_um=np.array(ys,dtype=np.int64),mask=mask)
write(OUT/'center-cover.json',{'domain_um':d,'inner_square_um':inner,'obstacles':obs,'cover':covers,'closed_outer_boxes_are_necessary_only':True});cases=[]
for r in load(G/'audit/remaining-first32-cases.json'):
    allowed=sum(1<<i for i in r['omitted_sites']);selected=[i for i,c in enumerate(covers) if not c[0]&~allowed];cases.append({'case':r['case'],'omitted_sites':r['omitted_sites'],'center_cover_indices':selected,'provisional_center_domain_empty':not selected})
write(OUT/'cases.json',cases);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'continuous_center_classes':int(mask.size),'retained_center_classes':int(legal.sum()),'cover_boxes':len(covers),'source_inner_obstacles':len(obs),'source_angle_unrestricted':True,'first32_cases':len(cases),'provisional_empty_center_domains':sum(r['provisional_center_domain_empty'] for r in cases),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
