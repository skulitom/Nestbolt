"""Necessary disk stock/frame/cog geometry on all surviving continuous cells."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-free-cog-disk-domain-20261108';FINE=ROOT/'output/h5-free-cog-fine-grid-20261108';G=ROOT/'output/h5-free-cog-geometry-v2-20261107';SOURCE=ROOT/'output/h5-three-empty-sources-20261107';M=ROOT/'output/h5-five-column-covers-v2-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(FINE/'audit/remaining-cases.json');assert len(cases)==35;inputs=[Path(__file__),FINE/'audit/checks.json',FINE/'audit/remaining-cases.json',G/'geometry.json',G/'audit/checks.json',SOURCE/'canonical-source.json',SOURCE/'audit/checks.json',M/'stock-cover.json',M/'turned-4/source-inner-rectangles.json',M/'mask-audit/checks.json',JOB]+[FINE/(r['case']+'.npz') for r in cases]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'The109mm source disk forces its center at least109mm inside the outward stock. Reconcile every fixed site pose and certify a108.99mm fixed-cog disk with exact source segment distances and the actual fixed matrix determinant. Enclose each transformed center outward to a1micrometre interval. A surviving5mm cell is impossible if even its farthest corner from an entire center interval is within217.99mm, or if every corner is within109mm of a mandatory frame inner rectangle. Clip cells to the necessary stock-center rectangle before these tests. All tests exclude entire continuous cells, with no chosen angle or source-feasibility claim.','inherited_numeric_preparation_seconds':load(FINE/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':20,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
geo=load(G/'geometry.json');center=list(map(Q,geo['source_center']));mind=min(Q(r['segment_distance_squared']) for r in geo['source_disk_edge_certificates']);canonical=load(SOURCE/'canonical-source.json');fixed=[]
for pose in canonical['first_cog_site_poses']:
    t=pose['transform'];assert not t['mirrored'];c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));det=c*c+s*s;xy=[center[0]*c-center[1]*s+Q(t['translation'][0]),center[0]*s+center[1]*c+Q(t['translation'][1])];assert mind*det>Q(108991,1000)**2
    box=[math.floor(v*1000) for v in xy]+[math.ceil(v*1000) for v in xy];fixed.append({'site':pose['site'],'center_interval_um':box,'matrix_determinant':str(det),'source_segment_distance_squared_min':str(mind*det),'certified_fixed_disk_radius_um':108990})
assert len(fixed)==17;sb=load(M/'stock-cover.json')['outward_stock_rectangle_um'];r=109000;domain=[sb[0]+r,sb[1]+r,sb[2]-r,sb[3]-r];frames=[r['bounds_um'] for r in load(M/'turned-4/source-inner-rectangles.json') if r['site_bit']==17];assert len(frames)==18;write(OUT/'geometry.json',{'moving_disk_radius_um':r,'fixed_disk_radius_um':108990,'stock_center_domain_um':domain,'fixed_cog_disks':fixed,'frame_inner_rectangles_um':frames,'cell_step_um':5000});results=[]
for case in cases:
    name=case['case']
    with np.load(FINE/(name+'.npz'),allow_pickle=False) as z:old=z['remaining_center_cells'];yy,xx=np.nonzero(old)
    x0=xx*5000;y0=yy*5000;x1=x0+5000;y1=y0+5000;stock=(x1>domain[0])&(y1>domain[1])&(x0<=domain[2])&(y0<=domain[3]);l=np.maximum(x0,domain[0]);b=np.maximum(y0,domain[1]);u=np.minimum(x1,domain[2]);v=np.minimum(y1,domain[3]);reasons=np.where(stock,0,1).astype(np.uint8);witness=np.full(len(xx),-1,dtype=np.int16)
    for i,(a,c,d,e) in enumerate(frames):
        dx=np.maximum(0,np.maximum(a-l,u-d));dy=np.maximum(0,np.maximum(c-b,v-e));bad=stock&(reasons==0)&(dx*dx+dy*dy<r*r);reasons[bad]=2;witness[bad]=i
    for disk in fixed:
        site=disk['site']
        if site in case['omitted_sites']:continue
        a,c,d,e=disk['center_interval_um'];dx=np.maximum(np.abs(l-d),np.abs(u-a));dy=np.maximum(np.abs(b-e),np.abs(v-c));bad=stock&(reasons==0)&(dx*dx+dy*dy<(r+108990)**2);reasons[bad]=3;witness[bad]=site
    remaining=old.copy();remaining[yy,xx]=reasons==0;np.savez_compressed(OUT/(name+'.npz'),source_y=yy,source_x=xx,reason=reasons,witness=witness,remaining_center_cells=remaining)
    results.append({'case':name,'omitted_sites':case['omitted_sites'],'input_center_cells':len(xx),'stock_excluded_cells':int((reasons==1).sum()),'frame_excluded_cells':int((reasons==2).sum()),'fixed_cog_excluded_cells':int((reasons==3).sum()),'remaining_center_cells':int(remaining.sum()),'provisional_exact_first32_excluded':not bool(remaining.any())})
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':35,'input_center_cells':sum(r['input_center_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
