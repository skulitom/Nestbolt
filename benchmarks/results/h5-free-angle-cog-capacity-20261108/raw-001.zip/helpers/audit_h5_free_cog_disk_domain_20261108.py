"""Independent corner witnesses for complete source-disk domain exclusions."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free-cog-disk-domain-20261108';OUT=BASE/'audit';FINE=ROOT/'output/h5-free-cog-fine-grid-20261108';SOURCE=ROOT/'output/h5-three-empty-sources-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';G=ROOT/'output/h5-free-cog-geometry-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,FINE/'audit',G/'audit',SOURCE/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'geometry.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconstruct all17 fixed cog outlines with rational actual pose coefficients and independently check center-to-segment distances and outward center intervals. Reconcile all18 source-certified frame rectangles and necessary disk stock limits. For every excluded cell, verify its recorded stock, frame or mandatory-cog witness using all4 clipped-cell corners and all4 uncertain-center corners. Convex squared distance ensures these maxima bound the entire continuous cell. Replay complete source cell identity and remaining masks. Missing exclusions remain conservative; no survivor is claimed feasible.'})
geometry=load(BASE/'geometry.json');source=load(SOURCE/'canonical-source.json');geo=load(G/'geometry.json');center=list(map(Q,geo['source_center']));part=next(p for p in load(JOB)['parts'] if p['id']=='cog');poly=[tuple(map(Q,p)) for p in part['geometry'][0]['outer']];assert geometry['moving_disk_radius_um']==109000 and geometry['fixed_disk_radius_um']==108990;disks={r['site']:r for r in geometry['fixed_cog_disks']};assert set(disks)==set(range(17));edgechecks=0
for pose in source['first_cog_site_poses']:
    t=pose['transform'];c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));tx,ty=map(Q,t['translation']);actual=(center[0]*c-center[1]*s+tx,center[0]*s+center[1]*c+ty);points=[(x*c-y*s+tx,x*s+y*c+ty) for x,y in poly];row=disks[pose['site']];bb=row['center_interval_um'];assert Q(bb[0],1000)<=actual[0]<=Q(bb[2],1000) and Q(bb[1],1000)<=actual[1]<=Q(bb[3],1000) and bb[2]-bb[0]<=1 and bb[3]-bb[1]<=1
    for a,b in zip(points,points[1:]+points[:1]):
        e=[b[k]-a[k] for k in range(2)];v=[actual[k]-a[k] for k in range(2)];norm=sum(z*z for z in e);q=sum(v[k]*e[k] for k in range(2));u=min(Q(1),max(Q(0),q/norm));d=sum((v[k]-u*e[k])**2 for k in range(2));assert d>Q(108991,1000)**2;edgechecks+=1
    assert c*c+s*s==Q(row['matrix_determinant'])>0
M=ROOT/'output/h5-five-column-covers-v2-20261107';frames=[r['bounds_um'] for r in load(M/'turned-4/source-inner-rectangles.json') if r['site_bit']==17];assert frames==geometry['frame_inner_rectangles_um'];sb=load(M/'stock-cover.json')['outward_stock_rectangle_um'];domain=[sb[0]+109000,sb[1]+109000,sb[2]-109000,sb[3]-109000];assert domain==geometry['stock_center_domain_um'];cases=load(FINE/'audit/remaining-cases.json');saved={r['case']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==35;results=[]
for case in cases:
    name=case['case']
    with np.load(FINE/(name+'.npz'),allow_pickle=False) as z:old=z['remaining_center_cells'];ys,xs=np.nonzero(old)
    with np.load(BASE/(name+'.npz'),allow_pickle=False) as z:
        assert np.array_equal(z['source_y'],ys) and np.array_equal(z['source_x'],xs);reason=z['reason'];witness=z['witness'];remaining=z['remaining_center_cells'];assert set(np.unique(reason))<={0,1,2,3}
        x0=xs*5000;y0=ys*5000;x1=x0+5000;y1=y0+5000;stock=(x1>domain[0])&(y1>domain[1])&(x0<=domain[2])&(y0<=domain[3]);assert np.array_equal(reason==1,~stock)
        l=np.maximum(x0,domain[0]);r=np.minimum(x1,domain[2]);b=np.maximum(y0,domain[1]);t=np.minimum(y1,domain[3]);corners=[(x,y) for x in [l,r] for y in [b,t]]
        for index in np.unique(witness[reason==2]):
            chosen=(reason==2)&(witness==index);a,c,d,e=frames[int(index)];worst=np.zeros(int(chosen.sum()),dtype=np.int64)
            for x,y in corners:
                xx=x[chosen];yy=y[chosen];dx=xx-np.clip(xx,a,d);dy=yy-np.clip(yy,c,e);worst=np.maximum(worst,dx*dx+dy*dy)
            assert np.all(worst<109000**2)
        for site in np.unique(witness[reason==3]):
            assert int(site) not in case['omitted_sites'];chosen=(reason==3)&(witness==site);a,c,d,e=disks[int(site)]['center_interval_um'];worst=np.zeros(int(chosen.sum()),dtype=np.int64)
            for x,y in corners:
                for cx,cy in product([a,d],[c,e]):worst=np.maximum(worst,(x[chosen]-cx)**2+(y[chosen]-cy)**2)
            assert np.all(worst<217990**2)
        expected=old.copy();expected[ys,xs]=reason==0;assert np.array_equal(remaining,expected)
    record={'case':name,'omitted_sites':case['omitted_sites'],'input_center_cells':len(xs),'stock_excluded_cells':int((reason==1).sum()),'frame_excluded_cells':int((reason==2).sum()),'fixed_cog_excluded_cells':int((reason==3).sum()),'remaining_center_cells':int(remaining.sum()),'provisional_exact_first32_excluded':not bool(remaining.any())};assert saved[name]==record;results.append({**record,'exact_first32_excluded':not bool(remaining.any())})
process=load(ROOT/'output/h5-free-cog-disk-domain-process-20261108/process.json');assert process['passed'] and process['closed'];total=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];survivors=[r for r in results if not r['exact_first32_excluded']]
write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',survivors);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':35,'fixed_source_disk_segment_checks':edgechecks,'fixed_cog_disks_verified':17,'frame_source_rectangles_verified':18,'continuous_center_cells_verified':sum(r['input_center_cells'] for r in results),'stock_cells_excluded':sum(r['stock_excluded_cells'] for r in results),'frame_cells_excluded':sum(r['frame_excluded_cells'] for r in results),'fixed_cog_cells_excluded':sum(r['fixed_cog_excluded_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'additional_exact_first32_cases_excluded':35-len(survivors),'exact_first32_cases_remaining':len(survivors),'all_exact_rigid_source_angles_covered':True,'complete_preparation_seconds_if_consumed':total,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
