"""Independent certificate of the 2.5 mm continuous-cell refinement."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];TEMPLATE=ROOT/'output/audit_h5_free_cog_fine_grid_20261108.py'
src=TEMPLATE.read_text(encoding='utf-8')
changes={
"BASE=ROOT/'output/h5-free-cog-fine-grid-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-free-cog-area-grid-20261107'":"BASE=ROOT/'output/h5-free-cog-quarter-grid-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-free-cog-disk-domain-20261108'",
"for p in [Path(__file__),BASE/":"for p in [Path(__file__),TEMPLATE,ROOT/'output/h5-free-cog-fine-grid-20261108/audit/case-results.json',BASE/",
"each five-millimetre cell into its unique audited ten-millimetre parent":"each2.5mm cell into its unique audited5mm disk-domain parent",
"Reconcile all152 full arrays":"Reconcile all96 full arrays",
"h=5000;ny,nx=600,300":"h=2500;ny,nx=1200,600",
"range(-21,22)":"range(-43,44)",
"(23*h)**2":"(45*h)**2",
"assert len(cases)==len(saved)==38;results=[]":"assert len(cases)==len(saved)==24;parent_cases={r['case']:r for r in load(ROOT/'output/h5-free-cog-fine-grid-20261108/audit/case-results.json')};results=[]",
"name=case['case'];data=":"name=case['case'];bounds=parent_cases[name];data=",
"case['remaining_center_grid_cells']":"case['remaining_center_cells']",
"upper==case['first_companion_upper_um2'];required=case['minimum_required_first_companion_um2']":"upper==bounds['first_companion_upper_um2'];required=bounds['minimum_required_first_companion_um2']",
"output/h5-free-cog-fine-grid-process-20261108/process.json":"output/h5-free-cog-quarter-grid-process-20261108/process.json",
"'cases_verified':38,'full_arrays_verified':152":"'cases_verified':24,'full_arrays_verified':96",
"'additional_exact_first32_cases_excluded':38-len(remaining)":"'additional_exact_first32_cases_excluded':24-len(remaining)",
}
for a,b in changes.items():assert a in src,a;src=src.replace(a,b)
exec(compile(src,str(Path(__file__)),'exec'))
