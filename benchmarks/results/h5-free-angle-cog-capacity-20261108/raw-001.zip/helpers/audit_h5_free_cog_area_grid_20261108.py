"""Independent continuous cell-occupancy and companion-capacity certificate."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free-cog-area-grid-20261107';OUT=BASE/'audit';CENTER=ROOT/'output/h5-free-cog-centers-20261107';AREA=ROOT/'output/h5-three-empty-areas-20261107';INV=ROOT/'output/h5-three-empty-inventory-20261107';G=ROOT/'output/h5-free-cog-geometry-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,CENTER/'audit',AREA/'audit',G/'audit',INV]:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'kernel.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):
    bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently reconstruct inner companion cells by direct rectangle containment, and fixed-interior subtraction by positive rectangle intersection, without producer difference grids. Center cells use a half-open partition and closed cover intersection; the closure is used for all occupancy bounds. Derive every kernel entry by all16 corner pairs of the center and target cells, then independently sum shifted arrays (no convolution library). Recheck each237 source-bound case and every original companion split. All excluded center cells fail a continuous necessary bound at every real point and every exact rigid cog angle, not merely sampled grid centers. Preserve every surviving cell and case. This is source-geometry research, not a timed/native H5 pass.','process_cap_seconds':60,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
h=10000;ny,nx=300,150;radius=108000;oldkernel=load(BASE/'kernel.json');assert oldkernel['step_um']==h and oldkernel['radius_um']==radius and oldkernel['offset']==10
assert load(G/'audit/checks.json')['universal_source_disk_radius_mm']==108
left=np.arange(nx,dtype=np.int64)*h;bottom=np.arange(ny,dtype=np.int64)*h;right=left+h;top=bottom+h
def raster(rects,kind):
    cells=np.zeros((ny,nx),dtype=bool)
    for l,b,r,t in rects:
        if kind=='inner':xx=(left>=l)&(right<=r);yy=(bottom>=b)&(top<=t)
        elif kind=='obstacle':xx=(right>l)&(left<r);yy=(top>b)&(bottom<t)
        else:xx=(right>l)&(left<=r);yy=(top>b)&(bottom<=t)
        cells|=yy[:,None]&xx[None,:]
    return cells
kernel=[];offsets=[];corners=list(product([0,h],repeat=2))
for dy in range(-10,11):
    row=[]
    for dx in range(-10,11):
        distance=max((a-dx*h-c)**2+(b-dy*h-d)**2 for a,b in corners for c,d in corners);inside=distance<=radius**2;row.append(int(inside))
        if inside:offsets.append((dy,dx))
    kernel.append(row)
assert kernel==oldkernel['kernel'] and len(offsets)==oldkernel['covered_target_cells']
assert (12*h)**2>radius**2 # No offset outside the enumerated square can qualify.
assert not any(kernel[0]+kernel[-1]) and all(not row[0] and not row[-1] for row in kernel)
def occupancy(region):
    out=np.zeros((ny,nx),dtype=np.int64)
    for dy,dx in offsets:
        out[max(0,-dy):min(ny,ny-dy),max(0,-dx):min(nx,nx-dx)]+=region[max(0,dy):min(ny,ny+dy),max(0,dx):min(nx,nx+dx)]
    return out
# Boundary/negative controls: one corner cell cannot wrap to the opposite edge.
fixture=np.zeros((ny,nx),dtype=bool);fixture[0,0]=True;control=occupancy(fixture);assert control[-1,-1]==0 and control[0,0]==1 and control.max()==1
assert not raster([[h,h,2*h,2*h]],'inner')[0,0] and raster([[h,h,2*h,2*h]],'inner')[1,1]
assert not raster([[h,h,2*h,2*h]],'obstacle')[0,0]
assert raster([[h,h,h,h]],'center')[1,1] and not raster([[h,h,h,h]],'center')[1,0]
cases=load(CENTER/'audit/case-results.json');saved={r['case']:r for r in load(BASE/'case-results.json')};inv={r['case']:r for r in load(INV/'capacity-results.json')};cover=load(CENTER/'center-cover.json')['cover'];assert len(cases)==len(saved)==237;results=[]
for case in cases:
    name=case['case'];data=load(AREA/(name+'-capacity.json'));region=raster(data['combined_regions_um'],'inner')&~raster(data['fixed_inner_obstacles_um'],'obstacle');domain=raster([cover[i][1:5] for i in case['center_cover_indices']],'center');assert domain.any();counts=occupancy(region)
    splits=inv[name]['relaxed_free_cog_remaining_splits'];required=min((12-b)*39999+(21-i)*19799 for b,i in splits)*10**6;upper=data['combined_area_upper_um2'];remaining=domain&(counts*h*h<=upper-required)
    with np.load(BASE/(name+'.npz'),allow_pickle=False) as z:
        assert set(z.files)=={'companion_inner_cells','center_domain_cells','forced_occupied_cell_counts','remaining_center_cells'}
        for key,value in [('companion_inner_cells',region),('center_domain_cells',domain),('forced_occupied_cell_counts',counts),('remaining_center_cells',remaining)]:assert np.array_equal(z[key],value),(name,key)
    expected={'case':name,'omitted_sites':case['omitted_sites'],'first_companion_upper_um2':upper,'minimum_required_first_companion_um2':required,'companion_inner_grid_cells':int(region.sum()),'necessary_center_grid_cells':int(domain.sum()),'pruned_center_grid_cells':int((domain&~remaining).sum()),'remaining_center_grid_cells':int(remaining.sum()),'minimum_forced_companion_overlap_um2':int(counts[domain].min())*h*h,'provisional_exact_first32_excluded':not bool(remaining.any())};assert saved[name]==expected
    results.append({**expected,'exact_first32_excluded':expected['provisional_exact_first32_excluded'],'continuous_all_source_angles_checked':True,'native_layout_pass_claimed':False})
process=load(ROOT/'output/h5-free-cog-area-grid-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];survivors=[r for r in results if not r['exact_first32_excluded']]
write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',survivors)
write(OUT/'controls.json',{'direct_rectangle_boundary_controls':True,'all16_corner_pair_distance_controls':True,'zero_padding_no_wraparound':True,'grid_centers_not_used_as_samples':True,'original_quantities_and_inventory_bounds_preserved':True,'integer_shift_sum_independent_of_producer_convolution':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':237,'full_cell_arrays_verified':237*4,'continuous_center_cells_verified':sum(r['necessary_center_grid_cells'] for r in results),'center_cells_excluded':sum(r['pruned_center_grid_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_grid_cells'] for r in results),'exact_first32_cases_excluded':len(results)-len(survivors),'exact_first32_cases_remaining':len(survivors),'universal_compulsory_disk_radius_mm':108,'kernel_target_cells':len(offsets),'every_continuous_center_and_rigid_source_angle_covered':True,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
