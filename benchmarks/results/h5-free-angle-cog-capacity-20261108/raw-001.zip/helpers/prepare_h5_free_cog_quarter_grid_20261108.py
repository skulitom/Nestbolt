"""Refine the audited disk-domain survivors to 2.5 mm continuous cells."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];TEMPLATE=ROOT/'output/prepare_h5_free_cog_fine_grid_20261108.py'
src=TEMPLATE.read_text(encoding='utf-8')
changes={
"OUT=ROOT/'output/h5-free-cog-fine-grid-20261108';OLD=ROOT/'output/h5-free-cog-area-grid-20261107'":"OUT=ROOT/'output/h5-free-cog-quarter-grid-20261108';OLD=ROOT/'output/h5-free-cog-disk-domain-20261108'",
"assert len(cases)==38":"assert len(cases)==24",
"inputs=[Path(__file__),OLD/":"inputs=[Path(__file__),TEMPLATE,ROOT/'output/h5-free-cog-fine-grid-20261108/audit/case-results.json',OLD/",
"Subdivide each surviving10mm center cell into four5mm half-open child cells":"Subdivide each surviving5mm disk-domain center cell into four2.5mm half-open child cells",
"Rebuild conservative inner companion cells at5mm":"Rebuild conservative inner companion cells at2.5mm",
"'grid_step_um':5000":"'grid_step_um':2500",
"h=5000;ny,nx=600,300":"h=2500;ny,nx=1200,600",
"results=[]\nfor case in cases:":"parent_cases={r['case']:r for r in load(ROOT/'output/h5-free-cog-fine-grid-20261108/audit/case-results.json')};results=[]\nfor case in cases:",
"name=case['case'];data=":"name=case['case'];bounds=parent_cases[name];data=",
"case['remaining_center_grid_cells']":"case['remaining_center_cells']",
"upper=case['first_companion_upper_um2'];required=case['minimum_required_first_companion_um2']":"upper=bounds['first_companion_upper_um2'];required=bounds['minimum_required_first_companion_um2']",
"'cases':38":"'cases':24",
}
for a,b in changes.items():assert a in src,a;src=src.replace(a,b)
exec(compile(src,str(Path(__file__)),'exec'))
