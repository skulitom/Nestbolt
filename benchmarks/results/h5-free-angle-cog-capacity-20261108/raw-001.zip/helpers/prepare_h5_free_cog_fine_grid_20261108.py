"""Refine only the 38 surviving continuous domains with five-millimetre cells."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from math import isqrt
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-free-cog-fine-grid-20261108';OLD=ROOT/'output/h5-free-cog-area-grid-20261107';AREA=ROOT/'output/h5-three-empty-areas-20261107';G=ROOT/'output/h5-free-cog-geometry-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/remaining-cases.json');assert len(cases)==38 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),OLD/'audit/checks.json',OLD/'audit/remaining-cases.json',G/'geometry.json',G/'audit/checks.json']+[p for r in cases for p in [OLD/(r['case']+'.npz'),AREA/(r['case']+'-capacity.json')]]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Use the already certified source topology and exact segment distances to strengthen the universal disk from108to109mm, checking every edge rationally. Subdivide each surviving10mm center cell into four5mm half-open child cells; no excluded coarse cell returns. Rebuild conservative inner companion cells at5mm and use exact integer horizontal row-prefix sums for the compulsory disk occupancy kernel. Every child cell bounds all continuous centers and all exact rigid source angles. Keep the original independently audited companion-area upper and integer-inventory lower bounds. This refines necessary geometry, never resumes a model or opens an optimizer.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':40,'memory_bytes':2**31,'grid_step_um':5000,'source_disk_radius_um':109000,'optimizer_calls':0,'retry_permitted':False})
geo=load(G/'geometry.json');assert all(Q(r['segment_distance_squared'])>109**2 for r in geo['source_disk_edge_certificates']) and load(G/'audit/checks.json')['source_winding_number']==1
h=5000;ny,nx=600,300;radius=109000;limit=radius//h;stripes=[]
for dy in range(-limit,limit+1):
    q=radius*radius-h*h*(abs(dy)+1)**2
    if q>=0:
        dxmax=isqrt(q)//h-1
        if dxmax>=0:stripes.append([dy,dxmax])
def cells(rects,kind):
    diff=np.zeros((ny+1,nx+1),dtype=np.int32)
    for l,b,r,t in rects:
        if kind=='inner':xa,ya,xb,yb=-((-l)//h),-((-b)//h),r//h,t//h
        else:xa,ya,xb,yb=l//h,b//h,-((-r)//h),-((-t)//h)
        xa,xb=max(0,min(nx,xa)),max(0,min(nx,xb));ya,yb=max(0,min(ny,ya)),max(0,min(ny,yb))
        if xa<xb and ya<yb:diff[ya,xa]+=1;diff[yb,xa]-=1;diff[ya,xb]-=1;diff[yb,xb]+=1
    return diff.cumsum(0,dtype=np.int32).cumsum(1,dtype=np.int32)[:-1,:-1]>0
def occupied(region):
    prefix=np.pad(np.cumsum(region,axis=1,dtype=np.int32),((0,0),(1,0)));out=np.zeros((ny,nx),dtype=np.int32);x=np.arange(nx)
    for dy,w in stripes:
        sums=prefix[:,np.minimum(nx,x+w+1)]-prefix[:,np.maximum(0,x-w)];out[max(0,-dy):min(ny,ny-dy)]+=sums[max(0,dy):min(ny,ny+dy)]
    return out
results=[]
for case in cases:
    name=case['case'];data=load(AREA/(name+'-capacity.json'));region=cells(data['combined_regions_um'],'inner')&~cells(data['fixed_inner_obstacles_um'],'obstacle')
    with np.load(OLD/(name+'.npz'),allow_pickle=False) as z:domain=np.repeat(np.repeat(z['remaining_center_cells'],2,axis=0),2,axis=1)
    assert int(domain.sum())==case['remaining_center_grid_cells']*4;counts=occupied(region);upper=case['first_companion_upper_um2'];required=case['minimum_required_first_companion_um2'];remaining=domain&(counts.astype(np.int64)*h*h<=upper-required);np.savez_compressed(OUT/(name+'.npz'),companion_inner_cells=region,center_domain_cells=domain,forced_occupied_cell_counts=counts,remaining_center_cells=remaining)
    results.append({'case':name,'omitted_sites':case['omitted_sites'],'first_companion_upper_um2':upper,'minimum_required_first_companion_um2':required,'companion_inner_grid_cells':int(region.sum()),'necessary_center_grid_cells':int(domain.sum()),'pruned_center_grid_cells':int((domain&~remaining).sum()),'remaining_center_grid_cells':int(remaining.sum()),'minimum_forced_companion_overlap_um2':int(counts[domain].min())*h*h,'provisional_exact_first32_excluded':not bool(remaining.any())})
write(OUT/'kernel-stripes.json',{'grid_step_um':h,'radius_um':radius,'horizontal_stripes':stripes,'covered_target_cells':sum(2*w+1 for _,w in stripes),'source_disk_edges_verified':80});write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':38,'continuous_child_cells':sum(r['necessary_center_grid_cells'] for r in results),'pruned_center_cells':sum(r['pruned_center_grid_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
