"""Conservative continuous center-cell pruning by compulsory cog occupancy."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
from scipy.signal import convolve2d
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-free-cog-area-grid-20261107';CENTER=ROOT/'output/h5-free-cog-centers-20261107';AREA=ROOT/'output/h5-three-empty-areas-20261107';INV=ROOT/'output/h5-three-empty-inventory-20261107';G=ROOT/'output/h5-free-cog-geometry-v2-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(CENTER/'audit/case-results.json');inputs=[Path(__file__),CENTER/'audit/checks.json',CENTER/'audit/case-results.json',CENTER/'center-cover.json',AREA/'audit/checks.json',INV/'capacity-results.json',G/'audit/checks.json']+[AREA/(r['case']+'-capacity.json') for r in cases];assert load(CENTER/'audit/checks.json')['passed']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Cover every necessary continuous cog center with closed10mm grid cells. Build a conservative inner subset of the previously certified companion occupied region: cells wholly inside at least one component envelope and touching no mandatory fixed inner rectangle. Every possible cog center in a cell covers a common set of companion grid cells: worst corner-to-corner squared distance is h*h*((abs(dx)+1)^2+(abs(dy)+1)^2), bounded by the all-angle108mm source disk. Exact integer convolution counts compulsory occupied area. Subtract only this lower bound from the independently proved companion-area upper bound. Retain every center cell that could meet any previously surviving whole-part inventory. This is a continuum necessary bound, not a discrete placement search or feasible-layout claim.','inherited_numeric_preparation_seconds':load(CENTER/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':40,'memory_bytes':2**31,'grid_step_um':10000,'stock_grid_shape':[300,150],'source_disk_radius_um':108000,'optimizer_calls':0,'retry_permitted':False})
h=10000;ny,nx=300,150;rad=108000;offset=10;kernel=np.array([[h*h*((abs(x)+1)**2+(abs(y)+1)**2)<=rad*rad for x in range(-offset,offset+1)] for y in range(-offset,offset+1)],dtype=np.int64);assert kernel.sum()>0
def cells(rects,kind):
    diff=np.zeros((ny+1,nx+1),dtype=np.int32)
    for l,b,r,t in rects:
        if kind=='inner':xa,ya,xb,yb=-((-l)//h),-((-b)//h),r//h,t//h
        elif kind=='obstacle':xa,ya,xb,yb=l//h,b//h,-((-r)//h),-((-t)//h)
        else:xa,ya,xb,yb=l//h,b//h,r//h+1,t//h+1
        xa,xb=max(0,min(nx,xa)),max(0,min(nx,xb));ya,yb=max(0,min(ny,ya)),max(0,min(ny,yb))
        if xa<xb and ya<yb:diff[ya,xa]+=1;diff[yb,xa]-=1;diff[ya,xb]-=1;diff[yb,xb]+=1
    return diff.cumsum(0,dtype=np.int32).cumsum(1,dtype=np.int32)[:-1,:-1]>0
inv={r['case']:r for r in load(INV/'capacity-results.json')};cover=load(CENTER/'center-cover.json')['cover'];results=[]
for case in cases:
    name=case['case'];data=load(AREA/(name+'-capacity.json'));region=cells(data['combined_regions_um'],'inner')&~cells(data['fixed_inner_obstacles_um'],'obstacle');domain=cells([cover[i][1:5] for i in case['center_cover_indices']],'center');counts=convolve2d(region.astype(np.int64),kernel,mode='same',boundary='fill',fillvalue=0);assert counts.max()<=kernel.sum()
    splits=inv[name]['relaxed_free_cog_remaining_splits'];assert splits;required=min(((12-b)*39999+(21-i)*19799)*10**6 for b,i in splits);upper=data['combined_area_upper_um2'];blocked=counts*h*h;remaining=domain&(upper-blocked>=required);np.savez_compressed(OUT/(name+'.npz'),companion_inner_cells=region,center_domain_cells=domain,forced_occupied_cell_counts=counts,remaining_center_cells=remaining)
    results.append({'case':name,'omitted_sites':case['omitted_sites'],'first_companion_upper_um2':upper,'minimum_required_first_companion_um2':required,'companion_inner_grid_cells':int(region.sum()),'necessary_center_grid_cells':int(domain.sum()),'pruned_center_grid_cells':int((domain&~remaining).sum()),'remaining_center_grid_cells':int(remaining.sum()),'minimum_forced_companion_overlap_um2':int(blocked[domain].min()),'provisional_exact_first32_excluded':not bool(remaining.any())})
write(OUT/'kernel.json',{'step_um':h,'radius_um':rad,'offset':offset,'kernel':kernel.tolist(),'covered_target_cells':int(kernel.sum())});write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':len(results),'center_cells':sum(r['necessary_center_grid_cells'] for r in results),'pruned_center_cells':sum(r['pruned_center_grid_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
