"""Exact pose-invariant original-cog area and disk containment certificate."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-free-cog-geometry-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PRIOR=ROOT/'benchmarks/results/h5-three-empty-cog-capacity-20261107';DER=ROOT/'output/h5-orientation-roofs-20261107/cog-derivation.json';STOCK=ROOT/'output/h5-roof-inventory-bound-20261107/stock-and-inventory.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def add(a,b):
    r=dict(a)
    for k,v in b.items():r[k]=r.get(k,Q(0))+v
    return {k:v for k,v in r.items() if v}
def scale(p,k):return {a:b*k for a,b in p.items() if b*k}
def mul(a,b):
    r={}
    for m,v in a.items():
        for n,w in b.items():
            k=tuple(x+y for x,y in zip(m,n));r[k]=r.get(k,Q(0))+v*w
    return {k:v for k,v in r.items() if v}
def det(a,b):return a[0]*b[1]-a[1]*b[0]
OUT.mkdir();began=time.perf_counter();assert load(PRIOR/'checks.json')['passed']
inputs=[Path(__file__),JOB,DER,STOCK,PRIOR/'checks.json',PRIOR/'inventory-audit.json',PRIOR/'fixed32-capacities.json',ROOT/'crates/validator/src/lib.rs']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Exact rational original vertices and symbolic shoelace polynomial in c,s,tx,ty prove filled outer area equals source area times(c*c+s*s), independent of translation. Exact rigid rotations impose c*c+s*s=1. Prove a centered source disk from positive radial fan triangles and edge-line distances; it remains contained under every exact rigid angle. Record an explicit perturbation/determinant predicate for future native candidates, not an unproved all-angle libm guarantee. A deliberately conservative50000mm2 cog area lower bound and108mm disk suffice. Re-enumerate all286 original companion inventories and all680 first-core areas for the exact-source geometry theorem. No sampled angles or new optimizer.','inherited_numeric_preparation_seconds':load(PRIOR/'checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':10,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
job=load(JOB);part=next(p for p in job['parts'] if p['id']=='cog');assert part['quantity']==15 and job['units']=='mm';p=[tuple(map(Q,v)) for v in part['geometry'][0]['outer']];center=tuple(map(Q,load(DER)['source_center']));v=[(x-center[0],y-center[1]) for x,y in p];n=len(p);assert n==80
area=sum(det(a,b) for a,b in zip(p,p[1:]+p[:1]))/2;assert area>50062
# Four indeterminates ordered c,s,tx,ty.
c={(1,0,0,0):Q(1)};s={(0,1,0,0):Q(1)};tx={(0,0,1,0):Q(1)};ty={(0,0,0,1):Q(1)}
trans=[(add(add(scale(c,x),scale(s,-y)),tx),add(add(scale(s,x),scale(c,y)),ty)) for x,y in p];poly={}
for a,b in zip(trans,trans[1:]+trans[:1]):poly=add(poly,add(mul(a[0],b[1]),scale(mul(a[1],b[0]),-1)))
poly=scale(poly,Q(1,2));assert poly=={(2,0,0,0):area,(0,2,0,0):area}
radius=Q(108);edges=[]
for i,(a,b) in enumerate(zip(v,v[1:]+v[:1])):
    edge=(b[0]-a[0],b[1]-a[1]);cross=det(a,b);norm=sum(z*z for z in edge);assert cross>0 and cross*cross>radius*radius*norm
    edges.append({'edge':i,'radial_cross':str(cross),'edge_length_squared':str(norm),'line_distance_squared':str(cross*cross/norm)})
# Winding is verified separately by the auditor; all source vertices are exterior to disk.
pad=Q(1,10**6);error=n*(8192*pad+pad*pad);lower=50000;detmin=Q(999,1000);assert area*detmin-error>lower
write(OUT/'geometry.json',{'source_center':[str(x) for x in center],'source_vertex_count':n,'source_filled_outer_area_mm2':str(area),'symbolic_area_coefficients':{','.join(map(str,k)):str(z) for k,z in poly.items()},'source_disk_radius_mm':108,'source_disk_edge_certificates':edges,'exact_rigid_area_lower_mm2':lower,'exact_rigid_disk_contained':True,'native_candidate_required_determinant_min':str(detmin),'native_candidate_required_vertex_error_max_mm':str(pad),'native_candidate_required_unrounded_coordinate_abs_max_mm':4096,'native_candidate_area_error_bound_mm2':str(error),'native_candidate_area_lower_mm2':lower,'all_angle_libm_error_claimed':False,'native_candidate_predicates_must_be_checked':True,'part_in_hole_not_enabled':True})
short=load(STOCK)['short_area_upper_um2'];available=short-lower*10**6;splits=[]
for b in range(13):
    for i in range(22):
        a=(b*39999+i*19799)*10**6;splits.append({'short_brackets':b,'short_inserts':i,'short_body_lower_um2':a,'allowed_with_any_source_rigid_short_cog':a<=available})
maximum=max(r['short_body_lower_um2'] for r in splits if r['allowed_with_any_source_rigid_short_cog']);required=(12*39999+21*19799)*10**6-maximum;assert required==495777*10**6
proofs=load(PRIOR/'fixed32-capacities.json');assert len(proofs)==680 and all(Q(str(r['first_companion_area_upper_mm2']))<required/10**6 for r in proofs)
write(OUT/'whole-part-splits.json',splits);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'source_filled_cog_area_lower_mm2':lower,'universal_source_disk_radius_mm':108,'short_companion_area_upper_mm2':available/1e6,'first_companion_area_required_mm2':required/1e6,'exact_source_rigid_short_cog_cases_excluded':680,'remaining_first32_cases_requiring_cog_on_first':237,'native_floatingpoint_all_angles_claimed':False,'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
