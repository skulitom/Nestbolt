"""Correct source-disk certificate: segment distance, not infinite edge lines."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/prepare_h5_free_cog_geometry_20261107.py'
src=OLD.read_text(encoding='utf-8')
# Preserve the failed first preparation. This distinct corrected stage retains its cost.
src=src.replace("OUT=ROOT/'output/h5-free-cog-geometry-20261107'", "OUT=ROOT/'output/h5-free-cog-geometry-v2-20261107'")
src=src.replace("inputs=[Path(__file__),JOB", "failure=load(ROOT/'output/h5-free-cog-geometry-process-20261107/process.json');assert failure['closed'] and not failure['passed']\ninputs=[Path(__file__),OLD,ROOT/'output/h5-free-cog-geometry-process-20261107/process.json',JOB")
src=src.replace("load(PRIOR/'checks.json')['complete_preparation_seconds_if_consumed']", "load(PRIOR/'checks.json')['complete_preparation_seconds_if_consumed']+failure['complete_seconds']")
src=src.replace('positive radial fan triangles and edge-line distances','positive radial fan triangles and exact center-to-segment distances; a separate auditor certifies winding and simplicity')
a="""    edge=(b[0]-a[0],b[1]-a[1]);cross=det(a,b);norm=sum(z*z for z in edge);assert cross>0 and cross*cross>radius*radius*norm
    edges.append({'edge':i,'radial_cross':str(cross),'edge_length_squared':str(norm),'line_distance_squared':str(cross*cross/norm)})"""
b="""    edge=(b[0]-a[0],b[1]-a[1]);cross=det(a,b);norm=sum(z*z for z in edge);assert cross>0 and norm>0
    t=max(Q(0),min(Q(1),-sum(x*y for x,y in zip(a,edge))/norm));distance=sum((x+t*y)**2 for x,y in zip(a,edge));assert distance>radius*radius
    edges.append({'edge':i,'radial_cross':str(cross),'edge_length_squared':str(norm),'projection_parameter':str(t),'segment_distance_squared':str(distance)})"""
assert a in src;src=src.replace(a,b)
exec(compile(src,str(Path(__file__)), 'exec'))
