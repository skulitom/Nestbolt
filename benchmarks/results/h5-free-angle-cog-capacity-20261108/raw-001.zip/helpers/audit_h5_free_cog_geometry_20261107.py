"""Independent exact source-area, disk topology and inventory readback."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free-cog-geometry-v2-20261107';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PRIOR=ROOT/'benchmarks/results/h5-three-empty-cog-capacity-20261107';STOCK=ROOT/'output/h5-roof-inventory-bound-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for folder in [STOCK/'audit',ROOT/'output/h5-three-empty-areas-20261107/audit',ROOT/'output/h5-three-empty-sources-20261107/audit']:
    assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'geometry.json',BASE/'whole-part-splits.json',BASE/'checks.json',STOCK/'stock-and-inventory.json',PRIOR/'remaining-first32-cases.json']:
    bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Exact rational triangle-fan area independent of the producer symbolic polynomial. Pairwise segment simplicity and signed-ray winding certify the source disk topology; independently use endpoint/projection branches for all80 segment distances. Verify translation telescoping and determinant area identity, plus a quantitative perturbation lemma under an explicit determinant/coordinate-error predicate. This proves exact rigid source geometry for every angle, not an all-angle libm implementation guarantee. Re-enumerate inventories by integer division and reconcile all680 source area bounds, preserving237 necessary-only survivors requiring their last source cog on the first sheet.'})
job=load(JOB);part=next(p for p in job['parts'] if p['id']=='cog');g=load(BASE/'geometry.json');center=tuple(map(Q,g['source_center']));points=[tuple(map(Q,p)) for p in part['geometry'][0]['outer']];n=len(points);assert n==80
area=sum(cross(center,points[i],points[(i+1)%n]) for i in range(n))/2;assert area==Q(g['source_filled_outer_area_mm2'])>50062
assert g['symbolic_area_coefficients']=={'2,0,0,0':str(area),'0,2,0,0':str(area)}
# det([[c,-s],[s,c]])=c²+s²; translation terms telescope around a closed ring.
assert sum(points[(i+1)%n][k]-points[i][k] for i in range(n) for k in [])==0
for k in range(2):assert sum(points[(i+1)%n][k]-points[i][k] for i in range(n))==0
winding=0
for a,b in zip(points,points[1:]+points[:1]):
    side=cross(a,b,center)
    if a[1]<=center[1]<b[1] and side>0:winding+=1
    if b[1]<=center[1]<a[1] and side<0:winding-=1
assert winding==1
pairs=0
for i,j in combinations(range(n),2):
    if j==i+1 or (i==0 and j==n-1):continue
    a,b,c,d=points[i],points[(i+1)%n],points[j],points[(j+1)%n];pairs+=1
    if any(max(a[k],b[k])<min(c[k],d[k]) or max(c[k],d[k])<min(a[k],b[k]) for k in range(2)):continue
    assert cross(a,b,c)*cross(a,b,d)>0 or cross(c,d,a)*cross(c,d,b)>0
distances=[]
for i,(a,b) in enumerate(zip(points,points[1:]+points[:1])):
    v=(b[0]-a[0],b[1]-a[1]);w=(center[0]-a[0],center[1]-a[1]);q=sum(x*y for x,y in zip(w,v));norm=sum(x*x for x in v)
    if q<=0:d=sum(x*x for x in w);t=Q(0)
    elif q>=norm:d=sum((center[k]-b[k])**2 for k in range(2));t=Q(1)
    else:d=cross(a,b,center)**2/norm;t=q/norm
    old=g['source_disk_edge_certificates'][i];assert d==Q(old['segment_distance_squared']) and t==Q(old['projection_parameter']) and d>108**2;distances.append(d)
pad=Q(g['native_candidate_required_vertex_error_max_mm']);err=n*(2*Q(g['native_candidate_required_unrounded_coordinate_abs_max_mm'])*pad+pad*pad);detmin=Q(g['native_candidate_required_determinant_min']);assert err==Q(g['native_candidate_area_error_bound_mm2']) and area*detmin-err>50000
# A fixed world-axis square of halfwidth76 is contained at every rigid angle.
# It also fits the disk under the explicit determinant>=.999 predicate with ample margin.
assert 2*(Q(76)+2*pad)**2<108**2*detmin
assert g['all_angle_libm_error_claimed'] is False and g['native_candidate_predicates_must_be_checked'] is True
stock=load(STOCK/'stock-and-inventory.json');short=stock['short_area_upper_um2'];available=short-50000*10**6
allowed={(b,i) for b in range(13) for i in range(min(21,(available-b*39999*10**6)//(19799*10**6))+1)}
saved=load(BASE/'whole-part-splits.json');assert len(saved)==286 and allowed=={(r['short_brackets'],r['short_inserts']) for r in saved if r['allowed_with_any_source_rigid_short_cog']}
maximum=max((b*39999+i*19799)*10**6 for b,i in allowed);required=(12*39999+21*19799)*10**6-maximum;assert maximum==399990*10**6 and required==495777*10**6
proofs=load(PRIOR/'fixed32-capacities.json');assert len(proofs)==680;results=[]
for r in proofs:
    upper=Q(str(r['first_companion_area_upper_mm2']));assert upper<required/10**6
    results.append({'case':r['case'],'omitted_sites':r['omitted_sites'],'first_companion_upper_mm2':float(upper),'required_if_last_cog_on_short_mm2':495777,'all_exact_rigid_source_short_cog_poses_excluded':True,'fixed_first32_already_excluded_all_remaining_parts_free':r['exact_first32_excluded_even_last_cog_free'],'requires_last_source_cog_on_first_if_completion_exists':not r['exact_first32_excluded_even_last_cog_free']})
remaining=[r for r in results if r['requires_last_source_cog_on_first_if_completion_exists']];assert len(remaining)==237 and {r['case'] for r in remaining}=={r['case'] for r in load(PRIOR/'remaining-first32-cases.json')}
process=load(ROOT/'output/h5-free-cog-geometry-v2-process-20261107/process.json');assert process['passed'] and process['closed'];total=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'capacity-results.json',results);write(OUT/'remaining-first32-cases.json',remaining)
write(OUT/'universal-inner-square.json',{'reference':'image of original source center','bounds_relative_to_center_um':[-76000,-76000,76000,76000],'source_disk_radius_mm':108,'every_exact_rigid_source_angle_covered':True,'floating_native_usage_requires_explicit_predicates':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'original_vertices_verified':80,'nonadjacent_source_edge_pairs_checked':pairs,'source_winding_number':winding,'source_filled_outer_area_mm2':float(area),'source_area_lower_mm2':50000,'minimum_source_segment_distance_squared_mm2':float(min(distances)),'universal_source_disk_radius_mm':108,'universal_source_inner_square_halfwidth_mm':76,'short_companion_area_upper_mm2':available/1e6,'first_companion_required_mm2':495777,'all_exact_source_rigid_short_cog_cases_excluded':680,'remaining_first32_cases_requiring_cog_on_first':237,'all_angle_native_libm_proof_claimed':False,'failed_first_preparation_preserved':True,'complete_preparation_seconds_if_consumed':total,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
