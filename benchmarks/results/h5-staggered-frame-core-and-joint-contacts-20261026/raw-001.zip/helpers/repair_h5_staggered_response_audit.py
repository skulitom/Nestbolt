"""Separate returned-worker counters from the actual logged search phases."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-staggered-core-contact-pool-20261026';old=ROOT/'output/audit_h5_staggered_contact_response.py';s=old.read_text(encoding='utf-8')
record={'failed':True,'reason':'The first response audit incorrectly inferred presolve termination from the returned response having zero branches. The actual log starts search, default_lp explores6127 branches and no_lp11174, while max_lp closes infeasibility with1086 LP iterations and supplies the returned counters.','repair':'Preserve the exact call, response and failed audit. Check actual logged search start, completing worker and all worker branch counters separately. No solver restart or model change.','solver_calls_repeated':0}
with (BASE/'response-audit/failure-review.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
s=s.replace("OUT=BASE/'response-audit'","OUT=BASE/'response-audit-worker-repaired'")
s=s.replace(" and 'Problem closed by presolve.' in log"," and 'Starting search at ' in log and 'Problem closed by presolve.' not in log")
s=s.replace("pool=load(BASE/'candidates.json');",'''stats=log.split('Search stats',1)[1].split('SAT stats',1)[0];worker_stats=[]
for name,bools,conflicts,branches in re.findall(r"^\\s+'([^']+)':\\s+([0-9']+)\\s+([0-9']+)\\s+([0-9']+)",stats,re.M):
    worker_stats.append({'worker':name,'booleans':int(bools.replace("'",'')),'conflicts':int(conflicts.replace("'",'')),'branches':int(branches.replace("'",''))})
assert {r['worker']:r['branches'] for r in worker_stats}=={'default_lp':6127,'max_lp':0,'no_lp':11174} and response.num_lp_iterations==1086 and re.search(r'^#Done\\s+[0-9.]+s max_lp \\[loading\\]',log,re.M)
write(OUT/'worker-stats.json',worker_stats)
pool=load(BASE/'candidates.json');''')
s=s.replace("'stopped_after_presolve':True,","'stopped_after_presolve':False,'completing_worker':'max_lp','response_lp_iterations':response.num_lp_iterations,'worker_stats':worker_stats,'returned_response_branches':response.num_branches,")
with (ROOT/'output/audit_h5_staggered_contact_response_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
