"""Keep the failed parser and restrict its check to the actual Search stats table."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-staggered-core-contact-pool-20261026';source=ROOT/'output/audit_h5_staggered_contact_response_repaired.py';s=source.read_text(encoding='utf-8')
record={'failed':True,'reason':'The repaired parser included both Search stats and the intervening SAT formula table before SAT stats. Duplicate worker names from SAT formula overwrote their branch counts in the comparison.','repair':'Bound the parser at the next SAT formula heading, retain the three exact Search stats records, and verify the completing-worker line and response LP iterations. Original model, one call and response remain unchanged.','solver_calls_repeated':0}
with (BASE/'response-audit-worker-repaired/failure-review.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
s=s.replace("OUT=BASE/'response-audit-worker-repaired'","OUT=BASE/'response-audit-worker-table-repaired'").replace(".split('SAT stats',1)",".split('SAT formula',1)")
with (ROOT/'output/audit_h5_staggered_contact_response_table_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
