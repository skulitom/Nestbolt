"""Retain the failed premise and repair only its provenance audit, without regenerating geometry."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'output/audit_h5_staggered_contact_graph.py';s=p.read_text(encoding='utf-8');d=ROOT/'output/h5-staggered-core-contact-pool-20261026/audit'
r={'failed':True,'reason':'The audit required every non-cog obstacle proposal to be separated from its generating cog. The shared proposal enumerator also includes an obstacle-interior representative. Those poses were admitted only against the fixed26 core, and are legitimate standalone candidates, but conflict with their generating cog candidate. Their exact graph exclusion must be retained.','repair':'Preserve this failed audit. Independently classify representative versus boundary proposals, require every conflicting parent proposal to be an interior representative and require its full source conflict edge. No candidate, graph, generation result or budget changes; no solver opened.','solver_calls':0}
with (d/'failure-review.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(r,f,indent=2);f.write('\n')
s=s.replace("OUT=BASE/'audit'","OUT=BASE/'audit-provenance-repaired'").replace('provenance=Counter()','provenance=Counter();parent_conflicts=[];interior_proposals=0')
s=s.replace(" and g.distance(shapes[o['parent']])>required",'')
needle="assert t['rotation_radians']==orientation['angle'] and t['mirrored']==orientation['mirrored']"
replacement=needle+"\n        if query[name]['proposals'][o['proposal']]['kind']=='representative':interior_proposals+=1\n        if g.distance(shapes[o['parent']])<=required:\n            assert query[name]['proposals'][o['proposal']]['kind']=='representative';parent_conflicts.append((o['parent'],i))"
assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace('covered=[0]*n;',"for parent,child in parent_conflicts:assert (graph[parent]>>child)&1\ncovered=[0]*n;")
s=s.replace("'source_provenance_counts':dict(provenance),","'source_provenance_counts':dict(provenance),'obstacle_interior_representatives':interior_proposals,'conflicting_parent_edges_verified':len(parent_conflicts),")
with (ROOT/'output/audit_h5_staggered_contact_graph_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
