"""Audit the sole joint finite-pool call without reopening it."""
from pathlib import Path
from hashlib import sha256
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-staggered-core-contact-pool-20261026';SEARCH=BASE/'search';OUT=BASE/'response-audit-worker-table-repaired';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();check=load(BASE/'model/checks.json');assert check['passed']
for record in [load(BASE/'model/plan.json'),load(BASE/'plan.json')]:
    for n,h in record['inputs'].items():assert digest(ROOT/n)==h,n
assert digest(SEARCH/'model.pb')==check['model_sha256'];opened=load(SEARCH/'opened.json');assert opened['maximum_calls']==1 and opened['solver_seconds']==60 and opened['shared_seconds']==90
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=60.,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False)
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes());result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<90
assert cp_model_pb2.CpSolverStatus.Name(response.status)==result['status']=='INFEASIBLE' and not response.solution and result['selected'] is None and result['solver_calls']==1 and result['closed'];assert response.num_branches==result['branches']==0 and response.num_conflicts==result['conflicts']==0 and response.wall_time==result['solver_wall_seconds']
assert 0<response.wall_time<=result['returned_solve_seconds']<=process['seconds'] and result['returned_solve_seconds']<60;log=(SEARCH/'solver.log').read_text();wall=float(re.findall(r'^walltime:\s+([0-9.]+)',log,re.M)[-1]);assert abs(wall-response.wall_time)<.000001 and 'Starting search at ' in log and 'Problem closed by presolve.' not in log
stats=log.split('Search stats',1)[1].split('SAT formula',1)[0];worker_stats=[]
for name,bools,conflicts,branches in re.findall(r"^\s+'([^']+)':\s+([0-9']+)\s+([0-9']+)\s+([0-9']+)",stats,re.M):
    worker_stats.append({'worker':name,'booleans':int(bools.replace("'",'')),'conflicts':int(conflicts.replace("'",'')),'branches':int(branches.replace("'",''))})
assert {r['worker']:r['branches'] for r in worker_stats}=={'default_lp':6127,'max_lp':0,'no_lp':11174} and response.num_lp_iterations==1086 and re.search(r'^#Done\s+[0-9.]+s max_lp \[loading\]',log,re.M)
write(OUT/'worker-stats.json',worker_stats)
pool=load(BASE/'candidates.json');depths={str(k):sum(r['placement']['part_id']=='cog' and r['source'].get('depth')==k for r in pool) for k in range(4)}
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':'INFEASIBLE','solver_calls':1,'closed':True,'solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],'shared_budget_honored':True,'soft_overruns':False,'stopped_after_presolve':False,'completing_worker':'max_lp','response_lp_iterations':response.num_lp_iterations,'worker_stats':worker_stats,'returned_response_branches':response.num_branches,'all25_movers_required':True,'mandatory_counts':check['exact_family_counts'],'cog_contact_depth_counts':depths,'finite_pool_only':True,'fixed26_neighborhood_excluded':False,'unrestricted_source_exclusion':False,'formal_unsat_certificate_claimed':False,'full66_target_witness':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
