"""Fresh finite original-shape contact closure with all25 remaining originals required."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter,deque
import json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,mapping
from shapely.affinity import affine_transform,translate
import diagnose_h5_concave_gaps as geom
from build_h5_cog_free_regions import proposals,identity
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-staggered-core-contact-pool-20261026';CORE=ROOT/'output/h5-staggered-frame-bracket-core-repaired-20261026/audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'regions').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+180;spec=load(CORE/'next-neighborhood.json');assert load(CORE/'checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};source={k:Polygon(v['geometry'][0]['outer']) for k,v in parts.items()};guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);caps={'cog':1400,'bracket':300,'insert':300};phases=[0.,4.5,9.,13.5]
orient=[{'family':'cog','angle':math.radians(a),'mirrored':False} for a in phases]+[{'family':'bracket','angle':q*math.pi/2,'mirrored':m} for m in [False,True] for q in range(4)]+[{'family':'insert','angle':q*math.pi/2,'mirrored':False} for q in range(2)]
inputs=[JOB,CORE/'next-neighborhood.json',CORE/'checks.json',Path(geom.__file__),ROOT/'output/build_h5_cog_free_regions.py',ROOT/'output/h5-original-cog-phase-lattice-20261026/wheel-audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'generation_seconds':180,'candidate_caps':caps,'orientations':orient,'required_pair_gap_mm':required,'required_extra_stock_mm':guard,'radial_cog_contacts':{'angles_degrees':list(range(0,360,15)),'bisection_steps':32,'initial_radius_bracket_mm':[0,300],'pair_target_gap_mm':.225,'extra_radial_margin_mm':.001,'maximum_parent_depth':3},'spatial_quota':{'bin_mm':25,'maximum_per_family_orientation_bin':2},'fixed_boundary_seed_caps':{'cog':160,'bracket':150,'insert':150},'noncog_contact_parents':64,'method':'New fixed26/short15 source geometry. All25 movers remain mandatory:3 brackets,7 inserts,15 cogs. Generate fresh fixed-obstacle translation regions for14 declared original orientations, admitting boundary vertices, midpoints and representatives round-robin with reserved family quotas. Extend cog centers independently by actual source-pair radial contacts, interleaving every active parent rather than forcing common rows, pitch or phase. Every accepted source pose must satisfy stock and all26 fixed filled outers. Then add non-cog boundary contacts around64 spatially spread cog candidates using original Minkowski obstacles, with remaining family quotas. Exact transform deduplication plus an explicitly finite25mm spatial quota controls near-duplicates; omitted proposals and unfinished queues are retained. No unrestricted coverage claim. A complete fresh conflict graph and independent audit must precede one joint solver with exact3/7/15 counts. Prior unchanged finite calls stay closed. No native/quality call here.'})
def shape(p):
    t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
    return affine_transform(source[p['part_id']],[m*c,-s,m*s,c,*t['translation']])
def pose(o,xy):return {'part_id':o['family'],'sheet_id':'sheet-0','transform':{'rotation_radians':o['angle'],'mirrored':o['mirrored'],'translation':list(xy)}}
def centered_cog(phase):
    a=math.radians(phase);c,s=math.cos(a),math.sin(a);return shape(pose({'family':'cog','angle':a,'mirrored':False},[-139.723742*c+139.723742*s,-139.723742*s-139.723742*c]))
def cog_pose(pi,center):
    a=math.radians(phases[pi]);c,s=math.cos(a),math.sin(a);return pose(orient[pi],[center[0]-139.723742*c+139.723742*s,center[1]-139.723742*s-139.723742*c])
fixed=np.asarray([shape(p) for p in spec['fixed_first_placements']],dtype=object);stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];bounds=[m['left']+edge+guard,m['bottom']+edge+guard,stock['width']-m['right']-edge-guard,stock['height']-m['top']-edge-guard];geom.EPS=.0126
pool=[];seen={};buckets=Counter();counts=Counter();events=[];queries=[];pending={}
def consider(p,origin):
    family=p['part_id'];key=identity(p)
    if counts[family]>=caps[family]:return None,'family_cap'
    if key in seen:return seen[key],'exact_duplicate'
    g=shape(p);b=g.bounds;t=p['transform'];bucket=(family,t['rotation_radians'],t['mirrored'],math.floor(b[0]/25),math.floor(b[1]/25))
    if buckets[bucket]>=2:return None,'spatial_quota'
    if not(b[0]>bounds[0] and b[1]>bounds[1] and b[2]<bounds[2] and b[3]<bounds[3]):return None,'stock'
    ds=shapely.distance(g,fixed)
    if float(np.min(ds))<=required:return None,'fixed_geometry'
    index=len(pool);seen[key]=index;pool.append({'index':index,'placement':p,'source':origin,'fixed_minimum_distance_mm':float(np.min(ds))});counts[family]+=1;buckets[bucket]+=1;return index,'added'
def attempt(p,origin):
    index,status=consider(p,origin);events.append({'source':origin,'candidate':index,'result':status});return index,status
for oi,o in enumerate(orient):
    if time.perf_counter()>=deadline:pending['unbuilt_fixed_queries']=list(range(oi,len(orient)));break
    region=geom.regions(shape(pose(o,[0.,0.])),list(fixed),stock,edge,required);q={'index':oi,'orientation':o,'geometry':mapping(region),'proposals':proposals(region)};queries.append(q);write(OUT/'regions'/f'fixed-{oi:02d}.json',q)
queue=deque((q['index'],0) for q in queries if q['proposals']);seeds=Counter()
while queue and time.perf_counter()<deadline:
    qi,point=queue.popleft();q=queries[qi];family=q['orientation']['family']
    if seeds[family]<(160 if family=='cog' else 150):
        i,status=attempt(pose(q['orientation'],q['proposals'][point]['point']),{'kind':'fixed_boundary','query':qi,'proposal':point,'depth':0})
        if status=='added':seeds[family]+=1
        if point+1<len(q['proposals']):queue.append((qi,point+1))
    else:pending.setdefault('capped_fixed_boundary_lists',[]).append([qi,point])
pending['unfinished_fixed_boundary_lists']=list(queue);write(OUT/'seed-counts.json',dict(seeds));cg=[centered_cog(p) for p in phases];contacts=[]
for ai in range(4):
    for degrees in range(0,360,15):
        for bi in range(4):
            if time.perf_counter()>=deadline:raise RuntimeError('Preparation exceeded declared generation limit before contact table completion')
            a=math.radians(degrees);ux,uy=math.cos(a),math.sin(a);lo,hi=0.,300.
            for _ in range(32):
                mid=(lo+hi)/2;distance=cg[ai].distance(translate(cg[bi],xoff=mid*ux,yoff=mid*uy))
                if distance>.225:hi=mid
                else:lo=mid
            radius=hi+.001;actual=cg[ai].distance(translate(cg[bi],xoff=radius*ux,yoff=radius*uy));assert actual>.225
            contacts.append({'index':len(contacts),'parent_phase':ai,'child_phase':bi,'direction_degrees':degrees,'bracket_mm':[lo,hi],'radius_mm':radius,'offset_mm':[radius*ux,radius*uy],'verified_gap_mm':actual})
write(OUT/'radial-contacts.json',contacts);by_phase={i:[r for r in contacts if r['parent_phase']==i] for i in range(4)}
def cog_center(r):
    t=r['placement']['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);x,y=t['translation'];return [x+139.723742*c-139.723742*s,y+139.723742*s+139.723742*c]
frontier=deque((r['index'],0,0) for r in pool if r['placement']['part_id']=='cog')
while frontier and counts['cog']<caps['cog'] and time.perf_counter()<deadline:
    parent,k,depth=frontier.popleft();r=pool[parent];pi=next(i for i,o in enumerate(orient[:4]) if o['angle']==r['placement']['transform']['rotation_radians']);contact=by_phase[pi][k];center=cog_center(r);center=[center[d]+contact['offset_mm'][d] for d in range(2)];index,status=attempt(cog_pose(contact['child_phase'],center),{'kind':'cog_contact','parent':parent,'contact':contact['index'],'depth':depth+1})
    if k+1<len(by_phase[pi]):frontier.append((parent,k+1,depth))
    if status=='added' and depth+1<3:frontier.append((index,0,depth+1))
pending['cog_contact_frontier']=list(frontier)
cog_indices=sorted([r['index'] for r in pool if r['placement']['part_id']=='cog'],key=lambda i:(*cog_center(pool[i])[::-1],pool[i]['placement']['transform']['rotation_radians']));parent_indices=[cog_indices[i] for i in sorted(set(np.linspace(0,len(cog_indices)-1,min(64,len(cog_indices)),dtype=int).tolist()))] if cog_indices else [];write(OUT/'noncog-parent-indices.json',parent_indices)
contact_queries={}
for pi in range(4):
    for oi in range(4,len(orient)):
        if time.perf_counter()>=deadline:pending.setdefault('unbuilt_noncog_queries',[]).append([pi,oi]);continue
        obstacle=geom.obstacle(cg[pi],shape(pose(orient[oi],[0.,0.])),.225);q={'parent_phase':pi,'orientation_index':oi,'geometry':mapping(obstacle),'proposals':proposals(obstacle)};contact_queries[pi,oi]=q;write(OUT/'regions'/f'contact-{pi}-{oi:02d}.json',q)
q2=deque()
for parent in parent_indices:
    pi=next(i for i,o in enumerate(orient[:4]) if o['angle']==pool[parent]['placement']['transform']['rotation_radians'])
    for oi in range(4,len(orient)):
        if (pi,oi) in contact_queries:q2.append((parent,pi,oi,0))
while q2 and time.perf_counter()<deadline:
    parent,pi,oi,k=q2.popleft();o=orient[oi];q=contact_queries[pi,oi]
    if counts[o['family']]>=caps[o['family']]:pending.setdefault('capped_noncog_contact_lists',[]).append([parent,pi,oi,k]);continue
    xy=q['proposals'][k]['point'];center=cog_center(pool[parent]);attempt(pose(o,[xy[d]+center[d] for d in range(2)]),{'kind':'noncog_contact','parent':parent,'parent_phase':pi,'orientation':oi,'proposal':k})
    if k+1<len(q['proposals']):q2.append((parent,pi,oi,k+1))
pending['unfinished_noncog_contact_lists']=list(q2);write(OUT/'candidates.json',pool);write(OUT/'events.json',events);write(OUT/'pending.json',pending)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'candidate_counts':dict(counts),'candidates':len(pool),'event_counts':dict(Counter(e['result'] for e in events)),'fixed_queries':len(queries),'radial_source_contacts':len(contacts),'noncog_contact_queries':len(contact_queries),'noncog_contact_parents':len(parent_indices),'fixed_first_originals':26,'fixed_short_originals':15,'mandatory_moving_counts':{'bracket':3,'insert':7,'cog':15},'all66_originals_required':True,'rigid_lattice_required':False,'independent_graph_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
