from pathlib import Path
from hashlib import sha256
import json
import subprocess
import time
ROOT=Path.cwd()
PYTHON=ROOT/'.cache/shop-venv/Scripts/python.exe'
out=ROOT/'benchmarks/results/h3-open-line-audit-driver-20261015'
assert not out.exists()
out.mkdir()
rows=[]
for name,script,pattern in [('reviewed','h3_reviewed_prerequisites.py','h3-reviewed-prerequisites-*'),('open-lines','h3_open_line_audit.py','h3-open-lines-*')]:
    before=set((ROOT/'benchmarks/results').glob(pattern))
    start=time.perf_counter()
    with (out/(name+'.log')).open('wb') as log:
        result=subprocess.run([str(PYTHON),str(ROOT/'scripts'/script)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    rows.append(dict(name=name,exit_code=result.returncode,wall_seconds=time.perf_counter()-start,paths=[p.relative_to(ROOT).as_posix() for p in sorted(set((ROOT/'benchmarks/results').glob(pattern))-before)],log_sha256=sha256((out/(name+'.log')).read_bytes()).hexdigest()))
    (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(rows[-1]),flush=True)
    assert result.returncode==0
