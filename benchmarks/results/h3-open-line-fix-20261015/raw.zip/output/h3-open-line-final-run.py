from pathlib import Path
import subprocess,sys
root=Path.cwd()
for command in [[sys.executable,'output/ccd1.py',sys.executable,'output/h3-open-line-final-checks.py'],[sys.executable,'output/h3-open-line-final-audits.py']]:
    result=subprocess.run(command,cwd=root,creationflags=subprocess.CREATE_NO_WINDOW)
    if result.returncode:sys.exit(result.returncode)
