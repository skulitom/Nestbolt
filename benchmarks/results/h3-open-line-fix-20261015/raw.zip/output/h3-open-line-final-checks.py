from pathlib import Path
import json
import subprocess
import sys
import time
from hashlib import sha256
ROOT = Path.cwd()
out = ROOT/'benchmarks/results/h3-open-line-final-checks-20261015'
out.mkdir(exist_ok=False)
commands = [
    ('format', ['cargo','fmt','--all','--check']),
    ('workspace-tests', ['cargo','test','--workspace','--locked']),
    ('cli-release', ['cargo','test','--release','-p','nestbolt-cli','--test','features','--locked']),
    ('clippy', ['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),
    ('release', ['cargo','build','--release','--locked','-p','nestbolt-cli','-p','nestbolt-mcp']),
    ('examples', ['cargo','build','--release','--locked','-p','nestbolt-core','--example','lightburn_inspect','--example','lightburn_roundtrip']),
    ('web', [sys.executable,'scripts/build_web.py','--test']),
]
rows=[]
for name,command in commands:
    start=time.perf_counter()
    with (out/(name+'.log')).open('wb') as log:
        result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    row=dict(name=name,command=command,exit_code=result.returncode,wall_seconds=time.perf_counter()-start,log_sha256=sha256((out/(name+'.log')).read_bytes()).hexdigest())
    rows.append(row)
    (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(row),flush=True)
    if result.returncode:sys.exit(result.returncode)
print('All open-line checks passed',flush=True)
