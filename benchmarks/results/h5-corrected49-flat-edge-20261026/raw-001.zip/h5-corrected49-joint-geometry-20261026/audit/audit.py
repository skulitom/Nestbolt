"""Independent source containment, integer anchor complement and closed cog-grid reader."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-corrected49-joint-geometry-20261026';OUT=BASE/'audit';GEO=ROOT/'output/h5-allocation-geometry-20261026'
FIX=ROOT/'output/h5-retained49-stack-repair-20261026';MIX=ROOT/'output/h5-mixed-octagon-geometry-20261026';PAIR=ROOT/'output/h5-fixed-noncog-center-regions-20261026/upper-five-model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(FIX/'audit/checks.json')['passed'] and load(GEO/'audit/checks.json')['passed'] and load(MIX/'audit/checks.json')['passed']
source=load(FIX/'corrected49-source.json');moving=load(FIX/'mandatory17-movers.json');originals=load(GEO/'originals.json');ids={(p['family'],p['copy_index']):p['index'] for p in originals}
fixed=load(BASE/'fixed49.json');rectangles=load(BASE/'fixed-source-rectangles.json');movers=load(BASE/'mandatory17.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']}
assert len(source)==len(fixed)==49 and len(moving)==len(movers)==17 and sorted([p['original_index'] for p in fixed]+[p['index'] for p in movers])==list(range(66))
rid=0
for row,record in zip(source,fixed):
    assert record['source_placement']==row and record['original_index']==ids[row['part_id'],row['copy_index']] and record['key']==[row['part_id'],row['copy_index']] and record['sheet']==int(row['sheet_id'].split('-')[1])
    t=row['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];poly=Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[row['part_id']]['geometry'][0]['outer']]);assert record['rectangles']
    for index in record['rectangles']:
        assert index==rid;r=rectangles[rid];assert r['id']==rid and r['original_index']==record['original_index'] and r['family']==row['part_id'] and r['sheet']==record['sheet']
        b=r['bounds_um'];assert all(isinstance(x,int) for x in b) and b[0]<b[2] and b[1]<b[3] and poly.contains(box(*(v/1000 for v in b)));rid+=1
assert rid==len(rectangles)==69
for row,record in zip(moving,movers):
    assert record['prior_source_placement']==row and {k:v for k,v in record.items() if k!='prior_source_placement'}==next(p for p in originals if p['index']==ids[row['part_id'],row['copy_index']])
assert sorted(p['index'] for p in movers)==[20,23]+list(range(51,66))
variants=load(GEO/'variants.json');domains=load(GEO/'domains.json');regions=load(BASE/'bracket-anchor-regions.json');expected_domains=[d for d in domains if d['allowed'] and d['variant']<8];merged_count=0;forbidden_count=0
def unit_union(rows):return unary_union([box(a,b,c+1,d+1) for a,b,c,d in rows])
for d,r in zip(expected_domains,regions):
    assert r['variant']==d['variant'] and r['sheet']==d['sheet'] and r['domain_um']==d['bounds_um'];domain=d['bounds_um'];forbidden=[]
    for f in [p['bounds_um'] for p in rectangles if p['sheet']==d['sheet']]:
        for m in variants[d['variant']]['coarse_rectangles_um']:
            b=[max(domain[0],f[0]-m[2]+1),max(domain[1],f[1]-m[3]+1),min(domain[2],f[2]-m[0]-1),min(domain[3],f[3]-m[1]-1)]
            if b[0]<=b[2] and b[1]<=b[3]:forbidden.append(b)
    assert Counter(map(tuple,forbidden))==Counter(map(tuple,r['forbidden_integer_boxes']))
    exact=box(domain[0],domain[1],domain[2]+1,domain[3]+1).difference(unit_union(forbidden));raw=unit_union(r['raw_free_cells']);merged=unit_union(r['merged_free_cells']);assert exact.equals(raw) and raw.equals(merged)
    assert all(all(isinstance(v,int) for v in b) and b[0]<=b[2] and b[1]<=b[3] for b in r['merged_free_cells']);merged_count+=len(r['merged_free_cells']);forbidden_count+=len(forbidden)
assert len(regions)==len(expected_domains)==16
octagon=load(MIX/'octagon.json')['vertices_um'];polys=load(BASE/'cog-fixed-forbidden-polygons.json');support_checks=0
for r,p in zip(rectangles,polys):
    assert p['fixed_rectangle_id']==r['id'] and p['sheet']==r['sheet'];b=r['bounds_um'];sums={(x-u,y-v) for x in [b[0],b[2]] for y in [b[1],b[3]] for u,v in octagon};verts=p['vertices_um'];faces=p['inward_faces'];assert len(verts)==len(faces)==12 and all(tuple(v) in sums for v in verts)
    for j,(a,c,rhs) in enumerate(faces):
        u,v=verts[j],verts[(j+1)%12];assert a*u[0]+c*u[1]==rhs and a*v[0]+c*v[1]==rhs and math.gcd(abs(a),abs(c))==1
        assert all(a*x+c*y>rhs for k,(x,y) in enumerate(verts) if k not in [j,(j+1)%12]) and all(a*x+c*y>=rhs for x,y in sums);support_checks+=len(sums)
assert len(polys)==69
table=[];removed=remaining=corner_checks=0
for d,cover in zip([d for d in domains if d['variant']==12],load(BASE/'cog-cell-covers.json')):
    s=d['sheet'];x0,y0,x1,y1=d['bounds_um'];step=10000;nx=math.ceil((x1-x0)/step);ny=math.ceil((y1-y0)/step)
    assert cover['sheet']==s and cover['domain_um']==d['bounds_um'] and cover['step_um']==step and (cover['columns'],cover['rows'])==(nx,ny) and len(cover['removing_polygon_by_cell'])==nx*ny
    assert (x1-x0)//step==nx-1 and (y1-y0)//step==ny-1
    legal=[]
    for k,pi in enumerate(cover['removing_polygon_by_cell']):
        i,j=k%nx,k//nx;b=[x0+i*step,y0+j*step,min(x1,x0+(i+1)*step),min(y1,y0+(j+1)*step)]
        if pi<0:assert pi==-1;legal.append(k);table.append([s,i,j]);remaining+=1
        else:
            p=polys[pi];assert p['sheet']==s;removed+=1
            for a,c,rhs in p['inward_faces']:assert all(a*x+c*y>rhs for x in [b[0],b[2]] for y in [b[1],b[3]]);corner_checks+=4
    assert cover['legal_grid_indices']==legal
assert load(BASE/'cog-cell-table.json')==table
assert (BASE/'bracket-cog-forbidden-polygons.json').read_bytes()==(MIX/'forbidden-polygons.json').read_bytes() and (BASE/'cog-pair-separation-polygon.json').read_bytes()==(PAIR/'pair-separation-polygon.json').read_bytes() and load(PAIR/'model-audit/checks.json')['passed']
assert Counter(p['key'][0] for p in fixed if p['sheet']==1)=={'bracket':4,'insert':2}
counts=[p['short_counts'] for p in load(GEO/'allowed-allocations.json') if p['short_counts'][1]==2 and 4<=p['short_counts'][0]<=6];assert load(BASE/'short-count-rows.json')==counts
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'corrected_source_valid_fixed_originals_verified':49,'mandatory_movers_verified':17,'all66_source_identities_accounted_for':True,
    'fresh_source_contained_rectangles_verified':69,'bracket_variant_sheet_domains_verified':16,'exact_forbidden_integer_boxes_verified':forbidden_count,'complete_merged_bracket_anchor_rectangles_verified':merged_count,
    'fixed_cog_minkowski_polygons_verified':69,'exact_point_sum_support_checks':support_checks,'closed_cog_grid_cells_verified':removed+remaining,'strictly_excluded_cells':removed,'canonical_grid_table_rows_verified':remaining,'exact_corner_facet_checks':corner_checks,
    'boundary_integer_centers_preserved':True,'reused_mixed_and_pair_geometry_hash_verified':True,'compatible_universal_count_rows_verified':len(counts),'old_position_dependent_certificates_not_used':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
