"""Fresh necessary geometry for two mandatory brackets and all15 cogs."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon,Point,box
from h5_fixed_proxy_regions import coarse_regions
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-corrected49-joint-geometry-20261026'
FIX=ROOT/'output/h5-retained49-stack-repair-20261026';GEO=ROOT/'output/h5-allocation-geometry-20261026';MIX=ROOT/'output/h5-mixed-octagon-geometry-20261026'
PAIR=ROOT/'output/h5-fixed-noncog-center-regions-20261026/upper-five-model';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
    ps=sorted(set(points));lo=[];hi=[]
    for p in ps:
        while len(lo)>1 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
        lo.append(p)
    for p in ps[::-1]:
        while len(hi)>1 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
        hi.append(p)
    return lo[:-1]+hi[:-1]
assert load(FIX/'audit/checks.json')['passed'] and load(GEO/'audit/checks.json')['passed'] and load(MIX/'audit/checks.json')['passed'] and load(PAIR/'model-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
paths=[FIX/n for n in ['corrected49-source.json','mandatory17-movers.json','audit/checks.json']]+[GEO/n for n in ['originals.json','variants.json','domains.json','allowed-allocations.json','audit/checks.json']]+[MIX/n for n in ['octagon.json','forbidden-polygons.json','audit/checks.json']]+[PAIR/n for n in ['pair-separation-polygon.json','model-audit/checks.json']]+[JOB]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_calls':0,
    'method':'Rebuild every fixed obstacle from corrected49 original source transforms. Decompose filled non-cog outer rings into axis-aligned source cells and inset each integer world rectangle by at least2um; verify containment. Preserve all17 mandatory movers: two bracket originals and every cog. For each bracket variant/sheet derive the complete integer anchor complement against all fixed source rectangles; merge only adjacent rectangles with identical Y ranges. For cogs rebuild the exact source-octagon Minkowski forbidden polygons, then create a closed10mm stock-domain cell cover that discards cells only on strict whole-cell inclusion in one forbidden polygon. Canonical floor-divided grid indices give a necessary (sheet,xcell,ycell) table; all boundary centers are retained. Reuse only universal mixed octagon polygons, all-angle64-facet cog-pair necessity and count-frontier rows compatible with fixed short4brackets/2inserts. Old position-dependent exclusions are not reused. A later coordinated model must include all17 movers with legal sheets/orientations, source-aware mixed collisions and cog separation; necessary assignments are not source witnesses.'})
fixed=load(FIX/'corrected49-source.json');moving=load(FIX/'mandatory17-movers.json');job=load(JOB);parts={p['id']:p for p in job['parts']};originals=load(GEO/'originals.json');ids={(p['family'],p['copy_index']):p['index'] for p in originals}
assert len(fixed)==49 and len(moving)==17 and sorted((p['part_id'],p['copy_index']) for p in fixed+moving)==sorted(ids)
rectangles=[];fixed_records=[]
for row in fixed:
    t=row['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    outer=[(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[row['part_id']]['geometry'][0]['outer']];polygon=Polygon(outer);xs=sorted(set(round(x,8) for x,y in outer));ys=sorted(set(round(y,8) for x,y in outer));index=ids[row['part_id'],row['copy_index']];sheet=int(row['sheet_id'].split('-')[1]);local=[]
    for x,xx in zip(xs,xs[1:]):
        for y,yy in zip(ys,ys[1:]):
            if polygon.contains(Point((x+xx)/2,(y+yy)/2)):
                b=[math.ceil(x*1000)+2,math.ceil(y*1000)+2,math.floor(xx*1000)-2,math.floor(yy*1000)-2];assert b[0]<b[2] and b[1]<b[3] and polygon.contains(box(*(v/1000 for v in b)))
                rid=len(rectangles);rectangles.append({'id':rid,'original_index':index,'family':row['part_id'],'sheet':sheet,'bounds_um':b});local.append(rid)
    fixed_records.append({'original_index':index,'key':[row['part_id'],row['copy_index']],'sheet':sheet,'rectangles':local,'source_placement':row})
write(OUT/'fixed49.json',fixed_records);write(OUT/'fixed-source-rectangles.json',rectangles)
movers=[{**next(p for p in originals if p['index']==ids[r['part_id'],r['copy_index']]),'prior_source_placement':r} for r in moving]
assert sorted(p['index'] for p in movers)==[20,23]+list(range(51,66));write(OUT/'mandatory17.json',movers)
variants=load(GEO/'variants.json');domains=load(GEO/'domains.json');regions=[]
for d in domains:
    if not d['allowed'] or d['variant']>=8:continue
    obstacles=[p['bounds_um'] for p in rectangles if p['sheet']==d['sheet']];forbidden,raw=coarse_regions(obstacles,variants[d['variant']]['coarse_rectangles_um'],d['bounds_um']);merged=[];latest={}
    for b in raw:
        key=(b[1],b[3]);last=latest.get(key)
        if last is not None and merged[last][2]+1==b[0]:merged[last][2]=b[2]
        else:latest[key]=len(merged);merged.append(b.copy())
    regions.append({'variant':d['variant'],'sheet':d['sheet'],'domain_um':d['bounds_um'],'forbidden_integer_boxes':forbidden,'raw_free_cells':raw,'merged_free_cells':merged})
write(OUT/'bracket-anchor-regions.json',regions)
octagon=load(MIX/'octagon.json')['vertices_um'];polys=[]
for rect in rectangles:
    b=rect['bounds_um'];points=[(x-u,y-v) for x in [b[0],b[2]] for y in [b[1],b[3]] for u,v in octagon];poly=hull(points);faces=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        nx,ny=-(b[1]-a[1]),b[0]-a[0];rhs=nx*a[0]+ny*a[1];g=math.gcd(abs(nx),abs(ny));assert rhs%g==0;faces.append([nx//g,ny//g,rhs//g])
    polys.append({'fixed_rectangle_id':rect['id'],'sheet':rect['sheet'],'vertices_um':poly,'inward_faces':faces})
write(OUT/'cog-fixed-forbidden-polygons.json',polys);table=[];covers=[]
for domain in [d for d in domains if d['variant']==12]:
    s=domain['sheet'];x0,y0,x1,y1=domain['bounds_um'];step=10000;nx=math.ceil((x1-x0)/step);ny=math.ceil((y1-y0)/step)
    assert (x1-x0)%step and (y1-y0)%step
    cells=np.array([[x0+i*step,y0+j*step,min(x1,x0+(i+1)*step),min(y1,y0+(j+1)*step)] for j in range(ny) for i in range(nx)],dtype=np.int64);removed=np.full(len(cells),-1,dtype=np.int64)
    for pi,p in enumerate(polys):
        if p['sheet']!=s:continue
        ix=np.flatnonzero(removed<0);available=cells[ix];inside=np.ones(len(ix),dtype=bool)
        for a,b,c in p['inward_faces']:inside &= a*available[:,0 if a>=0 else 2]+b*available[:,1 if b>=0 else 3]>c
        removed[ix[inside]]=pi
    legal=np.flatnonzero(removed<0).tolist();table.extend([[s,k%nx,k//nx] for k in legal]);covers.append({'sheet':s,'domain_um':domain['bounds_um'],'step_um':step,'columns':nx,'rows':ny,'removing_polygon_by_cell':removed.tolist(),'legal_grid_indices':legal})
write(OUT/'cog-cell-covers.json',covers);write(OUT/'cog-cell-table.json',table)
short_counts={f:sum(p['sheet']==1 and p['key'][0]==f for p in fixed_records) for f in ['frame','bracket','insert']};assert short_counts=={'frame':0,'bracket':4,'insert':2}
allocations=[p['short_counts'] for p in load(GEO/'allowed-allocations.json') if p['short_counts'][1]==2 and 4<=p['short_counts'][0]<=6];write(OUT/'short-count-rows.json',allocations)
shutil.copyfile(MIX/'forbidden-polygons.json',OUT/'bracket-cog-forbidden-polygons.json');shutil.copyfile(PAIR/'pair-separation-polygon.json',OUT/'cog-pair-separation-polygon.json')
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'corrected_source_valid_fixed_originals':49,'mandatory_movers':17,'fixed_source_rectangles':len(rectangles),'fixed_cog_forbidden_polygons':len(polys),
    'bracket_variant_sheet_domains':len(regions),'bracket_raw_anchor_cells':sum(len(p['raw_free_cells']) for p in regions),'bracket_merged_anchor_cells':sum(len(p['merged_free_cells']) for p in regions),
    'cog_allowed_grid_rows':len(table),'cog_allowed_cells_by_sheet':[len(p['legal_grid_indices']) for p in covers],'all_angle_count_rows':allocations,'fresh_corrected_pose_geometry':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
