"""Independent immutable-prefix and every appended support-constraint reader."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-flat-edge-joint-model-20261026';OLD=ROOT/'output/h5-corrected49-joint-model-repaired-20261026';SUP=ROOT/'output/h5-cog-flat-edge-support-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(OLD/'model-audit/checks.json')['passed'] and load(SUP/'audit/checks.json')['passed'] and load(SUP/'mask/audit/checks.json')['passed']
old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model.pb').read_bytes());p=cp_model_pb2.CpModelProto();p.ParseFromString((BASE/'model.pb').read_bytes());prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(p);del prefix.variables[15797:];del prefix.constraints[17412:];assert prefix.SerializeToString()==old.SerializeToString()
mp=load(OLD/'mapping.json');new=load(BASE/'mapping.json');assert new['base_mapping']==mp;table=load(SUP/'mask/cog-cell-table.json');ci=17412;vi=15797
assert len(new['support_mask_tables'])==15
for cg,r in zip(mp['cogs'],new['support_mask_tables']):
    assert r=={'original_index':cg['original_index'],'constraint':ci};ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='table' and not ct.enforcement_literal and not ct.table.negated and not ct.table.vars and len(ct.table.exprs)==3
    for v,e in zip([cg['sheet']]+cg['grid'],ct.table.exprs):assert list(e.vars)==[v] and list(e.coeffs)==[1] and e.offset==0
    assert list(ct.table.values)==[v for row in table for v in row];ci+=1
source={(r['variant'],r['component']):r['strict_forbidden_relative_center_strips_um'] for r in load(SUP/'moving-bracket-support-strips.json')};ri=0
for pair in mp['mixed_pairs']:
    bi,gi=pair['bracket'],pair['cog'];br,cg=mp['brackets'][bi],mp['cogs'][gi]
    for v in range(8):
        for component in range(3):
            for axis,(x,y,xx,yy) in enumerate(source[v,component]):
                fs=[];cts=[]
                for fi,(nx,ny,rhs) in enumerate([(1,0,x),(-1,0,-xx),(0,1,y),(0,-1,-yy)]):
                    var=p.variables[vi];assert var.name==f'support_{bi}_{gi}_{v}_{component}_{axis}_{fi}' and list(var.domain)==[0,1]
                    ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='linear' and list(ct.enforcement_literal)==[vi]
                    coeff={cg['coordinates'][0]:nx,cg['coordinates'][1]:ny,br['coordinates'][0]:-nx,br['coordinates'][1]:-ny};coeff={k:v for k,v in sorted(coeff.items()) if v}
                    assert list(ct.linear.vars)==list(coeff) and list(ct.linear.coeffs)==list(coeff.values()) and list(ct.linear.domain)==[-9223372036854775808,rhs];fs.append(vi);cts.append(ci);vi+=1;ci+=1
                ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='bool_or' and list(ct.enforcement_literal)==[pair['same_sheet'],br['variant_flags'][v]] and list(ct.bool_or.literals)==fs
                assert new['moving_support_clauses'][ri]=={'bracket':bi,'cog':gi,'variant':v,'component':component,'axis':axis,'facet_variables':fs,'facet_constraints':cts,'or_constraint':ci};ri+=1;ci+=1
assert ri==len(new['moving_support_clauses'])==1440 and vi==len(p.variables)==21557 and ci==len(p.constraints)==24627
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':vi,'constraints_verified':ci,'base15797_variables_and17412_constraints_byte_identical':True,
    'additional_fixed_source_mask_tables_verified':15,'new_mask_rows_verified':len(table),'additional_support_halfplanes_verified':5760,'additional_conditional_support_or_clauses_verified':ri,
    'fixed_source_valid_originals':49,'mandatory_movers':17,'all_mover_positions_sheets_variants_free':True,'all_real_cog_angles_retained':True,'no_hints_or_objective':True,
    'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
