"""One60-second source-support-strengthened mandatory17-mover search, without retry."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-flat-edge-joint-model-20261026';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2
    from ortools.sat.python import cp_model
    check=load(BASE/'model-audit/checks.json');assert check['passed'] and check['mandatory_movers']==17 and check['fixed_source_valid_originals']==49
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and digest(OUT/'model.pb')==check['model_sha256']
    solver=cp_model.CpSolver();params={'max_time_in_seconds':60.,'num_search_workers':4,'random_seed':0,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False,'ignore_subsolvers':['fj']}
    for k,v in params.items():
        if isinstance(v,list):getattr(solver.parameters,k).extend(v)
        else:setattr(solver.parameters,k,v)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'model_sha256':digest(OUT/'model.pb'),'maximum_calls':1,'solver_seconds':60,'shared_seconds':90,'parameters':params})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
        solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());start=time.perf_counter();status=solver.solve(model);elapsed=time.perf_counter()-start
    response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(OUT/'response.pb').write_bytes(response.SerializeToString())
    if response.solution:
        original=cp_model_pb2.CpModelProto();original.ParseFromString((OUT/'model.pb').read_bytes());write(OUT/'assignment.json',{v.name:int(value) for v,value in zip(original.variables,response.solution)})
    write(OUT/'result.json',{'status':solver.status_name(status),'returned_solve_seconds':elapsed,'solver_wall_seconds':response.wall_time,'returned_response_branches':response.num_branches,'returned_response_conflicts':response.num_conflicts,'has_solution':bool(response.solution),'solver_soft_overrun_seconds':max(0.,response.wall_time-60),'returned_soft_overrun_seconds':max(0.,elapsed-60),'solver_calls':1,'closed':True,'mandatory_movers':17,'fixed_source_valid_originals':49,'all66_originals_accounted_for':True,'source_layout_claimed':False,'full66_target_witness':False,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');start=time.perf_counter();write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':90,'solver_seconds':60,'maximum_calls':1,'retry_permitted':False})
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=max(.01,90-(time.perf_counter()-start)));(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final response; call closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
