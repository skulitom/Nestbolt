"""Append certified all-angle flat-edge geometry to the closed mandatory17 model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-corrected49-joint-model-repaired-20261026';SUP=ROOT/'output/h5-cog-flat-edge-support-20261026';OUT=ROOT/'output/h5-flat-edge-joint-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(OLD/'model-audit/checks.json')['passed'] and load(SUP/'audit/checks.json')['passed'] and load(SUP/'mask/audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
paths=[OLD/n for n in ['model.pb','mapping.json','plan.json','model-audit/checks.json','response-audit/checks.json']]+[p for p in SUP.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'retry_permitted':False,'ignore_subsolvers':['fj'],
    'method':'Append materially stronger source-derived cog/flat-edge necessities to the immutable corrected49 mandatory17 model. The old905867-branch UNKNOWN call remains closed. Preserve every old variable/domain and constraint byte for byte. Add the audited4548-row fixed-source support mask as a second table for each mandatory cog. For each bracket/cog same-sheet pair and selected bracket variant, require the relative center outside both certified support strips for every source-contained bracket component. These strips derive from actual support vertices, not filled cog convex hulls or virtual disks. All17 movers remain mandatory with free positions, sheets and bracket variants; no hints/objective or actual cog angle. Audit the entire prefix and appended constraints before one new60-second call inside90 shared seconds; no unchanged retry. A necessary assignment still requires full source/native/material checks.'})
p=cp_model_pb2.CpModelProto();p.ParseFromString((OLD/'model.pb').read_bytes());mp=load(OLD/'mapping.json');table=load(SUP/'mask/cog-cell-table.json');table_records=[]
for cg in mp['cogs']:
    ix=len(p.constraints);ct=p.constraints.add()
    for variable in [cg['sheet']]+cg['grid']:e=ct.table.exprs.add();e.vars.append(variable);e.coeffs.append(1)
    ct.table.values.extend(v for r in table for v in r);table_records.append({'original_index':cg['original_index'],'constraint':ix})
source={(r['variant'],r['component']):r['strict_forbidden_relative_center_strips_um'] for r in load(SUP/'moving-bracket-support-strips.json')};records=[]
for pair in mp['mixed_pairs']:
    bi,gi=pair['bracket'],pair['cog'];br,cg=mp['brackets'][bi],mp['cogs'][gi]
    for v in range(8):
        for component in range(3):
            for axis,(x,y,xx,yy) in enumerate(source[v,component]):
                faces=[[1,0,x],[-1,0,-xx],[0,1,y],[0,-1,-yy]];variables=[];constraints=[]
                for fi,(nx,ny,rhs) in enumerate(faces):
                    z=len(p.variables);var=p.variables.add(name=f'support_{bi}_{gi}_{v}_{component}_{axis}_{fi}');var.domain.extend([0,1]);variables.append(z)
                    coeff={cg['coordinates'][0]:nx,cg['coordinates'][1]:ny,br['coordinates'][0]:-nx,br['coordinates'][1]:-ny};coeff={k:v for k,v in sorted(coeff.items()) if v};ix=len(p.constraints);ct=p.constraints.add();ct.enforcement_literal.append(z);ct.linear.vars.extend(coeff);ct.linear.coeffs.extend(coeff.values());ct.linear.domain.extend([-9223372036854775808,rhs]);constraints.append(ix)
                ix=len(p.constraints);ct=p.constraints.add();ct.enforcement_literal.extend([pair['same_sheet'],br['variant_flags'][v]]);ct.bool_or.literals.extend(variables)
                records.append({'bracket':bi,'cog':gi,'variant':v,'component':component,'axis':axis,'facet_variables':variables,'facet_constraints':constraints,'or_constraint':ix})
assert len(p.variables)==21557 and len(p.constraints)==24627
(OUT/'model.pb').write_bytes(p.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(p),encoding='utf-8',newline='\n');model=cp_model.CpModel();assert model.proto.parse_text_format((OUT/'model.pbtxt').read_text()) and model.validate()==''
write(OUT/'mapping.json',{'base_mapping':mp,'support_mask_tables':table_records,'moving_support_clauses':records})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(p.variables),'constraints':len(p.constraints),'additional_fixed_source_mask_tables':15,'new_mask_rows':len(table),'additional_mixed_support_clauses':len(records),'additional_facet_variables':5760,
    'fixed_source_valid_originals':49,'mandatory_movers':17,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
