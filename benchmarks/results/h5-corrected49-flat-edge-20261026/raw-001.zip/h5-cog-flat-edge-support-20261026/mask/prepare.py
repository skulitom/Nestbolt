"""Tighten the corrected fixed-obstacle cog mask using certified support strips."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-flat-edge-support-20261026';OLD=ROOT/'output/h5-corrected49-joint-geometry-20261026';OUT=BASE/'mask'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
paths=[BASE/n for n in ['fixed49-support-strips.json','prior15-center-checks.json','audit/checks.json','audit/necessity-proof.json']]+[OLD/n for n in ['cog-cell-covers.json','cog-cell-table.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_calls':0,'method':'Start from the audited5100-row necessary cog cell table. Remove an additional cell only if all four corners are strictly inside one certified all-angle fixed-rectangle support strip. Preserve original excluded cells and all boundary possibilities. Store a per-original-row reason or null and the retained table. Check all15 prior cog-center canonical cells remain. This is a new source-derived geometric restriction, not a rerun of the closed17-mover model.'})
strips=load(BASE/'fixed49-support-strips.json');covers={r['sheet']:r for r in load(OLD/'cog-cell-covers.json')};table=[];reasons=[]
for sheet,i,j in load(OLD/'cog-cell-table.json'):
    c=covers[sheet];x0,y0,x1,y1=c['domain_um'];step=c['step_um'];b=[x0+i*step,y0+j*step,min(x1,x0+(i+1)*step),min(y1,y0+(j+1)*step)];reason=None
    for r in strips:
        if r['sheet']!=sheet:continue
        for axis,(a,c,d,e) in enumerate(r['strict_forbidden_strips_um']):
            if a<b[0]<=b[2]<d and c<b[1]<=b[3]<e:reason=[r['fixed_rectangle_id'],axis];break
        if reason is not None:break
    reasons.append(reason)
    if reason is None:table.append([sheet,i,j])
allowed=set(map(tuple,table));prior=[]
for p in load(BASE/'prior15-center-checks.json'):
    c=covers[p['sheet']];x0,y0,_,_=c['domain_um'];x,y=p['rounded_center_um'];key=[p['sheet'],(x-x0)//10000,(y-y0)//10000];assert tuple(key) in allowed;prior.append({'original_index':p['original_index'],'cell':key})
write(OUT/'additional-removing-strip-by-old-row.json',reasons);write(OUT/'cog-cell-table.json',table);write(OUT/'prior15-cell-checks.json',prior)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'old_rows':len(reasons),'new_rows':len(table),'additional_excluded_cells':len(reasons)-len(table),'retained_rows_by_sheet':[sum(r[0]==s for r in table) for s in [0,1]],'prior15_cells_retained':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
