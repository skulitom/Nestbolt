"""Read every added strict support-strip exclusion in the necessary cog grid."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];SUP=ROOT/'output/h5-cog-flat-edge-support-20261026';BASE=SUP/'mask';OLD=ROOT/'output/h5-corrected49-joint-geometry-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SUP/'audit/checks.json')['passed'] and load(OLD/'audit/checks.json')['passed'];old=load(OLD/'cog-cell-table.json');why=load(BASE/'additional-removing-strip-by-old-row.json');new=load(BASE/'cog-cell-table.json');covers={r['sheet']:r for r in load(OLD/'cog-cell-covers.json')};strips={r['fixed_rectangle_id']:r for r in load(SUP/'fixed49-support-strips.json')}
assert len(why)==len(old)==5100;expected=[];tests=0
for (s,i,j),reason in zip(old,why):
    if reason is None:expected.append([s,i,j]);continue
    rid,axis=reason;record=strips[rid];assert record['sheet']==s and axis in [0,1];a,b,c,d=record['strict_forbidden_strips_um'][axis];cover=covers[s];x0,y0,x1,y1=cover['domain_um'];step=cover['step_um']
    for x in [x0+i*step,min(x1,x0+(i+1)*step)]:
        for y in [y0+j*step,min(y1,y0+(j+1)*step)]:assert a<x<c and b<y<d;tests+=1
assert new==expected and len(set(map(tuple,new)))==len(new)
allowed=set(map(tuple,new));prior=load(BASE/'prior15-cell-checks.json')
for p,checked in zip(load(SUP/'prior15-center-checks.json'),prior):
    s=p['sheet'];x,y=p['rounded_center_um'];b=covers[s]['domain_um'];cell=[s,(x-b[0])//10000,(y-b[1])//10000];assert checked=={'original_index':p['original_index'],'cell':cell} and tuple(cell) in allowed
assert len(prior)==15
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'old_rows_verified':len(old),'retained_rows_verified':len(new),'additional_strict_whole_cell_exclusions':len(old)-len(new),'exact_corner_checks':tests,
    'prior15_canonical_cells_retained':True,'closed_boundary_center_coverage_preserved':True,'new_rows_by_sheet':[sum(r[0]==s for r in new) for s in [0,1]],'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
