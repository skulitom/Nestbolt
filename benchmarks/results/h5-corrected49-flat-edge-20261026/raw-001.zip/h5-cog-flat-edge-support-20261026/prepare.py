"""All-angle cog collision strips from support-point transverse bounds."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog-flat-edge-support-20261026';OLD=ROOT/'output/h5-rotation-independent-geometry-20261026';GEO=ROOT/'output/h5-corrected49-joint-geometry-20261026'
VARS=ROOT/'output/h5-allocation-geometry-20261026/variants.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
paths=[OLD/n for n in ['original-cog-proof.json','audit/checks.json','audit/necessity-proof.json']]+[GEO/n for n in ['fixed-source-rectangles.json','mandatory17.json','audit/checks.json']]+[VARS]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_calls':0,
    'method':'Use the original full-circle source cog hull support and exact vertex radii, never the hull as filled source geometry. A support vertex after rounding the center lies at axial reach at least h=h0-2 and has total radius at most R=ceil(original maximum radius)+2 micrometres. Its transverse reach is at most ceil(sqrt(R^2-h^2))=L. Thus a rectangle edge spanning the support point in its transverse direction blocks a cog sooner than the root disk alone. For every source-contained rectangle with width and height greater than both2L and R-(innerRadius-1), certify two strict-interior forbidden center strips: [left-h,bottom+L,right+h,top-L] and [left+L,bottom-h,right-L,top+h]. In the outer axial band the support vertex lies strictly inside the rectangle; in the central axial band the strictly smaller inner disk meets it. This proof covers all real rotations and both signs, with center-flooring error below sqrt(2)um. Derive fresh fixed49 strips and all bracket variants; do not open a solver. Independently verify the mathematical prerequisites and each strip, and check the preserved15 prior cog centers are not wrongly excluded by the fixed49 strips.'})
assert load(OLD/'audit/checks.json')['passed'] and load(GEO/'audit/checks.json')['passed'];proof=load(OLD/'original-cog-proof.json');vertices=[(F(*x)*1000,F(*y)*1000) for x,y in proof['centered_vertices_rational']]
r2=max(x*x+y*y for x,y in vertices);source_outer=math.isqrt(r2.numerator//r2.denominator)
if source_outer*source_outer<r2:source_outer+=1
h0=proof['all_angle_stock_support_radius_units1000'];inner=proof['quantization_safe_radius_units1000'];h=h0-2;R=source_outer+2;L=math.isqrt(R*R-h*h)
if L*L<R*R-h*h:L+=1
core=inner-1;minimum_width=R-core;assert h>inner>core>0
write(OUT/'support-proof.json',{'original_vertex_count':len(vertices),'maximum_original_radius_squared_um2':[r2.numerator,r2.denominator],'original_circumradius_upper_um':source_outer,
    'original_all_axis_support_lower_um':h0,'rounded_center_support_lower_um':h,'rounded_center_vertex_radius_upper_um':R,'support_vertex_transverse_upper_um':L,
    'source_contained_rounded_inner_radius_um':inner,'strictly_smaller_core_radius_um':core,'rectangle_minimum_axial_width_strict_um':minimum_width,'rectangle_minimum_transverse_width_strict_um':2*L,
    'proof':'For every rotated original cog and either sign of an axis, its hull support is attained by an original source vertex at axial projection at least h0 from the true center. Moving the reference to the floored center perturbs its vector by less than sqrt(2)um, so projection is greater than h0-2=h and norm is less than ceil(R0)+2=R. Its transverse coordinate has absolute value at most L since h^2+L^2>=R^2. For a center strictly inside the horizontal strip and outside the central axial band [left-core,right+core], the matching support vertex is beyond the near edge and before the far edge because rectangle width > R-core; its transverse coordinate is strictly between bottom/top because of L margins. Inside the central band, distance to the rectangle is at most core<inner, so its guaranteed source disk intersects the rectangle interior. Swap axes for the vertical strip. A source vertex strictly inside a source-contained rectangle implies an original filled-source collision. No convex-hull interior or virtual separation disk is substituted for source geometry.'})
def strips(b):
    x,y,xx,yy=b;assert xx-x>minimum_width and yy-y>minimum_width and xx-x>2*L and yy-y>2*L
    return [[x-h,y+L,xx+h,yy-L],[x+L,y-h,xx-L,yy+h]]
fixed=[]
for r in load(GEO/'fixed-source-rectangles.json'):fixed.append({'fixed_rectangle_id':r['id'],'original_index':r['original_index'],'sheet':r['sheet'],'source_rectangle_um':r['bounds_um'],'strict_forbidden_strips_um':strips(r['bounds_um'])})
moving=[]
for v in load(VARS):
    if v['family']=='bracket':
        for component,b in enumerate(v['coarse_rectangles_um']):moving.append({'variant':v['id'],'component':component,'source_rectangle_um':b,'strict_forbidden_relative_center_strips_um':strips(b)})
write(OUT/'fixed49-support-strips.json',fixed);write(OUT/'moving-bracket-support-strips.json',moving)
center=proof['center'];prior=[];rejected=[]
for p in load(GEO/'mandatory17.json'):
    if p['family']!='cog':continue
    row=p['prior_source_placement'];t=row['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation'];xy=[math.floor((center[0]*c-center[1]*s+tx)*1000),math.floor((center[0]*s+center[1]*c+ty)*1000)];sheet=int(row['sheet_id'].split('-')[1]);violations=[]
    for r in fixed:
        if r['sheet']!=sheet:continue
        for axis,b in enumerate(r['strict_forbidden_strips_um']):
            if b[0]<xy[0]<b[2] and b[1]<xy[1]<b[3]:violations.append([r['fixed_rectangle_id'],axis])
    prior.append({'original_index':p['index'],'sheet':sheet,'rounded_center_um':xy,'violations':violations})
    if violations:rejected.append(p['index'])
write(OUT/'prior15-center-checks.json',prior);assert not rejected,rejected
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'source_support_um':h0,'rounded_support_um':h,'rounded_vertex_radius_um':R,'transverse_support_reach_um':L,'fixed_source_rectangles':len(fixed),'fixed_forbidden_strips':2*len(fixed),
    'moving_bracket_components':len(moving),'moving_relative_forbidden_strips':2*len(moving),'prior_cog_centers_checked':len(prior),'prior_centers_wrongly_excluded':len(rejected),'all_real_rotations':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
