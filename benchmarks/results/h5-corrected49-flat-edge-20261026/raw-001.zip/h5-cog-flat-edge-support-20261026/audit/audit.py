"""Exact source/radius/support prerequisites and flat-edge strip necessity reader."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-flat-edge-support-20261026';OLD=ROOT/'output/h5-rotation-independent-geometry-20261026';GEO=ROOT/'output/h5-corrected49-joint-geometry-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(OLD/'audit/checks.json')['passed'] and load(GEO/'audit/checks.json')['passed']
proof=load(OLD/'original-cog-proof.json');v=[(F(*x)*1000,F(*y)*1000) for x,y in proof['centered_vertices_rational']];hull=[(F(*x)*1000,F(*y)*1000) for x,y in proof['convex_hull_vertices_rational']];s=load(BASE/'support-proof.json')
maximum=max(x*x+y*y for x,y in v);R0=s['original_circumradius_upper_um'];assert [maximum.numerator,maximum.denominator]==s['maximum_original_radius_squared_um2'] and (R0-1)**2<maximum<=R0**2
h0=s['original_all_axis_support_lower_um'];assert h0==proof['all_angle_stock_support_radius_units1000']==139270 and all(p in v for p in hull)
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
for a,b in zip(hull,hull[1:]+hull[:1]):
    origin=cross(a,b,(0,0));length=(b[0]-a[0])**2+(b[1]-a[1])**2;assert origin>0 and origin*origin>=h0*h0*length and all(cross(a,b,p)>=0 for p in v)
inside=False;r0=proof['original_inscribed_radius_units1000'];assert r0==109115
for a,b in zip(v,v[1:]+v[:1]):
    dx,dy=b[0]-a[0],b[1]-a[1];length=dx*dx+dy*dy;t=max(F(0),min(F(1),-(a[0]*dx+a[1]*dy)/length));point=(a[0]+t*dx,a[1]+t*dy);assert point[0]*point[0]+point[1]*point[1]>=r0*r0
    if (a[1]>0)!=(b[1]>0):
        at=a[0]+(b[0]-a[0])*(-a[1])/(b[1]-a[1])
        if at>0:inside=not inside
assert inside
R=s['rounded_center_vertex_radius_upper_um'];h=s['rounded_center_support_lower_um'];L=s['support_vertex_transverse_upper_um'];inner=s['source_contained_rounded_inner_radius_um'];core=s['strictly_smaller_core_radius_um']
assert R-R0==h0-h==r0-inner==2 and 2**2>2 and inner==proof['quantization_safe_radius_units1000'] and core==inner-1
assert (L-1)**2<R*R-h*h<=L*L and s['rectangle_minimum_axial_width_strict_um']==R-core and s['rectangle_minimum_transverse_width_strict_um']==2*L
fixed=load(BASE/'fixed49-support-strips.json');rects=load(GEO/'fixed-source-rectangles.json');moving=load(BASE/'moving-bracket-support-strips.json');variants=load(ROOT/'output/h5-allocation-geometry-20261026/variants.json');margins=[]
def check_strips(b,strips):
    x,y,xx,yy=b;w,ht=xx-x,yy-y;assert w>R-core and ht>R-core and w>2*L and ht>2*L
    assert strips==[[x-h,y+L,xx+h,yy-L],[x+L,y-h,xx-L,yy+h]]
    margins.append([w-(R-core),ht-(R-core),w-2*L,ht-2*L])
    # The outer-band support vertex fits before the far rectangle edge.
    assert x-core+R<xx and xx+core-R>x and y-core+R<yy and yy+core-R>y
    # In the central band, disk distance is bounded by core < inner.
    assert core<inner and y+L<yy-L and x+L<xx-L
assert len(fixed)==len(rects)==69
for r,p in zip(rects,fixed):
    assert p['fixed_rectangle_id']==r['id'] and p['original_index']==r['original_index'] and p['sheet']==r['sheet'] and p['source_rectangle_um']==r['bounds_um'];check_strips(r['bounds_um'],p['strict_forbidden_strips_um'])
expected=[(v['id'],i,b) for v in variants if v['family']=='bracket' for i,b in enumerate(v['coarse_rectangles_um'])];assert len(moving)==len(expected)==24
for p,(variant,component,b) in zip(moving,expected):assert p['variant']==variant and p['component']==component and p['source_rectangle_um']==b;check_strips(b,p['strict_forbidden_relative_center_strips_um'])
saved=load(BASE/'prior15-center-checks.json');movers=[p for p in load(GEO/'mandatory17.json') if p['family']=='cog'];assert len(saved)==len(movers)==15;tested=0
for p,row in zip(movers,saved):
    t=p['prior_source_placement']['transform'];assert not t['mirrored'];c,sn=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);u,w=proof['center'];tx,ty=t['translation'];xy=[math.floor((c*u-sn*w+tx)*1000),math.floor((sn*u+c*w+ty)*1000)];sheet=int(p['prior_source_placement']['sheet_id'].split('-')[1])
    assert row=={'original_index':p['index'],'sheet':sheet,'rounded_center_um':xy,'violations':[]}
    for r in fixed:
        if r['sheet']!=sheet:continue
        for a,b,c,d in r['strict_forbidden_strips_um']:assert not (a<xy[0]<c and b<xy[1]<d);tested+=1
write(OUT/'necessity-proof.json',{'all_real_rotations':True,'flooring_error_norm_squared_strictly_below':2,'source_vertex_support_lower_um':h,'source_vertex_norm_upper_um':R,'support_vertex_transverse_upper_um':L,'inner_disk_um':inner,'central_band_core_um':core,
    'argument':'The verified source convex hull contains the h0 disk and consists of original source vertices. For any rotation and signed axis, a source vertex attains projection >=h0. Center flooring changes its projection/norm by less than sqrt(2), yielding projection>h0-2=h and norm<R0+2=R, hence transverse absolute coordinate<=L. A center in a strip outer axial band therefore places this actual source vertex strictly inside the source-contained rectangle: the near edge follows from support h, the far edge from width>R-core, and both transverse edges from strict L margins. In the central axial band, distance to the rectangle is <=core<inner, so the source-contained cog disk intersects its interior. The original source polygon near a vertex strictly inside the rectangle has positive-area overlap. This holds for both signs and axes. The convex hull is used only to certify a source vertex support, never as filled source collision geometry. The checked inequalities apply to every fixed and moving rectangle listed.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_cog_vertices_verified':len(v),'source_hull_edges_verified':len(hull),'original_disk_boundary_edges_verified':len(v),'exact_original_circumradius_upper_um':R0,
    'rounded_support_um':h,'rounded_vertex_radius_um':R,'transverse_bound_um':L,'rectangle_strips_verified':2*len(margins),'fixed_rectangles_verified':len(fixed),'moving_bracket_components_verified':len(moving),
    'minimum_strict_width_margin_um':min(min(r) for r in margins),'prior_cog_centers_verified':15,'prior_center_strip_checks':tested,'prior_center_exclusions':0,'all_real_rotations_proved_without_angle_sampling':True,
    'convex_hull_not_used_as_filled_geometry':True,'virtual_separation_disk_not_used_for_mixed_collisions':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
