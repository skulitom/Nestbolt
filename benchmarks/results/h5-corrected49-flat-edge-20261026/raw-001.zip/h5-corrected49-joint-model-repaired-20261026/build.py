"""Coupled mandatory17-mover necessary model around the corrected source-valid49."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-corrected49-joint-geometry-20261026';OUT=ROOT/'output/h5-corrected49-joint-model-repaired-20261026'
VARS=ROOT/'output/h5-allocation-geometry-20261026/variants.json';DOM=ROOT/'output/h5-allocation-geometry-20261026/domains.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(GEO/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
paths=[p for p in GEO.rglob('*') if p.is_file()]+[VARS,DOM]+[ROOT/'output/h5-corrected49-joint-model-20261026'/n for n in ['build.py','plan.json','failure.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'retry_permitted':False,'ignore_subsolvers':['fj'],
    'method':'Keep the corrected49 source-valid non-cogs fixed and require all17 other originals. Each bracket selects exactly one of77 complete fixed-obstacle-free integer anchor cells across all8 variants and both sheets; linked variant/sheet flags activate source-contained coarse rectangles for bracket/bracket NoOverlap2D. Every cog has a free center, linked sheet and canonical floor-divided10mm coordinates in the complete necessary5100-row fixed-obstacle table, with exact stock bounds. Nine universal short count rows link both brackets and all15 cogs. Every cog pair on the same sheet must satisfy the audited64-facet necessary center separation; each bracket/cog pair sharing a sheet must avoid each of the three source-contained rectangle/octagon Minkowski polygons for its selected variant. Sheet equality is fully reified. Copy ordering applies only among the two freely movable brackets and among all15 freely movable identical cogs. No hint, objective, fixed cog center or actual cog angle. Independently read all serialized variables and constraints before one60-second solve within90 shared seconds. The grid mask is a necessary outer cover; any assignment still needs exact fixed-source/mixed and original-ring angle readback. No unchanged-model retry and no66-part witness claim from a necessary assignment.'})
model=cp_model.CpModel();brackets=[];cogs=[];bvars=[];cvars=[];regions=load(GEO/'bracket-anchor-regions.json');cells=[{'variant':r['variant'],'sheet':r['sheet'],'bounds_um':b} for r in regions for b in r['merged_free_cells']];assert len(cells)==77
for oid in [20,23]:
    x=model.new_int_var(min(c['bounds_um'][0] for c in cells),max(c['bounds_um'][2] for c in cells),f'br_{oid}_x');y=model.new_int_var(min(c['bounds_um'][1] for c in cells),max(c['bounds_um'][3] for c in cells),f'br_{oid}_y');sheet=model.new_bool_var(f'br_{oid}_sheet');key=model.new_int_var(0,8000000,f'br_{oid}_key')
    vs=[model.new_bool_var(f'br_{oid}_variant_{v}') for v in range(8)];options={(v,s):model.new_bool_var(f'br_{oid}_option_{v}_{s}') for v in range(8) for s in range(2)};choices=[model.new_bool_var(f'br_{oid}_cell_{k}') for k in range(len(cells))]
    exact=model.add_exactly_one(choices);saved=[]
    for k,(cell,z) in enumerate(zip(cells,choices)):
        b=cell['bounds_um'];cts=[model.add(x>=b[0]),model.add(y>=b[1]),model.add(x<=b[2]),model.add(y<=b[3])]
        for ct in cts:ct.only_enforce_if(z)
        saved.append({**cell,'selector':z.index,'bounds_constraints':[ct.index for ct in cts]})
    variant_cts=[model.add(vs[v]==options[v,0]+options[v,1]).index for v in range(8)];option_records=[]
    for (v,s),z in options.items():ct=model.add(z==sum(choices[k] for k,c in enumerate(cells) if (c['variant'],c['sheet'])==(v,s)));option_records.append({'variant':v,'sheet':s,'selector':z.index,'link_constraint':ct.index})
    sc=model.add(sheet==sum(z for (v,s),z in options.items() if s==1));kc=model.add(key==y+4000000*sheet)
    brackets.append({'original_index':oid,'coordinates':[x.index,y.index],'sheet':sheet.index,'key':key.index,'variant_flags':[v.index for v in vs],'options':option_records,'cells':saved,'exactly_one_constraint':exact.index,'variant_constraints':variant_cts,'sheet_constraint':sc.index,'key_constraint':kc.index})
    bvars.append({'xy':[x,y],'sheet':sheet,'key':key,'variants':vs,'options':options})
br_order=model.add(bvars[0]['key']<=bvars[1]['key']).index
domains={d['sheet']:d['bounds_um'] for d in load(DOM) if d['variant']==12};table=load(GEO/'cog-cell-table.json');x0,y0,x1,y1=domains[0];assert domains[1][0]==x0 and domains[1][1]==y0 and domains[1][2]==x1
for oid in range(51,66):
    x=model.new_int_var(x0,x1,f'cog_{oid}_x');y=model.new_int_var(y0,y1,f'cog_{oid}_y');s=model.new_bool_var(f'cog_{oid}_sheet');gx=model.new_int_var(0,(x1-x0)//10000,f'cog_{oid}_gx');gy=model.new_int_var(0,(y1-y0)//10000,f'cog_{oid}_gy');key=model.new_int_var(0,8000000,f'cog_{oid}_key')
    divs=[model.add_division_equality(gx,x-x0,10000).index,model.add_division_equality(gy,y-y0,10000).index];kc=model.add(key==y+4000000*s);stock=model.add(y<=domains[1][3]).only_enforce_if(s);tc=model.add_allowed_assignments([s,gx,gy],table)
    cogs.append({'original_index':oid,'coordinates':[x.index,y.index],'sheet':s.index,'grid':[gx.index,gy.index],'key':key.index,'division_constraints':divs,'key_constraint':kc.index,'short_stock_constraint':stock.index,'cell_table_constraint':tc.index});cvars.append({'xy':[x,y],'sheet':s,'key':key})
cg_orders=[model.add(cvars[i]['key']<=cvars[i+1]['key']).index for i in range(14)]
bs=model.new_int_var(4,6,'short_brackets');cs=model.new_int_var(0,15,'short_cogs');bc=model.add(bs==4+sum(p['sheet'] for p in bvars));cc=model.add(cs==sum(p['sheet'] for p in cvars));count_table=model.add_allowed_assignments([bs,cs],[[b,c] for b,i,c in load(GEO/'short-count-rows.json')])
rects=[];by_sheet=[[],[]];variants=load(VARS)
for br,bv in zip(brackets,bvars):
    for option in br['options']:
        v,s=option['variant'],option['sheet'];z=bv['options'][v,s]
        for component,b in enumerate(variants[v]['coarse_rectangles_um']):
            k=len(rects);ix=model.new_optional_fixed_size_interval_var(bv['xy'][0]+b[0],b[2]-b[0],z,f'brrect_{k}_x');iy=model.new_optional_fixed_size_interval_var(bv['xy'][1]+b[1],b[3]-b[1],z,f'brrect_{k}_y')
            rects.append({'original_index':br['original_index'],'variant':v,'sheet':s,'component':component,'presence':z.index,'bounds_um':b,'intervals':[ix.index,iy.index]});by_sheet[s].append([ix,iy])
no_overlap=[model.add_no_overlap_2d([r[0] for r in rows],[r[1] for r in rows]).index for rows in by_sheet]
def same_sheet(a,b,name):
    z=model.new_bool_var(name);eq=model.add(a['sheet']==b['sheet']).only_enforce_if(z);ne=model.add(a['sheet']!=b['sheet']).only_enforce_if(z.Not());return z,[eq.index,ne.index]
def outside(a,b,faces,when,name):
    zs=[];cts=[]
    for fi,(nx,ny,rhs) in enumerate(faces):
        z=model.new_bool_var(f'{name}_face_{fi}');zs.append(z);cts.append(model.add(nx*(b['xy'][0]-a['xy'][0])+ny*(b['xy'][1]-a['xy'][1])<=rhs).only_enforce_if(z).index)
    oc=model.add_bool_or(zs);oc.only_enforce_if(when);return {'facet_variables':[z.index for z in zs],'facet_constraints':cts,'or_constraint':oc.index}
cg_pairs=[];pair_faces=load(GEO/'cog-pair-separation-polygon.json')['inward_faces']
for i,j in combinations(range(15),2):
    same,links=same_sheet(cvars[i],cvars[j],f'cg_same_{i}_{j}');clause=outside(cvars[i],cvars[j],pair_faces,[same],f'cgpair_{i}_{j}')
    cg_pairs.append({'cogs':[i,j],'same_sheet':same.index,'same_sheet_constraints':links,'clause':clause})
mixed=[];polys={(p['variant'],p['component']):p['inward_faces'] for p in load(GEO/'bracket-cog-forbidden-polygons.json')}
for bi,bv in enumerate(bvars):
    for ci,cv in enumerate(cvars):
        same,links=same_sheet(bv,cv,f'mixed_same_{bi}_{ci}');clauses=[]
        for v in range(8):
            for component in range(3):clauses.append({'variant':v,'component':component,**outside(bv,cv,polys[v,component],[same,bv['variants'][v]],f'mixed_{bi}_{ci}_{v}_{component}')})
        mixed.append({'bracket':bi,'cog':ci,'same_sheet':same.index,'same_sheet_constraints':links,'clauses':clauses})
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'brackets':brackets,'bracket_copy_order':br_order,'cogs':cogs,'cog_copy_orders':cg_orders,'counts':{'variables':[bs.index,cs.index],'links':[bc.index,cc.index],'table':count_table.index},'bracket_rectangles':rects,'bracket_no_overlap':no_overlap,'cog_pairs':cg_pairs,'mixed_pairs':mixed})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'fixed_source_valid_originals':49,'mandatory_movers':17,'bracket_cell_choices':154,'bracket_optional_rectangles':96,'cog_grid_tables':15,'cog_pair_clauses':105,'mixed_pair_variant_component_clauses':720,'fully_reified_sheet_equalities':135,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
