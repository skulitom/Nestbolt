"""Verify the closed response and every assigned necessary constraint, if present."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
from itertools import combinations
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-corrected49-joint-model-repaired-20261026';SEARCH=BASE/'search';GEO=ROOT/'output/h5-corrected49-joint-geometry-20261026';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
modelcheck=load(BASE/'model-audit/checks.json');assert modelcheck['passed'] and modelcheck['mandatory_movers']==17 and modelcheck['fixed_source_valid_originals']==49
process=load(SEARCH/'process.json');result=load(SEARCH/'result.json');opened=load(SEARCH/'opened.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<90 and result['closed'] and result['solver_calls']==1 and opened['maximum_calls']==1
assert digest(SEARCH/'model.pb')==digest(BASE/'model.pb')==modelcheck['model_sha256']==opened['model_sha256']
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes());status=cp_model_pb2.CpSolverStatus.Name(response.status);assert status==result['status'] and status in ['UNKNOWN','INFEASIBLE','FEASIBLE','OPTIMAL']
assert response.wall_time==result['solver_wall_seconds'] and response.num_branches==result['returned_response_branches'] and response.num_conflicts==result['returned_response_conflicts'] and bool(response.solution)==result['has_solution']
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(encoding='utf-8'),sat_parameters_pb2.SatParameters());assert params.max_time_in_seconds==60 and params.num_search_workers==4 and list(params.ignore_subsolvers)==['fj']
log=(SEARCH/'solver.log').read_text(encoding='utf-8');assert f'status: {status}' in log;printed=Decimal(re.search(r'^walltime: ([0-9.e+-]+)$',log,re.M).group(1));assert abs(printed-Decimal(str(response.wall_time)))<=Decimal(5).scaleb(printed.as_tuple().exponent-1)+Decimal('1e-12')
model=cp_model_pb2.CpModelProto();model.ParseFromString((BASE/'model.pb').read_bytes());mp=load(BASE/'mapping.json');checked=selected_intervals=pair_checks=0;poses=None;allocation=None
if response.solution:
    sol=list(response.solution);assert len(sol)==len(model.variables)==15797
    for variable,value in zip(model.variables,sol):assert any(a<=value<=b for a,b in zip(variable.domain[::2],variable.domain[1::2]))
    def expr(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
    def lit(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
    def active(ct):return all(lit(v) for v in ct.enforcement_literal)
    intervals={i:(expr(ct.interval.start),expr(ct.interval.end),expr(ct.interval.size),active(ct)) for i,ct in enumerate(model.constraints) if ct.WhichOneof('constraint')=='interval'};selected_intervals=sum(r[3] for r in intervals.values())
    for i,ct in enumerate(model.constraints):
        checked+=1
        if not active(ct):continue
        kind=ct.WhichOneof('constraint')
        if kind=='linear':
            value=sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs));assert any(a<=value<=b for a,b in zip(ct.linear.domain[::2],ct.linear.domain[1::2]))
        elif kind=='bool_or':assert any(lit(v) for v in ct.bool_or.literals)
        elif kind=='exactly_one':assert sum(lit(v) for v in ct.exactly_one.literals)==1
        elif kind=='int_div':
            a,b=map(expr,ct.int_div.exprs);assert a>=0 and b>0 and expr(ct.int_div.target)==a//b
        elif kind=='table':
            assert not ct.table.negated;value=tuple(expr(e) for e in ct.table.exprs);width=len(value);assert value in {tuple(ct.table.values[j:j+width]) for j in range(0,len(ct.table.values),width)}
        elif kind=='interval':a,b,size,on=intervals[i];assert a+size==b and size>0 and on
        elif kind=='no_overlap_2d':
            rects=[]
            for x,y in zip(ct.no_overlap_2d.x_intervals,ct.no_overlap_2d.y_intervals):
                assert intervals[x][3]==intervals[y][3]
                if intervals[x][3]:rects.append((*intervals[x][:2],*intervals[y][:2]))
            for a,b in combinations(rects,2):assert a[1]<=b[0] or b[1]<=a[0] or a[3]<=b[2] or b[3]<=a[2];pair_checks+=1
        else:raise AssertionError(kind)
    assert load(SEARCH/'assignment.json')=={v.name:value for v,value in zip(model.variables,sol)}
    originals={r['index']:r for r in load(GEO/'mandatory17.json')};poses=[];allocation={'bracket':[0,0],'cog':[0,0]}
    for br in mp['brackets']:
        chosen=[c for c in br['cells'] if sol[c['selector']]];assert len(chosen)==1;c=chosen[0];assert sol[br['variant_flags'][c['variant']]] and sol[br['sheet']]==c['sheet']
        poses.append({'original_index':br['original_index'],'family':'bracket','copy_index':originals[br['original_index']]['copy_index'],'sheet':c['sheet'],'variant':c['variant'],'anchor_um':[sol[v] for v in br['coordinates']],'source_validated':False});allocation['bracket'][c['sheet']]+=1
    for cg in mp['cogs']:
        s=sol[cg['sheet']];poses.append({'original_index':cg['original_index'],'family':'cog','copy_index':originals[cg['original_index']]['copy_index'],'sheet':s,'variant':12,'anchor_um':[sol[v] for v in cg['coordinates']],'source_angle_unselected':True,'source_validated':False});allocation['cog'][s]+=1
    assert sorted(p['original_index'] for p in poses)==sorted(originals);write(OUT/'mandatory17-necessary-poses.json',poses);write(OUT/'allocation.json',allocation)
else:assert not (SEARCH/'assignment.json').exists()
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':status,'closed':True,'solver_calls':1,'solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],
    'solver_soft_overrun_seconds':result['solver_soft_overrun_seconds'],'returned_soft_overrun_seconds':result['returned_soft_overrun_seconds'],'branches':response.num_branches,'conflicts':response.num_conflicts,
    'search_started':'Starting search at' in log,'fj_excluded_in_parameters':True,'fj_excluded_in_search_log':'1 ignored subsolver: [fj]' in log,'fixed_source_valid_originals':49,'mandatory_movers':17,
    'has_necessary_assignment':bool(response.solution),'assignment_constraints_verified':checked,'active_optional_intervals_verified':selected_intervals,'bracket_rectangle_pairs_verified':pair_checks,'mover_allocation':allocation,
    'fixed49_subset_excluded':status=='INFEASIBLE','unrestricted_job_exclusion_claimed':False,'actual_cog_angles_selected':False,'full66_source_validated':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
