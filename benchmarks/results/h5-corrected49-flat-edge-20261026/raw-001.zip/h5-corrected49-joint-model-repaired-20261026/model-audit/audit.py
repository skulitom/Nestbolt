"""Complete independent serialized reader for the mandatory17-mover model."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-corrected49-joint-model-repaired-20261026';GEO=ROOT/'output/h5-corrected49-joint-geometry-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEO/'audit/checks.json')['passed'];p=cp_model_pb2.CpModelProto();p.ParseFromString((BASE/'model.pb').read_bytes());mp=load(BASE/'mapping.json')
assert not p.HasField('objective') and not p.HasField('floating_point_objective') and not p.solution_hint.vars
vi=ci=0;LOW=-9223372036854775808;HIGH=9223372036854775807
def variable(ix,name,domain):
    global vi
    assert ix==vi;v=p.variables[vi];assert v.name==name and list(v.domain)==domain;vi+=1
def linear(ix,coeff,domain,when=[]):
    global ci
    assert ix==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='linear' and list(ct.enforcement_literal)==when
    assert dict(zip(ct.linear.vars,ct.linear.coeffs))=={k:v for k,v in coeff.items() if v} and list(ct.linear.domain)==domain;ci+=1
def expression(e,coeff,offset=0):assert dict(zip(e.vars,e.coeffs))==coeff and e.offset==offset
def table(ix,variables,rows):
    global ci
    assert ix==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='table' and not ct.enforcement_literal and not ct.table.negated and not ct.table.vars
    assert len(ct.table.exprs)==len(variables)
    for e,v in zip(ct.table.exprs,variables):expression(e,{v:1})
    assert list(ct.table.values)==[v for row in rows for v in row];ci+=1
regions=load(GEO/'bracket-anchor-regions.json');cells=[{'variant':r['variant'],'sheet':r['sheet'],'bounds_um':b} for r in regions for b in r['merged_free_cells']];assert len(cells)==77
assert len(mp['brackets'])==2
for oid,br in zip([20,23],mp['brackets']):
    assert br['original_index']==oid;x,y=br['coordinates'];sheet,key=br['sheet'],br['key']
    variable(x,f'br_{oid}_x',[min(c['bounds_um'][0] for c in cells),max(c['bounds_um'][2] for c in cells)])
    variable(y,f'br_{oid}_y',[min(c['bounds_um'][1] for c in cells),max(c['bounds_um'][3] for c in cells)])
    variable(sheet,f'br_{oid}_sheet',[0,1]);variable(key,f'br_{oid}_key',[0,8000000])
    assert len(br['variant_flags'])==8 and len(br['options'])==16 and len(br['cells'])==77
    for v,z in enumerate(br['variant_flags']):variable(z,f'br_{oid}_variant_{v}',[0,1])
    for (v,s),o in zip([(v,s) for v in range(8) for s in range(2)],br['options']):assert (o['variant'],o['sheet'])==(v,s);variable(o['selector'],f'br_{oid}_option_{v}_{s}',[0,1])
    for k,c in enumerate(br['cells']):variable(c['selector'],f'br_{oid}_cell_{k}',[0,1])
    assert br['exactly_one_constraint']==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='exactly_one' and not ct.enforcement_literal and list(ct.exactly_one.literals)==[c['selector'] for c in br['cells']];ci+=1
    for c,r in zip(cells,br['cells']):
        assert {k:r[k] for k in c}==c;b=c['bounds_um'];z=r['selector'];indices=r['bounds_constraints']
        assert len(indices)==4;linear(indices[0],{x:1},[b[0],HIGH],[z]);linear(indices[1],{y:1},[b[1],HIGH],[z]);linear(indices[2],{x:1},[LOW,b[2]],[z]);linear(indices[3],{y:1},[LOW,b[3]],[z])
    for v,ix in enumerate(br['variant_constraints']):linear(ix,{br['variant_flags'][v]:1,br['options'][2*v]['selector']:-1,br['options'][2*v+1]['selector']:-1},[0,0])
    for o in br['options']:
        coeff={o['selector']:1};coeff.update({c['selector']:-1 for c in br['cells'] if (c['variant'],c['sheet'])==(o['variant'],o['sheet'])});linear(o['link_constraint'],coeff,[0,0])
    coeff={sheet:1};coeff.update({o['selector']:-1 for o in br['options'] if o['sheet']==1});linear(br['sheet_constraint'],coeff,[0,0]);linear(br['key_constraint'],{key:1,y:-1,sheet:-4000000},[0,0])
linear(mp['bracket_copy_order'],{mp['brackets'][0]['key']:1,mp['brackets'][1]['key']:-1},[LOW,0])
domains={d['sheet']:d['bounds_um'] for d in load(ROOT/'output/h5-allocation-geometry-20261026/domains.json') if d['variant']==12};x0,y0,x1,y1=domains[0];rows=load(GEO/'cog-cell-table.json')
assert len(mp['cogs'])==15
for oid,cg in zip(range(51,66),mp['cogs']):
    assert cg['original_index']==oid;x,y=cg['coordinates'];s=cg['sheet'];gx,gy=cg['grid'];key=cg['key']
    variable(x,f'cog_{oid}_x',[x0,x1]);variable(y,f'cog_{oid}_y',[y0,y1]);variable(s,f'cog_{oid}_sheet',[0,1]);variable(gx,f'cog_{oid}_gx',[0,(x1-x0)//10000]);variable(gy,f'cog_{oid}_gy',[0,(y1-y0)//10000]);variable(key,f'cog_{oid}_key',[0,8000000])
    for ix,target,v,offset in zip(cg['division_constraints'],[gx,gy],[x,y],[x0,y0]):
        assert ix==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='int_div' and not ct.enforcement_literal and len(ct.int_div.exprs)==2
        expression(ct.int_div.target,{target:1});expression(ct.int_div.exprs[0],{v:1},-offset);expression(ct.int_div.exprs[1],{},10000);ci+=1
    linear(cg['key_constraint'],{key:1,y:-1,s:-4000000},[0,0]);linear(cg['short_stock_constraint'],{y:1},[LOW,domains[1][3]],[s]);table(cg['cell_table_constraint'],[s,gx,gy],rows)
for i,ix in enumerate(mp['cog_copy_orders']):linear(ix,{mp['cogs'][i]['key']:1,mp['cogs'][i+1]['key']:-1},[LOW,0])
assert len(mp['cog_copy_orders'])==14
counts=mp['counts'];bs,cs=counts['variables'];variable(bs,'short_brackets',[4,6]);variable(cs,'short_cogs',[0,15]);linear(counts['links'][0],{bs:1,**{b['sheet']:-1 for b in mp['brackets']}},[4,4]);linear(counts['links'][1],{cs:1,**{c['sheet']:-1 for c in mp['cogs']}},[0,0]);table(counts['table'],[bs,cs],[[b,c] for b,i,c in load(GEO/'short-count-rows.json')])
variants=load(ROOT/'output/h5-allocation-geometry-20261026/variants.json');ri=0;by_sheet=[[],[]]
for br in mp['brackets']:
    for o in br['options']:
        v,s=o['variant'],o['sheet'];z=o['selector']
        for component,b in enumerate(variants[v]['coarse_rectangles_um']):
            r=mp['bracket_rectangles'][ri];assert r=={'original_index':br['original_index'],'variant':v,'sheet':s,'component':component,'presence':z,'bounds_um':b,'intervals':[ci,ci+1]};intervals=[ci,ci+1]
            for axis in [0,1]:
                ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='interval' and list(ct.enforcement_literal)==[z] and ct.name==f'brrect_{ri}_{"xy"[axis]}'
                expression(ct.interval.start,{br['coordinates'][axis]:1},b[axis]);expression(ct.interval.size,{},b[axis+2]-b[axis]);expression(ct.interval.end,{br['coordinates'][axis]:1},b[axis+2]);ci+=1
            by_sheet[s].append(intervals);ri+=1
assert ri==len(mp['bracket_rectangles'])==96
for s,ix in enumerate(mp['bracket_no_overlap']):
    assert ix==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='no_overlap_2d' and not ct.enforcement_literal
    assert list(ct.no_overlap_2d.x_intervals)==[r[0] for r in by_sheet[s]] and list(ct.no_overlap_2d.y_intervals)==[r[1] for r in by_sheet[s]];ci+=1
def same_sheet(record,a,b,name):
    z=record['same_sheet'];variable(z,name,[0,1]);linear(record['same_sheet_constraints'][0],{a['sheet']:1,b['sheet']:-1},[0,0],[z]);linear(record['same_sheet_constraints'][1],{a['sheet']:1,b['sheet']:-1},[LOW,-1,1,HIGH],[-z-1]);return z
def outside(record,a,b,faces,when,name):
    global ci
    assert len(record['facet_variables'])==len(record['facet_constraints'])==len(faces)
    for fi,((nx,ny,rhs),z,ix) in enumerate(zip(faces,record['facet_variables'],record['facet_constraints'])):
        variable(z,f'{name}_face_{fi}',[0,1]);x,y=a['coordinates'];u,v=b['coordinates'];linear(ix,{u:nx,v:ny,x:-nx,y:-ny},[LOW,rhs],[z])
    assert record['or_constraint']==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='bool_or' and list(ct.enforcement_literal)==when and list(ct.bool_or.literals)==record['facet_variables'];ci+=1
pair_faces=load(GEO/'cog-pair-separation-polygon.json')['inward_faces'];assert len(mp['cog_pairs'])==105
for r,(i,j) in zip(mp['cog_pairs'],combinations(range(15),2)):
    assert r['cogs']==[i,j];a,b=mp['cogs'][i],mp['cogs'][j];same=same_sheet(r,a,b,f'cg_same_{i}_{j}');outside(r['clause'],a,b,pair_faces,[same],f'cgpair_{i}_{j}')
polys={(p['variant'],p['component']):p['inward_faces'] for p in load(GEO/'bracket-cog-forbidden-polygons.json')};assert len(mp['mixed_pairs'])==30
for r,(bi,gi) in zip(mp['mixed_pairs'],[(bi,gi) for bi in range(2) for gi in range(15)]):
    assert (r['bracket'],r['cog'])==(bi,gi);a,b=mp['brackets'][bi],mp['cogs'][gi];same=same_sheet(r,a,b,f'mixed_same_{bi}_{gi}');assert len(r['clauses'])==24
    for clause,(v,c) in zip(r['clauses'],[(v,c) for v in range(8) for c in range(3)]):
        assert (clause['variant'],clause['component'])==(v,c);outside(clause,a,b,polys[v,c],[same,a['variant_flags'][v]],f'mixed_{bi}_{gi}_{v}_{c}')
assert vi==len(p.variables)==15797 and ci==len(p.constraints)==17412
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':vi,'constraints_verified':ci,'fixed_source_valid_originals':49,'mandatory_movers':17,'all66_original_identities_accounted_for':True,
    'bracket_exactly_one_cell_choices_verified':154,'bracket_variants_and_sheets_linked':True,'cog_grid_divisions_verified':30,'cog_complete_cell_tables_verified':15,'linked_count_rows_verified':9,
    'optional_bracket_rectangles_verified':96,'bracket_no_overlap_constraints_verified':2,'fully_reified_sheet_equalities_verified':135,'cog_pair_clauses_verified':105,'mixed_variant_component_clauses_verified':720,
    'all_mover_coordinates_free':True,'no_hints_or_objective':True,'all_real_cog_rotations_retained':True,'source_readback_still_required':True,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
