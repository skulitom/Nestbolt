"""Check the diagnostic reader against existing authored tests and malformed traces."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-mixed-stage-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_mixed_stage as runner
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_passed']
out=probe/'authored-trace-reader';out.mkdir(exist_ok=False)
target=Path(load(probe/'preparation.json')['target'])
binaries=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
binary=binaries[0];rows=[];all_traces=[]
for name in ['balanced_pair_moves_two_incoming_and_three_returns',
             'balanced_pair_without_return_room_preserves_incumbent',
             'balanced_pair_disabled_or_expired_preserves_incumbent',
             'return_frame_keeps_incumbent_when_roundoff_increases_charged_material',
             'productive_exchange_rejects_unchanged_inventory_without_material_gain',
             'productive_exchange_keeps_same_inventory_when_material_decreases',
             'mixed_pair_moves_different_parts_and_three_returns',
             'mixed_pair_preserves_a_frozen_sheet',
             'mixed_pair_failed_return_room_preserves_incumbent']:
    command=[str(binary),'--exact','sheets::vstrip::exchange::tests::'+name,'--nocapture']
    result=subprocess.run(command,cwd=probe/'workspace',capture_output=True,timeout=120)
    (out/(name+'-stdout.log')).write_bytes(result.stdout);(out/(name+'-stderr.log')).write_bytes(result.stderr)
    row={'test':name,'command':command,'exit_code':result.returncode};rows.append(row)
    assert result.returncode==0,(name,result.stderr.decode(errors='replace'))
    traces=runner.parse_log(result.stderr.decode())
    summary=runner.check_traces(traces);all_traces+=traces
    row.update({k:v for k,v in summary.items() if k not in ['traces','attempt_rows']})
    runner.write(out/'progress.json',rows)
summary=runner.check_traces(all_traces)
assert summary['paired_accepted']>=4
assert any(a['neutral_inventory'] and a['outcome']=='accepted' and a['before_material']-a['after_material']>99.9 for a in summary['attempt_rows'])
assert any(a['outcome']=='neutral_inventory_rejected' for a in summary['attempt_rows'])
assert any(a['outcome']=='source_repair_failed' for a in summary['attempt_rows'])
assert any(a['outcome']=='material_guard_failed' and a['after_material']>a['before_material'] for a in summary['attempt_rows'])
accepted=next(t for t in all_traces if any(a['outcome']=='accepted' for a in t['attempts']))
def modify_attempt(t,**values):
    next(a for a in t['attempts'] if a['outcome']=='accepted').update(values)
def accepted_proposal(t):
    return t['proposals'][next(a for a in t['attempts'] if a['outcome']=='accepted')['proposal_index']]
def rejects(name,mutate,stats=None):
    t=copy.deepcopy(accepted);mutate(t)
    try:runner.check_traces([t],stats)
    except AssertionError:return name
    raise AssertionError('Reader accepted '+name)
rejected=[
    rejects('accepted material increase',lambda t:modify_attempt(t,after_material=t['before_material']+1)),
    rejects('accepted unresolved source repair',lambda t:modify_attempt(t,source_loss=1)),
    rejects('out-of-range proposal index',lambda t:modify_attempt(t,proposal_index=len(t['proposals']))),
    rejects('incomplete paired obstruction set',lambda t:accepted_proposal(t).update(blockers=4)),
    rejects('nonfinite last extent',lambda t:modify_attempt(t,after_last_extent=float('nan'))),
    rejects('unavailable incoming original item',lambda t:accepted_proposal(t)['incoming_ids'].__setitem__(1,999999)),
    rejects('inconsistent attempt counters',lambda t:None,{'directed_exchange_attempts':999999}),
    rejects('unfinished observation',lambda t:modify_attempt(t,outcome='unfinished')),
]
neutral_trace=next(t for t in all_traces if any(a['outcome']=='neutral_inventory_rejected' for a in t['attempts']))
def rejects_trace(name,mutate):
    t=copy.deepcopy(neutral_trace);mutate(t)
    try:runner.check_traces([t])
    except AssertionError:return name
    raise AssertionError('Reader accepted '+name)
def neutral_attempt(t):return next(a for a in t['attempts'] if a['outcome']=='neutral_inventory_rejected')
def neutral_proposal(t):return t['proposals'][neutral_attempt(t)['proposal_index']]
rejected += [
    rejects('negative receiver duration',lambda t:modify_attempt(t,receiver_elapsed=-1)),
    rejects('nonfinite source allowance',lambda t:modify_attempt(t,source_remaining=float('nan'))),
    rejects('nonexistent pair choice',lambda t:t['pair_choices'].append([999999,999999])),
    rejects('incorrect phase allocation',lambda t:t.update(pair_phase_remaining=t['pair_phase_remaining']+1)),
    rejects_trace('neutral equal-material accepted',lambda t:neutral_attempt(t).update(outcome='accepted')),
    rejects_trace('neutral rejection with different returned inventory',lambda t:neutral_proposal(t)['returned_ids'].__setitem__(0,999999)),
]
assert summary['mixed_accepted']>=5
assert summary['mixed_attempts']>=summary['mixed_accepted']
mixed_trace=next(t for t in all_traces if any(len(set(g['incoming_ids']))==2 for g in t['generations']))
def rejects_generation(name,mutate):
    t=copy.deepcopy(mixed_trace);mutate(t['generations'][0])
    try:runner.check_traces([t])
    except AssertionError:return name
    raise AssertionError('Reader accepted '+name)
rejected += [
    rejects_generation('sample partition mismatch',lambda g:g.update(seen=g['seen']+1)),
    rejects_generation('negative sampling count',lambda g:g.update(boundary=-1)),
    rejects_generation('unrecorded deadline truncation',lambda g:g.update(deadline_reached=not g['deadline_reached'])),
    rejects_generation('impossible retained count',lambda g:g.update(retained=7)),
    rejects_generation('unavailable generated pair',lambda g:g.update(incoming_ids=[999999,999999])),
    rejects_generation('nonfinite generation time',lambda g:g.update(elapsed=float('nan'))),
]
try:runner.parse_log('MIXED_GENERATION {}')
except AssertionError:rejected.append('orphaned generation trace')
else:raise AssertionError('Reader accepted orphaned generation trace')
try:runner.check_traces([mixed_trace],{'mixed_exchange_attempts':999999})
except AssertionError:rejected.append('inconsistent mixed counters')
else:raise AssertionError('Reader accepted inconsistent mixed counters')
# Multiset equality retains multiplicity and ignores ordering; geometry alone
# is not used to merge distinct original item identities.
assert runner.neutral({'incoming_ids':[4,4],'returned_ids':[4,4]})
assert runner.neutral({'incoming_ids':[1,4],'returned_ids':[4,1]})
assert not runner.neutral({'incoming_ids':[4,4],'returned_ids':[4]})
assert not runner.neutral({'incoming_ids':[4,4],'returned_ids':[5,5]})
record={'all_checks_pass':True,'test_binary_sha256':digest(binary),
    'reader_sha256':digest(root/'scripts/h5_mixed_stage.py'),
    'authored_test_traces':rows,'malformed_records_rejected':rejected,
    'identity_multiset_checks':4,'mixed_accepted_observed':summary['mixed_accepted'],'strict_material_rejection_observed':True,
    'source_repair_failure_observed':True,'measured_development_searches':0,'quality_claim':False}
runner.write(out/'checks.json',record);shutil.copyfile(__file__,out/'check.py')
print(json.dumps(record))
