//! Isolated experiment: return complete actual obstruction sets while inserting
//! a last-sheet part, repair both sheets, then check the whole original job.
use super::*;
use jagua_rs::entities::Item;
use jagua_rs::geometry::geo_traits::TransformableFrom;

// Read-only diagnostic copy. Logging may perturb wall deadlines.
#[derive(Default, serde::Serialize)]
struct BalancedTrace {
    disabled_or_expired: bool,
    baseline_invalid: bool,
    before_material: Option<f64>,
    before_last_extent: Option<f32>,
    available_source_items: Vec<usize>,
    pair_choices: Vec<Vec<usize>>,
    exchange_remaining: Option<f64>,
    pair_phase_remaining: Option<f64>,
    proposals: Vec<ObservedProposal>,
    attempts: Vec<ObservedAttempt>,
}
#[derive(serde::Serialize)]
struct ObservedProposal {
    paired: bool,
    target: usize,
    incoming_ids: Vec<usize>,
    returned_ids: Vec<usize>,
    blockers: usize,
    incoming_area: f32,
    returned_area: f32,
}
#[derive(serde::Serialize)]
struct ObservedAttempt {
    proposal_index: usize,
    receiver_initial_loss: Option<f32>,
    receiver_loss: Option<f32>,
    source_initial_loss: Option<f32>,
    source_loss: Option<f32>,
    receiver_remaining: Option<f64>,
    receiver_elapsed: Option<f64>,
    source_remaining: Option<f64>,
    source_elapsed: Option<f64>,
    after_material: Option<f64>,
    after_last_extent: Option<f32>,
    outcome: &'static str,
}
impl Drop for BalancedTrace {
    fn drop(&mut self) {
        eprintln!("MIXED_DIAG {}", serde_json::to_string(self).expect("diagnostic serialization"));
    }
}

#[derive(serde::Serialize)]
struct PairGenerationTrace {
    incoming_ids: Vec<usize>,
    sample_total: usize,
    seen: usize,
    invalid_pose: usize,
    boundary: usize,
    empty: usize,
    over_three: usize,
    area_rejected: usize,
    eligible: usize,
    retained: usize,
    deadline_reached: bool,
    start_remaining: f64,
    elapsed: f64,
    #[serde(skip)]
    started: Instant,
}
impl Drop for PairGenerationTrace {
    fn drop(&mut self) {
        self.elapsed = self.started.elapsed().as_secs_f64();
        eprintln!("MIXED_GENERATION {}", serde_json::to_string(self).expect("generation serialization"));
    }
}

struct Proposal {
    victims: Vec<PItemKey>,
    incoming: DTransformation,
    blockers: usize,
    rank: usize,
    area: f32,
}

fn retain_proposal(out: &mut Vec<Proposal>, proposal: Proposal) {
    if let Some(previous) = out.iter().position(|p| p.victims == proposal.victims) {
        if out[previous].blockers <= proposal.blockers {
            return;
        }
        out.remove(previous);
    }
    out.push(proposal);
    out.sort_by(|a, b| {
        (a.blockers - a.victims.len())
            .cmp(&(b.blockers - b.victims.len()))
            .then(a.area.total_cmp(&b.area))
            .then(a.rank.cmp(&b.rank))
    });
    out.truncate(6);
}

fn proposals(
    receiver: &JLayout,
    incoming: &Item,
    rng: &mut Xoshiro256PlusPlus,
    clock: &Clock,
    until: f64,
) -> Vec<Proposal> {
    let bounds = receiver.container().outer_cd().bbox();
    let mut buffer = incoming.shape_cd().as_ref().clone();
    let mut samples = Vec::new();
    // Anchors make an actual obstruction, rather than a merely nearby part,
    // the return candidate. Align bounding-box corners after snapping rotation.
    for p in receiver.placed_items().values() {
        let dt = convert_sample_to_closest_feasible(p.d_transf(), incoming);
        buffer.transform_from(incoming.shape_cd(), &dt.compose());
        let a = buffer.bbox();
        let b = p.shape().bbox();
        let (x, y) = dt.translation();
        samples.push(
            DTransformation::new(
                dt.rotation(),
                (x + b.x_min - a.x_min, y + b.y_min - a.y_min),
            )
            .with_reflection(dt.reflected),
        );
    }
    if let Some(sampler) = UniformBBoxSampler::new(bounds, incoming, bounds) {
        samples.extend((0..128).map(|_| sampler.sample(rng)));
    }
    let mut collector = BasicHazardCollector::new();
    let mut out: Vec<Proposal> = Vec::new();
    for dt in samples {
        if clock.now() >= until {
            break;
        }
        buffer.transform_from(incoming.shape_cd(), &dt.compose());
        collector.clear();
        receiver
            .cde()
            .collect_poly_collisions(&buffer, &NoFilter, &mut collector);
        crate::separate::charge(clock, incoming, 1);
        if collector.is_empty()
            || collector.len() > 3
            || collector
                .iter()
                .any(|(_, h)| !matches!(h, BasicHazardEntity::PlacedItem { .. }))
        {
            continue;
        }
        // Moving every actual obstruction can leave a feasible receiver when
        // evicting only one leaves known collisions. Returned filled area can
        // increase while last-sheet height and material stay unchanged. Both
        // repairs and the whole-job material guard still control acceptance.
        // Keep the original smaller single-victim alternatives as a fallback.
        let blocked: Vec<_> = receiver
            .placed_items()
            .iter()
            .enumerate()
            .filter(|(_, (key, _))| {
                collector.iter().any(
                    |(_, h)| matches!(h, BasicHazardEntity::PlacedItem { pk, .. } if *pk == *key),
                )
            })
            .collect();
        let area: f32 = blocked.iter().map(|(_, (_, p))| p.item().area()).sum();
        if blocked.len() > 1 {
            retain_proposal(
                &mut out,
                Proposal {
                    victims: blocked.iter().map(|(_, (key, _))| *key).collect(),
                    incoming: dt,
                    blockers: collector.len(),
                    rank: blocked[0].0,
                    area,
                },
            );
        }
        // Stable receiver placement order, independent of tree traversal order.
        for (rank, (key, p)) in receiver.placed_items().iter().enumerate() {
            if p.item().area() >= incoming.area()
                || !collector.iter().any(
                    |(_, h)| matches!(h, BasicHazardEntity::PlacedItem { pk, .. } if *pk == key),
                )
            {
                continue;
            }
            let proposal = Proposal {
                victims: vec![key],
                incoming: dt,
                blockers: collector.len(),
                rank,
                area: p.item().area(),
            };
            retain_proposal(&mut out, proposal);
        }
    }
    out
}

// Only choose the reciprocal frame when every returned part permits it. The
// separator can still move the parts independently; this is an initial pose.
fn return_group_poses(
    victims: &[(PItemKey, std::sync::Arc<Item>, DTransformation)],
    incoming_here: DTransformation,
    incoming_before: DTransformation,
) -> Vec<DTransformation> {
    let (from_x, from_y) = incoming_here.translation();
    let (to_x, to_y) = incoming_before.translation();
    let translated = || {
        victims
            .iter()
            .map(|(_, _, previous)| {
                let (x, y) = previous.translation();
                DTransformation::new(previous.rotation(), (x + to_x - from_x, y + to_y - from_y))
                    .with_reflection(previous.reflected)
            })
            .collect()
    };
    // Keep the previous arithmetic exactly when the two frames already agree.
    if incoming_here.rotation() == incoming_before.rotation()
        && incoming_here.reflected == incoming_before.reflected
    {
        return translated();
    }
    let frame = incoming_here
        .compose()
        .inverse()
        .transform(&incoming_before.compose());
    let aligned: Option<Vec<_>> = victims
        .iter()
        .map(|(_, victim, previous)| {
            let pose = previous.compose().transform(&frame).decompose();
            victim.allowed_orientations().allows(&pose).then_some(pose)
        })
        .collect();
    aligned.unwrap_or_else(translated)
}

type IncomingMember = (PItemKey, std::sync::Arc<Item>, DTransformation);

// Distribute a bounded set of nearby same-item pairs across original part types.
// The caller supplies stable decreasing-area order. Pointer identity keeps
// distinct original items separate even when their shapes or indices match.
fn incoming_pairs(layout: &JLayout, keys: &[PItemKey]) -> Vec<Vec<PItemKey>> {
    let mut groups: Vec<Vec<usize>> = Vec::new();
    for (index, &key) in keys.iter().enumerate() {
        let item = layout.placed_items()[key].item();
        if let Some(group) = groups.iter_mut().find(|group| {
            std::sync::Arc::ptr_eq(layout.placed_items()[keys[group[0]]].item(), item)
        }) {
            group.push(index);
        } else {
            groups.push(vec![index]);
        }
    }
    groups.retain(|group| group.len() >= 2);
    let mut anchors = Vec::new();
    for rank in 0..12 {
        for (group, members) in groups.iter().enumerate() {
            if let Some(&index) = members.get(rank) {
                anchors.push((group, index));
                if anchors.len() == 12 {
                    break;
                }
            }
        }
        if anchors.len() == 12 {
            break;
        }
    }
    let mut grouped_pairs = vec![Vec::new(); groups.len()];
    for (group, i) in anchors {
        let a = layout.placed_items()[keys[i]].shape().bbox();
        let mut neighbours: Vec<_> = groups[group]
            .iter()
            .filter_map(|&j| {
                if i == j {
                    return None;
                }
                let b = layout.placed_items()[keys[j]].shape().bbox();
                let dx = (a.x_min + a.x_max) - (b.x_min + b.x_max);
                let dy = (a.y_min + a.y_max) - (b.y_min + b.y_max);
                Some((dx * dx + dy * dy, j))
            })
            .collect();
        neighbours.sort_by(|a, b| a.0.total_cmp(&b.0).then(a.1.cmp(&b.1)));
        for (_, j) in neighbours.into_iter().take(2) {
            let pair = (i.min(j), i.max(j));
            if !grouped_pairs[group].contains(&pair) {
                grouped_pairs[group].push(pair);
            }
        }
    }
    let mut pairs = Vec::new();
    for rank in 0..24 {
        for group in &grouped_pairs {
            if let Some(&(a, b)) = group.get(rank) {
                pairs.push(vec![keys[a], keys[b]]);
                if pairs.len() == 6 {
                    return pairs;
                }
            }
        }
    }
    pairs
}

// Try nearby members of different original items, including singleton types.
// Input order is stable and area-ranked. Bounds match the existing selector.
fn mixed_incoming_pairs(layout: &JLayout, keys: &[PItemKey]) -> Vec<Vec<PItemKey>> {
    let mut pairs = Vec::new();
    let mut seen = Vec::new();
    for (i, &key) in keys.iter().enumerate().take(12) {
        let item = layout.placed_items()[key].item();
        let a = layout.placed_items()[key].shape().bbox();
        let mut neighbours: Vec<_> = keys
            .iter()
            .enumerate()
            .filter_map(|(j, &other)| {
                if i == j || std::sync::Arc::ptr_eq(item, layout.placed_items()[other].item()) {
                    return None;
                }
                let b = layout.placed_items()[other].shape().bbox();
                let dx = (a.x_min + a.x_max) - (b.x_min + b.x_max);
                let dy = (a.y_min + a.y_max) - (b.y_min + b.y_max);
                Some((dx * dx + dy * dy, j))
            })
            .collect();
        neighbours.sort_by(|a, b| a.0.total_cmp(&b.0).then(a.1.cmp(&b.1)));
        for (_, j) in neighbours.into_iter().take(2) {
            let pair = (i.min(j), i.max(j));
            if !seen.contains(&pair) {
                seen.push(pair);
                pairs.push(vec![keys[pair.0], keys[pair.1]]);
                if pairs.len() == 6 {
                    return pairs;
                }
            }
        }
    }
    pairs
}

fn same_original_inventory(a: &[IncomingMember], b: &[IncomingMember]) -> bool {
    a.len() == b.len()
        && a.iter().all(|(_, item, _)| {
            a.iter()
                .filter(|(_, other, _)| std::sync::Arc::ptr_eq(item, other))
                .count()
                == b.iter()
                    .filter(|(_, other, _)| std::sync::Arc::ptr_eq(item, other))
                    .count()
        })
}

// Incoming groups must preserve their relative transform and every member's
// permissions. An illegal mapped orientation rejects this proposal as a whole.
fn incoming_group_poses(
    members: &[IncomingMember],
    anchor: DTransformation,
) -> Option<Vec<DTransformation>> {
    let old = members.first()?.2;
    let same = old.rotation() == anchor.rotation() && old.reflected == anchor.reflected;
    let frame = old.compose().inverse().transform(&anchor.compose());
    let (ox, oy) = old.translation();
    let (nx, ny) = anchor.translation();
    members
        .iter()
        .enumerate()
        .map(|(i, (_, item, previous))| {
            let pose = if i == 0 {
                anchor
            } else if same {
                let (px, py) = previous.translation();
                DTransformation::new(previous.rotation(), (px + nx - ox, py + ny - oy))
                    .with_reflection(previous.reflected)
            } else {
                previous.compose().transform(&frame).decompose()
            };
            item.allowed_orientations().allows(&pose).then_some(pose)
        })
        .collect()
}

fn paired_proposals(
    receiver: &JLayout,
    incoming: &[IncomingMember],
    rng: &mut Xoshiro256PlusPlus,
    clock: &Clock,
    until: f64,
) -> Vec<Proposal> {
    debug_assert_eq!(incoming.len(), 2);
    let mut generation = PairGenerationTrace {
        incoming_ids: incoming.iter().map(|(_, item, _)| item.idx()).collect(),
        sample_total: 0, seen: 0, invalid_pose: 0, boundary: 0, empty: 0,
        over_three: 0, area_rejected: 0, eligible: 0, retained: 0,
        deadline_reached: false, start_remaining: until - clock.now(),
        elapsed: 0.0, started: Instant::now(),
    };
    let anchor = &incoming[0].1;
    let bounds = receiver.container().outer_cd().bbox();
    let mut samples = Vec::new();
    let mut buffer = anchor.shape_cd().as_ref().clone();
    for p in receiver.placed_items().values() {
        let dt = convert_sample_to_closest_feasible(p.d_transf(), anchor);
        buffer.transform_from(anchor.shape_cd(), &dt.compose());
        let a = buffer.bbox();
        let b = p.shape().bbox();
        let (x, y) = dt.translation();
        samples.push(
            DTransformation::new(
                dt.rotation(),
                (x + b.x_min - a.x_min, y + b.y_min - a.y_min),
            )
            .with_reflection(dt.reflected),
        );
    }
    if let Some(sampler) = UniformBBoxSampler::new(bounds, anchor, bounds) {
        samples.extend((0..128).map(|_| sampler.sample(rng)));
    }
    if !std::sync::Arc::ptr_eq(&incoming[0].1, &incoming[1].1) {
        for p in receiver.placed_items().values() {
            let dt = convert_sample_to_closest_feasible(p.d_transf(), anchor);
            let Some(poses) = incoming_group_poses(incoming, dt) else {
                continue;
            };
            let mut min_x = f32::INFINITY;
            let mut min_y = f32::INFINITY;
            for ((_, item, _), pose) in incoming.iter().zip(poses) {
                let mut shape = item.shape_cd().as_ref().clone();
                shape.transform_from(item.shape_cd(), &pose.compose());
                min_x = min_x.min(shape.bbox().x_min);
                min_y = min_y.min(shape.bbox().y_min);
                crate::separate::charge(clock, item, 1);
            }
            let b = p.shape().bbox();
            let (x, y) = dt.translation();
            samples.push(
                DTransformation::new(dt.rotation(), (x + b.x_min - min_x, y + b.y_min - min_y))
                    .with_reflection(dt.reflected),
            );
        }
    }
    let incoming_area: f32 = incoming.iter().map(|(_, item, _)| item.area()).sum();
    let mut collector = BasicHazardCollector::new();
    let mut out = Vec::new();
    generation.sample_total = samples.len();
    for sample in samples {
        if clock.now() >= until {
            generation.deadline_reached = true;
            break;
        }
        generation.seen += 1;
        let Some(poses) = incoming_group_poses(incoming, sample) else {
            generation.invalid_pose += 1;
            continue;
        };
        let mut collisions = Vec::new();
        let mut allowed = true;
        for ((_, item, _), pose) in incoming.iter().zip(&poses) {
            buffer = item.shape_cd().as_ref().clone();
            buffer.transform_from(item.shape_cd(), &pose.compose());
            collector.clear();
            receiver
                .cde()
                .collect_poly_collisions(&buffer, &NoFilter, &mut collector);
            crate::separate::charge(clock, item, 1);
            for (_, hazard) in collector.iter() {
                if let BasicHazardEntity::PlacedItem { pk, .. } = hazard {
                    if !collisions.contains(pk) {
                        collisions.push(*pk);
                    }
                } else {
                    allowed = false;
                }
            }
            if !allowed || collisions.len() > 3 {
                break;
            }
        }
        if !allowed || collisions.is_empty() || collisions.len() > 3 {
            if !allowed { generation.boundary += 1; }
            else if collisions.is_empty() { generation.empty += 1; }
            else { generation.over_three += 1; }
            continue;
        }
        // Keep the complete union of both incoming members' actual obstructions.
        let victims: Vec<_> = receiver
            .placed_items()
            .iter()
            .enumerate()
            .filter(|(_, (key, _))| collisions.contains(key))
            .collect();
        let area: f32 = victims.iter().map(|(_, (_, p))| p.item().area()).sum();
        if area > incoming_area {
            generation.area_rejected += 1;
            continue;
        }
        generation.eligible += 1;
        retain_proposal(
            &mut out,
            Proposal {
                victims: victims.iter().map(|(_, (key, _))| *key).collect(),
                incoming: sample,
                blockers: victims.len(),
                rank: victims[0].0,
                area,
            },
        );
    }
    generation.retained = out.len();
    out
}

impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search<'_, '_, F> {
    fn exchange_report(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        layout: &JLayout,
        shape: Shape,
    ) -> Result<Report> {
        let mut sheets = frozen.to_vec();
        sheets.extend(strip.split(layout, shape.sheets)?);
        let layout = self.model.to_layout(&sheets);
        let started = Instant::now();
        let report = validate(self.model.job, &layout)?;
        self.clock.validated(self.model.job, &layout);
        self.check_cost = self.check_cost.max(started.elapsed().as_secs_f64());
        Ok(report)
    }

    /// At most one exchange. The original separator is untouched until both
    /// repairs and the independent whole-job material/geometry guard pass.
    pub(super) fn directed_exchange(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        sep: &mut Separator,
        shape: Shape,
        until: f64,
    ) -> Result<usize> {
        let mut trace = BalancedTrace::default();
        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            trace.disabled_or_expired = true;
            return Ok(0);
        }
        let baseline = self.exchange_report(strip, frozen, &sep.layout, shape)?;
        if !baseline.valid {
            trace.baseline_invalid = true;
            return Ok(0);
        }
        let before = baseline.metrics.as_ref().expect("valid baseline");
        trace.before_material = Some(before.material_area);
        trace.before_last_extent = Some(strip.fit_last(&sep.layout, shape));
        let single = strip.container(Shape {
            sheets: 1,
            last: self.model.full_width,
        })?;
        let last_container = strip.container(Shape {
            sheets: 1,
            last: shape.last,
        })?;
        let last_index = shape.sheets - 1;
        let last_offset = strip.start(last_index);
        let mut incoming_keys = strip.in_last(&sep.layout, shape);
        incoming_keys.sort_by(|&a, &b| {
            sep.layout.placed_items()[b]
                .item()
                .area()
                .total_cmp(&sep.layout.placed_items()[a].item().area())
        });
        let mut fill = vec![0.0_f32; last_index];
        for p in sep
            .layout
            .placed_items()
            .values()
            .filter(|p| !strip.is_blocker(p))
        {
            let i = strip.sheet_of(p.shape());
            if i < last_index {
                fill[i] += p.item().area();
            }
        }
        let mut targets: Vec<_> = (0..last_index).collect();
        targets.sort_by(|&a, &b| fill[a].total_cmp(&fill[b]));
        let now = self.clock.now();
        let group_until = now + (self.last_step(until) - now).max(0.0) * 0.5;
        let same_pairs = incoming_pairs(&sep.layout, &incoming_keys);
        let mixed_pairs = mixed_incoming_pairs(&sep.layout, &incoming_keys);
        let mut choices =
            Vec::with_capacity(same_pairs.len() + mixed_pairs.len() + incoming_keys.len());
        for index in 0..same_pairs.len().max(mixed_pairs.len()) {
            if let Some(pair) = same_pairs.get(index) {
                choices.push(pair.clone());
            }
            if let Some(pair) = mixed_pairs.get(index) {
                choices.push(pair.clone());
            }
        }

        trace.available_source_items = incoming_keys.iter().map(|key|sep.layout.placed_items()[*key].item().idx()).collect();
        trace.pair_choices = choices.iter().map(|pair|pair.iter().map(|key|sep.layout.placed_items()[*key].item().idx()).collect()).collect();
        trace.exchange_remaining = Some(self.last_step(until) - now);
        trace.pair_phase_remaining = Some(group_until - now);
        choices.extend(incoming_keys.into_iter().map(|key| vec![key]));
        for selected in choices {
            let paired = selected.len() == 2;
            let exchange_until = if paired { group_until } else { until };
            if self.clock.now() >= self.last_step(exchange_until) {
                continue;
            }
            let incoming_key = selected[0];
            let members: Vec<_> = selected
                .iter()
                .map(|&key| {
                    let p = &sep.layout.placed_items()[key];
                    (key, p.item().clone(), shift(p.d_transf(), -last_offset))
                })
                .collect();
            let mixed = paired && !std::sync::Arc::ptr_eq(&members[0].1, &members[1].1);
            let incoming = &sep.layout.placed_items()[incoming_key];
            let incoming_item = incoming.item().clone();
            let incoming_old = shift(incoming.d_transf(), -last_offset);
            for &target in targets.iter().take(3) {
                if self.clock.now() >= self.last_step(exchange_until) {
                    break;
                }
                let offset = strip.start(target);
                let mut receiver = JLayout::new(single.clone());
                let mut source = JLayout::new(last_container.clone());
                let mut changed_keys = Vec::new();
                for (key, p) in sep
                    .layout
                    .placed_items()
                    .iter()
                    .filter(|(_, p)| !strip.is_blocker(p))
                {
                    let i = strip.sheet_of(p.shape());
                    if i == target {
                        receiver.place_item(p.item(), shift(p.d_transf(), -offset));
                        changed_keys.push(key);
                    } else if i == last_index {
                        if !selected.contains(&key) {
                            source.place_item(p.item(), shift(p.d_transf(), -last_offset));
                        }
                        changed_keys.push(key);
                    }
                }
                self.clock
                    .charge(Work::RegisteredItem, changed_keys.len() as f64);
                let proposal_until = self.last_step(exchange_until);
                let candidates = if paired {
                    paired_proposals(
                        &receiver,
                        &members,
                        &mut self.rng,
                        &self.clock,
                        proposal_until,
                    )
                } else {
                    proposals(
                        &receiver,
                        &incoming_item,
                        &mut self.rng,
                        &self.clock,
                        proposal_until,
                    )
                };
                let proposal_base = trace.proposals.len();
                for proposal in &candidates {
                    trace.proposals.push(ObservedProposal {
                        paired, target,
                        incoming_ids: members.iter().map(|(_,item,_)|item.idx()).collect(),
                        returned_ids: proposal.victims.iter().map(|key| receiver.placed_items()[*key].item().idx()).collect(),
                        blockers: proposal.blockers,
                        incoming_area: members.iter().map(|(_,item,_)|item.area()).sum(),
                        returned_area: proposal.area,
                    });
                }
                for (proposal_number, proposal) in candidates.into_iter().enumerate() {
                    if self.clock.now() >= self.last_step(exchange_until) {
                        break;
                    }
                    self.stats.directed_exchange_attempts += 1;
                    self.stats.paired_exchange_attempts += u64::from(paired);
                    let index = trace.attempts.len();
                    trace.attempts.push(ObservedAttempt {
                        proposal_index: proposal_base + proposal_number,
                        receiver_initial_loss: None, receiver_loss: None,
                        source_initial_loss: None, source_loss: None,
                        receiver_remaining: None, receiver_elapsed: None,
                        source_remaining: None, source_elapsed: None,
                        after_material: None, after_last_extent: None, outcome: "unfinished",
                    });
                    self.stats.mixed_exchange_attempts += u64::from(mixed);
                    let victims: Vec<_> = proposal
                        .victims
                        .iter()
                        .map(|&key| {
                            let p = &receiver.placed_items()[key];
                            (key, p.item().clone(), p.d_transf())
                        })
                        .collect();
                    let mut next_receiver = JLayout::from_snapshot(&receiver.save());
                    for &(key, _, _) in &victims {
                        next_receiver.remove_item(key);
                    }
                    if paired {
                        let Some(poses) = incoming_group_poses(&members, proposal.incoming) else {
                            trace.attempts[index].outcome = "forbidden_incoming_orientation";
                            continue;
                        };
                        for ((_, item, _), pose) in members.iter().zip(poses) {
                            next_receiver.place_item(item, pose);
                        }
                    } else {
                        next_receiver.place_item(&incoming_item, proposal.incoming);
                    }
                    let mut next_source = JLayout::from_snapshot(&source.save());
                    let returned = if victims.len() == 1 {
                        vec![convert_sample_to_closest_feasible(
                            incoming_old,
                            &victims[0].1,
                        )]
                    } else {
                        return_group_poses(&victims, proposal.incoming, incoming_old)
                    };
                    for ((_, victim, _), pose) in victims.iter().zip(returned) {
                        next_source.place_item(victim, pose);
                    }
                    self.clock
                        .charge(Work::RegisteredItem, changed_keys.len() as f64);
                    let now = self.clock.now();
                    // Bound each pair so one hard proposal cannot consume all
                    // remaining opportunities. Each repair gets half the pair.
                    let pair_end = now + ((self.last_step(exchange_until) - now) * 0.5).min(0.4);
                    let middle = (now + pair_end) / 2.0;
                    let mut receiver_sep = Separator::new(
                        next_receiver,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    trace.attempts[index].receiver_initial_loss = Some(receiver_sep.tracker.total_loss());
                    trace.attempts[index].receiver_remaining = Some(middle - self.clock.now());
                    let receiver_started = Instant::now();
                    let (receiver_snapshot, receiver_tracker) =
                        receiver_sep.separate(&self.deadline(middle));
                    trace.attempts[index].receiver_elapsed = Some(receiver_started.elapsed().as_secs_f64());
                    trace.attempts[index].receiver_loss = Some(receiver_tracker.total_loss());
                    if receiver_tracker.total_loss() > 0.0 {
                        trace.attempts[index].outcome = "receiver_repair_failed";
                        continue;
                    }
                    let mut source_sep = Separator::new(
                        next_source,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    trace.attempts[index].source_initial_loss = Some(source_sep.tracker.total_loss());
                    trace.attempts[index].source_remaining = Some(pair_end - self.clock.now());
                    let source_started = Instant::now();
                    let (source_snapshot, source_tracker) =
                        source_sep.separate(&self.deadline(pair_end));
                    trace.attempts[index].source_elapsed = Some(source_started.elapsed().as_secs_f64());
                    trace.attempts[index].source_loss = Some(source_tracker.total_loss());
                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(exchange_until)
                    {
                        trace.attempts[index].outcome = if source_tracker.total_loss() > 0.0 { "source_repair_failed" } else { "expired_after_repairs" };
                        continue;
                    }
                    let mut trial = JLayout::from_snapshot(&sep.layout.save());
                    for &key in &changed_keys {
                        trial.remove_item(key);
                    }
                    for (snapshot, start) in
                        [(receiver_snapshot, offset), (source_snapshot, last_offset)]
                    {
                        for p in JLayout::from_snapshot(&snapshot).placed_items().values() {
                            trial.place_item(p.item(), shift(p.d_transf(), start));
                        }
                    }
                    self.clock.charge(
                        Work::RegisteredItem,
                        (sep.layout.placed_items().len() + changed_keys.len()) as f64,
                    );
                    trace.attempts[index].after_last_extent = Some(strip.fit_last(&trial, shape));
                    let report = self.exchange_report(strip, frozen, &trial, shape)?;
                    if !report.valid {
                        trace.attempts[index].outcome = "independent_geometry_failed";
                        self.stats.rejected_layouts += 1;
                        continue;
                    }
                    let after = report.metrics.as_ref().expect("valid exchange");
                    trace.attempts[index].after_material = Some(after.material_area);
                    if after.sheets_used > before.sheets_used
                        || after.material_area > before.material_area
                        || self.clock.now() >= exchange_until
                    {
                        trace.attempts[index].outcome = if self.clock.now() >= exchange_until { "expired_before_acceptance" } else { "material_guard_failed" };
                        continue;
                    }
                    // Same inventory can still improve the geometry, but a
                    // flat material result must not consume the sole exchange.
                    if same_original_inventory(&members, &victims)
                        && after.material_area >= before.material_area
                    {
                        trace.attempts[index].outcome = "neutral_inventory_rejected";
                        self.stats.neutral_exchange_rejections += 1;
                        continue;
                    }
                    trace.attempts[index].outcome = "accepted";
                    sep.layout = trial;
                    sep.rebuild();
                    self.stats.directed_exchanges += 1;
                    self.stats.paired_exchanges += u64::from(paired);
                    self.stats.mixed_exchanges += u64::from(mixed);
                    return Ok(1);
                }
            }
        }
        Ok(0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nestbolt_validator::job::{Margins, Part, Stock};
    use nestbolt_validator::{Polygon, Units};

    fn rectangle(id: &str, width: f64, height: f64) -> Part {
        Part {
            id: id.into(),
            quantity: 1,
            geometry: vec![Polygon {
                outer: vec![[0.0, 0.0], [width, 0.0], [width, height], [0.0, height]],
                holes: vec![],
            }],
            rotations: Rotations::List { degrees: vec![0.0] },
            allow_mirror: false,
            priority: 1.0,
        }
    }

    fn fixture() -> (Job, Layout) {
        let job = Job {
            version: 1,
            name: "authored exchange".into(),
            units: Units::Mm,
            parts: vec![
                rectangle("filler", 60.0, 94.0),
                rectangle("return", 30.0, 20.0),
                rectangle("incoming", 30.0, 85.0),
            ],
            stocks: vec![Stock {
                id: "stock".into(),
                width: 100.0,
                height: 100.0,
                count: None,
                margins: Margins::default(),
                outline: vec![],
                defects: vec![],
            }],
            clearance: 0.2,
            edge_clearance: 1.0,
            mode: Mode::All,
        };
        let layout = Layout {
            version: 1,
            units: Units::Mm,
            sheets: (0..2)
                .map(|i| Sheet {
                    id: format!("sheet-{i}"),
                    stock_id: "stock".into(),
                })
                .collect(),
            placements: [
                ("filler", 0, [2.0, 2.0]),
                ("return", 0, [64.0, 2.0]),
                ("incoming", 1, [2.0, 2.0]),
            ]
            .into_iter()
            .map(|(id, sheet, translation)| Placement {
                part_id: id.into(),
                copy_index: 0,
                sheet_id: format!("sheet-{sheet}"),
                transform: RigidTransform {
                    translation,
                    rotation_radians: 0.0,
                    mirrored: false,
                },
            })
            .collect(),
        };
        (job, layout)
    }

    fn fingerprint(layout: &JLayout) -> String {
        format!(
            "{:?}",
            layout
                .placed_items()
                .iter()
                .map(|(k, p)| (k, p.item().idx(), p.d_transf()))
                .collect::<Vec<_>>()
        )
    }

    fn exercise(
        job: &Job,
        layout: &Layout,
        seed: u64,
        enabled: bool,
        expired: bool,
        frozen_count: usize,
    ) -> (usize, Layout, Stats) {
        let validation = validate(job, layout).unwrap();
        assert!(validation.valid, "{:?}", validation.violations);
        let model = Model::new(job).unwrap();
        let clock = Clock::new(Timing::Work, 30.0);
        let mut search = Search {
            model: &model,
            allow_exchange: enabled,
            rng: Xoshiro256PlusPlus::seed_from_u64(seed),
            clock: clock.clone(),
            best: (layout.clone(), validation, 0.0),
            history: vec![],
            stats: Stats::default(),
            progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
            check_cost: 0.0,
            check_every: 5.0,
        };
        let strip = Strip {
            model: &model,
            gap: 2.0,
            clock,
            containers: Default::default(),
        };
        let sheets = model.sheets_of(layout).unwrap();
        let (frozen, window) = sheets.split_at(frozen_count);
        let mut shape = Shape {
            sheets: window.len(),
            last: model.full_width,
        };
        let initial = strip.layout(window, shape).unwrap();
        shape.last = strip.fit_last(&initial, shape);
        let mut sep = Separator::new(
            strip.layout(window, shape).unwrap(),
            seed,
            EXPLORE,
            search.clock.clone(),
        );
        sep.pin(blocker_index(&model));
        assert_eq!(sep.tracker.total_loss(), 0.0);
        // Compare the same f32 internal frame before/after the exchange. The
        // public-to-internal conversion predates this operation and has its own
        // tests; comparing to the authored f64 coordinates conflates the two.
        let mut before_sheets = frozen.to_vec();
        before_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let before_layout = model.to_layout(&before_sheets);
        let before_report = validate(job, &before_layout).unwrap();
        assert!(before_report.valid);
        let before_material = before_report.metrics.as_ref().unwrap().material_area;
        let original = fingerprint(&sep.layout);
        let until = if expired {
            0.0
        } else {
            search.clock.now() + 3.0
        };
        let moved = search
            .directed_exchange(&strip, frozen, &mut sep, shape, until)
            .unwrap();
        if moved == 0 {
            assert_eq!(
                fingerprint(&sep.layout),
                original,
                "failed proposal mutated the original state"
            );
        }
        let mut after_sheets = frozen.to_vec();
        after_sheets.extend(strip.split(&sep.layout, shape.sheets).unwrap());
        let after = model.to_layout(&after_sheets);
        for i in 0..frozen_count {
            let id = format!("sheet-{i}");
            let before_fixed: Vec<_> = before_layout
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            let after_fixed: Vec<_> = after
                .placements
                .iter()
                .filter(|p| p.sheet_id == id)
                .collect();
            assert_eq!(
                serde_json::to_value(before_fixed).unwrap(),
                serde_json::to_value(after_fixed).unwrap()
            );
        }
        let report = validate(job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert!(report.metrics.as_ref().unwrap().material_area <= before_material);
        assert_eq!(sep.tracker.total_loss(), 0.0);
        eprintln!(
            "authored exchange seed={seed} enabled={enabled} expired={expired} frozen={frozen_count} moved={moved} attempts={} material_before={before_material:.9} material_after={:.9}",
            search.stats.directed_exchange_attempts,
            report.metrics.as_ref().unwrap().material_area
        );
        (moved, after, search.stats)
    }

    #[test]
    fn window_search_reaches_exchange_before_gap_filling() {
        let (mut job, mut layout) = fixture();
        // This small last-sheet part fits an earlier gap. A successful fill
        // must not bypass the exchange opportunity for the large incoming part.
        job.parts.push(rectangle("gap-part", 5.0, 5.0));
        layout.placements.push(Placement {
            part_id: "gap-part".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [36.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        for (enabled, budget) in [(true, 20.0), (false, 20.0), (true, 0.0)] {
            let report = validate(&job, &layout).unwrap();
            assert!(report.valid);
            let before_material = report.metrics.as_ref().unwrap().material_area;
            let model = Model::new(&job).unwrap();
            let clock = Clock::new(Timing::Work, 30.0);
            let mut search = Search {
                model: &model,
                allow_exchange: enabled,
                rng: Xoshiro256PlusPlus::seed_from_u64(0),
                clock,
                best: (layout.clone(), report, 0.0),
                history: vec![],
                stats: Stats::default(),
                progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
                check_cost: 0.0,
                check_every: 5.0,
            };
            search
                .window_search(model.sheets_of(&layout).unwrap(), budget, 0.2, 2)
                .unwrap();
            let checked = validate(&job, &search.best.0).unwrap();
            assert!(checked.valid);
            assert!(checked.metrics.as_ref().unwrap().material_area <= before_material);
            if enabled && budget > 0.0 {
                assert!(search.stats.directed_exchange_attempts > 0);
                assert!(search.stats.directed_exchanges > 0);
            } else {
                assert_eq!(search.stats.directed_exchange_attempts, 0);
                assert_eq!(search.stats.directed_exchanges, 0);
            }
            eprintln!(
                "window exchange enabled={enabled} budget={budget} attempts={} accepted={} valid={}",
                search.stats.directed_exchange_attempts,
                search.stats.directed_exchanges,
                checked.valid
            );
        }
    }

    #[test]
    fn directed_exchange_returns_smaller_actual_obstruction() {
        let (job, layout) = fixture();
        for seed in 0..5 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            assert_eq!(moved, 1, "seed {seed}, {stats:?}");
            assert_eq!(stats.directed_exchanges, 1);
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
            );
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
            );
        }
    }

    #[test]
    fn directed_exchange_expired_or_disabled_leaves_layout_intact() {
        let (job, layout) = fixture();
        for (enabled, expired) in [(true, true), (false, false)] {
            let (moved, _, stats) = exercise(&job, &layout, 0, enabled, expired, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.directed_exchange_attempts, 0);
        }
    }

    #[test]
    fn directed_exchange_rejects_returns_that_cannot_fit() {
        let (mut job, layout) = fixture();
        job.parts[2] = rectangle("incoming", 20.0, 10.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert_eq!(stats.directed_exchanges, 0);
    }

    #[test]
    fn directed_exchange_preserves_frozen_sheets_and_mirror_contract() {
        let (mut job, mut layout) = fixture();
        job.parts.push(rectangle("fixed", 20.0, 20.0));
        for p in &mut layout.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        let fixed = Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        };
        layout.placements.push(fixed.clone());
        job.parts[2].allow_mirror = true;
        let incoming = layout
            .placements
            .iter_mut()
            .find(|p| p.part_id == "incoming")
            .unwrap();
        incoming.transform.mirrored = true;
        incoming.transform.translation[0] += 30.0;
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 1);
        assert_eq!(moved, 1);
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "fixed" && p.sheet_id == "sheet-0")
        );
    }

    #[test]
    fn directed_exchange_failed_source_repair_leaves_layout_intact() {
        let (mut job, layout) = fixture();
        job.parts[1] = rectangle("return", 5.0, 90.0);
        job.parts[2] = rectangle("incoming", 30.0, 30.0);
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0);
        assert!(stats.directed_exchange_attempts > 0);
    }

    #[test]
    fn directed_exchange_respects_stock_defects() {
        let (mut job, layout) = fixture();
        job.edge_clearance = job.clearance;
        job.stocks[0].defects.push(Polygon {
            outer: vec![[96.0, 20.0], [98.0, 20.0], [98.0, 30.0], [96.0, 30.0]],
            holes: vec![],
        });
        let (moved, _, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
    }

    fn obstruction_set_fixture(count: usize, return_height: f64) -> (Job, Layout) {
        let (mut job, mut layout) = fixture();
        job.parts[1] = rectangle("return", 30.0, return_height);
        job.parts[1].quantity = count as u32;
        let template = layout
            .placements
            .iter()
            .find(|p| p.part_id == "return")
            .unwrap()
            .clone();
        for copy in 1..count {
            let mut part = template.clone();
            part.copy_index = copy as u32;
            part.transform.translation[1] += copy as f64 * (return_height + 2.0);
            layout.placements.push(part);
        }
        (job, layout)
    }

    #[test]
    fn obstruction_set_moves_two_blockers_atomically() {
        let (job, layout) = obstruction_set_fixture(2, 20.0);
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            2
        );
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
        );
    }

    #[test]
    fn obstruction_set_moves_three_blockers_atomically() {
        let (job, layout) = obstruction_set_fixture(3, 20.0);
        let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            3
        );
    }

    #[test]
    fn complete_sets_can_return_equal_or_greater_area_at_the_same_material() {
        // The independently validated witness retains a 33 mm charged height:
        // a 2550/2700 mm2 incoming part can trade for three 900 mm2 squares.
        // Their relative positions fit in the otherwise empty return sheet.
        for incoming_width in [85.0, 90.0] {
            let (mut job, mut layout) = obstruction_set_fixture(3, 30.0);
            for part in &mut job.parts {
                for polygon in &mut part.geometry {
                    for point in &mut polygon.outer {
                        point.swap(0, 1);
                    }
                }
            }
            job.parts[2] = rectangle("incoming", incoming_width, 30.0);
            for part in &mut layout.placements {
                part.transform.translation.swap(0, 1);
            }
            let original = validate(&job, &layout).unwrap();
            assert!(original.valid);
            assert_eq!(original.metrics.unwrap().material_area, 13300.0);
            let (moved, after, _) = exercise(&job, &layout, 0, true, false, 0);
            assert_eq!(moved, 1);
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
            );
        }
    }
    fn return_frame_witness() -> (Job, Layout) {
        let job = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../examples/return-frame-job.json"
        )))
        .unwrap();
        let layout = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../examples/return-frame-before.json"
        )))
        .unwrap();
        (job, layout)
    }

    fn witness_victims(
        receiver: &JLayout,
    ) -> Vec<(PItemKey, std::sync::Arc<Item>, DTransformation)> {
        receiver
            .placed_items()
            .iter()
            .filter(|(_, p)| p.item().external_id() == 2)
            .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
            .collect()
    }

    #[test]
    fn return_frame_rotates_into_the_vacated_gap_without_extra_material() {
        let (job, before) = return_frame_witness();
        let original = validate(&job, &before).unwrap();
        assert!(original.valid);
        assert_eq!(original.metrics.unwrap().material_area, 19500.0);
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        let incoming = sheets[1]
            .layout()
            .placed_items()
            .values()
            .find(|p| p.item().external_id() == 3)
            .unwrap();
        let incoming_old = incoming.d_transf();
        let placed = RigidTransform {
            translation: [2.0, 64.0],
            rotation_radians: 0.0,
            mirrored: false,
        };
        let incoming_new = model.internal(incoming.item().idx(), &placed);
        let victims = witness_victims(sheets[0].layout());
        assert_eq!(victims.len(), 3);
        let poses = return_group_poses(&victims, incoming_new, incoming_old);
        let mut after = before.clone();
        let p = after
            .placements
            .iter_mut()
            .find(|p| p.part_id == "incoming")
            .unwrap();
        p.sheet_id = "sheet-0".into();
        p.transform = placed;
        for ((p, (_, item, _)), pose) in after
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "return")
            .zip(&victims)
            .zip(&poses)
        {
            assert!(item.allowed_orientations().allows(pose));
            p.sheet_id = "sheet-1".into();
            p.transform = model.external(item.idx(), pose);
        }
        let report = validate(&job, &after).unwrap();
        assert!(report.valid, "{:?}", report.violations);
        assert_eq!(report.metrics.unwrap().material_area, 19500.0);
        let (fx, fy) = incoming_new.translation();
        let (tx, ty) = incoming_old.translation();
        for (p, (_, item, previous)) in after
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "return")
            .zip(&victims)
        {
            let (x, y) = previous.translation();
            let translated = DTransformation::new(previous.rotation(), (x + tx - fx, y + ty - fy))
                .with_reflection(previous.reflected);
            p.transform = model.external(item.idx(), &translated);
        }
        assert!(!validate(&job, &after).unwrap().valid);
    }

    #[test]
    fn return_frame_keeps_incumbent_when_roundoff_increases_charged_material() {
        let (mut job, before) = return_frame_witness();
        job.parts[1] = rectangle("source-filler", 20.0, 94.0);
        let (moved, _, stats) = exercise(&job, &before, 0, true, false, 0);
        // This exact authored attempt repairs both sheets but raises charged
        // material by 0.0007 mm2. The strict guard must retain the incumbent;
        // exercise also requires exact internal-state preservation on failure.
        assert_eq!(moved, 0);
        assert!(stats.directed_exchange_attempts > 0);
        assert_eq!(stats.directed_exchanges, 0);
    }

    #[test]
    fn directed_exchange_uses_the_rotated_return_gap() {
        let (mut job, mut before) = return_frame_witness();
        // Keep the incoming part first in the area-ranked source list. A narrow
        // tall neighbour still obstructs the old translation-only return pose.
        job.parts[1] = rectangle("source-filler", 20.0, 94.0);
        // A separate fixed top strip controls this sheet's occupied height.
        // It isolates successful frame use from the original fixture's strict
        // floating-point material rejection, which has its own test above.
        job.parts.push(rectangle("ceiling", 94.0, 1.0));
        before.placements.push(Placement {
            part_id: "ceiling".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 97.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(stats.directed_exchanges, 1);
        assert!(
            after
                .placements
                .iter()
                .any(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
        );
        assert_eq!(
            after
                .placements
                .iter()
                .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                .count(),
            3
        );
    }

    #[test]
    fn return_frame_preserves_permitted_reflection_and_relative_positions() {
        let (mut job, before) = return_frame_witness();
        job.parts[2].allow_mirror = true;
        job.parts[3].allow_mirror = true;
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        let mut victims = witness_victims(sheets[0].layout());
        for (i, (_, _, previous)) in victims.iter_mut().enumerate() {
            *previous = DTransformation::new(0.0, (12.0 + 6.0 * i as f32, 23.0));
        }
        let here = DTransformation::new(0.0, (10.0, 20.0));
        let old =
            DTransformation::new(std::f32::consts::FRAC_PI_2, (40.0, 50.0)).with_reflection(true);
        let poses = return_group_poses(&victims, here, old);
        // (x,y) relative to the old incoming frame maps to (y,x), then (40,50).
        for (i, (pose, (_, item, _))) in poses.iter().zip(&victims).enumerate() {
            assert!(pose.reflected && item.allowed_orientations().allows(pose));
            let (x, y) = pose.translation();
            assert!((x - 43.0).abs() < 0.0001);
            assert!((y - (52.0 + 6.0 * i as f32)).abs() < 0.0001);
            let matrix = pose.compose();
            let matrix = matrix.matrix();
            assert!(matrix[0][0].into_inner().abs() < 0.0001);
            assert!((matrix[0][1].into_inner() - 1.0).abs() < 0.0001);
            assert!((matrix[1][0].into_inner() - 1.0).abs() < 0.0001);
            assert!(matrix[1][1].into_inner().abs() < 0.0001);
        }
    }

    #[test]
    fn return_frame_falls_back_for_the_whole_group_if_any_orientation_is_forbidden() {
        let (job, before) = return_frame_witness();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&before).unwrap();
        for reflected in [false, true] {
            let mut victims = witness_victims(sheets[0].layout());
            if !reflected {
                // Only the first member forbids the quarter-turn. All members
                // must retain the old translation, rather than deform the set.
                victims[0].1 = sheets[0]
                    .layout()
                    .placed_items()
                    .values()
                    .find(|p| p.item().external_id() == 0)
                    .unwrap()
                    .item()
                    .clone();
            }
            let here = DTransformation::new(3.0 * std::f32::consts::FRAC_PI_2, (10.0, 20.0));
            let old = DTransformation::new(
                if reflected {
                    std::f32::consts::FRAC_PI_2
                } else {
                    0.0
                },
                (40.0, 50.0),
            )
            .with_reflection(reflected);
            let poses = return_group_poses(&victims, here, old);
            for (pose, (_, item, previous)) in poses.iter().zip(&victims) {
                assert!(item.allowed_orientations().allows(pose));
                assert_eq!(pose.rotation(), previous.rotation());
                assert_eq!(pose.reflected, previous.reflected);
                let (x, y) = previous.translation();
                assert_eq!(pose.translation(), (x + 40.0 - 10.0, y + 50.0 - 20.0));
            }
        }
    }
    fn balanced_fixture() -> (Job, Layout) {
        (
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/balanced-group-job.json"
            )))
            .unwrap(),
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/balanced-group-before.json"
            )))
            .unwrap(),
        )
    }

    #[test]
    fn balanced_pair_moves_two_incoming_and_three_returns() {
        let (job, layout) = balanced_fixture();
        assert_eq!(
            validate(&job, &layout)
                .unwrap()
                .metrics
                .unwrap()
                .material_area,
            19700.0
        );
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            assert_eq!(moved, 1, "{stats:?}");
            assert_eq!(stats.paired_exchanges, 1);
            assert!(stats.paired_exchange_attempts > 0);
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "incoming" && p.sheet_id == "sheet-0")
                    .count(),
                2
            );
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
        }
    }

    #[test]
    fn balanced_pair_disabled_or_expired_preserves_incumbent() {
        let (job, layout) = balanced_fixture();
        for (enabled, expired) in [(false, false), (true, true)] {
            let (moved, _, stats) = exercise(&job, &layout, 0, enabled, expired, 0);
            assert_eq!(moved, 0);
            assert_eq!(stats.paired_exchange_attempts, 0);
            assert_eq!(stats.paired_exchanges, 0);
        }
    }

    #[test]
    fn balanced_pair_preserves_frozen_prefix() {
        let (mut job, mut layout) = balanced_fixture();
        job.parts.push(rectangle("fixed", 10.0, 10.0));
        for p in &mut layout.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        layout.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        layout.placements.push(Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 1);
        assert_eq!(moved, 1);
        assert_eq!(stats.paired_exchanges, 1);
    }

    #[test]
    fn balanced_pair_rejects_illegal_group_orientation() {
        let (mut job, layout) = balanced_fixture();
        for mirrors in [false, true] {
            job.parts
                .iter_mut()
                .find(|p| p.id == "incoming")
                .unwrap()
                .allow_mirror = mirrors;
            let model = Model::new(&job).unwrap();
            let sheets = model.sheets_of(&layout).unwrap();
            let source = sheets[1].layout();
            let members: Vec<_> = source
                .placed_items()
                .iter()
                .filter(|(_, p)| p.item().area() == 1350.0)
                .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
                .collect();
            assert_eq!(members.len(), 2);
            let old = members[0].2;
            let reflected =
                DTransformation::new(old.rotation(), (30.0, 3.0)).with_reflection(!old.reflected);
            if !mirrors {
                assert!(incoming_group_poses(&members, reflected).is_none());
            } else {
                let permitted = model.internal(
                    members[0].1.idx(),
                    &RigidTransform {
                        translation: [32.0, 2.0],
                        rotation_radians: 0.0,
                        mirrored: true,
                    },
                );
                assert!(permitted.reflected);
                assert!(incoming_group_poses(&members, permitted).is_some());
            }
            assert!(
                incoming_group_poses(
                    &members,
                    DTransformation::new(old.rotation() + std::f32::consts::FRAC_PI_2, (0.0, 0.0))
                        .with_reflection(old.reflected)
                )
                .is_none()
            );
            let shifted = incoming_group_poses(
                &members,
                DTransformation::new(old.rotation(), (3.0, 4.0)).with_reflection(old.reflected),
            )
            .unwrap();
            let old_delta = (
                members[1].2.translation().0 - members[0].2.translation().0,
                members[1].2.translation().1 - members[0].2.translation().1,
            );
            let new_delta = (
                shifted[1].translation().0 - shifted[0].translation().0,
                shifted[1].translation().1 - shifted[0].translation().1,
            );
            let scale = members
                .iter()
                .map(|(_, _, pose)| pose.translation().0.abs().max(pose.translation().1.abs()))
                .fold(1.0_f32, f32::max);
            let tolerance = 4.0 * f32::EPSILON * scale;
            assert!((old_delta.0 - new_delta.0).abs() <= tolerance);
            assert!((old_delta.1 - new_delta.1).abs() <= tolerance);
        }
    }

    #[test]
    fn balanced_pair_selection_is_unique_bounded_and_identity_safe() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let item = source
            .placed_items()
            .values()
            .find(|p| p.item().area() == 1350.0)
            .unwrap()
            .item();
        let mut many = JLayout::new(source.container().clone());
        let keys: Vec<_> = (0..20)
            .map(|i| many.place_item(item, DTransformation::new(0.0, (i as f32 * 32.0, 0.0))))
            .collect();
        let pairs = incoming_pairs(&many, &keys);
        assert_eq!(pairs.len(), 6);
        assert_eq!(pairs, incoming_pairs(&many, &keys));
        for (i, pair) in pairs.iter().enumerate() {
            assert_eq!(pair.len(), 2);
            assert_ne!(pair[0], pair[1]);
            assert!(!pairs[..i].contains(pair));
        }
        let other_model = Model::new(&job).unwrap();
        let other_sheets = other_model.sheets_of(&layout).unwrap();
        let other = other_sheets[1]
            .layout()
            .placed_items()
            .values()
            .find(|p| p.item().area() == 1350.0)
            .unwrap()
            .item();
        let key = many.place_item(other, DTransformation::new(0.0, (0.0, 47.0)));
        assert!(incoming_pairs(&many, &[keys[0], key]).is_empty());
    }

    #[test]
    fn balanced_pair_falls_back_to_a_valid_single_exchange() {
        let (mut job, layout) = balanced_fixture();
        let incoming = job.parts.iter_mut().find(|p| p.id == "incoming").unwrap();
        let quantity = incoming.quantity;
        *incoming = rectangle("incoming", 30.0, 20.0);
        incoming.quantity = quantity;
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 1);
        assert_eq!(stats.paired_exchange_attempts, 0);
        assert_eq!(stats.paired_exchanges, 0);
        assert_eq!(stats.directed_exchanges, 1);
    }

    #[test]
    fn balanced_pair_without_return_room_preserves_incumbent() {
        let (mut job, mut layout) = balanced_fixture();
        let incoming = job.parts.iter_mut().find(|p| p.id == "incoming").unwrap();
        *incoming = rectangle("incoming", 30.0, 44.9);
        incoming.quantity = 2;
        for p in layout
            .placements
            .iter_mut()
            .filter(|p| p.part_id == "incoming")
        {
            p.transform.translation[1] = if p.copy_index == 0 { 1.01 } else { 46.12 };
        }
        job.parts.push(rectangle("source-extra", 30.0, 7.7));
        layout.placements.push(Placement {
            part_id: "source-extra".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [2.0, 91.23],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        // The source fits 2*44.9 + 7.7 plus spacing. Three returned squares
        // plus that extra part need 98.3 mm in a 98 mm side band.
        let (moved, _, stats) = exercise(&job, &layout, 0, true, false, 0);
        assert_eq!(moved, 0, "{stats:?}");
        assert_eq!(stats.directed_exchanges, 0);
        assert_eq!(stats.paired_exchanges, 0);
    }
    #[test]
    fn accepted_exchange_still_fills_a_known_gap() {
        let (mut job, mut layout) = fixture();
        // This small last-sheet part fits an earlier gap. A successful fill
        // must not bypass the exchange opportunity for the large incoming part.
        job.parts.push(rectangle("gap-part", 5.0, 5.0));
        layout.placements.push(Placement {
            part_id: "gap-part".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [36.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        for (enabled, budget) in [(true, 20.0), (false, 20.0), (true, 0.0)] {
            let report = validate(&job, &layout).unwrap();
            assert!(report.valid);
            let before_material = report.metrics.as_ref().unwrap().material_area;
            let model = Model::new(&job).unwrap();
            let clock = Clock::new(Timing::Work, 30.0);
            let mut search = Search {
                model: &model,
                allow_exchange: enabled,
                rng: Xoshiro256PlusPlus::seed_from_u64(0),
                clock,
                best: (layout.clone(), report, 0.0),
                history: vec![],
                stats: Stats::default(),
                progress: |_: &Progress, _: &dyn Fn() -> Option<Layout>| {},
                check_cost: 0.0,
                check_every: 5.0,
            };
            search
                .window_search(model.sheets_of(&layout).unwrap(), budget, 0.2, 2)
                .unwrap();
            let checked = validate(&job, &search.best.0).unwrap();
            assert!(checked.valid);
            assert!(checked.metrics.as_ref().unwrap().material_area <= before_material);
            if enabled && budget > 0.0 {
                assert!(search.stats.directed_exchange_attempts > 0);
                assert!(search.stats.directed_exchanges > 0);
                assert!(
                    search.stats.direct_insertions > 0,
                    "accepted exchange must retain gap filling: {:?}",
                    search.stats
                );
                assert!(search.stats.post_exchange_fill_calls > 0);
                assert!(search.stats.post_exchange_fill_moves > 0);
                assert!(
                    search
                        .best
                        .0
                        .placements
                        .iter()
                        .any(|p| p.part_id == "gap-part" && p.sheet_id == "sheet-0"),
                    "the known gap part must reach the earlier sheet"
                );
            } else {
                assert_eq!(search.stats.directed_exchange_attempts, 0);
                assert_eq!(search.stats.directed_exchanges, 0);
                assert_eq!(search.stats.post_exchange_fill_calls, 0);
                assert_eq!(search.stats.post_exchange_fill_moves, 0);
            }
            eprintln!(
                "window exchange enabled={enabled} budget={budget} attempts={} accepted={} valid={}",
                search.stats.directed_exchange_attempts,
                search.stats.directed_exchanges,
                checked.valid
            );
        }
    }
    fn equal_inventory_fixture(taller_source: bool) -> (Job, Layout) {
        let (mut job, mut layout) = balanced_fixture();
        job.parts.retain(|p| p.id != "return");
        job.parts
            .iter_mut()
            .find(|p| p.id == "incoming")
            .unwrap()
            .quantity = 4;
        layout.placements.retain(|p| p.part_id != "return");
        for p in &mut layout.placements {
            if taller_source && p.part_id == "incoming" && p.copy_index == 1 {
                p.transform.translation[1] = 52.0;
            }
        }
        for (copy_index, y) in [(2, 2.0), (3, 49.0)] {
            layout.placements.push(Placement {
                part_id: "incoming".into(),
                copy_index,
                sheet_id: "sheet-0".into(),
                transform: RigidTransform {
                    translation: [2.0, y],
                    rotation_radians: 0.0,
                    mirrored: false,
                },
            });
        }
        if taller_source {
            // The validator credits the largest offcut on either sheet. Keep
            // the receiver taller so exchanging the pairs saves real material.
            job.parts.push(rectangle("ceiling", 94.0, 0.5));
            layout.placements.push(Placement {
                part_id: "ceiling".into(),
                copy_index: 0,
                sheet_id: "sheet-0".into(),
                transform: RigidTransform {
                    translation: [2.0, 98.0],
                    rotation_radians: 0.0,
                    mirrored: false,
                },
            });
        }
        (job, layout)
    }

    #[test]
    fn productive_exchange_rejects_unchanged_inventory_without_material_gain() {
        let (job, layout) = equal_inventory_fixture(false);
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            eprintln!(
                "PRODUCTIVE_WITNESS {}",
                serde_json::json!({
                    "case":"unchanged_inventory", "seed":seed, "job":&job,
                    "before":&layout, "after":&after, "moved":moved, "stats":&stats,
                })
            );
            assert_eq!(
                moved, 0,
                "unchanged inventory with no material gain must not end exchange search: {stats:?}"
            );
            assert_eq!(stats.directed_exchanges, 0);
            assert!(stats.paired_exchange_attempts > 0);
        }
    }

    #[test]
    fn productive_exchange_keeps_same_inventory_when_material_decreases() {
        let (job, layout) = equal_inventory_fixture(true);
        let before = validate(&job, &layout)
            .unwrap()
            .metrics
            .unwrap()
            .material_area;
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            eprintln!(
                "PRODUCTIVE_WITNESS {}",
                serde_json::json!({
                    "case":"same_inventory_improves", "seed":seed, "job":&job,
                    "before":&layout, "after":&after, "moved":moved, "stats":&stats,
                })
            );
            assert_eq!(
                moved, 1,
                "a same-inventory exchange that saves material must remain eligible: {stats:?}"
            );
            assert_eq!(stats.paired_exchanges, 1);
            let report = validate(&job, &after).unwrap();
            assert!(report.valid);
            assert!(before - report.metrics.unwrap().material_area > 99.9);
        }
    }

    #[test]
    fn productive_exchange_pair_selection_reaches_different_part_types() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let mut items: Vec<_> = model
            .instance
            .items
            .iter()
            .map(|(item, _)| item.clone())
            .collect();
        items.sort_by(|a, b| b.area().total_cmp(&a.area()));
        assert_eq!(items.len(), 3);
        let mut many = JLayout::new(sheets[0].layout().container().clone());
        let mut keys = Vec::new();
        for (family, item) in items.iter().enumerate() {
            for copy in 0..20 {
                keys.push(many.place_item(
                    item,
                    DTransformation::new(0.0, (copy as f32 * 500.0, family as f32 * 10000.0)),
                ));
            }
        }
        let pairs = incoming_pairs(&many, &keys);
        assert_eq!(pairs.len(), 6);
        assert_eq!(pairs, incoming_pairs(&many, &keys));
        let mut families: Vec<_> = pairs
            .iter()
            .map(|p| many.placed_items()[p[0]].item().idx())
            .collect();
        families.sort_unstable();
        families.dedup();
        assert_eq!(
            families.len(),
            3,
            "bounded pair choices must reach all three available part types"
        );
        for (index, pair) in pairs.iter().enumerate() {
            assert!(!pairs[..index].contains(pair));
            assert_eq!(pair.len(), 2);
            assert_ne!(pair[0], pair[1]);
            assert!(std::sync::Arc::ptr_eq(
                many.placed_items()[pair[0]].item(),
                many.placed_items()[pair[1]].item()
            ));
        }
    }
    fn mixed_fixture() -> (Job, Layout) {
        (
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/mixed-group-job.json"
            )))
            .unwrap(),
            serde_json::from_str(include_str!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../examples/mixed-group-before.json"
            )))
            .unwrap(),
        )
    }

    #[test]
    fn mixed_pair_moves_different_parts_and_three_returns() {
        let (job, before) = mixed_fixture();
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &before, seed, true, false, 0);
            eprintln!(
                "MIXED_WITNESS {}",
                serde_json::json!({"case":"mixed_positive","seed":seed,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats})
            );
            assert_eq!(
                moved, 1,
                "different original parts must be eligible for the authored two-to-three exchange: {stats:?}"
            );
            assert_eq!(stats.paired_exchanges, 1);
            for id in ["short-incoming", "tall-incoming"] {
                assert!(
                    after
                        .placements
                        .iter()
                        .any(|p| p.part_id == id && p.sheet_id == "sheet-0")
                );
            }
            assert_eq!(
                after
                    .placements
                    .iter()
                    .filter(|p| p.part_id == "return" && p.sheet_id == "sheet-1")
                    .count(),
                3
            );
        }
    }

    #[test]
    fn mixed_pair_disabled_or_expired_preserves_incumbent() {
        let (job, before) = mixed_fixture();
        for seed in 0..4 {
            for (enabled, expired) in [(false, false), (true, true)] {
                let (moved, _, stats) = exercise(&job, &before, seed, enabled, expired, 0);
                assert_eq!(moved, 0);
                assert_eq!(stats.directed_exchange_attempts, 0);
                assert_eq!(stats.directed_exchanges, 0);
            }
        }
    }

    #[test]
    fn mixed_pair_checks_each_members_rotation_and_reflection() {
        let (mut job, layout) = mixed_fixture();
        for permit_second in [false, true] {
            for part in &mut job.parts {
                if part.id == "short-incoming" || part.id == "tall-incoming" {
                    let permits = part.id == "short-incoming" || permit_second;
                    part.rotations = Rotations::List {
                        degrees: if permits { vec![0.0, 90.0] } else { vec![0.0] },
                    };
                    part.allow_mirror = permits;
                }
            }
            let model = Model::new(&job).unwrap();
            let sheets = model.sheets_of(&layout).unwrap();
            let mut members: Vec<_> = sheets[1]
                .layout()
                .placed_items()
                .iter()
                .filter(|(_, p)| p.item().area() < 2000.0)
                .map(|(key, p)| (key, p.item().clone(), p.d_transf()))
                .collect();
            members.sort_by(|a, b| a.1.area().total_cmp(&b.1.area()));
            assert_eq!(members.len(), 2);
            assert!(!std::sync::Arc::ptr_eq(&members[0].1, &members[1].1));
            let old = members[0].2;
            let quarter =
                DTransformation::new(old.rotation() + std::f32::consts::FRAC_PI_2, (0.0, 0.0))
                    .with_reflection(old.reflected);
            assert_eq!(
                incoming_group_poses(&members, quarter).is_some(),
                permit_second
            );
            let reflected = model.internal(
                members[0].1.idx(),
                &RigidTransform {
                    translation: [32.0, 2.0],
                    rotation_radians: 0.0,
                    mirrored: true,
                },
            );
            assert_eq!(
                incoming_group_poses(&members, reflected).is_some(),
                permit_second
            );
            let translated = incoming_group_poses(
                &members,
                DTransformation::new(old.rotation(), (4.0, 5.0)).with_reflection(old.reflected),
            )
            .unwrap();
            let old_delta = (
                members[1].2.translation().0 - old.translation().0,
                members[1].2.translation().1 - old.translation().1,
            );
            let new_delta = (
                translated[1].translation().0 - translated[0].translation().0,
                translated[1].translation().1 - translated[0].translation().1,
            );
            assert!(
                (old_delta.0 - new_delta.0).abs() < 0.0001
                    && (old_delta.1 - new_delta.1).abs() < 0.0001
            );
        }
    }

    #[test]
    fn mixed_pair_selection_is_bounded_unique_and_reaches_singletons() {
        let (job, layout) = mixed_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let source = sheets[1].layout();
        let mut keys: Vec<_> = source.placed_items().keys().collect();
        keys.sort_by(|a, b| {
            source.placed_items()[*b]
                .item()
                .area()
                .total_cmp(&source.placed_items()[*a].item().area())
        });
        let pairs = mixed_incoming_pairs(source, &keys);
        assert_eq!(pairs.len(), 3);
        assert_eq!(pairs, mixed_incoming_pairs(source, &keys));
        assert!(pairs.iter().any(|p| p.contains(&keys[0])));
        assert!(
            pairs
                .iter()
                .any(|p| p.contains(&keys[1]) && p.contains(&keys[2]))
        );
        for (i, pair) in pairs.iter().enumerate() {
            assert_ne!(pair[0], pair[1]);
            assert!(!pairs[..i].contains(pair));
            assert!(!std::sync::Arc::ptr_eq(
                source.placed_items()[pair[0]].item(),
                source.placed_items()[pair[1]].item()
            ));
        }
        let mut many = JLayout::new(source.container().clone());
        let mut many_keys = Vec::new();
        for (family, key) in keys.iter().enumerate() {
            for copy in 0..20 {
                many_keys.push(many.place_item(
                    source.placed_items()[*key].item(),
                    DTransformation::new(0.0, (copy as f32 * 500.0, family as f32 * 10000.0)),
                ));
            }
        }
        let pairs = mixed_incoming_pairs(&many, &many_keys);
        assert_eq!(pairs.len(), 6);
        assert_eq!(pairs, mixed_incoming_pairs(&many, &many_keys));
        for (i, pair) in pairs.iter().enumerate() {
            assert!(!pairs[..i].contains(pair));
        }
        assert!(mixed_incoming_pairs(&many, &many_keys[..20]).is_empty());
    }

    #[test]
    fn mixed_pair_preserves_a_frozen_sheet() {
        let (mut job, mut before) = mixed_fixture();
        for p in &mut before.placements {
            p.sheet_id = if p.sheet_id == "sheet-0" {
                "sheet-1".into()
            } else {
                "sheet-2".into()
            };
        }
        before.sheets.push(Sheet {
            id: "sheet-2".into(),
            stock_id: "stock".into(),
        });
        job.parts.push(rectangle("fixed", 20.0, 20.0));
        before.placements.push(Placement {
            part_id: "fixed".into(),
            copy_index: 0,
            sheet_id: "sheet-0".into(),
            transform: RigidTransform {
                translation: [2.0, 2.0],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 1);
        eprintln!(
            "MIXED_WITNESS {}",
            serde_json::json!({"case":"mixed_frozen","seed":0,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats})
        );
        assert_eq!(moved, 1);
        assert_eq!(stats.mixed_exchanges, 1);
        for id in ["short-incoming", "tall-incoming"] {
            assert!(
                after
                    .placements
                    .iter()
                    .any(|p| p.part_id == id && p.sheet_id == "sheet-1")
            );
        }
    }

    #[test]
    fn mixed_pair_failed_return_room_preserves_incumbent() {
        let (mut job, mut before) = mixed_fixture();
        *job.parts
            .iter_mut()
            .find(|p| p.id == "short-incoming")
            .unwrap() = rectangle("short-incoming", 30.0, 39.9);
        *job.parts
            .iter_mut()
            .find(|p| p.id == "tall-incoming")
            .unwrap() = rectangle("tall-incoming", 30.0, 49.9);
        for p in &mut before.placements {
            if p.part_id == "short-incoming" {
                p.transform.translation[1] = 1.01;
            }
            if p.part_id == "tall-incoming" {
                p.transform.translation[1] = 41.12;
            }
        }
        job.parts.push(rectangle("source-extra", 30.0, 7.7));
        before.placements.push(Placement {
            part_id: "source-extra".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [2.0, 91.23],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 0);
        eprintln!(
            "MIXED_WITNESS {}",
            serde_json::json!({"case":"mixed_no_return_room","seed":0,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats})
        );
        assert_eq!(moved, 0);
        assert_eq!(stats.mixed_exchanges, 0);
        assert!(stats.directed_exchange_attempts > 0);
    }
}
