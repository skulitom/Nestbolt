"""Observe mixed-pair sample rejection reasons, choices and repair allocations without changing decisions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib,json,shutil,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-mixed-stage-20261018';old=root/'output/h5-mixed-exchange-probe-20261018/candidate'
out.mkdir(exist_ok=False);work=out/'workspace';shutil.copytree(old,work)
rel='crates/core/src/sheets/vstrip/exchange.rs';path=work/rel;original=path.read_text(encoding='utf-8');text=original;changes=[]
def replace(before,after):
    global text
    assert text.count(before)==1,before
    text=text.replace(before,after);changes.append((before,after))
# Reuse the already-qualified identity/stage insertions through the last
# material-acceptance insertion, which needs the newer neutral-rejection path.
prior=(root/'output/prepare_h5_balanced_stage.py').read_text(encoding='utf-8')
start=prior.index("types='''");end=prior.index("replace('''                    {\n                        continue;\n                    }\n                    sep.layout = trial;'''")
exec(compile(prior[start:end],'<preserved identity observations>','exec'))
replace('''                    {
                        continue;
                    }
                    // Same inventory''','''                    {
                        trace.attempts[index].outcome = if self.clock.now() >= exchange_until { "expired_before_acceptance" } else { "material_guard_failed" };
                        continue;
                    }
                    // Same inventory''')
replace('''                        self.stats.neutral_exchange_rejections += 1;''','''                        trace.attempts[index].outcome = "neutral_inventory_rejected";
                        self.stats.neutral_exchange_rejections += 1;''')
replace('''                    sep.layout = trial;''','''                    trace.attempts[index].outcome = "accepted";
                    sep.layout = trial;''')
replace('''    before_last_extent: Option<f32>,
    proposals:''','''    before_last_extent: Option<f32>,
    available_source_items: Vec<usize>,
    pair_choices: Vec<Vec<usize>>,
    exchange_remaining: Option<f64>,
    pair_phase_remaining: Option<f64>,
    proposals:''')
replace('''    source_loss: Option<f32>,
    after_material:''','''    source_loss: Option<f32>,
    receiver_remaining: Option<f64>,
    receiver_elapsed: Option<f64>,
    source_remaining: Option<f64>,
    source_elapsed: Option<f64>,
    after_material:''')
replace('''        choices.extend(incoming_keys.into_iter().map(|key| vec![key]));''','''
        trace.available_source_items = incoming_keys.iter().map(|key|sep.layout.placed_items()[*key].item().idx()).collect();
        trace.pair_choices = choices.iter().map(|pair|pair.iter().map(|key|sep.layout.placed_items()[*key].item().idx()).collect()).collect();
        trace.exchange_remaining = Some(self.last_step(until) - now);
        trace.pair_phase_remaining = Some(group_until - now);
        choices.extend(incoming_keys.into_iter().map(|key| vec![key]));''')
replace('''                        source_initial_loss: None, source_loss: None,
                        after_material:''','''                        source_initial_loss: None, source_loss: None,
                        receiver_remaining: None, receiver_elapsed: None,
                        source_remaining: None, source_elapsed: None,
                        after_material:''')
replace('''                    trace.attempts[index].receiver_initial_loss = Some(receiver_sep.tracker.total_loss());''','''                    trace.attempts[index].receiver_initial_loss = Some(receiver_sep.tracker.total_loss());
                    trace.attempts[index].receiver_remaining = Some(middle - self.clock.now());
                    let receiver_started = Instant::now();''')
replace('''                    trace.attempts[index].receiver_loss = Some(receiver_tracker.total_loss());''','''                    trace.attempts[index].receiver_elapsed = Some(receiver_started.elapsed().as_secs_f64());
                    trace.attempts[index].receiver_loss = Some(receiver_tracker.total_loss());''')
replace('''                    trace.attempts[index].source_initial_loss = Some(source_sep.tracker.total_loss());''','''                    trace.attempts[index].source_initial_loss = Some(source_sep.tracker.total_loss());
                    trace.attempts[index].source_remaining = Some(pair_end - self.clock.now());
                    let source_started = Instant::now();''')
replace('''                    trace.attempts[index].source_loss = Some(source_tracker.total_loss());''','''                    trace.attempts[index].source_elapsed = Some(source_started.elapsed().as_secs_f64());
                    trace.attempts[index].source_loss = Some(source_tracker.total_loss());''')
exec(compile((root/'output/mixed_generation_instrumentation.py').read_text(encoding='utf-8'),'<sampling observations>','exec'))
text=text.replace('BALANCED_DIAG ','MIXED_DIAG ')
# Prefix changes are also accounted for in the exact reversal audit.
reverse=text.replace('MIXED_DIAG ','BALANCED_DIAG ')
for before,after in reversed(changes):
    assert reverse.count(after)==1;reverse=reverse.replace(after,before)
assert reverse==original
path.write_text(text,encoding='utf-8',newline='\n')
(out/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='productive-candidate',tofile='observations-only')),encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
files=[{'path':p.relative_to(old).as_posix(),'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(old.rglob('*')) if p.is_file()]
plan={'utc':datetime.now(timezone.utc).isoformat(),'old_source':str(old),'changed_file':rel,'source_files':files,'production_digest':source_digest(),'target':str(root/'output/h5-mixed-stage-target-20261018'),'instrumentation_reversible_to_exact_original_text':True,'proposal_repair_acceptance_settings_unchanged':True,'purpose':__doc__,'measurement_planned':{'jobs':['m-mechanical-large-plates','m-mechanical-panel-hardware'],'kerfs':[.2,1.5],'seed':0,'seconds':60,'cpu':8,'serial':True}}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
builder=(root/'output/build_h5_balanced_stage.py').read_text(encoding='utf-8').replace('h5-balanced-stage-20261018','h5-mixed-stage-20261018').replace('h5-balanced-stage-target-20261018','h5-mixed-stage-target-20261018')
(root/'output/build_h5_mixed_stage.py').write_text(builder,encoding='utf-8',newline='\n')
print(json.dumps({'instrumentation_reversible':True,'other_source_files_unchanged':len(files)-1,'original_tests':107}))
