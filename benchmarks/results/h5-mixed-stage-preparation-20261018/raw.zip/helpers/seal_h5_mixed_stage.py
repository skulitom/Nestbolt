from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-mixed-stage-20261018'
out=root/'benchmarks/results/h5-mixed-stage-preparation-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_mixed_stage as runner
load,write,digest=runner.load,runner.write,runner.digest
build=load(probe/'build.json');plan=load(probe/'preparation.json');reader=load(probe/'authored-trace-reader/checks.json')
assert build['all_passed'] and digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert digest(probe/'workspace'/plan['changed_file'])==build['source_sha256']
assert '107 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert runner.prior.source_digest()==plan['production_digest']
for row in plan['source_files']:
    assert digest(Path(plan['old_source'])/row['path'])==row['sha256']
    if row['path']!=plan['changed_file']:assert digest(probe/'workspace'/row['path'])==row['sha256']
assert reader['all_checks_pass'] and len(reader['authored_test_traces'])==9
assert len(reader['malformed_records_rejected'])==22 and reader['identity_multiset_checks']==4
assert reader['reader_sha256']==digest(root/'scripts/h5_mixed_stage.py')
out.mkdir(exist_ok=False)
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_mixed_stage.py','build_h5_mixed_stage.py',
             'prepare_h5_mixed_stage_runner.py','check_h5_mixed_stage_reader.py','seal_h5_mixed_stage.py','prepare_h5_mixed_stage_reports.py']:
    files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_mixed_stage.py'
files['helpers/prior-identity-prepare.py']=root/'output/prepare_h5_balanced_stage.py'
files['helpers/generation-insertions.py']=root/'output/mixed_generation_instrumentation.py'
files['helpers/generate-prepare.py']=root/'output/prepare_h5_mixed_stage_generation.py'
files['helpers/productive-prepare-template.py']=root/'output/prepare_h5_productive_stage.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
raw=out/'raw.zip'
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(raw) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        b=z.read(name);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
for name in ['preparation.json','build.json','instrumentation.patch']:shutil.copyfile(probe/name,out/name)
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(raw),'bytes':raw.stat().st_size,'members':inventory,'crc_and_every_member_verified':True})
write(out/'checks.json',{'optimized_core_tests_passed':107,'strict_lint_passed':True,'observer_build_passed':True,
    'authored_test_traces':9,'malformed_records_rejected':22,'identity_multiset_checks':4,
    'production_and_rejected_candidate_unchanged':True,'measured_search_started':False,'quality_claim':False,'H5_complete':False})
doc='# Mixed-pair sampling and repair observations — preparation, 2026-10-18\n\nThe [mixed-part pilot](h5-mixed-exchange-pilot-20261018.md) validates all 72\noutcomes but fails the four mechanical material pairs. Eleven attempted mixed\nexchanges accept none. These aggregate counters do not locate the rejection.\n\nThis separate diagnostic copy records every paired proposal-generation call:\nincoming item IDs, generated/visited samples, invalid poses, stock-boundary\ncollisions, empty obstruction sets, sets over three parts, excessive returned\narea, eligible candidates, retained proposals and deadline truncation. The\nreasons form an exhaustive ordered partition of visited samples. A boundary\ncollision takes precedence over an oversized set when both occur. Sampling\nduration includes setup and group-anchor construction. It is not a minimum\ntime requirement. Existing stage observations also retain source inventories,\nbounded pair choices, proposal identities, receiver/source repair loss and\ntime, immediate material and final rejection reasons.\n\nAll inserted observations reverse exactly to the original source text before\nformatting. The other 151 files are unchanged. All 107 optimized core tests,\nstrict lint and the observer build pass. Nine actual authored test executions\ncover the previous cases plus mixed positive, frozen-sheet and failed-repair\ncases. The reader rejects 22 malformed observations and checks four inventory\nmultisets. Sample partitions, proposal totals and all seven exchange counters\nmust reconcile. Original candidate decisions, work charges and limits remain.\nLogging can perturb wall deadlines and trajectories.\n\nThe committed plan opens four serial mechanical development observations,\nboth kerfs, seed zero, 60 seconds each on physical CCD0 CPU 8. Each requires\nindependent CLI validation, public exports, exact ZIP/member checks and a\nfilled-outer geometry audit. This is diagnosis, not a repeat quality trial.\nThe original failed pilot, +1% limit, 13-job gate and reserved inputs remain\nunchanged. No production integration or H5 credit; completion stays 60%.\n'
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-mixed-stage-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n## 2026-10-18 — Qualify mixed-pair sampling and repair observations\n\n[The isolated observer](benchmarks/results/h5-mixed-stage-preparation-20261018.md)\npasses 107 optimized tests, strict lint/build, nine actual authored traces,\n22 malformed-observation checks and four inventory-multiset checks. Inserted\nobservations reverse exactly; the other 151 files remain unchanged. Per-call\nsampling reasons partition every visited sample and reconcile retained\nproposals; stage observations reconcile all seven exchange counters.\n\nThe committed plan opens four serial 60-second seed-zero mechanical searches.\nThis diagnoses the rejected mixed candidate and can perturb wall deadlines;\nit does not replace the failed quality pilot. Geometry, material, time limits,\nproduction and reserved inputs remain unchanged. H2/H5 remain open at 60%.\n')
print(json.dumps({'sealed_members':len(inventory),'bytes':raw.stat().st_size}))
