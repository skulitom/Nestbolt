"""Executed by the exact-reversal instrumentation builder; no decision changes."""
generation='''#[derive(serde::Serialize)]
struct PairGenerationTrace {
    incoming_ids: Vec<usize>,
    sample_total: usize,
    seen: usize,
    invalid_pose: usize,
    boundary: usize,
    empty: usize,
    over_three: usize,
    area_rejected: usize,
    eligible: usize,
    retained: usize,
    deadline_reached: bool,
    start_remaining: f64,
    elapsed: f64,
    #[serde(skip)]
    started: Instant,
}
impl Drop for PairGenerationTrace {
    fn drop(&mut self) {
        self.elapsed = self.started.elapsed().as_secs_f64();
        eprintln!("MIXED_GENERATION {}", serde_json::to_string(self).expect("generation serialization"));
    }
}

'''
replace('struct Proposal {',generation+'struct Proposal {')
replace('''    debug_assert_eq!(incoming.len(), 2);
    let anchor''','''    debug_assert_eq!(incoming.len(), 2);
    let mut generation = PairGenerationTrace {
        incoming_ids: incoming.iter().map(|(_, item, _)| item.idx()).collect(),
        sample_total: 0, seen: 0, invalid_pose: 0, boundary: 0, empty: 0,
        over_three: 0, area_rejected: 0, eligible: 0, retained: 0,
        deadline_reached: false, start_remaining: until - clock.now(),
        elapsed: 0.0, started: Instant::now(),
    };
    let anchor''')
replace('''    let mut out = Vec::new();
    for sample in samples {
        if clock.now() >= until {
            break;
        }
        let Some(poses) = incoming_group_poses(incoming, sample) else {
            continue;''','''    let mut out = Vec::new();
    generation.sample_total = samples.len();
    for sample in samples {
        if clock.now() >= until {
            generation.deadline_reached = true;
            break;
        }
        generation.seen += 1;
        let Some(poses) = incoming_group_poses(incoming, sample) else {
            generation.invalid_pose += 1;
            continue;''')
replace('''        if !allowed || collisions.is_empty() || collisions.len() > 3 {
            continue;''','''        if !allowed || collisions.is_empty() || collisions.len() > 3 {
            if !allowed { generation.boundary += 1; }
            else if collisions.is_empty() { generation.empty += 1; }
            else { generation.over_three += 1; }
            continue;''')
replace('''        if area > incoming_area {
            continue;
        }
        retain_proposal(''','''        if area > incoming_area {
            generation.area_rejected += 1;
            continue;
        }
        generation.eligible += 1;
        retain_proposal(''')
replace('''    out
}

impl<F:''','''    generation.retained = out.len();
    out
}

impl<F:''')
