"""Add observations to the rejected balanced-pair experiment, preserving decisions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import difflib, json, shutil, sys

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
out=root/'output/h5-balanced-stage-20261018'
old=root/'output/h5-balanced-group-probe-20261018/candidate'
work=out/'workspace'
out.mkdir(exist_ok=False)
shutil.copytree(old,work)
rel='crates/core/src/sheets/vstrip/exchange.rs'
path=work/rel
original=path.read_text(encoding='utf-8');text=original;changes=[]
def replace(before,after):
    global text
    assert text.count(before)==1,before
    text=text.replace(before,after);changes.append((before,after))

types='''// Read-only diagnostic copy. Logging may perturb wall deadlines.
#[derive(Default, serde::Serialize)]
struct BalancedTrace {
    disabled_or_expired: bool,
    baseline_invalid: bool,
    before_material: Option<f64>,
    before_last_extent: Option<f32>,
    proposals: Vec<ObservedProposal>,
    attempts: Vec<ObservedAttempt>,
}
#[derive(serde::Serialize)]
struct ObservedProposal {
    paired: bool,
    target: usize,
    incoming_ids: Vec<usize>,
    returned_ids: Vec<usize>,
    blockers: usize,
    incoming_area: f32,
    returned_area: f32,
}
#[derive(serde::Serialize)]
struct ObservedAttempt {
    proposal_index: usize,
    receiver_initial_loss: Option<f32>,
    receiver_loss: Option<f32>,
    source_initial_loss: Option<f32>,
    source_loss: Option<f32>,
    after_material: Option<f64>,
    after_last_extent: Option<f32>,
    outcome: &'static str,
}
impl Drop for BalancedTrace {
    fn drop(&mut self) {
        eprintln!("BALANCED_DIAG {}", serde_json::to_string(self).expect("diagnostic serialization"));
    }
}

'''
replace('struct Proposal {',types+'struct Proposal {')
replace('''        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            return Ok(0);''','''        let mut trace = BalancedTrace::default();
        if !self.allow_exchange || shape.sheets < 2 || self.clock.now() >= self.last_step(until) {
            trace.disabled_or_expired = true;
            return Ok(0);''')
replace('''        if !baseline.valid {
            return Ok(0);''','''        if !baseline.valid {
            trace.baseline_invalid = true;
            return Ok(0);''')
replace('''        let before = baseline.metrics.as_ref().expect("valid baseline");''','''        let before = baseline.metrics.as_ref().expect("valid baseline");
        trace.before_material = Some(before.material_area);
        trace.before_last_extent = Some(strip.fit_last(&sep.layout, shape));''')
replace('''                for proposal in candidates {''','''                let proposal_base = trace.proposals.len();
                for proposal in &candidates {
                    trace.proposals.push(ObservedProposal {
                        paired, target,
                        incoming_ids: members.iter().map(|(_,item,_)|item.idx()).collect(),
                        returned_ids: proposal.victims.iter().map(|key| receiver.placed_items()[*key].item().idx()).collect(),
                        blockers: proposal.blockers,
                        incoming_area: members.iter().map(|(_,item,_)|item.area()).sum(),
                        returned_area: proposal.area,
                    });
                }
                for (proposal_number, proposal) in candidates.into_iter().enumerate() {''')
replace('''                    self.stats.paired_exchange_attempts += u64::from(paired);''','''                    self.stats.paired_exchange_attempts += u64::from(paired);
                    let index = trace.attempts.len();
                    trace.attempts.push(ObservedAttempt {
                        proposal_index: proposal_base + proposal_number,
                        receiver_initial_loss: None, receiver_loss: None,
                        source_initial_loss: None, source_loss: None,
                        after_material: None, after_last_extent: None, outcome: "unfinished",
                    });''')
replace('''                        let Some(poses) = incoming_group_poses(&members, proposal.incoming) else {
                            continue;''','''                        let Some(poses) = incoming_group_poses(&members, proposal.incoming) else {
                            trace.attempts[index].outcome = "forbidden_incoming_orientation";
                            continue;''')
replace('''                    let (receiver_snapshot, receiver_tracker) =''','''                    trace.attempts[index].receiver_initial_loss = Some(receiver_sep.tracker.total_loss());
                    let (receiver_snapshot, receiver_tracker) =''')
replace('''                    if receiver_tracker.total_loss() > 0.0 {
                        continue;''','''                    trace.attempts[index].receiver_loss = Some(receiver_tracker.total_loss());
                    if receiver_tracker.total_loss() > 0.0 {
                        trace.attempts[index].outcome = "receiver_repair_failed";
                        continue;''')
replace('''                    let (source_snapshot, source_tracker) =''','''                    trace.attempts[index].source_initial_loss = Some(source_sep.tracker.total_loss());
                    let (source_snapshot, source_tracker) =''')
replace('''                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(exchange_until)
                    {
                        continue;''','''                    trace.attempts[index].source_loss = Some(source_tracker.total_loss());
                    if source_tracker.total_loss() > 0.0
                        || self.clock.now() >= self.last_step(exchange_until)
                    {
                        trace.attempts[index].outcome = if source_tracker.total_loss() > 0.0 { "source_repair_failed" } else { "expired_after_repairs" };
                        continue;''')
replace('''                    let report = self.exchange_report(strip, frozen, &trial, shape)?;''','''                    trace.attempts[index].after_last_extent = Some(strip.fit_last(&trial, shape));
                    let report = self.exchange_report(strip, frozen, &trial, shape)?;''')
replace('''                    if !report.valid {
                        self.stats.rejected_layouts += 1;''','''                    if !report.valid {
                        trace.attempts[index].outcome = "independent_geometry_failed";
                        self.stats.rejected_layouts += 1;''')
replace('''                    let after = report.metrics.as_ref().expect("valid exchange");''','''                    let after = report.metrics.as_ref().expect("valid exchange");
                    trace.attempts[index].after_material = Some(after.material_area);''')
replace('''                    {
                        continue;
                    }
                    sep.layout = trial;''','''                    {
                        trace.attempts[index].outcome = if self.clock.now() >= exchange_until { "expired_before_acceptance" } else { "material_guard_failed" };
                        continue;
                    }
                    trace.attempts[index].outcome = "accepted";
                    sep.layout = trial;''')
reverse=text
for before,after in reversed(changes):
    assert reverse.count(after)==1
    reverse=reverse.replace(after,before)
assert reverse==original
path.write_text(text,encoding='utf-8',newline='\n')
(out/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='rejected-pair-experiment',tofile='observations-only')),encoding='utf-8',newline='\n')
files=[{'path':p.relative_to(old).as_posix(),'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(old.rglob('*')) if p.is_file()]
plan={'utc':datetime.now(timezone.utc).isoformat(),'old_source':str(old),'changed_file':rel,'source_files':files,
      'production_digest':source_digest(),'target':str(root/'output/h5-balanced-stage-target-20261018'),
      'instrumentation_reversible_to_exact_original_text':True,'proposal_repair_acceptance_settings_unchanged':True,
      'purpose':'Observe retained proposal identities, attempted repair stages, and immediate material/last-sheet extent. Distinguish identical-item multiset swaps from changed sheet assignments without assuming either improves final packing.',
      'measurement_planned':{'jobs':['m-mechanical-large-plates','m-mechanical-panel-hardware'],'kerfs':[0.2,1.5],'seed':0,'seconds':60,'cpu':8,'serial':True}}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
builder=(root/'output/build_h5_return_reuse_stage_diagnosis.py').read_text(encoding='utf-8').replace('h5-return-reuse-stage-diagnosis-20261018','h5-balanced-stage-20261018').replace('h5-return-reuse-stage-target-20261018','h5-balanced-stage-target-20261018')
(root/'output/build_h5_balanced_stage.py').write_text(builder,encoding='utf-8',newline='\n')
print(json.dumps({'instrumentation_reversible':True,'unchanged_other_source_files':len(files)-1}))
