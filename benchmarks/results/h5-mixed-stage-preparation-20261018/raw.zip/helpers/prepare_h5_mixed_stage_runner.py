"""Retain diagnostic measurement methods; validate mixed pair sampling observations."""
from pathlib import Path
import ast
root=Path(__file__).resolve().parents[1]
def adapt(s):
    return s.replace('h5-productive-stage','h5-mixed-stage').replace('h5_productive_stage','h5_mixed_stage').replace('h5-productive-exchange-pilot','h5-mixed-exchange-pilot').replace('h5_productive_exchange_pilot','h5_mixed_exchange_pilot').replace('PRODUCTIVE_DIAG ','MIXED_DIAG ')
text=adapt((root/'scripts/h5_productive_stage.py').read_text(encoding='utf-8'))
text=text.replace('productive-exchange candidate','mixed-exchange candidate')
text=text.replace('len(choices)<=6','len(choices)<=12')
text=text.replace("assert isinstance(pair,list) and len(pair)==2 and pair[0]==pair[1]\n            assert type(pair[0]) is int and inventory[pair[0]]>=2", "assert isinstance(pair,list) and len(pair)==2\n            assert all(type(i) is int and i>=0 for i in pair)\n            assert not (Counter(pair)-inventory)")
text=text.replace("                assert p['incoming_ids'][0]==p['incoming_ids'][1]\n",'')
needle="        ps=t['proposals'];seen=set()"
assert text.count(needle)==1
text=text.replace(needle,needle+"\n        assert isinstance(t['generations'],list)")
text=text.replace("            assert not ps and not t['attempts']", "            assert not ps and not t['attempts'] and not t['generations']")
needle="        for p in ps:\n"
extra='''        for g in t['generations']:
            ids=g['incoming_ids'];assert isinstance(ids,list) and len(ids)==2
            assert all(type(i) is int and i>=0 for i in ids) and ids in choices
            assert not (Counter(ids)-inventory)
            counts=['sample_total','seen','invalid_pose','boundary','empty','over_three','area_rejected','eligible','retained']
            assert all(type(g[k]) is int and g[k]>=0 for k in counts)
            assert g['seen']<=g['sample_total']
            assert g['seen']==sum(g[k] for k in ['invalid_pose','boundary','empty','over_three','area_rejected','eligible'])
            assert g['retained']<=min(6,g['eligible'])
            assert type(g['deadline_reached']) is bool
            assert g['deadline_reached']==(g['seen']<g['sample_total'])
            assert type(g['start_remaining']) in [int,float] and math.isfinite(g['start_remaining'])
            assert type(g['elapsed']) in [int,float] and math.isfinite(g['elapsed']) and g['elapsed']>=0
        assert sum(g['retained'] for g in t['generations'])==sum(p['paired'] for p in ps)
'''
assert text.count(needle)==1;text=text.replace(needle,extra+needle)
needle="    if stats is not None:\n"
assert text.count(needle)==1;text=text.replace(needle,"    mixed=[a for a in paired if len(set(a['proposal']['incoming_ids']))==2]\n"+needle+"        assert len(mixed)==stats.get('mixed_exchange_attempts',0)\n        assert sum(a['outcome']=='accepted' for a in mixed)==stats.get('mixed_exchanges',0)\n")
text=text.replace("'paired_attempts':len(paired)","'mixed_attempts':len(mixed),'mixed_accepted':sum(a['outcome']=='accepted' for a in mixed),\n        'paired_attempts':len(paired)")
needle='\ndef read_trace(archive, record):'
parse='''
def parse_log(log):
    traces=[];pending=[]
    for line in log.splitlines():
        if line.startswith('MIXED_GENERATION '):
            pending.append(json.loads(line.removeprefix('MIXED_GENERATION ')))
        elif line.startswith('MIXED_DIAG '):
            trace=json.loads(line.removeprefix('MIXED_DIAG '))
            assert 'generations' not in trace
            trace['generations']=pending;pending=[];traces.append(trace)
    assert not pending,'orphaned generation trace'
    return traces

'''
assert text.count(needle)==1;text=text.replace(needle,parse+needle)
old="        traces=[json.loads(line.removeprefix('MIXED_DIAG '))\n            for line in z.read('search-stderr.log').decode('utf-8').splitlines() if line.startswith('MIXED_DIAG ')]"
assert text.count(old)==1;text=text.replace(old,"        traces=parse_log(z.read('search-stderr.log').decode('utf-8'))")
text=text.replace('One stderr trace per invocation.','Pair sample rejection partitions and one stage trace per invocation.')
path=root/'scripts/h5_mixed_stage.py';assert not path.exists();path.write_text(text,encoding='utf-8',newline='\n');compile(text,str(path),'exec')
functions=lambda s:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
old=functions((root/'scripts/h5_productive_stage.py').read_text(encoding='utf-8'));new=functions(text)
assert old['run']==new['run'] and old['neutral']==new['neutral']
check=adapt((root/'output/check_h5_productive_stage_reader.py').read_text(encoding='utf-8'))
check=check.replace("'productive_exchange_keeps_same_inventory_when_material_decreases']", "'productive_exchange_keeps_same_inventory_when_material_decreases',\n             'mixed_pair_moves_different_parts_and_three_returns',\n             'mixed_pair_preserves_a_frozen_sheet',\n             'mixed_pair_failed_return_room_preserves_incumbent']")
old="    traces=[json.loads(line.removeprefix('MIXED_DIAG ')) for line in result.stderr.decode().splitlines() if line.startswith('MIXED_DIAG ')]"
assert check.count(old)==1;check=check.replace(old,"    traces=runner.parse_log(result.stderr.decode())")
check=check.replace("rejects('two different incoming part types'", "rejects('unavailable incoming original item'")
needle='# Multiset equality retains multiplicity'
extra='''assert summary['mixed_accepted']>=5
assert summary['mixed_attempts']>=summary['mixed_accepted']
mixed_trace=next(t for t in all_traces if any(len(set(g['incoming_ids']))==2 for g in t['generations']))
def rejects_generation(name,mutate):
    t=copy.deepcopy(mixed_trace);mutate(t['generations'][0])
    try:runner.check_traces([t])
    except AssertionError:return name
    raise AssertionError('Reader accepted '+name)
rejected += [
    rejects_generation('sample partition mismatch',lambda g:g.update(seen=g['seen']+1)),
    rejects_generation('negative sampling count',lambda g:g.update(boundary=-1)),
    rejects_generation('unrecorded deadline truncation',lambda g:g.update(deadline_reached=not g['deadline_reached'])),
    rejects_generation('impossible retained count',lambda g:g.update(retained=7)),
    rejects_generation('unavailable generated pair',lambda g:g.update(incoming_ids=[999999,999999])),
    rejects_generation('nonfinite generation time',lambda g:g.update(elapsed=float('nan'))),
]
try:runner.parse_log('MIXED_GENERATION {}')
except AssertionError:rejected.append('orphaned generation trace')
else:raise AssertionError('Reader accepted orphaned generation trace')
try:runner.check_traces([mixed_trace],{'mixed_exchange_attempts':999999})
except AssertionError:rejected.append('inconsistent mixed counters')
else:raise AssertionError('Reader accepted inconsistent mixed counters')
'''
assert check.count(needle)==1;check=check.replace(needle,extra+needle)
check=check.replace("'identity_multiset_checks':4,", "'identity_multiset_checks':4,'mixed_accepted_observed':summary['mixed_accepted'],")
path=root/'output/check_h5_mixed_stage_reader.py';path.write_text(check,encoding='utf-8',newline='\n');compile(check,str(path),'exec')
print('Measurement function unchanged; reader prepared for nine authored tests and 22 malformed cases')
