"""Prepare sealing and exact-archive checks for mixed-pair observations."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def adapt(s):return s.replace('h5-productive-stage','h5-mixed-stage').replace('h5_productive_stage','h5_mixed_stage')
s=adapt((root/'output/seal_h5_productive_stage.py').read_text(encoding='utf-8'))
s=s.replace('101 passed; 0 failed','107 passed; 0 failed').replace("len(reader['authored_test_traces'])==6","len(reader['authored_test_traces'])==9").replace("len(reader['malformed_records_rejected'])==14","len(reader['malformed_records_rejected'])==22")
s=s.replace("'optimized_core_tests_passed':101","'optimized_core_tests_passed':107").replace("'authored_test_traces':6,'malformed_records_rejected':14","'authored_test_traces':9,'malformed_records_rejected':22")
s=s.replace("inventory={name:","files['helpers/generation-insertions.py']=root/'output/mixed_generation_instrumentation.py'\nfiles['helpers/generate-prepare.py']=root/'output/prepare_h5_mixed_stage_generation.py'\nfiles['helpers/productive-prepare-template.py']=root/'output/prepare_h5_productive_stage.py'\ninventory={name:")
start=s.index('doc=');end=s.index("\n(out.parent",start)
doc='''# Mixed-pair sampling and repair observations — preparation, 2026-10-18

The [mixed-part pilot](h5-mixed-exchange-pilot-20261018.md) validates all 72
outcomes but fails the four mechanical material pairs. Eleven attempted mixed
exchanges accept none. These aggregate counters do not locate the rejection.

This separate diagnostic copy records every paired proposal-generation call:
incoming item IDs, generated/visited samples, invalid poses, stock-boundary
collisions, empty obstruction sets, sets over three parts, excessive returned
area, eligible candidates, retained proposals and deadline truncation. The
reasons form an exhaustive ordered partition of visited samples. A boundary
collision takes precedence over an oversized set when both occur. Sampling
duration includes setup and group-anchor construction. It is not a minimum
time requirement. Existing stage observations also retain source inventories,
bounded pair choices, proposal identities, receiver/source repair loss and
time, immediate material and final rejection reasons.

All inserted observations reverse exactly to the original source text before
formatting. The other 151 files are unchanged. All 107 optimized core tests,
strict lint and the observer build pass. Nine actual authored test executions
cover the previous cases plus mixed positive, frozen-sheet and failed-repair
cases. The reader rejects 22 malformed observations and checks four inventory
multisets. Sample partitions, proposal totals and all seven exchange counters
must reconcile. Original candidate decisions, work charges and limits remain.
Logging can perturb wall deadlines and trajectories.

The committed plan opens four serial mechanical development observations,
both kerfs, seed zero, 60 seconds each on physical CCD0 CPU 8. Each requires
independent CLI validation, public exports, exact ZIP/member checks and a
filled-outer geometry audit. This is diagnosis, not a repeat quality trial.
The original failed pilot, +1% limit, 13-job gate and reserved inputs remain
unchanged. No production integration or H5 credit; completion stays 60%.
'''
s=s[:start]+'doc='+repr(doc)+s[end:]
start=s.index("with (root/'BENCHMARKS.md')");end=s.index('print(json.dumps',start)
entry='''

## 2026-10-18 — Qualify mixed-pair sampling and repair observations

[The isolated observer](benchmarks/results/h5-mixed-stage-preparation-20261018.md)
passes 107 optimized tests, strict lint/build, nine actual authored traces,
22 malformed-observation checks and four inventory-multiset checks. Inserted
observations reverse exactly; the other 151 files remain unchanged. Per-call
sampling reasons partition every visited sample and reconcile retained
proposals; stage observations reconcile all seven exchange counters.

The committed plan opens four serial 60-second seed-zero mechanical searches.
This diagnoses the rejected mixed candidate and can perturb wall deadlines;
it does not replace the failed quality pilot. Geometry, material, time limits,
production and reserved inputs remain unchanged. H2/H5 remain open at 60%.
'''
s=s[:start]+"with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\\n') as f:f.write("+repr(entry)+")\n"+s[end:]
p=root/'output/seal_h5_mixed_stage.py';p.write_text(s,encoding='utf-8',newline='\n');compile(s,str(p),'exec')
s=adapt((root/'output/finish_h5_productive_stage.py').read_text(encoding='utf-8'))
s=s.replace('# Productive-exchange choices and repair allocations','# Mixed-pair sampling and repair observations')
idx=s.index("(out.parent/(out.name+'.md')).write_text")
extra='''generation_rows=[]
for row in result['records']:
    for call,t in enumerate(row['diagnosis']['traces']):
        for index,g in enumerate(t['generations']):
            generation_rows.append({'job':row['job'],'kerf_mm':row['kerf_mm'],
                'call':call,'generation':index,'mixed':len(set(g['incoming_ids']))==2,**g})
write(out/'observed-generations.json',{'records':generation_rows,
    'partition_precedence':['invalid_pose','boundary','empty','over_three','area_rejected','eligible'],
    'logging_can_perturb_deadlines':True,'quality_claim':False})
lines += ['## Paired sample rejection partition','',
    '| Job | Kerf | Pair kind | Calls | Visited / total | Invalid pose | Boundary | Empty | Over 3 | Returned area | Eligible | Retained | Truncated calls |',
    '| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for row in result['records']:
    for mixed in [False,True]:
        gs=[g for g in generation_rows if (g['job'],g['kerf_mm'],g['mixed'])==(row['job'],row['kerf_mm'],mixed)]
        total=lambda k:sum(g[k] for g in gs)
        lines.append(f"| {row['job']} | {row['kerf_mm']} | {'mixed' if mixed else 'same'} | {len(gs)} | {total('seen')} / {total('sample_total')} | {total('invalid_pose')} | {total('boundary')} | {total('empty')} | {total('over_three')} | {total('area_rejected')} | {total('eligible')} | {total('retained')} | {total('deadline_reached')} |")
lines += ['', 'Reasons partition visited samples in the displayed order. Boundary collisions',
    'take precedence when an oversized set also occurs. An empty set needs no exchange',
    'and is skipped by this proposal routine. Retained proposals may never be attempted',
    'when the phase expires. Counts do not establish causality or global infeasibility.','']
'''
s=s[:idx]+extra+s[idx:]
p=root/'output/finish_h5_mixed_stage.py';p.write_text(s,encoding='utf-8',newline='\n');compile(s,str(p),'exec')
s=adapt((root/'output/audit_h5_productive_stage.py').read_text(encoding='utf-8'))
p=root/'output/audit_h5_mixed_stage.py';p.write_text(s,encoding='utf-8',newline='\n');compile(s,str(p),'exec')
print('Sealer, exact-archive report and independent geometry audit prepared')
