"""Prepare read-only mixed-pair sampling observations in a separate workspace."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/prepare_h5_productive_stage.py').read_text(encoding='utf-8')
s=s.replace('h5-productive-stage','h5-mixed-stage').replace('h5_productive_stage','h5_mixed_stage')
s=s.replace('h5-productive-exchange-probe','h5-mixed-exchange-probe')
s=s.replace("replace('''        let mut choices = incoming_pairs(&sep.layout, &incoming_keys);''','''        let mut choices = incoming_pairs(&sep.layout, &incoming_keys);", "replace('''        choices.extend(incoming_keys.into_iter().map(|key| vec![key]));''','''")
s=s.replace("        trace.pair_phase_remaining = Some(group_until - now);''')", "        trace.pair_phase_remaining = Some(group_until - now);\n        choices.extend(incoming_keys.into_iter().map(|key| vec![key]));''')")
s=s.replace("text=text.replace('BALANCED_DIAG ',", "exec(compile((root/'output/mixed_generation_instrumentation.py').read_text(encoding='utf-8'),'<sampling observations>','exec'))\ntext=text.replace('BALANCED_DIAG ',")
s=s.replace('PRODUCTIVE_DIAG ','MIXED_DIAG ').replace("'original_tests':101","'original_tests':107")
s=s.replace("Observe choices, repair allocations and rejection stages without changing decisions.","Observe mixed-pair sample rejection reasons, choices and repair allocations without changing decisions.")
p=root/'output/prepare_h5_mixed_stage.py';p.write_text(s,encoding='utf-8',newline='\n');compile(s,str(p),'exec')
print('Separate observation preparation generated; no search launched')
