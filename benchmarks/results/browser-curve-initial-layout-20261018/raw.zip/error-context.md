# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: features.spec.ts >> DXF and SVG import; exports keep arcs and curves
- Location: tests/features.spec.ts:206:1

# Error details

```
Error: nesting failed: Error: no complete layout within 5 s: these parts are many or detailed; allow more time
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - heading "Nestbolt" [level=1] [ref=e5]
    - textbox "Project name" [ref=e6]: Untitled project
    - button "Save" [ref=e7] [cursor=pointer]
    - combobox "Open saved project" [ref=e8]:
      - option "Open saved…" [selected]
    - button "Delete" [disabled] [ref=e9]
    - button "Project ZIP" [ref=e10] [cursor=pointer]
    - button "Open ZIP" [ref=e11] [cursor=pointer]
    - button "New" [ref=e12] [cursor=pointer]
  - paragraph [ref=e13]: Free, open-source nesting for laser, CNC and other sheet cutting. Everything runs in this browser; files are never uploaded.
  - main [ref=e14]:
    - complementary [ref=e15]:
      - region [ref=e16]:
        - heading "Parts" [level=2] [ref=e17]
        - generic [ref=e18] [cursor=pointer]:
          - button "Import SVG, DXF or LightBurn (or drop files here)" [ref=e19]
          - text: Import SVG, DXF or LightBurn (or drop files here)
        - generic [ref=e20]:
          - generic [ref=e21]:
            - checkbox "Close larger gaps" [ref=e22]
            - text: Close larger gaps
          - paragraph [ref=e23]: Gaps up to 0.005 mm join automatically. Larger repairs are listed with their positions.
          - group [ref=e24]:
            - generic "Layers and colours — plate-in.dxf" [ref=e25] [cursor=pointer]
            - paragraph [ref=e26]: "File units: 25.4 mm per drawing unit."
            - paragraph [ref=e27]: "Cleanup: 0 duplicate segments removed; 0 zero-length segments removed; 0 collinear overlaps merged."
            - paragraph [ref=e28]: Automatic selection prefers cut, outline and profile layers. Tick a choice to set a filter; layer and colour filters apply together. Counts include ignored entities.
            - group "Cut layers (automatic)" [ref=e29]:
              - generic [ref=e31]:
                - checkbox "Layer OVAL in plate-in.dxf" [checked] [ref=e32]
                - text: OVAL
                - generic [ref=e33]: 1 entities · 1 selected outlines/paths
              - generic [ref=e34]:
                - checkbox "Layer PLATE in plate-in.dxf" [checked] [ref=e35]
                - text: PLATE
                - generic [ref=e36]: 2 entities · 2 selected outlines/paths
              - generic [ref=e37]:
                - checkbox "Layer SLOT in plate-in.dxf" [checked] [ref=e38]
                - text: SLOT
                - generic [ref=e39]: 4 entities · 4 selected outlines/paths
            - group "Cut colours (automatic)" [ref=e40]:
              - generic [ref=e42]:
                - checkbox "Colour aci:7 in plate-in.dxf" [checked] [ref=e43]
                - text: aci:7
                - generic [ref=e44]: 7 entities · 7 selected outlines/paths
            - group "Sheet outline layers (automatic SHEET)" [ref=e45]:
              - generic [ref=e47]:
                - checkbox "Sheet layer OVAL in plate-in.dxf" [ref=e48]
                - text: OVAL
              - generic [ref=e49]:
                - checkbox "Sheet layer PLATE in plate-in.dxf" [ref=e50]
                - text: PLATE
              - generic [ref=e51]:
                - checkbox "Sheet layer SLOT in plate-in.dxf" [ref=e52]
                - text: SLOT
            - button "Use automatic selection for plate-in.dxf" [ref=e53] [cursor=pointer]
          - group [ref=e54]:
            - generic "Layers and colours — curves-mm.svg" [ref=e55] [cursor=pointer]
            - paragraph [ref=e56]: "Cleanup: 0 duplicate segments removed; 0 zero-length segments removed; 0 collinear overlaps merged."
            - paragraph [ref=e57]: Automatic selection prefers cut, outline and profile layers. Tick a choice to set a filter; layer and colour filters apply together. Counts include ignored entities.
            - group "Cut layers (automatic)" [ref=e58]:
              - generic [ref=e60]:
                - checkbox "Layer 0 in curves-mm.svg" [checked] [ref=e61]
                - text: "0"
                - generic [ref=e62]: 5 entities · 5 selected outlines/paths
            - group "Cut colours (automatic)" [ref=e63]:
              - generic [ref=e65]:
                - 'checkbox "Colour #000000 in curves-mm.svg" [checked] [ref=e66]'
                - text: "#000000"
                - generic [ref=e67]: 5 entities · 5 selected outlines/paths
            - group "Sheet outline layers (automatic SHEET)" [ref=e68]:
              - generic [ref=e70]:
                - checkbox "Sheet layer 0 in curves-mm.svg" [ref=e71]
                - text: "0"
            - button "Use automatic selection for curves-mm.svg" [ref=e72] [cursor=pointer]
          - button "Apply import options" [ref=e73] [cursor=pointer]
        - list [ref=e74]:
          - listitem [ref=e75]: "plate-in.dxf: undefined layer \"OVAL\" is referenced by 1 DXF record(s); default layer properties are assumed. Define the layer or re-export to preserve its colour and visibility"
          - listitem [ref=e76]: "plate-in.dxf: undefined layer \"PLATE\" is referenced by 2 DXF record(s); default layer properties are assumed. Define the layer or re-export to preserve its colour and visibility"
          - listitem [ref=e77]: "plate-in.dxf: undefined layer \"SLOT\" is referenced by 4 DXF record(s); default layer properties are assumed. Define the layer or re-export to preserve its colour and visibility"
        - table [ref=e78]:
          - rowgroup [ref=e79]:
            - row [ref=e80]:
              - columnheader [ref=e81]
              - columnheader "Part" [ref=e82]
              - columnheader "Qty" [ref=e83]
              - columnheader "Rotation" [ref=e84]
              - columnheader "Mirror" [ref=e85]
              - columnheader [ref=e86]
          - rowgroup [ref=e87]:
            - row [ref=e88]:
              - cell [ref=e89]
              - cell "PLATE (plate-in-1) 59.1 cm²" [ref=e92]:
                - text: PLATE (plate-in-1)
                - generic [ref=e93]: 59.1 cm²
              - cell [ref=e94]:
                - spinbutton "Quantity of plate-in-1" [ref=e95]: "1"
              - cell "0/90/180/270°" [ref=e96]:
                - combobox "Rotations of plate-in-1" [ref=e97]:
                  - option "0/90/180/270°" [selected]
                  - option "0/180° (grain)"
                  - option "Fixed 0°"
                  - option "Every 15°"
                  - option "Free"
              - cell [ref=e98]:
                - checkbox "Allow mirroring plate-in-1" [ref=e99]
              - cell [ref=e100]:
                - button "Remove plate-in-1" [ref=e101] [cursor=pointer]: ×
            - row [ref=e102]:
              - cell [ref=e103]
              - cell "OVAL (plate-in-2) 22.8 cm²" [ref=e106]:
                - text: OVAL (plate-in-2)
                - generic [ref=e107]: 22.8 cm²
              - cell [ref=e108]:
                - spinbutton "Quantity of plate-in-2" [ref=e109]: "1"
              - cell "0/90/180/270°" [ref=e110]:
                - combobox "Rotations of plate-in-2" [ref=e111]:
                  - option "0/90/180/270°" [selected]
                  - option "0/180° (grain)"
                  - option "Fixed 0°"
                  - option "Every 15°"
                  - option "Free"
              - cell [ref=e112]:
                - checkbox "Allow mirroring plate-in-2" [ref=e113]
              - cell [ref=e114]:
                - button "Remove plate-in-2" [ref=e115] [cursor=pointer]: ×
            - row [ref=e116]:
              - cell [ref=e117]
              - cell "SLOT (plate-in-3) 24.4 cm²" [ref=e120]:
                - text: SLOT (plate-in-3)
                - generic [ref=e121]: 24.4 cm²
              - cell [ref=e122]:
                - spinbutton "Quantity of plate-in-3" [ref=e123]: "1"
              - cell "0/90/180/270°" [ref=e124]:
                - combobox "Rotations of plate-in-3" [ref=e125]:
                  - option "0/90/180/270°" [selected]
                  - option "0/180° (grain)"
                  - option "Fixed 0°"
                  - option "Every 15°"
                  - option "Free"
              - cell [ref=e126]:
                - checkbox "Allow mirroring plate-in-3" [ref=e127]
              - cell [ref=e128]:
                - button "Remove plate-in-3" [ref=e129] [cursor=pointer]: ×
            - row [ref=e130]:
              - cell [ref=e131]
              - cell "rounded (curves-mm-1) 23.4 cm²" [ref=e134]:
                - text: rounded (curves-mm-1)
                - generic [ref=e135]: 23.4 cm²
              - cell [ref=e136]:
                - spinbutton "Quantity of curves-mm-1" [ref=e137]: "1"
              - cell "0/90/180/270°" [ref=e138]:
                - combobox "Rotations of curves-mm-1" [ref=e139]:
                  - option "0/90/180/270°" [selected]
                  - option "0/180° (grain)"
                  - option "Fixed 0°"
                  - option "Every 15°"
                  - option "Free"
              - cell [ref=e140]:
                - checkbox "Allow mirroring curves-mm-1" [ref=e141]
              - cell [ref=e142]:
                - button "Remove curves-mm-1" [ref=e143] [cursor=pointer]: ×
            - row [ref=e144]:
              - cell [ref=e145]
              - cell "disc (curves-mm-2) 10.2 cm²" [ref=e148]:
                - text: disc (curves-mm-2)
                - generic [ref=e149]: 10.2 cm²
              - cell [ref=e150]:
                - spinbutton "Quantity of curves-mm-2" [ref=e151]: "1"
              - cell "0/90/180/270°" [ref=e152]:
                - combobox "Rotations of curves-mm-2" [ref=e153]:
                  - option "0/90/180/270°" [selected]
                  - option "0/180° (grain)"
                  - option "Fixed 0°"
                  - option "Every 15°"
                  - option "Free"
              - cell [ref=e154]:
                - checkbox "Allow mirroring curves-mm-2" [ref=e155]
              - cell [ref=e156]:
                - button "Remove curves-mm-2" [ref=e157] [cursor=pointer]: ×
            - row [ref=e158]:
              - cell [ref=e159]
              - cell "oval (curves-mm-3) 14.1 cm²" [ref=e162]:
                - text: oval (curves-mm-3)
                - generic [ref=e163]: 14.1 cm²
              - cell [ref=e164]:
                - spinbutton "Quantity of curves-mm-3" [ref=e165]: "1"
              - cell "0/90/180/270°" [ref=e166]:
                - combobox "Rotations of curves-mm-3" [ref=e167]:
                  - option "0/90/180/270°" [selected]
                  - option "0/180° (grain)"
                  - option "Fixed 0°"
                  - option "Every 15°"
                  - option "Free"
              - cell [ref=e168]:
                - checkbox "Allow mirroring curves-mm-3" [ref=e169]
              - cell [ref=e170]:
                - button "Remove curves-mm-3" [ref=e171] [cursor=pointer]: ×
            - row [ref=e172]:
              - cell [ref=e173]
              - cell "bezier (curves-mm-4) 40.3 cm²" [ref=e176]:
                - text: bezier (curves-mm-4)
                - generic [ref=e177]: 40.3 cm²
              - cell [ref=e178]:
                - spinbutton "Quantity of curves-mm-4" [ref=e179]: "1"
              - cell "0/90/180/270°" [ref=e180]:
                - combobox "Rotations of curves-mm-4" [ref=e181]:
                  - option "0/90/180/270°" [selected]
                  - option "0/180° (grain)"
                  - option "Fixed 0°"
                  - option "Every 15°"
                  - option "Free"
              - cell [ref=e182]:
                - checkbox "Allow mirroring curves-mm-4" [ref=e183]
              - cell [ref=e184]:
                - button "Remove curves-mm-4" [ref=e185] [cursor=pointer]: ×
            - row [ref=e186]:
              - cell [ref=e187]
              - cell "frame (curves-mm-5) 18.0 cm²" [ref=e190]:
                - text: frame (curves-mm-5)
                - generic [ref=e191]: 18.0 cm²
              - cell [ref=e192]:
                - spinbutton "Quantity of curves-mm-5" [ref=e193]: "1"
              - cell "0/90/180/270°" [ref=e194]:
                - combobox "Rotations of curves-mm-5" [ref=e195]:
                  - option "0/90/180/270°" [selected]
                  - option "0/180° (grain)"
                  - option "Fixed 0°"
                  - option "Every 15°"
                  - option "Free"
              - cell [ref=e196]:
                - checkbox "Allow mirroring curves-mm-5" [ref=e197]
              - cell [ref=e198]:
                - button "Remove curves-mm-5" [ref=e199] [cursor=pointer]: ×
      - region [ref=e200]:
        - heading "Sheets" [level=2] [ref=e201]
        - group "Sheet size 1" [ref=e202]:
          - generic [ref=e204]:
            - text: Width
            - spinbutton "Width mm" [ref=e205]: "400"
            - text: mm
          - generic [ref=e206]:
            - text: Height
            - spinbutton "Height mm" [ref=e207]: "300"
            - text: mm
          - generic [ref=e208]:
            - text: Count
            - spinbutton "Count" [ref=e209]
          - generic [ref=e210]:
            - text: Margin
            - spinbutton "Margin mm" [ref=e211]: "5"
            - text: mm
          - generic [ref=e212]:
            - text: Remnant outline
            - button "Remnant outline for sheet size 1" [ref=e213]
          - group [ref=e214]:
            - generic "Defects (0)" [ref=e215]
        - combobox "Add a sheet size" [ref=e216]:
          - option "Add sheet size…" [selected]
          - option "Diode laser 300×200"
          - option "CO2 bed 600×400"
          - option "Plywood 1220×2440"
          - option "Sheet metal 1250×2500"
          - option "Sheet metal 1500×3000"
          - option "Fabric roll 1500 × 10 m"
      - region [ref=e217]:
        - heading "Settings" [level=2] [ref=e218]
        - generic [ref=e219]:
          - generic [ref=e220]:
            - text: Part spacing
            - spinbutton "Part spacing mm" [ref=e221]: "1"
            - text: mm
          - generic [ref=e222]:
            - text: Edge spacing
            - spinbutton "Edge spacing mm" [ref=e223]: "1"
            - text: mm
          - generic [ref=e224]:
            - text: Goal
            - combobox "Goal" [ref=e225]:
              - option "Place every part" [selected]
              - option "Fill the sheets (most area)"
              - option "Fill by priority"
          - generic [ref=e226]:
            - text: Time
            - spinbutton "Time s" [ref=e227]: "5"
            - text: s
        - generic [ref=e228]:
          - checkbox "Common-line cutting" [ref=e229]
          - text: Common-line cutting
        - generic [ref=e230]:
          - checkbox "Lead-in allowances" [ref=e231]
          - text: Lead-in allowances
        - group [ref=e232]:
          - generic "Advanced" [ref=e233] [cursor=pointer]
          - generic [ref=e234]:
            - checkbox "Quick initial layout" [ref=e235]
            - text: Quick initial layout
          - paragraph [ref=e236]: Start with a simple arrangement, then improve it. May use more material.
          - generic [ref=e237]:
            - generic "Complex drawings and large quantities use fewer workers to limit memory" [ref=e238]:
              - text: Workers
              - spinbutton "Workers" [ref=e239]: "1"
            - generic [ref=e240]:
              - text: Seed
              - spinbutton "Seed" [ref=e241]: "0"
            - generic [ref=e242]:
              - checkbox "Repeatable" [ref=e243]
              - text: Repeatable
      - button "Nest" [ref=e245] [cursor=pointer]
      - alert [ref=e246]: "Error: no complete layout within 5 s: these parts are many or detailed; allow more time"
    - region [ref=e247]:
      - heading "Result" [level=2] [ref=e248]
      - paragraph [ref=e249]: Import parts, choose sheets and press Nest, or try the example boxes.
  - contentinfo [ref=e250]:
    - text: Built on
    - link "jagua-rs" [ref=e251] [cursor=pointer]:
      - /url: https://github.com/JeroenGar/jagua-rs
    - text: and
    - link "sparrow" [ref=e252] [cursor=pointer]:
      - /url: https://github.com/JeroenGar/sparrow
    - text: by Jeroen Gardeyn et al. MIT licensed;
    - link "third-party notices" [ref=e253] [cursor=pointer]:
      - /url: ./THIRD_PARTY_NOTICES.txt
    - text: .
    - link "Benchmark results" [ref=e254] [cursor=pointer]:
      - /url: ./results/
    - text: against Deepnest, SVGnest and Sparrow.
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { readFileSync } from 'node:fs';
  3   | import { fileURLToPath } from 'node:url';
  4   | import { zip } from '../src/zip.js';
  5   | import type { Project } from '../src/types.js';
  6   | 
  7   | // One end-to-end test per v1 feature through the browser app (the CLI has the
  8   | // same set in crates/cli/tests/features.rs). examples/parts.svg imports as
  9   | // parts-1 frame (80 x 60, 60 x 40 window), parts-2 washer (24 mm), parts-3
  10  | // bracket and parts-4 elliptical tab.
  11  | const example = (name: string) => fileURLToPath(new URL(`../../examples/${name}`, import.meta.url));
  12  | const fixture = (name: string) => fileURLToPath(new URL(`./fixtures/${name}`, import.meta.url));
  13  | 
  14  | type Layout = { sheets: { id: string; stock_id: string }[];
  15  |   placements: { part_id: string; transform: { rotation_radians: number; mirrored: boolean } }[] };
  16  | type ProjectFile = { request: { quick_start?: boolean; common_line?: { kerf_mm: number; search_bonus?: boolean }; spacing_mm: number; edge_spacing_mm: number; sheets: { count?: number | null }[] };
  17  |   result: { layout: Layout; validation: { valid: boolean } } };
  18  | 
  19  | /** Read one entry of the app's stored (uncompressed) ZIP. */
  20  | function zipEntry(path: string, wanted: string): string {
  21  |   const bytes = readFileSync(path);
  22  |   for (let at = 0; bytes.readUInt32LE(at) === 0x04034b50;) {
  23  |     const size = bytes.readUInt32LE(at + 18);
  24  |     const nameLength = bytes.readUInt16LE(at + 26);
  25  |     const extra = bytes.readUInt16LE(at + 28);
  26  |     const name = bytes.subarray(at + 30, at + 30 + nameLength).toString('utf8');
  27  |     const start = at + 30 + nameLength + extra;
  28  |     if (name === wanted) return bytes.subarray(start, start + size).toString('utf8');
  29  |     at = start + size;
  30  |   }
  31  |   throw new Error(`${wanted} not in ${path}`);
  32  | }
  33  | 
  34  | async function project(page: Page): Promise<ProjectFile> {
  35  |   const [archive] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Project ZIP' }).click()]);
  36  |   return JSON.parse(zipEntry(await archive.path(), 'project.json'));
  37  | }
  38  | 
  39  | /** Import files, keep only the given parts with quantities, one sheet size, one worker. */
  40  | async function setUp(page: Page, files: string[], keep: Record<string, number>, w: number, h: number, seconds = 5) {
  41  |   await page.goto('/');
  42  |   await page.locator('.drop input[type=file]').setInputFiles(files);
  43  |   await expect(page.locator('table.parts tbody tr').first()).toBeVisible();
  44  |   const ids = await page.getByRole('button', { name: /^Remove / }).evaluateAll((buttons) =>
  45  |     buttons.map((b) => b.getAttribute('aria-label')!.replace('Remove ', '')));
  46  |   for (const id of ids.filter((id) => !(id in keep))) {
  47  |     await page.getByRole('button', { name: `Remove ${id}`, exact: true }).click();
  48  |   }
  49  |   for (const [id, quantity] of Object.entries(keep)) await page.getByLabel(`Quantity of ${id}`).fill(String(quantity));
  50  |   const sheet = page.locator('fieldset.sheet-row').first();
  51  |   await sheet.getByLabel('Width').fill(String(w));
  52  |   await sheet.getByLabel('Height').fill(String(h));
  53  |   await page.getByLabel('Time').fill(String(seconds));
  54  |   await page.getByText('Advanced').click();
  55  |   await page.getByLabel('Workers').fill('1');
  56  |   return sheet;
  57  | }
  58  | 
  59  | async function nest(page: Page) {
  60  |   await page.getByRole('button', { name: 'Nest' }).click();
  61  |   // Lead review flags also use .error; only the app alert means nesting failed.
  62  |   await expect(page.locator('.summary, [role="alert"]').first()).toBeVisible({ timeout: 90_000 });
> 63  |   if (await page.getByRole('alert').count()) throw new Error(`nesting failed: ${await page.getByRole('alert').innerText()}`);
      |                                                    ^ Error: nesting failed: Error: no complete layout within 5 s: these parts are many or detailed; allow more time
  64  |   await expect(page.locator('.summary')).toContainText('valid');
  65  | }
  66  | 
  67  | const metric = async (page: Page, name: string) =>
  68  |   Number(await page.locator('.summary div', { hasText: name }).locator('dd').innerText());
  69  | 
  70  | test('lead allowances expose flags, reserve offcuts and export a separate review layer', async ({ page }, testInfo) => {
  71  |   const source = fileURLToPath(new URL('../../crates/core/tests/fixtures/leads.svg', import.meta.url));
  72  |   // Exercise lead behavior with the usual five-second functional-test budget.
  73  |   // One second can expire before a complete layout exists on shared CI runners.
  74  |   const sheet = await setUp(page, [source], { 'leads-1': 2 }, 60, 35);
  75  |   await sheet.getByLabel('Margin').fill('0');
  76  |   await page.getByLabel('Lead-in allowances', { exact: true }).check();
  77  |   await expect(page.getByRole('button', { name: 'Nest', exact: true })).toBeDisabled();
  78  |   await page.getByLabel('Lead kerf').fill('0.2');
  79  |   await page.getByLabel('Lead length').fill('0.4');
  80  |   await expect(page.getByRole('button', { name: 'Nest', exact: true })).toBeDisabled();
  81  |   await page.getByLabel('Lead length').fill('3');
  82  |   await page.getByLabel('Outer lead angle').fill('45.001');
  83  |   await expect(page.getByRole('button', { name: 'Nest', exact: true })).toBeDisabled();
  84  |   await page.getByLabel('Outer lead angle').fill('45');
  85  |   await page.getByLabel('Lead style').selectOption('arc');
  86  |   await nest(page);
  87  |   await expect(page.locator('.lead-report')).toContainText('4/6 contours have checked space', { timeout: 90_000 });
  88  |   await expect(page.locator('.lead-report')).toContainText('2 need manual attention');
  89  |   await expect(page.locator('.lead-preview')).toHaveCount(4);
  90  |   expect(await page.locator('svg.sheet').first().evaluate(el => el.getBoundingClientRect().height)).toBeGreaterThan(150);
  91  |   await expect(page.locator('[role=alert]')).toHaveCount(0);
  92  |   const [archive] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Project ZIP' }).click()]);
  93  |   const saved = JSON.parse(zipEntry(await archive.path(), 'project.json'));
  94  |   expect(saved.request.lead_in.style).toBe('arc');
  95  |   expect(saved.result.validation.metrics.placed_area).toBeCloseTo(391.68, 5);
  96  |   expect(saved.result.lead_in.validation.valid).toBe(true);
  97  |   expect(saved.result.lead_in.validation.source_checked).toBe(true);
  98  |   expect(saved.result.lead_in.validation.coverage).toEqual({ expected_contours: 6, reserved_contours: 4, flagged_contours: 2 });
  99  |   expect(saved.result.lead_in.parts.flatMap((p: { reservations: { shortened: boolean }[] }) => p.reservations).filter((r: { shortened: boolean }) => r.shortened)).toHaveLength(2);
  100 |   await expect(page.locator('.lead-report')).toContainText('1.2 mm lead.');
  101 |   const svg = zipEntry(await archive.path(), `sheets/${saved.result.layout.sheets[0].id}.svg`);
  102 |   expect(svg).toContain('id="LEADIN"');expect(svg).toContain('stroke="#ff0000"');
  103 |   const dxf = zipEntry(await archive.path(), `sheets/${saved.result.layout.sheets[0].id}.dxf`);
  104 |   expect(dxf).toContain('LEADIN');
  105 |   await testInfo.attach('lead-project', { body: JSON.stringify(saved), contentType: 'application/json' });
  106 |   await testInfo.attach('lead-controls', { body: await page.screenshot({ fullPage: true }), contentType: 'image/png' });
  107 |   await page.locator('.results').evaluate(el => el.scrollTo(0, el.scrollHeight));
  108 |   await testInfo.attach('lead-preview', { body: await page.screenshot({ fullPage: true }), contentType: 'image/png' });
  109 |   await page.getByLabel('Common-line cutting', { exact: true }).check();
  110 |   await page.getByLabel('Kerf mm', { exact: true }).fill('0.3');
  111 |   await expect(page.getByLabel('Lead kerf')).toHaveValue('0.3');
  112 |   await page.getByLabel('Lead-in allowances', { exact: true }).uncheck();
  113 |   await expect(page.locator('.lead-report')).toHaveCount(0);
  114 | });
  115 | 
  116 | for (const bonus of [false, true]) {
  117 | test(`common-line kerf overrides spacing and exports its own compensated layer (bonus ${bonus})`, async ({ page }, testInfo) => {
  118 |   const source = fileURLToPath(new URL('../../crates/core/tests/fixtures/common-panels.svg', import.meta.url));
  119 |   const sheet = await setUp(page, [source], { 'common-panels-1': 2 }, 86, 36, 1);
  120 |   await sheet.getByLabel('Margin').fill('0');
  121 |   await page.getByLabel('Repeatable', { exact: true }).check();
  122 |   await page.getByLabel('Part spacing').fill('5');
  123 |   await page.getByLabel('Common-line cutting', { exact: true }).check();
  124 |   await expect(page.getByRole('button', { name: 'Nest', exact: true })).toBeDisabled();
  125 |   await expect(page.getByLabel('Search for more shared cuts')).not.toBeChecked();
  126 |   if (bonus) await page.getByLabel('Search for more shared cuts').check();
  127 |   await page.getByLabel('Kerf mm', { exact: true }).fill('0.2');
  128 |   await expect(page.getByLabel('Search for more shared cuts')).toBeChecked({ checked: bonus });
  129 |   await expect(page.getByLabel('Part spacing')).toBeDisabled();
  130 |   await expect(page.getByLabel('Part spacing')).toHaveValue('0.2');
  131 |   await nest(page);
  132 |   const saved = await project(page);
  133 |   expect(!!saved.request.common_line?.search_bonus).toBe(bonus);
  134 |   await testInfo.attach('common-line-project', { body: JSON.stringify(saved), contentType: 'application/json' });
  135 |   await expect(page.locator('.common-line-report')).toContainText('30.0 mm saved');
  136 |   const [archive] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Download all sheets (ZIP)' }).click()]);
  137 |   const svg = zipEntry(await archive.path(), `sheets/${saved.result.layout.sheets[0].id}.svg`);
  138 |   expect(svg).toContain('id="COMMON"');
  139 |   expect(svg).toContain('stroke="#0000ff"');
  140 |   await page.getByLabel('Common-line cutting', { exact: true }).uncheck();
  141 |   await expect(page.getByLabel('Part spacing')).toHaveValue('5');
  142 |   await expect(page.locator('.common-line-report')).toHaveCount(0);
  143 | });
  144 | }
  145 | 
  146 | test('quick initial layout is optional and survives project export and reopening', async ({ page }) => {
  147 |   await setUp(page, [example('parts.svg')], { 'parts-3': 8 }, 300, 150, 1);
  148 |   const quick = page.getByLabel('Quick initial layout', { exact: true });
  149 |   await expect(quick).not.toBeChecked();
  150 |   await quick.check();
  151 |   await page.getByLabel('Repeatable', { exact: true }).check();
  152 |   await nest(page);
  153 |   await expect(page.locator('.summary')).toContainText('8/8');
  154 |   const saved = await project(page);
  155 |   expect(saved.request.quick_start).toBe(true);
  156 |   expect(saved.result.validation.valid).toBe(true);
  157 |   const [archive] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Project ZIP', exact: true }).click()]);
  158 |   const path = await archive.path();
  159 |   expect(zipEntry(path, `sheets/${saved.result.layout.sheets[0].id}.svg`)).toContain('<svg');
  160 |   await page.getByRole('button', { name: 'New', exact: true }).click();
  161 |   await page.locator('input[type=file][accept=".zip"]').setInputFiles(path);
  162 |   await expect(quick).toBeChecked();
  163 |   await expect(page.locator('.summary')).toContainText('8/8');
```