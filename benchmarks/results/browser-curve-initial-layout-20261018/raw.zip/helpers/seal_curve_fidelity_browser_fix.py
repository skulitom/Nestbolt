"""Preserve the hosted curve-test failure and qualified explicit-start test fix."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/ci-d414824-web-diagnosis-20261018'
out=root/'benchmarks/results/browser-curve-initial-layout-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
checks=load(probe/'local-checks/checks.json');assert checks['all_passed'] and checks['browser_passed']==86
assert digest(probe/'browser-failure-diagnostics.zip')=='7e02075b43f57f70aa1d6fa2af95f23d108979e7bb2efe91791fd621f1fde548'
with zipfile.ZipFile(probe/'browser-failure-diagnostics.zip') as z:assert z.testzip() is None
with zipfile.ZipFile(probe/'trace.zip') as z:
    names=[n for n in z.namelist() if n.startswith('src/')];assert len(names)==1
    assert z.read(names[0]).decode().replace('\r\n','\n')==(probe/'features-before.spec.ts').read_text(encoding='utf-8')
log=(probe/'web-api.log').read_text(encoding='utf-8')
assert '85 passed' in log and '1 failed' in log and 'no complete layout within 5 s' in log
context=(probe/'error-context.md').read_text(encoding='utf-8')
assert context.count('spinbutton "Quantity of ')==8
assert '- checkbox "Quick initial layout" [ref=e235]\n' in context
job=json.loads(subprocess.check_output(['gh','api','repos/skulitom/Nestbolt/actions/jobs/117677582736'],cwd=root))
assert job['conclusion']=='failure' and job['status']=='completed' and job['head_sha']=='d41482449d5fe418d15453f9b6ef54ef24f8404b'
write(probe/'hosted-job.json',job)
state=json.loads(subprocess.check_output(['gh','run','view','39128166075','--json','status,conclusion,headSha,jobs,url'],cwd=root))
write(probe/'hosted-run-snapshot.json',{'observed_utc':datetime.now(timezone.utc).isoformat(),'run':state})
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==load(probe/'local-checks/plan.json')['production_digest']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['read_d414824_web_failure.py','check_curve_fidelity_browser_suite.py','seal_curve_fidelity_browser_fix.py']:files['helpers/'+name]=root/'output'/name
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()}
with zipfile.ZipFile(out/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(out/'raw.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'all_members_and_crc_verified':True,'archive':'raw.zip','bytes':(out/'raw.zip').stat().st_size,'sha256':digest(out/'raw.zip'),'members':inventory})
for source,name in [('local-checks/checks.json','checks.json'),('local-checks/plan.json','plan.json'),
    ('hosted-job.json','hosted-job.json'),('hosted-run-snapshot.json','hosted-run-snapshot.json')]:shutil.copyfile(probe/source,out/name)
doc='''# Curve-fidelity browser test: explicit initial layout — 2026-10-18

The [browser job on d414824](https://github.com/skulitom/Nestbolt/actions/runs/39128166075/job/117677582736)
fails one Chromium import/export test: nesting does not produce a complete layout
within its requested five seconds. The log reports 85 passes, one failure and
four opt-in skips. The downloaded diagnostic artifact matches GitHub's published
SHA-256; its trace contains the exact original test source. The saved page has
all eight imported parts, a five-second allowance and quick initial layout off.
The failure precedes either export. These records establish an incomplete search;
they do not establish host scheduling as the cause or prove a solver regression.

The test now explicitly enables the existing quick initial layout option before
nesting. Its purpose remains importing both formats and preserving curved export
entities. All original assertions and the five-second search allowance remain.
Two additional assertions check that the saved project records the chosen option
and contains all eight placements. No retry, application change, default change,
benchmark limit change or claimed performance improvement is introduced.

The browser app rebuild and test type checks pass. The full local suite passes
**86 tests with four opt-in skips**, using the same two-worker concurrency and
zero retries. Chromium and Firefox both complete the edited import/export test.
Product-source hashes remain unchanged. The original hosted failure, screenshot,
trace, source, logs and local results are preserved in the checked archive.

Hosted confirmation of the corrected test remains pending. The previous failed
run is not replaced or described as passing. This test-only change does not
justify another application release or close H2/H5. The READMEs remain accurate.

[Local checks](browser-curve-initial-layout-20261018/checks.json),
[test-change scope](browser-curve-initial-layout-20261018/plan.json),
[original hosted failure](browser-curve-initial-layout-20261018/hosted-job.json) and
[archive integrity](browser-curve-initial-layout-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
note='''**Browser curve-test follow-up, 2026-10-18:** [the d414824 trace and local correction](../benchmarks/results/browser-curve-initial-layout-20261018.md)
preserve a Chromium import/export failure: no complete eight-part layout within
five seconds. This fidelity test now explicitly uses quick initial layout,
retaining the five-second allowance and all original assertions, with added checks
for all eight parts and the saved option. The full local suite passes 86 tests
with four skips, two workers and zero retries; hosted confirmation is pending.
Application source, benchmark limits and release assets are unchanged. H2/H5
remain open at 60%.
'''
prior=subprocess.check_output(['git','show','HEAD:BENCHMARKS.md'],cwd=root)
assert (root/'BENCHMARKS.md').read_bytes()==prior
append(root/'BENCHMARKS.md','\n'+note.replace('../benchmarks/','benchmarks/'))
for name in ['docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']:append(root/name,'\n'+note)
p=root/'docs/STATUS.md';s=p.read_text(encoding='utf-8');marker='**Latest browser follow-up, 2026-10-17:**'
assert s.count(marker)==1;p.write_text(s.replace(marker,note+'\n'+marker),encoding='utf-8',newline='\n')
append(root/'.gitattributes','\nbenchmarks/results/browser-curve-initial-layout-20261018/** -text -whitespace\n')
assert (root/'BENCHMARKS.md').read_bytes().startswith(prior)
print(json.dumps({'local_suite_passed':86,'skipped':4,'archive_members':len(inventory),'archive_bytes':(out/'raw.zip').stat().st_size,'hosted_confirmation_pending':True,'prior_run_status':state['status']}))
