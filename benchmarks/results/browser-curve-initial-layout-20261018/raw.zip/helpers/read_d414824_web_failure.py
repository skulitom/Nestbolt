"""Preserve the completed browser-job log while the other hosted jobs finish."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/ci-d414824-web-diagnosis-20261018';OUT.mkdir()
cmd=['gh','run','view','--job','117677582736','--log']
r=subprocess.run(cmd,cwd=ROOT,capture_output=True,timeout=90)
(OUT/'web.log').write_bytes(r.stdout);(OUT/'web.stderr').write_bytes(r.stderr)
(OUT/'fetch.json').write_text(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'command':cmd,'exit_code':r.returncode,
    'log_sha256':sha256(r.stdout).hexdigest()},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'exit_code':r.returncode,'bytes':len(r.stdout),'stderr':r.stderr.decode(errors='replace')[:500]}))
