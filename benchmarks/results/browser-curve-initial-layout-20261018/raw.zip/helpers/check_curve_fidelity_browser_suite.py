"""Check the curve-fidelity browser test with explicit quick initial placement."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,traceback
root=Path(__file__).resolve().parents[1];out=root/'output/ci-d414824-web-diagnosis-20261018/local-checks';out.mkdir()
digest=lambda p:sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
original=(out.parent/'features-before.spec.ts').read_text(encoding='utf-8')
current=(root/'web/tests/features.spec.ts').read_text(encoding='utf-8')
inserts=["  // Test import/export fidelity from a complete initial layout. A five-second\n  // stochastic search can expire before placing all curves on shared runners.\n  await page.getByLabel('Quick initial layout', { exact: true }).check();\n",
    "  const saved = await project(page);\n  expect(saved.request.quick_start).toBe(true);\n  expect(saved.result.layout.placements).toHaveLength(8);\n"]
reconstructed=current
for value in inserts:assert reconstructed.count(value)==1;reconstructed=reconstructed.replace(value,'')
assert reconstructed==original
# The existing build helper regenerates only this known workspace package.
pkg=(root/'web/src/pkg').resolve();assert pkg.is_relative_to(root.resolve()) and pkg.name=='pkg'
plan={'started':datetime.now(timezone.utc).isoformat(),'production_digest':source_digest(),'changed_test_sha256':digest(root/'web/tests/features.spec.ts'),
    'all_original_assertions_preserved':True,'added_assertions':['quick_start saved','all eight placements'],
    'unchanged_search_allowance_seconds':5,'local_and_CI_workers':2,'retries':0,'benchmark_change':False,
    'hosted_failure':'d414824 Chromium curve import/export; no complete layout within five seconds',
    'cause_limits':'The trace proves the incomplete search and request settings, not host scheduling or a solver regression.'}
write(out/'plan.json',plan);stages=[]
def run(label,command,cwd):
    started=datetime.now(timezone.utc).isoformat()
    with (out/(label+'.log')).open('xb') as f:r=subprocess.run(list(map(str,command)),cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
    row={'label':label,'command':list(map(str,command)),'exit_code':r.returncode,'started':started,
        'finished':datetime.now(timezone.utc).isoformat(),'log_sha256':digest(out/(label+'.log'))}
    stages.append(row);write(out/'progress.json',stages);print(json.dumps(row),flush=True)
    assert r.returncode==0,label
try:
    run('web-build',[sys.executable,'scripts/build_web.py'],root)
    run('test-types',['node','node_modules/typescript/bin/tsc','-p','tsconfig.tests.json'],root/'web')
    run('browser-suite',['node','node_modules/@playwright/test/cli.js','test','--workers','2','--retries','0','--output',out/'test-results','--trace','retain-on-failure'],root/'web')
    assert source_digest()==plan['production_digest']
    assert digest(root/'web/tests/features.spec.ts')==plan['changed_test_sha256']
    log=(out/'browser-suite.log').read_text(encoding='utf-8');assert '86 passed' in log and '4 skipped' in log
    write(out/'checks.json',{'all_passed':True,'browser_passed':86,'browser_skipped':4,'stages':stages,
        'unchanged_product_source':True,'all_original_assertions_preserved':True,'search_allowance_seconds':5,
        'hosted_followup_pending':True,'performance_measurement':False})
    shutil.copyfile(root/'web/tests/features.spec.ts',out/'features-after.spec.ts');shutil.copyfile(__file__,out/'check.py')
except BaseException:
    write(out/'failure.json',{'error':traceback.format_exc(),'stages':stages});raise
