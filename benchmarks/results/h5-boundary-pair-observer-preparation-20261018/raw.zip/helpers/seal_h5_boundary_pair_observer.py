"""Seal the focused observation build before its two diagnostic searches."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-boundary-pair-observer-20261018'
out=root/'benchmarks/results/h5-boundary-pair-observer-preparation-20261018'
sys.path.insert(0,str(root/'scripts'));import h5_boundary_pair_observer as runner
load,write,digest=runner.load,runner.write,runner.digest
build=load(probe/'build.json');plan=load(probe/'preparation.json');reader=load(probe/'authored-trace-reader/checks.json')
assert build['all_passed'] and digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert '130 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
source=load(probe/'reconstruction.json');assert source['all_formatted_files_exact'] and len(source['files'])==156
assert source['unchanged_other_files']==155 and source['all_130_original_tests_unchanged']
assert runner.prior.source_digest()==plan['production_digest']
for rel,expected in build['observed_sources'].items():assert digest(probe/'workspace'/rel)==expected
assert reader['all_checks_pass'] and len(reader['authored_test_traces'])==16
assert len(reader['malformed_records_rejected'])==21 and reader['reader_sha256']==digest(root/'scripts/h5_boundary_pair_observer.py')
assert reader['all_choice_poses_match_unique_baseline_members']
assert reader['parent_profile_branch_witnesses_exact']==12 and reader['actual_profile_branch_counters_exact']
assert reader['frozen_CLI_baseline_checks']==reader['actual_invocations']>0
assert digest(probe/'authored-tests.exe')==reader['test_binary_sha256']
method=load(probe/'runner-method.json');assert method['measurement_function_AST_exact'] and method['runner_sha256']==reader['reader_sha256']
assert digest(root/method['reference'])==method['reference_sha256']
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_boundary_pair_observer.py','build_h5_boundary_pair_observer.py',
             'check_h5_boundary_pair_observer_reader.py','check_h5_boundary_pair_observer_source.py',
             'seal_h5_boundary_pair_observer.py','record_h5_boundary_pair_observer_preparation.py']:
    files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_boundary_pair_observer.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for n,row in inventory.items():
        b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_qualified':True,'optimized_core_tests_passed':130,'original_tests_unchanged':130,
    'strict_lint_passed':True,'observer_build_passed':True,'authored_test_cases':16,'malformed_records_rejected':21,
    'frozen_CLI_baseline_checks':reader['frozen_CLI_baseline_checks'],'baseline_metrics_exact':True,
    'parent_profile_branch_witnesses_exact':12,'actual_profile_branch_counters_exact':True,
    'exact_choice_poses_verified':True,'exact_parent_reconstruction':True,'unchanged_other_files':155,'production_unchanged':True,'measured_search_started':False,'H5_complete':False}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','reconstruction.json','instrumentation.patch','runner-method.json']:shutil.copyfile(probe/name,out/name)
shutil.copyfile(probe/'authored-trace-reader/checks.json',out/'reader-checks.json')
doc=f'''# Boundary-part physical selection — observation preparation, 2026-10-18

The [completed boundary-pair pilot](h5-boundary-pair-pilot-20261018.md)
provides quality evidence for the candidate. This separate observer qualifies
only after that pilot fails at least one material comparison. It does not
repeat the quality pilot or change any selection, budget, repair or acceptance.

The observer retains the preceding family/outcome trace and additionally
records each choice's exact public physical poses. Conversion uses the same
sheet-offset subtraction and model transformation as the ordinary exporter.
The reader requires each pose to match a unique member of the independently
validated baseline exactly, with complete single-copy coverage and bounded
pair multiplicity. This distinguishes actual boundary copies from other
copies of the same part. Family and stage checks reuse the qualified prior
reader; its source is included in the measurement guards.

All 130 existing optimized tests, strict lint and the observer build pass.
Sixteen authored cases qualify actual traces; 21 malformed observations are
rejected. All {reader['frozen_CLI_baseline_checks']} captured baselines validate
with the frozen public CLI and reproduce their metrics exactly. Twelve
profile-branch witnesses match the unobserved parent's saved records exactly,
and their aggregated counters equal logged attempts. All 156 formatted source
files reconstruct exactly, with 155 unchanged and every original test retained.

The diagnostic plan retains panel hardware, both kerfs, seed zero, 60 seconds,
serial physical CCD0 CPU 8 and the original 20-minute session cap. The measured
run function is AST-identical to the previous two-case diagnostic; per-case
validation/export is unchanged. The plan is committed before measurement.
Logging may alter wall trajectories, so no comparative quality or speed claim
follows. Production, reserved data, release and README claims remain unchanged.
H2/H5 remain open at 60%.

[Checks](h5-boundary-pair-observer-preparation-20261018/checks.json),
[reader checks](h5-boundary-pair-observer-preparation-20261018/reader-checks.json),
[source reconstruction](h5-boundary-pair-observer-preparation-20261018/reconstruction.json),
[archive integrity](h5-boundary-pair-observer-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-boundary-pair-observer-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'all_qualified':True,'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size}))
