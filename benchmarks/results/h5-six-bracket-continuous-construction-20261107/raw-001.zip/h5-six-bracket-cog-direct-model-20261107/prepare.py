"""One source-contact initializer; no optimized ancestor and no seed batch."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.affinity import translate
from h5_six_bracket_cog_direct_model_20261107 import compile_model,Objective,owner_shapes,pair_energy,source_rows,source_pose,transformed
from h5_six_bracket_cog_direct_readback_20261107 import verify
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-six-bracket-cog-source-20261107';Q=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=ROOT/'output/h5-six-bracket-cog-direct-model-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');checked=load(SOURCE/'audit/checks.json');assert checked['passed'];charge=checked['complete_preparation_seconds']
inputs=[Path(__file__),JOB,Q/'partitions.json']+[ROOT/'output'/n for n in ['h5_six_bracket_cog_direct_model_20261107.py','h5_six_bracket_cog_direct_readback_20261107.py','h5_direct_pose_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py']]+[SOURCE/n for n in ['plan.json','library.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'complete_prior_preparation_seconds':charge,'method':'Keep the single source-derived centered5x3 cog grid only as initialization, with all15 angles and all22 centers free in the new model. For each legal companion mode, form original convex-piece cog-minus-companion Minkowski hulls with .23square gap, union the15 translated obstacles and clip to hard source center bounds. Candidate centers are every clipped-obstacle vertex plus every remaining-free-region vertex/representative point plus a9x9 hard-domain grid. These approximate floating obstacles ONLY generate finite seed candidates; they never constrain the model or exclude an allocation. Greedily place6brackets then1insert by original+clearance area against all previously placed moving originals, with exact recorded tie order(score,mode,Y,X). Preserve every candidate score. One initializer only. Compile all231original+clearance moving pairs,59parameters and all15 full-circle angles. Fixed44 are protected by the previously audited hard source domains; no soft domain penalty. No optimized ancestor, random restart, optimizer or native call.','grid_fractions':[i/8 for i in range(9)],'candidate_cap':40000,'preparation_internal_target_seconds':22,'preparation_process_cap_seconds':25,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
lib=load(SOURCE/'library.json');assert digest(SOURCE/'library.json')==checked['library_sha256'];parts=load(Q/'partitions.json');values=np.zeros(59);modes=[0]*22;placed=[]
for seed in lib['cog_seed']:
    i=seed['owner'];values[2*i:2*i+2]=seed['center'];values[44+i-7]=seed['angle_radians']*lib['angle_scale_mm'];placed.append(owner_shapes(lib,'cog',0,seed['center'],seed['angle_radians']))
model=compile_model(lib,modes,values);cogpose=source_pose(model['owners'][7],np.zeros(59));cogpose['rotation_radians']=lib['cog_seed'][0]['angle_radians'];px,py=lib['families']['cog']['source_center'];c,s=math.cos(cogpose['rotation_radians']),math.sin(cogpose['rotation_radians']);cogpose['translation']=[-(px*c-py*s),-(px*s+py*c)];cogpieces=[transformed(p,cogpose) for p in parts['cog']['pieces']];square=np.array(list(product([-.23,.23],repeat=2)));candidate_sets={};geometry_records=[]
for family in ['bracket','insert']:
    candidate_sets[family]=[]
    for mode in lib['family_modes'][family]:
        mi=mode['mode'];owner={'owner':0,'source_center':lib['families'][family]['source_center'],'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'angle_coordinate':None};pose=source_pose(owner,[0,0]);pieces=[transformed(p,pose) for p in parts[family]['pieces']];hulls=[]
        for a,b in product(cogpieces,pieces):
            diff=(a[:,None,:]-b[None,:,:]).reshape(-1,2);hulls.append(MultiPoint((diff[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
        template=shapely.union_all(hulls);bounds=mode['center_bounds_mm'];domain=box(bounds[0][0],bounds[1][0],bounds[0][1],bounds[1][1]);blocked=shapely.union_all([translate(template,*seed['center']) for seed in lib['cog_seed']]).intersection(domain);free=domain.difference(blocked);points=set(map(tuple,shapely.get_coordinates(blocked)))|set(map(tuple,shapely.get_coordinates(free)))
        for geometry in shapely.get_parts(free):
            if not geometry.is_empty:points.add(tuple(geometry.representative_point().coords[0]))
        for xi,yi in product(range(9),repeat=2):points.add((bounds[0][0]+xi/8*(bounds[0][1]-bounds[0][0]),bounds[1][0]+yi/8*(bounds[1][1]-bounds[1][0])))
        centers=sorted({(min(max(x,bounds[0][0]),bounds[0][1]),min(max(y,bounds[1][0]),bounds[1][1])) for x,y in points},key=lambda p:(p[1],p[0]));candidate_sets[family].append({'mode':mi,'centers':[list(p) for p in centers]});geometry_records.append({'family':family,'mode':mi,'piece_pair_hulls':len(hulls),'template':mapping(template),'blocked':mapping(blocked),'free':mapping(free),'candidate_centers':len(centers),'certified_constraint':False});assert time.perf_counter()-start<22
write(OUT/'contact-candidates.json',candidate_sets);write(OUT/'candidate-geometry.json',geometry_records);records=[];trialcount=0
for i in range(7):
    family=lib['identities'][i][0];trials=[]
    for option in candidate_sets[family]:
        for xy in option['centers']:
            value=pair_energy(owner_shapes(lib,family,option['mode'],xy),placed);trials.append({'mode':option['mode'],'center':xy,'score_mm2':value});trialcount+=1
    best=min(trials,key=lambda t:(t['score_mm2'],t['mode'],t['center'][1],t['center'][0]));modes[i]=best['mode'];values[2*i:2*i+2]=best['center'];placed.append(owner_shapes(lib,family,modes[i],best['center']));records.append({'owner':i,'identity':lib['identities'][i],'candidates':trials,'selected':best});assert trialcount<=40000 and time.perf_counter()-start<22
write(OUT/'initializer-trials.json',records);model=compile_model(lib,modes,values);assert verify(model,lib,modes,values);write(OUT/'initial-mode-values.json',{'modes':modes,'values':values.tolist()});write(OUT/'model.json',model);rows=source_rows(model,values);source=audit(load(JOB),rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));assert source['stock_failures']==0;write(OUT/'seed-source66.json',rows);write(OUT/'seed-source-checks.json',source);energy,g,details=Objective(model).evaluate(values,True);write(OUT/'initial-objective.json',{'energy_mm2':energy,'gradient':g.tolist(),**details});assert time.perf_counter()-start<22
checks={'passed':True,'seconds':time.perf_counter()-start,'candidate_trials':trialcount,'contact_candidate_centers_by_family':{f:sum(len(v['centers']) for v in a) for f,a in candidate_sets.items()},'originals':66,'moving_originals':22,'moving_pairs':231,'parameters':59,'continuous_angles':15,'initial_objective_mm2':energy,'initial_original_overlap_mm2':details['original_overlap_area_mm2'],'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'source_valid66':source['valid'],'complete_prior_preparation_seconds':charge,'optimizer_calls':0,'model_sha256':digest(OUT/'model.json'),'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
