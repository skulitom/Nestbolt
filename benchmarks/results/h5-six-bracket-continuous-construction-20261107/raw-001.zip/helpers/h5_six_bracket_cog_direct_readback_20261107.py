"""Independent full field reconstruction for all22 movers/all15 cog angles."""
def verify(model,library,modes,values):
    assert len(modes)==22 and len(values)==59;owners=[];bounds=[]
    assert library['identities']==[['bracket',i] for i in range(6,12)]+[['insert',20]]+[['cog',i] for i in range(15)]
    for i,identity in enumerate(library['identities']):
        selected=next(m for m in library['family_modes'][identity[0]] if m['mode']==modes[i]);free=identity[0]=='cog';bounds.extend(selected['center_bounds_mm'])
        owners.append({'owner':i,'identity':identity,'mode':modes[i],'rotation_radians':selected['rotation_radians'],'mirrored':selected['mirrored'],'source_center':library['families'][identity[0]]['source_center'],'angle_coordinate':44+i-7 if free else None,'angle_scale_mm':library['angle_scale_mm'] if free else None})
    bounds+=library['angle_bounds']
    assert model['owners']==owners and model['bounds']==bounds and model['initial']==[min(max(float(v),bb[0]),bb[1]) for v,bb in zip(values,bounds)]
    assert model['parameters']==59 and model['families']==library['families'] and model['fixed_source_rows']==library['fixed_source_rows'] and model['pairs']==library['pairs']==[[i,j] for i in range(22) for j in range(i+1,24)] and model['objective_weights']=={'original_area':1,'clearance_area':1}
    return True
