from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/verify_h5_four_column_direct_checkpoint_20261107.py').read_text(encoding='utf-8').replace('h5-four-column-continuous-search-20261107','h5-six-bracket-continuous-construction-20261107')
with (ROOT/'output/verify_h5_six_bracket_cog_checkpoint_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
