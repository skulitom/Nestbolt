from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
common=[('h5-fifteen-cog-direct-model-20261107','h5-six-bracket-cog-direct-model-v2-20261107'),('h5-fifteen-cog-source-20261107','h5-six-bracket-cog-source-20261107'),('h5_fifteen_cog_direct_model_20261107','h5_six_bracket_cog_direct_model_20261107'),('h5_fifteen_cog_direct_readback_20261107','h5_six_bracket_cog_direct_readback_v2_20261107'),('h5-fifteen-cog-initializer-process-20261107','h5-six-bracket-cog-initializer-v2-process-20261107'),("lib['identities'][:9]","lib['identities'][:7]"),('range(63)','range(59)'),("source['same_sheet_pairs']==1456","source['same_sheet_pairs']==1380")]
def convert(old,new,extra):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for before,after in common+extra:
        assert before in s,(old,before);s=s.replace(before,after)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
convert('run_h5_fifteen_cog_direct_search_20261107.py','run_h5_six_bracket_cog_direct_search_20261107.py',[
 ("'parameters':63","'parameters':59"),('new24-mover/63parameter','new22-mover/59parameter'),('protect fixed42','protect fixed44'),('276original+clearance','231original+clearance'),
 ("'complete_initializer_and_model_preparation':load(ROOT/'output/h5-six-bracket-cog-initializer-v2-process-20261107/prepare.json')['complete_seconds']","'complete_failed_initializer':load(ROOT/'output/h5-six-bracket-cog-initializer-process-20261107/prepare.json')['complete_seconds'],'complete_initializer_and_model_preparation':load(ROOT/'output/h5-six-bracket-cog-initializer-v2-process-20261107/prepare.json')['complete_seconds']"),
 ("'h5-six-bracket-cog-initializer-v2-process-20261107/prepare.json'","'h5-six-bracket-cog-initializer-process-20261107/prepare.json','h5-six-bracket-cog-initializer-v2-process-20261107/prepare.json'"),
 ('Allsource/initializer/model/selection/runtimecharged;','Allsource/failedinitializer/correctedfinalization/model/selection/runtimecharged;unchanged recordedinitializer reused after verifierbound correction,not regenerated;')])
convert('audit_h5_fifteen_cog_direct_response_20261107.py','audit_h5_six_bracket_cog_direct_response_20261107.py',[
 ('len(evaluated)+len(skipped)==43','len(evaluated)+len(skipped)==45'),("opened_optimizer['parameters']==63","opened_optimizer['parameters']==59"),('values[48+i-9]','values[44+i-7]'),('if i>=9 else','if i>=7 else'),('len(moving_pairs)==276','len(moving_pairs)==231'),('63coordinategradients','59coordinategradients'),('1456same-sheetpairs','1380same-sheetpairs'),('All276movingpairs','All231movingpairs'),
 ("charges['complete_source_geometry_preparation']==load(SOURCE/'audit/checks.json')['complete_preparation_seconds']","charges['complete_source_geometry_preparation']==load(SOURCE/'audit/checks.json')['complete_preparation_seconds'] and charges['complete_failed_initializer']==load(ROOT/'output/h5-six-bracket-cog-initializer-process-20261107/prepare.json')['complete_seconds']")])
base=(ROOT/'output/run_h5_direct_pose_audit_20261107.py').read_text(encoding='utf-8').replace('h5-direct-pose-audit-process-20261107','h5-six-bracket-cog-response-audit-process-20261107').replace("stages=[('audit','audit_h5_direct_pose_model_20261107.py',90)]","stages=[('audit','audit_h5_six_bracket_cog_direct_response_20261107.py',90)]")
with (ROOT/'output/run_h5_six_bracket_cog_response_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(base)
