"""Version one stale pair-loop bound; retain failed initialization and all its cost."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'output/h5_six_bracket_cog_direct_readback_20261107.py';s=p.read_text(encoding='utf-8');assert s.count('range(i+1,24)')==1;s=s.replace('range(i+1,24)','range(i+1,22)')
with (ROOT/'output/h5_six_bracket_cog_direct_readback_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
base=(ROOT/'output/run_h5_direct_pose_audit_20261107.py').read_text(encoding='utf-8')
for label,stage,script,cap in [('initializer-v2','prepare','finalize_h5_six_bracket_cog_initializer_20261107.py',15),('model-audit-v2','audit','audit_h5_six_bracket_cog_direct_model_v2_20261107.py',90)]:
    s=base.replace('h5-direct-pose-audit-process-20261107','h5-six-bracket-cog-'+label+'-process-20261107').replace("stages=[('audit','audit_h5_direct_pose_model_20261107.py',90)]",f"stages=[('{stage}','{script}',{cap})]")
    with (ROOT/'output'/('run_h5_six_bracket_cog_'+label.replace('-','_')+'_20261107.py')).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_six_bracket_cog_direct_model_20261107.py').read_text(encoding='utf-8').replace('h5-six-bracket-cog-direct-model-20261107','h5-six-bracket-cog-direct-model-v2-20261107').replace('h5_six_bracket_cog_direct_readback_20261107','h5_six_bracket_cog_direct_readback_v2_20261107').replace('h5-six-bracket-cog-initializer-process-20261107','h5-six-bracket-cog-initializer-v2-process-20261107')
old="charge=checked['complete_preparation_seconds']+prep['complete_seconds'];"
new="failed=load(ROOT/'output/h5-six-bracket-cog-initializer-process-20261107/prepare.json');assert not failed['passed'] and failed['job']['closed'] and failed['job']['root_exit_code']==1;charge=checked['complete_preparation_seconds']+failed['complete_seconds']+prep['complete_seconds'];"
assert old in s;s=s.replace(old,new)
with (ROOT/'output/audit_h5_six_bracket_cog_direct_model_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
