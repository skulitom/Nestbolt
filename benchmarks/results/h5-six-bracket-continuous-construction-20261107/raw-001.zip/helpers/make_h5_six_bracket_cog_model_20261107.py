"""Version the source model and initializer for the changed22-owner inventory."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def convert(old,new,changes):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for before,after in changes:
        assert before in s,(old,before);s=s.replace(before,after)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
convert('h5_fifteen_cog_direct_model_20261107.py','h5_six_bracket_cog_direct_model_20261107.py',[
 ('len(modes)==24 and len(values)==63','len(modes)==22 and len(values)==59'),
 ('48+i-9','44+i-7'),("'parameters':63","'parameters':59"),('np.zeros(63)','np.zeros(59)')])
convert('h5_fifteen_cog_direct_readback_20261107.py','h5_six_bracket_cog_direct_readback_20261107.py',[
 ('all24 movers','all22 movers'),('len(modes)==24 and len(values)==63','len(modes)==22 and len(values)==59'),
 ("[['bracket',i] for i in range(8,12)]+[['insert',i] for i in range(16,21)]","[['bracket',i] for i in range(6,12)]+[['insert',20]]"),
 ('48+i-9','44+i-7'),("model['parameters']==63","model['parameters']==59"),('range(39)','range(22)'),
]) if 'range(39)' in (ROOT/'output/h5_fifteen_cog_direct_readback_20261107.py').read_text() else convert('h5_fifteen_cog_direct_readback_20261107.py','h5_six_bracket_cog_direct_readback_20261107.py',[
 ('all24 movers','all22 movers'),('len(modes)==24 and len(values)==63','len(modes)==22 and len(values)==59'),
 ("[['bracket',i] for i in range(8,12)]+[['insert',i] for i in range(16,21)]","[['bracket',i] for i in range(6,12)]+[['insert',20]]"),
 ('48+i-9','44+i-7'),("model['parameters']==63","model['parameters']==59"),('range(24)','range(22)'),
])
common=[('h5-fifteen-cog-source-20261107','h5-six-bracket-cog-source-20261107'),('h5-fifteen-cog-direct-model-20261107','h5-six-bracket-cog-direct-model-20261107'),('h5_fifteen_cog_direct_model_20261107','h5_six_bracket_cog_direct_model_20261107'),('h5_fifteen_cog_direct_readback_20261107','h5_six_bracket_cog_direct_readback_20261107')]
convert('prepare_h5_fifteen_cog_initializer_20261107.py','prepare_h5_six_bracket_cog_initializer_20261107.py',common+[
 ('all24 centers','all22 centers'),('place4brackets then5inserts','place6brackets then1insert'),('all276original+clearance','all231original+clearance'),('63parameters','59parameters'),('Fixed42','Fixed44'),('np.zeros(63)','np.zeros(59)'),('modes=[0]*24','modes=[0]*22'),('48+i-9','44+i-7'),("model['owners'][9]","model['owners'][7]"),('for i in range(9):','for i in range(7):'),("'moving_originals':24","'moving_originals':22"),("'moving_pairs':276","'moving_pairs':231"),("'parameters':63","'parameters':59")])
convert('audit_h5_fifteen_cog_direct_model_20261107.py','audit_h5_six_bracket_cog_direct_model_20261107.py',common+[
 ('h5-fifteen-cog-initializer-process-20261107','h5-six-bracket-cog-initializer-process-20261107'),
 ('48+i-9','44+i-7'),('48+own-9','44+own-7'),('list(range(9))','list(range(7))'),("source['pair_failures']==14","source['pair_failures']==load(BASE/'checks.json')['source_pair_failures']"),("source['same_sheet_pairs']==1456","source['same_sheet_pairs']==1380"),('if i>=9 else','if i>=7 else'),('if own>=9:','if own>=7:'),('vectors==44','vectors==46'),('np.zeros(63)','np.zeros(59)'),('chosen[:9]','chosen[:7]'),('np.arange(63)','np.arange(59)'),('range(63)','range(59)'),("'coordinates':63","'coordinates':59"),("lib['identities'][:9]","lib['identities'][:7]"),('len(keys)==33 and equivalent==5','len(keys)==43 and equivalent==1'),("'physical_owner_options':57","'physical_owner_options':65"),("mm['owners'][9]['angle_coordinate']=49","mm['owners'][7]['angle_coordinate']=45"),("mm['parameters']=62","mm['parameters']=58"),('all67owner-mode bindings/276pairs/63parameters','all67owner-mode bindings/231pairs/59parameters'),('126central derivatives','118central derivatives'),('fixed42','fixed44'),("'independent_central_coordinates':126","'independent_central_coordinates':118")])
base=(ROOT/'output/run_h5_direct_pose_audit_20261107.py').read_text(encoding='utf-8')
for label,stage,script,cap in [('initializer','prepare','prepare_h5_six_bracket_cog_initializer_20261107.py',25),('model-audit','audit','audit_h5_six_bracket_cog_direct_model_20261107.py',90)]:
    s=base.replace('h5-direct-pose-audit-process-20261107','h5-six-bracket-cog-'+label+'-process-20261107').replace("stages=[('audit','audit_h5_direct_pose_model_20261107.py',90)]",f"stages=[('{stage}','{script}',{cap})]")
    with (ROOT/'output'/('run_h5_six_bracket_cog_'+label.replace('-','_')+'_20261107.py')).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
