from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_fifteen_cog_source_20261107.py').read_text(encoding='utf-8')
old="short.append(normalized('insert',15,math.pi/2,[origin[0]+4*(mw+gap),origin[1]],'sheet-1'));"
new="right=origin[0]+3*(mw+gap)\nfor n in range(4):short.append(normalized('insert',14+n,math.pi/2,[right+n*(ih+gap),origin[1]],'sheet-1'))\nfor n in range(2):short.append(normalized('insert',18+n,0.,[right+n*(iw+gap),origin[1]+iw+gap],'sheet-1'))\n"
assert old in s;s=s.replace(old,new)
changes={
 'h5-fifteen-cog-source-20261107':'h5-six-bracket-cog-source-20261107',
 'h5-fifteen-cog-source-preparation-process-20261107':'h5-six-bracket-cog-source-preparation-process-20261107',
 "r['short_counts']==[8,5,0]":"r['short_counts']==[6,9,0]",
 "allocation['first_counts']==[18,4,16,15]":"allocation['first_counts']==[18,6,12,15]",
 'for n in range(4):\n    x=origin':'for n in range(3):\n    x=origin',
 'short13-source.json':'short15-source.json','fixed42':'fixed44','seed57':'seed59',
 "fixedcheck['originals']==42":"fixedcheck['originals']==44",
 "fixedcheck['same_sheet_pairs']==484":"fixedcheck['same_sheet_pairs']==511",
 "[['bracket',i] for i in range(8,12)]+[['insert',i] for i in range(16,21)]":"[['bracket',i] for i in range(6,12)]+[['insert',20]]",
 'combinations(range(24),2)':'combinations(range(22),2)',
 "len(lib['pairs'])==276":"len(lib['pairs'])==231",
 "lib['continuous_parameters']==63":"lib['continuous_parameters']==59",
 "lib['angle_coordinate_start']==48":"lib['angle_coordinate_start']==44",
 "lib['first_cog_owner']==9":"lib['first_cog_owner']==7",
 "'owner':9+n":"'owner':7+n",
 "source['originals']==57":"source['originals']==59",
 "source['same_sheet_pairs']==1024":"source['same_sheet_pairs']==1051",
 "charge=checked['complete_failed_and_corrected_preparation_seconds']+prep['complete_seconds']":"prior=ROOT/'output/h5-fifteen-cog-source-20261107';priorcheck=load(prior/'audit/checks.json');assert priorcheck['passed'];charge=priorcheck['complete_preparation_seconds']+prep['complete_seconds']",
 "inputs=[Path(__file__),JOB,":"inputs=[Path(__file__),JOB,prior/'audit/checks.json',",
 "'short_allocation':[8,5,0]":"'short_allocation':[6,9,0]",
 "'fixed_originals':42":"'fixed_originals':44",
 "'source_seed_originals':57":"'source_seed_originals':59",
 "'source_seed_pairs':1024":"'source_seed_pairs':1051",
 "'source_seed_stock_edges':228":"'source_seed_stock_edges':236",
 "'model_moving_originals':24":"'model_moving_originals':22",
 "'model_continuous_parameters':63":"'model_continuous_parameters':59",
 "'model_moving_pairs':276":"'model_moving_pairs':231",
 "'companions_unplaced':9":"'companions_unplaced':7",
 '440survivorsand8/5/0complement':'440survivorsand6/9/0complement',
 'sourcefixed29andshort13':'sourcefixed29andshort15',
 'Checkall57sourceoriginals1024pairs':'Checkall59sourceoriginals1051pairs',
 'Verifyall24identities':'Verifyall22identities',
 '15continuousangles63parameters276pair':'15continuousangles59parameters231pair',
 'initializerforthe9companions':'initializerforthe7companions',
}
for old,new in changes.items():assert old in s,old;s=s.replace(old,new)
with (ROOT/'output/audit_h5_six_bracket_cog_source_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
base=(ROOT/'output/run_h5_direct_pose_audit_20261107.py').read_text(encoding='utf-8')
for label,stage,script,cap in [('preparation','prepare','prepare_h5_six_bracket_cog_source_20261107.py',15),('audit','audit','audit_h5_six_bracket_cog_source_20261107.py',90)]:
    out=base.replace('h5-direct-pose-audit-process-20261107','h5-six-bracket-cog-source-'+label+'-process-20261107').replace("stages=[('audit','audit_h5_direct_pose_model_20261107.py',90)]",f"stages=[('{stage}','{script}',{cap})]")
    with (ROOT/'output'/('run_h5_six_bracket_cog_source_'+label+'_20261107.py')).open('x',encoding='utf-8',newline='\n') as f:f.write(out)
