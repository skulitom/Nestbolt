from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1];source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-six-bracket-continuous-construction-20261107'","BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-six-bracket-cog-direct-model-v2-20261107';F=ROOT/'output/h5-six-bracket-cog-checkpoint-20261107';D=ROOT/'output/h5-six-bracket-cog-source-20261107'","PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-fifteen-cog-continuous-construction-20261107'","front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==29","folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,F,D]+[ROOT/'output'/n for n in ['h5-six-bracket-cog-direct-model-20261107','h5-six-bracket-cog-source-preparation-process-20261107','h5-six-bracket-cog-source-audit-process-20261107','h5-six-bracket-cog-initializer-process-20261107','h5-six-bracket-cog-initializer-v2-process-20261107','h5-six-bracket-cog-model-audit-v2-process-20261107','h5-six-bracket-cog-response-audit-process-20261107']]","['*h5*mixed*mode*20261107.py']":"['*h5*six*bracket*cog*20261107.py']","'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_six_bracket_cog_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(F/'readback-correction.json','readback-correction.json'),(D/'audit/checks.json','source-audit.json'),(D/'audit/exact-contact-readback.json','exact-contact-pitches.json'),(D/'allocation-readback.json','allocation-readback.json'),(BASE/'audit/checks.json','model-audit.json'),(BASE/'audit/candidate-geometry-readback.json','candidate-geometry-readback.json'),(BASE/'audit/derivative-controls.json','derivative-controls.json'),(BASE/'audit/seed-descent-controls.json','seed-descent-controls.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(BASE/'audit/physical-mode-controls.json','physical-mode-audit.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/mode-selection-controls.json','mode-selection-controls.json'),(BASE/'response-audit/round-reconciliation.json','round-reconciliation.json'),(BASE/'response-audit/round-01-collision-details.json','source-failures.json'),(BASE/'search/process.json','closed-search-process.json')]
for folder in ['source-preparation','source-audit','initializer','initializer-v2','model-audit-v2','response-audit']:copies.append((ROOT/'output'/('h5-six-bracket-cog-'+folder+'-process-20261107')/'process.json',folder+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Six-bracket continuous construction — 2026-11-07

The changed 22-mover model closes after three bounded calls without a valid
layout. Its best objective candidate is from **call 1** and still fails
**29 source pairs**, with **17,515.461166 mm²** of original overlap. Every
fixed-part clearance and stock edge passes. The final call has fewer failing
pairs but more total overlap; both results are retained. H2/H5 remain open at
**60% completed milestone weight**, with four fixed arrangements and 440 whole
allocations unresolved. No native validation, exclusion or release follows.

## Source allocation and controls

[Current-ledger and original-source checks]({NAME}/source-audit.json) reconcile
all 4,576 allocation rows and 440 survivors. The historical six-bracket/nine-insert
short-sheet allocation remains unexcluded. The new recipe uses three separate
two-bracket/one-insert modules, four turned inserts to their right, and two
horizontal inserts above those. The short sheet contains fifteen originals.
Eighteen frames in three columns by six rows and eleven side inserts remain
fixed on the first sheet. All 44 fixed originals pass 511 same-sheet pair checks.

The charged source-derived cog grid uses fifteen originals at the analytic
6.75° phase and 261.766 mm pitches. Together they form a valid **59-part control**,
with 1,051 pair checks, 236 stock edges and 71 holes containing 7,708 vertices.
Six brackets and one insert remain unplaced at this stage. This does not
improve the retained 64-part partial or prove full66 validity.

Independent readback verifies 882 exact rational contact sections, all 67
owner/mode bindings and 388 source stock-corner controls. The complete source
preparation costs **3.789957 s**, including its entire consumed source lineage.
No optimized ancestor or previous selected mode is copied into initialization.
The allocation and earlier unrestricted-angle necessary models are historical;
the change is in the remaining original identities and constructive interactions.

## Preserved preparation failure and corrected model

One deterministic initialization evaluates **4,212 source contact/grid trials**.
An adapted field verifier incorrectly retained 24 as the inner pair-loop bound
after the outer bound changed to 22. Its assertion stops preparation before
model serialization or any optimization. The failed stage takes **2.673755 s**.

[A versioned correction]({NAME}/readback-correction.json) changes only that
inner bound to 22. All candidate geometry, scores and selected points are
byte-identical; none is regenerated. A separate **0.418969 s** finalization
reconstructs the recorded selection and completes model/source outputs.
The entire failure and correction remain charged, giving **6.882681 s** of
preparation before search. Both verifier versions and the failed process are
preserved. The seed has 10 overlapping pairs and passes all stock checks.

[The complete model audit]({NAME}/model-audit.json) independently replays every
trial and all 66 original source poses. The model retains six brackets, one
insert and fifteen freely rotating cogs: **59 continuous parameters and 231
moving pairs**. Original and clearance-outline overlap receive equal weight.
Hard source-center bounds protect all 44 fixed parts and stock throughout
every selected legal mode.

Controls check 67 full objective scores and mode bindings, 46 dynamic vectors,
40 scalar/batched gradient comparisons, 118 central derivatives, three descent
steps and nine corruptions. All pass. The physical-equivalence audit checks
81 mode pairs, yielding 65 distinct physical owner options and 43 single-owner
neighbors. Selected transforms and all original holes remain preserved.

## Closed calls and complete source replay

The declared pipeline permits one 18-second call and at most two 14-second
calls for new physical mode vectors. Each later call selects the lowest full
objective among unvisited neighbors of the best retained candidate; the
proposal need not improve before optimization. No physical vector is called
twice, and the three-call limit cannot be extended.

[Independent response replay]({NAME}/response-audit.json) verifies all **298
retained points and 85 orientation trials**, along with the recorded 332
evaluation counters. All three calls stop on time without a numerical return.
Each response reconstructs every original and checks 1,380 same-sheet pairs,
264 stock edges and 90 holes containing 10,026 vertices.

| Call | Failed source pairs | Original overlap (mm²) | Best retained call |
|---|---:|---:|---:|
| 0 | 30 | 17,543.744761 | 0 |
| 1 | 29 | 17,515.461166 | 1 |
| 2 | 28 | 18,007.001771 | 1 |

Call 0 has 29 positive overlaps and one clearance-only failure. The later
failures are all positive overlaps between moving originals. Fixed–fixed,
fixed–moving and stock checks pass throughout. The seed-to-candidate increase
in failing-pair count is preserved; reduced summed overlap is not validity.

Preparation-inclusive algorithm/shared totals are **55.654869/55.729385 s**,
within the original 60/90-second limits. Slice overruns of 0.029180, 0.171435
and 0.023611 s are retained. Peak aggregate committed memory is 94,199,808
bytes, and all five search processes close. No old call is resumed.

## Next source scope

[The next proposal]({NAME}/next-step.json) frees the eleven side-strip inserts,
leaving only eighteen three-column frames and fifteen short-sheet parts fixed.
It retains all six brackets, twelve inserts and fifteen continuous-angle cogs:
33 movers, 81 parameters and 528 moving pairs. This allows side-strip and
upper-right corner movement excluded by the current uniform top-domain model.
Older broad searches and the four-column soft-domain model remain historical
and closed; this is not a first unfixed-insert claim.

Before any new model, source-safe rectangular center cells must be constructed
and independently certified against the original fixed frames. Hard cell bounds
must guarantee separation throughout each cell. The construction may restrict
coverage; completeness cannot be assumed. Compound orientation/cell choices
need an explicit audit because identical local orientations can have different
admissible domains. No successor geometry, initializer or model is prepared.
Only the 3.789957 s source lineage may be reused without consuming the failed
initialization or closed optimized candidates; all new preparation is charged.

Main 52313564 has four passed CI jobs and two running native checks at review.
Checkpoint 1191e857 and this checkpoint await the ordinary push gate. Production,
README, releases and reserved H2 vectors remain unchanged. All66 source/native/
material checks, production parity and the unchanged full H5 matrix remain required.

[Checkpoint audit]({NAME}/checkpoint-audit.json), [closed process]({NAME}/closed-search-process.json),
[raw manifest]({NAME}/raw-manifest.json), [source bindings]({NAME}/source-bindings.json).
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 six-bracket continuous construction:** [independent source/model/response audits]({link}) verify the historical six-bracket/nine-insert allocation, a valid 59-part source control, 882 exact contact sections and 388 stock-corner controls. A stale inner pair-loop bound stops initialization before optimization; the failed 2.673755 s stage is preserved, its verifier is versioned, and all 4,212 recorded trials are reused unchanged. Corrected model checks cover 22 movers, 59 parameters, 231 pairs, 67 mode bindings and 118 central derivatives. Three distinct physical-vector calls close at the declared limit; all 298 retained points, 85 orientation trials and 332 evaluation counters replay. Call 1 remains best with 29 source overlaps totaling 17,515.461166 mm²; all fixed-part and stock checks pass. Complete preparation is 6.882681 s and algorithm/shared totals are 55.654869/55.729385 s. All slice overruns and worse candidates remain preserved, every process closes, and no native call or exclusion follows. Next assess source-certified hard domain cells after freeing eleven side-strip inserts, retaining 33 movers and all fifteen continuous cog angles; no successor is prepared and no closed call may resume. Four fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%. Main 52313564 has four passed CI jobs and two native checks running, so both pending checkpoints await the ordinary push gate. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a);intro=f'''Latest H5 evidence: [six-bracket continuous construction](../benchmarks/results/{NAME}.md).
Source audits verify the changed short allocation and a valid 59-part control.
A field-verifier bound error is preserved and corrected before optimization;
all 4,212 initialization trials are reused unchanged and all failed work is charged.
The complete 22-mover model and three bounded responses pass replay audits,
but no full66 layout results. Call 1 remains best with 29 overlapping pairs and
17,515.461166 mm² total overlap; every fixed-part clearance and stock edge passes.
All 298 retained points, 85 orientation trials and slice overruns are preserved.
Preparation-inclusive algorithm/shared totals are 55.654869/55.729385 s; every
process is closed. Next assess hard certified center cells after freeing eleven
side-strip inserts, retaining 33 movers and all fifteen continuous cog angles.
No successor geometry, initializer or model is prepared. Four fixed arrangements
and 440 allocations remain; H2/H5 stay open at 60% completed milestone weight.
Main 52313564 has four passed CI jobs and two native checks running; checkpoint
1191e857 and this checkpoint await the ordinary push gate. Full66 source/native/
material checks, production parity and the unchanged H5 matrix remain required.
No release qualifies.
''';p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
