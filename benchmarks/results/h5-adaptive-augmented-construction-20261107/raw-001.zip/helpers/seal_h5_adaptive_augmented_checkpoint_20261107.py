"""Preserve the adaptive augmented preflight, closed pipeline and full replay."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-adaptive-augmented-construction-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-adaptive-augmented-preflight-20261107';F=BASE/'response-audit';D=BASE/'audit'",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-augmented-conditional-construction-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==2 and front['best_original']['pair_failures']==50 and not front['source_valid66']",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/n for n in ['h5-adaptive-augmented-preflight-preparation-process-20261107','h5-adaptive-augmented-preflight-audit-process-20261107','h5-adaptive-augmented-preflight-response-audit-process-20261107']]",
    "['*h5*mixed*mode*20261107.py']":"['*h5*adaptive*augmented*20261107.py','h5_augmented_deadline_neighbors_20261107.py','prepare_h5_augmented_conditional_push_20261107.py','push_h5_augmented_conditional_checkpoints_20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_adaptive_augmented_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json']",
    'OUT.mkdir();members={};external={};bindings={};queue=[];seen=set()':'''SECOND=ROOT/'benchmarks/results/h5-weighted-relocated-construction-20261107'
assert load(SECOND/'archive-checks.json')['passed']
second_manifest=load(SECOND/'raw-manifest.json');second_hash=digest(SECOND/'raw-manifest.json')
for row in second_manifest['files']:
    parents.setdefault((row['sha256'],row['bytes']),{'manifest':(SECOND/'raw-manifest.json').relative_to(ROOT).as_posix(),'manifest_sha256':second_hash,'archive':row['archive'],'member':row['path'],'bytes':row['bytes'],'sha256':row['sha256']})
for row in load(SECOND/'external-evidence.json').values():parents.setdefault((row['sha256'],row['bytes']),row)
OUT.mkdir();members={};external={};bindings={};queue=[];seen=set()''',
    'while queue:':"add('helpers/h5-adaptive-augmented-generator-failure-20261107.json',ROOT/'output/h5-adaptive-augmented-generator-failure-20261107.json')\nwhile queue:",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(D/'checks.json','preflight-audit.json'),(D/'source-ranking-controls.json','source-ranking-controls.json'),(D/'deadline-controls.json','deadline-controls.json'),(D/'selected-model-controls.json','selected-model-controls.json'),(D/'adaptive-history-controls.json','adaptive-history-controls.json'),(D/'weight-update-controls.json','weight-update-controls.json'),(BASE/'selection.json','initial-selection.json'),(F/'checks.json','response-audit.json'),(F/'epoch-reconciliation.json','epoch-reconciliation.json'),(F/'epoch-01/original-source-checks.json','best-original-source-checks.json'),(F/'epoch-01-selection/checks.json','first-runtime-selection-audit.json'),(F/'epoch-02-selection/checks.json','stopping-selection-audit.json'),(BASE/'search/process.json','closed-search-process.json'),(BASE/'search/result.json','closed-search-result.json'),(BASE/'search/epoch-00/closed-problem.json','closed-problem-00.json'),(BASE/'search/epoch-01/closed-problem.json','closed-problem-01.json'),(BASE/'outcome-diagnostic/checks.json','outcome-diagnostic.json'),(BASE/'outcome-diagnostic/family-failures.json','family-failures.json'),(BASE/'outcome-diagnostic/prior-comparisons.json','prior-comparisons.json'),(BASE/'outcome-diagnostic/selection-stop-diagnostic.json','selection-stop-diagnostic.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json'),(BASE/'main-ci-aggregate-at-review.json','main-ci-aggregate-at-review.json'),(ROOT/'output/h5-adaptive-augmented-generator-failure-20261107.json','preserved-generator-failure.json')]
for stage in ['preparation','audit','response-audit']:copies.append((ROOT/'output'/f'h5-adaptive-augmented-preflight-{stage}-process-20261107'/'process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'best_admissible_single_or_joint_preflight_required','finding':'The finite adaptive pipeline stops correctly after two calls. Its third-round best single improves current augmented score by5060.157191736245mm2 and beats the best joint by2216.679441854445mm2. The frozen rule requires a joint to beat the best single, so it must stop. The unoptimized single and joint at that stop are diagnostic only. The best optimized full layout still fails50source pairs; the result is worse than the earlier area-only adaptive result in both overlap and failing pairs.',
    'proposal':'Preflight a separately versioned selection rule that accepts the best admissible strict-improving one-owner OR two-owner change. Preserve full single and joint ranking diagnostics. Start only from a new admissible original-source proposal, independently re-ranked after adding both current closed keys to the nine-key ledger; do not resume this pipeline or seed from its optimized or stopping candidate. Retain all source geometry, hard domains, positive area-only weight updates and coefficient1 auxiliary terms.',
    'requirements':['Independently verify the revised choice rule against the saved complete runtime score readbacks, using stopped candidates only as validation cases. This does not authorize optimizing any saved candidate or resuming any old call.','Re-rank the fully audited original-source pool against all11closed keys and rebuild a genuinely new source-only model. Coordinates alone do not create a new objective/physical-mode/weight key. Open nothing if no admissible strictly improving source choice exists.','Keep all528original/clearance pairs,15auxiliary bracket terms,81coordinates, every legal hard domain and cog continuous angle. Do not retune weights, coefficients or tolerances.','Retain tested deadline support and partial-stop evidence. Independently validate every new weight vector, dynamic model, full selection score and all three local winner streams; compare original/unweighted global scores across weights.','Charge the complete17.623198099434376seconds of consumed source/model/selector preparation plus any new stages. Freeze a separate finite60/90-second contract and source reserve before measurement; no budget reset, extension or retries.','Every prior pipeline and all11closed keys remain closed. Full66 source validity is required before native validation, material claims or H5 credit.'],
    'source_only_preparation_seconds_before_new_work':17.623198099434376,'closed_augmented_problems':4,'closed_prior_weighted_problems':7,'new_rule_prepared':False,'new_source_state_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
ci=load(BASE/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs']);pre=load(D/'checks.json');diag=load(BASE/'outcome-diagnostic/checks.json');family=load(BASE/'outcome-diagnostic/family-failures.json');stop=load(BASE/'outcome-diagnostic/selection-stop-diagnostic.json')
report=f'''# Adaptive augmented construction — 2026-11-07

The bounded adaptive pipeline closes after **two distinct calls** and a third
selection round that correctly stops without opening a call. Independent replay
verifies every evaluation, both complete runtime selection rounds and all six
full-source winner outputs. Its best original-overlap candidate still fails
**50 source pairs**, with **29,249.033408 mm²** overlap. It improves those two
measures against the preceding fixed-weight augmented construction, but remains
worse than the earlier area-only adaptive result (46 failed pairs and
28,414.189788 mm²). No packing validity or allocation exclusion is claimed.
H2/H5 remain open at **60% completed milestone weight**.

## Source-only initialization and deadline controls

[The source pool is independently re-ranked]({NAME}/source-ranking-controls.json)
against nine closed keys using all 2,854 previously audited full-score readbacks.
The 6,396 original center trials remain unchanged and fully charged; only the
newly closed proposal's exclusion flag changes. A fresh model reconstructs
owners 15 and 17 in mode 2 from the original A/W source coordinates and their
raw proposal centers. Its augmented score is 216,774.908067 mm², below the best
single's 229,308.162672 and source baseline 244,577.060782. Its original overlap
is still 76,322.315097 mm². No optimized ancestor supplies an initializer.

[Model controls]({NAME}/selected-model-controls.json) independently verify all
81 coordinates, 528 weighted original/clearance pairs and 15 coefficient-1
auxiliary bracket terms. All legal hard domains and continuous cog angles stay
intact. The selected score agrees exactly with the scalar reference; 152
directed gradient terms differ by at most 5.685e-14 mm. Existing contact and
nearest-feature conventions remain explicit, without a smoothness claim.

[The deadline-aware selector]({NAME}/deadline-controls.json) reproduces the
entire original audited pool exactly. Six injected expiration points cover
before initialization, after one complete mode, before proposals, after one
proposal, after 1,441 proposals and after the complete 2,854-proposal pool.
Every stop preserves the exact completed prefix and returns no selected
proposal. A real 0.05 s deadline stops after 82 center trials; the observed
cooperative overrun is 0.015768 s and the full control returns in 0.070894 s.
One in-progress geometry batch may overrun; the Windows Job remains the outer
time, memory and process bound. No validation output seeds the search.

[The earlier adaptive pipeline is reconciled]({NAME}/adaptive-history-controls.json)
as a code and validation reference. Both 528-coefficient historical updates
reproduce independently rounded exact-rational arithmetic. [Two additional
validation-only update vectors]({NAME}/weight-update-controls.json), both clamp
limits and the all-zero-loss case also pass. Updated models and scalar
gradients retain every term; auxiliary coefficients do not change.

Full source preparation is **17.623198 s**, including the preceding 16.974380 s
pool and the complete new 0.648818 s preparation wrapper. The independent
preflight wrapper takes 24.366325 s and closes all descendants. A text-extraction
error in the first search-code generator occurs before any generated runner or
search exists; [the original failure and helper]({NAME}/preserved-generator-failure.json)
are preserved. Version 2 corrects only its newline delimiter.

## Finite search and complete replay

The frozen controller permits at most three 8 s L-BFGS-B calls, a selection
deadline at 52 s and a source-check boundary at 54 s inside the preparation-
inclusive 60/90 s limits. Later rounds update the fixed positive bounded weights
using only the preceding augmented winner's area losses. The full augmented
objective scores every center and proposal. A joint must beat both the current
state and the best admissible single by more than 1e-6 mm².

[The result]({NAME}/closed-search-result.json) opens only two new keys. Epoch 0
has 113 optimizer evaluations and 101 retained improvements; all three winner
streams coincide at 53 failed pairs and 39,731.032334 mm² overlap. Epoch 1 has
104 evaluations and 94 retained points. Its original-overlap winner differs
from the shared augmented/unweighted winner:

| Epoch 1 winner | Failed source pairs | Original overlap (mm²) | Unweighted area sum (mm²) |
| --- | ---: | ---: | ---: |
| Original overlap | 50 | 29,249.033408 | 59,731.770000 |
| Augmented / unweighted | 51 | 29,249.898618 | 59,717.242440 |

[Independent response replay]({NAME}/response-audit.json) checks all
**{front['total_evaluation_records_verified']} evaluation records**, **{front['saved_points_verified']}
retained points**, 1,056 runtime weight coefficients, **12,792 center trials**
and **5,708 full proposals**. Every runtime selection score is independently
reconstructed, including the final stopping round. All six full66 source
readbacks cover 1,380 same-sheet pairs, 264 stock edges, 90 holes and 10,026 hole
vertices each. Fixed-part and stock checks pass. No winner is valid.

Preparation-inclusive algorithm/shared totals are **46.232997/46.308978 s**.
The two solve-slice overruns remain recorded in the response audit.
[All five search processes close]({NAME}/closed-search-process.json), with
121,110,528 bytes peak aggregate committed memory. [The initial key]({NAME}/closed-problem-00.json)
and [the adaptive key]({NAME}/closed-problem-01.json) are permanently closed.
All nine prior keys remain closed as well; no native call or third optimizer
call follows the stopping condition.

## Why the next round stopped

[The final selection]({NAME}/selection-stop-diagnostic.json) has baseline
130,033.415542 mm², best single 124,973.258351 mm² and best joint
127,189.937793 mm². The single changes owner 11 to mode 0. The joint adds
owner 2 in mode 2; it is 2,216.679442 mm² worse than the single. Both improve
the baseline, but the frozen joint-only prerequisite correctly rejects the
joint and ends the whole pipeline. The unused candidates are diagnostic only.

[Source-failure diagnosis]({NAME}/outcome-diagnostic.json) records
{diag['positive_area_pairs']} positive area terms, {diag['flat_available_pair_gradient_count']}
flat available pair gradients, {diag['bracket_bracket_source_failures']} bracket/bracket
failures and {diag['cog_lower_y_negative_gradient_blocked']} cogs with lower-y descent blocked.
[Family failures]({NAME}/family-failures.json) and [prior comparisons]({NAME}/prior-comparisons.json)
retain the complete composition and the worse result against the earlier
area-only adaptive construction.

[Next]({NAME}/next-step.json), independently preflight a separately specified
rule accepting the best strict-improving admissible single **or** joint choice.
Reconcile it against the saved complete score readbacks, then build a fresh
original-source initializer with all eleven closed keys excluded and all
preparation charged. No revised rule, successor state or call is prepared.
This pipeline, its optimized winners and unused stopping candidates cannot
be continued or reused as a successor seed. Four earlier arrangements and
440 allocation candidates remain unresolved.

[At review]({NAME}/main-ci-at-review.json), main 193660c4 has {success} passed
jobs and {live} live jobs; the workflow aggregate also passed at review.
The preceding 760d2ee6 checkpoint and this one are ready for the ordinary
commit/push checks. Product code, README claims and releases are unchanged.

[Archive verification]({NAME}/archive-checks.json),
[manifest]({NAME}/raw-manifest.json), [source bindings]({NAME}/source-bindings.json),
[historical references]({NAME}/external-evidence.json) and
[runtime pins]({NAME}/runtime-bindings.json) preserve the complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 adaptive augmented construction:** [independent preflight and full response replay]({link}) verify the new original-source initializer, complete deadline-aware selector, six injected stops and one real-time stop with preserved partial prefixes. All 2,854 source proposal scores are independently re-ranked against nine closed keys; every consumed source stage is charged. The fixed positive area-only weight rule and unchanged 528 area/15 auxiliary terms pass scalar controls. Two new optimizer keys close after 217 evaluations and 195 retained points; all 219 records, 12,792 runtime centers, 5,708 proposals, 1,056 updated coefficients and six full66 winner outputs replay. The best original-area winner fails 50 pairs with 29,249.033408 mm² overlap; the augmented/unweighted winner fails 51. Fixed-part and stock checks pass. The result remains worse than the earlier area-only adaptive construction. Complete preparation is 17.623198 s and algorithm/shared totals are 46.232997/46.308978 s; all processes close and slice overruns remain preserved. The third selection correctly stops because its best single beats the best joint by 2,216.679442 mm² under the frozen joint-only rule. Next preflight accepting the best admissible strict-improving single or joint from a new original-source initializer; no successor is prepared and no saved optimized/stopping candidate may seed it. All eleven keys and the current pipeline remain closed. The pre-generation newline-extraction failure and corrected generator remain preserved. No native call or allocation exclusion follows. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. All six jobs and the aggregate on main 193660c4 pass; prior checkpoint 760d2ee6 and this one are ready for the ordinary commit/push checks. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [adaptive augmented construction](../benchmarks/results/{NAME}.md).
The source initializer, bounded positive weight updates and deadline-aware
selector pass independent checks; six injected stops and one real-time stop
preserve partial results without choosing a candidate. Two distinct optimizer
keys close after 217 evaluations. All 219 records, 195 retained points, 12,792
runtime centers, 5,708 full proposals and six full66 winner outputs replay.
The best original-area candidate still fails 50 pairs with 29,249.033408 mm²
overlap; fixed-part and stock checks pass. This remains worse than the earlier
area-only adaptive result. Complete preparation is 17.623198 s; algorithm/shared
totals are 46.232997/46.308978 s. Every process closes and slice overruns remain.
The third selection stops because its best single beats its best joint under
the frozen joint-only prerequisite. Next preflight selecting the best strict-
improving admissible single or joint from a new original-source initializer.
No successor is prepared. The current pipeline, its winners and all eleven
closed keys stay closed; no native validation or allocation exclusion follows.
Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%.
All six jobs and the aggregate on main 193660c4 pass. The preceding 760d2ee6
checkpoint and this one are ready for the ordinary commit/push checks.
Product code, README and releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
