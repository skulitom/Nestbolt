"""Exclusive bounded independent replay of the completed adaptive pipeline."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/run_h5_adaptive_augmented_preflight_stage_20261107.py').read_text(encoding='utf-8')
source=source.replace("stage=sys.argv[1]","stage='response-audit'").replace("{'preparation':('prepare_h5_adaptive_augmented_preflight_20261107.py',20),'audit':('audit_h5_adaptive_augmented_preflight_20261107.py',180)}","{'response-audit':('audit_h5_adaptive_augmented_response_20261107.py',900)}")
exec(compile(source,str(Path(__file__)),'exec'))
