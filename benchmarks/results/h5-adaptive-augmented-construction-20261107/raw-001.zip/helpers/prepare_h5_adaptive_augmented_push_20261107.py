"""Bind the two pending evidence checkpoints to the completed previous main CI."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/push_h5_augmented_conditional_checkpoints_20261107.py').read_text(encoding='utf-8')
changes={
    'h5-augmented-conditional-main-sync-20261107':'h5-adaptive-augmented-main-sync-20261107',
    "prefixes=('benchmarks/results/h5-augmented-conditional-construction-20261107',)":"prefixes=('benchmarks/results/h5-augmented-conditional-construction-20261107','benchmarks/results/h5-adaptive-augmented-construction-20261107')",
    "['h5-augmented-conditional-construction-20261107']":"['h5-augmented-conditional-construction-20261107','h5-adaptive-augmented-construction-20261107']",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
with (ROOT/'output/push_h5_adaptive_augmented_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
