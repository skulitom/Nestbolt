"""Prepare an ordinary main push, gated on completion of the preceding CI."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/push_h5_bracket_augmented_checkpoints_20261107.py').read_text(encoding='utf-8')
changes={
    'h5-bracket-augmented-main-sync-20261107':'h5-augmented-conditional-main-sync-20261107',
    'cbc49d2cfe1eaec6b750034e42325f8f75dabd0d':'193660c4e7b0840d32f870c6246341f580a3bcf3',
    '42372151646':'42374123784',
    "prefixes=('benchmarks/results/h5-bracket-augmented-construction-20261107',)":"prefixes=('benchmarks/results/h5-augmented-conditional-construction-20261107',)",
    "['h5-bracket-augmented-construction-20261107']":"['h5-augmented-conditional-construction-20261107']",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
with (ROOT/'output/push_h5_augmented_conditional_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
