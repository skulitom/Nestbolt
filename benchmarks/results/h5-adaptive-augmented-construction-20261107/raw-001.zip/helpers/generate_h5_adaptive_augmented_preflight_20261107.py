"""Version deadline support without editing the bound historical selector."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/h5_bracket_augmented_neighbors_20261107.py').read_text(encoding='utf-8')
changes={
    'from itertools import combinations,product':'from itertools import combinations,product\n+import math,time'.replace('\n+','\n'),
    'def neighbors(library,modes,values,weights,identity,region_data,closed_keys):':'''class SelectionDeadline(Exception):
    def __init__(self,evidence):
        self.evidence=evidence
        super().__init__('Complete augmented selection stopped at its deadline')


def neighbors(library,modes,values,weights,identity,region_data,closed_keys,deadline,clock=time.perf_counter):
    assert math.isfinite(deadline)
    aliases=[];trials=[];selections=[];records=[];checks=0
    def checkpoint(stage):
        nonlocal checks
        checks+=1;observed=clock()
        if observed>=deadline:
            raise SelectionDeadline({'complete':False,'status':'SELECTION_DEADLINE','stage':stage,'checkpoints':checks,'deadline':deadline,'observed':observed,'overrun_seconds':observed-deadline,'records':records,'aliases':aliases,'trials':trials,'selections':selections,'selected_proposal':None,'optimizer_calls':0})
    checkpoint('before-model')''',
    'options={};aliases=[];trials=[];selections=[]':'options={}\n    checkpoint(\'after-baseline\')',
    "seen[cls]=mi;bb=mode['center_bounds_mm']":"checkpoint('before-mode');seen[cls]=mi;bb=mode['center_bounds_mm']",
    "    records=[]\n    def emit(selected):":"            checkpoint('after-mode')\n    def emit(selected):\n        checkpoint('before-proposal')",
    '    return records,aliases,trials,selections':"    checkpoint('complete')\n    return records,aliases,trials,selections",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
with (ROOT/'output/h5_augmented_deadline_neighbors_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
stage=(ROOT/'output/run_h5_augmented_neighbors_stage_20261107.py').read_text(encoding='utf-8')
stage=stage.replace("{'preparation':('prepare_h5_augmented_neighbors_20261107.py',20),'audit':('audit_h5_augmented_neighbors_20261107.py',600),'response-audit':('audit_h5_augmented_conditional_response_20261107.py',300)}", "{'preparation':('prepare_h5_adaptive_augmented_preflight_20261107.py',20),'audit':('audit_h5_adaptive_augmented_preflight_20261107.py',180)}")
stage=stage.replace('h5-augmented-conditional-neighbors-{stage}-process-20261107','h5-adaptive-augmented-preflight-{stage}-process-20261107')
with (ROOT/'output/run_h5_adaptive_augmented_preflight_stage_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(stage)
