"""Bind read-only diagnosis to the best original-area epoch, without resuming it."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/diagnose_h5_augmented_conditional_outcome_20261107.py').read_text(encoding='utf-8')
changes={
    "BASE=ROOT/'output/h5-augmented-conditional-neighbors-20261107'":"BASE=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107'",
    "assert checked['passed']":"assert checked['passed'] and checked['best_original']['epoch']==1",
    'response-audit/original-source-checks.json':'response-audit/epoch-01/original-source-checks.json',
    'search/response.json':'search/epoch-01/response.json',
    'search/model.json':'search/epoch-01/model.json',
    "checked['best_original_overlap_mm2']":"checked['best_original']['score_mm2']",
    "('prior_augmented',A)]":"('prior_augmented',A),('prior_augmented_conditional',N)]",
    "A/'response-audit/checks.json',B/":"A/'response-audit/checks.json',N/'response-audit/checks.json',B/",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
source+='''
selection=load(BASE/'search/epoch-02/selection.json');audit=load(BASE/'response-audit/epoch-02-selection/checks.json');assert audit['passed'] and not audit['improves'] and not selection['joint_improves_current_and_single']
single=selection['best_single'];joint=selection['best_joint'];current=selection['current_score'];assert single['augmented_objective_mm2']<joint['augmented_objective_mm2']<current-1e-6
write(OUT/'selection-stop-diagnostic.json',{'passed':True,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'search/epoch-02/selection.json',BASE/'response-audit/epoch-02-selection/checks.json']},'current_augmented_score_mm2':current,'best_single':single,'best_joint':joint,'single_improvement_over_current_mm2':current-single['augmented_objective_mm2'],'joint_improvement_over_current_mm2':current-joint['augmented_objective_mm2'],'single_advantage_over_joint_mm2':joint['augmented_objective_mm2']-single['augmented_objective_mm2'],'joint_only_prerequisite_correctly_stops':True,'best_admissible_single_is_unoptimized':True,'candidate_changed':False,'optimizer_calls':0,'closed_pipeline_resumed':False,'interpretation':'The frozen pipeline requires a joint to beat both baseline and best single. It correctly stops although an admissible single improves baseline. This suggests preflighting a separately specified choice rule that accepts the best strict-improving admissible single or joint, from a new original-source initializer with the complete closed ledger. The unused candidates and current winners remain diagnostic-only; they cannot seed or continue this closed pipeline.'})
'''
with (ROOT/'output/diagnose_h5_adaptive_augmented_outcome_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
