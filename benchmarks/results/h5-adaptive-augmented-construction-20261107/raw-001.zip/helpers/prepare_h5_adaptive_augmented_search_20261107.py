"""Build a versioned finite controller around the verified one-call recorder."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/run_h5_augmented_conditional_search_20261107.py').read_text(encoding='utf-8')
prefix=old[:old.index('def child(started):')].replace("BASE=ROOT/'output/h5-augmented-conditional-neighbors-20261107'","BASE=ROOT/'output/h5-adaptive-augmented-preflight-20261107'")
begin=old.index('    obj=Objective(model,regions,identity);bounds=');end=old.index('\n\n\ndef main():',begin)
body=old[begin:end].replace('OUT/', 'folder/').replace("28.,", "8.,")
body=body[:body.index('    print({k:v for k,v in response.items()')]+"    return response\n"
epoch='''def run_epoch(folder,started,model,lib,identity,regions,key,plan):
    import numpy as np
    from scipy.optimize import minimize
    from h5_bracket_augmented_objective_20261107 import Objective
    from h5_mixed_direct_pose_20261107 import source_rows
    from h5_legacy64_source_readback import audit
'''+body
controller='''
def child(started):
    import scipy
    from h5_bracket_augmented_objective_20261107 import compile_model,Objective,problem_key
    from h5_bracket_augmented_readback_20261107 import verify
    from h5_augmented_deadline_neighbors_20261107 import neighbors,rank,apply_neighbor,SelectionDeadline
    from h5_weighted_original_model_20261107 import update_weights
    from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
    from h5_checked_affinity_20261107 import affinity_mask
    assert scipy.__version__=='1.17.1' and affinity_mask()==4294901760
    assert all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
    plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
    for name,h in load(BASE/'runtime-bindings.json').items():assert digest(ROOT/name)==h,name
    initial=load(BASE/'selected-state.json');lib=load(A/'library.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');classes=family_classes(lib)
    modes=initial['modes'];values=initial['values'];weights=initial['pair_weights'];old_closed={r['key'] for r in load(BASE/'closed-problems.json')};visited=set(old_closed)
    summaries=[];best_original=None;best_unweighted=None;valid_witness=None;stop='MAXIMUM_EPOCHS';total_trials=0;total_centers=0;updates=0
    for epoch in range(plan['maximum_optimizer_calls']):
        if time.perf_counter()-started>=plan['selection_boundary_seconds']:stop='TIME_STOP_BEFORE_EPOCH';break
        folder=OUT/f'epoch-{epoch:02d}';folder.mkdir();incoming=list(values)
        write(folder/'opened.json',{'epoch':epoch,'incoming_values':incoming,'incoming_modes':modes,'weights_before_update':weights,'visited_keys':sorted(visited),'algorithm_seconds_including_preparation':time.perf_counter()-started})
        if epoch:
            previous=compile_model(lib,modes,incoming,weights,identity);losses=Objective(previous,regions,identity).pair_losses(incoming).tolist();after=update_weights(weights,losses)
            write(folder/'weight-transition.json',{'before':weights,'pair_losses_mm2':losses,'after':after,'source':'previous_epoch_augmented_best','auxiliary_excluded_from_weight_update':True});weights=after;updates+=1
            try:
                records,aliases,trials,selections=neighbors(lib,modes,incoming,weights,identity,regions,visited,deadline=started+plan['selection_boundary_seconds'])
            except SelectionDeadline as exc:
                write(folder/'partial-selection.json',exc.evidence);stop='SELECTION_DEADLINE';break
            write(folder/'neighbors.json',records);write(folder/'owner-aliases.json',aliases);write(folder/'center-trials.json',trials);write(folder/'center-selections.json',selections);total_trials+=len(records);total_centers+=len(trials)
            singles=[r for r in records if not r['excluded'] and len(r['changes'])==1];joints=[r for r in records if not r['excluded'] and len(r['changes'])==2]
            single=min(singles,key=rank) if singles else None;joint=min(joints,key=rank) if joints else None;baseline=records[0]['augmented_objective_mm2'];improves=single is not None and joint is not None and joint['augmented_objective_mm2']<min(single['augmented_objective_mm2'],baseline)-1e-6
            write(folder/'selection.json',{'best_single':single,'best_joint':joint,'current_score':baseline,'joint_improves_current_and_single':improves})
            if not improves:stop='NO_IMPROVING_JOINT';break
            modes,model,point=apply_neighbor(lib,modes,incoming,weights,identity,joint);incoming=point.tolist()
        else:
            model=compile_model(lib,modes,incoming,weights,identity);assert model==load(BASE/'selected-model.json')
        assert verify(model,lib,modes,incoming,weights,identity)
        key=problem_key(physical_key(lib,classes,modes),weights,identity);assert key not in visited
        if time.perf_counter()-started>=plan['source_reserve_boundary_seconds']:stop='TIME_STOP_BEFORE_CALL';break
        write(folder/'model.json',model);assert verify(load(folder/'model.json'),lib,modes,incoming,weights,identity)
        visited.add(key);response=run_epoch(folder,started,model,lib,identity,regions,key,plan)
        for label,field in [('original','original_overlap_area_mm2'),('unweighted','unweighted_objective_mm2')]:
            r=response['winners'][label];candidate={'epoch':epoch,'label':label,'metric':field,'score_mm2':r[field],'pair_failures':response['source_readbacks'][label]['pair_failures'],'source_valid66':response['source_readbacks'][label]['source_valid66']}
            if label=='original' and (best_original is None or candidate['score_mm2']<best_original['score_mm2']):best_original=candidate
            if label=='unweighted' and (best_unweighted is None or candidate['score_mm2']<best_unweighted['score_mm2']):best_unweighted=candidate
        if response['valid_witness'] is not None:valid_witness={'epoch':epoch,**response['valid_witness']}
        summary={'epoch':epoch,'key':key,'status':response['status'],'function_evaluations':response['function_evaluations'],'saved_points':response['saved_points'],'source_readbacks':response['source_readbacks'],'minimum_weight':min(weights),'maximum_weight':max(weights)}
        summaries.append(summary);print(summary,flush=True);values=response['winners']['augmented']['values']
        if valid_witness is not None:stop='SOURCE_VALID_CANDIDATE';break
        if time.perf_counter()-started>=plan['source_reserve_boundary_seconds']:stop='TIME_STOP_AFTER_SOURCE_CHECK';break
    elapsed=time.perf_counter()-started
    result={'closed':True,'status':stop,'optimizer_calls':len(summaries),'unique_new_keys':len(visited)-len(old_closed),'historical_closed_keys':len(old_closed),'weight_updates':updates,'complete_runtime_proposals':total_trials,'complete_runtime_centers':total_centers,'epochs':summaries,'best_original':best_original,'best_unweighted':best_unweighted,'source_valid66':valid_witness is not None,'valid_witness':valid_witness,'complete_preparation_seconds':plan['complete_preparation_seconds'],'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'old_calls_resumed':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False,'retry_permitted':False}
    write(OUT/'result.json',result);print({k:v for k,v in result.items() if k!='epochs'})


def main():
    checked=load(BASE/'audit/checks.json');assert checked['passed'] and checked['joint_improves_current_and_single'];OUT.mkdir();charge=checked['complete_preparation_seconds'];started=time.perf_counter()-charge
    inputs=[Path(__file__),JOB]+[BASE/n for n in ['plan.json','checks.json','selected-model.json','selected-state.json','selection.json','closed-problems.json','runtime-bindings.json','audit/plan.json','audit/checks.json','audit/deadline-controls.json','audit/selected-model-controls.json','audit/weight-update-controls.json']]+[A/n for n in ['library.json','objective-identity.json','audit-v2/optimizer-controls.json']]+[B/'regions.json']+[ROOT/'output'/n for n in ['h5_augmented_deadline_neighbors_20261107.py','h5_bracket_augmented_objective_20261107.py','h5_bracket_augmented_readback_20261107.py','h5_weighted_original_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py','h5_checked_affinity_20261107.py']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'complete_preparation_seconds':charge,'algorithm_seconds':60,'shared_seconds':90,'source_reserve_boundary_seconds':54,'selection_boundary_seconds':52,'memory_bytes':2**31,'cpu_affinity_mask':4294901760,'blas_threads':1,'maximum_optimizer_calls':3,'optimizer_slice_seconds':8.,'method':'One finite adaptive augmented pipeline from the independently audited new original-source joint. All consumed source preparation is charged. Exclude all nine prior identities and close every new complete objective/physical-mode/weight key after one call. At most three eight-second calls, each shortened at54seconds. After each call source-check all three winner streams and stop on valid66. Later epochs update the fixed bounded area-only weight rule from the preceding augmented winner inside this pipeline, retaining coefficient1 auxiliary terms. Deadline-aware selection evaluates all6396source centers and2854full augmented proposals; a joint must strictly improve current and best admissible single by1e-6. Stop at52seconds during selection, preserving partial evidence with no chosen candidate. Verify every dynamic model before its call. Record every evaluation and all augmented/original/unweighted strict improvements. Global original and unweighted winners are comparable across epochs; augmented winners remain local to their weight vector. Source validity is authoritative. Stop on finite count, time, partial/no-improvement selection, valid source or inconsistency. No historical optimized seed, restart, reseed, grid refinement or native call.','retry_permitted':False,'restarts':0})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE);cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'complete_preparation_seconds':charge,'memory_bytes':2**31,'retry_permitted':False})
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1');r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(Path(__file__)),'--child',str(started)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env);(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0
    write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'retry_permitted':False});print(load(OUT/'process.json'));print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No complete result; pipeline remains closed.')

if __name__=='__main__':
    if '--child' in sys.argv:child(float(sys.argv[2]))
    else:main()
'''
with (ROOT/'output/run_h5_adaptive_augmented_search_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+epoch+controller)

# Extract the complete read-only per-call replay without changing its math.
audit=(ROOT/'output/audit_h5_augmented_conditional_response_20261107.py').read_text(encoding='utf-8')
header=audit[:audit.index('OUT.mkdir();started=')].replace("BASE=ROOT/'output/h5-augmented-conditional-neighbors-20261107'","BASE=ROOT/'output/h5-adaptive-augmented-preflight-20261107'")
body=audit[audit.index('assert verify(model,lib,initial'):audit.index("process=load(S/'process.json')")]
body=body.replace(" and model==load(BASE/'selected-model.json')",'').replace("key=load(BASE/'selected-state.json')['key']","key=initial['key']")
body=body.replace("assert key not in {r['key'] for r in load(BASE/'closed-problems.json')}","assert key not in closed_keys")
result="""
write(OUT/'all-evaluation-replay.json',replay);write(OUT/'winner-reconciliation.json',readbacks)
return {'records':records,'saved_points':saved,'function_evaluations':response['function_evaluations'],'score_error':max(score_errors),'original_error':max(original_errors),'gradient_error':max_gradient_error,'readbacks':readbacks,'valid_witness':valid_witness,'distinct_winners':len({r['evaluation'] for r in winners.values()})}
"""
function="def audit_epoch(S,OUT,lib,initial,identity,regions,closed_keys):\n    OUT.mkdir();model=load(S/'model.json');response=load(S/'response.json')\n"+'\n'.join('    '+line if line else '' for line in (body+result).splitlines())+'\n'
with (ROOT/'output/h5_adaptive_augmented_epoch_readback_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(header+function)
