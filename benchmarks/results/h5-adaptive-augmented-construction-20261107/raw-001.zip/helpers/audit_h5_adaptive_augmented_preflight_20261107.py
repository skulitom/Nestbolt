"""Independently verify source re-ranking, partial stops and bounded weights."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,time,os,copy
import numpy as np
from h5_augmented_deadline_neighbors_20261107 import neighbors,SelectionDeadline
from h5_augmented_selection_readback_20261107 import independent_classes
from h5_augmented_selection_score_reference_20261107 import FullScore
from h5_bracket_augmented_reference_20261107 import Reference
from h5_bracket_augmented_readback_20261107 import verify
from h5_bracket_augmented_objective_20261107 import Objective,compile_model
from h5_weighted_original_model_20261107 import update_weights
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-adaptive-augmented-preflight-20261107';OUT=BASE/'audit';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def independent_update(before,losses):
    peak=max(losses);result=[]
    for weight,loss in zip(before,losses):
        if loss==0:raw=float(F(weight)*F(.95))
        else:
            ratio=float(F(loss)/F(peak));scaled=float(F(.8)*F(ratio));factor=float(F(1.2)+F(scaled));raw=float(F(weight)*F(factor))
        result.append(min(64.,max(1.,raw)))
    return result
OUT.mkdir();start=time.perf_counter();plan=load(BASE/'plan.json');assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
for name,h in load(BASE/'runtime-bindings.json').items():assert digest(ROOT/name)==h,name
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','neighbors.json','closed-problems.json','selection.json','runtime-bindings.json']]+[ROOT/'output/h5-adaptive-augmented-preflight-preparation-process-20261107/process.json']
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');classes=independent_classes(lib);closed=load(BASE/'closed-problems.json');prior=load(N/'closed-problems.json');last=load(N/'search/closed-problem.json')
assert len(closed)==9 and closed[:-1]==prior and closed[-1]=={'key':last['key'],'objective':identity['version'],'source':'output/h5-augmented-conditional-neighbors-20261107/search/closed-problem.json'} and last['closed']
keys={r['key'] for r in closed};assert len(keys)==9;original=load(N/'neighbors.json');records=load(BASE/'neighbors.json');readbacks=load(N/'audit/selection-replay/proposal-score-controls.json');assert len(original)==len(records)==len(readbacks)==2854
changes=[];independent={};maxerror=0.
for prior_row,row,readback in zip(original,records,readbacks):
    expected=copy.deepcopy(prior_row);expected['excluded']=row['key'] in keys;expected['exclusion_reason']='closed_objective_problem' if expected['excluded'] else None;assert row==expected
    if row!=prior_row:changes.append(row['sequence'])
    physical=[classes[f][mi] for (f,_),mi in zip(lib['identities'],row['modes'])]
    key=sha256(json.dumps({'physical':physical,'weights':initial['pair_weights'],'objective_identity':identity},sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    assert row['physical_key']==physical and row['key']==key and readback['sequence']==row['sequence'];independent[row['sequence']]=readback['augmented_objective_mm2']
    for field in ['augmented_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2','unweighted_objective_mm2']:
        error=abs(row[field]-readback[field]);assert error<1e-6;maxerror=max(maxerror,error)
assert changes==[load(N/'selection.json')['best_joint']['sequence']] and sum(r['excluded'] for r in records)==2
winners=[];rank_controls=[]
for count in [1,2]:
    eligible=[r for r in records if not r['excluded'] and len(r['changes'])==count];chosen=min(eligible,key=lambda r:(r['augmented_objective_mm2'],r['modes']));oracle=min(eligible,key=lambda r:(independent[r['sequence']],r['modes']));gap=independent[chosen['sequence']]-independent[oracle['sequence']];assert gap<=1e-6
    winners.append(chosen);rank_controls.append({'changed_owners':count,'producer_sequence':chosen['sequence'],'independent_sequence':oracle['sequence'],'independent_score_gap_mm2':gap})
single,joint=winners;baseline=records[0]['augmented_objective_mm2'];improves=joint['augmented_objective_mm2']<min(single['augmented_objective_mm2'],baseline)-1e-6
if improves:assert independent[joint['sequence']]<min(independent[single['sequence']],independent[0])-1e-6
assert load(BASE/'selection.json')=={'best_single':single,'best_joint':joint,'current_score':baseline,'joint_improves_current_and_single':improves}
write(OUT/'source-ranking-controls.json',{'passed':True,'proposals':2854,'source_center_trials_reused':6396,'changed_records':changes,'closed_keys':9,'excluded_choices':2,'ranking':rank_controls,'maximum_score_error_mm2':maxerror,'joint_improves':improves})
print({'source_ranking_passed':True,'joint_improves':improves},flush=True)

# The validation call is discarded after exact comparison; no output seeds search.
expected=(records,load(N/'owner-aliases.json'),load(N/'center-trials.json'),load(N/'center-selections.json'))
before=time.perf_counter();complete=neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys,deadline=before+30)
assert complete==expected;complete_seconds=time.perf_counter()-before
controls=[]
class Clock:
    def __init__(self,stop):self.stop=stop;self.calls=0
    def __call__(self):self.calls+=1;return 1. if self.calls>=self.stop else 0.
def check_prefix(evidence):
    assert evidence['complete'] is False and evidence['status']=='SELECTION_DEADLINE' and evidence['selected_proposal'] is None and evidence['optimizer_calls']==0
    for field,full in zip(['records','aliases','trials','selections'],expected):assert evidence[field]==full[:len(evidence[field])]
    assert len(evidence['trials'])%82==0 and len(evidence['selections'])==len(evidence['trials'])//82
    assert evidence['observed']>=evidence['deadline'] and evidence['overrun_seconds']==evidence['observed']-evidence['deadline']
for expiry in plan['deadline_validation']['synthetic_expiry_checkpoints']:
    timer=Clock(expiry);returned=False;before=time.perf_counter()
    try:neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys,deadline=1.,clock=timer);returned=True
    except SelectionDeadline as exc:
        evidence=exc.evidence;check_prefix(evidence);assert timer.calls==expiry;write(OUT/f'deadline-{expiry:04d}.json',evidence)
        controls.append({'expiry_checkpoint':expiry,'stage':evidence['stage'],'preserved_trials':len(evidence['trials']),'preserved_proposals':len(evidence['records']),'seconds':time.perf_counter()-before,'selected_proposal':None})
    assert not returned
    print(controls[-1],flush=True)
before=time.perf_counter();deadline=before+plan['deadline_validation']['real_deadline_seconds'];returned=False
try:neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,regions,keys,deadline=deadline);returned=True
except SelectionDeadline as exc:
    evidence=exc.evidence;check_prefix(evidence);write(OUT/'deadline-real.json',evidence);real={'stage':evidence['stage'],'elapsed_seconds':time.perf_counter()-before,'requested_seconds':.05,'observed_overrun_seconds':evidence['overrun_seconds'],'preserved_trials':len(evidence['trials']),'preserved_proposals':len(evidence['records']),'selected_proposal':None}
assert not returned
write(OUT/'deadline-controls.json',{'passed':True,'full_result_exactly_preserved':True,'full_validation_seconds':complete_seconds,'synthetic_cases':controls,'real_case':real,'cooperative_limit':'Stops between complete geometry batches or proposals; one in-progress batch may overrun, recorded explicitly. A Windows Job remains the outer process/time/memory bound. No partial selector result can return normally.','validation_only':True,'optimizer_calls':0})

# Read the earlier pipeline's recorded updates only as validation evidence.
historic=[]
for epoch in [1,2]:
    p=R/f'search/epoch-{epoch:02d}/weight-transition.json';transition=load(p);inputs.append(p)
    assert transition['source']=='previous_epoch_weighted_best' and independent_update(transition['before'],transition['pair_losses_mm2'])==transition['after']==update_weights(transition['before'],transition['pair_losses_mm2'])
    historic.append({'epoch':epoch,'coefficients':len(transition['after']),'minimum':min(transition['after']),'maximum':max(transition['after'])})
history=load(R/'response-audit/checks.json');assert history['passed'] and history['closed_optimizer_calls']==3 and history['weight_update_vectors']==2 and history['weight_update_coefficients_verified']==1056
inputs+=[R/'response-audit/plan.json',R/'response-audit/checks.json',R/'search/plan.json']
for historical_plan in [R/'response-audit/plan.json',R/'search/plan.json']:
    for name,h in load(historical_plan)['inputs'].items():assert digest(ROOT/name)==h,name
write(OUT/'adaptive-history-controls.json',{'passed':True,'prior_closed_calls':3,'historical_updates':historic,'prior_fully_replayed_center_trials':history['runtime_center_trials_verified'],'prior_saved_points':history['saved_points_verified'],'scope':'Code and read-only validation reference only. No prior optimized point or selected center is consumed by new preparation. Prior area-only identities remain closed. New augmented runtime needs complete selection and response readback.','known_changes_required':['bounded deadline-aware selector','three incumbent streams and every evaluation','full augmented objective in every conditional score','nine prior keys excluded','six-second final source-check reserve','independent updated-weight and dynamic-model verification']})

model_controls=None;weight_controls=[]
if improves:
    modes=initial['modes'].copy();point=initial['values'].copy()
    for (i,mi),center in zip(joint['changes'],joint['centers']):modes[i]=mi;point[2*i:2*i+2]=center
    state=load(BASE/'selected-state.json');model=load(BASE/'selected-model.json');weights=initial['pair_weights'];assert state=={'modes':modes,'values':point,'pair_weights':weights,'key':joint['key'],'objective_identity':identity} and joint['key'] not in keys
    inputs+=[BASE/'selected-model.json',BASE/'selected-state.json'];assert verify(model,lib,modes,point,weights,identity)
    oracle=FullScore(lib,weights,regions);full=oracle(modes,point);assert abs(full['augmented_objective_mm2']-joint['augmented_objective_mm2'])<1e-6
    reference=Reference(lib);obj=Objective(model,regions,identity);value,g,d=obj.evaluate(point,True);rv,rg,rd=reference.evaluate(model,point,True,d['auxiliary_terms']);assert abs(value-rv)<1e-6 and np.max(np.abs(g-rg))<1e-6
    model_controls={'passed':True,'parameters':81,'moving_owners':33,'all_area_pairs':528,'all_auxiliary_pairs':15,'selected_changes':joint['changes'],'key':joint['key'],'augmented_objective_mm2':value,'original_overlap_mm2':d['original_overlap_area_mm2'],'maximum_scalar_gradient_error_mm':float(np.max(np.abs(g-rg))),'independent_score_error_mm2':abs(value-rv),'scalar_directed_gradient_terms':rd['directed_scalar_gradient_terms'],'gradient_interpretation':'Existing selected source-boundary/nearest-feature conventions only; no blanket smooth derivative claim.','optimized_ancestor_consumed':False}
    write(OUT/'selected-model-controls.json',model_controls)
    for step in range(2):
        losses=obj.pair_losses(point).tolist();rv,rg,rd=reference.evaluate(model,point,True,d['auxiliary_terms']);assert np.max(np.abs(np.array(losses)-rd['pair_losses_mm2']))<1e-7
        after=update_weights(weights,losses);assert after==independent_update(weights,losses) and all(1<=w<=64 for w in after)
        changed=compile_model(lib,modes,point,after,identity);assert verify(changed,lib,modes,point,after,identity) and changed['supplementary_objective']==model['supplementary_objective']
        updated=Objective(changed,regions,identity);uv,ug,ud=updated.evaluate(point,True);ur,urg,urd=reference.evaluate(changed,point,True,ud['auxiliary_terms']);assert abs(uv-ur)<1e-6 and np.max(np.abs(ug-urg))<1e-6 and ud['auxiliary_bracket_depth_mm2']==d['auxiliary_bracket_depth_mm2']
        write(OUT/f'weight-control-{step:02d}.json',{'validation_only':True,'before':weights,'pair_losses_mm2':losses,'after':after,'updated_model':changed})
        weight_controls.append({'step':step,'coefficients':528,'minimum':min(after),'maximum':max(after),'max_pair_loss_error_mm2':float(np.max(np.abs(np.array(losses)-rd['pair_losses_mm2']))),'score_error_mm2':abs(uv-ur),'gradient_error_mm':float(np.max(np.abs(ug-urg))),'auxiliary_unchanged':True});weights=after;model=changed;obj=updated;d=ud
    # Exercise both clamps and the all-zero peak without a new geometry state.
    edge_before=[1.,64.,63.9,1.,32.,64.];edge_losses=[0.,0.,1.,1.,.5,1.];zeros=[0.]*6
    assert update_weights(edge_before,edge_losses)==independent_update(edge_before,edge_losses)
    assert update_weights(edge_before,zeros)==independent_update(edge_before,zeros)
    write(OUT/'weight-update-controls.json',{'passed':True,'source_validation_steps':weight_controls,'edge_before':edge_before,'edge_losses':edge_losses,'edge_after':update_weights(edge_before,edge_losses),'zero_after':update_weights(edge_before,zeros),'validation_only':True,'optimizer_calls':0})
else:assert not (BASE/'selected-model.json').exists() and not (BASE/'selected-state.json').exists()
prep=load(ROOT/'output/h5-adaptive-augmented-preflight-preparation-process-20261107/process.json');assert prep['passed'] and prep['closed'] and prep['job']['active_processes']==0
charge=plan['source_pool_preparation_seconds']+prep['complete_seconds'];assert plan['source_pool_preparation_seconds']==load(N/'audit/checks.json')['complete_preparation_seconds']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently re-rank every saved full source-score readback with expanded closed keys. Verify all retained proposal fields and their identity. Freshly reconstruct selected model, source score and scalar gradient. Require complete deadline selector output identical to original audited pool; test six synthetic interruption boundaries and one real deadline, retaining exact partial prefixes with no returned selection. Replay old adaptive weight updates and two validation-only updates plus clamps/zero cases using rationally rounded binary64. No optimizer, no candidate update or new search contract.'})
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in data.get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json','plan-v2.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings)
summary={'passed':True,'seconds':time.perf_counter()-start,'source_bindings':len(bindings),'prior_source_scores_reranked':2854,'source_center_trials_reused':6396,'closed_keys':9,'excluded_choices':2,'joint_improves_current_and_single':improves,'fresh_selected_model_readback':model_controls is not None,'complete_deadline_selector_matches':True,'synthetic_deadline_cases':6,'real_deadline_cases':1,'partial_results_preserved':True,'partial_selection_returned':False,'historical_update_coefficients_verified':1056,'new_validation_update_coefficients_verified':len(weight_controls)*528,'new_selector_preparation_seconds':prep['complete_seconds'],'complete_preparation_seconds':charge,'optimized_ancestor_consumed':False,'validation_outputs_used_as_seed':False,'optimizer_calls':0,'pipeline_prepared':False,'native_calls':0,'any_allocation_excluded':False,'H5_complete':False}
write(OUT/'checks.json',summary);print(summary)
