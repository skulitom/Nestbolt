"""Re-rank the audited original source pool after closing its previous winner."""
from pathlib import Path
from hashlib import sha256
import json,time,os,copy
from h5_bracket_augmented_neighbors_20261107 import rank,apply_neighbor
from h5_bracket_augmented_objective_20261107 import Objective
from h5_bracket_augmented_readback_20261107 import verify
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
parent=ROOT/'benchmarks/results/h5-augmented-conditional-construction-20261107';assert load(parent/'archive-checks.json')['passed']
assert load(N/'audit/checks.json')['passed'] and load(N/'response-audit/checks.json')['passed'] and load(R/'response-audit/checks.json')['passed']
inputs=[Path(__file__),parent/'next-step.json',parent/'archive-checks.json']+[ROOT/'output'/n for n in ['h5_augmented_deadline_neighbors_20261107.py','generate_h5_adaptive_augmented_preflight_20261107.py','audit_h5_adaptive_augmented_preflight_20261107.py','h5_bracket_augmented_neighbors_20261107.py','h5_bracket_augmented_objective_20261107.py','h5_bracket_augmented_readback_20261107.py','h5_weighted_original_model_20261107.py','run_h5_weighted_relocated_search_20261107.py','audit_h5_weighted_relocated_response_20261107.py']]+[N/n for n in ['plan.json','neighbors.json','center-trials.json','center-selections.json','owner-aliases.json','closed-problems.json','audit/checks.json','audit/selection-replay/checks.json','audit/selection-replay/proposal-score-controls.json','search/closed-problem.json','response-audit/checks.json','runtime-bindings.json']]+[A/n for n in ['library.json','initial-state.json','objective-identity.json']]+[B/'regions.json',R/'response-audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reuse the complete independently audited original-source pool and all of its preparation cost. Change only closed-ledger flags after the latest sole call; rank all 2854 proposals against nine closed keys. Independently reconcile every retained proposal score and select a new joint only if it improves current source and best admissible single. Reconstruct its full model from original A/W initializer plus the raw proposal. No optimized state seeds preparation. Versioned deadline selector and old adaptive runner/response reader are code references; their controls are validation only.',
    'source_pool_preparation_seconds':load(N/'audit/checks.json')['complete_preparation_seconds'],'closed_keys':9,'score_tolerance_mm2':1e-6,'strict_joint_improvement_mm2':1e-6,
    'deadline_validation':{'complete_output':'exact comparison with all source pool centers/aliases/proposals','synthetic_expiry_checkpoints':[1,4,159,160,1600,3013],'real_deadline_seconds':.05,'partial_policy':'serialize complete captured prefix, no selected proposal, no optimizer; no reuse as successor state','validation_cap_seconds':180},
    'weight_validation':'Reconcile both prior adaptive area-only updates using independently rounded exact-rational operations. Validate the same fixed bounded positive update on the new unoptimized selected model and on its validation-only next weight vector. Preserve all 528 area and 15 auxiliary terms. No control output seeds a search.',
    'preparation_cap_seconds':20,'memory_bytes':2**31,'optimizer_calls':0,'pipeline_prepared':False,'retry_permitted':False})
closed=load(N/'closed-problems.json');last=load(N/'search/closed-problem.json');assert last['closed'] and not last['retry_permitted'];identity=load(A/'objective-identity.json')
closed=closed+[{'key':last['key'],'objective':identity['version'],'source':'output/h5-augmented-conditional-neighbors-20261107/search/closed-problem.json'}];keys={r['key'] for r in closed};assert len(keys)==9
write(OUT/'closed-problems.json',closed);records=copy.deepcopy(load(N/'neighbors.json'))
for row in records:row['excluded']=row['key'] in keys;row['exclusion_reason']='closed_objective_problem' if row['excluded'] else None
write(OUT/'neighbors.json',records)
single=min((r for r in records if len(r['changes'])==1 and not r['excluded']),key=rank);joint=min((r for r in records if len(r['changes'])==2 and not r['excluded']),key=rank);baseline=records[0]['augmented_objective_mm2'];improves=joint['augmented_objective_mm2']<min(single['augmented_objective_mm2'],baseline)-1e-6
write(OUT/'selection.json',{'best_single':single,'best_joint':joint,'current_score':baseline,'joint_improves_current_and_single':improves})
if improves:
    lib=load(A/'library.json');initial=load(A/'initial-state.json');modes,model,values=apply_neighbor(lib,initial['modes'],initial['values'],initial['pair_weights'],identity,joint)
    assert verify(model,lib,modes,values,initial['pair_weights'],identity) and abs(Objective(model,load(B/'regions.json'),identity).score(values)-joint['augmented_objective_mm2'])<1e-6
    write(OUT/'selected-model.json',model);write(OUT/'selected-state.json',{'modes':modes,'values':values.tolist(),'pair_weights':initial['pair_weights'],'key':joint['key'],'objective_identity':identity})
runtime=load(N/'runtime-bindings.json')
for name,h in runtime.items():assert digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'source_proposals_reused':2854,'source_center_trials_reused':6396,'closed_keys':len(keys),'excluded_choices':sum(r['excluded'] for r in records),'best_single_score_mm2':single['augmented_objective_mm2'],'best_joint_score_mm2':joint['augmented_objective_mm2'],'joint_improves_current_and_single':improves,'optimizer_calls':0,'optimized_ancestor_consumed':False,'H5_complete':False})
print(load(OUT/'checks.json'))
