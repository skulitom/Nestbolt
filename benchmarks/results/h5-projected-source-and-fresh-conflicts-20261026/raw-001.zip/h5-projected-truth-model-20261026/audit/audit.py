"""Independently verify exact unary channels and monotone auxiliary completion."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,time,shutil,traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-projected-truth-model-20261026';PARENT=ROOT/'output/h5-projected-expanded-model-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def unary(v,lo,hi,en):
    c=cp_model_pb2.ConstraintProto();c.linear.vars.append(v);c.linear.coeffs.append(1);c.linear.domain.extend([lo,hi]);c.enforcement_literal.append(en);return c
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Verify unchanged audited projected parent through its committed source chain. Independently reconstruct every retained unary plane and appended complementary integer halfline. Inspect every old direction-flag occurrence to prove monotone completion is valid. Restore the complete parent by dropping only appended constraints. Verify all original fields/hints, exact two-way placement feasibility and real solver import/export. No solver.'})
    for p in [BASE/'plan.json',PARENT/'audit/plan.json']:
        for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
    manifest=load(ROOT/'benchmarks/results/h5-expanded-source-search-20261026/raw-manifest.json');known={r['sha256'] for r in manifest['files']+manifest['aliases']}
    for n,h in load(PARENT/'plan.json')['inputs'].items():assert digest(ROOT/n)==h and h in known,n
    pc=load(PARENT/'audit/checks.json');assert pc['passed'] and pc['complete_parent_restored_exactly'] and pc['exact_two_way_parent_projection_verified'];old=cp_model_pb2.CpModelProto();old.ParseFromString((PARENT/'model.pb').read_bytes());new=cp_model_pb2.CpModelProto();new.ParseFromString((BASE/'model.pb').read_bytes());assert len(old.variables)==223086 and len(old.constraints)==289916
    for n in ['mapping.json','shared-directions.json','necessary-rules.json','advisory-hints.json','projections.json','replacements.json']:assert (BASE/n).read_bytes()==(PARENT/n).read_bytes()
    records=load(PARENT/'replacements.json');complements=load(BASE/'complements.json');assert len(records)==len(complements)==201575;flags={r['flag'] for r in records};byflag={r['flag']:r for r in records};assert len(flags)==201575;en=Counter();oruses=Counter()
    for c in old.constraints:
        kind=c.WhichOneof('constraint');assert kind in ['linear','bool_or']
        for v in c.enforcement_literal:
            if (v if v>=0 else -v-1) in flags:
                assert v in flags and list(c.enforcement_literal)==[v];r=byflag[v];assert c==old.constraints[r['constraint']];en[v]+=1
        if kind=='linear':assert not flags.intersection(c.linear.vars)
        else:
            for v in c.bool_or.literals:
                if (v if v>=0 else -v-1) in flags:assert v in flags;oruses[v]+=1
    assert set(en)==set(oruses)==flags and all(n==1 for n in en.values()) and not flags.intersection(old.solution_hint.vars)
    for i,(r,record) in enumerate(zip(records,complements)):
        assert record=={'constraint':len(old.constraints)+i,**{k:r[k] for k in ['flag','projection','new_bound','sense']}};z=r['projection'];C=r['new_bound'];flag=r['flag']
        if r['sense']=='ge':positive=unary(z,C,2**63-1,flag);negative=unary(z,-2**63,C-1,-flag-1)
        else:assert r['sense']=='le';positive=unary(z,-2**63,C,flag);negative=unary(z,C+1,2**63-1,-flag-1)
        assert old.constraints[r['constraint']]==positive and new.constraints[len(old.constraints)+i]==negative
    assert new.constraints[:len(old.constraints)]==old.constraints and len(new.constraints)==491491 and new.variables==old.variables and new.solution_hint==old.solution_hint and len(new.solution_hint.vars)==54
    restored=cp_model_pb2.CpModelProto();restored.CopyFrom(new);del restored.constraints[len(old.constraints):];assert restored==old
    write(OUT/'equivalence-proof.json',{'retained_original_constraints':len(old.constraints),'appended_complements':len(records),'all_positive_plane_definitions_checked':len(en),'positive_source_OR_occurrences':sum(oruses.values()),'negative_arithmetic_or_hint_uses_of_old_direction_flags':0,'child_to_parent':'Drop only the appended complementary constraints; all parent constraints and other fields are exactly present.','parent_to_child':'Preserve every coordinate, query/domain/sheet choice, active-pair variable and exact projection variable. Set each auxiliary direction flag to the truth of its already verified unary threshold. A previously true flag implies that threshold and remains true. Only false-to-true changes are possible. The exhaustive occurrence audit permits only positive source OR literals and enforcement of the flag own threshold, so no old constraint can become false. The complementary integer halfline holds whenever its flag is false. Thus the full exact-channel extension exists for every feasible parent placement.','scope':'Exact same feasible projection onto physical placement/selector/projection variables, with direction auxiliaries allowed to change. No claimed equality of all auxiliary assignments. Full original66-part/12-mover/54-fixed restrictions, all538 pair modes and guards remain.'})
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'solver-import-roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert actual==new and digest(BASE/'model.pb')==load(BASE/'result.json')['model_sha256']
    checks={'passed':True,'seconds':time.perf_counter()-start,'variables':len(new.variables),'constraints':len(new.constraints),'hints':54,'appended_complements_verified':len(records),'positive_plane_definitions_verified':len(en),'positive_OR_occurrences_verified':sum(oruses.values()),'negative_arithmetic_or_hint_uses_in_parent':0,'complete_parent_restored_exactly':True,'exact_two_way_placement_projection_verified':True,'monotone_auxiliary_completion_verified':True,'actual_solver_import_export_verified':True,'required_originals':66,'moving_originals':12,'fixed_originals':54,'same_sheet_pair_modes':538,'original_anchor_variables':24,'signed_projection_variables':8185,'copy_symmetry_exclusions':0,'coordinate_locks':0,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'performance_benefit_demonstrated':False,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
