"""Complete unary projection channels to exact truth, preserving physical feasibility."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-projected-expanded-model-20261026';OUT=ROOT/'output/h5-projected-truth-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed'];paths=[p for p in PARENT.rglob('*') if p.is_file()]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Retain the entire audited223086-variable/289916-constraint projected parent and all54 hints. Append one complementary unary constraint for each shared direction: if the flag is false, a >= threshold becomes <=threshold-1 and a <= threshold becomes >=threshold+1. The flag then equals actual threshold truth. Existential feasibility on all original placement/choice/domain variables and exact projections is preserved because every old flag occurs only positively in source ORs and as enforcement of its own threshold. Saturating false-to-true flags to actual plane truth cannot invalidate a source OR. No geometry change, source-clause deletion, coordinate lock or solver call.'})
    old=cp_model_pb2.CpModelProto();old.ParseFromString((PARENT/'model.pb').read_bytes());new=cp_model_pb2.CpModelProto();new.CopyFrom(old);rows=[]
    for r in load(PARENT/'replacements.json'):
        ci=len(new.constraints);c=new.constraints.add();c.enforcement_literal.append(-r['flag']-1);c.linear.vars.append(r['projection']);c.linear.coeffs.append(1);c.linear.domain.extend([-2**63,r['new_bound']-1] if r['sense']=='ge' else [r['new_bound']+1,2**63-1]);rows.append({'constraint':ci,**{k:r[k] for k in ['flag','projection','new_bound','sense']}})
    for name in ['mapping.json','shared-directions.json','necessary-rules.json','advisory-hints.json','projections.json','replacements.json']:shutil.copyfile(PARENT/name,OUT/name)
    write(OUT/'complements.json',rows);(OUT/'model.pb').write_bytes(new.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(new),encoding='utf-8',newline='\n');result={'seconds':time.perf_counter()-start,'variables':len(new.variables),'constraints':len(new.constraints),'hints':len(new.solution_hint.vars),'parent_variables':len(old.variables),'parent_constraints':len(old.constraints),'appended_exact_complement_constraints':len(rows),'signed_projection_variables':8185,'required_originals':66,'moving_originals':12,'fixed_originals':54,'same_sheet_pair_modes':538,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'performance_benefit_demonstrated':False,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
