"""Create a separate readback audit for the new terminal projected-model call."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];target=ROOT/'output/audit_h5_projected_expanded_search.py';assert not target.exists();s=(ROOT/'output/audit_h5_expanded_source_search.py').read_text()
for a,b in [('h5-expanded-source-search-20261026','h5-projected-expanded-search-20261026'),('h5-expanded-source-model-20261026','h5-projected-expanded-model-20261026'),('214901','223086'),('281731','289916')]:
    assert a in s;s=s.replace(a,b)
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print(target)
