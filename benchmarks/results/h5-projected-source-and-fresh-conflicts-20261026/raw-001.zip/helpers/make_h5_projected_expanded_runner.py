"""Create a new closed-once runner; preserve the earlier timed-out runner verbatim."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'output/run_h5_expanded_source_search.py';target=ROOT/'output/run_h5_projected_expanded_search.py';assert not target.exists();s=source.read_text()
changes={
    'h5-expanded-source-search-20261026':'h5-projected-expanded-search-20261026',
    'h5-expanded-source-model-20261026':'h5-projected-expanded-model-20261026',
    "checks['every_variable_and_constraint_independently_reconstructed'] and checks['one_sided_existential_projection_verified']":"checks['complete_parent_restored_exactly'] and checks['exact_two_way_parent_projection_verified']",
    '214901':'223086',
    '281731':'289916',
    'One new twelve-original source formulation releases three additional cogs, rebuilds all54-fixed domains and requires all66 originals. Independently audited223086 variables/289916 constraints, all538 full original pair modes, two exact area rules, fresh second-sheet capacity2,54 advisory hints.':'One distinct exact projection formulation replaces201575 shared-flag coordinate definitions with unary signed thresholds and8185 exactly defined integer projections. Independent two-way elimination restores the full12-mover parent. Independently audited223086 variables/289916 constraints, all538 full original pair modes, two exact area rules, fresh second-sheet capacity2,54 advisory hints.',
    'One distinct expanded12-mover/54-fixed full-original source model.':'One distinct exact signed-projection representation of the complete12-mover/54-fixed full-original source model; all parent source constraints and base variables retain their exact feasible projection.',
}
for old,new in changes.items():
    assert old in s,old
    s=s.replace(old,new)
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print(target)
