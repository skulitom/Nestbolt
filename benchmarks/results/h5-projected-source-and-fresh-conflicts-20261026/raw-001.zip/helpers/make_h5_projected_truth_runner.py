"""Create distinct once-only runner and readback for exact unary truth channels."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('run_h5_projected_expanded_search.py','run_h5_projected_truth_search.py'),('audit_h5_projected_expanded_search.py','audit_h5_projected_truth_search.py')]:
    dest=ROOT/'output'/target;assert not dest.exists();s=(ROOT/'output'/source).read_text()
    for a,b in [('h5-projected-expanded-search-20261026','h5-projected-truth-search-20261026'),('h5-projected-expanded-model-20261026','h5-projected-truth-model-20261026'),('289916','491491')]:assert a in s;s=s.replace(a,b)
    if source.startswith('run_'):
        old="checks['exact_two_way_parent_projection_verified']";assert old in s;s=s.replace(old,"checks['exact_two_way_placement_projection_verified'] and checks['monotone_auxiliary_completion_verified']")
        old='One distinct exact projection formulation replaces201575 shared-flag coordinate definitions with unary signed thresholds and8185 exactly defined integer projections. Independent two-way elimination restores the full12-mover parent.';assert old in s;s=s.replace(old,'One distinct exact truth-channel formulation appends201575 unary complements to the audited signed-projection parent. Every direction flag equals its exact threshold truth. Independently verified monotone auxiliary completion preserves the full feasible placement projection; dropping only complements restores the complete projected parent.')
        old='One distinct exact signed-projection representation of the complete12-mover/54-fixed full-original source model; all parent source constraints and base variables retain their exact feasible projection.';assert old in s;s=s.replace(old,'One distinct exact unary truth-channel representation of the complete12-mover/54-fixed full-original source model. All source clauses and physical placement choices retain exactly the same feasible projection; only auxiliary direction assignments become exact threshold truth.')
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    print(dest)
