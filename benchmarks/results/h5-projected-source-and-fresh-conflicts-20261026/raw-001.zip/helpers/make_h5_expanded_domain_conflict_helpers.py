"""Adapt the complete audited raw-core census to fresh54-fixed domains; no old bits reused."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('build_h5_original_domain_conflicts.py','build_h5_expanded_domain_conflicts.py'),('audit_h5_original_domain_conflicts.py','audit_h5_expanded_domain_conflicts.py')]:
    dest=ROOT/'output'/target;assert not dest.exists();s=(ROOT/'output'/source).read_text()
    changes=[('h5-full-original-joint-prepared-20261025','h5-expanded-cog-joint-prepared-20261026'),('h5-original-domain-conflicts-20261025','h5-expanded-domain-conflicts-20261026'),('h5-full-original-joint-20261025','h5-expanded-cog-neighborhood-20261026'),('len(uses)==36','len(uses)==66'),('==394','==538'),("'physical_part_pairs':36","'physical_part_pairs':66"),("'physical_query_pair_uses':394","'physical_query_pair_uses':538"),('the9 mandatory originals','the12 mandatory originals'),('their394 physical uses','their538 physical uses'),('164-case/394-use/36-physical-pair','164-case/538-use/66-physical-pair')]
    for old,new in changes:s=s.replace(old,new)
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    print(dest)
