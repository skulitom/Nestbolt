"""Use the existing exact grouping algorithm solely on the new conflict matrices."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('h5-convex-domain-conflicts-20261025/groups/prepare.py','prepare_h5_expanded_conflict_groups.py'),('h5-convex-domain-conflicts-20261025/groups/audit/audit.py','audit_h5_expanded_conflict_groups.py')]:
    dest=ROOT/'output'/target;assert not dest.exists();s=(ROOT/'output'/source).read_text();s=s.replace('h5-convex-domain-conflicts-20261025','h5-expanded-domain-conflicts-20261026').replace('all394 physical case uses','all538 physical case uses')
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    print(dest)
