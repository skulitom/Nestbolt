"""Exactly factor repeated signed coordinate projections in the full12 source model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-expanded-source-model-20261026';OUT=ROOT/'output/h5-projected-expanded-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def linear(terms,lo=-2**63,hi=2**63-1,en=()):
    t=Counter()
    for v,c in terms:t[v]+=c
    ids=sorted(v for v,c in t.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(t[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en);return p
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'audit/checks.json')['passed']
    paths=[PARENT/n for n in ['plan.json','model.pb','model.pbtxt','mapping.json','shared-directions.json','necessary-rules.json','advisory-hints.json','result.json','audit/plan.json','audit/checks.json','audit/projection-proof.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'For each same ordered physical pair and exact primitive normal, canonicalize the first nonzero coefficient to positive so opposite normals share one integer projection z=A*(xb-xa)+B*(yb-ya). Add its exact defining equality and full coordinate-domain extrema. Replace only each shared flag definition by flag=>z>=C for positive normal or flag=>z<=-C for its negative. Keep every existing variable, every other constraint and all54 advisory hints unchanged. No direction threshold or geometry approximation, source-plane removal, copy-order cut, old fixed57 exclusion or witness lock. Eliminating the new projection variables must recover the complete parent exactly; no solver call.'})
    parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model.pb').read_bytes());model=cp_model_pb2.CpModelProto();model.CopyFrom(parent);mapping=load(PARENT/'mapping.json');coords={p['part']:p for p in mapping['parts']};definitions=load(PARENT/'shared-directions.json');groups={};rows=[];replacements=[];before=0
    for r in definitions:
        sign=1 if r['a']>0 or r['a']==0 and r['b']>0 else -1;A,B=sign*r['a'],sign*r['b'];key=(*r['parts'],A,B);a,b=[coords[i] for i in r['parts']]
        if key not in groups:
            terms=[(b['x'],A),(a['x'],-A),(b['y'],B),(a['y'],-B)];lo=hi=0
            for v,c in terms:
                low,high=parent.variables[v].domain;lo+=c*(low if c>=0 else high);hi+=c*(high if c>=0 else low)
            assert -2**63<lo<=hi<2**63;var=len(model.variables);model.variables.add(name=f'projection-{len(groups)}',domain=[lo,hi]);ci=len(model.constraints);model.constraints.add().CopyFrom(linear([(var,1)]+[(v,-c) for v,c in terms],0,0));row={'parts':r['parts'],'a':A,'b':B,'variable':var,'domain':[lo,hi],'equality_constraint':ci,'direction_flags':[]};groups[key]=row;rows.append(row)
        group=groups[key];z=group['variable'];ci=r['constraint'];old=parent.constraints[ci];assert old==linear([(b['x'],r['a']),(a['x'],-r['a']),(b['y'],r['b']),(a['y'],-r['b'])],lo=r['bound'],en=[r['flag']]);before+=len(old.linear.vars)
        new=linear([(z,1)],lo=r['bound'],en=[r['flag']]) if sign==1 else linear([(z,1)],hi=-r['bound'],en=[r['flag']]);model.constraints[ci].CopyFrom(new);group['direction_flags'].append(r['flag']);replacements.append({'constraint':ci,'flag':r['flag'],'projection':z,'sign':sign,'original_bound':r['bound'],'new_bound':sign*r['bound'],'sense':'ge' if sign==1 else 'le'})
    for name in ['mapping.json','shared-directions.json','necessary-rules.json','advisory-hints.json']:shutil.copyfile(PARENT/name,OUT/name)
    write(OUT/'projections.json',rows);write(OUT/'replacements.json',replacements);after=len(definitions)+sum(len(model.constraints[r['equality_constraint']].linear.vars) for r in rows);(OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n')
    result={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':len(model.solution_hint.vars),'parent_variables':len(parent.variables),'parent_constraints':len(parent.constraints),'shared_direction_definitions_replaced':len(definitions),'signed_projection_variables':len(rows),'projection_equalities':len(rows),'old_definition_nonzero_terms':before,'new_definition_and_equality_nonzero_terms':after,'nonzero_terms_saved':before-after,'required_originals':66,'moving_originals':12,'fixed_originals':54,'same_sheet_pair_modes':538,'original_parent_fields_and_other_constraints_unchanged':True,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'performance_benefit_demonstrated':False,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
