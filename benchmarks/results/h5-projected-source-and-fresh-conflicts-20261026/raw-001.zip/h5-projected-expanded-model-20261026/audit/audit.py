"""Verify exact signed-projection factorization by eliminating every added variable."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
from collections import Counter
import json,time,shutil,traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-projected-expanded-model-20261026';PARENT=ROOT/'output/h5-expanded-source-model-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def lin(terms,lo=-2**63,hi=2**63-1,en=()):
    coefficients={v:sum(c for w,c in terms if w==v) for v,c in terms};ids=sorted(i for i in coefficients if coefficients[i]);c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(ids);c.linear.coeffs.extend(coefficients[i] for i in ids);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(en);return c
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Verify the complete parent against committed evidence. Independently canonicalize exact opposite normals by lexicographic ordering; enumerate all16 corners of each four-coordinate domain for exact projection extrema. Reconstruct each defining equality and every unary signed threshold, check all flags/metadata, eliminate the added projection variables to restore the entire parent proto, and verify actual solver import/export. No solver.'})
    manifest=load(ROOT/'benchmarks/results/h5-expanded-source-search-20261026/raw-manifest.json');known={r['sha256'] for r in manifest['files']+manifest['aliases']}
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h and h in known,n
    for n,h in load(PARENT/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    assert load(PARENT/'audit/checks.json')['every_variable_and_constraint_independently_reconstructed'];parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model.pb').read_bytes());child=cp_model_pb2.CpModelProto();child.ParseFromString((BASE/'model.pb').read_bytes());nv,nc=len(parent.variables),len(parent.constraints);assert (nv,nc)==(214901,281731)
    for name in ['mapping.json','shared-directions.json','necessary-rules.json','advisory-hints.json']:assert (BASE/name).read_bytes()==(PARENT/name).read_bytes()
    mapping=load(BASE/'mapping.json');parts=mapping['parts'];defs=load(PARENT/'shared-directions.json');projections=load(BASE/'projections.json');replacements=load(BASE/'replacements.json');expected_groups={};actual_groups={};expected_replacements=[];replacement_indices=set();old_terms=0;new_terms=0;sign_counts=Counter();max_lhs_bound=0
    for d in defs:
        normal=max((d['a'],d['b']),(-d['a'],-d['b']));A,B=normal;key=(*d['parts'],A,B);sign=1 if (d['a'],d['b'])==normal else -1;a,b=[parts[i] for i in d['parts']]
        if key not in expected_groups:
            i=len(expected_groups);r=projections[i];z=nv+i;ci=nc+i;assert r['parts']==d['parts'] and (r['a'],r['b'])==normal and r['variable']==z and r['equality_constraint']==ci
            vals=[]
            for xa,ya,xb,yb in product(*[list(parent.variables[v].domain) for v in [a['x'],a['y'],b['x'],b['y']]]):vals.append(A*(xb-xa)+B*(yb-ya))
            bounds=[min(vals),max(vals)];assert bounds==r['domain'];assert child.variables[z]==cp_model_pb2.IntegerVariableProto(name=f'projection-{i}',domain=bounds)
            eq=lin([(z,1),(b['x'],-A),(a['x'],A),(b['y'],-B),(a['y'],B)],0,0);assert child.constraints[ci]==eq and len(eq.enforcement_literal)==0;new_terms+=len(eq.linear.vars);absolute_sum=sum(max(abs(child.variables[v].domain[0]*c),abs(child.variables[v].domain[1]*c)) for v,c in zip(eq.linear.vars,eq.linear.coeffs));assert absolute_sum<2**63-1;max_lhs_bound=max(max_lhs_bound,absolute_sum)
            expected_groups[key]={'parts':d['parts'],'a':A,'b':B,'variable':z,'domain':bounds,'equality_constraint':ci,'direction_flags':[]};actual_groups[key]=r
        r=expected_groups[key];r['direction_flags'].append(d['flag']);z=r['variable'];idx=d['constraint'];assert idx not in replacement_indices;replacement_indices.add(idx);old=lin([(b['x'],d['a']),(a['x'],-d['a']),(b['y'],d['b']),(a['y'],-d['b'])],lo=d['bound'],en=[d['flag']]);assert parent.constraints[idx]==old
        expected=lin([(z,1)],lo=d['bound'],en=[d['flag']]) if sign>0 else lin([(z,1)],hi=-d['bound'],en=[d['flag']]);assert child.constraints[idx]==expected;old_terms+=len(old.linear.vars);new_terms+=1;sign_counts[sign]+=1;expected_replacements.append({'constraint':idx,'flag':d['flag'],'projection':z,'sign':sign,'original_bound':d['bound'],'new_bound':sign*d['bound'],'sense':'ge' if sign>0 else 'le'})
    assert list(expected_groups.values())==projections and expected_replacements==replacements and len(expected_groups)==8185 and len(replacements)==201575
    for i,c in enumerate(parent.constraints):
        if i not in replacement_indices:assert child.constraints[i]==c,i
    assert child.variables[:nv]==parent.variables and len(child.variables)==nv+len(projections) and len(child.constraints)==nc+len(projections)
    restored=cp_model_pb2.CpModelProto();restored.CopyFrom(child);del restored.variables[nv:];del restored.constraints[nc:]
    for i in replacement_indices:restored.constraints[i].CopyFrom(parent.constraints[i])
    assert restored==parent and child.solution_hint==parent.solution_hint and len(child.solution_hint.vars)==54 and all(v<nv for v in child.solution_hint.vars)
    # Exact elimination, including all signs and finite bounds, proves both directions.
    proof={'parent_to_child':'Keep every parent variable. For each added projection set its integer value to the exact signed difference form. Independent16-corner extrema show that value is always in the declared domain. The equality holds and every active old direction implies the corresponding unary lower/upper threshold. All other constraints and hints are byte-identical.','child_to_parent':'Each new equality fixes its projection exactly to the old coordinate form. Substitute that equality into each unary threshold; with the explicitly verified sign it becomes exactly the old shared-flag direction constraint. Remove only added variables/equalities. The restored complete proto equals the parent, including every other field.','scope':'Same existential projection onto all original214901 variables, source domains, 12 mandatory movers/54 fixed originals and full538 pair modes. No geometric relaxation, strengthening, copy symmetry or coordinate locks. Actual speed remains unproven.','original_direction_definitions':len(defs),'positive_sign_thresholds':sign_counts[1],'negative_sign_thresholds':sign_counts[-1],'signed_projection_groups':len(projections),'maximum_exact_linear_absolute_sum':max_lhs_bound};write(OUT/'equivalence-proof.json',proof)
    real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'solver-import-roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert actual==child;result=load(BASE/'result.json');assert result['old_definition_nonzero_terms']==old_terms and result['new_definition_and_equality_nonzero_terms']==new_terms and result['nonzero_terms_saved']==old_terms-new_terms and result['model_sha256']==digest(BASE/'model.pb')
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_parent_inputs_verified':len(load(BASE/'plan.json')['inputs']),'variables':len(child.variables),'constraints':len(child.constraints),'hints':54,'direction_definitions_replaced':len(replacements),'signed_projection_variables':len(projections),'projection_equalities':len(projections),'projection_corners_checked':16*len(projections),'old_definition_nonzero_terms':old_terms,'new_definition_and_equality_nonzero_terms':new_terms,'nonzero_terms_saved':old_terms-new_terms,'complete_parent_restored_exactly':True,'every_signed_threshold_and_projection_bound_verified':True,'exact_two_way_parent_projection_verified':True,'actual_solver_import_export_verified':True,'required_originals':66,'moving_originals':12,'fixed_originals':54,'same_sheet_pair_modes':538,'original_anchor_variables':24,'copy_symmetry_exclusions':0,'coordinate_locks':0,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'performance_benefit_demonstrated':False,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
