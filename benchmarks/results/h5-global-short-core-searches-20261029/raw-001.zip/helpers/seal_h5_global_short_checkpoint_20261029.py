"""Seal two closed global short-sheet studies and exact cog-strip preparation."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
GLOBAL=ROOT/'output/h5-global-short-core-20261029';BASE=ROOT/'output/h5-coarse-short-core-20261029';PRE=GLOBAL/'coarse-preflight';STRIP=BASE/'cog-strip-preflight';SYNC=ROOT/'output/h5-fixed9-main-sync-20261029';PUB=BASE/'publication';NAME='h5-global-short-core-searches-20261029';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='d3b652b6400057aab92bc47f8121e8a339a88d2d' and not git('diff','HEAD','--name-only')
responses=[]
for folder,unit,ncts in [(GLOBAL,1,1414),(BASE,100,1424)]:
    model=load(folder/'model-audit/checks.json');response=load(folder/'response-audit/checks.json');assert model['passed'] and model['variables_verified']==1438 and model['constraints_verified']==ncts
    assert response['passed'] and response['status']=='UNKNOWN' and response['closed_solver_calls']==1 and response['incumbents']==response['assignments']==response['source_checker_calls']==response['native_calls']==0
    assert response['algorithm_seconds']<60 and response['shared_seconds']<90 and not response['original_or_all_angle_feasibility_excluded'];responses.append({'anchor_unit_um':unit,**response})
assert load(PRE/'audit/checks.json')['passed'] and load(STRIP/'audit/checks.json')['passed']
assert load(GLOBAL/'response-audit/unexercised-source-reader-defect.json')['float_parse_failures_reproduced']==2 and load(BASE/'response-audit/reader-review.json')['corrected_center_expression_evaluated']
receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['normal_atomic_fast_forward'] and receipt['prior_main_all6_pass']
prior=load(ROOT/'benchmarks/results/h5-fixed-nine-triple-and-global-short-preflight-20261029/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
main=load(PUB/'main.json')['commit']['sha'];ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert main==head and ci['head_sha']==main and ci['status']=='in_progress' and len(jobs)==6
passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==4 and set(live)=={'checks (ubuntu-latest)','checks (windows-latest)'}
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    assert p.is_file() and '.claude' not in p.parts;members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [GLOBAL,BASE,SYNC]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['h5_global_short_core_values_20261029.py','build_h5_global_short_core_20261029.py','h5_global_short_core_reader_20261029.py','audit_h5_global_short_core_model_20261029.py','check_h5_global_short_core_candidate_20261029.py','run_h5_global_short_core_20261029.py','audit_h5_global_short_core_response_20261029.py','prepare_h5_coarse_short_core_preflight_20261029.py','audit_h5_coarse_short_core_preflight_20261029.py','prepare_h5_coarse_short_core_scripts_20261029.py','finish_h5_coarse_short_core_scripts_20261029.py','h5_coarse_short_core_values_20261029.py','build_h5_coarse_short_core_20261029.py','h5_coarse_short_core_reader_20261029.py','audit_h5_coarse_short_core_model_20261029.py','check_h5_coarse_short_core_candidate_20261029.py','run_h5_coarse_short_core_20261029.py','audit_h5_coarse_short_core_response_20261029.py','prepare_h5_cog_strip_capacity_20261029.py','audit_h5_cog_strip_capacity_20261029.py','push_h5_fixed9_checkpoint_20261029.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_global_short_archive_20261029.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert q.is_relative_to(ROOT) and '.claude' not in q.parts and '.cache' not in q.parts and digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(GLOBAL,'model/built.json','micrometre-model.json'),(GLOBAL,'model-audit/checks.json','micrometre-model-audit.json'),(GLOBAL,'response-audit/checks.json','micrometre-response-audit.json'),(GLOBAL,'response-audit/unexercised-source-reader-defect.json','unused-reader-defect.json'),(PRE,'source-mapping-proof.json','coarse-source-mapping-proof.json'),(PRE,'audit/checks.json','coarse-preflight-audit.json'),(BASE,'model/built.json','coarse-model.json'),(BASE,'model-audit/checks.json','coarse-model-audit.json'),(BASE,'response-audit/checks.json','coarse-response-audit.json'),(BASE,'response-audit/reader-review.json','coarse-reader-review.json'),(STRIP,'geometry.json','cog-strip-geometry.json'),(STRIP,'necessity-proof.json','cog-strip-necessity-proof.json'),(STRIP,'audit/checks.json','cog-strip-audit.json'),(SYNC,'receipt.json','prior-main-push-receipt.json')]
for folder,a,b in copies:shutil.copyfile(folder/a,OUT/b)
shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json');write(OUT/'search-summary.json',responses)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40795603963,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'next-step.json',{'action':'Use the independently audited16 interior rectangles per cog to strengthen whole-sheet propagation. Derive and independently verify one common bounding box containing every possible model rectangle, including expanded stock and100um anchor rounding, before choosing cumulative capacity constants. Build a distinct model retaining every existing exact cog facet, all13 mandatory identities, all26 movable anchor coordinates and all10 copy orders. Add the32 cog strips to the global NoOverlap2D and, only with proved domains, redundant cumulative constraints. Audit every added interval, link, owner and capacity against the positive/negative controls before declaring any new bounded call. Earlier calls stay closed. Any relaxation solution still needs original source13, first53 and combined66 validation before native checks.','strip_geometry_prepared_and_audited':True,'capacity_constants_prepared':False,'new_CP_model_created':False,'new_search_opened':False,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'independently_audited_models':2,'closed_solver_calls':2,'statuses':['UNKNOWN','UNKNOWN'],'incumbents':0,'assignments':0,'source_checker_calls':0,'native_calls':0,'algorithm_and_shared_budgets_respected':True,'allocated_solve_overruns_preserved':True,'coarse_rounding_map_and_copy_orders_verified':True,'old_unused_reader_defect_preserved':True,'new_reader_expression_corrected_but_pipeline_unexercised':True,'next_cog_strips_per_original':16,'next_global_piece_count':48,'next_strip_corner_edge_checks':2048,'next_capacity_constants_not_yet_prepared':True,'new_source_valid13':False,'new_source_valid66':False,'full_allocation_or_original_job_excluded':False,'valid64_preserved':True,'remaining_necessary_allocations':444,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
