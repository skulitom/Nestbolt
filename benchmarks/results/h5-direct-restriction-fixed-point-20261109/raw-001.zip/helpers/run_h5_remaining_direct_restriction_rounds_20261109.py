"""Administrative once-only loop driver, observing the already completed round00."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-restriction-loop-20261109';OUT=ROOT/'output/h5-direct-restriction-all-rounds-20261109';OUT.mkdir();began=time.perf_counter()
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
plan=load(BASE/'plan.json');write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_rounds':plan['maximum_rounds'],'round00_already_closed':True,'sequential_only':True,'retry_permitted':False});rounds=[]
for index in range(plan['maximum_rounds']):
    if index:assert not rounds[-1]['joint_fixed_point'] and not rounds[-1]['all_scopes_excluded']
    for audit in [False,True]:
        suffix='-audit' if audit else '';folder=ROOT/f'output/h5-direct-restriction-round-{index:02d}{suffix}-process-20261109'
        if index==0:assert folder.exists()
        else:
            assert not folder.exists();wrapper=ROOT/f'output/run_h5_direct_restriction_round_{index:02d}{"_audit" if audit else ""}_stage_20261109.py'
            r=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(wrapper)],cwd=ROOT,capture_output=True,timeout=75)
            (OUT/f'round-{index:02d}{suffix}-stdout.txt').write_bytes(r.stdout);(OUT/f'round-{index:02d}{suffix}-stderr.txt').write_bytes(r.stderr);assert r.returncode==0,(index,audit,r.stderr.decode(errors='replace'))
        process=load(folder/'process.json');assert process['passed'] and process['closed'] and process['job']['active_processes']==0
    check=load(BASE/f'round-{index:02d}/audit/checks.json');assert check['passed'];rounds.append(check);write(OUT/f'round-{index:02d}-closed.json',check);print({'closed_round':index,'removed':check['conditional_seed_exclusions']+check['clique_exclusions'],'remaining_nodes':check['remaining_nodes'],'joint_fixed_point':check['joint_fixed_point']},flush=True)
    if check['joint_fixed_point'] or check['all_scopes_excluded']:break
last=rounds[-1];result={'passed':True,'closed_rounds':len(rounds),'final_round_index':last['round_index'],'joint_fixed_point':last['joint_fixed_point'],'all_scopes_excluded':last['all_scopes_excluded'],'declared_cap_reached':not(last['joint_fixed_point'] or last['all_scopes_excluded']),'remaining_nodes':last['remaining_nodes'],'total_new_conditional_seeds':sum(r['conditional_seed_exclusions'] for r in rounds),'total_new_clique_exclusions':sum(r['clique_exclusions'] for r in rounds),'complete_preparation_seconds_before_final_geometry':last['complete_preparation_seconds_if_consumed'],'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False}
write(OUT/'round-summary.json',rounds);write(OUT/'checks.json',result);print(result,flush=True)
