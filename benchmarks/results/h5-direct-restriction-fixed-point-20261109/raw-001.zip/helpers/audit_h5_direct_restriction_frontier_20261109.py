"""Independent round-chain, source geometry and final preparation verification."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_horizontal_segment_areas_20261109 import horizontal_segment_areas
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-direct-restriction-frontier-20261109';OUT=SOURCE/'audit';LOOP=ROOT/'output/h5-direct-restriction-loop-20261109';DIRECT=ROOT/'output/h5-direct-overlay-reference-20261109';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109';GEOM=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108';COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108';PARENT=ROOT/'benchmarks/results/h5-direct-overlay-capacity-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process_path=ROOT/'output/h5-direct-restriction-frontier-process-20261109/process.json';process=load(process_path);assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();plan=load(SOURCE/'plan.json');last=plan['final_round_index'];bindings={};seen=set()
def verify(values):
    for name,h in values.items():
        if name not in seen:assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name;seen.add(name)
        if name in bindings:assert bindings[name]==h,name
        bindings[name]=h
verify(plan['inputs']);verify(load(PRE/'audit/plan.json')['inputs'])
for i in range(last+1):
    folder=LOOP/f'round-{i:02d}';check=load(folder/'audit/checks.json');assert check['passed'] and check['complete_direct_queries']==8551 and check['conditional_area_bounds']==25653 and check['possible_node_records']==87484 and check['original_physical_records']==151597
    verify(load(folder/'audit/plan.json')['inputs'])
    if i<last:assert not check['joint_fixed_point'] and not check['all_scopes_excluded']
geometry=load(GEOM/'geometries.json');stock=load(GEOM/'stock-cover.json')['outward_stock_rectangle_um'];results=[];sweeps=0
for case,summary in zip([1,9],load(SOURCE/'case-results.json')):
    data=load(PRE/f'choice-{case:02d}.json');graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');initial=load(PARENT/f'choice-{case:02d}-frontier.json')['remaining_current_positions'];current=initial;seed_count=clique_count=0
    for i in range(last+1):
        front=load(LOOP/f'round-{i:02d}/choice-{case:02d}-frontier.json');assert front['input_active_positions']==current and set(front['remaining_current_positions'])<=set(current)
        seed_count+=front['conditional_seed_exclusions'];clique_count+=front['clique_exclusions'];current=front['remaining_current_positions']
    saved=load(SOURCE/f'choice-{case:02d}-frontier.json');assert saved['input_active_positions']==initial and saved['remaining_current_positions']==current and len(initial)-len(current)==seed_count+clique_count
    mask=sum(1<<p for p in current);path=COVER/f'choice-{case:02d}-covers.json';covers=load(path);bindings[path.relative_to(ROOT).as_posix()]=sha256(path.read_bytes()).hexdigest();regions=[set(),set()]
    for p in current:
        node=nodes[p]
        for box in covers[p]['remaining_closed_anchor_boxes_um']:
            for component in geometry[node['geometry']]['all_alias_component_outer_rectangles_um']:
                rectangle=(max(stock[0],box[0]+component[0]),max(stock[1],box[1]+component[1]),min(stock[2],box[2]+component[2]),min(stock[3],box[3]+component[3]))
                if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:regions[node['family']].add(rectangle)
                sweeps+=1
    regions=[sorted(group) for group in regions];assert saved['family_component_regions_um']==[[list(r) for r in family] for family in regions]
    areas=horizontal_segment_areas(*regions,data['fixed_forbidden_clearance_regions_um']);cliques=load(DIRECT/f'choice-{case:02d}-queries.json')['root_clique_masks_hex'];counts=[sum((int(group,16)&mask)>0 for group in family) for family in cliques];required=[319992000000,158392000000,478384000000];fails=[f for f in range(3) if areas[f]<required[f]]
    expected={'refinement_index':case,'empty_sites':data['empty_sites'],'input_nodes':len(initial),'remaining_nodes':len(current),'remaining_nodes_by_family':[sum(nodes[p]['family']==f for p in current) for f in [0,1]],'new_conditional_seeds':seed_count,'new_clique_exclusions':clique_count,'global_clique_upper_counts':counts,'family_and_joint_area_upper_um2':areas,'required_global_area_um2':required,'failing_area_indices':fails,'scope_excluded':bool(fails) or any(n<8 for n in counts),'conditional_clique_fixed_point':front['fixed_point']}
    assert expected==summary;results.append(expected)
cost=load(PARENT/'checks.json')['complete_preparation_seconds_if_consumed'];processes=load(SOURCE/'process-summary.json');assert len(processes)==2+2*(last+1)
for row in processes:
    path=ROOT/'output'/(row['stage']+'-process-20261109')/'process.json';p=load(path);assert p['passed'] and p['closed'] and p['job']['active_processes']==0 and p['complete_seconds']==row['complete_seconds'];charged=not row['stage'].endswith('-audit');assert row['charged']==charged
    if charged:cost+=p['complete_seconds']
assert abs(cost-plan['complete_preparation_seconds_before_this_stage'])<1e-8;cost+=process['complete_seconds']
for p in [Path(__file__),ROOT/'output/h5_horizontal_segment_areas_20261109.py',GEOM/'geometries.json',GEOM/'stock-cover.json',process_path,process_path.parent/'opened.json']+list(SOURCE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Pin complete independent audits for every declared round; independently reconcile original-position masks, every seed/count total and complete preparation. Reconstruct every final source/alias component sweep from closed anchor covers and verify all six global union areas by horizontal interval-tree sums.'})
write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',[r for r in results if not r['scope_excluded']])
checks={'passed':True,'complete_rounds':last+1,'complete_query_evaluations':8551*(last+1),'conditional_area_bounds_verified':25653*(last+1),'possible_node_records_verified':87484*(last+1),'original_physical_records_verified':151597*(last+1),'joint_conditional_clique_fixed_point':all(r['conditional_clique_fixed_point'] for r in results),'new_conditional_seeds':sum(r['new_conditional_seeds'] for r in results),'new_clique_exclusions':sum(r['new_clique_exclusions'] for r in results),'remaining_nodes':sum(r['remaining_nodes'] for r in results),'remaining_fixed29_cases':sum(not r['scope_excluded'] for r in results),'retained_source_component_sweeps':sweeps,'exact_global_area_bounds_verified':6,'complete_preparation_seconds_if_consumed':cost,'seconds':time.perf_counter()-began,'common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks);print(results)
