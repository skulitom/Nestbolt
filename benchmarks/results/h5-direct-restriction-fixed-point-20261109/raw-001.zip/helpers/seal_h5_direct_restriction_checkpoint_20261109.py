"""Seal two complete audited restriction rounds and the exact final frontier."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
original=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=original[:original.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-direct-restriction-fixed-point-20261109'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-direct-restriction-loop-20261109';F=ROOT/'output/h5-direct-restriction-frontier-20261109/audit';D=F.parent",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-direct-overlay-capacity-20261109'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['complete_rounds']==2 and front['joint_conditional_clique_fixed_point'] and front['new_conditional_seeds']==7 and front['remaining_nodes']==8343",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-direct-restriction-all-rounds-20261109',ROOT/'output/h5-direct-overlay-capacity-main-sync-20261109']+[ROOT/'output'/(r['stage']+'-process-20261109') for r in load(D/'process-summary.json')]+[ROOT/'output'/('h5-direct-restriction-frontier'+suffix+'-process-20261109') for suffix in ['', '-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*direct_restriction*20261109.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_direct_restriction_checkpoint_20261109.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"load(F/'source-bindings.json').items()":"load(F/'plan.json')['inputs'].items()",
}
for before,after in changes.items():assert before in prefix,before;prefix=prefix.replace(before,after)
exec(prefix)
processes=load(D/'process-summary.json')
for suffix in ['', '-audit']:
    label='h5-direct-restriction-frontier'+suffix;p=load(ROOT/'output'/(label+'-process-20261109')/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
    processes.append({'stage':label,'passed':True,'closed':True,'active_processes':0,'complete_seconds':p['complete_seconds'],'charged':suffix==''})
inherited=load(PARENT/'process-summary.json')+load(PARENT/'inherited-process-summary.json');assert len(processes)==8 and len(inherited)==738 and all(p['closed'] and p['active_processes']==0 for p in inherited)
write(OUT/'process-summary.json',processes);write(OUT/'inherited-process-summary.json',inherited)
copies=[(F/'checks.json','frontier-audit.json'),(F/'case-results.json','case-results.json'),(F/'remaining-cases.json','remaining-cases.json'),(BASE/'plan.json','complete-loop-plan.json'),(BASE/'preflight-audit/checks.json','baseline-preflight-audit.json'),(ROOT/'output/h5-direct-restriction-all-rounds-20261109/checks.json','loop-closure.json'),(ROOT/'output/h5-direct-restriction-all-rounds-20261109/round-summary.json','complete-round-summary.json'),(ROOT/'output/h5-direct-overlay-capacity-main-sync-20261109/receipt.json','prior-main-push-receipt.json')]
for i in [0,1]:copies.extend([(BASE/f'round-{i:02d}/audit/checks.json',f'round-{i:02d}-complete-audit.json'),(BASE/f'round-{i:02d}/audit/case-results.json',f'round-{i:02d}-cases.json')])
for case in [1,9]:copies.extend([(D/f'choice-{case:02d}-frontier.json',f'choice-{case:02d}-frontier.json'),(BASE/f'round-01/choice-{case:02d}-queries.json',f'choice-{case:02d}-all-final-queries.json')])
for source,name in copies:shutil.copyfile(source,OUT/name)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42553859232','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='e14101852a180aaa76a1e03e6d019a0b34c7522c';write(OUT/'main-ci-at-review.json',ci)
cost=front['complete_preparation_seconds_if_consumed'];cases=load(F/'case-results.json')
write(OUT/'checks.json',{**front,**archive,'passed':True,'new_processes_closed':8,'inherited_processes_closed':738,'all746_processes_closed':True,'completion_percent':60,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'unused_declared_rounds':6})
proposal='The complete direct-reference conditional and root-clique rules now have a genuine fixed point under the existing14306-edge overlay. Do not repeat them on unchanged inputs. Assess a fresh finite pair-capacity scope using the complete direct-query rows and audited8343-mask signatures. The old206356-pair pilot used6650representative/direct queries before the overlay and latest reductions; it is not the same numerical input. Freeze an explicit balanced anchor/complete-partner scope before evaluating any new pair, preserve old pair proofs, and independently verify every current target and positive physical cover. Keep original physical keys and all151597records. New pair deficits can add only certified incompatibility edges; independently distinguish old edges and verify complete implications before claiming any exclusion. No new pair plan, transpose or numeric pair call is prepared. All preparation remains charged; no optimizer or timed H5 acceptance from this lineage.'
write(OUT/'next-step.json',{'status':'direct_conditional_clique_fixed_point_at8343nodes_both_cases_open','proposal':proposal,'new_pair_stage_prepared':False,'authoritative_current_masks':'output/h5-direct-restriction-frontier-20261109/choice-{01,09}-frontier.json remaining_current_positions','current_direct_signatures':'output/h5-direct-restriction-loop-20261109/round-01/choice-{01,09}-signatures.json','current_direct_areas':'output/h5-direct-restriction-loop-20261109/round-01/choice-{01,09}-queries.json','consumed_preparation_seconds':cost,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'whole_allocations_remaining':440,'H5_complete':False})
table='\n'.join(f"| {r['empty_sites']} | {r['new_conditional_seeds']} | {r['remaining_nodes']} | {r['remaining_nodes_by_family'][0]} / {r['remaining_nodes_by_family'][1]} | {r['family_and_joint_area_upper_um2'][2]/1e6:,.6f} |" for r in cases)
passed=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
report=f'''# Complete direct restriction fixed point — 2026-11-09

**Two complete audited rounds exclude seven more bracket cells, then reach a fixed point.**
Both fixed29 arrangements remain open with **8,343 cells**. H2/H5 remain open
at **60% completed milestone weight**.

## Complete bounded restriction

The [preceding direct proof](h5-direct-overlay-capacity-20261109.md) removed 201
cells. [The new loop plan]({NAME}/complete-loop-plan.json) retains all 8,551
original direct-query identities and each family's companion-area requirement,
starting from the proved 8,350-cell mask. The original graph plus 14,306
certified pair edges remains fixed. A maximum of eight rounds and eight
simultaneous clique passes per round is declared before execution.

Each original possible-node set P is intersected with the current mask.
Its previous query signature is carried only when that intersection is
exactly unchanged; otherwise it is reprojected. The producer subtracts exact
newly uncovered family/joint areas from the preceding complete vectors.
The independent auditor uses allowed-node unions and recomputes every full
positive physical-area vector by integer weight planes. It also verifies
every current direct seed and every candidate in every clique pass.

[Round00]({NAME}/round-00-complete-audit.json) excludes seven bracket cells in
case09. [Round01]({NAME}/round-01-complete-audit.json) tightens 2,447 further
signatures and finds no new seed or clique implication. Across both rounds,
all **51,306 bounds**, **17,102 query evaluations**, **174,968 possible-node
records** and **303,194 original physical records** independently match.
Inactive reference queries remain checked but cannot remove another target.

[The loop closes]({NAME}/loop-closure.json) at the genuine fixed point after
two rounds; the other six permitted rounds never open. This fixed point
applies to the declared conditional and root-clique rules, not every possible
capacity proof.

## Exact final geometry and scope

The [final source audit]({NAME}/frontier-audit.json) reconciles the full round
chain and reconstructs all 21,146 retained source/alias component sweeps from
original closed anchor covers. Independent horizontal interval-tree areas
exactly reproduce all six global vertical union bounds.

| Omitted sites | New cells excluded | Remaining cells | Brackets / inserts | Global joint upper (mm²) |
|---|---:|---:|---:|---:|
{table}

Both joint bounds remain above the required 478,384 mm². The 453/455 earlier
whole-choice exclusions stand, including 428 at zero clearance. Common-line
occupied outer envelopes reserve holes, with all 90 cutting holes preserved.
No ordinary part-in-hole or whole-allocation exclusion follows.

## Process closure and next work

[All eight new numerical processes]({NAME}/process-summary.json) pass and close
with zero descendants; [738 inherited processes]({NAME}/inherited-process-summary.json)
remain terminal, including four preserved failures. Workers retain CCD1
logical processors 16–31, one BLAS/OMP/MKL thread and 2 GiB Windows Job caps.
Plan and final-geometry stages use 30 s; complete round producers and auditors
use 60 s each. Consumed preparation is **{cost:.6f} s**. No optimizer, timer
reset or timed H5 pass follows.

[Next]({NAME}/next-step.json), assess a fresh finite pair-capacity scope using
the complete direct rows and the new fixed-point masks. The preceding pair
pilot used a different representative-query graph before the new overlay and
reductions. Any new pair scope must be frozen and fully audited, with existing
edges distinguished from new proofs. No new pair plan or call is prepared.

All 440 whole-job allocations, full66 source/native/material checks,
production integration and the H5 matrix remain open. Valid64 stays best;
eight older first32 and 680 five-column cores remain closed. Product, README
and releases are unchanged.

[The pair and direct-capacity checkpoints reached main `e1410185`]({NAME}/prior-main-push-receipt.json)
after all six prior checks passed, preserving 52 files. [Fresh CI at review]({NAME}/main-ci-at-review.json)
has {passed} passed / {live} live jobs. This checkpoint awaits ordinary push.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the complete chain.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-09 H5 complete direct restriction fixed point:** [two complete rounds and exact source-frontier audit]({{link}}) verify 51,306 bounds, 17,102 query evaluations, 174,968 possible-node records and 303,194 physical records. Round00 excludes seven bracket cells; round01 finds no further seed or clique implication and the loop stops, leaving 8,343 cells in both open choices. All 21,146 retained source-component sweeps and six exact global union areas replay. The other six permitted rounds never open. All eight new and 738 inherited processes are terminal, preserving inherited failures. Consumed preparation {cost:.6f} s cannot reset or open an optimizer. Next assess a fresh finite pair-capacity scope on the complete direct graph; none is prepared. All 440 allocations/full66/H5 remain open, valid64 stays best, H2/H5 remain at 60%, common-line holes stay reserved, and product/README/releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8');start=content.index('Latest H5 evidence:');end=content.index('\nThe earlier fixed 13-cog construction',start)
intro=f'''Latest H5 evidence: [complete direct restriction fixed point](../benchmarks/results/{NAME}.md).
Two complete independently audited rounds verify all 51,306 conditional bounds.
The first excludes seven bracket cells; the second finds no further seed or
clique implication. The loop reaches a genuine fixed point with 8,343 cells
across both open choices, and the other six declared rounds never open.
All 21,146 original source/alias component sweeps and six global union areas
replay. Neither arrangement is excluded. The 453/455 prior exclusions stand,
including 428 at zero clearance. Common-line holes remain reserved; no ordinary
part-in-hole or whole-allocation exclusion is claimed. All eight new and 738
inherited processes are terminal, with four inherited failures preserved.
Consumed preparation is {cost:.6f} s; no optimizer or timer reset is permitted.
Next assess a fresh finite pair-capacity scope on the complete direct graph;
none is prepared. All 440 allocations/full66/H5 remain open, valid64 stays best,
and H2/H5 remain at 60%. Eight older first32 and 680 five-column cores stay
closed. Product, README and releases are unchanged. The pair and direct-capacity
checkpoints reached main e1410185 after all six prior checks passed, preserving
52 files. Fresh CI has {passed} passed/{live} live jobs at review; this checkpoint
awaits ordinary push.
'''
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(content[:start]+intro+content[end:])
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text\n')
print({'passed':True,'archive':archive,'source_bindings':len(bindings),'historical_references':len(external),'new_cell_exclusions':7,'remaining_cells':8343,'complete_preparation_seconds':cost})
