"""Reconcile every closed loop round and recompute final full-domain areas."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_exact_rectangle_areas_20261108 import vertical_areas
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-restriction-loop-20261109';DIRECT=ROOT/'output/h5-direct-overlay-reference-20261109';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109';PARENT=ROOT/'benchmarks/results/h5-direct-overlay-capacity-20261109';ADMIN=ROOT/'output/h5-direct-restriction-all-rounds-20261109';OUT=ROOT/'output/h5-direct-restriction-frontier-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
complete=load(ADMIN/'checks.json');assert complete['passed'];last=complete['final_round_index'];assert 0<=last<load(BASE/'plan.json')['maximum_rounds']
OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),ROOT/'output/h5_exact_rectangle_areas_20261108.py',BASE/'plan.json',BASE/'preflight-audit/plan.json',BASE/'preflight-audit/checks.json',ADMIN/'checks.json',ADMIN/'round-summary.json',PRE/'audit/plan.json',PRE/'audit/checks.json'];processes=[];cost=load(PARENT/'checks.json')['complete_preparation_seconds_if_consumed']
for label,charge in [('h5-direct-restriction-plan',True),('h5-direct-restriction-plan-audit',False)]+[(f'h5-direct-restriction-round-{i:02d}'+suffix,suffix=='') for i in range(last+1) for suffix in ['', '-audit']]:
    folder=ROOT/'output'/(label+'-process-20261109');p=load(folder/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
    if charge:cost+=p['complete_seconds']
    processes.append({'stage':label,'passed':True,'closed':True,'active_processes':0,'complete_seconds':p['complete_seconds'],'charged':charge});inputs.extend([folder/'process.json',folder/'opened.json'])
assert abs(cost-complete['complete_preparation_seconds_before_final_geometry'])<1e-8
for i in range(last+1):
    folder=BASE/f'round-{i:02d}';assert load(folder/'audit/checks.json')['passed'];inputs.extend([folder/'audit/plan.json',folder/'audit/checks.json',folder/'audit/case-results.json'])
    if i<last:assert not load(folder/'audit/checks.json')['joint_fixed_point'] and not load(folder/'audit/checks.json')['all_scopes_excluded']
results=[]
for case in [1,9]:
    current=load(BASE/f'round-{last:02d}/choice-{case:02d}-frontier.json');retained=current['remaining_current_positions'];initial=load(PARENT/f'choice-{case:02d}-frontier.json')['remaining_current_positions'];data=load(PRE/f'choice-{case:02d}.json');graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');mask=sum(1<<p for p in retained);regions=[set(),set()]
    for r in data['node_regions']:
        if mask&(1<<r['current_position']):regions[r['family']].update(map(tuple,r['regions_um']))
    regions=[sorted(group) for group in regions];areas=vertical_areas(*regions,data['fixed_forbidden_clearance_regions_um']);groups=load(DIRECT/f'choice-{case:02d}-queries.json')['root_clique_masks_hex'];counts=[sum(bool(int(group,16)&mask) for group in family) for family in groups];required=[319992000000,158392000000,478384000000];fails=[f for f in range(3) if areas[f]<required[f]]
    histories=[load(BASE/f'round-{i:02d}/choice-{case:02d}-frontier.json') for i in range(last+1)]
    for i,front in enumerate(histories):assert front['input_active_positions']==(initial if i==0 else histories[i-1]['remaining_current_positions'])
    seeds=sum(r['conditional_seed_exclusions'] for r in histories);clique=sum(r['clique_exclusions'] for r in histories);assert len(initial)-len(retained)==seeds+clique
    summary={'refinement_index':case,'empty_sites':data['empty_sites'],'input_nodes':len(initial),'remaining_nodes':len(retained),'remaining_nodes_by_family':[sum(nodes[p]['family']==f for p in retained) for f in [0,1]],'new_conditional_seeds':seeds,'new_clique_exclusions':clique,'global_clique_upper_counts':counts,'family_and_joint_area_upper_um2':areas,'required_global_area_um2':required,'failing_area_indices':fails,'scope_excluded':bool(fails) or any(n<8 for n in counts),'conditional_clique_fixed_point':current['fixed_point']}
    write(OUT/f'choice-{case:02d}-frontier.json',{**summary,'input_active_positions':initial,'remaining_current_positions':retained,'family_component_regions_um':[[list(r) for r in family] for family in regions]});results.append(summary)
    inputs.extend([PARENT/f'choice-{case:02d}-frontier.json',DIRECT/f'choice-{case:02d}-queries.json',PRE/f'choice-{case:02d}.json',graph/'nodes.json']+[BASE/f'round-{i:02d}/choice-{case:02d}-frontier.json' for i in range(last+1)])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'final_round_index':last,'complete_preparation_seconds_before_this_stage':cost,'method':'Reconcile every complete audited round and all original-position masks; require changed masks before any dependent round. Recompute final global source-envelope areas for both scopes. No further optimizer or graph search.'})
write(OUT/'process-summary.json',processes);write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'closed_rounds':last+1,'joint_fixed_point':complete['joint_fixed_point'],'total_new_conditional_seeds':sum(r['new_conditional_seeds'] for r in results),'total_new_clique_exclusions':sum(r['new_clique_exclusions'] for r in results),'remaining_nodes':sum(r['remaining_nodes'] for r in results),'seconds':time.perf_counter()-began,'independent_audit_pending':True,'optimizer_calls':0});print(results)
