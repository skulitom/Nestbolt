"""Complete independent positive-area and graph replay for each restriction round."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_block_projected_coverage_atoms_20261109 import allowed_projection
from h5_pair_capacity_bitsets_20261109 import physical_columns,weight_planes,weighted_area
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-restriction-loop-20261109';DIRECT=ROOT/'output/h5-direct-overlay-reference-20261109';PARENT=ROOT/'benchmarks/results/h5-direct-overlay-capacity-20261109';iteration=int(sys.argv[1]);SOURCE=BASE/f'round-{iteration:02d}';OUT=SOURCE/'audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process_path=ROOT/f'output/h5-direct-restriction-round-{iteration:02d}-process-20261109/process.json';process=load(process_path);assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();bindings={};seen=set()
def verify(values):
    for name,h in values.items():
        if name not in seen:assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name;seen.add(name)
        if name in bindings:assert bindings[name]==h,name
        bindings[name]=h
verify(load(SOURCE/'plan.json')['inputs']);verify(load(BASE/'preflight-audit/plan.json')['inputs']);verify(load(ROOT/'output/h5-direct-overlay-controls-20261109/source-bindings.json'))
plan=load(BASE/'plan.json');summaries=load(SOURCE/'case-results.json');results=[];record_count=physical_count=query_count=0
if iteration:
    previous=BASE/f'round-{iteration-1:02d}';assert load(previous/'audit/checks.json')['passed'];verify(load(previous/'audit/plan.json')['inputs'])
for case,summary in zip([1,9],summaries):
    data=load(DIRECT/f'choice-{case:02d}-queries.json');saved=load(SOURCE/f'choice-{case:02d}-frontier.json');qcount=len(data['query_positions']);full=(1<<qcount)-1
    if iteration==0:
        prior=data['active_current_positions'];active=load(PARENT/f'choice-{case:02d}-frontier.json')['remaining_current_positions'];old_signatures=load(DIRECT/f'choice-{case:02d}-capacity/projected-signatures.json')
    else:
        prior_front=load(previous/f'choice-{case:02d}-frontier.json');prior=prior_front['input_active_positions'];active=prior_front['remaining_current_positions'];old_signatures=load(previous/f'choice-{case:02d}-signatures.json')
    assert saved['input_active_positions']==active
    prior_mask=sum(1<<p for p in prior);mask=sum(1<<p for p in active);assert mask&~prior_mask==0;removed=prior_mask^mask
    project=allowed_projection(data);current_signatures=load(SOURCE/f'choice-{case:02d}-signatures.json');maps=[{},{}];changed=[0,0];reprojected=[0,0]
    for family in [0,1]:
        records=load(DIRECT/f'choice-{case:02d}-family-{family}-possible-nodes.json');assert len(records)==len(current_signatures[family])==len(old_signatures[family])
        for (key,possible,_),old_row,new_row in zip(records,old_signatures[family],current_signatures[family]):
            assert old_row[0]==key;possible=int(possible,16);old=int(old_row[1],16)
            if possible&removed:current=project(possible&mask)[family];reprojected[family]+=1
            else:current=old
            assert old&~current==0 and new_row==[key,hex(current)];maps[family][int(key,16)]=(old,current);changed[family]+=old!=current;record_count+=1
    physical_masks=[[],[]];weights=[];updates=0
    for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
        if piece['refinement_index']!=case:continue
        for b,i,weight in load(ROOT/piece['folder']/'atoms.json'):
            b0,b1=maps[0][int(b,16)];i0,i1=maps[1][int(i,16)];physical_masks[0].append(full-b1);physical_masks[1].append(full-i1);weights.append(weight)
            updates+=(b1-b0).bit_count()+(i1-i0).bit_count()+((b1&i1)-(b0&i0)).bit_count();physical_count+=1
    columns=[physical_columns(rows,qcount) for rows in physical_masks];planes=weight_planes(weights);rows=load(SOURCE/f'choice-{case:02d}-queries.json');assert len(rows)==qcount;active_set=set(active);seeds=[]
    for qi,row in enumerate(rows):
        position=data['query_positions'][qi];family=data['query_families'][qi];values=[weighted_area(v,planes) for v in [columns[0][qi],columns[1][qi],columns[0][qi]|columns[1][qi]]];required=data['required_by_reference_family_um2'][family];fails=[f for f in range(3) if values[f]<required[f]];excluded=bool(fails) and position in active_set
        assert row=={'query_index':qi,'current_position':position,'family':family,'family_and_joint_area_upper_um2':values,'required_area_um2':required,'failing_area_indices':fails,'current_cell_excluded':excluded}
        if excluded:seeds.append(position)
        query_count+=1
    assert saved['conditional_removed_positions']==seeds
    graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8;overlay=[0]*len(nodes)
    for edge in load(ROOT/f'benchmarks/results/h5-pair-capacity-conflicts-20261109/choice-{case:02d}-new-edges.json'):
        a,b=edge['left_current_position'],edge['right_current_position'];overlay[a]|=1<<b;overlay[b]|=1<<a
    cliques=[[int(v,16) for v in family] for family in data['root_clique_masks_hex']];current=mask&~sum(1<<p for p in seeds);rounds=saved['clique_rounds'];assert 1<=len(rounds)<=plan['maximum_clique_passes_per_round']
    for step,round_saved in enumerate(rounds):
        rejected=[]
        for p in active:
            if not current&(1<<p):continue
            forbidden=int.from_bytes(raw[p*width:(p+1)*width],'little')|overlay[p]|(1<<p);allowed=current&~forbidden;upper=[sum((group&allowed)>0 for group in family) for family in cliques];required=[7 if nodes[p]['family']==f else 8 for f in [0,1]]
            if upper[0]<required[0] or upper[1]<required[1]:rejected.append({'current_position':p,'upper':upper,'required':required})
        assert round_saved=={'pass_index':step,'removed':rejected}
        if not rejected:assert step==len(rounds)-1
        current&=~sum(1<<r['current_position'] for r in rejected)
    retained=[p for p in active if current&(1<<p)];assert retained==saved['remaining_current_positions'];counts=[sum((group&current)>0 for group in family) for family in cliques]
    expected={'refinement_index':case,'input_nodes':len(active),'remaining_nodes':len(retained),'complete_queries':qcount,'original_physical_records':len(weights),'conditional_seed_exclusions':len(seeds),'seeds_by_family':[sum(nodes[p]['family']==f for p in seeds) for f in [0,1]],'clique_exclusions':len(active)-len(retained)-len(seeds),'changed_signatures_by_family':changed,'reprojected_records_by_family':reprojected,'nonzero_weighted_query_updates':updates,'global_clique_upper_counts':counts,'scope_excluded':any(n<8 for n in counts),'fixed_point':active==retained}
    assert summary==expected and all(saved[k]==v for k,v in expected.items());results.append(expected)
    del columns,physical_masks,weights
assert record_count==87484 and physical_count==151597 and query_count==8551
cost=plan['inherited_numeric_preparation_seconds'];processes=[]
for label in ['h5-direct-restriction-plan']+[f'h5-direct-restriction-round-{i:02d}' for i in range(iteration+1)]:
    folder=ROOT/'output'/(label+'-process-20261109');p=load(folder/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0;cost+=p['complete_seconds'];processes.append({'stage':label,'complete_seconds':p['complete_seconds'],'charged':True})
    for path in [folder/'process.json',folder/'opened.json']:bindings[path.relative_to(ROOT).as_posix()]=sha256(path.read_bytes()).hexdigest()
for p in [Path(__file__),ROOT/'output/h5_pair_capacity_bitsets_20261109.py']+list(SOURCE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Independent allowed-union projection of every changed P intersection and exact unchanged carry. Full positive physical transpose/weight-plane recomputation of all25653bounds from all151597originalrecords. Verify all8551identities, every current seed, every overlay-aware clique implication, all summary fields and full preparation charges.'})
checks={'passed':True,'round_index':iteration,'complete_direct_queries':query_count,'conditional_area_bounds':3*query_count,'possible_node_records':record_count,'original_physical_records':physical_count,'conditional_seed_exclusions':sum(r['conditional_seed_exclusions'] for r in results),'clique_exclusions':sum(r['clique_exclusions'] for r in results),'remaining_nodes':sum(r['remaining_nodes'] for r in results),'joint_fixed_point':all(r['fixed_point'] for r in results),'all_scopes_excluded':all(r['scope_excluded'] for r in results),'remaining_fixed29_cases':sum(not r['scope_excluded'] for r in results),'complete_preparation_seconds_if_consumed':cost,'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False}
write(OUT/'case-results.json',results);write(OUT/'checks.json',checks);print(checks);print(results)
