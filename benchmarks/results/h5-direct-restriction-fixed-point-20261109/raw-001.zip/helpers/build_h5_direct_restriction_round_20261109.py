"""Complete monotone signature restriction with exact newly lost area deltas."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_block_projected_coverage_atoms_20261109 import forbidden_projection
from h5_weighted_query_masks_20261109 import weighted_query_sums
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-restriction-loop-20261109';SOURCE=ROOT/'output/h5-direct-overlay-reference-20261109';PARENT=ROOT/'benchmarks/results/h5-direct-overlay-capacity-20261109';iteration=int(sys.argv[1]);OUT=BASE/f'round-{iteration:02d}'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
plan=load(BASE/'plan.json');assert 0<=iteration<plan['maximum_rounds'] and load(BASE/'preflight-audit/checks.json')['passed']
initial_process=load(ROOT/'output/h5-direct-restriction-plan-audit-process-20261109/process.json');assert initial_process['passed'] and initial_process['closed'] and initial_process['job']['active_processes']==0
if iteration:
    previous=BASE/f'round-{iteration-1:02d}';audit=load(previous/'audit/checks.json');p=load(ROOT/f'output/h5-direct-restriction-round-{iteration-1:02d}-audit-process-20261109/process.json')
    assert audit['passed'] and not audit['joint_fixed_point'] and not audit['all_scopes_excluded'] and p['passed'] and p['closed'] and p['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),ROOT/'output/h5_block_projected_coverage_atoms_20261109.py',ROOT/'output/h5_weighted_query_masks_20261109.py',BASE/'plan.json',BASE/'preflight-audit/checks.json',BASE/'preflight-audit/plan.json'];results=[]
if iteration:inputs.extend([previous/'audit/checks.json',previous/'audit/plan.json',ROOT/f'output/h5-direct-restriction-round-{iteration-1:02d}-audit-process-20261109/process.json'])
for case in [1,9]:
    data=load(SOURCE/f'choice-{case:02d}-queries.json');qcount=len(data['query_positions']);graph=ROOT/data['graph'];nodes=load(graph/'nodes.json')
    if iteration==0:
        prior=data['active_current_positions'];active=load(PARENT/f'choice-{case:02d}-frontier.json')['remaining_current_positions'];old_folder=SOURCE/f'choice-{case:02d}-capacity';old_signatures=load(old_folder/'projected-signatures.json');old_rows=load(old_folder/'query-results.json')
        inputs.extend([PARENT/f'choice-{case:02d}-frontier.json',old_folder/'projected-signatures.json',old_folder/'query-results.json'])
    else:
        front=load(previous/f'choice-{case:02d}-frontier.json');prior=front['input_active_positions'];active=front['remaining_current_positions'];old_signatures=load(previous/f'choice-{case:02d}-signatures.json');old_rows=load(previous/f'choice-{case:02d}-queries.json')
        inputs.extend([previous/f'choice-{case:02d}-frontier.json',previous/f'choice-{case:02d}-signatures.json',previous/f'choice-{case:02d}-queries.json'])
    assert [r['current_position'] for r in old_rows]==data['query_positions']
    old_mask=sum(1<<p for p in prior);mask=sum(1<<p for p in active);assert mask&~old_mask==0
    inputs.extend([SOURCE/f'choice-{case:02d}-queries.json',graph/'nodes.json'])
    project=forbidden_projection(data);maps=[{},{}];signatures=[[],[]];changed=[0,0];reprojected=[0,0]
    for family in [0,1]:
        path=SOURCE/f'choice-{case:02d}-family-{family}-possible-nodes.json';inputs.append(path);records=load(path);assert len(records)==len(old_signatures[family])
        for (key,possible,_),saved in zip(records,old_signatures[family]):
            assert saved[0]==key;possible=int(possible,16);old=int(saved[1],16)
            if possible&old_mask==possible&mask:new=old
            else:new=project(possible&mask)[family];reprojected[family]+=1
            assert old&~new==0;changed[family]+=old!=new;maps[family][int(key,16)]=(old,new);signatures[family].append([key,hex(new)])
    deltas=[[],[],[]];physical_count=0;nonzero_updates=0
    for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
        if piece['refinement_index']!=case:continue
        path=ROOT/piece['folder']/'atoms.json';inputs.append(path)
        for b,i,weight in load(path):
            b0,b1=maps[0][int(b,16)];i0,i1=maps[1][int(i,16)]
            for family,loss in enumerate([b1&~b0,i1&~i0,(b1&i1)&~(b0&i0)]):
                if loss:deltas[family].append((loss,weight));nonzero_updates+=loss.bit_count()
            physical_count+=1
    losses=[weighted_query_sums(values,qcount) for values in deltas];active_set=set(active);rows=[];seeds=[]
    for qi,position in enumerate(data['query_positions']):
        old_values=old_rows[qi]['family_and_joint_area_upper_um2'];values=[old_values[f]-losses[f][qi] for f in range(3)];assert all(0<=a<=b for a,b in zip(values,old_values));family=data['query_families'][qi];required=data['required_by_reference_family_um2'][family];fails=[f for f in range(3) if values[f]<required[f]];excluded=bool(fails) and position in active_set
        rows.append({'query_index':qi,'current_position':position,'family':family,'family_and_joint_area_upper_um2':values,'required_area_um2':required,'failing_area_indices':fails,'current_cell_excluded':excluded})
        if excluded:seeds.append(position)
    current=mask&~sum(1<<p for p in seeds);cliques=[[int(v,16) for v in family] for family in data['root_clique_masks_hex']];forbidden={p:int(v,16) for p,v in zip(data['query_positions'],data['representative_active_forbidden_rows_hex'])};rounds=[]
    for step in range(plan['maximum_clique_passes_per_round']):
        removed=[]
        for p in active:
            if not current&(1<<p):continue
            allowed=current&~forbidden[p];upper=[sum(bool(group&allowed) for group in family) for family in cliques];required=[8-int(nodes[p]['family']==f) for f in [0,1]]
            if any(a<b for a,b in zip(upper,required)):removed.append({'current_position':p,'upper':upper,'required':required})
        rounds.append({'pass_index':step,'removed':removed});current&=~sum(1<<r['current_position'] for r in removed)
        if not removed:break
    retained=[p for p in active if current&(1<<p)];counts=[sum(bool(group&current) for group in family) for family in cliques]
    summary={'refinement_index':case,'input_nodes':len(active),'remaining_nodes':len(retained),'complete_queries':qcount,'original_physical_records':physical_count,'conditional_seed_exclusions':len(seeds),'seeds_by_family':[sum(nodes[p]['family']==f for p in seeds) for f in [0,1]],'clique_exclusions':len(active)-len(retained)-len(seeds),'changed_signatures_by_family':changed,'reprojected_records_by_family':reprojected,'nonzero_weighted_query_updates':nonzero_updates,'global_clique_upper_counts':counts,'scope_excluded':any(n<8 for n in counts),'fixed_point':active==retained}
    write(OUT/f'choice-{case:02d}-signatures.json',signatures);write(OUT/f'choice-{case:02d}-queries.json',rows);write(OUT/f'choice-{case:02d}-frontier.json',{**summary,'input_active_positions':active,'remaining_current_positions':retained,'conditional_removed_positions':seeds,'clique_rounds':rounds});results.append(summary)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'round_index':iteration,'method':'Complete direct-query delta update with exact unchanged-intersection carry, monotone newly lost masks, current-target filtering and simultaneous overlay-aware clique implications.'})
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'passed':True,'round_index':iteration,'conditional_seed_exclusions':sum(r['conditional_seed_exclusions'] for r in results),'clique_exclusions':sum(r['clique_exclusions'] for r in results),'remaining_nodes':sum(r['remaining_nodes'] for r in results),'joint_fixed_point':all(r['fixed_point'] for r in results),'all_scopes_excluded':all(r['scope_excluded'] for r in results),'seconds':time.perf_counter()-began,'optimizer_calls':0,'H5_complete':False});print(results)
