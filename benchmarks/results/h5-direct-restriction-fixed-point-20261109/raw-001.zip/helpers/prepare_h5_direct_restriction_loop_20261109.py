"""Freeze a finite complete monotone loop over the reduced direct-reference masks."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-direct-restriction-loop-20261109';SOURCE=ROOT/'output/h5-direct-overlay-reference-20261109';PARENT=ROOT/'benchmarks/results/h5-direct-overlay-capacity-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PARENT/'archive-checks.json')['passed']
OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),PARENT/'checks.json',PARENT/'archive-checks.json',SOURCE/'plan.json',SOURCE/'preflight-audit/plan.json',SOURCE/'preflight-audit/checks.json',ROOT/'output/h5-direct-overlay-frontier-20261109/audit/plan.json',ROOT/'output/h5-direct-overlay-frontier-20261109/audit/checks.json',ROOT/'output/h5-direct-overlay-controls-20261109/checks.json',ROOT/'output/h5-direct-overlay-controls-20261109/source-bindings.json',ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json']
cases=[]
for case in [1,9]:
    data=load(SOURCE/f'choice-{case:02d}-queries.json');old=data['active_current_positions'];current=load(PARENT/f'choice-{case:02d}-frontier.json')['remaining_current_positions'];assert set(current)<set(old)
    rows=load(SOURCE/f'choice-{case:02d}-capacity/query-results.json');assert [r['current_position'] for r in rows]==data['query_positions']
    for suffix in ['queries.json','family-0-possible-nodes.json','family-1-possible-nodes.json']:inputs.append(SOURCE/f'choice-{case:02d}-{suffix}')
    inputs.extend([PARENT/f'choice-{case:02d}-frontier.json']+[SOURCE/f'choice-{case:02d}-capacity'/name for name in ['projected-signatures.json','query-results.json','audit/checks.json','audit/plan.json']])
    graph=ROOT/data['graph'];inputs.extend([graph/'nodes.json',graph/'conflicts.bin'])
    cases.append({'refinement_index':case,'baseline_nodes':len(old),'initial_current_nodes':len(current),'complete_queries':len(rows),'baseline_source':f'output/h5-direct-overlay-reference-20261109/choice-{case:02d}-capacity','initial_frontier':f'benchmarks/results/h5-direct-overlay-capacity-20261109/choice-{case:02d}-frontier.json'})
for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):inputs.append(ROOT/piece['folder']/'atoms.json')
for name in ['h5_block_projected_coverage_atoms_20261109.py','h5_weighted_query_masks_20261109.py','h5_pair_capacity_bitsets_20261109.py']:inputs.append(ROOT/'output'/name)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'method':'Retain all8551 original direct query identities and fixed original+pair-overlay forbidden rows. Starting from the proved8350 mask, restrict every original P. Carry old signatures only for exactly unchanged P intersections; otherwise reproject. Producer subtracts newly lost family/joint weighted areas. Each independent auditor recomputes every full physical positive-area vector via allowed projections and physical integer weight planes, all current direct seeds and every simultaneous clique implication. Complete terminal audits are required before dependent rounds. Continue only on changed masks; stop at joint fixed point, all scopes excluded, or eight-round cap. No optimizer, original atlas or P reconstruction repeat.','maximum_rounds':8,'maximum_clique_passes_per_round':8,'producer_cap_seconds':60,'auditor_cap_seconds':60,'memory_bytes':2**31,'complete_cases':cases,'inherited_numeric_preparation_seconds':load(PARENT/'checks.json')['complete_preparation_seconds_if_consumed'],'optimizer_calls':0,'H5_complete':False})
write(OUT/'checks.json',{'prepared':True,'complete_queries':sum(c['complete_queries'] for c in cases),'initial_current_nodes':sum(c['initial_current_nodes'] for c in cases),'seconds':time.perf_counter()-began,'independent_audit_pending':True,'optimizer_calls':0});print(cases)
