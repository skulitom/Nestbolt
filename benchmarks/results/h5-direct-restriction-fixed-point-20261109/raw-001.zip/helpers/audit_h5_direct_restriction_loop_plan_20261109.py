"""Verify the complete baseline and current masks before opening restriction rounds."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-direct-restriction-loop-20261109';SOURCE=ROOT/'output/h5-direct-overlay-reference-20261109';PARENT=ROOT/'benchmarks/results/h5-direct-overlay-capacity-20261109';OUT=BASE/'preflight-audit'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
process_path=ROOT/'output/h5-direct-restriction-plan-process-20261109/process.json';process=load(process_path);assert process['passed'] and process['closed'] and process['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={};seen=set()
def verify(values):
    for name,h in values.items():
        if name not in seen:assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name;seen.add(name)
        if name in bindings:assert bindings[name]==h,name
        bindings[name]=h
verify(plan['inputs'])
for path in [SOURCE/'preflight-audit/plan.json',ROOT/'output/h5-direct-overlay-frontier-20261109/audit/plan.json']+[SOURCE/f'choice-{case:02d}-capacity/audit/plan.json' for case in [1,9]]:verify(load(path)['inputs'])
verify(load(ROOT/'output/h5-direct-overlay-controls-20261109/source-bindings.json'))
qcount=current_count=record_count=0
for case in [1,9]:
    data=load(SOURCE/f'choice-{case:02d}-queries.json');original=data['active_current_positions'];current=load(PARENT/f'choice-{case:02d}-frontier.json')['remaining_current_positions'];assert set(current)<set(original);mask=sum(1<<p for p in original)
    assert set(data['query_positions'])==set(original) and len(data['query_positions'])==len(original) and data['query_targets']==[[p] for p in data['query_positions']]
    assert data['required_by_reference_family_um2']==[[279993000000,158392000000,438385000000],[319992000000,138593000000,458585000000]]
    rows=load(SOURCE/f'choice-{case:02d}-capacity/query-results.json');signatures=load(SOURCE/f'choice-{case:02d}-capacity/projected-signatures.json');assert len(rows)==len(original)
    for qi,row in enumerate(rows):assert row['query_index']==qi and row['current_position']==data['query_positions'][qi] and row['family']==data['query_families'][qi]
    for family in [0,1]:
        records=load(SOURCE/f'choice-{case:02d}-family-{family}-possible-nodes.json');assert len(records)==len(signatures[family])
        for row,saved in zip(records,signatures[family]):assert row[0]==saved[0] and int(row[1],16)&mask==int(row[2],16) and 0<=int(saved[1],16)<(1<<len(rows))
        record_count+=len(records)
    qcount+=len(rows);current_count+=len(current)
assert qcount==8551 and current_count==8350 and record_count==87484 and plan['maximum_rounds']==8 and plan['maximum_clique_passes_per_round']==8
for p in [Path(__file__),BASE/'plan.json',process_path,process_path.parent/'opened.json']:bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Pin complete preceding direct capacity and exact frontier audits; verify every baseline query, original P identity/signature and strictly reduced current mask before any bounded round.'})
checks={'passed':True,'complete_direct_queries':qcount,'initial_current_nodes':current_count,'possible_node_records':record_count,'maximum_rounds':8,'seconds':time.perf_counter()-began,'optimizer_calls':0};write(OUT/'checks.json',checks);print(checks)
