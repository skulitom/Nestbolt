"""Seal qualified source-repair reuse before its unchanged matched pilot."""
from pathlib import Path
from hashlib import sha256
import difflib,json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-return-reuse-probe-20261018'
out=root/'benchmarks/results/h5-return-reuse-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan=load(probe/'preparation.json');build=load(probe/'build-v2.json');public=load(probe/'public-checks/checks.json')
assert build['all_checks_passed'] and public['all_checks_passed']
assert '96 passed; 0 failed; 0 ignored' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if arm!='candidate' or row['path'] not in plan['changed_files']:
            assert digest(probe/arm/row['path'])==row['sha256']
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
assert 'Ran 5 tests' in (probe/'pilot-harness-tests.log').read_text(encoding='utf-8')
assert (probe/'pilot-harness-tests.log').read_text(encoding='utf-8').rstrip().endswith('OK')
before=(Path(plan['old_probe'])/'candidate'/plan['changed_files'][0]).read_text(encoding='utf-8')
after=(probe/'candidate'/plan['changed_files'][0]).read_text(encoding='utf-8')
assert after[after.index('#[cfg(test)]'):].startswith(before[before.index('#[cfg(test)]'):].rsplit('\n}',1)[0])
# The entire existing post-repair validity/material/deadline/commit block stays exact.
start='                    if source_tracker.total_loss() > 0.0'
assert after[after.index(start):after.index('#[cfg(test)]')]==before[before.index(start):before.index('#[cfg(test)]')]
for snippet in ['.min(0.4);','let middle = (now + pair_end) / 2.0;']:
    assert before.count(snippet)==after.count(snippet)==1
stats=plan['changed_files'][1]
before_stats=(Path(plan['old_probe'])/'candidate'/stats).read_text(encoding='utf-8')
after_stats=(probe/'candidate'/stats).read_text(encoding='utf-8')
assert after_stats==before_stats.replace('    pub directed_exchanges: u64,','    pub directed_exchanges: u64,\n    #[serde(skip_serializing_if = "is_zero")]\n    pub directed_source_reuses: u64,')
(probe/'candidate-final.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='rejected-return-frame',tofile='qualified-return-reuse')),encoding='utf-8',newline='\n')
out.mkdir()
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
for name in ['prepare_h5_return_reuse.py','build_h5_return_reuse.py','return_repair_reuse_helper.rs','return_repair_reuse_tests.rs',
             'prepare_return_reuse_checks.py','check_h5_return_reuse_public.py','check_h5_return_reuse_harness.py']:
    files['helpers/'+name]=root/'output'/name
files['helpers/seal.py']=Path(__file__);files['helpers/pilot.py']=root/'scripts/h5_return_reuse_pilot.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(archive),'bytes':archive.stat().st_size,'members':inventory,'all_members_and_crc_verified':True})
write(out/'checks.json',{'all_functional_checks_pass':True,'optimized_core_passed':96,'all_90_previous_tests_retained':True,
    'new_reuse_tests':6,'strict_lint_pass':True,'public_observer_outcomes':10,'public_CLI_cross_checks':4,
    'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,'pilot_harness_tests':5,
    'whole_post_repair_acceptance_block_unchanged':True,'old_per_pair_deadline_cap_unchanged':True,
    'production_files_unchanged':True,'binaries':build['binaries'],'measured_search_started':False,
    'H5_complete':False,'integrated':False,'completed_weight_percent':60})
for name in ['preparation.json','build-v2.json','candidate.patch','candidate-final.patch','pilot-method.json']:shutil.copyfile(probe/name,out/name)
doc='''# Compatible return-repair reuse preparation — 2026-10-18

The isolated candidate passes 96 optimized core tests (all 90 existing tests
retained), strict lint, ten fixed-work authored observer outcomes, four public
CLI comparisons and five unchanged adversarial paired-harness checks. Normal
results remain exact apart from elapsed wall time; common-mode replays and
independent quantities/metrics pass. Production is unchanged.

Three fixed saved source assignments now have independently valid packings;
the fourth remains unresolved. Earlier traces repeat eight distinct source
inventory/container pairs across 25 attempts, with 17 repeats after the first.
The candidate retains one source Separator per exchange invocation. Reuse
requires the exact shared static-container object and original Item object
multiset, permitted saved poses and loss no worse than the fresh start. A
different container, geometry, permissions or count causes a fresh attempt.

The best returned snapshot is restored with matching tracker indices while
preserving guided-search weights and RNG state. Restoration registrations are
charged. The existing fresh separator is still constructed for a fair loss
comparison, and its usual RNG seed is consumed. The cache cannot outlive the
call. Its reuse counter omits zero values. Six added tests exercise restoration
and moved keys, preserved RNG, membership counts, geometry/permission identity,
static-container identity, fresh-start preference, forbidden poses and actual
reuse under strict material rejection with unchanged incumbent state.

Proposal ranking/caps, return-frame initialization, existing repair deadlines
and the whole independent geometry/material/deadline acceptance block remain
unchanged. The single retained state does not increase the existing shared
budget. No partially repaired state becomes the incumbent or an export.

The separate 72-outcome matched pilot keeps the previous four jobs, two kerfs,
three seeds, three arms, rotating sequential arm order, 60-second budgets and
eight physical CCD0 cores. Blocks, scoring, per-case handling and measurement
functions are AST-identical to the preceding pilot. It cannot close the full
13-job gate or relax the +1% material limit. No quality claim precedes those
results; H2/H5 remain open at 60%.
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-return-reuse-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''

## 2026-10-18 — Qualify compatible source-repair progress reuse

[The isolated candidate](benchmarks/results/h5-return-reuse-preparation-20261018.md)
passes 96 optimized tests, strict lint, ten authored observer outcomes, four
public CLI comparisons and five unchanged harness checks. All 90 old tests stay;
six new tests cover cache compatibility, best-state/tracker-key restoration,
RNG continuity, fresh-state preference and actual reuse under strict material
rejection. Normal results remain exact and common fixed-work replay passes.

One call-local source Separator may resume only for the same static container
and original part-object multiset, legal poses and no worse starting loss.
Restoration is charged; old proposal/repair budgets and the complete independent
acceptance block are unchanged. The original baseline binary is byte-identical.
The separately committed 72-outcome pilot retains its exact paired/scoring
method and original +1% limit. No production integration, held-out access or H5
credit. All artifacts verify; H2/H5 remain open at 60%.
''')
print(json.dumps({'sealed':str(out),'members':len(inventory),'bytes':archive.stat().st_size}))
