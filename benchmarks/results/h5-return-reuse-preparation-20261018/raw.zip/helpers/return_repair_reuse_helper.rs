// A cache lives only within one directed_exchange invocation. Exact shared
// static-container and Item identities bind geometry, defects and permissions;
// equal counts make identical copies interchangeable. Placement keys are not
// identities, and positions deliberately do not define an assignment.
fn same_return_assignment(a: &JLayout, b: &JLayout) -> bool {
    if !std::sync::Arc::ptr_eq(a.container().base_cde(), b.container().base_cde())
        || a.placed_items().len() != b.placed_items().len()
    {
        return false;
    }
    let members = |layout: &JLayout| {
        let mut items: Vec<_> = layout.placed_items().values().map(|p| p.item().clone()).collect();
        items.sort_by_key(|item| item.idx());
        items
    };
    members(a).iter().zip(members(b)).all(|(a,b)| std::sync::Arc::ptr_eq(a,&b))
}

fn resume_return_repair(saved: &mut Option<Separator>, fresh: Separator) -> (Separator, bool) {
    if let Some(previous) = saved.take()
        && previous.pinned.is_none() && previous.region.is_none()
        && fresh.pinned.is_none() && fresh.region.is_none()
        && same_return_assignment(&previous.layout, &fresh.layout)
        && previous.layout.placed_items().values().all(|p| p.item().allowed_orientations().allows(&p.d_transf()))
        && previous.tracker.total_loss() <= fresh.tracker.total_loss()
    {
        // The whole separator retains its matching tracker, weights and RNG.
        // Both separators share this invocation's clock and EXPLORE settings.
        (previous, true)
    } else {
        (fresh, false)
    }
}

fn remember_return_repair(
    saved: &mut Option<Separator>,
    mut separator: Separator,
    snapshot: &LayoutSnapshot,
    tracker: &crate::separate::Tracker,
) {
    // separate() returns its best snapshot, which need not be its current
    // mutable state. Restore both positions and tracker indices together;
    // rollback preserves guided-search weights and charges the registrations.
    separator.rollback(snapshot, Some(tracker));
    *saved = Some(separator);
}
