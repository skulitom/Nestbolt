"""Isolate one-slot, call-local compatible source-repair reuse."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib,json,shutil,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-return-reuse-probe-20261018';out.mkdir()
old=root/'output/h5-return-frame-probe-20261017'
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel;before=path.read_text(encoding='utf-8');text=before
assert digest(path)=='17e9c64a28399e42c1212357b93058bf1ea5a4f3d91206432e53adf401a8d912'
def replace(a,b):
    global text
    assert text.count(a)==1,a;text=text.replace(a,b)
marker="impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search<'_, '_, F> {"
replace(marker,(root/'output/return_repair_reuse_helper.rs').read_text(encoding='utf-8')+'\n'+marker)
replace('        let last_index = shape.sheets - 1;','        let mut saved_source_repair = None;\n        let last_index = shape.sheets - 1;')
replace('''                    let mut source_sep = Separator::new(
                        next_source,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );''','''                    let fresh_source = Separator::new(
                        next_source,
                        self.rng.next_u64(),
                        EXPLORE,
                        self.clock.clone(),
                    );
                    let (mut source_sep, reused) = resume_return_repair(&mut saved_source_repair, fresh_source);
                    self.stats.directed_source_reuses += u64::from(reused);''')
replace('''                    if source_tracker.total_loss() > 0.0''','''                    remember_return_repair(&mut saved_source_repair, source_sep, &source_snapshot, &source_tracker);
                    if source_tracker.total_loss() > 0.0''')
closing=text.rindex('\n}');text=text[:closing]+'\n'+(root/'output/return_repair_reuse_tests.rs').read_text(encoding='utf-8')+text[closing:]
path.write_text(text,encoding='utf-8',newline='\n')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='rejected-return-frame',tofile='return-reuse-candidate')),encoding='utf-8',newline='\n')
stats='crates/core/src/sheets.rs';p=out/'candidate'/stats;s=p.read_text(encoding='utf-8');needle='    pub directed_exchanges: u64,';assert s.count(needle)==1
p.write_text(s.replace(needle,needle+'\n    #[serde(skip_serializing_if = "is_zero")]\n    pub directed_source_reuses: u64,'),encoding='utf-8',newline='\n')
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'scope':__doc__,'old_probe':str(old),'changed_files':[rel,stats],
    'production_digest':source_digest(),'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
    'target':str(root/'output/h5-return-reuse-target-20261018'),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),
    'policy':'One optional source Separator per directed exchange invocation. Match exact static-container Arc and original Item Arc multiset; require permitted saved poses and no worse unweighted loss than the fresh start. Keep best snapshot, matching tracker/weights/RNG, charge rollback registrations, and preserve every original proposal/repair/deadline/acceptance/rollback limit. New counter omits zero values.',
    'new_tests':6,'all_90_existing_tests_retained':True,'measured_search_started':False,'H5_complete':False,'integrated':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'prepared':str(out),'new_tests':6,'production_digest':plan['production_digest']}))
