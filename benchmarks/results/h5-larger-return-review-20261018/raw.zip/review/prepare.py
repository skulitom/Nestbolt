"""Observe four failed authored tests under both unchanged runtimes, after each search ends."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-larger-return-test-review-v2-20261018';out.mkdir(exist_ok=False)
failed=root/'output/h5-larger-return-probe-20261018/initial-larger-attempt/candidate'
prior=root/'output/h5-mixed-exchange-probe-20261018/candidate';rel='crates/core/src/sheets/vstrip/exchange.rs'
failed_text=(failed/rel).read_text(encoding='utf-8');prior_runtime=(prior/rel).read_text(encoding='utf-8').split('#[cfg(test)]')[0]
direct='''        eprintln!("PAIR_FILTER_REVIEW {}", serde_json::json!({"kind":"direct","test":std::thread::current().name(),"job":job,"before":&before_layout,"after":&after,"stats":&search.stats,"moved":moved}));
'''
window='''            eprintln!("PAIR_FILTER_REVIEW {}", serde_json::json!({"kind":"window","test":std::thread::current().name(),"job":&job,"before":&layout,"after":&search.best.0,"stats":&search.stats,"enabled":enabled,"budget":budget}));
'''
files=[]
for arm in ['original','broader']:
    work=out/arm;shutil.copytree(failed,work)
    text=failed_text if arm=='broader' else prior_runtime+'#[cfg(test)]'+failed_text.split('#[cfg(test)]',1)[1]
    base=text
    a='        (moved, after, search.stats)';assert text.count(a)==1;text=text.replace(a,direct+a)
    a='''            assert!(checked.metrics.as_ref().unwrap().material_area <= before_material);
            if enabled && budget > 0.0 {'''
    cut=text.index('    fn accepted_exchange_still_fills_a_known_gap()')
    prefix,tail=text[:cut],text[cut:];assert tail.count(a)==1
    text=prefix+tail.replace(a,a.replace('            if enabled',window+'            if enabled'))
    assert text.replace(direct,'').replace(window,'')==base
    assert text.split('#[cfg(test)]')[0]==base.split('#[cfg(test)]')[0]
    (work/rel).write_text(text,encoding='utf-8',newline='\n')
    files.append({'arm':arm,'observed_source_sha256':sha256((work/rel).read_bytes()).hexdigest(),'runtime_sha256':sha256(base.split('#[cfg(test)]')[0].encode()).hexdigest(),'only_post_search_test_logging_added':True})
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'arms':files,'production_digest':source_digest(),
    'failed_candidate_source':str(failed),'failed_source_sha256':sha256((failed/rel).read_bytes()).hexdigest(),'prior_source':str(prior),'prior_source_sha256':sha256((prior/rel).read_bytes()).hexdigest(),
    'relative_source':rel,'target':str(root/'output/h5-larger-return-test-review-target-20261018'),
    'tests':['balanced_pair_falls_back_to_a_valid_single_exchange','return_frame_keeps_incumbent_when_roundoff_increases_charged_material','directed_exchange_uses_the_rotated_return_gap','accepted_exchange_still_fills_a_known_gap'],
    'timing':'Existing authored fixed-work budgets; all added logging occurs after each search has ended. No performance or quality measurement.',
    'production_changed':False,'held_out_inputs_read':False}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'prepare.py')
print('Two runtimes preserved exactly; only post-search test logging added')
