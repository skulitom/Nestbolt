"""Build both authored-test observers and independently validate every emitted layout."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,traceback
root=Path(__file__).resolve().parents[1];out=root/'output/h5-larger-return-test-review-v2-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(out/'plan.json');records=load(out/'progress.json');assert len(records)==6 and all(r['arm']=='original' for r in records)
builds=[];cli=root/'target/release/nestbolt.exe'
assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
def guards():
    assert source_digest()==plan['production_digest']
    assert digest(Path(plan['failed_candidate_source'])/plan['relative_source'])==plan['failed_source_sha256']
    assert digest(Path(plan['prior_source'])/plan['relative_source'])==plan['prior_source_sha256']
    for arm in plan['arms']:assert digest(out/arm['arm']/plan['relative_source'])==arm['observed_source_sha256']
try:
    for arm in ['broader']:
        guards();work=out/arm;command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--no-run','--target-dir',plan['target']+'-broader-v2']
        started=datetime.now(timezone.utc).isoformat()
        with (out/(arm+'-v2-build.log')).open('xb') as f:r=subprocess.run(command,cwd=work,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
        builds.append({'arm':arm,'command':command,'exit_code':r.returncode,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'log_sha256':digest(out/(arm+'-v2-build.log'))});write(out/'builds-v2.json',builds)
        assert r.returncode==0
        binaries=list((Path(plan['target']+'-broader-v2')/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1
        binary=out/(arm+'-v2-tests.exe');shutil.copyfile(binaries[0],binary)
        assert digest(binary)!=digest(out/'original-tests.exe')
        for test in plan['tests']:
            folder=out/(arm+'-v2-'+test);folder.mkdir();args=[str(binary),'--exact','sheets::vstrip::exchange::tests::'+test,'--nocapture']
            result=subprocess.run(args,cwd=work,capture_output=True,timeout=180)
            (folder/'stdout.log').write_bytes(result.stdout);(folder/'stderr.log').write_bytes(result.stderr)
            write(folder/'command.json',{'command':args,'exit_code':result.returncode,'binary_sha256':digest(binary)})
            assert result.returncode==(0 if arm=='original' else 101),(arm,test,result.returncode)
            rows=[json.loads(line.removeprefix('PAIR_FILTER_REVIEW ')) for line in result.stderr.decode().splitlines() if line.startswith('PAIR_FILTER_REVIEW ')]
            assert len(rows)==(3 if arm=='original' and test=='accepted_exchange_still_fills_a_known_gap' else 1)
            for index,row in enumerate(rows):
                case=folder/str(index);case.mkdir();write(case/'observation.json',row);write(case/'job.json',row['job']);metrics={}
                for phase in ['before','after']:
                    write(case/(phase+'.json'),row[phase]);args=[str(cli),'validate','--job',str(case/'job.json'),'--layout',str(case/(phase+'.json'))]
                    checked=subprocess.run(args,capture_output=True,timeout=60)
                    (case/(phase+'-stdout.json')).write_bytes(checked.stdout);(case/(phase+'-stderr.log')).write_bytes(checked.stderr);write(case/(phase+'-command.json'),{'command':args,'exit_code':checked.returncode})
                    assert checked.returncode==0 and json.loads(checked.stdout)['valid']
                    metrics[phase]=json.loads(checked.stdout)['metrics']
                assert metrics['after']['material_area']<=metrics['before']['material_area']
                records.append({'arm':arm,'test':test,'index':index,'enabled':row.get('enabled',True),'budget':row.get('budget'),
                    'material_before':metrics['before']['material_area'],'material_after':metrics['after']['material_area'],'stats':row['stats'],
                    'gap_part_sheet':[p['sheet_id'] for p in row['after']['placements'] if p['part_id']=='gap-part'],
                    'observation_path':(case/'observation.json').relative_to(out).as_posix(),'all_layouts_valid':True})
            write(out/'progress-v2.json',records);print(json.dumps({'arm':arm,'test':test,'expected_exit':result.returncode,'observations':len(rows)}),flush=True)
    guards();pairs=[]
    for test in plan['tests']:
        selected={arm:next(r for r in records if r['arm']==arm and r['test']==test and r['enabled'] and r['budget']!=0) for arm in ['original','broader']}
        assert selected['original']['material_before']==selected['broader']['material_before']
        pairs.append({'test':test,'original_material':selected['original']['material_after'],'broader_material':selected['broader']['material_after'],
            'difference_mm2':selected['broader']['material_after']-selected['original']['material_after'],
            'original_gap_sheet':selected['original']['gap_part_sheet'],'broader_gap_sheet':selected['broader']['gap_part_sheet']})
    write(out/'results.json',{'all_original_tests_passed':True,'all_four_broader_failures_reproduced':True,'observations':len(records),'public_validations':len(records)*2,'all_layouts_valid':True,'strict_material_nonincrease':True,'pairs':pairs,'records':records,'guards_unchanged':True,'performance_or_quality_claim':False})
    shutil.copyfile(__file__,out/'run.py');print(json.dumps({'all_layouts_valid':True,'public_validations':len(records)*2,'pairs':pairs}))
except BaseException:write(out/'failure-v2.json',{'error':traceback.format_exc(),'builds':builds,'records':records});raise
