"""Add a larger-return regression before changing the paired proposal filter."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-larger-return-probe-20261018';old=root/'output/h5-mixed-exchange-probe-20261018';out.mkdir(exist_ok=False)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
added={}
for source,name in [('job.json','larger-return-job.json'),('before.json','larger-return-before.json')]:
    p=out/'candidate/examples'/name;shutil.copyfile(root/'benchmarks/results/h5-larger-return-witness-20261018'/source,p);added['examples/'+name]=digest(p)
rel='crates/core/src/sheets/vstrip/exchange.rs';p=out/'candidate'/rel;text=p.read_text(encoding='utf-8')
tests='''    fn larger_return_fixture() -> (Job, Layout) {
        (
            serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../examples/larger-return-job.json"))).unwrap(),
            serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../examples/larger-return-before.json"))).unwrap(),
        )
    }

    #[test]
    fn larger_return_moves_both_incoming_with_strict_material_guard() {
        let (job, before) = larger_return_fixture();
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &before, seed, true, false, 0);
            eprintln!("LARGER_RETURN_WITNESS {}", serde_json::json!({"case":"larger_positive","seed":seed,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats}));
            assert_eq!(moved, 1, "larger return area must not exclude a valid material-nonincreasing pair exchange: {stats:?}");
            assert_eq!(stats.mixed_exchanges, 1);
            assert_eq!(stats.paired_exchanges, 1);
            for id in ["short-incoming", "tall-incoming"] {
                assert!(after.placements.iter().any(|p|p.part_id == id && p.sheet_id == "sheet-0"));
            }
            assert_eq!(after.placements.iter().filter(|p|p.part_id == "return" && p.sheet_id == "sheet-1").count(), 3);
        }
    }

    #[test]
    fn larger_return_disabled_or_expired_preserves_incumbent() {
        let (job, before) = larger_return_fixture();
        for seed in 0..4 {
            for (enabled, expired) in [(false, false), (true, true)] {
                let (moved, _, stats) = exercise(&job, &before, seed, enabled, expired, 0);
                assert_eq!(moved, 0);
                assert_eq!(stats.directed_exchange_attempts, 0);
                assert_eq!(stats.directed_exchanges, 0);
            }
        }
    }

'''
negative=text[text.index('    #[test]\n    fn mixed_pair_failed_return_room_preserves_incumbent()'):text.rindex('\n}')]
negative=negative.replace('mixed_pair_failed_return_room_preserves_incumbent','larger_return_failed_room_preserves_incumbent').replace('mixed_fixture()','larger_return_fixture()').replace('MIXED_WITNESS ','LARGER_RETURN_WITNESS ').replace('mixed_no_return_room','larger_no_return_room')
tests+=negative
p.write_text(text[:text.rindex('\n}')]+'\n'+tests+text[text.rindex('\n}'):],encoding='utf-8',newline='\n')
(out/'new-regressions.rs').write_text(tests,encoding='utf-8',newline='\n')
shutil.copyfile(p,out/'exchange-regressions-before.rs')
for src,dest in [('baseline-observer.exe','baseline-observer.exe'),('candidate-observer.exe','rejected-mixed-observer.exe')]:shutil.copyfile(old/src,out/dest)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'scope':__doc__,'old_probe':str(old),'changed_files':[rel],'added_files':added,
    'production_digest':source_digest(),'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
    'target':str(root/'output/h5-larger-return-target-20261018'),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),'rejected_mixed_observer_sha256':digest(out/'rejected-mixed-observer.exe'),
    'policy':'Only remove the paired proposal returned-area rejection. Keep the original complete union of at most three obstructions, ranking and six-proposal cap, pair selection/order, samples/anchors, all pose checks, both repairs, strict whole-job geometry/material checks, neutral guard, post-exchange fill, deadlines and normal-mode behavior.',
    'new_initial_tests':3,'all_107_existing_tests_retained':True,'runtime_changed':False,'measured_search_started':False,'H5_complete':False,'integrated':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'prepared':str(out),'initial_tests':3,'runtime_unchanged':True}))
