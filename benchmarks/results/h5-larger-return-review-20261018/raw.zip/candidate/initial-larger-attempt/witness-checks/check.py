"""Validate actual larger-return pair outcomes with the unchanged public CLI."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-larger-return-probe-20261018';out=probe/'initial-larger-attempt/witness-checks';out.mkdir(exist_ok=False)
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
assert json.loads((probe/'build-failure.json').read_bytes())['stages'][-1]['exit_code']==101
rows=[json.loads(line.split('LARGER_RETURN_WITNESS ',1)[1]) for line in (probe/'core-tests.log').read_text(encoding='utf-8').splitlines() if line.startswith('LARGER_RETURN_WITNESS ')]
expected={('larger_positive',s) for s in range(4)}|{('larger_frozen',0),('larger_no_return_room',0)}
assert len(rows)==6 and {(r['case'],r['seed']) for r in rows}==expected
cli=root/'target/release/nestbolt.exe';before_hash=sha256(cli.read_bytes()).hexdigest();records=[]
for row in rows:
    folder=out/(row['case']+'-s'+str(row['seed']));folder.mkdir();write(folder/'witness.json',row);write(folder/'job.json',row['job']);metrics={}
    for phase in ['before','after']:
        write(folder/(phase+'.json'),row[phase]);args=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/(phase+'.json'))]
        result=subprocess.run(args,capture_output=True,timeout=60)
        (folder/(phase+'-stdout.json')).write_bytes(result.stdout);(folder/(phase+'-stderr.log')).write_bytes(result.stderr);write(folder/(phase+'-command.json'),{'command':args,'exit_code':result.returncode})
        assert result.returncode==0,(row['case'],phase,result.stderr)
        report=json.loads(result.stdout);assert report['valid'];metrics[phase]=report['metrics']['material_area']
    stats=row['stats'];assert stats.get('mixed_exchanges',0)<=stats.get('mixed_exchange_attempts',0)<=stats.get('paired_exchange_attempts',0)<=stats.get('directed_exchange_attempts',0)
    if row['case']=='larger_no_return_room':
        assert row['moved']==0 and stats.get('directed_exchanges',0)==0
    else:
        assert row['moved']==1 and stats['mixed_exchanges']==1 and stats['paired_exchanges']==1
        target='sheet-1' if row['case']=='larger_frozen' else 'sheet-0'
        for name in ['short-incoming','tall-incoming']:assert any(p['part_id']==name and p['sheet_id']==target for p in row['after']['placements'])
    # The core exercise independently compares the exact internal incumbent,
    # with strict material nonincrease and exact rollback/frozen-sheet equality.
    # These public fixtures start at authored f64 coordinates before conversion.
    assert abs(metrics['after']-metrics['before'])<.001,metrics
    records.append({'case':row['case'],'seed':row['seed'],'valid_before_and_after':True,'material_mm2':metrics,'moved':row['moved'],'stats':stats})
assert sha256(cli.read_bytes()).hexdigest()==before_hash
write(out/'checks.json',{'all_checks_passed':True,'actual_outcomes':6,'public_validations':12,'CLI_sha256':before_hash,'records':records,'geometry_and_quantities_valid':True,'internal_strict_material_rollback_and_frozen_checks_pass':True,'production_changed':False})
shutil.copyfile(__file__,out/'check.py');print(json.dumps({'all_checks_passed':True,'actual_outcomes':6,'public_validations':12}))
