"""Remove only the pair proposal area filter after preserving its regression."""
from pathlib import Path
from hashlib import sha256
import difflib,json
root=Path(__file__).resolve().parents[1];out=root/'output/h5-larger-return-probe-20261018'
plan=json.loads((out/'preparation.json').read_bytes());r=json.loads((out/'regressions-before.json').read_bytes())
assert r['exit_code']==101 and r['positive_assertion_failed'] and r['expected_counts']
assert sha256((out/'regressions-before.log').read_bytes()).hexdigest()==r['log_sha256']
assert sha256((out/'regressions-before.exe').read_bytes()).hexdigest()==r['binary_sha256']
rel=plan['changed_files'][0];p=out/'candidate'/rel;before=p.read_text(encoding='utf-8');text=before
removed=['    let incoming_area: f32 = incoming.iter().map(|(_, item, _)| item.area()).sum();\n',
         '        if area > incoming_area {\n            continue;\n        }\n']
for fragment in removed:assert text.count(fragment)==1;text=text.replace(fragment,'')
expected=(Path(plan['old_probe'])/'candidate'/rel).read_text(encoding='utf-8')
runtime=expected.split('#[cfg(test)]')[0]
for fragment in removed:runtime=runtime.replace(fragment,'')
assert text.split('#[cfg(test)]')[0]==runtime
start=expected.index('    #[test]\n    fn mixed_pair_preserves_a_frozen_sheet()')
end=expected.index('    #[test]\n    fn mixed_pair_failed_return_room_preserves_incumbent()',start)
frozen=expected[start:end].replace('mixed_pair_preserves_a_frozen_sheet','larger_return_preserves_a_frozen_sheet').replace('mixed_fixture()','larger_return_fixture()').replace('MIXED_WITNESS ','LARGER_RETURN_WITNESS ').replace('mixed_frozen','larger_frozen')
at=text.rindex('\n}');text=text[:at]+'\n'+frozen+text[at:]
p.write_text(text,encoding='utf-8',newline='\n')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='unchanged-runtime-regression',tofile='larger-return-candidate')),encoding='utf-8',newline='\n')
(out/'runtime-change.json').write_text(json.dumps({'removed_fragments':removed,'other_runtime_text_exact':True,'new_tests_total':4,'all_previous_107_tests_retained':True,'strict_material_guard_unchanged':True,'deadlines_unchanged':True},indent=2)+'\n',encoding='utf-8',newline='\n')
s=(root/'output/build_h5_mixed_exchange_v2.py').read_text(encoding='utf-8').replace('h5-mixed-exchange-probe-20261018','h5-larger-return-probe-20261018').replace('-v2','')
path=root/'output/build_h5_larger_return.py';path.write_text(s,encoding='utf-8',newline='\n');compile(s,str(path),'exec')
print('Only paired returned-area rejection removed; frozen-sheet case added; all original runtime text otherwise exact')
