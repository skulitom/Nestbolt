    fn larger_return_fixture() -> (Job, Layout) {
        (
            serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../examples/larger-return-job.json"))).unwrap(),
            serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../../examples/larger-return-before.json"))).unwrap(),
        )
    }

    #[test]
    fn larger_return_moves_both_incoming_with_strict_material_guard() {
        let (job, before) = larger_return_fixture();
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &before, seed, true, false, 0);
            eprintln!("LARGER_RETURN_WITNESS {}", serde_json::json!({"case":"larger_positive","seed":seed,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats}));
            assert_eq!(moved, 1, "larger return area must not exclude a valid material-nonincreasing pair exchange: {stats:?}");
            assert_eq!(stats.mixed_exchanges, 1);
            assert_eq!(stats.paired_exchanges, 1);
            for id in ["short-incoming", "tall-incoming"] {
                assert!(after.placements.iter().any(|p|p.part_id == id && p.sheet_id == "sheet-0"));
            }
            assert_eq!(after.placements.iter().filter(|p|p.part_id == "return" && p.sheet_id == "sheet-1").count(), 3);
        }
    }

    #[test]
    fn larger_return_disabled_or_expired_preserves_incumbent() {
        let (job, before) = larger_return_fixture();
        for seed in 0..4 {
            for (enabled, expired) in [(false, false), (true, true)] {
                let (moved, _, stats) = exercise(&job, &before, seed, enabled, expired, 0);
                assert_eq!(moved, 0);
                assert_eq!(stats.directed_exchange_attempts, 0);
                assert_eq!(stats.directed_exchanges, 0);
            }
        }
    }

    #[test]
    fn larger_return_failed_room_preserves_incumbent() {
        let (mut job, mut before) = larger_return_fixture();
        *job.parts
            .iter_mut()
            .find(|p| p.id == "short-incoming")
            .unwrap() = rectangle("short-incoming", 30.0, 39.9);
        *job.parts
            .iter_mut()
            .find(|p| p.id == "tall-incoming")
            .unwrap() = rectangle("tall-incoming", 30.0, 49.9);
        for p in &mut before.placements {
            if p.part_id == "short-incoming" {
                p.transform.translation[1] = 1.01;
            }
            if p.part_id == "tall-incoming" {
                p.transform.translation[1] = 41.12;
            }
        }
        job.parts.push(rectangle("source-extra", 30.0, 7.7));
        before.placements.push(Placement {
            part_id: "source-extra".into(),
            copy_index: 0,
            sheet_id: "sheet-1".into(),
            transform: RigidTransform {
                translation: [2.0, 91.23],
                rotation_radians: 0.0,
                mirrored: false,
            },
        });
        let (moved, after, stats) = exercise(&job, &before, 0, true, false, 0);
        eprintln!(
            "LARGER_RETURN_WITNESS {}",
            serde_json::json!({"case":"larger_no_return_room","seed":0,"job":&job,"before":&before,"after":&after,"moved":moved,"stats":&stats})
        );
        assert_eq!(moved, 0);
        assert_eq!(stats.mixed_exchanges, 0);
        assert!(stats.directed_exchange_attempts > 0);
    }