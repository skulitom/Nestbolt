"""Independent exact containment of the new saved-world fixed39 inner bodies."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product
import ast,json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-first57-shelf-necessary-rectangles-20261104';OUT=BASE/'audit'
OLD=ROOT/'output/h5-first57-necessary-rectangles-20261104'
SHELF=ROOT/'output/h5-first57-top-insert-row-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
HELPER=ROOT/'output/audit_h5_first57_necessary_rectangles_20261104.py'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for folder in [BASE,OLD/'audit',SHELF/'audit']:
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
assert load(OLD/'audit/checks.json')['passed'] and load(SHELF/'audit/checks.json')['passed']
names={'cross','area','orient','transform','containment'}
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in names]
assert len(functions)==len(names)
exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
parts={p['id']:p for p in load(JOB)['parts']};canonical=load(PIECES)
fixed=load(SHELF/'fixed39.json');rects=load(BASE/'fixed-core-inner-rectangles.json')
selection=load(SHELF/'selection.json');assert selection==load(BASE/'selection.json')
assert len(fixed)==39 and len(rects)==41
seen=set()
for r in rects:
    owner=r['fixed_owner'];row=fixed[owner];family=row['part_id']
    assert r['identity']==[family,row['copy_index']] and r['site_bit']==15
    pieces=canonical[family] if family=='bracket' else [parts[family]['geometry'][0]['outer']]
    assert 0<=r['piece']<len(pieces) and (owner,r['piece']) not in seen;seen.add((owner,r['piece']))
    poly=transform(pieces[r['piece']],row['transform']);assert len(poly)==4
    containment(r['bounds_um'],poly)
assert seen=={(i,k) for i,row in enumerate(fixed) for k in range(2 if row['part_id']=='bracket' else 1)}
world=load(BASE/'world-cog-inner-rectangles.json')
assert world==[r for r in load(OLD/'world-cog-inner-rectangles.json') if r['site_bit'] in selection['remaining_candidate_sites']]
assert len(world)==975 and set(selection['remaining_candidate_sites'])==set(range(15))-{4,10}
moving=load(BASE/'moving-source-inner-rectangles.json');geometries=load(BASE/'geometry-domains.json')
assert moving==[r for r in load(OLD/'moving-source-inner-rectangles.json') if r['family']=='bracket']
assert geometries==load(OLD/'geometry-domains.json')[:8] and len(moving)==8
assert {(r['source_mode']['rotation_degrees'],r['source_mode']['mirrored']) for r in moving}=={(degree,mirror) for degree in parts['bracket']['rotations']['degrees'] for mirror in [False,True]}
inventory=load(PRE/'inventory.json')
assert sorted([[r['part_id'],r['copy_index']] for r in fixed]+selection['remaining_six_bracket_identities']+inventory['required_cog12_identities'])==sorted(inventory['first57_identities'])
inputs=[Path(__file__),HELPER,JOB,PIECES,PRE/'inventory.json']+[d/n for d,names in [(BASE,['plan.json','checks.json','selection.json','fixed-core-inner-rectangles.json','world-cog-inner-rectangles.json','moving-source-inner-rectangles.json','geometry-domains.json']),(OLD,['audit/plan.json','audit/checks.json']),(SHELF,['audit/plan.json','audit/checks.json','fixed39.json','selection.json'])] for n in names]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Every new fixed rectangle is strictly positive and all four corners lie inside its exact original convex source piece under the saved binary64 transform. Prior independent source-partition, cog containment and full-stock mode proofs apply to the unchanged subset. Ignoring positive clearance and using inner filled-source bodies enlarges feasibility. The fixed39 shelf is mandatory; all13 remaining cog sites are considered with one additional omission. No old fixed-core domains or capacities are reused.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'fixed_originals_verified':39,'fresh_fixed_inner_rectangles_verified':41,'fresh_exact_corners_verified':164,
    'unchanged_cog_inner_rectangles_verified':975,'legal_bracket_modes':8,'geometry_domains':8,'full_stock_necessary_relaxation':True,
    'complete_first57_identity_partition':True,'site_choices_excluded':0,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
