"""Fresh fixed39 necessary rectangles; reuse only certified intrinsic modes/cog bodies."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product
import ast,json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'output/h5-first57-necessary-rectangles-20261104'
SHELF=ROOT/'output/h5-first57-top-insert-row-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104'
OUT=ROOT/'output/h5-first57-shelf-necessary-rectangles-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
HELPER=ROOT/'output/prepare_h5_first57_necessary_rectangles_20261104.py'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),HELPER,JOB,PIECES,PRE/'inventory.json']+[OLD/n for n in ['audit/plan.json','audit/checks.json','geometry-domains.json','world-cog-inner-rectangles.json','moving-source-inner-rectangles.json']]+[SHELF/n for n in ['plan.json','audit/plan.json','audit/checks.json','fixed39.json','selection.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Rebuild source-contained inner rectangles from every saved original transform of the new fixed39 shelf. Preserve original cog inner rectangles for the13 remaining sites and all8 legal bracket modes with outward full-physical-stock domains. Zero clearance is a necessary relaxation. No prior fixed29 cover or capacity is imported.',
    'preparation_cap_seconds':25,'maximum_process_seconds':35,'fixed_core_mask_bit':15,'additional_empty_cog_sites':1,
    'required_brackets':6,'solver_calls':0,'global_allocation_exclusions':0})
assert load(OLD/'audit/checks.json')['passed'] and load(SHELF/'audit/checks.json')['passed']
names={'cross','area','transform','inside','inward','near_orthogonal_inner'}
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in names]
assert len(functions)==len(names)
exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
parts={p['id']:p for p in load(JOB)['parts']};canonical=load(PIECES)
fixed=load(SHELF/'fixed39.json');selection=load(SHELF/'selection.json')
assert len(fixed)==39 and selection['additional_empty_sites_required']==1
rects=[]
for owner,row in enumerate(fixed):
    family=row['part_id'];pieces=canonical[family] if family=='bracket' else [parts[family]['geometry'][0]['outer']]
    for pi,piece in enumerate(pieces):
        poly=transform(piece,row['transform'])
        assert len(poly)==4 and all(cross(a,b,c)>0 for a,b,c in zip(poly,poly[1:]+poly[:1],poly[2:]+poly[:2]))
        rects.append({'fixed_owner':owner,'identity':[family,row['copy_index']],'piece':pi,'site_bit':15,'bounds_um':near_orthogonal_inner(poly)})
world=[r for r in load(OLD/'world-cog-inner-rectangles.json') if r['site_bit'] in selection['remaining_candidate_sites']]
moving=[r for r in load(OLD/'moving-source-inner-rectangles.json') if r['family']=='bracket']
geometries=load(OLD/'geometry-domains.json')[:8]
assert len(rects)==41 and len(world)==975 and len(moving)==len(geometries)==8
inventory=load(PRE/'inventory.json')
assert sorted([[r['part_id'],r['copy_index']] for r in fixed]+selection['remaining_six_bracket_identities']+inventory['required_cog12_identities'])==sorted(inventory['first57_identities'])
for name,value in [('fixed-core-inner-rectangles.json',rects),('world-cog-inner-rectangles.json',world),('moving-source-inner-rectangles.json',moving),('geometry-domains.json',geometries),('selection.json',selection)]:write(OUT/name,value)
elapsed=time.perf_counter()-started;assert elapsed<25
checks={'prepared':True,'seconds':elapsed,'fixed_originals':39,'fixed_source_inner_rectangles':41,'cog_inner_rectangles':975,'legal_bracket_modes':8,
    'full_physical_stock_domains':True,'independent_source_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
