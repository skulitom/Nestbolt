from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'output'
def write(name,text):
    with (O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
wrapper=(O/'run_h5_first57_shelf_necessary_rectangles_20261104.py').read_text(encoding='utf-8')
wrapper=wrapper.replace('h5-first57-shelf-necessary-rectangles-process','h5-first57-edge-combined-sources-process').replace('prepare_h5_first57_shelf_necessary_rectangles','prepare_h5_edge_combined_sources').replace('35','20')
write('run_h5_edge_combined_sources_20261104.py',wrapper)
for kind in ['prepare','run','audit']:
    text=(O/f'{kind}_h5_first57_shelf_necessary_mask_cover_20261104.py').read_text(encoding='utf-8')
    text=text.replace('h5-first57-shelf-necessary-rectangles','h5-first57-edge-combined-sources').replace('h5-first57-shelf-necessary-mask-cover','h5-first57-edge-insert-mask-cover')
    text=text.replace('prepare_h5_first57_shelf_necessary_mask_cover','prepare_h5_edge_insert_mask_cover')
    text=text.replace('plus41 fixed-core','plus35 fixed-core').replace('fixed39','fixed33')
    if kind=='prepare':text=text.replace('for g in geometries:','for g in geometries[8:]:')
    if kind=='audit':
        text=text.replace('for gid,g in enumerate(geometries):','for g in geometries[8:]:\n    gid=g["geometry"]')
        text=text.replace('range(8)','range(8,10)').replace("'geometries':8","'geometries':2").replace("'site_bit_fields_independently_replayed':128","'site_bit_fields_independently_replayed':32")
    write(f'{kind}_h5_edge_insert_mask_cover_20261104.py',text)
print('Prepared exact byte-composition and new insert-only cover helpers.')
