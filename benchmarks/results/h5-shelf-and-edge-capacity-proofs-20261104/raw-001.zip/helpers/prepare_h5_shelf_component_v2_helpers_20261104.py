"""Preserve the failed empty-domain run and create an explicit zero-shape branch."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'output'
def write(name,text):
    with (O/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
for kind in ['prepare','audit','run']:
    old=f'{kind}_h5_first57_shelf_component_area_20261104.py'
    text=(O/old).read_text(encoding='utf-8').replace('h5-first57-shelf-component-area','h5-first57-shelf-component-area-v2')
    if kind=='prepare':
        text=text.replace("edges=STRtree(shapes).query(shapes,predicate='intersects')","edges=STRtree(shapes).query(shapes,predicate='intersects') if shapes else ([],[])")
        text=text.replace("inputs=[Path(__file__)]","inputs=[Path(__file__),ROOT/'output/h5-first57-shelf-component-area-process-20261104/process.json',ROOT/'output/h5-first57-shelf-component-area-process-20261104/stderr.txt',ROOT/'output/h5-first57-shelf-component-area-20261104/plan.json']")
    if kind=='run':text=text.replace('prepare_h5_first57_shelf_component_area_20261104.py','prepare_h5_first57_shelf_component_area_v2_20261104.py')
    write(f'{kind}_h5_first57_shelf_component_area_v2_20261104.py',text)
print('Created v2 with explicit empty-list handling; original failure retained.')
