"""Create fresh fixed33 necessary proofs without any shelf obstacles."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'output'
def emit(old,new):
    text=(O/old).read_text(encoding='utf-8')
    text=text.replace('h5-first57-shelf-','h5-first57-edge-necessary-')
    text=text.replace('h5_first57_shelf_','h5_first57_edge_necessary_')
    text=text.replace('h5-first57-top-insert-row-20261104','h5-first57-edge-companion-v2-20261104')
    text=text.replace('fixed39','fixed33').replace('fixed_originals\':39','fixed_originals\':33').replace('fixed_originals_verified\':39','fixed_originals_verified\':33')
    text=text.replace('len(fixed)==39','len(fixed)==33').replace('len(rects)==41','len(rects)==35')
    text=text.replace("':41","':35").replace("':164","':140").replace('plus41 fixed-core','plus35 fixed-core')
    text=text.replace('remaining_six_bracket_identities','remaining_moving12_identities')
    text=text.replace('new fixed33 shelf','edge fixed33 core').replace('fixed33 shelf is mandatory','fixed33 core is mandatory')
    text=text.replace('before the shelf construction','before the edge construction')
    # The v2 empty-list handling is unchanged, but this new input set does not use the shelf failure.
    text=text.replace(",ROOT/'output/h5-first57-edge-necessary-component-area-process-20261104/process.json',ROOT/'output/h5-first57-edge-necessary-component-area-process-20261104/stderr.txt',ROOT/'output/h5-first57-edge-necessary-component-area-20261104/plan.json'",'')
    with (O/new).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
for family in ['necessary_rectangles','necessary_mask_cover','component_area_v2']:
    for kind in ['prepare','run','audit']:
        emit(f'{kind}_h5_first57_shelf_{family}_20261104.py',f'{kind}_h5_first57_edge_necessary_{family}_20261104.py')
print('Created fixed33 proof scripts; six inserts are free and ignored by bracket-only bound.')
