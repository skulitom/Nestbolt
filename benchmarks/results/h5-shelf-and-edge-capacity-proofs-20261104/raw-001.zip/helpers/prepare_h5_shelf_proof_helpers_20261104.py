"""Specialize the prior independent continuous proof pipeline for the new fixed39."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'output'
def emit(old,new,replacements):
    text=(O/old).read_text(encoding='utf-8')
    for a,b in replacements:
        assert a in text,(old,a);text=text.replace(a,b)
    if (O/new).exists():
        assert (O/new).read_text(encoding='utf-8')==text
    else:
        with (O/new).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
for name in ['necessary_rectangles','necessary_mask_cover','component_area']:
    emit(f'run_h5_first57_{name}_20261104.py',f'run_h5_first57_shelf_{name}_20261104.py',[
        (name.replace('_','-'),('shelf_'+name).replace('_','-')),(f'prepare_h5_first57_{name}',f'prepare_h5_first57_shelf_{name}')])
emit('prepare_h5_first57_necessary_mask_cover_20261104.py','prepare_h5_first57_shelf_necessary_mask_cover_20261104.py',[
    ('h5-first57-necessary-rectangles','h5-first57-shelf-necessary-rectangles'),('h5-first57-necessary-mask-cover','h5-first57-shelf-necessary-mask-cover'),
    ('all1125 cog plus29 fixed-core','all975 cog plus41 fixed-core'),('at most three cog bits','at most one cog bit'),
    ("'required_empty_cog_sites':3","'required_empty_cog_sites':1"),('popcount[row]<=3','popcount[row]<=1')])
emit('audit_h5_first57_necessary_mask_cover_20261104.py','audit_h5_first57_shelf_necessary_mask_cover_20261104.py',[
    ('h5-first57-necessary-rectangles','h5-first57-shelf-necessary-rectangles'),('h5-first57-necessary-mask-cover','h5-first57-shelf-necessary-mask-cover'),
    ('popcount[mask]<=3','popcount[mask]<=1'),('m.bit_count()<=3','m.bit_count()<=1'),
    ('range(10)','range(8)'),("'geometries':10","'geometries':8"),("'site_bit_fields_independently_replayed':160","'site_bit_fields_independently_replayed':128"),
    ('at most3 cog bits','at most1 cog bit'),('fixed29','fixed39')])
for kind in ['prepare','audit']:
    replacements=[
        ('h5-first57-necessary-rectangles','h5-first57-shelf-necessary-rectangles'),('h5-first57-necessary-mask-cover','h5-first57-shelf-necessary-mask-cover'),
        ('h5-first57-component-area','h5-first57-shelf-component-area'),('combinations(range(15),3)','combinations([i for i in range(15) if i not in [4,10]],1)')]
    if kind=='prepare':
        replacements += [('all455','all13'),("'required_brackets':8","'required_brackets':6"),("'required_empty_sites':3","'required_empty_sites':1"),
            ("sum(g['capacity'] for g in groups)<8","sum(g['capacity'] for g in groups)<6")]
    else:
        replacements += [('fixed29','fixed39'),('len(actual)==455','len(actual)==13'),('range(455)','range(13)'),('excluded=capacity<8','excluded=capacity<6'),
            ('selected twelve of the15 original cog poses','selected twelve of the13 remaining original cog poses; sites4 and10 were omitted before the shelf construction')]
    emit(f'{kind}_h5_first57_component_area_20261104.py',f'{kind}_h5_first57_shelf_component_area_20261104.py',replacements)
print('Created shelf proof wrappers and independent derived mask/capacity readers.')
