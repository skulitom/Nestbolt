"""Seal source shelf control, exact conditional exclusions and preserved failure."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-shelf-and-edge-capacity-proofs-20261104';OUT=ROOT/'benchmarks/results'/NAME
SHELF=ROOT/'output/h5-first57-top-insert-row-20261104'
SRC=ROOT/'output/h5-first57-shelf-necessary-rectangles-20261104';COVER=ROOT/'output/h5-first57-shelf-necessary-mask-cover-20261104';CAP=ROOT/'output/h5-first57-shelf-component-area-v2-20261104'
ESRC=ROOT/'output/h5-first57-edge-necessary-necessary-rectangles-20261104';ECOVER=ROOT/'output/h5-first57-edge-necessary-necessary-mask-cover-20261104';ECAP=ROOT/'output/h5-first57-edge-necessary-component-area-v2-20261104'
COMBINED=ROOT/'output/h5-first57-edge-combined-sources-20261104';INSERT=ROOT/'output/h5-first57-edge-insert-mask-cover-20261104';JOINT=ROOT/'output/h5-first57-edge-joint-capacities-20261104'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
for base in [SHELF,SRC,COVER,CAP,ESRC,ECOVER,ECAP,COMBINED,INSERT,JOINT]:assert load(base/'audit/checks.json')['passed']
assert load(CAP/'audit/checks.json')['new_site_choices_excluded']==13
assert load(ECAP/'audit/retained-choices.json')==[{'index':4,'empty_sites':[5],'bracket_capacity':6,'group_capacities':[5,1]}]
assert 5 in load(JOINT/'audit/checks.json')['remaining_site_choices']
failure=ROOT/'output/h5-first57-shelf-component-area-process-20261104';assert load(failure/'process.json')['exit_code']==1
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.append(ROOT/'benchmarks/results/h5-first57-edge-controls-and-companion-20261104')
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')]
setup=setup.replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
folders=['h5-first57-top-insert-row','h5-first57-top-insert-row-process','h5-first57-shelf-necessary-rectangles','h5-first57-shelf-necessary-rectangles-process','h5-first57-shelf-necessary-mask-cover','h5-first57-shelf-necessary-mask-cover-process','h5-first57-shelf-component-area','h5-first57-shelf-component-area-process','h5-first57-shelf-component-area-v2','h5-first57-shelf-component-area-v2-process',
    'h5-first57-edge-necessary-necessary-rectangles','h5-first57-edge-necessary-necessary-rectangles-process','h5-first57-edge-necessary-necessary-mask-cover','h5-first57-edge-necessary-necessary-mask-cover-process','h5-first57-edge-necessary-component-area-v2','h5-first57-edge-necessary-component-area-v2-process',
    'h5-first57-edge-combined-sources','h5-first57-edge-combined-sources-process','h5-first57-edge-insert-mask-cover','h5-first57-edge-insert-mask-cover-process','h5-first57-edge-joint-capacities','h5-first57-edge-joint-capacities-process']
for name in folders:
    folder=ROOT/'output'/(name+'-20261104')
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_first57_top_insert_row_20261104.py','*h5*shelf*20261104.py','*h5_first57_edge_necessary*20261104.py','*h5_edge*20261104.py','prepare_h5_joint_capacity_runner_20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-shelf-and-edge-capacity-report-20261104.md']:add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(SHELF/'audit/checks.json','shelf-source-audit.json'),(SRC/'audit/checks.json','shelf-inner-body-audit.json'),(COVER/'audit/checks.json','shelf-mask-audit.json'),(CAP/'audit/checks.json','shelf-capacity-audit.json'),(CAP/'audit/verified-choices.json','shelf-choices.json'),(failure/'process.json','failed-capacity-process.json'),
    (ESRC/'audit/checks.json','edge-inner-body-audit.json'),(ECOVER/'audit/checks.json','edge-mask-audit.json'),(ECAP/'audit/checks.json','edge-capacity-audit.json'),(ECAP/'audit/retained-choices.json','retained-edge-choice.json'),
    (COMBINED/'audit/checks.json','combined-source-audit.json'),(INSERT/'audit/checks.json','insert-mask-audit.json'),(JOINT/'audit/checks.json','joint-capacity-audit.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'next-step.json',{'fixed_shelf_continuously_excluded':True,'fixed33_omitted_sites':[4,5,10],'fixed33_remaining_cog_choices':1,'required_remaining_brackets':6,'required_remaining_inserts':6,
    'necessary_bracket_group_capacities':[5,1],'next_method':'Assess a genuinely distinct positive construction over the remaining fixed33 cog selection with certified necessary continuous anchor covers and mandatory five/one bracket group counts. Build fresh positive source-covering obstacles for occupied sites and remove only interactions proved irrelevant to the complete swept source-covering mode domains. Domain and count implications need independent audits; source-contained necessary rectangles alone cannot certify a positive placement. Charge all consumed preparation, including inherited source generation, before any new frozen60/90-second call. Do not rerun the closed twelve-part companion or the excluded fixed shelf.',
    'new_model_prepared':False,'previous_calls_remain_closed':True,'necessary_first57_site_choices':259,'older_fixed13_cog_frontier':{'site_choices':2,'count_distributions':3},'remaining_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'source_valid52_reference':True,'fixed39_shelf_choices_excluded':13,'fixed33_edge_choices_excluded':12,'fixed33_edge_choices_remaining':1,
    'joint_bound_additional_exclusions':0,'preserved_failed_preparation':True,'all_successful_preparations_within_caps':True,'solver_calls':0,'native_calls':0,'source_valid66':False,
    'broader_fixed29_choices_remaining':259,'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-shelf-and-edge-capacity-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 shelf and edge capacity proofs:** [independent continuous-source audits]({link}) validate a 52-part reference control but prove the fixed top insert shelf cannot hold the six remaining brackets for any of 13 cog selections. Fresh fixed33 bracket capacities, with the shelf removed, exclude 12 of 13 choices and retain only empty cog sites [4,5,10], with necessary bracket group capacities five/one. A joint bracket/insert area-count proof adds no exclusion to this frontier. The failed empty-list preparation and corrected version remain preserved; every successful preparation is within its cap. No new solver/native call was opened and every prior call stays closed. These conditional exclusions leave the broader 259-choice fixed29 frontier and 440 whole-job allocations unchanged. Full66 validation and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [edge controls and twelve-part companion](../benchmarks/results/h5-first57-edge-controls-and-companion-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [shelf and edge capacity proofs](../benchmarks/results/{NAME}.md).',1)
a='The direct 4/2/3 short sheet passes source checks in 0.297 s. New source-valid\nedge controls fix two brackets and two inserts, leaving six of each moving.\nThe audited twelve-part companion closes UNKNOWN without a complete placement.\nThe necessary capacity proofs still exclude 196 of the 455 fixed-core twelve-cog\nselections, leaving 259. A direct top insert shelf and fresh bracket capacities\nremain to investigate before another construction.'
b='The direct 4/2/3 short sheet passes source checks in 0.297 s. A new source-valid\n52-part reference shelf cannot be completed: continuous bounds exclude all 13\ncog choices. Without the shelf, fixed33 retains only empty sites [4,5,10], with\nnecessary bracket capacities five/one. Joint bracket/insert bounds leave that\nchoice open. The broader fixed29 frontier remains 259 choices. A new positive\nconstruction and fully charged model remain to develop; all prior calls stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
