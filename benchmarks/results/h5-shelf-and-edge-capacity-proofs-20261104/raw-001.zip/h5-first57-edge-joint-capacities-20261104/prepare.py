"""Joint source-body area/count bounds for all13 fixed33 cog selections."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from shapely import box,union_all,STRtree
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-edge-joint-capacities-20261104'
SOURCE=ROOT/'output/h5-first57-edge-combined-sources-20261104'
BR=ROOT/'output/h5-first57-edge-necessary-necessary-mask-cover-20261104';INS=ROOT/'output/h5-first57-edge-insert-mask-cover-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for base in [SOURCE,BR,INS]:assert load(base/'audit/checks.json')['passed']
inputs=[Path(__file__)]+[base/n for base in [SOURCE,BR,INS] for n in ['audit/plan.json','audit/checks.json']]+[SOURCE/n for n in ['geometry-domains.json','fixed-core-inner-rectangles.json','world-cog-inner-rectangles.json']]+[(BR if gid<8 else INS)/f'geometry-{gid:02d}-cover.json' for gid in range(10)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'For each of13 one-more-empty cog choices, group all eligible bracket and insert anchor boxes by intersections of swept inner source bodies. Each node carries its complete source-contained body. Bound group occupancy jointly by b*minimum_bracket_area+i*minimum_insert_area <= group reachable area, disallowing any family without an eligible node. Convolve bounded group count pairs for the required six brackets/six inserts. Independent exact integer area and count replay is required before exclusions. No prior bracket capacity result is used.',
    'preparation_cap_seconds':25,'maximum_process_seconds':35,'required_brackets':6,'required_inserts':6,'solver_calls':0})
geometries=load(SOURCE/'geometry-domains.json')
sources=load(SOURCE/'world-cog-inner-rectangles.json')+load(SOURCE/'fixed-core-inner-rectangles.json')
covers=[load((BR if gid<8 else INS)/f'geometry-{gid:02d}-cover.json') for gid in range(10)]
minima={family:min(sum((c-a)*(d-b) for a,b,c,d in g['inner_rectangles_um']) for g in geometries if g['aliases'][0][0]==family) for family in ['bracket','insert']}
write(OUT/'source-area-minima.json',minima);records=[]
for index,empty in enumerate(i for i in range(15) if i not in [4,10]):
    bits=1<<empty;nodes=[];shapes=[];owners=[]
    for gid,cover in enumerate(covers):
        for ri,(mask,x,y,z,w,*_) in enumerate(cover):
            if mask&~bits:continue
            node=len(nodes);nodes.append([gid,ri])
            for a,b,c,d in geometries[gid]['inner_rectangles_um']:shapes.append(box(x+a,y+b,z+c,w+d));owners.append(node)
    parent=list(range(len(nodes)))
    def root(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    def join(i,j):
        a,b=root(i),root(j)
        if a!=b:parent[max(a,b)]=min(a,b)
    edges=STRtree(shapes).query(shapes,predicate='intersects') if shapes else ([],[])
    for a,b in zip(*edges):join(owners[int(a)],owners[int(b)])
    grouped={}
    for i,node in enumerate(nodes):grouped.setdefault(root(i),[]).append(i)
    obstacle=union_all([box(*r['bounds_um']) for r in sources if r['site_bit']!=empty])
    groups=[];counts={(0,0)}
    for indices in grouped.values():
        selected=set(indices);assignments=[nodes[i] for i in indices]
        area=float(union_all([p for p,owner in zip(shapes,owners) if owner in selected]).difference(obstacle).area)
        families=sorted({geometries[g]['aliases'][0][0] for g,ri in assignments})
        pairs=[[b,i] for b in range(7 if 'bracket' in families else 1) for i in range(7 if 'insert' in families else 1) if b*minima['bracket']+i*minima['insert']<=area]
        counts={(b+x,i+y) for b,i in counts for x,y in pairs if b+x<=6 and i+y<=6}
        groups.append({'anchor_boxes':assignments,'families':families,'reachable_area_um2':area,'allowed_count_pairs':pairs})
    claim={'index':index,'additional_empty_site':empty,'eligible_anchor_boxes':len(nodes),'groups':groups,'reachable_total_pairs':sorted(map(list,counts)),'diagnostic_excluded':(6,6) not in counts}
    write(OUT/f'choice-{index:02d}.json',claim)
    records.append({k:v for k,v in claim.items() if k not in ['groups','reachable_total_pairs']}|{'group_count':len(groups),'group_areas_um2':[g['reachable_area_um2'] for g in groups]})
    assert time.perf_counter()-started<25
write(OUT/'all-choices.json',records)
checks={'prepared':True,'seconds':time.perf_counter()-started,'choices':13,'diagnostic_excluded':sum(r['diagnostic_excluded'] for r in records),'independent_exact_area_and_count_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
