"""Independent two-dimensional difference-count replay of all continuous mask cells."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from bisect import bisect_left,bisect_right
import json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-shelf-necessary-mask-cover-20261104';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-first57-shelf-necessary-rectangles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def classify_axis(points):
    values=[]
    for i,x in enumerate(points):
        if i:values.append(points[i-1]+x)
        values.append(2*x)
    return values
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,SOURCE/'audit']:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(SOURCE/'audit/checks.json')['passed']
source_obstacles=load(SOURCE/'world-cog-inner-rectangles.json')+load(SOURCE/'fixed-core-inner-rectangles.json')
geometries=load(SOURCE/'geometry-domains.json');popcount=np.array([v.bit_count() for v in range(65536)],dtype=np.uint8)
total_classes=total_retained=total_boxes=total_masks=0;summaries=[]
for gid,g in enumerate(geometries):
    assert g['geometry']==gid
    d=g['anchor_domain_um'];expected=[]
    for si,source in enumerate(source_obstacles):
        u,v,w,z=source['bounds_um']
        for pi,(a,b,c,e) in enumerate(g['inner_rectangles_um']):
            rect=[u-c,v-e,w-a,z-b]
            if rect[0]>=d[2] or rect[2]<=d[0] or rect[1]>=d[3] or rect[3]<=d[1]:continue
            expected.append({'source_rectangle':si,'moving_component':pi,'site_bit':source['site_bit'],'bounds_um':rect})
    actual=load(BASE/f'geometry-{gid:02d}-obstacles.json');assert actual==expected
    xs=sorted({d[0],d[2]}|{v for r in expected for v in [r['bounds_um'][0],r['bounds_um'][2]] if d[0]<=v<=d[2]})
    ys=sorted({d[1],d[3]}|{v for r in expected for v in [r['bounds_um'][1],r['bounds_um'][3]] if d[1]<=v<=d[3]})
    xx,yy=classify_axis(xs),classify_axis(ys)
    with np.load(BASE/f'geometry-{gid:02d}-classes.npz',allow_pickle=False) as data:
        assert set(data.files)=={'xcuts_um','ycuts_um','mask'}
        assert data['xcuts_um'].dtype==data['ycuts_um'].dtype==np.dtype('int64')
        assert data['xcuts_um'].tolist()==xs and data['ycuts_um'].tolist()==ys
        mask=data['mask'];assert mask.dtype==np.dtype('uint16') and mask.shape==(len(yy),len(xx))
    replay=np.zeros(mask.shape,dtype=np.uint16)
    for bit in range(16):
        diff=np.zeros((len(yy)+1,len(xx)+1),dtype=np.int32);events=[]
        for r in expected:
            if r['site_bit']!=bit:continue
            a,b,c,e=r['bounds_um']
            xa,xb=bisect_right(xx,2*a),bisect_left(xx,2*c)
            ya,yb=bisect_right(yy,2*b),bisect_left(yy,2*e)
            assert 0<=xa<=xb<=len(xx) and 0<=ya<=yb<=len(yy)
            if xa<xb and ya<yb:
                assert xx[xa]>2*a and xx[xb-1]<2*c and yy[ya]>2*b and yy[yb-1]<2*e
                if xa:assert xx[xa-1]<=2*a
                if xb<len(xx):assert xx[xb]>=2*c
                if ya:assert yy[ya-1]<=2*b
                if yb<len(yy):assert yy[yb]>=2*e
                events.append((xa,ya,xb,yb))
        for xa,ya,xb,yb in events:
            diff[ya,xa]+=1;diff[ya,xb]-=1;diff[yb,xa]-=1;diff[yb,xb]+=1
        counts=np.cumsum(np.cumsum(diff,axis=0,dtype=np.int32),axis=1,dtype=np.int32)
        assert int(counts.min())>=0 and int(counts.max())<=len(events)
        replay[counts[:-1,:-1]>0]|=np.uint16(1<<bit)
    assert np.array_equal(replay,mask)
    valid=((mask&32768)==0)&(popcount[mask]<=1)
    covered=np.zeros(mask.shape,dtype=np.uint8);boxes=load(BASE/f'geometry-{gid:02d}-cover.json')
    for r in boxes:
        assert len(r)==9 and all(isinstance(v,int) for v in r)
        m,left,bottom,right,top,xa,ya,xb,yb=r
        assert 0<=m<32768 and m.bit_count()<=1 and 0<=xa<=xb<len(xx) and 0<=ya<=yb<len(yy)
        assert [left,bottom,right,top]==[xs[xa//2],ys[ya//2],xs[(xb+1)//2],ys[(yb+1)//2]]
        assert np.all(mask[ya:yb+1,xa:xb+1]==m)
        covered[ya:yb+1,xa:xb+1]+=1
    assert np.array_equal(covered,valid.astype(np.uint8))
    hist=np.bincount(mask[valid],minlength=65536);summary=load(BASE/f'geometry-{gid:02d}-summary.json')
    assert summary['geometry']==gid and summary['all_classes']==mask.size and summary['retained_classes']==int(valid.sum())
    assert summary['cover_boxes']==len(boxes) and summary['x_classes']==len(xx) and summary['y_classes']==len(yy)
    masks=[]
    for m in np.flatnonzero(hist).tolist():
        rs=[r for r in boxes if r[0]==m]
        masks.append({'mask':m,'required_empty_sites':[i for i in range(15) if m&(1<<i)],'class_count':int(hist[m]),'cover_boxes':len(rs),
            'bounds_um':[min(r[1] for r in rs),min(r[2] for r in rs),max(r[3] for r in rs),max(r[4] for r in rs)]})
    assert summary['mask_summary']==masks and summary['retained_masks']==len(masks)
    total_classes+=int(mask.size);total_retained+=int(valid.sum());total_boxes+=len(boxes);total_masks+=len(masks)
    verified={'geometry':gid,'continuous_classes_verified':int(mask.size),'retained_classes_covered_once':int(valid.sum()),'retained_masks':len(masks),'closed_cover_boxes':len(boxes)}
    summaries.append(verified);print(verified,flush=True)
write(OUT/'geometry-verification.json',summaries)
inputs=[Path(__file__),SOURCE/'audit/plan.json',SOURCE/'audit/checks.json',SOURCE/'world-cog-inner-rectangles.json',SOURCE/'fixed-core-inner-rectangles.json',SOURCE/'geometry-domains.json',
    BASE/'plan.json',BASE/'checks.json']+[p for gid in range(8) for p in [BASE/f'geometry-{gid:02d}-{suffix}' for suffix in ['classes.npz','obstacles.json','cover.json','summary.json']]]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Each obstacle is an open rectangle with edges included among the exact coordinate cuts. Hence its membership is constant on every point/open-interval Cartesian class. A separate per-site two-dimensional event-count prefix sum reproduces every bit of every class. Every potentially feasible class (no fixed bit and at most1 cog bit) is covered exactly once by a recorded box; closure of an open class only adds possible points. Consequently the closed boxes are a continuous necessary cover for all original moving modes at full stock extent, conditional on the fixed39 and candidate cog poses. No site subset has yet been excluded.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'geometries':8,'site_bit_fields_independently_replayed':128,
    'continuous_classes_verified':total_classes,'retained_classes_covered_once':total_retained,'retained_geometry_masks':total_masks,'necessary_cover_boxes':total_boxes,
    'all_boundary_points_and_open_intervals_verified':True,'continuous_necessary_cover_certified':True,'full_physical_stock_domains':True,
    'fixed39_and_candidate_cog_pose_scope_only':True,'new_site_choices_excluded':0,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
