"""Independent direct-formula, complete source and identity readback of the shelf."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-top-insert-row-20261104';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';EDGE=ROOT/'output/h5-first57-edge-companion-v2-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for folder in [BASE,EDGE/'audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(EDGE/'audit/checks.json')['passed']
selection=load(EDGE/'selection.json');mode=load(EDGE/'family-modes.json')['insert'][0]
rectangle=load(EDGE/'mode-rectangles.json')['insert'][0]['rectangles'][0]['outward_offsets_grid']
bracket=[r for r in load(EDGE/'added-fixed-source-covers.json') if r['added_fixed_identity']==['bracket',0]]
assert len(bracket)==2
first=max(r['bounds_grid'][2] for r in bracket)-rectangle[0];pitch=rectangle[2]-rectangle[0]+23;y=mode['integer_lower_left_bounds'][1][1]
rows=load(BASE/'selected-top-inserts.json');assert len(rows)==6
for index,(r,copy) in enumerate(zip(rows,range(15,21))):
    xy=[first+index*pitch,y]
    assert r['identity']==['insert',copy] and r['mode']==0 and r['lower_left_grid']==xy
    assert all(lo<=xy[k]<=hi for k,(lo,hi) in enumerate(mode['integer_lower_left_bounds']))
    source={'part_id':'insert','copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]/100+mode['translation_from_lower_left'][k] for k in range(2)]}}
    assert r['source']==source
fixed=load(EDGE/'fixed33.json')+[r['source'] for r in rows];assert fixed==load(BASE/'fixed39.json') and len(fixed)==39
sites=load(PRE/'source-cog-sites.json');source=fixed+[r for i,r in enumerate(sites) if i not in selection['omitted_sites']]
assert source==load(BASE/'source52.json') and len(source)==52
spec=load(PRE/'plan.json');checked=audit(load(JOB),source,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in source])
assert checked==load(BASE/'source-checks.json') and checked['valid']
assert checked['same_sheet_pairs']==1326 and checked['stock_edges']==208 and checked['cutouts']==56 and checked['hole_vertices']==5722
remaining=[i for i in selection['remaining_moving12_identities'] if i[0]=='bracket'];assert remaining==[['bracket',i] for i in [2,3,4,5,6,9]]
assert load(BASE/'selection.json')=={'omitted_sites':selection['omitted_sites'],'remaining_candidate_sites':selection['remaining_candidate_sites'],'additional_empty_sites_required':1,
    'candidate_twelve_cog_subsets':13,'remaining_six_bracket_identities':remaining,'shelf_start_x_grid':first,'shelf_y_grid':y,'shelf_pitch_grid':pitch}
inventory=load(PRE/'inventory.json')
identities=[(r['part_id'],r['copy_index']) for r in fixed]+list(map(tuple,remaining))+list(map(tuple,inventory['required_cog12_identities']))
assert len(identities)==len(set(identities))==57 and set(identities)==set(map(tuple,inventory['first57_identities']))
assert set(identities).isdisjoint(map(tuple,inventory['short9_identities'])) and set(identities)|set(map(tuple,inventory['short9_identities']))==set(map(tuple,inventory['full66_identities']))
write(OUT/'original-source-checks.json',checked)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[BASE/n for n in ['plan.json','checks.json','selected-top-inserts.json','fixed39.json','source52.json','source-checks.json','selection.json']]+[EDGE/n for n in ['audit/plan.json','audit/checks.json','fixed33.json','selection.json','added-fixed-source-covers.json','family-modes.json','mode-rectangles.json']]+[PRE/n for n in ['plan.json','source-cog-sites.json','inventory.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'The six top insert positions are independently reconstructed from the exact audited left-bracket world cover, inward source-stock bounds and the0.23mm pitch rule. All52 source originals are read back, including1326 same-sheet pairs,208 stock edges and every cutout vertex. Removing one of the13 candidate cogs preserves source validity. Fixed39 plus12 required cog identities plus6 remaining bracket identities yields first57, disjoint from source-valid short9. This does not prove any six-bracket companion feasible; fresh necessary capacity bounds are still required before another call.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'source_valid52':True,'same_sheet_pairs':1326,'stock_edges':208,'cutouts':56,'hole_vertices':5722,
    'fixed_originals':39,'remaining_brackets':6,'candidate_twelve_cog_subsets':13,'full66_identity_partition_preserved':True,
    'necessary_bracket_capacity_pending':True,'source_valid66':False,'site_choices_excluded':0,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
