"""Direct top-edge insert row, with all thirteen remaining reference cogs."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-top-insert-row-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';EDGE=ROOT/'output/h5-first57-edge-companion-v2-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[PRE/n for n in ['plan.json','source-cog-sites.json','inventory.json']]+[EDGE/n for n in ['plan.json','audit/plan.json','audit/checks.json','fixed33.json','selection.json','added-fixed-source-covers.json','family-modes.json','mode-rectangles.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New direct positive top shelf. Keep the audited fixed33 and all13 remaining reference cogs, with sites4 and10 omitted. Place each of the six remaining original inserts horizontally at its inward full-stock upper Y anchor. Start X to the right of the upper-left fixed bracket using the maximum right edge of its exact saved-world outward cover including0.23mm expansion, and use the source-covering insert width plus0.23mm pitch. Independently re-read all source contours, pairs, stock edges and holes. This leaves six brackets only if the control is valid, and still requires fresh necessary capacity checks before any model; a failed shelf excludes no whole allocation.',
    'coordinate_units_per_mm':100,'insert_mode':0,'source_gap_grid':23,'preparation_cap_seconds':10,'maximum_process_seconds':20,'solver_calls':0,'native_calls':0})
assert load(EDGE/'audit/checks.json')['passed']
selection=load(EDGE/'selection.json');mode=load(EDGE/'family-modes.json')['insert'][0]
ir=load(EDGE/'mode-rectangles.json')['insert'][0]['rectangles'][0]['outward_offsets_grid']
left_bracket=[r for r in load(EDGE/'added-fixed-source-covers.json') if r['added_fixed_identity']==['bracket',0]]
assert len(left_bracket)==2
x0=max(r['bounds_grid'][2] for r in left_bracket)-ir[0]
y=mode['integer_lower_left_bounds'][1][1];pitch=ir[2]-ir[0]+23
identities=[i for i in selection['remaining_moving12_identities'] if i[0]=='insert'];assert identities==[['insert',i] for i in range(15,21)]
placed=[]
for index,identity in enumerate(identities):
    xy=[x0+index*pitch,y]
    assert all(lo<=xy[k]<=hi for k,(lo,hi) in enumerate(mode['integer_lower_left_bounds']))
    source={'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0',
            'transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],
                         'translation':[xy[k]/100+mode['translation_from_lower_left'][k] for k in range(2)]}}
    placed.append({'identity':identity,'mode':0,'lower_left_grid':xy,'source':source})
fixed=load(EDGE/'fixed33.json')+[r['source'] for r in placed]
sites=load(PRE/'source-cog-sites.json');control=fixed+[r for i,r in enumerate(sites) if i not in selection['omitted_sites']]
spec=load(PRE/'plan.json');check=audit(load(JOB),control,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in control])
write(OUT/'selected-top-inserts.json',placed);write(OUT/'fixed39.json',fixed);write(OUT/'source52.json',control);write(OUT/'source-checks.json',check)
write(OUT/'selection.json',{'omitted_sites':selection['omitted_sites'],'remaining_candidate_sites':selection['remaining_candidate_sites'],
    'additional_empty_sites_required':1,'candidate_twelve_cog_subsets':13,'remaining_six_bracket_identities':[i for i in selection['remaining_moving12_identities'] if i[0]=='bracket'],
    'shelf_start_x_grid':x0,'shelf_y_grid':y,'shelf_pitch_grid':pitch})
checks={'prepared':True,'seconds':time.perf_counter()-started,'source_valid52':check['valid'],'fixed_originals':39,'source_control_parts':len(control),
    'same_sheet_pairs':check['same_sheet_pairs'],'stock_edges':check['stock_edges'],'cutouts':check['cutouts'],'hole_vertices':check['hole_vertices'],
    'top_insert_lower_left_mm':[[v/100 for v in r['lower_left_grid']] for r in placed],'remaining_brackets':6,'candidate_twelve_cog_subsets':13,
    'independent_original_source_audit_pending':True,'necessary_bracket_capacity_pending':True,'source_valid66':False,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
assert check['valid'] and len(control)==52 and checks['seconds']<10
