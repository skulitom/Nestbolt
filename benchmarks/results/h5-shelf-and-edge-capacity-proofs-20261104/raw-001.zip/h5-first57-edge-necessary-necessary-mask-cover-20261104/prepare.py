"""Exhaustive continuous rectangle-arrangement masks, including every boundary class."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-necessary-necessary-rectangles-20261104';OUT=ROOT/'output/h5-first57-edge-necessary-necessary-mask-cover-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def deadline():assert time.perf_counter()-started<55,'Declared preparation cap reached; no capacity exclusion is certified.'
def classes(cuts):
    result=np.empty(2*len(cuts)-1,dtype=np.int64);result[::2]=2*cuts;result[1::2]=cuts[:-1]+cuts[1:];return result
assert load(BASE/'audit/checks.json')['passed']
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','world-cog-inner-rectangles.json','fixed-core-inner-rectangles.json','geometry-domains.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'For each necessary source geometry, form exact open forbidden anchor rectangles from every moving source-contained component and all975 cog plus35 fixed-core inner rectangles. Partition both axes at every obstacle boundary and stock-domain endpoint. The class matrix alternates every boundary point and every intervening open interval; integer doubled-coordinate samples classify entire continuous cells exactly, not a sampled placement grid. OR site bits over every open obstacle. Retain only cells with no fixed-core bit and at most one cog bit. Run-length rectangles cover every retained class; closing their boundaries only enlarges the necessary domain. Independently replay source containment and every mask using a different exact event/count construction before negative conclusions.',
    'coordinate_units_per_mm':1000,'samples_units_per_mm':2000,'fixed_core_mask_bit':15,'required_empty_cog_sites':1,
    'preparation_cap_seconds':55,'maximum_process_seconds':75,'maximum_cells_per_geometry':40000000,
    'cover_row_fields':['mask','left_um','bottom_um','right_um','top_um','first_x_class','first_y_class','last_x_class','last_y_class'],
    'solver_calls':0,'site_choices_excluded':0})
obstacle_sources=load(BASE/'world-cog-inner-rectangles.json')+load(BASE/'fixed-core-inner-rectangles.json')
geometries=load(BASE/'geometry-domains.json')
popcount=np.array([i.bit_count() for i in range(65536)],dtype=np.uint8)
summaries=[]
for g in geometries:
    gid=g['geometry'];d=g['anchor_domain_um'];obstacles=[]
    for source_index,source in enumerate(obstacle_sources):
        u,v,w,z=source['bounds_um']
        for component,(a,b,c,e) in enumerate(g['inner_rectangles_um']):
            rect=[u-c,v-e,w-a,z-b]
            if rect[0]>=d[2] or rect[2]<=d[0] or rect[1]>=d[3] or rect[3]<=d[1]:continue
            obstacles.append({'source_rectangle':source_index,'moving_component':component,'site_bit':source['site_bit'],'bounds_um':rect})
    xs=np.array(sorted({d[0],d[2]}|{x for o in obstacles for x in [o['bounds_um'][0],o['bounds_um'][2]] if d[0]<=x<=d[2]}),dtype=np.int64)
    ys=np.array(sorted({d[1],d[3]}|{y for o in obstacles for y in [o['bounds_um'][1],o['bounds_um'][3]] if d[1]<=y<=d[3]}),dtype=np.int64)
    xx,yy=classes(xs),classes(ys);assert len(xx)*len(yy)<=40000000
    mask=np.zeros((len(yy),len(xx)),dtype=np.uint16)
    for index,o in enumerate(obstacles):
        a,b,c,e=o['bounds_um']
        xa=int(np.searchsorted(xx,2*a,side='right'));xb=int(np.searchsorted(xx,2*c,side='left'))
        ya=int(np.searchsorted(yy,2*b,side='right'));yb=int(np.searchsorted(yy,2*e,side='left'))
        mask[ya:yb,xa:xb]|=np.uint16(1<<o['site_bit'])
        if index%128==0:deadline()
    np.savez_compressed(OUT/f'geometry-{gid:02d}-classes.npz',xcuts_um=xs,ycuts_um=ys,mask=mask)
    boxes=[];active={};counts={}
    def close(key,span):
        m,xa,xb=key;ya,yb=span
        boxes.append([m,int(xs[xa//2]),int(ys[ya//2]),int(xs[(xb+1)//2]),int(ys[(yb+1)//2]),xa,ya,xb,yb])
    for yi,row in enumerate(mask):
        labels=np.where(((row&32768)==0)&(popcount[row]<=1),row,np.uint16(65535))
        starts=np.r_[0,np.flatnonzero(labels[1:]!=labels[:-1])+1]
        ends=np.r_[starts[1:]-1,len(labels)-1]
        current={}
        for xa,xb in zip(starts.tolist(),ends.tolist()):
            m=int(labels[xa])
            if m==65535:continue
            key=(m,xa,xb);current[key]=[active[key][0] if key in active else yi,yi]
            counts[m]=counts.get(m,0)+xb-xa+1
        for key,span in active.items():
            if key not in current:close(key,span)
        active=current
        if yi%128==0:deadline()
    for key,span in active.items():close(key,span)
    boxes.sort()
    masks=[]
    for m in sorted(counts):
        selected=[r for r in boxes if r[0]==m]
        masks.append({'mask':m,'required_empty_sites':[i for i in range(15) if m&(1<<i)],'class_count':counts[m],'cover_boxes':len(selected),
            'bounds_um':[min(r[1] for r in selected),min(r[2] for r in selected),max(r[3] for r in selected),max(r[4] for r in selected)]})
    write(OUT/f'geometry-{gid:02d}-obstacles.json',obstacles);write(OUT/f'geometry-{gid:02d}-cover.json',boxes)
    summary={'geometry':gid,'obstacle_rectangles':len(obstacles),'x_boundary_points':len(xs),'y_boundary_points':len(ys),
        'x_classes':len(xx),'y_classes':len(yy),'all_classes':int(mask.size),'retained_classes':sum(counts.values()),
        'retained_masks':len(masks),'cover_boxes':len(boxes),'mask_summary':masks}
    write(OUT/f'geometry-{gid:02d}-summary.json',summary);summaries.append(summary)
    print({k:v for k,v in summary.items() if k!='mask_summary'},flush=True);deadline()
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'geometries':len(summaries),
    'all_continuous_classes':sum(s['all_classes'] for s in summaries),'retained_classes':sum(s['retained_classes'] for s in summaries),
    'retained_masks':sum(s['retained_masks'] for s in summaries),'cover_boxes':sum(s['cover_boxes'] for s in summaries),
    'boundaries_and_isolated_points_preserved':True,'independent_mask_and_cover_audit_pending':True,
    'site_choices_excluded':0,'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
