"""Bind the audited fixed33 bodies to the complete original bracket/insert modes."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-edge-combined-sources-20261104'
FIXED=ROOT/'output/h5-first57-edge-necessary-necessary-rectangles-20261104'
OLD=ROOT/'output/h5-first57-necessary-rectangles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for base in [FIXED,OLD]:
    assert load(base/'audit/checks.json')['passed']
    for p,h in load(base/'audit/plan.json')['inputs'].items():assert digest(ROOT/p)==h
inputs=[Path(__file__)]+[FIXED/p for p in ['audit/plan.json','audit/checks.json','fixed-core-inner-rectangles.json','world-cog-inner-rectangles.json','selection.json']]+[OLD/p for p in ['audit/plan.json','audit/checks.json','geometry-domains.json','moving-source-inner-rectangles.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Exact unchanged copies of independently certified fixed33 source-contained bodies and every original bracket/insert necessary mode. Their disjoint fields can be composed without a geometric approximation. New insert anchor cover remains necessary.',
    'preparation_cap_seconds':10,'maximum_process_seconds':20,'solver_calls':0})
for base,names in [(FIXED,['fixed-core-inner-rectangles.json','world-cog-inner-rectangles.json','selection.json']),(OLD,['geometry-domains.json','moving-source-inner-rectangles.json'])]:
    for n in names:shutil.copyfile(base/n,OUT/n);assert digest(base/n)==digest(OUT/n)
elapsed=time.perf_counter()-started;assert elapsed<10
checks={'prepared':True,'seconds':elapsed,'fixed_originals':33,'source_modes':12,'geometries':10,'independent_composition_audit_pending':True,'solver_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
