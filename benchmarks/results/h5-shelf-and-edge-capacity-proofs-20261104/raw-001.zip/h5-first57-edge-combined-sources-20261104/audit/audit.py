from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-edge-combined-sources-20261104';OUT=BASE/'audit'
FIXED=ROOT/'output/h5-first57-edge-necessary-necessary-rectangles-20261104';OLD=ROOT/'output/h5-first57-necessary-rectangles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,FIXED/'audit',OLD/'audit']:
    for p,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
assert load(FIXED/'audit/checks.json')['passed'] and load(OLD/'audit/checks.json')['passed']
names=[]
for base,files in [(FIXED,['fixed-core-inner-rectangles.json','world-cog-inner-rectangles.json','selection.json']),(OLD,['geometry-domains.json','moving-source-inner-rectangles.json'])]:
    for n in files:assert digest(base/n)==digest(BASE/n);names.extend([base/n,BASE/n])
assert load(BASE/'geometry-domains.json')[:8]==load(FIXED/'geometry-domains.json')
inputs=[Path(__file__),BASE/'plan.json',BASE/'checks.json',FIXED/'audit/plan.json',FIXED/'audit/checks.json',OLD/'audit/plan.json',OLD/'audit/checks.json']+names
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'proof':'Every consumed byte equals its independently audited original; all12 modes are present, and the eight bracket geometry domains equal the previously covered set. New insert cover uses geometries8 and9 only.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'unchanged_source_files_verified':5,'legal_modes':12,'fixed_originals':33,'geometries':10,'site_choices_excluded':0,'solver_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
