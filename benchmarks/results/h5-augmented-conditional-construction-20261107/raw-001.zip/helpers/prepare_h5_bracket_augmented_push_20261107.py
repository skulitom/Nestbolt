"""Bind the next normal main checkpoint push to the newly completed CI."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/push_h5_bracket_depth_checkpoints_20261107.py').read_text(encoding='utf-8')
changes={
    'h5-bracket-depth-main-sync-20261107':'h5-bracket-augmented-main-sync-20261107',
    'c7e4b305d1a52bad8449bab8070fe2b82028d084':'cbc49d2cfe1eaec6b750034e42325f8f75dabd0d',
    '42369490349':'42372151646',
    "prefixes=('benchmarks/results/h5-weighted-relocated-construction-20261107','benchmarks/results/h5-bracket-collision-depth-preflight-20261107')":"prefixes=('benchmarks/results/h5-bracket-augmented-construction-20261107',)",
    "['h5-weighted-relocated-construction-20261107','h5-bracket-collision-depth-preflight-20261107']":"['h5-bracket-augmented-construction-20261107']",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
with (ROOT/'output/push_h5_bracket_augmented_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
