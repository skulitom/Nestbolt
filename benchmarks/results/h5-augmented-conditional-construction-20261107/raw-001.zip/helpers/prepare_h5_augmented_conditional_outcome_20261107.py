"""Bind the existing read-only outcome audit to the new closed candidate."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/diagnose_h5_bracket_augmented_outcome_20261107.py').read_text(encoding='utf-8')
changes={
    "BASE=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'outcome-diagnostic'":"BASE=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'outcome-diagnostic'",
    "'search/model.json','objective-identity.json'":"'search/model.json'",
    "[B/'regions.json',R/'response-audit/checks.json',W/'response-audit/checks.json']":"[A/'objective-identity.json',A/'response-audit/checks.json',B/'regions.json',R/'response-audit/checks.json',W/'response-audit/checks.json']",
    "load(BASE/'objective-identity.json')":"load(A/'objective-identity.json')",
    "[('prior_weighted',W),('prior_conditional_relocation',R)]":"[('prior_weighted',W),('prior_conditional_relocation',R),('prior_augmented',A)]",
    "prior['source_pair_failures']":"prior.get('source_pair_failures',prior.get('best_original_pair_failures'))",
    "prior['original_overlap_mm2']":"prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2'))",
}
for a,b in changes.items():assert a in s,a;s=s.replace(a,b)
needle="response=load(BASE/'search/response.json');model="
assert needle in s;s=s.replace(needle,"response=load(BASE/'search/response.json');assert all(v['auxiliary_bracket_depth_mm2']==0 for v in response['source_readbacks'].values());model=")
with (ROOT/'output/diagnose_h5_augmented_conditional_outcome_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
