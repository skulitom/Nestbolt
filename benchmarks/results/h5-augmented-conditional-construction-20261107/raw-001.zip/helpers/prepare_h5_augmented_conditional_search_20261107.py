"""Bind one finite call and complete replay to the newly selected source model."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=ROOT/'output/run_h5_bracket_augmented_search_20261107.py';new=ROOT/'output/run_h5_augmented_conditional_search_20261107.py'
s=old.read_text(encoding='utf-8')
changes={
    "BASE=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'search'":"BASE=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'search'",
    "load(BASE/'model.json')":"load(BASE/'selected-model.json')",
    "load(BASE/'objective-identity.json')":"load(A/'objective-identity.json')",
    "load(BASE/'initial-state.json')":"load(BASE/'selected-state.json')",
    "load(BASE/'library.json')":"load(A/'library.json')",
    "load(BASE/'audit-v2/closure-controls.json')['new_objective_key']":"load(BASE/'selected-state.json')['key']",
    "load(BASE/'closed-prior-problems.json')":"load(BASE/'closed-problems.json')",
    "digest(BASE/'model.json')":"digest(BASE/'selected-model.json')",
    "load(BASE/'audit-v2/optimizer-controls.json')":"load(A/'audit-v2/optimizer-controls.json')",
    "load(BASE/'audit-v2/checks.json')":"load(BASE/'audit/checks.json')",
    "'optimizer_slice_seconds':36.":"'optimizer_slice_seconds':28.",
    "One separately identified augmented objective from the unchanged original W initializer, same legal mode vector and original frozen weights. No mode search, weight update or optimized ancestor seed. At most one36second L-BFGS-B call":"One separately identified augmented objective from the independently selected source-only conditional joint proposal, retaining original W weights. The selector considers6396nominal fixed-grid centers and2854complete proposals; its entire preparation is charged. No old optimized state or earlier computed selector output is consumed. No runtime mode search or weight update. At most one28second L-BFGS-B call",
}
for a,b in changes.items():assert a in s,a;s=s.replace(a,b)
a="inputs=[Path(__file__),JOB]+[BASE/n for n in ['plan.json','plan-v2.json','model.json','objective-identity.json','initial-state.json','library.json','closed-prior-problems.json','runtime-bindings.json','audit-v2/plan.json','audit-v2/checks.json','audit-v2/closure-controls.json','audit-v2/optimizer-controls.json']]+[B/'regions.json']+[ROOT/'output'/n for n in ['h5_bracket_augmented_objective_20261107.py','h5_bracket_augmented_readback_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py','h5_checked_affinity_20261107.py']]"
b="inputs=[Path(__file__),JOB]+[BASE/n for n in ['plan.json','checks.json','selected-model.json','selected-state.json','selection.json','closed-problems.json','runtime-bindings.json','audit/plan.json','audit/checks.json','audit/selected-model-controls.json','audit/selection-replay/checks.json']]+[A/n for n in ['library.json','objective-identity.json','initial-state.json','audit-v2/optimizer-controls.json']]+[B/'regions.json']+[ROOT/'output'/n for n in ['h5_bracket_augmented_objective_20261107.py','h5_bracket_augmented_readback_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py','h5_checked_affinity_20261107.py']]"
assert a in s;s=s.replace(a,b)
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
old_audit=ROOT/'output/audit_h5_bracket_augmented_response_20261107.py';new_audit=ROOT/'output/audit_h5_augmented_conditional_response_20261107.py'
s=old_audit.read_text(encoding='utf-8')
changes={
    "BASE=ROOT/'output/h5-bracket-augmented-model-20261107';S=BASE/'search'":"BASE=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';S=BASE/'search'",
    "load(BASE/'objective-identity.json')":"load(A/'objective-identity.json')",
    "load(BASE/'initial-state.json')":"load(BASE/'selected-state.json')",
    "load(BASE/'library.json')":"load(A/'library.json')",
    "load(BASE/'model.json')":"load(BASE/'selected-model.json')",
    "load(BASE/'audit-v2/closure-controls.json')['new_objective_key']":"load(BASE/'selected-state.json')['key']",
    "load(BASE/'closed-prior-problems.json')":"load(BASE/'closed-problems.json')",
    "load(BASE/'audit-v2/optimizer-controls.json')":"load(A/'audit-v2/optimizer-controls.json')",
    "load(BASE/'audit-v2/checks.json')":"load(BASE/'audit/checks.json')",
    "opened['allocated_seconds']<=36":"opened['allocated_seconds']<=28",
    "plan['optimizer_slice_seconds']==36":"plan['optimizer_slice_seconds']==28",
    "'prior_closed_keys_preserved':7":"'prior_closed_keys_preserved':8",
}
for a,b in changes.items():assert a in s,a;s=s.replace(a,b)
a="[BASE/n for n in ['plan.json','plan-v2.json','objective-identity.json','initial-state.json','library.json','closed-prior-problems.json','audit-v2/checks.json','audit-v2/closure-controls.json','audit-v2/optimizer-controls.json']]"
b="[BASE/n for n in ['plan.json','selected-model.json','selected-state.json','selection.json','closed-problems.json','audit/checks.json','audit/selection-replay/checks.json']]+[A/n for n in ['library.json','objective-identity.json','initial-state.json','audit-v2/optimizer-controls.json']]"
assert a in s;s=s.replace(a,b)
with new_audit.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'search_script_prepared':str(new),'response_audit_prepared':str(new_audit),'call_not_opened':True,'requires_complete_passing_selection_audit':True})
