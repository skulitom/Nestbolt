"""Preserve the complete augmented selector and its sole closed construction."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-augmented-conditional-construction-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-augmented-conditional-neighbors-20261107';F=BASE/'response-audit';D=BASE/'audit'",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-bracket-augmented-construction-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==1 and front['best_original_pair_failures']==55 and not front['source_valid66']",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/n for n in ['h5-augmented-conditional-neighbors-preparation-process-20261107','h5-augmented-conditional-neighbors-audit-process-20261107','h5-augmented-conditional-neighbors-response-audit-process-20261107','h5-bracket-augmented-main-sync-20261107']]",
    "['*h5*mixed*mode*20261107.py']":"['*h5*augmented*20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_augmented_conditional_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(D/'checks.json','model-audit.json'),(D/'selection-replay/checks.json','selection-replay.json'),(D/'selection-replay/near-tie-rankings.json','near-tie-rankings.json'),(D/'selected-model-controls.json','selected-model-controls.json'),(BASE/'selection.json','selection.json'),(F/'checks.json','response-audit.json'),(F/'winner-reconciliation.json','winner-reconciliation.json'),(F/'original-source-checks.json','source-failures.json'),(BASE/'search/process.json','closed-search-process.json'),(BASE/'search/closed-problem.json','closed-problem.json'),(BASE/'outcome-diagnostic/checks.json','outcome-diagnostic.json'),(BASE/'outcome-diagnostic/family-failures.json','family-failures.json'),(BASE/'outcome-diagnostic/prior-comparisons.json','prior-comparisons.json'),(BASE/'main-ci-at-seal.json','main-ci-at-seal.json'),(ROOT/'output/h5-bracket-augmented-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for stage in ['preparation','audit','response-audit']:copies.append((ROOT/'output'/f'h5-augmented-conditional-neighbors-{stage}-process-20261107'/'process.json',stage+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{
    'status':'adaptive_augmented_pipeline_preflight_required',
    'finding':'Two fixed-weight augmented calls are now closed. The current conditional source choice yields worse original overlap and more failed pairs than the previous augmented call. The remaining collisions concentrate in cog/companion pairs; none of the 55 positive area terms is flat in the available pair gradient, and all bracket auxiliary terms are zero. This is a local observation, not a feasibility or impossibility proof.',
    'proposal':'Reconcile the older area-only adaptive weighted pipeline and its full replay before designing a separately versioned augmented pipeline. Reuse only the original unoptimized source trial/proposal pool, expand the closed ledger to all nine keys, and independently select a new admissible joint that improves the original source baseline and best admissible single. Reconstruct from original source coordinates plus that raw proposal. The current or any previous optimized winner must not seed the successor. No new model, selected state, search contract or call exists yet.',
    'requirements':[
        'Preserve all 528 original/clearance terms, 15 coefficient-1 auxiliary bracket terms, all 81 coordinates and legal hard domains. Keep the original full66 acceptance gate and all three winner streams.',
        'Any bounded positive weight update must use a separately frozen source-area rule. Independently audit every updated weight and complete dynamic model. All conditional center and joint scores must include the full augmented objective with mutual pairs counted once.',
        'Version and test deadline-aware selector stop handling before an adaptive call. Preserve partial trials and do not optimize a partially ranked choice. The current selector has no deadline support.',
        'Freeze the complete finite pipeline before measurements. A possible ceiling is three short slices within the existing 60/90-second preparation-inclusive limits with a six-second source reserve; those timings are a proposal, not an authorized reset or an opened contract.',
        'Charge the full 16.9743796994444 seconds of consumed original source/model/selector preparation, plus every additional consumed stage. Do not use old computed selections or optimized ancestors for free.',
        'Both augmented keys and seven prior area-only weighted keys remain permanently closed. Coordinates alone do not distinguish a new objective/physical-mode/weight identity. No retries, continuations, reseeding or native validation without a valid full66 witness.',
        'If no eligible source joint passes all prerequisites, open no optimizer. Preserve the source contact derivative limitations and every prior failed or timed-out result.'
    ],
    'source_only_preparation_seconds_before_new_work':16.9743796994444,'closed_augmented_problems':2,'closed_prior_weighted_problems':7,
    'new_pipeline_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False
})
ci=load(BASE/'main-ci-at-seal.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
report=f'''# Augmented conditional construction — 2026-11-07

The complete source selector and one bounded search pass independent replay.
The three winner streams choose different candidates, but each still fails
**55 source-pair checks**. The best original-overlap candidate has
**36,097.586688 mm²** overlap, worse than the preceding augmented result's
33,707.125558 mm² and 44 failed pairs. No packing improvement, full-layout
validity or allocation exclusion is established. H2/H5 remain open at **60%**.

## Complete source selection

The model retains 33 movers, 81 coordinates, all 528 weighted original/clearance
area pairs, 15 unweighted bracket-depth terms at coefficient 1, and every hard
stock/fixed-part domain. Original source coordinates, nonunit source weights
and legal modes are unchanged. Cogs retain their continuous angles. Earlier
joint/relocated selector modules are code references only; their computed
scores, centers and optimized states are not consumed.

Every changed physical bracket/insert mode is tested on the frozen 9-by-9
source grid plus its clamped center against all 32 other owners. The
[independent preflight]({NAME}/model-audit.json) reconstructs **6,396 nominal
center trials** (6,364 unique centers and 32 exact aliases), all 147 legal
mode/domain bindings and **2,854 full proposals**: current, 78 singles and
2,775 joints. Joint families comprise 1,215 bracket/bracket, 1,296
bracket/insert and 264 insert/insert choices. Each mutual area and auxiliary
interaction is replaced exactly once.

[All 9,250 full scores replay]({NAME}/selection-replay.json) using independently
reconstructed source polygons, scalar binary64 depth projections and an
additional exact-rational boundary check. Maximum component-score and scalar
reduction errors are 1.165e-10 mm²; maximum rational auxiliary error is
3.638e-12 mm². The ranking policy and 1e-6 score-verification tolerance were
frozen before measurements. [No numerical ranking disagrees]({NAME}/near-tie-rankings.json),
so no tolerance fallback is used. Eight prior closed keys are retained;
one current proposal is excluded by that ledger.

The [chosen joint]({NAME}/selection.json) changes original inserts 10 and 20
(owners 16 and 17) to physical mode 2, with source centers
(1094.2374985, 2620.04999925) and (577.88125075, 2336.6250015).
Its augmented score is **216,065.491335 mm²**, compared with
229,308.162672 for the best single and 244,577.060782 for the current source
state. The joint improves the best single by 13,242.671337 mm².
[Selected-model controls]({NAME}/selected-model-controls.json) verify all
81 coordinates and 148 directed scalar gradient terms, with maximum gradient
error 5.685e-14 mm. The selected initializer still has 75,955.600891 mm²
original overlap; an improved weighted score is not a valid packing.
Existing contact/nearest-feature gradient conventions and their nonsmooth
limitations are retained.

The full selector preparation wrapper takes **5.285699 s**, bringing consumed
source preparation to **16.974380 s**. The independent exhaustive audit wrapper
takes 196.090574 s under its separate frozen 600 s validation limit.
All monitored descendants close within the 2 GiB memory bound.

## Sole closed search and complete response replay

One L-BFGS-B call uses the selected source joint with modes and weights held
fixed. Its 28 s slice returns at **28.064511 s**; the **0.064511 s overrun**
is preserved. Preparation-inclusive algorithm/shared totals are
**48.649513/48.735274 s**, within the frozen 60/90 s overall limits.
[The search process tree closes]({NAME}/closed-search-process.json), with
five processes and 101,482,496 bytes peak aggregate committed memory.

[Response replay]({NAME}/response-audit.json) verifies all **310 evaluation
records**, including 309 optimizer evaluations, and all **274 retained
improving points**. Independent full-score error is at most 2.329e-10 mm²,
original-area error 5.821e-11 mm² and winner scalar-gradient error
1.049e-13 mm. [The three distinct winner streams]({NAME}/winner-reconciliation.json)
are all retained:

| Winner metric | Evaluation | Original overlap (mm²) | Unweighted area sum (mm²) | Augmented score (mm²) | Failed source pairs |
| --- | ---: | ---: | ---: | ---: | ---: |
| Augmented | 309 | 36,112.738571 | 73,538.912801 | 89,201.639437 | 55 |
| Original overlap | 290 | 36,097.586688 | 73,538.314646 | 89,275.475931 | 55 |
| Unweighted area | 302 | 36,105.023349 | 73,528.687948 | 89,227.349054 | 55 |

Each winner receives a full 66-part original-source readback covering 1,380
same-sheet pairs, 264 stock edges, 90 holes and 10,026 hole vertices. Fixed-part
and stock checks pass in all three; none is valid. The independent response
audit wrapper takes 32.959490 s and closes all descendants. The
[new key is permanently closed]({NAME}/closed-problem.json), alongside the
earlier augmented key and seven area-only weighted keys. No native call follows.

## Remaining failures and next preflight

The [best-original source check]({NAME}/source-failures.json) has 52 positive
intersections and three clearance-only failures. Its [family composition]({NAME}/family-failures.json)
is:

| Families | Failing pairs | Original overlap (mm²) |
| --- | ---: | ---: |
| Bracket / insert | 6 | 5,243.233725 |
| Bracket / cog | 9 | 6,092.334134 |
| Insert / insert | 3 | 3.048438 |
| Cog / insert | 20 | 16,895.464987 |
| Cog / cog | 17 | 7,863.505404 |

The [read-only diagnostic]({NAME}/outcome-diagnostic.json) finds no flat
available pair gradient among 55 positive original/clearance area terms.
There is no bracket/bracket failure and auxiliary bracket loss is zero.
Four cogs have negative-gradient descent blocked at their lower-y bounds.
No flat-pair probe is triggered and no candidate changes.
[Comparisons]({NAME}/prior-comparisons.json) preserve the worse result against
the preceding augmented and earlier weighted constructions.

[The next preflight]({NAME}/next-step.json) will assess a bounded adaptive
augmented pipeline after reconciling the older area-only adaptive implementation.
It must start from an independently selected, admissible original-source
proposal; test deadline-aware selector stops; audit every weight and dynamic
model; retain full preparation accounting and freeze its finite contract
before any search. No successor model, pipeline or call exists yet. Current
and prior optimized winners are not successor initializers. Four earlier
fixed arrangements and all 440 allocation candidates remain unresolved.

The previous checkpoint reached main **193660c4** after all six preceding
checks passed, preserving 52 protected files. [The ordinary atomic push receipt]({NAME}/prior-main-push-receipt.json)
is retained. [At sealing]({NAME}/main-ci-at-seal.json), {success} jobs on its
fresh CI run pass and {live} remains live. This checkpoint awaits the ordinary
push gate. Product code, README claims and releases are unchanged.

[Archive verification]({NAME}/archive-checks.json),
[manifest]({NAME}/raw-manifest.json), [source bindings]({NAME}/source-bindings.json),
[historical references]({NAME}/external-evidence.json) and
[runtime pins]({NAME}/runtime-bindings.json) preserve the complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 augmented conditional construction:** [complete selection and response audits]({link}) independently replay all 6,396 center trials and 2,854 full augmented proposals, with zero ranking disagreements and maximum score error 1.165e-10 mm². The original-source joint changes inserts 10 and 20 to mode 2 and improves the best single by 13,242.671337 mm². It retains all 528 weighted area pairs, 15 coefficient-1 bracket terms, 81 coordinates and legal hard domains. One new key closes after 309 optimizer evaluations; all 310 records, 274 retained points and three distinct winner streams replay. Every winner fails 55 source pairs. The best original-overlap candidate has 36,097.586688 mm² overlap, worse than the preceding augmented result in both overlap and failed pairs. Fixed-part and stock checks pass. Complete preparation is 16.974380 s; algorithm/shared totals are 48.649513/48.735274 s, with every process closed and the 0.064511 s slice overrun preserved. A read-only diagnostic finds no bracket/bracket failure or flat available gradient among 55 positive area terms; four cogs have lower-y descent blocked by hard bounds. Next preflight a bounded adaptive augmented pipeline, with deadline-aware selector controls, independent weight/model readback and a new admissible original-source initializer. No successor is prepared. Both augmented keys and all seven older weighted keys remain closed. No native call or allocation exclusion follows. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. The prior checkpoint reached main 193660c4, preserving 52 files; five fresh CI jobs pass and Windows native CI remains live at sealing. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [augmented conditional construction](../benchmarks/results/{NAME}.md).
Independent replay verifies all 6,396 center trials and 2,854 full proposals,
with no ranking disagreements. The original-source joint improves the best
single augmented score while preserving all 528 area pairs, 15 bracket-depth
terms, 81 coordinates and legal hard domains. One new key closes after 309
optimizer evaluations. All 310 records, 274 retained points and three distinct
winner streams replay; each winner still fails 55 source pairs. The best
original overlap is 36,097.586688 mm², worse than the preceding augmented
result in both overlap and failing pairs. Fixed-part and stock checks pass.
Complete preparation is 16.974380 s; algorithm/shared totals are
48.649513/48.735274 s, with every process closed and the slice overrun retained.
No bracket/bracket failure or flat available pair gradient remains, but four
cogs have lower-y descent blocked by hard bounds. Next preflight a bounded
adaptive augmented pipeline with deadline-aware selectors, independent
weight/model readback and a new admissible original-source initializer.
No successor is prepared; both augmented keys and all seven older weighted
keys stay closed. Four earlier arrangements and 440 allocations remain;
H2/H5 stay at 60%. The previous checkpoint reached main 193660c4, preserving
52 files. Five fresh CI jobs pass and Windows native CI remains live at sealing.
This checkpoint awaits the ordinary push gate. Product code, README and
releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
