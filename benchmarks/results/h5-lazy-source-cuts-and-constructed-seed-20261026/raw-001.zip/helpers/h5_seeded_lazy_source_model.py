"""A verified non-cog source arrangement supplies hints; no part is fixed or omitted."""
from pathlib import Path
import json
from ortools.sat import cp_model_pb2
from h5_lazy_source_model import build as base_build
from h5_lazy_source_model_audit import verify as base_verify
ROOT=Path(__file__).resolve().parents[1]
def hints(domains,mapping):
    anchors=json.loads((ROOT/'output/h5-constructed-necessary-source-seed-20261026/anchors-um.json').read_bytes());result=[]
    for i,d in enumerate(domains):
        if d['family']=='cog':continue
        result.extend((v,anchors[i][k]) for k,v in enumerate(mapping['coordinate_indices'][i]))
    assert len(result)==90 and len({i for i,v in result})==90
    return result
def build(domains,pairs,rectangles,groups,pair_indices):
    model,mapping=base_build(domains,pairs,rectangles,groups,pair_indices)
    for index,value in hints(domains,mapping):model.add_hint(model.get_int_var_from_proto_index(index),value)
    assert model.validate()==''
    return model,mapping
def verify(proto,domains,pairs,rectangles,groups,pair_indices,mapping):
    assert list(zip(proto.solution_hint.vars,proto.solution_hint.values))==hints(domains,mapping)
    unhinted=cp_model_pb2.CpModelProto();unhinted.CopyFrom(proto);unhinted.ClearField('solution_hint');result=base_verify(unhinted,domains,pairs,rectangles,groups,pair_indices,mapping);result.pop('no_objective_or_hints');return {**result,'no_objective':True,'partial_coordinate_hints_verified':90,'cog_coordinate_hints':0,'hints_do_not_fix_any_coordinate':True}
