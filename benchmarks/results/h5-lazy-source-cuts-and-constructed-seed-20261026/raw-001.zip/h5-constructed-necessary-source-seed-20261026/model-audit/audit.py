"""Verify the constructed witness against all180 serialized necessary constraints."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_lazy_source_model_audit import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-constructed-necessary-source-seed-20261026';NECESSARY=ROOT/'output/h5-lazy-source-cuts-20261026';GEO=ROOT/'output/h5-global-source-cells-20261026';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();model=cp_model_pb2.CpModelProto();model.ParseFromString((NECESSARY/'initial-model.pb').read_bytes());mapping=load(NECESSARY/'initial-mapping.json');verify(model,load(GEO/'domains.json'),load(GEO/'pairs.json'),load(GEO/'inner-rectangles/rectangles.json'),load(GEO/'inner-rectangles/identical-source-groups.json'),[],mapping);anchors=load(BASE/'anchors-um.json');sol=[v for xy in anchors for v in xy];assert len(sol)==len(model.variables)==114
for v,value in zip(model.variables,sol):assert any(lo<=value<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]))
def expr(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
intervals={i:(expr(c.interval.start),expr(c.interval.end),expr(c.interval.size)) for i,c in enumerate(model.constraints) if c.WhichOneof('constraint')=='interval'};rect_pairs=events_checked=0
for i,c in enumerate(model.constraints):
    assert not c.enforcement_literal;kind=c.WhichOneof('constraint')
    if kind=='linear':value=sum(k*sol[v] for v,k in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=value<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
    elif kind=='interval':a,b,s=intervals[i];assert a+s==b and s>0
    elif kind=='no_overlap_2d':
        rects=[(*intervals[x][:2],*intervals[y][:2]) for x,y in zip(c.no_overlap_2d.x_intervals,c.no_overlap_2d.y_intervals)]
        for a,b in combinations(rects,2):assert a[1]<=b[0] or b[1]<=a[0] or a[3]<=b[2] or b[3]<=a[2];rect_pairs+=1
    elif kind=='cumulative':
        events={}
        for ix,dem in zip(c.cumulative.intervals,c.cumulative.demands):a,b,s=intervals[ix];d=expr(dem);events[a]=events.get(a,0)+d;events[b]=events.get(b,0)-d
        amount=0;capacity=expr(c.cumulative.capacity)
        for point in sorted(events):amount+=events[point];assert 0<=amount<=capacity;events_checked+=1
    else:raise AssertionError(kind)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'necessary_model_sha256':digest(NECESSARY/'initial-model.pb'),'all114_coordinates_in_domain':True,'all180_serialized_constraints_satisfied':True,'inner_rectangle_pairs_checked':rect_pairs,'cumulative_events_checked':events_checked,'source_copy_orders_satisfied':47,'actual_source_validity_not_implied':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
