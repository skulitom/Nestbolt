"""Construct all source non-cogs and an explicit complete necessary-rectangle witness."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,math,shutil,time
from shapely.geometry import box
from shapely.affinity import affine_transform
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-global-source-cells-20261026';SOURCE=ROOT/'output/h5-legacy57-sliding-source-20261026';OUT=ROOT/'output/h5-constructed-necessary-source-seed-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');start=time.perf_counter();ds=load(GEO/'domains.json');modes=load(SOURCE/'modes.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');inputs=[GEO/'domains.json',GEO/'fixed-short-placements.json',GEO/'inner-rectangles/rectangles.json',GEO/'inner-rectangles/identical-source-groups.json',SOURCE/'modes.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-lazy-source-cuts-20261026/result-audit/checks.json'];assert load(inputs[-1])['status']=='UNKNOWN'
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_seconds':30,'solver_calls':0,'method':'Construct an explicit witness for the closed114-coordinate necessary model without repeating its search. Keep original modes/counts:12 turned/6 wide frames,4 zero-degree/2 half-turn/2 turned brackets,13 vertical/6 horizontal inserts,12 cogs in their saved source modes. Put one insert in the exterior concave notch of each bracket (not a hole); place3 other vertical inserts beside the wide frames and8 above the brackets. Place all12 cog inner squares in6 columns by2 rows within full-source stock bounds. Assign equivalent copies by ascendingY/X so the existing symmetry constraints hold. Directly verify all180 necessary constraints and separately read all66 original source shapes. The expected54-source partial contains every non-cog plus the3 short cogs; the other12 original cogs remain present in the complete candidate and mandatory in future work. Their small necessary squares are not full source cog footprints. No full source fit, native call or quality gain is assumed.'})
low=6.525;gap=.225;slots={}
def add(mode,anchor):slots.setdefault(mode,[]).append([float(anchor[0]),float(anchor[1])])
for r in range(3):
    for c in range(4):add(15,[low+c*350.225,low+r*450.225])
for r in range(2):
    for c in range(3):add(14,[low+c*450.225,1357.2+r*350.225])
brackets=[]
for c in range(4):brackets.append((4,[low+c*300.225,2057.65]))
for mode,x in [(6,low),(6,306.75),(7,606.975),(9,857.2)]:brackets.append((mode,[x,2307.875]))
motifs=[]
for mode,anchor in brackets:
    add(mode,anchor);m=modes[mode];c,s=math.cos(m['angle']),math.sin(m['angle']);sgn=-1 if m['mirrored'] else 1;notch=affine_transform(box(100,75,300,250),[sgn*c,-s,sgn*s,c,*m['source_translation_offset']]);a,b,e,f=notch.bounds;insert_mode=12 if e-a>f-b else 13;xy=[anchor[0]+a+gap,anchor[1]+b+gap];add(insert_mode,xy);motifs.append({'bracket_mode':mode,'bracket_anchor':anchor,'insert_mode':insert_mode,'insert_anchor':xy,'exterior_notch_bounds':list(notch.bounds)})
for r in range(3):add(13,[1357.2,1357.2+r*180.225])
for r in range(2):
    for c in range(4):add(13,[1052.7+c*110.225,2608.1+r*180.225])
cog_slots=[[146.525+c*153.225,2684.6+r*153.225] for r in range(2) for c in range(6)]
for xy in cog_slots[:10]:add(16,xy)
for xy in cog_slots[10:]:add(3,xy)
assert Counter({k:len(v) for k,v in slots.items()})==Counter(d['mode'] for d in ds);anchors=[None]*57;groups={}
for i,d in enumerate(ds):groups.setdefault(d['mode'],[]).append(i)
for mode,indices in groups.items():
    ordered=sorted(slots[mode],key=lambda xy:(xy[1],xy[0]));assert len(indices)==len(ordered)
    for i,xy in zip(indices,ordered):anchors[i]=[round(v*1000) for v in xy]
for d,xy in zip(ds,anchors):assert all(d['lower_um'][k]<=xy[k]<=d['upper_um'][k] for k in range(2)),(d,xy)
rows=[]
for d,xy in zip(ds,anchors):
    m=modes[d['mode']];rows.append({'part_id':d['family'],'copy_index':d['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],'translation':[xy[k]/1000+m['source_translation_offset'][k] for k in range(2)]}})
short=load(GEO/'fixed-short-placements.json');rows+=short;stocks={'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.4269023299994]};guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);expected=[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])];full=audit(job,rows,stocks,required,guard,expected);partial=[p for p in rows if p['part_id']!='cog' or p['sheet_id']=='sheet-1'];partial_check=audit(job,partial,stocks,required,guard);write(OUT/'anchors-um.json',anchors);write(OUT/'motifs.json',motifs);write(OUT/'all66-candidate.json',rows);write(OUT/'all66-source-readback.json',full);write(OUT/'partial54-placements.json',partial);write(OUT/'partial54-source-readback.json',partial_check);assert len(partial)==54 and partial_check['valid']
write(OUT/'constructed.json',{'seconds':time.perf_counter()-start,'all66_originals_present':True,'actual_full_source_valid':full['valid'],'full_pair_failures':full['pair_failures'],'full_stock_failures':full['stock_failures'],'actual_source_partial_originals':54,'partial_source_valid':partial_check['valid'],'partial_same_sheet_pairs':partial_check['same_sheet_pairs'],'partial_stock_edges':partial_check['stock_edges'],'partial_minimum_pair_gap_mm':partial_check['minimum_pair_gap_mm'],'partial_minimum_extra_stock_mm':partial_check['minimum_extra_stock_mm'],'remaining_mandatory_cogs':12,'necessary_model_assignment_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'constructed.json'))
