"""Close the aggregate-count side condition for incompatible cell pairs."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];DOM=ROOT/'output/h5-fixed43-combined-domains-20261026';MODEL=ROOT/'output/h5-fourteen-cog-necessary-model-20261026';OUT=ROOT/'output/h5-fixed43-conflict-soundness-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();paths=[DOM/'merged-domain-rectangles.json',DOM/'audit/cell-capacities.json',DOM/'audit/incompatible-cell-pairs.json',DOM/'audit/checks.json',MODEL/'model-audit/checks.json',MODEL/'response-audit/checks.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Cross-domain incompatibility alone forbids both domains from being occupied, but only implies countA+countB<=1 when each domain separately has capacity1. Verify this extra side condition for all2409 aggregate-count rows. For any future rebuilt domain with larger capacity, use occupancy-presence logic or omit the aggregate row, never assume this old property persists.'})
assert load(DOM/'audit/checks.json')['passed'] and load(MODEL/'model-audit/checks.json')['passed'] and load(MODEL/'response-audit/checks.json')['passed'];caps=load(DOM/'audit/cell-capacities.json');pairs=load(DOM/'audit/incompatible-cell-pairs.json');domains=load(DOM/'merged-domain-rectangles.json');cases=0
for a,b in pairs:
    assert caps[a]['capacity']==caps[b]['capacity']==1
    aa,bb=domains[a]['bounds_units1000'],domains[b]['bounds_units1000'];maximum=max((x-u)**2+(y-v)**2 for x,y,u,v in product([aa[0],aa[2]],[aa[1],aa[3]],[bb[0],bb[2]],[bb[1],bb[3]]));assert maximum<247441**2
    for ca,cb in product([0,1],repeat=2):assert ((ca+cb<=1)==(not (ca and cb)));cases+=1
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'aggregate_conflict_rows_verified':len(pairs),'all_conflict_endpoints_separately_capacity1':True,'occupancy_boolean_cases_checked':cases,'larger_capacity_domains':sum(r['capacity']>1 for r in caps),'larger_capacity_domains_in_conflict_rows':0,'current_negative_scope_sound':True,'future_capacity_side_condition_must_be_rechecked':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
