"""Fresh repository, main CI and upstream stop-rule evidence."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed43-review-20261026';OUT.mkdir();sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
from pack_h5_evidence_archive import digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def run(args,name):
    p=subprocess.run(args,cwd=ROOT,capture_output=True,text=True);write(OUT/(name+'.json'),{'utc':datetime.now(timezone.utc).isoformat(),'args':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});p.check_returncode();return p.stdout.strip()
head=run(['git','rev-parse','HEAD'],'head');run(['git','fetch','origin','main'],'fetch');main=run(['git','rev-parse','origin/main'],'main');assert head=='5928270da59f7ce2c1bbd804ddf985d441490533' and main=='5928270da59f7ce2c1bbd804ddf985d441490533';assert not run(['git','diff','HEAD','--name-only'],'tracked')
runs=json.loads(run(['gh','run','list','--repo','skulitom/Nestbolt','--branch','main','--commit',main,'--limit','10','--json','databaseId,name,status,conclusion,headSha,url,createdAt,updatedAt'],'main-runs'));cirow=next(r for r in runs if r['name']=='Checks');ci=json.loads(run(['gh','run','view',str(cirow['databaseId']),'--json','databaseId,status,conclusion,headSha,jobs,url'],'main-ci'));assert ci['headSha']==main
sparrow=json.loads(run(['gh','api','repos/JeroenGar/sparrow/commits/main','--jq','{sha,date:.commit.committer.date,html_url}'],'sparrow-main'));studio=json.loads(run(['gh','api','repos/JeroenGar/sparrow-studio/commits/main','--jq','{sha,date:.commit.committer.date,html_url}'],'studio-main'));release=json.loads(run(['gh','api','repos/JeroenGar/sparrow/releases/latest','--jq','{tag_name,published_at,html_url}'],'sparrow-release'));sr=json.loads(run(['gh','api','repos/JeroenGar/sparrow-studio/releases?per_page=1','--jq','map({tag_name,published_at,html_url})'],'studio-releases'))
assert sparrow['sha']=='1fe3e3146110c34d77510636defb737c7ce893c6' and studio['sha']=='c0bb9e8671defc5c25a02feb91789601a08f2e75' and release['tag_name']=='v0.3.0' and sr==[]
prior=json.loads((ROOT/'benchmarks/results/h5-expanded-source-search-20261026/source-review.json').read_bytes());assert source_digest()==prior['production_digest'] and all(digest(ROOT/n)==h for n,h in prior['current_readmes'].items())
review={'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'main_head':main,'production_digest':source_digest(),'current_readmes':prior['current_readmes'],'sparrow_head':sparrow['sha'],'studio_head':studio['sha'],'sparrow_release':release['tag_name'],'studio_latest_release':sr,'upstream_heads_and_sparrow_release_unchanged':True,'main_ci_id':ci['databaseId'],'main_ci_status':ci['status'],'main_ci_conclusion':ci['conclusion'],'main_ci_successful_jobs':sum(j['conclusion']=='success' for j in ci['jobs']),'source_and_readmes_unchanged':True,'no_new_release_qualified':True,'completion_percent':60,'H2_complete':False,'H5_complete':False,'reserved_H2_vectors_evaluated':0};write(OUT/'review.json',review);print(review,flush=True)
