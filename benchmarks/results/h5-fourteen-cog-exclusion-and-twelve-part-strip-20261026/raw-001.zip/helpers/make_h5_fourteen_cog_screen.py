from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/screen_h5_first_three_cog_space.py').read_text().replace('h5-first-three-cog-space-20261026','h5-first-fourteen-cog-space-20261026')
s=s.replace("if p['sheet_id']=='sheet-0'];assert len(first)==55", "if p['sheet_id']=='sheet-0' and p['part_id']!='cog'];assert len(first)==44")
s=s.replace("'fixed_originals':55,'mandatory_new_cogs':3", "'fixed_originals':44,'mandatory_first_sheet_cogs':14")
s=s.replace('all55 fixed original filled outers','all44 fixed non-cog original filled outers, releasing all11 existing first-sheet cogs and retaining the3 remaining cogs as mandatory, for14 first-sheet cogs')
s=s.replace('current fixed first55','44 non-cog originals; all14 first-sheet cogs are mandatory')
with (ROOT/'output/screen_h5_first_fourteen_cog_space.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
