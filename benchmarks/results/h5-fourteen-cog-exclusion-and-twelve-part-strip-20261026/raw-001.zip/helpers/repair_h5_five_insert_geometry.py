from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];FAILED=ROOT/'output/h5-five-insert-short-sheet-20261026'
record={'construction_exit_code':1,'construction_failure':'Original filled-outer pair assertion failed before any candidate/checks file was written.','follow_on_audit_exit_code':1,'follow_on_audit_failure':'Missing partial64-placements.json because construction failed; no pass was recorded.','diagnosis':'Profiles7 and5 have lower and upper horizontal arms respectively. The candidate incorrectly raised profile7, shrinking the gap. Keep profile7 atY6.525 and raise profile5 toY19 for the first two pairs. The intended free gap is then betweenY106.525 and219.0.','original_plan_and_scripts_preserved':True,'solver_calls':0}
with (FAILED/'failure-review.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
s=(ROOT/'output/build_h5_five_insert_short_sheet.py').read_text().replace("OUT=ROOT/'output/h5-five-insert-short-sheet-20261026'", "OUT=ROOT/'output/h5-five-insert-short-sheet-repaired-20261026'")
s=s.replace("placed(brs[0],7,left,19.0 if widen else 6.525);placed(brs[1],5,left+(80.45 if widen else 75.225),6.525)", "placed(brs[0],7,left,6.525);placed(brs[1],5,left+(80.45 if widen else 75.225),19.0 if widen else 6.525)")
needle="write(OUT/'plan.json',"
assert needle in s;s=s.replace(needle,"inputs += [ROOT/'output/h5-five-insert-short-sheet-20261026'/n for n in ['plan.json','build.py','failure-review.json','audit/plan.json','audit/audit.py']]\n"+needle)
with (ROOT/'output/build_h5_five_insert_short_sheet_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_five_insert_short_sheet.py').read_text().replace('h5-five-insert-short-sheet-20261026','h5-five-insert-short-sheet-repaired-20261026')
with (ROOT/'output/audit_h5_five_insert_short_sheet_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print(record)
