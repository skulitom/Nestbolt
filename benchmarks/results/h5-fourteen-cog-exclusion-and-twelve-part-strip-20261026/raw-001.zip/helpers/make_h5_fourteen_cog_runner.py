from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_stem_ordered_nine_decision.py').read_text().replace('h5-stem-ordered-nine-decision-20261026','h5-fourteen-cog-necessary-model-20261026').replace('One complete remaining-original composition selector','One mandatory fourteen-cog necessary decision')
with (ROOT/'output/run_h5_fourteen_cog_necessary_model.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
