from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_composition_selection_checkpoint.py').read_text().replace('h5-composition-selection-review-20261026','h5-fixed43-review-20261026').replace('5025ace18886dfa503fd74572a7e4dc1715f3b94','5928270da59f7ce2c1bbd804ddf985d441490533').replace('6246967c2962095d78b15693ae34550fbe163743','5928270da59f7ce2c1bbd804ddf985d441490533')
with (ROOT/'output/review_h5_fixed43_checkpoint.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
