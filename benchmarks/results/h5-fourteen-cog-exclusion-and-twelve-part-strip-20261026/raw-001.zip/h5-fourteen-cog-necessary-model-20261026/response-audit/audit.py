"""Verify the sole fourteen-cog solver call and every returned model constraint."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fourteen-cog-necessary-model-20261026';RUN=BASE/'search';DOM=ROOT/'output/h5-fixed43-combined-domains-20261026';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=pb.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify one closed call, actual model/parameter import, terminal response and timing. For positives check every variable domain and active linear/product constraint with Python integers, all selected domain coordinates, all14 original identities and every91 pair distance. A positive remains necessary geometry only; a negative has the audited fixed43/short9 neighborhood scope. No retry.'})
for plan in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(plan)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];process=load(RUN/'process.json');budget=load(RUN/'budget.json');census=load(RUN/'census.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<=30 and budget['shared_seconds']==30 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==20 and budget['deadline_perf_counter']==budget['start_perf_counter']+30
assert not census['pending_pairs'] and census['solver_calls']==len(census['results'])==len(list(RUN.rglob('opened.json')))==1;folder=RUN/'000';row=load(folder/'result.json');opened=load(folder/'opened.json');assert row==census['results'][0] and row['parts']==list(range(14)) and opened['maximum_calls']==row['solver_calls']==1
m=proto(folder/'model.pb');assert m==proto(BASE/'models/000.pb') and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=20,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'] and opened['seconds_limit']==20
response=pb.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert pb.CpSolverStatus.Name(response.status)==row['status'] and abs(response.wall_time-row['seconds'])<.2 and row['solver_soft_overshoot_seconds']==max(0,row['seconds']-20) and row['seconds']<=row['stage_seconds'];positive=row['status'] in ['OPTIMAL','FEASIBLE'];sol=list(response.solution);active=0;centers=[]
if positive:
    assert len(sol)==len(m.variables) and sol[:28]==row['original_coordinates_units1000'] and not m.HasField('objective') and response.objective_value==response.best_objective_bound==0
    for v,n in zip(m.variables,sol):assert any(a<=n<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    def truth(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
    def value(e):return e.offset+sum(sol[i]*c for i,c in zip(e.vars,e.coeffs))
    for c in m.constraints:
        if not all(truth(v) for v in c.enforcement_literal):continue
        kind=c.WhichOneof('constraint')
        if kind=='linear':n=sum(sol[i]*v for i,v in zip(c.linear.vars,c.linear.coeffs));assert any(a<=n<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        else:assert kind=='int_prod' and value(c.int_prod.target)==math.prod(value(e) for e in c.int_prod.exprs)
        active+=1
    mapping=load(BASE/'mapping.json');domains=load(DOM/'merged-domain-rectangles.json');spec=load(BASE/'plan.json')
    for p in mapping['points']:
        chosen=[i for i,f in enumerate(p['domains']) if sol[f]];assert len(chosen)==1;x,y=sol[p['x']],sol[p['y']];bb=domains[chosen[0]]['bounds_units1000'];assert bb[0]<=x<=bb[2] and bb[1]<=y<=bb[3];centers.append({'original':p['original'],'center_units1000':[x,y],'domain':chosen[0]})
    assert len(centers)==14 and [r['center_units1000'][0] for r in centers]==sorted(r['center_units1000'][0] for r in centers);pairs=[]
    for a,b in combinations(centers,2):
        x,y=a['center_units1000'];u,v=b['center_units1000'];distance2=(x-u)**2+(y-v)**2;assert distance2>=247441**2;pairs.append({'originals':[a['original'],b['original']],'squared_distance_units':distance2})
    assert sorted(spec['fixed_first_originals']+spec['fixed_short_originals']+[r['original'] for r in centers])==list(range(66));write(OUT/'necessary-centers.json',centers);write(OUT/'necessary-pair-distances.json',pairs)
else:assert row['status'] in ['UNKNOWN','INFEASIBLE'] and not sol and row['original_coordinates_units1000'] is None
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':1,'status':row['status'],'solver_seconds':row['seconds'],'shared_seconds':process['seconds'],'shared_budget_honored':True,'soft_overrun_seconds':row['solver_soft_overshoot_seconds'],'positive_variables_verified':len(sol),'positive_active_constraints_verified':active,'necessary_centers_found':len(centers),'all14_original_cogs_required':True,'all66_identities_preserved':True,'full_source_angles_verified':False,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
