"""Independent implication, reduction, coordinate-envelope and rigid-owner readback."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from datetime import datetime,timezone
from hashlib import sha256
import json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-twelve-cog-integer-20261107';OUT=BASE/'audit'
D=ROOT/'output/h5-independent-twelve-cog-geometry-20261107';C=ROOT/'output/h5-independent-twelve-cog-canonical-20261107';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029/rigid-rectangle-preflight';PROCESS=ROOT/'output/h5-independent-twelve-cog-integer-process-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();floor=lambda v:v.numerator//v.denominator;ceil=lambda v:-floor(-v)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json']:queue.append(z)
assert load(C/'audit/checks.json')['passed'] and load(PRIOR/'audit-v3/checks.json')['passed'];spec=load(BASE/'plan.json');assert spec['grid_units_per_mm']==100 and spec['normal_scale']==1000000 and spec['world_origin_mm']==[0,2100] and spec['rectangle_gap_grid']==23 and F(spec['inset_mm'])==F('1e-7')
sources=[{'class':t['class'],'relative_grid_bounds':t['relative_grid_bounds'],'regions':[r for r in load(C/'audit/rounded-regions.json') if r['class']==t['class']]} for t in load(C/'templates.json')]
sources.append({'class':'cog_cog','relative_grid_bounds':load(D/'templates.json')[10]['relative_grid_bounds'],'regions':load(C/'cog-pair-regions.json')})
actual=load(BASE/'templates.json');assert len(actual)==4;plane_count=redundant=impossible=dominated=0;insets=[];max_activity=0;chains=[]
for t,source in zip(actual,sources):
    assert t['class']==source['class'] and t['relative_grid_bounds']==source['relative_grid_bounds'];bounds=t['relative_grid_bounds'];envelope=[F(max(map(abs,b)),100) for b in bounds];assert list(map(F,t['normal_error_envelope_mm']))==envelope
    assert len(t['regions'])==len(source['regions']);records={r['region']:r for r in t['regions']};assert len(records)==len(t['regions'])
    for r,s in zip(t['regions'],source['regions']):
        assert {k:v for k,v in r.items() if k not in ['planes','retained_edges','domain_redundant_edges','domain_impossible_edges','dominated_by']}==s
        poly=[tuple(map(F,p)) for p in s['hull_vertices']];assert len(poly)==len(r['planes']);keep=[];drop=[];bad=[]
        for i,(a,b,p) in enumerate(zip(poly,poly[1:]+poly[:1],r['planes'])):
            dx,dy=b[0]-a[0],b[1]-a[1];den=max(abs(dx),abs(dy));normal=[dy/den,-dx/den];raw=[round(v*1000000) for v in normal];div=math.gcd(*map(abs,raw));co=p['coefficients']
            assert p['edge']==i and p['unreduced_coefficients']==raw and p['divisor']==div>0 and co==[v//div for v in raw]
            error=sum(abs(normal[k]-F(raw[k],1000000))*envelope[k] for k in [0,1]);assert F(p['rounding_error_bound_mm'])==error
            rhs=sum(normal[k]*a[k] for k in [0,1]);upper=floor((rhs-error-F('1e-7'))*100000000)//div;assert p['upper']==upper
            inset=rhs-(F(div*upper,100000000)+error);assert inset>=F('1e-7');insets.append(inset)
            low=sum(min(c*lo,c*hi) for c,(lo,hi) in zip(co,bounds));high=sum(max(c*lo,c*hi) for c,(lo,hi) in zip(co,bounds))
            assert p['domain_activity_minimum']==low and p['domain_activity_maximum']==high and max(abs(low),abs(high),abs(upper))<2**53
            max_activity=max(max_activity,abs(low),abs(high));plane_count+=1
            if high<=upper:drop.append(i);redundant+=1
            else:keep.append(i)
            if low>upper:bad.append(i)
        assert r['retained_edges']==keep and r['domain_redundant_edges']==drop and r['domain_impossible_edges']==bad
        if bad:impossible+=1;assert r['dominated_by'] is None
    def cmap(r):
        v={}
        for i in r['retained_edges']:
            p=r['planes'][i];key=tuple(p['coefficients']);v[key]=min(v.get(key,p['upper']),p['upper'])
        return v
    for r in t['regions']:
        if r['dominated_by'] is None:continue
        dominated+=1;assert not r['domain_impossible_edges'];dest=records[r['dominated_by']];assert not dest['domain_impossible_edges']
        a,b=cmap(r),cmap(dest);assert all(key in a and a[key]<=value for key,value in b.items()) and (a!=b or dest['region']<r['region'])
        chain=[r['region']];current=r
        while current['dominated_by'] is not None:
            nxt=current['dominated_by'];assert nxt not in chain;chain.append(nxt);current=records[nxt]
        assert current['region'] in t['retained_region_ids'];chains.append({'class':t['class'],'chain':chain})
    assert t['retained_region_ids']==[r['region'] for r in t['regions'] if not r['domain_impossible_edges'] and r['dominated_by'] is None] and t['retained_region_ids']
aliases=load(BASE/'aliases.json');assert aliases==load(C/'aliases.json')
for a in aliases:
    t=next(t for t in actual if t['class']==a['class']);bounds=t['relative_grid_bounds']
    assert all(bounds[k][0]<=a['canonical_relative_grid_bounds'][k][0]<=a['canonical_relative_grid_bounds'][k][1]<=bounds[k][1] for k in [0,1])
original=load(D/'family-modes.json');modes=load(BASE/'family-modes.json')
for f,opts in modes.items():
    assert len(opts)==len(original[f])
    for m,s in zip(opts,original[f]):
        assert {k:v for k,v in m.items() if k!='integer_world_lower_left_bounds'}==s
        assert m['integer_world_lower_left_bounds']==[[b[0]-(210000 if k else 0),b[1]-(210000 if k else 0)] for k,b in enumerate(s['individual_grid_bounds'])]
cg=modes['cog'][0];cb=actual[3]['relative_grid_bounds'];assert cb==[[0,cg['individual_grid_bounds'][0][1]-cg['individual_grid_bounds'][0][0]],[cg['individual_grid_bounds'][1][0]-cg['individual_grid_bounds'][1][1],cg['individual_grid_bounds'][1][1]-cg['individual_grid_bounds'][1][0]]]
for name in ['instances.json','inventory.json','control-positions.json']:assert digest(BASE/name)==digest(D/name)
assert digest(BASE/'owner-pairs.json')==digest(C/'owner-pairs.json');instances=load(BASE/'instances.json');assert len(instances)==28 and sum(r['mode_count'] for r in instances)==108
rects=load(BASE/'mode-rectangles.json');old=load(PRIOR/'mode-rectangles.json');rectcount=0
for family,opts in rects.items():
    assert len(opts)==len(old[family])
    for a,b in zip(opts,old[family]):
        assert {k:v for k,v in a.items() if k!='rectangles'}=={k:v for k,v in b.items() if k!='rectangles'} and len(a['rectangles'])==len(b['rectangles'])
        for r,s in zip(a['rectangles'],b['rectangles']):
            assert {k:v for k,v in r.items() if k!='outward_offsets_grid'}==s
            assert r['outward_offsets_grid']==[floor(F(v)*100) if k<2 else ceil(F(v)*100) for k,v in enumerate(s['exact_affine_bounds_mm'])];rectcount+=1
components=load(BASE/'components.json');expected=[]
for item in instances[:16]:
    sizes={len(m['rectangles']) for m in rects[item['identity'][0]]};assert len(sizes)==1
    for piece in range(next(iter(sizes))):expected.append({'component':len(expected),'owner':item['owner'],'identity':item['identity'],'piece':piece})
assert components==expected and len(components)==24
pairs=[{'components':[a['component'],b['component']],'owners':[a['owner'],b['owner']]} for a,b in combinations(components,2) if a['owner']!=b['owner']]
assert pairs==load(BASE/'component-pairs.json') and len(pairs)==268
positions=load(BASE/'control-positions.json');controls=load(BASE/'control-regions.json');assert len(controls)==66
for control,(a,b) in zip(controls,combinations(range(12),2)):
    delta=[positions[b][k]-positions[a][k] for k in [0,1]];assert control['owners']==[a+16,b+16] and control['relative_grid']==delta and control['region'] in actual[3]['retained_region_ids']
    r=next(r for r in actual[3]['regions'] if r['region']==control['region']);assert all(sum(c*x for c,x in zip(p['coefficients'],delta))<=p['upper'] for p in r['planes'])
lookup={t['class']:t for t in actual};pairmap=load(BASE/'owner-pairs.json');expanded=sum(len(lookup[c]['retained_region_ids']) for p in pairmap for c in p['classes'])
expanded_planes=sum(sum(len(r['retained_edges']) for r in lookup[c]['regions'] if r['region'] in lookup[c]['retained_region_ids']) for p in pairmap for c in p['classes'])
prep=load(PROCESS/'prepare.json');opened=load(PROCESS/'opened.json');summary=load(BASE/'checks.json')
assert prep['passed'] and prep['job']['closed'] and prep['job']['active_processes']==0 and prep['complete_seconds']<=30 and prep['complete_seconds']>=summary['seconds_including_evidence_serialization'] and summary['seconds_including_evidence_serialization']<=20
for p,h in opened['inputs'].items():assert digest(ROOT/p)==h
assert (summary['integer_planes'],summary['domain_redundant_planes'],summary['domain_impossible_regions'],summary['dominated_regions'],summary['expanded_region_choices'],summary['expanded_guarded_region_planes'])==(plane_count,redundant,impossible,dominated,expanded,expanded_planes)
write(OUT/'dominance-chains.json',chains);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+list(BASE.glob('*.json'))+[PROCESS/n for n in ['opened.json','prepare.json','prepare-job.json','prepare-stdout.txt','prepare-stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Verify every exact source-halfplane implication including negative relative coordinates, every full-domain integer activity bound and every removed inequality. Check all impossible-region certificates and coefficient-matched subset implications, with acyclic chains ending at retained regions. Verify each alias domain lies in its coefficient-error envelope, all108 source modes and original world bounds, outward source rectangles,24 rigid components,268 component pairs and all66 control differences against complete unpruned integer planes. Model mode/coordinate coupling and full66 placement remain unproved.'})
result={'passed':True,'seconds':time.perf_counter()-start,'recursive_bindings_verified':len(bindings),'templates':4,'exact_integer_plane_implications':plane_count,'domain_redundant_planes_verified':redundant,'domain_impossible_regions_verified':impossible,'dominated_regions_verified':dominated,'retained_cached_regions':sum(len(t['retained_region_ids']) for t in actual),'expanded_region_choices':expanded,'expanded_guarded_region_planes':expanded_planes,'minimum_integer_inset_mm':float(min(insets)),'maximum_integer_plane_activity':max_activity,'source_mode_options':108,'relative_coordinate_alias_envelopes':12,'mode_component_rectangles':rectcount,'rigid_components':24,'different_owner_component_pairs':268,'integer_cog_control_pairs':66,'complete_integer_preparation_seconds':prep['complete_seconds'],'independent_full_model_audit_required':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
