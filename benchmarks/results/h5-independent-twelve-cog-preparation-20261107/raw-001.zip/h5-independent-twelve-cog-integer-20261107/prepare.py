"""Integer implications and exact bound/dominance reductions before model construction."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from datetime import datetime,timezone
from hashlib import sha256
import json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'output/h5-independent-twelve-cog-geometry-20261107';C=ROOT/'output/h5-independent-twelve-cog-canonical-20261107'
OUT=ROOT/'output/h5-independent-twelve-cog-integer-20261107';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029/rigid-rectangle-preflight'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(C/'audit/checks.json')['passed'] and load(PRIOR/'audit-v3/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
grid=100;scale=1000000;eps=F('1e-7');templates=[];planes=redundant=impossible=dominance=0
sources=[{'class':t['class'],'relative_grid_bounds':t['relative_grid_bounds'],'regions':[r for r in load(C/'audit/rounded-regions.json') if r['class']==t['class']]} for t in load(C/'templates.json')]
cg=load(D/'templates.json')[10];sources.append({'class':'cog_cog','relative_grid_bounds':cg['relative_grid_bounds'],'regions':load(C/'cog-pair-regions.json')})
for source in sources:
    bounds=source['relative_grid_bounds'];envelope=[F(max(map(abs,b)),grid) for b in bounds];regions=[]
    for r in source['regions']:
        poly=[tuple(map(F,p)) for p in r['hull_vertices']];record={**r,'planes':[],'retained_edges':[],'domain_redundant_edges':[],'domain_impossible_edges':[],'dominated_by':None}
        for edge,(a,b) in enumerate(zip(poly,poly[1:]+poly[:1])):
            dx,dy=b[0]-a[0],b[1]-a[1];den=max(abs(dx),abs(dy));normal=[dy/den,-dx/den];raw=[round(n*scale) for n in normal];div=math.gcd(*map(abs,raw));assert div>0
            error=sum(abs(normal[k]-F(raw[k],scale))*envelope[k] for k in [0,1]);co=[v//div for v in raw];rhs=sum(n*x for n,x in zip(normal,a));upper=math.floor((rhs-error-eps)*grid*scale)//div
            lo=sum(min(c*l,c*h) for c,(l,h) in zip(co,bounds));hi=sum(max(c*l,c*h) for c,(l,h) in zip(co,bounds));assert max(abs(lo),abs(hi),abs(upper))<2**53
            record['planes'].append({'edge':edge,'coefficients':co,'upper':upper,'unreduced_coefficients':raw,'divisor':div,'rounding_error_bound_mm':str(error),'domain_activity_minimum':lo,'domain_activity_maximum':hi});planes+=1
            if hi<=upper:record['domain_redundant_edges'].append(edge);redundant+=1
            else:record['retained_edges'].append(edge)
            if lo>upper:record['domain_impossible_edges'].append(edge)
        if record['domain_impossible_edges']:impossible+=1
        regions.append(record)
    def constraints(r):
        result={}
        for e in r['retained_edges']:
            p=r['planes'][e];key=tuple(p['coefficients']);result[key]=min(result.get(key,p['upper']),p['upper'])
        return result
    candidates=[r for r in regions if not r['domain_impossible_edges']];maps={r['region']:constraints(r) for r in candidates}
    for a in candidates:
        ac=maps[a['region']]
        for b in candidates:
            if a['region']==b['region']:continue
            bc=maps[b['region']]
            if all(key in ac and ac[key]<=upper for key,upper in bc.items()) and (ac!=bc or b['region']<a['region']):
                a['dominated_by']=b['region'];dominance+=1;break
    keep=[r['region'] for r in regions if not r['domain_impossible_edges'] and r['dominated_by'] is None];assert keep
    templates.append({'class':source['class'],'relative_grid_bounds':bounds,'normal_error_envelope_mm':[str(v) for v in envelope],'regions':regions,'retained_region_ids':keep})
    assert time.perf_counter()-start<20
modes=load(D/'family-modes.json')
for opts in modes.values():
    for m in opts:m['integer_world_lower_left_bounds']=[[b[0]-(210000 if k else 0),b[1]-(210000 if k else 0)] for k,b in enumerate(m['individual_grid_bounds'])]
rects=load(PRIOR/'mode-rectangles.json')
for opts in rects.values():
    for m in opts:
        for r in m['rectangles']:r['outward_offsets_grid']=[math.floor(F(v)*grid) if i<2 else math.ceil(F(v)*grid) for i,v in enumerate(r['exact_affine_bounds_mm'])]
instances=load(D/'instances.json');components=[]
for item in instances[:16]:
    for piece in range(2 if item['identity'][0]=='bracket' else 1):components.append({'component':len(components),'owner':item['owner'],'identity':item['identity'],'piece':piece})
pairs=[{'components':[a['component'],b['component']],'owners':[a['owner'],b['owner']]} for a,b in combinations(components,2) if a['owner']!=b['owner']];assert len(components)==24 and len(pairs)==268
positions=load(D/'control-positions.json');cg_template=templates[3];chosen=[]
for a,b in combinations(range(12),2):
    delta=[positions[b][k]-positions[a][k] for k in [0,1]];matches=[]
    for r in cg_template['regions']:
        if r['region'] not in cg_template['retained_region_ids']:continue
        if all(sum(c*x for c,x in zip(p['coefficients'],delta))<=p['upper'] for p in r['planes']):matches.append(r['region'])
    assert matches,(a,b,delta)
    chosen.append({'owners':[a+16,b+16],'region':matches[0],'relative_grid':delta})
for name,data in [('templates.json',templates),('family-modes.json',modes),('mode-rectangles.json',rects),('components.json',components),('component-pairs.json',pairs),('control-regions.json',chosen)]:write(OUT/name,data)
for name in ['aliases.json','owner-pairs.json']:shutil.copyfile(C/name,OUT/name)
for name in ['instances.json','inventory.json','control-positions.json']:shutil.copyfile(D/name,OUT/name)
lookup={t['class']:t for t in templates};allpairs=load(C/'owner-pairs.json')
expanded=sum(len(lookup[c]['retained_region_ids']) for p in allpairs for c in p['classes'])
expanded_planes=sum(sum(len(r['retained_edges']) for r in lookup[c]['regions'] if r['region'] in lookup[c]['retained_region_ids']) for p in allpairs for c in p['classes'])
inputs=[Path(__file__)]+[D/n for n in ['plan.json','audit/plan.json','audit/checks.json','family-modes.json','instances.json','inventory.json','templates.json','control-positions.json']]+[C/n for n in ['plan.json','audit/plan.json','audit/checks.json','audit/rounded-regions.json','templates.json','aliases.json','owner-pairs.json','cog-pair-regions.json']]+[PRIOR/n for n in ['plan.json','checks.json','mode-rectangles.json','audit-v3/plan.json','audit-v3/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Convert canonical and cog-pair rounded source hulls to conservative integer halfplanes at0.01mm grid and1000000 normal scale, with1e-7mm inward reserve and exact per-template relative-coordinate envelopes. Remove only planes proved redundant by their full rectangular coordinate domain, regions contradicted by one integer plane over that whole domain, and regions whose remaining coefficient-matched inequalities imply another retained region through an acyclic dominance chain. Independently audit all implications and every alias domain before any model. Preserve all original mode-specific world bounds, outward source rectangles,24 rigid components and268 different-owner pairs. Check all66 partial-control cog differences against the final integer regions. No model or solver is opened.','grid_units_per_mm':grid,'normal_scale':scale,'inset_mm':str(eps),'world_origin_mm':[0,2100],'rectangle_gap_grid':23,'preparation_target_seconds':20,'complete_process_cap_seconds':30,'independent_audit_cap_seconds':60,'future_algorithm_seconds':60,'future_shared_seconds':90,'future_maximum_calls':1,'retry_permitted':False,'solver_calls':0})
result={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-start,'templates':4,'source_regions':sum(len(t['regions']) for t in templates),'integer_planes':planes,'domain_redundant_planes':redundant,'domain_impossible_regions':impossible,'dominated_regions':dominance,'retained_cached_regions':sum(len(t['retained_region_ids']) for t in templates),'expanded_region_choices':expanded,'expanded_guarded_region_planes':expanded_planes,'retained_cog_control_pairs':66,'rigid_components':24,'rigid_component_pairs':268,'source_mode_options':108,'new_model_created':False,'solver_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
