from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-independent-twelve-cog-preparation-20261107';OUT=ROOT/'benchmarks/results'/NAME
D=ROOT/'output/h5-independent-twelve-cog-geometry-20261107';C=ROOT/'output/h5-independent-twelve-cog-canonical-20261107';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';F=ROOT/'output/h5-independent-twelve-cog-checkpoint-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
front=load(F/'checks.json');assert front['passed'] and front['solver_calls']==0 and not front['source_valid66']
inventory_ast=ast.parse((ROOT/'output/seal_h5_polygon_clearance_proofs_20261107.py').read_text(encoding='utf-8')).body
def assignment(node,name):return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
inventory_start=next(i for i,node in enumerate(inventory_ast) if assignment(node,'setup'));inventory_end=next(i for i,node in enumerate(inventory_ast) if assignment(node,'walker'))
exec(compile(ast.Module(body=inventory_ast[inventory_start:inventory_end],type_ignores=[]),'historical-parent-archives','exec'))
PARENTS.extend(ROOT/'benchmarks/results'/name for name in ['h5-polygon-clearance-proofs-20261107','h5-exact-circle-forest-20261107','h5-strip-capacity-models-20261107','h5-twelve-cog-row-construction-20261107','h5-twelve-cog-543-constructions-20261107'])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
exec(old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']"))
folders=[D,C,I,F]+[ROOT/'output'/f'h5-independent-twelve-cog-{s}-process-20261107' for s in ['geometry','canonical','integer']]+[ROOT/'output/h5-twelve-cog-543-main-sync-20261107']
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for p in (ROOT/'output').glob('*h5*independent*twelve*cog*20261107.py'):add('helpers/'+p.name,p)
failure=ROOT/'output/h5-independent-twelve-cog-runner-command-failure-20261107.json';add('runner-command-failure.json',failure)
for name in ['ccd1.py','pack_h5_evidence_archive.py',walker.name,'seal_h5_twelve_cog_543_checkpoint_20261107.py','seal_h5_polygon_clearance_proofs_20261107.py','push_h5_twelve_cog_543_checkpoint_20261107.py']:add('helpers/'+name,ROOT/'output'/name)
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'preparation-charges.json','preparation-charges.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(D/'audit/checks.json','source-geometry-audit.json'),(C/'audit/checks.json','canonical-coordinate-audit.json'),(I/'audit/checks.json','integer-geometry-audit.json'),(ROOT/'output/h5-twelve-cog-543-main-sync-20261107/receipt.json','prior-push-receipt.json'),(failure,'runner-command-failure.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Independently movable twelve-cog preparation — 2026-11-07

Fresh source geometry and a smaller coordinate representation are now verified
for **twelve independently movable cogs**, eight brackets and eight inserts.
The model will retain the fixed29 core and validated nine-part small sheet.
No complete model or solver call has opened, and the full66 placement remains
unproved. Four fixed arrangements and all 440 whole allocations remain;
H2/H5 stay open at **60% completed milestone weight**.

## Source domains and controls

[Independent source readback]({NAME}/source-geometry-audit.json) verifies
all 66 identities as a disjoint fixed29/moving28/short9 inventory. Each of
the twelve cogs has two independent coordinates at the declared seven-degree
phase. All 96 orthogonal modes remain, plus twelve fixed-phase cog modes.
This differs from the closed thirteen-cog/short11 models and the twelve-cog
rigid-row models; their negative results do not transfer.

Exact affine extrema define inward 0.01 mm grid bounds with a 0.025 mm reserve.
All 52 individual mode-domain corner controls and a deterministic 50-original
control pass **25,348 pair checks**, 8,312 stock-edge checks, 2,566 hole checks
and 214,130 hole-vertex checks. The control uses four columns and three levels
at 260 mm pitch, with 0.01 mm horizontal offsets between levels. Sixteen
orthogonal companions remain unplaced. Minimum source gap is 0.214826984 mm,
above the required 0.211708673 mm; minimum extra stock clearance is 0.025 mm.
Whole-domain separation above the fixed core is 0.225 mm.

The first preparation has eleven interaction templates, 876 certified rounded
regions and one disabled degenerate region. **10,520 exact support proofs**
certify the actual original affine source pieces. All 192 cog/orthogonal pairs
and 66 cog/cog pairs are mapped; the 120 orthogonal pairs remain required.
This broad representation would expand to 80,202 choices before the disabled
region is removed, so it was not sent directly to a solver.

## Shared coordinates with complete mode coupling

[The canonical-coordinate audit]({NAME}/canonical-coordinate-audit.json)
checks the exact signed-permutation map
`z = Q_mode * (position_B - position_A) + K_mode`.
Each quarter turn has an exact integer inverse and preserves Euclidean distance.
The model must enforce the corresponding map under the same selected part mode.
Nonmirrored brackets, mirrored brackets and inserts use three distinct templates;
each template is independently certified against all four original mode aliases.
No exact symmetry of floating-point source vertices is assumed.

All 192 endpoint controls and full coordinate domains pass. Maximum alignment
rounding is 0.001600606 mm. The new representative obstacles use 0.234 mm square
inflation; **6,728 exact source support proofs** certify all 218 rounded regions
with minimum original-source gap **0.232399392 mm**. The 132 already certified
cog/cog regions remain unchanged. All 108 modes and 258 cog interactions remain,
requiring 2,304 conditional coordinate-link equations in the future model.
The region-choice count falls to **29,640**. This is a different conservative
positive construction, not a proof that its free domain equals the earlier one.

## Integer geometry and exact reductions

[Integer readback]({NAME}/integer-geometry-audit.json) verifies **1,244**
halfplane implications with a 1,000,000 normal scale, template-specific complete
coordinate error envelopes and at least 0.0000001 mm inward reserve.
Exact coefficient-matched subset proofs remove **31 dominated cached regions**;
every proof chain terminates at a retained region. No plane is removed as
domain-redundant, and no region is ruled out by an individual domain bound.

There are **319 retained cached regions**, **27,594 expanded region choices**
and **97,284 expanded guarded planes**. All 66 cog-control differences satisfy
the full original integer inequalities, including dominated-region substitutions.
The audit preserves all original mode domains, 20 source-mode component rectangles,
24 rigid components and 268 different-owner component pairs.

[Charged preparation so far]({NAME}/preparation-charges.json) totals
**3.242979 seconds**, including all three complete new preparation processes,
earlier fixed-source/rectangle/site preparation consumed by the source inventory,
and the complete direct short9 process. Independent audits are recorded separately.
All six preparation/audit process trees close within their frozen limits and
2 GiB job memory caps. The complete future model-build cost must still be charged.

## Next step and preservation

[The next model plan]({NAME}/next-step.json) requires all 28 world positions,
all mode-coupled canonical coordinates, complete source-domain and pair constraints,
rigid component links and an independent read of every serialized model field
before one frozen 60/90-second call. A partial cog hint is verified; it does not
place the sixteen companions. Full66 source/native/material checks, production
integration and the unchanged full H5 matrix remain required.

A [shell quoting failure]({NAME}/runner-command-failure.json) occurred before
the canonical runner was generated or any process started. The separate generator
corrected command delivery with unchanged limits; no geometry or solver call
was repeated. All prior bounded calls remain closed.

[The prior normal push]({NAME}/prior-push-receipt.json) placed both row checkpoints
on main **3baf15d1**, after all six preceding checks passed and while preserving
all 52 remote files. At this checkpoint's review,
[current CI]({NAME}/main-ci-at-review.json) has five successes and a live Windows
native check. No live run is cancelled. Production, READMEs and release assets
are unchanged; no new release is made.

[The archive manifest]({NAME}/raw-manifest.json) records {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes.
[Historical references]({NAME}/external-evidence.json) and
[input bindings]({NAME}/source-bindings.json) preserve all consumed source bytes.
Independent archive verification is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-07 H5 independent twelve-cog preparation:** [source, coordinate and integer audits]({link}) verify28 original movers with12 independently positioned cogs, all108 source modes,25,348 source pair checks and258 cog interactions. Exact mode-coupled quarter-turn coordinates reduce the initial80,202 region choices to29,640, with6,728 new original-source support proofs and minimum certified gap0.232399392mm. All1,244 integer implications and31 dominance proofs pass, leaving27,594 choices and97,284 guarded planes. The50-original partial control retains all66 cog-pair checks;16 companions remain unplaced. Complete charged preparation so far is3.242979s; a complete model and independent protobuf audit are next, before one frozen60/90-second call. No solver or native call opened and no arrangement/allocation is excluded. Four fixed arrangements and440 allocations remain; H2/H5 stay open at60%. Both earlier row checkpoints reached main3baf15d1 normally after all six prior checks passed, preserving52 remote files. Current Windows CI is live at review. The pre-execution shell quoting failure remains documented; all bounded processes closed. No release is made.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
s=s[:a]+f'''Latest H5 evidence: [independent twelve-cog preparation](../benchmarks/results/{NAME}.md).
Fresh geometry allows all twelve cogs to move independently with sixteen
orthogonal companions, retaining all 108 source-mode options and the direct
nine-part small sheet. Exact mode-coupled coordinate proofs and integer reductions
leave 27,594 region choices and 97,284 guarded planes. All source, coordinate and
integer audits pass; charged preparation so far is 3.242979 s. A complete model
and independent serialized-model readback are next, before one bounded call.
No model or solver has opened, and the 50-original control remains incomplete.
Four fixed arrangements and all 440 whole allocations remain; full66 source,
material/native checks and the full H5 gate remain open. H2/H5 stay open at 60%.
The preceding row checkpoints reached main 3baf15d1 after all six prior checks
passed; its Windows native check is still live at review.
'''+s[b:]
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':True,**archive,'source_valid66':False,'solver_calls':0})
