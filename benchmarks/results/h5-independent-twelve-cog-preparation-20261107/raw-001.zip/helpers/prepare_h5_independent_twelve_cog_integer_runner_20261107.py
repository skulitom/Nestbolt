from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_independent_twelve_cog_canonical_20261107.py').read_text(encoding='utf-8').replace('twelve-cog-canonical-process','twelve-cog-integer-process').replace('twelve_cog_canonical','twelve_cog_integer').replace("20261107.py',90","20261107.py',60")
ast.parse(s)
with (ROOT/'output/run_h5_independent_twelve_cog_integer_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for stage in ['prepare','audit','run']:ast.parse((ROOT/'output'/(stage+'_h5_independent_twelve_cog_integer_20261107.py')).read_text(encoding='utf-8'))
print('Integer helpers parse; runner generated.')
