from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-independent-twelve-cog-checkpoint-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();inputs=[Path(__file__)];reports={};processes={}
for stage in ['geometry','canonical','integer']:
    b=ROOT/'output'/f'h5-independent-twelve-cog-{stage}-20261107';p=ROOT/'output'/f'h5-independent-twelve-cog-{stage}-process-20261107'
    reports[stage]=load(b/'audit/checks.json');processes[stage]=load(p/'process.json')
    assert reports[stage]['passed'] and reports[stage]['solver_calls']==0 and not reports[stage]['new_model_created'] and not reports[stage]['source_valid66']
    assert processes[stage]['passed'] and processes[stage]['closed'] and len(processes[stage]['stages'])==2
    assert all(r['passed'] and r['job']['active_processes']==0 and r['job']['closed'] and r['job']['reason_code']==r['job']['error_code']==0 for r in processes[stage]['stages'])
    assert not any((b/name).exists() for name in ['model','search','response-audit'])
    inputs.extend([b/'plan.json',b/'audit/plan.json',b/'audit/checks.json',p/'opened.json',p/'process.json'])
g,c,i=(reports[k] for k in ['geometry','canonical','integer']);assert g['moving_originals']==28 and g['cogs']==12 if 'cogs' in g else g['moving_originals']==28
assert g['pairs']==25348 and g['exact_source_support_proofs']==10520 and c['exact_original_source_support_proofs']==6728 and i['exact_integer_plane_implications']==1244
assert c['expanded_region_choices_after_disabled']==29640 and i['expanded_region_choices']==27594 and i['expanded_guarded_region_planes']==97284
assert i['dominated_regions_verified']==31 and i['domain_redundant_planes_verified']==i['domain_impossible_regions_verified']==0
charge_inputs={
 'fixed_source_mode_geometry_preparation_seconds':(ROOT/'output/h5-first55-after-source-valid11-20261029/checks.json','seconds'),
 'source_reference_site_preparation_consumed_by_direct_short9_seconds':(ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight/checks.json','seconds'),
 'source_rectangle_preparation_seconds':(ROOT/'output/h5-first55-cog-site-masks-20261029/rigid-rectangle-preflight/checks.json','seconds'),
 'direct_short9_inventory_complete_process_seconds':(ROOT/'output/h5-first57-direct-short9-process-20261104/process.json','complete_process_seconds')}
charges={k:load(p)[field] for k,(p,field) in charge_inputs.items()};inputs.extend(p for p,field in charge_inputs.values())
for stage in processes:charges[stage+'_complete_preparation_seconds']=processes[stage]['stages'][0]['complete_seconds']
write(OUT/'preparation-charges.json',charges)
ci=json.loads(subprocess.check_output(['gh','run','view','42331520271','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='3baf15d164fb03dca5be7d460c6d4c1496ad6445';write(OUT/'main-ci-at-review.json',ci)
receipt=ROOT/'output/h5-twelve-cog-543-main-sync-20261107/receipt.json';r=load(receipt);assert r['new_main']==ci['headSha'] and r['prior_main_all6_pass'] and r['remote_files_preserved']==52 and r['normal_atomic_fast_forward'];inputs.append(receipt)
inputs.extend([ROOT/'output/h5-independent-twelve-cog-runner-command-failure-20261107.json',ROOT/'output/prepare_h5_independent_twelve_cog_canonical_runner_20261107.py',ROOT/'output/prepare_h5_independent_twelve_cog_integer_runner_20261107.py'])
next_step={'next':'Build and independently read a complete28-mover integer model using mode-coupled canonical coordinates. No further rigid-row pattern or unchanged closed solver call is needed before this new construction.','source_integer_preparation':'output/h5-independent-twelve-cog-integer-20261107','all_world_position_variables':56,'cog_coordinate_variables':24,'orthogonal_mode_options':96,'cog_mode_options':12,'cog_orthogonal_pairs':192,'cog_cog_pairs':66,'orthogonal_original_pairs':120,'different_owner_component_pairs':268,'required_conditional_canonical_links':2304,'partial_control':'output/h5-independent-twelve-cog-integer-20261107/control-regions.json','partial_control_not_full66':True,'model_requirement':'For each cog/orthogonal pair add two canonical coordinates. Under every selected orthogonal mode enforce z=Q*(pB-pA)+K exactly, retaining the local world origin because it cancels in the difference. Couple canonical class/region selection to the same owner mode. Enforce all108 source-mode domains and all97,284 retained integer planes,24 rigid component links and268 different-owner separations. Same-family X order requires identical geometry/domains. Retain every one of28 original mover identities with fixed29 and direct short9. A partial hint may use the verified12-cog control and all66 integer pair choices; no16-companion hint is established. Full protobuf readback, native solver import and source reconstruction are mandatory before one freshly frozen60/90s call.','charged_preparation_seconds_before_complete_model_build':sum(charges.values()),'all_consumed_preparation_and_complete_model_build_chargeable':True,'source_valid66_required_before_native':True,'full66_source_pair_checks':1632,'full66_source_stock_edges':264,'full66_holes':90,'full66_hole_vertices':10026,'maximum_calls':1,'retry_permitted':False,'independent_model_audit_complete':False,'solver_call_prepared':False,'fixed_arrangements_remaining':4,'whole_allocations_remaining':440,'completion_percent':60,'H2_complete':False,'H5_complete':False}
write(OUT/'next-step.json',next_step)
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconcile all three closed source/coordinate/integer preparation and independent audit processes, every recursive input hash, charged preparation ledger, preserved pre-execution shell failure and successful normal main push. No CP model, solver, native result, full66 placement, continuous exclusion or H5 completion is claimed.'})
result={'passed':True,'seconds':time.perf_counter()-start,'recursive_bindings':len(bindings),'source_pair_checks':g['pairs'],'source_support_proofs':g['exact_source_support_proofs'],'canonical_source_support_proofs':c['exact_original_source_support_proofs'],'integer_plane_implications':i['exact_integer_plane_implications'],'source_mode_options':108,'original_movers':28,'independent_cogs':12,'canonical_expanded_choices':29640,'final_expanded_region_choices':27594,'retained_integer_region_planes':97284,'dominated_cached_regions':31,'charged_preparation_before_model_seconds':sum(charges.values()),'closed_preparation_and_audit_processes':6,'all_descendants_closed':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'fixed_arrangements_remaining':4,'new_fixed_arrangement_exclusions':0,'whole_allocations_remaining':440,'completion_percent':60,'H2_complete':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
