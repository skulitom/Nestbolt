from pathlib import Path
import ast,json
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'output/run_h5_independent_twelve_cog_geometry_20261107.py'
target=ROOT/'output/run_h5_independent_twelve_cog_canonical_20261107.py'
text=source.read_text(encoding='utf-8').replace('twelve-cog-geometry-process','twelve-cog-canonical-process').replace('twelve_cog_geometry','twelve_cog_canonical').replace("20261107.py',40","20261107.py',30")
ast.parse(text)
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
for stage in ['prepare','audit','run']:
    ast.parse((ROOT/'output'/(stage+'_h5_independent_twelve_cog_canonical_20261107.py')).read_text(encoding='utf-8'))
with (ROOT/'output/h5-independent-twelve-cog-runner-command-failure-20261107.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'stage':'PowerShell inline Python runner generation before any canonical process','reason':'Quoted replacement text was split by shell argument handling; Python reported SyntaxError before execution. The subsequent attempted runner path did not exist.','runner_written_by_failed_command':False,'canonical_preparation_started_by_failed_command':False,'solver_started':False,'correction':'A separate UTF-8 generator file writes and parses the intended runner with unchanged30/90-second caps. No model, search or source preparation is repeated.'},f,indent=2);f.write('\n')
print('Canonical helpers parse; runner generated.')
