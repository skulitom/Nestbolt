"""Quarter-turn-coupled interaction coordinates, independently source-certified later."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from datetime import datetime,timezone
from hashlib import sha256
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import hull,merge_exact,area
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-independent-twelve-cog-geometry-20261107';PRE=ROOT/'output/h5-first57-direct-short9-20261104'
OUT=ROOT/'output/h5-independent-twelve-cog-canonical-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def clip(domain,a,b):
    a,b=tuple(map(F,a)),tuple(map(F,b));x0,y0,x1,y1=map(F,domain);poly=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)];out=[]
    cross=lambda p:(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
    for p,q in zip(poly,poly[1:]+poly[:1]):
        cp,cq=cross(p),cross(q)
        if cp<=0:out.append(p)
        if (cp<0<cq) or (cq<0<cp):
            t=cp/(cp-cq);out.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    out=hull(out)
    return [[float(x),float(y)] for x,y in out] if len(out)>=3 and area(out)>0 else None
assert load(SOURCE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',JOB,PRE/'geometry-library.json']+[SOURCE/n for n in ['plan.json','checks.json','family-modes.json','instances.json','inventory.json','geometry-grid-bounds.json','owner-pairs.json','templates.json','audit/plan.json','audit/checks.json','audit/rounded-regions.json','audit/disabled-regions.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
 'method':'Define exact signed-permutation coordinates z=Q_mode*(lower_left_B-lower_left_A)+K_mode on the0.01mm grid for each cog/orthogonal pair. Q reverses the selected orthogonal quarter turn; K is the nearest grid shift aligning the source bounding-box-centre differences with a canonical representative. Four nonmirrored bracket modes share one template; four mirrored bracket modes share another; four insert modes share a third. Independently certify every resulting region against every actual source alias in these coordinates; do not assume exact rotational symmetry of binary64 source vertices. Fresh representative obstacles use0.234mm square inflation to allow the small rounded shift discrepancy. Retain the independently certified cog/cog template and all original domains/identities. All108 source modes and258 cog interactions remain; model links must enforce z exactly under each selected source mode. The earlier11-template preflight is preserved and charged, without a solver call.',
 'grid_units_per_mm':100,'square_halfwidth_mm':.234,'required_certified_source_gap_mm':.225,'preparation_target_seconds':20,'complete_process_cap_seconds':30,'independent_audit_cap_seconds':90,'retry_permitted':False,'future_algorithm_seconds':60,'future_shared_seconds':90,'future_maximum_calls':1,'solver_calls':0})
modes=load(SOURCE/'family-modes.json');library=load(PRE/'geometry-library.json');cg=modes['cog'][0];instances=load(SOURCE/'instances.json')
matrices=[[[1,0],[0,1]],[[0,1],[-1,0]],[[-1,0],[0,-1]],[[0,-1],[1,0]]]
def centre(m):
    b=list(map(F,m['exact_normalized_source_bounds_mm']));return [(b[k]+b[k+2])/2 for k in [0,1]]
cc=centre(cg);aliases=[];classes=[('bracket',False,0),('bracket',True,4),('insert',False,0)]
for cid,(family,mirrored,representative) in enumerate(classes):
    ref=modes[family][representative];target=[cc[k]-centre(ref)[k] for k in [0,1]]
    for mode in modes[family]:
        if mode['mirrored']!=mirrored:continue
        q=matrices[int(mode['rotation_degrees'])//90];diff=[cc[k]-centre(mode)[k] for k in [0,1]]
        ideal=[target[k]-sum(q[k][j]*diff[j] for j in [0,1]) for k in [0,1]];offset=[round(x*100) for x in ideal]
        raw=[[mode['individual_grid_bounds'][k][0]-cg['individual_grid_bounds'][k][1],mode['individual_grid_bounds'][k][1]-cg['individual_grid_bounds'][k][0]] for k in [0,1]]
        corners=[[sum(q[k][j]*p[j] for j in [0,1])+offset[k] for k in [0,1]] for p in product(*raw)]
        bounds=[[min(p[k] for p in corners),max(p[k] for p in corners)] for k in [0,1]]
        aliases.append({'class':cid,'family':family,'mode':mode['mode'],'geometry':mode['normalized_geometry'],'matrix':q,'offset_grid':offset,'exact_alignment_mm':[str(x) for x in ideal],'rounding_error_mm':[str(F(offset[k],100)-ideal[k]) for k in [0,1]],'raw_relative_grid_bounds':raw,'canonical_relative_grid_bounds':bounds})
assert len(aliases)==12
square=np.asarray([[-.234,-.234],[.234,-.234],[.234,.234],[-.234,.234]])
templates=[];obstacles=[]
for cid,(family,mirrored,representative) in enumerate(classes):
    members=[a for a in aliases if a['class']==cid];assert len(members)==4
    bounds=[[min(a['canonical_relative_grid_bounds'][k][0] for a in members),max(a['canonical_relative_grid_bounds'][k][1] for a in members)] for k in [0,1]]
    domain=[F(bounds[0][0],100),F(bounds[1][0],100),F(bounds[0][1],100),F(bounds[1][1],100)];gid=modes[family][representative]['normalized_geometry'];polys=[]
    for a,b in product(library[10]['pieces'],library[gid]['pieces']):
        diff=(np.asarray(a)[:,None,:]-np.asarray(b)[None,:,:]).reshape(-1,2);polys.append(MultiPoint((diff[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
    inflated=unary_union(polys);envelope=inflated.convex_hull;outer=hull([tuple(map(F,p)) for p in envelope.exterior.coords[:-1]]);regions=[];kinds=[]
    for a,b in zip(outer,outer[1:]+outer[:1]):
        r=clip(domain,a,b)
        if r is not None:regions.append(r);kinds.append('convex_exterior_halfplane')
    pockets=envelope.difference(inflated).intersection(box(*map(float,domain)));triangles=[p for p in shapely.constrained_delaunay_triangles(pockets).geoms if p.area>0];merged,merges=merge_exact(triangles) if triangles else ([],0)
    regions.extend(merged);kinds.extend(['concave_pocket']*len(merged));assert regions
    free=box(*map(float,domain)).difference(inflated);combined=unary_union([Polygon(r) for r in regions]);raw_error=combined.symmetric_difference(free).area
    snapped_error=shapely.symmetric_difference(shapely.union_all([Polygon(r) for r in regions],grid_size=1e-8),shapely.difference(box(*map(float,domain)),inflated,grid_size=1e-8),grid_size=1e-8).area
    assert inflated.is_valid and free.is_valid and snapped_error<1e-4
    templates.append({'class':cid,'family':family,'mirrored':mirrored,'representative_mode':representative,'representative_geometry':gid,'domain_mm':[str(x) for x in domain],'relative_grid_bounds':bounds,'regions':[{'region':i,'kind':kind,'vertices':r} for i,(kind,r) in enumerate(zip(kinds,regions))],'exterior_regions':kinds.count('convex_exterior_halfplane'),'pocket_regions':kinds.count('concave_pocket'),'pocket_triangles':len(triangles),'exact_merges':merges,'raw_overlay_error_mm2':raw_error,'snapped_overlay_error_mm2':snapped_error})
    obstacles.append({'class':cid,'inflated':mapping(inflated)});assert time.perf_counter()-started<20
pairs=[]
for p in load(SOURCE/'owner-pairs.json'):
    if p['kind']=='cog_cog':pairs.append({**p,'classes':['cog_cog']})
    else:
        family=instances[p['owners'][1]]['identity'][0];pairs.append({**p,'classes':[0,1] if family=='bracket' else [2]})
cg_regions=[r for r in load(SOURCE/'audit/rounded-regions.json') if r['geometry']==10]
for name,data in [('aliases.json',aliases),('templates.json',templates),('obstacles.json',obstacles),('owner-pairs.json',pairs),('cog-pair-regions.json',cg_regions)]:write(OUT/name,data)
expanded=sum(len(cg_regions) if p['kind']=='cog_cog' else sum(len(templates[c]['regions']) for c in p['classes']) for p in pairs)
result={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-started,'orthogonal_mode_aliases':12,'canonical_mover_templates':3,'new_cached_regions':sum(len(t['regions']) for t in templates),'retained_cog_pair_regions':len(cg_regions),'expanded_cog_region_choices_before_new_disabled':expanded,'earlier_expanded_cog_choices':load(SOURCE/'checks.json')['expanded_cog_region_choices'],'cog_interaction_pairs':258,'source_mode_options':108,'required_conditional_relative_coordinate_equalities':192*2,'conditional_alias_coordinate_links':sum(2*len(modes[instances[p['owners'][1]]['identity'][0]]) for p in pairs if p['kind']=='cog_orthogonal'),'source_certification_pending':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
