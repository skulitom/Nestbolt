"""Prove mode-coupled coordinate maps and every canonical original-source separation."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from datetime import datetime,timezone
from hashlib import sha256
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import hull
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-twelve-cog-canonical-20261107';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-independent-twelve-cog-geometry-20261107'
PROCESS=ROOT/'output/h5-independent-twelve-cog-canonical-process-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json']:queue.append(z)
assert load(SOURCE/'audit/checks.json')['passed'];modes=load(SOURCE/'family-modes.json');instances=load(SOURCE/'instances.json');templates=load(BASE/'templates.json');aliases=load(BASE/'aliases.json');cg=modes['cog'][0]
parts={p['id']:p for p in load(JOB)['parts']};canonical=load(PIECES)
def original(points,m):
    c,s=map(F,[math.cos(m['rotation_radians']),math.sin(m['rotation_radians'])]);tx,ty=map(F,m['translation_from_lower_left']);sgn=-1 if m['mirrored'] else 1
    return [(tx+sgn*F(x)*c-F(y)*s,ty+sgn*F(x)*s+F(y)*c) for x,y in points]
def center(family,m):
    v=original(parts[family]['geometry'][0]['outer'],m);return [(min(p[k] for p in v)+max(p[k] for p in v))/2 for k in [0,1]]
cc=center('cog',cg);keys=set();transforms={};map_controls=0;max_error=F(0);expected_classes=[('bracket',False,0),('bracket',True,4),('insert',False,0)]
for a in aliases:
    cid=a['class'];family,mirror,representative=expected_classes[cid];m=modes[family][a['mode']];q=a['matrix'];shift=a['offset_grid'];key=(family,m['mode']);assert key not in keys;keys.add(key)
    assert a['family']==family and m['mirrored']==mirror and a['geometry']==m['normalized_geometry']
    assert q=={0:[[1,0],[0,1]],90:[[0,1],[-1,0]],180:[[-1,0],[0,-1]],270:[[0,-1],[1,0]]}[int(m['rotation_degrees'])]
    assert all(sum(q[k][i]*q[k][j] for k in [0,1])==int(i==j) for i in [0,1] for j in [0,1])
    ref=center(family,modes[family][representative]);mc=center(family,m);ideal=[cc[k]-ref[k]-sum(q[k][j]*(cc[j]-mc[j]) for j in [0,1]) for k in [0,1]]
    assert list(map(F,a['exact_alignment_mm']))==ideal and shift==[round(v*100) for v in ideal]
    errors=[F(shift[k],100)-ideal[k] for k in [0,1]];assert list(map(F,a['rounding_error_mm']))==errors and max(map(abs,errors))<=F('.005');max_error=max(max_error,*map(abs,errors))
    raw=[[m['individual_grid_bounds'][k][0]-cg['individual_grid_bounds'][k][1],m['individual_grid_bounds'][k][1]-cg['individual_grid_bounds'][k][0]] for k in [0,1]];assert a['raw_relative_grid_bounds']==raw
    corners=[]
    for pa,pb in product(product(*cg['individual_grid_bounds']),product(*m['individual_grid_bounds'])):
        d=[pb[k]-pa[k] for k in [0,1]];z=[sum(q[k][j]*d[j] for j in [0,1])+shift[k] for k in [0,1]]
        assert [sum(q[j][k]*(z[j]-shift[j]) for j in [0,1]) for k in [0,1]]==d;corners.append(z);map_controls+=1
    assert a['canonical_relative_grid_bounds']==[[min(p[k] for p in corners),max(p[k] for p in corners)] for k in [0,1]]
    # z + Q*B - (Q*A + K) = Q*(d+B-A). Q is an exact Euclidean isometry.
    def mapped(points,source_mode,offset):
        return [tuple(sum(F(q[k][j])*p[j] for j in [0,1])+F(offset[k],100) for k in [0,1]) for p in original(points,source_mode)]
    A={'outer':mapped(parts['cog']['geometry'][0]['outer'],cg,shift),'pieces':[mapped(p,cg,shift) for p in canonical['cog']]}
    B={'outer':mapped(parts[family]['geometry'][0]['outer'],m,[0,0]),'pieces':[mapped(p,m,[0,0]) for p in canonical[family]]}
    for body in [A,B]:
        body['hull']=hull(body['outer']);polys=[Polygon([(float(x),float(y)) for x,y in p]) for p in body['pieces']];outer=Polygon([(float(x),float(y)) for x,y in body['outer']])
        assert unary_union(polys).symmetric_difference(outer).area<1e-7 and abs(sum(p.area for p in polys)-outer.area)<1e-7
    transforms[key]=(A,B)
assert keys=={(f,m['mode']) for f in ['bracket','insert'] for m in modes[f]} and map_controls==192
def nfp(a,b):return MultiPoint((np.asarray(a,dtype=float)[:,None,:]-np.asarray(b,dtype=float)[None,:,:]).reshape(-1,2)).convex_hull
def certificate(region,shape,moving,fixed,obstacle):
    line=list(shapely.shortest_line(obstacle,shape).coords)
    if len(line)!=2:return None
    dx,dy=line[1][0]-line[0][0],line[1][1]-line[0][1];length=math.hypot(dx,dy)
    if not length:return None
    normal=[dx/length,dy/length];nx,ny=map(F,normal);norm=nx*nx+ny*ny
    gap=min(x*nx+y*ny for x,y in region)+min(x*nx+y*ny for x,y in moving)-max(x*nx+y*ny for x,y in fixed)
    if gap<=0 or gap*gap<F('.225')**2*norm:return None
    return normal,float(gap)/math.sqrt(float(norm))
assert len(templates)==3;rounded=[];proofs=[];disabled=[];cache={};minimum_gap=math.inf;whole=piecewise=0
for cid,t in enumerate(templates):
    family,mirror,representative=expected_classes[cid];members=[a for a in aliases if a['class']==cid];assert len(members)==4
    assert (t['class'],t['family'],t['mirrored'],t['representative_mode'],t['representative_geometry'])==(cid,family,mirror,representative,modes[family][representative]['normalized_geometry'])
    limits=[[min(a['canonical_relative_grid_bounds'][k][0] for a in members),max(a['canonical_relative_grid_bounds'][k][1] for a in members)] for k in [0,1]]
    assert t['relative_grid_bounds']==limits and list(map(F,t['domain_mm']))==[F(limits[0][0],100),F(limits[1][0],100),F(limits[0][1],100),F(limits[1][1],100)]
    for ri,r in enumerate(t['regions']):
        assert r['region']==ri;v=hull([tuple(F(round(x,9)) for x in p) for p in r['vertices']])
        if len(v)<3:disabled.append([cid,ri]);continue
        shape=Polygon([(float(x),float(y)) for x,y in v]);assert shape.is_valid and shape.area>0
        rounded.append({'class':cid,'region':ri,'kind':r['kind'],'hull_vertices':[[str(x),str(y)] for x,y in v]})
        for alias in members:
            key=(family,alias['mode']);A,B=transforms[key];ck=(key,-1,-1)
            if ck not in cache:cache[ck]=nfp(A['hull'],B['hull'])
            result=certificate(v,shape,B['hull'],A['hull'],cache[ck])
            if result:
                n,gap=result;proofs.append([cid,ri,*key,-1,-1,*n]);minimum_gap=min(minimum_gap,gap);whole+=1;continue
            for bi,b in enumerate(B['pieces']):
                ck=(key,-1,bi)
                if ck not in cache:cache[ck]=nfp(A['hull'],b)
                result=certificate(v,shape,b,A['hull'],cache[ck])
                if result:
                    n,gap=result;proofs.append([cid,ri,*key,-1,bi,*n]);minimum_gap=min(minimum_gap,gap);piecewise+=1;continue
                for ai,a in enumerate(A['pieces']):
                    ck=(key,ai,bi)
                    if ck not in cache:cache[ck]=nfp(a,b)
                    result=certificate(v,shape,b,a,cache[ck]);assert result,(cid,ri,key,ai,bi)
                    n,gap=result;proofs.append([cid,ri,*key,ai,bi,*n]);minimum_gap=min(minimum_gap,gap);piecewise+=1
    assert time.perf_counter()-started<85
pairs=load(BASE/'owner-pairs.json');original_pairs=load(SOURCE/'owner-pairs.json');assert len(pairs)==258
for p,old in zip(pairs,original_pairs):
    assert {k:v for k,v in p.items() if k!='classes'}==old
    if p['kind']=='cog_cog':assert p['classes']==['cog_cog']
    else:
        family=instances[p['owners'][1]]['identity'][0];assert p['classes']==([0,1] if family=='bracket' else [2])
        mapped_modes=[(a['family'],a['mode']) for a in aliases if a['class'] in p['classes']]
        assert mapped_modes==[(family,m['mode']) for m in modes[family]]
cg_regions=load(BASE/'cog-pair-regions.json');assert cg_regions==[r for r in load(SOURCE/'audit/rounded-regions.json') if r['geometry']==10]
expanded=sum(len(cg_regions) if p['kind']=='cog_cog' else sum(sum(r['class']==c for r in rounded) for c in p['classes']) for p in pairs)
required_links=sum(2*len(modes[instances[p['owners'][1]]['identity'][0]]) for p in pairs if p['kind']=='cog_orthogonal')
prep=load(PROCESS/'prepare.json');opened=load(PROCESS/'opened.json');summary=load(BASE/'checks.json')
assert prep['passed'] and prep['exit_code']==0 and prep['job']['closed'] and prep['job']['active_processes']==0 and prep['complete_seconds']<=30
assert prep['complete_seconds']>=summary['seconds_including_evidence_serialization'] and summary['seconds_including_evidence_serialization']<=20
for p,h in opened['inputs'].items():assert digest(ROOT/p)==h
assert summary['conditional_alias_coordinate_links']==required_links==2304 and not opened['repeat_permitted']
for name,data in [('rounded-regions.json',rounded),('source-supports.json',proofs),('disabled-regions.json',disabled),('source-bindings.json',bindings)]:write(OUT/name,data)
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',JOB,PIECES]+list(BASE.glob('*.json'))+[PROCESS/n for n in ['opened.json','prepare.json','prepare-job.json','prepare-stdout.txt','prepare-stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently reconstruct every original binary64 affine outline and convex source piece. Prove exact signed-permutation isometry and integer inverse for all12 source modes, derive all192 endpoint controls and full relative coordinate domains. In coordinates z=Qd+K, use fixed source Q*A+K and moving source Q*B; every retained region and all4 aliases in its class require exact rational support separation of their actual pieces. Whole hulls count only when independently proved separated. Verify all258 physical pair mappings, original cog template bytes and all108 mode options. No equality of floating rotated source outlines, continuous coverage, full66 placement or model execution is assumed.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings_verified':len(bindings),'quarter_turn_source_aliases':12,'exact_isometries_and_integer_inverses':12,'coordinate_endpoint_controls':map_controls,'maximum_coordinate_alignment_rounding_mm':float(max_error),'new_templates':3,'rounded_new_regions':len(rounded),'disabled_new_regions':len(disabled),'retained_cog_pair_regions':len(cg_regions),'exact_original_source_support_proofs':len(proofs),'whole_hull_proofs':whole,'piecewise_proofs':piecewise,'minimum_certified_source_gap_mm':minimum_gap,'cog_interaction_pairs':258,'source_mode_options':108,'required_conditional_coordinate_links':required_links,'expanded_region_choices_after_disabled':expanded,'earlier_expanded_region_choices_before_disabled':load(SOURCE/'checks.json')['expanded_cog_region_choices'],'complete_canonical_preparation_seconds':prep['complete_seconds'],'complete_prior_geometry_preparation_seconds':load(SOURCE/'audit/checks.json')['complete_geometry_preparation_seconds'],'all_original_modes_and_identities_retained':True,'independent_model_audit_still_required':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
