"""Independent source-domain, original-polygon and rational region-support readback."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from datetime import datetime,timezone
from hashlib import sha256
from copy import deepcopy
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import hull
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-twelve-cog-geometry-20261107';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';PROCESS=ROOT/'output/h5-independent-twelve-cog-geometry-process-20261107'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json']:queue.append(z)
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(PRE/'plan.json');inventory=load(BASE/'inventory.json');modes=load(BASE/'family-modes.json');old_modes=load(PRE/'family-modes.json');library=load(PRE/'geometry-library.json');canonical=load(PIECES)
assert inventory==load(PRE/'inventory.json') and load(PRE/'audit/checks.json')['passed']
fixed=load(PRE/'fixed29.json');short=load(PRE/'short9-source.json');instances=load(BASE/'instances.json')
expected_ids=inventory['moving16_orthogonal_identities']+inventory['required_cog12_identities'];assert len(instances)==28
assert instances==[{'owner':i,'identity':x,'mode_count':len(old_modes[x[0]])} for i,x in enumerate(expected_ids)]
full={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
assert len(full)==66 and len(fixed)==29 and len(short)==9 and len(set(map(tuple,expected_ids)))==28
assert full=={(r['part_id'],r['copy_index']) for r in fixed+short}|set(map(tuple,expected_ids))
assert not {(r['part_id'],r['copy_index']) for r in fixed+short}&set(map(tuple,expected_ids))
def affine(points,m):
    c,s=map(F,[math.cos(m['rotation_radians']),math.sin(m['rotation_radians'])]);sgn=-1 if m['mirrored'] else 1
    tx,ty=map(F,m['translation_from_lower_left'] if 'translation_from_lower_left' in m else m['translation'])
    return [(tx+sgn*F(x)*c-F(y)*s,ty+sgn*F(x)*s+F(y)*c) for x,y in points]
stock=list(map(F,spec['construction_stock']));safe=[stock[0]+F(1,40),stock[1]+F(1,40),stock[2]-F(1,40),stock[3]-F(1,40)];eps=F(1,1000000)
top=max(v[1] for r in fixed for v in affine(parts[r['part_id']]['geometry'][0]['outer'],r['transform']))
domain=load(BASE/'domain.json');assert list(map(F,domain['safe_world_bounds_mm']))==safe and F(domain['core_top_mm'])==top and not domain['cartesian_product_collision_free'] and domain['cog_position_variables']==24
assert safe[1]-top>F(spec['required_pair_gap_mm'])
mode_data={};stock_bound_checks=0
for family,items in modes.items():
    assert len(items)==len(old_modes[family])
    source=Polygon(parts[family]['geometry'][0]['outer']);cp=[Polygon(p) for p in canonical[family]]
    assert unary_union(cp).symmetric_difference(source).area<1e-7 and abs(sum(p.area for p in cp)-source.area)<1e-7
    for m,original in zip(items,old_modes[family]):
        assert {k:v for k,v in m.items() if k not in ['individual_grid_bounds','exact_normalized_source_bounds_mm']}==original
        outer=affine(parts[family]['geometry'][0]['outer'],m);b=[min(p[k] for p in outer) for k in [0,1]]+[max(p[k] for p in outer) for k in [0,1]]
        assert list(map(F,m['exact_normalized_source_bounds_mm']))==b
        for k,(lo,hi) in enumerate(m['individual_grid_bounds']):
            assert F(lo,100)>=safe[k]-b[k]+eps>F(lo-1,100)
            assert F(hi,100)<=safe[k+2]-b[k+2]-eps<F(hi+1,100);stock_bound_checks+=2
        shape=Polygon([(float(x),float(y)) for x,y in outer]);assert shape.hausdorff_distance(Polygon(library[m['normalized_geometry']]['outer']))<1e-9
        mode_data[family,m['mode']]={'mode':m,'outer':outer,'hull':hull(outer),'pieces':[affine(p,m) for p in canonical[family]]}
assert stock_bound_checks==52
counts={'pairs':0,'stock_edges':0,'holes':0,'hole_vertices':0};minimum_pair=math.inf;minimum_stock=math.inf
def read_source(source,previous,expected):
    global minimum_pair,minimum_stock
    assert len(source)==len(expected) and {(r['part_id'],r['copy_index']) for r in source}==set(expected)
    shapes=[];local={k:0 for k in counts};lgap=lstock=math.inf
    for r in source:
        part=parts[r['part_id']];t=r['transform'];ang=t['rotation_radians'];assert not t['mirrored'] or part['allow_mirror']
        assert part['rotations']['kind']=='free' or any(abs(math.remainder(ang-math.radians(v),math.tau))<1e-12 for v in part['rotations']['degrees'])
        c,s=math.cos(ang),math.sin(ang);sign=-1 if t['mirrored'] else 1
        def ring(points):return [(sign*x*c-y*s+t['translation'][0],sign*x*s+y*c+t['translation'][1]) for x,y in points]
        geom=part['geometry'][0];outer=Polygon(ring(geom['outer']));material=Polygon(ring(geom['outer']),[ring(h) for h in geom.get('holes',[])])
        assert outer.is_valid and material.is_valid and abs(material.area-Polygon(geom['outer'],geom.get('holes',[])).area)<1e-6
        bounds=outer.bounds;st=spec['source_stocks'][r['sheet_id']];margin=min(bounds[0]-st[0],bounds[1]-st[1],st[2]-bounds[2],st[3]-bounds[3]);assert margin>spec['stock_guard_mm']
        lstock=min(lstock,margin);local['stock_edges']+=4;local['holes']+=len(geom.get('holes',[]));local['hole_vertices']+=sum(len(h) for h in geom.get('holes',[]));shapes.append((r['sheet_id'],outer))
    for (sa,a),(sb,b) in combinations(shapes,2):
        if sa!=sb:continue
        gap=a.distance(b);assert a.disjoint(b) and gap>spec['required_pair_gap_mm'];lgap=min(lgap,gap);local['pairs']+=1
    assert previous['valid'] and previous['originals']==len(source) and previous['same_sheet_pairs']==local['pairs'] and previous['cutouts']==local['holes'] and previous['hole_vertices']==local['hole_vertices']
    assert abs(previous['minimum_pair_gap_mm']-lgap)<1e-12 and abs(previous['minimum_extra_stock_mm']-lstock)<1e-12
    for k,v in local.items():counts[k]+=v
    minimum_pair=min(minimum_pair,lgap);minimum_stock=min(minimum_stock,lstock)
controls=load(BASE/'controls.json');assert len(controls)==52
representative={'bracket':expected_ids[0],'insert':next(x for x in expected_ids if x[0]=='insert'),'cog':expected_ids[16]};ci=0
for family,items in modes.items():
    for m in items:
        for corner,xy in enumerate(product(*m['individual_grid_bounds'])):
            control=controls[ci];ci+=1;assert (control['family'],control['mode'],control['corner'],control['position_grid'])==(family,m['mode'],corner,list(xy))
            source=load(BASE/control['source']);assert source[:29]==fixed and source[30:]==short;r=source[29]
            assert [r['part_id'],r['copy_index']]==representative[family] and r['sheet_id']=='sheet-0'
            assert r['transform']=={'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':[xy[k]/100+m['translation_from_lower_left'][k] for k in [0,1]]}
            read_source(source,load(BASE/control['checks']),[(r['part_id'],r['copy_index']) for r in source])
assert counts['pairs']==24492
reference=load(BASE/'reference50-source.json');assert reference[:29]==fixed and reference[41:]==short
positions=load(BASE/'control-positions.json');cg=modes['cog'][0];base=[b[0] for b in cg['individual_grid_bounds']]
assert positions==[[base[0]+col*26000+row,base[1]+row*26000] for col in range(4) for row in range(3)]
for r,identity,xy in zip(reference[29:41],inventory['required_cog12_identities'],positions):
    assert [r['part_id'],r['copy_index']]==identity and r['sheet_id']=='sheet-0'
    assert r['transform']=={'rotation_radians':cg['rotation_radians'],'mirrored':cg['mirrored'],'translation':[xy[k]/100+cg['translation_from_lower_left'][k] for k in [0,1]]}
    assert all(lo<=xy[k]<=hi for k,(lo,hi) in enumerate(cg['individual_grid_bounds']))
assert all(a[0]<b[0] for a,b in zip(positions,positions[1:]))
read_source(reference,load(BASE/'reference50-checks.json'),full-set(map(tuple,inventory['moving16_orthogonal_identities'])))
bounds=load(BASE/'geometry-grid-bounds.json')
for gid in range(11):
    opts=[m for v in modes.values() for m in v if m['normalized_geometry']==gid]
    assert bounds[str(gid)]==[[min(m['individual_grid_bounds'][k][0] for m in opts),max(m['individual_grid_bounds'][k][1] for m in opts)] for k in [0,1]]
expected_pairs=[{'owners':[a,b],'geometries':sorted({m['normalized_geometry'] for m in modes[expected_ids[b][0]]}),'kind':'cog_orthogonal'} for a in range(16,28) for b in range(16)]
expected_pairs.extend({'owners':[a,b],'geometries':[10],'kind':'cog_cog'} for a,b in combinations(range(16,28),2))
assert load(BASE/'owner-pairs.json')==expected_pairs and len(expected_pairs)==258
assert len(set(tuple(sorted(p['owners'])) for p in expected_pairs))==258
assert len(list(combinations(range(28),2)))==258+120
def nfp(a,b):return MultiPoint((np.asarray(a,dtype=float)[:,None,:]-np.asarray(b,dtype=float)[None,:,:]).reshape(-1,2)).convex_hull
def certify(region,shape,moving,fixed,obstacle):
    line=list(shapely.shortest_line(obstacle,shape).coords)
    if len(line)!=2:return None
    dx,dy=line[1][0]-line[0][0],line[1][1]-line[0][1];length=math.hypot(dx,dy)
    if not length:return None
    normal=[dx/length,dy/length];nx,ny=map(F,normal);norm=nx*nx+ny*ny
    gap=min(x*nx+y*ny for x,y in region)+min(x*nx+y*ny for x,y in moving)-max(x*nx+y*ny for x,y in fixed)
    if gap<=0 or gap*gap<F('.225')**2*norm:return None
    return normal,float(gap)/math.sqrt(float(norm))
templates=load(BASE/'templates.json');assert len(templates)==11;rounded=[];proofs=[];disabled=[];minimum_gap=math.inf;control_regions=[]
A=mode_data['cog',0];cache={};whole=piecewise=0
for gid,t in enumerate(templates):
    assert t['geometry']==gid and t['fixed_geometry']==10 and t['relative_coordinate']=='lower_left_B_minus_lower_left_A' and t['cog_x_order_applied']==(gid==10)
    ba,bb=bounds['10'],bounds[str(gid)];difference=[[bb[k][0]-ba[k][1],bb[k][1]-ba[k][0]] for k in [0,1]]
    if gid==10:difference[0][0]=0
    assert t['relative_grid_bounds']==difference and list(map(F,t['domain_mm']))==[F(difference[0][0],100),F(difference[1][0],100),F(difference[0][1],100),F(difference[1][1],100)]
    aliases=[(key,v) for key,v in mode_data.items() if v['mode']['normalized_geometry']==gid]
    for ri,r in enumerate(t['regions']):
        assert r['region']==ri
        vertices=hull([tuple(F(round(x,9)) for x in p) for p in r['vertices']])
        if len(vertices)<3:disabled.append([gid,ri]);continue
        shape=Polygon([(float(x),float(y)) for x,y in vertices]);assert shape.is_valid and shape.area>0
        rounded.append({'geometry':gid,'region':ri,'kind':r['kind'],'hull_vertices':[[str(x),str(y)] for x,y in vertices]})
        for key,B in aliases:
            ck=(key,-1,-1)
            if ck not in cache:cache[ck]=nfp(A['hull'],B['hull'])
            result=certify(vertices,shape,B['hull'],A['hull'],cache[ck])
            if result:
                n,gap=result;proofs.append([gid,ri,*key,-1,-1,*n]);minimum_gap=min(minimum_gap,gap);whole+=1;continue
            for bi,piece in enumerate(B['pieces']):
                ck=(key,-1,bi)
                if ck not in cache:cache[ck]=nfp(A['hull'],piece)
                result=certify(vertices,shape,piece,A['hull'],cache[ck])
                if result:
                    n,gap=result;proofs.append([gid,ri,*key,-1,bi,*n]);minimum_gap=min(minimum_gap,gap);piecewise+=1;continue
                for ai,ap in enumerate(A['pieces']):
                    ck=(key,ai,bi)
                    if ck not in cache:cache[ck]=nfp(ap,piece)
                    result=certify(vertices,shape,piece,ap,cache[ck]);assert result,(gid,ri,key,ai,bi)
                    n,gap=result;proofs.append([gid,ri,*key,ai,bi,*n]);minimum_gap=min(minimum_gap,gap);piecewise+=1
    assert time.perf_counter()-started<85
for ia,ib in combinations(range(12),2):
    delta=[F(positions[ib][k]-positions[ia][k],100) for k in [0,1]];found=[]
    for r in rounded:
        if r['geometry']!=10:continue
        v=[tuple(map(F,p)) for p in r['hull_vertices']]
        if all((b[0]-a[0])*(delta[1]-a[1])-(b[1]-a[1])*(delta[0]-a[0])>=0 for a,b in zip(v,v[1:]+v[:1])):found.append(r['region'])
    assert found,(ia,ib,delta);control_regions.append({'cog_owners':[16+ia,16+ib],'relative_position_grid':[int(d*100) for d in delta],'containing_regions':found})
prep=load(PROCESS/'prepare.json');opened=load(PROCESS/'opened.json');summary=load(BASE/'checks.json')
assert prep['passed'] and prep['exit_code']==0 and prep['job']['closed'] and prep['job']['active_processes']==0 and prep['complete_seconds']<=40
assert prep['complete_seconds']>=summary['seconds_including_evidence_serialization'] and summary['seconds_including_evidence_serialization']<=30
for p,h in opened['inputs'].items():assert digest(ROOT/p)==h
assert not opened['repeat_permitted'] and summary['cached_regions']==sum(len(t['regions']) for t in templates)
expanded=sum(len(templates[g]['regions']) for p in expected_pairs for g in p['geometries']);assert summary['expanded_cog_region_choices']==expanded
for name,data in [('rounded-regions.json',rounded),('source-supports.json',proofs),('disabled-regions.json',disabled),('control-regions.json',control_regions),('source-bindings.json',bindings)]:write(OUT/name,data)
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',JOB,PIECES]+list(BASE.glob('*.json'))+[PROCESS/n for n in ['opened.json','prepare.json','prepare-job.json','prepare-stdout.txt','prepare-stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independent exact affine source extrema and neighbouring excluded grid bounds for every source mode. Reconstruct every original outline and cutout in52 individual corner controls and the50-original grid control; verify all same-sheet pairs and stock margins. Check all258 original cog pair mappings and every relative-domain endpoint; account for120 remaining orthogonal pairs. For each rounded convex region and every source-mode alias, prove exact rational support separation from original transformed source pieces, using whole hulls only where their stronger separation is proved. Check all66 cog-control differences belong to certified source-safe regions. No global free-space coverage, full66 feasibility, model or solver claim.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings_verified':len(bindings),'all66_identities_accounted_once':True,'moving_originals':28,'source_modes':13,'source_mode_options':108,'mode_stock_bounds_verified':52,'individual_mode_corner_controls':52,'reference50_controls':1,**counts,
 'minimum_source_gap_mm':minimum_pair,'minimum_extra_stock_mm':minimum_stock,'whole_domain_core_gap_mm':float(safe[1]-top),'cog_interaction_pairs':258,'orthogonal_pairs_still_required':120,'cached_templates':11,'rounded_regions_verified':len(rounded),'disabled_degenerate_regions':len(disabled),'exact_source_support_proofs':len(proofs),'whole_hull_proofs':whole,'piecewise_proofs':piecewise,'minimum_certified_source_gap_mm':minimum_gap,'cog_control_pair_memberships_verified':66,'expanded_cog_region_choices_before_disabled':expanded,
 'complete_geometry_preparation_seconds':prep['complete_seconds'],'source_control_is_not_full66':True,'global_coverage_claimed':False,'new_model_created':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
