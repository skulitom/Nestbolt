"""Fresh individual-cog source domains and compact interaction regions; no solver."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import hull,merge_exact,area
from h5_legacy64_source_readback import audit

ROOT=Path(__file__).resolve().parents[1];PRE=ROOT/'output/h5-first57-direct-short9-20261104'
OUT=ROOT/'output/h5-independent-twelve-cog-geometry-20261107'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def exact(points,m):
    c,s=F(math.cos(m['rotation_radians'])),F(math.sin(m['rotation_radians']));sign=-1 if m['mirrored'] else 1
    tx,ty=map(F,m.get('translation_from_lower_left',m.get('translation')))
    return [(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in points]
def exterior(domain,a,b):
    a,b=tuple(map(F,a)),tuple(map(F,b));x0,y0,x1,y1=map(F,domain)
    poly=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)];out=[]
    cross=lambda p:(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
    for p,q in zip(poly,poly[1:]+poly[:1]):
        cp,cq=cross(p),cross(q)
        if cp<=0:out.append(p)
        if (cp<0<cq) or (cq<0<cp):
            t=cp/(cp-cq);out.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    out=hull(out)
    return [[float(x),float(y)] for x,y in out] if len(out)>=3 and area(out)>0 else None

assert load(PRE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py',JOB]+[PRE/n for n in ['plan.json','audit/plan.json','audit/checks.json','fixed29.json','short9-source.json','inventory.json','family-modes.json','geometry-library.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
 'method':'Fresh construction for fixed29 plus directly constructed short9: twelve cogs move independently at the declared7-degree source phase, alongside eight brackets and eight inserts with every original quarter-turn/mirror mode. Derive inward0.01mm grid domains from exact original affine extrema and a0.025mm stock/core reserve. Check all52 individual mode-domain corners and a deterministic4-column/3-level50-original control at260mm pitch. Prepare ten cog-to-orthogonal geometry templates and one identical-cog template; cover the inflated convex hull exterior by clipped halfplanes and triangulate only concave pockets. All258 original pairs involving cogs must be coupled later; all120 orthogonal pairs remain mandatory through audited rigid rectangles. No rigid cog-row constraints, fixed reference-site masks or source exclusions transfer. Earlier closed thirteen-cog/short11 and twelve-cog rigid-row calls stay closed. No solver/model is opened.',
 'grid_units_per_mm':100,'extra_stock_mm':'0.025','inward_reserve_mm':'0.000001','square_halfwidth_mm':.226,'required_certified_gap_mm':.225,
 'preparation_target_seconds':30,'complete_process_cap_seconds':40,'independent_audit_cap_seconds':90,'future_algorithm_seconds':60,'future_shared_seconds':90,
 'future_maximum_calls':1,'retry_permitted':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(PRE/'plan.json');inventory=load(PRE/'inventory.json')
fixed=load(PRE/'fixed29.json');short=load(PRE/'short9-source.json');modes=deepcopy(load(PRE/'family-modes.json'));library=load(PRE/'geometry-library.json')
stock=list(map(F,spec['construction_stock']));safe=[stock[0]+F(1,40),stock[1]+F(1,40),stock[2]-F(1,40),stock[3]-F(1,40)];eps=F(1,1000000);grid=100
core_top=max(v[1] for r in fixed for v in exact(parts[r['part_id']]['geometry'][0]['outer'],r['transform']))
assert safe[1]-core_top>F(spec['required_pair_gap_mm'])
instances=[{'owner':i,'identity':x,'mode_count':len(modes[x[0]])} for i,x in enumerate(inventory['moving16_orthogonal_identities']+inventory['required_cog12_identities'])]
assert len(instances)==28 and sum(r['mode_count'] for r in instances)==108
controls=[];representatives={'bracket':inventory['moving16_orthogonal_identities'][0],'insert':next(x for x in inventory['moving16_orthogonal_identities'] if x[0]=='insert'),'cog':inventory['required_cog12_identities'][0]}
def pose(identity,mode,xy):
    return {'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]/grid+mode['translation_from_lower_left'][k] for k in [0,1]]}}
for family,items in modes.items():
    for m in items:
        v=exact(parts[family]['geometry'][0]['outer'],m);bounds=[min(p[k] for p in v) for k in [0,1]]+[max(p[k] for p in v) for k in [0,1]]
        domain=[[math.ceil((safe[k]-bounds[k]+eps)*grid),math.floor((safe[k+2]-bounds[k+2]-eps)*grid)] for k in [0,1]]
        assert all(lo<hi for lo,hi in domain);m['individual_grid_bounds']=domain;m['exact_normalized_source_bounds_mm']=[str(x) for x in bounds]
        for corner,xy in enumerate(product(*domain)):
            source=fixed+[pose(representatives[family],m,xy)]+short
            check=audit(job,source,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in source]);assert check['valid']
            stem=f'{family}-{m["mode"]}-corner-{corner}';write(OUT/(stem+'-source.json'),source);write(OUT/(stem+'-checks.json'),check)
            controls.append({'family':family,'mode':m['mode'],'corner':corner,'position_grid':xy,'source':stem+'-source.json','checks':stem+'-checks.json'})
        assert time.perf_counter()-started<30
cg=modes['cog'][0];base=[b[0] for b in cg['individual_grid_bounds']]
positions=[[base[0]+col*26000+row,base[1]+row*26000] for col in range(4) for row in range(3)]
cogs=[pose(identity,cg,xy) for identity,xy in zip(inventory['required_cog12_identities'],positions)]
assert all(all(lo<=xy[k]<=hi for k,(lo,hi) in enumerate(cg['individual_grid_bounds'])) for xy in positions)
reference=fixed+cogs+short;missing=set(map(tuple,inventory['moving16_orthogonal_identities']));full={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
assert len(reference)==50 and {(r['part_id'],r['copy_index']) for r in reference}==full-missing
check=audit(job,reference,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],full-missing);write(OUT/'reference50-source.json',reference);write(OUT/'reference50-checks.json',check);assert check['valid']
write(OUT/'control-positions.json',positions)
write(OUT/'domain.json',{'safe_world_bounds_mm':[str(x) for x in safe],'core_top_mm':str(core_top),'cartesian_product_collision_free':False,'cog_position_variables':24,'source_control_is_not_full66':True})
geometry_bounds={}
for gid in range(11):
    aliases=[m for opts in modes.values() for m in opts if m['normalized_geometry']==gid];assert aliases
    geometry_bounds[gid]=[[min(m['individual_grid_bounds'][k][0] for m in aliases),max(m['individual_grid_bounds'][k][1] for m in aliases)] for k in [0,1]]
square=np.asarray([[-.226,-.226],[.226,-.226],[.226,.226],[-.226,.226]])
templates=[];obstacles=[]
for gid in range(11):
    A,B=geometry_bounds[10],geometry_bounds[gid];bounds=[[B[k][0]-A[k][1],B[k][1]-A[k][0]] for k in [0,1]]
    if gid==10:bounds[0][0]=0
    domain=[F(bounds[0][0],grid),F(bounds[1][0],grid),F(bounds[0][1],grid),F(bounds[1][1],grid)];pieces=[]
    for a,b in product(library[10]['pieces'],library[gid]['pieces']):
        diff=(np.asarray(a)[:,None,:]-np.asarray(b)[None,:,:]).reshape(-1,2)
        pieces.append(MultiPoint((diff[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
    inflated=unary_union(pieces);envelope=inflated.convex_hull;outer=hull([tuple(map(F,p)) for p in envelope.exterior.coords[:-1]])
    regions=[];kinds=[]
    for a,b in zip(outer,outer[1:]+outer[:1]):
        r=exterior(domain,a,b)
        if r is not None:regions.append(r);kinds.append('convex_exterior_halfplane')
    pockets=envelope.difference(inflated).intersection(box(*map(float,domain)))
    triangles=[p for p in shapely.constrained_delaunay_triangles(pockets).geoms if p.area>0]
    merged,merges=merge_exact(triangles) if triangles else ([],0)
    regions.extend(merged);kinds.extend(['concave_pocket']*len(merged));assert regions
    free=box(*map(float,domain)).difference(inflated);combined=unary_union([Polygon(p) for p in regions])
    raw_error=combined.symmetric_difference(free).area
    snapped=shapely.symmetric_difference(shapely.union_all([Polygon(p) for p in regions],grid_size=1e-8),shapely.difference(box(*map(float,domain)),inflated,grid_size=1e-8),grid_size=1e-8).area
    assert inflated.is_valid and free.is_valid and snapped<1e-4,(gid,raw_error,snapped)
    templates.append({'geometry':gid,'fixed_geometry':10,'relative_coordinate':'lower_left_B_minus_lower_left_A','relative_grid_bounds':bounds,'domain_mm':[str(x) for x in domain],'cog_x_order_applied':gid==10,
       'regions':[{'region':i,'kind':kind,'vertices':r} for i,(kind,r) in enumerate(zip(kinds,regions))],'exterior_regions':kinds.count('convex_exterior_halfplane'),'pocket_regions':kinds.count('concave_pocket'),'pocket_triangles':len(triangles),'exact_merges':merges,'raw_overlay_error_mm2':raw_error,'snapped_overlay_error_mm2':snapped})
    obstacles.append({'geometry':gid,'inflated':mapping(inflated)})
    assert time.perf_counter()-started<30
owner_pairs=[]
for cog in range(16,28):
    for orthogonal in range(16):
        opts=modes[instances[orthogonal]['identity'][0]]
        owner_pairs.append({'owners':[cog,orthogonal],'geometries':sorted({m['normalized_geometry'] for m in opts}),'kind':'cog_orthogonal'})
for a,b in combinations(range(16,28),2):owner_pairs.append({'owners':[a,b],'geometries':[10],'kind':'cog_cog'})
assert len(owner_pairs)==258
for name,data in [('family-modes.json',modes),('instances.json',instances),('inventory.json',inventory),('controls.json',controls),('geometry-grid-bounds.json',geometry_bounds),('templates.json',templates),('obstacles.json',obstacles),('owner-pairs.json',owner_pairs)]:write(OUT/name,data)
result={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-started,'moving_originals':28,'cogs':12,'orthogonal_companions':16,'source_mode_options':108,'independent_cog_coordinate_variables':24,
 'source_mode_corner_controls':len(controls),'corner_source_pairs':sum(load(OUT/c['checks'])['same_sheet_pairs'] for c in controls),'reference50_source_valid':True,'reference50_pairs':check['same_sheet_pairs'],'reference_control_pitch_mm':260,
 'cog_interaction_pairs':258,'cog_orthogonal_pairs':192,'cog_cog_pairs':66,'orthogonal_pairs_still_required':120,'cached_templates':11,'cached_regions':sum(len(t['regions']) for t in templates),
 'expanded_cog_region_choices':sum(len(templates[g]['regions']) for p in owner_pairs for g in p['geometries']),'independent_source_audit_required':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
