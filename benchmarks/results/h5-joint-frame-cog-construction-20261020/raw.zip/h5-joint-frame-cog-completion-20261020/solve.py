"""One changed, independently reconstructed joint frame/cog model per audited case."""
from datetime import datetime,timezone
import gzip,json,shutil,time
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT,load,write,digest

SRC=ROOT/'output/h5-joint-frame-cog-contacts-20261020'
OUT=ROOT/'output/h5-joint-frame-cog-completion-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'solve.py')
    audit=load(SRC/'audit/checks.json')
    assert audit['passed'] and audit['cases_verified']==8 and audit['all_cliques_pairwise_valid_and_complete']
    cases=load(SRC/'plan.json')['frame_cases']
    sources=[SRC/n for n in ['plan.json','results.json','audit/checks.json']]
    for i in cases:
        sources += [SRC/f'frame-{i}'/n for n in ['mapping.json','new-candidates.json','cliques.jsonl.gz','generation.json']]
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
          'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources},
          'cases':cases,'seconds_per_case':20,'workers':8,'seed':0,
          'method':'Hold each case’s50 original non-cog poses fixed. Require exactly one compatible frame, and jointly select9..15 cogs using every independently audited old/new choice and frame/cog or cog/cog conflict. Maximize the cog count. A complete feasible hint is the original released frame plus nine original cogs. Reconstruct every protobuf model field and verify the hint before one20-second call per case; preserve all callbacks and the final outcome. No retries or extended searches.',
          'native_packing_calls':0,'quality_runs':0})
    results=[]
    for removed in cases:
        src=SRC/f'frame-{removed}'
        folder=OUT/f'frame-{removed}'
        folder.mkdir()
        mp=load(src/'mapping.json')
        ids=mp['candidates']
        local={i:j for j,i in enumerate(ids)}
        frame_indices=sorted(local[i] for i in mp['frame_candidates'])
        cog_indices=sorted(local[i] for i in mp['cog_candidates'])
        assert sorted(frame_indices+cog_indices)==list(range(len(ids)))
        seed=set(mp['seed_cog_candidates'])|{mp['seed_frame_candidate']}
        hint=[int(i in seed) for i in ids]
        with gzip.open(src/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
            original_rows=[json.loads(line) for line in f]
        rows=sorted({tuple(sorted(row)) for row in original_rows})
        model=cp_model.CpModel()
        variables=[model.new_bool_var(f'p{i}') for i in ids]
        for row in rows:
            model.add_at_most_one(variables[j] for j in row)
        model.add_linear_constraint(sum(variables[j] for j in frame_indices),1,1)
        model.add_linear_constraint(sum(variables[j] for j in cog_indices),9,15)
        model.maximize(sum(variables[j] for j in cog_indices))
        for j,value in enumerate(hint):
            model.add_hint(variables[j],value)
        assert model.validate()==''
        model.export_to_file(str(folder/'model.pbtxt'))
        expected=cp_model_pb2.CpModelProto()
        for i in ids:
            v=expected.variables.add()
            v.name=f'p{i}'
            v.domain.extend([0,1])
        for row in sorted(set(tuple(sorted(set(r))) for r in original_rows)):
            expected.constraints.add().at_most_one.literals.extend(row)
        for indices,domain in [(frame_indices,[1,1]),(cog_indices,[9,15])]:
            c=expected.constraints.add().linear
            c.vars.extend(indices)
            c.coeffs.extend([1]*len(indices))
            c.domain.extend(domain)
        expected.objective.vars.extend(cog_indices)
        expected.objective.coeffs.extend([-1]*len(cog_indices))
        expected.objective.scaling_factor=-1
        expected.solution_hint.vars.extend(range(len(ids)))
        expected.solution_hint.values.extend(hint)
        actual=text_format.Parse((folder/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
        assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
        assert sum(hint[j] for j in frame_indices)==1 and sum(hint[j] for j in cog_indices)==9
        assert all(sum(hint[j] for j in row)<=1 for row in rows)
        write(folder/'mapping.json',{'candidates':ids,'fixed_non_cog_candidates':mp['fixed_non_cog_candidates'],
              'frame_local_indices':frame_indices,'cog_local_indices':cog_indices,'complete_hint':hint})
        write(folder/'model-audit.json',{'all_model_fields_independently_reconstructed':True,
              'complete_feasible_seed_verified':True,'variables':len(ids),'constraints':len(actual.constraints),
              'frame_choices':len(frame_indices),'cog_choices':len(cog_indices),
              'model_sha256':digest(folder/'model.pbtxt')})
        solver=cp_model.CpSolver()
        solver.parameters.max_time_in_seconds=20
        solver.parameters.num_search_workers=8
        solver.parameters.random_seed=0
        solver.parameters.log_search_progress=True
        solver.parameters.log_to_stdout=False
        (folder/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
        records=[]
        fixed=mp['fixed_non_cog_candidates']
        frame_set=set(mp['frame_candidates'])
        class Capture(cp_model.CpSolverSolutionCallback):
            def on_solution_callback(self):
                chosen=[i for j,i in enumerate(ids) if self.value(variables[j])]
                frames=[i for i in chosen if i in frame_set]
                assert len(frames)==1
                count=len(chosen)-1
                r={'index':len(records),'removed_frame':removed,'chosen_frame':frames[0],
                   'selected_indices':sorted(fixed+chosen),'cogs':count,'seconds':self.wall_time,
                   'objective':self.objective_value,'best_bound':self.best_objective_bound}
                assert count==r['objective']
                write(folder/f"incumbent-{r['index']}.json",r)
                records.append(r)
                print(json.dumps({k:v for k,v in r.items() if k!='selected_indices'}),flush=True)
        write(folder/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'seconds_limit':20})
        with (folder/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
            solver.log_callback=lambda s:(log.write(s+'\n'),log.flush())
            start=time.perf_counter()
            status=solver.solve(model,Capture())
            seconds=time.perf_counter()-start
        feasible=status in [cp_model.FEASIBLE,cp_model.OPTIMAL]
        result={'removed_frame':removed,'status':solver.status_name(status),'seconds':seconds,
                'incumbents':len(records),'feasible':feasible,'response_stats':solver.response_stats(),
                'full_target_witness':False,'native_margin_qualified':False}
        if feasible:
            chosen=[i for j,i in enumerate(ids) if solver.value(variables[j])]
            frames=[i for i in chosen if i in frame_set]
            assert len(frames)==1
            count=len(chosen)-1
            write(folder/'selected-indices.json',sorted(fixed+chosen))
            result.update(chosen_frame=frames[0],cogs=count,missing_cogs=15-count,
                          best_bound=solver.best_objective_bound,full_inventory_candidate=count==15)
        else:
            assert not records
        write(folder/'result.json',result)
        results.append(result)
        print(json.dumps({k:v for k,v in result.items() if k!='response_stats'}),flush=True)
    write(OUT/'results.json',results)

if __name__=='__main__':
    main()
