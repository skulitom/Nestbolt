"""Audit every returned joint frame/cog layout against original geometry and CLI."""
from collections import Counter,defaultdict
from itertools import combinations
import copy,gzip,json,math,shutil,subprocess
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT,SRC as ORIGINAL,load,write,digest

SOURCE=ROOT/'output/h5-cog-free-region-contacts-20261020-v2'
CONTACTS=ROOT/'output/h5-joint-frame-cog-contacts-20261020'
JOINT=ROOT/'output/h5-joint-full-frame-small-search-20261020'
RUN=ROOT/'output/h5-joint-frame-cog-completion-20261020'
OUT=RUN/'audit'

def layout_key(layout):
    return json.dumps(layout,sort_keys=True,separators=(',',':'))

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'audit.py')
    for p,h in load(RUN/'plan.json')['inputs'].items():
        assert digest(ROOT/p)==h
    assert load(CONTACTS/'audit/checks.json')['passed']
    source=load(SOURCE/'candidates.json')
    job=load(ORIGINAL/'job.json')
    parts={p['id']:p for p in job['parts']}
    stock=job['stocks'][0]
    target=load(ORIGINAL/'conditional-target.json')
    old=load(JOINT/'audit/layout-final.json')
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    cache={layout_key(old):{'layout':JOINT/'audit/layout-final.json',
                           'public':JOINT/'audit/public-final.json','command':JOINT/'audit/command-final.json'}}
    results=[]
    fresh=reused=0
    for result in load(RUN/'results.json'):
        removed=result['removed_frame']
        src=CONTACTS/f'frame-{removed}'
        folder=RUN/f'frame-{removed}'
        dst=OUT/f'frame-{removed}'
        dst.mkdir()
        pool=source+load(src/'new-candidates.json')
        mp=load(src/'mapping.json')
        fixed=set(mp['fixed_non_cog_candidates'])
        ids=mp['candidates']
        local={i:j for j,i in enumerate(ids)}
        frame_choices=set(mp['frame_candidates'])
        with gzip.open(src/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
            cliques=[json.loads(line) for line in f]
        outcomes=[load(folder/f'incumbent-{i}.json') for i in range(result['incumbents'])]
        if result['feasible']:
            final=load(folder/'selected-indices.json')
            if not outcomes or outcomes[-1]['selected_indices']!=final:
                outcomes.append({'index':'final','selected_indices':final,'cogs':result['cogs'],
                                 'chosen_frame':result['chosen_frame']})
        else:
            assert not outcomes
        records=[]
        for r in outcomes:
            chosen=set(r['selected_indices'])
            assert len(chosen)==len(r['selected_indices']) and fixed<=chosen<=fixed|set(ids)
            chosen_frames=(chosen-fixed)&frame_choices
            assert chosen_frames=={r['chosen_frame']}
            chosen_local={local[i] for i in chosen-fixed}
            assert all(len(chosen_local&set(c))<=1 for c in cliques)
            counts=Counter()
            placements=[]
            geoms=defaultdict(list)
            tops=Counter()
            for i in r['selected_indices']:
                p=copy.deepcopy(pool[i]['placement'])
                part,t=parts[p['part_id']],p['transform']
                assert not t['mirrored'] or part['allow_mirror']
                if part['rotations']['kind']=='list':
                    assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9
                               for a in part['rotations']['degrees'])
                p['copy_index']=counts[p['part_id']]
                counts[p['part_id']]+=1
                placements.append(p)
                g=shape(part,t)
                a,b,c,d=g.bounds
                m,edge=stock['margins'],job['edge_clearance']
                height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
                assert g.is_valid and a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7
                assert c<=stock['width']-m['right']-edge+1e-7 and d<=height-m['top']-edge+1e-7
                geoms[p['sheet_id']].append(g)
                tops[p['sheet_id']]=max(tops[p['sheet_id']],d+m['top']+edge)
            assert counts==Counter(frame=18,bracket=12,insert=21,cog=r['cogs']) and 9<=r['cogs']<=15
            minimum=math.inf
            pairs=0
            for gs in geoms.values():
                for a,b in combinations(gs,2):
                    pairs+=1
                    minimum=min(minimum,a.distance(b))
                    assert a.disjoint(b) and a.distance(b)>=job['clearance']-1e-7
            layout={'version':1,'units':'mm','sheets':old['sheets'],'placements':placements}
            index=r['index']
            path=dst/f'layout-{index}.json'
            write(path,layout)
            key=layout_key(layout)
            if key in cache:
                origin=cache[key]
                assert load(origin['layout'])==layout
                public=load(origin['public'])
                code=load(origin['command'])['exit_code']
                write(dst/f'validation-reuse-{index}.json',{
                    'rerun':False,'exact_layout_match':True,
                    'source_files':{str(p.relative_to(ROOT)):digest(p) for p in origin.values()}})
                shutil.copyfile(origin['public'],dst/f'public-{index}.json')
                reused+=1
                reused_here=True
            else:
                cmd=[str(cli),'validate','--library',str(ORIGINAL/'library.json'),
                     '--request',str(ORIGINAL/'request.json'),'--layout',str(path)]
                cp=subprocess.run(cmd,capture_output=True,timeout=60)
                code=cp.returncode
                public_path=dst/f'public-{index}.json'
                command_path=dst/f'command-{index}.json'
                public_path.write_bytes(cp.stdout)
                (dst/f'public-{index}.stderr').write_bytes(cp.stderr)
                write(command_path,{'command':cmd,'exit_code':code})
                public=json.loads(cp.stdout)
                cache[key]={'layout':path,'public':public_path,'command':command_path}
                fresh+=1
                reused_here=False
            assert public['valid']==(r['cogs']==15)
            if r['cogs']<15:
                assert code!=0 and public['violations']==[
                    {'code':'quantity','message':f"part cog: expected 15, found {r['cogs']}"}]
            else:
                assert code==0 and not public['violations']
            material=stock['width']*(stock['height']+tops['sheet-1'])
            assert material<=target['target_material_mm2']+1e-6
            records.append({'incumbent':index,'removed_frame':removed,'chosen_frame':r['chosen_frame'],
                            'frame_changed':r['chosen_frame']!=removed,'cogs':r['cogs'],
                            'missing_cogs':15-r['cogs'],'new_frame_contact_used':r['chosen_frame']>=len(source),
                            'new_cog_contacts_used':sum(i>=len(source) and pool[i]['placement']['part_id']=='cog'
                                                       for i in chosen),
                            'original_geometry_pairs':pairs,'minimum_distance_mm':minimum,
                            'charged_material_mm2':material,'filled_area_mm2':sum(g.area for gs in geoms.values() for g in gs),
                            'original_CLI_valid':public['valid'],'exact_CLI_result_reused':reused_here})
        write(dst/'checks.json',{'passed':True,'records':records,'all_returned_layouts_checked':len(records)})
        results.extend(records)
    checks={'passed':True,'cases_verified':8,'all_returned_layouts_checked':len(results),'records':results,
            'fresh_frozen_CLI_calls':fresh,'exact_frozen_CLI_results_reused':reused,
            'best_cog_count':max(r['cogs'] for r in results),
            'full_target_witness':any(r['original_CLI_valid'] for r in results),
            'native_margin_qualified':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks)
    print(json.dumps({k:v for k,v in checks.items() if k!='records'}))

if __name__=='__main__':
    main()
