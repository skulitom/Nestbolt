"""Independently verify every frame/cog proposal and each conditional conflict graph."""
from collections import Counter,deque
import gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import box,shape as read_shape
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT,SRC as ORIGINAL,load,write,digest

SOURCE=ROOT/'output/h5-cog-free-region-contacts-20261020-v2'
JOINT=ROOT/'output/h5-joint-full-frame-small-search-20261020'
REFINE=ROOT/'output/h5-single-frame-spatial-refinement-20261020'
RUN=ROOT/'output/h5-joint-frame-cog-contacts-20261020'
OUT=RUN/'audit'

def polygons(g):
    if g.is_empty:
        return []
    if g.geom_type=='Polygon':
        return [g]
    return [p for child in g.geoms for p in polygons(child)] if hasattr(g,'geoms') else []

def samples(g):
    out=[]
    seen=set()
    for pi,p in enumerate(polygons(g)):
        point=p.representative_point()
        raw=[{'kind':'representative','polygon':pi,'point':[point.x,point.y]}]
        for ri,ring in enumerate([p.exterior]+list(p.interiors)):
            coords=list(ring.coords)[:-1]
            for vi in range(len(coords)):
                a,b=coords[vi],coords[(vi+1)%len(coords)]
                raw.extend([{'kind':'vertex','polygon':pi,'ring':ri,'vertex':vi,'point':list(a)},
                            {'kind':'edge-midpoint','polygon':pi,'ring':ri,'vertex':vi,
                             'point':[(a[0]+b[0])/2,(a[1]+b[1])/2]}])
        for r in raw:
            key=tuple(float(x).hex() for x in r['point'])
            if key not in seen:
                seen.add(key)
                out.append(r)
    return out

def identity(p):
    t=p['transform']
    return (p['part_id'],p['sheet_id'],t['mirrored'],float(t['rotation_radians']).hex(),
            *(float(x).hex() for x in t['translation']))

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'audit.py')
    plan=load(RUN/'plan.json')
    for p,h in plan['inputs'].items():
        assert digest(ROOT/p)==h
    source=load(SOURCE/'candidates.json')
    assert len(source)==9736 and all(p['index']==i for i,p in enumerate(source))
    job=load(ORIGINAL/'job.json')
    parts={p['id']:p for p in job['parts']}
    stock=job['stocks'][0]
    target=load(ORIGINAL/'conditional-target.json')
    m,edge,clearance=stock['margins'],job['edge_clearance'],job['clearance']
    seed=set(load(JOINT/'selected-indices.json'))
    all_fixed={i for i in seed if source[i]['placement']['part_id']!='cog'}
    seed_cogs=seed-all_fixed
    original_ids=[i for i,p in enumerate(source) if p['placement']['part_id'] in ['frame','cog']]
    base_geometry={i:shape(parts[source[i]['placement']['part_id']],source[i]['placement']['transform'])
                   for i in all_fixed|set(original_ids)}
    pending_nodes=load(REFINE/'pending-nodes.json')
    results=[]
    for saved in load(RUN/'results.json'):
        start=time.perf_counter()
        removed=saved['removed_frame']
        assert removed in plan['frame_cases']
        folder=RUN/f'frame-{removed}'
        mp=load(folder/'mapping.json')
        fixed=all_fixed-{removed}
        assert mp['fixed_non_cog_candidates']==sorted(fixed)
        assert Counter(source[i]['placement']['part_id'] for i in fixed)==Counter(frame=17,bracket=12,insert=21)
        pool=source+load(folder/'new-candidates.json')
        assert all(p['index']==i for i,p in enumerate(pool))
        geometry=dict(base_geometry)
        fixed_here={s:sorted(i for i in fixed if source[i]['placement']['sheet_id']==s)
                    for s in ['sheet-0','sheet-1']}
        expected_filter=[]
        eligible=[]
        fixed_pairs=0
        for i in original_ids:
            p=source[i]['placement']
            blockers=[]
            for j in fixed_here[p['sheet_id']]:
                fixed_pairs+=1
                if geometry[i].distance(geometry[j])<clearance-1e-7:
                    blockers.append(j)
            expected_filter.append({'candidate':i,'fixed_blockers':blockers})
            if not blockers:
                eligible.append(i)
        assert expected_filter==load(folder/'old-filter.json')
        assert eligible==mp['original_eligible_candidates']
        queries=[load(folder/'regions'/f'query-{i}.json') for i in range(saved['queries_completed'])]
        for qi,q in enumerate(queries):
            assert qi==q['index']
            region=read_shape(q['region'])
            assert region.is_valid and region.is_empty==q['region_empty'] and abs(region.area-q['region_area'])<1e-7
            assert samples(region)==q['proposals']
            if qi<2:
                assert q['family']=='frame' and q['axis_class']==[0,90][qi]
                cells=[c for n in pending_nodes if n['removed_candidate']==removed and n['axis_class']==q['axis_class']
                       for c in n['frame_center_cells']]
                original_region=(unary_union([box(*(v/10000 for v in c)) for c in cells])
                                 if cells else shapely.Polygon())
                expected=original_region.buffer(-0.001,join_style='mitre',mitre_limit=5)
                assert expected.equals_exact(region,0)
                assert q['sheet_id']=='sheet-0' and q['rotation_radians']==math.radians(q['axis_class'])
            else:
                assert q['family']=='cog'
                sheet,angle=[(s,a) for s in ['sheet-0','sheet-1'] for a in [0.0,4.5,9.0,13.5]][qi-2]
                assert q['sheet_id']==sheet and q['phase_degrees']==angle and q['rotation_radians']==math.radians(angle)
        queue=deque((q['index'],0) for q in queries if q['proposals'])
        deferred=[]
        caps={'frame':600,'cog':1000}
        counts=Counter()
        keys={identity(p['placement']):i for i,p in enumerate(source)}
        assert len(keys)==len(source)
        added=[]
        proposal_pairs=0
        rejected=0
        for e in load(folder/'source-events.json'):
            while True:
                qi,pi=queue.popleft()
                family=queries[qi]['family']
                if counts[family]>=caps[family]:
                    deferred.append([qi,pi])
                else:
                    break
            assert (qi,pi,family)==(e['query'],e['proposal'],e['family'])
            q=queries[qi]
            x,y=q['proposals'][pi]['point']
            angle=q['rotation_radians']
            if family=='frame':
                c,s=math.cos(angle),math.sin(angle)
                x,y=x-225*c+175*s,y-225*s-175*c
            p={'part_id':family,'sheet_id':q['sheet_id'],
               'transform':{'rotation_radians':angle,'translation':[x,y],'mirrored':False}}
            g=shape(parts[family],p['transform'])
            assert g.is_valid
            a,b,c,d=g.bounds
            height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
            outside=(a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or
                     c>stock['width']-m['right']-edge+1e-7 or d>height-m['top']-edge+1e-7)
            blockers=[]
            for j in fixed_here[p['sheet_id']]:
                proposal_pairs+=1
                if g.distance(geometry[j])<clearance-1e-7:
                    blockers.append(j)
            if outside or blockers:
                rejected+=1
                assert not e['added'] and e['reason']=='original_geometry_rejection'
                assert e['outside']==bool(outside) and e['blockers']==blockers
            elif identity(p) in keys:
                assert not e['added'] and e['reason']=='exact_duplicate' and e['candidate']==keys[identity(p)]
            else:
                assert e['added']
                i=len(source)+len(added)
                assert e['candidate']==i and pool[i]['placement']==p
                assert pool[i]['source']=={'kind':'joint-frame-cog-contact','removed_frame':removed,'query':qi,'proposal':pi}
                assert abs(pool[i]['filled_area_mm2']-g.area)<1e-7
                keys[identity(p)]=i
                geometry[i]=g
                added.append(i)
                counts[family]+=1
            if pi+1<len(q['proposals']):
                queue.append((qi,pi+1))
        expected_pending=sorted([list(x) for x in queue]+deferred)
        assert expected_pending==sorted(load(folder/'pending-queries.json'))
        assert added==mp['new_candidates'] and counts['frame']==saved['new_frames'] and counts['cog']==saved['new_cogs']
        ids=mp['candidates']
        assert ids==sorted(eligible+added)
        for family in ['frame','cog']:
            assert mp[family+'_candidates']==[i for i in ids if pool[i]['placement']['part_id']==family]
        for i in ids:
            p=pool[i]['placement']
            g=geometry[i]
            a,b,c,d=g.bounds
            height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
            assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7
            assert c<=stock['width']-m['right']-edge+1e-7 and d<=height-m['top']-edge+1e-7
        gs=np.asarray([geometry[i] for i in ids],dtype=object)
        bounds=shapely.bounds(gs)
        sheets=np.asarray([pool[i]['placement']['sheet_id'] for i in ids])
        families=np.asarray([pool[i]['placement']['part_id'] for i in ids])
        adjacency=[0]*len(ids)
        edges=set()
        all_pairs=near_pairs=0
        for i in range(len(ids)):
            js=np.arange(i+1,len(ids))
            js=js[(sheets[js]==sheets[i])&((families[js]=='cog')|(families[i]=='cog'))]
            all_pairs+=len(js)
            dx=np.maximum(0,np.maximum(bounds[js,0]-bounds[i,2],bounds[i,0]-bounds[js,2]))
            dy=np.maximum(0,np.maximum(bounds[js,1]-bounds[i,3],bounds[i,1]-bounds[js,3]))
            js=js[np.hypot(dx,dy)<=clearance+1e-7]
            near_pairs+=len(js)
            for j in js[shapely.distance(gs[i],gs[js])<clearance-1e-7]:
                j=int(j)
                edges.add((i,j))
                adjacency[i]|=1<<j
                adjacency[j]|=1<<i
        with gzip.open(folder/'conflicts.jsonl.gz','rt',encoding='utf-8') as f:
            saved_edges=[tuple(json.loads(line)) for line in f]
        assert len(saved_edges)==len(edges) and set(saved_edges)==edges
        covered=[0]*len(ids)
        with gzip.open(folder/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
            cliques=[json.loads(line) for line in f]
        for clique in cliques:
            assert len(clique)==len(set(clique)) and all(0<=i<len(ids) for i in clique)
            mask=sum(1<<i for i in clique)
            for i in clique:
                others=mask^(1<<i)
                assert not(others&~adjacency[i])
                covered[i]|=others
        assert covered==adjacency
        assert mp['seed_frame_candidate']==removed and mp['seed_cog_candidates']==sorted(seed_cogs)
        seed_local={ids.index(i) for i in seed_cogs|{removed}}
        sm=sum(1<<i for i in seed_local)
        assert all(not(adjacency[i]&sm) for i in seed_local)
        record={'removed_frame':removed,'old_filter_pairs_checked':fixed_pairs,
                'proposal_fixed_pairs_checked':proposal_pairs,'rejected_proposals_verified':rejected,
                'queries_and_samples_verified':len(queries),'new_frames_verified':counts['frame'],
                'new_cogs_verified':counts['cog'],'all_eligible_pair_checks':all_pairs,
                'near_pair_distances_checked':near_pairs,'exact_conflicts':len(edges),'cliques':len(cliques),
                'all_conflicts_and_cliques_exact':True,'original_seed_retained':True,
                'pending_query_pointers_verified':len(expected_pending),'seconds':time.perf_counter()-start}
        write(OUT/f'frame-{removed}.json',record)
        results.append(record)
        print(json.dumps(record),flush=True)
    assert [r['removed_frame'] for r in results]==plan['frame_cases']
    checks={'passed':True,'cases_verified':len(results),'records':results,
            'source_pool_unchanged':True,'all_old_filters_verified':True,
            'all_new_frame_and_cog_candidates_verified':True,'all_pair_graphs_recomputed_independently':True,
            'all_cliques_pairwise_valid_and_complete':True,'all_eight_feasible_seeds_retained':True,
            'scope':'Finite constructions only; no complete free-space or infeasibility claim. Exactly one frame must be selected in each later model.',
            'full_target_witness':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks)

if __name__=='__main__':
    main()
