"""New finite frame/cog constructions for the eight unresolved single-frame cases."""
from collections import Counter,deque
from datetime import datetime,timezone
import copy,gzip,heapq,itertools,json,math,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import box,mapping
from shapely.ops import unary_union
from shapely.strtree import STRtree
import diagnose_h5_concave_gaps as gap
from build_h5_cog_free_regions import proposals,identity
from audit_h5_cog_lattices import shape
from census_h5_one_part_moves import bits
from reduce_h5_free_cog_pool import ROOT,SRC as ORIGINAL,load,write,digest

SOURCE=ROOT/'output/h5-cog-free-region-contacts-20261020-v2'
JOINT=ROOT/'output/h5-joint-full-frame-small-search-20261020'
REFINE=ROOT/'output/h5-single-frame-spatial-refinement-20261020'
OUT=ROOT/'output/h5-joint-frame-cog-contacts-20261020'

def make_graph(folder,ids,pool,geometry,clearance):
    gs=np.asarray([geometry[i] for i in ids],dtype=object)
    families=np.asarray([pool[i]['placement']['part_id'] for i in ids])
    adjacency=[0]*len(ids)
    edges=[]
    near=0
    for sheet in ['sheet-0','sheet-1']:
        local=np.asarray([j for j,i in enumerate(ids) if pool[i]['placement']['sheet_id']==sheet],dtype=int)
        if not len(local):
            continue
        tree=STRtree(gs[local])
        pairs=tree.query(gs[local],predicate='dwithin',distance=clearance+1e-7)
        a,b=local[pairs[0]],local[pairs[1]]
        take=(a<b)&((families[a]=='cog')|(families[b]=='cog'))
        a,b=a[take],b[take]
        near+=len(a)
        keep=shapely.distance(gs[a],gs[b])<clearance-1e-7
        for i,j in zip(a[keep],b[keep]):
            i,j=int(i),int(j)
            edges.append((i,j))
            adjacency[i]|=1<<j
            adjacency[j]|=1<<i
    remaining=adjacency.copy()
    heap=[(-a.bit_count(),i) for i,a in enumerate(remaining) if a]
    heapq.heapify(heap)
    cliques=[]
    covered=0
    start=time.perf_counter()
    while heap and time.perf_counter()-start<10:
        degree,i=heapq.heappop(heap)
        if -degree!=remaining[i].bit_count() or not remaining[i]:
            continue
        choices=remaining[i]
        clique=[i]
        mask=1<<i
        while choices:
            sample=list(itertools.islice(bits(choices),16))
            j=max(sample,key=lambda v:((adjacency[v]&choices).bit_count(),-v))
            clique.append(j)
            mask|=1<<j
            choices&=adjacency[j]
        assert all(not((mask^(1<<j))&~adjacency[j]) for j in clique)
        cliques.append(clique)
        for j in clique:
            before=remaining[j].bit_count()
            remaining[j]&=~mask
            covered+=before-remaining[j].bit_count()
            if remaining[j]:
                heapq.heappush(heap,(-remaining[j].bit_count(),j))
    compressed=len(cliques)
    residual=0
    for i,mask in enumerate(remaining):
        for j in bits(mask&~((1<<(i+1))-1)):
            cliques.append([i,j])
            residual+=1
    assert covered//2+residual==len(edges)
    for name,rows in [('conflicts.jsonl.gz',sorted(edges)),('cliques.jsonl.gz',cliques)]:
        with gzip.open(folder/name,'xt',encoding='utf-8',newline='\n') as f:
            for row in rows:
                f.write(json.dumps(row)+'\n')
    return adjacency,{'conflict_edges':len(edges),'near_pair_distances':near,
                      'compressed_cliques':compressed,'residual_pair_constraints':residual,
                      'clique_limit_reached':bool(heap),'compression_and_write_seconds':time.perf_counter()-start}

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'build.py')
    sources=[SOURCE/n for n in ['candidates.json','audit/checks.json']]
    sources += [JOINT/n for n in ['selected-indices.json','audit/checks.json']]
    sources += [REFINE/n for n in ['pending-nodes.json','audit/checks.json']]
    sources += [ORIGINAL/n for n in ['job.json','conditional-target.json']]
    sources += [ROOT/'output/build_h5_cog_free_regions.py',ROOT/'output/diagnose_h5_concave_gaps.py']
    proof=load(REFINE/'audit/checks.json')
    assert proof['passed']
    cases=[r['candidate'] for r in proof['frame_proofs'] if not r['single_frame_move_ruled_out']]
    assert len(cases)==8
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
          'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources},'frame_cases':cases,
          'per_case_generation_seconds':120,'maximum_new_frames_per_case':600,
          'maximum_new_cogs_per_case':1000,'clique_seconds_per_case':10,
          'frame_center_region_erosion_mm':0.001,'cog_phases_degrees':[0.0,4.5,9.0,13.5],
          'method':'For each unresolved frame, hold the other50 non-cog poses fixed. Preserve every original source candidate unchanged and retain every old frame/cog pose compatible with those50. The old frame and all nine seed cogs are mandatory retained controls. Union that frame case’s remaining pending center cells by axis class, erode by0.001mm for positive construction margin, and sample each polygon representative point, boundary vertex and edge midpoint. Use canonical0/90-degree frame transforms with the recorded local center; original poses retain their original rotation. Generate cog translation regions at four phases on both target sheets around the50 fixed non-cogs. Process samples round-robin under the declared per-family caps and time. Every proposal receives original stock and fixed-neighbour geometry checks. No absence is an impossibility proof.',
          'graph':'Recompute every same-sheet cog/cog and frame/cog conflict from original geometry. Frame/frame pairs are omitted because the model will require exactly one frame; they are never represented as geometric conflicts. Compress verified cliques up to10 seconds and retain all residual edges. Do not reuse the old51-fixed graph.',
          'followup':'After independent candidate/filter/pair-graph audit, one changed20-second joint model per case will require exactly one frame and maximize9..15 cogs, with a complete feasible old-frame/nine-cog hint. No retries or extensions.',
          'native_packing_calls':0,'quality_runs':0})
    source=load(SOURCE/'candidates.json')
    assert len(source)==9736
    job=load(ORIGINAL/'job.json')
    parts={p['id']:p for p in job['parts']}
    target=load(ORIGINAL/'conditional-target.json')
    stock=job['stocks'][0]
    selected=set(load(JOINT/'selected-indices.json'))
    all_fixed={i for i in selected if source[i]['placement']['part_id']!='cog'}
    seed_cogs=selected-all_fixed
    assert len(all_fixed)==51 and len(seed_cogs)==9
    original_ids=[i for i,p in enumerate(source) if p['placement']['part_id'] in ['frame','cog']]
    geometry_base={i:shape(parts[source[i]['placement']['part_id']],source[i]['placement']['transform'])
                   for i in all_fixed|set(original_ids)}
    pending=load(REFINE/'pending-nodes.json')
    results=[]
    for removed in cases:
        folder=OUT/f'frame-{removed}'
        folder.mkdir()
        (folder/'regions').mkdir()
        start=time.perf_counter()
        fixed=all_fixed-{removed}
        assert len(fixed)==50
        fixed_here={s:sorted(i for i in fixed if source[i]['placement']['sheet_id']==s)
                    for s in ['sheet-0','sheet-1']}
        pool=copy.deepcopy(source)
        geometry=dict(geometry_base)
        keys={identity(p['placement']):i for i,p in enumerate(pool)}
        old_filter=[]
        eligible=[]
        for i in original_ids:
            p=source[i]['placement']
            blockers=[j for j in fixed_here[p['sheet_id']]
                      if geometry[i].distance(geometry[j])<job['clearance']-1e-7]
            old_filter.append({'candidate':i,'fixed_blockers':blockers})
            if not blockers:
                eligible.append(i)
        assert {removed}|seed_cogs<=set(eligible)
        queries=[]
        expired=False
        for axis in [0,90]:
            cells=[c for n in pending if n['removed_candidate']==removed and n['axis_class']==axis
                   for c in n['frame_center_cells']]
            region=unary_union([box(*(v/10000 for v in c)) for c in cells]) if cells else shapely.Polygon()
            region=region.buffer(-0.001,join_style='mitre',mitre_limit=5)
            q={'index':len(queries),'family':'frame','axis_class':axis,'sheet_id':'sheet-0',
               'rotation_radians':math.radians(axis),'region':mapping(region),
               'region_empty':region.is_empty,'region_area':region.area,'proposals':proposals(region)}
            write(folder/'regions'/f"query-{q['index']}.json",q)
            queries.append(q)
        for sheet in ['sheet-0','sheet-1']:
            this_stock=copy.deepcopy(stock)
            if sheet=='sheet-1':
                this_stock['height']=target['required_used_height_mm']
            for degrees in [0.0,4.5,9.0,13.5]:
                if time.perf_counter()-start>=120:
                    expired=True
                    break
                angle=math.radians(degrees)
                moving=shape(parts['cog'],{'rotation_radians':angle,'translation':[0,0],'mirrored':False})
                region=gap.regions(moving,[geometry[j] for j in fixed_here[sheet]],
                                   this_stock,job['edge_clearance'],job['clearance'])
                q={'index':len(queries),'family':'cog','phase_degrees':degrees,'sheet_id':sheet,
                   'rotation_radians':angle,'region':mapping(region),'region_empty':region.is_empty,
                   'region_area':region.area,'proposals':proposals(region)}
                write(folder/'regions'/f"query-{q['index']}.json",q)
                queries.append(q)
            if expired:
                break
        queue=deque((q['index'],0) for q in queries if q['proposals'])
        deferred=[]
        events=[]
        added=[]
        added_count=Counter()
        caps={'frame':600,'cog':1000}
        while queue and time.perf_counter()-start<120:
            qi,pi=queue.popleft()
            q=queries[qi]
            family=q['family']
            if added_count[family]>=caps[family]:
                deferred.append([qi,pi])
                continue
            x,y=q['proposals'][pi]['point']
            angle=q['rotation_radians']
            if family=='frame':
                c,s=math.cos(angle),math.sin(angle)
                x,y=x-225*c+175*s,y-225*s-175*c
            p={'part_id':family,'sheet_id':q['sheet_id'],
               'transform':{'rotation_radians':angle,'translation':[x,y],'mirrored':False}}
            g=shape(parts[family],p['transform'])
            a,b,c,d=g.bounds
            m,edge=stock['margins'],job['edge_clearance']
            height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
            outside=(a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or
                     c>stock['width']-m['right']-edge+1e-7 or d>height-m['top']-edge+1e-7)
            blockers=[j for j in fixed_here[p['sheet_id']] if g.distance(geometry[j])<job['clearance']-1e-7]
            event={'query':qi,'proposal':pi,'family':family}
            if outside or blockers:
                event.update(added=False,reason='original_geometry_rejection',outside=bool(outside),blockers=blockers)
            elif identity(p) in keys:
                i=keys[identity(p)]
                assert i in eligible or i in added
                event.update(added=False,reason='exact_duplicate',candidate=i)
            else:
                i=len(pool)
                pool.append({'index':i,'placement':p,'source':{'kind':'joint-frame-cog-contact',
                             'removed_frame':removed,'query':qi,'proposal':pi},'filled_area_mm2':g.area})
                keys[identity(p)]=i
                geometry[i]=g
                added.append(i)
                added_count[family]+=1
                event.update(added=True,candidate=i)
            events.append(event)
            if pi+1<len(q['proposals']):
                queue.append((qi,pi+1))
        generation_seconds=time.perf_counter()-start
        remaining=list(queue)+deferred
        ids=sorted(eligible+added)
        write(folder/'new-candidates.json',pool[len(source):])
        write(folder/'old-filter.json',old_filter)
        write(folder/'source-events.json',events)
        write(folder/'pending-queries.json',remaining)
        mp={'candidates':ids,'fixed_non_cog_candidates':sorted(fixed),
            'frame_candidates':[i for i in ids if pool[i]['placement']['part_id']=='frame'],
            'cog_candidates':[i for i in ids if pool[i]['placement']['part_id']=='cog'],
            'original_eligible_candidates':eligible,'new_candidates':added,
            'seed_frame_candidate':removed,'seed_cog_candidates':sorted(seed_cogs)}
        write(folder/'mapping.json',mp)
        adjacency,graph=make_graph(folder,ids,pool,geometry,job['clearance'])
        seed_local={ids.index(i) for i in seed_cogs|{removed}}
        seedmask=sum(1<<i for i in seed_local)
        assert all(not(adjacency[i]&seedmask) for i in seed_local)
        result={'removed_frame':removed,'old_source_candidates':len(source),
                'old_eligible_frames':sum(source[i]['placement']['part_id']=='frame' for i in eligible),
                'old_eligible_cogs':sum(source[i]['placement']['part_id']=='cog' for i in eligible),
                'new_frames':added_count['frame'],'new_cogs':added_count['cog'],
                'frame_choices':len(mp['frame_candidates']),'cog_choices':len(mp['cog_candidates']),
                'queries_completed':len(queries),'declared_queries':10,'events':len(events),
                'event_outcomes':dict(Counter(e.get('reason','added') for e in events)),
                'pending_queries':len(remaining),'generation_seconds':generation_seconds,
                'generation_limit_reached':expired or bool(queue),'new_pose_cap_reached':bool(deferred),
                'original_seed_retained':True,'full_target_witness':False,
                'total_seconds':time.perf_counter()-start,**graph}
        write(folder/'generation.json',result)
        results.append(result)
        print(json.dumps(result),flush=True)
    write(OUT/'results.json',results)

if __name__=='__main__':
    try:
        main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():
            (OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
