"""Derive separately auditable stronger solver/oracle without changing old calls."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-circle-stock-neighborhood-20261025'
def digest(p):return sha256(p.read_bytes()).hexdigest()
def replace(text,old,new):
    assert text.count(old)==1,(old,text.count(old));return text.replace(old,new)

solver=ROOT/'output/solve_h5_conflict_owner_neighborhood.py'
audit=ROOT/'output/audit_h5_conflict_owner_model.py'
s=solver.read_text(encoding='utf-8');a=audit.read_text(encoding='utf-8')
s=replace(s,'from audit_h5_conflict_owner_model import verify','from audit_h5_circle_stock_model import verify')
s=replace(s,"BASE=ROOT/'output/h5-conflict-owner-neighborhood-20261025'","BASE=ROOT/'output/h5-circle-stock-neighborhood-20261025'")
s=replace(s,"ROOT/'output/audit_h5_conflict_owner_model.py'","ROOT/'output/audit_h5_circle_stock_model.py'")
s=replace(s,'for n in range(20):',"for n in range(len(atlas['normals'])):")
s=replace(s,'all20 independently proved edge normals and complete16-gon cog proxies.',
    'all132 independently proved edge normals and complete128-vertex cog proxies. Every cog uses the certified139.2707mm all-angle stock supports. Add exact109.1mm whole-circle separation for all15 moving-cog pairs using integer squared distances, conditionally on a shared sheet. The circle and polygon are distinct necessary conditions; the convex-hull support disk is never used as collision geometry.')
s=replace(s,"mapping={'parts':parts,'pairs':pairs};write(OUT/'mapping.json',mapping)",'''circles=[]
    for pair in pairs:
        a,b=[parts[i] for i in pair['parts']]
        if a['family']!='cog' or b['family']!='cog':continue
        prefix=f"circle{a['index']}-{b['index']}"
        dx=var(prefix+'-dx',-150000,150000);dy=var(prefix+'-dy',-300000,300000)
        sx=var(prefix+'-dx-squared',0,150000**2);sy=var(prefix+'-dy-squared',0,300000**2)
        linear([(dx,1),(b['x'],-1),(a['x'],1)],0,0)
        linear([(dy,1),(b['y'],-1),(a['y'],1)],0,0)
        model.add_multiplication_equality(vs[sx],[vs[dx],vs[dx]])
        model.add_multiplication_equality(vs[sy],[vs[dy],vs[dy]])
        model.add_linear_constraint(vs[sx]+vs[sy],21820**2,cp_model.INT_MAX).only_enforce_if(vs[pair['different_sheet']].Not())
        circles.append({'parts':pair['parts'],'different_sheet':pair['different_sheet'],
                        'dx':dx,'dy':dy,'dx_squared':sx,'dy_squared':sy,'minimum_squared_distance':21820**2})
    assert len(circles)==15
    mapping={'parts':parts,'pairs':pairs,'circles':circles};write(OUT/'mapping.json',mapping)''')
s=replace(s,'Only this complete57-fixed/9-mandatory-moving neighborhood and source orientation inventory.',
    'Only this complete57-fixed/9-mandatory-moving neighborhood and source orientation inventory, with128-vertex floor-safe proxies, exact cog-circle pair separation and certified all-angle stock bounds.')
a=replace(a,'assert vi==len(actual.variables) and ci==len(actual.constraints)', '''circles=[]
    def square(target,source):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();p.int_prod.target.vars.append(target);p.int_prod.target.coeffs.append(1)
        for _ in range(2):
            e=p.int_prod.exprs.add();e.vars.append(source);e.coeffs.append(1)
        assert actual.constraints[ci]==p,(ci,'exact square');ci+=1
    for pair in pairs:
        a,b=[parts[i] for i in pair['parts']]
        if a['family']!='cog' or b['family']!='cog':continue
        prefix=f"circle{a['index']}-{b['index']}"
        dx=var(prefix+'-dx',-150000,150000);dy=var(prefix+'-dy',-300000,300000)
        sx=var(prefix+'-dx-squared',0,150000**2);sy=var(prefix+'-dy-squared',0,300000**2)
        linear([(dx,1),(b['x'],-1),(a['x'],1)],0,0)
        linear([(dy,1),(b['y'],-1),(a['y'],1)],0,0)
        square(sx,dx);square(sy,dy)
        assert spec['exact_cog_pair_minimum_squared_units100']==(2*10910)**2
        linear([(sx,1),(sy,1)],(2*10910)**2,2**63-1,[-pair['different_sheet']-1])
        circles.append({'parts':pair['parts'],'different_sheet':pair['different_sheet'],
                        'dx':dx,'dy':dy,'dx_squared':sx,'dy_squared':sy,'minimum_squared_distance':(2*10910)**2})
    assert len(circles)==15
    assert vi==len(actual.variables) and ci==len(actual.constraints)''')
a=replace(a,"return {'parts':parts,'pairs':pairs}","return {'parts':parts,'pairs':pairs,'circles':circles}")
a=replace(a,"'separation_normals_per_pair':20,'exact_projection_disjunctions':1060,", "'separation_normals_per_pair':132,'exact_projection_disjunctions':6996,")
a=replace(a,"'support_variables':220,", "'support_variables':1452,'exact_moving_cog_circle_pairs':15,'integer_square_constraints':30,'new_circle_auxiliary_variables':60,")
outputs={ROOT/'output/solve_h5_circle_stock_neighborhood.py':s,ROOT/'output/audit_h5_circle_stock_model.py':a}
for p,text in outputs.items():
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
record={'utc':datetime.now(timezone.utc).isoformat(),'sources':{p.relative_to(ROOT).as_posix():digest(p) for p in [solver,audit]},
        'generated':{p.relative_to(ROOT).as_posix():digest(p) for p in outputs},
        'changes':['Use independently audited128-vertex proxies and132 exact normals','Use independently certified all-angle stock bounds',
                   'Add15 exact whole-circle cog-pair inequalities, with30 independently reconstructed integer square constraints',
                   'Preserve57 fixed originals,9 mandatory moving originals, all modes/sheets, all66 original area charges and the same single60-second budget'],
        'solver_calls':0}
with (BASE/'solver-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
