"""Independent protobuf oracle for all nine mandatory moving originals."""
from collections import Counter
from itertools import combinations,product
from ortools.sat import cp_model_pb2

def verify(actual,spec,queries,atlas,aux):
    vi=ci=domains=modes=planes=component_pairs=0
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]),(vi,name)
        vi+=1;return vi-1
    def linear(terms,lo,hi,en=()):
        nonlocal ci
        merged=Counter()
        for v,c in terms:merged[v]+=c
        ids=sorted(v for v,c in merged.items() if c);p=cp_model_pb2.ConstraintProto()
        p.enforcement_literal.extend(en);p.linear.vars.extend(ids);p.linear.coeffs.extend(merged[v] for v in ids);p.linear.domain.extend([lo,hi])
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    def boolean(kind,ids):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();getattr(p,kind).literals.extend(ids)
        assert actual.constraints[ci]==p,(ci,kind);ci+=1
    parts=[]
    for pi,item in enumerate(spec['movable_parts']):
        name=f'part{pi}';x=var(name+'-x',0,150000);y=var(name+'-y',0,300000);sheet=var(name+'-sheet',0,1);options=[]
        for q in spec['queries']:
            if q['family']!=item['family'] or q['mode'] not in item['allowed_modes']:continue
            prefix=name+f"-q{q['index']}";active=var(prefix+'-active',0,1);ds=[]
            bounds=q['coordinate_bounds'];linear([(x,1)],bounds[0],bounds[2],[active]);linear([(y,1)],bounds[1],bounds[3],[active])
            for face in queries[q['index']]['domains']:
                d=var(prefix+f"-domain{face['index']}",0,1);ds.append(d);bounds=face['coordinate_bounds']
                linear([(x,1)],bounds[0],bounds[2],[d]);linear([(y,1)],bounds[1],bounds[3],[d])
                for h in face['halfplanes']:linear([(x,h['a']),(y,h['b'])],-2**63,h['upper'],[d]);planes+=1
            linear([(d,1) for d in ds]+[(active,-1)],0,0)
            options.append({'query':q['index'],'active':active,'domains':ds,'sheet':q['sheet'],'moving_proxy':q['moving_proxy']});modes+=1;domains+=len(ds)
        assert sorted(spec['queries'][m['query']]['mode'] for m in options)==item['allowed_modes']
        boolean('exactly_one',[m['active'] for m in options])
        linear([(sheet,1)]+[(m['active'],-1) for m in options if m['sheet']],0,0);components=[]
        for arm in range(2 if item['family']=='bracket' else 1):
            support=[]
            for n,(nx,ny) in enumerate(atlas['normals']):
                vals=[max(nx*px+ny*py for px,py in atlas['proxies'][m['moving_proxy']]['components'][arm]) for m in options]
                assert vals==[atlas['proxies'][m['moving_proxy']]['supports'][arm][n] for m in options]
                v=var(name+f'-component{arm}-support{n}',min(vals),max(vals))
                linear([(v,1)]+[(m['active'],-value) for m,value in zip(options,vals)],0,0);support.append(v)
            components.append(support)
        parts.append({'index':pi,'item':item['index'],'family':item['family'],'x':x,'y':y,'sheet':sheet,'modes':options,'components':components})
    assert len(parts)==9 and [p['item'] for p in parts]==[28,29,50,54,57,58,62,64,65]
    charges=[aux['part_areas'][p['family']]['lower_units'] for p in parts]
    linear([(p['sheet'],-charge) for p,charge in zip(parts,charges)],-2**63,
           aux['sheet_capacities'][0]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][0]-sum(charges))
    linear([(p['sheet'],charge) for p,charge in zip(parts,charges)],-2**63,
           aux['sheet_capacities'][1]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][1])
    pairs=[]
    for i,j in combinations(range(9),2):
        a,b=parts[i],parts[j];prefix=f'pair{i}-{j}';different=var(prefix+'-different-sheet',0,1)
        boolean('bool_xor',[a['sheet'],b['sheet'],-different-1])
        for sa,sb in product([0,1],repeat=2):assert [d for d in [0,1] if (sa+sb+1-d)%2]==[int(sa!=sb)]
        ps=[]
        for ai,bi in product(range(len(a['components'])),range(len(b['components']))):
            ds=[];component_pairs+=1
            for n,(nx,ny) in enumerate(atlas['normals']):
                d=var(prefix+f'-components{ai}-{bi}-normal{n}',0,1);ds.append(d)
                opposite=next(k for k,(x,y) in enumerate(atlas['normals']) if (x,y)==(-nx,-ny));assert atlas['opposite_normal_indices'][n]==opposite
                linear([(b['x'],100*nx),(a['x'],-100*nx),(b['y'],100*ny),(a['y'],-100*ny),
                        (a['components'][ai][n],-1),(b['components'][bi][opposite],-1)],0,2**63-1,[d])
            boolean('bool_or',[different]+ds);ps.append({'components':[ai,bi],'directions':ds})
        pairs.append({'parts':[i,j],'different_sheet':different,'component_pairs':ps})
    assert len(pairs)==36 and component_pairs==53
    circles=[]
    def square(target,source):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();p.int_prod.target.vars.append(target);p.int_prod.target.coeffs.append(1)
        for _ in range(2):
            e=p.int_prod.exprs.add();e.vars.append(source);e.coeffs.append(1)
        assert actual.constraints[ci]==p,(ci,'exact square');ci+=1
    for pair in pairs:
        a,b=[parts[i] for i in pair['parts']]
        if a['family']!='cog' or b['family']!='cog':continue
        prefix=f"circle{a['index']}-{b['index']}"
        dx=var(prefix+'-dx',-150000,150000);dy=var(prefix+'-dy',-300000,300000)
        sx=var(prefix+'-dx-squared',0,150000**2);sy=var(prefix+'-dy-squared',0,300000**2)
        linear([(dx,1),(b['x'],-1),(a['x'],1)],0,0)
        linear([(dy,1),(b['y'],-1),(a['y'],1)],0,0)
        square(sx,dx);square(sy,dy)
        assert spec['exact_cog_pair_minimum_squared_units100']==(2*10910)**2
        linear([(sx,1),(sy,1)],(2*10910)**2,2**63-1,[-pair['different_sheet']-1])
        circles.append({'parts':pair['parts'],'different_sheet':pair['different_sheet'],
                        'dx':dx,'dy':dy,'dx_squared':sx,'dy_squared':sy,'minimum_squared_distance':(2*10910)**2})
    assert len(circles)==15
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');assert not extra.ListFields()
    return {'parts':parts,'pairs':pairs,'circles':circles},{'variables':vi,'constraints':ci,'fixed_original_parts':57,'mandatory_movable_parts':9,
        'required_original_parts':66,'role_mode_options':modes,'complete_convex_domain_options':domains,'reified_outward_halfplanes':planes,
        'physical_part_pairs':36,'cross_part_convex_component_pairs':53,'separation_normals_per_pair':132,'exact_projection_disjunctions':6996,
        'support_variables':1452,'exact_moving_cog_circle_pairs':15,'integer_square_constraints':30,'new_circle_auxiliary_variables':60,'original_area_constraints':2,'full_original_stock_bounds_constraints':2*modes,
        'sheet_xor_truth_tables_checked':True,'both_bracket_arms_share_anchor_and_mode':True,
        'hints':0,'objectives':0,'copy_order_constraints':0,'optional_original_parts':0,'same_part_pair_constraints':0,
        'all_permitted_modes_and_sheets_retained':True}
