"""Independent stronger cog containment, cache, full-domain and SAT audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,math,shutil,time,traceback
import shapely
from shapely.geometry import Polygon,MultiPoint,Point,box,shape
from shapely.geometry.polygon import orient
from shapely.affinity import translate
from shapely.ops import unary_union
from audit_h5_strong_pair_domains import hull,admits

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-circle-stock-neighborhood-20261025'
OLD=ROOT/'output/h5-conflict-owner-neighborhood-20261025';SRC=ROOT/'output/h5-source-orientation-construction-20261025'
GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json');result=load(BASE/'result.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(BASE.rglob('*.json')) if OUT not in p.parents},
        'method':'Check immutable inputs and18 reused query bytes against committed evidence. Prove the new128-vertex proxy contains the old16-gon and every vertex over all4 floor-error corners remains within the original all-angle disk. Reconstruct10 new fixed-original/cog obstacles with unmerged original triangles and direct Minkowski hulls; retain100 prior cache entries unchanged. Verify every full original-stock query, its padded coverage, every convex expansion and all rationally rounded inequalities. Rebuild all19 component types, every support and all361 integer Minkowski hulls in the132-normal basis. Preserve every released source pose and diagnose old rejected anchors. The139.2707mm hull support is used only for stock bounds.'})
    start=time.perf_counter();prior=load(OLD/'plan.json');assert load(OLD/'audit/checks.json')['passed'] and load(OLD/'stronger-cog-conditions/audit/checks.json')['passed']
    assert result['queries_completed']==20 and not load(BASE/'pending.json') and not any(result[k] for k in ['merge_cap_queries','merge_time_queries','domain_cap_reached'])
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    manifest=ROOT/'benchmarks/results/h5-conflict-owner-neighborhood-20261025/raw-manifest.json';mf=load(manifest);byhash={r['sha256']:r for r in mf['files']+mf['aliases']};provenance=[]
    trusted=[OLD/n for n in ['plan.json','audit/checks.json','fixed-originals.json','moving-proxies.json','cache-references.json',
              'stronger-cog-conditions/certificate.json','stronger-cog-conditions/audit/checks.json','solve/positions.json']]+[SRC/'hint-poses.json',SRC/'propagation.json',GEO/'fixed-styles.json']
    trusted += [OLD/'queries'/f'{i:04d}.json' for i in range(18)]
    for p in trusted:
        h=digest(p);assert h in byhash,p;provenance.append({'source':p.relative_to(ROOT).as_posix(),'sha256':h,'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':byhash[h]['path']})
    for name,h in plan['reused_query_hashes'].items():assert digest(OLD/'queries'/name)==digest(BASE/'queries'/name)==h
    assert len(plan['reused_query_hashes'])==18
    for key in ['fixed_items','movable_parts','fixed_original_area_units_per_sheet','required_original_counts']:assert plan[key]==prior[key]
    cert=load(OLD/'stronger-cog-conditions/certificate.json');proxies=load(BASE/'moving-proxies.json');oldproxies=load(OLD/'moving-proxies.json')
    assert len(proxies)==11 and all(proxies[i]==oldproxies[i] for i in range(11) if i!=9)
    vertices=proxies[9]['vertices_units10000'];oldvertices=oldproxies[9]['vertices_units10000'];generated=plan['generated128_vertices']
    assert len(generated)==128 and all(x*x+y*y<=1091000**2 for x,y in generated)
    assert hull(vertices)==hull(oldvertices+generated) and len(vertices)==128 and len(set(map(tuple,vertices)))==128
    sq=[(x-ex)**2+(y-ey)**2 for x,y in vertices for ex,ey in product([0,100],repeat=2)]
    assert max(sq)<1091157**2;containment=0
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        for p in vertices+oldvertices:
            assert (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])>=0;containment+=1
    floor=load(BASE/'cog-floor-certificate.json')
    assert floor['vertices_units10000']==vertices and floor['maximum_squared_distance']==max(sq) and floor['strict_squared_margin_units']==1091157**2-max(sq)
    assert floor['floor_vertex_corner_checks']==512 and not floor['whole_circle_used_as_exact_polygon'] and not floor['convex_hull_support_disk_used_for_collisions']
    cog=Polygon([(x/10000,y/10000) for x,y in vertices]);assert shape(proxies[9]['geometry']).equals(cog) and shape(proxies[9]['component_polygons'][0]).equals(cog)
    expected=[dict(q) for q in prior['queries']]
    for q in expected:
        if q['family']=='cog':q['coordinate_bounds']=cert['stronger_stock_center_bounds_units100'][q['sheet']]
    assert expected==plan['queries'] and plan['cog_floor_radius_units10000']==1091000 and plan['exact_cog_pair_minimum_squared_units100']==21820**2
    fixed=load(BASE/'fixed-originals.json');assert fixed==load(OLD/'fixed-originals.json');styles=load(GEO/'fixed-styles.json');refs=load(BASE/'cache-references.json')
    assert len(refs)==110 and len({(r['fixed_style'],r['moving_proxy']) for r in refs})==110;local={};cachechecks=[];nreused=0;totalhulls=0
    previous={(r['fixed_style'],r['moving_proxy']):r for r in load(OLD/'cache-references.json')}
    for r in refs:
        p=ROOT/r['source'];assert digest(p)==r['sha256'];row=load(p);exclusion=shape(row['strict_interior_exclusion']);local[(r['fixed_style'],r['moving_proxy'])]=exclusion
        assert all(r[k]==row[k] for k in ['index','fixed_style','moving_proxy'])
        if r['reused']:
            assert r['moving_proxy']!=9 and all(r[k]==previous[(r['fixed_style'],r['moving_proxy'])][k] for k in ['source','sha256']) and r['sha256'] in byhash;nreused+=1;continue
        assert r['moving_proxy']==9;st=shape(styles[r['fixed_style']]['geometry']);triangles=list(shapely.constrained_delaunay_triangles(st).geoms)
        assert unary_union(triangles).equals(st)
        pieces=[MultiPoint([(a[0]-b[0],a[1]-b[1]) for a in list(t.exterior.coords)[:-1] for b in list(cog.exterior.coords)[:-1]]).convex_hull for t in triangles]
        raw=shape(row['raw_forbidden']);independent=unary_union(pieces);hd=raw.hausdorff_distance(independent);area=raw.symmetric_difference(independent).area
        assert hd<1e-7 and area<1e-4 and exclusion.difference(independent).is_empty
        margin=exclusion.distance(independent.boundary);assert margin>.0005;totalhulls+=len(pieces)
        cachechecks.append({'fixed_style':r['fixed_style'],'triangle_hulls':len(pieces),'hausdorff_error_mm':hd,'symmetric_difference_mm2':area,'strict_margin_mm':margin})
    assert nreused==100 and len(cachechecks)==10
    atlas=load(BASE/'support-atlas.json');components=[];specs=[];normals=set()
    for m in proxies:
        cs=[m['vertices_units10000']] if m['family']=='cog' else [[[r[0]*100,r[1]*100],[r[2]*100,r[1]*100],[r[2]*100,r[3]*100],[r[0]*100,r[3]*100]] for r in m['components_units100']]
        for pts in cs:
            components.append(pts)
            for a,b in zip(pts,pts[1:]+pts[:1]):
                nx,ny=b[1]-a[1],a[0]-b[0];d=math.gcd(nx,ny);normals.add((nx//d,ny//d))
        specs.append({'moving_proxy':m['index'],'family':m['family'],'class':m['class'],'components':cs})
    normals=sorted(normals);assert atlas['normals']==[list(n) for n in normals] and len(normals)==132
    assert atlas['opposite_normal_indices']==[normals.index((-x,-y)) for x,y in normals]
    assert [atlas[k] for k in ['geometry_units_per_mm','coordinate_units_per_mm','geometry_units_per_coordinate_unit']]==[10000,100,100]
    for s in specs:s['supports']=[[max(a*x+b*y for x,y in c) for a,b in normals] for c in s['components']]
    assert atlas['proxies']==specs and len(components)==19;facets=0
    for a,b in product(components,repeat=2):
        summed=hull([(x-u,y-v) for x,y in a for u,v in b])
        for p,q in zip(summed,summed[1:]+summed[:1]):
            nx,ny=q[1]-p[1],p[0]-q[0];d=math.gcd(nx,ny);assert (nx//d,ny//d) in normals;facets+=1
        for nx,ny in normals:assert max(nx*x+ny*y for x,y in summed)==max(nx*x+ny*y for x,y in a)+max(-nx*x-ny*y for x,y in b)
    hints=[h for h in load(SRC/'hint-poses.json') if h['item'] in [p['index'] for p in plan['movable_parts']]]
    selected=load(OLD/'solve/positions.json')['movable_parts'];domains=planes=tests=memberships=0;querychecks=[];selectedchecks=[]
    for q in expected:
        assert time.perf_counter()-start<120
        row=load(BASE/'queries'/f"{q['index']:04d}.json");assert row['query']==q;owners=[r for r in fixed if r['sheet']==q['sheet']]
        obstacles=unary_union([translate(local[(r['style'],q['moving_proxy'])],*r['transform']['translation']) for r in owners])
        stock=box(*(v/100 for v in q['coordinate_bounds']));free=stock.difference(obstacles);region=shape(row['padded_region'])
        assert row['fixed_items']==[r['item'] for r in owners] and stock.equals(shape(row['original_anchor_rectangle']))
        assert obstacles.equals(shape(row['strict_interior_forbidden_union'])) and free.equals(shape(row['free_outer_region']))
        assert free.is_empty or region.covers(free)
        assert unary_union([region,obstacles]).covers(stock);polys=[]
        for i,f in enumerate(row['domains']):
            assert f['index']==i;raw=shape(f['raw_face']);poly=shape(f['expanded_convex_face'])
            expanded=MultiPoint([(x+dx,y+dy) for x,y in list(raw.exterior.coords)[:-1] for dx,dy in [(-.001,-.001),(-.001,.001),(.001,.001),(.001,-.001)]]).convex_hull
            assert poly.is_valid and poly.equals(expanded) and poly.equals(poly.convex_hull) and poly.covers(raw)
            points=list(orient(poly,sign=1).exterior.coords);vs=[[F(v) for v in p] for p in points[:-1]]
            bounds=[math.floor(min(x for x,y in vs)*100),math.floor(min(y for x,y in vs)*100),math.ceil(max(x for x,y in vs)*100),math.ceil(max(y for x,y in vs)*100)]
            assert bounds==f['coordinate_bounds'] and 0<=bounds[0]<=bounds[2]<=150000 and 0<=bounds[1]<=bounds[3]<=300000;rows=[]
            for p0,p1 in zip(points,points[1:]):
                x,y=map(F,p0);u,v=map(F,p1);a,b=v-y,x-u
                if not a and not b:continue
                scale=max(abs(a),abs(b));a/=scale;b/=scale;c=a*x+b*y;A,B=round(a*10**7),round(b*10**7)
                error=abs(F(A)-a*10**7)*150000+abs(F(B)-b*10**7)*300000+1;C=math.ceil(c*100*10**7+error)
                assert (A or B) and max(abs(A)*150000+abs(B)*300000,abs(C))<2**60
                rows.append({'edge':[list(p0),list(p1)],'a':A,'b':B,'upper':C,'rounding_error_bound':[error.numerator,error.denominator]})
                for vx,vy in vs:assert A*vx*100+B*vy*100<=C;tests+=1
            assert rows==f['halfplanes'];planes+=len(rows);domains+=1;polys.append(poly)
        assert region.is_empty or unary_union(polys).covers(region)
        for h in hints:
            if h['family']==q['family'] and h['mode']==q['mode']:
                assert any(admits(f,h['x_units'],h['y_units']) for f in row['domains']);memberships+=1
        for p in selected:
            if p['query']==q['index']:
                b=q['coordinate_bounds'];inside=b[0]<=p['x_units']<=b[2] and b[1]<=p['y_units']<=b[3]
                selectedchecks.append({'item':p['item'],'query':q['index'],'stock_admitted':inside,'integer_domain_admitted':any(admits(f,p['x_units'],p['y_units']) for f in row['domains'])})
        querychecks.append({'query':q['index'],'domains':len(polys),'whole_stock_coverage_verified':True,'reused':q['family']!='cog'})
    assert domains==result['convex_domains'] and memberships==7 and len(selectedchecks)==9
    for i in [54,62]:assert not next(r for r in selectedchecks if r['item']==i)['integer_domain_admitted']
    for i in [58,64,65]:assert not next(r for r in selectedchecks if r['item']==i)['stock_admitted']
    write(OUT/'provenance.json',provenance);write(OUT/'new-obstacle-checks.json',cachechecks);write(OUT/'query-checks.json',querychecks);write(OUT/'prior-anchor-checks.json',selectedchecks)
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_source_matches':len(provenance),'reused_query_bytes_verified':18,
        'unchanged_fixed_originals':57,'mandatory_movable_originals':9,'required_originals':66,'cog_proxy_vertices':128,
        'exact_floor_vertex_corner_checks':512,'strict_floor_squared_margin_units':1091157**2-max(sq),'exact_convex_containment_tests':containment,
        'old16gon_contained':True,'new_independent_triangle_hulls':totalhulls,'reused_cache_entries':100,'new_cog_cache_entries':10,
        'all20_original_stock_queries_covered':True,'convex_domains':domains,'outward_halfplanes':planes,'rational_vertex_checks':tests,
        'source_pose_memberships':memberships,'exact_component_types':19,'common_edge_normals':132,'exact_ordered_minkowski_hulls':361,'minkowski_facets_in_basis':facets,
        'two_prior_fixed_conflict_anchors_rejected':True,'three_prior_stock_anchors_rejected':True,
        'circle_is_not_substituted_by_its_polygon':True,'convex_hull_support_used_only_for_stock':True,
        'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
