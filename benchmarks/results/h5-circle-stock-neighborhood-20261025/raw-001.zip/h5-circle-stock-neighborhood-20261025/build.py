"""Stronger all-angle cog geometry, certified stock bounds and fresh cog domains."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,math,shutil,time,traceback
from shapely.geometry import Polygon,MultiPoint,box,shape,mapping,GeometryCollection
from shapely.geometry.polygon import orient
from shapely.affinity import translate
from shapely.ops import unary_union
from conservative_h5_round_obstacles import raw_obstacle
from build_h5_strong_pair_domains import convex_faces,halfplanes

ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-conflict-owner-neighborhood-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
OUT=ROOT/'output/h5-circle-stock-neighborhood-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def support_atlas(proxies):
    specs=[];normals=set()
    for p in proxies:
        cs=[p['vertices_units10000']] if p['family']=='cog' else [[[r[0]*100,r[1]*100],[r[2]*100,r[1]*100],[r[2]*100,r[3]*100],[r[0]*100,r[3]*100]] for r in p['components_units100']]
        for pts in cs:
            for a,b in zip(pts,pts[1:]+pts[:1]):
                nx,ny=b[1]-a[1],a[0]-b[0];d=math.gcd(nx,ny);normals.add((nx//d,ny//d))
        specs.append({'moving_proxy':p['index'],'family':p['family'],'class':p['class'],'components':cs})
    normals=sorted(normals);assert all((-x,-y) in normals for x,y in normals)
    for s in specs:s['supports']=[[max(nx*x+ny*y for x,y in pts) for nx,ny in normals] for pts in s['components']]
    return {'geometry_units_per_mm':10000,'coordinate_units_per_mm':100,'geometry_units_per_coordinate_unit':100,
            'normals':[list(n) for n in normals],'opposite_normal_indices':[normals.index((-x,-y)) for x,y in normals],
            'proxies':specs,'meaning':'Exact integer separating-axis conditions for every pair of convex components of different physical parts. The stronger cog polygon is certified inside every original cog over all floor errors; it is not the exact whole circle. Whole-circle cog-pair inequalities are separately required in a subsequent model.'}

def main():
    assert load(OLD/'audit/checks.json')['passed'] and load(OLD/'stronger-cog-conditions/audit/checks.json')['passed']
    OUT.mkdir();(OUT/'obstacles').mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    prior=load(OLD/'plan.json');cert=load(OLD/'stronger-cog-conditions/certificate.json');proxies=load(OLD/'moving-proxies.json')
    oldvertices=proxies[9]['vertices_units10000'];generated=[[round(1090999*math.cos(math.tau*k/128)),round(1090999*math.sin(math.tau*k/128))] for k in range(128)]
    assert all(x*x+y*y<=1091000**2 for x,y in generated)
    poly_units=orient(MultiPoint(generated+oldvertices).convex_hull,sign=1)
    vertices=[[int(x),int(y)] for x,y in list(poly_units.exterior.coords)[:-1]]
    assert len(vertices)==128 and all(poly_units.covers(MultiPoint([v])) for v in oldvertices)
    squared=[(x-ex)**2+(y-ey)**2 for x,y in vertices for ex,ey in product([0,100],repeat=2)]
    assert max(squared)<cert['original_disk_radius_units10000']**2
    polygon=Polygon([(x/10000,y/10000) for x,y in vertices]);proxies[9]={**proxies[9],'vertices_units10000':vertices,'component_polygons':[mapping(polygon)],'geometry':mapping(polygon)}
    queries=[dict(q) for q in prior['queries']]
    for q in queries:
        if q['family']=='cog':q['coordinate_bounds']=cert['stronger_stock_center_bounds_units100'][q['sheet']]
    inputs=[OLD/n for n in ['plan.json','result.json','audit/checks.json','audit/provenance.json','fixed-originals.json','moving-proxies.json','cache-references.json',
        'stronger-cog-conditions/certificate.json','stronger-cog-conditions/audit/checks.json','solve/positions.json','solution-audit/checks.json']]
    inputs += [GEO/'fixed-styles.json',SRC/'propagation.json',SRC/'hint-poses.json',ROOT/'benchmarks/results/h5-conflict-owner-neighborhood-20261025/raw-manifest.json']
    inputs += [ROOT/'output'/n for n in ['conservative_h5_round_obstacles.py','build_h5_strong_pair_domains.py','diagnose_h5_concave_gaps.py']]
    plan={**prior,'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'queries':queries,'construction_limit_seconds':120,'maximum_domains':20000,
          'reused_query_hashes':{f'{i:04d}.json':digest(OLD/'queries'/f'{i:04d}.json') for i in range(18)},
          'original16gon_vertices':oldvertices,'generated128_vertices':generated,
          'cog_floor_radius_units10000':1091000,'exact_cog_pair_minimum_squared_units100':21820**2,
          'all_angle_stock_support_radius_units10000':1392707,
          'method':'Same57 fixed originals and9 mandatory moving originals, with unchanged allowed orientation/sheet inventory and original area charges. Reuse all18 completed non-cog queries byte for byte. Build a128-vertex cog polygon by taking the convex hull of an inscribed128-point circle approximation and every previous16-gon vertex. Prove all512 floor-error vertex corners remain inside the original certified disk, preserving the old proxy as a subset. Replace only the10 fixed-style cog obstacle entries, retaining100 other certified entries. Build both fresh cog regions directly from the independently certified139.2707mm all-angle stock supports; this hull support is never used for collision geometry. Complete outward region/domain coverage and exact support atlas precede independent audit. No solver call; subsequent model must also impose exact109.1mm whole-circle pair squared distances.'}
    plan.pop('reused_obstacle_hashes',None);write(OUT/'plan.json',plan)
    start=time.perf_counter();deadline=start+120
    write(OUT/'moving-proxies.json',proxies);write(OUT/'support-atlas.json',support_atlas(proxies))
    write(OUT/'cog-floor-certificate.json',{'vertices_units10000':vertices,'old_vertices_retained_as_subset':True,
        'generated_points_inside_radius1091000_circle':True,'floor_vertex_corner_checks':512,
        'maximum_squared_distance':max(squared),'original_disk_radius_units10000':cert['original_disk_radius_units10000'],
        'strict_squared_margin_units':cert['original_disk_radius_units10000']**2-max(squared),
        'whole_circle_used_as_exact_polygon':False,'convex_hull_support_disk_used_for_collisions':False})
    shutil.copyfile(OLD/'fixed-originals.json',OUT/'fixed-originals.json');fixed=load(OUT/'fixed-originals.json')
    refs=[];local={};new=[]
    for r in load(OLD/'cache-references.json'):
        if r['moving_proxy']==9:continue
        p=ROOT/r['source'];assert digest(p)==r['sha256'];refs.append({**r,'reused':True});local[(r['fixed_style'],r['moving_proxy'])]=shape(load(p)['strict_interior_exclusion'])
    assert len(refs)==100
    for st in load(GEO/'fixed-styles.json'):
        assert time.perf_counter()<deadline
        raw=raw_obstacle(shape(st['geometry']),polygon);exclusion=raw.buffer(-.001,quad_segs=8).intersection(raw)
        margin=exclusion.distance(raw.boundary);assert raw.is_valid and exclusion.is_valid and not exclusion.is_empty and exclusion.difference(raw).is_empty and margin>.0005
        p=OUT/'obstacles'/f"{st['index']:03d}.json";row={'index':st['index']*10+9,'fixed_style':st['index'],'moving_proxy':9,
            'raw_forbidden':mapping(raw),'strict_interior_exclusion':mapping(exclusion),'actual_boundary_margin_mm':margin}
        write(p,row);refs.append({'index':row['index'],'fixed_style':st['index'],'moving_proxy':9,'source':p.relative_to(ROOT).as_posix(),'sha256':digest(p),'reused':False})
        local[(st['index'],9)]=exclusion;new.append(row)
    refs.sort(key=lambda r:(r['fixed_style'],r['moving_proxy']));write(OUT/'cache-references.json',refs)
    records=[];total=0
    for q in queries:
        if time.perf_counter()>=deadline or total>=20000:break
        path=OUT/'queries'/f"{q['index']:04d}.json"
        if q['family']!='cog':
            shutil.copyfile(OLD/'queries'/path.name,path);stored=load(path);assert stored['query']==q
            ds=stored['domains'];merge=stored['merge'];empty=shape(stored['free_outer_region']).is_empty
        else:
            stock=box(*(v/100 for v in q['coordinate_bounds']));owners=[r for r in fixed if r['sheet']==q['sheet']]
            forbidden=unary_union([translate(local[(r['style'],9)],*r['transform']['translation']) for r in owners])
            free=stock.difference(forbidden);region=free.buffer(.001,quad_segs=8) if not free.is_empty else GeometryCollection()
            assert region.is_valid and (free.is_empty or region.covers(free)) and unary_union([region,forbidden]).covers(stock)
            faces,merge=convex_faces(region,deadline);ds=[];polygons=[]
            for i,face in enumerate(faces):
                pts=list(face.exterior.coords)[:-1]
                expanded=orient(MultiPoint([(x+dx,y+dy) for (x,y),(dx,dy) in product(pts,[(-.001,-.001),(-.001,.001),(.001,.001),(.001,-.001)])]).convex_hull,sign=1)
                a,b,c,d=expanded.bounds;bounds=[math.floor(F(a)*100),math.floor(F(b)*100),math.ceil(F(c)*100),math.ceil(F(d)*100)]
                assert 0<=bounds[0]<=bounds[2]<=150000 and 0<=bounds[1]<=bounds[3]<=300000
                ds.append({'index':i,'raw_face':mapping(face),'expanded_convex_face':mapping(expanded),'coordinate_bounds':bounds,'halfplanes':halfplanes(expanded)});polygons.append(expanded)
            assert region.is_empty or unary_union(polygons).covers(region)
            write(path,{'query':q,'fixed_items':[r['item'] for r in owners],'original_anchor_rectangle':mapping(stock),
                'strict_interior_forbidden_union':mapping(forbidden),'free_outer_region':mapping(free),'padded_region':mapping(region),'domains':ds,'merge':merge});empty=free.is_empty
        total+=len(ds);records.append({'query':q['index'],'family':q['family'],'sheet':q['sheet'],'domains':len(ds),'empty':empty,'reused':q['family']!='cog',**merge})
    write(OUT/'query-summary.json',records);write(OUT/'pending.json',queries[len(records):])
    result={'seconds':time.perf_counter()-start,'fixed_originals':57,'mandatory_movable_originals':9,'required_originals':66,
        'queries_planned':20,'queries_completed':len(records),'pending_queries':20-len(records),'convex_domains':total,
        'reused_queries':sum(r['reused'] for r in records),'new_queries':sum(not r['reused'] for r in records),
        'reused_cache_entries':100,'new_cog_cache_entries':len(new),'empty_queries':sum(r['empty'] for r in records),
        'merge_cap_queries':sum(r['merge_cap_reached'] for r in records),'merge_time_queries':sum(r['merge_time_reached'] for r in records),
        'domain_cap_reached':total>=20000,'cog_proxy_vertices':len(vertices),'support_normals':len(load(OUT/'support-atlas.json')['normals']),
        'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
