"""One declared bounded search of the complete nine-part conflict-owner move."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations,product
import json,shutil,sys,time,traceback
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
from audit_h5_circle_stock_model import verify

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-circle-stock-neighborhood-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025';OUT=BASE/'solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    spec=load(BASE/'plan.json');atlas=load(BASE/'support-atlas.json');aux=load(SRC/'propagation.json')
    queries={q['index']:load(BASE/'queries'/f"{q['index']:04d}.json") for q in spec['queries']}
    params={'max_time_in_seconds':60,'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,
            'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
    inputs=[BASE/n for n in ['plan.json','result.json','audit/checks.json','support-atlas.json']]+[SRC/'propagation.json',ROOT/'output/audit_h5_circle_stock_model.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'query_hashes':{str(i):digest(BASE/'queries'/f'{i:04d}.json') for i in queries},'parameters':params,'maximum_solver_calls':1,
        'construction_limit_seconds':120,'independent_model_audit_limit_seconds':120,'fixed_originals':57,'mandatory_moving_originals':9,
        'required_originals':66,'objective':None,'hints':None,
        'method':'All9 mandatory originals choose every allowed mode and sheet from20 independently certified original-stock queries. Each chooses one complete outward convex domain with all rational halfplanes and the original outward stock anchor bounds. Retain full original area charges on both sheets. Exact integer projection separation for every pair of components of different physical parts, using all132 independently proved edge normals and complete128-vertex cog proxies. Every cog uses the certified139.2707mm all-angle stock supports. Add exact109.1mm whole-circle separation for all15 moving-cog pairs using integer squared distances, conditionally on a shared sheet. The circle and polygon are distinct necessary conditions; the convex-hull support disk is never used as collision geometry. No copy ordering, source-position hints, optional originals, objective or inherited two-core domain restrictions. Independently reconstruct every protobuf variable/constraint and parameters before one60-second/eight-worker/seed-zero call. This necessary relaxation does not establish accepted native geometry or H5.'})
    start=time.perf_counter();model=cp_model.CpModel();vs=[]
    def var(name,lo,hi):
        v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi,en=()):
        c=model.add_linear_constraint(sum(vs[i]*coef for i,coef in terms),lo,hi)
        if en:c.only_enforce_if([vs[i] for i in en])
    parts=[]
    for pi,item in enumerate(spec['movable_parts']):
        name=f'part{pi}';x=var(name+'-x',0,150000);y=var(name+'-y',0,300000);sheet=var(name+'-sheet',0,1);modes=[]
        for q in spec['queries']:
            if q['family']!=item['family'] or q['mode'] not in item['allowed_modes']:continue
            tag=name+f"-q{q['index']}";active=var(tag+'-active',0,1);ds=[];bounds=q['coordinate_bounds']
            linear([(x,1)],bounds[0],bounds[2],[active]);linear([(y,1)],bounds[1],bounds[3],[active])
            for face in queries[q['index']]['domains']:
                d=var(tag+f"-domain{face['index']}",0,1);ds.append(d);bounds=face['coordinate_bounds']
                linear([(x,1)],bounds[0],bounds[2],[d]);linear([(y,1)],bounds[1],bounds[3],[d])
                for h in face['halfplanes']:linear([(x,h['a']),(y,h['b'])],cp_model.INT_MIN,h['upper'],[d])
            linear([(d,1) for d in ds]+[(active,-1)],0,0)
            modes.append({'query':q['index'],'active':active,'domains':ds,'sheet':q['sheet'],'moving_proxy':q['moving_proxy']})
        model.add_exactly_one([vs[m['active']] for m in modes]);linear([(sheet,1)]+[(m['active'],-m['sheet']) for m in modes],0,0)
        components=[]
        for arm in range(2 if item['family']=='bracket' else 1):
            support=[]
            for n in range(len(atlas['normals'])):
                values=[atlas['proxies'][m['moving_proxy']]['supports'][arm][n] for m in modes]
                v=var(name+f'-component{arm}-support{n}',min(values),max(values))
                linear([(v,1)]+[(m['active'],-value) for m,value in zip(modes,values)],0,0);support.append(v)
            components.append(support)
        parts.append({'index':pi,'item':item['index'],'family':item['family'],'x':x,'y':y,'sheet':sheet,'modes':modes,'components':components})
    charges=[aux['part_areas'][p['family']]['lower_units'] for p in parts]
    linear([(p['sheet'],-charge) for p,charge in zip(parts,charges)],cp_model.INT_MIN,
           aux['sheet_capacities'][0]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][0]-sum(charges))
    linear([(p['sheet'],charge) for p,charge in zip(parts,charges)],cp_model.INT_MIN,
           aux['sheet_capacities'][1]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][1])
    pairs=[]
    for a,b in combinations(parts,2):
        prefix=f"pair{a['index']}-{b['index']}";different=var(prefix+'-different-sheet',0,1)
        model.add_bool_xor([vs[a['sheet']],vs[b['sheet']],vs[different].Not()]);ps=[]
        for ai,bi in product(range(len(a['components'])),range(len(b['components']))):
            ds=[]
            for n,(nx,ny) in enumerate(atlas['normals']):
                d=var(prefix+f'-components{ai}-{bi}-normal{n}',0,1);ds.append(d);opp=atlas['opposite_normal_indices'][n]
                linear([(b['x'],100*nx),(a['x'],-100*nx),(b['y'],100*ny),(a['y'],-100*ny),
                        (a['components'][ai][n],-1),(b['components'][bi][opp],-1)],0,cp_model.INT_MAX,[d])
            model.add_bool_or([vs[different]]+[vs[d] for d in ds]);ps.append({'components':[ai,bi],'directions':ds})
        pairs.append({'parts':[a['index'],b['index']],'different_sheet':different,'component_pairs':ps})
    circles=[]
    for pair in pairs:
        a,b=[parts[i] for i in pair['parts']]
        if a['family']!='cog' or b['family']!='cog':continue
        prefix=f"circle{a['index']}-{b['index']}"
        dx=var(prefix+'-dx',-150000,150000);dy=var(prefix+'-dy',-300000,300000)
        sx=var(prefix+'-dx-squared',0,150000**2);sy=var(prefix+'-dy-squared',0,300000**2)
        linear([(dx,1),(b['x'],-1),(a['x'],1)],0,0)
        linear([(dy,1),(b['y'],-1),(a['y'],1)],0,0)
        model.add_multiplication_equality(vs[sx],[vs[dx],vs[dx]])
        model.add_multiplication_equality(vs[sy],[vs[dy],vs[dy]])
        model.add_linear_constraint(vs[sx]+vs[sy],21820**2,cp_model.INT_MAX).only_enforce_if(vs[pair['different_sheet']].Not())
        circles.append({'parts':pair['parts'],'different_sheet':pair['different_sheet'],
                        'dx':dx,'dy':dy,'dx_squared':sx,'dy_squared':sy,'minimum_squared_distance':21820**2})
    assert len(circles)==15
    mapping={'parts':parts,'pairs':pairs,'circles':circles};write(OUT/'mapping.json',mapping)
    assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));construction=time.perf_counter()-start;assert construction<120
    start=time.perf_counter();actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes())
    expected,stats=verify(actual,spec,queries,atlas,aux);assert expected==mapping
    solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');audittime=time.perf_counter()-start;assert audittime<120
    write(OUT/'model-audit.json',{'passed':True,'construction_seconds':construction,'audit_seconds':audittime,**stats,
        'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'python':sys.version,'ortools':ortools.__version__})
    print(load(OUT/'model-audit.json'),flush=True)
    def positions(value):
        rows=[]
        for p in parts:
            chosen=[m for m in p['modes'] if value(vs[m['active']])];assert len(chosen)==1;m=chosen[0]
            domains=[i for i,v in enumerate(m['domains']) if value(vs[v])];assert len(domains)==1;q=spec['queries'][m['query']]
            rows.append({'part':p['index'],'item':p['item'],'family':p['family'],'query':m['query'],'domain':domains[0],
                'moving_proxy':m['moving_proxy'],'x_units':value(vs[p['x']]),'y_units':value(vs[p['y']]),'sheet':value(vs[p['sheet']]),'class':q['class'],'mode':q['mode']})
        return {'fixed_items':spec['fixed_items'],'movable_parts':rows,'required_originals':66}
    records=[]
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            write(OUT/f'incumbent-{len(records)}.json',positions(self.value));records.append({'index':len(records),'seconds':self.wall_time});print(records[-1],flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':60,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda message:(log.write(message+'\n'),log.flush())
        start=time.perf_counter();status=solver.solve(model,Capture());elapsed=time.perf_counter()-start
    feasible=status in [cp_model.FEASIBLE,cp_model.OPTIMAL]
    if feasible:write(OUT/'positions.json',positions(solver.value))
    result={'status':solver.status_name(status),'seconds':elapsed,'solver_calls':1,'incumbents':records,
        'has_complete_66_part_necessary_proxy_solution':feasible,'response_stats':solver.response_stats(),
        'scope':'Only this complete57-fixed/9-mandatory-moving neighborhood and source orientation inventory, with128-vertex floor-safe proxies, exact cog-circle pair separation and certified all-angle stock bounds. A negative is conditional, UNKNOWN unresolved. Positive requires original outlines/angles, original clearance/native guards, production budget and the full13-job/two-kerf H5 matrix.',
        'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
