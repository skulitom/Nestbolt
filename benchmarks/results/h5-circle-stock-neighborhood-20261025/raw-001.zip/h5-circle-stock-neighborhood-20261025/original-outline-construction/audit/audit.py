"""Independent full-profile, inward-grid and fixed-source margin audit."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time,traceback
from shapely.geometry import Polygon,shape
from shapely.affinity import translate

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-circle-stock-neighborhood-20261025'
OLD=ROOT/'output/h5-conflict-owner-neighborhood-20261025';SRC=ROOT/'output/h5-source-orientation-construction-20261025'
PREP=BASE/'original-outline-construction';OUT=PREP/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(PREP/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,
        'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(PREP.glob('*.json'))},
        'production_guard_source_hashes':{n:digest(ROOT/n) for n in ['crates/core/src/construct.rs','crates/core/src/sheets.rs']},
        'method':'Reconstruct all original profiles independently, including all80 cog vertices at the source angle. Check each moved source part can be exactly reconstructed from its profile and original anchor; the two missing brackets retain all8 orientations. Recompute all20 stock rectangles as rational inward1-micrometre grid bounds and all1246 fixed-original pair distances. Derive the scale-dependent conversion guard from current production source and record both pair-distance and stock-margin shortfalls. This preparatory finite-angle construction is not an exhaustive relaxation, native qualification or H5 completion.'})
    start=time.perf_counter()
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};g=load(SRC/'geometry.json');items=load(SRC/'items.json');spec=load(OLD/'plan.json')
    source=load(ROOT/load(SRC/'plan.json')['hint_source']);disk=load(ROOT/'output/h5-cog-center-capacity-20261020/disk.json');center=[float(F(*v)) for v in disk['center']]
    profiles=load(PREP/'profiles.json');queries=load(PREP/'queries.json');assert len(profiles)==10 and len(queries)==20
    matrices=[(1,0,0,1),(0,-1,1,0),(-1,0,0,-1),(0,1,-1,0)];profileby={};vertex_checks=0
    for i,p in enumerate(profiles):
        assert p['index']==i;family=p['family'];original=parts[family]['geometry'][0]['outer']
        if family=='cog':
            angles={float(source['placements'][r['source_index']]['transform']['rotation_radians']).hex() for r in spec['movable_parts'] if r['family']=='cog'}
            assert len(angles)==1 and p['rotation_hex'] in angles and float(p['rotation_radians']).hex()==p['rotation_hex']
            c,s=math.cos(p['rotation_radians']),math.sin(p['rotation_radians']);rotated_center=[c*center[0]-s*center[1],s*center[0]+c*center[1]]
            coords=[[c*x-s*y-rotated_center[0],s*x+c*y-rotated_center[1]] for x,y in original]
            assert len(coords)==p['original_vertex_count']==80 and p['original_center']==center
        else:
            cl=g['classes'][p['class']];a,b,c,d=matrices[cl['quarter_turn']];sign=-1 if cl['mirrored'] else 1
            coords=[[sign*a*x+b*y,sign*c*x+d*y] for x,y in original];mx,my=min(x for x,y in coords),min(y for x,y in coords)
            assert p['rotated_original_min']==[mx,my] and p['quarter_turn']==cl['quarter_turn'] and p['mirrored']==cl['mirrored']
            coords=[[x-mx,y-my] for x,y in coords];assert coords==p['vertices']
        assert len(coords)==len(p['vertices'])==p['original_vertex_count']
        for a,b in zip(coords,p['vertices']):assert max(abs(a[0]-b[0]),abs(a[1]-b[1]))<1e-7;vertex_checks+=1
        polygon=Polygon(coords);saved=shape(p['geometry']);assert polygon.hausdorff_distance(saved)<1e-7 and polygon.is_valid
        assert list(saved.bounds)==p['bounds'];profileby[p['class']]=p
    source_matches=[]
    for r in spec['movable_parts']:
        if r['source_index'] is None:continue
        placement=source['placements'][r['source_index']];t=placement['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        actual=Polygon([(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in parts[r['family']]['geometry'][0]['outer']])
        p=profileby[r['fixed_representative_class']]
        anchor=[tx+c*center[0]-s*center[1],ty+s*center[0]+c*center[1]] if r['family']=='cog' else list(actual.bounds[:2])
        error=translate(shape(p['geometry']),*anchor).hausdorff_distance(actual);assert error<1e-7
        source_matches.append({'item':r['index'],'profile':p['index'],'actual_anchor':anchor,'reconstruction_error_mm':error})
    assert len(source_matches)==7
    stocks=[[F(*v) for v in b] for b in g['stock_bounds_rational']]
    for q,old in zip(queries,spec['queries']):
        assert all(q[k]==old[k] for k in ['index','family','mode','class','sheet'])
        p=profiles[q['profile']];assert p==profileby[q['class']];st=stocks[q['sheet']];b=list(map(F,p['bounds']));margin=F(1,10000)
        continuous=[st[0]-b[0]+margin,st[1]-b[1]+margin,st[2]-b[2]-margin,st[3]-b[3]-margin]
        assert q['continuous_bounds_rational']==[[v.numerator,v.denominator] for v in continuous]
        bounds=[math.ceil(continuous[0]*1000),math.ceil(continuous[1]*1000),math.floor(continuous[2]*1000),math.floor(continuous[3]*1000)]
        assert q['anchor_bounds_units1000']==bounds and not q['empty']
        assert F(bounds[0],1000)+b[0]>=st[0]+margin and F(bounds[1],1000)+b[1]>=st[1]+margin
        assert F(bounds[2],1000)+b[2]<=st[2]-margin and F(bounds[3],1000)+b[3]<=st[3]-margin
    for r in spec['movable_parts']:assert sorted(q['mode'] for q in queries if q['family']==r['family'] and q['mode'] in r['allowed_modes'])==r['allowed_modes']
    magnitude=max([1.]+[abs(v) for p in job['parts'] for geo in p['geometry'] for point in geo['outer'] for v in point]+[v for st in job['stocks'] for v in [st['width'],st['height']]])
    guard=max(magnitude*32*2**-23,.00002);separation=(job['clearance']+guard)/math.cos(.05)
    assert guard==.011444091796875 and separation==.21170867250963943
    fixed=load(OLD/'fixed-originals.json');rows=[];stockshort=[]
    for a,b in combinations(fixed,2):
        if a['sheet']!=b['sheet']:continue
        distance=shape(a['geometry']).distance(shape(b['geometry']));assert distance>=job['clearance']-1e-7
        rows.append({'items':[a['item'],b['item']],'distance_mm':distance,'native_conservative_distance_mm':separation,'native_margin_shortfall':distance<separation})
    assert rows==load(PREP/'fixed-pair-checks.json') and [r for r in rows if r['native_margin_shortfall']]==load(PREP/'native-margin-shortfalls.json')
    for r in fixed:
        b=shape(r['geometry']).bounds;st=[float(v) for v in stocks[r['sheet']]];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]]
        assert min(extra)>-1e-7
        if min(extra)<guard:stockshort.append({'item':r['item'],'sheet':r['sheet'],'family':r['family'],'extra_stock_margins_mm':extra,'conversion_guard_mm':guard})
    write(OUT/'source-profile-reconstruction.json',source_matches);write(OUT/'fixed-stock-guard-shortfalls.json',stockshort)
    checks={'passed':True,'seconds':time.perf_counter()-start,'profiles':10,'original_profile_vertex_checks':vertex_checks,'all80_cog_vertices_preserved':True,
        'original_source_profile_reconstructions':7,'inward_stock_grid_queries':20,'all_recorded_bracket_insert_modes_preserved':True,
        'original_clearance_fixed_pair_checks':len(rows),'fixed_pair_native_margin_shortfalls':sum(r['native_margin_shortfall'] for r in rows),
        'fixed_stock_guard_shortfalls':len(stockshort),'native_margin_qualified':False,'construction_only_not_exhaustive':True,
        'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    assert checks['seconds']<60;write(OUT/'checks.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
