"""Prepare full original shapes for a distinct constructive source-angle search."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,math,shutil,time,traceback
from shapely.geometry import Polygon,shape,mapping

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-circle-stock-neighborhood-20261025'
OLD=ROOT/'output/h5-conflict-owner-neighborhood-20261025';SRC=ROOT/'output/h5-source-orientation-construction-20261025'
OUT=BASE/'original-outline-construction'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    sourcepath=ROOT/load(SRC/'plan.json')['hint_source'];jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';diskpath=ROOT/'output/h5-cog-center-capacity-20261020/disk.json'
    inputs=[sourcepath,jobpath,diskpath,SRC/'geometry.json',SRC/'items.json',OLD/'plan.json',OLD/'fixed-originals.json',BASE/'solve/result.json',BASE/'solve/model-audit.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'preparation_limit_seconds':60,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'anchor_units_per_mm':1000,
        'stock_construction_margin_mm':.0001,'original_clearance_mm':.2,'clearance_construction_margin_mm':.0001,
        'method':'Prepare a distinct constructive search using full original outer polygons, including every cog tooth, rather than the prior necessary proxies. Preserve57 original source transforms and all9 mandatory moving originals. Both brackets retain all8 orientations; the insert retains its source vertical orientation; each cog uses its known source angle, whose shared value is checked. This finite angle and1-micrometre anchor grid are construction choices, not an exhaustive necessary relaxation. Record20 inward-rounded stock anchor rectangles from actual oriented bounds. Full original clearance and material cap are unchanged. Audit fixed-original geometry and native-margin shortfalls explicitly. No obstacle domains, solver or accepted layout yet; eventual positives still require native guards, production-budget implementation and the full H5 matrix.'})
    start=time.perf_counter();spec=load(OLD/'plan.json');g=load(SRC/'geometry.json');items=load(SRC/'items.json');source=load(sourcepath);job=load(jobpath);parts={p['id']:p for p in job['parts']};disk=load(diskpath)
    assert job['clearance']==.2;center=[float(F(*v)) for v in disk['center']]
    cogs=[p for p in spec['movable_parts'] if p['family']=='cog'];angles=[source['placements'][p['source_index']]['transform']['rotation_radians'] for p in cogs]
    assert len(cogs)==6 and len(set(float(a).hex() for a in angles))==1
    profiles=[];byclass={}
    for cl in [g['classes'][k] for k in list(range(4,12))+[13]]:
        points=[]
        for x,y in parts[cl['family']]['geometry'][0]['outer']:
            assert float(x).is_integer() and float(y).is_integer();x,y=int(x),int(y)
            if cl['mirrored']:x=-x
            points.append([(x,y),(-y,x),(-x,-y),(y,-x)][cl['quarter_turn']])
        xmin,ymin=min(x for x,y in points),min(y for x,y in points)
        xy=[[x-xmin,y-ymin] for x,y in points];polygon=Polygon(xy);assert polygon.is_valid
        row={'index':len(profiles),'family':cl['family'],'class':cl['index'],'quarter_turn':cl['quarter_turn'],'mirrored':cl['mirrored'],
             'rotation_radians':cl['quarter_turn']*math.pi/2,'anchor':'oriented lower-left corner','rotated_original_min':[xmin,ymin],
             'original_vertex_count':len(points),'vertices':xy,'geometry':mapping(polygon),'bounds':list(polygon.bounds)}
        byclass[cl['index']]=row['index'];profiles.append(row)
    angle=angles[0];c,s=math.cos(angle),math.sin(angle);cog_points=[[c*(x-center[0])-s*(y-center[1]),s*(x-center[0])+c*(y-center[1])] for x,y in parts['cog']['geometry'][0]['outer']]
    cog=Polygon(cog_points);assert cog.is_valid and len(cog_points)==80
    byclass[None]=len(profiles);profiles.append({'index':len(profiles),'family':'cog','class':None,'mirrored':False,
        'rotation_radians':angle,'rotation_hex':float(angle).hex(),'anchor':'transformed original cog center','original_center':center,
        'original_vertex_count':80,'vertices':cog_points,'geometry':mapping(cog),'bounds':list(cog.bounds)})
    stocks=[[F(*v) for v in b] for b in g['stock_bounds_rational']];queries=[]
    for q in spec['queries']:
        p=profiles[byclass[q['class']]];bounds=list(map(F,p['bounds']));st=stocks[q['sheet']];margin=F(1,10000)
        continuous=[st[0]-bounds[0]+margin,st[1]-bounds[1]+margin,st[2]-bounds[2]-margin,st[3]-bounds[3]-margin]
        integer=[math.ceil(continuous[0]*1000),math.ceil(continuous[1]*1000),math.floor(continuous[2]*1000),math.floor(continuous[3]*1000)]
        queries.append({'index':q['index'],'family':q['family'],'mode':q['mode'],'class':q['class'],'sheet':q['sheet'],
            'profile':p['index'],'continuous_bounds_rational':[[v.numerator,v.denominator] for v in continuous],
            'anchor_bounds_units1000':integer,'empty':integer[0]>integer[2] or integer[1]>integer[3]})
    assert len(profiles)==10 and len(queries)==20 and not any(q['empty'] for q in queries)
    for p in spec['movable_parts']:assert sorted(q['mode'] for q in queries if q['family']==p['family'] and q['mode'] in p['allowed_modes'])==p['allowed_modes']
    fixed=load(OLD/'fixed-originals.json');guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05)
    pairchecks=[];minimum=float('inf');shortfalls=[]
    for a,b in combinations(fixed,2):
        if a['sheet']!=b['sheet']:continue
        distance=shape(a['geometry']).distance(shape(b['geometry']));assert distance>=job['clearance']-1e-7;minimum=min(minimum,distance)
        row={'items':[a['item'],b['item']],'distance_mm':distance,'native_conservative_distance_mm':required,'native_margin_shortfall':distance<required}
        pairchecks.append(row)
        if row['native_margin_shortfall']:shortfalls.append(row)
    write(OUT/'profiles.json',profiles);write(OUT/'queries.json',queries);write(OUT/'fixed-pair-checks.json',pairchecks);write(OUT/'native-margin-shortfalls.json',shortfalls)
    checks={'passed':True,'seconds':time.perf_counter()-start,'required_originals':66,'fixed_originals':57,'mandatory_moving_originals':9,
        'full_original_profiles':10,'complete_original_cog_vertices':80,'source_cog_angles_distinct':1,'mode_sheet_queries':20,
        'all_recorded_bracket_and_insert_modes_retained':True,'source_cog_angle_fixed_for_construction_only':True,
        'anchor_grid_units_per_mm':1000,'stock_bounds_round_inward':True,'fixed_original_pair_checks':len(pairchecks),'minimum_fixed_original_gap_mm':minimum,
        'fixed_pairs_below_native_conservative_margin':len(shortfalls),'native_guard_mm':guard,'native_conservative_distance_mm':required,
        'fixed_source_alone_native_qualified':not shortfalls,'independent_profile_audit_pending':True,
        'obstacle_domains_constructed':False,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    assert checks['seconds']<60;write(OUT/'checks.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
