"""Preserve a checker KeyError caused by an intentionally omitted zero counter."""
from pathlib import Path
import json,shutil
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-productive-exchange-probe-20261018'
source=(probe/'witness-checks').resolve();saved=(probe/'witness-checks-initial').resolve()
assert source.is_relative_to(root.resolve()) and saved.is_relative_to(root.resolve()) and not saved.exists()
checker=root/'output/check_h5_productive_witnesses.py'
shutil.copyfile(checker,source/'initial-check.py')
(source/'failure-review.json').write_text(json.dumps({'observed_error':"KeyError: 'directed_exchanges'",'location':'check_h5_productive_witnesses.py line 27','reason':'Zero-valued exchange counters are intentionally omitted by serialization. The checker incorrectly required the key. Use the existing default of zero for an absent counter; preserve every positive-count and material assertion. Candidate code and test outcomes are unchanged.','initial_partial_outputs_preserved':True},indent=2)+'\n',encoding='utf-8',newline='\n')
source.rename(saved)
text=checker.read_text(encoding='utf-8');old="row['stats']['directed_exchanges']==0";assert text.count(old)==1
checker.write_text(text.replace(old,"row['stats'].get('directed_exchanges',0)==0"),encoding='utf-8',newline='\n')
shutil.copyfile(__file__,saved/'repair.py')
print('Original checker and partial validations preserved; zero-counter handling corrected')
