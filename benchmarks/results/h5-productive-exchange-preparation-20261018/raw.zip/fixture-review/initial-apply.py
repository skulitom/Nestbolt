from pathlib import Path
import difflib,json,shutil
root=Path(__file__).resolve().parents[1];out=root/'output/h5-productive-exchange-probe-20261018'
proof=json.loads((out/'regressions-before.json').read_bytes())
assert proof['expected_counts'] and proof['same_inventory_improvement_passed']
assert proof['unchanged_inventory_assertion_failed'] and proof['pair_diversity_assertion_failed']
path=out/'candidate/crates/core/src/sheets/vstrip/exchange.rs'
text=path.read_text(encoding='utf-8');before=text
shutil.copyfile(path,out/'exchange-regressions-before.rs')
start=text.index('// Try nearby copies of the same original part.')
end=text.index('// Incoming groups must preserve',start)
text=text[:start]+(root/'output/productive_pair_selection.rs').read_text(encoding='utf-8')+text[end:]
needle='''                    sep.layout = trial;
                    sep.rebuild();'''
assert text.count(needle)==1
replacement='''                    // Same inventory can still improve the geometry, but a
                    // flat material result must not consume the sole exchange.
                    if same_original_inventory(&members, &victims)
                        && after.material_area >= before.material_area
                    {
                        self.stats.neutral_exchange_rejections += 1;
                        continue;
                    }
                    sep.layout = trial;
                    sep.rebuild();'''
text=text.replace(needle,replacement)
path.write_text(text,encoding='utf-8',newline='\n')
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='post-fill-before',tofile='productive-after')),encoding='utf-8',newline='\n')
path=out/'candidate/crates/core/src/sheets.rs';text=path.read_text(encoding='utf-8')
needle='    pub post_exchange_fill_moves: u64,';assert text.count(needle)==1
path.write_text(text.replace(needle,needle+'\n    #[serde(skip_serializing_if = "is_zero")]\n    pub neutral_exchange_rejections: u64,'),encoding='utf-8',newline='\n')
builder=(root/'output/build_h5_post_exchange_fill.py').read_text(encoding='utf-8').replace('h5-post-exchange-fill-probe-20261018','h5-productive-exchange-probe-20261018')
needle="run('core-tests',['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',plan['target']])"
assert builder.count(needle)==1
builder=builder.replace(needle,needle[:-2]+",'--','--nocapture'])")
(root/'output/build_h5_productive_exchange.py').write_text(builder,encoding='utf-8',newline='\n')
print('Varied bounded pairs and same-inventory material guard applied in the isolated candidate')
