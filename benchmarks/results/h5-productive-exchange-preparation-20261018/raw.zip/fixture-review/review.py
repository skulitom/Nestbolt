"""Preserve and replace a rounding-only positive fixture with a real material saving."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-productive-exchange-probe-20261018'
review=out/'fixture-review';review.mkdir(exist_ok=False)
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
rel='crates/core/src/sheets/vstrip/exchange.rs';candidate=out/'candidate'/rel
for source,name in [(candidate,'initial-exchange.rs'),(root/'output/productive_exchange_tests.rs','initial-tests.rs'),(root/'output/check_h5_productive_exchange_before.py','initial-check.py'),(root/'output/apply_h5_productive_exchange.py','initial-apply.py')]:
    shutil.copyfile(source,review/name)
witnesses=[json.loads(line.split('PRODUCTIVE_WITNESS ',1)[1]) for line in (out/'regressions-before.log').read_text(encoding='utf-8').splitlines() if line.startswith('PRODUCTIVE_WITNESS ')]
witness=next(w for w in witnesses if w['case']=='same_inventory_improves')
job=copy.deepcopy(witness['job']);before=copy.deepcopy(witness['before'])
ceiling=copy.deepcopy(job['parts'][0]);ceiling.update(id='ceiling',quantity=1)
ceiling['geometry']=[{'outer':[[0.,0.],[94.,0.],[94.,.5],[0.,.5]],'holes':[]}]
job['parts'].append(ceiling)
before['placements'].append({'part_id':'ceiling','copy_index':0,'sheet_id':'sheet-0','transform':{'translation':[2.,98.],'rotation_radians':0.,'mirrored':False}})
after=copy.deepcopy(before)
for p in after['placements']:
    if p['part_id']=='incoming':p['sheet_id']='sheet-0' if p['sheet_id']=='sheet-1' else 'sheet-1'
cli=root/'target/release/nestbolt.exe';records=[]
for name,j,l in [('initial-before',witness['job'],witness['before']),('initial-after',witness['job'],witness['after']),('reviewed-before',job,before),('reviewed-after',job,after)]:
    jp=review/(name+'-job.json');lp=review/(name+'-layout.json');write(jp,j);write(lp,l)
    args=[str(cli),'validate','--job',str(jp),'--layout',str(lp)]
    result=subprocess.run(args,capture_output=True,timeout=60)
    (review/(name+'-stdout.json')).write_bytes(result.stdout);(review/(name+'-stderr.log')).write_bytes(result.stderr)
    write(review/(name+'-command.json'),{'command':args,'exit_code':result.returncode})
    assert result.returncode==0,(name,result.stderr)
    report=json.loads(result.stdout);assert report['valid'],report
    records.append({'case':name,'valid':True,'material':report['metrics']['material_area']})
assert abs(records[0]['material']-records[1]['material'])<.001
assert abs(records[2]['material']-records[3]['material']-100.)<.001
old='''        (job, layout)
    }

    #[test]
    fn productive_exchange_rejects_unchanged_inventory_without_material_gain()'''
new='''        if taller_source {
            // The validator credits the largest offcut on either sheet. Keep
            // the receiver taller so exchanging the pairs saves real material.
            job.parts.push(rectangle("ceiling", 94.0, 0.5));
            layout.placements.push(Placement {
                part_id: "ceiling".into(), copy_index: 0, sheet_id: "sheet-0".into(),
                transform: RigidTransform {
                    translation: [2.0, 98.0], rotation_radians: 0.0, mirrored: false,
                },
            });
        }
        (job, layout)
    }

    #[test]
    fn productive_exchange_rejects_unchanged_inventory_without_material_gain()'''
for path in [candidate,root/'output/productive_exchange_tests.rs']:
    text=path.read_text(encoding='utf-8');assert text.count(old)==1
    text=text.replace(old,new)
    assertion='assert!(report.metrics.unwrap().material_area < before);'
    assert text.count(assertion)==1
    text=text.replace(assertion,'assert!(before - report.metrics.unwrap().material_area > 99.9);')
    path.write_text(text,encoding='utf-8',newline='\n')
driver=(root/'output/check_h5_productive_exchange_before.py').read_text(encoding='utf-8').replace('regressions-before','regressions-before-v2')
(root/'output/check_h5_productive_exchange_before_v2.py').write_text(driver,encoding='utf-8',newline='\n')
path=root/'output/apply_h5_productive_exchange.py';text=path.read_text(encoding='utf-8').replace("out/'regressions-before.json'","out/'regressions-before-v2.json'")
path.write_text(text,encoding='utf-8',newline='\n')
write(review/'review.json',{'reason':'Initial positive test passed on less than 0.001 mm2 rounding difference; it did not demonstrate useful material reduction. Added a receiver ceiling to make the intended swap save 100 mm2 and strengthened the positive assertion to >99.9 mm2. Runtime is unchanged. Original tests, logs, and passed original reference check remain preserved.','CLI_sha256':sha256(cli.read_bytes()).hexdigest(),'records':records,'measured_searches':0})
shutil.copyfile(__file__,review/'review.py')
print(json.dumps(records))
