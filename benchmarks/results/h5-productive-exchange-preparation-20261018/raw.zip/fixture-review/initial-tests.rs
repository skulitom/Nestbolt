    fn equal_inventory_fixture(taller_source: bool) -> (Job, Layout) {
        let (mut job, mut layout) = balanced_fixture();
        job.parts.retain(|p| p.id != "return");
        job.parts.iter_mut().find(|p| p.id == "incoming").unwrap().quantity = 4;
        layout.placements.retain(|p| p.part_id != "return");
        for p in &mut layout.placements {
            if taller_source && p.part_id == "incoming" && p.copy_index == 1 {
                p.transform.translation[1] = 52.0;
            }
        }
        for (copy_index, y) in [(2, 2.0), (3, 49.0)] {
            layout.placements.push(Placement {
                part_id: "incoming".into(), copy_index, sheet_id: "sheet-0".into(),
                transform: RigidTransform {
                    translation: [2.0, y], rotation_radians: 0.0, mirrored: false,
                },
            });
        }
        (job, layout)
    }

    #[test]
    fn productive_exchange_rejects_unchanged_inventory_without_material_gain() {
        let (job, layout) = equal_inventory_fixture(false);
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            eprintln!("PRODUCTIVE_WITNESS {}", serde_json::json!({
                "case":"unchanged_inventory", "seed":seed, "job":&job,
                "before":&layout, "after":&after, "moved":moved, "stats":&stats,
            }));
            assert_eq!(moved, 0, "unchanged inventory with no material gain must not end exchange search: {stats:?}");
            assert_eq!(stats.directed_exchanges, 0);
            assert!(stats.paired_exchange_attempts > 0);
        }
    }

    #[test]
    fn productive_exchange_keeps_same_inventory_when_material_decreases() {
        let (job, layout) = equal_inventory_fixture(true);
        let before = validate(&job, &layout).unwrap().metrics.unwrap().material_area;
        for seed in 0..4 {
            let (moved, after, stats) = exercise(&job, &layout, seed, true, false, 0);
            eprintln!("PRODUCTIVE_WITNESS {}", serde_json::json!({
                "case":"same_inventory_improves", "seed":seed, "job":&job,
                "before":&layout, "after":&after, "moved":moved, "stats":&stats,
            }));
            assert_eq!(moved, 1, "a same-inventory exchange that saves material must remain eligible: {stats:?}");
            assert_eq!(stats.paired_exchanges, 1);
            let report = validate(&job, &after).unwrap();
            assert!(report.valid);
            assert!(report.metrics.unwrap().material_area < before);
        }
    }

    #[test]
    fn productive_exchange_pair_selection_reaches_different_part_types() {
        let (job, layout) = balanced_fixture();
        let model = Model::new(&job).unwrap();
        let sheets = model.sheets_of(&layout).unwrap();
        let mut items: Vec<_> = model.instance.items.iter().map(|(item,_)| item.clone()).collect();
        items.sort_by(|a,b| b.area().total_cmp(&a.area()));
        assert_eq!(items.len(),3);
        let mut many = JLayout::new(sheets[0].layout().container().clone());
        let mut keys = Vec::new();
        for (family,item) in items.iter().enumerate() {
            for copy in 0..20 {
                keys.push(many.place_item(item, DTransformation::new(0.0, (copy as f32*500.0, family as f32*10000.0))));
            }
        }
        let pairs = incoming_pairs(&many,&keys);
        assert_eq!(pairs.len(),6);
        assert_eq!(pairs,incoming_pairs(&many,&keys));
        let mut families: Vec<_> = pairs.iter().map(|p|many.placed_items()[p[0]].item().idx()).collect();
        families.sort_unstable();families.dedup();
        assert_eq!(families.len(),3,"bounded pair choices must reach all three available part types");
        for (index,pair) in pairs.iter().enumerate() {
            assert!(!pairs[..index].contains(pair));
            assert_eq!(pair.len(),2);assert_ne!(pair[0],pair[1]);
            assert!(std::sync::Arc::ptr_eq(many.placed_items()[pair[0]].item(),many.placed_items()[pair[1]].item()));
        }
    }
