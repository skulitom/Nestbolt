// Distribute a bounded set of nearby same-item pairs across original part types.
// The caller supplies stable decreasing-area order. Pointer identity keeps
// distinct original items separate even when their shapes or indices match.
fn incoming_pairs(layout: &JLayout, keys: &[PItemKey]) -> Vec<Vec<PItemKey>> {
    let mut groups: Vec<Vec<usize>> = Vec::new();
    for (index, &key) in keys.iter().enumerate() {
        let item = layout.placed_items()[key].item();
        if let Some(group) = groups.iter_mut().find(|group| {
            std::sync::Arc::ptr_eq(layout.placed_items()[keys[group[0]]].item(), item)
        }) {
            group.push(index);
        } else {
            groups.push(vec![index]);
        }
    }
    groups.retain(|group| group.len() >= 2);
    let mut anchors = Vec::new();
    for rank in 0..12 {
        for (group, members) in groups.iter().enumerate() {
            if let Some(&index) = members.get(rank) {
                anchors.push((group, index));
                if anchors.len() == 12 {
                    break;
                }
            }
        }
        if anchors.len() == 12 {
            break;
        }
    }
    let mut grouped_pairs = vec![Vec::new(); groups.len()];
    for (group, i) in anchors {
        let a = layout.placed_items()[keys[i]].shape().bbox();
        let mut neighbours: Vec<_> = groups[group]
            .iter()
            .filter_map(|&j| {
                if i == j {
                    return None;
                }
                let b = layout.placed_items()[keys[j]].shape().bbox();
                let dx = (a.x_min + a.x_max) - (b.x_min + b.x_max);
                let dy = (a.y_min + a.y_max) - (b.y_min + b.y_max);
                Some((dx * dx + dy * dy, j))
            })
            .collect();
        neighbours.sort_by(|a,b| a.0.total_cmp(&b.0).then(a.1.cmp(&b.1)));
        for (_,j) in neighbours.into_iter().take(2) {
            let pair = (i.min(j),i.max(j));
            if !grouped_pairs[group].contains(&pair) {
                grouped_pairs[group].push(pair);
            }
        }
    }
    let mut pairs = Vec::new();
    for rank in 0..24 {
        for group in &grouped_pairs {
            if let Some(&(a,b)) = group.get(rank) {
                pairs.push(vec![keys[a],keys[b]]);
                if pairs.len()==6 { return pairs; }
            }
        }
    }
    pairs
}

fn same_original_inventory(a: &[IncomingMember], b: &[IncomingMember]) -> bool {
    a.len() == b.len() && a.iter().all(|(_,item,_)| {
        a.iter().filter(|(_,other,_)|std::sync::Arc::ptr_eq(item,other)).count()
        == b.iter().filter(|(_,other,_)|std::sync::Arc::ptr_eq(item,other)).count()
    })
}

