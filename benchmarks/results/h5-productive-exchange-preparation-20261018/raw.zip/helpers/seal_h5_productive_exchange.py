"""Seal the qualified isolated candidate before any development performance run."""
from pathlib import Path
from hashlib import sha256
import difflib,json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-productive-exchange-probe-20261018'
out=root/'benchmarks/results/h5-productive-exchange-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');public=load(probe/'public-checks/checks.json');witness=load(probe/'witness-checks/checks.json')
assert build['all_checks_passed'] and public['all_checks_passed'] and witness['all_checks_passed']
assert witness['actual_outcomes']==8 and witness['public_validations']==16
assert '101 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
for row in public['records']:
    stats=row['stats'];calls=stats.get('post_exchange_fill_calls',0);moves=stats.get('post_exchange_fill_moves',0)
    assert type(calls) is int and type(moves) is int and moves<=stats.get('direct_insertions',0)
    if row['arm']=='candidate':assert calls==stats.get('directed_exchanges',0)
    else:assert calls==moves==0
for name in ['regressions-before','regressions-before-v2']:
    regression=load(probe/(name+'.json'))
    assert regression['runtime_unchanged'] and regression['unchanged_inventory_assertion_failed'] and regression['pair_diversity_assertion_failed'] and regression['same_inventory_improvement_passed'] and regression['expected_counts']
    assert digest(probe/(name+'.log'))==regression['log_sha256']
review=load(probe/'fixture-review/review.json');assert len(review['records'])==4
assert abs(review['records'][2]['material']-review['records'][3]['material']-100)<.001
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
assert digest(probe/'rejected-fill-observer.exe')==plan['rejected_fill_observer_sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json');assert digest(root/method['reference'])==method['reference_sha256'] and digest(root/method['candidate_runner'])==method['runner_sha256']
exchange='crates/core/src/sheets/vstrip/exchange.rs'
before=(Path(plan['old_probe'])/'candidate'/exchange).read_text(encoding='utf-8');after=(probe/'candidate'/exchange).read_text(encoding='utf-8')
assert after[after.index('#[cfg(test)]'):].startswith(before[before.index('#[cfg(test)]'):].rsplit('\n}',1)[0])
patch=[]
for rel in plan['changed_files']:
    before=(Path(plan['old_probe'])/'candidate'/rel).read_text(encoding='utf-8');after=(probe/'candidate'/rel).read_text(encoding='utf-8')
    patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='post-fill/'+rel,tofile='productive/'+rel))
(probe/'candidate-final.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
out.mkdir(exist_ok=False)
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
helpers=['prepare_h5_productive_exchange.py','check_h5_productive_exchange_before.py','check_h5_productive_exchange_before_v2.py','review_h5_productive_fixture.py','apply_h5_productive_exchange.py','build_h5_productive_exchange.py','prepare_h5_productive_checks.py','check_h5_productive_exchange_public.py','check_h5_productive_exchange_harness.py','check_h5_productive_witnesses.py','seal_h5_productive_exchange.py','record_h5_productive_preparation.py','productive_exchange_tests.rs','productive_pair_selection.rs']
for name in helpers:files['helpers/'+name]=root/'output'/name
files['helpers/pilot.py']=root/'scripts/h5_productive_exchange_pilot.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(archive),'bytes':archive.stat().st_size,'members':inventory,'all_members_and_crc_verified':True})
write(out/'checks.json',{'all_functional_checks_pass':True,'optimized_core_passed':101,'all_98_previous_tests_retained':True,'new_regression_tests':3,'original_runtime_fails_two_new_regressions':True,'positive_same_inventory_exchange_saves_over_99_9_mm2':True,'initial_rounding_only_positive_fixture_preserved_and_replaced':True,'actual_exchange_witnesses':8,'actual_witness_CLI_validations':16,'strict_lint_pass':True,'public_observer_outcomes':10,'public_CLI_cross_checks':4,'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,'pilot_harness_tests':5,'production_files_unchanged':True,'binaries':build['binaries'],'measured_search_started':False,'H5_complete':False,'integrated':False,'completed_weight_percent':60})
for name in ['preparation.json','build.json','regressions-before.json','regressions-before-v2.json','candidate-final.patch','pilot-method.json']:shutil.copyfile(probe/name,out/name)
doc='''# Varied pairs and productive exchanges — preparation, 2026-10-18

The [identity diagnosis](h5-balanced-stage-20261018.md) found accepted swaps
of the same part inventory with no material/extent reduction. Continuing
[gap filling](h5-post-exchange-fill-pilot-20261018.md) helped some authored
and bracket cases but all four mechanical comparisons still failed the
original material limit. Both results remain preserved.

This isolated candidate distributes at most twelve anchors and six nearby
same-original-item pairs across part types in stable order. It rejects a
validated swap of equal original-item multisets unless material strictly
decreases. Swaps changing sheet inventory retain the nonincrease rule.
Original-item pointer identity and multiplicities distinguish inventories;
geometry, source/receiver repairs, phase/total budgets and post-exchange
gap filling remain. An omitted-zero counter records neutral rejections.
This is a candidate policy, not evidence that neutral swaps can never help.

Two new authored regressions fail on the unchanged runtime: it only reaches
one of three available pair families and accepts a swap saving no material.
A third test protects same-inventory swaps that save material. Its first
fixture passed on a 0.0006 mm2 rounding difference; original source, logs,
and independent checks are retained. Adding a receiver ceiling makes the
authored swap save 100 mm2, independently validated. The strengthened test
requires more than 99.9 mm2; the unchanged runtime passes that positive
case and still fails the two target regressions before any runtime edit.

All 101 optimized core tests pass, including all 98 previous tests. Sixteen
public CLI validations cover before/after geometry and quantities for eight
actual authored outcomes across four seeds: no-op swaps reject with exact
internal-state rollback, useful same-inventory swaps remain accepted.
Strict lint/build, ten public fixed-work observer outcomes, four public CLI
comparisons and five adversarial paired-harness checks also pass. Normal
output and common fixed-work replays stay exact except for wall duration.
Original sources, binaries, archive CRC and every member hash verify.
The first witness checker incorrectly indexed an omitted zero-valued
exchange counter; its source, error review and partial validations remain.
Reading the absent counter as zero fixes the checker without changing any
candidate result, material assertion or positive-counter requirement.

The paired pilot retains four jobs, two kerfs, three seeds, three sequential
rotating arms per block, eight physical CCD0 cores and 60-second searches.
Block, scoring, case and measurement functions are AST-identical to the
previous pilot. The original +1% material limit and full 13-job gate remain.
No production integration or measured quality claim; H2/H5 stay open at 60%.
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-productive-exchange-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:
    f.write('''

## 2026-10-18 — Qualify varied pairs and productive exchanges

[The isolated candidate](benchmarks/results/h5-productive-exchange-preparation-20261018.md)
passes 101 optimized core tests, preserving all 98 previous tests, strict
lint/build, ten authored public outcomes, four public CLI comparisons and
five paired-harness checks. Sixteen additional independent validations
cover eight actual exchange outcomes. It distributes bounded pairs across
part types and requires strict material improvement for same-inventory swaps;
different-inventory swaps retain the existing nonincrease rule.

Two new regressions fail on the unchanged runtime; a strengthened positive
witness still passes and saves over 99.9 mm2. The initial rounding-only
positive fixture, original runs and all failed pilots remain preserved.
Normal output, common fixed-work replay, budgets, geometry validation and
paired scoring rules are unchanged. No production change or measured
improvement is claimed. H2/H5 remain open at 60%.
''')
print(json.dumps({'sealed':str(out),'members':len(inventory),'bytes':archive.stat().st_size}))
