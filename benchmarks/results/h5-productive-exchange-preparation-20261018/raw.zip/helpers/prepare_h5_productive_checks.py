"""Prepare the unchanged paired pilot and functional checks for productive exchange selection."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-productive-exchange-probe-20261018'
source=root/'scripts/h5_post_exchange_fill_pilot.py';text=source.read_text(encoding='utf-8')
text=text.replace('h5-post-exchange-fill-probe-20261018','h5-productive-exchange-probe-20261018')
text=text.replace('h5-post-exchange-fill-preparation-20261018','h5-productive-exchange-preparation-20261018')
text=text.replace('h5-balanced-group-pilot-20261018/results.json','h5-post-exchange-fill-pilot-20261018/results.json')
text=text.replace('Isolated post-exchange gap-fill candidate, common-line search bonus on','Isolated varied-pair and productive-exchange candidate, common-line search bonus on')
end=text.index('"""',3)+3
text='''"""Paired development pilot for varied pair selection and productive exchanges.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The baseline is the unchanged preview. The candidate distributes bounded
same-original-item pairs across part types and requires a material decrease
for swaps preserving the per-sheet item inventory. Changed-inventory swaps
keep their nonincrease rule. Post-exchange gap filling, repairs, samplers,
geometry validation and total budgets remain. This cannot close H5.
"""'''+text[end:]
needle="ROOT/'benchmarks/results/h5-balanced-stage-20261018/control-flow-review.json'])"
assert text.count(needle)==1
text=text.replace(needle,"ROOT/'benchmarks/results/h5-balanced-stage-20261018/control-flow-review.json',\n                  ROOT/'benchmarks/results/h5-post-exchange-fill-pilot-20261018/verification.json',\n                  PROBE/'witness-checks/checks.json'])")
target=root/'scripts/h5_productive_exchange_pilot.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
def functions(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef)}
before,after=functions(source),functions(target);names=['blocks','summarize','case','measure']
assert all(before[n]==after[n] for n in names)
method={'reference':source.relative_to(root).as_posix(),'reference_sha256':sha256(source.read_bytes()).hexdigest(),'candidate_runner':target.relative_to(root).as_posix(),'runner_sha256':sha256(target.read_bytes()).hexdigest(),'identical_function_ASTs':names,'scoring_or_measurement_changed':False}
(probe/'pilot-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n')
for suffix in ['public','harness']:
    p=root/f'output/check_h5_post_exchange_fill_{suffix}.py'
    s=p.read_text(encoding='utf-8').replace('h5-post-exchange-fill-probe-20261018','h5-productive-exchange-probe-20261018').replace('h5_post_exchange_fill_pilot','h5_productive_exchange_pilot')
    (root/f'output/check_h5_productive_exchange_{suffix}.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(method))
