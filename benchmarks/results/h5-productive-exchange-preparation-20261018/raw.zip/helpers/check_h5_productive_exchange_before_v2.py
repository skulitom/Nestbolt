"""Run the three new authored checks against the unchanged previous runtime."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-productive-exchange-probe-20261018'
plan=json.loads((out/'preparation.json').read_bytes());work=out/'candidate';old=Path(plan['old_probe'])/'candidate'
rel='crates/core/src/sheets/vstrip/exchange.rs'
assert (work/rel).read_text(encoding='utf-8').split('#[cfg(test)]')[0]==(old/rel).read_text(encoding='utf-8').split('#[cfg(test)]')[0]
assert (work/'crates/core/src/sheets.rs').read_bytes()==(old/'crates/core/src/sheets.rs').read_bytes()
command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',plan['target'],'productive_exchange_','--','--nocapture']
started=datetime.now(timezone.utc).isoformat()
with (out/'regressions-before-v2.log').open('xb') as f:
    result=subprocess.run(command,cwd=work,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
log=(out/'regressions-before-v2.log').read_text(encoding='utf-8')
record={'command':command,'exit_code':result.returncode,'started':started,'finished':datetime.now(timezone.utc).isoformat(),
    'log_sha256':sha256((out/'regressions-before-v2.log').read_bytes()).hexdigest(),'runtime_unchanged':True,
    'unchanged_inventory_assertion_failed':'unchanged inventory with no material gain must not end exchange search:' in log,
    'pair_diversity_assertion_failed':'bounded pair choices must reach all three available part types' in log,
    'same_inventory_improvement_passed':'productive_exchange_keeps_same_inventory_when_material_decreases ... ok' in log,
    'expected_counts':'1 passed; 2 failed' in log,'measured_searches':0}
(out/'regressions-before-v2.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
assert result.returncode==101 and all(record[k] for k in ['unchanged_inventory_assertion_failed','pair_diversity_assertion_failed','same_inventory_improvement_passed','expected_counts']),record
print(json.dumps(record))
