"""Qualify varied pair choices and reject inventory-preserving exchanges with no material reduction."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,sys
root=Path(__file__).resolve().parents[1]
out=root/'output/h5-productive-exchange-probe-20261018';out.mkdir(exist_ok=False)
old=root/'output/h5-post-exchange-fill-probe-20261018'
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
rel='crates/core/src/sheets/vstrip/exchange.rs';p=out/'candidate'/rel
text=p.read_text(encoding='utf-8');closing=text.rindex('\n}')
p.write_text(text[:closing]+'\n'+(root/'output/productive_exchange_tests.rs').read_text(encoding='utf-8')+text[closing:],encoding='utf-8',newline='\n')
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
shutil.copyfile(old/'candidate-observer.exe',out/'rejected-fill-observer.exe')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'scope':__doc__,'old_probe':str(old),
    'changed_files':[rel,'crates/core/src/sheets.rs'],'added_files':{},'production_digest':source_digest(),
    'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},
    'target':str(root/'output/h5-productive-exchange-target-20261018'),
    'baseline_observer_sha256':digest(out/'baseline-observer.exe'),'rejected_fill_observer_sha256':digest(out/'rejected-fill-observer.exe'),
    'policy':'At most twelve anchors and six same-original-item pairs, distributed across original part types in stable order. Reject a validated exchange with the same incoming/returned original-item multiset unless material strictly decreases. Exchanges changing sheet inventory keep the existing nonincrease rule. Pair phases, return groups, both repairs, original material/geometry guards, post-exchange gap filling and total search budgets remain.',
    'new_tests':3,'all_98_existing_tests_retained':True,'measured_search_started':False,'H5_complete':False,'integrated':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'prepared':str(out),'new_tests':3,'runtime_unchanged':True}))
