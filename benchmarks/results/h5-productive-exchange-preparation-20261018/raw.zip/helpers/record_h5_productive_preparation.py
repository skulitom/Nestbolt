from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
checks=json.loads((root/'benchmarks/results/h5-productive-exchange-preparation-20261018/checks.json').read_bytes())
assert checks['all_functional_checks_pass'] and checks['original_runtime_fails_two_new_regressions']
marker='**N4 productive-exchange preparation, 2026-10-18:**'
note='''**N4 productive-exchange preparation, 2026-10-18:** [the isolated candidate](../benchmarks/results/h5-productive-exchange-preparation-20261018.md)
passes 101 optimized core tests, preserving all 98 previous tests, strict
lint/build, ten authored public outcomes, four CLI comparisons and five
paired-harness checks. It distributes bounded pairs across original part
types and rejects same-inventory swaps without material reduction. Two
new regressions fail on the unchanged runtime, while a positive witness
saving over 99.9 mm2 passes. The original rounding-only positive fixture
is preserved. Sixteen independent validations cover eight actual authored
outcomes. Normal output and common fixed-work replay pass; geometry,
budgets and the +1% material limit remain. The committed 72-outcome pilot
retains the previous paired method. No production change or H5 credit;
H2/H5 remain open at 60%.
'''
paths=[root/n for n in ['docs/STATUS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']]
assert all(marker not in p.read_text(encoding='utf-8') for p in paths)
p=paths[0];text=p.read_text(encoding='utf-8');at=text.index('**N4 post-exchange gap-fill outcome, 2026-10-18:**')
p.write_text(text[:at]+note+'\n'+text[at:],encoding='utf-8',newline='\n')
for p in paths[1:]:
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write('\n\n'+note)
print('Candidate preparation recorded without milestone credit')
