"""Fine-capacity canonical model with provably impossible unary mask choices removed."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];COARSE=ROOT/'output/h5-first55-local-grid-regions-20261029';BASE=ROOT/'output/h5-first55-fine-grid-regions-20261104';PRE=BASE;RID=BASE;TARGET=ROOT/'output/h5-first55-fine-eleven-companion-model-20261104';COUNT=ROOT/'output/h5-first55-eleven-companion-inputs-20261104';GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';STRIP=ROOT/'output/h5-first55-direct-fine-strip-capacity-20261029';FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';AXIS=COARSE/'component-halfspace-bound';OUT=TARGET/'model';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';ORIGINAL_COUNT=ROOT/'output/h5-first55-direct-fine-filtered-components-20261029';FINAL_COUNT=ROOT/'output/h5-first55-direct-smaller-block-filtered-20261104';PAIR_BOUND=ROOT/'output/h5-shared-five-pair-domain-bound-20261029';FOUR_BOUND=ROOT/'output/h5-shared-four-direct-difference-bound-20261104';THREE_BOUND=ROOT/'output/h5-shared-three-bracket-difference-bound-20261104';TWO_DOMAIN=ROOT/'output/h5-shared-two-insert-domain-20261104';TWO_SOURCE=ROOT/'output/h5-source-two-insert-continuous-block-20261104';FACTOR=ROOT/'output/h5-first55-component-factorization-20261029'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'geometry-audit/checks.json')['passed'] and load(COUNT/'audit/checks.json')['passed']
assert load(COUNT/'audit/checks.json')['all_source_mode_aliases_agree_on_component']
TARGET.mkdir()
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
modes=load(BASE/'family-modes.json');instances=load(COUNT/'instances.json');unary=load(BASE/'unary-templates.json');model=cp_model.CpModel()
def linear(co,lo,hi,guard=None):
    expression=sum(c*model.get_int_var_from_proto_index(i) for i,c in co.items() if c)
    ct=model.add_linear_constraint(expression,lo,hi)
    if guard is not None:ct.only_enforce_if(model.get_bool_var_from_proto_index(guard))
    return ct.index
owners=[]
for i,instance in enumerate(instances):
    fm=modes[instance['identity'][0]];positions=[]
    for axis in [0,1]:positions.append(model.new_int_var(min(m['integer_lower_left_bounds'][axis][0] for m in fm),max(m['integer_lower_left_bounds'][axis][1] for m in fm),f'{"x" if axis==0 else "y"}_{i}_grid').index)
    owners.append({'owner':i,'identity':instance['identity'],'positions':positions,'modes':[],'unary_regions':[],'unary_geometry_marginals':[]})
for owner in owners:
    for mode in modes[owner['identity'][0]]:
        selector=model.new_bool_var(f'mode_{owner["owner"]}_{mode["mode"]}').index;record={**mode,'selector':selector,'stock_constraints':[]}
        for axis,var in enumerate(owner['positions']):
            lo,hi=mode['integer_lower_left_bounds'][axis];record['stock_constraints'].append(linear({var:1},lo,hi,selector))
        owner['modes'].append(record)
    owner['one_mode_constraint']=linear({m['selector']:1 for m in owner['modes']},1,1)
empty=[model.new_bool_var(f'empty_cog_site_{i}').index for i in range(15)];exact_two=linear({v:1 for v in empty},2,2)
allowed=load(COUNT/'audit/allowed-empty-site-pairs.json');forbidden=[]
for a,b in combinations(range(15),2):
    if [a,b] not in allowed:forbidden.append({'empty_sites':[a,b],'constraint':linear({empty[a]:1,empty[b]:1},cp_model.INT_MIN,1)})
assert len(forbidden)==101
eligible={(a[0],a[2],a[3]) for row in load(COUNT/'all4-companion-bounds.json') for a in row['region_component_assignments']}
unary_plane_count=mask_links=mask_pruned_unary_count=fixed_block_pruned_count=0
for owner in owners:
    i=owner['owner'];geometries=sorted({m['normalized_geometry'] for m in owner['modes']})
    for gid in geometries:
        for region in unary[gid]['regions']:
            if not any(set(region['required_empty_sites'])<=set(sites) for sites in allowed):mask_pruned_unary_count+=1;continue
            if (owner['identity'][0],gid,region['region']) not in eligible:fixed_block_pruned_count+=1;continue
            selector=model.new_bool_var(f'unary_{i}_{gid}_{region["region"]}').index
            record={'geometry':gid,'region':region['region'],'selector':selector,'required_empty_sites':region['required_empty_sites'],'plane_constraints':[],'empty_site_constraints':[]}
            for plane in region['planes']:
                nx,ny=plane['coefficients'];record['plane_constraints'].append(linear({2*i:nx,2*i+1:ny},cp_model.INT_MIN,plane['upper'],selector));unary_plane_count+=1
            for site in region['required_empty_sites']:
                record['empty_site_constraints'].append(linear({selector:1,empty[site]:-1},cp_model.INT_MIN,0));mask_links+=1
            owner['unary_regions'].append(record)
    owner['one_unary_region_constraint']=linear({r['selector']:1 for r in owner['unary_regions']},1,1)
    for gid in geometries:
        ms=[m['selector'] for m in owner['modes'] if m['normalized_geometry']==gid];rs=[r['selector'] for r in owner['unary_regions'] if r['geometry']==gid]
        owner['unary_geometry_marginals'].append({'geometry':gid,'mode_selectors':ms,'region_selectors':rs,'constraint':linear({**{i:-1 for i in ms},**{i:1 for i in rs}},0,0)})
pairs=[];pair_plane_count=0
mode_rectangles=load(RID/'mode-rectangles.json');component_inventory=load(COUNT/'components.json');component_pairs=load(COUNT/'component-pairs.json');components=[];separations=[];coordinate_links=0
labels=['left','bottom','right','top']
for item in component_inventory:
    owner=owners[item['owner']];family=owner['identity'][0];piece=item['piece'];coords=[]
    for k,label in enumerate(labels):
        axis=k%2
        lo=min(m['integer_lower_left_bounds'][axis][0]+mode_rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        hi=max(m['integer_lower_left_bounds'][axis][1]+mode_rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        coords.append(model.new_int_var(lo,hi,f'rect_{item["component"]}_{label}_grid').index)
    record={**item,'coordinates':coords,'mode_links':[]}
    for mode in owner['modes']:
        offsets=mode_rectangles[family][mode['mode']]['rectangles'][piece]['outward_offsets_grid'];constraints=[]
        for k,(var,offset) in enumerate(zip(coords,offsets)):
            constraints.append(linear({var:1,owner['positions'][k%2]:-1},offset,offset,mode['selector']));coordinate_links+=1
        record['mode_links'].append({'mode':mode['mode'],'mode_selector':mode['selector'],'outward_offsets_grid':offsets,'constraints':constraints})
    components.append(record)
for item in component_pairs:
    ai,bi=item['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];selectors=[];constraints=[]
    directions=[{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}]
    for direction,coefficients in enumerate(directions):
        selector=model.new_bool_var(f'separate_{ai}_{bi}_{direction}').index;selectors.append(selector);constraints.append(linear(coefficients,cp_model.INT_MIN,-23,selector))
    separations.append({**item,'selectors':selectors,'constraints':constraints,'one_direction_constraint':linear({v:1 for v in selectors},1,1)})
symmetry=[]
count_choices=[];all_distributions=[]
for pair_index,row in enumerate(load(COUNT/'all4-companion-bounds.json')):
    sites=row['empty_sites'];a,b=sites;pair_var=model.new_bool_var(f'component_site_pair_{a}_{b}').index
    pair_links=[linear({pair_var:1,empty[a]:-1},cp_model.INT_MIN,0),linear({pair_var:1,empty[b]:-1},cp_model.INT_MIN,0),linear({pair_var:1,empty[a]:-1,empty[b]:-1},-1,cp_model.INT_MAX)]
    distributions=[]
    for di,counts in enumerate(row['remaining_distributions']):
        var=model.new_bool_var(f'component_distribution_{pair_index}_{di}').index;distributions.append({'counts':counts,'selector':var});all_distributions.append(var)
    dist_link=linear({**{r['selector']:1 for r in distributions},pair_var:-1},0,0)
    attribution={}
    for family,mode,gid,region,group in row['region_component_assignments']:
        key=(family,gid,region)
        if key in attribution:assert attribution[key]==group
        attribution[key]=group
    observed=set();group_vars=[[] for _ in row['groups']]
    for owner in owners:
        family=owner['identity'][0]
        for region in owner['unary_regions']:
            if not set(region['required_empty_sites'])<=set(sites):continue
            key=(family,region['geometry'],region['region']);assert key in attribution;observed.add(key);group_vars[attribution[key]].append(region['selector'])
    assert observed==set(attribution)
    group_constraints=[]
    for gi,(group,selectors) in enumerate(zip(row['groups'],group_vars)):
        assert selectors
        co={var:1 for var in selectors}
        co.update({r['selector']:-r['counts'][gi] for r in distributions if r['counts'][gi]})
        group_constraints.append({'group':gi,'family':group['family'],'region_selectors':selectors,'constraint':linear(co,0,0,pair_var)})
    owner_groups=[]
    peers={family:sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1]) for family in ['bracket','insert']}
    for distribution in distributions:
        assigned=[None]*len(owners)
        for family in ['bracket','insert']:
            blocks=[]
            for gi,group in enumerate(row['groups']):
                if group['family']==family:blocks.extend([gi]*distribution['counts'][gi])
            assert len(blocks)==len(peers[family])
            for owner,gi in zip(peers[family],blocks):assigned[owner['owner']]=gi
        assert all(v is not None for v in assigned)
        distribution['canonical_owner_groups']=assigned;distribution['within_component_order']=[]
        for family in ['bracket','insert']:
            for left,right in zip(peers[family],peers[family][1:]):
                ai,bi=left['owner'],right['owner']
                if assigned[ai]!=assigned[bi]:continue
                ymin=min(m['integer_lower_left_bounds'][1][0] for o in [left,right] for m in o['modes']);ymax=max(m['integer_lower_left_bounds'][1][1] for o in [left,right] for m in o['modes']);scale=ymax-ymin+1
                coefficient={left['positions'][0]:scale,right['positions'][0]:-scale,left['positions'][1]:1,right['positions'][1]:-1}
                ct=linear(coefficient,cp_model.INT_MIN,0,distribution['selector'])
                distribution['within_component_order'].append({'family':family,'owners':[ai,bi],'group':assigned[ai],'x_scale':scale,'constraint':ct})
    for owner in owners:
        family=owner['identity'][0];coefficients={};members=[]
        for region in owner['unary_regions']:
            if not set(region['required_empty_sites'])<=set(sites):continue
            gi=attribution[(family,region['geometry'],region['region'])];coefficients[region['selector']]=gi+1;members.append({'selector':region['selector'],'group':gi})
        for distribution in distributions:coefficients[distribution['selector']]=-(distribution['canonical_owner_groups'][owner['owner']]+1)
        owner_groups.append({'owner':owner['owner'],'region_groups':members,'constraint':linear(coefficients,0,0,pair_var)})
    count_choices.append({'empty_sites':sites,'pair_selector':pair_var,'pair_and_constraints':pair_links,'distributions':distributions,'distribution_pair_constraint':dist_link,'component_counts':group_constraints,'canonical_owner_component_constraints':owner_groups})
one_pair_choice=linear({r['pair_selector']:1 for r in count_choices},1,1)
one_distribution=linear({v:1 for v in all_distributions},1,1)
validation=model.validate();write(OUT/'validation.json',{'validation':validation});assert validation==''
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
mapping={'owners':owners,'empty_site_selectors':empty,'exactly_two_empty_sites_constraint':exact_two,'pairs':pairs,'rigid_components':components,'rectangle_separations':separations,'rectangle_gap_grid':23,'symmetry_constraints':symmetry,'position_units_per_mm':100,'world_origin_mm':[0,2100],'forbidden_site_pairs':forbidden,'component_count_choices':count_choices,'one_site_pair_choice_constraint':one_pair_choice,'one_count_distribution_constraint':one_distribution};write(OUT/'mapping.json',mapping)
elapsed=time.perf_counter()-started
charges={'source_valid_short11_shared_seconds':load(SHORT/'response-audit/checks.json')['shared_seconds_including_preparation'],'fixed_first_sheet_preparation_seconds':load(FIRST/'checks.json')['seconds'],'cog_site_selection_preparation_seconds':load(SLOTS/'checks.json')['seconds'],'site_mask_region_preparation_seconds':load(PRIOR/'checks.json')['seconds'],'source_rigid_rectangle_preparation_seconds':load(PRIOR/'rigid-rectangle-preflight/checks.json')['seconds'],'source_mask_integer_preparation_seconds':load(PRIOR/'integer-preparation/checks.json')['seconds'],'accessible_area_bound_seconds':load(PRIOR/'accessible-area-bound/checks.json')['seconds'],'connected_capacity_bound_seconds':load(PRIOR/'connected-capacity-bound/checks.json')['seconds'],'local_grid_preparation_seconds':load(COARSE/'checks.json')['seconds'],'fine_grid_preparation_seconds':load(BASE/'checks.json')['seconds'],'component_axis_capacity_bound_seconds':load(AXIS/'checks.json')['seconds'],'generic_component_count_preparation_seconds':load(GENERIC/'checks.json')['seconds'],'direct_fine_area_bound_seconds':load(FINE/'checks.json')['seconds'],'direct_fine_strip_bound_seconds':load(STRIP/'checks.json')['seconds'],'component_count_filter_seconds':load(ORIGINAL_COUNT/'checks.json')['seconds'],'continuous_pair_bound_seconds':load(PAIR_BOUND/'checks.json')['seconds'],'direct_four_part_bound_seconds':load(FOUR_BOUND/'checks.json')['seconds'],'three_bracket_bound_seconds':load(THREE_BOUND/'checks.json')['seconds'],'direct_block_count_filter_seconds':load(FINAL_COUNT/'checks.json')['seconds'],'count_input_preparation_seconds':load(COUNT/'checks.json')['seconds'],'two_insert_domain_seconds':load(TWO_DOMAIN/'checks.json')['seconds'],'continuous_two_insert_construction_seconds':load(TWO_SOURCE/'checks.json')['seconds'],'component_factorization_seconds':load(FACTOR/'checks.json')['seconds'],'cp_model_build_seconds':elapsed};write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),COARSE/'checks.json']+[folder/'checks.json' for folder in [ORIGINAL_COUNT,FINAL_COUNT,PAIR_BOUND,FOUR_BOUND,THREE_BOUND,TWO_DOMAIN,TWO_SOURCE,FACTOR]]+[FINE/'plan.json',FINE/'checks.json',FINE/'audit/plan.json',FINE/'audit/checks.json',GENERIC/'checks.json',STRIP/'plan.json',STRIP/'checks.json',STRIP/'audit/plan.json',STRIP/'audit/checks.json',COUNT/'plan.json',COUNT/'checks.json',COUNT/'audit/plan.json',COUNT/'audit/checks.json',COUNT/'all4-companion-bounds.json',COUNT/'instances.json',COUNT/'components.json',COUNT/'component-pairs.json',COUNT/'fixed-source2.json',COUNT/'audit/allowed-empty-site-pairs.json',AXIS/'plan.json',AXIS/'checks.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',FIRST/'checks.json',SLOTS/'checks.json',SHORT/'response-audit/plan.json',SHORT/'response-audit/checks.json']+[BASE/n for n in ['plan.json','checks.json','family-modes.json','unary-templates.json','mode-rectangles.json','instances.json','inventory.json','components.json','component-pairs.json','allowed-empty-site-pairs.json']]+[PRIOR/n for n in ['plan.json','checks.json','rigid-rectangle-preflight/checks.json','integer-preparation/checks.json','accessible-area-bound/checks.json','connected-capacity-bound/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Use new0.01mm grid geometry, scale100000 normals and0.23mm outward-rectangle spacing. Charge both original coarse-grid prerequisite preparation and the new fine-grid preparation. Construct every one of the five remaining independent eleven-part companions across four site choices, with seven source brackets and four source inserts. The two other source inserts have fixed validated continuous poses and are separated from all companions by the audited source-support factorization. Use complete source modes, only companion unary regions, all rigid rectangle links, all146 different-owner rectangle pairs and conditional component counts. Canonicalize interchangeable copies within their components. No objective or hints. Independently audit every model field before one60/90-second call; all previous calls remain closed.','algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'source_validation_reserve_seconds':4,'retry_permitted':False,'solver_calls':0})
result={'passed':True,'seconds':elapsed,'preparation_seconds_charged':sum(charges.values()),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'original_moving_parts':len(owners),'source_mode_selectors':sum(len(o['modes']) for o in owners),'empty_site_selectors':15,'retained_empty_site_pairs':len(allowed),'forbidden_site_pair_constraints':len(forbidden),'component_pair_selectors':len(count_choices),'component_distribution_selectors':len(all_distributions),'conditional_component_count_equalities':sum(len(r['component_counts']) for r in count_choices),'unary_site_mask_pruned_selectors':mask_pruned_unary_count,'fixed_block_pruned_unary_selectors':fixed_block_pruned_count,'unary_region_selectors':sum(len(o['unary_regions']) for o in owners),'unary_integer_planes':unary_plane_count,'empty_site_mask_implications':mask_links,'rigid_components':len(components),'rigid_component_coordinate_links':coordinate_links,'different_owner_rectangle_pairs':len(separations),'rectangle_direction_selectors':4*len(separations),'same_family_order_constraints':len(symmetry),'canonical_owner_component_equalities':sum(len(r['canonical_owner_component_constraints']) for r in count_choices),'within_component_lexicographic_order_constraints':sum(len(d['within_component_order']) for r in count_choices for d in r['distributions']),'model_sha256':digest(OUT/'model.pb'),'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
