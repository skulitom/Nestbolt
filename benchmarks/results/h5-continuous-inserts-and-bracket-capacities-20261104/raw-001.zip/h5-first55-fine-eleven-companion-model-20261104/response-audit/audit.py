"""Independently audit the sole closed first55 call, its absent assignment and all timings."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-first55-fine-eleven-companion-model-20261104';GEO=ROOT/'output/h5-first55-fine-grid-regions-20261104';MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
queue=[GEO/'plan.json',MODEL/'plan.json',BASE/'model-audit/plan.json',SEARCH/'opened.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts)
        assert digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
opened,result,process,budget=[load(SEARCH/n) for n in ['opened.json','result.json','process.json','budget.json']]
assert load(BASE/'model-audit/checks.json')['passed']
assert digest(MODEL/'model.pb')==digest(SEARCH/'model.pb')==opened['model_sha256']==load(BASE/'model-audit/checks.json')['model_sha256']
model=cp_model_pb2.CpModelProto();model.ParseFromString((SEARCH/'model.pb').read_bytes())
assert len(model.variables)==2813 and len(model.constraints)==12294 and not model.HasField('objective')
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes())
assert response.status==cp_model_pb2.INFEASIBLE and result['status']=='INFEASIBLE' and not response.solution
assert not list((SEARCH/'incumbents').glob('*.json')) and result['incumbents_recorded']==0
assert not (SEARCH/'assignment.json').exists() and not (SEARCH/'source-response').exists()
parameters=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
assert {f.name for f,v in parameters.ListFields()}=={'max_time_in_seconds','num_search_workers','random_seed','log_search_progress','log_to_stdout','ignore_subsolvers'}
assert parameters.max_time_in_seconds==opened['parameters']['max_time_in_seconds']==result['allocated_solve_seconds']
assert parameters.num_search_workers==4 and parameters.random_seed==0 and parameters.log_search_progress and not parameters.log_to_stdout and list(parameters.ignore_subsolvers)==['fj']
assert response.num_branches==result['returned_response_branches']==31379 and response.num_conflicts==result['returned_response_conflicts']==3985 and response.wall_time==result['solver_wall_seconds']
assert result['closed'] and result['solver_calls']==1 and not result['has_assignment'] and not result['source_valid66'] and result['source_checker_calls']==0 and not result['any_allocation_excluded']
assert process['closed'] and process['exit_code']==0 and not process['timeout']
assert result['algorithm_seconds_including_preparation']<60 and process['seconds_including_preparation']<90
assert result['algorithm_overrun_seconds']==0
assert result['returned_solve_overrun_seconds']==max(0.,result['returned_solve_seconds']-result['allocated_solve_seconds'])==0
assert opened['maximum_calls']==budget['maximum_calls']==1 and not opened['retry_permitted'] and not budget['retry_permitted']
charge=load(MODEL/'checks.json')['preparation_seconds_charged'];charges=load(MODEL/'preparation-charges.json')
assert charge==sum(charges.values())==opened['preparation_seconds_charged']==budget['preparation_seconds_charged']==result['preparation_seconds_charged']
short=load(ROOT/'output/h5-short11-integer-mode-regions-20261029/response-audit/checks.json')
assert charges['source_valid_short11_shared_seconds']==short['shared_seconds_including_preparation']
assert opened['source_validation_reserve_seconds']==budget['source_validation_reserve_seconds']==4
assert (SEARCH/'stderr.txt').read_text()==''
log=(SEARCH/'solver.log').read_text();assert 'Stopped after presolve.' not in log and 'status: INFEASIBLE' in log and 'Starting search' in log
lp_diagnostics = log[log.index('Lp debug'):log.index('Lp pool')]
with (OUT/'lp-diagnostics.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(lp_diagnostics)
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),GEO/'plan.json',MODEL/'plan.json',MODEL/'checks.json',MODEL/'preparation-charges.json',BASE/'model-audit/plan.json',BASE/'model-audit/checks.json']+[SEARCH/n for n in ['opened.json','budget.json','model.pb','parameters.pbtxt','response.pb','result.json','process.json','solver.log','stdout.txt','stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_input_bindings_verified':len(bindings),'closed_solver_calls':1,'solver_status':'INFEASIBLE','stopped_after_presolve':False,'branches':response.num_branches,'conflicts':response.num_conflicts,'assignments':0,'source_checker_calls':0,'preparation_seconds_charged':charge,'prior_short11_shared_seconds_charged':charges['source_valid_short11_shared_seconds'],'allocated_solve_seconds':result['allocated_solve_seconds'],'returned_solve_seconds':result['returned_solve_seconds'],'solve_slice_overrun_seconds':result['returned_solve_overrun_seconds'],'algorithm_seconds_including_preparation':result['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':process['seconds_including_preparation'],'overall_algorithm_shared_overruns_seconds':0,'infeasibility_proven':False,'restricted_grid_model_solver_reports_infeasible':True,'independent_unsat_certificate_available':False,'continuous_source_domain_excluded':False,'source_valid66':False,'any_allocation_excluded':False,'remaining_candidates':440,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
