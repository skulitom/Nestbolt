"""Construct two source inserts from integer hull extrema and validate four full partial layouts."""
from pathlib import Path
from fractions import Fraction as F
from math import ceil,floor
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];DOMAIN=ROOT/'output/h5-shared-two-insert-domain-20261104';GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-source-two-insert-block-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(DOMAIN/'audit/checks.json')['passed'] and load(GEO/'geometry-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');started=time.perf_counter();nodes=load(DOMAIN/'nodes.json');pair=next(p for p in load(DOMAIN/'retained-option-pairs.json') if p[0]==p[1]);node=nodes[pair[0]];family,mode_id,gid,ri=node['key'];assert family=='insert';mode=load(GEO/'family-modes.json')[family][mode_id];assert mode['mode']==mode_id and mode['normalized_geometry']==gid
region=next(r for r in load(GEO/'unary-templates.json')[gid]['regions'] if r['region']==ri);bounds=list(map(F,node['translation_bounds_mm']));stock=mode['integer_lower_left_bounds'];origin=[0,2100];slices=[]
for x in range(max(stock[0][0],ceil(bounds[0]*10)),min(stock[0][1],floor(bounds[2]*10))+1):
    lo=max(stock[1][0],ceil((bounds[1]-origin[1])*10));hi=min(stock[1][1],floor((bounds[3]-origin[1])*10));possible=True
    for p in region['planes']:
        a,b=p['coefficients'];right=p['upper']-a*x
        if b>0:hi=min(hi,right//b)
        elif b<0:lo=max(lo,ceil(F(right,b)))
        elif right<0:possible=False;break
    if possible and lo<=hi:slices.append([x,lo,hi])
assert slices
low=min(([x,lo] for x,lo,hi in slices),key=lambda p:(p[1],p[0]));high=max(([x,hi] for x,lo,hi in slices),key=lambda p:(p[1],-p[0]));offset=load(GEO/'mode-rectangles.json')[family][mode_id]['rectangles'][0]['outward_offsets_grid'];gap=high[1]+offset[1]-low[1]-offset[3];assert gap>=3
positions=sorted([low,high]);block=[]
for identity,xy in zip([15,16],positions):
    for p in region['planes']:assert sum(v*c for v,c in zip(xy,p['coefficients']))<=p['upper']
    block.append({'part_id':'insert','copy_index':identity,'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]/10+origin[k]+mode['translation_from_lower_left'][k] for k in [0,1]]}})
write(OUT/'source2.json',block);write(OUT/'selected.json',{'source_node_pair':pair,'source_key':node['key'],'identities':[['insert',15],['insert',16]],'lower_left_grid':positions,'world_origin_mm':origin,'grid_units_per_mm':10,'integer_x_slices':slices,'source_rectangle_offsets_grid':offset,'vertical_rectangle_gap_grid':gap})
inventory=load(GEO/'inventory.json');missing={('bracket',i) for i in [0,1,2,3,5,6,9]}|{('insert',i) for i in [17,18,19,20]};expected=[tuple(v) for v in inventory['full66_identities'] if tuple(v) not in missing];assert len(expected)==55
job=load(JOB);spec=load(FIRST/'plan.json');sites=load(SLOTS/'source-cog-sites.json');uses=load(DOMAIN/'compatible-uses.json');checks=[]
for empty in sorted({tuple(u['empty_sites']) for u in uses}):
    rows=load(FIRST/'fixed29.json')
    for site,identity in zip([i for i in range(15) if i not in empty],inventory['required_cog13_identities']):
        row=deepcopy(sites[site]);row['copy_index']=identity[1];rows.append(row)
    rows+=load(SHORT)+deepcopy(block);name='empty-'+'-'.join(map(str,empty));write(OUT/(name+'-source55.json'),rows)
    result=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected);write(OUT/(name+'-checks.json'),result)
    assert result['same_sheet_pairs']==1001 and result['stock_edges']==220 and result['cutouts']==65;checks.append({'empty_sites':empty,'source_file':name+'-source55.json','checks_file':name+'-checks.json','source_valid55':result['valid']})
elapsed=time.perf_counter()-started
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT,FIRST/'plan.json',FIRST/'fixed29.json',SLOTS/'source-cog-sites.json']+[DOMAIN/n for n in ['plan.json','audit/plan.json','audit/checks.json','nodes.json','retained-option-pairs.json','compatible-uses.json']]+[GEO/n for n in ['plan.json','geometry-audit/plan.json','geometry-audit/checks.json','family-modes.json','mode-rectangles.json','unary-templates.json','inventory.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Select the first necessary repeated source option, scan every integer X in its original projected interval, solve all local integer hull planes exactly for the allowed Y interval, and select its lowest and highest feasible points. Require the original outward model rectangles to meet the0.3mm separation rule. Reconstruct unchanged source contours for inserts15/16, combine with fixed29,13 occupied cogs and the validated short11, and independently check every source pair, stock edge and cutout in all four uses. No packing solver is called.','discovery_cap_seconds':60,'packing_solver_calls':0,'native_calls':0})
result={'passed':all(c['source_valid55'] for c in checks),'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'source_valid55_all_four_uses':all(c['source_valid55'] for c in checks),'compatible_uses':checks,'original_parts_per_use':55,'same_sheet_pairs_per_use':1001,'stock_edges_per_use':220,'cutouts_per_use':65,'remaining_originals':11,'shared_source_insert_copies':2,'packing_solver_calls':0,'original_source_audits':4,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
