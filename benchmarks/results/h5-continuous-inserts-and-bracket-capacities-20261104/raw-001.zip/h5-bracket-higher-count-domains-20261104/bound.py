"""Extend audited triple domains through the required bracket count using exact DBMs."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from math import lcm
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-small-bracket-triple-domains-20261104';COUNT=ROOT/'output/h5-first55-small-bracket-filtered-20261104';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';OUT=ROOT/'output/h5-bracket-higher-count-domains-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRIOR/'audit/checks.json')['passed'] and load(COUNT/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
nodes=load(PRIOR/'nodes.json');old_domains=load(PRIOR/'domains.json');rows=load(COUNT/'all-filtered-bounds.json');gap=F(149,1000);assert 2*gap**2<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2
domains=[]
for di,d in enumerate(old_domains):
    if not d['retained_triples']:continue
    keys={tuple(nodes[i]['key']) for i in d['nodes']};uses=[];target=3
    for row in rows:
        for gi,g in enumerate(row['groups']):
            if g['family']!='bracket':continue
            if {tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi}!=keys:continue
            counts=[r[gi] for r in row['remaining_distributions']];target=max(target,*counts);uses.append({'empty_sites':row['empty_sites'],'group':gi,'counts':counts})
    if target>3:domains.append({'domain':di,'nodes':d['nodes'],'uses':uses,'target':target,'stages':[]})
visited=0;timed_out=False
def domain(whole):
    bs=[list(map(F,nodes[i]['translation_bounds_mm'])) for i in whole];ps=[(o,list(map(F,r))) for o,i in enumerate(whole) for r in nodes[i]['contained_rectangles_mm']]
    scale=lcm(gap.denominator,*(v.denominator for b in bs for v in b),*(v.denominator for o,r in ps for v in r));bs=[[int(v*scale) for v in b] for b in bs];ps=[(o,[int(v*scale) for v in r]) for o,r in ps];q=int(gap*scale);size=len(whole)+1
    matrices=[]
    for axis in [0,1]:
        lo=[b[axis] for b in bs]+[0];hi=[b[axis+2] for b in bs]+[0]
        matrices.append([[0 if i==j else hi[i]-lo[j] for j in range(size)] for i in range(size)])
    clauses=[]
    for k,(a,A) in enumerate(ps):
        for b,B in ps[k+1:]:
            if a!=b:clauses.append([(0,a,b,B[0]-A[2]-q),(0,b,a,A[0]-B[2]-q),(1,a,b,B[1]-A[3]-q),(1,b,a,A[1]-B[3]-q)])
    return matrices,clauses
def search(matrices,clauses):
    global visited,timed_out
    visited+=1
    if time.perf_counter()-started>=58:timed_out=True;return 'unknown',None
    chosen=None
    for ci,clause in enumerate(clauses):
        if any(matrices[axis][a][b]<=c for axis,a,b,c in clause):continue
        possible=[di for di,(axis,a,b,c) in enumerate(clause) if matrices[axis][b][a]+c>=0]
        if not possible:return 'excluded',{'contradiction_clause':ci}
        if chosen is None or len(possible)<len(chosen[1]):chosen=(ci,possible)
    if chosen is None:return 'relaxed',None
    ci,possible=chosen;children=[]
    for di in possible:
        axis,a,b,c=clauses[ci][di];old=matrices[axis];size=len(old)
        new=[[min(old[i][j],old[i][a]+c+old[b][j]) for j in range(size)] for i in range(size)];assert all(new[i][i]==0 for i in range(size))
        updated=matrices[:];updated[axis]=new;status,proof=search(updated,clauses)
        if status!='excluded':return status,None
        children.append({'direction':di,'proof':proof})
    return 'excluded',{'split_clause':ci,'children':children}
certs=[]
for d in domains:
    current={tuple(t) for t in old_domains[d['domain']]['retained_triples']};rank={n:i for i,n in enumerate(d['nodes'])}
    for k in range(4,d['target']+1):
        # Every feasible k-multiset must have every (k-1)-submultiset retained.
        initial=sorted({t+(n,) for t in current for n in d['nodes'][rank[t[-1]]:] if all(sub in current for sub in combinations(t+(n,),k-1))})
        retained=[];excluded=[];processed=0
        for whole in initial:
            if time.perf_counter()-started>=58:timed_out=True;break
            status,proof=search(*domain(whole))
            if status=='excluded':excluded.append(list(whole));certs.append({'domain':d['domain'],'size':k,'nodes':list(whole),'proof':proof})
            else:retained.append(list(whole))
            processed+=1
            if timed_out:break
        retained.extend(list(t) for t in initial[processed:]);d['stages'].append({'size':k,'initial':[list(t) for t in initial],'excluded':excluded,'retained':retained,'scan_complete':not timed_out and processed==len(initial)})
        current={tuple(t) for t in retained}
        if not current:d['maximum_brackets_proven_pending_audit']=k-1;break
        if timed_out:break
    if timed_out:break
elapsed=time.perf_counter()-started
inputs=[Path(__file__),FIRST/'plan.json']+[PRIOR/n for n in ['plan.json','checks.json','nodes.json','domains.json','audit/plan.json','audit/checks.json','audit/retained-triples.json']]+[COUNT/n for n in ['plan.json','all-filtered-bounds.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each still-used original small bracket domain, extend the independently audited triple survivors to each required larger multiplicity. Enumerate every canonical multiset whose previous-size subsets survive. Apply exact necessary source interval/contained rectangle disjunction trees. Never discard unprocessed or relaxed survivors. A complete empty level proves capacity below that level; rational full-closure audit is required.','gap_mm':str(gap),'discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'packing_solver_calls':0,'native_calls':0})
write(OUT/'domains.json',domains);write(OUT/'exclusion-certificates.json',certs)
result={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'scan_complete':not timed_out,'domains':len(domains),'stages':sum(len(d['stages']) for d in domains),'exact_search_nodes':visited,'exclusion_trees_pending_audit':len(certs),'capacity_bounds_pending_audit':[{k:d[k] for k in ['domain','maximum_brackets_proven_pending_audit']} for d in domains if 'maximum_brackets_proven_pending_audit' in d],'independent_audit_required':True,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
