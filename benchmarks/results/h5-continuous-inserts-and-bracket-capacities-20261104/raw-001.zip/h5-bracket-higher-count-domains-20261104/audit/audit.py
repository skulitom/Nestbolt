"""Exhaustive multiset enumeration independently verifies higher bracket capacities."""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-small-bracket-triple-domains-20261104';COUNT=ROOT/'output/h5-first55-small-bracket-filtered-20261104';BASE=ROOT/'output/h5-bracket-higher-count-domains-20261104';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name;bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(PRIOR/'audit/checks.json')['passed'] and load(COUNT/'audit/checks.json')['passed']
assert load(BASE/'exclusion-certificates.json')==[]
nodes=load(PRIOR/'nodes.json');old=load(PRIOR/'domains.json');domains=load(BASE/'domains.json');rows=load(COUNT/'all-filtered-bounds.json')
expected=[]
for di,d in enumerate(old):
    if not d['retained_triples']:continue
    keys={tuple(nodes[i]['key']) for i in d['nodes']};uses=[];target=3
    for row in rows:
        for gi,g in enumerate(row['groups']):
            if g['family']=='bracket' and keys=={tuple(a[:4]) for a in row['region_component_assignments'] if a[4]==gi}:
                counts=[r[gi] for r in row['remaining_distributions']];uses.append({'empty_sites':row['empty_sites'],'group':gi,'counts':counts});target=max(target,*counts)
    if target>3:expected.append({'domain':di,'nodes':d['nodes'],'uses':uses,'target':target})
assert len(domains)==len(expected);enumerated=0;proved=[]
for d,e in zip(domains,expected):
    assert {k:d[k] for k in e}==e
    triples={tuple(t) for t in old[d['domain']]['retained_triples']};capacity=None
    for k,stage in enumerate(d['stages'],4):
        assert stage['size']==k and stage['scan_complete'] and not stage['excluded']
        possible=[]
        # Audit every multiset directly, without producer prefix extension or DBM code.
        for whole in combinations_with_replacement(d['nodes'],k):
            enumerated+=1
            if all(t in triples for t in combinations(whole,3)):possible.append(list(whole))
        possible.sort();assert stage['initial']==stage['retained']==possible
        if not possible:capacity=k-1;assert stage is d['stages'][-1];break
    assert capacity==d['maximum_brackets_proven_pending_audit']
    proved.append({'domain':d['domain'],'nodes':d['nodes'],'uses':d['uses'],'maximum_brackets':capacity})
write(OUT/'capacity-bounds.json',proved);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','domains.json','exclusion-certificates.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'independent_method':'Enumerate every canonical multiset at each recorded multiplicity directly. A possible placement requires every triple subset to be in the independently audited necessary triple survivors. Verify exact equality of all remaining sets. No new difference-constraint tree was used to exclude any higher multiset.'})
result={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'domains_verified':len(domains),'all_multisets_directly_enumerated':enumerated,'capacity_bounds_verified':[{k:d[k] for k in ['domain','maximum_brackets']} for d in proved],'new_difference_tree_exclusions':0,'any_placement_proven':False,'count_distribution_application_pending':True,'packing_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
