"""Prepare a distinct finer-grid construction; preserve every earlier closed call."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OLD='h5-first55-eleven-companion-model-20261104'
NEW='h5-first55-fine-eleven-companion-model-20261104'
COARSE='h5-first55-local-grid-regions-20261029'
FINE='h5-first55-fine-grid-regions-20261104'
def write(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def replace(s,a,b,count=1):
    assert s.count(a)==count,(a,s.count(a));return s.replace(a,b)

s=(ROOT/'output/build_h5_eleven_companion_model_20261104.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=replace(s,f"BASE=ROOT/'output/{COARSE}';PRE=BASE",f"COARSE=ROOT/'output/{COARSE}';BASE=ROOT/'output/{FINE}';PRE=BASE")
s=replace(s,"AXIS=BASE/'component-halfspace-bound'","AXIS=COARSE/'component-halfspace-bound'")
s=replace(s,"cp_model.INT_MIN,-3,selector","cp_model.INT_MIN,-23,selector")
s=replace(s,"'rectangle_gap_grid':3","'rectangle_gap_grid':23")
s=replace(s,"'position_units_per_mm':10","'position_units_per_mm':100")
s=replace(s,"'local_grid_preparation_seconds':load(BASE/'checks.json')['seconds']","'local_grid_preparation_seconds':load(COARSE/'checks.json')['seconds'],'fine_grid_preparation_seconds':load(BASE/'checks.json')['seconds']")
s=replace(s,"inputs=[Path(__file__)]","inputs=[Path(__file__),COARSE/'checks.json']")
s=replace(s,"'method':'Construct every", "'method':'Use new0.01mm grid geometry, scale100000 normals and0.23mm outward-rectangle spacing. Charge both original coarse-grid prerequisite preparation and the new fine-grid preparation. Construct every")
write('build_h5_fine_eleven_model_20261104.py',s)

s=(ROOT/'output/audit_h5_eleven_companion_model_20261104.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=replace(s,f"BASE=ROOT/'output/{COARSE}';PRE=BASE",f"COARSE=ROOT/'output/{COARSE}';BASE=ROOT/'output/{FINE}';PRE=BASE")
s=s.replace("BASE/'model/preparation-charges.json'","COARSE/'model/preparation-charges.json'").replace("BASE/'component-halfspace-bound/checks.json'","COARSE/'component-halfspace-bound/checks.json'")
s=replace(s,"mapping['position_units_per_mm']==10", "mapping['position_units_per_mm']==100")
s=replace(s,"mapping['rectangle_gap_grid']==3", "mapping['rectangle_gap_grid']==23")
s=replace(s,"MIN,-3,vi", "MIN,-23,vi")
s=replace(s,"assert load(MODEL/'preparation-charges.json')==expected_charges", "expected_charges['fine_grid_preparation_seconds']=load(BASE/'checks.json')['seconds']\nassert load(BASE/'geometry-audit/checks.json')['maximum_outward_padding_mm']<0.01<0.1\nassert load(MODEL/'preparation-charges.json')==expected_charges")
write('audit_h5_fine_eleven_model_20261104.py',s)

s=(ROOT/'output/check_h5_eleven_companion_candidate_20261104.py').read_text(encoding='utf-8').replace(OLD,NEW).replace(COARSE,FINE)
write('check_h5_fine_eleven_candidate_20261104.py',s)
s=(ROOT/'output/run_h5_eleven_companion_model_20261104.py').read_text(encoding='utf-8').replace(OLD,NEW).replace(COARSE,FINE).replace('check_h5_eleven_companion_candidate_20261104.py','check_h5_fine_eleven_candidate_20261104.py')
write('run_h5_fine_eleven_model_20261104.py',s)
print('Prepared fine-grid eleven-part construction, field audit, full66 checker and single-call runner.')
