from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_block_pruned_response_20261104.py').read_text(encoding='utf-8')
for a,b in [('h5-first55-block-pruned-model-v2-20261104','h5-first55-eleven-companion-model-20261104'),('len(model.variables)==6498 and len(model.constraints)==32697','len(model.variables)==2813 and len(model.constraints)==12294'),("response.status==cp_model_pb2.UNKNOWN and result['status']=='UNKNOWN'","response.status==cp_model_pb2.INFEASIBLE and result['status']=='INFEASIBLE'"),("result['returned_response_branches']==53720","result['returned_response_branches']==31870"),("result['returned_response_conflicts']==4508","result['returned_response_conflicts']==4117"),("max(0.,result['returned_solve_seconds']-result['allocated_solve_seconds'])>0","max(0.,result['returned_solve_seconds']-result['allocated_solve_seconds'])==0"),("'status: UNKNOWN'","'status: INFEASIBLE'"),("'solver_status':'UNKNOWN'","'solver_status':'INFEASIBLE'")]:assert a in s,a;s=s.replace(a,b)
s=s.replace("'infeasibility_proven':False", "'infeasibility_proven':False,'restricted_grid_model_solver_reports_infeasible':True,'independent_unsat_certificate_available':False,'continuous_source_domain_excluded':False")
p=ROOT/'output/audit_h5_eleven_response_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
