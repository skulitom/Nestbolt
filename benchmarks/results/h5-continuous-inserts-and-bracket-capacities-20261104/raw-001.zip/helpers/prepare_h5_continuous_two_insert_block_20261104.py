from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/construct_h5_two_insert_block_20261104.py').read_text(encoding='utf-8').replace('h5-source-two-insert-block-20261104','h5-source-two-insert-continuous-block-20261104')
a=s.index("region=next(");b=s.index("inventory=load(",a)
s=s[:a]+'''region=next(r for r in load(GEO/'unary-templates.json')[gid]['regions'] if r['region']==ri);hull=[list(map(F,p)) for p in region['hull_vertices']];origin=[0,0]
x=F(ceil(min(p[0] for p in hull)*100),100);intersections=[]
for p,q in zip(hull,hull[1:]+hull[:1]):
    if p[0]==q[0]:
        if x==p[0]:intersections.extend([p[1],q[1]])
    elif min(p[0],q[0])<=x<=max(p[0],q[0]):intersections.append(p[1]+(x-p[0])*(q[1]-p[1])/(q[0]-p[0]))
assert len(intersections)>=2
lo,hi=min(intersections),max(intersections);positions=[[x,F(ceil((lo+F(1,1000))*1000),1000)],[x,F(floor((hi-F(1,1000))*1000),1000)]]
rectangle=list(map(F,load(GEO/'mode-rectangles.json')[family][mode_id]['rectangles'][0]['exact_affine_bounds_mm']));gap=positions[1][1]+rectangle[1]-positions[0][1]-rectangle[3];assert gap>=F(226,1000)
block=[]
for identity,xy in zip([15,16],positions):
    signs=[]
    for p,q in zip(hull,hull[1:]+hull[:1]):signs.append((q[0]-p[0])*(xy[1]-p[1])-(q[1]-p[1])*(xy[0]-p[0]))
    assert all(v>=0 for v in signs) or all(v<=0 for v in signs)
    block.append({'part_id':'insert','copy_index':identity,'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[float(xy[k])+mode['translation_from_lower_left'][k] for k in [0,1]]}})
write(OUT/'source2.json',block);write(OUT/'selected.json',{'source_node_pair':pair,'source_key':node['key'],'identities':[['insert',15],['insert',16]],'lower_left_mm':[[str(v) for v in p] for p in positions],'source_hull_vertices':region['hull_vertices'],'vertical_slice_bounds_mm':[str(lo),str(hi)],'source_rectangle_bounds_mm':[str(v) for v in rectangle],'vertical_rectangle_gap_mm':str(gap),'x_quantum_mm':'1/100','y_quantum_mm':'1/1000','vertical_endpoint_inset_mm':'1/1000'})
''' +s[b:]
s=s.replace('Select the first necessary repeated source option, scan every integer X in its original projected interval, solve all local integer hull planes exactly for the allowed Y interval, and select its lowest and highest feasible points. Require the original outward model rectangles to meet the0.3mm separation rule.', 'Select the first necessary repeated source option. At the first0.01mm X coordinate inside its original convex source hull, compute the exact rational vertical slice. Inset its two Y endpoints by0.001mm, rounding further inward to0.001mm coordinates. Verify both points lie inside every original hull edge and the original rotated rectangle gap is at least0.226mm. This direct source construction does not use rounded grid planes.')
p=ROOT/'output/construct_h5_continuous_two_insert_block_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
