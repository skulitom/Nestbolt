from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_eleven_response_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first55-eleven-companion-model-20261104','h5-first55-fine-eleven-companion-model-20261104').replace('h5-first55-local-grid-regions-20261029','h5-first55-fine-grid-regions-20261104').replace('==31870','==31379').replace('==4117','==3985')
p=ROOT/'output/audit_h5_fine_eleven_response_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
