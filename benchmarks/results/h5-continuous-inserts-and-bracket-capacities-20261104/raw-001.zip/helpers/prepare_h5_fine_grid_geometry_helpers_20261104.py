from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/prepare_h5_local_grid_regions_20261029.py').read_text(encoding='utf-8').replace('h5-first55-local-grid-regions-20261029','h5-first55-fine-grid-regions-20261104').replace('grid=10;scale=10000','grid=100;scale=100000').replace('2**31','2**53').replace('0.1mm','0.01mm').replace('scale10000','scale100000').replace('require3grid units(0.3mm)','require23grid units(0.23mm)').replace("'rectangle_gap_grid':3","'rectangle_gap_grid':23")
p=ROOT/'output/prepare_h5_fine_grid_regions_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_local_grid_regions_20261029.py').read_text(encoding='utf-8').replace('h5-first55-local-grid-regions-20261029','h5-first55-fine-grid-regions-20261104')
s=s.replace("spec['grid_units_per_mm']==10 and spec['normal_scale']==10000 and spec['rectangle_gap_grid']==3", "spec['grid_units_per_mm']==100 and spec['normal_scale']==100000 and spec['rectangle_gap_grid']==23")
s=s.replace("origin=list(map(F,spec['world_origin_mm']))", "grid=spec['grid_units_per_mm'];scale=spec['normal_scale'];origin=list(map(F,spec['world_origin_mm']))")
for a,b in [('(a-origin[axis])*10','(a-origin[axis])*grid'),('(b-origin[axis])*10','(b-origin[axis])*grid'),('limit[axis]*10','limit[axis]*grid'),('F(lo,10)','F(lo,grid)'),('F(hi,10)','F(hi,grid)'),('F(raw[i],10000)','F(raw[i],scale)'),("(rhs-error-F('1e-7'))*100000", "(rhs-error-F('1e-7'))*scale*grid"),('F(div*upper,100000)','F(div*upper,scale*grid)'),('int(v*10)','int(v*grid)'),('2**31','2**53'),('exact*10','exact*grid'),('F(tick,10)','F(tick,grid)'),("F('0.1')","F('0.01')"),("F(spec['rectangle_gap_grid'],10)","F(spec['rectangle_gap_grid'],grid)")]:assert a in s,a;s=s.replace(a,b)
p=ROOT/'output/audit_h5_fine_grid_regions_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
