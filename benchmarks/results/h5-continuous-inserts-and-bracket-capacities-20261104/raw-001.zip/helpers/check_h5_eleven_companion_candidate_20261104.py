"""Reconstruct all66 original contours from the joint empty-site and orthogonal placement assignment."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from copy import deepcopy
import json, sys, time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-eleven-companion-model-20261104';GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';SEARCH=BASE/'search';OUT=SEARCH/'source-response';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=float(sys.argv[1]);OUT.mkdir();mapping=load(BASE/'model/mapping.json');values=load(SEARCH/'assignment.json');inventory=load(GEO/'inventory.json');sites=load(SLOTS/'source-cog-sites.json');empty=[i for i,v in enumerate(mapping['empty_site_selectors']) if values[v]];assert len(empty)==2
occupied=[i for i in range(15) if i not in empty];required=inventory['required_cog13_identities'];assert len(occupied)==len(required)==13
rows=load(FIRST/'fixed29.json');site_choices=[]
for site,identity in zip(occupied,required):
    row=deepcopy(sites[site]);assert identity[0]=='cog';row['copy_index']=identity[1];rows.append(row);site_choices.append({'site':site,'identity':identity,'transform':row['transform']})
fixed_two=ROOT/'output/h5-first55-eleven-companion-inputs-20261104/fixed-source2.json';rows+=load(SHORT)+load(fixed_two);chosen=[]
for owner in mapping['owners']:
    selected=[m for m in owner['modes'] if values[m['selector']]];assert len(selected)==1;mode=selected[0]
    selected_regions=[r for r in owner['unary_regions'] if values[r['selector']]];assert len(selected_regions)==1;r=selected_regions[0];assert r['geometry']==mode['normalized_geometry'] and set(r['required_empty_sites'])<=set(empty)
    xy=[values[v]/mapping['position_units_per_mm']+mapping['world_origin_mm'][k] for k,v in enumerate(owner['positions'])]
    rows.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]+mode['translation_from_lower_left'][k] for k in [0,1]]}})
    chosen.append({'owner':owner['owner'],'identity':owner['identity'],'mode':mode['mode'],'geometry':mode['normalized_geometry'],'lower_left_mm':xy,'unary_region':r['region'],'required_empty_sites':r['required_empty_sites']})
for pair in mapping['pairs']:
    selected=[r for r in pair['regions'] if values[r['selector']]];assert len(selected)==1 and selected[0]['geometries']==[chosen[i]['geometry'] for i in pair['owners']]
job,spec=load(JOB),load(FIRST/'plan.json');expected=list(map(tuple,inventory['full66_identities']));assert len(rows)==66
check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
assert check['cutouts']==90 and check['hole_vertices']==10026 and check['same_sheet_pairs']==1540 and check['stock_edges']==264
write(OUT/'candidate-source66.json',rows);write(OUT/'selected-modes.json',chosen);write(OUT/'selected-cog-sites.json',{'empty_sites':empty,'occupied_sites':site_choices});write(OUT/'original-source-checks.json',check)
inputs=[Path(__file__),fixed_two,ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT,FIRST/'plan.json',FIRST/'fixed29.json',SLOTS/'source-cog-sites.json',GEO/'inventory.json',BASE/'model/mapping.json',SEARCH/'assignment.json',SEARCH/'assignment-check.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'source_valid66':check['valid'],'originals':66,'first_originals':55,'short_originals':11,'empty_cog_sites':empty,'same_sheet_pairs':1540,'stock_edges':264,'cutouts':90,'hole_vertices':10026,'source_checker_calls':1,'algorithm_seconds_including_preparation':time.perf_counter()-started,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
