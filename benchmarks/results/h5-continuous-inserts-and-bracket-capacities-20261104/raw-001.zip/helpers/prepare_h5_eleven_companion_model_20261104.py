from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def write(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/build_h5_block_pruned_model_v2_20261104.py').read_text(encoding='utf-8').replace('h5-first55-block-pruned-model-v2-20261104','h5-first55-eleven-companion-model-20261104').replace('h5-first55-block-count-model-inputs-20261104','h5-first55-eleven-companion-inputs-20261104').replace('all14-filtered-bounds.json','all4-companion-bounds.json')
s=s.replace("THREE_BOUND=ROOT/'output/h5-shared-three-bracket-difference-bound-20261104'", "THREE_BOUND=ROOT/'output/h5-shared-three-bracket-difference-bound-20261104';TWO_DOMAIN=ROOT/'output/h5-shared-two-insert-domain-20261104';TWO_SOURCE=ROOT/'output/h5-source-two-insert-continuous-block-20261104';FACTOR=ROOT/'output/h5-first55-component-factorization-20261029'")
s=s.replace("instances=load(BASE/'instances.json')", "instances=load(COUNT/'instances.json')").replace("component_inventory=load(RID/'components.json');component_pairs=load(RID/'component-pairs.json')", "component_inventory=load(COUNT/'components.json');component_pairs=load(COUNT/'component-pairs.json')")
s=s.replace('assert len(forbidden)==91','assert len(forbidden)==101')
s=s.replace('unary_plane_count=mask_links=mask_pruned_unary_count=0',"eligible={(a[0],a[2],a[3]) for row in load(COUNT/'all4-companion-bounds.json') for a in row['region_component_assignments']}\nunary_plane_count=mask_links=mask_pruned_unary_count=fixed_block_pruned_count=0")
line="            if not any(set(region['required_empty_sites'])<=set(sites) for sites in allowed):mask_pruned_unary_count+=1;continue"
assert s.count(line)==1;s=s.replace(line,line+"\n            if (owner['identity'][0],gid,region['region']) not in eligible:fixed_block_pruned_count+=1;continue")
s=s.replace("'cp_model_build_seconds':elapsed", "'two_insert_domain_seconds':load(TWO_DOMAIN/'checks.json')['seconds'],'continuous_two_insert_construction_seconds':load(TWO_SOURCE/'checks.json')['seconds'],'component_factorization_seconds':load(FACTOR/'checks.json')['seconds'],'cp_model_build_seconds':elapsed")
s=s.replace("[ORIGINAL_COUNT,FINAL_COUNT,PAIR_BOUND,FOUR_BOUND,THREE_BOUND]", "[ORIGINAL_COUNT,FINAL_COUNT,PAIR_BOUND,FOUR_BOUND,THREE_BOUND,TWO_DOMAIN,TWO_SOURCE,FACTOR]")
s=s.replace("COUNT/'all4-companion-bounds.json',", "COUNT/'all4-companion-bounds.json',COUNT/'instances.json',COUNT/'components.json',COUNT/'component-pairs.json',COUNT/'fixed-source2.json',")
a=s.index("'method':");b=s.index(",'algorithm_seconds':",a)
s=s[:a]+"'method':'Construct every one of the five remaining independent eleven-part companions across four site choices, with seven source brackets and four source inserts. The two other source inserts have fixed validated continuous poses and are separated from all companions by the audited source-support factorization. Use complete source modes, only companion unary regions, all rigid rectangle links, all146 different-owner rectangle pairs and conditional component counts. Canonicalize interchangeable copies within their components. No objective or hints. Independently audit every model field before one60/90-second call; all previous calls remain closed.'"+s[b:]
s=s.replace("'original_moving_parts':13,'source_mode_selectors':80", "'original_moving_parts':len(owners),'source_mode_selectors':sum(len(o['modes']) for o in owners)")
s=s.replace("'unary_site_mask_pruned_selectors':mask_pruned_unary_count", "'unary_site_mask_pruned_selectors':mask_pruned_unary_count,'fixed_block_pruned_unary_selectors':fixed_block_pruned_count")
write('build_h5_eleven_companion_model_20261104.py',s)
s=(ROOT/'output/check_h5_block_pruned_candidate_v2_20261104.py').read_text(encoding='utf-8').replace('h5-first55-block-pruned-model-v2-20261104','h5-first55-eleven-companion-model-20261104')
s=s.replace("rows+=load(SHORT);chosen=[]", "fixed_two=ROOT/'output/h5-first55-eleven-companion-inputs-20261104/fixed-source2.json';rows+=load(SHORT)+load(fixed_two);chosen=[]")
s=s.replace('inputs=[Path(__file__),','inputs=[Path(__file__),fixed_two,');write('check_h5_eleven_companion_candidate_20261104.py',s)
s=(ROOT/'output/run_h5_block_pruned_model_v2_20261104.py').read_text(encoding='utf-8').replace('h5-first55-block-pruned-model-v2-20261104','h5-first55-eleven-companion-model-20261104').replace('check_h5_block_pruned_candidate_v2_20261104.py','check_h5_eleven_companion_candidate_20261104.py');write('run_h5_eleven_companion_model_20261104.py',s)
print('Prepared complete eleven-part companion model and full66 source checker.')
