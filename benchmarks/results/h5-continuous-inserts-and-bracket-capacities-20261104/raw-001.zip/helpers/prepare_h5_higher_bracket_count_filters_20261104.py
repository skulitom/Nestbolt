from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def write(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def common(s):
    s=s.replace('h5-first55-small-bracket-filtered-20261104','h5-first55-higher-bracket-filtered-20261104')
    s=s.replace('h5-first55-direct-smaller-block-filtered-20261104','h5-first55-small-bracket-filtered-20261104')
    s=s.replace("BOUND=ROOT/'output/h5-small-bracket-triple-domains-20261104'","TRIPLE=ROOT/'output/h5-small-bracket-triple-domains-20261104';BOUND=ROOT/'output/h5-bracket-higher-count-domains-20261104'")
    s=s.replace("BOUND/'nodes.json'","TRIPLE/'nodes.json'").replace('audit/maximum-two-bracket-domains.json','audit/capacity-bounds.json')
    s=s.replace("inputs=[Path(__file__)]", "inputs=[Path(__file__),TRIPLE/'nodes.json']")
    s=s.replace("'checks.json','nodes.json','audit/plan.json'", "'checks.json','audit/plan.json'")
    return s
s=common((ROOT/'output/filter_h5_small_bracket_counts_20261104.py').read_text(encoding='utf-8'))
s=s.replace("out=[];removed=[];empty=[]", "caps={d['domain']:d['maximum_brackets'] for d in proved}\nout=[];removed=[];empty=[]")
s=s.replace("if keys and keys<=source:causes.append({'group':gi,'domain':di,'count':counts[gi],'capacity':2})", "if keys and keys<=source and counts[gi]>caps[di]:causes.append({'group':gi,'domain':di,'count':counts[gi],'capacity':caps[di]})")
s=s.replace('a required bracket count is at least3 and every original mode/region option of that component is contained in an independently proved maximum-two-bracket domain','a required bracket count exceeds the independently audited source domain capacity and every original mode/region option of that component is covered')
write('filter_h5_higher_bracket_counts_20261104.py',s)
s=common((ROOT/'output/audit_h5_small_bracket_counts_20261104.py').read_text(encoding='utf-8'))
s=s.replace("original=load(PRIOR/", "caps={d['domain']:d['maximum_brackets'] for d in proved}\noriginal=load(PRIOR/")
s=s.replace("counts[gi]==cert['count']>=3 and cert['capacity']==2", "counts[gi]==cert['count']>cert['capacity']==caps[cert['domain']]")
s=s.replace("if keys and not keys-domain:applicable.append({'group':gi,'domain':di,'count':counts[gi],'capacity':2})", "if keys and not keys-domain and counts[gi]>caps[di]:applicable.append({'group':gi,'domain':di,'count':counts[gi],'capacity':caps[di]})")
write('audit_h5_higher_bracket_counts_20261104.py',s)
