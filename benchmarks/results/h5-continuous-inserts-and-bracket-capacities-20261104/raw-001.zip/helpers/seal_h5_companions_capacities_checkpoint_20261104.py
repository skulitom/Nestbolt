"""Seal continuous inserts, closed companion calls and exact bracket capacities."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-continuous-inserts-and-bracket-capacities-20261104';OUT=ROOT/'benchmarks/results'/NAME;PARENT=ROOT/'benchmarks/results/h5-continuous-small-block-exclusions-20261104'
FOLDERS=['h5-shared-two-insert-domain-20261104','h5-source-two-insert-block-20261104','h5-source-two-insert-continuous-block-20261104','h5-first55-eleven-companion-inputs-20261104','h5-first55-eleven-companion-model-20261104','h5-first55-fine-grid-regions-20261104','h5-first55-fine-eleven-companion-model-20261104','h5-small-bracket-triple-domains-20261104','h5-first55-small-bracket-filtered-20261104','h5-bracket-higher-count-domains-20261104','h5-first55-higher-bracket-filtered-20261104']
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
assert load(PARENT/'archive-checks.json')['passed']
final=load(ROOT/'output'/FOLDERS[-1]/'audit/checks.json');assert final['passed'] and final['remaining_site_choices']==9 and final['remaining_count_distributions']==13
for name in ['h5-first55-eleven-companion-model-20261104','h5-first55-fine-eleven-companion-model-20261104']:
    r=load(ROOT/'output'/name/'response-audit/checks.json');assert r['passed'] and r['solver_status']=='INFEASIBLE' and r['closed_solver_calls']==1 and r['assignments']==0 and not r['continuous_source_domain_excluded']
for name in ['h5-small-bracket-triple-domains-20261104','h5-bracket-higher-count-domains-20261104']:
    assert load(ROOT/'output'/name/'audit/checks.json')['passed']
parent_manifest=load(PARENT/'raw-manifest.json');parent_hash=digest(PARENT/'raw-manifest.json');parent_by_hash={(r['sha256'],r['bytes']):r for r in parent_manifest['files']}
OUT.mkdir();members={};external={};queue=[];seen=set();bindings={}
def add(name,p):
    assert p.is_file() and p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts)
    h=digest(p);size=p.stat().st_size;old=parent_by_hash.get((h,size))
    if old:external[name]={'manifest':(PARENT/'raw-manifest.json').relative_to(ROOT).as_posix(),'manifest_sha256':parent_hash,'archive':old['archive'],'member':old['path'],'bytes':size,'sha256':h}
    else:members[name]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for name in FOLDERS:
    folder=ROOT/'output'/name
    for p in folder.rglob('*'):
        if p.is_file():add(name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5*two_insert*20261104.py','*h5*eleven*20261104.py','*h5*fine_grid*20261104.py','*h5*small_bracket*20261104.py','*h5*higher*bracket*20261104.py','*h5*bracket*higher*20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]:add('helpers/'+name,ROOT/'output'/name)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for name,h in load(p).get('inputs',{}).items():
            q=ROOT/name;assert digest(q)==h,name;bindings[name]=h;add('source-inputs/'+name,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'external-evidence.json',external);write(OUT/'source-bindings.json',bindings)
copies={
'two-insert-domain-audit.json':'h5-shared-two-insert-domain-20261104/audit/checks.json',
'continuous-source55.json':'h5-source-two-insert-continuous-block-20261104/checks.json',
'companion-input-audit.json':'h5-first55-eleven-companion-inputs-20261104/audit/checks.json',
'coarse-model-audit.json':'h5-first55-eleven-companion-model-20261104/model-audit/checks.json',
'coarse-response-audit.json':'h5-first55-eleven-companion-model-20261104/response-audit/checks.json',
'fine-geometry-audit.json':'h5-first55-fine-grid-regions-20261104/geometry-audit/checks.json',
'fine-model-audit.json':'h5-first55-fine-eleven-companion-model-20261104/model-audit/checks.json',
'fine-response-audit.json':'h5-first55-fine-eleven-companion-model-20261104/response-audit/checks.json',
'triple-capacity-audit.json':'h5-small-bracket-triple-domains-20261104/audit/checks.json',
'higher-capacity-audit.json':'h5-bracket-higher-count-domains-20261104/audit/checks.json',
'triple-filter-audit.json':'h5-first55-small-bracket-filtered-20261104/audit/checks.json',
'final-filter-audit.json':'h5-first55-higher-bracket-filtered-20261104/audit/checks.json',
'all9-filtered-bounds.json':'h5-first55-higher-bracket-filtered-20261104/all-filtered-bounds.json'}
for name,path in copies.items():shutil.copyfile(ROOT/'output'/path,OUT/name)
write(OUT/'next-step.json',{'method':'Extend exact original-source bracket pair/triple capacities to the larger remaining components before considering a distinct construction model. The shared continuous two-insert placement remains compatible with site pairs12/14 and13/14;9/13 and11/14 were independently excluded by bracket capacities.','authoritative_count_table':'output/h5-first55-higher-bracket-filtered-20261104/all-filtered-bounds.json','remaining_site_choices':9,'remaining_count_distributions':13,'remaining_allocation_candidates':440,'closed_calls_must_not_be_repeated':True,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'partial_source55_variants':4,'closed_solver_calls':2,'solver_statuses':['INFEASIBLE','INFEASIBLE'],'assignments':0,'solve_slice_overruns_seconds':0,'continuous_exclusions_from_solver_status':False,'original_count_distributions':24,'remaining_count_distributions':13,'original_site_choices':14,'remaining_site_choices':9,'remaining_allocation_candidates':440,'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Continuous inserts and exact bracket capacities — 2026-11-04

Independent original-source proofs reduce the restricted first-sheet construction
from **14 site choices / 24 count distributions to 9 choices / 13 distributions**.
The 440 whole-job allocations and H5 gate remain open. No full 66-part placement
or native validation was produced.

## A valid continuous two-insert block

The [domain audit]({NAME}/two-insert-domain-audit.json) reconstructs all 14 source
options shared by five distributions over four choices. Of 105 option pairs,
98 fail exact necessary directional bounds and seven remain. An initial 0.1 mm
grid construction failed before any solver call: conservative rounding at a
sharp region tip removes a valid continuous interval. Its failure is preserved.

Direct rational hull slicing places the two inserts at lower-left coordinates
(6.53,2308.128) and (6.53,2490.319) mm. [Original contour checks]({NAME}/continuous-source55.json)
validate four partial layouts of **55 parts total across both sheets**, each
with 1,001 same-sheet pair checks, 220 stock-edge checks and 65 cutouts. These
contain 44 first-sheet parts and the already validated short-sheet 11; they are
not complete first-sheet layouts. Eleven original parts remain to place.
The [companion input audit]({NAME}/companion-input-audit.json) verifies all 894
mode/region assignments and the source-support separation from the fixed inserts.

## Two distinct, closed companion constructions

Both models have 2,813 variables and 12,294 constraints. Every field, original
mode, 18 rigid rectangles and 146 different-owner rectangle pairs passes
independent readback. Each received exactly one bounded call, without a restart.

| Construction | Grid / outward rectangle gap | Charged preparation | Algorithm / shared time | Result |
|---|---|---:|---:|---|
| [Coarse model]({NAME}/coarse-model-audit.json) | 0.1 mm / 0.3 mm | 42.698448 s | 47.138130 / 47.211093 s | [INFEASIBLE]({NAME}/coarse-response-audit.json) |
| [Fine model]({NAME}/fine-model-audit.json) | 0.01 mm / 0.23 mm | 42.986673 s | 47.265134 / 47.330650 s | [INFEASIBLE]({NAME}/fine-response-audit.json) |

The [fine geometry audit]({NAME}/fine-geometry-audit.json) verifies 4,559 exact
halfplane implications for unchanged source hulls. Maximum normal approximation
error falls to 0.007398 mm. Physical source spacing is unchanged; the finer
construction still exceeds its requirement. Both calls have no assignment or
overrun. These grid results have no independent unsat certificate and **do not
prove continuous infeasibility**. A response audit initially invoked in the
default runtime failed to import OR-Tools before creating output; its successful
execution uses the pinned CP-SAT runtime. No solver call was repeated.

## Continuous bracket capacity proofs

The [triple audit]({NAME}/triple-capacity-audit.json) reconstructs 153 source
options across six small bracket domains, checks 1,963 incompatible pairs, and
verifies 578 complete disjunction trees with independent rational Floyd closure.
Three domains cannot contain three brackets. Applying those proofs removes
eight distributions and site choices [5,12], [5,13], [10,14] and [11,14], leaving
[10 choices / 16 distributions]({NAME}/triple-filter-audit.json).

The [higher-count audit]({NAME}/higher-capacity-audit.json) directly enumerates
992,858 multisets and checks every required triple subset against audited
survivors. It proves capacities three and four for two other bracket domains.
No new difference-constraint exclusions are needed at these higher counts.
The [final filtering audit]({NAME}/final-filter-audit.json) removes three more
distributions, including site choice [9,13], and verifies all 2,613 retained
source-mode attributions. [The authoritative table]({NAME}/all9-filtered-bounds.json)
contains **9 site choices and 13 count distributions**. Every other field of
each retained source row is unchanged. These proofs concern the specified
fixed-cog construction, not whole-job infeasibility.

The archive contains {archive['archive_members']} new canonical members and
{archive['archive_bytes']:,} compressed bytes. [Its manifest]({NAME}/raw-manifest.json),
[external evidence map]({NAME}/external-evidence.json), and [source bindings]({NAME}/source-bindings.json)
preserve every new attempt and bind reused historical bytes to the previously
committed full archive. An independent archive reader verifies both bundles.

[Next work]({NAME}/next-step.json) applies exact capacities to the larger
remaining bracket regions. H2/H5 remain open at **60%**. No product change or
release claim follows, and the original gates and reserved H2 vectors remain intact.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 continuous inserts and bracket capacities:** [the independently audited checkpoint]({link}) validates a shared two-insert placement and four partial 55-part layouts across both sheets. Distinct coarse/fine eleven-part companion models each close INFEASIBLE with no assignment or overrun; these statuses do not exclude continuous geometry. Exact bracket triple proofs and exhaustive higher-count enumeration reduce the restricted domain from 14 choices / 24 distributions to 9 / 13, with every retained source field preserved. The 440 whole-job allocations, full66 source/native/material checks and H5 matrix remain open. H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [smaller global construction](../benchmarks/results/h5-block-pruned-global-call-20261104.md).';assert s.count(old)==1
s=s.replace(old,f'Latest H5 evidence: [continuous inserts and exact bracket capacities](../benchmarks/results/{NAME}.md).\nThe restricted construction now has 9 site choices and 13 count distributions.',1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
