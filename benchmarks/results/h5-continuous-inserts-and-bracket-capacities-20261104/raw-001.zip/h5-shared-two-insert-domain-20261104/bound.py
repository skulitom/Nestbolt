"""Extract the common two-insert source block and exact necessary pair/area bounds."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];COUNT=ROOT/'output/h5-first55-direct-smaller-block-filtered-20261104';FACTOR=ROOT/'output/h5-first55-component-factorization-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';FINE=ROOT/'output/h5-first55-direct-fine-band-capacity-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';OUT=ROOT/'output/h5-shared-two-insert-domain-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
for p in [COUNT,FACTOR,GEN,FINE]:assert load(p/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter();rows=load(COUNT/'all-filtered-bounds.json');graphs={tuple(r['empty_sites']):r for r in load(FACTOR/'all18-factorizations.json')};uses=[];keys=None
for row in rows:
    graph=graphs[tuple(row['empty_sites'])]
    if len(graph['independent_blocks'])<2:continue
    for counts in row['remaining_distributions']:
        for block in graph['independent_blocks']:
            totals={f:sum(counts[i] for i in block if row['groups'][i]['family']==f) for f in ['bracket','insert']}
            if totals!={'bracket':0,'insert':2}:continue
            selected=sorted({tuple(a[:4]) for a in row['region_component_assignments'] if a[4] in block})
            if keys is None:keys=selected
            assert keys==selected;uses.append({'empty_sites':row['empty_sites'],'counts':counts,'block_groups':block})
assert len(keys)==14 and len(uses)==5;unary=load(PRIOR/'integer-preparation/unary-templates.json');inner=load(GEN/'source-inner-rectangles.json');nodes=[]
for family,mode,gid,ri in keys:
    hull=[tuple(map(F,p)) for p in next(r for r in unary[gid]['regions'] if r['region']==ri)['hull_vertices']];bounds=[min(p[k] for p in hull) for k in [0,1]]+[max(p[k] for p in hull) for k in [0,1]]
    assert len(inner[family][mode])==1;nodes.append({'key':[family,mode,gid,ri],'translation_bounds_mm':[str(v) for v in bounds],'contained_rectangles_mm':inner[family][mode]})
spans={k:[] for k in keys}
for r in load(FINE/'source-fine-covers.json'):
    key=tuple(r['source_key'])
    if key in spans:spans[key].extend(r['band_spans_tenths_mm'])
x0=min(l for ss in spans.values() for y,l,r in ss);x1=max(r for ss in spans.values() for y,l,r in ss);y0=min(y for ss in spans.values() for y,l,r in ss);y1=max(y for ss in spans.values() for y,l,r in ss)+1;w=x1-x0;supports=[]
for key in keys:
    support=0
    for y,l,r in spans[key]:support|=((1<<(r-l))-1)<<((y-y0)*w+l-x0)
    supports.append(support)
gap=F(149,1000);assert 2*gap**2<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2;pair_certs=[];area_certs=[];retained=[]
for i,j in combinations_with_replacement(range(len(nodes)),2):
    A,B=[list(map(F,nodes[k]['translation_bounds_mm'])) for k in [i,j]];a,b=[list(map(F,nodes[k]['contained_rectangles_mm'][0])) for k in [i,j]]
    maxima=[B[2]+b[0]-A[0]-a[2],A[2]+a[0]-B[0]-b[2],B[3]+b[1]-A[1]-a[3],A[3]+a[1]-B[1]-b[3]]
    if max(maxima)<gap:pair_certs.append({'nodes':[i,j],'maximum_directional_gaps_mm':[str(v) for v in maxima]});continue
    upper=F((supports[i]|supports[j]).bit_count(),5);lower=(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])
    if lower>upper:area_certs.append({'nodes':[i,j],'upper_support_area_mm2':str(upper),'lower_source_area_mm2':str(lower)});continue
    retained.append([i,j])
elapsed=time.perf_counter()-started
inputs=[Path(__file__),FIRST/'plan.json',PRIOR/'integer-preparation/unary-templates.json',GEN/'plan.json',GEN/'source-inner-rectangles.json',GEN/'audit/plan.json',GEN/'audit/checks.json']+[COUNT/n for n in ['plan.json','audit/plan.json','audit/checks.json','all-filtered-bounds.json']]+[FACTOR/n for n in ['plan.json','audit/plan.json','audit/checks.json','all18-factorizations.json']]+[FINE/n for n in ['plan.json','audit/plan.json','audit/checks.json','source-fine-covers.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Find every retained independent block with zero brackets and two inserts; require equality of its complete source-option domain across all uses. Enumerate all105 nondecreasing mode/region option pairs including repeated options. A pair is excluded only by exact necessary original-rectangle directional-gap bounds or exact area of its audited source-support union. Preserve all survivors; no solver or native call.','gap_mm':str(gap),'discovery_cap_seconds':60,'packing_solver_calls':0,'native_calls':0})
write(OUT/'nodes.json',nodes);write(OUT/'compatible-uses.json',uses);write(OUT/'pair-certificates.json',pair_certs);write(OUT/'area-certificates.json',area_certs);write(OUT/'retained-option-pairs.json',retained)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'scan_complete':True,'source_options':len(nodes),'compatible_site_choices':len({tuple(u['empty_sites']) for u in uses}),'compatible_count_distributions':len(uses),'initial_option_pairs':105,'directional_certificates':len(pair_certs),'area_certificates':len(area_certs),'necessary_option_pairs_remaining':len(retained),'continuous_source_block_excluded_pending_audit':not retained,'independent_audit_required':True,'remaining_count_distributions':24,'remaining_site_choices':14,'remaining_allocation_candidates':440,'packing_solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
