"""Independent common-domain extraction and complete two-insert pair readback."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-shared-two-insert-domain-20261104';OUT=BASE/'audit';COUNT=ROOT/'output/h5-first55-direct-smaller-block-filtered-20261104';FACTOR=ROOT/'output/h5-first55-component-factorization-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name;bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
source={tuple(r['empty_sites']):r for r in load(COUNT/'all-filtered-bounds.json')};uses=[];allkeys=[]
for g in load(FACTOR/'all18-factorizations.json'):
    if tuple(g['empty_sites']) not in source or len(g['independent_blocks'])<2:continue
    r=source[tuple(g['empty_sites'])]
    for counts in r['remaining_distributions']:
        for block in g['independent_blocks']:
            if sum(counts[i] for i in block)!=2 or any(counts[i] for i in block if r['groups'][i]['family']!='insert'):continue
            uses.append({'empty_sites':r['empty_sites'],'counts':counts,'block_groups':block});allkeys.append(sorted({tuple(a[:4]) for a in r['region_component_assignments'] if a[4] in block}))
nodes=load(BASE/'nodes.json');assert uses==load(BASE/'compatible-uses.json') and len(uses)==5 and all(keys==[tuple(n['key']) for n in nodes] for keys in allkeys) and len(nodes)==14
unary=load(PRIOR/'integer-preparation/unary-templates.json');inner=load(GEN/'source-inner-rectangles.json');bounds=[];boxes=[]
for n in nodes:
    f,m,g,r=n['key'];assert f=='insert' and n['contained_rectangles_mm']==inner[f][m] and len(inner[f][m])==1
    hull=[tuple(map(F,p)) for p in next(v for v in unary[g]['regions'] if v['region']==r)['hull_vertices']];b=[min(p[k] for p in hull) for k in [0,1]]+[max(p[k] for p in hull) for k in [0,1]];assert b==list(map(F,n['translation_bounds_mm']));bounds.append(b);boxes.append(list(map(F,inner[f][m][0])))
gap=F(149,1000);assert 2*gap**2<F(load(FIRST/'plan.json')['required_pair_gap_mm'])**2;certs=load(BASE/'pair-certificates.json');actual={tuple(c['nodes']):c for c in certs};assert len(actual)==len(certs);expected=[];retained=[]
for i,j in combinations_with_replacement(range(14),2):
    A,B=bounds[i],bounds[j];a,b=boxes[i],boxes[j];rel=[B[0]-A[2],B[1]-A[3],B[2]-A[0],B[3]-A[1]]
    possible=[rel[2]>=a[2]-b[0]+gap,rel[0]<=a[0]-b[2]-gap,rel[3]>=a[3]-b[1]+gap,rel[1]<=a[1]-b[3]-gap]
    if any(possible):retained.append([i,j])
    else:
        expected.append((i,j));assert actual[i,j]['maximum_directional_gaps_mm']==[str(v) for v in [rel[2]+b[0]-a[2],-rel[0]+a[0]-b[2],rel[3]+b[1]-a[3],-rel[1]+a[1]-b[3]]]
assert set(expected)==set(actual) and load(BASE/'area-certificates.json')==[] and retained==load(BASE/'retained-option-pairs.json') and len(retained)==7
write(OUT/'source-bindings.json',bindings);inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','nodes.json','compatible-uses.json','pair-certificates.json','area-certificates.json','retained-option-pairs.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'original_source_options_verified':14,'independent_block_uses_verified':5,'site_choices':4,'complete_option_pairs_verified':105,'exact_directional_exclusions_verified':98,'necessary_option_pairs_remaining':7,'continuous_block_excluded':False,'any_placement_proven':False,'packing_solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
