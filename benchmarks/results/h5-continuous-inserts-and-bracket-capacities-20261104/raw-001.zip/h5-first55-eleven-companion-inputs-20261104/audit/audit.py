"""Verify original continuous fixed poses, source55 inventories and exact companion decomposition."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-eleven-companion-inputs-20261104';OUT=BASE/'audit';COUNT=ROOT/'output/h5-first55-direct-smaller-block-filtered-20261104';DOMAIN=ROOT/'output/h5-shared-two-insert-domain-20261104';FIXED=ROOT/'output/h5-source-two-insert-continuous-block-20261104';GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';FACTOR=ROOT/'output/h5-first55-component-factorization-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';GEN=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name;bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(FACTOR/'audit/checks.json')['model_clearance_preserved_between_blocks'];selected=load(FIXED/'selected.json');f,m,gid,ri=selected['source_key'];assert f=='insert' and selected['identities']==[['insert',15],['insert',16]]
region=next(r for r in load(PRIOR/'integer-preparation/unary-templates.json')[gid]['regions'] if r['region']==ri);assert selected['source_hull_vertices']==region['hull_vertices'];hull=[list(map(F,p)) for p in region['hull_vertices']];points=[list(map(F,p)) for p in selected['lower_left_mm']]
for xy in points:
    cross=[(q[0]-p[0])*(xy[1]-p[1])-(q[1]-p[1])*(xy[0]-p[0]) for p,q in zip(hull,hull[1:]+hull[:1])];assert all(v>=0 for v in cross) or all(v<=0 for v in cross)
mode=load(GEO/'family-modes.json')[f][m];outer=list(map(F,load(GEO/'mode-rectangles.json')[f][m]['rectangles'][0]['exact_affine_bounds_mm']));inner=list(map(F,load(GEN/'source-inner-rectangles.json')[f][m][0]));extension=max(inner[0]-outer[0],inner[1]-outer[1],outer[2]-inner[2],outer[3]-inner[3]);assert extension<F(15,100)
assert points[1][1]+outer[1]-points[0][1]-outer[3]==F(selected['vertical_rectangle_gap_mm'])>=F(226,1000)
fixed=load(FIXED/'source2.json');assert fixed==load(BASE/'fixed-source2.json')
for row,xy,identity in zip(fixed,points,selected['identities']):assert row=={'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[float(xy[k])+mode['translation_from_lower_left'][k] for k in [0,1]]}}
original={tuple(r['empty_sites']):r for r in load(COUNT/'all-filtered-bounds.json')};graphs={tuple(r['empty_sites']):r for r in load(FACTOR/'all18-factorizations.json')};uses=load(DOMAIN/'compatible-uses.json');new=load(BASE/'all4-companion-bounds.json');assert len(new)==4;assignments=0;aliases=0
for row in new:
    src=original[tuple(row['empty_sites'])];matches=[u for u in uses if u['empty_sites']==row['empty_sites']];removed=matches[0]['block_groups'];kept=[i for i in range(len(src['groups'])) if i not in removed];assert removed in graphs[tuple(row['empty_sites'])]['independent_blocks']
    assert all((edge['groups'][0] in removed)==(edge['groups'][1] in removed) for edge in graphs[tuple(row['empty_sites'])]['interaction_edges'])
    assert all(m['block_groups']==removed for m in matches) and all(m['counts'] in src['remaining_distributions'] for m in matches)
    excluded_keys={tuple(a[:4]) for a in src['region_component_assignments'] if a[4] in removed};assert excluded_keys=={tuple(n['key']) for n in load(DOMAIN/'nodes.json')} and tuple(selected['source_key']) in excluded_keys
    expected_assignments=[a[:4]+[kept.index(a[4])] for a in src['region_component_assignments'] if a[4] in kept];expected={'empty_sites':src['empty_sites'],'groups':[src['groups'][i] for i in kept],'region_component_assignments':expected_assignments,'remaining_distributions':[[m['counts'][i] for i in kept] for m in matches],'original_group_indices':kept,'fixed_group_indices':removed};assert row==expected
    bygeometry={}
    for f,m,g,r,gi in row['region_component_assignments']:assert row['groups'][gi]['family']==f;bygeometry.setdefault((f,g,r),set()).add(gi);assignments+=1
    assert all(len(v)==1 for v in bygeometry.values());aliases+=len(bygeometry)
    for counts in row['remaining_distributions']:
        assert sum(counts)==11
        for f,total in [('bracket',7),('insert',4)]:assert sum(n for n,g in zip(counts,row['groups']) if g['family']==f)==total
original_instances=load(GEO/'instances.json');fixed_ids={tuple(v) for v in selected['identities']};instances=[r for r in original_instances if tuple(r['identity']) not in fixed_ids];assert instances==load(BASE/'instances.json') and len(instances)==11
expected_components=[]
for owner,instance in enumerate(instances):
    source=[c for c in load(GEO/'components.json') if c['identity']==instance['identity']]
    for c in source:expected_components.append({**c,'component':len(expected_components),'owner':owner})
assert expected_components==load(BASE/'components.json') and len(expected_components)==18
pairs=[{'components':[a['component'],b['component']],'owners':[a['owner'],b['owner']]} for a,b in combinations(expected_components,2) if a['owner']!=b['owner']];assert pairs==load(BASE/'component-pairs.json') and len(pairs)==146
inventory=load(GEO/'inventory.json');sites=load(SLOTS/'source-cog-sites.json');spec=load(FIRST/'plan.json');source_records=[]
for row in new:
    empty=row['empty_sites'];expected=load(FIRST/'fixed29.json')
    for site,identity in zip([i for i in range(15) if i not in empty],inventory['required_cog13_identities']):r=deepcopy(sites[site]);r['copy_index']=identity[1];expected.append(r)
    expected+=load(SHORT)+deepcopy(fixed);name='empty-'+'-'.join(map(str,empty));assert expected==load(FIXED/(name+'-source55.json'))
    check=load(FIXED/(name+'-checks.json'));assert check['valid'] and check['originals']==55 and check['family_counts']=={'frame':18,'insert':17,'cog':15,'bracket':5} and check['same_sheet_pairs']==1001 and check['stock_edges']==220 and check['cutouts']==65 and check['hole_vertices']==6976 and check['pair_failures']==check['stock_failures']==0
    assert len(check['pairs'])==1001 and all(p['distance_mm']>=spec['required_pair_gap_mm'] for p in check['pairs']);source_records.extend([FIXED/(name+'-source55.json'),FIXED/(name+'-checks.json')])
write(OUT/'source-bindings.json',bindings);write(OUT/'allowed-empty-site-pairs.json',[r['empty_sites'] for r in new]);inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','all4-companion-bounds.json','instances.json','components.json','component-pairs.json','fixed-source2.json']]+source_records+[FIXED/'selected.json',FIXED/'plan.json',GEO/'family-modes.json',GEO/'mode-rectangles.json',PRIOR/'integer-preparation/unary-templates.json',GEN/'source-inner-rectangles.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_mode_assignments_verified':assignments,'unique_geometry_region_attributions':aliases,'all_source_mode_aliases_agree_on_component':True,'continuous_fixed_poses_inside_original_hull':True,'fixed_shape_extension_bounded_by_existing_separation_proof':True,'fixed_outer_to_inner_extension_mm':str(extension),'independent_block_separation_inherited_without_grid_pose_assumption':True,'source55_exact_inventories_verified':4,'original_source_pairs_read_back':4004,'original_source_stock_edges_read_back':880,'original_source_cutouts_read_back':260,'source_hole_vertices_per_use':6976,'site_choices':4,'count_distributions':5,'remaining_originals':11,'moving_brackets':7,'moving_inserts':4,'rigid_components':18,'different_owner_rectangle_pairs':146,'fixed_source2_preserved':True,'source_valid66':False,'packing_solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
