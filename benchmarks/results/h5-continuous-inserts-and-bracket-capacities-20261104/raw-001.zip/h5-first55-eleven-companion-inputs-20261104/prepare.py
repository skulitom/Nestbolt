"""Extract the complete eleven-part companions of the independently placed two inserts."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];COUNT=ROOT/'output/h5-first55-direct-smaller-block-filtered-20261104';DOMAIN=ROOT/'output/h5-shared-two-insert-domain-20261104';FIXED=ROOT/'output/h5-source-two-insert-continuous-block-20261104';GEO=ROOT/'output/h5-first55-local-grid-regions-20261029';FACTOR=ROOT/'output/h5-first55-component-factorization-20261029';OUT=ROOT/'output/h5-first55-eleven-companion-inputs-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(FIXED/'checks.json')['source_valid55_all_four_uses'] and load(DOMAIN/'audit/checks.json')['passed'] and load(FACTOR/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();uses=load(DOMAIN/'compatible-uses.json');rows=load(COUNT/'all-filtered-bounds.json');companions=[]
for row in rows:
    matched=[u for u in uses if u['empty_sites']==row['empty_sites']]
    if not matched:continue
    removed=matched[0]['block_groups'];assert all(u['block_groups']==removed for u in matched);kept=[i for i in range(len(row['groups'])) if i not in removed];index={old:new for new,old in enumerate(kept)}
    distributions=[]
    for u in matched:
        assert u['counts'] in row['remaining_distributions'] and sum(u['counts'][i] for i in removed)==2
        distributions.append([u['counts'][i] for i in kept])
    assignments=[a[:4]+[index[a[4]]] for a in row['region_component_assignments'] if a[4] in index]
    companions.append({'empty_sites':row['empty_sites'],'groups':[row['groups'][i] for i in kept],'region_component_assignments':assignments,'remaining_distributions':distributions,'original_group_indices':kept,'fixed_group_indices':removed})
assert len(companions)==4 and sum(len(r['remaining_distributions']) for r in companions)==5
fixed_ids={tuple(v) for v in load(FIXED/'selected.json')['identities']};original=load(GEO/'instances.json');instances=[r for r in original if tuple(r['identity']) not in fixed_ids];assert len(instances)==11
owner_map={old:new for new,old in enumerate(i for i,r in enumerate(original) if tuple(r['identity']) not in fixed_ids)};components=[]
for row in load(GEO/'components.json'):
    if row['owner'] in owner_map:components.append({**row,'component':len(components),'owner':owner_map[row['owner']]})
pairs=[{'components':[a['component'],b['component']],'owners':[a['owner'],b['owner']]} for a,b in combinations(components,2) if a['owner']!=b['owner']]
assert len(components)==18 and len(pairs)==146
write(OUT/'all4-companion-bounds.json',companions);write(OUT/'instances.json',instances);write(OUT/'components.json',components);write(OUT/'component-pairs.json',pairs);write(OUT/'fixed-source2.json',load(FIXED/'source2.json'));elapsed=time.perf_counter()-started
inputs=[Path(__file__)]+[COUNT/n for n in ['plan.json','audit/plan.json','audit/checks.json','all-filtered-bounds.json']]+[DOMAIN/n for n in ['plan.json','audit/plan.json','audit/checks.json','nodes.json','compatible-uses.json']]+[FIXED/n for n in ['plan.json','checks.json','selected.json','source2.json']]+[FACTOR/n for n in ['plan.json','audit/plan.json','audit/checks.json','all18-factorizations.json']]+[GEO/n for n in ['plan.json','geometry-audit/plan.json','geometry-audit/checks.json','instances.json','components.json','component-pairs.json','mode-rectangles.json','inventory.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For every compatible count distribution of the proved shared two-insert block, preserve every source option and count in its other independent component. Fix source inserts15/16 to their validated continuous poses and remove them from the moving inventory. Reindex only remaining source groups, owners and rectangle components. The original independent-block separation proof justifies omitting fixed-two versus companion constraints; final full66 source validation remains mandatory.','packing_solver_calls':0,'native_calls':0})
checks={'passed':True,'seconds':elapsed,'site_choices':4,'count_distributions':5,'moving_originals':11,'fixed_source_originals':2,'moving_brackets':7,'moving_inserts':4,'rigid_components':18,'different_owner_rectangle_pairs':146,'independent_audit_required':True,'packing_solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
