"""Remove only rationally certified redundant same-orientation/sheet domains."""
from collections import Counter,defaultdict
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import combinations
import math,shutil,time,traceback
from audit_h5_direct_coordinate_domains import clip
from build_h5_direct_coordinate_domains import ROOT,OUT as BASE,load,write,digest
SRC=BASE/'consolidated/audit';OUT=BASE/'reduced';SECONDS=30;COMPARISONS=500000

def inequalities(row):
    a,b,c,d=row['coordinate_bounds']
    return [(h['a'],h['b'],h['upper']) for h in row['halfspaces']]+[(-1,0,-a),(0,-1,-b),(1,0,c),(0,1,d)]

def vertices_clip(row):
    a,b,c,d=row['coordinate_bounds'];poly=[(F(a),F(b)),(F(c),F(b)),(F(c),F(d)),(F(a),F(d))]
    for A,B,C in inequalities(row):poly=clip(poly,F(A),F(B),F(C))
    return poly

def vertices_intersections(row):
    lines=inequalities(row);vertices=set()
    for (a,b,c),(d,e,f) in combinations(lines,2):
        det=a*e-b*d
        if not det:continue
        x=F(c*e-b*f,det);y=F(a*f-c*d,det)
        if all(A*x+B*y<=C for A,B,C in lines):vertices.add((x,y))
    return vertices

def inside(poly,row):return all(a*x+b*y<=c for a,b,c in inequalities(row) for x,y in poly)

def main():
    assert load(SRC/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'reduce.py');source=SRC/'integer-domains.json';rows=load(source);manifest=ROOT/'benchmarks/results/h5-direct-coordinate-domains-20261025/raw-manifest.json';raw=load(manifest);key=BASE.name+'/consolidated/audit/integer-domains.json';match=next(r for r in raw['files']+raw['aliases'] if r['path']==key);assert digest(source)==match['sha256'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [source,SRC/'checks.json',BASE/'plan.json',BASE/'next-step.json',manifest]},'source_manifest_member':key,'reduction_seconds_limit':SECONDS,'comparison_limit':COMPARISONS,'method':'Clip each already inward-rounded bounded domain with exact rational arithmetic. Remove an empty continuous domain, or map a domain to an already retained domain in the identical orientation class and sheet only if every rational source vertex satisfies every target integer halfspace and bound. Every allowed coordinate is preserved. Process by descending continuous area for useful supersets; the order is not an acceptance condition. Stop containment comparisons at30seconds or500000, keep all remaining domains and do not extend. Independently reconstruct every empty or replaced source domain from pairwise boundary-line intersections and verify its full target inequalities. Because domains are bounded convex polyhedra, vertices certify whole-domain containment. No solver or pose generation.'})
    prep=time.perf_counter();polys={i:vertices_clip(r) for i,r in enumerate(rows)};prepseconds=time.perf_counter()-prep
    def area(i):
        p=polys[i]
        return abs(sum(x*v-y*u for (x,y),(u,v) in zip(p,p[1:]+p[:1]))/2) if p else F(0)
    order=sorted(range(len(rows)),key=lambda i:(-area(i),i));kept=[];byquery=defaultdict(list);removed=[];comparisons=0;start=time.perf_counter();cutoff=None
    for i in order:
        row=rows[i];p=polys[i]
        if not p:removed.append({'source':i,'reason':'empty rational domain after integer bounding interval intersection'});continue
        replacement=None
        if time.perf_counter()-start<SECONDS and comparisons<COMPARISONS:
            for j in byquery[row['query']]:
                if time.perf_counter()-start>=SECONDS or comparisons>=COMPARISONS:break
                a,b,c,d=rows[j]['coordinate_bounds']
                if any(x<a or x>c or y<b or y>d for x,y in p):continue
                comparisons+=1
                if inside(p,rows[j]):replacement=j;break
        else:
            if cutoff is None:cutoff=i
        if replacement is None:kept.append(i);byquery[row['query']].append(i)
        else:removed.append({'source':i,'target':replacement,'reason':'bounded rational source polyhedron contained in retained same-query target','vertices':[[[x.numerator,x.denominator],[y.numerator,y.denominator]] for x,y in p]})
    seconds=time.perf_counter()-start;kept=sorted(kept);write(OUT/'selection.json',{'retained':kept,'removed':removed,'processing_order':order});write(OUT/'integer-domains.json',[{'source_domain':i,**rows[i]} for i in kept]);write(OUT/'result.json',{'preparation_seconds':prepseconds,'reduction_seconds':seconds,'source_domains':len(rows),'retained_domains':len(kept),'removed_domains':len(removed),'comparisons':comparisons,'time_limit_reached':cutoff is not None or seconds>=SECONDS,'comparison_limit_reached':comparisons>=COMPARISONS,'first_unsearched_source':cutoff,'independent_audit_pending':True,'solver_calls':0})
    # Independent line-intersection oracle, without trusting clipping vertices.
    auditstart=time.perf_counter();checkedvertices=0;checkedinequalities=0;empties=0;assert len(set(kept))==len(kept) and set(kept)|{r['source'] for r in removed}==set(range(len(rows))) and not set(kept)&{r['source'] for r in removed}
    for r in removed:
        i=r['source'];v=vertices_intersections(rows[i])
        if 'target' not in r:assert not v;empties+=1;continue
        j=r['target'];assert j in kept and rows[i]['query']==rows[j]['query'] and rows[i]['orientation_class']==rows[j]['orientation_class'] and rows[i]['sheet_id']==rows[j]['sheet_id'] and rows[i]['family']==rows[j]['family'];assert v and inside(v,rows[j]);assert set(v)==set(polys[i]);checkedvertices+=len(v);checkedinequalities+=len(v)*len(inequalities(rows[j]))
    counts=Counter(rows[i]['family'] for i in kept);write(OUT/'checks.json',{'passed':True,'independent_audit_seconds':time.perf_counter()-auditstart,'source_matches_committed_manifest':True,'source_domains':len(rows),'retained_domains':len(kept),'retained_by_family':dict(counts),'removed_empty_domains':empties,'removed_by_certified_containment':len(removed)-empties,'independent_intersection_vertices_checked':checkedvertices,'target_inequalities_checked':checkedinequalities,'no_feasible_grid_coordinate_lost':True,'per_copy_domain_choices':counts['bracket']*12+counts['insert']*21,'solver_calls':0,'full_target_witness':False});print(load(OUT/'result.json'));print(load(OUT/'checks.json'),flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
