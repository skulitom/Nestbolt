"""Independently check all pair domains, integer cells and original-ring clearance samples."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,box
from h5_global_sliding_objective import SlidingObjective
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-local-source-cells-20261026';GEO=ROOT/'output/h5-legacy57-sliding-source-20261026';OUT=BASE/'geometry-audit-orientation-repaired';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
obj=SlidingObjective(GEO);ds=load(BASE/'domains.json');pairs=load(BASE/'pairs.json');assert len(ds)==57 and len(pairs)==1596 and [(p['left'],p['right']) for p in pairs]==list(combinations(range(57),2));job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};required=(job['clearance']+3000*32*2**-23)/math.cos(.05);guard=3000*32*2**-23;shapes=[];stock_checks=0
for m in obj.modes:
    c,s=math.cos(m['angle']),math.sin(m['angle']);sgn=-1 if m['mirrored'] else 1;tx,ty=m['source_translation_offset'];shapes.append(Polygon([(sgn*x*c-y*s+tx,sgn*x*s+y*c+ty) for x,y in parts[m['family']]['geometry'][0]['outer']]))
for i,d in enumerate(ds):
    assert d['original']==obj.moving[i]['original'] and d['mode']==plan['fixed_source_modes'][i];free=obj.free[d['mode']]
    for x in [d['lower_um'][0],d['upper_um'][0]]:
        for y in [d['lower_um'][1],d['upper_um'][1]]:
            b=shapes[d['mode']].bounds;assert min(b[0]+x/1000-6.5,b[1]+y/1000-6.5,1493.5-b[2]-x/1000,2993.5-b[3]-y/1000)>guard;stock_checks+=4
cells=faces=entire=source_samples=0;minimum_distance=math.inf
from shapely.affinity import translate
for p in pairs:
    i,j=p['left'],p['right'];a,b=ds[i],ds[j];bounds=[b['lower_um'][0]-a['upper_um'][0],b['lower_um'][1]-a['upper_um'][1],b['upper_um'][0]-a['lower_um'][0],b['upper_um'][1]-a['lower_um'][1]];assert p['relative_bounds_um']==bounds and p['originals']==[a['original'],b['original']];region=box(*[v/1000 for v in bounds]);obstacle=obj.obstacles[a['mode']*len(obj.modes)+b['mode']]
    if p['kind']=='entire_box_safe':assert region.disjoint(obstacle);entire+=1;pieces=[region]
    else:
        assert p['kind']=='convex_cell_disjunction';pieces=[]
        for cell in p['cells']:
            vv=cell['vertices_um'];area2=sum(vv[k][0]*vv[(k+1)%len(vv)][1]-vv[(k+1)%len(vv)][0]*vv[k][1] for k in range(len(vv)));assert area2==cell['area2_um2']>0;expected=[]
            for a0,b0 in zip(vv,vv[1:]+vv[:1]):
                dx,dy=b0[0]-a0[0],b0[1]-a0[1];divisor=math.gcd(abs(dx),abs(dy));nx,ny=-dy//divisor,dx//divisor;rhs=nx*a0[0]+ny*a0[1];assert all(nx*x+ny*y>=rhs for x,y in vv);expected.append([nx,ny,rhs])
            assert expected==cell['faces'];g=Polygon([[x/1000,y/1000] for x,y in vv]);assert g.is_valid and g.equals(g.convex_hull) and region.covers(g) and g.disjoint(obstacle);distance=g.distance(obstacle);reverse_distance=Polygon([[x/1000,y/1000] for x,y in reversed(vv)]).distance(obstacle);assert cell['distance_to_original_obstacle_mm'] in [distance,reverse_distance] and distance>0 and reverse_distance>0;minimum_distance=min(minimum_distance,distance);pieces.append(g);cells+=1;faces+=len(expected)
    for g in pieces:
        for x,y in list(g.exterior.coords)[:-1]+[list(g.representative_point().coords)[0]]:
            other=translate(shapes[b['mode']],xoff=x,yoff=y);assert shapes[a['mode']].disjoint(other) and shapes[a['mode']].distance(other)>required;source_samples+=1
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'all57_domains_verified':True,'all1596_pairs_verified':True,'stock_edge_corner_checks':stock_checks,'entire_relative_boxes_verified':entire,'convex_cells_verified':cells,'exact_integer_halfplanes_verified':faces,'original_source_clearance_samples':source_samples,'minimum_cell_distance_to_conservative_obstacle_mm':minimum_distance,'all66_required':True,'positive_assignment_needs_full_source_readback':True,'finite_sufficient_subset_only':True,'unrestricted_exclusion':False,'native_calls':0});print(load(OUT/'checks.json'))
