"""Encode every source-clearance cell as an enforced integer halfplane conjunction."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-local-source-cells-20261026';OUT=ROOT/'output/h5-local-source-cells-model-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(GEO/'geometry-audit-orientation-repaired/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs={p.relative_to(ROOT).as_posix():digest(p) for p in GEO.rglob('*') if p.is_file()};write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'objective':None,'all57_first_originals_required':True,'all9_short_originals_fixed':True,'finite_sufficient_geometry_only':True})
ds=load(GEO/'domains.json');pairs=load(GEO/'pairs.json');model=cp_model.CpModel();coords=[];records=[]
for d in ds:
    xy=[model.new_int_var(d['lower_um'][k],d['upper_um'][k],f'{axis}_{d["original"]}') for k,axis in enumerate(['x','y'])];coords.append(xy)
    for k,v in enumerate(xy):model.add_hint(v,d['hint_um'][k])
for pair_index,p in enumerate(pairs):
    if p['kind']=='entire_box_safe':continue
    i,j=p['left'],p['right'];cells=p['cells'];selectors=[model.new_bool_var(f'pair_{i}_{j}_cell_{c}') for c in range(len(cells))];model.add_exactly_one(selectors);entry={'pair_index':pair_index,'selector_indices':[v.index for v in selectors],'cell_constraint_indices':[]}
    for cell,z in zip(cells,selectors):
        indices=[]
        for nx,ny,rhs in cell['faces']:
            ct=model.add(nx*(coords[j][0]-coords[i][0])+ny*(coords[j][1]-coords[i][1])>=rhs);ct.only_enforce_if(z);indices.append(ct.index)
        entry['cell_constraint_indices'].append(indices)
    records.append(entry)
assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',{'coordinate_indices':[[v.index for v in xy] for xy in coords],'pairs':records});write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'mandatory_originals':57,'coordinate_variables':114,'selector_variables':len(model.proto.variables)-114,'model_sha256':digest(OUT/'model.pb'),'model_validation':'','solver_calls':0});print(load(OUT/'built.json'))
