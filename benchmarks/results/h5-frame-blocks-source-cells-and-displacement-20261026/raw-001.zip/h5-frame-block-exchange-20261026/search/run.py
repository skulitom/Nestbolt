"""One bounded compound call for coordinated frame-block choices and joint translations."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-frame-block-exchange-20261026';GEO=ROOT/'output/h5-legacy57-sliding-source-20261026';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
class Stop(Exception):pass
class StageStop(Exception):pass
def child():
    import numpy as np
    import scipy
    from scipy.optimize import minimize
    from h5_guided_sliding_objective import GuidedObjective
    assert load(BASE/'checks.json')['passed']
    for n,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    obj=GuidedObjective(GEO);patterns=load(BASE/'patterns.json');global_start=time.perf_counter();global_end=global_start+60;outcomes=[]
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'search_seconds':60,'shared_seconds':90,'per_pattern_seconds':12,'maximum_patterns':4,'maximum_weight_updates_each':20,'frame_orientation_changes_as_groups':True,'all57_movers_mandatory':True,'scipy_version':scipy.__version__,'numpy_version':np.__version__})
    for pattern in patterns:
        if time.perf_counter()>=global_end:break
        dest=OUT/pattern['name'];dest.mkdir();x=np.asarray(pattern['anchors']).reshape(-1);modes=list(pattern['modes']);npairs=len(obj.left);n=len(obj.moving);base=np.r_[np.ones(npairs),np.full(n,4.)];pw=np.ones(npairs);sw=np.full(n,4.);calls=0;best=None;improvements=[];updates=[];stages=[];trials=[];changes=[];started=time.perf_counter();deadline=min(global_end,started+12)
        def evaluate(z,mi,kind):
            nonlocal calls,best
            if time.perf_counter()>=deadline:raise Stop()
            value,gradient,diag,pq,sq=obj.weighted(z,mi,pw,sw);calls+=1;raw=diag['unweighted_penalty_mm2']
            if best is None or raw<best['value']:best={'value':raw,'anchors':np.asarray(z).reshape(-1,2).tolist(),'modes':list(mi),'evaluation':calls,'seconds':time.perf_counter()-started,'diagnostics':diag};improvements.append({'evaluation':calls,'seconds':best['seconds'],'value':raw,'kind':kind,**diag})
            return value,gradient,diag,pq,sq
        status='ITERATION_LIMIT'
        try:
            value,_,diag,pq,sq=evaluate(x,modes,'initial')
            for iteration in range(20):
                q=np.r_[pq,sq];weights=np.r_[pw,sw];ratio=weights/base;eligible=np.flatnonzero((q>1e-12)&(ratio<1e6))
                if not len(eligible):status='ZERO_PENALTY_CANDIDATE' if diag['unweighted_penalty_mm2']<=1e-12 else 'WEIGHT_CAP';break
                utility=q/ratio;selected=sorted(eligible.tolist(),key=lambda k:(-utility[k],k))[:max(1,int(np.ceil(len(eligible)*.25)))];entries=[]
                for k in selected:
                    before=float(weights[k]);weights[k]=min(1e6*base[k],1.5*before);entries.append({'term':k,'depth_squared':float(q[k]),'utility':float(utility[k]),'before':before,'after':float(weights[k])})
                pw=weights[:npairs].copy();sw=weights[npairs:].copy();updates.append({'iteration':iteration,'eligible_terms':len(eligible),'selected':entries});value,_,diag,pq,sq=evaluate(x,modes,'weighted-start');stage_start=time.perf_counter();stage_modes=list(modes);stage_calls=0;stage_best={'value':value,'x':x.copy()};returned=None
                def fun(z):
                    nonlocal stage_calls,stage_best
                    if stage_calls>=700:raise StageStop()
                    v,g,*_=evaluate(z,stage_modes,'position');stage_calls+=1
                    if v<stage_best['value']:stage_best={'value':v,'x':np.asarray(z).copy()}
                    return v,g
                try:returned=minimize(fun,x,jac=True,method='L-BFGS-B',options={'maxiter':300,'maxfun':700,'maxls':20,'ftol':1e-12,'gtol':1e-6});x=np.asarray(returned.x)
                except StageStop:x=stage_best['x']
                value,_,diag,pq,sq=evaluate(x,modes,'position-returned');stages.append({'iteration':iteration,'seconds':time.perf_counter()-stage_start,'weighted_value':float(value),'unweighted_value':diag['unweighted_penalty_mm2'],'function_evaluations':stage_calls,'scipy_success':bool(returned.success) if returned is not None else False,'message':str(returned.message) if returned is not None else '700-evaluation stage limit'})
                if best['value']<=1e-12:status='ZERO_PENALTY_CANDIDATE';break
                if iteration%4==0:
                    for i,item in enumerate(obj.moving):
                        if item['family']=='frame':continue
                        original=modes[i];chosen=original;chosen_value=value
                        for alternate in item['allowed_modes']:
                            if alternate==original:continue
                            mi=list(modes);mi[i]=alternate;v,*_=evaluate(x,mi,'nonframe-mode');trials.append({'iteration':iteration,'original':item['original'],'from_mode':original,'alternative_mode':alternate,'weighted_value':float(v)})
                            if v<chosen_value-1e-8:chosen,chosen_value=alternate,v
                        if chosen!=original:changes.append({'iteration':iteration,'original':item['original'],'from_mode':original,'to_mode':chosen,'before_weighted':float(value),'after_weighted':float(chosen_value)});modes[i]=chosen;value=chosen_value
                    value,_,diag,pq,sq=evaluate(x,modes,'mode-returned')
                if best['value']<=1e-12:status='ZERO_PENALTY_CANDIDATE';break
        except Stop:status='TIME_LIMIT'
        assert best is not None
        record={'name':pattern['name'],'status':status,'seconds':time.perf_counter()-started,'objective_evaluations':calls,'weight_updates':len(updates),'returned_stages':len(stages),'mode_trials':len(trials),'accepted_nonframe_mode_changes':len(changes),'initial_unweighted_penalty_mm2':pattern['initial_unweighted_penalty_mm2'],'best_unweighted_penalty_mm2':best['value'],'closed':True,'all57_mandatory':True,'native_calls':0}
        for name,data in [('result',record),('best',best),('best-moving-placements',obj.placements(best['anchors'],best['modes'])),('improvements',improvements),('weight-updates',updates),('position-stages',stages),('mode-trials',trials),('accepted-mode-changes',changes),('final-weights',{'pair':pw.tolist(),'stock':sw.tolist()})]:write(dest/(name+'.json'),data)
        outcomes.append(record);print(record,flush=True)
        if best['value']<=1e-12:break
    write(OUT/'result.json',{'closed':True,'seconds':time.perf_counter()-global_start,'patterns_returned':len(outcomes),'patterns':outcomes,'all66_required_each':True,'finite_macro_alternatives_only':True,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');inputs={p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()};inputs.update(load(BASE/'plan.json')['inputs']);write(OUT/'plan.json',{'inputs':inputs,'search_seconds':60,'shared_seconds':90,'per_pattern_seconds':12,'maximum_calls':1,'retry_permitted':False});start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90);(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:(OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed response; call closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
