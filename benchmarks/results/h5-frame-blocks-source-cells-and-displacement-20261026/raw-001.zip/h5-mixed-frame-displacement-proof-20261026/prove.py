"""A five-original strip-width obstruction, independent of the finite cell model."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from datetime import datetime,timezone
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-legacy57-sliding-source-20261026';SEED=ROOT/'output/h5-frame-block-exchange-20261026/search/mixed-12-turned-6-wide/best.json';OUT=ROOT/'output/h5-mixed-frame-displacement-proof-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def ceil(q):return -((-q.numerator)//q.denominator)
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def rational(q):return [q.numerator,q.denominator]
OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();job=load(JOB);parts={p['id']:p for p in job['parts']};moving=load(GEO/'moving.json');modes=load(GEO/'modes.json');seed=load(SEED);selected=[0,1,2,3,31];radius=180000;proof=[];inputs=[JOB,SEED,GEO/'moving.json',GEO/'modes.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selected_originals':selected,'vertical_radius_um':radius,'method':'Use exact quarter-turn source filled outers for four turned frames and one vertical insert. Construct strictly source-contained integer-micrometre rectangles. Relax stock constraints to containment of those rectangles; enclose the saved binary64 anchors outward by integer bounds. Prove every pair of vertical intervals must intersect for every legal source translation within180mm vertically, even with arbitrary horizontal motion. Intervals in one dimension have the pairwise-intersection property: all five therefore cross a common horizontal line in each placement. Their disjoint horizontal intervals require at least the sum of their widths, which exceeds usable stock width even with zero clearance. This excludes that fixed-mode vertical neighborhood independently of all other61 parts and of the CP-SAT result. It is not a full-job impossibility proof.'})
for i,item in enumerate(moving):
    if item['original'] not in selected:continue
    mode=modes[seed['modes'][i]];assert mode['family']==item['family'] and not mode['mirrored'] and mode['angle']==math.pi/2;offset=[F.from_float(float(v)) for v in mode['source_translation_offset']];outer=[(offset[0]-F.from_float(float(y)),offset[1]+F.from_float(float(x))) for x,y in parts[item['family']]['geometry'][0]['outer']];assert len(outer)==4;xs=[p[0] for p in outer];ys=[p[1] for p in outer];inner=[ceil(min(xs)*1000)+1,ceil(min(ys)*1000)+1,(max(xs)*1000)//1-1,(max(ys)*1000)//1-1];inner=[int(v) for v in inner];corners=[(F(x,1000),F(y,1000)) for x in [inner[0],inner[2]] for y in [inner[1],inner[3]]]
    for p in corners:
        signs=[cross(a,b,p) for a,b in zip(outer,outer[1:]+outer[:1])];assert all(v>0 for v in signs) or all(v<0 for v in signs)
    center=F.from_float(float(seed['anchors'][i][1]))*1000;center_lo=center//1;center_hi=ceil(center);lower=max(6500-inner[1],int(center_lo)-radius);upper=min(2993500-inner[3],center_hi+radius);assert lower<=upper
    proof.append({'original':item['original'],'family':item['family'],'copy_index':item['copy_index'],'mode':seed['modes'][i],'source_outer_rational':[[rational(x),rational(y)] for x,y in outer],'source_contained_rectangle_um':inner,'source_anchor_y_um_rational':rational(center),'enclosing_anchor_center_um':[int(center_lo),center_hi],'relaxed_anchor_y_bounds_um':[lower,upper],'width_um':inner[2]-inner[0]})
assert [r['original'] for r in proof]==selected;overlaps=[]
for a,b in combinations(proof,2):
    alo,ahi=a['relaxed_anchor_y_bounds_um'];blo,bhi=b['relaxed_anchor_y_bounds_um'];ar=a['source_contained_rectangle_um'];br=b['source_contained_rectangle_um'];margins=[alo+ar[3]-bhi-br[1],blo+br[3]-ahi-ar[1]];assert min(margins)>0;overlaps.append({'originals':[a['original'],b['original']],'guaranteed_y_overlap_margins_um':margins})
width=sum(r['width_um'] for r in proof);assert width==1509990>1487000
write(OUT/'rectangles.json',proof);write(OUT/'pair-overlap-proof.json',overlaps);write(OUT/'certificate.json',{'vertical_radius_um':radius,'selected_originals':selected,'guaranteed_vertical_pair_intersections':len(overlaps),'minimum_overlap_margin_um':min(min(r['guaranteed_y_overlap_margins_um']) for r in overlaps),'required_cross_section_width_um':width,'available_stock_width_um':1487000,'width_excess_um':width-1487000,'source_clearance_assumed_um':0,'all_other61_originals_unconstrained':True,'horizontal_translation_unrestricted_within_stock':True,'fixed_source_modes_required':True,'filled_outers_reserved_part_in_hole_off':True,'implication':'Any valid layout must change at least one of these five orientations or move at least one vertically by more than180mm from the saved mixed candidate.','whole_job_excluded':False});write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'source_originals':5,'exact_source_corners':20,'exact_inner_corner_inclusion_checks':80,'pair_intersections':10,'solver_calls':0});print(load(OUT/'certificate.json'))
