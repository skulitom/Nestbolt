"""Independently reconstruct source inner rectangles and the interval-width obstruction."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-frame-displacement-proof-20261026';OUT=BASE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
records=load(BASE/'rectangles.json');certificate=load(BASE/'certificate.json');saved=load(BASE/'pair-overlap-proof.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};geo=ROOT/'output/h5-legacy57-sliding-source-20261026';moving=load(geo/'moving.json');modes=load(geo/'modes.json');seed=load(ROOT/'output/h5-frame-block-exchange-20261026/search/mixed-12-turned-6-wide/best.json');items={r['original']:(i,r) for i,r in enumerate(moving)};radius=180000;assert certificate['vertical_radius_um']==plan['vertical_radius_um']==radius;bounds=[];width=0;edge_checks=0
for r in records:
    i,item=items[r['original']];m=modes[seed['modes'][i]];assert r['mode']==seed['modes'][i] and m['angle']==math.pi/2 and not m['mirrored'] and r['family']==item['family'];tx,ty=map(F.from_float,map(float,m['source_translation_offset']));source=[(tx-F.from_float(float(v[1])),ty+F.from_float(float(v[0]))) for v in parts[item['family']]['geometry'][0]['outer']];assert source==[(F(*x),F(*y)) for x,y in r['source_outer_rational']];box=r['source_contained_rectangle_um'];corners=[(F(x,1000),F(y,1000)) for x in [box[0],box[2]] for y in [box[1],box[3]]]
    area2=sum(source[k][0]*source[(k+1)%4][1]-source[(k+1)%4][0]*source[k][1] for k in range(4));assert area2!=0
    for corner in corners:
        for a,b in zip(source,source[1:]+source[:1]):
            signed=(b[0]-a[0])*(corner[1]-a[1])-(b[1]-a[1])*(corner[0]-a[0]);assert signed*area2>0;edge_checks+=1
    center=F.from_float(float(seed['anchors'][i][1]))*1000;assert center==F(*r['source_anchor_y_um_rational']);lo=math.floor(center);hi=math.ceil(center);assert [lo,hi]==r['enclosing_anchor_center_um'];low=max(6500-box[1],lo-radius);high=min(2993500-box[3],hi+radius);assert [low,high]==r['relaxed_anchor_y_bounds_um'] and low<=high;assert r['width_um']==box[2]-box[0]>0;width+=r['width_um'];bounds.append((r['original'],low+box[3],high+box[1]))
assert [r['original'] for r in records]==[0,1,2,3,31];expected=[]
for a,b in combinations(bounds,2):
    margins=[a[1]-b[2],b[1]-a[2]];assert all(x>0 for x in margins);expected.append({'originals':[a[0],b[0]],'guaranteed_y_overlap_margins_um':margins})
assert expected==saved and width==certificate['required_cross_section_width_um']==1509990 and certificate['available_stock_width_um']==1487000 and certificate['width_excess_um']==22990 and certificate['minimum_overlap_margin_um']==min(min(p['guaranteed_y_overlap_margins_um']) for p in saved)==22
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_originals_verified':5,'exact_source_edges_checked':edge_checks,'guaranteed_vertical_pair_intersections_verified':10,'minimum_guaranteed_overlap_margin_um':22,'necessary_width_um':width,'usable_width_um':1487000,'excess_um':22990,'vertical_neighborhood_excluded_mm':180,'horizontal_positions_not_fixed':True,'other61_parts_not_fixed':True,'exact_quarter_turn_source_geometry':True,'independent_of_solver_or_minkowski_cells':True,'whole_job_excluded':False,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
