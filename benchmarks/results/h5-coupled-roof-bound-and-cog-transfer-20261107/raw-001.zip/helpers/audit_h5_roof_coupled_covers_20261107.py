"""Independent source containment, exhaustive masks and coupled area proof."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from bisect import bisect_left,bisect_right
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-roof-coupled-covers-20261107';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-orientation-roofs-20261107';BRACKET=ROOT/'output/h5-orientation-roof-covers-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PAD=Q(1,10**6)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def det(a,b):return a[0]*b[1]-a[1]*b[0]
def area(p):return sum(det(a,b) for a,b in zip(p,p[1:]+p[:1]))/2
def posed(vertices,t):
    c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));sign=-1 if t['mirrored'] else 1;matrix=((sign*c,-s),(sign*s,c));translation=list(map(Q,t['translation']));p=[tuple(sum(matrix[k][j]*Q(v[j]) for j in range(2))+translation[k] for k in range(2)) for v in vertices];return p if area(p)>0 else p[::-1]
def contains(p,r):
    corners=[(Q(x,1000)+sx*PAD,Q(y,1000)+sy*PAD) for x,sx in [(r[0],-1),(r[2],1)] for y,sy in [(r[1],-1),(r[3],1)]]
    return all(det((b[0]-a[0],b[1]-a[1]),(v[0]-a[0],v[1]-a[1]))>0 for a,b in zip(p,p[1:]+p[:1]) for v in corners)
def axis(cuts):return [v for i,x in enumerate(cuts) for v in ([2*x,x+cuts[i+1]] if i+1<len(cuts) else [2*x])]
def counts(xx,yy,rects):
    d=np.zeros((len(yy)+1,len(xx)+1),dtype=np.int32)
    for a,b,c,e in rects:
        i,j=bisect_right(xx,2*a),bisect_left(xx,2*c);k,l=bisect_right(yy,2*b),bisect_left(yy,2*e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
    return np.cumsum(np.cumsum(d,0,dtype=np.int32),1,dtype=np.int32)[:-1,:-1]
def union_area(rects):
    if not rects:return 0
    xs=sorted({r[k] for r in rects for k in [0,2]});ys=sorted({r[k] for r in rects for k in [1,3]});d=np.zeros((len(ys),len(xs)),dtype=np.int32)
    for a,b,c,e in rects:
        i,j=bisect_left(xs,a),bisect_left(xs,c);k,l=bisect_left(ys,b),bisect_left(ys,e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
    covered=np.cumsum(np.cumsum(d,0),1)[:-1,:-1]>0;return int(np.sum(covered*np.diff(ys)[:,None]*np.diff(xs)[None,:],dtype=np.int64))
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');prepared=load(BASE/'checks.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),JOB,SOURCE/'fixed27-source.json',SOURCE/'turned-2/roof-source.json',SOURCE/'turned-2/sites.json',SOURCE/'cog-derivation.json',SOURCE/'audit/checks.json',BRACKET/'audit/plan.json']+[p for p in BASE.iterdir() if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
# Reconcile the independently audited bracket proof's complete input snapshot.
for p,h in load(BRACKET/'audit/plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
write(OUT/'plan.json',{'inputs':bindings,'method':'Read actual source polygons, exactly certify every reused inner obstacle rectangle, reconstruct all original insert orientations and physical stock domains. Accumulate open forbidden rectangles with signed corner events per cog/frame bit and prefix counts, comparing every continuous class with saved masks. Verify exact retained label coverage, independently recompute all insert/bracket/coupled rectangle unions using a two-dimensional interval count grid, and apply independently bounded original filled areas to all twelve fixed cases. Original holes are retained, not nesting space. No source placements, optimizer or sufficient-domain claim.','process_cap_seconds':30,'retry_permitted':False})
assert load(SOURCE/'audit/checks.json')['passed'] and load(BRACKET/'audit/checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};part=parts['insert'];assert not part['allow_mirror'] and part['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]};assert area([tuple(map(Q,v)) for v in part['geometry'][0]['outer']])==19800
recipe=load(SOURCE/'source-recipe.json');stock=list(map(Q,recipe['source_stocks']['sheet-0']));fixed=load(SOURCE/'fixed27-source.json')+load(SOURCE/'turned-2/roof-source.json');frames={(r['part_id'],r['copy_index']):r for r in fixed if r['sheet_id']=='sheet-0'};assert len(frames)==18;sites=load(SOURCE/'turned-2/sites.json');assert len(sites)==16;deriv=load(SOURCE/'cog-derivation.json');theta=deriv['rotation_radians'];c,s=math.cos(theta),math.sin(theta);cx,cy=deriv['source_center'];shapes={}
for identity,row in frames.items():shapes[('frame',identity)]=[posed(parts['frame']['geometry'][0]['outer'],row['transform'])]
for site in sites:
    t={'rotation_radians':theta,'mirrored':False,'translation':[site['center'][0]-(cx*c-cy*s),site['center'][1]-(cx*s+cy*c)]};shapes[('cog',site['site'])]=[posed(p,t) for p in deriv['convex_pieces']]
sources=load(BRACKET/'turned-2/source-inner-rectangles.json')
for r in sources:
    if r['kind']=='frame':assert r['site_bit']==16;key=('frame',tuple(r['identity']))
    else:assert r['kind']=='cog' and 0<=r['site_bit']<16;key=('cog',r['site_bit'])
    polygon=shapes[key][r['piece']];assert all(abs(v)<4096 for point in polygon for v in point) and contains(polygon,r['bounds_um'])
assert {r['site_bit'] for r in sources}==set(range(17));rounding=Q(64*8192,2**53-64);assert rounding<PAD
fixture=counts([0,1,2,3,4],[0,1,2,3,4],[(0,0,2,2)]);assert fixture.tolist()==[[0,0,0,0,0],[0,1,1,1,0],[0,1,1,1,0],[0,1,1,1,0],[0,0,0,0,0]];assert union_area([[0,0,2,2],[1,1,3,3]])==7
geometries=load(BASE/'geometries.json');assert len(geometries)==4;seen=set();maxdet=Q(0);records=[];covers={}
for g in geometries:
    mode=g['mode'];pose=g['pose'];assert not pose['mirrored'];seen.add(pose['rotation_radians']);c,s=Q(math.cos(pose['rotation_radians'])),Q(math.sin(pose['rotation_radians']));maxdet=max(maxdet,abs(c*c+s*s-1));outer=posed(part['geometry'][0]['outer'],pose);assert str(area(outer))==g['source_area_mm2'] and contains(outer,g['inner_component_um']);lo=[min(v[k] for v in outer) for k in range(2)];hi=[max(v[k] for v in outer) for k in range(2)];domain=[stock[0]-lo[0]-PAD,stock[1]-lo[1]-PAD,stock[2]-hi[0]+PAD,stock[3]-hi[1]+PAD];domain=[math.floor(v*1000) if k<2 else math.ceil(v*1000) for k,v in enumerate(domain)];assert domain==g['stock_center_domain_um'];assert g['outer_bounds_um']==[math.floor(v*1000)-1 if k<2 else math.ceil(v*1000)+1 for k,v in enumerate(lo+hi)]
    data=load(BASE/f'mode-{mode:02d}.json');assert data['geometry']==g;expected=[];aa,bb,cc,ee=g['inner_component_um']
    for si,r in enumerate(sources):
        u,v,w,z=r['bounds_um'];q=[u-cc,v-ee,w-aa,z-bb]
        if q[0]<domain[2] and q[2]>domain[0] and q[1]<domain[3] and q[3]>domain[1]:expected.append({'source':si,'bit':r['site_bit'],'bounds_um':q})
    assert expected==data['obstacles'];xs=sorted({domain[0],domain[2]}|{o['bounds_um'][j] for o in expected for j in [0,2] if domain[0]<=o['bounds_um'][j]<=domain[2]});ys=sorted({domain[1],domain[3]}|{o['bounds_um'][j] for o in expected for j in [1,3] if domain[1]<=o['bounds_um'][j]<=domain[3]});xx,yy=axis(xs),axis(ys);mask=np.zeros((len(yy),len(xx)),dtype=np.uint32)
    for bit in range(17):
        values=counts(xx,yy,[o['bounds_um'] for o in expected if o['bit']==bit]);assert values.min()>=0;mask|=(values>0).astype(np.uint32)<<bit
    with np.load(BASE/f'mode-{mode:02d}-classes.npz',allow_pickle=False) as saved:assert saved['xcuts_um'].tolist()==xs and saved['ycuts_um'].tolist()==ys and np.array_equal(saved['mask'],mask)
    legal=((mask&65536)==0)&((mask&(mask-1))==0);covered=np.zeros(mask.shape,dtype=np.bool_)
    for label,a,b,c,e,xa,ya,xb,yb in data['cover']:
        assert [a,b,c,e]==[xs[xa//2],ys[ya//2],xs[(xb+1)//2],ys[(yb+1)//2]];assert np.all(mask[ya:yb+1,xa:xb+1]==label) and np.all(legal[ya:yb+1,xa:xb+1]);covered[ya:yb+1,xa:xb+1]=True
    assert np.array_equal(covered,legal);covers[mode]=data['cover'];records.append({'mode':mode,'continuous_classes':int(mask.size),'retained_classes':int(legal.sum()),'cover_boxes':len(data['cover']),'all_masks_and_coverage_verified':True})
assert seen=={0,math.pi/2,math.pi,3*math.pi/2};insert_error=4*(2*4096*PAD+PAD*PAD)+19800*maxdet;assert 19800-insert_error>19799;assert load(BRACKET/'audit/checks.json')['bracket_area_error_bound_mm2']<1
cases=[r for r in load(BRACKET/'audit/capacity-results.json') if not r['fixed48_cannot_extend_to_full66']];assert [r['omitted_site'] for r in cases]==plan['remaining_omitted_sites'];results=[]
for case in cases:
    saved=load(BASE/(case['case']+'-capacity.json'));omitted=case['omitted_site'];allowed=1<<omitted;rects=[]
    for g in geometries:
        a,b,c,e=g['outer_bounds_um']
        for label,l,bot,r,top,*_ in covers[g['mode']]:
            if label&~allowed==0:rects.append([l+a,bot+b,r+c,top+e])
    rects=list(map(list,sorted(set(map(tuple,rects)))));assert rects==saved['insert_occupied_rectangles_um'];old=load(BRACKET/'turned-2'/(case['case']+'-capacity.json'));oldrects=old['occupied_cover_rectangles_um'];combined=list(map(list,sorted(set(map(tuple,oldrects))|set(map(tuple,rects)))));assert combined==saved['combined_occupied_rectangles_um'];ia,ba,ja=map(union_area,[rects,oldrects,combined]);assert ia==saved['insert_occupied_union_area_um2'] and ba==saved['bracket_occupied_union_area_um2']==old['occupied_cover_union_area_um2'] and ja==saved['coupled_occupied_union_area_um2'];capacity=ia//(19799*10**6);required=(6*39999+12*19799)*10**6;assert required//10**6==saved['coupled_required_area_lower_mm2']==477582;assert capacity==saved['provisional_insert_capacity'] and (capacity<12)==saved['provisional_insufficient_insert_area'] and (ja<required)==saved['provisional_insufficient_coupled_area'];assert load(SOURCE/'turned-2'/(case['case']+'-checks.json'))['valid']
    results.append({'case':case['case'],'omitted_site':omitted,'insert_capacity_upper':capacity,'bracket_capacity_upper':case['maximum_brackets_from_necessary_cover'],'coupled_area_upper_mm2':ja/1e6,'required_area_lower_mm2':477582,'area_shortfall_mm2':(required-ja)/1e6,'individual_insert_bound_excludes':capacity<12,'coupled_area_bound_excludes':ja<required,'exact_fixed48_cannot_extend_to_full66':capacity<12 or ja<required,'whole_orientation_class_excluded':False,'whole_allocation_excluded':False})
excluded=sum(r['exact_fixed48_cannot_extend_to_full66'] for r in results);assert excluded==prepared['provisional_excluded_cases']==12;assert all(r['insert_capacity_upper']>=12 and r['bracket_capacity_upper']>=6 for r in results);total=sum(r['continuous_classes'] for r in records);assert total==prepared['continuous_classes'];process=load(ROOT/'output/h5-roof-coupled-covers-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'class-controls.json',records);write(OUT/'capacity-results.json',results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source_inner_rectangles_verified':len(sources),'insert_modes_verified':4,'continuous_classes_verified':total,'fixed48_cases':12,'individual_insert_exclusions':0,'coupled_area_exclusions':excluded,'largest_occupied_area_upper_mm2':max(r['coupled_area_upper_mm2'] for r in results),'smallest_area_shortfall_mm2':min(r['area_shortfall_mm2'] for r in results),'required_area_lower_mm2':477582,'complete_preparation_seconds_if_consumed':charge,'insert_area_error_bound_mm2':float(insert_error),'new_three_pattern_cases_total':33,'three_turned_cases_source_invalid':16,'earlier_bracket_proof_exclusions':5,'remaining_new_fixed48_cases':0,'whole_orientation_classes_excluded':0,'whole_allocations_excluded':0,'earlier_arrangements_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
