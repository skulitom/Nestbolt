from pathlib import Path
root=Path(__file__).resolve().parents[1];old='h5-orientation-roof-capacity-20261107';new='h5-coupled-roof-bound-and-cog-transfer-20261107'
for source,target in [('verify_h5_orientation_checkpoint_20261107.py','verify_h5_coupled_roof_checkpoint_20261107.py'),('verify_h5_orientation_staged_20261107.py','verify_h5_coupled_roof_staged_20261107.py')]:
    s=(root/'output'/source).read_text(encoding='utf-8').replace(old,new).replace('h5-orientation-staged-checks-20261107','h5-coupled-roof-staged-checks-20261107')
    with (root/'output'/target).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(root/'output/push_h5_six_unturned_checkpoint_20261107.py').read_text(encoding='utf-8').replace('h5-six-unturned-main-sync-20261107','h5-coupled-roof-main-sync-20261107').replace('a45826d315434c357fa855da0be08162eabf94f3','be9c79d648839c0e0c93598d45442b4f7252eb32').replace('42402787576','42405388174').replace("prefixes=('benchmarks/results/h5-six-unturned-frame-construction-20261107',)","prefixes=('benchmarks/results/h5-coupled-roof-bound-and-cog-transfer-20261107',)")
s=s.replace("OUT.mkdir();write(OUT/'prior-main-ci.json',ci)","assert json.loads((ROOT/'benchmarks/results/h5-coupled-roof-bound-and-cog-transfer-20261107/archive-checks.json').read_bytes())['passed']\nOUT.mkdir();write(OUT/'prior-main-ci.json',ci)")
with (root/'output/push_h5_coupled_roof_checkpoint_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
