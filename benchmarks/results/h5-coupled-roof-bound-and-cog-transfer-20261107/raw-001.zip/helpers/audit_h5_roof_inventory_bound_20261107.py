"""Independent bound releasing every bracket and insert on both sheets."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
from bisect import bisect_left
from statistics import median
import json,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-roof-inventory-bound-20261107';OUT=BASE/'audit';INSERT=ROOT/'output/h5-roof-coupled-covers-20261107';BRACKET=ROOT/'output/h5-orientation-roof-covers-20261107';SOURCE=ROOT/'output/h5-orientation-roofs-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';BENCH=ROOT/'benchmarks/results/h5-source-frontier-pilot-20261018/results.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def union_area(rects):
    if not rects:return 0
    xs=sorted({r[k] for r in rects for k in [0,2]});ys=sorted({r[k] for r in rects for k in [1,3]});d=np.zeros((len(ys),len(xs)),dtype=np.int32)
    for a,b,c,e in rects:
        i,j=bisect_left(xs,a),bisect_left(xs,c);k,l=bisect_left(ys,b),bisect_left(ys,e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
    covered=np.cumsum(np.cumsum(d,0),1)[:-1,:-1]>0;return int(np.sum(covered*np.diff(ys)[:,None]*np.diff(xs)[None,:],dtype=np.int64))
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BENCH,INSERT/'audit/plan.json',BRACKET/'audit/plan.json']+[p for p in BASE.iterdir() if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
for path in [INSERT/'audit/plan.json',BRACKET/'audit/plan.json']:
    for p,h in load(path)['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently derive the unchanged material target from the frozen normal seeds. Check actual single-stock source and material implementation: only one trailing offcut is subtracted. At least two gross sheets remain charged with three or more sheets; two sheets require one used-height prefix below the target-derived short height. Verify an exact original fixed frame already exceeds that height, so the other sheet must be short. Relax its usable bounds outward on integer micrometres and use its entire area. Reconstruct every case\'s combined first-sheet cover from audited mode/mask records and independently compute all unions with a signed two-dimensional count grid. Apply lower occupied source areas of all12 brackets and21 inserts, independent of their split, and retain original fixed33 identities. No code or solver change.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};assert job['units']=='mm' and len(job['stocks'])==1;stock=job['stocks'][0];assert stock['outline']==stock['defects']==[] and stock['width']==1500 and stock['height']==3000
normal=[r for r in load(BENCH)['records'] if r['job']==job['name'] and r['kerf_mm']==.2 and r['arm']=='normal'];assert len(normal)==3 and {r['seed'] for r in normal}=={0,1,2} and all(r['status']=='valid' for r in normal);target=Q(median(r['metrics']['material_area'] for r in normal)*1.01);gross=Q(stock['width'])*Q(stock['height']);assert 2*gross>target;limit=(target-gross)/Q(stock['width']);saved=load(BASE/'stock-and-inventory.json');assert Q(saved['target_material_area_mm2'])==target and Q(saved['short_used_height_limit_mm'])==limit
# The metric's one-offcut semantics and its ordering control are bound, not changed.
code=(ROOT/'crates/validator/src/job.rs').read_text(encoding='utf-8');fixture=(ROOT/'crates/validator/tests/job.rs').read_text(encoding='utf-8')
assert 'full_area += geometry.area();' in code and 'if last.is_none() || saving > offcut {' in code and 'offcut = saving;' in code and 'let material_area = (full_area - offcut).max(0.0);' in code
assert 'fn equal_stock_metric_matches_the_plan_formula()' in fixture and 'layout.sheets.reverse();' in fixture and 'assert_eq!(m.material_area, 11000.0);' in fixture
m=stock['margins'];edge=job['edge_clearance'];exact=[Q(m['left'])+Q(edge),Q(m['bottom'])+Q(edge),Q(stock['width'])-Q(m['right'])-Q(edge),limit-Q(m['top'])-Q(edge)];short=saved['short_usable_outward_rectangle_um'];assert Q(short[0],1000)<exact[0] and Q(short[1],1000)<exact[1] and Q(short[2],1000)>exact[2] and Q(short[3],1000)>exact[3];shortarea=(short[2]-short[0])*(short[3]-short[1]);assert shortarea==saved['short_area_upper_um2']
ia=load(INSERT/'audit/checks.json');ba=load(BRACKET/'audit/checks.json');assert ia['passed'] and ba['passed'] and ia['insert_area_error_bound_mm2']<1 and ba['bracket_area_error_bound_mm2']<1
def signed_area(v):return sum(Q(a[0])*Q(b[1])-Q(a[1])*Q(b[0]) for a,b in zip(v,v[1:]+v[:1]))/2
assert signed_area(parts['bracket']['geometry'][0]['outer'])==40000 and signed_area(parts['insert']['geometry'][0]['outer'])==19800;assert parts['bracket']['quantity']==12 and parts['insert']['quantity']==21;required=(12*39999+21*19799)*10**6;assert required==saved['whole_remaining_inventory_area_lower_mm2']*10**6
geometries=load(INSERT/'geometries.json');results=[]
for omitted in range(16):
    case=f'omit-{omitted:02d}';data=load(BASE/(case+'.json'));original=load(SOURCE/'turned-2'/(case+'-source.json'));core=[r for r in original if r['sheet_id']=='sheet-0'];assert core==data['fixed_first33'];assert len(core)==len({(r['part_id'],r['copy_index']) for r in core})==33
    assert {r['copy_index'] for r in core if r['part_id']=='frame'}==set(range(18)) and {r['copy_index'] for r in core if r['part_id']=='cog'}==set(range(15));assert not any(r['part_id'] in ['bracket','insert'] for r in core);assert load(SOURCE/'turned-2'/(case+'-checks.json'))['valid']
    frame=next(r for r in core if r['part_id']=='frame');t=frame['transform'];c,s=Q(math.cos(t['rotation_radians'])),Q(math.sin(t['rotation_radians']));top=max(Q(x)*s+Q(y)*c+Q(t['translation'][1]) for x,y in parts['frame']['geometry'][0]['outer']);assert top-Q(1,10**6)>limit
    rects=[]
    for g in geometries:
        a,b,c,e=g['outer_bounds_um']
        for label,l,bot,r,high,*_ in load(INSERT/f"mode-{g['mode']:02d}.json")['cover']:
            if label&~(1<<omitted)==0:rects.append([l+a,bot+b,r+c,high+e])
    rects+=load(BRACKET/'turned-2'/(case+'-capacity.json'))['occupied_cover_rectangles_um'];rects=list(map(list,sorted(set(map(tuple,rects)))));assert rects==data['first_sheet_union_rectangles_um'];first=union_area(rects);upper=first+shortarea;shortfall=required-upper;assert first==data['first_sheet_area_upper_um2'] and upper==data['both_sheets_area_upper_um2'] and required==data['remaining_inventory_area_lower_um2'];assert shortfall>0 and data['provisional_excluded_for_every_bracket_insert_split'];assert abs(shortfall/1e6-data['area_shortfall_mm2'])<1e-9
    results.append({'case':case,'first_sheet_area_upper_mm2':first/1e6,'short_sheet_area_upper_mm2':shortarea/1e6,'required_inventory_area_lower_mm2':required//10**6,'area_shortfall_mm2':shortfall/1e6,'fixed_first33_impossible_with_any_bracket_insert_split':True,'whole_orientation_class_excluded':False,'whole_allocation_excluded':False})
process=load(ROOT/'output/h5-roof-inventory-bound-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'capacity-results.json',results);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'fixed_first33_cores_verified':16,'original_remaining_brackets':12,'original_remaining_inserts':21,'source_material_target_mm2':float(target),'short_sheet_area_upper_mm2':shortarea/1e6,'largest_first_sheet_area_upper_mm2':max(r['first_sheet_area_upper_mm2'] for r in results),'smallest_area_shortfall_mm2':min(r['area_shortfall_mm2'] for r in results),'fixed_first33_cores_excluded_for_every_bracket_insert_split':16,'complete_preparation_seconds_if_consumed':charge,'single_sheet_case_excluded':True,'at_least_three_sheets_exceed_material_target':True,'whole_orientation_classes_excluded':0,'whole_allocations_excluded':0,'earlier_arrangements_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
