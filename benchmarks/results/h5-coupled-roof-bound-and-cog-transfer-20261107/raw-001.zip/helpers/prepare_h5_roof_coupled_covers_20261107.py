"""New insert covers and coupled occupied-area bounds for twelve fixed cores."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json,math,time,os
import numpy as np
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-roof-coupled-covers-20261107';SOURCE=ROOT/'output/h5-orientation-roofs-20261107';BRACKET=ROOT/'output/h5-orientation-roof-covers-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PAD=F(1,10**6)
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(p):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1]))/2
def transform(p,t):
    c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));tx,ty=map(F,t['translation']);return [(F(x)*c-F(y)*s+tx,F(x)*s+F(y)*c+ty) for x,y in p]
def inner(p):
    bb=[min(v[0] for v in p),min(v[1] for v in p),max(v[0] for v in p),max(v[1] for v in p)];r=[math.ceil((v+2*PAD)*1000) if k<2 else math.floor((v-2*PAD)*1000) for k,v in enumerate(bb)];corners=product([F(r[0],1000)-PAD,F(r[2],1000)+PAD],[F(r[1],1000)-PAD,F(r[3],1000)+PAD]);corners=list(corners)
    assert all(cross(a,b,v)>0 for a,b in zip(p,p[1:]+p[:1]) for v in corners);return r
def axis(cuts):
    xx=np.empty(2*len(cuts)-1,dtype=np.int64);xx[::2]=2*cuts;xx[1::2]=cuts[:-1]+cuts[1:];return xx
def union_area(rects):
    xs=sorted({r[k] for r in rects for k in [0,2]});total=0
    for a,b in zip(xs,xs[1:]):
        intervals=sorted((r[1],r[3]) for r in rects if r[0]<b and a<r[2]);length=0;hi=None
        for lo,end in intervals:
            if hi is None or lo>hi:length+=end-lo;hi=end
            elif end>hi:length+=end-hi;hi=end
        total+=(b-a)*length
    return total
def deadline():assert time.perf_counter()-began<18,'Declared preparation cap reached; no exclusion certified.'
OUT.mkdir();began=time.perf_counter();assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
prior=load(BRACKET/'audit/checks.json');assert prior['passed'];cases=[r for r in load(BRACKET/'audit/capacity-results.json') if not r['fixed48_cannot_extend_to_full66']];assert len(cases)==12 and all(r['turned_frames']==2 for r in cases)
sources_path=BRACKET/'turned-2/source-inner-rectangles.json';inputs=[Path(__file__),JOB,SOURCE/'source-recipe.json',SOURCE/'audit/checks.json',sources_path,BRACKET/'audit/checks.json',BRACKET/'audit/capacity-results.json',ROOT/'output/h5_checked_affinity_20261107.py']+[BRACKET/'turned-2'/(r['case']+'-capacity.json') for r in cases]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each of the twelve remaining exact two-turned-frame cores, keep the audited fixed frames and fifteen chosen cog sites. Reuse their source-contained inner rectangles, derive the four legal original insert modes and full-stock center domains, then exhaustively classify every continuous axis point/interval combination with open forbidden rectangles. Retain masks with no frame bit and at most one omitted cog bit. Outward occupied rectangles cover every possible insert footprint. Combine each case\'s insert rectangles and previously audited bracket rectangles. Exact union area bounds all six brackets and twelve inserts because the full original filled outlines must be disjoint. Independently verify source containment, masks, cover completeness, individual and coupled area limits before exclusions. No source poses, model or optimizer is created.','remaining_omitted_sites':[r['omitted_site'] for r in cases],'insert_modes':4,'inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'preparation_internal_cap_seconds':18,'process_cap_seconds':20,'memory_bytes':2**31,'maximum_classes_per_mode':40000000,'bracket_area_lower_mm2':39999,'insert_area_lower_mm2':19799,'required_brackets':6,'required_inserts':12,'coupled_required_area_lower_mm2':6*39999+12*19799,'optimizer_calls':0,'retry_permitted':False})
job=load(JOB);part=next(p for p in job['parts'] if p['id']=='insert');assert not part['allow_mirror'] and part['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]};original=part['geometry'][0]['outer'];assert area(original)==19800;center=[float((min(F(v[k]) for v in original)+max(F(v[k]) for v in original))/2) for k in range(2)];stock=list(map(F,load(SOURCE/'source-recipe.json')['source_stocks']['sheet-0']));sources=load(sources_path);geometries=[];covers={};records=[]
for deg in part['rotations']['degrees']:
    a=math.radians(deg);c,s=math.cos(a),math.sin(a);cx,cy=center;pose={'rotation_radians':a,'mirrored':False,'translation':[-(cx*c-cy*s),-(cx*s+cy*c)]};outer=transform(original,pose);assert area(outer)>19799;lo=[min(v[k] for v in outer) for k in range(2)];hi=[max(v[k] for v in outer) for k in range(2)];domain=[stock[0]-lo[0]-PAD,stock[1]-lo[1]-PAD,stock[2]-hi[0]+PAD,stock[3]-hi[1]+PAD];domain=[math.floor(v*1000) if k<2 else math.ceil(v*1000) for k,v in enumerate(domain)];bounds=[math.floor(v*1000)-1 if k<2 else math.ceil(v*1000)+1 for k,v in enumerate(lo+hi)];g={'mode':len(geometries),'pose':pose,'inner_component_um':inner(outer),'stock_center_domain_um':domain,'outer_bounds_um':bounds,'source_area_mm2':str(area(outer))};geometries.append(g)
    mode=g['mode'];d=domain;aa,bb,cc,ee=g['inner_component_um'];obstacles=[]
    for si,source in enumerate(sources):
        u,v,w,z=source['bounds_um'];q=[u-cc,v-ee,w-aa,z-bb]
        if q[0]<d[2] and q[2]>d[0] and q[1]<d[3] and q[3]>d[1]:obstacles.append({'source':si,'bit':source['site_bit'],'bounds_um':q})
    xs=np.array(sorted({d[0],d[2]}|{o['bounds_um'][i] for o in obstacles for i in [0,2] if d[0]<=o['bounds_um'][i]<=d[2]}),dtype=np.int64);ys=np.array(sorted({d[1],d[3]}|{o['bounds_um'][i] for o in obstacles for i in [1,3] if d[1]<=o['bounds_um'][i]<=d[3]}),dtype=np.int64);xx,yy=axis(xs),axis(ys);assert len(xx)*len(yy)<=40000000;mask=np.zeros((len(yy),len(xx)),dtype=np.uint32)
    for o in obstacles:
        a,b,c,e=o['bounds_um'];xa=int(np.searchsorted(xx,2*a,side='right'));xb=int(np.searchsorted(xx,2*c,side='left'));ya=int(np.searchsorted(yy,2*b,side='right'));yb=int(np.searchsorted(yy,2*e,side='left'));mask[ya:yb,xa:xb]|=np.uint32(1<<o['bit'])
    np.savez_compressed(OUT/f'mode-{mode:02d}-classes.npz',xcuts_um=xs,ycuts_um=ys,mask=mask);boxes=[];active={}
    def close(key,span):
        m,xa,xb=key;ya,yb=span;boxes.append([m,int(xs[xa//2]),int(ys[ya//2]),int(xs[(xb+1)//2]),int(ys[(yb+1)//2]),xa,ya,xb,yb])
    for yi,row in enumerate(mask):
        legal=((row&65536)==0)&((row&(row-1))==0);labels=np.where(legal,row,np.uint32(131071));starts=np.r_[0,np.flatnonzero(labels[1:]!=labels[:-1])+1];ends=np.r_[starts[1:]-1,len(labels)-1];current={}
        for xa,xb in zip(starts.tolist(),ends.tolist()):
            label=int(labels[xa])
            if label==131071:continue
            key=(label,xa,xb);current[key]=[active[key][0] if key in active else yi,yi]
        for key,span in active.items():
            if key not in current:close(key,span)
        active=current
    for key,span in active.items():close(key,span)
    boxes.sort();covers[mode]=boxes;write(OUT/f'mode-{mode:02d}.json',{'geometry':g,'obstacles':obstacles,'cover':boxes});records.append({'mode':mode,'classes':int(mask.size),'cover_boxes':len(boxes),'retained_classes':sum((r[7]-r[5]+1)*(r[8]-r[6]+1) for r in boxes)});deadline()
results=[]
for case in cases:
    omitted=case['omitted_site'];allowed=1<<omitted;rects=[]
    for g in geometries:
        a,b,c,e=g['outer_bounds_um']
        for r in covers[g['mode']]:
            if r[0]&~allowed==0:rects.append([r[1]+a,r[2]+b,r[3]+c,r[4]+e])
    rects=sorted(set(map(tuple,rects)));bracket=load(BRACKET/'turned-2'/(case['case']+'-capacity.json'));oldrects=bracket['occupied_cover_rectangles_um'];oldarea=union_area(oldrects);assert oldarea==bracket['occupied_cover_union_area_um2'];insertarea=union_area(rects);jointrects=sorted(set(map(tuple,oldrects))|set(rects));jointarea=union_area(jointrects);requiredarea=(6*39999+12*19799)*10**6;capacity=insertarea//(19799*10**6)
    record={'case':case['case'],'omitted_site':omitted,'insert_occupied_rectangles_um':rects,'combined_occupied_rectangles_um':jointrects,'insert_occupied_union_area_um2':insertarea,'bracket_occupied_union_area_um2':oldarea,'coupled_occupied_union_area_um2':jointarea,'insert_occupied_union_area_mm2':insertarea/1e6,'coupled_occupied_union_area_mm2':jointarea/1e6,'provisional_insert_capacity':capacity,'required_inserts':12,'coupled_required_area_lower_mm2':requiredarea//10**6,'provisional_insufficient_insert_area':capacity<12,'provisional_insufficient_coupled_area':jointarea<requiredarea,'independent_audit_pending':True,'fixed_core_excluded':False};write(OUT/(case['case']+'-capacity.json'),record);results.append({k:v for k,v in record.items() if 'rectangles' not in k});deadline()
write(OUT/'geometries.json',geometries);write(OUT/'mode-summary.json',records);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'continuous_classes':sum(r['classes'] for r in records),'insert_modes':4,'cases':results,'provisional_excluded_cases':sum(r['provisional_insufficient_insert_area'] or r['provisional_insufficient_coupled_area'] for r in results),'independent_audit_pending':True,'fixed_cores_excluded':0,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print({k:v for k,v in load(OUT/'checks.json').items() if k!='cases'})
