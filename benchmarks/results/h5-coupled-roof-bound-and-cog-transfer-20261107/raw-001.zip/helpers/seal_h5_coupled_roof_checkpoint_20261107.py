"""Archive coupled source-area exclusions and a changed cog allocation."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-coupled-roof-bound-and-cog-transfer-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-roof-one-short-cog-20261107';F=BASE/'audit';D=ROOT/'output/h5-roof-coupled-covers-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-orientation-roof-capacity-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['source44_valid_cases']==120 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-roof-inventory-bound-20261107',ROOT/'output/h5-orientation-main-sync-20261107']+[ROOT/'output'/('h5-roof-'+n+'-process-20261107') for n in ['coupled-covers','coupled-covers-audit','inventory-bound','inventory-bound-audit','one-short-cog','one-short-cog-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5_roof_coupled*20261107.py','*h5_roof_inventory*20261107.py','*h5_roof_one_short*20261107.py','*h5_coupled_roof*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_coupled_roof_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
BOUND=ROOT/'output/h5-roof-inventory-bound-20261107'
copies=[(D/'plan.json','coupled-cover-plan.json'),(D/'audit/checks.json','coupled-cover-audit.json'),(D/'audit/capacity-results.json','coupled-capacities.json'),(D/'audit/class-controls.json','insert-class-controls.json'),(BOUND/'plan.json','inventory-independent-plan.json'),(BOUND/'stock-and-inventory.json','stock-and-inventory.json'),(BOUND/'audit/checks.json','inventory-independent-audit.json'),(BOUND/'audit/capacity-results.json','all-inventory-capacities.json'),(BASE/'plan.json','cog-transfer-plan.json'),(BASE/'allocation-readback.json','allocation-readback.json'),(BASE/'short12-source.json','short12-source.json'),(BASE/'short12-checks.json','short12-checks.json'),(F/'checks.json','source44-audit.json'),(BASE/'cases.json','source44-cases.json'),(BASE/'remaining-identities.json','remaining-identities.json'),(ROOT/'output/h5-orientation-main-sync-20261107/receipt.json','main-push-receipt.json')]
for n in ['coupled-covers','coupled-covers-audit','inventory-bound','inventory-bound-audit','one-short-cog','one-short-cog-audit']:copies.append((ROOT/'output'/('h5-roof-'+n+'-process-20261107')/'process.json',n+'-process.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime);ci=json.loads(subprocess.check_output(['gh','run','view','42405388174','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='be9c79d648839c0e0c93598d45442b4f7252eb32';write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
coupled=load(D/'audit/checks.json');inventory=load(BOUND/'audit/checks.json');write(OUT/'checks.json',{**front,**archive,'passed':True,'old_fixed48_coupled_exclusions':12,'old_fixed_first33_any_inventory_exclusions':16,'whole_orientation_classes_excluded':0,'whole_allocations_excluded':0,'historical_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime)})
write(OUT/'next-step.json',{'status':'old_cores_excluded_new_source44_cases_ready','next':'For all120 source-valid44 cases, extract necessary bracket and insert center covers from the already audited full bit-mask matrices, now allowing two empty cog sites. Keep every boundary point/interval class. First-sheet remaining inventory is six brackets and sixteen inserts; verify individual and combined occupied-area bounds, with conservative required area556778mm2. Independently check the selected masks, complete covers and exact areas before excluding any new case. Only a surviving case warrants a complete source-derived companion model/initializer and a frozen bounded solver.','mask_inputs':['output/h5-orientation-roof-covers-20261107/turned-2/mode-00..07-classes.npz','output/h5-roof-coupled-covers-20261107/mode-00..03-classes.npz'],'important':'The stored full masks were independently verified for all classes. The old retained covers permit only one empty site, so they are insufficient for the new two-empty-site problem. Extract new covers from complete matrices; do not reuse truncated covers or rerun old solvers. Cog bits remain site geometry identities, not source copy labels.','new_partial_cases':120,'new_partial_parts':44,'remaining_per_case':{'bracket':6,'insert':16},'inherited_preparation_seconds':front['complete_preparation_seconds_if_consumed'],'charge_all_new_preparation':True,'original_algorithm_seconds':60,'original_shared_seconds':90,'memory_bytes':2**31,'all_old_calls_remain_closed':True,'full66_valid':False,'whole_allocations_remaining':440,'earlier_arrangements_remaining':4,'optimizer_calls':0,'H5_complete':False})
report=f'''# Coupled roof bounds and cog transfer — 2026-11-07

**All twelve remaining fixed 48-part layouts are excluded** by an independent
combined bracket/insert area proof. A stronger bound then excludes all sixteen
two-turned-frame first-sheet cores **for every bracket/insert split between
sheets**. These are exact fixed-core results; no whole orientation class or
whole-job allocation is excluded.

A changed source inventory moves one cog onto the short sheet and produces
**120 source-valid 44-part partial layouts**. Each still lacks six brackets and
sixteen inserts. No optimizer runs, no complete 66-part layout is established,
and the preserved valid 64-part result remains best. H2/H5 stay open at
**60% completed milestone weight**.

[The new insert covers]({NAME}/coupled-cover-plan.json) use all four legal
original orientations over the entire physical first stock. Source-contained
inner obstacles and open forbidden-center rectangles preserve every boundary
point and intervening interval. [Independent proof readback]({NAME}/coupled-cover-audit.json)
verifies **1,250 reused source rectangles and 4,115,344 continuous classes**,
using signed corner counts instead of producer slice assignment. Every retained
label and covering rectangle is checked. Exact union areas are independently
recomputed using a two-dimensional count grid.

Individually, each case's bracket bound admits at least six and its insert bound
at least twelve. Their combined occupied cover is nevertheless too small for
all eighteen originals. Conservative lower areas of 39,999 mm² per bracket and
19,799 mm² per insert require **477,582 mm²**. The largest combined upper bound
is **426,333.180631 mm²**, leaving at least **51,248.819369 mm²** missing.
[All twelve bounds]({NAME}/coupled-capacities.json) are preserved. Together with
the earlier five bracket exclusions and sixteen invalid three-turned cases,
all 33 declared patterns from the preceding checkpoint are closed.

[The broader inventory proof]({NAME}/inventory-independent-plan.json) releases
every bracket and insert on both sheets, retaining only the exact eighteen
frames and fifteen cogs on the first sheet. All twelve brackets and twenty-one
inserts require at least **895,767 mm²**. The full outward-relaxed short usable
rectangle contributes at most **465,326.048858 mm²**, regardless of its contents.
Adding the first-sheet occupied cover still leaves at least **4,107.770511 mm²**
missing in every one of the sixteen fixed cores.

[Independent readback]({NAME}/inventory-independent-audit.json) recomputes the
normal-seed target and exact rectangle unions. It binds the current material
implementation and ordering test: gross sheet areas are charged with only one
trailing offcut subtracted. Three sheets exceed the target. A fixed first-sheet
frame already exceeds the allowed short height, so any second sheet must be
the short one. One sheet also fails the first-sheet area bound. The
[sixteen results]({NAME}/all-inventory-capacities.json) therefore cover arbitrary
bracket/insert counts and placements on these fixed cores. Moving a frame or
cog, or transferring a cog to the short sheet, changes the problem and remains
outside this exclusion.

[The changed allocation]({NAME}/allocation-readback.json) is a survivor in the
audited 4,576-row / 440-survivor ledger: short counts **6 brackets, 5 inserts,
1 cog**; first-sheet counts **18 frames, 6 brackets, 16 inserts, 14 cogs**.
This is not a claim that the allocation was globally untested. The new
[source constructor]({NAME}/cog-transfer-plan.json) retains three source-sized
two-L-plus-insert modules. One cog and two stacked horizontal inserts replace
the six right-hand inserts. [The short twelve-part layout]({NAME}/short12-source.json)
passes [source checks]({NAME}/short12-checks.json), with minimum gap **0.230000 mm**.

The audited two-turned frame pattern and sixteen cog sites now supply every
fourteen-of-sixteen choice: **120 exact partial layouts**. [Independent
readback]({NAME}/source44-audit.json) verifies all 120, **67,440 same-sheet pairs**,
**6,720 original holes across cases**, and all identities. A separate direct
segment calculation checks all 66 short-sheet pairs and 48 stock edges.
Original cog 14 is on the short sheet; cogs 0–13 bind to occupied first-sheet
sites. [Six brackets and sixteen inserts]({NAME}/remaining-identities.json)
remain mandatory. The new partials are not packing-quality improvements.

| Complete stage | Preparation | Separate audit |
|---|---:|---:|
| Coupled insert/bracket covers | 0.629648 s | 4.309011 s |
| Inventory-independent fixed-core bound | 0.192242 s | 0.560377 s |
| One-cog transfer and 120 source partials | 4.098935 s | 4.862092 s |

With **12.186441 s** inherited preparation retained, the new source pipeline
carries **17.107266 s** before any future model or search. All six bounded
process stages close with zero active descendants under the 2 GiB cap and
unchanged CPU/thread controls. No old solver call is restarted or retimed.

[Next]({NAME}/next-step.json), extract complete necessary covers allowing two
empty cog sites from the already audited full mask matrices. The old retained
one-empty-site covers are insufficient. Independently verify the six-bracket /
sixteen-insert area screen before any complete companion model. Four earlier
arrangements and all 440 whole-job allocations remain unresolved. Full source,
native and material checks, product integration, surface parity and the original
H5 matrix are still required.

[Both preceding checkpoints reached main be9c79d6 normally]({NAME}/main-push-receipt.json)
after all six prior checks passed, with all 52 protected files intact. Its
[fresh CI snapshot]({NAME}/main-ci-at-review.json) has **{success} passed / {live} live jobs**.
This evidence checkpoint awaits the next ordinary main push. Product code,
README and releases are unchanged.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve all inputs and results.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 coupled roof bounds and cog transfer:** [independent proofs and source readback]({{link}}) exclude all twelve remaining fixed 48-part cases after 4,115,344 continuous insert classes. Their combined bracket/insert occupied area is short by at least 51,248.819369 mm². A broader proof releases all brackets and inserts across both sheets and excludes all sixteen exact first33 cores for every such inventory split, with at least 4,107.770511 mm² missing; no whole orientation class or allocation is excluded. A changed 6/5/1 short allocation transfers one cog and passes complete source checks. All 120 fourteen-of-sixteen first-sheet choices produce valid 44-part partials, independently checking 67,440 pairs and 6,720 original holes. Each still needs six brackets and sixteen inserts; no optimizer runs and the valid 64-part result remains best. Preparation retains 17.107266 s total and all bounded processes close. Next extract complete two-empty-site covers and audit the coupled area bound before any complete model. Four earlier arrangements and 440 allocations remain. H2/H5 stay open at 60%. Both preceding checkpoints reached main be9c79d6 after all six prior checks passed with 52 protected files intact; fresh CI has {success} passed / {live} live jobs. Product and release state is unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';text=p.read_text(encoding='utf-8');a=text.index('Latest H5 evidence:');b=text.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [coupled roof bounds and cog transfer](../benchmarks/results/{NAME}.md).
Independent insert covers and exact combined-area proofs exclude all twelve
remaining fixed 48-part cases. A stronger bound excludes all sixteen exact
first-sheet frame/cog cores for every bracket/insert split between sheets.
No whole orientation class or allocation is excluded. A changed short-sheet
allocation of six brackets, five inserts and one cog passes source checks.
All 120 choices of fourteen first-sheet cog sites give valid 44-part partials,
with 67,440 pairs and 6,720 original holes independently replayed. Each still
needs six brackets and sixteen inserts. No optimizer runs; the valid 64-part
result remains best. Preparation retains 17.107266 s and all processes close.
Next extract complete two-empty-site necessary covers and audit the coupled
area bound before any complete companion model. Four earlier arrangements
and 440 allocations remain. H2/H5 stay open at 60%. Both prior checkpoints
reached main be9c79d6 after all six checks passed, preserving 52 files. Fresh
CI has {success} passed / {live} live jobs. Product and releases are unchanged.
'''
p.write_text(text[:a]+intro+text[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings)})
