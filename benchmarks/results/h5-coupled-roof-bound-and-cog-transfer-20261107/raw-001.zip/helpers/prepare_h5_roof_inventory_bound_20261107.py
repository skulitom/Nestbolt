"""Remove the short-sheet bracket/insert inventory restriction for fixed cores."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,math,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-roof-coupled-covers-20261107';BRACKET=ROOT/'output/h5-orientation-roof-covers-20261107';SOURCE=ROOT/'output/h5-orientation-roofs-20261107';OUT=ROOT/'output/h5-roof-inventory-bound-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def union_area(rects):
    xs=sorted({r[k] for r in rects for k in [0,2]});total=0
    for a,b in zip(xs,xs[1:]):
        intervals=sorted((r[1],r[3]) for r in rects if r[0]<b and a<r[2]);length=0;hi=None
        for lo,end in intervals:
            if hi is None or lo>hi:length+=end-lo;hi=end
            elif end>hi:length+=end-hi;hi=end
        total+=(b-a)*length
    return total
OUT.mkdir();began=time.perf_counter();audit=load(BASE/'audit/checks.json');assert audit['passed'] and load(BRACKET/'audit/checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};target=load(SOURCE/'benchmark-target.json');assert len(job['stocks'])==1 and job['stocks'][0]['outline']==job['stocks'][0]['defects']==[] and job['units']=='mm'
inputs=[Path(__file__),JOB,SOURCE/'benchmark-target.json',SOURCE/'source-recipe.json',BASE/'audit/checks.json',BASE/'geometries.json',BRACKET/'audit/checks.json',ROOT/'crates/validator/src/job.rs',ROOT/'crates/validator/tests/job.rs']+[BASE/f'mode-{i:02d}.json' for i in range(4)]+[BRACKET/'turned-2'/f'omit-{i:02d}-capacity.json' for i in range(16)]+[SOURCE/'turned-2'/f'omit-{i:02d}-source.json' for i in range(16)]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Recombine the independently audited insert masks for all16 two-turned roof cores, including the four earlier bracket-excluded omissions. Release every bracket and insert on both sheets; keep only the exact eighteen frames and fifteen cogs on the first sheet. All12 brackets and21 inserts need at least895767mm2 occupied area. The entire outward-relaxed short usable rectangle is an upper bound regardless of which originals it contains. Add it to the first sheet\'s necessary bracket/insert occupied union. Compare that sum against the whole remaining inventory, without any assumption about short-sheet counts or layout. Source material code charges full gross areas minus only the largest single offcut. At the unchanged target, three sheets are impossible and any second sheet must be the short one because a fixed first-sheet frame already exceeds the allowed short height. This proves only those exact fixed first33 cores impossible under arbitrary bracket/insert splits; moving a frame/cog or transferring a cog is outside scope.','inherited_numeric_preparation_seconds':audit['complete_preparation_seconds_if_consumed'],'process_cap_seconds':10,'memory_bytes':2**31,'charge_entire_process_if_consumed':True,'optimizer_calls':0,'retry_permitted':False})
stock=job['stocks'][0];gross=F(stock['width'])*F(stock['height']);maximum=F(target['target_material_mm2']);assert 2*gross>maximum;short_height=(maximum-gross)/F(stock['width']);assert abs(float(short_height)-target['short_used_height_limit_mm'])<1e-10;physical=list(map(F,target['source_stocks']['sheet-1']));shortrect=[math.floor(v*1000)-1 if k<2 else math.ceil(v*1000)+1 for k,v in enumerate(physical)];shortarea=(shortrect[2]-shortrect[0])*(shortrect[3]-shortrect[1]);required=(parts['bracket']['quantity']*39999+parts['insert']['quantity']*19799)*10**6;assert required==895767*10**6
write(OUT/'stock-and-inventory.json',{'gross_stock_area_mm2':str(gross),'target_material_area_mm2':str(maximum),'two_full_sheets_exceed_target':True,'short_used_height_limit_mm':str(short_height),'short_usable_outward_rectangle_um':shortrect,'short_area_upper_um2':shortarea,'short_area_upper_mm2':shortarea/1e6,'remaining_original_counts':{'bracket':12,'insert':21},'whole_remaining_inventory_area_lower_mm2':required//10**6,'short_counts_restricted':False,'source_material_rule':'Sum gross stock areas minus the largest one trailing offcut; upward rounding of used height can only increase material use.'})
geometries=load(BASE/'geometries.json');covers={i:load(BASE/f'mode-{i:02d}.json')['cover'] for i in range(4)};results=[]
for omitted in range(16):
    case=f'omit-{omitted:02d}';rows=[r for r in load(SOURCE/'turned-2'/(case+'-source.json')) if r['sheet_id']=='sheet-0'];assert len(rows)==33 and sum(r['part_id']=='frame' for r in rows)==18 and sum(r['part_id']=='cog' for r in rows)==15
    frame=next(r for r in rows if r['part_id']=='frame');t=frame['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);frame_top=max(x*s+y*c+t['translation'][1] for x,y in parts['frame']['geometry'][0]['outer']);assert F(frame_top)-F('.000001')>short_height
    insert=[]
    for g in geometries:
        a,b,c,e=g['outer_bounds_um']
        for label,l,bot,r,top,*_ in covers[g['mode']]:
            if label&~(1<<omitted)==0:insert.append([l+a,bot+b,r+c,top+e])
    bracket=load(BRACKET/'turned-2'/(case+'-capacity.json'))['occupied_cover_rectangles_um'];rects=sorted(set(map(tuple,insert))|set(map(tuple,bracket)));firstarea=union_area(rects);upper=firstarea+shortarea;shortfall=required-upper
    record={'case':case,'omitted_site':omitted,'fixed_first33':rows,'first_sheet_union_rectangles_um':rects,'first_sheet_area_upper_um2':firstarea,'short_sheet_area_upper_um2':shortarea,'both_sheets_area_upper_um2':upper,'remaining_inventory_area_lower_um2':required,'area_shortfall_mm2':shortfall/1e6,'provisional_excluded_for_every_bracket_insert_split':shortfall>0,'independent_audit_pending':True,'whole_allocation_excluded':False};write(OUT/(case+'.json'),record);results.append({k:v for k,v in record.items() if k not in ['fixed_first33','first_sheet_union_rectangles_um']})
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':results,'provisional_fixed33_exclusions':sum(r['provisional_excluded_for_every_bracket_insert_split'] for r in results),'smallest_area_shortfall_mm2':min(r['area_shortfall_mm2'] for r in results),'independent_audit_pending':True,'fixed33_cores_excluded':0,'whole_allocations_excluded':0,'optimizer_calls':0,'H5_complete':False});print({k:v for k,v in load(OUT/'checks.json').items() if k!='cases'})
