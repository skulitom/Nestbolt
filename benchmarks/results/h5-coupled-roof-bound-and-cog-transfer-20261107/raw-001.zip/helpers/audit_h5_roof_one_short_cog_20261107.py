"""Independent source12/source44 and changed-inventory readback."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,time
import numpy as np
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-roof-one-short-cog-20261107';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-orientation-roofs-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def world(r):
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;return np.array(parts[r['part_id']]['geometry'][0]['outer'])@np.array([[m*c,m*s],[-s,c]])+t['translation']
def direct_gap(a,b):
    def one(p,q):
        d=np.roll(q,-1,axis=0)-q;v=p[:,None,:]-q[None,:,:];t=np.clip((v*d[None,:,:]).sum(2)/(d*d).sum(1)[None,:],0,1);v-=t[:,:,None]*d[None,:,:];return float(np.sqrt((v*v).sum(2).min()))
    return min(one(a,b),one(b,a))
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+[p for p in BASE.iterdir() if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconstruct the short-sheet changes from original dimensions, the audited radius/phase and source module positions. Check every short pair by independent matrix transforms and direct segment distances, plus all stock edges. Replay every complete original44part source check, all120 omitted-site combinations, every source identity/remaining identity and all original holes. Verify the changed inventory against the full440-survivor ledger and reconcile the inherited preparation charge. No full model or optimizer.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};recipe=load(SOURCE/'source-recipe.json');deriv=load(SOURCE/'cog-derivation.json');fixed=load(SOURCE/'fixed27-source.json');roof=load(SOURCE/'turned-2/roof-source.json');sites=load(SOURCE/'turned-2/sites.json');short=load(BASE/'short12-source.json');stocks=recipe['source_stocks'];required=recipe['required_pair_gap_mm'];guard=recipe['stock_guard_mm'];gap=recipe['gap_mm'];origin=recipe['origin'];radius=deriv['radius_upper_mm'];mw,mh=recipe['short_module_dimensions'];right=origin[0]+3*(mw+gap);theta=deriv['rotation_radians'];center=np.array(deriv['source_center']);c,s=math.cos(theta),math.sin(theta);rot=np.array([[c,s],[-s,c]])
old=[r for r in fixed if r['sheet_id']=='sheet-1' and (r['part_id']=='bracket' or 11<=r['copy_index']<=13)];assert short[:9]==old and len(short)==12;assert [r['part_id'] for r in short[9:]]==['cog','insert','insert']
assert short[9]['copy_index']==14 and short[9]['transform']['rotation_radians']==theta and not short[9]['transform']['mirrored'];expected=(np.array(parts['cog']['geometry'][0]['outer'])-center)@rot+[right+radius,origin[1]+radius];assert np.allclose(world(short[9]),expected,atol=1e-10,rtol=0)
iv=parts['insert']['geometry'][0]['outer'];height=max(v[1] for v in iv)-min(v[1] for v in iv)
for i in range(2):
    r=short[10+i];assert r['copy_index']==14+i and r['transform']['rotation_radians']==0 and not r['transform']['mirrored'];assert np.allclose(world(r).min(0),[right+2*radius+gap,origin[1]+i*(height+gap)],atol=1e-10,rtol=0)
vertices=list(map(world,short));shapes=list(map(Polygon,vertices));distances=[]
for i,j in combinations(range(12),2):
    assert shapes[i].intersection(shapes[j]).area==0;d=direct_gap(vertices[i],vertices[j]);assert d+1e-7>=required;distances.append(d)
for p in vertices:
    low=p.min(0);high=p.max(0);b=stocks['sheet-1'];assert all(low[k]>=b[k]+guard for k in range(2)) and all(high[k]<=b[k+2]-guard for k in range(2))
fresh=audit(job,short,stocks,required,guard);assert fresh==load(BASE/'short12-checks.json') and fresh['valid'];frames=[r for r in fixed if r['sheet_id']=='sheet-0']+roof;allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};cases=load(BASE/'cases.json');assert [tuple(r['empty_sites']) for r in cases]==list(combinations(range(16),2));holes=0;totalpairs=0
for case in cases:
    rows=load(BASE/(case['case']+'-source.json'));check=load(BASE/(case['case']+'-checks.json'));assert rows[:18]==frames and rows[-12:]==short;selected=[site for site in sites if site['site'] not in case['empty_sites']];assert len(selected)==14
    for i,(r,site) in enumerate(zip(rows[18:32],selected)):
        assert r['part_id']=='cog' and r['copy_index']==i and r['sheet_id']=='sheet-0' and r['transform']['rotation_radians']==theta and not r['transform']['mirrored'];assert np.allclose(world(r),(np.array(parts['cog']['geometry'][0]['outer'])-center)@rot+site['center'],rtol=0,atol=1e-10)
    ids={(r['part_id'],r['copy_index']) for r in rows};assert len(ids)==len(rows)==44;remaining=sorted(allids-ids);assert list(map(list,remaining))==load(BASE/'remaining-identities.json');assert sum(f=='bracket' for f,i in remaining)==6 and sum(f=='insert' for f,i in remaining)==16;assert {r['copy_index'] for r in rows if r['part_id']=='cog'}==set(range(15))
    replay=audit(job,rows,stocks,required,guard);assert replay==check and replay['valid']==case['source_valid44']==True;holes+=sum(len(parts[r['part_id']]['geometry'][0]['holes']) for r in rows);totalpairs+=replay['same_sheet_pairs']
allocation=load(BASE/'allocation-readback.json');assert allocation['row']['short_counts']==[6,5,1] and allocation['row']['first_counts']==[18,6,16,14] and allocation['row']['excluded_by'] is None and allocation['unexcluded_rows']==440
process=load(ROOT/'output/h5-roof-one-short-cog-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source_short12_valid':True,'short_independent_pairs':66,'short_minimum_source_gap_mm':min(distances),'short_stock_edges':48,'source44_cases_replayed':120,'source44_valid_cases':120,'same_sheet_pairs_across_cases':totalpairs,'source_holes_across_cases':holes,'remaining_brackets_per_case':6,'remaining_inserts_per_case':16,'unexcluded_global_allocation_rows':440,'complete_preparation_seconds_if_consumed':charge,'complete_model_prepared':False,'full66_valid':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
