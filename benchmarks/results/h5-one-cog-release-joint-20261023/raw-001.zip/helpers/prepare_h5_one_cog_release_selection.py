"""Prepare fresh compatibility-preserving reduction, conditional solve and original audit."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def put(name,s):
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def replace(s,a,b):
    assert a in s,a
    return s.replace(a,b)

s=(ROOT/'output/reduce_h5_expanded_frame_joint.py').read_text()
s=replace(s,'build_h5_expanded_frame_joint','build_h5_one_cog_release_joint')
s=replace(s,'map the exact original 64-part seed','map all 30 exact original 64-part seeds')
s=replace(s,"remap={old:new for new,old in enumerate(kept)};projected=[sum(1<<remap[j] for j in bits(adj[i]) if j in ks) for i in kept]","remap={old:new for new,old in enumerate(kept)};keptmask=sum(1<<j for j in kept);projected=[sum(1<<remap[j] for j in bits(adj[i]&keptmask)) for i in kept]")
a=s.index("    area=mp['area_weights'];seed_group=");b=s.index('    remaining=projected.copy()',a)
s=s[:a]+'''    area=mp['area_weights'];mapped=[]
    for seed in mp['mapped_seeds']:
        group=seed['core_group'];chosen_global=sorted(replacements.get(i,i) for i in seed['selected_variable_candidates']);chosen=[newlocal[i] for i in chosen_global];mask=sum(1<<j for j in chosen);counts=Counter(pool[i]['placement']['part_id'] for i in chosen_global)
        assert len(chosen)==len(set(chosen))==32 and counts==Counter(bracket=10,cog=1,insert=21)
        assert all(not(projected[j]&mask) for j in chosen) and all(group in mp['compatible_groups'][local[i]] for i in chosen_global)
        row={**seed,'source':'mapped-64-part-seed','source_original_seed':seed['source'],'selected_variable_candidates':chosen_global,'counts':dict(counts),'objective':sum(area[pool[i]['placement']['part_id']] for i in chosen_global)}
        assert row['objective']==865862719;mapped.append(row)
    assert len(mapped)==30;best=mapped[0]
    write(OUT/'mapping.json',{**mp,'candidates':globals_kept,'compatible_groups':[mp['compatible_groups'][j] for j in kept],'mapped_seeds':mapped});write(OUT/'best-hint.json',best);write(OUT/'substitutions.json',removed)
''' +s[b:]
s=replace(s,"sample=list(itertools.islice(bits(choices),16));j=max(sample,key=lambda j:((projected[j]&choices).bit_count(),-j));","j=(choices&-choices).bit_length()-1;")
s=replace(s,"'exact_64_seed_counts_group_and_full_graph_checked':True","'all_30_exact_64_seeds_counts_groups_and_full_graph_checked':True,'mapped_seeds':len(mapped)")
s=replace(s,'then compress the exact induced graph.','then compress the exact induced graph by first-fit lowest-index clique expansion.')
put('reduce_h5_one_cog_release_joint.py',s)

s=(ROOT/'output/solve_h5_individual_frame_joint.py').read_text()
s=replace(s,'One bounded four-family search','One bounded conditional one-cog repair search')
s=replace(s,'h5-individual-frame-joint-20261023','h5-one-cog-release-joint-20261023')
s=replace(s,"ids=mp['candidates'];n=len(ids);cliques=[]","ids=mp['candidates'];n=len(ids);ng=len(mp['core_groups']);cliques=[]")
s=replace(s,"names=['frame','bracket','cog','insert']","names=['bracket','cog','insert']")
s=replace(s,"seed=set(best['selected_candidates']);hint=[int(i in seed) for i in ids]","seed=set(best['selected_variable_candidates']);hint=[int(i in seed) for i in ids]+[int(g==best['core_group']) for g in range(ng)]")
s=replace(s,"assert low==best['objective']>=4401740785 and high==4481740785 and audit['maximum_score_with_17_frames']<low","assert low==best['objective']>=865862719 and high==945862719")
s=replace(s,"domains={f:([caps[f],caps[f]] if f=='frame' else [0,caps[f]]) for f in names}","domains={f:[0,caps[f]] for f in names}")
s=replace(s,"variables=[model.new_bool_var(f'p{i}') for i in ids]","variables=[model.new_bool_var(f'p{i}') for i in ids]+[model.new_bool_var(f'core{g}') for g in range(ng)]")
s=replace(s,"    for f,js in families.items():model.add_linear_constraint","    model.add_exactly_one(variables[n:])\n    for j,compatible in enumerate(mp['compatible_groups']):model.add_bool_or([variables[j].Not()]+[variables[n+g] for g in compatible])\n    for f,js in families.items():model.add_linear_constraint")
s=replace(s,"for i in ids:v=expected.variables.add();v.name=f'p{i}';v.domain.extend([0,1])","for name in [f'p{i}' for i in ids]+[f'core{g}' for g in range(ng)]:v=expected.variables.add();v.name=name;v.domain.extend([0,1])")
s=replace(s,"    for f,js in families.items():c=expected.constraints.add().linear;","    expected.constraints.add().exactly_one.literals.extend(range(n,n+ng))\n    for j,compatible in enumerate(mp['compatible_groups']):expected.constraints.add().bool_or.literals.extend([-j-1]+[n+g for g in compatible])\n    for f,js in families.items():c=expected.constraints.add().linear;")
s=replace(s,'expected.solution_hint.vars.extend(range(n));','expected.solution_hint.vars.extend(range(n+ng));')
s=replace(s,"    assert {f:sum(hint[j] for j in js)","    assert sum(hint[n:])==1 and all(not hint[j] or best['core_group'] in mp['compatible_groups'][j] for j in range(n))\n    assert {f:sum(hint[j] for j in js)")
s=replace(s,"'variables':n,'constraints'","'variables':n+ng,'variable_poses':n,'core_choices':ng,'constraints'")
s=replace(s,"'frame_equality_already_implied_by_floor':True,'maximum_score_with_17_frames':audit['maximum_score_with_17_frames'],","'exactly_one_fixed_core_verified':True,'zero_variable_cog_permitted':True,")
s=replace(s,"    def selected(value):return [i for j,i in enumerate(ids) if value(variables[j])]","    def selected(value):\n        cores=[g for g in range(ng) if value(variables[n+g])];assert len(cores)==1\n        core=cores[0];return core,sorted(mp['core_groups'][core]['fixed_candidates']+[i for j,i in enumerate(ids) if value(variables[j])])")
s=replace(s,"chosen=selected(self.value);r={'index':len(records)","core,chosen=selected(self.value);r={'index':len(records),'core_group':core")
s=replace(s,"chosen=selected(solver.value);write(OUT/'selected-indices.json',chosen);result.update(counts=","core,chosen=selected(solver.value);write(OUT/'selected-indices.json',chosen);result.update(core_group=core,counts=")
put('solve_h5_one_cog_release_joint.py',s)

s=(ROOT/'output/audit_h5_individual_frame_layouts.py').read_text()
s=replace(s,'wider-frame layout','one-cog repair layout')
s=replace(s,'build_h5_individual_frame_joint','build_h5_one_cog_release_joint')
s=replace(s,"seed=best['selected_candidates']","seed=sorted(mp['core_groups'][best['core_group']]['fixed_candidates']+best['selected_variable_candidates'])")
s=replace(s,"'index':'hint','selected_indices'","'index':'hint','core_group':best['core_group'],'selected_indices'")
s=replace(s,"'index':'final','selected_indices'","'index':'final','core_group':result['core_group'],'selected_indices'")
s=replace(s,"chosen=r['selected_indices'];sm=set(chosen)","chosen=r['selected_indices'];fixed=set(mp['core_groups'][r['core_group']]['fixed_candidates']);sm=set(chosen)-fixed\n        assert fixed<=set(chosen) and len(fixed)==32 and Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,cog=14)")
s=replace(s,"assert all(not(adj[j]&mask) for j in selected_local)","assert all(not(adj[j]&mask) and r['core_group'] in mp['compatible_groups'][j] for j in selected_local)")
s=replace(s,"'incumbent':index,'counts'","'incumbent':index,'core_group':r['core_group'],'counts'")
s=replace(s,"'new_individual_frame_poses_selected':sorted(i for i in sm if pool[i]['placement']['part_id']=='frame' and i not in previous_frames),'small_poses_unavailable_to_previous_groups':sorted(i for i in sm if pool[i]['placement']['part_id']!='frame' and i not in previous_small)","'variable_cog_poses':sorted(i for i in sm if pool[i]['placement']['part_id']=='cog'),'variable_objective':r['objective']")
put('audit_h5_one_cog_release_layouts.py',s)
print('Prepared new conditional reduction, single bounded solver and original-layout audit; no solve called.')
