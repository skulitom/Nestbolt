"""Conservative source-hull-box material bounds in grid-aligned rectangular windows."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import itertools,json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
COUNT=ROOT/'output/h5-first55-strip-filtered-components-20261029'
GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'
PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
OUT=ROOT/'output/h5-first55-component-window-capacity-20261029'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(COUNT/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
inner={f:[[[F(v) for v in b] for b in mode] for mode in opts] for f,opts in load(GENERIC/'source-inner-rectangles.json').items()}
unary=load(PRIOR/'integer-preparation/unary-templates.json')
windows=[(l,b,r,t) for l,r in itertools.combinations(range(0,1501,100),2) for b,t in itertools.combinations(range(2000,3001,100),2)]
W=np.array(windows,dtype=np.float64);L,B,R,T=W.T
indices=np.array([(l//10,(b-2000)//10,r//10,(t-2000)//10) for l,b,r,t in windows],dtype=np.int64)
IL,IB,IR,IT=indices.T
@lru_cache(None)
def bounds(gid,ri):
    points=[tuple(map(F,v)) for v in unary[gid]['regions'][ri]['hull_vertices']]
    return tuple(fn(p[a] for p in points) for fn in [min,max] for a in [0,1])
def overlap(a,b,l,r):return max(F(0),min(b,r)-max(a,l))
@lru_cache(None)
def estimated(f,m,gid,ri):
    xl,yl,xh,yh=map(float,bounds(gid,ri));values=np.zeros(len(windows))
    for raw in inner[f][m]:
        l,b,r,t=map(float,raw)
        dx=np.minimum(np.maximum(0,np.minimum(r+xl,R)-np.maximum(l+xl,L)),np.maximum(0,np.minimum(r+xh,R)-np.maximum(l+xh,L)))
        dy=np.minimum(np.maximum(0,np.minimum(t+yl,T)-np.maximum(b+yl,B)),np.maximum(0,np.minimum(t+yh,T)-np.maximum(b+yh,B)))
        values+=dx*dy
    return values
@lru_cache(None)
def exact(f,m,gid,ri,window):
    xl,yl,xh,yh=bounds(gid,ri);L,B,R,T=map(F,window);value=F(0)
    for l,b,r,t in inner[f][m]:
        dx=min(overlap(l+x,r+x,L,R) for x in [xl,xh]);dy=min(overlap(b+y,t+y,B,T) for y in [yl,yh]);value+=dx*dy
    return value
rows=[];initial_total=remaining_total=cert_count=0;subsets_done=screened=exact_windows=0;all_complete=True
for prior in load(COUNT/'all25-filtered-bounds.json'):
    groups=prior['groups'];possible={tuple(v) for v in prior['remaining_distributions']};initial_total+=len(possible)
    attribution=[set() for g in groups]
    for f,m,gid,ri,gi in prior['region_component_assignments']:attribution[gi].add((f,m,gid,ri))
    group_estimates=np.full((len(windows),len(groups)),np.inf);complete=True
    for gi,keys in enumerate(attribution):
        for key in sorted(keys):
            if time.perf_counter()-started>=58:complete=False;break
            np.minimum(group_estimates[:,gi],estimated(*key),out=group_estimates[:,gi])
        if not complete:break
    records=[];completed=row_screened=checked=0
    for mask in range(1,1<<len(groups)):
        if not complete or time.perf_counter()-started>=58:complete=False;break
        selected=[i for i in range(len(groups)) if mask>>i&1]
        if {groups[i]['family'] for i in selected}!={'bracket','insert'}:continue
        bits=0
        for i in selected:bits|=int(groups[i]['support_hex'],16)
        occupancy=np.zeros((100,150),dtype=np.int64)
        while bits:
            bit=bits&-bits;y,x=divmod(bit.bit_length()-1,150);occupancy[y,x]=100;bits^=bit
        prefix=np.pad(occupancy,((1,0),(1,0))).cumsum(axis=0).cumsum(axis=1)
        available=prefix[IT,IR]-prefix[IB,IR]-prefix[IT,IL]+prefix[IB,IL]
        if possible:
            counts=np.array(sorted(possible),dtype=np.float64);estimate=counts[:,selected]@group_estimates[:,selected].T
            candidates=np.flatnonzero(np.any((estimate>available-1e-4)&(estimate>1e-4),axis=0))
        else:candidates=[]
        for wi in candidates:
            if time.perf_counter()-started>=58:complete=False;break
            window=windows[int(wi)];coefficients=[F(0)]*len(groups);witnesses={}
            for gi in selected:
                values=[(exact(*key,window),key) for key in sorted(attribution[gi])];value,key=min(values)
                coefficients[gi]=value;witnesses[str(gi)]={'source_key':list(key),'minimum_area_mm2':str(value),'source_options':len(values)}
            removed=sorted(v for v in possible if sum(v[i]*coefficients[i] for i in selected)>int(available[wi]))
            if removed:
                records.append({'groups':selected,'window_mm':list(window),'upper_area_mm2':int(available[wi]),'coefficients_mm2':[str(v) for v in coefficients],'group_minimum_witnesses':witnesses,'distributions_removed':[list(v) for v in removed]});possible.difference_update(removed)
            checked+=1;exact_windows+=1
        row_screened+=len(windows);screened+=len(windows)
        if not complete:break
        completed+=1;subsets_done+=1
    all_complete=all_complete and complete;remaining_total+=len(possible);cert_count+=len(records)
    rows.append({'empty_sites':prior['empty_sites'],'initial_distributions':prior['remaining_distributions'],'certificates':records,'remaining_distributions':[list(v) for v in sorted(possible)],'mixed_subsets_completed':completed,'windows_screened':row_screened,'windows_recomputed_exactly':checked,'scan_complete':complete,'restricted_construction_excluded':not possible})
elapsed=time.perf_counter()-started
inputs=[Path(__file__),COUNT/'plan.json',COUNT/'audit/plan.json',COUNT/'audit/checks.json',COUNT/'all25-filtered-bounds.json',GENERIC/'source-inner-rectangles.json',PRIOR/'integer-preparation/unary-templates.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each original convex translation hull, enlarge to its exact axis-aligned box. For each contained source rectangle independently, minimize X overlap and Y overlap with a fixed window over their respective translation intervals, at both endpoints. Their product is the exact rectangle minimum over this enlarged box. The sum of independent rectangle minima is a conservative material lower bound. Minimize this sum across all original mode/hull options attributed to each source component. Count-weighted selected-group bounds cannot exceed the area of their conservative support-cell union inside the window. Floating screening only; every recorded exclusion is recomputed with exact rational arithmetic.','window_grid_mm':100,'windows_per_mixed_subset':len(windows),'discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'unprocessed_distributions_retained':True,'floating_exclusions_permitted':False,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'all25-window-bounds.json',rows)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'scan_complete':all_complete,'site_pairs_retained_in_table':len(rows),'initial_count_distributions':initial_total,'remaining_count_distributions':remaining_total,'count_distributions_excluded':initial_total-remaining_total,'certificates':cert_count,'mixed_subsets_completed':subsets_done,'windows_screened':screened,'windows_recomputed_exactly':exact_windows,'cached_source_options':estimated.cache_info().currsize,'new_restricted_site_exclusions':sum(r['restricted_construction_excluded'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
