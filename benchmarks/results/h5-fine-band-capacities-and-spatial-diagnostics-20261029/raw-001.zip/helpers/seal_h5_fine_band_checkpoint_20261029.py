"""Seal independently proved fine-band capacities and retained spatial diagnostics."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
FINE=ROOT/'output/h5-first55-fine-band-capacity-20261029';FINESTRIP=ROOT/'output/h5-first55-fine-band-strip-capacity-20261029';FILTER=ROOT/'output/h5-first55-fine-band-filtered-components-20261029';DIAG=ROOT/'output/h5-first55-diagonal-strip-capacity-20261029';DIAGMATH=ROOT/'output/h5-diagonal-strip-geometry-preflight-20261029';BOX=ROOT/'output/h5-first55-component-window-capacity-20261029';CONVEX=ROOT/'output/h5-first55-convex-window-capacity-20261029';WINMATH=ROOT/'output/h5-window-geometry-preflight-20261029';PUB=FINE/'publication';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
NAME='h5-fine-band-capacities-and-spatial-diagnostics-20261029';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,v):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(v)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='b86ea9dcf6bd4985a71022683b1fe84137961761' and not git('diff','HEAD','--name-only')
fine=load(FINE/'audit/checks.json');assert fine['passed'] and fine['necessary_subset_certificates_verified']==26 and fine['count_distributions_excluded']==40 and fine['remaining_count_distributions']==42 and fine['restricted_pairs_remaining']==18 and fine['new_restricted_site_exclusions']==7 and fine['independent_exact_polygon_band_clippings']==196029
assert load(FILTER/'audit/checks.json')['passed'] and load(FILTER/'audit/checks.json')['source_geometry_and_attributions_unchanged'] and load(FILTER/'audit/checks.json')['all_source_mode_aliases_agree_on_component']
for folder in [DIAG,BOX,CONVEX,FINE,FINESTRIP]:
    c=load(folder/'checks.json');assert c['passed'] and c['scan_complete'] and c['cap_overrun_seconds']==0 and c['solver_calls']==c['native_calls']==0
for folder in [DIAG,CONVEX,FINESTRIP]:assert load(folder/'diagnostic-audit/checks.json')['passed']
for folder in [DIAGMATH,WINMATH]:assert load(folder/'checks.json')['passed'] and load(folder/'checks.json')['all_exact_minima_match']
assert digest(SHORT/'search/source-response/candidate-source11.json')=='8b7fa5f6ad765aab6fdba1a586c29d8cac2cce607ed1d7fcd0fb6938c4eeada0'
assert digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
prior=load(ROOT/'benchmarks/results/h5-source-strip-capacities-and-restricted-component-search-20261029/publication-review.json');production=source_digest();readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert production==prior['production_digest'] and readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];remote=load(PUB/'main.json')['commit']['sha'];assert remote==ci['head_sha']==head and ci['id']==40841006837 and ci['status']=='completed' and ci['conclusion']=='success'
assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json';assert sum(r['excluded_by'] is None for r in load(frontier))==440
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(name,path):
    assert path.is_file() and '.claude' not in path.parts
    members[name]=path
    if path.name in ['plan.json','opened.json'] or path.suffix=='.py':queue.append(path)
for folder in [DIAG,DIAGMATH,BOX,CONVEX,WINMATH,FINE,FINESTRIP,FILTER]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=set()
for pattern in ['*h5*diagonal*20261029.py','*h5*window*20261029.py','*h5*fine_band*20261029.py']:
    helpers.update((ROOT/'output').glob(pattern))
helpers.update(ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name])
for p in sorted(helpers):add('helpers/'+p.name,p)
add('publication/prior-push-receipt.json',ROOT/'output/h5-strip-search-main-sync-20261029/receipt.json')
while queue:
    path=queue.pop()
    if path in seen:continue
    seen.add(path)
    if path.name in ['plan.json','opened.json']:
        for name,h in load(path).get('inputs',{}).items():
            p=ROOT/name;assert p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts) and digest(p)==h,name
            bindings[name]=h;add('source-inputs/'+name,p)
    elif path.suffix=='.py':
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    p=ROOT/folder/(module+'.py')
                    if p.is_file():add('imported-helpers/'+folder+'/'+p.name,p)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(FINE/'checks.json','fine-band-preparation.json'),(FINE/'audit/checks.json','fine-band-audit.json'),(FINE/'all25-fine-band-bounds.json','all25-fine-band-bounds.json'),(FINE/'audit/allowed-empty-site-pairs.json','allowed-empty-site-pairs.json'),(FINE/'audit/excluded-empty-site-pairs.json','excluded-empty-site-pairs.json'),(FILTER/'checks.json','filtered-count-preparation.json'),(FILTER/'audit/checks.json','filtered-count-audit.json'),(DIAG/'checks.json','diagonal-preparation.json'),(DIAG/'diagnostic-audit/checks.json','diagonal-diagnostic-audit.json'),(DIAGMATH/'checks.json','diagonal-math-preflight.json'),(BOX/'checks.json','box-window-preparation.json'),(CONVEX/'checks.json','convex-window-preparation.json'),(CONVEX/'diagnostic-audit/checks.json','window-diagnostic-audit.json'),(WINMATH/'checks.json','window-math-preflight.json'),(FINESTRIP/'checks.json','fine-strip-preparation.json'),(FINESTRIP/'diagnostic-audit/checks.json','fine-strip-diagnostic-audit.json'),(FINE/'next-step.json','next-step.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':remote,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40841006837,'main_all6_pass':True,'successful_jobs_at_snapshot':6,'normal_push_still_requires_fresh_head_and_live_run_checks':True,'unchanged_frontier_path':frontier.relative_to(ROOT).as_posix(),'unchanged_frontier_sha256':digest(frontier),'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'necessary_subset_certificates_verified':26,'source_swept_vertices_enclosed':14714,'independent_exact_polygon_band_clippings':196029,'count_distributions_excluded':40,'remaining_count_distributions':42,'new_restricted_site_exclusions':7,'restricted_site_pairs_remaining':18,'restricted_site_pairs_excluded_total':87,'only_independently_proved_count_exclusions_applied':True,'new_solver_calls':0,'source_checker_calls':0,'native_calls':0,'new_allocation_exclusions':0,'remaining_candidates':440,'source_valid_short11_preserved':True,'valid64_preserved':True,'source_valid66_created':False,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(FINE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(FINE/'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [source-strip capacities and restricted component search](../benchmarks/results/h5-source-strip-capacities-and-restricted-component-search-20261029.md).';new=f'Latest H5 evidence: [fine-band capacities and spatial diagnostics](../benchmarks/results/{NAME}.md).';assert s.count(old)==1
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s.replace(old,new,1))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'new_solver_calls':0,'new_restricted_site_exclusions':7,'remaining_count_distributions':42,'restricted_site_pairs_remaining':18,'remaining_allocations':440,'completion_percent':60})
