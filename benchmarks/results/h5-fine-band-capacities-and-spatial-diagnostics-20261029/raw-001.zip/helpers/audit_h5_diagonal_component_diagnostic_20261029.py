"""Read back the no-improvement scan and independently test its exact rectangle clipping formula."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];LOCAL=ROOT/'output/h5-first55-local-grid-regions-20261029';BASE=LOCAL/'diagonal-component-bound';OUT=BASE/'diagnostic-audit';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';HELPER=ROOT/'output/bound_h5_diagonal_component_capacity_20261029.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygon_below(box,n,cut):
    l,b,r,t=box;poly=[(l,b),(r,b),(r,t),(l,t)];out=[]
    for a,z in zip(poly,poly[1:]+poly[:1]):
        da=n[0]*a[0]+n[1]*a[1]-cut;dz=n[0]*z[0]+n[1]*z[1]-cut
        if da<=0:out.append(a)
        if (da<=0)!=(dz<=0):
            fraction=da/(da-dz);out.append(tuple(a[k]+fraction*(z[k]-a[k]) for k in [0,1]))
    return abs(sum(a[0]*z[1]-z[0]*a[1] for a,z in zip(out,out[1:]+out[:1])))/2 if out else F(0)
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
tree=ast.parse(HELPER.read_text(encoding='utf-8'));fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='rectangle_below');fn.decorator_list=[];scope={'F':F};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(HELPER),'exec'),scope);formula=scope['rectangle_below']
boxes=[tuple(map(F,b)) for mode in load(LOCAL/'component-halfspace-bound/source-inner-rectangles.json') for b in mode]+[(F(0),F(0),F(10),F(10))];normals=[tuple(n) for n in load(BASE/'plan.json')['directions']];cases=0
for box in boxes:
    l,b,r,t=box
    for n in normals:
        breaks=sorted({n[0]*x+n[1]*y for x in [l,r] for y in [b,t]});cuts=breaks+[breaks[0]-1,breaks[-1]+1]
        for a,z in zip(breaks,breaks[1:]):cuts.extend(a+(z-a)*fraction for fraction in [F(1,4),F(1,2),F(3,4)])
        for cut in cuts:assert formula(box,n,cut)==polygon_below(box,n,cut);cases+=1
axis={tuple(r['empty_sites']):r for r in load(LOCAL/'component-halfspace-bound/all35-halfspace-bounds.json')};grid={tuple(r['empty_sites']):r for r in load(PRIOR/'connected-capacity-bound/all105-capacity-bounds.json')};allowed=load(LOCAL/'component-halfspace-bound/audit/allowed-empty-site-pairs.json');rows=load(BASE/'all29-diagonal-bounds.json');assert [r['empty_sites'] for r in rows]==allowed;examined=0
for row in rows:
    key=tuple(row['empty_sites']);old=axis[key];assert not row['restricted_construction_excluded'] and row['total_bracket_capacity_upper_bound']==old['total_bracket_capacity_upper_bound']
    for actual,prior,h in zip(row['components'],old['components'],grid[key]['components_hex']):
        assert actual['capacity_upper_bound']==actual['prior_axis_capacity']==prior['capacity_upper_bound'] and actual['strongest_diagonal_certificate'] is None and actual['scan_complete'] and actual['directions_completed']==6
        bits=int(h,16);cells=[divmod(i,150) for i in range(15000) if bits>>i&1];expected=0
        for nx,ny in normals:
            lows=[10*(nx*x+ny*(200+y))+10*(min(0,nx)+min(0,ny)) for y,x in cells];highs=[10*(nx*x+ny*(200+y))+10*(max(0,nx)+max(0,ny)) for y,x in cells]
            first=-(-min(lows)//50)*50;last=max(highs)//50*50;expected+=2*len(range(first,last+1,50))
        assert actual['halfspaces_examined']==expected;examined+=expected
assert examined==19102==load(BASE/'checks.json')['halfspaces_examined'] and load(BASE/'checks.json')['cap_overrun_seconds']==0
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),HELPER]+[BASE/n for n in ['plan.json','checks.json','all29-diagonal-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'exact_analytic_clipping_oracle_cases':cases,'scan_shape_halfspaces_verified':examined,'unchanged_component_capacities_verified':True,'remaining_site_pairs':29,'new_certificates':0,'new_restricted_exclusions':0,'all19102_material_bounds_independently_recomputed':False,'diagnostic_only_not_a_proof_that_stronger_diagonal_bounds_do_not_exist':True,'global_allocation_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
