from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/bound_h5_component_strips_20261029.py').read_text(encoding='utf-8')
s=s.replace("OUT=ROOT/'output/h5-first55-component-strip-capacity-20261029'","OUT=ROOT/'output/h5-first55-fine-band-strip-capacity-20261029';FILTER=ROOT/'output/h5-first55-strip-filtered-components-20261029';FINE=ROOT/'output/h5-first55-fine-band-capacity-20261029'")
s=s.replace("assert load(COUNT/'audit/checks.json')['passed'];", "assert load(COUNT/'audit/checks.json')['passed'] and load(FINE/'audit/checks.json')['passed'];")
s=s.replace("for prior in load(COUNT/'all29-vectorized-bounds.json'):","""fine_rows={tuple(r['empty_sites']):r for r in load(FINE/'all25-fine-band-bounds.json')}
for original in load(FILTER/'all25-filtered-bounds.json'):
    fine=fine_rows[tuple(original['empty_sites'])]
    if not fine['remaining_distributions']:continue
    prior={**original,'remaining_distributions':fine['remaining_distributions']}""")
a=s.index('        union=0');b=s.index('        if possible:',a)
s=s[:a]+'''        union={}
        for i in selected:
            for row,lo,hi in fine['groups'][i]['band_spans_tenths_mm']:union.setdefault(row,[]).append((lo,hi))
        merged={row:merge(spans) for row,spans in union.items()}
        flat=np.array([(row,lo,hi) for row,spans in merged.items() for lo,hi in spans],dtype=np.int64)
        xp=np.sum(np.clip(100*np.arange(151,dtype=np.int64)[:,None]-flat[:,1],0,flat[:,2]-flat[:,1]),axis=1,dtype=np.int64)
        yp=np.zeros(101,dtype=np.int64)
        for row,lo,hi in flat:yp[(int(row)-1000)//5+1]+=hi-lo
        yp=np.cumsum(yp,dtype=np.int64);prefix=[xp,yp]
        fifths=np.array([prefix[axis][b]-prefix[axis][a] for axis,l,r,a,b in strips],dtype=np.int64)
        available=fifths/5.;screened+=len(strips);strips_screened+=len(strips)
''' +s[b:]
s=s.replace('>int(available[int(si)])','>F(int(fifths[int(si)]),5)')
s=s.replace("'upper_area_mm2':int(available[int(si)])","'upper_area_mm2':str(F(int(fifths[int(si)]),5))")
s=s.replace("inputs=[Path(__file__),COUNT/", "inputs=[Path(__file__),FINE/'plan.json',FINE/'audit/plan.json',FINE/'audit/checks.json',FINE/'all25-fine-band-bounds.json',FILTER/'plan.json',FILTER/'all25-filtered-bounds.json',COUNT/")
s=s.replace('its exact grid-cell strip area','the exact area of its independently audited 2mm-band, 0.1mm-horizontal support union inside the strip')
s=s.replace("'all29-strip-bounds.json'","'all18-fine-band-strip-bounds.json'")
p=ROOT/'output/bound_h5_fine_band_strips_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name})
