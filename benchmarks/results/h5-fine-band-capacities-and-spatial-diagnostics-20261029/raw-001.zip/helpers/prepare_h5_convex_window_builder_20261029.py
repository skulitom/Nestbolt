from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/bound_h5_component_windows_20261029.py').read_text(encoding='utf-8')
s=s.replace('Conservative source-hull-box material bounds in grid-aligned rectangular windows.','Convex source-hull material minima in grid-aligned rectangular windows.')
s=s.replace('import numpy as np','import numpy as np\nimport h5_window_geometry_20261029 as geometry')
s=s.replace("OUT=ROOT/'output/h5-first55-component-window-capacity-20261029'","OUT=ROOT/'output/h5-first55-convex-window-capacity-20261029'\nPREFLIGHT=ROOT/'output/h5-window-geometry-preflight-20261029'")
s=s.replace("assert load(COUNT/'audit/checks.json')['passed']","assert load(COUNT/'audit/checks.json')['passed'] and load(PREFLIGHT/'checks.json')['passed']")
a=s.index('@lru_cache(None)\ndef estimated(');b=s.index('rows=[];',a)
s=s[:a]+'''@lru_cache(None)
def hull(gid,ri):return [tuple(map(F,v)) for v in unary[gid]['regions'][ri]['hull_vertices']]
@lru_cache(None)
def estimated(f,m,gid,ri):return geometry.vertex_upper_estimates(inner[f][m],hull(gid,ri),W)
@lru_cache(None)
def exact(f,m,gid,ri,window):return geometry.minimum_material(inner[f][m],tuple(map(F,window)),hull(gid,ri))['minimum']
def lower_box(f,m,gid,ri,window):
    xl,yl,xh,yh=bounds(gid,ri);L,B,R,T=map(F,window);value=F(0)
    for l,b,r,t in inner[f][m]:
        dx=min(overlap(l+x,r+x,L,R) for x in [xl,xh]);dy=min(overlap(b+y,t+y,B,T) for y in [yl,yh]);value+=dx*dy
    return value
''' + s[b:]
old="""                values=[(exact(*key,window),key) for key in sorted(attribution[gi])];value,key=min(values)
                coefficients[gi]=value;witnesses[str(gi)]={'source_key':list(key),'minimum_area_mm2':str(value),'source_options':len(values)}"""
new="""                value=None;witness=None;exact_count=pruned=0
                for key in sorted(attribution[gi],key=lambda key:(estimated(*key)[wi],key)):
                    if time.perf_counter()-started>=58:complete=False;break
                    lower=lower_box(*key,window)
                    if value is not None and lower>=value:pruned+=1;continue
                    v=exact(*key,window);exact_count+=1
                    if value is None or v<value:value,witness=v,key
                if not complete:break
                coefficients[gi]=value;witnesses[str(gi)]={'source_key':list(witness),'minimum_area_mm2':str(value),'source_options':len(attribution[gi]),'exact_convex_options':exact_count,'conservative_box_prunes':pruned}
            if not complete:break"""
assert old in s;s=s.replace(old,new)
s=s.replace("inputs=[Path(__file__),COUNT/", "inputs=[Path(__file__),Path(geometry.__file__),PREFLIGHT/'plan.json',PREFLIGHT/'checks.json',COUNT/")
a=s.index("'method':");b=s.index(",'window_grid_mm'",a)
s=s[:a]+"'method':'For each original convex translation hull and mode, minimize contained source-rectangle material inside each window at source/window breakpoint-grid vertices inside the hull, all hull-edge breakpoints, and every interior stationary minimum of each hull-edge quadratic. Each subdivided objective is bilinear, so these candidates contain a global minimum. Floating vertex minima are UPPER estimates used only to screen prospective exclusions; exact rational minima authorize every exclusion. Independently minimized source rectangles over an enlarged hull box may skip a hull only when their exact lower bound is at least the current exact group minimum. Compare count-weighted group minima with the exact selected support-cell union area inside each window.'"+s[b:]
s=s.replace("'all25-window-bounds.json'","'all25-convex-window-bounds.json'")
p=ROOT/'output/bound_h5_convex_component_windows_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name})
