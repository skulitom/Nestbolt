from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new,audit in [('filter_h5_strip_component_counts_20261029.py','filter_h5_fine_band_component_counts_20261029.py',False),('audit_h5_strip_filtered_counts_20261029.py','audit_h5_fine_band_filtered_counts_20261029.py',True)]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    s=s.replace("SOURCE=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'","SOURCE=ROOT/'output/h5-first55-strip-filtered-components-20261029'")
    s=s.replace("STRIP=ROOT/'output/h5-first55-component-strip-capacity-20261029'","STRIP=ROOT/'output/h5-first55-fine-band-capacity-20261029'")
    target='BASE' if audit else 'OUT'
    s=s.replace(target+"=ROOT/'output/h5-first55-strip-filtered-components-20261029'",target+"=ROOT/'output/h5-first55-fine-band-filtered-components-20261029'")
    s=s.replace("SOURCE/'all29-vectorized-bounds.json'","SOURCE/'all25-filtered-bounds.json'")
    s=s.replace("STRIP/'all29-strip-bounds.json'","STRIP/'all25-fine-band-bounds.json'")
    s=s.replace("OUT/'all25-filtered-bounds.json'","OUT/'all18-filtered-bounds.json'").replace("BASE/'all25-filtered-bounds.json'","BASE/'all18-filtered-bounds.json'").replace("'checks.json','all25-filtered-bounds.json'","'checks.json','all18-filtered-bounds.json'")
    s=s.replace('len(rows)==25','len(rows)==18').replace('for r in rows)==82','for r in rows)==42').replace("'restricted_site_pairs':25","'restricted_site_pairs':18").replace("'count_distributions':82","'count_distributions':42")
    s=s.replace('independently audited strip result','independently audited fine-band capacity result').replace('Required model preparation also charges generic count construction and strip discovery.','Required model preparation also charges every step in the prior filtered source chain and this fine-band discovery.')
    s=s.replace("'generic_count_construction_seconds_required':load(SOURCE/'checks.json')['seconds'],'strip_bound_seconds_required':load(STRIP/'checks.json')['seconds']","'prior_filtered_count_seconds_required':load(SOURCE/'checks.json')['seconds'],'fine_band_bound_seconds_required':load(STRIP/'checks.json')['seconds'],'all_prior_source_chain_charges_still_required':True")
    p=ROOT/'output'/new;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    print({'prepared':p.name})
