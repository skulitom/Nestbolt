"""Exact diagonal halfspace capacity certificates for the remaining fixed-site constructions."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-local-grid-regions-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';AXIS=BASE/'component-halfspace-bound';OUT=BASE/'diagonal-component-bound'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(AXIS/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py')
normals=[(1,1),(1,-1),(2,1),(1,2),(2,-1),(1,-2)]
inputs=[Path(__file__),AXIS/'plan.json',AXIS/'audit/plan.json',AXIS/'audit/checks.json',AXIS/'audit/allowed-empty-site-pairs.json',AXIS/'all35-halfspace-bounds.json',AXIS/'source-inner-rectangles.json',PRIOR/'integer-preparation/plan.json',PRIOR/'integer-preparation/unary-templates.json',PRIOR/'connected-capacity-bound/audit/plan.json',PRIOR/'connected-capacity-bound/audit/checks.json',PRIOR/'connected-capacity-bound/all105-capacity-bounds.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each remaining fixed-site choice and each audited bracket occupancy component, compute exact translation-projection extrema over every assigned source-mode unary hull. Contained original-source rectangles yield material lower bounds in each diagonal halfspace; exact clipping of the grid component yields upper area bounds. Minimize required material over every source mode and divide available area by that minimum to bound whole brackets. Retain inherited axis capacities where no stronger certificate is found. This is a necessary condition only for the saved conservative construction.','directions':[list(n) for n in normals],'threshold_spacing_projection_units':50,'both_halfspaces':True,'discovery_cap_seconds':60,'stop_starting_new_thresholds_after_seconds':58,'partial_scan_allowed_only_with_all_unprocessed_choices_retained':True,'solver_calls':0,'global_allocation_exclusion_permitted':False})
started=time.perf_counter();unary=load(PRIOR/'integer-preparation/unary-templates.json');inner=[[[F(v) for v in b] for b in opts] for opts in load(AXIS/'source-inner-rectangles.json')]
allowed=load(AXIS/'audit/allowed-empty-site-pairs.json');axis_rows={tuple(r['empty_sites']):r for r in load(AXIS/'all35-halfspace-bounds.json')};prior_rows={tuple(r['empty_sites']):r for r in load(PRIOR/'connected-capacity-bound/all105-capacity-bounds.json')}
@lru_cache(None)
def rectangle_below(box,normal,cut):
    l,b,r,t=box;nx,ny=normal;minimum=min(nx*l,nx*r)+min(ny*b,ny*t);sx=abs(nx)*(r-l);sy=abs(ny)*(t-b);area=(r-l)*(t-b);z=cut-minimum
    if z<=0:return F(0)
    if z>=sx+sy:return area
    positive=lambda v:max(F(0),v)**2
    return (positive(z)-positive(z-sx)-positive(z-sy)+positive(z-sx-sy))/(2*abs(nx*ny))
@lru_cache(None)
def material(mode,normal,above,relative_cut):
    values=[rectangle_below(tuple(box),normal,relative_cut) for box in inner[mode]]
    return sum((box[2]-box[0])*(box[3]-box[1])-v if above else v for box,v in zip(inner[mode],values))
rows=[];cap_reached=False;total_thresholds=0;certificates=0
for empty in allowed:
    previous=axis_rows[tuple(empty)];components=[int(h,16) for h in prior_rows[tuple(empty)]['components_hex']];mode_points=[{} for _ in components]
    for mode,gid,ri,ci in previous['region_component_assignments']:
        points=[tuple(map(F,p)) for p in unary[gid]['regions'][ri]['hull_vertices']];mode_points[ci].setdefault(mode,[]).extend(points)
    component_rows=[]
    for ci,(bits,old) in enumerate(zip(components,previous['components'])):
        capacity=old['capacity_upper_bound'];best=None;examined=0;completed_normals=0
        cells=[divmod(i,150) for i in range(15000) if bits>>i&1];total=F(len(cells)*100)
        for normal in normals:
            if cap_reached:break
            nx,ny=normal;bounds={m:[min(nx*x+ny*y for x,y in p),max(nx*x+ny*y for x,y in p)] for m,p in mode_points[ci].items()}
            histogram={}
            for y,x in cells:
                k=nx*x+ny*(200+y);histogram[k]=histogram.get(k,0)+1
            lo=min(histogram);hi=max(histogram);counts=[histogram.get(k,0) for k in range(lo,hi+1)];suffix=[0]*(len(counts)+1)
            for k in range(len(counts)-1,-1,-1):suffix[k]=suffix[k+1]+counts[k]
            minoff=min(0,nx)+min(0,ny);maxoff=max(0,nx)+max(0,ny)
            first=-(-(lo+minoff)//5)*5;last=(hi+maxoff)//5*5
            for cut_index in range(first,last+1,5):
                if time.perf_counter()-started>=58:cap_reached=True;break
                cutoff=min(len(counts),max(0,cut_index-minoff-lo));above_area=F(suffix[cutoff]*100)
                for k in range(cut_index-maxoff+1,cut_index-minoff):
                    count=histogram.get(k,0)
                    if count:above_area+=count*(100-rectangle_below((F(0),F(0),F(10),F(10)),normal,F(10*(cut_index-k))))
                cut=F(10*cut_index);assert 0<=above_area<=total
                for above in [False,True]:
                    available=above_area if above else total-above_area
                    values={mode:material(mode,normal,above,cut-limits[0 if above else 1]) for mode,limits in bounds.items()};least=min(values.values());examined+=1;total_thresholds+=1
                    if least>0:
                        bound=int(available//least)
                        if bound<capacity:
                            capacity=bound;best={'normal':list(normal),'above':above,'threshold':str(cut),'upper_area_mm2':str(available),'mode_translation_projection_bounds':{str(m):[str(v) for v in limits] for m,limits in bounds.items()},'per_mode_minimum_material_mm2':{str(m):str(v) for m,v in values.items()},'minimum_bracket_material_mm2':str(least),'capacity':bound}
            if not cap_reached:completed_normals+=1
        component_rows.append({'component':ci,'prior_axis_capacity':old['capacity_upper_bound'],'capacity_upper_bound':capacity,'strongest_diagonal_certificate':best,'halfspaces_examined':examined,'directions_completed':completed_normals,'scan_complete':completed_normals==len(normals)})
        certificates+=best is not None
    total_capacity=sum(c['capacity_upper_bound'] for c in component_rows)
    rows.append({'empty_sites':empty,'components':component_rows,'total_bracket_capacity_upper_bound':total_capacity,'required_brackets':7,'restricted_construction_excluded':total_capacity<7})
elapsed=time.perf_counter()-started
write(OUT/'all29-diagonal-bounds.json',rows)
checks={'passed':True,'seconds':elapsed,'cap_seconds':60,'cap_overrun_seconds':max(0,elapsed-60),'discovery_scan_complete':not cap_reached,'site_pairs_retained_in_table':len(rows),'halfspaces_examined':total_thresholds,'strengthened_component_certificates':certificates,'additional_restricted_pairs_excluded':sum(r['restricted_construction_excluded'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
