"""Exact diagonal strip material and piecewise-quadratic translation minima."""
from fractions import Fraction as F

def corner_projections(box,normal):
    l,b,r,t=box;nx,ny=normal
    return sorted({nx*x+ny*y for x in [l,r] for y in [b,t]})

def rectangle_below(box,normal,cut):
    l,b,r,t=box;nx,ny=normal;assert nx and ny and l<r and b<t
    low=min(nx*l,nx*r)+min(ny*b,ny*t);sx=abs(nx)*(r-l);sy=abs(ny)*(t-b);z=cut-low
    if z<=0:return F(0)
    if z>=sx+sy:return (r-l)*(t-b)
    positive=lambda v:max(F(0),v)**2
    return (positive(z)-positive(z-sx)-positive(z-sy)+positive(z-sx-sy))/(2*abs(nx*ny))

def strip_material(boxes,normal,left,right,shift):
    return sum(rectangle_below(b,normal,right-shift)-rectangle_below(b,normal,left-shift) for b in boxes)

def minimum_strip_material(boxes,normal,intervals,left,right):
    assert left<right and intervals
    best=None;best_shift=None;endpoint_cases=stationary_cases=pieces=0
    for lo,hi in intervals:
        assert lo<=hi
        stops={lo,hi}
        for box in boxes:
            for corner in corner_projections(box,normal):
                for cut in [left,right]:
                    shift=cut-corner
                    if lo<shift<hi:stops.add(shift)
        ordered=sorted(stops);values={}
        for shift in ordered:
            value=strip_material(boxes,normal,left,right,shift);values[shift]=value;endpoint_cases+=1
            if best is None or value<best:best,best_shift=value,shift
        for a,b in zip(ordered,ordered[1:]):
            q0,q1=values[a],values[b];qh=strip_material(boxes,normal,left,right,(a+b)/2);qa=2*(q1+q0-2*qh);qb=q1-q0-qa;pieces+=1
            if qa>0:
                tau=-qb/(2*qa)
                if 0<tau<1:
                    shift=a+(b-a)*tau;value=strip_material(boxes,normal,left,right,shift);assert value==q0+qb*tau+qa*tau*tau;stationary_cases+=1
                    if value<best:best,best_shift=value,shift
    assert best is not None and best>=0
    return {'minimum':best,'minimizer':best_shift,'endpoint_cases':endpoint_cases,'stationary_cases':stationary_cases,'quadratic_pieces':pieces}

def estimated_rectangle_below(box,normal,cut):
    import numpy as np
    l,b,r,t=map(float,box);nx,ny=normal;low=min(nx*l,nx*r)+min(ny*b,ny*t);sx=abs(nx)*(r-l);sy=abs(ny)*(t-b);z=np.clip(cut-low,0.,sx+sy)
    positive=lambda v:np.maximum(0.,v)**2
    return (positive(z)-positive(z-sx)-positive(z-sy)+positive(z-sx-sy))/(2*abs(nx*ny))

def estimated_strip_minima(boxes,normal,intervals,left,right):
    import numpy as np
    left=np.asarray(left,dtype=np.float64);right=np.asarray(right,dtype=np.float64);minimum=np.full(left.shape,np.inf)
    def values(shift):
        result=np.zeros_like(shift)
        for box in boxes:result+=estimated_rectangle_below(box,normal,right-shift)-estimated_rectangle_below(box,normal,left-shift)
        return result
    for lo,hi in intervals:
        lo,hi=float(lo),float(hi);stops=[np.full(left.shape,lo),np.full(left.shape,hi)]
        for box in boxes:
            for corner in corner_projections(box,normal):stops.extend([np.clip(left-float(corner),lo,hi),np.clip(right-float(corner),lo,hi)])
        stops=np.sort(np.array(stops),axis=0);endpoint_values=values(stops);minimum=np.minimum(minimum,np.min(endpoint_values,axis=0))
        midpoint_values=values((stops[:-1]+stops[1:])/2);q0,q1=endpoint_values[:-1],endpoint_values[1:];qa=2*(q1+q0-2*midpoint_values);qb=q1-q0-qa
        tau=np.divide(-qb,2*qa,out=np.zeros_like(qa),where=qa>1e-9);inside=(qa>1e-9)&(tau>0)&(tau<1)&(stops[:-1]<stops[1:])
        interior=np.where(inside,q0+qb*tau+qa*tau*tau,np.inf);minimum=np.minimum(minimum,np.min(interior,axis=0))
    return minimum
