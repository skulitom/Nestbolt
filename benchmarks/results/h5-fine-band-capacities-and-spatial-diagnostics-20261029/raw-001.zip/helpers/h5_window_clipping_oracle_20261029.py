"""Independent cell subdivision and polygon-clipping oracle for window material."""
from fractions import Fraction as F

def clip(poly,axis,above,cut):
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        ina=a[axis]>=cut if above else a[axis]<=cut;inb=b[axis]>=cut if above else b[axis]<=cut
        if ina:out.append(a)
        if ina!=inb:
            tau=(cut-a[axis])/(b[axis]-a[axis]);out.append(tuple(a[k]+tau*(b[k]-a[k]) for k in [0,1]))
    return list(dict.fromkeys(out))

def area(poly):return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1])))/2 if poly else F(0)

def rectangle(poly,window):
    for axis,above,cut in [(0,True,window[0]),(1,True,window[1]),(0,False,window[2]),(1,False,window[3])]:poly=clip(poly,axis,above,cut)
    return poly

def material(boxes,window,position):
    x,y=position
    return sum(area(rectangle([(l+x,b+y),(r+x,b+y),(r+x,t+y),(l+x,t+y)],window)) for l,b,r,t in boxes)

def minimum(boxes,window,hull):
    lo=[min(p[k] for p in hull) for k in [0,1]];hi=[max(p[k] for p in hull) for k in [0,1]];axes=[]
    for k in [0,1]:
        cuts={lo[k],hi[k]}
        for box in boxes:
            for source in [box[k],box[k+2]]:
                for target in [window[k],window[k+2]]:
                    p=target-source
                    if lo[k]<p<hi[k]:cuts.add(p)
        axes.append(sorted(cuts))
    cells=0;evaluations=0;stationaries=0;best=None
    def consider(p):
        nonlocal best,evaluations
        v=material(boxes,window,p);evaluations+=1;best=v if best is None else min(best,v);return v
    for l,r in zip(axes[0],axes[0][1:]):
        for b,t in zip(axes[1],axes[1][1:]):
            poly=rectangle(hull,(l,b,r,t))
            if not poly:continue
            cells+=1
            for p in poly:consider(p)
            for a,z in zip(poly,poly[1:]+poly[:1]):
                if a==z:continue
                at=lambda tau:tuple(a[k]+tau*(z[k]-a[k]) for k in [0,1])
                q0=material(boxes,window,a);q1=material(boxes,window,at(F(1,3)));q2=material(boxes,window,at(F(2,3)));evaluations+=3
                d1=q1-q0;d2=q2-q0;qa=F(9,2)*(d2-2*d1);qb=3*d1-qa/3
                assert q0+qa+qb==material(boxes,window,z);evaluations+=1
                if qa>0:
                    tau=-qb/(2*qa)
                    if 0<tau<1:
                        value=consider(at(tau));assert value==q0+qb*tau+qa*tau*tau;stationaries+=1
    assert best is not None
    return {'minimum':best,'cells':cells,'area_evaluations':evaluations,'stationary_candidates':stationaries}
