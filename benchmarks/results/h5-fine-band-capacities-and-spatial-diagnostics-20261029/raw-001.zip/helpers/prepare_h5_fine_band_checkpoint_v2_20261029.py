"""Correct the sealer-template boundary; preserve the failed first preparation helper."""
from pathlib import Path
source=Path(__file__).with_name('prepare_h5_fine_band_checkpoint_20261029.py')
code=source.read_text(encoding='utf-8')
assert code.count("old.index('copies=[]')")==1
code=code.replace("old.index('copies=[]')","old.index('copies=[')")
exec(compile(code,str(source),'exec'))
