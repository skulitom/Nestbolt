"""Exact rectangle-union material minima over a convex translation hull."""
from fractions import Fraction as F

def material(boxes,window,position):
    L,B,R,T=window;x,y=position
    return sum(max(F(0),min(r+x,R)-max(l+x,L))*max(F(0),min(t+y,T)-max(b+y,B)) for l,b,r,t in boxes)

def minimum_material(boxes,window,hull):
    assert len(hull)>=3
    L,B,R,T=window
    xc=sorted({cut-edge for l,b,r,t in boxes for cut in [L,R] for edge in [l,r]})
    yc=sorted({cut-edge for l,b,r,t in boxes for cut in [B,T] for edge in [b,t]})
    signed=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(hull,hull[1:]+hull[:1]));assert signed
    direction=1 if signed>0 else -1
    def inside(p):return all(direction*((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]))>=0 for a,b in zip(hull,hull[1:]+hull[:1]))
    best=None;point=None;grid_cases=edge_cases=stationary_cases=0
    def consider(p):
        nonlocal best,point
        v=material(boxes,window,p)
        if best is None or v<best:best,point=v,p
        return v
    # Within each source/window breakpoint cell, the objective is bilinear.
    # A nonconstant bilinear function has no strict interior minimum. Its
    # polygon boundary is linear on axis edges and quadratic on hull edges.
    for x in xc:
        for y in yc:
            if inside((x,y)):consider((x,y));grid_cases+=1
    for a,b in zip(hull,hull[1:]+hull[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1];stops={F(0),F(1)}
        for delta,start,cuts in [(dx,a[0],xc),(dy,a[1],yc)]:
            if delta:
                for cut in cuts:
                    tau=(cut-start)/delta
                    if 0<tau<1:stops.add(tau)
        stops=sorted(stops)
        at=lambda tau:(a[0]+dx*tau,a[1]+dy*tau)
        values={tau:consider(at(tau)) for tau in stops};edge_cases+=len(stops)
        for lo,hi in zip(stops,stops[1:]):
            q0,q1=values[lo],values[hi];qh=material(boxes,window,at((lo+hi)/2));qa=2*(q1+q0-2*qh);qb=q1-q0-qa
            if qa>0:
                tau=-qb/(2*qa)
                if 0<tau<1:
                    value=consider(at(lo+(hi-lo)*tau));assert value==qa*tau*tau+qb*tau+q0;stationary_cases+=1
    assert best is not None and inside(point)
    return {'minimum':best,'minimizer':point,'grid_cases':grid_cases,'edge_cases':edge_cases,'stationary_cases':stationary_cases}

def vertex_upper_estimates(boxes,hull,windows):
    import numpy as np
    L,B,R,T=windows.T;result=np.full(len(windows),np.inf)
    for p in hull:
        x,y=map(float,p);values=np.zeros(len(windows))
        for box in boxes:
            l,b,r,t=map(float,box)
            values+=np.maximum(0,np.minimum(r+x,R)-np.maximum(l+x,L))*np.maximum(0,np.minimum(t+y,T)-np.maximum(b+y,B))
        np.minimum(result,values,out=result)
    return result
