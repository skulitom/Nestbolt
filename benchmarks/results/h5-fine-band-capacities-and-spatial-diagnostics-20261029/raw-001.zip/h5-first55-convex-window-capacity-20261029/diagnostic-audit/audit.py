"""Read both complete window diagnostics and independently sample their source bounds."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time
import numpy as np
import h5_window_geometry_20261029 as tested
import h5_window_clipping_oracle_20261029 as oracle
ROOT=Path(__file__).resolve().parents[1];BOX=ROOT/'output/h5-first55-component-window-capacity-20261029';CONVEX=ROOT/'output/h5-first55-convex-window-capacity-20261029';OUT=CONVEX/'diagnostic-audit';COUNT=ROOT/'output/h5-first55-strip-filtered-components-20261029';GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BOX/'plan.json',CONVEX/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
source=load(COUNT/'all25-filtered-bounds.json');unary=load(PRIOR/'integer-preparation/unary-templates.json');inner={f:[[[F(v) for v in b] for b in mode] for mode in opts] for f,opts in load(GENERIC/'source-inner-rectangles.json').items()}
for folder,name in [(BOX,'all25-window-bounds.json'),(CONVEX,'all25-convex-window-bounds.json')]:
    rows=load(folder/name);assert len(rows)==len(source)==25;total=0;screened=0
    for row,prior in zip(rows,source):
        nb=sum(g['family']=='bracket' for g in prior['groups']);ni=len(prior['groups'])-nb;subsets=((1<<nb)-1)*((1<<ni)-1)
        assert row['empty_sites']==prior['empty_sites'] and row['initial_distributions']==prior['remaining_distributions'] and row['remaining_distributions']==sorted(prior['remaining_distributions'])
        assert row['certificates']==[] and row['windows_recomputed_exactly']==0 and row['scan_complete'] and not row['restricted_construction_excluded']
        assert row['mixed_subsets_completed']==subsets and row['windows_screened']==subsets*6600
        total+=len(row['remaining_distributions']);screened+=row['windows_screened']
    checks=load(folder/'checks.json');assert checks['passed'] and checks['scan_complete'] and checks['cap_overrun_seconds']==0 and checks['remaining_count_distributions']==total==82 and checks['windows_screened']==screened==1881000
samples=[];clippings=cells=stationaries=0;maxerror=0.
for index,row in enumerate(source):
    for variant in [0,1]:
        f,m,gid,ri,gi=row['region_component_assignments'][(index*17+variant*43)%len(row['region_component_assignments'])]
        raw=next(r for r in unary[gid]['regions'] if r['region']==ri);hull=[tuple(map(F,p)) for p in raw['hull_vertices']];boxes=inner[f][m]
        xmin=min(x for x,y in hull);xmax=max(x for x,y in hull);ymin=min(y for x,y in hull);ymax=max(y for x,y in hull)
        cx=(xmin+xmax+min(b[0] for b in boxes)+max(b[2] for b in boxes))/2;cy=(ymin+ymax+min(b[1] for b in boxes)+max(b[3] for b in boxes))/2
        l=max(0,100*math.floor(cx/100)-100);b=max(2000,100*math.floor(cy/100)-100);r=min(1500,l+300);t=min(3000,b+300);window=tuple(map(F,(l,b,r,t)))
        result=tested.minimum_material(boxes,window,hull);expected=oracle.minimum(boxes,window,hull)
        assert result['minimum']==expected['minimum']==oracle.material(boxes,window,result['minimizer'])
        # A single rectangle's overlap minimum on an axis-aligned box occurs
        # at one of its four corners; sum the separate clipping minima.
        lower=sum(min(oracle.material([box],window,(x,y)) for x in [xmin,xmax] for y in [ymin,ymax]) for box in boxes)
        exact_upper=min(oracle.material(boxes,window,p) for p in hull)
        estimate=float(tested.vertex_upper_estimates(boxes,hull,np.array([[float(v) for v in window]]))[0]);error=abs(estimate-float(exact_upper))
        assert lower<=result['minimum']<=exact_upper and error<1e-4;maxerror=max(maxerror,error)
        cells+=expected['cells'];clippings+=expected['area_evaluations']+1+4*len(boxes)+len(hull);stationaries+=expected['stationary_candidates']
        samples.append({'empty_sites':row['empty_sites'],'source_key':[f,m,gid,ri],'group':gi,'window_mm':[str(v) for v in window],'box_lower_bound_mm2':str(lower),'convex_minimum_mm2':str(result['minimum']),'vertex_upper_bound_mm2':str(exact_upper),'float_upper_estimate_error_mm2':error,'oracle_cells':expected['cells']})
write(OUT/'source-samples.json',samples);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),Path(tested.__file__),Path(oracle.__file__)]+[folder/name for folder,names in [(BOX,['plan.json','checks.json','all25-window-bounds.json']),(CONVEX,['plan.json','checks.json','all25-convex-window-bounds.json'])] for name in names]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'diagnostics_verified':2,'screening_shape_verified_per_diagnostic':1881000,'independent_exact_source_minimum_samples':len(samples),'independent_convex_subcells':cells,'independent_clip_area_evaluations':clippings,'sample_stationary_candidates_verified':stationaries,'maximum_sample_floating_error_mm2':maxerror,'all_remaining_count_sets_preserved':True,'all_screened_window_values_independently_recomputed':False,'diagnostic_only_not_a_proof_of_no_stronger_window_bounds':True,'remaining_count_distributions':82,'restricted_pairs_remaining':25,'new_restricted_site_exclusions':0,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
