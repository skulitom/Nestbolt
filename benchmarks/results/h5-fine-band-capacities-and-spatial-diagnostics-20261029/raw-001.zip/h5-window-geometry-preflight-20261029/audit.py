"""Independent exact clipping preflight for convex-hull window minima."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,random,shutil,time
import h5_window_geometry_20261029 as tested
import h5_window_clipping_oracle_20261029 as oracle
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-window-geometry-preflight-20261029'
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def convex(points):
    points=sorted(set(points))
    def half(points):
        result=[]
        for p in points:
            while len(result)>1:
                a,b=result[-2:]
                if (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])>0:break
                result.pop()
            result.append(p)
        return result
    return half(points)[:-1]+half(points[::-1])[:-1]
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();rng=random.Random(81753);cases=[];stationaries=evaluations=cells=0
for number in range(120):
    boxes=[]
    for _ in range(1+number%3):
        l,b=F(rng.randrange(-10,10)),F(rng.randrange(-10,10));boxes.append((l,b,l+rng.randrange(2,20),b+rng.randrange(2,20)))
    hull=convex([(F(rng.randrange(-15,16)),F(rng.randrange(-15,16))) for _ in range(8)])
    assert len(hull)>=3
    l,b=F(rng.randrange(-10,11)),F(rng.randrange(-10,11));window=(l,b,l+rng.randrange(2,25),b+rng.randrange(2,25))
    got=tested.minimum_material(boxes,window,hull);expected=oracle.minimum(boxes,window,hull)
    assert got['minimum']==expected['minimum']==oracle.material(boxes,window,got['minimizer'])
    stationaries+=expected['stationary_candidates'];evaluations+=expected['area_evaluations']+1;cells+=expected['cells']
    cases.append({'boxes':[[str(v) for v in q] for q in boxes],'hull':[[str(v) for v in p] for p in hull],'window':[str(v) for v in window],'minimum':str(got['minimum']),'minimizer':[str(v) for v in got['minimizer']],'grid_candidates':got['grid_cases'],'boundary_stationary_candidates':got['stationary_cases'],'oracle_cells':expected['cells']})
assert stationaries>0
write(OUT/'cases.json',cases);paths=[Path(__file__),Path(tested.__file__),Path(oracle.__file__)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in paths},'scope':'Exact deterministic geometry cases, not packing calls or production source placements. The independent oracle clips the translation hull into every bilinear breakpoint cell, clips translated source rectangles into the window, and minimizes each boundary quadratic using one-third interpolation.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'oracle_cases':len(cases),'convex_subcells_verified':cells,'interior_edge_stationary_candidates_verified':stationaries,'independent_polygon_clip_area_evaluations':evaluations,'all_exact_minima_match':True,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
