"""Audit all projections and retention; independently sample diagonal minima with exact clipping."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
import numpy as np
import h5_diagonal_strip_geometry_20261029 as tested
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-diagonal-strip-capacity-20261029';OUT=BASE/'diagnostic-audit';COUNT=ROOT/'output/h5-first55-strip-filtered-components-20261029';GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def clipped(poly,normal,above,cut):
    out=[];nx,ny=normal
    for a,b in zip(poly,poly[1:]+poly[:1]):
        da=nx*a[0]+ny*a[1];db=nx*b[0]+ny*b[1];ina=da>=cut if above else da<=cut;inb=db>=cut if above else db<=cut
        if ina:out.append(a)
        if ina!=inb:
            tau=(cut-da)/(db-da);out.append(tuple(a[k]+tau*(b[k]-a[k]) for k in [0,1]))
    return out
def area(poly):return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1])))/2 if poly else F(0)
def clipped_area(boxes,normal,left,right,shift):
    value=F(0);dx=shift/normal[0]
    for l,b,r,t in boxes:value+=area(clipped(clipped([(l+dx,b),(r+dx,b),(r+dx,t),(l+dx,t)],normal,True,left),normal,False,right))
    return value
def oracle_minimum(boxes,normal,intervals,left,right):
    best=None;endpoints=stationaries=evaluations=0
    for lo,hi in intervals:
        stops={lo,hi}
        for l,b,r,t in boxes:
            for x,y in [(l,b),(r,b),(r,t),(l,t)]:
                for cut in [left,right]:
                    shift=cut-normal[0]*x-normal[1]*y
                    if lo<shift<hi:stops.add(shift)
        ordered=sorted(stops)
        for shift in ordered:
            value=clipped_area(boxes,normal,left,right,shift);best=value if best is None else min(best,value);endpoints+=1;evaluations+=1
        for a,b in zip(ordered,ordered[1:]):
            q0=clipped_area(boxes,normal,left,right,a);q1=clipped_area(boxes,normal,left,right,a+(b-a)/3);q2=clipped_area(boxes,normal,left,right,a+2*(b-a)/3);evaluations+=3
            da=q1-q0;db=q2-q0;qa=F(9,2)*(db-2*da);qb=3*da-qa/3
            assert q0+qa+qb==clipped_area(boxes,normal,left,right,b);evaluations+=1
            if qa>0:
                tau=-qb/(2*qa)
                if 0<tau<1:
                    value=clipped_area(boxes,normal,left,right,a+(b-a)*tau);assert value==q0+qb*tau+qa*tau*tau;best=min(best,value);stationaries+=1;evaluations+=1
    return best,endpoints,stationaries,evaluations
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
assert load(COUNT/'audit/checks.json')['passed'];sources=load(COUNT/'all25-filtered-bounds.json');rows=load(BASE/'all25-diagonal-strip-bounds.json');assert len(rows)==len(sources)==25
unary=load(PRIOR/'integer-preparation/unary-templates.json');inner={f:[[[F(v) for v in b] for b in mode] for mode in opts] for f,opts in load(GENERIC/'source-inner-rectangles.json').items()};normals=[(1,1),(1,-1),(2,1),(1,2),(2,-1),(1,-2)];raw_intervals=union_intervals=screened=0;samples=[];max_error=0.;stationary_samples=clip_evaluations=0
for row_index,(row,source) in enumerate(zip(rows,sources)):
    assert row['empty_sites']==source['empty_sites'] and row['initial_distributions']==row['remaining_distributions']==source['remaining_distributions'] and not row['restricted_construction_excluded'] and row['scan_complete']
    assert [r['normal'] for r in row['directions']]==[list(n) for n in normals];groups=source['groups'];nb=sum(g['family']=='bracket' for g in groups);ni=len(groups)-nb;subset_count=((1<<nb)-1)*((1<<ni)-1)
    for di,record in enumerate(row['directions']):
        normal=normals[di];nx,ny=normal;events=[{} for g in groups]
        for f,m,gid,ri,gi in source['region_component_assignments']:
            points=next(r['hull_vertices'] for r in unary[gid]['regions'] if r['region']==ri);values=[nx*F(x)+ny*F(y) for x,y in points];lo,hi=min(values),max(values);assert lo<hi;raw_intervals+=1;e=events[gi].setdefault(m,{});e[lo]=e.get(lo,0)+1;e[hi]=e.get(hi,0)-1
        projections=[]
        for by_mode in events:
            p={}
            for mode,e in by_mode.items():
                balance=0;start=None;intervals=[]
                for x,delta in sorted(e.items()):
                    old=balance;balance+=delta;assert balance>=0
                    if old==0 and balance>0:start=x
                    if old>0 and balance==0:assert start is not None;intervals.append((start,x));start=None
                assert balance==0 and intervals and start is None;p[mode]=intervals;union_intervals+=len(intervals)
            projections.append(p)
        assert record['projection_intervals_mm']==[{str(m):[[str(v) for v in i] for i in intervals] for m,intervals in p.items()} for p in projections]
        low=min(0,nx*1500)+min(ny*2000,ny*3000);high=max(0,nx*1500)+max(ny*2000,ny*3000);cuts=(high-low)//50+1;strips=cuts*(cuts-1)//2
        assert record['scan_complete'] and record['mixed_subsets_completed']==subset_count and record['strips_screened']==strips*subset_count and record['certificates']==[] and record['strips_recomputed_exactly']==0;screened+=record['strips_screened']
        gi=(row_index+di)%len(groups);mode=sorted(projections[gi])[(2*row_index+di)%len(projections[gi])];intervals=projections[gi][mode];boxes=inner[groups[gi]['family']][mode];corners=[nx*x+ny*y for l,b,r,t in boxes for x,y in [(l,b),(r,b),(r,t),(l,t)]];lo=intervals[0][0]+min(corners);hi=intervals[-1][1]+max(corners)
        left=F(50*((2*lo+hi)//150));right=F(50*(-(-((lo+2*hi)/3)//50)));left=max(F(low),left);right=min(F(high),right)
        assert left<right and left%50==right%50==0
        result=tested.minimum_strip_material(boxes,normal,tuple(intervals),left,right);exact,endpoint_count,stationary_count,evaluations=oracle_minimum(boxes,normal,intervals,left,right);stationary_samples+=stationary_count;clip_evaluations+=evaluations
        assert result['minimum']==exact and clipped_area(boxes,normal,left,right,result['minimizer'])==exact
        estimate=float(tested.estimated_strip_minima(boxes,normal,tuple(intervals),np.array([float(left)]),np.array([float(right)]))[0]);error=abs(estimate-float(exact));assert error<1e-4;max_error=max(max_error,error)
        samples.append({'empty_sites':row['empty_sites'],'normal':list(normal),'group':gi,'mode':mode,'strip':[str(left),str(right)],'minimum':str(exact),'floating_estimate':estimate,'absolute_error_mm2':error,'independent_endpoint_cases':endpoint_count,'independent_stationary_cases':stationary_count,'independent_clip_area_evaluations':evaluations})
assert screened==3990000 and len(samples)==150 and sum(len(r['remaining_distributions']) for r in rows)==82
check=load(BASE/'checks.json');assert check['count_distributions_excluded']==0 and check['new_restricted_site_exclusions']==0 and check['certificates']==0 and check['cap_overrun_seconds']==0
write(OUT/'source-minimum-samples.json',samples);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),Path(tested.__file__)]+[BASE/n for n in ['plan.json','checks.json','all25-diagonal-strip-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_projection_intervals_verified':raw_intervals,'merged_projection_intervals_verified':union_intervals,'screening_shape_verified':screened,'independent_exact_source_minimum_samples':len(samples),'sample_interior_stationary_candidates_verified':stationary_samples,'independent_clip_area_evaluations':clip_evaluations,'maximum_sample_floating_error_mm2':max_error,'all_remaining_count_sets_preserved':True,'all3990000_strip_values_independently_recomputed':False,'diagnostic_only_not_a_proof_of_no_stronger_diagonal_bounds':True,'remaining_count_distributions':82,'restricted_pairs_remaining':25,'new_restricted_site_exclusions':0,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
