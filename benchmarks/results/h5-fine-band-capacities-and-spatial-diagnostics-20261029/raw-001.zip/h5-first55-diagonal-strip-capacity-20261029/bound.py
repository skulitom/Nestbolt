"""Exact-certified diagonal strip discovery over the retained continuous source components."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
from functools import lru_cache
import itertools,json,shutil,time
import numpy as np
import h5_diagonal_strip_geometry_20261029 as geometry
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';COUNT=ROOT/'output/h5-first55-strip-filtered-components-20261029';GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';PREFLIGHT=ROOT/'output/h5-diagonal-strip-geometry-preflight-20261029';OUT=ROOT/'output/h5-first55-diagonal-strip-capacity-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(COUNT/'audit/checks.json')['passed'] and load(PREFLIGHT/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py');started=time.perf_counter()
inner={f:[[[F(v) for v in b] for b in mode] for mode in opts] for f,opts in load(GENERIC/'source-inner-rectangles.json').items()};unary=load(PRIOR/'integer-preparation/unary-templates.json');normals=[(1,1),(1,-1),(2,1),(1,2),(2,-1),(1,-2)];cell=(F(0),F(0),F(10),F(10));direction_data={}
for normal in normals:
    nx,ny=normal;lo=min(0,nx*1500)+min(ny*2000,ny*3000);hi=max(0,nx*1500)+max(ny*2000,ny*3000);cuts=list(range(lo,hi+1,50));pairs=list(itertools.combinations(range(len(cuts)),2));direction_data[normal]={'cuts':cuts,'pairs':pairs,'left':np.array([cuts[a] for a,b in pairs],dtype=np.float64),'right':np.array([cuts[b] for a,b in pairs],dtype=np.float64),'a':np.array([a for a,b in pairs],dtype=np.int64),'b':np.array([b for a,b in pairs],dtype=np.int64)}
assert sum(len(v['pairs']) for v in direction_data.values())==14000
def merge(intervals):
    result=[]
    for lo,hi in sorted(intervals):
        if result and lo<=result[-1][1]:result[-1]=(result[-1][0],max(hi,result[-1][1]))
        else:result.append((lo,hi))
    return tuple(result)
@lru_cache(None)
def hull_interval(gid,ri,normal):
    nx,ny=normal;points=unary[gid]['regions'][ri]['hull_vertices'];values=[nx*F(x)+ny*F(y) for x,y in points];return min(values),max(values)
@lru_cache(None)
def estimated_mode(f,m,normal,intervals):
    d=direction_data[normal];return geometry.estimated_strip_minima(inner[f][m],normal,intervals,d['left'],d['right'])
@lru_cache(None)
def exact_mode(f,m,normal,intervals,left,right):return geometry.minimum_strip_material(inner[f][m],normal,intervals,F(left),F(right))
@lru_cache(None)
def cell_below(normal,cut):return geometry.rectangle_below(cell,normal,F(cut))
rows=[];initial_total=remaining_total=cert_count=0;subsets_done=strips_screened=exact_strips=endpoint_cases=stationary_cases=0;all_complete=True
for prior in load(COUNT/'all25-filtered-bounds.json'):
    groups=prior['groups'];possible={tuple(v) for v in prior['remaining_distributions']};initial_total+=len(possible);direction_records=[]
    subsets=[]
    for mask in range(1,1<<len(groups)):
        selected=[i for i in range(len(groups)) if mask>>i&1]
        if {groups[i]['family'] for i in selected}!={'bracket','insert'}:continue
        bits=0
        for i in selected:bits|=int(groups[i]['support_hex'],16)
        positions=[]
        while bits:
            bit=bits&-bits;y,x=divmod(bit.bit_length()-1,150);positions.append((10*x,2000+10*y));bits^=bit
        subsets.append((selected,np.array(positions,dtype=np.int64)))
    for normal in normals:
        if time.perf_counter()-started>=58:all_complete=False;break
        d=direction_data[normal];raw=[{} for g in groups]
        for f,m,gid,ri,gi in prior['region_component_assignments']:raw[gi].setdefault(m,[]).append(hull_interval(gid,ri,normal))
        projections=[{m:merge(intervals) for m,intervals in by_mode.items()} for by_mode in raw];estimates=np.zeros((len(d['pairs']),len(groups)));complete=True
        for gi,g in enumerate(groups):
            if time.perf_counter()-started>=58:complete=False;all_complete=False;break
            estimates[:,gi]=np.min(np.array([estimated_mode(g['family'],m,normal,intervals) for m,intervals in projections[gi].items()]),axis=0)
        records=[];completed=screened=checked=endpoints=stationaries=0
        for selected,positions in subsets:
            if not complete or time.perf_counter()-started>=58:complete=False;all_complete=False;break
            offsets,frequencies=np.unique(positions[:,0]*normal[0]+positions[:,1]*normal[1],return_counts=True)
            below=geometry.estimated_rectangle_below(cell,normal,np.array(d['cuts'],dtype=np.float64)[:,None]-offsets[None,:])@frequencies
            available=below[d['b']]-below[d['a']];screened+=len(d['pairs']);strips_screened+=len(d['pairs'])
            if possible:
                counts=np.array(sorted(possible),dtype=np.float64);estimate=counts[:,selected]@estimates[:,selected].T;candidate_indices=np.flatnonzero(np.any((estimate>available-1e-4)&(estimate>1e-4),axis=0))
            else:candidate_indices=[]
            for si in candidate_indices:
                if time.perf_counter()-started>=58:complete=False;all_complete=False;break
                a,b=d['pairs'][int(si)];left,right=d['cuts'][a],d['cuts'][b];upper=sum(int(count)*(cell_below(normal,right-int(offset))-cell_below(normal,left-int(offset))) for offset,count in zip(offsets,frequencies));values={};coefficients=[F(0)]*len(groups);case_endpoints=case_stationaries=0
                for gi in selected:
                    g=groups[gi];values[str(gi)]={}
                    for m,intervals in projections[gi].items():
                        result=exact_mode(g['family'],m,normal,intervals,left,right);case_endpoints+=result['endpoint_cases'];case_stationaries+=result['stationary_cases'];values[str(gi)][str(m)]={k:str(v) if isinstance(v,F) else v for k,v in result.items()}
                    coefficients[gi]=min(F(v['minimum']) for v in values[str(gi)].values())
                checked+=1;exact_strips+=1;endpoints+=case_endpoints;endpoint_cases+=case_endpoints;stationaries+=case_stationaries;stationary_cases+=case_stationaries
                removed=sorted(v for v in possible if sum(v[i]*coefficients[i] for i in selected)>upper)
                if removed:records.append({'groups':selected,'normal':list(normal),'strip_projection':[left,right],'upper_area_mm2':str(upper),'selected_group_mode_minima':values,'coefficients_mm2':[str(v) for v in coefficients],'distributions_removed':[list(v) for v in removed]});possible.difference_update(removed)
            if not complete:break
            completed+=1;subsets_done+=1
        cert_count+=len(records)
        direction_records.append({'normal':list(normal),'projection_intervals_mm':[{str(m):[[str(v) for v in interval] for interval in intervals] for m,intervals in by_mode.items()} for by_mode in projections],'certificates':records,'mixed_subsets_completed':completed,'strips_screened':screened,'strips_recomputed_exactly':checked,'source_endpoint_cases':endpoints,'source_stationary_cases':stationaries,'scan_complete':complete})
        if not complete:break
    complete=len(direction_records)==len(normals) and all(r['scan_complete'] for r in direction_records);all_complete=all_complete and complete;remaining_total+=len(possible)
    rows.append({'empty_sites':prior['empty_sites'],'initial_distributions':prior['remaining_distributions'],'directions':direction_records,'remaining_distributions':[list(v) for v in sorted(possible)],'scan_complete':complete,'restricted_construction_excluded':not possible})
elapsed=time.perf_counter()-started
inputs=[Path(__file__),Path(geometry.__file__),PREFLIGHT/'plan.json',PREFLIGHT/'checks.json',COUNT/'plan.json',COUNT/'audit/plan.json',COUNT/'audit/checks.json',COUNT/'all25-filtered-bounds.json',GENERIC/'source-inner-rectangles.json',PRIOR/'integer-preparation/unary-templates.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'normals':[list(n) for n in normals],'projection_cut_spacing':50,'strips_per_mixed_subset_all_directions':14000,'method':'Project every source unary hull onto each diagonal normal and merge allowed intervals by mode and source component. Minimize mandatory contained-rectangle area inside each strip at all interval/source-corner breakpoints and every interior stationary minimum of each exact quadratic piece. Compare selected count-weighted minima with the exact conservative support-cell strip area. Floating estimates only screen proposed violations; every exclusion is an exact rational certificate. Retain all unprocessed distributions after the fixed cap.','discovery_cap_seconds':60,'stop_starting_work_after_seconds':58,'unprocessed_distributions_retained':True,'floating_exclusions_permitted':False,'solver_calls':0,'native_calls':0,'global_allocation_exclusion_permitted':False})
write(OUT/'all25-diagonal-strip-bounds.json',rows)
checks={'passed':True,'seconds':elapsed,'cap_overrun_seconds':max(0,elapsed-60),'scan_complete':all_complete,'site_pairs_retained_in_table':len(rows),'initial_count_distributions':initial_total,'remaining_count_distributions':remaining_total,'count_distributions_excluded':initial_total-remaining_total,'certificates':cert_count,'mixed_subset_directions_completed':subsets_done,'strips_screened':strips_screened,'strips_recomputed_exactly':exact_strips,'source_endpoint_cases':endpoint_cases,'source_stationary_cases':stationary_cases,'new_restricted_site_exclusions':sum(r['restricted_construction_excluded'] for r in rows),'restricted_pairs_remaining':sum(not r['restricted_construction_excluded'] for r in rows),'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
