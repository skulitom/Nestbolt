"""Validate the closed fine-band strip diagnostic and independently clip sampled support unions."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
import h5_window_clipping_oracle_20261029 as oracle
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-fine-band-strip-capacity-20261029';OUT=BASE/'diagnostic-audit';FINE=ROOT/'output/h5-first55-fine-band-capacity-20261029';FILTER=ROOT/'output/h5-first55-strip-filtered-components-20261029';OLD=ROOT/'output/h5-first55-component-strip-capacity-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def merge(spans):
    events={}
    for lo,hi in spans:events[lo]=events.get(lo,0)+1;events[hi]=events.get(hi,0)-1
    level=0;result=[]
    for x,delta in sorted(events.items()):
        old=level;level+=delta
        if old==0 and level>0:start=x
        if old>0 and level==0:result.append((start,x))
    assert level==0
    return result
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for n,h in load(p).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n;bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
source={tuple(r['empty_sites']):r for r in load(FILTER/'all25-filtered-bounds.json')};fine={tuple(r['empty_sites']):r for r in load(FINE/'all25-fine-band-bounds.json') if r['remaining_distributions']};old={tuple(r['empty_sites']):r for r in load(OLD/'all29-strip-bounds.json')};rows=load(BASE/'all18-fine-band-strip-bounds.json')
assert len(rows)==len(fine)==18 and {tuple(r['empty_sites']) for r in rows}==set(fine)
samples=[];clippings=0;screened=0;total=0
for index,row in enumerate(rows):
    key=tuple(row['empty_sites']);src=source[key];proof=fine[key];nb=sum(g['family']=='bracket' for g in src['groups']);ni=len(src['groups'])-nb;subsets=((1<<nb)-1)*((1<<ni)-1)
    assert row['initial_distributions']==proof['remaining_distributions'] and row['remaining_distributions']==proof['remaining_distributions'] and row['certificates']==[] and row['strips_recomputed_exactly']==0 and row['source_breakpoint_cases']==0 and row['scan_complete'] and not row['restricted_construction_excluded']
    assert row['projection_intervals_mm']==old[key]['projection_intervals_mm'] and row['mixed_subsets_completed']==subsets and row['strips_screened']==16375*subsets
    screened+=row['strips_screened'];total+=len(row['remaining_distributions'])
    # Two sampled mixed-family unions per retained site choice, two axes each.
    for variant in [0,1]:
        selected=list(range(len(src['groups']))) if variant==0 else [index%nb,nb+index%ni];events={}
        for i in selected:
            for y,lo,hi in proof['groups'][i]['band_spans_tenths_mm']:events.setdefault(y,[]).append((lo,hi))
        bands=[(y,lo,hi) for y,v in events.items() for lo,hi in merge(v)]
        for axis in [0,1]:
            left=100*(index%9) if axis==0 else 2000+100*(index%6);right=left+300;window=(F(left),F(2000),F(right),F(3000)) if axis==0 else (F(0),F(left),F(1500),F(right))
            boxes=[(F(lo,10),F(y*2),F(hi,10),F((y+1)*2)) for y,lo,hi in bands]
            exact=oracle.material(boxes,window,(F(0),F(0)));clippings+=len(boxes)
            direct=F(sum(max(0,min(hi,right*10)-max(lo,left*10)) if axis==0 else (hi-lo) if left<=y*2 and (y+1)*2<=right else 0 for y,lo,hi in bands),5)
            assert direct==exact;samples.append({'empty_sites':list(key),'groups':selected,'axis':axis,'strip_mm':[left,right],'upper_area_mm2':str(exact)})
assert screened==3537000 and total==42
write(OUT/'support-area-samples.json',samples);write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__),Path(oracle.__file__),OLD/'audit/plan.json',OLD/'audit/checks.json',OLD/'all29-strip-bounds.json']+[BASE/n for n in ['plan.json','checks.json','all18-fine-band-strip-bounds.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_projections_match_previously_independent_audit':True,'screening_shape_verified':screened,'independent_support_area_samples':len(samples),'independent_polygon_clippings':clippings,'all_remaining_count_sets_preserved':True,'all_screened_strip_values_independently_recomputed':False,'diagnostic_only_not_a_proof_of_no_stronger_strip_bounds':True,'remaining_count_distributions':42,'restricted_pairs_remaining':18,'new_restricted_site_exclusions':0,'global_allocation_exclusions':0,'remaining_allocation_candidates':440,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
