"""Independent clipping oracle, using one-third interpolation for stationary candidates."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,random,shutil,time
import h5_diagonal_strip_geometry_20261029 as tested
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-diagonal-strip-geometry-preflight-20261029'
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def clipped(poly,normal,above,cut):
    out=[];nx,ny=normal
    for a,b in zip(poly,poly[1:]+poly[:1]):
        da=nx*a[0]+ny*a[1];db=nx*b[0]+ny*b[1];ina=da>=cut if above else da<=cut;inb=db>=cut if above else db<=cut
        if ina:out.append(a)
        if ina!=inb:
            tau=(cut-da)/(db-da);out.append(tuple(a[k]+tau*(b[k]-a[k]) for k in [0,1]))
    return out
def area(poly):return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1])))/2 if poly else F(0)
def oracle(boxes,normal,left,right,shift):
    value=F(0);dx=shift/normal[0]
    for l,b,r,t in boxes:
        poly=[(l+dx,b),(r+dx,b),(r+dx,t),(l+dx,t)];value+=area(clipped(clipped(poly,normal,True,left),normal,False,right))
    return value
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();rng=random.Random(7841);directions=[(1,1),(1,-1),(2,1),(1,2),(2,-1),(1,-2)];cases=[];stationary_total=0;clip_evaluations=0
for number in range(120):
    normal=directions[number%6];boxes=[]
    for _ in range(1+number%3):
        l,b=F(rng.randrange(-20,20)),F(rng.randrange(-20,20));boxes.append([l,b,l+rng.randrange(2,20),b+rng.randrange(2,20)])
    lo=F(rng.randrange(-30,0));hi=F(rng.randrange(1,31));left=F(rng.randrange(-30,30));right=left+rng.randrange(1,31);intervals=[(lo,hi)]
    result=tested.minimum_strip_material(boxes,normal,intervals,left,right);stops={lo,hi}
    for l,b,r,t in boxes:
        for x,y in [(l,b),(r,b),(r,t),(l,t)]:
            for cut in [left,right]:
                shift=cut-normal[0]*x-normal[1]*y
                if lo<shift<hi:stops.add(shift)
    ordered=sorted(stops);best=None
    for shift in ordered:
        value=oracle(boxes,normal,left,right,shift);clip_evaluations+=1;assert value==tested.strip_material(boxes,normal,left,right,shift);best=value if best is None else min(best,value)
    for a,b in zip(ordered,ordered[1:]):
        q0=oracle(boxes,normal,left,right,a);qthird=oracle(boxes,normal,left,right,a+(b-a)/3);qtwothirds=oracle(boxes,normal,left,right,a+2*(b-a)/3);clip_evaluations+=3
        da=qthird-q0;db=qtwothirds-q0;qa=F(9,2)*(db-2*da);qb=3*da-qa/3
        assert q0+qa+qb==oracle(boxes,normal,left,right,b);clip_evaluations+=1
        if qa>0:
            tau=-qb/(2*qa)
            if 0<tau<1:
                value=oracle(boxes,normal,left,right,a+(b-a)*tau);clip_evaluations+=1;assert value==q0+qb*tau+qa*tau*tau;best=min(best,value);stationary_total+=1
    assert result['minimum']==best==oracle(boxes,normal,left,right,result['minimizer']);clip_evaluations+=1
    cases.append({'normal':list(normal),'boxes':[[str(v) for v in box] for box in boxes],'intervals':[[str(v) for v in i] for i in intervals],'strip':[str(left),str(right)],'minimum':str(best),'minimizer':str(result['minimizer']),'stationary_cases':result['stationary_cases']})
assert stationary_total>0
write(OUT/'cases.json',cases);paths=[Path(__file__),Path(tested.__file__)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in paths},'scope':'Deterministic exact mathematical oracle cases, not production source placements or packing calls.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'normal_directions':6,'oracle_cases':len(cases),'interior_stationary_candidates_verified':stationary_total,'independent_polygon_clip_area_evaluations':clip_evaluations,'all_exact_minima_match':True,'floating_screening_not_used_for_exclusions':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
