"""Audit every completed release case against the frozen geometric primitives."""
from fractions import Fraction as F
import json, shutil, time
from audit_h5_cog_reachable_area import exact_difference_area
from reduce_h5_free_cog_pool import ROOT, load, write, digest

CENTER=ROOT/'output/h5-cog-center-capacity-20261020'
AREA=ROOT/'output/h5-cog-reachable-area-20261020'
RUN=ROOT/'output/h5-single-non-cog-release-census-20261020'
OUT=RUN/'audit'
S=10000

def main():
    OUT.mkdir()
    shutil.copyfile(__file__,OUT/'audit.py')
    start=time.perf_counter()
    for p,h in load(RUN/'plan.json')['inputs'].items():
        assert digest(ROOT/p)==h
    result=load(RUN/'result.json')
    primitives=load(CENTER/'interior-rectangles.json')
    fixed=sorted({p['fixed_candidate'] for p in primitives})
    done=[r['removed_candidate'] for r in result['cases']]
    assert done+result['pending_candidates']==fixed and len(done)==result['cases_completed']
    disk=load(CENTER/'disk.json')
    separation=disk['center_separation_units']
    cog=load(AREA/'cog.json')
    radius=cog['circumradius_units']
    area_lower=F(*cog['filled_area_lower_bound'])
    pool=load(ROOT/'output/h5-insert-aligned-frame-pool-20261020/candidates.json')
    records=[]
    component_count=cover_count=0
    for removed in done:
        case=load(RUN/f'case-{removed}.json')
        assert case['removed_candidate']==removed
        assert case['part_id']==pool[removed]['placement']['part_id']
        bounds=[]
        for row in case['sheets']:
            sheet=row['sheet']
            original=load(CENTER/f'{sheet}.json')
            original_area=load(AREA/f'{sheet}.json')
            domain=row['center_domain_units']
            solid_domain=row['solid_domain_units']
            assert domain==original['domain_units'] and solid_domain==original_area['usable_domain_units']
            forbidden=[]
            solid=[]
            for p in primitives:
                if p['fixed_candidate']==removed or p['sheet_id']!=sheet:
                    continue
                a,b,c,d=p['inner_rectangle_units']
                for x,y in disk['offset_rectangles_half_sizes_units']:
                    rect=[max(domain[0],a-x),max(domain[1],b-y),min(domain[2],c+x),min(domain[3],d+y)]
                    if rect[0]<rect[2] and rect[1]<rect[3]:
                        forbidden.append(rect)
                rect=[max(solid_domain[0],a),max(solid_domain[1],b),
                      min(solid_domain[2],c),min(solid_domain[3],d)]
                if rect[0]<rect[2] and rect[1]<rect[3]:
                    solid.append(rect)
            assert forbidden==row['forbidden_rectangles'] and solid==row['solid_rectangles']
            free=row['free_cells']
            union_area=exact_difference_area(free,[])
            assert union_area==sum((c-a)*(d-b) for a,b,c,d in free)
            assert exact_difference_area(free,[domain])==0
            assert exact_difference_area(free,forbidden)==union_area
            assert exact_difference_area([domain],forbidden)==union_area
            assert exact_difference_area(original['free_cells_units'],free)==0
            seen=[]
            all_included=[]
            component_bounds=[]
            for comp in row['components']:
                component_count+=1
                ids=comp['cell_indices']
                seen.extend(ids)
                cells=[free[i] for i in ids]
                left,bottom,right,top=solid_domain
                included=[[max(left,a-radius),max(bottom,b-radius),min(right,c+radius),min(top,d+radius)]
                          for a,b,c,d in cells]
                assert included==comp['included_reachable_rectangles']
                all_included.extend(included)
                measure=exact_difference_area(included,solid)
                assert measure==comp['reachable_area_units_squared']
                area_bound=F(measure,S*S)//area_lower
                assert area_bound==comp['area_bound']
                bbox=comp['bounding_box_units']
                assert all(bbox[0]<=a<c<=bbox[2] and bbox[1]<=b<d<=bbox[3] for a,b,c,d in cells)
                grid=comp['grid']
                nx,ny=grid['columns'],grid['rows']
                assert nx>0 and ny>0 and grid['capacity']==nx*ny
                w,h=(bbox[2]-bbox[0]+nx-1)//nx,(bbox[3]-bbox[1]+ny-1)//ny
                assert w*w+h*h<separation*separation
                band_bounds=[]
                assert {c['axis'] for c in comp['band_covers']}=={'horizontal','vertical'}
                for cover in comp['band_covers']:
                    cover_count+=1
                    boxes=cover['rectangles_units']
                    assert len(boxes)==cover['capacity']
                    assert all(a<c and b<d and (c-a)**2+(d-b)**2<separation*separation for a,b,c,d in boxes)
                    assert exact_difference_area(cells,boxes)==0
                    band_bounds.append(len(boxes))
                bound=min(area_bound,nx*ny,*band_bounds)
                assert bound==comp['upper_bound']
                component_bounds.append(bound)
            assert sorted(seen)==list(range(len(free)))
            measure=exact_difference_area(all_included,solid)
            assert measure==row['whole_reachable_area_units_squared']
            whole_bound=F(measure,S*S)//area_lower
            assert whole_bound==row['whole_area_bound']
            bound=min(whole_bound,sum(component_bounds))
            assert bound==row['upper_bound']
            bounds.append(bound)
        total=sum(bounds)
        assert total==case['upper_bound'] and total>=9
        assert case['single_pose_change_ruled_out']==(total<15)
        records.append({'removed_candidate':removed,'part_id':case['part_id'],'sheet_bounds':bounds,
                        'upper_bound':total,'single_pose_change_ruled_out':total<15})
    assert sum(r['single_pose_change_ruled_out'] for r in records)==result['single_pose_changes_ruled_out']
    not_ruled_out=[r['removed_candidate'] for r in records if not r['single_pose_change_ruled_out']]
    assert not_ruled_out==result['not_ruled_out']
    summary={part:{'ruled_out':sum(r['part_id']==part and r['single_pose_change_ruled_out'] for r in records),
                   'inconclusive':sum(r['part_id']==part and not r['single_pose_change_ruled_out'] for r in records)}
             for part in ['frame','bracket','insert']}
    checks={'passed':True,'cases_verified':len(records),'pending_candidates':result['pending_candidates'],
            'components_verified':component_count,'band_covers_verified':cover_count,
            'all_complement_areas_exact':True,'all_reachable_areas_exact':True,
            'all_original_seed_center_regions_retained':True,'records':records,
            'by_part':summary,'not_ruled_out':not_ruled_out,'seconds':time.perf_counter()-start,
            'scope':'Only changes to one non-cog pose with all other50 held fixed. Inconclusive cases are not feasible layouts. Multiple non-cog changes remain possible.',
            'full_target_witness':False,'native_packing_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks)
    print(json.dumps({k:v for k,v in checks.items() if k!='records'}))

if __name__=='__main__':
    main()
