"""Alternate the two evaluators on exactly the four frozen validation cases."""
from pathlib import Path
from hashlib import sha256
import copy,json,time,statistics,os,ctypes
import numpy as np
from h5_cross_pair_weighted_model_20261107 import Objective as New
from h5_weighted_original_model_20261107 import Objective as Old
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cross-pair-preflight-20261107';OUT=BASE/'timing-v2'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();plan=load(BASE/'plan-v2.json');assert load(BASE/'audit-v2/checks.json')['passed']
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
for name,h in load(BASE/'audit-v2/runtime-bindings.json').items():assert digest(ROOT/name)==h,name
assert os.environ['OPENBLAS_NUM_THREADS']==os.environ['OMP_NUM_THREADS']==os.environ['MKL_NUM_THREADS']=='1'
from h5_checked_affinity_20261107 import affinity_mask
mask=ctypes.c_size_t(affinity_mask());assert mask.value==sum(1<<i for i in range(16,32))
records=[];reports=[];started=time.perf_counter()
for case in load(BASE/'cases.json'):
    if not case['timed']:continue
    mm=load(ROOT/case['model_path']);before=copy.deepcopy(mm);x=np.asarray(case['values']);original=x.copy();objects={'previous':Old(mm),'batched':New(mm)};reference=objects['previous'].evaluate(x)
    for obj in objects.values():
        for _ in range(plan['timing']['warmups_per_implementation']):obj.evaluate(x)
    samples={k:[] for k in objects}
    for repetition in range(plan['timing']['repetitions']):
        order=['previous','batched'] if repetition%2==0 else ['batched','previous']
        for position,name in enumerate(order):
            begin=time.perf_counter();e,g=objects[name].evaluate(x);elapsed=time.perf_counter()-begin
            assert e==reference[0] and np.max(np.abs(g-reference[1]))<plan['weighted_gradient_absolute_tolerance'];samples[name].append(elapsed);records.append({'case':case['name'],'repetition':repetition,'order_position':position,'implementation':name,'seconds':elapsed,'score':e,'maximum_gradient_error':float(np.max(np.abs(g-reference[1])))})
    assert np.array_equal(x,original) and mm==before
    medians={k:statistics.median(v) for k,v in samples.items()};reports.append({'case':case['name'],'samples_per_implementation':10,'median_seconds':medians,'median_speed_ratio':medians['previous']/medians['batched'],'minimum_seconds':{k:min(v) for k,v in samples.items()},'maximum_seconds':{k:max(v) for k,v in samples.items()}})
    print(reports[-1],flush=True)
write(OUT/'samples.json',records);write(OUT/'summary.json',reports)
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'fixed_cases':len(reports),'recorded_samples':len(records),'warmup_evaluations':16,'affinity_mask':mask.value,'blas_threads':1,'minimum_speed_ratio':min(r['median_speed_ratio'] for r in reports),'maximum_speed_ratio':max(r['median_speed_ratio'] for r in reports),'candidate_values_unchanged':True,'models_unchanged':True,'optimizer_calls':0,'closed_calls_remain_closed':True,'H5_complete':False})
