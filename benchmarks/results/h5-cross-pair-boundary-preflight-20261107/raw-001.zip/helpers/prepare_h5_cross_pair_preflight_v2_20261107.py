"""Preserve the preflight ABI-check failure; version only affinity reporting."""
from pathlib import Path
from hashlib import sha256
import json,ctypes
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cross-pair-preflight-20261107';PROCESS=ROOT/'output/h5-cross-pair-preflight-process-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not load(PROCESS/'process.json')['passed'] and load(PROCESS/'process.json')['closed']
for name,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
kernel=ctypes.WinDLL('kernel32',use_last_error=True);mask=ctypes.c_size_t();system=ctypes.c_size_t();ctypes.set_last_error(0);ok=kernel.GetProcessAffinityMask(kernel.GetCurrentProcess(),ctypes.byref(mask),ctypes.byref(system));error=ctypes.get_last_error();typed=affinity_mask()
assert not ok and error==6 and typed==sum(1<<i for i in range(16,32))
write(BASE/'affinity-abi-diagnostic.json',{'untyped_return':ok,'untyped_last_error':error,'typed_mask':typed,'expected_mask':sum(1<<i for i in range(16,32)),'cause':'ctypes default integer ABI truncates the pseudo process handle passed to GetProcessAffinityMask; explicit HANDLE/pointer signatures succeed. The failed check ran before any numerical controls or timings.','failed_process_sha256':digest(PROCESS/'process.json'),'cases_sha256':digest(BASE/'cases.json'),'kernel_unchanged':True,'optimizer_calls':0})
old="mask=ctypes.c_size_t();system=ctypes.c_size_t();assert ctypes.windll.kernel32.GetProcessAffinityMask(ctypes.windll.kernel32.GetCurrentProcess(),ctypes.byref(mask),ctypes.byref(system));assert mask.value==sum(1<<i for i in range(16,32))"
new="from h5_checked_affinity_20261107 import affinity_mask\nmask=ctypes.c_size_t(affinity_mask());assert mask.value==sum(1<<i for i in range(16,32))"
for kind in ['audit','time']:
    source=ROOT/'output'/f'{kind}_h5_cross_pair_preflight_20261107.py';text=source.read_text(encoding='utf-8');assert text.count(old)==1;text=text.replace(old,new).replace("BASE/'plan.json'","BASE/'plan-v2.json'")
    if kind=='audit':text=text.replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'")
    else:text=text.replace("OUT=BASE/'timing'","OUT=BASE/'timing-v2'").replace("BASE/'audit/","BASE/'audit-v2/")
    with (ROOT/'output'/f'{kind}_h5_cross_pair_preflight_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
source=ROOT/'output/run_h5_cross_pair_preflight_20261107.py';text=source.read_text(encoding='utf-8').replace('h5-cross-pair-preflight-process-20261107','h5-cross-pair-preflight-v2-process-20261107').replace("BASE/'plan.json'","BASE/'plan-v2.json'").replace('audit_h5_cross_pair_preflight_20261107.py','audit_h5_cross_pair_preflight_v2_20261107.py').replace('time_h5_cross_pair_preflight_20261107.py','time_h5_cross_pair_preflight_v2_20261107.py')
with (ROOT/'output/run_h5_cross_pair_preflight_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
plan=load(BASE/'plan.json');plan['correction']='Only typed Windows affinity observation and versioned output destinations; same numerical kernels, cases, tolerances, control logic and timing protocol. Original failure retained.'
for p in [Path(__file__),BASE/'plan.json',BASE/'affinity-abi-diagnostic.json',PROCESS/'process.json',PROCESS/'audit-stderr.txt']+[ROOT/'output'/n for n in ['h5_checked_affinity_20261107.py','audit_h5_cross_pair_preflight_v2_20261107.py','time_h5_cross_pair_preflight_v2_20261107.py','run_h5_cross_pair_preflight_v2_20261107.py']]:plan['inputs'][p.relative_to(ROOT).as_posix()]=digest(p)
write(BASE/'plan-v2.json',plan);print({'preserved_failure':True,'typed_affinity_mask':typed,'unchanged_frozen_cases':5,'unchanged_kernels':True,'optimizer_calls':0})
