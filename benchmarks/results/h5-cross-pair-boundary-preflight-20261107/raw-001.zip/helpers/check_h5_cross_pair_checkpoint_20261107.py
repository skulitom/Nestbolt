"""Read back numerical records, paired timings, preserved failure and closure."""
from pathlib import Path
from hashlib import sha256
import json,math,sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cross-pair-preflight-20261107';OUT=BASE/'checkpoint';A=BASE/'audit-v2';T=BASE/'timing-v2'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();plan=load(BASE/'plan-v2.json');a=load(A/'checks.json');t=load(T/'checks.json');assert a['passed'] and t['passed']
failed=load(ROOT/'output/h5-cross-pair-preflight-process-20261107/process.json');passed=load(ROOT/'output/h5-cross-pair-preflight-v2-process-20261107/process.json')
assert failed['closed'] and not failed['passed'] and len(failed['stages'])==1 and failed['stages'][0]['job']['root_exit_code']==1
assert passed['closed'] and passed['passed'] and len(passed['stages'])==2 and all(r['job']['closed'] and r['job']['active_processes']==0 and r['job']['root_exit_code']==0 and r['job']['peak_job_committed_memory']<2**31 and r['job']['complete_ms']<r['job']['maximum_ms'] for r in passed['stages'])
original=load(BASE/'plan.json')
for key in original:
    if key!='inputs':assert plan[key]==original[key],key
old="mask=ctypes.c_size_t();system=ctypes.c_size_t();assert ctypes.windll.kernel32.GetProcessAffinityMask(ctypes.windll.kernel32.GetCurrentProcess(),ctypes.byref(mask),ctypes.byref(system));assert mask.value==sum(1<<i for i in range(16,32))"
new="from h5_checked_affinity_20261107 import affinity_mask\nmask=ctypes.c_size_t(affinity_mask());assert mask.value==sum(1<<i for i in range(16,32))"
for kind in ['audit','time']:
    source=(ROOT/'output'/f'{kind}_h5_cross_pair_preflight_20261107.py').read_text(encoding='utf-8');corrected=(ROOT/'output'/f'{kind}_h5_cross_pair_preflight_v2_20261107.py').read_text(encoding='utf-8');expected=source.replace(old,new).replace("BASE/'plan.json'","BASE/'plan-v2.json'")
    if kind=='audit':expected=expected.replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'")
    else:expected=expected.replace("OUT=BASE/'timing'","OUT=BASE/'timing-v2'").replace("BASE/'audit/","BASE/'audit-v2/")
    assert corrected==expected
interactions=load(A/'interaction-controls.json');cases=load(A/'case-controls.json');samples=load(A/'central-samples.json');assert len(interactions)==842 and sum(c['directed_terms'] for c in cases)==842 and len(cases)==5 and len(samples)==810
for r in interactions:assert max(abs(x-y) for x,y in zip(r['batched'],r['scalar']))==r['maximum_error']<plan['directed_gradient_absolute_tolerance'] and 1<=r['weight']<=64 and r['owner']!=r['other']
for c in cases:assert len(c['gradient'])==len(c['scalar_gradient'])==81 and max(abs(x-y) for x,y in zip(c['gradient'],c['scalar_gradient']))==c['maximum_scalar_gradient_error']<plan['weighted_gradient_absolute_tolerance']
for case in load(BASE/'cases.json'):
    selected=[r for r in samples if r['case']==case['name']];assert {(r['coordinate'],r['step']) for r in selected}=={(i,s) for i in range(81) for s in plan['central_steps']}
    mm=load(ROOT/case['model_path']);data=load(ROOT/case['values_path']);expected=data['values'] if case['selector']=='values' else data[case['selector']]['values'];assert case['values']==expected
for r in samples:assert r['passed'] and abs(r['analytic']-r['numeric'])==r['absolute_error']<r['tolerance']==plan['central_absolute_tolerance']+plan['central_relative_tolerance']*abs(r['analytic'])
timings=load(T/'samples.json');summaries=load(T/'summary.json');assert len(timings)==80 and len(summaries)==4
median=lambda values:sum(sorted(values)[4:6])/2
for report in summaries:
    rows=[r for r in timings if r['case']==report['case']];assert len(rows)==20
    for repeat in range(10):
        chosen=[r for r in rows if r['repetition']==repeat];assert len(chosen)==2
        expected=['previous','batched'] if repeat%2==0 else ['batched','previous'];assert [r['implementation'] for r in chosen]==expected and [r['order_position'] for r in chosen]==[0,1]
    medians={kind:median([r['seconds'] for r in rows if r['implementation']==kind]) for kind in ['previous','batched']};assert medians==report['median_seconds'] and report['median_speed_ratio']==medians['previous']/medians['batched']
    assert all(math.isfinite(r['seconds']) and r['seconds']>0 and r['maximum_gradient_error']<plan['weighted_gradient_absolute_tolerance'] for r in rows)
bindings=dict(plan['inputs'])
for p in [Path(__file__),BASE/'plan-v2.json',BASE/'main-ci-at-review.json']+list(A.glob('*.json'))+list(T.glob('*.json'))+[ROOT/'output/h5-cross-pair-preflight-process-20261107/process.json',ROOT/'output/h5-cross-pair-preflight-v2-process-20261107/process.json']:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
for name,h in bindings.items():assert digest(ROOT/name)==h,name
runtime=load(A/'runtime-bindings.json')
for p in list((ROOT/'.cache/shop-venv/Lib/site-packages/shapely.libs').glob('*.dll'))+list((ROOT/'.cache/shop-venv/Lib/site-packages/numpy.libs').glob('*.dll')):runtime[p.relative_to(ROOT).as_posix()]=digest(p)
for name,h in runtime.items():assert digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime);write(OUT/'runtime-note.json',{'preflight_pinned_files':len(load(A/'runtime-bindings.json')),'supplementary_post_run_dll_pins':len(runtime)-len(load(A/'runtime-bindings.json')),'note':'The numerical audit pinned Python, NumPy and Shapely extension files. This checkpoint separately pins their bundled GEOS/OpenBLAS/runtime DLLs after the run; no before-run DLL pin is claimed.'})
write(OUT/'source-bindings.json',bindings)
checks={'passed':True,'directed_interactions':842,'weighted_coordinates':405,'central_samples':810,'timing_samples':80,'frozen_validation_cases':5,'timed_cases':4,'synthetic_polygon_cases':9,'empty_batch_controls':3,'collection_source_edges':8,'collection_permutations':2,'original_failure_preserved':True,'version_correction_limited_to_affinity_observation_and_output_paths':True,'kernels_cases_tolerances_unchanged':True,'maximum_scalar_directed_error':a['maximum_scalar_directed_error'],'maximum_scalar_weighted_error':a['maximum_scalar_weighted_error'],'minimum_median_speed_ratio':t['minimum_speed_ratio'],'maximum_median_speed_ratio':t['maximum_speed_ratio'],'failed_validation_seconds':failed['complete_seconds'],'passing_validation_seconds':passed['complete_seconds'],'all_three_stage_processes_closed':True,'new_optimizer_calls':0,'source_candidate_changes':0,'native_calls':0,'allocation_exclusions':0,'closed_calls_remain_closed':True,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
