"""Seal frozen numerical controls and alternating boundary-batching timings."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-cross-pair-boundary-preflight-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-cross-pair-preflight-20261107';F=BASE/'checkpoint';D=BASE/'audit-v2'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-weighted-mixed-rows-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['new_optimizer_calls']==0 and front['source_candidate_changes']==0 and not front['H5_complete']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-cross-pair-preflight-process-20261107',ROOT/'output/h5-cross-pair-preflight-v2-process-20261107']",
"['*h5*mixed*mode*20261107.py']":"['*h5*cross*pair*20261107.py','h5_checked_affinity_20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_cross_pair_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"'next-step-correction.json']":"'next-step-correction.json','plan-v2.json']"
}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
runtime=load(F/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'runtime-note.json','runtime-note.json'),(D/'checks.json','numerical-audit.json'),(D/'synthetic-controls.json','synthetic-controls.json'),(D/'collection-controls.json','collection-controls.json'),(D/'case-controls.json','case-controls.json'),(D/'central-summary.json','central-summary.json'),(BASE/'timing-v2/summary.json','timing-summary.json'),(BASE/'timing-v2/checks.json','timing-checks.json'),(BASE/'plan-v2.json','frozen-plan.json'),(BASE/'affinity-abi-diagnostic.json','affinity-abi-diagnostic.json'),(ROOT/'output/h5-cross-pair-preflight-process-20261107/process.json','preserved-failed-process.json'),(ROOT/'output/h5-cross-pair-preflight-v2-process-20261107/process.json','passing-process.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k!='passed'}})
write(OUT/'next-step.json',{'status':'weighted_joint_owner_selection_preflight_required','proposal':'Assess simultaneous physical-mode changes for two bracket/insert owners under the exact bounded pair weights. The closed weighted pipeline considered only one changed owner at a time; batch speed alone supplies no new search mechanism.','validation_only_first':True,'requirements':['Use the preserved unoptimized source initializer and its audited initial weights. Saved optimized cases from this timing study remain verification-only and cannot seed a new search.','Independently enumerate the current vector, every distinct single-owner neighbor, and every distinct two-owner neighbor using exact filled-outline/domain equivalence; retain aliases, owner mapping and exclusions explicitly. The existing library suggests 78 singles and 2775 two-owner neighbors; independently prove those counts before scoring.','Independently reconstruct every weighted full score from all528 original/clearance pair terms and verify delta-scoring if introduced. Compare best admissible joint and single proposals with deterministic score/full-vector tie breaking. Do not select using partial pair scores.','Exclude all previously closed weighted coefficient/physical-mode keys and preserve the earlier unweighted calls. Require a joint proposal that strictly improves the best admissible single proposal before claiming a new escape mechanism. A numerical speedup alone cannot reopen any closed problem.','Before any later optimizer call, independently check the selected model, freeze a finite complete accounting contract, include the entire9.437443899689242s consumed source preparation plus every new placement-preparation stage, and retain dual weighted/unweighted incumbents and full66 source readback. No new optimizer or successor selector is prepared in this checkpoint.'],'new_optimizer_calls':0,'new_selector_prepared':False,'closed_calls_remain_closed':True,'H5_complete':False})
report=f'''# Cross-pair boundary preflight — 2026-11-07

Batching exact boundary integration across active part pairs passes the frozen
numerical controls. On four fixed validation cases the research evaluator is
**1.4252–1.5082× faster** by median time. No placement search runs, no source
candidate changes, and no closed call resumes. This is a kernel measurement,
not a packing-quality result. H2/H5 remain open at **60% completed milestone weight**.

## Same geometry with explicit interaction mappings

The previous evaluator vectorizes edges within each directed pair. The new
research module concatenates edges across all active directed pairs at each
original/clearance geometry level. Each clipped leaf retains its explicit
source edge, interaction group, owner, pivot and pair coefficient. It retains
the exact straight-segment integral, zero contribution from points and
degenerate edges, and the shared-boundary half convention. That convention
does not turn a contact into a unique smooth derivative.

[The numerical audit]({NAME}/numerical-audit.json) compares **842 directed
interactions** against both the scalar integral and the preceding vector
implementation. Independent source-ring transforms and weighted accumulation
check **405 owner coordinates** across five frozen cases, including all
coefficients set to 64. Scores, pair losses and detail fields agree. Maximum
scalar discrepancies are **1.274e-11** per directed integral and **1.819e-12**
in the assembled weighted gradient.

[Nine polygon controls]({NAME}/synthetic-controls.json) cover disjoint and
point contacts, shared sides, identical outlines, both containment directions,
partial and multipart clipping, variable vertex counts and a repeated vertex.
Three additional controls cover empty and mixed-empty batches.
[Eight explicit edge origins]({NAME}/collection-controls.json) exercise
empty, point, line, multiline and nested collection leaves with nonconsecutive
groups, an empty group, distinct pivots, a degenerate edge and two input orders.

[Central differences]({NAME}/central-summary.json) check **810 samples**:
all 81 coordinates, at two frozen steps, for each of five deterministic
interior validation points. The prior tolerance remains
`0.02 + 3e-6 × |analytic derivative|`. The largest absolute discrepancy is
0.005094 in the all64 coefficient control. No point or tolerance is changed
after observing a result. These points are verification-only.

## Frozen paired timings

[The protocol]({NAME}/frozen-plan.json) fixes cases, tolerances, two warmups
per implementation, ten samples per implementation and alternating order
before execution. Both implementations use the same models and coordinates
under CCD1 (logical CPUs 16–31), with BLAS/OMP/MKL threads fixed to one.
Every measured result is checked for numerical agreement and input immutability.

| Frozen validation case | Previous median | Batched median | Ratio |
|---|---:|---:|---:|
| Unoptimized weighted initializer | 43.578 ms | 28.893 ms | 1.5082× |
| Epoch1 weighted winner | 80.594 ms | 56.548 ms | 1.4252× |
| Epoch3 weighted winner | 85.897 ms | 60.168 ms | 1.4276× |
| Epoch3 unweighted winner | 85.456 ms | 59.852 ms | 1.4278× |

[All medians and ranges]({NAME}/timing-summary.json) are reconstructed from
the 80 raw timing records preserved in the archive. The maximum-weight case
is a numerical control only. No optimizer throughput or end-to-end production
speedup is inferred from these four research measurements.

## Preserved affinity-check failure

The [first audit process]({NAME}/preserved-failed-process.json) stops before
geometry or timing because an untyped ctypes call truncates the Windows
pseudo process handle. [A separate diagnostic]({NAME}/affinity-abi-diagnostic.json)
reproduces error 6 and verifies that explicit HANDLE/pointer signatures read
the expected CCD1 affinity. Versioned audit and timing files change only
that observation and output destinations; original files, frozen cases,
kernels, tolerances and failed output remain preserved.

The failed wrapper takes 0.267324s; the [passing two-stage wrapper]({NAME}/passing-process.json)
takes 34.325079s, including 27.632215s for the audit and 6.685359s for timing.
All three stage jobs close, with no active processes, deadline overrun or
memory-limit breach. These are validation-only times, not a new placement
preparation. [Checkpoint readback]({NAME}/checkpoint-audit.json) independently
reconciles corrections, controls, medians, immutable sources and closure.
[Runtime bindings]({NAME}/runtime-bindings.json) pin 12 files; the
[runtime note]({NAME}/runtime-note.json) explicitly distinguishes seven
preflight pins from five supplementary DLL hashes recorded afterward.

## Next selection preflight and repository state

[The next proposal]({NAME}/next-step.json) assesses simultaneous two-owner
physical-mode changes under the exact weights. The closed weighted pipeline
scored single-owner changes. Before any new search, independently enumerate
and score joint alternatives from the unoptimized source initializer, preserve
every closed coefficient/mode problem and require an improvement over the
best admissible single move. A later pipeline would need its own finite
contract and complete preparation accounting. No selector or successor call
exists here; a faster evaluator alone cannot reopen any closed call.

The preceding weighted result remains invalid: 49 original pair failures and
28,207.754973 mm² overlap. Four earlier fixed arrangements and 440 allocations
remain unresolved. No native call, allocation exclusion or release follows.
Main remains d8aa6a90; [four CI jobs pass and two native jobs run at review]({NAME}/main-ci-at-review.json).
The preceding 0af0c522 checkpoint and this checkpoint await the ordinary push
gate. Product code and README claims are unchanged.

[Archive verification]({NAME}/archive-checks.json),
[manifest]({NAME}/raw-manifest.json),
[historical evidence references]({NAME}/external-evidence.json) and
[source bindings]({NAME}/source-bindings.json) preserve the complete record.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 cross-pair boundary preflight:** [frozen numerical and timing audits]({link}) verify 842 directed integrals, 405 weighted coordinates and 810 central samples, including maximum weight 64. Nine polygon controls, three empty batches and two nested-collection permutations preserve edge/interaction/owner mappings and shared-boundary conventions. The first Windows affinity-check ABI failure is preserved; typed HANDLE signatures correct only observation/output paths, with kernels, cases and tolerances unchanged. Eighty alternating samples on four fixed cases show 1.4252–1.5082× median research-evaluator speedups under CCD1/one BLAS thread. The passing wrapper takes 34.325079s and all three validation stage jobs close. No optimizer, candidate mutation, native call or exclusion occurs. Next independently assess exact weighted two-owner mode proposals from the unoptimized source initializer; no new selector or search exists, and faster evaluation cannot reopen a closed call. The prior best still fails 49 pairs with 28,207.754973 mm² overlap; four earlier arrangements and 440 allocations remain. H2/H5 stay open at 60%. Main d8aa6a90 has four passed CI jobs and both native jobs running at review; 0af0c522 and this checkpoint await the ordinary push gate. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [cross-pair boundary preflight](../benchmarks/results/{NAME}.md).
The batched research evaluator passes 842 scalar/vector interaction controls,
405 weighted coordinates and 810 central samples, including weight 64.
Eighty alternating measurements on four frozen cases show 1.4252–1.5082×
median speedups. The original affinity-check ABI failure and typed correction
remain preserved; kernels, cases and tolerances stay unchanged. All three
validation jobs close. No optimizer runs or candidate changes.
The prior weighted search remains closed and invalid: 49 source pair failures,
28,207.754973 mm² overlap, with fixed-part and stock checks passing.
Next independently assess weighted two-owner physical-mode proposals from
the unoptimized source initializer; no new selector or search is prepared.
Faster evaluation alone cannot reopen any closed call. Four earlier fixed
arrangements and 440 allocations remain. H2/H5 stay at 60% completed milestone
weight. Main d8aa6a90 has four passed jobs and two live native CI checks at
review; 0af0c522 and this checkpoint await the ordinary push gate.
Product code, README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
