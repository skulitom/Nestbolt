"""Batch exact clipped-edge integrals across directed pair interactions."""
import numpy as np
import shapely

def integrate_groups(starts,edges,pivots,groups,geometries,count):
    gradients=np.zeros((count,3));counts=np.zeros(count,dtype=np.int64)
    geometries=np.asarray(geometries,dtype=object);origins=np.arange(len(geometries))
    assert len(starts)==len(edges)==len(pivots)==len(groups)==len(geometries)
    while len(geometries):
        keep=~shapely.is_empty(geometries);geometries=geometries[keep];origins=origins[keep]
        if not len(geometries):return gradients,counts
        if not np.any(shapely.get_type_id(geometries)>=4):break
        geometries,parents=shapely.get_parts(geometries,return_index=True);origins=origins[parents]
    keep=shapely.get_type_id(geometries)==1;geometries=geometries[keep];origins=origins[keep]
    if not len(geometries):return gradients,counts
    coordinates,segments=shapely.get_coordinates(geometries,return_index=True)
    p=starts[origins];v=edges[origins];denominators=np.sum(v*v,axis=1);good=denominators>0
    parameters=np.sum((coordinates-p[segments])*v[segments],axis=1)/np.where(good,denominators,1.)[segments]
    lo=np.full(len(geometries),np.inf);hi=np.full(len(geometries),-np.inf)
    np.minimum.at(lo,segments,parameters);np.maximum.at(hi,segments,parameters)
    lo=np.maximum(0.,lo);hi=np.minimum(1.,hi);keep=good&(hi>lo)
    p=p[keep];v=v[keep];lo=lo[keep];hi=hi[keep];origins=origins[keep]
    delta=(hi-lo)[:,None]*v;normal=np.column_stack((delta[:,1],-delta[:,0]))
    relative=p+((hi+lo)/2)[:,None]*v-pivots[origins]
    torque=-relative[:,1]*normal[:,0]+relative[:,0]*normal[:,1]
    np.add.at(gradients,groups[origins],np.column_stack((normal,torque)))
    np.add.at(counts,groups[origins],1)
    return gradients,counts

def boundary_gradients(vertices,lines,others,pivots):
    count=len(vertices);assert count==len(lines)==len(others)==len(pivots)
    if not count:return np.zeros((0,3)),np.zeros(0,dtype=np.int64),np.zeros(0)
    vertices=[np.asarray(v,dtype=float).reshape((-1,2)) for v in vertices]
    sizes=np.asarray([len(v) for v in vertices]);assert all(len(line)==n for line,n in zip(lines,sizes))
    if not np.sum(sizes):return np.zeros((count,3)),np.zeros(count,dtype=np.int64),np.zeros(count)
    starts=np.concatenate([np.asarray(v,dtype=float) for v in vertices]);edges=np.concatenate([np.roll(v,-1,axis=0)-v for v in vertices]);groups=np.repeat(np.arange(count),sizes);edge_pivots=np.asarray(pivots)[groups]
    flat_lines=np.concatenate(lines);other_array=np.asarray(others,dtype=object)
    clipped=shapely.intersection(flat_lines,other_array[groups]);shared=shapely.intersection(flat_lines,shapely.boundary(other_array)[groups])
    full,counts=integrate_groups(starts,edges,edge_pivots,groups,clipped,count)
    coincident,_=integrate_groups(starts,edges,edge_pivots,groups,shared,count)
    lengths=np.bincount(groups,weights=shapely.length(shared),minlength=count)
    return full-.5*coincident,counts,lengths
