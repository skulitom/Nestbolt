"""Independent boundary, interaction, coefficient and full-gradient controls."""
from pathlib import Path
from hashlib import sha256
import copy,json,math,time,os,sys
import numpy as np
import shapely
from shapely.geometry import Polygon,LineString,Point,GeometryCollection,MultiLineString,box
from shapely.geometry.polygon import orient
from h5_cross_pair_boundary_gradient_20261107 import boundary_gradients,integrate_groups
from h5_cross_pair_weighted_model_20261107 import Objective as New
from h5_weighted_original_model_20261107 import Objective as Old
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient,line_parts
from h5_vector_boundary_gradient_20261107 import boundary_gradient
from h5_weighted_original_readback_20261107 import verify
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cross-pair-preflight-20261107';OUT=BASE/'audit';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();plan=load(BASE/'plan.json');lib=load(W/'library.json')
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
assert os.environ['OPENBLAS_NUM_THREADS']==os.environ['OMP_NUM_THREADS']==os.environ['MKL_NUM_THREADS']=='1'
import ctypes
mask=ctypes.c_size_t();system=ctypes.c_size_t();assert ctypes.windll.kernel32.GetProcessAffinityMask(ctypes.windll.kernel32.GetCurrentProcess(),ctypes.byref(mask),ctypes.byref(system));assert mask.value==sum(1<<i for i in range(16,32))
runtime_paths=[Path(sys.executable),Path(np.__file__),Path(shapely.__file__)]+list(Path(shapely.__file__).parent.glob('*.pyd'))+list(Path(shapely.__file__).parent.glob('*.dll'))+list((Path(np.__file__).parent/'_core').glob('_multiarray_umath*.pyd'))
write(OUT/'runtime-bindings.json',{p.relative_to(ROOT).as_posix():digest(p) for p in runtime_paths})
write(OUT/'environment.json',{'python':sys.version,'numpy':np.__version__,'shapely':shapely.__version__,'geos':shapely.geos_version_string,'affinity_mask':mask.value,'threads':{k:os.environ[k] for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']}})
# Empty batches, variable vertex counts, contacts, containment and degenerate edges.
synthetic=[('disjoint',Polygon([(0,0),(3,0),(1,2)]),box(4,4,6,6)),('point',box(0,0,2,2),box(2,2,4,4)),('shared-side',box(0,0,2,2),box(2,0,4,2)),('identical',box(0,0,2,2),box(0,0,2,2)),('contained',box(1,1,2,2),box(0,0,3,3)),('containing',box(0,0,3,3),box(1,1,2,2)),('partial',Polygon([(0,0),(4,0),(5,2),(3,4),(0,3)]),box(2,-1,6,3)),('multipart',box(0,0,6,3),Polygon([(1,-1),(2,-1),(2,1),(4,1),(4,-1),(5,-1),(5,2),(1,2)])),('degenerate-edge',Polygon([(0,0),(2,0),(2,0),(3,2),(0,3)]),box(1,-1,4,2))]
vertices=[];lines=[];others=[];pivots=[]
for k,(name,a,b) in enumerate(synthetic):
    a=orient(a,sign=1);v=np.asarray(a.exterior.coords)[:-1];vertices.append(v);lines.append(shapely.linestrings(np.stack([v,np.roll(v,-1,axis=0)],axis=1)));others.append(b);pivots.append([.31*k,-.27*k]);synthetic[k]=(name,a,b)
gg,nn,ss=boundary_gradients(vertices,lines,others,pivots);controls=[]
for k,(name,a,b) in enumerate(synthetic):
    scalar,n,s=moving_boundary_gradient(a,b,pivots[k]);previous,pn,ps=boundary_gradient(vertices[k],lines[k],b,pivots[k]);err=float(np.max(np.abs(gg[k]-scalar)));assert err<1e-7 and np.max(np.abs(gg[k]-previous))<1e-7 and nn[k]==n==pn and abs(ss[k]-s)<1e-8 and abs(ss[k]-ps)<1e-8
    controls.append({'name':name,'owner_wkt':a.wkt,'other_wkt':b.wkt,'pivot':pivots[k],'vertices':len(vertices[k]),'gradient':gg[k].tolist(),'scalar_gradient':scalar.tolist(),'segments':int(n),'shared_length':float(ss[k]),'absolute_error':err})
assert boundary_gradients([],[],[],[])[0].shape==(0,3)
empty=np.empty((0,2));result=boundary_gradients([empty,vertices[0]],[np.empty(0,dtype=object),lines[0]],[box(0,0,1,1),others[0]],[[0,0],pivots[0]]);assert np.all(result[0]==0)
result=boundary_gradients([empty],[np.empty(0,dtype=object)],[box(0,0,1,1)],[[0,0]]);assert np.all(result[0]==0)
write(OUT/'synthetic-controls.json',controls)
# Direct leaf controls deliberately mix origins, pivots, groups and nested collections.
starts=np.asarray([[0.,float(i)] for i in range(8)]);edges=np.asarray([[4.,0.] for i in range(8)]);edges[6]=0;pivots=np.asarray([[.13*i,-.21*i] for i in range(8)]);groups=np.asarray([2,0,2,1,0,3,1,4])
geoms=[GeometryCollection(),Point(2,1),LineString([(1,2),(2,2),(3,2)]),MultiLineString([[(.5,3),(1,3)],[(2,3),(3.5,3)]]),GeometryCollection([Point(2,4),GeometryCollection([LineString([(1,4),(3,4)]),MultiLineString([[(0,4),(.5,4)],[(3.5,4),(4,4)]])])]),LineString([(-1,5),(5,5)]),LineString([(0,6),(1,6)]),LineString([(3,7),(1,7)])]
expected=np.zeros((6,3));counts=np.zeros(6,dtype=int)
for index,geometry in enumerate(geoms):
    p=starts[index];edge=edges[index];den=float(edge@edge)
    if den==0:continue
    for leaf in line_parts(geometry):
        ts=[float((np.asarray(c)-p)@edge/den) for c in leaf.coords];lo=max(0.,min(ts));hi=min(1.,max(ts))
        if hi<=lo:continue
        d=(hi-lo)*edge;normal=np.asarray([d[1],-d[0]]);rel=p+(hi+lo)*.5*edge-pivots[index];expected[groups[index]]+=np.asarray([*normal,float(np.asarray([-rel[1],rel[0]])@normal)]);counts[groups[index]]+=1
orders=[list(range(8)),[4,0,7,2,6,1,5,3]];leaf_controls=[]
for order in orders:
    actual,an=integrate_groups(starts[order],edges[order],pivots[order],groups[order],np.asarray(geoms,dtype=object)[order],6);assert np.max(np.abs(actual-expected))<1e-12 and np.array_equal(an,counts);leaf_controls.append({'order':order,'gradient':actual.tolist(),'counts':an.tolist()})
write(OUT/'collection-controls.json',{'origins':list(range(8)),'groups':groups.tolist(),'starts':starts.tolist(),'edges':edges.tolist(),'pivots':pivots.tolist(),'geometries':[g.wkt for g in geoms],'scalar_gradient':expected.tolist(),'scalar_counts':counts.tolist(),'permutations':leaf_controls,'empty_group':5})
def independent_shapes(mm,x):
    shapes=[]
    for i,identity in enumerate(lib['identities']):
        mode=lib['family_modes'][identity[0]][mm['owners'][i]['mode']];theta=x[66+i-18]/lib['angle_scale_mm'] if i>=18 else mode['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][identity[0]]['source_center'];tx=x[2*i]-(sign*px*c-py*s);ty=x[2*i+1]-(sign*px*s+py*c)
        shapes.append([Polygon([(sign*a*c-b*s+tx,sign*a*s+b*c+ty) for a,b in lib['families'][identity[0]][kind]]) for kind in ['original','clearance']])
    return shapes
def full_score(mm,x):
    ps=independent_shapes(mm,x);return sum(w*sum(ps[i][k].intersection(ps[j][k]).area for k in [0,1]) for w,(i,j) in zip(mm['pair_weights'],lib['pairs']))
reports=[];interactions=[];samples=[];derivative_summary=[]
for case in load(BASE/'cases.json'):
    mm=load(ROOT/case['model_path']);x=np.asarray(case['values']);weights=mm['pair_weights'];modes=[o['mode'] for o in mm['owners']];assert verify(mm,lib,modes,mm['initial'],weights)
    if case['maximum_weight_control']:mm=copy.deepcopy(mm);mm['pair_weights']=[64.]*528
    old=Old(mm);new=New(mm);e,g,d=new.evaluate(x,True);oe,og,od=old.evaluate(x,True);assert e==oe and np.max(np.abs(g-og))<plan['weighted_gradient_absolute_tolerance']
    for key in d:
        if key=='coincident_boundary_length_mm':assert abs(d[key]-od[key])<plan['shared_length_absolute_tolerance_mm']
        else:assert d[key]==od[key],key
    assert abs(e-full_score(mm,x))<plan['score_absolute_tolerance_mm2'] and abs(new.score(x)-e)<plan['score_absolute_tolerance_mm2'] and np.array_equal(new.pair_losses(x),old.pair_losses(x))
    ps=independent_shapes(mm,x);reference=np.zeros(81);count=0;levels=new.geometry(x)
    for k,entries in enumerate(levels):
        vv=[];ll=[];oo=[];pp=[];mapping=[]
        for pair,(i,j) in enumerate(lib['pairs']):
            area=ps[i][k].intersection(ps[j][k]).area
            if area<=0:continue
            for own,other in [(i,j),(j,i)]:
                v,poly,line,pivot=entries[own];vv.append(v);ll.append(line);oo.append(entries[other][1]);pp.append(pivot);mapping.append((pair,own,other))
        bg,bn,bs=boundary_gradients(vv,ll,oo,pp)
        for directed,(pair,own,other) in enumerate(mapping):
            scalar,n,s=moving_boundary_gradient(ps[own][k],ps[other][k],x[2*own:2*own+2]);previous,pn,sp=boundary_gradient(vv[directed],ll[directed],oo[directed],pp[directed]);err=float(np.max(np.abs(bg[directed]-scalar)));assert err<plan['directed_gradient_absolute_tolerance'] and np.max(np.abs(bg[directed]-previous))<plan['directed_gradient_absolute_tolerance'] and bn[directed]==n==pn and abs(bs[directed]-s)<plan['shared_length_absolute_tolerance_mm']
            weight=mm['pair_weights'][pair];reference[2*own:2*own+2]+=weight*scalar[:2]
            if own>=18:reference[66+own-18]+=weight*scalar[2]/lib['angle_scale_mm']
            interactions.append({'case':case['name'],'level':k,'interaction':directed,'pair':pair,'owner':own,'other':other,'weight':weight,'vertices':len(vv[directed]),'batched':bg[directed].tolist(),'previous':previous.tolist(),'scalar':scalar.tolist(),'segments':int(n),'shared_length':float(s),'maximum_error':err});count+=1
    error=float(np.max(np.abs(g-reference)));assert error<plan['weighted_gradient_absolute_tolerance']
    reports.append({'case':case['name'],'weighted_objective':e,'unweighted_objective':d['unweighted_objective_mm2'],'source_overlap':d['original_overlap_area_mm2'],'directed_terms':count,'coordinates':81,'maximum_scalar_gradient_error':error,'maximum_previous_gradient_error':float(np.max(np.abs(g-og))),'gradient':g.tolist(),'scalar_gradient':reference.tolist(),'maximum_weight':max(mm['pair_weights'])})
    point=np.asarray(case['central_values']);value,derivative=new.evaluate(point);assert abs(value-full_score(mm,point))<plan['score_absolute_tolerance_mm2'];errs=[]
    for coordinate in range(81):
        for step in plan['central_steps']:
            plus=point.copy();minus=point.copy();plus[coordinate]+=step;minus[coordinate]-=step;numeric=(full_score(mm,plus)-full_score(mm,minus))/(2*step);error=abs(numeric-derivative[coordinate]);tolerance=plan['central_absolute_tolerance']+plan['central_relative_tolerance']*abs(derivative[coordinate]);record={'case':case['name'],'coordinate':coordinate,'step':step,'analytic':float(derivative[coordinate]),'numeric':numeric,'absolute_error':float(error),'tolerance':float(tolerance),'passed':bool(error<tolerance)};samples.append(record);errs.append(float(error))
            if not record['passed']:write(OUT/'failed-central-samples.json',samples)
            assert record['passed'],record
    derivative_summary.append({'case':case['name'],'samples':162,'maximum_absolute_error':max(errs)})
    write(OUT/(case['name']+'-completed.json'),reports[-1]);print({'completed_case':case['name'],'directed_terms':count,'central_samples':162},flush=True)
write(OUT/'case-controls.json',reports);write(OUT/'interaction-controls.json',interactions);write(OUT/'central-samples.json',samples);write(OUT/'central-summary.json',derivative_summary)
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
write(OUT/'source-bindings.json',plan['inputs'])
checks={'passed':True,'seconds':time.perf_counter()-started,'synthetic_polygon_cases':len(synthetic),'empty_batch_controls':3,'collection_source_edges':8,'collection_permutations':2,'directed_real_interactions':len(interactions),'weighted_coordinates':81*len(reports),'central_samples':len(samples),'maximum_scalar_directed_error':max(r['maximum_error'] for r in interactions),'maximum_scalar_weighted_error':max(r['maximum_scalar_gradient_error'] for r in reports),'maximum_previous_weighted_error':max(r['maximum_previous_gradient_error'] for r in reports),'score_and_details_equivalent':True,'maximum_weight_control':64,'optimizer_calls':0,'closed_calls_remain_closed':True,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
