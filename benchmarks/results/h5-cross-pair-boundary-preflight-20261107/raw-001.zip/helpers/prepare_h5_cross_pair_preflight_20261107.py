"""Freeze numerical cases and timing protocol before either evaluator runs."""
from pathlib import Path
from hashlib import sha256
import ast,json,copy
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cross-pair-preflight-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
BASE.mkdir();assert load(W/'audit-v2/checks.json')['passed'] and load(W/'response-audit/checks.json')['passed']
spec=[('initial','model.json','initial-state.json','values'),('epoch01-weighted','search/epoch-01/model.json','search/epoch-01/response.json','weighted_best'),('epoch03-weighted','search/epoch-03/model.json','search/epoch-03/response.json','weighted_best'),('epoch03-unweighted','search/epoch-03/model.json','search/epoch-03/response.json','unweighted_best'),('initial-max64','model.json','initial-state.json','values')]
cases=[];inputs={};queue=[]
def bind(p):
    name=p.relative_to(ROOT).as_posix()
    if name not in inputs:inputs[name]=digest(p);queue.append(p)
for index,(name,mp,vp,key) in enumerate(spec):
    model=load(W/mp);data=load(W/vp);values=data['values'] if key=='values' else data[key]['values'];bb=np.asarray(model['bounds']);margin=.03+np.arange(81)*.00037
    point=np.clip(np.asarray(values)+.137*np.sin(np.arange(81)*2**.5+.2+index),bb[:,0]+margin,bb[:,1]-margin)
    cases.append({'name':name,'model_path':(W/mp).relative_to(ROOT).as_posix(),'values_path':(W/vp).relative_to(ROOT).as_posix(),'selector':key,'values':values,'maximum_weight_control':index==4,'central_values':point.tolist(),'timed':index<4})
    bind(W/mp);bind(W/vp)
write(BASE/'cases.json',cases);bind(BASE/'cases.json')
for p in [Path(__file__),W/'library.json',W/'audit-v2/checks.json',W/'response-audit/checks.json',W/'search/process.json',ROOT/'benchmarks/results/h5-weighted-mixed-rows-construction-20261107/next-step.json',ROOT/'output/h5-windows-job-controls-v4-20261107/checks.json']+[ROOT/'output'/n for n in ['h5_cross_pair_boundary_gradient_20261107.py','h5_cross_pair_weighted_model_20261107.py','h5_weighted_original_model_20261107.py','h5_weighted_original_readback_20261107.py','h5_original_overlap_gradient_v2_20261107.py','h5_vector_boundary_gradient_20261107.py','audit_h5_cross_pair_preflight_20261107.py','time_h5_cross_pair_preflight_20261107.py','run_h5_cross_pair_preflight_20261107.py','ccd1.py']]:bind(p)
while queue:
    p=queue.pop()
    if p.suffix!='.py':continue
    for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
        names=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
        for name in names:
            if '.' not in name:
                for folder in ['output','scripts']:
                    candidate=ROOT/folder/(name+'.py')
                    if candidate.is_file():bind(candidate)
write(BASE/'plan.json',{'inputs':inputs,'purpose':'Frozen-case numerical/performance-only validation. No optimizer, no candidate changes and no reopening of any closed call.','cases':5,'timed_cases':4,'directed_gradient_absolute_tolerance':1e-7,'weighted_gradient_absolute_tolerance':1e-6,'score_absolute_tolerance_mm2':1e-6,'shared_length_absolute_tolerance_mm':1e-8,'central_steps':[1e-5,1e-6],'central_absolute_tolerance':.02,'central_relative_tolerance':3e-6,'central_case_rule':'For each of five cases freeze all81 deterministic interior coordinates before evaluation; same two steps and tolerance as prior weighted audit. These are verification points only.','timing':{'repetitions':10,'warmups_per_implementation':2,'evaluations_per_sample':1,'order':'old,new on even repetitions; new,old on odd; same four cases in fixed order','cpu_affinity':list(range(16,32)),'blas_threads':1,'aggregate':'median previous seconds / median batched seconds for each case; record every sample','cap_seconds':120},'audit_cap_seconds':180,'memory_bytes':2**31,'source_optimizer_calls':0,'retry_permitted':False,'closed_calls_remain_closed':True,'H5_complete':False})
print({'frozen_cases':len(cases),'bound_sources':len(inputs),'optimizer_calls':0})
