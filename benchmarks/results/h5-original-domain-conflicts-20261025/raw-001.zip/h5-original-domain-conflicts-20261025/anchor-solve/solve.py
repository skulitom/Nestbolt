"""One full-original coordinate solve of the selected nine convex domains."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time,traceback,sys
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
from audit_h5_selected_anchor_model import verify

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-original-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'anchor-solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'selection-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    spec=load(SOURCE/'plan.json');selected=load(BASE/'solve/selection.json')['movable_parts']
    queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']};mutual={q['index']:load(SOURCE/'mutual'/f"{q['index']:03d}.json") for q in spec['mutual_cases']}
    inputs=[BASE/'solve/selection.json',BASE/'selection-audit/checks.json',SOURCE/'plan.json',SOURCE/'audit/checks.json',ROOT/'output/audit_h5_selected_anchor_model.py']
    params={'max_time_in_seconds':60,'num_search_workers':8,'random_seed':0,'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'query_hashes':{str(i):digest(SOURCE/'queries'/f'{i:03d}.json') for i in queries},'mutual_hashes':{str(i):digest(SOURCE/'mutual'/f'{i:03d}.json') for i in mutual},
        'construction_limit_seconds':120,'independent_audit_limit_seconds':120,'parameters':params,'maximum_solver_calls':1,
        'method':'Place all9 mandatory originals inside their independently checked selected convex domains with18 integer anchors. Keep every inward halfplane and every same-sheet full-original forbidden piece. For each outside inequality derive exact minimum and maximum projection over the complete integer difference rectangle. Omit an entire forbidden piece only if an edge always separates its whole rectangle; omit a direction only if its maximum cannot reach the required bound. Retain the full separation disjunction for each other piece, including an empty clause if impossible. Audit every bound reduction and every protobuf variable/constraint before one60-second/eight-worker/seed-zero call. Fixed57 originals, original area charges and66 original counts remain unchanged. A negative excludes only this selected domain combination. A positive still needs independent complete original geometry/native validation and production/H5 qualification.'})
    start=time.perf_counter();model=cp_model.CpModel();vs=[]
    def var(name,lo,hi):
        v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi,en=()):
        c=model.add_linear_constraint(sum(vs[i]*coef for i,coef in terms),lo,hi)
        if en:c.only_enforce_if([vs[i] for i in en])
    parts=[]
    for p in selected:
        f=queries[p['query']]['domains'][p['domain_row']];q=spec['queries'][p['query']];a,b=f['coordinate_bounds'],q['anchor_bounds_units1000'];bounds=[max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3])]
        x=var(f"part{p['part']}-x",bounds[0],bounds[2]);y=var(f"part{p['part']}-y",bounds[1],bounds[3])
        for h in f['halfplanes']:linear([(x,h['a']),(y,h['b'])],cp_model.INT_MIN,h['bound'])
        parts.append({**p,'x':x,'y':y,'coordinate_bounds':bounds})
    lookup={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']};pairs=[]
    for a,b in combinations(parts,2):
        if a['sheet']!=b['sheet']:continue
        case=lookup[(a['profile'],b['profile'])];ba,bb=a['coordinate_bounds'],b['coordinate_bounds'];r=[bb[0]-ba[2],bb[1]-ba[3],bb[2]-ba[0],bb[3]-ba[1]];records=[]
        for f in mutual[case]['faces']:
            edges=[]
            for n,h in enumerate(f['outside_halfplanes']):
                low=sum(min(c*v,c*w) for c,v,w in [(h['a'],r[0],r[2]),(h['b'],r[1],r[3])]);high=sum(max(c*v,c*w) for c,v,w in [(h['a'],r[0],r[2]),(h['b'],r[1],r[3])])
                edges.append({'edge':n,'minimum_projection':low,'maximum_projection':high,'always':low>=h['bound'],'possible':high>=h['bound']})
            dirs=[]
            if not any(e['always'] for e in edges):
                for e in edges:
                    if not e['possible']:continue
                    h=f['outside_halfplanes'][e['edge']];d=var(f"pair{a['part']}-{b['part']}-face{f['index']}-edge{e['edge']}",0,1);dirs.append(d)
                    linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],cp_model.INT_MAX,[d])
                model.add_bool_or([vs[d] for d in dirs])
            records.append({'face':f['index'],'edges':edges,'always_separated':any(e['always'] for e in edges),'directions':dirs})
        pairs.append({'parts':[a['part'],b['part']],'case':case,'difference_bounds':r,'faces':records})
    mapping={'parts':parts,'pairs':pairs};write(OUT/'mapping.json',mapping);assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb'));bt=time.perf_counter()-start;assert bt<120
    start=time.perf_counter();actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());expected,stats=verify(actual,spec,selected,queries,mutual);assert expected==mapping
    solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');at=time.perf_counter()-start;assert at<120
    write(OUT/'model-audit.json',{'passed':True,'construction_seconds':bt,'audit_seconds':at,**stats,'model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),
        'python':sys.version,'ortools':ortools.__version__});print(load(OUT/'model-audit.json'),flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'seconds_limit':60,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();code=solver.solve(model);elapsed=time.perf_counter()-start
    feasible=code in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    if feasible:
        positions=[{**s,'x_units':solver.value(vs[p['x']]),'y_units':solver.value(vs[p['y']])} for s,p in zip(selected,parts)]
        write(OUT/'positions.json',{'fixed_items':spec['fixed_items'],'coordinate_units_per_mm':1000,'movable_parts':positions,'required_originals':66})
    result={'status':solver.status_name(code),'seconds':elapsed,'solver_calls':1,'has_full_original_model_candidate':feasible,'response_stats':solver.response_stats(),
        'scope':'Only the chosen nine convex domains, source angles and adjusted57-original fixed source. A negative does not exclude other domain combinations or unrestricted packing.',
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
