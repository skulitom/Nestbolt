"""Exact geometric certificate for three incompatible cog anchor regions."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time,traceback

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-original-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'three-cog-certificate'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def derive(boxes,radius):
    a,b,c=[v.copy() for v in boxes];required=radius*radius+1
    assert a[2]<c[0] and c[2]<b[0] and b[1]>c[3]
    dx=max(abs(b[0]-c[2]),abs(b[2]-c[0]));residual=required-dx*dx;assert residual>0
    dy=math.isqrt(residual);dy+=dy*dy<residual
    b[1]=max(b[1],c[1]+dy)
    maxdx=max(abs(a[0]-b[2]),abs(a[2]-b[0]));maxdy=max(abs(a[1]-b[3]),abs(a[3]-b[1]))
    maximum=maxdx*maxdx+maxdy*maxdy
    assert b[1]<=b[3] and maximum<required
    return {'required_squared_center_distance_units':required,'BC_maximum_x_difference_units':dx,'BC_required_y_difference_units':dy,
        'B_derived_minimum_y_units':b[1],'AB_maximum_x_difference_units':maxdx,'AB_maximum_y_difference_units':maxdy,
        'AB_maximum_squared_distance_units':maximum,'strict_squared_distance_shortfall_units':required-maximum}
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'certify.py');start=time.perf_counter();rawpath=SOURCE/'mutual/081.json';qpath=SOURCE/'queries/018.json'
    inputs=[rawpath,qpath,SOURCE/'plan.json',BASE/'audit/checks.json',BASE/'domain-core/core.json',BASE/'domain-core/model-audit.json',BASE/'solve/selection.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Prove a strict origin-centred disk lies inside the recorded original cog/cog no-fit polygon using exact winding and exact distance to every finite boundary segment. Choose an integer radius at least1 micrometre below that boundary. Any two nonoverlapping source-angle original cogs must have integer-centre squared distance at leastR²+1. For the three solver-indicated selected domains, use only whole integer anchor bounds: B lies above C, bounded horizontal separation forces a minimum B-C vertical gap, which makes the maximum possible A-B distance too small. Check both original boxes and boxes rounded outward to5mm. Group every source-angle cog domain whose whole coordinate box is contained in each enlarged box. Disjoint x intervals ensure the three occupancy groups require distinct cogs. The resulting global three-group exclusion is independently checkable without trusting a solver core, avoids all copy-label permutations, and preserves every original count/material limit.'})
    raw=load(rawpath)['raw_forbidden'];assert raw['type']=='Polygon' and len(raw['coordinates'])==1;ring=[tuple(map(F,p)) for p in raw['coordinates'][0]]
    distances=[];winding=0
    for a,b in zip(ring,ring[1:]):
        dx,dy=b[0]-a[0],b[1]-a[1];length=dx*dx+dy*dy
        if not length:continue
        t=max(F(0),min(F(1),-(a[0]*dx+a[1]*dy)/length));x,y=a[0]+t*dx,a[1]+t*dy;distances.append(x*x+y*y)
        cross=a[0]*b[1]-a[1]*b[0]
        if a[1]<=0<b[1] and cross>0:winding+=1
        elif b[1]<=0<a[1] and cross<0:winding-=1
    assert abs(winding)==1;minimum=min(distances);n=(minimum*1000000).numerator;d=(minimum*1000000).denominator;radius=math.isqrt(n//d)-1
    assert radius>0 and all(F(radius*radius,1000000)<v for v in distances)
    selection=load(BASE/'solve/selection.json')['movable_parts'];core=load(BASE/'domain-core/core.json');assert core['parts']==[3,4,5]
    domains=load(qpath)['domains'];boxes=[]
    for i in core['parts']:
        p=selection[i];assert p['query']==18 and p['profile']==9 and p['sheet']==0;boxes.append(domains[p['domain_row']]['coordinate_bounds'])
    original=derive(boxes,radius);rounded=[[b[0]//5000*5000,b[1]//5000*5000,-((-b[2])//5000)*5000,-((-b[3])//5000)*5000] for b in boxes]
    enlarged=derive(rounded,radius);groups=[]
    for name,b in zip(['A','B','C'],rounded):
        rows=[i for i,f in enumerate(domains) if b[0]<=f['coordinate_bounds'][0] and b[1]<=f['coordinate_bounds'][1] and f['coordinate_bounds'][2]<=b[2] and f['coordinate_bounds'][3]<=b[3]]
        assert rows;groups.append({'name':name,'coordinate_box_units1000':b,'query':18,'domain_rows':rows,'domain_indices':[domains[i]['index'] for i in rows]})
    assert all(set(a['domain_rows']).isdisjoint(b['domain_rows']) for i,a in enumerate(groups) for b in groups[i+1:])
    spec=load(SOURCE/'plan.json');cogs=[p for p in spec['parts'] if p['family']=='cog'];assert len(cogs)==6 and all(p['profiles']==[9] and p['queries']==[18,19] for p in cogs)
    certificate={'coordinate_units_per_mm':1000,'raw_no_fit_case':81,'raw_no_fit_sha256':digest(rawpath),'boundary_segments_checked':len(distances),'origin_winding_number':winding,
        'minimum_exact_boundary_distance_squared_mm2':[minimum.numerator,minimum.denominator],'strict_inner_disk_radius_units':radius,
        'original_boxes':boxes,'original_box_proof':original,'enlarged_box_proof':enlarged,'groups':groups,
        'applicable_moving_cog_parts':[p['part'] for p in cogs],
        'exclusion':'At least one of groups A,B,C must have no selected moving cog domain. All six mandatory cogs remain present; their copy identities may be permuted.'}
    write(OUT/'certificate.json',certificate)
    result={'seconds':time.perf_counter()-start,'strict_inner_disk_radius_mm':radius/1000,'original_boundary_segments_checked':len(distances),
        'global_conflict_group_sizes':[len(g['domain_rows']) for g in groups],'excluded_domain_triples':math.prod(len(g['domain_rows']) for g in groups),
        'enlarged_AB_squared_distance_shortfall_units':enlarged['strict_squared_distance_shortfall_units'],'independent_audit_pending':True,
        'solver_calls':0,'native_packing_calls':0,'full_target_witness':False,'H5_complete':False}
    assert result['seconds']<60;write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
