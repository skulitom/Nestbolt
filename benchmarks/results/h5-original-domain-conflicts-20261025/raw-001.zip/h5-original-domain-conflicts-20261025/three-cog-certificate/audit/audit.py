"""Independent finite-segment and three-region impossibility certificate check."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time,traceback

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-original-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';CERT=BASE/'three-cog-certificate';OUT=CERT/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();cert=load(CERT/'certificate.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [CERT/'plan.json',CERT/'certificate.json',CERT/'result.json',BASE/'audit/checks.json']},
        'method':'Recompute exact finite-segment distances by the independent cross-product/interior-projection formula, and independently count positive-ray crossings to locate the origin inside the full original no-fit polygon. Verify the strict disk radius against every boundary segment and the1-micrometre downward margin. Recheck both complete box deductions with integer squares and ceil-square-root inequalities. Reconstruct all contained domain groups, disjoint x intervals and identical six-cog profiles. The certificate proves these three selected region groups cannot all be occupied without any CP-SAT result or assumed core validity.'})
    for n,h in load(CERT/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
    assert load(BASE/'audit/checks.json')['passed'];rawpath=SOURCE/'mutual/081.json';assert digest(rawpath)==cert['raw_no_fit_sha256']
    raw=load(rawpath)['raw_forbidden'];assert raw['type']=='Polygon' and len(raw['coordinates'])==1;ring=[tuple(map(F,v)) for v in raw['coordinates'][0]]
    distances=[];crossings=0;radius=cert['strict_inner_disk_radius_units']
    for a,b in zip(ring,ring[1:]):
        dx,dy=b[0]-a[0],b[1]-a[1];norm=dx*dx+dy*dy
        if not norm:continue
        dot=-(a[0]*dx+a[1]*dy)
        if 0<=dot<=norm:distance=(a[0]*b[1]-a[1]*b[0])**2/norm
        else:distance=min(a[0]*a[0]+a[1]*a[1],b[0]*b[0]+b[1]*b[1])
        assert F(radius*radius,1000000)<distance;distances.append(distance)
        if (a[1]>0)!=(b[1]>0):
            hit=a[0]-a[1]*(b[0]-a[0])/(b[1]-a[1]);assert hit!=0
            if hit>0:crossings+=1
    assert crossings%2==1 and cert['origin_winding_number'] in [-1,1] and len(distances)==cert['boundary_segments_checked']
    minimum=min(distances);assert minimum==F(*cert['minimum_exact_boundary_distance_squared_mm2'])
    scaled=minimum*1000000;assert (radius+1)**2<=scaled<(radius+2)**2
    def verify_boxes(boxes,p):
        a,b,c=boxes;assert a[2]<c[0] and c[2]<b[0] and b[1]>c[3]
        required=radius**2+1;dx=max(abs(x-y) for x in [b[0],b[2]] for y in [c[0],c[2]])
        dy=p['BC_required_y_difference_units'];assert dy>0 and (dy-1)**2<required-dx*dx<=dy*dy
        newlower=max(b[1],c[1]+dy);assert newlower<=b[3]
        maxx=max(abs(x-y) for x in [a[0],a[2]] for y in [b[0],b[2]])
        maxy=max(abs(x-y) for x in [a[1],a[3]] for y in [newlower,b[3]])
        maximum=maxx**2+maxy**2;assert maximum<required
        assert p=={'required_squared_center_distance_units':required,'BC_maximum_x_difference_units':dx,'BC_required_y_difference_units':dy,'B_derived_minimum_y_units':newlower,
            'AB_maximum_x_difference_units':maxx,'AB_maximum_y_difference_units':maxy,'AB_maximum_squared_distance_units':maximum,'strict_squared_distance_shortfall_units':required-maximum}
    domains=load(SOURCE/'queries/018.json')['domains'];selection=load(BASE/'solve/selection.json')['movable_parts']
    assert cert['original_boxes']==[domains[selection[i]['domain_row']]['coordinate_bounds'] for i in [3,4,5]]
    verify_boxes(cert['original_boxes'],cert['original_box_proof']);boxes=[g['coordinate_box_units1000'] for g in cert['groups']]
    for old,new in zip(cert['original_boxes'],boxes):assert new==[old[0]//5000*5000,old[1]//5000*5000,((old[2]+4999)//5000)*5000,((old[3]+4999)//5000)*5000]
    verify_boxes(boxes,cert['enlarged_box_proof'])
    for group in cert['groups']:
        b=group['coordinate_box_units1000'];rows=[]
        for i,face in enumerate(domains):
            a=face['coordinate_bounds']
            if b[0]<=a[0]<=a[2]<=b[2] and b[1]<=a[1]<=a[3]<=b[3]:rows.append(i)
        assert group['query']==18 and group['domain_rows']==rows and group['domain_indices']==[domains[i]['index'] for i in rows]
    spec=load(SOURCE/'plan.json');cogs=[p for p in spec['parts'] if p['family']=='cog'];assert len(cogs)==6 and [p['part'] for p in cogs]==cert['applicable_moving_cog_parts'] and all(p['profiles']==[9] and p['queries']==[18,19] for p in cogs)
    checks={'passed':True,'seconds':time.perf_counter()-start,'boundary_segments_checked':len(distances),'exact_rational_finite_segment_proof':True,
        'origin_inside_by_independent_ray_crossings':True,'strict_original_no_fit_disk_radius_mm':radius/1000,'two_complete_box_certificates_verified':True,
        'global_conflict_group_sizes':[len(g['domain_rows']) for g in cert['groups']],'excluded_domain_triples':math.prod(len(g['domain_rows']) for g in cert['groups']),
        'all_six_cog_copies_covered_without_label_restriction':True,'independent_of_solver_unsat_core':True,'proved_three_region_occupancy_exclusion':True,
        'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    assert checks['seconds']<60;write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
