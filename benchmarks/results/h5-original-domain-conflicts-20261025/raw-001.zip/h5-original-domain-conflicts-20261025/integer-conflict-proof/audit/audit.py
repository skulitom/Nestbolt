"""Replay the integer contradiction without CP-SAT or proof-generator control flow."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time,traceback

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-original-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';PROOF=BASE/'integer-conflict-proof';OUT=PROOF/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();rules=load(PROOF/'rules.json');events=load(PROOF/'events.json');result=load(PROOF/'result.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,
        'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [PROOF/n for n in ['plan.json','rules.json','events.json','final-bounds.json','result.json']]},
        'method':'Reconstruct every initial selected-domain bound, every inward rule and every full-original separation clause from authoritative source files. Independently replay each logged interval update from its stated rule, proving a claimed unit clause has exactly one direction possible under current bounds. Recompute exact floor/ceiling updates and dependency sets, without the generator traversal or any solver. Check the final empty interval or empty clause and its selected-domain core. A verified core excludes only those same selected domains, not other choices or unrestricted layouts.'})
    for n,h in load(PROOF/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
    selected=load(BASE/'solve/selection.json')['movable_parts'];spec=load(SOURCE/'plan.json');bounds=[];deps=[];inward=[];clauses=[]
    for p in selected:
        d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];q=spec['queries'][p['query']];b=d['coordinate_bounds'];s=q['anchor_bounds_units1000'];i=p['part']
        bounds.extend([[max(b[0],s[0]),min(b[2],s[2])],[max(b[1],s[1]),min(b[3],s[3])]]);deps.extend([[{i},{i}],[{i},{i}]])
        for e,h in enumerate(d['halfplanes']):inward.append({'part':i,'edge':e,'terms':[[2*i,h['a']],[2*i+1,h['b']]],'bound':h['bound']})
    lookup={(r['profile_a'],r['profile_b']):r['index'] for r in spec['mutual_cases']}
    for a,b in combinations(selected,2):
        if a['sheet']!=b['sheet']:continue
        case=lookup[(a['profile'],b['profile'])];row=load(SOURCE/'mutual'/f'{case:03d}.json');i,j=a['part'],b['part']
        for f in row['faces']:
            clauses.append({'parts':[i,j],'case':case,'face':f['index'],'edges':[{'terms':[[2*j,h['a']],[2*i,-h['a']],[2*j+1,h['b']],[2*i+1,-h['b']]],'bound':h['bound']} for h in f['outside_halfplanes']]})
    assert rules=={'initial_bounds':bounds,'inward':inward,'clauses':clauses}
    def limits(terms):
        lower=upper=0;dl=set();du=set()
        for v,c in terms:
            if c>0:lower+=c*bounds[v][0];upper+=c*bounds[v][1];dl|=deps[v][0];du|=deps[v][1]
            elif c<0:lower+=c*bounds[v][1];upper+=c*bounds[v][0];dl|=deps[v][1];du|=deps[v][0]
        return lower,upper,dl,du
    empty_clause=None
    for ei,event in enumerate(events):
        assert time.perf_counter()-start<120
        if event['kind']=='empty_clause':
            clause=clauses[event['clause']];why=set(clause['parts'])
            for h in clause['edges']:
                lo,hi,dl,du=limits(h['terms']);assert hi<h['bound'];why|=du
            assert event['dependencies']==sorted(why) and ei==len(events)-1;empty_clause=(event['clause'],why);continue
        reason=event['reason']
        if reason['kind']=='inward':
            r=inward[reason['rule']];terms,limit,why=r['terms'],r['bound'],{r['part']}
        else:
            clause=clauses[reason['clause']];live=[];why=set(clause['parts'])
            for e,h in enumerate(clause['edges']):
                lo,hi,dl,du=limits(h['terms'])
                if hi>=h['bound']:live.append(e)
                else:why|=du
            assert live==[reason['edge']];r=clause['edges'][live[0]];terms=[[v,-c] for v,c in r['terms']];limit=-r['bound']
        v=event['variable'];c=next(c for w,c in terms if w==v);other=[(w,k) for w,k in terms if w!=v];lo,hi,dl,du=limits(other);rhs=limit-lo
        if c>0:side=1;new=rhs//c
        else:side=0;new=-( (-rhs)//c )
        assert c and event['side']==side and event['old']==bounds[v][side] and event['new']==new
        assert new<bounds[v][1] if side else new>bounds[v][0]
        why|=dl;assert sorted(why)==event['dependencies'];bounds[v][side]=new;deps[v][side]=why
        if bounds[v][0]>bounds[v][1]:assert ei==len(events)-1
    assert bounds==load(PROOF/'final-bounds.json');core=[]
    if result['status']=='CONTRADICTION':
        c=load(PROOF/'contradiction.json')
        if c['kind']=='empty_integer_interval':
            v=c['variable'];assert bounds[v][0]>bounds[v][1] and c['interval']==bounds[v];core=sorted(deps[v][0]|deps[v][1])
        else:assert empty_clause and c['clause']==empty_clause[0];core=sorted(empty_clause[1])
        assert c['core_parts']==core==result['selected_domain_core_parts'] and c['selected_domain_core']==[selected[i] for i in core]
    summary={'passed':True,'seconds':time.perf_counter()-start,'source_inward_rules_rebuilt':len(inward),'whole_original_forbidden_clauses_rebuilt':len(clauses),
        'integer_bound_events_replayed':len(events),'exact_integer_arithmetic_only':True,'independent_of_CP_SAT':True,'status':result['status'],
        'verified_selected_domain_core_parts':core,'verified_selected_domain_core_items':[selected[i]['item'] for i in core],
        'selected_domain_combination_excluded':bool(core),'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',summary);print(summary,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
