"""Bounded fresh additions to the exact returned two-sheet cog partial."""
from collections import Counter,deque
from datetime import datetime,timezone
from itertools import combinations
import copy,math,shutil,subprocess,time
from shapely.geometry import mapping,shape as read_geometry
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import proposals,identity
from build_h5_two_sheet_cog_group_choice import ROOT,SRC,OUT as SEED,load,write,digest,save_rows
OUT=ROOT/'output/h5-two-sheet-final-gaps-20261023'

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'check.py');inputs=[SEED/n for n in ['layout-audit/layout-final.json','layout-audit/checks.json']]+[SRC/n for n in ['job.json','conditional-target.json']]
    assert load(inputs[1])['passed'];job=load(inputs[2]);parts={p['id']:p for p in job['parts']};original=load(inputs[0]);target=load(inputs[3]);stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance']
    counts=Counter(p['part_id'] for p in original['placements']);assert counts==Counter(frame=18,cog=15,bracket=10,insert=20)
    planned=[{'sheet':s,'family':f,'degrees':a,'mirrored':mir} for s in ['sheet-0','sheet-1'] for f,angles,mirrors in [('bracket',[0,90,180,270],[False,True]),('insert',[0,90],[False])] for mir in mirrors for a in angles]
    plan={'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'generation_seconds':30,'queries':planned,'new_pose_caps':{'bracket':200,'insert':200},'combination_seconds':30,'maximum_bracket_sets':20101,'construction_padding_mm':0.0126,
      'method':'Keep every returned 63-part placement exactly fixed. Query all bracket quarter-turn/reflection and both insert rectangle classes on both original target sheets against all fixed filled outlines. Preserve all regions and representative/vertex/midpoint proposals. Process round-robin under fresh caps and independently check actual stock and neighbor geometry. Build every possible conflict among admitted additions. Enumerate zero, one or two compatible brackets and choose the first compatible insert if one exists, respecting remaining quantities two brackets and one insert. Keep all tested sets and any pending suffix, then select maximum original filled area. This is a fresh fixed-layout insertion construction, not a repeated or extended group solver. Conservative regions and finite caps do not prove impossibility. Validate the unchanged prefix and all original geometry and frozen CLI for the chosen result.',
      'solver_calls':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0}
    write(OUT/'plan.json',plan);gap.EPS=.0126;oldg=[shape(parts[p['part_id']],p['transform']) for p in original['placements']];queries=[];start=time.perf_counter()
    for spec in planned:
        if time.perf_counter()-start>=30:break
        this=copy.deepcopy(stock)
        if spec['sheet']=='sheet-1':this['height']=target['required_used_height_mm']
        t={'rotation_radians':math.radians(spec['degrees']),'mirrored':spec['mirrored'],'translation':[0.,0.]};moving=shape(parts[spec['family']],t)
        region=gap.regions(moving,[g for p,g in zip(original['placements'],oldg) if p['sheet_id']==spec['sheet']],this,edge,clear)
        q={'index':len(queries),**spec,'rotation_radians':t['rotation_radians'],'region':mapping(region),'empty':region.is_empty,'proposals':proposals(region)};assert proposals(read_geometry(q['region']))==q['proposals'];write(OUT/f"query-{q['index']}.json",q);queries.append(q)
    queue=deque((q['index'],0) for q in queries if q['proposals']);deferred=[];added=[];geoms=[];seen=set();made=Counter();events=[];oldpairs=0
    while queue and time.perf_counter()-start<30:
        qi,pi=queue.popleft();q=queries[qi];f=q['family']
        if made[f]>=plan['new_pose_caps'][f]:deferred.append([qi,pi]);continue
        p={'part_id':f,'sheet_id':q['sheet'],'transform':{'rotation_radians':q['rotation_radians'],'mirrored':q['mirrored'],'translation':q['proposals'][pi]['point']}}
        g=shape(parts[f],p['transform']);a,b,c,d=g.bounds;h=stock['height'] if q['sheet']=='sheet-0' else target['required_used_height_mm'];outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>h-m['top']-edge+1e-7
        distances=[g.distance(og) for op,og in zip(original['placements'],oldg) if op['sheet_id']==p['sheet_id']];oldpairs+=len(distances);valid=not outside and all(v>=clear-1e-7 for v in distances)
        event={'query':qi,'proposal':pi,'valid':valid,'outside':bool(outside),'minimum_neighbor_distance_mm':min(distances)}
        if valid and identity(p) not in seen:
            assert min(distances)>=clear+gap.EPS-1e-7;assert a>=m['left']+edge+gap.EPS-1e-7 and b>=m['bottom']+edge+gap.EPS-1e-7 and c<=stock['width']-m['right']-edge-gap.EPS+1e-7 and d<=h-m['top']-edge-gap.EPS+1e-7
            event.update(added=True,candidate=len(added));added.append(p);geoms.append(g);seen.add(identity(p));made[f]+=1
        else:event.update(added=False,reason='duplicate' if valid else 'geometry')
        events.append(event)
        if pi+1<len(q['proposals']):queue.append((qi,pi+1))
    generation_seconds=time.perf_counter()-start;write(OUT/'candidates.json',added);write(OUT/'source-events.json',events);write(OUT/'pending-proposals.json',{'queries':planned[len(queries):],'lists':sorted(deferred+list(map(list,queue)))})
    conflicts=[];adj=[set() for _ in added];pairchecks=0
    for i,j in combinations(range(len(added)),2):
        if added[i]['sheet_id']!=added[j]['sheet_id']:continue
        pairchecks+=1
        if geoms[i].distance(geoms[j])<clear-1e-7:conflicts.append([i,j]);adj[i].add(j);adj[j].add(i)
    write(OUT/'conflicts.json',conflicts)
    br=[i for i,p in enumerate(added) if p['part_id']=='bracket'];ins=[i for i,p in enumerate(added) if p['part_id']=='insert'];sets=[[]]+[[i] for i in br]+[list(p) for p in combinations(br,2)];assert len(sets)<=20101
    trials=[];start=time.perf_counter();best=[];bestscore=0
    for bs in sets:
        if time.perf_counter()-start>=30:break
        compatible=all(j not in adj[i] for i,j in combinations(bs,2));chosen=bs.copy() if compatible else []
        if compatible:
            extra=next((j for j in ins if all(j not in adj[i] for i in bs)),None)
            if extra is not None:chosen.append(extra)
        score=sum(40000 if added[i]['part_id']=='bracket' else 19800 for i in chosen)
        trials.append({'brackets':bs,'brackets_compatible':compatible,'chosen':chosen,'filled_area_mm2':score})
        if (score,chosen)>(bestscore,best):bestscore=score;best=chosen
    combination_seconds=time.perf_counter()-start;write(OUT/'trials.json',trials);write(OUT/'pending-combinations.json',sets[len(trials):]);layout=copy.deepcopy(original);outcounts=counts.copy()
    for i in best:
        p=copy.deepcopy(added[i]);p['copy_index']=outcounts[p['part_id']];outcounts[p['part_id']]+=1;layout['placements'].append(p)
    assert layout['placements'][:len(original['placements'])]==original['placements'] and len(best)==len(set(best))
    assert all(outcounts[f]<=p['quantity'] for f,p in parts.items());gs=[shape(parts[p['part_id']],p['transform']) for p in layout['placements']];minimum=math.inf;fullpairs=0;tops=Counter()
    for p,g in zip(layout['placements'],gs):tops[p['sheet_id']]=max(tops[p['sheet_id']],g.bounds[3]+m['top']+edge)
    for i,j in combinations(range(len(gs)),2):
        if layout['placements'][i]['sheet_id']!=layout['placements'][j]['sheet_id']:continue
        fullpairs+=1;d=gs[i].distance(gs[j]);minimum=min(minimum,d);assert gs[i].disjoint(gs[j]) and d>=clear-1e-7
    material=stock['width']*(stock['height']+tops['sheet-1']);assert material<=target['target_material_mm2']+1e-6
    write(OUT/'layout.json',layout);cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    source=ROOT/'output/h5-coordinated-placement-selection-20261018';cmd=[str(cli),'validate','--library',str(source/'library.json'),'--request',str(source/'request.json'),'--layout',str(OUT/'layout.json')]
    cp=subprocess.run(cmd,capture_output=True,timeout=60);(OUT/'public.json').write_bytes(cp.stdout);(OUT/'public.stderr').write_bytes(cp.stderr);write(OUT/'command.json',{'command':cmd,'exit_code':cp.returncode});public=load(OUT/'public.json')
    missing={f:p['quantity']-outcounts[f] for f,p in parts.items() if outcounts[f]<p['quantity']};expected=[{'code':'quantity','message':f"part {f}: expected {parts[f]['quantity']}, found {outcounts[f]}"} for f in missing]
    assert sorted(public['violations'],key=lambda v:v['message'])==sorted(expected,key=lambda v:v['message']) and public['valid']==(not missing) and (cp.returncode==0)==(not missing)
    checks={'passed':True,'generation_seconds':generation_seconds,'queries_completed':len(queries),'empty_regions':sum(q['empty'] for q in queries),'pending_queries':len(planned)-len(queries),'pending_proposal_lists':len(deferred)+len(queue),'new_candidates':dict(made),'events':len(events),'proposal_original_pair_checks':oldpairs,'addition_pair_checks':pairchecks,'conflicts':len(conflicts),'combination_seconds':combination_seconds,'bracket_sets_checked':len(trials),'pending_bracket_sets':len(sets)-len(trials),'selected_additions':best,'added_filled_area_mm2':bestscore,'counts':dict(outcounts),'missing':missing,'filled_area_mm2':sum(g.area for g in gs),'material_mm2':material,'minimum_distance_mm':minimum,'full_original_geometry_pairs':fullpairs,'original_prefix_unchanged':True,'fresh_frozen_CLI_calls':1,'full_target_witness':public['valid'],'native_margin_qualified':False,'solver_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
