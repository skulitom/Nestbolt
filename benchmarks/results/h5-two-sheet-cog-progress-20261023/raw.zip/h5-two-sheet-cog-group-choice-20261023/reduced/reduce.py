"""Fresh substitutions preserving every complete-group compatibility and original count."""
from collections import Counter
from datetime import datetime,timezone
import gzip,json,shutil,time
from build_h5_two_sheet_cog_group_choice import ROOT,OUT as BASE,load,write,digest,save_rows
from census_h5_one_part_moves import bits
OUT=BASE/'reduced'

def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'reduce.py')
    inputs=[BASE/n for n in ['plan.json','candidates.json','mapping.json','cliques.jsonl.gz','audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_seconds':30,'maximum_comparisons':10000000,
      'method':'On the complete newly audited graph and all 365 group-compatibility lists, order candidates by degree and global id. Remove b only for an earlier retained adjacent a of the same family, with N(a) minus b contained in N(b), and every group compatible with b also compatible with a. Check each certificate independently by enumerating original neighbors and groups. This preserves exact family counts, filled area and every group choice. Keep every remaining candidate when either limit is reached. Project every original verified clique to retained variables and independently compare the complete induced adjacency. Map the exact prior 63-part seed only through these fresh certificates and verify its full count, graph and group feasibility. No prior reduction or pending comparison is resumed.'})
    pool=load(BASE/'candidates.json');mp=load(BASE/'mapping.json');ids=mp['candidates'];local={i:j for j,i in enumerate(ids)};adj=[0]*len(ids);cliques=[]
    with gzip.open(BASE/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            c=json.loads(line);cliques.append(c);mask=sum(1<<j for j in c)
            for j in c:adj[j]|=mask^(1<<j)
    assert sum(a.bit_count() for a in adj)//2==load(BASE/'audit/checks.json')['conflicts']
    fam=[pool[i]['placement']['part_id'] for i in ids];allowed=[sum(1<<g for g in groups) for groups in mp['compatible_groups']];order=sorted(range(len(ids)),key=lambda j:(adj[j].bit_count(),ids[j]))
    kept=[];byfamily={f:[] for f in set(fam)};removed=[];comparisons=0;start=time.perf_counter();bounded=False
    for at,b in enumerate(order):
        replacement=None
        if time.perf_counter()-start>=30 or comparisons>=10000000:kept+=order[at:];bounded=True;break
        for a in byfamily[fam[b]]:
            comparisons+=1
            if (adj[b]>>a)&1 and not(allowed[b]&~allowed[a]) and not(adj[a]&~(adj[b]|(1<<b))):replacement=a;break
            if comparisons>=10000000:break
        if replacement is None:kept.append(b);byfamily[fam[b]].append(b)
        else:removed.append({'removed':ids[b],'replacement':ids[replacement]})
    seconds=time.perf_counter()-start;kept=sorted(kept);kept_set=set(kept);kept_global=[ids[j] for j in kept];replacements={r['removed']:r['replacement'] for r in removed}
    assert set(kept_global).isdisjoint(replacements) and set(kept_global)|replacements.keys()==set(ids)
    certificate_neighbors=certificate_groups=0
    for r in removed:
        b,a=local[r['removed']],local[r['replacement']];assert a in kept_set and fam[a]==fam[b] and (adj[b]>>a)&1
        for j in bits(adj[a]):
            certificate_neighbors+=1
            if j!=b:assert (adj[b]>>j)&1
        for g in mp['compatible_groups'][b]:certificate_groups+=1;assert g in mp['compatible_groups'][a]
    remap={old:new for new,old in enumerate(kept)};projected=sorted({tuple(sorted(remap[j] for j in c if j in kept_set)) for c in cliques});projected=[c for c in projected if len(c)>1];covered=[0]*len(kept)
    for c in projected:
        mask=sum(1<<j for j in c)
        for j in c:covered[j]|=mask^(1<<j)
    expected=[sum(1<<remap[j] for j in bits(adj[i]) if j in kept_set) for i in kept];assert covered==expected
    save_rows(OUT/'cliques.jsonl.gz',projected);write(OUT/'substitutions.json',removed)
    seed=sorted(replacements.get(i,i) for i in mp['seed_candidates']);local2={i:j for j,i in enumerate(kept_global)};seed_local=[local2[i] for i in seed];mask=sum(1<<j for j in seed_local)
    assert len(seed)==len(set(seed))==30 and Counter(pool[i]['placement']['part_id'] for i in seed)==Counter(bracket=9,insert=21)
    compatible=[mp['compatible_groups'][j] for j in kept]
    assert all(not(covered[j]&mask) and mp['seed_group'] in compatible[j] for j in seed_local)
    write(OUT/'mapping.json',{**mp,'candidates':kept_global,'compatible_groups':compatible,'seed_candidates':seed,'original_seed_candidates':mp['seed_candidates']})
    checks={'passed':True,'seconds':seconds,'comparisons':comparisons,'limit_reached':bounded,'original_candidates':len(ids),'kept_candidates':len(kept),'removed_candidates':len(removed),'certificate_neighbors_independently_verified':certificate_neighbors,'certificate_group_memberships_independently_verified':certificate_groups,'all_substitutions_preserve_family_count_area_and_group_choice':True,'projected_cliques':len(projected),'full_induced_graph_coverage_checked':True,'prior_63_part_seed_mapped_and_verified':True,'original_CLI_acceptance_pending':True,'native_margin_qualified':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
