"""Independent original geometry, complete-group compatibility and graph audit."""
from collections import Counter,deque
from itertools import combinations
import copy,gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import shape as read_geometry,box
from shapely.affinity import affine_transform
from shapely.ops import unary_union
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_two_sheet_cog_group_choice import ROOT,SRC,OLD,BLOCK,CAT,BEST,COVER,OUT,load,write,digest

def main():
    dst=OUT/'audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');start=time.perf_counter();plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    pool=load(OUT/'candidates.json');source=load(OLD/'candidates.json');mp=load(OUT/'mapping.json');result=load(OUT/'result.json');assert pool[:len(source)]==source and mp['source_pool_size']==len(source)
    keys={identity(p['placement']):i for i,p in enumerate(source)};assert len(keys)==len(source)
    selected=sorted(keys[identity(p)] for p in load(OLD/'layout-audit/layout-final.json')['placements']);fixed=sorted(i for i in selected if source[i]['placement']['part_id']=='frame');seed=sorted(i for i in selected if source[i]['placement']['part_id'] in ['bracket','insert'])
    assert fixed==mp['fixed_candidates'] and seed==mp['seed_candidates'] and len(fixed)==18
    catalogue=load(CAT/'placements.json');last=[p for p in load(BEST/'layout.json')['placements'] if p['part_id']=='cog' and p['sheet_id']=='sheet-1'];assert len(last)==1
    specs=[]
    for i,r in enumerate(catalogue):
        if r['zone']['sheet']!='sheet-0':continue
        if len(r['placements'])==15:
            specs.append((i,None,False));specs.extend((i,j,True) for j in range(15))
        elif len(r['placements'])==14:specs.append((i,None,True))
    groups=[]
    for i,(g,drop,include) in enumerate(specs):
        ps=[p for j,p in enumerate(catalogue[g]['placements']) if drop is None or j!=drop]+(last if include else [])
        cg=sorted(keys[identity(p)] for p in ps);assert len(cg)==len(set(cg))==15
        groups.append({'index':i,'catalogue_group':g,'drop':drop,'last_seed_cog':include,'candidates':cg})
    assert len(groups)==165 and groups==load(OLD/'mapping.json')['cog_groups']
    prior_sets={tuple(g['candidates']) for g in groups}
    first=[i for i,r in enumerate(catalogue) if r['zone']['sheet']=='sheet-0'];last_groups=[None]+[i for i,r in enumerate(catalogue) if r['zone']['sheet']=='sheet-1']
    combined=[(i,j) for i in first for j in last_groups if len(catalogue[i]['placements'])+(len(catalogue[j]['placements']) if j is not None else 0)==15]
    new_cases=[];combined_seen=set()
    for index,(i,j) in enumerate(combined):
        ps=catalogue[i]['placements']+(catalogue[j]['placements'] if j is not None else [])
        cg=sorted(keys[identity(p)] for p in ps);key=tuple(cg)
        if key not in combined_seen and key not in prior_sets:
            new_cases.append({'index':index,'first_group':i,'last_group':j,'candidates':cg,'first_sheet_cogs':len(catalogue[i]['placements']),'last_sheet_cogs':len(catalogue[j]['placements']) if j is not None else 0,'in_prior_165_cases':False,'same_as_case':None})
        combined_seen.add(key)
    assert new_cases==load(COVER/'new-cases.json') and len(new_cases)==200
    for r in new_cases:groups.append({'index':len(groups),'source_coverage_case':r['index'],'first_group':r['first_group'],'last_group':r['last_group'],'candidates':r['candidates']})
    assert len(groups)==365 and groups==mp['cog_groups']==plan['groups'] and mp['seed_group']==144
    assert set(groups[144]['candidates'])==set(selected)-set(fixed)-set(seed)
    orientations=[{'family':f,'degrees':a,'mirrored':mir} for f,angles,mirrors in [('bracket',[0,90,180,270],[False,True]),('insert',[0,90],[False])] for mir in mirrors for a in angles]
    planned=[];seen=set()
    prior_queries={(q['sheet'],tuple(q['neighbors']),q['family'],q['degrees'],q['mirrored']) for q in load(OLD/'plan.json')['queries']}
    for group in groups[165:]:
        for sheet in ['sheet-0','sheet-1']:
            neighbors=[i for i in fixed+group['candidates'] if source[i]['placement']['sheet_id']==sheet]
            for o in orientations:
                k=(sheet,tuple(neighbors),o['family'],o['degrees'],o['mirrored'])
                if k in prior_queries:continue
                if k not in seen:seen.add(k);planned.append({'index':len(planned),'case':group['index'],'sheet':sheet,'neighbors':neighbors,**o})
    assert planned==plan['queries'];job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clear=job['clearance'];target=load(SRC/'conditional-target.json');gap.EPS=plan['construction_padding_mm']
    gs={i:shape(parts[p['placement']['part_id']],p['placement']['transform']) for i,p in enumerate(pool)}
    caches=load(OUT/'cache-index.json');cache={};maxerror=0.
    for at,r in enumerate(caches):
        saved=load(OUT/'obstacles'/f'{at}.json');assert r=={k:v for k,v in saved.items() if k!='geometry'} and r['index']==at
        o=r['moving'];moving=shape(parts[o['family']],{'rotation_radians':math.radians(o['degrees']),'mirrored':o['mirrored'],'translation':[0.,0.]});g=read_geometry(saved['geometry'])
        assert gap.obstacle(shape(parts[r['fixed_part']],r['fixed_transform']),moving,clear).equals_exact(g,0)
        p=r['first_actual_fixed'];t=p['transform'];direct=gap.obstacle(shape(parts[p['part_id']],t),moving,clear);shift=affine_transform(g,[1,0,0,1,*t['translation']]);error=direct.hausdorff_distance(shift);maxerror=max(maxerror,error)
        assert error<1e-7 and direct.symmetric_difference(shift).area<1e-5
        k=(r['fixed_part'],float(r['fixed_transform']['rotation_radians']).hex(),r['fixed_transform']['mirrored'],o['family'],o['degrees'],o['mirrored']);assert k not in cache;cache[k]=g
    queries=[];maxregionerror=0.
    for i in range(result['completed_queries']):
        q=load(OUT/'regions'/f'query-{i}.json');assert all(q[k]==v for k,v in planned[i].items()) and q['rotation_radians']==math.radians(q['degrees'])
        moving=shape(parts[q['family']],{'rotation_radians':q['rotation_radians'],'mirrored':q['mirrored'],'translation':[0.,0.]});a,b,c,d=moving.bounds;h=stock['height'] if q['sheet']=='sheet-0' else target['required_used_height_mm']
        domain=box(m['left']+edge+gap.EPS-a,m['bottom']+edge+gap.EPS-b,stock['width']-m['right']-edge-gap.EPS-c,h-m['top']-edge-gap.EPS-d);ob=[]
        for j in q['neighbors']:
            p=pool[j]['placement'];t=p['transform'];k=(p['part_id'],float(t['rotation_radians']).hex(),t['mirrored'],q['family'],q['degrees'],q['mirrored']);ob.append(affine_transform(cache[k],[1,0,0,1,*t['translation']]))
        expected=domain.difference(unary_union(ob));region=read_geometry(q['region']);error=expected.symmetric_difference(region).area;maxregionerror=max(maxregionerror,error)
        assert expected.is_empty==region.is_empty and error<1e-6 and q['proposals']==proposals(region);queries.append(q)
    oldsmall=[i for i,p in enumerate(source) if p['placement']['part_id'] in ['bracket','insert']];oldframes=[];framepairs=0;filters=load(OUT/'frame-filter.json');assert len(filters)==len(oldsmall)
    for i,row in zip(oldsmall,filters):
        blockers=[]
        for j in fixed:
            if source[j]['placement']['sheet_id']!=source[i]['placement']['sheet_id']:continue
            framepairs+=1
            if gs[i].distance(gs[j])<clear-1e-7:blockers.append(j)
        assert row=={'candidate':i,'frame_blockers':blockers}
        if not blockers:oldframes.append(i)
    assert oldframes==mp['old_frame_compatible'];queue=deque((q['index'],0) for q in queries if q['proposals']);deferred=[];counts=Counter();added=[];rejects=duplicates=proposaldistances=0
    for event in load(OUT/'source-events.json'):
        while True:
            qi,pi=queue.popleft();q=queries[qi]
            if counts[q['family']]>=plan['new_contact_caps'][q['family']]:deferred.append([qi,pi])
            else:break
        assert (event['query'],event['proposal'])==(qi,pi)
        p={'part_id':q['family'],'sheet_id':q['sheet'],'transform':{'rotation_radians':q['rotation_radians'],'mirrored':q['mirrored'],'translation':q['proposals'][pi]['point']}}
        g=shape(parts[p['part_id']],p['transform']);a,b,c,d=g.bounds;h=stock['height'] if q['sheet']=='sheet-0' else target['required_used_height_mm'];outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>h-m['top']-edge+1e-7
        dd=[g.distance(gs[j]) for j in q['neighbors']];proposaldistances+=len(dd);blockers=[j for j,dist in zip(q['neighbors'],dd) if dist<clear-1e-7]
        if outside or blockers:rejects+=1;assert event=={'query':qi,'proposal':pi,'added':False,'reason':'geometry','outside':bool(outside),'blockers':blockers}
        elif identity(p) in keys:duplicates+=1;assert event=={'query':qi,'proposal':pi,'added':False,'reason':'duplicate','candidate':keys[identity(p)]}
        else:
            i=len(source)+len(added);assert event=={'query':qi,'proposal':pi,'added':True,'candidate':i} and pool[i]['placement']==p and pool[i]['source']=={'kind':'two-sheet-cog-group-contact','query':qi,'proposal':pi} and abs(pool[i]['filled_area_mm2']-g.area)<1e-7
            assert not dd or min(dd)>=clear+gap.EPS-1e-7
            assert a>=m['left']+edge+gap.EPS-1e-7 and b>=m['bottom']+edge+gap.EPS-1e-7 and c<=stock['width']-m['right']-edge-gap.EPS+1e-7 and d<=h-m['top']-edge-gap.EPS+1e-7
            keys[identity(p)]=i;added.append(i);counts[p['part_id']]+=1
        if pi+1<len(q['proposals']):queue.append((qi,pi+1))
    pending=load(OUT/'pending.json');assert pending=={'queries':planned[len(queries):],'proposal_lists':sorted(deferred+list(map(list,queue)))}
    assert added==mp['new_candidates'] and dict(counts)==result['new_candidates']
    allsmall=oldframes+added;cogs=sorted({i for g in groups for i in g['candidates']});blocked={i:set() for i in allsmall};cogedges=[];cogposs=cogexact=0
    for sheet in ['sheet-0','sheet-1']:
        sm=np.asarray([i for i in allsmall if pool[i]['placement']['sheet_id']==sheet]);gg=np.asarray([gs[int(i)] for i in sm],dtype=object);bb=shapely.bounds(gg)
        for i in cogs:
            if pool[i]['placement']['sheet_id']!=sheet:continue
            cogposs+=len(sm);a,b,c,d=gs[i].bounds;dx=np.maximum(0,np.maximum(bb[:,0]-c,a-bb[:,2]));dy=np.maximum(0,np.maximum(bb[:,1]-d,b-bb[:,3]));js=np.flatnonzero(np.hypot(dx,dy)<=clear+1e-7);cogexact+=len(js)
            for j in js[shapely.distance(gs[i],gg[js])<clear-1e-7]:other=int(sm[j]);blocked[other].add(i);cogedges.append([i,other])
    with gzip.open(OUT/'cog-conflicts.jsonl.gz','rt',encoding='utf-8') as f:assert [json.loads(l) for l in f]==sorted(cogedges)
    compatibility=[{'candidate':i,'compatible_groups':[g['index'] for g in groups if not blocked[i].intersection(g['candidates'])]} for i in allsmall]
    assert compatibility==load(OUT/'compatibility.json');ids=[r['candidate'] for r in compatibility if r['compatible_groups']]
    assert ids==mp['candidates'] and [r['compatible_groups'] for r in compatibility if r['compatible_groups']]==mp['compatible_groups']
    allfixed=set(fixed+cogs);group_pairs=0
    for i in set(ids)|allfixed:
        p=pool[i]['placement'];t=p['transform'];part=parts[p['part_id']];a,b,c,d=gs[i].bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        assert gs[i].is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
    for group in groups:
        for i,j in combinations(fixed+group['candidates'],2):
            if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
            group_pairs+=1;assert gs[i].disjoint(gs[j]) and gs[i].distance(gs[j])>=clear-1e-7
    gg=np.asarray([gs[i] for i in ids],dtype=object);bb=shapely.bounds(gg);ss=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);adj=[0]*len(ids);allpairs=near=0
    for i in range(len(ids)):
        js=np.arange(i+1,len(ids));js=js[ss[js]==ss[i]];allpairs+=len(js);dx=np.maximum(0,np.maximum(bb[js,0]-bb[i,2],bb[i,0]-bb[js,2]));dy=np.maximum(0,np.maximum(bb[js,1]-bb[i,3],bb[i,1]-bb[js,3]));js=js[np.hypot(dx,dy)<=clear+1e-7];near+=len(js)
        for j in js[shapely.distance(gg[i],gg[js])<clear-1e-7]:j=int(j);adj[i]|=1<<j;adj[j]|=1<<i
    edgecount=sum(v.bit_count() for v in adj)//2;previous=(-1,-1);seen=0
    with gzip.open(OUT/'conflicts.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:pair=tuple(json.loads(line));i,j=pair;assert pair>previous and i<j and (adj[i]>>j)&1;previous=pair;seen+=1
    assert seen==edgecount==result['conflicts'];covered=[0]*len(ids);cliquecount=0
    with gzip.open(OUT/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            c=json.loads(line);assert len(c)==len(set(c));mask=sum(1<<i for i in c);cliquecount+=1
            for i in c:others=mask^(1<<i);assert not(others&~adj[i]);covered[i]|=others
    assert covered==adj;local={i:j for j,i in enumerate(ids)};seedmask=sum(1<<local[i] for i in seed)
    assert all(not(adj[local[i]]&seedmask) and 144 in mp['compatible_groups'][local[i]] for i in seed)
    record={'passed':True,'seconds':time.perf_counter()-start,'all_365_groups_reconstructed':True,'additional_200_groups_reconstructed':True,'no_prior_query_repeated':True,'group_geometry_pairs':group_pairs,'cache_entries':len(cache),'maximum_absolute_translation_error_mm':maxerror,'query_regions_reconstructed':len(queries),'maximum_region_area_error_mm2':maxregionerror,'frame_filter_pairs':framepairs,'proposal_neighbor_pairs':proposaldistances,'duplicates':duplicates,'rejections':rejects,'pending_lists_preserved':len(pending['proposal_lists']),'cog_small_pair_possibilities':cogposs,'cog_small_exact_distances':cogexact,'cog_conflicts':len(cogedges),'all_compatibility_lists_reconstructed':True,'small_pair_possibilities':allpairs,'small_pair_exact_distances':near,'conflicts':edgecount,'cliques_including_residual':cliquecount,'complete_graph_coverage':True,'original_seed_preserved':True,'native_margin_qualified':False}
    write(dst/'checks.json',record);print(record,flush=True)
if __name__=='__main__':main()
