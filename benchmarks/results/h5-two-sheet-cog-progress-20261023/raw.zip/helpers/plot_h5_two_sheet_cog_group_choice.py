from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
src=root/'output/h5-two-sheet-cog-group-choice-20261023'
layout=json.loads((src/'layout-audit/layout-final.json').read_bytes())
from collections import Counter
counts=Counter(p['part_id'] for p in layout['placements'])
missing=', '.join(f'{n-counts[f]} {f}{"s" if n-counts[f]!=1 else ""}' for f,n in [('bracket',12),('cog',15),('insert',21)] if counts[f]<n)
s=(root/'output/plot_h5_dense_insert_gap.py').read_text(encoding='utf-8')
s=s.replace("src=root/'output/h5-dense-insert-gap-20261023'", "src=root/'output/h5-two-sheet-cog-group-choice-20261023'")
s=s.replace("src/'layout.json'", "src/'layout-audit/layout-final.json'")
s=s.replace('Improved partial: 64 of 66 parts; missing two cogs', f'Two-sheet cog partial: {len(layout["placements"])} of 66 parts; missing {missing}')
exec(compile(s,str(__file__),'exec'))
