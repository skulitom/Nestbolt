"""Use the central opening for nine original inserts, retaining all remaining obligations."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];FRAMES=ROOT/'output/h5-central-notch-frame-core-20261026';SHORT=ROOT/'output/h5-nine-insert-short-sheet-20261026';PRIOR=ROOT/'output/h5-central-notch-mixed-core-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-central-nine-insert-core-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[FRAMES/'frame-placements.json',FRAMES/'checks.json',SHORT/'short-sheet-placements.json',SHORT/'audit/checks.json',PRIOR/'placements.json',PRIOR/'audit/checks.json',JOB,SRC/'items.json',SRC/'geometry.json',ROOT/'output/h5-compact-joint-model-20261026/response-audit/checks.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'After the compact fixed24 model closes UNKNOWN, preserve all18 checked central-notch frame poses and all15 original short poses. Replace the opening contents(two brackets plus four inserts) with nine original180x110 inserts in three rows of three, with0.225mm spacing. Keep all six first-sheet bracket originals, the other three first inserts and all15 cogs mandatory. The former notch contents occupy159200mm2 of filled area; nine inserts occupy178200mm2, reducing remaining first-sheet filled demand by19000mm2. This42-original subassembly is not a better partial count than the earlier64; no old domain or unknown result transfers as an exclusion. No solver/native call.'})
assert load(PRIOR/'audit/checks.json')['passed'] and load(ROOT/'output/h5-compact-joint-model-20261026/response-audit/checks.json')['status']=='UNKNOWN';items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};frames=load(FRAMES/'frame-placements.json');short=load(SHORT/'short-sheet-placements.json');insert=[];anchors=[]
for i,original in enumerate(range(38,47)):
    row,col=divmod(i,3);x=456.75+col*180.225;y=1807.65+row*110.225;insert.append({'part_id':'insert','copy_index':items[original]['copy'],'sheet_id':'sheet-0','transform':{'rotation_radians':0.,'mirrored':False,'translation':[x,y]}});anchors.append({'original':original,'row':row,'column':col,'lower_left_mm':[x,y]})
placements=frames+insert+short;job=load(JOB);parts={p['id']:p for p in job['parts']};stocks=[[float(F(*v)) for v in r] for r in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);shapes={};edges=[];holes=vertices=0
for p in placements:
    original=ids[p['part_id'],p['copy_index']];t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;g=parts[p['part_id']]['geometry'][0];a=[mi*co,-si,mi*si,co,*t['translation']];filled=affine_transform(Polygon(g['outer']),a);full=affine_transform(Polygon(g['outer'],g.get('holes',[])),a);assert filled.is_valid and full.is_valid;sheet=int(p['sheet_id'].split('-')[1]);b=filled.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;shapes[original]=(sheet,filled);edges.append({'original':original,'extra_margins_mm':extra});holes+=len(full.interiors);vertices+=sum(len(h) for h in g.get('holes',[]))
pairs=[]
for i,j in combinations(sorted(shapes),2):
    sa,a=shapes[i];sb,b=shapes[j]
    if sa==sb:d=a.distance(b);assert a.disjoint(b) and d>gap;pairs.append({'originals':[i,j],'distance_mm':d})
remaining=sorted(set(range(66))-set(shapes));assert len(shapes)==len(placements)==42 and remaining==[18,19,20,23,24,27,47,48,49]+list(range(51,66));write(OUT/'placements.json',placements);write(OUT/'insert-placements.json',insert);write(OUT/'anchors.json',anchors);write(OUT/'mandatory-remaining-originals.json',remaining);write(OUT/'pairs.json',pairs);write(OUT/'stock-edges.json',edges)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_placed':42,'fixed_first_originals':27,'fixed_short_originals':15,'central_insert_originals':9,'mandatory_remaining_counts':dict(Counter(items[i]['family'] for i in remaining)),'all66_originals_accounted_once':True,'same_sheet_pairs':len(pairs),'stock_edge_checks':168,'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_pair_gap_mm':min(p['distance_mm'] for p in pairs),'minimum_extra_stock_mm':min(min(p['extra_margins_mm']) for p in edges),'remaining_first_filled_area_reduction_mm2':19000,'old64_partial_preserved':True,'old_domains_or_exclusions_transferred':False,'independent_readback_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
