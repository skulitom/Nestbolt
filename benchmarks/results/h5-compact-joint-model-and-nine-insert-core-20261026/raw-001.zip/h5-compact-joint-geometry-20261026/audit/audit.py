"""Exact all-mode, all-fractional-anchor inner-component necessity certificate."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,math,shutil,time
from h5_rational_geometry_helpers import contains,point_bounds,sub,mul
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-compact-joint-geometry-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';INV=ROOT/'output/h5-fixed24-joint-neighborhood-20261026';SUP=ROOT/'output/h5-fixed24-joint-support-domains-20261026';FACETS=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026';GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ratio=lambda x:[x.numerator,x.denominator]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();paths=[p for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents]+[GEOM/'original-cog-proof.json',GEOM/'audit/checks.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Independently reconstruct each exact orthogonal source grid and every allowed ideal quarter turn/mirror. Verify source area coverage. Use rational Taylor intervals on each actual stored angle; subtract the shared fractional anchor before taking exact edge cross products. Prove every4micrometre-inset component corner strictly inside its actual original component for every fractional anchor in the full closed[0,1]micrometre box. Convexity then contains the entire inner rectangle. Verify ideal/actual outer-coordinate errors, relaxed stock bounds, support-interval overlap conditions, every polygon facet and all66 identity obligations.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SUP/'audit/checks.json')['passed'] and load(GEOM/'audit/checks.json')['passed'];spec=load(INV/'next-neighborhood.json');assert sorted(spec['fixed_first_originals']+spec['fixed_short_originals']+spec['mandatory_moving_first_originals'])==list(range(66));assert len(spec['mandatory_moving_first_noncogs'])==12 and len(spec['mandatory_moving_first_cogs'])==15
parts={p['id']:p for p in load(JOB)['parts']};profiles=load(BASE/'profiles.json');sources=load(BASE/'source-grid-components.json');const=load(BASE/'constants.json');assert const['moving_inset']==4 and const['rounded_cog_box_inset']==2 and const['stock_bounds_units1000']==[6500,6500,1493500,2993500] and const['relaxed_stock_bounds_units1000']==[6480,6480,1493520,2993520]
profiles_checked=components=corners=edges=0;max_error=F(0);minimum_cross=None;certs=[]
for family in ['bracket','insert']:
    p=parts[family];vs=[tuple(map(F,v)) for v in p['geometry'][0]['outer']];assert p['rotations']=={'kind':'list','degrees':[0.,90.,180.,270.]};assert all(a[0]==b[0] or a[1]==b[1] for a,b in zip(vs,vs[1:]+vs[:1]));xs=sorted({x for x,y in vs});ys=sorted({y for x,y in vs});rects=[]
    for i,j in product(range(len(xs)-1),range(len(ys)-1)):
        a,c=xs[i:i+2];b,d=ys[j:j+2]
        if contains(vs,((a+c)/2,(b+d)/2)):rects.append([a,b,c,d])
    assert rects==sources[family];area=abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(vs,vs[1:]+vs[:1])))/2;assert sum((c-a)*(d-b) for a,b,c,d in rects)==area
    allowed=list(product([False,True] if p['allow_mirror'] else [False],p['rotations']['degrees']));assert len(profiles[family])==len(allowed)
    for mode,(row,(mirror,degree)) in enumerate(zip(profiles[family],allowed)):
        assert row['mode']==mode and row['degrees']==degree and row['mirrored']==mirror and row['rotation_radians']==math.radians(degree);quarter=int(degree/90);mi=-1 if mirror else 1
        def ideal(x,y):
            x*=mi
            return [(x,y),(-y,x),(-x,-y),(y,-x)][quarter]
        rotated=[ideal(x,y) for x,y in vs];mn=[min(q[k] for q in rotated) for k in range(2)];mx=[max(q[k] for q in rotated) for k in range(2)];assert mn==row['ideal_outer_min_mm'] and [int((mx[k]-mn[k])*1000) for k in range(2)]==row['outer_size_units1000'];t={'rotation_radians':row['rotation_radians'],'mirrored':mirror,'translation':[-mn[0],-mn[1]]}
        for original,q in zip(vs,rotated):
            bounds=point_bounds(original,t)
            for k in range(2):
                error=max(abs(v-(q[k]-mn[k])) for v in bounds[k]);max_error=max(max_error,error);assert error<F(1,1000000)
        assert len(row['components_units1000'])==len(rects)
        for index,(a,b,c,d) in enumerate(rects):
            source=[(a,b),(c,b),(c,d),(a,d)];q=[ideal(x,y) for x,y in source];box=[int((min(z[0] for z in q)-mn[0])*1000),int((min(z[1] for z in q)-mn[1])*1000),int((max(z[0] for z in q)-mn[0])*1000),int((max(z[1] for z in q)-mn[1])*1000)];assert box==row['components_units1000'][index];inner=[box[0]+4,box[1]+4,box[2]-4,box[3]-4];true=[point_bounds(v,t) for v in source];local_min=None
            for x,y in product([F(inner[0],1000),F(inner[2],1000)],[F(inner[1],1000),F(inner[3],1000)]):
                point=((x-F(1,1000),x),(y-F(1,1000),y))
                for aa,bb in zip(true,true[1:]+true[:1]):
                    cross=sub(mul(sub(bb[0],aa[0]),sub(point[1],aa[1])),mul(sub(bb[1],aa[1]),sub(point[0],aa[0])));lower=cross[0] if mi==1 else -cross[1];assert lower>0;edges+=1;local_min=lower if local_min is None else min(local_min,lower)
                corners+=1
            minimum_cross=local_min if minimum_cross is None else min(minimum_cross,local_min);components+=1;w,h=inner[2]-inner[0],inner[3]-inner[1];assert min(w,h)>2*const['cog_support_transverse'] and min(w,h)+const['cog_original_inner_radius']>const['cog_original_outer_radius'];certs.append({'family':family,'mode':mode,'component':index,'strict_cross_lower_mm2':ratio(local_min),'inner_size_units1000':[w,h]})
        profiles_checked+=1
assert max_error<F(1,1000000) and F(1,1000000)*1000+1<20
source=load(SUP/'fixed-source-rectangles.json');assert load(BASE/'fixed-components.json')==[{'index':r['index'],'original':r['item'],'bounds_units1000':r['world_inner_rectangle_units1000']} for r in source] and len(source)==28
cog=load(GEOM/'original-cog-proof.json');assert cog['original_inscribed_radius_units1000']==109115 and cog['all_angle_stock_support_radius_units1000']==139270 and 15000**2>=140001**2-139270**2
vertices=load(FACETS/'vertices.json');facets=load(FACETS/'facets.json');assert len(vertices)==len(facets)==32
for k,(a,b) in enumerate(zip(vertices,vertices[1:]+vertices[:1])):
    nx,ny=b[1]-a[1],a[0]-b[0];rhs=nx*a[0]+ny*a[1];assert facets[k]=={'normal':[nx,ny],'rhs':rhs} and rhs>0 and all(nx*x+ny*y<=rhs for x,y in vertices) and a[0]**2+a[1]**2<254297**2;c=vertices[(k+2)%32];assert(b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0])>0
write(OUT/'component-certificates.json',certs);write(OUT/'necessity-proof.json',{'all27_movers_required':True,'all66_identities_accounted_once':True,'statement':'For every allowed non-cog quarter turn and mirror, ideal axis-aligned components exactly cover the original filled outer before inset. Floor the translated ideal outer minimum to integer micrometres. Its true fractional translation lies in[0,1)^2 micrometres. Exact source-edge cross-product intervals prove the four corners of each4-unit-inset model rectangle strictly inside its true transformed component throughout the larger closed[0,1]^2 fractional box; convexity contains the full model rectangle. Outer-coordinate error below0.000001mm plus flooring is smaller than the20-unit outward stock allowance. Thus every source placement maps into the mode table, stock bounds and positive-size inner boxes. Disjoint original filled outers imply mutual nonoverlap of these moving boxes and the28 already certified fixed boxes. Every inner component has transverse width above2beta and minsize+r>R. The source support-tip/inner-disk interval proof therefore applies: continuous cog centers cannot enter either strict support exclusion rectangle. Insetting its integer endpoints by2units means a floor-rounded cog center inside that closed integer rectangle would have its true center strictly inside the forbidden continuous rectangle. Requiring an outside direction for both rectangles is consequently necessary for every original free cog angle. All cog pairs also require the separately certified254297 rounded separation; the verified32-gon is strictly inside that forbidden disk, so an outward facet is necessary. These are permissive necessities only, with clearance deliberately omitted; a positive needs original source shapes, native guards and every H5 gate.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'allowed_profiles_verified':profiles_checked,'original_grid_components_across_profiles':components,'all_fractional_anchor_corners_verified':corners,'exact_interval_edge_tests':edges,'maximum_ideal_actual_coordinate_error_upper_mm':ratio(max_error),'minimum_strict_component_cross_lower_mm2':ratio(minimum_cross),'fixed_source_components_verified':28,'mandatory_moving_components':20,'integer_cog_pair_facets_verified':32,'all27_movers_required':True,'all66_originals_accounted_once':True,'necessary_geometry_only':True,'solver_calls':0,'H5_complete':False});print({k:v for k,v in load(OUT/'checks.json').items() if not k.endswith('_mm') and not k.endswith('_mm2')})
