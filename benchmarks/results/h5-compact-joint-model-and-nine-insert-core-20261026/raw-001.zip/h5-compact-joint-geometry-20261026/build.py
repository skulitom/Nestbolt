"""Exact quarter-turn source components for a necessary continuous joint model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,math,shutil,time
from h5_rational_geometry_helpers import contains
ROOT=Path(__file__).resolve().parents[1];JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SRC=ROOT/'output/h5-source-orientation-construction-20261025';INV=ROOT/'output/h5-fixed24-joint-neighborhood-20261026';SUP=ROOT/'output/h5-fixed24-joint-support-domains-20261026';DOM=ROOT/'output/h5-fixed24-joint-combined-domains-repaired-20261026';FACETS=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026';OUT=ROOT/'output/h5-compact-joint-geometry-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[JOB,SRC/'geometry.json',INV/'next-neighborhood.json',INV/'checks.json',SUP/'fixed-source-rectangles.json',SUP/'audit/checks.json',SUP/'audit/necessity-proof.json',DOM/'audit/checks.json',DOM/'audit/necessity-proof.json',FACETS/'vertices.json',FACETS/'facets.json',ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json',ROOT/'output/h5_rational_geometry_helpers.py']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'coordinate_units_per_mm':1000,'moving_component_inset_units':4,'stock_outward_relaxation_units':20,'rounded_cog_support_box_inset_units':2,'method':'Retain all24 fixed first originals,15 fixed short originals and27 mandatory movers. Decompose each moving non-cog source filled outer at all source vertex coordinates, keeping exact interior grid cells. Enumerate every original allowed quarter turn and mirror. Ideal integer quarter-turn component boxes are expressed relative to the ideal outer minimum. For any continuous original translation, floor that ideal lower-left anchor to1micrometre; inset each model component by4micrometres. Independent exact trig intervals must prove these entire model boxes inside their true original components for every fractional anchor in[0,1)micrometre. The20micrometre stock relaxation must cover the ideal/actual angle difference and flooring. Pairwise inner-box nonoverlap and all-angle cog support exclusions will therefore be necessary, not source-feasible substitutes. No solver is opened.'})
parts={p['id']:p for p in load(JOB)['parts']};profiles={};source_rects={}
for family in ['bracket','insert']:
    p=parts[family];vs=[tuple(map(F,v)) for v in p['geometry'][0]['outer']];assert all(v.denominator==1 for pt in vs for v in pt);xs=sorted({x for x,y in vs});ys=sorted({y for x,y in vs});rects=[]
    for a,b in zip(xs,xs[1:]):
        for c,d in zip(ys,ys[1:]):
            if contains(vs,((a+b)/2,(c+d)/2)):rects.append(list(map(int,[a,c,b,d])))
    source_rects[family]=rects;rows=[]
    for mirrored,degree in product([False,True] if p['allow_mirror'] else [False],p['rotations']['degrees']):
        quarter=int(degree//90);assert degree==90*quarter and 0<=quarter<4;co,si=[(1,0),(0,1),(-1,0),(0,-1)][quarter];mi=-1 if mirrored else 1
        def rotate(x,y):return mi*co*x-si*y,mi*si*x+co*y
        points=[rotate(int(x),int(y)) for x,y in vs];mn=[min(x for x,y in points),min(y for x,y in points)];mx=[max(x for x,y in points),max(y for x,y in points)];boxes=[]
        for a,b,c,d in rects:
            q=[rotate(x,y) for x,y in [(a,b),(c,b),(c,d),(a,d)]];boxes.append([1000*(min(x for x,y in q)-mn[0]),1000*(min(y for x,y in q)-mn[1]),1000*(max(x for x,y in q)-mn[0]),1000*(max(y for x,y in q)-mn[1])])
        rows.append({'mode':len(rows),'degrees':degree,'rotation_radians':math.radians(degree),'mirrored':mirrored,'ideal_outer_min_mm':mn,'outer_size_units1000':[1000*(mx[i]-mn[i]) for i in range(2)],'components_units1000':boxes})
    profiles[family]=rows
stocks=load(SRC/'geometry.json')['stock_bounds_rational'][0];stock=[int(F(*v)*1000) for v in stocks];fixed=load(SUP/'fixed-source-rectangles.json');assert len(fixed)==28
write(OUT/'profiles.json',profiles);write(OUT/'source-grid-components.json',source_rects);write(OUT/'fixed-components.json',[{'index':r['index'],'original':r['item'],'bounds_units1000':r['world_inner_rectangle_units1000']} for r in fixed]);write(OUT/'constants.json',{'units_per_mm':1000,'moving_inset':4,'fractional_anchor_upper_exclusive':1,'source_angle_coordinate_error_bound_mm':[1,1000000],'stock_bounds_units1000':stock,'relaxed_stock_bounds_units1000':[stock[0]-20,stock[1]-20,stock[2]+20,stock[3]+20],'cog_original_inner_radius':109115,'cog_original_outer_radius':140001,'cog_original_support':139270,'cog_support_transverse':15000,'rounded_cog_box_inset':2,'rounded_cog_pair_distance':254297,'source_cog_pair_distance':254300})
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'bracket_profiles':len(profiles['bracket']),'insert_profiles':len(profiles['insert']),'bracket_components':len(source_rects['bracket']),'insert_components':len(source_rects['insert']),'fixed_components':28,'mandatory_moving_components':4*len(source_rects['bracket'])+8*len(source_rects['insert']),'independent_necessity_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
