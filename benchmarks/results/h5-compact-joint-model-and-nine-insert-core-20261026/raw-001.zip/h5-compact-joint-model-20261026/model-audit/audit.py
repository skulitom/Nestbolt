"""Independently reconstruct every compact-model variable role and protobuf constraint."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2 as pb
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-compact-joint-model-20261026';GEO=ROOT/'output/h5-compact-joint-geometry-20261026';INV=ROOT/'output/h5-fixed24-joint-neighborhood-20261026';DOM=ROOT/'output/h5-fixed24-joint-combined-domains-repaired-20261026';FACETS=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026';ITEMS=ROOT/'output/h5-source-orientation-construction-20261025/items.json';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def read_model(p):
    m=pb.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Reconstruct all variable roles by independently required names and domains, every mode table, stock row, component coordinate/size equality, fixed and moving interval, global2Dnonoverlap, symmetry row, complete cog-domain occupancy, every cog-pair facet and every cog/component outside-box disjunction. Rebuild mapping and all constraints from independent geometry certificates rather than trusting saved mapping. Check integer arithmetic bounds and actual solver import/export. A negative is useful only because every original continuous source layout maps into this necessary model.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEO/'audit/checks.json')['passed'] and load(DOM/'audit/checks.json')['passed'];spec=load(INV/'next-neighborhood.json');assert sorted(spec['fixed_first_originals']+spec['fixed_short_originals']+spec['mandatory_moving_first_originals'])==list(range(66));assert len(spec['mandatory_moving_first_noncogs'])==12 and len(spec['mandatory_moving_first_cogs'])==15
items=load(ITEMS);profiles=load(GEO/'profiles.json');const=load(GEO/'constants.json');stock=const['relaxed_stock_bounds_units1000'];inset=const['moving_inset'];m=read_model(BASE/'models/000.pb');assert not m.HasField('objective') and not m.HasField('solution_hint');names={v.name:i for i,v in enumerate(m.variables)};assert len(names)==len(m.variables);seen=set();rows=[];mapping={'noncogs':[],'cogs':[],'boxes':[],'occupancies':[],'cog_pairs':[],'support_pairs':[]};I64=2**63-1
def variable(name,lo,hi):
    assert name in names and name not in seen;seen.add(name);index=names[name];assert m.variables[index]==pb.IntegerVariableProto(name=name,domain=[lo,hi]);return index
def equation(terms,limits,flags=()):
    c=pb.ConstraintProto();c.enforcement_literal.extend(flags)
    for v,k in sorted(terms.items()):
        if k:c.linear.vars.append(v);c.linear.coeffs.append(k)
    c.linear.domain.extend(limits);rows.append(c)
def expression(v=None,n=0):
    e=pb.LinearExpressionProto();e.offset=n
    if v is not None:e.vars.append(v);e.coeffs.append(1)
    return e
def moving_interval(name,left,right,size):
    i=len(rows);c=pb.ConstraintProto(name=name);c.interval.start.CopyFrom(expression(left));c.interval.end.CopyFrom(expression(right));c.interval.size.CopyFrom(expression(size));rows.append(c);return i
for original in spec['mandatory_moving_first_noncogs']:
    family=items[original]['family'];allowed=profiles[family];table=[]
    for profile in allowed:
        record=[profile['mode'],*profile['outer_size_units1000']]
        for rectangle in profile['components_units1000']:record.extend(rectangle)
        table.append(record)
    p={'original':original,'family':family,'x':variable(f'n{original}-x',stock[0],stock[2]),'y':variable(f'n{original}-y',stock[1],stock[3]),'profile_vars':[],'components':[]}
    for k,column in enumerate(zip(*table)):p['profile_vars'].append(variable(f'n{original}-profile{k}',min(column),max(column)))
    c=pb.ConstraintProto()
    for v in p['profile_vars']:c.table.exprs.add().CopyFrom(expression(v))
    for record in table:c.table.values.extend(record)
    rows.append(c);equation({p['x']:1,p['profile_vars'][1]:1},[-I64,stock[2]]);equation({p['y']:1,p['profile_vars'][2]:1},[-I64,stock[3]])
    for j in range(len(allowed[0]['components_units1000'])):
        local=p['profile_vars'][3+4*j:7+4*j];sizes=[(profile['components_units1000'][j][2]-profile['components_units1000'][j][0]-8,profile['components_units1000'][j][3]-profile['components_units1000'][j][1]-8) for profile in allowed];box={'original':original,'component':j}
        for label,axis in [('left',0),('bottom',1),('right',0),('top',1)]:box[label]=variable(f'n{original}-c{j}-{label}',stock[axis],stock[axis+2])
        for label,axis in [('width',0),('height',1)]:box[label]=variable(f'n{original}-c{j}-{label}',min(s[axis] for s in sizes),max(s[axis] for s in sizes))
        for role,anchor,offset,margin in [('left',p['x'],local[0],inset),('bottom',p['y'],local[1],inset),('right',p['x'],local[2],-inset),('top',p['y'],local[3],-inset)]:equation({box[role]:1,anchor:-1,offset:-1},[margin,margin])
        equation({box['width']:1,box['right']:-1,box['left']:1},[0,0]);equation({box['height']:1,box['top']:-1,box['bottom']:1},[0,0]);box['x_interval']=moving_interval(f'n{original}-c{j}-x',box['left'],box['right'],box['width']);box['y_interval']=moving_interval(f'n{original}-c{j}-y',box['bottom'],box['top'],box['height']);p['components'].append(box);mapping['boxes'].append({'kind':'moving',**box})
    mapping['noncogs'].append(p)
for fixed in load(GEO/'fixed-components.json'):
    a,b,c,d=fixed['bounds_units1000'];intervals=[]
    for axis,lo,hi in [('x',a,c),('y',b,d)]:
        intervals.append(len(rows));row=pb.ConstraintProto(name=f"fixed{fixed['index']}-{axis}");row.interval.start.CopyFrom(expression(n=lo));row.interval.end.CopyFrom(expression(n=hi));row.interval.size.CopyFrom(expression(n=hi-lo));rows.append(row)
    mapping['boxes'].append({'kind':'fixed','fixed_component':fixed['index'],'original':fixed['original'],'bounds_units1000':fixed['bounds_units1000'],'x_interval':intervals[0],'y_interval':intervals[1]})
c=pb.ConstraintProto();c.no_overlap_2d.x_intervals.extend(b['x_interval'] for b in mapping['boxes']);c.no_overlap_2d.y_intervals.extend(b['y_interval'] for b in mapping['boxes']);rows.append(c)
for family in ['bracket','insert']:
    subset=[p for p in mapping['noncogs'] if p['family']==family]
    for p,q in zip(subset,subset[1:]):equation({q['x']:1,p['x']:-1},[0,I64])
domains=load(DOM/'merged-domain-rectangles.json');caps=load(DOM/'audit/cell-capacities.json');conflicts=load(DOM/'audit/incompatible-cell-pairs.json');bounds=[[min(d['bounds_units1000'][k] for d in domains),max(d['bounds_units1000'][k+2] for d in domains)] for k in range(2)]
for original in spec['mandatory_moving_first_cogs']:mapping['cogs'].append({'original':original,'x':variable(f'c{original}-x',*bounds[0]),'y':variable(f'c{original}-y',*bounds[1]),'domains':[]})
for p in mapping['cogs']:
    for d in domains:
        flag=variable(f"c{p['original']}-domain{d['index']}",0,1);p['domains'].append(flag);bb=d['bounds_units1000'];equation({p['x']:1},[bb[0],bb[2]],[flag]);equation({p['y']:1},[bb[1],bb[3]],[flag])
    equation(dict.fromkeys(p['domains'],1),[1,1])
for j,cap in enumerate(caps):
    assert cap['domain']==j;v=variable(f'domain{j}-occupancy',0,cap['capacity']);mapping['occupancies'].append(v);terms=dict.fromkeys([p['domains'][j] for p in mapping['cogs']],1);terms[v]=-1;equation(terms,[0,0])
for a,b in conflicts:assert caps[a]['capacity']==caps[b]['capacity']==1;equation({mapping['occupancies'][a]:1,mapping['occupancies'][b]:1},[0,1])
for p,q in zip(mapping['cogs'],mapping['cogs'][1:]):equation({q['x']:1,p['x']:-1},[0,I64])
facets=load(FACETS/'facets.json')
for p,q in combinations(mapping['cogs'],2):
    flags=[]
    for k,facet in enumerate(facets):
        nx,ny=facet['normal'];v=variable(f"cog-pair{p['original']}-{q['original']}-f{k}",0,1);flags.append(v);equation({q['x']:nx,p['x']:-nx,q['y']:ny,p['y']:-ny},[facet['rhs'],I64],[v])
    equation(dict.fromkeys(flags,1),[1,1]);mapping['cog_pairs'].append({'originals':[p['original'],q['original']],'flags':flags})
# Derive each outside direction from the closed, rounded forbidden-box bounds.
for cog in mapping['cogs']:
    for box in [r for r in mapping['boxes'] if r['kind']=='moving']:
        for axis in ['horizontal','vertical']:
            offsets=[15002,-139268,-15002,139268] if axis=='horizontal' else [-139268,15002,139268,-15002]
            flags=[];coordinates=[(cog['x'],box['left'],[-I64,offsets[0]-1]),(cog['x'],box['right'],[offsets[2]+1,I64]),(cog['y'],box['bottom'],[-I64,offsets[1]-1]),(cog['y'],box['top'],[offsets[3]+1,I64])]
            for j,(point,edge,limits) in enumerate(coordinates):
                v=variable(f"support-c{cog['original']}-n{box['original']}-b{box['component']}-{axis}-{j}",0,1);flags.append(v);equation({point:1,edge:-1},limits,[v])
            equation(dict.fromkeys(flags,1),[1,1]);mapping['support_pairs'].append({'cog':cog['original'],'noncog':box['original'],'component':box['component'],'axis':axis,'flags':flags})
assert seen==set(names) and len(seen)==6658 and rows==list(m.constraints) and len(rows)==8244 and mapping==load(BASE/'mapping.json')
largest=0
for c in rows:
    if c.WhichOneof('constraint')=='linear':
        bound=sum(abs(k)*max(abs(v) for v in m.variables[i].domain) for i,k in zip(c.linear.vars,c.linear.coeffs));assert bound<2**62;largest=max(largest,bound)
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert read_model(OUT/'roundtrip.pb')==m
write(OUT/'necessity-proof.json',{'all27_originals_required':True,'all66_identities_accounted_once':True,'statement':'Every valid original layout of this fixed24/short15 neighborhood gives one allowed non-cog mode and the floor of each continuous ideal anchor. The geometry certificate places all20 model component boxes inside those true originals and the28 fixed boxes inside their originals. Original nonoverlap therefore implies the global2Dnonoverlap row. Stock relaxation and positive dimensions hold. Identical remaining originals within each family can be relabelled by X; the fixed originals retain their transforms. Every true cog center floors into at least one of38 complete domains. Choosing any one containing domain gives valid occupancy/capacity/conflict counts. All105 cog pairs obey254297 rounded separation and therefore lie outside the certified inner32-gon. Each cog/component source pair avoids both strict support exclusion rectangles. The2-unit integer inset ensures that a floor center inside a model forbidden rectangle would put its true center strictly inside a forbidden continuous rectangle; hence one outside direction can always be selected for each of600 disjunctions. These assignments satisfy every independently reconstructed row. Thus an actual INFEASIBLE response would exclude this neighborhood at all original allowed non-cog modes, free cog angles and continuous translations. Any positive is only necessary and requires actual source realization, original guards, native/material validation and the fullH5 requirements.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':len(seen),'constraints_verified':len(rows),'mandatory_noncogs':12,'mandatory_cogs':15,'profile_tables_verified':12,'moving_components_verified':20,'fixed_components_verified':28,'global_nonoverlap_boxes':48,'cog_domain_flags_verified':570,'cog_pairs_verified':105,'cog_component_support_boxes_verified':600,'largest_linear_absolute_activity_bound':largest,'all_mapping_fields_reconstructed':True,'all66_identities_accounted_once':True,'no_objective_or_hints':True,'actual_import_export_verified':True,'necessary_geometry_only':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
