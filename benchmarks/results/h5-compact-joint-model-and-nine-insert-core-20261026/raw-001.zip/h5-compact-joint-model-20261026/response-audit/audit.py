"""Audit a closed compact joint response, evaluating every positive geometric constraint."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,math,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-compact-joint-model-20261026';GEO=ROOT/'output/h5-compact-joint-geometry-20261026';RUN=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def model(p):
    m=pb.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify the sole declared closed60solver/90shared call, exact model and parameter bytes, internal logged timer, returned call time and full shared process. Independently evaluate every positive variable, linear row, profile table, interval equality and all48 global nonoverlap boxes. Decode only a necessary-coordinate witness, retaining all27 movers and unassigned source cog angles. Check actual rounded cog distances separately because the inner-polygon facet condition is a relaxation. Negative scope is the fixed24/short15 neighborhood only; UNKNOWN is never an exclusion.'})
for p in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];proc=load(RUN/'process.json');budget=load(RUN/'budget.json');census=load(RUN/'census.json');assert proc['exit_code']==0 and not proc['timeout'] and proc['seconds']<=90 and budget['shared_seconds']==90 and budget['deadline_perf_counter']==budget['start_perf_counter']+90 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==60
folder=RUN/'000';r=load(folder/'result.json');opened=load(folder/'opened.json');assert census['solver_calls']==len(census['results'])==len(list(RUN.rglob('opened.json')))==1 and not census['pending_pairs'] and r==census['results'][0] and opened['maximum_calls']==r['solver_calls']==1 and r['parts']==load(BASE/'inventory.json')[0]['parts'] and len(r['parts'])==27
m=model(folder/'model.pb');assert m==model(BASE/'models/000.pb') and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=60,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'] and opened['seconds_limit']==60
response=pb.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert pb.CpSolverStatus.Name(response.status)==r['status'] and 0<response.wall_time<=r['seconds']<=r['stage_seconds']<=proc['seconds'] and r['solver_soft_overshoot_seconds']==max(0,r['seconds']-60);log=(folder/'solver.log').read_text();assert abs(float(re.findall(r'^walltime: ([0-9.]+)$',log,re.M)[-1])-response.wall_time)<.0005
sol=list(response.solution);positive=r['status'] in ['FEASIBLE','OPTIMAL'];active=intervals=boxpairs=tables=0;violations=[]
if positive:
    assert len(sol)==len(m.variables) and sol[:54]==r['original_coordinates_units1000']
    for v,n in zip(m.variables,sol):assert any(a<=n<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    def truth(i):return bool(sol[i]) if i>=0 else not bool(sol[-i-1])
    def value(e):return e.offset+sum(sol[i]*a for i,a in zip(e.vars,e.coeffs))
    for c in m.constraints:
        if not all(truth(i) for i in c.enforcement_literal):continue
        kind=c.WhichOneof('constraint')
        if kind=='linear':
            n=sum(sol[i]*a for i,a in zip(c.linear.vars,c.linear.coeffs));assert any(a<=n<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        elif kind=='table':
            assert not c.table.negated and not c.table.vars;v=tuple(value(e) for e in c.table.exprs);width=len(v);assert v in {tuple(c.table.values[i:i+width]) for i in range(0,len(c.table.values),width)};tables+=1
        elif kind=='interval':assert value(c.interval.start)+value(c.interval.size)==value(c.interval.end) and value(c.interval.size)>0;intervals+=1
        else:
            assert kind=='no_overlap_2d';boxes=[]
            for x,y in zip(c.no_overlap_2d.x_intervals,c.no_overlap_2d.y_intervals):
                a,b=m.constraints[x].interval,m.constraints[y].interval;boxes.append([value(a.start),value(b.start),value(a.end),value(b.end)])
            assert len(boxes)==48
            for a,b in combinations(boxes,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];boxpairs+=1
        active+=1
    mapping=load(BASE/'mapping.json');profiles=load(GEO/'profiles.json');noncogs=[];cogs=[]
    for p in mapping['noncogs']:
        mode=sol[p['profile_vars'][0]];profile=profiles[p['family']][mode];noncogs.append({'original':p['original'],'family':p['family'],'mode':mode,'degrees':profile['degrees'],'mirrored':profile['mirrored'],'ideal_anchor_floor_units1000':[sol[p['x']],sol[p['y']]],'ideal_outer_min_mm':profile['ideal_outer_min_mm'],'source_translation_and_native_clearance_not_validated':True})
    for p in mapping['cogs']:cogs.append({'original':p['original'],'center_floor_units1000':[sol[p['x']],sol[p['y']]],'source_angle_unassigned':True})
    for a,b in combinations(cogs,2):
        square=sum((x-y)**2 for x,y in zip(a['center_floor_units1000'],b['center_floor_units1000']))
        if square<254297**2:violations.append({'originals':[a['original'],b['original']],'squared_distance_units':square,'required_squared_distance_units':254297**2})
    assert len(noncogs)==12 and len(cogs)==15 and sorted(p['original'] for p in noncogs+cogs)==sorted(r['parts']);write(OUT/'necessary-coordinate-witness.json',{'noncogs':noncogs,'cogs':cogs,'rounded_cog_distance_violations':violations,'all27_originals_present':True,'source_geometry_witness':False,'native_material_validation_performed':False,'H5_complete':False})
else:assert r['status'] in ['INFEASIBLE','UNKNOWN'] and not sol
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':1,'status':r['status'],'solver_reported_wall_seconds':response.wall_time,'returned_solve_call_seconds':r['seconds'],'shared_process_seconds':proc['seconds'],'shared_budget_honored':True,'reported_soft_overrun_seconds':max(0,response.wall_time-60),'returned_call_soft_overrun_seconds':r['solver_soft_overshoot_seconds'],'solver_branches':response.num_branches,'solver_conflicts':response.num_conflicts,'stopped_after_presolve':'Stopped after presolve.' in log,'positive_variables_verified':len(sol),'positive_active_constraints_verified':active,'positive_profile_tables_verified':tables,'positive_intervals_verified':intervals,'positive_nonoverlap_box_pairs_verified':boxpairs,'necessary_coordinate_witness':positive,'rounded_cog_distance_violations':len(violations),'all27_movers_mandatory':True,'fixed24_short15_neighborhood_excluded':r['status']=='INFEASIBLE','global_target_exclusion_claimed':False,'source66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
