"""Complete necessary joint model:12 quarter-turn non-cogs and15 free-angle cogs."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-compact-joint-geometry-20261026';INV=ROOT/'output/h5-fixed24-joint-neighborhood-20261026';DOM=ROOT/'output/h5-fixed24-joint-combined-domains-repaired-20261026';FACETS=ROOT/'output/h5-fixed40-linear-distance-geometry-20261026';ITEMS=ROOT/'output/h5-source-orientation-construction-20261025/items.json';OUT=ROOT/'output/h5-compact-joint-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(GEO/'audit/checks.json')['passed'] and load(DOM/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();spec=load(INV/'next-neighborhood.json');items=load(ITEMS);profiles=load(GEO/'profiles.json');const=load(GEO/'constants.json');domains=load(DOM/'merged-domain-rectangles.json');caps=load(DOM/'audit/cell-capacities.json');conflicts=load(DOM/'audit/incompatible-cell-pairs.json');facets=load(FACETS/'facets.json');stock=const['relaxed_stock_bounds_units1000'];inset=const['moving_inset']
inputs=[GEO/n for n in ['plan.json','profiles.json','source-grid-components.json','fixed-components.json','constants.json','audit/checks.json','audit/necessity-proof.json','audit/component-certificates.json']]+[INV/'next-neighborhood.json',INV/'checks.json',ITEMS,DOM/'merged-domain-rectangles.json',DOM/'audit/checks.json',DOM/'audit/necessity-proof.json',DOM/'audit/cell-capacities.json',DOM/'audit/incompatible-cell-pairs.json',FACETS/'vertices.json',FACETS/'facets.json',ROOT/'output/h5-central-notch-joint-selection-20261026/response-audit-timing-repaired/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_calls':1,'solver_seconds':60,'shared_seconds':90,'workers':4,'seed':0,'mandatory_moving_originals':spec['mandatory_moving_first_originals'],'fixed_first_originals':spec['fixed_first_originals'],'fixed_short_originals':spec['fixed_short_originals'],'method':'All12 moving non-cogs and15 moving cogs are mandatory. Mode tables cover every original quarter-turn/mirror profile. Integer lower-left anchors represent flooring of continuous ideal outer minima; all20 moving inner component rectangles are independently certified for every fractional anchor. NoOverlap2D includes those20 boxes and28 fixed source-contained boxes. Exact relaxed stock limits and same-family X ordering preserve all valid source placements. Each cog chooses one of38 complete domains; exact occupancy counts obey certified capacities and conflicts. Every105 cog pair chooses one of32 outward facets of a polygon strictly inside the forbidden254297 separation disk. Every300 cog/moving-component pair must avoid both rounded support-exclusion boxes, using exactly one outside direction per box. No cog angle, non-cog translation or old finite source pose is fixed. No hints/objective. This is a necessary relaxation, so any positive still needs original source angles/geometry and full66 native/material checks. The previous finite joint call remains closed. Full reconstruction/import audit must precede this sole60solver/90shared call; no repeat, reseed or extension.'})
m=pb.CpModelProto();mapping={'noncogs':[],'cogs':[],'boxes':[],'occupancies':[],'cog_pairs':[],'support_pairs':[]}
def var(name,lo,hi):
    i=len(m.variables);m.variables.add(name=name,domain=[lo,hi]);return i
def linear(terms,lo,hi,en=()):
    terms={k:v for k,v in terms.items() if v};ids=sorted(terms);m.constraints.add(enforcement_literal=en,linear=pb.LinearConstraintProto(vars=ids,coeffs=[terms[i] for i in ids],domain=[lo,hi]))
def expr(v=None,offset=0):return pb.LinearExpressionProto(vars=[] if v is None else [v],coeffs=[] if v is None else [1],offset=offset)
def interval(name,left,right,size):
    index=len(m.constraints);m.constraints.add(name=name,interval=pb.IntervalConstraintProto(start=expr(left),end=expr(right),size=expr(size)));return index
I64=2**63-1
for original in spec['mandatory_moving_first_noncogs']:
    family=items[original]['family'];ps=profiles[family];rows=[[p['mode'],*p['outer_size_units1000'],*(v for r in p['components_units1000'] for v in r)] for p in ps];count=len(ps[0]['components_units1000']);p={'original':original,'family':family,'x':var(f'n{original}-x',stock[0],stock[2]),'y':var(f'n{original}-y',stock[1],stock[3]),'profile_vars':[],'components':[]}
    for col in range(len(rows[0])):p['profile_vars'].append(var(f'n{original}-profile{col}',min(r[col] for r in rows),max(r[col] for r in rows)))
    m.constraints.add(table=pb.TableConstraintProto(exprs=[expr(v) for v in p['profile_vars']],values=[v for row in rows for v in row]));linear({p['x']:1,p['profile_vars'][1]:1},-I64,stock[2]);linear({p['y']:1,p['profile_vars'][2]:1},-I64,stock[3])
    for j in range(count):
        a,b,c,d=p['profile_vars'][3+4*j:7+4*j];sizes=[(r[5+4*j]-r[3+4*j]-2*inset,r[6+4*j]-r[4+4*j]-2*inset) for r in rows]
        component={'original':original,'component':j,'left':var(f'n{original}-c{j}-left',stock[0],stock[2]),'bottom':var(f'n{original}-c{j}-bottom',stock[1],stock[3]),'right':var(f'n{original}-c{j}-right',stock[0],stock[2]),'top':var(f'n{original}-c{j}-top',stock[1],stock[3]),'width':var(f'n{original}-c{j}-width',min(x for x,y in sizes),max(x for x,y in sizes)),'height':var(f'n{original}-c{j}-height',min(y for x,y in sizes),max(y for x,y in sizes))}
        linear({component['left']:1,p['x']:-1,a:-1},inset,inset);linear({component['bottom']:1,p['y']:-1,b:-1},inset,inset);linear({component['right']:1,p['x']:-1,c:-1},-inset,-inset);linear({component['top']:1,p['y']:-1,d:-1},-inset,-inset);linear({component['width']:1,component['right']:-1,component['left']:1},0,0);linear({component['height']:1,component['top']:-1,component['bottom']:1},0,0)
        component['x_interval']=interval(f'n{original}-c{j}-x',component['left'],component['right'],component['width']);component['y_interval']=interval(f'n{original}-c{j}-y',component['bottom'],component['top'],component['height']);p['components'].append(component);mapping['boxes'].append({'kind':'moving',**component})
    mapping['noncogs'].append(p)
for r in load(GEO/'fixed-components.json'):
    a,b,c,d=r['bounds_units1000'];xi=len(m.constraints);m.constraints.add(name=f"fixed{r['index']}-x",interval=pb.IntervalConstraintProto(start=expr(offset=a),end=expr(offset=c),size=expr(offset=c-a)));yi=len(m.constraints);m.constraints.add(name=f"fixed{r['index']}-y",interval=pb.IntervalConstraintProto(start=expr(offset=b),end=expr(offset=d),size=expr(offset=d-b)));mapping['boxes'].append({'kind':'fixed','fixed_component':r['index'],'original':r['original'],'bounds_units1000':r['bounds_units1000'],'x_interval':xi,'y_interval':yi})
m.constraints.add(no_overlap_2d=pb.NoOverlap2DConstraintProto(x_intervals=[r['x_interval'] for r in mapping['boxes']],y_intervals=[r['y_interval'] for r in mapping['boxes']]))
for family in ['bracket','insert']:
    ps=[p for p in mapping['noncogs'] if p['family']==family]
    for a,b in zip(ps,ps[1:]):linear({b['x']:1,a['x']:-1},0,I64)
xb=[min(d['bounds_units1000'][0] for d in domains),max(d['bounds_units1000'][2] for d in domains)];yb=[min(d['bounds_units1000'][1] for d in domains),max(d['bounds_units1000'][3] for d in domains)]
for original in spec['mandatory_moving_first_cogs']:mapping['cogs'].append({'original':original,'x':var(f'c{original}-x',*xb),'y':var(f'c{original}-y',*yb),'domains':[]})
for p in mapping['cogs']:
    for d in domains:
        f=var(f"c{p['original']}-domain{d['index']}",0,1);p['domains'].append(f);a,b,c,e=d['bounds_units1000'];linear({p['x']:1},a,c,[f]);linear({p['y']:1},b,e,[f])
    linear(dict.fromkeys(p['domains'],1),1,1)
for j,cap in enumerate(caps):
    assert cap['domain']==j;v=var(f'domain{j}-occupancy',0,cap['capacity']);mapping['occupancies'].append(v);linear({**{p['domains'][j]:1 for p in mapping['cogs']},v:-1},0,0)
for a,b in conflicts:assert caps[a]['capacity']==caps[b]['capacity']==1;linear({mapping['occupancies'][a]:1,mapping['occupancies'][b]:1},0,1)
for a,b in zip(mapping['cogs'],mapping['cogs'][1:]):linear({b['x']:1,a['x']:-1},0,I64)
for a,b in combinations(mapping['cogs'],2):
    flags=[]
    for j,f in enumerate(facets):
        nx,ny=f['normal'];flag=var(f"cog-pair{a['original']}-{b['original']}-f{j}",0,1);flags.append(flag);linear({b['x']:nx,a['x']:-nx,b['y']:ny,a['y']:-ny},f['rhs'],I64,[flag])
    linear(dict.fromkeys(flags,1),1,1);mapping['cog_pairs'].append({'originals':[a['original'],b['original']],'flags':flags})
beta=const['cog_support_transverse'];h=const['cog_original_support'];margin=const['rounded_cog_box_inset']
for cog in mapping['cogs']:
    for box in [r for r in mapping['boxes'] if r['kind']=='moving']:
        for axis in ['horizontal','vertical']:
            lx,rx,ly,ry=(beta+margin-1,-beta-margin+1,-h+margin-1,h-margin+1) if axis=='horizontal' else (-h+margin-1,h-margin+1,beta+margin-1,-beta-margin+1);flags=[]
            directions=[({cog['x']:1,box['left']:-1},-I64,lx),({cog['x']:1,box['right']:-1},rx,I64),({cog['y']:1,box['bottom']:-1},-I64,ly),({cog['y']:1,box['top']:-1},ry,I64)]
            for j,(terms,lo,hi) in enumerate(directions):flag=var(f"support-c{cog['original']}-n{box['original']}-b{box['component']}-{axis}-{j}",0,1);flags.append(flag);linear(terms,lo,hi,[flag])
            linear(dict.fromkeys(flags,1),1,1);mapping['support_pairs'].append({'cog':cog['original'],'noncog':box['original'],'component':box['component'],'axis':axis,'flags':flags})
assert len(mapping['noncogs'])==12 and len(mapping['cogs'])==15 and len(mapping['boxes'])==48 and len(mapping['support_pairs'])==600 and len(m.variables)==6658 and len(m.constraints)==8244
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');write(OUT/'mapping.json',mapping);write(OUT/'inventory.json',[{'index':0,'parts':spec['mandatory_moving_first_originals'],'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(p),'solver_seconds':60,'necessary_geometry_only':True}]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'variables':len(m.variables),'constraints':len(m.constraints),'mandatory_originals':27,'moving_components':20,'fixed_components':28,'cog_domain_choices':570,'cog_pairs':105,'cog_component_support_boxes':600,'solver_calls':0});print(load(OUT/'prepared.json'))
