"""Exact lower bounds on horizontal occupied length under all allowed Y translations."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
import json, shutil, time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'output/h5-short11-all-pair-separators-20261029'
BASE = ROOT / 'output/h5-short11-relative-region-model-20261029'
OUT = BASE / 'slice-capacity-diagnostic'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def minimum_slice_width(vertices, lo, hi):
    breaks = sorted({lo, hi} | {y for x, y in vertices if lo < y < hi})
    records = []
    best = None
    for a, b in zip(breaks, breaks[1:]):
        middle = (a+b)/2
        edges = [(p, q) for p, q in zip(vertices, vertices[1:]+vertices[:1]) if min(p[1], q[1]) < middle < max(p[1], q[1])]
        values = []
        for y in [a, b]:
            intersections = sorted(p[0]+(y-p[1])*(q[0]-p[0])/(q[1]-p[1]) for p, q in edges)
            assert len(intersections) % 2 == 0
            width = sum((v-u for u, v in zip(intersections[::2], intersections[1::2])), F(0))
            assert width >= 0
            values.append(width)
        value = min(values)
        best = value if best is None else min(best, value)
        records.append({'vertical_interval': [str(a), str(b)], 'edge_count': len(edges), 'endpoint_widths': list(map(str, values))})
    assert best is not None
    return best, records

assert load(BASE / 'response-audit/checks.json')['passed']
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'diagnose.py')
started = time.perf_counter()
world = load(SOURCE / 'world-pieces.json')
bounds = np.load(BASE / 'model.npz')['bounds'][:22]
stock = load(ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json')['source_stock']
available = F(stock[2])-F(stock[0])-2*F('.025')
records = []
for height in [210, 215, 220, 225, 230, 235, 240, 245, 250]:
    total = F(0)
    per_part = []
    for owner, row in enumerate(world):
        vertices = [tuple(map(F, p)) for p in row['outline']]
        low, high = map(F, bounds[2*owner+1])
        # Expand the vertical interval slightly, making the lower bound conservative
        # with respect to the recorded stock/domain floating-point operations.
        lo, hi = F(height)-high-F('1e-9'), F(height)-low+F('1e-9')
        width, pieces = minimum_slice_width(vertices, lo, hi)
        total += width
        per_part.append({'owner': owner, 'identity': row['identity'], 'minimum_width': str(width),
                         'minimum_width_mm': float(width), 'source_y_interval': [str(lo), str(hi)],
                         'linear_intervals': pieces})
    records.append({'height_mm': height, 'minimum_sum_width': str(total), 'minimum_sum_width_mm': float(total),
                    'available_width': str(available), 'excess_width_mm': float(total-available), 'parts': per_part})
write(OUT / 'slice-bounds.json', records)
best = max(records, key=lambda r: F(r['minimum_sum_width']))
inputs = [Path(__file__), SOURCE / 'audit/plan.json', SOURCE / 'audit/checks.json', SOURCE / 'world-pieces.json',
          BASE / 'plan.json', BASE / 'model.npz', BASE / 'response-audit/plan.json', BASE / 'response-audit/checks.json',
          ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
                        'method': 'At each declared horizontal height, derive each original filled outline horizontal-section length as a piecewise-linear function of its vertical translation. The minimum over each full allowed Y domain is attained at an endpoint or one-sided vertex limit. Sum these independent minima. A sum above usable width gives a necessary capacity contradiction for these fixed posed outlines; otherwise the sampled diagnostic is inconclusive. It ignores positive gaps and all coupling between heights and parts, so it is only a relaxation. No solver call or orientation search is opened.'})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'sampled_heights': len(records),
          'originals_at_each_height': 11, 'best_height_mm': best['height_mm'],
          'maximum_necessary_width_mm': best['minimum_sum_width_mm'], 'available_width_mm': float(available),
          'maximum_excess_mm': best['excess_width_mm'], 'fixed_pose_capacity_contradiction_found': best['excess_width_mm'] > 0,
          'independent_certificate_audit_pending_if_positive': best['excess_width_mm'] > 0,
          'allocation_excluded': False, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
print([{'height': r['height_mm'], 'width': r['minimum_sum_width_mm']} for r in records])
