"""Prepare a guarded push of the two verified source-geometry checkpoints."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head.startswith('8c434a2b')
source = (ROOT / 'output/push_h5_short12_checkpoint_20261029.py').read_text(encoding='utf-8')
replacements = [
    ("OUT=ROOT/'output/h5-short12-main-sync-20261029'", "OUT=ROOT/'output/h5-axis-partition-main-sync-20261029'"),
    ("OLD='3e33dedbed809b2fdd3b97a8784b50a25732c3c0';NEW='9dab2f4e5290a72c208d132f6e21ad31340f365c'", "OLD='9dab2f4e5290a72c208d132f6e21ad31340f365c';NEW='" + head + "'"),
    ('40800774981', '40805531238'),
    ('benchmarks/results/h5-short-source-reference-exclusion-20261029', 'benchmarks/results/h5-short11-source-readback-and-translation-cycle-20261029'),
    ('benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029', 'benchmarks/results/h5-axis-choice-rejection-and-exact-source-partition-20261029'),
]
for old, new in replacements:
    assert old in source
    source = source.replace(old, new)
path = ROOT / 'output/push_h5_axis_partition_checkpoint_20261029.py'
compile(source, str(path), 'exec')
with path.open('x', encoding='utf-8', newline='\n') as f:
    f.write(source)
print({'prepared': path.name, 'head': head, 'all6_prior_checks_required': True,
       'unchanged_remote_head_required': True, 'normal_atomic_fast_forward_only': True})
