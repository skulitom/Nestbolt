"""Prepare the one-call convex-hull runner with only the region selectors integral."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'output/run_h5_relative_region_model_20261029.py').read_text(encoding='utf-8')
for old, new in [
    ('h5-short11-relative-region-model-20261029', 'h5-short11-region-convex-hull-model-20261029'),
    ('whole-part relative-region construction', 'convex-combination relative-region construction'),
    ('values[22:]', 'values[22:717]'),
]:
    assert old in source
    source = source.replace(old, new)
path = ROOT / 'output/run_h5_region_hull_model_20261029.py'
compile(source, str(path), 'exec')
with path.open('x', encoding='utf-8', newline='\n') as f:
    f.write(source)
print({'prepared': path.name, 'maximum_calls': 1, 'binary_variables': [22, 717], 'other_weights_continuous': True})
