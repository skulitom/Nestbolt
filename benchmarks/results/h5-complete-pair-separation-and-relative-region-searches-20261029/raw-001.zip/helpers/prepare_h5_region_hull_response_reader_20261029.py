"""Prepare a separate response reader for the closed convex-hull construction."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'output/audit_h5_all_pair_response_20261029.py').read_text(encoding='utf-8')
old = 'h5-short11-all-pair-separators-20261029'
assert source.count(old) == 1
source = source.replace(old, 'h5-short11-region-convex-hull-model-20261029')
path = ROOT / 'output/audit_h5_region_hull_response_20261029.py'
compile(source, str(path), 'exec')
with path.open('x', encoding='utf-8', newline='\n') as f:
    f.write(source)
print({'prepared': path.name})
