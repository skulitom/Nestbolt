"""Derive a separate one-call runner for the independently audited region model."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'output/run_h5_all_pair_separators_20261029.py').read_text(encoding='utf-8')
old_choice = """            if group['guaranteed_axis'] is not None:
                chosen = [group['guaranteed_axis']]
            elif 'one_of_row' in group:
                chosen = [i for i in group['possible_axes'] if values[group['variants'][i]['selector']] > .5]
            else:
                chosen = group['possible_axes']
            choices_pass &= len(chosen) == 1
            selected.append({'owners': group['owners'], 'pieces': group['pieces'], 'axes': chosen})"""
new_choice = """            chosen = [r['region'] for r in group['regions'] if values[r['selector']] > .5]
            choices_pass &= len(chosen) == 1
            selected.append({'owners': group['owners'], 'regions': chosen})"""
replacements = [
    ('all-pair source construction', 'whole-part relative-region construction'),
    ('h5-short11-all-pair-separators-20261029', 'h5-short11-relative-region-model-20261029'),
    ("'groups.json'", "'mapping.json'"),
    (old_choice, new_choice),
    ("'one_axis_per_pair'", "'one_region_per_original_pair'"),
    ("'selected_axes'", "'selected_regions'"),
]
for old, new in replacements:
    assert old in source, old
    source = source.replace(old, new)
path = ROOT / 'output/run_h5_relative_region_model_20261029.py'
compile(source, str(path), 'exec')
with path.open('x', encoding='utf-8', newline='\n') as f:
    f.write(source)
print({'prepared': path.name, 'maximum_calls': 1, 'requires_independent_model_audit': True})
