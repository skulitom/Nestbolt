"""Seal three closed construction calls, exact region proofs and broader mode preparation."""
from pathlib import Path
from datetime import datetime, timezone
import ast, json, shutil, subprocess, sys
from pack_h5_evidence_archive import pack, digest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from h2_import_audit import source_digest

PAIR = ROOT / 'output/h5-short11-all-pair-separators-20261029'
REGION = ROOT / 'output/h5-short11-relative-region-model-20261029'
HULL = ROOT / 'output/h5-short11-region-convex-hull-model-20261029'
MODES = ROOT / 'output/h5-short11-all-modes-preflight-20261029'
SYNC = ROOT / 'output/h5-axis-partition-main-sync-20261029'
PUB = HULL / 'publication'
NAME = 'h5-complete-pair-separation-and-relative-region-searches-20261029'
OUT = ROOT / 'benchmarks/results' / NAME
load = lambda p: json.loads(p.read_bytes())

def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def append(path, value):
    with path.open('a', encoding='utf-8', newline='\n') as f:
        f.write(value)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

head = git('rev-parse', 'HEAD')
assert head == '8c434a2b54e7bd47a8acd341772a4496efbe0e87' and not git('diff', 'HEAD', '--name-only')
responses = []
for base in [PAIR, REGION, HULL]:
    assert load(base / 'audit/checks.json')['passed']
    response = load(base / 'response-audit/checks.json')
    assert response['passed'] and response['closed_solver_calls'] == 1
    assert response['outcome'] == 'NODE_LIMIT_NO_ASSIGNMENT' and response['logged_nodes'] == 128
    assert response['all_overruns_seconds'] == response['assignments'] == response['tiny_coefficients_ignored'] == 0
    assert not response['infeasibility_proven'] and not response['any_allocation_excluded']
    responses.append(response)
assert load(PAIR / 'relative-free-region-preflight/audit/checks.json')['exact_whole_region_source_support_proofs'] == 21960
assert load(HULL / 'audit/checks.json')['exact_rounded_region_support_proofs'] == 21960
assert not load(REGION / 'slice-capacity-diagnostic/checks.json')['fixed_pose_capacity_contradiction_found']
assert load(MODES / 'checks.json')['total_instance_mode_options'] == 58
prior = load(ROOT / 'benchmarks/results/h5-axis-choice-rejection-and-exact-source-partition-20261029/publication-review.json')
production = source_digest()
readmes = {name: digest(ROOT / name) for name in prior['current_readmes']}
assert production == prior['production_digest'] and readmes == prior['current_readmes']
up = {'sparrow_head': load(PUB / 'sparrow-head.json')['sha'], 'studio_head': load(PUB / 'studio-head.json')['sha'],
      'sparrow_release': load(PUB / 'sparrow-release.json')['tag_name'],
      'studio_latest_release': [r['tag_name'] for r in load(PUB / 'studio-releases.json')]}
assert all(up[k] == prior[k] for k in up)
assert [(r['tag_name'], r['prerelease'], r['draft']) for r in load(PUB / 'nestbolt-releases.json')] == [('v0.2.0-alpha.1', True, False), ('v0.1.0', False, False)]
ci, jobs = load(PUB / 'main-ci.json'), load(PUB / 'main-ci-jobs.json')['jobs']
assert load(PUB / 'main.json')['commit']['sha'] == ci['head_sha'] == head
assert ci['id'] == 40811474503 and ci['status'] == 'completed' and ci['conclusion'] == 'success'
assert len(jobs) == 6 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs)
receipt = load(SYNC / 'receipt.json')
assert receipt['new_main'] == head and receipt['normal_atomic_fast_forward'] and receipt['prior_main_all6_pass']
frontier = ROOT / 'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json'
assert sum(r['excluded_by'] is None for r in load(frontier)) == 440
assert digest(ROOT / 'output/h5-oblique64-source-20261028/source64.json') == 'bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
OUT.mkdir()
members, queue, seen, bindings = {}, [], set(), {}

def add(name, path):
    assert path.is_file() and '.claude' not in path.parts
    members[name] = path
    if path.name in ['plan.json', 'opened.json'] or path.suffix == '.py':
        queue.append(path)

for folder in [PAIR, REGION, HULL, MODES, SYNC]:
    for path in folder.rglob('*'):
        if path.is_file():
            add(folder.name + '/' + path.relative_to(folder).as_posix(), path)
helpers = [
    'build_h5_all_pair_separators_20261029.py', 'audit_h5_all_pair_separators_20261029.py',
    'run_h5_all_pair_separators_20261029.py', 'audit_h5_all_pair_response_20261029.py',
    'prepare_h5_relative_free_regions_20261029.py', 'audit_h5_relative_free_regions_20261029.py',
    'build_h5_relative_region_model_20261029.py', 'audit_h5_relative_region_model_20261029.py',
    'prepare_h5_relative_region_runner_20261029.py', 'run_h5_relative_region_model_20261029.py',
    'prepare_h5_relative_region_response_reader_20261029.py', 'audit_h5_relative_region_response_20261029.py',
    'diagnose_h5_fixed_mode_slice_capacity_20261029.py', 'build_h5_region_hull_model_20261029.py',
    'audit_h5_region_hull_model_20261029.py', 'prepare_h5_region_hull_runner_20261029.py',
    'run_h5_region_hull_model_20261029.py', 'prepare_h5_region_hull_response_reader_20261029.py',
    'audit_h5_region_hull_response_20261029.py', 'prepare_h5_short11_all_modes_20261029.py',
    'prepare_h5_axis_partition_main_push_20261029.py', 'push_h5_axis_partition_checkpoint_20261029.py',
    'pack_h5_evidence_archive.py', 'ccd1.py', 'verify_h5_relative_region_archive_20261029.py', Path(__file__).name,
]
for name in helpers:
    add('helpers/' + name, ROOT / 'output' / name)
while queue:
    path = queue.pop()
    if path in seen:
        continue
    seen.add(path)
    if path.name in ['plan.json', 'opened.json']:
        for name, expected in load(path).get('inputs', {}).items():
            source = ROOT / name
            assert source.is_relative_to(ROOT) and not {'.claude', '.cache'} & set(source.parts)
            assert digest(source) == expected, name
            bindings[name] = expected
            add('source-inputs/' + name, source)
    elif path.suffix == '.py':
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            modules = [v.name for v in node.names] if isinstance(node, ast.Import) else [node.module] if isinstance(node, ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:
                    continue
                for folder in ['output', 'scripts']:
                    source = ROOT / folder / (module + '.py')
                    if source.is_file():
                        add('imported-helpers/' + folder + '/' + source.name, source)
archive, _ = pack(ROOT, OUT, NAME, members)
write(OUT / 'source-bindings.json', bindings)
copies = [
    (PAIR / 'audit/checks.json', 'all-pair-model-audit.json'),
    (PAIR / 'response-audit/checks.json', 'all-pair-response-audit.json'),
    (PAIR / 'response-audit/status-interpretation.json', 'all-pair-status.json'),
    (PAIR / 'relative-free-region-preflight/checks.json', 'free-region-preflight.json'),
    (PAIR / 'relative-free-region-preflight/audit/checks.json', 'free-region-audit.json'),
    (REGION / 'audit/checks.json', 'region-model-audit.json'),
    (REGION / 'response-audit/checks.json', 'region-response-audit.json'),
    (REGION / 'slice-capacity-diagnostic/checks.json', 'slice-capacity-diagnostic.json'),
    (HULL / 'audit/checks.json', 'convex-hull-model-audit.json'),
    (HULL / 'response-audit/checks.json', 'convex-hull-response-audit.json'),
    (MODES / 'checks.json', 'all-mode-preflight.json'),
    (MODES / 'family-modes.json', 'all-mode-transforms.json'),
    (SYNC / 'receipt.json', 'prior-main-push-receipt.json'),
    (PUB / 'main-ci-jobs.json', 'main-ci-snapshot.json'),
]
for source, name in copies:
    shutil.copyfile(source, OUT / name)
write(OUT / 'publication-review.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'source_head': head, 'remote_main': head,
    'production_digest': production, 'current_readmes': readmes, **up,
    'upstream_heads_and_releases_unchanged': True, 'stable_release': 'v0.1.0', 'preview_release': 'v0.2.0-alpha.1',
    'main_CI': 40811474503, 'main_all6_pass': True, 'normal_push_requires_fresh_head_and_live_run_checks': True,
    'unchanged_frontier_path': frontier.relative_to(ROOT).as_posix(), 'unchanged_frontier_sha256': digest(frontier),
    'reserved_H2_vectors_evaluated': 0, 'completion_percent': 60, 'H2_complete': False, 'H5_complete': False,
    'new_release_qualified': False,
})
write(OUT / 'next-step.json', {
    'action': load(MODES / 'plan.json')['method'], 'instance_mode_options': 58, 'unique_filled_geometries': 11,
    'independent_mode_audit_pending': True, 'short_originals': 11, 'first_originals': 55,
    'cog_phase_fixed_degrees': 7, 'model_created': False, 'search_opened': False,
    'remaining_candidates': 440, 'completion_percent': 60, 'H2_complete': False, 'H5_complete': False,
})
write(OUT / 'checks.json', {
    'passed': True, 'closed_new_solver_calls': 3, 'all_call_outcomes': 'NODE_LIMIT_NO_ASSIGNMENT',
    'logged_nodes_each': 128, 'new_solver_budget_overruns': 0, 'tiny_coefficients_dropped': 0,
    'exact_whole_region_support_proofs': 21960, 'exact_rounded_region_support_proofs': 21960,
    'sampled_slice_capacity_contradiction': False, 'new_allocation_exclusions': 0,
    'remaining_candidates': 440, 'next_mode_options_prepared': 58, 'variable_orientation_model_created': False,
    'valid64_preserved': True, 'source_valid66_created': False, 'native_calls': 0,
    'completion_percent': 60, 'H2_complete': False, 'H5_complete': False, **archive,
})
report = (HULL / 'report-template.md').read_text(encoding='utf-8').format(name=NAME, files=archive['archive_members'], aliases=archive['verified_aliases'], bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x', encoding='utf-8', newline='\n') as f:
    f.write(report)
note = (HULL / 'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md', 'docs/PLAN_V1_1.md', 'docs/V1_1_RESEARCH.md', 'docs/STATUS.md']:
    append(ROOT / name, note.format(link=('' if name == 'BENCHMARKS.md' else '../') + f'benchmarks/results/{NAME}.md'))
status = ROOT / 'docs/STATUS.md'
content = status.read_text(encoding='utf-8')
old = 'Latest H5 evidence: [rejected axis choices and an exact smaller source partition](../benchmarks/results/h5-axis-choice-rejection-and-exact-source-partition-20261029.md).'
new = f'Latest H5 evidence: [complete pair separation and relative-region searches](../benchmarks/results/{NAME}.md).'
assert content.count(old) == 1
with status.open('w', encoding='utf-8', newline='\n') as f:
    f.write(content.replace(old, new, 1))
append(ROOT / '.gitattributes', f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed': NAME, **archive, 'source_bindings': len(bindings), 'remaining_candidates': 440, 'completion_percent': 60})
