from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/plot_h5_dense_insert_gap.py').read_text(encoding='utf-8')
s=s.replace("src=root/'output/h5-dense-insert-gap-20261023'", "src=root/'output/h5-complete-cog-group-choice-20261023'")
s=s.replace("src/'layout.json'", "src/'layout-audit/layout-final.json'")
s=s.replace('Improved partial: 64 of 66 parts; missing two cogs', 'Complete-cog partial: 63 of 66 parts; missing three brackets')
exec(compile(s,str(__file__),'exec'))
