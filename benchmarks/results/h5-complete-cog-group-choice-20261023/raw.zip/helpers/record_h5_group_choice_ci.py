from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parents[1]
data=json.loads(subprocess.check_output(['gh','run','view','39950507182','--json','status,conclusion,jobs,headSha,url'],cwd=root))
assert data['headSha']=='2333dd2c590750fa44a3170b34827c25320fe755' and data['status']=='completed' and data['conclusion']=='success'
assert len(data['jobs'])==6 and all(j['conclusion']=='success' for j in data['jobs'])
path=root/'output/h5-complete-cog-group-choice-20261023/main-ci-2333dd2c.json'
with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(data,f,indent=2);f.write('\n')
print('All six prior-main checks saved as successful.')
