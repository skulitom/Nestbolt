"""Audit previously uncombined complete-cog groups split across both target sheets."""
from collections import Counter
from datetime import datetime,timezone
from itertools import combinations
import copy,math,shutil,time
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_complete_cog_group_choice import ROOT,SRC,CAT,OUT as PRIOR,load,write,digest
OUT=ROOT/'output/h5-cog-sheet-group-coverage-20261023'

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    inputs=[PRIOR/n for n in ['candidates.json','mapping.json','audit/checks.json','solve/result.json','layout-audit/checks.json']]+[CAT/n for n in ['placements.json','checks.json']]+[SRC/n for n in ['job.json','conditional-target.json']]
    assert load(PRIOR/'layout-audit/checks.json')['passed'] and load(CAT/'checks.json')['passed']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_cases':1000,'maximum_seconds':30,
      'method':'Enumerate every saved first-sheet catalogue group paired with every saved last-sheet catalogue group, or no last group, whose combined quantity is exactly 15 cogs. Preserve source group ids and exact placements. Map by exact pose identity into the completed source pool. Deduplicate only identical complete global-id sets, report coverage by the prior 165 cases, and retain all new cases and any pending suffix. Independently recompute original cog/cog, cog/frame and frame/frame geometry, allowed transforms and both target-stock bounds for every declared combination. No small-part completion, solver, CLI acceptance, native packing or quality result is inferred. In particular, this audits 12+3 and 10+5 distributions omitted from the prior zero-or-one-last-cog cases without claiming these distributions were never explored by other earlier algorithms.',
      'solver_calls':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    catalogue=load(CAT/'placements.json');first=[i for i,r in enumerate(catalogue) if r['zone']['sheet']=='sheet-0'];last=[None]+[i for i,r in enumerate(catalogue) if r['zone']['sheet']=='sheet-1']
    specs=[{'first_group':i,'last_group':j} for i in first for j in last if len(catalogue[i]['placements'])+(len(catalogue[j]['placements']) if j is not None else 0)==15]
    pool=load(PRIOR/'candidates.json');mp=load(PRIOR/'mapping.json');keys={identity(p['placement']):i for i,p in enumerate(pool)};fixed=mp['fixed_candidates'];prior={tuple(g['candidates']) for g in mp['cog_groups']}
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json');clear=job['clearance']
    gs={i:shape(parts['frame'],pool[i]['placement']['transform']) for i in fixed};records=[];unique={};distances={};stockchecks=pairchecks=0;minimum=math.inf;start=time.perf_counter()
    for spec in specs:
        if len(records)>=1000 or time.perf_counter()-start>=30:break
        ps=catalogue[spec['first_group']]['placements']+(catalogue[spec['last_group']]['placements'] if spec['last_group'] is not None else [])
        ids=sorted(keys[identity(p)] for p in ps);assert len(ids)==len(set(ids))==15
        for i in fixed+ids:
            p=pool[i]['placement'];t=p['transform'];part=parts[p['part_id']]
            assert not t['mirrored'] and (p['part_id']=='cog' or p['part_id']=='frame')
            if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
            if i not in gs:gs[i]=shape(part,t)
            a,b,c,d=gs[i].bounds;h=st['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
            assert gs[i].is_valid and a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=st['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7;stockchecks+=1
        for i,j in combinations(fixed+ids,2):
            if pool[i]['placement']['sheet_id']!=pool[j]['placement']['sheet_id']:continue
            key=tuple(sorted([i,j]))
            if key not in distances:
                dist=gs[i].distance(gs[j]);assert gs[i].disjoint(gs[j]) and dist>=clear-1e-7;distances[key]=dist
            minimum=min(minimum,distances[key]);pairchecks+=1
        key=tuple(ids);nlast=sum(pool[i]['placement']['sheet_id']=='sheet-1' for i in ids)
        r={'index':len(records),**spec,'candidates':ids,'first_sheet_cogs':15-nlast,'last_sheet_cogs':nlast,'in_prior_165_cases':key in prior,'same_as_case':unique.get(key)}
        if key not in unique:unique[key]=r['index']
        records.append(r)
    new=[r for r in records if r['same_as_case'] is None and not r['in_prior_165_cases']]
    write(OUT/'cases.json',records);write(OUT/'new-cases.json',new);write(OUT/'pending.json',specs[len(records):])
    checks={'passed':True,'seconds':time.perf_counter()-start,'planned_combinations':len(specs),'checked_combinations':len(records),'pending_combinations':len(specs)-len(records),'unique_complete_groups':len(unique),'new_complete_groups':len(new),
      'last_sheet_cog_count_histogram':dict(Counter(r['last_sheet_cogs'] for r in records)),'new_last_sheet_cog_count_histogram':dict(Counter(r['last_sheet_cogs'] for r in new)),
      'original_stock_and_transform_checks':stockchecks,'original_geometry_pairs_including_exact_reuse':pairchecks,'distinct_original_geometry_pair_checks':len(distances),'minimum_distance_mm':minimum,
      'every_component_pose_already_in_full_source_pool':True,'full_job_completion_checked':False,'native_margin_qualified':False,'solver_calls':0,'quality_runs':0}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
