"""Check every solver return against original geometry, quantities, stock and CLI."""
from collections import Counter,defaultdict
from itertools import combinations
from datetime import datetime,timezone
import copy,math,shutil,subprocess
from audit_h5_cog_lattices import shape
from build_h5_group_choice import rows
from build_h5_complete_cog_group_choice import ROOT,SRC,OUT,OLD,load,write,digest
def main():
    dst=OUT/'layout-audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py')
    for name,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
    pool=load(OUT/'candidates.json');mp=load(OUT/'mapping.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    target=load(SRC/'conditional-target.json');stock=job['stocks'][0];edge=job['edge_clearance'];m=stock['margins']
    run=OUT/'solve';result=load(run/'result.json');audit=load(run/'model-audit.json')
    assert digest(run/'model.pb')==audit['model_sha256'] and digest(run/'parameters.pbtxt')==audit['parameters_sha256']
    assert digest(OUT/'mapping.json')==audit['mapping_sha256'] and digest(OUT/'cliques.jsonl.gz')==audit['cliques_sha256']
    for name,h in audit['input_hashes'].items():assert digest(ROOT/name)==h
    best_hint=load(OUT/'hints/best-hint.json');g=best_hint['group'];chosen=sorted(best_hint['selected_small_candidates']+mp['fixed_candidates']+mp['cog_groups'][g]['candidates'])
    outcomes=[{'index':'hint','selected_indices':chosen,'cog_group':g,'objective':best_hint['objective'],'counts':dict(Counter(pool[i]['placement']['part_id'] for i in chosen))}]
    outcomes += [load(run/f'incumbent-{i}.json') for i in range(result['incumbents'])]
    if (run/'selected-indices.json').exists():
        final=load(run/'selected-indices.json')
        if not outcomes or final!=outcomes[-1]['selected_indices']:
            outcomes.append({'index':'final','selected_indices':final,'cog_group':result['cog_group'],'objective':result['objective'],'counts':result['counts']})
    cliques=rows(OUT/'cliques.jsonl.gz');ids=mp['candidates'];local={i:j for j,i in enumerate(ids)}
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    source=ROOT/'output/h5-coordinated-placement-selection-20261018'
    original=OLD/'layout-audit';seed_layout=load(original/'layout-final.json')
    cache={};records=[];fresh=reused=0
    def key(layout):
        import json
        return json.dumps(layout,sort_keys=True,separators=(',',':'))
    cache[key(seed_layout)]={'layout':original/'layout-final.json','public':original/'public-final.json','command':original/'command-final.json'}
    areas=load(ROOT/'output/h5-group-choice-20261023/mapping.json')['area_weights']
    for r in outcomes:
        chosen=r['selected_indices'];g=r['cog_group'];frames=set(mp['fixed_candidates']+mp['cog_groups'][g]['candidates']);sm=set(chosen)-frames
        assert frames<=set(chosen) and len(chosen)==len(set(chosen)) and sm<=local.keys()
        selected_local={local[i] for i in sm};assert all(len(selected_local&set(c))<=1 for c in cliques)
        assert all(g in mp['compatible_groups'][local[i]] for i in sm)
        expected_score=sum(areas[pool[i]['placement']['part_id']] for i in sm)
        assert expected_score==r['objective'] and audit['seed_score']<=expected_score<=audit['full_score']
        counts=Counter();geoms=defaultdict(list);placements=[];tops=Counter()
        for i in chosen:
            p=copy.deepcopy(pool[i]['placement']);t=p['transform'];part=parts[p['part_id']]
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
            shape_i=shape(part,t);a,b,c,d=shape_i.bounds;height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
            assert shape_i.is_valid and a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7
            assert c<=stock['width']-m['right']-edge+1e-7 and d<=height-m['top']-edge+1e-7
            geoms[p['sheet_id']].append(shape_i);tops[p['sheet_id']]=max(tops[p['sheet_id']],d+m['top']+edge)
        assert dict(counts)==r['counts'] and counts['frame']==18 and counts['cog']==15
        assert all(counts[f]<=p['quantity'] for f,p in parts.items())
        pairs=0;minimum=math.inf
        for shapes in geoms.values():
            for a,b in combinations(shapes,2):
                pairs+=1;distance=a.distance(b);minimum=min(minimum,distance)
                assert a.disjoint(b) and distance>=job['clearance']-1e-7
        layout={'version':1,'units':'mm','sheets':seed_layout['sheets'],'placements':placements};index=r['index'];path=dst/f'layout-{index}.json';write(path,layout)
        if key(layout) in cache:
            origin=cache[key(layout)];assert load(origin['layout'])==layout;public=load(origin['public']);code=load(origin['command'])['exit_code']
            write(dst/f'validation-reuse-{index}.json',{'rerun':False,'exact_layout_match':True,'source_files':{p.relative_to(ROOT).as_posix():digest(p) for p in origin.values()}})
            shutil.copyfile(origin['public'],dst/f'public-{index}.json');reused+=1;reuse=True
        else:
            cmd=[str(cli),'validate','--library',str(source/'library.json'),'--request',str(source/'request.json'),'--layout',str(path)]
            cp=subprocess.run(cmd,capture_output=True,timeout=60);code=cp.returncode;pp=dst/f'public-{index}.json';cc=dst/f'command-{index}.json'
            pp.write_bytes(cp.stdout);(dst/f'public-{index}.stderr').write_bytes(cp.stderr);write(cc,{'command':cmd,'exit_code':code})
            public=load(pp);cache[key(layout)]={'layout':path,'public':pp,'command':cc};fresh+=1;reuse=False
        missing={f:p['quantity']-counts[f] for f,p in parts.items() if counts[f]<p['quantity']}
        expected=[{'code':'quantity','message':f"part {f}: expected {parts[f]['quantity']}, found {counts[f]}"} for f in missing]
        assert sorted(public['violations'],key=lambda v:v['message'])==sorted(expected,key=lambda v:v['message'])
        assert public['valid']==(not missing) and (code==0)==(not missing)
        material=stock['width']*(stock['height']+tops['sheet-1']);area=sum(g.area for shapes in geoms.values() for g in shapes)
        assert material<=target['target_material_mm2']+1e-6
        records.append({'incumbent':index,'cog_group':g,'counts':dict(counts),'missing':missing,'filled_area_mm2':area,
          'material_mm2':material,'minimum_distance_mm':minimum,'original_geometry_pairs':pairs,'original_CLI_valid':public['valid'],'exact_CLI_result_reused':reuse})
    best=max(records,key=lambda r:r['filled_area_mm2']) if records else None
    check={'passed':True,'utc':datetime.now(timezone.utc).isoformat(),'layouts_checked_including_hint':len(records),'all_returned_layouts_checked':len(records)-1,
      'fresh_frozen_CLI_calls':fresh,'exact_frozen_CLI_results_reused':reused,'best':best,'records':records,
      'full_target_witness':any(r['original_CLI_valid'] for r in records),'native_margin_qualified':False,
      'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0}
    write(dst/'checks.json',check);print({k:v for k,v in check.items() if k!='records'},flush=True)
if __name__=='__main__':main()
