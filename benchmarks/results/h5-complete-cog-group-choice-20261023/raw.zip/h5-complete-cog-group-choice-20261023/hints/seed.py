"""Bounded comparison of all 165 complete-cog cases with every small part free."""
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction
from itertools import permutations
import gzip,json,shutil,time
from build_h5_complete_cog_group_choice import ROOT,OUT as BASE,load,write,digest
OUT=BASE/'hints'

def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'seed.py')
    mp=load(BASE/'mapping.json');pool=load(BASE/'candidates.json');ids=mp['candidates'];local={i:j for j,i in enumerate(ids)};adj=[0]*len(ids)
    with gzip.open(BASE/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);mask=sum(1<<j for j in row)
            for j in row:adj[j]|=mask^(1<<j)
    weights=load(ROOT/'output/h5-group-choice-20261023/mapping.json')['area_weights'];caps={'bracket':12,'insert':21};family=[pool[i]['placement']['part_id'] for i in ids];poses=[pool[i]['placement'] for i in ids]
    orders=[]
    def coordinate(j,kind,reverse):
        p=poses[j];x,y=p['transform']['translation'];sheet=(p['sheet_id']=='sheet-1')^reverse
        if kind=='degree':return (adj[j].bit_count(),sheet,y,x,ids[j])
        return (sheet,-y if kind=='top-left' else y,-x if kind=='bottom-right' else x,ids[j])
    for f in permutations(caps):
        for kind in ['bottom-left','top-left','bottom-right','degree']:
            for reverse in [False,True]:
                rank={name:i for i,name in enumerate(f)};orders.append(({'families':list(f),'kind':kind,'last_sheet_first':reverse},sorted(range(len(ids)),key=lambda j:(rank[family[j]],coordinate(j,kind,reverse)))))
    for kind in ['area','degree-per-area']:
        for reverse in [False,True]:
            orders.append(({'kind':kind,'last_sheet_first':reverse},sorted(range(len(ids)),key=lambda j:((poses[j]['sheet_id']=='sheet-1')^reverse,-weights[family[j]] if kind=='area' else Fraction(adj[j].bit_count(),weights[family[j]]),adj[j].bit_count(),ids[j]))))
    assert len(orders)==20
    inputs=[BASE/n for n in ['plan.json','candidates.json','mapping.json','audit/checks.json','cliques.jsonl.gz']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_seconds':30,'maximum_cases':3300,
      'ordering_specs':[d for d,o in orders],'method':'Visit all 165 cog cases in saved order, each with the declared 20 deterministic small-part orderings. Start from no small parts and add compatible original bracket/insert poses greedily while checking the entire adjacency and original quantity caps. Keep every result and any pending suffix; retain the prior checked 61-part seed if no result improves its original filled area. Each selected group always contributes all 15 cogs and the same 18 frames. Verify every final mask, compatibility and score; this is a new construction census, not a new solver or a production repair.'})
    allowed=[0]*len(mp['cog_groups'])
    for j,groups in enumerate(mp['compatible_groups']):
        for g in groups:allowed[g]|=1<<j
    best={'source':'prior-61','group':mp['seed_group'],'selected_small_candidates':mp['seed_candidates'],'counts':dict(Counter(pool[i]['placement']['part_id'] for i in mp['seed_candidates'])),'objective':sum(weights[pool[i]['placement']['part_id']] for i in mp['seed_candidates'])}
    def rank(r):return (r['objective'],len(r['selected_small_candidates']),r['selected_small_candidates'],-r['group'])
    hints=[];cases=[(g,d,o) for g in range(len(mp['cog_groups'])) for d,o in orders];start=time.perf_counter()
    for g,description,order in cases:
        if time.perf_counter()-start>=30:break
        counts=Counter();mask=0;chosen=[]
        for j in order:
            if counts[family[j]]>=caps[family[j]] or not((allowed[g]>>j)&1) or adj[j]&mask:continue
            chosen.append(j);mask|=1<<j;counts[family[j]]+=1
            if counts==caps:break
        assert not(mask&~allowed[g]) and all(not(adj[j]&mask) for j in chosen) and all(counts[f]<=caps[f] for f in caps)
        r={'index':len(hints),'source':'group-greedy','group':g,'ordering':description,'selected_small_candidates':sorted(ids[j] for j in chosen),'counts':dict(counts),'objective':sum(weights[family[j]] for j in chosen)};hints.append(r)
        if rank(r)>rank(best):best=r
    elapsed=time.perf_counter()-start
    write(OUT/'hints.json',hints);write(OUT/'best-hint.json',best);write(OUT/'pending.json',[{'group':g,'ordering':d} for g,d,o in cases[len(hints):]])
    # Rebuild each result independently from the final selected global ids.
    for r in hints+[best]:
        chosen=[local[i] for i in r['selected_small_candidates']];mask=sum(1<<j for j in chosen);counts=Counter(family[j] for j in chosen)
        assert len(chosen)==len(set(chosen)) and dict(counts)==r['counts'] and all(counts[f]<=caps[f] for f in caps)
        assert all(not(adj[j]&mask) and r['group'] in mp['compatible_groups'][j] for j in chosen)
        assert sum(weights[family[j]] for j in chosen)==r['objective']
    checks={'passed':True,'seconds':elapsed,'planned_cases':len(cases),'completed_cases':len(hints),'pending_cases':len(cases)-len(hints),'limit_reached':elapsed>=30,'every_result_full_graph_compatibility_counts_score_checked':True,'prior_seed_preserved':best['objective']>=736200000,'best_hint':{k:v for k,v in best.items() if k!='selected_small_candidates'},'full_inventory_hint':best['counts']==caps,'original_CLI_acceptance_pending':True,'native_margin_qualified':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
