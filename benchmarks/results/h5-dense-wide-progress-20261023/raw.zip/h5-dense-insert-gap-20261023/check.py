"""Four conservative insertion queries against the exact improved 63-part layout."""
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import copy,math,shutil,subprocess,time
from shapely.geometry import mapping,shape as read_geometry
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import proposals
from build_h5_dense_wide_contacts import ROOT,SRC,OUT as SEED,load,write,digest
OUT=ROOT/'output/h5-dense-insert-gap-20261023'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'check.py');inputs=[SEED/'layout-audit/layout-final.json',SEED/'layout-audit/checks.json',SRC/'job.json',SRC/'conditional-target.json']
    assert load(inputs[1])['passed'];job=load(inputs[2]);parts={p['id']:p for p in job['parts']};layout=load(inputs[0]);target=load(inputs[3]);stock=job['stocks'][0]
    counts=Counter(p['part_id'] for p in layout['placements']);assert counts==Counter(frame=18,bracket=12,cog=13,insert=20)
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_seconds':30,'maximum_queries':4,'construction_padding_mm':0.0126,
      'method':'Keep all63 improved placements byte-for-byte. Check the two rectangle orientation classes on each original target sheet using conservative original-outline free translation regions. Record the region and all representative/vertex/edge-midpoint proposals and check each actual insert against every original neighbor. If any fits, append exactly one insert, choosing sheet then y,x,angle; independently check the entire layout and frozen original CLI. Empty conservative regions are not an unrestricted impossibility proof. No cogs move or new solver runs occur. Preserve any unbuilt query on expiry.'})
    gap.EPS=.0126;queries=[(s,a) for s in ['sheet-0','sheet-1'] for a in [0,90]];geometries=[shape(parts[p['part_id']],p['transform']) for p in layout['placements']];valid=[];records=[];checked_pairs=0;start=time.perf_counter()
    for s,a in queries:
        if time.perf_counter()-start>=30:break
        this=copy.deepcopy(stock)
        if s=='sheet-1':this['height']=target['required_used_height_mm']
        t={'rotation_radians':math.radians(a),'mirrored':False,'translation':[0.,0.]};moving=shape(parts['insert'],t);neighbors=[g for p,g in zip(layout['placements'],geometries) if p['sheet_id']==s]
        region=gap.regions(moving,neighbors,this,job['edge_clearance'],job['clearance']);points=proposals(region);events=[]
        for i,r in enumerate(points):
            p={'part_id':'insert','copy_index':20,'sheet_id':s,'transform':{**t,'translation':r['point']}};g=shape(parts['insert'],p['transform']);x0,y0,x1,y1=g.bounds;m=stock['margins'];e=job['edge_clearance']
            outside=x0<m['left']+e-1e-7 or y0<m['bottom']+e-1e-7 or x1>stock['width']-m['right']-e+1e-7 or y1>this['height']-m['top']-e+1e-7
            ds=[g.distance(other) for other in neighbors];checked_pairs+=len(ds);ok=not outside and all(d>=job['clearance']-1e-7 for d in ds)
            events.append({'proposal':i,'outside':bool(outside),'minimum_distance_mm':min(ds),'valid':ok})
            if ok:valid.append(p)
        record={'index':len(records),'sheet':s,'degrees':a,'region':mapping(region),'region_empty':region.is_empty,'proposals':points,'events':events}
        assert proposals(read_geometry(record['region']))==points;write(OUT/f"query-{record['index']}.json",record);records.append(record)
    check={'passed':True,'seconds':time.perf_counter()-start,'queries_completed':len(records),'pending_queries':queries[len(records):],'empty_regions':sum(r['region_empty'] for r in records),'proposals':sum(len(r['proposals']) for r in records),'original_pair_checks':checked_pairs,'feasible_additions':len(valid),'original_seed_unchanged':True,'full_target_witness':False,'native_margin_qualified':False,'solver_calls':0,'quality_runs':0}
    if valid:
        p=min(valid,key=lambda p:(p['sheet_id'],p['transform']['translation'][1],p['transform']['translation'][0],p['transform']['rotation_radians']));out=copy.deepcopy(layout);out['placements'].append(p);write(OUT/'layout.json',out)
        assert out['placements'][:-1]==layout['placements'];gs=[shape(parts[p['part_id']],p['transform']) for p in out['placements']];minimum=math.inf;pairs=0
        for i,j in combinations(range(len(gs)),2):
            if out['placements'][i]['sheet_id']!=out['placements'][j]['sheet_id']:continue
            d=gs[i].distance(gs[j]);minimum=min(minimum,d);pairs+=1;assert gs[i].disjoint(gs[j]) and d>=job['clearance']-1e-7
        cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
        original=ROOT/'output/h5-coordinated-placement-selection-20261018';cmd=[str(cli),'validate','--library',str(original/'library.json'),'--request',str(original/'request.json'),'--layout',str(OUT/'layout.json')]
        cp=subprocess.run(cmd,capture_output=True,timeout=60);(OUT/'public.json').write_bytes(cp.stdout);(OUT/'public.stderr').write_bytes(cp.stderr);write(OUT/'command.json',{'command':cmd,'exit_code':cp.returncode});report=load(OUT/'public.json')
        assert not report['valid'] and cp.returncode!=0 and report['violations']==[{'code':'quantity','message':'part cog: expected 15, found 13'}]
        check.update(appended_insert=p,full_layout_pairs=pairs,minimum_distance_mm=minimum,counts={'frame':18,'bracket':12,'cog':13,'insert':21},filled_area_mm2=sum(g.area for g in gs))
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
