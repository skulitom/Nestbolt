"""Independent construction replay, translation checks, and complete original conflict graph."""
from collections import Counter,deque
from itertools import combinations
import copy,gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import shape as read_geometry,box
from shapely.affinity import affine_transform
from shapely.ops import unary_union
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_dense_wide_contacts import ROOT,SRC,OLD,CAT,OUT,load,write,digest

def main():
    dst=OUT/'audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');start=time.perf_counter();plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    pool=load(OUT/'candidates.json');source=load(OLD/'candidates.json');mp=load(OUT/'mapping.json');oldmp=load(OLD/'mapping.json');result=load(OUT/'result.json')
    assert pool[:len(source)]==source and mp['source_pool_size']==len(source) and mp['old_candidates']==oldmp['candidates'] and mp['fixed_candidates']==oldmp['fixed_candidates']
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clearance=job['clearance'];gap.EPS=plan['construction_padding_mm']
    target=load(SRC/'conditional-target.json');ids=mp['candidates'];fixed=mp['fixed_candidates'];geometry={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in ids+fixed}
    groups=load(CAT/'placements.json');selected=sorted([i for i,r in enumerate(groups) if r['zone']['sheet']=='sheet-0' and len(r['placements'])>=9],key=lambda i:(-len(groups[i]['placements']),i))
    orient=[{'family':'bracket','degrees':a,'mirrored':mir} for mir in [False,True] for a in [0,90,180,270]]+[{'family':'insert','degrees':a,'mirrored':False} for a in [0,90]]
    planned=[{'group':i,**o} for i in selected for o in orient];assert planned==plan['queries'] and selected==plan['groups']
    caches=load(OUT/'cache-index.json');cache={};maximum_error=0.;cache_direct_pairs=0
    for at,r in enumerate(caches):
        saved=load(OUT/'obstacles'/f'{at}.json');assert r=={k:v for k,v in saved.items() if k!='geometry'} and r['index']==at
        f=shape(parts[r['fixed_part']],r['fixed_transform']);o=r['moving'];moving=shape(parts[o['family']],{'rotation_radians':math.radians(o['degrees']),'mirrored':o['mirrored'],'translation':[0.,0.]})
        g=read_geometry(saved['geometry']);expected=gap.obstacle(f,moving,clearance);assert expected.equals_exact(g,0)
        p=r['first_actual_fixed'];t=p['transform'];direct=gap.obstacle(shape(parts[p['part_id']],t),moving,clearance);shift=affine_transform(g,[1,0,0,1,*t['translation']])
        error=direct.hausdorff_distance(shift);maximum_error=max(maximum_error,error);assert error<1e-7 and direct.symmetric_difference(shift).area<1e-5;cache_direct_pairs+=1
        k=(r['fixed_part'],float(r['fixed_transform']['rotation_radians']).hex(),r['fixed_transform']['mirrored'],o['family'],o['degrees'],o['mirrored']);assert k not in cache;cache[k]=g
    queries=[];region_error=0.
    for i in range(result['completed_queries']):
        q=load(OUT/'regions'/f'query-{i}.json');item=planned[i];assert q['index']==i and all(q[k]==v for k,v in item.items()) and q['rotation_radians']==math.radians(q['degrees'])
        moving=shape(parts[q['family']],{'rotation_radians':q['rotation_radians'],'mirrored':q['mirrored'],'translation':[0.,0.]});a,b,c,d=moving.bounds
        domain=box(m['left']+edge+gap.EPS-a,m['bottom']+edge+gap.EPS-b,stock['width']-m['right']-edge-gap.EPS-c,stock['height']-m['top']-edge-gap.EPS-d);obstacles=[]
        for p in [pool[j]['placement'] for j in fixed]+groups[q['group']]['placements']:
            t=p['transform'];k=(p['part_id'],float(t['rotation_radians']).hex(),t['mirrored'],q['family'],q['degrees'],q['mirrored'])
            obstacles.append(affine_transform(cache[k],[1,0,0,1,*t['translation']]))
        region=read_geometry(q['region']);expected=domain.difference(unary_union(obstacles));assert expected.is_empty==region.is_empty
        error=expected.symmetric_difference(region).area;region_error=max(region_error,error);assert error<1e-6 and q['proposals']==proposals(region);queries.append(q)
    group_geometries={i:[shape(parts['cog'],p['transform']) for p in groups[i]['placements']] for i in selected}
    events=load(OUT/'source-events.json');cogs=load(CAT/'new-poses.json');keys={identity(p['placement']):i for i,p in enumerate(source)};counts=Counter();added=[];newcogs=[];contacts=[]
    queue=deque((q['index'],0) for q in queries if q['proposals']);deferred=[];frame_pairs=group_pairs=rejected=duplicates=0
    for at,event in enumerate(events):
        if at<len(cogs):p=cogs[at];origin={'kind':'dense-cog','index':at};gg=[]
        else:
            while True:
                qi,pi=queue.popleft();q=queries[qi];f=q['family']
                if counts[f]>=plan['new_contact_caps'][f]:deferred.append([qi,pi])
                else:break
            p={'part_id':f,'sheet_id':'sheet-0','transform':{'rotation_radians':q['rotation_radians'],'mirrored':q['mirrored'],'translation':q['proposals'][pi]['point']}};origin={'kind':'dense-contact','query':qi,'proposal':pi};gg=group_geometries[q['group']]
        assert event['origin']==origin;g=shape(parts[p['part_id']],p['transform']);a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>h-m['top']-edge+1e-7;blockers=[];qblock=[]
        for j in fixed:
            if pool[j]['placement']['sheet_id']!=p['sheet_id']:continue
            frame_pairs+=1
            if g.distance(geometry[j])<clearance-1e-7:blockers.append(j)
        for j,other in enumerate(gg):
            group_pairs+=1
            if g.distance(other)<clearance-1e-7:qblock.append(j)
        if outside or blockers or qblock:
            rejected+=1;assert event=={'origin':origin,'added':False,'reason':'geometry','outside':bool(outside),'frame_blockers':blockers,'group_blockers':qblock}
        elif identity(p) in keys:
            duplicates+=1;assert event=={'origin':origin,'added':False,'reason':'duplicate','candidate':keys[identity(p)]}
        else:
            j=len(source)+len(added);assert event=={'origin':origin,'added':True,'candidate':j} and pool[j]['placement']==p and pool[j]['source']==origin and abs(pool[j]['filled_area_mm2']-g.area)<1e-7
            keys[identity(p)]=j;added.append(j);counts[p['part_id']]+=1;(newcogs if p['part_id']=='cog' else contacts).append(j)
        if at>=len(cogs) and pi+1<len(q['proposals']):queue.append((qi,pi+1))
    pending=load(OUT/'pending.json');assert pending=={'queries':planned[len(queries):],'proposal_lists':sorted(deferred+list(map(list,queue)))}
    assert added==mp['new_candidates'] and newcogs==mp['new_cogs'] and contacts==mp['new_contacts'] and dict(counts)==result['new_candidates'] and ids==sorted(mp['old_candidates']+added)
    assert mp['seed_candidates']==sorted(set(load(OLD/'solve/selected-indices.json'))-set(fixed))
    for i in ids+fixed:
        p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform'];g=geometry[i];a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        assert g.is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
        for j in fixed:
            if j==i or pool[j]['placement']['sheet_id']!=p['sheet_id']:continue
            frame_pairs+=1;assert g.disjoint(geometry[j]) and g.distance(geometry[j])>=clearance-1e-7
    gs=np.asarray([geometry[i] for i in ids],dtype=object);bb=shapely.bounds(gs);ss=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);adj=[0]*len(ids);allpairs=near=0
    for i in range(len(ids)):
        js=np.arange(i+1,len(ids));js=js[ss[js]==ss[i]];allpairs+=len(js)
        dx=np.maximum(0,np.maximum(bb[js,0]-bb[i,2],bb[i,0]-bb[js,2]));dy=np.maximum(0,np.maximum(bb[js,1]-bb[i,3],bb[i,1]-bb[js,3]));js=js[np.hypot(dx,dy)<=clearance+1e-7];near+=len(js)
        for j in js[shapely.distance(gs[i],gs[js])<clearance-1e-7]:j=int(j);adj[i]|=1<<j;adj[j]|=1<<i
    edgecount=sum(a.bit_count() for a in adj)//2;seen=0;previous=(-1,-1)
    with gzip.open(OUT/'conflicts.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            pair=tuple(json.loads(line));i,j=pair;assert pair>previous and i<j and (adj[i]>>j)&1;previous=pair;seen+=1
    assert seen==edgecount==result['conflicts'];covered=[0]*len(ids);cliquecount=0
    with gzip.open(OUT/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            c=json.loads(line);assert len(c)==len(set(c));mask=sum(1<<i for i in c);cliquecount+=1
            for i in c:others=mask^(1<<i);assert not(others&~adj[i]);covered[i]|=others
    assert covered==adj
    local={i:j for j,i in enumerate(ids)};seedmask=sum(1<<local[i] for i in mp['seed_candidates']);assert all(not(adj[local[i]]&seedmask) for i in mp['seed_candidates'])
    record={'passed':True,'seconds':time.perf_counter()-start,'source_pool_prefix_unchanged':True,'cache_entries':cache_direct_pairs,'maximum_absolute_translation_error_mm':maximum_error,'all_query_regions_reconstructed':len(queries),'maximum_region_area_error_mm2':region_error,
      'frame_pairs':frame_pairs,'proposal_group_pairs':group_pairs,'rejections':rejected,'duplicates':duplicates,'pending_lists_preserved':len(pending['proposal_lists']),'pending_queries_preserved':len(pending['queries']),
      'all_small_pair_possibilities':allpairs,'exact_pair_distances':near,'conflicts':edgecount,'cliques_including_residual_edges':cliquecount,'original_seed_feasible':True,
      'all_geometry_and_graph_coverage_checked':True,'native_margin_qualified':False,'full_target_witness':False}
    write(dst/'checks.json',record);print(record,flush=True)
if __name__=='__main__':main()
