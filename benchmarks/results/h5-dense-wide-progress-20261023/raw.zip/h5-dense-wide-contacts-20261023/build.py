"""Denser original cog groups and new small-part contacts, with all small families free."""
from collections import Counter,deque
from datetime import datetime,timezone
from pathlib import Path
from itertools import product
import copy,math,shutil,time,traceback
from shapely.geometry import box,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_cog_insert_contacts import graph
from build_h5_group_choice import ROOT,SRC,load,write,digest
OLD=ROOT/'output/h5-wide-small-pool-20261023'
CAT=ROOT/'output/h5-wide-catalogue-coverage-20261023'
OUT=ROOT/'output/h5-dense-wide-contacts-20261023'

def main():
    OUT.mkdir();(OUT/'regions').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    inputs=[OLD/n for n in ['candidates.json','mapping.json','audit/checks.json','layout-audit/checks.json','solve/selected-indices.json']]
    inputs += [CAT/n for n in ['new-poses.json','placements.json','checks.json']]+[SRC/n for n in ['job.json','conditional-target.json']]
    assert load(CAT/'checks.json')['passed'] and load(OLD/'layout-audit/checks.json')['passed']
    groups=load(CAT/'placements.json');selected=sorted([i for i,r in enumerate(groups) if r['zone']['sheet']=='sheet-0' and len(r['placements'])>=9],key=lambda i:(-len(groups[i]['placements']),i))
    orient=[{'family':'bracket','degrees':a,'mirrored':mir} for mir in [False,True] for a in [0,90,180,270]]+[{'family':'insert','degrees':a,'mirrored':False} for a in [0,90]]
    queries=[{'group':i,**o} for i in selected for o in orient]
    plan={'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'generation_seconds':120,'query_seconds':90,
      'new_contact_caps':{'bracket':1200,'insert':800},'compression_seconds':20,'solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'construction_padding_mm':0.0126,
      'groups':selected,'queries':queries,'method':'Keep the same original18 wider frames fixed and all10066 compatible old choices, before any old safe reduction. Add all488 audited absent cog poses. For each saved first-sheet denser group with at least9 cogs, in descending count then saved order, construct free regions for all bracket quarter turns/reflections and two insert size classes against18 frames plus that group. Groups only propose positions; no cog group is fixed in the final model. Cache the original zero-translation Minkowski obstacles and translate them exactly for each neighbor. Record every cache entry. Keep all proposal representatives, vertices and edge midpoints, then cycle round-robin under fresh caps. No old pending list is resumed. Retain all unbuilt queries and capped/unprocessed lists. Recompute all family-pair conflicts before a new audit/reduction and at most one solver call.',
      'hint':'Retain the prior62-part final after exact old-index preservation; any new safe substitutions must be proved on the changed graph before mapping the hint.',
      'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0}
    write(OUT/'plan.json',plan);beg=time.perf_counter();pool=copy.deepcopy(load(OLD/'candidates.json'));oldmp=load(OLD/'mapping.json');fixed=oldmp['fixed_candidates'];oldids=oldmp['candidates']
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];clearance=job['clearance'];gap.EPS=plan['construction_padding_mm']
    target=load(SRC/'conditional-target.json');geometry={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in oldids+fixed};keys={identity(p['placement']):i for i,p in enumerate(pool)}
    assert len(keys)==len(pool);events=[];new=[];newcogs=[];contacts=[];counts=Counter();obstacles={};obstacle_records=[];cache_geometries={}
    def consider(p,origin,query_fixed=None):
        g=shape(parts[p['part_id']],p['transform']);a,b,c,d=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>h-m['top']-edge+1e-7
        blockers=[i for i in fixed if pool[i]['placement']['sheet_id']==p['sheet_id'] and g.distance(geometry[i])<clearance-1e-7]
        qblockers=[j for j,gg in enumerate(query_fixed or []) if g.distance(gg)<clearance-1e-7];e={'origin':origin}
        if outside or blockers or qblockers:e.update(added=False,reason='geometry',outside=bool(outside),frame_blockers=blockers,group_blockers=qblockers)
        elif identity(p) in keys:e.update(added=False,reason='duplicate',candidate=keys[identity(p)])
        else:
            i=len(pool);pool.append({'index':i,'placement':p,'source':origin,'filled_area_mm2':g.area});keys[identity(p)]=i;geometry[i]=g;new.append(i);counts[p['part_id']]+=1;e.update(added=True,candidate=i)
            (newcogs if p['part_id']=='cog' else contacts).append(i)
        events.append(e)
        return e
    for j,p in enumerate(load(CAT/'new-poses.json')):assert consider(p,{'kind':'dense-cog','index':j})['added']
    def exclusion(p,moving,descriptor):
        t=p['transform'];zero={**t,'translation':[0.,0.]};k=(p['part_id'],float(t['rotation_radians']).hex(),t['mirrored'],descriptor['family'],descriptor['degrees'],descriptor['mirrored'])
        if k not in obstacles:
            index=len(obstacles);g=shape(parts[p['part_id']],zero);ob=gap.obstacle(g,moving,clearance);obstacles[k]=index;cache_geometries[index]=ob
            r={'index':index,'fixed_part':p['part_id'],'fixed_transform':zero,'moving':descriptor,'geometry':mapping(ob),'first_actual_fixed':p}
            write(OUT/'obstacles'/f'{index}.json',r);obstacle_records.append(r)
        return translate(cache_geometries[obstacles[k]],*t['translation'])
    done=[]
    for item in queries:
        if time.perf_counter()-beg>=plan['query_seconds']:break
        qbeg=time.perf_counter();o={k:item[k] for k in ['family','degrees','mirrored']};f=o['family'];t={'rotation_radians':math.radians(o['degrees']),'mirrored':o['mirrored'],'translation':[0.,0.]};moving=shape(parts[f],t)
        a,b,c,d=moving.bounds;domain=box(m['left']+edge+gap.EPS-a,m['bottom']+edge+gap.EPS-b,stock['width']-m['right']-edge-gap.EPS-c,stock['height']-m['top']-edge-gap.EPS-d)
        neighbors=[pool[i]['placement'] for i in fixed]+groups[item['group']]['placements'];region=domain.difference(unary_union([exclusion(p,moving,o) for p in neighbors]))
        q={'index':len(done),**item,'rotation_radians':t['rotation_radians'],'region':mapping(region),'proposals':proposals(region),'seconds':time.perf_counter()-qbeg}
        write(OUT/'regions'/f"query-{q['index']}.json",q);done.append(q)
        if len(done)%100==0:print({'queries':len(done),'elapsed':time.perf_counter()-beg},flush=True)
    query_seconds=time.perf_counter()-beg;queue=deque((q['index'],0) for q in done if q['proposals']);deferred=[];group_geometries={i:[shape(parts['cog'],p['transform']) for p in groups[i]['placements']] for i in selected}
    while queue and time.perf_counter()-beg<plan['generation_seconds']:
        qi,pi=queue.popleft();q=done[qi];f=q['family']
        if counts[f]>=plan['new_contact_caps'][f]:deferred.append([qi,pi]);continue
        p={'part_id':f,'sheet_id':'sheet-0','transform':{'rotation_radians':q['rotation_radians'],'mirrored':q['mirrored'],'translation':q['proposals'][pi]['point']}}
        consider(p,{'kind':'dense-contact','query':qi,'proposal':pi},group_geometries[q['group']])
        if pi+1<len(q['proposals']):queue.append((qi,pi+1))
    seconds=time.perf_counter()-beg;ids=sorted(oldids+new);seed=sorted(set(load(OLD/'solve/selected-indices.json'))-set(fixed));assert set(seed)<=set(ids)
    write(OUT/'candidates.json',pool);write(OUT/'source-events.json',events);write(OUT/'cache-index.json',[{k:v for k,v in r.items() if k!='geometry'} for r in obstacle_records])
    write(OUT/'pending.json',{'queries':queries[len(done):],'proposal_lists':sorted(deferred+list(map(list,queue)))})
    write(OUT/'mapping.json',{'candidates':ids,'fixed_candidates':fixed,'old_candidates':oldids,'new_candidates':new,'new_cogs':newcogs,'new_contacts':contacts,'seed_candidates':seed,'optional_insert_strip':oldmp['optional_insert_strip'],'source_pool_size':len(keys)-len(new)})
    r={'generation_seconds':seconds,'query_phase_seconds':query_seconds,'planned_queries':len(queries),'completed_queries':len(done),'cache_entries':len(obstacle_records),'new_candidates':dict(counts),'retained_candidates':len(ids),'events':len(events),
      'pending_queries':len(queries)-len(done),'pending_lists':len(deferred)+len(queue),'generation_limit_reached':seconds>=120,**graph(OUT,ids,pool,geometry,clearance)}
    write(OUT/'result.json',r);print(r,flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
