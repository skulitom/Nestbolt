"""Finite graph-checked starting layouts anchored on the newly admitted cog groups."""
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction
from itertools import permutations
import gzip,json,shutil,time
from build_h5_cog_free_regions import identity
from build_h5_dense_wide_contacts import ROOT,OUT as BASE,CAT,load,write,digest
RED=BASE/'reduced';OUT=BASE/'group-hints'
def main():
    assert load(RED/'checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'seed.py')
    inputs=[BASE/n for n in ['candidates.json','mapping.json','plan.json','audit/checks.json']]+[RED/n for n in ['mapping.json','cliques.jsonl.gz','substitutions.json','best-hint.json','checks.json']]+[CAT/'placements.json']
    groups=load(BASE/'plan.json')['groups'];planned=len(groups)*40
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_hint_seconds':30,'maximum_cases':planned,
      'method':'For every selected original cog group, map all members through the newly checked same-family substitutions. Enumerate the same20 family/coordinate orderings used by the reducer, with or without the optional11-insert strip:40 starts per group. Hold that starting group during each greedy scan, cap every original family quantity, and skip every conflict. Verify each final mask against the complete reduced adjacency. Keep every completed hint and a pending-case count if the30-second ceiling expires; do not extend or resume it. Select the best among these and the earlier41 verified hints by integer original filled area, count and exact ids. No solver call or native quality run is involved.'})
    pool=load(BASE/'candidates.json');mp=load(RED/'mapping.json');ids=mp['candidates'];local={i:j for j,i in enumerate(ids)};adj=[0]*len(ids)
    with gzip.open(RED/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:
            row=json.loads(line);mask=sum(1<<i for i in row)
            for i in row:adj[i]|=mask^(1<<i)
    replacement={r['removed']:r['replacement'] for r in load(RED/'substitutions.json')};keys={identity(p['placement']):i for i,p in enumerate(pool)}
    poses=[pool[i]['placement'] for i in ids];family=[p['part_id'] for p in poses];caps={'bracket':12,'cog':15,'insert':21};weights=mp['area_weights'];catalogue=load(CAT/'placements.json')
    strip=[local[replacement.get(i,i)] for i in load(BASE/'mapping.json')['optional_insert_strip']]
    def coordinate(j,kind):
        p=poses[j];x,y=p['transform']['translation'];sheet=p['sheet_id']
        return (adj[j].bit_count(),sheet,y,x,ids[j]) if kind=='degree' else (sheet,-y if kind=='top-left' else y,x,ids[j])
    orders=[]
    for order in permutations(caps):
        rank={f:i for i,f in enumerate(order)}
        for kind in ['bottom-left','top-left','degree']:orders.append(({'families':list(order),'kind':kind},sorted(range(len(ids)),key=lambda j:(rank[family[j]],coordinate(j,kind)))))
    orders.append(({'kind':'area'},sorted(range(len(ids)),key=lambda j:(-weights[family[j]],adj[j].bit_count(),ids[j]))))
    orders.append(({'kind':'degree-per-area'},sorted(range(len(ids)),key=lambda j:(Fraction(adj[j].bit_count(),weights[family[j]]),ids[j]))))
    cases=[(g,force,description,order) for g in groups for force in [False,True] for description,order in orders]
    assert len(cases)==planned;hints=[];start=time.perf_counter();best={**load(RED/'best-hint.json'),'source':'reduced-hints'}
    def rank(r):return (r['objective'],len(r['selected_small_candidates']),r['selected_small_candidates'])
    for g,force,description,order in cases:
        if time.perf_counter()-start>=30:break
        original=[keys[identity(p)] for p in catalogue[g]['placements']];chosen=[local[replacement.get(i,i)] for i in original]+(strip if force else [])
        assert len(chosen)==len(set(chosen));counts=Counter(family[j] for j in chosen);mask=sum(1<<j for j in chosen)
        assert all(counts[f]<=caps[f] for f in caps) and all(not(adj[j]&mask) for j in chosen)
        for j in order:
            if (mask>>j)&1 or counts[family[j]]>=caps[family[j]] or adj[j]&mask:continue
            chosen.append(j);mask|=1<<j;counts[family[j]]+=1
        assert all(not(adj[j]&mask) for j in chosen) and all(counts[f]<=caps[f] for f in caps)
        r={'index':len(hints),'source':'group-hints','group':g,'forced_strip':force,'ordering':description,'selected_small_candidates':sorted(ids[j] for j in chosen),'counts':dict(counts),'objective':sum(weights[family[j]] for j in chosen)}
        hints.append(r)
        if rank(r)>rank(best):best=r
    seconds=time.perf_counter()-start;write(OUT/'hints.json',hints);write(OUT/'best-hint.json',best)
    checks={'passed':True,'seconds':seconds,'planned_cases':planned,'completed_cases':len(hints),'pending_cases':planned-len(hints),'limit_reached':len(hints)<planned,
      'every_forced_group_and_final_mask_checked':True,'prior_hint_preserved':best['objective']>=load(RED/'best-hint.json')['objective'],'best_hint':{k:v for k,v in best.items() if k!='selected_small_candidates'},'full_inventory_hint':best['counts']==caps,'original_CLI_acceptance_pending':True,'native_margin_qualified':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
