"""Exact nominal filled-outline keys plus identical effective hard domains."""
from fractions import Fraction as F
import copy,math
def outline_key(library,family,mode):
    if family=='cog':return ('continuous-cog',)
    quarter=round(mode['rotation_radians']/(math.pi/2))%4;assert abs(math.remainder(mode['rotation_radians']-quarter*math.pi/2,math.tau))<1e-12;px,py=map(F,library['families'][family]['source_center']);sign=-1 if mode['mirrored'] else 1;points=[]
    for x,y in library['families'][family]['original']:
        x=sign*(F(x)-px);y=F(y)-py;points.append([(x,y),(-y,x),(-x,-y),(y,-x)][quarter])
    return tuple(sorted(tuple(sorted([a,b])) for a,b in zip(points,points[1:]+points[:1])))
def canonical_library(source):
    library=copy.deepcopy(source);records=[]
    for family,modes in library['family_modes'].items():
        groups={}
        for mode in modes:groups.setdefault((outline_key(source,family,mode),mode['cell_index']),[]).append(mode['mode'])
        for members in groups.values():
            originals=[source['family_modes'][family][i]['rectangle_mm'] for i in members];common=[max(r[0] for r in originals),max(r[1] for r in originals),min(r[2] for r in originals),min(r[3] for r in originals)];assert common[0]<common[2] and common[1]<common[3]
            # A cell index only proposes a group. Bound similarity is checked,
            # and its actual common subset makes every retained domain identical.
            assert max(abs(a[k]-b[k]) for a in originals for b in originals for k in range(4))<=4e-6
            for i in members:modes[i]['rectangle_mm']=common.copy();modes[i]['center_bounds_mm']=[[common[0],common[2]],[common[1],common[3]]]
            records.append({'family':family,'compound_modes':members,'source_rectangles':originals,'common_rectangle':common,'conservative_common_subset':True})
    return library,records
def family_classes(library):
    result={}
    for family,modes in library['family_modes'].items():
        seen=[];classes=[]
        for mode in modes:
            key=(outline_key(library,family,mode),tuple(map(F,mode['rectangle_mm'])))
            if key not in seen:seen.append(key)
            classes.append(seen.index(key))
        result[family]=classes
    return result
def physical_key(library,classes,modes):return tuple(classes[family][mode] for (family,_),mode in zip(library['identities'],modes))
