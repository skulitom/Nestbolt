"""Preserve exhaustive negative joint-selection evidence with no optimizer."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-weighted-joint-selection-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-weighted-joint-neighbors-20261107';F=BASE/'audit';D=F",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-cross-pair-boundary-preflight-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['optimizer_calls']==0 and not front['joint_strictly_improves_single'] and not front['H5_complete']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-weighted-joint-neighbors-preparation-process-20261107',ROOT/'output/h5-weighted-joint-neighbors-audit-process-20261107']",
"['*h5*mixed*mode*20261107.py']":"['*h5*weighted*joint*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_weighted_joint_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"
}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
preparation=load(ROOT/'output/h5-weighted-joint-neighbors-preparation-process-20261107/process.json');audit=load(ROOT/'output/h5-weighted-joint-neighbors-audit-process-20261107/process.json')
for process in [preparation,audit]:assert process['closed'] and process['passed'] and process['job']['closed'] and process['job']['active_processes']==0 and process['job']['root_exit_code']==0 and process['job']['peak_job_committed_memory']<2**31
assert not (BASE/'selected-model.json').exists() and not (BASE/'selected-state.json').exists() and not (BASE/'search').exists()
records=load(BASE/'neighbors.json');initial=records[0]['weighted_objective_mm2'];selection=load(BASE/'selection.json');assert selection['best_joint']['weighted_objective_mm2']>selection['best_single']['weighted_objective_mm2']>initial
copies=[(F/'checks.json','selection-audit.json'),(F/'enumeration-controls.json','enumeration-controls.json'),(BASE/'selection.json','selection.json'),(BASE/'closed-weighted-problems.json','closed-weighted-problems.json'),(BASE/'plan.json','frozen-plan.json'),(ROOT/'output/h5-weighted-joint-neighbors-preparation-process-20261107/process.json','preparation-process.json'),(ROOT/'output/h5-weighted-joint-neighbors-audit-process-20261107/process.json','audit-process.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),'baseline_weighted_objective_mm2':initial,'preparation_process_seconds':preparation['complete_seconds'],'audit_process_seconds':audit['complete_seconds'],'both_processes_closed':True,'selected_model_created':False,'new_optimizer_calls':0,'native_calls':0,'allocation_exclusions':0,**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'conditional_owner_center_relocation_preflight_required','finding':'All78 single and2775 two-owner physical-mode alternatives worsen the preserved weighted initializer when centers only clamp to their new bounds. This is not a statement about the interior of those hard cells. The strict joint-improvement prerequisite failed, so no optimizer/model was opened.','proposal':'Before considering any new optimizer, assess conditional center relocation within each changed owner mode on the same fixed9-by9 grid used by source preparation, plus its nearest-clamped center. Each trial scores that owner against all32 other originals at the unchanged source initializer, using exact original/clearance overlap and the audited weights. This differs from sequential greedy initialization because all33 original positions are already present, and from this checkpoint because centers can move inside their cells.','requirements':['Keep the unoptimized source initializer, initial weights, hard domains, geometry and actual cog angles. Include only physically changed owner modes; preserve and exclude all four closed weighted coefficient/mode problems. No optimized ancestor or timing validation point may seed this work.','Freeze the9-by9 grid and clamped-center control before scoring; do not refine it after results. At most78 alternative owner modes times82 nominal centers (6396 trials), with exact duplicate coordinates recorded. Full source validity is still a separate requirement.','For each owner-mode option select by complete weighted objective, then center coordinates. Score every one/two-owner proposal with selected centers, explicitly replacing their mutual interaction once. Reconstruct all528 weighted pair terms for each proposal; never rank by a partial pair score. Independently verify enumeration, centers, scores, duplicate handling and closed-key exclusions.','Compare best admissible relocated joint and single choices. If joint does not strictly improve single by more than1e-6mm², stop without optimization. If it does, separately preflight the selected model and finite search contract before any call; speed alone never reopens a closed problem.','Charge every consumed placement-preparation stage, including9.437443899689242s original preparation and this1.5178505999501795s stage if its results are used, plus all new preparation. Validation-only checks stay separate. No successor implementation or optimizer exists here.'],'new_optimizer_calls':0,'new_selector_prepared':False,'closed_calls_remain_closed':True,'H5_complete':False})
report=f'''# Weighted joint-selection preflight — 2026-11-07

The exhaustive two-owner mode comparison **does not meet its improvement
prerequisite**. The best joint choice scores613.576416mm² worse than the best
single choice; both score worse than the unoptimized initializer. No selected
model or optimizer is opened. This closes this proposed selection path without
changing any packing result. H2/H5 remain open at **60% completed milestone weight**.

## Complete physical-mode enumeration and full scores

The [frozen preflight]({NAME}/frozen-plan.json) uses the unchanged33-owner,
81-parameter original/clearance model and its audited initial pair weights.
It consumes only the preserved unoptimized source initializer. For a changed
mode, the owner center moves only as far as necessary to enter that mode's
hard bounds. Every other center and all15 actual cog angles stay fixed.

[Independent exact rational class reconstruction]({NAME}/enumeration-controls.json)
checks all147 owner/mode bindings. Brackets have10 physical choices, inserts
have3 choices represented by6 nominal modes, and cogs have one continuous-angle
mode. The exhaustive comparison includes the current vector, **78 single-owner
choices** and **2,775 two-owner choices**:1,215 bracket/bracket,1,296
bracket/insert and264 insert/insert. Equivalent current modes and aliases stay
explicit; no distinct full physical vector is duplicated.

The new selector caches exact intersections for each changed owner, replaces
the two changed owners' mutual interaction once, and sums **all528 weighted
pair losses** for every proposal. Each loss includes original and clearance
geometry. It uses no subtractive delta or partial-score ranking.
[Independent replay]({NAME}/selection-audit.json) transforms every source ring
and directly recomputes every complete score, without the cache. All **2,854
scores** agree within **1.74623e-10mm²**, below the frozen1e-6 tolerance.
Independent full-score ordering reproduces both best choices.

[All four closed weighted coefficient/physical-mode keys]({NAME}/closed-weighted-problems.json)
are reconstructed from their preserved models and responses. The current
initializer's problem is excluded; the other three old coefficient vectors
differ from the initial weights. Exclusion and physical alias checks apply
before ranking. Earlier weighted and unweighted calls remain closed.

## The improvement condition fails

| Choice | Weighted objective | Difference from initializer |
|---|---:|---:|
| Preserved initializer (closed problem) |244,566.416868mm²|—|
| Best admissible single change |244,973.051779mm²|+406.634911mm²|
| Best admissible two-owner change |245,586.628194mm²|+1,020.211327mm²|

[The best single]({NAME}/selection.json) changes insert7 (owner13) to mode2;
the best joint changes inserts7 and8 (owners13 and14) to mode2. These are
diagnostic alternatives, not accepted placements. The joint score is
**613.576416mm² worse** than the single score. The declared prerequisite
required a joint improvement greater than1e-6mm², so no selected-state/model
file or search directory is created. Conditional scalar/central model checks
are not run because no model is selected. No source-validity claim follows.

The [complete preparation wrapper]({NAME}/preparation-process.json) takes
**1.517851s**. With the entire consumed9.437444s original preparation, the
recorded preparation total is **10.955294s**. The separate
[validation wrapper]({NAME}/audit-process.json) takes48.647537s. Both bounded
Windows jobs close with no active processes, within their20/180s limits and
2GiB memory limits. The audit's peak committed memory is38,617,088bytes.
No optimizer, native call, allocation exclusion or source mutation occurs.

## Next geometry question and current state

The negative result applies to nearest-bound clamping. It does not establish
that those physical modes are worse at other centers inside their hard cells.
[The next preflight]({NAME}/next-step.json) assesses conditional center moves
on the existing fixed9-by9 source grid plus the clamped-center control, scoring
each changed owner against all other32 originals. Unlike the sequential source
initializer, all other original positions are already present during this
comparison. The grid may not be refined after viewing results. Any resulting
joint proposal must still beat the best single proposal and pass an independent
model/finite-accounting preflight before an optimizer could open.
No successor selector or optimizer is prepared in this checkpoint.

The preceding weighted search remains invalid, with49 source-pair failures
and28,207.754973mm² overlap. Four earlier fixed arrangements and440 allocations
remain unresolved. Product code, README claims and releases are unchanged.
[Main CI at review]({NAME}/main-ci-at-review.json) has five passed jobs and
Windows native checks running on d8aa6a90. Pending0af0c522, f03aadc1 and this
checkpoint await the ordinary push gate.

[Raw evidence manifest]({NAME}/raw-manifest.json),
[historical references]({NAME}/external-evidence.json),
[source bindings]({NAME}/source-bindings.json) and unchanged
[runtime pins]({NAME}/runtime-bindings.json) preserve all proposals, scores,
exclusions, scripts and closed processes. Runtime pins are checked at sealing;
this does not claim an additional before-run runtime check.
'''
# Keep prose readable without altering numerical evidence bytes.
for a,b in [('scores613','scores 613'),('416mm','416 mm'),('unchanged33','unchanged 33'),('all15','all 15'),('all147','all 147'),('have10','have 10'),('have3','have 3'),('by6','by 6'),('choices**:1','choices**: 1'),('bracket/bracket,1','bracket/bracket, 1'),('and264','and 264'),('all528','all 528'),('e-10mm','e-10 mm'),('frozen1','frozen 1'),('mm²|',' mm² |'),('|244','| 244'),('|245','| 245'),('|+','| +'),('|—|','| — |'),('insert7','insert 7'),('owner13','owner 13'),('mode2','mode 2'),('inserts7','inserts 7'),('and8','and 8'),('owners13','owners 13'),('and14','and 14'),('than1','than 1'),('e-6mm','e-6 mm'),('consumed9','consumed 9'),('takes48','takes 48'),('their20','their 20'),('is38','is 38'),('088bytes','088 bytes'),('fixed9','fixed 9'),('other32','other 32'),('with49','with 49'),('and28','and 28'),('973mm','973 mm'),('and440','and 440'),('Pending0','Pending 0')]:report=report.replace(a,b)
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 weighted joint-selection preflight:** [exhaustive independent replay]({link}) verifies 2,854 complete weighted scores: the current vector, 78 single-owner and 2,775 two-owner physical-mode alternatives. Exact class/domain reconstruction checks all 147 owner bindings; cached complete pair sums agree with independent original/clearance geometry within 1.747e-10 mm². All four closed weighted keys are checked and the current problem excluded. The best single alternative scores 244,973.051779 mm² and the best joint 245,586.628194 mm², both worse than the 244,566.416868 mm² initializer. The joint-improvement prerequisite fails by 613.576416 mm², so no selected model or optimizer opens. Complete preparation is 10.955294 s, including the entire new 1.517851 s stage; the independent audit takes 48.647537 s and both processes close. Next assess conditional centers on the unchanged 9-by-9 source grid against all other originals before any search; no successor exists. No native call, exclusion or source mutation follows. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. Main d8aa6a90 has five passed CI jobs and Windows native checks running at review; 0af0c522, f03aadc1 and this checkpoint await the ordinary push gate. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [weighted joint-selection preflight](../benchmarks/results/{NAME}.md).
Independent replay verifies all 2,854 weighted scores, 147 owner/mode bindings
and four closed problem keys. The best joint alternative is 613.576416 mm²
worse than the best single; both worsen the unchanged source initializer.
The declared improvement prerequisite fails, so no selected model or optimizer
opens. Complete preparation is 10.955294 s; both bounded processes close.
Next assess conditional centers on the existing 9-by-9 grid against all other
originals before any new search. No successor selector or optimizer exists.
The prior weighted search remains invalid: 49 source pair failures with
28,207.754973 mm² overlap. No native call or allocation exclusion follows.
Four earlier fixed arrangements and 440 allocations remain. H2/H5 stay at
60% completed milestone weight. Main d8aa6a90 has five passed CI jobs and
Windows native checks running at review. Pending 0af0c522, f03aadc1 and this
checkpoint await the ordinary push gate. Product code, README and releases
are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings),'new_optimizer_calls':0})
