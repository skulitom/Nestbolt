"""Independent physical classes, full scores, exclusions and selected geometry."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
import json,math,time
import numpy as np
from shapely.geometry import Polygon
from h5_cross_pair_weighted_model_20261107 import Objective
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'output/h5-weighted-mixed-rows-model-20261107';BASE=ROOT/'output/h5-weighted-joint-neighbors-20261107';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();plan=load(BASE/'plan.json');lib=load(W/'library.json');initial=load(W/'initial-state.json');modes=initial['modes'];values=initial['values'];weights=initial['pair_weights'];records=load(BASE/'neighbors.json');assert load(ROOT/'output/h5-weighted-joint-neighbors-preparation-process-20261107/process.json')['passed']
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
# Reconstruct exact transformed edge sets and domain classes without producer helpers.
classes={};class_controls=[]
for family,options in lib['family_modes'].items():
    seen=[];classes[family]=[]
    for mode in options:
        if family=='cog':edges=('continuous-cog',)
        else:
            quarter=round(mode['rotation_radians']/(math.pi/2))%4;assert abs(math.remainder(mode['rotation_radians']-quarter*math.pi/2,math.tau))<1e-12;cx,cy=map(F,lib['families'][family]['source_center']);sign=-1 if mode['mirrored'] else 1;points=[]
            for x,y in lib['families'][family]['original']:
                x=sign*(F(x)-cx);y=F(y)-cy
                for _ in range(quarter):x,y=-y,x
                points.append((x,y))
            edges=tuple(sorted(tuple(sorted((points[i],points[(i+1)%len(points)]))) for i in range(len(points))))
        bounds=tuple(F(a) for row in mode['center_bounds_mm'] for a in row);key=(edges,bounds)
        if key not in seen:seen.append(key)
        classes[family].append(seen.index(key))
    class_controls.append({'family':family,'nominal_modes':len(options),'classes':classes[family]})
assert classes=={'bracket':list(range(10)),'insert':[0,1,2,0,1,2],'cog':[0]}
opts={};aliases=[]
for i,(family,_) in enumerate(lib['identities']):
    seen={classes[family][modes[i]]:modes[i]};opts[i]=[]
    for mi,cls in enumerate(classes[family]):
        if cls in seen:kind='current' if cls==classes[family][modes[i]] else 'alias';rep=seen[cls]
        else:kind='new_physical_choice';rep=mi;seen[cls]=mi;opts[i].append(mi)
        aliases.append({'owner':i,'mode':mi,'class':cls,'representative':rep,'kind':kind})
assert aliases==load(BASE/'owner-aliases.json')
expected={()}|{((i,m),) for i in range(33) for m in opts[i]}|{((i,m),(j,n)) for i,j in combinations(range(33),2) for m,n in product(opts[i],opts[j])};assert len(expected)==2854 and expected=={tuple(map(tuple,r['changes'])) for r in records}
counts={'bracket/bracket':0,'bracket/insert':0,'insert/insert':0}
for r in records:
    if len(r['changes'])==2:
        families='/'.join(lib['identities'][i][0] for i,m in r['changes']);counts[families]+=1
assert counts=={'bracket/bracket':1215,'bracket/insert':1296,'insert/insert':264};write(OUT/'enumeration-controls.json',{'classes':class_controls,'owner_aliases_verified':len(aliases),'singles':78,'joint_families':counts,'complete_unique_vectors':2854})
def physical(chosen):return [classes[f][mi] for (f,_),mi in zip(lib['identities'],chosen)]
def weighted_key(chosen,ww):return sha256(json.dumps({'physical':physical(chosen),'weights':ww},separators=(',',':'),allow_nan=False).encode()).hexdigest()
closed=load(BASE/'closed-weighted-problems.json');assert len(closed)==4
for row in closed:
    folder=W/'search'/f'epoch-{row["epoch"]:02d}';mm=load(folder/'model.json');r=load(folder/'response.json');assert row['modes']==[o['mode'] for o in mm['owners']] and row['weights']==mm['pair_weights'] and row['physical_key']==physical(row['modes']) and row['key']==weighted_key(row['modes'],row['weights'])==r['key'] and r['closed']
closed_keys={r['key'] for r in closed}
def shapes(chosen,point):
    out=[]
    for i,(family,_) in enumerate(lib['identities']):
        mode=lib['family_modes'][family][chosen[i]];angle=point[66+i-18]/lib['angle_scale_mm'] if i>=18 else mode['rotation_radians'];c,s=math.cos(angle),math.sin(angle);sign=-1 if mode['mirrored'] else 1;cx,cy=lib['families'][family]['source_center'];tx=point[2*i]-(sign*cx*c-cy*s);ty=point[2*i+1]-(sign*cx*s+cy*c)
        out.append([Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in lib['families'][family][kind]]) for kind in ['original','clearance']])
    return out
def full_score(chosen,point):
    ps=shapes(chosen,point);return sum(w*sum(ps[i][k].intersection(ps[j][k]).area for k in [0,1]) for (i,j),w in zip(combinations(range(33),2),weights))
errors=[];keys=set();full_scores=[]
for sequence,row in enumerate(records):
    chosen=modes.copy();point=values.copy();assert sequence==row['sequence']
    for (i,mi),center in zip(row['changes'],row['centers']):
        chosen[i]=mi;bb=lib['family_modes'][lib['identities'][i][0]][mi]['center_bounds_mm'];expected_center=[min(hi,max(lo,values[2*i+k])) for k,(lo,hi) in enumerate(bb)];assert center==expected_center;point[2*i:2*i+2]=center
    key=weighted_key(chosen,weights);assert row['modes']==chosen and row['physical_key']==physical(chosen) and row['key']==key and key not in keys;keys.add(key);assert row['excluded']==(key in closed_keys) and row['exclusion_reason']==('closed_weighted_problem' if key in closed_keys else None)
    actual=full_score(chosen,point);error=abs(actual-row['weighted_objective_mm2']);assert error<plan['score_tolerance_mm2'],(sequence,actual,row['weighted_objective_mm2']);errors.append(error);full_scores.append({'sequence':sequence,'independent_weighted_score':actual,'absolute_error':error})
    if sequence%500==0:print({'verified_full_scores':sequence+1},flush=True)
write(OUT/'full-score-controls.json',full_scores)
selection=load(BASE/'selection.json');single=min((r for r in records if not r['excluded'] and len(r['changes'])==1),key=lambda r:(r['weighted_objective_mm2'],r['modes']));joint=min((r for r in records if not r['excluded'] and len(r['changes'])==2),key=lambda r:(r['weighted_objective_mm2'],r['modes']));assert selection['best_single']==single and selection['best_joint']==joint
for selected,size in [(single,1),(joint,2)]:
    independent=min((r for r in records if not r['excluded'] and len(r['changes'])==size),key=lambda r:(full_scores[r['sequence']]['independent_weighted_score'],r['modes']))
    assert selected['sequence']==independent['sequence'],('independent ranking differs',size,selected['sequence'],independent['sequence'])
improvement=full_scores[single['sequence']]['independent_weighted_score']-full_scores[joint['sequence']]['independent_weighted_score'];assert selection['joint_strictly_improves_single']==(improvement>plan['strict_joint_improvement_mm2'])
derivatives=[];scalar_terms=0;scalar_error=None
if selection['joint_strictly_improves_single']:
    mm=load(BASE/'selected-model.json');state=load(BASE/'selected-state.json');chosen=state['modes'];point=state['values'];assert state['key']==joint['key'] not in closed_keys and chosen==joint['modes'] and state['pair_weights']==weights
    obj=Objective(mm);value,g=obj.evaluate(point);assert abs(value-full_score(chosen,point))<1e-6;ps=shapes(chosen,point);reference=np.zeros(81)
    for index,(i,j) in enumerate(combinations(range(33),2)):
        for k in [0,1]:
            if ps[i][k].intersection(ps[j][k]).area<=0:continue
            for own,other in [(i,j),(j,i)]:
                gg,_,_=moving_boundary_gradient(ps[own][k],ps[other][k],point[2*own:2*own+2]);reference[2*own:2*own+2]+=weights[index]*gg[:2]
                if own>=18:reference[66+own-18]+=weights[index]*gg[2]/lib['angle_scale_mm']
                scalar_terms+=1
    scalar_error=float(np.max(np.abs(g-reference)));assert scalar_error<1e-7
    bb=np.asarray(mm['bounds']);margin=.03+np.arange(81)*.00037;interior=np.clip(np.asarray(point)+.137*np.sin(np.arange(81)*2**.5+.2),bb[:,0]+margin,bb[:,1]-margin);value,gg=obj.evaluate(interior)
    for coordinate in range(81):
        for step in [1e-5,1e-6]:
            plus=interior.copy();minus=interior.copy();plus[coordinate]+=step;minus[coordinate]-=step;numeric=(full_score(chosen,plus)-full_score(chosen,minus))/(2*step);error=abs(numeric-gg[coordinate]);assert error<.02+3e-6*abs(gg[coordinate]);derivatives.append({'coordinate':coordinate,'step':step,'analytic':float(gg[coordinate]),'numeric':numeric,'error':float(error)})
write(OUT/'selected-derivative-controls.json',derivatives)
process=load(ROOT/'output/h5-weighted-joint-neighbors-preparation-process-20261107/process.json');charge=load(W/'audit-v2/checks.json')['complete_preparation_seconds']+process['complete_seconds'];inputs=dict(plan['inputs'])
for p in [Path(__file__),BASE/'plan.json',ROOT/'output/h5-weighted-joint-neighbors-preparation-process-20261107/process.json']+list(BASE.glob('*.json')):inputs[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':inputs,'method':'Independent exact rational physical classes and aliases; exhaustive full geometry score for all2854 proposals, explicit closed keys and independent rankings. Independent scalar gradient and81-coordinate/two-step central controls on selected model. No optimizer.','optimizer_calls':0});write(OUT/'source-bindings.json',inputs)
checks={'passed':True,'seconds':time.perf_counter()-start,'complete_scores':2854,'single_neighbors':78,'joint_neighbors':2775,'joint_family_counts':counts,'weighted_pair_terms_per_score':528,'closed_weighted_keys':4,'excluded_choices':sum(r['excluded'] for r in records),'maximum_full_score_error_mm2':max(errors),'joint_strictly_improves_single':selection['joint_strictly_improves_single'],'joint_improvement_mm2':improvement,'best_single_mm2':single['weighted_objective_mm2'],'best_joint_mm2':joint['weighted_objective_mm2'],'selected_changes':joint['changes'],'selected_scalar_terms':scalar_terms,'selected_scalar_error':scalar_error,'central_samples':len(derivatives),'maximum_central_error':max((r['error'] for r in derivatives),default=0.),'complete_preparation_seconds':charge,'optimizer_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
