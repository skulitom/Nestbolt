"""Independent original geometry for the new insert-plus-nine-cog source witness."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon,shape
from shapely.affinity import affine_transform,translate
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';REG=ROOT/'output/h5-expanded-cog-neighborhood-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';GROUP=ROOT/'output/h5-selected-family-groups-20261026/response-audit';PAIR=ROOT/'output/h5-selected-pair-census-20261026/response-audit';SELECT=ROOT/'output/h5-conditional-domain-master-search-20261026/selection-audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-insert-cog-partial64-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();inputs=[JOB,SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',REG/'fixed-originals.json',REG/'audit/checks.json',SRC/'items.json',SRC/'geometry.json',GROUP/'checks.json',GROUP/'verified-subset-witnesses.json',PAIR/'checks.json',PAIR/'verified-pair-witnesses.json',SELECT/'checks.json',SELECT/'verified-domain-selection.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Combine the independently read-back first-sheet insert/seven-cog witness with the separately verified second-sheet two-cog witness. Reconstruct all54 fixed plus10 moving original job polygons including every cutout, with only declared source orientations. Independently check original/profile reconstruction, identities/copies, all same-sheet pairs and all stock edges against unchanged native guards. Also directly verify every selected source-domain plane and every moving same-sheet guarded pair face. Missing originals28/29 remain mandatory; this64-original partial is not native/full/material acceptance. No solver/native call.'});assert all(load(p)['passed'] for p in [SOURCE/'audit/checks.json',REG/'audit/checks.json',GROUP/'checks.json',PAIR/'checks.json',SELECT/'checks.json']);selection=load(SELECT/'verified-domain-selection.json')['movable_parts'];w=load(GROUP/'verified-subset-witnesses.json');assert len(w)==1 and w[0]['subset']==2;w=w[0];assert [p['part'] for p in w['selection']]==[2,3,4,5,6,7,8,9];second=next(r for r in load(PAIR/'verified-pair-witnesses.json') if r['pair']==45);assert second['parts']==[10,11];positions={p['part']:{**p,'x_units':w['coordinates_units1000'][2*i],'y_units':w['coordinates_units1000'][2*i+1]} for i,p in enumerate(w['selection'])}
for j,pi in enumerate([10,11]):positions[pi]={**selection[pi],'x_units':second['coordinates_units1000'][2*j],'y_units':second['coordinates_units1000'][2*j+1]}
assert set(positions)==set(range(2,12));spec=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');inside=sourcefaces=0
for pi,p in positions.items():
    assert {k:p[k] for k in selection[pi]}==selection[pi];d=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']];assert d['index']==p['domain_index'];x,y=p['x_units'],p['y_units'];b=d['coordinate_bounds'];assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
    for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];inside+=1
for a,b in combinations(positions.values(),2):
    if a['sheet']!=b['sheet']:continue
    case=next(c['index'] for c in spec['mutual_cases'] if (c['profile_a'],c['profile_b'])==(a['profile'],b['profile']));dx=b['x_units']-a['x_units'];dy=b['y_units']-a['y_units']
    for face in load(SOURCE/'mutual'/f'{case:03d}.json')['faces']:assert any(h['a']*dx+h['b']*dy>=h['bound'] for h in face['outside_halfplanes']);sourcefaces+=1
job=load(JOB);families={p['id']:p for p in job['parts']};items=load(SRC/'items.json');fixed={p['item']:p for p in load(REG/'fixed-originals.json')};moving={p['item']:p for p in positions.values()};assert len(fixed)==54 and len(moving)==10 and set(fixed).isdisjoint(moving) and set(fixed)|set(moving)==set(range(66))-{28,29};stocks=[[float(F(*v)) for v in b] for b in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);polys={};records=[];placements=[];holes=vertices=0;maxerror=0
for i in sorted(set(fixed)|set(moving)):
    family=items[i]['family'];g=families[family]['geometry'][0]
    if i in fixed:t=fixed[i]['transform'];sheet=fixed[i]['sheet'];expected=shape(fixed[i]['geometry'])
    else:
        p=moving[i];profile=profiles[p['profile']];sheet=p['sheet'];angle=profile['rotation_radians'];mirror=profile['mirrored'];c,s=math.cos(angle),math.sin(angle);mi=-1 if mirror else 1;x,y=p['x_units']/1000,p['y_units']/1000
        if family=='cog':cx,cy=profile['original_center'];tx=x-c*cx+s*cy;ty=y-s*cx-c*cy
        else:pts=[(mi*a*c-b*s,mi*a*s+b*c) for a,b in g['outer']];tx=x-min(a for a,b in pts);ty=y-min(b for a,b in pts)
        t={'rotation_radians':angle,'mirrored':mirror,'translation':[tx,ty]};expected=translate(shape(profile['geometry']),x,y)
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;matrix=[mi*c,-s,mi*s,c,*t['translation']];poly=affine_transform(Polygon(g['outer']),matrix);cut=affine_transform(Polygon(g['outer'],g.get('holes',[])),matrix);assert poly.is_valid and cut.is_valid and cut.exterior.equals(poly.exterior) and len(cut.interiors)==len(g.get('holes',[]));error=poly.hausdorff_distance(expected);assert error<1e-7;maxerror=max(maxerror,error);holes+=len(cut.interiors);vertices+=sum(len(h) for h in g.get('holes',[]));polys[i]=poly;records.append({'item':i,'family':family,'copy':items[i]['copy'],'sheet':sheet,'fixed':i in fixed});placements.append({'part_id':family,'copy_index':items[i]['copy'],'sheet_id':f'sheet-{sheet}','transform':t})
assert Counter(r['family'] for r in records)=={'frame':18,'bracket':10,'insert':21,'cog':15};pairs=[];stock=[]
for a,b in combinations(records,2):
    if a['sheet']!=b['sheet']:continue
    pa,pb=polys[a['item']],polys[b['item']];distance=pa.distance(pb);area=pa.intersection(pb).area;assert area==0 and distance>gap,(a['item'],b['item'],distance);pairs.append({'items':[a['item'],b['item']],'distance_mm':distance,'intersection_mm2':area})
for r in records:
    b=polys[r['item']].bounds;st=stocks[r['sheet']];margins=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(margins)>guard;stock.append({'item':r['item'],'extra_margins_mm':margins})
assert len(pairs)==1521 and len(stock)==64;write(OUT/'verified-moving-anchors.json',list(positions.values()));write(OUT/'partial64-placements.json',placements);write(OUT/'original-pair-checks.json',pairs);write(OUT/'original-stock-checks.json',stock);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_parts_in_partial':64,'fixed_originals':54,'moving_originals':10,'missing_required_originals':[28,29],'original_cutouts_preserved':holes,'original_cutout_vertices_preserved':vertices,'original_pairs_checked':len(pairs),'stock_edges_checked':256,'minimum_pair_gap_mm':min(p['distance_mm'] for p in pairs),'native_guarded_pair_gap_mm':gap,'maximum_original_profile_error_mm':maxerror,'source_inside_planes_checked':inside,'source_full_face_clauses_checked':sourcefaces,'fixed54_transforms_unchanged':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
