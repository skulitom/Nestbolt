"""Prepare distinct full-source coordinate subproblem helpers for the new selection."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('prepare_h5_selected_expanded_model.py','prepare_h5_conditional_selected_model.py'),('audit_h5_selected_expanded_model.py','audit_h5_conditional_selected_model.py'),('run_h5_selected_expanded_search.py','run_h5_conditional_selected_search.py'),('audit_h5_selected_expanded_search.py','audit_h5_conditional_selected_search.py')]:
    s=(ROOT/'output'/source).read_text()
    s=s.replace('h5-selected-expanded-model-20261026','h5-conditional-selected-model-20261026').replace('h5-selected-expanded-search-20261026','h5-conditional-selected-search-20261026').replace('h5-expanded-domain-master-search-20261026','h5-conditional-domain-master-search-20261026')
    if target=='audit_h5_conditional_selected_search.py':
        old="[PREP/n for n in ['model.pb','mapping.json','necessary-rules.json','audit/checks.json']]";assert old in s;s=s.replace(old,"[PREP/n for n in ['model.pb','mapping.json','audit/checks.json']]+[ROOT/'output/h5-projected-expanded-model-20261026/necessary-rules.json']");s=s.replace("rules=load(PREP/'necessary-rules.json')","rules=load(ROOT/'output/h5-projected-expanded-model-20261026/necessary-rules.json')")
    with (ROOT/'output'/target).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
