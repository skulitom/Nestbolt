"""Create one bounded caller and independent selection readback for the new raw rule."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('run_h5_expanded_domain_master.py','run_h5_conditional_domain_master.py'),('audit_h5_expanded_domain_selection.py','audit_h5_conditional_domain_selection.py')]:
    text=(ROOT/'output'/source).read_text()
    for a,b in [('h5-expanded-domain-master-search-20261026','h5-conditional-domain-master-search-20261026'),('h5-expanded-domain-master-20261026','h5-conditional-domain-master-20261026'),('9793','9794')]:assert a in text;text=text.replace(a,b)
    if source.startswith('run_'):
        text=text.replace("assert load(PREP/'audit/checks.json')['every_variable_and_constraint_reconstructed']","assert load(PREP/'audit/checks.json')['complete_parent_retained_exactly'] and load(PREP/'audit/checks.json')['fresh_raw_certificate_exactly_replayed']")
        text=text.replace('fresh capacity2 and independently certified copy ordering.','fresh capacity2, independently certified copy ordering and one raw-geometry conditional capacity: insert query16 row0 permits at most one cog in query18 row3. Every parent constraint and all36 hints retained.')
        text=text.replace('One necessary-master call, at most20solver seconds','One distinct necessary-master call after adding the independently raw-proved three-part capacity inequality, at most20solver seconds')
    else:
        anchor="        census=load(CONFLICTS/'plan.json');"
        assert anchor in text
        text=text.replace(anchor,"        insert_selected=parts[2]['query']==16 and parts[2]['domain_row']==0;selected_cogs=sum(p['query']==18 and p['domain_row']==3 for p in parts[3:]);assert not insert_selected or selected_cogs<=1\n        write(OUT/'selected-raw-capacity-check.json',{'insert_in_certified_domain':insert_selected,'cogs_in_certified_domain':selected_cogs,'passed':True})\n"+anchor)
    with (ROOT/'output'/target).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
