"""Exact-rational whole-rectangle containment proof against raw original boundaries."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';BASE=ROOT/'output/h5-selected-triple-collision-certificate-20261026';CAP=ROOT/'output/h5-expanded-second-sheet-capacity-20261026';OUT=ROOT/'output/h5-conditional-domain-master-20261026/certificate-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Independent proof using exact binary-rational raw polygon vertices and integer boxes, without Shapely or solving. Recheck all258.082mm disk boundary distances and ray containment at the origin; derive strict integer squared separation. Verify the integer horizontal square root, ordering boxes and exhaustive insert partition. For each complete signed difference box, clip every raw insert/cog polygon boundary segment against its closed rectangle using exact rational intervals: no intersection allowed. Exact ray parity at its center must be odd. A connected closed rectangle with an interior point and no boundary intersection lies wholly in the raw collision interior. Reconstruct all eligible current domains and identical-copy inventories. No inference from a solver negative is needed.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
known=set()
for name in ['h5-expanded-cog-neighborhood-20261026','h5-expanded-source-search-20261026','h5-projected-source-and-fresh-conflicts-20261026']:
    m=load(ROOT/'benchmarks/results'/name/'raw-manifest.json');known.update(r['sha256'] for r in m['files']+m['aliases'])
for p in [SOURCE/'mutual/080.json',SOURCE/'mutual/081.json',SOURCE/'queries/016.json',SOURCE/'queries/018.json',CAP/'certificate.json']:assert digest(p) in known
def polygon(case):
    raw=load(SOURCE/'mutual'/f'{case:03d}.json')['raw_forbidden'];assert raw['type']=='Polygon' and len(raw['coordinates'])==1;return [[F(x),F(y)] for x,y in raw['coordinates'][0]]
def parity(points,p):
    crossings=0
    for a,b in zip(points,points[1:]):
        if (a[1]>p[1])!=(b[1]>p[1]):
            x=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1]);assert x!=p[0]
            crossings+=x>p[0]
    return crossings%2
pts=polygon(81);assert parity(pts,[F(0),F(0)])==1;radius=F(258082,1000);minimum=None
for a,b in zip(pts,pts[1:]):
    dx,dy=b[0]-a[0],b[1]-a[1];norm=dx*dx+dy*dy
    if not norm:continue
    projection=-(a[0]*dx+a[1]*dy)
    if projection<=0:dist=a[0]*a[0]+a[1]*a[1]
    elif projection>=norm:dist=b[0]*b[0]+b[1]*b[1]
    else:dist=(a[0]*b[1]-a[1]*b[0])**2/norm
    assert dist>radius**2;minimum=dist if minimum is None else min(minimum,dist)
cap=load(CAP/'certificate.json');assert [minimum.numerator,minimum.denominator]==cap['minimum_exact_boundary_distance_squared_mm2'];required=258082**2+1;assert required==cap['required_integer_squared_distance_units'];cert=load(BASE/'certificate.json');insert=load(SOURCE/'queries/016.json')['domains'];cogs=load(SOURCE/'queries/018.json')['domains'];ib=insert[0]['coordinate_bounds'];cb=cogs[3]['coordinate_bounds'];assert cert['insert_box_units1000']==ib and cert['cog_box_units1000']==cb;dy=cb[3]-cb[1];sep=cert['required_cog_horizontal_separation_units'];assert (sep-1)**2+dy**2<required<=sep**2+dy**2;left=[cb[0],cb[1],cb[2]-sep,cb[3]];right=[cb[0]+sep,cb[1],cb[2],cb[3]];assert left==cert['ordered_cog_left_box_units1000'] and right==cert['ordered_cog_right_box_units1000'];mid=(ib[0]+ib[2])//2;halves=[[ib[0],ib[1],mid,ib[3]],[mid+1,ib[1],ib[2],ib[3]]];assert halves==cert['insert_integer_partition'];raw=polygon(80);segments=0;details=[]
for i,(a,b,row) in enumerate(zip(halves,[left,right],cert['collision_cases'])):
    delta=[b[0]-a[2],b[1]-a[3],b[2]-a[0],b[3]-a[1]];assert row['insert_half']==i and row['insert_box_units1000']==a and row['cog_box_units1000']==b and row['difference_box_units1000']==delta;rect=[F(v,1000) for v in delta];center=[(rect[0]+rect[2])/2,(rect[1]+rect[3])/2];assert parity(raw,center)==1
    for u,v in zip(raw,raw[1:]):
        lo,hi=F(0),F(1);possible=True
        for axis in range(2):
            dv=v[axis]-u[axis]
            if dv==0:
                if not rect[axis]<=u[axis]<=rect[axis+2]:possible=False;break
            else:
                t0=(rect[axis]-u[axis])/dv;t1=(rect[axis+2]-u[axis])/dv;lo=max(lo,min(t0,t1));hi=min(hi,max(t0,t1))
        assert not possible or lo>hi,('raw boundary meets box',i,u,v);segments+=1
    details.append({'box':i,'raw_boundary_segments_exactly_excluded':len(raw)-1,'center_exact_parity':1,'whole_closed_box_in_raw_interior':True})
def contained(b,a):return all(a[k]<=b[k] for k in [0,1]) and all(b[k]<=a[k] for k in [2,3])
ir=[i for i,d in enumerate(insert) if contained(d['coordinate_bounds'],ib)];cr=[i for i,d in enumerate(cogs) if contained(d['coordinate_bounds'],cb)];assert ir==cert['insert_domain_rows'] and cr==cert['cog_domain_rows'];assert [insert[i]['index'] for i in ir]==cert['insert_domain_indices'] and [cogs[i]['index'] for i in cr]==cert['cog_domain_indices'];spec=load(SOURCE/'plan.json');assert cert['applicable_insert_parts']==[p['part'] for p in spec['parts'] if p['family']=='insert' and 16 in p['queries']]==[2];assert cert['applicable_cog_parts']==[p['part'] for p in spec['parts'] if p['family']=='cog' and p['profiles']==[9] and 18 in p['queries']]==list(range(3,12));assert cert['required_cog_squared_separation_units']==required and cert['max_cog_y_separation_units']==dy
write(OUT/'exact-box-checks.json',details);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_disk_segments_rechecked':len(pts)-1,'raw_insert_cog_segment_box_checks':segments,'entire_raw_collision_boxes_certified':2,'integer_separation_and_exhaustive_partition_verified':True,'insert_domains':len(ir),'cog_domains':len(cr),'applicable_physical_cog_pairs':36,'copy_label_invariant':True,'no_dependence_on_solver_infeasibility':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
