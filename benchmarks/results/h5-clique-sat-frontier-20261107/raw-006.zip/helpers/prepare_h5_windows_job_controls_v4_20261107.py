from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/'output/h5_windows_job_runner_v3_20261107.c').read_text(encoding='utf-8')
text=text.replace('        if (GetFileAttributesW(argv[6]) != INVALID_FILE_ATTRIBUTES) reason = 2;',
'        if (!QueryInformationJobObject(job, JobObjectExtendedLimitInformation, &peak, sizeof(peak), NULL)) { failure = GetLastError(); break; }\n        if (peak.PeakJobMemoryUsed > memory_bytes) reason = 3;\n        else if (GetFileAttributesW(argv[6]) != INVALID_FILE_ATTRIBUTES) reason = 2;')
with (ROOT/'output/h5_windows_job_runner_v4_20261107.c').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
text=(ROOT/'output/check_h5_windows_job_runner_v3_20261107.py').read_text(encoding='utf-8')
text=text.replace('h5-windows-job-controls-v3-20261107','h5-windows-job-controls-v4-20261107').replace('h5_windows_job_runner_v3_20261107.c','h5_windows_job_runner_v4_20261107.c')
text=text.replace("'aggregate-memory-denial'","'conservative-memory-stop','two-child-memory-positive'")
text=text.replace("('memory','memory-parent',10000,128*1024*1024)]", "('memory','memory-parent',10000,128*1024*1024),('memory-positive','memory-parent',10000,256*1024*1024)]")
text=text.replace("assert job['limit_flags']==0x2200 and job['job_committed_memory_limit']==mem and job['peak_job_committed_memory']<=mem", "assert job['limit_flags']==0x2200 and job['job_committed_memory_limit']==mem\n    if name!='memory':assert job['peak_job_committed_memory']<=mem")
start=text.index('    else:\n        children=')
end=text.index("write('checks.json'",start)
text=text[:start]+'''    elif name=='memory':
        assert r.returncode==124 and job['reason_code']==3 and job['peak_job_committed_memory']>mem
    else:
        children=[json.loads((folder/f'memory-{i}.json').read_bytes()) for i in range(2)]
        assert r.returncode==0 and job['reason_code']==0 and all(c['allocated'] for c in children)
        assert job['peak_job_committed_memory']>160*1024*1024
'''+text[end:]
text=text.replace("'aggregate_committed_memory_enforced':True", "'OS_aggregate_memory_limit_configured':True,'conservative_peak_counter_stop_verified':True,'peak_counter_is_not_claimed_to_measure_only_successful_allocations':True")
with (ROOT/'output/check_h5_windows_job_runner_v4_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
with (ROOT/'output/h5-windows-job-memory-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'preserved_control':'output/h5-windows-job-controls-v3-20261107/memory','configured_limit':134217728,'reported_peak':204427264,'observed_application_results':'One80MiB allocation succeeds and the other raises MemoryError. The reported job peak exceeds the limit; its precise accounting cause is not established.','failed_assertion_preserved':'peak_job_committed_memory <= configured_limit','versioned_change':'Keep the Windows job memory limit and additionally terminate the entire job whenever its aggregate peak counter exceeds the frozen cap. This is conservative even if rejected allocation attempts contribute to the counter. No result above the counter cap qualifies. Add a256MiB positive control where both80MiB children must succeed.','research_calls':0},f,indent=2);f.write('\n')
