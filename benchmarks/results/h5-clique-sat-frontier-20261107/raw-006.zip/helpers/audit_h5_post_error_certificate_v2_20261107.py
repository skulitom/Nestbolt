"""First independent check of a stable certificate from a failed producer.
The failed process and original rejection remain unchanged. This is a theorem
check only; it cannot turn that execution into a successful benchmark run.
"""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,subprocess
from h5_drat_text_20261107 import to_text
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-post-error-certificate-v2-20261107';OUT.mkdir()
M=ROOT/'output/h5-first57-clique-sat-batch-10-model-20261107';C=ROOT/'output/h5-first57-clique-sat-batch-10-call-20261107';OLD=ROOT/'output/h5-first57-clique-sat-batch-10-result-audit-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
plan=load(M/'plan.json');ma=load(M/'audit.json');sr=load(C/'result.json');process=load(C/'process.json');original=load(OLD/'checks.json');job=process['job'];raw=C/'proof.drat.bin'
assert ma['passed'] and original['solver_status']=='UNSAT' and not original['valid_complete_process'] and not original['proof_verified']
assert not (OLD/'checker-opened.json').exists() and not (OLD/'checker-process.json').exists()
assert process['closed'] and job['active_processes']==0 and process['limit_reason'] is None and process['complete_process_cap_overrun_seconds']==0
assert job['error_code']==job['reason_code']==0 and job['root_exit_code']==3221226505 and process['exit_code']==126
assert job['peak_job_committed_memory']<=plan['solver_aggregate_committed_memory_bytes'] and sr['search_seconds']<=plan['solver_search_seconds']
assert sr['proof_bytes']<=raw.stat().st_size<=plan['binary_proof_byte_limit']
assert sha256((M/'model.cnf').read_bytes()).hexdigest()==ma['model_sha256']==sr['model_sha256']
paths=[M/'model.cnf',M/'plan.json',M/'audit.json',C/'process.json',C/'job.json',C/'result.json',raw,OLD/'checks.json',Path(__file__)]
write('plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in paths},'source_selection':plan['source_selection'],'checker_seconds':60,'checker_complete_process_seconds':70,'first_checker_attempt_for_this_certificate':True,'research_search_repeated':False,'producer_success_claimed':False,'reported_pre_destructor_proof_bytes':sr['proof_bytes'],'actual_closed_file_bytes':raw.stat().st_size,'full_job_construction_claimed':False,'rule':'A source-necessary formula plus independently verified complete DRAT certificate proves the fixed-arrangement contradiction regardless of the untrusted generator exit status. Preserve its nonzero exit and original failed audit; never count that execution as a successful timed construction. No process or checker has been rerun.'})
start=time.perf_counter();data=raw.read_bytes();text=to_text(data);(OUT/'proof.drat.txt').write_bytes(text)
checker=ROOT/'output/h5-sat-tools-20261107/drat-trim.exe';controls=load(ROOT/'output/h5-sat-controls-v2-20261107/checks.json')
assert controls['passed'] and sha256(checker.read_bytes()).hexdigest()==controls['checker_sha256']
write('conversion.json',{'binary_sha256':sha256(data).hexdigest(),'text_sha256':sha256(text).hexdigest(),'binary_bytes':len(data),'text_bytes':len(text),'exact_round_trip_passed':True,'seconds':time.perf_counter()-start})
args=[str(checker),str(M/'model.cnf'),str(OUT/'proof.drat.txt'),'-t','60']
write('checker-opened.json',{'command':args,'checker_sha256':controls['checker_sha256'],'formula_sha256':ma['model_sha256'],'proof_sha256':sha256(text).hexdigest(),'maximum_process_seconds':70,'retry_permitted':False})
t=time.perf_counter()
try:
    r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=70);stdout,stderr=r.stdout,r.stderr;rc=r.returncode;timeout=False
except subprocess.TimeoutExpired as e:stdout,stderr=e.stdout or b'',e.stderr or b'';rc=None;timeout=True
elapsed=time.perf_counter()-t;verified=rc==0 and not timeout and elapsed<=70 and any(line.strip()==b's VERIFIED' for line in stdout.splitlines())
(OUT/'checker-stdout.txt').write_bytes(stdout);(OUT/'checker-stderr.txt').write_bytes(stderr)
write('checker-process.json',{'closed':True,'exit_code':rc,'timeout':timeout,'complete_seconds':elapsed,'process_cap_overrun_seconds':max(0,elapsed-70),'verified':verified})
result={'passed':True,'proof_verified':verified,'source_selection':plan['source_selection'],'new_fixed_arrangement_exclusion':int(verified),'source_formula_sha256':ma['model_sha256'],'producer_success':False,'producer_failure_preserved':True,'original_audit_preserved':True,'search_calls':0,'first_independent_checker_attempt':True,'source_valid_placements':0,'scope':'Only a mathematical fixed29/current-cog exclusion at original0.2mm clearance if proof verified. No new zero-clearance claim or full-job budget/benchmark success.'}
write('checks.json',result);print(result)
