#include <stdio.h>
#include <stdint.h>
int wmain(int argc, wchar_t **argv) {
    if (argc!=2) return 64;
    FILE *f=_wfopen(argv[1],L"rb"); if(!f)return 65;
    unsigned long long position=0,records=0,adds=0,deletes=0,empty_end=0;
    const char *error="none";int op;
    while((op=fgetc(f))!=EOF) {
        position++;
        if(op!='a' && op!='d'){error="invalid-operation";break;}
        unsigned int literals=0;
        for(;;) {
            uint64_t value=0;unsigned int shift=0;int b;
            for(;;) {
                b=fgetc(f);
                if(b==EOF){error="truncated-varint";goto done;}
                position++;
                if(shift>28){error="oversized-varint";goto done;}
                value|=((uint64_t)(b&127))<<shift;shift+=7;
                if(b<128)break;
            }
            if(!value)break;
            if(value<2){error="invalid-literal";goto done;}
            literals++;
        }
        records++;adds+=op=='a';deletes+=op=='d';
        if(op=='a' && !literals){empty_end=position;break;}
    }
done:
    fclose(f);
    printf("{\"scanned_bytes\":%llu,\"first_empty_end\":%llu,\"records\":%llu,\"additions\":%llu,\"deletions\":%llu,\"parse_error\":\"%s\"}\n",position,empty_end,records,adds,deletes,error);
    return 0;
}
