from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
names=['prepare_h5_clique_sat_model_20261107.py','audit_h5_clique_sat_model_20261107.py','solve_h5_clique_sat_20261107.py','run_h5_clique_sat_20261107.py','audit_h5_clique_sat_result_20261107.py']
renamed={n:n.replace('_20261107.py','_earlier_20261107.py') for n in names}
for name in names:
    text=(ROOT/'output'/name).read_text(encoding='utf-8')
    text=text.replace('h5-first57-clique-sat-model-20261107','h5-first57-earlier-cover-clique-sat-model-20261107').replace('h5-first57-clique-sat-call-20261107','h5-first57-earlier-cover-clique-sat-call-20261107').replace('h5-first57-clique-sat-result-audit-20261107','h5-first57-earlier-cover-clique-sat-result-audit-20261107')
    for before,after in renamed.items():text=text.replace(before,after)
    if name.startswith('prepare_'):
        text=text.replace('h5-first57-frontier-refined-graphs-v2-20261106/choice-02','h5-first57-refined-conflict-graph-20261106')
        text=text.replace("gc=load(G/'checks.json');nodes=", "gc=load(G/'checks.json');gc['source_selection']=load(ROOT/'output/h5-first57-refined-anchor-tree-20261106/plan.json')['source_selection'];nodes=")
        text=text.replace('root-covers.json','initial-covers.json').replace("G.parent/'audit/checks.json'", "G/'audit/checks.json',G/'plan.json',ROOT/'output/h5-first57-refined-anchor-tree-20261106/plan.json'")
        text=text.replace('[0,5,11]','[4,5,10]').replace('==2135','==2427')
    if name=='audit_h5_clique_sat_result_20261107.py':
        text=text.replace("ROOT/'output/h5-first57-frontier-refined-trees-20261106/audit/remaining-fixed29-choices.json'", "ROOT/'output/h5-first57-clique-sat-batch-20261107/audit/remaining-fixed29-choices.json'")
    with (ROOT/'output'/renamed[name]).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print(renamed)
