from pathlib import Path
from hashlib import sha256
import json,time,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-windows-job-external-stop-20261107';OUT.mkdir()
EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/h5-sat-venv-20261106/Scripts/python.exe';WORKER=ROOT/'output/h5_job_control_worker_20261107.py'
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
args=[str(EXE),'10000',str(512*1024*1024),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(WORKER),'timeout-parent',str(OUT)]),str(ROOT),'version4']
write('plan.json',{'command':args,'runner_sha256':sha256(EXE.read_bytes()).hexdigest(),'maximum_control_seconds':15,'trigger':'Create stop marker after the grandchild has written its PID file.','research_calls':0})
start=time.perf_counter();p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
    while not (OUT/'sleep-child.json').exists():
        assert p.poll() is None and time.perf_counter()-start<8;time.sleep(.02)
    write('stop',{'reason':'external-stop-control'})
    stdout,stderr=p.communicate(timeout=6)
finally:
    if p.poll() is None:p.kill();p.wait()
(OUT/'runner-stdout.txt').write_bytes(stdout);(OUT/'runner-stderr.txt').write_bytes(stderr)
job=json.loads((OUT/'job.json').read_bytes());assert p.returncode==124 and job['error_code']==0 and job['reason_code']==2 and job['closed'] and job['active_processes']==0 and job['total_processes']>=4
write('checks.json',{'passed':True,'runner_exit_code':p.returncode,'job':job,'seconds':time.perf_counter()-start,'research_calls':0});print('External stop control passed')
