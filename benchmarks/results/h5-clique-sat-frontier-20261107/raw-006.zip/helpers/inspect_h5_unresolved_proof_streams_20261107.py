from pathlib import Path
from hashlib import sha256
import subprocess,time,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-unresolved-proof-prefixes-20261107';OUT.mkdir();SRC=ROOT/'output/h5_binary_drat_prefix_20261107.c';EXE=OUT/'prefix-parser.exe'
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
args=['C:/msys64/mingw64/bin/gcc.exe',str(SRC),'-std=c11','-O2','-Wall','-Wextra','-Werror','-municode','-o',str(EXE)]
r=subprocess.run(args,capture_output=True,timeout=60);(OUT/'build-stdout.txt').write_bytes(r.stdout);(OUT/'build-stderr.txt').write_bytes(r.stderr);write('build.json',{'command':args,'exit_code':r.returncode,'source_sha256':sha256(SRC.read_bytes()).hexdigest()});assert r.returncode==0,r.stderr.decode()
# Check parser boundaries against the earlier independent Python inspection and known valid proof.
controls=[]
for name,raw in [('complete',ROOT/'output/h5-first57-clique-sat-call-20261107/proof.drat.bin'),('post-error',ROOT/'output/h5-first57-clique-sat-batch-10-call-20261107/proof.drat.bin')]:
    r=subprocess.run([str(EXE),str(raw)],capture_output=True,timeout=10,check=True);v=json.loads(r.stdout);assert v['first_empty_end'] and v['parse_error']=='none';controls.append({'name':name,**v})
assert controls[1]['first_empty_end']==json.loads((ROOT/'output/h5-post-error-proof-prefix-inspection-20261107.json').read_bytes())['first_empty_addition_end_offset']
rows=[]
for index in [1,9,16,21,24,None]:
    stem=f'h5-first57-clique-sat-batch-{index:02d}-call-20261107' if index is not None else 'h5-first57-sat-pilot-call-20261107'
    folder=ROOT/'output'/stem;process=json.loads((folder/'process.json').read_bytes());assert process['closed']
    if index is not None:assert process['job']['active_processes']==0 and process['limit_reason']=='proof-byte-limit'
    else:assert json.loads((folder/'descendant-closure-v2.json').read_bytes())['all_matching_workers_closed']
    raw=folder/'proof.drat.bin';before=sha256(raw.read_bytes()).hexdigest();t=time.perf_counter();r=subprocess.run([str(EXE),str(raw)],capture_output=True,timeout=20,check=True);v=json.loads(r.stdout);assert sha256(raw.read_bytes()).hexdigest()==before
    row={'graph_index':index,'source':raw.relative_to(ROOT).as_posix(),'source_sha256':before,'source_bytes':raw.stat().st_size,'seconds':time.perf_counter()-t,**v,'certificate_verified':False,'research_calls':0,'checker_calls':0}
    rows.append(row)
write('checks.json',{'passed':True,'parser_sha256':sha256(EXE.read_bytes()).hexdigest(),'controls':controls,'inspections':rows,'research_calls':0,'checker_calls':0,'syntactic_prefix_is_not_a_proof':True});print(rows)
