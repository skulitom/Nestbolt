from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/'output/push_h5_frontier_refined_checkpoint_20261107.py').read_text(encoding='utf-8')
text=text.replace('h5-frontier-refined-main-sync-20261107','h5-sat-pilot-main-sync-20261107')
text=text.replace("prefixes=('benchmarks/results/h5-frontier-refined-proofs-20261106',)","prefixes=('benchmarks/results/h5-frontier-refined-proofs-20261106','benchmarks/results/h5-sat-certificate-pilot-20261107')")
text=text.replace("OUT.mkdir();write(OUT/'prior-main-ci.json',ci)","assert json.loads((ROOT/'benchmarks/results/h5-sat-certificate-pilot-20261107/archive-checks.json').read_bytes())['passed']\nOUT.mkdir();write(OUT/'prior-main-ci.json',ci)")
with (ROOT/'output/push_h5_sat_pilot_checkpoint_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
