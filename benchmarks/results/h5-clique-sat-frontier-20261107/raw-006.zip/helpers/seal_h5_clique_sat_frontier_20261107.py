from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-clique-sat-frontier-20261107';OUT=ROOT/'benchmarks/results'/NAME
F=ROOT/'output/h5-first57-clique-sat-frontier-20261107';B=ROOT/'output/h5-first57-clique-sat-batch-20261107';SYNC=ROOT/'output/h5-sat-pilot-main-sync-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
frontier=load(F/'checks.json');batch=load(B/'audit/checks.json');assert frontier['passed'] and frontier['new_fixed29_exclusions']==20 and frontier['remaining_fixed29_choices']==6
assert batch['passed'] and batch['new_verified_exclusions']==17 and load(B/'process.json')['closed']
assert load(SYNC/'receipt.json')['new_main']=='de1b6da8057ea8409263ba5a7d3c6e4188663fa9'
setup=(ROOT/'output/seal_h5_sat_certificate_pilot_20261107.py').read_text(encoding='utf-8')
exec(setup[setup.index('parent_setup='):setup.index('walker=ROOT')])
PARENTS.append(ROOT/'benchmarks/results/h5-sat-certificate-pilot-20261107')
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
exec(old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']"))
folders=[F,B,SYNC]
for stem in ['h5-first57-clique-sat','h5-first57-earlier-cover-clique-sat']:
    folders.extend(ROOT/'output'/(stem+suffix+'-20261107') for suffix in ['-model','-call','-result-audit'])
for row in load(B/'plan.json')['selection']:folders.extend(ROOT/'output'/row[key] for key in ['model','call','result_audit'])
for pattern in ['h5-windows-job-controls*-20261107','h5-windows-job-external-stop-20261107','h5-first57-post-error-certificate*-20261107','h5-unresolved-proof-prefixes-20261107']:
    folders.extend(p for p in (ROOT/'output').glob(pattern) if p.is_dir())
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
patterns=['*h5*sat*20261107.py','*h5*job*20261107.py','*h5*post_error*20261107.py','inspect_h5_unresolved_proof_streams_20261107.py','h5_windows_job_runner*20261107.c','h5_binary_drat_prefix_20261107.c','h5-windows-job*correction-20261107.json','h5-post-error-*-20261107.json']
for pattern in patterns:
    for p in (ROOT/'output').glob(pattern):
        if p.is_file():add('helpers/'+p.name,p)
for name in ['ccd1.py','pack_h5_evidence_archive.py',walker.name,'seal_h5_sat_certificate_pilot_20261107.py','push_h5_sat_pilot_checkpoint_20261107.py']:
    add('helpers/'+name,ROOT/'output'/name)
for name,h in load(F/'source-bindings.json').items():
    p=ROOT/name;assert digest(p)==h;bindings[name]=h;add('source-inputs/'+name,p)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
copies=[(F/'checks.json','frontier-audit.json'),(F/'new-exclusions.json','new-exclusions.json'),(F/'remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(F/'remaining-source-graphs.json','remaining-source-graphs.json'),(F/'next-step.json','next-step.json'),(B/'audit/checks.json','batch-audit.json'),(B/'audit/case-results.json','batch-case-results.json'),(B/'process.json','batch-process.json'),(SYNC/'receipt.json','main-sync-receipt.json'),
    (ROOT/'output/h5-windows-job-controls-v4-20261107/checks.json','job-controls.json'),(ROOT/'output/h5-windows-job-external-stop-20261107/checks.json','external-stop-control.json'),(ROOT/'output/h5-first57-clique-sat-result-audit-20261107/checks.json','first-certificate.json'),(ROOT/'output/h5-first57-earlier-cover-clique-sat-result-audit-20261107/checks.json','earlier-cover-certificate.json'),(ROOT/'output/h5-first57-post-error-certificate-v3-20261107/checks.json','post-error-certificate.json'),(ROOT/'output/h5-unresolved-proof-prefixes-20261107/checks.json','incomplete-stream-inspection.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{key:frontier[key] for key in ['new_fixed29_exclusions','remaining_fixed29_choices','total_excluded_at_required_clearance','previous_zero_clearance_exclusions','fresh_research_SAT_calls','successful_bounded_producers_with_accepted_proof','post_error_certificate_only','new_proof_byte_limits','carried_prior_time_limit','model_clauses_verified','graph_pairs_verified','threshold_gates_verified','source_cell_capacity_proofs','whole_allocation_candidates','source_valid_placements','completion_percent','H2_complete','H5_complete']}})
report=f'''# Complete clique-count certificate frontier — 2026-11-07

Independent proof checking excludes **20 more fixed29/current-cog arrangements**.
There are now **six remaining**, with **449 of455 excluded at original0.2mm
clearance**;427 of those were already excluded even at zero clearance. This
does not produce a placement or exclude any whole-job allocation. The440
allocation candidates, full66 source/native/material checks and H2/H5 remain
open at **60% completed milestone weight**.

## Process-tree supervision

The [Windows Job Object controls]({NAME}/job-controls.json) assign a suspended
launcher before its initial thread resumes. The operating system then contains
its interpreter and descendants in the same job. Kill-on-close, an aggregate
committed-memory limit and a conservative peak-counter stop are configured.
Normal completion waits for a child even after its parent exits. Timeout and
memory-stop controls finish with zero active processes. A larger256MiB positive
control allows both80MiB children to allocate. An [external-stop control]({NAME}/external-stop-control.json)
also terminates the entire child tree before a frozen deadline.

All failures remain preserved: a macro redefinition fails the first strict
build; Windows runtime exclusive-file mode prevents the next control report;
and the next memory control reports a peak above its configured limit despite
one rejected allocation. The final runner conservatively stops when that
counter exceeds the limit, rather than treating its accounting cause as known.
This is test infrastructure; no production dependency or benchmark meaning changes.
API sources and compiler/source/binary hashes are retained.

## Source-necessary Boolean models

Each model preserves every independently certified incompatible-cell pair.
The source conflict cliques form a complete partition of each family. A group
selector is equivalent to OR of its cells; pair clauses permit at most one
selected cell per group. Counting at least eight selected groups is therefore
exactly equivalent to counting at least eight cells. This reduces the threshold
logic from long per-cell chains while preserving every legal continuous completion.

Across25 fresh models, independent audits verify **47,714,816 clauses**,
**111,518,237 graph pairs**,5,912 threshold gates and72,937 source-inner-rectangle
single-cell capacity proofs. Complete source covers preserve all boundaries and
mode aliases. The first [0,5,11] proof and the separate earlier [4,5,10] graph
both pass their [independent certificate checks]({NAME}/first-certificate.json),
[including the earlier-cover check]({NAME}/earlier-cover-certificate.json).
The earlier timed-out [0,5,12] pilot is never rerun.

The [23-case batch]({NAME}/batch-audit.json) uses one fresh call for each other
arrangement, with60s search,1,000,000 conflicts,2GiB aggregate memory and64MiB
binary-proof limits frozen before execution. Model construction and every-clause
audit precede each call. Native job containment protects every stage and returns
zero active descendants. The batch closes in691.642932s, within its3600s cap.
Seventeen normal executions have complete proofs accepted against their exact
DIMACS bytes. Five calls stop at the proof-byte limit; these remain unresolved.

## A failed producer and an independently proved contradiction

[5,10,12] writes UNSAT and later exits with Windows error0xC0000409. Its original
audit rejects the run before invoking a proof checker. The full preserved binary
file contains13,336,634 bytes, exceeding its pre-destructor telemetry12,210,234.
The first artifact preflight preserves that size mismatch; the next rejects the
malformed full-file suffix. Neither invokes a checker.

A separately parsed, unchanged prefix ends in its first added empty clause at
byte12,210,234. The independent binary parser agrees with the Python inspection.
This is only a syntactic candidate until every necessary lemma is checked.
The exact prefix is losslessly converted and the **first native checker call
accepts its complete derivation**. The [certificate-only result]({NAME}/post-error-certificate.json)
therefore proves the fixed-arrangement contradiction. The full raw file, its
1,126,400-byte post-empty suffix, process error, earlier telemetry and failed
audits remain preserved. The producer is never relabelled successful and there
is no successful benchmark-construction claim or repeated search/checker call.

## Six unresolved source arrangements

The [combined audit]({NAME}/frontier-audit.json) combines19 proofs from successful
bounded producers and this one independently checked artifact. It deduplicates
the excluded choices and checks their source/model/proof bindings. The six
remaining choices are **[0,5,10], [0,5,12], [5,10,11], [10,11,12], [11,12,13]
and[12,13,14]**. Every earlier call stays closed.

[Read-only stream inspection]({NAME}/incomplete-stream-inspection.json) checks
all five byte-limited files and the prior time-limited pilot. None contains a
complete prefix ending in an added empty clause; all end in truncated data.
No checker call or exclusion is claimed for any of them. There are no graph
witnesses or source-valid placements.

[Next]({NAME}/next-step.json), assess genuinely stronger source clearance
polygons for those six retained graphs, using an inscribed16-direction shape
strictly inside the original200um Euclidean clearance disk. Rebuild from
unexpanded source geometry and independently verify every new removal/edge.
A case must gain an actual new necessary constraint before any fresh call.
No closed model is simply rerun or given larger limits. All consumed preparation
and failures remain recorded; none of this is a full-job60/90s construction claim.

The two preceding checkpoints reached main **de1b6da8** by normal atomic
fast-forward after all six prior CI checks passed; the [receipt]({NAME}/main-sync-receipt.json)
preserves all52 remote README/site files. No release or registry version is added.

[The manifest]({NAME}/raw-manifest.json) contains{archive['archive_members']} new
canonical members in{archive['archive_parts']} ZIP parts, totaling{archive['archive_bytes']:,} bytes.
[Historical references]({NAME}/external-evidence.json) and
[source bindings]({NAME}/source-bindings.json) retain every original dependency.
Independent archive verification is required before commit.
'''
# Keep generated prose readable without changing any hash-bound raw evidence.
for a,b in {'of455':'of 455','original0.2mm':'original 0.2 mm',';427':'; 427','The440':'The 440','full66':'full 66','larger256MiB':'larger 256 MiB','both80MiB':'both 80 MiB','Across25':'Across 25',',5,912':', 5,912','and72,937':'and 72,937','with60s':'with 60 s',',1,000,000':', 1,000,000',',2GiB':', 2 GiB','and64MiB':'and 64 MiB','in691.642932s':'in 691.642932 s','its3600s':'its 3600 s','error0x':'error 0x','contains13,336,634':'contains 13,336,634','telemetry12,210,234':'telemetry 12,210,234','byte12,210,234':'byte 12,210,234','combines19':'combines 19','and[12,13,14]':'and [12,13,14]','inscribed16-direction':'inscribed 16-direction','original200um':'original 200 um','full-job60/90s':'full-job 60/90 s','all52':'all 52',f"contains{archive['archive_members']}":f"contains {archive['archive_members']}",f"in{archive['archive_parts']} ZIP":f"in {archive['archive_parts']} ZIP",f"totaling{archive['archive_bytes']:,}":f"totaling {archive['archive_bytes']:,}"}.items():report=report.replace(a,b)
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-07 H5 clique-count certificate frontier:** [source/model/proof audits]({link}) verify 25 fresh models, 47,714,816 clauses, 111,518,237 graph pairs and 5,912 threshold gates. Complete conflict-clique partitions make group counts exactly equivalent to selected cell counts. Nineteen bounded producers have independently accepted proofs; a twentieth contradiction is proved by the first check of an unchanged complete prefix from a failed producer, preserving its Windows error and malformed suffix without claiming execution success. The 23-case batch closes in 691.642932 s; five proof-byte-limited calls and the earlier timed-out pilot remain open and have no complete certificate. The fixed29/current-cog frontier falls from 26 to six: 449 of 455 excluded at required 0.2 mm clearance, 427 even at zero clearance. Windows Job Object controls now verify descendant termination and conservative aggregate-memory stops. Next assess genuinely stronger source clearance polygons; require a new certified constraint before any fresh call. All prior calls remain closed, all 440 whole allocations and full66 validation remain open, and H2/H5 stay at 60%. The preceding two checkpoints reached main de1b6da8 after all six prior CI checks passed; no release was made.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8')
a='Latest H5 evidence: [SAT certificate pilot](../benchmarks/results/h5-sat-certificate-pilot-20261107.md).';assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [clique-count certificate frontier](../benchmarks/results/{NAME}.md).',1)
a='Its sole [0,5,12] pilot times out without a usable proof or assignment. All 26\narrangements remain unresolved. Process-tree resource enforcement must pass\na spawned-child control before another distinct call; this pilot stays closed.'
b='Its sole [0,5,12] pilot times out without a usable proof or assignment. New\nWindows Job Object controls verify descendant closure and conservative aggregate\nmemory stops. Complete clique partitions reduce the counting logic; 25 fresh\nmodels pass full audits. Nineteen bounded producers have accepted proofs, and a\nseparate complete certificate from one failed producer is accepted while its\nprocess failure and malformed suffix remain preserved. Twenty more choices are\nexcluded: six remain, with 449 of 455 excluded at required clearance and 427 even\nat zero clearance. Five proof-byte limits and the earlier time limit remain\nunresolved. New source clearance constraints are next; no closed call is rerun.'
assert s.count(a)==1;s=s.replace(a,b,1)
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
