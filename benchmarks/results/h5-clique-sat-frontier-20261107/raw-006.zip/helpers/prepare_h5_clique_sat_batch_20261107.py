from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-clique-sat-batch-20261107';OUT.mkdir()
load=lambda p:json.loads(p.read_bytes())
assert load(ROOT/'output/h5-first57-clique-sat-result-audit-20261107/checks.json')['proof_verified']
template_names=['prepare_h5_clique_sat_model_20261107.py','audit_h5_clique_sat_model_20261107.py','solve_h5_clique_sat_20261107.py','run_h5_clique_sat_20261107.py','audit_h5_clique_sat_result_20261107.py']
templates={name:(ROOT/'output'/name).read_text(encoding='utf-8') for name in template_names};rows=[]
for index in range(25):
    if index in [2,3]:continue
    G=ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106'/f'choice-{index:02d}';gc=load(G/'checks.json');sites=gc['source_selection']['empty_sites']
    model=f'h5-first57-clique-sat-batch-{index:02d}-model-20261107';call=f'h5-first57-clique-sat-batch-{index:02d}-call-20261107';audit=f'h5-first57-clique-sat-batch-{index:02d}-result-audit-20261107'
    assert not any((ROOT/'output'/name).exists() for name in [model,call,audit])
    scripts={}
    renamed={name:name.replace('_20261107.py',f'_batch_{index:02d}_20261107.py') for name in templates}
    for name,text in templates.items():
        text=text.replace('h5-first57-clique-sat-model-20261107',model).replace('h5-first57-clique-sat-call-20261107',call).replace('h5-first57-clique-sat-result-audit-20261107',audit)
        for before,after in renamed.items():text=text.replace(before,after)
        if name.startswith('prepare_'):
            text=text.replace('/choice-02',f'/choice-{index:02d}').replace('[0,5,11]',str(sites)).replace("==2135",'=='+str(gc['compact_nodes']))
            text=text.replace("'binary_proof_byte_limit':268435456","'binary_proof_byte_limit':67108864")
        if name=='audit_h5_clique_sat_result_20261107.py':
            text=text.replace("ROOT/'output/h5-first57-frontier-refined-trees-20261106/audit/remaining-fixed29-choices.json'", "ROOT/'output/h5-first57-clique-sat-result-audit-20261107/remaining-fixed29-choices.json'")
        p=ROOT/'output'/renamed[name]
        with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
        scripts[name]={'path':p.relative_to(ROOT).as_posix(),'sha256':sha256(p.read_bytes()).hexdigest()}
    rows.append({'graph_index':index,'empty_sites':sites,'compact_nodes':gc['compact_nodes'],'graph_checks_sha256':sha256((G/'checks.json').read_bytes()).hexdigest(),'model':model,'call':call,'result_audit':audit,'scripts':scripts})
rows.sort(key=lambda r:(r['compact_nodes'],r['graph_index']))
plan={'utc':datetime.now(timezone.utc).isoformat(),'selection':rows,'cases':len(rows),'order':'ascending compact graph size, then original refinement index','baseline_fixed29_choices':25,'baseline_required_clearance_exclusions':430,'excluded_from_selection':{'already_checked_UNSAT':[0,5,11],'closed_timed_out_pilot':[0,5,12],'earlier_separate_graph_not_in_this_batch':[4,5,10]},
    'frozen_per_case_search_seconds':60,'frozen_conflict_budget':1000000,'frozen_binary_proof_bytes':67108864,'frozen_job_committed_memory_bytes':2147483648,'one_call_per_distinct_case':True,'retry_permitted':False,
    'stage_caps_seconds':{'prepare':120,'model_audit':120,'call':100,'result_audit':90},'global_batch_seconds':3600,'full_job_construction_budget_claimed':False,
    'proof_rules':'Only a complete checked proof excludes an arrangement. SAT is graph witness only. Every per-case frontier is relative to the fixed25 baseline; aggregate by set union, never by summing per-case remaining counts. All closed calls remain closed. A global cap leaves untouched cases unattempted, not excluded.',
    'inputs':{str((ROOT/'output'/name).relative_to(ROOT)).replace('\\','/'):sha256((ROOT/'output'/name).read_bytes()).hexdigest() for name in templates},
    'baseline_frontier':'output/h5-first57-clique-sat-result-audit-20261107/remaining-fixed29-choices.json'}
plan['inputs'][plan['baseline_frontier']]=sha256((ROOT/plan['baseline_frontier']).read_bytes()).hexdigest()
with (OUT/'plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(plan,f,indent=2);f.write('\n')
print({'prepared_cases':len(rows),'order':[r['empty_sites'] for r in rows]})
