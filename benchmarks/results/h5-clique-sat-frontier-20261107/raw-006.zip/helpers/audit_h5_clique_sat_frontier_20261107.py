from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-clique-sat-frontier-20261107';OUT.mkdir();load=lambda p:json.loads(p.read_bytes())
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
start=time.perf_counter();BASE=ROOT/'output/h5-first57-frontier-refined-trees-20261106/audit/remaining-fixed29-choices.json';baseline=load(BASE)
def sites(row):return tuple(row['empty_sites'] if 'empty_sites' in row else row['source_selection']['empty_sites'])
assert len(baseline)==26 and len({sites(r) for r in baseline})==26
B=ROOT/'output/h5-first57-clique-sat-batch-20261107';batch=load(B/'audit/checks.json');assert batch['passed'] and batch['cases_attempted']==23
excluded={tuple(s) for s in load(B/'audit/new-exclusions.json')};assert len(excluded)==17
bindings={BASE.relative_to(ROOT).as_posix():sha256(BASE.read_bytes()).hexdigest()};reports=[]
for stem in ['h5-first57-clique-sat','h5-first57-earlier-cover-clique-sat']:
    M=ROOT/'output'/(stem+'-model-20261107');C=ROOT/'output'/(stem+'-call-20261107');A=ROOT/'output'/(stem+'-result-audit-20261107')
    answer=load(A/'checks.json');ma=load(M/'audit.json');call=load(C/'process.json');cp=load(A/'checker-process.json');opened=load(A/'checker-opened.json');conv=load(A/'conversion.json')
    assert answer['passed'] and answer['proof_verified'] and answer['valid_complete_process'] and ma['passed']
    assert call['closed'] and call['exit_code']==0 and call['limit_reason'] is None and call['job']['active_processes']==0
    assert cp['verified'] and cp['exit_code']==0 and cp['closed'] and not cp['timeout'] and cp['process_cap_overrun_seconds']==0
    assert sha256((M/'model.cnf').read_bytes()).hexdigest()==ma['model_sha256']==opened['formula_sha256']
    assert sha256((C/'proof.drat.bin').read_bytes()).hexdigest()==conv['binary_sha256'] and sha256((A/'proof.drat.txt').read_bytes()).hexdigest()==conv['text_sha256']==opened['proof_sha256']
    assert any(line.strip()==b's VERIFIED' for line in (A/'checker-stdout.txt').read_bytes().splitlines())
    empty=tuple(answer['source_selection']['empty_sites']);assert empty not in excluded;excluded.add(empty)
    reports.append({'empty_sites':empty,'proof_kind':'successful bounded producer and independent checker','response':str(A.relative_to(ROOT)/'checks.json')})
    for p in [M/'plan.json',M/'audit.json',C/'process.json',A/'checks.json',A/'checker-process.json',A/'checker-opened.json',A/'conversion.json']:
        bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
P=ROOT/'output/h5-first57-post-error-certificate-v3-20261107';post=load(P/'checks.json');pp=load(P/'plan.json');pc=load(P/'checker-process.json');conversion=load(P/'conversion.json');inspection=load(ROOT/'output/h5-post-error-proof-prefix-inspection-20261107.json')
assert post['passed'] and post['proof_verified'] and not post['producer_success'] and post['search_calls']==0 and post['first_independent_checker_attempt']
assert pc['verified'] and pc['exit_code']==0 and pc['closed'] and not pc['timeout'] and pc['process_cap_overrun_seconds']==0
for name,h in pp['inputs'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h;bindings[name]=h
raw=ROOT/inspection['source'];prefix=P/'proof-complete-prefix.drat.bin';assert prefix.read_bytes()==raw.read_bytes()[:inspection['first_empty_addition_end_offset']]
assert sha256(prefix.read_bytes()).hexdigest()==inspection['complete_prefix_sha256']==conversion['binary_sha256']
assert sha256((P/'proof.drat.txt').read_bytes()).hexdigest()==conversion['text_sha256'] and any(l.strip()==b's VERIFIED' for l in (P/'checker-stdout.txt').read_bytes().splitlines())
empty=tuple(post['source_selection']['empty_sites']);assert empty not in excluded;excluded.add(empty)
reports.append({'empty_sites':empty,'proof_kind':'first independently accepted exact prefix ending in empty clause; failed producer preserved','response':str(P.relative_to(ROOT)/'checks.json')})
assert len(excluded)==20 and excluded<={sites(r) for r in baseline}
remaining=[r for r in baseline if sites(r) not in excluded];assert len(remaining)==6
inspections=load(ROOT/'output/h5-unresolved-proof-prefixes-20261107/checks.json');assert inspections['passed'] and len(inspections['inspections'])==6
batchplan=load(B/'plan.json');selection={r['graph_index']:r for r in batchplan['selection']};mapped=[]
for row in inspections['inspections']:
    assert row['first_empty_end']==0 and not row['certificate_verified'] and row['checker_calls']==row['research_calls']==0
    raw=ROOT/row['source'];assert sha256(raw.read_bytes()).hexdigest()==row['source_sha256']
    index=row['graph_index'];empty=(0,5,12) if index is None else tuple(selection[index]['empty_sites']);refinement=3 if index is None else index
    G=ROOT/'output/h5-first57-frontier-refined-graphs-v2-20261106'/f'choice-{refinement:02d}';gc=load(G/'checks.json');assert tuple(gc['source_selection']['empty_sites'])==empty
    mapped.append({'empty_sites':empty,'refinement_index':refinement,'source_selection':gc['source_selection'],'graph':G.relative_to(ROOT).as_posix(),'closed_result':'time limit' if index is None else 'proof-byte limit','stream_inspection':row,'no_search_or_checker_repeat':True})
assert {tuple(r['empty_sites']) for r in mapped}=={sites(r) for r in remaining}
for p in [B/'plan.json',B/'process.json',B/'audit/checks.json',B/'audit/new-exclusions.json',P/'plan.json',P/'checks.json',P/'checker-process.json',ROOT/'output/h5-unresolved-proof-prefixes-20261107/checks.json']:
    bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
result={'passed':True,'prior_fixed29_choices':26,'new_fixed29_exclusions':20,'remaining_fixed29_choices':6,'total_excluded_at_required_clearance':449,'previous_zero_clearance_exclusions':427,'new_zero_clearance_exclusions_claimed':0,'fresh_research_SAT_calls':25,'successful_bounded_producers_with_accepted_proof':19,'post_error_certificate_only':1,'new_proof_byte_limits':5,'carried_prior_time_limit':1,'graph_witnesses':0,'model_clauses_verified':45512678+910583+1291555,'graph_pairs_verified':106296241+2278045+2943951,'threshold_gates_verified':5496+200+216,'source_cell_capacity_proofs':68375+2135+2427,'whole_allocation_candidates':440,'source_valid_placements':0,'LightBurn_or_full66_native_validator_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'aggregate_seconds':time.perf_counter()-start,'scope':'Fixed29/current12-of15reference-cog arrangement exclusions at original0.2mm clearance. No whole-allocation exclusion, new zero-clearance claim, placement or benchmark construction success follows.'}
for name,v in [('checks.json',result),('new-exclusions.json',sorted(excluded)),('remaining-fixed29-choices.json',remaining),('remaining-source-graphs.json',mapped),('supplementary-certificate-reports.json',reports),('source-bindings.json',bindings)]:write(name,v)
write('next-step.json',{'all_existing_searches_closed':True,'remaining_fixed29_choices':6,'next_genuine_source_strengthening':'Assess exact convex collision polygons expanded by an inscribed16-direction clearance polygon with integer micrometre vertices generated from(199,0),(183,76),(140,140),(76,183) and sign/quarter-turn symmetry. Every vertex has radius strictly below200um, so its convex hull is wholly within the original required0.2mm Euclidean clearance disk. Rebuild from unexpanded original source polygons, never by expanding an already inflated polygon. Independently certify all hull vertices and source containment, prune only fully covered closed anchor cells, preserve every alias/boundary and inherited edge, and audit every added conflict. This is genuinely new source geometry information rather than a rerun of the closed SAT models. Require an observed new removal/edge for a case before any fresh bounded model; if none changes, do not call a solver.','no_full_construction_budget_claim':True,'old_proof_caps_and_failures_preserved':True,'artifact_failure_rule':'A mathematical certificate may be checked independently of an untrusted producer exit, but never count a failed/timed-out producer as a successful benchmark execution. Preserve full raw stream and exact prefix boundary; no search or checker retries.','current_streams_have_no_complete_prefix':True,'H5_complete':False})
print(result)
