from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'output/seal_h5_clique_sat_frontier_20261107.py'
assert not (ROOT/'benchmarks/results/h5-clique-sat-frontier-20261107').exists()
text=old.read_text(encoding='utf-8')
text=text.replace("exec(setup[setup.index('parent_setup='):setup.index('walker=ROOT')])", "parent_nodes=ast.parse(setup).body\ndef assigns(node,name):return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)\nparent_start=next(i for i,node in enumerate(parent_nodes) if assigns(node,'parent_setup'))\nparent_end=next(i for i,node in enumerate(parent_nodes) if assigns(node,'walker'))\nexec(compile(ast.Module(body=parent_nodes[parent_start:parent_end],type_ignores=[]),'prior-parent-setup','exec'))")
text=text.replace("'h5-post-error-*-20261107.json'", "'h5-post-error-*-20261107.json','h5-clique-sat-seal-preflight-correction-20261107.json'")
with (ROOT/'output/seal_h5_clique_sat_frontier_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
with (ROOT/'output/h5-clique-sat-seal-preflight-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'original_sealer':old.relative_to(ROOT).as_posix(),'exit_code':1,'failure':'String-boundary extraction matched walker=ROOT inside a quoted expression, producing a truncated Python statement and SyntaxError.','artifact_created_before_failure':False,'documentation_modified_before_failure':False,'proofs_or_searches_repeated':False,'versioned_change':'Select the parent-manifest initialization statements by AST assignment targets instead of substring positions. Original sealer and this preflight failure remain preserved.'},f,indent=2);f.write('\n')
