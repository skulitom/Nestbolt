from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];NAME='h5-sat-certificate-pilot-20261107';OUT=ROOT/'benchmarks/results'/NAME
replacements={'PySAT1.9':'PySAT 1.9','CPython3.13':'CPython 3.13','CaDiCaL1.9':'CaDiCaL 1.9','byte0x1a':'byte 0x1a',
    'and1,216':'and 1,216','all2,229,216':'all 2,229,216','pairs,887,869':'pairs, 887,869','and953,103':'and 953,103','including16,840':'including 16,840',
    'over18,952':'over 18,952','least8':'least 8','capacity1':'capacity 1','the2,112':'the 2,112','original0.2mm':'original 0.2 mm',
    'takes3.085335s':'takes 3.085335 s','takes17.633587s':'takes 17.633587 s','full-job60/90-second':'full-job 60/90-second',
    'one60-second':'one 60-second','a1,000,000-conflict':'a 1,000,000-conflict','a90-second':'a 90-second','cap,2GiB':'cap, 2 GiB','and256MiB':'and 256 MiB',
    'after66.683245s':'after 66.683245 s','about4MiB':'about 4 MiB','still429':'still 429','of455':'of 455',',427':', 427',
    'contains95':'contains 95','and11,767,462':'and 11,767,462','verify953,103':'verify 953,103',',16,840':', 16,840','and2,112':'and 2,112',
    'for[0,5,12]':'for [0,5,12]','sole60-second':'sole 60-second','The26':'The 26',',440':', 440','at60%':'at 60%',
    'source-valid66':'source-valid 66','full953,103':'full 953,103','sole[0,5,12]':'sole [0,5,12]','All26':'All 26'}
report=OUT.with_suffix('.md');s=report.read_text(encoding='utf-8')
for a,b in replacements.items():s=s.replace(a,b)
with report.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    p=ROOT/name;s=p.read_text(encoding='utf-8');marker='**2026-11-07 H5 SAT certificate pilot:**';before,after=s.rsplit(marker,1)
    for a,b in replacements.items():after=after.replace(a,b)
    if name=='docs/STATUS.md':
        for a,b in [('full953,103','full 953,103'),('sole[0,5,12]','sole [0,5,12]'),('All26','All 26')]:before=before.replace(a,b)
    with p.open('w',encoding='utf-8',newline='\n') as f:f.write(before+marker+after)
v=(ROOT/'output/verify_h5_refined_cover_proofs_20261106.py').read_text(encoding='utf-8').replace('h5-refined-cover-proofs-20261106',NAME)
verifier=ROOT/'output/verify_h5_sat_certificate_pilot_20261107.py'
with verifier.open('x',encoding='utf-8',newline='\n') as f:f.write(v)
(OUT/'archive-verifier.py.txt').write_bytes(verifier.read_bytes())
print('publication prose and independent archive verifier prepared')
