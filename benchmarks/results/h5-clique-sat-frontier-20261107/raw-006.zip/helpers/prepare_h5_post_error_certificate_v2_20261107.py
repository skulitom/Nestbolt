from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];original=ROOT/'output/audit_h5_post_error_certificate_20261107.py'
text=original.read_text(encoding='utf-8').replace('h5-first57-post-error-certificate-20261107','h5-first57-post-error-certificate-v2-20261107')
text=text.replace("assert raw.stat().st_size==sr['proof_bytes']<=plan['binary_proof_byte_limit']", "assert sr['proof_bytes']<=raw.stat().st_size<=plan['binary_proof_byte_limit']")
text=text.replace("'producer_success_claimed':False", "'producer_success_claimed':False,'reported_pre_destructor_proof_bytes':sr['proof_bytes'],'actual_closed_file_bytes':raw.stat().st_size")
with (ROOT/'output/audit_h5_post_error_certificate_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
raw=ROOT/'output/h5-first57-clique-sat-batch-10-call-20261107/proof.drat.bin'
with (ROOT/'output/h5-post-error-certificate-size-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'failed_preflight_script':original.relative_to(ROOT).as_posix(),'failed_script_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'original_searches':0,'original_checker_calls':0,'reported_bytes':12210234,'actual_closed_file_bytes':raw.stat().st_size,'actual_closed_file_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'finding':'The worker samples proof size inside the solver context, before destructor/stream finalization. The closed file is larger. Its bytes, not the earlier telemetry, are authoritative for independent certificate verification. Do not infer completeness or correctness from either size.','versioned_change':'Require the entire stable closed file below the original64MiB proof cap, bind its exact hash, preserve the earlier report and failed preflight, and check that complete byte stream independently. No solver or proof-checker call is repeated.'},f,indent=2);f.write('\n')
