from pathlib import Path
import sys,subprocess,time,json,os
mode=sys.argv[1];folder=Path(sys.argv[2])
def save(name,data):
    with (folder/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(data,f,indent=2);f.write('\n')
if mode=='sleep-child':
    save('sleep-child.json',{'pid':os.getpid(),'parent_pid':os.getppid()});time.sleep(30)
elif mode=='timeout-parent':
    p=subprocess.Popen([sys.executable,__file__,'sleep-child',str(folder)])
    save('timeout-parent.json',{'pid':os.getpid(),'child_launcher_pid':p.pid});p.wait()
elif mode=='normal-child':
    time.sleep(.3);save('normal-child.json',{'pid':os.getpid(),'completed':True})
elif mode=='normal-parent':
    p=subprocess.Popen([sys.executable,__file__,'normal-child',str(folder)])
    save('normal-parent.json',{'pid':os.getpid(),'child_launcher_pid':p.pid})
    # Deliberately exit first: the runner must wait for the remaining child.
elif mode=='memory-child':
    index=sys.argv[3]
    try:
        block=bytearray(80*1024*1024)
        save('memory-'+index+'.json',{'pid':os.getpid(),'allocated':True,'bytes':len(block)})
        time.sleep(1)
    except MemoryError:save('memory-'+index+'.json',{'pid':os.getpid(),'allocated':False,'memory_error':True})
elif mode=='memory-parent':
    ps=[subprocess.Popen([sys.executable,__file__,'memory-child',str(folder),str(i)]) for i in range(2)]
    save('memory-parent.json',{'pid':os.getpid(),'children':[p.pid for p in ps]})
    exits=[p.wait() for p in ps];save('memory-parent-result.json',{'exit_codes':exits})
else:raise ValueError(mode)
