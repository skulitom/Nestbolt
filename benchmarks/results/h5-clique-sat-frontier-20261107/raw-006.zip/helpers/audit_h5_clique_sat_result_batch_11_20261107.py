from pathlib import Path
from hashlib import sha256
import time,json,subprocess
from h5_drat_text_20261107 import to_text
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-clique-sat-batch-11-result-audit-20261107';OUT.mkdir()
MODEL=ROOT/'output/h5-first57-clique-sat-batch-11-model-20261107';CALL=ROOT/'output/h5-first57-clique-sat-batch-11-call-20261107'
load=lambda p:json.loads(p.read_bytes())
def write(name,v):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=time.perf_counter();plan=load(MODEL/'plan.json');process=load(CALL/'process.json');modelaudit=load(MODEL/'audit.json')
assert process['closed'] and modelaudit['passed']
assert sha256((MODEL/'model.cnf').read_bytes()).hexdigest()==modelaudit['model_sha256']
result=load(CALL/'result.json') if (CALL/'result.json').exists() else {'status':'UNRESOLVED'}
job=process['job']
validprocess=process['exit_code']==0 and process['limit_reason'] is None and process['complete_process_cap_overrun_seconds']==0 and job['error_code']==0 and job['reason_code']==0 and job['closed'] and job['active_processes']==0 and job['peak_job_committed_memory']<=plan['solver_aggregate_committed_memory_bytes']
if result['status'] in ['SAT','UNSAT']:validprocess=validprocess and result['search_seconds']<=plan['solver_search_seconds'] and result['proof_bytes']<=plan['binary_proof_byte_limit']
record={'passed':True,'solver_status':result['status'],'valid_complete_process':validprocess,'proof_verified':False,'assignment_verified':False,'new_exclusions':0,'source_valid_placements':0,'model_sha256':modelaudit['model_sha256'],'source_selection':plan['source_selection'],'original_required_clearance_mm':.2}
if validprocess and result['status']=='UNSAT':
    raw=(CALL/'proof.drat.bin').read_bytes();assert len(raw)<=plan['binary_proof_byte_limit']
    t=time.perf_counter();text=to_text(raw);(OUT/'proof.drat.txt').write_bytes(text)
    write('conversion.json',{'binary_sha256':sha256(raw).hexdigest(),'text_sha256':sha256(text).hexdigest(),'binary_bytes':len(raw),'text_bytes':len(text),'exact_round_trip_passed':True,'seconds':time.perf_counter()-t,'converter_sha256':sha256((ROOT/'output/h5_drat_text_20261107.py').read_bytes()).hexdigest()})
    checker=ROOT/'output/h5-sat-tools-20261107/drat-trim.exe';controls=load(ROOT/'output/h5-sat-controls-v2-20261107/checks.json')
    assert controls['passed'] and sha256(checker.read_bytes()).hexdigest()==controls['checker_sha256']
    args=[str(checker),str(MODEL/'model.cnf'),str(OUT/'proof.drat.txt'),'-t',str(plan['checker_seconds'])]
    write('checker-opened.json',{'command':args,'checker_sha256':controls['checker_sha256'],'formula_sha256':modelaudit['model_sha256'],'proof_sha256':sha256(text).hexdigest(),'maximum_process_seconds':plan['checker_complete_process_seconds'],'retry_permitted':False})
    t=time.perf_counter()
    try:
        r=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=plan['checker_complete_process_seconds']);stdout,stderr=r.stdout,r.stderr
        verified=r.returncode==0 and any(line.strip()==b's VERIFIED' for line in stdout.splitlines());check={'exit_code':r.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        stdout,stderr=e.stdout or b'',e.stderr or b'';verified=False;check={'exit_code':None,'timeout':True}
    elapsed=time.perf_counter()-t
    (OUT/'checker-stdout.txt').write_bytes(stdout);(OUT/'checker-stderr.txt').write_bytes(stderr)
    check.update({'closed':True,'verified':verified,'complete_seconds':elapsed,'process_cap_overrun_seconds':max(0,elapsed-plan['checker_complete_process_seconds'])})
    write('checker-process.json',check);verified=verified and check['process_cap_overrun_seconds']==0
    record.update({'proof_verified':verified,'new_exclusions':int(verified),'classification':'continuous fixed-arrangement exclusion at required0.2mm clearance' if verified else 'unresolved: proof not accepted within limits'})
elif validprocess and result['status']=='SAT':
    model=load(CALL/'assignment.json');assignment={abs(x):x>0 for x in model};assert len(assignment)==len(model)
    checked=0
    with (MODEL/'model.cnf').open(encoding='ascii') as f:
        header=f.readline().split();assert set(assignment)==set(range(1,int(header[2])+1))
        for line in f:
            row=list(map(int,line.split()));assert row[-1]==0
            assert any(assignment[abs(x)]==(x>0) for x in row[:-1]);checked+=1
        assert checked==int(header[3])
    nodes=load(ROOT/plan['graph']/'nodes.json');selected=[[i for i,node in enumerate(nodes) if node['family']==family and assignment[i+1]] for family in [0,1]]
    assert all(len(family)>=8 for family in selected)
    write('necessary-graph-witness.json',{'selected_compact_nodes':selected,'selected_cells':[[nodes[i] for i in family] for family in selected],'full_CNF_assignment_sha256':sha256((CALL/'assignment.json').read_bytes()).hexdigest(),'source_valid_placement':False})
    record.update({'assignment_verified':True,'clauses_verified':checked,'selected_family_counts':list(map(len,selected)),'classification':'necessary graph witness only; no placement or exclusion'})
else:record['classification']='unresolved: limit, unknown or process failure'
remaining=load(ROOT/'output/h5-first57-clique-sat-result-audit-20261107/remaining-fixed29-choices.json')
if record['new_exclusions']:
    # Original records are preserved; exclude only the independently proved selected arrangement.
    assert isinstance(remaining,list)
    def empty(row):return row['empty_sites'] if 'empty_sites' in row else row['source_selection']['empty_sites']
    before=len(remaining);remaining=[row for row in remaining if empty(row)!=plan['source_selection']['empty_sites']];assert len(remaining)==before-1
write('remaining-fixed29-choices.json',remaining)
record.update({'remaining_fixed29_choices':len(remaining),'total_excluded_at_required_clearance':455-len(remaining),'previous_zero_clearance_exclusions':427,'whole_allocation_candidates':440,'audit_seconds':time.perf_counter()-started,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write('checks.json',record);print(record)
