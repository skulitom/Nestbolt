from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];src=ROOT/'output/h5_windows_job_runner_v2_20261107.c'
text=src.read_text(encoding='utf-8')
text=text.replace('FILE *report = _wfopen(argv[3], L"wx");\n    if (report) {\n        fprintf(report,', 'HANDLE report = CreateFileW(argv[3], GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);\n    if (report != INVALID_HANDLE_VALUE) {\n        char buffer[4096]; DWORD written = 0;\n        int length = snprintf(buffer, sizeof(buffer),')
text=text.replace('        fclose(report);','        if (length < 0 || length >= (int)sizeof(buffer) || !WriteFile(report, buffer, (DWORD)length, &written, NULL) || written != (DWORD)length) failure = ERROR_WRITE_FAULT;\n        CloseHandle(report);')
assert '_wfopen' not in text
with (ROOT/'output/h5_windows_job_runner_v3_20261107.c').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
text=(ROOT/'output/check_h5_windows_job_runner_v2_20261107.py').read_text(encoding='utf-8').replace('h5-windows-job-controls-v2-20261107','h5-windows-job-controls-v3-20261107').replace('h5_windows_job_runner_v2_20261107.c','h5_windows_job_runner_v3_20261107.c')
with (ROOT/'output/check_h5_windows_job_runner_v3_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
with (ROOT/'output/h5-windows-job-report-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'original_control':'output/h5-windows-job-controls-v2-20261107/normal','failure':'Native runner did not create job.json; original reader failed. The source used _wfopen with C11 exclusive mode wx, which is not portable to the linked Windows runtime.','versioned_change':'Use Windows CreateFileW CREATE_NEW plus WriteFile for exclusive report creation. Keep all job supervision logic and frozen control limits.','original_outputs_preserved':True,'research_calls':0},f,indent=2);f.write('\n')
