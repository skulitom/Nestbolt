from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
src=ROOT/'output/h5_windows_job_runner_20261107.c'
text=src.read_text(encoding='utf-8').replace('#define UNICODE\n#define _UNICODE\n','#ifndef UNICODE\n#define UNICODE\n#endif\n#ifndef _UNICODE\n#define _UNICODE\n#endif\n',1)
with (ROOT/'output/h5_windows_job_runner_v2_20261107.c').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
text=(ROOT/'output/check_h5_windows_job_runner_20261107.py').read_text(encoding='utf-8')
text=text.replace('h5-windows-job-controls-20261107','h5-windows-job-controls-v2-20261107').replace('h5_windows_job_runner_20261107.c','h5_windows_job_runner_v2_20261107.c')
with (ROOT/'output/check_h5_windows_job_runner_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
with (ROOT/'output/h5-windows-job-build-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'original_build':'output/h5-windows-job-controls-20261107/build.json','original_source_preserved':True,'failure':'-municode already defines UNICODE; source redefinition is rejected by -Werror.','versioned_change':'Guard UNICODE and _UNICODE declarations with #ifndef; keep -Werror and all process-limit logic.','original_process_controls_started':0,'research_calls':0},f,indent=2);f.write('\n')
