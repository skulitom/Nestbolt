#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

/* One hidden child tree. Assignment happens while the initial thread is
   suspended, so the interpreter launcher cannot create an unassigned child. */
int wmain(int argc, wchar_t **argv) {
    if (argc != 10) return 64;
    const DWORD wall_ms = wcstoul(argv[1], NULL, 10);
    const SIZE_T memory_bytes = (SIZE_T)_wcstoui64(argv[2], NULL, 10);
    HANDLE job = NULL, out = INVALID_HANDLE_VALUE, err = INVALID_HANDLE_VALUE;
    HANDLE input = INVALID_HANDLE_VALUE;
    PROCESS_INFORMATION pi = {0}; STARTUPINFOW si = {0};
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limit = {0}, peak = {0};
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION accounting = {0};
    SECURITY_ATTRIBUTES inherit = {sizeof(SECURITY_ATTRIBUTES), NULL, TRUE};
    DWORD failure = 0, exit_code = STILL_ACTIVE, reason = 0;
    BOOL assigned = FALSE, resumed = FALSE, closed = FALSE;
    ULONGLONG start = GetTickCount64(), drain_start = 0;
    wchar_t *command = _wcsdup(argv[7]);
    if (!command) { failure = ERROR_NOT_ENOUGH_MEMORY; goto cleanup; }
    job = CreateJobObjectW(NULL, NULL);
    if (!job) { failure = GetLastError(); goto cleanup; }
    limit.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE | JOB_OBJECT_LIMIT_JOB_MEMORY;
    limit.JobMemoryLimit = memory_bytes;
    if (!SetInformationJobObject(job, JobObjectExtendedLimitInformation, &limit, sizeof(limit))) { failure = GetLastError(); goto cleanup; }
    out = CreateFileW(argv[4], GENERIC_WRITE, FILE_SHARE_READ, &inherit, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    err = CreateFileW(argv[5], GENERIC_WRITE, FILE_SHARE_READ, &inherit, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    input = CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE, &inherit, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (out == INVALID_HANDLE_VALUE || err == INVALID_HANDLE_VALUE || input == INVALID_HANDLE_VALUE) { failure = GetLastError(); goto cleanup; }
    si.cb = sizeof(si); si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdOutput = out; si.hStdError = err; si.hStdInput = input;
    if (!CreateProcessW(NULL, command, NULL, NULL, TRUE, CREATE_SUSPENDED|CREATE_NO_WINDOW, NULL, argv[8], &si, &pi)) { failure = GetLastError(); goto cleanup; }
    if (!AssignProcessToJobObject(job, pi.hProcess)) { failure = GetLastError(); goto cleanup; }
    assigned = TRUE;
    if (ResumeThread(pi.hThread) == (DWORD)-1) { failure = GetLastError(); goto cleanup; }
    resumed = TRUE; CloseHandle(pi.hThread); pi.hThread = NULL;
    for (;;) {
        if (!QueryInformationJobObject(job, JobObjectBasicAccountingInformation, &accounting, sizeof(accounting), NULL)) { failure = GetLastError(); break; }
        if (!accounting.ActiveProcesses) { closed = TRUE; break; }
        if (GetFileAttributesW(argv[6]) != INVALID_FILE_ATTRIBUTES) reason = 2;
        else if (GetTickCount64() - start >= wall_ms) reason = 1;
        if (reason) {
            if (!TerminateJobObject(job, 124)) { failure = GetLastError(); break; }
            drain_start = GetTickCount64();
            while (GetTickCount64() - drain_start < 5000) {
                if (!QueryInformationJobObject(job, JobObjectBasicAccountingInformation, &accounting, sizeof(accounting), NULL)) { failure = GetLastError(); break; }
                if (!accounting.ActiveProcesses) { closed = TRUE; break; }
                Sleep(10);
            }
            break;
        }
        Sleep(10);
    }
cleanup:
    if (pi.hProcess && (!closed || !assigned)) TerminateProcess(pi.hProcess, 125);
    if (job) {
        if (!closed) TerminateJobObject(job, 125);
        QueryInformationJobObject(job, JobObjectExtendedLimitInformation, &peak, sizeof(peak), NULL);
        QueryInformationJobObject(job, JobObjectBasicAccountingInformation, &accounting, sizeof(accounting), NULL);
    }
    if (pi.hProcess) { WaitForSingleObject(pi.hProcess, 5000); GetExitCodeProcess(pi.hProcess, &exit_code); }
    HANDLE report = CreateFileW(argv[3], GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    if (report != INVALID_HANDLE_VALUE) {
        char buffer[4096]; DWORD written = 0;
        int length = snprintf(buffer, sizeof(buffer), "{\n  \"error_code\": %lu,\n  \"reason_code\": %lu,\n  \"root_pid\": %lu,\n  \"root_exit_code\": %lu,\n  \"assigned_before_resume\": %s,\n  \"resumed\": %s,\n  \"closed\": %s,\n  \"active_processes\": %lu,\n  \"total_processes\": %lu,\n  \"terminated_processes\": %lu,\n  \"limit_flags\": %lu,\n  \"job_committed_memory_limit\": %llu,\n  \"peak_job_committed_memory\": %llu,\n  \"peak_single_process_committed_memory\": %llu,\n  \"complete_ms\": %llu,\n  \"maximum_ms\": %lu\n}\n",
            failure, reason, pi.dwProcessId, exit_code, assigned?"true":"false", resumed?"true":"false", closed?"true":"false", accounting.ActiveProcesses, accounting.TotalProcesses, accounting.TotalTerminatedProcesses,
            peak.BasicLimitInformation.LimitFlags, (unsigned long long)peak.JobMemoryLimit, (unsigned long long)peak.PeakJobMemoryUsed, (unsigned long long)peak.PeakProcessMemoryUsed,
            (unsigned long long)(GetTickCount64()-start), wall_ms);
        if (length < 0 || length >= (int)sizeof(buffer) || !WriteFile(report, buffer, (DWORD)length, &written, NULL) || written != (DWORD)length) failure = ERROR_WRITE_FAULT;
        CloseHandle(report);
    } else if (!failure) failure = GetLastError() ? GetLastError() : ERROR_WRITE_FAULT;
    if (pi.hThread) CloseHandle(pi.hThread);
    if (pi.hProcess) CloseHandle(pi.hProcess);
    if (input != INVALID_HANDLE_VALUE) CloseHandle(input);
    if (out != INVALID_HANDLE_VALUE) CloseHandle(out);
    if (err != INVALID_HANDLE_VALUE) CloseHandle(err);
    if (job) CloseHandle(job);
    free(command);
    return failure || !closed ? 125 : reason ? 124 : exit_code == 0 ? 0 : 126;
}
