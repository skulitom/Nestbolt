from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import subprocess,time,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-windows-job-controls-v2-20261107';OUT.mkdir()
SRC=ROOT/'output/h5_windows_job_runner_v2_20261107.c';WORKER=ROOT/'output/h5_job_control_worker_20261107.py';EXE=OUT/'job-runner.exe'
PY=ROOT/'.cache/h5-sat-venv-20261106/Scripts/python.exe';GCC=Path('C:/msys64/mingw64/bin/gcc.exe')
def write(name,data):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(data,f,indent=2);f.write('\n')
args=[str(GCC),str(SRC),'-std=c11','-Wall','-Wextra','-Werror','-O2','-municode','-o',str(EXE)]
r=subprocess.run(args,capture_output=True,timeout=60);(OUT/'build-stdout.txt').write_bytes(r.stdout);(OUT/'build-stderr.txt').write_bytes(r.stderr)
write('build.json',{'command':args,'exit_code':r.returncode,'source_sha256':sha256(SRC.read_bytes()).hexdigest(),'compiler_sha256':sha256(GCC.read_bytes()).hexdigest()});assert r.returncode==0,r.stderr.decode()
write('plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'runner_sha256':sha256(EXE.read_bytes()).hexdigest(),'worker_sha256':sha256(WORKER.read_bytes()).hexdigest(),'controls':['normal-parent-exits-before-child','timeout-with-grandchild','aggregate-memory-denial'],'timeout_control_ms':2000,'other_control_ms':10000,'memory_control_bytes':128*1024*1024,'per_child_allocation_bytes':80*1024*1024,'research_calls':0,'sources':['https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects','https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information','https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-assignprocesstojobobject']})
records=[]
for name,mode,ms,mem in [('normal','normal-parent',10000,512*1024*1024),('timeout','timeout-parent',2000,512*1024*1024),('memory','memory-parent',10000,128*1024*1024)]:
    folder=OUT/name;folder.mkdir()
    command=subprocess.list2cmdline([str(PY),str(WORKER),mode,str(folder)])
    args=[str(EXE),str(ms),str(mem),str(folder/'job.json'),str(folder/'stdout.txt'),str(folder/'stderr.txt'),str(folder/'stop'),command,str(ROOT),'version1']
    t=time.perf_counter();r=subprocess.run(args,capture_output=True,timeout=20)
    (folder/'runner-stdout.txt').write_bytes(r.stdout);(folder/'runner-stderr.txt').write_bytes(r.stderr)
    job=json.loads((folder/'job.json').read_bytes());records.append({'control':name,'runner_exit_code':r.returncode,'outer_seconds':time.perf_counter()-t,'job':job})
    write(name+'-process.json',records[-1])
    assert job['error_code']==0 and job['closed'] and job['active_processes']==0 and job['assigned_before_resume'] and job['total_processes']>=4,job
    assert job['limit_flags']==0x2200 and job['job_committed_memory_limit']==mem and job['peak_job_committed_memory']<=mem
    if name=='normal':assert r.returncode==0 and job['reason_code']==0 and (folder/'normal-child.json').exists()
    elif name=='timeout':assert r.returncode==124 and job['reason_code']==1 and (folder/'sleep-child.json').exists() and job['complete_ms']<3000
    else:
        children=[json.loads((folder/f'memory-{i}.json').read_bytes()) for i in range(2)]
        assert r.returncode==0 and job['reason_code']==0 and sum(c['allocated'] for c in children)==1
        assert any(c.get('memory_error') for c in children) and job['peak_job_committed_memory']>80*1024*1024
write('checks.json',{'passed':True,'controls':records,'research_calls':0,'runner_sha256':sha256(EXE.read_bytes()).hexdigest(),'all_children_in_job_before_initial_resume':True,'all_jobs_active_process_count_zero':True,'aggregate_committed_memory_enforced':True,'parent_may_exit_before_child':True,'timeout_terminates_complete_tree':True})
print('Windows job controls passed')
