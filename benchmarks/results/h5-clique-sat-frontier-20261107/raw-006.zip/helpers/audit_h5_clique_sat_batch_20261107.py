from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];B=ROOT/'output/h5-first57-clique-sat-batch-20261107';OUT=B/'audit';OUT.mkdir()
load=lambda p:json.loads(p.read_bytes());start=time.perf_counter();plan=load(B/'plan.json');process=load(B/'process.json')
assert process['closed'] and process['all_attempted_trees_closed'] and process['global_cap_overrun_seconds']==0
for name,h in plan['inputs'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h
baseline=load(ROOT/plan['baseline_frontier']);assert len(baseline)==25
def sites(row):return tuple(row['empty_sites'] if 'empty_sites' in row else row['source_selection']['empty_sites'])
basechoices={sites(row) for row in baseline};assert len(basechoices)==25
verified=[];witnesses=[];unresolved=[];records=[];attempted=0;clause_sum=0;pair_sum=0;gate_sum=0;proof_bytes=0
for row in plan['selection']:
    for entry in row['scripts'].values():assert sha256((ROOT/entry['path']).read_bytes()).hexdigest()==entry['sha256']
    empty=tuple(row['empty_sites']);assert empty in basechoices and empty not in [(0,5,11),(0,5,12),(4,5,10)]
    p=B/f"case-{row['graph_index']:02d}-record.json"
    if not p.exists():unresolved.append({'empty_sites':list(empty),'reason':'unattempted'});continue
    attempted+=1;record=load(p);assert record['empty_sites']==row['empty_sites'] and record['graph_index']==row['graph_index']
    for stage in record['stages']:
        job=stage['job'];assert job['closed'] and job['active_processes']==0
        assert stage==load(B/f"case-{row['graph_index']:02d}-{stage['stage']}.json")
    if not record['all_stages_passed']:
        unresolved.append({'empty_sites':list(empty),'reason':'preserved stage failure'});records.append(record);continue
    M=ROOT/'output'/row['model'];C=ROOT/'output'/row['call'];A=ROOT/'output'/row['result_audit']
    mp=load(M/'plan.json');mc=load(M/'checks.json');ma=load(M/'audit.json');call=load(C/'process.json');answer=load(A/'checks.json')
    assert mc['passed'] and ma['passed'] and answer['passed'] and answer==record['result']
    assert mp['source_selection']['empty_sites']==list(empty)==answer['source_selection']['empty_sites']
    for name,h in mp['inputs'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h
    modelhash=sha256((M/'model.cnf').read_bytes()).hexdigest();assert modelhash==mc['model_sha256']==ma['model_sha256']==answer['model_sha256']
    assert ma['all_clauses_verified']==mc['clauses'] and ma['single_cell_capacity_proofs']==mc['nodes']
    assert call['closed'] and call['job']['active_processes']==0 and call['solver_calls_started']==1
    clause_sum+=ma['all_clauses_verified'];pair_sum+=ma['every_graph_pair_checked'];gate_sum+=ma['acyclic_threshold_gates']
    if answer['proof_verified']:
        native=call['job'];sr=load(C/'result.json');checker=load(A/'checker-process.json');conversion=load(A/'conversion.json');opened=load(A/'checker-opened.json')
        assert answer['solver_status']=='UNSAT' and answer['valid_complete_process'] and sr['status']=='UNSAT'
        assert call['exit_code']==0 and call['limit_reason'] is None and call['complete_process_cap_overrun_seconds']==0
        assert native['reason_code']==0 and native['error_code']==0 and native['peak_job_committed_memory']<=mp['solver_aggregate_committed_memory_bytes']
        assert sr['search_seconds']<=mp['solver_search_seconds'] and sr['proof_bytes']<=mp['binary_proof_byte_limit']
        raw=C/'proof.drat.bin';text=A/'proof.drat.txt'
        assert conversion['exact_round_trip_passed'] and sha256(raw.read_bytes()).hexdigest()==conversion['binary_sha256'] and sha256(text.read_bytes()).hexdigest()==conversion['text_sha256']==opened['proof_sha256']
        assert opened['formula_sha256']==modelhash and checker['closed'] and checker['exit_code']==0 and checker['verified'] and not checker['timeout'] and checker['process_cap_overrun_seconds']==0
        assert any(line.strip()==b's VERIFIED' for line in (A/'checker-stdout.txt').read_bytes().splitlines())
        verified.append(empty);proof_bytes+=raw.stat().st_size
    elif answer['assignment_verified']:
        assert answer['solver_status']=='SAT' and answer['source_valid_placements']==0
        witness=load(A/'necessary-graph-witness.json');assert not witness['source_valid_placement'];witnesses.append(empty)
    else:unresolved.append({'empty_sites':list(empty),'reason':answer['classification']})
    records.append({'empty_sites':list(empty),'graph_index':row['graph_index'],'solver_status':answer['solver_status'],'proof_verified':answer['proof_verified'],'assignment_verified':answer['assignment_verified'],'model_clauses':mc['clauses'],'threshold_gates':mc['threshold_gates'],'complete_call_seconds':call['complete_process_seconds'],'search_seconds':load(C/'result.json').get('search_seconds') if (C/'result.json').exists() else None,'response_audit':str(A.relative_to(ROOT)/'checks.json')})
assert attempted==process['cases_attempted'] and len(set(verified))==len(verified) and set(verified)<=basechoices
remaining=[r for r in baseline if sites(r) not in set(verified)]
result={'passed':True,'cases_frozen':len(plan['selection']),'cases_attempted':attempted,'cases_not_attempted':len(plan['selection'])-attempted,'new_verified_exclusions':len(verified),'new_graph_witnesses':len(witnesses),'batch_unresolved':len(unresolved),'remaining_fixed29_choices':len(remaining),'total_excluded_at_required_clearance':455-len(remaining),'previous_zero_clearance_exclusions':427,'source_valid_placements':0,'whole_allocation_candidates':440,'model_clauses_verified':clause_sum,'graph_pairs_verified':pair_sum,'threshold_gates_verified':gate_sum,'accepted_binary_proof_bytes':proof_bytes,'batch_complete_seconds':process['complete_seconds'],'aggregate_audit_seconds':time.perf_counter()-start,'completion_percent':60,'H2_complete':False,'H5_complete':False,'old_pilot_repeated':False,'prior_checked_case_repeated':False,'scope':'Original0.2mm clearance, fixed29/current12referencecog poses only. No zero-clearance or whole-allocation exclusion follows.'}
for name,value in [('checks.json',result),('new-exclusions.json',verified),('necessary-graph-witnesses.json',witnesses),('unresolved.json',unresolved),('case-results.json',records),('remaining-fixed29-choices.json',remaining)]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(result)
