from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];raw=ROOT/'output/h5-first57-clique-sat-batch-10-call-20261107/proof.drat.bin';data=raw.read_bytes();p=0;clauses=0;adds=0;deletes=0;empty_end=None;failure=None
try:
    while p<len(data):
        op=data[p];p+=1
        if op not in (97,100):raise ValueError('invalid operation')
        literals=0
        while True:
            value=0;shift=0
            while True:
                if p>=len(data):raise ValueError('truncated varint')
                if shift>28:raise ValueError('oversized varint')
                b=data[p];p+=1;value|=(b&127)<<shift;shift+=7
                if b<128:break
            if value==0:break
            if value<2:raise ValueError('invalid zero-variable literal')
            literals+=1
        clauses+=1;adds+=op==97;deletes+=op==100
        if op==97 and literals==0:
            empty_end=p;break
except ValueError as e:failure={'byte_offset':p,'reason':str(e)}
result={'source':raw.relative_to(ROOT).as_posix(),'source_sha256':sha256(data).hexdigest(),'source_bytes':len(data),'first_empty_addition_end_offset':empty_end,'complete_prefix_bytes':empty_end,'complete_prefix_sha256':sha256(data[:empty_end]).hexdigest() if empty_end else None,'clauses_to_first_empty':clauses,'additions':adds,'deletions':deletes,'parse_failure_before_empty':failure,'suffix_bytes':len(data)-empty_end if empty_end else None,'certificate_verified':False,'search_calls':0,'checker_calls':0}
with (ROOT/'output/h5-post-error-proof-prefix-inspection-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
print(result)
