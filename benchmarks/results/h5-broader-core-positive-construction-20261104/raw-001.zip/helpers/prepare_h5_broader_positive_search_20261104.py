from pathlib import Path
O=Path(__file__).resolve().parent
for old,new in [('check_h5_edge_single_choice_candidate_20261104.py','check_h5_broader_positive_candidate_20261104.py'),('run_h5_edge_single_choice_model_20261104.py','run_h5_broader_positive_model_20261104.py')]:
    s=(O/old).read_text(encoding='utf-8')
    s=s.replace('h5-first57-edge-single-choice-regions','h5-first57-broader-positive-regions')
    s=s.replace('check_h5_edge_single_choice_candidate_20261104.py','check_h5_broader_positive_candidate_20261104.py')
    s=s.replace("'fixed33.json'","'fixed29.json'").replace("'group-counts.json'","'selection.json'")
    s=s.replace('empty==[4,5,10]','empty==[5,11,14]')
    with (O/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Frozen single broad-model call and original66 source reader.')
