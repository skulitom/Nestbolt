"""Retain every original mover; use the new broad positive unary cover."""
from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'build_h5_edge_single_choice_model_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-edge-single-choice-regions','h5-first57-broader-positive-regions')
s=s.replace("EDGE=ROOT/'output/h5-first57-edge-companion-v2-20261104'","EDGE=ROOT/'output/h5-first57-disjoint-movers-20261104'")
s=s.replace("# Identical bracket copies can be relabelled: reserve copy9 for the one-body group.","# All original bracket and insert copies remain movable.")
s=s.replace("group=(1 if owner['identity']==['bracket',9] else 0) if family=='bracket' else None","group=None")
s=s.replace("[('bracket',0),('insert',None)]","[('bracket',None),('insert',None)]")
s=s.replace("'omitted_cog_sites':[4,5,10],'bracket_group_counts':[5,1]","'omitted_cog_sites':[5,11,14],'required_family_counts':{'bracket':8,'insert':8}")
s=s.replace("EDGE/'model/final-preparation-charges.json'","EDGE/'model-factorized/final-preparation-charges.json'")
a=s.index('processes={');b=s.index('for name,folder in processes.items():',a)
s=s[:a]+"""processes={
    'necessary_source_bodies_complete_process_seconds':'h5-first57-necessary-rectangles-process-20261104',
    'necessary_full_stock_cover_complete_process_seconds':'h5-first57-necessary-mask-cover-process-20261104',
    'necessary_component_capacities_complete_process_seconds':'h5-first57-component-area-process-20261104',
    'broader_joint_capacities_complete_process_seconds':'h5-first57-broader-joint-capacities-process-20261104',
    'failed_direct_insert_control_complete_process_seconds':'h5-first57-broader-insert-pocket-process-20261104',
    'broader_positive_regions_complete_process_seconds':'h5-first57-broader-positive-regions-process-20261104'}
"""+s[b:]
s=s.replace('prepare_h5_single_choice_model_builder_20261104.py','prepare_h5_broader_model_helpers_20261104.py')
s=s.replace("'fixed33.json','group-counts.json'","'fixed29.json','selection.json'")
a=s.index("    'method':'New single-selection region model.");b=s.index("    'algorithm_seconds':60",a)
s=s[:a]+"""    'method':'New fixed29 broad construction with all8 brackets and8 inserts movable, and selected12 cog poses excluding5,11,14. Every original mover selects one independently source-safe positive region and one legal mode. All24 component rectangles remain rigidly linked and16 moving-pair groups cover every268 different-owner component pair. X ordering only relabels identical copies within each family. The complete selection ledger includes all upstream necessary rectangle, mask and455-choice capacity work, the fresh joint comparison, the failed direct insert control, positive geometry and complete model build. No old model response, placement or hint is consumed.',
"""+s[b:]
s=s.replace("'owners':12,'legal_mode_selectors':72","'owners':16,'legal_mode_selectors':96").replace("'rigid_components':18","'rigid_components':24")
s=s.replace("'bracket_counts':[5,1]","'required_family_counts':{'bracket':8,'insert':8}")
with (O/'build_h5_broader_positive_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for old,new in [('run_h5_edge_single_choice_model_build_20261104.py','run_h5_broader_positive_model_build_20261104.py'),('finalize_h5_edge_single_choice_budget_20261104.py','finalize_h5_broader_positive_budget_20261104.py')]:
    s=(O/old).read_text(encoding='utf-8').replace('h5-first57-edge-single-choice-regions','h5-first57-broader-positive-regions').replace('h5-first57-edge-single-choice-model-process','h5-first57-broader-positive-model-process').replace('build_h5_edge_single_choice_model','build_h5_broader_positive_model')
    with (O/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared all16 original-mover model and complete selection-charge ledger.')
