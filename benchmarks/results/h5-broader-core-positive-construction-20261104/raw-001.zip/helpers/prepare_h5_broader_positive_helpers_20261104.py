"""Build new full-stock positive unary regions for the broader fixed29 construction."""
from pathlib import Path
O=Path(__file__).resolve().parent
old=(O/'prepare_h5_edge_single_choice_regions_20261104.py').read_text(encoding='utf-8')
prefix='''from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-broader-positive-regions-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104';OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
JOINT=ROOT/'output/h5-first57-broader-joint-capacities-20261104';FAILED=ROOT/'output/h5-first57-broader-insert-pocket-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),ROOT/'output/prepare_h5_broader_positive_helpers_20261104.py',ROOT/'output/prepare_h5_edge_single_choice_regions_20261104.py',ROOT/'output/h5_legacy64_source_readback.py',JOB]+[PRE/n for n in ['plan.json','audit/plan.json','audit/checks.json','fixed29.json','source-cog-sites.json','inventory.json']]+[MOV/n for n in ['audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json']]+[OBS/n for n in ['audit/plan.json','audit/checks.json','source-cover-obstacles.json']]+[JOINT/n for n in ['audit/plan.json','audit/checks.json','audit/verified-choices.json']]+[FAILED/n for n in ['audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Release both earlier edge brackets and both adjoining inserts. Use original fixed29 and all16 orthogonal movers, selecting the surviving broad cog choice with largest exact joint reachable area, lexicographic tie break. Rebuild full-stock positive unary integer domains from audited source-covering rectangles for every original mode and fixed source. Every forbidden open overlap box is converted to an exact half-open interval of integer anchors; a complete arrangement/free-box cover retains every integer anchor safe under these conservative covers. No necessary group clipping or fixed30 from the failed insert control is used. Independent event-count/source readback is required before a new model.',
    'coordinate_units_per_mm':100,'moving_right_top_extension_grid':23,'fixed_source_covers_already_expanded':True,
    'preparation_cap_seconds':25,'maximum_process_seconds':35,'maximum_cells_per_mode':40000000,'solver_calls':0,'native_calls':0})
for base in [PRE,MOV,OBS,JOINT,FAILED]:assert load(base/'audit/checks.json')['passed']
assert not load(FAILED/'audit/checks.json')['fixed30_use_permitted']
candidates=[r for r in load(JOINT/'audit/verified-choices.json') if not r['excluded']]
chosen=min(candidates,key=lambda r:(-sum(g['exact_area_um2'] for g in r['groups']),r['empty_sites']))
empty=chosen['empty_sites'];assert empty==[5,11,14]
modes=load(MOV/'family-modes.json');rects=load(MOV/'mode-rectangles.json')
obstacles=[r for r in load(OBS/'source-cover-obstacles.json') if r['site_bit'] not in empty]
assert len(obstacles)==5249 and {r['site_bit'] for r in obstacles}==set(range(16))-set(empty)
write(OUT/'active-source-cover-obstacles.json',obstacles)
fixed=load(PRE/'fixed29.json');sites=load(PRE/'source-cog-sites.json')
control=fixed+[r for i,r in enumerate(sites) if i not in empty];spec=load(PRE/'plan.json')
checked=audit(load(JOB),control,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in control])
assert len(control)==41 and checked['valid']
write(OUT/'source41.json',control);write(OUT/'source-checks.json',checked)
summaries=[];regions=[]
'''
loop=old[old.index("for family in ['bracket','insert']:"):old.index("for name in ['family-modes.json'")]
a=loop.index("        if family=='insert':");b=loop.index("        write(OUT/f'{tag}-forbidden.json'")
loop=loop[:a]+"""        for bi,box in enumerate(boxes):mode_regions.append({'family':family,'mode':mi,'group':None,'positive_box':bi,'necessary_box':None,'bounds_grid':box[:4]})
"""+loop[b:]
suffix='''for name in ['family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','inventory.json']:shutil.copyfile(MOV/name,OUT/name)
shutil.copyfile(PRE/'fixed29.json',OUT/'fixed29.json')
write(OUT/'regions.json',regions);write(OUT/'mode-summaries.json',summaries)
write(OUT/'selection.json',{'omitted_cog_sites':empty,'required_brackets':8,'required_inserts':8,'joint_reachable_area_um2':sum(g['exact_area_um2'] for g in chosen['groups']),'failed_fixed30_used':False})
checks={'prepared':True,'seconds':time.perf_counter()-started,'active_source_cover_obstacles':len(obstacles),'legal_modes':12,
    'all_integer_cells':sum(r['cells'] for r in summaries),'positive_free_boxes':sum(r['free_boxes'] for r in summaries),'construction_regions':len(regions),
    'bracket_regions':sum(r['family']=='bracket' for r in regions),'insert_regions':sum(r['family']=='insert' for r in regions),
    'source_valid41':True,'remaining_movers':16,'source_valid66':False,'independent_positive_region_audit_pending':True,'continuous_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
'''
with (O/'prepare_h5_broader_positive_regions_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+loop+suffix)
wrapper=(O/'run_h5_edge_single_choice_regions_20261104.py').read_text(encoding='utf-8').replace('h5-first57-edge-single-choice-regions-process','h5-first57-broader-positive-regions-process').replace('prepare_h5_edge_single_choice_regions','prepare_h5_broader_positive_regions')
with (O/'run_h5_broader_positive_regions_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(wrapper)
print('Prepared fresh fixed29 positive regions for all8 brackets and8 inserts.')
