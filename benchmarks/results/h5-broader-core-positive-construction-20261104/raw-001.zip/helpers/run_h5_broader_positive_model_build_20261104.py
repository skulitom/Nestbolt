from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-broader-positive-model-process-20261104';SCRIPT=ROOT/'output/build_h5_broader_positive_model_20261104.py'
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter()
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'script':SCRIPT.relative_to(ROOT).as_posix(),'script_sha256':sha256(SCRIPT.read_bytes()).hexdigest(),'maximum_process_seconds':25,'retry_permitted':False})
try:
    r=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(SCRIPT)],cwd=ROOT,capture_output=True,timeout=25)
    result={'exit_code':r.returncode,'timeout':False};stdout,stderr=r.stdout,r.stderr
except subprocess.TimeoutExpired as e:
    result={'timeout':True};stdout,stderr=e.stdout or b'',e.stderr or b''
(OUT/'stdout.txt').write_bytes(stdout);(OUT/'stderr.txt').write_bytes(stderr)
elapsed=time.perf_counter()-started;result.update({'complete_process_seconds':elapsed,'complete_process_cap_overrun_seconds':max(0,elapsed-25),'closed':True})
write(OUT/'process.json',result);print(result);print(stdout.decode(errors='replace'));print(stderr.decode(errors='replace'))
