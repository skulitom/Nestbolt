from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_edge_single_choice_model_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-edge-single-choice-regions','h5-first57-broader-positive-regions')
s=s.replace("EDGE=ROOT/'output/h5-first57-edge-companion-v2-20261104'","EDGE=ROOT/'output/h5-first57-disjoint-movers-20261104'")
s=s.replace("mapping['omitted_cog_sites']==[4,5,10] and mapping['bracket_group_counts']==[5,1]","mapping['omitted_cog_sites']==[5,11,14] and mapping['required_family_counts']=={'bracket':8,'insert':8}")
s=s.replace("len(instances)==12","len(instances)==16")
s=s.replace("region_count=0;counts=[0,0]","region_count=0;counts={'bracket':0,'insert':0}")
s=s.replace("group=(1 if o['identity']==['bracket',9] else 0) if family=='bracket' else None","group=None")
s=s.replace("if family=='bracket':counts[group]+=1","counts[family]+=1").replace("assert counts==[5,1]","assert counts=={'bracket':8,'insert':8}")
s=s.replace("len(raw_components)==18","len(raw_components)==24").replace("len(groups)==8","len(groups)==16")
s=s.replace("[('bracket',0),('insert',None)]","[('bracket',None),('insert',None)]")
s=s.replace("EDGE/'model/final-preparation-charges.json'","EDGE/'model-factorized/final-preparation-charges.json'")
a=s.index('processes={');b=s.index('for key,folder in processes.items():',a)
s=s[:a]+"""processes={
    'necessary_source_bodies_complete_process_seconds':'h5-first57-necessary-rectangles-process-20261104',
    'necessary_full_stock_cover_complete_process_seconds':'h5-first57-necessary-mask-cover-process-20261104',
    'necessary_component_capacities_complete_process_seconds':'h5-first57-component-area-process-20261104',
    'broader_joint_capacities_complete_process_seconds':'h5-first57-broader-joint-capacities-process-20261104',
    'failed_direct_insert_control_complete_process_seconds':'h5-first57-broader-insert-pocket-process-20261104',
    'broader_positive_regions_complete_process_seconds':'h5-first57-broader-positive-regions-process-20261104',
    'model_complete_process_seconds':'h5-first57-broader-positive-model-process-20261104'}
"""+s[b:]
s=s.replace('==3111','==7672').replace('==6611','==15870').replace('mode_count==72','mode_count==96').replace('links==480','links==640').replace('region_count==2907','region_count==7400')
s=s.replace('prepare_h5_single_choice_model_auditor_20261104.py','prepare_h5_broader_model_auditor_20261104.py')
s=s.replace("'group-counts.json'","'selection.json'")
s=s.replace('All18','All24').replace('eight groups preserve all147','sixteen groups preserve all268')
s=s.replace('Identical bracket copies are relabelled into necessary groups of five and one, with no cross-group symmetry ordering.','All8 bracket and8 insert copies remain freely movable, with only same-family X ordering.')
s=s.replace("'global_moving_groups_verified':8","'global_moving_groups_verified':16").replace("'mandatory_bracket_group_counts':[5,1]","'required_family_counts':{'bracket':8,'insert':8}").replace("'symmetry_rows_within_group':9","'symmetry_rows_within_family':14")
with (O/'audit_h5_broader_positive_model_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared exhaustive reader for all16-mover broad construction.')
