"""Specialize independent joint-count proof for both largest fixed29 capacity choices."""
from pathlib import Path
O=Path(__file__).resolve().parent
for kind in ['prepare','audit']:
    s=(O/f'{kind}_h5_edge_joint_capacities_20261104.py').read_text(encoding='utf-8')
    s=s.replace('h5-first57-edge-joint-capacities','h5-first57-broader-joint-capacities')
    s=s.replace('h5-first57-edge-combined-sources','h5-first57-necessary-rectangles')
    s=s.replace('h5-first57-edge-necessary-necessary-mask-cover','h5-first57-necessary-mask-cover').replace('h5-first57-edge-insert-mask-cover','h5-first57-necessary-mask-cover')
    s=s.replace("JOB_UNDEFINED_NEVER","JOB_UNDEFINED_NEVER")
    marker="load=lambda p:json.loads(p.read_bytes())"
    s=s.replace(marker,"CAP=ROOT/'output/h5-first57-component-area-20261104'\n"+marker)
    s=s.replace("inputs=[Path(__file__)]","inputs=[Path(__file__),CAP/'audit/plan.json',CAP/'audit/checks.json',CAP/'audit/retained-choices.json']")
    loop="for index,empty in enumerate(i for i in range(15) if i not in [4,10]):"
    select="""assert load(CAP/'audit/checks.json')['passed']
for p,h in load(CAP/'audit/plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
retained=load(CAP/'audit/retained-choices.json')
largest=max(r['bracket_capacity'] for r in retained)
selected=[r['empty_sites'] for r in retained if r['bracket_capacity']==largest]
assert largest==12 and selected==[[5,11,13],[5,11,14]]
for index,empty in enumerate(selected):"""
    assert loop in s;s=s.replace(loop,select)
    s=s.replace('bits=1<<empty','bits=sum(1<<i for i in empty)').replace('~(1<<empty)','~sum(1<<i for i in empty)')
    s=s.replace("r['site_bit']!=empty","r['site_bit'] not in empty")
    s=s.replace("'additional_empty_site'","'empty_sites'").replace("'fixed33_scope_only'","'fixed29_scope_only'")
    s=s.replace('fixed33','fixed29').replace('all13','both largest-capacity').replace('of13 one-more-empty cog choices','of the two largest-capacity three-empty cog choices')
    s=s.replace('required six brackets/six inserts','required eight brackets/eight inserts').replace('Each family requires six copies','Each family requires eight copies')
    s=s.replace("'required_brackets':6","'required_brackets':8").replace("'required_inserts':6","'required_inserts':8")
    s=s.replace('range(7','range(9').replace('[False]*7','[False]*9').replace('<=6','<=8').replace('(6,6)','(8,8)').replace('state[6][6]','state[8][8]')
    s=s.replace("'choices':13","'choices':2").replace("'choices_verified':13","'choices_verified':2").replace('len(actual)==13','len(actual)==2').replace('range(13)','range(2)')
    if kind=='audit':
        s=s.replace("inputs=[Path(__file__),HELPER","inputs=[Path(__file__),CAP/'audit/plan.json',CAP/'audit/checks.json',CAP/'audit/retained-choices.json',HELPER")
    with (O/f'{kind}_h5_broader_joint_capacities_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_h5_edge_joint_capacities_20261104.py').read_text(encoding='utf-8').replace('h5-first57-edge-joint-capacities','h5-first57-broader-joint-capacities').replace('prepare_h5_edge_joint_capacities','prepare_h5_broader_joint_capacities')
with (O/'run_h5_broader_joint_capacities_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared two-choice continuous-source joint bounds, with required8/8 inventory.')
