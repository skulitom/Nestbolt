from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-broader-core-positive-construction-20261104';OUT=ROOT/'benchmarks/results'/NAME
BASE=ROOT/'output/h5-first57-broader-positive-regions-20261104'
JOINT=ROOT/'output/h5-first57-broader-joint-capacities-20261104';FAILED=ROOT/'output/h5-first57-broader-insert-pocket-20261104'
SYNC=ROOT/'output/h5-shelf-and-single-edge-main-sync-20261104'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
for folder in [BASE/'audit',BASE/'model-audit',BASE/'response-audit',JOINT/'audit',FAILED/'audit']:assert load(folder/'checks.json')['passed']
assert not load(FAILED/'audit/checks.json')['fixed30_use_permitted']
response=load(BASE/'response-audit/checks.json')
assert response['closed_solver_calls']==1 and response['solver_status']=='INFEASIBLE' and response['assignments']==0
assert response['solve_slice_overrun_seconds']==response['algorithm_overrun_seconds']==response['shared_overrun_seconds']==0
assert load(SYNC/'receipt.json')['new_main']=='f8ba0d955ddcc9e1fa34ae112777cace0b264f91'
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')]
setup=setup.replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
folders=[BASE,JOINT,FAILED,SYNC]+[ROOT/'output'/n for n in ['h5-first57-broader-joint-capacities-process-20261104','h5-first57-broader-insert-pocket-process-20261104','h5-first57-broader-positive-regions-process-20261104','h5-first57-broader-positive-model-process-20261104']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for p in (ROOT/'output').glob('*h5_broader*20261104.py'):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-broader-core-positive-report-20261104.md','push_h5_shelf_and_single_edge_checkpoints_20261104.py']:add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(JOINT/'audit/checks.json','joint-capacity-audit.json'),(FAILED/'audit/checks.json','failed-insert-audit.json'),(BASE/'audit/checks.json','region-audit.json'),(BASE/'model-audit/checks.json','model-audit.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'model/final-preparation-charges.json','preparation-charges.json'),(BASE/'search/result.json','closed-result.json'),(SYNC/'receipt.json','main-sync-receipt.json')]:shutil.copyfile(source,OUT/name)
write(OUT/'next-step.json',{'closed_call_must_not_be_repeated':True,'closed_model_sha256':load(BASE/'model-audit/checks.json')['model_sha256'],'closed_status':'INFEASIBLE','continuous_exclusion':False,
    'fixed29_originals':29,'moving_brackets':8,'moving_inserts':8,'omitted_cog_sites':[5,11,14],
    'next_method':'Build a genuinely different positive unary geometry from original convex-source Minkowski obstacles, replacing the conservative2mm cog band rectangles. Keep fixed29, selected12 original cog poses, all16 movers and every source-mode alias. Construct fresh full-physical-stock domains from the current audited mode bounds; include every fixed29 original as an obstacle, not merely the cogs. Inflate source no-fit polygons by0.231mm square and independently certify rounded convex positive regions with exact rational supports against all original fixed/cog convex pieces at0.23mm separation. Mode aliases must each pass. Triangulate and exact-convex merge positive free regions; preserve any numerical/audit failures. Build new inward integer halfplanes with coefficient-rounding error proved over the actual full world-coordinate bounds. The older three-empty masks and grouped integer scripts provide code examples only: their old top-strip domains cannot be imported. Charge all consumed selection, polygon preparation and complete model build before a new audited60/90-second call. No rectangle model retry/reseed/extension.',
    'source_geometry_examples':['output/prepare_h5_first57_three_empty_masks_20261104.py','output/audit_h5_first57_three_empty_masks_20261104.py','output/h5_exact_convex_partition_tools_20261029.py'],
    'new_polygon_construction_prepared':False,'fixed29_choices_remaining':259,'fixed33_choices_remaining':1,'whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'joint_choices_audited':2,'joint_choices_excluded':0,
    'failed_source42_preserved':True,'failed_fixed30_used':False,'source_valid41':True,'positive_integer_cells':214933987,'positive_regions':925,
    'model_variables':7672,'model_constraints':15870,'closed_solver_calls':1,'solver_status':'INFEASIBLE','assignments':0,
    'charged_preparation_seconds':response['preparation_seconds_charged'],'algorithm_seconds_including_preparation':response['algorithm_seconds_including_preparation'],
    'shared_seconds_including_preparation':response['shared_seconds_including_preparation'],'overruns_seconds':0,
    'new_continuous_exclusions':0,'whole_allocation_candidates':440,'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-broader-core-positive-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 broader fixed-core construction:** [independent source/model/response audits]({link}) compare both largest-capacity cog choices for eight brackets/eight inserts; neither is excluded. The selected [5,11,14] direct insert control overlaps cog4 and is preserved as failed, so all sixteen originals remain movable. Fresh positive geometry verifies 214,933,987 integer cells and 925 regions. Every field of the 7,672-variable / 15,870-constraint model passes. Its sole call closes grid-INFEASIBLE in 5.260162 s, without an assignment. Complete preparation is 26.152827 s; algorithm/shared totals 32.216088/32.294957 s pass with zero overruns. No continuous exclusion follows. Next assess original-source polygon obstacles in place of rectangular band covers, with fresh full-stock proofs. Prior checkpoints are normally pushed at f8ba0d95. All 259 broader choices, 440 allocations, full66 validation and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [single edge-choice construction](../benchmarks/results/h5-single-edge-choice-construction-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [broader fixed-core construction](../benchmarks/results/{NAME}.md).',1)
a='placement or overrun. The broader fixed29 frontier remains 259 choices; joint\nbracket/insert bounds for its two largest-capacity choices are next to assess.\nAll prior calls stay closed.'
b='placement or overrun. Both largest-capacity broader choices pass joint bounds.\nA fresh sixteen-mover [5,11,14] model also closes grid-INFEASIBLE, with no overrun.\nThe broader fixed29 frontier remains 259 choices. Original-source polygon\nobstacles, with fresh full-stock proofs, are next to assess. All prior calls stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
