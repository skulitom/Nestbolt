from pathlib import Path
O=Path(__file__).resolve().parent
old=(O/'audit_h5_edge_single_choice_regions_20261104.py').read_text(encoding='utf-8')
prefix='''from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-broader-positive-regions-20261104';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104';OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
JOINT=ROOT/'output/h5-first57-broader-joint-capacities-20261104';FAILED=ROOT/'output/h5-first57-broader-insert-pocket-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,PRE/'audit',MOV/'audit',OBS/'audit',JOINT/'audit',FAILED/'audit']:
    for p,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
for base in [PRE,MOV,OBS,JOINT,FAILED]:assert load(base/'audit/checks.json')['passed']
assert not load(FAILED/'audit/checks.json')['fixed30_use_permitted']
for n in ['family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','inventory.json']:assert digest(BASE/n)==digest(MOV/n)
assert digest(BASE/'fixed29.json')==digest(PRE/'fixed29.json')
ranked=sorted((-sum(g['exact_area_um2'] for g in r['groups']),r['empty_sites']) for r in load(JOINT/'audit/verified-choices.json') if not r['excluded'])
area,empty=ranked[0];assert empty==[5,11,14]
assert load(BASE/'selection.json')=={'omitted_cog_sites':empty,'required_brackets':8,'required_inserts':8,'joint_reachable_area_um2':-area,'failed_fixed30_used':False}
obstacles=[r for r in load(OBS/'source-cover-obstacles.json') if r['site_bit'] not in empty]
assert obstacles==load(BASE/'active-source-cover-obstacles.json') and len(obstacles)==5249
rows=load(PRE/'fixed29.json')+[r for i,r in enumerate(load(PRE/'source-cog-sites.json')) if i not in empty]
spec=load(PRE/'plan.json')
checked=audit(load(JOB),rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows])
assert checked['valid'] and checked==load(BASE/'source-checks.json') and rows==load(BASE/'source41.json') and len(rows)==41
inventory=load(PRE/'inventory.json')
assert sorted([[r['part_id'],r['copy_index']] for r in load(BASE/'fixed29.json')]+[r['identity'] for r in load(BASE/'instances.json')]+inventory['required_cog12_identities']+inventory['short9_identities'])==sorted(inventory['full66_identities'])
modes=load(BASE/'family-modes.json');rects=load(BASE/'mode-rectangles.json');all_regions=[];summaries=[]
'''
loop=old[old.index("for family in ['bracket','insert']:"):old.index("assert summaries==")]
a=loop.index('        # Rebuild intersections');b=loop.index("        assert expected_regions==")
loop=loop[:a]+"""        expected_regions=[{'family':family,'mode':mi,'group':None,'positive_box':i,'necessary_box':None,'bounds_grid':r[:4]} for i,r in enumerate(boxes)]
"""+loop[b:]
suffix='''assert summaries==load(BASE/'mode-summaries.json') and all_regions==load(BASE/'regions.json')
inputs=[Path(__file__),ROOT/'output/prepare_h5_broader_positive_auditor_20261104.py',ROOT/'output/audit_h5_edge_single_choice_regions_20261104.py',ROOT/'output/h5_legacy64_source_readback.py',JOB]+[BASE/n for n in ['plan.json','checks.json','active-source-cover-obstacles.json','source41.json','source-checks.json','regions.json','mode-summaries.json','selection.json','family-modes.json','mode-rectangles.json']]+[base/n for base in [PRE,MOV,OBS,JOINT,FAILED] for n in ['audit/plan.json','audit/checks.json']]+[BASE/f'{family}-{m["mode"]:02d}-{suffix}' for family in ['bracket','insert'] for m in modes[family] for suffix in ['classes.npz','forbidden.json','free-boxes.json','regions.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Every world obstacle and full-stock moving source-covering rectangle is identical to independently certified geometry. Their right/top expansions imply at least0.23mm separation. Every integer anchor yielding component/obstacle overlap is represented by a reconstructed half-open forbidden rectangle. A separate event-count replay verifies all blocked cells and every free cell is covered once. Each positive region is exactly a free box. All16 original movers and full66 identity partition are preserved; the failed fixed30 control is not used. Moving-body interactions still require a model and original66 readback. This proof yields no continuous exclusion.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'active_source_cover_obstacles':5249,'legal_modes_verified':12,
    'integer_cells_independently_verified':sum(s['cells'] for s in summaries),'positive_free_boxes':sum(s['free_boxes'] for s in summaries),'construction_regions':len(all_regions),
    'bracket_regions':sum(r['family']=='bracket' for r in all_regions),'insert_regions':sum(r['family']=='insert' for r in all_regions),
    'source_valid41':True,'full66_identity_partition_preserved':True,'remaining_movers':16,'failed_fixed30_used':False,'source_valid66':False,'model_prepared':False,
    'continuous_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
'''
with (O/'audit_h5_broader_positive_regions_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+loop+suffix)
print('Prepared independent full-stock source/event replay.')
