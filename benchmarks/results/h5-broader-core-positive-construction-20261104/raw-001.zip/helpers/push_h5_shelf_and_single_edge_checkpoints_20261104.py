"""Push the audited checkpoint normally after all six CI recovery jobs finish successfully."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-shelf-and-single-edge-main-sync-20261104';OLD='c1e500a77dfcaab155a2092a17d5f19bce493238';BRANCH='codex/v1-1-shop-files';NAME='h5-shelf-and-edge-capacity-proofs-20261104'
def command(*args):return subprocess.check_output(args,cwd=ROOT,text=True).strip()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not OUT.exists();new=command('git','rev-parse','HEAD');assert command('git','branch','--show-current')==BRANCH and not command('git','diff','HEAD','--name-only')
paths=command('git','diff','--name-only',OLD+'..'+new).splitlines();allowed={'.gitattributes','BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md'}
assert all(p in allowed or p.startswith(('benchmarks/results/'+NAME,'benchmarks/results/h5-single-edge-choice-construction-20261104')) for p in paths)
ci=json.loads(command('gh','run','view','41922730064','--json','databaseId,status,conclusion,headSha,jobs,url'));assert ci['headSha']==OLD and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs'])
live=json.loads(command('gh','run','list','--branch','main','--limit','100','--json','databaseId,status,conclusion,headSha,workflowName,url'));assert all(r['status']=='completed' for r in live)
refs=dict(reversed(line.split()) for line in command('git','ls-remote','origin','refs/heads/main','refs/heads/'+BRANCH).splitlines());assert refs=={'refs/heads/main':OLD,'refs/heads/'+BRANCH:OLD}
subprocess.run(['git','merge-base','--is-ancestor',OLD,new],cwd=ROOT,check=True);OUT.mkdir();write(OUT/'prior-main-ci.json',ci);write(OUT/'pre-push-live-run-check.json',live);write(OUT/'changed-paths.json',paths)
result=subprocess.run(['git','push','--atomic','origin','HEAD:refs/heads/main','HEAD:refs/heads/'+BRANCH],cwd=ROOT,capture_output=True,text=True)
with (OUT/'push-stdout.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(result.stdout)
with (OUT/'push-stderr.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(result.stderr)
assert result.returncode==0,result.stderr
refs=dict(reversed(line.split()) for line in command('git','ls-remote','origin','refs/heads/main','refs/heads/'+BRANCH).splitlines());assert set(refs.values())=={new}
new_ci=None
for _ in range(15):
    runs=json.loads(command('gh','run','list','--branch','main','--commit',new,'--workflow','Checks','--limit','10','--json','databaseId,status,conclusion,headSha,url'))
    if runs:new_ci=runs[0];break
    time.sleep(2)
receipt={'utc':datetime.now(timezone.utc).isoformat(),'old_main':OLD,'new_main':new,'normal_atomic_fast_forward':True,'working_branch_also_updated':True,'prior_main_all6_pass':True,'prior_CI_run':41922730064,'new_main_CI':new_ci,'evidence_and_documentation_only':True,'live_run_cancelled':False,'older_fixed13_count_distributions':3,'older_fixed13_site_choices':2,'first57_original_site_choices':455,'first57_excluded_site_choices':196,'first57_remaining_site_choices':259,'edge_fixed_originals':33,'edge_necessary_cog_subsets':1,'fixed_shelf_choices_excluded':13,'fixed33_choices_excluded':12,'edge_remaining_orthogonal_movers':12,'edge_positive_region_call_status':'INFEASIBLE','edge_call_continuous_exclusion':False,'remaining_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False,'release_created':False};write(OUT/'receipt.json',receipt);print(receipt)
