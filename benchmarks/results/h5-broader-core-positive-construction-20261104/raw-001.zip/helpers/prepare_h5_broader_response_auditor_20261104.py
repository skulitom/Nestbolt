from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'audit_h5_edge_single_choice_response_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first57-edge-single-choice-regions','h5-first57-broader-positive-regions')
a=s.index('roots=[');b=s.index('queue=list(roots)',a)
s=s[:a]+"""roots=[BASE/'plan.json',MODEL/'plan.json',BASE/'audit/plan.json',BASE/'model-audit/plan.json',SEARCH/'opened.json',MODEL/'final-preparation-charges.json',
    ROOT/'output/h5-disjoint-assignment-reader-controls-20261104/plan.json',
    ROOT/'output/h5-first57-broader-positive-model-process-20261104/opened.json',
    ROOT/'output/h5-first57-broader-positive-regions-process-20261104/opened.json',
    ROOT/'output/h5-first57-broader-insert-pocket-process-20261104/opened.json',
    ROOT/'output/h5-first57-broader-joint-capacities-process-20261104/opened.json']
"""+s[b:]
a=s.index('expected={');b=s.index('assert charges==expected',a)
s=s[:a]+"""expected={
    'fixed_source_mode_geometry_preparation_seconds':load(ROOT/'output/h5-first55-after-source-valid11-20261029/checks.json')['seconds'],
    'source_cog_site_preparation_seconds':load(ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight/checks.json')['seconds'],
    'source_rectangle_preparation_seconds':load(ROOT/'output/h5-first55-cog-site-masks-20261029/rigid-rectangle-preflight/checks.json')['seconds']}
for folder,key in [
    ('h5-first57-direct-short9-process-20261104','direct_short9_and_inventory_complete_process_seconds'),
    ('h5-first57-disjoint-obstacles-process-20261104','disjoint_source_obstacles_complete_process_seconds'),
    ('h5-first57-disjoint-movers-process-20261104','full_stock_movers_complete_process_seconds'),
    ('h5-first57-necessary-rectangles-process-20261104','necessary_source_bodies_complete_process_seconds'),
    ('h5-first57-necessary-mask-cover-process-20261104','necessary_full_stock_cover_complete_process_seconds'),
    ('h5-first57-component-area-process-20261104','necessary_component_capacities_complete_process_seconds'),
    ('h5-first57-broader-joint-capacities-process-20261104','broader_joint_capacities_complete_process_seconds'),
    ('h5-first57-broader-insert-pocket-process-20261104','failed_direct_insert_control_complete_process_seconds'),
    ('h5-first57-broader-positive-regions-process-20261104','broader_positive_regions_complete_process_seconds'),
    ('h5-first57-broader-positive-model-process-20261104','model_complete_process_seconds')]:
    p=load(ROOT/'output'/folder/'process.json');assert p['exit_code']==0 and not p['timeout'] and p['closed'];expected[key]=p['complete_process_seconds']
"""+s[b:]
s=s.replace('==3111','==7672').replace('==6611','==15870').replace("'model_variables':3111","'model_variables':7672").replace("'model_constraints':6611","'model_constraints':15870")
s=s.replace('response.num_branches==33983 and response.num_conflicts==422','response.num_branches==59063 and response.num_conflicts==3721')
a=s.index("assert not load(ROOT/'output/h5-first57-edge-companion-20261104/source-cover-preflight/checks.json')")
b=s.index("write(OUT/'source-bindings.json'",a)
s=s[:a]+"""assert load(BASE/'audit/checks.json')['source_valid41'] and load(BASE/'audit/checks.json')['remaining_movers']==16
assert load(ROOT/'output/h5-first57-broader-insert-pocket-20261104/audit/checks.json')['failed_control_preserved']
assert not load(ROOT/'output/h5-first57-broader-insert-pocket-20261104/audit/checks.json')['fixed30_use_permitted']
"""+s[b:]
with (O/'audit_h5_broader_positive_response_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared exact broad-response and complete-ledger auditor.')
