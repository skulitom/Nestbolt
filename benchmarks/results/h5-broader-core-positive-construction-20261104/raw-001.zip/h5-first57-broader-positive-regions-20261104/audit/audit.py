from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-broader-positive-regions-20261104';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104';OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
JOINT=ROOT/'output/h5-first57-broader-joint-capacities-20261104';FAILED=ROOT/'output/h5-first57-broader-insert-pocket-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,PRE/'audit',MOV/'audit',OBS/'audit',JOINT/'audit',FAILED/'audit']:
    for p,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
for base in [PRE,MOV,OBS,JOINT,FAILED]:assert load(base/'audit/checks.json')['passed']
assert not load(FAILED/'audit/checks.json')['fixed30_use_permitted']
for n in ['family-modes.json','mode-rectangles.json','instances.json','components.json','pair-cover-groups.json','pair-cover-certificates.json','inventory.json']:assert digest(BASE/n)==digest(MOV/n)
assert digest(BASE/'fixed29.json')==digest(PRE/'fixed29.json')
ranked=sorted((-sum(g['exact_area_um2'] for g in r['groups']),r['empty_sites']) for r in load(JOINT/'audit/verified-choices.json') if not r['excluded'])
area,empty=ranked[0];assert empty==[5,11,14]
assert load(BASE/'selection.json')=={'omitted_cog_sites':empty,'required_brackets':8,'required_inserts':8,'joint_reachable_area_um2':-area,'failed_fixed30_used':False}
obstacles=[r for r in load(OBS/'source-cover-obstacles.json') if r['site_bit'] not in empty]
assert obstacles==load(BASE/'active-source-cover-obstacles.json') and len(obstacles)==5249
rows=load(PRE/'fixed29.json')+[r for i,r in enumerate(load(PRE/'source-cog-sites.json')) if i not in empty]
spec=load(PRE/'plan.json')
checked=audit(load(JOB),rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows])
assert checked['valid'] and checked==load(BASE/'source-checks.json') and rows==load(BASE/'source41.json') and len(rows)==41
inventory=load(PRE/'inventory.json')
assert sorted([[r['part_id'],r['copy_index']] for r in load(BASE/'fixed29.json')]+[r['identity'] for r in load(BASE/'instances.json')]+inventory['required_cog12_identities']+inventory['short9_identities'])==sorted(inventory['full66_identities'])
modes=load(BASE/'family-modes.json');rects=load(BASE/'mode-rectangles.json');all_regions=[];summaries=[]
for family in ['bracket','insert']:
    for mode in modes[family]:
        mi=mode['mode'];tag=f'{family}-{mi:02d}';dx,dy=mode['integer_lower_left_bounds'];expected=[]
        for oi,obs in enumerate(obstacles):
            for comp in rects[family][mi]['rectangles']:
                a,b,c,d=comp['outward_offsets_grid'];u,v,w,z=obs['bounds_grid']
                open_bounds=(u-c-23,v-d-23,w-a,z-b)
                x0=max(dx[0],open_bounds[0]+1);x1=min(dx[1]+1,open_bounds[2])
                y0=max(dy[0],open_bounds[1]+1);y1=min(dy[1]+1,open_bounds[3])
                if x0<x1 and y0<y1:expected.append({'obstacle':oi,'piece':comp['piece'],'integer_bounds_half_open':[x0,y0,x1,y1]})
        assert expected==load(BASE/f'{tag}-forbidden.json')
        xs=sorted({dx[0],dx[1]+1}|{r['integer_bounds_half_open'][k] for r in expected for k in [0,2]})
        ys=sorted({dy[0],dy[1]+1}|{r['integer_bounds_half_open'][k] for r in expected for k in [1,3]})
        with np.load(BASE/f'{tag}-classes.npz',allow_pickle=False) as data:
            assert set(data.files)=={'xcuts_grid','ycuts_grid','blocked'}
            assert data['xcuts_grid'].dtype==data['ycuts_grid'].dtype==np.dtype('int64')
            assert data['xcuts_grid'].tolist()==xs and data['ycuts_grid'].tolist()==ys
            blocked=data['blocked'];assert blocked.dtype==np.dtype('bool') and blocked.shape==(len(ys)-1,len(xs)-1)
        ix={v:i for i,v in enumerate(xs)};iy={v:i for i,v in enumerate(ys)}
        counts=np.zeros((len(ys),len(xs)),dtype=np.int32)
        for r in expected:
            a,b,c,d=r['integer_bounds_half_open'];xa,xb,ya,yb=ix[a],ix[c],iy[b],iy[d]
            counts[ya,xa]+=1;counts[ya,xb]-=1;counts[yb,xa]-=1;counts[yb,xb]+=1
        np.cumsum(counts,axis=0,out=counts);np.cumsum(counts,axis=1,out=counts)
        assert counts.min()>=0 and counts.max()<=len(expected) and np.array_equal(counts[:-1,:-1]>0,blocked)
        del counts
        boxes=load(BASE/f'{tag}-free-boxes.json');covered=np.zeros(blocked.shape,dtype=np.uint8)
        for row in boxes:
            a,b,c,d,xa,ya,xb,yb=row
            assert all(type(v) is int for v in row) and 0<=xa<xb<len(xs) and 0<=ya<yb<len(ys)
            assert [a,b,c,d]==[xs[xa],ys[ya],xs[xb]-1,ys[yb]-1]
            assert a<=c and b<=d and not blocked[ya:yb,xa:xb].any()
            covered[ya:yb,xa:xb]+=1
        assert np.array_equal(covered,(~blocked).astype(np.uint8))
        expected_regions=[{'family':family,'mode':mi,'group':None,'positive_box':i,'necessary_box':None,'bounds_grid':r[:4]} for i,r in enumerate(boxes)]
        assert expected_regions==load(BASE/f'{tag}-regions.json');all_regions.extend(expected_regions)
        summary={'family':family,'mode':mi,'forbidden_rectangles':len(expected),'cells':int(blocked.size),'free_cells':int((~blocked).sum()),'free_boxes':len(boxes),'construction_regions':len(expected_regions)}
        summaries.append(summary);print(summary,flush=True)
assert summaries==load(BASE/'mode-summaries.json') and all_regions==load(BASE/'regions.json')
inputs=[Path(__file__),ROOT/'output/prepare_h5_broader_positive_auditor_20261104.py',ROOT/'output/audit_h5_edge_single_choice_regions_20261104.py',ROOT/'output/h5_legacy64_source_readback.py',JOB]+[BASE/n for n in ['plan.json','checks.json','active-source-cover-obstacles.json','source41.json','source-checks.json','regions.json','mode-summaries.json','selection.json','family-modes.json','mode-rectangles.json']]+[base/n for base in [PRE,MOV,OBS,JOINT,FAILED] for n in ['audit/plan.json','audit/checks.json']]+[BASE/f'{family}-{m["mode"]:02d}-{suffix}' for family in ['bracket','insert'] for m in modes[family] for suffix in ['classes.npz','forbidden.json','free-boxes.json','regions.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Every world obstacle and full-stock moving source-covering rectangle is identical to independently certified geometry. Their right/top expansions imply at least0.23mm separation. Every integer anchor yielding component/obstacle overlap is represented by a reconstructed half-open forbidden rectangle. A separate event-count replay verifies all blocked cells and every free cell is covered once. Each positive region is exactly a free box. All16 original movers and full66 identity partition are preserved; the failed fixed30 control is not used. Moving-body interactions still require a model and original66 readback. This proof yields no continuous exclusion.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'active_source_cover_obstacles':5249,'legal_modes_verified':12,
    'integer_cells_independently_verified':sum(s['cells'] for s in summaries),'positive_free_boxes':sum(s['free_boxes'] for s in summaries),'construction_regions':len(all_regions),
    'bracket_regions':sum(r['family']=='bracket' for r in all_regions),'insert_regions':sum(r['family']=='insert' for r in all_regions),
    'source_valid41':True,'full66_identity_partition_preserved':True,'remaining_movers':16,'failed_fixed30_used':False,'source_valid66':False,'model_prepared':False,
    'continuous_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
