"""Preserve and independently verify the failed direct insert control."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-broader-insert-pocket-20261104';OUT=BASE/'audit'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104';OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
JOINT=ROOT/'output/h5-first57-broader-joint-capacities-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,PRE/'audit',MOV/'audit',OBS/'audit',JOINT/'audit']:
    for p,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/p)==h,p
for base in [PRE,MOV,OBS,JOINT]:assert load(base/'audit/checks.json')['passed']
choices=load(JOINT/'audit/verified-choices.json')
ranked=sorted(((-sum(g['exact_area_um2'] for g in r['groups']),r['empty_sites']) for r in choices if not r['excluded']))
area,empty=ranked[0];assert empty==[5,11,14]
inventory=load(PRE/'inventory.json');identity=sorted(i for i in inventory['moving16_orthogonal_identities'] if i[0]=='insert')[0]
fixed=load(PRE/'fixed29.json');owners={i for i,r in enumerate(fixed) if r['part_id']=='insert'}
highest=sorted((r for r in load(OBS/'source-cover-obstacles.json') if r.get('fixed_owner') in owners),key=lambda r:r['bounds_grid'][3])[-1]
m=load(MOV/'family-modes.json')['insert'][1];r=load(MOV/'mode-rectangles.json')['insert'][1]['rectangles'][0]['outward_offsets_grid']
xy=[m['integer_lower_left_bounds'][0][1],highest['bounds_grid'][3]-r[1]]
source={'part_id':'insert','copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':[xy[k]/100+m['translation_from_lower_left'][k] for k in [0,1]]}}
assert load(BASE/'selected-insert.json')=={'identity':identity,'mode':1,'lower_left_grid':xy,'source':source,'highest_fixed_insert_cover':highest}
control=fixed+[source]+[r for i,r in enumerate(load(PRE/'source-cog-sites.json')) if i not in empty]
assert control==load(BASE/'source42.json') and fixed+[source]==load(BASE/'fixed30.json')
spec=load(PRE/'plan.json');checked=audit(load(JOB),control,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in control])
assert checked==load(BASE/'source-checks.json') and not checked['valid'] and checked['pair_failures']==1 and checked['stock_failures']==0
selection={'omitted_cog_sites':empty,'selected_exact_joint_reachable_area_um2':-area,'fixed_insert_identity':identity,'remaining_moving15_identities':[i for i in inventory['moving16_orthogonal_identities'] if i!=identity]}
assert selection==load(BASE/'selection.json')
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[BASE/n for n in ['plan.json','checks.json','selected-insert.json','fixed30.json','source42.json','source-checks.json','selection.json']]+[PRE/n for n in ['plan.json','fixed29.json','source-cog-sites.json','inventory.json']]+[MOV/n for n in ['audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json']]+[OBS/'source-cover-obstacles.json',JOINT/'audit/plan.json',JOINT/'audit/checks.json',JOINT/'audit/verified-choices.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'proof':'Independent formula and original-source replay confirms one failed pair. The inner-body necessary insert pocket does not establish a source-safe direct placement. This exact attempted control remains failed and must not be used as fixed geometry or a negative continuous proof.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'failed_control_preserved':True,'source_valid42':False,'same_sheet_pairs':861,'stock_edges':168,'cutouts':42,'hole_vertices':3936,'pair_failures':1,'stock_failures':0,'fixed30_use_permitted':False,'whole_allocation_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
