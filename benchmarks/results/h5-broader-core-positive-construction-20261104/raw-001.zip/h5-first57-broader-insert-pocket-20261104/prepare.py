"""Direct original insert above the fixed right-side stack for the selected broad choice."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-broader-insert-pocket-20261104'
PRE=ROOT/'output/h5-first57-direct-short9-20261104';MOV=ROOT/'output/h5-first57-disjoint-movers-20261104';OBS=ROOT/'output/h5-first57-disjoint-obstacles-20261104'
JOINT=ROOT/'output/h5-first57-broader-joint-capacities-20261104';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB]+[PRE/n for n in ['plan.json','audit/plan.json','audit/checks.json','fixed29.json','source-cog-sites.json','inventory.json']]+[MOV/n for n in ['audit/plan.json','audit/checks.json','family-modes.json','mode-rectangles.json']]+[OBS/n for n in ['audit/plan.json','audit/checks.json','source-cover-obstacles.json']]+[JOINT/n for n in ['audit/plan.json','audit/checks.json','audit/verified-choices.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Choose the nonexcluded broad candidate having largest independently exact combined reachable group area, lexicographic empty-site tie break. Release every earlier edge bracket/insert. Place the smallest remaining insert identity vertically above the original right-side fixed insert stack, at its inward full-stock rightmost X anchor. Choose the lowest Y that separates its outward moving rectangle from the right/top-expanded highest fixed insert cover. Validate all original sources against fixed29 and the selected twelve cog poses. This direct control may fail; preserve that outcome without retry or exclusion.',
    'preparation_cap_seconds':10,'maximum_process_seconds':20,'coordinate_units_per_mm':100,'insert_mode':1,'solver_calls':0,'native_calls':0})
for base in [PRE,MOV,OBS,JOINT]:assert load(base/'audit/checks.json')['passed']
candidates=[r for r in load(JOINT/'audit/verified-choices.json') if not r['excluded']]
chosen=min(candidates,key=lambda r:(-sum(g['exact_area_um2'] for g in r['groups']),r['empty_sites']))
empty=chosen['empty_sites'];assert empty==[5,11,14]
fixed=load(PRE/'fixed29.json');inventory=load(PRE/'inventory.json')
identity=min((i for i in inventory['moving16_orthogonal_identities'] if i[0]=='insert'),key=lambda i:i[1]);assert identity==['insert',6]
fixed_insert_owners={i for i,r in enumerate(fixed) if r['part_id']=='insert'}
sources=[r for r in load(OBS/'source-cover-obstacles.json') if r.get('fixed_owner') in fixed_insert_owners]
assert len(sources)==11
highest=max(sources,key=lambda r:r['bounds_grid'][3])
mode=load(MOV/'family-modes.json')['insert'][1]
rectangle=load(MOV/'mode-rectangles.json')['insert'][1]['rectangles'][0]['outward_offsets_grid']
xy=[mode['integer_lower_left_bounds'][0][1],highest['bounds_grid'][3]-rectangle[1]]
assert all(lo<=xy[k]<=hi for k,(lo,hi) in enumerate(mode['integer_lower_left_bounds']))
source={'part_id':'insert','copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]/100+mode['translation_from_lower_left'][k] for k in [0,1]]}}
control=fixed+[source]+[r for i,r in enumerate(load(PRE/'source-cog-sites.json')) if i not in empty]
spec=load(PRE/'plan.json');checked=audit(load(JOB),control,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in control])
write(OUT/'selected-insert.json',{'identity':identity,'mode':1,'lower_left_grid':xy,'source':source,'highest_fixed_insert_cover':highest})
write(OUT/'source42.json',control);write(OUT/'source-checks.json',checked)
write(OUT/'selection.json',{'omitted_cog_sites':empty,'selected_exact_joint_reachable_area_um2':sum(g['exact_area_um2'] for g in chosen['groups']),
    'fixed_insert_identity':identity,'remaining_moving15_identities':[i for i in inventory['moving16_orthogonal_identities'] if i!=identity]})
write(OUT/'fixed30.json',fixed+[source])
elapsed=time.perf_counter()-started;assert elapsed<10
checks={'prepared':True,'seconds':elapsed,'source_valid42':checked['valid'],'originals':len(control),'same_sheet_pairs':checked['same_sheet_pairs'],'stock_edges':checked['stock_edges'],'cutouts':checked['cutouts'],'hole_vertices':checked['hole_vertices'],
    'insert_lower_left_mm':[v/100 for v in xy],'omitted_cog_sites':empty,'remaining_brackets':8,'remaining_inserts':7,'pair_failures':checked['pair_failures'],'stock_failures':checked['stock_failures'],
    'independent_source_readback_pending':True,'source_valid66':False,'whole_allocation_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
