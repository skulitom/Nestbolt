"""Prepare diagnostic-only instruments for the newly rejected complete-set candidate."""
from pathlib import Path
import ast
root=Path(__file__).resolve().parents[1]
prep=(root/'output/prepare_h5_obstruction_stage_diagnosis.py').read_text(encoding='utf-8')
prep=prep.replace('h5-obstruction-stage','h5-complete-stage')
prep=prep.replace('output/h5-obstruction-set-probe/candidate','output/h5-complete-set-probe-20261017/candidate')
prep=prep.replace('37700709f38c8a590cb5ea59c0a8dc3258a34c38bf12edfbb55ecbfd030fe7a8','bdf31c479b78844075b90333ad33bff79aa50e10d60a0df229fd0411995ed291')
prep=prep.replace('if blocked.len() > 1 && area < incoming.area() {','if blocked.len() > 1 {')
prep=prep.replace('multi_smaller','multi_eligible_smaller').replace('multi_not_smaller','multi_eligible_not_smaller')
prep=prep.replace('smallest_rejected_area_ratio','smallest_not_smaller_area_ratio')
prep=prep.replace('atomic-set-original','complete-set-original')
prep=prep.replace('Identify current atomic-set proposal eligibility, area-filter exclusions and repair stages; no quality inference.',
    'Identify current complete-set eligibility and actual complete/partial repair stages; no quality inference.')
prep=prep.replace('rejected atomic-set experiment','rejected complete-set experiment')
build=(root/'output/build_h5_obstruction_stage_diagnosis.py').read_text(encoding='utf-8').replace('h5-obstruction-stage','h5-complete-stage')
runner=(root/'scripts/h5_obstruction_stage_diagnosis.py').read_text(encoding='utf-8')
runner=runner.replace('h5_obstruction_set_pilot','h5_complete_set_pilot').replace('h5-obstruction-stage','h5-complete-stage')
runner=runner.replace('h5-obstruction-set-recovered-pilot-20261016','h5-complete-set-pilot-20261017')
runner=runner.replace("OLD/'decision.json'","OLD/'verification.json'")
runner=runner.replace('rejected atomic-set candidate','rejected complete-set candidate')
runner=runner.replace('full-set area exclusions','eligible full sets by returned-area relation')
runner=runner.replace("        assert attempt['returned_area'] < attempt['incoming_area']", "        assert attempt['returned_area'] > 0 and attempt['incoming_area'] > 0\n        if attempt['victims'] == 1:\n            assert attempt['returned_area'] < attempt['incoming_area']")
runner=runner.replace('multi_smaller','multi_eligible_smaller').replace('multi_not_smaller','multi_eligible_not_smaller')
runner=runner.replace('smallest_rejected_area_ratio','smallest_not_smaller_area_ratio')
targets={'output/prepare_h5_complete_stage_diagnosis.py':prep,
         'output/build_h5_complete_stage_diagnosis.py':build,
         'scripts/h5_complete_stage_diagnosis.py':runner}
for rel,text in targets.items():
    ast.parse(text);p=root/rel;assert not p.exists();p.write_text(text,encoding='utf-8',newline='\n')
print('Prepared isolated instrumentation and diagnostic runner; no build or measurements started.')
