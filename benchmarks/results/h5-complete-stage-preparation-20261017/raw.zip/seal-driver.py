from pathlib import Path
from hashlib import sha256
import json
import shutil
import subprocess
import sys
import zipfile
root=Path(__file__).resolve().parents[1]
probe=root/'output/h5-complete-stage-diagnosis-20261017'
out=root/'benchmarks/results/h5-complete-stage-preparation-20261017'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
build=load(probe/'build.json');assert build['all_passed']
assert digest(probe/'exchange-diagnosis.exe')==build['binary_sha256']
assert '85 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
plan=load(probe/'preparation.json')
sys.path.insert(0,str(root/'scripts'))
from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for row in plan['source_files']:
    assert digest(Path(plan['old_source'])/row['path'])==row['sha256']
    if row['path']!=plan['changed_file']:assert digest(probe/'workspace'/row['path'])==row['sha256']
out.mkdir(exist_ok=False)
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
files['build-driver.py']=root/'output/build_h5_complete_stage_diagnosis.py'
files['seal-driver.py']=Path(__file__)
files['driver-preparation.py']=root/'output/prepare_complete_stage_drivers.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()}
raw=out/'raw.zip'
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(raw) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        data=z.read(name);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
for name in ['preparation.json','build.json','instrumentation.patch']:
    shutil.copyfile(probe/name,out/name)
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(raw),'bytes':raw.stat().st_size,
    'members':inventory,'crc_and_every_member_verified':True})
write(out/'checks.json',{'optimized_core_tests_passed':85,'strict_lint_passed':True,
    'instrumented_observer_build_passed':True,'old_candidate_and_production_unchanged':True,
    'diagnostic_only':True,'quality_claim':False,'measured_search_started':False,
    'completed_weight_percent':60,'H5_complete':False})
(out.parent/(out.name+'.md')).write_text("""# Complete-set repair-stage diagnostic preparation — 2026-10-17

An isolated diagnostic copy of the rejected complete-set candidate passes
85 optimized core tests, strict lint and its observer build. Aggregate counters
record eligible complete sets by returned-area relation, retained proposal
sizes and actual receiving/return-sheet repair, validity and material outcomes.
Full sets can have equal or larger area; original single-victim fallbacks still
must be smaller. These distinctions are explicit in the trace reader.

Reversing instrumentation restores the exact original text before formatting;
all other source files and the rejected candidate remain byte-identical.
Proposal choices, geometry, repair settings, work coefficients and deadlines
remain unchanged. Tracing can perturb wall-clock outcomes, so no improvement
or speed inference is permitted. Source, binary, logs and all member hashes/CRC
are retained and verified.

The earlier pilot retains 72 valid outcomes but four failed mechanical material
pairs, with no accepted exchange on panel hardware. The planned four serial
CCD0 CPU-8 observations locate failure stages; they cannot replace that paired
comparison. Two mechanical jobs, both kerfs, seed zero, 60 seconds each.
No production integration, reserved input access or H5 closure; completion 60%.
""",encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in ['h5-complete-stage-preparation-20261017','h5-complete-stage-diagnosis-20261017']:
        f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write("""

## 2026-10-17 — Prepare complete-set repair-stage diagnosis

[The diagnostic-only copy](benchmarks/results/h5-complete-stage-preparation-20261017.md)
passes 85 optimized core tests, strict lint and the observer build. Instrumentation
is reversible to exact original text before formatting, with every other source
unchanged. Complete sets are counted by returned-area relation; actual attempts
distinguish complete/partial sets and both repair, geometry and material stages.
Trace reading permits larger/equal complete sets while retaining the single-part
area invariant. All archive members and CRC verify. Four 60-second serial CPU-8
observations are planned after their plan is committed. This is not a new quality
comparison or an unchanged retry of the failed pilot. Production, every original
failure and gate limits remain; no reserved inputs or H5 credit. Completion 60%.
""")
print(json.dumps({'sealed':str(out),'members':len(inventory),'bytes':raw.stat().st_size}))
