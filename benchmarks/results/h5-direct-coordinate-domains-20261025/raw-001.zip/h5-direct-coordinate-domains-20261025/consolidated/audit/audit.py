"""Verify all consolidation lineages and inward-rounded domains without packing."""
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product
from collections import Counter
import math,shutil,time,traceback
import shapely
from shapely.geometry import MultiPoint,box,shape as from_geojson
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from diagnose_h5_concave_gaps import polygons
from audit_h5_direct_coordinate_domains import clip
from build_h5_direct_coordinate_domains import ROOT,OUT as SOURCE,load,write,digest
BASE=SOURCE/'consolidated';OUT=BASE/'audit'

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');original=load(SOURCE/'plan.json');result=load(BASE/'result.json');assert load(SOURCE/'audit/checks.json')['passed'];scale=original['coordinate_units_per_mm'];coef=original['coefficient_scale'];maxx,maxy=original['coordinate_maxima'];gap=plan['part_gap_mm'];pad=plan['additional_offset_margin_mm'];assert gap==original['new_part_separation_mm']==.22 and pad==.00001
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'result.json',SOURCE/'audit/checks.json',SOURCE/'plan.json']},'method':'Rebuild each relaxed positive-clearance obstacle from explicit boundary-segment vertex sums and all128 circumscribed disk vertices. Verify original stock bounds, all source-face lineages exactly once, convex hull coverage of every source face and containment of every hull in the separately reconstructed safe region. Re-derive every rounded coefficient using exact rational arithmetic and clip the entire bounded coordinate plane exactly; every resulting vertex must satisfy every unrounded original face edge. Remove only exact-empty continuous intersections or empty integer bounding intervals. Retain all original domains and no solver call.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    radius=(gap+pad)/math.cos(math.pi/128);disk=[(radius*math.cos(math.tau*k/128),radius*math.sin(math.tau*k/128)) for k in range(128)];minimum=shapely.Polygon(disk).boundary.distance(shapely.Point(0,0));assert minimum>=gap+pad-1e-14;kept=[];discarded=[];faces=edges=vertices=sourcefaces=0;counts=Counter();max_added_area=0.
    for spec in original['queries']:
        path=SOURCE/'queries'/f"{spec['index']:03d}.json";source=load(path);q=load(BASE/'queries'/path.name);assert q['query_source_sha256']==digest(path) and q['domain_bounds_mm']==source['domain_bounds_mm'] and q['family']==source['family'];assert all(q[k]==v for k,v in spec.items());raw=from_geojson(source['raw_forbidden']);expanded=[raw]
        for poly in polygons(raw):
            for ring in [poly.exterior,*poly.interiors]:
                pts=list(ring.coords)
                for a,b in zip(pts,pts[1:]):expanded.append(MultiPoint([(x+u,y+v) for (x,y),(u,v) in product([a,b],disk)]).convex_hull)
        forbidden=unary_union(expanded);assert forbidden.equals(from_geojson(q['expanded_forbidden']));safe=box(*source['domain_bounds_mm']).difference(forbidden);assert safe.equals(from_geojson(q['safe_region']));assert sorted(i for r in q['faces'] for i in r['source_faces'])==list(range(len(source['faces'])));sourcefaces+=len(source['faces'])
        for fi,row in enumerate(q['faces']):
            face=from_geojson(row['polygon']);assert face.is_valid and face.equals(face.convex_hull) and face.difference(safe).is_empty;old=[from_geojson(source['faces'][i]['polygon']) for i in row['source_faces']];assert all(g.difference(face).is_empty for g in old);assert face.equals(unary_union(old).convex_hull);max_added_area=max(max_added_area,face.area-unary_union(old).area);xy=list(orient(face,sign=1).exterior.coords);pairs=[(p,q) for p,q in zip(xy,xy[1:]) if p!=q];assert len(pairs)==len(row['halfspaces']);rp=[(F(0),F(0)),(F(maxx),F(0)),(F(maxx),F(maxy)),(F(0),F(maxy))];unrounded=[]
            for (p,q),h in zip(pairs,row['halfspaces']):
                assert h['edge']==[list(p),list(q)];x,y=map(F,p);u,v=map(F,q);a=v-y;b=x-u;c=a*x+b*y;A=round(a*coef);B=round(b*coef);err=abs(A-a*coef)*maxx+abs(B-b*coef)*maxy+1;C=math.floor(c*scale*coef-err);assert (A,B,C)==(h['a'],h['b'],h['upper']);assert h['rounding_error_bound']==[err.numerator,err.denominator];assert C+err<=c*scale*coef;rp=clip(rp,F(A),F(B),F(C));unrounded.append((a,b,c*scale));edges+=1
            xmin,ymin,xmax,ymax=row['coordinate_bounds']
            for a,b,c in [(-1,0,-xmin),(0,-1,-ymin),(1,0,xmax),(0,1,ymax)]:rp=clip(rp,F(a),F(b),F(c))
            for x,y in rp:assert all(a*x+b*y<=c for a,b,c in unrounded) and 0<=x<=maxx and 0<=y<=maxy;vertices+=1
            record={'query':spec['index'],'face':fi,'family':source['family'],'orientation_class':spec['orientation_class'],'sheet_id':spec['sheet_id']};faces+=1
            if not rp:discarded.append({**record,'reason':'empty exact rational halfspace intersection'});continue
            tight=[math.ceil(min(p[0] for p in rp)),math.ceil(min(p[1] for p in rp)),math.floor(max(p[0] for p in rp)),math.floor(max(p[1] for p in rp))]
            if tight[0]>tight[2] or tight[1]>tight[3]:discarded.append({**record,'reason':'empty integer-coordinate bounding interval','tight_coordinate_bounds':tight});continue
            kept.append({**record,'coordinate_bounds':tight,'halfspaces':[{k:h[k] for k in ['a','b','upper']} for h in row['halfspaces']]});counts[source['family']]+=1
    assert sourcefaces==3884 and faces==result['consolidated_faces']==3715 and result['pending_merge_queues']==0;assert len(kept)+len(discarded)==faces;write(OUT/'integer-domains.json',kept);write(OUT/'discarded-faces.json',discarded);checks={'passed':True,'seconds':time.perf_counter()-start,'queries_verified':len(original['queries']),'original_faces_covered_exactly_once':sourcefaces,'consolidated_convex_faces':faces,'retained_integer_domains':len(kept),'retained_by_family':dict(counts),'discarded_empty_domains':len(discarded),'exact_rational_halfspaces_checked':edges,'exact_rational_vertices_checked':vertices,'maximum_added_area_per_hull_mm2':max_added_area,'clearance_envelope_minimum_chord_mm':minimum,'required_small_part_counts':{'bracket':12,'insert':21},'implied_per_copy_domain_choices':counts['bracket']*12+counts['insert']*21,'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
