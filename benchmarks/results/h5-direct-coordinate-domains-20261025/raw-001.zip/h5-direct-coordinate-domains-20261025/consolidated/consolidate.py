"""Consolidate safe domain pieces using certified convex hulls, preserving every source face."""
from datetime import datetime,timezone
import heapq,math,shutil,time,traceback
import shapely
from shapely.geometry import shape as from_geojson,box,mapping
from shapely.ops import unary_union
from conservative_h5_polygon_obstacles import expand,circle_check
from build_h5_direct_coordinate_domains import ROOT,OUT as BASE,load,write,digest,halfspaces
OUT=BASE/'consolidated';PAD=.00001;SECONDS=60;ATTEMPTS=200000

def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'consolidate.py');plan=load(BASE/'plan.json');maxx,maxy=plan['coordinate_maxima'];gap=plan['new_part_separation_mm'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'result.json',BASE/'audit/checks.json',ROOT/'output/conservative_h5_polygon_obstacles.py']},'seconds_limit':SECONDS,'merge_attempt_limit':ATTEMPTS,'part_gap_mm':gap,'additional_offset_margin_mm':PAD,'method':'The source audit retains3872 integer domains, causing58434 per-copy domain choices. Consolidate adjacent source faces into convex hulls only when the whole hull is covered by a separately constructed safe region. That region uses the same original stock anchor bounds and original zero-clearance forbidden set, expanded by the same verified128-gon at0.22mm plus0.00001mm numerical margin. This is a new certified simplification phase; no original query is retried, old face is dropped, positive0.22mm gap is reduced or solver rerun. Retain exact source-face lineages for every hull. Re-encode halfspaces with the unchanged inward rational-rounding rule. Stop merges at60seconds or200000 attempts, retaining all unmerged faces and recording unfinished consolidation; those faces remain usable after verification.','solver_calls':0,'native_margin_qualified':False});write(OUT/'clearance-polygon-check.json',circle_check(gap,PAD));start=time.perf_counter();deadline=start+SECONDS;total_attempts=0;results=[]
    for spec in plan['queries']:
        q=load(BASE/'queries'/f"{spec['index']:03d}.json");polys=[from_geojson(r['polygon']) for r in q['faces']];raw=from_geojson(q['raw_forbidden']);forbidden=expand(raw,gap,PAD);safe=box(*q['domain_bounds_mm']).difference(forbidden);assert all(p.difference(safe).is_empty for p in polys);faces={i:p for i,p in enumerate(polys)};lineage={i:[i] for i in faces};neighbors={i:set() for i in faces};tree=shapely.STRtree(polys);queue=[]
        for i,p in enumerate(polys):
            for j0 in tree.query(p,predicate='intersects'):
                j=int(j0)
                if i<j:neighbors[i].add(j);neighbors[j].add(i);heapq.heappush(queue,(i,j))
        attempts=merges=0
        while queue and total_attempts<ATTEMPTS and time.perf_counter()<deadline:
            a,b=heapq.heappop(queue)
            if a not in faces or b not in faces or b not in neighbors[a]:continue
            attempts+=1;total_attempts+=1;hull=faces[a].union(faces[b]).convex_hull
            if not hull.difference(safe).is_empty:continue
            adjacent=(neighbors[a]|neighbors[b])-{a,b};faces[a]=hull;del faces[b];lineage[a]+=lineage.pop(b);neighbors[a]=adjacent;merges+=1
            for j in adjacent:neighbors[j].discard(b);neighbors[j].add(a);heapq.heappush(queue,(min(a,j),max(a,j)))
            del neighbors[b]
        rows=[]
        for i,p in sorted(faces.items()):
            assert p.equals(p.convex_hull) and p.difference(safe).is_empty;assert all(polys[j].difference(p).is_empty for j in lineage[i]);a,b,c,d=p.bounds;rows.append({'source_faces':sorted(lineage[i]),'polygon':mapping(p),'coordinate_bounds':[math.ceil(a*100),math.ceil(b*100),math.floor(c*100),math.floor(d*100)],'halfspaces':halfspaces(p,maxx,maxy)})
        assert sorted(j for r in rows for j in r['source_faces'])==list(range(len(polys)));row={**spec,'family':q['family'],'domain_bounds_mm':q['domain_bounds_mm'],'expanded_forbidden':mapping(forbidden),'safe_region':mapping(safe),'faces':rows,'source_faces':len(polys),'merge_attempts':attempts,'merges':merges,'unprocessed_merge_queue':len(queue),'query_source_sha256':digest(BASE/'queries'/f"{spec['index']:03d}.json")};write(OUT/'queries'/f"{spec['index']:03d}.json",row);results.append({'query':spec['index'],'family':q['family'],'source_faces':len(polys),'faces':len(rows),'merge_attempts':attempts,'merges':merges,'pending_queue':len(queue)});print(results[-1],flush=True)
    result={'seconds':time.perf_counter()-start,'queries':len(results),'source_faces':sum(q['source_faces'] for q in results),'consolidated_faces':sum(q['faces'] for q in results),'merge_attempts':total_attempts,'pending_merge_queues':sum(q['pending_queue'] for q in results),'limit_reached':any(q['pending_queue'] for q in results),'records':results,'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
