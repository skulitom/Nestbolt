"""Independently verify exact-count coordinate domains and inward rational rounding."""
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product
import math,shutil,time,traceback
import shapely
from shapely.geometry import Polygon,MultiPoint,box,shape as from_geojson
from shapely.geometry.polygon import orient
from shapely.affinity import translate
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from diagnose_h5_concave_gaps import convex_pieces,polygons
from build_h5_direct_coordinate_domains import ROOT,SRC,PRIOR,AREA,OUT as BASE,load,write,digest
OUT=BASE/'audit'

def clip(poly,a,b,c):
    if not poly:return []
    result=[]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        vp=a*p[0]+b*p[1]-c;vq=a*q[0]+b*q[1]-c
        if vp<=0:result.append(p)
        if (vp<0 and vq>0) or (vp>0 and vq<0):
            t=vp/(vp-vq);result.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    # Repeated boundary vertices are harmless, but remove them for later bounds.
    return list(dict.fromkeys(result))

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(BASE/'result.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json');pool=load(PRIOR/'candidates.json');mp=load(PRIOR/'mapping.json');classes=plan['orientation_classes'];aliases=plan['all_permitted_orientation_aliases'];scale=plan['coordinate_units_per_mm'];coeff=plan['coefficient_scale'];maxx,maxy=plan['coordinate_maxima'];gap=plan['new_part_separation_mm'];pad=plan['offset_numerical_margin_mm'];stockextra=plan['extra_stock_margin_mm'];core=mp['core_groups'][0]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'result.json',BASE/'cache-checks.json',BASE/'orientations.json',BASE/'fixed-core.json']},'method':'Check original input digests and exact orientation/component unions. Reconstruct cached Minkowski obstacles by Cartesian vertex differences of exactly covering convex pieces, then all translated unions. Rebuild each explicit128-gon clearance envelope independently from boundary segment vertex sums, and verify minimum chord distance. Reconstruct inward stock domains and each complete safe region. Verify that convex faces cover it exactly. Independently derive every integer halfspace from exact rational binary-float vertices; prove the coefficient-error subtraction with rational arithmetic. Clip the complete bounded integer-coordinate plane by these constraints with exact rational arithmetic; verify each resulting vertex satisfies every original face edge. Empty real polygons or empty integer coordinate bounding boxes can be removed, retaining the reason. No packing or solver claim.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    committed=ROOT/'benchmarks/results/h5-occupied-area-relaxation-20261025/raw-manifest.json';manifest=load(committed);hashes={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']};matched=[]
    for n,h in plan['inputs'].items():
        p=ROOT/n;key=AREA.name+'/'+p.relative_to(AREA).as_posix() if p.is_relative_to(AREA) else 'source-inputs/'+n
        if key in hashes:assert hashes[key]==h;matched.append({'source':n,'manifest':committed.relative_to(ROOT).as_posix(),'manifest_sha256':digest(committed),'member':key,'sha256':h})
    assert len(matched)>=7
    expected_aliases=[(f,a,mir) for f in ['bracket','insert'] for mir in ([False,True] if parts[f]['allow_mirror'] else [False]) for a in parts[f]['rotations']['degrees']];assert [(r['family'],r['degrees'],r['mirrored']) for r in aliases]==expected_aliases
    max_transform_error=0.
    for a in aliases:
        o=classes[a['class']];assert a['family']==o['family'];original=shape(parts[a['family']],{'rotation_radians':math.radians(a['degrees']),'mirrored':a['mirrored'],'translation':[-v for v in a['original_zero_bounds_min']]});normalized=from_geojson(o['polygon']);error=original.hausdorff_distance(normalized);assert error<1e-9;max_transform_error=max(max_transform_error,error)
    for o in classes:
        normalized=from_geojson(o['polygon']);pieces=[box(*b) for b in o['rectangular_components']];assert unary_union(pieces).equals(normalized);assert normalized.bounds==(0.,0.,o['width_mm'],o['height_mm']);assert normalized.area==(40000 if o['family']=='bracket' else 19800);assert all(all(float(x).is_integer() for x in b) for b in o['rectangular_components'])
    assert plan['fixed_core']==core and Counter(pool[i]['placement']['part_id'] for i in core['fixed_candidates'])==Counter(frame=18,cog=15)
    fixed={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in core['fixed_candidates']};stored=load(BASE/'fixed-core.json');assert stored['candidate_ids']==core['fixed_candidates'] and stored['placements']==[pool[i]['placement'] for i in core['fixed_candidates']];assert all(fixed[i].equals(from_geojson(g)) for i,g in zip(stored['candidate_ids'],stored['polygons']))
    cache={};vertexsums=0
    for row in load(BASE/'cache-checks.json'):
        family,angle,mirror,ci=row['key'];p=pool[row['first_fixed_candidate']]['placement'];assert family==p['part_id'] and angle==float(p['transform']['rotation_radians']).hex() and mirror==p['transform']['mirrored'];zero=shape(parts[family],{**p['transform'],'translation':[0.,0.]});moving=from_geojson(classes[ci]['polygon']);fp=convex_pieces(zero);mpieces=convex_pieces(moving);assert unary_union(fp).equals(zero) and unary_union(mpieces).equals(moving);sums=[]
        for a,b in product(fp,mpieces):sums.append(MultiPoint([(x-u,y-v) for (x,y),(u,v) in product(list(a.exterior.coords)[:-1],list(b.exterior.coords)[:-1])]).convex_hull);vertexsums+=1
        expected=unary_union(sums);actual=from_geojson(row['raw_local_geometry']);assert expected.equals(actual);cache[tuple(row['key'])]=actual
    radius=(gap+pad)/math.cos(math.pi/128);disk=[(radius*math.cos(math.tau*j/128),radius*math.sin(math.tau*j/128)) for j in range(128)];diskpoly=Polygon(disk);chord_distance=diskpoly.boundary.distance(shapely.Point(0,0));assert chord_distance>=gap+pad-1e-14
    qcount=faces=edges=vertices=0;kept=[];discarded=[];sumareas=0.;domain_counts=Counter()
    for spec in plan['queries']:
        q=load(BASE/'queries'/f"{spec['index']:03d}.json");assert all(q[k]==v for k,v in spec.items());o=classes[q['orientation_class']];ids=[i for i in core['fixed_candidates'] if pool[i]['placement']['sheet_id']==q['sheet_id']];assert ids==q['fixed_candidates'] and q['family']==o['family'];obstacles=[]
        for i in ids:
            p=pool[i]['placement'];t=p['transform'];key=(p['part_id'],float(t['rotation_radians']).hex(),t['mirrored'],o['index']);obstacles.append(translate(cache[key],*t['translation']))
        raw=unary_union(obstacles);assert raw.equals(from_geojson(q['raw_forbidden']));expanded=[raw]
        for poly in polygons(raw):
            for ring in [poly.exterior,*poly.interiors]:
                pts=list(ring.coords)
                for a,b in zip(pts,pts[1:]):expanded.append(MultiPoint([(x+u,y+v) for (x,y),(u,v) in product([a,b],disk)]).convex_hull)
        forbidden=unary_union(expanded);assert forbidden.equals(from_geojson(q['expanded_forbidden']));height=st['height'] if q['sheet_id']=='sheet-0' else target['required_used_height_mm'];bounds=[m['left']+edge+stockextra,m['bottom']+edge+stockextra,st['width']-m['right']-edge-stockextra-o['width_mm'],height-m['top']-edge-stockextra-o['height_mm']];assert bounds==q['domain_bounds_mm'];region=box(*bounds).difference(forbidden);assert region.equals(from_geojson(q['safe_region']));polys=[from_geojson(r['polygon']) for r in q['faces']];assert unary_union(polys).equals(region);sumareas+=region.area
        for fi,(row,poly) in enumerate(zip(q['faces'],polys)):
            assert poly.is_valid and poly.equals(poly.convex_hull) and poly.difference(region).is_empty
            pts=list(orient(poly,sign=1).exterior.coords);expectededges=[(p,z) for p,z in zip(pts,pts[1:]) if p!=z];assert len(expectededges)==len(row['halfspaces']);rationalpoly=[(F(0),F(0)),(F(maxx),F(0)),(F(maxx),F(maxy)),(F(0),F(maxy))];original_edges=[]
            for (p,z),h in zip(expectededges,row['halfspaces']):
                assert h['edge']==[list(p),list(z)];x,y=map(F,p);u,v=map(F,z);a=v-y;b=x-u;c=a*x+b*y;A=round(a*coeff);B=round(b*coeff);error=abs(A-a*coeff)*maxx+abs(B-b*coeff)*maxy+1;C=math.floor(c*scale*coeff-error);assert (A,B,C)==(h['a'],h['b'],h['upper']) and h['rounding_error_bound']==[error.numerator,error.denominator];assert C+abs(A-a*coeff)*maxx+abs(B-b*coeff)*maxy<c*scale*coeff;original_edges.append((a,b,c*scale));rationalpoly=clip(rationalpoly,F(A),F(B),F(C));edges+=1
            xmin,ymin,xmax,ymax=row['coordinate_bounds']
            for a,b,c in [(-1,0,-xmin),(0,-1,-ymin),(1,0,xmax),(0,1,ymax)]:rationalpoly=clip(rationalpoly,F(a),F(b),F(c))
            for x,y in rationalpoly:
                assert 0<=x<=maxx and 0<=y<=maxy and all(a*x+b*y<=c for a,b,c in original_edges);vertices+=1
            faces+=1;record={'query':q['index'],'face':fi,'family':o['family'],'orientation_class':o['index'],'sheet_id':q['sheet_id']}
            if not rationalpoly:discarded.append({**record,'reason':'empty exact rational halfspace intersection'});continue
            tight=[math.ceil(min(p[0] for p in rationalpoly)),math.ceil(min(p[1] for p in rationalpoly)),math.floor(max(p[0] for p in rationalpoly)),math.floor(max(p[1] for p in rationalpoly))]
            if tight[0]>tight[2] or tight[1]>tight[3]:discarded.append({**record,'reason':'empty integer-coordinate bounding interval','tight_coordinate_bounds':tight});continue
            kept.append({**record,'coordinate_bounds':tight,'halfspaces':[{k:h[k] for k in ['a','b','upper']} for h in row['halfspaces']]});domain_counts[o['family']]+=1
        qcount+=1
    assert qcount==result['completed_queries']==20 and faces==result['convex_faces']==3884 and len(kept)+len(discarded)==faces and not load(BASE/'pending.json')
    write(OUT/'integer-domains.json',kept);write(OUT/'discarded-faces.json',discarded);write(OUT/'provenance.json',{'passed':True,'source_members_matching_committed_evidence':matched})
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_source_matches':len(matched),'all_original_orientation_aliases':len(aliases),'unique_normalized_classes':len(classes),'maximum_original_float_transform_error_mm':max_transform_error,'cached_obstacles_reconstructed':len(cache),'convex_piece_vertex_sums':vertexsums,'clearance_polygon_minimum_chord_mm':chord_distance,'queries_checked':qcount,'convex_faces_checked':faces,'exact_rational_halfspaces_checked':edges,'exact_rational_vertices_checked_inside_original_faces':vertices,'retained_integer_coordinate_domains':len(kept),'retained_by_family':dict(domain_counts),'discarded_empty_domains':len(discarded),'no_integer_feasible_point_discarded_by_empty_domain_filter':True,'all_safe_regions_exactly_covered_before_inward_rounding':True,'native_margin_qualified':False,'full_target_witness':False,'solver_calls':0};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
