"""One frozen physical slab, vertical raw-multiplicity sweep; never rerun a slab."""
from pathlib import Path
from hashlib import sha256
import json,time,sys
from h5_projected_coverage_atoms_20261109 import vertical_atoms,forbidden_projection
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-projected-partition-20261109';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
index,slab=map(int,sys.argv[1:]);spec=next(s for s in load(BASE/'plan.json')['slabs'] if (s['refinement_index'],s['slab_index'])==(index,slab));OUT=BASE/f'choice-{index:02d}-slab-{slab}';OUT.mkdir();began=time.perf_counter()
bindings=load(BASE/'plan.json')['inputs']
for name,h in bindings.items():assert digest(ROOT/name)==h
p=PRE/f'choice-{index:02d}.json';data=load(p)
write(OUT/'plan.json',{'inputs':{**bindings,BASE.joinpath('plan.json').relative_to(ROOT).as_posix():digest(BASE/'plan.json'),Path(__file__).relative_to(ROOT).as_posix():digest(Path(__file__))},'slab':spec,'method':'Raw rectangle event multiplicities in vertical strips; node profiles cached only while unchanged. Merge fixed intervals and subtract their union from each node-query signature segment. Store every positive integer area after quotienting by both complete conditional family-query masks.'})
rectangles=[(r['current_position'],box) for r in data['node_regions'] for box in r['regions_um']]+[(-1,box) for box in data['fixed_forbidden_clearance_regions_um']]
atoms=vertical_atoms(rectangles,data['current_nodes'],*spec['closed_x_bounds_um'],forbidden_projection(data));assert len(atoms)<=spec['maximum_signature_count']
write(OUT/'atoms.json',[[hex(key[0]),hex(key[1]),area] for key,area in sorted(atoms.items())])
total=sum(atoms.values())
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'refinement_index':index,'slab_index':slab,'signatures':len(atoms),'physical_union_area_um2':total,'conditional_queries':len(data['required_representatives']),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
