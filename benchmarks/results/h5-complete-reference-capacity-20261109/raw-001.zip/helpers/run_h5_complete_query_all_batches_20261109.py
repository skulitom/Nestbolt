"""Run every frozen complete-query batch and its independent audit exactly once."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-complete-query-all-batches-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(ROOT/'output/h5-projected-partition-block-completion-20261109/checks.json')['passed']
plan=load(ROOT/'output/h5-fixed29-projected-partition-20261109/plan.json');assert len(plan['query_batches'])==50
OUT.mkdir();write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'administrative_runner':True,'numeric_workers':'Every frozen complete query batch followed by its independent complementary-loss auditor, sequential60s/2GiB WindowsJobs.','optimizer_calls':0,'retry_permitted':False})
for spec in plan['query_batches']:
    batch=spec['batch_index']
    for audit in [False,True]:
        label=f'h5-fixed29-complete-query-batch-{batch:02d}'+('-audit' if audit else '')
        folder=ROOT/'output'/(label+'-process-20261109')
        if batch==0:
            result=load(folder/'process.json');assert result['passed'] and result['closed'] and result['job']['active_processes']==0
        else:
            assert not folder.exists(),str(folder)
            wrapper=ROOT/'output'/('run_'+label.replace('-','_')+'_stage_20261109.py')
            r=subprocess.run([sys.executable,str(wrapper)],cwd=ROOT,capture_output=True)
            (OUT/(label+'-stdout.txt')).write_bytes(r.stdout);(OUT/(label+'-stderr.txt')).write_bytes(r.stderr)
            assert (folder/'process.json').is_file(),(r.returncode,r.stderr)
            result=load(folder/'process.json');assert r.returncode==0 and result['passed'] and result['closed'] and result['job']['active_processes']==0,(label,result)
        checkfolder=ROOT/'output/h5-fixed29-projected-partition-20261109'/f'query-batch-{batch:02d}'
        if audit:checkfolder=checkfolder/'audit'
        checks=load(checkfolder/'checks.json')
        entry={'utc':datetime.now(timezone.utc).isoformat(),'batch':batch,'case':spec['refinement_index'],'audit':audit,'complete_seconds':result['complete_seconds'],'passed':True,'excluded_queries':checks['excluded_queries' if audit else 'provisional_excluded_queries']}
        with (OUT/'progress.jsonl').open('a',encoding='utf-8',newline='\n') as f:f.write(json.dumps(entry)+'\n')
        print(entry,flush=True)
write(OUT/'checks.json',{'passed':True,'all50_batches_complete':True,'all100_processes_closed':True,'optimizer_calls':0})
print(load(OUT/'checks.json'),flush=True)
