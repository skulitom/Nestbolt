"""Horizontal node-union/XOR sweep independently reproduces the complete histogram."""
from pathlib import Path
from hashlib import sha256
import json,time,sys
from h5_block_projected_coverage_atoms_20261109 import horizontal_atoms,allowed_projection
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-projected-partition-20261109';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
slab=int(sys.argv[1]);index=9;assert 4<=slab<=15;SOURCE=BASE/f'choice-{index:02d}-slab-{slab}';OUT=SOURCE/'audit';OUT.mkdir();began=time.perf_counter()
bindings={}
for folder in [BASE,SOURCE,PRE/'audit']:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h;bindings[name]=h
for p in [Path(__file__),SOURCE/'plan.json',SOURCE/'checks.json',SOURCE/'atoms.json']:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independent horizontal scan: form each current-node union of X intervals before XORing its coverage bit; fixed rectangles use a separate signed-count event process. Independently transpose allowed queries from raw bytes, union across covering nodes and complement. Compare every positive integer area of every complete family-query signature, not only totals. Exact shared slab boundaries have zero area. No inferred feasible placements.'})
spec=next(s for s in load(BASE/'plan.json')['slabs'] if (s['refinement_index'],s['slab_index'])==(index,slab));data=load(PRE/f'choice-{index:02d}.json')
rectangles=[]
for r in data['node_regions']:
    for box in r['regions_um']:rectangles.append((r['current_position'],box))
for box in data['fixed_forbidden_clearance_regions_um']:rectangles.append((-1,box))
atoms=horizontal_atoms(rectangles,data['current_nodes'],*spec['closed_x_bounds_um'],allowed_projection(data));saved=load(SOURCE/'atoms.json')
assert saved==[[hex(key[0]),hex(key[1]),area] for key,area in sorted(atoms.items())]
full=(1<<len(data['required_representatives']))-1
assert all(not key[0]&~full and not key[1]&~full and area>0 for key,area in atoms.items())
total=sum(atoms.values());assert total==load(SOURCE/'checks.json')['physical_union_area_um2']
process=load(ROOT/f'output/h5-fixed29-block-atoms-{index:02d}-{slab}-process-20261109/process.json');assert process['closed'] and process['passed']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'refinement_index':index,'slab_index':slab,'exact_signature_areas_verified':len(atoms),'physical_union_area_um2':total,'conditional_queries':len(data['required_representatives']),'all_signatures_match_independent_axis_and_multiplicity_method':True,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
