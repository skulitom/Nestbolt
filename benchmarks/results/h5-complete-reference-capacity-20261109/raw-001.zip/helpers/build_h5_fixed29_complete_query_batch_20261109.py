"""Frozen complete representative batch, summing positive projected coverage areas."""
from pathlib import Path
from hashlib import sha256
import json,time,sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-projected-partition-20261109';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
batch=int(sys.argv[1]);plan=load(BASE/'plan.json');spec=plan['query_batches'][batch];assert spec['batch_index']==batch
assert load(ROOT/'output/h5-projected-partition-block-completion-20261109/checks.json')['passed']
OUT=BASE/f'query-batch-{batch:02d}';OUT.mkdir();began=time.perf_counter();index=spec['refinement_index'];data=load(PRE/f'choice-{index:02d}.json')
inputs=[Path(__file__),BASE/'plan.json',PRE/'audit/checks.json',PRE/'audit/plan.json',PRE/f'choice-{index:02d}.json',ROOT/'output/h5-projected-partition-block-completion-20261109/checks.json',ROOT/'output/h5-projected-partition-block-completion-20261109/plan.json',ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'];atoms={}
pieces=[p for p in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json') if p['refinement_index']==index]
assert len(pieces)==(16 if index==1 else 22)
for piece in pieces:
    folder=ROOT/piece['folder'];assert load(folder/'audit/checks.json')['passed']
    inputs.extend([folder/'plan.json',folder/'audit/plan.json',folder/'audit/checks.json',folder/'atoms.json'])
    for ub,ui,area in load(folder/'atoms.json'):
        key=(int(ub,16),int(ui,16));atoms[key]=atoms.get(key,0)+area
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'batch':spec,'method':'For every representative in this frozen consecutive batch, sum all positive signature areas with its uncovered-query bit absent from the relevant family. Joint coverage is positive if either family covers it. Every complete physical proof piece is included, with all eight children replacing exactly the two failed parent intervals, merging identical signatures only by exact integer addition. Deficits transfer only through the previously verified graph-row mapping. No pose-specific transfer or feasible placement claim.','optimizer_calls':0,'retry_permitted':False})
representatives=data['required_representatives'];active=sum(1<<p for p in data['active_current_positions']);mapping=data['pivot_to_representative'];required=data['required_other_family_and_joint_area_um2'];results=[]
for position in spec['representative_positions']:
    qi=representatives.index(position);bit=1<<qi;areas=[0,0,0]
    for (ub,ui),area in atoms.items():
        b=not ub&bit;i=not ui&bit
        if b:areas[0]+=area
        if i:areas[1]+=area
        if b or i:areas[2]+=area
    failures=[k for k,(upper,lower) in enumerate(zip(areas,required)) if upper<lower]
    forbidden=int(data['representative_active_forbidden_rows_hex'][qi],16)
    excluded=[p for p,r in mapping if r==position] if failures else []
    results.append({'refinement_index':index,'representative_current_position':position,'representative_query_index':qi,'allowed_current_nodes':(active&~forbidden).bit_count(),'family_and_joint_area_upper_um2':areas,'failing_area_indices':failures,'provisional_reference_query_excluded':bool(failures),'dominated_active_bracket_positions_excluded':excluded})
write(OUT/'query-results.json',results)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'batch_index':batch,'refinement_index':index,'representative_queries':len(results),'exact_area_bounds':3*len(results),'coalesced_signatures':len(atoms),'provisional_excluded_queries':sum(r['provisional_reference_query_excluded'] for r in results),'provisional_excluded_bracket_positions':sum(len(r['dominated_active_bracket_positions_excluded']) for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
