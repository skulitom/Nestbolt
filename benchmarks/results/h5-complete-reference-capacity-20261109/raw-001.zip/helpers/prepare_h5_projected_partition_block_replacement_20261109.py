"""Replace one terminal failed interval with four complete proper subinterval proofs."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-projected-partition-20261109';OUT=ROOT/'output/h5-projected-partition-block-replacement-20261109'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();original=load(BASE/'plan.json');failed_path=ROOT/'output/h5-fixed29-projected-atoms-09-3-process-20261109/process.json';failed=load(failed_path)
assert load(ROOT/'output/h5-block-query-projection-controls-20261109/checks.json')['passed']
assert failed['closed'] and not failed['passed'] and failed['job']['reason_code']==1 and failed['job']['active_processes']==0
assert not (BASE/'choice-09-slab-3/atoms.json').exists()
parent=next(s for s in original['slabs'] if (s['refinement_index'],s['slab_index'])==(9,3));left,right=parent['closed_x_bounds_um'];cuts=[left+(right-left)*i//4 for i in range(5)]
assert cuts[0]==left and cuts[-1]==right and all(a<b for a,b in zip(cuts,cuts[1:]))
children=[{**parent,'child_index':i,'closed_x_bounds_um':[a,b],'parent_closed_x_bounds_um':[left,right]} for i,(a,b) in enumerate(zip(cuts,cuts[1:]))]
inputs=[Path(__file__),BASE/'plan.json',failed_path,ROOT/'output/h5_block_projected_coverage_atoms_20261109.py',ROOT/'output/h5-block-query-projection-controls-20261109/checks.json',ROOT/'output/h5-block-query-projection-controls-20261109/plan.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'The original case09slab3 producer is terminal at its60s limit with no histogram; it and the stopped administrative runner remain closed. Prove four new proper physical subintervals whose exact union equals that entire interval. Every child requires both independently controlled sweeps using checked8-node intersection versus4-node union tables under the unchanged60s/2GiB/400000-state limits. All previously accepted slabs are reused byte-for-byte, remaining originally frozen slabs4..15 are opened only once with the checked block projection, and all3138representative queries remain mandatory. This replaces one incomplete area-integration proof by a complete interval decomposition; no optimizer, sampled omission or timer reset. The full failed cost stays charged.','parent_slab':parent,'replacement_slabs':children,'remaining_original_slabs':[s for s in original['slabs'] if s['refinement_index']==9 and s['slab_index']>=4],'failed_full_seconds_to_charge':failed['complete_seconds'],'process_cap_seconds':10,'optimizer_calls':0,'retry_permitted':False})
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'exact_parent_width_um':right-left,'sum_child_width_um':sum(s['closed_x_bounds_um'][1]-s['closed_x_bounds_um'][0] for s in children),'closed_child_intervals_cover_parent_without_positive_area_overlap':True,'replacement_children':4,'optimizer_calls':0})
print(load(OUT/'checks.json'))
