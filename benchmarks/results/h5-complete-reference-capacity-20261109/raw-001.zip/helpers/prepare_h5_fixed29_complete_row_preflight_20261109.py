"""Freeze complete active bracket row coverage and exact node-region inputs."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed29-complete-row-preflight-20261109'
PRIOR=ROOT/'benchmarks/results/h5-reference-subdivision-20261109';FRONT=ROOT/'output/h5-fixed29-conditional-frontier-20261108'
DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108';COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();parent=load(PRIOR/'checks.json');assert parent['passed'] and load(PRIOR/'archive-checks.json')['passed']
cases=load(FRONT/'audit/remaining-cases.json');assert [c['refinement_index'] for c in cases]==[1,9]
inputs=[Path(__file__),PRIOR/'checks.json',PRIOR/'archive-checks.json',FRONT/'audit/checks.json',FRONT/'audit/plan.json',FRONT/'audit/remaining-cases.json',DOM/'audit/checks.json',DOM/'audit/plan.json',COVER/'audit/checks.json',COVER/'audit/plan.json',OLD/'geometries.json',OLD/'stock-cover.json']
for case in cases:
    index=case['refinement_index'];d=load(DOM/f'choice-{index:02d}-dominance.json');graph=ROOT/d['graph']
    inputs.extend([DOM/f'choice-{index:02d}-dominance.json',graph/'nodes.json',graph/'conflicts.bin',FRONT/f'choice-{index:02d}-frontier.json',COVER/f'choice-{index:02d}-covers.json',COVER/f'choice-{index:02d}-regions.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Cover EVERY currently active bracket cell in BOTH remaining scopes with its previously certified minimal conflict-row representative. Reverify all subset implications on the active mask, with explicit self collision. Materialize source alias-component sweeps over EVERY current complete closed cover; keep all graph positions unchanged. Freeze exact rectangle inputs and all required representatives in ascending current position. Proposed weighted area partition groups physical area by the bitset of current-node sweep regions covering it, after removing fixed clearance regions. A complete exact partition can answer every conditional area query without reconstructing unions. This preflight computes only source inputs, coverage and size metrics, not atom areas or exclusions. Common-line holes reserved.','process_cap_seconds':20,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'inherited_numeric_preparation_seconds':parent['consumed_preparation_seconds']})
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um'];summary=[]
for case in cases:
    index=case['refinement_index'];d=load(DOM/f'choice-{index:02d}-dominance.json');graph=ROOT/d['graph'];nodes=load(graph/'nodes.json');N=len(nodes);width=(N+7)//8;raw=(graph/'conflicts.bin').read_bytes();assert len(raw)==N*width
    frontier=load(FRONT/f'choice-{index:02d}-frontier.json');active=frontier['remaining_current_positions'];active_mask=sum(1<<p for p in active);mapping=dict(d['pivot_to_representative'])
    pivots=[p for p in active if nodes[p]['family']==0];reps=sorted({mapping[p] for p in pivots});rows={}
    for p in sorted(set(pivots)|set(reps)):
        node=nodes[p];box=node['bounds_um'];component=geometries[node['geometry']]['inner_rectangles_um'][frontier['source_self_collision_components'][p]]
        assert box[2]-box[0]<component[2]-component[0] and box[3]-box[1]<component[3]-component[1]
        rows[p]=(int.from_bytes(raw[p*width:(p+1)*width],'little')|(1<<p))&active_mask
    assert all(rows[mapping[p]]&~rows[p]==0 for p in pivots)
    original=load(COVER/f'choice-{index:02d}-covers.json');pernode=[];all_rect=[]
    for p in active:
        node=nodes[p];geometry=geometries[node['geometry']];rectangles=set()
        for box in original[p]['remaining_closed_anchor_boxes_um']:
            for component in geometry['all_alias_component_outer_rectangles_um']:
                value=[box[k]+component[k] for k in range(4)]
                r=(max(stock[0],value[0]),max(stock[1],value[1]),min(stock[2],value[2]),min(stock[3],value[3]))
                if r[0]<r[2] and r[1]<r[3]:rectangles.add(r)
        rects=[list(r) for r in sorted(rectangles)];all_rect.extend(rects)
        pernode.append({'current_position':p,'source_node_label':node['node'],'family':node['family'],'regions_um':rects})
    fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um']
    all_rect+=fixed
    xevents={}
    for l,b,r,t in all_rect:xevents[l]=xevents.get(l,0)+1;xevents[r]=xevents.get(r,0)-1
    current=peak=0
    for x in sorted(xevents):current+=xevents[x];peak=max(peak,current)
    assert current==0
    record={'refinement_index':index,'empty_sites':case['empty_sites'],'graph':d['graph'],'current_nodes':N,'active_current_positions':active,'active_bracket_pivots':pivots,'required_representatives':reps,'pivot_to_representative':[[p,mapping[p]] for p in pivots],'representative_active_forbidden_rows_hex':[hex(rows[p]) for p in reps],'node_regions':pernode,'fixed_forbidden_clearance_regions_um':fixed,'required_other_family_and_joint_area_um2':[279993000000,158392000000,438385000000]}
    write(OUT/f'choice-{index:02d}.json',record)
    row={'refinement_index':index,'active_nodes':len(active),'active_bracket_pivots':len(pivots),'required_representatives':len(reps),'node_rectangles':sum(len(r['regions_um']) for r in pernode),'fixed_rectangles':len(fixed),'x_coordinates':len({r[k] for r in all_rect for k in [0,2]}),'y_coordinates':len({r[k] for r in all_rect for k in [1,3]}),'maximum_active_rectangles_per_x_strip':peak,'source_subset_implications':len(pivots),'scope_excluded':False}
    summary.append(row);print(row,flush=True)
write(OUT/'case-summary.json',summary);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'scopes':2,'covered_current_bracket_cells':sum(r['active_bracket_pivots'] for r in summary),'required_representatives':sum(r['required_representatives'] for r in summary),'area_partition_prepared':False,'optimizer_calls':0,'independent_audit_pending':True,'H5_complete':False})
