"""Freeze all physical slabs and all conditional query batches before execution."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed29-atom-partition-20261109'
PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109';CONTROL=ROOT/'output/h5-node-coverage-atom-controls-20261109'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();assert load(PRE/'audit/checks.json')['passed'] and load(CONTROL/'checks.json')['passed']
control_process=load(ROOT/'output/h5-node-coverage-atom-controls-process-20261109/process.json');assert control_process['passed'] and control_process['closed']
inputs=[Path(__file__),ROOT/'output/h5_node_coverage_atoms_20261109.py',PRE/'audit/checks.json',PRE/'audit/plan.json',CONTROL/'checks.json',CONTROL/'plan.json',ROOT/'output/h5-node-coverage-atom-controls-process-20261109/process.json',ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/stock-cover.json']
stock=load(inputs[-1])['outward_stock_rectangle_um'];left,right=stock[0],stock[2]
cuts=[left+(right-left)*i//4 for i in range(5)];assert cuts[0]==left and cuts[-1]==right and all(a<b for a,b in zip(cuts,cuts[1:]))
slabs=[];batches=[]
for index in [1,9]:
    p=PRE/f'choice-{index:02d}.json';inputs.append(p);data=load(p);reps=data['required_representatives']
    for i,(a,b) in enumerate(zip(cuts,cuts[1:])):slabs.append({'refinement_index':index,'slab_index':i,'closed_x_bounds_um':[a,b],'producer_cap_seconds':60,'audit_cap_seconds':60,'maximum_signature_count':400000})
    for first in range(0,len(reps),64):batches.append({'batch_index':len(batches),'refinement_index':index,'representative_positions':reps[first:first+64],'producer_cap_seconds':60,'audit_cap_seconds':60})
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Exact physical area measure partition by the bitset of active current-node sweep regions covering each point, excluding fixed forbidden clearance regions. Four adjacent full-width slabs per remaining case, with every stock X interval retained; shared slab boundaries have zero area and do not alter the upper bound. Vertical producer uses raw-rectangle multiplicity counts and fixed interval subtraction. Independent horizontal audit merges each node intervals before XOR events and subtracts fixed raw counts. Entire signature histograms must match. After all eight slabs, every required representative is covered by a frozen consecutive batch of at most64; no pilot selection or adaptive extension. All mappings, physical area partitions and conditional queries require complete reconciliation. Common-line occupied envelopes reserve holes. No optimizer or timed-gate claim.','slabs':slabs,'query_batches':batches,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'inherited_numeric_preparation_seconds':load(PRE/'audit/checks.json')['complete_preparation_seconds_if_consumed']+control_process['complete_seconds']})
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'slabs':len(slabs),'query_batches':len(batches),'required_representatives':sum(len(b['representative_positions']) for b in batches),'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
