"""Two independent exact sweeps for area grouped by covering current-node bitsets."""

def vertical_atoms(rectangles,node_count,left,right):
    rows=[]
    for node,(a,b,c,d) in rectangles:
        a=max(a,left);c=min(c,right)
        if a<c and b<d:rows.append((node,(a,b,c,d)))
    events={}
    for i,(node,(a,b,c,d)) in enumerate(rows):
        events.setdefault(a,[]).append((i,True));events.setdefault(c,[]).append((i,False))
    active_moving=set();active_fixed=set();profile=[];fixed=[];atoms={};xs=sorted(events)
    for xi,x in enumerate(xs):
        changed_moving=changed_fixed=False
        for i,add in events[x]:
            if rows[i][0]<0:active=active_fixed;changed_fixed=True
            else:active=active_moving;changed_moving=True
            if add:active.add(i)
            else:active.remove(i)
        if xi+1==len(xs):break
        if changed_moving:
            yevents={}
            for i in active_moving:
                node,(a,b,c,d)=rows[i]
                yevents.setdefault(b,[]).append((node,1));yevents.setdefault(d,[]).append((node,-1))
            counts=[0]*node_count;mask=0;ys=sorted(yevents);profile=[]
            for yi,y in enumerate(ys):
                for node,sign in yevents[y]:
                    old=counts[node];counts[node]+=sign;assert counts[node]>=0
                    if old==0 and counts[node]>0:mask|=1<<node
                    if old>0 and counts[node]==0:mask&=~(1<<node)
                if yi+1<len(ys) and mask:
                    top=ys[yi+1]
                    if profile and profile[-1][1]==y and profile[-1][2]==mask:profile[-1]=(profile[-1][0],top,mask)
                    else:profile.append((y,top,mask))
            assert mask==0 and not any(counts)
        if changed_fixed:
            fixed=[]
            for a,b in sorted((rows[i][1][1],rows[i][1][3]) for i in active_fixed):
                if fixed and a<=fixed[-1][1]:fixed[-1][1]=max(b,fixed[-1][1])
                else:fixed.append([a,b])
        dx=xs[xi+1]-x;fi=0
        for bottom,top,mask in profile:
            while fi<len(fixed) and fixed[fi][1]<=bottom:fi+=1
            p=bottom;j=fi;length=0
            while j<len(fixed) and fixed[j][0]<top:
                lo,hi=fixed[j];length+=max(0,min(lo,top)-p);p=max(p,hi)
                if p>=top:break
                j+=1
            length+=max(0,top-p)
            if length:atoms[mask]=atoms.get(mask,0)+dx*length
        assert len(atoms)<=400000
    assert not active_moving and not active_fixed
    return atoms

def horizontal_atoms(rectangles,node_count,left,right):
    rows=[]
    for node,box in rectangles:
        low=max(left,box[0]);high=min(right,box[2])
        if high>low and box[3]>box[1]:rows.append((node,low,box[1],high,box[3]))
    events={}
    for i,(node,a,b,c,d) in enumerate(rows):
        events.setdefault(b,[]).append((i,1));events.setdefault(d,[]).append((i,-1))
    active=[set(),set()];moving_events={};fixed_events={};atoms={};ys=sorted(events)
    for yi,y in enumerate(ys):
        changed=[False,False]
        for i,sign in events[y]:
            category=int(rows[i][0]<0);changed[category]=True
            if sign==1:active[category].add(i)
            else:active[category].remove(i)
        if yi+1==len(ys):break
        if changed[0]:
            pernode={}
            for i in active[0]:
                node,a,b,c,d=rows[i];pernode.setdefault(node,[]).append((a,c))
            moving_events={}
            for node,intervals in pernode.items():
                assert 0<=node<node_count
                merged=[]
                for a,b in sorted(intervals):
                    if not merged or a>merged[-1][1]:merged.append([a,b])
                    elif b>merged[-1][1]:merged[-1][1]=b
                bit=1<<node
                for a,b in merged:moving_events[a]=moving_events.get(a,0)^bit;moving_events[b]=moving_events.get(b,0)^bit
        if changed[1]:
            fixed_events={}
            for i in active[1]:
                node,a,b,c,d=rows[i];fixed_events[a]=fixed_events.get(a,0)+1;fixed_events[c]=fixed_events.get(c,0)-1
        xs=sorted(set(moving_events)|set(fixed_events));mask=0;fixed_count=0;dy=ys[yi+1]-y
        for xi,x in enumerate(xs):
            mask^=moving_events.get(x,0);fixed_count+=fixed_events.get(x,0);assert fixed_count>=0
            if xi+1<len(xs) and mask and not fixed_count:
                area=(xs[xi+1]-x)*dy;atoms[mask]=atoms.get(mask,0)+area
        assert mask==0 and fixed_count==0 and len(atoms)<=400000
    assert not any(active)
    return atoms
