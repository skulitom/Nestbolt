"""Independently verify every active mapping, source rectangle and fixed input."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109';OUT=BASE/'audit'
FRONT=ROOT/'output/h5-fixed29-conditional-frontier-20261108';DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108';COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();bindings={}
for folder in [BASE,FRONT/'audit',DOM/'audit',COVER/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h;bindings[name]=h
for p in [Path(__file__)]+list(BASE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Read all original active node positions and map every bracket through the previously certified dominance relation. Check row-subset implication on the current active mask byte by byte, including source-proven self collision. Reconstruct every possible alias component rectangle from original closed covers and stock clipping. Verify every fixed rectangle unchanged. Freeze all3138 required representatives, not a sample; area proof still pending.'})
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um'];summary=[];implications=rectangles=0
for case in load(FRONT/'audit/remaining-cases.json'):
    index=case['refinement_index'];record=load(BASE/f'choice-{index:02d}.json');dominance=load(DOM/f'choice-{index:02d}-dominance.json');graph=ROOT/dominance['graph'];nodes=load(graph/'nodes.json');N=len(nodes);width=(N+7)//8;raw=(graph/'conflicts.bin').read_bytes();assert len(raw)==N*width
    frontier=load(FRONT/f'choice-{index:02d}-frontier.json');active=frontier['remaining_current_positions'];assert record['active_current_positions']==active and len(set(active))==len(active)
    pivots=[i for i in active if nodes[i]['family']==0];mapping=dict(dominance['pivot_to_representative']);assert record['active_bracket_pivots']==pivots and record['pivot_to_representative']==[[i,mapping[i]] for i in pivots]
    representatives=sorted({mapping[i] for i in pivots});assert record['required_representatives']==representatives
    def row(position):
        values=bytearray(raw[position*width:(position+1)*width]);values[position//8]|=1<<(position%8)
        return values
    masks=bytearray(width)
    for p in active:masks[p//8]|=1<<(p%8)
    for p in sorted(set(pivots)|set(representatives)):
        source=nodes[p];box=source['bounds_um'];c=geometries[source['geometry']]['inner_rectangles_um'][frontier['source_self_collision_components'][p]]
        assert c[2]-c[0]>box[2]-box[0] and c[3]-c[1]>box[3]-box[1]
    for p in pivots:
        a=row(mapping[p]);b=row(p)
        assert all((x&m)&~y==0 for x,y,m in zip(a,b,masks));implications+=1
    assert record['representative_active_forbidden_rows_hex']==[hex(int.from_bytes(bytes(x&m for x,m in zip(row(p),masks)),'little')) for p in representatives]
    covers=load(COVER/f'choice-{index:02d}-covers.json');assert [r['current_position'] for r in record['node_regions']]==active
    for p,r in zip(active,record['node_regions']):
        source=nodes[p];assert r['source_node_label']==source['node'] and r['family']==source['family']
        expected=set()
        for box in covers[p]['remaining_closed_anchor_boxes_um']:
            for component in geometries[source['geometry']]['all_alias_component_outer_rectangles_um']:
                l=max(stock[0],box[0]+component[0]);b=max(stock[1],box[1]+component[1]);right=min(stock[2],box[2]+component[2]);t=min(stock[3],box[3]+component[3])
                if l<right and b<t:expected.add((l,b,right,t))
        assert r['regions_um']==[list(v) for v in sorted(expected)];rectangles+=len(expected)
    fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um'];assert fixed==record['fixed_forbidden_clearance_regions_um']
    assert record['required_other_family_and_joint_area_um2']==[279993000000,158392000000,438385000000]
    moving=[v for r in record['node_regions'] for v in r['regions_um']]
    summary.append({'refinement_index':index,'active_nodes':len(active),'bracket_pivots':len(pivots),'required_representatives':len(representatives),'moving_x_coordinates':len({r[k] for r in moving for k in [0,2]}),'moving_y_coordinates':len({r[k] for r in moving for k in [1,3]}),'fixed_x_coordinates':len({r[k] for r in fixed for k in [0,2]}),'fixed_y_coordinates':len({r[k] for r in fixed for k in [1,3]})})
process=load(ROOT/'output/h5-fixed29-complete-row-preflight-process-20261109/process.json');assert process['closed'] and process['passed']
write(OUT/'case-summary.json',summary)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'complete_active_bracket_mapping_implications':implications,'source_node_rectangles_verified':rectangles,'required_representatives':sum(r['required_representatives'] for r in summary),'scopes':2,'complete_preparation_seconds_if_consumed':load(BASE/'plan.json')['inherited_numeric_preparation_seconds']+process['complete_seconds'],'area_partition_prepared':False,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'));print(summary)
