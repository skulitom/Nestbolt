"""Freeze all physical slabs and all conditional query batches before execution."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed29-projected-partition-20261109'
PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109';CONTROL=ROOT/'output/h5-projected-coverage-atom-controls-20261109'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();assert load(PRE/'audit/checks.json')['passed'] and load(CONTROL/'checks.json')['passed']
control_process=load(ROOT/'output/h5-projected-coverage-atom-controls-process-20261109/process.json');assert control_process['passed'] and control_process['closed']
inputs=[Path(__file__),ROOT/'output/h5_projected_coverage_atoms_20261109.py',PRE/'audit/checks.json',PRE/'audit/plan.json',CONTROL/'checks.json',CONTROL/'plan.json',ROOT/'output/h5-projected-coverage-atom-controls-process-20261109/process.json',ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/stock-cover.json']
stock=load(inputs[-1])['outward_stock_rectangle_um'];left,right=stock[0],stock[2]
cuts=[left+(right-left)*i//16 for i in range(17)];assert cuts[0]==left and cuts[-1]==right and all(a<b for a,b in zip(cuts,cuts[1:]))
slabs=[];batches=[]
for index in [1,9]:
    p=PRE/f'choice-{index:02d}.json';inputs.append(p);data=load(p);reps=data['required_representatives']
    for i,(a,b) in enumerate(zip(cuts,cuts[1:])):slabs.append({'refinement_index':index,'slab_index':i,'closed_x_bounds_um':[a,b],'producer_cap_seconds':60,'audit_cap_seconds':60,'maximum_signature_count':400000})
    for first in range(0,len(reps),64):batches.append({'batch_index':len(batches),'refinement_index':index,'representative_positions':reps[first:first+64],'producer_cap_seconds':60,'audit_cap_seconds':60})
oldplan=load(ROOT/'output/h5-fixed29-atom-partition-20261109/plan.json')
oldprocess=load(ROOT/'output/h5-fixed29-atom-partition-plan-process-20261109/process.json');assert oldprocess['passed'] and oldprocess['closed']
failed=load(ROOT/'output/h5-fixed29-node-atoms-01-0-process-20261109/process.json');assert failed['closed'] and not failed['passed'] and failed['job']['reason_code']==0
inputs.extend([ROOT/'output/h5-fixed29-atom-partition-20261109/plan.json',ROOT/'output/h5-fixed29-atom-partition-plan-process-20261109/process.json',ROOT/'output/h5-fixed29-node-atoms-01-0-process-20261109/process.json',ROOT/'output/h5-fixed29-node-atom-representation-correction-20261109.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Complete quotient of physical area by ALL conditional-query exclusion masks for bracket and insert families. Sixteen adjacent physical X slabs per remaining case preserve the complete stock interval; shared boundaries have zero area. Vertical producer intersects transposed forbidden-query masks of covering nodes. Independent horizontal auditor unions allowed-query masks transposed independently from raw bytes and complements. Every signature area must match. Original raw-node400000-signature failure remains closed and fully charged; no limit is raised. All3138 required representative queries remain frozen in50 consecutive batches, and complete reconciliation remains mandatory. Common-line holes reserved; no optimizer or timer reset.','slabs':slabs,'query_batches':batches,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'inherited_numeric_preparation_seconds':oldplan['inherited_numeric_preparation_seconds']+oldprocess['complete_seconds']+failed['complete_seconds']+control_process['complete_seconds']})
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'slabs':len(slabs),'query_batches':len(batches),'required_representatives':sum(len(b['representative_positions']) for b in batches),'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
