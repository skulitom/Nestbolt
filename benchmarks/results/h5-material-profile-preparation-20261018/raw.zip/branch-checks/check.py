"""Execute the new branch regression separately, validate its twelve public outcomes."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-material-profile-probe-20261018';out=probe/'branch-checks'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
build=load(probe/'build.json');assert build['all_checks_passed'];out.mkdir()
target=Path(load(probe/'preparation.json')['target']);binaries=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1;binary=binaries[0]
command=[str(binary),'--exact','sheets::vstrip::exchange::tests::material_profile_rejection_preserves_incumbent_and_disabled_boundaries','--nocapture']
r=subprocess.run(command,capture_output=True,timeout=120)
(out/'stdout.log').write_bytes(r.stdout);(out/'stderr.log').write_bytes(r.stderr);write(out/'command.json',{'command':command,'exit_code':r.returncode})
assert r.returncode==0 and '1 passed; 0 failed' in r.stdout.decode()
rows=[json.loads(line.removeprefix('PROFILE_REJECT_WITNESS ')) for line in r.stderr.decode().splitlines() if line.startswith('PROFILE_REJECT_WITNESS ')]
assert len(rows)==12 and {(v['seed'],v['enabled'],v['expired']) for v in rows}=={(s,e,x) for s in range(4) for e,x in [(True,False),(False,False),(True,True)]}
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
records=[];canonical_metrics={}
for i,row in enumerate(rows):
    case=out/f'case-{i}';case.mkdir();write(case/'job.json',row['job']);write(case/'observation.json',row)
    assert row['moved']==0
    canonical=next(v['after'] for v in rows if v['seed']==row['seed'] and not v['enabled'])
    assert row['after']==canonical,'Active/expired result differs from the disabled internal incumbent'
    if row['enabled'] and not row['expired']:assert row['stats']['material_profile_exchange_rejections']>0
    else:assert row['stats'].get('material_profile_exchange_rejections',0)==row['stats'].get('directed_exchange_attempts',0)==0
    metrics=[]
    for name in ['before','after']:
        write(case/(name+'.json'),row[name]);args=[str(cli),'validate','--job',str(case/'job.json'),'--layout',str(case/(name+'.json'))]
        checked=subprocess.run(args,capture_output=True,timeout=60)
        (case/(name+'-stdout.json')).write_bytes(checked.stdout);(case/(name+'-stderr.log')).write_bytes(checked.stderr)
        write(case/(name+'-command.json'),{'command':args,'exit_code':checked.returncode});assert checked.returncode==0
        value=json.loads(checked.stdout);assert value['valid'];metrics.append(value['metrics'])
    # Public authored f64 positions predate conversion to the solver's f32
    # frame. Compare operation output to its disabled canonical incumbent,
    # while retaining any original-authored metric difference separately.
    if row['seed'] not in canonical_metrics:canonical_metrics[row['seed']]=metrics[1]
    assert metrics[1]==canonical_metrics[row['seed']]
    records.append({'seed':row['seed'],'enabled':row['enabled'],'expired':row['expired'],'valid_before_and_after':True,
        'canonical_layout_and_metrics_exact':True,'authored_metrics':metrics[0],'canonical_metrics':metrics[1],
        'authored_material_delta':metrics[1]['material_area']-metrics[0]['material_area'],'stats':row['stats']})
assert digest(cli)==expected
shutil.copyfile(binary,out/'authored-tests.exe');shutil.copyfile(__file__,out/'check.py')
write(out/'checks.json',{'all_checks_passed':True,'actual_outcomes':12,'public_validations':24,'CLI_sha256':expected,'test_binary_sha256':digest(binary),'records':records,'quality_claim':False,'measured_searches':0})
print(json.dumps({'actual_outcomes':12,'public_validations':24,'canonical_layouts_and_metrics_exact':True,'active_cases':4}))
