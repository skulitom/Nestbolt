"""Check actual profile witnesses against the frozen public validator."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-material-profile-probe-20261018';out=probe/'profile-checks'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
assert load(probe/'build.json')['all_checks_passed'];out.mkdir()
target=Path(load(probe/'preparation.json')['target']);binaries=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(binaries)==1;binary=binaries[0]
command=[str(binary),'sheets::vstrip::exchange::material_profile::tests','--nocapture','--test-threads=1']
r=subprocess.run(command,capture_output=True,timeout=180)
(out/'stdout.log').write_bytes(r.stdout);(out/'stderr.log').write_bytes(r.stderr);write(out/'command.json',{'command':command,'exit_code':r.returncode})
assert r.returncode==0 and '5 passed; 0 failed' in r.stdout.decode()
rows=[json.loads(line.removeprefix('MATERIAL_PROFILE_WITNESS ')) for line in r.stderr.decode().splitlines() if line.startswith('MATERIAL_PROFILE_WITNESS ')]
assert len(rows)==23 and len({row['case'] for row in rows})==23
assert sum(row['equal_profile'] for row in rows)==19
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
records=[]
def validate(case,job,layout,name):
    write(case/'job.json',job);write(case/(name+'.json'),layout)
    args=[str(cli),'validate','--job',str(case/'job.json'),'--layout',str(case/(name+'.json'))]
    result=subprocess.run(args,capture_output=True,timeout=60)
    (case/(name+'-stdout.json')).write_bytes(result.stdout);(case/(name+'-stderr.log')).write_bytes(result.stderr)
    write(case/(name+'-command.json'),{'command':args,'exit_code':result.returncode})
    return result,json.loads(result.stdout)
for i,row in enumerate(rows):
    case=out/f'case-{i}';case.mkdir();write(case/'observation.json',row);metrics=[]
    for stage in ['before','after']:
        result,checked=validate(case,row['job'],row[stage],stage);assert result.returncode==0 and checked['valid']
        assert checked['metrics']==row[stage+'_metrics'];metrics.append(checked['metrics'])
    if row['equal_profile']:assert metrics[0]['material_area']==metrics[1]['material_area']
    records.append({'case':row['case'],'equal_profile':row['equal_profile'],'valid_before_and_after':True,
        'frozen_CLI_metrics_exact':True,'before_material':metrics[0]['material_area'],'after_material':metrics[1]['material_area']})
# Reproduce the authored counterexample: equal material profiles do not imply
# valid geometry. It must be rejected by the full public validator.
row=next(r for r in rows if r['case']=='context-Mm-false-false')
bad=copy.deepcopy(row['before']);bad['placements'][1]['transform']['translation']=[25.0,74.0]
case=out/'invalid-overlap';case.mkdir();result,checked=validate(case,row['job'],bad,'overlap')
assert not checked['valid'] and any(v['code']=='overlap' for v in checked['violations'])
assert digest(cli)==expected
shutil.copyfile(__file__,out/'check.py')
write(out/'checks.json',{'all_checks_passed':True,'proof_tests_passed':5,'valid_witness_pairs':23,'equal_profiles':19,
    'frozen_CLI_checks':47,'invalid_overlap_rejected':True,'invalid_overlap_exit_code':result.returncode,
    'CLI_sha256':expected,'test_binary_sha256':digest(binary),'records':records,'quality_claim':False,'new_measured_searches':0})
print(json.dumps({'proof_tests':5,'valid_pairs':23,'equal_profiles':19,'frozen_CLI_checks':47,'invalid_overlap_rejected':True}))
