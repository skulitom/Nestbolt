"""Prepare exact material-profile proofs and a regression before early rejection."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-material-profile-probe-20261018'
old=root/'output/h5-exact-reject-probe-20261018';assert out.is_dir() and not (out/'preparation.json').exists()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
for arm in ['baseline','candidate']:assert (out/arm).is_dir()
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
folder=root/'benchmarks/results/h5-exact-state-20261018';audit=load(folder/'layout-checks.json');assert audit['all_checks_passed'] and audit['neutral_pairs']==6
fixtures=[];inputs={}
for pair in audit['pairs']:
    a,b=[folder/row['path'] for row in pair['layouts']]
    assert (a/'job.json').read_bytes()==(b/'job.json').read_bytes()
    fixtures.append([load(a/'job.json'),load(a/'layout.json'),load(b/'layout.json')])
    for f in [a/'job.json',a/'layout.json',b/'layout.json']:
        inputs[f.relative_to(root).as_posix()]=digest(f)
fixture='examples/material-profile-fixtures.json';(out/'candidate'/fixture).write_text(json.dumps(fixtures,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
module='crates/core/src/sheets/vstrip/exchange/material_profile.rs';p=out/'candidate'/module;p.parent.mkdir(exist_ok=True);shutil.copyfile(root/'output/material_profile.rs',p)
exchange='crates/core/src/sheets/vstrip/exchange.rs';p=out/'candidate'/exchange;text=p.read_text(encoding='utf-8')
needle='\nuse super::*;\n';assert text.count(needle)==1;text=text.replace(needle,needle+'mod material_profile;\nuse material_profile::material_profile;\n')
test='''
    #[test]
    fn material_profile_rejection_preserves_incumbent_and_disabled_boundaries() {
        let (job,layout)=equal_inventory_fixture(false);
        for seed in 0..4 {
            for (enabled,expired) in [(true,false),(false,false),(true,true)] {
                let (moved,after,stats)=exercise(&job,&layout,seed,enabled,expired,0);
                eprintln!("PROFILE_REJECT_WITNESS {}",serde_json::json!({
                    "job":&job,"before":&layout,"after":&after,"seed":seed,
                    "enabled":enabled,"expired":expired,"moved":moved,"stats":&stats}));
                assert_eq!(moved,0);assert_eq!(stats.directed_exchanges,0);
                if enabled && !expired {
                    assert!(stats.material_profile_exchange_rejections>0,
                        "Changed poses with proven unchanged charged material must reject early: {stats:?}");
                    assert!(stats.material_profile_exchange_rejections+stats.exact_state_exchange_rejections
                        <=stats.neutral_exchange_rejections);
                } else {
                    assert_eq!(stats.material_profile_exchange_rejections,0);
                    assert_eq!(stats.directed_exchange_attempts,0);
                }
            }
        }
    }
'''
pos=text.rindex('\n}');p.write_text(text[:pos]+test+text[pos:],encoding='utf-8',newline='\n')
stats='crates/core/src/sheets.rs';p=out/'candidate'/stats;text=p.read_text(encoding='utf-8');needle='    pub exact_state_exchange_rejections: u64,';assert text.count(needle)==1
p.write_text(text.replace(needle,needle+'\n    #[serde(skip_serializing_if = "is_zero")]\n    pub material_profile_exchange_rejections: u64,'),encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
rows={arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']}
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),'old_source_files':rows,
    'changed_files':[exchange,stats],'added_files':{module:digest(out/'candidate'/module),fixture:digest(out/'candidate'/fixture)},
    'production_digest':source_digest(),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),
    'target':str(root/'output/h5-material-profile-target-20261018'),'unchanged_prior_tests':117,'new_tests':6,
    'fixture_inputs':inputs,'early_branch_installed':False,'held_out_access':False,'acceptance_guards_unchanged':True}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py');print(json.dumps({'expected_core_tests':123,'prior_tests_unchanged':117,'saved_neutral_pairs':6,'early_branch_installed':False}))
