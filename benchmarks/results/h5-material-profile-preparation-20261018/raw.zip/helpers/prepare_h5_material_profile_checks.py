"""Keep the existing paired methods and add the material-profile proof record."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-material-profile-probe-20261018'
def adapt(s):return s.replace('h5-exact-reject-probe','h5-material-profile-probe').replace('h5-exact-reject-preparation','h5-material-profile-preparation').replace('h5_exact_reject_pilot','h5_material_profile_pilot')
source=root/'scripts/h5_exact_reject_pilot.py';original=source.read_text(encoding='utf-8');text=adapt(original);end=text.index('"""',3)+3
text='''"""Paired development pilot for rejecting proven unchanged-material exchanges.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The baseline is the unchanged preview. The candidate keeps exact-state early
rejection and adds a sufficient unchanged-material check for same-inventory
trials. Profiles use the unchanged validator's original-geometry footprints,
grid and transforms, and require the same immutable job, stock assignments,
sheet maxima and copy identities. Profiles never authorize acceptance.
Every accepted exchange retains the full geometry and strict material guards.
Profile work uses existing validated-vertex charges; budgets and coefficients
are unchanged. All 117 prior tests remain; six new tests cover general profile
proofs, saved panel states, invalid context, real gains and the early branch.
This descriptive pilot cannot close H5 or justify a public comparative claim.
"""'''+text[end:]
text=text.replace("PROBE/'branch-checks/checks.json',","PROBE/'branch-checks/checks.json', PROBE/'profile-checks/checks.json',")
text=text.replace('Isolated exact-state early-rejection candidate, common-line search bonus on','Isolated material-profile rejection candidate, common-line search bonus on')
text=text.replace("'previous_failed_pilot': 'benchmarks/results/h5-larger-return-pilot-20261018/results.json'","'previous_failed_pilot': 'benchmarks/results/h5-exact-reject-pilot-20261018/results.json'")
needle="ROOT/'benchmarks/results/h5-exact-state-20261018/source-review.json'])";assert text.count(needle)==1
text=text.replace(needle,"ROOT/'benchmarks/results/h5-exact-state-20261018/source-review.json',\n                  ROOT/'benchmarks/results/h5-exact-reject-pilot-20261018/verification.json',\n                  ROOT/'benchmarks/results/h5-exact-reject-pilot-20261018/source-review.json'])")
path=root/'scripts/h5_material_profile_pilot.py';assert not path.exists();path.write_text(text,encoding='utf-8',newline='\n');compile(text,str(path),'exec')
functions=lambda s:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
a,b=functions(original),functions(text);names=['blocks','summarize','case','measure'];assert all(a[n]==b[n] for n in names)
record={'reference':source.relative_to(root).as_posix(),'reference_sha256':sha256(source.read_bytes()).hexdigest(),
    'candidate_runner':path.relative_to(root).as_posix(),'runner_sha256':sha256(path.read_bytes()).hexdigest(),
    'identical_function_ASTs':names,'scoring_or_measurement_changed':False}
(probe/'pilot-method.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
for suffix in ['public','harness','branch']:
    s=adapt((root/f'output/check_h5_exact_reject_{suffix}.py').read_text(encoding='utf-8'))
    if suffix=='branch':
        s=s.replace('exact_duplicate_rejection_preserves_incumbent_and_disabled_boundaries','material_profile_rejection_preserves_incumbent_and_disabled_boundaries')
        s=s.replace('EXACT_REJECT_WITNESS ','PROFILE_REJECT_WITNESS ').replace('exact_state_exchange_rejections','material_profile_exchange_rejections')
    p=root/f'output/check_h5_material_profile_{suffix}.py';p.write_text(s,encoding='utf-8',newline='\n');compile(s,str(p),'exec')
print(json.dumps(record))
