"""Prepare the evidence seal and milestone note for the material-profile candidate."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/seal_h5_exact_reject.py').read_text(encoding='utf-8').replace('h5-exact-reject','h5-material-profile').replace('h5_exact_reject','h5_material_profile')
s=s.replace('117 passed; 0 failed','123 passed; 0 failed')
s=s.replace("assert source['all_113_original_tests_unchanged'] and source['other_exchange_runtime_exact'] and source['no_accepted_validation_bypass']", "assert source['all_117_prior_tests_unchanged'] and source['accepted_geometry_and_strict_material_guards_unchanged']\nproof=load(probe/'profile-checks/checks.json'); reconstruction=load(probe/'source-reconstruction/checks.json')\nassert proof['all_checks_passed'] and proof['frozen_CLI_checks']==47 and proof['valid_witness_pairs']==23\nassert reconstruction['all_checks_passed'] and reconstruction['all_reconstructed_bytes_exact']")
s=s.replace('before-early-branch','before-material-profile-branch').replace('exact_state_exchange_rejections','material_profile_exchange_rejections')
s=s.replace("'optimized_core_tests_passed':117,'prior_tests_unchanged':113,'new_tests':4", "'optimized_core_tests_passed':123,'prior_tests_unchanged':117,'new_tests':6,\n    'material_profile_proof_tests':5,'material_profile_witness_pairs':23,'profile_frozen_CLI_checks':47,\n    'invalid_overlap_full_validator_rejected':True,'all_formatted_reconstructed_files_exact':True")
s=s.replace("'exact_exchange_runtime_reversal':True", "'recorded_runtime_substitutions_exact':True")
s=s.replace("for name in helpers:files['helpers/'+name]=root/'output'/name", "helpers.extend(['resume_prepare_h5_material_profile.py','check_h5_material_profile_proofs.py','check_h5_material_profile_source.py','prepare_h5_material_profile_seal.py','material_profile.rs'])\nfor name in helpers:files['helpers/'+name]=root/'output'/name")
s=s.replace("shutil.copyfile(probe/'branch-checks/checks.json',out/'branch-checks.json');", "shutil.copyfile(probe/'profile-checks/checks.json',out/'profile-checks.json')\nshutil.copyfile(probe/'source-reconstruction/checks.json',out/'source-reconstruction.json')\nshutil.copyfile(probe/'branch-checks/checks.json',out/'branch-checks.json');")
start=s.index("doc='''");end=s.index("\n(out.parent",start)
doc='''# Exact material-profile rejection — preparation, 2026-10-18

The [preceding pilot](h5-exact-reject-pilot-20261018.md) validates all 72
outcomes but fails six of eight material comparisons. Exact-state rejection
skips only three of 41 neutral trials. Read-only review of six saved panel
pairs finds identical per-sheet highest original coordinates in every pair,
including five with changed poses. No new geometry or search was used.

This isolated candidate uses the unchanged validator's original-geometry
footprints, transforms, units and grid. Equal profiles require the same
immutable job, sheet-to-stock assignments, exact highest-coordinate bits
and original copy identities. These are sufficient inputs for the existing
charged-material calculation, including outlined stock, margins and defects.
Only same-inventory trials are eligible. Equality rejects a non-improving
trial; it never establishes collision freedom or permits acceptance.
Every accepted exchange still passes the full geometry and strict material
guards. The baseline profile is cached lazily; footprint work is charged
using the existing validated-vertex coefficient. Budgets and coefficients
are unchanged. Public layout conversion is extracted once and reused.

All 123 optimized core tests pass: 117 prior tests unchanged and six new
tests. Before installing the branch, five proof tests pass and the actual
branch regression fails as intended. The original source, executable and
failure log remain. The initial preparation failure also remains preserved.
Twenty-three valid before/after pairs cover saved panel layouts, units,
transforms, outlines, defects, grid boundaries and real improvements.
Forty-seven frozen-CLI checks confirm all witness metrics exactly and reject
the authored overlapping layout despite its equal profile. Twelve actual
branch outcomes pass another 24 frozen-CLI checks, preserving the canonical
incumbent for active, disabled and expired calls across four seeds.

Strict lint/build, ten public outcomes, four CLI comparisons and five pilot
harness tests pass. Normal results and deterministic common replays match
exactly except wall time. Reconstructing and formatting the recorded runtime
substitutions reproduces every candidate source byte. Validator sources match
production; the statistics file adds only one counter.

The planned 72-outcome comparison retains four jobs, two kerfs, three seeds,
rotating sequential three-arm blocks, eight physical CCD0 cores and 60-second
budgets. Block, case, scoring and measurement functions remain AST-identical
to the preceding pilot. The plan is committed before measurement. This is
qualification, not evidence that the material gate passes. The full 13-job
gate stays closed until the smaller pilot succeeds.

All six hosted checks on earlier main `924336a` passed. Production, frozen
inputs, published preview and three READMEs remain unchanged. No integration
or new release is justified by these experimental checks. H2/H5 remain open
and completed milestone weight is 60%.

[Checks](h5-material-profile-preparation-20261018/checks.json),
[proof witnesses](h5-material-profile-preparation-20261018/profile-checks.json),
[branch outcomes](h5-material-profile-preparation-20261018/branch-checks.json),
[source reconstruction](h5-material-profile-preparation-20261018/source-reconstruction.json),
[archive integrity](h5-material-profile-preparation-20261018/integrity.json).
'''
s=s[:start]+"doc="+repr(doc)+s[end:]
(root/'output/seal_h5_material_profile.py').write_text(s,encoding='utf-8',newline='\n')
s=(root/'output/record_h5_exact_reject_preparation.py').read_text(encoding='utf-8').replace('h5-exact-reject','h5-material-profile')
start=s.index("note='''");end=s.index('\ndef append',start)
note='''**N4 material-profile candidate preparation, 2026-10-18:** [all 123 optimized tests pass](../benchmarks/results/h5-material-profile-preparation-20261018.md),
with all 117 prior tests unchanged. The candidate rejects same-inventory
trials whose exact original-geometry profiles prove unchanged charged
material. It uses the existing validator footprints and preserves every
accepted geometry/material check. Budgets and coefficients are unchanged;
profile work uses the existing vertex charge. Five proofs, 23 witness pairs
and 47 frozen-CLI checks cover geometry contexts, real gains and an invalid
overlap; 12 branch outcomes pass another 24 CLI checks. The original failing
branch regression is preserved. Strict lint/build, public parity/replay,
five harness tests and exact formatted-source reconstruction pass. The
unchanged 72-outcome method is committed before measurement. No quality,
integration or release claim; H2/H5 remain open at 60%.
'''
s=s[:start]+'note='+repr(note)+s[end:]
s=s.replace('**N4 exact-state diagnosis, 2026-10-18:**','**N4 exact-state early-rejection outcome, 2026-10-18:**')
s=s.replace('Qualify exact-state early rejection','Qualify exact material-profile early rejection')
(root/'output/record_h5_material_profile_preparation.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared material-profile seal and documentation helpers.')
