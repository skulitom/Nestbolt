//! Rejection evidence only. Equal highest original coordinates and unchanged
//! sheet/stock assignments feed the same charged-material calculation.
//! This deliberately does not establish collision freedom or validity.
use nestbolt_validator::Footprint;
use nestbolt_validator::job::{Job, Layout};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Debug)]
pub(super) struct MaterialProfile<'a> {
    // Retain the immutable job borrow: profiles from different jobs never match.
    job: &'a Job,
    sheets: BTreeMap<String, (String, u64)>,
    copies: BTreeSet<(String, u32)>,
}

impl PartialEq for MaterialProfile<'_> {
    fn eq(&self, other: &Self) -> bool {
        std::ptr::eq(self.job, other.job)
            && self.sheets == other.sheets
            && self.copies == other.copies
    }
}
impl Eq for MaterialProfile<'_> {}

pub(super) fn material_profile<'a>(job: &'a Job, layout: &Layout) -> Option<MaterialProfile<'a>> {
    if layout.units != job.units || layout.placements.is_empty() || layout.sheets.is_empty() {
        return None;
    }
    let mut parts = BTreeMap::new();
    for part in &job.parts {
        if parts.insert(part.id.as_str(), part).is_some() { return None; }
    }
    let mut stocks = BTreeSet::new();
    for stock in &job.stocks {
        if !stocks.insert(stock.id.as_str()) { return None; }
    }
    let mut assignments = BTreeMap::new();
    for sheet in &layout.sheets {
        if !stocks.contains(sheet.stock_id.as_str())
            || assignments.insert(sheet.id.as_str(), sheet.stock_id.as_str()).is_some() {
            return None;
        }
    }
    let mut highest = BTreeMap::<&str, f64>::new();
    let mut copies = BTreeSet::new();
    for placement in &layout.placements {
        let part = parts.get(placement.part_id.as_str())?;
        if placement.copy_index >= part.quantity
            || !copies.insert((placement.part_id.clone(), placement.copy_index))
            || !assignments.contains_key(placement.sheet_id.as_str()) {
            return None;
        }
        // Use the actual validator implementation, including its grid,
        // original components/holes, reflection, rotation and declared units.
        let footprint = Footprint::from_polygons(&part.geometry, job.units, placement.transform).ok()?;
        let top = footprint.bounds()[3];
        if !top.is_finite() { return None; }
        highest.entry(placement.sheet_id.as_str())
            .and_modify(|value| *value = value.max(top)).or_insert(top);
    }
    let mut sheets = BTreeMap::new();
    for (id, stock) in assignments {
        sheets.insert(id.to_owned(), (stock.to_owned(), highest.get(id)?.to_bits()));
    }
    Some(MaterialProfile { job, sheets, copies })
}

#[cfg(test)]
mod tests {
    use super::*;
    use nestbolt_validator::{Polygon, RigidTransform, Units};
    use nestbolt_validator::job::{validate, Margins, Mode, Part, Placement, Rotations, Sheet, Stock};

    fn rect(x: f64, y: f64, w: f64, h: f64) -> Polygon {
        Polygon { outer:vec![[x,y],[x+w,y],[x+w,y+h],[x,y+h]], holes:vec![] }
    }

    fn fixture(units: Units, outline: bool, defect: bool) -> (Job, Layout, Layout) {
        let job=Job {
            version:1,name:"Material-profile rejection witness".into(),units,
            parts:vec![
                Part {id:"top".into(),quantity:1,geometry:vec![rect(0.0,0.0,40.0,5.0)],
                    rotations:Rotations::Free,allow_mirror:true,priority:1.0},
                Part {id:"low".into(),quantity:1,geometry:vec![Polygon {
                    outer:vec![[0.0,0.0],[10.0,0.0],[4.0,10.0]],holes:vec![]}],
                    rotations:Rotations::Free,allow_mirror:true,priority:1.0},
            ],
            stocks:vec![Stock {id:"stock".into(),width:100.0,height:100.0,count:None,
                margins:Margins {left:1.0,right:2.0,bottom:1.0,top:3.0},
                outline:if outline {vec![Polygon {outer:vec![[0.0,0.0],[100.0,0.0],[100.0,70.0],[90.0,70.0],[90.0,100.0],[0.0,100.0]],holes:vec![]}]} else {vec![]},
                defects:if defect {vec![rect(70.0,40.0,5.0,5.0)]} else {vec![]}}],
            clearance:0.2,edge_clearance:0.2,mode:Mode::All,
        };
        let before=Layout {version:1,units,sheets:vec![Sheet{id:"sheet-0".into(),stock_id:"stock".into()}],
            placements:vec![
                Placement {part_id:"top".into(),copy_index:0,sheet_id:"sheet-0".into(),
                    transform:RigidTransform{translation:[20.0,80.0],..Default::default()}},
                Placement {part_id:"low".into(),copy_index:0,sheet_id:"sheet-0".into(),
                    transform:RigidTransform{translation:[10.0,10.0],..Default::default()}},
            ]};
        let mut after=before.clone();after.placements[1].transform=RigidTransform {
            translation:[50.0,20.0],rotation_radians:std::f64::consts::FRAC_PI_2,mirrored:true};
        (job,before,after)
    }

    fn observe(name:&str,job:&Job,before:&Layout,after:&Layout,equal:bool) {
        let first=validate(job,before).unwrap();let second=validate(job,after).unwrap();
        assert!(first.valid && second.valid,"{first:?} {second:?}");
        let a=material_profile(job,before).unwrap();let b=material_profile(job,after).unwrap();
        assert_eq!(a==b,equal);
        if equal {assert_eq!(first.metrics.as_ref().unwrap().material_area,second.metrics.as_ref().unwrap().material_area);}
        eprintln!("MATERIAL_PROFILE_WITNESS {}",serde_json::json!({
            "case":name,"job":job,"before":before,"after":after,"equal_profile":equal,
            "before_metrics":first.metrics,"after_metrics":second.metrics}));
    }

    #[test]
    fn material_profile_saved_panel_pairs_preserve_charged_material() {
        let fixtures:Vec<(Job,Layout,Layout)>=serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),"/../../examples/material-profile-fixtures.json"))).unwrap();
        assert_eq!(fixtures.len(),6);
        for (index,(job,before,after)) in fixtures.iter().enumerate() {
            observe(&format!("saved-panel-{index}"),job,before,after,true);
        }
    }

    #[test]
    fn material_profile_equal_under_transforms_units_margins_outlines_and_defects() {
        for units in [Units::Mm,Units::Inch,Units::Unitless] {
            for outline in [false,true] {
                for defect in [false,true] {
                    let (job,before,after)=fixture(units,outline,defect);
                    observe(&format!("context-{units:?}-{outline}-{defect}"),&job,&before,&after,true);
                }
            }
        }
    }

    #[test]
    fn material_profile_grid_edges_and_real_improvements_remain_distinct() {
        let (job,before,_)=fixture(Units::Mm,false,false);
        for (delta,equal) in [(0.49e-6,true),(0.51e-6,false),(-0.51e-6,false),(-1.0,false)] {
            let mut after=before.clone();after.placements[0].transform.translation[1]+=delta;
            observe(&format!("grid-{delta}"),&job,&before,&after,equal);
            if delta == -1.0 {
                assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area
                    < validate(&job,&before).unwrap().metrics.unwrap().material_area);
            }
        }
        let mut rotated=before.clone();rotated.placements[0].transform.rotation_radians=0.01;
        observe("highest-part-rotation",&job,&before,&rotated,false);
    }

    #[test]
    fn material_profile_rejects_mismatched_context_and_malformed_identifiers() {
        let (job,before,_)=fixture(Units::Mm,false,false);
        let valid=material_profile(&job,&before).unwrap();
        let other_job=job.clone();assert_ne!(valid,material_profile(&other_job,&before).unwrap());
        let mut reordered=before.clone();reordered.placements.reverse();assert_eq!(valid,material_profile(&job,&reordered).unwrap());
        let mut cases=vec![];
        let mut bad=before.clone();bad.units=Units::Inch;cases.push(bad);
        let mut bad=before.clone();bad.placements[0].part_id="unknown".into();cases.push(bad);
        let mut bad=before.clone();bad.placements[0].copy_index=1;cases.push(bad);
        let mut bad=before.clone();bad.placements.push(bad.placements[0].clone());cases.push(bad);
        let mut bad=before.clone();bad.placements[0].sheet_id="unknown".into();cases.push(bad);
        let mut bad=before.clone();bad.sheets[0].stock_id="unknown".into();cases.push(bad);
        let mut bad=before.clone();bad.sheets.push(bad.sheets[0].clone());cases.push(bad);
        let mut bad=before.clone();bad.sheets.push(Sheet{id:"empty".into(),stock_id:"stock".into()});cases.push(bad);
        let mut bad=before.clone();bad.placements[0].transform.translation[0]=f64::NAN;cases.push(bad);
        for bad in cases {assert!(material_profile(&job,&bad).is_none());}
        let mut missing=before.clone();missing.placements.pop();assert_ne!(valid,material_profile(&job,&missing).unwrap());
        let mut changed_job=job.clone();changed_job.stocks.push(Stock{id:"other".into(),..job.stocks[0].clone()});
        let mut reassigned=before.clone();reassigned.sheets[0].stock_id="other".into();
        assert_ne!(material_profile(&changed_job,&before),material_profile(&changed_job,&reassigned));
    }

    #[test]
    fn material_profile_is_rejection_evidence_not_validity() {
        let (job,before,_)=fixture(Units::Mm,false,false);
        let mut overlap=before.clone();overlap.placements[1].transform.translation=[25.0,74.0];
        assert!(!validate(&job,&overlap).unwrap().valid);
        assert_eq!(material_profile(&job,&before),material_profile(&job,&overlap));
    }
}
