"""Seal the experimental exact-state candidate before its unchanged quality pilot."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-material-profile-probe-20261018';out=root/'benchmarks/results/h5-material-profile-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');public=load(probe/'public-checks/checks.json');branch=load(probe/'branch-checks/checks.json');source=load(probe/'source-checks.json')
assert build['all_checks_passed'] and public['all_checks_passed'] and branch['all_checks_passed']
assert '123 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert branch['actual_outcomes']==12 and branch['public_validations']==24
assert source['all_117_prior_tests_unchanged'] and source['accepted_geometry_and_strict_material_guards_unchanged']
proof=load(probe/'profile-checks/checks.json'); reconstruction=load(probe/'source-reconstruction/checks.json')
assert proof['all_checks_passed'] and proof['frozen_CLI_checks']==47 and proof['valid_witness_pairs']==23
assert reconstruction['all_checks_passed'] and reconstruction['all_reconstructed_bytes_exact']
red=load(probe/'before-material-profile-branch/checks.json');assert red['expected_runtime_failure']
assert digest(probe/'before-material-profile-branch/expected-failure.log')==red['log_sha256']
assert digest(probe/'before-material-profile-branch/authored-tests.exe')==red['binary_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not(arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
stats='crates/core/src/sheets.rs'
field='\n    #[serde(skip_serializing_if = "is_zero")]\n    pub material_profile_exchange_rejections: u64,'
s=(probe/'candidate'/stats).read_text(encoding='utf-8');assert s.count(field)==1
assert s.replace(field,'')==(Path(plan['old_probe'])/'candidate'/stats).read_text(encoding='utf-8')
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
assert public['observer_outcomes']==10 and public['CLI_cross_checks']==4
assert all(row['canonical_layout_and_metrics_exact'] for row in branch['records'])
assert sum(r['stats'].get('material_profile_exchange_rejections',0)>0 for r in branch['records'])==4
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json');assert digest(root/method['reference'])==method['reference_sha256'] and digest(root/method['candidate_runner'])==method['runner_sha256']
ci=load(root/'output/ci-main-924336a-confirmed-20261018.json');assert ci['conclusion']=='success' and len(ci['jobs'])==6
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
helpers=['prepare_h5_material_profile.py','check_h5_material_profile_red.py','apply_h5_material_profile.py','build_h5_material_profile.py','prepare_h5_material_profile_checks.py','check_h5_material_profile_branch.py','check_h5_material_profile_public.py','check_h5_material_profile_harness.py','seal_h5_material_profile.py','record_h5_material_profile_preparation.py']
helpers.extend(['resume_prepare_h5_material_profile.py','check_h5_material_profile_proofs.py','check_h5_material_profile_source.py','prepare_h5_material_profile_seal.py','material_profile.rs'])
for name in helpers:files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_material_profile_pilot.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        b=z.read(name);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_functional_checks_pass':True,'optimized_core_tests_passed':123,'prior_tests_unchanged':117,'new_tests':6,
    'material_profile_proof_tests':5,'material_profile_witness_pairs':23,'profile_frozen_CLI_checks':47,
    'invalid_overlap_full_validator_rejected':True,'all_formatted_reconstructed_files_exact':True,
    'expected_failure_preserved':True,'recorded_runtime_substitutions_exact':True,'stats_only_added_counter':True,'strict_lint_passed':True,'observer_build_passed':True,
    'actual_branch_outcomes':12,'branch_frozen_CLI_checks':24,'public_observer_outcomes':10,'public_CLI_cross_checks':4,
    'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,'pilot_harness_tests':5,
    'production_unchanged':True,'measurement_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','source-checks.json','candidate.patch','pilot-method.json']:shutil.copyfile(probe/name,out/name)
shutil.copyfile(probe/'before-material-profile-branch/checks.json',out/'expected-failure.json')
shutil.copyfile(probe/'profile-checks/checks.json',out/'profile-checks.json')
shutil.copyfile(probe/'source-reconstruction/checks.json',out/'source-reconstruction.json')
shutil.copyfile(probe/'branch-checks/checks.json',out/'branch-checks.json');shutil.copyfile(probe/'public-checks/checks.json',out/'public-checks.json')
shutil.copyfile(root/'output/ci-main-924336a-confirmed-20261018.json',out/'main-ci-924336a.json')
doc="# Exact material-profile rejection — preparation, 2026-10-18\n\nThe [preceding pilot](h5-exact-reject-pilot-20261018.md) validates all 72\noutcomes but fails six of eight material comparisons. Exact-state rejection\nskips only three of 41 neutral trials. Read-only review of six saved panel\npairs finds identical per-sheet highest original coordinates in every pair,\nincluding five with changed poses. No new geometry or search was used.\n\nThis isolated candidate uses the unchanged validator's original-geometry\nfootprints, transforms, units and grid. Equal profiles require the same\nimmutable job, sheet-to-stock assignments, exact highest-coordinate bits\nand original copy identities. These are sufficient inputs for the existing\ncharged-material calculation, including outlined stock, margins and defects.\nOnly same-inventory trials are eligible. Equality rejects a non-improving\ntrial; it never establishes collision freedom or permits acceptance.\nEvery accepted exchange still passes the full geometry and strict material\nguards. The baseline profile is cached lazily; footprint work is charged\nusing the existing validated-vertex coefficient. Budgets and coefficients\nare unchanged. Public layout conversion is extracted once and reused.\n\nAll 123 optimized core tests pass: 117 prior tests unchanged and six new\ntests. Before installing the branch, five proof tests pass and the actual\nbranch regression fails as intended. The original source, executable and\nfailure log remain. The initial preparation failure also remains preserved.\nTwenty-three valid before/after pairs cover saved panel layouts, units,\ntransforms, outlines, defects, grid boundaries and real improvements.\nForty-seven frozen-CLI checks confirm all witness metrics exactly and reject\nthe authored overlapping layout despite its equal profile. Twelve actual\nbranch outcomes pass another 24 frozen-CLI checks, preserving the canonical\nincumbent for active, disabled and expired calls across four seeds.\n\nStrict lint/build, ten public outcomes, four CLI comparisons and five pilot\nharness tests pass. Normal results and deterministic common replays match\nexactly except wall time. Reconstructing and formatting the recorded runtime\nsubstitutions reproduces every candidate source byte. Validator sources match\nproduction; the statistics file adds only one counter.\n\nThe planned 72-outcome comparison retains four jobs, two kerfs, three seeds,\nrotating sequential three-arm blocks, eight physical CCD0 cores and 60-second\nbudgets. Block, case, scoring and measurement functions remain AST-identical\nto the preceding pilot. The plan is committed before measurement. This is\nqualification, not evidence that the material gate passes. The full 13-job\ngate stays closed until the smaller pilot succeeds.\n\nAll six hosted checks on earlier main `924336a` passed. Production, frozen\ninputs, published preview and three READMEs remain unchanged. No integration\nor new release is justified by these experimental checks. H2/H5 remain open\nand completed milestone weight is 60%.\n\n[Checks](h5-material-profile-preparation-20261018/checks.json),\n[proof witnesses](h5-material-profile-preparation-20261018/profile-checks.json),\n[branch outcomes](h5-material-profile-preparation-20261018/branch-checks.json),\n[source reconstruction](h5-material-profile-preparation-20261018/source-reconstruction.json),\n[archive integrity](h5-material-profile-preparation-20261018/integrity.json).\n"
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-material-profile-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'all_functional_checks_pass':True,'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size}))
