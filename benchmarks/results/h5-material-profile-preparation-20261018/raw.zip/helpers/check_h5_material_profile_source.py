"""Reconstruct the formatted candidate from its preserved red regression source."""
from pathlib import Path
from hashlib import sha256
import json, shutil, subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-material-profile-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(probe/'preparation.json');out=probe/'source-reconstruction';out.mkdir()
work=root/'output/h5-material-profile-reconstruction-20261018';shutil.copytree(probe/'candidate',work)
rel='crates/core/src/sheets/vstrip/exchange.rs'
text=(probe/'before-material-profile-branch'/rel).read_text(encoding='utf-8')
for before,after in load(probe/'runtime-substitutions.json'):
    assert text.count(before)==1; text=text.replace(before,after)
(work/rel).write_text(text,encoding='utf-8',newline='\n')
r=subprocess.run(['cargo','fmt','--all'],cwd=work,capture_output=True)
(out/'format-stdout.log').write_bytes(r.stdout);(out/'format-stderr.log').write_bytes(r.stderr);assert r.returncode==0
files=sorted(p.relative_to(work).as_posix() for p in work.rglob('*') if p.is_file())
assert files==sorted(p.relative_to(probe/'candidate').as_posix() for p in (probe/'candidate').rglob('*') if p.is_file())
for name in files: assert (work/name).read_bytes()==(probe/'candidate'/name).read_bytes(),name
parent=Path(plan['old_probe'])/'candidate'
stats='crates/core/src/sheets.rs'
field='\n    #[serde(skip_serializing_if = "is_zero")]\n    pub material_profile_exchange_rejections: u64,'
s=(probe/'candidate'/stats).read_text(encoding='utf-8');assert s.count(field)==1
assert s.replace(field,'')==(parent/stats).read_text(encoding='utf-8')
unchanged=[]
for row in plan['old_source_files']['candidate']:
    name=row['path']; assert digest(parent/name)==row['sha256']
    if name not in plan['changed_files']:
        assert digest(probe/'candidate'/name)==row['sha256'];unchanged.append(name)
for name,expected in plan['added_files'].items():assert digest(probe/'candidate'/name)==expected
validator=[p.relative_to(root).as_posix() for p in (root/'crates/validator').rglob('*') if p.is_file()]
for name in validator:assert (root/name).read_bytes()==(probe/'candidate'/name).read_bytes()
checks={'all_checks_passed':True,'reconstructed_formatted_files':len(files),'all_reconstructed_bytes_exact':True,
    'prior_files_unchanged':len(unchanged),'validator_files_exact_to_production':len(validator),
    'stats_only_added_counter':True,'runtime_substitutions_exact':True,'no_compilation_or_search':True}
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'check.py');print(json.dumps(checks))
