"""Install rejection-only material profiles after the retained failing regression."""
from pathlib import Path
from hashlib import sha256
import difflib,json,re,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-material-profile-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');red=load(out/'before-material-profile-branch/checks.json');assert red['expected_runtime_failure']
assert digest(out/'before-material-profile-branch/expected-failure.log')==red['log_sha256']
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel
original=path.read_text(encoding='utf-8');assert path.read_bytes()==(out/'before-material-profile-branch'/rel).read_bytes()
text=original;changes=[]
def replace(before,after):
    global text
    assert text.count(before)==1,(before,text.count(before));text=text.replace(before,after);changes.append((before,after))
before='''    fn exchange_report(
        &mut self,
        strip: &Strip,
        frozen: &[SPProblem],
        layout: &JLayout,
        shape: Shape,
    ) -> Result<Report> {
        let mut sheets = frozen.to_vec();
        sheets.extend(strip.split(layout, shape.sheets)?);
        let layout = self.model.to_layout(&sheets);
        let started = Instant::now();
        let report = validate(self.model.job, &layout)?;
        self.clock.validated(self.model.job, &layout);
        self.check_cost = self.check_cost.max(started.elapsed().as_secs_f64());
        Ok(report)
    }
'''
after='''    fn exchange_layout(
        &self,
        strip: &Strip,
        frozen: &[SPProblem],
        layout: &JLayout,
        shape: Shape,
    ) -> Result<Layout> {
        let mut sheets = frozen.to_vec();
        sheets.extend(strip.split(layout, shape.sheets)?);
        Ok(self.model.to_layout(&sheets))
    }

    fn exchange_report(&mut self, layout: &Layout) -> Result<Report> {
        let started = Instant::now();
        let report = validate(self.model.job, layout)?;
        self.clock.validated(self.model.job, layout);
        self.check_cost = self.check_cost.max(started.elapsed().as_secs_f64());
        Ok(report)
    }
'''
replace(before,after)
replace('''        let baseline = self.exchange_report(strip, frozen, &sep.layout, shape)?;''','''        let baseline_layout = self.exchange_layout(strip, frozen, &sep.layout, shape)?;
        let baseline = self.exchange_report(&baseline_layout)?;''')
replace('''        let before = baseline.metrics.as_ref().expect("valid baseline");''','''        let before = baseline.metrics.as_ref().expect("valid baseline");
        let baseline_profile = std::cell::OnceCell::new();''')
replace('''                    let report = self.exchange_report(strip, frozen, &trial, shape)?;''','''                    let trial_layout = self.exchange_layout(strip, frozen, &trial, shape)?;
                    if same_original_inventory(&members, &victims) {
                        let original_profile = baseline_profile.get_or_init(|| {
                            let profile = material_profile(self.model.job, &baseline_layout);
                            self.clock.validated(self.model.job, &baseline_layout);
                            profile
                        });
                        let trial_profile = material_profile(self.model.job, &trial_layout);
                        self.clock.validated(self.model.job, &trial_layout);
                        if original_profile.as_ref().is_some_and(|profile| {
                            trial_profile.as_ref() == Some(profile)
                        }) {
                            self.stats.neutral_exchange_rejections += 1;
                            self.stats.material_profile_exchange_rejections += 1;
                            continue;
                        }
                    }
                    let report = self.exchange_report(&trial_layout)?;''')
reverse=text
for before,after in reversed(changes):
    assert reverse.count(after)==1;reverse=reverse.replace(after,before)
assert reverse==original
path.write_text(text,encoding='utf-8',newline='\n')
(out/'runtime-substitutions.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
parent=(Path(plan['old_probe'])/'candidate'/rel).read_text(encoding='utf-8');after=path.read_text(encoding='utf-8')
def functions(s):
    s=s.split('#[cfg(test)]',1)[1];matches=list(re.finditer(r'^    fn (\w+)\(',s,re.M));result={}
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(s);chunk=s[m.start():end]
        result[m[1]]=chunk[:chunk.rfind('\n    }')+6]
    return result
a,b=functions(parent),functions(after)
for name,body in a.items():assert b[name]==body,name
assert set(b)-set(a)=={'material_profile_rejection_preserves_incumbent_and_disabled_boundaries'}
for name,expected in plan['added_files'].items():assert digest(out/'candidate'/name)==expected
patch=[]
for name in plan['changed_files']:
    left=(Path(plan['old_probe'])/'candidate'/name).read_text(encoding='utf-8');right=(out/'candidate'/name).read_text(encoding='utf-8')
    patch.extend(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='exact-reject/'+name,tofile='material-profile/'+name))
for name in plan['added_files']:
    if name.endswith('.rs'):patch.extend(difflib.unified_diff([], (out/'candidate'/name).read_text(encoding='utf-8').splitlines(True),fromfile='/dev/null',tofile='material-profile/'+name))
(out/'candidate.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
record={'early_rejection_installed':True,'all_117_prior_tests_unchanged':True,'new_tests':6,'preformat_runtime_reversal_exact':True,
    'full_validator_body_same_except_borrowed_argument':True,'layout_conversion_extracted_once':True,
    'accepted_geometry_and_strict_material_guards_unchanged':True,'neutral_profile_only_rejects':True,
    'profile_footprints_charged_with_existing_validated_vertex_coefficient':True,'baseline_profile_cached_lazily':True,
    'all_budgets_and_coefficients_unchanged':True,'expected_failure_preserved':True,'source_sha256':digest(path)}
(out/'source-checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'apply.py');print(json.dumps(record))
builder=(root/'output/build_h5_exact_reject.py').read_text(encoding='utf-8').replace('h5-exact-reject','h5-material-profile')
(root/'output/build_h5_material_profile.py').write_text(builder,encoding='utf-8',newline='\n')
