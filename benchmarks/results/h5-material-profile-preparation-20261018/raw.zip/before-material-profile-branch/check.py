"""Check profile proofs and preserve the expected missing-branch regression."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-material-profile-probe-20261018'
plan=json.loads((out/'preparation.json').read_bytes());target=Path(plan['target']);assert not target.exists()
work=out/'candidate';failed=out/'before-material-profile-branch';failed.mkdir()
for rel in plan['changed_files']+list(plan['added_files']):
    p=failed/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/rel,p)
command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',str(target),'material_profile','--','--nocapture']
started=datetime.now(timezone.utc).isoformat()
with (failed/'expected-failure.log').open('xb') as log:r=subprocess.run(command,cwd=work,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
text=(failed/'expected-failure.log').read_text(encoding='utf-8')
record={'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,
    'log_sha256':sha256((failed/'expected-failure.log').read_bytes()).hexdigest(),
    'five_profile_proofs_passed': '5 passed; 1 failed' in text,
    'expected_runtime_failure':r.returncode!=0 and '5 passed; 1 failed' in text and 'Changed poses with proven unchanged charged material must reject early' in text,
    'new_measured_searches':0}
bins=list((target/'release/deps').glob('nestbolt_core-*.exe'))
if len(bins)==1:
    shutil.copyfile(bins[0],failed/'authored-tests.exe');record['binary_sha256']=sha256(bins[0].read_bytes()).hexdigest()
(failed/'checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,failed/'check.py');print(json.dumps(record),flush=True)
assert record['expected_runtime_failure']
