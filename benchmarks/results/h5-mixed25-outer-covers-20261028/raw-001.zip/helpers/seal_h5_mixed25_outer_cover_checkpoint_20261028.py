"""Seal the closed full25 outer-cover call and its preserved control correction."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,re,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-mixed25-outer-covers-20261028';PUB=BASE/'publication';NAME='h5-mixed25-outer-covers-20261028';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='b699d1c1845828fe1bfaa675804b32fc4a894528' and not git('diff','HEAD','--name-only')
geometry=load(BASE/'geometry-audit-corrected/checks.json');model=load(BASE/'model-audit/checks.json');response=load(BASE/'response-audit/checks.json');assert all(x['passed'] for x in [geometry,model,response]) and response['status']=='UNKNOWN' and not response['has_source66_candidate']
prior=load(ROOT/'benchmarks/results/h5-cog-feature-source-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main==head;receipt=load(ROOT/'output/h5-cog-feature-main-sync-20261028/receipt.json');assert receipt['new_main']==head and receipt['prior_main_all6_pass'] and receipt['normal_atomic_fast_forward']
jobs=load(PUB/'main-ci-jobs.json')['jobs'];passed=[r['name'] for r in jobs if r['status']=='completed' and r['conclusion']=='success'];live=[r['name'] for r in jobs if r['status']!='completed'];assert len(jobs)==6 and len(passed)==3 and len(live)==3
log=(BASE/'search/solver.log').read_text(encoding='utf-8');search_start=float(re.search(r'Starting search at ([0-9.]+)s',log).group(1));assert search_start==25.42
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-cog-feature-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['h5_outer_cover_geometry_20261028.py','prepare_h5_mixed25_outer_covers_20261028.py','audit_h5_mixed25_outer_covers_20261028.py','prepare_h5_mixed25_cover_control_corrected_20261028.py','audit_h5_mixed25_outer_covers_corrected_20261028.py','build_h5_mixed25_cover_model_20261028.py','audit_h5_mixed25_cover_model_20261028.py','run_h5_mixed25_cover_model_20261028.py','audit_h5_mixed25_cover_response_20261028.py','push_cog_feature_checkpoints_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for a,b in [('geometry-audit-corrected/checks.json','geometry-audit.json'),('geometry-audit-corrected/mode-audit.json','mode-coverage.json'),('geometry-audit/failure.json','preserved-control-failure.json'),('control-corrected/plan.json','corrected-control-plan.json'),('model-audit/checks.json','model-audit.json'),('model-audit/partial-control-check.json','partial-control-check.json'),('response-audit/checks.json','response-audit.json'),('search/result.json','search-result.json'),('publication/main-ci-jobs.json','main-ci-snapshot.json')]:shutil.copyfile(BASE/a,OUT/b)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'prior_three_checkpoints_pushed':True,'prior_main_CI':40742366525,'prior_main_all6_pass':True,'main_CI':40748909850,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
next_action='The full25 outer-cover NoOverlap2D call is CLOSED UNKNOWN, with no assignment, after60.517049s returned/61.248900s shared; preserve0.517049s soft overrun and172 returned-worker branches/zero returned-worker conflicts. Presolve/search transition is25.42s. All25 movers are mandatory around source41; source56 only validates a deliberately partial control and fails all10 omitted mandatory constraints in the actual target. Original264mm-pitch control was source-valid but had20 overlapping cover-component pairs; preserve it and the failed audit. Corrected control uses exact280177um X pitch/269022um row pitch/80000um alternate offset and passes925 original pairs/224edges/74holes8074vertices and8940106 integer cover pairs. All13 modes cover the full112um L-infinity expansion; 2mm slabs give280 cog rectangles with1108.110548mm2 excess over expanded source. Do not restart/extend this closed call or assume UNKNOWN excludes actual packing. Next investigate constraint generation for the full25 source target: begin with the fresh mixed26 fixed-owner free regions (output/h5-mixed26-height-20261028/new-free-regions) and independently audited source-contained capacity rectangles, then add exact/conservative original-source relative no-fit cells only for mover pairs exposed by a complete candidate. Reuse intrinsic pair geometry from output/h5-free23-source-regions-20261028 only after verifying mode/gap/geometry hashes and reverse-delta conventions; never reuse old fixed-owner regions after the core changed. The11 source-mode set (phase7 cog,8 bracket modes,2 insert orientations) is a declared constructive subset, not all-angle coverage. Every candidate must contain all66 originals, undergo source pair/stock/hole checks, and remain rejected until fully valid. Preserve all failed candidates and generated constraints. This is a new algorithm, not a restart of any closed all-pairs or outer-cover model. Predeclare at most8 distinct model solves within one60-second total algorithm budget and90-second shared budget; no60-second allowance per iteration, no repeated identical model after UNKNOWN. Audit the initial relaxation, complete required-part accounting, source56 positive control, cut geometry and their serialized constraints before execution. Source/native/material/fullH5 validation remain required for any full candidate. Keep old valid64,444 necessary allocations,H2 original gate and22 unopened vectors. Three prior checkpoints are now on main b699d1c1 after all6 previous jobs passed; current CI40748909850 is live. Queue this checkpoint until all6 pass, then fresh refs/ancestry/live-run guards before normal atomic push. No production/README change or qualified release.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'independent_audits':3,'solver_calls':1,'search_closed':True,'status':'UNKNOWN','all25_mandatory':True,'target_originals':66,'source56_control_is_partial_only':True,'failed_control_preserved':True,'new_full66_witness':False,'search_started_seconds':search_start,'returned_soft_overrun_seconds':response['returned_soft_overrun_seconds'],'previous_source64_preserved':True,'remaining_necessary_allocations':444,'actual_or_global_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=f'''# Full mixed-part outer-cover model — 2026-10-28

The new model keeps **all 25 remaining parts mandatory** around the verified
41 fixed originals. Its sole bounded call returns **UNKNOWN with no layout**.
This is not an infeasibility result. The call is closed, and H2/H5 remain open
at **60% completed milestone weight**.

This formulation replaces the earlier relative-cell model with conservative
outer rectangle covers and NoOverlap2D. The complete filled outer polygon is
first expanded by a 112 µm square; only then is its union partitioned into
rectangles with disjoint interiors. Cog covers use 2 mm slabs and outward
rounding. These are **outer covers**, unlike the previously used source-contained
capacity rectangles. Holes remain reserved and every original hole is preserved
in source readback. The finite mode set is one 7° cog orientation, eight bracket
quarter/mirror modes and four insert quarter turns; no free-angle claim follows.

Independent coverage checks reconstruct 118 triangle/square Minkowski hulls
across all 13 modes and verify 39,068 same-owner rectangle pairs. Each cog uses
280 rectangles, covering 51,420.521888 mm² versus 50,312.411340 mm² for the
expanded source: **1,108.110548 mm² of conservative excess**. Maximum difference
between legal original transforms and normalized source coordinates is
5.69e-14 mm, far below the retained source-clearance margin.

The initial aligned control at 264 mm pitch passes original-source geometry but
fails the cover model with **20 overlapping component pairs**. Its bytes, source
success and failed cover audit remain preserved. A separate deterministic
construction uses full cover width plus 1 µm horizontally, and the maximum
forbidden vertical interval endpoint plus 1 µm for all 18 adjacent-row offsets.
Its pitches are **280.177 mm × 269.022 mm**, with an 80 mm middle-row offset.
Neither the source modes nor cover resolution changed.

The corrected 56-original control passes **925 original pairs, 224 stock edges,
74 holes / 8,074 hole vertices**, and **8,940,106 integer cover-component pairs**.
The ten absent parts are omitted only from this control. The actual search
requires all 25 movers, accounting for every one of the 66 originals exactly once.

The serialized model audit checks **142 variables, 8,819 constraints, 50
independent anchor coordinates, 67 mode choices, 4,305 component options and
70 partial hint values**. Every source bound, placement link, mandatory-part
constraint, NoOverlap2D entry, capacity and ordering constraint is inspected.
For the partial-control test, exactly ten mandatory-presence domains change
from one to zero in a separate model copy; restoring them recreates the actual
model bytes. That partial assignment fails all ten missing-part constraints
in the actual 66-original target. It is never presented as a complete solution.

The sole 60-second, four-worker call starts search after the logged **25.42 s**
presolve transition and returns UNKNOWN. Solver time is **60.511707 s**,
returned time **60.517049 s** and shared time **61.248900 s**, within the hard
90-second shared limit. The returned **0.517049 s soft overrun** is retained.
The response reports 172 branches and zero conflicts for its returned worker;
these are not aggregate claims about the whole portfolio. There are no
incumbents, source candidates, native calls or H5 completion credit.

The next experiment will test a smaller initial full25 relaxation and add
source collision constraints only for pairs exposed by complete candidates.
It must use the fresh mixed26 fixed-owner regions, verify all reusable intrinsic
pair geometry and retain all 66 required originals. A candidate remains rejected
until every source pair, stock edge and hole passes. Any new sequence will have
one total 60-second algorithm budget, a 90-second shared limit and at most eight
distinct solves; the time budget will not reset for each model. No closed call
is restarted, and UNKNOWN will not trigger a repeat of an identical model.

The previous three checkpoints were pushed normally and atomically to main
**b699d1c1** after all six jobs on 8713c6e1 passed. New
[CI 40748909850](https://github.com/skulitom/Nestbolt/actions/runs/40748909850)
has three passing jobs at this review; web, Linux and Windows checks remain live.
This checkpoint waits for all six jobs and fresh remote guards before pushing.
Production, READMEs and upstream heads/releases are unchanged. The previous
valid64, 444 necessary allocations, original H2 gate and all 22 unopened reserved
vectors remain preserved. No new release qualifies.

Evidence: [source coverage]({NAME}/geometry-audit.json),
[mode coverage details]({NAME}/mode-coverage.json),
[preserved failed control]({NAME}/preserved-control-failure.json),
[complete model audit]({NAME}/model-audit.json),
[partial-control distinction]({NAME}/partial-control-check.json),
[response audit]({NAME}/response-audit.json),
[next step]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The verified archive contains {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including all inputs, failed and corrected controls, models,
source readbacks, logs, response and publication receipt.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 full25 outer-cover model, 2026-10-28:** [the evidence]({link}) verifies
all 13 source modes, complete clearance-expanded covers and a corrected
56-original control. The source-valid initial control's 20 cover collisions
and failed audit remain preserved. The actual target keeps all 25 movers
mandatory, with 142 variables / 8,819 constraints; the partial control fails
all ten missing-part constraints in that actual model. The sole call is CLOSED
UNKNOWN with no candidate (60.517049 s returned / 61.248900 s shared); preserve
the 0.517049 s soft overrun. No infeasibility, native or H5 claim follows.
Next audit a full25 relaxation with source collision constraints added for
exposed pairs, using fresh fixed-owner regions and one total bounded sequence;
never restart an identical model or give each iteration a fresh 60 seconds.
All66 source/native/material checks remain required. The three previous
checkpoints are now on main b699d1c1 after all six prior checks passed; new
CI 40748909850 is live. Production/READMEs, valid64, 444-count frontier,
H2 gate and 22 reserved vectors remain unchanged. H2/H5 stay open at 60%.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
