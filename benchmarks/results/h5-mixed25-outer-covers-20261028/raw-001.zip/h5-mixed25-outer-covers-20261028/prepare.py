"""Prepare a new full mixed-part outer-cover formulation and honest source56 control."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,math,shutil
from shapely.geometry import Polygon,mapping
from h5_outer_cover_geometry_20261028 import square_expand,slab_cover,rectangle_union
from h5_orthogonal_source_model_geometry_20261028 import original_um,transformed,polygon_rectangles,expanded_rectangles
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-outer-covers-20261028';OLD=ROOT/'output/h5-mixed26-height-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
BASE.mkdir();shutil.copyfile(__file__,BASE/'prepare.py');assert load(OLD/'source-audit/checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};fixed=load(OLD/'response-audit/source41.json');remaining=load(OLD/'remaining25.json');assert len(fixed)==41 and len(remaining)==25
inputs=[JOB,OLD/'response-audit/source41.json',OLD/'response-audit/selected-poses.json',OLD/'remaining25.json',OLD/'modes.json',OLD/'source-audit/checks.json',ROOT/'output/h5_outer_cover_geometry_20261028.py',ROOT/'output/h5_orthogonal_source_model_geometry_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'formulation':'new whole-source outer rectangle covers with NoOverlap2D; not source-contained capacity rectangles or the closed no-fit-cell model','fixed_originals':41,'mandatory_movers':25,'target_originals':66,'pad_um':112,'cog_slab_width_um':2000,'outward_bound_rounding_um':1,'source_stock_guard_um':13,'cog_angles_degrees':[7],'bracket_modes':'all quarter turns, mirrored or unmirrored','insert_modes':'all four quarter turns, unmirrored','constructive_subset_only':True,'same_owner_components':'partition expanded whole polygon into rectangles with disjoint interiors before adding constraints','positive_control':'fixed41 plus15 phase7 cogs at264mm pitch in an aligned5-column/3-row packet; ten other mandatory originals are absent only from the control','control_cog_pitch_mm':264,'control_cog_source_lower_left_mm':[6.525,2159.659],'source_stocks':{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},'required_source_gap_mm':.21170867250963943,'native_stock_guard_mm':.011444091796875,'solver_seconds':60,'shared_seconds':90,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'maximum_solver_calls':1,'retry_permitted':False,'source_and_native_required_for_full66':True,'H5_complete':False})
write(BASE/'fixed41.json',fixed);write(BASE/'remaining25.json',remaining)
modes=[];a=math.radians(7);c,s=math.cos(a),math.sin(a);center=139.723742;offset=[-center*c+center*s,-center*s-center*c];cog=parts['cog'];outer=[[(x-center)*c-(y-center)*s,(x-center)*s+(y-center)*c] for x,y in cog['geometry'][0]['outer']]
expanded=square_expand(outer,.112);rects,slabs=slab_cover(expanded,2000);covered=rectangle_union(rects);assert covered.covers(expanded)
modes.append({'id':0,'family':'cog','angle':a,'mirrored':False,'source_translation_offset':offset,'outer_mm':outer,'source_bounds_mm':list(Polygon(outer).bounds),'cover_rectangles_um':rects,'expanded_geometry':mapping(expanded),'cover_geometry':mapping(covered),'slabs':slabs})
for family in ['bracket','insert']:
    for mirror in ([False,True] if family=='bracket' else [False]):
        for quarter in range(4):
            points,lo=transformed(original_um(parts[family]['geometry'][0]['outer']),quarter,mirror);rects=expanded_rectangles(polygon_rectangles(points),112);outer=[[x/1000,y/1000] for x,y in points];expanded=rectangle_union(rects)
            modes.append({'id':len(modes),'family':family,'quarter':quarter,'angle':quarter*math.pi/2,'mirrored':mirror,'source_translation_offset':[-lo[0]/1000,-lo[1]/1000],'outer_mm':outer,'source_bounds_mm':list(Polygon(outer).bounds),'cover_rectangles_um':rects,'expanded_geometry':mapping(expanded),'cover_geometry':mapping(expanded)})
write(BASE/'modes.json',modes)
old_modes=load(OLD/'modes.json');poses=load(OLD/'response-audit/selected-poses.json');fixed_rectangles=[]
for pose in poses:
    ox,oy=pose['anchor_um'];mode=old_modes[pose['mode']]
    for k,(x0,y0,x1,y1) in enumerate(mode['expanded_rectangles_um']):fixed_rectangles.append({'owner':[pose['family'],pose['copy_index']],'component':k,'rectangle_um':[x0+ox,y0+oy,x1+ox,y1+oy]})
write(BASE/'fixed-first-rectangles.json',fixed_rectangles)
cg=modes[0];xmin,ymin,_,_=cg['source_bounds_mm'];anchors=sorted([[math.ceil((6.525-xmin+264*col)*1000),math.ceil((2159.659-ymin+264*row)*1000)] for col in range(5) for row in range(3)])
control=[];source56=list(fixed)
for copy,(x,y) in enumerate(anchors):
    control.append({'family':'cog','copy_index':copy,'mode':0,'anchor_um':[x,y]});source56.append({'part_id':'cog','copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':a,'mirrored':False,'translation':[x/1000+offset[0],y/1000+offset[1]]}})
write(BASE/'control.json',control);write(BASE/'control-source56.json',source56)
write(BASE/'prepared.json',{'modes':len(modes),'cog_rectangles':len(modes[0]['cover_rectangles_um']),'fixed_first_rectangles':len(fixed_rectangles),'control_originals':len(source56),'unplaced_control_originals':10,'solver_calls':0})
print(load(BASE/'prepared.json'))
