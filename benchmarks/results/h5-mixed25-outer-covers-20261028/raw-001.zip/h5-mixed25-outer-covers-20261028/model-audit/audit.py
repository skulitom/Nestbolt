"""Read every saved model field and keep the partial control distinct from target66."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from ortools.sat import cp_model_pb2
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-outer-covers-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,BASE/'control-corrected',MODEL]:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
ga=load(BASE/'geometry-audit-corrected/checks.json');assert ga['passed'];modes=load(BASE/'modes.json');fixed=load(BASE/'fixed-first-rectangles.json');remaining=load(BASE/'remaining25.json');control=load(BASE/'control-corrected/control.json');mp=load(MODEL/'mapping.json');built=load(MODEL/'built.json')
assert digest(BASE/'modes.json')==ga['modes_sha256'] and digest(BASE/'plan.json')==ga['plan_sha256'] and digest(BASE/'fixed-first-rectangles.json')==ga['fixed_rectangles_sha256']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'};assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256']
seenvars=set();seencts=set();hints={};control_values={};allx=[];ally=[];widths=[];heights=[];MIN=-9223372036854775808;MAX=9223372036854775807
def var(ix,name,domain):
    assert ix not in seenvars;seenvars.add(ix);v=p.variables[ix];assert v.name==name and list(v.domain)==domain and {f.name for f,z in v.ListFields()}=={'name','domain'}
def linear(ix,coeffs,lo=MIN,hi=MAX,on=None):
    assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='linear' and {f.name for f,z in ct.ListFields()}<= {'linear','enforcement_literal'}
    assert list(ct.enforcement_literal)==([] if on is None else [on]) and dict(zip(ct.linear.vars,ct.linear.coeffs))==coeffs and len(ct.linear.vars)==len(coeffs) and list(ct.linear.domain)==[lo,hi]
def expr(e,v,offset):
    assert e.offset==offset and list(e.vars)==([] if v is None else [v]) and list(e.coeffs)==([] if v is None else [1]) and {f.name for f,z in e.ListFields()}<= {'vars','coeffs','offset'}
def interval(ix,name,variable,lo,hi,selector=None):
    assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='interval' and ct.name==name and list(ct.enforcement_literal)==([] if selector is None else [selector])
    assert {f.name for f,z in ct.ListFields()}==({'name','interval'} if selector is None else {'name','interval','enforcement_literal'})
    expr(ct.interval.start,variable,lo);expr(ct.interval.size,None,hi-lo);expr(ct.interval.end,variable,hi)
assert len(mp['fixed_components'])==len(fixed)==29
for k,(row,source) in enumerate(zip(mp['fixed_components'],fixed)):
    assert row['index']==k;a,b,c,d=source['rectangle_um'];interval(row['x_interval'],f'fixed_x_{k}',None,a,c);interval(row['y_interval'],f'fixed_y_{k}',None,b,d);allx.append(row['x_interval']);ally.append(row['y_interval']);widths.append(c-a);heights.append(d-b)
assert len(mp['items'])==len(remaining)==25
for i,(item,original) in enumerate(zip(mp['items'],remaining)):
    family,copy=original['family'],original['copy_index'];assert (item['index'],item['family'],item['copy_index'])==(i,family,copy);present,x,y=item['presence'],item['x'],item['y'];var(present,f'present_{i}',[0,1]);var(x,f'x_{i}',[0,1500000]);var(y,f'y_{i}',[0,3000000]);linear(item['mandatory'],{present:1},1,1);hints[present]=1
    known=next((r for r in control if (r['family'],r['copy_index'])==(family,copy)),None);control_values[present]=int(known is not None);control_values[x],control_values[y]=known['anchor_um'] if known else [0,0]
    if known:hints[x],hints[y]=known['anchor_um']
    allowed=[m['id'] for m in modes if m['family']==family];assert [o['mode'] for o in item['options']]==allowed
    for o in item['options']:
        mi=o['mode'];m=modes[mi];select=o['selector'];var(select,f'mode_{i}_{mi}',[0,1]);a,b,c,d=m['source_bounds_mm'];linear(o['x_bound'],{x:1},math.ceil(6513-a*1000),math.floor(1493487-c*1000),select);linear(o['y_bound'],{y:1},math.ceil(6513-b*1000),math.floor(2993487-d*1000),select)
        control_values[select]=int(known is not None and known['mode']==mi)
        if known:hints[select]=int(known['mode']==mi)
        assert len(o['components'])==len(m['cover_rectangles_um'])
        for k,(component,(a,b,c,d)) in enumerate(zip(o['components'],m['cover_rectangles_um'])):
            assert component['component']==k;ix,iy=component['x_interval'],component['y_interval'];interval(ix,f'cover_x_{i}_{mi}_{k}',x,a,c,select);interval(iy,f'cover_y_{i}_{mi}_{k}',y,b,d,select);allx.append(ix);ally.append(iy);widths.append(c-a);heights.append(d-b)
    linear(item['choice'],{**{o['selector']:1 for o in item['options']},present:-1},0,0)
ix=mp['no_overlap_2d'];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,z in ct.ListFields()}=={'no_overlap_2d'} and list(ct.no_overlap_2d.x_intervals)==allx and list(ct.no_overlap_2d.y_intervals)==ally
for key,ints,demands,capacity in [('x_cumulative',allx,heights,2987202),('y_cumulative',ally,widths,1487202)]:
    assert mp[key.replace('cumulative','capacity_um')]==capacity;ix=mp[key];assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert {f.name for f,z in ct.ListFields()}=={'cumulative'} and list(ct.cumulative.intervals)==ints and len(ct.cumulative.demands)==len(demands);expr(ct.cumulative.capacity,None,capacity)
    for e,d in zip(ct.cumulative.demands,demands):expr(e,None,d)
orders=[(a,b) for family in ['bracket','cog','insert'] for group in [[r for r in mp['items'] if r['family']==family]] for a,b in zip(group,group[1:])];assert len(orders)==len(mp['orders'])==22
for row,(a,b) in zip(mp['orders'],orders):assert (row['left'],row['right'])==(a['index'],b['index']);linear(row['constraint'],{a['x']:1,b['x']:-1},hi=0)
assert seenvars==set(range(len(p.variables))) and seencts==set(range(len(p.constraints)))
assert dict(zip(p.solution_hint.vars,p.solution_hint.values))==hints=={int(k):v for k,v in load(MODEL/'actual-partial-hints.json').items()} and len(p.solution_hint.vars)==len(hints)==70
sol=[control_values[i] for i in range(len(p.variables))];assert sol==load(MODEL/'partial-control-assignment.json')
disabled=[r['mandatory'] for r in mp['items'] if r['family']!='cog'];assert disabled==mp['control_only_disabled_mandatory_constraints'] and len(disabled)==10
partial=cp_model_pb2.CpModelProto();partial.CopyFrom(p)
for ix in disabled:partial.constraints[ix].linear.domain[:]=[0,0]
control_check=evaluate(partial,sol,0);assert control_check['expanded_pairs']==ga['control_integer_rectangle_pairs']==8940106
(OUT/'partial-control-model.pb').write_bytes(partial.SerializeToString())
for ix in disabled:partial.constraints[ix].linear.domain[:]=[1,1]
assert partial.SerializeToString()==p.SerializeToString()
for ix in disabled:
    ct=p.constraints[ix];value=sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs));assert value==0 and list(ct.linear.domain)==[1,1]
write(OUT/'partial-control-check.json',{'passed':True,**control_check,'control_source_originals':56,'only_changed_fields':[{'constraint':i,'actual_target_domain':[1,1],'control_only_domain':[0,0]} for i in disabled],'partial_control_fails_actual_target_on_all10_missing_mandatory_constraints':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'variables_verified':len(p.variables),'constraints_verified':len(p.constraints),'mandatory_movers':25,'fixed_originals':41,'actual_target_originals':66,'independent_anchor_coordinates':50,'mode_options_verified':67,'component_options_verified':len(allx),'partial_hints_verified':70,'source56_control_assignment_values_verified':len(sol),'source56_control_component_pairs_verified':control_check['expanded_pairs'],'control_does_not_pass_actual66_target':True,'all_model_fields_verified':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'plan_sha256':digest(BASE/'plan.json'),'source_control_plan_sha256':digest(BASE/'control-corrected/plan.json'),'full66_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'modes.json',BASE/'control-corrected/plan.json',BASE/'geometry-audit-corrected/checks.json',MODEL/'model.pb',MODEL/'mapping.json',MODEL/'plan.json',MODEL/'partial-control-assignment.json',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py']}})
print(load(OUT/'checks.json'))
