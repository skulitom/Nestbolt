"""All25 movers mandatory; whole-source covers share each owner's anchor."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-outer-covers-20261028';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter();ga=load(BASE/'geometry-audit-corrected/checks.json');assert ga['passed']
for n,key in [('plan.json','plan_sha256'),('modes.json','modes_sha256'),('fixed-first-rectangles.json','fixed_rectangles_sha256'),('control-corrected/plan.json','control_plan_sha256')]:assert digest(BASE/n)==ga[key]
modes=load(BASE/'modes.json');remaining=load(BASE/'remaining25.json');control=load(BASE/'control-corrected/control.json');fixed=load(BASE/'fixed-first-rectangles.json');model=cp_model.CpModel();allx=[];ally=[];ws=[];hs=[];fixed_map=[];items=[];hints={};control_values={}
for k,row in enumerate(fixed):
    a,b,c,d=row['rectangle_um'];ix=model.new_fixed_size_interval_var(a,c-a,f'fixed_x_{k}');iy=model.new_fixed_size_interval_var(b,d-b,f'fixed_y_{k}')
    allx.append(ix.index);ally.append(iy.index);ws.append(c-a);hs.append(d-b);fixed_map.append({'index':k,'x_interval':ix.index,'y_interval':iy.index})
for i,original in enumerate(remaining):
    family,copy=original['family'],original['copy_index'];present=model.new_bool_var(f'present_{i}');required=model.add(present==1);x=model.new_int_var(0,1500000,f'x_{i}');y=model.new_int_var(0,3000000,f'y_{i}');options=[];hints[present.index]=1
    known=next((r for r in control if (r['family'],r['copy_index'])==(family,copy)),None);control_values[present.index]=int(known is not None);control_values[x.index],control_values[y.index]=known['anchor_um'] if known else [0,0]
    if known:hints[x.index],hints[y.index]=known['anchor_um']
    for mode in [m for m in modes if m['family']==family]:
        mi=mode['id'];select=model.new_bool_var(f'mode_{i}_{mi}');a,b,c,d=mode['source_bounds_mm'];xbounds=[math.ceil(6513-a*1000),math.floor(1493487-c*1000)];ybounds=[math.ceil(6513-b*1000),math.floor(2993487-d*1000)]
        xc=model.add_linear_constraint(x,*xbounds);xc.only_enforce_if(select);yc=model.add_linear_constraint(y,*ybounds);yc.only_enforce_if(select);components=[]
        for k,(a,b,c,d) in enumerate(mode['cover_rectangles_um']):
            ix=model.new_optional_fixed_size_interval_var(x+a,c-a,select,f'cover_x_{i}_{mi}_{k}');iy=model.new_optional_fixed_size_interval_var(y+b,d-b,select,f'cover_y_{i}_{mi}_{k}')
            allx.append(ix.index);ally.append(iy.index);ws.append(c-a);hs.append(d-b);components.append({'component':k,'x_interval':ix.index,'y_interval':iy.index})
        options.append({'mode':mi,'selector':select.index,'x_bound':xc.index,'y_bound':yc.index,'components':components});control_values[select.index]=int(known is not None and known['mode']==mi)
        if known:hints[select.index]=int(known['mode']==mi)
    choice=model.add(sum(model.get_int_var_from_proto_index(o['selector']) for o in options)==present)
    items.append({'index':i,'family':family,'copy_index':copy,'presence':present.index,'mandatory':required.index,'x':x.index,'y':y.index,'options':options,'choice':choice.index})
xints=[model.get_interval_var_from_proto_index(i) for i in allx];yints=[model.get_interval_var_from_proto_index(i) for i in ally]
no_overlap=model.add_no_overlap_2d(xints,yints);xc=model.add_cumulative(xints,hs,ga['x_capacity_um']);yc=model.add_cumulative(yints,ws,ga['y_capacity_um']);orders=[]
for family in ['bracket','cog','insert']:
    group=[r for r in items if r['family']==family]
    for a,b in zip(group,group[1:]):
        ct=model.add(model.get_int_var_from_proto_index(a['x'])<=model.get_int_var_from_proto_index(b['x']));orders.append({'left':a['index'],'right':b['index'],'constraint':ct.index})
for ix,v in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(ix),v)
assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'items':items,'fixed_components':fixed_map,'no_overlap_2d':no_overlap.index,'x_cumulative':xc.index,'y_cumulative':yc.index,'orders':orders,'x_capacity_um':ga['x_capacity_um'],'y_capacity_um':ga['y_capacity_um'],'control_only_disabled_mandatory_constraints':[r['mandatory'] for r in items if r['family']!='cog']})
write(OUT/'partial-control-assignment.json',[control_values[i] for i in range(len(model.proto.variables))]);write(OUT/'actual-partial-hints.json',{str(k):v for k,v in hints.items()})
inputs=[BASE/n for n in ['plan.json','modes.json','fixed41.json','remaining25.json','fixed-first-rectangles.json','control-corrected/plan.json','control-corrected/control.json','control-corrected/control-source56.json','geometry-audit-corrected/checks.json']];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'actual_target_mandatory_movers':25,'control_omits_ten_originals_only_for_audit':True,'solver_calls':0})
write(OUT/'built.json',{'seconds':time.perf_counter()-started,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'mandatory_movers':25,'fixed_originals':41,'target_originals':66,'independent_anchor_coordinates':50,'mode_options':sum(len(r['options']) for r in items),'component_options_including_fixed':len(allx),'partial_hint_values':len(hints),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
