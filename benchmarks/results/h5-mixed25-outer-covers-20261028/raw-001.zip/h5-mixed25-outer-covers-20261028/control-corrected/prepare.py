"""One exact rectangle construction repairs the model control, without a solver."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-outer-covers-20261028';OUT=BASE/'control-corrected';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');mode=load(BASE/'modes.json')[0];local=mode['cover_rectangles_um'];fixed=load(BASE/'fixed-first-rectangles.json');old=load(BASE/'control.json')
all_rects=[{'owner':r['owner'],'r':r['rectangle_um']} for r in fixed]
for p in old:
    x,y=p['anchor_um'];all_rects += [{'owner':['cog',p['copy_index']],'r':[a+x,b+y,c+x,d+y]} for a,b,c,d in local]
failures=[]
for a,b in combinations(all_rects,2):
    r,s=a['r'],b['r']
    if min(r[2],s[2])>max(r[0],s[0]) and min(r[3],s[3])>max(r[1],s[1]):failures.append({'owners':[a['owner'],b['owner']],'intersection_um':[max(r[0],s[0]),max(r[1],s[1]),min(r[2],s[2]),min(r[3],s[3])]})
assert failures and all(a['owners'][0][0]==a['owners'][1][0]=='cog' for a in failures)
write(BASE/'geometry-audit/failure.json',{'closed':True,'stage':'integer rectangle disjointness of the source-valid56 control','error':'AssertionError','overlapping_cover_component_pairs':len(failures),'source_control_remains_valid':True,'source_modes_or_resolution_changed':False,'solver_calls':0,'correction':'Create a separately recorded control using cover-derived horizontal and alternating-row pitches; preserve the original control and failed audit.'})
write(OUT/'old-control-overlaps.json',failures)
xstep=max(r[2] for r in local)-min(r[0] for r in local)+1;offset=80000
assert xstep-offset>=max(r[2] for r in local)-min(r[0] for r in local)-offset
ray_bounds=[]
# For each possible relative X between two adjacent rows, take the largest
# open forbidden-Y interval endpoint. Adding1um puts the entire second row
# beyond all component overlaps; the finite column-pair list is exhaustive.
for sign in [-1,1]:
    for column_delta in range(-4,5):
        dx=column_delta*xstep+sign*offset;endpoints=[a[3]-b[1] for a in local for b in local if min(a[2],b[2]+dx)>max(a[0],b[0]+dx)]
        ray_bounds.append({'dx_um':dx,'maximum_forbidden_y_endpoint_um':max(endpoints) if endpoints else None})
ystep=max(r['maximum_forbidden_y_endpoint_um'] or 0 for r in ray_bounds)+1
assert 2*ystep>=max(r[3] for r in local)-min(r[1] for r in local)
xmin,ymin,_,_=mode['source_bounds_mm'];xbase=math.ceil((6.525-xmin)*1000);ybase=math.ceil((2159.659-ymin)*1000)
anchors=sorted([[xbase+col*xstep+(offset if row==1 else 0),ybase+row*ystep] for col in range(5) for row in range(3)])
control=[];rows=load(BASE/'fixed41.json')
for copy,(x,y) in enumerate(anchors):
    control.append({'family':'cog','copy_index':copy,'mode':0,'anchor_um':[x,y]});rows.append({'part_id':'cog','copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':mode['angle'],'mirrored':False,'translation':[x/1000+mode['source_translation_offset'][0],y/1000+mode['source_translation_offset'][1]]}})
write(OUT/'control.json',control);write(OUT/'control-source56.json',rows);write(OUT/'row-separation-proof.json',ray_bounds)
inputs=[BASE/n for n in ['plan.json','modes.json','fixed41.json','fixed-first-rectangles.json','control.json','control-source56.json','geometry-audit/source-control-readback.json','geometry-audit/failure.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'exact cover-bound construction; horizontal bbox width plus1um and maximum forbidden-Y endpoint plus1um for all18 relative X offsets between adjacent rows; no optimization','xstep_um':xstep,'ystep_um':ystep,'alternate_row_x_offset_um':offset,'source_control_originals':56,'missing_mandatory_target_originals':10,'cover_resolution_unchanged_um':2000,'solver_calls':0,'native_calls':0})
print({'xstep_um':xstep,'ystep_um':ystep,'preserved_bad_cover_pairs':len(failures),'source_originals':len(rows),'solver_calls':0})
