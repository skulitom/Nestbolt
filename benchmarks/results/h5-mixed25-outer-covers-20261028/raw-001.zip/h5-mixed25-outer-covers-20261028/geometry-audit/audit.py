"""Independent triangle-square coverage, integer partition and source56 checks."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from itertools import combinations
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,box,shape
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed25-outer-covers-20261028';OUT=BASE/'geometry-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');mode_results=[];total_hulls=0;component_pairs=0;maximum_transform_error=0
for mode in modes:
    part=parts[mode['family']];a=mode['angle'];c,s=math.cos(a),math.sin(a);m=-1 if mode['mirrored'] else 1;ox,oy=mode['source_translation_offset']
    original=[(m*x*c-y*s+ox,m*x*s+y*c+oy) for x,y in part['geometry'][0]['outer']];delta=max(abs(v-w) for p,q in zip(original,mode['outer_mm']) for v,w in zip(p,q));assert delta<1e-9;maximum_transform_error=max(maximum_transform_error,delta)
    polygon=Polygon(mode['outer_mm']);rects=mode['cover_rectangles_um'];rect_shapes=[box(x0/1000,y0/1000,x1/1000,y1/1000) for x0,y0,x1,y1 in rects];cover=unary_union(rect_shapes)
    assert cover.equals(shape(mode['cover_geometry'])) and cover.covers(polygon)
    for x0,y0,x1,y1 in rects:assert all(isinstance(x,int) for x in [x0,y0,x1,y1]) and x0<x1 and y0<y1
    for ra,rb in combinations(rects,2):assert ra[2]<=rb[0] or rb[2]<=ra[0] or ra[3]<=rb[1] or rb[3]<=ra[1];component_pairs+=1
    triangles=list(shapely.constrained_delaunay_triangles(polygon).geoms);assert unary_union(triangles).equals(polygon)
    hulls=[]
    for triangle in triangles:
        hull=MultiPoint([(x+dx,y+dy) for x,y in list(triangle.exterior.coords)[:-1] for dx in [-.112,.112] for dy in [-.112,.112]]).convex_hull
        assert cover.covers(hull),mode['id'];hulls.append(hull);total_hulls+=1
    reference=unary_union(hulls);built=shape(mode['expanded_geometry']);assert reference.symmetric_difference(built).area<1e-8
    bb=polygon.bounds;cb=cover.bounds;overhang=[bb[0]-cb[0],bb[1]-cb[1],cb[2]-bb[2],cb[3]-bb[3]];assert max(overhang)<=.114000001
    assert Polygon(original).difference(cover).is_empty
    mode_results.append({'mode':mode['id'],'family':mode['family'],'source_vertices':len(original),'triangle_square_hulls':len(hulls),'cover_rectangles':len(rects),'source_area_mm2':polygon.area,'expanded_area_mm2':reference.area,'cover_area_mm2':cover.area,'cover_area_excess_over_expanded_mm2':cover.area-reference.area,'bbox_overhang_mm':overhang,'source_transform_error_mm':delta,'complete_expansion_covered':True})
assert len(modes)==13 and Counter(m['family'] for m in modes)=={'cog':1,'bracket':8,'insert':4}
fixed=load(BASE/'fixed41.json');remaining=load(BASE/'remaining25.json');all_keys={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};fixed_keys={(r['part_id'],r['copy_index']) for r in fixed};moving_keys={(r['family'],r['copy_index']) for r in remaining};assert len(fixed_keys)==41 and len(moving_keys)==25 and fixed_keys.isdisjoint(moving_keys) and fixed_keys|moving_keys==all_keys
control=load(BASE/'control.json');rows=load(BASE/'control-source56.json');expected=fixed_keys|{('cog',i) for i in range(15)};checked=audit(job,rows,plan['source_stocks'],plan['required_source_gap_mm'],plan['native_stock_guard_mm'],expected);assert checked['valid'];write(OUT/'source-control-readback.json',checked)
fixed_rects=load(BASE/'fixed-first-rectangles.json');old=ROOT/'output/h5-mixed26-height-20261028';old_modes=load(old/'modes.json');poses=load(old/'response-audit/selected-poses.json');rebuilt=[]
for pose in poses:
    x,y=pose['anchor_um'];md=old_modes[pose['mode']]
    for k,(a,b,c,d) in enumerate(md['expanded_rectangles_um']):rebuilt.append({'owner':[pose['family'],pose['copy_index']],'component':k,'rectangle_um':[a+x,b+y,c+x,d+y]})
assert fixed_rects==rebuilt and len(fixed_rects)==29
rectangles=[r['rectangle_um'] for r in fixed_rects]
for control_item in control:
    assert control_item['mode']==0;md=modes[0];x,y=control_item['anchor_um']
    row=next(r for r in rows if r['part_id']=='cog' and r['copy_index']==control_item['copy_index']);assert row['transform']['rotation_radians']==md['angle']
    assert row['transform']['translation']==[x/1000+md['source_translation_offset'][0],y/1000+md['source_translation_offset'][1]]
    rectangles += [[a+x,b+y,c+x,d+y] for a,b,c,d in md['cover_rectangles_um']]
control_pairs=0
for a,b in combinations(rectangles,2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1];control_pairs+=1
# Both capacities use the original guarded stock plus the largest global cover overhang.
limits=[6399,6399,1493601,2993601]
for a,b,c,d in rectangles:assert limits[0]<=a<c<=limits[2] and limits[1]<=b<d<=limits[3]
capacities=[]
for axis in [0,1]:
    events={}
    for a,b,c,d in rectangles:
        lo,hi,weight=(a,c,d-b) if axis==0 else (b,d,c-a);events[lo]=events.get(lo,0)+weight;events[hi]=events.get(hi,0)-weight
    total=peak=0
    for _,change in sorted(events.items()):total+=change;peak=max(peak,total)
    capacity=limits[3]-limits[1] if axis==0 else limits[2]-limits[0];assert total==0 and peak<=capacity;capacities.append({'axis':axis,'capacity_um':capacity,'peak_um':peak,'slack_um':capacity-peak})
write(OUT/'mode-audit.json',mode_results);write(OUT/'control-capacities.json',capacities)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'modes_verified':13,'triangle_square_hulls_covered':total_hulls,'same_owner_integer_rectangle_pairs':component_pairs,'cog_cover_rectangles':len(modes[0]['cover_rectangles_um']),'cog_cover_area_mm2':mode_results[0]['cover_area_mm2'],'cog_expanded_area_mm2':mode_results[0]['expanded_area_mm2'],'cog_cover_excess_mm2':mode_results[0]['cover_area_excess_over_expanded_mm2'],'maximum_original_transform_roundoff_mm':maximum_transform_error,'roundoff_below_guard_margin':True,'control_originals':56,'omitted_control_originals':10,'actual_target_originals':66,'all25_movers_accounted_for':True,'control_source_pairs':checked['same_sheet_pairs'],'control_stock_edges':checked['stock_edges'],'control_holes':checked['cutouts'],'control_hole_vertices':checked['hole_vertices'],'control_cover_components':len(rectangles),'control_integer_rectangle_pairs':control_pairs,'cover_bounds_um':limits,'x_capacity_um':limits[3]-limits[1],'y_capacity_um':limits[2]-limits[0],'full66_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False,'plan_sha256':digest(BASE/'plan.json'),'modes_sha256':digest(BASE/'modes.json'),'fixed_rectangles_sha256':digest(BASE/'fixed-first-rectangles.json')})
inputs=[BASE/n for n in ['plan.json','modes.json','fixed41.json','remaining25.json','fixed-first-rectangles.json','control.json','control-source56.json']]+[old/'response-audit/selected-poses.json',old/'modes.json',ROOT/'output/h5_legacy64_source_readback.py'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
print(load(OUT/'checks.json'))
