from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-joint-optional-trees-20261106';OUT=ROOT/'benchmarks/results'/NAME
BASE=ROOT/'output/h5-first57-joint-optional-trees-20261106'
INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
PROCESS=ROOT/'output/h5-first57-joint-optional-trees-process-20261106'
IPROCESS=ROOT/'output/h5-first57-broader-insert-covers-process-20261106'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
audit=load(BASE/'audit/checks.json');ia=load(INS/'audit/checks.json')
assert audit['passed'] and ia['passed'] and audit['new_fixed29_choices_excluded']==11 and audit['remaining_fixed29_choices']==52
assert audit['tree_records_verified']==19134 and audit['total_joint_graph_witnesses']==32 and len(audit['budget_limited_cases'])==20
processes=[load(p/'process.json') for p in [IPROCESS,PROCESS]]
assert all(p['closed'] and p['exit_code']==0 and not p['timeout'] and p['complete_process_cap_overrun_seconds']==0 for p in processes)
assert audit['case_complete_cap_overrun_seconds']==0
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104','h5-source-polygons-and-joint-frontier-20261104','h5-mandatory-clique-exclusions-20261104','h5-full-frontier-proofs-20261106','h5-frontier-insert-exclusions-20261106','h5-deferred-conflict-tree-20261106','h5-optional-bracket-trees-20261106']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for folder in [BASE,INS,PROCESS,IPROCESS]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_joint_optional*20261106.py','*h5_broader_insert*20261106.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-joint-optional-trees-report-20261106.md','prepare_h5_local_conflict_covers_20261104.py']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(INS/'audit/checks.json','insert-audit.json'),(BASE/'audit/checks.json','joint-audit.json'),(BASE/'audit/remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(BASE/'audit/joint-graph-witnesses.json','joint-graph-witnesses.json')]:
    shutil.copyfile(source,OUT/name)
write(OUT/'process-ledger.json',{'new_complete_preparation_seconds':sum(p['complete_process_seconds'] for p in processes),
    'processes':processes,'independent_audit_seconds':[ia['seconds'],audit['seconds']],
    'per_case_search_cutoff_seconds':0.70,'per_case_complete_cap_seconds':0.75,'expanded_node_cap':1500,
    'budget_limited_cases':audit['budget_limited_cases'],'all_limited_processes_closed':True,
    'case_complete_cap_overrun_seconds':0,'placement_solver_calls':0,'native_calls':0,
    'full_construction_60_90_budget_claimed':False})
write(OUT/'next-step.json',{'all_prior_placement_calls_closed':True,'current_joint_tree_process_closed':True,
    'remaining_fixed29_choices':52,'total_fixed29_choices_excluded':403,'joint_graph_witnesses':32,'limited_joint_cases':20,
    'next_method':'Assess exact union-coverage conflict certificates. The current conflict graph adds an edge only when one pair of source-inner rectangles overlaps for every anchor pair. For a cell pair, derive the full closed relative-anchor box and all open collision rectangles from the two source-inner component sets. The union may cover the whole relative box even when no individual rectangle does. Independently verify every boundary and open interval class using exact integer/rational arithmetic; touching open obstacle boundaries alone must not count as coverage. First quantify genuinely new conflict edges on the retained complete covers or saved witnesses. Only source-certified added edges justify a stronger joint model with fresh limits and independent complete tree replay. If no edges are added, do not rerun the closed model. Preserve every old open tree, cutoff, witness and exclusion; any later construction must charge all consumed preparation.',
    'survivors':'output/h5-first57-joint-optional-trees-20261106/audit/remaining-fixed29-choices.json',
    'joint_witnesses':'output/h5-first57-joint-optional-trees-20261106/audit/joint-graph-witnesses.json',
    'source_inner_geometry':'output/h5-first57-necessary-rectangles-20261104/geometry-domains.json',
    'bracket_geometry':'output/h5-first57-full-frontier-cliques-20261104',
    'insert_geometry':'output/h5-first57-broader-insert-covers-20261106',
    'new_union_conflict_proof_prepared':False,'whole_allocation_candidates':440,
    'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'new_continuous_choices_excluded':11,'remaining_fixed29_choices':52,'total_fixed29_choices_excluded':403,'original_fixed29_choices':455,
    'complete_insert_cells_verified':21067,'insert_clique_pair_certificates':218597,
    **{k:audit[k] for k in ['tree_records_verified','branch_cliques','closed_count_leaves','propagation_covers','propagation_removals','mandatory_support_pair_checks','clique_pair_checks','strict_source_inner_pair_evaluations']},
    'joint_graph_witnesses':32,'limited_joint_cases':20,'placement_solver_calls':0,'native_calls':0,
    'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-joint-optional-trees-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 joint bracket/insert trees:** [independent continuous-cover and joint replay]({link}) verifies 21,067 complete insert cells, then 19,134 tree records, 9,590 mandatory covers and 444,620 ordered removals. Eleven complete trees exclude fixed29/cog choices, leaving 52 (403 of 455 excluded). Thirty-one new joint graph witnesses plus the independently rechecked prior witness remain necessary selections only; 20 cutoff cases retain explicit open leaves. No partial tree is an exclusion or a source placement. Complete preparations take 13.917995 and 34.529171 s; all complete-case/process caps pass. There are no placement solver/native calls or full construction budget claims. Next assess exact unions of source-inner collision rectangles for genuinely stronger pair conflicts; do not repeat a closed model without new certified constraints. All consumed preparation remains chargeable. Full66 checks, 440 whole allocations and H2/H5 stay open at 60%. Five prior-main CI jobs pass; the Windows native check is still live at report preparation.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [optional bracket trees](../benchmarks/results/h5-optional-bracket-trees-20261106.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [joint bracket/insert trees](../benchmarks/results/{NAME}.md).',1)
a='proofs exclude another 15. Mandatory proof trees exclude four more, and optional\nbracket trees exclude five, leaving 63 choices (392 of 455 excluded). Sixty-one\nbracket-graph witnesses, one node-limited case and the earlier joint witness\nremain unresolved. Fresh complete joint bracket/insert proofs are next.\nAll prior calls and bounded processes stay closed.'
b='proofs exclude another 15. Mandatory proof trees exclude four more, optional\nbracket trees exclude five, and joint bracket/insert trees exclude eleven.\nThere are 52 remaining choices (403 of 455 excluded): 32 necessary joint graph\nwitnesses and 20 cutoff cases. Exact union-based source-inner pair conflicts\nare the next method to assess. All prior calls and bounded processes stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
