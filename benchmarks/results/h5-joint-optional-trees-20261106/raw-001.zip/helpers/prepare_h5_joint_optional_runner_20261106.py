from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_optional_bracket_trees_20261106.py').read_text(encoding='utf-8')
s=s.replace('optional-bracket-trees','joint-optional-trees').replace('prepare_h5_optional_bracket_trees','prepare_h5_joint_optional_trees').replace('50','65')
with (O/'run_h5_joint_optional_trees_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
