from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-broader-insert-covers-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104'
FRONTIER=ROOT/'output/h5-first57-optional-bracket-trees-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
HELPER=ROOT/'output/prepare_h5_local_conflict_covers_20261104.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for b in [BR,FRONTIER,COVER]:assert load(b/'audit/checks.json')['passed']
remaining={tuple(r['empty_sites']) for r in load(FRONTIER/'audit/remaining-fixed29-choices.json')}
selection=[{'choice_index':i,'empty_sites':r['empty_sites'],'bracket_nodes':r['nodes'],
            'bracket_clique_bound':r['continuous_bracket_capacity_upper_bound']}
           for i,r in enumerate(load(BR/'audit/checks.json')['choices']) if tuple(r['empty_sites']) in remaining]
assert len(selection)==63
geometry=load(SOURCE/'geometry-domains.json')
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in ['intervals','conflict','first_fit','saturation_cover']]
assert len(functions)==4;exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
inputs=[Path(__file__),HELPER,SOURCE/'geometry-domains.json',FRONTIER/'audit/remaining-fixed29-choices.json']+[b/n for b in [BR,FRONTIER,COVER] for n in ['audit/plan.json','audit/checks.json']]+[COVER/f'geometry-{g:02d}-cover.json' for g in [8,9]]+[BR/f"choice-{r['choice_index']:02d}.json" for r in selection]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'selection':selection,'preparation_cap_seconds':25,'maximum_process_seconds':35,
    'method':'For all63 remaining fixed29 arrangements, reconstruct every insert anchor box from the audited full continuous mask cover, including all closed boundary cells. Split at most50mm per axis. Retain every cell; no unsupported mandatory-bracket assumption or sampled filtering. Certify self-conflicts and a disjoint pairwise-conflicting clique cover of all cells. These complete source-inner domains support the new joint bracket/insert graph only; no source placement is claimed.',
    'placement_solver_calls':0,'native_calls':0,'repeat_permitted':False})
summaries=[]
for choice,row in enumerate(selection):
    bits=sum(1<<i for i in row['empty_sites']);nodes=[]
    for gid in [8,9]:
        for ri,(mask,x,y,z,w,*_) in enumerate(load(COVER/f'geometry-{gid:02d}-cover.json')):
            if mask&~bits:continue
            for xi,(l,r) in enumerate(intervals(x,z)):
                for yi,(b,t) in enumerate(intervals(y,w)):
                    nodes.append({'node':len(nodes),'geometry':gid,'cover_box':ri,'cell':[xi,yi],'bounds_um':[l,b,r,t]})
    adj=[1<<i for i in range(len(nodes))];self_cert=[]
    for i,a in enumerate(nodes):
        proof=conflict(a,a);assert proof is not None;self_cert.append(proof)
        for j in range(i):
            if conflict(a,nodes[j]) is not None:adj[i]|=1<<j;adj[j]|=1<<i
    orders=[list(range(len(nodes))),list(reversed(range(len(nodes)))),
            sorted(range(len(nodes)),key=lambda n:(-adj[n].bit_count(),n))]
    attempts=[first_fit(order,adj) for order in orders]+[saturation_cover(adj)]
    best=min(range(len(attempts)),key=lambda i:(len(attempts[i]),i));cert=[]
    for group in attempts[best]:
        pairs=[]
        for k,a in enumerate(group):
            for b in group[k+1:]:
                proof=conflict(nodes[a],nodes[b]);assert proof is not None;pairs.append([a,b,*proof])
        cert.append({'nodes':group,'strict_overlap_certificates':pairs})
    data={'source_selection':row,'empty_sites':row['empty_sites'],'nodes':nodes,'self_certificates':self_cert,
          'candidate_cover_counts':[len(g) for g in attempts],'selected_cover':best,'insert_cliques':cert,
          'insert_capacity_upper_bound':len(cert),'diagnostic_excluded':len(cert)<8}
    write(OUT/f'choice-{choice:02d}.json',data)
    summaries.append({'empty_sites':row['empty_sites'],'complete_insert_cells':len(nodes),'insert_clique_bound':len(cert),'diagnostic_excluded':len(cert)<8})
    assert time.perf_counter()-started<25
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':summaries,
    'independent_audit_pending':True,'placement_solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False})
print({'choices':len(summaries),'insert_cells':sum(r['complete_insert_cells'] for r in summaries),'seconds':time.perf_counter()-started})
