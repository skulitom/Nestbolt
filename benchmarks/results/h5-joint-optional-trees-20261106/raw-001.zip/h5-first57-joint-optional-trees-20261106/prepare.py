"""Two-family necessary graph, with complete optional branches and mandatory support."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-joint-optional-trees-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104'
INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
FRONTIER=ROOT/'output/h5-first57-optional-bracket-trees-20261106'
KNOWN=ROOT/'output/h5-first57-deferred-conflict-tree-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';HELPER=ROOT/'output/prepare_h5_local_conflict_covers_20261104.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def members(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask-=bit
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for b in [BR,INS,FRONTIER,KNOWN]:assert load(b/'audit/checks.json')['passed']
known=load(KNOWN/'audit/necessary-graph-witnesses.json');assert len(known)==1
known_empty=known[0]['source_selection']['empty_sites'];assert known_empty==[4,9,14]
selection=[r for r in load(INS/'audit/joint-candidates.json') if r['empty_sites']!=known_empty];assert len(selection)==62
geometry=load(SOURCE/'geometry-domains.json')
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='conflict']
assert len(functions)==1;exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
inputs=[Path(__file__),HELPER,SOURCE/'geometry-domains.json',INS/'audit/joint-candidates.json',KNOWN/'audit/necessary-graph-witnesses.json']+[b/n for b in [BR,INS,FRONTIER,KNOWN] for n in ['audit/plan.json','audit/checks.json']]+[BR/f"choice-{r['choice_index']:02d}.json" for r in selection]+[INS/f"choice-{r['insert_choice_index']:02d}.json" for r in selection]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'selection':selection,'known_joint_witness_not_researched':known_empty,
    'per_case_search_cutoff_seconds':0.70,'per_case_complete_cap_seconds':0.75,'maximum_expanded_nodes_per_case':1500,
    'global_search_cutoff_seconds':50,'preparation_cap_seconds':55,'maximum_process_seconds':65,
    'stop_case_after_first_joint_graph_witness':True,'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,
    'method':'The new model adds complete insert domains to the62 still-open bracket-only cases, requiring eight originals of each family. Retain all bracket and insert cells. A source-inner conflict clique permits at most one original. Family-specific complete clique partitions bound remaining counts. If the cover count equals the required family count, every clique is mandatory: remove a candidate only when it conflicts with every active member of a different mandatory group. Record each complete mandatory cover and every ordered removal. Otherwise branch once on each candidate of one conflict clique, preserving compatible cells of both families, plus skipping that whole clique. All branches are complete. Eight selected cells of each family create only a joint necessary-graph witness. Every time/node cutoff and post-witness branch is open; only an independently fully closed tree excludes a fixed arrangement. The already-known joint graph witness[4,9,14] is carried forward without searching it again.'})
summaries=[]
for choice,row in enumerate(selection):
    case_started=time.perf_counter();deadline=min(started+50,case_started+0.70)
    br=load(BR/f"choice-{row['choice_index']:02d}.json")
    ins=load(INS/f"choice-{row['insert_choice_index']:02d}.json")
    assert br['empty_sites']==ins['empty_sites']==row['empty_sites']
    offset=len(br['nodes']);nodes=br['nodes']+ins['nodes']
    original=[[sum(1<<n for n in c['nodes']) for c in br['cliques']],
              [sum(1<<(offset+n) for n in c['nodes']) for c in ins['insert_cliques']]]
    root_available=[(1<<offset)-1,((1<<len(nodes))-1)^((1<<offset)-1)]
    universe=(1<<len(nodes))-1;compatible={n:0 for n in range(len(nodes))};graph_complete=True
    for a in range(len(nodes)):
        if time.perf_counter()>=deadline:graph_complete=False;break
        for b in range(a+1,len(nodes)):
            if conflict(nodes[a],nodes[b]) is None:
                compatible[a]|=1<<b;compatible[b]|=1<<a
    conflicting={n:universe&~compatible[n] for n in compatible}
    records=[];witness=None;expanded=0
    def cover(family,mask,need,seed):
        options=[[g&mask for g in partition if g&mask] for partition in [original[family],seed]]
        best=min(options,key=len)
        if len(best)<need:return best
        vertices=list(members(mask))
        for order in [vertices,sorted(vertices,key=lambda n:(-(conflicting[n]&mask).bit_count(),n))]:
            groups=[]
            for v in order:
                options=[i for i,g in enumerate(groups) if not g&~conflicting[v]]
                if options:
                    i=max(options,key=lambda i:(groups[i].bit_count(),-i));groups[i]|=1<<v
                else:groups.append(1<<v)
            if len(groups)<len(best):best=groups
            if len(best)<need:break
        return best
    def visit(available,chosen,seeds):
        global expanded,witness
        index=len(records);record={'node':index,'expanded':False,'propagation':[]};records.append(record)
        def opened(reason):
            record.update({'kind':'open','reason':reason,'case_elapsed':time.perf_counter()-case_started,
                           'global_elapsed':time.perf_counter()-started});return index
        if not graph_complete:return opened('graph_preparation_limit')
        if witness is not None:return opened('earlier_joint_graph_witness')
        if time.perf_counter()>=deadline or expanded>=1500:return opened('time_or_expansion_limit')
        record['expanded']=True;expanded+=1;available=list(available);seeds=[list(s) for s in seeds]
        while True:
            if time.perf_counter()>=deadline:return opened('time_or_expansion_limit')
            need=[8-len(c) for c in chosen]
            if need==[0,0]:
                witness=[list(c) for c in chosen];record.update({'kind':'open_graph_witness','witness':witness});return index
            groups=[cover(f,available[f],need[f],seeds[f]) for f in range(2)];seeds=groups
            for f in range(2):
                if len(groups[f])<need[f]:
                    record.update({'kind':'closed_count_cover','family':f,'cover':[list(members(g)) for g in groups[f]]});return index
            changed=False
            for mf in range(2):
                if need[mf]==0 or len(groups[mf])!=need[mf]:continue
                step={'mandatory_family':mf,'cover':[list(members(g)) for g in groups[mf]],'removals':[]}
                empty_group=False
                for f in range(2):
                    for value in list(members(available[f])):
                        for gi,g in enumerate(groups[mf]):
                            current=g&available[mf]
                            assert current
                            if current&(1<<value):continue
                            if not current&compatible[value]:
                                step['removals'].append([f,value,gi]);available[f]&=~(1<<value);changed=True
                                empty_group=any(not (g&available[mf]) for g in groups[mf]);break
                        if empty_group:break
                    if empty_group:break
                if step['removals']:record['propagation'].append(step);break
            if not changed:break
        families=[f for f in range(2) if need[f]>0]
        family=min(families,key=lambda f:(len(groups[f])-need[f],min(g.bit_count() for g in groups[f]),f))
        group=min(groups[family],key=lambda g:(g.bit_count(),next(members(g))))
        values=list(members(group));record.update({'kind':'branch_clique','family':family,'clique':values,'children':[]})
        for value in values:
            child_available=[a&compatible[value] for a in available]
            child_chosen=[list(c) for c in chosen];child_chosen[family].append(value)
            if len(child_chosen[family])==8:child_available[family]=0
            record['children'].append({'value':value,'node':visit(child_available,child_chosen,groups)})
        skipped=list(available);skipped[family]&=~group
        record['skip']=visit(skipped,[list(c) for c in chosen],groups)
        return index
    root=visit(root_available,[[],[]],original)
    open_nodes=[r['node'] for r in records if r['kind'] in ['open','open_graph_witness']]
    elapsed=time.perf_counter()-case_started
    result={'source_selection':row,'empty_sites':row['empty_sites'],'original_bracket_node_count':offset,
        'graph_complete':graph_complete,'root':root,'records':records,'expanded_nodes':expanded,
        'open_nodes':open_nodes,'joint_graph_witness':witness,'case_seconds':elapsed,
        'case_complete_cap_overrun_seconds':max(0,elapsed-0.75),'diagnostic_excluded':not open_nodes}
    write(OUT/f'choice-{choice:02d}.json',result)
    summary={k:v for k,v in result.items() if k not in ['source_selection','records','open_nodes','joint_graph_witness']}|{'records':len(records),'open_leaves':len(open_nodes),'has_joint_graph_witness':witness is not None}
    summaries.append(summary);print(summary,flush=True);assert time.perf_counter()-started<55
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':summaries,
    'known_joint_witness_preserved_without_search':known_empty,'independent_tree_audit_pending':True,
    'source_valid66':False,'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
