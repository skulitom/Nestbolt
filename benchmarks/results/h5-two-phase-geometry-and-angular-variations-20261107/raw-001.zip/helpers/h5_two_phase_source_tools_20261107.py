"""Exact source transforms and support witnesses for two original cog phases."""
from fractions import Fraction as F
import math
import numpy as np
import shapely
from shapely.geometry import MultiPoint
from h5_exact_convex_partition_tools_20261029 import hull,area

def affine(points,mode):
    c,s=F(math.cos(mode['rotation_radians'])),F(math.sin(mode['rotation_radians']))
    sign=-1 if mode['mirrored'] else 1
    tx,ty=map(F,mode['translation_from_lower_left'] if 'translation_from_lower_left' in mode else mode['translation'])
    return [(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in points]

def exterior(domain,a,b):
    a,b=tuple(map(F,a)),tuple(map(F,b));x0,y0,x1,y1=map(F,domain)
    poly=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)];out=[]
    cross=lambda p:(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
    for p,q in zip(poly,poly[1:]+poly[:1]):
        cp,cq=cross(p),cross(q)
        if cp<=0:out.append(p)
        if (cp<0<cq) or (cq<0<cp):
            t=cp/(cp-cq);out.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    out=hull(out)
    return [[float(x),float(y)] for x,y in out] if len(out)>=3 and area(out)>0 else None

def nfp(a,b):
    return MultiPoint((np.asarray(a,dtype=float)[:,None,:]-np.asarray(b,dtype=float)[None,:,:]).reshape(-1,2)).convex_hull

def support(region,shape,moving,fixed,obstacle,required=F('.225')):
    line=list(shapely.shortest_line(obstacle,shape).coords)
    if len(line)!=2:return None
    dx,dy=line[1][0]-line[0][0],line[1][1]-line[0][1];length=math.hypot(dx,dy)
    if not length:return None
    normal=[dx/length,dy/length];nx,ny=map(F,normal);norm=nx*nx+ny*ny
    gap=min(x*nx+y*ny for x,y in region)+min(x*nx+y*ny for x,y in moving)-max(x*nx+y*ny for x,y in fixed)
    if gap<=0 or gap*gap<required*required*norm:return None
    return normal,float(gap)/math.sqrt(float(norm))
