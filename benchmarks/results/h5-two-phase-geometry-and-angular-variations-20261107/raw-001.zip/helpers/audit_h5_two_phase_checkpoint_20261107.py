from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-two-phase-checkpoint-20261107';G=ROOT/'output/h5-two-phase-cog-geometry-20261107';B=ROOT/'output/h5-two-phase-union-model-20261107';A=ROOT/'output/h5-original-cog-angular-variations-20261107';M=ROOT/'output/h5-mixed-mode-union-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();geometry=load(G/'audit-v2/checks.json');model=load(B/'audit/checks.json');response=load(B/'response-audit/checks.json');angular=load(A/'audit/checks.json')
assert all(r['passed'] for r in [geometry,model,response,angular]) and response['optimizer_calls']==0 and angular['source_overlap_decreases']==12 and not angular['source_valid66']
best=load(A/'best-local-variation.json');assert best['identity']==['cog',2] and best['angle_degrees']==7.25 and best['pair_failures']==39
lib=load(M/'library.json');state=load(M/'search/result.json');target=best['owner'];assert target==17 and lib['owners'][target]['identity']==best['identity']
families={}
for i,o in enumerate(lib['owners']):
    if i==target:continue
    families.setdefault(o['identity'][0],set()).add(state['final_modes'][i])
assert {k:sorted(v) for k,v in families.items()}=={'bracket':[0,1,5],'insert':[0,1,2],'cog':[0]}
next_step={'next':'Prepare a focused original-source translation repair with cog2 fixed at the source-improving7.25degree pose and all other currently selected legal modes retained. This is a new complete physical mode vector, not a repeat of either closed all7degree vector or the closed7/16degree pipeline.',
    'invalid_source_seed':(A/best['source_file']).relative_to(ROOT).as_posix(),'seed_source_sha256':digest(A/best['source_file']),'seed_source_pair_failures':39,'seed_source_stock_failures':0,'target_original':['cog',2],'target_owner':17,'target_angle_degrees':7.25,
    'source_selection_basis':'The frozen24variation original-source diagnostic evaluated6.75/7.25degrees for every current cog. Twelve variations reduce actual summed pairwise overlap; this selected pose reduces it by33.68170645437931mm2. All candidates remain invalid. This is a physical source measurement, not a derivative certificate or optimizer success.',
    'fresh_geometry_scope':'Source-certify every one of27 interactions involving the newly rotated original. The other27 owners have seven distinct currently selected source poses: bracket modes0/1/5,insert modes0/1/2,cog phase7degrees. Prepare at most seven direct source templates with the rotated target as A and each other pose as B over full signed relative stock domains. Map every affected original pair to its actual ordered owners; reverse an owner tuple when needed and prove that mapping. Do not assume a reflection shortcut. All231 unaffected cog interactions can retain their original certified M arrays and mappings; retain all268 orthogonal component interactions and hard bounds. Derive target stock/core bounds and its exact source affine pose from the original job.',
    'all_source_invariants':'All28 moving originals remain independently translatable; fixed29 and short9 stay preserved. All66 originals,90holes,10026holevertices,original gap,stock guards and material target remain mandatory. Selected modes other than target cog2 remain the current actual source modes. No synthetic replacement shapes or PIH fallback.',
    'required_before_call':['Fresh exact original-source separation certificates for every target interaction and whole target domain','Independent region,owner-pair,stock,pose,array and derivative controls,including explicit changes to original pair[16,17] if the ordered tuple is reversed','Known pinned optimizer controls and complete preparation charge','One newly frozen bounded translation call for this never-optimized physical mode vector,with no restart or reseed; retain four-second source reserve','Full original66-part check after any returned candidate; native/material only after source validity'],
    'complete_direct_candidate_plus_angular_probe_charge_seconds':angular['complete_direct_candidate_plus_probe_seconds'],
    'charge_note':'42.03567809960805s consists of complete M shared35.98353959969245s and complete original-source angular probe6.0521384999156s. All consumed source7degree region/pose data are already in M lineage. Add every new target-region/model preparation and runtime cost. The separately closed7/16degree geometry/model/pipeline is not a runtime input to this focused repair; its complete48.980238900054246s result and all failed-audit/correction evidence remain preserved. If any of its geometry is instead consumed,the additional full consumed preparation must be charged explicitly.',
    'new_target_geometry_prepared':False,'new_target_model_prepared':False,'new_optimizer_calls':0,'any_allocation_excluded':False,'fixed_arrangements_remaining':4,'whole_allocations_remaining':440,'H2_complete':False,'H5_complete':False}
write(OUT/'next-step.json',next_step)
inputs=[Path(__file__),ROOT/'output/h5-two-phase-audit-correction-20261107.json',ROOT/'output/h5-two-phase-search-preparation-20261107.json']+[G/n for n in ['plan.json','checks.json','audit-v2/plan.json','audit-v2/checks.json']]+[B/n for n in ['plan.json','audit/plan.json','audit/checks.json','response-audit/plan.json','response-audit/checks.json','search/process.json']]+[A/n for n in ['plan.json','checks.json','best-local-variation.json','audit/plan.json','audit/checks.json']]
folders=['h5-two-phase-cog-geometry-process-20261107','h5-two-phase-audit-v2-process-20261107','h5-two-phase-boundary-controls-20261107','h5-two-phase-union-model-process-20261107','h5-original-cog-angular-variations-process-20261107']
for name in folders:
    for file in ['opened.json','process.json','plan.json','checks.json']:
        p=ROOT/'output'/name/file
        if p.is_file():inputs.append(p)
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    d=load(p)
    if not isinstance(d,dict):continue
    for name,h in {**d.get('inputs',{}),**d.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert z.is_relative_to(ROOT) and not {'.claude','.cache'}&set(z.parts) and digest(z)==h,name;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings)
ci=json.loads(subprocess.check_output(['gh','run','view','42343100154','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='4ca0d8cd68c3c6fac8c4c995b2b85334c72dc766';write(OUT/'main-ci-at-review.json',ci)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reconcile the complete independently certified7/16degree geometry and direct ordered model, the preserved/corrected corner membership failure, the12eligible phase substitutions that stop before any optimizer call,and the independent24variation original-source diagnostic. Preserve every failed source result and all budgets. Scope a new focused source-certified7.25degree target repair without opening a new call or transferring exclusions.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'source_bindings':len(bindings),'finite_phase_model_options':120,'ordered_geometry_templates':28,'certified_regions':2621,'exact_source_supports':38364,'model_projection_comparisons':5242,'ordered_pair_mode_couplings':2568,'phase_substitutions':12,'phase_pipeline_optimizer_calls':0,'phase_pipeline_shared_seconds':response['shared_seconds_including_preparation'],'angular_source_variations':24,'angular_overlap_decreases':12,'best_angular_identity':['cog',2],'best_angular_degrees':7.25,'best_angular_area_change_mm2':best['change_from_baseline_mm2'],'source_pair_failures':39,'source_stock_failures':0,'source_valid66':False,'new_target_templates_required':7,'new_target_geometry_prepared':False,'next_direct_consumed_charge_seconds':angular['complete_direct_candidate_plus_probe_seconds'],'fixed_arrangements_remaining':4,'whole_allocations_remaining':440,'completion_percent':60,'H2_complete':False,'H5_complete':False,'main_ci_status':ci['status'],'main_ci_conclusion':ci['conclusion']}
write(OUT/'checks.json',checks);print(checks)
