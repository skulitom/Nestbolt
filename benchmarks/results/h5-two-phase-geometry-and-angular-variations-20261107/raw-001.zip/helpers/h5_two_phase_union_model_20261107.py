"""Direct ordered-source template model for two legal cog phases."""
from pathlib import Path
from fractions import Fraction as F
import json
import numpy as np
from h5_cog_physical_union_distance_v2_20261107 import Objective
ROOT=Path(__file__).resolve().parents[1];G=ROOT/'output/h5-two-phase-cog-geometry-20261107';M=ROOT/'output/h5-mixed-mode-union-20261107';BASE=ROOT/'output/h5-two-phase-union-model-20261107'
load=lambda p:json.loads(p.read_bytes())
def pack():
    source=load(M/'library.json');modes=load(G/'family-modes.json');templates=load(G/'templates.json');result=load(M/'search/result.json')
    lib={k:source[k] for k in ['owners','rectangles','components','component_pairs','world_origin_mm','rectangle_gap_grid']}
    lib.update({'family_modes':modes,'pairs':load(G/'owner-pairs.json'),'initial_modes':result['final_modes'],'initial_values_mm':result['final_values_mm'],'groups':[],'couplings':[]})
    arrays={};global_region=0
    for template in templates:
        gi=template['template'];rr=template['regions'];nv=max(len(r['vertices_mm']) for r in rr);starts=np.zeros((len(rr),nv,2));ends=starts.copy();valid=np.zeros((len(rr),nv),dtype=bool);normals=starts.copy();upper=np.full((len(rr),nv),np.inf)
        for ri,r in enumerate(rr):
            v=[tuple(map(F,p)) for p in r['vertices_mm']];n=len(v);starts[ri,:n]=np.array(v,dtype=float);ends[ri,:n]=np.roll(np.array(v,dtype=float),-1,axis=0);valid[ri,:n]=True
            for j,(a,b) in enumerate(zip(v,v[1:]+v[:1])):
                nx,ny=b[1]-a[1],a[0]-b[0];length=np.hypot(float(nx),float(ny));assert length>0
                normals[ri,j]=[float(nx)/length,float(ny)/length];upper[ri,j]=float(nx*a[0]+ny*a[1])/length
        prefix=f'g{gi}_';arrays.update({prefix+'starts':starts,prefix+'ends':ends,prefix+'valid':valid,prefix+'normals':normals,prefix+'upper':upper})
        lib['groups'].append({'group':gi,'class':gi,'a_mode':template['a_mode'],'b_family':template['b_family'],'b_mode':template['b_mode'],'source_region_indices':list(range(global_region,global_region+len(rr))),'source_region_signs':[1]*len(rr),'source_template':gi})
        global_region+=len(rr)
    for p in lib['pairs']:
        for ti in p['templates']:
            t=templates[ti];lib['couplings'].append({'pair':p['pair'],'a_mode':t['a_mode'],'b_mode':t['b_mode'],'template':ti})
    return arrays,lib

def compile_modes(regions,lib,modes,values):
    assert len(modes)==28 and all(isinstance(m,int) for m in modes)
    owners=[]
    for i,(old,mode) in enumerate(zip(lib['owners'],modes)):
        m=lib['family_modes'][old['identity'][0]][mode];assert m['mode']==mode
        owners.append({'owner':i,'identity':old['identity'],'mode':mode,'geometry':m['geometry'],'position_bounds_grid':m['integer_world_lower_left_bounds'],'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation_from_lower_left':m['translation_from_lower_left']})
    a=dict(regions);a['bounds']=np.array([b for o in owners for b in o['position_bounds_grid']],dtype=float)/100;a['initial']=np.clip(values,a['bounds'][:,0],a['bounds'][:,1])
    lookup={(c['pair'],c['a_mode'],c['b_mode']):c['template'] for c in lib['couplings']};selected={g['group']:[] for g in lib['groups']}
    for pair in lib['pairs']:
        oi,oj=pair['owners'];selected[lookup[pair['pair'],modes[oi],modes[oj]]].append(pair)
    groups=[]
    for g in lib['groups']:
        pp=selected[g['group']];prefix=f'g{g["group"]}_';n=len(pp)
        a[prefix+'owners']=np.array([p['owners'] for p in pp],dtype=np.int64).reshape(-1,2);a[prefix+'matrix']=np.tile(np.eye(2),(n,1,1));a[prefix+'offset']=np.zeros((n,2))
        if n:groups.append({**g,'pairs':[p['pair'] for p in pp]})
    axes=[];positive=[];negative=[];uppers=[]
    for pair in lib['component_pairs']:
        ca,cb=[lib['components'][i] for i in pair['components']];oa,ob=[owners[i] for i in pair['owners']]
        ra=lib['rectangles'][oa['identity'][0]][oa['mode']]['rectangles'][ca['piece']]['outward_offsets_grid'];rb=lib['rectangles'][ob['identity'][0]][ob['mode']]['rectangles'][cb['piece']]['outward_offsets_grid'];gap=lib['rectangle_gap_grid'];oi,oj=pair['owners']
        axes.append([0,0,1,1]);positive.append([oi,oj,oi,oj]);negative.append([oj,oi,oj,oi]);uppers.append([rb[0]-ra[2]-gap,ra[0]-rb[2]-gap,rb[1]-ra[3]-gap,ra[1]-rb[3]-gap])
    a['orth_axis']=np.array(axes,dtype=np.int64);a['orth_positive']=np.array(positive,dtype=np.int64);a['orth_negative']=np.array(negative,dtype=np.int64);a['orth_upper']=np.array(uppers,dtype=float)/100
    return a,{'owners':owners,'groups':groups}

def readback(a,meta,regions,lib,modes,values):
    expected_keys=set(regions)|{'bounds','initial','orth_axis','orth_positive','orth_negative','orth_upper'}
    for k,v in regions.items():assert a[k] is v
    assert len(meta['owners'])==28
    for i,owner in enumerate(meta['owners']):
        identity=lib['owners'][i]['identity'];m=lib['family_modes'][identity[0]][modes[i]]
        assert owner=={'owner':i,'identity':identity,'mode':modes[i],'geometry':m['geometry'],'position_bounds_grid':m['integer_world_lower_left_bounds'],'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation_from_lower_left':m['translation_from_lower_left']}
        assert a['bounds'][2*i:2*i+2].tolist()==[[v/100 for v in b] for b in m['integer_world_lower_left_bounds']]
    assert np.array_equal(a['initial'],np.minimum(np.maximum(values,a['bounds'][:,0]),a['bounds'][:,1]))
    expected_groups=[];covered=[]
    for group in lib['groups']:
        gi=group['group'];prefix=f'g{gi}_';pp=[]
        for pair in lib['pairs']:
            oi,oj=pair['owners'];family=lib['owners'][oj]['identity'][0]
            if modes[oi]==group['a_mode'] and family==group['b_family'] and modes[oj]==group['b_mode']:pp.append(pair)
        assert a[prefix+'owners'].shape==(len(pp),2) and a[prefix+'owners'].tolist()==[p['owners'] for p in pp]
        assert np.array_equal(a[prefix+'matrix'],np.broadcast_to(np.eye(2),(len(pp),2,2))) and np.array_equal(a[prefix+'offset'],np.zeros((len(pp),2)))
        expected_keys.update(prefix+k for k in ['owners','matrix','offset'])
        if pp:expected_groups.append({**group,'pairs':[p['pair'] for p in pp]});covered.extend(p['pair'] for p in pp)
    assert expected_groups==meta['groups'] and sorted(covered)==list(range(258))
    for i,pair in enumerate(lib['component_pairs']):
        rr=[]
        for ci in pair['components']:
            c=lib['components'][ci];oi=c['owner'];rr.append(lib['rectangles'][c['identity'][0]][modes[oi]]['rectangles'][c['piece']]['outward_offsets_grid'])
        ra,rb=rr;oi,oj=pair['owners'];gap=lib['rectangle_gap_grid']
        assert a['orth_axis'][i].tolist()==[0,0,1,1] and a['orth_positive'][i].tolist()==[oi,oj,oi,oj] and a['orth_negative'][i].tolist()==[oj,oi,oj,oi]
        assert a['orth_upper'][i].tolist()==[(rb[0]-ra[2]-gap)/100,(ra[0]-rb[2]-gap)/100,(rb[1]-ra[3]-gap)/100,(ra[1]-rb[3]-gap)/100]
    assert all(a[k].shape==(268,4) for k in ['orth_axis','orth_positive','orth_negative','orth_upper']) and set(a)==expected_keys
    return True

def source_rows(lib,modes,values,fixed):
    rows=list(fixed)
    for i,owner in enumerate(lib['owners']):
        m=lib['family_modes'][owner['identity'][0]][modes[i]]
        rows.append({'part_id':owner['identity'][0],'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':[float(values[2*i+k])+lib['world_origin_mm'][k]+m['translation_from_lower_left'][k] for k in [0,1]]}})
    return rows
