from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time,os
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-original-cog-angular-variations-process-20261107';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/shop-venv/Scripts/python.exe';SCRIPT=ROOT/'output/probe_h5_original_cog_angular_variations_20261107.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),SCRIPT,EXE,EXE.parent/'checks.json']},'wall_ms':8000,'memory_bytes':2**31,'retry_permitted':False,'source_optimizer_calls':0})
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
r=subprocess.run([str(EXE),'8000',str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(SCRIPT)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=16,env=env)
(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');record={'closed':True,'complete_seconds':time.perf_counter()-start,'passed':r.returncode==0 and job['reason_code']==job['error_code']==0 and job['closed'] and job['active_processes']==0,'exit_code':r.returncode,'job':job,'repeat_permitted':False}
write(OUT/'process.json',record);print(record)
