"""Preserve two-phase source geometry, closed no-call pipeline and angular source controls."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
replacements={"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-two-phase-geometry-and-angular-variations-20261107'","BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-two-phase-union-model-20261107';F=ROOT/'output/h5-two-phase-checkpoint-20261107';D=ROOT/'output/h5-original-cog-angular-variations-20261107'","PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-mixed-mode-source-repair-20261107'","front['closed_optimizer_calls']==1":"front['phase_pipeline_optimizer_calls']==0","folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,F,D]+[ROOT/'output'/n for n in ['h5-two-phase-cog-geometry-20261107','h5-two-phase-cog-geometry-process-20261107','h5-two-phase-audit-v2-process-20261107','h5-two-phase-boundary-controls-20261107','h5-two-phase-union-model-process-20261107','h5-original-cog-angular-variations-process-20261107']]","['*h5*mixed*mode*20261107.py']":"['*h5*two*phase*20261107.py','*h5*original*cog*angular*20261107.py']","'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_two_phase_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"}
for old,new in replacements.items():assert old in prefix,old;prefix=prefix.replace(old,new)
needle="for name,h in load(F/'source-bindings.json').items():";assert needle in prefix
prefix=prefix.replace(needle,"for n in ['h5-two-phase-audit-correction-20261107.json','h5-two-phase-search-preparation-20261107.json']:add('corrections-and-preflight/'+n,ROOT/'output'/n)\n"+needle)
exec(prefix)
G=ROOT/'output/h5-two-phase-cog-geometry-20261107'
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(G/'audit-v2/checks.json','source-geometry-audit.json'),(G/'audit-v2/exact-source-partition.json','exact-source-partition.json'),(ROOT/'output/h5-two-phase-cog-geometry-process-20261107/process.json','geometry-and-first-audit-process.json'),(ROOT/'output/h5-two-phase-audit-v2-process-20261107/process.json','corrected-audit-process.json'),(ROOT/'output/h5-two-phase-audit-correction-20261107.json','audit-correction.json'),(ROOT/'output/h5-two-phase-boundary-controls-20261107/checks.json','boundary-diagnostic.json'),(BASE/'audit/checks.json','model-audit.json'),(BASE/'audit/ordered-phase-permutation-controls.json','ordered-phase-controls.json'),(BASE/'response-audit/checks.json','closed-pipeline-audit.json'),(BASE/'response-audit/replayed-mode-trials.json','phase-substitutions.json'),(BASE/'search/process.json','closed-pipeline-process.json'),(D/'audit/checks.json','angular-source-audit.json'),(D/'variations.json','angular-variations.json'),(D/'best-local-variation.json','best-invalid-local-variation.json'),(ROOT/'output/h5-original-cog-angular-variations-process-20261107/process.json','angular-process.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Two-phase geometry and original angular variations — 2026-11-07

The independently certified 7°/16° model finds **no improving single-cog phase
change** at the current invalid candidate. Its bounded pipeline closes after
12 eligible evaluations, before any optimizer call. A separate original-source
diagnostic finds smaller 0.25° rotations can reduce overlap, but **every one
of its 24 candidates still fails 39 original pairs**. No full layout or
allocation exclusion follows. H2/H5 remain open at **60% completed milestone
weight**, with four fixed arrangements and 440 whole allocations remaining.

## Fresh original geometry and its controls

[Source readback]({NAME}/source-geometry-audit.json) verifies all **120 finite
owner/mode options**, including cog phases 7° and 16°. Both phases derive from
the original 80-vertex cog and its 200-vertex hole. Their 9° difference is half
the original 20-tooth pitch. [Exact signed boundary cancellation and area]({NAME}/exact-source-partition.json)
prove the original bracket, insert and cog convex-piece partitions.

The construction explicitly represents **28 ordered source interaction types**,
with **2,621 certified convex regions and 38,364 exact rational support proofs**.
The minimum certified source gap is **0.225999998 mm**. Every phase-specific
pose, hard stock/core bound, relative-coordinate domain and original-owner
mapping is checked. All **258 cog interactions and 2,568 mode couplings** remain;
there is no X ordering or unproved symmetry/alias shortcut for mixed phases.

The complete source preparation takes **11.017775 s** and includes geometry,
support selection/proofs, source controls and serialization. Its original
source controls include 56 mode corners and 28 ordered pairs. All preserve the
original cutouts and fixed 29-part core plus valid nine-part small sheet.

## Preserved boundary-control failure and correction

[The first audit fails an exact region-membership control]({NAME}/geometry-and-first-audit-process.json)
after 5.365260 s. Four exact stock-relative corner points lie just outside the
rounded region domain. [The diagnostic]({NAME}/boundary-diagnostic.json) measures
maximum inward rounding of **4.547474 × 10⁻¹⁴ mm**. These corner placements
pass their actual original-source checks, but their exact region-membership
failures remain recorded. No source-region coverage claim is substituted.

[The corrected audit]({NAME}/audit-correction.json) retains every region and
support byte, rechecks all original corner cases, and adds 28 source controls
shifted 0.01 mm inward per owner. All new controls have exact region membership.
[The corrected bounded process]({NAME}/corrected-audit-process.json) takes
**11.980541 s** and closes normally. Its independent reconstruction covers
**112 source cases, 54,432 pairs, 17,696 stock edges, 5,448 holes and 458,592
hole vertices**. No geometry preparation or optimizer is repeated.

## Ordered model and closed phase pipeline

[Model controls]({NAME}/model-audit.json) verify every packed vertex, plane,
padding field, stock bound and pose; all 2,568 ordered couplings; **5,242 exact
rational projection comparisons**; 120 owner/mode reconstructions; 93 dynamic
mode vectors; 168 analytic derivatives; and six deliberate corruption cases.
[Permutation controls]({NAME}/ordered-phase-controls.json) swap both cog poses
and phases, exercising both mixed pair orders. Pinned SciPy 1.17.1 tool
provenance and optimizer controls remain verified. Complete model preparation
and its separate audit take **0.505597 / 4.471970 s**.

The newly frozen pipeline requires at least one 16° cog. Every all-7° vector
is ineligible, so no closed physical mode vector can be optimized again.
It allows at most four new calls of at most four seconds, within the original
preparation-inclusive 60/90-second and 2 GiB caps with a four-second source
reserve. Each call also requires a strict improving, previously unoptimized
mode vector after complete dynamic readback.

[Independent response replay]({NAME}/closed-pipeline-audit.json) checks all
[12 eligible phase substitutions]({NAME}/phase-substitutions.json), with 80
all-first-phase alternatives skipped as declared. Every eligible move increases
the new model objective, by **204.065951 to 974.501086 mm²**, from the reference
value **16,515.048706 mm²**. The pipeline stops before selecting any vector or
opening an optimizer, source-candidate or native call. Its initial candidate
remains unchanged and invalid. This local result proves no packing exclusion.

Charged preparation is **47.836676 s**; algorithm/shared totals are
**48.885302 / 48.980239 s**, with no overrun. [All five processes close]({NAME}/closed-pipeline-process.json),
with **65,957,888 bytes** peak committed memory. The entire pipeline stays
closed; no extension, changed seed or restart is permitted.

## Smaller original-source angular variations

A separate diagnostic starts from the earlier invalid mixed-mode candidate
and uses the original source polygons directly. It freezes angles **6.75° and
7.25° for each of twelve cogs**, changing one original at a time. Every other
pose stays identical. The changed cog receives freshly derived inward stock
bounds and only the necessary lower-left clamp. The 7°/16° geometry and search
state are not runtime inputs to this diagnostic.

[Independent source replay]({NAME}/angular-source-audit.json) reconstructs all
[24 variations]({NAME}/angular-variations.json), checking **40,800 original
pairs, 6,600 stock edges, 2,250 holes and 250,650 hole vertices**, including the
baseline. Twelve variations reduce summed pairwise overlap. The frozen ranking
selects [original cog 2 at 7.25°]({NAME}/best-invalid-local-variation.json),
which reduces that sum by **33.681706 mm²**, from **41,111.290981 mm²**.
This sum can double-count overlap and is not a union-area or validity measure.
All 24 candidates retain **39 failing pairs and zero stock failures**.

[The complete bounded probe]({NAME}/angular-process.json) takes **6.052138 s**,
including startup and serialization; the separate source replay takes
3.706794 s internally. There is no optimizer call, allocation exclusion or
valid layout. The measured local improvement is useful source evidence only.

## Next focused source repair

[The next specification]({NAME}/next-step.json) holds cog 2 at its selected
7.25° pose and retains the other currently selected legal modes. All 28 original
translations remain free. Every one of the rotated cog's **27 interactions**
needs a new exact source certificate. The other originals have seven distinct
selected poses, so **seven new direct source templates** suffice in principle.
Every affected ordered-owner mapping must be read back explicitly; the 231
unaffected cog interactions and 268 orthogonal component interactions remain.

This geometry and model are **not built or run**. If the direct original
candidate and angular diagnostic are consumed, their complete charge is
**42.035678 s** before fresh preparation. The separate closed 7°/16° pipeline
remains reported in full; any reuse of its geometry must add its consumed cost.
One fresh, bounded translation call can be considered only after complete
source/model controls. Every returned candidate needs all-66 source validation
before native/material checks. Production integration, UI/CLI/MCP parity and
the unchanged full H5 matrix remain required. H2 retains its original gate
and unopened reserved vectors. No release qualifies.

Local checkpoint **0ffe29b1** is committed; [main CI at review]({NAME}/main-ci-at-review.json)
still checks **4ca0d8cd**. Queued evidence waits for all six jobs and aggregate
success before an ordinary push. No live run is cancelled.

[Raw evidence]({NAME}/raw-manifest.json) contains {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes. [Historical
references]({NAME}/external-evidence.json) and [source bindings]({NAME}/source-bindings.json)
preserve all consumed inputs and failed/corrected audits. Independent archive
readback is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 two-phase geometry and angular source variations:** [independent source/model/response audits]({link}) verify 120 finite modes, 28 ordered templates, 2,621 safe regions, 38,364 exact supports and 5,242 projection comparisons. The corrected source audit preserves four tiny rounded-domain corner membership failures and passes 112 original-source controls. All twelve eligible 16-degree substitutions increase the objective, so the bounded phase pipeline stops before any optimizer call; preparation-inclusive algorithm/shared totals are 48.885302/48.980239 s. A separate frozen 24-variation source diagnostic finds twelve smaller rotations reduce overlap. Cog 2 at 7.25 degrees gives the largest measured decrease, 33.681706 mm², but every candidate still fails 39 pairs and passes all stock edges. Its complete process takes 6.052138 s; independent replay checks 40,800 pairs. The next unprepared focused repair needs fresh certificates for all 27 interactions of that rotated cog, using seven source templates in principle, and starts with 42.035678 s of direct candidate/probe cost. All closed pipelines remain closed. Four fixed arrangements and 440 allocations remain; H2/H5 stay at 60%. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
path=ROOT/'docs/STATUS.md';text=path.read_text(encoding='utf-8');begin=text.index('Latest H5 evidence:');end=text.index('\nThe earlier fixed 13-cog construction',begin)
intro=f'''Latest H5 evidence: [two-phase geometry and angular source variations](../benchmarks/results/{NAME}.md).
Fresh 7°/16° geometry and all 2,568 ordered mode couplings pass independent
source/model controls. Every eligible single-cog 16° change increases the
objective, so its bounded pipeline closes before opening an optimizer call.
The initial candidate remains invalid. A separate original-source probe checks
24 smaller rotations; twelve reduce measured overlap, but all retain 39 failing
pairs and pass stock checks. The best turns cog 2 to 7.25°, reducing summed
pairwise overlap by 33.681706 mm². This is source evidence, not a valid layout.
A focused translation repair now needs exact certificates for that cog's
27 interactions and a new audited model. Neither is prepared. The direct
candidate-plus-probe lineage costs 42.035678 s before new preparation.
Four fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%.
Full source/native/material validation, production parity and the unchanged
H5 matrix remain required. Main 4ca0d8cd CI is retained; checkpoint 0ffe29b1
and this evidence await the ordinary push gate. No release qualifies.
'''
path.write_text(text[:begin]+intro+text[end:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
