from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,time
from h5_exact_convex_partition_tools_20261029 import cross
from shapely.geometry import Polygon,Point
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-two-phase-cog-geometry-20261107';OUT=ROOT/'output/h5-two-phase-boundary-controls-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();records=[]
for t in load(BASE/'templates.json'):
    xy=t['positive_pair_position_grid'];corner=[F(xy[1][k]-xy[0][k],100) for k in [0,1]];inside=[v-F(2,100) for v in corner]
    vertices=[[tuple(map(F,p)) for p in r['vertices_mm']] for r in t['regions']]
    containing=lambda point:[i for i,v in enumerate(vertices) if all(cross(a,b,point)>=0 for a,b in zip(v,v[1:]+v[:1]))]
    old=containing(corner);new=containing(inside);assert new
    union=unary_union([Polygon([(float(x),float(y)) for x,y in v]) for v in vertices])
    max_x=max(x for v in vertices for x,y in v);max_y=max(y for v in vertices for x,y in v)
    records.append({'template':t['template'],'corner_relative_mm':[str(x) for x in corner],'corner_containing_regions':old,'interior_relative_mm':[str(x) for x in inside],'interior_containing_regions':new,'positive_x_domain_rounding_inward_mm':str(max(F(0),corner[0]-max_x)),'positive_y_domain_rounding_inward_mm':str(max(F(0),corner[1]-max_y)),'binary64_point_to_region_union_distance_mm':union.distance(Point(*map(float,corner)))})
write(OUT/'controls.json',records)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),BASE/'templates.json',ROOT/'output/h5-two-phase-cog-geometry-process-20261107/audit-stderr.txt',ROOT/'output/audit_h5_two_phase_cog_geometry_20261107.py']},'method':'Diagnostic exact membership at the declared corner and at a deterministic0.02mm-inward relative point. Do not change any source region or rerun preparation. Compare rounded region domain extrema with exact rational stock-relative bounds; independent source-safe positive controls remain required.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'ordered_templates':28,'exact_corner_membership_failures':sum(not r['corner_containing_regions'] for r in records),'interior_memberships':sum(bool(r['interior_containing_regions']) for r in records),'maximum_inward_domain_rounding_mm':max(float(F(r[k])) for r in records for k in ['positive_x_domain_rounding_inward_mm','positive_y_domain_rounding_inward_mm']),'regions_changed':False,'optimizer_calls':0})
print(load(OUT/'checks.json'))
