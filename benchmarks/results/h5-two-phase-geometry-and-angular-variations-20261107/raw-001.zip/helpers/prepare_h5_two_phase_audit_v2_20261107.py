from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/audit_h5_two_phase_cog_geometry_20261107.py';NEW=ROOT/'output/audit_h5_two_phase_cog_geometry_v2_20261107.py';BASE=ROOT/'output/h5-two-phase-cog-geometry-20261107'
digest=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_bytes())
text=OLD.read_text(encoding='utf-8').replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'")
needle="    assert any(all(cross(a,b,delta)>=0 for a,b in zip(v,v[1:]+v[:1])) for r in t['regions'] for v in [[tuple(map(F,p)) for p in r['vertices_mm']]])"
assert text.count(needle)==1
replacement="""    def memberships(point):
        return [ri for ri,r in enumerate(t['regions']) for vertices in [[tuple(map(F,p)) for p in r['vertices_mm']]] if all(cross(a,b,point)>=0 for a,b in zip(vertices,vertices[1:]+vertices[:1]))]
    diagnostic=load(ROOT/'output/h5-two-phase-boundary-controls-20261107/controls.json')[ti]
    assert diagnostic['template']==ti and memberships(delta)==diagnostic['corner_containing_regions']
    inside_positions=[[p+1 for p in positions[0]],[p-1 for p in positions[1]]]
    inside_delta=[F(inside_positions[1][k]-inside_positions[0][k],100) for k in [0,1]]
    assert [str(v) for v in inside_delta]==diagnostic['interior_relative_mm'] and memberships(inside_delta)==diagnostic['interior_containing_regions'] and memberships(inside_delta)
    inner_rows=fixed+[]
    for identity,m,xy in zip(expected_ids,[ma,mb],inside_positions):
        assert all(lo<=xy[k]<=hi for k,(lo,hi) in enumerate(m['individual_grid_bounds']))
        inner_rows.append({'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':[xy[k]/100+m['translation_from_lower_left'][k] for k in [0,1]]}})
    inner_rows+=short
    from h5_legacy64_source_readback import audit as original_source_reader
    inner_checks=original_source_reader(job,inner_rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in inner_rows])
    check_source(inner_rows,inner_checks)
    write(OUT/f'pair-{ti:02d}-interior-source.json',inner_rows);write(OUT/f'pair-{ti:02d}-interior-checks.json',inner_checks)
""".rstrip()
text=text.replace(needle,replacement)
needle2='queue=inputs.copy();seen=set();bindings={}'
assert needle2 in text
text=text.replace(needle2,"inputs += [ROOT/'output/audit_h5_two_phase_cog_geometry_20261107.py',ROOT/'output/h5-two-phase-cog-geometry-process-20261107/audit-stderr.txt',ROOT/'output/h5-two-phase-boundary-controls-20261107/plan.json',ROOT/'output/h5-two-phase-boundary-controls-20261107/controls.json',ROOT/'output/h5-two-phase-boundary-controls-20261107/checks.json',ROOT/'output/h5-two-phase-audit-correction-20261107.json']+list(OUT.glob('*.json'))\n"+needle2)
text=text.replace("'ordered_pair_positive_controls':pair_controls,**counts","'ordered_pair_positive_controls':pair_controls,'interior_exact_membership_controls':28,'preserved_original_corner_membership_failures':4,**counts")
text=text.replace("including all four ordered cog-phase combinations. No approximate symmetry/alias reuse", "including all four ordered cog-phase combinations. Preserve and replay all four exact stock-corner membership failures caused by at most4.55e-14mm inward domain rounding. Independently check28 new original-pair controls shifted0.01mm inward per owner and prove exact membership0.02mm inside the relative domain. No source region or source gap is changed. No approximate symmetry/alias reuse")
with NEW.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
correction={'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),OLD,NEW,ROOT/'output/h5-two-phase-cog-geometry-process-20261107/audit.json',ROOT/'output/h5-two-phase-cog-geometry-process-20261107/audit-stderr.txt',ROOT/'output/h5-two-phase-boundary-controls-20261107/plan.json',ROOT/'output/h5-two-phase-boundary-controls-20261107/checks.json']},'reason':'The first auditor required exact membership at an exact stock-domain corner. Binary64 region-vertex rounding shrinks four domain corners inward by at most4.5474735088646414e-14mm. Those original positive source controls remain valid, and their failed exact memberships remain preserved. The corrected auditor still rechecks every original control and every exact support; it also checks28 fresh controls0.01mm inward per owner, with exact safe-region membership. This changes only the verification control location, not the geometry, source bounds, source safety threshold or proof obligations. No optimizer call ran and no geometry preparation is repeated.','regions_sha256_unchanged':digest(BASE/'templates.json'),'source_supports_sha256_unchanged':digest(BASE/'source-supports.json'),'changed_algorithm_data':False,'new_source_optimizer_calls':0}
with (ROOT/'output/h5-two-phase-audit-correction-20261107.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(correction,f,indent=2);f.write('\n')
print({'new_audit':NEW.name,'geometry_unchanged':True})
