from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
from h5_two_phase_union_model_20261107 import ROOT,BASE,G,M,load,compile_modes,readback,Objective
from h5_cog_union_distance_20261107 import nearest_regions
OUT=BASE/'audit';digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');assert load(G/'audit-v2/checks.json')['passed']
lib=load(BASE/'library.json');npz=np.load(BASE/'regions.npz',allow_pickle=False);arrays={k:npz[k] for k in npz.files}
for a in arrays.values():a.flags.writeable=False
prior=load(M/'library.json')
for k in ['owners','rectangles','components','component_pairs','world_origin_mm','rectangle_gap_grid']:assert lib[k]==prior[k]
assert lib['family_modes']==load(G/'family-modes.json') and lib['pairs']==load(G/'owner-pairs.json')
assert lib['initial_modes']==load(M/'search/result.json')['final_modes'] and lib['initial_values_mm']==load(M/'search/result.json')['final_values_mm']
templates=load(G/'templates.json');expected_couplings=[];offset=0;keys=set();projections=0;vertices_checked=0;maximum_projection_error=0.
def exact_projection(point,v):
    if all((b[0]-a[0])*(point[1]-a[1])-(b[1]-a[1])*(point[0]-a[0])>=0 for a,b in zip(v,v[1:]+v[:1])):return point,F(0)
    options=[]
    for a,b in zip(v,v[1:]+v[:1]):
        edge=[b[k]-a[k] for k in [0,1]];den=sum(x*x for x in edge);t=max(F(0),min(F(1),sum((point[k]-a[k])*edge[k] for k in [0,1])/den));q=tuple(a[k]+t*edge[k] for k in [0,1]);options.append((sum((point[k]-q[k])**2 for k in [0,1]),q))
    distance,q=min(options);return q,distance
for ti,t in enumerate(templates):
    rr=t['regions'];g={'group':ti,'class':ti,'a_mode':t['a_mode'],'b_family':t['b_family'],'b_mode':t['b_mode'],'source_region_indices':list(range(offset,offset+len(rr))),'source_region_signs':[1]*len(rr),'source_template':ti};assert lib['groups'][ti]==g;offset+=len(rr);prefix=f'g{ti}_';keys.update(prefix+k for k in ['starts','ends','valid','normals','upper'])
    points=[(F(0),F(0)),(F(23333,100),F(-18425,100))]
    q,d=nearest_regions(np.asarray(points,dtype=float),*[arrays[prefix+k] for k in ['starts','ends','valid','normals','upper']])
    for ri,r in enumerate(rr):
        v=[tuple(map(F,p)) for p in r['vertices_mm']];n=len(v);vertices_checked+=n;expected=np.array(v,dtype=float)
        assert np.array_equal(arrays[prefix+'starts'][ri,:n],expected) and np.array_equal(arrays[prefix+'ends'][ri,:n],expected[list(range(1,n))+[0]])
        assert arrays[prefix+'valid'][ri].tolist()==[True]*n+[False]*(arrays[prefix+'valid'].shape[1]-n)
        assert np.all(arrays[prefix+'starts'][ri,n:]==0) and np.all(arrays[prefix+'ends'][ri,n:]==0)
        for j,(a,b) in enumerate(zip(v,v[1:]+v[:1])):
            nx,ny=b[1]-a[1],a[0]-b[0];length=np.hypot(float(nx),float(ny))
            assert arrays[prefix+'normals'][ri,j].tolist()==[float(nx)/length,float(ny)/length] and arrays[prefix+'upper'][ri,j]==float(nx*a[0]+ny*a[1])/length
        assert np.all(arrays[prefix+'normals'][ri,n:]==0) and np.all(np.isposinf(arrays[prefix+'upper'][ri,n:]))
        for pi,point in enumerate(points):
            expected,distance=exact_projection(point,v);error=float(np.max(np.abs(q[pi,ri]-np.array(expected,dtype=float))));assert error<1e-8 and abs(d[pi,ri]-float(distance))<1e-7+1e-12*float(distance);maximum_projection_error=max(maximum_projection_error,error);projections+=1
assert set(arrays)==keys and offset==2621 and projections==5242
for pair in lib['pairs']:
    oi,oj=pair['owners'];family=lib['owners'][oj]['identity'][0]
    expected=set()
    for am in lib['family_modes']['cog']:
        for bm in lib['family_modes'][family]:
            matching=[t for t in templates if t['a_geometry']==am['geometry'] and t['b_geometry']==bm['geometry']];assert len(matching)==1;expected.add((am['mode'],bm['mode'],matching[0]['template']))
    actual=[c for c in lib['couplings'] if c['pair']==pair['pair']]
    assert len(actual)==len(expected) and {(c['a_mode'],c['b_mode'],c['template']) for c in actual}==expected
    for ti in pair['templates']:
        t=templates[ti];expected_couplings.append({'pair':pair['pair'],'a_mode':t['a_mode'],'b_mode':t['b_mode'],'template':ti})
assert lib['couplings']==expected_couplings and len(expected_couplings)==2568
initial=lib['initial_modes'];x=np.array(lib['initial_values_mm']);aa,meta=compile_modes(arrays,lib,initial,x);assert readback(aa,meta,arrays,lib,initial,x);initial_value,initial_gradient=Objective(aa,meta).evaluate(aa['initial']);vectors=1;owner_modes=0
for oi,owner in enumerate(lib['owners']):
    for m in lib['family_modes'][owner['identity'][0]]:
        modes=initial.copy();modes[oi]=m['mode'];a,mm=compile_modes(arrays,lib,modes,x);assert readback(a,mm,arrays,lib,modes,x);owner_modes+=1
        if modes!=initial:vectors+=1
assert owner_modes==120 and vectors==93
derivatives=[];symmetry=[]
for phase in range(3):
    modes=initial.copy()
    if phase==1:modes[16:]=[i%2 for i in range(12)]
    if phase==2:modes[16:]=[1]*12
    a,mm=compile_modes(arrays,lib,modes,x);point=a['initial']+.037*np.sin(np.arange(56)*2**.5+.2+phase);obj=Objective(a,mm);value,g=obj.evaluate(point);errors=[];h=1e-4
    for i in range(56):
        plus=point.copy();minus=point.copy();plus[i]+=h;minus[i]-=h;observed=(obj.evaluate(plus)[0]-obj.evaluate(minus)[0])/(2*h);error=abs(observed-g[i]);assert error<.003+1e-6*abs(g[i]),(phase,i,observed,g[i]);errors.append(error)
    assert np.max(np.abs(g.reshape(28,2).sum(axis=0)))<1e-8 and obj.evaluate(point-1e-7*g)[0]<value
    swap_modes=modes.copy();swap_modes[16:]=swap_modes[16:][::-1];swapped=point.reshape(28,2).copy();swapped[16:]=swapped[16:][::-1];a2,m2=compile_modes(arrays,lib,swap_modes,swapped.reshape(-1));value2,g2=Objective(a2,m2).evaluate(swapped.reshape(-1));expected=g.reshape(28,2).copy();expected[16:]=expected[16:][::-1]
    value_error=abs(value2-value);gradient_error=float(np.max(np.abs(g2.reshape(28,2)-expected)));assert value_error<1e-4 and gradient_error<1e-5,(phase,value_error,gradient_error)
    derivatives.append({'phase':phase,'modes':modes,'coordinates':56,'maximum_error':max(errors),'energy_mm2':value});symmetry.append({'phase':phase,'swapped_cog_coordinates_and_modes':True,'value_error_mm2':value_error,'maximum_gradient_error':gradient_error})
write(OUT/'derivative-controls.json',derivatives);write(OUT/'ordered-phase-permutation-controls.json',symmetry)
corruptions=[]
for kind in ['stock','pose','pair_order','pair_phase','pair_offset','rectangle']:
    a,mm=compile_modes(arrays,lib,initial,x)
    if kind=='stock':a['bounds'][0,0]+=1
    elif kind=='pose':mm['owners'][16]['rotation_radians']+=.01
    elif kind=='pair_order':a['g0_owners'][0]=a['g0_owners'][0][::-1]
    elif kind=='pair_phase':mm['groups'][0]['a_mode']=1
    elif kind=='pair_offset':a['g0_offset'][0,0]+=1
    else:a['orth_upper'][0,0]+=1
    caught=False
    try:readback(a,mm,arrays,lib,initial,x)
    except AssertionError:caught=True
    assert caught,kind;corruptions.append({'corruption':kind,'rejected':True})
write(OUT/'negative-controls.json',corruptions)
controls=load(M/'audit/optimizer-controls.json');provenance=load(M/'audit/tool-provenance.json');assert controls['passed']
for name,record in provenance['tool_files'].items():assert digest(ROOT/name)==record['sha256']
write(OUT/'optimizer-controls.json',controls);write(OUT/'tool-provenance.json',provenance)
inputs=[Path(__file__),ROOT/'output/h5_two_phase_union_model_20261107.py',ROOT/'output/h5_cog_physical_union_distance_v2_20261107.py',ROOT/'output/h5_cog_union_distance_20261107.py']+[BASE/n for n in ['plan.json','regions.npz','library.json','checks.json']]+[G/n for n in ['family-modes.json','templates.json','owner-pairs.json','audit-v2/plan.json','audit-v2/checks.json']]+[M/n for n in ['library.json','search/result.json','audit/optimizer-controls.json','audit/tool-provenance.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read every packed vertex, edge normal, padding and source-template identifier; verify5242 exact rational projections, all2568 ordered pair-mode couplings,120owner/mode reconstructions and93dynamic vectors. Check168 analytic derivatives and simultaneous cog-pose/mode permutations, including both mixed ordered phases. Reject six deliberate corruptions. Reuse pinned audited SciPy controls and verify tool bytes. No source optimizer call; the all7degree initial reference cannot be optimized again.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_regions':2621,'vertices_checked':vertices_checked,'exact_projection_comparisons':projections,'maximum_projection_error_mm':maximum_projection_error,'ordered_pair_mode_couplings':2568,'owner_modes':120,'dynamic_vectors':vectors,'analytic_derivatives':168,'negative_controls':6,'initial_reference_objective_mm2':initial_value,'regions_sha256':digest(BASE/'regions.npz'),'library_sha256':digest(BASE/'library.json'),'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False})
print(load(OUT/'checks.json'))
