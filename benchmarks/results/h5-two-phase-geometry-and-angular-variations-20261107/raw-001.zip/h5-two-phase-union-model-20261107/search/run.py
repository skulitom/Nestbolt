"""One frozen mode-descent pipeline, never repeating a complete mode vector."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time,sys,os,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-two-phase-union-model-20261107';OUT=BASE/'search'
PY=ROOT/'.cache/shop-venv/Scripts/python.exe';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')

def child(started):
    import numpy as np,scipy
    from scipy.optimize import minimize
    from h5_two_phase_union_model_20261107 import compile_modes,readback as readback_compilation,Objective,source_rows
    from h5_legacy64_source_readback import audit
    assert scipy.__version__=='1.17.1'
    plan=load(OUT/'plan.json');checked=load(BASE/'audit/checks.json');assert checked['passed']
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
    for name,r in load(BASE/'audit/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==r['sha256'],name
    assert digest(BASE/'regions.npz')==checked['regions_sha256'] and digest(BASE/'library.json')==checked['library_sha256']
    archive=np.load(BASE/'regions.npz',allow_pickle=False);regions={k:archive[k] for k in archive.files}
    for a in regions.values():a.flags.writeable=False
    library=load(BASE/'library.json');modes=library['initial_modes'];values=np.array(library['initial_values_mm']);visited={tuple(modes)}
    options=load(BASE/'audit/optimizer-controls.json')['options'];first=ROOT/'output/h5-first57-direct-short9-20261104'
    spec=load(first/'plan.json');fixed=load(first/'fixed29.json')+load(first/'short9-source.json')
    job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');identities=list(map(tuple,load(ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json')['full66_identities']))
    summaries=[];calls=0;trials_total=0;stop='MAXIMUM_CHANGED_MODE_CALLS';valid=False
    for round_index in range(plan['maximum_changed_mode_calls']):
        if time.perf_counter()-started>=56:stop='ALGORITHM_TIME_STOP_BEFORE_MODE_ENUMERATION';break
        folder=OUT/f'round-{round_index:02d}';folder.mkdir();(folder/'incumbents').mkdir()
        arrays,meta=compile_modes(regions,library,modes,values);assert readback_compilation(arrays,meta,regions,library,modes,values)
        current_value,current_gradient=Objective(arrays,meta).evaluate(values)
        write(folder/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'modes':modes,'values_mm':values.tolist(),'objective_mm2':current_value,'previously_optimized_or_initial_modes':[list(v) for v in sorted(visited)],'algorithm_seconds_including_preparation':time.perf_counter()-started})
        trials=[];skipped=[];best=None;enumeration_complete=True
        for owner in library['owners']:
            oi=owner['owner']
            for alternative in library['family_modes'][owner['identity'][0]]:
                new_mode=alternative['mode']
                if new_mode==modes[oi]:continue
                candidate=modes.copy();candidate[oi]=new_mode
                if not any(candidate[16:]):skipped.append({'owner':oi,'mode':new_mode,'reason':'at_least_one_second_cog_phase_required'});continue
                if tuple(candidate) in visited:skipped.append({'owner':oi,'mode':new_mode,'reason':'complete_mode_vector_already_optimized_or_initial'});continue
                if time.perf_counter()-started>=56:enumeration_complete=False;break
                aa,mm=compile_modes(regions,library,candidate,values)
                assert readback_compilation(aa,mm,regions,library,candidate,values)
                value,gradient=Objective(aa,mm).evaluate(aa['initial']);trials_total+=1
                changed=[i for i in range(56) if aa['initial'][i]!=values[i]]
                assert all(i//2==oi for i in changed)
                trial={'sequence':len(trials),'owner':oi,'identity':owner['identity'],'mode':new_mode,'modes':candidate,'objective_mm2':value,'decrease_mm2':current_value-value,'clamped_coordinates':{str(i):float(aa['initial'][i]) for i in changed},'dynamic_readback_passed':True}
                trials.append(trial)
                key=(value,owner['identity'][0],owner['identity'][1],new_mode)
                if current_value-value>1e-6 and (best is None or key<best[0]):best=(key,trial,aa,mm,gradient)
            if not enumeration_complete:break
        write(folder/'mode-trials.json',{'complete':enumeration_complete,'evaluated':trials,'skipped':skipped,'strict_improvement_threshold_mm2':1e-6})
        if not enumeration_complete:stop='ALGORITHM_TIME_STOP_DURING_MODE_ENUMERATION';break
        if best is None:stop='NO_IMPROVING_UNVISITED_MODE_VECTOR';break
        _,selected,aa,mm,gg=best
        assert tuple(selected['modes']) not in visited and selected['modes']!=modes and selected['decrease_mm2']>1e-6
        assert readback_compilation(aa,mm,regions,library,selected['modes'],values)
        write(folder/'selected-mode.json',selected);np.savez_compressed(folder/'selected-arrays.npz',**aa);write(folder/'selected-mapping.json',mm)
        # Read the serialized model back before opening its sole optimizer call.
        read=np.load(folder/'selected-arrays.npz',allow_pickle=False)
        assert set(read.files)==set(aa) and all(np.array_equal(read[k],aa[k]) for k in aa)
        assert load(folder/'selected-mapping.json')==mm
        remaining=min(4.,56-(time.perf_counter()-started))
        if remaining<=0:stop='ALGORITHM_TIME_STOP_BEFORE_CHANGED_MODE_CALL';break
        objective=Objective(aa,mm);deadline=time.perf_counter()+remaining
        state={'evaluations':0,'best':selected['objective_mm2'],'values':aa['initial'].copy(),'gradient':gg.copy(),'incumbents':1}
        write(folder/'incumbents/00000.json',{'sequence':0,'evaluation':0,'objective_mm2':state['best'],'values_mm':state['values'].tolist(),'gradient':state['gradient'].tolist(),'algorithm_seconds_including_preparation':time.perf_counter()-started})
        class Deadline(Exception):pass
        def function(x):
            if time.perf_counter()>=deadline:raise Deadline()
            value,gradient=objective.evaluate(x);state['evaluations']+=1
            if value<state['best']:
                state['best']=value;state['values']=x.copy();state['gradient']=gradient.copy()
                write(folder/'incumbents'/f'{state["incumbents"]:05d}.json',{'sequence':state['incumbents'],'evaluation':state['evaluations'],'objective_mm2':value,'values_mm':x.tolist(),'gradient':gradient.tolist(),'algorithm_seconds_including_preparation':time.perf_counter()-started});state['incumbents']+=1
            return value,gradient
        def callback(x):
            if state['best']<=1e-16:raise StopIteration()
        write(folder/'optimizer-opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'method':'L-BFGS-B','options':options,'analytic_jacobian':True,'allocated_seconds':remaining,'modes':selected['modes'],'never_previously_optimized':True,'maximum_calls_for_this_vector':1,'retry_permitted':False,'array_sha256':digest(folder/'selected-arrays.npz'),'algorithm_seconds_including_preparation':time.perf_counter()-started})
        visited.add(tuple(selected['modes']));calls+=1;before=time.perf_counter();numerical=None
        try:
            result=minimize(function,aa['initial'].copy(),jac=True,bounds=aa['bounds'],method='L-BFGS-B',callback=callback,options=options)
            status='RETURNED';numerical={'success':bool(result.success),'status':int(result.status),'message':str(result.message),'iterations':int(result.nit),'function_evaluations':int(result.nfev),'gradient_evaluations':int(result.njev),'objective_mm2':float(result.fun),'values_mm':result.x.tolist(),'gradient':result.jac.tolist()}
        except Deadline:status='TIME_STOP'
        elapsed=time.perf_counter()-before;values=state['values'];modes=selected['modes'];energy,g=objective.evaluate(values)
        assert energy==state['best'] and np.array_equal(g,state['gradient']) and np.all(values>=aa['bounds'][:,0]) and np.all(values<=aa['bounds'][:,1])
        write(folder/'response.json',{'closed':True,'optimizer_calls':1,'status':status,'numerical_result':numerical,'allocated_seconds':remaining,'returned_seconds':elapsed,'slice_overrun_seconds':max(0.,elapsed-remaining),'evaluations':state['evaluations'],'incumbents':state['incumbents'],'best_objective_mm2':energy,'best_values_mm':values.tolist(),'best_gradient':g.tolist(),'modes':modes,'algorithm_seconds_including_preparation':time.perf_counter()-started})
        rows=source_rows(library,modes,values,fixed);write(folder/'candidate-source66.json',rows)
        before=time.perf_counter();source=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],identities);source_seconds=time.perf_counter()-before
        assert source['originals']==66 and source['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026
        write(folder/'original-source-checks.json',source);valid=source['valid']
        summary={'round':round_index,'changed_owner':selected['owner'],'changed_mode':selected['mode'],'mode_trials':len(trials),'optimizer_status':status,'objective_before_mode_change_mm2':current_value,'objective_after_mode_change_mm2':selected['objective_mm2'],'objective_after_optimization_mm2':energy,'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'source_valid66':valid,'source_checker_seconds':source_seconds,'algorithm_seconds_including_preparation':time.perf_counter()-started}
        write(folder/'result.json',summary);summaries.append(summary);print(summary,flush=True)
        if valid:stop='SOURCE_VALID_CANDIDATE';break
        if status=='TIME_STOP' or time.perf_counter()-started>=56:stop='ALGORITHM_TIME_STOP_AFTER_SOURCE_CHECK';break
    elapsed=time.perf_counter()-started
    write(OUT/'result.json',{'closed':True,'status':stop,'optimizer_calls':calls,'source_checker_calls':len(summaries),'mode_trials':trials_total,'rounds':summaries,'final_modes':modes,'final_values_mm':values.tolist(),'source_valid66':valid,'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'native_calls':0,'any_allocation_excluded':False,'H5_complete':False,'retry_permitted':False})
    print(load(OUT/'result.json'))

def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py')
    charges={**load(BASE/'source-preparation-charges.json'),'complete_new_two_phase_model_preparation':load(ROOT/'output/h5-two-phase-union-model-process-20261107/prepare.json')['complete_seconds']}
    charge=sum(charges.values());started=time.perf_counter()-charge;write(OUT/'preparation-charges.json',charges)
    first=ROOT/'output/h5-first57-direct-short9-20261104'
    files=[Path(__file__),ROOT/'output/h5_two_phase_union_model_20261107.py',ROOT/'output/h5_cog_union_distance_20261107.py',ROOT/'output/h5_cog_physical_union_distance_v2_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5-two-phase-union-model-process-20261107/prepare.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5-independent-twelve-cog-integer-20261107/inventory.json']+[BASE/n for n in ['plan.json','source-preparation-charges.json','library.json','regions.npz','audit/plan.json','audit/checks.json','audit/optimizer-controls.json','audit/tool-provenance.json']]+[first/n for n in ['plan.json','fixed29.json','short9-source.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'preparation_seconds_charged':charge,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'maximum_changed_mode_calls':4,'maximum_one_call_seconds':4,'at_least_one_second_phase_required':True,'restarts':0,'retry_permitted':False,'blas_threads':1,'strict_mode_improvement_mm2':1e-6,'visited_definition':'Initial closed mode vector and every vector for which a continuous call is opened. In addition, every all7degree cog vector is excluded from the new phase family. Unselected scored alternatives may be evaluated at subsequent changed coordinates but can never repeat an optimized vector.','tie_order':['objective_mm2','part_id','copy_index','mode'],'method':'One new source-phase-coupled pipeline using freshly certified ordered7/16degree geometry. Every candidate must contain at least one16degree cog; all closed all7degree vectors are excluded. Fully score and independently read back every eligible unvisited single-owner substitution before choosing the deterministic best strict improvement. Clamp only the changed original to its phase/mode stock bounds. Serialize and read back the entire selected model, then at most one L-BFGS-B call per new complete vector, maximum4seconds each and4calls total, also limited by preparation-inclusive60seconds with4seconds source reserve. Check all66 originals after every returned candidate. Stop on first validity,no improvement,4calls,inconsistency or cap. No numerical convergence or local minimum proves source validity or exclusion.'})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
    cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'memory_bytes':2**31,'preparation_seconds_charged':charge,'retry_permitted':False})
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(Path(__file__)),'--child',str(started)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env)
    (OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0
    write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'repeat_permitted':False})
    print(load(OUT/'process.json'));print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed result; pipeline remains closed.')
if __name__=='__main__':
    if '--child' in sys.argv:child(float(sys.argv[2]))
    else:main()
