from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
from h5_two_phase_union_model_20261107 import ROOT,BASE,G,M,load,pack
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
BASE.mkdir();started=time.perf_counter();shutil.copyfile(__file__,BASE/'prepare.py');assert load(G/'audit-v2/checks.json')['passed']
arrays,lib=pack();np.savez_compressed(BASE/'regions.npz',**arrays);write(BASE/'library.json',lib)
charges={'complete_prior_warm_start_and_diagnostic':load(G/'plan.json')['consumed_warm_start_and_diagnostic_seconds'],'complete_new_two_phase_source_geometry':load(ROOT/'output/h5-two-phase-cog-geometry-process-20261107/prepare.json')['complete_seconds']}
write(BASE/'source-preparation-charges.json',charges)
inputs=[Path(__file__),ROOT/'output/h5_two_phase_union_model_20261107.py',ROOT/'output/h5_cog_physical_union_distance_v2_20261107.py',ROOT/'output/h5_cog_union_distance_20261107.py',ROOT/'output/h5-two-phase-cog-geometry-process-20261107/prepare.json']+[G/n for n in ['plan.json','family-modes.json','templates.json','owner-pairs.json','audit-v2/plan.json','audit-v2/checks.json']]+[M/n for n in ['library.json','search/result.json','search/process.json','audit/optimizer-controls.json','audit/tool-provenance.json']]
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Pack all2621 certified source regions in millimetres, derive exact-edge outward normals, and directly couple every ordered phase pair. All28 source templates are explicit; no reflected/symmetric/canonical alias shortcut. Retain all120 finite owner/mode choices and258 pair interactions with2568 actual mode couplings, every rigid rectangle direction and original mode stock bound. Initial candidate is the previous invalid result with7degree cogs; it may be evaluated for reference but never optimized again. A future distinct pipeline must include at least one16degree cog, choose only a strict improving unvisited legal mode vector, and independently read back all dynamic fields before a call. All candidate source checks remain mandatory.',
    'source_preparation_seconds':sum(charges.values()),'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'maximum_changed_mode_calls':4,'maximum_one_call_seconds':4,'at_least_one_second_phase_required':True,'retry_permitted':False,'optimizer_calls':0})
write(BASE/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'finite_owner_modes':120,'source_templates':28,'certified_source_regions':2621,'pair_mode_couplings':len(lib['couplings']),'regions_sha256':digest(BASE/'regions.npz'),'library_sha256':digest(BASE/'library.json'),'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False})
print(load(BASE/'checks.json'))
