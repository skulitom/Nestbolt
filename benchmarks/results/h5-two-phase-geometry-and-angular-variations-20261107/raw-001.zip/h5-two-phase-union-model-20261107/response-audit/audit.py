from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
from h5_two_phase_union_model_20261107 import ROOT,BASE,load,compile_modes,readback,Objective
OUT=BASE/'response-audit';S=BASE/'search';digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');assert load(BASE/'audit/checks.json')['passed']
lib=load(BASE/'library.json');npz=np.load(BASE/'regions.npz',allow_pickle=False);regions={k:npz[k] for k in npz.files}
for a in regions.values():a.flags.writeable=False
initial=lib['initial_modes'];x=np.array(lib['initial_values_mm']);a,meta=compile_modes(regions,lib,initial,x);assert readback(a,meta,regions,lib,initial,x)
value,g=Objective(a,meta).evaluate(x);folder=S/'round-00';opened=load(folder/'opened.json');saved=load(folder/'mode-trials.json');result=load(S/'result.json');plan=load(S/'plan.json');process=load(S/'process.json');job=load(S/'job.json')
assert opened['modes']==initial and np.array_equal(opened['values_mm'],x) and opened['objective_mm2']==value==load(BASE/'audit/checks.json')['initial_reference_objective_mm2']
assert opened['previously_optimized_or_initial_modes']==[initial] and saved['complete']
trials=[];skipped=[]
for owner in lib['owners']:
    oi=owner['owner']
    for m in lib['family_modes'][owner['identity'][0]]:
        mode=m['mode']
        if mode==initial[oi]:continue
        modes=initial.copy();modes[oi]=mode
        if not any(modes[16:]):skipped.append({'owner':oi,'mode':mode,'reason':'at_least_one_second_cog_phase_required'});continue
        assert oi>=16 and mode==1 and sum(modes[16:])==1
        aa,mm=compile_modes(regions,lib,modes,x);assert readback(aa,mm,regions,lib,modes,x);energy,gradient=Objective(aa,mm).evaluate(aa['initial'])
        changed={str(i):float(aa['initial'][i]) for i in range(56) if aa['initial'][i]!=x[i]};assert all(int(i)//2==oi for i in changed)
        trials.append({'sequence':len(trials),'owner':oi,'identity':owner['identity'],'mode':mode,'modes':modes,'objective_mm2':energy,'decrease_mm2':value-energy,'clamped_coordinates':changed,'dynamic_readback_passed':True})
assert len(trials)==12 and len(skipped)==80 and saved=={'complete':True,'evaluated':trials,'skipped':skipped,'strict_improvement_threshold_mm2':1e-6}
assert all(t['decrease_mm2']<=1e-6 for t in trials) and not (folder/'selected-mode.json').exists() and not (folder/'optimizer-opened.json').exists() and not (folder/'response.json').exists() and not list((folder/'incumbents').glob('*'))
assert sorted(p.name for p in S.glob('round-*'))==['round-00']
assert result['closed'] and result['status']=='NO_IMPROVING_UNVISITED_MODE_VECTOR' and result['optimizer_calls']==result['source_checker_calls']==result['native_calls']==0 and result['rounds']==[] and result['mode_trials']==12
assert result['final_modes']==initial and np.array_equal(result['final_values_mm'],x) and not result['source_valid66'] and not result['any_allocation_excluded']
assert result['algorithm_seconds_including_preparation']<=process['seconds_including_preparation']<60 and result['algorithm_overrun_seconds']==0
assert process['exit_code']==job['reason_code']==job['error_code']==job['active_processes']==0 and job['closed'] and process['tree_closed'] and process['job']==job and job['peak_job_committed_memory']<2**31
charges=load(S/'preparation-charges.json');assert sum(charges.values())==plan['preparation_seconds_charged']
assert charges=={**load(BASE/'source-preparation-charges.json'),'complete_new_two_phase_model_preparation':load(ROOT/'output/h5-two-phase-union-model-process-20261107/prepare.json')['complete_seconds']}
assert plan['maximum_changed_mode_calls']==plan['maximum_one_call_seconds']==4 and plan['at_least_one_second_phase_required'] and plan['source_check_reserve_seconds']==4 and not plan['retry_permitted']
write(OUT/'replayed-mode-trials.json',trials)
inputs=[Path(__file__),ROOT/'output/h5_two_phase_union_model_20261107.py']+[BASE/n for n in ['plan.json','source-preparation-charges.json','library.json','regions.npz','audit/plan.json','audit/checks.json']]+[p for p in S.rglob('*') if p.is_file()]
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    d=load(p)
    if not isinstance(d,dict):continue
    for name,h in {**d.get('inputs',{}),**d.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert digest(z)==h;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently enumerate all92 single-owner alternatives at the unchanged original invalid candidate. Verify80 all7degree vectors are ineligible and all12 eligible second-phase changes increase the newly certified source-union objective. Recompute each dynamic model,hard-bound clamp and energy; verify the strict-improvement stop occurs before selecting any vector or opening any optimizer/source/native call. Reconcile every charge and process cap. This result excludes only improving one-owner phase substitutions at this point, not any continuous packing or larger mode combination.'})
checks={'passed':True,'seconds':time.perf_counter()-start,'source_bindings':len(bindings),'eligible_mode_trials_replayed':12,'ineligible_all_first_phase_changes':80,'initial_reference_objective_mm2':value,'minimum_objective_increase_mm2':min(t['objective_mm2']-value for t in trials),'maximum_objective_increase_mm2':max(t['objective_mm2']-value for t in trials),'closed_pipeline':True,'optimizer_calls':0,'source_checker_calls':0,'native_calls':0,'source_valid66':False,'preparation_seconds_charged':sum(charges.values()),'algorithm_seconds_including_preparation':result['algorithm_seconds_including_preparation'],'shared_seconds_including_preparation':process['seconds_including_preparation'],'peak_job_committed_memory':job['peak_job_committed_memory'],'all_descendants_closed':True,'any_allocation_excluded':False,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
