"""Frozen original-source angular variation diagnostic; no placement optimizer."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil,copy
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-original-cog-angular-variations-20261107';M=ROOT/'output/h5-mixed-mode-union-20261107';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'probe.py')
assert load(M/'response-audit/checks.json')['passed'];source=load(M/'search/round-00/candidate-source66.json');lib=load(M/'library.json');initial=load(M/'search/result.json');job=load(JOB);spec=load(FIRST/'plan.json');part=next(p for p in job['parts'] if p['id']=='cog');assert part['rotations']['kind']=='free' and not part['allow_mirror']
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,FIRST/'plan.json',I/'inventory.json']+[M/n for n in ['library.json','search/result.json','search/process.json','search/round-00/candidate-source66.json','search/round-00/original-source-checks.json','response-audit/plan.json','response-audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'At the unchanged invalid original66-part mixed-mode candidate, evaluate each of12 cog copies at6.75 and7.25degrees, one original at a time. Derive its normalized source pose, exact inward stock/core domain and only the necessary lower-left clamp; retain every other original pose byte-for-byte. Check all66 original contours,holes,pairs and stock edges for each of24 variations. Report summed pairwise intersection area and all source failures; it is a local diagnostic,not a derivative proof,optimizer restart or validity surrogate. Freeze angle choices and tie-break before observing any results. No half-phase geometry,closed phase-model result or phase search state is an algorithm input.',
    'angles_degrees':[6.75,7.25],'maximum_source_variations':24,'comparison':'Sum actual pairwise filled-outer intersection areas,then source pair failures,owner,angle. Areas can double-count and do not measure union area. Source validity still requires every original gap/stock check.',
    'preparation_target_seconds':5,'complete_process_cap_seconds':8,'memory_bytes':2**31,'source_optimizer_calls':0,'retry_permitted':False,'consumed_original_candidate_process_seconds':load(M/'search/process.json')['seconds_including_preparation']})
identities=list(map(tuple,load(I/'inventory.json')['full66_identities']));baseline=audit(job,source,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],identities);assert baseline==load(M/'search/round-00/original-source-checks.json');base_area=sum(p['intersection_area_mm2'] for p in baseline['pairs']);write(OUT/'baseline-checks.json',baseline)
stock=list(map(F,spec['construction_stock']));safe=[stock[0]+F(1,40),stock[1]+F(1,40),stock[2]-F(1,40),stock[3]-F(1,40)];eps=F(1,1000000);modes=[]
for angle in [6.75,7.25]:
    theta=math.radians(angle);c,s=math.cos(theta),math.sin(theta);vertices=[(x*c-y*s,x*s+y*c) for x,y in part['geometry'][0]['outer']];offset=[-min(x for x,y in vertices),-min(y for x,y in vertices)];cx,sx=F(c),F(s);tx,ty=map(F,offset)
    exact=[(F(x)*cx-F(y)*sx+tx,F(x)*sx+F(y)*cx+ty) for x,y in part['geometry'][0]['outer']];bounds=[min(p[k] for p in exact) for k in [0,1]]+[max(p[k] for p in exact) for k in [0,1]]
    grid=[[math.ceil((safe[k]-bounds[k]+eps)*100),math.floor((safe[k+2]-bounds[k+2]-eps)*100)] for k in [0,1]]
    modes.append({'angle_degrees':angle,'rotation_radians':theta,'mirrored':False,'translation_from_lower_left':offset,'exact_source_bounds_mm':[str(v) for v in bounds],'world_lower_left_grid_bounds':grid})
write(OUT/'probe-modes.json',modes);rows=[]
for owner in lib['owners'][16:]:
    oi=owner['owner'];identity=owner['identity'];assert initial['final_modes'][oi]==0;before=[initial['final_values_mm'][2*oi],initial['final_values_mm'][2*oi+1]+2100]
    for mode in modes:
        lower=[min(max(before[k],mode['world_lower_left_grid_bounds'][k][0]/100),mode['world_lower_left_grid_bounds'][k][1]/100) for k in [0,1]];candidate=copy.deepcopy(source);matches=[i for i,r in enumerate(candidate) if [r['part_id'],r['copy_index']]==identity];assert len(matches)==1;index=matches[0]
        candidate[index]['transform']={'rotation_radians':mode['rotation_radians'],'mirrored':False,'translation':[lower[k]+mode['translation_from_lower_left'][k] for k in [0,1]]}
        checks=audit(job,candidate,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],identities);assert checks['originals']==66 and checks['same_sheet_pairs']==1632 and checks['stock_edges']==264 and checks['cutouts']==90 and checks['hole_vertices']==10026 and checks['stock_failures']==0
        area=sum(p['intersection_area_mm2'] for p in checks['pairs']);stem=f'{len(rows):02d}';write(OUT/(stem+'-source66.json'),candidate);write(OUT/(stem+'-checks.json'),checks)
        rows.append({'sequence':len(rows),'owner':oi,'identity':identity,'angle_degrees':mode['angle_degrees'],'source_row':index,'lower_left_before_mm':before,'lower_left_after_mm':lower,'changed_lower_left_axes':[k for k in [0,1] if lower[k]!=before[k]],'summed_pairwise_intersection_area_mm2':area,'change_from_baseline_mm2':area-base_area,'pair_failures':checks['pair_failures'],'stock_failures':checks['stock_failures'],'source_valid66':checks['valid'],'source_file':stem+'-source66.json','checks_file':stem+'-checks.json'})
        assert time.perf_counter()-started<5
write(OUT/'variations.json',rows);best=min(rows,key=lambda r:(r['summed_pairwise_intersection_area_mm2'],r['pair_failures'],r['owner'],r['angle_degrees']));write(OUT/'best-local-variation.json',best)
write(OUT/'checks.json',{'passed':True,'seconds_including_serialization':time.perf_counter()-started,'source_variations':len(rows),'source_checks_including_baseline':25,'originals_each':66,'same_sheet_pairs_each':1632,'stock_edges_each':264,'holes_each':90,'hole_vertices_each':10026,'baseline_summed_pairwise_intersection_area_mm2':base_area,'baseline_pair_failures':baseline['pair_failures'],'decreasing_overlap_variations':sum(r['change_from_baseline_mm2']<0 for r in rows),'best_change_mm2':best['change_from_baseline_mm2'],'best_owner':best['owner'],'best_identity':best['identity'],'best_angle_degrees':best['angle_degrees'],'best_pair_failures':best['pair_failures'],'any_source_valid66':any(r['source_valid66'] for r in rows),'optimizer_calls':0,'any_allocation_excluded':False,'H5_complete':False})
print(load(OUT/'checks.json'))
