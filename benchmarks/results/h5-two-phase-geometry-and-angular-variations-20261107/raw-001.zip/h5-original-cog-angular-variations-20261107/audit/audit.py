from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil,copy
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-original-cog-angular-variations-20261107';OUT=BASE/'audit';M=ROOT/'output/h5-mixed-mode-union-20261107';FIRST=ROOT/'output/h5-first57-direct-short9-20261104';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');job=load(JOB);spec=load(FIRST/'plan.json');part=next(p for p in job['parts'] if p['id']=='cog');original=load(M/'search/round-00/candidate-source66.json');state=load(M/'search/result.json');owners=load(M/'library.json')['owners'];identities=list(map(tuple,load(I/'inventory.json')['full66_identities']))
assert part['rotations']['kind']=='free' and not part['allow_mirror'];baseline=audit(job,original,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],identities);assert baseline==load(BASE/'baseline-checks.json')==load(M/'search/round-00/original-source-checks.json');base_area=sum(p['intersection_area_mm2'] for p in baseline['pairs'])
stock=list(map(F,spec['construction_stock']));safe=[stock[0]+F(1,40),stock[1]+F(1,40),stock[2]-F(1,40),stock[3]-F(1,40)];eps=F(1,1000000);modes=load(BASE/'probe-modes.json')
assert [m['angle_degrees'] for m in modes]==[6.75,7.25]
for m in modes:
    theta=math.radians(m['angle_degrees']);assert m['rotation_radians']==theta and not m['mirrored'];c,s=math.cos(theta),math.sin(theta)
    rot=[(x*c-y*s,x*s+y*c) for x,y in part['geometry'][0]['outer']];offset=[-min(x for x,y in rot),-min(y for x,y in rot)];assert offset==m['translation_from_lower_left']
    exact=[(F(x)*F(c)-F(y)*F(s)+F(offset[0]),F(x)*F(s)+F(y)*F(c)+F(offset[1])) for x,y in part['geometry'][0]['outer']];b=[min(p[k] for p in exact) for k in [0,1]]+[max(p[k] for p in exact) for k in [0,1]];assert [str(v) for v in b]==m['exact_source_bounds_mm']
    for k,(lo,hi) in enumerate(m['world_lower_left_grid_bounds']):
        assert F(lo-1,100)<safe[k]-b[k]+eps<=F(lo,100) and F(hi,100)<=safe[k+2]-b[k+2]-eps<F(hi+1,100)
records=load(BASE/'variations.json');assert len(records)==24;checks=0;area_changes=[];source_failures=[]
for i,(owner,mode) in enumerate((o,m) for o in owners[16:] for m in modes):
    r=records[i];oi=owner['owner'];identity=owner['identity'];assert r['sequence']==i and r['owner']==oi and r['identity']==identity and r['angle_degrees']==mode['angle_degrees']
    before=[state['final_values_mm'][2*oi],state['final_values_mm'][2*oi+1]+2100];after=[max(b[0]/100,min(b[1]/100,before[k])) for k,b in enumerate(mode['world_lower_left_grid_bounds'])]
    assert before==r['lower_left_before_mm'] and after==r['lower_left_after_mm'] and [k for k in [0,1] if before[k]!=after[k]]==r['changed_lower_left_axes']
    reconstructed=copy.deepcopy(original);index=next(j for j,p in enumerate(reconstructed) if [p['part_id'],p['copy_index']]==identity);assert index==r['source_row']
    reconstructed[index]['transform']={'rotation_radians':mode['rotation_radians'],'mirrored':False,'translation':[after[k]+mode['translation_from_lower_left'][k] for k in [0,1]]}
    assert reconstructed==load(BASE/r['source_file']) and sum(a!=b for a,b in zip(original,reconstructed))==1
    result=audit(job,reconstructed,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],identities);assert result==load(BASE/r['checks_file'])
    assert result['originals']==66 and result['same_sheet_pairs']==1632 and result['stock_edges']==264 and result['cutouts']==90 and result['hole_vertices']==10026 and result['stock_failures']==0
    area=sum(p['intersection_area_mm2'] for p in result['pairs']);assert area==r['summed_pairwise_intersection_area_mm2'] and area-base_area==r['change_from_baseline_mm2'] and result['valid']==r['source_valid66'] and result['pair_failures']==r['pair_failures']
    area_changes.append(area-base_area);source_failures.append(result['pair_failures']);checks+=1
best=min(records,key=lambda r:(r['summed_pairwise_intersection_area_mm2'],r['pair_failures'],r['owner'],r['angle_degrees']));assert best==load(BASE/'best-local-variation.json')
process=load(ROOT/'output/h5-original-cog-angular-variations-process-20261107/process.json');summary=load(BASE/'checks.json');assert process['passed'] and process['closed'] and process['job']['active_processes']==0 and process['complete_seconds']<8 and summary['seconds_including_serialization']<5
assert summary['best_owner']==best['owner']==17 and best['identity']==['cog',2] and best['angle_degrees']==7.25 and summary['best_change_mm2']==min(area_changes) and summary['decreasing_overlap_variations']==sum(v<0 for v in area_changes)==12
assert not any(r['source_valid66'] for r in records) and not summary['any_source_valid66'] and all(n==39 for n in source_failures)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,FIRST/'plan.json',I/'inventory.json']+[p for p in BASE.glob('*.json')]+[M/n for n in ['library.json','search/result.json','search/process.json','search/round-00/candidate-source66.json','search/round-00/original-source-checks.json']]+[ROOT/'output/h5-original-cog-angular-variations-process-20261107'/n for n in ['opened.json','process.json']]
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    d=load(p)
    if not isinstance(d,dict):continue
    for name,h in {**d.get('inputs',{}),**d.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert digest(z)==h;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently derive both6.75/7.25degree original affine poses and exact stock-bound neighbours. Reconstruct each of24 variations and require exactly one original transform to change. Recheck every original outer,cutout,pair and stock edge,then recompute source overlap sums and the frozen ranking. Preserve all39failures in every candidate. This establishes only local source geometry information; no optimization,derivative proof,allocation exclusion or valid66 layout.'})
result={'passed':True,'seconds':time.perf_counter()-start,'source_bindings':len(bindings),'variations_reconstructed':checks,'source_pairs_checked':25*1632,'stock_edges_checked':25*264,'holes_checked':25*90,'hole_vertices_checked':25*10026,'source_overlap_decreases':12,'best_identity':best['identity'],'best_angle_degrees':7.25,'best_overlap_area_change_mm2':best['change_from_baseline_mm2'],'all_candidates_pair_failures':39,'all_candidates_stock_failures':0,'source_valid66':False,'complete_probe_process_seconds':process['complete_seconds'],'complete_direct_candidate_plus_probe_seconds':load(M/'search/process.json')['seconds_including_preparation']+process['complete_seconds'],'source_optimizer_calls':0,'any_allocation_excluded':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
