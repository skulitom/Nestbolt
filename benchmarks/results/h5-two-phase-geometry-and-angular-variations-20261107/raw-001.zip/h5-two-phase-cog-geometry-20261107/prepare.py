"""Fresh full-domain original source geometry for cog phases7/16; no optimizer."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import hull,merge_exact,area
from h5_two_phase_source_tools_20261107 import affine,exterior,nfp,support
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-two-phase-cog-geometry-20261107'
FIRST=ROOT/'output/h5-first57-direct-short9-20261104';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';M=ROOT/'output/h5-mixed-mode-union-20261107'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
BASE.mkdir();started=time.perf_counter();shutil.copyfile(__file__,BASE/'prepare.py')
assert load(I/'audit/checks.json')['passed'] and load(FIRST/'audit/checks.json')['passed'] and load(M/'response-audit/checks.json')['passed']
inputs=[Path(__file__),ROOT/'output/h5_two_phase_source_tools_20261107.py',ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,PIECES,ROOT/'output/h5-mixed-mode-checkpoint-20261107/next-step-v2.json']+[I/n for n in ['family-modes.json','inventory.json','audit/plan.json','audit/checks.json']]+[FIRST/n for n in ['plan.json','fixed29.json','short9-source.json','audit/plan.json','audit/checks.json']]+[M/n for n in ['search/result.json','search/process.json','response-audit/plan.json','response-audit/checks.json']]+[ROOT/'output/h5-mixed-mode-coverage-process-20261107/process.json']
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Prepare direct original-source geometry for all8 bracket,4 insert and2 cog phases7/16degrees. Derive exact affine inward stock/core bounds and56 source corner controls. Construct all28 ordered cog/mode forbidden templates over complete signed relative domains, with no cog X-order restriction or canonical-alias shortcut. Use original convex pieces, square inflation.226mm, clipped exterior hull halfplanes and convex concave-pocket cells. Round candidate region vertices to9decimals, then independently test exact rational support inequalities against original source convex pieces before retaining each region. These source-support preparations are charged as algorithm work. No old geometry or closed solve state is treated as a proof for the new phase. A later independent auditor must rederive every support, domain and coupling before any model.',
    'cog_phases_degrees':[7,16],'world_origin_mm':[0,2100],'extra_stock_mm':'.025','inward_reserve_mm':'.000001','square_halfwidth_mm':.226,'certified_pair_gap_mm':'.225','grid_units_per_mm':100,
    'preparation_target_seconds':15,'complete_process_cap_seconds':20,'independent_audit_cap_seconds':90,'future_algorithm_seconds':60,'future_shared_seconds':90,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,
    'consumed_warm_start_and_diagnostic_seconds':load(M/'search/process.json')['seconds_including_preparation']+load(ROOT/'output/h5-mixed-mode-coverage-process-20261107/process.json')['complete_seconds']})
job=load(JOB);parts={p['id']:p for p in job['parts']};canonical=load(PIECES);spec=load(FIRST/'plan.json');inventory=load(I/'inventory.json');old_modes=load(I/'family-modes.json');fixed=load(FIRST/'fixed29.json');short=load(FIRST/'short9-source.json')
stock=list(map(F,spec['construction_stock']));safe=[stock[0]+F(1,40),stock[1]+F(1,40),stock[2]-F(1,40),stock[3]-F(1,40)];eps=F(1,1000000)
core_top=max(p[1] for r in fixed for p in affine(parts[r['part_id']]['geometry'][0]['outer'],r['transform']));assert safe[1]-core_top>F(spec['required_pair_gap_mm'])
modes={};geometries=[];exact_geometry=[];controls=[]
representatives={'bracket':inventory['moving16_orthogonal_identities'][0],'insert':next(i for i in inventory['moving16_orthogonal_identities'] if i[0]=='insert'),'cog':inventory['required_cog12_identities'][0]}
for family in ['bracket','insert','cog']:
    modes[family]=[]
    options=[(m['rotation_degrees'],m['rotation_radians'],m['mirrored'],m['translation_from_lower_left']) for m in old_modes[family]]
    if family=='cog':
        assert parts[family]['rotations']['kind']=='free' and not parts[family]['allow_mirror']
        theta=math.radians(16);c,s=math.cos(theta),math.sin(theta);points=[(x*c-y*s,x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']]
        options.append((16.,theta,False,[-min(x for x,y in points),-min(y for x,y in points)]))
    for mode,(degrees,angle,mirrored,translation) in enumerate(options):
        m={'mode':mode,'rotation_degrees':degrees,'rotation_radians':angle,'mirrored':mirrored,'translation_from_lower_left':translation,'geometry':len(geometries)}
        outer=affine(parts[family]['geometry'][0]['outer'],m);pieces=[affine(p,m) for p in canonical[family]];holes=[affine(h,m) for h in parts[family]['geometry'][0].get('holes',[])]
        bounds=[min(v[k] for v in outer) for k in [0,1]]+[max(v[k] for v in outer) for k in [0,1]]
        world=[[math.ceil((safe[k]-bounds[k]+eps)*100),math.floor((safe[k+2]-bounds[k+2]-eps)*100)] for k in [0,1]]
        m['individual_grid_bounds']=world;m['integer_world_lower_left_bounds']=[[a-[0,210000][k],b-[0,210000][k]] for k,(a,b) in enumerate(world)];m['exact_normalized_source_bounds_mm']=[str(v) for v in bounds];modes[family].append(m)
        exact_geometry.append({'outer':outer,'hull':hull(outer),'pieces':pieces})
        geometries.append({'geometry':m['geometry'],'family':family,'mode':mode,'outer':[[float(x),float(y)] for x,y in outer],'pieces':[[[float(x),float(y)] for x,y in p] for p in pieces],'holes':[[[float(x),float(y)] for x,y in h] for h in holes]})
        for corner,xy in enumerate(product(*world)):
            identity=representatives[family];row={'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':mirrored,'translation':[xy[k]/100+translation[k] for k in [0,1]]}}
            rows=fixed+[row]+short;check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in rows]);assert check['valid']
            stem=f'{family}-{mode}-{corner}';write(BASE/(stem+'-source.json'),rows);write(BASE/(stem+'-checks.json'),check);controls.append({'family':family,'mode':mode,'corner':corner,'position_grid':xy,'source':stem+'-source.json','checks':stem+'-checks.json'})
        assert time.perf_counter()-started<15
assert len(geometries)==14 and len(controls)==56
instances=[{'owner':i,'identity':x,'mode_count':len(modes[x[0]])} for i,x in enumerate(inventory['moving16_orthogonal_identities']+inventory['required_cog12_identities'])];assert sum(i['mode_count'] for i in instances)==120
geometry_modes=[m for family in ['bracket','insert','cog'] for m in modes[family]];assert [m['geometry'] for m in geometry_modes]==list(range(14))
square=np.array([[-.226,-.226],[.226,-.226],[.226,.226],[-.226,.226]]);templates=[];proofs=[];disabled=[];minimum_gap=math.inf
for agid in [12,13]:
    for bgid in range(14):
        ma,mb=geometry_modes[agid],geometry_modes[bgid];aa,bb=ma['individual_grid_bounds'],mb['individual_grid_bounds'];relative=[[bb[k][0]-aa[k][1],bb[k][1]-aa[k][0]] for k in [0,1]]
        domain=[F(relative[0][0],100),F(relative[1][0],100),F(relative[0][1],100),F(relative[1][1],100)];A,B=exact_geometry[agid],exact_geometry[bgid];pieces=[]
        for a,b in product(geometries[agid]['pieces'],geometries[bgid]['pieces']):
            difference=(np.asarray(a)[:,None,:]-np.asarray(b)[None,:,:]).reshape(-1,2);pieces.append(MultiPoint((difference[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
        inflated=unary_union(pieces);envelope=inflated.convex_hull;h=hull([tuple(map(F,p)) for p in envelope.exterior.coords[:-1]]);raw=[]
        for a,b in zip(h,h[1:]+h[:1]):
            region=exterior(domain,a,b)
            if region is not None:raw.append(('convex_exterior_halfplane',region))
        pockets=envelope.difference(inflated).intersection(box(*map(float,domain)))
        triangles=[p for p in shapely.constrained_delaunay_triangles(pockets).geoms if p.area>0];merged,merges=merge_exact(triangles) if triangles else ([],0);raw.extend(('concave_pocket',p) for p in merged)
        tid=len(templates);regions=[];cache={};proof_count_before=len(proofs)
        for raw_id,(kind,points) in enumerate(raw):
            vertices=hull([tuple(F(round(x,9)) for x in p) for p in points])
            if len(vertices)<3 or area(vertices)<=0:disabled.append({'template':tid,'raw_region':raw_id,'reason':'degenerate_after_rounding'});continue
            shape=Polygon([(float(x),float(y)) for x,y in vertices]);assert shape.is_valid
            local=[];tasks=[(-1,-1)]
            while tasks:
                ai,bi=tasks.pop();ap=A['hull'] if ai==-1 else A['pieces'][ai];bp=B['hull'] if bi==-1 else B['pieces'][bi]
                if (ai,bi) not in cache:cache[ai,bi]=nfp(ap,bp)
                witness=support(vertices,shape,bp,ap,cache[ai,bi])
                if witness:
                    normal,gap=witness;local.append({'template':tid,'region':len(regions),'a_piece':ai,'b_piece':bi,'normal':normal,'gap_lower_mm':gap});minimum_gap=min(minimum_gap,gap)
                elif bi==-1:tasks.extend((-1,j) for j in range(len(B['pieces'])))
                elif ai==-1:tasks.extend((j,bi) for j in range(len(A['pieces'])))
                else:raise AssertionError(('unsafe rounded region',tid,raw_id,ai,bi))
            regions.append({'region':len(regions),'raw_region':raw_id,'kind':kind,'vertices_mm':[[str(x),str(y)] for x,y in vertices]});proofs.extend(local)
        assert regions
        templates.append({'template':tid,'a_geometry':agid,'b_geometry':bgid,'a_mode':ma['mode'],'b_family':geometries[bgid]['family'],'b_mode':mb['mode'],'relative_grid_bounds':relative,'domain_mm':[str(x) for x in domain],'relative_coordinate':'lower_left_B_minus_lower_left_A','cog_x_order_applied':False,'regions':regions,'raw_regions':len(raw),'pocket_triangles':len(triangles),'exact_merges':merges,'source_support_proofs':len(proofs)-proof_count_before})
        identities=[inventory['required_cog12_identities'][0],inventory['required_cog12_identities'][1] if geometries[bgid]['family']=='cog' else representatives[geometries[bgid]['family']]]
        pair_rows=[];pair_xy=[[v[0] for v in aa],[v[1] for v in bb]]
        for identity,mode,xy in zip(identities,[ma,mb],pair_xy):pair_rows.append({'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]/100+mode['translation_from_lower_left'][k] for k in [0,1]]}})
        control_rows=fixed+pair_rows+short;control=audit(job,control_rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in control_rows]);assert control['valid']
        write(BASE/f'pair-{tid:02d}-source.json',control_rows);write(BASE/f'pair-{tid:02d}-checks.json',control)
        templates[-1]['positive_pair_position_grid']=pair_xy
        write(BASE/f'template-{tid:02d}.json',templates[-1]);assert time.perf_counter()-started<15
owner_pairs=[]
for a in range(16,28):
    for b in range(16):owner_pairs.append({'pair':len(owner_pairs),'owners':[a,b],'kind':'cog_orthogonal','templates':[t['template'] for t in templates if t['b_family']==instances[b]['identity'][0]]})
for a,b in combinations(range(16,28),2):owner_pairs.append({'pair':len(owner_pairs),'owners':[a,b],'kind':'cog_cog','templates':[t['template'] for t in templates if t['b_family']=='cog']})
assert len(templates)==28 and len(owner_pairs)==258 and sum(len(p['templates']) for p in owner_pairs)==2568
for name,data in [('family-modes.json',modes),('geometry-library.json',geometries),('inventory.json',inventory),('instances.json',instances),('controls.json',controls),('templates.json',templates),('source-supports.json',proofs),('disabled-regions.json',disabled),('owner-pairs.json',owner_pairs),('domain.json',{'safe_world_bounds_mm':[str(x) for x in safe],'core_top_mm':str(core_top),'world_origin_mm':[0,2100],'cartesian_product_collision_free':False}),('invalid-warm-start.json',load(M/'search/result.json'))]:write(BASE/name,data)
result={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-started,'moving_originals':28,'finite_owner_modes':120,'source_mode_geometries':14,'source_corner_controls':56,'ordered_source_templates':28,'pair_interactions':258,'expanded_pair_mode_couplings':2568,'certified_regions':sum(len(t['regions']) for t in templates),'exact_source_supports':len(proofs),'disabled_degenerate_regions':len(disabled),'minimum_certified_source_gap_mm':minimum_gap,'new_model_created':False,'optimizer_calls':0,'source_valid66':False,'H5_complete':False}
write(BASE/'checks.json',result);print(result)
