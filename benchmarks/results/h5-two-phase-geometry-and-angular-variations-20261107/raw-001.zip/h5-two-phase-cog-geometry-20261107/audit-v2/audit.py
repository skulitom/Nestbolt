"""Independent exact partition, source pose, ordered pair and support-certificate audit."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
from collections import Counter
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil
from shapely.geometry import Polygon
from h5_exact_convex_partition_tools_20261029 import hull,area,cross
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-two-phase-cog-geometry-20261107';OUT=BASE/'audit-v2'
FIRST=ROOT/'output/h5-first57-direct-short9-20261104';I=ROOT/'output/h5-independent-twelve-cog-integer-20261107';PROCESS=ROOT/'output/h5-two-phase-cog-geometry-process-20261107'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PIECES=ROOT/'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
job=load(JOB);parts={p['id']:p for p in job['parts']};canonical=load(PIECES);spec=load(FIRST/'plan.json');inventory=load(BASE/'inventory.json');modes=load(BASE/'family-modes.json');old=load(I/'family-modes.json');geometries=load(BASE/'geometry-library.json');fixed=load(FIRST/'fixed29.json');short=load(FIRST/'short9-source.json')
assert inventory==load(I/'inventory.json');ids=inventory['moving16_orthogonal_identities']+inventory['required_cog12_identities'];full={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}
assert len(full)==66 and len(ids)==28 and len(fixed)==29 and len(short)==9 and set(map(tuple,ids)).isdisjoint({(r['part_id'],r['copy_index']) for r in fixed+short})
assert full==set(map(tuple,ids))|{(r['part_id'],r['copy_index']) for r in fixed+short}
assert load(BASE/'instances.json')==[{'owner':i,'identity':identity,'mode_count':8 if identity[0]=='bracket' else 4 if identity[0]=='insert' else 2} for i,identity in enumerate(ids)]
def transform(points,m):
    c,s=map(F,[math.cos(m['rotation_radians']),math.sin(m['rotation_radians'])]);sign=-1 if m['mirrored'] else 1;tx,ty=map(F,m.get('translation_from_lower_left',m.get('translation')))
    return [(sign*F(x)*c-F(y)*s+tx,sign*F(x)*s+F(y)*c+ty) for x,y in points]
partition=[]
for family in ['bracket','insert','cog']:
    outer=[tuple(map(F,p)) for p in parts[family]['geometry'][0]['outer']];pieces=[[tuple(map(F,p)) for p in piece] for piece in canonical[family]]
    if area(outer)<0:outer.reverse()
    for p in pieces:
        if area(p)<0:p.reverse()
        assert p==hull(p) or area(p)==area(hull(p));assert all(cross(a,b,c)>=0 for a,b,c in zip(p,p[1:]+p[:1],p[2:]+p[:2]))
    vertices=set(outer)|{v for p in pieces for v in p}
    def edges(polygons):
        counts=Counter()
        for p in polygons:
            for a,b in zip(p,p[1:]+p[:1]):
                points=sorted(v for v in vertices if cross(a,b,v)==0 and all(min(a[k],b[k])<=v[k]<=max(a[k],b[k]) for k in [0,1]))
                if a>b:points.reverse()
                assert points[0]==a and points[-1]==b
                for u,v in zip(points,points[1:]):counts[min(u,v),max(u,v)]+=1 if u<v else -1
        return {k:v for k,v in counts.items() if v}
    assert edges(pieces)==edges([outer]) and sum(area(p) for p in pieces)==area(outer)
    partition.append({'family':family,'convex_pieces':len(pieces),'boundary_segments':len(edges(pieces)),'exact_area_mm2':str(area(outer)),'exact_partition_verified':True})
write(OUT/'exact-source-partition.json',partition)
cog=parts['cog'];assert cog['rotations']['kind']=='free' and not cog['allow_mirror'];points=cog['geometry'][0]['outer'];assert len(points)==80 and len(cog['geometry'][0]['holes'])==1 and len(cog['geometry'][0]['holes'][0])==200
cx=sum(x for x,y in points)/80;cy=sum(y for x,y in points)/80;polar=[(math.hypot(x-cx,y-cy),math.atan2(y-cy,x-cx)) for x,y in points]
for tooth in range(20):
    for corner in range(4):
        radius,angle=polar[4*tooth+corner];r0,a0=polar[corner]
        assert abs(radius-r0)<1e-6 and abs(math.remainder(angle-a0-tooth*math.tau/20,math.tau))<1e-8
assert [m['rotation_degrees'] for m in modes['cog']]==[7.,16.] and abs((modes['cog'][1]['rotation_radians']-modes['cog'][0]['rotation_radians'])-math.pi/20)<1e-16
stock=list(map(F,spec['construction_stock']));safe=[stock[0]+F(1,40),stock[1]+F(1,40),stock[2]-F(1,40),stock[3]-F(1,40)];eps=F(1,1000000)
core_top=max(v[1] for r in fixed for v in transform(parts[r['part_id']]['geometry'][0]['outer'],r['transform']))
assert load(BASE/'domain.json')=={'safe_world_bounds_mm':[str(x) for x in safe],'core_top_mm':str(core_top),'world_origin_mm':[0,2100],'cartesian_product_collision_free':False}
assert safe[1]-core_top>F(spec['required_pair_gap_mm']);data=[];mode_data=[]
for family in ['bracket','insert','cog']:
    assert len(modes[family])=={'bracket':8,'insert':4,'cog':2}[family]
    for mi,m in enumerate(modes[family]):
        assert m['mode']==mi and m['geometry']==len(data)
        if family!='cog' or mi==0:
            original=old[family][mi]
            for key in ['rotation_degrees','rotation_radians','mirrored','translation_from_lower_left']:assert m[key]==original[key]
        else:
            assert m['rotation_radians']==math.radians(16) and not m['mirrored'];c,s=math.cos(m['rotation_radians']),math.sin(m['rotation_radians']);rot=[(x*c-y*s,x*s+y*c) for x,y in points]
            assert m['translation_from_lower_left']==[-min(x for x,y in rot),-min(y for x,y in rot)]
        outer=transform(parts[family]['geometry'][0]['outer'],m);pieces=[transform(p,m) for p in canonical[family]];holes=[transform(h,m) for h in parts[family]['geometry'][0].get('holes',[])];bounds=[min(v[k] for v in outer) for k in [0,1]]+[max(v[k] for v in outer) for k in [0,1]]
        assert m['exact_normalized_source_bounds_mm']==[str(v) for v in bounds]
        for k,(lo,hi) in enumerate(m['individual_grid_bounds']):
            assert F(lo-1,100)<safe[k]-bounds[k]+eps<=F(lo,100)
            assert F(hi,100)<=safe[k+2]-bounds[k+2]-eps<F(hi+1,100)
        assert m['integer_world_lower_left_bounds']==[[lo-[0,210000][k],hi-[0,210000][k]] for k,(lo,hi) in enumerate(m['individual_grid_bounds'])]
        assert geometries[len(data)]=={'geometry':len(data),'family':family,'mode':mi,'outer':[[float(x),float(y)] for x,y in outer],'pieces':[[[float(x),float(y)] for x,y in p] for p in pieces],'holes':[[[float(x),float(y)] for x,y in h] for h in holes]}
        data.append({'outer':outer,'hull':hull(outer),'pieces':pieces});mode_data.append(m)
assert len(data)==14
counts={'source_cases':0,'source_pairs':0,'stock_edges':0,'holes':0,'hole_vertices':0};minimum_pair=math.inf;minimum_stock=math.inf
def check_source(rows,saved):
    global minimum_pair,minimum_stock
    assert len(rows)==len({(r['part_id'],r['copy_index']) for r in rows});shapes=[];holes=hole_vertices=0;pair_count=0;min_pair=min_stock=math.inf
    for r in rows:
        part=parts[r['part_id']];assert 0<=r['copy_index']<part['quantity'];t=r['transform'];theta=t['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if t['mirrored'] else 1
        assert not t['mirrored'] or part['allow_mirror'];assert part['rotations']['kind']=='free' or any(abs(math.remainder(theta-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees'])
        def ring(v):return [(sign*x*c-y*s+t['translation'][0],sign*x*s+y*c+t['translation'][1]) for x,y in v]
        source=part['geometry'][0];outer=Polygon(ring(source['outer']));material=Polygon(ring(source['outer']),[ring(h) for h in source.get('holes',[])])
        assert outer.is_valid and material.is_valid and abs(material.area-Polygon(source['outer'],source.get('holes',[])).area)<1e-6
        b=outer.bounds;stock=spec['source_stocks'][r['sheet_id']];gap=min(b[0]-stock[0],b[1]-stock[1],stock[2]-b[2],stock[3]-b[3]);assert gap>spec['stock_guard_mm'];min_stock=min(min_stock,gap);holes+=len(source.get('holes',[]));hole_vertices+=sum(len(h) for h in source.get('holes',[]));shapes.append((r['sheet_id'],outer))
    for (sa,a),(sb,b) in combinations(shapes,2):
        if sa!=sb:continue
        gap=a.distance(b);assert a.disjoint(b) and gap>spec['required_pair_gap_mm'];min_pair=min(min_pair,gap);pair_count+=1
    assert saved['valid'] and saved['originals']==len(rows) and saved['same_sheet_pairs']==pair_count and saved['stock_edges']==4*len(rows) and saved['cutouts']==holes and saved['hole_vertices']==hole_vertices
    assert saved['minimum_pair_gap_mm']==min_pair and saved['minimum_extra_stock_mm']==min_stock
    counts['source_cases']+=1;counts['source_pairs']+=pair_count;counts['stock_edges']+=4*len(rows);counts['holes']+=holes;counts['hole_vertices']+=hole_vertices;minimum_pair=min(minimum_pair,min_pair);minimum_stock=min(minimum_stock,min_stock)
controls=load(BASE/'controls.json');ci=0;representatives={'bracket':ids[0],'insert':next(i for i in ids if i[0]=='insert'),'cog':ids[16]}
for family in ['bracket','insert','cog']:
    for m in modes[family]:
        for corner,xy in enumerate(product(*m['individual_grid_bounds'])):
            control=controls[ci];ci+=1;assert (control['family'],control['mode'],control['corner'],control['position_grid'])==(family,m['mode'],corner,list(xy))
            rows=load(BASE/control['source']);assert rows[:29]==fixed and rows[30:]==short;r=rows[29];assert [r['part_id'],r['copy_index']]==representatives[family] and r['sheet_id']=='sheet-0'
            assert r['transform']=={'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':[xy[k]/100+m['translation_from_lower_left'][k] for k in [0,1]]}
            check_source(rows,load(BASE/control['checks']))
assert ci==len(controls)==56
templates=load(BASE/'templates.json');proofs=load(BASE/'source-supports.json');assert len(templates)==28;proof_map={};minimum_certified=math.inf
for proof in proofs:proof_map.setdefault((proof['template'],proof['region']),[]).append(proof)
regions_checked=proofs_checked=pair_controls=0
for ti,t in enumerate(templates):
    agid=12+ti//14;bgid=ti%14;ma,mb=mode_data[agid],mode_data[bgid];aa,bb=ma['individual_grid_bounds'],mb['individual_grid_bounds'];relative=[[bb[k][0]-aa[k][1],bb[k][1]-aa[k][0]] for k in [0,1]]
    assert t['template']==ti and t['a_geometry']==agid and t['b_geometry']==bgid and t['a_mode']==ma['mode'] and t['b_family']==geometries[bgid]['family'] and t['b_mode']==mb['mode']
    assert t['relative_grid_bounds']==relative and t['domain_mm']==[str(F(relative[0][0],100)),str(F(relative[1][0],100)),str(F(relative[0][1],100)),str(F(relative[1][1],100))] and not t['cog_x_order_applied'] and t['relative_coordinate']=='lower_left_B_minus_lower_left_A'
    assert t==load(BASE/f'template-{ti:02d}.json');A,B=data[agid],data[bgid];local_proofs=0
    for ri,r in enumerate(t['regions']):
        assert r['region']==ri;v=[tuple(map(F,p)) for p in r['vertices_mm']];assert v==hull(v) and area(v)>0;coverage=set()
        for proof in proof_map[ti,ri]:
            ai,bi=proof['a_piece'],proof['b_piece'];ap=A['hull'] if ai==-1 else A['pieces'][ai];bp=B['hull'] if bi==-1 else B['pieces'][bi];nx,ny=map(F,proof['normal']);norm=nx*nx+ny*ny
            assert norm>0;gap=min(x*nx+y*ny for x,y in v)+min(x*nx+y*ny for x,y in bp)-max(x*nx+y*ny for x,y in ap)
            assert gap>0 and gap*gap>=F('.225')**2*norm
            actual=float(gap)/math.sqrt(float(norm));assert actual==proof['gap_lower_mm'];minimum_certified=min(minimum_certified,actual)
            coverage.update(product(range(len(A['pieces'])) if ai==-1 else[ai],range(len(B['pieces'])) if bi==-1 else[bi]));proofs_checked+=1;local_proofs+=1
        assert coverage==set(product(range(len(A['pieces'])),range(len(B['pieces']))));regions_checked+=1
    assert local_proofs==t['source_support_proofs']
    positions=[[v[0] for v in aa],[v[1] for v in bb]];assert positions==t['positive_pair_position_grid']
    rows=load(BASE/f'pair-{ti:02d}-source.json');assert rows[:29]==fixed and rows[31:]==short
    expected_ids=[ids[16],ids[17] if geometries[bgid]['family']=='cog' else representatives[geometries[bgid]['family']]]
    for row,identity,m,xy in zip(rows[29:31],expected_ids,[ma,mb],positions):
        assert [row['part_id'],row['copy_index']]==identity and row['sheet_id']=='sheet-0' and row['transform']=={'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':[xy[k]/100+m['translation_from_lower_left'][k] for k in [0,1]]}
    check_source(rows,load(BASE/f'pair-{ti:02d}-checks.json'));delta=[F(positions[1][k]-positions[0][k],100) for k in [0,1]]
    def memberships(point):
        return [ri for ri,r in enumerate(t['regions']) for vertices in [[tuple(map(F,p)) for p in r['vertices_mm']]] if all(cross(a,b,point)>=0 for a,b in zip(vertices,vertices[1:]+vertices[:1]))]
    diagnostic=load(ROOT/'output/h5-two-phase-boundary-controls-20261107/controls.json')[ti]
    assert diagnostic['template']==ti and memberships(delta)==diagnostic['corner_containing_regions']
    inside_positions=[[p+1 for p in positions[0]],[p-1 for p in positions[1]]]
    inside_delta=[F(inside_positions[1][k]-inside_positions[0][k],100) for k in [0,1]]
    assert [str(v) for v in inside_delta]==diagnostic['interior_relative_mm'] and memberships(inside_delta)==diagnostic['interior_containing_regions'] and memberships(inside_delta)
    inner_rows=fixed+[]
    for identity,m,xy in zip(expected_ids,[ma,mb],inside_positions):
        assert all(lo<=xy[k]<=hi for k,(lo,hi) in enumerate(m['individual_grid_bounds']))
        inner_rows.append({'part_id':identity[0],'copy_index':identity[1],'sheet_id':'sheet-0','transform':{'rotation_radians':m['rotation_radians'],'mirrored':m['mirrored'],'translation':[xy[k]/100+m['translation_from_lower_left'][k] for k in [0,1]]}})
    inner_rows+=short
    from h5_legacy64_source_readback import audit as original_source_reader
    inner_checks=original_source_reader(job,inner_rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],[(r['part_id'],r['copy_index']) for r in inner_rows])
    check_source(inner_rows,inner_checks)
    write(OUT/f'pair-{ti:02d}-interior-source.json',inner_rows);write(OUT/f'pair-{ti:02d}-interior-checks.json',inner_checks)
    pair_controls+=1;assert time.perf_counter()-started<85
assert proofs_checked==len(proofs)
expected=[]
for a in range(16,28):
    for b in range(16):expected.append({'pair':len(expected),'owners':[a,b],'kind':'cog_orthogonal','templates':[t['template'] for t in templates if t['b_family']==ids[b][0]]})
for a,b in combinations(range(16,28),2):expected.append({'pair':len(expected),'owners':[a,b],'kind':'cog_cog','templates':[t['template'] for t in templates if t['b_family']=='cog']})
assert load(BASE/'owner-pairs.json')==expected and len(expected)==258 and sum(len(p['templates']) for p in expected)==2568
assert {(templates[i]['a_mode'],templates[i]['b_mode']) for i in expected[-1]['templates']}=={(0,0),(0,1),(1,0),(1,1)}
summary=load(BASE/'checks.json');prep=load(PROCESS/'prepare.json');assert prep['passed'] and prep['job']['closed'] and prep['job']['active_processes']==0 and prep['complete_seconds']<20
assert summary['finite_owner_modes']==120 and summary['certified_regions']==regions_checked and summary['exact_source_supports']==proofs_checked and summary['minimum_certified_source_gap_mm']==minimum_certified and summary['seconds_including_evidence_serialization']<15
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',JOB,PIECES]+list(BASE.glob('*.json'))+[PROCESS/n for n in ['opened.json','prepare.json','prepare-job.json','prepare-stdout.txt','prepare-stderr.txt']]+[FIRST/n for n in ['plan.json','fixed29.json','short9-source.json']]+[I/n for n in ['family-modes.json','inventory.json']]
inputs += [ROOT/'output/audit_h5_two_phase_cog_geometry_20261107.py',ROOT/'output/h5-two-phase-cog-geometry-process-20261107/audit-stderr.txt',ROOT/'output/h5-two-phase-boundary-controls-20261107/plan.json',ROOT/'output/h5-two-phase-boundary-controls-20261107/controls.json',ROOT/'output/h5-two-phase-boundary-controls-20261107/checks.json',ROOT/'output/h5-two-phase-audit-correction-20261107.json']+list(OUT.glob('*.json'))
queue=inputs.copy();seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    obj=load(p)
    if not isinstance(obj,dict):continue
    for name,h in {**obj.get('inputs',{}),**obj.get('preserved_inputs',{})}.items():
        z=ROOT/name;assert digest(z)==h;bindings[name]=h
        if z.name in ['plan.json','opened.json'] or z.name.endswith('process.json'):queue.append(z)
write(OUT/'source-bindings.json',bindings)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently prove original convex-piece partitions by exact signed boundary-segment cancellation and exact area. Reconstruct every affine source mode/outer/cutout and grid-bound neighbour, every original shape in56corner and28ordered-pair controls, and all28 signed pair domains. Replay every rational support inequality and require complete original convex-piece pair coverage for every region. Verify258 owner-pair mappings with2568 mode couplings,including all four ordered cog-phase combinations. Preserve and replay all four exact stock-corner membership failures caused by at most4.55e-14mm inward domain rounding. Independently check28 new original-pair controls shifted0.01mm inward per owner and prove exact membership0.02mm inside the relative domain. No source region or source gap is changed. No approximate symmetry/alias reuse,no global free-space completeness claim,no solver or full66 layout claim.'})
result={'passed':True,'seconds':time.perf_counter()-started,'source_bindings':len(bindings),'exact_source_partitions':3,'source_mode_geometries':14,'finite_owner_modes':120,'mode_corner_controls':56,'ordered_pair_positive_controls':pair_controls,'interior_exact_membership_controls':28,'preserved_original_corner_membership_failures':4,**counts,'minimum_source_gap_mm':minimum_pair,'minimum_stock_margin_mm':minimum_stock,'ordered_templates':28,'source_regions':regions_checked,'exact_supports_verified':proofs_checked,'minimum_certified_source_gap_mm':minimum_certified,'pair_interactions':258,'expanded_pair_mode_couplings':2568,'complete_preparation_seconds':prep['complete_seconds'],'optimizer_calls':0,'global_coverage_claimed':False,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
