"""Prepare the remaining first sheet after the independently valid short11."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from collections import Counter
from copy import deepcopy
from itertools import combinations, product
import json, math, shutil, time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
from h5_legacy64_source_readback import audit

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output/h5-first55-after-source-valid11-20261029'
MODES = ROOT / 'output/h5-short11-all-modes-preflight-20261029'
CP = ROOT / 'output/h5-short11-integer-mode-regions-20261029'
JOB = ROOT / 'output/h5-coordinated-placement-selection-20261018/job.json'
OLD = ROOT / 'output/h5-oblique64-source-20261028/source64.json'
STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')

assert load(CP / 'source-audit/checks.json')['passed']
assert digest(OLD) == 'bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'prepare.py')
started = time.perf_counter()
job, source64, short = load(JOB), load(OLD), load(CP / 'search/source-response/candidate-source11.json')
parts = {p['id']: p for p in job['parts']}
spec = load(STOCK)
stocks = {'sheet-0': [6.5, 6.5, 1493.5, 2993.5], 'sheet-1': spec['source_stock']}
def shape(row):
    t = row['transform']; c, s = math.cos(t['rotation_radians']), math.sin(t['rotation_radians'])
    m = -1 if t['mirrored'] else 1
    return affine_transform(Polygon(parts[row['part_id']]['geometry'][0]['outer']), [m*c, -s, m*s, c, *t['translation']])
frames = [deepcopy(r) for r in source64 if r['sheet_id'] == 'sheet-0' and r['part_id'] == 'frame']
frame_top = max(shape(r).bounds[3] for r in frames)
side = [deepcopy(r) for r in source64 if r['sheet_id'] == 'sheet-0' and r['part_id'] == 'insert' and shape(r).bounds[3] <= frame_top]
side.sort(key=lambda r: r['copy_index'])
assert len(frames) == 18 and len(side) == 11
inventory = load(MODES / 'inventory.json')
first_ids = [tuple(k) for k in inventory['mandatory_first55_identities']]
insert_ids = sorted(k[1] for k in first_ids if k[0] == 'insert')
relabels = []
for row, idx in zip(side, insert_ids):
    relabels.append({'source_copy_index': row['copy_index'], 'first55_copy_index': idx, 'transform': deepcopy(row['transform'])})
    row['copy_index'] = idx
fixed = frames + side
fixed_ids = {(r['part_id'], r['copy_index']) for r in fixed}
mover_ids = sorted(set(first_ids) - fixed_ids)
assert Counter(k[0] for k in mover_ids) == {'bracket': 7, 'insert': 6, 'cog': 13}
all_ids = {(p['id'], i) for p in job['parts'] for i in range(p['quantity'])}
short_ids = {(r['part_id'], r['copy_index']) for r in short}
assert not (set(first_ids) & short_ids) and set(first_ids) | short_ids == all_ids
assert max(shape(r).bounds[3] for r in fixed) == frame_top
fixed_check = audit(job, fixed, stocks, spec['required_pair_gap_mm'], spec['stock_guard_mm'], expected=list(fixed_ids))
partial_check = audit(job, fixed+short, stocks, spec['required_pair_gap_mm'], spec['stock_guard_mm'], expected=list(fixed_ids|short_ids))
assert fixed_check['valid'] and partial_check['valid']
construction_stock = [6.5, frame_top+.2, 1493.5, 2993.5]
family_modes, library = load(MODES / 'family-modes.json'), load(MODES / 'geometry-library.json')
for family, modes in family_modes.items():
    for mode in modes:
        w, h = library[mode['normalized_geometry']]['dimensions']
        mode['lower_left_bounds'] = [[construction_stock[0]+.025, construction_stock[2]-.025-w], [construction_stock[1]+.025, construction_stock[3]-.025-h]]
        assert all(lo <= hi for lo, hi in mode['lower_left_bounds'])
instances = [{'identity': k, 'mode_count': len(family_modes[k[0]])} for k in mover_ids]
options = [sorted({m['normalized_geometry'] for m in family_modes[k[0]]}) for k in mover_ids]
needed = set(); expanded = 0
for a, b in combinations(options, 2):
    keys = list(product(a, b)); needed.update(keys); expanded += len(keys)
for name, value in [('fixed29.json', fixed), ('fixed29-source-checks.json', fixed_check), ('partial40.json', fixed+short), ('partial40-source-checks.json', partial_check), ('insert-identity-relabels.json', relabels), ('family-modes.json', family_modes), ('geometry-library.json', library), ('instances.json', instances), ('inventory.json', {'fixed29_identities': sorted(fixed_ids), 'moving26_identities': mover_ids, 'mandatory_first55_identities': first_ids, 'valid_short11_identities': sorted(short_ids), 'full66_identities': sorted(all_ids)})]:
    write(OUT / name, value)
inputs = [Path(__file__), ROOT/'output/h5_legacy64_source_readback.py', JOB, OLD, STOCK, MODES/'inventory.json', MODES/'family-modes.json', MODES/'geometry-library.json', MODES/'audit/plan.json', MODES/'audit/checks.json', CP/'search/source-response/candidate-source11.json', CP/'source-audit/plan.json', CP/'source-audit/checks.json', CP/'response-audit/plan.json', CP/'response-audit/checks.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}, 'method': 'Retain 18 original frames and eleven side inserts from valid64, relabelling identical insert copies to the mandatory first55 identities. Keep the new independently source-valid eleven-part short sheet. Move the remaining seven brackets, six inserts and thirteen cogs together in the first-sheet bottom strip. All bracket quarter-turn/mirror and insert quarter-turn modes remain available; cogs retain a declared 7-degree phase. Regenerate and independently audit all pair-region templates for the taller stock domain, then prepare and audit integer inequalities and a complete 26-mover model before declaring one bounded search. This is a restricted construction and cannot prove global infeasibility. Preserve the earlier closed calls and valid64.', 'source_stocks': stocks, 'construction_stock': construction_stock, 'fixed_original_max_y': frame_top, 'fixed_to_mover_y_separation_mm': construction_stock[1]+.025-frame_top, 'moving_stock_extra_mm': .025, 'required_pair_gap_mm': spec['required_pair_gap_mm'], 'stock_guard_mm': spec['stock_guard_mm'], 'grid_units_per_mm': 1000, 'integer_normal_error_envelope_mm': [1500, 900], 'future_algorithm_seconds': 60, 'future_shared_seconds': 90, 'future_maximum_calls': 1, 'retry_permitted': False, 'new_model_created': False, 'search_opened': False})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'fixed_originals': 29, 'valid_partial_originals': 40, 'first_originals': 55, 'moving_originals': 26, 'moving_family_counts': dict(Counter(k[0] for k in mover_ids)), 'instance_mode_options': sum(r['mode_count'] for r in instances), 'original_moving_pairs': 325, 'cached_geometry_pair_templates_needed': len(needed), 'expanded_geometry_pair_cases': expanded, 'source_valid_short11_preserved': True, 'source_valid64_preserved': True, 'independent_preflight_audit_pending': True, 'first55_constructed': False, 'source_valid66': False, 'new_model_created': False, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
