"""Prepare cached relative free regions for every allowed filled-geometry pair."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations, product
import json, math, shutil, time
import numpy as np
import shapely
from shapely.geometry import Polygon, MultiPoint, box, mapping
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import merge_exact

ROOT = Path(__file__).resolve().parents[1]
MODES = ROOT / 'output/h5-first55-after-source-valid11-20261029'
STOCK = MODES / 'plan.json'
OUT = MODES / 'pair-region-preflight'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

assert load(MODES / 'audit/checks.json')['passed']
OUT.mkdir()
shutil.copyfile(__file__, OUT / 'prepare.py')
started = time.perf_counter()
library, family_modes, instances = [load(MODES / n) for n in ['geometry-library.json', 'family-modes.json', 'instances.json']]
stock = load(STOCK)['construction_stock']
geometry_bounds = {g['id']: [[stock[0]+.025, stock[2]-.025-g['dimensions'][0]], [stock[1]+.025, stock[3]-.025-g['dimensions'][1]]] for g in library}
options = [sorted({m['normalized_geometry'] for m in family_modes[row['identity'][0]]}) for row in instances]
owner_pairs = []
needed = set()
for ia, ib in combinations(range(26), 2):
    keys = list(product(options[ia], options[ib]))
    needed.update(keys)
    owner_pairs.append({'owners': [ia, ib], 'identities': [instances[ia]['identity'], instances[ib]['identity']], 'geometry_pairs': [list(k) for k in keys]})
assert len(owner_pairs) == 325 and len(needed) == 95
templates, obstacles = [], []
radius = .226/math.cos(math.pi/32)
for ga, gb in sorted(needed):
    a, b = library[ga], library[gb]
    A, B = geometry_bounds[ga], geometry_bounds[gb]
    domain = [B[0][0]-A[0][1], B[1][0]-A[1][1], B[0][1]-A[0][0], B[1][1]-A[1][0]]
    piece_obstacles = []
    for av in a['pieces']:
        for bv in b['pieces']:
            points = (np.asarray(av)[:, None, :]-np.asarray(bv)[None, :, :]).reshape(-1, 2)
            piece_obstacles.append(MultiPoint(points).convex_hull)
    raw = unary_union(piece_obstacles)
    inflated = raw.buffer(radius, quad_segs=8)
    free = box(*domain).difference(inflated)
    assert raw.is_valid and inflated.is_valid and free.is_valid and not free.is_empty
    triangles = list(shapely.constrained_delaunay_triangles(free).geoms)
    assert triangles and all(len(p.exterior.coords) == 4 and p.area > 0 for p in triangles)
    triangulated = unary_union(triangles)
    assert triangulated.symmetric_difference(free).area < 1e-7
    regions, merges = merge_exact(triangles)
    combined = unary_union([Polygon(p) for p in regions])
    error = combined.symmetric_difference(free).area
    assert error < 1e-7 and len(regions)+merges == len(triangles)
    templates.append({'geometries': [ga, gb], 'relative_variable': 'lower_left_b_minus_lower_left_a',
                      'domain': domain, 'piece_pairs': len(piece_obstacles), 'regions': regions,
                      'initial_triangles': len(triangles), 'exact_convex_merges': merges,
                      'free_space_coverage_error_mm2': error})
    obstacles.append({'geometries': [ga, gb], 'raw_obstacle': mapping(raw), 'inflated_obstacle': mapping(inflated), 'bounded_free_region': mapping(free)})
    assert time.perf_counter()-started < 30, 'Preparation cap reached; no solver may be opened.'
template_lookup = {tuple(t['geometries']): i for i, t in enumerate(templates)}
for group in owner_pairs:
    group['template_indices'] = [template_lookup[tuple(k)] for k in group['geometry_pairs']]
write(OUT / 'templates.json', templates)
write(OUT / 'obstacles.json', obstacles)
write(OUT / 'owner-pairs.json', owner_pairs)
write(OUT / 'geometry-stock-bounds.json', geometry_bounds)
elapsed = time.perf_counter()-started
inputs = [Path(__file__), ROOT / 'output/h5_exact_convex_partition_tools_20261029.py', STOCK,
          MODES / 'plan.json', MODES / 'checks.json', MODES / 'audit/plan.json', MODES / 'audit/checks.json',
          MODES / 'family-modes.json', MODES / 'geometry-library.json', MODES / 'instances.json', MODES / 'inventory.json']
write(OUT / 'plan.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
    'method': 'Cache all 95 ordered filled-geometry pair templates needed by the 325 moving-original pairs. All 93 legal source-mode options remain available; equivalent filled insert geometry shares a template without merging source transforms. Each template covers its mode-specific relative stock rectangle minus the conservatively inflated original-source Minkowski obstacle. Exact-area convex merges follow constrained triangulation. Independently certify every region after nine-decimal vertex rounding and every owner/mode/template mapping before any full variable-orientation model. Float free-space construction and fixed 7-degree cog phases restrict negative conclusions.',
    'buffer_target_mm': .226, 'buffer_radius_mm': radius, 'buffer_quad_segs': 8,
    'required_region_gap_mm': .225, 'geometry_preparation_cap_seconds': 30, 'new_model_created': False, 'solver_calls': 0,
})
checks = {'passed': True, 'seconds': elapsed, 'original_pair_groups': 55, 'cached_geometry_pair_templates': len(templates),
          'expanded_original_pair_geometry_combinations': sum(len(g['template_indices']) for g in owner_pairs),
          'cached_regions': sum(len(t['regions']) for t in templates),
          'expanded_region_choices': sum(len(templates[i]['regions']) for g in owner_pairs for i in g['template_indices']),
          'cached_original_piece_pairs': sum(t['piece_pairs'] for t in templates),
          'independent_region_and_mapping_audit_pending': True, 'new_model_created': False,
          'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
