"""Compact source-safe pair regions using square inflation and convex exterior covers."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations, product
import json, math, shutil, time
import numpy as np
import shapely
from shapely.geometry import Polygon, MultiPoint, box, mapping
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import hull, merge_exact, area

ROOT=Path(__file__).resolve().parents[1]
MODES=ROOT/'output/h5-first55-after-source-valid11-20261029'
PRIOR=MODES/'pair-region-preflight'
OUT=MODES/'compact-pair-regions'
load=lambda p:json.loads(p.read_bytes()); digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def clip_exterior(domain,a,b):
    a,b=tuple(map(F,a)),tuple(map(F,b))
    def cross(p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
    x0,y0,x1,y1=map(F,domain); polygon=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)]; result=[]
    for p,q in zip(polygon,polygon[1:]+polygon[:1]):
        cp,cq=cross(p),cross(q)
        if cp<=0:result.append(p)
        if (cp<0 and cq>0) or (cp>0 and cq<0):
            t=cp/(cp-cq);result.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    result=hull(result)
    return [[float(x),float(y)] for x,y in result] if len(result)>=3 and area(result)>0 else None
assert load(PRIOR/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
library,modes,instances=[load(MODES/n) for n in ['geometry-library.json','family-modes.json','instances.json']]
stock=load(MODES/'plan.json')['construction_stock']
bounds={g['id']:[[stock[0]+.025,stock[2]-.025-g['dimensions'][0]],[stock[1]+.025,stock[3]-.025-g['dimensions'][1]]] for g in library}
families={m['normalized_geometry']:family for family,items in modes.items() for m in items}
options=[sorted({m['normalized_geometry'] for m in modes[row['identity'][0]]}) for row in instances]
needed=set();owner_pairs=[]
for ia,ib in combinations(range(26),2):
    keys=list(product(options[ia],options[ib]));needed.update(keys)
    owner_pairs.append({'owners':[ia,ib],'identities':[instances[ia]['identity'],instances[ib]['identity']],'geometry_pairs':[list(k) for k in keys]})
assert len(needed)==95
templates=[]; obstacles=[]
radius=.226; square=np.asarray([[-radius,-radius],[radius,-radius],[radius,radius],[-radius,radius]])
for ga,gb in sorted(needed):
    a,b=library[ga],library[gb]; A,B=bounds[ga],bounds[gb]
    domain=[B[0][0]-A[0][1],B[1][0]-A[1][1],B[0][1]-A[0][0],B[1][1]-A[1][0]]
    ordered=families[ga]==families[gb]
    if ordered:domain[0]=max(0.,domain[0])
    raw_parts=[];inflated_parts=[]
    for av in a['pieces']:
        for bv in b['pieces']:
            points=(np.asarray(av)[:,None,:]-np.asarray(bv)[None,:,:]).reshape(-1,2)
            raw_parts.append(MultiPoint(points).convex_hull)
            inflated_parts.append(MultiPoint((points[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
    raw=unary_union(raw_parts); inflated=unary_union(inflated_parts); envelope=inflated.convex_hull
    outer=hull([tuple(map(F,p)) for p in envelope.exterior.coords[:-1]])
    regions=[]; kinds=[]
    for pa,pb in zip(outer,outer[1:]+outer[:1]):
        region=clip_exterior(domain,pa,pb)
        if region is not None:regions.append(region);kinds.append('convex_exterior_halfplane')
    pockets=envelope.difference(inflated).intersection(box(*domain))
    triangles=[p for p in shapely.constrained_delaunay_triangles(pockets).geoms if p.area>0]
    merged,merges=merge_exact(triangles) if triangles else ([],0)
    regions.extend(merged);kinds.extend(['concave_pocket']*len(merged))
    free=box(*domain).difference(inflated);combined=unary_union([Polygon(p) for p in regions])
    error=combined.symmetric_difference(free).area
    assert raw.is_valid and inflated.is_valid and free.is_valid and regions and error<1e-6,(ga,gb,error)
    templates.append({'geometries':[ga,gb],'relative_variable':'lower_left_b_minus_lower_left_a','domain':domain,'same_family_x_order_applied':ordered,'piece_pairs':len(raw_parts),'regions':regions,'region_kinds':kinds,'exterior_cover_regions':kinds.count('convex_exterior_halfplane'),'pocket_triangles':len(triangles),'exact_pocket_merges':merges,'free_space_coverage_error_mm2':error})
    obstacles.append({'geometries':[ga,gb],'raw_obstacle':mapping(raw),'inflated_obstacle':mapping(inflated),'bounded_free_region':mapping(free)})
    assert time.perf_counter()-started<30
lookup={tuple(t['geometries']):i for i,t in enumerate(templates)}
for group in owner_pairs:group['template_indices']=[lookup[tuple(k)] for k in group['geometry_pairs']]
for name,value in [('templates.json',templates),('obstacles.json',obstacles),('owner-pairs.json',owner_pairs),('geometry-stock-bounds.json',bounds)]:write(OUT/name,value)
elapsed=time.perf_counter()-started
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py']+[MODES/n for n in ['plan.json','checks.json','family-modes.json','geometry-library.json','instances.json','inventory.json','audit/plan.json','audit/checks.json']]+[PRIOR/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'All26 moving originals and all93 source modes remain. Replace circular polygon inflation by the union of each convex source-pair Minkowski obstacle inflated with an axis-aligned square of halfwidth0.226mm. The square contains the radius0.226mm Euclidean disk. Cover the exterior of the inflated obstacle convex hull with overlapping convex clipped halfplanes; triangulate and exactly convex-merge only its concave pockets. For same-family pairs apply the already planned identical-copy X order by clipping relative X to nonnegative. Independently certify every rounded region against every original convex source-piece pair. These are conservative construction regions, not an allocation-infeasibility certificate. No solver is opened.','square_half_width_mm':radius,'required_region_gap_mm':.225,'regions_may_overlap':True,'same_family_order':'copy_index ascending implies lower_left_x nondecreasing','geometry_preparation_cap_seconds':30,'new_model_created':False,'solver_calls':0})
checks={'passed':True,'seconds':elapsed,'original_pair_groups':325,'cached_geometry_pair_templates':95,'expanded_original_pair_geometry_combinations':3038,'cached_regions':sum(len(t['regions']) for t in templates),'expanded_region_choices':sum(len(templates[i]['regions']) for g in owner_pairs for i in g['template_indices']),'cached_original_piece_pairs':sum(t['piece_pairs'] for t in templates),'maximum_float_free_space_coverage_error_mm2':max(t['free_space_coverage_error_mm2'] for t in templates),'independent_region_and_mapping_audit_pending':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks)
write(OUT/'prior-summary-correction.json',{'field':'original_pair_groups','preserved_prior_value':load(PRIOR/'checks.json')['original_pair_groups'],'correct_value':len(load(PRIOR/'owner-pairs.json')),'independent_prior_audit_value':load(PRIOR/'audit/checks.json')['original_owner_pairs_verified'],'explanation':'The first taller-domain preparation inherited a summary-only constant of55. Its actual owner-pair data and independent audit both contain325 pairs. Preserve the original summary and this explicit correction; no model or search used that summary field.'})
print(checks)
