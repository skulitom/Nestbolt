"""Prepare simultaneous13-of15 valid cog-site selection with all thirteen orthogonal movers."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations
from copy import deepcopy
from collections import Counter
import json, shutil, time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';BASE=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029';OUT=BASE/'cog-slot-selection-preflight'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OLD=ROOT/'output/h5-oblique64-source-20261028/source64.json';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'response-audit/checks.json')['passed'] and load(BASE/'reduced-response-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
job,spec,inventory=load(JOB),load(FIRST/'plan.json'),load(FIRST/'inventory.json');fixed=load(FIRST/'fixed29.json');short=load(SHORT)
sites=[deepcopy(r) for r in load(OLD) if r['part_id']=='cog' and r['sheet_id']=='sheet-0']
sites.sort(key=lambda r:(r['transform']['translation'][1],r['transform']['translation'][0]))
assert len(sites)==15 and {r['copy_index'] for r in sites}==set(range(15))
pool_check=audit(job,fixed+sites,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected=[(r['part_id'],r['copy_index']) for r in fixed+sites]);assert pool_check['valid']
required_cogs=sorted(k[1] for k in inventory['moving26_identities'] if k[0]=='cog');assert required_cogs==list(range(1,14))
movable=[k for k in inventory['moving26_identities'] if k[0]!='cog'];assert Counter(k[0] for k in movable)=={'bracket':7,'insert':6}
cases=[]
for index,chosen in enumerate(combinations(range(15),13)):
    rows=[]
    for slot,copy in zip(chosen,required_cogs):
        row=deepcopy(sites[slot]);row['copy_index']=copy;rows.append(row)
    keys={(r['part_id'],r['copy_index']) for r in fixed+rows+short}
    assert len(keys)==53 and not keys&set(map(tuple,movable)) and keys|set(map(tuple,movable))==set(map(tuple,inventory['full66_identities']))
    cases.append({'case':index,'selected_slots':chosen,'empty_slots':sorted(set(range(15))-set(chosen)),'cog_copy_indices_in_slot_order':required_cogs})
assert len(cases)==105
control=[]
for slot,copy in zip(cases[0]['selected_slots'],required_cogs):
    row=deepcopy(sites[slot]);row['copy_index']=copy;control.append(row)
control=fixed+control+short
control_check=audit(job,control,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected=[(r['part_id'],r['copy_index']) for r in control]);assert control_check['valid']
for name,value in [('source-cog-sites.json',sites),('all15-site-source-control.json',pool_check),('all105-site-subsets.json',cases),('partial53-control.json',control),('partial53-source-checks.json',control_check),('inventory.json',{'fixed29_identities':inventory['fixed29_identities'],'mandatory_first55_identities':inventory['mandatory_first55_identities'],'required_cog13_identities':[['cog',i] for i in required_cogs],'moving13_orthogonal_identities':movable,'valid_short11_identities':inventory['valid_short11_identities'],'full66_identities':inventory['full66_identities']})]:write(OUT/name,value)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,OLD,SHORT,FIRST/'plan.json',FIRST/'fixed29.json',FIRST/'inventory.json',FIRST/'family-modes.json',BASE/'response-audit/plan.json',BASE/'response-audit/checks.json',BASE/'reduced-response-audit/plan.json',BASE/'reduced-response-audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Replace thirteen continuous cog placements with fifteen optional already-source-valid sites from the preserved valid64 first sheet. Select exactly thirteen sites in one model, retaining all105 possible empty-site pairs. Keep all seven bracket and six insert identities and all80 legal orthogonal source-mode options. Every selected cog receives a required copy identity1..13 by deterministic selected-site order at source readback. Keep fixed29 and validshort11. Prepare owner-mode/cog-site source-safe regions guarded by site occupancy, and the complete orthogonal mover-pair constraints. Independently audit the simultaneous site-choice model before one bounded call. This is a restricted fixed-lattice construction, not a global infeasibility certificate or a retry of either closed continuous-cog call.','candidate_cog_sites':15,'required_occupied_sites':13,'site_subsets':105,'orthogonal_moving_originals':13,'legal_orthogonal_mode_options':80,'source_stocks':spec['source_stocks'],'required_pair_gap_mm':spec['required_pair_gap_mm'],'stock_guard_mm':spec['stock_guard_mm'],'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'retry_permitted':False,'new_model_created':False,'search_opened':False})
result={'passed':True,'seconds':time.perf_counter()-started,'candidate_cog_sites':15,'required_occupied_sites':13,'all105_site_subsets_preserve_full66_identities':True,'source_valid44_pool_control':True,'source_valid53_example_control':True,'example_control_pairs':control_check['same_sheet_pairs'],'example_control_cutouts':control_check['cutouts'],'example_control_hole_vertices':control_check['hole_vertices'],'orthogonal_movers':13,'orthogonal_source_mode_options':80,'independent_site_selection_audit_pending':True,'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
