"""Exact domain-bound certificates for redundant guarded region planes; no model changes."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, time
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029';OUT=BASE/'redundant-plane-preflight'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'model-audit-v2/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
modes=load(BASE/'family-modes.json'); templates=load(BASE/'integer-templates.json');pairs=load(BASE/'owner-pairs.json');geom={}
for family,items in modes.items():
    for m in items:
        key=m['normalized_geometry'];entry={'family':family,'integer_bounds':m['integer_lower_left_bounds']}
        if key in geom:assert geom[key]==entry
        geom[key]=entry
certificates=[];dropped=retained=0
for ti,template in enumerate(templates):
    ga,gb=template['geometries'];a,b=geom[ga],geom[gb]
    bounds=[[b['integer_bounds'][axis][0]-a['integer_bounds'][axis][1],b['integer_bounds'][axis][1]-a['integer_bounds'][axis][0]] for axis in [0,1]]
    same=a['family']==b['family']
    if same:bounds[0][0]=max(bounds[0][0],0)
    regions=[]
    for region in template['regions']:
        planes=[]
        for index,plane in enumerate(region['planes']):
            n=plane['coefficients'];maximum=sum(c*(bounds[k][1] if c>=0 else bounds[k][0]) for k,c in enumerate(n));redundant=maximum<=plane['upper']
            planes.append({'plane':index,'maximum_domain_activity':maximum,'upper':plane['upper'],'redundant':redundant})
            dropped+=int(redundant);retained+=int(not redundant)
        regions.append({'region':region['region'],'planes':planes})
    certificates.append({'template':ti,'geometries':[ga,gb],'integer_relative_domain':bounds,'same_family_x_order_used':same,'regions':regions})
expanded_dropped=expanded_kept=0
for group in pairs:
    for ti in group['template_indices']:
        for r in certificates[ti]['regions']:
            expanded_dropped+=sum(p['redundant'] for p in r['planes']);expanded_kept+=sum(not p['redundant'] for p in r['planes'])
assert expanded_dropped+expanded_kept==load(BASE/'model/checks.json')['conditional_integer_region_planes']
write(OUT/'certificates.json',certificates)
inputs=[Path(__file__),BASE/'plan.json',BASE/'family-modes.json',BASE/'integer-templates.json',BASE/'owner-pairs.json',BASE/'model/checks.json',BASE/'model/mapping.json',BASE/'model-audit-v2/plan.json',BASE/'model-audit-v2/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each selected geometry-pair region, both-owner mode marginals imply its exact integer stock domains. Identical-copy adjacent X-order constraints imply nonnegative relative X for all same-family pairs. Bound each integer plane over that rectangle using exact integer arithmetic. Only planes with maximum activity no greater than their saved upper bound may be omitted. Independently verify this implication and full retained model before a distinct reduced-constraint construction. Keep every mode and region selector; no geometric pruning, new model or search occurs in this preparation.'})
result={'passed':True,'seconds':time.perf_counter()-started,'cached_planes':dropped+retained,'cached_redundant_planes':dropped,'cached_retained_planes':retained,'expanded_planes':expanded_dropped+expanded_kept,'expanded_redundant_planes':expanded_dropped,'expanded_retained_planes':expanded_kept,'mode_options_preserved':93,'region_selectors_preserved':88690,'independent_implication_audit_pending':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
