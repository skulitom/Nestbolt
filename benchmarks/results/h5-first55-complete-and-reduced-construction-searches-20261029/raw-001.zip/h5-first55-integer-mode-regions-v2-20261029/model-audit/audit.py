"""Read every protobuf variable, guarded plane and source-mode coupling independently."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations
import json, shutil, time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'output/h5-first55-integer-mode-regions-v2-20261029'
MODEL = BASE / 'model'
OUT = BASE / 'model-audit'
PRIOR = ROOT / 'output/h5-first55-after-source-valid11-20261029'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
MIN = -9223372036854775808

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
for folder in [BASE, MODEL, BASE / 'geometry-audit']:
    for name, expected in load(folder / 'plan.json')['inputs'].items():
        assert digest(ROOT / name) == expected, name
assert load(BASE / 'geometry-audit/checks.json')['passed'] and load(PRIOR / 'audit/checks.json')['passed']
p = cp_model_pb2.CpModelProto()
p.ParseFromString((MODEL / 'model.pb').read_bytes())
text_copy = text_format.Parse((MODEL / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
assert p == text_copy and {f.name for f, v in p.ListFields()} == {'variables', 'constraints'}
assert len(p.variables) == 88835 and len(p.constraints) == load(MODEL / 'checks.json')['constraints']
mapping = load(MODEL / 'mapping.json')
family_modes, instances, templates, owner_pairs = [load(BASE / n) for n in ['family-modes.json', 'instances.json', 'integer-templates.json', 'owner-pairs.json']]
owners, pairs = mapping['owners'], mapping['pairs']
assert mapping['position_units_per_mm'] == 1000 and len(owners) == len(instances) == 26
used_vars, used_constraints = set(), set()

def variable(index, name, domain):
    assert index not in used_vars
    used_vars.add(index)
    v = p.variables[index]
    assert v.name == name and list(v.domain) == domain
    assert {f.name for f, value in v.ListFields()} == {'name', 'domain'}

def linear(index, coefficients, lo, hi, guard=None):
    assert index not in used_constraints
    used_constraints.add(index)
    c = p.constraints[index]
    assert c.WhichOneof('constraint') == 'linear'
    assert list(c.enforcement_literal) == ([] if guard is None else [guard])
    assert {f.name for f, value in c.ListFields()} == {'linear'} | ({'enforcement_literal'} if guard is not None else set())
    expected = {i: v for i, v in coefficients.items() if v}
    assert dict(zip(c.linear.vars, c.linear.coeffs)) == expected and len(c.linear.vars) == len(expected)
    assert list(c.linear.domain) == [lo, hi]

mode_count = 0
for index, (owner, instance) in enumerate(zip(owners, instances)):
    assert owner['owner'] == index and owner['identity'] == instance['identity'] and owner['positions'] == [2*index, 2*index+1]
    modes = family_modes[instance['identity'][0]]
    for axis in [0, 1]:
        domain = [min(m['integer_lower_left_bounds'][axis][0] for m in modes), max(m['integer_lower_left_bounds'][axis][1] for m in modes)]
        variable(2*index+axis, f'{"x" if axis == 0 else "y"}_{index}_um', domain)
    assert len(owner['modes']) == len(modes)
    for actual, expected in zip(owner['modes'], modes):
        assert {k: v for k, v in actual.items() if k not in ['selector', 'stock_constraints']} == expected
        selector = actual['selector']
        assert 52 <= selector < 145
        variable(selector, f'mode_{index}_{expected["mode"]}', [0, 1])
        assert len(actual['stock_constraints']) == 2
        for axis in [0, 1]:
            lo, hi = expected['integer_lower_left_bounds'][axis]
            linear(actual['stock_constraints'][axis], {2*index+axis: 1}, lo, hi, selector)
        mode_count += 1
    linear(owner['one_mode_constraint'], {m['selector']: 1 for m in owner['modes']}, 1, 1)

seen_pairs = set()
region_count = plane_count = marginal_count = 0
for actual, expected in zip(pairs, owner_pairs):
    ia, ib = actual['owners']
    assert actual['owners'] == expected['owners'] and (ia, ib) not in seen_pairs
    seen_pairs.add((ia, ib))
    expected_regions = [(ti, r['region']) for ti in expected['template_indices'] for r in templates[ti]['regions']]
    assert [(r['template'], r['region']) for r in actual['regions']] == expected_regions
    for region in actual['regions']:
        template = templates[region['template']]
        geometric_region = template['regions'][region['region']]
        assert region['geometries'] == template['geometries']
        selector = region['selector']
        assert 145 <= selector < 88835
        variable(selector, f'region_{ia}_{ib}_{region["template"]}_{region["region"]}', [0, 1])
        assert len(region['plane_constraints']) == len(geometric_region['planes'])
        for constraint, plane in zip(region['plane_constraints'], geometric_region['planes']):
            nx, ny = plane['coefficients']
            linear(constraint, {2*ia: -nx, 2*ia+1: -ny, 2*ib: nx, 2*ib+1: ny}, MIN, plane['upper'], selector)
            plane_count += 1
        region_count += 1
    linear(actual['one_region_constraint'], {r['selector']: 1 for r in actual['regions']}, 1, 1)
    expected_marginals = [(side, owner, geometry) for side, owner in enumerate([ia, ib]) for geometry in sorted({m['normalized_geometry'] for m in owners[owner]['modes']})]
    assert [(m['side'], m['owner'], m['geometry']) for m in actual['mode_marginals']] == expected_marginals
    for marginal in actual['mode_marginals']:
        side, owner, geometry = marginal['side'], marginal['owner'], marginal['geometry']
        ms = [m['selector'] for m in owners[owner]['modes'] if m['normalized_geometry'] == geometry]
        rs = [r['selector'] for r in actual['regions'] if r['geometries'][side] == geometry]
        assert marginal['mode_selectors'] == ms and marginal['region_selectors'] == rs and ms and rs
        linear(marginal['constraint'], {**{i: -1 for i in ms}, **{i: 1 for i in rs}}, 0, 0)
        marginal_count += 1
assert len(pairs) == len(owner_pairs) == 325 and seen_pairs == set(combinations(range(26), 2))
prior_symmetry = []
for family in ['bracket', 'insert', 'cog']:
    same = sorted((o for o in owners if o['identity'][0] == family), key=lambda o: o['identity'][1])
    prior_symmetry.extend([[family, [a['owner'], b['owner']]] for a, b in zip(same, same[1:])])
assert [[r['family'], r['owners']] for r in mapping['symmetry_constraints']] == prior_symmetry
for symmetry in mapping['symmetry_constraints']:
    a, b = symmetry['owners']
    assert owners[a]['identity'][0] == owners[b]['identity'][0] == symmetry['family']
    assert owners[a]['identity'][1] < owners[b]['identity'][1]
    linear(symmetry['constraint'], {2*a: 1, 2*b: -1}, MIN, 0)
assert used_vars == set(range(len(p.variables))) and used_constraints == set(range(len(p.constraints)))
assert mode_count == 93 and region_count == 88690 and plane_count == sum(len(templates[ti]['regions'][ri]['planes']) for group in owner_pairs for ti in group['template_indices'] for ri in range(len(templates[ti]['regions']))) and marginal_count == 2025
assert load(BASE / 'inventory.json') == load(PRIOR / 'inventory.json')
inputs = [Path(__file__), BASE / 'plan.json', BASE / 'family-modes.json', BASE / 'integer-templates.json', BASE / 'owner-pairs.json',
          BASE / 'instances.json', BASE / 'inventory.json', BASE / 'geometry-audit/plan.json', BASE / 'geometry-audit/checks.json',
          MODEL / 'plan.json', MODEL / 'checks.json', MODEL / 'model.pb', MODEL / 'model.pbtxt', MODEL / 'mapping.json',
          PRIOR / 'audit/plan.json', PRIOR / 'audit/checks.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'variables_verified': len(used_vars), 'constraints_verified': len(used_constraints),
          'source_mode_selectors_verified': mode_count, 'region_selectors_verified': region_count,
          'exact_guarded_region_planes_verified': plane_count, 'guarded_mode_stock_domains_verified': 186,
          'both_owner_mode_marginals_verified': marginal_count, 'identical_copy_order_constraints_verified': 23,
          'all26_moving_and29_fixed_and11_short_identities_preserved': True, 'all_model_fields_exhaustively_verified': True,
          'binary_and_text_models_identical': True, 'continuous_weights': 0, 'deactivation_constants': 0,
          'model_sha256': digest(MODEL / 'model.pb'), 'mapping_sha256': digest(MODEL / 'mapping.json'),
          'negative_result_cannot_exclude_allocation': True, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
