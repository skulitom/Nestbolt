"""Teach the independent reader OR-Tools' empty-clause encoding of constant false."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029'
source=(ROOT/'output/audit_h5_first55_integer_model_v2_20261029.py').read_text(encoding='utf-8')
old="c = p.constraints[index]\n    assert c.WhichOneof('constraint') == 'linear'"
new="c = p.constraints[index]\n    expected_nonzero = {i: v for i, v in coefficients.items() if v}\n    if not expected_nonzero and not lo <= 0 <= hi:\n        assert c.WhichOneof('constraint') == 'bool_or' and not c.bool_or.literals\n        assert list(c.enforcement_literal) == ([] if guard is None else [guard])\n        assert {f.name for f, value in c.ListFields()} == {'bool_or'} | ({'enforcement_literal'} if guard is not None else set())\n        return\n    assert c.WhichOneof('constraint') == 'linear'"
assert old in source;source=source.replace(old,new).replace("OUT = BASE / 'model-audit'","OUT = BASE / 'model-audit-v2'")
p=ROOT/'output/audit_h5_first55_integer_model_v3_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
record={'initial_audit_passed':False,'model_changed':False,'reason':'The initial reader expected every conditional integer plane to serialize as linear. OR-Tools represents the declared impossible0<=-1 condition as an empty bool_or clause enforced by the region selector. The corrected reader explicitly verifies this equivalent constant-false encoding and all of its fields.','initial_runner_started_solver':False,'initial_runner_created_search_directory':False,'initial_runner_guard':'Missing model-audit/checks.json stopped the attempted runner before creating a search directory.','new_audit_folder':'model-audit-v2','solver_calls':0}
assert not (BASE/'search').exists()
with (BASE/'model-audit-correction.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(record)
