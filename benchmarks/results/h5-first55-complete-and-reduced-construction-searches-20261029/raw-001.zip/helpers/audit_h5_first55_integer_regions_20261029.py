"""Prove inward grid domains and exact implication of each integer halfplane."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from fractions import Fraction as F
import json, math, shutil, time

ROOT = Path(__file__).resolve().parents[1]
MODES = ROOT / 'output/h5-first55-after-source-valid11-20261029'
REGIONS = MODES / 'compact-pair-regions-v2'
BASE = ROOT / 'output/h5-first55-integer-mode-regions-20261029'
OUT = BASE / 'geometry-audit'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def cross(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

OUT.mkdir()
shutil.copyfile(__file__, OUT / 'audit.py')
started = time.perf_counter()
for name, expected in load(BASE / 'plan.json')['inputs'].items():
    assert digest(ROOT / name) == expected, name
assert load(REGIONS / 'audit/checks.json')['passed'] and load(MODES / 'audit/checks.json')['passed']
original_modes = load(MODES / 'family-modes.json')
integer_modes = load(BASE / 'family-modes.json')
grid = load(BASE / 'plan.json')['position_units_per_mm']
scale = load(BASE / 'plan.json')['normal_coefficient_scale']
assert grid == 1000 and scale == 1_000_000_000
mode_count = 0
all_domains = []
for family, modes in original_modes.items():
    assert len(integer_modes[family]) == len(modes)
    for original, converted in zip(modes, integer_modes[family]):
        assert {k: v for k, v in converted.items() if k != 'integer_lower_left_bounds'} == original
        for actual, (lo, hi) in zip(converted['integer_lower_left_bounds'], original['lower_left_bounds']):
            assert actual == [math.ceil(F(lo)*grid), math.floor(F(hi)*grid)]
            assert F(actual[0], grid) >= F(lo) and F(actual[1], grid) <= F(hi) and actual[0] < actual[1]
        all_domains.append(converted['integer_lower_left_bounds'])
        mode_count += 1
assert max(d[0][1] for d in all_domains)-min(d[0][0] for d in all_domains) < 1500*grid
assert max(d[1][1] for d in all_domains)-min(d[1][0] for d in all_domains) < 900*grid
templates, originals = load(BASE / 'integer-templates.json'), load(REGIONS / 'templates.json')
assert len(templates) == len(originals) == 95
regions = planes = 0
minimum_inset = None
maximum_activity = 0
for converted, original in zip(templates, originals):
    assert converted['geometries'] == original['geometries'] and len(converted['regions']) == len(original['regions'])
    for index, (record, vertices) in enumerate(zip(converted['regions'], original['regions'])):
        assert record['region'] == index
        points = [tuple(F(round(v, 9)) for v in p) for p in vertices]
        polygon = [tuple(map(F, p)) for p in record['hull_vertices']]
        assert len(polygon) >= 3 and len(record['planes']) == len(polygon)
        assert set(polygon) <= set(points)
        assert all(cross(a, b, c) > 0 for a, b, c in zip(polygon, polygon[1:]+polygon[:1], polygon[2:]+polygon[:2]))
        assert all(cross(a, b, p) >= 0 for a, b in zip(polygon, polygon[1:]+polygon[:1]) for p in points)
        for edge, (a, b, plane) in enumerate(zip(polygon, polygon[1:]+polygon[:1], record['planes'])):
            assert plane['edge'] == edge
            dx, dy = b[0]-a[0], b[1]-a[1]
            length = F(math.hypot(float(dx), float(dy)))
            exact = [dy/length, -dx/length]
            raw = [round(v*scale) for v in exact]
            divisor = math.gcd(abs(raw[0]), abs(raw[1]))
            assert plane['unreduced_coefficients'] == raw and plane['divisor'] == divisor > 0
            assert plane['coefficients'] == [v//divisor for v in raw]
            error = abs(exact[0]-F(raw[0], scale))*1500 + abs(exact[1]-F(raw[1], scale))*900
            assert F(plane['rounding_error_bound_mm']) == error
            rhs = exact[0]*a[0]+exact[1]*a[1]
            assert plane['upper'] == math.floor((rhs-error-F('1e-7'))*scale*grid/divisor)
            inset = rhs-F(plane['upper']*divisor, scale*grid)-error
            assert inset >= F('1e-7')
            minimum_inset = inset if minimum_inset is None else min(minimum_inset, inset)
            activity = sum(abs(c)*1_500_000 for c in plane['coefficients'])
            assert activity < 2**62 and abs(plane['upper']) < 2**62
            maximum_activity = max(maximum_activity, activity)
            planes += 1
        regions += 1
assert regions == sum(len(t['regions']) for t in originals) and planes == sum(len(r['hull_vertices']) for t in templates for r in t['regions']) and mode_count == 13
assert load(BASE / 'owner-pairs.json') == load(REGIONS / 'owner-pairs.json')
assert load(BASE / 'instances.json') == load(MODES / 'instances.json')
assert load(BASE / 'inventory.json') == load(MODES / 'inventory.json')
inputs = [Path(__file__), BASE / 'plan.json', BASE / 'checks.json', BASE / 'family-modes.json', BASE / 'integer-templates.json',
          BASE / 'owner-pairs.json', BASE / 'instances.json', BASE / 'inventory.json', MODES / 'family-modes.json',
          MODES / 'audit/plan.json', MODES / 'audit/checks.json', REGIONS / 'templates.json',
          REGIONS / 'audit/plan.json', REGIONS / 'audit/checks.json']
write(OUT / 'plan.json', {'utc': datetime.now(timezone.utc).isoformat(), 'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs}})
checks = {'passed': True, 'seconds': time.perf_counter()-started, 'source_mode_domains_rounded_inward': mode_count,
          'exact_region_hulls_verified': regions, 'exact_integer_plane_implications_verified': planes,
          'minimum_inset_after_all_rounding_mm': float(minimum_inset), 'maximum_integer_activity_bound': maximum_activity,
          'all_activities_within_int64': True, 'complete_owner_mode_template_mapping_preserved': True,
          'position_units_per_mm': grid, 'negative_result_restricted_to_grid_and_declared_geometry': True,
          'new_model_created': False, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT / 'checks.json', checks)
print(checks)
