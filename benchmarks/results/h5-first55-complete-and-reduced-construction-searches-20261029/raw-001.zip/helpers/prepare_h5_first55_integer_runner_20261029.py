from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/'output/run_h5_integer_mode_regions_20261029.py').read_text(encoding='utf-8')
changes=[('output/h5-short11-integer-mode-regions-20261029','output/h5-first55-integer-mode-regions-v2-20261029'),('check_h5_integer_mode_candidate_20261029.py','check_h5_first55_integer_candidate_20261029.py'),('60-(time.perf_counter()-started)-3','60-(time.perf_counter()-started)-4'),("'source_validation_reserve_seconds': 3","'source_validation_reserve_seconds': 4"),("'source_valid11'","'source_valid66'"),("'source_valid66': source_valid, 'source_valid66': False","'source_valid66': source_valid")]
for old,new in changes:
    assert old in text,old
    text=text.replace(old,new)
p=ROOT/'output/run_h5_first55_integer_regions_20261029.py';compile(text,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print({'prepared':p.name,'source_checker':'all66_originals','short11_shared_seconds_included_in_charge':True,'maximum_calls':1})
