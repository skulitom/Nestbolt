"""Derive separate taller-domain region helpers; preserve all closed short-sheet calls."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def derive(src,dst,replacements):
    text=(ROOT/'output'/src).read_text(encoding='utf-8')
    for old,new in replacements:
        assert old in text,(src,old)
        text=text.replace(old,new)
    path=ROOT/'output'/dst;compile(text,str(path),'exec')
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
common=[('output/h5-short11-all-modes-preflight-20261029','output/h5-first55-after-source-valid11-20261029'),("STOCK = ROOT / 'output/h5-short-two-cog-exchange-20261028/plan.json'","STOCK = MODES / 'plan.json'"),("load(STOCK)['source_stock']","load(STOCK)['construction_stock']"),('range(11)','range(26)')]
derive('prepare_h5_all_mode_pair_regions_20261029.py','prepare_h5_first55_pair_regions_20261029.py',common+[
    ('len(owner_pairs) == 55','len(owner_pairs) == 325'),
    ('needed by the 55 original pairs. All 58 legal source-mode options','needed by the 325 moving-original pairs. All 93 legal source-mode options'),
])
derive('audit_h5_all_mode_pair_regions_20261029.py','audit_h5_first55_pair_regions_20261029.py',common+[
    ('expanded_cases == 1081','expanded_cases == 3038'),
    ('assert regions_checked == 666',"assert regions_checked == sum(len(t['regions']) for t in templates)"),
    ("'original_owner_pairs_verified': 55","'original_owner_pairs_verified': 325"),
])
print({'prepared':['prepare_h5_first55_pair_regions_20261029.py','audit_h5_first55_pair_regions_20261029.py'],'model_created':False,'solver_calls':0})
