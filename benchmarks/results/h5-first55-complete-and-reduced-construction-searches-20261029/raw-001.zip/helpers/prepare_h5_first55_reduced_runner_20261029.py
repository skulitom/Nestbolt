from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst,changes in [
    ('check_h5_first55_integer_candidate_20261029.py','check_h5_first55_reduced_candidate_20261029.py',[("SEARCH=BASE/'search'","SEARCH=BASE/'reduced-search'"),("BASE/'model/mapping.json'","BASE/'reduced-model/mapping.json'")]),
    ('run_h5_first55_integer_regions_v2_20261029.py','run_h5_first55_reduced_regions_20261029.py',[("MODEL = BASE / 'model'","MODEL = BASE / 'reduced-model'"),("OUT = BASE / 'search'","OUT = BASE / 'reduced-search'"),('model-audit-v2','reduced-model-audit'),('check_h5_first55_integer_candidate_20261029.py','check_h5_first55_reduced_candidate_20261029.py'),("'log_search_progress': True, 'log_to_stdout': False, 'ignore_subsolvers': ['fj']","'log_search_progress': True, 'log_to_stdout': False, 'ignore_subsolvers': ['fj'],\n                  'cp_model_presolve': False, 'linearization_level': 0")]),
]:
    text=(ROOT/'output'/src).read_text(encoding='utf-8')
    for old,new in changes:
        assert old in text,(src,old)
        text=text.replace(old,new)
    p=ROOT/'output'/dst;compile(text,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print({'prepared':2,'prior_call_closed':True,'reduced_model_audit_required':True,'presolve':False,'linearization_level':0,'maximum_calls':1})
