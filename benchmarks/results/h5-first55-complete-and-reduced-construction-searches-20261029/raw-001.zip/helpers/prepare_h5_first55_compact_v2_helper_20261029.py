"""Preserve the failed floating-overlay diagnostic and generate a corrected preparation."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/prepare_h5_first55_compact_regions_20261029.py').read_text(encoding='utf-8')
replacements=[("OUT=MODES/'compact-pair-regions'","OUT=MODES/'compact-pair-regions-v2'"),
    ("error=combined.symmetric_difference(free).area\n    assert raw.is_valid and inflated.is_valid and free.is_valid and regions and error<1e-6,(ga,gb,error)","error=combined.symmetric_difference(free).area\n    snapped_combined=shapely.union_all([Polygon(p) for p in regions],grid_size=1e-8)\n    snapped_free=shapely.difference(box(*domain),inflated,grid_size=1e-8)\n    snapped_error=shapely.symmetric_difference(snapped_combined,snapped_free,grid_size=1e-8).area\n    assert raw.is_valid and inflated.is_valid and free.is_valid and regions and snapped_error<1e-4,(ga,gb,error,snapped_error)"),
    ("'free_space_coverage_error_mm2':error}","'free_space_coverage_error_mm2':error,'snapped_coverage_diagnostic_error_mm2':snapped_error}"),
    ("'maximum_float_free_space_coverage_error_mm2':max(t['free_space_coverage_error_mm2'] for t in templates)","'maximum_float_free_space_coverage_error_mm2':max(t['free_space_coverage_error_mm2'] for t in templates),'maximum_snapped_coverage_diagnostic_error_mm2':max(t['snapped_coverage_diagnostic_error_mm2'] for t in templates)"),
    ("inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py']", "inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/prepare_h5_first55_compact_regions_20261029.py',ROOT/'output/diagnose_h5_first55_compact_coverage_20261029.py',MODES/'compact-pair-regions/failure-diagnostic.json']"),
    ('No solver is opened.', 'The initial preparation stopped because a floating union lost a 17500mm2 triangular pocket at a boundary mismatch of about7e-15mm; that failed helper and diagnostic remain preserved. Report raw and 1e-8mm-grid overlay diagnostics separately. Neither is a proof of coverage or safety; exact source support for every individual region is mandatory. No solver is opened.'),
]
for old,new in replacements:
    assert old in source,old
    source=source.replace(old,new)
p=ROOT/'output/prepare_h5_first55_compact_regions_v2_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'prepared':p.name,'failed_initial_preparation_preserved':True,'source_support_audit_required':True})
