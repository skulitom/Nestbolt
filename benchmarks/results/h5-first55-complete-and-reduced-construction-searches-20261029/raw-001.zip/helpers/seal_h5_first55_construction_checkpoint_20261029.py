"""Seal the complete first55 construction, reduced model, failures and site-selection preparation."""
from pathlib import Path
from datetime import datetime, timezone
import ast, json, shutil, subprocess, sys
from pack_h5_evidence_archive import pack, digest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
BASE=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029'
FAILED=ROOT/'output/h5-first55-integer-mode-regions-20261029'
SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
SYNC=ROOT/'output/h5-source-valid11-main-sync-20261029'
PUB=BASE/'publication';SLOTS=BASE/'cog-slot-selection-preflight'
NAME='h5-first55-complete-and-reduced-construction-searches-20261029'
OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,v):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(v)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD')
assert head=='f81a9ccde862a1eff5cc00a10328dcb5a798d5e0' and not git('diff','HEAD','--name-only')
for p in [FIRST/'pair-region-preflight/audit',FIRST/'compact-pair-regions-v2/audit',BASE/'geometry-audit',BASE/'model-audit-v2',BASE/'response-audit',BASE/'redundant-plane-preflight/audit',BASE/'reduced-model-audit',BASE/'reduced-response-audit']:
    assert load(p/'checks.json')['passed'],str(p)
responses=[load(BASE/n/'checks.json') for n in ['response-audit','reduced-response-audit']]
assert all(r['closed_solver_calls']==1 and r['solver_status']=='UNKNOWN' and r['assignments']==0 and r['overall_algorithm_shared_overruns_seconds']==0 for r in responses)
assert responses[0]['stopped_after_presolve'] and responses[0]['branches']==0
assert not responses[1]['stopped_after_presolve'] and responses[1]['branches']==89145
assert all(r['solve_slice_overrun_seconds']>0 and not r['infeasibility_proven'] and not r['any_allocation_excluded'] for r in responses)
assert load(SLOTS/'checks.json')['source_valid53_example_control'] and not load(SLOTS/'checks.json')['new_model_created']
assert load(SHORT/'source-audit/checks.json')['source_valid11']
assert digest(SHORT/'search/source-response/candidate-source11.json')=='8b7fa5f6ad765aab6fdba1a586c29d8cac2cce607ed1d7fcd0fb6938c4eeada0'
prior=load(ROOT/'benchmarks/results/h5-source-valid-eleven-and-first-sheet-preparation-20261029/publication-review.json')
production=source_digest();readmes={n:digest(ROOT/n) for n in prior['current_readmes']}
assert production==prior['production_digest'] and readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs']
assert load(PUB/'main.json')['commit']['sha']==ci['head_sha']==head and ci['id']==40819131061
assert len(jobs)==6 and all(j['status']!='completed' or j['conclusion']=='success' for j in jobs)
all6=all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['normal_atomic_fast_forward'] and receipt['prior_main_all6_pass']
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json'
assert sum(r['excluded_by'] is None for r in load(frontier))==440
assert digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(name,path):
    assert path.is_file() and '.claude' not in path.parts
    members[name]=path
    if path.name in ['plan.json','opened.json'] or path.suffix=='.py':queue.append(path)
for folder in [FIRST,BASE,FAILED,SYNC]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=sorted((ROOT/'output').glob('*h5_first55*20261029.py'))
helpers += [ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','h5_exact_convex_partition_tools_20261029.py','ccd1.py','prepare_h5_source_valid11_main_push_20261029.py','push_h5_source_valid11_checkpoint_20261029.py','verify_h5_first55_construction_archive_20261029.py',Path(__file__).name]]
for p in helpers:add('helpers/'+p.name,p)
while queue:
    path=queue.pop()
    if path in seen:continue
    seen.add(path)
    if path.name in ['plan.json','opened.json']:
        for name,h in load(path).get('inputs',{}).items():
            p=ROOT/name;assert p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts)
            assert digest(p)==h,name
            bindings[name]=h;add('source-inputs/'+name,p)
    elif path.suffix=='.py':
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    p=ROOT/folder/(module+'.py')
                    if p.is_file():add('imported-helpers/'+folder+'/'+p.name,p)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(FIRST/'pair-region-preflight/audit/checks.json','tall-region-audit.json'),(FIRST/'compact-pair-regions-v2/checks.json','compact-region-preparation.json'),(FIRST/'compact-pair-regions-v2/audit/checks.json','compact-region-audit.json'),(BASE/'geometry-audit/checks.json','integer-geometry-audit.json'),(BASE/'model-audit-v2/checks.json','complete-model-audit.json'),(BASE/'response-audit/checks.json','complete-response-audit.json'),(BASE/'redundant-plane-preflight/audit/checks.json','redundancy-implication-audit.json'),(BASE/'reduced-model-audit/checks.json','reduced-model-audit.json'),(BASE/'reduced-response-audit/checks.json','reduced-response-audit.json'),(BASE/'preparation-corrections.json','preparation-corrections.json'),(SLOTS/'checks.json','site-selection-preflight.json'),(SLOTS/'plan.json','next-step.json'),(SLOTS/'inventory.json','site-selection-inventory.json'),(SLOTS/'all105-site-subsets.json','all105-site-subsets.json'),(SLOTS/'partial53-source-checks.json','partial53-source-checks.json'),(SYNC/'receipt.json','prior-main-push-receipt.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40819131061,'main_all6_pass':all6,'successful_jobs_at_snapshot':sum(j['conclusion']=='success' for j in jobs),'normal_push_requires_all6_and_fresh_head_and_live_run_checks':True,'unchanged_frontier_path':frontier.relative_to(ROOT).as_posix(),'unchanged_frontier_sha256':digest(frontier),'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'closed_new_solver_calls':2,'both_solver_statuses':'UNKNOWN','complete_model_variables':88835,'complete_model_constraints':317577,'reduced_model_variables':88835,'reduced_model_constraints':172639,'proved_redundant_constraints_removed':144938,'complete_call_branches':0,'reduced_call_branches':89145,'source_assignments':0,'solve_slice_overruns_seconds':[r['solve_slice_overrun_seconds'] for r in responses],'overall_algorithm_shared_overruns_seconds':0,'source_valid_short11_preserved':True,'valid64_preserved':True,'source_valid_partial53_example':True,'next_candidate_cog_sites':15,'next_required_cog_sites':13,'next_site_subsets':105,'next_orthogonal_movers':13,'next_independent_preflight_audit_pending':True,'first55_constructed':False,'source_valid66_created':False,'new_allocation_exclusions':0,'remaining_candidates':440,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8')
old='Latest H5 evidence: [source-valid eleven-part short sheet and first-sheet preparation](../benchmarks/results/h5-source-valid-eleven-and-first-sheet-preparation-20261029.md).'
new=f'Latest H5 evidence: [complete and reduced first-sheet construction searches](../benchmarks/results/{NAME}.md).'
assert content.count(old)==1
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(content.replace(old,new,1))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'closed_calls':2,'source_valid66':False,'remaining_candidates':440,'completion_percent':60})
