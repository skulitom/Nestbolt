"""Prepare the normal main push after the previous main passed all six checks."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head.startswith('f81a9ccd')
source=(ROOT/'output/push_h5_relative_region_checkpoint_20261029.py').read_text(encoding='utf-8')
replacements=[("OUT=ROOT/'output/h5-relative-region-main-sync-20261029'","OUT=ROOT/'output/h5-source-valid11-main-sync-20261029'"),("OLD='8c434a2b54e7bd47a8acd341772a4496efbe0e87';NEW='407f91ed4d1e0b13f3c467800039d4ad2bcdfd5a'","OLD='407f91ed4d1e0b13f3c467800039d4ad2bcdfd5a';NEW='"+head+"'"),('40811474503','40814954855'),('benchmarks/results/h5-complete-pair-separation-and-relative-region-searches-20261029','benchmarks/results/h5-source-valid-eleven-and-first-sheet-preparation-20261029')]
for old,new in replacements:
    assert old in source,old
    source=source.replace(old,new)
p=ROOT/'output/push_h5_source_valid11_checkpoint_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'prepared':p.name,'head':head,'all6_prior_checks_required':True,'unchanged_remote_head_required':True,'normal_atomic_fast_forward_only':True})
