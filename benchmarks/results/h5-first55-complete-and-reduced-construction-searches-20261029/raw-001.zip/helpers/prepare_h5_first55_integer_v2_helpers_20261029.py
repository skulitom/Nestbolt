"""Preserve collapsed-region preparation failure; make such selectors explicitly impossible."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for stem in ['prepare_h5_first55_integer_regions','audit_h5_first55_integer_regions','build_h5_first55_integer_model','audit_h5_first55_integer_model']:
    text=(ROOT/'output'/(stem+'_20261029.py')).read_text(encoding='utf-8')
    text=text.replace('output/h5-first55-integer-mode-regions-20261029','output/h5-first55-integer-mode-regions-v2-20261029')
    if stem.startswith('prepare_'):
        old="assert len(polygon) >= 3\n        region = {'region': index, 'hull_vertices': [[str(x), str(y)] for x, y in polygon], 'planes': []}"
        new="region = {'region': index, 'hull_vertices': [[str(x), str(y)] for x, y in polygon], 'planes': []}\n        if len(polygon) < 3:\n            region['discarded_degenerate'] = True\n            region['planes'] = [{'edge': None, 'coefficients': [0, 0], 'upper': -1, 'unreduced_coefficients': [0, 0], 'divisor': 1, 'rounding_error_bound_mm': '0'}]\n            record['regions'].append(region)\n            plane_count += 1\n            continue"
        assert old in text;text=text.replace(old,new)
        text=text.replace('Source-mode domains round inward.','Source-mode domains round inward. Regions that collapse to fewer than three convex-hull vertices after nine-decimal rounding get the explicitly impossible guarded inequality0<=-1, so their source selectors cannot be chosen; other regions remain unchanged. The failed initial conversion is preserved.')
        text=text.replace("inputs = [Path(__file__),", "inputs = [Path(__file__), ROOT / 'output/prepare_h5_first55_integer_regions_20261029.py',")
        text=text.replace("'integer_halfplanes': plane_count,", "'integer_halfplanes': plane_count, 'disabled_degenerate_regions': sum(bool(r.get('discarded_degenerate')) for t in integer_templates for r in t['regions']),")
    elif stem=='audit_h5_first55_integer_regions':
        old="assert len(polygon) >= 3 and len(record['planes']) == len(polygon)"
        new="if len(polygon) < 3:\n            distinct = list(set(points))\n            assert len(distinct) <= 2 or all(cross(distinct[0], distinct[1], q) == 0 for q in distinct)\n            assert record.get('discarded_degenerate') and set(polygon) <= set(points)\n            assert record['planes'] == [{'edge': None, 'coefficients': [0, 0], 'upper': -1, 'unreduced_coefficients': [0, 0], 'divisor': 1, 'rounding_error_bound_mm': '0'}]\n            regions += 1\n            planes += 1\n            continue\n        assert not record.get('discarded_degenerate') and len(record['planes']) == len(polygon)"
        assert old in text;text=text.replace(old,new)
        text=text.replace("sum(len(r['hull_vertices']) for t in templates for r in t['regions'])", "sum(1 if r.get('discarded_degenerate') else len(r['hull_vertices']) for t in templates for r in t['regions'])")
        text=text.replace("'exact_integer_plane_implications_verified': planes,", "'exact_integer_plane_implications_verified': planes, 'impossible_degenerate_region_guards_verified': sum(bool(r.get('discarded_degenerate')) for t in templates for r in t['regions']),")
    p=ROOT/'output'/(stem+'_v2_20261029.py');compile(text,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print({'prepared_v2_helpers':4,'collapsed_regions_explicitly_disabled':True,'prior_failed_conversion_preserved':True,'solver_calls':0})
