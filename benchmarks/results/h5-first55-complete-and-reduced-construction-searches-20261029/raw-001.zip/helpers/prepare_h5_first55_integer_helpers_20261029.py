"""Prepare separate integer conversion, full model and independent audit helpers."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def derive(src,dst,replacements):
    text=(ROOT/'output'/src).read_text(encoding='utf-8')
    for old,new in replacements:
        assert old in text,(src,old)
        text=text.replace(old,new)
    p=ROOT/'output'/dst;compile(text,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
paths=[('output/h5-short11-all-modes-preflight-20261029','output/h5-first55-after-source-valid11-20261029'),("MODES / 'pair-region-preflight'","MODES / 'compact-pair-regions-v2'"),('output/h5-short11-integer-mode-regions-20261029','output/h5-first55-integer-mode-regions-20261029')]
derive('prepare_h5_integer_mode_regions_20261029.py','prepare_h5_first55_integer_regions_20261029.py',paths+[
    ("PRIOR = ROOT / 'output/h5-short11-all-mode-region-model-20261029'","PRIOR = ROOT / 'output/h5-short11-integer-mode-regions-20261029'"),
    ('*320','*900'),('[1500, 320]','[1500, 900]'),('all 58 legal source-mode options','all 93 legal source-mode options for the26 first-sheet movers'),
    ("'instance_mode_options': 58","'instance_mode_options': 93"),
    ("'source_validation_reserve_seconds': 3","'source_validation_reserve_seconds': 4"),
])
derive('audit_h5_integer_mode_regions_20261029.py','audit_h5_first55_integer_regions_20261029.py',paths+[
    ('< 320*grid','< 900*grid'),('*320','*900'),
    ('assert regions == 666 and planes == 2264 and mode_count == 13',"assert regions == sum(len(t['regions']) for t in originals) and planes == sum(len(r['hull_vertices']) for t in templates for r in t['regions']) and mode_count == 13"),
])
derive('build_h5_integer_mode_regions_20261029.py','build_h5_first55_integer_model_20261029.py',[
    ('output/h5-short11-integer-mode-regions-20261029','output/h5-first55-integer-mode-regions-20261029'),
    ("PRIOR = ROOT / 'output/h5-short11-all-mode-region-model-20261029'","PRIOR = ROOT / 'output/h5-first55-after-source-valid11-20261029'\nSHORT = ROOT / 'output/h5-short11-integer-mode-regions-20261029'"),
    ('len(model.proto.variables) == 80','len(model.proto.variables) == 145'),
    ('len(model.proto.variables) == 7634','len(model.proto.variables) == 88835'),
    ("charges = {'prior_source_mode_and_template_preparation_seconds': load(PRIOR / 'checks.json')['preparation_seconds_charged'],", "charges = {'source_valid_short11_shared_seconds': load(SHORT / 'response-audit/checks.json')['shared_seconds_including_preparation'],\n           'first_sheet_mode_preparation_seconds': load(PRIOR / 'checks.json')['seconds'],\n           'compact_pair_region_preparation_seconds': load(PRIOR / 'compact-pair-regions-v2/checks.json')['seconds'],"),
    ("inputs = [Path(__file__), PRIOR / 'checks.json',", "inputs = [Path(__file__), PRIOR / 'checks.json', PRIOR / 'compact-pair-regions-v2/checks.json', SHORT / 'response-audit/plan.json', SHORT / 'response-audit/checks.json',"),
    ("'source_mode_options': 58, 'region_selectors': 7554","'source_mode_options': 93, 'region_selectors': 88690"),
    ("'guarded_mode_stock_domains': 116, 'both_owner_mode_marginals': 500, 'identity_symmetry_constraints': 8","'guarded_mode_stock_domains': 186, 'both_owner_mode_marginals': 2025, 'identity_symmetry_constraints': 23"),
])
derive('audit_h5_integer_mode_region_model_20261029.py','audit_h5_first55_integer_model_20261029.py',[
    ('output/h5-short11-integer-mode-regions-20261029','output/h5-first55-integer-mode-regions-20261029'),
    ('output/h5-short11-all-mode-region-model-20261029','output/h5-first55-after-source-valid11-20261029'),
    ('len(p.variables) == 7634 and len(p.constraints) == 26264',"len(p.variables) == 88835 and len(p.constraints) == load(MODEL / 'checks.json')['constraints']"),
    ('len(owners) == len(instances) == 11','len(owners) == len(instances) == 26'),
    ('22 <= selector < 80','52 <= selector < 145'),('80 <= selector < 7634','145 <= selector < 88835'),
    ('== 55 and seen_pairs == set(combinations(range(11), 2))','== 325 and seen_pairs == set(combinations(range(26), 2))'),
    ("prior_symmetry = load(PRIOR / 'audit/symmetry-review.json')['ordered_adjacent_copy_pairs']", "prior_symmetry = []\nfor family in ['bracket', 'insert', 'cog']:\n    same = sorted((o for o in owners if o['identity'][0] == family), key=lambda o: o['identity'][1])\n    prior_symmetry.extend([[family, [a['owner'], b['owner']]] for a, b in zip(same, same[1:])])"),
    ('set(range(7634)) and used_constraints == set(range(26264))','set(range(len(p.variables))) and used_constraints == set(range(len(p.constraints)))'),
    ('mode_count == 58 and region_count == 7554 and plane_count == 25574 and marginal_count == 500',"mode_count == 93 and region_count == 88690 and plane_count == sum(len(templates[ti]['regions'][ri]['planes']) for group in owner_pairs for ti in group['template_indices'] for ri in range(len(templates[ti]['regions']))) and marginal_count == 2025"),
    (", PRIOR / 'audit/symmetry-review.json'",''),
    ("'guarded_mode_stock_domains_verified': 116","'guarded_mode_stock_domains_verified': 186"),
    ("'identical_copy_order_constraints_verified': 8","'identical_copy_order_constraints_verified': 23"),
    ("'all11_short_and55_first_identities_preserved'","'all26_moving_and29_fixed_and11_short_identities_preserved'"),
])
print({'prepared_integer_helpers':4,'whole_short11_shared_time_will_be_charged':True,'solver_calls':0})
