from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/audit_h5_first55_pair_regions_20261029.py').read_text(encoding='utf-8')
replacements=[("BASE = MODES / 'pair-region-preflight'","BASE = MODES / 'compact-pair-regions-v2'"),
    ("assert template['domain'] == expected_domain","same_family = instances[next(i for i, row in enumerate(instances) if any(m['normalized_geometry'] == ga for m in modes[row['identity'][0]]))]['identity'][0] == instances[next(i for i, row in enumerate(instances) if any(m['normalized_geometry'] == gb for m in modes[row['identity'][0]]))]['identity'][0]\n    if same_family:\n        expected_domain[0] = max(0., expected_domain[0])\n    assert template['same_family_x_order_applied'] == same_family\n    assert template['domain'] == expected_domain"),
    ("assert coverage < 1e-7 and abs(sum(p.area for p in polygons)-combined.area) < 1e-7","assert coverage == template['free_space_coverage_error_mm2']\n    snapped_combined = shapely.union_all(polygons, grid_size=1e-8)\n    from shapely.geometry import box\n    snapped_free = shapely.difference(box(*template['domain']), shape(obstacle_record['inflated_obstacle']), grid_size=1e-8)\n    snapped_error = shapely.symmetric_difference(snapped_combined, snapped_free, grid_size=1e-8).area\n    assert snapped_error == template['snapped_coverage_diagnostic_error_mm2'] and snapped_error < 1e-4"),
    ("'all_mode_specific_relative_stock_domains_verified': True,","'all_mode_specific_relative_stock_domains_verified': True,\n          'same_family_x_order_domains_verified': True, 'overlapping_regions_individually_certified': True,\n          'float_overlay_coverage_is_diagnostic_only': True, 'global_coverage_claimed': False,")]
for old,new in replacements:
    assert old in source,old
    source=source.replace(old,new)
p=ROOT/'output/audit_h5_first55_compact_regions_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'prepared':p.name,'individual_original_source_support_required':True})
