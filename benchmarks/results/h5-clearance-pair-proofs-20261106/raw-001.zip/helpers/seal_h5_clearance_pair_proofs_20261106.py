from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-clearance-pair-proofs-20261106';OUT=ROOT/'benchmarks/results'/NAME
EDGE=ROOT/'output/h5-first57-clearance-pair-edges-20261106';BASE=ROOT/'output/h5-first57-clearance-pair-trees-20261106'
SYNC=ROOT/'output/h5-clearance-domain-main-sync-20261106'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
ea=load(EDGE/'audit/checks.json');ta=load(BASE/'audit/checks.json')
assert ea['passed'] and ta['passed'] and ea['added_source_conflict_edges_verified']==22610
assert ta['new_fixed29_choices_excluded']==2 and ta['remaining_fixed29_choices']==26
assert ta['tree_records_verified']==15668 and ta['total_joint_graph_witnesses']==5 and len(ta['budget_limited_cases'])==21
excluded=[r['empty_sites'] for r in ta['choices'] if r['continuous_fixed29_choice_excluded']]
assert excluded==[[0,5,13],[5,9,10]]
assert load(SYNC/'receipt.json')['new_main']=='e758566041033f8203d1213dd664718a832b5465'
process_folders=[ROOT/'output'/f'h5-first57-{n}-process-20261106' for n in ['clearance-pair-edges','clearance-pair-trees']]
processes=[load(p/'process.json') for p in process_folders]
assert all(p['closed'] and p['exit_code']==0 and not p['timeout'] and p['complete_process_cap_overrun_seconds']==0 for p in processes)
assert ta['case_complete_cap_overrun_seconds']==ea['case_complete_cap_overrun_seconds']==0
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104','h5-source-polygons-and-joint-frontier-20261104','h5-mandatory-clique-exclusions-20261104','h5-full-frontier-proofs-20261106','h5-frontier-insert-exclusions-20261106','h5-deferred-conflict-tree-20261106','h5-optional-bracket-trees-20261106','h5-joint-optional-trees-20261106','h5-union-augmented-proofs-20261106','h5-source-cog-pruned-proofs-20261106','h5-clearance-domain-proofs-20261106']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for folder in [EDGE,BASE,SYNC]+process_folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for p in (ROOT/'output').glob('*h5_clearance_pair*20261106.py'):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'push_h5_clearance_domain_checkpoint_20261106.py','h5-clearance-pair-proofs-report-20261106.md']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(EDGE/'audit/checks.json','edge-audit.json'),(BASE/'audit/checks.json','tree-audit.json'),(BASE/'audit/remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(BASE/'audit/joint-graph-witnesses.json','joint-graph-witnesses.json'),(SYNC/'receipt.json','main-sync-receipt.json')]:
    shutil.copyfile(source,OUT/name)
write(OUT/'process-ledger.json',{'new_complete_preparation_seconds':sum(p['complete_process_seconds'] for p in processes),'processes':processes,
    'independent_audit_seconds':[ea['seconds'],ta['seconds']],'tree_limited_cases':21,'edge_complete_scans':13,'edge_partial_scans':15,
    'all_processes_closed':True,'case_complete_cap_overrun_seconds':0,'placement_solver_calls':0,'native_calls':0,'full_construction_60_90_budget_claimed':False})
write(OUT/'next-step.json',{'all_prior_processes_closed':True,'remaining_fixed29_choices':26,'total_fixed29_choices_excluded_at_required_clearance':429,
    'previous_zero_clearance_exclusions':427,'new_required_clearance_exclusions':excluded,
    'next_method':'Assess clearance-aware root pruning against the29 fixed original core rectangles. The previous necessary anchor cover only excluded strict zero-clearance intersections with certified fixed source-inner rectangles. For each surviving closed cell, derive fixed-inner minus moving-inner collision rectangles and expand by the independently justified140 micrometre square, strictly inside the200 micrometre required-clearance ball. Certify whole-cell coverage by exact open-rectangle union classes. Retain every cell whose complete coverage is unproved, preserve all source aliases and every current source/cog/pair certificate, and independently replay every removal against the original fixed identities and source containment audit. First measure genuinely smaller domains; only then prepare a distinct bounded tree for changed cases. Freeze all limits, preserve incomplete results, and charge consumed preparation before any later construction budget claim.',
    'survivors':'output/h5-first57-clearance-pair-trees-20261106/audit/remaining-fixed29-choices.json',
    'root_domains':'output/h5-first57-clearance-cog-pruning-20261106',
    'fixed_inner_rectangles':'output/h5-first57-necessary-rectangles-20261104/fixed-core-inner-rectangles.json',
    'source_inner_geometry':'output/h5-first57-necessary-rectangles-20261104/geometry-domains.json',
    'new_fixed_core_clearance_model_prepared':False,'whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'new_continuous_choices_excluded_at_required_clearance':2,'remaining_fixed29_choices':26,'total_fixed29_choices_excluded_at_required_clearance':429,'original_fixed29_choices':455,
    'previous_zero_clearance_exclusions':427,'new_excluded_choices':excluded,'new_clearance_pair_edges':22610,
    'required_job_clearance_mm':0.2,'pair_expansion_square_radius_um':140,'new_zero_clearance_exclusion_claimed':False,
    **{k:ta[k] for k in ['tree_records_verified','branch_cliques','closed_count_leaves','propagation_covers','propagation_removals','mandatory_support_pair_checks','clique_pair_checks','strict_source_inner_pair_evaluations']},
    'joint_graph_witnesses':5,'limited_joint_cases':21,'placement_solver_calls':0,'native_calls':0,
    'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-clearance-pair-proofs-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 required-clearance pair exclusions:** [independent edge and tree audits]({link}) verify 22,610 new pair conflicts across all 28 retained arrangements, using a 140 µm square whose Euclidean norm stays below the original 200 µm clearance. The two-family replay checks 15,668 records and 559,564 ordered removals. Complete trees exclude [0,5,13] and [5,9,10] at required 0.2 mm clearance, leaving 26 arrangements: five necessary graph witnesses and twenty-one cutoff cases. The total is 429 of 455 excluded at required clearance; only the earlier 427 are certified even at zero clearance. Thirteen edge scans complete and fifteen retain verified prefixes, without an augmentation-completeness claim. Complete preparations take 10.627570 and 22.117861 s, with zero complete-case/process overrun and no placement/native call. Next assess exact required-clearance root pruning against the 29 fixed original core rectangles. The previous two checkpoints were pushed normally to main e7585660 after all six prior CI checks passed; the new run is underway. Full66 checks, 440 whole allocations and H2/H5 remain open at 60%; every bounded process stays closed.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8')
a='Latest H5 evidence: [union and clearance domains](../benchmarks/results/h5-clearance-domain-proofs-20261106.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [required-clearance pair exclusions](../benchmarks/results/{NAME}.md).',1)
a='one unchanged case is carried forward. Exact clearance-aware pair conflicts\nare next. All prior calls and bounded processes stay closed.'
b='one unchanged case is carried forward. Another 22,610 required-clearance pair\nconflicts strengthen all 28 cases; complete trees exclude [0,5,13] and [5,9,10].\nThere are now 26 choices (429 of 455 excluded at required 0.2 mm clearance;\n427 of those even at zero clearance): five necessary graph witnesses and\ntwenty-one cutoff cases. Clearance-aware root pruning against the fixed core\nis next. All prior calls and bounded processes stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
