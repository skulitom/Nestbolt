"""Exact-rational cover, disk and raw-boundary proof for the focused obstruction."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-partial62-capacity-obstruction-repaired-20261026';REG=ROOT/'output/h5-partial62-fixed-regions-20261026';SOURCE=ROOT/'output/h5-expanded-cog-joint-prepared-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def vertices(g):
    if g['type']=='Polygon':return [p for ring in g['coordinates'] for p in ring]
    if g['type']=='MultiPolygon':return [p for polygon in g['coordinates'] for ring in polygon for p in ring]
    assert g['type']=='GeometryCollection';return [p for sub in g['geometries'] for p in vertices(sub)]
def outward(g):
    ps=[[F(x)*1000,F(y)*1000] for x,y in vertices(g)];return [math.floor(min(p[0] for p in ps))-1,math.floor(min(p[1] for p in ps))-1,math.ceil(max(p[0] for p in ps))+1,math.ceil(max(p[1] for p in ps))+1]
def raw(case):
    g=load(SOURCE/'mutual'/f'{case:03d}.json')['raw_forbidden'];assert g['type']=='Polygon' and len(g['coordinates'])==1;return [[F(x),F(y)] for x,y in g['coordinates'][0]]
def parity(points,p):
    count=0
    for a,b in zip(points,points[1:]):
        if (a[1]>p[1])!=(b[1]>p[1]):
            x=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1]);assert x!=p[0];count+=x>p[0]
    return count%2
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Use exact binary-rational raw vertices only. Verify complete four-original/source-mode inventory and every empty or eligible region. Bound every actual free-region vertex outward; prove all five cog components covered by two zones. Recompute every raw cog/cog boundary distance and origin ray parity, then compare exact zone squared diameters to the strict collision disk. Two mandatory cogs and capacity1 per zone force a left occupant. For both bracket modes, independently derive whole difference boxes, exclude every raw original no-fit boundary segment by exact interval clipping against the closed rectangle, and verify odd ray parity at its center. Connectedness then proves the complete rectangle lies in collision interior. No solver or broader-construction impossibility claim.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for n,h in load(REG/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(REG/'audit/checks.json')['passed'];known=set()
for name in ['h5-domain-selection-and-triple-certificate-20261026','h5-projected-source-and-fresh-conflicts-20261026']:
    m=load(ROOT/'benchmarks/results'/name/'raw-manifest.json');known.update(r['sha256'] for r in m['files']+m['aliases'])
for i in [9,49,81]:assert digest(SOURCE/'mutual'/f'{i:03d}.json') in known
cert=load(BASE/'certificate.json');spec=load(REG/'plan.json');assert [p['index'] for p in spec['parts']]==[28,29,53,54] and len(spec['fixed_items'])==62;assert [p['profiles'] for p in spec['parts']]==[list(range(8)),list(range(8)),[9],[9]];regions={q['index']:load(REG/'queries'/f"{q['index']:03d}.json")['free_region'] for q in spec['queries']};assert [q for q in range(16) if vertices(regions[q])]==cert['nonempty_bracket_queries']==[0,8];assert [q for q in [18,19] if vertices(regions[q])]==cert['nonempty_cog_queries']==[18];g=regions[18];assert g['type']=='MultiPolygon' and len(g['coordinates'])==5;components=[];groups={0:[],1:[]}
for i,coords in enumerate(g['coordinates']):
    b=outward({'type':'Polygon','coordinates':coords});assert b[2]<1100000 or b[0]>1100000;zone=0 if b[2]<1100000 else 1;components.append({'component':i,'zone':zone,'outward_bounds_units1000':b});groups[zone].append(b)
assert components==cert['cog_components'];zones=[[min(b[k] for b in groups[z]) if k<2 else max(b[k] for b in groups[z]) for k in range(4)] for z in [0,1]];assert zones==cert['complete_cog_zone_boxes_units1000'];disk=raw(81);assert parity(disk,[F(0),F(0)])==1;radius=F(258082,1000);disk_checks=0
for a,b in zip(disk,disk[1:]):
    dx,dy=b[0]-a[0],b[1]-a[1];norm=dx*dx+dy*dy
    if not norm:continue
    dot=-(a[0]*dx+a[1]*dy)
    dist=a[0]**2+a[1]**2 if dot<=0 else b[0]**2+b[1]**2 if dot>=norm else (a[0]*b[1]-a[1]*b[0])**2/norm
    assert dist>radius**2;disk_checks+=1
diagonals=[(b[2]-b[0])**2+(b[3]-b[1])**2 for b in zones];assert diagonals==cert['zone_diagonal_squared_units'] and max(diagonals)<258082**2;assert cert['capacity_per_zone']==1 and cert['required_cogs']==2;segmentchecks=0;rows=[]
for entry,(q,case) in zip(cert['bracket_collision_cases'],[(0,9),(8,49)]):
    a=outward(regions[q]);b=zones[0];delta=[b[0]-a[2],b[1]-a[3],b[2]-a[0],b[3]-a[1]];assert entry['bracket_query']==q and entry['profile']==spec['queries'][q]['profile'] and entry['original_mutual_case']==case and entry['bracket_outward_box_units1000']==a and entry['difference_box_units1000']==delta;rect=[F(v,1000) for v in delta];pts=raw(case);assert parity(pts,[(rect[0]+rect[2])/2,(rect[1]+rect[3])/2])==1
    for u,v in zip(pts,pts[1:]):
        lo,hi=F(0),F(1);possible=True
        for axis in [0,1]:
            d=v[axis]-u[axis]
            if d==0:
                if not rect[axis]<=u[axis]<=rect[axis+2]:possible=False;break
            else:
                p=(rect[axis]-u[axis])/d;r=(rect[axis+2]-u[axis])/d;lo=max(lo,min(p,r));hi=min(hi,max(p,r))
        assert not possible or lo>hi,(q,u,v);segmentchecks+=1
    rows.append({'query':q,'raw_mutual_case':case,'complete_difference_box_inside_raw_collision':True,'boundary_segments_checked':len(pts)-1})
write(OUT/'exact-bracket-collision-checks.json',rows);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'complete_focused_inventory_verified':True,'fixed_originals':62,'mandatory_moving_originals':4,'raw_cog_disk_segments_reverified':disk_checks,'all_cog_components_covered':5,'capacity1_zones':2,'both_zones_forced_by_two_required_cogs':True,'all_nonempty_bracket_modes_checked':2,'raw_bracket_cog_segment_box_checks':segmentchecks,'whole_bracket_left_cog_collision_boxes':2,'focused62_fixed_source_construction_infeasible':True,'broader54_fixed_search_not_excluded':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
