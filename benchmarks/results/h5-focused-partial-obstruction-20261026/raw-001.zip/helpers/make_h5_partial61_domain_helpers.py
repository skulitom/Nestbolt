"""Prepare fresh domain helpers; retain the audited original pair-case numbering."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(name,s):
    compile(s,name,'exec')
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for name in ['build','audit']:
    s=(ROOT/'output'/f'{name}_h5_expanded_cog_joint_domains.py').read_text(encoding='utf-8')
    s=s.replace('h5-expanded-cog-neighborhood-20261026','h5-partial61-fixed-regions-20261026').replace('h5-expanded-cog-joint-prepared-20261026','h5-partial61-joint-prepared-20261026')
    s=s.replace(" and load(REG/'anchor-repair-census/audit/checks.json')['passed']",'')
    s=s.replace("'anchor-repair-census/audit/checks.json','anchor-repair-census/audit/verified-nine-cog-anchors.json'","'prior-three-cog-membership.json'")
    s=s.replace("len(parts)==12","len(parts)==5").replace("len(spec['parts'])==12","len(spec['parts'])==5")
    s=s.replace("'fixed_originals':54","'fixed_originals':61").replace("'mandatory_moving_originals':12","'mandatory_moving_originals':5").replace("'moving_originals':12","'moving_originals':5")
    s=s.replace("len(spec['fixed_items'])==54","len(spec['fixed_items'])==61").replace("{'bracket':2,'insert':1,'cog':9}","{'bracket':2,'cog':3}").replace('[3681713590,249662718]','[3901764462,349788154]')
    s=s.replace("load(REG/'anchor-repair-census/audit/verified-nine-cog-anchors.json')['positions']","load(REG/'prior-three-cog-membership.json')").replace("qi=18+r['sheet'];x,y=r['xy']","qi=r['query'];x,y=r['anchor_units1000']").replace("'anchor_units1000':r['xy']","'anchor_units1000':r['anchor_units1000']")
    s=s.replace("'physical_pairs':66","'physical_pairs':10").replace('len(physical)==66','len(physical)==10').replace('len(inventory)==66','len(inventory)==10').replace('==538','==230').replace("'same_sheet_query_pair_modes':538","'same_sheet_query_pair_modes':230").replace('len(witness)==9','len(witness)==3').replace('all9_repaired_partial_anchors_representable','all3_prior_cog_anchors_representable')
    s=s.replace('new54-fixed','new61-fixed').replace('new54','new61').replace('new fixed54','new fixed61').replace('12 mandatory movers','5 mandatory movers').replace('full66 physical pair/538 mode','full10 physical pair/230 mode').replace('complete66 physical pair inventory for12 movers','complete10 physical pair inventory for5 movers').replace('nine-cog partial','three-cog partial').replace('No old fixed57','No old fixed54 or fixed62').replace('no_old_fixed57_conditional_exclusion_transferred','no_old_fixed54_or_fixed62_conditional_exclusion_transferred')
    if name=='build':
        s=s.replace("mutual=[{'index':i,'profile_a':a,'profile_b':b} for i,(a,b) in enumerate(pairs)];assert mutual==load(OLD/'plan.json')['mutual_cases'] and len(mutual)==82", "mutual=load(OLD/'plan.json')['mutual_cases'];assert len(pairs)==73 and len(mutual)==82 and set(pairs)<=set((c['profile_a'],c['profile_b']) for c in mutual)")
        s=s.replace("'mutual_cases':mutual,", "'mutual_cases':mutual,'used_mutual_cases':[c['index'] for c in mutual if (c['profile_a'],c['profile_b']) in pairs],'unused_profile_queries':[16,17],")
        s=s.replace('The10 source profiles, source angles, pair guard and82 ordered profile pairs are unchanged', 'The10 source profiles, source angles and pair guard are unchanged. Retain all82 historical pair cases with unchanged IDs;73 are used and9 are explicitly unused')
    else:
        s=s.replace("expected=[{'index':i,'profile_a':a,'profile_b':b} for i,(a,b) in enumerate(desired)];assert expected==spec['mutual_cases']==load(OLD/'plan.json')['mutual_cases'] and len(expected)==82", "expected=load(OLD/'plan.json')['mutual_cases'];assert expected==spec['mutual_cases'] and len(expected)==82 and len(desired)==73;assert [c['index'] for c in expected if (c['profile_a'],c['profile_b']) in desired]==spec['used_mutual_cases'];assert spec['unused_profile_queries']==[16,17]")
    save(f'{name}_h5_partial61_joint_domains.py',s)
push=(ROOT/'output/push_h5_domain_selection_checkpoint.py').read_text(encoding='utf-8').replace('h5-domain-selection-main-sync-20261026','h5-conditional-selection-main-sync-20261026').replace('40261923411','40264589776').replace('b8535505cbe17167056041765648fd4770a8320b','679e97e0d7fca4798ba2a1d690c044d72b8f72e2').replace('6a27fec0e549bd39cbfcf597aecacf16816d1cfc','b8535505cbe17167056041765648fd4770a8320b')
save('push_h5_conditional_selection_checkpoint.py',push)
