from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_partial61_checkpoint.py').read_text(encoding='utf-8').replace('h5-partial61-checkpoint-review-20261026','h5-partial61-checkpoint-review-repaired-20261026').replace("r['name']=='CI'","r['name']=='Checks'")
with (ROOT/'output/review_h5_partial61_checkpoint_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (ROOT/'output/h5-partial61-checkpoint-review-20261026/failure-record.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'failure':'StopIteration selecting CI by invented workflow name CI; actual saved GitHub name is Checks. Raw successful read results preserved.','repair':'Use observed workflow name Checks in a fresh output directory. No mutation or solver call in the failed review.','solver_calls':0,'remote_writes':0},f,indent=2);f.write('\n')
