"""Engineering plot of the independently verified partial; no packing acceptance."""
from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-insert-cog-partial64-20261026';OUT=ROOT/'output/h5-partial64-bottom-cog-visual-repaired-20261026';OUT.mkdir()
load=lambda p:json.loads(p.read_bytes())
assert load(BASE/'checks.json')['passed'];job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};placements=load(BASE/'partial64-placements.json');items=load(ROOT/'output/h5-source-orientation-construction-20261025/items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};colors={'frame':'#d8e4ef','bracket':'#f4c78d','insert':'#8ed4b0','cog':'#c3a0d8'}
fig,(full,detail)=plt.subplots(1,2,figsize=(12,12),gridspec_kw={'width_ratios':[1,1]})
for axis in [full,detail]:
    axis.add_patch(Rectangle((6.5,6.5),1487,2987,fill=False,color='#333',lw=1))
    for p in placements:
        if p['sheet_id']!='sheet-0':continue
        item=ids[p['part_id'],p['copy_index']];t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;pts=[(mi*x*c-y*s+t['translation'][0],mi*x*s+y*c+t['translation'][1]) for x,y in parts[p['part_id']]['geometry'][0]['outer']];released=item in [53,54];axis.add_patch(Polygon(pts,facecolor=colors[p['part_id']],edgecolor='#c21d2e' if released else '#555',lw=2 if released else .6));x=sum(q[0] for q in pts)/len(pts);y=sum(q[1] for q in pts)/len(pts);axis.text(x,y,str(item),ha='center',va='center',fontsize=8 if axis==detail else 5,color='#a10d22' if released else '#222',clip_on=True)
    axis.set_aspect('equal');axis.set_xlabel('mm');axis.set_ylabel('mm')
full.set_xlim(-15,1510);full.set_ylim(-15,3010);full.set_title('First sheet: original item IDs')
detail.set_xlim(700,1510);detail.set_ylim(2020,3000);detail.set_title('Cog region; released originals 53/54 in red')
fig.suptitle('Verified partial: 64 of 66 originals; brackets 28/29 missing\nFilled outer contours shown; cutouts remain reserved. Not a cutting layout.',fontsize=12);fig.tight_layout(rect=(0,0,1,.94));fig.savefig(OUT/'partial64-first-sheet.png',dpi=140);plt.close(fig)
with (OUT/'plot-inputs.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'partial_source':BASE.relative_to(ROOT).as_posix(),'visible_sheet':0,'highlighted_originals':[53,54],'missing_originals':[28,29],'full_target_witness':False},f,indent=2);f.write('\n')
print(OUT/'partial64-first-sheet.png')
