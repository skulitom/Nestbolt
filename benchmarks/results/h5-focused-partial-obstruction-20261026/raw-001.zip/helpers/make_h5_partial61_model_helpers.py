"""Generate a five-original model and independent whole-model auditor."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(name,s):
    compile(s,name,'exec')
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for name in ['prepare','audit']:
    s=(ROOT/'output'/f'{name}_h5_expanded_source_model.py').read_text(encoding='utf-8')
    s=s.replace('h5-expanded-source-model-20261026','h5-partial61-source-model-20261026').replace('h5-expanded-cog-joint-prepared-20261026','h5-partial61-joint-prepared-20261026').replace('h5-expanded-cog-neighborhood-20261026','h5-partial61-fixed-regions-20261026')
    s=s.replace(";CAP=ROOT/'output/h5-expanded-second-sheet-capacity-20261026'",'').replace(" and load(CAP/'audit/checks.json')['passed']",'')
    s=s.replace("'moving_originals':12","'moving_originals':5").replace("'fixed_originals':54","'fixed_originals':61").replace("'hints':54","'hints':18").replace("'original_anchor_variables':24","'original_anchor_variables':10").replace("'physical_pairs':66","'physical_pairs':10").replace("'same_sheet_pair_modes':538","'same_sheet_pair_modes':115").replace("'fresh_capacity_verified':True","'no_old_capacity_transferred':True")
    s=s.replace('twelve-mover','five-mover').replace('fresh54-fixed','fresh61-fixed').replace('12 mandatory originals','5 mandatory originals').replace('of12 physical originals','of5 physical originals').replace('fixed54 and these12','fixed61 and these5').replace('and54 unchanged fixed','and61 unchanged fixed').replace('all nine repaired cog positions','three previous cog positions').replace('All unordered physical pairs have every same-sheet query combination.','All unordered physical pairs have every nonempty same-sheet query combination; empty-query flags are forced false.').replace('all538 same-sheet pair modes','all115 nonempty same-sheet pair modes').replace('all66 physical pairs/538 query modes','all10 physical pairs/115 nonempty query modes')
    if name=='prepare':
        s=s.replace("+[CAP/n for n in ['plan.json','certificate.json','audit/plan.json','audit/checks.json']]",'')
        s=s.replace("qb={i:bounds(q['domains']) for i,q in queries.items()}","qb={i:bounds(q['domains']) for i,q in queries.items() if q['domains']}")
        s=s.replace(";cap=load(CAP/'certificate.json');lin(model,[(modes[p,19]['active'],1) for p in cap['applicable_moving_parts']],hi=cap['capacity'])",'')
        s=s.replace("'capacity_certificate_sha256':digest(CAP/'certificate.json'),",'')
        s=s.replace(' and the freshly audited second-sheet capacity2','; no previous capacity, area conflict, domain conflict or conditional exclusion is copied').replace(' Fresh geometric disk/bin proof supplies second-sheet cog capacity2.',' No prior capacity is transferred.')
        s=s.replace("qa,qbb=mode['query_a'],mode['query_b'];ma,mb=", "qa,qbb=mode['query_a'],mode['query_b']\n            if qa not in qb or qbb not in qb:continue\n            ma,mb=")
        s=s.replace("'fresh_capacity_rules':1","'fresh_capacity_rules':0")
    else:
        a=s.index('    manifest=load(');b=s.index("    assert load(SOURCE/'audit/checks.json')",a)
        s=s[:a]+"    committed=0\n    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n;committed+=1\n    for n,h in load(SOURCE/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n\n"+s[b:]
        s=s.replace("'committed_source_inputs_verified':committed","'fresh_source_inputs_verified':committed").replace('Verify all committed source hashes and the fresh capacity audit.','Verify all fresh source hashes and independent domain audit.').replace('both exact original-area inequalities, fresh capacity,','both exact original-area inequalities without any inherited capacity,')
        s=s.replace("len(spec['parts'])==12","len(spec['parts'])==5").replace("len(spec['fixed_items'])==54","len(spec['fixed_items'])==61")
        s=s.replace("for qi,q in queries.items():\n        boxes", "for qi,q in queries.items():\n        if not q['domains']:continue\n        boxes")
        s=s.replace("for q in original['queries'])", "for q in original['queries'] if q in boxes)")
        s=s.replace("rules['constraint_span']==[cc,cc+3]","rules['constraint_span']==[cc,cc+2]")
        a=s.index(";cap=load(CAP/'certificate.json')");b=s.index('\n',a);s=s[:a]+s[b:]
        s=s.replace("if spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']:","if qa in boxes and qb in boxes and spec['queries'][qa]['sheet']==spec['queries'][qb]['sheet']:")
        s=s.replace("len(mapping['source_pair_faces'])==538","len(mapping['source_pair_faces'])==115").replace('len(hint_pairs)==54','len(hint_pairs)==18')
    assert 'CAP/' not in s
    save(f'{name}_h5_partial61_source_model.py',s)
