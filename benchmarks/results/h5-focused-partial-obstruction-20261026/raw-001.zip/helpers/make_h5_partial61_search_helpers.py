from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
method='One distinct five-mover search fixes61 verified originals from the64-part partial and moves original brackets28/29 plus cogs53/54/61. All66 originals remain mandatory. Fresh inward domains, all10 physical pairs and115 nonempty same-sheet modes preserve original shapes and guarded spacing. The other115 empty-query modes are impossible because their selectors are forced false. Two exact original-area inequalities are freshly reconstructed. No prior capacity or conditional exclusion is transferred. Three cog positions supply18 advisory hints. One45second solver call inside60seconds shared import/search/readback,8workers,seed0,10seconds reserve. Every previous call remains closed. No retry, reseed, extension or production qualification.'
for kind in ['run','audit']:
    s=(ROOT/'output'/f'{kind}_h5_free_bottom_cog_search.py').read_text(encoding='utf-8')
    s=s.replace('h5-free-bottom-cog-source-search-20261026','h5-partial61-source-search-20261026').replace('h5-free-bottom-cog-source-model-20261026','h5-partial61-source-model-20261026').replace('h5-expanded-cog-joint-prepared-20261026','h5-partial61-joint-prepared-20261026').replace("ROOT/'output/h5-projected-expanded-model-20261026/necessary-rules.json'","PREP/'necessary-rules.json'")
    s=s.replace('223086','22545').replace('289925','39619').replace('==538','==115').replace(':538',':115').replace('==12','==5').replace("'moving_originals':12","'moving_originals':5").replace("'fixed_originals':54","'fixed_originals':61").replace("'original_anchor_variables':24","'original_anchor_variables':10").replace('len(actual.solution_hint.vars)==60','len(actual.solution_hint.vars)==18').replace("'hints':60","'hints':18")
    if kind=='run':
        s=re.sub(r" and checks\['full_projected_parent_restored_exactly'\].*?(?=\n)"," and checks['every_variable_and_constraint_independently_reconstructed'] and checks['no_old_capacity_transferred']",s,count=1)
        s=re.sub(r"'method':'One distinct full-source subproblem.*?'",repr('method')+':'+repr(method),s)
        s=re.sub(r"'scope':'All66 originals mandatory,12 movers and54 fixed.*?'", "'scope':"+repr(method+' A negative only excludes this finite61-fixed construction.'),s)
    else:
        s=s.replace(";assert sum(p['family']=='cog' and p['sheet']==1 for p in parts)<=2",'')
        s=s.replace('original area and fresh capacity','fresh original area without inherited capacity')
    compile(s,kind,'exec')
    with (ROOT/'output'/f'{kind}_h5_partial61_source_search.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
