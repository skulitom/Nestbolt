"""Fresh five-mover neighborhood after the focused62-fixed geometric obstruction."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('build_h5_partial62_fixed_regions.py','build_h5_partial61_fixed_regions.py'),('audit_h5_partial62_fixed_regions.py','audit_h5_partial61_fixed_regions.py')]:
    s=(ROOT/'output'/source).read_text().replace('h5-partial62-fixed-regions-20261026','h5-partial61-fixed-regions-20261026').replace('[53,54]','[53,54,61]').replace('[28,29,53,54]','[28,29,53,54,61]').replace('{28,29,53,54}','{28,29,53,54,61}').replace('prior-two-cog-membership.json','prior-three-cog-membership.json')
    if source.startswith('build_'):
        for a,b in [('with62 original transforms','with61 original transforms'),('len(fixed)==62','len(fixed)==61'),("'fixed_originals':62","'fixed_originals':61"),("'mandatory_moving_originals':4","'mandatory_moving_originals':5"),('fix62 originals','fix61 originals'),('release only brackets28/29 and cogs53/54.','release only brackets28/29 and cogs53/54/61.'),('all62 original fixed shapes','all61 original fixed shapes')]:assert a in s;s=s.replace(a,b)
    else:
        for a,b in [('all62 fixed originals','all61 fixed originals'),('both prior cog anchors','all three prior cog anchors'),('len(fixed)==62 and len(plan[\'parts\'])==4','len(fixed)==61 and len(plan[\'parts\'])==5'),("==[0,1,2,3]","==[0,1,2,3,4]"),('(53 if q[\'sheet\']==0 else 9)','(52 if q[\'sheet\']==0 else 9)'),('len(membership)==2','len(membership)==3'),('len(fixedpairs)==1414','len(fixedpairs)==1362'),("'fixed_originals':62","'fixed_originals':61"),("'moving_originals':4","'moving_originals':5"),("'original_fixed_stock_edges':248","'original_fixed_stock_edges':244"),("'two_prior_cog_anchors_inside':True","'three_prior_cog_anchors_inside':True")]:assert a in s,(source,a);s=s.replace(a,b)
    with (ROOT/'output'/target).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
