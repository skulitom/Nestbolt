from pathlib import Path
R=Path(__file__).resolve().parent
OLD='output/h5-cog-region-capacities-20261025/shared-search';NEW='output/h5-cog-region-capacities-20261025/disk-search'
def save(n,s):
    with (R/n).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'solve_h5_cog_capacity_master.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace('from audit_h5_cog_capacity_master import verify','from audit_h5_cog_coordinate_master import verify')
s=s.replace("    pair_exclusions=load", "    disk_path=regional_path/'disk-relaxation';assert load(disk_path/'checks.json')['passed'];disk=load(disk_path/'polygon.json')\n    pair_exclusions=load")
s=s.replace("ROOT/'output/audit_h5_cog_capacity_master.py'","ROOT/'output/audit_h5_cog_coordinate_master.py',disk_path/'polygon.json',disk_path/'checks.json'")
needle="    mapping={'parts':parts,'groups':details,'region_occupancies':occupancies};"
addition="""    cog_positions=[]
    boxes=[f['coordinate_bounds'] for q in [18,19] for f in queries[q]['domains']];bounds=[min(b[k] for b in boxes) if k<2 else max(b[k] for b in boxes) for k in range(4)]
    for i in regional['applicable_cog_parts']:
        x=var(f'cog{i}-anchor-x',bounds[0],bounds[2]);y=var(f'cog{i}-anchor-y',bounds[1],bounds[3]);cog_positions.append({'part':i,'x':x,'y':y})
        for m in parts[i]['modes']:
            for row,selector in enumerate(m['domains']):
                for h in queries[m['query']]['domains'][row]['halfplanes']:
                    model.add_linear_constraint(vs[x]*h['a']+vs[y]*h['b'],cp_model.INT_MIN,h['bound']).only_enforce_if(vs[selector])
    for a,b in combinations(cog_positions,2):
        dirs=[];i,j=a['part'],b['part']
        for k,h in enumerate(disk['outside_halfplanes']):
            d=var(f'cog-pair{i}-{j}-disk-edge{k}',0,1);dirs.append(d)
            model.add_linear_constraint((vs[b['x']]-vs[a['x']])*h['a']+(vs[b['y']]-vs[a['y']])*h['b'],h['bound'],cp_model.INT_MAX).only_enforce_if(vs[d])
        sa,sb=parts[i]['sheet'],parts[j]['sheet'];model.add_bool_or([vs[d] for d in dirs]+[vs[sa],vs[sb]])
        model.add_bool_or([vs[d] for d in dirs]+[vs[sa].Not(),vs[sb].Not()])
"""
assert s.count(needle)==1;s=s.replace(needle,addition+needle.replace("'region_occupancies':occupancies","'region_occupancies':occupancies,'simultaneous_cog_coordinates':cog_positions"))
s=s.replace('certificate,pair_exclusions,capacity,regional);','certificate,pair_exclusions,capacity,regional,disk);')
s=s.replace('Add all35 independently certified regional capacity bounds','Additionally bind12 simultaneous cog anchors to every selected original inward domain and require each same-sheet cog pair to separate outside a strictly inner32-gon of the certified original cog collision disk. This is a necessary relaxation only; retain the complete original-coordinate validation stage. Add all35 independently certified regional capacity bounds')
needle="        write(OUT/'selection.json',{'fixed_items':spec['fixed_items'],'movable_parts':selected,'required_originals':66})"
assert s.count(needle)==1;s=s.replace(needle,needle+"\n        write(OUT/'necessary-cog-positions.json',[{'part':p['part'],'x_units':solver.value(vs[p['x']]),'y_units':solver.value(vs[p['y']])} for p in cog_positions])")
save('solve_h5_cog_coordinate_master.py',s)
for src,dst in [('audit_h5_cog_capacity_selection.py','audit_h5_cog_coordinate_selection.py'),('solve_h5_cog_capacity_anchors.py','solve_h5_cog_coordinate_anchors.py')]:save(dst,(R/src).read_text(encoding='utf-8').replace(OLD,NEW))
s=(R/'run_h5_cog_capacity_search.py').read_text(encoding='utf-8').replace("OUT=BASE/'shared-search'","OUT=BASE/'disk-search'")
s=s.replace('solve_h5_cog_capacity_master.py','solve_h5_cog_coordinate_master.py').replace('audit_h5_cog_capacity_selection.py','audit_h5_cog_coordinate_selection.py').replace('solve_h5_cog_capacity_anchors.py','solve_h5_cog_coordinate_anchors.py')
s=s.replace("[BASE/'capacities.json',BASE/'audit/checks.json']","[BASE/'capacities.json',BASE/'audit/checks.json',BASE/'disk-relaxation/polygon.json',BASE/'disk-relaxation/checks.json']")
s=s.replace('Build and independently audit the strengthened master','Build and independently audit the strengthened master with simultaneous full-domain cog anchors and a certified inner collision polygon')
save('run_h5_cog_coordinate_search.py',s)
print('Prepared distinct simultaneous-coordinate necessary search with one shared60-second allowance.')
