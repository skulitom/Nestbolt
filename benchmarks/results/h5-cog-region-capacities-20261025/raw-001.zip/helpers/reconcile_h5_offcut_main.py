"""Preserve the new main documentation and both local evidence checkpoints."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-offcut-main-reconciliation-20261025';OUT.mkdir();sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def run(args,name):
    begin=datetime.now(timezone.utc).isoformat();r=subprocess.run(args,cwd=ROOT,capture_output=True)
    (OUT/(name+'.stdout')).write_bytes(r.stdout);(OUT/(name+'.stderr')).write_bytes(r.stderr);write(OUT/(name+'.json'),{'command':args,'utc':begin,'exit_code':r.returncode})
    r.check_returncode();return r.stdout
old=run(['git','rev-parse','HEAD'],'local-before').decode().strip();remote=run(['git','rev-parse','origin/main'],'main-before').decode().strip()
assert old.startswith('db0c8a01') and remote=='613594568fb49a71abf0248aec218a6b12f63319'
assert not run(['git','diff','HEAD','--name-only'],'tracked-before').strip()
base=run(['git','merge-base','HEAD','origin/main'],'base-before').decode().strip();assert base=='4f359ff7b4c5642c92fb0df26744934395627a42'
remote_files=run(['git','diff','--name-only',base+'..'+remote],'remote-paths').decode().splitlines();local_files=run(['git','diff','--name-only',base+'..'+old],'local-paths').decode().splitlines()
assert len(remote_files)==15 and all(p.startswith('web/public/') for p in remote_files) and not set(remote_files)&set(local_files)
expected={p:sha256(subprocess.check_output(['git','show',ref+':'+p],cwd=ROOT)).hexdigest() for ref,paths in [(remote,remote_files),(old,local_files)] for p in paths}
before=source_digest();assert before=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
run(['git','show','--format=fuller','--stat',remote],'remote-commit');run(['git','diff',base+'..'+remote],'remote-patch')
run(['gh','run','view','40240715636','--json','databaseId,status,conclusion,headSha,jobs,url'],'cancelled-prior-ci')
run(['gh','run','list','--branch','main','--commit',remote,'--limit','10','--json','databaseId,name,status,conclusion,headSha,url,createdAt,updatedAt'],'new-main-ci-initial')
run(['git','merge','--no-edit','origin/main'],'merge')
head=run(['git','rev-parse','HEAD'],'head-after').decode().strip();after=source_digest();assert before==after
for p,h in expected.items():assert sha256((ROOT/p).read_bytes()).hexdigest()==h
assert not run(['git','diff','HEAD','--name-only'],'tracked-after').strip()
run(['git','merge-base','--is-ancestor',old,'HEAD'],'local-ancestor');run(['git','merge-base','--is-ancestor',remote,'HEAD'],'remote-ancestor')
write(OUT/'receipt.json',{'utc':datetime.now(timezone.utc).isoformat(),'local_before':old,'remote_main':remote,'merge_head':head,'remote_documentation_files_preserved':len(remote_files),
    'local_evidence_files_preserved':len(local_files),'preserved_file_sha256':expected,'production_digest':after,'prior_main_ci_cancelled':True,'prior_ci_id':40240715636,
    'prior_ci_successful_jobs':5,'windows_pass_claimed':False,'pushed':False,'H2_complete':False,'H5_complete':False,'completion_percent':60})
print({'merge_head':head,'remote_files_preserved':len(remote_files),'local_files_preserved':len(local_files),'production_digest':after,'pushed':False},flush=True)
