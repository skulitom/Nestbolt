"""Independent full inherited model plus simultaneous cog-coordinate audit."""
from itertools import combinations
from collections import Counter
from ortools.sat import cp_model_pb2
from audit_h5_cog_capacity_master import verify as verify_base
def verify(actual,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional,disk):
    cogs=regional['applicable_cog_parts'];assert len(cogs)==6
    nplanes=sum(len(f['halfplanes']) for q in [18,19] for f in queries[q]['domains'])*6
    ndirs=15*len(disk['outside_halfplanes']);nvars=12+ndirs;nconstraints=nplanes+ndirs+30
    prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(actual);del prefix.variables[-nvars:];del prefix.constraints[-nconstraints:]
    mapping,stats=verify_base(prefix,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional);vi=len(prefix.variables);ci=len(prefix.constraints);positions=[]
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]);vi+=1;return vi-1
    def linear(terms,lo,hi,en):
        nonlocal ci
        values=Counter()
        for v,c in terms:values[v]+=c
        ids=sorted(v for v,c in values.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(values[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en)
        assert p==actual.constraints[ci];ci+=1
    allboxes=[f['coordinate_bounds'] for q in [18,19] for f in queries[q]['domains']];bounds=[min(b[k] for b in allboxes) if k<2 else max(b[k] for b in allboxes) for k in range(4)]
    for i in cogs:
        assert spec['parts'][i]['profiles']==[9] and spec['parts'][i]['queries']==[18,19]
        x=var(f'cog{i}-anchor-x',bounds[0],bounds[2]);y=var(f'cog{i}-anchor-y',bounds[1],bounds[3]);positions.append({'part':i,'x':x,'y':y})
        for m in mapping['parts'][i]['modes']:
            for row,selector in enumerate(m['domains']):
                for h in queries[m['query']]['domains'][row]['halfplanes']:linear([(x,h['a']),(y,h['b'])],-2**63,h['bound'],[selector])
    for a,b in combinations(positions,2):
        dirs=[];i,j=a['part'],b['part']
        for k,h in enumerate(disk['outside_halfplanes']):
            d=var(f'cog-pair{i}-{j}-disk-edge{k}',0,1);dirs.append(d)
            linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],2**63-1,[d])
        sa,sb=mapping['parts'][i]['sheet'],mapping['parts'][j]['sheet']
        for literals in [dirs+[sa,sb],dirs+[-sa-1,-sb-1]]:
            p=cp_model_pb2.ConstraintProto();p.bool_or.literals.extend(literals);assert actual.constraints[ci]==p;ci+=1
        for s1 in [0,1]:
            for s2 in [0,1]:
                for separated in [False,True]:assert ((separated or s1 or s2) and (separated or not s1 or not s2))==(separated or s1!=s2)
    assert vi==len(actual.variables) and ci==len(actual.constraints);mapping['simultaneous_cog_coordinates']=positions
    return mapping,{**stats,'variables':vi,'constraints':ci,'simultaneous_cog_anchor_variables':12,'conditional_inward_domain_halfplanes':nplanes,
        'necessary_disk_pair_directions':ndirs,'same_sheet_gating_clauses':30,'both_sheet_truth_tables_verified':True,'original_collision_validation_still_required':True}
