from pathlib import Path
R=Path(__file__).resolve().parent
NEW='output/h5-cog-region-capacities-20261025/shared-search'
def save(n,s):
    with (R/n).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
def budget(s):
    s=s.replace("    solver=cp_model.CpSolver()","    remaining=load(OUT.parent/'budget.json')['deadline_perf_counter']-time.perf_counter()-0.25\n    assert remaining>0,'Shared construction/solve budget exhausted before call'\n    params['max_time_in_seconds']=min(60,remaining)\n    solver=cp_model.CpSolver()")
    s=s.replace("'seconds_limit':60","'seconds_limit':params['max_time_in_seconds']")
    s=s.replace("'parameters_sha256':digest(OUT/'parameters.pbtxt')","'parameters_sha256':digest(OUT/'parameters.pbtxt'),'remaining_shared_budget_at_parameter_set':remaining")
    s=s.replace("'maximum_solver_calls':1,","'maximum_solver_calls':1,'shared_budget_path':str(OUT.parent/'budget.json'),")
    return s
s=(R/'solve_h5_second_sheet_master.py').read_text(encoding='utf-8').replace('output/h5-second-sheet-capacity-master-20261025',NEW)
s=s.replace('from audit_h5_second_sheet_master import verify','from audit_h5_cog_capacity_master import verify')
s=s.replace("    pair_exclusions=load", "    regional_path=ROOT/'output/h5-cog-region-capacities-20261025';assert load(regional_path/'audit/checks.json')['passed'];regional=load(regional_path/'capacities.json')\n    pair_exclusions=load")
s=s.replace("ROOT/'output/audit_h5_second_sheet_master.py'","ROOT/'output/audit_h5_cog_capacity_master.py',regional_path/'capacities.json',regional_path/'audit/checks.json',OUT.parent/'budget.json'")
needle="    mapping={'parts':parts,'groups':details,'region_occupancies':occupancies};"
addition="""    for group in regional['constraints']:
        selectors=[]
        for i in regional['applicable_cog_parts']:
            q=next(q for q in parts[i]['modes'] if q['query']==group['query']);selectors.extend(q['domains'][r] for r in group['domain_rows'])
        linear([(v,1) for v in selectors],cp_model.INT_MIN,group['capacity'])
"""
assert s.count(needle)==1;s=s.replace(needle,addition+needle)
s=s.replace('certificate,pair_exclusions,capacity);','certificate,pair_exclusions,capacity,regional);')
s=s.replace('Independently audit every preserved constraint','Add all35 independently certified regional capacity bounds, counting every selected domain across all six cogs. A single parent60-second budget covers construction, model audits, master search, selected-domain audit and any coordinate search. Each call receives only the remaining budget; there are no retries. Independently audit every preserved constraint')
save('solve_h5_cog_capacity_master.py',budget(s))
s=(R/'audit_h5_second_sheet_selection.py').read_text(encoding='utf-8').replace('output/h5-second-sheet-capacity-master-20261025',NEW)
s=s.replace("    assert load(PROOF/'checks.json')['passed'];cap=", "    regional_path=ROOT/'output/h5-cog-region-capacities-20261025';assert load(regional_path/'audit/checks.json')['passed'];regional=load(regional_path/'capacities.json')\n    counts=[]\n    for group in regional['constraints']:\n        count=sum(p['part'] in regional['applicable_cog_parts'] and p['query']==group['query'] and p['domain_row'] in group['domain_rows'] for p in parts);assert count<=group['capacity'];counts.append({'candidate':group['candidate'],'count':count,'capacity':group['capacity']})\n    write(OUT/'regional-capacity-check.json',{'passed':True,'counts':counts})\n    assert load(PROOF/'checks.json')['passed'];cap=")
save('audit_h5_cog_capacity_selection.py',s)
s=(R/'solve_h5_selected_anchors.py').read_text(encoding='utf-8').replace('output/h5-original-domain-conflicts-20261025',NEW)
s=s.replace("inputs=[BASE/'solve/selection.json'","inputs=[BASE/'budget.json',BASE/'selection-audit/regional-capacity-check.json',BASE/'solve/selection.json'")
s=s.replace('before one60-second/eight-worker/seed-zero call','before one eight-worker/seed-zero call using only the remaining parent60-second shared construction/audit/solve budget, with no retry')
save('solve_h5_cog_capacity_anchors.py',budget(s))
print('Prepared shared-budget capacity search and independent full model audits.')
