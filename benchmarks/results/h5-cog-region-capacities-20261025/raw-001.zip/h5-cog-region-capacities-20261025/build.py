"""Exact integer box-cover capacities for complete original cog-domain groups."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,time,shutil,traceback
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OLD=ROOT/'output/h5-original-domain-conflicts-20261025';OUT=ROOT/'output/h5-cog-region-capacities-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def cover(box,required):
    nxpoints,nypoints=box[2]-box[0]+1,box[3]-box[1]+1
    for count,nx,ny in sorted((nx*ny,nx,ny) for nx in range(1,6) for ny in range(1,6) if nx*ny<=5):
        dx=(nxpoints+nx-1)//nx-1;dy=(nypoints+ny-1)//ny-1
        if dx*dx+dy*dy<required:
            return {'capacity':count,'columns':nx,'rows':ny,'maximum_cell_x_span_units':dx,'maximum_cell_y_span_units':dy,'maximum_cell_squared_diameter_units':dx*dx+dy*dy,'strict_squared_diameter_shortfall_units':required-dx*dx-dy*dy}
    return None
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();cert=load(OLD/'three-cog-certificate/certificate.json');required=cert['strict_inner_disk_radius_units']**2+1
    paths=[SOURCE/'plan.json',SOURCE/'queries/018.json',SOURCE/'queries/019.json',OLD/'three-cog-certificate/certificate.json',OLD/'three-cog-certificate/audit/checks.json',ROOT/'benchmarks/results/h5-convex-domain-conflicts-20261025/raw-manifest.json']
    assert load(paths[4])['passed'];spec=load(paths[0]);cogs=[p for p in spec['parts'] if p['family']=='cog'];assert len(cogs)==6 and all(p['profiles']==[9] and p['queries']==[18,19] for p in cogs)
    grids=[1,1000,5000,10000,25000]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},
        'queries':[18,19],'outward_box_grid_units':grids,'maximum_useful_capacity':5,'maximum_candidate_boxes':4000,'maximum_solver_calls':0,
        'method':'For every complete original cog-domain integer box, also consider its outward1/1000/5000/10000/25000-unit rounded boxes. For each candidate box compute a certified grid cover with at most5 cells: distribute its integer x/y coordinates among consecutive bins, each with span at most ceil(integer_point_count/bin_count)-1. If every complete cell diagonal is shorter than the independently certified original-cog separation, each cell holds at most one cog. The cell count bounds all domains wholly contained in the box, across every one of the six mandatory cogs. Deduplicate equal domain sets retaining the strongest capacity, then remove only bounds implied by a superset with an equal or lower certified capacity. All unpruned certificates and exact dominance witnesses are retained; no domain choice or original part is deleted.'})
    candidates=[];domains={}
    for qi in [18,19]:
        ds=load(SOURCE/'queries'/f'{qi:03d}.json')['domains'];domains[qi]=ds;seen=set()
        for row,d in enumerate(ds):
            a=d['coordinate_bounds']
            for grid in grids:
                box=[a[0]//grid*grid,a[1]//grid*grid,((a[2]+grid-1)//grid)*grid,((a[3]+grid-1)//grid)*grid]
                if tuple(box) in seen:continue
                seen.add(tuple(box));proof=cover(box,required)
                if proof is None:continue
                ids=[i for i,f in enumerate(ds) if all([box[0]<=f['coordinate_bounds'][0],box[1]<=f['coordinate_bounds'][1],f['coordinate_bounds'][2]<=box[2],f['coordinate_bounds'][3]<=box[3]])]
                assert row in ids
                candidates.append({'candidate':len(candidates),'query':qi,'profile':9,'sheet':spec['queries'][qi]['sheet'],'source_domain_row':row,'outward_grid_units':grid,'box_units1000':box,'domain_rows':ids,'domain_indices':[ds[i]['index'] for i in ids],**proof})
                assert time.perf_counter()-start<60 and len(candidates)<=4000
    byset={}
    for c in candidates:
        key=(c['query'],tuple(c['domain_rows']));old=byset.get(key)
        if old is None or (c['capacity'],c['candidate'])<(old['capacity'],old['candidate']):byset[key]=c
    chosen=sorted(byset.values(),key=lambda c:(c['query'],c['capacity'],-len(c['domain_rows']),c['candidate']));sets={c['candidate']:set(c['domain_rows']) for c in chosen}
    kept=[];dominance=[]
    for c in chosen:
        dominator=next((d for d in kept if d['query']==c['query'] and d['capacity']<=c['capacity'] and sets[c['candidate']]<=sets[d['candidate']]),None)
        if dominator:dominance.append({'removed_candidate':c['candidate'],'retained_candidate':dominator['candidate']})
        else:kept.append(c)
    # Account for every raw candidate, including exact-domain-set duplicates.
    all_dominance=[]
    for c in candidates:
        d=next(k for k in kept if k['query']==c['query'] and k['capacity']<=c['capacity'] and set(c['domain_rows'])<=sets[k['candidate']])
        all_dominance.append({'candidate':c['candidate'],'retained_candidate':d['candidate']})
    write(OUT/'candidates.json',candidates);write(OUT/'dominance.json',all_dominance)
    payload={'coordinate_units_per_mm':1000,'required_squared_center_distance_units':required,'applicable_cog_parts':[p['part'] for p in cogs],
        'constraints':kept,'source_disk_certificate_sha256':digest(paths[3])};write(OUT/'capacities.json',payload)
    last=load(ROOT/'output/h5-second-sheet-capacity-master-20261025/solve/selection.json')['movable_parts'];violations=[]
    for c in kept:
        owners=[p['part'] for p in last if p['part'] in payload['applicable_cog_parts'] and p['query']==c['query'] and p['domain_row'] in c['domain_rows']]
        if len(owners)>c['capacity']:violations.append({'candidate':c['candidate'],'query':c['query'],'capacity':c['capacity'],'selected_parts':owners})
    write(OUT/'previous-selection-violations.json',violations)
    result={'seconds':time.perf_counter()-start,'candidate_boxes_certified':len(candidates),'distinct_domain_sets':len(byset),'retained_constraints':len(kept),
        'capacity_counts':dict(Counter(c['capacity'] for c in kept)),'domain_memberships':sum(len(c['domain_rows']) for c in kept),'all_six_copy_literals':6*sum(len(c['domain_rows']) for c in kept),
        'previous_selection_violated_constraints':len(violations),'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
