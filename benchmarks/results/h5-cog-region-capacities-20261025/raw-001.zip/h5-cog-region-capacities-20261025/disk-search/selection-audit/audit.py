"""Validate domain selection and inspect whole convex-difference collisions."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations,product
import json,shutil,time,traceback
from shapely.geometry import shape,mapping,MultiPoint
from shapely.geometry.polygon import orient

ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-original-domain-conflicts-20261025';BASE=ROOT/'output/h5-convex-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';NEW=ROOT/'output/h5-cog-region-capacities-20261025/disk-search';OUT=NEW/'selection-audit';PROOF=BASE/'second-sheet-pair-proofs/audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();spec=load(SOURCE/'plan.json');selection=load(NEW/'solve/selection.json');census=load(BASE/'plan.json')
    inputs=[(NEW if n.startswith('solve/') else BASE)/n for n in ['plan.json','audit/checks.json','groups/audit/checks.json','solve/plan.json','solve/model-audit.json','solve/result.json','solve/selection.json']]+[SOURCE/'plan.json',PROOF/'checks.json',PROOF/'certified-pair-exclusions.json',PROOF/'capacity-certificate.json',OLD/'three-cog-certificate/certificate.json',OLD/'three-cog-certificate/audit/checks.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':120,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Independently check all nine chosen queries/domains, mandatory identities, source area charges, index-copy ordering and every chosen bit-table entry. For every same-sheet pair reconstruct the complete convex difference of the two actual inset allowed faces, not their boxes. Enclose every exact-rational vertex difference in a padded convex polygon and verify every vertex by rational halfplanes; this encloses every possible anchor difference. Prove additional domain incompatibility only when that whole polygon lies strictly inside a previously independently certified inset raw original obstacle. Preserve all tested pairs and negative/non-proof cases; a missing proof does not establish feasibility. No original counts or shapes change and no native call.'})
    assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'groups/audit/checks.json')['passed'] and load(NEW/'solve/model-audit.json')['passed']
    assert load(NEW/'solve/result.json')['has_necessary_domain_candidate'];parts=selection['movable_parts'];assert len(parts)==9 and selection['fixed_items']==spec['fixed_items'] and selection['required_originals']==66
    faces={};domains=[]
    for i,p in enumerate(parts):
        item=spec['parts'][i];assert p['part']==i and p['item']==item['index'] and p['family']==item['family'] and p['query'] in item['queries']
        q=spec['queries'][p['query']];assert q['profile']==p['profile'] and q['sheet']==p['sheet']
        rows=load(SOURCE/'queries'/f"{p['query']:03d}.json")['domains'];f=rows[p['domain_row']];assert f['index']==p['domain_index'];faces[i]=shape(f['inset_face'])
        choice=sum(len(load(SOURCE/'queries'/f'{qi:03d}.json')['domains']) for qi in item['queries'][:item['queries'].index(p['query'])])+p['domain_row'];assert choice==p['choice_index']
        domains.append({'part':i,'query':p['query'],'domain_row':p['domain_row'],'domain_index':f['index'],'bounds':f['coordinate_bounds'],'whole_inset_face':f['inset_face']})
    orders=[[0,1],[3,4],[4,5],[5,6],[6,7],[7,8]]
    for i,j in orders:assert parts[i]['choice_index']<=parts[j]['choice_index'] and spec['parts'][i]['queries']==spec['parts'][j]['queries']
    regional_path=ROOT/'output/h5-cog-region-capacities-20261025';assert load(regional_path/'audit/checks.json')['passed'];regional=load(regional_path/'capacities.json')
    counts=[]
    for group in regional['constraints']:
        count=sum(p['part'] in regional['applicable_cog_parts'] and p['query']==group['query'] and p['domain_row'] in group['domain_rows'] for p in parts);assert count<=group['capacity'];counts.append({'candidate':group['candidate'],'count':count,'capacity':group['capacity']})
    write(OUT/'regional-capacity-check.json',{'passed':True,'counts':counts})
    assert load(PROOF/'checks.json')['passed'];cap=load(PROOF/'capacity-certificate.json');ex=load(PROOF/'certified-pair-exclusions.json')
    selected_cogs=[p for p in parts if p['part'] in cap['applicable_parts'] and p['query']==19];assert len(selected_cogs)<=2
    for a,b in combinations(selected_cogs,2):assert [a['domain_row'],b['domain_row']] not in ex['domain_row_pairs']
    write(OUT/'second-sheet-check.json',{'passed':True,'selected_second_sheet_cogs':len(selected_cogs),'capacity':2,'all_exact_pair_exclusions_satisfied':True})
    cert=load(OLD/'three-cog-certificate/certificate.json');occupancy=[]
    for g in cert['groups']:
        owners=[p['part'] for p in parts if p['part'] in cert['applicable_moving_cog_parts'] and p['query']==g['query'] and p['domain_row'] in g['domain_rows']]
        occupancy.append({'region':g['name'],'occupied':bool(owners),'parts':owners})
    assert not all(g['occupied'] for g in occupancy);write(OUT/'occupancy-check.json',occupancy)
    aux=load(ROOT/'output/h5-source-orientation-construction-20261025/propagation.json');areas=[spec['fixed_original_area_units_per_sheet'][s]+sum(aux['part_areas'][p['family']]['lower_units'] for p in parts if p['sheet']==s) for s in [0,1]]
    assert all(areas[s]<=aux['sheet_capacities'][s]['upper_area_units'] for s in [0,1])
    caseids={(c['query_a'],c['query_b']):c for c in census['cases']};checks=[];proofs=[];vertices=0
    for a,b in combinations(parts,2):
        if a['sheet']!=b['sheet']:continue
        case=caseids[(a['query'],b['query'])];packed=(BASE/'cases'/f"{case['index']:03d}.bin").read_bytes();index=a['domain_row']*case['rows_b']+b['domain_row']
        assert not (packed[index//8] & (1<<(7-index%8)))
        av=list(faces[a['part']].exterior.coords)[:-1];bv=list(faces[b['part']].exterior.coords)[:-1]
        exact=[(F(xb)-F(xa),F(yb)-F(ya)) for (xa,ya),(xb,yb) in product(av,bv)]
        padded=orient(MultiPoint([(float(x)+dx,float(y)+dy) for (x,y),(dx,dy) in product(exact,[(-1e-6,-1e-6),(-1e-6,1e-6),(1e-6,1e-6),(1e-6,-1e-6)])]).convex_hull,sign=1)
        points=[(F(x),F(y)) for x,y in list(padded.exterior.coords)[:-1]]
        for p,q in zip(points,points[1:]+points[:1]):
            nx,ny=q[1]-p[1],p[0]-q[0];c=nx*p[0]+ny*p[1]
            for x,y in exact:assert nx*x+ny*y<=c;vertices+=1
        core=shape(load(OLD/'cores'/f"{case['mutual_case']:03d}.json")['core']);conflict=core.contains_properly(padded)
        row={'parts':[a['part'],b['part']],'items':[a['item'],b['item']],'query_pair_case':case['index'],'mutual_case':case['mutual_case'],
            'domain_rows':[a['domain_row'],b['domain_row']],'domain_indices':[a['domain_index'],b['domain_index']],
            'whole_padded_convex_difference':mapping(padded),'exact_vertex_differences':len(exact),'bounding_rectangle_conflict':False,
            'whole_convex_difference_strictly_inside_original_core':conflict,'core_boundary_margin_mm':core.boundary.distance(padded) if conflict else None}
        checks.append(row)
        if conflict:proofs.append({k:v for k,v in row.items() if k!='whole_padded_convex_difference'})
    write(OUT/'selected-domains.json',domains);write(OUT/'pair-checks.json',checks);write(OUT/'new-convex-domain-conflicts.json',proofs)
    result={'passed':True,'seconds':time.perf_counter()-start,'mandatory_original_domains_checked':9,'all_previous_box_and_convex_exclusions_satisfied':True,'certified_three_region_exclusion_satisfied':True,
        'original_area_units_per_sheet':areas,'same_sheet_pairs_checked':len(checks),'exact_vertex_halfplane_containment_checks':vertices,
        'new_whole_convex_domain_conflicts':len(proofs),'selected_combination_geometrically_excluded':bool(proofs),'anchor_feasibility_proved':False,
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    assert result['seconds']<120;write(OUT/'checks.json',result);print(result,flush=True);print({'new_conflicts':proofs},flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
