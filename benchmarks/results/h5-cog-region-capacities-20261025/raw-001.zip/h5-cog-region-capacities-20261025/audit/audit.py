"""Independent integer-grid cover, membership and dominance checks."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,time,shutil,traceback
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-region-capacities-20261025';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OLD=ROOT/'output/h5-original-domain-conflicts-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');cap=load(BASE/'capacities.json');candidates=load(BASE/'candidates.json');dom=load(BASE/'dominance.json')
    lastpath=ROOT/'output/h5-second-sheet-capacity-master-20261025/solve/selection.json'
    inputs=[p for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents]+[lastpath]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Rebuild each candidate rounded box and the complete contained-domain set directly from committed original inputs. Construct explicit consecutive integer x/y bin intervals using floor fractions of the integer point counts, check their exact complete/disjoint coverage, then verify every cell diagonal against the independently certified raw-original no-fit disk. Recheck all retained-capacity choices and all1215 dominance witnesses without repeating the builder selection algorithm. Recompute previous-selection violations. Every physical cog is counted once by its selected domain in each group.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    manifest=load(ROOT/'benchmarks/results/h5-convex-domain-conflicts-20261025/raw-manifest.json');committed={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    spec=load(SOURCE/'plan.json');ds={q:load(SOURCE/'queries'/f'{q:03d}.json')['domains'] for q in [18,19]}
    for q in [18,19]:
        p=SOURCE/'queries'/f'{q:03d}.json';assert digest(p)==committed['source-inputs/'+p.relative_to(ROOT).as_posix()]
    p=OLD/'three-cog-certificate/certificate.json';assert digest(p)==cap['source_disk_certificate_sha256']==committed['source-inputs/'+p.relative_to(ROOT).as_posix()]
    c=load(p);assert load(OLD/'three-cog-certificate/audit/checks.json')['passed'];required=c['strict_inner_disk_radius_units']**2+1;assert required==cap['required_squared_center_distance_units']
    cogs=[p for p in spec['parts'] if p['family']=='cog'];assert [p['part'] for p in cogs]==cap['applicable_cog_parts'] and len(cogs)==6 and all(p['profiles']==[9] and p['queries']==[18,19] for p in cogs)
    cell_checks=0;records=[]
    for i,row in enumerate(candidates):
        assert time.perf_counter()-start<60 and row['candidate']==i
        qi=row['query'];a=ds[qi][row['source_domain_row']]['coordinate_bounds'];grid=row['outward_grid_units'];assert grid in plan['outward_box_grid_units']
        box=[a[0]-a[0]%grid,a[1]-a[1]%grid,a[2]+(-a[2])%grid,a[3]+(-a[3])%grid];assert row['box_units1000']==box and row['profile']==9 and row['sheet']==spec['queries'][qi]['sheet']
        ids=[j for j,d in enumerate(ds[qi]) if box[0]<=d['coordinate_bounds'][0]<=d['coordinate_bounds'][2]<=box[2] and box[1]<=d['coordinate_bounds'][1]<=d['coordinate_bounds'][3]<=box[3]]
        assert ids==row['domain_rows'] and row['domain_indices']==[ds[qi][j]['index'] for j in ids]
        nx,ny=row['columns'],row['rows'];assert nx*ny==row['capacity']<=5
        def bins(lo,hi,n):
            count=hi-lo+1;rows=[(lo+(i*count)//n,lo+((i+1)*count)//n-1) for i in range(n)]
            assert rows[0][0]==lo and rows[-1][1]==hi and all(rows[i][1]+1==rows[i+1][0] for i in range(n-1))
            assert sum(max(0,b-a+1) for a,b in rows)==count
            return rows
        xs,ys=bins(box[0],box[2],nx),bins(box[1],box[3],ny);maxx=max(b-a for a,b in xs);maxy=max(b-a for a,b in ys)
        assert maxx==row['maximum_cell_x_span_units'] and maxy==row['maximum_cell_y_span_units']
        for (xl,xh),(yl,yh) in product(xs,ys):
            if xl>xh or yl>yh:continue
            assert (xh-xl)**2+(yh-yl)**2<required;cell_checks+=1
        maximum=maxx**2+maxy**2;assert row['maximum_cell_squared_diameter_units']==maximum and row['strict_squared_diameter_shortfall_units']==required-maximum
        records.append({'candidate':i,'x_intervals':xs,'y_intervals':ys,'all_cells_strictly_below_original_cog_separation':True})
    retained={c['candidate']:c for c in cap['constraints']};assert len(retained)==len(cap['constraints'])
    assert all(candidates[i]==c for i,c in retained.items());assert len(dom)==len(candidates)
    for i,r in enumerate(dom):
        assert r['candidate']==i and r['retained_candidate'] in retained;a,b=candidates[i],retained[r['retained_candidate']]
        assert a['query']==b['query'] and b['capacity']<=a['capacity'] and set(a['domain_rows'])<=set(b['domain_rows'])
    last=load(lastpath)['movable_parts'];violations=[]
    for c in cap['constraints']:
        owners=[p['part'] for p in last if p['part'] in cap['applicable_cog_parts'] and p['query']==c['query'] and p['domain_row'] in c['domain_rows']]
        if len(owners)>c['capacity']:violations.append({'candidate':c['candidate'],'query':c['query'],'capacity':c['capacity'],'selected_parts':owners})
    assert violations==load(BASE/'previous-selection-violations.json')
    write(OUT/'integer-covers.json',records)
    result={'passed':True,'seconds':time.perf_counter()-start,'candidate_boxes_and_memberships_verified':len(candidates),'exact_integer_cell_diagonals_verified':cell_checks,
        'dominance_witnesses_verified':len(dom),'retained_constraints':len(retained),'physical_cog_copies':6,'capacity_counts':{str(n):sum(c['capacity']==n for c in retained.values()) for n in [1,2]},
        'previous_selection_violations_verified':len(violations),'original_domains_counts_and_material_unchanged':True,'no_solver_calls':True,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
