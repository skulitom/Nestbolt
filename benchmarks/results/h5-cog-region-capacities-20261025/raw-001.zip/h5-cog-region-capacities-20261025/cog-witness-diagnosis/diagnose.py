"""Locate original cog collisions in the necessary inner-polygon witness."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from shapely.geometry import shape,Point
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-region-capacities-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'cog-witness-diagnosis'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'diagnose.py');start=time.perf_counter();paths=[BASE/'disk-search/solve/selection.json',BASE/'disk-search/solve/necessary-cog-positions.json',BASE/'search-audit/checks.json',SOURCE/'mutual/081.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'diagnostic_limit_seconds':30,
        'method':'For the six independently checked necessary anchors only, evaluate every original cog/cog forbidden-piece separation inequality using exact integers and retain every failed piece. Also locate the same point in the independently reconstructed raw/guarded original collision regions. This diagnoses the necessary relaxation witness, not another search or complete66-part proposal.'})
    assert load(paths[2])['passed'];selection=load(paths[0])['movable_parts'];positions=load(paths[1]);mutual=load(paths[3]);raw,expanded=shape(mutual['raw_forbidden']),shape(mutual['expanded_forbidden']);checks=[]
    for a,b in combinations(positions,2):
        if selection[a['part']]['sheet']!=selection[b['part']]['sheet']:continue
        dx,dy=b['x_units']-a['x_units'],b['y_units']-a['y_units'];point=Point(dx/1000,dy/1000)
        failed=[f['index'] for f in mutual['faces'] if not any(h['a']*dx+h['b']*dy>=h['bound'] for h in f['outside_halfplanes'])]
        checks.append({'parts':[a['part'],b['part']],'items':[selection[a['part']]['item'],selection[b['part']]['item']],'sheet':selection[a['part']]['sheet'],
            'difference_units1000':[dx,dy],'raw_original_collision':raw.contains(point),'guarded_original_collision':expanded.contains(point),
            'raw_boundary_distance_mm':raw.boundary.distance(point),'guarded_boundary_distance_mm':expanded.boundary.distance(point),'failed_original_forbidden_piece_indices':failed})
    write(OUT/'pairs.json',checks)
    result={'seconds':time.perf_counter()-start,'same_sheet_pairs':len(checks),'raw_original_collision_pairs':sum(c['raw_original_collision'] for c in checks),
        'guarded_original_collision_pairs':sum(c['guarded_original_collision'] for c in checks),'pairs_failing_full_integer_separation':sum(bool(c['failed_original_forbidden_piece_indices']) for c in checks),
        'original_forbidden_faces_per_cog_pair':len(mutual['faces']),'original_separating_edges_per_pair':sum(len(f['outside_halfplanes']) for f in mutual['faces']),
        'no_new_solver_calls':True,'not_a_full66_original_candidate':True,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
