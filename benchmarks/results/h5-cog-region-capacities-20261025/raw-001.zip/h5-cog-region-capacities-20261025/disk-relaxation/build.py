"""A strictly inner integer polygon for original same-angle cog collisions."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-region-capacities-20261025';OUT=BASE/'disk-relaxation';OLD=ROOT/'output/h5-original-domain-conflicts-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();p=OLD/'three-cog-certificate/certificate.json';source=load(p);radius=source['strict_inner_disk_radius_units']
    assert load(OLD/'three-cog-certificate/audit/checks.json')['passed']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'construction_limit_seconds':10,'vertices':32,'inputs':{p.relative_to(ROOT).as_posix():digest(p)},
        'method':'Round32 angular samples at R-1 integer anchor units, then prove all integer vertices strictly inside the independently certified raw original-cog no-fit disk. Exact integer edge halfplanes define the convex polygon. Simultaneous original nonoverlapping cogs must lie outside this strictly inner polygon; the resulting linear disjunction is necessary, not sufficient. No circles or hulls substitute for final original-polygon validation.'})
    points=[[round((radius-1)*math.cos(2*math.pi*i/32)),round((radius-1)*math.sin(2*math.pi*i/32))] for i in range(32)];edges=[]
    for i,(x,y) in enumerate(points):
        u,v=points[(i+1)%32];a,b=v-y,x-u;bound=a*x+b*y;assert bound>0 and all(a*px+b*py<=bound for px,py in points)
        assert x*x+y*y<radius*radius;edges.append({'a':a,'b':b,'bound':bound,'sense':'ge'})
    cert={'coordinate_units_per_mm':1000,'strict_raw_no_fit_disk_radius_units':radius,'disk_certificate_sha256':digest(p),'vertices':points,'outside_halfplanes':edges,
        'scope':'All mandatory moving cogs have the same original profile9/source angle. For each same-sheet pair require at least one edge-normal difference >= bound; this is a necessary relaxation of original-shape nonoverlap.'}
    write(OUT/'polygon.json',cert);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'vertices':32,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False})
    # Independent algebraic audit: no trigonometric reconstruction or builder normals.
    checks=0
    for i,p0 in enumerate(points):
        p1=points[(i+1)%32];cross=lambda p:(p1[0]-p0[0])*(p[1]-p0[1])-(p1[1]-p0[1])*(p[0]-p0[0])
        assert all(cross(p)>=0 for p in points) and cross([0,0])>0
        for j,p2 in enumerate(points):
            if j not in [i,(i+1)%32]:assert cross(p2)>0
            checks+=1
        assert edges[i]=={'a':p1[1]-p0[1],'b':p0[0]-p1[0],'bound':p0[0]*p1[1]-p1[0]*p0[1],'sense':'ge'}
    assert len(set(map(tuple,points)))==32 and max(sum(v*v for v in p) for p in points)<radius**2
    write(OUT/'checks.json',{'passed':True,'exact_integer_vertex_norms_checked':32,'exact_cross_product_checks':checks,'origin_strictly_inside':True,
        'all_vertices_and_their_convex_hull_strictly_inside_certified_original_disk':True,'necessary_original_shape_separation_only':True,'solver_calls':0,'H5_complete':False})
    print(load(OUT/'checks.json'),flush=True)
if __name__=='__main__':main()
