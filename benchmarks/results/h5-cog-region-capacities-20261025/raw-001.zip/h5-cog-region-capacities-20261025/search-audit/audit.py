"""Audit completed shared budgets and the actual simultaneous-anchor witness."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-region-capacities-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'search-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    inputs=[p for name in ['shared-search','disk-search'] for p in (BASE/name).rglob('*') if p.is_file()]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'audit_limit_seconds':60,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'method':'Verify both terminal one-master/one-coordinate pipelines stayed inside their declared shared60-second budget; compare every exported parameter to the recorded remaining allowance, source hashes, model hashes and stage results. Independently check the simultaneous cog-anchor assignment against every selected exact inward inequality, all coordinate/stock bounds and every same-sheet certified inner-polygon separation. This necessary witness does not override the full-original coordinate negative.'})
    records=[]
    for name in ['shared-search','disk-search']:
        root=BASE/name;plan=load(root/'plan.json');budget=load(root/'budget.json');result=load(root/'result.json')
        for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
        assert budget['shared_seconds']==60 and budget['deadline_perf_counter']==budget['start_perf_counter']+60
        assert result['status']=='ANCHORS_INFEASIBLE' and result['elapsed_seconds']<60 and result['master_solver_calls']==result['anchor_solver_calls']==1
        assert [r['stage'] for r in result['stages']]==['master','selection','anchors'] and all(r['exit_code']==0 for r in result['stages'])
        assert sum(r['seconds'] for r in result['stages'])<=result['elapsed_seconds']
        for folder,label in [('solve','master'),('anchor-solve','anchors')]:
            d=root/folder;model=load(d/'model-audit.json');opened=load(d/'opened.json');r=load(d/'result.json');p=text_format.Parse((d/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
            assert model['passed'] and digest(d/'model.pb')==model['model_sha256'] and digest(d/'parameters.pbtxt')==model['parameters_sha256']
            assert 0<p.max_time_in_seconds==min(60,model['remaining_shared_budget_at_parameter_set'])==opened['seconds_limit']<=60
            assert p.num_search_workers==8 and p.random_seed==0 and p.cp_model_presolve and p.cp_model_probing_level==0 and p.symmetry_level==0
            assert r['solver_calls']==1 and r['seconds']<=p.max_time_in_seconds
            assert r['status']==('OPTIMAL' if folder=='solve' else 'INFEASIBLE')
            assert model['construction_seconds']+model['audit_seconds']+r['seconds']<=next(x['seconds'] for x in result['stages'] if x['stage']==label)
            for n,h in load(d/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
        assert load(root/'selection-audit/checks.json')['passed'] and load(root/'selection-audit/regional-capacity-check.json')['passed'] and load(root/'selection-audit/second-sheet-check.json')['passed']
        records.append({'pipeline':name,'elapsed_seconds':result['elapsed_seconds'],'shared_seconds':60,'master_calls':1,'anchor_calls':1,'anchor_status':'INFEASIBLE','all_hashes_parameters_and_stage_bounds_verified':True})
    root=BASE/'disk-search';selected=load(root/'solve/selection.json')['movable_parts'];positions=load(root/'solve/necessary-cog-positions.json');disk=load(BASE/'disk-relaxation/polygon.json');spec=load(SOURCE/'plan.json')
    assert [p['part'] for p in positions]==[3,4,5,6,7,8];inside_checks=0;outside=[]
    for p in positions:
        s=selected[p['part']];assert s['profile']==9;x,y=p['x_units'],p['y_units'];assert isinstance(x,int) and isinstance(y,int)
        q=spec['queries'][s['query']];d=load(SOURCE/'queries'/f"{s['query']:03d}.json")['domains'][s['domain_row']]
        for b in [d['coordinate_bounds'],q['anchor_bounds_units1000']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
        for h in d['halfplanes']:assert h['a']*x+h['b']*y<=h['bound'];inside_checks+=1
    for a,b in combinations(positions,2):
        if selected[a['part']]['sheet']!=selected[b['part']]['sheet']:continue
        dx,dy=b['x_units']-a['x_units'],b['y_units']-a['y_units'];edges=[i for i,h in enumerate(disk['outside_halfplanes']) if h['a']*dx+h['b']*dy>=h['bound']];assert edges
        outside.append({'parts':[a['part'],b['part']],'difference_units':[dx,dy],'satisfied_necessary_edges':edges})
    write(OUT/'pipeline-checks.json',records);write(OUT/'necessary-cog-pairs.json',outside)
    checks={'passed':True,'seconds':time.perf_counter()-start,'shared_pipelines_verified':2,'total_master_calls':2,'total_coordinate_calls':2,
        'both_within_shared60_second_allowance':True,'simultaneous_cog_anchors_verified':6,'exact_inward_halfplanes_checked':inside_checks,'same_sheet_necessary_polygon_pairs_checked':len(outside),
        'full_original_selected_coordinates_infeasible_in_both_pipelines':True,'no_full_original_witness_claimed':True,'native_packing_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
