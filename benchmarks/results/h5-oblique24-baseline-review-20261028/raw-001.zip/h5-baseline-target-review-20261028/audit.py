"""Read-only recheck of the target and the original normal/common source layouts."""
from pathlib import Path
from hashlib import sha256
from statistics import median
from itertools import combinations
from datetime import datetime,timezone
import json,math,shutil,time,zipfile
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'benchmarks/results/h5-source-frontier-pilot-20261018';OUT=ROOT/'output/h5-baseline-target-review-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';TARGET=ROOT/'output/h5-contact-placement-selection-20261018/conditional-target.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();results=load(BASE/'results.json');rs=[r for r in results['records'] if r['job']=='m-mechanical-large-plates' and r['kerf_mm']==.2];assert len(rs)==9 and {(r['arm'],r['seed']) for r in rs}=={(a,s) for a in ['normal','baseline','candidate'] for s in range(3)};dataset=ROOT/'benchmarks/datasets/M/m-mechanical-large-plates.json';inputs=[BASE/'results.json',BASE/'whole-job-area.json',JOB,TARGET,dataset,ROOT/'benchmarks/datasets/cutting/manifest.json']+[BASE/r['archive'] for r in rs]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Re-read all9 retained laser large-plates archives from the frozen source-frontier pilot. Verify CRC, archive/layout/job hashes, identical original geometry and saved validation. Reconstruct every original outer and hole directly, identify actual hole-contained riders and filled-outer overlaps, and recompute the three-seed normal material median and unchanged1% target. This audit does not rerun a solver, adopt a different comparator, change PIH semantics, relax a guard or claim global source infeasibility.'})
reference=load(JOB);records=[];pair_count=hole_checks=0
for r in rs:
    p=BASE/r['archive'];assert digest(p)==r['archive_sha256'] and r['status']=='valid'
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None;job_data=z.read('nested/job.json');layout_data=z.read('nested/layout.json');job=json.loads(job_data);layout=json.loads(layout_data);validation=json.loads(z.read('validate-stdout.json'));assert digest(dataset)==r['job_sha256'] and sha256(job_data).hexdigest()==r['artifacts']['nested/job.json']==digest(JOB) and sha256(layout_data).hexdigest()==r['layout_sha256'];assert job==reference and validation['valid'];assert validation['metrics']==r['metrics']
    parts={p['id']:p for p in job['parts']};shapes=[];holes=[];keys=[]
    for placement in layout['placements']:
        key=[placement['part_id'],placement['copy_index']];keys.append(key);g=parts[placement['part_id']]['geometry'][0];t=placement['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        def ring(points):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in points]
        outer=Polygon(ring(g['outer']));assert outer.is_valid;shapes.append((placement['sheet_id'],key,outer))
        for hi,h in enumerate(g.get('holes',[])):holes.append((placement['sheet_id'],key,hi,Polygon(ring(h))))
    assert sorted(keys)==sorted([[p['id'],i] for p in job['parts'] for i in range(p['quantity'])])
    riders=[]
    for sheet,key,outer in shapes:
        owners=[]
        for hs,hkey,hi,hole in holes:
            if hs==sheet and hkey!=key:
                hole_checks+=1
                if hole.covers(outer):owners.append({'owner':hkey,'hole':hi})
        if owners:riders.append({'part':key,'owners':owners,'filled_outer_area_mm2':outer.area})
    overlaps=[]
    for (sa,ka,a),(sb,kb,b) in combinations(shapes,2):
        if sa!=sb:continue
        pair_count+=1;area=a.intersection(b).area
        if area>1e-7:overlaps.append({'parts':[ka,kb],'intersection_area_mm2':area})
    assert len(riders)==r['riders']==(21 if r['arm']=='normal' else 0)
    assert len(overlaps)==(21 if r['arm']=='normal' else 0)
    if riders:assert all(x['part'][0]=='insert' for x in riders) and abs(sum(x['filled_outer_area_mm2'] for x in riders)-415800)<1e-6
    records.append({'arm':r['arm'],'seed':r['seed'],'archive':r['archive'],'archive_sha256':r['archive_sha256'],'layout_sha256':r['layout_sha256'],'original_dataset_job_sha256':r['job_sha256'],'nested_job_sha256':r['artifacts']['nested/job.json'],'originals':len(shapes),'saved_validation_valid':True,'material_area_mm2':validation['metrics']['material_area'],'hole_riders':riders,'filled_outer_overlaps':overlaps})
normal=median(r['material_area_mm2'] for r in records if r['arm']=='normal');target=normal*1.01;prior=load(TARGET);assert math.isclose(target,prior['target_material_mm2'],rel_tol=0,abs_tol=1e-7);height=(target-4500000)/1500;top=height-6.5;assert math.isclose(top,prior['required_outline_top_mm'],rel_tol=0,abs_tol=1e-9)
write(OUT/'records.json',records);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_archives_verified':9,'original_parts_checked':sum(r['originals'] for r in records),'same_sheet_filled_outer_pairs_checked':pair_count,'hole_containment_checks':hole_checks,'normal_insert_riders_each_seed':21,'normal_rider_filled_area_mm2_each_seed':415800,'common_riders_each_seed':0,'normal_filled_outer_overlaps_each_seed':21,'common_filled_outer_overlaps_each_seed':0,'normal_median_material_area_mm2':normal,'unchanged_material_target_mm2':target,'unchanged_target_outline_top_mm':top,'original_parts_and_all_labels_unchanged':True,'normal_baseline_is_not_a_PIH_off_source_witness':True,'no_global_infeasibility_claimed':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
