"""Preserve the enlarged source construction and the unchanged baseline provenance."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-oblique24-baseline-review-20261028';OUT=ROOT/'benchmarks/results'/NAME;SOURCE=ROOT/'output/h5-oblique24-source-20261028';BASELINE=ROOT/'output/h5-baseline-target-review-20261028';FAILED=ROOT/'output/h5-baseline-target-review-initial-failure-20261028';PUB=SOURCE/'publication';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='fdefb3a7dd6f5359e360498d8f728af606e392ef' and not git('diff','HEAD','--name-only')
assert all(load(p)['passed'] for p in [SOURCE/'preflight/checks.json',SOURCE/'result-audit/checks.json',BASELINE/'checks.json'])
result=load(SOURCE/'result-audit/checks.json');assert not result['source_valid'] and result['source_summary']['pair_failures']==34 and result['source_summary']['stock_failures']==8
old=load(ROOT/'benchmarks/results/h5-short13-x-exclusion-20261028/publication-review.json');production=source_digest();assert production==old['production_digest'];readmes={n:digest(ROOT/n) for n in old['current_readmes']};assert readmes==old['current_readmes'];up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==old[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main=='541d5bc94c32d4852cc9146dbcc3ff3c6ef67e2d';jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [SOURCE,BASELINE,FAILED]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for n in ['prepare_h5_oblique24_source_20261028.py','audit_h5_oblique24_preflight_20261028.py','run_h5_oblique24_source_20261028.py','audit_h5_oblique24_result_20261028.py','audit_h5_baseline_target_20261028.py','h5_oblique_sliding_objective.py','h5_legacy64_source_readback.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for f in ['output','scripts']:
                    q=ROOT/f/(module+'.py')
                    if q.is_file():add('imported-helpers/'+f+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for p,n in [(SOURCE/'prepared.json','source-prepared.json'),(SOURCE/'preflight/checks.json','source-preflight.json'),(SOURCE/'search/result.json','source-search-result.json'),(SOURCE/'result-audit/checks.json','source-result-checks.json'),(BASELINE/'checks.json','baseline-target-checks.json'),(BASELINE/'records.json','baseline-source-records.json'),(FAILED/'diagnostics.json','baseline-reader-repair.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')]:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'main_CI':40685021297,'main_all6_pass':True,'normal_push_authorized_after_fresh_live_run_check':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'source_preflight_and_result_audits_passed':True,'all24_movers_and42_fixed_originals_accounted':True,'source66_valid':False,'source_pair_failures':34,'source_stock_failures':8,'source_search_calls':1,'source_search_closed':True,'baseline_archives_verified':9,'normal_hole_riders_each_seed':21,'common_hole_riders_each_seed':0,'material_target_unchanged':True,'infeasibility_claimed_from_source_failure':False,'remaining_necessary_allocations':452,'native_calls':0,'main_all6_pass':True,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='The new24-mover phase7 source search is closed at a local minimum after212 objective evaluations and one mode change: independent all66 readback finds34 pair failures and8 stock failures. Do not rerun, reseed or extend that model or resume the earlier17-mover model. The42-part core and22 pre-existing moving originals were independently valid before insertion; the larger domain did not produce a full witness. A read-only9-archive review confirms the target remains4988890.353494999mm2 and normal mode places all21 inserts in holes, while both common-line arms have zero riders. Thus the normal baseline is not a reusable PIH-OFF source witness, and no comparator or guard changes. The complete current count frontier remains452 survivors, after the proved short7/5/1 and7/6/1 exclusions. A concrete next action is a predeclared bounded screen of distinct remaining maximal short-count vectors with the audited source X-capacity formulation, adapting mandatory family counts while preserving every allowed mode and whole stock domain. Verify each serialized model before its sole call; never reopen7/5/1, keep every UNKNOWN or unprocessed allocation, and apply only verified subset/upward-closure exclusions to the complete452 list. A positive relaxed projection is not source feasibility. Use that evidence to choose a materially different whole source construction rather than another restart of the failed local model. Keep all66 originals, PIH OFF, material target and guards; native validation still requires a complete source-valid66. Main541d5bc9 now passes allsix jobs in40685021297, enabling a normal combined push of fdefb3a7 and this checkpoint after fresh remote, ancestry and no-live-run checks. H2 stays open under the explicit unchanged-gate decision,22 reserved vectors remain unopened, and no release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Whole upper-group source search and baseline target review — 2026-10-28

Freeing the whole upper group still produces **no valid 66-part layout**.
The one bounded source search ends at a local minimum, and the independent
original-shape reader finds 34 pair failures and eight stock failures. This
does not prove the enlarged construction domain impossible. The call is closed.

## Enlarged source construction

The fixed core contains 42 independently valid originals: 18 frames and inserts
5–15 on the first sheet, plus eight brackets and five inserts on the short sheet.
All 15 cogs, four first-sheet brackets and five upper inserts may move. Compared
with the previous 17-mover model, two existing corner brackets and five inserts
are now free. Every bracket retains all eight modes, every insert both outer
classes, and the cogs use the declared 7° phase. No part or stock requirement
changes, and the valid short-sheet allocation remains eight brackets/five inserts.

The rebuilt geometry has 11 fixed-neighbor free regions and 66 pair obstacles:
45 identical intrinsic obstacles are verified and reused, and 21 involving
inserts are new. Preflight reconstructs all 11 modes from original coordinates,
checks 1,089 source-pair samples and 11 free-region representatives, and verifies
all 48 gradient components. The 22 previously placed movers exactly match the
audited source64 layout. All 66 originals are accounted for once.

The sole call returns LOCAL_STATIONARY after two positional stages, 212 objective
evaluations, 66 mode trials and one accepted change. Search time is **0.074719 s**;
shared process time **2.892560 s**. There is one initial configuration and no
random restart. The independent readback checks 1,456 pairs, 264 stock edges and
all 90 holes with 10,026 hole vertices. It retains all 34 pair failures and eight
stock failures, including the worst extra stock clearance of −5.525542 mm.
Neither source validity, native validation nor H5 completion is claimed.

## Baseline provenance

A separate read-only review verifies the nine retained laser large-plates
archives: three seeds for normal, common baseline and common candidate modes.
CRC, archive hashes, layout hashes, both source-job hashes and saved validations
are checked. All 594 original placements are reconstructed, with 13,974 filled
outer pair checks and 36,884 hole-containment checks.

Each normal layout places **all 21 inserts inside holes**, totaling 415,800 mm²
of filled insert area. Each common-line layout has zero hole riders and zero
filled-outer overlaps. The normal baseline therefore cannot be reused directly
when holes must remain reserved. This is a provenance check, not a new benchmark
or a global infeasibility argument.

The normal three-seed material median is **4,939,495.3995 mm²**. Multiplying by
the unchanged 1.01 limit reproduces **4,988,890.353495 mm²**, and the target short
outline top remains **319.42690233 mm**. No comparator, seed, metric, allowance
or threshold is replaced.

The first review attempt compared a serialized-job hash with the record's
dataset-job hash. Its failed reader and diagnostic are preserved. The corrected
reader independently verifies each hash against its corresponding original file;
no source file or recorded hash changed and no solver was rerun.

## Next step and publication

The proven short-sheet 7/5/1 and 7/6/1 exclusions remain closed. All 452 remaining
count allocations are retained. Next screen distinct remaining maximal count
vectors with the audited source X-capacity model, using a declared bounded pass
and retaining every unknown or unprocessed case. Verified exclusions may prune
counts; positive relaxed assignments still require actual source construction.

Main `541d5bc9` now passes all six jobs in
[CI 40685021297](https://github.com/skulitom/Nestbolt/actions/runs/40685021297).
The count-exclusion checkpoint and this evidence can be pushed together after
fresh remote and live-run checks. Production, READMEs and upstream heads/releases
are unchanged. H2/H5 remain open at **60% completed milestone weight**; all 22
reserved H2 vectors remain unopened, and no new release qualifies.

[Source preflight]({NAME}/source-preflight.json),
[closed source result]({NAME}/source-result-checks.json),
[baseline checks]({NAME}/baseline-target-checks.json),
[original baseline records]({NAME}/baseline-source-records.json),
[next step]({NAME}/next-step.json),
[byte-verified archive]({NAME}/raw-manifest.json).
The archive preserves {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including all source inputs, original comparator archives,
new free regions, every reused obstacle, auditors, raw failures and provenance
repair records.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 whole upper-group source search, 2026-10-28:** [the evidence]({link})
frees all 24 upper-group originals around the independently valid 42-part core,
including the two existing corner brackets and five inserts fixed previously.
All source-mode, free-region and 48 gradient checks pass. The sole local call
closes after 212 evaluations / one mode change in 0.074719 search / 2.892560 shared
seconds. Original all66 readback retains 34 pair failures and eight stock failures;
this is no source witness or infeasibility proof. A read-only nine-archive baseline
review confirms 21 insert hole-riders in each normal layout and none in common
mode, so the normal layout is not a reusable PIH-OFF witness. The original
4,988,890.353495 mm² material target remains unchanged. Next use the verified
X-capacity formulation on distinct remaining maximal short-count vectors,
retaining unknown/unprocessed cases and all 452 current candidates until excluded.
Main541d5bc9 now passes all six CI jobs; the two queued checkpoints may be normally
pushed after fresh remote/live-run checks. Production, READMEs and upstream
releases are unchanged. H2/H5 stay open at 60%; all 22 reserved vectors remain
unopened, and no new release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'bound_source_inputs':len(bindings),'main_all6_pass':True,'completion_percent':60})
