"""Free the whole24-original upper packet around the independently valid42-part core."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time
from shapely.geometry import Polygon,shape,mapping
from shapely.affinity import affine_transform,translate
import diagnose_h5_concave_gaps as geom
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-oblique24-source-20261028';BASE=ROOT/'output/h5-oblique64-source-20261028';OLD=ROOT/'output/h5-oblique-joint-source-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'free').mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();deadline=start+120
assert load(BASE/'audit/checks.json')['passed'] and load(OLD/'result-audit/checks.json')['passed'];job=load(JOB);parts={p['id']:p for p in job['parts']};source=load(BASE/'source64.json');required=.21170867250963943;geom.EPS=.0126
released={('cog',i) for i in range(15)}|{('bracket',i) for i in range(8,12)}|{('insert',i) for i in range(16,21)};fixed=[r for r in source if (r['part_id'],r['copy_index']) not in released];assert len(fixed)==42 and sum(r['sheet_id']=='sheet-0' for r in fixed)==29
inputs=[JOB,BASE/'source64.json',BASE/'audit/checks.json',OLD/'modes.json',OLD/'moving.json',OLD/'result-audit/checks.json',Path(geom.__file__),ROOT/'output/h5_oblique_sliding_objective.py',ROOT/'benchmarks/results/h5-short13-x-exclusion-20261028/updated-allocations.json']+[OLD/'obstacles'/f'{i:02d}-{j:02d}.json' for i in range(9) for j in range(i,9)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'preparation_seconds':120,'search_seconds':60,'shared_search_seconds':90,'maximum_positional_stages':8,'per_stage_maximum_iterations':1000,'per_stage_maximum_function_evaluations':2500,'initial_configurations':1,'random_restarts':0,'retry_permitted':False,'finite_cog_phases_degrees':[7.0],'allowed_bracket_modes':8,'insert_outer_classes':2,'required_pair_gap_mm':required,'stock_guard_mm':3000*32*2**-23,'construction_eps_mm':geom.EPS,'method':'A materially larger source neighborhood than the closed phase7 seventeen-mover model: retain only the independently valid42-part core, comprising18 frames and first-sheet inserts5..15 plus all13 valid short-sheet originals(8 brackets,5 inserts). All15 phase7 cogs, all4 first-sheet brackets8..11 and all5 upper inserts16..20 may slide; every bracket may use all8 legal modes and every insert both outer classes. The two existing corner brackets and allfive upper inserts are now free. Rebuild every fixed-neighbor region against only29 first-sheet originals; reuse45 intrinsic pair obstacles only because their exact source shapes and gap are unchanged, then add21 insert-involving obstacles. Preserve the22 existing moving originals at their audited source64 poses and place the two missing brackets at the same declared bottom-corner anchors as the earlier17-mover construction, so the domain change is explicit. One60-second deterministic L-BFGS/mode-descent call, at most8 stages, with one initial state and no random restart or resumed old run. Independent all66 original-ring readback is required; no native call unless it fully passes. Earlier short7/5/1 and7/6/1 exclusions remain closed; this construction retains the valid8/5/0 short allocation.'})
def poly(family,a,mir):
    c,s=math.cos(a),math.sin(a);m=-1 if mir else 1;return affine_transform(Polygon(parts[family]['geometry'][0]['outer']),[m*c,-s,m*s,c,0,0])
def world(r):return translate(poly(r['part_id'],r['transform']['rotation_radians'],r['transform']['mirrored']),*r['transform']['translation'])
modes=load(OLD/'modes.json');shapes=[shape(m['geometry']) for m in modes]
for angle in [0.,math.pi/2]:
    g=poly('insert',angle,False);offset=[-g.bounds[0],-g.bounds[1]];g=translate(g,*offset);modes.append({'index':len(modes),'family':'insert','angle':angle,'mirrored':False,'source_translation_offset':offset,'geometry':mapping(g)});shapes.append(g)
fixed_first=[world(r) for r in fixed if r['sheet_id']=='sheet-0'];assert len(shapes)==11 and len(fixed_first)==29
for i,g in enumerate(shapes):
    assert time.perf_counter()<deadline;free=geom.regions(g,fixed_first,job['stocks'][0],job['edge_clearance'],required);assert not free.is_empty and free.is_valid;write(OUT/'free'/f'{i:02d}.json',mapping(free))
reused={};new=0
for i,g in enumerate(shapes):
    for j in range(i,len(shapes)):
        assert time.perf_counter()<deadline
        if j<9:
            p=OLD/'obstacles'/f'{i:02d}-{j:02d}.json';shutil.copyfile(p,OUT/'obstacles'/p.name);reused[p.relative_to(ROOT).as_posix()]=digest(p)
        else:
            obstacle=geom.obstacle(g,shapes[j],required);assert not obstacle.is_empty and obstacle.is_valid;write(OUT/'obstacles'/f'{i:02d}-{j:02d}.json',mapping(obstacle));new+=1
moving=[]
for family,copies in [('cog',range(15)),('bracket',range(8,12)),('insert',range(16,21))]:
    for copy in copies:
        old=next((r for r in source if r['part_id']==family and r['copy_index']==copy),None)
        if old:
            t=old['transform'];mi=next(m['index'] for m in modes if m['family']==family and m['angle']==t['rotation_radians'] and m['mirrored']==t['mirrored']);anchor=[t['translation'][k]-modes[mi]['source_translation_offset'][k] for k in range(2)]
        else:
            initial=next(r for r in load(OLD/'moving.json') if r['family']==family and r['copy_index']==copy);mi=initial['initial_mode'];anchor=initial['initial_anchor']
        moving.append({'original':(51 if family=='cog' else 18 if family=='bracket' else 30)+copy,'family':family,'copy_index':copy,'allowed_modes':[m['index'] for m in modes if m['family']==family],'initial_mode':mi,'initial_anchor':anchor,'previously_source_valid':old is not None})
assert len(moving)==24 and sum(r['previously_source_valid'] for r in moving)==22 and len(reused)==45 and new==21
write(OUT/'modes.json',modes);write(OUT/'fixed42.json',fixed);write(OUT/'moving.json',moving);write(OUT/'reused-intrinsic-obstacles.json',reused)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'modes':11,'free_regions':11,'unordered_configuration_obstacles':66,'intrinsic_obstacles_reused':45,'new_insert_pair_obstacles':21,'moving_originals':24,'position_variables':48,'fixed_first_originals':29,'fixed_short_originals':13,'all66_originals_accounted':True,'previously_fixed_originals_now_free':7,'optimizer_opened':False,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'))
