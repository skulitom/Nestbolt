"""Retain the completed bounded search and independently read all66 original outlines."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
import numpy as np
from h5_oblique_sliding_objective import SlidingObjective
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-oblique24-source-20261028';SEARCH=BASE/'search';OUT=BASE/'result-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(SEARCH/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'preflight/checks.json')['passed'];plan=load(BASE/'plan.json');result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');best=load(SEARCH/'best.json');obj=SlidingObjective(BASE)
assert result['closed'] and result['initial_configurations']==1 and result['random_restarts']==0 and result['all24_movers_mandatory'] and process['exit_code']==0 and not process['timeout'] and process['seconds']<90 and result['search_seconds']<60
assert len(load(SEARCH/'position-stages.json'))==result['positional_stages_returned']<=8
assert len(load(SEARCH/'mode-trials.json'))==result['mode_trials'] and len(load(SEARCH/'accepted-mode-changes.json'))==result['accepted_mode_changes']
value,gradient,diag=obj.evaluate(np.asarray(best['anchors']).reshape(-1),best['modes']);assert abs(value-best['value'])<1e-8 and diag==best['diagnostics'] and value==result['best_value']
moving=load(SEARCH/'best-moving-placements.json');assert moving==obj.placements(best['anchors'],best['modes'])
fixed=load(BASE/'fixed42.json');moving_keys={(r['part_id'],r['copy_index']) for r in moving};assert fixed==[r for r in load(ROOT/'output/h5-oblique64-source-20261028/source64.json') if (r['part_id'],r['copy_index']) not in moving_keys];assert len(fixed)==42 and len(moving)==24;rows=fixed+moving;job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json')
expected=[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])];stocks={'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.4269023299994]}
readback=audit(job,rows,stocks,plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected);write(OUT/'all66-source-candidate.json',rows);write(OUT/'source-readback.json',readback)
summary={k:v for k,v in readback.items() if k not in ['pairs','stock']}
write(OUT/'failed-source-pairs.json',[r for r in readback['pairs'] if not r['passed']]);write(OUT/'failed-source-stock.json',[r for r in readback['stock'] if not r['passed']])
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':result['status'],'objective_evaluations':result['objective_evaluations'],'search_seconds':result['search_seconds'],'shared_seconds':process['seconds'],'fixed42_unchanged':True,'all66_originals_accounted':True,'source_summary':summary,'source_valid':readback['valid'],'closed_search_not_repeated':True,'infeasibility_claimed':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
