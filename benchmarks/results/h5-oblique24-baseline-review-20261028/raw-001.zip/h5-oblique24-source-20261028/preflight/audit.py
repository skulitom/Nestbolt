"""Independent original-source checks before the sole24-mover construction call."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon,Point,shape
from shapely.affinity import translate
from h5_oblique_sliding_objective import SlidingObjective
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-oblique24-source-20261028';OUT=BASE/'preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={r['id']:r for r in job['parts']};fixed=load(BASE/'fixed42.json');obj=SlidingObjective(BASE);modes=obj.modes;required=plan['required_pair_gap_mm'];guard=plan['stock_guard_mm']
def polygon(family,t):
    a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[family]['geometry'][0]['outer']])
originals=[]
for i,mode in enumerate(modes):
    g=polygon(mode['family'],{'rotation_radians':mode['angle'],'mirrored':mode['mirrored'],'translation':mode['source_translation_offset']})
    assert g.equals_exact(shape(mode['geometry']),1e-10) and g.is_valid;originals.append(g)
assert len(modes)==11 and [m['family'] for m in modes]==['cog']+['bracket']*8+['insert']*2
assert modes[0]['angle']==math.radians(7)
assert {(m['angle'],m['mirrored']) for m in modes[1:9]}=={(q*math.pi/2,m) for q in range(4) for m in [False,True]}
assert {(m['angle'],m['mirrored']) for m in modes[9:]}=={(0.,False),(math.pi/2,False)}
prior_modes=load(ROOT/'output/h5-oblique-joint-source-20261028/modes.json');assert modes[:9]==prior_modes
for n,h in load(BASE/'reused-intrinsic-obstacles.json').items():
    assert digest(ROOT/n)==h and (ROOT/n).read_bytes()==(BASE/'obstacles'/Path(n).name).read_bytes()
assert len(fixed)==42 and len(obj.moving)==24 and sum(r['sheet_id']=='sheet-0' for r in fixed)==29
stocks={'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.4269023299994]}
fixed_read=audit(job,fixed,stocks,required,guard);assert fixed_read['valid'];write(OUT/'fixed42-readback.json',fixed_read)
placed_fixed=[polygon(r['part_id'],r['transform']) for r in fixed if r['sheet_id']=='sheet-0'];free_samples=[]
for i,g in enumerate(originals):
    reg=obj.free[i];components=[reg] if reg.geom_type=='Polygon' else list(reg.geoms)
    for component in components:
        pt=component.representative_point();xy=list(pt.coords)[0];placed=translate(g,*xy);b=placed.bounds;extra=[b[0]-6.5,b[1]-6.5,1493.5-b[2],2993.5-b[3]];gap=min(placed.distance(f) for f in placed_fixed)
        assert min(extra)>guard and gap>required
        free_samples.append({'mode':i,'anchor':xy,'minimum_source_gap_mm':gap,'minimum_stock_extra_mm':min(extra)})
write(OUT/'free-samples.json',free_samples)
samples=[]
for i,a in enumerate(originals):
    for j,b in enumerate(originals):
        obstacle=obj.obstacles[i*len(modes)+j]
        for dx,dy in [(-350,-250),(-250,0),(-150,120),(0,0),(150,-120),(250,0),(350,250),(0,350),(0,-350)]:
            gap=a.distance(translate(b,dx,dy));inside=obstacle.covers(Point(dx,dy))
            if not inside:assert gap>required
            if gap<=required:assert inside
            samples.append({'modes':[i,j],'delta':[dx,dy],'source_gap_mm':gap,'inside_configuration_obstacle':bool(inside)})
write(OUT/'pair-samples.json',samples)
mi=[r['initial_mode'] for r in obj.moving];x=np.asarray([r['initial_anchor'] for r in obj.moving]).reshape(-1)
prior=load(ROOT/'output/h5-oblique64-source-20261028/source64.json');placed=obj.placements(x,mi)
for item,r in zip(obj.moving,placed):
    if not item['previously_source_valid']:continue
    old=next(z for z in prior if (z['part_id'],z['copy_index'])==(r['part_id'],r['copy_index']))
    assert polygon(r['part_id'],r['transform']).equals_exact(polygon(old['part_id'],old['transform']),1e-9)
allkeys=[(r['part_id'],r['copy_index']) for r in fixed+placed];expected=[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])];assert sorted(allkeys)==sorted(expected) and len(set(allkeys))==66
value,gradient,diag=obj.evaluate(x,mi);h=1e-5;errors=[]
for k in range(len(x)):
    up=x.copy();down=x.copy();up[k]+=h;down[k]-=h
    numeric=(obj.evaluate(up,mi)[0]-obj.evaluate(down,mi)[0])/(2*h);error=abs(numeric-gradient[k]);assert error<.003;errors.append(float(error))
initial_read=audit(job,fixed+placed,stocks,required,guard,expected);write(OUT/'initial66-readback.json',initial_read)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_source_modes_checked':11,'source_pair_obstacle_samples':len(samples),'free_region_source_samples':len(free_samples),'gradient_components_checked':len(errors),'maximum_gradient_error':max(errors),'all66_originals_accounted':True,'fixed42_source_valid':True,'all22_existing_movers_match_audited64':True,'initial_objective':value,'initial_diagnostics':diag,'initial_source_pair_failures':initial_read['pair_failures'],'initial_source_stock_failures':initial_read['stock_failures'],'external_solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
