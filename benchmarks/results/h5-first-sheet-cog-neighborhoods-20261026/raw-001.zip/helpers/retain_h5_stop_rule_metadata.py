"""Retain only commit metadata needed for upstream stop-rule checks."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first-sheet-source-review-20261026'
for name in ['sparrow-main.json','studio-main.json']:
    path=BASE/name;record=json.loads(path.read_bytes());data=json.loads(record['stdout'])
    retained={'sha':data['sha'],'date':data['commit']['committer']['date'],'html_url':data['html_url']}
    record['stdout']=json.dumps(retained,separators=(',',':'))+'\n';record['retained_fields']=['sha','commit.committer.date','html_url'];record['unneeded_source_diffs_omitted']=True
    with path.open('w',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print({'upstream_metadata_snapshots':2,'source_diffs_retained':False})
