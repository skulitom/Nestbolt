"""Prepare a new original-cog57/58 region census with four other poses fixed."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first-pair-regions-20261026';OUT.mkdir();records=[]
for kind in ['prove','audit']:
    source=ROOT/'output'/f'{kind}_h5_two_cog_regions.py';s=source.read_text(encoding='utf-8')
    replacements={
        'PART=7;RELEASED=[7,8]':'PART=4;RELEASED=[4,5]',
        'h5-two-cog-regions-20261026':'h5-first-pair-regions-20261026',
        'release-7-8':'release-4-5',
        "[spec['parts'][i] for i in [0,1,2,7,8]]":"[spec['parts'][i] for i in [0,1,2,4,5]]",
        'original cogs64/65 both released and original cogs54/57/58/62':'original cogs57/58 both released and original cogs54/62/64/65',
        'Both released cogs follow all four retained cog indices, so their moving-versus-fixed source clauses and domains are identical and represented once;':'Both released cog indices follow fixed cog3 and precede fixed cogs6/7/8, so their moving-versus-fixed source clauses and domains are identical and represented once;',
        'original cogs64/65 released. Both released cogs have identical source domains and original pair direction against the four earlier fixed cogs.':'original cogs57/58 released. Both released cogs have identical source domains and original pair direction against fixed cogs3/6/7/8; one fixed index precedes both and three follow both.',
    }
    applied={}
    for a,b in replacements.items():
        if a in s:s=s.replace(a,b);applied[a]=b
    assert 'PART=4;RELEASED=[4,5]' in s and 'release-4-5' in s
    dest=ROOT/'output'/f'{kind}_h5_first_pair_regions.py';compile(s,str(dest),'exec')
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':source.relative_to(ROOT).as_posix(),'source_sha256':sha256(source.read_bytes()).hexdigest(),'target':dest.relative_to(ROOT).as_posix(),'target_sha256':sha256(dest.read_bytes()).hexdigest(),'replacements':applied})
with (OUT/'helper-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'helpers':records,'released_parts':[4,5],'released_originals':[57,58],'fixed_cog_parts':[3,6,7,8],'mandatory_originals':66,'distinct_preparation':True,'solver_calls':0},f,indent=2);f.write('\n')
with (OUT/'budget.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':60,'deadline_perf_counter':time.perf_counter()+60,'solver_calls':0,'offline_not_production_qualification':True},f,indent=2);f.write('\n')
print({'prepared':str(OUT),'helpers':2},flush=True)
