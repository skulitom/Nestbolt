"""Capture current repository, upstream stop-rule and terminal main-CI evidence."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first-sheet-source-review-20261026';OUT.mkdir();sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
from pack_h5_evidence_archive import digest
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def run(args,name):
    p=subprocess.run(args,cwd=ROOT,capture_output=True,text=True);write(OUT/(name+'.json'),{'utc':datetime.now(timezone.utc).isoformat(),'args':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});p.check_returncode();return p.stdout.strip()
head=run(['git','rev-parse','HEAD'],'head');run(['git','fetch','origin','main'],'fetch');main=run(['git','rev-parse','origin/main'],'main');assert main=='822a5f67428e6dfdecab7bcea45e7c89cc31b159';assert run(['git','rev-list','--left-right','--count','origin/main...HEAD'],'ahead').split()==['0','3'];assert not run(['git','diff','HEAD','--name-only'],'tracked')
ci=json.loads(run(['gh','run','view','40248595273','--json','databaseId,status,conclusion,headSha,jobs,url'],'main-ci'));assert ci['headSha']==main and ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==6 and all(j['conclusion']=='success' for j in ci['jobs'])
sparrow=json.loads(run(['gh','api','repos/JeroenGar/sparrow/commits/main'],'sparrow-main'));studio=json.loads(run(['gh','api','repos/JeroenGar/sparrow-studio/commits/main'],'studio-main'));release=json.loads(run(['gh','api','repos/JeroenGar/sparrow/releases/latest'],'sparrow-release'));studio_releases=json.loads(run(['gh','api','repos/JeroenGar/sparrow-studio/releases?per_page=1'],'studio-releases'))
assert sparrow['sha']=='1fe3e3146110c34d77510636defb737c7ce893c6' and studio['sha']=='c0bb9e8671defc5c25a02feb91789601a08f2e75' and release['tag_name']=='v0.3.0'
prior=json.loads((ROOT/'benchmarks/results/h5-two-cog-source-focus-20261026/source-review.json').read_bytes());assert source_digest()==prior['production_digest'] and all(digest(ROOT/n)==h for n,h in prior['current_readmes'].items())
write(OUT/'review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'main_head':main,'production_digest':source_digest(),'current_readmes':prior['current_readmes'],'sparrow_head':sparrow['sha'],'studio_head':studio['sha'],'sparrow_release':release['tag_name'],'studio_latest_release':[{k:r.get(k) for k in ['tag_name','published_at','html_url']} for r in studio_releases],'upstream_heads_and_sparrow_release_unchanged':True,'main_ci_id':40248595273,'main_ci_status':ci['status'],'main_ci_conclusion':ci['conclusion'],'main_ci_successful_jobs':6,'source_and_readmes_unchanged':True,'no_new_release_qualified':True,'completion_percent':60,'H2_complete':False,'H5_complete':False,'reserved_H2_vectors_evaluated':0})
print(json.loads((OUT/'review.json').read_bytes()),flush=True)
