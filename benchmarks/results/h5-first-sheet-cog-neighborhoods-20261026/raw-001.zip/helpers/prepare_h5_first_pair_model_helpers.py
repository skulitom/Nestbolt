"""Prepare distinct five-mover model helpers for original cogs57/58."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];records=[]
for srcname,dstname in [('prepare_h5_two_cog_fixed_source_model.py','prepare_h5_first_pair_source_model.py'),('audit_h5_two_cog_fixed_source_model.py','audit_h5_first_pair_source_model.py')]:
    src=ROOT/'output'/srcname;s=src.read_text(encoding='utf-8');replacements={
        'h5-two-cog-fixed-source-model-20261026':'h5-first-pair-source-model-20261026',
        'h5-two-cog-regions-20261026/release-7-8':'h5-first-pair-regions-20261026/release-4-5',
        '[3,4,5,6]':'[3,6,7,8]',
        '[0,1,2,7,8]':'[0,1,2,4,5]',
        '{0,1,2,7,8}':'{0,1,2,4,5}',
        "regplan['released_cog_parts']==[7,8]":"regplan['released_cog_parts']==[4,5]",
        "spec['parts'][7]['queries']==spec['parts'][8]['queries']==[18,19] and all(p['part']<7 for p in fixed)":"spec['parts'][4]['queries']==spec['parts'][5]['queries']==[18,19] and all((p['part']<4)==(p['part']<5) for p in fixed)",
        'assert len(allowed)==173':"assert len(allowed)==load(REG/'result.json')['residual_domains']",
        'four retained first-sheet cog witnesses':'four retained cog witnesses on both sheets',
        'Cogs64/65, both brackets and insert':'Cogs57/58, both brackets and insert',
        'released cogs7/8 against fixed3..6':'released cogs4/5 against fixed3/6/7/8',
    };applied={}
    for a,b in replacements.items():
        if a in s:s=s.replace(a,b);applied[a]=b
    assert 'h5-first-pair-source-model-20261026' in s and 'h5-first-pair-regions-20261026/release-4-5' in s
    dest=ROOT/'output'/dstname;compile(s,str(dest),'exec')
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dest.relative_to(ROOT).as_posix(),'target_sha256':sha256(dest.read_bytes()).hexdigest(),'replacements':applied})
with (ROOT/'output/h5-first-pair-regions-20261026/model-helper-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'helpers':records,'solver_calls':0},f,indent=2);f.write('\n')
print({'model_helpers_prepared':2,'solver_calls':0})
