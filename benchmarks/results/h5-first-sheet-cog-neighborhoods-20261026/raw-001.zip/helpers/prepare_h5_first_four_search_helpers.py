"""Prepare one bounded call for all four first-sheet cogs plus three missing parts."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first-four-source-model-20261026'
assert json.loads((BASE/'audit/checks.json').read_bytes())['passed'];records=[]
for srcname,dstname in [('run_h5_first_three_source_search.py','run_h5_first_four_source_search.py'),('audit_h5_first_three_source_search.py','audit_h5_first_four_source_search.py')]:
    src=ROOT/'output'/srcname;s=src.read_text(encoding='utf-8');replacements={
        'h5-first-three-source-search-20261026':'h5-first-four-source-search-20261026',
        'h5-first-three-source-model-20261026':'h5-first-four-source-model-20261026',
        'h5-first-three-regions-20261026/release-4-5-6':'h5-first-four-regions-20261026/release-3-4-5-6',
        '379893':'376774',
        "'mandatory_moving_originals':6":"'mandatory_moving_originals':7",
        "'fixed_originals':60":"'fixed_originals':59",
        "'fixed_cog_coordinate_pairs':3":"'fixed_cog_coordinate_pairs':2",
        'six coordinate equalities':'four coordinate equalities',
        'original cogs54/64/65':'original cogs64/65',
        '3524':'407',
        'Original cogs57/58/62':'Original cogs54/57/58/62',
        'six movable':'seven movable',
        'six moving':'seven moving',
        'six movers':'seven movers',
        'and60 fixed':'and59 fixed',
        'fixed60':'fixed59',
        'three-cog focus':'four-cog focus',
        "['three_fixed_cog_positions']":"['two_fixed_cog_positions']",
        '[3,7,8]':'[7,8]',
    };applied={}
    for a,b in replacements.items():
        if a in s:s=s.replace(a,b);applied[a]=b
    dst=ROOT/'output'/dstname;compile(s,str(dst),'exec')
    with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dst.relative_to(ROOT).as_posix(),'target_sha256':sha256(dst.read_bytes()).hexdigest(),'replacements':applied})
with (BASE/'search-helper-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'helpers':records,'maximum_solver_calls':1,'solver_cap_seconds':45,'shared_import_audit_search_seconds':60,'shutdown_reserve_seconds':10,'previous_calls_remain_closed':True},f,indent=2);f.write('\n')
print({'search_helpers_prepared':2,'solver_calls':0})
