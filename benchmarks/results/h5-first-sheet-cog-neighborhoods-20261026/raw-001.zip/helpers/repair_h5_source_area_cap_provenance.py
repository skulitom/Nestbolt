"""Resolve the retained fixed-geometry audit in its original committed archive."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-area-caps-20261026';src=ROOT/'output/audit_h5_source_area_caps.py';dst=ROOT/'output/audit_h5_source_area_caps_repaired.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
known=set()
for name in ['h5-bounded-source-search-20261026','h5-fixed-six-completion-20261026','h5-guarded-cell-search-20261025']:
    m=load(ROOT/'benchmarks/results'/name/'raw-manifest.json');known.update(r['sha256'] for r in m['files']+m['aliases'])
missing=[n for n,h in load(BASE/'plan.json')['inputs'].items() if h not in known]
assert missing==['output/h5-guarded-source-adjustment-20261025/audit/checks.json']
older=ROOT/'benchmarks/results/h5-guarded-source-adjustment-20261025/raw-manifest.json';m=load(older);olderhashes={r['sha256'] for r in m['files']+m['aliases']}
for n in missing:assert digest(ROOT/n)==load(BASE/'plan.json')['inputs'][n] and digest(ROOT/n) in olderhashes
s=src.read_text(encoding='utf-8');a="OUT=BASE/'audit'";assert s.count(a)==1;s=s.replace(a,"OUT=BASE/'audit-provenance-repaired'");a="'h5-guarded-cell-search-20261025']";assert s.count(a)==1;s=s.replace(a,"'h5-guarded-cell-search-20261025','h5-guarded-source-adjustment-20261025']")
with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (BASE/'audit/provenance-repair.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'failure':'AssertionError: output/h5-guarded-source-adjustment-20261025/audit/checks.json','stage':'Committed input lookup before independent area math or geometry checks','missing_inputs':missing,'earlier_manifest':older.relative_to(ROOT).as_posix(),'earlier_manifest_sha256':digest(older),'initial_source':src.relative_to(ROOT).as_posix(),'initial_source_sha256':digest(src),'repaired_source':dst.relative_to(ROOT).as_posix(),'repaired_source_sha256':digest(dst),'completed_geometry_work_repeated':False,'solver_calls':0},f,indent=2);f.write('\n')
print({'resolved_inputs':missing,'solver_calls':0})
