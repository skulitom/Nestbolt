"""Prepare complete original-source readback for the new closed-call result."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];src=ROOT/'output/audit_h5_bounded_source_search.py';dst=ROOT/'output/audit_h5_first_pair_source_search.py';s=src.read_text(encoding='utf-8')
replacements={
    'h5-bounded-source-search-20261026':'h5-first-pair-source-search-20261026',
    "'mandatory_moving_originals':9,'fixed_originals':57":"'mandatory_moving_originals':5,'fixed_originals':61,'fixed_cog_coordinate_pairs':4",
    'fixed57 construction':'fixed61 construction with inherited parent copy ordering',
    "verified=[{**p,**xy} for p,xy in zip(parts,positions)];write(OUT/'verified-original-positions.json',verified)":"verified=[{**p,**xy} for p,xy in zip(parts,positions)]\n        fixed=load(ROOT/'output/h5-first-pair-regions-20261026/release-4-5/plan.json')['four_fixed_cog_positions']\n        assert [p['part'] for p in fixed]==[3,6,7,8]\n        for p in fixed:assert positions[p['part']]['x_units']==p['x_units'] and positions[p['part']]['y_units']==p['y_units'] and parts[p['part']]['sheet']==p['sheet']\n        write(OUT/'verified-original-positions.json',verified)",
}
for a,b in replacements.items():assert a in s,a;s=s.replace(a,b)
marker="    write(OUT/'plan.json',"
assert s.count(marker)==1
s=s.replace(marker,"    inputs += [ROOT/'output/h5-first-pair-regions-20261026/release-4-5/plan.json',ROOT/'output/h5-first-pair-source-model-20261026/audit/checks.json']\n"+marker)
compile(s,str(dst),'exec')
with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (ROOT/'output/h5-first-pair-source-model-20261026/readback-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dst.relative_to(ROOT).as_posix(),'target_sha256':sha256(dst.read_bytes()).hexdigest(),'replacements':replacements,'extra_input_sources_recorded':True,'solver_calls':0},f,indent=2);f.write('\n')
print({'readback_prepared':str(dst)})
