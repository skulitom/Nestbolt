"""Prepare the full first-sheet cog neighborhood as one distinct case."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first-four-regions-20261026';OUT.mkdir();records=[]
jobs=[(f'{k}_h5_first_three_regions.py',f'{k}_h5_first_four_regions.py') for k in ['prove','audit']]+[('prepare_h5_first_three_source_model.py','prepare_h5_first_four_source_model.py'),('audit_h5_first_three_source_model.py','audit_h5_first_four_source_model.py')]
for srcname,dstname in jobs:
    src=ROOT/'output'/srcname;s=src.read_text(encoding='utf-8');replacements={
        'PART=4;RELEASED=[4,5,6]':'PART=3;RELEASED=[3,4,5,6]',
        'h5-first-three-regions-20261026':'h5-first-four-regions-20261026',
        'h5-first-three-source-model-20261026':'h5-first-four-source-model-20261026',
        'release-4-5-6':'release-3-4-5-6',
        '[0,1,2,4,5,6]':'[0,1,2,3,4,5,6]',
        '{0,1,2,4,5,6}':'{0,1,2,3,4,5,6}',
        '[3,7,8]':'[7,8]',
        'len(six)==3':'len(six)==2',
        'three_fixed_cog_positions':'two_fixed_cog_positions',
        'three_fixed_witness_poses':'two_fixed_witness_poses',
        'conditional_on_three_fixed_positions':'conditional_on_two_fixed_positions',
        'conditional on three verified cog poses':'conditional on two verified cog poses',
        'original cogs57/58/62 all released and original cogs54/64/65':'original cogs54/57/58/62 all released and original cogs64/65',
        'all three released cogs are mandatory (six movers,60 fixed originals)':'all four released cogs are mandatory (seven movers,59 fixed originals)',
        'All three released cog indices follow fixed cog3 and precede fixed cogs7/8':'All four released cog indices precede fixed cogs7/8',
        'they remain three separate mandatory parts':'they remain four separate mandatory parts',
        'three cogs fixed and original cogs57/58/62 released. All three released cogs have identical source domains and original pair direction against fixed cogs3/7/8; one fixed index precedes all three and two follow them. All three remain separate mandatory parts. These regions do not establish simultaneous placement of the six movers':'two cogs fixed and original cogs54/57/58/62 released. All four released cogs have identical source domains and original pair direction against later fixed cogs7/8. All four remain separate mandatory parts. These regions do not establish simultaneous placement of the seven movers',
        'three selected cog poses fixed':'two selected cog poses fixed',
        "regplan['released_cog_parts']==[4,5,6]":"regplan['released_cog_parts']==[3,4,5,6]",
        "spec['parts'][4]['queries']==spec['parts'][5]['queries']==spec['parts'][6]['queries']==[18,19] and all((p['part']<4)==(p['part']<i) for p in fixed for i in [4,5,6])":"spec['parts'][3]['queries']==spec['parts'][4]['queries']==spec['parts'][5]['queries']==spec['parts'][6]['queries']==[18,19] and all((p['part']<3)==(p['part']<i) for p in fixed for i in [3,4,5,6])",
        "'fixed_originals':60":"'fixed_originals':59",
        "'moving_originals':6":"'moving_originals':7",
        "'appended_coordinate_equalities':6":"'appended_coordinate_equalities':4",
        "'exact_fixed_coordinate_equalities':6":"'exact_fixed_coordinate_equalities':4",
        'three retained cog witnesses on both sheets':'two retained cog witnesses on the second sheet',
        'Cogs57/58/62, both brackets and insert':'Cogs54/57/58/62, both brackets and insert',
        'The other three cogs and57 source originals are fixed':'The other two cogs and57 source originals are fixed',
        'fixed60':'fixed59',
        'released cogs4/5/6 against fixed3/7/8':'released cogs3/4/5/6 against fixed7/8',
        'three-cog domain census':'four-cog domain census',
        'three-cog region census':'four-cog region census',
    };applied={}
    for a,b in replacements.items():
        if a in s:s=s.replace(a,b);applied[a]=b
    dst=ROOT/'output'/dstname;compile(s,str(dst),'exec')
    with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dst.relative_to(ROOT).as_posix(),'target_sha256':sha256(dst.read_bytes()).hexdigest(),'replacements':applied})
with (OUT/'helper-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'helpers':records,'released_parts':[3,4,5,6],'released_originals':[54,57,58,62],'fixed_cog_parts':[7,8],'mandatory_originals':66,'distinct_preparation':True,'solver_calls':0},f,indent=2);f.write('\n')
with (OUT/'budget.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':60,'deadline_perf_counter':time.perf_counter()+60,'solver_calls':0,'offline_not_production_qualification':True},f,indent=2);f.write('\n')
print({'prepared':str(OUT),'helpers':4},flush=True)
