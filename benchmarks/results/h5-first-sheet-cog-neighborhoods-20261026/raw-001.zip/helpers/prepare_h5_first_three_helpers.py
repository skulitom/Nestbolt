"""Create a wider first-sheet neighborhood without repeating closed calls."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first-three-regions-20261026';OUT.mkdir();records=[]
for kind in ['prove','audit']:
    src=ROOT/'output'/f'{kind}_h5_first_pair_regions.py';s=src.read_text(encoding='utf-8')
    replacements={
        'PART=4;RELEASED=[4,5]':'PART=4;RELEASED=[4,5,6]',
        'h5-first-pair-regions-20261026':'h5-first-three-regions-20261026',
        'release-4-5':'release-4-5-6',
        '[0,1,2,4,5]':'[0,1,2,4,5,6]',
        'len(six)==4':'len(six)==3',
        'four_fixed_cog_positions':'three_fixed_cog_positions',
        'both_released_cogs':'all_released_cogs',
        'four_fixed_witness_poses':'three_fixed_witness_poses',
        'conditional_on_four_fixed_positions':'conditional_on_three_fixed_positions',
        'conditional on four verified cog poses':'conditional on three verified cog poses',
        'original cogs57/58 both released and original cogs54/62/64/65':'original cogs57/58/62 all released and original cogs54/64/65',
        'both released cogs are mandatory (five movers,61 fixed originals)':'all three released cogs are mandatory (six movers,60 fixed originals)',
        'Both released cog indices follow fixed cog3 and precede fixed cogs6/7/8':'All three released cog indices follow fixed cog3 and precede fixed cogs7/8',
        'they remain two separate mandatory parts':'they remain three separate mandatory parts',
        'four cogs fixed and original cogs57/58 released. Both released cogs have identical source domains and original pair direction against fixed cogs3/6/7/8; one fixed index precedes both and three follow both. Both remain separate mandatory parts. These regions do not establish simultaneous placement of the five movers':'three cogs fixed and original cogs57/58/62 released. All three released cogs have identical source domains and original pair direction against fixed cogs3/7/8; one fixed index precedes all three and two follow them. All three remain separate mandatory parts. These regions do not establish simultaneous placement of the six movers',
        'four selected cog poses fixed':'three selected cog poses fixed',
    };applied={}
    for a,b in replacements.items():
        if a in s:s=s.replace(a,b);applied[a]=b
    dest=ROOT/'output'/f'{kind}_h5_first_three_regions.py';compile(s,str(dest),'exec')
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dest.relative_to(ROOT).as_posix(),'target_sha256':sha256(dest.read_bytes()).hexdigest(),'replacements':applied})
for srcname,dstname in [('prepare_h5_first_pair_source_model.py','prepare_h5_first_three_source_model.py'),('audit_h5_first_pair_source_model.py','audit_h5_first_three_source_model.py')]:
    src=ROOT/'output'/srcname;s=src.read_text(encoding='utf-8');replacements={
        'h5-first-pair-source-model-20261026':'h5-first-three-source-model-20261026',
        'h5-first-pair-regions-20261026/release-4-5':'h5-first-three-regions-20261026/release-4-5-6',
        '[3,6,7,8]':'[3,7,8]',
        '[0,1,2,4,5]':'[0,1,2,4,5,6]',
        '{0,1,2,4,5}':'{0,1,2,4,5,6}',
        "regplan['released_cog_parts']==[4,5]":"regplan['released_cog_parts']==[4,5,6]",
        "spec['parts'][4]['queries']==spec['parts'][5]['queries']==[18,19] and all((p['part']<4)==(p['part']<5) for p in fixed)":"spec['parts'][4]['queries']==spec['parts'][5]['queries']==spec['parts'][6]['queries']==[18,19] and all((p['part']<4)==(p['part']<i) for p in fixed for i in [4,5,6])",
        'four_fixed_cog_positions':'three_fixed_cog_positions',
        "'fixed_originals':61":"'fixed_originals':60",
        "'moving_originals':5":"'moving_originals':6",
        "'appended_coordinate_equalities':8":"'appended_coordinate_equalities':6",
        "'exact_fixed_coordinate_equalities':8":"'exact_fixed_coordinate_equalities':6",
        'four retained cog witnesses on both sheets':'three retained cog witnesses on both sheets',
        'Cogs57/58, both brackets and insert':'Cogs57/58/62, both brackets and insert',
        'The other four cogs and57 source originals are fixed':'The other three cogs and57 source originals are fixed',
        'fixed61':'fixed60',
        'released cogs4/5 against fixed3/6/7/8':'released cogs4/5/6 against fixed3/7/8',
    };applied={}
    for a,b in replacements.items():
        if a in s:s=s.replace(a,b);applied[a]=b
    dest=ROOT/'output'/dstname;compile(s,str(dest),'exec')
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dest.relative_to(ROOT).as_posix(),'target_sha256':sha256(dest.read_bytes()).hexdigest(),'replacements':applied})
with (OUT/'helper-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'helpers':records,'released_parts':[4,5,6],'released_originals':[57,58,62],'fixed_cog_parts':[3,7,8],'mandatory_originals':66,'distinct_preparation':True,'solver_calls':0},f,indent=2);f.write('\n')
with (OUT/'budget.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'shared_seconds':60,'deadline_perf_counter':time.perf_counter()+60,'solver_calls':0,'offline_not_production_qualification':True},f,indent=2);f.write('\n')
print({'prepared':str(OUT),'helpers':4},flush=True)
