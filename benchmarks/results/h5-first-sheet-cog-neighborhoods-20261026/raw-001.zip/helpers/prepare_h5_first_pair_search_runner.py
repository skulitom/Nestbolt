"""Prepare the sole call for the audited first-sheet pair model."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];src=ROOT/'output/run_h5_two_cog_fixed_source_search.py';dst=ROOT/'output/run_h5_first_pair_source_search.py';s=src.read_text(encoding='utf-8')
replacements={'h5-two-cog-fixed-source-search-20261026':'h5-first-pair-source-search-20261026','h5-two-cog-fixed-source-model-20261026':'h5-first-pair-source-model-20261026','382735':'382335','original cogs54/57/58/62':'original cogs54/62/64/65','6364':'5964','Original cogs64/65':'Original cogs57/58'}
for a,b in replacements.items():assert a in s,a;s=s.replace(a,b)
compile(s,str(dst),'exec')
with dst.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (ROOT/'output/h5-first-pair-source-model-20261026/runner-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dst.relative_to(ROOT).as_posix(),'target_sha256':sha256(dst.read_bytes()).hexdigest(),'replacements':replacements,'maximum_solver_calls':1,'solver_cap_seconds':45,'shared_import_audit_search_seconds':60,'shutdown_reserve_seconds':10},f,indent=2);f.write('\n')
print({'runner_prepared':str(dst),'solver_calls':0})
