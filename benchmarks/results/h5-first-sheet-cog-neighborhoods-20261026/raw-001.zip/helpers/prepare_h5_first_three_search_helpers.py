"""Prepare one bounded search and its independent source readback for six movers."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first-three-source-model-20261026'
assert json.loads((BASE/'audit/checks.json').read_bytes())['passed'];records=[]
for srcname,dstname in [('run_h5_first_pair_source_search.py','run_h5_first_three_source_search.py'),('audit_h5_first_pair_source_search.py','audit_h5_first_three_source_search.py')]:
    src=ROOT/'output'/srcname;s=src.read_text(encoding='utf-8');replacements={
        'h5-first-pair-source-search-20261026':'h5-first-three-source-search-20261026',
        'h5-first-pair-source-model-20261026':'h5-first-three-source-model-20261026',
        'h5-first-pair-regions-20261026/release-4-5':'h5-first-three-regions-20261026/release-4-5-6',
        '382335':'379893',
        "'mandatory_moving_originals':5":"'mandatory_moving_originals':6",
        "'fixed_originals':61":"'fixed_originals':60",
        "'fixed_cog_coordinate_pairs':4":"'fixed_cog_coordinate_pairs':3",
        'eight coordinate equalities':'six coordinate equalities',
        'original cogs54/62/64/65':'original cogs54/64/65',
        '5964':'3524',
        'Original cogs57/58':'Original cogs57/58/62',
        'five movable':'six movable',
        'five moving':'six moving',
        'five movers':'six movers',
        'and61 fixed':'and60 fixed',
        'fixed61':'fixed60',
        'two-cog focus':'three-cog focus',
        "['four_fixed_cog_positions']":"['three_fixed_cog_positions']",
        '[3,6,7,8]':'[3,7,8]',
    };applied={}
    for a,b in replacements.items():
        if a in s:s=s.replace(a,b);applied[a]=b
    dest=ROOT/'output'/dstname;compile(s,str(dest),'exec')
    with dest.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    records.append({'source':src.relative_to(ROOT).as_posix(),'source_sha256':sha256(src.read_bytes()).hexdigest(),'target':dest.relative_to(ROOT).as_posix(),'target_sha256':sha256(dest.read_bytes()).hexdigest(),'replacements':applied})
with (BASE/'search-helper-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'utc':datetime.now(timezone.utc).isoformat(),'helpers':records,'maximum_solver_calls':1,'solver_cap_seconds':45,'shared_import_audit_search_seconds':60,'shutdown_reserve_seconds':10,'previous_calls_remain_closed':True},f,indent=2);f.write('\n')
print({'search_helpers_prepared':2,'solver_calls':0})
