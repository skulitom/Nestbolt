"""Independently verify exact parent preservation and conditional restrictions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-bounded-source-model-20261026';BASE=ROOT/'output/h5-first-four-source-model-20261026';REG=ROOT/'output/h5-first-four-regions-20261026/release-3-4-5-6';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Verify all input hashes, the parent model/mapping/audit against their committed archive, and complete independently replayed four-cog domain census. Parse actual parent/child protobufs; strip only the appended constraints and require exact parent equality including every variable, clause, objective and hint. Independently reconstruct each appended unit equality from fixed witness coordinates and every missing original domain row. No additional restriction or omitted nonempty domain is permitted. Confirm identical source domain/pair direction for released cogs3/4/5/6 against fixed7/8. Validate actual CpModel import/export equals the audited child. No solver call.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    manifest=load(ROOT/'benchmarks/results/h5-bounded-source-search-20261026/raw-manifest.json');known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']}
    for p in [PARENT/n for n in ['model.pb','mapping.json','result.json','audit/checks.json']]:assert digest(p)==known[p.relative_to(ROOT/'output').as_posix()]
    audit=load(REG/'audit/checks.json');assert audit['passed'] and audit['all20_queries_and3523_original_domains_replayed'] and audit['pending_domains']==0
    for n,h in load(REG/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h
    regplan=load(REG/'plan.json');assert regplan['released_cog_parts']==[3,4,5,6];fixed=regplan['two_fixed_cog_positions'];assert [p['part'] for p in fixed]==[7,8]
    spec=load(SOURCE/'plan.json');assert spec['parts'][3]['queries']==spec['parts'][4]['queries']==spec['parts'][5]['queries']==spec['parts'][6]['queries']==[18,19] and all((p['part']<3)==(p['part']<i) for p in fixed for i in [3,4,5,6])
    parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model.pb').read_bytes());actual=cp_model_pb2.CpModelProto();actual.ParseFromString((BASE/'model.pb').read_bytes());n=len(parent.constraints);restored=cp_model_pb2.CpModelProto();restored.CopyFrom(actual);del restored.constraints[n:];assert restored==parent
    m=load(BASE/'mapping.json');assert m==load(PARENT/'mapping.json');restriction=load(BASE/'restriction.json');assert restriction['fixed_cogs']==fixed and restriction['parent_constraints']==n
    expected=[];records=[];positions={p['part']:p for p in m['simultaneous_original_coordinates']}
    def add(variable,value,record):
        c=cp_model_pb2.ConstraintProto();c.linear.vars.append(variable);c.linear.coeffs.append(1);c.linear.domain.extend([value,value]);expected.append(c);records.append({'constraint':n+len(expected)-1,'variable':variable,'value':value,**record})
    for witness in fixed:
        for axis in ('x','y'):add(positions[witness['part']][axis],witness[axis+'_units'],{'kind':'fixed_cog_coordinate','part':witness['part'],'item':witness['item'],'axis':axis})
    residual=load(REG/'audit/verified-residuals.json');allowed={(r['query'],r['domain_row']) for r in residual};assert len(allowed)==load(REG/'result.json')['residual_domains']
    # Read the complete source inventories, not only the producer's kept list.
    counts={'kept':0,'excluded':0};kept=[];excluded=[]
    for p in m['parts']:
        if p['part'] not in {0,1,2,3,4,5,6}:continue
        assert [v['query'] for v in p['modes']]==spec['parts'][p['part']]['queries']
        for mode in p['modes']:
            domains=load(SOURCE/'queries'/f"{mode['query']:03d}.json")['domains'];assert len(mode['domains'])==len(domains)
            for i,d in enumerate(domains):
                r={'part':p['part'],'item':p['item'],'query':mode['query'],'domain_row':i,'flag':mode['domains'][i]}
                if (mode['query'],i) in allowed:kept.append(r);counts['kept']+=1
                else:add(mode['domains'][i],0,{'kind':'empty_conditional_domain',**r});excluded.append(r);counts['excluded']+=1
    assert kept==restriction['retained_domains'] and excluded==restriction['excluded_domains'] and records==restriction['appended_constraints'] and list(actual.constraints[n:])==expected
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'solver-import-roundtrip.pb'))
    roundtrip=cp_model_pb2.CpModelProto();roundtrip.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert roundtrip==actual
    checks={'passed':True,'seconds':time.perf_counter()-start,'variables':len(actual.variables),'constraints':len(actual.constraints),'hints':len(actual.solution_hint.vars),'exact_parent_restored':True,'all_original_full_guarded_pair_clauses_areas_counts_and_domains_retained':True,'exact_fixed_coordinate_equalities':4,'audited_conditional_empty_domain_exclusions':counts['excluded'],'all_nonempty_domains_retained':counts['kept'],'no_single_cog_exclusion_reused':True,'identical_released_cog_domains_and_source_direction_verified':True,'actual_solver_import_export_verified':True,'required_originals':66,'fixed_originals':59,'moving_originals':7,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
