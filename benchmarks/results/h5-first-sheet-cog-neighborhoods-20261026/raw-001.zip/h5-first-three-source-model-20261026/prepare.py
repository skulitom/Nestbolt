"""Focus the complete source-clause model on two released cog positions."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-bounded-source-model-20261026';REG=ROOT/'output/h5-first-three-regions-20261026/release-4-5-6';OUT=ROOT/'output/h5-first-three-source-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    assert load(PARENT/'audit/checks.json')['passed'] and load(REG/'audit/checks.json')['passed']
    inputs=[PARENT/n for n in ['model.pb','mapping.json','result.json','audit/checks.json']]+[REG/n for n in ['plan.json','summary.json','result.json','audit/checks.json','audit/verified-residuals.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'fixed_cog_parts':[3,7,8],'moving_parts':[0,1,2,4,5,6],'required_originals':66,'fixed_originals':60,'maximum_solver_calls':0,'method':'Start from the entire independently verified complete-source-clause model with all original66 counts, areas, domains, all394 physical pair/query source relations, proved necessary exclusions and advisory hints. Preserve every parent byte semantically: no variable, constraint, hint or original is removed or changed. Append exact x/y equalities for the three retained cog witnesses on both sheets and forbid precisely those domains independently proved empty in the distinct complete three-cog region census. Cogs57/58/62, both brackets and insert remain mandatory and movable. The other three cogs and57 source originals are fixed. No single-cog-position obstruction is applied. Parent copy ordering remains a constructive restriction; any negative is only conditional on this parent model/source orientations/domains/fixed60. Offline preparation is not production-budget qualification. Audit all appended restrictions and actual import before a separately budgeted one-shot search.'})
    model=cp_model_pb2.CpModelProto();model.ParseFromString((PARENT/'model.pb').read_bytes());m=load(PARENT/'mapping.json');assert len(model.variables)==167044 and len(model.constraints)==376363
    original_constraints=len(model.constraints);append_rows=[];coords={p['part']:p for p in m['simultaneous_original_coordinates']};fixed=load(REG/'plan.json')['three_fixed_cog_positions'];assert [p['part'] for p in fixed]==[3,7,8]
    def equality(var,value,reason):
        c=model.constraints.add();c.linear.vars.append(var);c.linear.coeffs.append(1);c.linear.domain.extend([value,value]);append_rows.append({'constraint':len(model.constraints)-1,'variable':var,'value':value,**reason})
    for p in fixed:
        for axis in ['x','y']:equality(coords[p['part']][axis],p[axis+'_units'],{'kind':'fixed_cog_coordinate','part':p['part'],'item':p['item'],'axis':axis})
    allowed={(r['query'],r['domain_row']) for r in load(REG/'audit/verified-residuals.json')};kept=[];excluded=[]
    for p in m['parts']:
        if p['part'] not in [0,1,2,4,5,6]:continue
        for mode in p['modes']:
            for row,flag in enumerate(mode['domains']):
                record={'part':p['part'],'item':p['item'],'query':mode['query'],'domain_row':row,'flag':flag}
                if (mode['query'],row) in allowed:kept.append(record)
                else:excluded.append(record);equality(flag,0,{'kind':'empty_conditional_domain',**record})
    write(OUT/'mapping.json',m);write(OUT/'restriction.json',{'parent_constraints':original_constraints,'parent_variables':len(model.variables),'fixed_cogs':fixed,'moving_parts':[0,1,2,4,5,6],'retained_domains':kept,'excluded_domains':excluded,'appended_constraints':append_rows})
    (OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n')
    result={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'parent_constraints_retained':original_constraints,'appended_coordinate_equalities':6,'appended_empty_domain_exclusions':len(excluded),'retained_domain_flags':len(kept),'hints':len(model.solution_hint.vars),'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'fixed_originals':60,'moving_originals':6,'required_originals':66,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
