"""Independent area-cap replay with direct polygon clipping and GEOS cross-check."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil
from shapely.geometry import shape,box
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-source-area-caps-20261026';OUT=BASE/'audit-provenance-repaired';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';FIXED=ROOT/'output/h5-guarded-source-adjustment-20261025/audit/adjusted-fixed-originals.json';FAMS=['bracket','insert','cog']
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def area(p):return abs(sum((q[0]-r[0])*(q[1]+r[1]) for q,r in zip(p,p[1:]+p[:1])))/2
def points(g):
    assert g['type']=='Polygon' and len(g['coordinates'])==1 and g['coordinates'][0][0]==g['coordinates'][0][-1]
    return [(F(x),F(y)) for x,y in g['coordinates'][0][:-1]]
def direct_clip(poly,axis,bound,upper):
    if not poly:return []
    result=[]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        dp=(p[axis]-bound)*(1 if upper else -1);dq=(q[axis]-bound)*(1 if upper else -1)
        if dp<=0:result.append(p)
        if (dp<0<dq) or (dq<0<dp):
            t=(bound-p[axis])/(q[axis]-p[axis]);result.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    return result
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Verify committed input bytes and every complete source-domain/profile vertex enclosure. Independently recompute exact binary-rational profile areas with a separate shoelace identity. Clip each whole fixed outer polygon directly against the four rectangle boundaries, without triangle fans or producer clipping code; require exact rational area agreement and conservatively floored subtraction. Cross-check each area with GEOS and independently verify fixed polygon counts/disjointness and native clearance. Reconstruct all14 capacities and82 count cases. These necessary area exclusions depend on source profiles/domains and fixed57, not any chosen cog pose. No solver/native run or unrestricted impossibility claim.'})
    manifests=[ROOT/'benchmarks/results'/n/'raw-manifest.json' for n in ['h5-bounded-source-search-20261026','h5-fixed-six-completion-20261026','h5-guarded-cell-search-20261025','h5-guarded-source-adjustment-20261025']];known={}
    for path in manifests:
        m=load(path)
        for r in m['files']+m['aliases']:known.setdefault(r['sha256'],[]).append(r['path'])
    provenance={}
    for n,h in load(BASE/'plan.json')['inputs'].items():
        assert digest(ROOT/n)==h and h in known,n
        provenance[n]={'sha256':h,'committed_content_reference':known[h][0]}
    spec=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');fixed=load(FIXED);pp=[points(p['geometry']) for p in profiles];lower={f:min(math.floor(area(poly)) for p,poly in zip(profiles,pp) if p['family']==f) for f in FAMS};assert lower==load(BASE/'family-area-lower-bounds.json')
    assert len(fixed)==len({p['item'] for p in fixed})==57
    native_gap=(.2+3000*32*2**-23)/math.cos(.05);fixed_pairs=0
    for a,b in combinations(fixed,2):
        if a['sheet']==b['sheet']:assert shape(a['geometry']).distance(shape(b['geometry']))>=native_gap;fixed_pairs+=1
    assert fixed_pairs==1246
    # Independently inspect every translated profile vertex at both extrema.
    bounds={};vertex_checks=0;domains=0
    for sheet,family in product([0,1],FAMS):
        xmin=ymin=None;xmax=ymax=None
        for q in spec['queries']:
            if (q['sheet'],q['family'])!=(sheet,family):continue
            for d in load(SOURCE/'queries'/f"{q['index']:03d}.json")['domains']:
                r=d['coordinate_bounds'];domains+=1
                for x,y in pp[q['profile']]:
                    lo_x=F(r[0],1000)+x;lo_y=F(r[1],1000)+y;hi_x=F(r[2],1000)+x;hi_y=F(r[3],1000)+y
                    xmin=lo_x if xmin is None else min(xmin,lo_x);ymin=lo_y if ymin is None else min(ymin,lo_y);xmax=hi_x if xmax is None else max(xmax,hi_x);ymax=hi_y if ymax is None else max(ymax,hi_y);vertex_checks+=1
        bounds[sheet,family]=[xmin,ymin,xmax,ymax]
    assert domains==3523
    stored=load(BASE/'family-occupancy-bounds.json');assert {(r['sheet'],r['family']):[F(*v) for v in r['bounds']] for r in stored}==bounds
    capacities=load(BASE/'capacities.json');expected_inventory=[(s,list(fs)) for s in [0,1] for n in [1,2,3] for fs in combinations(FAMS,n)];assert [(r['sheet'],r['families']) for r in capacities]==expected_inventory
    clipped_count=0;max_geos_error=0.
    for i,row in enumerate(capacities):
        boxes=[bounds[row['sheet'],f] for f in row['families']];b=[min(r[0] for r in boxes),min(r[1] for r in boxes),max(r[2] for r in boxes),max(r[3] for r in boxes)];assert [F(*v) for v in row['exact_occupancy_bounds']]==b
        rect=[math.floor(b[0])-1,math.floor(b[1])-1,math.ceil(b[2])+1,math.ceil(b[3])+1];assert rect==row['padded_rectangle_mm'] and row['index']==i;rectarea=(rect[2]-rect[0])*(rect[3]-rect[1]);assert rectarea==row['rectangle_area_mm2']
        original=[p for p in fixed if p['sheet']==row['sheet']];assert [p['item'] for p in original]==[r['item'] for r in row['fixed_obstacles']];occupied=0
        for p,r in zip(original,row['fixed_obstacles']):
            poly=points(p['geometry'])
            for axis,bound,upper in [(0,F(rect[0]),False),(0,F(rect[2]),True),(1,F(rect[1]),False),(1,F(rect[3]),True)]:poly=direct_clip(poly,axis,bound,upper)
            a=area(poly) if poly else F(0);assert a==F(*r['exact_clipped_area']) and math.floor(a)==r['lower_area_mm2'];occupied+=r['lower_area_mm2'];geos=shape(p['geometry']).intersection(box(*rect)).area;error=abs(float(a)-geos);assert error<1e-6;max_geos_error=max(max_geos_error,error);clipped_count+=1
        assert row['net_upper_area_mm2']==rectarea-occupied
    cases=[]
    for s in [0,1]:
        for c in product(range(3),range(2),range(7)):
            if not any(c):continue
            row=next(r for r in capacities if r['sheet']==s and r['families']==[f for f,n in zip(FAMS,c) if n]);d=sum(n*lower[f] for f,n in zip(FAMS,c));cases.append({'sheet':s,'counts':dict(zip(FAMS,c)),'capacity_index':row['index'],'lower_demand_mm2':d,'upper_capacity_mm2':row['net_upper_area_mm2'],'excluded':d>row['net_upper_area_mm2']})
    assert cases==load(BASE/'count-cases.json') and sum(c['excluded'] for c in cases)==28
    # Apply every family-subset capacity to each complementary all-nine allocation.
    allocations=[]
    for c in product(range(3),range(2),range(7)):
        other=tuple(t-n for t,n in zip([2,1,6],c));fail=[]
        for r in capacities:
            counts=c if r['sheet']==0 else other;d=sum(counts[FAMS.index(f)]*lower[f] for f in r['families'])
            if d>r['net_upper_area_mm2']:fail.append(r['index'])
        allocations.append({'first_sheet_counts':dict(zip(FAMS,c)),'second_sheet_counts':dict(zip(FAMS,other)),'failed_capacity_indices':fail,'excluded':bool(fail)})
    write(OUT/'verified-capacity-inequalities.json',{'area_lower_bounds_mm2':lower,'inequalities':[{'sheet':r['sheet'],'families':r['families'],'upper_area_mm2':r['net_upper_area_mm2']} for r in capacities],'scope':'Necessary for every source-domain placement with original57 fixed and part-in-hole off. No cog witness is fixed. Never carry these capacities to changed source domains/profiles or fixed originals without rebuilding them. All66 originals still required.','full_target_witness':False,'H5_complete':False});write(OUT/'all-nine-sheet-allocations.json',allocations);write(OUT/'source-provenance.json',provenance)
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_input_files_verified':len(provenance),'all3523_source_domains_verified':True,'translated_profile_vertex_checks':vertex_checks,'independent_fixed_pair_checks':fixed_pairs,'exact_direct_polygon_clips':clipped_count,'maximum_geos_area_difference_mm2':max_geos_error,'capacity_regions':14,'count_cases':82,'excluded_count_cases':28,'all_nine_sheet_allocations':len(allocations),'excluded_all_nine_allocations':sum(r['excluded'] for r in allocations),'no_cog_witness_pose_assumed':True,'seven_first_sheet_movers_not_excluded_by_area':True,'two_brackets_plus_two_cogs_second_sheet_excluded':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
