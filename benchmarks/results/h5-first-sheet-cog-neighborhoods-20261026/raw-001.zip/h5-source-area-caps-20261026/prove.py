"""Necessary area capacities for the complete recorded source placement domains."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil
from prove_h5_fixed_six_completion import clip
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';FIXED=ROOT/'output/h5-guarded-source-adjustment-20261025/audit/adjusted-fixed-originals.json';OUT=ROOT/'output/h5-source-area-caps-20261026';FAMILIES=['bracket','insert','cog']
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def area(poly):return sum(x[0]*y[1]-x[1]*y[0] for x,y in zip(poly,poly[1:]+poly[:1]))/2
def points(g):
    assert g['type']=='Polygon' and len(g['coordinates'])==1
    return [(F(x),F(y)) for x,y in g['coordinates'][0][:-1]]
def enc(x):return [x.numerator,x.denominator]
def clipped_signed_fan(poly,rect):
    if area(poly)<0:poly=list(reversed(poly))
    total=F(0)
    for i in range(1,len(poly)-1):
        tri=[poly[0],poly[i],poly[i+1]];a=area(tri)
        if a==0:continue
        sign=1 if a>0 else -1
        if sign<0:tri.reverse()
        for edge in [(-1,0,-rect[0]),(1,0,rect[2]),(0,-1,-rect[1]),(0,1,rect[3])]:tri=clip(tri,*edge)
        if tri:total+=abs(area(tri))*sign
    assert total>=0
    return total
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();spec=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');fixed=load(FIXED)
    inputs=[SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',FIXED,ROOT/'output/h5-guarded-source-adjustment-20261025/audit/checks.json',ROOT/'output/prove_h5_fixed_six_completion.py']+sorted((SOURCE/'queries').glob('*.json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each sheet and each nonempty subset of bracket/insert/cog families, enclose every source-domain anchor box translated by every exact binary-rational profile vertex. Round the union bounds outward to whole millimetres and pad another1mm on every side. Every source-profile filled polygon lies inside this rectangle. Lower each family area to the floor of the minimum exact profile area. Subtract only floored exact clipped areas of the independently verified disjoint57 fixed original outer polygons, using signed fan triangles clipped with exact rational arithmetic. This yields a conservative integer upper area capacity. Enumerate every bracket count0..2,insert0..1,cog0..6 assigned to the sheet; a demand exceeding capacity is a necessary count exclusion, conditional only on the recorded source domains/profiles and fixed57, not any cog witness. Every original remains required in any full layout. Part-in-hole stays off. No solver/native call, production qualification, or unrestricted impossibility claim.'})
    assert len(fixed)==57 and load(ROOT/'output/h5-guarded-source-adjustment-20261025/audit/checks.json')['passed']
    ppoly=[points(p['geometry']) for p in profiles];lower={f:min(math.floor(abs(area(poly))) for p,poly in zip(profiles,ppoly) if p['family']==f) for f in FAMILIES};family_boxes={}
    for sheet in [0,1]:
        for family in FAMILIES:
            boxes=[]
            for q in spec['queries']:
                if q['sheet']!=sheet or q['family']!=family:continue
                poly=ppoly[q['profile']];mins=[min(p[k] for p in poly) for k in [0,1]];maxs=[max(p[k] for p in poly) for k in [0,1]]
                for d in load(SOURCE/'queries'/f"{q['index']:03d}.json")['domains']:
                    r=d['coordinate_bounds'];boxes.append([F(r[0],1000)+mins[0],F(r[1],1000)+mins[1],F(r[2],1000)+maxs[0],F(r[3],1000)+maxs[1]])
            family_boxes[sheet,family]=[min(r[0] for r in boxes),min(r[1] for r in boxes),max(r[2] for r in boxes),max(r[3] for r in boxes)]
    capacities=[]
    for sheet in [0,1]:
        for n in [1,2,3]:
            for fs in combinations(FAMILIES,n):
                boxes=[family_boxes[sheet,f] for f in fs];box=[min(r[0] for r in boxes),min(r[1] for r in boxes),max(r[2] for r in boxes),max(r[3] for r in boxes)];rect=[math.floor(box[0])-1,math.floor(box[1])-1,math.ceil(box[2])+1,math.ceil(box[3])+1];rectarea=(rect[2]-rect[0])*(rect[3]-rect[1]);obstacles=[]
                for p in fixed:
                    if p['sheet']!=sheet:continue
                    clipped=clipped_signed_fan(points(p['geometry']),rect);obstacles.append({'item':p['item'],'exact_clipped_area':enc(clipped),'lower_area_mm2':math.floor(clipped)})
                cap=rectarea-sum(o['lower_area_mm2'] for o in obstacles);assert cap>=0;capacities.append({'index':len(capacities),'sheet':sheet,'families':list(fs),'exact_occupancy_bounds':[enc(v) for v in box],'padded_rectangle_mm':rect,'rectangle_area_mm2':rectarea,'fixed_obstacles':obstacles,'net_upper_area_mm2':cap})
    cases=[]
    for sheet in [0,1]:
        for counts in product(range(3),range(2),range(7)):
            if not any(counts):continue
            fs=[f for f,c in zip(FAMILIES,counts) if c];row=next(r for r in capacities if r['sheet']==sheet and r['families']==fs);demand=sum(c*lower[f] for f,c in zip(FAMILIES,counts));cases.append({'sheet':sheet,'counts':dict(zip(FAMILIES,counts)),'capacity_index':row['index'],'lower_demand_mm2':demand,'upper_capacity_mm2':row['net_upper_area_mm2'],'excluded':demand>row['net_upper_area_mm2']})
    write(OUT/'family-area-lower-bounds.json',lower);write(OUT/'family-occupancy-bounds.json',[{'sheet':s,'family':f,'bounds':[enc(v) for v in b]} for (s,f),b in family_boxes.items()]);write(OUT/'capacities.json',capacities);write(OUT/'count-cases.json',cases)
    result={'seconds':time.perf_counter()-start,'capacity_regions':len(capacities),'count_cases':len(cases),'excluded_count_cases':sum(c['excluded'] for c in cases),'full_first_sheet_7_mover_case':next(c for c in cases if c['sheet']==0 and list(c['counts'].values())==[2,1,4]),'second_sheet_two_brackets_two_cogs':next(c for c in cases if c['sheet']==1 and list(c['counts'].values())==[2,0,2]),'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
