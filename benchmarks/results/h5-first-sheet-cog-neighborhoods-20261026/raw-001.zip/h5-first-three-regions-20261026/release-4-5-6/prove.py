"""Exact real-domain completion census conditional on three verified cog poses."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil,traceback,sys
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';SIX=ROOT/'output/h5-guarded-cell-search-20261025';WIT=SIX/'first-sheet-four-cog-diagnostic/audit/six-cog-positions.json';PART=4;RELEASED=[4,5,6];OUT=ROOT/'output/h5-first-three-regions-20261026'/'release-4-5-6'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def canon(poly):
    poly=list(dict.fromkeys(poly))
    if len(poly)>2:
        area=sum(p[0]*q[1]-p[1]*q[0] for p,q in zip(poly,poly[1:]+poly[:1]))
        if area==0:return [min(poly),max(poly)] if min(poly)!=max(poly) else [min(poly)]
        if area<0:poly.reverse()
        changed=True
        while changed and len(poly)>2:
            changed=False
            for i,p in enumerate(poly):
                a=poly[i-1];b=poly[(i+1)%len(poly)]
                if (p[0]-a[0])*(b[1]-p[1])==(p[1]-a[1])*(b[0]-p[0]):poly.pop(i);changed=True;break
    if poly:
        i=poly.index(min(poly));poly=poly[i:]+poly[:i]
    return poly
def clip(poly,a,b,c):
    if not poly:return []
    out=[]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        v=a*p[0]+b*p[1]-c;w=a*q[0]+b*q[1]-c
        if v<=0:out.append(p)
        if (v<0<w) or (w<0<v):
            t=v/(v-w);out.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    return canon(out)
def encode(poly):return [[[v.numerator,v.denominator] for v in p] for p in poly]
def encode_many(polys):return [encode(p) for p in polys]
def unique(polys):return sorted(set(tuple(p) for p in polys if p))
def apply_clause(polys,edges):
    result=[]
    for original in polys:
        live=[];safe=False
        for a,b,c in edges:
            vals=[a*x+b*y for x,y in original]
            if max(vals)<=c:safe=True;break
            if min(vals)<=c:live.append((a,b,c))
        if safe:result.append(original);continue
        pending=list(original)
        for a,b,c in live:
            outside=clip(pending,a,b,c)
            if outside:result.append(outside)
            pending=clip(pending,-a,-b,-c)
            if not pending:break
    return unique(result)
def main():
    OUT.mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();deadline=min(start+60,load(OUT.parent/'budget.json')['deadline_perf_counter'])
    spec=load(SOURCE/'plan.json');six=load(WIT);assert len(six)==6 and load(SIX/'first-sheet-four-cog-diagnostic/audit/checks.json')['passed'] and load(SIX/'six-cog-geometry-audit/checks.json')['passed']
    queries=sorted(set(q for p in [spec['parts'][i] for i in [0,1,2,4,5,6]] for q in p['queries']));assert queries==list(range(20));six=[p for p in six if p['part'] not in RELEASED];assert len(six)==3;lookup={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']};used=sorted({lookup[spec['queries'][q]['profile'],9] for q in queries})
    inputs=[SOURCE/'plan.json',SOURCE/'audit/checks.json',WIT,SIX/'first-sheet-four-cog-diagnostic/audit/checks.json',SIX/'six-cog-geometry-audit/checks.json']+[SOURCE/'queries'/f'{q:03d}.json' for q in queries]+[SOURCE/'mutual'/f'{i:03d}.json' for i in used]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'query_indices':queries,'proof_budget_seconds':60,'released_cog_parts':RELEASED,'three_fixed_cog_positions':six,'required_originals':66,'all_released_cogs_still_must_be_placed':True,'maximum_live_fragments_per_domain':50000,'maximum_recorded_events':200000,'solver_calls':0,'coordinate_units_per_mm':1000,
        'method':'Distinct complete source-region census with original cogs57/58/62 all released and original cogs54/64/65 plus57 source originals fixed. Both brackets28/29,insert50 and all three released cogs are mandatory (six movers,60 fixed originals). All20 original queries and3523 inward domains are examined with exact rational clipping, unchanged source orientations and full guarded clauses. All three released cog indices follow fixed cog3 and precede fixed cogs7/8, so their moving-versus-fixed source clauses and domains are identical and represented once; they remain three separate mandatory parts in any model. Bracket copy domains are likewise identical. Preserve all boundaries, lines and points and correct original pair direction. Never reuse single-cog conditional exclusions. Offline60-second preparation is not production qualification. No solver/native call.'})
    completed=[];pending=[];events_total=0;stop=False
    for qi in queries:
        q=spec['queries'][qi];data=load(SOURCE/'queries'/f'{qi:03d}.json');case=lookup[q['profile'],9];mutual=load(SOURCE/'mutual'/f'{case:03d}.json');clauses=[]
        for cog in six:
            if cog['sheet']!=q['sheet']:continue
            moving_part=0 if q['family']=='bracket' else 2 if q['family']=='insert' else PART;sign=1 if moving_part<cog['part'] else -1
            for fi,face in enumerate(mutual['faces']):
                clauses.append({'index':len(clauses),'cog_part':cog['part'],'cog_item':cog['item'],'mutual_case':case,'face':fi,'edges':[[sign*h['a'],sign*h['b'],sign*(h['a']*cog['x_units']+h['b']*cog['y_units'])-h['bound']] for h in face['outside_halfplanes']]})
        dest=OUT/'queries'/f'{qi:03d}';dest.mkdir();write(dest/'clauses.json',clauses);rows=[]
        for di,d in enumerate(data['domains']):
            if stop or time.perf_counter()>=deadline or events_total>=200000:
                stop=True;pending.append({'query':qi,'domain_row':di,'domain_index':d['index']});continue
            r=d['coordinate_bounds'];active=[];bad=None;taut=0
            for clause in clauses:
                live=[];safe=False
                for hi,(a,b,c) in enumerate(clause['edges']):
                    lo=a*(r[0] if a>=0 else r[2])+b*(r[1] if b>=0 else r[3]);up=a*(r[2] if a>=0 else r[0])+b*(r[3] if b>=0 else r[1])
                    if up<=c:safe=True;break
                    if lo<=c:live.append(hi)
                if safe:taut+=1;continue
                if not live:bad=clause['index'];break
                active.append({'clause':clause['index'],'live_edges':live})
            row={'query':qi,'domain_row':di,'domain_index':d['index'],'coordinate_bounds':r}
            if bad is not None:row.update({'status':'WHOLE_BOX_EXCLUDED','failed_clause':bad,'events':[],'residual':[]})
            else:
                poly=canon([(F(r[0]),F(r[1])),(F(r[2]),F(r[1])),(F(r[2]),F(r[3])),(F(r[0]),F(r[3]))])
                for h in d['halfplanes']:poly=clip(poly,h['a'],h['b'],h['bound'])
                initial=encode(poly);polys=unique([poly]);events=[];active.sort(key=lambda v:(len(v['live_edges']),v['clause']));done=0
                for stage in active:
                    if not polys:break
                    if time.perf_counter()>=deadline or len(polys)>50000 or events_total>=200000:stop=True;break
                    edges=[clauses[stage['clause']]['edges'][i] for i in stage['live_edges']];after=apply_clause(polys,edges);done+=1
                    if after!=polys:events.append({'clause':stage['clause'],'before_count':len(polys),'after':encode_many(after)});events_total+=1
                    polys=after
                status='CONTINUOUSLY_EXCLUDED' if not polys else 'UNRESOLVED_CAP' if stop else 'RESIDUAL'
                row.update({'status':status,'initial_domain':initial,'box_tautologies':taut,'active_clauses':active,'completed_active_clauses':done,'events':events,'residual':encode_many(polys)})
                if status=='UNRESOLVED_CAP':pending.append({'query':qi,'domain_row':di,'domain_index':d['index'],'partial_record':True})
            write(dest/f'domain-{di:04d}.json',row);rows.append({'domain_row':di,'domain_index':d['index'],'status':row['status'],'residual_fragments':len(row['residual']),'lower_dimensional_residuals':sum(len(p)<3 for p in row['residual'])})
        write(dest/'summary.json',rows);summary={'query':qi,'family':q['family'],'sheet':q['sheet'],'profile':q['profile'],'planned_domains':len(data['domains']),'recorded_domains':len(rows),'whole_box_excluded':sum(r['status']=='WHOLE_BOX_EXCLUDED' for r in rows),'continuously_excluded':sum(r['status']=='CONTINUOUSLY_EXCLUDED' for r in rows),'residual_domains':sum(r['status']=='RESIDUAL' for r in rows),'unresolved_partial_domains':sum(r['status']=='UNRESOLVED_CAP' for r in rows),'residual_fragments':sum(r['residual_fragments'] for r in rows),'lower_dimensional_residuals':sum(r['lower_dimensional_residuals'] for r in rows)};completed.append(summary);print({**summary,'seconds':time.perf_counter()-start},flush=True)
    write(OUT/'summary.json',completed);write(OUT/'pending-domains.json',pending)
    result={'seconds':time.perf_counter()-start,'planned_queries':20,'planned_domains':sum(r['planned_domains'] for r in completed),'recorded_domains':sum(r['recorded_domains'] for r in completed),'whole_box_excluded':sum(r['whole_box_excluded'] for r in completed),'continuously_excluded':sum(r['continuously_excluded'] for r in completed),'residual_domains':sum(r['residual_domains'] for r in completed),'residual_fragments':sum(r['residual_fragments'] for r in completed),'lower_dimensional_residuals':sum(r['lower_dimensional_residuals'] for r in completed),'pending_domains':len(pending),'recorded_changed_clause_events':events_total,'cap_reached':stop,'independent_audit_pending':True,'all_exclusions_conditional_on_three_fixed_witness_poses':True,'released_cog_parts':RELEASED,'all_released_cogs_still_required':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
