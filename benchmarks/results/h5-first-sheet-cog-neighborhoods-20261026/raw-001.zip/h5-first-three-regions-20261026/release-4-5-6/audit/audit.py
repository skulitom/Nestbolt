"""Independent exact corner and convex-hull clipping replay of completion census."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product,combinations
from collections import Counter
import json,time,shutil,traceback,sys
ROOT=Path(__file__).resolve().parents[1];PART=4;RELEASED=[4,5,6];BASE=ROOT/'output/h5-first-three-regions-20261026'/'release-4-5-6';OUT=BASE/'audit';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';WIT=ROOT/'output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic/audit/six-cog-positions.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def hull(points):
    pts=sorted(set(points))
    if len(pts)<3:return pts
    def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    low=[];high=[]
    for p in pts:
        while len(low)>1 and cross(low[-2],low[-1],p)<=0:low.pop()
        low.append(p)
    for p in reversed(pts):
        while len(high)>1 and cross(high[-2],high[-1],p)<=0:high.pop()
        high.append(p)
    return low[:-1]+high[:-1]
def intersect(poly,edge):
    a,b,c=edge;pts=[p for p in poly if a*p[0]+b*p[1]<=c]
    for i in range(len(poly)):
        p=poly[i];q=poly[(i+1)%len(poly)];left=a*p[0]+b*p[1]-c;right=a*q[0]+b*q[1]-c
        if left*right<0:
            u=q[0]-p[0];v=q[1]-p[1];t=(c-a*p[0]-b*p[1])/(a*u+b*v);pts.append((p[0]+t*u,p[1]+t*v))
    return hull(pts)
def encode(poly):return [[[v.numerator,v.denominator] for v in p] for p in poly]
def encode_many(polys):return [encode(p) for p in polys]
def union_clause(polys,edges):
    pieces=[]
    for poly in polys:
        if any(all(a*x+b*y<=c for x,y in poly) for a,b,c in edges):pieces.append(poly);continue
        remainder=list(poly)
        for edge in edges:
            if not any(edge[0]*x+edge[1]*y<=edge[2] for x,y in poly):continue
            inside=intersect(remainder,edge)
            if inside:pieces.append(inside)
            remainder=intersect(remainder,tuple(-v for v in edge))
            if not remainder:break
    return sorted({tuple(p) for p in pieces if p})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify every original source and exact witness against the committed archive, then recheck all six witness domains and all427 mutual source clauses. Reconstruct every translated moving-anchor clause directly. Independently enumerate all four domain-box corners for whole-box rejection/tautology/edge pruning. Replay every rational domain and union-of-halfplanes intersection using an independent candidate-vertex plus monotone-convex-hull clipper, retaining line and point results. Compare every event, initial polygon, residual and query census, and verify every residual fragment against every original domain and full source clause. Empty real domains certify no corresponding original-part anchor only with the three selected cog poses fixed; nonempty residuals do not establish simultaneous completion. Never apply a conditional exclusion to moving fixed cogs. No solver/native call.'})
    manifest=load(ROOT/'benchmarks/results/h5-bounded-source-search-20261026/raw-manifest.json');known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']};plan=load(BASE/'plan.json')
    olderpath=ROOT/'benchmarks/results/h5-guarded-cell-search-20261025/raw-manifest.json';older=load(olderpath);oldknown={r['path']:r['sha256'] for r in older['files']+older['aliases']}
    repair=load(ROOT/'output/h5-fixed-six-completion-20261026/audit/provenance-repair.json');assert digest(olderpath)==repair['earlier_manifest_sha256']
    fallback=set(repair['fallback_inputs'])
    for n,h in plan['inputs'].items():
        reference=oldknown['source-inputs/'+n] if n in fallback else known['source-inputs/'+n]
        assert digest(ROOT/n)==h==reference

    result=load(BASE/'result.json');assert result['pending_domains']==0 and not result['cap_reached'] and load(BASE/'pending-domains.json')==[]
    spec=load(SOURCE/'plan.json');six=load(WIT);assert [s['part'] for s in six]==list(range(3,9));sourcechecks=0
    for s in six:
        p=spec['parts'][s['part']];assert s['item']==p['index'] and s['family']=='cog' and s['query'] in p['queries'];q=spec['queries'][s['query']];assert s['profile']==q['profile']==9 and s['sheet']==q['sheet'];d=load(SOURCE/'queries'/f"{s['query']:03d}.json")['domains'][s['domain_row']];assert d['index']==s['domain_index'];x,y=s['x_units'],s['y_units']
        for b in [q['anchor_bounds_units1000'],d['coordinate_bounds']]:assert b[0]<=x<=b[2] and b[1]<=y<=b[3]
        assert all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes'])
    for a,b in combinations(six,2):
        if a['sheet']!=b['sheet']:continue
        x=b['x_units']-a['x_units'];y=b['y_units']-a['y_units']
        for face in load(SOURCE/'mutual/081.json')['faces']:assert any(h['a']*x+h['b']*y>=h['bound'] for h in face['outside_halfplanes']);sourcechecks+=1
    assert sourcechecks==427;lookup={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']};counts=Counter();summaries=[];residuals=[];cornerchecks=0
    assert plan['query_indices']==sorted(set(q for p in [spec['parts'][i] for i in [0,1,2,4,5,6]] for q in p['queries']))==list(range(20));assert plan['released_cog_parts']==RELEASED;six=[p for p in six if p['part'] not in RELEASED];assert len(six)==3 and plan['three_fixed_cog_positions']==six and plan['all_released_cogs_still_must_be_placed']
    for qi in plan['query_indices']:
        q=spec['queries'][qi];case=lookup[q['profile'],9];mutual=load(SOURCE/'mutual'/f'{case:03d}.json');clauses=[];data=load(SOURCE/'queries'/f'{qi:03d}.json');dest=BASE/'queries'/f'{qi:03d}';rows=[]
        for cog in six:
            if cog['sheet']!=q['sheet']:continue
            moving_part=0 if q['family']=='bracket' else 2 if q['family']=='insert' else PART
            for fi,face in enumerate(mutual['faces']):clauses.append({'index':len(clauses),'cog_part':cog['part'],'cog_item':cog['item'],'mutual_case':case,'face':fi,'edges':[([h['a'],h['b'],h['a']*cog['x_units']+h['b']*cog['y_units']-h['bound']] if moving_part<cog['part'] else [-h['a'],-h['b'],-h['a']*cog['x_units']-h['b']*cog['y_units']-h['bound']]) for h in face['outside_halfplanes']]})
        assert clauses==load(dest/'clauses.json');counts['translated_source_clauses']+=len(clauses)
        for di,d in enumerate(data['domains']):
            row=load(dest/f'domain-{di:04d}.json');r=d['coordinate_bounds'];assert all(row[k]==v for k,v in {'query':qi,'domain_row':di,'domain_index':d['index'],'coordinate_bounds':r}.items());corners=list(product([r[0],r[2]],[r[1],r[3]]));active=[];bad=None;taut=0
            for clause in clauses:
                live=[];safe=False
                for hi,(a,b,c) in enumerate(clause['edges']):
                    values=[a*x+b*y for x,y in corners];cornerchecks+=4
                    if all(v<=c for v in values):safe=True;break
                    if any(v<=c for v in values):live.append(hi)
                if safe:taut+=1;continue
                if not live:bad=clause['index'];break
                active.append({'clause':clause['index'],'live_edges':live})
            if bad is not None:
                assert row['status']=='WHOLE_BOX_EXCLUDED' and row['failed_clause']==bad and row['events']==[] and row['residual']==[];counts['whole_box_excluded']+=1
                assert all(all(a*x+b*y>c for x,y in corners) for a,b,c in clauses[bad]['edges'])
            else:
                poly=hull([(F(x),F(y)) for x,y in corners])
                for h in d['halfplanes']:poly=intersect(poly,(h['a'],h['b'],h['bound']))
                assert encode(poly)==row['initial_domain'];polys=[tuple(poly)] if poly else [];active.sort(key=lambda v:(len(v['live_edges']),v['clause']));assert active==row['active_clauses'] and row['box_tautologies']==taut;events=[];done=0
                for stage in active:
                    if not polys:break
                    after=union_clause(polys,[clauses[stage['clause']]['edges'][i] for i in stage['live_edges']]);done+=1
                    if after!=polys:events.append({'clause':stage['clause'],'before_count':len(polys),'after':encode_many(after)})
                    polys=after
                assert events==row['events'] and done==row['completed_active_clauses'] and encode_many(polys)==row['residual'];counts['recorded_changed_clause_events']+=len(events)
                assert row['status']==('RESIDUAL' if polys else 'CONTINUOUSLY_EXCLUDED');counts['residual_domains' if polys else 'continuously_excluded']+=1
                for poly in polys:
                    assert all(r[0]<=x<=r[2] and r[1]<=y<=r[3] for x,y in poly)
                    assert all(all(h['a']*x+h['b']*y<=h['bound'] for x,y in poly) for h in d['halfplanes'])
                    assert all(any(all(a*x+b*y<=c for x,y in poly) for a,b,c in clause['edges']) for clause in clauses)
                if polys:residuals.append({'query':qi,'family':q['family'],'domain_row':di,'domain_index':d['index'],'fragments':encode_many(polys)})
            counts['recorded_domains']+=1;counts['residual_fragments']+=len(row['residual']);counts['lower_dimensional_residuals']+=sum(len(p)<3 for p in row['residual']);rows.append({'domain_row':di,'domain_index':d['index'],'status':row['status'],'residual_fragments':len(row['residual']),'lower_dimensional_residuals':sum(len(p)<3 for p in row['residual'])})
        assert rows==load(dest/'summary.json');summaries.append({'query':qi,'family':q['family'],'sheet':q['sheet'],'profile':q['profile'],'planned_domains':len(data['domains']),'recorded_domains':len(rows),'whole_box_excluded':sum(r['status']=='WHOLE_BOX_EXCLUDED' for r in rows),'continuously_excluded':sum(r['status']=='CONTINUOUSLY_EXCLUDED' for r in rows),'residual_domains':sum(r['status']=='RESIDUAL' for r in rows),'unresolved_partial_domains':0,'residual_fragments':sum(r['residual_fragments'] for r in rows),'lower_dimensional_residuals':sum(r['lower_dimensional_residuals'] for r in rows)})
    assert summaries==load(BASE/'summary.json') and all(result[k]==v for k,v in counts.items() if k in result);assert sum(s['planned_domains'] for s in summaries)==result['planned_domains']==3523
    assert sum(s['planned_domains'] for s in summaries if s['family']=='bracket')==2418 and sum(s['planned_domains'] for s in summaries if s['family']=='insert')==338 and sum(s['planned_domains'] for s in summaries if s['family']=='cog')==767
    write(OUT/'verified-residuals.json',residuals);write(OUT/'conditional-region-summary.json',{'released_cog_parts':RELEASED,'all_released_cogs_still_required':True,'fixed_cog_positions':six,'all3523_original_domains_examined':True,'residual_domains':counts['residual_domains'],'residual_fragments':counts['residual_fragments'],'scope':'Residuals are complete conditional original bracket/insert/cog regions with three cogs fixed and original cogs57/58/62 released. All three released cogs have identical source domains and original pair direction against fixed cogs3/7/8; one fixed index precedes all three and two follow them. All three remain separate mandatory parts. These regions do not establish simultaneous placement of the six movers or a66-original target. All counts, source geometry and native/material guards remain unchanged.','full_target_witness':False,'H5_complete':False})
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_source_files_verified':len(plan['inputs']),'witness_full_guarded_clauses_rechecked':sourcechecks,'exact_integer_corner_evaluations':cornerchecks,**counts,'all20_queries_and3523_original_domains_replayed':True,'independent_convex_hull_clipper_matches_every_event':True,'all_boundaries_lines_and_points_retained':True,'pending_domains':0,'all3523_original_domains_examined':True,'released_cog_parts':RELEASED,'all_released_cogs_still_required':True,'all_residual_fragments_pass_full_original_clauses':True,'conditional_on_three_fixed_positions':True,'unrestricted_impossibility_claim':False,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
