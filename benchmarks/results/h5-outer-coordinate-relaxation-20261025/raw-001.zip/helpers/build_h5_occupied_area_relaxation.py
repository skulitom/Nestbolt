"""Continuous occupied-area outer covers for the seven fixed frame/cog arrangements."""
from collections import Counter
from datetime import datetime,timezone
import math,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from conservative_h5_round_obstacles import raw_obstacle
from diagnose_h5_concave_gaps import convex_pieces
from build_h5_small_pair_joint import ROOT,SRC,OUT as PRIOR,load,write,digest
OUT=ROOT/'output/h5-occupied-area-relaxation-20261025';EPS=.001;STEP=50.;SECONDS=120

def vertices(g):
    if g.geom_type=='Polygon':return np.asarray(g.exterior.coords)[:-1]
    return np.asarray(g.coords)

def outer_cover(region,moving):
    if region.is_empty:return Polygon(),Polygon(),[],0
    a,b,c,d=region.bounds;cells=[(i,j) for i in range(math.floor(a/STEP),math.floor(c/STEP)+1) for j in range(math.floor(b/STEP),math.floor(d/STEP)+1)];boxes=np.asarray([box(i*STEP,j*STEP,(i+1)*STEP,(j+1)*STEP) for i,j in cells],dtype=object);hits=np.flatnonzero(shapely.intersects(boxes,region));clips=shapely.intersection(boxes[hits],region);square=np.asarray([[-EPS,-EPS],[-EPS,EPS],[EPS,EPS],[EPS,-EPS]]);hulls=[];sums=[];rows=[];pieces=convex_pieces(moving)
    assert unary_union(pieces).equals(moving)
    for ci,clip in zip(hits,clips):
        if clip.is_empty:continue
        vv=vertices(clip.convex_hull);h=MultiPoint((vv[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull;assert h.covers(clip);hulls.append(h);rows.append({'cell':list(cells[int(ci)]),'hull':mapping(h)})
        hv=vertices(h)
        for piece in pieces:sums.append(MultiPoint((hv[:,None,:]+vertices(piece)[None,:,:]).reshape(-1,2)).convex_hull)
    cover=unary_union(hulls);assert region.difference(cover).is_empty;sweep=unary_union(sums);assert cover.is_valid and sweep.is_valid
    return cover,sweep,rows,len(sums)

def main():
    assert load(PRIOR/'layout-audit/checks.json')['passed'];pool=load(PRIOR/'candidates.json');mp=load(PRIOR/'mapping.json');groups=mp['core_groups'];assert len(groups)==7;job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];target=load(SRC/'conditional-target.json');m=stock['margins'];edge=job['edge_clearance'];assert job['clearance']>.1 and not stock['outline'] and not stock['defects']
    specs=[{'family':f,'degrees':angle,'mirrored':mir} for f in ['bracket','insert'] for mir in ([False,True] if parts[f]['allow_mirror'] else [False]) for angle in parts[f]['rotations']['degrees']];assert len(specs)==12
    queries=[{'index':j,'core_group':g['index'],'specification':si,'sheet_id':sheet} for j,(g,si,sheet) in enumerate((g,si,sheet) for g in groups for si in range(len(specs)) for sheet in ['sheet-0','sheet-1'])];assert len(queries)==168
    OUT.mkdir();(OUT/'queries').mkdir();(OUT/'obstacles').mkdir();(OUT/'cores').mkdir();shutil.copyfile(__file__,OUT/'build.py');inputs=[PRIOR/n for n in ['plan.json','candidates.json','mapping.json','audit/checks.json','layout-audit/checks.json','solve/result.json','next-step.json']]+[SRC/n for n in ['job.json','conditional-target.json']]+[ROOT/'output/conservative_h5_round_obstacles.py',ROOT/'output/diagnose_h5_concave_gaps.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'query_seconds':SECONDS,'grid_step_mm':STEP,'outward_numerical_padding_mm':EPS,'specifications':specs,'queries':queries,'required_family_area_mm2':{'bracket':480000,'insert':415800},'required_combined_area_mm2':895800,'method':'This is a continuous geometric area relaxation, not a pose search. Keep each original33-part core fixed, but ignore positive clearance and every mutual small-part constraint. Cover every allowed bracket/insert orientation/reflection, including all four insert quarter turns. The translation domain expands original stock bounds by0.001mm. Original filled-outline zero-clearance Minkowski forbidden regions are computed from exactly covering convex pieces. Shrink their union by0.001mm and intersect it with the unshrunk union, so excluded geometry stays inside the zero-clearance forbidden set. Every placement meeting the original0.2mm clearance is therefore admitted by this more permissive translation region, subject to numerical checks. For every intersecting50mm grid cell, take the convex hull of the clipped translation region and expand it by a0.001mm square; their union must cover the whole region, including any boundary line or point. Minkowski-sum each convex outer cover with every exactly covering convex moving-part piece. Union these sums, then intersect with an expanded usable stock region after removing only a shrunken subset of fixed occupied geometry. This is an outer cover of every point any individual admissible small part could occupy. Union all orientations by family and both families by sheet; sum sheet areas. Non-overlapping full inventory must fit inside these occupied-point unions, so insufficient combined or family area can reject only the recorded fixed core. Sufficient area proves no packing.','numerical_scope':'Geometry uses floating original vertices. Preserve every raw obstacle, shrunken exclusion, translation region, grid hull and occupied cover. Independently verify the construction, source geometry and all known compatible placements before any conditional negative conclusion; no unrestricted impossibility or H5 claim. Negative buffers only remove forbidden material and enlarge the relaxation; they never certify an accepted placement. Stock padding and zero clearance are relaxation parameters, not changes to original acceptance.','order':'Complete one core at a time in source order, each with every permitted orientation and both sheets. Stop starting queries at120seconds; retain every unfinished query and do not extend or restart the phase. Any aggregate requires all24 queries for that core.','solver_calls':0,'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0,'shapely_version':shapely.__version__,'geos_version':shapely.geos_version_string})
    fixedids=sorted({i for g in groups for i in g['fixed_candidates']});geometry={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixedids};here={};physical={};stockboxes={};fixedunions={};physicalexclusions={}
    for g in groups:
        assert len(g['fixed_candidates'])==33 and Counter(pool[i]['placement']['part_id'] for i in g['fixed_candidates'])==Counter(frame=18,cog=15)
        for sheet in ['sheet-0','sheet-1']:
            key=(g['index'],sheet);here[key]=[i for i in g['fixed_candidates'] if pool[i]['placement']['sheet_id']==sheet];height=stock['height'] if sheet=='sheet-0' else target['required_used_height_mm'];stockboxes[key]=box(m['left']+edge-EPS,m['bottom']+edge-EPS,stock['width']-m['right']-edge+EPS,height-m['top']-edge+EPS);fixedunions[key]=unary_union([geometry[i] for i in here[key]]);physicalexclusions[key]=fixedunions[key].buffer(-EPS,quad_segs=8).intersection(fixedunions[key]);assert physicalexclusions[key].difference(fixedunions[key]).is_empty;physical[key]=stockboxes[key].difference(physicalexclusions[key])
            write(OUT/'cores'/f"{g['index']}-{sheet}.json",{'core_group':g['index'],'sheet_id':sheet,'fixed_candidates':here[key],'expanded_stock':mapping(stockboxes[key]),'fixed_union':mapping(fixedunions[key]),'physical_exclusion':mapping(physicalexclusions[key]),'physical_outer_free_region':mapping(physical[key])})
    cache={};cachegs={};cachechecks=[];completed=[];start=time.perf_counter()
    for q in queries:
        if time.perf_counter()-start>=SECONDS:break
        begun=time.perf_counter();spec=specs[q['specification']];t={'rotation_radians':math.radians(spec['degrees']),'mirrored':spec['mirrored'],'translation':[0.,0.]};moving=shape(parts[spec['family']],t);a,b,c,d=moving.bounds;key=(q['core_group'],q['sheet_id']);sa,sb,sc,sd=stockboxes[key].bounds;domain=box(sa-a,sb-b,sc-c,sd-d);obstacles=[];refs=[]
        for i in here[key]:
            p=pool[i]['placement'];ft=p['transform'];fz={**ft,'translation':[0.,0.]};ck=(p['part_id'],float(ft['rotation_radians']).hex(),ft['mirrored'],spec['family'],spec['degrees'],spec['mirrored'])
            if ck not in cache:
                k=len(cache);cache[ck]=k;local=raw_obstacle(shape(parts[p['part_id']],fz),moving);direct=raw_obstacle(geometry[i],moving);shifted=translate(local,*ft['translation']);hd=shifted.hausdorff_distance(direct);area=shifted.symmetric_difference(direct).area;assert hd<1e-7 and area<1e-4;cachegs[k]=local;row={'index':k,'first_fixed_candidate':i,'fixed_zero_transform':fz,'moving_family':spec['family'],'moving_zero_transform':t,'hausdorff_error_mm':hd,'area_error_mm2':area};cachechecks.append(row);write(OUT/'obstacles'/f'{k:03d}.json',{**row,'raw_geometry':mapping(local)})
            k=cache[ck];obstacles.append(translate(cachegs[k],*ft['translation']));refs.append({'fixed_candidate':i,'cache':k})
        forbidden=unary_union(obstacles);eroded=forbidden.buffer(-EPS,quad_segs=8).intersection(forbidden);assert eroded.difference(forbidden).is_empty;region=domain.difference(eroded);assert region.is_valid;cover,sweep,cells,sums=outer_cover(region,moving);occupied=sweep.intersection(physical[key]);assert occupied.is_valid
        row={**q,'family':spec['family'],'moving_transform':t,'domain_bounds':list(domain.bounds),'obstacles':refs,'raw_forbidden':mapping(forbidden),'shrunken_forbidden':mapping(eroded),'translation_region':mapping(region),'translation_outer_cover':mapping(cover),'cell_hulls':cells,'minkowski_sums':sums,'swept_outer_cover':mapping(sweep),'occupied_outer_cover':mapping(occupied),'translation_region_area_mm2':region.area,'occupied_outer_area_mm2':occupied.area,'seconds':time.perf_counter()-begun};write(OUT/'queries'/f"{q['index']:03d}.json",row);completed.append(row)
        if len(completed)%24==0:print({'queries_completed':len(completed),'seconds':time.perf_counter()-start},flush=True)
    seconds=time.perf_counter()-start;write(OUT/'cache-checks.json',cachechecks);write(OUT/'pending.json',queries[len(completed):]);aggregate=[]
    for g in groups:
        qs=[q for q in completed if q['core_group']==g['index']]
        if len(qs)!=24:continue
        familyareas=Counter();combined=0;covers=[]
        for sheet in ['sheet-0','sheet-1']:
            fam={f:unary_union([shapely.geometry.shape(q['occupied_outer_cover']) for q in qs if q['family']==f and q['sheet_id']==sheet]) for f in ['bracket','insert']};both=unary_union(list(fam.values()));combined+=both.area
            for f,area in fam.items():familyareas[f]+=area.area
            covers.append({'sheet_id':sheet,'families':{f:mapping(v) for f,v in fam.items()},'combined':mapping(both)})
        row={'core_group':g['index'],'complete_queries':24,'family_area_upper_mm2':dict(familyareas),'combined_area_upper_mm2':combined,'combined_slack_mm2':combined-895800,'family_slack_mm2':{f:familyareas[f]-required for f,required in [('bracket',480000),('insert',415800)]},'covers':covers};write(OUT/'cores'/f"{g['index']}-aggregate.json",row);aggregate.append({k:v for k,v in row.items() if k!='covers'})
    result={'seconds':seconds,'planned_queries':len(queries),'completed_queries':len(completed),'pending_queries':len(queries)-len(completed),'query_limit_reached':len(completed)<len(queries),'cache_cases_checked':len(cache),'complete_core_aggregates':len(aggregate),'aggregates':aggregate,'independent_audit_pending':True,'conditional_exclusion_claimed':False,'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
