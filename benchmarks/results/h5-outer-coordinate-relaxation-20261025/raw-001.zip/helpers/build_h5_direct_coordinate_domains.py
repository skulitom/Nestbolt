"""Construct inward-safe continuous domains for an exact-inventory coordinate model."""
from collections import defaultdict
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import heapq,math,shutil,time,traceback
import shapely
from shapely.geometry import Polygon,box,mapping
from shapely.geometry.polygon import orient
from shapely.affinity import translate
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from conservative_h5_round_obstacles import raw_obstacle
from conservative_h5_polygon_obstacles import expand,circle_check
from diagnose_h5_concave_gaps import polygons
from build_h5_occupied_area_relaxation import ROOT,SRC,PRIOR,load,write,digest
OUT=ROOT/'output/h5-direct-coordinate-domains-20261025'
AREA=ROOT/'output/h5-occupied-area-relaxation-20261025'
GAP=.22;STOCK_EXTRA=.02;NUMERICAL=.0001;GRID=100;COEFF=10**7;SECONDS=120;MERGE_CAP=100000

def rotate(pt,quarter,mirrored):
    x,y=pt;x=-x if mirrored else x
    return [(x,y),(-y,x),(-x,-y),(y,-x)][quarter]

def classes(parts):
    result=[];aliases=[]
    for family in ['bracket','insert']:
        part=parts[family];base=Polygon(part['geometry'][0]['outer'])
        rects=[box(0,0,300,75),box(0,75,100,250)] if family=='bracket' else [box(0,0,180,110)]
        assert unary_union(rects).equals(base)
        for mirrored in ([False,True] if part['allow_mirror'] else [False]):
            for degrees in part['rotations']['degrees']:
                quarter=int(degrees/90);assert degrees==quarter*90
                pts=[rotate(pt,quarter,mirrored) for pt in part['geometry'][0]['outer']];xmin=min(p[0] for p in pts);ymin=min(p[1] for p in pts);g=Polygon([(x-xmin,y-ymin) for x,y in pts]);components=[]
                for rect in rects:
                    q=Polygon([(x-xmin,y-ymin) for x,y in [rotate(pt,quarter,mirrored) for pt in rect.exterior.coords]]);assert q.equals(box(*q.bounds));components.append(list(q.bounds))
                assert unary_union([box(*b) for b in components]).equals(g)
                equivalent=next((r for r in result if r['family']==family and shapely.geometry.shape(r['polygon']).equals(g)),None)
                if equivalent is None:
                    equivalent={'index':len(result),'family':family,'degrees':degrees,'mirrored':mirrored,'original_zero_bounds_min':[xmin,ymin],'polygon':mapping(g),'rectangular_components':components,'width_mm':g.bounds[2],'height_mm':g.bounds[3]};result.append(equivalent)
                aliases.append({'family':family,'degrees':degrees,'mirrored':mirrored,'class':equivalent['index'],'original_zero_bounds_min':[xmin,ymin]})
    assert len(result)==10 and len(aliases)==12
    return result,aliases

def merge_convex(region,deadline):
    triangles=[t for p in polygons(region) for t in shapely.constrained_delaunay_triangles(p).geoms]
    if not triangles:return [],{'triangles':0,'attempts':0,'merges':0,'cap_reached':False,'time_reached':False}
    assert unary_union(triangles).equals(region)
    faces={i:g for i,g in enumerate(triangles)};edgefaces=defaultdict(list);neighbors={i:set() for i in faces}
    for i,g in faces.items():
        xy=list(g.exterior.coords)
        for a,b in zip(xy,xy[1:]):edgefaces[tuple(sorted([a,b]))].append(i)
    queue=[]
    for ids in edgefaces.values():
        for a,b in combinations(ids,2):neighbors[a].add(b);neighbors[b].add(a);heapq.heappush(queue,(min(a,b),max(a,b)))
    attempts=merges=0
    while queue and attempts<MERGE_CAP and time.perf_counter()<deadline:
        a,b=heapq.heappop(queue)
        if a not in faces or b not in faces or b not in neighbors[a]:continue
        attempts+=1;u=faces[a].union(faces[b])
        if u.geom_type!='Polygon' or not u.equals(u.convex_hull):continue
        adjacent=(neighbors[a]|neighbors[b])-{a,b};faces[a]=u;del faces[b];merges+=1;neighbors[a]=adjacent
        for j in adjacent:
            neighbors[j].discard(b);neighbors[j].add(a);heapq.heappush(queue,(min(a,j),max(a,j)))
        del neighbors[b]
    gs=[faces[i] for i in sorted(faces)];assert unary_union(gs).equals(region) and all(g.equals(g.convex_hull) for g in gs)
    return gs,{'triangles':len(triangles),'attempts':attempts,'merges':merges,'cap_reached':bool(queue) and attempts>=MERGE_CAP,'time_reached':bool(queue) and time.perf_counter()>=deadline,'remaining_triangles_or_faces_preserved':True}

def halfspaces(poly,maxx,maxy):
    points=list(orient(poly,sign=1.).exterior.coords);rows=[]
    for p,q in zip(points,points[1:]):
        x0,y0=map(F,p);x1,y1=map(F,q);a=y1-y0;b=x0-x1
        if a==b==0:continue
        c=a*x0+b*y0;A=round(a*COEFF);B=round(b*COEFF);error=abs(A-a*COEFF)*maxx+abs(B-b*COEFF)*maxy+1;C=math.floor(c*GRID*COEFF-error)
        assert max(abs(A)*maxx+abs(B)*maxy,abs(C))<2**60
        rows.append({'edge':[list(p),list(q)],'a':A,'b':B,'upper':C,'rounding_error_bound':[error.numerator,error.denominator]})
    assert len(rows)>=3
    return rows

def main():
    OUT.mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json');pool=load(PRIOR/'candidates.json');mp=load(PRIOR/'mapping.json');core=mp['core_groups'][0];screen=load(AREA/'fixed-core-margin-census/checks.json');assert screen['passing_sufficient_distance_screen']==[0] and load(AREA/'audit-verified/checks.json')['passed'];assert GAP>screen['compensated_sheet_separation_mm'] and STOCK_EXTRA>screen['conversion_guard_mm']
    orientations,aliases=classes(parts);queries=[{'index':i,'orientation_class':o['index'],'sheet_id':sheet} for i,(o,sheet) in enumerate((o,s) for o in orientations for s in ['sheet-0','sheet-1'])];paths=[SRC/'job.json',SRC/'conditional-target.json',PRIOR/'candidates.json',PRIOR/'mapping.json',AREA/'audit-verified/checks.json',AREA/'fixed-core-margin-census/checks.json',AREA/'next-step.json',ROOT/'output/conservative_h5_polygon_obstacles.py'];maxx=math.ceil(st['width']*GRID);maxy=math.ceil(st['height']*GRID)
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'fixed_core':core,'required_counts':{p['id']:p['quantity'] for p in job['parts']},'queries':queries,'orientation_classes':orientations,'all_permitted_orientation_aliases':aliases,'query_seconds':SECONDS,'per_query_merge_attempt_limit':MERGE_CAP,'new_part_separation_mm':GAP,'offset_numerical_margin_mm':NUMERICAL,'extra_stock_margin_mm':STOCK_EXTRA,'coordinate_units_per_mm':GRID,'coefficient_scale':COEFF,'coordinate_maxima':[maxx,maxy],'declared_later_solver_seconds':60,'declared_later_solver_workers':8,'declared_later_solver_seed':0,'method':'Use source-exact quarter-turn integer affine transforms to normalize the two bracket rectangles and one insert rectangle by their bounding-box minimum. All12 allowed orientations are represented by10 exactly equivalent normalized classes. Reconstruct fixed original polygons, form zero-clearance Minkowski obstacles for each normalized class, and expand their union by the verified circumscribed128-gon with clearance0.22 plus0.0001mm numerical margin. Subtract this from inward stock anchor domains with0.02mm additional margin. Constrained triangulation exactly covers each safe region; merge only exactly convex adjacent unions. Merge caps preserve all unmerged faces. Encode each CCW face edge with exact rational coefficients from its stored binary-float vertices. Round a,b times10^7 to integers, subtract the exact worst-case coefficient error over positive bounded grid coordinates plus one unit, and floor the bound. Every admitted0.01mm-grid point therefore lies inside that safe convex face. This is a conservative feasible-subset construction, not a continuous outer relaxation or unrestricted impossibility test.','limits':'One120-second geometry phase, with no new query after its deadline. Preserve pending queries, cap-hit unmerged faces and all failures; do not extend or rerun. No solver runs in this script. A later model is allowed only after independent geometry/rounding verification and model field checks; one60-second eight-worker seed-zero solve is declared here.','later_model':'Require all12 brackets and21 inserts; fix all18 frames and15 cogs from core0. Coordinates, orientations and sheet assignments may change. Pairwise axis-separation constraints apply only across different physical parts; the two arms of the same bracket are allowed to touch. Identical-copy ordering only removes interchangeable-copy symmetry. No area or partial-count objective.','native_margin_qualified':False,'solver_calls':0,'held_out_files_evaluated':0,'shapely_version':shapely.__version__,'geos_version':shapely.geos_version_string})
    write(OUT/'clearance-polygon-check.json',circle_check(GAP,NUMERICAL));write(OUT/'orientations.json',{'classes':orientations,'aliases':aliases});fixed={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in core['fixed_candidates']};write(OUT/'fixed-core.json',{'candidate_ids':core['fixed_candidates'],'placements':[pool[i]['placement'] for i in core['fixed_candidates']],'polygons':[mapping(fixed[i]) for i in core['fixed_candidates']]})
    cache={};cache_checks=[];completed=[];start=time.perf_counter();deadline=start+SECONDS
    for query in queries:
        if time.perf_counter()>=deadline:break
        began=time.perf_counter();o=orientations[query['orientation_class']];moving=shapely.geometry.shape(o['polygon']);ids=[i for i in core['fixed_candidates'] if pool[i]['placement']['sheet_id']==query['sheet_id']];obstacles=[]
        for i in ids:
            p=pool[i]['placement'];t=p['transform'];key=(p['part_id'],float(t['rotation_radians']).hex(),t['mirrored'],o['index'])
            if key not in cache:
                local=raw_obstacle(shape(parts[p['part_id']],{**t,'translation':[0.,0.]}),moving);direct=raw_obstacle(fixed[i],moving);shifted=translate(local,*t['translation']);err=shifted.symmetric_difference(direct).area;hd=shifted.hausdorff_distance(direct);assert err<1e-4 and hd<1e-7;cache[key]=local;cache_checks.append({'key':list(key),'first_fixed_candidate':i,'area_error_mm2':err,'hausdorff_error_mm':hd,'raw_local_geometry':mapping(local)})
            obstacles.append(translate(cache[key],*t['translation']))
        raw=unary_union(obstacles);forbidden=expand(raw,GAP,NUMERICAL);height=st['height'] if query['sheet_id']=='sheet-0' else target['required_used_height_mm'];bounds=[m['left']+edge+STOCK_EXTRA,m['bottom']+edge+STOCK_EXTRA,st['width']-m['right']-edge-STOCK_EXTRA-o['width_mm'],height-m['top']-edge-STOCK_EXTRA-o['height_mm']];domain=box(*bounds);region=domain.difference(forbidden);faces,mergestats=merge_convex(region,deadline);rows=[]
        for face in faces:
            a,b,c,d=face.bounds;coordinate_bounds=[math.ceil(a*GRID),math.ceil(b*GRID),math.floor(c*GRID),math.floor(d*GRID)];rows.append({'polygon':mapping(face),'coordinate_bounds':coordinate_bounds,'halfspaces':halfspaces(face,maxx,maxy)})
        record={**query,'family':o['family'],'fixed_candidates':ids,'domain_bounds_mm':bounds,'raw_forbidden':mapping(raw),'expanded_forbidden':mapping(forbidden),'safe_region':mapping(region),'faces':rows,'merge':mergestats,'seconds':time.perf_counter()-began};write(OUT/'queries'/f"{query['index']:03d}.json",record);completed.append(record);print({'query':query['index'],'faces':len(rows),'triangles':mergestats['triangles'],'seconds':record['seconds']},flush=True)
    write(OUT/'cache-checks.json',cache_checks);write(OUT/'pending.json',queries[len(completed):]);result={'seconds':time.perf_counter()-start,'planned_queries':len(queries),'completed_queries':len(completed),'pending_queries':len(queries)-len(completed),'convex_faces':sum(len(q['faces']) for q in completed),'empty_regions':sum(not q['faces'] for q in completed),'cached_obstacles':len(cache),'original_orientation_classes':len(aliases),'unique_normalized_classes':len(orientations),'independent_audit_pending':True,'solver_calls':0,'native_margin_qualified':False,'full_target_witness':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
