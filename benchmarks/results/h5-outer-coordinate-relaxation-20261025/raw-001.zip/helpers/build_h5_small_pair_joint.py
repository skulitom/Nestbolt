"""Complete conditional graph extended only by independently audited pair-contact geometry."""
from collections import Counter
from datetime import datetime,timezone
import shutil,time
import numpy as np
import shapely
from shapely.strtree import STRtree
from audit_h5_cog_lattices import shape
from build_h5_individual_frame_joint import ROOT,SRC,load,write,digest,read_graph,save_graph
OLD=ROOT/'output/h5-shifted-core-small-joint-20261023';REG=ROOT/'output/h5-small-pair-contacts-20261023';OUT=ROOT/'output/h5-small-pair-joint-20261023'

def main():
    assert load(REG/'audit/checks.json')['passed'];mp=load(REG/'audit/mapping.json');oldmp=load(OLD/'mapping.json');pool=load(REG/'candidates.json');oldpool=load(OLD/'candidates.json');ids=mp['candidates'];n0=len(oldmp['candidates']);assert pool[:len(oldpool)]==oldpool and ids[:n0]==oldmp['candidates'] and mp['compatible_groups'][:n0]==oldmp['compatible_groups'] and mp['core_groups']==oldmp['core_groups'] and mp['mapped_seeds'][:2]==oldmp['mapped_seeds'];assert n0==14046 and len(ids)==17481 and len(mp['mapped_seeds'])==4
    OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');inputs=[OLD/n for n in ['plan.json','candidates.json','mapping.json','adjacency.bin.gz','audit/checks.json']]+[REG/n for n in ['plan.json','candidates.json','audit/plan.json','audit/checks.json','audit/mapping.json','audit/provenance.json']]+[SRC/n for n in ['job.json','conditional-target.json']]
    manifest=ROOT/'benchmarks/results/h5-shifted-core-small-joint-20261023/raw-manifest.json';data=load(manifest);hashes={r['path']:r['sha256'] for r in data['files']+data['aliases']};sourcechecks=[]
    for path in inputs:
        if path.is_relative_to(OLD):key=OLD.name+'/'+path.relative_to(OLD).as_posix();assert hashes[key]==digest(path);sourcechecks.append({'source':path.relative_to(ROOT).as_posix(),'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':key,'sha256':digest(path)})
    write(OUT/'provenance.json',{'passed':True,'source_members_matching_committed_evidence':sourcechecks})
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'scope':'Fresh global small-part selection includes all14046 unchanged old choices and3435 independently verified pair-contact poses across the same seven fixed33-part cores. Preserve both original64 and both new63 baseline mappings. Pair-release neighborhoods generate new geometry only; the selection may move every small part.','graph':'Inherit every old-old geometric conflict only after exact source pool/mapping/core equivalence and committed-hash verification. Construct all new-old and new-new same-sheet conflicts from original outlines; independently reconstruct every new row using a sequential bounds scan. No derived clique and no conflict omitted due disjoint core memberships.','reduction_seconds':30,'maximum_reduction_comparisons':50000000,'compression_seconds':20,'additional_greedy_hint_calls':0,'solve_seconds':60,'solve_calls':1,'workers':8,'seed':0,'cp_model_presolve':False,'objective':'Unchanged variable area floor815800000 and full score895800000, with12 brackets and21 inserts at most and exactly one18-frame/15-cog core. Use the highest-area63-part hint but retain the original floor and both64-part feasible seeds. Reconstruct every model and parameter field independently; check every returned original layout and frozen CLI quantity outcome.','native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    shutil.copyfile(REG/'candidates.json',OUT/'candidates.json');write(OUT/'mapping.json',mp);start=time.perf_counter();job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};clear=job['clearance'];gs=np.asarray([shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in ids],dtype=object);sheets=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);adj=read_graph(OLD/'adjacency.bin.gz',n0)+[0]*(len(ids)-n0);oldedges=sum(v.bit_count() for v in adj)//2;near=edges=0
    for sheet in ['sheet-0','sheet-1']:
        js=np.flatnonzero(sheets==sheet);tree=STRtree(gs[js])
        for j in js[js>=n0]:
            ks=js[tree.query(gs[j],predicate='dwithin',distance=clear+1e-7)];ks=ks[ks<j];near+=len(ks);ks=ks[shapely.distance(gs[ks],gs[j])<clear-1e-7];j=int(j)
            for k in ks:k=int(k);adj[j]|=1<<k;adj[k]|=1<<j;edges+=1
    save_graph(OUT/'adjacency.bin.gz',adj);assert read_graph(OUT/'adjacency.bin.gz',len(ids))==adj and sum(v.bit_count() for v in adj)//2==oldedges+edges
    result={'seconds':time.perf_counter()-start,'variable_poses':len(ids),'old_variable_poses':n0,'new_variable_poses':len(ids)-n0,'families':dict(Counter(pool[i]['placement']['part_id'] for i in ids)),'core_choices':7,'old_geometric_edges':oldedges,'new_near_pairs':near,'new_geometric_edges':edges,'total_geometric_edges':oldedges+edges,'native_margin_qualified':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
