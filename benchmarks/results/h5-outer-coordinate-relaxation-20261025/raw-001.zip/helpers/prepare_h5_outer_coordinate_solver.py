"""Adapt the independently checked coordinate encoding to the new outer relaxation."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-outer-coordinate-relaxation-20261025';SOURCE=ROOT/'output/solve_h5_direct_coordinates.py';TARGET=ROOT/'output/solve_h5_outer_coordinates.py'
changes=[
('One predeclared exact-inventory coordinate solve after full independent encoding checks.','One predeclared exact-count outer coordinate relaxation after full independent encoding checks.'),
("BASE=ROOT/'output/h5-direct-coordinate-domains-20261025';RED=BASE/'reduced'","BASE=ROOT/'output/h5-outer-coordinate-relaxation-20261025';RED=BASE/'audit'"),
("BASE/'consolidated/audit/checks.json'","BASE/'audit/checks.json'"),
('assert gap==22 and scale==100','assert gap==-1 and scale==100'),
('inward-rounded halfspace','outward-rounded halfspace'),
('All domain choices remain; only independently certified containment removal was used.','Every outer domain remains; no domains are removed.'),
('must be separated along at least one axis by22 grid units','may overlap along the chosen axis by at most one grid unit'),
('Offline conditional feasibility model on the declared0.01mm grid and verified safe subdomains. A full witness still requires original geometry/CLI and native checks, original production budget and the full H5 matrix. UNKNOWN is not infeasibility; infeasibility would apply only to this restricted model. No repeated or extended solve.','Outer relaxation covering original continuous placements around fixed core0 via outward-rounded0.01mm grid domains. Every returned66-part model solution remains diagnostic and may overlap or violate original bounds. It is not an accepted cutting layout. UNKNOWN is unresolved; a negative result needs the complete outward-coverage audit and is conditional on this fixed core. No repeated or extended solve.'),
('],-2**63,-22,[same,directions[j]])','],-2**63,1,[same,directions[j]])'),
("f'incumbent-{i}-layout.json'","f'incumbent-{i}-relaxed-layout.json'"),
("'original_geometry_acceptance_pending':feasible","'original_geometry_diagnostic_pending':feasible,'full_model_solution_is_only_relaxation':True,'full_target_witness':False"),
("OUT/'positions.json'","OUT/'relaxed-positions.json'"),
("OUT/'layout.json'","OUT/'relaxed-layout.json'")]
s=SOURCE.read_text(encoding='utf-8');records=[]
for a,b in changes:
    count=s.count(a);assert count>0,(a,count);s=s.replace(a,b);records.append({'old':a,'new':b,'occurrences':count})
assert 'gap==22' not in s and ',-22,' not in s and 'safe subdomains' not in s and 'inward-rounded' not in s
with TARGET.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
shutil.copyfile(SOURCE,BASE/'inner-model-template.py')
with (BASE/'model-template-provenance.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'source':SOURCE.relative_to(ROOT).as_posix(),'source_sha256':sha256(SOURCE.read_bytes()).hexdigest(),'generated':TARGET.relative_to(ROOT).as_posix(),'generated_sha256':sha256(TARGET.read_bytes()).hexdigest(),'changes':records,'scope':'The independent model reconstruction remains enabled and must check the complete new outward-domain model before its sole solver call.'},f,indent=2);f.write('\n')
print({'generated':str(TARGET),'substitution_groups':len(records)})
