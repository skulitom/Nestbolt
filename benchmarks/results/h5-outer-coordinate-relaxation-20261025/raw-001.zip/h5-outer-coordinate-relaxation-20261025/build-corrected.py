"""Outer coordinate domains covering continuous original placements around fixed core 0."""
from fractions import Fraction as F
from datetime import datetime,timezone
from itertools import product
import math,shutil,time,traceback
from shapely.geometry import MultiPoint,shape as from_geojson,mapping
from shapely.geometry.polygon import orient
from shapely.ops import unary_union
from build_h5_direct_coordinate_domains import ROOT,OUT as INNER,AREA,load,write,digest
OUT=ROOT/'output/h5-outer-coordinate-relaxation-20261025'
SCALE=100;COEFF=10**7;EPS=.001;SECONDS=120

def outward(poly,maxx,maxy):
    pts=list(orient(poly,sign=1).exterior.coords);rows=[]
    for p,q in zip(pts,pts[1:]):
        x,y=map(F,p);u,v=map(F,q);a=v-y;b=x-u
        if a==b==0:continue
        c=a*x+b*y;A=round(a*COEFF);B=round(b*COEFF);err=abs(A-a*COEFF)*maxx+abs(B-b*COEFF)*maxy+1;upper=math.ceil(c*SCALE*COEFF+err);rows.append({'edge':[list(p),list(q)],'a':A,'b':B,'upper':upper,'rounding_error_bound':[err.numerator,err.denominator]})
    assert len(rows)>=3
    return rows

def main():
    assert load(AREA/'audit-verified/checks.json')['passed'] and load(INNER/'solve/result.json')['status']=='INFEASIBLE';OUT.mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'build.py');old=load(INNER/'plan.json');area=load(AREA/'plan.json');specs=area['specifications'];classes=[]
    for i,spec in enumerate(specs):
        alias=next(a for a in old['all_permitted_orientation_aliases'] if all(a[k]==spec[k] for k in ['family','degrees','mirrored']));base=old['orientation_classes'][alias['class']];classes.append({**base,'index':i,'degrees':spec['degrees'],'mirrored':spec['mirrored'],'original_zero_bounds_min':alias['original_zero_bounds_min'],'source_normalized_class':alias['class']})
    assert len(classes)==12;queries=[{'index':i,'orientation_class':c['index'],'sheet_id':s} for i,(c,s) in enumerate((c,s) for c in classes for s in ['sheet-0','sheet-1'])];paths=[INNER/'plan.json',INNER/'fixed-core.json',INNER/'solve/plan.json',INNER/'solve/result.json',INNER/'solve/next-step.json',AREA/'plan.json',AREA/'result.json',AREA/'audit-verified/checks.json'];maxx,maxy=old['coordinate_maxima'];plan={'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'fixed_core':old['fixed_core'],'required_counts':old['required_counts'],'orientation_classes':classes,'queries':queries,'coordinate_units_per_mm':SCALE,'coefficient_scale':COEFF,'coordinate_maxima':[maxx,maxy],'extra_outward_numerical_padding_mm':EPS,'coordinate_rounding':'floor both normalized anchor coordinates to the0.01mm grid','quantization_square_mm':[[-.01,-.01],[-.01,0.],[0.,0.],[0.,-.01]],'quantization_range_per_axis_mm':[-.01,0.],'new_part_separation_mm':-.01,'pair_overlap_allowance_units':1,'pair_overlap_is_relaxation_only':True,'query_seconds':SECONDS,'declared_later_solver_seconds':60,'declared_later_solver_workers':8,'declared_later_solver_seed':0,'method':'Reuse every independently audited50mm-cell outer translation hull for core0 from the continuous zero-clearance occupied-area construction. Keep all12 original orientation/reflection cases, including equivalent insert rotations. Shift each hull by the exact quarter-turn normalized bounding-box minimum, then Minkowski-add the floor-quantization square[-0.01,0]^2 plus0.001mm outward numerical padding in every direction. The independent audit must prove with rational vertex tests that every exact shifted source hull plus the full floor square is contained. Encode each resulting convex hull with outward-rounded integer halfspaces: round coefficients, add the exact worst-case coefficient error over the bounded coordinate range plus one unit, and ceil the right side. Outward integer bounding intervals retain the whole hull. Every original continuous placement represented by the committed source region therefore has a grid representative in these relaxed domains.','pair_relaxation_proof':'Original brackets are unions of two axis-aligned rectangles under exact quarter turns; inserts are one rectangle. Original positive-clearance placement implies those ideal rectangles from different parts do not intersect, since the checked floating transform error is far below0.2mm. Two nonoverlapping axis-aligned rectangles are ordered on x or y. Component offsets and dimensions are exact grid multiples, so flooring both anchors preserves a zero-gap axis order. Allowing a further one-grid-unit overlap is an intentional additional relaxation. Only pairs from different physical parts receive this rule.','stock_and_acceptance':'The source outer region deliberately expands original stock bounds and drops positive clearance. Its full two-sheet material target and fixed core are unchanged as inputs. Outer model solutions are diagnostic and cannot be accepted as cutting layouts. No native qualification, quality run or H5 completion is inferred. A negative result can concern only the recorded fixed core after full continuous-coverage and model verification.','limits':'One120-second construction phase; keep every pending query, never resume or extend. After independent geometry/rounding and model verification, one separately declared60-second/eight-worker/seed-zero solver call. Do not retry the completed inner model.','solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'plan.json',plan);shutil.copyfile(INNER/'fixed-core.json',OUT/'fixed-core.json');start=time.perf_counter();done=[]
    for query in queries:
        if time.perf_counter()-start>=SECONDS:break
        o=classes[query['orientation_class']];source_spec=next(q for q in area['queries'] if q['core_group']==0 and q['specification']==o['index'] and q['sheet_id']==query['sheet_id']);path=AREA/'queries'/f"{source_spec['index']:03d}.json";source=load(path);assert source['moving_transform']['rotation_radians']==math.radians(o['degrees']) and source['moving_transform']['mirrored']==o['mirrored'];source_hulls=[from_geojson(r['hull']) for r in source['cell_hulls']];assert from_geojson(source['translation_region']).difference(unary_union(source_hulls)).is_empty;rows=[];shift=o['original_zero_bounds_min']
        for i,h in enumerate(source_hulls):
            points=list(h.exterior.coords)[:-1];square=[(-.01-EPS,-.01-EPS),(-.01-EPS,EPS),(EPS,EPS),(EPS,-.01-EPS)];expanded=MultiPoint([(x+shift[0]+dx,y+shift[1]+dy) for (x,y),(dx,dy) in product(points,square)]).convex_hull;a,b,c,d=expanded.bounds;bounds=[math.floor(a*SCALE),math.floor(b*SCALE),math.ceil(c*SCALE),math.ceil(d*SCALE)];assert 0<=bounds[0]<=bounds[2]<=maxx and 0<=bounds[1]<=bounds[3]<=maxy;rows.append({'source_cell_hull':i,'source_cell':source['cell_hulls'][i]['cell'],'polygon':mapping(expanded),'coordinate_bounds':bounds,'halfspaces':outward(expanded,maxx,maxy)})
        row={**query,'family':o['family'],'source_query':path.relative_to(ROOT).as_posix(),'source_query_sha256':digest(path),'source_specification':o['index'],'faces':rows};write(OUT/'queries'/f"{query['index']:03d}.json",row);done.append(row)
    write(OUT/'pending.json',queries[len(done):]);result={'seconds':time.perf_counter()-start,'planned_queries':len(queries),'completed_queries':len(done),'pending_queries':len(queries)-len(done),'outer_domains':sum(len(q['faces']) for q in done),'independent_audit_pending':True,'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
