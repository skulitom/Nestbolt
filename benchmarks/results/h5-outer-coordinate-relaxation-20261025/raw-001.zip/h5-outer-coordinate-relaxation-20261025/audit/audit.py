"""Verify continuous coverage, outward rational rounding and all known core-0 placements."""
from collections import Counter,defaultdict
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product,combinations
import math,shutil,time,traceback
from shapely.geometry import shape as from_geojson,box
from shapely.geometry.polygon import orient
from shapely.affinity import translate
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from build_h5_outer_coordinate_domains import ROOT,INNER,AREA,OUT as BASE,load,write,digest
OUT=BASE/'audit'

def edges(poly):
    points=list(orient(poly,sign=1).exterior.coords);result=[]
    for p,q in zip(points,points[1:]):
        x,y=map(F,p);u,v=map(F,q)
        if p!=q:result.append((v-y,x-u,(v-y)*x+(x-u)*y,p,q))
    return result

def contains_point(row,x,y):
    a,b,c,d=row['coordinate_bounds']
    return a<=x<=c and b<=y<=d and all(h['a']*x+h['b']*y<=h['upper'] for h in row['halfspaces'])

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');result=load(BASE/'result.json');classes=plan['orientation_classes'];scale=plan['coordinate_units_per_mm'];coef=plan['coefficient_scale'];maxx,maxy=plan['coordinate_maxima'];area=load(AREA/'plan.json');old=load(INNER/'plan.json');job=load(ROOT/'output/h5-skeleton-contact-selection-20261020/job.json');parts={p['id']:p for p in job['parts']};mp=load(ROOT/'output/h5-small-pair-joint-20261023/mapping.json');pool=load(ROOT/'output/h5-small-pair-joint-20261023/candidates.json');assert load(AREA/'audit-verified/checks.json')['passed'];assert plan['quantization_square_mm']==[[-.01,-.01],[-.01,0.],[0.,0.],[0.,-.01]] and plan['pair_overlap_allowance_units']==1 and plan['new_part_separation_mm']==-.01
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'result.json',BASE/'plan-correction.json',INNER/'plan.json',AREA/'audit-verified/checks.json']},'method':'Match all inherited inputs and24 original query records against committed evidence. Recheck each original translation-region union coverage. For every source hull, prove using exact rational vertex/edge inequalities that its exact normalized shift plus the complete floor-quantization square lies in the new hull. Convexity extends vertex containment to every continuous point. Re-derive outward-rounded integer coefficients, their full error allowance and outward bounds, then check every expanded-hull rational vertex satisfies all encoded inequalities. Check every original orientation/reflection and component union. Verify every known original compatible core0 pose has an encoded floor-grid representative, and check every cross-part rectangle pair of the saved core0 baseline. Keep the baseline partial and require66 parts in the future model. No solver call or accepted layout.'})
    manifests=[]
    for name in ['h5-occupied-area-relaxation-20261025','h5-direct-coordinate-domains-20261025','h5-direct-coordinate-selection-20261025']:
        p=ROOT/'benchmarks/results'/name/'raw-manifest.json';data=load(p);manifests.append((p,{r['path']:r['sha256'] for r in data['files']+data['aliases']}))
    provenance=[]
    def committed(p,h):
        assert digest(p)==h;relative=p.relative_to(ROOT).as_posix();keys=['source-inputs/'+relative]
        if p.is_relative_to(ROOT/'output'):keys.append(p.relative_to(ROOT/'output').as_posix())
        for manifest,rows in manifests:
            for key in keys:
                if key in rows and rows[key]==h:provenance.append({'source':relative,'sha256':h,'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':key});return
        raise AssertionError(('missing committed provenance',relative))
    for n,h in plan['inputs'].items():committed(ROOT/n,h)
    expected=[(f,a,mir) for f in ['bracket','insert'] for mir in ([False,True] if parts[f]['allow_mirror'] else [False]) for a in parts[f]['rotations']['degrees']];assert [(o['family'],o['degrees'],o['mirrored']) for o in classes]==expected and len(classes)==12
    transformerror=0.
    for o in classes:
        alias=next(a for a in old['all_permitted_orientation_aliases'] if (a['family'],a['degrees'],a['mirrored'])==(o['family'],o['degrees'],o['mirrored']));assert o['original_zero_bounds_min']==alias['original_zero_bounds_min'];source=old['orientation_classes'][alias['class']];assert o['rectangular_components']==source['rectangular_components'] and o['polygon']==source['polygon'];ideal=from_geojson(o['polygon']);rects=[box(*b) for b in o['rectangular_components']];assert unary_union(rects).equals(ideal) and all(all(float(x*scale).is_integer() for x in b) for b in o['rectangular_components']);original=shape(parts[o['family']],{'rotation_radians':math.radians(o['degrees']),'mirrored':o['mirrored'],'translation':[-v for v in o['original_zero_bounds_min']]});error=original.hausdorff_distance(ideal);assert error<1e-9;transformerror=max(transformerror,error)
    assert 2*transformerror<job['clearance']==.2;assert load(BASE/'fixed-core.json')==load(INNER/'fixed-core.json') and plan['fixed_core']==mp['core_groups'][0]
    domains=[];byquery=defaultdict(list);hulls=hschecks=requiredvertices=expandedvertices=0
    for spec in plan['queries']:
        q=load(BASE/'queries'/f"{spec['index']:03d}.json");assert all(q[k]==v for k,v in spec.items());o=classes[q['orientation_class']];p=ROOT/q['source_query'];committed(p,q['source_query_sha256']);source=load(p);assert source['core_group']==0 and source['specification']==o['index'] and source['sheet_id']==q['sheet_id'] and source['family']==o['family'];source_hulls=[from_geojson(r['hull']) for r in source['cell_hulls']];assert unary_union(source_hulls).equals(from_geojson(source['translation_outer_cover']));assert from_geojson(source['translation_region']).difference(unary_union(source_hulls)).is_empty;assert len(q['faces'])==len(source_hulls)
        for i,(row,oldhull) in enumerate(zip(q['faces'],source_hulls)):
            assert row['source_cell_hull']==i and row['source_cell']==source['cell_hulls'][i]['cell'];hull=from_geojson(row['polygon']);es=edges(hull);assert hull.is_valid and hull.equals(hull.convex_hull);points=[(F(x),F(y)) for x,y in list(hull.exterior.coords)[:-1]];assert all(a*x+b*y<=c for a,b,c,_,_ in es for x,y in points)
            sx,sy=map(F,o['original_zero_bounds_min']);required=[(F(x)+sx+dx,F(y)+sy+dy) for (x,y),(dx,dy) in product(list(oldhull.exterior.coords)[:-1],[(F(-1,100),F(-1,100)),(F(-1,100),F(0)),(F(0),F(0)),(F(0),F(-1,100))])];assert all(a*x+b*y<=c for a,b,c,_,_ in es for x,y in required);requiredvertices+=len(required);assert len(es)==len(row['halfspaces'])
            for (a,b,c,p0,p1),h in zip(es,row['halfspaces']):
                assert h['edge']==[list(p0),list(p1)];A=round(a*coef);B=round(b*coef);error=abs(A-a*coef)*maxx+abs(B-b*coef)*maxy+1;upper=math.ceil(c*scale*coef+error);assert (A,B,upper)==(h['a'],h['b'],h['upper']) and h['rounding_error_bound']==[error.numerator,error.denominator];assert upper-error>=c*scale*coef;hschecks+=1
            assert all(contains_point(row,x*scale,y*scale) for x,y in points+required);expandedvertices+=len(points);hulls+=1;di=len(domains);d={'query':q['index'],'face':i,'family':o['family'],'orientation_class':o['index'],'sheet_id':q['sheet_id'],'coordinate_bounds':row['coordinate_bounds'],'halfspaces':[{k:h[k] for k in ['a','b','upper']} for h in row['halfspaces']]};domains.append(d);byquery[q['index']].append(di)
    assert hulls==result['outer_domains']==953 and result['completed_queries']==24 and not load(BASE/'pending.json');known=[];lookup={};max_known_transform_error=0.
    for local,i in enumerate(mp['candidates']):
        if 0 not in mp['compatible_groups'][local]:continue
        p=pool[i]['placement'];t=p['transform'];o=next(o for o in classes if o['family']==p['part_id'] and o['mirrored']==t['mirrored'] and abs(math.remainder(t['rotation_radians']-math.radians(o['degrees']),math.tau))<1e-9);query=2*o['index']+int(p['sheet_id']=='sheet-1');anchor=[F(x)+F(d) for x,d in zip(t['translation'],o['original_zero_bounds_min'])];x,y=[math.floor(v*scale) for v in anchor];matched=next((j for j in byquery[query] if contains_point(domains[j],x,y)),None);assert matched is not None,(i,query,x,y);ideal=translate(from_geojson(o['polygon']),*[float(v) for v in anchor]);err=ideal.hausdorff_distance(shape(parts[p['part_id']],t));assert err<1e-8;max_known_transform_error=max(max_known_transform_error,err);record={'candidate':i,'query':query,'domain':matched,'class':o['index'],'sheet_id':p['sheet_id'],'x_units':x,'y_units':y};known.append(record);lookup[i]=record
    baseline=[];componentpairs=0
    for seed in mp['mapped_seeds']:
        if seed['core_group']!=0:continue
        chosen=seed['selected_variable_candidates'];assert all(i in lookup for i in chosen);records=[lookup[i] for i in chosen]
        for a,b in combinations(records,2):
            if a['sheet_id']!=b['sheet_id']:continue
            for aa,bb in product(classes[a['class']]['rectangular_components'],classes[b['class']]['rectangular_components']):
                ax0,ay0,ax1,ay1=[round(v*scale) for v in aa];bx0,by0,bx1,by1=[round(v*scale) for v in bb];assert a['x_units']+ax1<=b['x_units']+bx0+1 or b['x_units']+bx1<=a['x_units']+ax0+1 or a['y_units']+ay1<=b['y_units']+by0+1 or b['y_units']+by1<=a['y_units']+ay0+1;componentpairs+=1
        baseline.append({'parts':len(chosen)+33,'counts':dict(Counter(pool[i]['placement']['part_id'] for i in chosen)),'grid_representatives':records})
    assert len(baseline)==1 and baseline[0]['parts']==64;write(OUT/'known-pose-memberships.json',known);write(OUT/'baseline-grid-check.json',baseline);write(OUT/'integer-domains.json',domains);write(OUT/'selection.json',{'retained':list(range(len(domains))),'removed':[]});write(OUT/'provenance.json',{'passed':True,'source_members_matching_committed_evidence':provenance});counts=Counter(d['family'] for d in domains);checks={'passed':True,'seconds':time.perf_counter()-start,'committed_input_and_query_matches':len(provenance),'original_orientation_reflection_cases':12,'query_source_regions_recovered_completely':24,'source_hulls_and_outer_domains_verified':hulls,'exact_rational_required_quantization_vertices_covered':requiredvertices,'exact_rational_expanded_hull_vertices_encoded':expandedvertices,'outward_rational_halfspaces_verified':hschecks,'maximum_original_orientation_transform_error_mm':transformerror,'maximum_known_transformed_polygon_error_mm':max_known_transform_error,'known_compatible_original_poses_with_grid_representatives':len(known),'original_core0_baseline_parts':64,'baseline_cross_part_rectangle_pairs_verified':componentpairs,'per_family_domains':dict(counts),'per_copy_domain_choices':counts['bracket']*12+counts['insert']*21,'quantization_coverage_proof':'Exact convex vertex containment covers each entire source hull plus every floor displacement, then the entire expanded hull satisfies every outward encoded inequality and global bound. Source hulls cover every source translation region.','pair_coverage_proof':'Exact grid-multiple component dimensions/offsets and monotone floor preserve every continuous zero-gap axis order. The extra one-unit overlap only enlarges the relaxation. Original0.2mm clearance exceeds twice the measured ideal-quarter-turn transform error.','full_inventory_required_by_later_model':66,'relaxed_layouts_may_overlap_or_leave_original_stock':True,'solver_calls':0,'full_target_witness':False,'native_margin_qualified':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
