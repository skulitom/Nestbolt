"""One predeclared exact-count outer coordinate relaxation after full independent encoding checks."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
from itertools import combinations,product
from hashlib import sha256
import gc,json,math,shutil,sys,time,traceback
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-outer-coordinate-relaxation-20261025';RED=BASE/'audit';OUT=BASE/'solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    assert load(RED/'checks.json')['passed'] and load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');plan=load(BASE/'plan.json');domains=load(RED/'integer-domains.json');classes=plan['orientation_classes'];maxx,maxy=plan['coordinate_maxima'];scale=plan['coordinate_units_per_mm'];gap=math.ceil(plan['new_part_separation_mm']*scale);assert gap==-1 and scale==100;stride=(maxx+1)*(maxy+1);required=plan['required_counts'];assert required=={'frame':18,'bracket':12,'cog':15,'insert':21};groups=defaultdict(list)
    for i,d in enumerate(domains):groups[d['query']].append(i)
    queries=plan['queries'];assert set(groups)==set(q['index'] for q in queries);familyqueries={f:[q for q in queries if classes[q['orientation_class']]['family']==f] for f in ['bracket','insert']};inputs=[BASE/'plan.json',BASE/'fixed-core.json',BASE/'audit/checks.json',RED/'plan.json',RED/'integer-domains.json',RED/'selection.json',RED/'checks.json'];parameters=dict(max_time_in_seconds=60,num_search_workers=8,random_seed=0,cp_model_presolve=True,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False)
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'parameters':parameters,'maximum_solver_calls':1,'required_counts':required,'variable_part_counts':{'bracket':12,'insert':21},'fixed_core':0,'coordinate_units_per_mm':scale,'gap_units':gap,'method':'Exactly one orientation/sheet mode per original small-part copy. Its active mode chooses exactly one certified convex domain, linking shared anchor coordinates to every outward-rounded halfspace and bound. Every outer domain remains; no domains are removed. Rectangle-component offsets are exact weighted sums of the active mode offsets. Every pair of components belonging to different physical parts may overlap along the chosen axis by at most one grid unit when on the same sheet. The two arms of one bracket share its anchor/mode and are never separated from each other. Identical-copy sheet/y/x ordering only removes interchangeable-copy symmetry. There is no objective, unplaced-part variable, reduced quantity or partial solution.','presolve_rationale':'Enable ordinary presolve to simplify reified domain bounds. Disable expensive probing and automatic symmetry discovery; identical-copy symmetry is already encoded explicitly. These choices precede the sole60-second call and do not change feasible solutions.','scope':'Outer relaxation covering original continuous placements around fixed core0 via outward-rounded0.01mm grid domains. Every returned66-part model solution remains diagnostic and may overlap or violate original bounds. It is not an accepted cutting layout. UNKNOWN is unresolved; a negative result needs the complete outward-coverage audit and is conditional on this fixed core. No repeated or extended solve.'})
    start=time.perf_counter();model=cp_model.CpModel();vs=[];items=[];pairs=[]
    def var(lo,hi,name):
        v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
    def lin(terms,lo,hi,enforce=()):
        c=model.add_linear_constraint(sum(vs[i]*a for i,a in terms),lo,hi)
        if enforce:c.only_enforce_if([vs[i] if i>=0 else vs[-i-1].Not() for i in enforce])
    for family in ['bracket','insert']:
        for copy in range(required[family]):
            k=len(items);prefix=f'{family}-{copy}';x=var(0,maxx,prefix+'-x');y=var(0,maxy,prefix+'-y');sheet=var(0,1,prefix+'-sheet');key=var(0,2*stride-1,prefix+'-key');modes={};choices={}
            for q in familyqueries[family]:
                qi=q['index'];modes[qi]=var(0,1,prefix+f'-mode{qi}')
                for di in groups[qi]:choices[di]=var(0,1,prefix+f'-domain{di}')
            components=[]
            for ci in range(2 if family=='bracket' else 1):
                coords=[]
                for axis in range(4):
                    values=[round(classes[q['orientation_class']]['rectangular_components'][ci][axis]*scale) for q in familyqueries[family]];coords.append(var(min(values),max(values),prefix+f'-arm{ci}-offset{axis}'))
                components.append(coords)
            item={'index':k,'family':family,'copy':copy,'x':x,'y':y,'sheet':sheet,'key':key,'modes':modes,'choices':choices,'components':components};items.append(item)
            model.add_exactly_one([vs[i] for i in modes.values()])
            for q in familyqueries[family]:
                qi=q['index'];lin([(choices[di],1) for di in groups[qi]]+[(modes[qi],-1)],0,0)
                for di in groups[qi]:
                    d=domains[di];a,b,c,e=d['coordinate_bounds'];presence=[choices[di]];lin([(x,1)],a,c,presence);lin([(y,1)],b,e,presence)
                    for h in d['halfspaces']:lin([(x,h['a']),(y,h['b'])],cp_model.INT_MIN,h['upper'],presence)
            lin([(sheet,1)]+[(modes[q['index']],-int(q['sheet_id']=='sheet-1')) for q in familyqueries[family]],0,0)
            for ci,coords in enumerate(components):
                for axis,vid in enumerate(coords):lin([(vid,1)]+[(modes[q['index']],-round(classes[q['orientation_class']]['rectangular_components'][ci][axis]*scale)) for q in familyqueries[family]],0,0)
            lin([(key,1),(sheet,-stride),(y,-(maxx+1)),(x,-1)],0,0)
    for family in ['bracket','insert']:
        js=[r for r in items if r['family']==family]
        for a,b in zip(js,js[1:]):lin([(a['key'],1),(b['key'],-1)],cp_model.INT_MIN,0)
    for a,b in combinations(items,2):
        name=f"pair-{a['index']}-{b['index']}";same=var(0,1,name+'-same');lin([(a['sheet'],1),(b['sheet'],-1)],0,0,[same]);model.add(vs[a['sheet']]!=vs[b['sheet']]).only_enforce_if(vs[same].Not());arms=[]
        for ai,bi in product(range(len(a['components'])),range(len(b['components']))):
            aa=a['components'][ai];bb=b['components'][bi];dirs=[var(0,1,name+f'-arms{ai}-{bi}-dir{j}') for j in range(4)];terms=[[(a['x'],1),(aa[2],1),(b['x'],-1),(bb[0],-1)],[(b['x'],1),(bb[2],1),(a['x'],-1),(aa[0],-1)],[(a['y'],1),(aa[3],1),(b['y'],-1),(bb[1],-1)],[(b['y'],1),(bb[3],1),(a['y'],-1),(aa[1],-1)]]
            for direction,expr in zip(dirs,terms):lin(expr,cp_model.INT_MIN,-gap,[same,direction])
            model.add_bool_or([vs[same].Not()]+[vs[d] for d in dirs]);arms.append({'a':ai,'b':bi,'directions':dirs})
        pairs.append({'a':a['index'],'b':b['index'],'same':same,'arms':arms})
    assert len(items)==33 and len(pairs)==528 and sum(len(p['arms']) for p in pairs)==978;assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'));write(OUT/'mapping.json',{'items':items,'pairs':pairs,'stride':stride,'domain_source':(RED/'integer-domains.json').relative_to(ROOT).as_posix()})
    # Independent expected protobuf, derived again from the source domains and components.
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes());vi=ci=0;oracleitems=[];oraclepairs=[]
    def checkvar(name,lo,hi):
        nonlocal vi
        expected=cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]);assert actual.variables[vi]==expected,(vi,name);vi+=1;return vi-1
    def checklinear(terms,lo,hi,enforcement=()):
        nonlocal ci
        merged=Counter()
        for idx,value in terms:merged[idx]+=value
        ids=sorted(i for i,v in merged.items() if v);expected=cp_model_pb2.ConstraintProto();expected.enforcement_literal.extend(enforcement);expected.linear.vars.extend(ids);expected.linear.coeffs.extend(merged[i] for i in ids);expected.linear.domain.extend([lo,hi]);assert actual.constraints[ci]==expected,(ci,actual.constraints[ci],expected);ci+=1
    def checkbool(kind,ids,enforcement=()):
        nonlocal ci
        expected=cp_model_pb2.ConstraintProto();expected.enforcement_literal.extend(enforcement);getattr(expected,kind).literals.extend(ids);assert actual.constraints[ci]==expected,(ci,kind);ci+=1
    for family,count in [('bracket',12),('insert',21)]:
        qs=[q for q in queries if classes[q['orientation_class']]['family']==family]
        for copy in range(count):
            prefix=f'{family}-{copy}';x=checkvar(prefix+'-x',0,maxx);y=checkvar(prefix+'-y',0,maxy);s=checkvar(prefix+'-sheet',0,1);key=checkvar(prefix+'-key',0,2*stride-1);modeids={};domainids={};comps=[]
            for q in qs:
                qi=q['index'];modeids[qi]=checkvar(prefix+f'-mode{qi}',0,1)
                for di,d in enumerate(domains):
                    if d['query']==qi:domainids[di]=checkvar(prefix+f'-domain{di}',0,1)
            for arm in range(2 if family=='bracket' else 1):
                ids=[]
                for axis in range(4):
                    vals=[int(classes[q['orientation_class']]['rectangular_components'][arm][axis])*100 for q in qs];ids.append(checkvar(prefix+f'-arm{arm}-offset{axis}',min(vals),max(vals)))
                comps.append(ids)
            checkbool('exactly_one',list(modeids.values()))
            for q in qs:
                ds=[i for i,d in enumerate(domains) if d['query']==q['index']];checklinear([(domainids[i],1) for i in ds]+[(modeids[q['index']],-1)],0,0)
                for di in ds:
                    d=domains[di];en=[domainids[di]];bound=d['coordinate_bounds'];checklinear([(x,1)],bound[0],bound[2],en);checklinear([(y,1)],bound[1],bound[3],en)
                    for h in d['halfspaces']:checklinear([(x,h['a']),(y,h['b'])],-2**63,h['upper'],en)
            checklinear([(s,1)]+[(modeids[q['index']],-1) for q in qs if q['sheet_id']=='sheet-1'],0,0)
            for arm,comp in enumerate(comps):
                for axis,vid in enumerate(comp):checklinear([(vid,1)]+[(modeids[q['index']],-int(classes[q['orientation_class']]['rectangular_components'][arm][axis])*100) for q in qs],0,0)
            checklinear([(key,1),(s,-stride),(y,-(maxx+1)),(x,-1)],0,0);oracleitems.append({'index':len(oracleitems),'family':family,'copy':copy,'x':x,'y':y,'sheet':s,'key':key,'modes':modeids,'choices':domainids,'components':comps})
    for family in ['bracket','insert']:
        familyitems=[r for r in oracleitems if r['family']==family]
        for a,b in zip(familyitems,familyitems[1:]):checklinear([(a['key'],1),(b['key'],-1)],-2**63,0)
    for a,b in combinations(oracleitems,2):
        name=f"pair-{a['index']}-{b['index']}";same=checkvar(name+'-same',0,1);checklinear([(a['sheet'],1),(b['sheet'],-1)],0,0,[same]);expected=cp_model_pb2.ConstraintProto();expected.enforcement_literal.append(-same-1);expected.linear.vars.extend([a['sheet'],b['sheet']]);expected.linear.coeffs.extend([1,-1]);expected.linear.domain.extend([-2**63,-1,1,2**63-1]);assert actual.constraints[ci]==expected;ci+=1;arms=[]
        for ai,aa in enumerate(a['components']):
            for bi,bb in enumerate(b['components']):
                directions=[checkvar(name+f'-arms{ai}-{bi}-dir{j}',0,1) for j in range(4)]
                for j,(left,right,lp,rp,end,startaxis) in enumerate([(a,b,aa,bb,2,0),(b,a,bb,aa,2,0),(a,b,aa,bb,3,1),(b,a,bb,aa,3,1)]):
                    axis='x' if j<2 else 'y';checklinear([(left[axis],1),(lp[end],1),(right[axis],-1),(rp[startaxis],-1)],-2**63,1,[same,directions[j]])
                checkbool('bool_or',[-same-1]+directions);arms.append({'a':ai,'b':bi,'directions':directions})
        oraclepairs.append({'a':a['index'],'b':b['index'],'same':same,'arms':arms})
    assert oracleitems==items and oraclepairs==pairs and vi==len(actual.variables)==len(vs) and ci==len(actual.constraints);extra=cp_model_pb2.CpModelProto();extra.CopyFrom(actual);extra.ClearField('variables');extra.ClearField('constraints');assert not extra.ListFields();solver=cp_model.CpSolver()
    for name,value in parameters.items():setattr(solver.parameters,name,value)
    expected_parameters=sat_parameters_pb2.SatParameters(**parameters);assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==expected_parameters;(OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');write(OUT/'model-audit.json',{'passed':True,'seconds':time.perf_counter()-start,'every_variable_constraint_and_parameter_independently_reconstructed':True,'variables':vi,'constraints':ci,'physical_small_parts':len(items),'original_fixed_parts':33,'required_total_parts':66,'domain_choice_booleans':sum(len(r['choices']) for r in items),'orientation_sheet_modes':sum(len(r['modes']) for r in items),'physical_part_pairs':len(pairs),'cross_part_rectangle_pairs':sum(len(r['arms']) for r in pairs),'same_part_rectangle_pairs_constrained':0,'copy_symmetry_order_constraints':31,'objective':'none; all quantities mandatory','model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt'),'ortools':ortools.__version__,'python':sys.version});print(load(OUT/'model-audit.json'),flush=True)
    fixed=load(BASE/'fixed-core.json')['placements'];records=[]
    def selection(value):
        positions=[]
        for item in items:
            active=[q for q,v in item['modes'].items() if value(vs[v])];selected=[d for d,v in item['choices'].items() if value(vs[v])];assert len(active)==len(selected)==1;q=queries[active[0]];assert domains[selected[0]]['query']==active[0];positions.append({'item':item['index'],'family':item['family'],'copy':item['copy'],'query':active[0],'domain':selected[0],'class':q['orientation_class'],'sheet_id':q['sheet_id'],'x_units':value(vs[item['x']]),'y_units':value(vs[item['y']])})
        layout={'version':1,'units':'mm','sheets':[{'id':s,'stock_id':'stock'} for s in ['sheet-0','sheet-1']],'placements':[]};counts=Counter()
        for p in fixed:
            p=json.loads(json.dumps(p));p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;layout['placements'].append(p)
        for p in positions:
            o=classes[p['class']];offset=o['original_zero_bounds_min'];f=p['family'];layout['placements'].append({'part_id':f,'copy_index':counts[f],'sheet_id':p['sheet_id'],'transform':{'rotation_radians':math.radians(o['degrees']),'mirrored':o['mirrored'],'translation':[p['x_units']/scale-offset[0],p['y_units']/scale-offset[1]]}});counts[f]+=1
        assert counts==Counter(required);return positions,layout
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            positions,layout=selection(self.value);i=len(records);write(OUT/f'incumbent-{i}-positions.json',positions);write(OUT/f'incumbent-{i}-relaxed-layout.json',layout);record={'index':i,'seconds':self.wall_time,'parts':len(layout['placements'])};records.append(record);print(record,flush=True)
    del actual,extra,oracleitems,oraclepairs;gc.collect();write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_calls':1,'seconds_limit':60,'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda message:(log.write(message+'\n'),log.flush());began=time.perf_counter();status=solver.solve(model,Capture());elapsed=time.perf_counter()-began
    feasible=status in [cp_model.FEASIBLE,cp_model.OPTIMAL];result={'status':solver.status_name(status),'seconds':elapsed,'has_full_model_solution':feasible,'incumbents':records,'response_stats':solver.response_stats(),'solver_calls':1,'original_geometry_diagnostic_pending':feasible,'full_model_solution_is_only_relaxation':True,'full_target_witness':False,'native_margin_qualified':False,'H5_complete':False}
    if feasible:
        positions,layout=selection(solver.value);write(OUT/'relaxed-positions.json',positions);write(OUT/'relaxed-layout.json',layout);result['counts']=dict(Counter(p['part_id'] for p in layout['placements']))
    else:result['interpretation']='No full model layout returned. UNKNOWN is not infeasibility. This grid/domain model cannot establish unrestricted impossibility.'
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():
            with (OUT/'failure.txt').open('x',encoding='utf-8',newline='\n') as f:f.write(traceback.format_exc())
        raise
