"""Independently check the projected cog and every original fixed-core distance."""
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import math,shutil
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
from build_h5_direct_coordinate_domains import ROOT,load,write,digest
BASE=ROOT/'output/h5-guarded-alternate-core-20261025';OUT=BASE/'audit'

def geometry(part,t):
    c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
    return affine_transform(Polygon(part['geometry'][0]['outer']),[m*c,-s,m*s,c,*t['translation']])

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');plan=load(BASE/'plan.json');fixed=load(BASE/'fixed-core.json');projection=load(BASE/'projection.json');checks=load(BASE/'checks.json');assert checks['passed'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'fixed-core.json',BASE/'projection.json',BASE/'checks.json']},'method':'Verify input hashes and all32 unchanged source placements. Independently transform the original filled polygons with the geometry library affine transform, derive allowable stock-translation intervals and the nearest-zero projection, compare every saved pair distance and boundary margin, and recheck against source-derived guard thresholds. No native acceptance or full packing claim.'})
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    source=ROOT/'output/h5-skeleton-contact-selection-20261020';job=load(source/'job.json');target=load(source/'conditional-target.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];pool=load(ROOT/'output/h5-small-pair-joint-20261023/candidates.json');positions=fixed['placements'];assert len(positions)==33 and Counter(p['part_id'] for p in positions)==Counter(frame=18,cog=15);i=fixed['source_candidate_ids'].index(fixed['changed_source_candidate']);assert positions[i]==projection['new_placement'] and projection['source_placement']==pool[fixed['changed_source_candidate']]['placement'];assert all(p==pool[j]['placement'] for k,(j,p) in enumerate(zip(fixed['source_candidate_ids'],positions)) if k!=i)
    old=projection['source_placement'];g=geometry(parts[old['part_id']],old['transform']);a,b,c,d=g.bounds;bounds=projection['guarded_stock_bounds_mm'];assert bounds==[m['left']+edge+plan['stock_extra_mm'],m['bottom']+edge+plan['stock_extra_mm'],stock['width']-m['right']-edge-plan['stock_extra_mm'],target['required_used_height_mm']-m['top']-edge-plan['stock_extra_mm']];intervals=[(bounds[0]-a,bounds[2]-c),(bounds[1]-b,bounds[3]-d)];delta=[lo if lo>0 else hi if hi<0 else 0 for lo,hi in intervals];assert all(abs(x-y)<1e-10 for x,y in zip(delta,projection['translation_delta_mm']));assert all(abs(x+dx-y)<1e-10 for x,dx,y in zip(old['transform']['translation'],delta,positions[i]['transform']['translation']));assert old['transform']['rotation_radians']==positions[i]['transform']['rotation_radians'] and old['transform']['mirrored']==positions[i]['transform']['mirrored']
    gs=[geometry(parts[p['part_id']],p['transform']) for p in positions];savedpairs=load(BASE/'pair-distances.json');rows=[]
    for a,b in combinations(range(33),2):
        if positions[a]['sheet_id']!=positions[b]['sheet_id']:continue
        distance=gs[a].distance(gs[b]);row=savedpairs[len(rows)];assert (a,b)==(row['a'],row['b']) and abs(distance-row['distance_mm'])<1e-9;assert gs[a].disjoint(gs[b]) and distance>=checks['compensated_sheet_separation_mm'];rows.append(distance)
    savededges=load(BASE/'stock-margins.json');margins=[]
    for k,g in enumerate(gs):
        height=stock['height'] if positions[k]['sheet_id']=='sheet-0' else target['required_used_height_mm'];a,b,c,d=g.bounds
        for side,v in [('left',a-m['left']-edge),('bottom',b-m['bottom']-edge),('right',stock['width']-m['right']-edge-c),('top',height-m['top']-edge-d)]:
            row=savededges[len(margins)];assert row['index']==k and row['side']==side and abs(row['extra_stock_margin_mm']-v)<1e-9 and v>=checks['conversion_guard_mm'];margins.append(v)
    assert len(rows)==438 and len(margins)==132;result={'passed':True,'changed_cogs':1,'unchanged_original_placements':32,'source_orientation_and_reflection_unchanged':True,'projection_delta_mm':delta,'original_polygon_pairs_verified':len(rows),'original_stock_boundary_margins_verified':len(margins),'minimum_pair_gap_mm':min(rows),'minimum_extra_stock_margin_mm':min(margins),'passes_sufficient_distance_screen':True,'native_margin_qualified':False,'full_target_witness':False,'solver_calls':0};write(OUT/'checks.json',result);print(result,flush=True)
if __name__=='__main__':main()
