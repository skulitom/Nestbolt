from pathlib import Path
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-extended-repair-probe-20261018'
assert json.loads((out/'before-extended-repair-v2/checks.json').read_bytes())['expected_runtime_failure']
path=out/'candidate/crates/core/src/sheets/vstrip/exchange.rs';s=path.read_text(encoding='utf-8');stub=(out/'stub.txt').read_text(encoding='utf-8')
implementation='''// Both phases share the original four-acceptance window cap.
fn continue_remaining_exchanges(
    accepted: usize,
    mut step: impl FnMut() -> Result<Option<bool>>,
) -> Result<usize> {
    let mut extra = 0;
    for _ in accepted..4 {
        let Some(material_improved) = step()? else { break };
        extra += 1;
        if !material_improved { break; }
    }
    Ok(extra)
}

fn source_repair_deadline(short: f64, phase: f64, extended: bool) -> f64 {
    if extended { phase } else { short }
}

'''
assert s.count(stub)==1;s=s.replace(stub,implementation)
needle='''                    // Same inventory can still improve the geometry, but a'''
strict='''                    // The additional phase must improve on the retained
                    // short-phase incumbent; a flat rearrangement is insufficient.
                    if extended && after.material_area >= before.material_area {
                        self.stats.extended_flat_rejections += 1;
                        continue;
                    }
'''
assert s.count(needle)==1;s=s.replace(needle,strict+needle)
path.write_text(s,encoding='utf-8',newline='\n');(out/'strict-guard.txt').write_text(strict,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True);shutil.copyfile(__file__,out/'apply.py')
print('Enabled bounded extended repairs after the unchanged short phase, with strict material gain required.')
