"""Validate saved two-phase and extended-mode outputs without rerunning authored searches."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math,shutil,subprocess
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-extended-repair-probe-20261018';out=probe/'extended-checks'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_checks_passed'];out.mkdir()
log=(probe/'core-tests.log').read_text(encoding='utf-8');assert '148 passed; 0 failed' in log
def rows(marker):return [json.loads(line.split(marker,1)[1]) for line in log.splitlines() if marker in line]
observations=rows('EXTENDED_REPAIR_WITNESS ');assert len(observations)==13
chain=rows('CHAIN_WITNESS ')
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
records=[]
for i,row in enumerate(observations):
 folder=out/f'case-{i}';folder.mkdir();write(folder/'witness.json',row);write(folder/'job.json',row['job']);parts={p['id']:p for p in row['job']['parts']};metrics={};pairs=0
 for kind in ['before','after']:
  write(folder/(kind+'.json'),row[kind]);args=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/(kind+'.json'))]
  r=subprocess.run(args,capture_output=True,timeout=60);(folder/(kind+'-stdout.json')).write_bytes(r.stdout);(folder/(kind+'-stderr.log')).write_bytes(r.stderr);write(folder/(kind+'-command.json'),{'command':args,'exit_code':r.returncode});assert r.returncode==0
  report=json.loads(r.stdout);assert report['valid'];metrics[kind]=report['metrics']
  assert Counter(p['part_id'] for p in row[kind]['placements'])==Counter({p['id']:p['quantity'] for p in row['job']['parts']})
  assert len({(p['part_id'],p['copy_index']) for p in row[kind]['placements']})==len(row[kind]['placements'])
  shapes=[]
  for placement in row[kind]['placements']:
   t=placement['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
   def tr(p):return (m*c*p[0]-s*p[1]+t['translation'][0],m*s*p[0]+c*p[1]+t['translation'][1])
   for g in parts[placement['part_id']]['geometry']:
    shape=Polygon([tr(p) for p in g['outer']]);assert shape.is_valid
    for sheet,other in shapes:
     if sheet==placement['sheet_id']:
      pairs+=1;assert shape.disjoint(other) and shape.distance(other)+1e-7>=row['job']['clearance']
    shapes.append((placement['sheet_id'],shape))
 stats=row['stats'];attempts=stats.get('extended_exchange_attempts',0);accepted=stats.get('extended_exchanges',0);flat=stats.get('extended_flat_rejections',0)
 assert all(type(x) is int and x>=0 for x in [attempts,accepted,flat])
 assert accepted<=attempts<=stats.get('directed_exchange_attempts',0) and flat+accepted<=attempts
 assert row['moved']==stats.get('directed_exchanges',0) and 0<=row['moved']<=4
 assert metrics['after']['material_area']<=metrics['before']['material_area']
 if row['moved']==0:assert row['after']==row['before']
 if row['mode']==1:
  assert accepted==row['moved']
  if accepted:assert metrics['after']['material_area']<metrics['before']['material_area'] and row['finished']<row['until']
 if row['mode']==2:assert row['fast_layout']==row['after'] and attempts==accepted==flat==0
 fast_reference=None
 if row['mode']==0 and row['budget']==5.0:
  baseline=next(x for x in chain if x['job']==row['job'] and x['seed']==row['seed'] and x['enabled'] and x['budget']==3.0)
  assert row['moved']>=baseline['moved'] and accepted==row['moved']-baseline['moved']
  write(folder/'fast-reference.json',baseline)
  case='larger_positive' if 'larger returned area' in row['job']['name'] else 'mixed_positive'
  previous=root/'output/h5-continuous-repair-probe-20261018/regression-checks'/f"{case}-s{row['seed']}"
  assert load(previous/'parent-layout.json')==baseline['after'] and load(previous/'job.json')==row['job']
  frozen=load(previous/'parent-stdout.json');assert frozen['valid']
  if accepted:assert metrics['after']['material_area']<frozen['metrics']['material_area']
  else:assert row['after']==baseline['after']
  fast_reference={'source':str(previous.relative_to(root)),'layout_sha256':digest(previous/'parent-layout.json'),'validation_sha256':digest(previous/'parent-stdout.json'),'material':frozen['metrics']['material_area']}
 records.append({'job':row['job']['name'],'seed':row['seed'],'mode':row['mode'],'enabled':row['enabled'],'budget':row['budget'],'moved':row['moved'],'extended_attempts':attempts,'extended_accepted':accepted,'extended_flat_rejections':flat,'before_material':metrics['before']['material_area'],'after_material':metrics['after']['material_area'],'filled_outer_pairs':pairs,'fast_reference':fast_reference})
assert sum(r['mode']==1 and r['extended_accepted']>0 for r in records)>=2
assert sum(r['extended_flat_rejections'] for r in records)>0
assert sum(r['mode']==2 for r in records)==1 and sum(r['fast_reference'] is not None for r in records)==2
target=Path(load(probe/'preparation.json')['target']);bins=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1;shutil.copyfile(bins[0],out/'authored-tests.exe');shutil.copyfile(__file__,out/'check.py')
checks={'all_checks_passed':True,'native_saved_outcomes':13,'public_CLI_validations':26,'filled_outer_pairs':sum(r['filled_outer_pairs'] for r in records),'records':records,'actual_extended_acceptance_observed':True,'actual_flat_rejection_observed':True,'successful_fast_incumbent_retained_after_expired_tail':True,'two_previous_opportunities_retained_or_strictly_improved':True,'CLI_sha256':expected,'test_binary_sha256':digest(bins[0]),'core_log_sha256':digest(probe/'core-tests.log'),'new_searches':0,'quality_claim':False}
write(out/'checks.json',checks)
# Reuse the previously independent-validated parent outputs by exact witness identity.
old_log=(root/'output/h5-exchange-chain-probe-20261018/core-tests.log').read_text(encoding='utf-8')
def witnesses(text):
 result={}
 for line in text.splitlines():
  for marker in ['LARGER_RETURN_WITNESS ','MIXED_WITNESS ']:
   if marker in line:
    row=json.loads(line.split(marker,1)[1]);result[(row['case'],row['seed'])]=row
 return result
old=witnesses(old_log);new=witnesses(log);restored=[]
for key in [('larger_positive',3),('mixed_positive',0),('mixed_frozen',0)]:
 assert new[key]==old[key] and new[key]['moved']==1
 previous=root/'output/h5-continuous-repair-probe-20261018/regression-checks'/f'{key[0]}-s{key[1]}'
 assert load(previous/'parent-witness.json')==new[key]
 assert load(previous/'parent-stdout.json')['valid']
 restored.append({'case':key[0],'seed':key[1],'whole_witness_exact':True,'validated_parent_witness_sha256':digest(previous/'parent-witness.json'),'validation_sha256':digest(previous/'parent-stdout.json')})
write(probe/'restored-witnesses.json',{'all_checks_passed':True,'previously_failing_cases_restored_exactly':3,'records':restored,'core_log_sha256':digest(probe/'core-tests.log'),'parent_log_sha256':digest(root/'output/h5-exchange-chain-probe-20261018/core-tests.log'),'new_searches':0})
print(json.dumps({'saved_outcomes':13,'CLI_checks':26,'filled_outer_pairs':checks['filled_outer_pairs'],'old_regressions_restored_exactly':3,'extended_accepts':sum(r['extended_accepted'] for r in records),'flat_rejections':sum(r['extended_flat_rejections'] for r in records)}))
