"""Reconstruct all files and restore the preceding short-phase runtime exactly."""
from pathlib import Path
from hashlib import sha256
import ast,difflib,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-extended-repair-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');assert load(out/'build.json')['all_checks_passed'];parent=Path(plan['old_probe'])/'candidate';rel=plan['changed_files'][0]
prior=(parent/rel).read_text(encoding='utf-8');current=(out/'candidate'/rel).read_text(encoding='utf-8')
old_runtime,old_tests=prior.split('#[cfg(test)]\nmod tests {',1);runtime,tests=current.split('#[cfg(test)]\nmod tests {',1)
a=runtime.index('// Both phases share');b=runtime.index('impl<F:',a);helper=runtime[a:b];restored=runtime[:a]+runtime[b:]
a=restored.index('    pub(super) fn directed_exchange_window(');b=restored.index('    pub(super) fn directed_exchange_chain(',a);phases=restored[a:b];restored=restored[:a]+restored[b:]
assert 'let accepted = self.directed_exchange_chain(strip, frozen, sep, shape, short_until)?;' in phases
assert 'self.extend_exchange_chain(strip, frozen, sep, shape, until, accepted)?' in phases
a=restored.index('    fn directed_exchange_once(');b=restored.index('    /// At most one exchange.',a);wrapper=restored[a:b];assert 'self.directed_exchange_mode(strip, frozen, sep, shape, until, false)' in wrapper;restored=restored[:a]+restored[b:]
restored=restored.replace('fn directed_exchange_mode(','fn directed_exchange_once(').replace('        extended: bool,\n','')
for line in ['                    self.stats.extended_exchange_attempts += u64::from(extended);\n','                    self.stats.extended_exchanges += u64::from(extended);\n']:
 assert restored.count(line)==1;restored=restored.replace(line,'')
a=restored.index('                    let source_until =');b=restored.index('                    let (source_snapshot, source_tracker)',a);call=restored[a:b]
assert 'source_repair_deadline(pair_end, self.last_step(exchange_until), extended)' in call
restored=restored[:a]+restored[b:];restored=restored.replace('source_sep.separate(&self.deadline(source_until))','source_sep.separate(&self.deadline(pair_end))')
strict=(out/'strict-guard.txt').read_text(encoding='utf-8');assert restored.count(strict)==1;restored=restored.replace(strict,'')
assert restored==old_runtime
assert tests.split('    fn extended_exercise(',1)[0].rstrip()==old_tests.rsplit('\n}',1)[0].rstrip()
caller=plan['changed_files'][1];a=(parent/caller).read_text(encoding='utf-8');b=(out/'candidate'/caller).read_text(encoding='utf-8')
b=b.replace('self.directed_exchange_window(','self.directed_exchange_chain(').replace('                                    budget,\n','');assert b==a
stats=plan['changed_files'][2];a=(parent/stats).read_text(encoding='utf-8');b=(out/'candidate'/stats).read_text(encoding='utf-8')
start=b.index('    #[serde(skip_serializing_if = "is_zero")]\n    pub extended_exchange_attempts');end=b.index('    pub extended_flat_rejections: u64,',start)+len('    pub extended_flat_rejections: u64,\n');assert b[:start]+b[end:]==a
red=(out/'before-extended-repair-v2'/rel).read_text(encoding='utf-8');script=ast.parse((out/'apply.py').read_text(encoding='utf-8'))
implementation=next(ast.literal_eval(n.value) for n in script.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='implementation' for t in n.targets))
stub=(out/'stub.txt').read_text(encoding='utf-8');assert red.count(stub)==1
fresh=root/'output/h5-extended-repair-reconstruction-20261018';shutil.copytree(out/'candidate',fresh)
reconstructed=red.replace(stub,implementation);needle='                    // Same inventory can still improve the geometry, but a';assert reconstructed.count(needle)==1;reconstructed=reconstructed.replace(needle,strict+needle)
(fresh/rel).write_text(reconstructed,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
for row in plan['old_source_files']['candidate']:
 name=row['path'];assert digest(parent/name)==row['sha256'];assert (fresh/name).read_bytes()==(out/'candidate'/name).read_bytes()
 if name not in plan['changed_files']:assert digest(out/'candidate'/name)==row['sha256']
record={'all_checks_passed':True,'prior_tests_unchanged':141,'new_tests':7,'short_phase_runtime_exact_after_adapter_and_zero_counter_reversal':True,'caller_exact_after_dispatch_and_existing_budget_argument_reversal':True,'all_formatted_reconstructed_files_exact':True,'reconstructed_files':156,'unchanged_other_files':153,'unchanged_short_phase_cap_seconds':1.2,'maximum_total_accepted_exchanges_per_window':4,'new_stage_requires_strict_material_gain':True,'new_stage_uses_remaining_existing_relocation_allowance':True,'validation_reserve_preserved':True,'original_geometry_quantity_orientation_frozen_and_material_guards_preserved':True,'whole_search_budget_unchanged':True,'three_stage_counters_skip_zero_serialization':True,'no_new_random_samples':True,'new_searches':0}
for name in ['reconstruction.json','source-checks.json']:(out/name).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
patch=''
for rel in plan['changed_files']:patch+=''.join(difflib.unified_diff((parent/rel).read_text(encoding='utf-8').splitlines(True),(out/'candidate'/rel).read_text(encoding='utf-8').splitlines(True),fromfile='exchange-chain/'+rel,tofile='extended-repair/'+rel))
(out/'candidate.patch').write_text(patch,encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'check-source.py');print(json.dumps(record))
