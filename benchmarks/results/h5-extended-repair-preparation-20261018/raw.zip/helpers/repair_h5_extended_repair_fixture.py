"""Keep the initial red run and correct only its newly authored frozen-sheet fixture."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-extended-repair-probe-20261018';old=out/'before-extended-repair';failed=out/'preparation-frozen-fixture-failure'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
shutil.copytree(old,failed)
rows=[json.loads(x.split('EXTENDED_REPAIR_WITNESS ',1)[1]) for x in (old/'expected-failure.log').read_text(encoding='utf-8').splitlines() if 'EXTENDED_REPAIR_WITNESS ' in x]
row=next(x for x in rows if x['enabled'] and any(p['id']=='fixed' for p in x['job']['parts']))
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
write(failed/'witness.json',row);write(failed/'job.json',row['job']);metrics={}
cli=root/'target/release/nestbolt.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
for kind in ['before','after']:
 write(failed/(kind+'.json'),row[kind]);args=[str(cli),'validate','--job',str(failed/'job.json'),'--layout',str(failed/(kind+'.json'))]
 r=subprocess.run(args,capture_output=True,timeout=60);(failed/(kind+'-stdout.json')).write_bytes(r.stdout);(failed/(kind+'-stderr.log')).write_bytes(r.stderr);write(failed/(kind+'-command.json'),{'command':args,'exit_code':r.returncode});assert r.returncode==0
 value=json.loads(r.stdout);assert value['valid'];metrics[kind]=value['metrics']
assert metrics['before']['material_area']==metrics['after']['material_area'] and metrics['before']['last_sheet_id']==metrics['after']['last_sheet_id']=='sheet-0'
rel='crates/core/src/sheets/vstrip/exchange.rs';p=out/'candidate'/rel;s=p.read_text(encoding='utf-8');a=s.index('    fn extended_frozen_fixture(');b=s.index('\n    #[test]',a);block=s[a:b]
needle='rectangle("fixed", 10.0, 10.0)';assert block.count(needle)==1;block=block.replace(needle,'rectangle("fixed", 10.0, 94.0)');updated=s[:a]+block+s[b:]
assert updated.split('#[cfg(test)]\nmod tests {',1)[0]==s.split('#[cfg(test)]\nmod tests {',1)[0]
p.write_text(updated,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
generator=root/'output/prepare_h5_extended_repair.py';g=generator.read_text(encoding='utf-8');needle='job.parts.push(rectangle("fixed",10.0,10.0));';assert g.count(needle)==1
shutil.copyfile(generator,failed/'original-prepare.py');generator.write_text(g.replace(needle,'job.parts.push(rectangle("fixed",10.0,94.0));'),encoding='utf-8',newline='\n');shutil.copyfile(generator,out/'prepare.py')
write(failed/'repair.json',{'cause':'The small frozen sheet controls the whole-job trailing offcut, so the proposed positive gain is impossible even though the swap succeeds.','CLI_checks':2,'metrics':metrics,'repair':'Increase only the newly authored frozen sheet part height from 10 to 94 mm. Keep every assertion and all 141 prior test bodies.','runtime_unchanged':True,'initial_red_log_sha256':digest(old/'expected-failure.log'),'initial_red_binary_sha256':digest(old/'authored-tests.exe'),'no_quality_runs':True})
shutil.copyfile(__file__,failed/'repair.py')
s=(root/'output/check_h5_extended_repair_red.py').read_text(encoding='utf-8').replace("assert not target.exists()","assert target.is_dir()").replace("out=probe/'before-extended-repair'","out=probe/'before-extended-repair-v2'")
(root/'output/check_h5_extended_repair_red_v2.py').write_text(s,encoding='utf-8',newline='\n')
p=root/'output/apply_h5_extended_repair.py';s=p.read_text(encoding='utf-8').replace("out/'before-extended-repair/checks.json'","out/'before-extended-repair-v2/checks.json'");p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'preserved_original_red_run':True,'original_material':metrics['before']['material_area'],'limiting_sheet':'sheet-0','new_fixture_height_mm':94,'runtime_unchanged':True}))
