"""Retain short exchanges, then try strictly improving continuous repairs with remaining time."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];old=root/'output/h5-exchange-chain-probe-20261018';out=root/'output/h5-extended-repair-probe-20261018'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert json.loads((root/'benchmarks/results/h5-continuous-repair-failure-20261018/checks.json').read_bytes())['optimized_tests_failed']==3
out.mkdir()
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel;original=path.read_text(encoding='utf-8');s=original
stub='''// Both phases share the original four-acceptance window cap.
fn continue_remaining_exchanges(
    _accepted: usize,
    _step: impl FnMut() -> Result<Option<bool>>,
) -> Result<usize> {
    Ok(0)
}

fn source_repair_deadline(short: f64, _phase: f64, _extended: bool) -> f64 {
    short
}

'''
needle='impl<F: FnMut(&Progress, &dyn Fn() -> Option<Layout>)> Search';assert s.count(needle)==1;s=s.replace(needle,stub+needle)
needle='    pub(super) fn directed_exchange_chain('
methods='''    pub(super) fn directed_exchange_window(
        &mut self, strip: &Strip, frozen: &[SPProblem], sep: &mut Separator,
        shape: Shape, short_until: f64, until: f64,
    ) -> Result<usize> {
        let accepted = self.directed_exchange_chain(strip, frozen, sep, shape, short_until)?;
        let extra = self.extend_exchange_chain(strip, frozen, sep, shape, until, accepted)?;
        Ok(accepted + extra)
    }

    fn extend_exchange_chain(
        &mut self, strip: &Strip, frozen: &[SPProblem], sep: &mut Separator,
        shape: Shape, until: f64, accepted: usize,
    ) -> Result<usize> {
        continue_remaining_exchanges(accepted, || self.directed_exchange_mode(strip, frozen, sep, shape, until, true))
    }

'''
assert s.count(needle)==1;s=s.replace(needle,methods+needle)
needle='''    /// At most one exchange. The original separator is untouched until both'''
wrapper='''    fn directed_exchange_once(
        &mut self, strip: &Strip, frozen: &[SPProblem], sep: &mut Separator,
        shape: Shape, until: f64,
    ) -> Result<Option<bool>> {
        self.directed_exchange_mode(strip, frozen, sep, shape, until, false)
    }

'''
assert s.count(needle)==1;s=s.replace(needle,wrapper+needle)
a=s.index(needle);b=s.index('\n}\n\n#[cfg(test)]\nmod tests',a);body=s[a:b]
body=body.replace('fn directed_exchange_once(','fn directed_exchange_mode(')
needle='''        until: f64,
    ) -> Result<Option<bool>>''';assert body.count(needle)==1;body=body.replace(needle,'''        until: f64,
        extended: bool,
    ) -> Result<Option<bool>>''')
needle='                    self.stats.directed_exchange_attempts += 1;';assert body.count(needle)==1;body=body.replace(needle,needle+'\n                    self.stats.extended_exchange_attempts += u64::from(extended);')
needle='''                    let (source_snapshot, source_tracker) =
                        source_sep.separate(&self.deadline(pair_end));'''
replacement='''                    let source_until = source_repair_deadline(pair_end, self.last_step(exchange_until), extended);
                    let (source_snapshot, source_tracker) =
                        source_sep.separate(&self.deadline(source_until));'''
assert body.count(needle)==1;body=body.replace(needle,replacement)
needle='                    self.stats.directed_exchanges += 1;';assert body.count(needle)==1;body=body.replace(needle,needle+'\n                    self.stats.extended_exchanges += u64::from(extended);')
s=s[:a]+body+s[b:]
caller=out/'candidate/crates/core/src/sheets/vstrip.rs';c=caller.read_text(encoding='utf-8');assert c.count('self.directed_exchange_chain(')==1
c=c.replace('self.directed_exchange_chain(','self.directed_exchange_window(')
needle='''                                    exchange_until,
                                )''';assert c.count(needle)==1;c=c.replace(needle,'''                                    exchange_until,
                                    budget,
                                )''');caller.write_text(c,encoding='utf-8',newline='\n')
stats_rel='crates/core/src/sheets.rs';p=out/'candidate'/stats_rel;c=p.read_text(encoding='utf-8');needle='    pub mixed_exchanges: u64,'
fields='''
    #[serde(skip_serializing_if = "is_zero")]
    pub extended_exchange_attempts: u64,
    #[serde(skip_serializing_if = "is_zero")]
    pub extended_exchanges: u64,
    #[serde(skip_serializing_if = "is_zero")]
    pub extended_flat_rejections: u64,'''
assert c.count(needle)==1;p.write_text(c.replace(needle,needle+fields),encoding='utf-8',newline='\n')
# Reuse the unchanged full fixture setup and its exact rollback/geometry checks.
a=original.index('    fn chain_exercise(');b=original.index('    // BEGIN exchange-chain tests',a);helper=original[a:b]
helper=helper.replace('fn chain_exercise(','fn extended_exercise(').replace('        budget: f64,','        phase: (f64, f64, u8),')
helper=helper.replace('        let validation = validate(job, layout).unwrap();','        let (short_budget, budget, mode) = phase;\n        let validation = validate(job, layout).unwrap();',1)
needle='''        let moved = search
            .directed_exchange_chain(&strip, frozen, &mut sep, shape, until)
            .unwrap();'''
dispatch='''        let short_until = if short_budget<=0.0 {0.0} else {search.clock.now()+short_budget};
        let mut fast_layout = None;
        let moved = match mode {
            0 => search.directed_exchange_window(&strip,frozen,&mut sep,shape,short_until,until).unwrap(),
            1 => usize::from(search.directed_exchange_mode(&strip,frozen,&mut sep,shape,until,true).unwrap().is_some()),
            2 => {
                let accepted=search.directed_exchange_chain(&strip,frozen,&mut sep,shape,short_until).unwrap();
                assert!(accepted>0);
                let fingerprint_before=fingerprint(&sep.layout);
                fast_layout=Some(search.exchange_layout(&strip,frozen,&sep.layout,shape).unwrap());
                let expired=search.clock.now();
                let extra=search.extend_exchange_chain(&strip,frozen,&mut sep,shape,expired,accepted).unwrap();
                assert_eq!(extra,0);assert_eq!(fingerprint(&sep.layout),fingerprint_before);
                accepted
            },
            _ => unreachable!(),
        };'''
assert helper.count(needle)==1;helper=helper.replace(needle,dispatch).replace('CHAIN_WITNESS','EXTENDED_REPAIR_WITNESS')
helper=helper.replace('"budget":budget,','"budget":budget,"short_budget":short_budget,"mode":mode,"fast_layout":fast_layout,"stats":search.stats,')
tests='''
    // BEGIN extended-repair tests
    #[test]
    fn extended_repair_shares_four_acceptance_cap_and_stops_after_no_move() {
        for accepted in 0..=4 {
            let mut calls=0;
            let extra=continue_remaining_exchanges(accepted,||{calls+=1;Ok(Some(true))}).unwrap();
            assert_eq!(extra,4-accepted,"Remaining allowance must be usable");assert_eq!(calls,4-accepted);
        }
        let mut calls=0;assert_eq!(continue_remaining_exchanges(1,||{calls+=1;Ok(None)}).unwrap(),0);assert_eq!(calls,1);
    }

    fn extended_frozen_fixture() -> (Job,Layout) {
        let (mut job,mut layout)=fixture();job.parts.push(rectangle("fixed",10.0,94.0));
        for p in &mut layout.placements {p.sheet_id=if p.sheet_id=="sheet-0" {"sheet-1".into()}else{"sheet-2".into()};}
        layout.sheets.push(Sheet{id:"sheet-2".into(),stock_id:"stock".into()});
        layout.placements.push(Placement{part_id:"fixed".into(),copy_index:0,sheet_id:"sheet-0".into(),transform:RigidTransform{translation:[2.0,2.0],..Default::default()}});(job,layout)
    }

    #[test]
    fn extended_repair_actual_whole_job_gain_preserves_frozen_sheet_and_replays() {
        let (job,layout)=extended_frozen_fixture();
        let (_,baseline,_)=extended_exercise(&job,&layout,0,false,(0.0,3.0,1),1);
        let (moved,after,stats)=extended_exercise(&job,&layout,0,true,(0.0,3.0,1),1);
        assert_eq!(moved,1);assert_eq!(stats.extended_exchanges,1);assert!(stats.extended_exchange_attempts>0);
        assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area<validate(&job,&baseline).unwrap().metrics.unwrap().material_area);
        let (again,replay,_)=extended_exercise(&job,&layout,0,true,(0.0,3.0,1),1);
        assert_eq!(again,moved);assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(replay).unwrap());
    }

    #[test]
    fn extended_repair_rejects_actual_flat_swap_and_requires_strict_gain() {
        let (job,layout)=larger_return_fixture();let (_,baseline,_)=extended_exercise(&job,&layout,0,false,(0.0,3.0,1),0);
        let (moved,after,stats)=extended_exercise(&job,&layout,0,true,(0.0,3.0,1),0);
        assert!(stats.extended_flat_rejections>0,"Actual flat tail proposal must be rejected");
        if moved>0 {assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area<validate(&job,&baseline).unwrap().metrics.unwrap().material_area);}
        else {assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(baseline).unwrap());}
    }

    #[test]
    fn extended_repair_expired_tail_preserves_successful_fast_incumbent_exactly() {
        let (job,layout)=fixture();let (moved,_,stats)=extended_exercise(&job,&layout,0,true,(3.0,3.0,2),0);
        assert!(moved>0);assert_eq!(stats.extended_exchange_attempts,0);assert_eq!(stats.extended_exchanges,0);
    }

    #[test]
    fn extended_repair_disabled_deadline_and_failed_source_keep_incumbents() {
        let (job,layout)=chain_fixture();
        for (enabled,phase) in [(false,(1.2,5.4,0)),(true,(0.0,0.0,0)),(true,(1e-12,1e-12,0)),(true,(0.0,0.0,1))] {
            let (moved,_,stats)=extended_exercise(&job,&layout,0,enabled,phase,0);assert_eq!(moved,0);assert_eq!(stats.extended_exchanges,0);
        }
        let (mut job,layout)=fixture();job.parts[1]=rectangle("return",5.0,90.0);job.parts[2]=rectangle("incoming",30.0,30.0);
        let (moved,_,stats)=extended_exercise(&job,&layout,0,true,(1.2,3.0,0),0);assert_eq!(moved,0);assert_eq!(stats.extended_exchanges,0);
    }

    #[test]
    fn extended_repair_preserves_fast_opportunities_and_only_improves_afterward() {
        for ((job,layout),seed) in [(larger_return_fixture(),3),(mixed_fixture(),0)] {
            let (fast,baseline,_)=chain_exercise(&job,&layout,seed,true,3.0,0);assert!(fast>0);
            let (moved,after,stats)=extended_exercise(&job,&layout,seed,true,(3.0,5.0,0),0);
            assert!((fast..=4).contains(&moved));assert_eq!(stats.directed_exchanges,moved as u64);
            assert_eq!(stats.extended_exchanges,(moved-fast) as u64);
            if moved>fast {assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area<validate(&job,&baseline).unwrap().metrics.unwrap().material_area);}
            else {assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(baseline).unwrap());}
        }
    }
    // END extended-repair tests
'''
# Preserve the known useful source witness, with the new mode-aware deadline adapter.
parent_failed=root/'output/h5-continuous-repair-probe-20261018/candidate'/rel
f=parent_failed.read_text(encoding='utf-8');a=f.index('    #[test]\n    fn continuous_repair_can_clear_source_after_short_slice_has_elapsed');b=f.index('\n    #[test]',a+8)
witness=f[a:b].replace('continuous_repair_can_clear_source_after_short_slice_has_elapsed','extended_repair_source_can_clear_after_short_slice_has_elapsed')
witness=witness.replace('let (_, source_until) = repair_deadlines(now, full_until);','let source_until = source_repair_deadline(former_source, full_until, true);')
assert 'repair_deadlines' not in witness
pos=s.rindex('\n}');s=s[:pos]+'\n\n'+helper+tests+witness+s[pos:];path.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},'changed_files':[rel,'crates/core/src/sheets/vstrip.rs',stats_rel],'added_files':{},'production_digest':source_digest(),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),'target':str(root/'output/h5-extended-repair-target-20261018'),'unchanged_prior_tests':141,'new_tests':7,'normal_mode_unchanged':True,'measured_search_started':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n');(out/'stub.txt').write_text(stub,encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'prepared':True,'prior_tests':141,'new_tests':7,'new_searches':0}))
