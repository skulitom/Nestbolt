"""Seal the two-phase candidate's qualification before measuring quality."""
from pathlib import Path
from hashlib import sha256
import json, shutil, sys, zipfile
root=Path(__file__).resolve().parents[1]
probe=root/'output/h5-extended-repair-probe-20261018'
out=root/'benchmarks/results/h5-extended-repair-preparation-20261018'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');source=load(probe/'reconstruction.json')
public=load(probe/'public-checks/checks.json');branch=load(probe/'branch-checks/checks.json')
extended=load(probe/'extended-checks/checks.json');repair=load(probe/'repair-checks/checks.json');restored=load(probe/'restored-witnesses.json')
assert all(x['all_checks_passed'] for x in [build,source,public,branch,extended,repair,restored])
assert '148 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert source['prior_tests_unchanged']==141 and source['unchanged_other_files']==153
assert source['short_phase_runtime_exact_after_adapter_and_zero_counter_reversal']
assert source['caller_exact_after_dispatch_and_existing_budget_argument_reversal']
for folder in ['before-extended-repair','before-extended-repair-v2']:
 red=load(probe/folder/'checks.json')
 assert digest(probe/folder/'expected-failure.log')==red['log_sha256']
 assert digest(probe/folder/'authored-tests.exe')==red['binary_sha256']
assert red['expected_runtime_failure']
fixture=load(probe/'preparation-frozen-fixture-failure/repair.json')
assert fixture['runtime_unchanged'] and fixture['CLI_checks']==2
assert digest(probe/'before-extended-repair/expected-failure.log')==fixture['initial_red_log_sha256']
assert digest(probe/'before-extended-repair/authored-tests.exe')==fixture['initial_red_binary_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
 for row in rows:
  assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
  if not (arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for rel,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/rel)==expected
assert public['observer_outcomes']==10 and public['CLI_cross_checks']==4
assert branch['actual_outcomes']==12 and branch['public_validations']==24
assert extended['native_saved_outcomes']==13 and extended['public_CLI_validations']==26
assert repair['public_CLI_checks']==2 and repair['independent_final_filled_outer_pairs']==300
assert restored['previously_failing_cases_restored_exactly']==3
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8')
assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json')
assert digest(root/method['reference'])==method['reference_sha256']
assert digest(root/method['candidate_runner'])==method['runner_sha256']
assert method['scoring_measurement_and_PID_reuse_guard_unchanged']
counter=load(probe/'counter-audit-method.json')
assert digest(root/'output/finish_h5_extended_repair_pilot.py')==counter['candidate_finisher_sha256']
assert digest(root/counter['parent'])==counter['parent_sha256']
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
helpers=['prepare_h5_extended_repair.py','repair_h5_extended_repair_fixture.py',
 'check_h5_extended_repair_red.py','check_h5_extended_repair_red_v2.py',
 'apply_h5_extended_repair.py','build_h5_extended_repair.py','prepare_h5_extended_repair_checks.py',
 'check_h5_extended_repair_source.py','check_h5_extended_repair_witness.py',
 'check_h5_extended_repair_source_witness.py','check_h5_extended_repair_public.py',
 'check_h5_extended_repair_branch.py','check_h5_extended_repair_harness.py',
 'prepare_h5_extended_repair_finish.py','finish_h5_extended_repair_pilot.py',
 'audit_h5_extended_repair.py','seal_h5_extended_repair.py','record_h5_extended_repair_preparation.py']
for name in helpers:files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_extended_repair_pilot.py'
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()}
out.mkdir();archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(inventory)
 for n,row in inventory.items():
  b=z.read(n);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_functional_checks_pass':True,'optimized_core_tests_passed':148,'prior_tests_unchanged':141,'new_tests':7,
 'expected_three_runtime_failures_preserved':True,'initial_new_fixture_failure_preserved':True,
 'strict_lint_passed':True,'observer_build_passed':True,'short_phase_runtime_and_deadline_retained':True,
 'extended_phase_requires_strict_material_gain':True,'maximum_combined_exchanges_per_window':4,
 'whole_search_budget_and_validation_reserve_unchanged':True,'original_guards_preserved':True,
 'all_156_formatted_files_reconstruct_exactly':True,'unchanged_other_files':153,
 'actual_branch_outcomes':12,'branch_frozen_CLI_checks':24,'extended_witness_outcomes':13,
 'extended_witness_CLI_checks':26,'extended_witness_filled_outer_pairs':106,
 'source_repair_CLI_checks':2,'source_repair_final_filled_outer_pairs':300,
 'previous_opportunities_restored_exactly':3,'public_observer_outcomes':10,'public_CLI_cross_checks':4,
 'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,'pilot_harness_tests':5,
 'PID_reuse_guard_unchanged':True,'extended_counter_subset_checks_added':True,
 'production_unchanged':True,'measurement_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','source-checks.json','reconstruction.json','candidate.patch','pilot-method.json','counter-audit-method.json','restored-witnesses.json']:
 shutil.copyfile(probe/name,out/name)
for sub,name in [('before-extended-repair','initial-red'),('before-extended-repair-v2','expected-failure'),('public-checks','public-checks'),('branch-checks','branch-checks'),('extended-checks','extended-checks'),('repair-checks','repair-checks')]:
 shutil.copyfile(probe/sub/'checks.json',out/(name+'.json'))
shutil.copyfile(probe/'preparation-frozen-fixture-failure/repair.json',out/'fixture-repair.json')
doc='''# Extended repair after the short phase — preparation, 2026-10-18

The [direct long-source experiment](h5-continuous-repair-failure-20261018.md)
lost three existing authored exchange opportunities. This isolated candidate
retains the original short phase, including its 1.2-second cap and proposal order,
then uses the remaining existing relocation allowance for longer source repairs.
The two phases share the four-acceptance cap. Each extended acceptance must strictly
reduce whole-job material; flat trials are rejected. Original geometry, quantity,
orientation, frozen-sheet, filled-hole, material and deadline guards remain,
including the validation reserve. The overall search budget is unchanged.

All 148 optimized core tests pass: 141 prior test bodies unchanged and seven new
regressions. The new tests cover the combined cap, strict extended gain, flat
rejection, replay, failed/expired operations, preservation of a successful short
phase after tail expiry, earlier opportunities and actual source repair after
the short allowance. The three previously failing witnesses match their validated
parent witnesses exactly. The corrected new tests first produce three expected
old-behavior failures, while four preservation tests pass; both source and binary
are retained. The first red run also exposed a newly authored fixture error:
a small frozen sheet controlled the whole-job offcut, so the proposed exchange
could not improve material. Two independent CLI checks confirm equal 21,300 mm²
before/after. Only that new fixed part's height changed from 10 to 94 mm;
assertions and all 141 older test bodies remain unchanged. Both red runs survive.

Thirteen saved extended outcomes pass 26 frozen-CLI checks and 106 independent
filled-outer pair checks. The source-repair witness has 25 squares: its initial
overlapping proposal is retained as invalid, its repaired result is valid, and
all 300 final pairs pass. Its prior 300,000 evaluations are explicitly simulated
to exercise expiry; this is a functional fixture, not a performance measurement.
Twelve original branch outputs pass 24 CLI checks. Ten public outcomes and four
CLI comparisons confirm normal-mode equivalence except wall time and exact common
replay. Strict lint, the executable build and five adversarial harness tests pass.

All 156 formatted source files reconstruct exactly; 153 are unchanged. Reversing
the added dispatch, adapters and zero-valued stage counters restores the original
short phase and caller. No new random sample is introduced. Measurement, scoring,
rotating arm order and process identity checks are AST-identical to the prior
pilot. Added evidence checks bound extended counts by total counts and retain the
shared four-acceptance cap. Counter values alone do not establish final quality.

The next pilot must commit its plan before measuring four development jobs, both
kerfs and three seeds at matched 60-second budgets on eight physical CCD0 cores.
No quality measurement has begun. H5 still requires every original material
limit and the full 13-job evaluation. Production and release claims are unchanged.
**H2/H5 remain open; completed milestone weight is 60%.**

[Checks](h5-extended-repair-preparation-20261018/checks.json),
[authored geometry](h5-extended-repair-preparation-20261018/extended-checks.json),
[restored witnesses](h5-extended-repair-preparation-20261018/restored-witnesses.json),
[source reconstruction](h5-extended-repair-preparation-20261018/reconstruction.json),
[raw evidence](h5-extended-repair-preparation-20261018/raw.zip),
[archive integrity](h5-extended-repair-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
print(json.dumps({'all_functional_checks_pass':True,'members':len(inventory),'archive_bytes':archive.stat().st_size,'new_quality_runs':0}))
