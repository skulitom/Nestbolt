from pathlib import Path
import json, subprocess
root=Path(__file__).resolve().parents[1]
out=root/'benchmarks/results/h5-extended-repair-preparation-20261018'
assert json.loads((out/'checks.json').read_bytes())['all_functional_checks_pass']
prior=(root/'BENCHMARKS.md').read_bytes()
assert prior==subprocess.check_output(['git','show','HEAD:BENCHMARKS.md'],cwd=root)
note='''**N4 two-phase repair qualification, 2026-10-18:** the [isolated candidate](../benchmarks/results/h5-extended-repair-preparation-20261018.md)
retains the original short exchange phase, then uses the remaining existing
relocation allowance for longer source repairs. Both phases share four accepted
exchanges; the extended phase requires strict material gains. The original guards,
overall budget and validation reserve remain. All 148 optimized tests pass:
141 old bodies unchanged and seven new regressions. The three opportunities lost
by the rejected direct-long-source allocation match their prior witnesses exactly.
Both red runs and a corrected new frozen-sheet fixture are preserved. Thirteen
saved extended outcomes pass 26 CLI checks and independent geometry; the actual
source-repair fixture, original branch checks, public replay, source reconstruction,
lint, build and five harness tests also pass. A matched four-job pilot is ready
to be planned. No quality improvement, integration or H5 closure is claimed.
H2/H5 remain open at 60%; production and release claims are unchanged.
'''
def append(p,s):
 with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
append(root/'BENCHMARKS.md','\n\n## 2026-10-18 — Extended repair qualification after the short phase\n\n'+note.replace('../benchmarks/','benchmarks/'))
for name in ['docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md']:append(root/name,'\n\n'+note)
p=root/'docs/STATUS.md';s=p.read_text(encoding='utf-8');at=s.index('**N4 ')
s=s[:at]+note+'\n'+s[at:];p.write_text(s,encoding='utf-8',newline='\n')
append(root/'.gitattributes','\nbenchmarks/results/h5-extended-repair-preparation-20261018/** -text -whitespace\nbenchmarks/results/h5-extended-repair-pilot-20261018/** -text -whitespace\n')
assert (root/'BENCHMARKS.md').read_bytes().startswith(prior)
print('Recorded two-phase qualification; no new quality claims.')
