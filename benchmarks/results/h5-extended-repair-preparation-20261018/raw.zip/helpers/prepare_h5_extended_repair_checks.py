from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-extended-repair-probe-20261018'
for stage in ['public','branch','harness']:
 s=(root/f'output/check_h5_exchange_chain_{stage}.py').read_text(encoding='utf-8').replace('h5-exchange-chain','h5-extended-repair').replace('h5_exchange_chain','h5_extended_repair').replace('141 passed; 0 failed','148 passed; 0 failed')
 (root/f'output/check_h5_extended_repair_{stage}.py').write_text(s,encoding='utf-8',newline='\n')
s=(root/'output/check_h5_continuous_repair_witness.py').read_text(encoding='utf-8').replace('h5-continuous-repair','h5-extended-repair').replace('145 passed; 0 failed','148 passed; 0 failed')
(root/'output/check_h5_extended_repair_source_witness.py').write_text(s,encoding='utf-8',newline='\n')
ref=root/'scripts/h5_exchange_chain_pilot.py';original=ref.read_text(encoding='utf-8');s=original.replace('h5-exchange-chain-probe','h5-extended-repair-probe').replace('h5-exchange-chain-preparation','h5-extended-repair-preparation')
end=s.index('"""',3)+3;s='''"""Paired development pilot of a strictly improving extended source-repair phase.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The isolated candidate retains the previous short exchange phase, then uses
the remaining existing relocation allowance for continuous source repairs.
Additional acceptances require a strict material decrease. Both phases share
the four-exchange cap. Geometry, inventory, frozen-sheet and filled-hole guards
remain. Stage counters identify extended attempts, accepts and flat rejections.
141 prior tests and seven new regressions must qualify before measurement.
This descriptive pilot cannot close H5 or justify a comparative claim.
"""'''+s[end:]
s=s.replace('Isolated exchange-continuation candidate','Isolated extended-source-repair candidate')
s=s.replace("PROBE/'chain-checks/checks.json'", "PROBE/'extended-checks/checks.json', PROBE/'repair-checks/checks.json', PROBE/'restored-witnesses.json'")
s=s.replace("'previous_failed_pilot': 'benchmarks/results/h5-free-return-pilot-20261018/results.json'","'previous_failed_pilot': 'benchmarks/results/h5-exchange-chain-pilot-20261018/results.json'")
needle="ROOT/'benchmarks/results/h5-free-return-observer-20261018/source-review.json'";assert s.count(needle)==1
s=s.replace(needle,needle+",\n                  ROOT/'benchmarks/results/h5-exchange-chain-pilot-20261018/verification.json',\n                  ROOT/'benchmarks/results/h5-continuous-repair-failure-20261018/checks.json'")
path=root/'scripts/h5_extended_repair_pilot.py';assert not path.exists();compile(s,str(path),'exec');path.write_text(s,encoding='utf-8',newline='\n')
def fn(t,n):return next(x for x in ast.parse(t).body if isinstance(x,ast.FunctionDef) and x.name==n)
names=['blocks','summarize','case','measure','require_runner_stopped','require_measurements_finished']
for n in names:assert ast.dump(fn(s,n))==ast.dump(fn(original,n))
method={'reference':ref.relative_to(root).as_posix(),'reference_sha256':sha256(ref.read_bytes()).hexdigest(),'candidate_runner':path.relative_to(root).as_posix(),'runner_sha256':sha256(path.read_bytes()).hexdigest(),'identical_function_ASTs':names,'scoring_measurement_and_PID_reuse_guard_unchanged':True}
(probe/'pilot-method.json').write_text(json.dumps(method,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(method))
