"""Independently check the saved native source repair, retaining its invalid proposal."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math,shutil,subprocess
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-extended-repair-probe-20261018';out=probe/'repair-checks'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_checks_passed'];out.mkdir()
log=(probe/'core-tests.log').read_text(encoding='utf-8');assert '148 passed; 0 failed' in log
rows=[json.loads(line.split('CONTINUOUS_REPAIR_WITNESS ',1)[1]) for line in log.splitlines() if 'CONTINUOUS_REPAIR_WITNESS ' in line];assert len(rows)==1;row=rows[0]
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
write(out/'witness.json',row);write(out/'job.json',row['job']);parts={p['id']:p for p in row['job']['parts']};records=[]
for kind in ['before','after']:
 write(out/(kind+'.json'),row[kind]);args=[str(cli),'validate','--job',str(out/'job.json'),'--layout',str(out/(kind+'.json'))]
 r=subprocess.run(args,capture_output=True,timeout=60);(out/(kind+'-stdout.json')).write_bytes(r.stdout);(out/(kind+'-stderr.log')).write_bytes(r.stderr);write(out/(kind+'-command.json'),{'command':args,'exit_code':r.returncode})
 result=json.loads(r.stdout);assert result['valid']==(kind=='after');assert (r.returncode==0)==(kind=='after')
 assert Counter(p['part_id'] for p in row[kind]['placements'])==Counter({p['id']:p['quantity'] for p in row['job']['parts']})
 assert len({(p['part_id'],p['copy_index']) for p in row[kind]['placements']})==25
 shapes=[];pairs=0;collisions=0;minimum=math.inf
 for placement in row[kind]['placements']:
  t=placement['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
  def tr(p):return (m*c*p[0]-s*p[1]+t['translation'][0],m*s*p[0]+c*p[1]+t['translation'][1])
  for g in parts[placement['part_id']]['geometry']:
   shape=Polygon([tr(p) for p in g['outer']]);assert shape.is_valid
   for other in shapes:
    pairs+=1;collisions+=int(shape.intersects(other));minimum=min(minimum,shape.distance(other)-row['job']['clearance'])
   shapes.append(shape)
 assert pairs==300
 if kind=='before':assert collisions>0
 else:assert collisions==0 and minimum>=-1e-7
 records.append({'kind':kind,'expected_valid':kind=='after','CLI_exit':r.returncode,'pairs':pairs,'filled_outer_intersections':collisions,'minimum_clearance_slack_mm':minimum,'validation':result})
assert row['former_source_until']<row['source_started']<row['finished']<row['full_until']==row['source_until']
assert row['simulated_prior_evaluations']==300000 and row['work']['evaluations']>300000
target=Path(load(probe/'preparation.json')['target']);bins=list((target/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1
shutil.copyfile(bins[0],out/'authored-tests.exe');shutil.copyfile(__file__,out/'check.py')
checks={'all_checks_passed':True,'authored_repair_outcomes':1,'public_CLI_checks':2,'invalid_overlapping_proposal_preserved':True,'repaired_output_valid':True,'independent_final_filled_outer_pairs':300,'records':records,'source_started':row['source_started'],'former_source_until':row['former_source_until'],'finished':row['finished'],'full_until':row['full_until'],'CLI_sha256':expected,'test_binary_sha256':digest(bins[0]),'core_log_sha256':digest(probe/'core-tests.log'),'tests_reused_from_full_build':True,'new_searches':0,'quality_claim':False,'limitation':'The prior delay is explicitly simulated by 300,000 charged evaluations. Geometry is actually repaired by the native separator. This qualifies elapsed-slice policy and geometry only, not development quality or wall-time performance.'}
write(out/'checks.json',checks);print(json.dumps({k:checks[k] for k in ['all_checks_passed','public_CLI_checks','independent_final_filled_outer_pairs','source_started','former_source_until','finished','full_until']}))
