"""Tighten source-body conservation with a continuous circular outer cover."""
from pathlib import Path
from hashlib import sha256
from math import isqrt
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-free-cog-round-complement-20261108';OLD=ROOT/'output/h5-free-cog-complement-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();cases=load(OLD/'audit/remaining-cases.json');assert len(cases)==19 and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),OLD/'audit/checks.json',OLD/'audit/remaining-cases.json',OLD/'source-outer-bound.json']+[OLD/(r['case']+'.npz') for r in cases]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Reuse the independently certified outer cover of the companion complement and140.001mm all-angle source outer radius. For a center cell C and target cell Q, include Q exactly when the minimum squared distance between their closed squares is <=radius²; this covers every possible point of any rotated cog with center anywhere in C. The offset criterion is h²*(max(abs(dx)-1,0)²+max(abs(dy)-1,0)²)<=radius². Exact horizontal-prefix queries sum complement cells in this circular neighborhood, a subset of the earlier outer rectangle. Full cog area50000 minus this outside upper is compulsory companion-region occupancy. No grid center sampling, chosen source angle, optimizer or feasible-pose claim.','inherited_numeric_preparation_seconds':load(OLD/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':20,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
h=2500;ny,nx=1200,600;radius=load(OLD/'source-outer-bound.json')['source_outer_radius_um'];assert radius==140001;stripes=[]
for dy in range(-58,59):
    q=radius*radius-(h*max(abs(dy)-1,0))**2
    if q>=0:stripes.append([dy,isqrt(q)//h+1])
write(OUT/'kernel-stripes.json',{'step_um':h,'source_outer_radius_um':radius,'horizontal_stripes':stripes,'covered_target_cells':sum(2*w+1 for _,w in stripes),'minimum_distance_outer_cover':True});results=[]
for case in cases:
    name=case['case']
    with np.load(OLD/(name+'.npz'),allow_pickle=False) as z:
        domain=z['remaining_center_cells'];outer=z['complement_outer_cells'];yy,xx=np.nonzero(domain);selected=domain[z['source_y'],z['source_x']];previous_outside=z['outside_area_upper_um2'][selected];assert len(previous_outside)==len(xx)
    prefix=np.pad(outer.cumsum(1,dtype=np.int32),((0,0),(1,0)));counts=np.zeros(len(xx),dtype=np.int32)
    for dy,w in stripes:
        y=yy+dy;valid=(y>=0)&(y<ny);counts[valid]+=prefix[y[valid],np.minimum(nx,xx[valid]+w+1)]-prefix[y[valid],np.maximum(0,xx[valid]-w)]
    outside=counts.astype(np.int64)*h*h;assert np.all(outside<=previous_outside);forced=np.maximum(0,50000*10**6-outside);upper=case['first_companion_upper_um2'];required=case['required_first_companion_um2'];allowed=upper-forced>=required;remaining=domain.copy();remaining[yy,xx]=allowed
    np.savez_compressed(OUT/(name+'.npz'),source_y=yy,source_x=xx,outside_area_upper_um2=outside,forced_companion_overlap_lower_um2=forced,remaining_center_cells=remaining)
    results.append({'case':name,'omitted_sites':case['omitted_sites'],'input_center_cells':len(xx),'pruned_center_cells':int((~allowed).sum()),'remaining_center_cells':int(allowed.sum()),'first_companion_upper_um2':upper,'required_first_companion_um2':required,'maximum_outside_cog_area_upper_um2':int(outside.max()),'minimum_forced_companion_overlap_um2':int(forced.min()),'minimum_area_deficit_um2':int((required-upper+forced).min()),'provisional_exact_first32_excluded':not bool(allowed.any())})
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':19,'input_center_cells':sum(r['input_center_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
