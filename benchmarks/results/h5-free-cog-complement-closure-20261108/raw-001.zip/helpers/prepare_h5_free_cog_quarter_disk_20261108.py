"""Apply certified disk-domain witnesses to the surviving 2.5 mm cells."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-free-cog-quarter-disk-20261108';OLD=ROOT/'output/h5-free-cog-disk-domain-20261108';FINE=ROOT/'output/h5-free-cog-quarter-grid-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();bindings={}
for folder in [OLD/'audit',FINE/'audit']:
    assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
cases=load(FINE/'audit/remaining-cases.json');assert len(cases)==19
for p in [Path(__file__),OLD/'geometry.json',OLD/'audit/checks.json',FINE/'audit/remaining-cases.json',FINE/'audit/checks.json']+[FINE/(r['case']+'.npz') for r in cases]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reuse only the independently certified unchanged fixed-source disks, outward center intervals, frame inner rectangles and109mm moving source disk. Every inherited source/pose binding is rechecked. Apply complete stock/frame/cog corner witnesses to each new2.5mm surviving continuous cell, retaining all cells without a conclusive witness. No source angle sampling, optimizer or feasible-pose claim.','inherited_numeric_preparation_seconds':load(FINE/'audit/checks.json')['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':20,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
geometry=load(OLD/'geometry.json');assert geometry['cell_step_um']==5000;geometry={**geometry,'cell_step_um':2500};write(OUT/'geometry.json',geometry);domain=geometry['stock_center_domain_um'];frames=geometry['frame_inner_rectangles_um'];fixed=geometry['fixed_cog_disks'];r=geometry['moving_disk_radius_um'];rr=r+geometry['fixed_disk_radius_um'];results=[]
for case in cases:
    name=case['case']
    with np.load(FINE/(name+'.npz'),allow_pickle=False) as z:old=z['remaining_center_cells'];yy,xx=np.nonzero(old)
    x0=xx*2500;y0=yy*2500;x1=x0+2500;y1=y0+2500;stock=(x1>domain[0])&(y1>domain[1])&(x0<=domain[2])&(y0<=domain[3]);l=np.maximum(x0,domain[0]);b=np.maximum(y0,domain[1]);u=np.minimum(x1,domain[2]);v=np.minimum(y1,domain[3]);reasons=np.where(stock,0,1).astype(np.uint8);witness=np.full(len(xx),-1,dtype=np.int16)
    for i,(a,c,d,e) in enumerate(frames):
        dx=np.maximum(0,np.maximum(a-l,u-d));dy=np.maximum(0,np.maximum(c-b,v-e));bad=stock&(reasons==0)&(dx*dx+dy*dy<r*r);reasons[bad]=2;witness[bad]=i
    for disk in fixed:
        site=disk['site']
        if site in case['omitted_sites']:continue
        a,c,d,e=disk['center_interval_um'];dx=np.maximum(np.abs(l-d),np.abs(u-a));dy=np.maximum(np.abs(b-e),np.abs(v-c));bad=stock&(reasons==0)&(dx*dx+dy*dy<rr*rr);reasons[bad]=3;witness[bad]=site
    remaining=old.copy();remaining[yy,xx]=reasons==0;np.savez_compressed(OUT/(name+'.npz'),source_y=yy,source_x=xx,reason=reasons,witness=witness,remaining_center_cells=remaining)
    results.append({'case':name,'omitted_sites':case['omitted_sites'],'input_center_cells':len(xx),'stock_excluded_cells':int((reasons==1).sum()),'frame_excluded_cells':int((reasons==2).sum()),'fixed_cog_excluded_cells':int((reasons==3).sum()),'remaining_center_cells':int(remaining.sum()),'provisional_exact_first32_excluded':not bool(remaining.any())})
write(OUT/'case-results.json',results);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'cases':19,'input_center_cells':sum(r['input_center_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'provisional_excluded_cases':sum(r['provisional_exact_first32_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
