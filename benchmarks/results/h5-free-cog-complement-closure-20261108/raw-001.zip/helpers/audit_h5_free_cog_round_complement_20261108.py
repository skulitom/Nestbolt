"""Direct circular-stencil readback for the complete full-body area exclusion."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free-cog-round-complement-20261108';OUT=BASE/'audit';OLD=ROOT/'output/h5-free-cog-complement-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for folder in [BASE,OLD/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for p,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__),BASE/'kernel-stripes.json',BASE/'case-results.json',BASE/'checks.json']+list(BASE.glob('*.npz')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconcile the independently certified source outer disk, full-body lower area and complete companion-complement outer masks. Derive every circular outer-kernel cell by minimum distance from target rectangle corners to the clipped center rectangle, independent of producer integer-square-root stripes. For every2997 continuous center cell, directly count a clipped boolean stencil against the complement mask; no prefix queries. Verify stencil boundary controls, exact equality to all producer values, and every full-body area-deficit threshold. Circular neighborhood bounds every real center and every exact rigid source angle.'})
h=2500;ny,nx=1200,600;radius=load(OLD/'source-outer-bound.json')['source_outer_radius_um'];assert radius==140001;kernel=np.zeros((117,117),dtype=bool)
for dy in range(-58,59):
    for dx in range(-58,59):
        minimum=min((x-min(h,max(0,x)))**2+(y-min(h,max(0,y)))**2 for x in [dx*h,(dx+1)*h] for y in [dy*h,(dy+1)*h]);kernel[dy+58,dx+58]=minimum<=radius**2
savedkernel=load(BASE/'kernel-stripes.json');reconstructed=np.zeros_like(kernel)
for dy,w in savedkernel['horizontal_stripes']:reconstructed[dy+58,58-w:59+w]=True
assert np.array_equal(reconstructed,kernel) and int(kernel.sum())==savedkernel['covered_target_cells'];assert not kernel[0].any() and not kernel[-1].any() and not kernel[:,0].any() and not kernel[:,-1].any();assert (58*h)**2>radius**2
assert kernel[58,58] and kernel[58,115] and not kernel[58,116] and not kernel[115,115]
def count(outer,y,x):
    y0,y1=max(0,y-58),min(ny,y+59);x0,x1=max(0,x-58),min(nx,x+59);return np.count_nonzero(outer[y0:y1,x0:x1]&kernel[y0-y+58:y1-y+58,x0-x+58:x1-x+58])
fixture=np.zeros((ny,nx),dtype=bool);fixture[0,0]=True;assert count(fixture,0,0)==1 and count(fixture,ny-1,nx-1)==0 and count(fixture,0,57)==1 and count(fixture,0,58)==0
cases=load(OLD/'audit/remaining-cases.json');saved={r['case']:r for r in load(BASE/'case-results.json')};assert len(cases)==len(saved)==19;results=[]
for case in cases:
    name=case['case']
    with np.load(OLD/(name+'.npz'),allow_pickle=False) as z:
        domain=z['remaining_center_cells'];outer=z['complement_outer_cells'];yy,xx=np.nonzero(domain);selected=domain[z['source_y'],z['source_x']];previous=z['outside_area_upper_um2'][selected]
    outside=np.array([count(outer,int(y),int(x))*h*h for y,x in zip(yy,xx)],dtype=np.int64);assert np.all(outside<=previous);forced=np.maximum(0,50000*10**6-outside);upper=case['first_companion_upper_um2'];required=case['required_first_companion_um2'];allowed=forced<=upper-required;remaining=domain.copy();remaining[yy,xx]=allowed
    with np.load(BASE/(name+'.npz'),allow_pickle=False) as z:
        for key,value in [('source_y',yy),('source_x',xx),('outside_area_upper_um2',outside),('forced_companion_overlap_lower_um2',forced),('remaining_center_cells',remaining)]:assert np.array_equal(z[key],value),(name,key)
    row={'case':name,'omitted_sites':case['omitted_sites'],'input_center_cells':len(xx),'pruned_center_cells':int((~allowed).sum()),'remaining_center_cells':int(allowed.sum()),'first_companion_upper_um2':upper,'required_first_companion_um2':required,'maximum_outside_cog_area_upper_um2':int(outside.max()),'minimum_forced_companion_overlap_um2':int(forced.min()),'minimum_area_deficit_um2':int((required-upper+forced).min()),'provisional_exact_first32_excluded':not bool(allowed.any())};assert row==saved[name];results.append({**row,'exact_first32_excluded':not bool(allowed.any())})
process=load(ROOT/'output/h5-free-cog-round-complement-process-20261108/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds'];remaining=[r for r in results if not r['exact_first32_excluded']];write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',remaining);write(OUT/'controls.json',{'every_kernel_cell_directly_reconstructed':True,'closed_cell_minimum_distance_outer_cover':True,'zero_boundary_no_wrap':True,'axis_inclusion_and_diagonal_exclusion':True,'all_counts_direct_stencil_not_prefix':True,'circular_cover_subset_of_rectangle_cover':True})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'cases_verified':19,'circular_kernel_cells_verified':int(kernel.size),'circular_kernel_cells_retained':int(kernel.sum()),'continuous_center_cells_verified':sum(r['input_center_cells'] for r in results),'direct_complement_stencil_queries':sum(r['input_center_cells'] for r in results),'center_cells_excluded':sum(r['pruned_center_cells'] for r in results),'remaining_center_cells':sum(r['remaining_center_cells'] for r in results),'additional_exact_first32_cases_excluded':19-len(remaining),'exact_first32_cases_remaining':len(remaining),'minimum_full_body_area_deficit_mm2':min(r['minimum_area_deficit_um2'] for r in results)/1e6,'all_exact_rigid_source_angles_covered':True,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
