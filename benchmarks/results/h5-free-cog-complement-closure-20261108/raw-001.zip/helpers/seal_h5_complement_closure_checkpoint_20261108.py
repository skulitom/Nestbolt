"""Preserve complete 680-core closure and the reconciled older eight-core scope."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
process_names=['free-cog-quarter-disk','free-cog-quarter-disk-audit','free-cog-complement','free-cog-complement-audit','free-cog-round-complement','free-cog-round-complement-audit','eight-core-scope']
process_paths=[ROOT/'output'/('h5-'+n+'-process-20261108') for n in process_names]
s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-free-cog-complement-closure-20261108'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-free-cog-round-complement-20261108';F=BASE/'audit';D=ROOT/'output/h5-eight-core-scope-20261108'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-free-angle-cog-capacity-20261108'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['cases_verified']==19 and front['exact_first32_cases_remaining']==0 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-free-cog-quarter-disk-20261108',ROOT/'output/h5-free-cog-complement-20261108',ROOT/'output/h5-free-angle-main-sync-20261108']+process_paths",
"['*h5*mixed*mode*20261107.py']":"['*h5_free_cog*2026110[78].py','*h5_eight_core*20261108.py','*h5_complement_closure*20261108.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_complement_closure_checkpoint_20261108.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
scope=load(D/'checks.json');assert scope['passed'] and scope['remaining_first_cog_scopes']==8;total=scope['inherited_preparation_seconds']+load(process_paths[-1]/'process.json')['complete_seconds'];copies=[(D/'plan.json','older-eight-scope-plan.json'),(D/'checks.json','older-eight-scope-audit.json'),(D/'remaining-core-scopes.json','older-eight-core-scopes.json'),(D/'history-warning.json','historical-three-column-scope.json'),(ROOT/'output/h5-free-angle-main-sync-20261108/receipt.json','prior-main-push-receipt.json')]
stage_folders={'finer-disk':ROOT/'output/h5-free-cog-quarter-disk-20261108','rectangle-complement':ROOT/'output/h5-free-cog-complement-20261108','circular-complement':BASE}
for label,folder in stage_folders.items():
    assert load(folder/'audit/checks.json')['passed'];copies.extend([(folder/'plan.json',label+'-plan.json'),(folder/'audit/checks.json',label+'-audit.json'),(folder/'audit/case-results.json',label+'-cases.json')])
copies.extend([(stage_folders['rectangle-complement']/'source-outer-bound.json','source-outer-bound.json'),(BASE/'kernel-stripes.json','circular-kernel.json'),(F/'controls.json','circular-controls.json'),(F/'remaining-cases.json','remaining-current-core-cases.json')]);process_table=[]
for name,folder in zip(process_names,process_paths):
    r=load(folder/'process.json');assert r['passed'] and r['closed'] and r['job']['active_processes']==0;copies.append((folder/'process.json',name+'-process.json'));process_table.append({'stage':name,'seconds':r['complete_seconds'],'closed':True,'active_processes':0})
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'process-summary.json',process_table)
frontier={r['case']:r for r in load(PARENT/'fixed-core-frontier.json')};assert len(frontier)==680 and sum(r['exact_first32_excluded'] for r in frontier.values())==661
for label,folder in stage_folders.items():
    rows=load(folder/'audit/case-results.json');assert {r['case'] for r in rows}=={k for k,v in frontier.items() if not v['exact_first32_excluded']}
    for r in rows:
        v=frontier[r['case']];assert v['omitted_sites']==r['omitted_sites'];v['remaining_continuous_center_cells']=r['remaining_center_cells']
        if r['exact_first32_excluded']:v['exact_first32_excluded']=True;v['first_excluding_stage']=label
assert all(r['exact_first32_excluded'] for r in frontier.values());write(OUT/'fixed-core-frontier.json',list(frontier.values()))
runtime=load(PARENT/'runtime-bindings.json')
for n,h in runtime.items():assert n.startswith('.cache/') and digest(ROOT/n)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42528251097','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='916859b2bd967d63c005275aeb6149be11fb15cd';success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs']);write(OUT/'main-ci-at-review.json',ci)
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'all680_frontier_identities_reconciled':True,'prior_exact_first32_exclusions':661,'additional_exact_first32_exclusions':19,'total_current_exact_first32_exclusions':680,'current_family_first32_cases_remaining':0,'older_one_three_first32_cases_remaining':8,'complete_preparation_seconds_if_consumed':total,'all_inherited_failures_preserved':True})
write(OUT/'next-step.json',{'status':'all680_current_fixed_first32_cores_excluded','proposal':'Investigate the separately reconciled older eight one-/three-turned exact first32 cores. All eight now require the last source cog on the FIRST sheet for every possible source angle, and each retains explicit necessary companion splits. Build complete necessary free-angle center covers from each changed fixed-frame/cog world using its own certified source-inner rectangles. These older pools use framebit16, with15 or16 cog sites; the current17-site/framebit17 masks may not be reused. Preserve every source binding, boundary class and survivor before any coupled occupancy or full-body complement proof. The already explored three-column18frame hard-domain scope is historical, not a new construction, and closed calls may not resume. This numeric lineage exceeds60seconds; no optimizer or timer reset is permitted. Any eventual bounded constructor needs genuinely independent source computation and a separate preflight.','older_remaining_first32_cases':8,'changed_frame_worlds':2,'older_source_frame_bit':16,'new_center_covers_prepared':False,'complete_model_prepared':False,'optimizer_allowed_from_current_charged_lineage':False,'consumed_preparation_seconds':total,'earlier_arrangements_remaining':4,'whole_allocation_candidates_remaining':440,'optimizer_calls':0,'H5_complete':False})
table='\n'.join('| '+r['stage']+' | '+f"{r['seconds']:.6f}"+' | Pass |' for r in process_table)
report=f'''# Full cog-body complement proof closes all 680 fixed cores — 2026-11-08

**The final nineteen cases are excluded by an independently checked source-body
area proof. All 680 exact first32 cores in this family are now excluded**, even
with the last cog and every bracket/insert free to move. The smallest deficit
in the final nineteen is **825.361864 mm²**. This is conditional on the eighteen
fixed frames and fourteen fixed cog poses; it does not exclude a whole allocation
or orientation class. H2/H5 remain open at **60% completed milestone weight**.
The preserved valid 64-part result remains best.

[Finer disk-domain witnesses]({NAME}/finer-disk-audit.json) independently verify
all 25,407 surviving 2.5 mm center cells, including the original fixed-source
disk certificates. They exclude another 1,296 cells but leave all nineteen
cases with 24,111 cells. No old stage is rerun.

[The stronger source-body proof]({NAME}/rectangle-complement-plan.json) uses the
entire cog's conservative **50,000 mm²** filled-area lower bound. [All eighty
original vertices]({NAME}/source-outer-bound.json) are inside a **140.001 mm**
circle about the source center; its convexity bounds the entire cog at every
exact rigid angle. No native floating-point all-angle guarantee is claimed.

Let `U` be the certified union of all possible bracket/insert component envelopes
and `F` the mandatory fixed source inner union. All companion bodies must lie in
`R = U minus F`, whose area was independently bounded earlier. A valid cog
cannot occupy `F`, so its area outside `R` is bounded by the area of its outer
neighborhood in stock outside `U union F`. Subtract that outside-area upper bound
from 50,000 mm² to obtain compulsory cog occupancy inside the companion region.
That occupied area is unavailable to brackets and inserts.

The first version uses each continuous center cell expanded to an outer rectangle.
A conservative 2.5 mm grid covers its possible outside area: only cells wholly
inside a certified `U` or `F` rectangle are removed. [Independent direct counting]({NAME}/rectangle-complement-audit.json)
replays all **24,111** rectangle queries, separately from producer prefix sums.
It leaves **2,997** center cells across the same nineteen cases.

[The circular refinement]({NAME}/circular-complement-plan.json) uses the actual
source outer-radius bound. A target grid square is included whenever its minimum
distance from the entire center square is at most 140.001 mm. This covers every
point of every possible cog throughout the continuous center cell; grid centers
are not sampled as substitute placements.

[Independent circular-stencil readback]({NAME}/circular-complement-audit.json)
checks **13,689 kernel cells**, retaining **10,301**, and directly counts all
**2,997** remaining complement queries. It uses no producer prefix queries.
[Boundary, diagonal and zero-padding controls]({NAME}/circular-controls.json)
pass, and every circular bound is no larger than its earlier rectangle bound.

[Every remaining center cell fails]({NAME}/circular-complement-cases.json): the
compulsory cog occupancy leaves too little of the certified companion region
for every necessary whole-part inventory. [The current frontier is empty]({NAME}/remaining-current-core-cases.json).
[All 680 source identities and their first excluding stages reconcile]({NAME}/fixed-core-frontier.json),
preserving the prior 661 exclusions and adding nineteen.

[A separate scope reconciliation]({NAME}/older-eight-scope-plan.json) identifies
the **eight earlier one-/three-turned first32 cores** that remain unexcluded.
It binds their actual source44 controls, exact fixed identities/poses, changed
world obstacles, family capacities and all necessary whole-part splits. The
source-invariant cog-area proof now excludes every short-sheet cog pose for all
eight, with a minimum **320.484383 mm²** deficit; any completion requires the
last cog on the first sheet. [All eight remain unresolved there]({NAME}/older-eight-core-scopes.json).
These are separate from the closed 680-case family.

The older worlds use **frame bit16**, with fifteen or sixteen cog sites; the
current seventeen-site/frame-bit17 masks cannot be reused. Historical review also
confirms that the [three-column eighteen-frame hard-domain scope already exists]({NAME}/historical-three-column-scope.json).
It must not be presented as a new construction or used to reopen a closed call.

| Bounded stage | Complete process (s) | Outcome |
|---|---:|---|
{table}

[Every bounded process closes]({NAME}/process-summary.json) with zero live
children under unchanged CCD1/thread and 2 GiB controls. Consumed preparation is
**{total:.6f} s**, including all inherited failed work. This is geometry research
on an exhausted numeric lineage, not a timed H5 pass. No optimizer is opened and
the timer may not reset.

[Next]({NAME}/next-step.json), derive complete source-dependent free-angle cog
center covers for the older eight cores, preserving their different world
geometry and bit identities. They retain necessary inventories, not layouts.
Four earlier arrangements and 440 whole-job allocations remain. Full66
source/native/material acceptance, product integration, parity and the H5 matrix
remain open.

[The preceding checkpoint reached main916859b2]({NAME}/prior-main-push-receipt.json);
[CI at review]({NAME}/main-ci-at-review.json) has **{success} passed / {live} live
jobs**. This checkpoint awaits the ordinary push gate. Product, README and
release state are unchanged.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-08 H5 complete cog-family exclusion:** [independent full-body complement proofs]({{link}}) close the final nineteen exact first32 cores, so all 680 in the current family are excluded with every remaining original free. Finer disk witnesses reduce 25,407 center cells to 24,111. Exact source radius140.001 mm and filled-area lower50,000 mm² give a complement-area conservation bound; independent rectangle queries leave 2,997 cells, and complete circular stencils exclude all of them, with minimum deficit825.361864 mm². All source angles and continuous cell positions are covered, without a native or timed-gate pass. A separate reconciliation preserves eight older one-/three-turned cores and every necessary split; their last cog must be first for every source pose, and changed framebit16 worlds require fresh covers. The historical three-column18frame scope must not be reopened as new. Consumed preparation is {total:.6f} s; no optimizer or timer reset is permitted. Four earlier arrangements and440 whole allocations remain; valid64 stays best, H2/H5 stay open at60%. Main916859b2 has{success} passed/{live} live CI jobs; this checkpoint awaits the ordinary push gate. Product and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';content=p.read_text(encoding='utf-8');a=content.index('Latest H5 evidence:');b=content.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [complete cog-family exclusion](../benchmarks/results/{NAME}.md).
Full source-body conservation and independently counted circular complement
bounds exclude the last nineteen cases, closing all 680 exact first32 cores
in this family with every remaining original free. The smallest final deficit
is 825.361864 mm². No whole allocation or orientation class is excluded.
Eight separate older one-/three-turned cores remain; every necessary inventory
is preserved and their last source cog must be first. Their changed source worlds
need new free-angle center covers with framebit16, not current framebit17 masks.
The historical three-column eighteen-frame scope is already explored.
Consumed preparation is {total:.6f} s. This lineage may not reset its timer or
open an optimizer. Four earlier arrangements and 440 whole-job allocations remain;
valid64 stays best, H2/H5 stay open at 60%. Main916859b2 has {success} passed /
{live} live CI jobs; this checkpoint awaits the ordinary push gate.
Product and releases are unchanged.
'''
p.write_text(content[:a]+intro+content[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings),'total_consumed_preparation_seconds':total,'current_fixed_cores_remaining':0,'older_fixed_cores_remaining':8,'main_ci_passed':success,'main_ci_live':live})
