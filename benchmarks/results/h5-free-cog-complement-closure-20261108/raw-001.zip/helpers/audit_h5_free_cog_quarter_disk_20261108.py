"""Independent exact source and corner witnesses for the 2.5 mm domains."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];TEMPLATE=ROOT/'output/audit_h5_free_cog_disk_domain_20261108.py';src=TEMPLATE.read_text(encoding='utf-8')
changes={
"BASE=ROOT/'output/h5-free-cog-disk-domain-20261108'":"BASE=ROOT/'output/h5-free-cog-quarter-disk-20261108'",
"FINE=ROOT/'output/h5-free-cog-fine-grid-20261108'":"FINE=ROOT/'output/h5-free-cog-quarter-grid-20261108'",
"for p in [Path(__file__),BASE/":"for p in [Path(__file__),TEMPLATE,BASE/",
"assert len(cases)==len(saved)==35":"assert len(cases)==len(saved)==19",
"x0=xs*5000;y0=ys*5000;x1=x0+5000;y1=y0+5000":"x0=xs*2500;y0=ys*2500;x1=x0+2500;y1=y0+2500",
"output/h5-free-cog-disk-domain-process-20261108/process.json":"output/h5-free-cog-quarter-disk-process-20261108/process.json",
"'cases_verified':35":"'cases_verified':19",
"'additional_exact_first32_cases_excluded':35-len(survivors)":"'additional_exact_first32_cases_excluded':19-len(survivors)",
}
for a,b in changes.items():assert a in src,a;src=src.replace(a,b)
exec(compile(src,str(Path(__file__)),'exec'))
