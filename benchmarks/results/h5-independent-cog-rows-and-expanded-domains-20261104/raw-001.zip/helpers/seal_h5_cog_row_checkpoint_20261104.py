"""Seal the audited movable-packet construction and its sole closed call."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-independent-cog-rows-and-expanded-domains-20261104';OUT=ROOT/'benchmarks/results'/NAME
REG=ROOT/'output/h5-independent-cog-row-regions-v2-20261104';BASE=ROOT/'output/h5-independent-cog-row-integer-20261104';EXP=ROOT/'output/h5-individual-cog-row-domains-20261104';RED=ROOT/'output/h5-independent-cog-row-reduced-cover-20261104'
PARENTS=[ROOT/'benchmarks/results'/n for n in ['h5-continuous-small-block-exclusions-20261104','h5-continuous-inserts-and-bracket-capacities-20261104','h5-direct-counts-and-relative-hull-capacities-20261104','h5-corner-channel-construction-20261104','h5-relative-projections-and-movable-packet-20261104','h5-translated-cog-packet-construction-20261104']]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
assert load(REG/'source-region-audit/checks.json')['passed']
for folder in ['geometry-audit','model-audit','response-audit']:assert load(BASE/folder/'checks.json')['passed']
response=load(BASE/'response-audit/checks.json');assert response['solver_status']=='UNKNOWN' and response['closed_solver_calls']==1 and response['assignments']==0 and response['algorithm_overrun_seconds']==response['shared_overrun_seconds']==0 and 0<response['solve_slice_overrun_seconds']<.16
parent_by_hash={}
for parent in PARENTS:
    assert load(parent/'archive-checks.json')['passed'];manifest=load(parent/'raw-manifest.json');h=digest(parent/'raw-manifest.json')
    for row in manifest['files']:parent_by_hash.setdefault((row['sha256'],row['bytes']),(parent,h,row))
OUT.mkdir();members={};external={};queue=[];seen=set();bindings={}
def traversable(p):return p.name in ['plan.json','opened.json'] or p.name.endswith('process.json')
def add(name,p):
    assert p.is_file() and p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts)
    h=digest(p);size=p.stat().st_size;prior=parent_by_hash.get((h,size))
    if prior:
        parent,mh,row=prior;external[name]={'manifest':(parent/'raw-manifest.json').relative_to(ROOT).as_posix(),'manifest_sha256':mh,'archive':row['archive'],'member':row['path'],'bytes':size,'sha256':h}
    else:members[name]=p
    if traversable(p) or p.suffix=='.py':queue.append(p)
assert load(EXP/'audit/checks.json')['passed'] and load(RED/'source-region-audit/checks.json')['passed']
folders=[ROOT/'output'/n for n in [
 'h5-independent-cog-row-regions-20261104','h5-independent-cog-rows-process-20261104',
 'h5-independent-cog-row-regions-v2-20261104','h5-independent-cog-rows-v2-process-20261104',
 'h5-independent-cog-row-integer-20261104','h5-independent-cog-row-integer-process-20261104',
 'h5-cog-row-control-process-20261104','h5-independent-cog-row-overlap-regions-20261104',
 'h5-cog-row-overlap-regions-process-20261104','h5-independent-cog-row-reduced-cover-20261104',
 'h5-cog-row-reduced-cover-process-20261104','h5-individual-cog-row-domains-20261104',
 'h5-individual-cog-row-domains-process-20261104']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for p in (ROOT/'output').glob('*h5*cog_row*20261104.py'):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]:add('helpers/'+name,ROOT/'output'/name)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if traversable(p):
        data=load(p)
        for name,h in data.get('inputs',{}).items():
            z=ROOT/name;assert digest(z)==h,name;bindings[name]=h;add('source-inputs/'+name,z)
        if 'script' in data and 'script_sha256' in data:
            z=ROOT/data['script'];assert digest(z)==data['script_sha256'];bindings[data['script']]=data['script_sha256'];add('source-inputs/'+data['script'],z)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    z=ROOT/folder/(module+'.py')
                    if z.is_file():add('imported-helpers/'+folder+'/'+z.name,z)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'external-evidence.json',external);write(OUT/'source-bindings.json',bindings)
copies=[(REG/'checks.json','row-regions.json'),(REG/'source-region-audit/checks.json','row-source-audit.json'),
 (BASE/'geometry-audit/checks.json','integer-audit.json'),(BASE/'row-control/audit/checks.json','positive-row-control-audit.json'),
 (BASE/'model/checks.json','model.json'),(BASE/'model/build-process.json','model-build-process.json'),
 (BASE/'model/final-preparation-charges.json','preparation-charges.json'),(BASE/'model/budget.json','budget.json'),
 (BASE/'model-audit/checks.json','model-audit.json'),(BASE/'response-audit/checks.json','response-audit.json'),
 (RED/'checks.json','reduced-cover.json'),(RED/'source-region-audit/checks.json','reduced-cover-source-audit.json'),
 (EXP/'rows.json','expanded-row-domains.json'),(EXP/'audit/checks.json','expanded-domain-audit.json'),
 (ROOT/'output/h5-independent-cog-rows-process-20261104/process.json','failed-stagger-process.json'),
 (ROOT/'output/h5-individual-cog-row-domains-process-20261104/process.json','expanded-domain-process.json')]
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'next-step.json',{'closed_call_must_not_be_repeated':True,'closed_model_sha256':load(BASE/'model-audit/checks.json')['model_sha256'],
 'closed_call_status':'UNKNOWN','next_construction':'Use independently audited individual-row stock/core boxes rather than the common packet box. Generate fresh source-certified mover-minus-row and shiftB-minus-shiftA regions over the expanded domains. Recompute integer coefficient error envelopes and world-stock bounds; the previous1600x1000mm and100x120mm envelopes cannot simply transfer. Establish source-valid joint row controls, audit any complete new model, and charge every preparation used within the original60/90-second limits before a genuinely new single solver call.',
 'expanded_source_domains':'output/h5-individual-cog-row-domains-20261104',
 'expanded_interaction_regions_prepared':False,'joint_inter_row_safety_proven':False,
 'reduced_overlapping_cover_disposition':'Safe after independent source audit, but1504regions exceed the original1377; no second solver call warranted or made.',
 'fixed_cog_frontier':{'site_choices':2,'count_distributions':3},'remaining_allocation_candidates':440,
 'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
 'variables':9924,'constraints':35142,'row_translation_variables':6,'closed_solver_calls':1,'solver_status':'UNKNOWN',
 'assignments':0,'solve_slice_overrun_seconds':response['solve_slice_overrun_seconds'],
 'algorithm_seconds_including_preparation':response['algorithm_seconds_including_preparation'],
 'shared_seconds_including_preparation':response['shared_seconds_including_preparation'],
 'expanded_individual_row_domains_verified':3,'expanded_row_corner_controls_verified':12,
 'continuous_source_domain_excluded':False,'remaining_allocation_candidates':440,'source_valid66':False,
 'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f"""# Independent cog rows and expanded domains — 2026-11-04

Three independently moving cog rows now have audited interaction regions and a
complete model. Its sole bounded call closes **UNKNOWN with no placement**.
A separate source audit establishes substantially wider, individual stock-safe
row domains for the next construction. No complete66 layout or new exclusion
is claimed; all440 allocations remain and H2/H5 stay open at **60%**.

## Preserved failure and positive control

The first proposed1mm stagger fails four original cog gaps: the minimum becomes
0.201356506mm against0.211708673mm required. Its source files, failed checks and
[0.481104s process]({NAME}/failed-stagger-process.json) remain intact and charged.
Vertical movement does not monotonically improve interlocking tooth clearance.

Fresh regions use three rigid rows of5,4,4 original cogs, with independent X/Y
shifts initially restricted to the whole packet's safe rectangle. The four
previous common-shift controls remain source-valid, but are not claimed to
satisfy the more conservative new row interaction regions.
[Independent source checks]({NAME}/row-source-audit.json) certify1329mover/row
regions and48row/row regions with32978 and10144 exact support proofs.
Two degenerate row regions are explicitly disabled. All12original modes and
all13cogs are covered; minimum certified separation is0.225999999264mm.
[Integer readback]({NAME}/integer-audit.json) verifies5083halfplane implications,
relative error envelopes, world bounds and all20rigid component rectangles.

A deterministic preparation enumerates188rounded centroid neighbours and7728
adjacent-row difference combinations, retaining4992admissible controls.
[Independent readback]({NAME}/positive-row-control-audit.json) verifies the complete
selection and its53original shapes:916pairs,212stock edges,63holes and6732hole
vertices. Selected shifts in0.01mm units are[-9156,34],[-4071,1],[-8542,29].
This remains a partial control missing13orthogonal originals.

## One closed construction call

[Every model field is audited]({NAME}/model-audit.json):9924variables,
35142constraints,26orthogonal world-position variables,6row shifts,80source-mode
selectors,8952mover/row region selectors and48row/row selectors. It includes
20rigid rectangles,544coordinate links,183different-owner pairs and11valid
identical-copy symmetry rows. The54-value partial hint specifies only row
shifts and row-region choices; it is not a full placement.

[Complete charged preparation]({NAME}/preparation-charges.json) is30.882969s,
including the failed stagger and complete model process.
[Response readback]({NAME}/response-audit.json) verifies one closed UNKNOWN call:
23.984251s allocated,24.142690s returned,56542branches and3793conflicts.
The **0.158439s solve-slice overrun is preserved**. Preparation-inclusive
algorithm/shared totals56.173849/56.302587s remain within60/90s. No incumbent,
assignment, source66 check or native call exists. Do not repeat, reseed or extend
this call. UNKNOWN excludes no continuous domain or allocation.

## Representation check and wider source domains

An overlapping exterior-halfplane/pocket representation yields1831regions.
Deterministic hull unions reduce this to1504after327merges.
[All retained regions pass fresh source certification]({NAME}/reduced-cover-source-audit.json):
1465mover/row and39row/row regions,33976 and9020 exact support proofs, with
minimum separation0.225999998882mm. Floating overlap filters were only candidate
filters; the exact source proofs establish safety. The reduced cover is still
larger than the original1377regions, so it triggers **no additional solver call**.
Both raw and reduced representations, processes and diagnostics are preserved.

The more useful next change removes the inherited whole-packet movement bound.
[Exact individual row bounds]({NAME}/expanded-row-domains.json) are:

| Row (cogs) | X shift, mm | Y shift, mm |
|---|---|---|
|0 (5)|-91.56 to79.99|0.01 to605.65|
|1 (4)|-430.42 to-0.01|-246.19 to359.46|
|2 (4)|-350.42 to79.99|-492.38 to113.27|

All contain the earlier shared X[-91.56,-0.01]/Y[0.01,113.27] rectangle.
[Independent exact affine readback]({NAME}/expanded-domain-audit.json) proves
stock containment and fixed-core separation across each entire individual box,
including nearest excluded grid points and the1e-6mm inward reserve. It verifies
all36mover-minus-row mode domains and3row-difference domains. Twelve corner
controls each contain one row, fixed29 and short11; other moving rows are
intentionally absent. Together with the preserved source53 control, the reader
checks8044pairs,2340stock edges,715holes and66716hole vertices. The complete new
preflight costs0.799117s. Minimum fixed-core clearance across the boxes is
0.225489808mm, above the required source gap.

**The Cartesian product of these boxes is not proven collision-free.** Fresh
inter-row and mover-row regions, larger integer error envelopes, a joint control
and a complete charged/audited model remain necessary before another new call.
[The next-step record]({NAME}/next-step.json) preserves those requirements.

The fixed-cog frontier remains2choices/3distributions. Full66 source/native/material
checks, production integration and the H5 matrix remain open. H2 retains its
original gate and22unopened reserved vectors. No production or README change,
new release or registry publication is warranted. All six jobs and the aggregate
run for main a3fcf47f now pass in
[CI41894305822](https://github.com/skulitom/Nestbolt/actions/runs/41894305822).

[The manifest]({NAME}/raw-manifest.json) contains{archive['archive_members']}new
canonical members and{archive['archive_bytes']:,}compressed bytes.
[External references]({NAME}/external-evidence.json) and
[input bindings]({NAME}/source-bindings.json) retain the historical evidence.
Every archive member, reused parent member, binding and local report link is
independently checked before commit.
"""
import re
# Keep generated prose readable without changing identifiers or numeric precision.
report=re.sub(r'(?<=[A-Za-z])(?=[0-9])|(?<=[0-9])(?=[A-Za-z])',' ',report)
# The generic spacing rule must not touch paths, URLs, identifiers or milestone names.
report=report.replace('H 2','H2').replace('H 5','H5').replace('source 53','source53').replace('source 66','source66').replace('full 66','full66').replace('fixed 29','fixed29').replace('short 11','short11').replace('a 3 fcf 47 f','a3fcf47f').replace('CI 41894305822','CI41894305822').replace('1 e-6','1e-6')
report=report.replace('h 5-independent-cog-rows-and-expanded-domains-20261104','h5-independent-cog-rows-and-expanded-domains-20261104')
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 independent cog rows:** [the independent construction and domain audits]({link}) verify a 9,924-variable / 35,142-constraint model with three independently translated rows. Its sole call closes UNKNOWN with no assignment; the 0.158439 s solve-slice overrun is preserved, while algorithm/shared totals 56.173849 / 56.302587 s stay within 60/90 s. A fresh overlapping cover is source-safe but larger and receives no solver call. Exact per-row stock/core bounds now allow substantially more movement, with 12 independently verified corner controls and all 36 relative mode domains; fresh interaction regions and a complete model are still required. All 440 allocations, full66 validation and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
old='Latest H5 evidence: [translated cog-packet construction](../benchmarks/results/h5-translated-cog-packet-construction-20261104.md).';assert s.count(old)==1
s=s.replace(old,f'Latest H5 evidence: [independent cog rows and expanded domains](../benchmarks/results/{NAME}.md).',1)
old='The shared-translation packet construction is audited and its sole grid call\nis closed without a placement. Independently moving cog rows are the next\nconstruction hypothesis; their interaction proofs and model remain unbuilt.';assert s.count(old)==1
s=s.replace(old,'The independent-row construction is audited and its sole call closes UNKNOWN\nwithout a placement. Fresh individual row bounds allow substantially more motion\ninside the stock; their enlarged interaction regions and model remain to build.',1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
