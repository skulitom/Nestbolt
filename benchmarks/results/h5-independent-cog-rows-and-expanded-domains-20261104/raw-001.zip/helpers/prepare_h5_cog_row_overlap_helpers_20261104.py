"""Prepare overlapping convex exterior covers instead of full-space triangulation."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/prepare_h5_independent_cog_rows_v2_20261104.py').read_text(encoding='utf-8').replace('h5-independent-cog-row-regions-v2-20261104','h5-independent-cog-row-overlap-regions-20261104')
s=s.replace('import merge_exact','import hull,merge_exact,area')
start=s.index('def partition(domain,obstacles):');end=s.index("assert load(PACKET/'audit/checks.json')",start)
s=s[:start]+'''def clip_exterior(domain,a,b):
    a,b=tuple(map(F,a)),tuple(map(F,b))
    def cross(p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
    x0,y0,x1,y1=map(F,domain);polygon=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)];result=[]
    for p,q in zip(polygon,polygon[1:]+polygon[:1]):
        cp,cq=cross(p),cross(q)
        if cp<=0:result.append(p)
        if (cp<0<cq) or (cq<0<cp):
            t=cp/(cp-cq);result.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    result=hull(result)
    return [[float(x),float(y)] for x,y in result] if len(result)>=3 and area(result)>0 else None
def partition(domain,obstacles):
    obstacle=unary_union(obstacles);envelope=obstacle.convex_hull;outer=hull([tuple(map(F,p)) for p in envelope.exterior.coords[:-1]])
    regions=[];kinds=[]
    for a,b in zip(outer,outer[1:]+outer[:1]):
        region=clip_exterior(domain,a,b)
        if region is not None:regions.append(region);kinds.append('convex_exterior_halfplane')
    pockets=polygonal(envelope.difference(obstacle).intersection(box(*map(float,domain))))
    triangles=[p for p in shapely.constrained_delaunay_triangles(pockets).geoms if p.area>0]
    assert all(p.geom_type=='Polygon' and len(p.exterior.coords)==4 for p in triangles)
    merged,merges=merge_exact(triangles) if triangles else ([],0)
    regions.extend(merged);kinds.extend(['concave_pocket']*len(merged))
    free=polygonal(box(*map(float,domain)).difference(obstacle));combined=unary_union([Polygon(p) for p in regions]);error=combined.symmetric_difference(free).area
    snapped=shapely.union_all([Polygon(p) for p in regions],grid_size=1e-8);snapped_free=shapely.difference(box(*map(float,domain)),obstacle,grid_size=1e-8);snap_error=shapely.symmetric_difference(snapped,snapped_free,grid_size=1e-8).area
    assert obstacle.is_valid and free.is_valid and regions and snap_error<1e-4,(error,snap_error)
    return {'domain_mm':[str(v) for v in domain],'free_area_mm2':free.area,'initial_triangles':len(triangles),'exact_merges':merges,'regions':[{'region':i,'vertices':v,'kind':kinds[i]} for i,v in enumerate(regions)],'floating_partition_coverage_error_mm2':error,'snapped_coverage_diagnostic_error_mm2':snap_error,'convex_exterior_cover_regions':kinds.count('convex_exterior_halfplane'),'concave_pocket_regions':kinds.count('concave_pocket'),'regions_may_overlap':True}
''' +s[end:]
s=s.replace('New construction with three independently translated rigid source-cog rows of5,4,4 copies.', 'New representation of the three independently translated rigid source-cog rows of5,4,4 copies: cover the exterior of each complete obstacle convex hull with overlapping exact-clipped halfplanes, and triangulate/merge only its concave pockets. This is a different representation, not a restart of the closed triangulated-row model. Preserve raw and snapped overlay diagnostics separately; neither is a global coverage or source safety proof. Independently certify every retained rounded region before any new model. Keep all original sources, modes, row domains and clearances.')
s=s.replace("inputs=[ROOT/'output/", "inputs=[Path(__file__).parent/'prepare_h5_cog_row_overlap_helpers_20261104.py',ROOT/'output/",1)
s=s.replace("'old_fixed_cog_exclusions_reused':False", "'old_fixed_cog_exclusions_reused':False,'overlapping_convex_exterior_cover':True,'full_free_space_triangulation_replaced':True")
p=ROOT/'output/prepare_h5_cog_row_overlap_regions_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_independent_cog_rows_v2_preparation_20261104.py').read_text(encoding='utf-8').replace('h5-independent-cog-rows-v2-process-20261104','h5-cog-row-overlap-regions-process-20261104').replace('prepare_h5_independent_cog_rows_v2_20261104.py','prepare_h5_cog_row_overlap_regions_20261104.py')
p=ROOT/'output/run_h5_cog_row_overlap_regions_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_independent_cog_row_regions_20261104.py').read_text(encoding='utf-8').replace('h5-independent-cog-row-regions-v2-20261104','h5-independent-cog-row-overlap-regions-20261104')
p=ROOT/'output/audit_h5_cog_row_overlap_regions_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
