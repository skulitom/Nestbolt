"""Preserve the failed row stagger and use verified common-shift source controls."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/prepare_h5_independent_cog_rows_20261104.py').read_text(encoding='utf-8').replace('h5-independent-cog-row-regions-20261104','h5-independent-cog-row-regions-v2-20261104')
s=s.replace("inputs=[Path(__file__),", "inputs=[ROOT/'output/h5-independent-cog-row-regions-20261104/plan.json',ROOT/'output/h5-independent-cog-row-regions-20261104/control-0-source53.json',ROOT/'output/h5-independent-cog-row-regions-20261104/control-0-source-checks.json',ROOT/'output/h5-independent-cog-rows-process-20261104/opened.json',ROOT/'output/h5-independent-cog-rows-process-20261104/process.json',Path(__file__),",1)
s=s.replace('Four declared original-source controls use a common X shift and a fixed1mm additional Y shift per row, with base Y restricted to keep every row inside its domain.', 'The original1mm staggered control failed four original cog clearances at0.201356506mm; its files and complete0.481104s process are preserved. Use the already source-verified common X/Y shifts as the four original-source controls. These controls establish source safety and identities only, not membership in the more conservative future row-pair construction regions. Derive admissible independent row movements from fresh certified collision regions rather than assuming monotonic clearance under vertical displacement.')
s=s.replace("'control_row_y_increment_mm':1", "'control_row_y_increment_mm':0,'failed_staggered_preparation_preserved':True,'source_controls_are_not_yet_model_controls':True")
s=s.replace("base_y=[shift[1][0],shift[1][1]-2*grid]", "base_y=[shift[1][0],shift[1][1]]").replace("delta=[sx,sy+group['row']*grid]", "delta=[sx,sy]")
p=ROOT/'output/prepare_h5_independent_cog_rows_v2_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_independent_cog_rows_preparation_20261104.py').read_text(encoding='utf-8').replace('h5-independent-cog-rows-process-20261104','h5-independent-cog-rows-v2-process-20261104').replace('prepare_h5_independent_cog_rows_20261104.py','prepare_h5_independent_cog_rows_v2_20261104.py')
p=ROOT/'output/run_h5_independent_cog_rows_v2_preparation_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
