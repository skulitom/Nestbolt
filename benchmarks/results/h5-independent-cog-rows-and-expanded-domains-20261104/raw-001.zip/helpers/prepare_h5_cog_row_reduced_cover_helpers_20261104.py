from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/run_h5_cog_row_overlap_regions_20261104.py').read_text(encoding='utf-8')
source=source.replace('h5-cog-row-overlap-regions-process-20261104','h5-cog-row-reduced-cover-process-20261104').replace('prepare_h5_cog_row_overlap_regions_20261104.py','prepare_h5_cog_row_reduced_cover_20261104.py')
with (ROOT/'output/run_h5_cog_row_reduced_cover_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
source=(ROOT/'output/audit_h5_independent_cog_row_regions_20261104.py').read_text(encoding='utf-8').replace('h5-independent-cog-row-regions-v2-20261104','h5-independent-cog-row-reduced-cover-20261104')
with (ROOT/'output/audit_h5_cog_row_reduced_cover_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
