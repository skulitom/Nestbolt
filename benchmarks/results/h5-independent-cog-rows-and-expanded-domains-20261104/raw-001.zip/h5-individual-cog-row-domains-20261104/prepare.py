"""Give each rigid source row its own complete stock/core-safe translation box."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json, math, shutil, time
from h5_legacy64_source_readback import audit

ROOT=Path(__file__).resolve().parents[1]
PRE=ROOT/'output/h5-translated-cog-packet-preflight-20261104'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
OUT=ROOT/'output/h5-individual-cog-row-domains-20261104'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

assert load(PRE/'audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT]
inputs += [FIRST/n for n in ['plan.json','fixed29.json','family-modes.json','audit/plan.json','audit/checks.json']]
inputs += [PRE/n for n in ['plan.json','packet-source13.json','translation-domain.json','inventory.json','audit/plan.json','audit/checks.json','corner-0-source53.json','corner-0-source-checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New construction domain: each rigid row of5,4,4 cogs receives its own exact source bounding-box translation rectangle inside stock and above fixed29. The former common packet rectangle unnecessarily limited every independent row by the entire packet extrema. Derive each row range with0.01mm inward rounding and1e-6mm reserve. Independently check four corners for each row together with fixed29 and short11, excluding the other two moving rows. These12 partial controls prove stock/core and internal-row safety only; new row-to-row and mover-to-row regions are mandatory. Retain the previously source-valid complete13-cog control separately. Preserve all66 identities, every source mode, gap and material target. No previous grid status or continuous capacity exclusion is transferred.',
    'grid_units_per_mm':100,'inward_rounding_reserve_mm':'0.000001','extra_stock_mm':'0.025',
    'source_geometry_preparation_target_seconds':20,'future_algorithm_seconds':60,'future_shared_seconds':90,
    'future_maximum_calls':1,'retry_permitted':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(FIRST/'plan.json')
cogs=load(PRE/'packet-source13.json');fixed=load(FIRST/'fixed29.json');short=load(SHORT)
inventory=load(PRE/'inventory.json');old_domain=load(PRE/'translation-domain.json');old_shift=old_domain['shift_bounds_grid']
stock=list(map(F,spec['construction_stock']));extra=F('.025');eps=F('.000001');grid=100
safe=[stock[0]+extra,stock[1]+extra,stock[2]-extra,stock[3]-extra]
levels=sorted({r['transform']['translation'][1] for r in cogs});rows=[];controls=[];row_modes=[]
base_modes=load(FIRST/'family-modes.json')
for ri,y in enumerate(levels):
    indices=[i for i,r in enumerate(cogs) if r['transform']['translation'][1]==y];source=[cogs[i] for i in indices];vertices=[]
    for r in source:
        t=r['transform'];c,s=F(math.cos(t['rotation_radians'])),F(math.sin(t['rotation_radians']));sign=-1 if t['mirrored'] else 1;tx,ty=map(F,t['translation'])
        vertices.extend((sign*F(x)*c-F(v)*s+tx,sign*F(x)*s+F(v)*c+ty) for x,v in parts['cog']['geometry'][0]['outer'])
    box=[min(v[k] for v in vertices) for k in [0,1]]+[max(v[k] for v in vertices) for k in [0,1]]
    shift=[[math.ceil((safe[k]-box[k]+eps)*grid),math.floor((safe[k+2]-box[k+2]-eps)*grid)] for k in [0,1]]
    assert all(lo<=old_shift[k][0]<=old_shift[k][1]<=hi for k,(lo,hi) in enumerate(shift))
    rows.append({'row':ri,'source_indices':indices,'source_identities':[[r['part_id'],r['copy_index']] for r in source],
                 'reference_y_mm':y,'source_row_bounds_mm':[str(x) for x in box],
                 'shift_bounds_grid':shift,'shift_bounds_mm':[[str(F(x,grid)) for x in b] for b in shift]})
    for ci,delta in enumerate(product(*shift)):
        moved=deepcopy(source)
        for r in moved:r['transform']['translation']=[v+delta[k]/grid for k,v in enumerate(r['transform']['translation'])]
        result=fixed+moved+short;expected=[(r['part_id'],r['copy_index']) for r in result]
        check=audit(job,result,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
        stem=f'row-{ri}-corner-{ci}'
        write(OUT/f'{stem}-source.json',result);write(OUT/f'{stem}-checks.json',check);assert check['valid']
        controls.append({'row':ri,'corner':ci,'shift_grid':delta,'source':f'{stem}-source.json','source_checks':f'{stem}-checks.json'})
    for family in ['bracket','insert']:
        for m in base_modes[family]:
            relative=[[F(b[0])-F(shift[k][1],grid),F(b[1])-F(shift[k][0],grid)] for k,b in enumerate(m['lower_left_bounds'])]
            row_modes.append({'row':ri,'family':family,**m,'relative_lower_left_bounds_mm':[[str(x) for x in b] for b in relative]})
    assert time.perf_counter()-started<20
pair_domains=[]
for a in range(3):
    for b in range(a+1,3):
        bounds=[[rows[b]['shift_bounds_grid'][k][0]-rows[a]['shift_bounds_grid'][k][1],rows[b]['shift_bounds_grid'][k][1]-rows[a]['shift_bounds_grid'][k][0]] for k in [0,1]]
        pair_domains.append({'rows':[a,b],'relative_coordinate':'shift_B_minus_shift_A','bounds_grid':bounds,'bounds_mm':[[str(F(v,grid)) for v in bb] for bb in bounds]})
for name,value in [('rows.json',rows),('controls.json',controls),('row-modes.json',row_modes),('pair-domains.json',pair_domains),('source-cogs.json',cogs),('inventory.json',inventory)]:write(OUT/name,value)
for old,new in [('corner-0-source53.json','shared-control-source53.json'),('corner-0-source-checks.json','shared-control-checks.json')]:shutil.copyfile(PRE/old,OUT/new)
write(OUT/'domain.json',{'safe_world_bounds_mm':[str(v) for v in safe],'previous_shared_shift_bounds_grid':old_shift,'grid_units_per_mm':grid,'inter_row_safety_not_proven':True,'independent_row_bounds_are_not_a_joint_feasible_domain':True})
result={'passed':True,'seconds_including_source_controls':time.perf_counter()-started,'source_row_sizes':[len(r['source_indices']) for r in rows],
        'individual_row_shift_bounds_grid':[r['shift_bounds_grid'] for r in rows],'partial_row_controls':len(controls),
        'source_pairs_checked':sum(load(OUT/r['source_checks'])['same_sheet_pairs'] for r in controls),
        'shared_source53_controls_retained':1,'row_source_mode_domains':len(row_modes),'row_pair_difference_domains':len(pair_domains),
        'all_old_row_bounds_contained':True,'independent_audit_required':True,'fresh_interaction_regions_required':True,
        'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
