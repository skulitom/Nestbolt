"""Conservative integer regions for three independently translated source rows."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];REG=ROOT/'output/h5-independent-cog-row-regions-v2-20261104';PACKET=ROOT/'output/h5-translated-cog-packet-preflight-20261104';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';OUT=ROOT/'output/h5-independent-cog-row-integer-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(REG/'source-region-audit/checks.json')['passed'] and load(PRIOR/'rigid-rectangle-preflight/audit-v3/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter();grid=100;scale=100000;epsilon=F('1e-7');origin=[F(0),F(2100)];envelope=[F(1600),F(1000)];pair_envelope=[F(100),F(120)]
modes=load(REG/'family-modes.json');converted={}
for family,opts in modes.items():
    converted[family]=[]
    for m in opts:
        extra={}
        for source,dest in [('lower_left_bounds','integer_world_lower_left_bounds'),('relative_lower_left_bounds_mm','integer_relative_lower_left_bounds')]:
            extra[dest]=[[math.ceil((F(lo)-origin[k])*grid),math.floor((F(hi)-origin[k])*grid)] for k,(lo,hi) in enumerate(m[source])]
        converted[family].append({**m,**extra})
raw_rect=load(PRIOR/'rigid-rectangle-preflight/mode-rectangles.json')
rects={family:[{**m,'rectangles':[{**r,'outward_offsets_grid':[math.floor(F(v)*grid) if i<2 else math.ceil(F(v)*grid) for i,v in enumerate(r['exact_affine_bounds_mm'])]} for r in m['rectangles']]} for m in opts] for family,opts in raw_rect.items()}
max_activity=0;max_error=F(0);plane_count=0
def convert_region(source,offset,limits):
    global max_activity,max_error,plane_count
    region={**source,'planes':[]};polygon=[tuple(map(F,p)) for p in source['hull_vertices']]
    for edge,(a,b) in enumerate(zip(polygon,polygon[1:]+polygon[:1])):
        dx,dy=b[0]-a[0],b[1]-a[1];den=max(abs(dx),abs(dy));assert den>0;normal=[dy/den,-dx/den];raw=[round(n*scale) for n in normal]
        error=sum(abs(n-F(c,scale))*limit for n,c,limit in zip(normal,raw,limits));rhs=sum(n*(x-o) for n,x,o in zip(normal,a,offset));divisor=math.gcd(*map(abs,raw));assert divisor>0
        coefficients=[v//divisor for v in raw];upper=math.floor((rhs-error-epsilon)*scale*grid)//divisor
        activity=sum(abs(c)*int(limit*grid) for c,limit in zip(coefficients,limits));assert activity<2**53 and abs(upper)<2**53
        max_activity=max(max_activity,activity);max_error=max(max_error,error);plane_count+=1
        region['planes'].append({'edge':edge,'exact_infinity_normal':[str(n) for n in normal],'normalization_denominator':str(den),'unreduced_coefficients':raw,'divisor':divisor,'coefficients':coefficients,'upper':upper,'rounding_error_bound_mm':str(error)})
    return region
mover=load(REG/'source-region-audit/rounded-mover-regions.json');pairs=load(REG/'source-region-audit/rounded-row-pair-regions.json');templates=[];pair_templates=[]
for row in range(3):
    for gid in range(10):
        source=[r for r in mover if r['row']==row and r['geometry']==gid];assert source
        templates.append({'row':row,'geometry':gid,'regions':[convert_region({k:v for k,v in r.items() if k not in ['row','geometry']},origin,envelope) for r in source]})
for rows in [[0,1],[0,2],[1,2]]:
    source=[r for r in pairs if r['rows']==rows];assert source
    pair_templates.append({'rows':rows,'regions':[convert_region({k:v for k,v in r.items() if k!='rows'},[F(0),F(0)],pair_envelope) for r in source]})
for name,data in [('family-modes.json',converted),('mode-rectangles.json',rects),('mover-row-templates.json',templates),('row-pair-templates.json',pair_templates)]:write(OUT/name,data)
for name in ['rows.json','source-cogs.json','instances.json','inventory.json','controls.json']:shutil.copyfile(REG/name,OUT/name)
for name in ['components.json','component-pairs.json']:shutil.copyfile(PRIOR/'rigid-rectangle-preflight'/name,OUT/name)
inputs=[Path(__file__)]+[REG/n for n in ['plan.json','checks.json','family-modes.json','rows.json','source-cogs.json','instances.json','inventory.json','controls.json','source-region-audit/plan.json','source-region-audit/checks.json','source-region-audit/rounded-mover-regions.json','source-region-audit/rounded-row-pair-regions.json','source-region-audit/disabled-regions.json']]+[PRIOR/'rigid-rectangle-preflight'/n for n in ['plan.json','checks.json','mode-rectangles.json','components.json','component-pairs.json','audit-v3/plan.json','audit-v3/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Convert independently source-certified mover-to-row and row-to-row hulls to0.01mm positions and rationally bounded integer halfplanes. Mover relative coordinates use local origin(0,2100) and absolute error envelope1600x1000mm; row-pair shift differences use origin0 and100x120mm. The future model must apply mover planes to world_position-minus-row_shift, and row-pair planes to shiftB-minus-shiftA. Retain all source modes and the safe per-row shift rectangles. Outward-rounded rigid original rectangles require0.23mm different-owner separation. Disable exactly the source-audited degenerate regions.','grid_units_per_mm':grid,'normal_scale':scale,'world_origin_mm':[0,2100],'mover_relative_error_envelope_mm':[1600,1000],'row_pair_error_envelope_mm':[100,120],'plane_inset_mm':str(epsilon),'rectangle_gap_grid':23,'future_algorithm_seconds':60,'future_shared_seconds':90,'future_maximum_calls':1,'retry_permitted':False,'new_model_created':False,'solver_calls':0})
checks={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-started,'mover_row_regions':len(mover),'row_pair_regions':len(pairs),'integer_planes':plane_count,'maximum_integer_relative_plane_activity':max_activity,'maximum_normal_error_bound_mm':float(max_error),'source_mode_options':80,'row_translation_variables':6,'independent_integer_audit_required':True,'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
