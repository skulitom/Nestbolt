"""Exhaustively read all world/row coordinate links, source regions and partial hints."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-cog-row-integer-20261104';MODEL=BASE/'model';CONTROL=BASE/'row-control';OUT=BASE/'model-audit';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,BASE/'geometry-audit',CONTROL/'audit',MODEL]:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(BASE/'geometry-audit/checks.json')['passed'] and load(CONTROL/'audit/checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'}
mapping=load(MODEL/'mapping.json');owners=mapping['owners'];rows=mapping['cog_rows'];source_rows=load(BASE/'rows.json');modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');inventory=load(BASE/'inventory.json');templates={(t['row'],t['geometry']):t['regions'] for t in load(BASE/'mover-row-templates.json')};pair_templates=load(BASE/'row-pair-templates.json')
assert len(owners)==13 and len(rows)==3 and mapping['position_units_per_mm']==100 and mapping['world_origin_mm']==[0,2100]
assert [o['identity'] for o in owners]==[i['identity'] for i in instances]==inventory['moving13_orthogonal_identities']
assert sorted(i for r in source_rows for i in r['source_indices'])==list(range(13))
used_vars=set();used_ct=set();max_activity=0
def variable(i,name,domain):
    assert i not in used_vars;used_vars.add(i);v=p.variables[i];assert v.name==name and list(v.domain)==domain and {f.name for f,x in v.ListFields()}=={'name','domain'}
def linear(i,co,lo,hi,guard=None):
    global max_activity
    assert i not in used_ct;used_ct.add(i);c=p.constraints[i];co={k:v for k,v in co.items() if v}
    assert c.WhichOneof('constraint')=='linear' and list(c.enforcement_literal)==([] if guard is None else [guard]) and {f.name for f,x in c.ListFields()}=={'linear'}|({'enforcement_literal'} if guard is not None else set())
    assert len(c.linear.vars)==len(co) and dict(zip(c.linear.vars,c.linear.coeffs))==co and list(c.linear.domain)==[lo,hi]
    activity=sum(abs(coeff)*max(abs(v) for v in p.variables[vi].domain) for vi,coeff in co.items());assert activity<2**53;max_activity=max(max_activity,activity)
mode_count=0
for i,owner in enumerate(owners):
    assert owner['owner']==i and owner['positions']==[2*i,2*i+1];expected=modes[owner['identity'][0]];assert len(owner['modes'])==len(expected)
    for k in [0,1]:variable(2*i+k,f'world_{i}_{k}_grid',[min(m['integer_world_lower_left_bounds'][k][0] for m in expected),max(m['integer_world_lower_left_bounds'][k][1] for m in expected)])
    for actual,source in zip(owner['modes'],expected):
        assert {k:v for k,v in actual.items() if k not in ['selector','stock_constraints']}==source;sel=actual['selector'];assert 32<=sel<112;variable(sel,f'mode_{i}_{source["mode"]}',[0,1]);assert len(actual['stock_constraints'])==2
        for k in [0,1]:linear(actual['stock_constraints'][k],{2*i+k:1},*source['integer_world_lower_left_bounds'][k],sel)
        mode_count+=1
    linear(owner['one_mode_constraint'],{m['selector']:1 for m in owner['modes']},1,1)
for row,source in zip(rows,source_rows):
    assert {k:v for k,v in row.items() if k!='positions'}==source and row['positions']==[26+2*row['row'],27+2*row['row']]
    for k,vi in enumerate(row['positions']):variable(vi,f'row_shift_{row["row"]}_{k}_grid',source['shift_bounds_grid'][k])
unary_count=unary_planes=0
for owner in owners:
    i=owner['owner'];geometries=sorted({m['normalized_geometry'] for m in owner['modes']});assert [r['row'] for r in owner['row_regions']]==[0,1,2]
    for block in owner['row_regions']:
        ri=block['row'];rv=rows[ri]['positions'];expected=[(gid,r['region']) for gid in geometries for r in templates[ri,gid]]
        assert [(r['geometry'],r['region']) for r in block['regions']]==expected
        for actual in block['regions']:
            gid,rid,sel=actual['geometry'],actual['region'],actual['selector'];source=next(r for r in templates[ri,gid] if r['region']==rid);variable(sel,f'unary_{i}_{ri}_{gid}_{rid}',[0,1]);assert len(actual['plane_constraints'])==len(source['planes'])
            for ci,plane in zip(actual['plane_constraints'],source['planes']):
                nx,ny=plane['coefficients'];linear(ci,{2*i:nx,2*i+1:ny,rv[0]:-nx,rv[1]:-ny},MIN,plane['upper'],sel);unary_planes+=1
            unary_count+=1
        linear(block['one_region_constraint'],{r['selector']:1 for r in block['regions']},1,1)
        assert [g['geometry'] for g in block['geometry_marginals']]==geometries
        for g in block['geometry_marginals']:
            ms=[m['selector'] for m in owner['modes'] if m['normalized_geometry']==g['geometry']];rs=[r['selector'] for r in block['regions'] if r['geometry']==g['geometry']]
            assert g['mode_selectors']==ms and g['region_selectors']==rs and ms and rs;linear(g['constraint'],{**{v:-1 for v in ms},**{v:1 for v in rs}},0,0)
pair_count=pair_planes=0;row_pair_constraints=[]
assert [r['rows'] for r in mapping['row_pair_regions']]==[[0,1],[0,2],[1,2]]
for actual,source in zip(mapping['row_pair_regions'],pair_templates):
    assert actual['rows']==source['rows'];ai,bi=source['rows'];a,b=rows[ai]['positions'],rows[bi]['positions'];assert [r['region'] for r in actual['regions']]==[r['region'] for r in source['regions']]
    for record,region in zip(actual['regions'],source['regions']):
        sel=record['selector'];variable(sel,f'row_pair_{ai}_{bi}_{region["region"]}',[0,1]);assert len(record['plane_constraints'])==len(region['planes'])
        for ci,plane in zip(record['plane_constraints'],region['planes']):
            nx,ny=plane['coefficients'];linear(ci,{b[0]:nx,b[1]:ny,a[0]:-nx,a[1]:-ny},MIN,plane['upper'],sel);row_pair_constraints.append(ci);pair_planes+=1
        pair_count+=1
    linear(actual['one_region_constraint'],{r['selector']:1 for r in actual['regions']},1,1);row_pair_constraints.append(actual['one_region_constraint'])
rects=load(BASE/'mode-rectangles.json');source_components=load(BASE/'components.json');components=mapping['rigid_components'];source_pairs=load(BASE/'component-pairs.json');separations=mapping['rectangle_separations'];links=0
assert len(components)==20 and mapping['rectangle_gap_grid']==23 and len(separations)==183
for record,source in zip(components,source_components):
    assert {k:v for k,v in record.items() if k not in ['coordinates','mode_links']}==source;owner=owners[source['owner']];family=owner['identity'][0];pi=source['piece'];ci=source['component'];assert len(record['coordinates'])==4
    for k,(vi,label) in enumerate(zip(record['coordinates'],['left','bottom','right','top'])):
        lo=min(m['integer_world_lower_left_bounds'][k%2][0]+rects[family][m['mode']]['rectangles'][pi]['outward_offsets_grid'][k] for m in owner['modes']);hi=max(m['integer_world_lower_left_bounds'][k%2][1]+rects[family][m['mode']]['rectangles'][pi]['outward_offsets_grid'][k] for m in owner['modes']);variable(vi,f'rect_{ci}_{label}_grid',[lo,hi])
    assert len(record['mode_links'])==len(owner['modes'])
    for link,mode in zip(record['mode_links'],owner['modes']):
        offsets=rects[family][mode['mode']]['rectangles'][pi]['outward_offsets_grid'];assert link['mode']==mode['mode'] and link['mode_selector']==mode['selector'] and link['outward_offsets_grid']==offsets and len(link['constraints'])==4
        for k,(ct,v) in enumerate(zip(link['constraints'],offsets)):linear(ct,{record['coordinates'][k]:1,owner['positions'][k%2]:-1},v,v,mode['selector']);links+=1
for record,source in zip(separations,source_pairs):
    assert record['components']==source['components'] and record['owners']==source['owners'];ai,bi=source['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];assert len(record['selectors'])==len(record['constraints'])==4
    for d,(vi,ct,co) in enumerate(zip(record['selectors'],record['constraints'],[{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}])):variable(vi,f'separate_{ai}_{bi}_{d}',[0,1]);linear(ct,co,MIN,-23,vi)
    linear(record['one_direction_constraint'],{v:1 for v in record['selectors']},1,1)
assert [r['components'] for r in separations]==[list(pair) for pair in combinations(range(20),2) if components[pair[0]]['owner']!=components[pair[1]]['owner']]
sym=[]
for family in ['bracket','insert']:
    peers=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1]);sym.extend((family,[a['owner'],b['owner']]) for a,b in zip(peers,peers[1:]))
    for o in peers:
        assert [list(p.variables[v].domain) for v in o['positions']]==[list(p.variables[v].domain) for v in peers[0]['positions']]
        assert [{k:v for k,v in m.items() if k not in ['selector','stock_constraints']} for m in o['modes']]==[{k:v for k,v in m.items() if k not in ['selector','stock_constraints']} for m in peers[0]['modes']]
        assert [[(r['geometry'],r['region']) for r in b['regions']] for b in o['row_regions']]==[[(r['geometry'],r['region']) for r in b['regions']] for b in peers[0]['row_regions']]
assert [(s['family'],s['owners']) for s in mapping['symmetry_constraints']]==sym
for record in mapping['symmetry_constraints']:
    a,b=record['owners'];linear(record['constraint'],{owners[a]['positions'][0]:1,owners[b]['positions'][0]:-1},MIN,0)
control=load(CONTROL/'selected-control.json');hints={}
for row,xy in zip(rows,control['row_shifts_grid']):hints.update(zip(row['positions'],xy))
for pair,rid in zip(mapping['row_pair_regions'],control['row_pair_regions']):hints.update({r['selector']:int(r['region']==rid) for r in pair['regions']})
assert mapping['partial_row_hint']==[[k,v] for k,v in sorted(hints.items())] and list(p.solution_hint.vars)==sorted(hints) and list(p.solution_hint.values)==[hints[k] for k in sorted(hints)] and len(hints)==54
for vi,value in hints.items():assert p.variables[vi].domain[0]<=value<=p.variables[vi].domain[-1]
for ci in row_pair_constraints:
    c=p.constraints[ci]
    if c.enforcement_literal and not hints[c.enforcement_literal[0]]:continue
    activity=sum(coeff*hints[vi] for vi,coeff in zip(c.linear.vars,c.linear.coeffs));assert c.linear.domain[0]<=activity<=c.linear.domain[-1]
assert used_vars==set(range(len(p.variables))) and used_ct==set(range(len(p.constraints))) and links==544 and mode_count==80
process_names={'packet_complete_preparation_seconds':'h5-translated-cog-packet-preflight-process-20261104','failed_row_stagger_preparation_seconds':'h5-independent-cog-rows-process-20261104','fresh_row_regions_complete_preparation_seconds':'h5-independent-cog-rows-v2-process-20261104','row_integer_complete_preparation_seconds':'h5-independent-cog-row-integer-process-20261104','row_control_complete_preparation_seconds':'h5-cog-row-control-process-20261104'}
charges={'source_valid_short11_shared_seconds':load(SHORT/'response-audit/checks.json')['shared_seconds_including_preparation'],'fixed_first_sheet_preparation_seconds':load(FIRST/'checks.json')['seconds'],'cog_site_selection_preparation_seconds':load(SLOTS/'checks.json')['seconds'],'source_rigid_rectangle_preparation_seconds':load(PRIOR/'rigid-rectangle-preflight/checks.json')['seconds'],**{key:load(ROOT/'output'/name/'process.json')['complete_process_seconds'] for key,name in process_names.items()},'cp_model_build_seconds':load(MODEL/'checks.json')['seconds']}
assert charges==load(MODEL/'preparation-charges.json') and sum(charges.values())==load(MODEL/'checks.json')['preparation_seconds_charged'];process=load(MODEL/'build-process.json');assert process['exit_code']==0 and process['complete_process_seconds']>=charges['cp_model_build_seconds']
for name,h in process['inputs'].items():assert digest(ROOT/name)==h
assert process['script_sha256']==digest(ROOT/'output/build_h5_independent_cog_row_model_20261104.py');charges['cp_model_build_seconds']=process['complete_process_seconds'];assert charges==load(MODEL/'final-preparation-charges.json') and sum(charges.values())==load(MODEL/'budget.json')['preparation_seconds_charged']
inputs=[Path(__file__),BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',CONTROL/'audit/plan.json',CONTROL/'audit/checks.json',CONTROL/'selected-control.json']+[p for p in BASE.glob('*.json')]+[p for p in MODEL.glob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Exhaustively reconstruct every variable domain and guarded row. Verify world positions minus each independent row shift, the single shared original source mode across all three row-region selectors, all shiftB-minus-shiftA pair regions, source stock bounds, rigid component links and every different-owner separation. Check identical-copy symmetry, every partial hint value and all row-only constraints under that hint. Verify complete preparation costs including the preserved failed row control and full model process. No full-layout feasibility is inferred from the partial row hint.'})
result={'passed':True,'seconds':time.perf_counter()-started,'variables_verified':len(used_vars),'constraints_verified':len(used_ct),'orthogonal_originals_verified':13,'row_cog_originals_verified':13,'source_mode_selectors_verified':mode_count,'row_translation_variables_verified':6,'mover_row_region_selectors_verified':unary_count,'mover_row_planes_verified':unary_planes,'row_pair_region_selectors_verified':pair_count,'row_pair_planes_verified':pair_planes,'rigid_components_verified':20,'rigid_component_links_verified':links,'different_owner_rectangle_pairs_verified':183,'partial_row_hint_values_verified':len(hints),'partial_row_constraints_satisfied':True,'same_family_order_constraints_verified':len(sym),'all_model_fields_exhaustively_verified':True,'maximum_proto_linear_activity':max_activity,'binary_and_text_models_identical':True,'complete_preparation_seconds_charged':sum(charges.values()),'failed_row_stagger_cost_preserved':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
