"""Audit complete finite control selection, row constraints and original source geometry."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-cog-row-integer-20261104';CONTROL=BASE/'row-control';OUT=CONTROL/'audit';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';PROCESS=ROOT/'output/h5-cog-row-control-process-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
floor=lambda v:v.numerator//v.denominator
ceil=lambda v:-floor(-v)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for name,h in load(CONTROL/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
assert load(BASE/'geometry-audit/checks.json')['passed'];templates={tuple(t['rows']):t['regions'] for t in load(BASE/'row-pair-templates.json')};rows=load(BASE/'rows.json');bounds=rows[0]['shift_bounds_grid']
def fits(x,r):return all(p['coefficients'][0]*x[0]+p['coefficients'][1]*x[1]<=p['upper'] for p in r['planes'])
expected={};candidates=0
for pair in [(0,1),(1,2)]:
    opts=[]
    for r in templates[pair]:
        coords=[[F(v) for v in p] for p in r['hull_vertices']];center=[100*sum(p[k] for p in coords)/len(coords) for k in [0,1]]
        neighbours=sorted({(x,y) for x in [floor(center[0]),ceil(center[0])] for y in [floor(center[1]),ceil(center[1])]})
        candidates+=len(neighbours)
        for point in neighbours:
            if fits(point,r):opts.append({'region':r['region'],'difference_grid':list(point)})
    expected[','.join(map(str,pair))]=opts
assert expected==load(CONTROL/'centroid-grid-options.json');feasible=[];combos=0
for first in expected['0,1']:
    for second in expected['1,2']:
        combos+=1;u,v=first['difference_grid'],second['difference_grid'];w=[u[k]+v[k] for k in [0,1]]
        third=[r['region'] for r in templates[(0,2)] if fits(w,r)]
        if not third:continue
        offsets=[[0,0],u,w];base=[];spread=[];valid=True
        for k,(lo,hi) in enumerate(bounds):
            least=max(lo-p[k] for p in offsets);greatest=min(hi-p[k] for p in offsets)
            if least>greatest:valid=False;break
            base.append(least);spread.append(max(p[k] for p in offsets)-min(p[k] for p in offsets))
        if valid:feasible.append({'row_shifts_grid':[[base[k]+p[k] for k in [0,1]] for p in offsets],'row_pair_regions':[first['region'],min(third),second['region']],'row_pair_differences_grid':[u,w,v],'spread_grid':spread})
assert feasible==load(CONTROL/'feasible-controls.json')
chosen=load(CONTROL/'selected-control.json');assert chosen==min(feasible,key=lambda r:(r['spread_grid'][1],r['spread_grid'][0],r['row_pair_differences_grid'],r['row_pair_regions']))
shifts=chosen['row_shifts_grid'];assert all(lo<=v<=hi for xy in shifts for v,(lo,hi) in zip(xy,bounds))
for pair,region_id,delta in zip([(0,1),(0,2),(1,2)],chosen['row_pair_regions'],chosen['row_pair_differences_grid']):
    assert delta==[shifts[pair[1]][k]-shifts[pair[0]][k] for k in [0,1]];assert fits(delta,next(r for r in templates[pair] if r['region']==region_id))
source_cogs=deepcopy(load(BASE/'source-cogs.json'))
for group,shift in zip(rows,shifts):
    for i in group['source_indices']:source_cogs[i]['transform']['translation']=[v+shift[k]/100 for k,v in enumerate(source_cogs[i]['transform']['translation'])]
source=load(FIRST/'fixed29.json')+source_cogs+load(SHORT);assert source==load(CONTROL/'candidate-source53.json')
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(FIRST/'plan.json');inv=load(BASE/'inventory.json');missing=set(map(tuple,inv['moving13_orthogonal_identities']));expected_ids=set(map(tuple,inv['full66_identities']))-missing
assert {(r['part_id'],r['copy_index']) for r in source}==expected_ids and len(source)==len(expected_ids)==53;shapes=[];holes=vertices=0;stock_min=float('inf')
for row in source:
    part=parts[row['part_id']];t=row['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);sign=-1 if t['mirrored'] else 1;assert not t['mirrored'] or part['allow_mirror']
    assert part['rotations']['kind']=='free' or any(abs(math.remainder(a-math.radians(v),math.tau))<1e-12 for v in part['rotations']['degrees'])
    def ring(poly):return [(sign*x*c-y*s+t['translation'][0],sign*x*s+y*c+t['translation'][1]) for x,y in poly]
    g=part['geometry'][0];outer=Polygon(ring(g['outer']));shape=Polygon(ring(g['outer']),[ring(h) for h in g.get('holes',[])])
    assert outer.is_valid and shape.is_valid and abs(shape.area-Polygon(g['outer'],g.get('holes',[])).area)<1e-6
    x0,y0,x1,y1=outer.bounds;lo_x,lo_y,hi_x,hi_y=spec['source_stocks'][row['sheet_id']];extra=min(x0-lo_x,y0-lo_y,hi_x-x1,hi_y-y1);assert extra>spec['stock_guard_mm'];stock_min=min(stock_min,extra)
    holes+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]));shapes.append((row['sheet_id'],outer))
pair_count=0;gap=float('inf')
for (sa,a),(sb,b) in combinations(shapes,2):
    if sa!=sb:continue
    distance=a.distance(b);assert a.disjoint(b) and distance>spec['required_pair_gap_mm'];gap=min(gap,distance);pair_count+=1
check=load(CONTROL/'original-source-checks.json');assert check['valid'] and pair_count==check['same_sheet_pairs']==916 and holes==check['cutouts']==63 and vertices==check['hole_vertices']==6732 and abs(gap-check['minimum_pair_gap_mm'])<1e-12 and abs(stock_min-check['minimum_extra_stock_mm'])<1e-12
process=load(PROCESS/'process.json');opened=load(PROCESS/'opened.json');assert process['closed'] and process['exit_code']==0 and not process['timeout'] and process['preparation_target_overrun_seconds']==process['complete_process_cap_overrun_seconds']==0
assert opened['script_sha256']==digest(ROOT/opened['script']) and opened['maximum_calls']==1 and not opened['retry_permitted'] and process['complete_process_seconds']>=load(CONTROL/'checks.json')['seconds_including_evidence_serialization']
inputs=[Path(__file__)]+[p for p in CONTROL.glob('*.json')]+[PROCESS/n for n in ['opened.json','process.json','stdout.txt','stderr.txt']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independently enumerate every declared centroid grid neighbour and all adjacent-row difference combinations. Derive feasible base shifts by intersecting three translated domain intervals, verify the complete retained list and deterministic selected minimum. Check all row pair integer planes. Rebuild every original filled polygon and hole directly and verify all916 same-sheet pairs,212 stock edges and the full53 identity set. The resulting control validates the row portion only;13 orthogonal originals remain unplaced.'})
result={'passed':True,'seconds':time.perf_counter()-started,'centroid_grid_neighbours_verified':candidates,'difference_combinations_verified':combos,'feasible_controls_verified':len(feasible),'all_three_selected_row_regions_verified':True,'selected_shifts_grid':shifts,'source_valid53':True,'source_pairs_verified':pair_count,'stock_edges_verified':212,'source_holes_verified':holes,'source_hole_vertices_verified':vertices,'minimum_source_gap_mm':gap,'minimum_extra_stock_mm':stock_min,'complete_preparation_seconds':process['complete_process_seconds'],'full66_identity_partition_preserved':True,'packing_solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
