"""Select a partial row control only from source-audited integer collision regions."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-independent-cog-row-integer-20261104';REG=ROOT/'output/h5-independent-cog-row-regions-v2-20261104';OUT=BASE/'row-control';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'geometry-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT,FIRST/'plan.json',FIRST/'fixed29.json']+[BASE/n for n in ['plan.json','rows.json','source-cogs.json','inventory.json','row-pair-templates.json','geometry-audit/plan.json','geometry-audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Finite deterministic positive control preparation, not a packing solver. For each adjacent row-pair source region, average its exact hull vertices and enumerate the four floor/ceil0.01mm grid neighbours. Keep only points satisfying every audited integer halfplane. Enumerate all pairs of retained adjacent-row differences; require their sum in a0/2 region and require all three row shifts to fit their safe domains. Select the feasible combination with smallest Y spread, then X spread, then lexicographic differences and region IDs. Choose the lowest feasible base X/Y shift. Rebuild and audit all53 original placed parts and every source hole before using the control. No orthogonal placement or full66 claim follows.','complete_preparation_target_seconds':60,'shared_process_cap_seconds':90,'maximum_calls':1,'packing_solver_calls':0,'retry_permitted':False})
templates={tuple(t['rows']):t['regions'] for t in load(BASE/'row-pair-templates.json')};groups=load(BASE/'rows.json');shift=groups[0]['shift_bounds_grid'];grid=100
def inside(point,region):return all(sum(c*v for c,v in zip(p['coefficients'],point))<=p['upper'] for p in region['planes'])
options={};rounding_candidates=0
for pair in [(0,1),(1,2)]:
    candidates=[]
    for r in templates[pair]:
        h=[list(map(F,p)) for p in r['hull_vertices']];center=[sum(p[k] for p in h)*grid/len(h) for k in [0,1]]
        neighbours=sorted(set(product(*[[math.floor(v),math.ceil(v)] for v in center])))
        for point in neighbours:
            rounding_candidates+=1
            if inside(point,r):candidates.append({'region':r['region'],'difference_grid':list(point)})
    options[pair]=candidates
feasible=[];examined=0
for a,b in product(options[(0,1)],options[(1,2)]):
    examined+=1;offsets=[[0,0],a['difference_grid'],[a['difference_grid'][k]+b['difference_grid'][k] for k in [0,1]]]
    covered=[r['region'] for r in templates[(0,2)] if inside(offsets[2],r)]
    if not covered:continue
    ranges=[[min(p[k] for p in offsets),max(p[k] for p in offsets)] for k in [0,1]]
    if not all(rhi-rlo<=shi-slo for (rlo,rhi),(slo,shi) in zip(ranges,shift)):continue
    base=[shift[k][0]-ranges[k][0] for k in [0,1]];shifts=[[base[k]+p[k] for k in [0,1]] for p in offsets]
    record={'row_shifts_grid':shifts,'row_pair_regions':[a['region'],min(covered),b['region']],'row_pair_differences_grid':[offsets[1],offsets[2],b['difference_grid']],'spread_grid':[hi-lo for lo,hi in ranges]}
    feasible.append(record)
write(OUT/'centroid-grid-options.json',{','.join(map(str,k)):v for k,v in options.items()});write(OUT/'feasible-controls.json',feasible)
assert feasible,'No centroid-grid row control found; preserve failed preparation without a packing call.'
chosen=min(feasible,key=lambda r:(r['spread_grid'][1],r['spread_grid'][0],r['row_pair_differences_grid'],r['row_pair_regions']));write(OUT/'selected-control.json',chosen)
rows=deepcopy(load(BASE/'source-cogs.json'))
for group,delta in zip(groups,chosen['row_shifts_grid']):
    assert all(lo<=v<=hi for v,(lo,hi) in zip(delta,shift))
    for i in group['source_indices']:rows[i]['transform']['translation']=[v+delta[k]/grid for k,v in enumerate(rows[i]['transform']['translation'])]
rows=load(FIRST/'fixed29.json')+rows+load(SHORT);job,spec=load(JOB),load(FIRST/'plan.json');inv=load(BASE/'inventory.json');missing=set(map(tuple,inv['moving13_orthogonal_identities']));expected=[tuple(x) for x in inv['full66_identities'] if tuple(x) not in missing]
check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
write(OUT/'candidate-source53.json',rows);write(OUT/'original-source-checks.json',check);assert check['valid'] and check['same_sheet_pairs']==916 and check['cutouts']==63 and check['hole_vertices']==6732
checks={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-started,'centroid_rounding_candidates':rounding_candidates,'adjacent_difference_combinations_checked':examined,'feasible_controls':len(feasible),'selected_row_shifts_grid':chosen['row_shifts_grid'],'selected_difference_spread_grid':chosen['spread_grid'],'source_valid53':True,'source_pairs':916,'stock_edges':212,'source_holes':63,'source_hole_vertices':6732,'all_three_integer_row_pair_regions_satisfied':True,'zero_difference_inside_all_row_pairs':all(any(inside([0,0],r) for r in rs) for rs in templates.values()),'independent_control_audit_required':True,'packing_solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
