"""Deterministic convex-cover reduction; every output still needs source certification."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, shutil, time
from itertools import combinations
from shapely.geometry import Polygon, shape
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT/'output/h5-independent-cog-row-overlap-regions-20261104'
OUT = ROOT/'output/h5-independent-cog-row-reduced-cover-20261104'
PROCESS = ROOT/'output/h5-cog-row-overlap-regions-process-20261104'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()

def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')

assert load(RAW/'checks.json')['passed']
assert load(PROCESS/'process.json')['exit_code'] == 0
OUT.mkdir(); (OUT/'mover-rows').mkdir(); (OUT/'row-pairs').mkdir()
shutil.copyfile(__file__, OUT/'prepare.py')
started = time.perf_counter()
inputs = [Path(__file__)] + list(RAW.rglob('*.json')) + list(PROCESS.glob('*.json'))
write(OUT/'plan.json', {
    'utc': datetime.now(timezone.utc).isoformat(),
    'inputs': {p.relative_to(ROOT).as_posix(): digest(p) for p in inputs},
    'method': 'Reduce the overlapping convex covers with deterministic greedy convex hull unions. Consider touching or overlapping bounding boxes, largest current area first. Accept a hull only when its intersection area with the original inflated source obstacle union is at most 1e-8 square mm; this floating filter is NOT a safety certificate. Remove contained regions through the same union operation. Retain all source controls, modes and row domains. Independently certify every rounded final hull against all original source pieces at 0.225 mm before integer conversion or solving. Preserve all raw regions and every merge. No completeness or continuous exclusion claim.',
    'preparation_stop_seconds': 20, 'complete_process_cap_seconds': 90,
    'candidate_intersection_area_tolerance_mm2': 1e-8,
    'bounding_box_contact_tolerance_mm': 1e-7,
    'solver_calls': 0, 'new_model_created': False, 'H5_complete': False,
})
obstacles = {}
for record in load(RAW/'obstacles.json'):
    key = ('mover', record['row'], record['geometry']) if 'row' in record else ('pair', *record['rows'])
    obstacles[key] = unary_union([shape(p) for p in record['obstacles']])
records = []; merges = []; candidate_tests = 0; max_area = 0.
for sub in ['mover-rows', 'row-pairs']:
    for path in sorted((RAW/sub).glob('*.json')):
        data = load(path)
        key = ('mover', data['row'], data['geometry']) if 'row' in data else ('pair', *data['rows'])
        obstacle = obstacles[key]
        active = {r['region']: Polygon(r['vertices']) for r in data['regions']}
        provenance = {i: [i] for i in active}
        initial = len(active); template_merges = []
        changed = True
        while changed:
            changed = False
            order = sorted(active, key=lambda i: (-active[i].area, i))
            for a, b in combinations(order, 2):
                if a not in active or b not in active: continue
                pa, pb = active[a], active[b]
                ba, bb = pa.bounds, pb.bounds
                if any(ba[k+2] < bb[k]-1e-7 or bb[k+2] < ba[k]-1e-7 for k in [0, 1]): continue
                candidate_tests += 1
                candidate = unary_union([pa, pb]).convex_hull
                overlap = candidate.intersection(obstacle).area
                if overlap > 1e-8: continue
                max_area = max(max_area, overlap)
                template_merges.append({'left': provenance[a][:], 'right': provenance[b][:], 'obstacle_overlap_mm2': overlap})
                active[a] = candidate; provenance[a].extend(provenance.pop(b)); del active[b]
                changed = True
                assert time.perf_counter()-started < 20, 'Closed preparation limit reached.'
        final = []
        for index, i in enumerate(sorted(active)):
            vertices = list(active[i].exterior.coords)[:-1]
            final.append({'region': index, 'vertices': vertices, 'source_regions': sorted(provenance[i])})
        data['regions'] = final
        data['reduced_cover'] = True
        data['original_region_count'] = initial
        data['final_region_count'] = len(final)
        data['floating_coverage_change_mm2'] = unary_union([Polygon(r['vertices']) for r in load(path)['regions']]).symmetric_difference(unary_union(list(active.values()))).area
        write(OUT/sub/path.name, data)
        records.append({'template': list(key), 'original_regions': initial, 'final_regions': len(final), 'coverage_change_mm2': data['floating_coverage_change_mm2']})
        merges.append({'template': list(key), 'merges': template_merges})
        assert time.perf_counter()-started < 20, 'Closed preparation limit reached.'
for path in RAW.glob('*.json'):
    if path.name not in ['plan.json', 'checks.json']:
        shutil.copyfile(path, OUT/path.name)
write(OUT/'reduction.json', records); write(OUT/'merges.json', merges)
checks = {'passed': True, 'seconds_including_evidence_serialization': time.perf_counter()-started,
          'initial_regions': sum(r['original_regions'] for r in records),
          'final_regions': sum(r['final_regions'] for r in records),
          'mover_row_regions': sum(r['final_regions'] for r in records if r['template'][0]=='mover'),
          'row_pair_regions': sum(r['final_regions'] for r in records if r['template'][0]=='pair'),
          'accepted_merges': sum(len(r['merges']) for r in merges), 'candidate_tests': candidate_tests,
          'maximum_accepted_obstacle_overlap_mm2': max_area,
          'independent_source_audit_required': True, 'source_valid66': False,
          'new_model_created': False, 'solver_calls': 0, 'native_calls': 0, 'H5_complete': False}
write(OUT/'checks.json', checks); print(checks)
