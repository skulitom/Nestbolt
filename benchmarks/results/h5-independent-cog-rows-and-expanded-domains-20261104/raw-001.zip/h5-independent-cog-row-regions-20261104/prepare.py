"""Fresh movable-row domains, source controls and all row interaction regions."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from copy import deepcopy
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,box,mapping
from shapely.affinity import translate
from shapely.ops import unary_union
from h5_exact_convex_partition_tools_20261029 import merge_exact
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];PACKET=ROOT/'output/h5-translated-cog-packet-preflight-20261104';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
OUT=ROOT/'output/h5-independent-cog-row-regions-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def polygonal(g):
    if g.is_empty:return Polygon()
    if g.geom_type=='Polygon':return g
    children=[polygonal(p) for p in g.geoms] if hasattr(g,'geoms') else []
    return unary_union([p for p in children if not p.is_empty]) if children else Polygon()
def partition(domain,obstacles):
    free=polygonal(box(*map(float,domain)).difference(unary_union(obstacles)))
    triangles=[p for p in shapely.constrained_delaunay_triangles(free).geoms if p.area>0]
    assert all(p.geom_type=='Polygon' and len(p.exterior.coords)==4 for p in triangles)
    convex,merges=merge_exact(triangles) if triangles else ([],0)
    polys=[Polygon(p) for p in convex];error=unary_union(polys).symmetric_difference(free).area if polys else free.area;assert error<1e-6
    return {'domain_mm':[str(v) for v in domain],'free_area_mm2':free.area,'initial_triangles':len(triangles),'exact_merges':merges,'regions':[{'region':i,'vertices':v} for i,v in enumerate(convex)],'floating_partition_coverage_error_mm2':error}
assert load(PACKET/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'mover-rows').mkdir();(OUT/'row-pairs').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
inputs=[Path(__file__),ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT]+[FIRST/n for n in ['plan.json','fixed29.json','family-modes.json','geometry-library.json','audit/plan.json','audit/checks.json']]+[PACKET/n for n in ['plan.json','packet-source13.json','inventory.json','family-modes.json','translation-domain.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New construction with three independently translated rigid source-cog rows of5,4,4 copies. Each row uses the previously source-certified common shift rectangle, which is safe for stock and fixed29 but does not establish inter-row clearance. Generate fresh no-fit regions for each orthogonal mode versus each row, and for every row pair as a function of shiftB-minus-shiftA. Rebuild Minkowski obstacles from source convex pieces with0.226mm square inflation. Independently certify all retained rounded regions before modeling. Four declared original-source controls use a common X shift and a fixed1mm additional Y shift per row, with base Y restricted to keep every row inside its domain. Preserve all66 identities, short11 and source stock/gap requirements.','square_halfwidth_mm':.226,'required_certified_source_gap_mm':.225,'source_geometry_preparation_target_seconds':30,'complete_process_cap_seconds':90,'future_algorithm_seconds':60,'future_shared_seconds':90,'future_maximum_calls':1,'retry_permitted':False,'control_row_y_increment_mm':1,'count_capacity_tables_used':False,'old_fixed_cog_exclusions_reused':False,'new_model_created':False,'solver_calls':0})
sites=load(PACKET/'packet-source13.json');packet=load(PACKET/'translation-domain.json');modes=load(PACKET/'family-modes.json');inventory=load(PACKET/'inventory.json');library=load(FIRST/'geometry-library.json');cgmode=load(FIRST/'family-modes.json')['cog'][0];grid=packet['shift_grid_units_per_mm'];shift=packet['shift_bounds_grid'];assert grid==100
levels=sorted({r['transform']['translation'][1] for r in sites});groups=[]
for ri,y in enumerate(levels):
    members=[i for i,r in enumerate(sites) if r['transform']['translation'][1]==y]
    groups.append({'row':ri,'reference_y_mm':y,'source_indices':members,'source_identities':[[sites[i]['part_id'],sites[i]['copy_index']] for i in members],'shift_bounds_grid':shift})
assert [len(g['source_indices']) for g in groups]==[5,4,4]
anchors=[]
for site in sites:
    t=site['transform'];assert t['rotation_radians']==cgmode['rotation_radians'] and t['mirrored']==cgmode['mirrored'];anchors.append([t['translation'][k]-cgmode['translation_from_lower_left'][k] for k in [0,1]])
job,spec=load(JOB),load(FIRST/'plan.json');fixed=load(FIRST/'fixed29.json');short=load(SHORT);missing=set(map(tuple,inventory['moving13_orthogonal_identities']));expected=[tuple(x) for x in inventory['full66_identities'] if tuple(x) not in missing]
controls=[];base_y=[shift[1][0],shift[1][1]-2*grid];assert base_y[0]<=base_y[1]
for ci,(sx,sy) in enumerate(product(shift[0],base_y)):
    cogs=deepcopy(sites);row_shifts=[]
    for group in groups:
        delta=[sx,sy+group['row']*grid];assert all(lo<=v<=hi for v,(lo,hi) in zip(delta,shift));row_shifts.append(delta)
        for i in group['source_indices']:cogs[i]['transform']['translation']=[v+delta[k]/grid for k,v in enumerate(cogs[i]['transform']['translation'])]
    source=fixed+cogs+short;check=audit(job,source,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],expected)
    write(OUT/f'control-{ci}-source53.json',source);write(OUT/f'control-{ci}-source-checks.json',check);assert check['valid'] and check['same_sheet_pairs']==916 and check['cutouts']==63 and check['hole_vertices']==6732
    controls.append({'control':ci,'row_shifts_grid':row_shifts,'source':f'control-{ci}-source53.json','source_checks':f'control-{ci}-source-checks.json'})
square=np.asarray([[-.226,-.226],[.226,-.226],[.226,.226],[-.226,.226]])
def inflated(a,b):
    polys=[]
    for pa in a:
        for pb in b:
            differences=(np.asarray(pa)[:,None,:]-np.asarray(pb)[None,:,:]).reshape(-1,2)
            polys.append(MultiPoint((differences[:,None,:]+square[None,:,:]).reshape(-1,2)).convex_hull)
    return unary_union(polys)
mover_records=[];obstacle_records=[]
for gid in range(10):
    aliases=[m for opts in modes.values() for m in opts if m['normalized_geometry']==gid];assert aliases
    bounds=[[max(F(m['relative_lower_left_bounds_mm'][k][0]) for m in aliases),min(F(m['relative_lower_left_bounds_mm'][k][1]) for m in aliases)] for k in [0,1]];domain=[bounds[0][0],bounds[1][0],bounds[0][1],bounds[1][1]]
    nf=inflated(library[10]['pieces'],library[gid]['pieces'])
    for group in groups:
        obstacles=[translate(nf,xoff=anchors[i][0],yoff=anchors[i][1]) for i in group['source_indices']]
        record={'row':group['row'],'geometry':gid,**partition(domain,obstacles)}
        write(OUT/'mover-rows'/f'{group["row"]}-{gid:02d}.json',record);mover_records.append(record)
        obstacle_records.append({'row':group['row'],'geometry':gid,'obstacles':[mapping(p) for p in obstacles]})
    assert time.perf_counter()-started<30,'Fresh row geometry preparation target reached; no solver may open.'
pair_nf=inflated(library[10]['pieces'],library[10]['pieces']);pair_records=[]
relative_bounds=[[F(lo-hi,grid),F(hi-lo,grid)] for lo,hi in shift];domain=[relative_bounds[0][0],relative_bounds[1][0],relative_bounds[0][1],relative_bounds[1][1]]
for ga,gb in combinations(groups,2):
    obstacles=[translate(pair_nf,xoff=anchors[a][0]-anchors[b][0],yoff=anchors[a][1]-anchors[b][1]) for a in ga['source_indices'] for b in gb['source_indices']]
    record={'rows':[ga['row'],gb['row']],'relative_coordinate':'shift_B_minus_shift_A',**partition(domain,obstacles)}
    write(OUT/'row-pairs'/f'{ga["row"]}-{gb["row"]}.json',record);pair_records.append(record)
    obstacle_records.append({'rows':record['rows'],'obstacles':[mapping(p) for p in obstacles]})
    assert time.perf_counter()-started<30,'Fresh inter-row geometry preparation target reached; no solver may open.'
for name,data in [('source-cogs.json',sites),('rows.json',groups),('controls.json',controls),('family-modes.json',modes),('inventory.json',inventory),('obstacles.json',obstacle_records),('instances.json',[{'identity':x,'mode_count':len(modes[x[0]])} for x in inventory['moving13_orthogonal_identities']])]:write(OUT/name,data)
checks={'passed':True,'seconds_including_evidence_serialization':time.perf_counter()-started,'source_cog_rows':3,'source_row_sizes':[5,4,4],'independent_row_translation_variables':6,'source_orthogonal_modes':12,'source_mode_options':80,'mover_row_templates':len(mover_records),'mover_row_regions':sum(len(r['regions']) for r in mover_records),'row_pair_templates':len(pair_records),'row_pair_regions':sum(len(r['regions']) for r in pair_records),'source53_controls':4,'source_control_pairs_verified':3664,'independent_source_region_audit_required':True,'new_model_created':False,'solver_calls':0,'source_valid66':False,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
