"""Build and independently read the new shared-translation source construction."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
old='h5-first55-corner-channel-regions-20261104';new='h5-translated-packet-integer-regions-20261104'
extra="PACKET=ROOT/'output/h5-translated-cog-packet-preflight-20261104';PACKET_PROCESS=ROOT/'output/h5-translated-cog-packet-preflight-process-20261104';REG_PROCESS=ROOT/'output/h5-translated-packet-regions-process-20261104'\n"
charges="{'source_valid_short11_shared_seconds':load(SHORT/'response-audit/checks.json')['shared_seconds_including_preparation'],'fixed_first_sheet_preparation_seconds':load(FIRST/'checks.json')['seconds'],'cog_site_selection_preparation_seconds':load(SLOTS/'checks.json')['seconds'],'source_rigid_rectangle_preparation_seconds':load(PRIOR/'rigid-rectangle-preflight/checks.json')['seconds'],'packet_complete_preparation_seconds':load(PACKET_PROCESS/'process.json')['complete_process_seconds'],'fresh_relative_region_complete_preparation_seconds':load(REG_PROCESS/'process.json')['complete_process_seconds'],'integer_region_complete_preparation_seconds':load(PREPARATION_PROCESS/'process.json')['complete_process_seconds'],'cp_model_build_seconds':elapsed}"
def common(s):return s.replace(old,new).replace('h5-corner-channel-preparation-process-20261104','h5-translated-packet-integer-process-20261104').replace('load=lambda p:',extra+'load=lambda p:',1)
s=common((ROOT/'output/build_h5_corner_channel_model_20261104.py').read_text(encoding='utf-8'))
s=s.replace('for owner in owners:\n',"shift_bounds=load(BASE/'packet-translation-domain.json')['shift_bounds_grid']\npacket_shift=[model.new_int_var(lo,hi,f'packet_shift_{axis}_grid').index for axis,(lo,hi) in enumerate(shift_bounds)]\nassert packet_shift==[26,27]\nfor owner in owners:\n",1)
s=s.replace("'stock_constraints':[]", "'stock_constraints':[],'world_stock_constraints':[]")
anchor="            lo,hi=mode['integer_lower_left_bounds'][axis];record['stock_constraints'].append(linear({var:1},lo,hi,selector))"
s=s.replace(anchor,anchor+"\n            lo,hi=mode['integer_world_lower_left_bounds'][axis];record['world_stock_constraints'].append(linear({var:1,packet_shift[axis]:1},lo,hi,selector))")
start=s.index('empty=[model.new_bool_var');end=s.index('unary_plane_count=',start);s=s[:start]+s[end:]
s=s.replace("'required_empty_sites':region['required_empty_sites'],", '').replace(",'empty_site_constraints':[]",'')
start=s.index("            for site in region['required_empty_sites']:");end=s.index("            owner['unary_regions'].append(record)",start);s=s[:start]+s[end:]
s=s.replace("'empty_site_selectors':empty,'exactly_two_empty_sites_constraint':exact_two,", "'packet_translation_variables':packet_shift,'packet_shift_bounds_grid':shift_bounds,")
s=s.replace(",'forbidden_site_pairs':forbidden",'')
start=s.index('charges={');end=s.index(";write(OUT/'preparation-charges.json'",start);s=s[:start]+'charges='+charges+s[end:]
start=s.index('inputs=[Path(__file__)');end=s.index("write(OUT/'plan.json'",start)
s=s[:start]+"inputs=[Path(__file__),PREPARATION_PROCESS/'opened.json',PREPARATION_PROCESS/'process.json',PACKET_PROCESS/'opened.json',PACKET_PROCESS/'process.json',REG_PROCESS/'opened.json',REG_PROCESS/'process.json',PACKET/'plan.json',PACKET/'audit/plan.json',PACKET/'audit/checks.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',FIRST/'checks.json',SLOTS/'checks.json',SHORT/'response-audit/plan.json',SHORT/'response-audit/checks.json']+[BASE/n for n in ['plan.json','checks.json','family-modes.json','unary-templates.json','mode-rectangles.json','instances.json','inventory.json','components.json','component-pairs.json','packet-translation-domain.json']]+[PRIOR/'rigid-rectangle-preflight'/n for n in ['plan.json','checks.json']]\n"+s[end:]
start=s.index("'method':'Construct all13");end=s.index("'algorithm_seconds':60",start)
s=s[:start]+"'method':'New translating-packet construction: all13 orthogonal owners and80 modes retain independent relative coordinates. Two additional shared X/Y variables translate all13 reference cogs and every orthogonal coordinate together into world space. Every mode has both relative-domain and original world-stock constraints. Fresh certified relative unary hulls protect mover/cog clearance; all20 rigid outward rectangles and183 different-owner pairs require0.23mm spacing. The separately source-certified packet shift domain protects cogs against stock and fixed29. Same-family relative-X order only removes interchangeable-copy symmetry. No fixed-cog count table, objective or hint is used. Audit all fields before one60/90-second call and charge every preparation process.',"+s[end:]
s=s.replace("'empty_site_selectors':15,'retained_empty_site_pairs':1,'forbidden_site_pair_constraints':104", "'shared_packet_translation_variables':2,'world_stock_constraints':160")
s=s.replace("'empty_site_mask_implications':mask_links", "'packet_shift_bounds_grid':shift_bounds")
save('build_h5_translated_packet_model_20261104.py',s)
s=(ROOT/'output/run_h5_corner_channel_model_build_20261104.py').read_text(encoding='utf-8').replace(old,new).replace('build_h5_corner_channel_model_20261104.py','build_h5_translated_packet_model_20261104.py')
save('run_h5_translated_packet_model_build_20261104.py',s)
s=common((ROOT/'output/audit_h5_corner_channel_model_20261104.py').read_text(encoding='utf-8'))
s=s.replace('rectangle_start=121+expected_unary', 'rectangle_start=108+expected_unary')
s=s.replace("['selector','stock_constraints']", "['selector','stock_constraints','world_stock_constraints']")
s=s.replace('26<=selector<106','28<=selector<108')
anchor="        for k in [0,1]:linear(actual['stock_constraints'][k],{2*i+k:1},*source['integer_lower_left_bounds'][k],selector)"
s=s.replace(anchor,anchor+"\n        assert len(actual['world_stock_constraints'])==2\n        for k in [0,1]:linear(actual['world_stock_constraints'][k],{2*i+k:1,26+k:1},*source['integer_world_lower_left_bounds'][k],selector)")
start=s.index("empty=mapping['empty_site_selectors']");end=s.index('for i,owner in enumerate(owners):',start)
s=s[:start]+"shift_bounds=load(BASE/'packet-translation-domain.json')['shift_bounds_grid'];assert mapping['packet_translation_variables']==[26,27] and mapping['packet_shift_bounds_grid']==shift_bounds\nfor k in [0,1]:variable(26+k,f'packet_shift_{k}_grid',shift_bounds[k])\n"+s[end:]
s=s.replace('assert 121<=selector<rectangle_start', 'assert 108<=selector<rectangle_start')
s=s.replace("assert region['required_empty_sites']==source['required_empty_sites'] and len(region['plane_constraints'])==len(source['planes'])", "assert len(region['plane_constraints'])==len(source['planes'])")
start=s.index("        assert len(region['empty_site_constraints'])");end=s.index('        unary_count+=1',start);s=s[:start]+s[end:]
start=s.index('expected_charges={');end=s.index("\nassert load(MODEL/'preparation-charges.json')",start)
s=s[:start]+'expected_charges='+charges.replace("'cp_model_build_seconds':elapsed", "'cp_model_build_seconds':load(MODEL/'checks.json')['seconds']")+s[end:]
s=s.replace('build_h5_corner_channel_model_20261104.py','build_h5_translated_packet_model_20261104.py')
s=s.replace("assert load(BASE/'geometry-audit/checks.json')['selection_uses_only_cog_geometry']", "assert load(BASE/'geometry-audit/checks.json')['source_certified_shared_translation_verified'] and load(BASE/'geometry-audit/checks.json')['relative_and_world_domains_verified']")
s=s.replace("(r['geometry'],r['region'],r['required_empty_sites'])", "(r['geometry'],r['region'])")
s=s.replace("'allowed-empty-site-pairs.json'", "'packet-translation-domain.json'")
s=s.replace("'empty_site_selectors_verified':15,'exactly_two_empty_sites_verified':True", "'shared_packet_translation_variables_verified':2,'world_stock_constraints_verified':160")
s=s.replace("'empty_site_implications_verified':mask_links", "'packet_shift_bounds_verified':shift_bounds")
s=s.replace("'corner_channel_choice_verified':True", "'source_certified_packet_translation_verified':True")
s=s.replace("'forbidden_site_pairs_verified':104,", '')
s=s.replace("inputs=[Path(__file__),", "inputs=[Path(__file__),PACKET_PROCESS/'opened.json',PACKET_PROCESS/'process.json',REG_PROCESS/'opened.json',REG_PROCESS/'process.json',PACKET/'audit/plan.json',PACKET/'audit/checks.json',",1)
save('audit_h5_translated_packet_model_20261104.py',s)
