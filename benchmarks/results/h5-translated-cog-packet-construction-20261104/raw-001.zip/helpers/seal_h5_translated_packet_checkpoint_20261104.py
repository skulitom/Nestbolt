"""Seal the audited movable-packet construction and its sole closed call."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-translated-cog-packet-construction-20261104';OUT=ROOT/'benchmarks/results'/NAME
REG=ROOT/'output/h5-translated-packet-regions-20261104';BASE=ROOT/'output/h5-translated-packet-integer-regions-20261104'
PARENTS=[ROOT/'benchmarks/results'/n for n in ['h5-continuous-small-block-exclusions-20261104','h5-continuous-inserts-and-bracket-capacities-20261104','h5-direct-counts-and-relative-hull-capacities-20261104','h5-corner-channel-construction-20261104','h5-relative-projections-and-movable-packet-20261104']]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
assert load(REG/'source-region-audit/checks.json')['passed']
for folder in ['geometry-audit','model-audit','response-audit']:assert load(BASE/folder/'checks.json')['passed']
response=load(BASE/'response-audit/checks.json');assert response['solver_status']=='INFEASIBLE' and response['closed_solver_calls']==1 and response['assignments']==0 and response['algorithm_overrun_seconds']==response['shared_overrun_seconds']==response['solve_slice_overrun_seconds']==0
parent_by_hash={}
for parent in PARENTS:
    assert load(parent/'archive-checks.json')['passed'];manifest=load(parent/'raw-manifest.json');h=digest(parent/'raw-manifest.json')
    for row in manifest['files']:parent_by_hash.setdefault((row['sha256'],row['bytes']),(parent,h,row))
OUT.mkdir();members={};external={};queue=[];seen=set();bindings={}
def traversable(p):return p.name in ['plan.json','opened.json'] or p.name.endswith('process.json')
def add(name,p):
    assert p.is_file() and p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts)
    h=digest(p);size=p.stat().st_size;prior=parent_by_hash.get((h,size))
    if prior:
        parent,mh,row=prior;external[name]={'manifest':(parent/'raw-manifest.json').relative_to(ROOT).as_posix(),'manifest_sha256':mh,'archive':row['archive'],'member':row['path'],'bytes':size,'sha256':h}
    else:members[name]=p
    if traversable(p) or p.suffix=='.py':queue.append(p)
processes=[ROOT/'output'/n for n in ['h5-translated-packet-regions-process-20261104','h5-translated-packet-integer-process-20261104']]
for folder in [BASE,REG]+processes:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for p in (ROOT/'output').glob('*h5*translated_packet*20261104.py'):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,'audit_h5_cog_site_mask_regions_20261029.py','prepare_h5_corner_channel_regions_20261104.py','audit_h5_corner_channel_regions_20261104.py','build_h5_corner_channel_model_20261104.py','audit_h5_corner_channel_model_20261104.py','run_h5_corner_channel_model_build_20261104.py','run_h5_corner_channel_model_20261104.py']:add('helpers/'+name,ROOT/'output'/name)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if traversable(p):
        data=load(p)
        for name,h in data.get('inputs',{}).items():
            z=ROOT/name;assert digest(z)==h,name;bindings[name]=h;add('source-inputs/'+name,z)
        if 'script' in data and 'script_sha256' in data:
            z=ROOT/data['script'];assert digest(z)==data['script_sha256'];bindings[data['script']]=data['script_sha256'];add('source-inputs/'+data['script'],z)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    z=ROOT/folder/(module+'.py')
                    if z.is_file():add('imported-helpers/'+folder+'/'+z.name,z)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'external-evidence.json',external);write(OUT/'source-bindings.json',bindings)
for source,name in [(REG/'checks.json','relative-regions.json'),(REG/'source-region-audit/checks.json','source-region-audit.json'),(processes[0]/'process.json','region-process.json'),(processes[1]/'process.json','integer-process.json'),(BASE/'geometry-audit/checks.json','integer-geometry-audit.json'),(BASE/'model/checks.json','model.json'),(BASE/'model/build-process.json','model-build-process.json'),(BASE/'model/final-preparation-charges.json','preparation-charges.json'),(BASE/'model/budget.json','budget.json'),(BASE/'model-audit/checks.json','model-audit.json'),(BASE/'response-audit/checks.json','response-audit.json')]:shutil.copyfile(source,OUT/name)
write(OUT/'next-step.json',{'closed_call_must_not_be_repeated':True,'current_model_sha256':load(BASE/'model-audit/checks.json')['model_sha256'],'current_call_status':'INFEASIBLE','continuous_exclusion_proven':False,'remaining_allocation_candidates':440,'fixed_cog_frontier_unchanged':{'site_choices':2,'count_distributions':3},'next_construction_hypothesis':'Replace the single rigid13-cog packet with three independently translated rigid rows containing5,4,4 source cogs. Preserve each row internal source geometry and the common safe shift rectangle as an initial constructive domain. This adds four degrees of freedom while retaining all66 identities. Generate fresh mover-to-row relative regions and row-to-row collision regions; shared translation no longer cancels across different rows. Independently certify every original piece interaction and the common-shift partial53 positive controls before any new model. World stock limits, fixed29 separation, source-valid short11, original gap/material target and60/90-second charged budget remain mandatory. Do not transfer fixed-cog counts, grid infeasibility or the single-packet pair safety to independently moving rows.','packet_preflight':'output/h5-translated-cog-packet-preflight-20261104','fresh_current_source_regions':'output/h5-translated-packet-regions-20261104','canonical_source_pieces':'output/h5-short11-all-pair-separators-20261029/canonical-pieces.json','prior_free26_template_note':'The older first55 compact-pair-regions-v2 covers95 geometry templates and88690 expanded choices. It has conservative floating coverage limitations and must not be treated as a source of global exclusions. Inspect existing audit records before using any template.','new_row_construction_prepared':False,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'source_relative_regions':228,'source_support_proofs':10268,'integer_planes':847,'variables':2407,'constraints':7410,'shared_translation_variables':2,'charged_preparation_seconds':response['preparation_seconds_charged'],'closed_solver_calls':1,'solver_status':'INFEASIBLE','assignments':0,'solve_slice_overrun_seconds':0,'overall_algorithm_shared_overruns_seconds':0,'continuous_source_domain_excluded':False,'remaining_allocation_candidates':440,'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Translated cog packet: audited closed call — 2026-11-04

Allowing the selected 13 cogs to translate together produces **no complete
placement**. The new model's sole bounded call closes **INFEASIBLE on its
0.01 mm grid**, with no assignment and no time overrun. This is a conservative
construction result, not an independent unsatisfiability certificate or a
continuous-source exclusion. All 440 whole-job allocations remain; H2/H5 stay
open at **60% completed milestone weight**.

## Fresh relative source geometry

The preceding [movable-packet preflight](h5-relative-projections-and-movable-packet-20261104.md)
proves the full permitted translation rectangle against original source
outlines and fixed stock/core limits. The new preparation rebuilds no-fit
obstacles from convex source pieces over the enlarged relative-coordinate
domains. It uses all 13 reference cogs and every legal orthogonal mode; no old
fixed-cog region or count-capacity table is consumed.

[Independent source readback]({NAME}/source-region-audit.json) checks **228
rounded convex regions** against all 12 source modes and all 13 original cogs.
It verifies **10,268 exact rational support proofs**, including 217 cases where
whole-cog hull separation is insufficient and all 21 original convex pieces
must be checked. Minimum certified source separation is **0.225999999447 mm**.
No region collapses after rounding. This is a safety proof for the retained
construction regions, with no global free-space coverage claim.

[The integer audit]({NAME}/integer-geometry-audit.json) verifies all **847
halfplane implications** on the 0.01 mm grid. It bounds normal-rounding error
over absolute local coordinates of 1600 × 1000 mm, including negative Y, and
retains at least 0.0000001 mm inward reserve. It separately checks both relative
and world-coordinate mode domains, the source-certified packet shift bounds,
and all 20 outward-rounded component rectangles. Maximum normal error is
0.007988366 mm; maximum component padding is below 0.01 mm.

## Shared translation in the full construction

[The model audit]({NAME}/model-audit.json) verifies every field of **2,407
variables and 7,410 constraints**. Thirteen orthogonal originals have independent
relative positions and all 80 source-mode selectors. Two additional variables
translate the entire reference cog packet. Every selected mode has its original
world-stock bounds enforced on the sum of relative position and packet shift:
all **160 new world-coordinate rows** are checked.

The 1,487 unary selectors and 5,526 guarded planes imply fresh source-safe
relative placement regions. All 20 component rectangles stay rigidly linked to
their original through 544 equalities; all 183 different-owner component pairs
require 0.23 mm axis spacing. The 11 same-family X-order rows only remove
interchangeable-copy symmetry. There is no objective, hint or capacity table.
The prepared source reader reconstructs all 66 original contours from any
assignment before native validation could run.

## Complete budget and response

[The final charge ledger]({NAME}/preparation-charges.json) totals **31.060628 s**:
the prior source-valid short11 construction, fixed-core/site/rectangle preparation,
the complete 2.087144 s packet preflight, complete 0.811722 s fresh region process,
complete 0.619951 s integer process, and **5.132983 s complete model build**.
The narrower internal build timestamp is preserved but is not the final charge.

[Independent response readback]({NAME}/response-audit.json) verifies one closed
call, **24.227846 s allocated solve time**, **9.115304 s returned solve time**,
182,013 branches and 54,427 conflicts. Preparation-inclusive algorithm/shared
totals are **40.896624 / 40.973398 s**. Solve-slice and overall overruns are zero.
There are no incumbents, assignments, source66 readbacks or native calls.
This call will not be repeated, reseeded or extended.

[The next construction hypothesis]({NAME}/next-step.json) separates the cog
packet into its three rigid rows of 5, 4 and 4 cogs, with independent translations.
This needs fresh mover-to-row and row-to-row collision regions: the current
proof that common translation cancels cannot protect independently moving rows.
The common-shift controls remain useful positive controls, and every original
stock, clearance, identity, material and charged-time requirement stays in force.
No such row model has been prepared or run yet.

The fixed-cog frontier remains two site choices / three count distributions.
Full66 original-source checks, native/material validation, production integration
and the full H5 matrix remain required. H2 retains its original gate and 22
unopened reserved vectors. Production and READMEs are unchanged; no release
qualifies. Main a3fcf47f has four successful jobs and two live checks in
[CI41894305822](https://github.com/skulitom/Nestbolt/actions/runs/41894305822)
at review. Local checkpoint34834b90 and this evidence wait for all six jobs and
the aggregate run before another normal push.

[The manifest]({NAME}/raw-manifest.json) contains {archive['archive_members']}
new canonical members and {archive['archive_bytes']:,} compressed bytes.
[External references]({NAME}/external-evidence.json) and
[source bindings]({NAME}/source-bindings.json) retain exact historical inputs.
The independent archive reader verifies every new and reused member, all input
hashes and every local report link before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 translated cog packet:** [the independent construction audits]({link}) verify 228 freshly source-certified relative regions, 847 integer-plane implications and the complete 2,407-variable / 7,410-constraint model with two shared translation variables. Its sole call closes grid INFEASIBLE with no assignment. Complete preparation is 31.060628 s; algorithm/shared totals are 40.896624 / 40.973398 s, with no overruns. No continuous exclusion follows. Next investigate independently translated cog rows with fresh inter-row safety proofs. All 440 allocations, full 66-part validation and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [relative projections and a movable cog packet](../benchmarks/results/h5-relative-projections-and-movable-packet-20261104.md).';assert s.count(old)==1
s=s.replace(old,f'Latest H5 evidence: [translated cog-packet construction](../benchmarks/results/{NAME}.md).',1)
s=s.replace('A new shared-translation packet preflight passes; its relative regions and model\nremain to build and audit.','The shared-translation packet construction is audited and its sole grid call\nis closed without a placement. Independently moving cog rows are the next\nconstruction hypothesis; their interaction proofs and model remain unbuilt.',1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
