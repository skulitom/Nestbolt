"""Adapt the independent original-source support reader to the fresh packet regions."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_cog_site_mask_regions_20261029.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'output/h5-first55-cog-site-masks-20261029'", "BASE=ROOT/'output/h5-translated-packet-regions-20261104'")
s=s.replace("JOB=ROOT/", "PRE=ROOT/'output/h5-translated-cog-packet-preflight-20261104'\nJOB=ROOT/",1)
s=s.replace("assert load(SLOTS/'audit/checks.json')['passed']", "assert load(PRE/'audit/checks.json')['passed']")
s=s.replace("sites=load(SLOTS/'source-cog-sites.json')", "sites=load(PRE/'packet-source13.json')")
s=s.replace("assert modes=={k:v for k,v in load(FIRST/'family-modes.json').items() if k!='cog'}", "assert modes==load(PRE/'family-modes.json')")
s=s.replace('mask_pairs=set()', 'rounded_records=[]')
start=s.index("    b=eligible[0][1]['mode']['lower_left_bounds']")
end=s.index('    checked=0',start)
s=s[:start]+'''    bounds=[[max(F(v['mode']['relative_lower_left_bounds_mm'][k][0]) for _,v in eligible),min(F(v['mode']['relative_lower_left_bounds_mm'][k][1]) for _,v in eligible)] for k in [0,1]]
    assert list(map(F,data['relative_domain_mm']))==[bounds[0][0],bounds[1][0],bounds[0][1],bounds[1][1]]
''' +s[end:]
start=s.index("        assert region['region']==index")
end=s.index('        rounded=hull',start)
s=s[:start]+"        assert region['region']==index\n"+s[end:]
s=s.replace("        shape=Polygon([(float(x),float(y)) for x,y in rounded]);assert shape.is_valid and shape.area>0", "        shape=Polygon([(float(x),float(y)) for x,y in rounded]);assert shape.is_valid and shape.area>0\n        rounded_records.append({'geometry':gid,'region':index,'hull_vertices':[[str(x),str(y)] for x,y in rounded]})")
s=s.replace('                if si in empty:continue\n','')
s=s.replace('assert mask_pairs==set(combinations(range(15),2))', "assert len(cogs)==13\nwrite(OUT/'rounded-regions.json',rounded_records)")
s=s.replace("SLOTS/'source-cog-sites.json',SLOTS/'audit/plan.json',SLOTS/'audit/checks.json'", "PRE/'packet-source13.json',PRE/'family-modes.json',PRE/'translation-domain.json',PRE/'audit/plan.json',PRE/'audit/checks.json'")
start=s.index("'method':'Independently transform")
end=s.index("})\nresult=",start)
s=s[:start]+"'method':'Independently transform original convex source pieces for all12 orthogonal source modes and the13 fixed reference cog poses. For every freshly rebuilt rounded relative region, certify separation from every reference cog. Prefer exact rational support against the whole cog hull; otherwise certify every one of its21 original convex pieces. Preserve source aliases separately. Shared packet translation cancels in these relative comparisons. Check original source partition coverage, the expanded relative domains, and all regions. Explicitly disable rounded degenerate regions. This proves positive safety only, not global free-space coverage.'"+s[end:]
s=s.replace("'original_cog_sites_verified':15", "'original_cog_sites_verified':13")
s=s.replace("'all105_empty_site_pairs_represented':True", "'all13_reference_cogs_checked':True,'fresh_expanded_relative_regions_verified':True,'shared_translation_cancels_in_source_supports':True")
p=ROOT/'output/audit_h5_translated_packet_regions_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
