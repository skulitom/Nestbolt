"""Prepare conservative integer conversion and its independent implication audit."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def save(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
new='h5-translated-packet-integer-regions-20261104'
extra="REG=ROOT/'output/h5-translated-packet-regions-20261104';PACKET=ROOT/'output/h5-translated-cog-packet-preflight-20261104'\n"
s=(ROOT/'output/prepare_h5_corner_channel_regions_20261104.py').read_text(encoding='utf-8').replace('h5-first55-corner-channel-regions-20261104',new)
s=s.replace('load=lambda p:',extra+'load=lambda p:',1)
s=s.replace("assert load(PRIOR/'source-region-audit/checks.json')['passed']", "assert load(REG/'source-region-audit/checks.json')['passed'] and load(PACKET/'audit/checks.json')['passed']")
s=s.replace('envelope=[F(1500),F(900)]','envelope=[F(1600),F(1000)]')
start=s.index("sites=load(SLOTS/'source-cog-sites.json')");end=s.index("modes=load(PRIOR/'family-modes.json')",start)
s=s[:start]+"packet_domain=load(PACKET/'translation-domain.json');write(OUT/'packet-translation-domain.json',packet_domain)\n"+s[end:]
s=s.replace("modes=load(PRIOR/'family-modes.json')", "modes=load(REG/'family-modes.json')")
s=s.replace("for k,(lo,hi) in enumerate(m['lower_left_bounds'])", "for k,(lo,hi) in enumerate(m['relative_lower_left_bounds_mm'])")
anchor='converted_rectangles='
idx=s.index(anchor);s=s[:idx]+"for opts in converted.values():\n    for m in opts:m['integer_world_lower_left_bounds']=[[math.ceil((F(lo)-origin[k])*grid),math.floor((F(hi)-origin[k])*grid)] for k,(lo,hi) in enumerate(m['lower_left_bounds'])]\n"+s[idx:]
s=s.replace("for old_template in load(PRIOR/'integer-preparation/unary-templates.json'):", "source_regions=load(REG/'source-region-audit/rounded-regions.json')\nsource_templates=[{'geometry':gid,'regions':[{k:v for k,v in r.items() if k!='geometry'} for r in source_regions if r['geometry']==gid]} for gid in range(10)]\nfor old_template in source_templates:")
start=s.index("        if not any(old['required_empty_mask']");end=s.index('        polygon=',start);s=s[:start]+s[end:]
s=s.replace("['region','required_empty_mask','required_empty_sites','hull_vertices']", "['region','hull_vertices']")
s=s.replace(",('allowed-empty-site-pairs.json',allowed)", '')
s=s.replace("shutil.copyfile(PRIOR/name,OUT/name)", "shutil.copyfile(REG/name,OUT/name)")
start=s.index('inputs=[Path(__file__)');end=s.index("write(OUT/'plan.json'",start)
s=s[:start]+"inputs=[Path(__file__)]+[REG/n for n in ['plan.json','checks.json','family-modes.json','instances.json','inventory.json','source-region-audit/plan.json','source-region-audit/checks.json','source-region-audit/rounded-regions.json']]+[PACKET/n for n in ['translation-domain.json','audit/plan.json','audit/checks.json']]+[PRIOR/'rigid-rectangle-preflight'/n for n in ['plan.json','checks.json','mode-rectangles.json','components.json','component-pairs.json','audit-v3/plan.json','audit-v3/checks.json']]\n"+s[end:]
start=s.index("'method':'Use local origin");end=s.index("'grid_units_per_mm':grid",start)
s=s[:start]+"'method':'Convert the freshly source-certified movable-packet relative hulls to local(0,2100)mm,0.01mm positions and exact rational infinity-normalized edge coefficients rounded at scale100000. Charge worst-case normal error over absolute local coordinates1600x1000mm, including negative Y, plus1e-7mm inset. Preserve every source mode and region. Convert both relative and world-coordinate mode domains; preserve the separately source-audited shared packet translation limits. Outward-round all original rigid component rectangles and require0.23mm different-owner spacing. Independently verify every implication before modeling. No fixed-cog capacity or source region is reused.',"+s[end:]
s=s.replace("'retained_empty_site_pairs':1,'selected_empty_sites':selected", "'shared_packet_translation_variables':2,'packet_shift_bounds_grid':packet_domain['shift_bounds_grid']")
save('prepare_h5_translated_packet_integer_regions_20261104.py',s)
s=(ROOT/'output/audit_h5_corner_channel_regions_20261104.py').read_text(encoding='utf-8').replace('h5-first55-corner-channel-regions-20261104',new)
s=s.replace('load=lambda p:',extra+'load=lambda p:',1).replace('limit==[1500,900]','limit==[1600,1000]')
s=s.replace("prior_modes=load(PRIOR/'family-modes.json')", "prior_modes=load(REG/'family-modes.json')")
s=s.replace("if k!='integer_lower_left_bounds'", "if k not in ['integer_lower_left_bounds','integer_world_lower_left_bounds']")
s=s.replace("old['lower_left_bounds'][axis]", "old['relative_lower_left_bounds_mm'][axis]")
s=s.replace('assert 0<=lo<=hi<=limit[axis]*grid', 'assert -limit[axis]*grid<=lo<=hi<=limit[axis]*grid')
anchor='        mode_count+=1'
s=s.replace(anchor,"        for axis in [0,1]:\n            a,b=map(F,old['lower_left_bounds'][axis]);lo,hi=m['integer_world_lower_left_bounds'][axis]\n            assert [lo,hi]==[ceil((a-origin[axis])*grid),floor((b-origin[axis])*grid)] and F(lo,grid)+origin[axis]>=a and F(hi,grid)+origin[axis]<=b\n"+anchor)
start=s.index("sites=load(SLOTS/'source-cog-sites.json')");end=s.index('new_unary=load',start)
s=s[:start]+"assert load(REG/'source-region-audit/checks.json')['passed'] and load(PACKET/'audit/checks.json')['passed']\npacket_domain=load(PACKET/'translation-domain.json');assert packet_domain==load(BASE/'packet-translation-domain.json') and packet_domain['shift_grid_units_per_mm']==grid\nsource_regions=load(REG/'source-region-audit/rounded-regions.json')\nold_unary=[{'geometry':gid,'regions':[{k:v for k,v in r.items() if k!='geometry'} for r in source_regions if r['geometry']==gid]} for gid in range(10)];"+s[end:]
s=s.replace("keep=[r for r in old['regions'] if any(set(r['required_empty_sites'])<=set(pair) for pair in allowed)]", "keep=old['regions']")
s=s.replace("digest(PRIOR/n)", "digest(REG/n)")
start=s.index('inputs=[Path(__file__)');end=s.index("write(OUT/'plan.json'",start)
s=s[:start]+"inputs=[Path(__file__),REG/'source-region-audit/plan.json',REG/'source-region-audit/checks.json',REG/'source-region-audit/rounded-regions.json',PACKET/'translation-domain.json',PACKET/'audit/plan.json',PACKET/'audit/checks.json']+[BASE/n for n in ['plan.json','checks.json','family-modes.json','mode-rectangles.json','unary-templates.json','removed-regions.json','packet-translation-domain.json','instances.json','inventory.json','components.json','component-pairs.json']]\n"+s[end:]
s=s.replace("'remaining_empty_site_pairs_verified':1,'selected_empty_sites_verified':chosen,'selection_uses_only_cog_geometry':True", "'packet_shift_bounds_verified':packet_domain['shift_bounds_grid'],'relative_and_world_domains_verified':True,'source_certified_shared_translation_verified':True")
save('audit_h5_translated_packet_integer_regions_20261104.py',s)
s=(ROOT/'output/run_h5_translated_packet_regions_20261104.py').read_text(encoding='utf-8').replace('h5-translated-packet-regions-process-20261104','h5-translated-packet-integer-process-20261104').replace('prepare_h5_translated_packet_regions_20261104.py','prepare_h5_translated_packet_integer_regions_20261104.py')
save('run_h5_translated_packet_integer_regions_20261104.py',s)
