"""Exact conservative local-coordinate unary planes and rigid rectangles on a0.01mm grid."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';OUT=ROOT/'output/h5-translated-packet-integer-regions-20261104'
REG=ROOT/'output/h5-translated-packet-regions-20261104';PACKET=ROOT/'output/h5-translated-cog-packet-preflight-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(REG/'source-region-audit/checks.json')['passed'] and load(PACKET/'audit/checks.json')['passed'] and load(PRIOR/'rigid-rectangle-preflight/audit-v3/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
origin=[F(0),F(2100)];envelope=[F(1600),F(1000)];grid=100;scale=100000;epsilon=F('1e-7')
packet_domain=load(PACKET/'translation-domain.json');write(OUT/'packet-translation-domain.json',packet_domain)
modes=load(REG/'family-modes.json');rectangles=load(PRIOR/'rigid-rectangle-preflight/mode-rectangles.json')
converted={family:[{**m,'integer_lower_left_bounds':[[math.ceil((F(lo)-origin[k])*grid),math.floor((F(hi)-origin[k])*grid)] for k,(lo,hi) in enumerate(m['relative_lower_left_bounds_mm'])]} for m in opts] for family,opts in modes.items()}
for opts in converted.values():
    for m in opts:m['integer_world_lower_left_bounds']=[[math.ceil((F(lo)-origin[k])*grid),math.floor((F(hi)-origin[k])*grid)] for k,(lo,hi) in enumerate(m['lower_left_bounds'])]
converted_rectangles={family:[{**m,'rectangles':[{**r,'outward_offsets_grid':[math.floor(F(v)*grid) if i<2 else math.ceil(F(v)*grid) for i,v in enumerate(r['exact_affine_bounds_mm'])]} for r in m['rectangles']]} for m in opts] for family,opts in rectangles.items()}
unary=[];removed=[];max_activity=0;max_error=F(0);planes=0
source_regions=load(REG/'source-region-audit/rounded-regions.json')
source_templates=[{'geometry':gid,'regions':[{k:v for k,v in r.items() if k!='geometry'} for r in source_regions if r['geometry']==gid]} for gid in range(10)]
for old_template in source_templates:
    regions=[]
    for old in old_template['regions']:
        polygon=[tuple(map(F,v)) for v in old['hull_vertices']]
        region={k:old[k] for k in ['region','hull_vertices']};region['planes']=[]
        for edge,(a,b) in enumerate(zip(polygon,polygon[1:]+polygon[:1])):
            dx,dy=b[0]-a[0],b[1]-a[1];den=max(abs(dx),abs(dy));assert den>0
            normal=[dy/den,-dx/den];raw=[round(n*scale) for n in normal]
            error=sum(abs(n-F(c,scale))*limit for n,c,limit in zip(normal,raw,envelope));rhs=sum(n*(x-o) for n,x,o in zip(normal,a,origin))
            divisor=math.gcd(*map(abs,raw));assert divisor>0
            coefficients=[v//divisor for v in raw];upper=math.floor((rhs-error-epsilon)*scale*grid)//divisor
            activity=sum(abs(c)*int(limit*grid) for c,limit in zip(coefficients,envelope));assert activity<2**53 and abs(upper)<2**53
            max_activity=max(max_activity,activity);max_error=max(max_error,error);planes+=1
            region['planes'].append({'edge':edge,'exact_infinity_normal':[str(n) for n in normal],'normalization_denominator':str(den),'unreduced_coefficients':raw,'divisor':divisor,'coefficients':coefficients,'upper':upper,'rounding_error_bound_mm':str(error)})
        regions.append(region)
    unary.append({'geometry':old_template['geometry'],'regions':regions})
for name,data in [('family-modes.json',converted),('mode-rectangles.json',converted_rectangles),('unary-templates.json',unary),('removed-regions.json',removed)]:write(OUT/name,data)
for name in ['instances.json','inventory.json']:shutil.copyfile(REG/name,OUT/name)
for name in ['components.json','component-pairs.json']:shutil.copyfile(PRIOR/'rigid-rectangle-preflight'/name,OUT/name)
elapsed=time.perf_counter()-started
inputs=[Path(__file__)]+[REG/n for n in ['plan.json','checks.json','family-modes.json','instances.json','inventory.json','source-region-audit/plan.json','source-region-audit/checks.json','source-region-audit/rounded-regions.json']]+[PACKET/n for n in ['translation-domain.json','audit/plan.json','audit/checks.json']]+[PRIOR/'rigid-rectangle-preflight'/n for n in ['plan.json','checks.json','mode-rectangles.json','components.json','component-pairs.json','audit-v3/plan.json','audit-v3/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Convert the freshly source-certified movable-packet relative hulls to local(0,2100)mm,0.01mm positions and exact rational infinity-normalized edge coefficients rounded at scale100000. Charge worst-case normal error over absolute local coordinates1600x1000mm, including negative Y, plus1e-7mm inset. Preserve every source mode and region. Convert both relative and world-coordinate mode domains; preserve the separately source-audited shared packet translation limits. Outward-round all original rigid component rectangles and require0.23mm different-owner spacing. Independently verify every implication before modeling. No fixed-cog capacity or source region is reused.','grid_units_per_mm':grid,'normal_scale':scale,'world_origin_mm':[str(v) for v in origin],'local_domain_envelope_mm':[str(v) for v in envelope],'plane_inset_mm':str(epsilon),'rectangle_gap_grid':23,'algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'source_validation_reserve_seconds':4,'retry_permitted':False,'solver_calls':0,'new_model_created':False})
result={'passed':True,'seconds':elapsed,'retained_cached_regions':sum(len(t['regions']) for t in unary),'removed_cached_regions':len(removed),'integer_planes':planes,'source_mode_options':80,'shared_packet_translation_variables':2,'packet_shift_bounds_grid':packet_domain['shift_bounds_grid'],'count_capacity_tables_used':False,'maximum_integer_plane_activity':max_activity,'maximum_normal_error_bound_mm':float(max_error),'grid_units_per_mm':grid,'normal_scale':scale,'source_region_hulls_unchanged':True,'new_model_created':False,'solver_calls':0,'native_calls':0,'independent_audit_required':True,'H5_complete':False};write(OUT/'checks.json',result);print(result)
