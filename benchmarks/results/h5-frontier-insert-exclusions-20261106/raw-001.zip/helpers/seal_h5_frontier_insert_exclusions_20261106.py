from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-frontier-insert-exclusions-20261106';OUT=ROOT/'benchmarks/results'/NAME
INS=ROOT/'output/h5-first57-frontier-insert-bounds-20261106';JOINT=ROOT/'output/h5-first57-frontier-joint-distributions-20261106';SYNC=ROOT/'output/h5-resumed-frontier-main-sync-20261106'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
ins=load(INS/'audit/checks.json');joint=load(JOINT/'audit/checks.json')
assert ins['passed'] and len(ins['choices'])==20 and ins['new_site_choices_excluded']==0
assert joint['passed'] and joint['new_fixed29_choices_excluded']==15 and joint['remaining_fixed29_choices']==72 and joint['complete_distributions_verified']==21738
assert load(SYNC/'receipt.json')['new_main']=='8a76582845da2c8bc381b0741fa3f0add10c92fb'
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py';tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104','h5-source-polygons-and-joint-frontier-20261104','h5-mandatory-clique-exclusions-20261104','h5-full-frontier-proofs-20261106']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
folders=[INS,JOINT,SYNC]+[ROOT/'output'/f'h5-first57-{stem}-process-20261106' for stem in ['frontier-insert-bounds','frontier-joint-distributions']]
for folder in folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_frontier_insert*20261106.py','*h5_frontier_distribution*20261106.py','*h5_frontier_joint*20261106.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-frontier-insert-exclusions-report-20261106.md','push_h5_resumed_frontier_checkpoints_20261106.py',
    'prepare_h5_consistent_insert_bounds_20261104.py','audit_h5_consistent_insert_bounds_20261104.py','prepare_h5_joint_clique_distributions_20261104.py','audit_h5_joint_clique_distributions_20261104.py']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for source,name in [(INS/'audit/checks.json','insert-audit.json'),(JOINT/'audit/checks.json','joint-audit.json'),(JOINT/'audit/remaining-fixed29-choices.json','remaining-fixed29-choices.json'),(JOINT/'audit/deferred-large-distributions.json','deferred-large-distributions.json'),(SYNC/'receipt.json','main-sync-receipt.json')]:shutil.copyfile(source,OUT/name)
processes=[load(p/'process.json') for p in folders[-2:]]
assert all(p['exit_code']==0 and p['closed'] and not p['timeout'] and p['complete_process_cap_overrun_seconds']==0 for p in processes)
write(OUT/'process-ledger.json',{'complete_preparation_seconds':sum(p['complete_process_seconds'] for p in processes),'processes':processes,'independent_audit_seconds':[ins['seconds'],joint['seconds']],'placement_solver_calls':0,'native_calls':0})
write(OUT/'next-step.json',{'all_prior_placement_calls_closed':True,'remaining_fixed29_choices':72,'total_fixed29_choices_excluded':383,'deferred_mandatory_choices':5,'larger_bracket_clique_bound_choices':67,
    'next_method':'For the five deferred mandatory-bracket cases, build a new bounded proof tree over the complete source-inner conflict graph. Retain the eight mandatory bracket groups and every certified remaining insert cell. Propagate source-incompatible nodes, then branch over every candidate in a selected mandatory bracket group. At each node a source-certified insert conflict-clique cover below eight proves contradiction. A complete branch partition plus independently replayed leaf certificates may exclude the continuous choice. Preserve unresolved graph selections, complete partial trees and time caps without claiming exclusion. Do not rerun or extend the previous exhaustive-distribution processes or any placement solver call.',
    'survivors':'output/h5-first57-frontier-joint-distributions-20261106/audit/deferred-large-distributions.json','bracket_geometry':'output/h5-first57-full-frontier-cliques-20261104','bracket_consistency':'output/h5-first57-frontier-clique-consistency-20261104','insert_geometry':'output/h5-first57-frontier-insert-bounds-20261106',
    'tree_proof_prepared':False,'whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'new_continuous_choices_excluded':15,'remaining_fixed29_choices':72,'total_fixed29_choices_excluded':383,'original_fixed29_choices':455,
    'insert_cases_verified':20,'mandatory_insert_pair_certificates':22618,'insert_clique_pair_certificates':11457,'complete_distributions_verified':21738,'ordered_removals_verified':375801,'strict_source_pair_checks':1717058,
    'deferred_large_cases':5,'placement_solver_calls':0,'native_calls':0,'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-frontier-insert-exclusions-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 frontier insert exclusions:** [independent continuous-cover and joint-distribution proofs]({link}) verify all 20 mandatory-bracket cases, then completely enumerate 21,738 eight-insert-group selections for the 15 cases within the frozen per-case limit. All selections contradict: 375,801 ordered removals and 1,717,058 strict source-inner pair checks. Fifteen fixed29/cog arrangements are excluded continuously, leaving 72 (383 of 455 excluded). Five larger cases remain explicitly deferred; no incomplete enumeration is treated as an exclusion. Complete preparations take 0.915583 and 5.521543 s with no overruns or placement/native calls. The prior checkpoints were pushed normally to main at 8a765828, preserving all newer remote files. Full66 checks, 440 whole allocations and H2/H5 remain open at 60%. A compact, independently replayable proof tree for the five deferred cases is next; all prior calls stay closed.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [complete frontier proof](../benchmarks/results/h5-full-frontier-proofs-20261106.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [frontier insert exclusions](../benchmarks/results/{NAME}.md).',1)
a='frontier now has 87 choices (368 of 455 excluded). Insert pruning for the\n20 surviving eight-clique choices is next. All prior calls stay closed.'
b='frontier then has 87 choices. Insert pruning and complete joint-distribution\nproofs exclude another 15, leaving 72 choices (383 of 455 excluded). Five larger\nmandatory-clique cases remain deferred for a compact proof tree; 67 have larger\nbracket-clique bounds. All prior calls stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
