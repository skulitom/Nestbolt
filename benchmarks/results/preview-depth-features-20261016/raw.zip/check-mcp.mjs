// Functional release check against the actual downloaded MCPB, on authored files.
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, readdir, access } from 'node:fs/promises';
import path from 'node:path';
import { startMcp, mcpFolders, inside } from './mcp-client.mjs';
import { readZip, sha256 } from './zip.mjs';

const config=JSON.parse(await readFile(process.argv[2],'utf8'));
const root=config.work, extension=path.join(root,'extension');
await mkdir(extension);
const entries=readZip(await readFile(config.bundle));
for (const [name,entry] of entries) {
  const target=path.resolve(extension,name);
  assert(inside(extension,target));
  await mkdir(path.dirname(target),{recursive:true});
  await writeFile(target,entry.read(),{flag:'wx'});
}
const manifest=JSON.parse(entries.get('manifest.json').read());
assert.equal(manifest.version,'0.2.0-alpha.1');
const folders=await mcpFolders(root);
for(const name of config.fixtures) await writeFile(path.join(folders.workspace,name),await readFile(path.join(config.fixtures_dir,name)),{flag:'wx'});
const client=startMcp({manifest,extension,...folders});
const replies=[];
async function call(name,args) {
  const reply=await client.request('tools/call',{name,arguments:args});
  replies.push({name,args,reply});
  await writeFile(path.join(root,'calls.json'),JSON.stringify(replies,null,2)+'\n');
  assert.equal(reply.isError??false,false);
  return reply.structuredContent??JSON.parse(reply.content.find(p=>p.type==='text').text);
}
try {
  await client.initialize();
  for(const [name,message] of [['uncached-text.lbrn2','re-save text in LightBurn'],['mixed-fixed.lbrn2','group movable artwork separately']]) {
    let error;
    try {await call('import_parts',{paths:[name],library_path:'rejected.json'});} catch(e) {error=String(e);}
    assert(error?.includes(message),error??'Unsupported input unexpectedly accepted');
    await writeFile(path.join(root,name+'.error.txt'),error+'\n');
    await assert.rejects(access(path.join(folders.workspace,'rejected.json')));
  }
  const imported=await call('import_parts',{paths:['lead-group.lbrn2'],library_path:'library.json'});
  assert.equal(imported.part_count,1);
  const request=config.request;
  const nested=await call('nest',{library_path:'library.json',request,out_dir:'nested',time_budget_s:1,seed:0});
  assert.equal(nested.validation.valid,true);
  assert.deepEqual([nested.lead_in.expected_contours,nested.lead_in.reserved_contours,nested.lead_in.flagged_contours],[10,8,2]);
  assert.equal(nested.files.length,3);
  const checked=await call('validate_layout',{library_path:'library.json',request,layout_path:'nested/layout.json'});
  assert.equal(checked.valid,true);assert.deepEqual(nested.lead_in,checked.lead_in);
  const exported=await call('export_layout',{library_path:'library.json',request,layout_path:'nested/layout.json',out_dir:'exported'});
  assert.equal(exported.files.length,3);
  assert.deepEqual(nested.lead_in,exported.lead_in);
  for(const file of exported.files) {
    const content=await readFile(path.join(folders.workspace,file));
    assert.deepEqual(content,await readFile(path.join(folders.workspace,'nested',path.basename(file))));
    if(file.endsWith('.lbrn2')) {assert(content.includes('<leadIn Value="0"/>'));assert(!content.includes('LEADIN'));}
    else {assert(file.includes('-cuts.'));assert(content.includes('LEADIN'));}
  }
  for(const name of config.fixtures) assert.deepEqual(await readFile(path.join(folders.workspace,name)),await readFile(path.join(config.fixtures_dir,name)));
  for(const dir of [folders.cwd,folders.home,folders.scratch]) assert.deepEqual(await readdir(dir),[]);
  for(const [name,entry] of entries) assert.equal(sha256(await readFile(path.join(extension,name))),sha256(entry.read()));
  await writeFile(path.join(root,'checks.json'),JSON.stringify({all_checks_pass:true,version:manifest.version,
    validation:checked,lead_in:nested.lead_in,exported_files:exported.files,
    rejected_fixtures:2,inputs_unchanged:true,extension_unchanged:true,repeat_export_byte_identical:true,
    other_owned_folders_empty:true,benchmark_or_quality_claim:false},null,2)+'\n');
} finally {await client.stop();}
console.log('Actual downloaded MCPB: two explicit repair errors, rigid LightBurn groups, lead sidecars and repeated exports pass.');
