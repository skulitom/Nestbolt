"""Independent byte-edge checks, complete implication replay and source-area readback."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_horizontal_segment_areas_20261109 import horizontal_segment_areas
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-insert-reference-frontier-20261109';OUT=BASE/'audit'
QUERY=ROOT/'output/h5-complete-insert-reference-20261109/reconciliation';PRE=ROOT/'output/h5-fixed29-complete-row-preflight-20261109';FRONT=ROOT/'output/h5-fixed29-conditional-frontier-20261108';OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108';COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();bindings={};seen=set()
for folder in [BASE,QUERY,PRE/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for name,h in load(folder/'plan.json')['inputs'].items():
        if name not in seen:assert digest(ROOT/name)==h;seen.add(name)
        bindings[name]=h
for p in [Path(__file__),ROOT/'output/h5_horizontal_segment_areas_20261109.py',ROOT/'output/h5-horizontal-segment-area-controls-20261109/checks.json',ROOT/'output/h5-horizontal-segment-area-controls-20261109/plan.json',OLD/'stock-cover.json']+list(BASE.glob('*.json')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
assert load(ROOT/'output/h5-horizontal-segment-area-controls-20261109/checks.json')['passed']
write(OUT/'plan.json',{'inputs':bindings,'method':'Derive every insert seed directly from all3512 complete insert-query results. Each current insert cell is its own query; no representative subset transfer is used. Verify root cliques with individual source adjacency bytes and source self-collision witnesses. Replay every candidate in every simultaneous count round, not only listed removals. Reconstruct every retained current node sweep from original closed source covers and every alias component, independently of producer precomputed rectangles. Horizontal interval-tree areas must exactly reproduce vertical-prefix producer bounds. Both complete original scopes remain represented, whether excluded or open.'})
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um'];allqueries=load(QUERY/'query-results.json');results=[];self_checks=edges=implications=source_sweeps=0
for summary in load(BASE/'case-results.json'):
    index=summary['refinement_index'];saved=load(BASE/f'choice-{index:02d}-frontier.json');data=load(PRE/f'choice-{index:02d}.json');graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');N=len(nodes);width=(N+7)//8;raw=(graph/'conflicts.bin').read_bytes();assert len(raw)==N*width
    previous=load(FRONT/f'choice-{index:02d}-frontier.json');original=load(ROOT/f'benchmarks/results/h5-closure-fixed-point-20261109/choice-{index:02d}-frontier.json')['remaining_current_positions'];assert saved['original_active_positions']==original and set(original)<=set(data['active_current_positions'])
    for p,node in enumerate(nodes):
        l,b,r,t=node['bounds_um'];component=geometries[node['geometry']]['inner_rectangles_um'][previous['source_self_collision_components'][p]]
        assert component[2]-component[0]>r-l and component[3]-component[1]>t-b;self_checks+=1
    rows=[int.from_bytes(raw[p*width:(p+1)*width],'little')|(1<<p) for p in range(N)];cliques=[]
    for family,groups in enumerate(load(graph/'root-covers.json')):
        covered=set();masks=[]
        for group in groups:
            assert len(set(group))==len(group) and all(nodes[p]['family']==family for p in group)
            for p in group:
                for q in group:
                    assert p==q or raw[p*width+q//8]>>(q%8)&1,(index,p,q)
                    edges+=p!=q
            covered.update(group);masks.append(sum(1<<p for p in group))
        assert covered=={p for p,node in enumerate(nodes) if node['family']==family};cliques.append(masks)
    queries={r['insert_current_position']:r for r in allqueries if r['refinement_index']==index};insert_positions=[p for p in original if nodes[p]['family']==1];assert set(queries)==set(insert_positions)
    causes=[]
    for qi,p in enumerate(insert_positions):
        row=queries[p];assert row['query_index']==qi;fails=[k for k,(value,need) in enumerate(zip(row['family_and_joint_area_upper_um2'],[319992000000,138593000000,458585000000])) if value<need]
        if fails:causes.append({'current_position':p,'query_index':qi,'failing_area_indices':fails})
    assert causes==saved['seed_exclusions']==load(QUERY/f'choice-{index:02d}-exclusions.json')
    active=sum(1<<p for p in original)&~sum(1<<r['current_position'] for r in causes);rounds=saved['clique_rounds'];assert 1<=len(rounds)<=8
    for iteration,round in enumerate(rounds):
        assert round['round']==iteration
        expected=[]
        for p in original:
            if not active>>p&1:continue
            companions=active&~rows[p];upper=[sum((bits&companions)!=0 for bits in groups) for groups in cliques];need=[8-int(nodes[p]['family']==0),8-int(nodes[p]['family']==1)]
            if upper[0]<need[0] or upper[1]<need[1]:expected.append({'current_position':p,'remaining_family_upper_counts':upper,'required_remaining_counts':need})
        assert round['removed']==expected
        if not expected:assert iteration==len(rounds)-1
        active&=~sum(1<<r['current_position'] for r in expected);implications+=len(expected)
    if len(rounds)<8:assert not rounds[-1]['removed']
    retained=[p for p in original if active>>p&1];assert saved['remaining_current_positions']==retained
    source_covers=load(COVER/f'choice-{index:02d}-covers.json');bindings[(COVER/f'choice-{index:02d}-covers.json').relative_to(ROOT).as_posix()]=digest(COVER/f'choice-{index:02d}-covers.json')
    regions=[set(),set()]
    for p in retained:
        node=nodes[p];geometry=geometries[node['geometry']]
        for box in source_covers[p]['remaining_closed_anchor_boxes_um']:
            for component in geometry['all_alias_component_outer_rectangles_um']:
                rectangle=(max(stock[0],box[0]+component[0]),max(stock[1],box[1]+component[1]),min(stock[2],box[2]+component[2]),min(stock[3],box[3]+component[3]))
                if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:regions[node['family']].add(rectangle)
                source_sweeps+=1
    regions=[sorted(group) for group in regions];assert saved['family_component_regions_um']==[[list(r) for r in group] for group in regions]
    areas=horizontal_segment_areas(*regions,data['fixed_forbidden_clearance_regions_um']);counts=[sum(bool(bits&active) for bits in groups) for groups in cliques];required=[319992000000,158392000000,478384000000];failures=[k for k,(area,need) in enumerate(zip(areas,required)) if area<need];excluded=bool(failures) or counts[0]<8 or counts[1]<8
    expected={'refinement_index':index,'empty_sites':data['empty_sites'],'active_nodes_before':len(original),'conditional_seed_exclusions':len(causes),'additional_clique_exclusions':sum(len(r['removed']) for r in rounds),'remaining_current_nodes':len(retained),'remaining_bracket_nodes':sum(nodes[p]['family']==0 for p in retained),'remaining_insert_nodes':sum(nodes[p]['family']==1 for p in retained),'global_clique_upper_counts':counts,'family_and_joint_area_upper_um2':areas,'required_family_and_joint_area_lower_um2':required,'failing_area_indices':failures,'provisional_fixed_scope_excluded':excluded}
    assert expected==summary;results.append({**expected,'fixed_scope_excluded':excluded});print(results[-1],flush=True)
process=load(ROOT/'output/h5-complete-insert-reference-frontier-process-20261109/process.json');assert process['passed'] and process['closed']
charge=load(BASE/'plan.json')['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'additional-source-bindings.json',bindings)
write(OUT/'case-results.json',results);write(OUT/'remaining-cases.json',[r for r in results if not r['fixed_scope_excluded']])
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'complete_scopes':2,'source_self_collision_checks':self_checks,'directed_root_clique_edges_verified':edges,'complete_conditional_seed_exclusions':sum(r['conditional_seed_exclusions'] for r in results),'additional_clique_implications_verified':implications,'retained_original_source_component_sweeps':source_sweeps,'exact_global_area_bounds_verified':6,'new_fixed_scope_exclusions':sum(r['fixed_scope_excluded'] for r in results),'remaining_fixed29_cases':sum(not r['fixed_scope_excluded'] for r in results),'complete_preparation_seconds_if_consumed':charge,'common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'whole_allocations_remaining':440,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
