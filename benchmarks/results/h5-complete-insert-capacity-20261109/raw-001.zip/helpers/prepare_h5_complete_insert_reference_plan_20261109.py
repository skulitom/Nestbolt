"""Freeze every current insert reference and every certified possible-node record."""
from pathlib import Path
from hashlib import sha256
import json, time
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'output/h5-complete-insert-reference-20261109'
PARENT = ROOT/'benchmarks/results/h5-closure-fixed-point-20261109'
OLD = ROOT/'output/h5-complete-closure-plan-20261109'
PRE = ROOT/'output/h5-fixed29-complete-row-preflight-20261109'
load = lambda p: json.loads(p.read_bytes())
def write(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')
OUT.mkdir()
started = time.perf_counter()
assert load(PARENT/'archive-checks.json')['passed']
assert load(PARENT/'checks.json')['combined_clique_and_conditional_fixed_point']
inputs = [Path(__file__),PARENT/'archive-checks.json',PARENT/'checks.json',PARENT/'global-exact-case-results.json',OLD/'plan.json',OLD/'checkpoint-audit/checks.json',OLD/'checkpoint-audit/source-bindings.json',ROOT/'output/h5-block-query-projection-controls-20261109/checks.json',ROOT/'output/h5-weighted-query-mask-controls-20261109/checks.json',ROOT/'output/h5-weighted-query-mask-controls-20261109/source-bindings.json',ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/geometries.json',ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json']
geometries = load(ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/geometries.json')
tasks = []; cases = []
global_results = {r['refinement_index']:r for r in load(PARENT/'global-exact-case-results.json')}
for case in [1,9]:
    source = PRE/f'choice-{case:02d}.json'; data = load(source)
    graph = ROOT/data['graph']; nodes = load(graph/'nodes.json'); count = len(nodes)
    raw = (graph/'conflicts.bin').read_bytes(); width = (count+7)//8; assert len(raw) == count*width
    frontier = PARENT/f'choice-{case:02d}-frontier.json'
    active = load(frontier)['remaining_current_positions']; active_mask = sum(1<<p for p in active)
    witnesses = ROOT/f'output/h5-fixed29-conditional-frontier-20261108/choice-{case:02d}-frontier.json'
    components = load(witnesses)['source_self_collision_components']
    positions = [p for p in active if nodes[p]['family']==1]
    assert len(positions)==(1683 if case==1 else 1829)
    rows = []; self_witnesses = []
    for p in positions:
        node = nodes[p]; box = node['bounds_um']; comp = geometries[node['geometry']]['inner_rectangles_um'][components[p]]
        assert box[2]-box[0]<comp[2]-comp[0] and box[3]-box[1]<comp[3]-comp[1]
        rows.append(hex((int.from_bytes(raw[p*width:(p+1)*width],'little')|(1<<p))&active_mask))
        self_witnesses.append([p,components[p]])
    lower = global_results[case]['required_family_and_joint_area_lower_um2']
    assert lower[:2]==[319992000000,158392000000] and lower[2]==sum(lower[:2])
    insert_minimum = lower[1]//8; assert 8*insert_minimum==lower[1]
    required = [lower[0],7*insert_minimum,lower[0]+7*insert_minimum]
    query = {'refinement_index':case,'empty_sites':data['empty_sites'],'graph':data['graph'],'current_nodes':count,'active_current_positions':active,'query_family':'insert','insert_reference_positions':positions,'required_representatives':positions,'representative_active_forbidden_rows_hex':rows,'node_regions':[r for r in data['node_regions'] if active_mask&(1<<r['current_position'])],'self_collision_witness_components':self_witnesses,'required_other_family_and_joint_area_um2':required}
    write(OUT/f'choice-{case:02d}-queries.json',query)
    inputs.extend([source,graph/'nodes.json',graph/'conflicts.bin',frontier,witnesses,OLD/f'choice-{case:02d}-atoms.json'])
    grouped=[[],[]]
    for spec in load(OLD/'plan.json')['closure_batches']:
        if spec['refinement_index']!=case:continue
        folder=OLD/f"closure-batch-{spec['batch_index']:02d}"
        assert load(folder/'audit/checks.json')['passed']
        inputs.extend([folder/'plan.json',folder/'closures.json',folder/'audit/checks.json',folder/'audit/source-bindings.json'])
        for key,possible,prior in load(folder/'closures.json'):
            grouped[spec['family']].append([key,possible,hex(int(possible,16)&active_mask)])
    for family in range(2):
        assert len({r[0] for r in grouped[family]})==len(grouped[family])
        write(OUT/f'choice-{case:02d}-family-{family}-possible-nodes.json',grouped[family])
        for first in range(0,len(grouped[family]),4096):
            tasks.append({'batch_index':len(tasks),'refinement_index':case,'family':family,'first':first,'stop':min(first+4096,len(grouped[family]))})
    cases.append({'refinement_index':case,'active_nodes':len(active),'insert_references':len(positions),'possible_node_records':list(map(len,grouped)),'required_other_family_and_joint_area_um2':required})
for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
    folder=ROOT/piece['folder'];inputs.extend([folder/'atoms.json',folder/'audit/checks.json'])
plan={'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'method':'Cover EVERY active insert reference directly, without representative subsampling. Each selected insert leaves8brackets+7inserts. Verify source self collision and raw graph forbidden rows. Reuse all original certified possible covering-node sets P, restrict them to current active masks and project against the complete insert query rows. Every physical signature and family remains represented. These P sets are conservative covers for arbitrary new queries although originally derived from bracket signatures. No geometric atlas or bracket fixed-point run is repeated. Every projection batch requires independent forbidden-intersection versus allowed-union verification before full weighted area evaluation.','projection_batches':tasks,'projection_producer_cap_seconds':30,'projection_auditor_cap_seconds':30,'memory_bytes':2**31,'inherited_numeric_preparation_seconds':load(PARENT/'checks.json')['complete_preparation_seconds_if_consumed'],'optimizer_calls':0,'retry_permitted':False,'common_line_holes_reserved':True}
write(OUT/'plan.json',plan);write(OUT/'case-summary.json',cases)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'complete_cases':2,'complete_insert_references':sum(c['insert_references'] for c in cases),'possible_node_records':sum(sum(c['possible_node_records']) for c in cases),'projection_batches':len(tasks),'independent_audit_pending':True,'optimizer_calls':0})
print(cases);print(load(OUT/'checks.json'))
