"""Seal complete direct insert-reference capacity and audited geometry frontier."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
original=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=original[:original.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-complete-insert-capacity-20261109'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-complete-insert-reference-20261109';F=ROOT/'output/h5-complete-insert-reference-frontier-20261109/audit';D=BASE/'reconciliation'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-closure-fixed-point-20261109'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['complete_conditional_seed_exclusions']==18 and front['remaining_fixed29_cases']==2 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,F.parent,ROOT/'output/h5-insert-all-projection-batches-20261109',ROOT/'output/h5-all-insert-area-audits-20261109']+[ROOT/'output'/(r['stage']+'-process-20261109') for r in load(D/'process-summary.json')]+[ROOT/'output'/('h5-complete-insert-reference-'+name+'-process-20261109') for name in ['reconciliation','frontier','frontier-audit']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*insert*20261109.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_complete_insert_capacity_checkpoint_20261109.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"load(F/'source-bindings.json').items()":"load(F/'additional-source-bindings.json').items()",
}
for before,after in changes.items():assert before in prefix,before;prefix=prefix.replace(before,after)
exec(prefix)
processes=load(D/'process-summary.json')
for name in ['reconciliation','frontier','frontier-audit']:
    label='h5-complete-insert-reference-'+name;p=load(ROOT/'output'/(label+'-process-20261109')/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
    processes.append({'stage':label,'passed':True,'closed':True,'active_processes':0,'complete_seconds':p['complete_seconds'],'newly_charged_here':name!='frontier-audit'})
assert len(processes)==112
inherited=load(PARENT/'process-summary.json')+load(PARENT/'inherited-process-summary.json');assert len(inherited)==479 and all(p['closed'] and p['active_processes']==0 for p in inherited)
write(OUT/'process-summary.json',processes);write(OUT/'inherited-process-summary.json',inherited)
copies=[(F/'checks.json','frontier-audit.json'),(F/'case-results.json','frontier-case-results.json'),(F/'remaining-cases.json','remaining-cases.json'),(D/'checks.json','complete-query-reconciliation.json'),(D/'case-results.json','complete-query-case-results.json'),(D/'query-results.json','all3512-insert-query-results.json'),(BASE/'plan.json','complete-insert-plan.json'),(BASE/'case-summary.json','preflight-cases.json'),(BASE/'preflight-audit/checks.json','source-preflight-audit.json'),(BASE/'area-plan/plan.json','complete-area-plan.json'),(ROOT/'output/h5-insert-all-projection-batches-20261109/checks.json','all24-projection-batches.json'),(ROOT/'output/h5-all-insert-area-audits-20261109/checks.json','all56-scalar-audits.json')]
for index in [1,9]:copies.extend([(F.parent/f'choice-{index:02d}-frontier.json',f'choice-{index:02d}-frontier.json'),(D/f'choice-{index:02d}-exclusions.json',f'choice-{index:02d}-insert-exclusions.json')])
for source,name in copies:shutil.copyfile(source,OUT/name)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42547117998','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='2ae15d964798b097284abaefe7e0d143a0de1905';write(OUT/'main-ci-at-review.json',ci)
queries=load(D/'checks.json');preflight=load(BASE/'preflight-audit/checks.json');cases=load(F/'case-results.json');total=front['complete_preparation_seconds_if_consumed']
write(OUT/'checks.json',{**front,**archive,'passed':True,'complete_insert_references':3512,'conservative_insert_conditional_bounds':10536,'possible_node_records_verified':87484,'query_memberships_verified':155286888,'new_processes_closed':112,'inherited_processes_closed':479,'all591_processes_closed':True,'remaining_current_nodes':8551,'completion_percent':60,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime)})
proposal='The eighteen insert removals change the active masks under the previously closed bracket-conditional bound, so a new coupled restriction pass is justified. Freeze a complete combined set of all3138 bracket representative queries and all3512 insert direct queries. Both existing result sets share the same baseline active masks8569: bracket signatures are in output/h5-incremental-closure-20261109/producer/choice-NN-signatures.json; insert signatures are in output/h5-complete-insert-reference-20261109/projection-batch-NN/projected-signatures.json. Their original physical keys match the same certified possible-node sets P. Reproject P under the new8551 masks, or use exact unchanged-intersection carry-forward; apply each reference family own required companion areas. Bracket deficits transfer only through the certified original graph-row mapping, insert deficits directly. Independently verify complete full physical loss sums for all6650 queries/19950 bounds, all current targets and every simultaneous clique implication. Bound any further complete rounds in advance and stop at a genuine joint fixed point or declared cap. Do not repeat the old unchanged bracket-only call, originalP construction or source atlas. No combined preflight or new round is prepared. Preserve full preparation charges; no optimizer or timed-gate acceptance from this lineage.'
write(OUT/'next-step.json',{'status':'complete_insert_reference_proof_removes18cells_both_cases_open','proposal':proposal,'combined_query_stage_prepared':False,'authoritative_current_masks':'output/h5-complete-insert-reference-frontier-20261109/choice-{01,09}-frontier.json remaining_current_positions','current_graph_positions_not_recompacted':True,'consumed_preparation_seconds':total,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'whole_allocations_remaining':440,'H5_complete':False})
table='\n'.join(f"| {r['empty_sites']} | {r['conditional_seed_exclusions']} | {r['remaining_current_nodes']} | {r['remaining_bracket_nodes']} / {r['remaining_insert_nodes']} | {r['family_and_joint_area_upper_um2'][2]/1e6:,.6f} |" for r in cases)
passed=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
report=f'''# Complete insert-reference capacity — 2026-11-09

**All 3,512 active insert references are independently checked; 18 more insert-position cells are excluded.**
The remaining fixed29 choices `[0,5,10]` and `[5,10,11]` still have 8,551 current
nodes. Existing 453/455 whole-choice exclusions stand, including 428 at zero
clearance. H2/H5 remain open at **60% completed milestone weight**.

## Complete new reference family

The [preceding bracket proof](h5-closure-fixed-point-20261109.md) reached a fixed
point. This proof covers a different complete reference family: all 1,683 and
1,829 active insert cells in the two cases. Selecting an insert leaves eight
brackets and seven inserts, requiring **319,992 / 138,593 / 458,585 mm²** of
bracket, insert and joint occupied area. Every insert is its own query;
no representative subsampling or dominance transfer is used.

[The source preflight]({NAME}/source-preflight-audit.json) independently checks
every reference identity, source self-collision witness and
{preflight['raw_adjacency_memberships_checked']:,} raw adjacency memberships.
It retains the original graph array positions, distinct from stable source labels.
Every original certified possible covering-node set P is restricted by the
current mask. Actual source coverage remains a subset of P for these new query
rows. The source area partition and original P construction are not repeated.

[All 24 frozen projection batches]({NAME}/all24-projection-batches.json) verify
all 87,484 possible-node records and 155,286,888 query memberships. The producer
intersects forbidden-query columns using eight-node tables. The independent
auditor reads rows as bytes, forms allowed-query columns, unions four-node
tables and complements. Every record is checked, with its original physical key.

## Complete capacities and new frontier

The two complete case producers sum weighted uncovered masks using the previously
controlled binary digit-plane method. [All 56 scalar audit batches]({NAME}/all56-scalar-audits.json)
instead sum positive covered areas from every original physical piece. Every
one of **10,536 conditional bounds** matches. [The reconciliation]({NAME}/complete-query-reconciliation.json)
requires all 3,512 distinct current insert references, every projection range
and every scalar audit range. [All query results]({NAME}/all3512-insert-query-results.json)
and exact exclusion causes are preserved.

| Omitted sites | New insert cells excluded | Remaining nodes | Brackets / inserts | Global joint upper (mm²) |
|---|---:|---:|---:|---:|
{table}

The [final frontier audit]({NAME}/frontier-audit.json) derives every seed from the
complete insert-query results. It rechecks 8,914 source self witnesses and
1,848,482 directed clique edges; no additional clique removal follows. All
21,662 retained source-component sweeps and six exact swept-envelope union
areas replay independently. The global joint bounds remain above 478,384 mm²,
so neither whole arrangement is excluded.

These bounds reserve common-line outer envelopes with holes retained in
cutting geometry. All 90 cutting holes remain. The possible-node projection is
a conservative cover, not exact physical coverage or a feasible placement.
No ordinary part-in-hole or whole-allocation exclusion follows.

## Process closure and next step

[All 112 new numerical processes]({NAME}/process-summary.json) pass and close
with zero descendants, as do the [479 inherited processes]({NAME}/inherited-process-summary.json).
The four inherited failed attempts remain preserved. New workers retain CCD1
logical processors 16–31, one BLAS/OMP/MKL thread, a 30 s hard time cap and
a 2 GiB Windows Job cap. Consumed preparation is **{total:.6f} s**.
No optimizer, timer reset or timed H5 pass follows.

[Next]({NAME}/next-step.json), combine the complete bracket and insert conditional
bounds under the newly reduced masks. The insert removals changed inputs to
the bracket proof, so its previous fixed point need not survive. A combined
stage must cover all 6,650 original reference queries and their current targets,
with each family's own companion-area requirement. No combined stage is prepared.

All 440 whole-job allocations, full66 source/native/material validation,
production integration and the H5 matrix remain open. The valid64 layout stays
best; the separate eight older first32 and 680 five-column cores stay closed.
Product, README and releases are unchanged.

The prior fixed-point checkpoint is committed as `3642e620`; main remains
`2ae15d96`. [Its CI at review]({NAME}/main-ci-at-review.json) has {passed} passed / {live}
live jobs. Both evidence commits await the ordinary push gate.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve the complete evidence chain.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-09 H5 complete insert-reference capacity:** [full source/projection/scalar/frontier audits]({{link}}) cover all 3,512 active insert cells directly, all 87,484 certified possible-node records, 155,286,888 projected query memberships and 10,536 conditional area bounds. Eight case01 and ten case09 insert cells are excluded; no additional clique removals follow. Both fixed29 choices remain with 8,551 current nodes. All 112 new and 479 inherited processes are terminal; inherited failures remain preserved. Consumed preparation {total:.6f} s cannot reset or open an optimizer. Next combine all 3,138 bracket and 3,512 insert queries under the changed masks; no combined stage is prepared. All 440 allocations/full66/H5 remain open, valid64 stays best, H2/H5 remain open at 60%, common-line holes stay reserved, and product/README/releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8');start=content.index('Latest H5 evidence:');end=content.index('\nThe earlier fixed 13-cog construction',start)
intro=f'''Latest H5 evidence: [complete insert-reference capacity](../benchmarks/results/{NAME}.md).
All 3,512 active insert references pass complete independent source and area
checks. All 87,484 possible-node records, 155,286,888 projected query memberships
and 10,536 conditional bounds are verified. Eight insert cells in [0,5,10]
and ten in [5,10,11] are excluded, leaving 8,551 nodes across both open choices.
No additional clique removal follows; six exact global swept-envelope areas
still leave both arrangements unresolved. The 453/455 prior exclusions stand,
including 428 at zero clearance. Common-line holes remain reserved, with no
ordinary part-in-hole or whole-allocation claim. All 112 new and 479 inherited
processes close; inherited failures remain preserved. Consumed preparation is
{total:.6f} s, with no optimizer or timer reset permitted. Next combine all
6,650 bracket/insert queries under the changed masks; none is prepared.
All 440 allocations and full66/H5 validation remain open; valid64 stays best.
H2/H5 remain open at 60%. Separate eight older first32 and 680 five-column
cores stay closed. Product, README and releases are unchanged. Prior checkpoint
3642e620 is committed; main 2ae15d96 has {passed} passed/{live} live CI jobs at review.
Both checkpoints await ordinary push.
'''
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(content[:start]+intro+content[end:])
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text\n')
print({'passed':True,'archive':archive,'bindings':len(bindings),'historical_references':len(external),'consumed_preparation_seconds':total,'remaining_nodes':8551,'new_insert_exclusions':18})
