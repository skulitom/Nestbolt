"""Project every certified possible cover in a frozen batch against all inserts."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_block_projected_coverage_atoms_20261109 import forbidden_projection
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-insert-reference-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
batch=int(sys.argv[1]);spec=load(BASE/'plan.json')['projection_batches'][batch]
assert spec['batch_index']==batch and load(BASE/'preflight-audit/checks.json')['passed']
OUT=BASE/f'projection-batch-{batch:02d}';OUT.mkdir();began=time.perf_counter()
case,family=spec['refinement_index'],spec['family'];source=BASE/f'choice-{case:02d}-queries.json';possible=BASE/f'choice-{case:02d}-family-{family}-possible-nodes.json'
data=load(source);project=forbidden_projection(data);records=load(possible)[spec['first']:spec['stop']]
inputs=[Path(__file__),ROOT/'output/h5_block_projected_coverage_atoms_20261109.py',BASE/'plan.json',BASE/'preflight-audit/plan.json',BASE/'preflight-audit/checks.json',source,possible]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'batch':spec,'method':'Project all current possible-node covers in this complete frozen range against every active insert forbidden row. Eight-node block intersections of forbidden-query columns. Preserve original physical signature keys and use only the correct family component.','optimizer_calls':0,'retry_permitted':False})
result=[[key,hex(project(int(current,16))[family])] for key,original,current in records]
write(OUT/'projected-signatures.json',result)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'batch_index':batch,'possible_node_records':len(result),'insert_queries_per_record':len(data['insert_reference_positions']),'independent_audit_pending':True,'optimizer_calls':0})
print(load(OUT/'checks.json'))
