"""Reconcile complete insert projections, scalar area audits, seeds and costs."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-insert-reference-20261109';OUT=BASE/'reconciliation'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(ROOT/'output/h5-all-insert-area-audits-20261109/checks.json')['passed']
assert load(ROOT/'output/h5-insert-all-projection-batches-20261109/checks.json')['passed']
OUT.mkdir();began=time.perf_counter();bindings={};processes=[];cost=load(BASE/'plan.json')['inherited_numeric_preparation_seconds']
def bind(p):
    key=p.relative_to(ROOT).as_posix();h=sha256(p.read_bytes()).hexdigest();assert key not in bindings or bindings[key]==h,key;bindings[key]=h
def verify(folder):
    p=folder/'plan.json';bind(p)
    for name,h in load(p)['inputs'].items():
        if name not in bindings:bind(ROOT/name)
        assert bindings[name]==h,name
def process(label,charge=False):
    global cost
    folder=ROOT/'output'/(label+'-process-20261109');v=load(folder/'process.json');assert v['passed'] and v['closed'] and v['job']['closed'] and v['job']['active_processes']==0
    assert v['job']['job_committed_memory_limit']==2**31
    for p in [folder/'process.json',folder/'opened.json']:bind(p)
    for name,h in load(folder/'opened.json')['inputs'].items():
        if name not in bindings:bind(ROOT/name)
        assert bindings[name]==h,name
    if charge:cost+=v['complete_seconds']
    processes.append({'stage':label,'passed':True,'closed':True,'active_processes':0,'complete_seconds':v['complete_seconds'],'newly_charged_here':charge})
verify(BASE);verify(BASE/'preflight-audit');verify(BASE/'area-plan')
process('h5-complete-insert-reference-plan',True);process('h5-complete-insert-reference-plan-audit');process('h5-insert-area-plan',True)
plan=load(BASE/'plan.json');memberships=records=0
for spec in plan['projection_batches']:
    batch=spec['batch_index'];folder=BASE/f'projection-batch-{batch:02d}';verify(folder);verify(folder/'audit')
    check=load(folder/'audit/checks.json');assert check['passed'];bind(folder/'audit/checks.json');records+=check['possible_node_records_verified'];memberships+=check['query_memberships_verified']
    expected=load(BASE/f"choice-{spec['refinement_index']:02d}-family-{spec['family']}-possible-nodes.json")[spec['first']:spec['stop']]
    assert [r[0] for r in load(folder/'projected-signatures.json')]==[r[0] for r in expected]
    process(f'h5-insert-projection-{batch:02d}',True);process(f'h5-insert-projection-{batch:02d}-audit')
cases=[];queries=[]
for case in [1,9]:
    data=load(BASE/f'choice-{case:02d}-queries.json');bind(BASE/f'choice-{case:02d}-queries.json')
    verify(BASE/f'choice-{case:02d}-areas');process(f'h5-insert-case-{case:02d}-areas',True)
    rows=[]
    for spec in load(BASE/'area-plan/plan.json')['scalar_audit_batches']:
        if spec['refinement_index']!=case:continue
        batch=spec['batch_index'];folder=BASE/f'area-audit-batch-{batch:02d}';verify(folder);assert load(folder/'checks.json')['passed'];bind(folder/'checks.json');bind(folder/'query-results.json')
        batch_rows=load(folder/'query-results.json');assert [r['query_index'] for r in batch_rows]==list(range(spec['first'],spec['stop']))
        rows.extend(batch_rows);process(f'h5-insert-area-audit-{batch:02d}')
    assert [r['insert_current_position'] for r in rows]==data['insert_reference_positions']
    active=set(data['active_current_positions']);causes=[]
    for qi,row in enumerate(rows):
        assert row['query_index']==qi and row['insert_current_position'] in active
        fails=[k for k,(a,b) in enumerate(zip(row['family_and_joint_area_upper_um2'],[319992000000,138593000000,458585000000])) if a<b]
        assert fails==row['failing_area_indices'] and bool(fails)==row['insert_reference_excluded']
        if fails:causes.append({'current_position':row['insert_current_position'],'query_index':qi,'failing_area_indices':fails})
    removed={r['current_position'] for r in causes};remaining=[p for p in data['active_current_positions'] if p not in removed]
    result={'refinement_index':case,'empty_sites':data['empty_sites'],'active_nodes_before':len(active),'complete_insert_references':len(rows),'conservative_area_bounds':3*len(rows),'new_insert_seed_exclusions':len(removed),'remaining_nodes_after_seeds':len(remaining),'remaining_insert_nodes_after_seeds':len(rows)-len(removed),'whole_scope_excluded':len(rows)-len(removed)<8}
    write(OUT/f'choice-{case:02d}-exclusions.json',causes);write(OUT/f'choice-{case:02d}-seed-frontier.json',{**result,'remaining_current_positions':remaining});cases.append(result);queries.extend(rows)
assert records==87484 and len(queries)==3512 and len(processes)==109
bind(Path(__file__))
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconcile every active insert reference, all24 complete projected P ranges, all56 scalar area ranges and all10536 bounds. Recheck source identity, threshold and exact seed lists. No dominance transfer is needed because every insert cell is a direct query. Verify all109 numerical processes terminal; charge preflight, area plan,24projection producers and2complete-area producers once through inherited ledger.'})
write(OUT/'case-results.json',cases);write(OUT/'query-results.json',queries);write(OUT/'process-summary.json',processes)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'complete_cases':2,'complete_insert_references':3512,'conservative_conditional_area_bounds':10536,'possible_node_records_verified':records,'query_memberships_verified':memberships,'new_insert_seed_exclusions':sum(r['new_insert_seed_exclusions'] for r in cases),'remaining_nodes_after_seeds':sum(r['remaining_nodes_after_seeds'] for r in cases),'all109_prior_new_processes_closed':True,'complete_preparation_seconds_before_this_reconciliation':cost,'common_line_holes_reserved':True,'whole_allocations_remaining':440,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'));print(cases)
