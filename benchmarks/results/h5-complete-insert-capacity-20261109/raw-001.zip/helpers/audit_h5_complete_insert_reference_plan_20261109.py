"""Independent raw adjacency-byte rows, source witnesses and complete coverage."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-complete-insert-reference-20261109';OUT=BASE/'preflight-audit'
OLD=ROOT/'output/h5-complete-closure-plan-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
producer=load(ROOT/'output/h5-complete-insert-reference-plan-process-20261109/process.json')
assert producer['passed'] and producer['closed'] and producer['job']['active_processes']==0
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings=dict(plan['inputs'])
for name,h in bindings.items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
for name,h in load(OLD/'checkpoint-audit/source-bindings.json').items():
    if name not in bindings:assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
    else:assert bindings[name]==h,name
geometries=load(ROOT/'output/h5-four-fixed29-current-areas-v3-20261108/geometries.json')
references=memberships=possible_records=0
for case in [1,9]:
    data=load(BASE/f'choice-{case:02d}-queries.json');graph=ROOT/data['graph'];nodes=load(graph/'nodes.json');raw=(graph/'conflicts.bin').read_bytes();width=(len(nodes)+7)//8
    source=load(ROOT/f'output/h5-fixed29-complete-row-preflight-20261109/choice-{case:02d}.json')
    active=load(ROOT/f'benchmarks/results/h5-closure-fixed-point-20261109/choice-{case:02d}-frontier.json')['remaining_current_positions']
    assert data['active_current_positions']==active
    expected=[p for p in active if nodes[p]['family']==1]
    assert data['insert_reference_positions']==data['required_representatives']==expected
    assert data['node_regions']==[r for r in source['node_regions'] if r['current_position'] in set(active)]
    assert data['required_other_family_and_joint_area_um2']==[319992000000,138593000000,458585000000]
    witnesses=dict(data['self_collision_witness_components'])
    for p,row in zip(expected,data['representative_active_forbidden_rows_hex']):
        component=geometries[nodes[p]['geometry']]['inner_rectangles_um'][witnesses[p]];l,b,r,t=nodes[p]['bounds_um']
        assert r-l<component[2]-component[0] and t-b<component[3]-component[1]
        forbidden=0
        for q in active:
            if p==q or raw[p*width+q//8]&(1<<(q%8)):forbidden|=1<<q
            memberships+=1
        assert hex(forbidden)==row;references+=1
    active_mask=sum(1<<p for p in active)
    expected_records=[[],[]]
    for spec in load(OLD/'plan.json')['closure_batches']:
        if spec['refinement_index']!=case:continue
        folder=OLD/f"closure-batch-{spec['batch_index']:02d}"
        for name,h in load(folder/'audit/source-bindings.json').items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
        for key,possible,prior in load(folder/'closures.json'):expected_records[spec['family']].append([key,possible,hex(int(possible,16)&active_mask)])
    for family,expected in enumerate(expected_records):
        records=load(BASE/f'choice-{case:02d}-family-{family}-possible-nodes.json');assert records==expected
        covered=[]
        for task in plan['projection_batches']:
            if task['refinement_index']==case and task['family']==family:covered.extend(range(task['first'],task['stop']))
        assert covered==list(range(len(records)));possible_records+=len(records)
    for p in [BASE/f'choice-{case:02d}-queries.json']+[BASE/f'choice-{case:02d}-family-{f}-possible-nodes.json' for f in range(2)]:bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
assert references==3512 and possible_records==87484
for p in [Path(__file__),BASE/'plan.json',BASE/'case-summary.json']:bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Verify every raw insert-reference forbidden edge through individual bytes plus source self witness, every active insert position, each copied certified P set and exact current restriction, and complete projection batch coverage. Prior conservative-cover proof is hash-verified and applies independently of new query family.'})
result={'passed':True,'seconds':time.perf_counter()-began,'complete_cases':2,'complete_insert_references':references,'raw_adjacency_memberships_checked':memberships,'possible_node_records_verified':possible_records,'projection_batches':len(plan['projection_batches']),'optimizer_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
