"""Scalar positive-area sums for every query in a complete consecutive batch."""
from pathlib import Path
from hashlib import sha256
import json,time,sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-insert-reference-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
batch=int(sys.argv[1]);spec=load(BASE/'area-plan/plan.json')['scalar_audit_batches'][batch];assert spec['batch_index']==batch
case=spec['refinement_index'];process=load(ROOT/f'output/h5-insert-case-{case:02d}-areas-process-20261109/process.json')
assert process['passed'] and process['closed'] and process['job']['active_processes']==0
SOURCE=BASE/f'choice-{case:02d}-areas';OUT=BASE/f'area-audit-batch-{batch:02d}';OUT.mkdir();began=time.perf_counter();bindings=dict(load(SOURCE/'plan.json')['inputs'])
for name,h in bindings.items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
data=load(BASE/f'choice-{case:02d}-queries.json');maps=[{},{}]
for projection in load(BASE/'plan.json')['projection_batches']:
    if projection['refinement_index']==case:
        for key,value in load(BASE/f"projection-batch-{projection['batch_index']:02d}/projected-signatures.json"):maps[projection['family']][int(key,16)]=int(value,16)
indices=list(range(spec['first'],spec['stop']));bits=[1<<qi for qi in indices];areas=[[0,0,0] for _ in indices];physical=0
for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
    if piece['refinement_index']!=case:continue
    for b,i,weight in load(ROOT/piece['folder']/'atoms.json'):
        b=maps[0][int(b,16)];i=maps[1][int(i,16)];joint=b&i;physical+=1
        for bit,values in zip(bits,areas):
            if not b&bit:values[0]+=weight
            if not i&bit:values[1]+=weight
            if not joint&bit:values[2]+=weight
saved=load(SOURCE/'query-results.json')[spec['first']:spec['stop']];assert len(saved)==len(indices);results=[];active=data['active_current_positions']
for qi,values,row in zip(indices,areas,saved):
    p=data['insert_reference_positions'][qi];failures=[k for k,(a,b) in enumerate(zip(values,[319992000000,138593000000,458585000000])) if a<b]
    forbidden=int(data['representative_active_forbidden_rows_hex'][qi],16);allowed=sum(not forbidden&(1<<node) for node in active)
    expected={'refinement_index':case,'insert_current_position':p,'query_index':qi,'family_and_joint_area_upper_um2':values,'failing_area_indices':failures,'provisional_insert_reference_excluded':bool(failures),'allowed_current_nodes':allowed}
    assert row==expected,(qi,row,expected);results.append({**expected,'insert_reference_excluded':bool(failures)})
for p in [Path(__file__),BASE/'area-plan/plan.json',SOURCE/'plan.json',SOURCE/'query-results.json']:bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'batch':spec,'method':'Independent scalar positive sums over every original physical piece, every complete selected insert-query range, each family and their union. Compare all integer upper bounds, thresholds, identities and current allowed-node counts. No binary weighted-counter or producer coalesced-atom output is used.'})
write(OUT/'query-results.json',results)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'batch_index':batch,'refinement_index':case,'insert_queries_verified':len(results),'conservative_area_bounds_verified':3*len(results),'original_physical_entries_checked':physical,'excluded_insert_cells':sum(r['insert_reference_excluded'] for r in results),'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
