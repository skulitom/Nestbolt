"""Sequential one-shot completion of all frozen insert projection producers/audits."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-insert-reference-20261109';OUT=ROOT/'output/h5-insert-all-projection-batches-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'preflight-audit/checks.json')['passed']
tasks=load(BASE/'plan.json')['projection_batches'];assert len(tasks)==24
OUT.mkdir();write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'administrative_runner':True,'complete_projection_batches':24,'numeric_process_caps_seconds':30,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
count=memberships=0
for task in tasks:
    batch=task['batch_index']
    for audit in [False,True]:
        label=f'h5-insert-projection-{batch:02d}'+('-audit' if audit else '');folder=ROOT/'output'/(label+'-process-20261109')
        if batch!=0:
            assert not folder.exists(),label
            wrapper=ROOT/'output'/('run_'+label.replace('-','_')+'_stage_20261109.py')
            r=subprocess.run([sys.executable,str(wrapper)],cwd=ROOT,capture_output=True)
            (OUT/(label+'-stdout.txt')).write_bytes(r.stdout);(OUT/(label+'-stderr.txt')).write_bytes(r.stderr)
            assert r.returncode==0,(label,r.stderr)
        process=load(folder/'process.json');assert process['passed'] and process['closed'] and process['job']['active_processes']==0
        check=BASE/f'projection-batch-{batch:02d}'
        if audit:check=check/'audit'
        result=load(check/'checks.json')
        entry={'utc':datetime.now(timezone.utc).isoformat(),'batch':batch,'case':task['refinement_index'],'family':task['family'],'audit':audit,'complete_seconds':process['complete_seconds'],'passed':True}
        with (OUT/'progress.jsonl').open('a',encoding='utf-8',newline='\n') as f:f.write(json.dumps(entry)+'\n')
        print(entry,flush=True)
        if audit:count+=result['possible_node_records_verified'];memberships+=result['query_memberships_verified']
write(OUT/'checks.json',{'passed':True,'all24_batches_complete':True,'all48_processes_closed':True,'possible_node_records_verified':count,'query_memberships_verified':memberships,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'),flush=True)
