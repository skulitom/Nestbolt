"""Complete all-query insert capacities via exact weighted loss vectors."""
from pathlib import Path
from hashlib import sha256
import json,time,sys
from h5_weighted_query_masks_20261109 import weighted_query_sums
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-insert-reference-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
case=int(sys.argv[1]);assert case in [1,9]
assert load(ROOT/'output/h5-insert-all-projection-batches-20261109/checks.json')['passed']
OUT=BASE/f'choice-{case:02d}-areas';OUT.mkdir();began=time.perf_counter();data=load(BASE/f'choice-{case:02d}-queries.json');maps=[{},{}]
inputs=[Path(__file__),ROOT/'output/h5_weighted_query_masks_20261109.py',BASE/'area-plan/plan.json',BASE/'plan.json',BASE/f'choice-{case:02d}-queries.json',ROOT/'output/h5-weighted-query-mask-controls-20261109/checks.json',ROOT/'output/h5-weighted-query-mask-controls-20261109/source-bindings.json',ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json']
for spec in load(BASE/'plan.json')['projection_batches']:
    if spec['refinement_index']!=case:continue
    folder=BASE/f"projection-batch-{spec['batch_index']:02d}";assert load(folder/'audit/checks.json')['passed'];inputs.extend([folder/'plan.json',folder/'projected-signatures.json',folder/'audit/plan.json',folder/'audit/checks.json'])
    for key,projected in load(folder/'projected-signatures.json'):
        assert int(key,16) not in maps[spec['family']];maps[spec['family']][int(key,16)]=int(projected,16)
atoms={};physical=0
for piece in load(ROOT/'output/h5-projected-partition-block-completion-20261109/proof-slabs.json'):
    if piece['refinement_index']!=case:continue
    folder=ROOT/piece['folder'];assert load(folder/'audit/checks.json')['passed'];inputs.extend([folder/'atoms.json',folder/'audit/checks.json'])
    for b,i,area in load(folder/'atoms.json'):
        key=(maps[0][int(b,16)],maps[1][int(i,16)]);atoms[key]=atoms.get(key,0)+area;physical+=1
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'method':'All current insert-reference queries, sum complete weighted uncovered masks in binary digit planes. Joint uncovered mask is intersection of bracket and insert uncovered masks. Positive capacity equals full physical area minus loss. Merge identical projected signatures only by exact addition.','optimizer_calls':0})
count=len(data['insert_reference_positions']);total=sum(atoms.values());losses=[weighted_query_sums([(b if family==0 else i if family==1 else b&i,area) for (b,i),area in atoms.items()],count) for family in range(3)]
active_mask=sum(1<<p for p in data['active_current_positions']);required=data['required_other_family_and_joint_area_um2'];results=[]
for qi,p in enumerate(data['insert_reference_positions']):
    areas=[total-losses[family][qi] for family in range(3)];failures=[family for family,(a,b) in enumerate(zip(areas,required)) if a<b]
    results.append({'refinement_index':case,'insert_current_position':p,'query_index':qi,'family_and_joint_area_upper_um2':areas,'failing_area_indices':failures,'provisional_insert_reference_excluded':bool(failures),'allowed_current_nodes':(active_mask&~int(data['representative_active_forbidden_rows_hex'][qi],16)).bit_count()})
write(OUT/'query-results.json',results)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'refinement_index':case,'complete_insert_queries':count,'conservative_area_bounds':3*count,'physical_entries':physical,'coalesced_projected_signatures':len(atoms),'provisional_excluded_insert_cells':sum(r['provisional_insert_reference_excluded'] for r in results),'independent_scalar_audits_pending':True,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
