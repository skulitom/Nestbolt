"""Independently project through four-node allowed-query unions."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_block_projected_coverage_atoms_20261109 import allowed_projection
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-insert-reference-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
batch=int(sys.argv[1]);label=f'h5-insert-projection-{batch:02d}';producer=load(ROOT/'output'/(label+'-process-20261109')/'process.json')
assert producer['passed'] and producer['closed'] and producer['job']['active_processes']==0
SOURCE=BASE/f'projection-batch-{batch:02d}';OUT=SOURCE/'audit';OUT.mkdir();began=time.perf_counter();bindings=dict(load(SOURCE/'plan.json')['inputs'])
for name,h in bindings.items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
spec=load(BASE/'plan.json')['projection_batches'][batch];assert spec==load(SOURCE/'plan.json')['batch']
case,family=spec['refinement_index'],spec['family'];data=load(BASE/f'choice-{case:02d}-queries.json');project=allowed_projection(data)
source=load(BASE/f'choice-{case:02d}-family-{family}-possible-nodes.json')[spec['first']:spec['stop']]
saved=load(SOURCE/'projected-signatures.json');assert len(saved)==len(source)
for (key,original,current),row in zip(source,saved):assert row==[key,hex(project(int(current,16))[family])]
for p in [Path(__file__),SOURCE/'plan.json',SOURCE/'projected-signatures.json']:bindings[p.relative_to(ROOT).as_posix()]=sha256(p.read_bytes()).hexdigest()
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently transpose forbidden rows from bytes into allowed-query columns, union four-node block tables and complement. Verify every possible-node record against every insert query, preserving complete frozen range and original physical keys. Producer terminal completion is required before opening.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'batch_index':batch,'possible_node_records_verified':len(saved),'query_memberships_verified':len(saved)*len(data['insert_reference_positions']),'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
