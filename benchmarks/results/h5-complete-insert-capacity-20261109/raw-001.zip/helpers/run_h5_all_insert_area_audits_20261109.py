"""Run all56 scalar audit batches exactly once after both case producers close."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-insert-reference-20261109';OUT=ROOT/'output/h5-all-insert-area-audits-20261109'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
for case in [1,9]:
    p=load(ROOT/f'output/h5-insert-case-{case:02d}-areas-process-20261109/process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
tasks=load(BASE/'area-plan/plan.json')['scalar_audit_batches'];assert len(tasks)==56
OUT.mkdir();write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'administrative_runner':True,'numeric_workers':'All56 frozen complete scalar audit batches, each30s/2GiB, after both full case producers are terminal. Batch00 already consumed.','optimizer_calls':0,'retry_permitted':False})
count=excluded=0
for task in tasks:
    batch=task['batch_index'];label=f'h5-insert-area-audit-{batch:02d}';folder=ROOT/'output'/(label+'-process-20261109')
    if batch!=0:
        assert not folder.exists(),label
        wrapper=ROOT/'output'/('run_'+label.replace('-','_')+'_stage_20261109.py');r=subprocess.run([sys.executable,str(wrapper)],cwd=ROOT,capture_output=True)
        (OUT/(label+'-stdout.txt')).write_bytes(r.stdout);(OUT/(label+'-stderr.txt')).write_bytes(r.stderr);assert r.returncode==0,(label,r.stderr)
    p=load(folder/'process.json');assert p['passed'] and p['closed'] and p['job']['active_processes']==0
    checks=load(BASE/f'area-audit-batch-{batch:02d}/checks.json');assert checks['passed'];count+=checks['insert_queries_verified'];excluded+=checks['excluded_insert_cells']
    entry={'utc':datetime.now(timezone.utc).isoformat(),'batch':batch,'case':task['refinement_index'],'passed':True,'complete_seconds':p['complete_seconds'],'excluded_insert_cells':checks['excluded_insert_cells']}
    with (OUT/'progress.jsonl').open('a',encoding='utf-8',newline='\n') as f:f.write(json.dumps(entry)+'\n')
    print(entry,flush=True)
assert count==3512
write(OUT/'checks.json',{'passed':True,'all56_scalar_audits_complete':True,'all56_processes_closed':True,'complete_insert_queries':count,'conservative_area_bounds':3*count,'excluded_insert_cells':excluded,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
