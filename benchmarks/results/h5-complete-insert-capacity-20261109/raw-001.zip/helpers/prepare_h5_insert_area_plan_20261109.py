"""Freeze all complete insert area producers and scalar independent audit ranges."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-complete-insert-reference-20261109';OUT=BASE/'area-plan'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(ROOT/'output/h5-insert-all-projection-batches-20261109/checks.json')['passed']
OUT.mkdir();began=time.perf_counter();inputs=[Path(__file__),BASE/'plan.json',BASE/'preflight-audit/checks.json',BASE/'preflight-audit/plan.json',ROOT/'output/h5-insert-all-projection-batches-20261109/checks.json'];tasks=[]
for case in [1,9]:
    data=load(BASE/f'choice-{case:02d}-queries.json');inputs.append(BASE/f'choice-{case:02d}-queries.json')
    for first in range(0,len(data['insert_reference_positions']),64):tasks.append({'batch_index':len(tasks),'refinement_index':case,'first':first,'stop':min(first+64,len(data['insert_reference_positions']))})
for spec in load(BASE/'plan.json')['projection_batches']:
    folder=BASE/f"projection-batch-{spec['batch_index']:02d}";assert load(folder/'audit/checks.json')['passed'];inputs.extend([folder/'plan.json',folder/'projected-signatures.json',folder/'audit/plan.json',folder/'audit/checks.json'])
assert len(tasks)==56
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in inputs},'complete_case_producers':[1,9],'scalar_audit_batches':tasks,'case_producer_cap_seconds':30,'audit_batch_cap_seconds':30,'memory_bytes':2**31,'method':'Compute all3512 insert-reference area triples using controlled binary weighted-loss vectors. Independently audit every query in56complete consecutive batches by summing positive covered areas directly from every original physical proof piece. Each audit requires its full case producer terminal success; all56 must pass before exclusion reconciliation.','optimizer_calls':0,'retry_permitted':False})
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'complete_case_producers':2,'complete_insert_queries':3512,'scalar_audit_batches':56,'optimizer_calls':0});print(load(OUT/'checks.json'))
