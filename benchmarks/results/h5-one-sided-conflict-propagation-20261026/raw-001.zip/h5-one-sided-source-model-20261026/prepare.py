"""Remove shared-direction complement definitions while preserving all face ORs."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-shared-direction-source-model-20261026';OUT=ROOT/'output/h5-one-sided-source-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    checks=load(PARENT/'audit/checks.json');assert checks['passed'] and checks['shared_direction_equivalence_verified']
    paths=[PARENT/n for n in ['model.pb','mapping.json','result.json','shared-directions.json','old-direction-projection.json','audit/checks.json','audit/equivalence-proof.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_calls':0,'method':'Remove only101455 negative-direction complement constraints from the independently verified shared-truth parent. Keep every variable, original base,14 area rules,394 physical pair modes,72 hints, positive flag-implies-plane definition and active face OR. Reindex mapping spans exactly. Existential projection is unchanged if every remaining flag use is positive: given any one-sided solution, set each flag to its exact plane truth; false-to-true changes only satisfy additional positive OR literals and the newly enabled own plane is true. The reverse implication is immediate by deleting constraints. Require independent complete occurrence audit and actual import before a separately bounded call.'})
    parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model.pb').read_bytes());assert len(parent.variables)==111710 and len(parent.constraints)==265709
    definitions=load(PARENT/'shared-directions.json');removed=[]
    for r in definitions:
        lo,hi=r['constraint_span'];assert hi==lo+2 and list(parent.constraints[lo].enforcement_literal)==[r['flag']] and list(parent.constraints[lo+1].enforcement_literal)==[-r['flag']-1]
        removed.append(lo+1)
    assert len(removed)==len(set(removed))==101455;drop=set(removed);offset=[0];kept=[]
    for i,c in enumerate(parent.constraints):
        if i not in drop:kept.append(c)
        offset.append(len(kept))
    model=cp_model_pb2.CpModelProto();model.CopyFrom(parent);del model.constraints[:];model.constraints.extend(kept);assert len(model.constraints)==164254
    mapping=load(PARENT/'mapping.json')
    for p in mapping['source_pair_faces']:p['constraint_span']=[offset[i] for i in p['constraint_span']]
    for r in definitions:r['constraint_span']=[offset[i] for i in r['constraint_span']]
    write(OUT/'mapping.json',mapping);write(OUT/'shared-directions.json',definitions);write(OUT/'removed-complement-indices.json',removed)
    shutil.copyfile(PARENT/'old-direction-projection.json',OUT/'old-direction-projection.json')
    write(OUT/'transformation.json',{'removed_constraints':101455,'original_variables_retained':111710,'original_base_constraints_retained':57577,'area_constraints_retained':14,'physical_pair_modes_retained':394,'hints_retained':72,'witness_coordinate_locks_added':0,'true_direction_implications_retained':101455,'only_negative_direction_complements_removed':True})
    (OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n')
    result={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':72,'parent_constraints':265709,'complement_constraints_removed':101455,'shared_direction_flags':101455,'physical_pair_modes':394,'model_sha256':digest(OUT/'model.pb'),'required_originals':66,'moving_originals':9,'fixed_originals':57,'area_inequalities_retained':14,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
