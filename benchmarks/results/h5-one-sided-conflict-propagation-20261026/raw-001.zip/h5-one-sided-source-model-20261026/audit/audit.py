"""Independent monotonicity and full model-restoration oracle for one-sided flags."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
from bisect import bisect_left
import json,time,shutil,traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-one-sided-source-model-20261026';PARENT=ROOT/'output/h5-shared-direction-source-model-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def lin(terms,lo,hi,en):
    d={v:sum(c for w,c in terms if w==v) for v,c in terms};ids=sorted(v for v,c in d.items() if c)
    p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(d[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en);return p
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Verify immutable parent hashes against the committed archive; identify removed constraints independently by negative shared-flag enforcement. Reconstruct every removed complement and retained positive plane from normalized coefficients. Restore the entire parent including all non-constraint fields. Inspect every remaining constraint occurrence: shared flags may appear only positively in face ORs or enforcing their own plane. Check all spans by independent binary-search offsets, all variables/hints/base/area retained, and actual solver import/export. Construct the exact monotone auxiliary assignment proof; no solver.'})
    manifest=load(ROOT/'benchmarks/results/h5-source-area-and-direction-sharing-20261026/raw-manifest.json');known={r['sha256'] for r in manifest['files']+manifest['aliases']}
    for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h and h in known,n
    for n,h in load(PARENT/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    pc=load(PARENT/'audit/checks.json');assert pc['passed'] and pc['shared_direction_equivalence_verified'] and pc['both_auxiliary_constraint_multisets_verified']
    old=cp_model_pb2.CpModelProto();old.ParseFromString((PARENT/'model.pb').read_bytes());new=cp_model_pb2.CpModelProto();new.ParseFromString((BASE/'model.pb').read_bytes())
    om=load(PARENT/'mapping.json');nm=load(BASE/'mapping.json');od=load(PARENT/'shared-directions.json');nd=load(BASE/'shared-directions.json');coords={r['part']:r for r in om['simultaneous_original_coordinates']};flags={r['flag'] for r in od};assert flags==set(range(10255,111710))
    assert old.variables==new.variables and len(new.variables)==111710 and len(old.constraints)==265709 and len(new.constraints)==164254
    byflag={r['flag']:r for r in od};removed=[];positive_defs={};negative_defs={}
    for i,c in enumerate(old.constraints):
        neg=[-v-1 for v in c.enforcement_literal if v<0 and -v-1 in flags]
        if neg:
            assert len(neg)==1 and list(c.enforcement_literal)==[-neg[0]-1] and neg[0] not in negative_defs;negative_defs[neg[0]]=i;removed.append(i)
    assert len(removed)==101455 and set(negative_defs)==flags and removed==load(BASE/'removed-complement-indices.json')
    for r in od:
        a,b=[coords[i] for i in r['parts']];terms=[(b['x'],r['a']),(a['x'],-r['a']),(b['y'],r['b']),(a['y'],-r['b'])];positive=lin(terms,r['bound'],2**63-1,[r['flag']]);negative=lin(terms,-2**63,r['bound']-1,[-r['flag']-1]);lo,hi=r['constraint_span'];assert hi==lo+2 and old.constraints[lo]==positive and old.constraints[lo+1]==negative and negative_defs[r['flag']]==lo+1;positive_defs[r['flag']]=positive
    drop=set(removed);expected=[c for i,c in enumerate(old.constraints) if i not in drop];assert list(new.constraints)==expected
    restored=cp_model_pb2.CpModelProto();restored.CopyFrom(new);del restored.constraints[:];cursor=0
    for i,c in enumerate(old.constraints):
        if i in drop:restored.constraints.add().CopyFrom(c)
        else:restored.constraints.add().CopyFrom(new.constraints[cursor]);cursor+=1
    assert cursor==len(new.constraints) and restored==old
    assert new.constraints[:57591]==old.constraints[:57591] and new.solution_hint==old.solution_hint and len(new.solution_hint.vars)==72 and all(v<10255 for v in new.solution_hint.vars)
    assert not new.HasField('objective') and not new.HasField('floating_point_objective') and not new.assumptions and not new.search_strategy
    # No unexamined negative or arithmetic use may invalidate monotone completion.
    en_counts=Counter();or_counts=Counter();kinds=Counter()
    for c in new.constraints:
        kind=c.WhichOneof('constraint');kinds[kind]+=1
        for v in c.enforcement_literal:
            if (v if v>=0 else -v-1) in flags:
                assert v in flags and list(c.enforcement_literal)==[v] and c==positive_defs[v];en_counts[v]+=1
        if kind=='linear':assert not flags.intersection(c.linear.vars)
        else:
            assert kind in ['bool_or','bool_and','exactly_one','at_most_one']
            for v in getattr(c,kind).literals:
                if (v if v>=0 else -v-1) in flags:assert kind=='bool_or' and v in flags;or_counts[v]+=1
    assert set(en_counts)==set(or_counts)==flags and all(n==1 for n in en_counts.values())
    def remap(span):return [i-bisect_left(removed,i) for i in span]
    assert {k:v for k,v in nm.items() if k!='source_pair_faces'}=={k:v for k,v in om.items() if k!='source_pair_faces'}
    assert len(nm['source_pair_faces'])==len(om['source_pair_faces'])==394
    for a,b in zip(om['source_pair_faces'],nm['source_pair_faces']):assert b=={**a,'constraint_span':remap(a['constraint_span'])}
    assert len(nd)==len(od)==101455
    for a,b in zip(od,nd):
        assert b=={**a,'constraint_span':remap(a['constraint_span'])} and b['constraint_span'][1]==b['constraint_span'][0]+1
        assert new.constraints[b['constraint_span'][0]]==positive_defs[b['flag']]
    assert (BASE/'old-direction-projection.json').read_bytes()==(PARENT/'old-direction-projection.json').read_bytes()
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'solver-import-roundtrip.pb'))
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert actual==new
    assert digest(BASE/'model.pb')==load(BASE/'result.json')['model_sha256']
    write(OUT/'equivalence-proof.json',{'scope':'Identical feasible projection onto the original10255 variables within the finite source orientations/inward integer domains/fixed57 construction.','parent_to_child':'Delete the negative complement constraints; every parent solution is a child solution with the same variables.','child_to_parent':'Retain all original variables. Replace each shared flag by the exact truth of its own normalized plane. A child flag already true implies that plane and remains true. Only false-to-true changes occur. Every occurrence audit allows solely positive face-OR literals and positive enforcement of that same plane. ORs cannot become false, and each newly enabled plane is true. Every removed false-implies-complement then holds exactly for integer coordinates. Thus a complete parent solution exists for each child base assignment.','positive_plane_definitions_checked':len(en_counts),'positive_OR_occurrences_checked':sum(or_counts.values()),'negative_or_arithmetic_shared_flag_uses_remaining':0,'all_base_variables_area_rules_hints_and_other_fields_preserved':True,'no_weaker_physical_layout_gate':True})
    checks={'passed':True,'seconds':time.perf_counter()-start,'variables':len(new.variables),'constraints':len(new.constraints),'hints':72,'committed_parent_files_verified':len(load(BASE/'plan.json')['inputs']),'removed_complements_verified':len(removed),'positive_plane_definitions_verified':len(en_counts),'positive_OR_occurrences_verified':sum(or_counts.values()),'negative_or_arithmetic_shared_flag_uses_remaining':0,'shared_direction_flags':101455,'physical_pair_modes':394,'constraint_kinds':dict(kinds),'complete_parent_restored_exactly':True,'all_original_full_guarded_source_clauses_retained':True,'shared_direction_equivalence_verified':True,'one_sided_monotone_projection_verified':True,'actual_solver_import_export_verified':True,'required_originals':66,'moving_originals':9,'fixed_originals':57,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
