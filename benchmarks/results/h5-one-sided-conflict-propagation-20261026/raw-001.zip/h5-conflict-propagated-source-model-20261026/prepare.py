"""Restore all previously proved domain conflicts beside the compact exact source model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil,traceback
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-one-sided-source-model-20261026';CONFLICTS=ROOT/'output/h5-convex-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=ROOT/'output/h5-conflict-propagated-source-model-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
    assert load(PARENT/'audit/checks.json')['passed'] and load(CONFLICTS/'audit/checks.json')['passed'] and load(CONFLICTS/'groups/audit/checks.json')['passed']
    names=['model.pb','mapping.json','result.json','audit/checks.json','shared-directions.json','old-direction-projection.json','removed-complement-indices.json']
    paths=[PARENT/n for n in names]+[CONFLICTS/n for n in ['plan.json','result.json','audit/checks.json','groups/result.json','groups/audit/checks.json']]+[SOURCE/'plan.json']+sorted((CONFLICTS/'groups').glob('[0-9][0-9][0-9].json'))+sorted((CONFLICTS/'cases').glob('*'))+sorted((SOURCE/'queries').glob('*.json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'solver_calls':0,'method':'Keep the complete one-sided shared-source model, all original variables/geometry/area rules/72 hints. Restore the complete previously certified convex-domain conflict table as Boolean group definitions plus exact mutual-exclusion clauses. A group Boolean equals the sum of its mutually exclusive original A-domain flags; it excludes all listed B domains or the entire B query if every B domain conflicts. This reinstates5,561,575 unique proven whole-domain conflicts over394 physical query-pair modes (24,091,856 physical uses), with3395 auxiliaries and7886 constraints. No new geometry exclusions are inferred. Independently verify the committed conflict bits, exact row partitions, source domain-to-variable ordering and every appended constraint before actual import and any distinct bounded call.'})
    model=cp_model_pb2.CpModelProto();model.ParseFromString((PARENT/'model.pb').read_bytes());assert len(model.variables)==111710 and len(model.constraints)==164254
    mapping=load(PARENT/'mapping.json');spec=load(CONFLICTS/'plan.json');groups={c['index']:load(CONFLICTS/'groups'/f"{c['index']:03d}.json") for c in spec['cases']};details=[];literal_count=0
    for pair in spec['physical_pair_case_uses']:
        i,j=pair['parts'];a,b=[mapping['parts'][k] for k in [i,j]]
        for caseid in pair['cases']:
            row=groups[caseid];case=row['case'];qa=next(m for m in a['modes'] if m['query']==case['query_a']);qb=next(m for m in b['modes'] if m['query']==case['query_b']);assert len(qa['domains'])==case['rows_a'] and len(qb['domains'])==case['rows_b']
            for group in row['groups']:
                if not group['conflicts_per_a_row']:continue
                start_constraint=len(model.constraints);da=[qa['domains'][k] for k in group['rows_a']];raw=bytes.fromhex(group['forbidden_b_hex']);forbidden=[qb['domains'][k] for k in range(case['rows_b']) if raw[k//8]&(1<<(7-k%8))];assert len(forbidden)==group['conflicts_per_a_row']
                if len(da)==1:flag=da[0]
                else:
                    flag=len(model.variables);model.variables.add(name=f"restored-pair{i}-{j}-case{caseid}-group{group['group']}",domain=[0,1]);terms=sorted([(v,1) for v in da]+[(flag,-1)]);c=model.constraints.add();c.linear.vars.extend(v for v,n in terms);c.linear.coeffs.extend(n for v,n in terms);c.linear.domain.extend([0,0])
                c=model.constraints.add()
                if len(forbidden)==len(qb['domains']):c.bool_or.literals.extend([-flag-1,-qb['active']-1]);literal_count+=2
                else:c.at_most_one.literals.extend([flag]+forbidden);literal_count+=1+len(forbidden)
                details.append({'parts':[i,j],'case':caseid,'group':group['group'],'flag':flag,'constraint_span':[start_constraint,len(model.constraints)]})
    assert len(model.variables)==115105 and len(model.constraints)==172140 and len(details)==4491 and literal_count==1572932
    mapping['restored_domain_conflict_groups']=details;write(OUT/'mapping.json',mapping)
    for name in ['shared-directions.json','old-direction-projection.json','removed-complement-indices.json']:shutil.copyfile(PARENT/name,OUT/name)
    write(OUT/'transformation.json',{'retained_parent_variables':111710,'retained_parent_constraints':164254,'appended_conflict_auxiliaries':3395,'appended_conflict_constraints':7886,'nonzero_physical_groups':4491,'mutual_exclusion_literals':literal_count,'unique_proven_domain_conflicts':5561575,'physical_proven_domain_conflicts':24091856,'physical_pair_modes':394,'all14_area_constraints_retained':True,'hints_retained':72,'new_geometry_exclusions':0})
    (OUT/'model.pb').write_bytes(model.SerializeToString());(OUT/'model.pbtxt').write_text(text_format.MessageToString(model),encoding='utf-8',newline='\n')
    result={'seconds':time.perf_counter()-start,'variables':len(model.variables),'constraints':len(model.constraints),'hints':72,'restored_conflict_auxiliaries':3395,'restored_conflict_constraints':7886,'nonzero_physical_groups':len(details),'unique_proven_domain_conflicts':5561575,'physical_proven_domain_conflicts':24091856,'model_sha256':digest(OUT/'model.pb'),'required_originals':66,'moving_originals':9,'fixed_originals':57,'solver_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
