"""Independently reconstruct every restored conflict from frozen bit matrices."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations,product
import json,time,shutil,traceback
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-conflict-propagated-source-model-20261026';PARENT=ROOT/'output/h5-one-sided-source-model-20261026';CONFLICTS=ROOT/'output/h5-convex-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'method':'Validate the complete parent audit hash chain and committed frozen conflict/source bytes. Decode all164 original bit matrices independently, verify all group row partitions including zero rows, reconstruct the complete394 physical mode inventory from the original nine parts, verify original domain variable ordering/Boolean domains and reconstruct all7886 additions. Recover the complete parent exactly. Check the group truth argument: mandatory parts select at most one domain, so a group sum is Boolean and mutual exclusion implements exactly all recorded conflicting pairs. No new geometry exclusion or solver call. Validate actual CpModel import/export.'})
    known=set()
    for name in ['h5-convex-domain-conflicts-20261025','h5-source-area-and-direction-sharing-20261026']:
        m=load(ROOT/'benchmarks/results'/name/'raw-manifest.json');known.update(r['sha256'] for r in m['files']+m['aliases'])
    inputs=load(BASE/'plan.json')['inputs'];committed=0
    for n,h in inputs.items():
        assert digest(ROOT/n)==h,n
        if not n.startswith(PARENT.relative_to(ROOT).as_posix()+'/'):assert h in known,n;committed+=1
    for n,h in load(PARENT/'audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    parentcheck=load(PARENT/'audit/checks.json');assert parentcheck['passed'] and parentcheck['one_sided_monotone_projection_verified']
    assert load(CONFLICTS/'audit/checks.json')['passed'] and load(CONFLICTS/'groups/audit/checks.json')['passed']
    old=cp_model_pb2.CpModelProto();old.ParseFromString((PARENT/'model.pb').read_bytes());new=cp_model_pb2.CpModelProto();new.ParseFromString((BASE/'model.pb').read_bytes())
    assert len(old.variables)==111710 and len(old.constraints)==164254
    restored=cp_model_pb2.CpModelProto();restored.CopyFrom(new);del restored.variables[111710:];del restored.constraints[164254:];assert restored==old
    om=load(PARENT/'mapping.json');nm=load(BASE/'mapping.json');assert {k:v for k,v in nm.items() if k!='restored_domain_conflict_groups'}==om
    spec=load(SOURCE/'plan.json');census=load(CONFLICTS/'plan.json');cases={(r['query_a'],r['query_b']):r for r in census['cases']};assert len(cases)==164
    groups={};unique=0;matrix_pairs=0
    for key,case in cases.items():
        cid=case['index'];meta=load(CONFLICTS/'cases'/f'{cid:03d}.json');blob=(CONFLICTS/'cases'/f'{cid:03d}.bin').read_bytes();assert digest(CONFLICTS/'cases'/f'{cid:03d}.bin')==meta['packed_sha256']
        textbits=''.join(format(b,'08b') for b in blob);n=case['domain_pairs'];assert n==case['rows_a']*case['rows_b'] and all(v=='0' for v in textbits[n:]);textbits=textbits[:n];matrix_pairs+=n;assert textbits.count('1')==meta['conflicts']
        row=load(CONFLICTS/'groups'/f'{cid:03d}.json');assert row['case']==case;seen=[]
        for g in row['groups']:
            bits=''.join(format(b,'08b') for b in bytes.fromhex(g['forbidden_b_hex']));assert all(v=='0' for v in bits[case['rows_b']:]);bits=bits[:case['rows_b']];assert bits.count('1')==g['conflicts_per_a_row']
            for i in g['rows_a']:assert bits==textbits[i*case['rows_b']:(i+1)*case['rows_b']];seen.append(i)
        assert sorted(seen)==list(range(case['rows_a']));groups[cid]=row;unique+=meta['conflicts']
    assert unique==5561575 and matrix_pairs==8449813
    for i,p in enumerate(nm['parts']):
        original=spec['parts'][i];assert p['part']==i and p['item']==original['index'] and p['family']==original['family'] and [m['query'] for m in p['modes']]==original['queries']
        for mode in p['modes']:
            qi=mode['query'];domains=load(SOURCE/'queries'/f'{qi:03d}.json')['domains'];assert len(mode['domains'])==len(domains) and list(new.variables[mode['active']].domain)==[0,1]
            for v,d in zip(mode['domains'],domains):assert v<10255 and new.variables[v].name==f"part{i}-query{qi}-face{d['index']}" and list(new.variables[v].domain)==[0,1]
    vi=111710;ci=164254;details=[];physical=0;uses=[];literals=0
    def check(c):
        nonlocal ci
        assert c==new.constraints[ci],ci;ci+=1
    for i,j in combinations(range(9),2):
        ids=[]
        for qa,qb in product(spec['parts'][i]['queries'],spec['parts'][j]['queries']):
            if spec['queries'][qa]['sheet']!=spec['queries'][qb]['sheet']:continue
            case=cases[(qa,qb)];ids.append(case['index']);a=next(m for m in nm['parts'][i]['modes'] if m['query']==qa);b=next(m for m in nm['parts'][j]['modes'] if m['query']==qb)
            for g in groups[case['index']]['groups']:
                if not g['conflicts_per_a_row']:continue
                begin=ci;av=[a['domains'][r] for r in g['rows_a']];rawbits=''.join(format(v,'08b') for v in bytes.fromhex(g['forbidden_b_hex']));bv=[v for r,v in enumerate(b['domains']) if rawbits[r]=='1'];physical+=len(av)*len(bv)
                if len(av)==1:flag=av[0]
                else:
                    flag=vi;vi+=1;assert new.variables[flag]==cp_model_pb2.IntegerVariableProto(name=f"restored-pair{i}-{j}-case{case['index']}-group{g['group']}",domain=[0,1]);c=cp_model_pb2.ConstraintProto();terms=sorted([(v,1) for v in av]+[(flag,-1)]);c.linear.vars.extend(v for v,n in terms);c.linear.coeffs.extend(n for v,n in terms);c.linear.domain.extend([0,0]);check(c)
                c=cp_model_pb2.ConstraintProto()
                if len(bv)==len(b['domains']):c.bool_or.literals.extend([-flag-1,-b['active']-1]);literals+=2
                else:c.at_most_one.literals.extend([flag]+bv);literals+=1+len(bv)
                check(c);details.append({'parts':[i,j],'case':case['index'],'group':g['group'],'flag':flag,'constraint_span':[begin,ci]})
        uses.append({'parts':[i,j],'cases':ids})
    assert uses==census['physical_pair_case_uses'] and sum(len(p['cases']) for p in uses)==394 and details==nm['restored_domain_conflict_groups'] and len(details)==4491
    assert vi==len(new.variables)==115105 and ci==len(new.constraints)==172140 and physical==24091856 and literals==1572932
    for name in ['shared-directions.json','old-direction-projection.json','removed-complement-indices.json']:assert (BASE/name).read_bytes()==(PARENT/name).read_bytes()
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'solver-import-roundtrip.pb'))
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'solver-import-roundtrip.pb').read_bytes());assert actual==new and digest(BASE/'model.pb')==load(BASE/'result.json')['model_sha256']
    write(OUT/'restored-propagation-proof.json',{'source':'Previously committed whole-box/whole-convex-domain conflict certificates, not a new geometric approximation.','group_truth':'Original mandatory part A selects exactly one domain overall. A sum over a subset of its flags is therefore0 or1. Equating that sum to the new Boolean makes the group flag exactly the disjunction of those original domain choices.','exclusion_truth':'Original part B also selects at most one listed domain. AtMostOne(group_flag, conflicting B flags) is therefore exactly the conjunction of pairwise group/B exclusions. If every B domain conflicts, not(group_flag AND queryB_active) is identical. A one-row A group directly uses that original domain flag.','all_original_constraints_retained':True,'unique_conflicts':unique,'physical_conflicts':physical,'new_geometric_exclusions':0,'no_focused_witness_pose_or_count_change':True})
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_source_files_verified':committed,'variables':vi,'constraints':ci,'hints':72,'unique_query_pair_cases':164,'domain_pair_bits_verified':matrix_pairs,'unique_proven_domain_conflicts':unique,'physical_proven_domain_conflicts':physical,'physical_pair_modes':394,'restored_groups':len(details),'restored_auxiliaries':3395,'restored_constraints':7886,'mutual_exclusion_literals':literals,'complete_parent_restored_exactly':True,'all_original_full_guarded_source_clauses_retained':True,'shared_direction_equivalence_verified':True,'one_sided_monotone_projection_verified':True,'complete_certified_conflict_table_restored':True,'actual_solver_import_export_verified':True,'required_originals':66,'moving_originals':9,'fixed_originals':57,'solver_calls':0,'model_sha256':digest(BASE/'model.pb'),'full_target_witness':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
