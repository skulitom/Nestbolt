"""Plot the verified partial and inventory adjacent fixed originals; no new search."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction
import json,shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch,Rectangle
from shapely.geometry import shape
from shapely.affinity import translate
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-fixed-source-neighborhood-review-20261026';OUT.mkdir();shutil.copyfile(__file__,OUT/'inspect.py')
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
fixedpath=ROOT/'output/h5-guarded-source-adjustment-20261025/audit/adjusted-fixed-originals.json';witpath=ROOT/'output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic/audit/six-cog-positions.json';profilepath=ROOT/'output/h5-full-original-joint-prepared-20261025/profiles.json';geompath=ROOT/'output/h5-source-orientation-construction-20261025/geometry.json'
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [fixedpath,witpath,profilepath,geompath]},'method':'Read the unchanged57 fixed original polygons and the already audited six-cog witness. Plot filled outer regions because part-in-hole is off. Inventory exact GEOS polygon distances from each first-sheet witness cog to every same-sheet fixed original. This is a63-original diagnostic missing brackets28/29 and insert50, not a full target layout or a new feasibility proof. No solver or native call.'})
fixed=load(fixedpath);profiles=load(profilepath);witness=load(witpath);records=[{'item':r['item'],'family':r['family'],'sheet':r['sheet'],'fixed':True,'poly':shape(r['geometry'])} for r in fixed]
for r in witness:records.append({'item':r['item'],'family':'cog','sheet':r['sheet'],'fixed':False,'poly':translate(shape(profiles[r['profile']]['geometry']),r['x_units']/1000,r['y_units']/1000)})
assert len(records)==63 and len({r['item'] for r in records})==63
neighbors=[]
for a in records:
    if a['fixed'] or a['sheet']!=0:continue
    for b in records:
        if not b['fixed'] or b['sheet']!=a['sheet']:continue
        neighbors.append({'moving_item':a['item'],'fixed_item':b['item'],'fixed_family':b['family'],'distance_mm':a['poly'].distance(b['poly']),'fixed_bounds':list(b['poly'].bounds)})
neighbors.sort(key=lambda r:(r['distance_mm'],r['moving_item'],r['fixed_item']));write(OUT/'first-sheet-fixed-neighbors.json',neighbors)
stocks=[[float(Fraction(*v)) for v in s] for s in load(geompath)['stock_bounds_rational']]
colors={'frame':'#c9dceb','bracket':'#efbe7f','insert':'#98d1ab','cog':'#b6a0cf'}
fig=plt.figure(figsize=(12,11));grid=fig.add_gridspec(2,2,width_ratios=[1,1.15],height_ratios=[3,1]);axes=[fig.add_subplot(grid[:,0]),fig.add_subplot(grid[0,1]),fig.add_subplot(grid[1,1])]
for ax,sheet,bounds,title in [(axes[0],0,[-10,-10,1510,3010],'Sheet 1: all fixed originals and four witness cogs'),(axes[1],0,[850,1900,1510,3010],'Sheet 1: lower-right detail'),(axes[2],1,[-10,-10,1510,350],'Sheet 2: target strip and two witness cogs')]:
    stock=stocks[sheet];ax.add_patch(Rectangle((stock[0],stock[1]),stock[2]-stock[0],stock[3]-stock[1],fill=False,color='#333333',lw=1))
    for r in records:
        if r['sheet']!=sheet:continue
        ax.add_patch(Patch(list(r['poly'].exterior.coords),facecolor=colors[r['family']],edgecolor='#333333',lw=1.3 if not r['fixed'] else .4))
        pt=r['poly'].representative_point()
        if bounds[0]<=pt.x<=bounds[2] and bounds[1]<=pt.y<=bounds[3]:ax.text(pt.x,pt.y,str(r['item']),ha='center',va='center',fontsize=8 if ax==axes[1] else 6,weight='bold' if not r['fixed'] else 'normal')
    ax.set_xlim(bounds[0],bounds[2]);ax.set_ylim(bounds[1],bounds[3]);ax.set_aspect('equal');ax.set_title(title,fontsize=10);ax.set_xlabel('mm');ax.set_ylabel('mm')
fig.suptitle('63-original diagnostic — missing brackets 28/29 and insert 50\nLabels are original item numbers; filled cutouts remain reserved. Not a cutting layout.',fontsize=12);fig.tight_layout();fig.savefig(OUT/'fixed-neighborhood.png',dpi=140);plt.close(fig)
summary={'originals_shown':63,'fixed_originals':57,'witness_cogs':6,'missing_originals':[28,29,50],'fixed_neighbor_pairs_inspected':len(neighbors),'neighbors_within_50mm':[r for r in neighbors if r['distance_mm']<=50],'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False};write(OUT/'result.json',summary);print(summary,flush=True)
