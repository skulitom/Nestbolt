"""Declare one bounded search of compact source geometry plus all certified conflicts."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];records=[]
for name in ['run_h5_one_sided_source_search.py','audit_h5_one_sided_source_search.py']:
    p=ROOT/'output'/name;s=p.read_text().replace('h5-one-sided-source-','h5-conflict-propagated-source-').replace('111710','115105').replace('164254','172140')
    if name.startswith('run_'):
        s=s.replace("checked['one_sided_monotone_projection_verified']","checked['one_sided_monotone_projection_verified'] and checked['complete_certified_conflict_table_restored']")
        s=s.replace('One distinct equivalent nine-mover representation removes101455 complement definitions from the shared-direction parent. Independently audited monotone completion proves exact feasible projection: flags occur only positively in face ORs and as enforcement of their own planes. Original base,14 area rules,all394 source pair modes and72 hints remain.','One distinct compact full-source model restores the entire certified convex-domain conflict table:5,561,575 unique conflicts and24,091,856 physical uses. All3395 auxiliaries and7886 added constraints are independently reconstructed from frozen matrices; the whole one-sided parent,14 area rules,394 source modes and72 hints remain.')
        s=s.replace('One distinct one-sided shared-direction representation removes exactly101455 complement constraints, with independently proved monotone completion restoring an exact parent solution for each feasible base assignment. All14 area rules and the original base remain.','One distinct compact source model restores all previously certified domain conflicts with3395 Boolean group auxiliaries and7886 verified constraints. This combines early domain propagation with full original guarded geometry; all14 area rules and the entire one-sided parent remain.')
        s=s.replace("'removed_complement_constraints':101455,","'removed_complement_constraints':101455,'complete_certified_conflict_table_restored':True,'restored_conflict_constraints':7886,'restored_conflict_auxiliaries':3395,")
    else:
        s=s.replace("assert model['one_sided_monotone_projection_verified']", "assert model['complete_certified_conflict_table_restored'] and model['restored_conflict_constraints']==7886 and model['restored_conflict_auxiliaries']==3395\n    assert model['one_sided_monotone_projection_verified']")
        s=s.replace("write(OUT/'plan.json',", "conflict_root=ROOT/'output/h5-convex-domain-conflicts-20261025';inputs += [conflict_root/'plan.json']+sorted((conflict_root/'cases').glob('*.bin'))\n    write(OUT/'plan.json',",1)
        s=s.replace('planes=pieces=edges=boxcount=same_pairs=0;','planes=pieces=edges=boxcount=same_pairs=conflict_pair_checks=0;')
        needle="mapping=load(RUN/'solve/mapping.json');assert len(mapping['parts'])==9"
        addition="""mapping=load(RUN/'solve/mapping.json');assert len(mapping['parts'])==9
        conflict_cases={(r['query_a'],r['query_b']):r for r in load(conflict_root/'plan.json')['cases']}
        for a,b in combinations(parts,2):
            if a['sheet']!=b['sheet']:continue
            c=conflict_cases[(a['query'],b['query'])];index=a['domain_row']*c['rows_b']+b['domain_row'];bits=(conflict_root/'cases'/f\"{c['index']:03d}.bin\").read_bytes();assert not bits[index//8]&(1<<(7-index%8));conflict_pair_checks+=1"""
        assert needle in s;s=s.replace(needle,addition)
        s=s.replace("'same_sheet_original_pairs_checked':same_pairs,","'same_sheet_original_pairs_checked':same_pairs,'selected_domain_conflict_pairs_checked':conflict_pair_checks,")
    q=ROOT/'output'/name.replace('one_sided','conflict_propagated');assert not q.exists();compile(s,str(q),'exec');q.write_text(s,encoding='utf-8',newline='\n');records.append({'source':p.relative_to(ROOT).as_posix(),'source_sha256':sha256(p.read_bytes()).hexdigest(),'generated':q.relative_to(ROOT).as_posix(),'generated_sha256':sha256(q.read_bytes()).hexdigest()})
out=ROOT/'output/h5-conflict-propagated-search-helper-generation-20261026.json'
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump({'helpers':records,'maximum_solver_calls':1,'solver_seconds':45,'total_seconds':60,'workers':8,'random_seed':0,'all_previous_calls_closed':True},f,indent=2);f.write('\n')
print(records)
