"""Create a distinct bounded runner for the audited one-sided projection."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];records=[]
for name in ['run_h5_shared_direction_source_search.py','audit_h5_shared_direction_source_search.py']:
    p=ROOT/'output'/name;s=p.read_text();s=s.replace('h5-shared-direction-source-','h5-one-sided-source-').replace('265709','164254')
    if name.startswith('run_'):
        s=s.replace("'old-direction-projection.json'","'old-direction-projection.json','removed-complement-indices.json'")
        s=s.replace("checked['shared_direction_equivalence_verified']","checked['shared_direction_equivalence_verified'] and checked['one_sided_monotone_projection_verified']")
        s=s.replace('One distinct equivalent nine-mover source representation: share101455 exact normalized direction truth flags across physical-pair modes, replacing156789 old mode-specific flags. Independent audit verifies two-way existential projection, all old/new auxiliary constraints and the unchanged original base plus14 area rules.','One distinct equivalent nine-mover representation removes101455 complement definitions from the shared-direction parent. Independently audited monotone completion proves exact feasible projection: flags occur only positively in face ORs and as enforcement of their own planes. Original base,14 area rules,all394 source pair modes and72 hints remain.')
        s=s.replace('One distinct full-source representation with verified exact shared-direction equivalence, removing55334 variables and110668 constraints while retaining all14 area rules and the original base.','One distinct one-sided shared-direction representation removes exactly101455 complement constraints, with independently proved monotone completion restoring an exact parent solution for each feasible base assignment. All14 area rules and the original base remain.')
        s=s.replace("'shared_direction_flags':101455,","'shared_direction_flags':101455,'one_sided_monotone_projection_verified':True,'removed_complement_constraints':101455,")
    else:
        s=s.replace("assert model['shared_direction_equivalence_verified']", "assert model['one_sided_monotone_projection_verified'] and model['removed_complement_constraints']==101455\n    assert model['shared_direction_equivalence_verified']")
    q=ROOT/'output'/name.replace('shared_direction','one_sided');assert not q.exists();compile(s,str(q),'exec');q.write_text(s,encoding='utf-8',newline='\n');records.append({'source':p.relative_to(ROOT).as_posix(),'source_sha256':sha256(p.read_bytes()).hexdigest(),'generated':q.relative_to(ROOT).as_posix(),'generated_sha256':sha256(q.read_bytes()).hexdigest()})
out=ROOT/'output/h5-one-sided-search-helper-generation-20261026.json'
with out.open('x',encoding='utf-8',newline='\n') as f:json.dump({'helpers':records,'maximum_solver_calls':1,'solver_seconds':45,'total_seconds':60,'workers':8,'random_seed':0,'all_previous_calls_closed':True},f,indent=2);f.write('\n')
print(records)
