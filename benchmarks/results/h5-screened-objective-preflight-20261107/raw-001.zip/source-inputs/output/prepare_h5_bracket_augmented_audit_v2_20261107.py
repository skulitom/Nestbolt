"""Classify source contact cases; retain every failed central sample."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-bracket-augmented-model-20261107';D=BASE/'derivative-diagnostic-v2'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
diagnostic=load(D/'checks.json');assert diagnostic['passed'] and diagnostic['original_failed_samples']==14 and diagnostic['all_interior_cases_without_shared_boundary'] and diagnostic['all_interior_cases_unique_nearest_features']
old=ROOT/'output/audit_h5_bracket_augmented_model_20261107.py';new=ROOT/'output/audit_h5_bracket_augmented_model_v2_20261107.py'
s=old.read_text(encoding='utf-8');a=s.index("    for h in plan['central_steps']:");b=s.index("write(OUT/'scalar-gradient-controls.json'",a)
replacement='''# Preserve the original324central samples, including all14 failures. A
# finite step through an edge-contact transition is not a derivative proof.
diagnostic=load(BASE/'derivative-diagnostic-v2/checks.json')
original_samples=load(BASE/'derivative-diagnostic-v2/all-original-central-controls.json')
assert len(original_samples)==324 and sum(r['failed'] for r in original_samples)==14
touching=[]
for record in original_samples:
    if not record['failed']:continue
    label,m,x=cases[0] if record['case']=='source_initializer' else cases[1]
    obj=Objective(m,regions,identity);value,g,detail=obj.evaluate(x,True)
    h=record['step'];k=record['coordinate'];xp=np.array(x);xm=np.array(x);xp[k]+=h;xm[k]-=h
    vp=reference.evaluate(m,xp)[0];vm=reference.evaluate(m,xm)[0];v0=reference.evaluate(m,x)[0]
    left=(v0-vm)/h;right=(vp-v0)/h;tol=plan['central_absolute_tolerance']+plan['central_relative_tolerance']*abs(g[k])
    assert min(left,right)-tol<=g[k]<=max(left,right)+tol
    touching.append({'case':label,'coordinate':k,'step':h,'selected_boundary_gradient':float(g[k]),'left_finite_slope':left,'right_finite_slope':right,'tolerance':float(tol),'interpretation':'finite one-sided enclosure only; not a unique derivative or global subgradient certificate'})
write(OUT/'preserved-original-central-controls.json',original_samples)
write(OUT/'touching-one-sided-controls.json',touching)
# The same two interior controls were fixed in the earlier weighted audit,
# before this objective existed. They are validation only, never search seeds.
smooth_controls=[]
for variation in [0,1]:
    selected=initial['modes'].copy() if variation==0 else [(v+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,v in enumerate(initial['modes'])]
    weights=initial['pair_weights'] if variation==0 else [1.+i%64 for i in range(528)]
    m=compile_model(lib,selected,initial['values'],weights,identity);assert verify(m,lib,selected,initial['values'],weights,identity)
    bb=np.asarray(m['bounds']);margin=.03+np.arange(81)*.00037
    point=np.clip(np.asarray(m['initial'])+.137*np.sin(np.arange(81)*2**.5+.2+variation),bb[:,0]+margin,bb[:,1]-margin)
    old_control=load(BASE/'derivative-diagnostic-v2/historical-interior-controls.json')[variation]
    assert m==old_control['model'] and point.tolist()==old_control['point']
    obj=Objective(m,regions,identity);value,g,details=obj.evaluate(point,True);rv,rg,rd=reference.evaluate(m,point,True,details['auxiliary_terms'])
    assert abs(value-rv)<plan['score_tolerance_mm2'] and np.max(np.abs(g-rg))<plan['scalar_gradient_tolerance_mm']
    assert rd['coincident_boundary_length_mm']==0 and all(t['distinct_closest_points']<=1 for t in rd['auxiliary_terms'])
    for h in plan['central_steps']:
        for k in range(81):
            xp=point.copy();xm=point.copy();xp[k]+=h;xm[k]-=h
            gp=(obj.score(xp)-obj.score(xm))/(2*h);err=abs(gp-g[k]);tolerance=plan['central_absolute_tolerance']+plan['central_relative_tolerance']*abs(g[k])
            assert err<tolerance,(variation,h,k,err,tolerance)
            max_central_error=max(max_central_error,err);central.append({'variation':variation,'step':h,'coordinate':k,'analytic':float(g[k]),'central':gp,'error':err,'tolerance':tolerance})
    smooth_controls.append({'variation':variation,'model':m,'point':point.tolist(),'scalar_gradient_error':float(np.max(np.abs(g-rg))),'no_shared_boundary':True,'unique_nearest_features':True})
write(OUT/'interior-model-controls.json',smooth_controls)
'''
s=s[:a]+replacement+s[b:]
changes={"OUT=BASE/'audit'":"OUT=BASE/'audit-v2'", "lib=load(BASE/'library.json')":"for name,h in load(BASE/'plan-v2.json')['inputs'].items():assert digest(ROOT/name)==h,name\nlib=load(BASE/'library.json')", "[Path(__file__),BASE/'plan.json'":"[Path(__file__),BASE/'plan-v2.json',BASE/'plan.json'", "'central_samples':len(central),":"'central_samples':len(central),'preserved_original_central_samples':324,'preserved_original_failed_samples':14,'finite_one_sided_enclosures':len(touching),"}
for a,b in changes.items():assert s.count(a)==1,a;s=s.replace(a,b)
with new.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
runner=(ROOT/'output/run_h5_bracket_augmented_stage_20261107.py').read_text(encoding='utf-8');a=runner.index('stage=sys.argv[1]');b=runner.index('SCRIPT=ROOT',a)
runner=runner[:a]+"stage='audit-v2'\nfilename,cap='audit_h5_bracket_augmented_model_v2_20261107.py',180\n"+runner[b:]
newrunner=ROOT/'output/run_h5_bracket_augmented_audit_v2_20261107.py'
with newrunner.open('x',encoding='utf-8',newline='\n') as f:f.write(runner)
inputs=[Path(__file__),old,new,newrunner,BASE/'plan.json',BASE/'model.json',D/'checks.json',D/'all-original-central-controls.json',D/'failing-coordinate-pair-causes.json',D/'historical-interior-controls.json',BASE/'derivative-diagnostic/serialization-failure.json',ROOT/'output/audit_h5_weighted_mixed_rows_model_v2_20261107.py',ROOT/'output/h5-bracket-augmented-model-audit-process-20261107/process.json',ROOT/'output/h5-bracket-augmented-model-audit-process-20261107/stderr.txt']
write(BASE/'plan-v2.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'correction':'The original verifier applied central-difference assertions directly at touching/near-transition saved contours. The unchanged area boundary convention need not equal a finite central slope there. Preserve all324original samples and all14failures, with independently reconstructed pair causes. Require independent scalar combined gradients at the same original cases and explicit full-objective one-sided finite-slope enclosures for each failing coordinate. Separately verify324central samples on the exact two deterministic interior controls already used by the old weighted-model audit; confirm no shared boundary and unique auxiliary nearest points. These points are validation only. No model, source initializer, objective, tolerance or optimizer changes. No global generalized-gradient certificate is claimed.','optimizer_calls':0,'model_changed':False,'initializer_changed':False})
print({'audit_v2_prepared':True,'model_changed':False,'original_failed_samples_retained':14})
