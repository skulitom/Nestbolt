"""Same weighted objective, with boundary work batched across active pairs."""
import math
import numpy as np
import shapely
from h5_weighted_original_model_20261107 import Objective as Previous,compile_model,update_weights
from h5_screened_boundary_gradient_20261107 import boundary_gradients

class Objective(Previous):
    def evaluate(self,values,details=False):
        gradient=np.zeros(self.model['parameters']);levels=[];weighted=[];records=[]
        losses=np.zeros(len(self.model['pairs']));segments=0;shared=0.
        for kind,entries in zip(['original','clearance'],self.geometry(values)):
            shapes=np.asarray([e[1] for e in entries],dtype=object);areas=shapely.area(shapely.intersection(shapes[self.left],shapes[self.right]));losses+=areas;levels.append(float(np.sum(areas)));weighted.append(float(np.dot(areas,self.weights)))
            vertices=[];lines=[];others=[];pivots=[];owners=[];coefficients=[]
            for index in np.flatnonzero(areas>0):
                i,j=self.model['pairs'][index];weight=self.weights[index]
                if details:records.append({'kind':kind,'owners':[i,j],'area_mm2':float(areas[index]),'weight':float(weight)})
                for own,other in [(i,j),(j,i)]:
                    v,poly,ll,pivot=entries[own];vertices.append(v);lines.append(ll);others.append(entries[other][1]);pivots.append(pivot);owners.append(own);coefficients.append(weight)
            gradients,counts,coincident=boundary_gradients(vertices,lines,others,pivots)
            for k,own in enumerate(owners):
                g=gradients[k];weight=coefficients[k];gradient[2*own:2*own+2]+=weight*g[:2];owner=self.model['owners'][own]
                if owner['angle_coordinate'] is not None:gradient[owner['angle_coordinate']]+=weight*g[2]/owner['angle_scale_mm']
                segments+=int(counts[k]);shared+=float(coincident[k])
        value=sum(weighted);assert math.isfinite(value) and np.all(np.isfinite(gradient))
        if details:return value,gradient,{'unweighted_objective_mm2':sum(levels),'original_overlap_area_mm2':levels[0],'clearance_overlap_area_mm2':levels[1],'weighted_original_overlap_area_mm2':weighted[0],'weighted_clearance_overlap_area_mm2':weighted[1],'pair_losses_mm2':losses.tolist(),'positive_terms':records,'clipped_segments':segments,'coincident_boundary_length_mm':shared}
        return value,gradient
