"""Seal complete screened-objective equivalence and complete evaluation timings."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
SYNC=ROOT/'output/h5-shared-source-main-sync-20261107'
if not (SYNC/'receipt.json').exists():SYNC=ROOT/'output/h5-tiered-source-main-sync-20261107'
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-screened-objective-preflight-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-screened-objective-preflight-20261107';F=BASE;D=BASE",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-shared-source-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['runtime_records_with_independent_all81gradients']==211 and front['closed_keys']==23 and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-screened-objective-preflight-process-20261107',ROOT/'output/h5-screened-objective-batches-process-20261107',SYNC]",
"['*h5*mixed*mode*20261107.py']":"['*h5*screened*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_screened_objective_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','inherited-source-domains.json','source-cache-bindings.json','runtime-cost-plan.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
for name in ['checks','plan','source-mode-controls','complete-objective-controls','runtime-winner-controls','preserved-original-central-controls','touching-one-sided-controls','central-controls','boundary-policy-controls','negative-controls','timings','closed-problems','main-ci-at-review']:
    shutil.copyfile(BASE/(name+'.json'),OUT/('objective-audit.json' if name=='checks' else name+'.json'))
shutil.copyfile(ROOT/'output/h5-screened-objective-preflight-process-20261107/process.json',OUT/'preflight-process.json')
for name in ['checks','plan','timings','exact-output-controls']:
    shutil.copyfile(BASE/'trajectory-timings'/(name+'.json'),OUT/('trajectory-'+name+'.json'))
shutil.copyfile(ROOT/'output/h5-screened-objective-batches-process-20261107/process.json',OUT/'trajectory-process.json')
shutil.copyfile(SYNC/'receipt.json',OUT/'prior-main-push-receipt.json')
process=load(OUT/'preflight-process.json');assert process['passed'] and process['job']['closed'] and process['job']['active_processes']==0
batch=load(OUT/'trajectory-checks.json');batch_process=load(OUT/'trajectory-process.json');assert batch['passed'] and batch_process['passed'] and batch_process['job']['active_processes']==0
ci=load(OUT/'main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs']);receipt=load(OUT/'prior-main-push-receipt.json');main=receipt['new_main'];assert ci['headSha']==main
timings=load(OUT/'timings.json');summary=[]
for context in dict.fromkeys(r['context'] for r in timings):
    old=[r for r in timings if r['context']==context and r['kind']=='old'];new=[r for r in timings if r['context']==context and r['kind']=='screened'];assert len(old)==len(new)==2
    ov=sum(r['complete_evaluation_seconds'] for r in old)/2;nv=sum(r['complete_evaluation_seconds'] for r in new)/2
    summary.append({'context':context,'old_evaluation_mean_seconds':ov,'screened_evaluation_mean_seconds':nv,'observed_mean_seconds_saved':ov-nv,'old_construction_mean_seconds':sum(r['construction_seconds'] for r in old)/2,'screened_construction_mean_seconds':sum(r['construction_seconds'] for r in new)/2})
write(OUT/'timing-summary.json',summary)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k!='passed'},'complete_trajectory_batches':batch['batches'],'trajectory_evaluations_verified':batch['complete_evaluations_verified'],'trajectory_timing_summary':batch['summary']})
write(OUT/'next-step.json',{'status':'screened_objective_original_source_and_budget_preflight_required',
'finding':'The complete screened objective matches every old field exactly in all 363 declared comparisons. Independent scalar reconstruction verifies all 81 coordinates in 216 cases, including every one of 211 runtime records. Contact, central, synthetic boundary, identity and corruption controls pass. Single-call variability and one slowdown are preserved. A separate eight-batch measurement covers both full saved trajectories with 392 exact evaluations. Two observations per variant do not establish stable runtime or a packing benefit.',
'proposal':'Use the fully verified screened objective only after preparing and independently reading a fresh original-source primary-tier initializer under all 23 closed keys. Retain the full prior source preparation plus every new cost. Combine measured construction/evaluation, shared-selector, serialization, startup and source-validation costs before freezing a new finite search; do not reopen any old call or seed from validation/optimized state.',
'requirements':['Keep all 23 closed objective/physical-mode/weight keys and previous pipeline count/time limits closed. The mathematical identity and closure keys are unchanged by the implementation substitution.','Preserve all original and clearance geometry, 528 weighted area terms, 15 auxiliary terms, 33 movers/15 angles, the half-shared-boundary convention and strict selector policy. Keep touching boxes and nonfinite bounds; no quantization or changed-context cache.','Future initialization must use only the exact hash/context-bound original A/W source data. Retain 39.04916139948182 s preparation plus new source/model work, with independent full66 source checks before any new search.','Measure the full preparation-inclusive 60/90 s and 2 GiB budget; the present evaluation timings do not promise call counts or optimizer convergence. All three winner streams and every evaluation/source output must remain independently auditable.','H5 still requires full66 source validity, native/material evidence, production parity and its original matrix. Four fixed arrangements and 440 allocation candidates remain unresolved.'],
'closed_problem_keys':23,'source_only_preparation_seconds_before_new_work':39.04916139948182,'complete_screened_objective_verified':True,'new_source_state_prepared':False,'new_search_contract_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
table='\n'.join(f"| {r['context']} | {r['old_evaluation_mean_seconds']:.6f} | {r['screened_evaluation_mean_seconds']:.6f} | {r['observed_mean_seconds_saved']:.6f} |" for r in summary)
batch_table='\n'.join(f"| {r['epoch']} | {r['old_mean_seconds']:.6f} | {r['screened_mean_seconds']:.6f} | {r['observed_mean_seconds_saved']:.6f} |" for r in batch['summary'])
report=f'''# Complete screened-objective preflight — 2026-11-07

The complete objective now uses exact boundary clipping after excluding only
strictly disjoint edge/polygon boxes. It preserves every old result field and
all gradient coordinates in **{front['complete_objective_comparisons']} comparisons**.
This is a validation checkpoint with **no optimizer call**. The latest packing
candidate still fails 54 source pairs; H2/H5 remain open at **60% completed weight**.

Only the weighted/augmented import chain changes. The original mathematical
identity, model compilation and closure keys remain identical; all nine original
identity code hashes remain verified and the new implementation hashes are bound
separately. All **23 closed problem keys** stay closed. Arrays retain directed-pair
order, integration pivots and the half-weight shared-boundary convention. Touching
boxes and nonfinite bounds remain included. There is no coordinate rounding or
cache reused across changed inputs.

[Complete objective controls]({NAME}/complete-objective-controls.json) compare
original/clearance/weighted/auxiliary/augmented scores, all 81 gradient coordinates,
all 528 pair losses, positive terms, clipped-segment counts, coincident lengths and
auxiliary records. Detailed and plain evaluation, score and pair-loss interfaces
are checked. [All 147 source owner/mode cases]({NAME}/source-mode-controls.json)
retain their independent source scores. Original, latest-source, historical flat
and two fixed interior controls are also included.

[Runtime replay]({NAME}/runtime-winner-controls.json) covers every one of **211
records from five closed calls**, with **{front['runtime_saved_points']} saved points**
and all fifteen strict winner streams. Each runtime record now receives independent
scalar reconstruction of all 81 gradient coordinates. Including the five source/
interior/contact cases, **{front['all81scalar_gradient_cases']} complete scalar-gradient
cases** pass. Maximum independent score error is
{front['maximum_independent_score_error_mm2']:.3e} mm² and gradient error is
{front['maximum_independent_gradient_error_mm']:.3e} mm. Three distinct winners in
the latest second epoch remain distinct. No closed output is used as an initializer.

The [original 324 central samples]({NAME}/preserved-original-central-controls.json)
retain all fourteen failed finite-step checks. Their [fourteen one-sided controls]({NAME}/touching-one-sided-controls.json)
reproduce the same selected gradient and finite slopes; they establish finite
enclosures only, not unique derivatives at contact. The two fixed historical
interior models pass [324 central samples]({NAME}/central-controls.json) with
unchanged steps and tolerances. No contact result is relabelled smooth.

[Eight boundary cases]({NAME}/boundary-policy-controls.json) cover empty groups,
empty edges, identical, contained, disjoint, corner-touching, shared-edge and
zero-length-edge geometry. Available scalar gradients, clipped counts and shared
lengths agree. Deliberately dropping touching edges is detected by the counts and
coincident lengths of identical squares. [Nine model corruptions]({NAME}/negative-controls.json)
remain rejected by independent model readback.

[Complete evaluation timings]({NAME}/timings.json), in seconds:

| Labelled context | Original mean | Screened mean | Observed saving |
| --- | ---: | ---: | ---: |
{table}

The fixed order is old/screened/screened/old, with two samples per variant in each
labelled context. Labels include duplicate states where winner streams coincide
or an epoch starts at its source initializer. Each evaluation includes geometry,
area calculations, all gradients, auxiliary calculations and detailed output.
Object construction is measured separately in the [summary]({NAME}/timing-summary.json).
Serialization, source validation and optimizer orchestration are outside these
measurements. These observations do not establish stable runtime, statistical
significance or a packing gain.

The single-call timings include variability and one slowdown; that result stays
preserved. A separate [full-trajectory measurement]({NAME}/trajectory-checks.json)
uses each latest closed epoch's complete saved sequence in fixed old/screened/
screened/old batch order. All **392 detailed evaluations** across eight batches
match exactly; their [per-evaluation output hashes]({NAME}/trajectory-exact-output-controls.json)
remain recorded. Each batch constructs one objective, then evaluates all 54 or 44
points. Reading inputs and checking the outputs are outside the timed interval.

| Saved epoch | Original mean | Screened mean | Observed saving |
| --- | ---: | ---: | ---: |
{batch_table}

These are saved-trajectory evaluation costs, not optimizer executions or evidence
that a future trajectory will match. The separate [batch process]({NAME}/trajectory-process.json)
closes in {batch_process['complete_seconds']:.6f} s under its 120 s / 2 GiB cap.

The [bounded audit]({NAME}/preflight-process.json) closes in
**{process['complete_seconds']:.6f} s**, with peak committed memory
{process['job']['peak_job_committed_memory']:,} bytes under its 900 s / 2 GiB cap.
All {process['job']['total_processes']} processes close. This validation process
does not create a new search initializer or consume an optimizer call.

[Next]({NAME}/next-step.json), prepare a fresh original-source model under all
twenty-three closures, retaining **39.049161 s** preparation plus every new source
cost. Independently verify the full model/source output and complete budget before
freezing another finite attempt. Four arrangements and all 440 allocation candidates
remain unresolved; full66 validity, native/material evidence and the original H5
matrix are still required.

Main is **{main[:8]}**. The [last ordinary push receipt]({NAME}/prior-main-push-receipt.json)
preserves 52 files and the preceding CI gate. [Current CI]({NAME}/main-ci-at-review.json)
has {success} passed and {live} live jobs at review. Product code, README and releases
are unchanged. This checkpoint awaits the next ordinary push gate.

[Archive checks]({NAME}/archive-checks.json), [raw manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical evidence]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain the complete evidence graph.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 complete screened-objective preflight:** [full objective, scalar and timing evidence]({{link}}) verifies exact old/new results in {front["complete_objective_comparisons"]} cases, including all 147 source modes and 211 records from five closed calls. All 81 scalar gradient coordinates are independently checked in {front["all81scalar_gradient_cases"]} cases; {front["runtime_saved_points"]} saved points and fifteen winner streams reconcile. The original 324 central samples and fourteen failures remain preserved; fourteen finite one-sided controls, 324 historical interior central checks, eight synthetic boundary cases and nine model corruptions pass. All 23 keys stay closed. The 52 single-call timings retain variability and one slowdown. Eight complete saved-trajectory batches verify 392 exact evaluations, with all timings retained and no convergence or packing claim. Next independently prepare an original-source initializer and full budget, retaining 39.049161 s plus new costs. No new source initializer or optimizer call is opened. The last layout still has 54 failed pairs; four arrangements and 440 allocations remain, with H2/H5 open at 60%. Main {main[:8]} has {success} passed / {live} live jobs at review. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [complete screened-objective preflight](../benchmarks/results/{NAME}.md).
All {front['complete_objective_comparisons']} old/new comparisons agree exactly, including 147 source modes and
211 evaluations from five closed searches. Independent scalar geometry checks all
81 gradient coordinates in {front['all81scalar_gradient_cases']} cases. Known contact failures stay preserved;
central, boundary and corruption controls pass. All 23 problem keys remain closed.
Full evaluation/construction timings cover {front['timed_complete_evaluations']} calls, retaining one slowdown.
Eight complete-trajectory batches verify 392 exact evaluations. Next prepare and
independently verify a fresh original-source model and full budget, retaining
39.049161 s source preparation plus new costs. No new initializer or search is
opened. The last candidate still has 54 failed pairs. Four arrangements and 440
allocations remain; H2/H5 stay at 60%. Main {main[:8]} has {success} passed / {live} live CI
jobs at review. Product code, README and releases are unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
