"""Bounded complete-objective equivalence, scalar readback and measured costs."""
from pathlib import Path
from hashlib import sha256
import ast,copy,json,time,os
import numpy as np
import shapely
from shapely.geometry import Polygon
from h5_bracket_augmented_objective_20261107 import Objective as Old,compile_model as old_compile,problem_key as old_key
from h5_screened_augmented_objective_20261107 import Objective as New,compile_model,problem_key
from h5_screened_boundary_gradient_20261107 import boundary_gradients as screened
from h5_cross_pair_boundary_gradient_20261107 import boundary_gradients as dense
from h5_bracket_augmented_reference_20261107 import Reference
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
from h5_bracket_augmented_readback_20261107 import verify
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
from h5_checked_affinity_20261107 import affinity_mask

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-screened-objective-preflight-20261107'
A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
Z=ROOT/'output/h5-shared-source-preflight-20261107';Y=ROOT/'output/h5-tiered-source-preflight-20261107';X=ROOT/'output/h5-indexed-source-preflight-20261107'
P=ROOT/'benchmarks/results/h5-shared-source-construction-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')

OUT.mkdir();started=time.perf_counter()
assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
assert load(P/'archive-checks.json')['passed'] and load(P/'response-audit.json')['passed']
lib=load(A/'library.json');initial=load(A/'initial-state.json');identity=load(A/'objective-identity.json');regions=load(B/'regions.json');reference=Reference(lib);original_plan=load(A/'plan.json')
paths=[Path(__file__)]+[P/n for n in ['archive-checks.json','response-audit.json','next-step.json','closed-problems.json','runtime-costs.json','boundary-box-controls.json','boundary-policy-controls.json']]+[A/n for n in ['library.json','initial-state.json','objective-identity.json','model.json','plan.json','audit-v2/checks.json','audit-v2/plan.json','audit-v2/all-owner-mode-scores.json','audit-v2/interior-model-controls.json','audit-v2/preserved-original-central-controls.json','audit-v2/touching-one-sided-controls.json','audit-v2/negative-controls.json','derivative-diagnostic-v2/historical-interior-controls.json']]+[B/'regions.json',R/'search/epoch-02/model.json',R/'search/epoch-02/response.json',Z/'selected-model.json',Z/'selected-state.json',Z/'audit/checks.json',Z/'runtime-bindings.json']
paths += [ROOT/'output'/n for n in ['prepare_h5_screened_objective_helpers_20261107.py','h5_screened_boundary_gradient_20261107.py','h5_screened_weighted_model_20261107.py','h5_screened_augmented_objective_20261107.py','h5_bbox_boundary_diagnostic_20261107.py','h5_cross_pair_boundary_gradient_20261107.py','h5_cross_pair_weighted_model_20261107.py','h5_bracket_augmented_objective_20261107.py','h5_bracket_augmented_reference_20261107.py','h5_bracket_augmented_readback_20261107.py','h5_original_overlap_gradient_v2_20261107.py']]
runs=[('indexed',X,0),('tiered',Y,0),('tiered',Y,1),('shared',Z,0),('shared',Z,1)]
for label,base,epoch in runs:
    assert load(base/'response-audit/checks.json')['passed'];E=base/f'search/epoch-{epoch:02d}'
    paths += [base/'response-audit/checks.json']+[E/n for n in ['model.json','evaluations.jsonl','response.json','closed-problem.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Only version the clipped-boundary import chain, preserving mathematical objective identity, models and keys. Compare every complete objective field and all81gradient coordinates to the original implementation in all147source owner/mode cases, original/contact/interior controls and every recorded evaluation of five independently closed calls. Independently rebuild all runtime gradients from scalar source polygons and rational auxiliary boundaries. Reconstruct all three strict winner streams. Retain the original324central samples and14failures; check their finite one-sided enclosures without claiming unique derivatives. Recheck324fixed historical interior central samples with unchanged tolerances. Test empty/coincident/containment/touching/zero-edge kernels and deliberately unsafe touching exclusion. Verify nine model corruptions and original code hashes. Measure complete construction and evaluation in fixed old/new/new/old order across declared source and closed-runtime contexts. No optimizer, source initializer or reopened key.','validation_only':True,'cap_seconds':900,'memory_bytes':2**31,'closed_keys':23,'score_tolerance_mm2':1e-6,'scalar_gradient_tolerance_mm':1e-6,'timing_repetitions_per_variant':2,'optimizer_calls':0,'retry_permitted':False})
for name,h in identity['code_sha256'].items():assert digest(ROOT/'output'/name)==h
closed=load(P/'closed-problems.json');assert len(closed)==len({r['key'] for r in closed})==23;write(OUT/'closed-problems.json',closed)
runtime=load(Z/'runtime-bindings.json')
for name,h in runtime.items():assert digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)

# Parse-normalized implementation check: only the two imports differ.
chains=[('h5_cross_pair_weighted_model_20261107.py','h5_screened_weighted_model_20261107.py','h5_cross_pair_boundary_gradient_20261107','h5_screened_boundary_gradient_20261107'),('h5_bracket_augmented_objective_20261107.py','h5_screened_augmented_objective_20261107.py','h5_cross_pair_weighted_model_20261107','h5_screened_weighted_model_20261107')]
for before,after,old_module,new_module in chains:
    expected=(ROOT/'output'/before).read_text(encoding='utf-8').replace(old_module,new_module)
    assert ast.dump(ast.parse(expected))==ast.dump(ast.parse((ROOT/'output'/after).read_text(encoding='utf-8')))

comparisons=[]
def compare(model,point,label,scalar_gradient=False):
    modes=[o['mode'] for o in model['owners']];assert verify(model,lib,modes,model['initial'],model['pair_weights'],identity)
    assert compile_model(lib,modes,model['initial'],model['pair_weights'],identity)==old_compile(lib,modes,model['initial'],model['pair_weights'],identity)==model
    physical=physical_key(lib,family_classes(lib),modes);assert problem_key(physical,model['pair_weights'],identity)==old_key(physical,model['pair_weights'],identity)
    old=Old(model,regions,identity);new=New(model,regions,identity)
    v,g,d=old.evaluate(point,True);nv,ng,nd=new.evaluate(point,True)
    assert v==nv and np.array_equal(g,ng) and d==nd
    assert old.score(point)==new.score(point) and np.array_equal(old.pair_losses(point),new.pair_losses(point))
    plain,plain_gradient=new.evaluate(point);assert plain==v and np.array_equal(plain_gradient,g)
    rv,rg,rd=reference.evaluate(model,point,scalar_gradient,d['auxiliary_terms'])
    err=abs(rv-v);assert err<1e-6
    for field in ['original_overlap_area_mm2','clearance_overlap_area_mm2','unweighted_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2']:
        assert abs(d[field]-rd[field])<1e-6,(label,field)
    assert np.max(np.abs(np.asarray(d['pair_losses_mm2'])-rd['pair_losses_mm2']))<1e-6
    ge=float(np.max(np.abs(g-rg))) if scalar_gradient else None
    if scalar_gradient:assert ge<1e-6,(label,ge)
    comparisons.append({'case':label,'complete_old_new_fields_exact':True,'independent_score_error_mm2':err,'independent_all81gradient_error_mm':ge,'scalar_directed_terms':rd['directed_scalar_gradient_terms'],'clipped_segments':d['clipped_segments'],'coincident_boundary_length_mm':d['coincident_boundary_length_mm'],'auxiliary_bracket_depth_mm2':d['auxiliary_bracket_depth_mm2']})
    return v,g,d

source_scores=load(A/'audit-v2/all-owner-mode-scores.json');mode_controls=[]
for i,(family,_) in enumerate(lib['identities']):
    for mode in lib['family_modes'][family]:
        modes=initial['modes'].copy();modes[i]=mode['mode'];m=compile_model(lib,modes,initial['values'],initial['pair_weights'],identity)
        v,g,d=compare(m,m['initial'],f'source-mode-{i}-{mode["mode"]}')
        old_control=source_scores[len(mode_controls)];score=New(m,regions,identity).score(m['initial'])
        assert old_control['owner']==i and old_control['mode']==mode['mode'] and score==old_control['augmented_mm2']
        mode_controls.append({'owner':i,'mode':mode['mode'],'complete_fields_exact':True,'score_mm2':score})
assert len(mode_controls)==147;write(OUT/'source-mode-controls.json',mode_controls);print({'source_modes_verified':147},flush=True)

flat=load(R/'search/epoch-02/model.json');flat_x=load(R/'search/epoch-02/response.json')['unweighted_best']['values'];flat_model=compile_model(lib,[o['mode'] for o in flat['owners']],flat_x,flat['pair_weights'],identity)
cases={'source_initializer':(load(A/'model.json'),initial['values']),'closed_flat_validation_only':(flat_model,flat_x),'latest_source_initializer':(load(Z/'selected-model.json'),load(Z/'selected-state.json')['values'])}
for label,(model,point) in cases.items():compare(model,point,label,True)
original_samples=load(A/'audit-v2/preserved-original-central-controls.json');assert len(original_samples)==324 and sum(r['failed'] for r in original_samples)==14
write(OUT/'preserved-original-central-controls.json',original_samples)
touching=[]
for control in load(A/'audit-v2/touching-one-sided-controls.json'):
    model,point=cases[control['case']];obj=New(model,regions,identity);value,g,d=obj.evaluate(point,True);k=control['coordinate'];h=control['step']
    assert g[k]==control['selected_boundary_gradient'];xp=np.asarray(point).copy();xm=xp.copy();xp[k]+=h;xm[k]-=h
    vp=reference.evaluate(model,xp)[0];vm=reference.evaluate(model,xm)[0];v0=reference.evaluate(model,point)[0]
    assert (v0-vm)/h==control['left_finite_slope'] and (vp-v0)/h==control['right_finite_slope']
    assert min(control['left_finite_slope'],control['right_finite_slope'])-control['tolerance']<=g[k]<=max(control['left_finite_slope'],control['right_finite_slope'])+control['tolerance']
    touching.append(control)
assert len(touching)==14;write(OUT/'touching-one-sided-controls.json',touching)
central=[]
for row in load(A/'audit-v2/interior-model-controls.json'):
    m=row['model'];point=np.asarray(row['point']);v,g,d=compare(m,point,f'interior-{row["variation"]}',True);cases[f'interior-{row["variation"]}']=(m,point)
    obj=New(m,regions,identity)
    for h in original_plan['central_steps']:
        for k in range(81):
            xp=point.copy();xm=point.copy();xp[k]+=h;xm[k]-=h;finite=(obj.score(xp)-obj.score(xm))/(2*h)
            error=abs(finite-g[k]);tolerance=original_plan['central_absolute_tolerance']+original_plan['central_relative_tolerance']*abs(g[k]);assert error<tolerance
            central.append({'variation':row['variation'],'step':h,'coordinate':k,'analytic':float(g[k]),'central':finite,'error':error,'tolerance':float(tolerance)})
assert len(central)==324;write(OUT/'central-controls.json',central)

METRICS={'augmented':'augmented_objective_mm2','original':'original_overlap_area_mm2','unweighted':'unweighted_objective_mm2'}
runtime_controls=[];total_records=0
for label,base,epoch in runs:
    E=base/f'search/epoch-{epoch:02d}';model=load(E/'model.json');response=load(E/'response.json');saved_closed=load(E/'closed-problem.json')
    assert saved_closed in closed and saved_closed['closed'] and not saved_closed['retry_permitted'] and saved_closed['response_sha256']==digest(E/'response.json')
    winners={};saved=0;records=0
    for sequence,line in enumerate((E/'evaluations.jsonl').read_text(encoding='utf-8').splitlines()):
        r=json.loads(line);v,g,d=compare(model,r['values'],f'{label}-{epoch}-evaluation-{sequence}',True)
        assert sequence==r['evaluation'] and v==r['augmented_objective_mm2'] and np.array_equal(g,r['gradient'])
        for field in list(METRICS.values())+['weighted_area_objective_mm2','auxiliary_bracket_depth_mm2']:assert d[field]==r[field]
        flags={name:name not in winners or d[field]<winners[name][field] for name,field in METRICS.items()};assert flags==r['improved']
        assert r['saved_sequence']==(saved if any(flags.values()) else None)
        if any(flags.values()):
            assert r==load(E/'points'/f'{saved:05d}.json');paths.append(E/'points'/f'{saved:05d}.json');saved+=1
            for name,flag in flags.items():
                if flag:winners[name]=r
        records+=1
        if sequence%20==0:print({'context':label,'epoch':epoch,'all81scalar_gradient_records':records},flush=True)
    assert winners==response['winners'] and records==response['total_evaluation_records'] and saved==response['saved_points']
    runtime_controls.append({'context':label,'epoch':epoch,'key':response['key'],'records':records,'saved_points':saved,'all_three_winners_exact':True,'distinct_winners':len({r['evaluation'] for r in winners.values()}),'closed_key_preserved':True});total_records+=records
    if base==Z:
        cases[f'latest-epoch-{epoch}-initial']=(model,model['initial'])
        for name,r in winners.items():cases[f'latest-epoch-{epoch}-{name}']=(model,r['values'])
assert total_records==211;write(OUT/'runtime-winner-controls.json',runtime_controls);write(OUT/'complete-objective-controls.json',comparisons)

def args_for(vertices,other):
    v=np.asarray(vertices,dtype=float).reshape((-1,2));ll=shapely.linestrings(np.stack((v,np.roll(v,-1,axis=0)),axis=1)) if len(v) else np.empty(0,dtype=object)
    return [v],[ll],[other],[[0.,0.]]
square=[[0.,0.],[2.,0.],[2.,2.],[0.,2.]]
synthetic=[('no_pairs',([],[],[],[])),('no_edges',args_for([],Polygon(square))),('identical',args_for(square,Polygon(square))),('contained',args_for(square,Polygon([[-1,-1],[3,-1],[3,3],[-1,3]]))),('disjoint',args_for(square,Polygon([[3,0],[5,0],[5,2],[3,2]]))),('corner_touch',args_for(square,Polygon([[2,2],[4,2],[4,4],[2,4]]))),('shared_edge',args_for(square,Polygon([[2,0],[4,0],[4,2],[2,2]]))),('zero_length_edge',args_for([[0,0]]+square,Polygon(square)))]
synthetic_controls=[]
for name,args in synthetic:
    a=dense(*args);b=screened(*args);assert all(np.array_equal(x,y) for x,y in zip(a,b));error=None
    if args[0] and len(args[0][0]):
        rg,n,shared=moving_boundary_gradient(Polygon(args[0][0]),args[2][0],np.asarray(args[3][0]));error=float(np.max(np.abs(rg-b[0][0])))
        assert error<1e-6 and n==b[1][0] and shared==b[2][0]
    synthetic_controls.append({'case':name,'old_new_exact':True,'independent_scalar_error':error})
# A deliberately unsafe comparison drops boundary-touching edges of identical squares.
v,ll,others,pivots=args_for(square,Polygon(square));left=shapely.bounds(ll[0]);right=shapely.bounds(others)[0]
unsafe=(left[:,0]>=right[2])|(left[:,2]<=right[0])|(left[:,1]>=right[3])|(left[:,3]<=right[1])
assert np.all(unsafe) and dense(v,ll,others,pivots)[1][0]==4 and dense(v,ll,others,pivots)[2][0]==8
write(OUT/'boundary-policy-controls.json',{'passed':True,'controls':synthetic_controls,'unsafe_touching_exclusion_rejected_by_counts_and_coincidence':True})

negative=[];model=load(A/'model.json')
def corrupt(label,edit):
    bad=copy.deepcopy(model);edit(bad)
    try:verify(bad,lib,initial['modes'],initial['values'],initial['pair_weights'],identity)
    except AssertionError:negative.append(label)
    else:raise AssertionError('accepted corruption: '+label)
corrupt('missing_auxiliary_pair',lambda m:m['supplementary_objective']['pair_indices'].pop())
corrupt('changed_coefficient',lambda m:m['supplementary_objective']['identity']['auxiliary_policy'].__setitem__('coefficient',2))
corrupt('wrong_regions_digest',lambda m:m['supplementary_objective']['identity'].__setitem__('regions_sha256','0'*64))
corrupt('wrong_identity_digest',lambda m:m['supplementary_objective'].__setitem__('identity_sha256','0'*64))
corrupt('missing_area_pair',lambda m:m['pairs'].pop())
corrupt('changed_hard_bound',lambda m:m['bounds'][0].__setitem__(0,m['bounds'][0][0]-1))
corrupt('wrong_source_center',lambda m:m['owners'][0].__setitem__('source_center',[0,0]))
corrupt('zero_weight',lambda m:m['pair_weights'].__setitem__(0,0))
corrupt('wrong_initial_coordinate',lambda m:m['initial'].__setitem__(0,m['initial'][0]+1))
assert negative==load(A/'audit-v2/negative-controls.json');write(OUT/'negative-controls.json',negative)

timings=[]
for label,(model,point) in cases.items():
    expected=Old(model,regions,identity).evaluate(point,True)
    for sequence,kind in enumerate(['old','screened','screened','old']):
        before=time.perf_counter();obj=(Old if kind=='old' else New)(model,regions,identity);constructed=time.perf_counter();got=obj.evaluate(point,True);returned=time.perf_counter()
        assert got[0]==expected[0] and np.array_equal(got[1],expected[1]) and got[2]==expected[2]
        timings.append({'context':label,'sequence':sequence,'kind':kind,'construction_seconds':constructed-before,'complete_evaluation_seconds':returned-constructed,'construction_and_evaluation_seconds':returned-before,'all_fields_exact':True})
write(OUT/'timings.json',timings)
queue=paths.copy();bindings={};seen=set()
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.suffix!='.json':continue
    data=load(p)
    if not isinstance(data,dict):continue
    for name,h in {**data.get('inputs',{}),**data.get('preserved_inputs',{})}.items():
        q=ROOT/name;assert digest(q)==h,name;bindings[name]=h
        if q.name in ['plan.json','plan-v2.json','opened.json','source-cache-bindings.json','inherited-source-domains.json'] or q.name.endswith('process.json'):queue.append(q)
for p in paths:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'source-bindings.json',bindings)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'complete_objective_comparisons':len(comparisons),'source_legal_owner_modes':147,'runtime_records_with_independent_all81gradients':total_records,'all81scalar_gradient_cases':sum(r['independent_all81gradient_error_mm'] is not None for r in comparisons),'maximum_independent_score_error_mm2':max(r['independent_score_error_mm2'] for r in comparisons),'maximum_independent_gradient_error_mm':max(r['independent_all81gradient_error_mm'] or 0. for r in comparisons),'runtime_closed_calls':len(runs),'runtime_saved_points':sum(r['saved_points'] for r in runtime_controls),'runtime_winner_streams':3*len(runs),'interior_central_samples':len(central),'preserved_original_central_samples':324,'preserved_original_failed_samples':14,'finite_one_sided_enclosures':len(touching),'synthetic_kernel_cases':len(synthetic_controls),'unsafe_touching_exclusion_rejected':True,'model_corruptions_rejected':len(negative),'timing_contexts':len(cases),'timed_complete_evaluations':len(timings),'source_bindings':len(bindings),'closed_keys':23,'objective_identity_unchanged':True,'model_compilation_unchanged':True,'original_code_hashes_verified':len(identity['code_sha256']),'prior_preparation_seconds_retained':39.04916139948182,'new_source_model_prepared':False,'new_search_contract_prepared':False,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
