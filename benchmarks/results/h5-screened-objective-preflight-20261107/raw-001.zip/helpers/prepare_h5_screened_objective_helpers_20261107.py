"""Version implementation only; preserve mathematical identity and every closed key."""
from pathlib import Path
import ast,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
parent=ROOT/'benchmarks/results/h5-shared-source-construction-20261107'
assert json.loads((parent/'archive-checks.json').read_bytes())['passed']
variants=[
('h5_bbox_boundary_diagnostic_20261107.py','h5_screened_boundary_gradient_20261107.py',[
    ('Read-only candidate kernel: omit strictly disjoint edge/polygon boxes.','Exact clipped-edge integrals, skipping only strictly disjoint boxes.'),
    ('def screened_boundary_gradients(','def boundary_gradients(')]),
('h5_cross_pair_weighted_model_20261107.py','h5_screened_weighted_model_20261107.py',[
    ('from h5_cross_pair_boundary_gradient_20261107 import boundary_gradients','from h5_screened_boundary_gradient_20261107 import boundary_gradients')]),
('h5_bracket_augmented_objective_20261107.py','h5_screened_augmented_objective_20261107.py',[
    ('from h5_cross_pair_weighted_model_20261107 import','from h5_screened_weighted_model_20261107 import')]),
]
for old,new,changes in variants:
    text=(OUT/old).read_text(encoding='utf-8')
    for before,after in changes:
        assert before in text,before
        text=text.replace(before,after)
    ast.parse(text)
    with (OUT/new).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print('Prepared complete screened objective; no source model or optimizer opened.')
