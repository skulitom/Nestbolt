"""Exact clipped-edge integrals, skipping only strictly disjoint boxes."""
import numpy as np
import shapely
from h5_cross_pair_boundary_gradient_20261107 import integrate_groups

def boundary_gradients(vertices,lines,others,pivots,statistics=None):
    count=len(vertices);assert count==len(lines)==len(others)==len(pivots)
    if not count:return np.zeros((0,3)),np.zeros(0,dtype=np.int64),np.zeros(0)
    vertices=[np.asarray(v,dtype=float).reshape((-1,2)) for v in vertices]
    sizes=np.asarray([len(v) for v in vertices]);assert all(len(line)==n for line,n in zip(lines,sizes))
    if not np.sum(sizes):return np.zeros((count,3)),np.zeros(count,dtype=np.int64),np.zeros(count)
    starts=np.concatenate(vertices);edges=np.concatenate([np.roll(v,-1,axis=0)-v for v in vertices]);groups=np.repeat(np.arange(count),sizes);edge_pivots=np.asarray(pivots)[groups]
    flat_lines=np.concatenate(lines);other_array=np.asarray(others,dtype=object)
    left=shapely.bounds(flat_lines);right=shapely.bounds(other_array)[groups]
    # Keep touching boxes and any nonfinite bound; no tolerance or coordinate rounding.
    disjoint=(left[:,0]>right[:,2])|(left[:,2]<right[:,0])|(left[:,1]>right[:,3])|(left[:,3]<right[:,1])
    keep=~disjoint|~(np.all(np.isfinite(left),axis=1)&np.all(np.isfinite(right),axis=1))
    if statistics is not None:statistics.update(total_edges=len(keep),retained_edges=int(np.count_nonzero(keep)),omitted_edges=int(np.count_nonzero(~keep)))
    starts=starts[keep];edges=edges[keep];groups=groups[keep];edge_pivots=edge_pivots[keep];flat_lines=flat_lines[keep]
    clipped=shapely.intersection(flat_lines,other_array[groups]);shared=shapely.intersection(flat_lines,shapely.boundary(other_array)[groups])
    full,counts=integrate_groups(starts,edges,edge_pivots,groups,clipped,count)
    coincident,_=integrate_groups(starts,edges,edge_pivots,groups,shared,count)
    lengths=np.bincount(groups,weights=shapely.length(shared),minlength=count)
    return full-.5*coincident,counts,lengths
