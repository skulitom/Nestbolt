"""Resolve single-call timing variability with fixed complete saved trajectories."""
from pathlib import Path
from hashlib import sha256
import json,time,os
import numpy as np
from h5_bracket_augmented_objective_20261107 import Objective as Old
from h5_screened_augmented_objective_20261107 import Objective as New
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-screened-objective-preflight-20261107';OUT=BASE/'trajectory-timings';Z=ROOT/'output/h5-shared-source-preflight-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';B=ROOT/'output/h5-bracket-collision-depth-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();assert load(BASE/'checks.json')['passed'] and affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
identity=load(A/'objective-identity.json');regions=load(B/'regions.json')
paths=[Path(__file__),BASE/'checks.json',BASE/'plan.json',BASE/'timings.json',A/'objective-identity.json',B/'regions.json',Z/'response-audit/checks.json']+[Z/f'search/epoch-{e:02d}'/n for e in [0,1] for n in ['model.json','evaluations.jsonl','response.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'The earlier single-evaluation timing observations include variability and one regression. Measure each entire latest saved trajectory in fixed old/screened/screened/old batch order. One objective construction per batch; all saved points evaluated with full details and returned outputs retained. Input loading and post-batch exact equality/hash checks excluded; construction and complete sequential evaluation separately timed. No optimizer, changed model, seed or resume. Existing independent all-coordinate audit remains bound. Two samples per variant, no statistical or convergence claim.','trajectories':2,'records':98,'batch_order':['old','screened','screened','old'],'cap_seconds':120,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
timings=[];controls=[]
for epoch in [0,1]:
    E=Z/f'search/epoch-{epoch:02d}';model=load(E/'model.json');records=[json.loads(s) for s in (E/'evaluations.jsonl').read_text(encoding='utf-8').splitlines()];baseline=None
    for sequence,kind in enumerate(['old','screened','screened','old']):
        before=time.perf_counter();obj=(Old if kind=='old' else New)(model,regions,identity);constructed=time.perf_counter()
        values=[obj.evaluate(r['values'],True) for r in records];returned=time.perf_counter()
        if baseline is None:baseline=values
        hashes=[]
        for index,(r,v,w) in enumerate(zip(records,values,baseline)):
            assert r['evaluation']==index and v[0]==w[0]==r['augmented_objective_mm2'] and np.array_equal(v[1],w[1]) and np.array_equal(v[1],r['gradient']) and v[2]==w[2]
            for field in ['augmented_objective_mm2','original_overlap_area_mm2','unweighted_objective_mm2','weighted_area_objective_mm2','auxiliary_bracket_depth_mm2']:assert r[field]==v[2][field]
            canonical=json.dumps({'value':v[0],'gradient':v[1].tolist(),'details':v[2]},sort_keys=True,separators=(',',':'),allow_nan=False).encode();hashes.append(sha256(canonical).hexdigest())
        controls.append({'epoch':epoch,'sequence':sequence,'kind':kind,'records':len(records),'complete_output_sha256_by_evaluation':hashes,'all_fields_exact':True})
        timings.append({'epoch':epoch,'sequence':sequence,'kind':kind,'records':len(records),'construction_seconds':constructed-before,'complete_trajectory_evaluation_seconds':returned-constructed,'construction_and_evaluation_seconds':returned-before})
    print({'epoch':epoch,'four_complete_trajectories_verified':len(records)},flush=True)
summary=[]
for epoch in [0,1]:
    means={kind:sum(r['complete_trajectory_evaluation_seconds'] for r in timings if r['epoch']==epoch and r['kind']==kind)/2 for kind in ['old','screened']}
    summary.append({'epoch':epoch,'old_mean_seconds':means['old'],'screened_mean_seconds':means['screened'],'observed_mean_seconds_saved':means['old']-means['screened']})
write(OUT/'timings.json',timings);write(OUT/'exact-output-controls.json',controls)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'trajectories':2,'batches':8,'complete_evaluations_verified':sum(r['records'] for r in timings),'distinct_saved_records':98,'summary':summary,'single_call_regression_preserved':True,'statistical_significance_claimed':False,'packing_improvement_claimed':False,'optimizer_calls':0,'old_calls_resumed':False,'new_source_state_prepared':False,'H5_complete':False});print(load(OUT/'checks.json'))
