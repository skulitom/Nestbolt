"""Versioned exact-area objective plus the preflighted nominal bracket depth."""
import copy,json
from hashlib import sha256
import numpy as np
from h5_screened_weighted_model_20261107 import Objective as AreaObjective,compile_model as area_model
from h5_bracket_collision_depth_20261107 import Auxiliary

VERSION='weighted-original-clearance-plus-bracket-depth-v1-20261107'

def canonical_digest(value):
    return sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def compile_model(library,modes,values,weights,identity):
    model=area_model(library,modes,values,weights)
    model['supplementary_objective']={
        'identity':copy.deepcopy(identity),'identity_sha256':canonical_digest(identity),
        'pair_indices':[k for k,(i,j) in enumerate(model['pairs']) if model['owners'][i]['identity'][0]==model['owners'][j]['identity'][0]=='bracket'],
    }
    return model

def problem_key(physical,weights,identity):
    return canonical_digest({'physical':list(physical),'weights':weights,'objective_identity':identity})

class Objective(AreaObjective):
    def __init__(self,model,region_data,identity):
        super().__init__(model)
        metadata=model['supplementary_objective']
        assert metadata['identity']==identity and identity['version']==VERSION
        assert metadata['identity_sha256']==canonical_digest(identity)
        assert identity['auxiliary_policy']==region_data['policy']
        assert metadata['pair_indices']==[k for k,(i,j) in enumerate(model['pairs']) if model['owners'][i]['identity'][0]==model['owners'][j]['identity'][0]=='bracket']
        assert len(metadata['pair_indices'])==15
        self.auxiliary=Auxiliary(region_data)

    def score(self,values):
        return super().score(values)+self.auxiliary.evaluate(self.model,values)[0]

    def evaluate(self,values,details=False):
        area,g,info=super().evaluate(values,True)
        auxiliary,gg,records=self.auxiliary.evaluate(self.model,values)
        value=area+auxiliary;gradient=g+gg
        assert np.isfinite(value) and np.all(np.isfinite(gradient)) and auxiliary>=0
        if details:
            return value,gradient,{**info,'weighted_area_objective_mm2':area,'auxiliary_bracket_depth_mm2':auxiliary,'augmented_objective_mm2':value,'auxiliary_terms':records}
        return value,gradient
