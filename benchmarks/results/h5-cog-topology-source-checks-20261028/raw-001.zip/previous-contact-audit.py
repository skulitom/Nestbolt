"""Read every sampled source contact and all64 original placed outlines independently."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from collections import Counter
from itertools import product
import json,math,shutil,time
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-oblique64-source-20261028';SCAN=ROOT/'output/h5-cog-oblique-contacts-20261028';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for base in [BASE,SCAN]:
    for n,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
plan=load(SCAN/'plan.json');result=load(SCAN/'result.json');process=load(SCAN/'process.json');assert result['status']=='COMPLETE' and result['closed'] and result['scan_seconds']<60 and process['seconds']<90 and process['exit_code']==0 and not process['timeout']
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');cog=next(p for p in job['parts'] if p['id']=='cog');center=[139.723742,139.723742]
exact=[(F(x)-F(center[0]),F(y)-F(center[1])) for x,y in cog['geometry'][0]['outer']];assert len(exact)==80 and all(a[0]*b[1]-a[1]*b[0]>0 for a,b in zip(exact,exact[1:]+exact[:1]))
v=[(float(x),float(y)) for x,y in exact];basepoly=Polygon(v);assert basepoly.is_valid and basepoly.contains(__import__('shapely').geometry.Point(0,0))
phases=plan['phases_degrees'];directions=plan['contact_directions_degrees'];required=plan['required_gap_mm'];transformed={}
for phase,d in product(phases,directions):
    c,s=math.cos(math.radians(phase)),math.sin(math.radians(phase));u,w=math.cos(math.radians(d)),math.sin(math.radians(d))
    xy=[(u*(c*x-s*y)+w*(s*x+c*y),-w*(c*x-s*y)+u*(s*x+c*y)) for x,y in v]
    a=Polygon(xy);assert a.is_valid and abs(a.area-basepoly.area)<1e-7;transformed[phase,d]=xy
contacts=load(SCAN/'contacts.json');table={};gap_checks=0
for row in contacts:
    pa,pb,d=row['phase_a'],row['phase_b'],row['direction'];key=(pa,pb,d);assert key not in table;table[key]=row
    lo,hi=row['contact_lower_mm'],row['clear_upper_mm'];assert 240<=lo<hi<=281 and abs((hi-lo)-41/2**20)<1e-10
    a=Polygon(transformed[pa,d])
    lower=a.distance(Polygon([(x+lo,y) for x,y in transformed[pb,d]]));upper=a.distance(Polygon([(x+hi,y) for x,y in transformed[pb,d]]))
    assert abs(lower-row['lower_gap_mm'])<1e-8 and abs(upper-row['upper_gap_mm'])<1e-8 and lower<=required+1e-10<upper;gap_checks+=2
assert set(table)==set(product(phases,phases,directions)) and len(table)==3888
ranked=[]
for pa in phases:
    for pb in phases:
        if pa>pb:continue
        keys={(a,b,d) for a,b in [(pa,pb),(pb,pa)] for d in directions};critical=max(table[k]['clear_upper_mm'] for k in keys);D=math.ceil((critical+.001)*100)/100
        ranked.append({'phases_degrees':[pa,pb],'neighbor_pitch_mm':D,'critical_clear_upper_mm':critical,'verified_ordered_contact_cases':len(keys)})
ranked.sort(key=lambda r:(r['neighbor_pitch_mm'],r['critical_clear_upper_mm'],r['phases_degrees']));assert ranked==load(SCAN/'ranked-pairs.json') and ranked[0]==result['best']
rows=load(BASE/'source64.json');items=load(ROOT/'output/h5-source-orientation-construction-20261025/items.json');missing=load(BASE/'mandatory-two-brackets.json')
assert [(r['family'],r['copy']) for r in missing]==[('bracket',10),('bracket',11)]
expected=[(r['family'],r['copy']) for r in items if r not in missing];assert len(expected)==64
stocks={'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.4269023299994]};guard=3000*32*2**-23
assert abs(required-(job['clearance']+guard)/math.cos(.05))<1e-15
readback=audit(job,rows,stocks,required,guard,expected=expected);write(OUT/'source64-readback.json',readback)
spec=load(ROOT/'output/h5-eight-bracket-short-core-20261026/audit-horizontal-mode-repaired/next-neighborhood.json');bykey={(r['part_id'],r['copy_index']):r for r in rows}
for r in spec['fixed_first_placements']+spec['fixed_short_placements']:assert bykey[r['part_id'],r['copy_index']]==r
packet=[r for r in rows if r['part_id']=='cog'];assert len(packet)==15 and all(r['sheet_id']=='sheet-0' for r in packet)
assert len(load(BASE/'fixed49-noncogs.json'))==49 and load(BASE/'fixed49-noncogs.json')==[r for r in rows if r['part_id']!='cog']
assert len(load(BASE/'moving17.json'))==17
counts={sheet:dict(Counter(r['part_id'] for r in rows if r['sheet_id']==sheet)) for sheet in stocks}
summary={k:v for k,v in readback.items() if k not in ['pairs','stock']}
write(OUT/'checks.json',{'passed':readback['valid'],'seconds':time.perf_counter()-start,'contact_cases_verified':len(table),'direct_original_contact_gap_checks':gap_checks,
 'ranked_complete_phase_pairs_verified':len(ranked),'source_star_kernel_edges_verified':80,'no_rotational_symmetry_assumed':True,
 'fixed42_original_placements_unchanged':True,'all15_cogs_and21_inserts_placed':True,'source64_summary':summary,'sheet_family_counts':counts,
 'mandatory_unplaced_originals':[['bracket',10],['bracket',11]],'full66_target_witness':False,'new_fixed49_exclusion_claimed':False,
 'old_position_dependent_proofs_not_transferred':True,'external_solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'));assert readback['valid']
