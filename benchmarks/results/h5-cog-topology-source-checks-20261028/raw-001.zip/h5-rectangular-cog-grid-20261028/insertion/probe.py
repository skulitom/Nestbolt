"""One bounded fixed-neighbour insertion sequence for the new aligned-row topology."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rectangular-cog-grid-20261028';OUT=BASE/'insertion'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    import math
    from shapely.geometry import Polygon,mapping,shape
    from shapely.affinity import affine_transform,translate
    import diagnose_h5_concave_gaps as geom
    geom.EPS=.0126;job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']}
    rows=load(BASE/'source58.json');required=.21170867250963943;start=time.perf_counter();records=[];placed=[];modes=[]
    def world(r):
        t=r['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1
        return affine_transform(Polygon(parts[r['part_id']]['geometry'][0]['outer']),[m*c,-s,m*s,c,*t['translation']])
    for family in ['bracket','insert']:
        for mirror in ([False,True] if family=='bracket' else [False]):
            for q in (range(4) if family=='bracket' else range(2)):
                a=q*math.pi/2;c,s=math.cos(a),math.sin(a);m=-1 if mirror else 1
                raw=affine_transform(Polygon(parts[family]['geometry'][0]['outer']),[m*c,-s,m*s,c,0,0]);offset=[-raw.bounds[0],-raw.bounds[1]]
                modes.append({'mode':len(modes),'family':family,'angle':a,'mirrored':mirror,'source_offset':offset,'geometry':mapping(translate(raw,*offset))})
    write(OUT/'modes.json',modes);step=0
    for family,copies in [('bracket',range(7,12)),('insert',range(18,21))]:
        for copy in copies:
            folder=OUT/f'step-{step}';folder.mkdir();fixed=[world(r) for r in rows if r['sheet_id']=='sheet-0'];candidates=[];region_rows=[]
            write(folder/'fixed-rows.json',[r for r in rows if r['sheet_id']=='sheet-0'])
            for mode in [m for m in modes if m['family']==family]:
                free=geom.regions(shape(mode['geometry']),fixed,job['stocks'][0],job['edge_clearance'],required)
                assert free.is_valid;write(folder/f'mode-{mode["mode"]}.json',mapping(free));components=geom.polygons(free)
                region_rows.append({'step':step,'family':family,'copy_index':copy,'mode':mode['mode'],'empty':free.is_empty,'area_mm2':free.area,'components':len(components)})
                for index,component in enumerate(components):
                    point=component.representative_point();candidates.append({'mode':mode['mode'],'component':index,'area_mm2':component.area,'anchor':list(point.coords)[0]})
            write(folder/'regions.json',region_rows);write(folder/'candidates.json',candidates);records.extend(region_rows);step+=1
            if not candidates:break
            chosen=sorted(candidates,key=lambda r:(-r['area_mm2'],r['mode'],r['component']))[0];mode=modes[chosen['mode']]
            row={'part_id':family,'copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':mode['angle'],'mirrored':mode['mirrored'],
                'translation':[chosen['anchor'][k]+mode['source_offset'][k] for k in [0,1]]}}
            assert min(world(row).distance(p) for p in fixed)>required
            rows.append(row);placed.append({'family':family,'copy_index':copy,'step':step-1,'choice':chosen,'row':row});write(folder/'chosen.json',placed[-1])
    write(OUT/'regions.json',records);write(OUT/'placed.json',placed);write(OUT/'source-candidate.json',rows)
    expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};missing=expected-{(r['part_id'],r['copy_index']) for r in rows}
    write(OUT/'result.json',{'seconds':time.perf_counter()-start,'closed':True,'region_calculations':len(records),'originals':len(rows),
        'inserted_originals':len(placed),'unplaced_originals':[list(k) for k in sorted(missing)],'actual_infeasibility_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'probe.py');assert load(BASE/'audit/checks.json')['passed'];start=time.perf_counter()
    inputs=[BASE/'plan.json',BASE/'source58.json',BASE/'audit/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/diagnose_h5_concave_gaps.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'maximum_shared_seconds':120,'maximum_region_calculations':46,'maximum_runs':1,'retry_permitted':False,
        'method':'One deterministic insertion sequence against the newly source-valid aligned cog grid. Try brackets7..11 first, each using all8 legal modes; then inserts18..20 using the2 occupied-outer classes (0/90degrees). At each step retain every conservative region and component representative point, choose largest component area with mode/index tie breaking, insert its representative point and reconstruct neighbours. Stop a family on its first empty step, then continue to the other family. At most46 region calculations, unchanged pair requirement0.21170867250963943 and conservative EPS0.0126mm. No repositioning, backtracking, optimizer, seed, retry or native call. Empty conservative regions and any incomplete result have no actual/global infeasibility implication. Independently audit all final original source geometry and missing-copy accounting.'})
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=max(.01,120-(time.perf_counter()-start)))
        (OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);process={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',process);print(process);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final result; call remains closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
