"""Read the finite insertion trace and every original source ring independently."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil
from shapely.geometry import Polygon,shape,Point
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rectangular-cog-grid-20261028';SEARCH=BASE/'insertion';OUT=SEARCH/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
for n,h in load(SEARCH/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
process=load(SEARCH/'process.json');result=load(SEARCH/'result.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<120
assert result['closed'] and result['region_calculations']<=46
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(SEARCH/'modes.json')
assert len(modes)==10
for family,expected in [('bracket',{(q*math.pi/2,m) for q in range(4) for m in [False,True]}),('insert',{(0,False),(math.pi/2,False)})]:
    assert {(m['angle'],m['mirrored']) for m in modes if m['family']==family}==expected
for i,m in enumerate(modes):
    c,s=math.cos(m['angle']),math.sin(m['angle']);sign=-1 if m['mirrored'] else 1;tx,ty=m['source_offset']
    original=Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in parts[m['family']]['geometry'][0]['outer']])
    assert i==m['mode'] and original.equals_exact(shape(m['geometry']),1e-10)
    assert max(abs(original.bounds[k]) for k in [0,1])<1e-10
current=load(BASE/'source58.json');verified_regions=[];verified_choices=[];representatives=0;empty_steps=[]
folders=sorted(SEARCH.glob('step-*'),key=lambda p:int(p.name.split('-')[-1]))
assert [p.name for p in folders]==[f'step-{i}' for i in range(len(folders))]
for step,folder in enumerate(folders):
    assert load(folder/'fixed-rows.json')==[r for r in current if r['sheet_id']=='sheet-0']
    rr=load(folder/'regions.json');candidates=load(folder/'candidates.json');family=rr[0]['family'];copy=rr[0]['copy_index']
    assert {r['mode'] for r in rr}=={m['mode'] for m in modes if m['family']==family}
    components={}
    for row in rr:
        assert row['step']==step and row['family']==family and row['copy_index']==copy
        free=shape(load(folder/f'mode-{row["mode"]}.json'));assert free.is_valid and free.is_empty==row['empty'] and free.area==row['area_mm2']
        polys=[] if free.is_empty else [free] if free.geom_type=='Polygon' else list(free.geoms)
        assert all(p.geom_type=='Polygon' for p in polys) and len(polys)==row['components'];components[row['mode']]=polys
    assert len(candidates)==sum(len(v) for v in components.values())
    assert {(c['mode'],c['component']) for c in candidates}=={(m,i) for m,v in components.items() for i in range(len(v))}
    for candidate in candidates:
        p=components[candidate['mode']][candidate['component']];assert p.area==candidate['area_mm2'] and p.contains(Point(candidate['anchor']));representatives+=1
    if candidates:
        chosen=load(folder/'chosen.json');assert chosen['choice']==sorted(candidates,key=lambda r:(-r['area_mm2'],r['mode'],r['component']))[0]
        assert chosen['family']==family and chosen['copy_index']==copy and chosen['step']==step
        m=modes[chosen['choice']['mode']];anchor=chosen['choice']['anchor']
        assert chosen['row']=={'part_id':family,'copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],
            'translation':[anchor[k]+m['source_offset'][k] for k in [0,1]]}}
        current.append(chosen['row']);verified_choices.append(chosen)
    else:assert all(r['empty'] for r in rr);empty_steps.append({'step':step,'family':family,'copy_index':copy})
    verified_regions+=rr
assert load(SEARCH/'regions.json')==verified_regions and load(SEARCH/'placed.json')==verified_choices
assert len(verified_regions)==result['region_calculations'] and len(verified_choices)==result['inserted_originals']
assert [(r[0]['family'],r[0]['copy_index']) for r in [load(f/'regions.json') for f in folders]]==[('bracket',7),('bracket',8),('insert',18),('insert',19),('insert',20)]
assert current==load(SEARCH/'source-candidate.json') and len(current)==result['originals']
expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};actual={(r['part_id'],r['copy_index']) for r in current}
missing=expected-actual;assert result['unplaced_originals']==[list(k) for k in sorted(missing)]
readback=audit(job,current,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},.21170867250963943,.011444091796875,expected-missing)
write(OUT/'source-readback.json',readback);assert readback['valid']
write(OUT/'checks.json',{'passed':True,'source_modes_verified':10,'region_records_verified':len(verified_regions),'representative_points_verified':representatives,
    'deterministic_choices_verified':len(verified_choices),'empty_family_steps':empty_steps,'source_originals':len(current),'source_valid':True,
    'source_pairs_verified':readback['same_sheet_pairs'],'source_stock_edges':readback['stock_edges'],'original_holes':readback['cutouts'],'hole_vertices':readback['hole_vertices'],
    'minimum_pair_gap_mm':readback['minimum_pair_gap_mm'],'minimum_extra_stock_mm':readback['minimum_extra_stock_mm'],'unplaced_originals':result['unplaced_originals'],
    'shared_seconds':process['seconds'],'actual_fixed_grid_infeasibility_claimed':False,'full66_exclusion_claimed':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
