"""Direct square-grid construction, independently checked before any insertion."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-rectangular-cog-grid-20261028'
SOURCE=ROOT/'output/h5-short7-7-source-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py')
inputs=[JOB,SOURCE/'source63.json',SOURCE/'audit/checks.json',ROOT/'output/h5-triangular-phase-model-20261028/source-packet-audit/checks.json',ROOT/'output/h5-oblique64-source-20261028/audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'One explicit new row topology: fifteen original cogs in three aligned rows of five, spacing258.86mm in both axes, each at7degrees. No contact scan, phase symmetry assumption, optimization, retry or rerun of any closed call. Retain the29 frame/side-insert core and14 short originals from source63. Translate the new cog packet to lower-left[6.525,2107.875], anchoring it on the left to leave a continuous right strip. Independently check all58 originals and all original holes, modes, filled-outline pairs and unchanged stock guards before any subsequent fixed-neighbour construction. The missing originals are brackets7..11 and inserts18..20. No full66 or native claim.'})
assert load(SOURCE/'audit/checks.json')['passed']
old=load(SOURCE/'source63.json');rows=[r for r in old if r['sheet_id']=='sheet-1' or (r['sheet_id']=='sheet-0' and (r['part_id']=='frame' or (r['part_id']=='insert' and 5<=r['copy_index']<=15)))]
assert len(rows)==43
cog=next(p for p in load(JOB)['parts'] if p['id']=='cog');a=math.radians(7);c,s=math.cos(a),math.sin(a);center=139.723742
raw=[(c*(x-center)-s*(y-center),s*(x-center)+c*(y-center)) for x,y in cog['geometry'][0]['outer']]
offset=[6.525-min(x for x,y in raw),2107.875-min(y for x,y in raw)]
for i in range(15):
    row,col=divmod(i,5);x=offset[0]+col*258.86;y=offset[1]+row*258.86
    rows.append({'part_id':'cog','copy_index':i,'sheet_id':'sheet-0','transform':{'rotation_radians':a,'mirrored':False,'translation':[x-c*center+s*center,y-s*center-c*center]}})
write(OUT/'source58.json',rows)
write(OUT/'constructed.json',{'originals':58,'source_validity_pending':True,'missing_originals':[['bracket',i] for i in range(7,12)]+[['insert',i] for i in range(18,21)],'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'constructed.json'))
