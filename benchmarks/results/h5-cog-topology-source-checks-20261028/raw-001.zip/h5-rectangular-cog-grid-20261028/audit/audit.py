"""Independent original-ring readback of the aligned cog grid and preserved cores."""
from pathlib import Path
from hashlib import sha256
import json,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rectangular-cog-grid-20261028';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');rows=load(BASE/'source58.json');old=load(ROOT/'output/h5-short7-7-source-20261028/source63.json')
retained=[r for r in old if r['sheet_id']=='sheet-1' or (r['sheet_id']=='sheet-0' and (r['part_id']=='frame' or (r['part_id']=='insert' and 5<=r['copy_index']<=15)))]
assert len(retained)==43 and rows[:43]==retained
missing={('bracket',i) for i in range(7,12)}|{('insert',i) for i in range(18,21)}
expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}-missing
readback=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},.21170867250963943,.011444091796875,expected)
write(OUT/'source-readback.json',readback)
write(OUT/'checks.json',{'passed':readback['valid'],'originals':len(rows),'unchanged_core_originals':43,'same_sheet_pairs':readback['same_sheet_pairs'],
    'stock_edges':readback['stock_edges'],'holes':readback['cutouts'],'hole_vertices':readback['hole_vertices'],'minimum_pair_gap_mm':readback['minimum_pair_gap_mm'],
    'minimum_extra_stock_mm':readback['minimum_extra_stock_mm'],'missing_originals':[list(k) for k in sorted(missing)],'full66_witness':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'));assert readback['valid']
