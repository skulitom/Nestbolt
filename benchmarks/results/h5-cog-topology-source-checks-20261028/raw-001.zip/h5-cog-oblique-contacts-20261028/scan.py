"""One bounded original-source contact scan for a constructive oblique cog packet."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog-oblique-contacts-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
class Budget(Exception):pass
def child():
    from shapely.geometry import Polygon
    from shapely.affinity import translate
    plan=load(OUT/'plan.json');job=load(JOB);part=next(p for p in job['parts'] if p['id']=='cog');center=[139.723742,139.723742]
    vertices=[(x-center[0],y-center[1]) for x,y in part['geometry'][0]['outer']];required=plan['required_gap_mm'];start=time.perf_counter();deadline=start+60
    assert all(a[0]*b[1]-a[1]*b[0]>0 for a,b in zip(vertices,vertices[1:]+vertices[:1]))
    phases=plan['phases_degrees'];directions=plan['contact_directions_degrees'];shapes={}
    for direction in directions:
        for phase in phases:
            a=math.radians(phase-direction);c,s=math.cos(a),math.sin(a);g=Polygon([(c*x-s*y,s*x+c*y) for x,y in vertices]);assert g.is_valid and g.contains(Polygon(vertices).centroid);shapes[direction,phase]=g
    rows=[];calls=0;status='COMPLETE';best=None
    def distance(a,b,d):
        nonlocal calls
        if time.perf_counter()>=deadline:raise Budget()
        calls+=1;return a.distance(translate(b,xoff=d))
    try:
        for ia,pa in enumerate(phases):
            for ib,pb in enumerate(phases):
                for direction in directions:
                    a,b=shapes[direction,pa],shapes[direction,pb];lo,hi=240.,281.
                    assert distance(a,b,lo)<required and distance(a,b,hi)>required
                    for _ in range(20):
                        mid=(lo+hi)/2
                        if distance(a,b,mid)>required:hi=mid
                        else:lo=mid
                    low_gap=distance(a,b,lo);high_gap=distance(a,b,hi);assert low_gap<=required<high_gap
                    rows.append({'phase_a':pa,'phase_b':pb,'direction':direction,'contact_lower_mm':lo,'clear_upper_mm':hi,'lower_gap_mm':low_gap,'upper_gap_mm':high_gap})
    except Budget:status='TIME_LIMIT'
    scan_seconds=time.perf_counter()-start;write(OUT/'contacts.json',rows)
    table={(r['phase_a'],r['phase_b'],r['direction']):r for r in rows};candidates=[]
    for pa in phases:
        for pb in phases:
            if pa>pb:continue
            keys={(a,b,d) for a,b in [(pa,pb),(pb,pa)] for d in directions}
            if all(k in table for k in keys):
                critical=max(table[k]['clear_upper_mm'] for k in keys);pitch=math.ceil((critical+.001)*100)/100
                candidates.append({'phases_degrees':[pa,pb],'neighbor_pitch_mm':pitch,'critical_clear_upper_mm':critical,'verified_ordered_contact_cases':len(keys)})
    candidates.sort(key=lambda r:(r['neighbor_pitch_mm'],r['critical_clear_upper_mm'],r['phases_degrees']));write(OUT/'ranked-pairs.json',candidates)
    if candidates:best=candidates[0]
    write(OUT/'result.json',{'status':status,'closed':True,'scan_seconds':scan_seconds,'distance_evaluations':calls,'contact_cases_completed':len(rows),
     'expected_contact_cases':len(phases)**2*len(directions),'complete_phase_pair_candidates':len(candidates),'best':best,
     'one_finite_angle_subset_only':True,'no_rotational_symmetry_used_to_skip_cases':True,'source_packet_audit_pending':True,
     'external_solver_calls':0,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'scan.py')
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{JOB.relative_to(ROOT).as_posix():digest(JOB)},'phases_degrees':[i*.5 for i in range(36)],
     'contact_directions_degrees':[0,72,108],'required_gap_mm':.21170867250963943,'maximum_scan_seconds':60,'maximum_shared_seconds':90,
     'maximum_runs':1,'retry_permitted':False,'bisection_steps':20,'method':'Scan exactly the declared36 original-source angles, all1296 ordered pairs and all three directed contacts0,72,108 degrees. This is a finite constructive angle subset; no symmetry is used to exclude untested angles or skip source cases. Rotate both original polygons by minus the contact direction and bracket the outward collision exit on240..281mm with20 bisections. Original cog outer polygons have the origin in their kernel; their difference plus the clearance disk is star-shaped, so each ray intersects the forbidden set in one initial interval. Recheck lower/upper gaps directly. Rank only phase pairs with every required directed/order case complete, using the ceiling to0.01mm of the maximum clear upper bracket plus0.001mm. A resulting5-column/3-row packet still needs all105 original pair checks and source/stock readback. No existing closed search is restarted and no full-layout/quality/native claim is made.'})
    t=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90)
        (OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'seconds':time.perf_counter()-t,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-t,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed result; scan closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
