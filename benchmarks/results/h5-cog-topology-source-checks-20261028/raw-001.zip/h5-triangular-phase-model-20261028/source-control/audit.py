"""Independent all-pair original-source positive control for the lattice model."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-triangular-phase-model-20261028';OUT=BASE/'source-control'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');assert load(BASE/'model-audit/checks.json')['passed']
control=load(BASE/'uniform-phase-control.json');pitch=control['packet_pitch_centimm']/100;job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json')
part=next(p for p in job['parts'] if p['id']=='cog');center=139.723742;polys=[]
for i in range(15):
    r,c=divmod(i,5);x=(c+.5*(r%2))*pitch;y=r*math.sqrt(3)/2*pitch;a=math.radians(control[f'phase_{i}']*.5);co,si=math.cos(a),math.sin(a)
    g=Polygon([(co*(u-center)-si*(v-center)+x,si*(u-center)+co*(v-center)+y) for u,v in part['geometry'][0]['outer']]);assert g.is_valid;polys.append(g)
checks=[]
for i,j in combinations(range(15),2):
    gap=polys[i].distance(polys[j]);assert polys[i].disjoint(polys[j]) and gap>.21170867250963943;checks.append({'cogs':[i,j],'gap_mm':gap})
write(OUT/'pairs.json',checks)
write(OUT/'checks.json',{'passed':True,'original_cogs':15,'source_pairs_verified':105,'minimum_source_gap_mm':min(r['gap_mm'] for r in checks),
    'uniform_phase_degrees':7,'control_pitch_mm':pitch,'stock_fit_claimed':False,'model_sha256':digest(BASE/'model.pb'),
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
