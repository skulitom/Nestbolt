"""Reconstruct all original cog outlines; report actual stock dimensions without a fit claim."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-triangular-phase-model-20261028';OUT=BASE/'source-packet-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');assert load(BASE/'response-audit/checks.json')['passed']
selected=load(BASE/'response-audit/selected-poses.json');pitch=selected['pitch_centimm']/100
jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';job=load(jobpath)
part=next(p for p in job['parts'] if p['id']=='cog');center=139.723742;polys=[];holes=[];rows=[]
for n in selected['nodes']:
    x=n['x_twice']*pitch/2;y=n['y_row']*math.sqrt(3)*pitch/2;a=math.radians(n['rotation_degrees']);co,si=math.cos(a),math.sin(a)
    tr=[x-co*center+si*center,y-si*center-co*center]
    transform=lambda ring:[(co*u-si*v+tr[0],si*u+co*v+tr[1]) for u,v in ring]
    g=Polygon(transform(part['geometry'][0]['outer']));assert g.is_valid;polys.append(g)
    for ring in part['geometry'][0].get('holes',[]):
        h=Polygon(transform(ring));assert h.is_valid and g.contains(h);holes.append({'cog':n['index'],'vertices':len(ring),'area_mm2':h.area})
    rows.append({'part_id':'cog','copy_index':n['index'],'sheet_id':'packet-local','transform':{'rotation_radians':a,'translation':tr,'mirrored':False}})
pairs=[]
for i,j in combinations(range(15),2):
    gap=polys[i].distance(polys[j]);assert polys[i].disjoint(polys[j]) and gap>.21170867250963943;pairs.append({'cogs':[i,j],'gap_mm':gap})
bbox=[min(g.bounds[0] for g in polys),min(g.bounds[1] for g in polys),max(g.bounds[2] for g in polys),max(g.bounds[3] for g in polys)]
width=bbox[2]-bbox[0];height=bbox[3]-bbox[1];available_width=1493.475-6.525
write(OUT/'source15-local.json',rows);write(OUT/'pairs.json',pairs);write(OUT/'holes.json',holes)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [jobpath,BASE/'response-audit/checks.json',BASE/'response-audit/selected-poses.json']}})
write(OUT/'checks.json',{'passed':True,'source_pairs_verified':105,'original_cogs':15,'original_holes_verified':len(holes),
    'original_hole_vertices_verified':sum(h['vertices'] for h in holes),'minimum_source_gap_mm':min(p['gap_mm'] for p in pairs),
    'bbox_mm':bbox,'width_mm':width,'height_mm':height,'available_stock_width_with_guard_mm':available_width,
    'fits_stock_width':width<=available_width,'excess_width_mm':max(0.,width-available_width),
    'stock_placement_created':False,'full66_exclusion_claimed':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
