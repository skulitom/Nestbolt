"""One predeclared finite phase-assignment model for a15-cog triangular packet."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SCAN=ROOT/'output/h5-cog-triangular-contacts-20261028';OUT=ROOT/'output/h5-triangular-phase-model-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');check=load(SCAN/'audit/checks.json');assert check['passed']
assert digest(SCAN/'audit/pitch-thresholds.json')==check['thresholds_sha256']
inputs=[SCAN/'plan.json',SCAN/'contacts.json',SCAN/'audit/checks.json',SCAN/'audit/pitch-thresholds.json',
    ROOT/'output/h5-short7-7-source-20261028/source63.json',ROOT/'output/h5-short7-7-source-20261028/audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'solver_seconds':60,'shared_process_seconds':90,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],
    'maximum_calls':1,'retry_permitted':False,'method':'Constructive finite phase assignment on a fixed5-column/3-row equilateral staggered lattice. All15 cogs are mandatory, each independently choosing one of36 legal source rotations0..17.5degrees; no symmetry reduction or source-angle exclusion. The common nearest-neighbour pitch is the maximum of30 audited directed source thresholds, rounded upward to0.01mm with an extra0.001mm before rounding. Minimize that pitch over the finite assignment. No stock fit, bracket fit or full66 claim follows from a solver result. Before one60-second four-worker call inside90seconds shared, independently audit every serialized variable, table and max/objective plus one uniform-phase source control. After a solution, reconstruct original sources and directly check all105 pairs and the actual bounding box before using the packet. No old phase7 local/source/scan run is restarted.'})
thresholds=load(SCAN/'audit/pitch-thresholds.json');lookup={(r['phase_a_index'],r['phase_b_index'],r['direction']):r['minimum_pitch_centimm'] for r in thresholds}
tables={d:[[a,b,lookup[a,b,d]] for a in range(36) for b in range(36)] for d in [0,60,120]}
nodes=[{'index':row*5+col,'row':row,'column':col,'x_twice':2*col+row%2,'y_row':row} for row in range(3) for col in range(5)]
edges=[]
for a in nodes:
    for b in nodes[a['index']+1:]:
        dx=b['x_twice']-a['x_twice'];dy=b['row']-a['row'];direction=0 if dy==0 and dx==2 else 60 if dy==1 and dx==1 else 120 if dy==1 and dx==-1 else None
        if direction is not None:edges.append({'a':a['index'],'b':b['index'],'direction':direction})
assert len(edges)==30
m=cp_model.CpModel();phases=[m.new_int_var(0,35,f'phase_{i}') for i in range(15)];costs=[];records=[]
for i,e in enumerate(edges):
    values=[r[2] for r in tables[e['direction']]];cost=m.new_int_var(min(values),max(values),f'edge_pitch_{i}')
    ct=m.add_allowed_assignments([phases[e['a']],phases[e['b']],cost],tables[e['direction']]);costs.append(cost)
    records.append({**e,'cost_variable':cost.index,'table_constraint':ct.index})
pitch=m.new_int_var(min(r['minimum_pitch_centimm'] for r in thresholds),max(r['minimum_pitch_centimm'] for r in thresholds),'packet_pitch_centimm')
maximum=m.add_max_equality(pitch,costs);m.minimize(pitch)
assert m.validate()=='' and m.export_to_file(str(OUT/'model.pb')) and m.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'nodes':nodes,'phase_variables':[p.index for p in phases],'edges':records,'pitch_variable':pitch.index,'maximum_constraint':maximum.index})
control={p.name:14 for p in phases}
for e,c in zip(edges,costs):control[c.name]=lookup[14,14,e['direction']]
control[pitch.name]=max(control[c.name] for c in costs);write(OUT/'uniform-phase-control.json',control)
write(OUT/'built.json',{'variables':len(m.proto.variables),'constraints':len(m.proto.constraints),'mandatory_cogs':15,
    'directed_edges':len(edges),'table_rows':30*1296,'uniform_control_pitch_mm':control[pitch.name]/100,
    'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
