"""Independent full model readback, including every directed allowed-table entry."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-triangular-phase-model-20261028';SCAN=ROOT/'output/h5-cog-triangular-contacts-20261028';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def fields(p,allowed):assert {f.name for f,v in p.ListFields()}<=set(allowed)
def expr(e,variable):
    fields(e,['vars','coeffs']);assert list(e.vars)==[variable] and list(e.coeffs)==[1] and e.offset==0
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SCAN/'audit/checks.json')['passed']
thresholds=load(SCAN/'audit/pitch-thresholds.json');lookup={(r['phase_a_index'],r['phase_b_index'],r['direction']):r['minimum_pitch_centimm'] for r in thresholds}
assert len(lookup)==3888
mp=load(BASE/'mapping.json');nodes=[{'index':r*5+c,'row':r,'column':c,'x_twice':2*c+r%2,'y_row':r} for r in range(3) for c in range(5)]
assert mp['nodes']==nodes and mp['phase_variables']==list(range(15));edges=[];far=[]
for a,b in combinations(nodes,2):
    dx=b['x_twice']-a['x_twice'];dy=b['row']-a['row'];distance4=dx*dx+3*dy*dy
    if distance4==4:
        direction=0 if dy==0 else 60 if dx>0 else 120;edges.append({'a':a['index'],'b':b['index'],'direction':direction})
    else:assert distance4>=12;far.append([a['index'],b['index']])
assert len(edges)==30 and len(far)==75
p=cp_model_pb2.CpModelProto();p.ParseFromString((BASE/'model.pb').read_bytes());fields(p,['variables','constraints','objective'])
assert len(p.variables)==46 and len(p.constraints)==31
def var(ix,name,domain):
    v=p.variables[ix];fields(v,['name','domain']);assert v.name==name and list(v.domain)==domain
for i in range(15):var(i,f'phase_{i}',[0,35])
assert len(mp['edges'])==30;control=load(BASE/'uniform-phase-control.json')
assert all(control[f'phase_{i}']==14 for i in range(15))
for i,(e,saved) in enumerate(zip(edges,mp['edges'])):
    assert saved=={**e,'cost_variable':15+i,'table_constraint':i}
    table=[[a,b,lookup[a,b,e['direction']]] for a in range(36) for b in range(36)];values=[r[2] for r in table]
    var(15+i,f'edge_pitch_{i}',[min(values),max(values)])
    ct=p.constraints[i];fields(ct,['table']);assert ct.WhichOneof('constraint')=='table'
    fields(ct.table,['values','exprs']);assert not ct.table.negated and len(ct.table.exprs)==3
    for expression,variable in zip(ct.table.exprs,[e['a'],e['b'],15+i]):expr(expression,variable)
    assert list(ct.table.values)==[value for row in table for value in row]
    assert control[f'edge_pitch_{i}']==lookup[14,14,e['direction']]
var(45,'packet_pitch_centimm',[min(lookup.values()),max(lookup.values())]);assert mp['pitch_variable']==45 and mp['maximum_constraint']==30
ct=p.constraints[30];fields(ct,['lin_max']);fields(ct.lin_max,['target','exprs']);expr(ct.lin_max.target,45)
assert len(ct.lin_max.exprs)==30
for i,e in enumerate(ct.lin_max.exprs):expr(e,15+i)
fields(p.objective,['vars','coeffs','scaling_factor']);assert list(p.objective.vars)==[45] and list(p.objective.coeffs)==[1] and p.objective.scaling_factor==1 and p.objective.offset==0
assert set(control)=={v.name for v in p.variables}
assert control['packet_pitch_centimm']==max(control[f'edge_pitch_{i}'] for i in range(30))
for v in p.variables:assert v.domain[0]<=control[v.name]<=v.domain[-1]
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':46,'constraints_verified':31,
    'allowed_table_rows_verified':38880,'mandatory_cog_phases':15,'legal_phases_per_cog':36,
    'directed_nearest_neighbours_verified':30,'non_nearest_pairs_verified':75,'uniform_control_assignment_valid':True,
    'no_hints_assumptions_or_fixed_phases':True,'finite_construction_only':True,'model_sha256':digest(BASE/'model.pb'),
    'mapping_sha256':digest(BASE/'mapping.json'),'plan_sha256':digest(BASE/'plan.json'),
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
