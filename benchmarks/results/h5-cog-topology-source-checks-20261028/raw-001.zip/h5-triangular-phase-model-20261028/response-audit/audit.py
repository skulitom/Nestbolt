"""Read the saved response and every incumbent independently of the solver API."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-triangular-phase-model-20261028';SEARCH=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
ma=load(BASE/'model-audit/checks.json');assert ma['passed']
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
process=load(SEARCH/'process.json');result=load(SEARCH/'result.json');opened=load(SEARCH/'opened.json')
assert not process['timeout'] and process['exit_code']==0 and process['seconds']<90
assert result['solver_calls']==1 and result['closed'] and opened['maximum_calls']==1
assert opened['model_audit_sha256']==digest(BASE/'model-audit/checks.json')
assert opened['source_control_sha256']==digest(BASE/'source-control/checks.json')
assert digest(SEARCH/'model.pb')==digest(BASE/'model.pb')==ma['model_sha256']==opened['model_sha256']
params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
assert params.max_time_in_seconds==60 and params.num_search_workers==4 and params.random_seed==0
assert list(params.ignore_subsolvers)==['fj'] and params.log_search_progress and not params.log_to_stdout
assert {f.name for f,v in params.ListFields()}==set(opened['parameters'])
p=cp_model_pb2.CpModelProto();p.ParseFromString((SEARCH/'model.pb').read_bytes())
r=cp_model_pb2.CpSolverResponse();r.ParseFromString((SEARCH/'response.pb').read_bytes())
status=cp_model_pb2.CpSolverStatus.Name(r.status);assert status==result['status']
assert r.wall_time==result['solver_wall_seconds'] and r.num_branches==result['returned_response_branches']
assert r.num_conflicts==result['returned_response_conflicts'] and bool(r.solution)==result['has_solution']
assert bool(r.solution)==(status in ['OPTIMAL','FEASIBLE'])
assert r.objective_value==result['objective_centimm'] and r.best_objective_bound==result['best_bound_centimm']
log=(SEARCH/'solver.log').read_text(encoding='utf-8');assert f'status: {status}' in log
printed=Decimal(re.search(r'^walltime: ([0-9.e+-]+)$',log,re.M).group(1))
assert abs(printed-Decimal(str(r.wall_time)))<=Decimal(5).scaleb(printed.as_tuple().exponent-1)+Decimal('1e-12')
assert result['returned_soft_overrun_seconds']==max(0.,result['returned_solve_seconds']-60)
assert result['solver_soft_overrun_seconds']==max(0.,r.wall_time-60)
tables={}
for i,c in enumerate(p.constraints):
    if c.WhichOneof('constraint')=='table':
        n=len(c.table.exprs);assert not c.table.negated
        tables[i]={tuple(c.table.values[k:k+n]) for k in range(0,len(c.table.values),n)}
def evaluate(sol,objective):
    assert len(sol)==len(p.variables)==46
    for v,x in zip(p.variables,sol):assert any(a<=x<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    def expr(e):return e.offset+sum(c*sol[v] for v,c in zip(e.vars,e.coeffs))
    for i,c in enumerate(p.constraints):
        assert not c.enforcement_literal
        if c.WhichOneof('constraint')=='table':assert tuple(expr(e) for e in c.table.exprs) in tables[i]
        elif c.WhichOneof('constraint')=='lin_max':assert expr(c.lin_max.target)==max(expr(e) for e in c.lin_max.exprs)
        else:raise AssertionError(c.WhichOneof('constraint'))
    assert objective==p.objective.scaling_factor*(p.objective.offset+sum(c*sol[v] for v,c in zip(p.objective.vars,p.objective.coeffs)))
records=[]
for i,path in enumerate(sorted((SEARCH/'incumbents').glob('*.json'))):
    row=load(path);assert row['sequence']==i;evaluate(row['values'],row['objective_centimm'])
    assert 0<=row['solver_wall_seconds']<=r.wall_time and row['best_bound_centimm']<=row['objective_centimm']
    if records:assert row['objective_centimm']<=records[-1]['objective_centimm'] and row['solver_wall_seconds']>=records[-1]['solver_wall_seconds']
    records.append(row)
assert len(records)==result['incumbents_recorded']
if r.solution:
    evaluate(list(r.solution),r.objective_value)
    assert records[-1]['objective_centimm']==r.objective_value
    assert load(SEARCH/'assignment.json')=={v.name:x for v,x in zip(p.variables,r.solution)}
    if status=='OPTIMAL':assert r.objective_value==r.best_objective_bound
    nodes=load(BASE/'mapping.json')['nodes']
    poses=[{**n,'phase_index':r.solution[n['index']],'rotation_degrees':r.solution[n['index']]*.5} for n in nodes]
    write(OUT/'selected-poses.json',{'pitch_centimm':r.solution[45],'nodes':poses})
inputs=[BASE/'plan.json',BASE/'mapping.json',BASE/'model-audit/checks.json',BASE/'source-control/checks.json']+list(SEARCH.glob('*'))+list((SEARCH/'incumbents').glob('*'))
write(OUT/'plan.json',{'inputs':{x.relative_to(ROOT).as_posix():digest(x) for x in inputs if x.is_file()}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':status,'incumbents_verified':len(records),
    'assignments_verified':len(records)+bool(r.solution),'variables_per_assignment':46,'constraints_per_assignment':31,
    'pitch_mm':r.objective_value/100,'bound_mm':r.best_objective_bound/100,'solver_wall_seconds':r.wall_time,
    'shared_seconds':process['seconds'],'model_sha256':digest(SEARCH/'model.pb'),'finite_lattice_only':True,
    'stock_fit_claimed':False,'source_geometry_verified':False,'full66_exclusion_claimed':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
