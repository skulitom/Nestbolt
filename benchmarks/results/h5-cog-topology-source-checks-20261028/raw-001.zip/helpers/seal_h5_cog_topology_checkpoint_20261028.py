"""Seal the closed finite phase model, source packet checks and aligned-row construction."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-cog-topology-source-checks-20261028';OUT=ROOT/'benchmarks/results'/NAME
SCAN=ROOT/'output/h5-cog-triangular-contacts-20261028';MODEL=ROOT/'output/h5-triangular-phase-model-20261028';GRID=ROOT/'output/h5-rectangular-cog-grid-20261028';PUB=MODEL/'publication'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='ef35554f66e44eb4c99e567d177dd013425530ca' and not git('diff','HEAD','--name-only')
contact=load(SCAN/'audit/checks.json');model=load(MODEL/'model-audit/checks.json');response=load(MODEL/'response-audit/checks.json');packet=load(MODEL/'source-packet-audit/checks.json')
grid=load(GRID/'audit/checks.json');insert=load(GRID/'insertion/audit/checks.json')
assert all(r['passed'] for r in [contact,model,response,packet,grid,insert])
assert response['status']=='OPTIMAL' and response['pitch_mm']==278.84 and not packet['fits_stock_width']
assert insert['source_originals']==62 and insert['unplaced_originals']==[['bracket',i] for i in range(8,12)]
prior=load(ROOT/'benchmarks/results/h5-seven-bracket-source-and-bound-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest']
readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],
    'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert up['sparrow_head']=='6f7b9d353c2b2a4fc68454590a2e8e83475c12ef'
assert all(up[k]==prior[k] for k in ['studio_head','sparrow_release','studio_latest_release'])
change=load(PUB/'sparrow-change.json');assert change['status']=='ahead' and change['total_commits']==1
assert [c['sha'] for c in change['commits']]==[up['sparrow_head']]
assert {f['filename'] for f in change['files']}=={'README.md','data/sparrow-icon.svg','data/sparrow-wordmark.svg'}
main=load(PUB/'main.json')['commit']['sha'];assert main=='db26d1203163d3af0331d7159734a33028be6e26'
jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [SCAN,MODEL,GRID,ROOT/'output/h5-cog-oblique-contacts-20261028',ROOT/'output/h5-seven-bracket-main-sync-pending-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['scan_h5_cog_triangular_contacts_20261028.py','audit_h5_cog_triangular_contacts_20261028.py',
    'build_h5_triangular_phase_model_20261028.py','audit_h5_triangular_phase_model_20261028.py','audit_h5_triangular_uniform_source_20261028.py',
    'run_h5_triangular_phase_model_20261028.py','audit_h5_triangular_phase_response_20261028.py','audit_h5_triangular_packet_source_20261028.py',
    'construct_h5_rectangular_cog_grid_20261028.py','audit_h5_rectangular_cog_grid_20261028.py',
    'probe_h5_rectangular_grid_remaining_20261028.py','audit_h5_rectangular_grid_insertion_20261028.py','render_h5_rectangular_grid_20261028.py',
    'pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
add('previous-contact-audit.py',ROOT/'output/h5-oblique64-source-20261028/audit/audit.py')
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for f in ['output','scripts']:
                    q=ROOT/f/(module+'.py')
                    if q.is_file():add('imported-helpers/'+f+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(SCAN/'audit/checks.json','contacts-audit.json'),(MODEL/'model-audit/checks.json','model-audit.json'),
    (MODEL/'response-audit/checks.json','response-audit.json'),(MODEL/'response-audit/selected-poses.json','selected-phases.json'),
    (MODEL/'source-packet-audit/checks.json','triangular-source-audit.json'),(MODEL/'search/result.json','solver-result.json'),
    (GRID/'audit/checks.json','aligned-grid-audit.json'),(GRID/'insertion/audit/checks.json','insertion-audit.json'),
    (GRID/'insertion/source-candidate.json','source62.json'),(GRID/'source62-upper.png','source62-upper.png'),
    (PUB/'main-ci-jobs.json','prior-main-ci.json')]
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,
    'production_digest':production,'current_readmes':readmes,**up,'sparrow_prior_head':prior['sparrow_head'],
    'sparrow_change_reviewed':'One README and wordmark commit; all three changed paths reviewed. No solver, fixed-sheet, part-in-part or licensing change.',
    'upstream_stop_rule_triggered':False,'upstream_releases_unchanged':True,'main_CI':40711177461,'main_all6_pass':True,
    'normal_push_requires_fresh_remote_guards':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'triangular_model_status':'OPTIMAL','finite_phase_model_only':True,'triangular_source_pairs_valid':True,
    'triangular_stock_width_fit':False,'aligned_source62_valid':True,'previous_source64_preserved':True,'remaining_necessary_allocations':444,
    'full66_witness':False,'full66_exclusion_claimed':False,'solver_calls':1,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='Both new topology calls are closed. The mixed-phase equilateral lattice is47.818912mm too wide despite valid source pairs. The aligned5x3 grid fits, but the single bounded insertion sequence stops at62 originals, missing brackets8..11. Keep the older source64 as best; neither result changes the444-count necessary frontier or establishes actual/global infeasibility. Stop treating a rigid15-cog lattice as the entire search space. For the7/7 short allocation, the43 fixed originals leave23 first-sheet movers:15 cogs, brackets7..11 and inserts18..20. Prepare a materially different constructive model with independent mover coordinates and original-source no-fit geometry (including legal bracket modes); audit its conservative direction and a valid partial control before predeclaring one bounded call. A failed fixed-phase local call must not be restarted, reseeded or extended. If fixed-core modelling is unproductive, revisit the frame/side-insert arrangement or another surviving count allocation explicitly, with fresh source validation. Native and material validation require all66 source-valid originals first. All H2 decisions,22 reserved vectors, unchanged material target and guards remain in force. Main db26d120 has allsix CI jobs passing; push this and queued ef355 normally after fresh guards. Upstream Sparrow6f7b9d35 only changes README/wordmark assets, so no stop rule fires. No release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Cog topology source checks — 2026-10-28

Two new cog arrangements were checked against the original source geometry.
Neither completes the mechanical layout: the mixed-phase triangular packet is
**47.819 mm too wide**, and the aligned-row construction places **62 of 66
originals**. The previous valid64 remains the best partial layout. H2/H5 remain
open at **60% completed milestone weight**.

## Finite triangular phase model

A new contact scan covers 2,592 ordered phase pairs along 60° and 120° rays,
with 62,208 distance evaluations. It reuses the 1,296 audited horizontal contacts
unchanged. The independent reader verifies all contact endpoints directly
against the original 80-vertex cog and checks the exact source-kernel argument.
Only the finite legal phases 0°–17.5° in 0.5° steps are considered; no unsampled
angle is excluded and no tooth symmetry is assumed.

All 15 cogs independently choose a phase on a fixed five-column, three-row
equilateral lattice. Thirty directed neighbour tables determine a common pitch.
The independent model reader verifies all 46 variables, 31 constraints and
38,880 allowed-table rows. A uniform-phase source control passes all 105 pairs.

The sole predeclared 60-second, four-worker solver call returns **OPTIMAL** in
10.309316 solver seconds and 11.141385 shared seconds. The saved protobuf and
all **31 incumbents** pass independent domain, table, maximum and objective
checks. The best pitch is **278.84 mm**, optimal only for this finite model.

Reconstructing the actual originals verifies all 105 cog pairs, all 15 holes
and 3,000 hole vertices. Minimum separation is **0.214489154 mm**, above the
unchanged guarded requirement. The packet is **1,534.768912 × 762.958224 mm**;
available guarded stock width is 1,486.95 mm. It cannot be used as the proposed
stock placement. No broader rotation, lattice or full-layout exclusion follows.

## Aligned rows and bounded insertion

A separate deterministic construction aligns three rows of five cogs, at 7°
and 258.86 mm spacing in both axes, leaving a strip on the right. It retains
the 29-original first-sheet frame/side-insert core and the source-valid short14.
The resulting source58 passes **1,037 pairs, 232 stock edges and all 72 holes**.
This checks the vertical contacts directly without relying on tooth symmetry.

One predeclared insertion sequence considers all eight bracket modes, then the
two insert outer-shape classes. It retains every conservative region, selects
the representative point of the largest component and stops a family when all
its regions are empty. The call closes after **22 region calculations in
9.370884 shared seconds**, inserting one bracket and three inserts.

Independent readback verifies all ten modes, 22 region records, nine candidate
points and four deterministic choices. Final source62 passes **1,219 pairs,
248 stock edges and 78 holes / 8,562 hole vertices**, with minimum gap
0.214826984 mm and minimum extra stock clearance 0.025 mm. Brackets8–11 remain
unplaced. Empty conservative regions do not prove actual or global infeasibility.

![Verified aligned-row partial layout]({NAME}/source62-upper.png)

The original-ring figure was visually inspected. Both calls are closed; there
were no retries or native calls. The next construction must allow independent
part positions or change the retained frame arrangement, with a declared budget
and independent original-source checks before any complete-layout claim.
The unchanged necessary count frontier still contains 444 candidates.

## Publication checks

All six jobs passed in main
[CI 40711177461](https://github.com/skulitom/Nestbolt/actions/runs/40711177461).
The queued seven-bracket checkpoint and this evidence can be pushed together
after fresh remote, ancestry and live-run checks. Production and all READMEs
remain byte-identical. All 22 reserved H2 vectors remain unopened.

Sparrow advanced one commit to
[`6f7b9d35`](https://github.com/JeroenGar/sparrow/commit/6f7b9d353c2b2a4fc68454590a2e8e83475c12ef).
The complete comparison changes only README and wordmark assets; it introduces
no fixed-sheet, part-in-part, solver or licensing change. Studio and both
projects' releases are unchanged, so the upstream stop rule does not fire.
The new release remains unqualified while H2/H5 are open.

[Contact audit]({NAME}/contacts-audit.json),
[response audit]({NAME}/response-audit.json),
[triangular stock check]({NAME}/triangular-source-audit.json),
[aligned insertion audit]({NAME}/insertion-audit.json),
[next work]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The byte-verified archive preserves {archive['archive_members']} canonical files
and {archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including every incumbent, contact input, source placement,
region, original-ring readback, helper and upstream comparison.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 cog topology checks, 2026-10-28:** [the evidence]({link}) audits
2,592 new contact cases and one finite mixed-phase model. Its sole call returns
OPTIMAL at 278.84 mm pitch; all 31 incumbents and 105 original cog pairs pass,
but the packet is 47.819 mm too wide. A new aligned-row source58 passes, then
one bounded insertion sequence places one bracket and three inserts. Final
source62 passes 1,219 source pairs and all 78 holes; brackets8–11 remain
unplaced and the earlier valid64 is preserved. Both calls are closed, with no
native or global infeasibility claim; the necessary frontier remains 444.
Next allow independent mover positions or change the retained frame arrangement.
Main db26d120 passes all six CI jobs, permitting a normal guarded checkpoint
push. Sparrow6f7b9d35 changes only README/wordmark assets; the upstream stop rule
does not fire. Production, READMEs and upstream releases remain unchanged.
H2/H5 stay open at 60%, all 22 reserved vectors remain unopened, and no release
qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'bound_source_inputs':len(bindings),'completion_percent':60,'main_all6_pass':True})
