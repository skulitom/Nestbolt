"""Plot independently verified original source rings for inspection."""
from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Patch,Rectangle
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rectangular-cog-grid-20261028';load=lambda p:json.loads(p.read_bytes())
assert load(BASE/'insertion/audit/checks.json')['source_valid'];job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']}
fig,ax=plt.subplots(figsize=(13,9));colours={'frame':'#bdd0d5','cog':'#a8c9ba','bracket':'#efc48b','insert':'#baa5d9'}
for r in load(BASE/'insertion/source-candidate.json'):
    if r['sheet_id']!='sheet-0':continue
    g=parts[r['part_id']]['geometry'][0];t=r['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    def ring(points):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in points]
    outer=ring(g['outer']);ax.add_patch(Polygon(outer,facecolor=colours[r['part_id']],edgecolor='#625d62',linewidth=.65))
    for h in g.get('holes',[]):ax.add_patch(Polygon(ring(h),facecolor='none',edgecolor='#8b8290',linewidth=.4))
ax.add_patch(Rectangle((6.5,6.5),1487,2987,fill=False,edgecolor='#333333',linestyle='--',linewidth=1))
ax.set_xlim(0,1500);ax.set_ylim(1960,3010);ax.set_aspect('equal');ax.set_xlabel('mm');ax.set_ylabel('mm')
fig.suptitle('Aligned cog rows: verified partial construction',y=.97,fontsize=16)
ax.set_title('Upper first sheet; original filled outlines with holes reserved',pad=10,fontsize=11)
fig.legend(handles=[Patch(facecolor=c,label=f.title()) for f,c in colours.items()],loc='lower center',bbox_to_anchor=(.5,.055),ncol=4,frameon=False)
fig.text(.5,.022,'62 of 66 originals placed across both sheets. Brackets 8–11 remain unplaced; the previous valid64 is preserved.',ha='center',fontsize=10)
fig.subplots_adjust(left=.065,right=.985,bottom=.16,top=.88);fig.savefig(BASE/'source62-upper.png',dpi=140);plt.close(fig)
print(str(BASE/'source62-upper.png'))
