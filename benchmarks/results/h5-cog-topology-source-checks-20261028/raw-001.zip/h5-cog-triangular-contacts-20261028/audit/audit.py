"""Direct original-vertex readback of every reused and new directed contact."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json,math,shutil,time
from shapely.geometry import Polygon,Point
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-triangular-contacts-20261028';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
result=load(BASE/'result.json');process=load(BASE/'process.json')
assert result['status']=='COMPLETE' and result['closed'] and process['exit_code']==0 and not process['timeout']
assert result['scan_seconds']<60 and process['seconds']<90 and result['new_distance_evaluations']==2592*24
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='cog');assert part['rotations']['kind']=='free' and not part['allow_mirror']
center=[139.723742,139.723742];vertices=[(F(x)-F(center[0]),F(y)-F(center[1])) for x,y in part['geometry'][0]['outer']]
assert len(vertices)==80 and all(a[0]*b[1]-a[1]*b[0]>0 for a,b in zip(vertices,vertices[1:]+vertices[:1]))
xy=[(float(x),float(y)) for x,y in vertices];original=Polygon(xy);assert original.is_valid and original.contains(Point(0,0))
phases=[i*.5 for i in range(36)];directions=[0,60,120];assert plan['phases_degrees']==phases
points={}
for phase,d in product(phases,directions):
    c,s=math.cos(math.radians(phase)),math.sin(math.radians(phase));u,v=math.cos(math.radians(d)),math.sin(math.radians(d))
    points[phase,d]=[(u*(c*x-s*y)+v*(s*x+c*y),-v*(c*x-s*y)+u*(s*x+c*y)) for x,y in xy]
old=load(ROOT/'output/h5-cog-oblique-contacts-20261028/contacts.json');reused=[r for r in old if r['direction']==0]
assert load(BASE/'reused-horizontal-contacts.json')==reused
rows=load(BASE/'contacts.json');new=load(BASE/'new-contacts.json');assert rows==reused+new and len(new)==2592
table={};thresholds=[];required=plan['required_gap_mm']
for r in rows:
    pa,pb,d=r['phase_a'],r['phase_b'],r['direction'];key=(pa,pb,d);assert key not in table;table[key]=r
    lo,hi=r['contact_lower_mm'],r['clear_upper_mm'];assert 240<=lo<hi<=281 and abs(hi-lo-41/2**20)<1e-10
    a=Polygon(points[pa,d]);lower=a.distance(Polygon([(x+lo,y) for x,y in points[pb,d]]));upper=a.distance(Polygon([(x+hi,y) for x,y in points[pb,d]]))
    assert abs(lower-r['lower_gap_mm'])<1e-8 and abs(upper-r['upper_gap_mm'])<1e-8 and lower<=required+1e-10<upper
    thresholds.append({'phase_a_index':phases.index(pa),'phase_b_index':phases.index(pb),'direction':d,
        'minimum_pitch_centimm':math.ceil((hi+.001)*100)})
assert set(table)==set(product(phases,phases,directions)) and len(table)==3888
write(OUT/'pitch-thresholds.json',thresholds)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_kernel_edges_verified':80,
    'new_contact_cases_verified':2592,'reused_horizontal_cases_verified':1296,'combined_direct_source_gap_checks':7776,
    'centimm_thresholds_verified':3888,'phase_subset_is_constructive_only':True,'no_symmetry_assumed':True,
    'thresholds_sha256':digest(OUT/'pitch-thresholds.json'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
