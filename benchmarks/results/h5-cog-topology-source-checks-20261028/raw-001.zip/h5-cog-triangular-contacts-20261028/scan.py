"""New sixty/one-twenty-degree source contacts; reuse the audited horizontal cases."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog-triangular-contacts-20261028'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OLD=ROOT/'output/h5-cog-oblique-contacts-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
class Budget(Exception):pass
def child():
    from shapely.geometry import Polygon
    from shapely.affinity import translate
    plan=load(OUT/'plan.json');job=load(JOB);cog=next(p for p in job['parts'] if p['id']=='cog');center=[139.723742,139.723742]
    vertices=[(x-center[0],y-center[1]) for x,y in cog['geometry'][0]['outer']];required=plan['required_gap_mm'];start=time.perf_counter();deadline=start+60
    assert all(a[0]*b[1]-a[1]*b[0]>0 for a,b in zip(vertices,vertices[1:]+vertices[:1]))
    phases=plan['phases_degrees'];directions=[60,120];shapes={}
    for d in directions:
        for phase in phases:
            a=math.radians(phase-d);c,s=math.cos(a),math.sin(a);g=Polygon([(c*x-s*y,s*x+c*y) for x,y in vertices]);assert g.is_valid;shapes[d,phase]=g
    rows=[];calls=0;status='COMPLETE'
    def distance(a,b,r):
        nonlocal calls
        if time.perf_counter()>=deadline:raise Budget()
        calls+=1;return a.distance(translate(b,xoff=r))
    try:
        for pa in phases:
            for pb in phases:
                for d in directions:
                    a,b=shapes[d,pa],shapes[d,pb];lo,hi=240.,281.
                    assert distance(a,b,lo)<required and distance(a,b,hi)>required
                    for _ in range(20):
                        mid=(lo+hi)/2
                        if distance(a,b,mid)>required:hi=mid
                        else:lo=mid
                    lower=distance(a,b,lo);upper=distance(a,b,hi);assert lower<=required<upper
                    rows.append({'phase_a':pa,'phase_b':pb,'direction':d,'contact_lower_mm':lo,'clear_upper_mm':hi,'lower_gap_mm':lower,'upper_gap_mm':upper})
    except Budget:status='TIME_LIMIT'
    write(OUT/'new-contacts.json',rows)
    reused=[r for r in load(OLD/'contacts.json') if r['direction']==0];assert len(reused)==1296
    write(OUT/'reused-horizontal-contacts.json',reused);write(OUT/'contacts.json',reused+rows)
    write(OUT/'result.json',{'status':status,'closed':True,'scan_seconds':time.perf_counter()-start,'new_distance_evaluations':calls,
        'new_contact_cases':len(rows),'reused_horizontal_cases':len(reused),'combined_cases':len(rows)+len(reused),
        'expected_new_cases':2592,'expected_combined_cases':3888,'finite_legal_phase_subset_only':True,
        'no_symmetry_assumed':True,'source_packet_not_yet_constructed':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'scan.py')
    inputs=[JOB,OLD/'plan.json',OLD/'contacts.json',OLD/'result.json',ROOT/'output/h5-oblique64-source-20261028/audit/checks.json',
        ROOT/'output/h5-short7-7-source-20261028/source63.json',ROOT/'output/h5-short7-7-source-20261028/audit/checks.json']
    assert load(inputs[-1])['passed'] and load(inputs[-3])['passed']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'phases_degrees':[i*.5 for i in range(36)],'new_directions_degrees':[60,120],'reused_directions_degrees':[0],
        'required_gap_mm':.21170867250963943,'maximum_scan_seconds':60,'maximum_shared_seconds':90,'maximum_runs':1,
        'retry_permitted':False,'bisection_steps':20,'method':'One finite original-source contact scan for an equilateral staggered cog lattice. Compute only the2592 previously untested ordered phase contacts at60/120degrees; reuse all1296 previously audited horizontal cases unchanged. Test exactly36 legal phases0..17.5degrees; do not invoke tooth symmetry or exclude any unsampled angle. Use original80-vertex cogs and the unchanged clearance, bracket240..281mm with20 bisections and retain direct endpoint checks. The source kernel proof ensures a single outward contact exit along each ray. Independently read all combined contacts before building any phase-assignment model. A future15-cog packet still requires all105 direct source-pair checks and cannot by itself place the five brackets and three upper inserts of the new7/7 allocation. No earlier local or contact run is restarted.'})
    start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90)
        (OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);process={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',process);print(process);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed result; scan closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
