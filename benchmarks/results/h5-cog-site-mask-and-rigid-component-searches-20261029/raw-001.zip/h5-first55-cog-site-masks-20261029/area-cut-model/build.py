"""Add independently proved accessible-area cuts to the immutable rigid model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';PRIOR=BASE/'rigid-model';BOUND=BASE/'accessible-area-bound';OUT=BASE/'area-cut-model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BOUND/'audit/checks.json')['passed'] and load(BASE/'rigid-model-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
model=cp_model_pb2.CpModelProto();model.ParseFromString((PRIOR/'model.pb').read_bytes());mapping=load(PRIOR/'mapping.json');area=load(BOUND/'all105-area-bounds.json')
allowed=load(BOUND/'audit/allowed-empty-site-pairs.json');allowed_masks=[sum(1<<i for i in p) for p in allowed]
cuts=[]
for r in area:
    if not r['restricted_construction_excluded']:continue
    index=len(model.constraints);ct=model.constraints.add();ct.name='area_forbidden_empty_pair_'+'_'.join(map(str,r['empty_sites']))
    ct.linear.vars.extend([mapping['empty_site_selectors'][i] for i in r['empty_sites']]);ct.linear.coeffs.extend([1,1]);ct.linear.domain.extend([0,1])
    cuts.append({'empty_sites':r['empty_sites'],'constraint':index,'area_upper_mm2':r['area_upper_bounds_mm2']['bracket'],'area_required_mm2':280000})
disabled=[]
for owner in mapping['owners']:
    for region in owner['unary_regions']:
        mask=sum(1<<i for i in region['required_empty_sites'])
        if not any(mask&~allowed_mask==0 for allowed_mask in allowed_masks):disabled.append(region['selector'])
assert disabled
disabled_index=len(model.constraints);ct=model.constraints.add();ct.name='unary_regions_with_no_remaining_site_pair';ct.linear.vars.extend(sorted(disabled));ct.linear.coeffs.extend([1]*len(disabled));ct.linear.domain.extend([0,0])
native=cp_model.CpModel();assert native.proto.parse_text_format(text_format.MessageToString(model)) and native.validate()==''
assert native.export_to_file(str(OUT/'model.pb')) and native.export_to_file(str(OUT/'model.pbtxt'))
shutil.copyfile(PRIOR/'mapping.json',OUT/'mapping.json')
write(OUT/'cuts.json',{'area_pair_cuts':cuts,'disabled_unary_selectors':sorted(disabled),'disabled_constraint':disabled_index,'allowed_empty_pairs':allowed})
elapsed=time.perf_counter()-started
charges=load(PRIOR/'preparation-charges.json');charges['accessible_area_bound_seconds']=load(BOUND/'checks.json')['seconds'];charges['area_cut_model_conversion_seconds']=elapsed
write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),BASE/'rigid-model-audit/plan.json',BASE/'rigid-model-audit/checks.json']+[PRIOR/n for n in ['plan.json','checks.json','model.pb','mapping.json','preparation-charges.json']]+[BOUND/n for n in ['plan.json','checks.json','all105-area-bounds.json','audit/plan.json','audit/checks.json','audit/allowed-empty-site-pairs.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Preserve the complete rigid source model; append 68 independently proved occupied bracket-area cuts and one implied zero-sum row for unary regions incompatible with every remaining empty-site pair. All37 surviving pairs remain. No objective, hints or source changes. New bounded call; neither earlier closed call is restarted.','algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'source_validation_reserve_seconds':4,'retry_permitted':False})
checks={'passed':True,'seconds':elapsed,'preparation_seconds_charged':sum(charges.values()),'variables':len(model.variables),'constraints':len(model.constraints),'area_cuts':len(cuts),'disabled_unary_selectors':len(disabled),'remaining_empty_site_pairs':len(allowed),'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'native_calls':0,'independent_audit_required':True,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
