"""Verify complete protobuf preservation and each area-derived addition."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';MODEL=BASE/'area-cut-model';OUT=BASE/'area-cut-model-audit';BOUND=BASE/'accessible-area-bound';PRIOR=BASE/'rigid-model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
queue=[MODEL/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
old=cp_model_pb2.CpModelProto();old.ParseFromString((PRIOR/'model.pb').read_bytes());new=cp_model_pb2.CpModelProto();new.ParseFromString((MODEL/'model.pb').read_bytes())
prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(new);del prefix.constraints[len(old.constraints):];assert prefix==old
assert len(old.constraints)==63132 and len(new.constraints)==63201 and len(new.variables)==11638
assert digest(PRIOR/'mapping.json')==digest(MODEL/'mapping.json')
mapping=load(MODEL/'mapping.json');cuts=load(MODEL/'cuts.json');area=load(BOUND/'all105-area-bounds.json');excluded=[r for r in area if r['restricted_construction_excluded']];allowed=[r['empty_sites'] for r in area if not r['restricted_construction_excluded']]
assert len(excluded)==68 and len(allowed)==37 and cuts['allowed_empty_pairs']==allowed
def same_linear(ct,variables,coefficients,domain):
    assert not ct.enforcement_literal and ct.WhichOneof('constraint')=='linear'
    assert list(ct.linear.vars)==variables and list(ct.linear.coeffs)==coefficients and list(ct.linear.domain)==domain
for i,(cut,r) in enumerate(zip(cuts['area_pair_cuts'],excluded)):
    assert cut=={'empty_sites':r['empty_sites'],'constraint':63132+i,'area_upper_mm2':r['area_upper_bounds_mm2']['bracket'],'area_required_mm2':280000}
    assert cut['area_upper_mm2']<280000 and r['contradictions']==['bracket']
    same_linear(new.constraints[63132+i],[mapping['empty_site_selectors'][s] for s in r['empty_sites']],[1,1],[0,1])
disabled=[]
for owner in mapping['owners']:
    for region in owner['unary_regions']:
        if all(not set(region['required_empty_sites']).issubset(pair) for pair in allowed):disabled.append(region['selector'])
assert sorted(disabled)==cuts['disabled_unary_selectors'] and cuts['disabled_constraint']==63200
same_linear(new.constraints[63200],sorted(disabled),[1]*len(disabled),[0,0])
assert all(list(new.variables[i].domain)==[0,1] for i in disabled)
charges=load(MODEL/'preparation-charges.json');oldcharges=load(PRIOR/'preparation-charges.json');assert {k:charges[k] for k in oldcharges}==oldcharges
assert charges['accessible_area_bound_seconds']==load(BOUND/'checks.json')['seconds']
assert charges['area_cut_model_conversion_seconds']==load(MODEL/'checks.json')['seconds'] and sum(charges.values())==load(MODEL/'checks.json')['preparation_seconds_charged']<56
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[MODEL/n for n in ['plan.json','model.pb','mapping.json','cuts.json','checks.json','preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'prior_model_all_fields_preserved':True,'original_constraints_verified':63132,'area_cuts_verified':68,'implied_disabled_unary_selectors':len(disabled),'variables':11638,'constraints':63201,'remaining_empty_site_pairs':37,'model_sha256':digest(MODEL/'model.pb'),'source_mapping_unchanged':True,'global_allocation_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
