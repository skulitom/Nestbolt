"""Verify every protobuf variable, site mask, mode coupling and original-pair constraint."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations
import json, shutil, time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-cog-site-masks-20261029';PRE=BASE/'integer-preparation';MODEL=BASE/'rigid-model';OUT=BASE/'rigid-model-audit';RID=BASE/'rigid-rectangle-preflight'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();MIN=-(2**63)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [PRE,MODEL,BASE/'integer-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
assert load(BASE/'integer-audit/checks.json')['passed']
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints'} and len(p.variables)==11638 and len(p.constraints)==63132
mapping=load(MODEL/'mapping.json');modes=load(PRE/'family-modes.json');unary=load(PRE/'unary-templates.json');templates=load(PRE/'pair-templates.json');groups=load(PRE/'owner-pairs.json');instances=load(BASE/'instances.json');inventory=load(BASE/'inventory.json');owners=mapping['owners']
assert len(owners)==len(instances)==13 and mapping['position_units_per_mm']==1000 and [o['identity'] for o in owners]==inventory['moving13_orthogonal_identities']
used_vars=set();used_ct=set();false_clauses=0
def variable(i,name,domain):
    assert i not in used_vars;used_vars.add(i);v=p.variables[i];assert v.name==name and list(v.domain)==domain and {f.name for f,x in v.ListFields()}=={'name','domain'}
def linear(i,coeff,lo,hi,guard=None):
    global false_clauses
    assert i not in used_ct;used_ct.add(i);c=p.constraints[i];co={j:v for j,v in coeff.items() if v}
    assert list(c.enforcement_literal)==([] if guard is None else [guard])
    if not co and not lo<=0<=hi:
        assert c.WhichOneof('constraint')=='bool_or' and not c.bool_or.literals and {f.name for f,x in c.ListFields()}=={'bool_or'}|({'enforcement_literal'} if guard is not None else set());false_clauses+=1;return
    assert c.WhichOneof('constraint')=='linear' and {f.name for f,x in c.ListFields()}=={'linear'}|({'enforcement_literal'} if guard is not None else set())
    assert dict(zip(c.linear.vars,c.linear.coeffs))==co and len(c.linear.vars)==len(co) and list(c.linear.domain)==[lo,hi]
mode_count=unary_count=unary_planes=mask_links=0
for i,(owner,instance) in enumerate(zip(owners,instances)):
    assert owner['owner']==i and owner['identity']==instance['identity'] and owner['positions']==[2*i,2*i+1]
    expected=modes[owner['identity'][0]];assert len(owner['modes'])==len(expected)
    for k in [0,1]:variable(2*i+k,f'{"x" if k==0 else "y"}_{i}_um',[min(m['integer_lower_left_bounds'][k][0] for m in expected),max(m['integer_lower_left_bounds'][k][1] for m in expected)])
    for actual,source in zip(owner['modes'],expected):
        assert {k:v for k,v in actual.items() if k not in ['selector','stock_constraints']}==source
        selector=actual['selector'];assert 26<=selector<106;variable(selector,f'mode_{i}_{source["mode"]}',[0,1]);assert len(actual['stock_constraints'])==2
        for k in [0,1]:linear(actual['stock_constraints'][k],{2*i+k:1},*source['integer_lower_left_bounds'][k],selector)
        mode_count+=1
    linear(owner['one_mode_constraint'],{m['selector']:1 for m in owner['modes']},1,1)
empty=mapping['empty_site_selectors'];assert empty==list(range(106,121))
for site,var in enumerate(empty):variable(var,f'empty_cog_site_{site}',[0,1])
linear(mapping['exactly_two_empty_sites_constraint'],{v:1 for v in empty},2,2)
assert len(list(combinations(empty,2)))==105
for i,owner in enumerate(owners):
    geometries=sorted({m['normalized_geometry'] for m in owner['modes']});expected=[(gid,r['region']) for gid in geometries for r in unary[gid]['regions']]
    assert [(r['geometry'],r['region']) for r in owner['unary_regions']]==expected
    for region in owner['unary_regions']:
        gid,ri=region['geometry'],region['region'];source=unary[gid]['regions'][ri];selector=region['selector'];assert 121<=selector<10826
        variable(selector,f'unary_{i}_{gid}_{ri}',[0,1]);assert region['required_empty_sites']==source['required_empty_sites'] and len(region['plane_constraints'])==len(source['planes'])
        for ci,plane in zip(region['plane_constraints'],source['planes']):
            nx,ny=plane['coefficients'];linear(ci,{2*i:nx,2*i+1:ny},MIN,plane['upper'],selector);unary_planes+=1
        assert len(region['empty_site_constraints'])==len(source['required_empty_sites'])
        for ci,site in zip(region['empty_site_constraints'],source['required_empty_sites']):linear(ci,{selector:1,empty[site]:-1},MIN,0);mask_links+=1
        unary_count+=1
    linear(owner['one_unary_region_constraint'],{r['selector']:1 for r in owner['unary_regions']},1,1)
    assert [m['geometry'] for m in owner['unary_geometry_marginals']]==geometries
    for marginal in owner['unary_geometry_marginals']:
        gid=marginal['geometry'];ms=[m['selector'] for m in owner['modes'] if m['normalized_geometry']==gid];rs=[r['selector'] for r in owner['unary_regions'] if r['geometry']==gid]
        assert marginal['mode_selectors']==ms and marginal['region_selectors']==rs and ms and rs;linear(marginal['constraint'],{**{v:-1 for v in ms},**{v:1 for v in rs}},0,0)
pair_count=pair_planes=marginals=0
assert mapping['pairs']==[] and mapping['rectangle_gap_um']==226 and load(RID/'audit-v3/checks.json')['passed']
source_rectangles=load(RID/'mode-rectangles.json');source_components=load(RID/'components.json');source_pairs=load(RID/'component-pairs.json');components=mapping['rigid_components'];separations=mapping['rectangle_separations'];coordinate_links=0
assert len(components)==20 and len(separations)==183
for actual,expected_component in zip(components,source_components):
    assert {k:v for k,v in actual.items() if k not in ['coordinates','mode_links']}==expected_component
    ci,oi,pi=actual['component'],actual['owner'],actual['piece'];owner=owners[oi];family=owner['identity'][0];assert actual['identity']==owner['identity'] and actual['coordinates']==list(range(10826+4*ci,10830+4*ci))
    for k,(label,vi) in enumerate(zip(['left','bottom','right','top'],actual['coordinates'])):
        axis=k%2
        lower=min(m['integer_lower_left_bounds'][axis][0]+source_rectangles[family][m['mode']]['rectangles'][pi]['outward_offsets_um'][k] for m in owner['modes'])
        upper=max(m['integer_lower_left_bounds'][axis][1]+source_rectangles[family][m['mode']]['rectangles'][pi]['outward_offsets_um'][k] for m in owner['modes'])
        variable(vi,f'rect_{ci}_{label}_um',[lower,upper])
    assert len(actual['mode_links'])==len(owner['modes'])
    for link,mode in zip(actual['mode_links'],owner['modes']):
        offsets=source_rectangles[family][mode['mode']]['rectangles'][pi]['outward_offsets_um']
        assert link['mode']==mode['mode'] and link['mode_selector']==mode['selector'] and link['outward_offsets_um']==offsets and len(link['constraints'])==4
        for k,(ct,vi,offset) in enumerate(zip(link['constraints'],actual['coordinates'],offsets)):
            linear(ct,{vi:1,owner['positions'][k%2]:-1},offset,offset,mode['selector']);coordinate_links+=1
for index,(actual,expected_pair) in enumerate(zip(separations,source_pairs)):
    assert actual['components']==expected_pair['components'] and actual['owners']==expected_pair['owners'] and actual['owners'][0]!=actual['owners'][1]
    ai,bi=actual['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];assert actual['selectors']==list(range(10906+4*index,10910+4*index)) and len(actual['constraints'])==4
    directions=[{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}]
    for direction,(vi,ct,coeff) in enumerate(zip(actual['selectors'],actual['constraints'],directions)):
        variable(vi,f'separate_{ai}_{bi}_{direction}',[0,1]);linear(ct,coeff,MIN,-226,vi)
    linear(actual['one_direction_constraint'],{vi:1 for vi in actual['selectors']},1,1)
assert coordinate_links==544
expected=[]
for family in ['bracket','insert']:
    peers=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1]);expected.extend((family,[a['owner'],b['owner']]) for a,b in zip(peers,peers[1:]))
assert [(r['family'],r['owners']) for r in mapping['symmetry_constraints']]==expected
for row in mapping['symmetry_constraints']:
    a,b=row['owners'];linear(row['constraint'],{2*a:1,2*b:-1},MIN,0)
assert used_vars==set(range(11638)) and used_ct==set(range(63132)) and mode_count==80 and unary_count==10705 and unary_planes==43721 and mask_links==17686 and pair_count==0 and pair_planes==0 and marginals==0
assert load(MODEL/'checks.json')['preparation_seconds_charged']==sum(load(MODEL/'preparation-charges.json').values())
inputs=[Path(__file__),RID/'plan.json',RID/'audit-v3/plan.json',RID/'audit-v3/checks.json',RID/'mode-rectangles.json',RID/'components.json',RID/'component-pairs.json',BASE/'plan.json',BASE/'instances.json',BASE/'inventory.json',BASE/'integer-audit/plan.json',BASE/'integer-audit/checks.json']+[PRE/n for n in ['plan.json','family-modes.json','unary-templates.json','pair-templates.json','owner-pairs.json']]+[MODEL/n for n in ['plan.json','checks.json','model.pb','model.pbtxt','mapping.json','preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'passed':True,'seconds':time.perf_counter()-started,'variables_verified':len(used_vars),'constraints_verified':len(used_ct),'original_moving_parts':13,'source_mode_selectors_verified':mode_count,'empty_site_selectors_verified':15,'exactly_two_empty_sites_verified':True,'unary_regions_verified':unary_count,'unary_planes_verified':unary_planes,'empty_site_implications_verified':mask_links,'pair_regions_verified':pair_count,'pair_planes_verified':pair_planes,'pair_geometry_marginals_verified':marginals,'rigid_components_verified':20,'source_mode_coordinate_links_verified':544,'different_owner_rectangle_pairs_verified':183,'separation_direction_selectors_verified':732,'all_components_rigidly_tied_to_original_source_poses':True,'disabled_region_empty_clauses_verified':false_clauses,'same_family_order_constraints_verified':11,'all_model_fields_exhaustively_verified':True,'binary_and_text_models_identical':True,'all105_empty_site_pairs_represented':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
