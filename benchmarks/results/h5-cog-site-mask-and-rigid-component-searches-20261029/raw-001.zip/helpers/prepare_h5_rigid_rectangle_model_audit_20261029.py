from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/audit_h5_cog_site_mask_model_20261029.py').read_text(encoding='utf-8')
source=source.replace("MODEL=BASE/'model';OUT=BASE/'model-audit'","MODEL=BASE/'rigid-model';OUT=BASE/'rigid-model-audit';RID=BASE/'rigid-rectangle-preflight'")
source=source.replace('len(p.variables)==23102 and len(p.constraints)==109655','len(p.variables)==11638 and len(p.constraints)==63132')
start=source.index('pair_count=pair_planes=marginals=0');end=source.index('expected=[]\nfor family',start)
replacement='''pair_count=pair_planes=marginals=0
assert mapping['pairs']==[] and mapping['rectangle_gap_um']==226 and load(RID/'audit-v3/checks.json')['passed']
source_rectangles=load(RID/'mode-rectangles.json');source_components=load(RID/'components.json');source_pairs=load(RID/'component-pairs.json');components=mapping['rigid_components'];separations=mapping['rectangle_separations'];coordinate_links=0
assert len(components)==20 and len(separations)==183
for actual,expected_component in zip(components,source_components):
    assert {k:v for k,v in actual.items() if k not in ['coordinates','mode_links']}==expected_component
    ci,oi,pi=actual['component'],actual['owner'],actual['piece'];owner=owners[oi];family=owner['identity'][0];assert actual['identity']==owner['identity'] and actual['coordinates']==list(range(10826+4*ci,10830+4*ci))
    for k,(label,vi) in enumerate(zip(['left','bottom','right','top'],actual['coordinates'])):
        axis=k%2
        lower=min(m['integer_lower_left_bounds'][axis][0]+source_rectangles[family][m['mode']]['rectangles'][pi]['outward_offsets_um'][k] for m in owner['modes'])
        upper=max(m['integer_lower_left_bounds'][axis][1]+source_rectangles[family][m['mode']]['rectangles'][pi]['outward_offsets_um'][k] for m in owner['modes'])
        variable(vi,f'rect_{ci}_{label}_um',[lower,upper])
    assert len(actual['mode_links'])==len(owner['modes'])
    for link,mode in zip(actual['mode_links'],owner['modes']):
        offsets=source_rectangles[family][mode['mode']]['rectangles'][pi]['outward_offsets_um']
        assert link['mode']==mode['mode'] and link['mode_selector']==mode['selector'] and link['outward_offsets_um']==offsets and len(link['constraints'])==4
        for k,(ct,vi,offset) in enumerate(zip(link['constraints'],actual['coordinates'],offsets)):
            linear(ct,{vi:1,owner['positions'][k%2]:-1},offset,offset,mode['selector']);coordinate_links+=1
for index,(actual,expected_pair) in enumerate(zip(separations,source_pairs)):
    assert actual['components']==expected_pair['components'] and actual['owners']==expected_pair['owners'] and actual['owners'][0]!=actual['owners'][1]
    ai,bi=actual['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];assert actual['selectors']==list(range(10906+4*index,10910+4*index)) and len(actual['constraints'])==4
    directions=[{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}]
    for direction,(vi,ct,coeff) in enumerate(zip(actual['selectors'],actual['constraints'],directions)):
        variable(vi,f'separate_{ai}_{bi}_{direction}',[0,1]);linear(ct,coeff,MIN,-226,vi)
    linear(actual['one_direction_constraint'],{vi:1 for vi in actual['selectors']},1,1)
assert coordinate_links==544
'''
source=source[:start]+replacement+source[end:]
changes=[('used_vars==set(range(23102)) and used_ct==set(range(109655))','used_vars==set(range(11638)) and used_ct==set(range(63132))'),('pair_count==12276 and pair_planes==47088 and marginals==816','pair_count==0 and pair_planes==0 and marginals==0'),("inputs=[Path(__file__),","inputs=[Path(__file__),RID/'plan.json',RID/'audit-v3/plan.json',RID/'audit-v3/checks.json',RID/'mode-rectangles.json',RID/'components.json',RID/'component-pairs.json',"),("'pair_geometry_marginals_verified':marginals,","'pair_geometry_marginals_verified':marginals,'rigid_components_verified':20,'source_mode_coordinate_links_verified':544,'different_owner_rectangle_pairs_verified':183,'separation_direction_selectors_verified':732,'all_components_rigidly_tied_to_original_source_poses':True,")]
for old,new in changes:
    assert old in source,old
    source=source.replace(old,new)
p=ROOT/'output/audit_h5_rigid_rectangle_model_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'prepared':p.name,'every_rigid_link_and_separation_will_be_checked':True})
