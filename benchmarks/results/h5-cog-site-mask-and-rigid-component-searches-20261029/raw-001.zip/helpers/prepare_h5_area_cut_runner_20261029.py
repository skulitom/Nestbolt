from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst in [('check_h5_rigid_rectangle_candidate_20261029.py','check_h5_area_cut_candidate_20261029.py'),('run_h5_rigid_rectangle_model_20261029.py','run_h5_area_cut_model_20261029.py')]:
    text=(ROOT/'output'/src).read_text(encoding='utf-8')
    for old,new in [('rigid-search','area-cut-search'),('rigid-model','area-cut-model'),('check_h5_rigid_rectangle_candidate_20261029.py','check_h5_area_cut_candidate_20261029.py')]:text=text.replace(old,new)
    p=ROOT/'output'/dst;compile(text,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print({'prepared':2,'maximum_calls':1,'previous_calls_remain_closed':True})
