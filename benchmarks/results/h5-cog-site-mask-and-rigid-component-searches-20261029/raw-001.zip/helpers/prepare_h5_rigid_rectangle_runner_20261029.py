from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for src,dst,changes in [
    ('check_h5_cog_site_mask_candidate_20261029.py','check_h5_rigid_rectangle_candidate_20261029.py',[("SEARCH=BASE/'search'","SEARCH=BASE/'rigid-search'"),("BASE/'model/mapping.json'","BASE/'rigid-model/mapping.json'")]),
    ('run_h5_cog_site_mask_model_20261029.py','run_h5_rigid_rectangle_model_20261029.py',[("MODEL = BASE / 'model'","MODEL = BASE / 'rigid-model'"),("OUT = BASE / 'search'","OUT = BASE / 'rigid-search'"),('model-audit','rigid-model-audit'),('check_h5_cog_site_mask_candidate_20261029.py','check_h5_rigid_rectangle_candidate_20261029.py')]),
]:
    text=(ROOT/'output'/src).read_text(encoding='utf-8')
    for old,new in changes:
        assert old in text,(src,old)
        text=text.replace(old,new)
    p=ROOT/'output'/dst;compile(text,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print({'prepared':2,'maximum_calls':1,'full66_source_checker_ready':True})
