from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/build_h5_cog_site_mask_model_20261029.py').read_text(encoding='utf-8')
source=source.replace("OUT=BASE/'model'","OUT=BASE/'rigid-model'")
source=source.replace("assert load(BASE/'integer-audit/checks.json')['passed']","RID=BASE/'rigid-rectangle-preflight'\nassert load(BASE/'integer-audit/checks.json')['passed'] and load(RID/'audit-v3/checks.json')['passed']")
start=source.index('pairs=[];pair_plane_count=0');end=source.index('symmetry=[]',start)
replacement='''pairs=[];pair_plane_count=0
mode_rectangles=load(RID/'mode-rectangles.json');component_inventory=load(RID/'components.json');component_pairs=load(RID/'component-pairs.json');components=[];separations=[];coordinate_links=0
labels=['left','bottom','right','top']
for item in component_inventory:
    owner=owners[item['owner']];family=owner['identity'][0];piece=item['piece'];coords=[]
    for k,label in enumerate(labels):
        axis=k%2
        lo=min(m['integer_lower_left_bounds'][axis][0]+mode_rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_um'][k] for m in owner['modes'])
        hi=max(m['integer_lower_left_bounds'][axis][1]+mode_rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_um'][k] for m in owner['modes'])
        coords.append(model.new_int_var(lo,hi,f'rect_{item["component"]}_{label}_um').index)
    record={**item,'coordinates':coords,'mode_links':[]}
    for mode in owner['modes']:
        offsets=mode_rectangles[family][mode['mode']]['rectangles'][piece]['outward_offsets_um'];constraints=[]
        for k,(var,offset) in enumerate(zip(coords,offsets)):
            constraints.append(linear({var:1,owner['positions'][k%2]:-1},offset,offset,mode['selector']));coordinate_links+=1
        record['mode_links'].append({'mode':mode['mode'],'mode_selector':mode['selector'],'outward_offsets_um':offsets,'constraints':constraints})
    components.append(record)
for item in component_pairs:
    ai,bi=item['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];selectors=[];constraints=[]
    directions=[{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}]
    for direction,coefficients in enumerate(directions):
        selector=model.new_bool_var(f'separate_{ai}_{bi}_{direction}').index;selectors.append(selector);constraints.append(linear(coefficients,cp_model.INT_MIN,-226,selector))
    separations.append({**item,'selectors':selectors,'constraints':constraints,'one_direction_constraint':linear({v:1 for v in selectors},1,1)})
'''
source=source[:start]+replacement+source[end:]
changes=[("'pairs':pairs,'symmetry_constraints':symmetry","'pairs':pairs,'rigid_components':components,'rectangle_separations':separations,'rectangle_gap_um':226,'symmetry_constraints':symmetry"),
    ("'reused_pair_region_preparation_seconds':load(FIRST/'compact-pair-regions-v2/checks.json')['seconds'],'reused_pair_integer_preparation_seconds':load(PRIOR/'checks.json')['seconds'],","'rigid_rectangle_preparation_seconds':load(RID/'checks.json')['seconds'],"),
    ("inputs=[Path(__file__),","inputs=[Path(__file__),RID/'plan.json',RID/'checks.json',RID/'mode-rectangles.json',RID/'components.json',RID/'component-pairs.json',RID/'audit-v3/plan.json',RID/'audit-v3/checks.json',"),
    ("All78 moving-part pairs independently select certified pair regions tied to both owner modes.","Replace moving-part pair regions with20 rigid outward component rectangles. Every coordinate is tied to its original owner position and selected source mode. All183 different-owner rectangle pairs choose one of four axis separations of226micrometres. Components belonging to one original remain rigid and have no artificial mutual spacing."),
    ("'pair_geometry_marginals':sum(len(p['mode_marginals']) for p in pairs),","'pair_geometry_marginals':0,'rigid_components':len(components),'rigid_component_coordinate_links':coordinate_links,'different_owner_rectangle_pairs':len(separations),'rectangle_direction_selectors':4*len(separations),"),
]
for old,new in changes:
    assert old in source,old
    source=source.replace(old,new)
p=ROOT/'output/build_h5_rigid_rectangle_model_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'prepared':p.name,'source_unary_regions_preserved':True,'rigid_pair_separation_gap_um':226})
