from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/run_h5_first55_integer_regions_v2_20261029.py').read_text(encoding='utf-8')
for old,new in [('output/h5-first55-integer-mode-regions-v2-20261029','output/h5-first55-cog-site-masks-20261029'),('model-audit-v2','model-audit'),('geometry-audit','integer-audit'),('check_h5_first55_integer_candidate_20261029.py','check_h5_cog_site_mask_candidate_20261029.py')]:
    assert old in source,old
    source=source.replace(old,new)
p=ROOT/'output/run_h5_cog_site_mask_model_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'prepared':p.name,'model_audit_required':True,'maximum_calls':1,'full66_original_source_checker_prepared':True})
