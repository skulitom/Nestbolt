from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head.startswith('6a0c7b56')
source=(ROOT/'output/push_h5_source_valid11_checkpoint_20261029.py').read_text(encoding='utf-8')
changes=[("OUT=ROOT/'output/h5-source-valid11-main-sync-20261029'","OUT=ROOT/'output/h5-first55-construction-main-sync-20261029'"),("OLD='407f91ed4d1e0b13f3c467800039d4ad2bcdfd5a';NEW='f81a9ccde862a1eff5cc00a10328dcb5a798d5e0'","OLD='f81a9ccde862a1eff5cc00a10328dcb5a798d5e0';NEW='"+head+"'"),('40814954855','40819131061'),('benchmarks/results/h5-source-valid-eleven-and-first-sheet-preparation-20261029','benchmarks/results/h5-first55-complete-and-reduced-construction-searches-20261029')]
for old,new in changes:
    assert old in source,old
    source=source.replace(old,new)
p=ROOT/'output/push_h5_first55_construction_checkpoint_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'prepared':p.name,'head':head,'prior_main_required':'f81a9ccd','CI_required':40819131061,'all6_pass_required':True,'normal_atomic_fast_forward_only':True})
