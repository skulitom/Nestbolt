from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/audit_h5_rigid_rectangle_response_20261029.py').read_text(encoding='utf-8')
changes=[('rigid-model','area-cut-model'),('rigid-search','area-cut-search'),('rigid-response-audit','area-cut-response-audit'),('len(model.constraints)==63132','len(model.constraints)==63201'),("result['returned_response_branches']==190637", "result['returned_response_branches']==32584"),("result['returned_response_conflicts']==24805", "result['returned_response_conflicts']==246"),("'max_lp':          0            0       0        13  8'990           0", "'max_lp':          0            0       1        19  10'052           0"),("'default_lp':          0            0       0         0  1'357           0", "'default_lp':          0            0       0         0   1'680           0"),("'max_lp_overflow_statistic':13,'max_lp_bad_statistic':8990,'default_lp_bad_statistic':1357", "'max_lp_adjust_statistic':1,'max_lp_overflow_statistic':19,'max_lp_bad_statistic':10052,'default_lp_bad_statistic':1680")]
for old,new in changes:
    assert old in source,old
    source=source.replace(old,new)
p=ROOT/'output/audit_h5_area_cut_response_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'prepared':p.name,'raw_LP_diagnostics_and_slice_overrun_retained':True})
