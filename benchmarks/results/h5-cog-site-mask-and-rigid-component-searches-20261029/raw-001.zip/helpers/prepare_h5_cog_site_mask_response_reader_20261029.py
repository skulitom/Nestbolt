from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/audit_h5_first55_integer_response_20261029.py').read_text(encoding='utf-8')
changes=[('output/h5-first55-integer-mode-regions-v2-20261029','output/h5-first55-cog-site-masks-20261029'),('model-audit-v2','model-audit'),('len(model.variables)==88835 and len(model.constraints)==317577','len(model.variables)==23102 and len(model.constraints)==109655'),("response.num_branches==result['returned_response_branches']==0","response.num_branches==result['returned_response_branches']==49571"),("assert 'Stopped after presolve.' in log and 'status: UNKNOWN' in log","assert 'Stopped after presolve.' not in log and 'status: UNKNOWN' in log and 'Starting search' in log\nlp_diagnostics = log[log.index('Lp debug'):log.index('Lp pool')]\nassert \"'max_lp_sym':          0            0       0         4  5'953\" in lp_diagnostics\nwith (OUT/'lp-diagnostics.txt').open('x',encoding='utf-8',newline='\\n') as f:f.write(lp_diagnostics)"),("'stopped_after_presolve':True,'branches':0,'conflicts':0","'stopped_after_presolve':False,'branches':response.num_branches,'conflicts':0,'max_lp_sym_overflow_statistic':4,'max_lp_sym_bad_statistic':5953")]
for old,new in changes:
    assert old in source,old
    source=source.replace(old,new)
p=ROOT/'output/audit_h5_cog_site_mask_response_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'prepared':p.name,'LP_diagnostics_and_slice_overrun_preserved':True})
