from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/audit_h5_cog_site_mask_response_20261029.py').read_text(encoding='utf-8')
changes=[("MODEL=BASE/'model';SEARCH=BASE/'search';OUT=BASE/'response-audit'", "MODEL=BASE/'rigid-model';SEARCH=BASE/'rigid-search';OUT=BASE/'rigid-response-audit'"),('model-audit/', 'rigid-model-audit/'),('len(model.variables)==23102 and len(model.constraints)==109655','len(model.variables)==11638 and len(model.constraints)==63132'),("result['returned_response_branches']==49571", "result['returned_response_branches']==190637"),("result['returned_response_conflicts']==0", "result['returned_response_conflicts']==24805"),("assert \"'max_lp_sym':          0            0       0         4  5'953\" in lp_diagnostics", "assert \"'max_lp':          0            0       0        13  8'990           0\" in lp_diagnostics\nassert \"'default_lp':          0            0       0         0  1'357           0\" in lp_diagnostics"),("'conflicts':0,'max_lp_sym_overflow_statistic':4,'max_lp_sym_bad_statistic':5953", "'conflicts':response.num_conflicts,'max_lp_overflow_statistic':13,'max_lp_bad_statistic':8990,'default_lp_bad_statistic':1357")]
for old,new in changes:
    assert old in source,old
    source=source.replace(old,new)
p=ROOT/'output/audit_h5_rigid_rectangle_response_20261029.py';compile(source,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'prepared':p.name,'raw_LP_diagnostics_and_slice_overrun_retained':True})
