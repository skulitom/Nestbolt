"""Run each of six distinct conditional release cases once under shared budget."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,subprocess,shutil,sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-single-cog-release-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(ROOT/'output/h5-fixed-six-completion-20261026/audit-provenance-repaired/checks.json')['passed'];start=time.perf_counter();deadline=start+180;shutil.copyfile(__file__,OUT/'run.py')
    write(OUT/'budget.json',{'utc':datetime.now(timezone.utc).isoformat(),'start_perf_counter':start,'deadline_perf_counter':deadline,'shared_seconds':180,'per_case_seconds':60,'maximum_cases':6,'solver_calls':0,'each_release_set_once':True})
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [ROOT/'output/prove_h5_single_cog_release.py',ROOT/'output/h5-fixed-six-completion-20261026/audit-provenance-repaired/checks.json',OUT/'helper-preparation.json']},'released_cog_parts':list(range(3,9)),'method':'Six distinct leave-one-cog-position-free conditional real-domain diagnostics, each once, at most60seconds each and180seconds shared. Each still requires all66 originals for final acceptance; no removed part is omitted from the intended final layout. Stop at caps and preserve pending cases. No solver/native call.'})
    results=[];pending=[]
    for part in range(3,9):
        if time.perf_counter()>=deadline:pending.append(part);continue
        began=time.perf_counter()
        try:
            r=subprocess.run([sys.executable,str(ROOT/'output/prove_h5_single_cog_release.py'),str(part)],cwd=ROOT,capture_output=True,timeout=max(.01,min(65,deadline-time.perf_counter()+5)));(OUT/f'release-{part}-stdout.txt').write_bytes(r.stdout);(OUT/f'release-{part}-stderr.txt').write_bytes(r.stderr);record={'released_part':part,'seconds':time.perf_counter()-began,'exit_code':r.returncode};write(OUT/f'release-{part}-process.json',record);assert r.returncode==0
            result=load(OUT/f'release-{part}/result.json');results.append(result);print({**result,'case':part},flush=True)
        except subprocess.TimeoutExpired as e:
            (OUT/f'release-{part}-stdout.txt').write_bytes(e.stdout or b'');(OUT/f'release-{part}-stderr.txt').write_bytes(e.stderr or b'');write(OUT/f'release-{part}-process.json',{'released_part':part,'seconds':time.perf_counter()-began,'timeout':True});pending.append(part);break
    write(OUT/'results.json',results);write(OUT/'pending-cases.json',sorted(set(pending+list(range(3+len(results),9)))))
    write(OUT/'result.json',{'seconds':time.perf_counter()-start,'completed_cases':len(results),'pending_cases':len(load(OUT/'pending-cases.json')),'cases_with_internal_pending_domains':sum(r['pending_domains']>0 for r in results),'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False})
    print(load(OUT/'result.json'),flush=True)
if __name__=='__main__':main()
