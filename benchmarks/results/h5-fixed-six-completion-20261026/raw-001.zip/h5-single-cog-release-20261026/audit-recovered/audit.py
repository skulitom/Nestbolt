"""Verify all six distinct release censuses and their shared preparation bound."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,subprocess,sys,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-single-cog-release-20261026';OUT=BASE/'audit-recovered'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();result=load(BASE/'result.json');assert result['completed_cases']==6 and not result['pending_cases'] and not result['cases_with_internal_pending_domains'] and result['seconds']<=180
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'budget.json',BASE/'result.json',BASE/'results.json',ROOT/'output/audit_h5_single_cog_release.py']},'method':'Independently replay each of the six different release cases, once, after all preparation is closed. Verify source hashes and all exact corner/polygon events; compare the complete16-query/2418-domain inventory in every case. Verify all extra witness query/mutual sources against the committed archive. Preserve case process logs, aggregate residuals and original item mapping. No solver or native call.'})
    # The witness recheck also reads these three files; record their provenance explicitly.
    manifest=load(ROOT/'benchmarks/results/h5-bounded-source-search-20261026/raw-manifest.json');known={r['path']:r['sha256'] for r in manifest['files']+manifest['aliases']};extra={}
    for n in ['queries/018.json','queries/019.json','mutual/081.json']:
        p=ROOT/'output/h5-full-original-joint-prepared-20261025'/n;h=digest(p);assert h==known['source-inputs/'+p.relative_to(ROOT).as_posix()];extra[p.relative_to(ROOT).as_posix()]=h
    write(OUT/'witness-source-provenance.json',{'passed':True,'inputs':extra,'applies_also_to_fixed_six_completion_replay':True})
    rows=[];six=load(ROOT/'output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic/audit/six-cog-positions.json')
    for part in range(3,9):
        if part==3:
            prior=BASE/'audit';assert load(prior/'release-3-process.json')['exit_code']==0 and load(BASE/'release-3/audit/checks.json')['passed']
            for n,h in load(BASE/'release-3/audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h
            write(OUT/'release-3-reused.json',{'already_completed':True,'solver_or_proof_repeated':False,'checks_sha256':digest(BASE/'release-3/audit/checks.json'),'original_process_sha256':digest(prior/'release-3-process.json')})
        else:
            assert not (BASE/f'release-{part}/audit').exists()
            began=time.perf_counter();p=subprocess.run([sys.executable,str(ROOT/'output/audit_h5_single_cog_release.py'),str(part)],cwd=ROOT,capture_output=True,timeout=60);(OUT/f'release-{part}-stdout.txt').write_bytes(p.stdout);(OUT/f'release-{part}-stderr.txt').write_bytes(p.stderr);write(OUT/f'release-{part}-process.json',{'exit_code':p.returncode,'seconds':time.perf_counter()-began});assert p.returncode==0,p.stderr.decode()

        checks=load(BASE/f'release-{part}/audit/checks.json');assert checks['passed'] and checks['recorded_domains']==2418;queryrows=load(BASE/f'release-{part}/summary.json');w=next(c for c in six if c['part']==part)
        row={'released_part':part,'released_original_item':w['item'],'released_source_sheet':w['sheet'],'all_original_parts_still_required':66,'residual_domains':load(BASE/f'release-{part}/audit/conditional-region-summary.json')['residual_domains'],'residual_fragments':checks['residual_fragments'],'lower_dimensional_residuals':checks['lower_dimensional_residuals'],'residual_queries':[q for q in queryrows if q['residual_domains']],'audit_seconds':checks['seconds']};rows.append(row);print(row,flush=True)
    write(OUT/'release-comparison.json',rows);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'complete_release_cases':6,'original_bracket_domains_replayed':6*2418,'all_source_clauses_and_closed_boundaries_retained':True,'independent_case_audits_passed':6,'each_case_and_audit_run_once':True,'shared_preparation_seconds':result['seconds'],'shared_preparation_limit_seconds':180,'additional_witness_sources_verified':3,'cases_leaving_no_bracket_region':[r['released_part'] for r in rows if not r['residual_domains']],'cases_with_conditional_bracket_regions':[r['released_part'] for r in rows if r['residual_domains']],'released_cogs_still_required':True,'no_joint_bracket_pair_or_released_cog_placement_claimed':True,'solver_calls':0,'native_calls':0,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
if __name__=='__main__':main()
