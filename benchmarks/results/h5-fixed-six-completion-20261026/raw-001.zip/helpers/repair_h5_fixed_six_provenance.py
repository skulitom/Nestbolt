"""Resolve two witness audit files from their original committed manifest."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed-six-completion-20261026';source=ROOT/'output/audit_h5_fixed_six_completion.py';target=ROOT/'output/audit_h5_fixed_six_completion_repaired.py';s=source.read_text(encoding='utf-8')
a="OUT=BASE/'audit'";assert s.count(a)==1;s=s.replace(a,"OUT=BASE/'audit-provenance-repaired'")
a="    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h==known['source-inputs/'+n]";assert s.count(a)==1
b="""    olderpath=ROOT/'benchmarks/results/h5-guarded-cell-search-20261025/raw-manifest.json';older=load(olderpath);oldknown={r['path']:r['sha256'] for r in older['files']+older['aliases']}
    repair=load(BASE/'audit/provenance-repair.json');assert digest(olderpath)==repair['earlier_manifest_sha256']
    fallback=set(repair['fallback_inputs'])
    for n,h in plan['inputs'].items():
        reference=oldknown['source-inputs/'+n] if n in fallback else known['source-inputs/'+n]
        assert digest(ROOT/n)==h==reference
"""
s=s.replace(a,b)
record={'reason':'The latest archive contains the six-cog positions but not both historical witness audit summaries. Resolve exactly those two immutable input hashes from their original committed guarded-cell manifest. Preserve the initial audit script/plan/failure; change no geometry, clipping calculation, domain, rule or proof.','source':source.relative_to(ROOT).as_posix(),'source_sha256':sha256(source.read_bytes()).hexdigest(),'earlier_manifest':'benchmarks/results/h5-guarded-cell-search-20261025/raw-manifest.json','earlier_manifest_sha256':sha256((ROOT/'benchmarks/results/h5-guarded-cell-search-20261025/raw-manifest.json').read_bytes()).hexdigest(),'fallback_inputs':['output/h5-guarded-cell-search-20261025/first-sheet-four-cog-diagnostic/audit/checks.json','output/h5-guarded-cell-search-20261025/six-cog-geometry-audit/checks.json'],'target':target.relative_to(ROOT).as_posix(),'target_sha256':sha256(s.encode()).hexdigest(),'solver_calls':0}
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (BASE/'audit/provenance-repair.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(target)
