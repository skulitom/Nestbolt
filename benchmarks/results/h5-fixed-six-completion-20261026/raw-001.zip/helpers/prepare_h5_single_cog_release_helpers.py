"""Prepare distinct leave-one-position-free geometry diagnostics and readbacks."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-single-cog-release-20261026';OUT.mkdir()
source=ROOT/'output/prove_h5_fixed_six_completion.py';s=source.read_text(encoding='utf-8');changes={
"import json,time,shutil,traceback":"import json,time,shutil,traceback,sys",
"OUT=ROOT/'output/h5-fixed-six-completion-20261026'":"PART=int(sys.argv[1]);assert PART in range(3,9);OUT=ROOT/'output/h5-single-cog-release-20261026'/f'release-{PART}'",
"deadline=start+180":"deadline=min(start+60,load(OUT.parent/'budget.json')['deadline_perf_counter'])",
"spec['parts'][:3]":"spec['parts'][:2]",
"assert queries==list(range(18))":"assert queries==list(range(16));six=[p for p in six if p['part']!=PART];assert len(six)==5",
"'proof_budget_seconds':180":"'proof_budget_seconds':60,'released_cog_part':PART,'five_fixed_cog_positions':six,'required_originals':66,'released_cog_still_must_be_placed':True",
"'planned_queries':18":"'planned_queries':16",
"'all_exclusions_conditional_on_exact_six_witness_poses':True":"'all_exclusions_conditional_on_five_fixed_witness_poses':True,'released_cog_part':PART,'released_cog_still_required':True"
}
for a,b in changes.items():assert s.count(a)==1,a;s=s.replace(a,b)
begin=s.index("        'method':");end=s.index("})\n    completed",begin)
s=s[:begin]+"        'method':'Distinct conditional diagnostic: release exactly one of the six known cog positions while keeping the other five and57 original source placements fixed. Both original brackets, the insert and released cog remain mandatory in any final layout; this diagnostic only examines the complete real bracket-anchor domains against the five fixed cogs. Cover all16 original bracket queries and2418 inward domains. Use exact integer box certificates then complete rational clipping with every boundary/line/point retained. Preserve every residual and cap. A nonempty residual is not a complete bracket pair or a place for the released cog. No solver/native call, source geometry or clearance changes.'"+s[end:]
target=ROOT/'output/prove_h5_single_cog_release.py'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
records=[{'source':source.relative_to(ROOT).as_posix(),'source_sha256':sha256(source.read_bytes()).hexdigest(),'target':target.relative_to(ROOT).as_posix(),'target_sha256':sha256(target.read_bytes()).hexdigest(),'replacements':changes}]
source=ROOT/'output/audit_h5_fixed_six_completion_repaired.py';s=source.read_text(encoding='utf-8');changes={
"import json,time,shutil,traceback":"import json,time,shutil,traceback,sys",
"BASE=ROOT/'output/h5-fixed-six-completion-20261026';OUT=BASE/'audit-provenance-repaired'":"PART=int(sys.argv[1]);assert PART in range(3,9);BASE=ROOT/'output/h5-single-cog-release-20261026'/f'release-{PART}';OUT=BASE/'audit'",
"repair=load(BASE/'audit/provenance-repair.json')":"repair=load(ROOT/'output/h5-fixed-six-completion-20261026/audit/provenance-repair.json')",
"spec['parts'][:3]":"spec['parts'][:2]",
"==list(range(18))":"==list(range(16));assert plan['released_cog_part']==PART;six=[p for p in six if p['part']!=PART];assert len(six)==5 and plan['five_fixed_cog_positions']==six and plan['released_cog_still_must_be_placed']",
"==result['planned_domains']==2756":"==result['planned_domains']==2418",
" and sum(s['residual_domains'] for s in br)==0":"",
"'all18_queries_and2756_original_domains_replayed':True":"'all16_queries_and2418_original_domains_replayed':True",
"'all2418_bracket_domains_continuously_excluded':True":"'all2418_bracket_domains_examined':True,'released_cog_part':PART,'released_cog_still_required':True",
"'conditional_on_exact_six_positions':True":"'conditional_on_five_fixed_positions':True"
}
for a,b in changes.items():assert s.count(a)==1,a;s=s.replace(a,b)
start=s.index("    write(OUT/'verified-residuals.json',residuals)");end=s.index("    checks=",start)
s=s[:start]+"    write(OUT/'verified-residuals.json',residuals);write(OUT/'conditional-region-summary.json',{'released_cog_part':PART,'released_cog_still_required':True,'fixed_cog_positions':six,'all2418_bracket_domains_examined':True,'residual_domains':counts['residual_domains'],'residual_fragments':counts['residual_fragments'],'scope':'Residuals are conditional bracket regions with five cogs fixed and one cog position released. They do not place both brackets, the insert or the released cog and do not establish a66-original target layout. All counts, source geometry and native/material guards remain unchanged.','full_target_witness':False,'H5_complete':False})\n"+s[end:]
s=s.replace('Empty real domains certify no integer completion only with the exact six cog poses fixed. Never apply this conditional exclusion to moving cogs.','Empty real domains certify no integer bracket anchor only with the five selected cog poses fixed; nonempty residuals do not place both brackets or the released cog. Never apply a conditional exclusion to moving fixed cogs.')
target=ROOT/'output/audit_h5_single_cog_release.py'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
records.append({'source':source.relative_to(ROOT).as_posix(),'source_sha256':sha256(source.read_bytes()).hexdigest(),'target':target.relative_to(ROOT).as_posix(),'target_sha256':sha256(target.read_bytes()).hexdigest(),'replacements':changes})
with (OUT/'helper-preparation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'generated_helpers':records,'maximum_distinct_release_cases':6,'solver_calls':0},f,indent=2);f.write('\n')
print({'helpers_prepared':2,'root':str(OUT)})
