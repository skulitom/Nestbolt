"""Prepare a new receipt for the next authorized normal main push."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];source=ROOT/'output/push_h5_guided_checkpoints.py';target=ROOT/'output/push_h5_bounded_checkpoints.py';s=source.read_text(encoding='utf-8')
changes={'h5-guided-main-sync-20261025':'h5-bounded-main-sync-20261026','40242602102':'40246226212','728b2db2e86c2d123920fdceb8e3e2c1bcf1f66e':'822a5f67428e6dfdecab7bcea45e7c89cc31b159','613594568fb49a71abf0248aec218a6b12f63319':'728b2db2e86c2d123920fdceb8e3e2c1bcf1f66e',"['0','10']":"['0','3']","'pushed_commits':10":"'pushed_commits':3"}
for a,b in changes.items():assert a in s;s=s.replace(a,b)
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print(target)
