"""Resume unfinished independent readbacks without repeating completed case3."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-single-cog-release-20261026';source=ROOT/'output/audit_h5_single_cog_release_census.py';target=ROOT/'output/audit_h5_single_cog_release_census_recovered.py';s=source.read_text(encoding='utf-8')
a="OUT=BASE/'audit'";assert s.count(a)==1;s=s.replace(a,"OUT=BASE/'audit-recovered'")
a="        began=time.perf_counter();p=subprocess.run([sys.executable,str(ROOT/'output/audit_h5_single_cog_release.py'),str(part)],cwd=ROOT,capture_output=True,timeout=60);(OUT/f'release-{part}-stdout.txt').write_bytes(p.stdout);(OUT/f'release-{part}-stderr.txt').write_bytes(p.stderr);write(OUT/f'release-{part}-process.json',{'exit_code':p.returncode,'seconds':time.perf_counter()-began});assert p.returncode==0,p.stderr.decode()";assert s.count(a)==1
b="""        if part==3:
            prior=BASE/'audit';assert load(prior/'release-3-process.json')['exit_code']==0 and load(BASE/'release-3/audit/checks.json')['passed']
            for n,h in load(BASE/'release-3/audit/plan.json')['inputs'].items():assert digest(ROOT/n)==h
            write(OUT/'release-3-reused.json',{'already_completed':True,'solver_or_proof_repeated':False,'checks_sha256':digest(BASE/'release-3/audit/checks.json'),'original_process_sha256':digest(prior/'release-3-process.json')})
        else:
            assert not (BASE/f'release-{part}/audit').exists()
            began=time.perf_counter();p=subprocess.run([sys.executable,str(ROOT/'output/audit_h5_single_cog_release.py'),str(part)],cwd=ROOT,capture_output=True,timeout=60);(OUT/f'release-{part}-stdout.txt').write_bytes(p.stdout);(OUT/f'release-{part}-stderr.txt').write_bytes(p.stderr);write(OUT/f'release-{part}-process.json',{'exit_code':p.returncode,'seconds':time.perf_counter()-began});assert p.returncode==0,p.stderr.decode()
"""
s=s.replace(a,b);a="checks['residual_domains']";assert s.count(a)==1;s=s.replace(a,"load(BASE/f'release-{part}/audit/conditional-region-summary.json')['residual_domains']")
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
record={'failure':'KeyError: residual_domains in aggregate row after case3 independent audit completed successfully. Counter omitted the zero-valued key; the separately verified per-case conditional-region-summary.json explicitly records zero.','source':source.relative_to(ROOT).as_posix(),'source_sha256':sha256(source.read_bytes()).hexdigest(),'target':target.relative_to(ROOT).as_posix(),'target_sha256':sha256(target.read_bytes()).hexdigest(),'correction':'Read the explicit verified residual count from each case conditional summary. Preserve and reuse completed case3 proof audit; run only cases4..8 whose audit directories do not exist. No geometry preparation, solver call or completed audit is repeated.','completed_case_reused':3,'remaining_cases':[4,5,6,7,8],'solver_calls':0}
with (BASE/'audit/failure-recovery.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(target)
