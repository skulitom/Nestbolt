"""Seal the first source-valid short11, its failed predecessor and first55 preflight."""
from pathlib import Path
from datetime import datetime, timezone
import ast, json, shutil, subprocess, sys
from pack_h5_evidence_archive import pack, digest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
MODES=ROOT/'output/h5-short11-all-modes-preflight-20261029'
MIP=ROOT/'output/h5-short11-all-mode-region-model-20261029'
CP=ROOT/'output/h5-short11-integer-mode-regions-20261029'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029'
SYNC=ROOT/'output/h5-relative-region-main-sync-20261029'
PUB=CP/'publication'
NAME='h5-source-valid-eleven-and-first-sheet-preparation-20261029'
OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,v):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(v)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD')
assert head=='407f91ed4d1e0b13f3c467800039d4ad2bcdfd5a' and not git('diff','HEAD','--name-only')
for p in [MODES/'audit',MODES/'pair-region-preflight/audit',MIP/'audit',MIP/'response-audit',CP/'geometry-audit',CP/'model-audit',CP/'response-audit',CP/'source-audit',FIRST/'audit']:
    assert load(p/'checks.json')['passed'],str(p)
failed=load(MIP/'response-audit/checks.json'); success=load(CP/'response-audit/checks.json'); source=load(CP/'source-audit/checks.json')
assert failed['outcome']=='TIME_LIMIT_NO_ASSIGNMENT' and failed['logged_nodes']==214 and failed['assignments']==0
assert failed['solve_slice_overrun_seconds']==0.3027277000946924 and failed['algorithm_and_shared_overruns_seconds']==0
assert success['solver_status']=='OPTIMAL' and success['source_valid11'] and success['all_overruns_seconds']==0
assert source['source_valid11'] and source['original_source_pair_checks']==55 and source['original_cutouts_preserved']==21
assert not source['source_valid66'] and not load(FIRST/'audit/checks.json')['first55_constructed']
prior=load(ROOT/'benchmarks/results/h5-complete-pair-separation-and-relative-region-searches-20261029/publication-review.json')
production=source_digest(); readmes={n:digest(ROOT/n) for n in prior['current_readmes']}
assert production==prior['production_digest'] and readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
ci=load(PUB/'main-ci.json'); jobs=load(PUB/'main-ci-jobs.json')['jobs']
assert load(PUB/'main.json')['commit']['sha']==ci['head_sha']==head
assert ci['id']==40814954855 and ci['status']=='completed' and ci['conclusion']=='success'
assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['normal_atomic_fast_forward'] and receipt['prior_main_all6_pass']
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json'
assert sum(r['excluded_by'] is None for r in load(frontier))==440
assert digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(name,path):
    assert path.is_file() and '.claude' not in path.parts
    members[name]=path
    if path.name in ['plan.json','opened.json'] or path.suffix=='.py':queue.append(path)
for folder in [MODES,MIP,CP,FIRST,SYNC]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['audit_h5_short11_all_modes_20261029.py','h5_exact_convex_partition_tools_20261029.py','prepare_h5_all_mode_pair_regions_20261029.py','audit_h5_all_mode_pair_regions_20261029.py','build_h5_all_mode_region_model_20261029.py','audit_h5_all_mode_region_model_20261029.py','run_h5_all_mode_region_model_20261029.py','audit_h5_all_mode_region_response_20261029.py','prepare_h5_integer_mode_regions_20261029.py','audit_h5_integer_mode_regions_20261029.py','build_h5_integer_mode_regions_20261029.py','audit_h5_integer_mode_region_model_20261029.py','check_h5_integer_mode_candidate_20261029.py','run_h5_integer_mode_regions_20261029.py','audit_h5_integer_mode_response_20261029.py','audit_h5_integer_mode_source_20261029.py','prepare_h5_first55_after_short11_20261029.py','audit_h5_first55_preflight_20261029.py','prepare_h5_relative_region_main_push_20261029.py','push_h5_relative_region_checkpoint_20261029.py','pack_h5_evidence_archive.py','ccd1.py','verify_h5_source_valid11_archive_20261029.py',Path(__file__).name]
for name in helpers:add('helpers/'+name,ROOT/'output'/name)
while queue:
    path=queue.pop()
    if path in seen:continue
    seen.add(path)
    if path.name in ['plan.json','opened.json']:
        for name,h in load(path).get('inputs',{}).items():
            p=ROOT/name;assert p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts)
            assert digest(p)==h,name
            bindings[name]=h;add('source-inputs/'+name,p)
    elif path.suffix=='.py':
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    p=ROOT/folder/(module+'.py')
                    if p.is_file():add('imported-helpers/'+folder+'/'+p.name,p)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(MODES/'audit/checks.json','all-mode-audit.json'),(MODES/'pair-region-preflight/audit/checks.json','pair-region-audit.json'),(MIP/'audit/checks.json','continuous-model-audit.json'),(MIP/'response-audit/checks.json','continuous-response-audit.json'),(CP/'geometry-audit/checks.json','integer-geometry-audit.json'),(CP/'model-audit/checks.json','integer-model-audit.json'),(CP/'response-audit/checks.json','integer-response-audit.json'),(CP/'source-audit/checks.json','independent-source-audit.json'),(CP/'search/source-response/candidate-source11.json','source-valid11.json'),(CP/'source-audit/replayed-source-checks.json','source-valid11-checks.json'),(FIRST/'checks.json','first55-preflight.json'),(FIRST/'audit/checks.json','first55-preflight-audit.json'),(FIRST/'plan.json','next-step.json'),(FIRST/'inventory.json','first55-inventory.json'),(FIRST/'partial40-source-checks.json','partial40-source-checks.json'),(SYNC/'receipt.json','prior-main-push-receipt.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40814954855,'main_all6_pass':True,'normal_push_requires_fresh_head_and_live_run_checks':True,'unchanged_frontier_path':frontier.relative_to(ROOT).as_posix(),'unchanged_frontier_sha256':digest(frontier),'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'closed_new_solver_calls':2,'continuous_outcome':'TIME_LIMIT_NO_ASSIGNMENT','continuous_solve_slice_overrun_seconds':failed['solve_slice_overrun_seconds'],'continuous_overall_algorithm_shared_overruns_seconds':0,'integer_outcome':'SOURCE_VALID11','integer_solver_status':'OPTIMAL','integer_all_overruns_seconds':0,'source_valid_short11':True,'source_valid_short_family_counts':{'bracket':5,'insert':4,'cog':2},'first55_fixed_originals':29,'first55_moving_originals':26,'first55_preflight_audited':True,'source_valid_partial40':True,'first55_constructed':False,'source_valid66_created':False,'valid64_preserved':True,'new_allocation_exclusions':0,'remaining_candidates':440,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(CP/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(CP/'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8')
old='Latest H5 evidence: [complete pair separation and relative-region searches](../benchmarks/results/h5-complete-pair-separation-and-relative-region-searches-20261029.md).\nThe 440 necessary allocation candidates remain open. The complete 66-part layout and\nH5 quality matrix remain unverified; the existing valid 64-part layout is preserved.'
new=f'Latest H5 evidence: [source-valid eleven-part short sheet and first-sheet preparation](../benchmarks/results/{NAME}.md).\nThe short sheet now passes independent original-source checks for five brackets,\nfour inserts and two cogs. Its matching 55-part first sheet remains to construct.\nThe 440 necessary allocation candidates, full66 checks and H5 matrix remain open;\nthe existing valid 64-part layout is preserved.'
assert content.count(old)==1
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(content.replace(old,new,1))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'source_valid11':True,'first55_constructed':False,'remaining_candidates':440,'completion_percent':60})
