"""Prepare a guarded normal push after all six prior main checks passed."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head.startswith('407f91ed')
source = (ROOT / 'output/push_h5_axis_partition_checkpoint_20261029.py').read_text(encoding='utf-8')
replacements = [
    ("OUT=ROOT/'output/h5-axis-partition-main-sync-20261029'", "OUT=ROOT/'output/h5-relative-region-main-sync-20261029'"),
    ("OLD='9dab2f4e5290a72c208d132f6e21ad31340f365c';NEW='8c434a2b54e7bd47a8acd341772a4496efbe0e87'", "OLD='8c434a2b54e7bd47a8acd341772a4496efbe0e87';NEW='" + head + "'"),
    ('40805531238', '40811474503'),
    ("['benchmarks/results/h5-short11-source-readback-and-translation-cycle-20261029','benchmarks/results/h5-axis-choice-rejection-and-exact-source-partition-20261029']", "['benchmarks/results/h5-complete-pair-separation-and-relative-region-searches-20261029']"),
]
for old, new in replacements:
    assert old in source, old
    source = source.replace(old, new)
path = ROOT / 'output/push_h5_relative_region_checkpoint_20261029.py'
compile(source, str(path), 'exec')
with path.open('x', encoding='utf-8', newline='\n') as f:
    f.write(source)
print({'prepared': path.name, 'head': head, 'all6_prior_checks_required': True,
       'unchanged_remote_head_required': True, 'normal_atomic_fast_forward_only': True})
