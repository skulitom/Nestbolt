from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,math,time,copy,shutil
import numpy as np
from shapely.geometry import Polygon
from h5_hard_cell_vector_model_20261107 import compile_model,Objective
from h5_hard_cell_direct_readback_20261107 import verify
from h5_hard_cell_compound_modes_20261107 import canonical_library,family_classes,physical_key
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-mixed-roof-hard-cells-20261107';BASE=ROOT/'output/h5-mixed-roof-continuous-model-20261107';Q=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=BASE/'audit-v2';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');original=load(SOURCE/'library.json');checked=load(SOURCE/'audit/checks.json');assert checked['passed'] and checked['library_sha256']==digest(SOURCE/'library.json');lib=load(BASE/'library.json');assert digest(BASE/'library.json')==load(BASE/'checks.json')['library_sha256'];saved=load(BASE/'initial-mode-values.json');modes=saved['modes'];values=np.asarray(saved['values']);model=load(BASE/'model.json');assert verify(model,lib,modes,values) and model==compile_model(lib,modes,values);job=load(JOB);radius=lib['angle_scale_mm']
def nominal_key(family,mode):
    if family=='cog':return ('continuous-cog',)
    px,py=map(F,original['families'][family]['source_center']);quarter=round(mode['rotation_radians']/(math.pi/2))%4;assert abs(math.remainder(mode['rotation_radians']-quarter*math.pi/2,math.tau))<1e-12;sign=-1 if mode['mirrored'] else 1;v=[]
    for point in original['families'][family]['original']:
        x,y=F(point[0])-px,F(point[1])-py;x*=sign
        for _ in range(quarter):x,y=-y,x
        v.append((x,y))
    return tuple(sorted(tuple(sorted([v[k],v[(k+1)%len(v)]])) for k in range(len(v))))
expected=copy.deepcopy(original);groups=[];classes={};cut_controls=[]
for family,options in original['family_modes'].items():
    proposed={}
    for option in options:proposed.setdefault((nominal_key(family,option),option['cell_index']),[]).append(option['mode'])
    for members in proposed.values():
        boxes=[options[i]['rectangle_mm'] for i in members];common=[max(r[0] for r in boxes),max(r[1] for r in boxes),min(r[2] for r in boxes),min(r[3] for r in boxes)];assert common[0]<common[2] and common[1]<common[3]
        for b in boxes:assert b[0]<=common[0]<common[2]<=b[2] and b[1]<=common[1]<common[3]<=b[3]
        maximum=max(abs(F(a[k])-F(b[k])) for a in boxes for b in boxes for k in range(4));assert maximum<=F(4,10**6)
        for i in members:expected['family_modes'][family][i]['rectangle_mm']=common.copy();expected['family_modes'][family][i]['center_bounds_mm']=[[common[0],common[2]],[common[1],common[3]]]
        groups.append({'family':family,'compound_modes':members,'source_rectangles':boxes,'common_rectangle':common,'conservative_common_subset':True});cut_controls.append({'family':family,'members':members,'maximum_source_bound_difference_mm':float(maximum),'common_domain_is_source_safe_subset':True})
    seen=[];classes[family]=[]
    for option in expected['family_modes'][family]:
        key=(nominal_key(family,option),tuple(map(F,option['rectangle_mm'])))
        if key not in seen:seen.append(key)
        classes[family].append(seen.index(key))
assert expected==lib and groups==load(BASE/'compound-domain-groups.json');assert canonical_library(original)==(lib,groups);assert classes==family_classes(lib)==load(BASE/'compound-classes.json')=={'bracket':list(range(19)),'insert':[0,1,2,3,0,1,2,3],'cog':[0,1]};write(OUT/'common-domain-controls.json',cut_controls)
def independent_shapes(family,mi,xy,theta=0.):
    mm=lib['family_modes'][family][mi];theta=theta if family=='cog' else mm['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if mm['mirrored'] else 1;px,py=lib['families'][family]['source_center'];tx=xy[0]-(sign*px*c-py*s);ty=xy[1]-(sign*px*s+py*c);return [Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in lib['families'][family][kind]]) for kind in ['original','clearance']]
def pair_score(polys,placed):return sum(p.intersection(other[k]).area for k,p in enumerate(polys) for other in placed)
candidates={}
for family in ['bracket','insert']:
    candidates[family]=[]
    for mode in lib['family_modes'][family]:
        bb=mode['center_bounds_mm'];points={(bb[0][0]+xi/8*(bb[0][1]-bb[0][0]),bb[1][0]+yi/8*(bb[1][1]-bb[1][0])) for xi,yi in product(range(9),repeat=2)}
        for seed in lib['source_moving_seed']:
            p=seed['center']
            if seed['identity'][0]==family and all(bb[k][0]<=p[k]<=bb[k][1] for k in [0,1]):points.add(tuple(p))
        candidates[family].append({'mode':mode['mode'],'centers':[list(p) for p in sorted(points,key=lambda p:(p[1],p[0]))]})
assert candidates==load(BASE/'compound-candidates.json');placed=[]
for seed in lib['source_moving_seed']:
    if seed['identity'][0]!='cog':continue
    i=seed['owner'];covering=[o['mode'] for o in lib['family_modes']['cog'] if all(o['center_bounds_mm'][k][0]<=seed['center'][k]<=o['center_bounds_mm'][k][1] for k in [0,1])];assert modes[i]==min(covering) and values[2*i:2*i+2].tolist()==seed['center'] and values[66+i-18]==radius*seed['angle_radians'];placed.append(independent_shapes('cog',modes[i],seed['center'],seed['angle_radians']))
records=load(BASE/'initializer-trials.json');assert [r['owner'] for r in records]==list(range(18));trials=0;total=0.
for record in records:
    i=record['owner'];identity=lib['identities'][i];assert record['identity']==identity;family=identity[0];expected_trials=[]
    for option in candidates[family]:
        for point in option['centers']:
            energy=pair_score(independent_shapes(family,option['mode'],point),placed);r=record['candidates'][len(expected_trials)];assert r['mode']==option['mode'] and r['center']==point and abs(r['score_mm2']-energy)<1e-7;expected_trials.append(r);trials+=1
    selected=min(expected_trials,key=lambda r:(r['score_mm2'],r['mode'],r['center'][1],r['center'][0]));assert len(expected_trials)==len(record['candidates']) and selected==record['selected'] and modes[i]==selected['mode'] and values[2*i:2*i+2].tolist()==selected['center'];placed.append(independent_shapes(family,modes[i],selected['center']));total+=selected['score_mm2']
assert trials==17010
def independent_rows(mm,x):
    rows=lib['fixed_source_rows'].copy()
    for i,owner in enumerate(mm['owners']):
        family=owner['identity'][0];mode=lib['family_modes'][family][owner['mode']];theta=x[66+i-18]/radius if family=='cog' else mode['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];rows.append({'part_id':family,'copy_index':owner['identity'][1],'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':mode['mirrored'],'translation':[x[2*i]-(sign*px*c-py*s),x[2*i+1]-(sign*px*s+py*c)]}})
    return rows
rows=independent_rows(model,values.tolist());assert rows==load(BASE/'seed-source66.json');source=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));assert source==load(BASE/'seed-source-checks.json') and source['originals']==66 and source['same_sheet_pairs']==1380 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026 and source['stock_failures']==0;fixedids={(r['part_id'],r['copy_index']) for r in lib['fixed_source_rows']};assert all(p['passed'] for p in source['pairs'] if any(tuple(k) in fixedids for k in p['keys']));obj=Objective(model);energy,g,details=obj.evaluate(values,True);assert load(BASE/'initial-objective.json')=={'energy_mm2':energy,'gradient':g.tolist(),**details} and abs(total-energy)<1e-7
def full_energy(mm,x):
    ps=[independent_shapes(o['identity'][0],o['mode'],x[2*i:2*i+2],x[66+i-18]/radius if i>=18 else 0.) for i,o in enumerate(mm['owners'])];return sum(ps[i][k].intersection(ps[j][k]).area for i,j in lib['pairs'] for k in [0,1])
bindings=0;vectors=1
for i,identity in enumerate(lib['identities']):
    for option in lib['family_modes'][identity[0]]:
        chosen=modes.copy();chosen[i]=option['mode'];mm=compile_model(lib,chosen,values);assert verify(mm,lib,chosen,values);bindings+=1;vectors+=chosen!=modes;assert abs(Objective(mm).score(mm['initial'])-full_energy(mm,mm['initial']))<1e-6
assert bindings==240 and vectors==208;reference=np.zeros(81);gradient_cases=0
for entries in obj.geometry(values):
    for i,j in lib['pairs']:
        if entries[i][1].intersection(entries[j][1]).area<=0:continue
        for own,other in [(i,j),(j,i)]:
            gg,_,_=moving_boundary_gradient(entries[own][1],entries[other][1],entries[own][3]);reference[2*own:2*own+2]+=gg[:2]
            if own>=18:reference[66+own-18]+=gg[2]/radius
            gradient_cases+=1
assert np.max(np.abs(reference-g))<1e-7;derivatives=[]
for variation in [0,1]:
    chosen=modes.copy()
    if variation:chosen=[(m+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,m in enumerate(chosen)]
    mm=compile_model(lib,chosen,values);bounds=np.asarray(mm['bounds']);margin=.03+np.arange(81)*.00037;point=np.clip(np.asarray(mm['initial'])+.137*np.sin(np.arange(81)*2**.5+.2+variation),bounds[:,0]+margin,bounds[:,1]-margin);val,gg=Objective(mm).evaluate(point);assert abs(val-full_energy(mm,point))<1e-6;errors=[]
    diagnostic=load(BASE/'derivative-diagnostic/records.json')
    for k in range(81):
        reference=diagnostic[variation*81+k];assert reference['variation']==variation and reference['coordinate']==k and reference['analytic']==gg[k]
        for step,sample_index in [(1e-5,1),(1e-6,2)]:
            plus=point.copy();minus=point.copy();plus[k]+=step;minus[k]-=step;numeric=(full_energy(mm,plus)-full_energy(mm,minus))/(2*step);error=abs(numeric-gg[k]);assert numeric==reference['samples'][sample_index]['numeric'] and error<.02+3e-6*abs(gg[k]),(variation,k,step,numeric,gg[k],error);errors.append(float(error))
    derivatives.append({'variation':variation,'coordinates':81,'steps':[1e-5,1e-6],'samples':162,'maximum_absolute_error':max(errors)})
write(OUT/'derivative-controls.json',derivatives);directions=[];bounds=np.asarray(model['bounds'])
for step in [1e-7,1e-6,1e-5]:
    point=np.clip(values-step*g,bounds[:,0],bounds[:,1]);after=full_energy(model,point);assert after<energy;directions.append({'step':step,'before':energy,'after':after})
write(OUT/'seed-descent-controls.json',directions);equivalence_controls=[]
for family,options in lib['family_modes'].items():
    for left,right in product(options,options):
        a=independent_shapes(family,left['mode'],[0,0])[0];b=independent_shapes(family,right['mode'],[0,0])[0];same_outline=nominal_key(family,left)==nominal_key(family,right);assert same_outline==(a.symmetric_difference(b).area<1e-8);same_domain=left['center_bounds_mm']==right['center_bounds_mm'];same_class=classes[family][left['mode']]==classes[family][right['mode']];assert same_class==(same_outline and same_domain);equivalence_controls.append({'family':family,'left':left['mode'],'right':right['mode'],'same_nominal_outline':same_outline,'same_effective_domain':same_domain,'same_compound_class':same_class})
assert len(equivalence_controls)==429 and classes['bracket'][2]!=classes['bracket'][3] and classes['insert'][1]!=classes['insert'][2] and classes['insert'][0]==classes['insert'][4] and classes['cog'][0]!=classes['cog'][1];write(OUT/'compound-equivalence-controls.json',equivalence_controls);keys=set();key=physical_key(lib,classes,modes);equivalent=0;raw=0
for i,identity in enumerate(lib['identities']):
    for option in lib['family_modes'][identity[0]]:
        if option['mode']==modes[i]:continue
        raw+=1;candidate=modes.copy();candidate[i]=option['mode'];new=physical_key(lib,classes,candidate)
        if new==key:equivalent+=1
        else:keys.add(new)
assert len(keys)==159 and equivalent==12 and raw==207 and saved['physical_key']==list(key);write(OUT/'physical-mode-controls.json',{'passed':True,'family_classes':classes,'compound_equivalence_pair_controls':429,'source_owner_options':240,'physical_owner_options':192,'unique_single_owner_physical_neighbors':159,'raw_current_equivalents':12,'raw_alternatives':207,'different_domain_same_outline_preserved':True,'conservative_alias_domain_intersections_verified':True})
negatives=[]
for kind in ['mode','source_mode','cell_index','mirror','pivot','angle','stock','coordinate','pair','parameter_count','weight']:
    mm=copy.deepcopy(model)
    if kind=='mode':mm['owners'][0]['rotation_radians']+=.01
    elif kind in ['source_mode','cell_index']:mm['owners'][0][kind]+=1
    elif kind=='mirror':mm['owners'][0]['mirrored']=not mm['owners'][0]['mirrored']
    elif kind=='pivot':mm['owners'][0]['source_center'][0]+=1
    elif kind=='angle':mm['owners'][18]['angle_coordinate']=67
    elif kind=='stock':mm['bounds'][0][0]+=1
    elif kind=='coordinate':mm['initial'][0]+=1
    elif kind=='pair':mm['pairs'].pop()
    elif kind=='parameter_count':mm['parameters']=80
    else:mm['objective_weights']['original_area']=3
    caught=False
    try:verify(mm,lib,modes,values)
    except AssertionError:caught=True
    assert caught;negatives.append({'corruption':kind,'rejected':True})
write(OUT/'negative-controls.json',negatives);controls=load(Q/'audit/optimizer-controls.json');provenance=load(Q/'audit/tool-provenance.json');assert controls['passed']
for name,r in provenance['tool_files'].items():assert digest(ROOT/name)==r['sha256']
write(OUT/'optimizer-controls.json',controls);write(OUT/'tool-provenance.json',provenance);prep=load(ROOT/'output/h5-mixed-roof-initializer-process-20261107/process.json');assert prep['passed'] and prep['closed'] and all(s['job']['closed'] and s['job']['active_processes']==0 for s in prep['stages']);charge=checked['complete_preparation_seconds']+prep['complete_seconds'];inputs=[Path(__file__),JOB,ROOT/'output/diagnose_h5_mixed_roof_derivatives_20261107.py',ROOT/'output/h5-mixed-roof-continuous-model-audit-process-20261107/process.json',ROOT/'output/h5-mixed-roof-continuous-model-audit-process-20261107/audit-stderr.txt',ROOT/'output/h5-mixed-roof-initializer-process-20261107/process.json']+[ROOT/'output'/n for n in ['h5_hard_cell_vector_model_20261107.py','h5_vector_boundary_gradient_20261107.py','h5_hard_cell_direct_readback_20261107.py','h5_hard_cell_compound_modes_20261107.py','h5_direct_pose_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_original_overlap_gradient_v2_20261107.py','h5_legacy64_source_readback.py']]+[SOURCE/n for n in ['plan.json','library.json','audit/checks.json','audit/plan.json']]+[BASE/n for n in ['plan.json','checks.json','library.json','model.json','compound-domain-groups.json','compound-classes.json','compound-candidates.json','initializer-trials.json','initial-mode-values.json','initial-objective.json','seed-source66.json','seed-source-checks.json','derivative-diagnostic/records.json','derivative-diagnostic/checks.json','audit/audit.py']]+[Q/n for n in ['audit/optimizer-controls.json','audit/tool-provenance.json']];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independent exactnominalgeometry andidenticalcommonharddomain aliases;preserve distinctcorner/side/topchoices. All17010trial scores/choices,240ownercompoundbindings/fullscores,208vectors,528pairs/81parameters,original66sourcechecks,scalargradientoracle,162 coordinates at two smaller finite-difference steps (324 samples), retaining all four diagnostic step sizes and the original large-step failure,429compoundequivalencecontrols,3descents and11corruptions. Prior source audit verifies entire hard domains including both cog cells; initializer charge includes the entire closed wrapper process;commonboundcuts areconservativesubsets. Verificationonly,nooptimizer.'});checks={'passed':True,'seconds':time.perf_counter()-start,'candidate_trials_verified':trials,'source_owner_mode_bindings':bindings,'dynamic_mode_vectors':vectors,'independent_full_score_controls':bindings,'scalar_batched_gradient_controls':gradient_cases,'independent_central_coordinates':162,'independent_central_samples':324,'original_large_step_failure_preserved':True,'seed_descent_controls':3,'compound_equivalence_controls':429,'corruption_controls':11,'distinct_cell_choices_preserved':True,'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'source_same_sheet_pairs':1380,'source_valid66':source['valid'],'initial_objective_mm2':energy,'initial_original_overlap_mm2':details['original_overlap_area_mm2'],'complete_preparation_seconds':charge,'library_sha256':digest(BASE/'library.json'),'model_sha256':digest(BASE/'model.json'),'source_optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
