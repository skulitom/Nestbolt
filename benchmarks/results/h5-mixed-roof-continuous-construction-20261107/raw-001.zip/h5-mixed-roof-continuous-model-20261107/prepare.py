"""One fresh source initializer for the33-mover compound-cell model."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
import numpy as np
from h5_hard_cell_compound_modes_20261107 import canonical_library,family_classes,physical_key
from h5_hard_cell_vector_model_20261107 import compile_model,Objective,owner_shapes,pair_energy,source_rows
from h5_hard_cell_direct_readback_20261107 import verify
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-mixed-roof-hard-cells-20261107';OUT=ROOT/'output/h5-mixed-roof-continuous-model-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py');source=load(SOURCE/'library.json');checked=load(SOURCE/'audit/checks.json');assert checked['passed'] and checked['library_sha256']==digest(SOURCE/'library.json');charge=checked['complete_preparation_seconds'];inputs=[Path(__file__),JOB]+[ROOT/'output'/n for n in ['h5_hard_cell_compound_modes_20261107.py','h5_hard_cell_direct_model_20261107.py','h5_hard_cell_vector_model_20261107.py','h5_vector_boundary_gradient_20261107.py','h5_hard_cell_direct_readback_20261107.py','h5_direct_pose_model_20261107.py','h5_mixed_direct_pose_20261107.py','h5_legacy64_source_readback.py']]+[SOURCE/n for n in ['plan.json','library.json','audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'complete_prior_preparation_seconds':charge,'method':'One source-only initializer for the changed mixed-frame-roof geometry,33movers,81parameters and15continuously rotating cogs. No finite-pool search output, optimized ancestor or old initializer point consumed. Use exact nominal outline keys plus identical effective hard rectangles; explicitly intersect near-identical alias bounds, preserving different cog and companion cells. Retain source15cog centers/angles only as starting positions, selecting their actual covering cog cells. Then greedily place6brackets and12inserts over all certified mode/cell options with9x9 grids; rank exact original-plus-clearance area score, thenmode,Y,X. Preserve all17010trial scores. Allcogs andcompanions remain movable; source48 is not a complete seed. Compileall528movingpairs withhardstock/core bounds, independentlyreadback the model, and reconstructall66source originals. Everycall in the predecessor finite model and old3column model staysclosed. No optimizer or native call during this preparation.','grid_fractions':[i/8 for i in range(9)],'candidate_cap':25000,'preparation_internal_target_seconds':22,'preparation_process_cap_seconds':25,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
lib,groups=canonical_library(source);classes=family_classes(lib);assert classes['bracket']==list(range(19)) and len(set(classes['insert']))==4 and classes['cog']==[0,1];write(OUT/'library.json',lib);write(OUT/'compound-domain-groups.json',groups);write(OUT/'compound-classes.json',classes);values=np.zeros(81);modes=[0]*33;placed=[]
for seed in lib['source_moving_seed']:
    if seed['identity'][0]!='cog':continue
    i=seed['owner'];values[2*i:2*i+2]=seed['center'];values[66+i-18]=seed['angle_radians']*lib['angle_scale_mm'];available=[mode['mode'] for mode in lib['family_modes']['cog'] if all(mode['center_bounds_mm'][k][0]<=seed['center'][k]<=mode['center_bounds_mm'][k][1] for k in [0,1])];assert available;modes[i]=min(available);placed.append(owner_shapes(lib,'cog',modes[i],seed['center'],seed['angle_radians']))
assert len(placed)==15;candidates={}
for family in ['bracket','insert']:
    candidates[family]=[]
    for mode in lib['family_modes'][family]:
        bb=mode['center_bounds_mm'];points={(bb[0][0]+xi/8*(bb[0][1]-bb[0][0]),bb[1][0]+yi/8*(bb[1][1]-bb[1][0])) for xi,yi in product(range(9),repeat=2)}
        for seed in lib['source_moving_seed']:
            point=seed['center']
            if seed['identity'][0]==family and all(bb[k][0]<=point[k]<=bb[k][1] for k in [0,1]):points.add(tuple(point))
        candidates[family].append({'mode':mode['mode'],'centers':[list(p) for p in sorted(points,key=lambda p:(p[1],p[0]))]})
write(OUT/'compound-candidates.json',candidates);records=[];count=0
for i in range(18):
    family=lib['identities'][i][0];trials=[]
    for option in candidates[family]:
        for point in option['centers']:
            value=pair_energy(owner_shapes(lib,family,option['mode'],point),placed);trials.append({'mode':option['mode'],'center':point,'score_mm2':value});count+=1
    selected=min(trials,key=lambda t:(t['score_mm2'],t['mode'],t['center'][1],t['center'][0]));modes[i]=selected['mode'];values[2*i:2*i+2]=selected['center'];placed.append(owner_shapes(lib,family,modes[i],selected['center']));records.append({'owner':i,'identity':lib['identities'][i],'candidates':trials,'selected':selected});assert count<=25000 and time.perf_counter()-start<22
write(OUT/'initializer-trials.json',records);model=compile_model(lib,modes,values);assert verify(model,lib,modes,values);write(OUT/'initial-mode-values.json',{'modes':modes,'values':values.tolist(),'physical_key':list(physical_key(lib,classes,modes))});write(OUT/'model.json',model);rows=source_rows(model,values);check=audit(load(JOB),rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],list(map(tuple,lib['all66_identities'])));assert check['stock_failures']==0;write(OUT/'seed-source66.json',rows);write(OUT/'seed-source-checks.json',check);value,g,details=Objective(model).evaluate(values,True);write(OUT/'initial-objective.json',{'energy_mm2':value,'gradient':g.tolist(),**details});assert time.perf_counter()-start<22;checks={'passed':True,'seconds':time.perf_counter()-start,'candidate_trials':count,'candidate_centers_by_family':{f:sum(len(v['centers']) for v in a) for f,a in candidates.items()},'source_owner_compound_options':sum(len(lib['family_modes'][f]) for f,_ in lib['identities']),'physical_owner_compound_options':sum(len(set(classes[f])) for f,_ in lib['identities']),'moving_originals':33,'continuous_angles':15,'parameters':81,'moving_pairs':528,'initial_objective_mm2':value,'initial_original_overlap_mm2':details['original_overlap_area_mm2'],'source_pair_failures':check['pair_failures'],'source_stock_failures':check['stock_failures'],'source_valid66':check['valid'],'complete_prior_preparation_seconds':charge,'library_sha256':digest(OUT/'library.json'),'model_sha256':digest(OUT/'model.json'),'optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
