from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
common=[
 ('h5-hard-cell-direct-model-20261107','h5-mixed-roof-continuous-model-20261107'),
 ('h5-three-column-hard-cells-v2-20261107','h5-mixed-roof-hard-cells-20261107'),
 ('h5_hard_cell_direct_model_20261107','h5_hard_cell_vector_model_20261107'),
 ("lib['identities'][:18]","lib['identities']"),
 ('h5-hard-cell-initializer-process-20261107/prepare.json','h5-mixed-roof-initializer-process-20261107/process.json'),
 ("BASE/'audit/","BASE/'audit-v2/"),
 ("'audit/plan.json','audit/checks.json','audit/optimizer-controls.json','audit/tool-provenance.json','audit/physical-mode-controls.json'","'audit-v2/plan.json','audit-v2/checks.json','audit-v2/optimizer-controls.json','audit-v2/tool-provenance.json','audit-v2/physical-mode-controls.json'")
]
def convert(old,new,extra):
    s=(ROOT/'output'/old).read_text()
    for before,after in common+extra:
        assert before in s,(old,before);s=s.replace(before,after)
    with (ROOT/'output'/new).open('x',encoding='utf-8',newline='\n') as f:f.write(s)

convert('run_h5_hard_cell_direct_search_20261107.py','run_h5_mixed_roof_continuous_search_20261107.py',[
 ("'optimizer_slice_seconds':[16,12,12]","'optimizer_slice_seconds':[13,13,13]"),
 ('foratmost16s','for at most 13 seconds'),('12seach','13 seconds each'),
 ('One finite new33-mover/81parameter/all15continuousangle pipeline.',
  'One finite mixed-frame-roof 33-mover/81-parameter/all15continuous-angle pipeline. The two cog cells are distinct legal choices and all33owners participate in neighbor enumeration, giving159 distinct physical single-owner neighbors and207 raw alternatives before closed-vector exclusion. Vectorized gradients retain the checked symmetric convention at coincident edges. Both the original large-step derivative failure and smaller-step convergence evidence are preserved. The fresh source-only initializer is consumed once; the finite-contact model and three-column calls remain closed.'),
 ("'h5_hard_cell_vector_model_20261107.py','h5_hard_cell_direct_readback_20261107.py'","'h5_hard_cell_vector_model_20261107.py','h5_vector_boundary_gradient_20261107.py','h5_hard_cell_direct_readback_20261107.py'")
])
convert('audit_h5_hard_cell_direct_response_20261107.py','audit_h5_mixed_roof_continuous_response_20261107.py',[
 ('len(evaluated)+len(skipped)==114','len(evaluated)+len(skipped)==207'),
 ("ROOT/'output/h5_hard_cell_vector_model_20261107.py',ROOT/'output/h5_hard_cell_direct_readback_20261107.py'","ROOT/'output/h5_hard_cell_vector_model_20261107.py',ROOT/'output/h5_vector_boundary_gradient_20261107.py',ROOT/'output/h5_hard_cell_direct_readback_20261107.py'")
])
wrapper=(ROOT/'output/run_h5_mixed_roof_initializer_20261107.py').read_text()
wrapper=wrapper.replace('h5-mixed-roof-initializer-process-20261107','h5-mixed-roof-continuous-response-audit-process-20261107')
wrapper=wrapper.replace("('prepare','prepare_h5_mixed_roof_initializer_20261107.py',25)","('audit','audit_h5_mixed_roof_continuous_response_20261107.py',180)")
with (ROOT/'output/run_h5_mixed_roof_continuous_response_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(wrapper)
