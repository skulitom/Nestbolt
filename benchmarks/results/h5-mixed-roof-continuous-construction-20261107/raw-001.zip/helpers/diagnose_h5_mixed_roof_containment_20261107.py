"""Read-only pair-gradient diagnostic; no optimization or candidate selection."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
from h5_hard_cell_vector_model_20261107 import Objective
from h5_vector_boundary_gradient_20261107 import boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-roof-continuous-model-20261107';OUT=BASE/'containment-diagnostic'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter()
cases=[('initializer',BASE/'model.json',BASE/'initial-mode-values.json','values')]+[(f'round-{i:02d}',BASE/f'search/round-{i:02d}/model.json',BASE/f'search/round-{i:02d}/response.json','best_values') for i in range(3)]
inputs=[Path(__file__),ROOT/'output/h5_hard_cell_vector_model_20261107.py',ROOT/'output/h5_vector_boundary_gradient_20261107.py']+[p for _,m,r,_ in cases for p in [m,r]]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Replay the frozen initializer and each of three closed responses. Inspect every ordered moving pair for strict source original and clearance containment. A pair is a translation plateau only if both outlines are contained with positive boundary distance and the independently clipped boundary translation gradients are negligible. This is diagnostic only: no candidate change, scoring exception, source-validity claim, solver or native call.','cases':4,'unordered_pairs_per_case':528,'optimizer_calls':0})
summaries=[];records=[]
for name,mp,rp,key in cases:
    model=load(mp);point=load(rp)[key];objective=Objective(model);levels=objective.geometry(point);found=[]
    for i,j in model['pairs']:
        for own,other in [(i,j),(j,i)]:
            controls=[]
            for kind,entries in zip(['original','clearance'],levels):
                vertices,poly,lines,pivot=entries[own];op=entries[other][1]
                if not op.contains(poly):break
                gap=poly.boundary.distance(op.boundary)
                if gap<=1e-8:break
                g,n,shared=boundary_gradient(vertices,lines,op,pivot)
                assert np.max(np.abs(g[:2]))<1e-7 and abs(poly.intersection(op).area-poly.area)<1e-7
                controls.append({'kind':kind,'contained_area_mm2':poly.area,'minimum_escape_boundary_distance_mm':gap,'translation_gradient':g[:2].tolist(),'angular_gradient':float(g[2]),'clipped_segments':n,'coincident_length_mm':shared})
            if len(controls)==2:found.append({'contained_owner':own,'containing_owner':other,'contained_identity':model['owners'][own]['identity'],'containing_identity':model['owners'][other]['identity'],'controls':controls})
    records.append({'case':name,'strict_containment_translation_plateaus':found});summaries.append({'case':name,'plateau_pairs':len(found),'contained_owners':len({r['contained_owner'] for r in found}),'contained_original_area_mm2':sum(r['controls'][0]['contained_area_mm2'] for r in found)})
write(OUT/'records.json',records);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'cases':summaries,'ordered_pairs_checked':4*528*2,'source_geometry_kinds':2,'optimizer_calls':0,'closed_calls_resumed':False,'H5_complete':False});print(load(OUT/'checks.json'))
