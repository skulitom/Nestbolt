"""Archive independently checked mixed-roof hard domains and closed search."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8')
prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-mixed-roof-continuous-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-mixed-roof-continuous-model-20261107';F=BASE/'response-audit';D=ROOT/'output/h5-mixed-roof-hard-cells-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-mixed-roof-contact-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==50 and not front['source_valid66']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D]+[ROOT/'output'/n for n in ['h5-mixed-roof-hard-cells-preparation-process-20261107','h5-mixed-roof-hard-cells-audit-process-20261107','h5-mixed-roof-initializer-process-20261107','h5-mixed-roof-continuous-model-audit-process-20261107','h5-mixed-roof-continuous-model-audit-v2-process-20261107','h5-mixed-roof-continuous-response-audit-process-20261107']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*mixed*roof*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_mixed_roof_continuous_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"
}
for old,new in changes.items():
    assert old in prefix,old
    prefix=prefix.replace(old,new)
exec(prefix)
runtime={name:r['sha256'] for name,r in load(BASE/'audit-v2/tool-provenance.json')['tool_files'].items()}
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(D/'audit/checks.json','source-domain-audit.json'),(BASE/'audit-v2/checks.json','model-audit.json'),(BASE/'audit-v2/physical-mode-controls.json','physical-mode-controls.json'),(BASE/'audit-v2/derivative-controls.json','derivative-controls.json'),(BASE/'derivative-diagnostic/checks.json','derivative-diagnostic.json'),(BASE/'audit-v2/negative-controls.json','negative-controls.json'),(F/'checks.json','response-audit.json'),(F/'mode-selection-controls.json','mode-selection-controls.json'),(F/'round-reconciliation.json','round-reconciliation.json'),(F/'round-02-collision-details.json','source-failures.json'),(BASE/'search/process.json','closed-process.json'),(BASE/'containment-diagnostic/checks.json','containment-diagnostic.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'separately_pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'expanded_neighborhood_preflight_required','proposal':'Assess joint bracket/insert and bracket/cog compound-cell changes under the changed mixed-frame geometry, preserving both cog cells and each continuous cog angle.','scope':'The closed construction tested only single-owner cell changes. An expanded source-only neighborhood would contain159 physical singles,3888 bracket/insert pairs and1620 bracket/cog pairs before exclusions. This is a preflight proposal, not authorization to reopen or repeat a closed vector.','requirements':['Independently verify all5667 proposed neighbors and their exact changed-pair score corrections, including each cog current angle; the old1374-neighbor helper is incompatible.','Exclude all three physical vectors already called here and preserve every failed outcome. Start from the existing unoptimized source initializer with its full12.254436-second charge plus all new preparation; no optimized ancestor clock reset.','Assess source contact translations if nearest-bound clamping cannot represent useful joint changes, with complete source validation and preparation accounting before declaring a new search.','Freeze a finite execution contract only after source, complete model, selector and timing checks pass. No extension, retry, silent reseed, or allocation exclusion from local failure.'],'new_selector_prepared':False,'new_optimizer_calls':0,'H5_complete':False})
report=f'''# Mixed frame roof: continuous construction — 2026-11-07

The complete continuous model closes after three distinct calls. Its best
candidate remains invalid: **50 original pairs fail**, comprising 46 positive
area intersections and four clearance failures. Total original overlap is
**45,898.003784 mm²**. Every fixed-part and stock check passes. This is a local
search result, with no continuous-layout or allocation exclusion. H2/H5 remain
open at **60% completed milestone weight**.

## Source-safe movement regions

The construction retains sixteen turned base frames, two unturned roof frames
and the six-bracket/nine-insert short sheet from the preceding source audit.
It frees six brackets, twelve inserts and all fifteen cog centers and angles:
33 moving originals, 81 continuous parameters and all 528 moving pairs.

[Independent domain readback]({NAME}/source-domain-audit.json) verifies two
outward-rounded boxes containing the actual fixed frame outlines, thirteen
mode arrangements, 184 atomic cells, 96 exact whole-cell support proofs and
1,200 original-source corner controls. Minimum certified axis clearance is
0.230001 mm. A 0.000001 mm inset is one **nanometre**. Source cog seed projections
are at most 1.414214 nm; the 48-part source control remains valid and incomplete.

There are 19 bracket, eight insert and **two distinct cog compound cells**.
Canonical aliases require both the same nominal filled outline and an identical
effective rectangle; a common conservative subset removes only near-identical
rounding differences. [Physical-equivalence controls]({NAME}/physical-mode-controls.json)
check all 429 within-family pairs, preserving both cog domains. There are 240
source owner options, 192 physical options and 159 distinct single-owner neighbors.
The rectangles conservatively restrict source free space; they are not a complete
cover of every legal original placement.

## One initializer and complete model verification

The source-derived cog positions initialize one greedy placement of the eighteen
companions. [The model audit]({NAME}/model-audit.json) replays all **17,010 trial
scores and choices**, 240 owner/mode bindings and full scores, and 208 mode vectors.
The initializer has 38 colliding pairs and 94,033.918707 mm² original overlap;
it is not a valid full layout. No failed optimized ancestor initializes this run.
Complete consumed preparation is **12.254436 s**, including the entire closed
initializer wrapper process. Validation-only audits do not enter the search clock.

The first derivative audit is preserved as failed. A four-step diagnostic finds
six coordinates exceeding the original tolerance at a 1e-4 finite-difference step.
The same tolerance passes all 162 coordinates at **both 1e-5 and 1e-6**, giving
324 independently summed central samples; maximum absolute errors are
0.003687262 and 0.005666829 respectively. The 1e-7 measurements show increased
roundoff. [All diagnostic measurements]({NAME}/derivative-diagnostic.json) and
[the corrected controls]({NAME}/derivative-controls.json) remain available.
The geometry, analytic gradient, initializer and optimizer settings are unchanged.
Checks also include 152 scalar boundary-gradient comparisons, three descent steps
and [eleven deliberate model corruptions]({NAME}/negative-controls.json).

## Closed execution and original-part replay

The frozen pipeline permits three calls with at most thirteen seconds each,
within preparation-inclusive 60/90-second algorithm/shared limits. Each call uses
a previously uncalled physical vector. All 33 owners, including every cog cell
transition, participate in subsequent neighbor enumeration. The two selected
changes affect insert owner16 and bracket owner1; no cog-cell change is selected.

[Independent response replay]({NAME}/response-audit.json) verifies **317 scored
neighbors, 315 retained points and 444 evaluation counters**, including each
gradient, bound, model and selection. Every candidate reconstructs all 66 originals:
1,380 same-sheet pairs, 264 stock edges, 90 holes and 10,026 hole vertices.
The successive candidates fail 52, 51 and 50 pairs; the third is best by the
declared objective. [The original failures]({NAME}/source-failures.json) are retained.

The last call closes at the algorithm's source-check stop. Algorithm/shared totals
are **56.105047/56.173290 s**, including preparation. Slice overruns of
0.023989, 0.053605 and 0.083377 seconds are preserved within the overall limits.
[All five search processes close]({NAME}/closed-process.json), with peak aggregate
committed memory 94,511,104 bytes. No native validator call is made, since there is
no source-valid full66 candidate. The calls cannot resume or receive a reset clock.

A separate [strict-containment diagnostic]({NAME}/containment-diagnostic.json)
checks 4,224 ordered pairs across the initializer and three responses. It finds
no part strictly contained in another for both original and clearance outlines;
that particular translation-plateau explanation is unsupported here.

## Next work and repository state

[The proposed expanded neighborhood]({NAME}/next-step.json) includes joint
bracket/insert and bracket/cog cell changes, retaining actual cog angles. Its
source bindings, scores, exclusions and complete timing require independent
preflight before any call. No new selector or successor call is prepared.
All four earlier fixed arrangements and 440 whole allocations remain unresolved.
Full66 source/native/material checks, production parity and the unchanged H5
matrix remain required. H2 retains its original gate and reserved vectors.

[Main CI at review]({NAME}/main-ci-at-review.json) has five passed jobs and a live
Windows native job on main6b81bf9d. The preceding dcfd2a26 checkpoint and this
checkpoint await the normal push gate. Production, README and releases are unchanged.
No release qualifies. [Raw evidence]({NAME}/raw-manifest.json) and
[source bindings]({NAME}/source-bindings.json) retain exact predecessor references;
six installed runtime files are [separately pinned]({NAME}/runtime-bindings.json).
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 mixed-roof continuous construction:** [independent source/model/response audits]({link}) verify 184 atomic cells, 96 exact support proofs, 1,200 source corner controls and both distinct cog domains. One initializer replays 17,010 trials; the model checks 240 owner options, 208 vectors and 429 equivalence pairs. The original large-step derivative failure is preserved; all 162 coordinates pass the same tolerance at both smaller steps, without changing the gradient or initializer. Three unique calls and 317 single-owner trials close at the source-check stop; 315 retained points and 444 evaluations replay. The final candidate still fails 50 pairs, with 45,898.003784 mm² overlap; every fixed-part and stock check passes. Complete preparation is 12.254436 s and algorithm/shared totals are 56.105047/56.173290 s. All slice overruns are retained and all processes close. A separate containment diagnostic finds no strict-containment plateau across the four saved cases. No native call or allocation exclusion follows. Next assess joint bracket/insert and bracket/cog cell changes with all three closed vectors excluded, complete source accounting and independent score preflight; no successor selector or call is prepared. Four earlier fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%. Main6b81bf9d has five passed CI jobs and a live Windows native job; dcfd2a26 and this checkpoint await the ordinary push gate. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md'
    append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [mixed-roof continuous construction](../benchmarks/results/{NAME}.md).
Source-safe hard cells protect all fixed frames and stock while freeing 33 part
centers and all fifteen cog angles. Independent audits replay 17,010 initializer
trials, 240 owner options and both distinct cog domains. A preserved derivative
check failure resolves at two smaller finite-difference steps with the same
tolerance; the analytic gradient and initializer remain unchanged.
Three unique calls and 317 single-owner trials close with 50 failing source
pairs and 45,898.003784 mm² overlap. Every fixed-part and stock check passes.
All 315 retained points and 444 evaluations replay. Algorithm/shared totals are
56.105047/56.173290 s including 12.254436 s preparation; all processes close and
all slice overruns are preserved. No full66 witness or allocation exclusion follows.
Next assess joint bracket/insert and bracket/cog cell changes, excluding all
closed vectors and auditing complete source scores and preparation first.
No successor selector or call is prepared. Four earlier fixed arrangements and
440 allocations remain; H2/H5 stay open at 60% completed milestone weight.
Main6b81bf9d has five passed jobs and a live Windows native check. Checkpoint
dcfd2a26 and this checkpoint await the ordinary push gate. Full66 source/native/
material checks, production parity and the unchanged H5 matrix remain required.
No release qualifies.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n')
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
