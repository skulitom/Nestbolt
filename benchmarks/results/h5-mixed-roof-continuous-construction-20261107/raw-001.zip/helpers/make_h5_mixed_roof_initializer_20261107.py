from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];s=(ROOT/'output/prepare_h5_hard_cell_initializer_20261107.py').read_text(encoding='utf-8')
s=s.replace("SOURCE=ROOT/'output/h5-three-column-hard-cells-v2-20261107';OUT=ROOT/'output/h5-hard-cell-direct-model-20261107'","SOURCE=ROOT/'output/h5-mixed-roof-hard-cells-20261107';OUT=ROOT/'output/h5-mixed-roof-continuous-model-20261107'")
s=s.replace('from h5_hard_cell_direct_model_20261107 import compile_model,Objective,owner_shapes,pair_energy,source_rows','from h5_hard_cell_vector_model_20261107 import compile_model,Objective,owner_shapes,pair_energy,source_rows')
s=s.replace("'h5_hard_cell_direct_model_20261107.py'","'h5_hard_cell_direct_model_20261107.py','h5_hard_cell_vector_model_20261107.py','h5_vector_boundary_gradient_20261107.py'")
s=s.replace(",'audit/unit-label-correction.json'",'')
old="assert classes['bracket']==list(range(10)) and classes['insert']==[0,1,2,0,1,2] and classes['cog']==[0]"
new="assert classes['bracket']==list(range(19)) and len(set(classes['insert']))==4 and classes['cog']==[0,1]"
assert old in s;s=s.replace(old,new)
old="i=seed['owner'];values[2*i:2*i+2]=seed['center'];values[66+i-18]=seed['angle_radians']*lib['angle_scale_mm'];placed.append(owner_shapes(lib,'cog',0,seed['center'],seed['angle_radians']))"
new="i=seed['owner'];values[2*i:2*i+2]=seed['center'];values[66+i-18]=seed['angle_radians']*lib['angle_scale_mm'];available=[mode['mode'] for mode in lib['family_modes']['cog'] if all(mode['center_bounds_mm'][k][0]<=seed['center'][k]<=mode['center_bounds_mm'][k][1] for k in [0,1])];assert available;modes[i]=min(available);placed.append(owner_shapes(lib,'cog',modes[i],seed['center'],seed['angle_radians']))"
assert old in s;s=s.replace(old,new)
s=s.replace("'source_owner_compound_options':147,'physical_owner_compound_options':111","'source_owner_compound_options':sum(len(lib['family_modes'][f]) for f,_ in lib['identities']),'physical_owner_compound_options':sum(len(set(classes[f])) for f,_ in lib['identities'])")
a=s.index("'method':'One source-only initializer");b=s.index(",'grid_fractions'",a)
method='One source-only initializer for the changed mixed-frame-roof geometry,33movers,81parameters and15continuously rotating cogs. No finite-pool search output, optimized ancestor or old initializer point consumed. Use exact nominal outline keys plus identical effective hard rectangles; explicitly intersect near-identical alias bounds, preserving different cog and companion cells. Retain source15cog centers/angles only as starting positions, selecting their actual covering cog cells. Then greedily place6brackets and12inserts over all certified mode/cell options with9x9 grids; rank exact original-plus-clearance area score, thenmode,Y,X. Preserve all17010trial scores. Allcogs andcompanions remain movable; source48 is not a complete seed. Compileall528movingpairs withhardstock/core bounds, independentlyreadback the model, and reconstructall66source originals. Everycall in the predecessor finite model and old3column model staysclosed. No optimizer or native call during this preparation.'
s=s[:a]+"'method':"+repr(method)+s[b:]
compile(s,'prepare_h5_mixed_roof_initializer_20261107.py','exec')
with (ROOT/'output/prepare_h5_mixed_roof_initializer_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/run_h5_hard_cell_model_audit_20261107.py').read_text(encoding='utf-8').replace('h5-hard-cell-model-audit-process-20261107','h5-mixed-roof-initializer-process-20261107').replace("('audit','audit_h5_hard_cell_direct_model_20261107.py',90)","('prepare','prepare_h5_mixed_roof_initializer_20261107.py',25)")
with (ROOT/'output/run_h5_mixed_roof_initializer_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
