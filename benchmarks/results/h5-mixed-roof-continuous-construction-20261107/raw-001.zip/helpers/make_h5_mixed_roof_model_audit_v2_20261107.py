from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'output/audit_h5_mixed_roof_continuous_model_20261107.py'
s=p.read_text()
s=s.replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'")
old="""    for k in range(81):
        plus=point.copy();minus=point.copy();plus[k]+=1e-4;minus[k]-=1e-4;numeric=(full_energy(mm,plus)-full_energy(mm,minus))/2e-4;error=abs(numeric-gg[k]);assert error<.02+3e-6*abs(gg[k]),(variation,k,numeric,gg[k],error);errors.append(float(error))
    derivatives.append({'variation':variation,'coordinates':81,'maximum_absolute_error':max(errors)})"""
new="""    diagnostic=load(BASE/'derivative-diagnostic/records.json')
    for k in range(81):
        reference=diagnostic[variation*81+k];assert reference['variation']==variation and reference['coordinate']==k and reference['analytic']==gg[k]
        for step,sample_index in [(1e-5,1),(1e-6,2)]:
            plus=point.copy();minus=point.copy();plus[k]+=step;minus[k]-=step;numeric=(full_energy(mm,plus)-full_energy(mm,minus))/(2*step);error=abs(numeric-gg[k]);assert numeric==reference['samples'][sample_index]['numeric'] and error<.02+3e-6*abs(gg[k]),(variation,k,step,numeric,gg[k],error);errors.append(float(error))
    derivatives.append({'variation':variation,'coordinates':81,'steps':[1e-5,1e-6],'samples':162,'maximum_absolute_error':max(errors)})"""
assert old in s;s=s.replace(old,new)
s=s.replace("'seed-descent-controls.json',directions)","'seed-descent-controls.json',directions)")
s=s.replace("'independent_central_coordinates':162", "'independent_central_coordinates':162,'independent_central_samples':324,'original_large_step_failure_preserved':True")
s=s.replace("'seed-source66.json','seed-source-checks.json']", "'seed-source66.json','seed-source-checks.json','derivative-diagnostic/records.json','derivative-diagnostic/checks.json','audit/audit.py']")
s=s.replace("inputs=[Path(__file__),JOB,", "inputs=[Path(__file__),JOB,ROOT/'output/diagnose_h5_mixed_roof_derivatives_20261107.py',ROOT/'output/h5-mixed-roof-continuous-model-audit-process-20261107/process.json',ROOT/'output/h5-mixed-roof-continuous-model-audit-process-20261107/audit-stderr.txt',")
s=s.replace('162centralderivatives', '162 coordinates at two smaller finite-difference steps (324 samples), retaining all four diagnostic step sizes and the original large-step failure')
with (ROOT/'output/audit_h5_mixed_roof_continuous_model_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
w=(ROOT/'output/run_h5_mixed_roof_continuous_model_audit_20261107.py').read_text()
w=w.replace('h5-mixed-roof-continuous-model-audit-process-20261107','h5-mixed-roof-continuous-model-audit-v2-process-20261107').replace('audit_h5_mixed_roof_continuous_model_20261107.py','audit_h5_mixed_roof_continuous_model_v2_20261107.py')
with (ROOT/'output/run_h5_mixed_roof_continuous_model_audit_v2_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(w)
