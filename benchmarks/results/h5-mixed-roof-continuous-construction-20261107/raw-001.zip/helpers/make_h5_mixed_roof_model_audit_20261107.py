from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'audit_h5_hard_cell_direct_model_20261107.py').read_text()

def replace(old, new):
    global source
    assert old in source, old
    source = source.replace(old, new)

replace('from h5_hard_cell_direct_model_20261107 import compile_model,Objective',
        'from h5_hard_cell_vector_model_20261107 import compile_model,Objective')
replace('h5-three-column-hard-cells-v2-20261107', 'h5-mixed-roof-hard-cells-20261107')
replace('h5-hard-cell-direct-model-20261107', 'h5-mixed-roof-continuous-model-20261107')
replace("{'bracket':list(range(10)),'insert':[0,1,2,0,1,2],'cog':[0]}",
        "{'bracket':list(range(19)),'insert':[0,1,2,3,0,1,2,3],'cog':[0,1]}")
replace("i=seed['owner'];assert modes[i]==0 and values[2*i:2*i+2].tolist()==seed['center'] and values[66+i-18]==radius*seed['angle_radians'];placed.append(independent_shapes('cog',0,seed['center'],seed['angle_radians']))",
        "i=seed['owner'];covering=[o['mode'] for o in lib['family_modes']['cog'] if all(o['center_bounds_mm'][k][0]<=seed['center'][k]<=o['center_bounds_mm'][k][1] for k in [0,1])];assert modes[i]==min(covering) and values[2*i:2*i+2].tolist()==seed['center'] and values[66+i-18]==radius*seed['angle_radians'];placed.append(independent_shapes('cog',modes[i],seed['center'],seed['angle_radians']))")
replace('trials==10932', 'trials==17010')
replace('bindings==147 and vectors==115', 'bindings==240 and vectors==208')
replace("chosen[:18]=[(m+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,m in enumerate(chosen[:18])]",
        "chosen=[(m+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,m in enumerate(chosen)]")
replace("len(equivalence_controls)==137 and classes['bracket'][2]!=classes['bracket'][3] and classes['insert'][1]!=classes['insert'][2] and classes['insert'][0]==classes['insert'][3]",
        "len(equivalence_controls)==429 and classes['bracket'][2]!=classes['bracket'][3] and classes['insert'][1]!=classes['insert'][2] and classes['insert'][0]==classes['insert'][4] and classes['cog'][0]!=classes['cog'][1]")
replace("enumerate(lib['identities'][:18])", "enumerate(lib['identities'])")
replace('len(keys)==78 and equivalent==12 and raw==114', 'len(keys)==159 and equivalent==12 and raw==207')
replace("'compound_equivalence_pair_controls':137,'source_owner_options':147,'physical_owner_options':111,'unique_single_owner_physical_neighbors':78,'raw_current_equivalents':12,'raw_alternatives':114",
        "'compound_equivalence_pair_controls':429,'source_owner_options':240,'physical_owner_options':192,'unique_single_owner_physical_neighbors':159,'raw_current_equivalents':12,'raw_alternatives':207")
replace('h5-hard-cell-initializer-process-20261107/prepare.json', 'h5-mixed-roof-initializer-process-20261107/process.json')
replace("prep['passed'] and prep['job']['closed']", "prep['passed'] and prep['closed'] and all(s['job']['closed'] and s['job']['active_processes']==0 for s in prep['stages'])")
replace("'h5_hard_cell_direct_model_20261107.py','h5_hard_cell_direct_readback_20261107.py'", "'h5_hard_cell_vector_model_20261107.py','h5_vector_boundary_gradient_20261107.py','h5_hard_cell_direct_readback_20261107.py'")
replace("'audit/checks.json','audit/unit-label-correction.json'", "'audit/checks.json','audit/plan.json'")
replace('All10932trial scores/choices,147ownercompoundbindings/fullscores,115vectors', 'All17010trial scores/choices,240ownercompoundbindings/fullscores,208vectors')
replace('137compoundequivalencecontrols', '429compoundequivalencecontrols')
replace("'compound_equivalence_controls':137", "'compound_equivalence_controls':429")
replace('PriorDsourceaudit verifiesentireharddomains', 'Prior source audit verifies entire hard domains including both cog cells; initializer charge includes the entire closed wrapper process')
destination = root / 'audit_h5_mixed_roof_continuous_model_20261107.py'
with destination.open('x', encoding='utf-8', newline='\n') as f:
    f.write(source)

wrapper = (root / 'run_h5_mixed_roof_initializer_20261107.py').read_text()
wrapper = wrapper.replace('h5-mixed-roof-initializer-process-20261107', 'h5-mixed-roof-continuous-model-audit-process-20261107')
wrapper = wrapper.replace("('prepare','prepare_h5_mixed_roof_initializer_20261107.py',25)", "('audit','audit_h5_mixed_roof_continuous_model_20261107.py',120)")
with (root / 'run_h5_mixed_roof_continuous_model_audit_20261107.py').open('x', encoding='utf-8', newline='\n') as f:
    f.write(wrapper)
