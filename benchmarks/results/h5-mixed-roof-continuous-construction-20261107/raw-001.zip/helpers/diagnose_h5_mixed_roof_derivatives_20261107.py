from pathlib import Path
from hashlib import sha256
import ast,json,math,time
import numpy as np
from shapely.geometry import Polygon
from h5_hard_cell_vector_model_20261107 import compile_model,Objective
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-mixed-roof-continuous-model-20261107'
OUT=BASE/'derivative-diagnostic'
load=lambda p:json.loads(p.read_bytes())
OUT.mkdir();start=time.perf_counter()
lib=load(BASE/'library.json');radius=lib['angle_scale_mm'];saved=load(BASE/'initial-mode-values.json');modes=saved['modes'];values=np.asarray(saved['values'])
source=ROOT/'output/audit_h5_mixed_roof_continuous_model_20261107.py'
tree=ast.parse(source.read_text())
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['independent_shapes','full_energy']]
assert len(functions)==2
exec(compile(ast.Module(body=functions,type_ignores=[]),str(source),'exec'))
records=[]
for variation in [0,1]:
    chosen=modes.copy()
    if variation:chosen=[(m+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,m in enumerate(chosen)]
    model=compile_model(lib,chosen,values);bounds=np.asarray(model['bounds']);margin=.03+np.arange(81)*.00037
    point=np.clip(np.asarray(model['initial'])+.137*np.sin(np.arange(81)*2**.5+.2+variation),bounds[:,0]+margin,bounds[:,1]-margin)
    val,gradient=Objective(model).evaluate(point)
    for k in range(81):
        samples=[]
        for step in [1e-4,1e-5,1e-6,1e-7]:
            plus=point.copy();minus=point.copy();plus[k]+=step;minus[k]-=step
            numeric=(full_energy(model,plus)-full_energy(model,minus))/(2*step)
            samples.append({'step':step,'numeric':numeric,'absolute_error':abs(numeric-gradient[k])})
        records.append({'variation':variation,'coordinate':k,'analytic':float(gradient[k]),'samples':samples})
with (OUT/'records.json').open('x') as f:json.dump(records,f,indent=2)
checks={'seconds':time.perf_counter()-start,'original_failure_preserved':True,'maximum_errors_by_step':{str(s['step']):max(r['samples'][i]['absolute_error'] for r in records) for i,s in enumerate(records[0]['samples'])},'failed_at_1e4':[r for r in records if r['samples'][0]['absolute_error']>=.02+3e-6*abs(r['analytic'])],'optimizer_calls':0,'source_audit_sha256':sha256(source.read_bytes()).hexdigest()}
with (OUT/'checks.json').open('x') as f:json.dump(checks,f,indent=2)
print(checks)
