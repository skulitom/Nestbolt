from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];NAME='h5-mixed-roof-contact-construction-20261107'
entry='**2026-11-07 H5 mixed frame roof and finite contacts:** [independent source/contact/graph/model/response audits]({link}) verify sixteen turned base frames, two unturned top frames and seventeen compatible cog sites. A valid 48-part control uses exactly fifteen cogs; six brackets and twelve inserts remain missing. All 136 cog-site pairs and 306 site/frame pairs pass, with minimum gaps of 0.301547629 and 0.268862770 mm. All 4,445 contacts and 155,575 fixed-pair checks replay; the frozen cap keeps 1,024 candidates per companion family. Every one of 2,096,128 candidate pairs is checked, reproducing 231,343 edges and 3,167 pose/cog conflicts. The model has 2,065 variables and 234,513 constraints and requires exact original quantities. Its single call returns finite-pool INFEASIBLE in 2.227445 s, without an assignment or incumbent; no continuous layout or allocation is excluded. Complete preparation is 11.631014 s and algorithm/shared totals are 14.700575/14.803571 s, with no overrun and all processes closed. Next assess source-certified hard cells for continuous cog centers and angles and all eighteen companions under the changed frame arrangement, including multiple cog-cell choices. No successor geometry or call is prepared. Four earlier fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%. Checkpoints be75186f and 6b81bf9d reached main after all six prior checks passed, preserving 52 remote files; fresh CI is running. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    p=ROOT/name;s=p.read_text(encoding='utf-8');lines=s.splitlines();matches=[i for i,line in enumerate(lines) if line.startswith('**2026-11-07 H5 mixed frame roof and finite contacts:**')];assert len(matches)==1
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';lines[matches[0]]=entry.format(link=link);s='\n'.join(lines)+'\n'
    if name=='docs/STATUS.md':
        a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
        intro=f'''Latest H5 evidence: [mixed frame roof and finite contacts](../benchmarks/results/{NAME}.md).
The changed frame arrangement leaves seventeen compatible cog sites. A valid
48-part control uses exactly fifteen cogs, with six brackets and twelve inserts
still missing. Independent audits verify all 4,445 contacts, 2,096,128 candidate
pairs and every field of the exact-inventory model. Its single declared call
returns finite-pool INFEASIBLE in 2.227445 s, without an assignment or incumbent.
Algorithm/shared totals including preparation are 14.700575/14.803571 s;
all processes close without an overrun. No continuous layout or allocation is
excluded. Next assess source-safe cells for continuous cog centers and angles
and all eighteen companions under the changed frame arrangement, including
multiple cog-cell choices. No successor geometry or call is prepared.
Four earlier fixed arrangements and 440 allocations remain. H2/H5 stay open
at 60% completed milestone weight. Main 6b81bf9d includes the previous two
checkpoints after all six prior checks passed; fresh CI is running.
All 66 original-source, native and material checks, production parity and the
unchanged H5 matrix remain required. No release qualifies.
'''
        s=s[:a]+intro+s[b:]
    p.write_text(s,encoding='utf-8',newline='\n')
