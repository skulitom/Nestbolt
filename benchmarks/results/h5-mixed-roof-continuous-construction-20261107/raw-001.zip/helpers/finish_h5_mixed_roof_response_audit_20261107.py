from pathlib import Path
p=Path(__file__).resolve().parent/'audit_h5_mixed_roof_continuous_response_20261107.py'
s=p.read_text(encoding='utf-8')
old="result['status']=='MAXIMUM_CALLS' and calls==3 and not result['source_valid66']"
new="result['status'] in ['MAXIMUM_CALLS','ALGORITHM_TIME_STOP_AFTER_SOURCE_CHECK'] and calls==3 and not result['source_valid66'] and (result['status']=='MAXIMUM_CALLS' or result['rounds'][-1]['algorithm_seconds_including_preparation']>=56)"
assert old in s
p.write_text(s.replace(old,new),encoding='utf-8',newline='\n')
