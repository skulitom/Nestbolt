"""Independent exact conservative-cell coverage and complete source controls."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product,combinations
import json,math,time,copy,shutil
from h5_exact_convex_partition_tools_20261029 import area,hull
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-roof-hard-cells-20261107';SOURCE=ROOT/'output/h5-mixed-roof-source-20261107';Q=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();UNIT=10**6
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def rd(v):return F(math.floor(v*UNIT),UNIT)
def ru(v):return F(math.ceil(v*UNIT),UNIT)
def rect(values):return list(map(F,values))
def covered(a,b):return b[0]<=a[0] and b[1]<=a[1] and a[2]<=b[2] and a[3]<=b[3]
def separate(a,b):return a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
def rectangle_area(r):return (r[2]-r[0])*(r[3]-r[1])
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');lib=load(BASE/'library.json');source=load(SOURCE/'source-geometry.json');prior=load(SOURCE/'audit/checks.json');assert prior['passed'] and prior['source_geometry_sha256']==digest(SOURCE/'source-geometry.json');job=load(JOB);parts={p['id']:p for p in job['parts']};partitions=load(Q/'partitions.json');fixed=source['fixed_source_rows'];assert fixed==lib['fixed_source_rows']==load(BASE/'fixed33-source.json') and lib['families']==source['families'];stocks=source['source_stocks'];required=source['required_pair_gap_mm'];guard=source['stock_guard_mm'];check=audit(job,fixed,stocks,required,guard);assert check==load(BASE/'fixed33-checks.json') and check['valid'];safe=[F(str(stocks['sheet-0'][0]))+F('.025'),F(str(stocks['sheet-0'][1]))+F('.025'),F(str(stocks['sheet-0'][2]))-F('.025'),F(str(stocks['sheet-0'][3]))-F('.025')];epsilon=F(1,UNIT);gap=F('.23');cores=[];records=[]
for name,indices in [('base',range(16)),('roof',range(16,18))]:
    vv=[];actual=[]
    for i in indices:
        t=fixed[i]['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation'];assert not t['mirrored']
        for x,y in parts['frame']['geometry'][0]['outer']:vv.append((F(x)*F(c)-F(y)*F(s)+F(tx),F(x)*F(s)+F(y)*F(c)+F(ty)));actual.append((F(x*c-y*s+tx),F(x*s+y*c+ty)))
    core=[rd(min(x for x,y in vv)),rd(min(y for x,y in vv)),ru(max(x for x,y in vv)),ru(max(y for x,y in vv))];assert all(core[0]<=x<=core[2] and core[1]<=y<=core[3] for x,y in actual);cores.append(core);records.append({'group':name,'frame_indices':list(indices),'outer_rectangle':list(map(str,core)),'source_vertices':[[str(x),str(y)] for x,y in vv]})
assert records==load(BASE/'fixed-core-boxes.json') and lib['fixed_core_outer_rectangles_mm']==[list(map(float,c)) for c in cores] and lib['safe_source_stock_mm']==list(map(float,safe))
for family in ['bracket','insert']:
    original=[tuple(map(F,p)) for p in parts[family]['geometry'][0]['outer']];pieces=[[tuple(map(F,p)) for p in pp] for pp in partitions[family]['pieces']];assert parts[family]['geometry'][0]['outer']==lib['families'][family]['original'] and sum(abs(area(p)) for p in pieces)==abs(area(original));boxes=[[min(x for x,y in original),min(y for x,y in original),max(x for x,y in original),max(y for x,y in original)]]
    if family=='bracket':boxes=[[original[0][0],original[0][1],original[3][0],original[4][1]],[original[0][0],original[0][1],original[1][0],original[2][1]]]
    for piece in pieces:
        assert abs(area(hull(piece)))==abs(area(piece));bb=[min(x for x,y in piece),min(y for x,y in piece),max(x for x,y in piece),max(y for x,y in piece)];assert any(covered(bb,b) for b in boxes)
    for a,b in combinations(pieces,2):
        axes=[(q[1]-p[1],p[0]-q[0]) for pp in [a,b] for p,q in zip(pp,pp[1:]+pp[:1])];assert any(max(x*nx+y*ny for x,y in a)<=min(x*nx+y*ny for x,y in b) or max(x*nx+y*ny for x,y in b)<=min(x*nx+y*ny for x,y in a) for nx,ny in axes)
radius=lib['angle_scale_mm'];center=lib['families']['cog']['source_center'];assert F(radius)**2>max(sum((F(p[k])-F(center[k]))**2 for k in [0,1]) for p in parts['cog']['geometry'][0]['outer']);decompositions=load(BASE/'rectangle-decompositions.json');certificates=load(BASE/'cell-support-certificates.json');expected_modes={};atom_count=proof_count=0;min_gap=math.inf
for family in ['bracket','insert','cog']:
    expected_modes[family]=[];px,py=lib['families'][family]['source_center'];options=[(False,0.)] if family=='cog' else [(mir,math.radians(deg)) for mir in ([False,True] if parts[family]['allow_mirror'] else [False]) for deg in parts[family]['rotations']['degrees']]
    for source_mode,(mirror,angle) in enumerate(options):
        local=[];c,s=map(F,[math.cos(angle),math.sin(angle)]);sign=-1 if mirror else 1
        if family=='cog':local=[[-ru(F(radius)),-ru(F(radius)),ru(F(radius)),ru(F(radius))]]
        else:
            for piece in partitions[family]['pieces']:
                v=[(sign*(F(x)-F(px))*c-(F(y)-F(py))*s,sign*(F(x)-F(px))*s+(F(y)-F(py))*c) for x,y in piece];local.append([rd(min(x for x,y in v)),rd(min(y for x,y in v)),ru(max(x for x,y in v)),ru(max(y for x,y in v))])
        root=[safe[0]-min(r[0] for r in local)+epsilon,safe[1]-min(r[1] for r in local)+epsilon,safe[2]-max(r[2] for r in local)-epsilon,safe[3]-max(r[3] for r in local)-epsilon];blocked=[[core[0]-gap-r[2],core[1]-gap-r[3],core[2]+gap-r[0],core[3]+gap-r[1]] for core,r in product(cores,local)];record=next(r for r in decompositions if r['family']==family and r['source_mode']==source_mode);assert record['rotation_radians']==angle and record['mirrored']==mirror and list(map(rect,record['local_piece_outer_boxes']))==local and rect(record['stock_center_root'])==root and list(map(rect,record['forbidden_center_rectangles']))==blocked
        axes=[sorted({root[k],root[k+2]}|{r[j] for r in blocked for j in [k,k+2] if root[k]<r[j]<root[k+2]}) for k in [0,1]];expected={}
        for x0,x1 in zip(axes[0],axes[0][1:]):
            for y0,y1 in zip(axes[1],axes[1][1:]):expected[x0,y0,x1,y1]=not any(r[0]<(x0+x1)/2<r[2] and r[1]<(y0+y1)/2<r[3] for r in blocked)
        actual={tuple(rect(r['bounds'])):r['retained'] for r in record['atomic_cells']};assert len(actual)==len(record['atomic_cells']) and actual==expected;atom_count+=len(actual);merged=list(map(rect,record['merged_cells']));assert merged==sorted(merged,key=lambda r:(r[1],r[0],r[3],r[2])) and all(covered(r,root) and all(separate(r,b) for b in blocked) for r in merged) and all(separate(a,b) for a,b in combinations(merged,2));assert sum(rectangle_area(r) for r in merged)==sum(rectangle_area(r) for r,keep in expected.items() if keep)
        for atom,keep in expected.items():
            if keep:assert sum(covered(atom,r) for r in merged)==1
        assert record['complete_for_conservative_rectangle_arrangement'] and not record['complete_for_original_free_space']
        for cell_index,cell in enumerate(merged):
            bb=list(map(float,[cell[0]+epsilon,cell[1]+epsilon,cell[2]-epsilon,cell[3]-epsilon]));ff=list(map(F,bb));assert all(ff[k]>cell[k] for k in [0,1]) and all(ff[k]<cell[k] for k in [2,3]);mode={'mode':len(expected_modes[family]),'source_mode':source_mode,'cell_index':cell_index,'rotation_radians':angle,'mirrored':mirror,'continuous_rotation':family=='cog','center_bounds_mm':[[bb[0],bb[2]],[bb[1],bb[3]]],'rectangle_mm':bb};expected_modes[family].append(mode);proofs=[]
            for pi,piece in enumerate(local):
                moved=[ff[0]+piece[0],ff[1]+piece[1],ff[2]+piece[2],ff[3]+piece[3]];assert covered(moved,safe)
                for fi,core in enumerate(cores):
                    gaps=[core[0]-moved[2],core[1]-moved[3],moved[0]-core[2],moved[1]-core[3]];axis=max(range(4),key=lambda k:gaps[k]);assert gaps[axis]>=F('.22');proofs.append({'piece':pi,'core':fi,'axis':axis,'exact_gap_mm':str(gaps[axis])});proof_count+=1;min_gap=min(min_gap,float(gaps[axis]))
            saved=next(r for r in certificates if r['family']==family and r['compound_mode']==mode['mode']);assert saved=={'family':family,'compound_mode':mode['mode'],'source_mode':source_mode,'cell_index':cell_index,'piece_core_axis_supports':proofs}
assert expected_modes==lib['family_modes'] and len(decompositions)==13 and len(expected_modes['cog'])>1;ids=[['bracket',i] for i in range(6,12)]+[['insert',i] for i in range(11)]+[['insert',20]]+[['cog',i] for i in range(15)];assert lib['identities']==ids and lib['pairs']==[list(p) for p in combinations(range(33),2)] and lib['continuous_parameters']==81 and lib['angle_coordinate_start']==66 and lib['first_cog_owner']==18 and lib['angle_bounds']==[[-math.pi*radius,math.pi*radius] for _ in range(15)];assert sorted(lib['all66_identities'])==sorted([[r['part_id'],r['copy_index']] for r in fixed]+ids)
partial=copy.deepcopy(load(SOURCE/'source48-control.json'));seeds=[]
for row in partial:
    if row['part_id']!='cog':continue
    identity=['cog',row['copy_index']];owner=ids.index(identity);t=row['transform'];theta=t['rotation_radians'];c,s=math.cos(theta),math.sin(theta);px,py=lib['families']['cog']['source_center'];oldcenter=[px*c-py*s+t['translation'][0],px*s+py*c+t['translation'][1]];choices=[]
    for mode in lib['family_modes']['cog']:
        point=[min(max(oldcenter[k],mode['center_bounds_mm'][k][0]),mode['center_bounds_mm'][k][1]) for k in [0,1]];choices.append((sum((a-b)**2 for a,b in zip(point,oldcenter)),mode['mode'],point))
    squared,mi,point=min(choices);assert squared<.0001**2;t['translation']=[point[0]-(px*c-py*s),point[1]-(px*s+py*c)];available=[m['mode'] for m in lib['family_modes']['cog'] if all(m['center_bounds_mm'][k][0]<=point[k]<=m['center_bounds_mm'][k][1] for k in [0,1])];seeds.append({'owner':owner,'identity':identity,'source_original_center':oldcenter,'center':point,'source_pose':t,'angle_radians':theta,'projection_distance_mm':math.sqrt(squared),'selected_projection_compound_mode':mi,'covering_compound_modes':available})
assert seeds==lib['source_moving_seed']==load(BASE/'source15-moving-seed.json') and partial==load(BASE/'source48-control.json');control=audit(job,partial,stocks,required,guard);assert control==load(BASE/'source48-checks.json') and control['valid'];corner_controls=[];bindings=0
for owner,(family,identity) in enumerate(ids):
    px,py=lib['families'][family]['source_center']
    for mode in lib['family_modes'][family]:
        bindings+=1
        for point in product(*mode['center_bounds_mm']):
            for theta in ([-math.pi/3,0.,math.pi/4] if family=='cog' else [mode['rotation_radians']]):
                c,s=math.cos(theta),math.sin(theta);m=-1 if mode['mirrored'] else 1;r={'part_id':family,'copy_index':identity,'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':mode['mirrored'],'translation':[point[0]-(m*px*c-py*s),point[1]-(m*px*s+py*c)]}};checked=audit(job,fixed+[r],stocks,required,guard);assert checked['valid'];corner_controls.append({'owner':owner,'mode':mode['mode'],'center':point,'angle':theta,'minimum_source_gap_mm':checked['minimum_pair_gap_mm'],'minimum_stock_mm':checked['minimum_extra_stock_mm']})
write(OUT/'source-corner-controls.json',corner_controls);process=load(ROOT/'output/h5-mixed-roof-hard-cells-preparation-process-20261107/process.json');assert process['closed'] and process['passed'];charge=prior['complete_preparation_seconds']+process['complete_seconds'];inputs=[Path(__file__),JOB,Q/'partitions.json',ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py']+[SOURCE/n for n in ['plan.json','source-geometry.json','source48-control.json','audit/checks.json']]+[BASE/n for n in ['plan.json','library.json','fixed33-source.json','fixed33-checks.json','fixed-core-boxes.json','rectangle-decompositions.json','cell-support-certificates.json','source48-control.json','source48-checks.json','source15-moving-seed.json']]+[ROOT/'output/h5-mixed-roof-hard-cells-preparation-process-20261107/process.json'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independent exact source-piece coverage, all-angle radius, containment of actual frame vertices in both coreboxes, all13 rational arrangements/atomic cells/merged coverage, every whole-cell piece/core support and stock bound. Verify every compound mode and all33 owner bindings,15 nearest-cell source projections, source48 partial and every source corner control. Multiple cog cells preserved. No optimizer.'});checks={'passed':True,'seconds':time.perf_counter()-start,'fixed_originals':33,'fixed_source_valid':True,'moving_originals':33,'continuous_parameters':81,'continuous_cog_angles':15,'moving_pairs':528,'fixed_containing_boxes_verified':2,'base_arrangements_verified':13,'atomic_cells_verified':atom_count,'compound_modes_by_family':{f:len(v) for f,v in expected_modes.items()},'owner_compound_bindings':bindings,'whole_cell_piece_core_supports':proof_count,'minimum_certified_axis_gap_mm':min_gap,'source_corner_controls':len(corner_controls),'source_control_originals':48,'source_control_valid':True,'seed_cog_projections_verified':15,'maximum_projection_nanometres':max(s['projection_distance_mm'] for s in seeds)*1e6,'complete_preparation_seconds':charge,'library_sha256':digest(BASE/'library.json'),'complete_initializer_prepared':False,'complete_model_prepared':False,'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
