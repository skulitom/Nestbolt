"""Frozen complete 2x2 reference-cell subdivisions for all five surviving queries."""
from pathlib import Path
from hashlib import sha256
import json,time
from h5_exact_rectangle_areas_20261108 import vertical_areas

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-fixed29-reference-subdivision-20261109'
BODY=ROOT/'output/h5-fixed29-reference-body-pilot-20261109'
FRONT=ROOT/'output/h5-fixed29-conditional-frontier-20261108'
POINT=ROOT/'output/h5-fixed29-conditional-pointwise-pilot-20261108'
DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108'
COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108'
OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')

def subtract_closed(box,forbidden):
    left,bottom,right,top=box;lowx,lowy,highx,highy=forbidden
    if right<=lowx or left>=highx or top<=lowy or bottom>=highy:return [box]
    result=[]
    if left<=lowx:result.append((left,bottom,min(right,lowx),top))
    if right>=highx:result.append((max(left,highx),bottom,right,top))
    midleft,midright=max(left,lowx),min(right,highx)
    if midleft<=midright:
        if bottom<=lowy:result.append((midleft,bottom,midright,min(top,lowy)))
        if top>=highy:result.append((midleft,max(bottom,highy),midright,top))
    return result

def sweep(boxes,geometry,stock):
    rectangles=set()
    for box in boxes:
        for component in geometry['all_alias_component_outer_rectangles_um']:
            value=[box[k]+component[k] for k in range(4)]
            rectangle=(max(value[0],stock[0]),max(value[1],stock[1]),min(value[2],stock[2]),min(value[3],stock[3]))
            if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:rectangles.add(rectangle)
    return rectangles

OUT.mkdir();began=time.perf_counter()
parent=load(BODY/'audit/checks.json');assert parent['passed'] and parent['remaining_fixed29_cases']==2
queries=load(BODY/'audit/pivot-results.json')
assert len(queries)==5 and all(not q['reference_cell_excluded'] for q in queries)
inputs=[Path(__file__),ROOT/'output/h5_exact_rectangle_areas_20261108.py',BODY/'audit/checks.json',BODY/'audit/plan.json',BODY/'audit/pivot-results.json',FRONT/'audit/checks.json',FRONT/'audit/plan.json',FRONT/'audit/remaining-cases.json',COVER/'audit/checks.json',COVER/'audit/plan.json',POINT/'audit/checks.json',POINT/'audit/plan.json',POINT/'audit/pivot-results.json',OLD/'geometries.json',OLD/'stock-cover.json']
for q in queries:
    index=q['refinement_index'];pivot=q['pivot_current_position'];graph=ROOT/load(DOM/f'choice-{index:02d}-dominance.json')['graph']
    inputs.extend([DOM/f'choice-{index:02d}-dominance.json',graph/'nodes.json',graph/'conflicts.bin',FRONT/f'choice-{index:02d}-frontier.json',COVER/f'choice-{index:02d}-covers.json',COVER/f'choice-{index:02d}-regions.json'])
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'selection':[[q['refinement_index'],q['pivot_current_position']] for q in queries],'subdivision':[2,2],'method':'Exactly the five surviving audited reference-body queries. Split each original closed anchor box at its integer axis midpoints into all four closed children. Intersect EVERY original certified reference-cover piece with each child, preserving points and lines. For each nonempty child, common occupied rectangles over the bounding box of its complete intersections are inside every possible reference outer envelope. Their141um axis buffers fit strictly inside200um clearance. Subtract the induced OPEN companion anchor obstacles from EVERY original CLOSED companion cover, using only current-frontier nonconflicting positions with the reference itself excluded. Sweep all alias outer components and calculate exact7bracket8insert capacities. Independently compute the alternative full-reference occupied-envelope bound before common-moving subtraction. Never add the two deductions. Exclude a parent only if every nonempty child fails; empty children require complete cover proof. No graph dominance transfer. Common-line holes remain reserved; no ordinary part-in-hole claim.','process_cap_seconds':45,'audit_cap_seconds_per_query':60,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'charge_entire_process_if_consumed':True,'inherited_numeric_preparation_seconds':parent['complete_preparation_seconds_if_consumed']})
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um']
results=[]
for qi,q in enumerate(queries):
    index=q['refinement_index'];pivot=q['pivot_current_position'];key=f'query-{qi:02d}'
    graph=ROOT/load(DOM/f'choice-{index:02d}-dominance.json')['graph'];nodes=load(graph/'nodes.json');N=len(nodes);width=(N+7)//8
    raw=(graph/'conflicts.bin').read_bytes();assert len(raw)==N*width
    conflicts=int.from_bytes(raw[pivot*width:(pivot+1)*width],'little')|(1<<pivot)
    active=load(FRONT/f'choice-{index:02d}-frontier.json')['remaining_current_positions'];assert pivot in active
    allowed=[position for position in active if not conflicts>>position&1]
    covers=load(COVER/f'choice-{index:02d}-covers.json');reference=nodes[pivot];geometry=geometries[reference['geometry']];assert geometry['family']=='bracket'
    original=covers[pivot]['remaining_closed_anchor_boxes_um'];left,bottom,right,top=reference['bounds_um'];midx=(left+right)//2;midy=(bottom+top)//2
    child_boxes=[[x0,y0,x1,y1] for x0,x1 in [(left,midx),(midx,right)] for y0,y1 in [(bottom,midy),(midy,top)]]
    fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um'];children=[];surviving=[]
    for ci,child in enumerate(child_boxes):
        intersections=sorted({(max(child[0],r[0]),max(child[1],r[1]),min(child[2],r[2]),min(child[3],r[3])) for r in original if max(child[0],r[0])<=min(child[2],r[2]) and max(child[1],r[1])<=min(child[3],r[3])})
        if not intersections:
            children.append({'child_index':ci,'closed_child_box_um':child,'reference_cover_intersections_um':[],'empty':True,'provisional_child_excluded':True});continue
        box=[min(r[0] for r in intersections),min(r[1] for r in intersections),max(r[2] for r in intersections),max(r[3] for r in intersections)]
        common=[]
        for component_index,(x0,y0,x1,y1) in enumerate(geometry['inner_rectangles_um']):
            rectangle=[box[2]+x0,box[3]+y0,box[0]+x1,box[1]+y1]
            if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:common.append({'source_component':component_index,'bounds_um':rectangle})
        buffered=[[r['bounds_um'][k]+(-141 if k<2 else 141) for k in range(4)] for r in common]
        forbidden=[sorted({(f[0]-c[2],f[1]-c[3],f[2]-c[0],f[3]-c[1]) for f in buffered for c in g['inner_rectangles_um']}) for g in geometries]
        records=[];regions={'bracket':set(),'insert':set()}
        for current in allowed:
            node=nodes[current];source=geometries[node['geometry']];pieces=[tuple(r) for r in covers[current]['remaining_closed_anchor_boxes_um']]
            for obstacle in forbidden[node['geometry']]:pieces=sorted({r for p in pieces for r in subtract_closed(p,obstacle)})
            records.append({'current_position':current,'remaining_closed_anchor_boxes_um':[list(r) for r in pieces]})
            regions[source['family']].update(sweep(pieces,source,stock))
        regions={family:sorted(rectangles) for family,rectangles in regions.items()}
        pointwise=vertical_areas(regions['bracket'],regions['insert'],fixed+buffered)
        fixed_only=vertical_areas(regions['bracket'],regions['insert'],fixed)[2]
        possible=sorted(sweep(intersections,geometry,stock))
        outside=vertical_areas(possible,[],regions['bracket']+regions['insert']+fixed)[0]
        compulsory=max(0,39999000000-outside);full_body=fixed_only-compulsory
        assert pointwise[2]<=q['prior_common_buffer_companion_area_upper_um2'] and full_body<=q['full_body_companion_area_upper_um2']
        required=[279993000000,158392000000,438385000000]
        failures=[i for i,(upper,lower) in enumerate(zip(pointwise,required)) if upper<lower]
        excluded=bool(failures) or full_body<required[2]
        record={'child_index':ci,'closed_child_box_um':child,'reference_cover_intersections_um':[list(r) for r in intersections],'empty':False,'reference_cover_bounding_box_um':box,'common_occupied_envelope_rectangles':common,'common_moving_clearance_regions_um':buffered,'open_forbidden_companion_anchor_rectangles_um':[[list(r) for r in group] for group in forbidden],'companion_covers':records,'family_component_regions_um':{family:[list(r) for r in rows] for family,rows in regions.items()},'possible_reference_occupied_regions_um':[list(r) for r in possible],'pointwise_area_upper_um2':pointwise,'fixed_only_companion_area_upper_um2':fixed_only,'reference_possible_area_outside_companion_and_fixed_um2':outside,'compulsory_reference_occupancy_in_companion_um2':compulsory,'full_body_companion_area_upper_um2':full_body,'combined_joint_area_upper_um2':min(pointwise[2],full_body),'failing_pointwise_area_indices':failures,'provisional_child_excluded':excluded}
        write(OUT/f'{key}-child-{ci}.json',record)
        children.append({k:record[k] for k in ['child_index','closed_child_box_um','reference_cover_intersections_um','empty','pointwise_area_upper_um2','full_body_companion_area_upper_um2','combined_joint_area_upper_um2','provisional_child_excluded']})
        if not excluded:surviving.extend(intersections)
        print({'query':qi,'case':index,'pivot':pivot,'child':ci,'joint_upper_mm2':record['combined_joint_area_upper_um2']/10**6,'excluded':excluded},flush=True)
    row={'query_index':qi,'refinement_index':index,'empty_sites':q['empty_sites'],'pivot_current_position':pivot,'pivot_source_label':reference['node'],'original_closed_anchor_box_um':reference['bounds_um'],'original_reference_cover_um':original,'allowed_current_positions':allowed,'children':children,'surviving_reference_cover_um':[list(r) for r in sorted(set(surviving))],'provisional_reference_cell_excluded':all(c['provisional_child_excluded'] for c in children),'dominance_transfer_permitted':False}
    write(OUT/f'{key}.json',row);results.append({'query_index':qi,'refinement_index':index,'pivot_current_position':pivot,'nonempty_children':sum(not c['empty'] for c in children),'excluded_nonempty_children':sum(not c['empty'] and c['provisional_child_excluded'] for c in children),'provisional_reference_cell_excluded':row['provisional_reference_cell_excluded']})
write(OUT/'query-results.json',results)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'fixed_queries':5,'closed_children':20,'nonempty_children':sum(r['nonempty_children'] for r in results),'provisional_excluded_reference_queries':sum(r['provisional_reference_cell_excluded'] for r in results),'independent_audit_pending':True,'optimizer_calls':0,'H5_complete':False})
