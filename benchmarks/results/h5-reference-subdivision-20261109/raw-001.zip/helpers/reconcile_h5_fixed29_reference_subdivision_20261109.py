"""Reconcile every frozen child, closed process and unchanged complete frontier."""
from pathlib import Path
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed29-reference-subdivision-20261109';OUT=BASE/'reconciliation'
BODY=ROOT/'output/h5-fixed29-reference-body-pilot-20261109';FRONT=ROOT/'output/h5-fixed29-conditional-frontier-20261108'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,value):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
OUT.mkdir();began=time.perf_counter();bindings={};checks=[];queries=load(BODY/'audit/pivot-results.json');rows=[]
specs=[('h5-fixed29-reference-subdivision-process-20261109',True),('h5-fixed29-reference-subdivision-audit-00-process-20261109',False),('h5-horizontal-segment-area-controls-process-20261109',True)]+[(f'h5-fixed29-reference-subdivision-audit-v2-{i:02d}-process-20261109',True) for i in range(5)]
processes=[]
for name,passed in specs:
    p=ROOT/'output'/name/'process.json';v=load(p)
    assert v['closed'] and v['passed']==passed and v['job']['closed'] and v['job']['active_processes']==0
    assert v['job']['job_committed_memory_limit']==2**31
    bindings[p.relative_to(ROOT).as_posix()]=digest(p)
    processes.append({'stage':name,'seconds':v['complete_seconds'],'cap_seconds':v['job']['maximum_ms']/1000,'passed':passed,'closed':True,'active_processes':0})
for i,q in enumerate(queries):
    audit=BASE/f'audit-v2-{i:02d}';check=load(audit/'checks.json');assert check['passed'] and check['query_index']==i
    for name,h in load(audit/'plan.json')['inputs'].items():assert digest(ROOT/name)==h;bindings[name]=h
    for p in [audit/'checks.json',audit/'plan.json',audit/'query-result.json']:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
    result=load(audit/'query-result.json');assert (result['refinement_index'],result['pivot_current_position'])==(q['refinement_index'],q['pivot_current_position'])
    assert len(result['children'])==4 and all(not c['empty'] and not c['child_excluded'] for c in result['children']) and not result['reference_cell_excluded']
    upper=max(c['combined_joint_area_upper_um2'] for c in result['children'])
    assert upper<=q['combined_companion_area_upper_um2']
    rows.append({'refinement_index':q['refinement_index'],'pivot_current_position':q['pivot_current_position'],'pivot_source_label':q['pivot_source_label'],'prior_joint_upper_um2':q['combined_companion_area_upper_um2'],'whole_reference_joint_upper_um2':upper,'whole_reference_reduction_um2':q['combined_companion_area_upper_um2']-upper,'least_child_joint_upper_um2':min(c['combined_joint_area_upper_um2'] for c in result['children']),'required_other_joint_area_lower_um2':438385000000,'reference_cell_excluded':False})
    checks.append(check)
assert len({c['complete_preparation_seconds_if_consumed'] for c in checks})==1
remaining=load(FRONT/'audit/remaining-cases.json');assert len(remaining)==2 and sum(r['remaining_current_nodes'] for r in remaining)==8903
for p in [Path(__file__),BODY/'audit/checks.json',BODY/'audit/pivot-results.json',FRONT/'audit/checks.json',FRONT/'audit/remaining-cases.json',ROOT/'output/h5-fixed29-reference-subdivision-audit-correction-20261109.json']:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Require all five original frozen queries and all twenty nonempty closed children to pass independent v2 verification. Reconcile the maximum conditional joint upper across every child, preserving global current-position masks because no child was excluded. Verify terminal state and aggregate memory enforcement for all eight preceding processes, including the initial hard-limit failure. Charge failed full wall time and the new numeric helper controls in addition to the single producer. No old process or optimizer is reopened.'})
write(OUT/'query-summary.json',rows);write(OUT/'process-summary.json',processes);write(OUT/'remaining-cases.json',remaining)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'queries_verified':5,'closed_children_verified':20,'exact_area_bounds_verified':sum(c['exact_area_bounds_verified'] for c in checks),'reference_boundary_classes_verified':sum(c['reference_boundary_classes_verified'] for c in checks),'common_rectangle_corner_checks':sum(c['common_rectangle_corner_checks'] for c in checks),'companion_covers_verified':sum(c['companion_covers_verified'] for c in checks),'complete_companion_boundary_classes_verified':sum(c['complete_companion_boundary_classes_verified'] for c in checks),'new_reference_cells_excluded':0,'new_child_regions_excluded':0,'remaining_fixed29_choices':2,'remaining_current_nodes':8903,'whole_allocations_remaining':440,'initial_hard_limit_failure_preserved':True,'all8_prior_processes_closed':True,'common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'whole_scope_exclusions':0,'complete_preparation_seconds_before_this_reconciliation':checks[0]['complete_preparation_seconds_if_consumed'],'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'));print(rows)
