"""Seal complete reference subdivisions and the independently controlled faster auditor."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
original=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8')
prefix=original[:original.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-reference-subdivision-20261109'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-fixed29-reference-subdivision-20261109';F=BASE/'reconciliation';D=ROOT/'output/h5-horizontal-segment-area-controls-20261109'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-conditional-bracket-capacity-20261109'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['queries_verified']==5 and front['closed_children_verified']==20 and front['new_reference_cells_excluded']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-conditional-bracket-capacity-main-sync-20261109']+[ROOT/'output'/r['stage'] for r in load(F/'process-summary.json')]+[ROOT/'output/h5-fixed29-reference-subdivision-reconciliation-process-20261109']",
"['*h5*mixed*mode*20261107.py']":"['*h5*reference_subdivision*20261109.py','*h5*horizontal_segment*20261109.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_reference_subdivision_checkpoint_20261109.py','seal_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for before,after in changes.items():assert before in prefix,before;prefix=prefix.replace(before,after)
exec(prefix)
reconcile=load(ROOT/'output/h5-fixed29-reference-subdivision-reconciliation-process-20261109/process.json')
assert reconcile['closed'] and reconcile['passed'] and reconcile['job']['active_processes']==0
total=front['complete_preparation_seconds_before_this_reconciliation']+reconcile['complete_seconds']
process_table=load(F/'process-summary.json')+[{'stage':'h5-fixed29-reference-subdivision-reconciliation-process-20261109','seconds':reconcile['complete_seconds'],'cap_seconds':reconcile['job']['maximum_ms']/1000,'passed':True,'closed':True,'active_processes':0}]
assert len(process_table)==9 and sum(not r['passed'] for r in process_table)==1
copies=[(F/'checks.json','reconciliation-checks.json'),(F/'query-summary.json','query-summary.json'),(F/'remaining-cases.json','remaining-fixed29-cases.json'),(BASE/'plan.json','subdivision-plan.json'),(D/'plan.json','area-controls-plan.json'),(D/'checks.json','area-controls-checks.json'),(D/'real-source-controls.json','area-controls-source-results.json'),(ROOT/'output/h5-fixed29-reference-subdivision-audit-correction-20261109.json','failed-audit-correction.json'),(ROOT/'output/h5-conditional-bracket-capacity-main-sync-20261109/receipt.json','prior-main-push-receipt.json')]
for i in range(5):copies.extend([(BASE/f'audit-v2-{i:02d}/checks.json',f'query-{i:02d}-audit.json'),(BASE/f'audit-v2-{i:02d}/query-result.json',f'query-{i:02d}-result.json')])
for r in process_table:copies.append((ROOT/'output'/r['stage']/'process.json',r['stage']+'.json'))
for source,name in copies:shutil.copyfile(source,OUT/name)
write(OUT/'process-summary.json',process_table)
runtime=load(PARENT/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
ci=json.loads(subprocess.check_output(['gh','run','view','42539853627','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True))
assert ci['headSha']=='0efe56887ae5c8f9a866388d6001b0e90c37515e'
success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs']);write(OUT/'main-ci-at-review.json',ci)
write(OUT/'checks.json',{**front,**archive,'passed':True,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime),'all9_processes_closed':True,'consumed_preparation_seconds':total,'fixed29_choices_excluded_of455':453,'zero_clearance_exclusions_of455':428,'older_first32_cores_closed':8,'separate_five_column_cores_closed':680,'completion_percent':60})
write(OUT/'next-step.json',{'status':'complete_subdivision_does_not_exclude_any_reference_cell','remaining_fixed29_choices':[[0,5,10],[5,10,11]],'current_graph_position_masks':'output/h5-fixed29-conditional-frontier-20261108/choice-{01,09}-frontier.json remaining_current_positions','new_refined_covers_required':False,'proposal':'Do not repeat this twenty-child pilot or open old optimizer calls. Assess a complete conditional proof covering the current minimal reference conflict rows, with explicit frozen batches, source masks and full preparation accounting; the faster independently controlled horizontal interval-tree audit makes broader exact replay practical. Additional pose-specific pruning requires a genuinely stronger coupling to companion placement or a proved benefit from finer source geometry. These five queries are not all minimal rows and the two surviving scopes are not placements. No broader batch, model or proof has been prepared. Any future timed constructor must independently recompute original inputs and pass a complete preparation-inclusive preflight.','consumed_preparation_seconds':total,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'whole_allocations_remaining':440,'source_valid66':False,'H5_complete':False})
rows=load(F/'query-summary.json')
query_table='\n'.join(f"| {r['refinement_index']:02d} / {r['pivot_current_position']} | {r['prior_joint_upper_um2']/1e6:,.6f} | {r['whole_reference_joint_upper_um2']/1e6:,.6f} | {r['least_child_joint_upper_um2']/1e6:,.6f} |" for r in rows)
process_rows='\n'.join(f"| {r['stage'].removeprefix('h5-').removesuffix('-20261109')} | {r['seconds']:.6f} | {r['cap_seconds']:.0f} | {'Pass' if r['passed'] else 'Preserved hard limit'} |" for r in process_table)
report=f'''# Complete bracket-reference subdivisions — 2026-11-09

**All five reference queries and all twenty closed child regions pass independent
verification, but none is excluded.** Four parent bounds tighten; the exact
fixed29 frontier stays at omitted cog sites **`[0,5,10]` and `[5,10,11]`**, with
8,903 current nodes. The existing 453/455 exclusions, including 428 at zero
clearance, are unchanged. H2/H5 remain open at **60% completed milestone weight**.

## Complete scope and geometric meaning

[The frozen selection]({NAME}/subdivision-plan.json) contains every surviving
query from the preceding five-query whole-reference pilot. Each original
closed anchor box is split at both integer midpoints. Every certified reference
cover piece is intersected with every child, including points and lines.
The independent auditor verifies each intersection and their complete union;
no unproved region is omitted. All twenty children are nonempty.

For each child, occupied rectangles common to every reference position receive
141 µm square buffers, strictly inside the original 0.2 mm clearance. Their
open forbidden companion-anchor regions are subtracted from complete closed
source covers. The current global mask and actual conflict row determine the
allowed companions. Every alias component is swept over the surviving covers.
The seven other brackets and eight inserts require **438,385 mm²**.

These are **common-line occupied outer envelopes with holes reserved**. The
[source-policy audit](h5-fixed29-pointwise-capacity-20261108/occupancy-scope/checks.json)
retains all 90 cutting holes. No net-material or ordinary part-in-hole exclusion
is claimed. Full-reference occupancy is an alternative bound calculated before
common-moving subtraction; the two deductions are never added. Pose-specific
bounds never transfer through conflict-row dominance.

## Independent result

[Complete reconciliation]({NAME}/reconciliation-checks.json) verifies
**100 exact area bounds**, **865 reference boundary/interior classes**,
**640 common-rectangle corner checks**, **51,628 companion covers** and
**1,119,932 companion boundary/interior classes**. A parent bound is the maximum
over every child, rather than the best selected child.

| Case / current reference | Prior parent upper (mm²) | New complete parent upper (mm²) | Smallest child upper (mm²) |
|---|---:|---:|---:|
{query_table}

[Exact integer results]({NAME}/query-summary.json) preserve source labels
separately from current graph positions. The closest complete parent bound,
case 09 / reference 1854, still exceeds the required area by **561.657222 mm²**.
Even its best child remains **380.171818 mm²** above the requirement. These
surpluses prove neither a feasible arrangement nor an impossibility result.
The full source cover remains unchanged.

## Preserved audit failure and checked replacement

The producer completes once in 37.161113 s under its 45 s cap. The first
independent horizontal interval-merge audit reaches its hard 60 s limit after
two child readbacks. Its process, partial output and original script remain
preserved; no final proof uses that partial result. The producer is not repeated.
[The correction record]({NAME}/failed-audit-correction.json) records the change.

The replacement auditor uses a horizontal event sweep with an interval tree,
independent of the producer's vertical prefix arrays. Before use,
[exhaustive controls]({NAME}/area-controls-checks.json) compare all 4,096 subsets
of twelve labelled overlapping, nested and touching rectangles with an exact
unit-cell oracle, then repeat all 4,096 after integer scaling and translation.
Duplicate multiplicities and empty categories pass. Nine previously certified
full-source area bounds also match. All five replacement audits pass separately
within their unchanged 60 s caps; all twenty children are replayed in full.

| Bounded process | Complete time (s) | Cap (s) | Result |
|---|---:|---:|---|
{process_rows}

[All nine processes close]({NAME}/process-summary.json) with no live descendants,
CCD1 logical processors 16–31, one BLAS/OMP/MKL thread and a 2 GiB Windows Job
memory cap. Consumed numeric preparation is **{total:.6f} s**, including the
complete failed audit and new helper controls. No optimizer, timer reset or
timed H5 pass is allowed from this lineage.

## Remaining work and repository state

[Next]({NAME}/next-step.json), assess complete conditional coverage of the current
minimal reference rows, with bounded batches and explicit accounting. The
five-query pilot does not cover every row. Repeating this subdivision or an old
closed optimization would add no new method. No broader batch is prepared.

[The two exact fixed29 cases]({NAME}/remaining-fixed29-cases.json), all 440
whole-job allocations, full 66-part source/native/material validation, production
integration and the full H5 matrix remain open. The valid 64-part layout stays
best. The separate eight older first32 and 680 five-column cores remain closed.
Product, README and release state are unchanged.

[The preceding checkpoint reached main 0efe5688]({NAME}/prior-main-push-receipt.json)
after all six prior checks passed. [Its current CI]({NAME}/main-ci-at-review.json)
has {success} passed / {live} live jobs at review. This evidence checkpoint may
be committed locally while that run finishes; a normal push must preserve it.
[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json),
[historical references]({NAME}/external-evidence.json) and
[runtime pins]({NAME}/runtime-bindings.json) preserve the consumed evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-09 H5 complete reference subdivisions:** [independent continuous-cover and area audits]({{link}}) verify all five surviving queries and twenty closed child regions, with 100 exact area bounds, 51,628 companion covers and 1,119,932 companion boundary/interior classes. Four parent bounds tighten, but no child or reference cell is excluded. The exact fixed29 choices [0,5,10] and [5,10,11] retain 8,903 nodes; 453/455 prior exclusions remain. The first auditor reaches its hard 60 s limit and is preserved. A distinct horizontal interval-tree auditor passes 8,192 exhaustive oracle controls, nine previous source bounds and all twenty new children, without repeating the producer. All nine processes close; consumed preparation {total:.6f} s cannot reset or open an optimizer. Common-line holes stay reserved; no ordinary part-in-hole or whole-allocation exclusion follows. Next assess complete conditional row coverage with frozen bounded batches; none is prepared. All 440 allocations, full66 validation and H5 remain open, valid64 stays best, and H2/H5 stay open at 60%. Main 0efe5688 has {success} passed/{live} live CI jobs at review. Product/releases unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8');start=content.index('Latest H5 evidence:');end=content.index('\nThe earlier fixed 13-cog construction',start)
intro=f'''Latest H5 evidence: [complete reference subdivisions](../benchmarks/results/{NAME}.md).
All five surviving bracket-reference queries and twenty closed child regions
pass independent continuous-cover and exact-area audits. Four parent bounds
tighten, but no child or reference cell is excluded. The exact fixed29 choices
[0,5,10] and [5,10,11] retain 8,903 nodes; 453/455 are excluded by prior proofs,
including 428 at zero clearance. These common-line bounds reserve all holes.
The initial audit's hard-limit failure is preserved. A distinct interval-tree
auditor passes 8,192 exhaustive controls, nine prior source bounds and all 100
new area bounds. All nine processes close. Consumed preparation is {total:.6f} s;
no optimizer or timer reset is permitted. Complete conditional row coverage is
the next method to assess; no broader batch has been prepared.
All 440 whole-job allocations remain, the valid 64-part layout stays best, and
H2/H5 remain open at 60% completed milestone weight. No whole allocation or
ordinary part-in-hole configuration is excluded. The separate eight older
first32 and 680 five-column cores remain closed.
Prior checkpoint reached main 0efe5688; its CI has {success} passed/{live} live
jobs at review. This checkpoint awaits ordinary push. Product/releases unchanged.
'''
status.write_text(content[:start]+intro+content[end:],encoding='utf-8',newline='\n')
append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'source_bindings':len(bindings),'historical_references':len(external),'consumed_preparation_seconds':total,'main_ci_passed':success,'main_ci_live':live})
