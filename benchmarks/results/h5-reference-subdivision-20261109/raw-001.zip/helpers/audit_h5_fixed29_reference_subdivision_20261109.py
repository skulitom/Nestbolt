"""Independent boundary-class coverage, common-envelope witnesses and horizontal areas."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,time,sys
import numpy as np
from h5_exact_rectangle_areas_20261108 import horizontal_areas

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-fixed29-reference-subdivision-20261109'
BODY=ROOT/'output/h5-fixed29-reference-body-pilot-20261109'
FRONT=ROOT/'output/h5-fixed29-conditional-frontier-20261108'
DOM=ROOT/'output/h5-fixed29-pivot-dominance-20261108'
COVER=ROOT/'output/h5-fixed29-clearance-domains-20261108'
OLD=ROOT/'output/h5-four-fixed29-current-areas-v3-20261108'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')

def axis(cuts):
    values=np.array(sorted(cuts),dtype=np.int64);result=np.empty(2*len(values)-1,dtype=np.int64)
    result[::2]=2*values;result[1::2]=values[:-1]+values[1:];return result

def cover(rows,xx,yy,closed):
    result=np.zeros((len(yy),len(xx)),dtype=bool)
    for left,bottom,right,top in rows:
        x0=int(np.searchsorted(xx,2*left,side='left' if closed else 'right'));x1=int(np.searchsorted(xx,2*right,side='right' if closed else 'left'))
        y0=int(np.searchsorted(yy,2*bottom,side='left' if closed else 'right'));y1=int(np.searchsorted(yy,2*top,side='right' if closed else 'left'))
        result[y0:y1,x0:x1]=True
    return result

def axes(box,rows):
    left,bottom,right,top=box
    return axis({left,right}|{r[k] for r in rows for k in [0,2] if left<=r[k]<=right}),axis({bottom,top}|{r[k] for r in rows for k in [1,3] if bottom<=r[k]<=top})

qi=int(sys.argv[1]);assert 0<=qi<5
OUT=BASE/f'audit-{qi:02d}';OUT.mkdir();began=time.perf_counter();bindings={}
for folder in [BASE,BODY/'audit',FRONT/'audit',COVER/'audit']:
    if folder!=BASE:assert load(folder/'checks.json')['passed']
    for name,expected in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==expected;bindings[name]=expected
key=f'query-{qi:02d}'
for p in [Path(__file__),BASE/'checks.json',BASE/'query-results.json',BASE/(key+'.json')]+sorted(BASE.glob(key+'-child-*.json')):bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'query_index':qi,'method':'Independently prove all four child intersections and their union on every continuous point/open-interval class, including zero-width/height boundaries. Verify every common rectangle corner inside its actual occupied-envelope component at every corner of every retained reference-cover piece. Independently derive all open companion obstacles and verify exact closed-cover differences using boundary-class truth grids, without producer subtraction. Reconstruct complete alias-component sweeps; replay all three pointwise and two full-body area bounds with horizontal interval merging, independent of producer vertical sweeps. A parent is excluded only if every nonempty child fails. Common-line holes reserved; no dominance transfer or ordinary part-in-hole exclusion.'})
queries=load(BODY/'audit/pivot-results.json');assert len(queries)==5
assert load(BASE/'plan.json')['selection']==[[q['refinement_index'],q['pivot_current_position']] for q in queries]
q=queries[qi];row=load(BASE/(key+'.json'));index=q['refinement_index'];pivot=q['pivot_current_position']
assert (row['query_index'],row['refinement_index'],row['pivot_current_position'])==(qi,index,pivot)
assert row['empty_sites']==q['empty_sites'] and not row['dominance_transfer_permitted']
remaining=load(FRONT/'audit/remaining-cases.json');assert index in {r['refinement_index'] for r in remaining}
graph=ROOT/load(DOM/f'choice-{index:02d}-dominance.json')['graph'];nodes=load(graph/'nodes.json');N=len(nodes);width=(N+7)//8
raw=(graph/'conflicts.bin').read_bytes();assert len(raw)==N*width
front=load(FRONT/f'choice-{index:02d}-frontier.json');active=front['remaining_current_positions'];assert pivot in active
allowed=[position for position in active if position!=pivot and not raw[pivot*width+position//8]>>(position%8)&1]
assert row['allowed_current_positions']==allowed and len(set(allowed))==len(allowed)
geometries=load(OLD/'geometries.json');stock=load(OLD/'stock-cover.json')['outward_stock_rectangle_um'];reference=nodes[pivot];geometry=geometries[reference['geometry']]
assert geometry['family']=='bracket' and row['pivot_source_label']==reference['node']
reference_box=reference['bounds_um'];assert row['original_closed_anchor_box_um']==reference_box
self_component=geometry['inner_rectangles_um'][front['source_self_collision_components'][pivot]]
assert reference_box[2]-reference_box[0]<self_component[2]-self_component[0] and reference_box[3]-reference_box[1]<self_component[3]-self_component[1]
covers=load(COVER/f'choice-{index:02d}-covers.json');original=covers[pivot]['remaining_closed_anchor_boxes_um'];assert row['original_reference_cover_um']==original
left,bottom,right,top=reference_box;mx=(left+right)//2;my=(bottom+top)//2
expected_children=[[left,bottom,mx,my],[left,my,mx,top],[mx,bottom,right,my],[mx,my,right,top]]
children=row['children'];assert len(children)==4 and [c['closed_child_box_um'] for c in children]==expected_children
all_intersections=[r for c in children for r in c['reference_cover_intersections_um']]
xx,yy=axes(reference_box,original+expected_children+all_intersections)
assert np.array_equal(cover(original,xx,yy,True),cover(all_intersections,xx,yy,True))
reference_classes=len(xx)*len(yy);companion_classes=corner_checks=companion_covers=area_count=0
assert 2*141**2<200**2
fixed=load(COVER/f'choice-{index:02d}-regions.json')['forbidden_fixed_clearance_rectangles_um'];surviving=[];checked_children=[]
for ci,child in enumerate(children):
    assert child['child_index']==ci
    child_box=child['closed_child_box_um'];intersections=child['reference_cover_intersections_um']
    assert len({tuple(r) for r in intersections})==len(intersections)
    assert all(child_box[0]<=r[0]<=r[2]<=child_box[2] and child_box[1]<=r[1]<=r[3]<=child_box[3] for r in intersections)
    assert np.array_equal(cover(original,xx,yy,True)&cover([child_box],xx,yy,True),cover(intersections,xx,yy,True))
    reference_classes+=len(xx)*len(yy)
    if not intersections:
        assert child=={'child_index':ci,'closed_child_box_um':child_box,'reference_cover_intersections_um':[],'empty':True,'provisional_child_excluded':True}
        assert not (BASE/f'{key}-child-{ci}.json').exists()
        checked_children.append({**child,'child_excluded':True});continue
    record=load(BASE/f'{key}-child-{ci}.json')
    assert {k:record[k] for k in child}==child and not child['empty']
    box=[min(r[0] for r in intersections),min(r[1] for r in intersections),max(r[2] for r in intersections),max(r[3] for r in intersections)]
    assert record['reference_cover_bounding_box_um']==box
    common=record['common_occupied_envelope_rectangles'];assert len({r['source_component'] for r in common})==len(common)
    for entry in common:
        component=geometry['inner_rectangles_um'][entry['source_component']];rect=entry['bounds_um']
        assert rect[0]<rect[2] and rect[1]<rect[3]
        for piece in intersections:
            for anchorx,anchory in product([piece[0],piece[2]],[piece[1],piece[3]]):
                for pointx,pointy in product([rect[0],rect[2]],[rect[1],rect[3]]):
                    assert component[0]<=pointx-anchorx<=component[2] and component[1]<=pointy-anchory<=component[3];corner_checks+=1
    buffered=record['common_moving_clearance_regions_um']
    assert buffered==[[r['bounds_um'][k]+(-141 if k<2 else 141) for k in range(4)] for r in common]
    forbidden=record['open_forbidden_companion_anchor_rectangles_um'];assert len(forbidden)==len(geometries)
    for gi,source in enumerate(geometries):
        expected=set()
        for a,b,c,d in source['inner_rectangles_um']:
            for x0,y0,x1,y1 in buffered:expected.add((x0-c,y0-d,x1-a,y1-b))
        assert forbidden[gi]==[list(r) for r in sorted(expected)]
    records=record['companion_covers'];assert [r['current_position'] for r in records]==allowed
    regions={'bracket':set(),'insert':set()}
    for current,entry in zip(allowed,records):
        node=nodes[current];source=geometries[node['geometry']];initial=covers[current]['remaining_closed_anchor_boxes_um'];retained=entry['remaining_closed_anchor_boxes_um'];obstacles=forbidden[node['geometry']]
        l,b,r,t=node['bounds_um'];assert all(l<=v[0]<=v[2]<=r and b<=v[1]<=v[3]<=t for v in retained)
        ax,ay=axes(node['bounds_um'],initial+retained+obstacles);assert len(ax)*len(ay)<4000000
        assert np.array_equal(cover(initial,ax,ay,True)&~cover(obstacles,ax,ay,False),cover(retained,ax,ay,True)),(qi,ci,current)
        companion_classes+=len(ax)*len(ay);companion_covers+=1
        for piece in retained:
            for component in source['all_alias_component_outer_rectangles_um']:
                translated=[piece[k]+component[k] for k in range(4)]
                rectangle=(max(stock[0],translated[0]),max(stock[1],translated[1]),min(stock[2],translated[2]),min(stock[3],translated[3]))
                if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:regions[source['family']].add(rectangle)
    regions={family:sorted(rows) for family,rows in regions.items()}
    assert record['family_component_regions_um']=={family:[list(r) for r in rows] for family,rows in regions.items()}
    possible=set()
    for piece in intersections:
        for component in geometry['all_alias_component_outer_rectangles_um']:
            translated=[piece[k]+component[k] for k in range(4)]
            rectangle=(max(stock[0],translated[0]),max(stock[1],translated[1]),min(stock[2],translated[2]),min(stock[3],translated[3]))
            if rectangle[0]<rectangle[2] and rectangle[1]<rectangle[3]:possible.add(rectangle)
    possible=sorted(possible);assert record['possible_reference_occupied_regions_um']==[list(r) for r in possible]
    pointwise=horizontal_areas(regions['bracket'],regions['insert'],fixed+buffered)
    fixed_only=horizontal_areas(regions['bracket'],regions['insert'],fixed)[2]
    outside=horizontal_areas(possible,[],regions['bracket']+regions['insert']+fixed)[0]
    compulsory=max(0,39999000000-outside);full_body=fixed_only-compulsory;area_count+=5
    assert pointwise==record['pointwise_area_upper_um2'] and fixed_only==record['fixed_only_companion_area_upper_um2'] and outside==record['reference_possible_area_outside_companion_and_fixed_um2']
    assert compulsory==record['compulsory_reference_occupancy_in_companion_um2'] and full_body==record['full_body_companion_area_upper_um2']
    assert record['combined_joint_area_upper_um2']==min(pointwise[2],full_body)
    assert pointwise[2]<=q['prior_common_buffer_companion_area_upper_um2'] and full_body<=q['full_body_companion_area_upper_um2'] and fixed_only>=pointwise[2]
    required=[279993000000,158392000000,438385000000];failures=[i for i,(upper,lower) in enumerate(zip(pointwise,required)) if upper<lower]
    excluded=bool(failures) or full_body<required[2]
    assert failures==record['failing_pointwise_area_indices'] and excluded==record['provisional_child_excluded']
    if not excluded:surviving.extend(intersections)
    checked_children.append({**child,'child_excluded':excluded});print({'query':qi,'child':ci,'joint_upper_mm2':min(pointwise[2],full_body)/10**6,'excluded':excluded},flush=True)
surviving=[list(r) for r in sorted(set(map(tuple,surviving)))]
assert row['surviving_reference_cover_um']==surviving
excluded=all(c['child_excluded'] for c in checked_children);assert excluded==row['provisional_reference_cell_excluded']
process=load(ROOT/'output/h5-fixed29-reference-subdivision-process-20261109/process.json');assert process['closed'] and process['passed']
charge=load(BASE/'plan.json')['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'query-result.json',{'query_index':qi,'refinement_index':index,'empty_sites':q['empty_sites'],'pivot_current_position':pivot,'pivot_source_label':reference['node'],'children':checked_children,'surviving_reference_cover_um':surviving,'reference_cell_excluded':excluded,'dominance_transfer_permitted':False})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'query_index':qi,'complete_closed_children_verified':4,'nonempty_children_verified':sum(not c['empty'] for c in checked_children),'excluded_nonempty_children':sum(not c['empty'] and c['child_excluded'] for c in checked_children),'reference_boundary_classes_verified':reference_classes,'common_rectangle_corner_checks':corner_checks,'companion_covers_verified':companion_covers,'complete_companion_boundary_classes_verified':companion_classes,'exact_area_bounds_verified':area_count,'reference_cell_excluded':excluded,'common_line_holes_reserved':True,'ordinary_part_in_hole_exclusions':0,'whole_fixed_scope_exclusions':0,'complete_preparation_seconds_if_consumed':charge,'full_algorithm_budget_satisfied':False,'optimizer_allowed_from_current_lineage':False,'optimizer_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
