/* tslint:disable */
/* eslint-disable */

/**
 * Decode file bytes using the same DXF/XML rules as the native tools.
 */
export function decode_drawing(name: string, bytes: Uint8Array): string;

/**
 * Net part area over usable sheet area: a necessary lower bound only.
 */
export function estimate_sheets(library_json: string, request_json: string): string;

/**
 * One sheet of a valid layout as `"svg"`, `"dxf"` or preserving `"lbrn2"` text.
 */
export function export_sheet(library_json: string, request_json: string, layout_json: string, sheet_id: string, format: string, sheet_outline: boolean): string;

/**
 * Import files given as `[{"name": "a.svg", "text": "..."}]` into a library.
 */
export function import_files(files_json: string, tolerance_mm: number, svg_user_unit_mm: number): string;

/**
 * Structured options shared with the native importer. The legacy entry point
 * remains available for existing integrations and published benchmark runners.
 */
export function import_files_with_options(files_json: string, options_json: string): string;

/**
 * Stock-outline import uses its own selection, preferring SHEET over CUT.
 */
export function import_sheet(name: string, text: string, options_json: string): string;

/**
 * Show layer/colour choices even when a drawing has no closed selected outline.
 */
export function inspect_files(files_json: string, options_json: string): string;

/**
 * Same geometry inspection as the native CLI; units are explicit.
 */
export function inspect_job(json: string, units: string): string;

/**
 * Bytes of WebAssembly linear memory this engine instance has reserved.
 */
export function memory_bytes(): number;

/**
 * Nest with a wall-clock (`repeatable = false`) or work budget. `progress` is
 * called with `(seconds, material)` whenever a better layout is checked, and
 * with that layout's JSON as a third argument at most once per
 * `live_interval_s` seconds when it is positive (for a live preview; the
 * search already pauses to check every improvement, so this costs one
 * serialisation per shown layout).
 */
export function nest(library_json: string, request_json: string, seconds: number, seed: number, repeatable: boolean, live_interval_s: number, progress: Function): string;

/**
 * Benchmark entry: the same search as `nestbolt sheets` on a polygon job
 * (validator job JSON), with default search options. Returns the full sheet
 * result, so browser and native runs are scored identically.
 */
export function nest_job(job_json: string, seconds: number, seed: number, repeatable: boolean, progress: Function): string;

/**
 * Independent check of a layout against a request.
 */
export function validate(library_json: string, request_json: string, layout_json: string): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly decode_drawing: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly estimate_sheets: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly export_sheet: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number) => [number, number, number, number];
    readonly import_files: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly import_files_with_options: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly import_sheet: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly inspect_files: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly inspect_job: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly memory_bytes: () => number;
    readonly nest: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: any) => [number, number, number, number];
    readonly nest_job: (a: number, b: number, c: number, d: number, e: number, f: any) => [number, number, number, number];
    readonly validate: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
