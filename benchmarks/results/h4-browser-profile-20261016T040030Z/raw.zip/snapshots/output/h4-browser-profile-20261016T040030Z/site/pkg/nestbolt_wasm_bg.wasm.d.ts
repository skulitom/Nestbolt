/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const decode_drawing: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const estimate_sheets: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const export_sheet: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number) => [number, number, number, number];
export const import_files: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const import_files_with_options: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const import_sheet: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
export const inspect_files: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const inspect_job: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const memory_bytes: () => number;
export const nest: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: any) => [number, number, number, number];
export const nest_job: (a: number, b: number, c: number, d: number, e: number, f: any) => [number, number, number, number];
export const validate: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
