"""Four distinct restricted whole-group completion models, built before solving."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import gzip,json,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
CENSUS=ROOT/'output/h5-frame-availability-20261020/final-census'
OUT=ROOT/'output/h5-availability-completion-20261020'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[CENSUS/n for n in ['plan.json','checks.json','groups.json','pairs.json','remaining.json']]
    inputs += [SRC/n for n in ['candidates.json','job.json','cog-skeletons.json','mapping.json','projected-cliques.jsonl.gz','selected-indices.json','audit/checks.json','conditional-target.json']]
    cases=load(CENSUS/'remaining.json');groups=load(CENSUS/'groups.json');cogs=load(SRC/'cog-skeletons.json')['sets']
    assert len(cases)==4
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'cases':4,'seconds_per_case':20,'workers':8,'seed':0,
        'method':'Fix each of the four geometrically compatible complete 18-frame/15-cog pairs identified by the census. Select exactly 12 brackets and maximize inserts from zero to the original cap 21 using all surviving original poses and projected conflict cliques. Each distinct model is solved once for at most 20 solver seconds; no retry. Warm matching case receives the complete known 58-part hint, other cases receive no hint. All incumbent indices and failures are retained.',
        'scope':'Restricted conditional models; no global impossibility claim. Quantities below 21 inserts have no full-job credit. No area capacity is required for exact non-overlapping whole poses.',
        'native_packing_calls':0,'quality_runs':0})
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[json.loads(l) for l in f]
    pool=load(SRC/'candidates.json');warm=set(load(SRC/'selected-indices.json'))
    prepared=[]
    for case,r in enumerate(cases):
        dest=OUT/f'case-{case}';dest.mkdir()
        fixed=sorted(groups[r['frame_group']]['candidates']+cogs[r['cog_group']]['candidates'])
        ids=sorted(r['remaining_candidates']['bracket']+r['remaining_candidates']['insert'])
        model=cp_model.CpModel();variables={i:model.new_bool_var(f'p{i}') for i in ids}
        rows=sorted(set(tuple(sorted(set(clique)&variables.keys())) for clique in cliques))
        rows=[row for row in rows if len(row)>1]
        for row in rows:model.add_at_most_one(variables[i] for i in row)
        brackets=[variables[i] for i in ids if pool[i]['placement']['part_id']=='bracket']
        inserts=[variables[i] for i in ids if pool[i]['placement']['part_id']=='insert']
        model.add(sum(brackets)==12);model.add(sum(inserts)<=21);model.maximize(sum(inserts))
        hint=set(fixed)<=warm and warm-set(fixed)<=variables.keys()
        if hint:
            for i,var in variables.items():model.add_hint(var,int(i in warm))
        assert model.validate()==''
        model.export_to_file(str(dest/'model.pbtxt'))
        solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=20
        solver.parameters.num_search_workers=8;solver.parameters.random_seed=0
        solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
        (dest/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
        write(dest/'mapping.json',{'frame_group':r['frame_group'],'cog_group':r['cog_group'],
            'fixed_candidates':fixed,'candidates':ids,'complete_hint':hint})
        with gzip.open(dest/'cliques.jsonl.gz','wt',encoding='utf-8',newline='\n') as f:
            for row in rows:f.write(json.dumps(row)+'\n')
        prepared.append({'case':case,'variables':len(ids),'cliques':len(rows),'complete_hint':hint,
            'model_sha256':digest(dest/'model.pbtxt'),'parameters_sha256':digest(dest/'parameters.pbtxt')})
    write(OUT/'prepared.json',prepared);print(json.dumps(prepared),flush=True)
if __name__=='__main__':main()
