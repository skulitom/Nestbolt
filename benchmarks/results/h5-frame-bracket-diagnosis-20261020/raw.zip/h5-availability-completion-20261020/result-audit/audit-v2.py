"""Check every returned incumbent in original geometry and the frozen public validator."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import json,copy,math,subprocess,shutil,gzip
from audit_h5_cog_lattices import shape,load,digest,write
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-availability-completion-20261020'
SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
def main():
    out=RUN/'result-audit';out.mkdir(exist_ok=True);shutil.copyfile(__file__,out/'audit-v2.py')
    for p,h in load(RUN/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    required=Counter({p['id']:p['quantity'] for p in job['parts']});target=load(SRC/'conditional-target.json')
    stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance']
    sheets=load(SRC/'selected-layout.json')['sheets'];records=[];case_results=[]
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    for result in load(RUN/'results.json'):
        case=result['case'];source=RUN/f'case-{case}';dest=out/f'case-{case}';dest.mkdir(exist_ok=True)
        mp=load(source/'mapping.json');assert result['model_sha256']==digest(source/'model.pbtxt')
        if not result['feasible']:
            assert result['incumbents']==0 and not (source/'selected-indices.json').exists()
            case_results.append({'case':case,'frame_group':mp['frame_group'],'cog_group':mp['cog_group'],
                'seconds':result['seconds'],'solver_status':result['status'],'has_layout':False})
            continue
        with gzip.open(source/'cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
        previous=-1
        outcomes=[(k,load(source/f'incumbent-{k}.json')) for k in range(result['incumbents'])]
        final_ids=load(source/'selected-indices.json')
        if final_ids!=outcomes[-1][1]['selected_indices']:
            outcomes.append(('final',{'selected_indices':final_ids,'inserts':result['inserts'],'objective':result['inserts']}))
        for k,inc in outcomes:
            ids=inc['selected_indices'];selected=set(ids)
            assert len(selected)==len(ids) and set(mp['fixed_candidates'])<=selected
            assert selected-set(mp['fixed_candidates'])<=set(mp['candidates'])
            assert all(len(c&selected)<=1 for c in cliques)
            assert inc['inserts']>previous if k!='final' else inc['inserts']==previous
            previous=inc['inserts']
            counts=Counter();placements=[];geometries=defaultdict(list);tops=Counter()
            for i in ids:
                p=copy.deepcopy(pool[i]['placement']);part=parts[p['part_id']];t=p['transform']
                p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1;placements.append(p)
                assert not t['mirrored'] or part['allow_mirror']
                if part['rotations']['kind']=='list':
                    assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
                g=shape(part,t);x0,y0,x1,y1=g.bounds
                top=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
                assert g.is_valid and x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7
                assert x1<=stock['width']-m['right']-edge+1e-7 and y1<=top-m['top']-edge+1e-7
                geometries[p['sheet_id']].append(g);tops[p['sheet_id']]=max(tops[p['sheet_id']],y1+m['top']+edge)
            assert counts==Counter(frame=18,cog=15,bracket=12,insert=inc['inserts'])
            assert 0<=inc['inserts']<=21 and inc['objective']==inc['inserts']
            pairs=0;minimum=math.inf
            for group in geometries.values():
                for a,b in combinations(group,2):
                    pairs+=1;distance=a.distance(b);minimum=min(minimum,distance)
                    assert a.disjoint(b) and distance>=job['clearance']-1e-7
            path=dest/f'layout-{k}.json';layout={'version':1,'units':'mm','sheets':sheets,'placements':placements}
            if path.exists():assert load(path)==layout
            else:write(path,layout)
            material=stock['width']*(stock['height']+tops['sheet-1'])
            assert material<=target['target_material_mm2']+1e-6
            cmd=[str(cli),'validate','--library',str(SRC/'library.json'),'--request',str(SRC/'request.json'),'--layout',str(path)]
            command_path=dest/f'command-{k}.json'
            if command_path.exists():
                saved=load(command_path);assert saved['command']==cmd
                assert (dest/f'public-{k}.stderr').exists()
                returncode=saved['exit_code'];report=load(dest/f'public-{k}.json')
            else:
                cp=subprocess.run(cmd,capture_output=True,timeout=60);returncode=cp.returncode
                (dest/f'public-{k}.json').write_bytes(cp.stdout);(dest/f'public-{k}.stderr').write_bytes(cp.stderr)
                write(command_path,{'command':cmd,'exit_code':cp.returncode});report=json.loads(cp.stdout)
            missing=required-counts
            assert report['valid']==(not missing)
            if missing:
                assert returncode!=0
                assert report['violations']==[{'code':'quantity','message':f"part insert: expected 21, found {inc['inserts']}"}]
            else:
                assert returncode==0 and report['violations']==[]
            records.append({'case':case,'incumbent':k,'inserts':inc['inserts'],'pairs':pairs,
                'minimum_distance_mm':minimum,'missing':dict(missing),
                'filled_area_mm2':sum(g.area for group in geometries.values() for g in group),
                'charged_material_mm2':material,'frozen_CLI_quantity_only_failure':bool(missing),'full_original_job_valid':not missing})
        assert result['status'] in ['OPTIMAL','FEASIBLE'] and result['inserts']==previous<=result['best_bound']
        if result['status']=='OPTIMAL':assert previous==result['best_bound']
        assert final_ids==outcomes[-1][1]['selected_indices']
        case_results.append({'case':case,'frame_group':mp['frame_group'],'cog_group':mp['cog_group'],
            'seconds':result['seconds'],'solver_status':result['status'],'inserts':previous,'missing_inserts':21-previous,
            'status_scope':'Solver-reported optimum of this fixed-group finite-pose subproblem; no independent infeasibility certificate or unrestricted claim.'})
    check={'all_returned_layouts_checked':len(records),'callback_incumbents_checked':sum(isinstance(r['incumbent'],int) for r in records),
        'distinct_final_layouts_also_checked':sum(r['incumbent']=='final' for r in records),'cases':case_results,'incumbents':records,
        'all_original_geometry_checks_pass':True,'all_frozen_CLI_failures_are_original_quantity_only':True,
        'improved_partial':max((r['inserts'] for r in records),default=0)>13,'full_target_witness':any(r['full_original_job_valid'] for r in records),
        'native_margin_qualified':False,'native_packing_calls':0,'quality_runs':0}
    write(out/'checks.json',check)
    print(json.dumps({k:v for k,v in check.items() if k!='incumbents'}),flush=True)
if __name__=='__main__':main()
