"""Reconstruct all frame-only models and heuristic costs from original cliques."""
from pathlib import Path
import gzip,json,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from build_h5_frame_availability import ROOT,SRC,CENSUS,OUT,load,write,digest
def main():
    shutil.copyfile(__file__,OUT/'audit-model.py')
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');mapping={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:original=[set(json.loads(l)) for l in f]
    groups=load(CENSUS/'groups.json');records=[]
    for row in load(OUT/'prepared.json'):
        case=row['case'];dest=OUT/f'case-{case}';mp=load(dest/'mapping.json')
        assert digest(dest/'model.pbtxt')==row['model_sha256']
        eligible={i for i,r in mapping.items() if case in r['compatible_skeletons']}
        ids=sorted(i for i in eligible if pool[i]['placement']['part_id']=='frame');assert ids==mp['candidates']
        br={i for i in eligible if pool[i]['placement']['part_id']=='bracket'}
        ins={i for i in eligible if pool[i]['placement']['part_id']=='insert'}
        assert len(br)==mp['eligible_brackets'] and len(ins)==mp['eligible_inserts']
        owners={i:[] for i in ids}
        for ci,clique in enumerate(original):
            for i in clique&owners.keys():owners[i].append(ci)
        scores=[]
        for i in ids:
            blocked=set().union(*(original[ci] for ci in owners[i]))
            scores.append({'candidate':i,'blocked_brackets':len(blocked&br),'blocked_inserts':len(blocked&ins),
                'cost':len(blocked&br)*len(ins)+len(blocked&ins)*len(br)})
        assert scores==mp['scores']
        excluded=[g['candidates'] for g in groups if set(g['candidates'])<=set(ids)]
        assert excluded==mp['excluded_frame_sets']
        local={i:j for j,i in enumerate(ids)}
        projected=sorted({tuple(sorted(c&local.keys())) for c in original if len(c&local.keys())>1})
        expected=cp_model_pb2.CpModelProto()
        for i in ids:v=expected.variables.add();v.name=f'p{i}';v.domain.extend([0,1])
        for clique in projected:
            expected.constraints.add().at_most_one.literals.extend(local[i] for i in clique)
        c=expected.constraints.add().linear;c.vars.extend(range(len(ids)));c.coeffs.extend([1]*len(ids));c.domain.extend([18,18])
        for group in excluded:
            c=expected.constraints.add().linear;c.vars.extend(local[i] for i in group);c.coeffs.extend([1]*18);c.domain.extend([-(2**63),17])
        nonzero=[(j,r['cost']) for j,r in enumerate(scores) if r['cost']]
        expected.objective.vars.extend(j for j,c in nonzero);expected.objective.coeffs.extend(c for j,c in nonzero)
        expected.objective.scaling_factor=1
        actual=text_format.Parse((dest/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
        assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
        records.append({'case':case,'variables':len(ids),'cliques':len(projected),'excluded_sets':len(excluded),
            'model_exactly_reconstructed':True,'costs_independently_recomputed':True})
    write(OUT/'model-audit.json',{'cases':records,'all_models_exact':True,'cost_is_heuristic_only':True})
    print(json.dumps(records),flush=True)
if __name__=='__main__':main()
