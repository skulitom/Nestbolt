"""Frame-only CP construction scored by how few smaller-part poses it obstructs."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import gzip,json,shutil
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
CENSUS=ROOT/'output/h5-whole-frame-census-20261020';OUT=ROOT/'output/h5-frame-availability-20261020'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[SRC/n for n in ['job.json','candidates.json','mapping.json','cog-skeletons.json','projected-cliques.jsonl.gz',
        'audit/checks.json','conditional-target.json']]
    inputs += [CENSUS/'groups.json',ROOT/'output/h5-novel-whole-frames-20261020/result-audit.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'cases':[0,1,2,3],'seconds_per_case':10,'workers':8,'seed':0,
        'method':'Select exactly 18 whole frames compatible with one fixed original 15-cog arrangement. Preserve every projected frame/frame conflict and exclude all 26 reviewed exact frame sets. Minimize the sum, over selected frames, of (blocked bracket poses * total eligible insert poses + blocked insert poses * total eligible bracket poses). This integer score is proportional to the sum of normalized blocked fractions; overlapping blocked sets may count repeatedly. It is a heuristic, not an area or fit guarantee. No bracket or insert is physically selected in this stage.',
        'followup':'Retain all incumbents and each final frame set. Only the final set from each case, at most four distinct frame/cog pairs, may enter one exact 20-second bracket/insert completion run each. No restart of an expired case.',
        'full_job_acceptance':'Unchanged original 66-copy job and stock target. Full geometry, frozen validator, native margins and H5 gates remain required.',
        'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');mp=load(SRC/'mapping.json');mapping={r['candidate']:r for r in mp['candidates']}
    frameids={i for i in mapping if pool[i]['placement']['part_id']=='frame'}
    smallids=set(mapping)-frameids;neighbors={i:set() for i in frameids}
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    for clique in cliques:
        for i in clique&frameids:neighbors[i].update(clique&smallids)
    groups=load(CENSUS/'groups.json');prepared=[]
    for case in range(4):
        dest=OUT/f'case-{case}';dest.mkdir()
        ids=sorted(i for i in frameids if case in mapping[i]['compatible_skeletons'])
        br={i for i in smallids if pool[i]['placement']['part_id']=='bracket' and case in mapping[i]['compatible_skeletons']}
        ins={i for i in smallids if pool[i]['placement']['part_id']=='insert' and case in mapping[i]['compatible_skeletons']}
        score=[{'candidate':i,'blocked_brackets':len(neighbors[i]&br),'blocked_inserts':len(neighbors[i]&ins),
            'cost':len(neighbors[i]&br)*len(ins)+len(neighbors[i]&ins)*len(br)} for i in ids]
        rows=sorted({tuple(sorted(c&set(ids))) for c in cliques if len(c&set(ids))>1})
        excluded=[g['candidates'] for g in groups if set(g['candidates'])<=set(ids)]
        model=cp_model.CpModel();variables={i:model.new_bool_var(f'p{i}') for i in ids}
        for row in rows:model.add_at_most_one(variables[i] for i in row)
        model.add(sum(variables.values())==18)
        for group in excluded:model.add(sum(variables[i] for i in group)<=17)
        model.minimize(sum(r['cost']*variables[r['candidate']] for r in score))
        assert model.validate()=='';model.export_to_file(str(dest/'model.pbtxt'))
        write(dest/'mapping.json',{'case':case,'candidates':ids,'scores':score,
            'eligible_brackets':len(br),'eligible_inserts':len(ins),'excluded_frame_sets':excluded})
        solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=10
        solver.parameters.num_search_workers=8;solver.parameters.random_seed=0
        solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
        (dest/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
        prepared.append({'case':case,'variables':len(ids),'conflict_cliques':len(rows),'excluded_sets':len(excluded),
            'model_sha256':digest(dest/'model.pbtxt'),'parameters_sha256':digest(dest/'parameters.pbtxt')})
    write(OUT/'prepared.json',prepared);print(json.dumps(prepared),flush=True)
if __name__=='__main__':main()
