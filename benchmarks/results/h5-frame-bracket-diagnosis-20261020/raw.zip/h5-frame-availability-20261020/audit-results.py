"""Check all frame proposals and freeze at most four final completion cases."""
from pathlib import Path
from collections import defaultdict,Counter
from itertools import combinations
from datetime import datetime,timezone
import gzip,json,math,shutil
from audit_h5_cog_lattices import shape,load,write,digest
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
OUT=ROOT/'output/h5-frame-availability-20261020';CENSUS=OUT/'final-census'
def main():
    shutil.copyfile(__file__,OUT/'audit-results.py')
    plan=load(OUT/'plan.json')
    for p,h in plan['inputs'].items():assert digest(ROOT/p)==h
    pool=load(SRC/'candidates.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    mp={r['candidate']:r for r in load(SRC/'mapping.json')['candidates']}
    old={tuple(g['candidates']) for g in load(ROOT/'output/h5-whole-frame-census-20261020/groups.json')}
    cogs=load(SRC/'cog-skeletons.json')['sets'];stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance']
    target=load(SRC/'conditional-target.json');checks=[];finals=[]
    with gzip.open(SRC/'projected-cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[set(json.loads(l)) for l in f]
    for result in load(OUT/'results.json'):
        case=result['case'];dest=OUT/f'case-{case}';mapping=load(dest/'mapping.json')
        if not result['feasible']:continue
        final=load(dest/'frame-candidates.json')
        candidates=[load(dest/f'incumbent-{i}.json') for i in range(result['incumbents'])]
        if final!=candidates[-1]['frame_candidates']:
            candidates.append({'index':'final','frame_candidates':final,'heuristic_cost':result['heuristic_cost']})
        costs={r['candidate']:r['cost'] for r in mapping['scores']}
        for saved in candidates:
            ids=saved['frame_candidates'];assert len(ids)==len(set(ids))==18
            assert tuple(ids) not in old and set(ids)<=set(mapping['candidates'])
            assert sum(costs[i] for i in ids)==saved['heuristic_cost']
            assert all(len(set(ids)&c)<=1 for c in cliques)
            geometries=defaultdict(list)
            for i in ids+cogs[case]['candidates']:
                p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform']
                assert not t['mirrored'] or part['allow_mirror']
                if part['rotations']['kind']=='list':
                    assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
                g=shape(part,t);x0,y0,x1,y1=g.bounds
                h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
                assert g.is_valid and x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7
                assert x1<=stock['width']-m['right']-edge+1e-7 and y1<=h-m['top']-edge+1e-7
                geometries[p['sheet_id']].append(g)
            pairs=0;minimum=math.inf
            for gs in geometries.values():
                for a,b in combinations(gs,2):
                    pairs+=1;distance=a.distance(b);minimum=min(minimum,distance)
                    assert a.disjoint(b) and distance>=job['clearance']-1e-7
            checks.append({'case':case,'incumbent':saved['index'],'pairs':pairs,'minimum_distance_mm':minimum,
                'heuristic_cost':saved['heuristic_cost']})
        assert result['status']=='OPTIMAL' and result['heuristic_cost']==result['best_cost_bound']
        finals.append({'case':case,'frames':final,'heuristic_cost':result['heuristic_cost']})
    audit={'all_returned_frame_layouts_checked':len(checks),'records':checks,'final_cases':len(finals),
        'full_target_witness':False,'native_margin_qualified':False,'only_frames_and_cogs_physically_placed':True}
    write(OUT/'result-audit.json',audit)
    CENSUS.mkdir();groups=[];pairs=[];remaining=[]
    for item in finals:
        ids=item['frames'];case=item['case']
        matching=[g for g in groups if g['candidates']==ids]
        if matching:gi=matching[0]['index']
        else:
            gi=len(groups);groups.append({'index':gi,'candidates':ids,'sources':[f'frame-availability-case-{case}']})
        blocked=set()
        for clique in cliques:
            if clique&set(ids):blocked.update(clique-set(ids))
        available={family:sorted(i for i,r in mp.items() if pool[i]['placement']['part_id']==family
            and case in r['compatible_skeletons'] and i not in blocked) for family in ['bracket','insert']}
        row={'frame_group':gi,'cog_group':case,'remaining_candidates':available,
            'counts':{f:len(v) for f,v in available.items()}}
        row['passes_trivial_quantity_check']=all(row['counts'][f]>=parts[f]['quantity'] for f in available)
        assert row['passes_trivial_quantity_check']
        remaining.append(row);pairs.append({'frame_group':gi,'cog_group':case,'compatible':True})
    write(CENSUS/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'source_audit_sha256':digest(OUT/'result-audit.json'),
        'source_plan_sha256':digest(OUT/'plan.json'),
        'method':'Exactly one final novel complete frame set per declared cog case. Surviving smaller-part poses are projected from the original audited conflicts; no additional pose generation.'})
    write(CENSUS/'groups.json',groups);write(CENSUS/'pairs.json',pairs);write(CENSUS/'remaining.json',remaining)
    write(CENSUS/'checks.json',{'final_cases':len(finals),'distinct_frame_sets':len(groups),
        'all_original_geometry_checked':True,'full_target_witness':False})
    print(json.dumps({'frame_layouts_checked':len(checks),'final_cases':len(finals),'distinct_frame_sets':len(groups),
        'remaining_counts':[r['counts'] for r in remaining]}),flush=True)
if __name__=='__main__':main()
