"""Reuse the sealed whole-group checker with explicit, recorded scope changes."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-availability-completion-adapter-20261020'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'adapt.py')
    manifest=json.loads((ROOT/'benchmarks/results/h5-whole-group-diagnosis-20261020/raw-manifest.json').read_bytes())
    hashes={r['path']:r['sha256'] for r in manifest['files']}
    specs=[
        ('prepare_h5_whole_group_selection.py','prepare_h5_availability_completion.py',[
            ("assert len(cases)==6","assert len(cases)==4"),
            ("'cases':6","'cases':4"),
            ("each of the six geometrically compatible","each of the four geometrically compatible")]),
        ('audit_h5_whole_group_models.py','audit_h5_availability_completion_model.py',[
            ('all_six_models_reconstructed_in_full','all_completion_models_reconstructed_in_full')]),
        ('solve_h5_whole_groups.py','solve_h5_availability_completion.py',[
            ('from prepare_h5_whole_group_selection import','from prepare_h5_availability_completion import'),
            ('all_six_models_reconstructed_in_full','all_completion_models_reconstructed_in_full')]),
        ('audit_h5_whole_group_results.py','audit_h5_availability_completion_results.py',[
            ("mp=load(source/'mapping.json');assert result['model_sha256']==digest(source/'model.pbtxt')",
             """mp=load(source/'mapping.json');assert result['model_sha256']==digest(source/'model.pbtxt')
        if not result['feasible']:
            assert result['incumbents']==0 and not (source/'selected-indices.json').exists()
            case_results.append({'case':case,'frame_group':mp['frame_group'],'cog_group':mp['cog_group'],
                'seconds':result['seconds'],'solver_status':result['status'],'has_layout':False})
            continue"""),
            ("assert missing and not report['valid'] and returncode!=0\n            assert report['violations']==[{'code':'quantity','message':f\"part insert: expected 21, found {inc['inserts']}\"}]",
             """assert report['valid']==(not missing)
            if missing:
                assert returncode!=0
                assert report['violations']==[{'code':'quantity','message':f"part insert: expected 21, found {inc['inserts']}"}]
            else:
                assert returncode==0 and report['violations']==[]"""),
            ("'frozen_CLI_quantity_only_failure':True","'frozen_CLI_quantity_only_failure':bool(missing),'full_original_job_valid':not missing"),
            ("assert result['status']=='OPTIMAL' and result['inserts']==previous==result['best_bound']",
             """assert result['status'] in ['OPTIMAL','FEASIBLE'] and result['inserts']==previous<=result['best_bound']
        if result['status']=='OPTIMAL':assert previous==result['best_bound']"""),
            ("max(r['inserts'] for r in records)>13","max((r['inserts'] for r in records),default=0)>13"),
            ("'full_target_witness':False","'full_target_witness':any(r['full_original_job_valid'] for r in records)")])
    ]
    records=[]
    for old,new,changes in specs:
        source=ROOT/'output'/old;raw=source.read_bytes()
        assert sha256(raw).hexdigest()==hashes['helpers/'+old]
        shutil.copyfile(source,OUT/old);text=raw.decode()
        common=[
            ("output/h5-whole-frame-census-20261020","output/h5-frame-availability-20261020/final-census"),
            ("output/h5-whole-group-selection-20261020","output/h5-availability-completion-20261020")]
        for before,after in common:
            text=text.replace(before,after)
        for before,after in changes:
            assert text.count(before)==1,(old,before,text.count(before))
            text=text.replace(before,after)
        if new.startswith('prepare_'):
            text=text.replace('Six distinct restricted','Four distinct restricted')
        path=ROOT/'output'/new
        with path.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
        records.append({'original':old,'original_sha256':sha256(raw).hexdigest(),'adapted':new,
            'adapted_sha256':sha256(path.read_bytes()).hexdigest(),'replacements':common+changes})
    (OUT/'adaptations.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'sealed_template_hashes_verified':True,'adapted_scripts':len(records)}),flush=True)
if __name__=='__main__':main()
