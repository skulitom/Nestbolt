"""Audit a continuous translation of the saved CP model, then compare area cuts."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import gzip,json,math,re,shutil,time,warnings
import numpy as np
import scipy
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-area-capacities-20261020'
SRC=ROOT/'output/h5-skeleton-contact-selection-20261020'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rows(path):
    with gzip.open(path,'rt',encoding='utf-8') as f:return [json.loads(line) for line in f]
def canonical(row):return (tuple(sorted(zip(row['indices'],row['coeffs']))),row['rhs'])
def matrix(rows,n):
    r=[];c=[];v=[]
    for ri,row in enumerate(rows):
        assert len(set(row['indices']))==len(row['indices']) and len(row['indices'])==len(row['coeffs'])
        r.extend([ri]*len(row['indices']));c.extend(row['indices']);v.extend(row['coeffs'])
    return coo_matrix((np.asarray(v,dtype=float),(r,c)),shape=(len(rows),n)).tocsr()

def audit_model(ub,eq,obj,warm):
    prep=load(OUT/'preparation.json')
    for name,h in prep['prepared_hashes'].items():assert digest(OUT/name)==h
    for name,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
    text=(SRC/'model.pbtxt').read_text(encoding='utf-8');parse=lambda s:json.loads('['+s+']')
    vp=r'variables\s*\{\s*name:\s*"(skeleton-\d+|p\d+)"\s*domain:\s*\[0, 1\]\s*\}'
    names=re.findall(vp,text);assert len(names)==len(obj)==len(warm)
    ep=r'constraints\s*\{\s*exactly_one\s*\{\s*literals:\s*\[([^\]]*)\]\s*\}\s*\}'
    ap=r'constraints\s*\{\s*at_most_one\s*\{\s*literals:\s*\[([^\]]*)\]\s*\}\s*\}'
    lp=r'constraints\s*\{\s*linear\s*\{\s*vars:\s*\[([^\]]*)\]\s*coeffs:\s*\[([^\]]*)\]\s*domain:\s*\[([^\]]*)\]\s*\}\s*\}'
    expected_eq=Counter();expected_ub=Counter()
    for s in re.findall(ep,text,re.S):expected_eq[(tuple((i,1) for i in sorted(parse(s))),1)]+=1
    for s in re.findall(ap,text,re.S):expected_ub[(tuple((i,1) for i in sorted(parse(s))),1)]+=1
    for a,c,d in re.findall(lp,text,re.S):
        terms=tuple(sorted(zip(parse(a),parse(c))));lo,hi=parse(d)
        if lo==hi:expected_eq[(terms,lo)]+=1
        else:
            if hi<9223372036854775807:expected_ub[(terms,hi)]+=1
            if lo>-9223372036854775808:expected_ub[(tuple((i,-c) for i,c in terms),-lo)]+=1
    assert Counter(map(canonical,ub))==expected_ub and Counter(map(canonical,eq))==expected_eq
    hp=r'solution_hint\s*\{\s*vars:\s*\[([^\]]*)\]\s*values:\s*\[([^\]]*)\]\s*\}'
    hints=re.findall(hp,text,re.S);assert len(hints)==1 and parse(hints[0][0])==list(range(len(obj))) and parse(hints[0][1])==warm
    op=r'objective\s*\{\s*vars:\s*\[([^\]]*)\]\s*scaling_factor:\s*(-?[0-9.]+)\s*coeffs:\s*\[([^\]]*)\]\s*\}'
    objectives=re.findall(op,text,re.S);assert len(objectives)==1
    ids,scale,coeffs=objectives[0];assert float(scale)==-1;expected=[0]*len(obj)
    for i,c in zip(parse(ids),parse(coeffs)):expected[i]=c
    assert expected==obj
    rest=text
    for pattern in [vp,ep,ap,lp,hp,op]:rest=re.sub(pattern,'',rest,flags=re.S)
    assert not rest.strip()
    write(OUT/'translation-audit.json',{'all_original_model_fields_consumed':True,'variable_bounds':[0,1],
        'original_model_sha256':digest(SRC/'model.pbtxt'),'objective_exact':True,
        'inequalities':len(ub),'equalities':len(eq),'only_integrality_relaxed':True,
        'area_coefficient_rational_audit':prep})

def exact_upper_bound(obj,ub,eq,ymarg,zmarg):
    # For min c*x with A*x<=b, E*x=d, 0<=x<=1, any y<=0,z gives
    # lower bound y*b+z*d+sum(min(0,c-A'*y-E'*z)).
    # All coefficients are integers; binary64 multipliers are exact dyadic rationals.
    y=[min(0.,float(v)) for v in ymarg];z=[float(v) for v in zmarg]
    assert all(math.isfinite(v) for v in y+z)
    ratios=[v.as_integer_ratio() for v in y+z];den=max(d for n,d in ratios)
    numer=[n*(den//d) for n,d in ratios];assert all(den%d==0 for n,d in ratios)
    residual=[c*den for c in obj];value=0
    for weight,row in zip(numer,ub+eq):
        value+=weight*row['rhs']
        for i,c in zip(row['indices'],row['coeffs']):residual[i]-=weight*c
    lower=value+sum(min(0,v) for v in residual)
    upper=Fraction(-lower,den)
    return {'numerator':str(upper.numerator),'denominator':str(upper.denominator),
            'upper_bound_inserts':float(upper),'integer_insert_upper_bound':upper.numerator//upper.denominator,
            'dual_inequality_signs_clamped_nonpositive':True,'exact_integer_arithmetic':True}

def main():
    shutil.copyfile(__file__,OUT/'solve.py')
    ub=rows(OUT/'inequalities.jsonl.gz');eq=rows(OUT/'equalities.jsonl.gz');cuts=rows(OUT/'area-cuts.jsonl.gz')
    obj=load(OUT/'objective.json');warm=load(OUT/'warm.json');audit_model(ub,eq,obj,warm)
    n=len(obj);eqmatrix=matrix(eq,n);eqrhs=np.asarray([r['rhs'] for r in eq],dtype=float);summary=[]
    for name,additional in [('original',[]),('with-area',cuts)]:
        path=OUT/name;path.mkdir();current=ub+additional;A=matrix(current,n);b=np.asarray([r['rhs'] for r in current],dtype=float)
        write(path/'started.json',{'utc':datetime.now(timezone.utc).isoformat(),'rows':len(current),'seconds_limit':120,'scipy':scipy.__version__})
        print('Starting '+name+' continuous relaxation',flush=True)
        start=time.perf_counter()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            result=linprog(np.asarray(obj,dtype=float),A_ub=A,b_ub=b,A_eq=eqmatrix,b_eq=eqrhs,bounds=(0,1),method='highs-ds',
                options={'time_limit':120.,'presolve':True,'threads':8,'random_seed':0})
        seconds=time.perf_counter()-start
        record={'scenario':name,'status':int(result.status),'success':bool(result.success),'message':result.message,
            'seconds':seconds,'iterations':int(result.nit),'warnings':[str(w.message) for w in caught],
            'fractional_relaxation_only':True,'physical_layout_found':False}
        if result.x is not None:
            x=result.x;record.update(objective_inserts=float(-result.fun),fractional_variables=int(np.count_nonzero((x>1e-7)&(x<1-1e-7))),
                max_inequality_violation=float(max(0,np.max(A@x-b))),max_equality_violation=float(np.max(np.abs(eqmatrix@x-eqrhs))),
                max_bound_violation=float(max(0,-np.min(x),np.max(x)-1)),
                original_warm_objective=float(-np.dot(obj,warm)))
            assert record['max_inequality_violation']<1e-5 and record['max_equality_violation']<1e-5 and record['max_bound_violation']<1e-6
            np.savez_compressed(path/'solution.npz',x=x,inequality_marginals=result.ineqlin.marginals,equality_marginals=result.eqlin.marginals)
            if result.success:
                certificate=exact_upper_bound(obj,current,eq,result.ineqlin.marginals,result.eqlin.marginals)
                assert certificate['upper_bound_inserts']>=record['objective_inserts']-1e-5
                write(path/'exact-bound.json',certificate);record['exact_bound']=certificate
        write(path/'result.json',record);summary.append(record);print(json.dumps(record),flush=True)
    write(OUT/'results.json',summary)
if __name__=='__main__':main()
