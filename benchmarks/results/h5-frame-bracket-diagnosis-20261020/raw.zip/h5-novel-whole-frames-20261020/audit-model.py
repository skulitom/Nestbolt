"""Independent checks of every modification to the previously audited LP rows."""
from pathlib import Path
import json,shutil
import solve_h5_area_relaxations as base
ROOT=base.ROOT;SRC=base.SRC;CAP=base.OUT
OUT=ROOT/'output/h5-novel-whole-frames-20261020'
CENSUS=ROOT/'output/h5-whole-frame-census-20261020'
load=base.load;write=base.write;digest=base.digest
def main():
    shutil.copyfile(__file__,OUT/'audit-model.py')
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    for p,h in load(OUT/'prepared.json')['hashes'].items():assert digest(OUT/p)==h
    pool=load(SRC/'candidates.json');mapping=load(SRC/'mapping.json')
    inverse={r['var']:r['candidate'] for r in mapping['candidates']};vi={i:v for v,i in inverse.items()}
    old=base.rows(CAP/'inequalities.jsonl.gz')+base.rows(CAP/'area-cuts.jsonl.gz')
    actual=base.rows(OUT/'inequalities.jsonl.gz');change=load(OUT/'row-change.json')
    assert old[change['row']]['kind']=='minimum-inserts' and old[change['row']]['rhs']==change['original_rhs']==-13
    assert change['new_rhs']==-21
    assert actual[change['row']]['rhs']==-21
    prefix=json.loads(json.dumps(actual[:len(old)]));prefix[change['row']]['rhs']=-13;assert prefix==old
    assert base.rows(OUT/'equalities.jsonl.gz')==base.rows(CAP/'equalities.jsonl.gz')
    expected=[];row=len(old)
    for group,record in zip(load(CENSUS/'groups.json'),load(OUT/'excluded-groups.json')):
        assert record['group']==group['index'] and len(group['candidates'])==18
        missing=sorted(set(group['candidates'])-vi.keys());assert record['missing_model_candidates']==missing
        if missing:assert record['row'] is None;continue
        assert record['row']==row;row+=1
        expected.append({'kind':'exclude-reviewed-frame-set','group':group['index'],
            'indices':[vi[i] for i in group['candidates']],'coeffs':[1]*18,'rhs':17})
    assert actual[len(old):]==expected and len(load(OUT/'excluded-groups.json'))==26
    integer=load(OUT/'integrality.json');n=len(load(CAP/'objective.json'))
    assert len(integer)==n and all(value==int(j in inverse and pool[inverse[j]]['placement']['part_id']=='frame') for j,value in enumerate(integer))
    assert mapping['options']==[0,1,2,3]
    bounds=load(OUT/'bounds.json');assert [b['case'] for b in bounds]==[0,1,2,3]
    for b in bounds:
        si=b['case'];assert len(b['lower'])==len(b['upper'])==n
        for j in range(n):
            if j<4:assert b['lower'][j]==b['upper'][j]==int(j==si)
            else:
                assert b['lower'][j]==0
                r=next_row[j]
                assert b['upper'][j]==int(si in r['compatible_skeletons'])
    write(OUT/'model-audit.json',{'all_source_hashes_verified':True,'original_rows_preserved_except_declared_insert_lower_bound':True,
        'all_26_reviewed_frame_sets_excluded':True,'explicit_exclusion_rows':len(expected),
        'only_frame_variables_integral':True,'integer_frames':sum(integer),'four_cog_cases_bounds_exact':True,
        'zero_objective_declared':True,'physical_layout_found':False})
    print((OUT/'model-audit.json').read_text(),flush=True)
if __name__=='__main__':
    next_row={r['var']:r for r in load(SRC/'mapping.json')['candidates']}
    main()
