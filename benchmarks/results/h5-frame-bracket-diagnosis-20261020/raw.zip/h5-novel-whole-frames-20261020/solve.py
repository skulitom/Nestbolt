from pathlib import Path
from datetime import datetime,timezone
import json,shutil,time,warnings,traceback
import numpy as np
import scipy
from scipy.optimize import milp,Bounds,LinearConstraint
import solve_h5_area_relaxations as base
ROOT=base.ROOT;OUT=ROOT/'output/h5-novel-whole-frames-20261020';SRC=base.SRC
load=base.load;write=base.write;digest=base.digest
def main():
    assert load(OUT/'model-audit.json')['all_26_reviewed_frame_sets_excluded']
    shutil.copyfile(__file__,OUT/'solve.py');plan=load(OUT/'plan.json')
    for p,h in plan['inputs'].items():assert digest(ROOT/p)==h
    for p,h in load(OUT/'prepared.json')['hashes'].items():assert digest(OUT/p)==h
    ub=base.rows(OUT/'inequalities.jsonl.gz');eq=base.rows(OUT/'equalities.jsonl.gz')
    n=load(OUT/'prepared.json')['variables'];A=base.matrix(ub+eq,n).tocsc()
    A.indices=A.indices.astype(np.int32);A.indptr=A.indptr.astype(np.int32)
    upper=np.asarray([r['rhs'] for r in ub+eq],float)
    lower=np.asarray([-np.inf]*len(ub)+[r['rhs'] for r in eq],float)
    integer=np.asarray(load(OUT/'integrality.json'),dtype=np.uint8)
    mapping=load(SRC/'mapping.json');pool=load(SRC/'candidates.json');results=[]
    for bound in load(OUT/'bounds.json'):
        case=bound['case'];dest=OUT/f'case-{case}';dest.mkdir()
        write(dest/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'scipy':scipy.__version__,'seconds_limit':30})
        print(f'Starting new whole-frame case {case}',flush=True);start=time.perf_counter()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            result=milp(c=np.zeros(n),integrality=integer,bounds=Bounds(bound['lower'],bound['upper']),
                constraints=LinearConstraint(A,lower,upper),
                options={'time_limit':30.,'presolve':True,'threads':8,'random_seed':0,'mip_rel_gap':0.})
        record={'case':case,'status':int(result.status),'success':bool(result.success),'message':result.message,
            'seconds':time.perf_counter()-start,'warnings':[str(w.message) for w in caught],
            'mip_nodes':getattr(result,'mip_node_count',None),'has_solution':result.x is not None,
            'full_target_witness':False,'native_packing_calls':0,'quality_runs':0}
        if result.x is not None:
            x=result.x;np.savez_compressed(dest/'solution.npz',x=x)
            lhs=A@x
            record.update(max_row_violation=float(max(0,np.max(lhs-upper),np.max(lower-lhs))),
                max_bound_violation=float(max(0,np.max(np.asarray(bound['lower'])-x),np.max(x-np.asarray(bound['upper'])))),
                max_frame_integrality_residual=float(np.max(np.abs(x[integer==1]-np.rint(x[integer==1])))))
            assert record['max_row_violation']<1e-5 and record['max_bound_violation']<1e-6
            assert record['max_frame_integrality_residual']<1e-6
            ids=sorted(r['candidate'] for r in mapping['candidates'] if integer[r['var']] and x[r['var']]>.5)
            assert len(ids)==18
            write(dest/'frame-candidates.json',ids)
            record['fractional_smaller_part_variables']=sum(1 for r in mapping['candidates'] if not integer[r['var']] and 1e-7<x[r['var']]<1-1e-7)
        write(dest/'result.json',record);results.append(record);print(json.dumps(record),flush=True)
    write(OUT/'results.json',results)
if __name__=='__main__':
    try:main()
    except BaseException:
        if not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
