"""Freeze a mixed-integer construction: whole frames, relaxed smaller parts."""
from pathlib import Path
from datetime import datetime,timezone
import gzip,json,shutil
import numpy as np
import solve_h5_area_relaxations as base
ROOT=base.ROOT;SRC=base.SRC;CAP=base.OUT
CENSUS=ROOT/'output/h5-whole-frame-census-20261020'
OUT=ROOT/'output/h5-novel-whole-frames-20261020'
load=base.load;write=base.write;digest=base.digest
def save_rows(path,rows):
    with gzip.open(path,'wt',encoding='utf-8',newline='\n') as f:
        for r in rows:f.write(json.dumps(r,separators=(',',':'))+'\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[CAP/n for n in ['preparation.json','translation-audit.json','inequalities.jsonl.gz',
        'equalities.jsonl.gz','area-cuts.jsonl.gz','objective.json']]
    inputs += [SRC/n for n in ['job.json','candidates.json','mapping.json','cog-skeletons.json',
        'projected-cliques.jsonl.gz','audit/checks.json','conditional-target.json']]
    inputs += [CENSUS/n for n in ['groups.json','checks.json']]
    inputs += [ROOT/'benchmarks/results/h5-whole-group-diagnosis-20261020/checks.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'case_order':[0,1,2,3],'seconds_per_case':30,'workers':8,'seed':0,
        'method':'For each fixed original 15-cog arrangement, solve one feasibility MILP. Require exactly 18 integral frame poses; bracket and insert variables remain continuous in [0,1], with exact quantities 12 and 21. Keep original conflict cliques and audited local area capacities. Explicitly exclude every one of the 26 reviewed exact frame sets, either by a missing model pose or a sum<=17 row. Use zero objective; stop after the single bounded call per case. Preserve all statuses and any final solution vector. No suffix retry.',
        'conditional_followup':'Only a newly found complete frame set may enter a new exact bracket/insert completion model, bounded to 20 seconds per distinct frame/cog pair. Whole frames with fractional smaller parts are not a physical full layout.',
        'acceptance':'Original quantities, geometry, stock, margins and target are unchanged. Restricted infeasibility is not unrestricted impossibility. Full candidates require independent geometry and frozen CLI checks followed by native-margin and full H5 qualification.',
        'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');mp=load(SRC/'mapping.json');n=len(load(CAP/'objective.json'))
    variable={r['candidate']:r['var'] for r in mp['candidates']}
    ub=base.rows(CAP/'inequalities.jsonl.gz')+base.rows(CAP/'area-cuts.jsonl.gz')
    matches=[i for i,r in enumerate(ub) if r['kind']=='minimum-inserts'];assert len(matches)==1
    at=matches[0];assert ub[at]['rhs']==-13;ub[at]['rhs']=-21
    excluded=[]
    for g in load(CENSUS/'groups.json'):
        missing=sorted(set(g['candidates'])-variable.keys())
        if missing:excluded.append({'group':g['index'],'missing_model_candidates':missing,'row':None})
        else:
            row=len(ub);ub.append({'kind':'exclude-reviewed-frame-set','group':g['index'],
                'indices':[variable[i] for i in g['candidates']],'coeffs':[1]*18,'rhs':17})
            excluded.append({'group':g['index'],'missing_model_candidates':[],'row':row})
    eq=base.rows(CAP/'equalities.jsonl.gz')
    integer=[0]*n
    for r in mp['candidates']:
        if pool[r['candidate']]['placement']['part_id']=='frame':integer[r['var']]=1
    assert sum(integer)==2213
    save_rows(OUT/'inequalities.jsonl.gz',ub);save_rows(OUT/'equalities.jsonl.gz',eq)
    write(OUT/'integrality.json',integer);write(OUT/'excluded-groups.json',excluded)
    write(OUT/'row-change.json',{'row':at,'original_rhs':-13,'new_rhs':-21})
    bounds=[]
    for case in range(4):
        lo=[0]*n;hi=[1]*n
        for i in range(4):lo[i]=hi[i]=int(i==case)
        for r in mp['candidates']:
            if case not in r['compatible_skeletons']:hi[r['var']]=0
        bounds.append({'case':case,'lower':lo,'upper':hi})
    write(OUT/'bounds.json',bounds)
    prepared={'variables':n,'integer_frame_variables':sum(integer),'inequalities':len(ub),'equalities':len(eq),
        'reviewed_groups':len(excluded),'explicit_exclusion_rows':sum(r['row'] is not None for r in excluded),
        'absent_pose_exclusions':sum(r['row'] is None for r in excluded)}
    prepared['hashes']={p.name:digest(p) for p in OUT.iterdir() if p.is_file()}
    write(OUT/'prepared.json',prepared);print(json.dumps(prepared),flush=True)
if __name__=='__main__':main()
