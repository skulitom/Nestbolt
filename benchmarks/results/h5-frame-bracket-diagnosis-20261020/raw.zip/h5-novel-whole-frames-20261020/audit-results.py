"""Check saved mixed-integer vectors and the whole frame/cog geometry they imply."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import json,math,shutil
import numpy as np
import solve_h5_area_relaxations as base
from audit_h5_cog_lattices import shape
ROOT=base.ROOT;SRC=base.SRC;OUT=ROOT/'output/h5-novel-whole-frames-20261020'
CENSUS=ROOT/'output/h5-whole-frame-census-20261020'
load=base.load;write=base.write;digest=base.digest
def main():
    shutil.copyfile(__file__,OUT/'audit-results.py')
    for p,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/p)==h
    for p,h in load(OUT/'prepared.json')['hashes'].items():assert digest(OUT/p)==h
    ub=base.rows(OUT/'inequalities.jsonl.gz');eq=base.rows(OUT/'equalities.jsonl.gz')
    integer=np.array(load(OUT/'integrality.json'),bool);n=len(integer)
    A=base.matrix(ub,n);E=base.matrix(eq,n);b=np.array([r['rhs'] for r in ub]);d=np.array([r['rhs'] for r in eq])
    bounds=load(OUT/'bounds.json');mp=load(SRC/'mapping.json');pool=load(SRC/'candidates.json')
    original_sets={tuple(g['candidates']) for g in load(CENSUS/'groups.json')}
    cogsets=load(SRC/'cog-skeletons.json')['sets'];job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json')
    summaries=[];groups=[];statuses=Counter()
    for result in load(OUT/'results.json'):
        si=result['case'];dest=OUT/f'case-{si}';statuses[str(result['status'])]+=1
        assert result==load(dest/'result.json')
        if not result['has_solution']:
            assert not (dest/'solution.npz').exists() and not (dest/'frame-candidates.json').exists()
            summaries.append({'case':si,'status':result['status'],'seconds':result['seconds'],'new_frame_set':False})
            continue
        x=np.load(dest/'solution.npz')['x'];assert x.shape==(n,) and np.all(np.isfinite(x))
        iv=float(max(0,np.max(A@x-b)));ev=float(np.max(np.abs(E@x-d)))
        bv=float(max(0,np.max(np.array(bounds[si]['lower'])-x),np.max(x-np.array(bounds[si]['upper']))))
        ir=float(np.max(np.abs(x[integer]-np.rint(x[integer]))))
        assert iv<1e-5 and ev<1e-5 and bv<1e-6 and ir<1e-6
        frames=sorted(r['candidate'] for r in mp['candidates'] if pool[r['candidate']]['placement']['part_id']=='frame' and x[r['var']]>.5)
        assert len(frames)==18 and frames==load(dest/'frame-candidates.json')
        assert tuple(frames) not in original_sets
        geoms=defaultdict(list);ids=sorted(frames+cogsets[si]['candidates'])
        assert len(ids)==33 and len(set(ids))==33
        counts=Counter();pairs=0;minimum=math.inf
        for i in ids:
            p=pool[i]['placement'];part=parts[p['part_id']];t=p['transform'];counts[p['part_id']]+=1
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind']=='list':
                assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
            g=shape(part,t);assert g.is_valid
            x0,y0,x1,y1=g.bounds;h=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
            assert x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7
            assert x1<=stock['width']-m['right']-edge+1e-7 and y1<=h-m['top']-edge+1e-7
            geoms[p['sheet_id']].append(g)
        assert counts=={'frame':18,'cog':15}
        for gs in geoms.values():
            for a,c in combinations(gs,2):
                pairs+=1;distance=a.distance(c);minimum=min(minimum,distance)
                assert a.disjoint(c) and distance>=job['clearance']-1e-7
        summaries.append({'case':si,'status':result['status'],'seconds':result['seconds'],'new_frame_set':True,
            'max_inequality_violation':iv,'max_equality_violation':ev,'max_bound_violation':bv,'max_frame_integrality_residual':ir,
            'original_frame_cog_pairs':pairs,'minimum_distance_mm':minimum,
            'fractional_smaller_part_variables':result['fractional_smaller_part_variables']})
        groups.append({'index':len(groups),'source_case':si,'frame_candidates':frames,'cog_candidates':cogsets[si]['candidates']})
    assert [r['case'] for r in summaries]==[0,1,2,3]
    write(OUT/'new-groups.json',groups)
    check={'all_four_bounded_outcomes_preserved':True,'statuses':dict(statuses),'new_frame_cog_pairs':len(groups),
        'distinct_new_frame_sets':len({tuple(g['frame_candidates']) for g in groups}),'cases':summaries,
        'saved_vectors_checked':True,'original_whole_group_geometry_checked':True,
        'full_target_witness':False,'native_margin_qualified':False,'native_packing_calls':0,'quality_runs':0,
        'interpretation':'Whole frame sets are construction candidates only. Fractional bracket/insert values are not physical placements; restricted failure is not unrestricted impossibility.'}
    write(OUT/'result-audit.json',check);print(json.dumps(check),flush=True)
if __name__=='__main__':main()
