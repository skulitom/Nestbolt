"""Bound simultaneous brackets in each rejected final frame/cog arrangement."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction
import gzip,json,shutil,time,warnings
import numpy as np
from scipy.optimize import linprog
import solve_h5_area_relaxations as base
ROOT=base.ROOT;SRC=base.SRC;PARENT=ROOT/'output/h5-availability-completion-20261020'
OUT=ROOT/'output/h5-frame-bracket-capacity-20261020'
load=base.load;write=base.write;digest=base.digest
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'diagnose.py')
    inputs=[PARENT/'model-audit.json',PARENT/'results.json',SRC/'candidates.json']
    for i in range(4):inputs.extend([PARENT/f'case-{i}/mapping.json',PARENT/f'case-{i}/cliques.jsonl.gz'])
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'cases':[0,1,2,3],'seconds_per_case':10,'workers':8,'seed':0,
        'method':'Remove all inserts from each audited fixed-frame/cog completion model, retain every bracket pose and projected bracket conflict, and maximize their fractional sum with [0,1] bounds. Construct an exact rational dual upper bound, then independently reconstruct it with Fraction. A bound below 12 certifies failure of the original bracket quantity only within this fixed-group finite-pose model.',
        'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');results=[]
    for case in range(4):
        dest=OUT/f'case-{case}';dest.mkdir();parent=PARENT/f'case-{case}'
        mp=load(parent/'mapping.json')
        ids=[i for i in mp['candidates'] if pool[i]['placement']['part_id']=='bracket'];local={i:j for j,i in enumerate(ids)}
        with gzip.open(parent/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
            sets=[set(json.loads(l))&local.keys() for l in f]
        groups=sorted({tuple(sorted(s)) for s in sets if len(s)>1})
        rows=[{'indices':[local[i] for i in g],'coeffs':[1]*len(g),'rhs':1} for g in groups]
        write(dest/'bracket-candidates.json',ids)
        with gzip.open(dest/'rows.jsonl.gz','wt',encoding='utf-8',newline='\n') as f:
            for r in rows:f.write(json.dumps(r)+'\n')
        A=base.matrix(rows,len(ids));b=np.ones(len(rows));cost=-np.ones(len(ids))
        write(dest/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'seconds_limit':10})
        start=time.perf_counter()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            result=linprog(cost,A_ub=A,b_ub=b,bounds=(0,1),method='highs-ds',
                options={'time_limit':10.,'threads':8,'random_seed':0})
        record={'case':case,'status':int(result.status),'success':bool(result.success),'message':result.message,
            'seconds':time.perf_counter()-start,'warnings':[str(w.message) for w in caught],
            'bracket_candidates':len(ids),'conflict_cliques':len(rows)}
        if result.x is not None:
            x=result.x;y=result.ineqlin.marginals
            np.savez_compressed(dest/'solution.npz',x=x,inequality_marginals=y)
            assert np.max(A@x-b)<1e-6 and np.min(x)>-1e-6 and np.max(x)<1+1e-6
            record['fractional_brackets']=float(-result.fun)
            if result.success:
                exact=base.exact_upper_bound([-1]*len(ids),rows,[],y,[])
                # A second implementation uses Fraction directly, with no shared integer accumulator.
                dual=[min(Fraction(0),Fraction(float(v))) for v in y]
                reduced=[Fraction(-1)]*len(ids);lower=sum(dual)
                for w,row in zip(dual,rows):
                    for j in row['indices']:reduced[j]-=w
                upper=-(lower+sum(min(Fraction(0),v) for v in reduced))
                assert upper==Fraction(int(exact['numerator']),int(exact['denominator']))
                certificate={'numerator':str(upper.numerator),'denominator':str(upper.denominator),
                    'upper_bound_brackets':float(upper),'integer_bracket_upper_bound':upper.numerator//upper.denominator,
                    'independent_fraction_reconstruction_matches':True}
                write(dest/'exact-bound.json',certificate)
                record.update(certificate=certificate,original_12_brackets_ruled_out=upper<12)
        write(dest/'result.json',record);results.append(record);print(json.dumps(record),flush=True)
    assert all(digest(ROOT/p)==h for p,h in load(OUT/'plan.json')['inputs'].items())
    write(OUT/'results.json',results)
if __name__=='__main__':main()
