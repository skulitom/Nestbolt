"""Check the separate H5 runner's unchanged scoring and resource prerequisite."""
import importlib.util
from pathlib import Path
import sys
import unittest
from unittest.mock import patch, Mock

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import test_h5_exchange_pilot as existing
import h4_preview_matrix as h4
path=ROOT/'output/h5-exchange-pilot-v2-preparation/h5_exchange_pilot_v2.py'
spec=importlib.util.spec_from_file_location('h5_v2_candidate',path)
candidate=importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
existing.pilot=candidate


class PrerequisiteTests(unittest.TestCase):
    def fake_load(self,path):
        if path.name=='opened.json':return {'pid':99999999}
        if path.name=='results.json':return {'guards_unchanged':True,'all_quality_checks_pass':False}
        if path.name=='verification.json':return {'all_artifact_checks_passed':True,'new_attempts':603}
        if path.name=='integrity.json':return {'crc_and_every_member_verified':True,'sha256':'retained'}
        if path.name=='plan.json':return {'guards':{'unchanged':True}}
        raise AssertionError(path)

    def test_completed_failed_quality_remains_usable_as_resource_prerequisite_only(self):
        with patch.object(candidate,'load',side_effect=self.fake_load), patch.object(candidate.psutil,'pid_exists',return_value=False), \
             patch.object(candidate,'digest',return_value='retained'), patch.object(h4,'cases',return_value=([],[],[])), \
             patch.object(h4,'guards',return_value={'unchanged':True}):
            result=candidate.require_measurements_finished()
        self.assertEqual(len(result),5)
        self.assertTrue(all(value=='retained' for value in result.values()))
        self.assertNotIn('H4_complete',result)
        self.assertNotIn('H5_complete',result)

    def test_running_original_matrix_prevents_new_measurement(self):
        process=Mock();process.cmdline.return_value=['python','scripts/h4_preview_matrix.py']
        with patch.object(candidate,'load',side_effect=self.fake_load), patch.object(candidate.psutil,'pid_exists',return_value=True), \
             patch.object(candidate.psutil,'Process',return_value=process):
            with self.assertRaisesRegex(AssertionError,'still running'):
                candidate.require_measurements_finished()


suite=unittest.TestSuite([
    unittest.defaultTestLoader.loadTestsFromModule(existing),
    unittest.defaultTestLoader.loadTestsFromTestCase(PrerequisiteTests),
])
raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
