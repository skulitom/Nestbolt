"""Prepare a separate unopened H5 runner after the preview's H4 failure."""
from pathlib import Path
import difflib

ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'scripts/h5_exchange_pilot.py').read_text(encoding='utf-8')
text=source.replace('This pilot cannot complete H5 or justify a public quality claim.',
    'This pilot cannot complete H5 or justify a public quality claim.\n'
    'The original unmeasured plan unnecessarily required an H4 pass. This separate\n'
    'plan instead requires the original H4 measurement to be completed and sealed,\n'
    'and the isolated score-granularity probe to finish, so runs cannot overlap.\n'
    'H4 quality failure remains a failure; every H5 gate stays unchanged.')
text=text.replace("'requires_completed_current_H4_quality_and_both_scale_fixtures': True,",
    "'requires_completed_sealed_original_preview_and_chunks_probe': True,\n"
    "        'supersedes_unopened_plan': 'benchmarks/results/h5-exchange-pilot-20261016/plan.json',\n"
    "        'workflow_prerequisite_change_only': 'Wait for completed measurements, not a passing unrelated gate; H4 remains failed and every H5 limit is unchanged.',")
start=text.index('def require_h4_finished(scale_paths):')
end=text.index('\n\ndef measure(out, scale_paths):',start)
text=text[:start]+'''def require_measurements_finished():
    import h4_preview_matrix as h4
    chunks = ROOT/'benchmarks/results/h4-score-chunks-probe-20261016'
    for folder, runner in [(H4, 'h4_preview_matrix.py'), (chunks, 'h4_score_chunks_probe.py')]:
        opened = load(folder/'opened.json')
        if psutil.pid_exists(opened['pid']):
            assert not any(runner in arg for arg in psutil.Process(opened['pid']).cmdline()), 'Another measurement is still running'
        assert load(folder/'results.json')['guards_unchanged']
    verification = load(H4/'verification.json')
    assert verification['all_artifact_checks_passed'] and verification['new_attempts'] == 603
    inventory = load(H4/'integrity.json')
    assert inventory['crc_and_every_member_verified'] and digest(H4/'raw.zip') == inventory['sha256']
    rows, _, _ = h4.cases()
    assert h4.guards(rows) == load(H4/'plan.json')['guards']
    paths = [H4/'results.json', H4/'verification.json', H4/'integrity.json', chunks/'results.json', chunks/'plan.json']
    return {path.relative_to(ROOT).as_posix(): digest(path) for path in paths}
'''+text[end:]
text=text.replace('def measure(out, scale_paths):','def measure(out):')
text=text.replace('prerequisites = require_h4_finished(scale_paths)','prerequisites = require_measurements_finished()')
text=text.replace("    parser.add_argument('--scale', type=Path, action='append', default=[])\n",'')
text=text.replace('measure(out, [path.resolve() for path in args.scale])','measure(out)')
assert text!=source and 'requires_completed_current_H4' not in text and 'scale_paths' not in text
out=ROOT/'output/h5-exchange-pilot-v2-preparation'
assert not out.exists()
out.mkdir()
(out/'h5_exchange_pilot_v2.py').write_text(text,encoding='utf-8',newline='\n')
(out/'runner-diff.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),text.splitlines(True),fromfile='original-unopened-runner',tofile='new-unopened-runner')),encoding='utf-8',newline='\n')
print('Prepared a separate runner; root scripts and original plan remain unchanged.')
