"""One 30-second cog-only selection around51 fixed original non-cogs; independently reconstruct the whole model."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
from hashlib import sha256
import gzip,json,shutil,time
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-dense-cog-completion-20261023';OUT=BASE/'solve'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py')
    pool=load(BASE/'candidates.json');mp=load(BASE/'mapping.json');ids=mp['candidates'];n=len(ids)
    with gzip.open(BASE/'cliques.jsonl.gz','rt',encoding='utf-8') as f:rows=[json.loads(l) for l in f]
    area=load(ROOT/'output/h5-group-choice-20261023/mapping.json')['area_weights'];caps={'cog':15}
    assert load(ROOT/'output/h5-group-choice-20261023/graph-audit/checks.json')['integer_objective_orders_all_original_count_combinations']==4576
    families={f:[j for j,i in enumerate(ids) if pool[i]['placement']['part_id']==f] for f in caps}
    weights=[area[pool[i]['placement']['part_id']] for i in ids];hint=[int(i in set(mp['seed_candidates'])) for i in ids]
    low=sum(w*v for w,v in zip(weights,hint));high=sum(area[f]*caps[f] for f in caps)
    model=cp_model.CpModel();variables=[model.new_bool_var(f'p{i}') for i in ids]
    for row in rows:model.add_at_most_one(variables[j] for j in row)
    for f,js in families.items():model.add_linear_constraint(sum(variables[j] for j in js),0,caps[f])
    expr=sum(weights[j]*variables[j] for j in range(n));model.add_linear_constraint(expr,low,high);model.maximize(expr)
    for j,v in enumerate(hint):model.add_hint(variables[j],v)
    assert model.validate()=='';assert model.export_to_file(str(OUT/'model.pb'))
    expected=cp_model_pb2.CpModelProto()
    for i in ids:v=expected.variables.add();v.name=f'p{i}';v.domain.extend([0,1])
    for row in rows:expected.constraints.add().at_most_one.literals.extend(row)
    for f,js in families.items():
        c=expected.constraints.add().linear;c.vars.extend(js);c.coeffs.extend([1]*len(js));c.domain.extend([0,caps[f]])
    c=expected.constraints.add().linear;c.vars.extend(range(n));c.coeffs.extend(weights);c.domain.extend([low,high])
    expected.objective.vars.extend(range(n));expected.objective.coeffs.extend([-w for w in weights]);expected.objective.scaling_factor=-1
    expected.solution_hint.vars.extend(range(n));expected.solution_hint.values.extend(hint)
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes())
    assert actual.SerializeToString(deterministic=True)==expected.SerializeToString(deterministic=True)
    assert all(sum(hint[j] for j in row)<=1 for row in rows)
    assert {f:sum(hint[j] for j in js) for f,js in families.items()}=={'cog':13}
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=30;solver.parameters.num_search_workers=8;solver.parameters.random_seed=0
    solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n')
    write(OUT/'model-audit.json',{'passed':True,'all_protobuf_fields_independently_reconstructed':True,'complete_seed_verified':True,
      'variables':n,'constraints':len(actual.constraints),'seed_score':low,'full_score':high,
      'input_hashes':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'candidates.json',BASE/'mapping.json',BASE/'cliques.jsonl.gz',BASE/'audit/checks.json',BASE/'source-pool.json',BASE/'seed-mapping.json',ROOT/'output/h5-group-choice-20261023/mapping.json']},
      'model_format':'binary protobuf','model_sha256':digest(OUT/'model.pb'),'parameters_sha256':digest(OUT/'parameters.pbtxt')})
    records=[]
    def selected(value):return sorted(mp['fixed_candidates']+[i for j,i in enumerate(ids) if value(variables[j])])
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            chosen=selected(self.value);r={'index':len(records),'selected_indices':chosen,'counts':dict(Counter(pool[i]['placement']['part_id'] for i in chosen)),
              'seconds':self.wall_time,'objective':self.objective_value,'best_bound':self.best_objective_bound}
            write(OUT/f"incumbent-{r['index']}.json",r);records.append(r);print({k:v for k,v in r.items() if k!='selected_indices'},flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'seconds_limit':30,'maximum_calls':1})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
        solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());start=time.perf_counter();status=solver.solve(model,Capture());seconds=time.perf_counter()-start
    r={'status':solver.status_name(status),'seconds':seconds,'incumbents':len(records),'best_bound':solver.best_objective_bound,'response_stats':solver.response_stats()}
    if status in [cp_model.FEASIBLE,cp_model.OPTIMAL]:
        chosen=selected(solver.value);write(OUT/'selected-indices.json',chosen);r.update(counts=dict(Counter(pool[i]['placement']['part_id'] for i in chosen)),objective=solver.objective_value)
    write(OUT/'result.json',r);print(r,flush=True)
if __name__=='__main__':main()
