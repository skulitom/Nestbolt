"""New cog-only contacts around all51 non-cogs of the improved64-part seed."""
from collections import Counter,deque
from datetime import datetime,timezone
import copy,gzip,heapq,itertools,math,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import mapping
from shapely.strtree import STRtree
import diagnose_h5_concave_gaps as gap
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import proposals,identity
from census_h5_one_part_moves import bits
from build_h5_group_choice import ROOT,SRC,load,write,digest,save_rows
SEED=ROOT/'output/h5-dense-insert-gap-20261023'
POOL=ROOT/'output/h5-dense-wide-contacts-20261023'
BOUND=ROOT/'output/h5-dense-fixed-cog-capacity-20261023'
OUT=ROOT/'output/h5-dense-cog-completion-20261023'
def graph(folder,ids,pool,geometry,clearance):
    gs=np.asarray([geometry[i] for i in ids],dtype=object);adj=[0]*len(ids);edges=[]
    for sheet in ['sheet-0','sheet-1']:
        local=np.asarray([j for j,i in enumerate(ids) if pool[i]['placement']['sheet_id']==sheet],dtype=int)
        if not len(local):continue
        pair=STRtree(gs[local]).query(gs[local],predicate='dwithin',distance=clearance+1e-7)
        a,b=local[pair[0]],local[pair[1]];take=a<b;a,b=a[take],b[take]
        take=shapely.distance(gs[a],gs[b])<clearance-1e-7
        for i,j in zip(a[take],b[take]):
            i,j=int(i),int(j);edges.append((i,j));adj[i]|=1<<j;adj[j]|=1<<i
    remaining=adj.copy();heap=[(-a.bit_count(),i) for i,a in enumerate(adj) if a];heapq.heapify(heap)
    cliques=[];covered=0;start=time.perf_counter()
    while heap and time.perf_counter()-start<20:
        degree,i=heapq.heappop(heap)
        if -degree!=remaining[i].bit_count() or not remaining[i]:continue
        choices=remaining[i];c=[i];mask=1<<i
        while choices:
            sample=list(itertools.islice(bits(choices),16));j=max(sample,key=lambda j:((adj[j]&choices).bit_count(),-j))
            c.append(j);mask|=1<<j;choices&=adj[j]
        assert all(not((mask^(1<<j))&~adj[j]) for j in c);cliques.append(sorted(c))
        for j in c:
            before=remaining[j].bit_count();remaining[j]&=~mask;covered+=before-remaining[j].bit_count()
            if remaining[j]:heapq.heappush(heap,(-remaining[j].bit_count(),j))
    compressed=len(cliques);residual=0
    for i,mask in enumerate(remaining):
        for j in bits(mask&~((1<<(i+1))-1)):cliques.append([i,j]);residual+=1
    assert covered//2+residual==len(edges)
    save_rows(folder/'conflicts.jsonl.gz',sorted(edges));save_rows(folder/'cliques.jsonl.gz',sorted(set(map(tuple,cliques))))
    return {'conflicts':len(edges),'compressed_cliques':compressed,'residual_edges':residual,'compression_limit_reached':bool(heap)}
def main():
    OUT.mkdir();(OUT/'regions').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    inputs=[SRC/n for n in ['job.json','conditional-target.json']]+[SEED/n for n in ['layout.json','checks.json']]+[POOL/'candidates.json',BOUND/'audit/checks.json']
    assert load(BOUND/'audit/checks.json')['passed'] and load(BOUND/'audit/checks.json')['records'][0]['upper_bound']==19
    source_layout=load(SEED/'layout.json');angles=sorted({p['transform']['rotation_radians'] for p in source_layout['placements'] if p['part_id']=='cog'}|{math.radians(a) for a in [0,4.5,9,13.5]})
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
      'generation_seconds':120,'new_candidate_caps':{'cog':1500},'compression_seconds':20,'solve_seconds':30,'solve_calls':1,'workers':8,'seed':0,
      'fixed':'Exactly18 frames,12 brackets and21 inserts from the improved64-part partial. Only cogs may move. Preserve the13-cog seed and the original all66-copy target.',
      'queries':[{'sheet':s,'family':'cog','rotation_radians':a} for s in ['sheet-0','sheet-1'] for a in angles],
      'generation':'Retain every compatible cog from the full changed pool, including its audited dense-group poses. Append the new fixed insert only if its exact pose is absent; independently map all64 source placements. Generate conservative Minkowski free translation regions against all51 fixed original outlines at the exact current cog angles plus four sampled phases. Use every polygon representative point, boundary vertex and edge midpoint in round-robin query order. Exact float transform deduplication only. Keep all rejected and pending proposals. No unchanged solve is retried.',
      'new_pose_padding_mm':0.0126,'padding_scope':'The region helper uses0.0126mm positive construction padding for new proposals only. Old seed positions retain their original validated coordinates. This is not native-margin qualification; every actual pose/pair is independently checked against the unchanged original requirements.',
      'graph':'Recompute every cog/cog conflict. Retain residual edges after bounded clique compression. Solve only after independent original-geometry and model audits.',
      'selection':'Cap the original15 cogs; maximize filled area from all13 retained seed cogs. The checked continuous bound19 is inconclusive, not an attainable packing. An original66-copy candidate still needs native margins and unchanged full H5 gates.',
      'native_packing_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();pool=copy.deepcopy(load(POOL/'candidates.json'));source_size=len(pool);job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    keys={identity(r['placement']):i for i,r in enumerate(pool)};selected=[];new_fixed=[]
    for p in source_layout['placements']:
        p=copy.deepcopy(p);p.pop('copy_index');k=identity(p)
        if k not in keys:
            assert p['part_id']=='insert';i=len(pool);pool.append({'index':i,'placement':p,'source':{'kind':'fixed-insert-from64'},'filled_area_mm2':shape(parts['insert'],p['transform']).area});keys[k]=i;new_fixed.append(i)
        selected.append(keys[k])
    selected=set(selected);fixed=sorted(i for i in selected if pool[i]['placement']['part_id']!='cog');seed=sorted(selected-set(fixed))
    assert Counter(pool[i]['placement']['part_id'] for i in fixed)==Counter(frame=18,bracket=12,insert=21)
    assert Counter(pool[i]['placement']['part_id'] for i in seed)==Counter(cog=13) and len(new_fixed)<=1
    write(OUT/'source-pool.json',pool);write(OUT/'seed-mapping.json',{'source_pool_size':source_size,'new_fixed_candidates':new_fixed,'selected_candidates':sorted(selected)})
    oldsmall=[i for i,p in enumerate(pool) if p['placement']['part_id']=='cog']
    geometry={i:shape(parts[pool[i]['placement']['part_id']],pool[i]['placement']['transform']) for i in fixed+oldsmall}
    here={s:[i for i in fixed if pool[i]['placement']['sheet_id']==s] for s in ['sheet-0','sheet-1']}
    filters=[];eligible=[]
    for i in oldsmall:
        blockers=[j for j in here[pool[i]['placement']['sheet_id']] if geometry[i].distance(geometry[j])<job['clearance']-1e-7]
        filters.append({'candidate':i,'fixed_blockers':blockers})
        if not blockers:eligible.append(i)
    assert set(seed)<=set(eligible);keys={identity(p['placement']):i for i,p in enumerate(pool)};assert len(keys)==len(pool)
    target=load(SRC/'conditional-target.json');stock=job['stocks'][0];queries=[];planned=load(OUT/'plan.json')['queries'];gap.EPS=0.0126
    for item in planned:
        if time.perf_counter()-start>=120:break
        s,f,angle=item['sheet'],item['family'],item['rotation_radians'];this=copy.deepcopy(stock)
        if s=='sheet-1':this['height']=target['required_used_height_mm']
        moving=shape(parts[f],{'rotation_radians':angle,'translation':[0,0],'mirrored':False});beg=time.perf_counter()
        region=gap.regions(moving,[geometry[i] for i in here[s]],this,job['edge_clearance'],job['clearance'])
        query={'index':len(queries),'sheet':s,'family':f,'degrees':math.degrees(angle),'rotation_radians':angle,'seconds':time.perf_counter()-beg,
          'region':mapping(region),'region_area':region.area,'region_empty':region.is_empty,'proposals':proposals(region)}
        write(OUT/'regions'/f"query-{query['index']}.json",query);queries.append(query)
        print({k:query[k] for k in ['index','sheet','family','seconds','region_empty']},flush=True)
    queue=deque((q['index'],0) for q in queries if q['proposals']);events=[];added=[];counts=Counter();deferred=[];caps={'cog':1500}
    while queue and time.perf_counter()-start<120:
        qi,pi=queue.popleft();query=queries[qi];f=query['family']
        if counts[f]>=caps[f]:deferred.append([qi,pi]);continue
        p={'part_id':f,'sheet_id':query['sheet'],'transform':{'rotation_radians':query['rotation_radians'],'translation':query['proposals'][pi]['point'],'mirrored':False}}
        g=shape(parts[f],p['transform']);a,b,c,d=g.bounds;m=stock['margins'];edge=job['edge_clearance'];height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>height-m['top']-edge+1e-7
        blockers=[j for j in here[p['sheet_id']] if g.distance(geometry[j])<job['clearance']-1e-7];event={'query':qi,'proposal':pi}
        if outside or blockers:event.update(added=False,reason='geometry',outside=bool(outside),blockers=blockers)
        elif identity(p) in keys:event.update(added=False,reason='duplicate',candidate=keys[identity(p)])
        else:
            i=len(pool);pool.append({'index':i,'placement':p,'source':{'kind':'dense-cog-completion','query':qi,'proposal':pi},'filled_area_mm2':g.area})
            keys[identity(p)]=i;geometry[i]=g;added.append(i);counts[f]+=1;event.update(added=True,candidate=i)
        events.append(event)
        if pi+1<len(query['proposals']):queue.append((qi,pi+1))
    elapsed=time.perf_counter()-start;ids=sorted(eligible+added)
    write(OUT/'candidates.json',pool);write(OUT/'old-filter.json',filters);write(OUT/'source-events.json',events)
    pending={'unbuilt_queries':planned[len(queries):],'proposals':sorted(deferred+list(map(list,queue)))};write(OUT/'pending.json',pending)
    write(OUT/'mapping.json',{'candidates':ids,'fixed_candidates':fixed,'seed_candidates':seed,'old_eligible':eligible,'new_candidates':added})
    result={'generation_seconds':elapsed,'queries':len(queries),'old_eligible':len(eligible),'new_candidates':dict(counts),'proposals_processed':len(events),
      'pending_queries':len(pending['unbuilt_queries']),'pending_proposal_lists':len(pending['proposals']),'generation_limit_reached':elapsed>=120,
      'retained_candidates':len(ids),**graph(OUT,ids,pool,geometry,job['clearance'])}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
