"""Reconstruct every declared blocker case and validate the concrete retained subassembly."""
from collections import Counter
from itertools import combinations
import copy,math,shutil,subprocess
from shapely.geometry import Polygon
from census_h5_dense_group_blockers import ROOT,SRC,SEED,CAT,OUT,load,write,digest
def polygon(part,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;x0,y0=t['translation']
    return Polygon([(m*x*c-y*s+x0,m*x*s+y*c+y0) for x,y in part['geometry'][0]['outer']])
def main():
    dst=OUT/'audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};old=load(SEED/'layout.json');groups=load(CAT/'placements.json');last=[p for p in old['placements'] if p['part_id']=='cog' and p['sheet_id']=='sheet-1'];assert len(last)==1
    planned=[]
    for i,r in enumerate(groups):
        if r['zone']['sheet']!='sheet-0':continue
        if len(r['placements'])==15:
            planned.append({'group':i,'drop':None,'last_seed_cog':False});planned.extend({'group':i,'drop':j,'last_seed_cog':True} for j in range(15))
        elif len(r['placements'])==14:planned.append({'group':i,'drop':None,'last_seed_cog':True})
    records=load(OUT/'cases.json');summary=load(OUT/'checks.json');assert len(planned)==165 and summary['pending_cases']==planned[len(records):]
    baseline=[polygon(parts[p['part_id']],p['transform']) for p in old['placements']];pairs=0;frame_pairs=0;small_pairs=0
    for r,spec in zip(records,planned):
        assert all(r[k]==v for k,v in spec.items());poses=[p for j,p in enumerate(groups[r['group']]['placements']) if r['drop'] is None or j!=r['drop']]+(last if r['last_seed_cog'] else [])
        assert len(poses)==15;gs=[polygon(parts['cog'],p['transform']) for p in poses];blocked={}
        for i,j in combinations(range(15),2):
            if poses[i]['sheet_id']!=poses[j]['sheet_id']:continue
            pairs+=1;assert gs[i].disjoint(gs[j]) and gs[i].distance(gs[j])>=job['clearance']-1e-7
        for ci,(p,g) in enumerate(zip(poses,gs)):
            for j,previous in enumerate(old['placements']):
                if previous['part_id']=='cog' or previous['sheet_id']!=p['sheet_id']:continue
                d=g.distance(baseline[j])
                if previous['part_id']=='frame':frame_pairs+=1;assert g.disjoint(baseline[j]) and d>=job['clearance']-1e-7
                else:
                    small_pairs+=1
                    if d<job['clearance']-1e-7:blocked.setdefault(j,[]).append({'cog_member':ci,'distance_mm':d})
        expected=[{'layout_index':j,'part_id':old['placements'][j]['part_id'],'copy_index':old['placements'][j]['copy_index'],'cogs':v} for j,v in sorted(blocked.items())]
        assert r['blocker_details']==expected and r['blocked_layout_indices']==sorted(blocked)
        assert r['missing']==dict(Counter(old['placements'][j]['part_id'] for j in blocked)) and r['required_moves']==len(blocked)
        assert abs(r['removed_filled_area_mm2']-sum(baseline[j].area for j in blocked))<1e-7
    best=min(records,key=lambda r:(r['removed_filled_area_mm2'],r['required_moves'],r['index']));assert best==load(OUT/'best-case.json')
    sub=load(OUT/'best-subassembly.json');cg=[copy.deepcopy(p) for j,p in enumerate(groups[best['group']]['placements']) if best['drop'] is None or j!=best['drop']]
    if best['last_seed_cog']:cg+=copy.deepcopy(last)
    expected=[copy.deepcopy(p) for j,p in enumerate(old['placements']) if p['part_id']!='cog' and j not in best['blocked_layout_indices']]+cg;counts=Counter()
    for p in expected:p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1
    assert sub['placements']==expected and sub['sheets']==old['sheets'] and counts==Counter(frame=18,cog=15,bracket=9,insert=16)
    st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json');tops=Counter();geoms=[];minimum=math.inf
    for p in sub['placements']:
        g=polygon(parts[p['part_id']],p['transform']);geoms.append(g);a,b,c,d=g.bounds;h=st['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        assert g.is_valid and a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=st['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7
        tops[p['sheet_id']]=max(tops[p['sheet_id']],d+m['top']+edge)
    for i,j in combinations(range(len(geoms)),2):
        if sub['placements'][i]['sheet_id']!=sub['placements'][j]['sheet_id']:continue
        d=geoms[i].distance(geoms[j]);minimum=min(minimum,d);assert geoms[i].disjoint(geoms[j]) and d>=job['clearance']-1e-7
    material=st['width']*(st['height']+tops['sheet-1']);assert material<=target['target_material_mm2']+1e-6
    cli=ROOT/'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    original=ROOT/'output/h5-coordinated-placement-selection-20261018';cmd=[str(cli),'validate','--library',str(original/'library.json'),'--request',str(original/'request.json'),'--layout',str(OUT/'best-subassembly.json')]
    cp=subprocess.run(cmd,capture_output=True,timeout=60);(dst/'public.json').write_bytes(cp.stdout);(dst/'public.stderr').write_bytes(cp.stderr);write(dst/'command.json',{'command':cmd,'exit_code':cp.returncode});public=load(dst/'public.json')
    expected=[{'code':'quantity','message':f'part {f}: expected {parts[f]["quantity"]}, found {counts[f]}'} for f in ['bracket','insert']]
    assert cp.returncode!=0 and not public['valid'] and sorted(public['violations'],key=lambda r:r['message'])==expected
    result={'passed':True,'all_declared_cases_reconstructed':len(records),'cog_pairs':pairs,'frame_pairs':frame_pairs,'small_part_pairs':small_pairs,'best_subassembly_exact':True,'counts':dict(counts),
      'missing':best['missing'],'minimum_distance_mm':minimum,'material_mm2':material,'filled_area_mm2':sum(g.area for g in geoms),'original_CLI_valid':False,'fresh_frozen_CLI_calls':1,'full_target_witness':False,'native_margin_qualified':False}
    write(dst/'checks.json',result);print(result,flush=True)
if __name__=='__main__':main()
