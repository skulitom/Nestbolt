"""Identify exact small-part moves required by saved complete15-cog arrangements."""
from datetime import datetime,timezone
from itertools import combinations
from collections import Counter
import copy,math,shutil,time
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity
from build_h5_dense_cog_completion import ROOT,SRC,SEED,OUT as COG,load,write,digest
CAT=ROOT/'output/h5-wide-catalogue-coverage-20261023'
OUT=ROOT/'output/h5-dense-group-blockers-20261023'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'census.py')
    inputs=[SEED/'layout.json',SEED/'checks.json',CAT/'placements.json',CAT/'checks.json',COG/'solve/result.json',COG/'layout-audit/checks.json',SRC/'job.json',SRC/'conditional-target.json']
    assert load(COG/'solve/result.json')['status']=='OPTIMAL' and load(COG/'layout-audit/checks.json')['passed']
    groups=load(CAT/'placements.json');old=load(SEED/'layout.json');last=[p for p in old['placements'] if p['part_id']=='cog' and p['sheet_id']=='sheet-1'];assert len(last)==1
    cases=[]
    for i,r in enumerate(groups):
        if r['zone']['sheet']!='sheet-0':continue
        n=len(r['placements'])
        if n==15:
            cases.append({'group':i,'drop':None,'last_seed_cog':False})
            cases.extend({'group':i,'drop':j,'last_seed_cog':True} for j in range(15))
        elif n==14:cases.append({'group':i,'drop':None,'last_seed_cog':True})
    assert len(cases)==165
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_cases':165,'maximum_seconds':30,
      'method':'Check every saved first-sheet15-cog group as-is, or remove each of its15 members and add the exact last-sheet seed cog. Also check every saved14-cog first-sheet group with that last cog. Every case has all15 original cogs. Check every original cog/cog, cog/frame and cog/bracket-or-insert pair and original stock bounds. Keep all18 frames fixed. List precisely which of the33 current bracket/insert poses would have to move for that particular complete cog arrangement. Rank by removed original filled area, removed count and case index, retaining all cases and any unprocessed suffix. This is a relocation hypothesis, not a packing completion or an unrestricted lower bound. No solver, native packing or quality runs.'})
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};st=job['stocks'][0];m=st['margins'];edge=job['edge_clearance'];target=load(SRC/'conditional-target.json');clear=job['clearance']
    oldg=[shape(parts[p['part_id']],p['transform']) for p in old['placements']];frames=[i for i,p in enumerate(old['placements']) if p['part_id']=='frame'];small=[i for i,p in enumerate(old['placements']) if p['part_id'] in ['bracket','insert']]
    assert len(frames)==18 and len(small)==33
    cache={};records=[];cg_pairs=frame_pairs=small_pairs=0;start=time.perf_counter()
    for spec in cases:
        if time.perf_counter()-start>=30:break
        poses=[copy.deepcopy(p) for j,p in enumerate(groups[spec['group']]['placements']) if spec['drop'] is None or j!=spec['drop']]
        if spec['last_seed_cog']:poses.append(copy.deepcopy(last[0]))
        assert len(poses)==15 and all(p['part_id']=='cog' and not p['transform']['mirrored'] for p in poses);gs=[]
        for p in poses:
            k=identity(p)
            if k not in cache:cache[k]=shape(parts['cog'],p['transform'])
            g=cache[k];a,b,c,d=g.bounds;h=st['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
            assert g.is_valid and a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=st['width']-m['right']-edge+1e-7 and d<=h-m['top']-edge+1e-7;gs.append(g)
        minimum=math.inf
        for i,j in combinations(range(15),2):
            if poses[i]['sheet_id']!=poses[j]['sheet_id']:continue
            cg_pairs+=1;d=gs[i].distance(gs[j]);minimum=min(minimum,d);assert gs[i].disjoint(gs[j]) and d>=clear-1e-7
        blockers={}
        for ci,(p,g) in enumerate(zip(poses,gs)):
            for j in frames+small:
                if old['placements'][j]['sheet_id']!=p['sheet_id']:continue
                d=g.distance(oldg[j])
                if j in frames:frame_pairs+=1;assert g.disjoint(oldg[j]) and d>=clear-1e-7
                else:
                    small_pairs+=1
                    if d<clear-1e-7:blockers.setdefault(j,[]).append({'cog_member':ci,'distance_mm':d})
        missing=Counter(old['placements'][j]['part_id'] for j in blockers);area=sum(oldg[j].area for j in blockers)
        records.append({'index':len(records),**spec,'blocked_layout_indices':sorted(blockers),'blocker_details':[{'layout_index':j,'part_id':old['placements'][j]['part_id'],'copy_index':old['placements'][j]['copy_index'],'cogs':v} for j,v in sorted(blockers.items())],
          'missing':dict(missing),'required_moves':len(blockers),'removed_filled_area_mm2':area,'minimum_cog_distance_mm':minimum})
    best=min(records,key=lambda r:(r['removed_filled_area_mm2'],r['required_moves'],r['index']));write(OUT/'cases.json',records);write(OUT/'best-case.json',best)
    # Keep an exact constructive subassembly for the next completion experiment.
    group=groups[best['group']];cogs=[copy.deepcopy(p) for j,p in enumerate(group['placements']) if best['drop'] is None or j!=best['drop']]
    if best['last_seed_cog']:cogs.append(copy.deepcopy(last[0]))
    retained=[copy.deepcopy(p) for i,p in enumerate(old['placements']) if p['part_id']!='cog' and i not in best['blocked_layout_indices']]+cogs
    counts=Counter()
    for p in retained:p['copy_index']=counts[p['part_id']];counts[p['part_id']]+=1
    layout={**copy.deepcopy(old),'placements':retained};write(OUT/'best-subassembly.json',layout)
    gg=[shape(parts[p['part_id']],p['transform']) for p in retained];pairs=0
    for i,j in combinations(range(len(gg)),2):
        if retained[i]['sheet_id']!=retained[j]['sheet_id']:continue
        pairs+=1;assert gg[i].disjoint(gg[j]) and gg[i].distance(gg[j])>=clear-1e-7
    check={'passed':True,'seconds':time.perf_counter()-start,'cases_checked':len(records),'pending_cases':cases[len(records):],'cog_pairs':cg_pairs,'frame_pairs':frame_pairs,'small_part_pairs':small_pairs,
      'minimum_required_moves_in_declared_cases':min(r['required_moves'] for r in records),'best_case':best,'best_subassembly_counts':dict(counts),'best_subassembly_pairs':pairs,
      'original_CLI_acceptance_pending':True,'full_target_witness':False,'native_margin_qualified':False,'solver_calls':0,'quality_runs':0}
    write(OUT/'checks.json',check);print({k:v for k,v in check.items() if k!='best_case'},flush=True);print(best,flush=True)
if __name__=='__main__':main()
