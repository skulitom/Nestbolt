from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,subprocess,shutil
root=Path(__file__).resolve().parents[1]
out=root/'output/ci-lead-budget-hosted-20261017';out.mkdir()
def gh(*args):return subprocess.check_output(['gh',*args],cwd=root,timeout=120)
def write(n,x):(out/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
for run,name in [('39074673874','old-run-terminal.json'),('39076499315','new-run-at-web-review.json')]:
    raw=gh('run','view',run,'--json','status,conclusion,headSha,url,jobs');(out/name).write_bytes(raw)
old=json.loads((out/'old-run-terminal.json').read_bytes())
assert old['status']=='completed' and old['conclusion']=='cancelled'
assert next(j for j in old['jobs'] if j['name']=='web')['conclusion']=='failure'
new=json.loads((out/'new-run-at-web-review.json').read_bytes())
assert new['headSha']=='c5e00fa831cc366d6ff2e9e154ead214ca75a8bb'
web=next(j for j in new['jobs'] if j['name']=='web');assert web['conclusion']=='success'
log=gh('api',f"repos/skulitom/Nestbolt/actions/jobs/{web['databaseId']}/logs")
(out/'web-success.log').write_bytes(log)
assert b'86 passed' in log and b'4 skipped' in log
write('review.json',{'utc':datetime.now(timezone.utc).isoformat(),'run':39076499315,'web_job':web['databaseId'],
    'browser_passed':86,'opt_in_skipped':4,'hosted_browser_confirmation':True,
    'whole_workflow_terminal_at_web_review':new['status']=='completed',
    'original_run_terminal':'cancelled after subsequent push; original web failure retained; not all-six success',
    'old_c36_Firefox_cause_established':False,'release_assets_changed':False,
    'files':{p.name:sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}})
shutil.copyfile(__file__,out/'capture.py')
print(json.dumps({'hosted_browser_pass':True,'passed':86,'skipped':4,'workflow_status':new['status']}))
