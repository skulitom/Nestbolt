from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/ci-lead-budget-hosted-20261017'
out=root/'benchmarks/results/browser-lead-hosted-confirmation-20261017'
raw=subprocess.check_output(['gh','run','view','39076499315','--json','status,conclusion,headSha,url,jobs'],cwd=root,timeout=120)
state=json.loads(raw)
assert state['status']=='completed' and state['conclusion']=='success'
assert len(state['jobs'])==6 and all(j['conclusion']=='success' for j in state['jobs'])
assert state['headSha']=='c5e00fa831cc366d6ff2e9e154ead214ca75a8bb'
(probe/'new-run-terminal.json').write_bytes(raw)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
assert b'86 passed' in (probe/'web-success.log').read_bytes()
shutil.copyfile(__file__,probe/'seal.py');out.mkdir()
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
inventory={n:{'bytes':p.stat().st_size,'sha256':digest(p)} for n,p in files.items()}
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for n,row in inventory.items():
        data=z.read(n);assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','sha256':digest(archive),'members':inventory,'crc_and_every_member_verified':True})
for name in ['old-run-terminal.json','new-run-terminal.json','review.json']:shutil.copyfile(probe/name,out/name)
write(out/'checks.json',{'utc':datetime.now(timezone.utc).isoformat(),'all_six_jobs_pass':True,'browser_passed':86,'browser_opt_in_skipped':4,
    'original_failed_web_job_preserved':True,'original_run_finally_cancelled':True,'source_digest':source_digest(),
    'release_assets_changed':False,'old_c36_Firefox_cause_established':False})
(out.parent/(out.name+'.md')).write_text('''# Hosted browser allowance confirmation — 2026-10-17

[The c5e00fa workflow](https://github.com/skulitom/Nestbolt/actions/runs/39076499315)
passes **all six jobs**, including both platform checks, both maker rebuilds,
benchmark smoke and the browser job. The saved browser log reports **86 passes
and four opt-in skips** after the lead test adopted the normal five-second
functional allowance. All test assertions and production source remain unchanged.

The earlier bf9e880 workflow ended cancelled after a later push while Windows
checks were still running. Its browser failure, complete diagnostics and terminal
state remain preserved; it is not an all-six success. This supplement leaves
the [original failure archive](browser-lead-budget-20261017.md) intact. It does
not establish the cause of the older c36baa8 Firefox failure.

The archive retains original and new workflow metadata, the successful browser
log, capture/review records and this sealing procedure. CRC and every member
hash/size verify. Published preview assets and gate limits are unchanged.
H2/H5 remain open; milestone completion stays 60%.
''',encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:f.write('\nbenchmarks/results/browser-lead-hosted-confirmation-20261017/** -text -whitespace\n')
for name in ['docs/STATUS.md','docs/RELEASE_READINESS.md']:
    p=root/name;s=p.read_text(encoding='utf-8')
    old='skips, two workers, no retries). Hosted confirmation is pending. The original'
    new='skips, two workers, no retries). [Hosted confirmation now passes all six jobs](../benchmarks/results/browser-lead-hosted-confirmation-20261017.md), including 86 browser tests and four skips. The original'
    assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,encoding='utf-8',newline='\n')
with (root/'BENCHMARKS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''

## 2026-10-17 — Hosted confirmation of the normal browser-test allowance

[c5e00fa passes all six hosted jobs](benchmarks/results/browser-lead-hosted-confirmation-20261017.md),
including 86 browser tests with four opt-in skips. The original bf9e880 browser
failure remains preserved; its overall run was later cancelled while Windows
checks were running. Original/new terminal metadata and the successful browser
log are archived and verified. No production, released-asset or gate change;
the older c36baa8 Firefox cause remains unknown. Completion remains 60%.
''')
assert (root/'BENCHMARKS.md').read_bytes().startswith(subprocess.check_output(['git','show','HEAD:BENCHMARKS.md'],cwd=root))
print(json.dumps({'all_six_jobs_pass':True,'archive_members':len(inventory),'archive_sha256':digest(archive)}))
