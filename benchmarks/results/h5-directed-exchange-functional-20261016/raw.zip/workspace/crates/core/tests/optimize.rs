use nestbolt_core::control::{Control, Interrupted, StopReason};
use nestbolt_core::{construct, optimize};
use nestbolt_validator::{
    Units,
    job::{Job, Margins, Mode, Part, Rotations, Stock, rectangle, validate},
};
use std::cell::Cell;

#[test]
fn shallow_overlap_repair_keeps_the_blaz1_development_quality_gain() {
    // This is a frozen development job, never a held-out case. The original
    // blocker-count ranking needed eleven sheets at the same four-pass budget.
    let job: Job = serde_json::from_str(include_str!(
        "../../../benchmarks/datasets/B/b-blaz1-nest-mb-free.json"
    ))
    .unwrap();
    let result = optimize::optimize(
        &job,
        optimize::Options {
            construct: construct::Options {
                seed: 0,
                random_samples: 64,
                ..construct::Options::default()
            },
            passes: 4,
        },
        |_| {},
    )
    .unwrap();
    assert!(result.validation.valid);
    assert!(result.best.layout.sheets.len() <= 10);
    assert!(result.validation.metrics.unwrap().normalized_material < 9.81);
}

#[test]
fn a_trial_the_collision_engine_lets_overlap_is_rejected_not_fatal() {
    // Development job (never held out). With seed 1004, pass 75 (diversified,
    // from the right, capped at one sheet) refines two 936 x 659 rectangles to
    // 0.0117 apart vertically, about the outlines' corner rounding, so every
    // edge crossing falls on a vertex and jagua's f32 tests miss a 10.5%
    // overlap. The independent check catches it; the search must carry on.
    // Found by the final acceptance run of 484ce8b, which stopped with an error.
    let job: Job = serde_json::from_str(include_str!(
        "../../../benchmarks/datasets/B/b-albano-strip-sheet.json"
    ))
    .unwrap();
    let result = optimize::optimize(
        &job,
        optimize::Options {
            construct: construct::Options {
                seed: 1004,
                ..construct::Options::default()
            },
            passes: 76,
        },
        |_| {},
    )
    .unwrap();
    assert!(result.validation.valid);
    assert_eq!(result.completed_passes, 76);
    let trial = &result.history[75];
    assert_eq!(trial.stage, "rejected");
    assert!(!trial.accepted && trial.material.is_none());
}

fn job() -> Job {
    Job {
        version: 1,
        name: "repack".into(),
        units: Units::Mm,
        clearance: 0.2,
        edge_clearance: 0.3,
        mode: Mode::All,
        parts: [(8.0, 4.0), (6.0, 6.0), (3.0, 7.0), (4.0, 4.0), (2.0, 5.0)]
            .into_iter()
            .enumerate()
            .map(|(i, (w, h))| Part {
                id: format!("p{i}"),
                quantity: 2,
                geometry: vec![rectangle(0.0, 0.0, w, h)],
                rotations: Rotations::List {
                    degrees: vec![0.0, 90.0],
                },
                allow_mirror: false,
                priority: (i + 1) as f64,
            })
            .collect(),
        stocks: vec![Stock {
            id: "sheet".into(),
            width: 16.0,
            height: 12.0,
            count: None,
            margins: Margins::default(),
            outline: vec![],
            defects: vec![],
        }],
    }
}

#[test]
fn repacking_preserves_a_valid_incumbent_and_accounts_for_every_pass() {
    let job = job();
    let options = optimize::Options {
        construct: construct::Options::default(),
        passes: 5,
    };
    let mut callbacks = vec![];
    let result = optimize::optimize(&job, options, |p| callbacks.push(p.pass)).unwrap();
    assert!(validate(&job, &result.best.layout).unwrap().valid);
    assert_eq!(callbacks, vec![0, 1, 2, 3, 4]);
    assert_eq!(result.completed_passes, 5);
    assert_eq!(
        result.history[3].sheet_limit,
        Some(
            result.history[..3]
                .iter()
                .rfind(|p| p.accepted)
                .unwrap()
                .sheets
                - 1
        )
    );
    assert_eq!(result.history[1].stage, "refine");
    assert_eq!(result.history[1].seed, result.history[0].seed);
    assert_eq!(result.history[2].stage, "contacts");
    assert_eq!(result.history[2].seed, result.history[0].seed);
    assert!(!result.history[1].contact_search);
    assert!(result.history[2].contact_search);
    assert_eq!(result.history[3].stage, "repair-sheet");
    assert!(!result.history[3].interleaved_copies);
    assert!(!result.history[4].interleaved_copies);
    assert!(result.best.layout.sheets.len() <= result.history[0].sheets);
    for pass in &result.history {
        if !pass.complete {
            assert!(!pass.accepted);
            assert!(pass.material.is_none());
        }
    }
    let repeat = optimize::optimize(&job, options, |_| {}).unwrap();
    assert_eq!(
        serde_json::to_string(&result).unwrap(),
        serde_json::to_string(&repeat).unwrap()
    );
}

#[test]
fn finishing_preserves_every_repacking_pass_and_the_incumbent_on_interruption() {
    let job = job();
    let options = optimize::Options {
        construct: construct::Options::default(),
        passes: 6,
    };
    let cancel = Cell::new(false);
    let mut probe = || cancel.get().then_some(StopReason::Cancelled);
    let before = optimize::optimize_controlled(
        &job,
        options,
        &mut Control::new(None, Some(&mut probe)),
        |p| cancel.set(p.pass == 5),
    )
    .unwrap();
    assert_eq!(before.completed_passes, 6);
    assert!(before.polishing.is_empty());
    let mut callbacks = vec![];
    let full = optimize::optimize(&job, options, |p| callbacks.push(p.pass)).unwrap();
    assert_eq!(
        callbacks,
        (0..6 + full.polishing.len() as u32).collect::<Vec<_>>()
    );
    assert_eq!(full.completed_passes, 6);
    assert!((3..=15).contains(&full.polishing.len()));
    assert_eq!(
        serde_json::to_string(&full.history).unwrap(),
        serde_json::to_string(&before.history).unwrap()
    );
    assert!(full.validation.valid);
    assert!(
        full.validation.metrics.as_ref().unwrap().material_area
            <= before.validation.metrics.as_ref().unwrap().material_area
    );
    let stopped = optimize::optimize_controlled(
        &job,
        options,
        &mut Control::new(Some(before.collision_checks + 1), None),
        |_| {},
    )
    .unwrap();
    assert_eq!(stopped.stopped, Some(StopReason::WorkLimit));
    assert_eq!(stopped.completed_passes, 6);
    assert!(stopped.polishing.is_empty());
    assert_eq!(
        serde_json::to_string(&stopped.best.layout).unwrap(),
        serde_json::to_string(&before.best.layout).unwrap()
    );
    let replay = optimize::optimize(&job, options, |_| {}).unwrap();
    assert_eq!(
        serde_json::to_string(&full).unwrap(),
        serde_json::to_string(&replay).unwrap()
    );
}

#[test]
fn fill_priority_search_never_reduces_the_incumbents_priority() {
    let mut job = job();
    job.mode = Mode::FillPriority;
    job.stocks[0].count = Some(1);
    let result = optimize::optimize(
        &job,
        optimize::Options {
            construct: construct::Options::default(),
            passes: 4,
        },
        |_| {},
    )
    .unwrap();
    assert!(result.validation.valid);
    let scores: Vec<_> = result
        .history
        .iter()
        .filter(|p| p.accepted)
        .map(|p| p.placed_priority.unwrap())
        .collect();
    assert!(scores.windows(2).all(|p| p[0] <= p[1]));
    assert_eq!(result.best.layout.sheets.len(), 1);
}

#[test]
fn impossible_stock_is_not_reported_as_a_successful_improvement() {
    let mut job = job();
    job.stocks[0].width = 1.0;
    job.stocks[0].height = 1.0;
    job.stocks[0].count = Some(1);
    let result = optimize::optimize(
        &job,
        optimize::Options {
            construct: construct::Options::default(),
            passes: 3,
        },
        |_| {},
    )
    .unwrap();
    assert!(!result.validation.valid);
    assert!(!result.best.complete);
    assert!(
        result
            .history
            .iter()
            .all(|p| !p.accepted && p.material.is_none())
    );
}

#[test]
fn collision_limit_stops_mid_pass_and_preserves_the_valid_incumbent_deterministically() {
    let job = job();
    let options = optimize::Options {
        construct: construct::Options::default(),
        passes: 1,
    };
    let initial = optimize::optimize(&job, options, |_| {}).unwrap();
    let limit = initial.collision_checks + 1;
    let run = || {
        optimize::optimize_controlled(
            &job,
            optimize::Options {
                passes: 8,
                ..options
            },
            &mut Control::new(Some(limit), None),
            |_| {},
        )
        .unwrap()
    };
    let stopped = run();
    assert_eq!(stopped.stopped, Some(StopReason::WorkLimit));
    assert_eq!(stopped.completed_passes, 1);
    assert_eq!(stopped.requested_passes, 8);
    assert_eq!(stopped.collision_checks, limit);
    assert!(stopped.validation.valid);
    assert_eq!(
        serde_json::to_string(&stopped.best.layout).unwrap(),
        serde_json::to_string(&initial.best.layout).unwrap()
    );
    assert_eq!(
        serde_json::to_string(&stopped).unwrap(),
        serde_json::to_string(&run()).unwrap()
    );
}

#[test]
fn cancellation_before_initial_layout_is_typed_and_after_progress_keeps_the_layout() {
    let job = job();
    let options = optimize::Options {
        construct: construct::Options::default(),
        passes: 4,
    };
    let mut already_cancelled = || Some(StopReason::Cancelled);
    let error = optimize::optimize_controlled(
        &job,
        options,
        &mut Control::new(None, Some(&mut already_cancelled)),
        |_| {},
    )
    .unwrap_err();
    assert_eq!(
        error.downcast_ref::<Interrupted>().unwrap().0,
        StopReason::Cancelled
    );
    let error =
        optimize::optimize_controlled(&job, options, &mut Control::new(Some(0), None), |_| {})
            .unwrap_err();
    assert_eq!(
        error.downcast_ref::<Interrupted>().unwrap().0,
        StopReason::WorkLimit
    );

    let cancel = Cell::new(false);
    let mut probe = || cancel.get().then_some(StopReason::Cancelled);
    let result = optimize::optimize_controlled(
        &job,
        options,
        &mut Control::new(None, Some(&mut probe)),
        |_| cancel.set(true),
    )
    .unwrap();
    assert_eq!(result.stopped, Some(StopReason::Cancelled));
    assert_eq!(result.completed_passes, 1);
    assert!(result.validation.valid && result.best.complete);
}

#[test]
fn interrupted_sheet_repair_cannot_leak_removed_or_displaced_parts() {
    let job = job();
    let options = optimize::Options {
        construct: construct::Options::default(),
        passes: 3,
    };
    let initial = optimize::optimize(&job, options, |_| {}).unwrap();
    assert!(initial.best.layout.sheets.len() > 1);
    let options = optimize::Options {
        passes: 4,
        ..options
    };
    let full = optimize::optimize(&job, options, |_| {}).unwrap();
    let repair_work = full.collision_checks - initial.collision_checks;
    assert!(repair_work > 2);
    for extra in [1, repair_work / 2, repair_work - 1] {
        let result = optimize::optimize_controlled(
            &job,
            options,
            &mut Control::new(Some(initial.collision_checks + extra), None),
            |_| {},
        )
        .unwrap();
        assert_eq!(result.stopped, Some(StopReason::WorkLimit));
        assert_eq!(result.completed_passes, 3);
        assert!(result.validation.valid);
        assert_eq!(
            serde_json::to_string(&result.best.layout).unwrap(),
            serde_json::to_string(&initial.best.layout).unwrap()
        );
    }
}

#[test]
fn longer_search_preserves_the_first_finished_block_and_shared_work_limit() {
    let mut job = job();
    job.parts.truncate(3);
    for part in &mut job.parts {
        part.quantity = 1;
    }
    let options = optimize::Options {
        construct: construct::Options {
            random_samples: 4,
            ..Default::default()
        },
        passes: 64,
    };
    let first = optimize::optimize(&job, options, |_| {}).unwrap();
    let longer = optimize::optimize(
        &job,
        optimize::Options {
            passes: 66,
            ..options
        },
        |_| {},
    )
    .unwrap();
    assert_eq!(longer.completed_passes, 66);
    assert_eq!(longer.history[64].seed, longer.history[65].seed);
    assert!(longer.history[65].contact_search);
    assert_eq!(
        serde_json::to_value(&first.history).unwrap(),
        serde_json::to_value(&longer.history[..64]).unwrap()
    );
    assert_eq!(
        serde_json::to_value(&first.polishing).unwrap(),
        serde_json::to_value(&longer.polishing[..first.polishing.len()]).unwrap()
    );
    assert!(longer.validation.valid);
    assert!(
        longer.validation.metrics.as_ref().unwrap().material_area
            <= first.validation.metrics.as_ref().unwrap().material_area
    );
    assert!(longer.polishing.len() > first.polishing.len());
    let diverse_checks = longer.history[65].collision_checks;
    assert!(diverse_checks > 2);
    let during_diversity = optimize::optimize_controlled(
        &job,
        optimize::Options {
            passes: 1024,
            ..options
        },
        &mut Control::new(
            Some(first.collision_checks + longer.history[64].collision_checks + diverse_checks / 2),
            None,
        ),
        |_| {},
    )
    .unwrap();
    assert_eq!(during_diversity.completed_passes, 65);
    assert_eq!(during_diversity.stopped, Some(StopReason::WorkLimit));
    assert!(during_diversity.validation.valid && during_diversity.best.complete);
    assert!(
        during_diversity
            .validation
            .metrics
            .as_ref()
            .unwrap()
            .material_area
            <= first.validation.metrics.as_ref().unwrap().material_area
    );
    let stopped = optimize::optimize_controlled(
        &job,
        optimize::Options {
            passes: 1024,
            ..options
        },
        &mut Control::new(Some(first.collision_checks + 1), None),
        |_| {},
    )
    .unwrap();
    assert_eq!(stopped.completed_passes, 64);
    assert_eq!(stopped.stopped, Some(StopReason::WorkLimit));
    assert!(stopped.validation.valid);
    assert_eq!(
        serde_json::to_value(stopped.best.layout).unwrap(),
        serde_json::to_value(first.best.layout).unwrap()
    );
    for passes in [0, 1025] {
        assert!(optimize::optimize(&job, optimize::Options { passes, ..options }, |_| {}).is_err());
    }
}
