//! Deterministic repacking search over the shared prepared geometry. This is the
//! first improvement stage; fixed passes are explicit experimental work budgets.
use anyhow::{Result, ensure};
use nestbolt_validator::job::{Job, Metrics, Mode, Report, validate};
use serde::Serialize;

use crate::construct::{
    Construction, Options as ConstructOptions, PreparedJob, Refinement, Rejected,
};
use crate::control::{Control, Interrupted, StopReason};

#[derive(Clone, Copy, Debug)]
pub struct Options {
    pub construct: ConstructOptions,
    /// Includes the initial construction. Every requested pass is accounted for.
    /// Six or more passes also enable up to fifteen bounded finishing trials per
    /// 64-pass block (and at the requested final pass), recorded in `polishing`
    /// and sharing the same collision/deadline control. After the first block,
    /// legacy and diversified constructions share each successive search seed.
    pub passes: u32,
}

#[derive(Debug, Serialize)]
pub struct Progress {
    pub pass: u32,
    pub stage: &'static str,
    pub contact_search: bool,
    pub interleaved_copies: bool,
    pub seed: u64,
    pub sheet_limit: Option<usize>,
    pub complete: bool,
    pub accepted: bool,
    pub sheets: usize,
    pub material: Option<f64>,
    pub placed_area: Option<f64>,
    pub placed_priority: Option<f64>,
    pub collision_checks: u64,
}

#[derive(Debug, Serialize)]
pub struct SearchResult {
    pub algorithm: &'static str,
    pub seed: u64,
    pub requested_passes: u32,
    pub completed_passes: u32,
    pub best: Construction,
    pub validation: Report,
    pub history: Vec<Progress>,
    /// Bounded finishing trials, separate from the requested repacking passes.
    pub polishing: Vec<Progress>,
    pub collision_checks: u64,
    pub stopped: Option<StopReason>,
}

fn seed(base: u64, pass: u32) -> u64 {
    base.wrapping_add(u64::from(pass).wrapping_mul(0x9e3779b97f4a7c15))
}

fn shuffled_order(count: usize, mut state: u64) -> Vec<usize> {
    let mut order: Vec<_> = (0..count).collect();
    for i in (1..count).rev() {
        state = state.wrapping_add(0x9e3779b97f4a7c15);
        let mut bits = state;
        bits = (bits ^ (bits >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
        bits = (bits ^ (bits >> 27)).wrapping_mul(0x94d049bb133111eb);
        bits ^= bits >> 31;
        order.swap(i, (bits % (i as u64 + 1)) as usize);
    }
    order
}

/// The initial construction. A [`Rejected`] one retries with derived seeds, so
/// a collision the engine missed never ends the search before it has a layout.
fn initial_construction(
    prepared: &PreparedJob<'_>,
    construct: ConstructOptions,
    control: &mut Control<'_>,
) -> Result<Construction> {
    let mut attempt = 0;
    loop {
        let options = ConstructOptions {
            seed: if attempt == 0 {
                construct.seed
            } else {
                seed(construct.seed ^ 0x5851f42d4c957f2d, attempt)
            },
            ..construct
        };
        match prepared.construct_ordered(options, None, None, Refinement::None, control) {
            Err(error) if error.is::<Rejected>() && attempt < 7 => attempt += 1,
            other => return other,
        }
    }
}

fn better(candidate: &Metrics, incumbent: &Metrics, mode: Mode) -> bool {
    match mode {
        Mode::All => {
            candidate.sheets_used < incumbent.sheets_used
                || (candidate.sheets_used == incumbent.sheets_used
                    && candidate.material_area < incumbent.material_area)
        }
        Mode::FillArea => {
            candidate.placed_area > incumbent.placed_area
                || (candidate.placed_area == incumbent.placed_area
                    && candidate.material_area < incumbent.material_area)
        }
        Mode::FillPriority => {
            candidate.placed_priority > incumbent.placed_priority
                || (candidate.placed_priority == incumbent.placed_priority
                    && (candidate.placed_area > incumbent.placed_area
                        || (candidate.placed_area == incumbent.placed_area
                            && candidate.material_area < incumbent.material_area)))
        }
    }
}

/// Run every declared pass and retain the independently valid incumbent. Failed
/// attempts remain in history; a sheet-removal attempt never relaxes stock caps.
/// At six or more passes, compression first tries three progressively smaller
/// reductions of the last-sheet height. Up to twelve further attempts repeat
/// successful reductions, decreasing the step after failure. No repacking pass
/// is replaced. Finishing runs every 64 passes and at the requested last pass,
/// sharing the same control as the main search. Runs through 64 passes preserve
/// the earlier schedule; longer runs retain its checked incumbent.
/// This fixed-pass API has no time-budget promise. Use `optimize_controlled` for
/// a deterministic collision limit or cooperative cancellation/deadline hook.
pub fn optimize(
    job: &Job,
    options: Options,
    progress: impl FnMut(&Progress),
) -> Result<SearchResult> {
    optimize_controlled(job, options, &mut Control::unlimited(), progress)
}

/// Interrupt a search at cooperative checkpoints and retain only its last
/// independently checked incumbent. If interrupted before the initial layout,
/// return a typed `Interrupted` error; no partially constructed layout escapes.
/// Geometry operations and independent validation finish before yielding.
pub fn optimize_controlled(
    job: &Job,
    options: Options,
    control: &mut Control<'_>,
    progress: impl FnMut(&Progress),
) -> Result<SearchResult> {
    optimize_controlled_scored(job, options, control, None, progress)
}

pub(crate) fn optimize_controlled_scored(
    job: &Job,
    options: Options,
    control: &mut Control<'_>,
    material: Option<&crate::scoring::MaterialAreas>,
    mut progress: impl FnMut(&Progress),
) -> Result<SearchResult> {
    ensure!(
        (1..=1024).contains(&options.passes),
        "search needs 1..=1024 passes"
    );
    let debug_started = std::env::var_os("NESTBOLT_DEBUG").map(|_| jagua_rs::Instant::now());
    let prepared = PreparedJob::new_controlled_scored(job, material, control)?;
    let check_layout = |layout: &nestbolt_validator::job::Layout| -> Result<Report> {
        let mut report = validate(job, layout)?;
        if let Some(material) = material {
            material.apply(layout, &mut report)?;
        }
        Ok(report)
    };
    if let Some(started) = debug_started {
        eprintln!(
            "debug warm prepared: {:.2} s",
            started.elapsed().as_secs_f64()
        );
    }
    let mut best = initial_construction(&prepared, options.construct, control)?;
    if let Some(started) = debug_started {
        eprintln!(
            "debug warm constructed: {:.2} s",
            started.elapsed().as_secs_f64()
        );
    }
    let mut validation = check_layout(&best.layout)?;
    if let Some(started) = debug_started {
        eprintln!(
            "debug warm validated: {:.2} s",
            started.elapsed().as_secs_f64()
        );
    }
    let mut history = vec![];
    // Preserve the complete original 64-pass portfolio and its finishing trials.
    // Longer runs continue from that checked incumbent in further 64-pass blocks.
    let mut polishing = vec![];
    let mut finish = |best: &mut Construction,
                      validation: &mut Report,
                      pass_end: u32,
                      control: &mut Control<'_>,
                      progress: &mut dyn FnMut(&Progress)|
     -> Result<()> {
        if validation.valid && !best.layout.sheets.is_empty() {
            let first_trial = polishing.len();
            let fractions = [0.03, 0.01, 0.003];
            let mut repeated_fraction = 0;
            for step in 0..15 {
                // Failed initial trials give no evidence of compressible space.
                // Avoid repeating the expensive restore/validation work in that case.
                if step == 3
                    && !polishing[first_trial..]
                        .iter()
                        .any(|p: &Progress| p.accepted)
                {
                    break;
                }
                if control.checkpoint().is_err() {
                    break;
                }
                // Preserve the first three trials and their random streams exactly.
                // Continuing from that incumbent cannot undo their accepted gains.
                let fraction = fractions[if step < 3 { step } else { repeated_fraction }];
                let pass = pass_end + step as u32;
                let trial_seed = seed(options.construct.seed, pass);
                let before = control.collision_checks();
                let candidate =
                    match prepared.compress_last_sheet(&best.layout, fraction, trial_seed, control)
                    {
                        Err(error) if error.is::<Interrupted>() => break,
                        Err(error) if error.is::<Rejected>() => None,
                        other => other?,
                    };
                let checked = candidate
                    .as_ref()
                    .map(|c| check_layout(&c.layout))
                    .transpose()?;
                let metrics = checked.as_ref().and_then(|c| c.metrics.as_ref());
                let accepted = checked.as_ref().is_some_and(|r| r.valid)
                    && metrics
                        .is_some_and(|m| better(m, validation.metrics.as_ref().unwrap(), job.mode));
                let entry = Progress {
                    pass,
                    stage: "compress-last-sheet",
                    contact_search: false,
                    interleaved_copies: false,
                    seed: trial_seed,
                    sheet_limit: None,
                    complete: candidate.is_some(),
                    accepted,
                    sheets: candidate
                        .as_ref()
                        .map_or(best.layout.sheets.len(), |c| c.layout.sheets.len()),
                    material: metrics.map(|m| m.normalized_material),
                    placed_area: metrics.map(|m| m.placed_area),
                    placed_priority: metrics.map(|m| m.placed_priority),
                    collision_checks: control.collision_checks() - before,
                };
                if accepted {
                    *best = candidate.unwrap();
                    *validation = checked.unwrap();
                }
                progress(&entry);
                polishing.push(entry);
                if step >= 3 && !accepted {
                    repeated_fraction += 1;
                    if repeated_fraction == fractions.len() {
                        break;
                    }
                }
            }
        }
        Ok(())
    };
    for pass in 0..options.passes {
        // Pass zero records the completed initial construction. After that,
        // interruption leaves its complete, validated incumbent untouched.
        if pass > 0 && control.checkpoint().is_err() {
            break;
        }
        // Compare refinement to the initial constructor before changing its
        // ordering or random stream. Later passes explore new orders and caps.
        let portfolio_pass = if pass < 64 {
            pass
        } else {
            64 + (pass - 64) / 2
        };
        let diversified = pass >= 64 && pass % 2 == 1;
        let trial_seed = seed(
            options.construct.seed,
            if pass <= 2 { 0 } else { portfolio_pass },
        );
        let sheet_limit = if portfolio_pass >= 3
            && portfolio_pass % 3 == 0
            && job.mode == Mode::All
            && validation.valid
            && best.layout.sheets.len() > 1
        {
            Some(best.layout.sheets.len() - 1)
        } else {
            None
        };
        let repairing = !diversified && sheet_limit.is_some() && portfolio_pass % 6 == 3;
        let refinement = if pass == 0 {
            Refinement::None
        } else if diversified {
            Refinement::Diversified {
                right: portfolio_pass % 4 < 2,
            }
        } else if repairing || portfolio_pass % 2 == 0 {
            Refinement::Contacts
        } else {
            Refinement::Translation
        };
        let interleaved_copies = !repairing && portfolio_pass >= 3 && portfolio_pass % 4 >= 2;
        let attempted = if pass == 0 {
            Ok(None)
        } else if repairing {
            prepared
                .repair_ranked(
                    &best.layout,
                    (portfolio_pass / 6) as usize,
                    ConstructOptions {
                        seed: trial_seed,
                        ..options.construct
                    },
                    control,
                )
                .map(Some)
        } else {
            let grouped: Vec<_> = shuffled_order(job.parts.len(), trial_seed)
                .into_iter()
                .flat_map(|index| (0..job.parts[index].quantity).map(move |copy| (index, copy)))
                .collect();
            let order = if interleaved_copies {
                shuffled_order(grouped.len(), trial_seed ^ 0xd1b54a32d192ed03)
                    .into_iter()
                    .map(|index| grouped[index])
                    .collect()
            } else {
                grouped
            };
            prepared
                .construct_ordered(
                    ConstructOptions {
                        seed: trial_seed,
                        ..options.construct
                    },
                    if pass <= 2 { None } else { Some(&order) },
                    sheet_limit,
                    refinement,
                    control,
                )
                .map(Some)
        };
        let mut rejected = false;
        let mut candidate = match attempted {
            Err(error) if error.is::<Interrupted>() => break,
            Err(error) if error.is::<Rejected>() => {
                rejected = true;
                None
            }
            other => other?,
        };
        let checked = if let Some(ref c) = candidate {
            Some(check_layout(&c.layout)?)
        } else {
            None
        };
        let report = checked.as_ref().unwrap_or(&validation);
        let current = candidate.as_ref().unwrap_or(&best);
        let accepted = report.valid
            && (pass == 0
                || !validation.valid
                || better(
                    report.metrics.as_ref().expect("valid metrics"),
                    validation
                        .metrics
                        .as_ref()
                        .expect("valid incumbent metrics"),
                    job.mode,
                ));
        let metrics = report.metrics.as_ref();
        let entry = Progress {
            pass,
            stage: if pass == 0 {
                "construct"
            } else if rejected {
                "rejected"
            } else if pass == 1 {
                "refine"
            } else if pass == 2 {
                "contacts"
            } else if repairing {
                "repair-sheet"
            } else if sheet_limit.is_some() {
                "remove-sheet"
            } else {
                "repack"
            },
            contact_search: matches!(
                refinement,
                Refinement::Contacts | Refinement::Diversified { .. }
            ),
            interleaved_copies,
            seed: trial_seed,
            sheet_limit,
            complete: current.complete && !rejected,
            accepted,
            sheets: current.layout.sheets.len(),
            material: metrics.filter(|_| !rejected).map(|m| m.normalized_material),
            placed_area: metrics.filter(|_| !rejected).map(|m| m.placed_area),
            placed_priority: metrics.filter(|_| !rejected).map(|m| m.placed_priority),
            collision_checks: current.collision_checks,
        };
        if pass > 0 && accepted {
            best = candidate.take().expect("later pass has candidate");
            validation = checked.expect("candidate checked");
        }
        progress(&entry);
        history.push(entry);
        if options.passes >= 6 && ((pass + 1) % 64 == 0 || pass + 1 == options.passes) {
            finish(&mut best, &mut validation, pass + 1, control, &mut progress)?;
        }
    }
    Ok(SearchResult {
        algorithm: "nestbolt-repack-v18",
        seed: options.construct.seed,
        requested_passes: options.passes,
        completed_passes: history.len() as u32,
        best,
        validation,
        history,
        polishing,
        collision_checks: control.collision_checks(),
        stopped: control.stop_reason(),
    })
}
