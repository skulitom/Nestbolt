"""Authored fixed-work CLI parity/replay on CCD1; not packing performance."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys

import psutil

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from cutting_development_set import public_inputs, write_json

OUT = ROOT/'output/h5-exchange-probe'
WORK = OUT/'public-work-v7'
BASELINE = ROOT/'target/release/nestbolt.exe'
CANDIDATE = OUT/'nestbolt-exchange.exe'
assert not WORK.exists()
assert json.loads((OUT/'release-build-v7.json').read_bytes())['exit_code'] == 0
shutil.copyfile(ROOT/'output/ci-curve-probe/target/release/nestbolt.exe', CANDIDATE)
WORK.mkdir()
psutil.Process().cpu_affinity(list(range(16,32)))

def rect(w,h):
    return [[0,0],[w,0],[w,h],[0,h]]

job = {'version':1,'name':'authored exchange public checks','units':'mm','clearance':0.2,
       'edge_clearance':1.0,'mode':'all','parts':[], 'stocks':[{'id':'sheet','width':120.0,'height':90.0,
       'count':None,'margins':{'left':0.0,'right':0.0,'bottom':0.0,'top':0.0},'outline':[],'defects':[]}]}
for name, quantity, ring, holes in [
    ('frame',4,rect(50,50),[[[10,10],[40,10],[40,40],[10,40]]]),
    ('insert',12,rect(10,10),[]),
    ('bracket',8,[[0,0],[20,0],[20,5],[5,5],[5,20],[0,20]],[]),
]:
    job['parts'].append({'id':name,'quantity':quantity,'geometry':[{'outer':ring,'holes':holes}],
        'rotations':{'kind':'list','degrees':[0.0,90.0]},'allow_mirror':True,'priority':1.0})
write_json(WORK/'job.json',job)
library, common = public_inputs(job,0.2,False)
normal=deepcopy(common); normal.pop('common_line')
write_json(WORK/'library.json',library)
write_json(WORK/'normal.json',normal)
write_json(WORK/'common.json',common)
records=[]

def run(binary, mode, seed, label):
    folder=WORK/f'{mode}-s{seed}-{label}'
    cmd=[str(binary),'nest','--library',str(WORK/'library.json'),'--request',str(WORK/f'{mode}.json'),
         '--out-dir',str(folder),'--seconds','3','--seed',str(seed),'--repeatable','--time-limit','30']
    result=subprocess.run(cmd,capture_output=True)
    (WORK/f'{folder.name}-stdout.txt').write_bytes(result.stdout)
    (WORK/f'{folder.name}-stderr.txt').write_bytes(result.stderr)
    assert result.returncode==0,(folder.name,result.stderr.decode(errors='replace'))
    report=json.loads((folder/'report.json').read_bytes())
    assert report['repeatable'] and report['validation']['valid']
    check=subprocess.run([str(BASELINE),'validate','--library',str(WORK/'library.json'),'--request',str(WORK/f'{mode}.json'),
                          '--layout',str(folder/'layout.json')],capture_output=True)
    (folder/'independent-stdout.json').write_bytes(check.stdout)
    (folder/'independent-stderr.txt').write_bytes(check.stderr)
    assert check.returncode==0 and json.loads(check.stdout)['valid']
    if mode=='common': assert report['parts_in_holes']==0
    record={'mode':mode,'seed':seed,'label':label,'binary_sha256':sha256(binary.read_bytes()).hexdigest(),
            'valid':True,'repeatable':True,'parts_in_holes':report['parts_in_holes'],
            'files':{p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(folder.iterdir())
                     if p.name in ['job.json','layout.json'] or p.suffix in ['.svg','.dxf']}}
    records.append(record)
    write_json(OUT/'public-progress-v7.json',records)
    return record

for seed in [0,1]:
    baseline=run(BASELINE,'normal',seed,'baseline')
    candidate=run(CANDIDATE,'normal',seed,'candidate')
    assert baseline['files']==candidate['files'], 'Ordinary mode changed under a fixed work budget'
    first=run(CANDIDATE,'common',seed,'first')
    replay=run(CANDIDATE,'common',seed,'replay')
    assert first['files']==replay['files'], 'Common mode failed fixed-work replay'
write_json(OUT/'public-checks-v7.json',{'scope':__doc__,'all_checks_pass':True,
    'normal_layout_and_exports_byte_identical':True,'common_layout_and_exports_replay_exactly':True,
    'all_independently_valid':True,'held_out_inputs_read':False,'records':records})
print(json.dumps({'runs':len(records),'all_checks_pass':True,'normal_hole_riders':[r['parts_in_holes'] for r in records if r['mode']=='normal']}))
