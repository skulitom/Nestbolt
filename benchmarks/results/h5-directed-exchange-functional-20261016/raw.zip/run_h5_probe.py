"""Preserve each functional check and candidate snapshot on CCD1."""
import datetime
import json
import pathlib
import subprocess
import sys
import zipfile

root = pathlib.Path(__file__).resolve().parents[1]
out = root / 'output/h5-exchange-probe'
name = sys.argv[1]
log = out / f'{name}.log'
assert not log.exists(), log
sources = ['crates/core/src/sheets.rs', 'crates/core/src/sheets/vstrip.rs',
           'crates/core/src/sheets/vstrip/exchange.rs']
with zipfile.ZipFile(out / f'{name}-sources.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
    for source in sources:
        archive.write(out / 'workspace' / source, source)
command = [sys.executable, str(root / 'output/ccd1.py'), *sys.argv[2:]]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('wb') as stream:
    result = subprocess.run(command, cwd=out / 'workspace', stdout=stream, stderr=subprocess.STDOUT)
(out / f'{name}.json').write_text(json.dumps({'command': command, 'started': started,
    'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': result.returncode,
    'scope': 'Functional check; not performance evidence'}, indent=2) + '\n', encoding='utf-8')
print(log.read_text(encoding='utf-8', errors='replace')[-10000:])
raise SystemExit(result.returncode)
