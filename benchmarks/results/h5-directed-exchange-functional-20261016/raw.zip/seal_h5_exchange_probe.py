"""Seal the isolated functional experiment without integrating or timing it."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'output/h5-exchange-probe'
OUT=ROOT/'benchmarks/results/h5-directed-exchange-functional-20261016'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not OUT.exists()
baseline=load(SOURCE/'baseline.json')
changed=[]
for row in baseline['files']:
    assert digest(ROOT/row['path'])==row['sha256'], ('Production source changed',row['path'])
    if digest(SOURCE/'workspace'/row['path'])!=row['sha256']:
        changed.append(row['path'])
assert changed==['crates/core/src/sheets.rs','crates/core/src/sheets/vstrip.rs']
added='crates/core/src/sheets/vstrip/exchange.rs'
assert (SOURCE/'workspace'/added).is_file()
for name in ['functional-v5','lint-focused-v7','core-common-v7','release-build-v7']:
    assert load(SOURCE/(name+'.json'))['exit_code']==0
public=load(SOURCE/'public-checks-v7.json')
assert public['all_checks_pass'] and len(public['records'])==8
assert {r['binary_sha256'] for r in public['records'] if r['label']=='baseline'}=={digest(ROOT/'target/release/nestbolt.exe')}
assert {r['binary_sha256'] for r in public['records'] if r['label']!='baseline'}=={digest(SOURCE/'nestbolt-exchange.exe')}
sys.path.insert(0,str(ROOT/'scripts'))
import h4_preview_matrix as h4
rows,_,_=h4.cases()
h4plan=load(ROOT/'benchmarks/results/h4-preview-development-20261016/plan.json')
assert h4.guards(rows)==h4plan['guards']
OUT.mkdir()
shutil.copyfile(ROOT/'target/release/nestbolt.exe',SOURCE/'nestbolt-baseline.exe')
for name in ['prepare_h5_exchange_probe.py','run_h5_probe.py','check_h5_exchange_public.py','seal_h5_exchange_probe.py']:
    shutil.copyfile(ROOT/'output'/name,SOURCE/name)
sources={name:digest(SOURCE/'workspace'/name) for name in changed+[added]}
checks={'scope':__doc__,'baseline_commit':baseline['head'],'production_unchanged':True,
    'current_H4_source_build_input_guards_unchanged':True,'changed_existing_sources':changed,
    'added_source':added,'candidate_source_sha256':sources,
    'baseline_binary_sha256':digest(SOURCE/'nestbolt-baseline.exe'),
    'candidate_binary_sha256':digest(SOURCE/'nestbolt-exchange.exe'),
    'focused_tests':6,'authored_scenarios':11,'authored_successful_exchanges':7,
    'core_tests_passed':80,'core_tests_existing_ignored':1,'common_geometry_tests_passed':6,
    'strict_lint_scope':'nestbolt-core --lib --test common_line',
    'public_fixed_work_runs':8,'public_checks':public,
    'failed_attempts_preserved':['compile-v1','functional-v2','functional-v3','functional-v4','lint-v5','lint-v6'],
    'measured_on_CCD0':False,'performance_improvement_established':False,'H5_complete':False,
    'held_out_geometry_read':False,'integrated':False,'completed_milestone_weight_percent':45}
write(OUT/'checks.json',checks)
archive=OUT/'raw.zip'
inventory={}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(SOURCE.rglob('*')):
        if not path.is_file(): continue
        member=path.relative_to(SOURCE).as_posix()
        inventory[member]={'sha256':digest(path),'bytes':path.stat().st_size}
        z.write(path,member)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,expected in inventory.items():
        raw=z.read(name)
        assert len(raw)==expected['bytes'] and sha256(raw).hexdigest()==expected['sha256']
write(OUT/'integrity.json',{'sha256':digest(archive),'bytes':archive.stat().st_size,
    'members':inventory,'crc_and_every_member_verified':True})
text=f'''# Directed common-line exchange: isolated functional evidence

The isolated candidate passes six focused tests, 80 core unit tests (one existing
ignored test), six common-line geometry tests, strict lint for the library and
common-line integration target, and eight authored public-CLI checks.
**This is not a packing comparison or an H5 pass.** The release candidate and
all active H4 source, executable, site and input guards remain unchanged.

The candidate is based on `{baseline['head']}`. It changes only `sheets.rs`,
`sheets/vstrip.rs` and the new `sheets/vstrip/exchange.rs` in an isolated workspace.
It is not integrated into production. Builds and functional checks used CCD1
(logical CPUs 16–31), outside the active measurement's CCD0 lanes.

## Operation and constraints

From a feasible stalled window, try inserting a last-sheet part into one of
three earlier receivers. Proposals identify actual collision hazards and reject
static hazards. A smaller blocking part returns to the last sheet. At most six
proposals are retained per receiver; receiver and source repairs share bounded
slices of the existing relocation allowance. The source keeps its current
shortened boundary. Failed repairs leave the original separator untouched.

Before accepting an exchange, the complete job, including frozen sheets, passes
the independent validator with no increase in material area or sheet count.
The operation reserves check time, charges deterministic work, respects rotation
and reflection rules, and keeps the existing independently valid incumbent.
It is enabled only when the caller reserves part holes; ordinary part-in-hole
search keeps its existing path. No gate, tolerance, default or frozen input changes.

The six focused tests cover eleven authored scenarios: seven successful
exchanges and four refusals/no-ops. They check a smaller actual obstruction,
seeds 0–4, a frozen sheet and allowed reflection, stock defects, expired/disabled
calls, larger return parts and an impossible source repair. Frozen-sheet
placements and failed-call state compare exactly in the same internal frame.
The complete original geometry, counts and material are independently checked.

The public checks use a newly authored frame/insert/bracket job and fixed work
budgets, seeds 0 and 1. Ordinary baseline and candidate layout, job, SVG and DXF
bytes match exactly; both retain twelve hole riders. Candidate common-line
replays also match those files exactly and report zero hole riders. All eight
layouts pass the unchanged production validator. These are functional and
repeatability checks, not wall-clock quality or speed measurements.

## Retained failures and scope

- Initial compile errors involved flag scope, method visibility and a Rust
  borrow; the same first failure was captured before repair.
- The first test build lacked the existing compile-time validation example;
  its unchanged tracked bytes were added to the isolated workspace.
- Two initial assertions compared authored f64 coordinates with the pre-existing
  f32 frame conversion. They now compare the exact state before and after this
  operation in the same frame, with no widened numeric tolerance.
- The first defect fixture requested an unsupported relation between edge and
  part clearance. The fixture now uses the supported equal-clearance case.
- Two broad lint attempts lacked unrelated compile-time examples/development
  fixtures. Their failures remain. The final strict lint scope is explicitly the
  library and common-line target; this report does not claim a full workspace lint.

All original logs, source snapshots, public inputs/results, helpers, final source
tree and both executables are in the verified archive. The existing production
workspace checks remain separate evidence.

The next decision requires a committed, equal-budget development comparison
against the unchanged preview binary after H4 quality and scale release the
measurement cores. Include both failed mechanical jobs, both kerfs, all three
development seeds and controls; keep every outcome. Do not infer that this
authored success fixes the retained +1% material failures. H5 remains open and
completed milestone weight remains 45%.

Baseline CLI SHA-256: `{checks['baseline_binary_sha256']}`. Candidate CLI:
`{checks['candidate_binary_sha256']}`. Raw archive: {len(inventory)} members,
{archive.stat().st_size:,} bytes, SHA-256 `{digest(archive)}`; CRC and every member
hash were checked. [Checks](h5-directed-exchange-functional-20261016/checks.json)
and [archive inventory](h5-directed-exchange-functional-20261016/integrity.json).
'''
(OUT.parent/(OUT.name+'.md')).write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'folder':str(OUT),'members':len(inventory),'archive_bytes':archive.stat().st_size,
    'archive_sha256':digest(archive),'candidate_binary_sha256':checks['candidate_binary_sha256']},indent=2))
