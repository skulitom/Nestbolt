"""Create an isolated, source-bound functional probe; do not touch release build."""
import hashlib
import json
import pathlib
import shutil
import subprocess

root = pathlib.Path(__file__).resolve().parents[1]
out = root / 'output/h5-exchange-probe'
workspace = out / 'workspace'
assert not workspace.exists(), 'Preserve an existing experiment rather than overwrite it'
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
chosen = [p for p in paths if p.startswith(('crates/', '.cargo/')) or p in
          ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'LICENSE', 'THIRD_PARTY_NOTICES')]
records = []
for name in chosen:
    source, target = root / name, workspace / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    records.append({'path': name, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
out.mkdir(exist_ok=True)
(out / 'baseline.json').write_text(json.dumps({
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(),
    'scope': 'Authored functional checks on CCD1 only; no measured packing comparison, no reserved inputs',
    'hypothesis': 'A directed exchange can move a last-sheet part into a receiver by returning a smaller actual obstruction, repairing both sheets and independently rejecting material regression.',
    'files': records,
}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(f'Copied {len(records)} tracked files into {workspace}')
