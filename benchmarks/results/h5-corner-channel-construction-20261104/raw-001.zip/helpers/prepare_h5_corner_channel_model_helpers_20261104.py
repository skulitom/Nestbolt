from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OLD='h5-first55-local-grid-regions-20261029';NEW='h5-first55-corner-channel-regions-20261104'
PROCESS="ROOT/'output/h5-corner-channel-preparation-process-20261104'"
def write(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/build_h5_local_grid_model_20261029.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace('load=lambda p:', 'PREPARATION_PROCESS='+PROCESS+'\nload=lambda p:',1)
s=s.replace('len(forbidden)==70','len(forbidden)==104').replace('cp_model.INT_MIN,-3,selector','cp_model.INT_MIN,-23,selector').replace("'rectangle_gap_grid':3","'rectangle_gap_grid':23").replace("'position_units_per_mm':10","'position_units_per_mm':100")
s=s.replace("'accessible_area_bound_seconds':load(PRIOR/'accessible-area-bound/checks.json')['seconds'],'connected_capacity_bound_seconds':load(PRIOR/'connected-capacity-bound/checks.json')['seconds'],'local_grid_preparation_seconds':load(BASE/'checks.json')['seconds']", "'corner_channel_complete_preparation_seconds':load(PREPARATION_PROCESS/'process.json')['complete_process_seconds']")
s=s.replace("inputs=[Path(__file__),", "inputs=[Path(__file__),PREPARATION_PROCESS/'opened.json',PREPARATION_PROCESS/'process.json',",1)
s=s.replace(",'accessible-area-bound/checks.json','connected-capacity-bound/checks.json'",'')
a=s.index("'method':");b=s.index(",'algorithm_seconds':",a)
s=s[:a]+"'method':'Construct all13 original moving owners, all80 source modes and the single corner-channel choice selected from cog geometry. Local0.01mm positions imply unchanged original source hulls. All20 outward component rectangles remain rigidly attached through mode equalities; every one of183 different-owner pairs requires0.23mm axis clearance. Same-family X order removes interchangeable-copy symmetry. No component count or capacity table is used, and no objective or hints are supplied. Independently audit every field before one60/90-second call. Charge complete geometry selection/preparation, short11 construction, source masks/rectangles and complete model-build process. All earlier calls remain closed.'"+s[b:]
s=s.replace("'retained_empty_site_pairs':35,'forbidden_site_pair_constraints':70", "'retained_empty_site_pairs':1,'forbidden_site_pair_constraints':104,'count_capacity_tables_used':False")
write('build_h5_corner_channel_model_20261104.py',s)

s=(ROOT/'output/audit_h5_local_grid_model_20261029.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace('load=lambda p:', 'PREPARATION_PROCESS='+PROCESS+";FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'\nload=lambda p:",1)
s=s.replace(" and len(p.variables)==8336 and len(p.constraints)==43571",'')
anchor="owners=mapping['owners']"
s=s.replace(anchor,anchor+"\nexpected_unary=sum(len(unary[g]['regions']) for o in owners for g in {m['normalized_geometry'] for m in modes[o['identity'][0]]});rectangle_start=121+expected_unary;direction_start=rectangle_start+80")
s=s.replace("mapping['position_units_per_mm']==10","mapping['position_units_per_mm']==100").replace("mapping['rectangle_gap_grid']==3","mapping['rectangle_gap_grid']==23")
s=s.replace('len(allowed)==35','len(allowed)==1').replace('len(expected_forbidden)==70','len(expected_forbidden)==104')
s=s.replace('121<=selector<7524','121<=selector<rectangle_start').replace('range(7524+4*ci,7528+4*ci)','range(rectangle_start+4*ci,rectangle_start+4*ci+4)').replace('range(7604+4*index,7608+4*index)','range(direction_start+4*index,direction_start+4*index+4)')
s=s.replace('MIN,-3,vi','MIN,-23,vi')
s=s.replace('used_vars==set(range(8336)) and used_ct==set(range(43571)) and mode_count==80 and unary_count==7403 and unary_planes==30208 and mask_links==11568',"used_vars==set(range(len(p.variables))) and used_ct==set(range(len(p.constraints))) and len(p.variables)==direction_start+732 and mode_count==80 and unary_count==expected_unary")
anchor="assert load(MODEL/'checks.json')['preparation_seconds_charged']==sum(load(MODEL/'preparation-charges.json').values())"
extra="""
expected_charges={'source_valid_short11_shared_seconds':load(SHORT/'response-audit/checks.json')['shared_seconds_including_preparation'],'fixed_first_sheet_preparation_seconds':load(FIRST/'checks.json')['seconds'],'cog_site_selection_preparation_seconds':load(SLOTS/'checks.json')['seconds'],'site_mask_region_preparation_seconds':load(PRIOR/'checks.json')['seconds'],'source_rigid_rectangle_preparation_seconds':load(PRIOR/'rigid-rectangle-preflight/checks.json')['seconds'],'source_mask_integer_preparation_seconds':load(PRIOR/'integer-preparation/checks.json')['seconds'],'corner_channel_complete_preparation_seconds':load(PREPARATION_PROCESS/'process.json')['complete_process_seconds'],'cp_model_build_seconds':load(MODEL/'checks.json')['seconds']}
assert load(MODEL/'preparation-charges.json')==expected_charges
process=load(MODEL/'build-process.json');assert process['exit_code']==0 and process['complete_process_seconds']>=expected_charges['cp_model_build_seconds']
expected_charges['cp_model_build_seconds']=process['complete_process_seconds'];assert load(MODEL/'final-preparation-charges.json')==expected_charges and load(MODEL/'budget.json')['preparation_seconds_charged']==sum(expected_charges.values())
assert load(BASE/'geometry-audit/checks.json')['selection_uses_only_cog_geometry'] and not load(BASE/'geometry-audit/checks.json')['count_capacity_tables_used']
for family in ['bracket','insert']:
    peers=[o for o in owners if o['identity'][0]==family];reference=peers[0]
    for o in peers:
        assert [list(p.variables[v].domain) for v in o['positions']]==[list(p.variables[v].domain) for v in reference['positions']]
        assert [(r['geometry'],r['region'],r['required_empty_sites']) for r in o['unary_regions']]==[(r['geometry'],r['region'],r['required_empty_sites']) for r in reference['unary_regions']]
        assert [{k:v for k,v in m.items() if k not in ['selector','stock_constraints']} for m in o['modes']]==[{k:v for k,v in m.items() if k not in ['selector','stock_constraints']} for m in reference['modes']]
assert [r['components'] for r in separations]==[list(t) for t in combinations(range(20),2) if components[t[0]]['owner']!=components[t[1]]['owner']]
"""
assert anchor in s;s=s.replace(anchor,anchor+extra)
s=s.replace("inputs=[Path(__file__),", "inputs=[Path(__file__),MODEL/'build-process.json',MODEL/'budget.json',MODEL/'final-preparation-charges.json',PREPARATION_PROCESS/'opened.json',PREPARATION_PROCESS/'process.json',",1)
s=s.replace("'all35_remaining_empty_site_pairs_represented':True,'forbidden_site_pairs_verified':70", "'corner_channel_choice_verified':True,'count_capacity_tables_used':False,'interchangeable_copy_X_order_verified':True,'complete_preparation_seconds_charged':sum(expected_charges.values()),'forbidden_site_pairs_verified':104")
write('audit_h5_corner_channel_model_20261104.py',s)

s=(ROOT/'output/check_h5_local_grid_candidate_20261029.py').read_text(encoding='utf-8').replace(OLD,NEW)
write('check_h5_corner_channel_candidate_20261104.py',s)
s=(ROOT/'output/run_h5_local_grid_model_20261029.py').read_text(encoding='utf-8').replace(OLD,NEW).replace('check_h5_local_grid_candidate_20261029.py','check_h5_corner_channel_candidate_20261104.py')
s=s.replace("load(MODEL / 'checks.json')['preparation_seconds_charged']", "load(MODEL / 'budget.json')['preparation_seconds_charged']")
s=s.replace("MODEL / 'plan.json', MODEL / 'model.pb'", "MODEL / 'plan.json', MODEL / 'budget.json', MODEL / 'final-preparation-charges.json', MODEL / 'build-process.json', MODEL / 'model.pb'")
write('run_h5_corner_channel_model_20261104.py',s)
