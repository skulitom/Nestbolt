"""Measure the complete model build and finalize its charged budget before audit."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];MODEL=ROOT/'output/h5-first55-corner-channel-regions-20261104/model';SCRIPT=ROOT/'output/build_h5_corner_channel_model_20261104.py'
assert not MODEL.exists();started=time.perf_counter()
r=subprocess.run(['python',str(ROOT/'output/ccd1.py'),str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(SCRIPT)],cwd=ROOT,capture_output=True,timeout=60);elapsed=time.perf_counter()-started
assert MODEL.exists();(MODEL/'build-stdout.txt').write_bytes(r.stdout);(MODEL/'build-stderr.txt').write_bytes(r.stderr)
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
write(MODEL/'build-process.json',{'utc':datetime.now(timezone.utc).isoformat(),'script_sha256':sha256(SCRIPT.read_bytes()).hexdigest(),'complete_process_seconds':elapsed,'exit_code':r.returncode,'inputs':{p.relative_to(ROOT).as_posix():sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),SCRIPT]}})
assert r.returncode==0,r.stderr.decode(errors='replace')
charges=json.loads((MODEL/'preparation-charges.json').read_bytes());assert elapsed>=charges['cp_model_build_seconds'];charges['cp_model_build_seconds']=elapsed
write(MODEL/'final-preparation-charges.json',charges);write(MODEL/'budget.json',{'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False,'preparation_seconds_charged':sum(charges.values()),'complete_geometry_and_model_process_times_charged':True,'count_capacity_tables_used':False})
print(r.stdout.decode(errors='replace'));print({'complete_model_build_seconds':elapsed,'complete_preparation_seconds_charged':sum(charges.values())})
