"""A new positive construction: choose a corner channel directly from cog-site geometry."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OLD='h5-first55-fine-grid-regions-20261104';NEW='h5-first55-corner-channel-regions-20261104'
SLOTS="ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight'"
def write(name,s):
    p=ROOT/'output'/name;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/prepare_h5_fine_grid_regions_20261104.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace(";OUT=ROOT/'output/"+NEW+"'", ";SLOTS="+SLOTS+";OUT=ROOT/'output/"+NEW+"'")
s=s.replace(" and load(PRIOR/'connected-capacity-bound/audit/checks.json')['passed']",'')
old="allowed=load(PRIOR/'connected-capacity-bound/audit/allowed-empty-site-pairs.json');allowed_masks=[sum(1<<i for i in pair) for pair in allowed]"
new="sites=load(SLOTS/'source-cog-sites.json');levels=sorted({F(str(r['transform']['translation'][1])) for r in sites});assert len(levels)==3 and len(sites)==15\nrows=[[i for i,r in enumerate(sites) if F(str(r['transform']['translation'][1]))==level] for level in levels];assert all(len(row)==5 for row in rows)\nselected=sorted(min(row,key=lambda i:(F(str(sites[i]['transform']['translation'][0])),i)) for row in rows[-2:])\nallowed=[selected];allowed_masks=[sum(1<<i for i in selected)]\nwrite(OUT/'selection.json',{'method':'Choose the leftmost cog in each of the two rows farthest in positiveY from the fixed frame block, opening a corner channel. This is a positive construction heuristic; it excludes no other choice.','rows_by_increasing_y':rows,'row_y_mm':[str(y) for y in levels],'selected_empty_sites':selected,'count_capacity_tables_used':False})"
assert old in s;s=s.replace(old,new)
a=s.index('inputs=');b=s.index("\nwrite(OUT/'plan.json'",a)
s=s[:a]+"inputs=[Path(__file__),SLOTS/'plan.json',SLOTS/'checks.json',SLOTS/'source-cog-sites.json']+[PRIOR/n for n in ['plan.json','checks.json','family-modes.json','instances.json','inventory.json','integer-preparation/plan.json','integer-preparation/unary-templates.json','source-region-audit/plan.json','source-region-audit/checks.json','rigid-rectangle-preflight/plan.json','rigid-rectangle-preflight/mode-rectangles.json','rigid-rectangle-preflight/components.json','rigid-rectangle-preflight/component-pairs.json','rigid-rectangle-preflight/audit-v3/plan.json','rigid-rectangle-preflight/audit-v3/checks.json']]"+s[b:]
s=s.replace('Retain all source modes and all35 site choices.', 'Retain all original source modes for the corner-channel choice derived directly from the cog poses. Use no component count table or capacity filter.')
s=s.replace("'retained_empty_site_pairs':35", "'retained_empty_site_pairs':1,'selected_empty_sites':selected,'count_capacity_tables_used':False")
write('prepare_h5_corner_channel_regions_20261104.py',s)
s=(ROOT/'output/audit_h5_fine_grid_regions_20261104.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace(";OUT=BASE/'geometry-audit'", ";SLOTS="+SLOTS+";OUT=BASE/'geometry-audit'")
old="allowed=load(PRIOR/'connected-capacity-bound/audit/allowed-empty-site-pairs.json');assert len(allowed)==35 and allowed==load(BASE/'allowed-empty-site-pairs.json')"
new="sites=load(SLOTS/'source-cog-sites.json');by_y={}\nfor i,r in enumerate(sites):by_y.setdefault(F(str(r['transform']['translation'][1])),[]).append(i)\nordered=[by_y[y] for y in sorted(by_y)];assert len(ordered)==3 and all(len(r)==5 for r in ordered)\nchosen=sorted(sorted(r,key=lambda i:(F(str(sites[i]['transform']['translation'][0])),i))[0] for r in ordered[1:])\nallowed=[chosen];selection=load(BASE/'selection.json');assert allowed==load(BASE/'allowed-empty-site-pairs.json') and selection['selected_empty_sites']==chosen and selection['rows_by_increasing_y']==ordered and selection['row_y_mm']==[str(y) for y in sorted(by_y)] and not selection['count_capacity_tables_used']"
assert old in s;s=s.replace(old,new)
s=s.replace(" and len(removed)==527",'')
s=s.replace("'removed_regions_verified':527,'remaining_empty_site_pairs_verified':35", "'removed_regions_verified':len(removed),'remaining_empty_site_pairs_verified':1,'selected_empty_sites_verified':chosen,'selection_uses_only_cog_geometry':True,'count_capacity_tables_used':False")
s=s.replace("inputs=[Path(__file__)]", "inputs=[Path(__file__),SLOTS/'source-cog-sites.json',BASE/'selection.json']")
write('audit_h5_corner_channel_regions_20261104.py',s)
s=(ROOT/'output/run_h5_relative_bracket_pairs_20261104.py').read_text(encoding='utf-8').replace('h5-relative-bracket-pair-process-20261104','h5-corner-channel-preparation-process-20261104').replace('bound_h5_relative_bracket_pairs_20261104.py','prepare_h5_corner_channel_regions_20261104.py')
write('run_h5_corner_channel_preparation_20261104.py',s)
