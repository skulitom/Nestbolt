"""Seal the distinct geometry-selected corner-channel construction and closed call."""
from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-corner-channel-construction-20261104';OUT=ROOT/'benchmarks/results'/NAME;BASE=ROOT/'output/h5-first55-corner-channel-regions-20261104';PROCESS=ROOT/'output/h5-corner-channel-preparation-process-20261104'
PARENTS=[ROOT/'benchmarks/results'/n for n in ['h5-continuous-small-block-exclusions-20261104','h5-continuous-inserts-and-bracket-capacities-20261104','h5-direct-counts-and-relative-hull-capacities-20261104']]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
for folder in ['geometry-audit','model-audit','response-audit']:assert load(BASE/folder/'checks.json')['passed']
response=load(BASE/'response-audit/checks.json');assert response['solver_status']=='INFEASIBLE' and response['closed_solver_calls']==1 and response['assignments']==0 and response['overall_algorithm_shared_overruns_seconds']==0 and not response['continuous_source_domain_excluded']
parent_by_hash={}
for parent in PARENTS:
    assert load(parent/'archive-checks.json')['passed'];manifest=load(parent/'raw-manifest.json');h=digest(parent/'raw-manifest.json')
    for row in manifest['files']:parent_by_hash.setdefault((row['sha256'],row['bytes']),(parent,h,row))
OUT.mkdir();members={};external={};queue=[];seen=set();bindings={}
def traversable(p):return p.name in ['plan.json','opened.json'] or p.name.endswith('process.json')
def add(name,p):
    assert p.is_file() and p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts)
    h=digest(p);size=p.stat().st_size;prior=parent_by_hash.get((h,size))
    if prior:
        parent,mh,row=prior;external[name]={'manifest':(parent/'raw-manifest.json').relative_to(ROOT).as_posix(),'manifest_sha256':mh,'archive':row['archive'],'member':row['path'],'bytes':size,'sha256':h}
    else:members[name]=p
    if traversable(p) or p.suffix=='.py':queue.append(p)
for folder in [BASE,PROCESS]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for p in (ROOT/'output').glob('*h5*corner_channel*20261104.py'):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]:add('helpers/'+name,ROOT/'output'/name)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if traversable(p):
        data=load(p)
        for name,h in data.get('inputs',{}).items():
            z=ROOT/name;assert digest(z)==h,name;bindings[name]=h;add('source-inputs/'+name,z)
        if 'script' in data and 'script_sha256' in data:
            z=ROOT/data['script'];assert digest(z)==data['script_sha256'];bindings[data['script']]=data['script_sha256'];add('source-inputs/'+data['script'],z)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    z=ROOT/folder/(module+'.py')
                    if z.is_file():add('imported-helpers/'+folder+'/'+z.name,z)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'external-evidence.json',external);write(OUT/'source-bindings.json',bindings)
for source,name in [(BASE/'selection.json','selection.json'),(PROCESS/'process.json','geometry-process.json'),(BASE/'geometry-audit/checks.json','geometry-audit.json'),(BASE/'model/checks.json','model.json'),(BASE/'model/build-process.json','model-build-process.json'),(BASE/'model/final-preparation-charges.json','preparation-charges.json'),(BASE/'model/budget.json','budget.json'),(BASE/'model-audit/checks.json','model-audit.json'),(BASE/'response-audit/checks.json','response-audit.json')]:shutil.copyfile(source,OUT/name)
write(OUT/'next-step.json',{'closed_call_must_not_be_repeated':True,'remaining_site_choices':[[5,10],[10,11]],'remaining_count_distributions':3,'remaining_allocation_candidates':440,'next_work':'Review the existing cog-height/topology source evidence before changing the construction. Investigate a genuinely different arrangement with movable cog poses or a changed frame core, or an exact continuous bound if it resolves the surviving geometry. Preserve the original source checks and charge every preparation dependency in any new bounded method.','prior_cog_height_work':'benchmarks/results/h5-independent-cog-height-20261028.md','prior_cog_topology_work':'benchmarks/results/h5-cog-topology-source-checks-20261028.md','prior_feasible_moves':'benchmarks/results/h5-feasible-cog-source-20261028.md','prior_fifteen_cog_calls_remain_closed':True,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'variables':2701,'constraints':11182,'count_capacity_tables_used':False,'charged_preparation_seconds':response['preparation_seconds_charged'],'closed_solver_calls':1,'solver_status':'INFEASIBLE','assignments':0,'solve_slice_overrun_seconds':0,'overall_algorithm_shared_overruns_seconds':0,'continuous_source_domain_excluded':False,'remaining_site_choices':2,'remaining_count_distributions':3,'remaining_allocation_candidates':440,'source_valid66':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Corner-channel construction: closed grid call — 2026-11-04

A distinct positive construction selects a corner channel directly from the
original cog-site geometry. Its sole bounded call closes **INFEASIBLE on the
0.01 mm grid**, without an assignment. This is not an independent unsat
certificate or a continuous-source exclusion. The two site choices / three
count distributions from the preceding source proofs remain authoritative;
all 440 whole-job allocations and H5 remain open.

[The selection rule]({NAME}/selection.json) takes the leftmost cog from each of
the two rows farthest in positive Y from the fixed frame block, selecting [5,10].
It reads no component count or capacity table. The [geometry audit]({NAME}/geometry-audit.json)
reconstructs that choice from the cog poses, preserves all source modes and
269 compatible original convex regions, and checks 1,069 exact halfplane
implications. It also verifies all 20 outward-rounded component rectangles.
Construction spacing is 0.23 mm; physical source requirements are unchanged.

The [model audit]({NAME}/model-audit.json) verifies every one of **2,701 variables
and 11,182 constraints**: 13 moving originals (seven brackets and six inserts),
80 mode selectors, 1,768 unary region selectors, all 183 different-owner
rectangle pairs and 544 rigid coordinate links. It verifies that same-family
X ordering only removes interchangeable-copy symmetry. No objective, hint or
component count constraint is present.

[The budget]({NAME}/budget.json) charges **28.151966 seconds** of preparation.
This includes the prior source-valid short11 construction, fixed frame/insert
core, cog-site and source-mask preparation, original rectangle and integer
preparation, the [complete 0.319194-second geometry process]({NAME}/geometry-process.json)
and [complete 3.432999-second model build]({NAME}/model-build-process.json).
[The final ledger]({NAME}/preparation-charges.json) uses the full model process,
including imports and evidence output, instead of its narrower internal timer.
No long count-proof derivation is consumed by this model or treated as free
preparation.

[Independent response readback]({NAME}/response-audit.json) verifies the sole
call, 27.088917 seconds of allocated solve time, 7.805048 seconds of returned
solve time, 175,608 branches and 45,633 conflicts. Algorithm/shared totals are
**36.725788 / 36.794205 seconds**, with no solve-slice or overall overrun.
There are no incumbents, source66 checks or native calls. The call stays closed.

[Next work]({NAME}/next-step.json) first reconciles the existing cog-height and
topology evidence before changing the arrangement. The older 15-cog optimizations
are closed and cannot be restarted. A new method still needs a complete
66-part original-source layout, native validation, material checks and the full
H5 matrix before integration or any release claim. H2/H5 remain open at **60%**.

The evidence archive contains {archive['archive_members']} new canonical members
and {archive['archive_bytes']:,} compressed bytes. [The manifest]({NAME}/raw-manifest.json),
[external evidence map]({NAME}/external-evidence.json), and [source bindings]({NAME}/source-bindings.json)
retain the complete model, preparation, runner, response, audits and exact
references to previously committed source evidence. The independent reader
checks every archive member and local report link before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 corner-channel construction:** [the independent geometry/model/response audits]({link}) verify a new [5,10] construction selected directly from cog poses, without count-capacity tables. Its 2,701-variable / 11,182-constraint model receives one closed call and returns grid INFEASIBLE with no assignment. Complete charged preparation is 28.151966 s; algorithm/shared totals are 36.725788 / 36.794205 s, with no overruns. This does not exclude continuous source placements. The two choices / three count distributions, all 440 whole-job allocations and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [direct count proofs and relative-hull capacities](../benchmarks/results/h5-direct-counts-and-relative-hull-capacities-20261104.md).';assert s.count(old)==1
s=s.replace(old,f'Latest H5 evidence: [bounded corner-channel construction](../benchmarks/results/{NAME}.md).',1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n');print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
