from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_fine_eleven_response_20261104.py').read_text(encoding='utf-8')
s=s.replace('h5-first55-fine-eleven-companion-model-20261104','h5-first55-corner-channel-regions-20261104').replace('h5-first55-fine-grid-regions-20261104','h5-first55-corner-channel-regions-20261104')
s=s.replace('==2813','==2701').replace('==12294','==11182').replace('==31379','==175608').replace('==3985','==45633')
s=s.replace("charge=load(MODEL/'checks.json')['preparation_seconds_charged'];charges=load(MODEL/'preparation-charges.json')", "charge=load(MODEL/'budget.json')['preparation_seconds_charged'];charges=load(MODEL/'final-preparation-charges.json')")
s=s.replace("MODEL/'preparation-charges.json',", "MODEL/'preparation-charges.json',MODEL/'budget.json',MODEL/'final-preparation-charges.json',MODEL/'build-process.json',")
s=s.replace("'remaining_candidates':440", "'remaining_candidates':440,'remaining_count_distributions':3,'remaining_site_choices':2,'corner_channel_geometry_selected_empty_sites':[5,10],'count_capacity_tables_used':False")
p=ROOT/'output/audit_h5_corner_channel_response_20261104.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
