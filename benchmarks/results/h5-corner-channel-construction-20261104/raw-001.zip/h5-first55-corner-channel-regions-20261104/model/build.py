"""Local0.1mm-grid construction with audited source implications and all35 site choices."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-corner-channel-regions-20261104';PRE=BASE;RID=BASE;OUT=BASE/'model';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029'
FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
PREPARATION_PROCESS=ROOT/'output/h5-corner-channel-preparation-process-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'geometry-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter()
modes=load(BASE/'family-modes.json');instances=load(BASE/'instances.json');unary=load(BASE/'unary-templates.json');model=cp_model.CpModel()
def linear(co,lo,hi,guard=None):
    expression=sum(c*model.get_int_var_from_proto_index(i) for i,c in co.items() if c)
    ct=model.add_linear_constraint(expression,lo,hi)
    if guard is not None:ct.only_enforce_if(model.get_bool_var_from_proto_index(guard))
    return ct.index
owners=[]
for i,instance in enumerate(instances):
    fm=modes[instance['identity'][0]];positions=[]
    for axis in [0,1]:positions.append(model.new_int_var(min(m['integer_lower_left_bounds'][axis][0] for m in fm),max(m['integer_lower_left_bounds'][axis][1] for m in fm),f'{"x" if axis==0 else "y"}_{i}_grid').index)
    owners.append({'owner':i,'identity':instance['identity'],'positions':positions,'modes':[],'unary_regions':[],'unary_geometry_marginals':[]})
for owner in owners:
    for mode in modes[owner['identity'][0]]:
        selector=model.new_bool_var(f'mode_{owner["owner"]}_{mode["mode"]}').index;record={**mode,'selector':selector,'stock_constraints':[]}
        for axis,var in enumerate(owner['positions']):
            lo,hi=mode['integer_lower_left_bounds'][axis];record['stock_constraints'].append(linear({var:1},lo,hi,selector))
        owner['modes'].append(record)
    owner['one_mode_constraint']=linear({m['selector']:1 for m in owner['modes']},1,1)
empty=[model.new_bool_var(f'empty_cog_site_{i}').index for i in range(15)];exact_two=linear({v:1 for v in empty},2,2)
allowed=load(BASE/'allowed-empty-site-pairs.json');forbidden=[]
for a,b in combinations(range(15),2):
    if [a,b] not in allowed:forbidden.append({'empty_sites':[a,b],'constraint':linear({empty[a]:1,empty[b]:1},cp_model.INT_MIN,1)})
assert len(forbidden)==104
unary_plane_count=mask_links=0
for owner in owners:
    i=owner['owner'];geometries=sorted({m['normalized_geometry'] for m in owner['modes']})
    for gid in geometries:
        for region in unary[gid]['regions']:
            selector=model.new_bool_var(f'unary_{i}_{gid}_{region["region"]}').index
            record={'geometry':gid,'region':region['region'],'selector':selector,'required_empty_sites':region['required_empty_sites'],'plane_constraints':[],'empty_site_constraints':[]}
            for plane in region['planes']:
                nx,ny=plane['coefficients'];record['plane_constraints'].append(linear({2*i:nx,2*i+1:ny},cp_model.INT_MIN,plane['upper'],selector));unary_plane_count+=1
            for site in region['required_empty_sites']:
                record['empty_site_constraints'].append(linear({selector:1,empty[site]:-1},cp_model.INT_MIN,0));mask_links+=1
            owner['unary_regions'].append(record)
    owner['one_unary_region_constraint']=linear({r['selector']:1 for r in owner['unary_regions']},1,1)
    for gid in geometries:
        ms=[m['selector'] for m in owner['modes'] if m['normalized_geometry']==gid];rs=[r['selector'] for r in owner['unary_regions'] if r['geometry']==gid]
        owner['unary_geometry_marginals'].append({'geometry':gid,'mode_selectors':ms,'region_selectors':rs,'constraint':linear({**{i:-1 for i in ms},**{i:1 for i in rs}},0,0)})
pairs=[];pair_plane_count=0
mode_rectangles=load(RID/'mode-rectangles.json');component_inventory=load(RID/'components.json');component_pairs=load(RID/'component-pairs.json');components=[];separations=[];coordinate_links=0
labels=['left','bottom','right','top']
for item in component_inventory:
    owner=owners[item['owner']];family=owner['identity'][0];piece=item['piece'];coords=[]
    for k,label in enumerate(labels):
        axis=k%2
        lo=min(m['integer_lower_left_bounds'][axis][0]+mode_rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        hi=max(m['integer_lower_left_bounds'][axis][1]+mode_rectangles[family][m['mode']]['rectangles'][piece]['outward_offsets_grid'][k] for m in owner['modes'])
        coords.append(model.new_int_var(lo,hi,f'rect_{item["component"]}_{label}_grid').index)
    record={**item,'coordinates':coords,'mode_links':[]}
    for mode in owner['modes']:
        offsets=mode_rectangles[family][mode['mode']]['rectangles'][piece]['outward_offsets_grid'];constraints=[]
        for k,(var,offset) in enumerate(zip(coords,offsets)):
            constraints.append(linear({var:1,owner['positions'][k%2]:-1},offset,offset,mode['selector']));coordinate_links+=1
        record['mode_links'].append({'mode':mode['mode'],'mode_selector':mode['selector'],'outward_offsets_grid':offsets,'constraints':constraints})
    components.append(record)
for item in component_pairs:
    ai,bi=item['components'];a,b=components[ai]['coordinates'],components[bi]['coordinates'];selectors=[];constraints=[]
    directions=[{a[2]:1,b[0]:-1},{b[2]:1,a[0]:-1},{a[3]:1,b[1]:-1},{b[3]:1,a[1]:-1}]
    for direction,coefficients in enumerate(directions):
        selector=model.new_bool_var(f'separate_{ai}_{bi}_{direction}').index;selectors.append(selector);constraints.append(linear(coefficients,cp_model.INT_MIN,-23,selector))
    separations.append({**item,'selectors':selectors,'constraints':constraints,'one_direction_constraint':linear({v:1 for v in selectors},1,1)})
symmetry=[]
for family in ['bracket','insert']:
    peers=sorted((o for o in owners if o['identity'][0]==family),key=lambda o:o['identity'][1])
    for a,b in zip(peers,peers[1:]):symmetry.append({'family':family,'owners':[a['owner'],b['owner']],'constraint':linear({2*a['owner']:1,2*b['owner']:-1},cp_model.INT_MIN,0)})
validation=model.validate();write(OUT/'validation.json',{'validation':validation});assert validation==''
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
mapping={'owners':owners,'empty_site_selectors':empty,'exactly_two_empty_sites_constraint':exact_two,'pairs':pairs,'rigid_components':components,'rectangle_separations':separations,'rectangle_gap_grid':23,'symmetry_constraints':symmetry,'position_units_per_mm':100,'world_origin_mm':[0,2100],'forbidden_site_pairs':forbidden};write(OUT/'mapping.json',mapping)
elapsed=time.perf_counter()-started
charges={'source_valid_short11_shared_seconds':load(SHORT/'response-audit/checks.json')['shared_seconds_including_preparation'],'fixed_first_sheet_preparation_seconds':load(FIRST/'checks.json')['seconds'],'cog_site_selection_preparation_seconds':load(SLOTS/'checks.json')['seconds'],'site_mask_region_preparation_seconds':load(PRIOR/'checks.json')['seconds'],'source_rigid_rectangle_preparation_seconds':load(PRIOR/'rigid-rectangle-preflight/checks.json')['seconds'],'source_mask_integer_preparation_seconds':load(PRIOR/'integer-preparation/checks.json')['seconds'],'corner_channel_complete_preparation_seconds':load(PREPARATION_PROCESS/'process.json')['complete_process_seconds'],'cp_model_build_seconds':elapsed};write(OUT/'preparation-charges.json',charges)
inputs=[Path(__file__),PREPARATION_PROCESS/'opened.json',PREPARATION_PROCESS/'process.json',BASE/'geometry-audit/plan.json',BASE/'geometry-audit/checks.json',FIRST/'checks.json',SLOTS/'checks.json',SHORT/'response-audit/plan.json',SHORT/'response-audit/checks.json']+[BASE/n for n in ['plan.json','checks.json','family-modes.json','unary-templates.json','mode-rectangles.json','instances.json','inventory.json','components.json','component-pairs.json','allowed-empty-site-pairs.json']]+[PRIOR/n for n in ['plan.json','checks.json','rigid-rectangle-preflight/checks.json','integer-preparation/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Construct all13 original moving owners, all80 source modes and the single corner-channel choice selected from cog geometry. Local0.01mm positions imply unchanged original source hulls. All20 outward component rectangles remain rigidly attached through mode equalities; every one of183 different-owner pairs requires0.23mm axis clearance. Same-family X order removes interchangeable-copy symmetry. No component count or capacity table is used, and no objective or hints are supplied. Independently audit every field before one60/90-second call. Charge complete geometry selection/preparation, short11 construction, source masks/rectangles and complete model-build process. All earlier calls remain closed.','algorithm_seconds':60,'shared_seconds':90,'maximum_calls':1,'source_validation_reserve_seconds':4,'retry_permitted':False,'solver_calls':0})
result={'passed':True,'seconds':elapsed,'preparation_seconds_charged':sum(charges.values()),'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'original_moving_parts':13,'source_mode_selectors':80,'empty_site_selectors':15,'retained_empty_site_pairs':1,'forbidden_site_pair_constraints':104,'count_capacity_tables_used':False,'unary_region_selectors':sum(len(o['unary_regions']) for o in owners),'unary_integer_planes':unary_plane_count,'empty_site_mask_implications':mask_links,'rigid_components':len(components),'rigid_component_coordinate_links':coordinate_links,'different_owner_rectangle_pairs':len(separations),'rectangle_direction_selectors':4*len(separations),'same_family_order_constraints':len(symmetry),'model_sha256':digest(OUT/'model.pb'),'independent_model_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
