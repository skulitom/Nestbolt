"""Independent complete scan replay; check every previously compatible envelope pair."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import ast,json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-refined-union-graph-20261106';OUT=BASE/'audit'
PARENT=ROOT/'output/h5-first57-refined-conflict-graph-20261106';TREE=ROOT/'output/h5-first57-refined-anchor-tree-20261106'
PROCESS=ROOT/'output/h5-first57-refined-union-graph-process-20261106';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';HELPER=ROOT/'output/audit_h5_union_conflict_probe_v2_20261106.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),HELPER,JOB,BASE/'plan.json',BASE/'checks.json',BASE/'new-edges.json',BASE/'conflicts.bin',BASE/'nodes.json',BASE/'initial-covers.json',
    PARENT/'nodes.json',PARENT/'conflicts.bin',PARENT/'initial-covers.json',SOURCE/'geometry-domains.json',PROCESS/'opened.json',PROCESS/'process.json'}
for base in [BASE,PARENT/'audit',TREE/'audit']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [PARENT/'audit',TREE/'audit']:
    inputs.add(base/'checks.json');assert load(base/'checks.json')['passed']
process=load(PROCESS/'process.json');assert process['closed'] and not process['timeout'] and process['exit_code']==0 and process['complete_process_cap_overrun_seconds']==0
plan=load(BASE/'plan.json');checks=load(BASE/'checks.json')
assert plan['required_job_clearance_mm']==load(JOB)['clearance']==0.2 and plan['square_radius_um']==140 and 2*140**2<200**2
assert checks['reported_complete_scan'] and checks['geometry_templates_completed']==55
nodes=load(BASE/'nodes.json');assert nodes==load(PARENT/'nodes.json') and load(BASE/'initial-covers.json')==load(PARENT/'initial-covers.json')
n=len(nodes);rowbytes=(n+7)//8;assert n==checks['compact_nodes'] and rowbytes==checks['row_bytes']
old=np.unpackbits(np.frombuffer((PARENT/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(n,rowbytes),axis=1,bitorder='little')[:,:n].astype(bool)
actual=np.unpackbits(np.frombuffer((BASE/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(n,rowbytes),axis=1,bitorder='little')
assert not np.any(actual[:,n:]) and digest(BASE/'conflicts.bin')==checks['conflict_bytes_sha256']
geometry=load(SOURCE/'geometry-domains.json');bounds=np.array([r['bounds_um'] for r in nodes],dtype=np.int64)
groups={g:np.array([i for i,r in enumerate(nodes) if r['geometry']==g],dtype=np.int64) for g in range(10)}
templates={}
for a in range(10):
    for b in range(10):
        templates[a,b]=[[ra[0]-rb[2]-140,ra[1]-rb[3]-140,ra[2]-rb[0]+140,ra[3]-rb[1]+140] for ra,rb in product(geometry[a]['inner_rectangles_um'],geometry[b]['inner_rectangles_um'])]
point_checks=[0]
functions=[v for v in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(v,ast.FunctionDef) and v.name in ['classes','covered']]
assert len(functions)==2;exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
found=[];candidates=0;outside=0;expected=old.copy()
for i,left in enumerate(nodes):
    a=left['bounds_um']
    for g,alljs in groups.items():
        js=alljs[(alljs>i)&(~old[i,alljs])]
        if not len(js):continue
        r=templates[left['geometry'],g];b=bounds[js]
        boxes=np.column_stack([b[:,0]-a[2],b[:,1]-a[3],b[:,2]-a[0],b[:,3]-a[1]])
        lower=[min(t[axis] for t in r) for axis in [0,1]];upper=[max(t[axis] for t in r) for axis in [2,3]]
        relevant=np.all(boxes[:,:2]>lower,axis=1)&np.all(boxes[:,2:]<upper,axis=1)
        outside+=int(np.count_nonzero(~relevant))
        for j,box in zip(js[relevant],boxes[relevant]):
            candidates+=1
            if covered(list(map(int,box)),r):found.append([i,int(j)]);expected[i,j]=expected[j,i]=True
found.sort();assert found==load(BASE/'new-edges.json') and len(found)==checks['new_component_union_conflicts']
assert candidates==checks['candidate_pairs_checked'] and np.array_equal(expected,actual[:,:n])
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Preserve every independently audited refined node and inherited graph bit. Enumerate every unordered previously compatible pair independently by row and target geometry. Complete closed-box coverage by an open rectangle union necessarily implies strict containment inside its open bounding envelope; every outside-envelope pair has an uncovered boundary point. Replay every remaining pair over all Cartesian boundary/open-interval classes with exact doubled-integer arithmetic. Compare the complete set of newly covered pairs and every updated graph bit. No new edge is found, so the graph remains byte-identical and no new tree is justified.'})
result={'passed':True,'seconds':time.perf_counter()-started,'all_nodes_preserved':n,'all_previously_compatible_pairs':candidates+outside,
    'outside_union_envelope_pairs':outside,'complete_candidate_pairs_replayed':candidates,'cartesian_class_checks':point_checks[0],
    'new_component_union_conflicts':len(found),'updated_graph_byte_identical_to_parent':(BASE/'conflicts.bin').read_bytes()==(PARENT/'conflicts.bin').read_bytes(),
    'complete_scan_independently_verified':True,'new_tree_justified':bool(found),'whole_arrangements_excluded':0,'remaining_fixed29_choices':26,
    'required_job_clearance_mm':0.2,'new_zero_clearance_exclusion_claimed':False,'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
