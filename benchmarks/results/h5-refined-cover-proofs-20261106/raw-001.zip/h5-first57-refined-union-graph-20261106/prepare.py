"""Stronger exact component-union conflicts on the refined continuous cover."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations_with_replacement
import ast,json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-refined-union-graph-20261106'
PARENT=ROOT/'output/h5-first57-refined-conflict-graph-20261106'
TREE=ROOT/'output/h5-first57-refined-anchor-tree-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
HELPER=ROOT/'output/prepare_h5_union_conflict_probe_20261106.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for p in [PARENT/'audit/checks.json',TREE/'audit/checks.json']:assert load(p)['passed']
assert load(TREE/'audit/checks.json')['new_fixed29_choices_excluded']==0
nodes=load(PARENT/'nodes.json');n=len(nodes);checks=load(PARENT/'checks.json');row=load(PARENT/'plan.json')['source_selection']
geometry=load(SOURCE/'geometry-domains.json')
function=[v for v in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(v,ast.FunctionDef) and v.name=='union_covers']
assert len(function)==1;exec(compile(ast.Module(body=function,type_ignores=[]),str(HELPER),'exec'))
inputs=[Path(__file__),HELPER,SOURCE/'geometry-domains.json']+[PARENT/name for name in ['plan.json','checks.json','audit/plan.json','audit/checks.json','nodes.json','initial-covers.json','conflicts.bin']]+[TREE/'audit/plan.json',TREE/'audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'source_selection':row,
    'scan_cutoff_seconds':10,'preparation_cap_seconds':15,'maximum_process_seconds':20,'required_job_clearance_mm':0.2,'square_radius_um':140,'repeat_permitted':False,
    'method':'Preserve every audited refined source node and prior graph edge. Scan compatible child pairs whose closed relative-anchor box lies inside the envelope of the union of source-inner difference rectangles expanded by140 micrometres. Certify full closed-box coverage with the exact open-union sweep. Save only new edges and their entire updated bit graph. A limited scan preserves its proved prefix and makes no augmentation-completeness claim. Independently replay every new edge and graph change before any fresh tree.'})
rowbytes=(n+7)//8;raw=np.frombuffer((PARENT/'conflicts.bin').read_bytes(),dtype=np.uint8).reshape(n,rowbytes)
graph=np.unpackbits(raw,axis=1,bitorder='little')[:,:n].astype(bool)
bounds=np.array([v['bounds_um'] for v in nodes],dtype=np.int64)
groups={g:np.array([i for i,v in enumerate(nodes) if v['geometry']==g],dtype=np.int64) for g in range(10)}
edges=[];tested=0;completed=0;complete=True
for ga,gb in combinations_with_replacement(range(10),2):
    if time.perf_counter()-started>=10:complete=False;break
    ia,ib=groups[ga],groups[gb]
    if not len(ia) or not len(ib):completed+=1;continue
    rects=[[a[0]-b[2]-140,a[1]-b[3]-140,a[2]-b[0]+140,a[3]-b[1]+140] for a in geometry[ga]['inner_rectangles_um'] for b in geometry[gb]['inner_rectangles_um']]
    a,b=bounds[ia],bounds[ib]
    lx=b[None,:,0]-a[:,None,2];ly=b[None,:,1]-a[:,None,3]
    ux=b[None,:,2]-a[:,None,0];uy=b[None,:,3]-a[:,None,1]
    eligible=(lx>min(r[0] for r in rects))&(ly>min(r[1] for r in rects))&(ux<max(r[2] for r in rects))&(uy<max(r[3] for r in rects))
    eligible &= ~graph[np.ix_(ia,ib)]
    if ga==gb:eligible &= ia[:,None]<ib[None,:]
    for ai,bi in zip(*np.nonzero(eligible)):
        if tested%64==0 and time.perf_counter()-started>=10:complete=False;break
        tested+=1;box=[int(lx[ai,bi]),int(ly[ai,bi]),int(ux[ai,bi]),int(uy[ai,bi])]
        if union_covers(box,rects) is not None:
            a,b=sorted([int(ia[ai]),int(ib[bi])]);edges.append([a,b]);graph[a,b]=graph[b,a]=True
    if not complete:break
    completed+=1
edges.sort();assert len(edges)==len(set(map(tuple,edges)))
write(OUT/'new-edges.json',edges)
for name in ['nodes.json','initial-covers.json']:shutil.copyfile(PARENT/name,OUT/name)
(OUT/'conflicts.bin').write_bytes(np.packbits(graph,axis=1,bitorder='little').tobytes())
result={'prepared':True,'seconds':time.perf_counter()-started,'compact_nodes':n,'bracket_nodes':checks['bracket_nodes'],'insert_nodes':checks['insert_nodes'],'row_bytes':rowbytes,
    'new_component_union_conflicts':len(edges),'candidate_pairs_checked':tested,'geometry_templates_completed':completed,'reported_complete_scan':complete,
    'conflict_bytes_sha256':digest(OUT/'conflicts.bin'),'whole_arrangements_excluded':0,'independent_graph_audit_pending':True,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);assert time.perf_counter()-started<15;print(result)
