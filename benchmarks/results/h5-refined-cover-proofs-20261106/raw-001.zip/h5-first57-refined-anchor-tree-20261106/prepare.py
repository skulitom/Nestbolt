"""One fresh bounded tree on the independently verified refined graph."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-refined-anchor-tree-20261106'
GRAPH=ROOT/'output/h5-first57-refined-conflict-graph-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def members(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask-=bit
OUT.mkdir();started=time.perf_counter();case_started=started;deadline=started+5.0;shutil.copyfile(__file__,OUT/'prepare.py')
audit=load(GRAPH/'audit/checks.json');assert audit['passed'] and audit['genuinely_new_child_conflicts']>0
inputs=[Path(__file__),ROOT/'output/prepare_h5_refined_tree_helpers_20261106.py',ROOT/'output/prepare_h5_clearance_pair_trees_20261106.py']+[GRAPH/name for name in ['plan.json','checks.json','audit/plan.json','audit/checks.json','nodes.json','initial-covers.json','conflicts.bin']]
row=load(GRAPH/'plan.json')['source_selection']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'source_selection':row,'search_cutoff_seconds':5.0,'complete_case_cap_seconds':5.5,'maximum_expanded_nodes':5000,'preparation_cap_seconds':8,'maximum_process_seconds':12,
    'required_job_clearance_mm':0.2,'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,
    'method':'One distinct include/skip proof tree over the complete independently audited refined source domains and every independently verified graph bit. Preserve all inherited conflicts and151808 genuinely new child conflicts. Fresh5.0-second search,5.5 complete-case,5000 expanded-node,8 preparation and12 process caps. Every limit/witness creates an explicit open leaf. Only a completely closed independently replayed tree excludes the selected fixed29/current-cog arrangement at required0.2mm clearance.'})
nodes=load(GRAPH/'nodes.json');offset=audit['retained_bracket_children'];n=len(nodes);universe=(1<<n)-1
rowbytes=(n+7)//8;raw=(GRAPH/'conflicts.bin').read_bytes();assert len(raw)==rowbytes*n
conflicting={i:int.from_bytes(raw[i*rowbytes:(i+1)*rowbytes],'little') for i in range(n)}
compatible={i:universe&~conflicting[i] for i in range(n)}
original=[[sum(1<<n for n in group) for group in cover] for cover in load(GRAPH/'initial-covers.json')]
root_available=[(1<<offset)-1,universe^((1<<offset)-1)]
graph_complete=True;records=[];witness=None;expanded=0
def cover(family,mask,need,seed):
    options=[[g&mask for g in partition if g&mask] for partition in [original[family],seed]]
    best=min(options,key=len)
    if len(best)<need:return best
    vertices=list(members(mask))
    for order in [vertices,sorted(vertices,key=lambda n:(-(conflicting[n]&mask).bit_count(),n))]:
        groups=[]
        for v in order:
            options=[i for i,g in enumerate(groups) if not g&~conflicting[v]]
            if options:
                i=max(options,key=lambda i:(groups[i].bit_count(),-i));groups[i]|=1<<v
            else:groups.append(1<<v)
        if len(groups)<len(best):best=groups
        if len(best)<need:break
    return best
def visit(available,chosen,seeds):
    global expanded,witness
    index=len(records);record={'node':index,'expanded':False,'propagation':[]};records.append(record)
    def opened(reason):
        record.update({'kind':'open','reason':reason,'case_elapsed':time.perf_counter()-case_started,
                       'global_elapsed':time.perf_counter()-started});return index
    if not graph_complete:return opened('graph_preparation_limit')
    if witness is not None:return opened('earlier_joint_graph_witness')
    if time.perf_counter()>=deadline or expanded>=5000:return opened('time_or_expansion_limit')
    record['expanded']=True;expanded+=1;available=list(available);seeds=[list(s) for s in seeds]
    while True:
        if time.perf_counter()>=deadline:return opened('time_or_expansion_limit')
        need=[8-len(c) for c in chosen]
        if need==[0,0]:
            witness=[list(c) for c in chosen];record.update({'kind':'open_graph_witness','witness':witness});return index
        groups=[cover(f,available[f],need[f],seeds[f]) for f in range(2)];seeds=groups
        for f in range(2):
            if len(groups[f])<need[f]:
                record.update({'kind':'closed_count_cover','family':f,'cover':[list(members(g)) for g in groups[f]]});return index
        changed=False
        for mf in range(2):
            if need[mf]==0 or len(groups[mf])!=need[mf]:continue
            step={'mandatory_family':mf,'cover':[list(members(g)) for g in groups[mf]],'removals':[]}
            empty_group=False
            for f in range(2):
                for value in list(members(available[f])):
                    for gi,g in enumerate(groups[mf]):
                        current=g&available[mf]
                        assert current
                        if current&(1<<value):continue
                        if not current&compatible[value]:
                            step['removals'].append([f,value,gi]);available[f]&=~(1<<value);changed=True
                            empty_group=any(not (g&available[mf]) for g in groups[mf]);break
                    if empty_group:break
                if empty_group:break
            if step['removals']:record['propagation'].append(step);break
        if not changed:break
    families=[f for f in range(2) if need[f]>0]
    family=min(families,key=lambda f:(len(groups[f])-need[f],min(g.bit_count() for g in groups[f]),f))
    group=min(groups[family],key=lambda g:(g.bit_count(),next(members(g))))
    values=list(members(group));record.update({'kind':'branch_clique','family':family,'clique':values,'children':[]})
    for value in values:
        child_available=[a&compatible[value] for a in available]
        child_chosen=[list(c) for c in chosen];child_chosen[family].append(value)
        if len(child_chosen[family])==8:child_available[family]=0
        record['children'].append({'value':value,'node':visit(child_available,child_chosen,groups)})
    skipped=list(available);skipped[family]&=~group
    record['skip']=visit(skipped,[list(c) for c in chosen],groups)
    return index
root=visit(root_available,[[],[]],original)
open_nodes=[r['node'] for r in records if r['kind'] in ['open','open_graph_witness']]
elapsed=time.perf_counter()-case_started
result={'source_selection':row,'empty_sites':row['empty_sites'],'refined_bracket_node_count':offset,'graph_complete':True,
    'root':root,'records':records,'expanded_nodes':expanded,'open_nodes':open_nodes,'joint_graph_witness':witness,
    'case_seconds':elapsed,'case_complete_cap_overrun_seconds':max(0,elapsed-5.5),'diagnostic_excluded':not open_nodes}
write(OUT/'tree.json',result)
checks={k:v for k,v in result.items() if k not in ['records','open_nodes','joint_graph_witness']}|{'tree_records':len(records),'open_leaves':len(open_nodes),'graph_witness':witness is not None,'independent_tree_audit_pending':True,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);assert time.perf_counter()-started<8;print(checks)
