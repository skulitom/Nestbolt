from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_clearance_pair_edges_20261106.py').read_text(encoding='utf-8')
s=s.replace('clearance-pair-edges','fixed-core-clearance').replace('prepare_h5_clearance_pair_edges','prepare_h5_fixed_core_clearance')
with (O/'run_h5_fixed_core_clearance_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared a distinct bounded fixed-core clearance process.')
