from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_refined_conflict_graph_20261106.py').read_text(encoding='utf-8')
s=s.replace('refined-conflict-graph','refined-union-graph').replace('prepare_h5_refined_conflict_graph','prepare_h5_refined_union_graph')
with (O/'run_h5_refined_union_graph_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared a distinct bounded refined union scan.')
