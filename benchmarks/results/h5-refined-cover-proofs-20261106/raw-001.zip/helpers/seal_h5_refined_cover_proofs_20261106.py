from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-refined-cover-proofs-20261106';OUT=ROOT/'benchmarks/results'/NAME
STAGES=['fixed-core-clearance','refined-anchor-cover','refined-conflict-graph','refined-anchor-tree','refined-union-graph']
BASES=[ROOT/'output'/f'h5-first57-{n}-20261106' for n in STAGES]
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
audits=[load(p/'audit/checks.json') for p in BASES];assert all(a['passed'] for a in audits)
fixed,cover,graph,tree,union=audits
assert fixed['removed_node_occurrences']==0 and cover['certified_child_removals']==157 and graph['genuinely_new_child_conflicts']==151808
assert tree['new_fixed29_choices_excluded']==0 and tree['open_leaves']==116 and tree['tree_records_verified']==1185
assert union['new_component_union_conflicts']==0 and union['complete_scan_independently_verified'] and union['updated_graph_byte_identical_to_parent']
process_folders=[ROOT/'output'/f'h5-first57-{n}-process-20261106' for n in STAGES]
processes=[load(p/'process.json') for p in process_folders]
assert all(p['closed'] and p['exit_code']==0 and not p['timeout'] and p['complete_process_cap_overrun_seconds']==0 for p in processes)
assert tree['complete_case_cap_overrun_seconds']==0
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py'
parsed=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in parsed.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
previous=ROOT/'output/seal_h5_clearance_pair_proofs_20261106.py'
parsed=ast.parse(previous.read_text(encoding='utf-8'))
extension=next(n for n in parsed.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='PARENTS' and n.value.func.attr=='extend')
exec(compile(ast.Module(body=[extension],type_ignores=[]),str(previous),'exec'))
PARENTS.append(ROOT/'benchmarks/results/h5-clearance-pair-proofs-20261106')
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for folder in BASES+process_folders:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_fixed_core_clearance*20261106.py','*h5_refined*20261106.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,previous.name,'h5-refined-cover-proofs-report-20261106.md']:
    add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for base,name in zip(BASES,['fixed-core-audit.json','cover-audit.json','graph-audit.json','tree-audit.json','union-scan-audit.json']):
    shutil.copyfile(base/'audit/checks.json',OUT/name)
shutil.copyfile(BASES[3]/'audit/remaining-fixed29-choices.json',OUT/'remaining-fixed29-choices.json')
prior_audit=load(ROOT/'output/h5-first57-clearance-pair-trees-20261106/audit/checks.json')
classification={'coarse_graph_witness_cases':[r['empty_sites'] for r in prior_audit['choices'] if r['joint_graph_witness'] and r['empty_sites']!=[4,5,10]],
    'coarse_cutoff_cases':prior_audit['budget_limited_cases'],'refined_cutoff_cases':[[4,5,10]],'total_remaining':26}
assert len(classification['coarse_graph_witness_cases'])==4 and len(classification['coarse_cutoff_cases'])==21
write(OUT/'frontier-classification.json',classification)
write(OUT/'process-ledger.json',{'stages':STAGES,'new_complete_preparation_seconds':sum(p['complete_process_seconds'] for p in processes),
    'processes':processes,'independent_audit_seconds':[a['seconds'] for a in audits],'all_processes_closed':True,
    'case_complete_cap_overrun_seconds':0,'placement_solver_calls':0,'native_calls':0,'full_construction_60_90_budget_claimed':False})
write(OUT/'next-step.json',{'all_prior_processes_closed':True,'remaining_fixed29_choices':26,'total_fixed29_choices_excluded_at_required_clearance':429,
    'do_not_repeat_refined_case':[4,5,10],
    'next_method':'Assess complete midpoint-refined source covers and exact root clique bounds for the other25 surviving fixed29/current-cog arrangements. Do not rerun the already refined[4,5,10] case. Split every retained parent cell into closed Cartesian children with shared boundaries preserved, retain all source aliases, and certify any child removals against the existing exact present-cog polygons. Deduplicate source queries only when geometry, child bounds and consuming present-site requirements are independently verified. Construct each new child graph with all inherited parent conflicts and exact child source-distance conflicts; independently audit complete coverage, every used graph edge and any complete conflict-clique capacity proof. Only root bounds below a required family count or a fully audited closed tree can exclude an arrangement. Freeze batch/case limits and retain partial results. A new tree requires genuinely stronger certified domains or edges. All consumed preparation remains chargeable before any later construction budget claim.',
    'survivors':'output/h5-first57-refined-anchor-tree-20261106/audit/remaining-fixed29-choices.json',
    'parent_domains':'output/h5-first57-clearance-cog-pruning-20261106','refinement_proof':'output/h5-first57-refined-anchor-cover-20261106',
    'current_refined_graph':'output/h5-first57-refined-conflict-graph-20261106','whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'new_whole_arrangement_exclusions':0,'remaining_fixed29_choices':26,'total_fixed29_choices_excluded_at_required_clearance':429,'previous_zero_clearance_exclusions':427,
    'refined_case':[4,5,10],'complete_parent_cells':646,'complete_child_cells':2584,'source_certified_child_removals':157,
    'retained_child_cells':2427,'all_child_pairs_verified':2943951,'new_child_conflicts':151808,
    'tree_records_verified':1185,'tree_open_leaves':116,'complete_union_scan_new_edges':0,
    'required_job_clearance_mm':0.2,'new_zero_clearance_exclusion_claimed':False,'whole_allocation_candidates':440,
    'placement_solver_calls':0,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-refined-cover-proofs-report-20261106.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}")
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-06 H5 refined continuous cover:** [independent cover, graph and tree audits]({link}) refine [4,5,10] from 646 retained parent boxes into 2,584 closed children without losing any boundary or source alias. Exact cog-distance proofs remove 157 children; the 2,427 retained cells have 151,808 newly verified conflicts, with every one of 2,943,951 unordered pairs audited. A fresh five-second tree verifies 1,185 records and 78,662 ordered removals but stops with 116 open leaves, so no further arrangement is excluded. The frontier remains 26: four coarse graph witnesses, twenty-one coarse cutoff cases and this refined cutoff. Separate complete fixed-core and refined component-union scans find zero additional removals/edges; neither triggers another tree. Complete preparations take 1.102050, 0.414443, 0.515050, 5.791520 and 1.940855 s with zero complete-case/process overrun. Next assess new complete child covers and root clique bounds for the other 25 surviving arrangements. All prior bounded processes stay closed; no placement/native call or full construction budget is claimed. Full66 checks, 440 whole allocations and H2/H5 remain open at 60%.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8')
a='Latest H5 evidence: [required-clearance pair exclusions](../benchmarks/results/h5-clearance-pair-proofs-20261106.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [refined continuous cover](../benchmarks/results/{NAME}.md).',1)
a='twenty-one cutoff cases. Clearance-aware root pruning against the fixed core\nis next. All prior calls and bounded processes stay closed.'
b='twenty-one cutoff cases. Fixed-core clearance pruning finds no new removals.\nA complete finer cover for [4,5,10] removes 157 child cells and adds 151,808\ncertified pair conflicts. Its distinct tree remains open at the frozen limit;\na complete component-union scan adds no further edge. Four coarse witnesses,\ntwenty-one coarse cutoff cases and this refined cutoff remain. New child covers\nand root clique bounds for the other 25 arrangements are next. All prior calls\nand bounded processes stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
