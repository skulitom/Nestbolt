from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_fixed_core_clearance_20261106.py').read_text(encoding='utf-8')
s=s.replace('fixed-core-clearance','refined-anchor-cover').replace('prepare_h5_fixed_core_clearance','prepare_h5_refined_anchor_cover').replace('40','20')
with (O/'run_h5_refined_anchor_cover_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared distinct closed-child source cover process.')
