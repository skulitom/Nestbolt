from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_refined_anchor_cover_20261106.py').read_text(encoding='utf-8')
s=s.replace('refined-anchor-cover','refined-conflict-graph').replace('prepare_h5_refined_anchor_cover','prepare_h5_refined_conflict_graph')
with (O/'run_h5_refined_conflict_graph_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared distinct refined graph process.')
