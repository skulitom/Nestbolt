from pathlib import Path
from textwrap import dedent
O=Path(__file__).resolve().parent
source=(O/'prepare_h5_clearance_pair_trees_20261106.py').read_text(encoding='utf-8')
methods=dedent(source[source.index('    def cover('):source.index('    root=visit(')]).replace('expanded>=1500','expanded>=5000')
prefix='''"""One fresh bounded tree on the independently verified refined graph."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-refined-anchor-tree-20261106'
GRAPH=ROOT/'output/h5-first57-refined-conflict-graph-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')
def members(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask-=bit
OUT.mkdir();started=time.perf_counter();case_started=started;deadline=started+5.0;shutil.copyfile(__file__,OUT/'prepare.py')
audit=load(GRAPH/'audit/checks.json');assert audit['passed'] and audit['genuinely_new_child_conflicts']>0
inputs=[Path(__file__),ROOT/'output/prepare_h5_refined_tree_helpers_20261106.py',ROOT/'output/prepare_h5_clearance_pair_trees_20261106.py']+[GRAPH/name for name in ['plan.json','checks.json','audit/plan.json','audit/checks.json','nodes.json','initial-covers.json','conflicts.bin']]
row=load(GRAPH/'plan.json')['source_selection']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'source_selection':row,'search_cutoff_seconds':5.0,'complete_case_cap_seconds':5.5,'maximum_expanded_nodes':5000,'preparation_cap_seconds':8,'maximum_process_seconds':12,
    'required_job_clearance_mm':0.2,'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0,
    'method':'One distinct include/skip proof tree over the complete independently audited refined source domains and every independently verified graph bit. Preserve all inherited conflicts and151808 genuinely new child conflicts. Fresh5.0-second search,5.5 complete-case,5000 expanded-node,8 preparation and12 process caps. Every limit/witness creates an explicit open leaf. Only a completely closed independently replayed tree excludes the selected fixed29/current-cog arrangement at required0.2mm clearance.'})
nodes=load(GRAPH/'nodes.json');offset=audit['retained_bracket_children'];n=len(nodes);universe=(1<<n)-1
rowbytes=(n+7)//8;raw=(GRAPH/'conflicts.bin').read_bytes();assert len(raw)==rowbytes*n
conflicting={i:int.from_bytes(raw[i*rowbytes:(i+1)*rowbytes],'little') for i in range(n)}
compatible={i:universe&~conflicting[i] for i in range(n)}
original=[[sum(1<<n for n in group) for group in cover] for cover in load(GRAPH/'initial-covers.json')]
root_available=[(1<<offset)-1,universe^((1<<offset)-1)]
graph_complete=True;records=[];witness=None;expanded=0
'''
suffix='''root=visit(root_available,[[],[]],original)
open_nodes=[r['node'] for r in records if r['kind'] in ['open','open_graph_witness']]
elapsed=time.perf_counter()-case_started
result={'source_selection':row,'empty_sites':row['empty_sites'],'refined_bracket_node_count':offset,'graph_complete':True,
    'root':root,'records':records,'expanded_nodes':expanded,'open_nodes':open_nodes,'joint_graph_witness':witness,
    'case_seconds':elapsed,'case_complete_cap_overrun_seconds':max(0,elapsed-5.5),'diagnostic_excluded':not open_nodes}
write(OUT/'tree.json',result)
checks={k:v for k,v in result.items() if k not in ['records','open_nodes','joint_graph_witness']}|{'tree_records':len(records),'open_leaves':len(open_nodes),'graph_witness':witness is not None,'independent_tree_audit_pending':True,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);assert time.perf_counter()-started<8;print(checks)
'''
with (O/'prepare_h5_refined_anchor_tree_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(prefix+methods+suffix)
s=(O/'run_h5_refined_conflict_graph_20261106.py').read_text(encoding='utf-8')
s=s.replace('refined-conflict-graph','refined-anchor-tree').replace('prepare_h5_refined_conflict_graph','prepare_h5_refined_anchor_tree')
s=s.replace("'maximum_process_seconds':20","'maximum_process_seconds':12").replace('timeout=20','timeout=12').replace('elapsed-20','elapsed-12')
with (O/'run_h5_refined_anchor_tree_20261106.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared a single distinct refined-domain tree.')
