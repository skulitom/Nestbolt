"""Exact bounded graph on retained child cells; preserves every parent conflict."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-refined-conflict-graph-20261106'
REF=ROOT/'output/h5-first57-refined-anchor-cover-20261106';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
AUG=ROOT/'output/h5-first57-union-conflict-edges-20261106';PAIR=ROOT/'output/h5-first57-clearance-pair-edges-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for base in [REF,AUG,PAIR]:assert load(base/'audit/checks.json')['passed']
row=load(REF/'plan.json')['source_selection']
paths=[BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json",AUG/f"choice-{row['augmentation_index']:02d}.json",PAIR/f"choice-{row['clearance_edge_index']:02d}.json"]
br,ins,augmentation,pair=map(load,paths);parents=br['nodes']+ins['nodes'];oldoffset=len(br['nodes'])
allnodes=load(REF/'nodes.json');retained=load(REF/'retained.json')
ids=retained['bracket']+retained['insert'];nodes=[allnodes[n] for n in ids];offset=len(retained['bracket'])
geometry=load(SOURCE/'geometry-domains.json')
inputs=[Path(__file__),SOURCE/'geometry-domains.json',REF/'plan.json',REF/'nodes.json',REF/'retained.json']+paths+[base/name for base in [REF,AUG,PAIR] for name in ['audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'source_selection':row,'graph_scan_cap_seconds':10,'preparation_cap_seconds':15,'maximum_process_seconds':20,
    'required_job_clearance_mm':0.2,'square_radius_um':140,'repeat_permitted':False,
    'method':'Compact all retained refined cells in family order. Inherit every parent zero-clearance source-inner conflict and saved original union/clearance edge. Add exact single-component required-clearance conflicts on each closed child pair using140 micrometre axis-square expansion. Save the entire exact boolean graph and inherited graph. Independently reconstruct every pair before any tree; report genuinely new child edges and preserve complete child domains. No placement or native call.'})
def matrix(cells,padding):
    n=len(cells);result=np.eye(n,dtype=bool);bounds=np.array([v['bounds_um'] for v in cells],dtype=np.int64)
    groups={g:np.array([i for i,v in enumerate(cells) if v['geometry']==g],dtype=np.int64) for g in range(10)}
    for ga in range(10):
        for gb in range(ga,10):
            assert time.perf_counter()-started<10
            ia,ib=groups[ga],groups[gb]
            if not len(ia) or not len(ib):continue
            a,b=bounds[ia],bounds[ib]
            lx=b[None,:,0]-a[:,None,2];ly=b[None,:,1]-a[:,None,3]
            ux=b[None,:,2]-a[:,None,0];uy=b[None,:,3]-a[:,None,1]
            clash=np.zeros((len(ia),len(ib)),dtype=bool)
            for ra in geometry[ga]['inner_rectangles_um']:
                for rb in geometry[gb]['inner_rectangles_um']:
                    clash |= ((ra[0]-rb[2]-padding<lx)&(ra[1]-rb[3]-padding<ly)&(ux<ra[2]-rb[0]+padding)&(uy<ra[3]-rb[1]+padding))
            result[np.ix_(ia,ib)] |= clash;result[np.ix_(ib,ia)] |= clash.T
    return result
parent_graph=matrix(parents,0)
for a,b in augmentation['added_conflict_edges']+pair['added_conflict_edges']:parent_graph[a,b]=parent_graph[b,a]=True
parent_ids=np.array([n['parent_node'] for n in nodes],dtype=np.int64)
inherited=parent_graph[np.ix_(parent_ids,parent_ids)]
single=matrix(nodes,140);graph=inherited|single
new=np.triu(graph&~inherited,1);new_count=int(np.count_nonzero(new))
assert new_count>0 and np.all(graph==graph.T) and np.all(np.diag(graph))
sample=next(zip(*np.nonzero(new)));sample=list(map(int,sample))
original=[]
for f,groups in enumerate([br['cliques'],ins['insert_cliques']]):
    family=[]
    for group in groups:
        parent_set={n+(oldoffset if f else 0) for n in group['nodes']}
        cells=[i for i,n in enumerate(nodes) if n['parent_node'] in parent_set]
        if cells:family.append(cells)
    original.append(family)
assert sorted(n for group in original[0] for n in group)==list(range(offset))
assert sorted(n for group in original[1] for n in group)==list(range(offset,len(nodes)))
for name,m in [('conflicts.bin',graph),('inherited.bin',inherited)]: (OUT/name).write_bytes(np.packbits(m,axis=1,bitorder='little').tobytes())
write(OUT/'nodes.json',nodes);write(OUT/'initial-covers.json',original)
checks={'prepared':True,'seconds':time.perf_counter()-started,'compact_nodes':len(nodes),'bracket_nodes':offset,'insert_nodes':len(nodes)-offset,
    'row_bytes':(len(nodes)+7)//8,'parent_nodes':len(parents),'all_unordered_pairs':len(nodes)*(len(nodes)-1)//2,
    'genuinely_new_child_conflicts':new_count,'new_conflict_example':sample,'initial_clique_counts':list(map(len,original)),
    'conflict_bytes_sha256':digest(OUT/'conflicts.bin'),'inherited_bytes_sha256':digest(OUT/'inherited.bin'),
    'independent_graph_audit_pending':True,'whole_arrangements_excluded':0,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);assert time.perf_counter()-started<15;print(checks)
