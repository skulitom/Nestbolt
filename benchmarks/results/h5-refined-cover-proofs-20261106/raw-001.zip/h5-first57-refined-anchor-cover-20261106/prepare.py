"""Complete closed child cover, with only certified original-cog removals."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-refined-anchor-cover-20261106'
FRONT=ROOT/'output/h5-first57-clearance-pair-trees-20261106'
CLEAR=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for p in [FRONT/'audit/checks.json',CLEAR/'audit-v2/checks.json']:assert load(p)['passed']
witnesses=load(FRONT/'audit/joint-graph-witnesses.json')
chosen=min(witnesses,key=lambda w:(w['source_selection']['bracket_nodes']+w['source_selection']['complete_insert_cells'],w['source_selection']['empty_sites']))
row=chosen['source_selection'];assert row['empty_sites']==[4,5,10]
brpath=BR/f"choice-{row['choice_index']:02d}.json";inspath=INS/f"choice-{row['insert_choice_index']:02d}.json";parentpath=CLEAR/f"choice-{row['clearance_pruning_index']:02d}.json"
br=load(brpath);ins=load(inspath);parent=load(parentpath);oldnodes=br['nodes']+ins['nodes'];oldoffset=len(br['nodes'])
inputs=[Path(__file__),FRONT/'audit/plan.json',FRONT/'audit/checks.json',FRONT/'audit/joint-graph-witnesses.json',
    CLEAR/'audit-v2/plan.json',CLEAR/'audit-v2/checks.json',CLEAR/'integer-source.json',CLEAR/'collision-polygons.json',brpath,inspath,parentpath]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'source_selection':row,'parent_bracket_node_count':oldoffset,'required_job_clearance_mm':0.2,'cog_diamond_radius_um':199,
    'pruning_scan_cutoff_seconds':10,'preparation_cap_seconds':15,'maximum_process_seconds':20,'repeat_permitted':False,
    'method':'Select the smallest complete-parent-node-count necessary graph witness, breaking ties by omitted sites. Split every retained parent closed box at the floor integer midpoint of each axis of width at least2 micrometres. Keep shared boundaries and all source geometry aliases. Remove a child only if all its closed corners lie strictly inside one present-cog exact source collision polygon expanded by the audited199 micrometre diamond. Unproved and unvisited children remain. Independently audit complete child coverage and every removal before a new graph. No placement solver/native call.'})
source=load(CLEAR/'integer-source.json');scale=int(source['scaled_units_per_micrometre'])
templates=load(CLEAR/'collision-polygons.json');polygons={g:[] for g in range(10)}
for ti,t in enumerate(templates):
    for site in range(15):
        if site in row['empty_sites']:continue
        shift=list(map(int,source['sites'][site]['translation_scaled']))
        poly=[(int(x)+shift[0],int(y)+shift[1]) for x,y in t['vertices_scaled']]
        bounds=(min(x for x,y in poly),min(y for x,y in poly),max(x for x,y in poly),max(y for x,y in poly))
        polygons[t['geometry']].append((ti,site,poly,bounds))
nodes=[];parents=[]
for f,numbers in enumerate([parent['retained_bracket_nodes'],parent['retained_insert_nodes']]):
    for pn in numbers:
        p=oldnodes[pn];box=p['bounds_um'];axes=[]
        for lo,hi in zip(box[:2],box[2:]):
            axes.append([(lo,(lo+hi)//2),((lo+hi)//2,hi)] if hi-lo>=2 else [(lo,hi)])
        children=[]
        for (x0,x1),(y0,y1) in product(*axes):
            n=len(nodes);children.append(n)
            nodes.append({'node':n,'family':f,'geometry':p['geometry'],'parent_node':pn,'bounds_um':[x0,y0,x1,y1]})
        parents.append({'parent_node':pn,'children':children})
removed=[];retained=[[],[]];cache={};queries=[]
for node in nodes:
    key=(node['geometry'],tuple(node['bounds_um']))
    if key not in cache:
        qi=len(queries);cache[key]=qi;query={'query':qi,'geometry':node['geometry'],'bounds_um':node['bounds_um'],'certificate':None,'scan_limited':False}
        if time.perf_counter()-started>=10:query['scan_limited']=True
        else:
            a,b,c,d=[v*scale for v in node['bounds_um']]
            for ti,site,poly,(px0,py0,px1,py1) in polygons[node['geometry']]:
                if not (px0<a and py0<b and c<px1 and d<py1):continue
                if all((v[0]-u[0])*(y-u[1])-(v[1]-u[1])*(x-u[0])>0
                       for u,v in zip(poly,poly[1:]+poly[:1]) for x,y in product([a,c],[b,d])):
                    query['certificate']={'template':ti,'site':site};break
        queries.append(query)
    qi=cache[key];node['query']=qi
    if queries[qi]['certificate'] is not None:removed.append(node['node'])
    else:retained[node['family']].append(node['node'])
    assert time.perf_counter()-started<15
write(OUT/'nodes.json',nodes);write(OUT/'parents.json',parents);write(OUT/'queries.json',queries)
write(OUT/'retained.json',{'bracket':retained[0],'insert':retained[1],'removed':removed})
checks={'prepared':True,'seconds':time.perf_counter()-started,'parent_cells':len(parents),'child_cells':len(nodes),
    'unique_child_queries':len(queries),'source_certified_removed_children':len(removed),'retained_children':list(map(len,retained)),
    'limited_queries':sum(q['scan_limited'] for q in queries),'new_whole_arrangement_exclusions':0,'remaining_fixed29_choices':26,
    'independent_geometry_audit_pending':True,'placement_solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
