"""Independent complete-query replay, including every negative coverage result."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import ast,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-fixed-core-clearance-20261106';OUT=BASE/'audit'
PROCESS=ROOT/'output/h5-first57-fixed-core-clearance-process-20261106'
FRONTIER=ROOT/'output/h5-first57-clearance-pair-trees-20261106';CLEAR=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';HELPER=ROOT/'output/audit_h5_union_conflict_probe_v2_20261106.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
inputs={Path(__file__),HELPER,JOB,BASE/'plan.json',BASE/'checks.json',BASE/'templates.json',BASE/'queries.json',
    PROCESS/'opened.json',PROCESS/'process.json',SOURCE/'geometry-domains.json',SOURCE/'fixed-core-inner-rectangles.json',
    FRONTIER/'plan.json',FRONTIER/'audit/remaining-fixed29-choices.json'}
for base in [BASE,SOURCE/'audit',FRONTIER/'audit',CLEAR/'audit-v2']:
    inputs.add(base/'plan.json')
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [SOURCE/'audit',FRONTIER/'audit',CLEAR/'audit-v2']:
    inputs.add(base/'checks.json');assert load(base/'checks.json')['passed']
process=load(PROCESS/'process.json');assert process['closed'] and not process['timeout'] and process['exit_code']==0 and process['complete_process_cap_overrun_seconds']==0
plan=load(BASE/'plan.json');assert load(JOB)['clearance']==plan['required_job_clearance_mm']==0.2 and plan['expansion_square_radius_um']==140
assert 2*140**2<200**2
remaining={tuple(r['empty_sites']) for r in load(FRONTIER/'audit/remaining-fixed29-choices.json')}
selection=[r for r in load(FRONTIER/'plan.json')['selection'] if tuple(r['empty_sites']) in remaining];assert len(selection)==26 and plan['selection']==selection
geometry=load(SOURCE/'geometry-domains.json');fixed=load(SOURCE/'fixed-core-inner-rectangles.json');assert len(fixed)==29
expected=[]
for g in geometry:
    for fi,fr in enumerate(fixed):
        a=fr['bounds_um']
        for ri,b in enumerate(g['inner_rectangles_um']):
            expected.append({'template':len(expected),'geometry':g['geometry'],'fixed_rectangle':fi,'moving_component':ri,
                'bounds_um':[a[0]-b[2]-140,a[1]-b[3]-140,a[2]-b[0]+140,a[3]-b[1]+140]})
assert load(BASE/'templates.json')==expected
point_checks=[0]
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in ['classes','covered']]
assert len(functions)==2;exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
queries=load(BASE/'queries.json');keys=set()
for qi,q in enumerate(queries):
    assert q['query']==qi and q['geometry'] in range(10)
    box=q['bounds_um'];assert len(box)==4 and all(type(v) is int for v in box) and box[0]<=box[2] and box[1]<=box[3]
    key=(q['geometry'],tuple(box));assert key not in keys;keys.add(key)
    intersecting=[r['template'] for r in expected if r['geometry']==q['geometry'] and all(r['bounds_um'][i]<box[i+2] and box[i]<r['bounds_um'][i+2] for i in [0,1])]
    if q['reason']=='scan_limit':assert not q['closed'] and not q['candidate_templates'];continue
    if q['reason']=='single':
        assert len(q['candidate_templates'])==1 and q['candidate_templates'][0] in intersecting
    else:assert q['candidate_templates']==intersecting
    rects=[expected[i]['bounds_um'] for i in q['candidate_templates']]
    assert covered(box,rects)==q['closed']
    assert q['reason'] in (['single','union'] if q['closed'] else ['unproved_union'])
results=[];consumed=set();removed_total=0
for ci,row in enumerate(selection):
    paths=[BASE/f'choice-{ci:02d}.json',BR/f"choice-{row['choice_index']:02d}.json",INS/f"choice-{row['insert_choice_index']:02d}.json",CLEAR/f"choice-{row['clearance_pruning_index']:02d}.json"]
    inputs.update(paths);data,br,ins,parent=map(load,paths);offset=len(br['nodes']);nodes=br['nodes']+ins['nodes']
    assert data['source_selection']==row and data['empty_sites']==parent['empty_sites']==br['empty_sites']==ins['empty_sites']==row['empty_sites']
    assert data['original_bracket_node_count']==offset and not data['whole_arrangement_excluded']
    retained=parent['retained_bracket_nodes']+parent['retained_insert_nodes']
    assert [r['node'] for r in data['node_queries']]==retained
    removed=[]
    for record in data['node_queries']:
        n,qi=record['node'],record['query'];q=queries[qi];consumed.add(qi)
        assert q['geometry']==nodes[n]['geometry'] and q['bounds_um']==nodes[n]['bounds_um']
        if q['closed']:removed.append(record)
    assert data['removed']==removed
    removed_ids={r['node'] for r in removed}
    assert data['retained_bracket_nodes']==[n for n in parent['retained_bracket_nodes'] if n not in removed_ids]
    assert data['retained_insert_nodes']==[n for n in parent['retained_insert_nodes'] if n not in removed_ids]
    removed_total+=len(removed)
    results.append({'fixed_core_index':ci,'source_selection':row,'removed_nodes':len(removed)})
assert consumed==set(range(len(queries)))
write(OUT/'stronger-model-candidates.json',[r for r in results if r['removed_nodes']])
write(OUT/'remaining-fixed29-choices.json',load(FRONTIER/'audit/remaining-fixed29-choices.json'))
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in sorted(inputs)},
    'proof':'Original fixed-core and moving inner rectangles are independently contained in source filled outlines under no part-in-hole placement. Exact difference rectangles expanded by a140 micrometre square lie inside the original200 micrometre source-distance forbidden region. Every closed query is replayed over all exact Cartesian boundary/open-interval classes. Every non-limited union query includes every intersecting template, and its reported negative or positive predicate is independently checked. Every consumed parent cell is mapped once; only certified closed queries can remove it. A negative coverage predicate is not a source-valid placement, and unchanged domains cannot justify another tree.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':results,'exact_templates_verified':len(expected),'unique_queries_verified':len(queries),
    'closed_queries':sum(q['closed'] for q in queries),'limited_queries':sum(q['reason']=='scan_limit' for q in queries),'cartesian_class_checks':point_checks[0],
    'removed_node_occurrences':removed_total,'cases_with_genuinely_smaller_domains':sum(r['removed_nodes']>0 for r in results),
    'required_job_clearance_mm':0.2,'expansion_square_radius_um':140,'new_zero_clearance_exclusion_claimed':False,
    'new_fixed29_choices_excluded':0,'total_fixed29_choices_excluded_at_required_clearance':429,'remaining_fixed29_choices':26,
    'whole_allocation_candidates':440,'placement_solver_calls':0,'native_calls':0,'source_valid66':False,'H5_complete':False}
write(OUT/'checks.json',result);print({k:v for k,v in result.items() if k!='choices'})
