"""Bounded exact root pruning against the original fixed core at required clearance."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-fixed-core-clearance-20261106'
FRONTIER=ROOT/'output/h5-first57-clearance-pair-trees-20261106'
CLEAR=ROOT/'output/h5-first57-clearance-cog-pruning-20261106'
BR=ROOT/'output/h5-first57-full-frontier-cliques-20261104';INS=ROOT/'output/h5-first57-broader-insert-covers-20261106'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
HELPER=ROOT/'output/prepare_h5_union_conflict_probe_20261106.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for p in [FRONTIER/'audit/checks.json',CLEAR/'audit-v2/checks.json',SOURCE/'audit/checks.json']:assert load(p)['passed']
assert load(JOB)['clearance']==0.2 and 2*140**2<200**2
remaining={tuple(r['empty_sites']) for r in load(FRONTIER/'audit/remaining-fixed29-choices.json')}
selection=[r for r in load(FRONTIER/'plan.json')['selection'] if tuple(r['empty_sites']) in remaining];assert len(selection)==26
geometry=load(SOURCE/'geometry-domains.json');fixed=load(SOURCE/'fixed-core-inner-rectangles.json');assert len(fixed)==29
function=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='union_covers']
assert len(function)==1;exec(compile(ast.Module(body=function,type_ignores=[]),str(HELPER),'exec'))
inputs=[Path(__file__),HELPER,JOB,SOURCE/'geometry-domains.json',SOURCE/'fixed-core-inner-rectangles.json',SOURCE/'audit/plan.json',SOURCE/'audit/checks.json',
    FRONTIER/'plan.json',FRONTIER/'audit/plan.json',FRONTIER/'audit/checks.json',FRONTIER/'audit/remaining-fixed29-choices.json',CLEAR/'audit-v2/plan.json',CLEAR/'audit-v2/checks.json']
inputs += [base/f"choice-{row[index]:02d}.json" for row in selection for base,index in [(BR,'choice_index'),(INS,'insert_choice_index'),(CLEAR,'clearance_pruning_index')]]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'selection':selection,'required_job_clearance_mm':0.2,'expansion_square_radius_um':140,'scan_cutoff_seconds':25,'preparation_cap_seconds':30,'maximum_process_seconds':40,
    'method':'For each unique retained anchor cell, form exact differences of certified fixed-core and moving source-inner rectangles, expanded by a140 micrometre square inside the original200 micrometre required-clearance ball. Certify complete closed-cell coverage by one open rectangle or an exact union. Cache only geometry/bounds-dependent fixed-core proofs. Keep every unproved or unvisited cell. Every removal needs independent source and boundary-class replay before use. No prior search is repeated.',
    'repeat_permitted':False,'placement_solver_calls':0,'native_calls':0})
templates=[]
for g in geometry:
    for fi,fixed_rect in enumerate(fixed):
        a=fixed_rect['bounds_um']
        for ri,b in enumerate(g['inner_rectangles_um']):
            templates.append({'template':len(templates),'geometry':g['geometry'],'fixed_rectangle':fi,'moving_component':ri,
                'bounds_um':[a[0]-b[2]-140,a[1]-b[3]-140,a[2]-b[0]+140,a[3]-b[1]+140]})
write(OUT/'templates.json',templates)
by_geometry={g:[r for r in templates if r['geometry']==g] for g in range(10)}
queries=[];cache={};results=[]
for ci,row in enumerate(selection):
    br=load(BR/f"choice-{row['choice_index']:02d}.json");ins=load(INS/f"choice-{row['insert_choice_index']:02d}.json")
    parent=load(CLEAR/f"choice-{row['clearance_pruning_index']:02d}.json");nodes=br['nodes']+ins['nodes'];offset=len(br['nodes'])
    assert parent['empty_sites']==br['empty_sites']==ins['empty_sites']==row['empty_sites']
    removed=[];node_queries=[];retained_b=[];retained_i=[]
    for n in parent['retained_bracket_nodes']+parent['retained_insert_nodes']:
        node=nodes[n];box=node['bounds_um'];key=(node['geometry'],tuple(box))
        if key not in cache:
            qi=len(queries);cache[key]=qi
            proof={'query':qi,'geometry':node['geometry'],'bounds_um':box,'closed':False,'candidate_templates':[]}
            if time.perf_counter()-started>=25:proof['reason']='scan_limit'
            else:
                candidates=[r for r in by_geometry[node['geometry']] if all(r['bounds_um'][i]<box[i+2] and box[i]<r['bounds_um'][i+2] for i in [0,1])]
                single=next((r for r in candidates if all(r['bounds_um'][i]<box[i] and box[i+2]<r['bounds_um'][i+2] for i in [0,1])),None)
                if single:proof.update({'closed':True,'candidate_templates':[single['template']],'reason':'single'})
                else:
                    proof['candidate_templates']=[r['template'] for r in candidates]
                    proof['closed']=union_covers(box,[r['bounds_um'] for r in candidates]) is not None
                    proof['reason']='union' if proof['closed'] else 'unproved_union'
            queries.append(proof)
        qi=cache[key];node_queries.append({'node':n,'query':qi})
        if queries[qi]['closed']:removed.append({'node':n,'query':qi})
        elif n<offset:retained_b.append(n)
        else:retained_i.append(n)
    result={'source_selection':row,'empty_sites':row['empty_sites'],'original_bracket_node_count':offset,'node_queries':node_queries,
        'removed':removed,'retained_bracket_nodes':retained_b,'retained_insert_nodes':retained_i,'whole_arrangement_excluded':False}
    write(OUT/f'choice-{ci:02d}.json',result)
    results.append({'fixed_core_index':ci,'source_selection':row,'removed_nodes':len(removed),'retained_bracket_nodes':len(retained_b),'retained_insert_nodes':len(retained_i)})
    assert time.perf_counter()-started<30
write(OUT/'queries.json',queries)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':results,'templates':len(templates),'unique_queries':len(queries),
    'closed_queries':sum(q['closed'] for q in queries),'removed_node_occurrences':sum(r['removed_nodes'] for r in results),
    'stronger_cases':sum(r['removed_nodes']>0 for r in results),'limited_queries':sum(q['reason']=='scan_limit' for q in queries),
    'independent_audit_pending':True,'whole_arrangements_excluded':0,'remaining_fixed29_choices':26,'placement_solver_calls':0,'native_calls':0,'H5_complete':False})
print({k:v for k,v in load(OUT/'checks.json').items() if k!='choices'})
