"""Independent exact-rational containment, area and cover checks for the three relaxations."""
from fractions import Fraction as F
from itertools import combinations
import math,shutil,time
from shapely.geometry import box,Point
from shapely.ops import unary_union
from audit_h5_cog_lattices import shape
from audit_h5_cog_center_capacity import winding,intersects_rectangle
from audit_h5_cog_reachable_area import exact_difference_area
from bound_h5_group_choice_regions import ROOT,SRC,RUN,CENTER,AREA,OUT,S,load,write,digest
def main():
    dst=OUT/'audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');start=time.perf_counter()
    for name,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/name)==h
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};stock=job['stocks'][0];m=stock['margins'];edge=F(job['edge_clearance'])
    target=load(SRC/'conditional-target.json');pool=load(SRC/'candidates.json');selected=load(RUN/'solve/selected-indices.json')
    disk=load(CENTER/'disk.json');cog=load(AREA/'cog.json');primitives=load(OUT/'interior-rectangles.json')
    radius=disk['radius_units'];circum=cog['circumradius_units'];sep=disk['center_separation_units'];area_lower=F(*cog['filled_area_lower_bound'])
    vs=[(F(x),F(y)) for x,y in parts['cog']['geometry'][0]['outer']];origin=vs[0]
    original_area=abs(sum((a[0]-origin[0])*(b[1]-origin[1])-(a[1]-origin[1])*(b[0]-origin[0]) for a,b in zip(vs[1:],vs[2:])))/2
    assert 0<area_lower<=original_area-F(1,1000000)
    for primitive in primitives:
        i=primitive['candidate'];p=pool[i]['placement'];assert i in selected and p['part_id']!='cog' and primitive['family']==p['part_id'] and primitive['sheet_id']==p['sheet_id']
        t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);vs=[]
        for x,y in parts[p['part_id']]['geometry'][0]['outer']:
            if t['mirrored']:x=-x
            vs.append([F(x*c-y*s+t['translation'][0]),F(x*s+y*c+t['translation'][1])])
        rect=[F(v,S) for v in primitive['inner_rectangle_units']];assert rect[0]<rect[2] and rect[1]<rect[3]
        assert all(winding((x,y),vs) for x in [rect[0],rect[2]] for y in [rect[1],rect[3]])
        assert not any(intersects_rectangle(a,b,rect) for a,b in zip(vs,vs[1:]+vs[:1]))
    expected_cases=[('noncogs-fixed',{'frame','bracket','insert'}),('frames-brackets-fixed',{'frame','bracket'}),('frames-fixed',{'frame'})]
    result=load(OUT/'result.json');assert [r['case'] for r in result['cases']]+result['pending']==[c for c,f in expected_cases]
    records=[];components_checked=covers_checked=0
    for name,families in expected_cases[:len(result['cases'])]:
        case=load(OUT/(name+'.json'));fixed=sorted(i for i in selected if pool[i]['placement']['part_id'] in families);assert case['fixed_candidates']==fixed
        bounds=[];seed_checks=0
        for r in case['sheets']:
            sheet=r['sheet'];height=F(stock['height'] if sheet=='sheet-0' else target['required_used_height_mm']);tol=F(1,1000000)
            domain=[math.floor((F(m['left'])+edge+F(radius,S)-tol)*S),math.floor((F(m['bottom'])+edge+F(radius,S)-tol)*S),
              math.ceil((F(stock['width'])-F(m['right'])-edge-F(radius,S)+tol)*S),math.ceil((height-F(m['top'])-edge-F(radius,S)+tol)*S)]
            usable=[math.floor((F(m['left'])+edge-tol)*S),math.floor((F(m['bottom'])+edge-tol)*S),
              math.ceil((F(stock['width'])-F(m['right'])-edge+tol)*S),math.ceil((height-F(m['top'])-edge+tol)*S)]
            assert r['center_domain_units']==domain and r['solid_domain_units']==usable
            solids=[p['inner_rectangle_units'] for p in primitives if p['candidate'] in fixed and p['sheet_id']==sheet]
            assert solids==r['solid_rectangles'];forbidden=[]
            for a,b,c,d in solids:
                for x,y in disk['offset_rectangles_half_sizes_units']:
                    z=[max(domain[0],a-x),max(domain[1],b-y),min(domain[2],c+x),min(domain[3],d+y)]
                    if z[0]<z[2] and z[1]<z[3]:forbidden.append(z)
            assert forbidden==r['forbidden_rectangles'];free=r['free_cells'];measure=exact_difference_area(free,[])
            assert measure==sum((c-a)*(d-b) for a,b,c,d in free)
            assert exact_difference_area(free,[domain])==0 and exact_difference_area(free,forbidden)==measure
            assert exact_difference_area([domain],forbidden)==measure
            seen=[];included=[];cb=[]
            for comp in r['components']:
                components_checked+=1;ids=comp['cell_indices'];seen+=ids;cells=[free[i] for i in ids]
                inc=[[max(usable[0],a-circum),max(usable[1],b-circum),min(usable[2],c+circum),min(usable[3],d+circum)] for a,b,c,d in cells]
                assert inc==comp['included_reachable_rectangles'];included+=inc;area=exact_difference_area(inc,solids)
                assert area==comp['reachable_area_units_squared'];ab=F(area,S*S)//area_lower;assert ab==comp['area_bound']
                bbox=comp['bounding_box_units'];assert all(bbox[0]<=a<c<=bbox[2] and bbox[1]<=b<d<=bbox[3] for a,b,c,d in cells)
                grid=comp['grid'];nx,ny=grid['columns'],grid['rows'];w=(bbox[2]-bbox[0]+nx-1)//nx;h=(bbox[3]-bbox[1]+ny-1)//ny
                assert nx>0 and ny>0 and grid['capacity']==nx*ny and w*w+h*h<sep*sep
                bs=[]
                for cover in comp['band_covers']:
                    covers_checked+=1;rects=cover['rectangles_units'];assert len(rects)==cover['capacity']
                    assert all(a<c and b<d and (c-a)**2+(d-b)**2<sep*sep for a,b,c,d in rects)
                    assert exact_difference_area(cells,rects)==0;bs.append(len(rects))
                bound=min(ab,nx*ny,*bs);assert bound==comp['upper_bound'];cb.append(bound)
            assert sorted(seen)==list(range(len(free)))
            area=exact_difference_area(included,solids);assert area==r['whole_reachable_area_units_squared']
            bound=min(F(area,S*S)//area_lower,sum(cb));assert r['whole_area_bound']==F(area,S*S)//area_lower and bound==r['upper_bound'];bounds.append(bound)
            center_region=unary_union([box(*(v/S for v in cell)) for cell in free])
            reach=unary_union([box(*(v/S for v in cell)) for cell in included]).difference(unary_union([box(*(v/S for v in cell)) for cell in solids]))
            for i in selected:
                p=pool[i]['placement']
                if p['part_id']!='cog' or p['sheet_id']!=sheet:continue
                t=p['transform'];a=shape(parts['cog'],t);x,y=[float(F(*v)) for v in disk['center']];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians'])
                point=Point(x*c-y*s+t['translation'][0],x*s+y*c+t['translation'][1])
                assert center_region.covers(point) and a.difference(reach).area<1e-6;seed_checks+=1
        assert seed_checks==13 and sum(bounds)==case['upper_bound']
        records.append({'case':name,'sheet_bounds':bounds,'upper_bound':sum(bounds),'fifteen_cogs_ruled_out':sum(bounds)<15,'original_cogs_retained':seed_checks})
    check={'passed':True,'seconds':time.perf_counter()-start,'records':records,'interior_rectangles_verified':len(primitives),
      'components_verified':components_checked,'band_covers_verified':covers_checked,'all_exact_area_and_complement_checks':True,
      'full_target_witness':False,'native_packing_calls':0,'quality_runs':0}
    write(dst/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
