"""Three continuous cog-capacity relaxations of the new 62-part partial."""
from fractions import Fraction as F
from datetime import datetime,timezone
from collections import Counter
import math,shutil,time,traceback
from bound_h5_cog_centers import q,point_inside,box_inside,transform,free_slabs,distance_squared
from census_h5_non_cog_releases import component_bound
from bound_h5_cog_reachable_area import sweep_area
from build_h5_group_choice import ROOT,SRC,load,write,digest
RUN=ROOT/'output/h5-group-choice-20261023'
CENTER=ROOT/'output/h5-cog-center-capacity-20261020'
AREA=ROOT/'output/h5-cog-reachable-area-20261020'
OUT=ROOT/'output/h5-group-choice-regions-20261023'
S=10000
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'bound.py')
    inputs=[RUN/n for n in ['solve/selected-indices.json','layout-audit/checks.json']]+[SRC/n for n in ['candidates.json','job.json','conditional-target.json']]
    inputs += [CENTER/n for n in ['disk.json','audit/checks.json','sheet-0.json','sheet-1.json']]
    inputs += [AREA/n for n in ['cog.json','sheet-0.json','sheet-1.json','audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
      'maximum_cases':3,'seconds_limit':90,'cases':['noncogs-fixed','frames-brackets-fixed','frames-fixed'],
      'method':'From the final62-part layout, compare three necessary cog-capacity relaxations: all49 non-cogs fixed; only18 frames and12 brackets fixed with every insert omitted; only18 frames fixed with every bracket and insert omitted. Derive exact strictly interior rectangles from original transformed geometry. Reuse hash-bound original cog disks and outward stock domains. Compute all-angle center regions and bound capacity by reachable area, rectangle diameter and band covers. At least15 is inconclusive, not permission to claim all families coexist. Save all completed cases and pending cases, no limit extension.',
      'native_packing_calls':0,'solver_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    start=time.perf_counter();pool=load(SRC/'candidates.json');selected=load(RUN/'solve/selected-indices.json')
    assert load(RUN/'layout-audit/checks.json')['passed']
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};disk=load(CENTER/'disk.json');cog=load(AREA/'cog.json')
    local_cog=[(F(x),F(y)) for x,y in parts['cog']['geometry'][0]['outer']];center=[F(*v) for v in disk['center']]
    assert point_inside(center,local_cog)
    assert min(distance_squared(center,a,b) for a,b in zip(local_cog,local_cog[1:]+local_cog[:1]))>F(disk['radius_units'],S)**2
    assert all(sum((v[k]-center[k])**2 for k in [0,1])<F(cog['circumradius_units'],S)**2 for v in local_cog)
    assert disk['effective_clearance_units']/S<job['clearance']-1e-7
    assert disk['center_separation_units']==2*disk['radius_units']+disk['effective_clearance_units']
    assert all(x*x+y*y<=disk['forbidden_offset_radius_units']**2 for x,y in disk['offset_rectangles_half_sizes_units'])
    primitives=[]
    for i in selected:
        p=pool[i]['placement'];f=p['part_id']
        if f=='cog':continue
        points=parts[f]['geometry'][0]['outer'];vs=[(q(x),q(y)) for x,y in points]
        xs,ys=sorted({x for x,y in points}),sorted({y for x,y in points})
        world=[(q(x),q(y)) for x,y in transform(points,p['transform'])]
        for a,c in zip(xs,xs[1:]):
            for b,d in zip(ys,ys[1:]):
                if not point_inside((q((a+c)/2),q((b+d)/2)),vs):continue
                corners=transform([(a,b),(c,b),(c,d),(a,d)],p['transform'])
                rect=[math.ceil(min(x for x,y in corners)*S)+1,math.ceil(min(y for x,y in corners)*S)+1,
                      math.floor(max(x for x,y in corners)*S)-1,math.floor(max(y for x,y in corners)*S)-1]
                assert box_inside([F(v,S) for v in rect],world)
                primitives.append({'candidate':i,'family':f,'sheet_id':p['sheet_id'],'local_cell':[a,b,c,d],'inner_rectangle_units':rect})
    write(OUT/'interior-rectangles.json',primitives)
    selections=[('noncogs-fixed',{'frame','bracket','insert'}),('frames-brackets-fixed',{'frame','bracket'}),('frames-fixed',{'frame'})]
    records=[]
    for name,families in selections:
        if time.perf_counter()-start>=90:break
        fixed=sorted(i for i in selected if pool[i]['placement']['part_id'] in families);sheets=[]
        for sheet in ['sheet-0','sheet-1']:
            domain=load(CENTER/f'{sheet}.json')['domain_units'];usable=load(AREA/f'{sheet}.json')['usable_domain_units']
            solids=[];obstacles=[]
            for r in primitives:
                if r['candidate'] not in fixed or r['sheet_id']!=sheet:continue
                a,b,c,d=r['inner_rectangle_units'];solids.append([a,b,c,d])
                obstacles.extend([[a-x,b-y,c+x,d+y] for x,y in disk['offset_rectangles_half_sizes_units']])
            cells,groups,clipped=free_slabs(domain,obstacles);components=[]
            for ids in groups:
                c=component_bound([cells[i] for i in ids],usable,solids,cog['circumradius_units'],disk['center_separation_units'],F(*cog['filled_area_lower_bound']))
                c['cell_indices']=ids;components.append(c)
            inc=[r for c in components for r in c['included_reachable_rectangles']];_,area=sweep_area(inc,solids)
            area_bound=F(area,S*S)//F(*cog['filled_area_lower_bound']);bound=min(area_bound,sum(c['upper_bound'] for c in components))
            sheets.append({'sheet':sheet,'center_domain_units':domain,'solid_domain_units':usable,'solid_rectangles':solids,
              'forbidden_rectangles':clipped,'free_cells':cells,'components':components,'whole_reachable_area_units_squared':area,'whole_area_bound':area_bound,'upper_bound':bound})
        total=sum(s['upper_bound'] for s in sheets)
        record={'case':name,'fixed_candidates':fixed,'fixed_counts':dict(Counter(pool[i]['placement']['part_id'] for i in fixed)),
          'sheets':sheets,'upper_bound':total,'fifteen_cogs_ruled_out':total<15}
        write(OUT/(name+'.json'),record);records.append({k:v for k,v in record.items() if k not in ['sheets','fixed_candidates']})
        print(records[-1],flush=True)
    write(OUT/'result.json',{'cases':records,'seconds':time.perf_counter()-start,'pending':[name for name,_ in selections[len(records):]],'independent_audit_pending':True})
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
