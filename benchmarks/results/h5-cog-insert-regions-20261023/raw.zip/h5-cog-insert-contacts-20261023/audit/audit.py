"""Check all two-family source events and geometry independently before selecting."""
from collections import Counter,deque
from itertools import combinations
import math,shutil,time
import numpy as np
import shapely
from shapely.geometry import shape as read_geometry
from audit_h5_cog_lattices import shape
from build_h5_cog_free_regions import identity,proposals
from build_h5_group_choice import ROOT,SRC,load,write,digest,rows
from build_h5_cog_insert_contacts import OUT,SEED
def main():
    dst=OUT/'audit';dst.mkdir();shutil.copyfile(__file__,dst/'audit.py');start=time.perf_counter()
    plan=load(OUT/'plan.json')
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h
    source=load(SRC/'candidates.json');pool=load(OUT/'candidates.json');assert pool[:len(source)]==source
    mp=load(OUT/'mapping.json');result=load(OUT/'result.json');job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']}
    selected=set(load(SEED/'solve/selected-indices.json'));fixed=mp['fixed_candidates'];seed=mp['seed_candidates']
    assert fixed==sorted(i for i in selected if pool[i]['placement']['part_id'] in ['frame','bracket']) and seed==sorted(selected-set(fixed))
    gs={i:shape(parts[p['placement']['part_id']],p['placement']['transform']) for i,p in enumerate(pool)}
    here={s:[i for i in fixed if pool[i]['placement']['sheet_id']==s] for s in ['sheet-0','sheet-1']}
    eligible=[];oldpairs=0;filters=load(OUT/'old-filter.json');small=[i for i,p in enumerate(source) if p['placement']['part_id'] in ['cog','insert']]
    assert len(filters)==len(small)
    for i,row in zip(small,filters):
        blockers=[]
        for j in here[pool[i]['placement']['sheet_id']]:
            oldpairs+=1
            if gs[i].distance(gs[j])<job['clearance']-1e-7:blockers.append(j)
        assert row=={'candidate':i,'fixed_blockers':blockers}
        if not blockers:eligible.append(i)
    assert eligible==mp['old_eligible']
    queries=[load(OUT/'regions'/f'query-{i}.json') for i in range(result['queries'])]
    for q in queries:
        item=plan['queries'][q['index']];assert item=={k:q[k] for k in ['sheet','family','degrees']}
        region=read_geometry(q['region']);assert region.area==q['region_area'] and region.is_empty==q['region_empty']
        assert q['proposals']==proposals(region) and q['rotation_radians']==math.radians(q['degrees'])
    queue=deque((q['index'],0) for q in queries if q['proposals']);keys={identity(p['placement']):i for i,p in enumerate(source)}
    added=[];counts=Counter();deferred=[];target=load(SRC/'conditional-target.json');stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];proposalpairs=rejected=0
    for event in load(OUT/'source-events.json'):
        while True:
            qi,pi=queue.popleft();q=queries[qi]
            if counts[q['family']]>=plan['new_candidate_caps'][q['family']]:deferred.append([qi,pi])
            else:break
        assert (event['query'],event['proposal'])==(qi,pi)
        p={'part_id':q['family'],'sheet_id':q['sheet'],'transform':{'rotation_radians':q['rotation_radians'],'translation':q['proposals'][pi]['point'],'mirrored':False}}
        g=shape(parts[p['part_id']],p['transform']);a,b,c,d=g.bounds;height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        outside=a<m['left']+edge-1e-7 or b<m['bottom']+edge-1e-7 or c>stock['width']-m['right']-edge+1e-7 or d>height-m['top']-edge+1e-7
        blockers=[];distances=[]
        for j in here[p['sheet_id']]:
            proposalpairs+=1;distances.append(g.distance(gs[j]))
            if distances[-1]<job['clearance']-1e-7:blockers.append(j)
        if outside or blockers:
            rejected+=1;assert event=={'query':qi,'proposal':pi,'added':False,'reason':'geometry','outside':bool(outside),'blockers':blockers}
        elif identity(p) in keys:assert event=={'query':qi,'proposal':pi,'added':False,'reason':'duplicate','candidate':keys[identity(p)]}
        else:
            i=len(source)+len(added);assert event=={'query':qi,'proposal':pi,'added':True,'candidate':i} and pool[i]['placement']==p
            assert pool[i]['source']=={'kind':'joint-cog-insert-contact','query':qi,'proposal':pi} and abs(pool[i]['filled_area_mm2']-g.area)<1e-7
            padding=plan['new_pose_padding_mm'];assert not distances or min(distances)>=job['clearance']+padding-1e-7
            assert a>=m['left']+edge+padding-1e-7 and b>=m['bottom']+edge+padding-1e-7
            assert c<=stock['width']-m['right']-edge-padding+1e-7 and d<=height-m['top']-edge-padding+1e-7
            keys[identity(p)]=i;added.append(i);counts[q['family']]+=1
        if pi+1<len(q['proposals']):queue.append((qi,pi+1))
    pending=load(OUT/'pending.json');assert pending['unbuilt_queries']==plan['queries'][len(queries):]
    assert pending['proposals']==sorted(deferred+list(map(list,queue))) and added==mp['new_candidates'] and dict(counts)==result['new_candidates']
    ids=mp['candidates'];assert ids==sorted(eligible+added)
    for i in ids+fixed:
        p=pool[i]['placement'];t=p['transform'];part=parts[p['part_id']];g=gs[i];a,b,c,d=g.bounds
        assert g.is_valid and (not t['mirrored'] or part['allow_mirror'])
        if part['rotations']['kind']=='list':assert any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in part['rotations']['degrees'])
        height=stock['height'] if p['sheet_id']=='sheet-0' else target['required_used_height_mm']
        assert a>=m['left']+edge-1e-7 and b>=m['bottom']+edge-1e-7 and c<=stock['width']-m['right']-edge+1e-7 and d<=height-m['top']-edge+1e-7
    for a,b in combinations(fixed,2):
        if pool[a]['placement']['sheet_id']==pool[b]['placement']['sheet_id']:assert gs[a].disjoint(gs[b]) and gs[a].distance(gs[b])>=job['clearance']-1e-7
    gg=np.asarray([gs[i] for i in ids],dtype=object);bb=shapely.bounds(gg);ss=np.asarray([pool[i]['placement']['sheet_id'] for i in ids]);adj=[0]*len(ids);edges=set();allpairs=near=0
    for i in range(len(ids)):
        js=np.arange(i+1,len(ids));js=js[ss[js]==ss[i]];allpairs+=len(js)
        dx=np.maximum(0,np.maximum(bb[js,0]-bb[i,2],bb[i,0]-bb[js,2]));dy=np.maximum(0,np.maximum(bb[js,1]-bb[i,3],bb[i,1]-bb[js,3]))
        js=js[np.hypot(dx,dy)<=job['clearance']+1e-7];near+=len(js)
        for j in js[shapely.distance(gg[i],gg[js])<job['clearance']-1e-7]:
            j=int(j);edges.add((i,j));adj[i]|=1<<j;adj[j]|=1<<i
    saved=rows(OUT/'conflicts.jsonl.gz');assert len(saved)==len(edges) and set(map(tuple,saved))==edges
    covered=[0]*len(ids);cliques=rows(OUT/'cliques.jsonl.gz')
    for c in cliques:
        assert len(c)==len(set(c));mask=sum(1<<j for j in c)
        for j in c:assert not((mask^(1<<j))&~adj[j]);covered[j]|=mask^(1<<j)
    assert adj==covered;local={i:j for j,i in enumerate(ids)};sm=sum(1<<local[i] for i in seed)
    assert all(not(adj[local[i]]&sm) for i in seed)
    check={'passed':True,'seconds':time.perf_counter()-start,'old_filter_pairs':oldpairs,'proposal_fixed_pairs':proposalpairs,'rejections_verified':rejected,
      'queries_verified':len(queries),'new_candidates':dict(counts),'all_small_pair_possibilities':allpairs,'exact_pair_distances':near,'conflicts':len(edges),'cliques':len(cliques),
      'all_pair_types_and_full_clique_coverage':True,'all_actual_proposals_and_stock_bounds_checked':True,'old_seed_preserved':True,'native_margin_qualified':False}
    write(dst/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
