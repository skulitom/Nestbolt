"""A distinct complete frame arrangement and optional side-strip insert poses."""
from collections import Counter
from datetime import datetime,timezone
from itertools import combinations
import copy,math,shutil
from audit_h5_cog_lattices import shape
from build_h5_group_choice import ROOT,SRC,CENSUS,load,write,digest
OUT=ROOT/'output/h5-wide-frame-group-20261023'
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py')
    inputs=[SRC/'job.json',SRC/'candidates.json',CENSUS/'groups.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
      'method':'Review all26 prior exact frame groups by axis orientation. Construct one distinct3-column/6-row group of all18 original450x350 frames at0 degrees, with0.225mm pair gaps and0.025mm extra stock margin. Also construct11 optional110x180 insert poses in the resulting side strip, with original90-degree rotation and the same gaps. These insert poses are optional future candidates, not required fixed obstacles. Independently check original transformed geometry, all pair distances, rotation permission and stock bounds. No full-job or native-margin acceptance claim.',
      'native_packing_calls':0,'solver_calls':0,'quality_runs':0,'held_out_files_evaluated':0})
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};pool=load(SRC/'candidates.json');groups=load(CENSUS/'groups.json')
    census=[]
    for group in groups:
        counts=Counter(round(math.degrees(pool[i]['placement']['transform']['rotation_radians']))%180 for i in group['candidates'])
        assert sum(counts.values())==18;census.append({'group':group['index'],'axis_orientations':dict(counts)})
    assert all(r['axis_orientations'].get(0,0)<18 for r in census);write(OUT/'prior-frame-census.json',census)
    stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];gap=.225;extra=.025;origin=[m['left']+edge+extra,m['bottom']+edge+extra]
    unrotated=shape(parts['frame'],{'rotation_radians':0,'translation':[0,0],'mirrored':False});a,b,c,d=unrotated.bounds;assert abs(c-a-450)<1e-9 and abs(d-b-350)<1e-9
    frames=[]
    for row in range(6):
        for col in range(3):
            frames.append({'part_id':'frame','sheet_id':'sheet-0','copy_index':len(frames),
              'transform':{'rotation_radians':0.,'translation':[origin[0]-a+col*(450+gap),origin[1]-b+row*(350+gap)],'mirrored':False}})
    geom=[shape(parts['frame'],p['transform']) for p in frames];right=max(g.bounds[2] for g in geom);top=max(g.bounds[3] for g in geom)
    t={'rotation_radians':math.pi/2,'translation':[0,0],'mirrored':False};g=shape(parts['insert'],t);x0,y0,x1,y1=g.bounds
    assert abs(x1-x0-110)<1e-7 and abs(y1-y0-180)<1e-7
    inserts=[]
    for row in range(11):
        p={'part_id':'insert','sheet_id':'sheet-0','copy_index':row,'transform':copy.deepcopy(t)}
        p['transform']['translation']=[right+gap-x0,origin[1]+row*(180+gap)-y0];inserts.append(p)
    write(OUT/'frame-group.json',frames);write(OUT/'optional-insert-strip.json',inserts)
    # Independent reconstruction from all original vertices and all pair combinations.
    all_shapes=[]
    from shapely.geometry import Polygon
    for p in frames+inserts:
        part=parts[p['part_id']];t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians'])
        assert any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in part['rotations']['degrees'])
        g=Polygon([(x*co-y*si+t['translation'][0],x*si+y*co+t['translation'][1]) for x,y in part['geometry'][0]['outer']]);assert g.is_valid
        x0,y0,x1,y1=g.bounds;assert x0>=m['left']+edge-1e-7 and y0>=m['bottom']+edge-1e-7 and x1<=stock['width']-m['right']-edge+1e-7 and y1<=stock['height']-m['top']-edge+1e-7
        all_shapes.append(g)
    minimum=math.inf;checks=0
    for a,b in combinations(all_shapes,2):
        checks+=1;dist=a.distance(b);minimum=min(minimum,dist);assert a.disjoint(b) and dist>=job['clearance']-1e-7
    check={'passed':True,'prior_groups_checked':26,'all_wide_group_previously_present':False,'frame_count':18,'optional_insert_count':11,
      'pair_checks':checks,'minimum_distance_mm':minimum,'frame_top_mm':top,'frame_right_mm':right,
      'side_strip_width_mm':stock['width']-m['right']-edge-right,'top_free_height_mm':stock['height']-m['top']-edge-top,
      'full_target_witness':False,'native_margin_qualified':False,'small_family_completion_not_run':True,
      'scope':'One verified frame group plus optional insert candidates. It does not improve the62-part partial or establish capacity for all remaining cogs/brackets/inserts.'}
    write(OUT/'checks.json',check);print(check,flush=True)
if __name__=='__main__':main()
