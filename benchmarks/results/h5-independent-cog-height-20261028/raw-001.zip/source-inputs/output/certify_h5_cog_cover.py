"""Find and independently verify a short cover of the fixed-pool cog conflict graph."""
from datetime import datetime, timezone
import gzip, json, shutil, time
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT, load, write, digest

POOL = ROOT / 'output/h5-cog-free-region-contacts-20261020-v2'
RUN = ROOT / 'output/h5-free-region-cog-completion-20261020'
OUT = ROOT / 'output/h5-cog-clique-cover-certificate-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'certify.py')
    sources = [POOL / n for n in ['cliques.jsonl.gz', 'conflicts.jsonl.gz', 'mapping.json', 'audit/checks.json']]
    sources += [RUN / 'audit/checks.json', RUN / 'audit/clique-cover.json']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'seconds_limit': 10, 'workers': 8, 'seed': 0,
        'method': 'Choose a small covering set from the883 independently verified pairwise-conflicting cliques and1045 singleton vertices. Cover every cog candidate at least once. Minimize cover count from the known independent set size9 through the saved greedy bound17, using a complete feasible greedy hint. Reconstruct the full covering model before one bounded solve. Independently verify every returned cover against actual saved conflict edges; a cover of k proves at most k cogs for this finite pool.',
        'scope': 'Certificate search only; no new placement, geometry or original-job acceptance. No assertion about continuous positions or other non-cog arrangements.',
        'native_packing_calls': 0, 'quality_runs': 0})
    with gzip.open(POOL / 'cliques.jsonl.gz', 'rt', encoding='utf-8') as f:
        original = [set(json.loads(line)) for line in f]
    n = len(load(POOL / 'mapping.json')['candidates'])
    groups = original + [{i} for i in range(n)]
    greedy = load(RUN / 'audit/clique-cover.json')
    chosen = set()
    for row in greedy:
        if row['source_clique'] is not None:
            chosen.add(row['source_clique'])
        else:
            assert len(row['local_candidates']) == 1
            chosen.add(len(original) + row['local_candidates'][0])
    assert len(chosen) == len(greedy) == 17
    assert set().union(*(groups[i] for i in chosen)) == set(range(n))
    owners = [[ci for ci, c in enumerate(groups) if i in c] for i in range(n)]
    model = cp_model.CpModel()
    variables = [model.new_bool_var(f'cover{j}') for j in range(len(groups))]
    for cs in owners:
        model.add_linear_constraint(sum(variables[j] for j in cs), 1, len(cs))
    model.add_linear_constraint(sum(variables), 9, 17)
    model.minimize(sum(variables))
    hint = [int(j in chosen) for j in range(len(groups))]
    for j, value in enumerate(hint):
        model.add_hint(variables[j], value)
    assert model.validate() == ''
    model.export_to_file(str(OUT / 'model.pbtxt'))
    expected = cp_model_pb2.CpModelProto()
    for j in range(len(groups)):
        v = expected.variables.add()
        v.name = f'cover{j}'
        v.domain.extend([0, 1])
    for i in range(n):
        cs = [j for j, g in enumerate(groups) if i in g]
        c = expected.constraints.add().linear
        c.vars.extend(cs)
        c.coeffs.extend([1] * len(cs))
        c.domain.extend([1, len(cs)])
    c = expected.constraints.add().linear
    c.vars.extend(range(len(groups)))
    c.coeffs.extend([1] * len(groups))
    c.domain.extend([9, 17])
    expected.objective.vars.extend(range(len(groups)))
    expected.objective.coeffs.extend([1] * len(groups))
    expected.objective.scaling_factor = 1
    expected.solution_hint.vars.extend(range(len(groups)))
    expected.solution_hint.values.extend(hint)
    actual = text_format.Parse((OUT / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
    assert actual.SerializeToString(deterministic=True) == expected.SerializeToString(deterministic=True)
    for c in actual.constraints:
        value = sum(co * hint[j] for j, co in zip(c.linear.vars, c.linear.coeffs))
        assert c.linear.domain[0] <= value <= c.linear.domain[1]
    write(OUT / 'model-audit.json', {
        'all_model_fields_independently_reconstructed': True, 'complete_greedy_hint_feasible': True,
        'variables': len(groups), 'constraints': len(actual.constraints),
        'model_sha256': digest(OUT / 'model.pbtxt')})
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 10
    solver.parameters.num_search_workers = 8
    solver.parameters.random_seed = 0
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = False
    (OUT / 'parameters.pbtxt').write_text(str(solver.parameters), encoding='utf-8', newline='\n')
    records = []
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            ids = [j for j, v in enumerate(variables) if self.value(v)]
            r = {'index': len(records), 'cover_ids': ids, 'cover_size': len(ids),
                 'seconds': self.wall_time, 'objective': self.objective_value,
                 'best_bound': self.best_objective_bound}
            assert len(ids) == r['objective']
            write(OUT / f"incumbent-{r['index']}.json", r)
            records.append(r)
            print(json.dumps({k: v for k, v in r.items() if k != 'cover_ids'}), flush=True)
    write(OUT / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'seconds_limit': 10})
    with (OUT / 'solver.log').open('x', encoding='utf-8', newline='\n') as log:
        solver.log_callback = lambda s: (log.write(s + '\n'), log.flush())
        start = time.perf_counter()
        status = solver.solve(model, Capture())
        seconds = time.perf_counter() - start
    feasible = status in [cp_model.FEASIBLE, cp_model.OPTIMAL]
    result = {'status': solver.status_name(status), 'seconds': seconds, 'incumbents': len(records),
              'feasible': feasible, 'response_stats': solver.response_stats(), 'full_target_witness': False}
    if feasible:
        ids = [j for j, v in enumerate(variables) if solver.value(v)]
        write(OUT / 'selected-cover-ids.json', ids)
        result.update(cover_size=len(ids), best_bound=solver.best_objective_bound)
        if not records or records[-1]['cover_ids'] != ids:
            records.append({'index': 'final', 'cover_ids': ids, 'cover_size': len(ids)})
    else:
        assert not records
    write(OUT / 'result.json', result)
    # Independent graph-edge check of every returned cover; objective optimality is unnecessary.
    adjacency = [set() for _ in range(n)]
    with gzip.open(POOL / 'conflicts.jsonl.gz', 'rt', encoding='utf-8') as f:
        for line in f:
            a, b = json.loads(line)
            adjacency[a].add(b)
            adjacency[b].add(a)
    verified = []
    for r in records:
        selected = r['cover_ids']
        assert len(selected) == len(set(selected)) == r['cover_size']
        covered = set()
        for ci in selected:
            vertices = groups[ci]
            assert all(vertices - {v} <= adjacency[v] for v in vertices)
            covered |= vertices
        assert covered == set(range(n))
        verified.append({'incumbent': r['index'], 'cover_size': len(selected)})
    best = min((r['cover_size'] for r in verified), default=None)
    write(OUT / 'checks.json', {
        'all_returned_covers_checked_against_exact_graph_edges': True, 'covers_verified': verified,
        'independent_cog_upper_bound': best, 'known_physical_cog_lower_bound': 9,
        'finite_pool_optimum_independently_certified': best == 9,
        'original15_ruled_out_for_this_finite_pool': best is not None and best < 15,
        'unrestricted_impossibility_claimed': False, 'full_target_witness': False})
    print(json.dumps({k: v for k, v in result.items() if k != 'response_stats'}), flush=True)
    print((OUT / 'checks.json').read_text(), flush=True)

if __name__ == '__main__':
    main()
