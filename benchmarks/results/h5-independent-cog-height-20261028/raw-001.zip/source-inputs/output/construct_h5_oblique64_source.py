"""Construct an original-source64 layout from the bounded contact scan."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-oblique64-source-20261028'
CORE=ROOT/'output/h5-eight-bracket-short-core-20261026/audit-horizontal-mode-repaired';SCAN=ROOT/'output/h5-cog-oblique-contacts-20261028';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'construct.py');start=time.perf_counter()
inputs=[JOB,CORE/'next-neighborhood.json',CORE/'checks.json',SCAN/'ranked-pairs.json',SCAN/'result.json',ROOT/'output/h5-source-orientation-construction-20261025/items.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
 'method':'One deterministic source construction: use the best complete contact-scan phase pair, five columns and three rows with horizontal neighbor pitchD and alternate row offsetD*cos72/heightD*sin72. Align the full packet right edge to1493.475mm and its bottom to2107.875mm, above the existing independently valid29 first-sheet originals; retain all13 short originals. Add all five remaining horizontal inserts in one centered top row at y2883.475 with0.225mm gaps. Add two top-corner brackets: copy8 unmirrored270degrees and copy9 mirrored90degrees, lower-left anchors(6.525,2693.475) and(1243.475,2693.475). Keep copies10/11 explicitly mandatory and unplaced. Independently read all64 original filled outlines and source holes before any acceptance claim. No optimizer, random restart, source change, relaxed guard or native call.'})
assert load(CORE/'checks.json')['passed'] and load(SCAN/'result.json')['status']=='COMPLETE'
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(CORE/'next-neighborhood.json');best=load(SCAN/'ranked-pairs.json')[0];D=best['neighbor_pitch_mm'];phases=best['phases_degrees'];cx=cy=139.723742
items=load(inputs[-1]);keys={(r['family'],r['copy']):r['index'] for r in items}
def bounds(row):
    t=row['transform'];a=t['rotation_radians'];co,si=math.cos(a),math.sin(a);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    p=[(m*x*co-y*si+tx,m*x*si+y*co+ty) for x,y in parts[row['part_id']]['geometry'][0]['outer']]
    return [min(x for x,y in p),min(y for x,y in p),max(x for x,y in p),max(y for x,y in p)]
packet=[];dx=D*math.cos(math.radians(72));dy=D*math.sin(math.radians(72))
for copy in range(15):
    row,col=divmod(copy,5);a=math.radians(phases[(row+col)%2]);co,si=math.cos(a),math.sin(a);x=col*D+(row%2)*dx;y=row*dy
    packet.append({'part_id':'cog','copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':a,'mirrored':False,'translation':[x-co*cx+si*cy,y-si*cx-co*cy]}})
bb=[bounds(r) for r in packet];extent=[min(b[0] for b in bb),min(b[1] for b in bb),max(b[2] for b in bb),max(b[3] for b in bb)]
shift=[1493.475-extent[2],2107.875-extent[1]]
for r in packet:r['transform']['translation']=[r['transform']['translation'][i]+shift[i] for i in range(2)]
rows=spec['fixed_first_placements']+spec['fixed_short_placements']+packet
for i,copy in enumerate(range(16,21)):
    rows.append({'part_id':'insert','copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':0.,'mirrored':False,'translation':[(1500-(5*180+4*.225))/2+i*(180+.225),2883.475]}})
for copy,a,mirror,anchor in [(8,3*math.pi/2,False,[6.525,2693.475]),(9,math.pi/2,True,[1243.475,2693.475])]:
    row={'part_id':'bracket','copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':a,'mirrored':mirror,'translation':[0.,0.]}}
    b=bounds(row);row['transform']['translation']=[anchor[0]-b[0],anchor[1]-b[1]];rows.append(row)
identities=[(r['part_id'],r['copy_index']) for r in rows];assert len(rows)==len(set(identities))==64
missing=[r for r in items if (r['family'],r['copy']) not in identities];assert [(r['family'],r['copy']) for r in missing]==[('bracket',10),('bracket',11)]
rows.sort(key=lambda r:keys[r['part_id'],r['copy_index']]);write(OUT/'source64.json',rows);write(OUT/'mandatory-two-brackets.json',missing)
write(OUT/'fixed49-noncogs.json',[r for r in rows if r['part_id']!='cog']);write(OUT/'moving17.json',[{'family':'cog','copy_index':r['copy_index'],'prior_source_placement':r} for r in packet]+[{'family':'bracket','copy_index':r['copy']} for r in missing])
bb=[bounds(r) for r in packet];extent=[min(b[0] for b in bb),min(b[1] for b in bb),max(b[2] for b in bb),max(b[3] for b in bb)]
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'phase_pair_degrees':phases,'neighbor_pitch_mm':D,'row_offset_mm':dx,'row_height_mm':dy,
 'source_cog_packet_bounds_mm':extent,'source_cog_packet_width_mm':extent[2]-extent[0],'source_cog_packet_height_mm':extent[3]-extent[1],
 'originals_placed':64,'mandatory_unplaced_brackets':2,'full_original_ring_readback_pending':True,'optimizer_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
