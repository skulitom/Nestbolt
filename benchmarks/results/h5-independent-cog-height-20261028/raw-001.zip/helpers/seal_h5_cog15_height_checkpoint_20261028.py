"""Seal the independent cog-height call with actual source height/width tradeoff."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-cog15-height-20261028';PUB=BASE/'publication';NAME='h5-independent-cog-height-20261028';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='05a7232c02bbd73ecf5380e699e7b92a26cecdd8' and not git('diff','HEAD','--name-only')
geo=load(BASE/'geometry-audit/checks.json');model=load(BASE/'model-audit/checks.json');response=load(BASE/'response-audit/checks.json');source=load(BASE/'source-audit/checks.json')
assert all(r['passed'] for r in [geo,model,response,source]);assert response['status']=='FEASIBLE' and response['incumbents_verified']==5 and source['height_reduction_from_control_mm']<.247
prior=load(ROOT/'benchmarks/results/h5-mixed-core-height-and-section-bounds-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest']
readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==prior[k] for k in up);main=load(PUB/'main.json')['commit']['sha'];assert main=='2adfa5699201a537ad04d5f58e772e27bae7aefe'
jobs=load(PUB/'main-ci-jobs.json')['jobs'];passed=[r['name'] for r in jobs if r['status']=='completed' and r['conclusion']=='success'];live=[r['name'] for r in jobs if r['status']!='completed']
assert len(jobs)==6 and len(passed)==5 and live==['checks (windows-latest)']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-mixed26-pending-main-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_cog15_height_20261028.py','audit_h5_cog15_height_geometry_20261028.py','build_h5_cog15_height_model_20261028.py',
    'audit_h5_cog15_height_model_20261028.py','run_h5_cog15_height_model_20261028.py','audit_h5_cog15_height_response_20261028.py','audit_h5_cog15_height_source_20261028.py',
    'pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for a,b in [('geometry-audit/checks.json','source-geometry-audit.json'),('geometry-audit/necessity-proof.json','source-capacity-proof.json'),('model-audit/checks.json','model-audit.json'),
    ('response-audit/checks.json','response-audit.json'),('source-audit/checks.json','source-audit.json'),('source-audit/incumbents.json','source-incumbents.json'),
    ('response-audit/source15.json','source15.json'),('publication/main-ci-jobs.json','prior-main-ci.json')]:shutil.copyfile(BASE/a,OUT/b)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'queued_verified_commit':head,'production_digest':production,'current_readmes':readmes,**up,
    'upstream_heads_and_releases_unchanged':True,'main_CI':40735870933,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_check':True,
    'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'independent_audits':4,'solver_status':'FEASIBLE','search_closed':True,'solver_calls':1,'all_five_incumbents_source_valid':True,
    'actual_packet_height_mm':source['actual_packet_height_mm'],'actual_packet_width_mm':source['actual_packet_width_mm'],'height_gain_from_old_source64_mm':source['height_reduction_from_old_source64_mm'],
    'width_cost_from_old_source64_mm':source['width_increase_from_old_source64_mm'],'material_gate_solved':False,'previous_source64_preserved':True,'remaining_necessary_allocations':444,'full66_witness':False,
    'actual_or_global_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='The independent15-cog phase7 height call is CLOSED FEASIBLE after one60-second optimization. All5 incumbents and final source15 pass; actual packet height772.202399mm improves the guarded control by0.246mm, but versus old source64 improves only0.126980mm while widening by41.066861mm to1436.447399mm. The0.258mm model-top decrease includes12um translation and must not be reported as physical compression. Preserve0.0577129s returned soft overrun, no optimality/free-angle/global claim. Do not repeat or extend this fixed-angle call or transplant its packet into source64 without full neighbour validation. Next investigate a materially different continuous-angle source formulation: all15 cog angles, centers and packet top independently movable, starting from the newly source-valid packet. The actual job allows free rotations; an initial0..18degree angle window is a constructive subset only, not an exact symmetry or global coverage claim for rounded source vertices. Recompute polygons directly from all original80-vertex outer rings at each angle; phase7 no-fit polygons/cells and fixed contained rectangles cannot be transferred to changing angles. Inspect/audit the new objective and pair/stock/top constraints, scale numerical variables explicitly, and preserve a complete feasible positive control before predeclaring one bounded nonlinear call with a finite iteration/evaluation budget and hard shared deadline. Keep every returned result and best genuinely source-valid incumbent; a failed local solve must not trigger restarts or imply impossibility. Independently read all original source pairs, stock edges, rotations and holes before accepting a packet. The other51 original non-cogs remain required, and any packet must be combined into all66 and pass source/native/material checks before integration/full H5. Preserve the old valid64, all444 necessary counts, H2 original gate and22 unopened vectors. Local05a7232c and this checkpoint wait for Windows in main CI40735870933 (five jobs passed) before normal push after fresh refs/live-run guards. No release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Independent cog-height optimization — 2026-10-28

The source-valid cog packet becomes only **0.126980 mm shorter** than the packet
in the earlier source64 layout, while becoming **41.066861 mm wider**. This does
not solve the material requirement. The sole fixed-angle call is closed and
not a proven optimum. H2/H5 remain open at **60% completed milestone weight**.

This model differs from the closed triangular phase table, oblique construction
and finite-pool cover: every one of the 15 cog positions is independent within
the full usable stock width, and the objective is the maximum source top.
There is no fixed lattice, pitch, row count or cog position. The angle remains
the audited 7° constructive subset; no free-angle coverage is claimed.

The complete guarded control uses 258.90 mm horizontal pitch, 80 mm alternate
offset and 246.25 mm row pitch. It passes all **105 original source pairs, 60
stock edges, 15 holes / 3,000 hole vertices**, and every occupied pair cell.
Its actual height is 772.448399 mm. This avoids treating the older source-valid
but less conservative clearance as a valid rounded hint for the no-fit model.

The independent geometry audit checks 6,084 source Minkowski hulls, 124 convex
relative cells, 430 conservative integer halfplanes and 92 source-contained
rectangles, with 7,360 exact source-edge and 4,186 same-owner rectangle checks.
Stock domains and the exact source-area lower bound are reconstructed. Necessary
X/Y capacities use 1,380 contained components and add no bounding-box exclusion.

The serialized model audit checks **13,051 variables, 48,046 constraints, 30
independent coordinates, all 105 source pairs, 13,020 cell choices and every
value of the complete feasible hint**. Its top objective is explicitly audited.
The sole 60-second, four-worker call returns **FEASIBLE**, with five incumbents.
Solver time is 60.049336 s, returned time 60.057713 s and shared time 61.047461 s.
The returned soft overrun of **0.057713 s** is preserved. The top objective is
778.717 mm and solver bound 511.526 mm, so no optimum is established. Zero
returned branch/conflict counters do not establish that the worker portfolio
performed no search.

Every incumbent and the final assignment pass the independent saved-model reader.
Every incumbent also passes original-source geometry, stock, angle and hole
readback. Final minimum source gap is **0.224621810 mm** and extra stock clearance
**0.013800281 mm**. The final actual bounds are approximately
(6.513800, 6.513800)–(1,442.961200, 778.716200) mm.

| Source packet | Actual width | Actual height |
| --- | ---: | ---: |
| Earlier valid64 cog packet | 1,395.380539 mm | 772.329379 mm |
| Guarded positive control | 1,395.548399 mm | 772.448399 mm |
| New independently positioned packet | 1,436.447399 mm | 772.202399 mm |

The model top decreases by 0.258 mm, but 0.012 mm comes from translation toward
the stock edge. Actual height decreases only **0.246 mm** from the guarded
control. Relative to the earlier valid64, the 0.126980 mm height gain costs
41.066861 mm of width. The packet is not transplanted into that layout; doing so
would require checking every other original neighbour. All 51 non-cog originals
remain obligations, and no native, full66 or H5 result is claimed.

The next investigation changes the angle variables as well as positions. It must
construct polygons directly from original source vertices for every changed
angle; the fixed-angle no-fit cells and contained rectangles cannot simply be
reused. Start from the newly valid source packet, audit the objective and all
pair/stock/top constraints, scale numerical variables explicitly, and declare a
single bounded nonlinear call only after the positive control passes. A failed
local solve will not justify restarts or an impossibility claim. Any useful
packet still needs all complementary originals and full source/native/material
validation before integration or the H5 matrix.

Main remains **2adfa569**. At this review CI 40735870933 has five passing jobs;
Windows checks remain live. The verified mixed-core commit **05a7232c** and this
checkpoint wait for all six jobs and fresh remote guards before a normal push.
Production and all READMEs are unchanged. Sparrow remains 6f7b9d35 / v0.3.0;
Studio remains c0bb9e86 without a release. No stop rule fires. The previous
valid64, 444-count frontier, original H2 gate and all 22 unopened reserved vectors
remain preserved. No release qualifies.

Evidence: [source geometry]({NAME}/source-geometry-audit.json),
[complete model]({NAME}/model-audit.json),
[response]({NAME}/response-audit.json),
[source extents and tradeoff]({NAME}/source-audit.json),
[every source incumbent]({NAME}/source-incumbents.json),
[next step]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The archive contains {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including all models, incumbent assignments, source readbacks,
inputs and closed-call records.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 independent cog-height result, 2026-10-28:** [the evidence]({link}) audits
all 15 independent cog positions, 13,051 variables, 48,046 constraints and the
complete positive control. The sole phase7 height call is CLOSED FEASIBLE;
all five incumbents pass original-source checks. Actual height is 772.202399 mm,
only 0.126980 mm shorter than the old valid64 cog packet, while width increases
by 41.066861 mm. The 0.258 mm model-top change includes 0.012 mm translation;
physical compression from the guarded control is 0.246 mm. Preserve the
0.057713 s returned soft overrun; no optimum or full66 claim follows. Next add
independent cog angles in a new direct-source formulation, with audited positive
control and one declared bounded call; never reuse phase7 obstacles at changed
angles. The other 51 originals remain required. Best valid64, 444 necessary
counts, H2 gate and 22 unopened reserved vectors stay unchanged. Main 2adfa569
has five passing jobs and Windows live; queued commits wait for all six before
normal push. Production/READMEs and upstream releases are unchanged. H2/H5
remain open at 60%; no release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
