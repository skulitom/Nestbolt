"""Original-ring checks for every saved cog incumbent and actual packet extents."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog15-height-20261028';OUT=BASE/'source-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();response=load(BASE/'response-audit/checks.json');assert response['passed'] and response['has_source_cog_candidate']
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='cog');mp=load(BASE/'model/mapping.json');mode=load(BASE/'mode.json')
expected={('cog',i) for i in range(15)};stocks={'sheet-0':[6.5,6.5,1493.5,2993.5]}
def rows_from(sol):
    return [{'part_id':'cog','copy_index':r['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['angle'],'mirrored':False,
        'translation':[sol[r['x']]/1000+mode['source_translation_offset'][0],sol[r['y']]/1000+mode['source_translation_offset'][1]]}} for r in mp['items']]
def extent(rows):
    points=[]
    for r in rows:
        t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);assert not t['mirrored']
        points.extend([(x*c-y*s+t['translation'][0],x*s+y*c+t['translation'][1]) for x,y in part['geometry'][0]['outer']])
    return [min(x for x,y in points),min(y for x,y in points),max(x for x,y in points),max(y for x,y in points)]
records=[]
for p in sorted((BASE/'search/incumbents').glob('*.json')):
    saved=load(p);rows=rows_from(saved['values']);source=audit(job,rows,stocks,.21170867250963943,.011444091796875,expected);assert source['valid'];bb=extent(rows)
    assert bb[3]<=saved['top_um']/1000 and saved['top_um']/1000-bb[3]<.001
    records.append({'sequence':saved['sequence'],'source_valid':True,'model_top_mm':saved['top_um']/1000,'actual_bounds_mm':bb,'actual_height_mm':bb[3]-bb[1],'actual_width_mm':bb[2]-bb[0],
        **{k:source[k] for k in ['same_sheet_pairs','stock_edges','cutouts','hole_vertices','minimum_pair_gap_mm','minimum_extra_stock_mm']}})
rows=rows_from(load(BASE/'search/assignment.json'));assert rows==load(BASE/'response-audit/source15.json');source=audit(job,rows,stocks,.21170867250963943,.011444091796875,expected);assert source['valid'];bb=extent(rows)
control=extent(load(BASE/'control-source15.json'));old=extent([r for r in load(ROOT/'output/h5-oblique64-source-20261028/source64.json') if r['part_id']=='cog'])
height=bb[3]-bb[1];width=bb[2]-bb[0];assert abs(height-records[-1]['actual_height_mm'])<1e-9
write(OUT/'source-readback.json',source);write(OUT/'incumbents.json',records)
inputs=[BASE/'plan.json',BASE/'model/mapping.json',BASE/'mode.json',BASE/'control-source15.json',BASE/'response-audit/checks.json',BASE/'response-audit/source15.json',BASE/'search/assignment.json',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5-oblique64-source-20261028/source64.json']+sorted((BASE/'search/incumbents').glob('*.json'))
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_incumbents_verified':len(records),'source_final_verified':True,'source_originals':15,'source_pairs_verified':105,'source_stock_edges':60,'source_holes':source['cutouts'],'source_hole_vertices':source['hole_vertices'],
    'actual_bounds_mm':bb,'actual_packet_height_mm':height,'actual_packet_width_mm':width,'control_packet_height_mm':control[3]-control[1],'height_reduction_from_control_mm':control[3]-control[1]-height,
    'old_source64_cog_height_mm':old[3]-old[1],'height_reduction_from_old_source64_mm':old[3]-old[1]-height,'old_source64_cog_width_mm':old[2]-old[0],'width_increase_from_old_source64_mm':width-(old[2]-old[0]),
    'model_top_reduction_mm':response['top_improvement_mm'],'model_rounding_and_translation_not_counted_as_height_gain':True,
    'minimum_source_pair_gap_mm':source['minimum_pair_gap_mm'],'minimum_extra_stock_mm':source['minimum_extra_stock_mm'],'noncog_originals_still_unplaced':51,
    'previous_source64_preserved':True,'full66_witness':False,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
