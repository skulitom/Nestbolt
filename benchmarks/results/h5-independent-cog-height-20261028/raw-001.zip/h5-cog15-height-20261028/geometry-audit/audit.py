"""Independent source obstacle/cell/rectangle and positive-control checks."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,shutil,time
import shapely
from shapely.geometry import Polygon,MultiPoint,shape,box
from shapely.ops import unary_union
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog15-height-20261028';OUT=BASE/'geometry-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(p for p in job['parts'] if p['id']=='cog');m=load(BASE/'mode.json');assert m==load(ROOT/'output/h5-free23-source-regions-20261028/modes.json')[0]
c,s=math.cos(m['angle']),math.sin(m['angle']);assert m['angle']==math.radians(7) and not m['mirrored'] and part['rotations']['kind']=='free'
g=Polygon([(x*c-y*s+m['source_translation_offset'][0],x*s+y*c+m['source_translation_offset'][1]) for x,y in part['geometry'][0]['outer']]);assert g.is_valid and g.equals_exact(shape(m['geometry']),1e-10)
triangles=list(shapely.constrained_delaunay_triangles(g).geoms);assert unary_union(triangles).equals(g) and all(t.equals(t.convex_hull) for t in triangles)
sums=[MultiPoint([(x-u,y-v) for x,y in list(a.exterior.coords)[:-1] for u,v in list(b.exterior.coords)[:-1]]).convex_hull for a in triangles for b in triangles]
required=unary_union(sums).buffer(.21170867250963943/math.cos(math.pi/64)+1e-7,quad_segs=16)
obstacle=shape(load(ROOT/'output/h5-oblique24-source-20261028/obstacles/00-00.json'));assert obstacle.covers(required)
data=load(BASE/'relative-cells.json');polys=[];planes=0
assert digest(BASE/'relative-cells.json')==digest(ROOT/'output/h5-free23-source-regions-20261028/relative/00-00.json')
for cell in data['cells']:
    poly=shape(cell['geometry']);assert poly.is_valid and not poly.interiors and poly.equals(poly.convex_hull);polys.append(poly)
    v=[tuple(F(str(x)) for x in p) for p in list(poly.exterior.coords)[:-1]];assert len(v)==len(cell['halfplanes'])
    assert sum(x*b-y*a for (x,y),(a,b) in zip(v,v[1:]+v[:1]))>0
    for (u,w),(aa,bb,cc) in zip(zip(v,v[1:]+v[:1]),cell['halfplanes']):
        nx,ny=u[1]-w[1],w[0]-u[0];norm=max(abs(nx),abs(ny));nx/=norm;ny/=norm
        assert all(nx*(p[0]-u[0])+ny*(p[1]-u[1])>=0 for p in v)
        assert aa==round(nx*10**9) and bb==round(ny*10**9)
        target=(nx*u[0]+ny*u[1])*10**12;error=abs(aa-nx*10**9)*1600000+abs(bb-ny*10**9)*3100000
        assert F(cc)>target+error and F(cc-1)<=target+error+1;planes+=1
assert unary_union(polys).equals(shape(data['domain_geometry'])) and shape(data['domain_geometry']).equals(box(-1600,-3100,1600,3100).difference(obstacle))
rects=load(BASE/'source-rectangles.json');assert rects==load(ROOT/'output/h5-free23-capacity-20261028/mode-rectangles.json')[0];vertices=[tuple(F(str(z)) for z in p) for p in list(g.exterior.coords)[:-1]]
def inside(pt):
    x,y=pt;answer=False
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        if (a[1]>y)!=(b[1]>y) and x<a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]):answer=not answer
    return answer
def hits(a,b,r):
    lo,hi=F(0),F(1)
    for k in [0,1]:
        d=b[k]-a[k]
        if d==0:
            if not r[k]<=a[k]<=r[k+2]:return False
        else:
            x,y=sorted([(r[k]-a[k])/d,(r[k+2]-a[k])/d]);lo=max(lo,x);hi=min(hi,y)
            if lo>hi:return False
    return True
edge_checks=0
for rr in rects['rectangles_um']:
    r=[F(v,1000) for v in rr];assert inside(r[:2])
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):assert not hits(a,b,r);edge_checks+=1
for a,b in combinations(rects['rectangles_um'],2):assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
stock=load(BASE/'stock.json');bb=[F(str(v))*1000 for v in g.bounds];ceil=lambda v:-((-v.numerator)//v.denominator)
assert stock['source_bounds_mm']==list(g.bounds) and stock['x_anchor_min_um']==ceil(6513-bb[0]) and stock['x_anchor_max_um']==(1493487-bb[2])//1
assert stock['y_anchor_min_um']==ceil(6513-bb[1]) and stock['source_upper_y_offset_um']==ceil(bb[3])
v=[tuple(F(str(x)) for x in p) for p in part['geometry'][0]['outer']];area=abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(v,v[1:]+v[:1])))/2
assert F(*stock['source_area_mm2'])==area and stock['area_lower_top_um']==ceil(15*area*1000000/F(1486974)+6513)
control=load(BASE/'control.json');rows=load(BASE/'control-source15.json');assert len(control)==len(rows)==15 and [r['anchor_um'] for r in control]==sorted(r['anchor_um'] for r in control)
for i,(r,row) in enumerate(zip(control,rows)):
    assert r['copy_index']==row['copy_index']==i and row['part_id']=='cog';x,y=r['anchor_um'];assert stock['x_anchor_min_um']<=x<=stock['x_anchor_max_um'] and stock['y_anchor_min_um']<=y and y+stock['source_upper_y_offset_um']<=stock['initial_top_um']
    assert row['transform']=={'rotation_radians':m['angle'],'mirrored':False,'translation':[r['anchor_um'][k]/1000+m['source_translation_offset'][k] for k in [0,1]]}
source=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5]},.21170867250963943,.011444091796875,{('cog',i) for i in range(15)});assert source['valid'] and source==load(BASE/'control-source-readback.json')
for saved,(a,b) in zip(load(BASE/'control-pair-cells.json'),combinations(control,2)):
    assert [saved['left'],saved['right']]==[a['copy_index'],b['copy_index']];dx,dy=[b['anchor_um'][k]-a['anchor_um'][k] for k in [0,1]];cell=data['cells'][saved['cell']]
    assert all(a*dx+b*dy>=c for a,b,c in cell['halfplanes'])
components=[[a+r['anchor_um'][0],b+r['anchor_um'][1],c+r['anchor_um'][0],d+r['anchor_um'][1]] for r in control for a,b,c,d in rects['rectangles_um']];sweeps=[]
for axis,capacity in [(0,stock['initial_top_um']-6500),(1,1487000)]:
    events={}
    for r in components:
        a,b=r[axis],r[axis+2];d=r[3-axis]-r[1-axis];events[a]=events.get(a,0)+d;events[b]=events.get(b,0)-d
    total=maximum=0
    for where,delta in sorted(events.items()):total+=delta;maximum=max(maximum,total);assert 0<=total<=capacity
    assert total==0;sweeps.append({'axis':axis,'maximum':maximum,'capacity':capacity,'slack':capacity-maximum})
write(OUT/'control-capacities.json',sweeps)
write(OUT/'necessity-proof.json',{'statement':'The92 contained source rectangles have disjoint interiors within each cog. In any valid source arrangement rectangles from different cogs also have disjoint interiors. At a horizontal section their total widths fit1487000um; at a vertical section their heights fit the interval6500um..top. These two cumulative bounds are necessary for any valid source arrangement with the modeled top. The area bound uses the exact original filled area and the more restrictive guarded model width1486974um. Pair-cell halfplanes conservatively imply the original source clearance within their audited coordinate range. The phase7 and micrometre choices are constructive restrictions, not actual/free-angle exclusions.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_vertices':len(vertices),'source_convex_triangles':len(triangles),'independent_minkowski_hulls':len(sums),'relative_cells':len(polys),'integer_halfplanes':planes,
    'source_contained_rectangles':len(rects['rectangles_um']),'exact_source_edge_checks':edge_checks,'same_owner_rectangle_pairs':92*91//2,'positive_control_originals':15,'positive_control_source_pairs':105,'positive_control_stock_edges':60,'positive_control_holes':source['cutouts'],'positive_control_hole_vertices':source['hole_vertices'],
    'positive_control_capacity_components':len(components),'stock_and_area_lower_bound_verified':True,'geometry_sha256':digest(BASE/'mode.json'),'cells_sha256':digest(BASE/'relative-cells.json'),'rectangles_sha256':digest(BASE/'source-rectangles.json'),'stock_sha256':digest(BASE/'stock.json'),'control_sha256':digest(BASE/'control.json'),'plan_sha256':digest(BASE/'plan.json'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
