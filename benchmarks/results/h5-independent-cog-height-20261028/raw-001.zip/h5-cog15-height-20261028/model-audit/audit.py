"""Read every saved model field and evaluate the complete positive control."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog15-height-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();ga=load(BASE/'geometry-audit/checks.json');assert ga['passed']
for path in [BASE/'plan.json',MODEL/'plan.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h
stock=load(BASE/'stock.json');control=load(BASE/'control.json');cells=load(BASE/'relative-cells.json')['cells'];rects=load(BASE/'source-rectangles.json')['rectangles_um'];mp=load(MODEL/'mapping.json');built=load(MODEL/'built.json')
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());assert {f.name for f,v in p.ListFields()}=={'variables','constraints','objective','solution_hint'}
assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256']
usedvars=set();usedcts=set();LOW=-9223372036854775808;HIGH=9223372036854775807
def var(ix,name,domain):
    assert ix not in usedvars;usedvars.add(ix);v=p.variables[ix];assert {f.name for f,z in v.ListFields()}=={'name','domain'} and v.name==name and list(v.domain)==domain
def ct(ix,kind,on=(),name=''):
    assert ix not in usedcts;usedcts.add(ix);c=p.constraints[ix];assert c.WhichOneof('constraint')==kind and {f.name for f,z in c.ListFields()}<= {'name','enforcement_literal',kind}
    assert c.name==name and list(c.enforcement_literal)==list(on);return c
def linear(ix,co,lo=LOW,hi=HIGH,on=()):
    e=ct(ix,'linear',on).linear;co={k:v for k,v in co.items() if v};assert {f.name for f,z in e.ListFields()}<= {'vars','coeffs','domain'}
    assert len(e.vars)==len(set(e.vars)) and dict(zip(e.vars,e.coeffs))==co and list(e.domain)==[lo,hi]
def expr(e,variable,offset):
    assert {f.name for f,z in e.ListFields()}<= {'vars','coeffs','offset'} and e.offset==offset
    assert list(e.vars)==([] if variable is None else [variable]) and list(e.coeffs)==([] if variable is None else [1])
top=mp['top_variable'];var(top,'source_top_um',[stock['area_lower_top_um'],stock['initial_top_um']]);hints={top:stock['initial_top_um']};assert len(mp['items'])==15
for i,(item,r) in enumerate(zip(mp['items'],control)):
    assert item['index']==item['copy_index']==r['copy_index']==i
    var(item['x'],f'x_{i}',[stock['x_anchor_min_um'],stock['x_anchor_max_um']]);var(item['y'],f'y_{i}',[stock['y_anchor_min_um'],stock['initial_top_um']-stock['source_upper_y_offset_um']])
    linear(item['top_constraint'],{item['y']:1,top:-1},hi=-stock['source_upper_y_offset_um']);hints[item['x']],hints[item['y']]=r['anchor_um']
assert len(mp['pairs'])==105
for pair,(a,b) in zip(mp['pairs'],combinations(mp['items'],2)):
    i,j=a['index'],b['index'];assert [pair['left'],pair['right']]==[i,j] and len(pair['cells'])==len(pair['plane_constraints'])==len(cells)==124
    e=ct(pair['choice'],'exactly_one').exactly_one;assert {f.name for f,z in e.ListFields()}=={'literals'} and list(e.literals)==pair['cells']
    dx,dy=[control[j]['anchor_um'][k]-control[i]['anchor_um'][k] for k in [0,1]];selected=next(k for k,c in enumerate(cells) if all(aa*dx+bb*dy>=cc for aa,bb,cc in c['halfplanes']))
    for k,(ix,cell,planes) in enumerate(zip(pair['cells'],cells,pair['plane_constraints'])):
        var(ix,f'pair_{i}_{j}_{k}',[0,1]);hints[ix]=int(k==selected);assert len(planes)==len(cell['halfplanes'])
        for constraint,(aa,bb,cc) in zip(planes,cell['halfplanes']):linear(constraint,{a['x']:-aa,b['x']:aa,a['y']:-bb,b['y']:bb},lo=cc,on=[ix])
assert len(mp['orders'])==14
for order,(a,b) in zip(mp['orders'],zip(mp['items'],mp['items'][1:])):
    assert [order['left'],order['right']]==[a['index'],b['index']];linear(order['constraint'],{a['x']:1,b['x']:-1},hi=0)
xs=[];ys=[];widths=[];heights=[];index=0
for item in mp['items']:
    for k,(a,b,c,d) in enumerate(rects):
        r=mp['components'][index];assert r['item']==item['index'] and r['rectangle']==k;index+=1
        for axis,start,end in [('x',a,c),('y',b,d)]:
            e=ct(r[axis+'_interval'],'interval',name=f'capacity_{axis}_{item["index"]}_{k}').interval;assert {f.name for f,z in e.ListFields()}=={'start','size','end'}
            expr(e.start,item[axis],start);expr(e.end,item[axis],end);expr(e.size,None,end-start)
        xs.append(r['x_interval']);ys.append(r['y_interval']);widths.append(c-a);heights.append(d-b)
assert index==len(mp['components'])==1380
for key,intervals,demands,variable,offset in [('x_cumulative',xs,heights,top,-6500),('y_cumulative',ys,widths,None,1487000)]:
    e=ct(mp[key],'cumulative').cumulative;assert {f.name for f,z in e.ListFields()}=={'intervals','demands','capacity'} and list(e.intervals)==intervals and len(e.demands)==len(demands)
    expr(e.capacity,variable,offset)
    for d,amount in zip(e.demands,demands):expr(d,None,amount)
assert usedvars==set(range(len(p.variables))) and usedcts==set(range(len(p.constraints)))
assert {f.name for f,z in p.objective.ListFields()}=={'vars','coeffs','scaling_factor'} and list(p.objective.vars)==[top] and list(p.objective.coeffs)==[1] and p.objective.offset==0 and p.objective.scaling_factor==1
assert {f.name for f,z in p.solution_hint.ListFields()}=={'vars','values'} and len(p.solution_hint.vars)==len(set(p.solution_hint.vars))==len(p.variables)
assert dict(zip(p.solution_hint.vars,p.solution_hint.values))==hints=={int(k):v for k,v in load(MODEL/'control-assignment.json').items()}
checked=evaluate(p,[hints[i] for i in range(len(p.variables))],stock['initial_top_um']);assert checked['variables']==13051 and checked['constraints']==48046
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'variables_verified':len(usedvars),'constraints_verified':len(usedcts),'mandatory_cogs':15,'independent_coordinates':30,
    'source_pairs':105,'relative_cell_options':13020,'capacity_components':1380,'full_control_values_verified':len(hints),'full_control_constraints_evaluated':checked['constraints'],'full_control_inactive_constraints':checked['inactive'],
    'objective_is_minimum_source_top':True,'no_lattice_fixed_original_or_unaccounted_constraint':True,'constructive_phase7_subset_only':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'plan_sha256':digest(BASE/'plan.json'),
    'full66_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
