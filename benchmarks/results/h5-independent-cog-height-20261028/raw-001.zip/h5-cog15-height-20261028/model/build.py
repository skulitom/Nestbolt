"""Independent cog coordinates with a source-top objective and complete hint."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog15-height-20261028';OUT=BASE/'model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter();ga=load(BASE/'geometry-audit/checks.json');assert ga['passed']
for n,k in [('mode.json','geometry_sha256'),('relative-cells.json','cells_sha256'),('source-rectangles.json','rectangles_sha256'),('stock.json','stock_sha256'),('control.json','control_sha256'),('plan.json','plan_sha256')]:assert digest(BASE/n)==ga[k]
inputs=[BASE/n for n in ['plan.json','mode.json','relative-cells.json','source-rectangles.json','stock.json','control.json','control-pair-cells.json','geometry-audit/checks.json','geometry-audit/necessity-proof.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
stock=load(BASE/'stock.json');control=load(BASE/'control.json');cells=load(BASE/'relative-cells.json')['cells'];rects=load(BASE/'source-rectangles.json')['rectangles_um'];model=cp_model.CpModel()
top=model.new_int_var(stock['area_lower_top_um'],stock['initial_top_um'],'source_top_um');hints={top.index:stock['initial_top_um']};items=[]
for i,r in enumerate(control):
    assert r['copy_index']==i;x=model.new_int_var(stock['x_anchor_min_um'],stock['x_anchor_max_um'],f'x_{i}');y=model.new_int_var(stock['y_anchor_min_um'],stock['initial_top_um']-stock['source_upper_y_offset_um'],f'y_{i}')
    ct=model.add(y+stock['source_upper_y_offset_um']<=top);items.append({'index':i,'copy_index':i,'x':x.index,'y':y.index,'top_constraint':ct.index});hints[x.index],hints[y.index]=r['anchor_um']
control_pairs={(r['left'],r['right']):r['cell'] for r in load(BASE/'control-pair-cells.json')};pairs=[]
for a,b in combinations(items,2):
    i,j=a['index'],b['index'];dx=model.get_int_var_from_proto_index(b['x'])-model.get_int_var_from_proto_index(a['x']);dy=model.get_int_var_from_proto_index(b['y'])-model.get_int_var_from_proto_index(a['y'])
    ss=[model.new_bool_var(f'pair_{i}_{j}_{k}') for k in range(len(cells))];one=model.add_exactly_one(ss);planes=[]
    for k,(sv,cell) in enumerate(zip(ss,cells)):
        rr=[]
        for aa,bb,cc in cell['halfplanes']:
            ct=model.add(aa*dx+bb*dy>=cc);ct.only_enforce_if(sv);rr.append(ct.index)
        planes.append(rr);hints[sv.index]=int(k==control_pairs[i,j])
    pairs.append({'left':i,'right':j,'cells':[s.index for s in ss],'choice':one.index,'plane_constraints':planes})
orders=[]
for a,b in zip(items,items[1:]):
    ct=model.add(model.get_int_var_from_proto_index(a['x'])<=model.get_int_var_from_proto_index(b['x']));orders.append({'left':a['index'],'right':b['index'],'constraint':ct.index})
components=[];xis=[];yis=[];widths=[];heights=[]
for item in items:
    x=model.get_int_var_from_proto_index(item['x']);y=model.get_int_var_from_proto_index(item['y'])
    for k,(a,b,c,d) in enumerate(rects):
        ix=model.new_fixed_size_interval_var(x+a,c-a,f'capacity_x_{item["index"]}_{k}');iy=model.new_fixed_size_interval_var(y+b,d-b,f'capacity_y_{item["index"]}_{k}')
        xis.append(ix);yis.append(iy);widths.append(c-a);heights.append(d-b);components.append({'item':item['index'],'rectangle':k,'x_interval':ix.index,'y_interval':iy.index})
xc=model.add_cumulative(xis,heights,top-6500);yc=model.add_cumulative(yis,widths,1487000);model.minimize(top)
for ix,v in sorted(hints.items()):model.add_hint(model.get_int_var_from_proto_index(ix),v)
assert model.validate()=='' and len(hints)==len(model.proto.variables);assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
write(OUT/'mapping.json',{'top_variable':top.index,'items':items,'pairs':pairs,'orders':orders,'components':components,'x_cumulative':xc.index,'y_cumulative':yc.index})
write(OUT/'control-assignment.json',{str(k):v for k,v in sorted(hints.items())})
write(OUT/'built.json',{'seconds':time.perf_counter()-started,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'mandatory_cogs':15,'independent_coordinates':30,'pairs':len(pairs),
    'relative_cell_options':sum(len(r['cells']) for r in pairs),'contained_capacity_components':len(components),'all_variables_hinted':True,'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),
    'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'built.json'))
