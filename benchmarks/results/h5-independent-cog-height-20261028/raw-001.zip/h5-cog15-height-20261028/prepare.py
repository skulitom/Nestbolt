"""Prepare an independent-position cog height objective and complete control."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon,shape
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-cog15-height-20261028';OLD=ROOT/'output/h5-free23-source-regions-20261028';CAP=ROOT/'output/h5-free23-capacity-20261028'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');started=time.perf_counter()
inputs=[JOB,OLD/'modes.json',OLD/'relative/00-00.json',OLD/'audit/checks.json',ROOT/'output/h5-oblique24-source-20261028/obstacles/00-00.json',
    CAP/'mode-rectangles.json',CAP/'geometry-audit-corrected/checks.json',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/construct_h5_oblique64_source.py',
    ROOT/'output/build_h5_triangular_phase_model_20261028.py',ROOT/'output/certify_h5_cog_cover.py',ROOT/'benchmarks/results/h5-mixed-core-height-and-section-bounds-20261028/next-step.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'New cog-packet height optimization informed by the exact mixed-core height bounds. Existing triangular work fixes a5x3 equilateral lattice and minimizes common pitch over phases; the oblique source64 construction fixes72degree row geometry, and the older clique cover concerns only a finite pose pool. This model instead independently positions every one of15 mandatory source cogs on1um X/Y coordinates within the full original usable width, initially retaining the audited phase7 constructive subset, and minimizes maximum source top. There are no other fixed parts and no fixed lattice, pitch, row count or initial coordinates. All105 pairs use the audited intrinsic source displacement cells; source-contained cog rectangles supply necessary X/Y cumulative capacities. Non-cogs remain explicit obligations before full66 acceptance. A new complete positive control uses horizontal pitch258.90mm, alternate offset80mm and row pitch246.25mm, then relabels identical copies by X/Y. These guarded spacings replace the old control clearance that was too small for conservative no-fit cells; no old search is resumed. Verify every original source pair, stock edge, hole and occupied integer cell before model construction; audit every model field/objective before one60-second four-worker call within90seconds shared. A phase7 optimum or failed construction is not a free-angle/global proof. No native/full H5 call follows from this packet alone.',
    'solver_seconds':60,'shared_process_seconds':90,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'maximum_calls':1,'retry_permitted':False,
    'phase_degrees':7,'cogs':15,'coordinate_grid_um':1,'source_stock_guard_um':13,'source_pair_gap_mm':.21170867250963943,'native_guard_mm':.011444091796875,
    'maximum_preparation_seconds':60})
assert load(OLD/'audit/checks.json')['passed'] and load(CAP/'geometry-audit-corrected/checks.json')['passed'];job=load(JOB);part=next(p for p in job['parts'] if p['id']=='cog');mode=load(OLD/'modes.json')[0]
assert mode['family']=='cog' and mode['angle']==math.radians(7) and not mode['mirrored'];g=shape(mode['geometry']);bounds=list(g.bounds)
shutil.copyfile(OLD/'relative/00-00.json',OUT/'relative-cells.json');write(OUT/'mode.json',mode);rectangles=load(CAP/'mode-rectangles.json')[0];write(OUT/'source-rectangles.json',rectangles)
def ceil(v):return -((-v.numerator)//v.denominator)
bb=[F(str(v))*1000 for v in bounds];anchor=[ceil(F(6525)-bb[0]),ceil(F(6525)-bb[1])];chosen=[]
for row in range(3):
    for col in range(5):chosen.append([anchor[0]+col*258900+(row%2)*80000,anchor[1]+row*246250])
control=[{'copy_index':i,'anchor_um':xy} for i,xy in enumerate(sorted(chosen))];rows=[]
for r in control:
    rows.append({'part_id':'cog','copy_index':r['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':mode['angle'],'mirrored':False,'translation':[r['anchor_um'][k]/1000+mode['source_translation_offset'][k] for k in [0,1]]}})
readback=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5]},.21170867250963943,.011444091796875,{('cog',i) for i in range(15)})
write(OUT/'control-source-readback.json',readback);assert readback['valid']
cells=load(OUT/'relative-cells.json')['cells'];pairs=[]
for a,b in combinations(control,2):
    dx,dy=[b['anchor_um'][k]-a['anchor_um'][k] for k in [0,1]];matches=[k for k,c in enumerate(cells) if all(aa*dx+bb*dy>=cc for aa,bb,cc in c['halfplanes'])]
    assert matches,(a,b);pairs.append({'left':a['copy_index'],'right':b['copy_index'],'cell':matches[0]})
outer=[tuple(F(str(v)) for v in point) for point in part['geometry'][0]['outer']];area=abs(sum(x*v-y*u for (x,y),(u,v) in zip(outer,outer[1:]+outer[:1])))/2
upper_offset=ceil(bb[3]);max_top=max(r['anchor_um'][1]+upper_offset for r in control);lower_top=ceil(15*area*1000000/F(1486974)+6513)
stock={'source_bounds_mm':bounds,'x_anchor_min_um':ceil(F(6513)-bb[0]),'x_anchor_max_um':int((F(1493487)-bb[2])//1),'y_anchor_min_um':ceil(F(6513)-bb[1]),
    'source_upper_y_offset_um':upper_offset,'initial_top_um':max_top,'area_lower_top_um':lower_top,'source_area_mm2':[area.numerator,area.denominator],
    'capacity_width_um':1487000,'capacity_y_bottom_um':6500,'actual_stock_bounds_mm':[6.5,6.5,1493.5,2993.5]}
write(OUT/'stock.json',stock);write(OUT/'control.json',control);write(OUT/'control-source15.json',rows);write(OUT/'control-pair-cells.json',pairs)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-started,'mandatory_cogs':15,'source_control_valid':True,'source_pairs_verified':105,'source_stock_edges':60,'source_holes':readback['cutouts'],
    'minimum_source_gap_mm':readback['minimum_pair_gap_mm'],'minimum_extra_stock_mm':readback['minimum_extra_stock_mm'],'relative_cells':len(cells),'relative_halfplanes':sum(len(c['halfplanes']) for c in cells),
    'contained_cog_rectangles':len(rectangles['rectangles_um']),'initial_top_um':max_top,'initial_source_packet_height_mm':(max(r['anchor_um'][1] for r in control)-min(r['anchor_um'][1] for r in control))/1000+bounds[3]-bounds[1],
    'area_lower_top_um':lower_top,'full66_witness':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'prepared.json'))
