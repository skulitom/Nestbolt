"""Independent rational read-back of interval traces and clause-tree coverage."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from h5_guided_conflict_oracle import source_rules,replay,limits
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-six-cog-guided-search-20261025';OUT=BASE/'conflict-proof-audit-completed'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert (BASE/'selected-clause-tree/tree.json').is_file() and (BASE/'selected-clause-tree/result.json').is_file()
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    roots=[BASE/'selected-conflict-proofs',BASE/'selected-clause-tree'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for r in roots for p in r.rglob('*') if p.is_file()},'method':'Reconstruct all source rules independently of the solver model. Replay every integer bound deduction with rational floor or ceiling; check unit clauses, contradiction and exact fixed points. Check complete coverage of every clause split and inherited assumptions. A recorded cap or unvisited/open leaf prevents any complete negative claim.'})
    for r in roots:
        for n,h in load(r/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
    first=roots[0];summary=load(first/'summary.json');result=load(first/'result.json');events=0;contradictions=[]
    assert result['seconds']<60 and len(summary)==19 and not load(first/'pending-cases.json')
    for i,row in enumerate(summary):
        trace=load(first/f'{i:03d}.json');rules,sources=source_rules(ROOT,row['parts']);assert trace['initial_bounds']==rules['initial_bounds'] and trace['clause_sources']==sources
        assert row['case']==i and row['status']==trace['status'] and row['events']==len(trace['events']);events+=replay(rules,trace)
        if trace['status']=='CONTRADICTION':contradictions.append(row['parts'])
    assert events==result['events']==1104 and not contradictions and all(r['status']=='FIXED_POINT' for r in summary)
    tree=load(roots[1]/'tree.json');tr=load(roots[1]/'result.json');rules,sources=source_rules(ROOT,tree['parts']);assert tree['initial_bounds']==rules['initial_bounds'] and tree['clause_sources']==sources
    nodes=tree['nodes'];stack=[(0,rules['initial_bounds'],[])];seen=set();te=leaves=splits=unvisited=opened=0
    while stack:
        ni,bounds,assumptions=stack.pop();assert ni not in seen;seen.add(ni);node=nodes[ni]
        assert node['index']==ni and node['initial_bounds']==bounds and node['assumptions']==assumptions
        if 'trace' not in node:unvisited+=1;continue
        extra=[]
        for ci,ei in assumptions:
            h=rules['clauses'][ci]['edges'][ei];extra.append({'terms':[[v,-c] for v,c in h['terms']],'bound':-h['bound']})
        trace=node['trace'];te+=replay(rules,trace,bounds,extra)
        if trace['status']=='CONTRADICTION':assert 'split' not in node;leaves+=1;continue
        if 'split' not in node:assert trace['status']=='CAP' or 'open_leaf' in node;opened+=1;continue
        assert trace['status']=='FIXED_POINT';split=node['split'];ci=split['clause'];assert ci not in [c for c,e in assumptions]
        final=trace['final_bounds'];live=[i for i,h in enumerate(rules['clauses'][ci]['edges']) if limits(h['terms'],final)[1]>=h['bound']]
        assert split['edges']==live and len(live)>=2 and len(split['children'])==len(live) and len(set(split['children']))==len(live)
        for ei,child in zip(live,split['children']):stack.append((child,final,assumptions+[[ci,ei]]))
        splits+=1
    assert seen==set(range(len(nodes))) and te==tr['events'] and leaves==tr['contradictory_leaves'] and splits==tr['branch_nodes'] and unvisited==tr['pending_nodes']
    complete=unvisited==opened==0 and not tree['pending_stack'];assert complete==tr['complete_contradiction_tree']
    if complete:
        selected=load(BASE/'shared-search/solve/selection.json')['movable_parts'];write(OUT/'certified-selected-combination-exclusion.json',{'parts':selected,'scope':'Only this complete selection of inward integer domains with original source angles, full original guarded pair clauses and fixed 57. Other selections remain open.','fully_replayed_clause_tree':True})
    checks={'passed':True,'seconds':time.perf_counter()-start,'single_traces':19,'single_trace_events':events,'single_trace_contradictions':0,'all_fixed_points_independently_checked':True,'tree_nodes':len(nodes),'tree_events':te,'tree_contradictory_leaves':leaves,'tree_branches':splits,'tree_unvisited':unvisited,'tree_open':opened,'complete_selected_combination_exclusion':complete,'tree_seconds':tr['seconds'],'tree_budget_honored':tr['seconds']<=60,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
