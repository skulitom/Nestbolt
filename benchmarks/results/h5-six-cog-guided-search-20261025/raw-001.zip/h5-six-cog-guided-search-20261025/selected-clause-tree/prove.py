"""A fresh finite proof tree, branching on complete original outside clauses."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,time,shutil
from prove_h5_second_sheet_domain_pairs import prove
from h5_guided_conflict_oracle import source_rules,limits
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-six-cog-guided-search-20261025';OUT=BASE/'selected-clause-tree'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();deadline=start+60
    rules,sources=source_rules(ROOT,list(range(9)))
    plan=load(BASE/'selected-conflict-proofs/plan.json');paths=[ROOT/'output/h5_guided_conflict_oracle.py',BASE/'selected-conflict-proofs/result.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{**plan['inputs'],**{p.relative_to(ROOT).as_posix():digest(p) for p in paths}},'parts':list(range(9)),'shared_seconds':60,'maximum_nodes':2000,'maximum_events':300000,'solver_calls':0,
        'method':'A distinct proof tree for the complete selected nine-domain combination. At each fixed point choose an unresolved full original outside clause with the fewest remaining possible edges. Branch on every live edge, adding its exact inequality as an inward rule. These children cover the entire parent solution set, although they may overlap. Assigned clauses remain enforced. Store every event, branch, pending node and cap. Only complete independent replay with contradictory leaves certifies this selected combination; no unrestricted impossibility or packing acceptance.'})
    nodes=[{'index':0,'initial_bounds':rules['initial_bounds'],'assumptions':[]}];stack=[0];events=0;visited=0
    while stack and time.perf_counter()<deadline and visited<2000 and events<300000:
        ni=stack.pop();node=nodes[ni];extra=[]
        for ci,ei in node['assumptions']:
            h=rules['clauses'][ci]['edges'][ei];extra.append({'terms':[[v,-c] for v,c in h['terms']],'bound':-h['bound']})
        trace=prove({**rules,'initial_bounds':node['initial_bounds'],'inward':rules['inward']+extra},deadline);node['trace']=trace;visited+=1;events+=len(trace['events'])
        if trace['status']=='CAP':break
        if trace['status']=='CONTRADICTION':continue
        assigned={c for c,e in node['assumptions']};eligible=[];bounds=trace['final_bounds']
        for ci,clause in enumerate(rules['clauses']):
            if ci in assigned or any(limits(h['terms'],bounds)[0]>=h['bound'] for h in clause['edges']):continue
            live=[ei for ei,h in enumerate(clause['edges']) if limits(h['terms'],bounds)[1]>=h['bound']];assert len(live)>=2
            eligible.append((len(live),ci,live))
        if not eligible:node['open_leaf']='Every disjunction assigned or interval-separated; remaining linear feasibility not proved.';break
        _,ci,live=min(eligible);children=[]
        for ei in live:
            child=len(nodes);children.append(child);nodes.append({'index':child,'initial_bounds':bounds,'assumptions':node['assumptions']+[[ci,ei]]})
        node['split']={'clause':ci,'edges':live,'children':children};stack.extend(reversed(children))
    complete=not stack and all('trace' in n and (n['trace']['status']=='CONTRADICTION' or 'split' in n) for n in nodes)
    write(OUT/'tree.json',{'parts':list(range(9)),'initial_bounds':rules['initial_bounds'],'clause_sources':sources,'nodes':nodes,'pending_stack':stack})
    result={'seconds':time.perf_counter()-start,'nodes':len(nodes),'visited_nodes':visited,'events':events,'contradictory_leaves':sum(n.get('trace',{}).get('status')=='CONTRADICTION' for n in nodes),'branch_nodes':sum('split' in n for n in nodes),'complete_contradiction_tree':complete,'pending_nodes':sum('trace' not in n for n in nodes),'open_leaves':sum('open_leaf' in n for n in nodes),'solver_calls':0,'independent_replay_pending':True,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':main()
