"""Finite exact interval diagnosis of the selected domains, without solver calls."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,time,shutil
from prove_h5_second_sheet_domain_pairs import prove
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-six-cog-guided-search-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';OUT=BASE/'selected-conflict-proofs'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prove.py');start=time.perf_counter();deadline=start+60
    spec=load(SOURCE/'plan.json');selected=load(BASE/'shared-search/solve/selection.json')['movable_parts']
    queries={p['query']:load(SOURCE/'queries'/f"{p['query']:03d}.json") for p in selected};lookup={(c['profile_a'],c['profile_b']):c['index'] for c in spec['mutual_cases']}
    pairs=[list(p) for p in combinations(range(9),2) if selected[p[0]]['sheet']==selected[p[1]]['sheet']];assert len(pairs)==18
    cases=pairs+[list(range(9))];indices=sorted({lookup[(selected[a]['profile'],selected[b]['profile'])] for a,b in pairs});mutual={i:load(SOURCE/'mutual'/f'{i:03d}.json') for i in indices}
    paths=[SOURCE/'plan.json',BASE/'shared-search/solve/selection.json',BASE/'search-audit/checks.json',ROOT/'output/prove_h5_second_sheet_domain_pairs.py']+[SOURCE/'queries'/f'{i:03d}.json' for i in queries]+[SOURCE/'mutual'/f'{i:03d}.json' for i in indices]
    assert load(BASE/'search-audit/checks.json')['passed']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'cases':cases,'shared_seconds':60,'maximum_passes_per_case':1000,'maximum_events_per_case':100000,'solver_calls':0,
        'method':'Diagnose all 18 same-sheet pairs and the complete selected nine-domain combination with exact integer interval deductions. Rebuild each selected domain and every applicable full guarded original forbidden-piece disjunction. Keep every event, fixed point, cap and pending case. Only independent exact replay can certify an exclusion. Fixed point means unproved, never feasible. No solver invocation or continuation of closed calls.'})
    summary=[]
    for ci,parts in enumerate(cases):
        if time.perf_counter()>=deadline:break
        bounds=[];inward=[];clauses=[];clause_sources=[]
        for i,part in enumerate(parts):
            p=selected[part];d=queries[p['query']]['domains'][p['domain_row']];q=spec['queries'][p['query']];a,b=d['coordinate_bounds'],q['anchor_bounds_units1000']
            bounds.extend([[max(a[0],b[0]),min(a[2],b[2])],[max(a[1],b[1]),min(a[3],b[3])]])
            inward.extend({'terms':[[2*i,h['a']],[2*i+1,h['b']]],'bound':h['bound']} for h in d['halfplanes'])
        for a,b in combinations(parts,2):
            pa,pb=selected[a],selected[b]
            if pa['sheet']!=pb['sheet']:continue
            case=lookup[(pa['profile'],pb['profile'])];i,j=parts.index(a),parts.index(b)
            for f in mutual[case]['faces']:
                clauses.append({'edges':[{'terms':[[2*j,h['a']],[2*i,-h['a']],[2*j+1,h['b']],[2*i+1,-h['b']]],'bound':h['bound']} for h in f['outside_halfplanes']]})
                clause_sources.append({'parts':[a,b],'mutual_case':case,'face':f['index']})
        rules={'initial_bounds':bounds,'inward':inward,'clauses':clauses};trace=prove(rules,deadline)
        write(OUT/f'{ci:03d}.json',{'parts':parts,'initial_bounds':bounds,'clause_sources':clause_sources,**trace})
        summary.append({'case':ci,'parts':parts,'status':trace['status'],'passes':trace['passes'],'events':len(trace['events'])})
        if trace['status']=='CAP':break
    write(OUT/'summary.json',summary);write(OUT/'pending-cases.json',cases[len(summary):])
    result={'seconds':time.perf_counter()-start,'planned_cases':len(cases),'completed_cases':len(summary),'contradictions':sum(s['status']=='CONTRADICTION' for s in summary),'fixed_points':sum(s['status']=='FIXED_POINT' for s in summary),'caps':sum(s['status']=='CAP' for s in summary),'events':sum(s['events'] for s in summary),'solver_calls':0,'independent_replay_pending':True,'full_target_witness':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True);print(summary,flush=True)
if __name__=='__main__':main()
