"""Read back the completed guided pipeline without invoking a solver."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json, time, shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2, sat_parameters_pb2
from audit_h5_selected_anchor_model import verify
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-six-cog-guided-search-20261025'; RUN=BASE/'shared-search'
SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025'; OUT=BASE/'search-audit'
load=lambda p:json.loads(p.read_bytes()); digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in RUN.rglob('*') if p.is_file()},
        'method':'Read back both closed calls, actual models and parameters, source hashes and three-stage timing. Independently reconstruct the full selected original-coordinate model again. Retain the master candidate and selected-domain INFEASIBLE separately. No retries, no unrestricted impossibility or acceptance claim.'})
    budget=load(RUN/'budget.json');result=load(RUN/'result.json');spec=load(SOURCE/'plan.json')
    assert budget['shared_seconds']==60 and budget['master_solver_cap_seconds']==45 and budget['solver_shutdown_reserve_seconds']==2
    assert budget['deadline_perf_counter']==budget['start_perf_counter']+60
    for path in [RUN/'plan.json',RUN/'solve/plan.json',RUN/'selection-audit/plan.json',RUN/'anchor-solve/plan.json']:
        plan=load(path)
        for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
        for field,folder in [('query_hashes',SOURCE/'queries'),('mutual_hashes',SOURCE/'mutual'),('group_hashes',ROOT/'output/h5-convex-domain-conflicts-20261025/groups')]:
            for i,h in plan.get(field,{}).items():assert digest(folder/f'{int(i):03d}.json')==h
    stages=[]
    for folder,expected in [('solve','OPTIMAL'),('anchor-solve','INFEASIBLE')]:
        root=RUN/folder;model=load(root/'model-audit.json');r=load(root/'result.json');opened=load(root/'opened.json')
        assert model['passed'] and digest(root/'model.pb')==model['model_sha256']==opened['model_sha256']
        assert digest(root/'parameters.pbtxt')==model['parameters_sha256']
        params=text_format.Parse((root/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters())
        limit=min(45,model['remaining_shared_budget_at_parameter_set']) if folder=='solve' else model['remaining_shared_budget_at_parameter_set']
        assert params.max_time_in_seconds==opened['seconds_limit']==limit and params.num_search_workers==8 and params.random_seed==0
        assert params.cp_model_presolve and params.cp_model_probing_level==0 and params.symmetry_level==0
        assert r['status']==expected and r['solver_calls']==1
        assert r['seconds']+model['construction_seconds']+model['audit_seconds']<=result['stages'][0 if folder=='solve' else 2]['seconds']
        stages.append({'folder':folder,'status':expected,'solver_seconds':r['seconds'],'limit_seconds':limit,'soft_cap_overshoot_seconds':max(0,r['seconds']-limit)})
    master=load(RUN/'solve/model-audit.json');assert master['hints']==79 and master['conditional_selected_domain_axis_bounds']==9204 and master['variables']==16775 and master['constraints']==55587
    assert load(RUN/'solve/result.json')['has_necessary_domain_candidate'] and not load(RUN/'anchor-solve/result.json')['has_full_original_model_candidate']
    assert result['status']=='ANCHORS_INFEASIBLE' and result['master_solver_calls']==result['anchor_solver_calls']==1
    assert [s['stage'] for s in result['stages']]==['master','selection','anchors'] and all(s['exit_code']==0 for s in result['stages'])
    assert sum(s['seconds'] for s in result['stages'])<=result['elapsed_seconds']<60
    selection=load(RUN/'selection-audit/checks.json');assert selection['passed'] and not selection['selected_combination_geometrically_excluded']
    queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']}
    mutual={q['index']:load(SOURCE/'mutual'/f"{q['index']:03d}.json") for q in spec['mutual_cases']}
    actual=cp_model_pb2.CpModelProto();actual.ParseFromString((RUN/'anchor-solve/model.pb').read_bytes())
    mapping,stats=verify(actual,spec,load(RUN/'solve/selection.json')['movable_parts'],queries,mutual)
    assert mapping==load(RUN/'anchor-solve/mapping.json')
    checks={'passed':True,'seconds':time.perf_counter()-start,'stages':stages,'actual_shared_seconds':result['elapsed_seconds'],'shared_budget_honored':True,
        'master_variables':16775,'master_constraints':55587,'advisory_hints':79,'conditional_domain_axis_bounds':9204,
        'anchor_variables':stats['variables'],'anchor_constraints':stats['constraints'],'anchor_model_independently_reconstructed_again':True,
        'completed_calls_closed_no_retry':True,'negative_scope':'Only the selected nine inward domains, original source angles and fixed 57; other domains and placements remain open.',
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)
if __name__=='__main__':main()
