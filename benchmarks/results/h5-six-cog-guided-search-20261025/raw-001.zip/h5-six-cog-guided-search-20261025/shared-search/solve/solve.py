"""One bounded necessary-domain compatibility call, with full independent oracle."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time,traceback,sys
import ortools
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from ortools.sat.python import cp_model
from audit_h5_six_cog_guided_master import verify
from itertools import combinations

ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-original-domain-conflicts-20261025';BASE=ROOT/'output/h5-convex-domain-conflicts-20261025';SOURCE=ROOT/'output/h5-full-original-joint-prepared-20261025';NEW=ROOT/'output/h5-six-cog-guided-search-20261025/shared-search';OUT=NEW/'solve';PROOF=BASE/'second-sheet-pair-proofs/audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'groups/audit/checks.json')['passed'] and load(OLD/'three-cog-certificate/audit/checks.json')['passed'];OUT.mkdir(parents=True);shutil.copyfile(__file__,OUT/'solve.py')
    assert load(PROOF/'checks.json')['passed']
    regional_path=ROOT/'output/h5-cog-region-capacities-20261025';assert load(regional_path/'audit/checks.json')['passed'];regional=load(regional_path/'capacities.json')
    fullpath=ROOT/'output/h5-original-core-search-20261025';corepath=ROOT/'output/h5-full-cog-coordinates-20261025/original-core-relaxation';assert load(fullpath/'audit/checks.json')['passed'] and load(corepath/'audit/checks.json')['passed'];atlas=load(fullpath/'atlas.json');mutual=load(corepath/'pieces.json');added=load(fullpath/'added-pairs.json')
    pairpath=ROOT/'output/h5-original-core-search-20261025/remaining-second-sheet-pairs';assert load(pairpath/'audit/checks.json')['passed'] and load(pairpath/'geometry-audit-repaired/checks.json')['passed'];new_pairs=load(pairpath/'audit/certified-new-exclusions.json');witness=load(pairpath/'audit/verified-pair-witnesses.json')[0]
    cellpath=ROOT/'output/h5-cog-displacement-cells-20261025';assert load(cellpath/'audit/checks.json')['passed'];cells={q:load(cellpath/'coarse-refinement'/f'selected-query-{q}.json') for q in [18,19]};cell_witness=load(cellpath/'audit/retained-witnesses.json')[0]
    witnesspath=ROOT/'output/h5-guarded-cell-search-20261025';assert load(witnesspath/'first-sheet-four-cog-diagnostic/audit/checks.json')['passed'] and load(witnesspath/'six-cog-geometry-audit/checks.json')['passed'];six=load(witnesspath/'first-sheet-four-cog-diagnostic/audit/six-cog-positions.json')
    pair_exclusions=load(PROOF/'certified-pair-exclusions.json');capacity=load(PROOF/'capacity-certificate.json')
    certificate=load(OLD/'three-cog-certificate/certificate.json')
    spec=load(SOURCE/'plan.json');queries={q['index']:load(SOURCE/'queries'/f"{q['index']:03d}.json") for q in spec['queries']};census=load(BASE/'plan.json')
    groups={c['index']:load(BASE/'groups'/f"{c['index']:03d}.json") for c in census['cases']};aux=load(ROOT/'output/h5-source-orientation-construction-20261025/propagation.json')
    orders=load(SOURCE/'support-construction/atlas.json')['copy_x_order_pairs'];params={'max_time_in_seconds':45,'num_search_workers':8,'random_seed':0,
        'cp_model_presolve':True,'cp_model_probing_level':0,'symmetry_level':0,'log_search_progress':True,'log_to_stdout':False}
    inputs=[BASE/'plan.json',BASE/'audit/checks.json',BASE/'groups/plan.json',BASE/'groups/result.json',BASE/'groups/audit/checks.json',SOURCE/'plan.json',
        SOURCE/'support-construction/atlas.json',ROOT/'output/h5-source-orientation-construction-20261025/propagation.json',ROOT/'output/audit_h5_six_cog_guided_master.py',witnesspath/'first-sheet-four-cog-diagnostic/audit/six-cog-positions.json',witnesspath/'first-sheet-four-cog-diagnostic/audit/checks.json',witnesspath/'six-cog-geometry-audit/checks.json',witnesspath/'remaining-three-candidates/audit/checks.json',cellpath/'audit/checks.json',cellpath/'audit/retained-witnesses.json',cellpath/'coarse-refinement/selected-query-18.json',cellpath/'coarse-refinement/selected-query-19.json',pairpath/'audit/checks.json',pairpath/'geometry-audit-repaired/checks.json',pairpath/'audit/certified-new-exclusions.json',pairpath/'audit/verified-pair-witnesses.json',pairpath/'audit/complete-pair-classification.json',fullpath/'atlas.json',fullpath/'audit/checks.json',corepath/'pieces.json',corepath/'audit/checks.json',fullpath/'added-pairs.json',regional_path/'capacities.json',regional_path/'audit/checks.json',OUT.parent/'budget.json',PROOF/'checks.json',PROOF/'certified-pair-exclusions.json',PROOF/'capacity-certificate.json',OLD/'three-cog-certificate/certificate.json',OLD/'three-cog-certificate/audit/checks.json',ROOT/'benchmarks/results/h5-original-domain-conflicts-20261025/raw-manifest.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'query_hashes':{str(i):digest(SOURCE/'queries'/f'{i:03d}.json') for i in queries},'group_hashes':{str(i):digest(BASE/'groups'/f'{i:03d}.json') for i in groups},
        'construction_limit_seconds':120,'independent_audit_limit_seconds':120,'parameters':params,'maximum_solver_calls':1,'shared_budget_path':str(OUT.parent/'budget.json'),
        'method':'Add9204 exact conditional coordinate bounds for all6x767 selected cog domains, and79 advisory values from the independently checked six-cog construction. All six cogs remain movable; the63-part partial construction is not fixed, and both missing brackets and the insert remain mandatory. Keep all66 original identities, all domains, area and occupancy constraints, and all140 added guarded/exact pair exclusions. Replace the necessary raw-core cog disjunctions with independently proved full guarded allowed displacement cells:229 on sheet0 and4 on sheet1. Each same-sheet pair activates exactly one cell; different-sheet pairs activate none. Enforce every selected cell integer box and inward halfplane on anchorB-anchorA, together with explicit query anchor bounds. First-sheet outward failure padding0.01mm is a stricter constructive restriction and limits negative scope. Independently reconstruct every model field, Boolean truth table and79 advisory hints before one45-second/eight-worker/seed-zero call inside the shared60-second pipeline, reserving2 seconds for shutdown. Hints fix no placements. All other original pair coordinates and66-part/native/H5 validation remain required. No continuation, retry or seed change of any closed call.'})
    start=time.perf_counter();model=cp_model.CpModel();vs=[]
    def var(name,lo,hi):
        v=model.new_int_var(lo,hi,name);assert v.index==len(vs);vs.append(v);return v.index
    def linear(terms,lo,hi):model.add_linear_constraint(sum(vs[i]*coef for i,coef in terms),lo,hi)
    parts=[]
    for pi,item in enumerate(spec['parts']):
        sheet=var(f'part{pi}-sheet',0,1);modes=[];allvars=[]
        for qi in item['queries']:
            active=var(f'part{pi}-query{qi}-active',0,1);ds=[]
            for face in queries[qi]['domains']:
                v=var(f"part{pi}-query{qi}-face{face['index']}",0,1);ds.append(v);allvars.append(v)
            linear([(d,1) for d in ds]+[(active,-1)],0,0);modes.append({'query':qi,'active':active,'domains':ds})
        model.add_exactly_one([vs[m['active']] for m in modes]);linear([(sheet,1)]+[(m['active'],-spec['queries'][m['query']]['sheet']) for m in modes],0,0)
        choice=var(f'part{pi}-choice-index',0,len(allvars)-1);linear([(choice,1)]+[(v,-i) for i,v in enumerate(allvars)],0,0)
        parts.append({'part':pi,'item':item['index'],'family':item['family'],'sheet':sheet,'choice':choice,'modes':modes})
    charges=[aux['part_areas'][p['family']]['lower_units'] for p in parts]
    linear([(p['sheet'],-c) for p,c in zip(parts,charges)],cp_model.INT_MIN,aux['sheet_capacities'][0]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][0]-sum(charges))
    linear([(p['sheet'],c) for p,c in zip(parts,charges)],cp_model.INT_MIN,aux['sheet_capacities'][1]['upper_area_units']-spec['fixed_original_area_units_per_sheet'][1])
    for i,j in orders:linear([(parts[i]['choice'],1),(parts[j]['choice'],-1)],cp_model.INT_MIN,0)
    details=[]
    for pair in census['physical_pair_case_uses']:
        i,j=pair['parts'];a,b=parts[i],parts[j]
        for caseid in pair['cases']:
            row=groups[caseid];case=row['case'];qa=next(m for m in a['modes'] if m['query']==case['query_a']);qb=next(m for m in b['modes'] if m['query']==case['query_b'])
            for group in row['groups']:
                if not group['conflicts_per_a_row']:continue
                da=[qa['domains'][k] for k in group['rows_a']];data=bytes.fromhex(group['forbidden_b_hex'])
                forbidden=[qb['domains'][k] for k in range(case['rows_b']) if data[k//8]&(1<<(7-k%8))]
                assert len(forbidden)==group['conflicts_per_a_row']
                if len(da)==1:flag=da[0]
                else:
                    flag=var(f"pair{i}-{j}-case{caseid}-group{group['group']}",0,1);linear([(v,1) for v in da]+[(flag,-1)],0,0)
                if len(forbidden)==len(qb['domains']):model.add_bool_or([vs[flag].Not(),vs[qb['active']].Not()])
                else:model.add_at_most_one([vs[flag]]+[vs[v] for v in forbidden])
                details.append({'parts':[i,j],'case':caseid,'group':group['group'],'flag':flag})
    occupancies=[]
    for g in certificate['groups']:
        flag=var(f"region-{g['name']}-occupied",0,1);selectors=[]
        for p in parts:
            if p['part'] not in certificate['applicable_moving_cog_parts']:continue
            q=next(m for m in p['modes'] if m['query']==g['query']);selectors.extend(q['domains'][i] for i in g['domain_rows'])
        linear([(v,1) for v in selectors]+[(flag,-1)],0,cp_model.INT_MAX)
        linear([(v,1) for v in selectors]+[(flag,-6)],cp_model.INT_MIN,0)
        occupancies.append({'name':g['name'],'occupied':flag,'selectors':selectors})
    model.add_bool_or([vs[g['occupied']].Not() for g in occupancies])
    for i,j in combinations(capacity['applicable_parts'],2):
        a=next(q for q in parts[i]['modes'] if q['query']==19);b=next(q for q in parts[j]['modes'] if q['query']==19)
        for ra,rb in pair_exclusions['domain_row_pairs']:model.add_bool_or([vs[a['domains'][ra]].Not(),vs[b['domains'][rb]].Not()])
    linear([(next(q for q in parts[i]['modes'] if q['query']==19)['active'],1) for i in capacity['applicable_parts']],cp_model.INT_MIN,2)
    for group in regional['constraints']:
        selectors=[]
        for i in regional['applicable_cog_parts']:
            q=next(q for q in parts[i]['modes'] if q['query']==group['query']);selectors.extend(q['domains'][r] for r in group['domain_rows'])
        linear([(v,1) for v in selectors],cp_model.INT_MIN,group['capacity'])
    for i,j in combinations(regional['applicable_cog_parts'],2):
        for row in added['pairs']:
            a=next(q for q in parts[i]['modes'] if q['query']==row['query']);b=next(q for q in parts[j]['modes'] if q['query']==row['query']);ia,ib=row['domain_rows']
            model.add_bool_or([vs[a['domains'][ia]].Not(),vs[b['domains'][ib]].Not()])
    cog_positions=[]
    boxes=[f['coordinate_bounds'] for q in [18,19] for f in queries[q]['domains']];bounds=[min(b[k] for b in boxes) if k<2 else max(b[k] for b in boxes) for k in range(4)]
    for i in regional['applicable_cog_parts']:
        x=var(f'cog{i}-anchor-x',bounds[0],bounds[2]);y=var(f'cog{i}-anchor-y',bounds[1],bounds[3]);cog_positions.append({'part':i,'x':x,'y':y})
        for m in parts[i]['modes']:
            box=atlas['query_anchor_bounds'][str(m['query'])]
            for v,lo,hi in [(x,box[0],box[2]),(y,box[1],box[3])]:
                model.add_linear_constraint(vs[v],lo,cp_model.INT_MAX).only_enforce_if(vs[m['active']])
                model.add_linear_constraint(vs[v],cp_model.INT_MIN,hi).only_enforce_if(vs[m['active']])
            for row,selector in enumerate(m['domains']):
                db=queries[m['query']]['domains'][row]['coordinate_bounds']
                model.add_linear_constraint(vs[x],db[0],db[2]).only_enforce_if(vs[selector]);model.add_linear_constraint(vs[y],db[1],db[3]).only_enforce_if(vs[selector])
                for h in queries[m['query']]['domains'][row]['halfplanes']:
                    model.add_linear_constraint(vs[x]*h['a']+vs[y]*h['b'],cp_model.INT_MIN,h['bound']).only_enforce_if(vs[selector])
    cell_pairs=[]
    for a,b in combinations(cog_positions,2):
        i,j=a['part'],b['part'];sa,sb=parts[i]['sheet'],parts[j]['sheet'];modes=[]
        for q in [18,19]:
            active=var(f'cog-pair{i}-{j}-query{q}-active',0,1);la=vs[sa].Not() if q==18 else vs[sa];lb=vs[sb].Not() if q==18 else vs[sb]
            model.add_bool_or([vs[active].Not(),la]);model.add_bool_or([vs[active].Not(),lb]);model.add_bool_or([vs[active],la.Not(),lb.Not()])
            flags=[]
            for d in cells[q]['domains']:
                flag=var(f"cog-pair{i}-{j}-query{q}-cell{d['index']}",0,1);flags.append({'index':d['index'],'flag':flag});r=d['coordinate_bounds']
                model.add_linear_constraint(vs[b['x']]-vs[a['x']],r[0],r[2]).only_enforce_if(vs[flag])
                model.add_linear_constraint(vs[b['y']]-vs[a['y']],r[1],r[3]).only_enforce_if(vs[flag])
                for h in d['halfplanes']:
                    model.add_linear_constraint((vs[b['x']]-vs[a['x']])*h['a']+(vs[b['y']]-vs[a['y']])*h['b'],cp_model.INT_MIN,h['bound']).only_enforce_if(vs[flag])
            linear([(f['flag'],1) for f in flags]+[(active,-1)],0,0);modes.append({'query':q,'active':active,'cells':flags})
        cell_pairs.append({'parts':[i,j],'sheet_modes':modes})
    for i,j in combinations(regional['applicable_cog_parts'],2):
        a=next(q for q in parts[i]['modes'] if q['query']==19);b=next(q for q in parts[j]['modes'] if q['query']==19)
        for ra,rb in new_pairs['domain_row_pairs']:model.add_bool_or([vs[a['domains'][ra]].Not(),vs[b['domains'][rb]].Not()])
    by={p['part']:p for p in six}
    for source in six:
        p=parts[source['part']];q=next(m for m in p['modes'] if m['query']==source['query']);xy=next(m for m in cog_positions if m['part']==source['part'])
        model.add_hint(vs[p['sheet']],source['sheet'])
        for m in p['modes']:model.add_hint(vs[m['active']],int(m['query']==source['query']))
        for v,value in [(q['domains'][source['domain_row']],1),(p['choice'],source['choice_index']),(xy['x'],source['x_units']),(xy['y'],source['y_units'])]:model.add_hint(vs[v],value)
    for pair in cell_pairs:
        a,b=[by[i] for i in pair['parts']]
        for mode in pair['sheet_modes']:
            q=mode['query'];active=int(a['query']==b['query']==q);model.add_hint(vs[mode['active']],active)
            if active:
                dx,dy=b['x_units']-a['x_units'],b['y_units']-a['y_units'];eligible=[]
                for d in cells[q]['domains']:
                    r=d['coordinate_bounds']
                    if r[0]<=dx<=r[2] and r[1]<=dy<=r[3] and all(h['a']*dx+h['b']*dy<=h['bound'] for h in d['halfplanes']):eligible.append(d['index'])
                assert eligible;cell=next(c for c in mode['cells'] if c['index']==eligible[0]);model.add_hint(vs[cell['flag']],1)
    mapping={'parts':parts,'groups':details,'region_occupancies':occupancies,'simultaneous_cog_coordinates':cog_positions,'guarded_displacement_cell_pairs':cell_pairs};write(OUT/'mapping.json',mapping);assert model.validate()=='' and model.export_to_file(str(OUT/'model.pb'))
    buildtime=time.perf_counter()-start;assert buildtime<120;start=time.perf_counter();actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'model.pb').read_bytes())
    expected,stats=verify(actual,spec,queries,census,groups,aux,orders,certificate,pair_exclusions,capacity,regional,atlas,added,new_pairs,witness,cells,cell_witness,six);assert expected==mapping
    remaining=load(OUT.parent/'budget.json')['deadline_perf_counter']-time.perf_counter()-2.0
    assert remaining>0,'Shared construction/solve budget exhausted before call'
    params['max_time_in_seconds']=min(45,remaining)
    solver=cp_model.CpSolver()
    for k,v in params.items():setattr(solver.parameters,k,v)
    assert text_format.Parse(str(solver.parameters),sat_parameters_pb2.SatParameters())==sat_parameters_pb2.SatParameters(**params)
    (OUT/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');at=time.perf_counter()-start;assert at<120
    write(OUT/'model-audit.json',{'passed':True,'construction_seconds':buildtime,'audit_seconds':at,**stats,'model_sha256':digest(OUT/'model.pb'),
        'parameters_sha256':digest(OUT/'parameters.pbtxt'),'remaining_shared_budget_at_parameter_set':remaining,'python':sys.version,'ortools':ortools.__version__});print(load(OUT/'model-audit.json'),flush=True)
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'maximum_solver_calls':1,'shared_budget_path':str(OUT.parent/'budget.json'),'seconds_limit':params['max_time_in_seconds'],'model_sha256':digest(OUT/'model.pb')})
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda s:(log.write(s+'\n'),log.flush());start=time.perf_counter();code=solver.solve(model);elapsed=time.perf_counter()-start
    feasible=code in [cp_model.OPTIMAL,cp_model.FEASIBLE]
    if feasible:
        selected=[]
        for p in parts:
            modes=[m for m in p['modes'] if solver.value(vs[m['active']])];assert len(modes)==1;m=modes[0]
            ds=[i for i,v in enumerate(m['domains']) if solver.value(vs[v])];assert len(ds)==1;q=spec['queries'][m['query']]
            selected.append({'part':p['part'],'item':p['item'],'family':p['family'],'query':m['query'],'domain_row':ds[0],
                'domain_index':queries[m['query']]['domains'][ds[0]]['index'],'profile':q['profile'],'sheet':q['sheet'],'choice_index':solver.value(vs[p['choice']])})
        write(OUT/'selection.json',{'fixed_items':spec['fixed_items'],'movable_parts':selected,'required_originals':66})
        write(OUT/'necessary-cog-positions.json',[{'part':p['part'],'x_units':solver.value(vs[p['x']]),'y_units':solver.value(vs[p['y']])} for p in cog_positions])
        chosen_cells=[]
        for pair in cell_pairs:
            active=[m for m in pair['sheet_modes'] if solver.value(vs[m['active']])]
            chosen=[]
            for m in active:
                chosen.extend({'query':m['query'],'cell_index':c['index']} for c in m['cells'] if solver.value(vs[c['flag']]))
            chosen_cells.append({'parts':pair['parts'],'chosen_cells':chosen})
        write(OUT/'guarded-cog-cell-selection.json',chosen_cells)

    result={'status':solver.status_name(code),'seconds':elapsed,'solver_calls':1,'has_necessary_domain_candidate':feasible,'response_stats':solver.response_stats(),
        'scope':'Complete original-angle/inward-domain/fixed57-source construction with the complete refined pair table and proved global three-cog occupancy exclusion. A feasible assignment has full guarded original-cog anchors and still requires full guarded-coordinate validation of every original; a negative is not unrestricted impossibility.',
        'full_target_witness':False,'native_full_job_qualified':False,'H5_complete':False}
    write(OUT/'result.json',result);print(result,flush=True)
if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
