"""Prepare selected-domain bounds and advisory hints from all six proved cogs."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'output'
OLD='output/h5-guarded-cell-search-20261025/shared-search';NEW='output/h5-six-cog-guided-search-20261025/shared-search'
WIT="ROOT/'output/h5-guarded-cell-search-20261025'"
def save(n,s):
    with (R/n).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'audit_h5_guarded_cell_master.py').read_text(encoding='utf-8')
s=s.replace('witness,cells,cell_witness):','witness,cells,cell_witness,six):')
s=s.replace('    added_variables=12+15*(2+ncells);added_constraints=nplanes+48+',"    nbounds=12*sum(len(queries[q]['domains']) for q in [18,19])\n    added_variables=12+15*(2+ncells);added_constraints=nplanes+nbounds+48+")
needle="            for row,selector in enumerate(m['domains']):\n                for h in ds[row]['halfplanes']:"
replacement="            for row,selector in enumerate(m['domains']):\n                db=ds[row]['coordinate_bounds'];linear([(x,1)],db[0],db[2],[selector]);linear([(y,1)],db[1],db[3],[selector])\n                for h in ds[row]['halfplanes']:"
assert needle in s;s=s.replace(needle,replacement)
a=s.index("    assert witness['domain_rows']==[1,1]");b=s.index('    expected=cp_model_pb2.PartialVariableAssignment()',a)
s=s[:a]+'''    assert [p['part'] for p in six]==cogs
    assert [p['choice_index'] for p in six]==sorted(p['choice_index'] for p in six)
    hints=[];by={p['part']:p for p in six}
    for source in six:
        target=source['part'];assert source['profile']==9 and source['item']==spec['parts'][target]['index']
        p=mapping['parts'][target];q=next(m for m in p['modes'] if m['query']==source['query']);xy=next(m for m in positions if m['part']==target)
        d=queries[source['query']]['domains'][source['domain_row']];assert d['index']==source['domain_index'];x,y=source['x_units'],source['y_units'];db=d['coordinate_bounds']
        assert db[0]<=x<=db[2] and db[1]<=y<=db[3] and all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes'])
        choice=sum(len(m['domains']) for m in p['modes'][:p['modes'].index(q)])+source['domain_row'];assert choice==source['choice_index']
        hints.append((p['sheet'],source['sheet']))
        hints.extend((m['active'],int(m['query']==source['query'])) for m in p['modes'])
        hints.extend([(q['domains'][source['domain_row']],1),(p['choice'],choice),(xy['x'],x),(xy['y'],y)])
    for pair in pair_cells:
        a,b=[by[i] for i in pair['parts']]
        for mode in pair['sheet_modes']:
            q=mode['query'];active=int(a['query']==b['query']==q);hints.append((mode['active'],active))
            if active:
                dx,dy=b['x_units']-a['x_units'],b['y_units']-a['y_units'];eligible=[]
                for d in cells[q]['domains']:
                    r=d['coordinate_bounds']
                    if r[0]<=dx<=r[2] and r[1]<=dy<=r[3] and all(h['a']*dx+h['b']*dy<=h['bound'] for h in d['halfplanes']):eligible.append(d['index'])
                assert eligible;cell=next(c for c in mode['cells'] if c['index']==eligible[0]);hints.append((cell['flag'],1))
'''+s[b:]
s=s.replace('==16','==79').replace("'hints':16","'hints':79").replace("'explicit_selected_query_box_constraints':48,","'explicit_selected_query_box_constraints':48,'conditional_selected_domain_axis_bounds':nbounds,")
s=s.replace("'hints_add_no_constraint_or_fixed_domain':True","'hints_add_no_constraint_or_fixed_domain':True,'all_six_cog_domain_and_cell_hint_memberships_checked':True")
save('audit_h5_six_cog_guided_master.py',s)
s=(R/'solve_h5_guarded_cell_master.py').read_text(encoding='utf-8').replace(OLD,NEW).replace('from audit_h5_guarded_cell_master import verify','from audit_h5_six_cog_guided_master import verify')
s=s.replace("    pair_exclusions=load(PROOF/","    witnesspath="+WIT+";assert load(witnesspath/'first-sheet-four-cog-diagnostic/audit/checks.json')['passed'] and load(witnesspath/'six-cog-geometry-audit/checks.json')['passed'];six=load(witnesspath/'first-sheet-four-cog-diagnostic/audit/six-cog-positions.json')\n    pair_exclusions=load(PROOF/")
s=s.replace("ROOT/'output/audit_h5_guarded_cell_master.py',","ROOT/'output/audit_h5_six_cog_guided_master.py',witnesspath/'first-sheet-four-cog-diagnostic/audit/six-cog-positions.json',witnesspath/'first-sheet-four-cog-diagnostic/audit/checks.json',witnesspath/'six-cog-geometry-audit/checks.json',witnesspath/'remaining-three-candidates/audit/checks.json',")
needle="            for row,selector in enumerate(m['domains']):\n                for h in queries[m['query']]['domains'][row]['halfplanes']:"
replacement="            for row,selector in enumerate(m['domains']):\n                db=queries[m['query']]['domains'][row]['coordinate_bounds']\n                model.add_linear_constraint(vs[x],db[0],db[2]).only_enforce_if(vs[selector]);model.add_linear_constraint(vs[y],db[1],db[3]).only_enforce_if(vs[selector])\n                for h in queries[m['query']]['domains'][row]['halfplanes']:"
assert needle in s;s=s.replace(needle,replacement)
a=s.index("    for target,source in zip([7,8],witness['positions']):");b=s.index("    mapping={'parts':parts",a)
s=s[:a]+'''    by={p['part']:p for p in six}
    for source in six:
        p=parts[source['part']];q=next(m for m in p['modes'] if m['query']==source['query']);xy=next(m for m in cog_positions if m['part']==source['part'])
        model.add_hint(vs[p['sheet']],source['sheet'])
        for m in p['modes']:model.add_hint(vs[m['active']],int(m['query']==source['query']))
        for v,value in [(q['domains'][source['domain_row']],1),(p['choice'],source['choice_index']),(xy['x'],source['x_units']),(xy['y'],source['y_units'])]:model.add_hint(vs[v],value)
    for pair in cell_pairs:
        a,b=[by[i] for i in pair['parts']]
        for mode in pair['sheet_modes']:
            q=mode['query'];active=int(a['query']==b['query']==q);model.add_hint(vs[mode['active']],active)
            if active:
                dx,dy=b['x_units']-a['x_units'],b['y_units']-a['y_units'];eligible=[]
                for d in cells[q]['domains']:
                    r=d['coordinate_bounds']
                    if r[0]<=dx<=r[2] and r[1]<=dy<=r[3] and all(h['a']*dx+h['b']*dy<=h['bound'] for h in d['halfplanes']):eligible.append(d['index'])
                assert eligible;cell=next(c for c in mode['cells'] if c['index']==eligible[0]);model.add_hint(vs[cell['flag']],1)
'''+s[b:]
s=s.replace('new_pairs,witness,cells,cell_witness);','new_pairs,witness,cells,cell_witness,six);')
s=s.replace('Keep all66 original identities,','Add9204 exact conditional coordinate bounds for all6x767 selected cog domains, and79 advisory values from the independently checked six-cog construction. All six cogs remain movable; the63-part partial construction is not fixed, and both missing brackets and the insert remain mandatory. Keep all66 original identities,')
s=s.replace('and16 advisory hints','and79 advisory hints');save('solve_h5_six_cog_guided_master.py',s)
for source,target in [('audit_h5_guarded_cell_selection.py','audit_h5_six_cog_guided_selection.py'),('solve_h5_guarded_cell_anchors.py','solve_h5_six_cog_guided_anchors.py')]:save(target,(R/source).read_text(encoding='utf-8').replace(OLD,NEW))
s=(R/'run_h5_guarded_cell_search.py').read_text(encoding='utf-8').replace('h5-guarded-cell-search-20261025','h5-six-cog-guided-search-20261025')
for name in ['solve_h5_guarded_cell_master','audit_h5_guarded_cell_selection','solve_h5_guarded_cell_anchors']:s=s.replace(name,name.replace('guarded_cell','six_cog_guided'))
s=s.replace("'method':'New master", "'method':'New master adds exact chosen-domain integer boxes and advisory hints from all six verified cogs while keeping all66 originals movable/mandatory. The known63-part partial layout is not fixed. New master")
save('run_h5_six_cog_guided_search.py',s)
print('Prepared six-cog guided full model with9204 exact axis bounds and79 advisory values; no solver run yet.')
