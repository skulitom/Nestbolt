"""Exact full-model oracle for sheet-conditional guarded displacement cells."""
from collections import Counter
from itertools import combinations,product
from ortools.sat import cp_model_pb2
from audit_h5_added_guarded_pairs_master import verify as verify_base

def verify(actual,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional,atlas,added,new_pairs,witness,cells,cell_witness,six):
    cogs=regional['applicable_cog_parts'];assert cogs==[3,4,5,6,7,8]
    ncells=sum(len(d['domains']) for d in cells.values());ncellplanes=sum(len(f['halfplanes']) for d in cells.values() for f in d['domains'])
    assert ncells==233 and ncellplanes==831
    nplanes=6*sum(len(f['halfplanes']) for q in [18,19] for f in queries[q]['domains'])
    nbounds=12*sum(len(queries[q]['domains']) for q in [18,19])
    added_variables=12+15*(2+ncells);added_constraints=nplanes+nbounds+48+15*(8+2*ncells+ncellplanes)+150
    prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(actual);del prefix.variables[-added_variables:];del prefix.constraints[-added_constraints:];prefix.ClearField('solution_hint')
    mapping,stats=verify_base(prefix,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional,added)
    vi=len(prefix.variables);ci=len(prefix.constraints);positions=[];pair_cells=[]
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]),(vi,name);vi+=1;return vi-1
    def linear(terms,lo,hi,en=()):
        nonlocal ci
        values=Counter()
        for v,c in terms:values[v]+=c
        ids=sorted(v for v,c in values.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(values[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en)
        assert actual.constraints[ci]==p,(ci,actual.constraints[ci],p);ci+=1
    def boolean(literals):
        nonlocal ci
        p=cp_model_pb2.ConstraintProto();p.bool_or.literals.extend(literals);assert actual.constraints[ci]==p,(ci,literals);ci+=1
    boxes=[f['coordinate_bounds'] for q in [18,19] for f in queries[q]['domains']]
    bounds=[min(b[k] for b in boxes) if k<2 else max(b[k] for b in boxes) for k in range(4)]
    for i in cogs:
        assert spec['parts'][i]['profiles']==[9] and spec['parts'][i]['queries']==[18,19]
        x=var(f'cog{i}-anchor-x',bounds[0],bounds[2]);y=var(f'cog{i}-anchor-y',bounds[1],bounds[3]);positions.append({'part':i,'x':x,'y':y})
        for m in mapping['parts'][i]['modes']:
            q=m['query'];ds=queries[q]['domains'];b=[min(f['coordinate_bounds'][k] for f in ds) if k<2 else max(f['coordinate_bounds'][k] for f in ds) for k in range(4)]
            assert atlas['query_anchor_bounds'][str(q)]==b and cells[q]['difference_bounds_units1000']==[b[0]-b[2],b[1]-b[3],b[2]-b[0],b[3]-b[1]]
            for v,lo,hi in [(x,b[0],b[2]),(y,b[1],b[3])]:linear([(v,1)],lo,2**63-1,[m['active']]);linear([(v,1)],-2**63,hi,[m['active']])
            for row,selector in enumerate(m['domains']):
                db=ds[row]['coordinate_bounds'];linear([(x,1)],db[0],db[2],[selector]);linear([(y,1)],db[1],db[3],[selector])
                for h in ds[row]['halfplanes']:linear([(x,h['a']),(y,h['b'])],-2**63,h['bound'],[selector])
    for a,b in combinations(positions,2):
        i,j=a['part'],b['part'];sa,sb=mapping['parts'][i]['sheet'],mapping['parts'][j]['sheet'];modes=[]
        for q in [18,19]:
            active=var(f'cog-pair{i}-{j}-query{q}-active',0,1)
            literals=([-sa-1,-sb-1] if q==18 else [sa,sb])
            boolean([-active-1,literals[0]]);boolean([-active-1,literals[1]]);boolean([active,-literals[0]-1,-literals[1]-1])
            flags=[]
            for d in cells[q]['domains']:
                flag=var(f"cog-pair{i}-{j}-query{q}-cell{d['index']}",0,1);flags.append({'index':d['index'],'flag':flag});r=d['coordinate_bounds']
                linear([(b['x'],1),(a['x'],-1)],r[0],r[2],[flag]);linear([(b['y'],1),(a['y'],-1)],r[1],r[3],[flag])
                for h in d['halfplanes']:
                    assert h['sense']=='le';linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],-2**63,h['bound'],[flag])
            linear([(f['flag'],1) for f in flags]+[(active,-1)],0,0);modes.append({'query':q,'active':active,'cells':flags})
        pair_cells.append({'parts':[i,j],'sheet_modes':modes})
    assert new_pairs['query']==19 and len(new_pairs['domain_row_pairs'])==10
    for i,j in combinations(cogs,2):
        a=next(m for m in mapping['parts'][i]['modes'] if m['query']==19);b=next(m for m in mapping['parts'][j]['modes'] if m['query']==19)
        for ra,rb in new_pairs['domain_row_pairs']:boolean([-a['domains'][ra]-1,-b['domains'][rb]-1])
    assert vi==len(actual.variables) and ci==len(actual.constraints)
    # Exhaust all Boolean sheet/activation combinations independently of the model construction.
    for sheet in [0,1]:
        for sa,sb,active in product([0,1],repeat=3):
            la,lb=(not sa,not sb) if sheet==0 else (bool(sa),bool(sb))
            clauses=(not active or la) and (not active or lb) and (active or not la or not lb)
            assert bool(clauses)==(active==int(sa==sb==sheet))
    mapping['simultaneous_cog_coordinates']=positions;mapping['guarded_displacement_cell_pairs']=pair_cells
    assert [p['part'] for p in six]==cogs
    assert [p['choice_index'] for p in six]==sorted(p['choice_index'] for p in six)
    hints=[];by={p['part']:p for p in six}
    for source in six:
        target=source['part'];assert source['profile']==9 and source['item']==spec['parts'][target]['index']
        p=mapping['parts'][target];q=next(m for m in p['modes'] if m['query']==source['query']);xy=next(m for m in positions if m['part']==target)
        d=queries[source['query']]['domains'][source['domain_row']];assert d['index']==source['domain_index'];x,y=source['x_units'],source['y_units'];db=d['coordinate_bounds']
        assert db[0]<=x<=db[2] and db[1]<=y<=db[3] and all(h['a']*x+h['b']*y<=h['bound'] for h in d['halfplanes'])
        choice=sum(len(m['domains']) for m in p['modes'][:p['modes'].index(q)])+source['domain_row'];assert choice==source['choice_index']
        hints.append((p['sheet'],source['sheet']))
        hints.extend((m['active'],int(m['query']==source['query'])) for m in p['modes'])
        hints.extend([(q['domains'][source['domain_row']],1),(p['choice'],choice),(xy['x'],x),(xy['y'],y)])
    for pair in pair_cells:
        a,b=[by[i] for i in pair['parts']]
        for mode in pair['sheet_modes']:
            q=mode['query'];active=int(a['query']==b['query']==q);hints.append((mode['active'],active))
            if active:
                dx,dy=b['x_units']-a['x_units'],b['y_units']-a['y_units'];eligible=[]
                for d in cells[q]['domains']:
                    r=d['coordinate_bounds']
                    if r[0]<=dx<=r[2] and r[1]<=dy<=r[3] and all(h['a']*dx+h['b']*dy<=h['bound'] for h in d['halfplanes']):eligible.append(d['index'])
                assert eligible;cell=next(c for c in mode['cells'] if c['index']==eligible[0]);hints.append((cell['flag'],1))
    expected=cp_model_pb2.PartialVariableAssignment();expected.vars.extend(v for v,_ in hints);expected.values.extend(x for _,x in hints);assert actual.solution_hint==expected
    assert len(hints)==len({v for v,_ in hints})==79
    for v,value in hints:assert actual.variables[v].domain[0]<=value<=actual.variables[v].domain[-1]
    return mapping,{**stats,'variables':vi,'constraints':ci,'simultaneous_cog_anchor_variables':12,'conditional_inward_domain_halfplanes':nplanes,'explicit_selected_query_box_constraints':48,'conditional_selected_domain_axis_bounds':nbounds,
        'guarded_displacement_cells_per_pair':ncells,'guarded_displacement_cell_flags':15*ncells,'pair_sheet_activation_flags':30,'pair_activation_truth_tables_exhausted':True,
        'chosen_cell_integer_box_constraints':30*ncells,'chosen_cell_inward_halfplanes':15*ncellplanes,'new_exact_second_sheet_pair_clauses':150,
        'hints':79,'hints_add_no_constraint_or_fixed_domain':True,'all_six_cog_domain_and_cell_hint_memberships_checked':True,'all66_originals_still_required':True,'full_guarded_original_cog_separation_implied':True,
        'remaining_original_pairs_need_full_coordinate_validation':True,'first_sheet_additional_constructive_failure_padding_mm':.01}
