"""Preserve the premature read-back failure; prepare a separate terminal audit."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-six-cog-guided-search-20261025'
with (BASE/'conflict-proof-audit/failure-record.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'error':'FileNotFoundError: selected-clause-tree/tree.json','cause':'Read-back started before the independent proof process reached its terminal files.','original_audit_preserved':True,'proof_or_solver_restarted':False,'repair':'Use a separate completed read-back directory only after the original proof process exits.'},f,indent=2);f.write('\n')
s=(ROOT/'output/audit_h5_guided_conflict_proofs.py').read_text(encoding='utf-8')
s=s.replace("OUT=BASE/'conflict-proof-audit'","OUT=BASE/'conflict-proof-audit-completed'")
s=s.replace('    OUT.mkdir();',"    assert (BASE/'selected-clause-tree/tree.json').is_file() and (BASE/'selected-clause-tree/result.json').is_file()\n    OUT.mkdir();")
with (ROOT/'output/audit_h5_guided_completed_conflict_proofs.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Preserved failed early read-back and prepared terminal-only audit; no computation rerun.')
