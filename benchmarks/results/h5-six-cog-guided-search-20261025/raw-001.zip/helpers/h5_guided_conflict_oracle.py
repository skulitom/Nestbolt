"""Source-rule reconstruction and rational replay of integer deductions."""
from fractions import Fraction
from itertools import combinations
import math,json
def source_rules(root,parts):
    load=lambda p:json.loads(p.read_bytes());source=root/'output/h5-full-original-joint-prepared-20261025'
    selected=load(root/'output/h5-six-cog-guided-search-20261025/shared-search/solve/selection.json')['movable_parts'];spec=load(source/'plan.json')
    bounds=[];inward=[];clauses=[];sources=[]
    for offset,part in enumerate(parts):
        p=selected[part];q=spec['queries'][p['query']];d=load(source/'queries'/f"{p['query']:03d}.json")['domains'][p['domain_row']]
        assert d['index']==p['domain_index'] and q['sheet']==p['sheet'] and q['profile']==p['profile']
        a,b=d['coordinate_bounds'],q['anchor_bounds_units1000']
        for axis in range(2):bounds.append([max(a[axis],b[axis]),min(a[axis+2],b[axis+2])])
        inward.extend({'terms':[[2*offset,h['a']],[2*offset+1,h['b']]],'bound':h['bound']} for h in d['halfplanes'])
    for left,right in combinations(parts,2):
        a,b=selected[left],selected[right]
        if a['sheet']!=b['sheet']:continue
        case=next(c['index'] for c in spec['mutual_cases'] if c['profile_a']==a['profile'] and c['profile_b']==b['profile'])
        i,j=parts.index(left),parts.index(right)
        for face in load(source/'mutual'/f'{case:03d}.json')['faces']:
            clauses.append({'edges':[{'terms':[[2*j,h['a']],[2*i,-h['a']],[2*j+1,h['b']],[2*i+1,-h['b']]],'bound':h['bound']} for h in face['outside_halfplanes']]})
            sources.append({'parts':[left,right],'mutual_case':case,'face':face['index']})
    return {'initial_bounds':bounds,'inward':inward,'clauses':clauses},sources
def limits(terms,bounds):
    products=[(c*bounds[v][0],c*bounds[v][1]) for v,c in terms]
    return sum(min(p) for p in products),sum(max(p) for p in products)
def replay(rules,trace,initial=None,extra=()):
    bounds=[b.copy() for b in (rules['initial_bounds'] if initial is None else initial)];inward=rules['inward']+list(extra);clauses=rules['clauses'];empty=None
    for ei,event in enumerate(trace['events']):
        assert empty is None
        if event['kind']=='empty_clause':
            assert all(limits(h['terms'],bounds)[1]<h['bound'] for h in clauses[event['clause']]['edges'])
            empty={'kind':'empty_clause','clause':event['clause']};assert ei==len(trace['events'])-1;continue
        assert event['kind']=='bound';reason=event['reason']
        if reason['kind']=='inward':h=inward[reason['rule']];terms,limit=h['terms'],h['bound']
        else:
            assert reason['kind']=='unit';edges=clauses[reason['clause']]['edges'];live=[i for i,h in enumerate(edges) if limits(h['terms'],bounds)[1]>=h['bound']]
            assert live==[reason['edge']];h=edges[live[0]];terms=[(v,-c) for v,c in h['terms']];limit=-h['bound']
        v=event['variable'];c=next(c for w,c in terms if w==v);assert c!=0
        other=limits([(w,k) for w,k in terms if w!=v],bounds)[0];value=Fraction(limit-other,c);side=int(c>0);new=math.floor(value) if c>0 else math.ceil(value)
        assert event['side']==side and event['new']==new and event['old']==bounds[v][side]
        assert (new<bounds[v][1] if side else new>bounds[v][0]);bounds[v][side]=new
        if bounds[v][0]>bounds[v][1]:empty={'kind':'empty_interval','variable':v,'interval':bounds[v].copy()};assert ei==len(trace['events'])-1
    assert bounds==trace['final_bounds'] and empty==trace['contradiction']
    if trace['status']=='CONTRADICTION':assert empty is not None
    else:assert trace['status'] in ['FIXED_POINT','CAP'] and empty is None
    if trace['status']=='FIXED_POINT':
        # Verify no further source inward or unit-clause bound deduction exists.
        active=list(inward)
        for clause in clauses:
            if any(limits(h['terms'],bounds)[0]>=h['bound'] for h in clause['edges']):continue
            live=[h for h in clause['edges'] if limits(h['terms'],bounds)[1]>=h['bound']];assert live
            if len(live)==1:active.append({'terms':[(v,-c) for v,c in live[0]['terms']],'bound':-live[0]['bound']})
        for h in active:
            for v,c in h['terms']:
                if not c:continue
                other=limits([(w,k) for w,k in h['terms'] if w!=v],bounds)[0];value=Fraction(h['bound']-other,c)
                assert (math.floor(value)>=bounds[v][1] if c>0 else math.ceil(value)<=bounds[v][0])
    return len(trace['events'])
