"""Finite offline checkerboard construction from original cog outlines."""
from pathlib import Path
import sys, json, math, itertools, time, copy, shutil, gzip, traceback
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import shapely
from shapely.geometry import Polygon, LineString, mapping
from shapely.affinity import affine_transform
import construct_h5_pattern_layouts as old
gap=old.gap
ROOT=old.ROOT
OUT=ROOT/'output/h5-cog-lattices-20261018'
SRC=ROOT/'output/h5-angle-pattern-placement-20261018/m-mechanical-large-plates-k0.2-s0-candidate'
load=old.load; write=gap.write; digest=old.digest

def main():
    OUT.mkdir()
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(), 'source_digest':gap.source_digest(),
          'script_sha256':digest(Path(__file__)), 'sources':{str(SRC.relative_to(ROOT)/n):digest(SRC/n) for n in ['job.json','library.json','request.json','original.json','conditional-target.json','patterns.json','frames.json']},
          'base_angles_degrees':[0,4.5,9], 'relative_phases_degrees':[0,3,6,9,12,15], 'alternate_offsets_mm':[-6,0,6],
          'grids':[[15,5],[12,4],[10,5],[9,3],[6,3],[5,5],[3,3]],
          'construction_clearance':.22, 'extra_pitch_mm':.0001,
          'catalogue_limit_seconds':120, 'whole_job_limit_seconds':120,
          'whole_job':'Rank all valid lattice variants by 15-cog bounding rectangle area, retain best 12. For each, try decompositions [15], [10,5], [9,6], [12,3], [5,5,5], all 25 retained frame allocations, original mixed bracket patterns or singles, four sort orders, three rectangle placement scores. Stop at first complete inventory, otherwise retain best partial and every attempted outcome. Original stock and conditional target unchanged. Component clearance is 0.22 mm for construction only; original acceptance is 0.2 mm.',
          'claim':'Offline feasibility diagnosis only; no native packing, runtime qualification, quality or H5 credit.'}
    assert plan['source_digest']=='8505a0bbce2c8f150799d3a6823611e21cbc33abb027b79bf095e43dc9ae7e88'
    write(OUT/'plan.json',plan);shutil.copyfile(__file__,OUT/'construct.py')
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json','patterns.json','frames.json']:shutil.copyfile(SRC/n,OUT/('prior-'+n if n in ['patterns.json','frames.json'] else n))
    job=load(SRC/'job.json'); parts={p['id']:p for p in job['parts']};shapes={p['id']:Polygon(p['geometry'][0]['outer']) for p in job['parts']}
    shape=shapes['cog'];cx,cy=shape.centroid.coords[0]
    assert parts['cog']['rotations']['kind']=='free' and not parts['cog']['allow_mirror']
    centered=affine_transform(shape,[1,0,0,1,-cx,-cy]); variants=[]; patterns={};records=[]; t0=time.perf_counter();queries=0;pair_checks=0
    obstacles=OUT/'obstacles';obstacles.mkdir();expired=False
    for base,phase in itertools.product(plan['base_angles_degrees'],plan['relative_phases_degrees']):
        if time.perf_counter()-t0>=plan['catalogue_limit_seconds']:expired=True;break
        aa,bb=map(math.radians,[base,base+phase]);a=gap.pose(centered,old.transform(aa));b=gap.pose(centered,old.transform(bb))
        forbidden=gap.obstacle(a,b,plan['construction_clearance']);queries+=1
        write(obstacles/f'{base}-{phase}.json',mapping(forbidden))
        for ox,oy in itertools.product(plan['alternate_offsets_mm'],repeat=2):
            h=forbidden.intersection(LineString([(-1000,oy),(1000,oy)]));v=forbidden.intersection(LineString([(ox,-1000),(ox,1000)]))
            dx=max(h.bounds[2]-ox,ox-h.bounds[0])+plan['extra_pitch_mm'];dy=max(v.bounds[3]-oy,oy-v.bounds[1])+plan['extra_pitch_mm']
            ident=f'b{base}-p{phase}-x{ox}-y{oy}';rec={'id':ident,'base':base,'phase':phase,'offset':[ox,oy],'pitch':[dx,dy],'patterns':[],'valid':True}
            for n,cols in plan['grids']:
                members=[]
                for i in range(n):
                    col,row=i%cols,i//cols;alt=(row+col)%2;theta=bb if alt else aa;c,s=math.cos(theta),math.sin(theta)
                    x=col*dx+alt*ox;y=row*dy+alt*oy
                    members.append(old.member('cog',old.transform(theta,x-c*cx+s*cy,y-s*cx-c*cy)))
                p=old.pattern(ident+f'-n{n}',members,shapes);geoms=[gap.pose(shape,m['transform']) for m in p['members']]
                bad=[];minimum=math.inf
                for i,j in itertools.combinations(range(n),2):
                    pair_checks+=1;d=geoms[i].distance(geoms[j]);minimum=min(minimum,d)
                    if not geoms[i].disjoint(geoms[j]) or d<job['clearance']:bad.append([i,j,d,geoms[i].intersection(geoms[j]).area])
                p['construction']={'variant':ident,'count':n,'columns':cols,'minimum_distance':minimum,'violations':bad}
                patterns[p['id']]=p;rec['patterns'].append(p['id'])
                if bad:rec['valid']=False
            records.append(rec)
            if rec['valid']:variants.append(rec)
    variants.sort(key=lambda r:(patterns[r['patterns'][0]]['width']*patterns[r['patterns'][0]]['height'],r['id']))
    write(OUT/'patterns.json',patterns);write(OUT/'variants.json',records)
    write(OUT/'generation.json',{'seconds':time.perf_counter()-t0,'expired':expired,'queries':queries,'variant_count':len(records),'valid_variants':len(variants),'pair_checks':pair_checks,'center':[cx,cy], 'selected_variants':[r['id'] for r in variants[:12]],'best':[{**r,'full_width':patterns[r['patterns'][0]]['width'],'full_height':patterns[r['patterns'][0]]['height']} for r in variants[:3]]})
    print(json.dumps({'phase':'catalogue','variants':len(records),'valid':len(variants),'best':[(r['id'],patterns[r['patterns'][0]]['width'],patterns[r['patterns'][0]]['height']) for r in variants[:3]]}),flush=True)
    patterns={**load(SRC/'patterns.json'),**patterns};frames=load(SRC/'frames.json');target=load(SRC/'conditional-target.json');stock=job['stocks'][0];g=.22
    m=stock['margins'];e=job['edge_clearance']
    width=stock['width']-m['left']-m['right']-2*e-2e-4
    heights=[stock['height']-m['bottom']-m['top']-2*e-2e-4,target['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
    # Rebuild free rectangles with the new positive padding, retaining exactly
    # the original frame rotations/count configurations and their order.
    frames=old.frame_configs(patterns['frame'],parts['frame']['quantity'],width,heights[0],g)
    write(OUT/'frames.json',frames)
    mixes=[]
    for name,p in patterns.items():
        inv=Counter(m['part_id'] for m in p['members'])
        if inv['bracket'] and not inv['cog'] and not inv['frame']:mixes.append(name)
    inventories=[]
    for name in mixes:
        inv=Counter(m['part_id'] for m in patterns[name]['members']);qty=min(parts[k]['quantity']//v for k,v in inv.items());items=[name]*qty
        for k in ['bracket','insert']:items += [k]*(parts[k]['quantity']-qty*inv[k])
        inventories.append((name,items))
    best=None;attempts=0;t0=time.perf_counter();expired=False;complete=None
    with gzip.open(OUT/'attempts.jsonl.gz','wt',encoding='utf-8',newline='\n') as log:
        for variant,decomp,(mode,other),fi,sort,fit in itertools.product(variants[:12],[[15],[10,5],[9,6],[12,3],[5,5,5]],inventories,range(len(frames)),['area','long','short','filled'],['short','area','bottom']):
            if time.perf_counter()-t0>=plan['whole_job_limit_seconds']:expired=True;break
            bycount={patterns[n]['construction']['count']:n for n in variant['patterns']};items=[bycount[n] for n in decomp]+other
            fr=frames[fi];free0=[(0,0,width+g,heights[0]+g)]
            for q in fr['placed']:free0=old.subtract(free0,q['rect'])
            added,left=old.pack(items,patterns,[free0,[(0,0,width+g,heights[1]+g)]],sort,fit,g)
            blocks=fr['placed']+added;area=sum(patterns[q['pattern']]['area'] for q in blocks);count=sum(len(patterns[q['pattern']]['members']) for q in blocks)
            rec={'variant':variant['id'],'decomposition':decomp,'mode':mode,'frame':fi,'sort':sort,'fit':fit,'count':count,'area':area,'blocks':blocks,'unplaced':left}
            log.write(json.dumps(rec,separators=(',',':'))+'\n');attempts+=1
            if best is None or (area,count)>(best['area'],best['count']):best=rec
            if not left:complete=rec;break
    write(OUT/'all-patterns.json',patterns);write(OUT/'best-attempt.json',best)
    layout=old.layout_of(job,patterns,best['blocks']);write(OUT/'best-partial.json',layout)
    write(OUT/'result.json',{'attempts':attempts,'seconds':time.perf_counter()-t0,'expired':expired,'frames':len(frames),'mixed_inventory_options':len(inventories),'complete':complete is not None,'placed_count':best['count'],'area':best['area'],'missing':dict(Counter({k:p['quantity'] for k,p in parts.items()})-Counter(p['part_id'] for p in layout['placements']))})
    if complete:
        moved={(p['part_id'],p['copy_index']) for p in layout['placements']}
        write(OUT/'validation.json',gap.validate(OUT,'full-layout',layout,job,load(OUT/'original.json'),moved))
    print((OUT/'result.json').read_text(),flush=True)

if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
