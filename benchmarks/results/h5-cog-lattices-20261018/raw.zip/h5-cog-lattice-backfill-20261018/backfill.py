"""Try remaining original parts in actual gaps of selected new lattice layouts."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import copy,gzip,json,math,shutil,time,traceback,itertools
from shapely.geometry import Polygon
import construct_h5_outline_beam as beam
base=beam.base;gap=beam.gap;load=base.load;write=base.write;ROOT=base.ROOT
SRC=ROOT/'output/h5-cog-lattices-20261018';OUT=ROOT/'output/h5-cog-lattice-backfill-20261018'

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'backfill.py')
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':base.digest(Path(__file__)),
          'inputs':{str(SRC.relative_to(ROOT)/n):base.digest(SRC/n) for n in ['attempts.jsonl.gz','all-patterns.json','job.json','result.json','conditional-target.json']},
          'selection':'Keep the greatest filled-area partial for each frame configuration and per-sheet cog inventory, with earliest attempt breaking ties. Rank these distinct groups by filled area then placed count then first attempt. Continue the first eight only.',
          'method':'Preserve all selected placements exactly. Repeatedly query each missing original family in decreasing filled area, with allowed reflections and quarter turns (15-degree finite sample for free parts), two original target sheets, conservative Minkowski exclusions, and three lowest distinct contacts per orientation. Select the first feasible family and its least prefix-waste contact. Stop on no-family-fit or all inventory. Check every proposed addition directly against original filled outer neighbours.',
          'selected_partial_cap':8,'total_continuation_seconds':120,'construction_clearance_mm':.22,'native_packing_calls':0,'quality_runs':0,'claim':'Offline finite feasibility only; original source attempts retained; incomplete or timed-out construction is not infeasibility.'}
    write(OUT/'plan.json',plan);patterns=load(SRC/'all-patterns.json');job=load(SRC/'job.json');target=load(SRC/'conditional-target.json');best={};read=0
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(SRC/n,OUT/n)
    with gzip.open(SRC/'attempts.jsonl.gz','rt',encoding='utf-8') as f:
        for index,line in enumerate(f):
            r=json.loads(line);read+=1;cogs=[0,0]
            for b in r['blocks']:cogs[b['bin']]+=sum(m['part_id']=='cog' for m in patterns[b['pattern']]['members'])
            key=(r['frame'],*cogs);rank=(r['area'],r['count'],-index)
            if key not in best or rank>best[key][0]:best[key]=(rank,index,r)
    selected=sorted(best.values(),key=lambda x:x[0],reverse=True)[:8]
    write(OUT/'selection.json',{'attempts_read':read,'groups':len(best),'selected':[{'source_attempt':i,'attempt':r} for _,i,r in selected]})
    parts={p['id']:p for p in job['parts']};shapes={p['id']:Polygon(p['geometry'][0]['outer']) for p in job['parts']}
    singles={k:base.pattern(k,[base.member(k)],shapes) for k in parts}
    for k,p in parts.items():
        if p['allow_mirror']:singles[k+'-mirror']=base.pattern(k+'-mirror',[base.member(k,base.transform(mirrored=True))],shapes)
    st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];origin=[m['left']+e+1e-4,m['bottom']+e+1e-4]
    width=st['width']-m['left']-m['right']-2*e-2e-4;heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,target['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
    t0=time.perf_counter();placer=beam.Placement(job,singles,width,heights);placer.clearance=plan['construction_clearance_mm'];fixed_cache={}
    byfamily={k:[t['template_id'] for t in placer.templates if t['members'][0]['part_id']==k] for k in parts};results=[];expired=False
    for si,(_,index,record) in enumerate(selected):
        if time.perf_counter()-t0>=plan['total_continuation_seconds']:expired=True;break
        folder=OUT/f'partial-{si:02d}';folder.mkdir();initial=base.layout_of(job,patterns,record['blocks']);actual=copy.deepcopy(initial);write(folder/'initial.json',initial)
        state={'id':0,'placed':[]};counts=Counter(p['part_id'] for p in initial['placements']);remaining=Counter({k:p['quantity'] for k,p in parts.items()})-counts
        for p in initial['placements']:
            t=p['transform'];key=(p['part_id'],t['rotation_radians'],t['mirrored']);zero={**t,'translation':[0.,0.]};shape=gap.pose(shapes[p['part_id']],zero);x0,y0,_,_=shape.bounds
            if key not in fixed_cache:
                q=base.pattern('fixed-'+p['part_id'],[base.member(p['part_id'],zero)],shapes);q.update(template_id=len(placer.templates),outer_geometries=[gap.pose(shapes[p['part_id']],q['members'][0]['transform'])]);fixed_cache[key]=q['template_id'];placer.templates.append(q)
            state['placed'].append({'template':fixed_cache[key],'x':t['translation'][0]-origin[0]+x0,'y':t['translation'][1]-origin[1]+y0,'sheet':int(p['sheet_id'].split('-')[-1])})
        state['score']=placer.score(state);write(folder/'initial-state.json',state);transitions=[];attempts=0
        with gzip.open(folder/'candidates.jsonl.gz','xt',encoding='utf-8',newline='\n') as log:
            while remaining:
                choice=None
                for family in sorted(remaining,key=lambda k:(-shapes[k].area,k)):
                    possibilities=[]
                    for tid,sheet in itertools.product(byfamily[family],[0,1]):
                        if time.perf_counter()-t0>=plan['total_continuation_seconds']:expired=True;break
                        points=placer.positions(state,tid,sheet)
                        if not points:log.write(json.dumps({'kind':'empty','step':len(transitions),'family':family,'template':tid,'sheet':sheet})+'\n')
                        for x,y in points:
                            b={'template':tid,'x':x,'y':y,'sheet':sheet};valid=placer.valid_addition(state,b);attempts+=1;trial={'id':attempts,'placed':state['placed']+[b]};trial['score']=placer.score(trial)
                            log.write(json.dumps({'kind':'candidate','step':len(transitions),'family':family,'block':b,'valid':valid,'score':trial['score']})+'\n')
                            if valid:possibilities.append(trial)
                    if expired:break
                    if possibilities:choice=(family,min(possibilities,key=lambda x:(x['score'],x['id'])));break
                if choice is None or expired:break
                family,state=choice;b=state['placed'][-1];t=copy.deepcopy(placer.templates[b['template']]['members'][0]['transform']);t['translation'][0]+=b['x']+origin[0];t['translation'][1]+=b['y']+origin[1]
                addition={'part_id':family,'copy_index':counts[family],'sheet_id':f"sheet-{b['sheet']}",'transform':t};actual['placements'].append(addition);counts[family]+=1;remaining[family]-=1
                if not remaining[family]:del remaining[family]
                transitions.append({'addition':addition,'block':b,'remaining':dict(remaining)});log.write(json.dumps({'kind':'accepted','step':len(transitions),'block':b,'remaining':dict(remaining)})+'\n')
        assert actual['placements'][:len(initial['placements'])]==initial['placements'];write(folder/'layout.json',actual);write(folder/'transitions.json',transitions)
        result={'partial':si,'source_attempt':index,'original_count':len(initial['placements']),'added':len(transitions),'placed_count':len(actual['placements']),'missing':dict(remaining),'candidate_attempts':attempts,'expired':expired,'complete':not remaining}
        if not remaining:
            for n in ['library.json','request.json']:shutil.copyfile(OUT/n,folder/n)
            result['validation']=gap.validate(folder,'full',actual,job,load(OUT/'original.json'),{(p['part_id'],p['copy_index']) for p in actual['placements']});assert result['validation']['metrics']['material_area']<=target['target_material_mm2']+1e-6
        write(folder/'result.json',result);results.append(result);print(json.dumps(result),flush=True)
        if not remaining or expired:break
    write(OUT/'templates.json',[{k:v for k,v in t.items() if k!='outer_geometries'} for t in placer.templates])
    write(OUT/'results.json',{'seconds':time.perf_counter()-t0,'expired':expired,'selected':len(selected),'processed':len(results),'cases':results,'full_witness':any(r['complete'] for r in results),'relative_obstacles':len(placer.obstacles),'addition_pair_checks':placer.pair_checks})
    print((OUT/'results.json').read_text(),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
