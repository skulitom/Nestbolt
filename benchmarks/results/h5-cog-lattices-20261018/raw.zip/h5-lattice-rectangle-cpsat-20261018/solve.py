"""Bounded exact-count rectangle-group model with freely placed frame blocks."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
from hashlib import sha256
import json,math,time,shutil,traceback,sys
import ortools
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'output/h5-cog-lattices-20261018';OUT=ROOT/'output/h5-lattice-rectangle-cpsat-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'solve.py');patterns=load(SRC/'all-patterns.json');job=load(SRC/'job.json');target=load(SRC/'conditional-target.json');st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];g=.22;scale=1000
    variant=load(SRC/'generation.json')['selected_variants'][0];mixes=[n for n,p in patterns.items() if Counter(m['part_id'] for m in p['members'])==Counter(bracket=2,insert=1)];mix=min(mixes,key=lambda n:(patterns[n]['width']*patterns[n]['height'],n))
    decomps=[[15],[10,5],[9,6],[12,3],[5,5,5]];width=st['width']-m['left']-m['right']-2*e-2e-4;heights=[st['height']-m['bottom']-m['top']-2*e-2e-4,target['required_used_height_mm']-m['bottom']-m['top']-2*e-2e-4]
    plan={'opened_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':digest(Path(__file__)),'input_hashes':{str(SRC.relative_to(ROOT)/n):digest(SRC/n) for n in ['all-patterns.json','generation.json','job.json','conditional-target.json']},
          'method':'All eighteen original frames, six verified two-bracket/one-insert patterns, fifteen remaining inserts and exactly one of five complete 15-cog decompositions. Every rectangle may translate on a 0.001 mm grid, rotate by a quarter-turn and choose either original target sheet when it fits. Frame columns are not fixed. Exact-one optional orientation/sheet intervals and per-sheet NoOverlap2D. Repeated identical items ordered by sheet/y/x to remove interchangeable-copy symmetry. No objective or partial inventory. Padded sizes ceil outward and sheet capacities floor inward.',
          'cog_variant':variant,'bracket_pattern':mix,'decompositions':decomps,'scale_per_mm':scale,'block_gap_mm':g,'width_mm':width,'height_limits_mm':heights,'seconds_limit':120,'seed':0,'workers':8,'python':sys.version,'ortools':ortools.__version__,
          'scope':'New finite offline model, not a quality run or budget change. Feasible rectangles must be expanded to all 66 original parts and independently validated. UNKNOWN or finite-model infeasibility does not prove unrestricted geometry impossible.'}
    write(OUT/'plan.json',plan)
    for n in ['job.json','library.json','request.json','original.json','conditional-target.json']:shutil.copyfile(SRC/n,OUT/n)
    used={n:patterns[n] for n in ['frame','insert',mix]+[variant+f'-n{n}' for n in [15,10,5,9,6,12,3]]};write(OUT/'patterns.json',used)
    assert all(Counter({'frame':18,'insert':15})+Counter(m['part_id'] for _ in range(6) for m in patterns[mix]['members'])+Counter(m['part_id'] for n in ds for m in patterns[variant+f'-n{n}']['members'])==Counter({p['id']:p['quantity'] for p in job['parts']}) for ds in decomps)
    model=cp_model.CpModel();options=[model.new_bool_var(f'inventory-{i}') for i in range(len(decomps))];model.add_exactly_one(options)
    items=[{'pattern':'frame','group':None} for _ in range(18)]+[{'pattern':mix,'group':None} for _ in range(6)]+[{'pattern':'insert','group':None} for _ in range(15)]
    for oi,ds in enumerate(decomps):items += [{'pattern':variant+f'-n{n}','group':oi} for n in ds]
    W=math.floor((width+g)*scale);Hs=[math.floor((h+g)*scale) for h in heights];big=(max(Hs)+1)*(W+1);intervals=[[],[]];placements=[];keys=defaultdict(list);metadata=[]
    for i,item in enumerate(items):
        p=used[item['pattern']];lits=[];row=[];key=model.new_int_var(0,2*big,f'key-{i}');keys[(item['group'],item['pattern'])].append(key)
        for sheet in [0,1]:
            for rot in [False,True]:
                w,h=(p['height'],p['width']) if rot else (p['width'],p['height']);wi=math.ceil((w+g)*scale);hi=math.ceil((h+g)*scale)
                if wi>W or hi>Hs[sheet]:continue
                name=f'{i}-s{sheet}-r{int(rot)}';present=model.new_bool_var('present-'+name);x=model.new_int_var(0,W-wi,'x-'+name);y=model.new_int_var(0,Hs[sheet]-hi,'y-'+name)
                ix=model.new_optional_fixed_size_interval_var(x,wi,present,'ix-'+name);iy=model.new_optional_fixed_size_interval_var(y,hi,present,'iy-'+name);intervals[sheet].append((ix,iy));lits.append(present)
                model.add(key==sheet*big+y*(W+1)+x).only_enforce_if(present)
                row.append({'item':i,'pattern':item['pattern'],'group':item['group'],'sheet':sheet,'rotated':rot,'width_units':wi,'height_units':hi,'present_var':present.index,'x_var':x.index,'y_var':y.index})
                placements.append((row[-1],present,x,y))
        if item['group'] is None:model.add_exactly_one(lits)
        else:
            model.add(sum(lits)==options[item['group']]);model.add(key==0).only_enforce_if(options[item['group']].Not())
        metadata.append({'item':i,**item,'key_var':key.index,'choices':row})
    for group in keys.values():
        for a,b in zip(group,group[1:]):model.add(a<=b)
    for rows in intervals:model.add_no_overlap_2d([p[0] for p in rows],[p[1] for p in rows])
    write(OUT/'mapping.json',{'W':W,'Hs':Hs,'key_stride':big,'inventory_variables':[o.index for o in options],'items':metadata})
    assert model.validate()=='';model.export_to_file(str(OUT/'model.pbtxt'));solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=120;solver.parameters.num_search_workers=8;solver.parameters.random_seed=0;solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
    with (OUT/'solver.log').open('x',encoding='utf-8',newline='\n') as log:
        solver.log_callback=lambda msg:(log.write(msg+'\n'),log.flush());t0=time.perf_counter();status=solver.solve(model);elapsed=time.perf_counter()-t0
    feasible=status in [cp_model.OPTIMAL,cp_model.FEASIBLE];result={'status':solver.status_name(status),'seconds':elapsed,'feasible':feasible,'response_stats':solver.response_stats(),'model_sha256':digest(OUT/'model.pbtxt')}
    if feasible:
        selected=[{**r,'x':solver.value(x)/scale,'y':solver.value(y)/scale} for r,p,x,y in placements if solver.boolean_value(p)];write(OUT/'selection.json',selected)
        counts=Counter();actual=[];base=[m['left']+e+1e-4,m['bottom']+e+1e-4]
        for b in selected:
            p=used[b['pattern']]
            for member in p['members']:
                t=json.loads(json.dumps(member['transform']));x,y=t['translation']
                if b['rotated']:t['rotation_radians']+=math.pi/2;x,y=p['height']-y,x
                t['translation']=[base[0]+b['x']+x,base[1]+b['y']+y];family=member['part_id'];actual.append({'part_id':family,'copy_index':counts[family],'sheet_id':f"sheet-{b['sheet']}",'transform':t});counts[family]+=1
        write(OUT/'layout.json',{'version':1,'units':'mm','sheets':load(OUT/'original.json')['sheets'],'placements':actual});result['counts']=dict(counts);result['decomposition_index']=next(i for i,o in enumerate(options) if solver.boolean_value(o))
    write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists() and not (OUT/'failure.txt').exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
