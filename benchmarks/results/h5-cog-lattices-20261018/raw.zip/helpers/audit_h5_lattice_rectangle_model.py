"""Parse exported model independently of producer mappings and solver APIs."""
from pathlib import Path
from collections import Counter,defaultdict
from hashlib import sha256
import json,math
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-lattice-rectangle-cpsat-20261018'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    proto=text_format.Parse((OUT/'model.pbtxt').read_text(encoding='utf-8'),cp_model_pb2.CpModelProto());plan=load(OUT/'plan.json');mapping=load(OUT/'mapping.json');patterns=load(OUT/'patterns.json');job=load(OUT/'job.json');scale=plan['scale_per_mm'];gap=plan['block_gap_mm']
    for name,h in plan['input_hashes'].items():assert sha256((ROOT/name).read_bytes()).hexdigest()==h
    assert not proto.HasField('objective') and not proto.HasField('floating_point_objective') and not proto.HasField('solution_hint')
    W=math.floor((plan['width_mm']+gap)*scale);Hs=[math.floor((h+gap)*scale) for h in plan['height_limits_mm']];big=(max(Hs)+1)*(W+1);assert (W,Hs,big)==(mapping['W'],mapping['Hs'],mapping['key_stride'])
    variables={v.name:(i,list(v.domain)) for i,v in enumerate(proto.variables)};assert len(variables)==len(proto.variables)
    options=mapping['inventory_variables'];assert len(options)==5
    expected=Counter();expected_variable_names=set();interval_specs={};keys=defaultdict(list);groups=defaultdict(Counter);rows=[]
    def var(name,domain):
        expected_variable_names.add(name);i,d=variables[name];assert d==domain,(name,d,domain);return i
    def linear(enforce,terms,domain):return ('linear',tuple(enforce),tuple(sorted((k,v) for k,v in terms.items() if v)),tuple(domain))
    def exact(lits):return ('exactly_one',(),tuple(sorted(lits)))
    def expr(e):return tuple(sorted(zip(e.vars,e.coeffs))),e.offset
    for i,oi in enumerate(options):assert var(f'inventory-{i}',[0,1])==oi
    expected[exact(options)]+=1
    for item in mapping['items']:
        i=item['item'];p=patterns[item['pattern']];group=item['group'];ki=var(f'key-{i}',[0,2*big]);assert ki==item['key_var'];keys[(group,item['pattern'])].append(ki);groups[group].update(m['part_id'] for m in p['members']);lits=[];expected_choices=[]
        for sheet in [0,1]:
            for rot in [False,True]:
                w,h=(p['height'],p['width']) if rot else (p['width'],p['height']);wi=math.ceil((w+gap)*scale);hi=math.ceil((h+gap)*scale)
                if wi>W or hi>Hs[sheet]:continue
                name=f'{i}-s{sheet}-r{int(rot)}';pi=var('present-'+name,[0,1]);xi=var('x-'+name,[0,W-wi]);yi=var('y-'+name,[0,Hs[sheet]-hi]);lits.append(pi)
                expected_choices.append({'item':i,'pattern':item['pattern'],'group':group,'sheet':sheet,'rotated':rot,'width_units':wi,'height_units':hi,'present_var':pi,'x_var':xi,'y_var':yi})
                for axis,vi,size in [('x',xi,wi),('y',yi,hi)]:interval_specs['i'+axis+'-'+name]=((pi,),(((vi,1),),0),((),size),(((vi,1),),size))
                rows.append((sheet,'ix-'+name,'iy-'+name));expected[linear([pi],{ki:1,yi:-(W+1),xi:-1},[sheet*big]*2)]+=1
        assert expected_choices==item['choices']
        if group is None:expected[exact(lits)]+=1
        else:
            expected[linear([],{**{l:1 for l in lits},options[group]:-1},[0,0])]+=1;expected[linear([-options[group]-1],{ki:1},[0,0])]+=1
    assert set(variables)==expected_variable_names
    required=Counter({p['id']:p['quantity'] for p in job['parts']})
    for i in range(5):assert groups[None]+groups[i]==required
    for seq in keys.values():
        for a,b in zip(seq,seq[1:]):expected[linear([],{a:1,b:-1},[-9223372036854775808,0])]+=1
    found=Counter();interval_ids={};overlaps=[]
    for i,c in enumerate(proto.constraints):
        kind=c.WhichOneof('constraint')
        if kind=='interval':
            assert c.name in interval_specs and c.name not in interval_ids;interval_ids[c.name]=i;actual=(tuple(c.enforcement_literal),expr(c.interval.start),expr(c.interval.size),expr(c.interval.end));assert actual==interval_specs[c.name]
        elif kind=='linear':found[linear(c.enforcement_literal,dict(zip(c.linear.vars,c.linear.coeffs)),c.linear.domain)]+=1
        elif kind=='exactly_one':assert not c.enforcement_literal;found[exact(c.exactly_one.literals)]+=1
        elif kind=='no_overlap_2d':assert not c.enforcement_literal;overlaps.append(c.no_overlap_2d)
        else:raise AssertionError(kind)
    assert found==expected and len(interval_ids)==len(interval_specs) and len(overlaps)==2
    for sheet,c in enumerate(overlaps):
        assert list(c.x_intervals)==[interval_ids[x] for s,x,y in rows if s==sheet] and list(c.y_intervals)==[interval_ids[y] for s,x,y in rows if s==sheet]
    checks={'variables':len(proto.variables),'constraints':len(proto.constraints),'optional_rectangles':len(rows),'intervals':len(interval_ids),'all_variable_domains_verified':True,'all_constraints_verified':True,'all_five_alternatives_require_exact_original_inventory':True,'outward_dimensions_and_inward_capacities_verified':True,'only_identical_copy_ordering':True,'no_objective_or_hidden_constraints':True,'model_sha256':sha256((OUT/'model.pbtxt').read_bytes()).hexdigest()}
    write(OUT/'model-audit.json',checks);print(json.dumps(checks))
if __name__=='__main__':main()
