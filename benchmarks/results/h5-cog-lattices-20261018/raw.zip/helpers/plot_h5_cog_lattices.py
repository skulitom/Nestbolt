from pathlib import Path
import json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle,Patch
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'output/h5-cog-lattices-20261018';BACK=ROOT/'output/h5-cog-lattice-backfill-20261018';load=lambda p:json.loads(p.read_bytes())
job=load(RUN/'job.json');parts={p['id']:p for p in job['parts']};colors={'frame':'#c5ced8','cog':'#dc873e','bracket':'#448a91','insert':'#6c9270'}
def draw(ax,p,shift=0):
    t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;x,y=t['translation'];coords=[(m*a*c-b*s+x,m*a*s+b*c+y+shift) for a,b in parts[p['part_id']]['geometry'][0]['outer']];ax.add_patch(Polygon(coords,facecolor=colors[p['part_id']],edgecolor='#26333e',linewidth=.35))
fig=plt.figure(figsize=(13,9));gs=fig.add_gridspec(2,3,width_ratios=[1.4,1,1],height_ratios=[1,1],wspace=.18)
ax=fig.add_subplot(gs[0,0]);gen=load(RUN/'generation.json');p=load(RUN/'patterns.json')[gen['best'][0]['patterns'][0]]
for m in p['members']:draw(ax,m)
ax.add_patch(Rectangle((0,0),p['width'],p['height'],fill=False,color='#687787',linestyle='--'));ax.set_xlim(-30,p['width']+30);ax.set_ylim(-30,p['height']+30);ax.set_aspect('equal');ax.set_title('Verified 15-cog group\n1,357.90 × 818.93 mm',fontsize=11);ax.set_xlabel('mm');ax.set_ylabel('mm')
ax=fig.add_subplot(gs[1,0]);ax.axis('off');ax.text(0,.92,'Finite construction results',fontsize=15,weight='bold');ax.text(0,.79,'162 phase/offset variants\n1,134 verified components\n45,360 component pair checks\n\n504,000 whole-job rectangle attempts\n8 outline-gap continuations\nNo complete 66-part layout found\n\nFree-placement rectangle search: UNKNOWN\n120.105 seconds; no complete selection',fontsize=10.5,linespacing=1.2,va='top');ax.legend(handles=[Patch(color=c,label=k.capitalize()) for k,c in colors.items()],loc='lower left',frameon=False,ncol=2)
for col,path,title in [(1,RUN/'best-partial.json','Highest filled-area rectangle result\n52/66; missing 14 inserts'),(2,BACK/'partial-04/layout.json','One gap-filled result\n60/66; missing 2 brackets, 4 cogs')]:
    ax=fig.add_subplot(gs[:,col]);layout=load(path);target=load(RUN/'conditional-target.json');h=target['required_used_height_mm'];ax.add_patch(Rectangle((0,0),1500,3000,fill=False,color='#334'));ax.add_patch(Rectangle((0,-h-90),1500,h,fill=False,color='#334'))
    for p in layout['placements']:draw(ax,p,0 if p['sheet_id']=='sheet-0' else -h-90)
    ax.set_xlim(-20,1520);ax.set_ylim(-h-110,3030);ax.set_aspect('equal');ax.set_title(title,fontsize=10);ax.set_xticks([0,750,1500]);ax.set_yticks([0,1000,2000,3000]);ax.tick_params(labelsize=8);ax.set_xlabel('mm')
fig.suptitle('H5 diagnostic: coherent cog groups, original stock and inventory',fontsize=16,y=.985);fig.text(.5,.015,'Original holes remain reserved. Partial layouts are not cutting jobs or H5 passes.',ha='center',fontsize=10);fig.savefig(RUN/'overview.png',dpi=160,bbox_inches='tight');plt.close(fig)
