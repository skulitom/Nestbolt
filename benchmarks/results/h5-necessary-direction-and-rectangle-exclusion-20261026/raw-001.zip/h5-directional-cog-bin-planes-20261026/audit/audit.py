"""Reconstruct complete bidirectional bins and exact source-face implications."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-directional-cog-bin-planes-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();deadline=start+300
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'audit_limit_seconds':300,'method':'Independently derive all80 required original profile pairs and their exact complete stock-difference boxes. Reconstruct every zero-anchored1mm integer Y bin and both side alternatives; require unique rows and full coverage. Verify each full-stock edge at all four exact corners. Independently choose each directional edge with Fraction thresholds, reconstruct exact endpoint-dominance pruning and check each retained requirement is an actual original rounded source plane. For every face, require its whole-stock proof or a retained directional line dominating its chosen edge throughout the complete bin. No fixed relative x order, no source coordinate witness claim, no reverse implication and no solver.'})
plan=load(BASE/'plan.json')
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'];s=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');bounds=s['anchor_bounds_units1000'];cases=[c for c in s['mutual_cases'] if profiles[c['profile_a']]['family']!='cog' and profiles[c['profile_b']]['family']=='cog'];assert len(cases)==80 and plan['profile_pairs']==[[c['profile_a'],c['profile_b']] for c in cases] and plan['relative_y_bin_width_units1000']==1000 and plan['relative_y_bin_origin_units1000']==0 and plan['directions']==['left','right']
rows=load(BASE/'guards.json');index={(tuple(r['profiles']),r['bin'],r['side']):r for r in rows};assert len(index)==len(rows);seen=set();faces_checked=stock_checked=retained=covered=0;details=[]
for ordinal,c in enumerate(cases):
    assert time.perf_counter()<deadline
    pa,pb=c['profile_a'],c['profile_b'];aa,bb=bounds[str(pa)],bounds[str(pb)];xmin,xmax=bb[0]-aa[2],bb[2]-aa[0];ymin,ymax=bb[1]-aa[3],bb[3]-aa[1];datum=load(SOURCE/'mutual'/f"{c['index']:03d}.json");following=ymin
    for k in range(ymin//1000,ymax//1000+1):
        lo,hi=max(ymin,k*1000),min(ymax,k*1000+999);assert lo==following;following=hi+1;covered+=hi-lo+1
        for side in ['left','right']:
            key=((pa,pb),k,side);r=index[key];seen.add(key);assert r['source_case']==c['index'] and r['relative_x_units1000']==[xmin,xmax] and r['relative_y_units1000']==[lo,hi];chosen=[];unique=[];keys=set();thresholds=[]
            for f in datum['faces']:
                stock=[j for j,h in enumerate(f['outside_halfplanes']) if all(h['a']*x+h['b']*y>=h['bound'] for x,y in product([xmin,xmax],[lo,hi]))]
                if stock:chosen.append({'face':f['index'],'edge':stock[0],'stock_proof':True});stock_checked+=1;continue
                options=[]
                for j,h in enumerate(f['outside_halfplanes']):
                    A=h['a']
                    if (side=='right' and A>0) or (side=='left' and A<0):
                        values=[F(h['bound']-h['b']*y,A) for y in [lo,hi]];t=max(xmin,math.ceil(max(values))) if side=='right' else min(xmax,math.floor(min(values)));options.append((t,j))
                assert options;t,edge=min(options,key=lambda v:(v[0] if side=='right' else -v[0],v[1]));thresholds.append(t);chosen.append({'face':f['index'],'edge':edge,'stock_proof':False});h=f['outside_halfplanes'][edge];key2=tuple(h[n] for n in ['a','b','bound'])
                if key2 not in keys:keys.add(key2);unique.append({'a':h['a'],'b':h['b'],'bound':h['bound'],'source_face':f['index'],'source_edge':edge})
            values=[[F(h['bound']-h['b']*y,h['a']) for y in [lo,hi]] for h in unique]
            def dominates(u,v):return all(a>=b for a,b in zip(u,v)) if side=='right' else all(a<=b for a,b in zip(u,v))
            keep=[i for i,v in enumerate(values) if not any(i!=j and dominates(w,v) and (w!=v or j<i) for j,w in enumerate(values))];requirements=[unique[i] for i in keep];assert requirements==r['requirements'] and len(unique)==r['unique_directional_source_edges'];retained+=len(requirements)
            assert len(r['source_face_proofs'])==len(datum['faces'])
            for expected,proof in zip(chosen,r['source_face_proofs']):
                assert all(proof[n]==v for n,v in expected.items());h=datum['faces'][proof['face']]['outside_halfplanes'][proof['edge']]
                if proof['stock_proof']:assert proof['dominant_requirement'] is None
                else:
                    endpoints=[F(h['bound']-h['b']*y,h['a']) for y in [lo,hi]];valid=[i for i,q in enumerate(requirements) if dominates([F(q['bound']-q['b']*y,q['a']) for y in [lo,hi]],endpoints)];assert valid and proof['dominant_requirement']==valid[0]
                faces_checked+=1
            threshold=max(thresholds,default=xmin) if side=='right' else min(thresholds,default=xmax);assert threshold==r['uniform_threshold_units1000'] and r['uniform_side_rectangle_empty']==(threshold>xmax if side=='right' else threshold<xmin)
    assert following==ymax+1;details.append({'profiles':[pa,pb],'source_case':c['index'],'all_relative_y_values_and_both_sides_verified':True,'passed':True})
    if (ordinal+1)%8==0:print({'audited_source_cases':ordinal+1,'of':80,'seconds':time.perf_counter()-start},flush=True)
assert len(seen)==len(rows)
write(OUT/'case-checks.json',details);write(OUT/'implication.json',{'compact_witness_implies_original_source_faces':True,'reverse_implication_claimed':False,'fixed_relative_x_order':False,'statement':'The chosen original profiles and actual integer relative Y select a unique complete bin. A direction flag chooses one of the two independently certified alternatives. Every retained sloping requirement is an actual rounded source edge. Exact endpoint dominance implies the chosen edge for each source face throughout the whole clipped interval; all remaining face edges hold on the full source difference box by exact corner checks. Hence each face has a satisfied original outside edge. No relative x order is imposed between nonidentical shapes. The sufficient construction may exclude original source points, so negatives do not exclude the full source family.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'ordered_profile_pairs':80,'complete_directional_pair_bins':len(rows),'relative_y_integer_values_covered_once_per_pair':covered,'retained_sloping_requirements_verified':retained,'original_source_face_implications_verified':faces_checked,'full_stock_edge_implications_verified':stock_checked,'both_x_directions_verified':True,'all_original_relative_y_values_covered':True,'reverse_equivalence_claimed':False,'audit_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
