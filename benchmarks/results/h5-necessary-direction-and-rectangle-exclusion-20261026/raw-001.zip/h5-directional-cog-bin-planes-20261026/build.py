"""Complete left/right sufficient source planes for nonidentical parts and cogs."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=ROOT/'output/h5-directional-cog-bin-planes-20261026';WIDTH=1000
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def dominates(u,v,side,lo,hi):
    sign=1 if side=='right' else -1
    return all(sign*((u['bound']-u['b']*y)*v['a']-(v['bound']-v['b']*y)*u['a'])>=0 for y in [lo,hi])
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+300
assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');bounds=spec['anchor_bounds_units1000'];cases=[c for c in spec['mutual_cases'] if profiles[c['profile_a']]['family']!='cog' and profiles[c['profile_b']]['family']=='cog'];assert len(cases)==80
paths=[SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json']+[SOURCE/'mutual'/f"{c['index']:03d}.json" for c in cases]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'profile_pairs':[[c['profile_a'],c['profile_b']] for c in cases],'relative_y_bin_width_units1000':WIDTH,'relative_y_bin_origin_units1000':0,'directions':['left','right'],'construction_limit_seconds':300,'method':'For all80 ordered bracket/cog and insert/cog source cases, derive the full actual profile stock-difference box. Cover its entire integer relative-Y interval in disjoint1mm bins anchored at zero, with both left and right alternatives per bin. For each original rounded source face, first accept any edge already true on the whole clipped stock rectangle. Otherwise choose a positive-X edge for the right alternative or a negative-X edge for the left alternative, using the least restrictive exact uniform threshold as a selection rule. Retain the sloping inequality itself. Prune only exact endpoint-dominated directional lines and record a retained implication for every original source face. No fixed x order between nonidentical parts. This is sufficient, not equivalent: source points may be excluded, so a negative cannot exclude the full source family. No solver call.'})
rows=[];face_count=total=0
for ordinal,c in enumerate(cases):
    assert time.perf_counter()<deadline
    pa,pb=c['profile_a'],c['profile_b'];aa,bb=bounds[str(pa)],bounds[str(pb)];xmin,xmax=bb[0]-aa[2],bb[2]-aa[0];ymin,ymax=bb[1]-aa[3],bb[3]-aa[1];datum=load(SOURCE/'mutual'/f"{c['index']:03d}.json")
    for k in range(ymin//WIDTH,ymax//WIDTH+1):
        assert time.perf_counter()<deadline
        lo,hi=max(ymin,k*WIDTH),min(ymax,(k+1)*WIDTH-1)
        for side in ['left','right']:
            chosen=[];unique=[];keys=set();thresholds=[]
            for f in datum['faces']:
                stock=[j for j,h in enumerate(f['outside_halfplanes']) if min(h['a']*xmin,h['a']*xmax)+min(h['b']*lo,h['b']*hi)>=h['bound']]
                if stock:chosen.append({'face':f['index'],'edge':stock[0],'stock_proof':True});continue
                options=[]
                for j,h in enumerate(f['outside_halfplanes']):
                    A,B,C=h['a'],h['b'],h['bound'];N=C-min(B*lo,B*hi)
                    if side=='right' and A>0:options.append((max(xmin,-((-N)//A)),j))
                    if side=='left' and A<0:options.append((min(xmax,N//A),j))
                assert options,(c,k,side,f['index'])
                threshold,edge=min(options,key=lambda r:(r[0] if side=='right' else -r[0],r[1]));thresholds.append(threshold);chosen.append({'face':f['index'],'edge':edge,'stock_proof':False});h=f['outside_halfplanes'][edge];key=tuple(h[n] for n in ['a','b','bound'])
                if key not in keys:keys.add(key);unique.append({'a':h['a'],'b':h['b'],'bound':h['bound'],'source_face':f['index'],'source_edge':edge})
            kept=[i for i,h in enumerate(unique) if not any(i!=j and dominates(g,h,side,lo,hi) and (not dominates(h,g,side,lo,hi) or j<i) for j,g in enumerate(unique))];requirements=[unique[i] for i in kept];proofs=[]
            for p in chosen:
                h=datum['faces'][p['face']]['outside_halfplanes'][p['edge']];dominant=None if p['stock_proof'] else next(i for i,g in enumerate(requirements) if dominates(g,h,side,lo,hi));proofs.append({**p,'dominant_requirement':dominant})
            threshold=(max(thresholds,default=xmin) if side=='right' else min(thresholds,default=xmax));empty=threshold>xmax if side=='right' else threshold<xmin
            rows.append({'profiles':[pa,pb],'source_case':c['index'],'bin':k,'side':side,'relative_y_units1000':[lo,hi],'relative_x_units1000':[xmin,xmax],'uniform_threshold_units1000':threshold,'uniform_side_rectangle_empty':empty,'unique_directional_source_edges':len(unique),'requirements':requirements,'source_face_proofs':proofs});face_count+=len(proofs);total+=len(requirements)
    if (ordinal+1)%8==0:print({'source_cases':ordinal+1,'of':80,'directional_rows':len(rows),'seconds':time.perf_counter()-start},flush=True)
write(OUT/'guards.json',rows);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'ordered_profile_pairs':80,'directional_pair_bin_rows':len(rows),'retained_sloping_requirements':total,'maximum_requirements_per_directional_bin':max(len(r['requirements']) for r in rows),'original_source_face_proofs':face_count,'unique_directional_edges_before_pruning':sum(r['unique_directional_source_edges'] for r in rows),'uniform_side_empty_rows':sum(r['uniform_side_rectangle_empty'] for r in rows),'both_x_directions_retained':True,'construction_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
