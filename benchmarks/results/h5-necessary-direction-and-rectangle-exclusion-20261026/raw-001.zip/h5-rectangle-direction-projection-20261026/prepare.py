"""Add optional inner rectangles to the necessary full-source projection."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-necessary-direction-projection-20261026';DATA=ROOT/'output/h5-inner-rectangle-data-20261026';OUT=ROOT/'output/h5-rectangle-direction-projection-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(DATA/'audit/checks.json')['passed'] and load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed']
paths=[PARENT/n for n in ['models/000.pb','inventory.json','profile-flags.json','plan.json','model-audit/checks.json','model-audit/necessity-proof.json','response-audit/checks.json','cell-selectors.json']]+[p for p in DATA.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'method':'Preserve the complete2732-variable/3582-constraint necessary projection. Add optional X/Y intervals for all98 physical/profile inner rectangles, presence exactly its profile flag. Add one global no-overlap-2D constraint over those rectangles. Inner subsets make this necessary only; no cog shape or sufficient clearance is added. All coordinates, profiles and cells remain free. New materially strengthened model gets one20solver/30shared second call after independent entire-parent equality, extension/necessity and actual import audits. Previous calls remain closed.'})
m=cp_model_pb2.CpModelProto();m.ParseFromString((PARENT/'models/000.pb').read_bytes());assert (len(m.variables),len(m.constraints))==(2732,3582);flags=load(PARENT/'profile-flags.json');allowed=load(PARENT/'inventory.json')[0]['allowed_profiles'];data={r['profile']:r for r in load(DATA/'rectangles.json')};rows=[];xs=[];ys=[]
for part in range(5):
    for p in allowed[part]:
        for r in data[p]['rectangles']:
            ids=[]
            for axis in range(2):
                ids.append(len(m.constraints));c=m.constraints.add();c.enforcement_literal.append(flags[str(part)][str(p)]);c.interval.start.vars.append(2*part+axis);c.interval.start.coeffs.append(1);c.interval.start.offset=r['bounds_units1000'][axis];c.interval.end.vars.append(2*part+axis);c.interval.end.coeffs.append(1);c.interval.end.offset=r['bounds_units1000'][axis+2];c.interval.size.offset=r['bounds_units1000'][axis+2]-r['bounds_units1000'][axis]
            xs.append(ids[0]);ys.append(ids[1]);rows.append({'part':part,'profile':p,'rectangle':r['index'],'presence':flags[str(part)][str(p)],'interval_constraints':ids,'bounds_units1000':r['bounds_units1000']})
c=m.constraints.add();c.no_overlap_2d.x_intervals.extend(xs);c.no_overlap_2d.y_intervals.extend(ys)
assert len(rows)==98 and (len(m.variables),len(m.constraints))==(2732,3779)
write(OUT/'optional-rectangles.json',rows)
for n in ['profile-flags.json','cell-selectors.json']:shutil.copyfile(PARENT/n,OUT/n)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');row={**load(PARENT/'inventory.json')[0],'constraints':len(m.constraints),'model_sha256':digest(p),'optional_inner_rectangles':98,'optional_intervals':196,'no_overlap_2d_constraints':1};write(OUT/'inventory.json',[row]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**row,'solver_calls':0});print(load(OUT/'prepared.json'))
