"""Independent unchanged-parent and complete optional-rectangle extension audit."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-rectangle-direction-projection-20261026';PARENT=ROOT/'output/h5-necessary-direction-projection-20261026';DATA=ROOT/'output/h5-inner-rectangle-data-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify all unchanged parent variables and constraints field-for-field, rebuild all196 optional intervals from audited inner subsets and exact original profile flags, then rebuild the one global2D nonoverlap. Check all fields and actual solver import/export; no solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'model-audit/necessity-proof.json')['necessary_projection_of_full_source'] and load(DATA/'audit/checks.json')['passed'] and load(DATA/'audit/implication.json')['necessary_inner_subsets']
m=proto(BASE/'models/000.pb');parent=proto(PARENT/'models/000.pb');assert {f.name for f,v in m.ListFields()}=={'variables','constraints'} and list(m.variables)==list(parent.variables) and list(m.constraints[:3582])==list(parent.constraints);ci=3582
flags=load(PARENT/'profile-flags.json');allowed=load(PARENT/'inventory.json')[0]['allowed_profiles'];rows=[];xs=[];ys=[]
for part in range(5):
    for p in allowed[part]:
        datum=next(r for r in load(DATA/'rectangles.json') if r['profile']==p)
        for r in datum['rectangles']:
            ids=[]
            for axis in range(2):
                low,high=r['bounds_units1000'][axis::2];expr=lambda offset:cp_model_pb2.LinearExpressionProto(vars=[2*part+axis],coeffs=[1],offset=offset)
                expected=cp_model_pb2.ConstraintProto(enforcement_literal=[flags[str(part)][str(p)]],interval=cp_model_pb2.IntervalConstraintProto(start=expr(low),end=expr(high),size=cp_model_pb2.LinearExpressionProto(offset=high-low)))
                assert m.constraints[ci]==expected;ids.append(ci);ci+=1
            xs.append(ids[0]);ys.append(ids[1]);rows.append({'part':part,'profile':p,'rectangle':r['index'],'presence':flags[str(part)][str(p)],'interval_constraints':ids,'bounds_units1000':r['bounds_units1000']})
assert m.constraints[ci]==cp_model_pb2.ConstraintProto(no_overlap_2d=cp_model_pb2.NoOverlap2DConstraintProto(x_intervals=xs,y_intervals=ys));ci+=1
assert ci==len(m.constraints)==3779 and len(rows)==98 and rows==load(BASE/'optional-rectangles.json')
for n in ['profile-flags.json','cell-selectors.json']:assert (BASE/n).read_bytes()==(PARENT/n).read_bytes()
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'necessity-proof.json',{'necessary_projection_of_full_source':True,'converse_claimed':False,'statement':'The entire audited necessary parent remains unchanged. Every new active rectangle is strictly contained in its chosen original filled shape. A full-source placement has disjoint filled shapes, and sibling inner rectangles are disjoint, so it satisfies global nonoverlap of all active subsets. Inactive profiles remove both corresponding intervals. Each interval start/end is the unchanged original anchor plus its audited inner bound, with exact fixed size; no new coordinate restriction is added. Thus every full-source placement extends to this model. Positives still require complete source clearance/geometry; negatives retain declared nine-original/angle/guard/grid scope.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'unchanged_parent_variables':2732,'unchanged_parent_constraints':3582,'optional_inner_rectangles':98,'optional_intervals':196,'no_overlap_2d_constraints':1,'variables':len(m.variables),'constraints':ci,'all_fields_reconstructed':True,'actual_import_export_verified':True,'necessary_projection_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
