"""Independent full reconstruction and necessity audit, without solving."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,combinations,permutations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-necessary-direction-projection-20261026';OUT=BASE/'model-audit'
SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';DATA=ROOT/'output/h5-eight-phase-band-capacity-20261026';DIR=ROOT/'output/h5-full-source-direction-bounds-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently reconstruct every variable, entire constraint proto and mapping from source stock boxes, audited full-source central rectangles, source cog spacing bounds and exact band data. Check contiguous full Y coverage and each cell-band coefficient. Exhaustively verify all bracket choice/order cases and all active cog choice/order cases. Prove omitted pair collisions relax the full source, without using any sufficient compact restriction. Verify all proto fields and actual solver import/export; no solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert all(load(f/'audit/checks.json')['passed'] for f in [SOURCE,DATA,DIR])
s=load(SOURCE/'plan.json');b=s['anchor_bounds_units1000'];allowed=[list(range(8))]*4+[[8,10]]+[[9,11,12,13,14,15,16,17]]*4
assert load(BASE/'plan.json')['allowed_profiles']==allowed
assert s['stock_bounds_rational']==load(DATA/'plan.json')['stock_bounds_rational']
assert load(SOURCE/'profiles.json')==load(ROOT/'output/h5-eight-phase-cog-screen-20261026/profiles.json')
m=cp_model_pb2.CpModelProto();m.ParseFromString((BASE/'models/000.pb').read_bytes());assert {f.name for f,v in m.ListFields()}=={'variables','constraints'};vi=ci=0
def var(name,dom):
    global vi
    v=vi;assert m.variables[v]==cp_model_pb2.IntegerVariableProto(name=name,domain=dom),v;vi+=1;return v
def check(c):
    global ci
    assert c==m.constraints[ci],ci;ci+=1
def lin(terms,low,high,enforce=()):
    ids=sorted(v for v,k in terms.items() if k);check(cp_model_pb2.ConstraintProto(linear=cp_model_pb2.LinearConstraintProto(vars=ids,coeffs=[terms[v] for v in ids],domain=[low,high]),enforcement_literal=enforce))
for i,options in enumerate(allowed):
    for axis in range(2):var(f'p{i}-'+('xy'[axis]),[min(b[str(p)][axis] for p in options),max(b[str(p)][axis+2] for p in options)])
flags={i:{p:var(f'p{i}-profile{p}',[0,1]) for p in options} for i,options in enumerate(allowed)}
assert {str(i):{str(p):v for p,v in f.items()} for i,f in flags.items()}==load(BASE/'profile-flags.json')
for i in range(9):
    lin(dict.fromkeys(flags[i].values(),1),1,1)
    for p,v in flags[i].items():
        for axis in range(2):lin({2*i+axis:1},b[str(p)][axis],b[str(p)][axis+2],[v])
for i in [0,1,2,5,6,7]:lin({2*i:1,2*(i+1):-1},-2**63,0)
lin({flags[i][p]:1 for i in range(5,9) for p in range(12,18)},1,4)
assert (vi,ci)==(84,148)
ds={r['profile']:r for r in load(DIR/'profile-bounds.json')};pairs=load(DIR/'pair-bounds.json')
assert set(ds)==set(range(9))|{10} and len(pairs)==80
assert load(DIR/'audit/implication.json')['necessary_for_all_recorded_original_profiles'] and not load(DIR/'audit/implication.json')['compact_sufficient_restriction_used']
directions={};req=[]
for a,cog in product(range(5),range(5,9)):
    v=var(f'pair-{a}-{cog}-right',[0,1]);directions[f'{a}-{cog}']=v
    for p in allowed[a]:
        d=ds[p];left,right=d['left_maximum_dx_units1000'],d['right_minimum_dx_units1000'];assert right+d['common_cog_dx_units1000']-left==d['order_contradiction_margin_units1000']>0
        assert len(d['all_cog_profile_rectangles'])==8 and all(r['rectangle_boundary_margin_mm']>0 for r in d['all_cog_profile_rectangles'])
        lin({2*a:-1,2*cog:1},-2**63,left,[flags[a][p],-v-1]);lin({2*a:-1,2*cog:1},right,2**63-1,[flags[a][p],v]);req.append({'parts':[a,cog],'profile':p,'left':left,'right':right})
for a,cog in product(range(5),range(5,8)):check(cp_model_pb2.ConstraintProto(bool_or=cp_model_pb2.BoolArgumentProto(literals=[-directions[f'{a}-{cog}']-1,directions[f'{a}-{cog+1}']])))
assert directions==load(BASE/'direction-flags.json') and req==load(BASE/'direction-requirements.json')
spacing=load(SOURCE/'audit/spacing-case-checks.json');lower={tuple(r['profiles']):r['minimum_integer_dx_units1000'] for r in spacing}
assert set(lower)==set(product(allowed[5],repeat=2)) and all(r['passed'] and r['source_rectangle_margin_mm']>0 for r in spacing);common=min(lower.values());assert all(d['common_cog_dx_units1000']==common for d in ds.values());added=[]
for a,cog in combinations(range(5,9),2):
    for pair,minimum in [(None,common)]+[(list(k),lower[k]) for k in product(allowed[a],allowed[cog])]:
        lin({2*a:-1,2*cog:1},minimum,2**63-1,[] if pair is None else [flags[a][pair[0]],flags[cog][pair[1]]]);added.append({'parts':[a,cog],'profiles':pair,'minimum_dx_units1000':minimum})
assert added==load(BASE/'spacing-constraints.json')
cells=[];groups=[];covered=0
for i,options in enumerate(allowed):
    for p in options:
        datum=load(DATA/'profiles'/f'{p:03d}.json');lo,hi=b[str(p)][1::2];assert datum['y_bounds_units1000']==[lo,hi];following=lo;ids=[]
        for ordinal,c in enumerate(datum['cells']):
            low,high=c['y_bounds_units1000'];assert c['index']==ordinal and low==following and high==min(low+999,hi);following=high+1;covered+=high-low+1
            v=var(f'p{i}-profile{p}-cell{ordinal}',[0,1]);lin({2*i+1:1},low,high,[v]);ids.append(v);cells.append({'variable':v,'part':i,'profile':p,'cell':ordinal,'y_bounds_units1000':[low,high],'demands':c['band_lower_area_units']})
        assert following==hi+1;groups.append({'part':i,'profile':p,'profile_flag':flags[i][p],'cell_flags':ids})
for g in groups:lin({g['profile_flag']:-1,**dict.fromkeys(g['cell_flags'],1)},0,0)
caps=load(DATA/'band-capacities.json');assert len(caps)==63
for band,cap in enumerate(caps):lin({r['variable']:r['demands'][band] for r in cells if r['demands'][band]!=0},-2**63,cap)
assert cells==load(BASE/'cell-selectors.json') and groups==load(BASE/'cell-groups.json')
r=load(BASE/'inventory.json')[0];assert vi==len(m.variables)==r['variables']==2732 and ci==len(m.constraints)==r['constraints']==3582 and digest(BASE/'models/000.pb')==r['model_sha256'] and r['solver_seconds']==20
assert r['originals']==[p['item'] for p in s['parts']]==[21,22,25,26,37,53,63,64,65]
symmetry={}
for family,slots in [('bracket',range(4)),('cog',range(5,9))]:
    assert len({s['parts'][i]['copy'] for i in slots})==4 and all(s['parts'][i]['family']==family for i in slots);count=0
    for chosen in product(allowed[slots.start],repeat=4):
        if family=='cog' and not any(p>=12 for p in chosen):continue
        for ranks in permutations(range(4)):
            order=sorted(range(4),key=lambda k:ranks[k]);assigned=[chosen[k] for k in order]
            assert sorted(assigned)==sorted(chosen) and all(p in allowed[i] for i,p in zip(slots,assigned));count+=1
    symmetry[family]=count
assert symmetry=={'bracket':98304,'cog':97920}
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));actual=cp_model_pb2.CpModelProto();actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==m
write(OUT/'necessity-proof.json',{'necessary_projection_of_full_source':True,'converse_claimed':False,'all_bracket_profiles_independent':True,'symmetry_cases':symmetry,'statement':'Relabel identical bracket and cog originals with their profiles in x order. Select each actual integer-Y cell; source-disjoint filled outers imply all audited band capacities. Every non-cog/cog relative point strictly between its aggregated L and R would be in an audited full-source forbidden rectangle for every stock-allowed relative Y, so assign its actual left/right branch. Right then left for consecutive cogs contradicts R+gap-L>0, proving monotonicity. Every cog gap follows from a source-specific whole-height forbidden rectangle. Remaining collisions were omitted, never strengthened; source placements extend to this model. Positives need full geometric checking; negatives concern only these nine originals, declared phases with at least one new phase, conservative guards and micrometre grid. No compact sufficient guards or prior count cuts were copied.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':vi,'constraints':ci,'direction_inequalities':len(req)*2,'monotone_clauses':15,'spacing_constraints':len(added),'cell_selectors':len(cells),'profile_cell_equalities':len(groups),'band_inequalities':63,'cell_band_coefficients_checked':len(cells)*63,'complete_profile_y_values_covered':covered,'symmetry_cases':symmetry,'all_fields_reconstructed':True,'actual_import_export_verified':True,'necessary_projection_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
