"""Verify the necessary projection call, never claim full geometry."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-necessary-direction-projection-20261026';RUN=BASE/'search';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify sole actual model/parameters/response, inventory and hard shared deadline. Positives: evaluate every variable and active constraint and record all nine original profile/coordinate/cell selections as a necessary allocation only. No full-geometry inference. Negative is only the audited necessary projection scope. UNKNOWN excludes nothing. No retry.'})
for plan in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(plan)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];proc=load(RUN/'process.json');budget=load(RUN/'budget.json');census=load(RUN/'census.json')
assert proc['exit_code']==0 and not proc['timeout'] and proc['seconds']<=30 and budget['shared_seconds']==30 and budget['deadline_perf_counter']==budget['start_perf_counter']+30 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==20 and budget['workers']==4 and budget['seed']==0
assert not census['pending_pairs'] and len(census['results'])==census['solver_calls']==len(list(RUN.rglob('opened.json')))==1
folder=RUN/'000';r=load(folder/'result.json');opened=load(folder/'opened.json');assert r==census['results'][0] and opened['maximum_calls']==r['solver_calls']==1 and r['parts']==list(range(9))
m=proto(folder/'model.pb');assert m==proto(BASE/'models/000.pb') and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=20,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'] and opened['seconds_limit']==20
resp=cp_model_pb2.CpSolverResponse();resp.ParseFromString((folder/'response.pb').read_bytes());assert cp_model_pb2.CpSolverStatus.Name(resp.status)==r['status'] and abs(resp.wall_time-r['seconds'])<.2 and r['seconds']<=r['stage_seconds'] and r['solver_soft_overshoot_seconds']==max(0,r['seconds']-20)
sol=list(resp.solution);positive=r['status'] in ['OPTIMAL','FEASIBLE'];active=0
if positive:
    assert len(sol)==len(m.variables) and sol[:18]==r['original_coordinates_units1000']
    for v,n in zip(m.variables,sol):assert any(lo<=n<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]))
    def truth(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
    for c in m.constraints:
        if not all(truth(v) for v in c.enforcement_literal):continue
        if c.WhichOneof('constraint')=='linear':n=sum(sol[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=n<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        else:assert c.WhichOneof('constraint')=='bool_or' and any(truth(v) for v in c.bool_or.literals)
        active+=1
    flags=load(BASE/'profile-flags.json');chosen=[]
    for i in range(9):
        ps=[int(p) for p,v in flags[str(i)].items() if sol[v]];assert len(ps)==1;chosen.extend(ps)
    assert any(p>=12 for p in chosen[5:]) and sol[:8:2]==sorted(sol[:8:2]) and sol[10:18:2]==sorted(sol[10:18:2])
    cells=[r for r in load(BASE/'cell-selectors.json') if sol[r['variable']]];assert len(cells)==9
    loads=[sum(r['demands'][j] for r in cells) for j in range(63)];caps=load(ROOT/'output/h5-eight-phase-band-capacity-20261026/band-capacities.json');assert all(a<=b for a,b in zip(loads,caps))
    for row in cells:
        i=row['part'];assert chosen[i]==row['profile'] and row['y_bounds_units1000'][0]<=sol[2*i+1]<=row['y_bounds_units1000'][1]
    ids=load(BASE/'inventory.json')[0]['originals'];write(OUT/'necessary-allocation.json',{'parts':[{'original':item,'profile':chosen[i],'anchor_units1000':sol[2*i:2*i+2]} for i,item in enumerate(ids)],'cells':cells,'band_loads':loads,'band_capacities':caps,'full_geometry_verified':False,'full66_target_witness':False})
else:assert r['status'] in ['INFEASIBLE','UNKNOWN'] and not sol and r['original_coordinates_units1000'] is None
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':1,'status':r['status'],'necessary_allocation':positive,'solver_seconds':r['seconds'],'shared_seconds':proc['seconds'],'shared_budget_honored':True,'soft_overrun_seconds':r['solver_soft_overshoot_seconds'],'positive_variables_checked':len(sol),'positive_active_constraints_checked':active,'full_geometry_verified':False,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
