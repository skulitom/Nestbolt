"""Necessary projection of the full eight-angle, nine-original strip family."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from itertools import product, combinations
import json, shutil, time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026'
DATA=ROOT/'output/h5-eight-phase-band-capacity-20261026'
DIR=ROOT/'output/h5-full-source-direction-bounds-20261026'
OUT=ROOT/'output/h5-necessary-direction-projection-20261026'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
for folder in [SOURCE,DATA,DIR]:assert load(folder/'audit/checks.json')['passed']
s=load(SOURCE/'plan.json');bounds=s['anchor_bounds_units1000'];allowed=[list(range(8)) for _ in range(4)]+[[8,10]]+[[9,11,12,13,14,15,16,17] for _ in range(4)]
paths=[SOURCE/n for n in ['plan.json','profiles.json','audit/checks.json','audit/spacing-case-checks.json']]+[p for folder in [DATA,DIR] for p in folder.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'allowed_profiles':allowed,'originals':[p['item'] for p in s['parts']],'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'method':'Necessary full-source projection. All four brackets may independently choose any of eight profiles; insert has both orientations and all four cogs have all eight declared phases. Sort identical bracket and cog copies together with profiles by x. Require at least one new cog phase12..17; the old two-phase branch remains separately closed. Retain conditional stock bounds, complete vertical cells and all63 band capacities. Each non-cog/cog pair has a left/right disjunction proved by full-source central forbidden rectangles, with15 necessary monotone side clauses. Add all390 full-source cog spacing bounds. Omit all remaining collision clauses; a positive is only a necessary allocation, never a geometric witness. A negative excludes only this fixed nine-original composition, declared angles, conservative guards and micrometre grid. No sufficient compact restriction, prior count exclusion, hint or fixed pose. One20solver/30shared second call after independent reconstruction and actual import audit.'})
m=cp_model_pb2.CpModelProto();flags={}
def var(name,dom):
    i=len(m.variables);m.variables.add(name=name,domain=dom);return i
def lin(terms,lo,hi,enforce=()):
    c=m.constraints.add();ids=sorted(i for i,k in terms.items() if k);c.linear.vars.extend(ids);c.linear.coeffs.extend(terms[i] for i in ids);c.linear.domain.extend([lo,hi]);c.enforcement_literal.extend(enforce)
for i,options in enumerate(allowed):
    for axis in range(2):var(f'p{i}-'+('xy'[axis]),[min(bounds[str(p)][axis] for p in options),max(bounds[str(p)][axis+2] for p in options)])
for i,options in enumerate(allowed):flags[i]={p:var(f'p{i}-profile{p}',[0,1]) for p in options}
for i in range(9):
    lin(dict.fromkeys(flags[i].values(),1),1,1)
    for p,v in flags[i].items():
        for axis in range(2):lin({2*i+axis:1},bounds[str(p)][axis],bounds[str(p)][axis+2],[v])
for i in [0,1,2,5,6,7]:lin({2*i:1,2*(i+1):-1},-2**63,0)
lin({flags[i][p]:1 for i in range(5,9) for p in range(12,18)},1,4)
assert (len(m.variables),len(m.constraints))==(84,148)
directions={};dmap={r['profile']:r for r in load(DIR/'profile-bounds.json')};requirements=[]
for a,b in product(range(5),range(5,9)):
    v=var(f'pair-{a}-{b}-right',[0,1]);directions[f'{a}-{b}']=v
    for p in allowed[a]:
        r=dmap[p];left,right=r['left_maximum_dx_units1000'],r['right_minimum_dx_units1000']
        lin({2*a:-1,2*b:1},-2**63,left,[flags[a][p],-v-1]);lin({2*a:-1,2*b:1},right,2**63-1,[flags[a][p],v]);requirements.append({'parts':[a,b],'profile':p,'left':left,'right':right})
for a,b in product(range(5),range(5,8)):m.constraints.add().bool_or.literals.extend([-directions[f'{a}-{b}']-1,directions[f'{a}-{b+1}']])
spacing=load(SOURCE/'audit/spacing-case-checks.json');lower={tuple(r['profiles']):r['minimum_integer_dx_units1000'] for r in spacing};common=min(lower.values());added=[]
for a,b in combinations(range(5,9),2):
    for pair,minimum in [(None,common)]+[(list(k),lower[k]) for k in product(allowed[a],allowed[b])]:
        lin({2*a:-1,2*b:1},minimum,2**63-1,[] if pair is None else [flags[a][pair[0]],flags[b][pair[1]]]);added.append({'parts':[a,b],'profiles':pair,'minimum_dx_units1000':minimum})
selectors=[];groups=[]
for i,options in enumerate(allowed):
    for p in options:
        ids=[]
        for cell in load(DATA/'profiles'/f'{p:03d}.json')['cells']:
            v=var(f'p{i}-profile{p}-cell{cell["index"]}',[0,1]);lin({2*i+1:1},*cell['y_bounds_units1000'],[v]);ids.append(v);selectors.append({'variable':v,'part':i,'profile':p,'cell':cell['index'],'y_bounds_units1000':cell['y_bounds_units1000'],'demands':cell['band_lower_area_units']})
        groups.append({'part':i,'profile':p,'profile_flag':flags[i][p],'cell_flags':ids})
for g in groups:lin({g['profile_flag']:-1,**dict.fromkeys(g['cell_flags'],1)},0,0)
for b,cap in enumerate(load(DATA/'band-capacities.json')):lin({r['variable']:r['demands'][b] for r in selectors},-2**63,cap)
assert (len(m.variables),len(m.constraints))==(2732,3582)
for n,v in [('profile-flags.json',flags),('direction-flags.json',directions),('direction-requirements.json',requirements),('spacing-constraints.json',added),('cell-selectors.json',selectors),('cell-groups.json',groups)]:write(OUT/n,v)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
row={'index':0,'parts':list(range(9)),'originals':[p['item'] for p in s['parts']],'allowed_profiles':allowed,'variables':len(m.variables),'constraints':len(m.constraints),'solver_seconds':20,'model_sha256':digest(p),'direction_flags':20,'direction_inequalities':272,'monotone_clauses':15,'cell_selectors':len(selectors),'profile_cell_equalities':len(groups),'band_inequalities':63,'spacing_constraints':len(added)}
write(OUT/'inventory.json',[row]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**row,'solver_calls':0});print(load(OUT/'prepared.json'))
