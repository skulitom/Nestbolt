"""Verify exact full-source restoration and complete selected-count identity freedom."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,permutations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-capacity-phase-mix-probe-20261026';PARENT=ROOT/'output/h5-relative-y-spacing-probe-20261026';CAP=ROOT/'output/h5-eight-phase-band-search-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Restore the entire full source parent proto by removing only the eight added count equalities. Require exact copies of every source mapping, flags, full band cells and valid spacing records, plus original parent source-extension proof. Reconstruct phase counts directly from the audited capacity allocation and each added equality from actual original choice flags. Enumerate all4096 possible ordered phase assignments to prove precisely the four three9/one15 patterns remain; check all24 original identity orders for each. Both insert choices and all bracket mirrors remain unchanged. Prove equivalence only to the declared original-source count subfamily, no global negative transfer. Actual import/export, no solving.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
for p in [PARENT/'model-audit/checks.json',PARENT/'response-audit/checks.json',CAP/'audit/checks.json',SOURCE/'audit/checks.json']:assert load(p)['passed']
assert load(PARENT/'model-audit/extension-proof.json')['equivalent_source_coordinate_feasibility'] and load(PARENT/'search/000/result.json')['status']=='UNKNOWN'
parent=proto(PARENT/'models/000.pb');m=proto(BASE/'models/000.pb');assert (len(parent.variables),len(parent.constraints))==(233773,253589);restored=cp_model_pb2.CpModelProto();restored.CopyFrom(m);del restored.constraints[253589:];assert restored==parent
for n in ['models/000-mapping.json','profile-flags.json','shared-planes.json','cell-selectors.json','cell-groups.json','spacing-constraints.json','relative-y-selectors.json','relative-y-constraints.json']:assert (BASE/n).read_bytes()==(PARENT/n).read_bytes()
s=load(SOURCE/'plan.json');assert s['allowed_profiles'][:5]==[[0,4],[2,6],[1,7],[3,5],[8,10]];phases=s['allowed_profiles'][5];assert s['allowed_profiles'][5:]==[phases]*4;allocation=load(CAP/'allocation.json');counts={str(pi):sum(r['count'] for r in allocation if r['profile']==pi) for pi in phases};assert counts==load(BASE/'cog-profile-counts.json')=={'9':3,'11':0,'12':0,'13':0,'14':0,'15':1,'16':0,'17':0};flags=load(BASE/'profile-flags.json')
for offset,pi in enumerate(phases):
    c=cp_model_pb2.ConstraintProto();c.linear.vars.extend(flags[str(i)][str(pi)] for i in range(5,9));c.linear.coeffs.extend([1]*4);c.linear.domain.extend([counts[str(pi)]]*2);assert c==m.constraints[253589+offset]
accepted=[];identity_cases=0
for chosen in product(phases,repeat=4):
    valid=all(chosen.count(pi)==counts[str(pi)] for pi in phases);assert valid==(chosen.count(9)==3 and chosen.count(15)==1)
    if not valid:continue
    accepted.append(chosen)
    for ranks in permutations(range(4)):
        ordered=[chosen[i] for i in sorted(range(4),key=lambda i:ranks[i])];assert ordered.count(9)==3 and ordered.count(15)==1 and all(p in s['allowed_profiles'][5+i] for i,p in enumerate(ordered));identity_cases+=1
assert len(accepted)==4 and identity_cases==96 and len(m.variables)==233773 and len(m.constraints)==253597
record={**load(PARENT/'inventory.json')[0],'constraints':253597,'model_sha256':digest(BASE/'models/000.pb'),'cog_profile_count_equalities':8,'cog_profile_counts':counts};assert load(BASE/'inventory.json')==[record]
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb')) and proto(OUT/'roundtrip.pb')==m
write(OUT/'scope-proof.json',{'equivalent_to_declared_full_source_count_subfamily':True,'all_cog_identity_orders_preserved':True,'coordinate_or_cell_locks':False,'compact_sufficient_geometry_copied':False,'statement':'Exact restoration proves every original full-source clause and valid implication remains. The only additions fix cog profile totals to the audited selected counts. All four ordered assignments and every original cog relabelling remain represented. Every guarded/grid source layout with one bracket in each declared mirror group, either insert orientation and precisely three profile9 plus one profile15 cogs extends to this model, and every model solution has those counts. Any negative is limited to that full-source subfamily and does not exclude other cog counts, bracket group compositions or native continuous layouts.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':233773,'constraints':253597,'exact_full_source_parent_restoration':True,'count_equalities_verified':8,'ordered_phase_assignments_checked':4096,'accepted_phase_assignments':4,'cog_identity_order_cases':96,'both_insert_choices_and_all_bracket_mirrors_preserved':True,'no_coordinate_cell_locks':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
