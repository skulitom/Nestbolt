"""Read-only necessary allocation inspection and inner rectangular source subsets."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import combinations
import json,shutil,time
from shapely.geometry import Polygon,box,Point
from shapely.affinity import translate
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';PARENT=ROOT/'output/h5-necessary-direction-projection-20261026';OUT=ROOT/'output/h5-inner-rectangle-data-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();paths=[SOURCE/'profiles.json',SOURCE/'audit/checks.json',PARENT/'response-audit/checks.json',PARENT/'response-audit/necessary-allocation.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'geometry_seconds':30,'audit_seconds':30,'method':'For each eight-bracket/two-insert profile, form the Cartesian grid of rounded original vertex coordinates at micrometre scale, retaining cells whose centre lies in the original filled outer. Inset each grid cell by1micrometre on each side. Prove every resulting rectangle is covered by the actual original polygon. They are inner subsets only, so forbidding their overlap is necessary and does not enforce source clearance. Record geometric collisions in the prior necessary allocation. No solving or full-layout claim.'})
profiles=load(SOURCE/'profiles.json');rows=[]
for p in profiles:
    if p['family']=='cog':continue
    shape=Polygon(p['vertices']);levels=[sorted(set(round(v[axis]*1000) for v in p['vertices'])) for axis in range(2)];rects=[]
    for xl,xh in zip(levels[0],levels[0][1:]):
        for yl,yh in zip(levels[1],levels[1][1:]):
            if not shape.contains(Point((xl+xh)/2000,(yl+yh)/2000)):continue
            bounds=[xl+1,yl+1,xh-1,yh-1];r=box(*(v/1000 for v in bounds));assert shape.covers(r) and r.area>0;rects.append({'index':len(rects),'bounds_units1000':bounds,'area_mm2':r.area,'source_boundary_margin_mm':r.distance(shape.boundary)})
    assert len(rects)==(3 if p['family']=='bracket' else 1);rows.append({'profile':p['index'],'family':p['family'],'rectangles':rects,'original_filled_area_mm2':shape.area,'inner_rectangle_area_mm2':sum(r['area_mm2'] for r in rects)})
write(OUT/'rectangles.json',rows)
parts=load(PARENT/'response-audit/necessary-allocation.json')['parts'];shapes=[translate(Polygon(profiles[r['profile']]['vertices']),*(v/1000 for v in r['anchor_units1000'])) for r in parts];pairs=[]
for a,b in combinations(range(9),2):pairs.append({'originals':[parts[a]['original'],parts[b]['original']],'overlap_area_mm2':shapes[a].intersection(shapes[b]).area,'distance_mm':shapes[a].distance(shapes[b])})
write(OUT/'prior-allocation-pairs.json',pairs);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'profiles':len(rows),'inner_rectangles':sum(len(r['rectangles']) for r in rows),'prior_overlapping_pairs':sum(r['overlap_area_mm2']>1e-8 for r in pairs),'prior_full_geometry_valid':False,'solver_calls':0});print(load(OUT/'result.json'))
