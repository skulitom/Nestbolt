"""Independent geometry containment checks for every inner source rectangle."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,combinations
import json,shutil,time
from shapely.geometry import Polygon,box,Point
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-inner-rectangle-data-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently reconstruct rounded source coordinate cells; check each source vertex within1e-6micrometre of its grid line, all retained inner rectangle corners/interiors and positive whole-boundary margins. Check pairwise rectangle interior disjointness and area accounting. No outer expansion or sufficient clearance is imposed. Verify every source profile has its own full recorded subset.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h
profiles=load(SOURCE/'profiles.json');rows=load(BASE/'rectangles.json');assert [r['profile'] for r in rows]==[0,1,2,3,4,5,6,7,8,10];count=0;minimum=1
for row in rows:
    p=profiles[row['profile']];shape=Polygon(p['vertices']);levels=[]
    for axis in range(2):
        for v in p['vertices']:assert abs(v[axis]*1000-round(v[axis]*1000))<1e-6
        levels.append(sorted({round(v[axis]*1000) for v in p['vertices']}))
    expected=[]
    for xl,xh in zip(levels[0],levels[0][1:]):
        for yl,yh in zip(levels[1],levels[1][1:]):
            if shape.contains(Point((xl+xh)/2000,(yl+yh)/2000)):expected.append([xl+1,yl+1,xh-1,yh-1])
    assert expected==[r['bounds_units1000'] for r in row['rectangles']];boxes=[]
    for j,r in enumerate(row['rectangles']):
        assert r['index']==j;lo,bot,hi,top=r['bounds_units1000'];rect=box(lo/1000,bot/1000,hi/1000,top/1000)
        assert all(shape.contains(Point(x/1000,y/1000)) for x,y in product([lo,hi],[bot,top]));assert shape.contains(rect) and rect.distance(shape.boundary)>.00099999
        assert abs(rect.area-(hi-lo)*(top-bot)/1e6)<1e-8 and abs(rect.area-r['area_mm2'])<1e-8;boxes.append(rect);count+=1;minimum=min(minimum,rect.distance(shape.boundary))
    assert all(a.intersection(b).area==0 for a,b in combinations(boxes,2));union=unary_union(boxes);assert shape.covers(union) and abs(union.area-row['inner_rectangle_area_mm2'])<1e-8 and 0<shape.area-union.area<3
elapsed=time.perf_counter()-start;assert elapsed<30
write(OUT/'implication.json',{'necessary_inner_subsets':True,'equivalent_full_geometry':False,'statement':'Every active rectangle is a strictly interior subset of its selected original filled shape. A placement of disjoint original filled shapes therefore has disjoint active inner rectangles. Optional interval presence is exactly the profile flag. Sibling rectangles have disjoint interiors. The1micrometre insets weaken constraints; no extra clearance is added. Cog collisions and remaining source geometry still require later checks.'})
write(OUT/'checks.json',{'passed':True,'seconds':elapsed,'source_profiles':len(rows),'inner_rectangles_verified':count,'minimum_boundary_margin_mm':minimum,'necessary_subset_implication_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
