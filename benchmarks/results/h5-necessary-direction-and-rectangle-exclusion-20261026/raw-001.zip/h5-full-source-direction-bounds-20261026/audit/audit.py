"""Independently verify original-source central forbidden rectangles and side ordering."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,math,shutil,time
from shapely.geometry import box,shape
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-full-source-direction-bounds-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rings(g):
    for p in [g] if g.geom_type=='Polygon' else g.geoms:
        yield p.exterior
        yield from p.interiors
def extremes(g,y):
    values=[]
    for ring in rings(g):
        xy=list(ring.coords)
        for (x0,y0),(x1,y1) in zip(xy,xy[1:]):
            if y0==y1:
                if y==y0:values.extend([x0,x1])
            elif min(y0,y1)<=y<=max(y0,y1):values.append(x0+(x1-x0)*(y-y0)/(y1-y0))
    assert values;return min(values),max(values)
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();deadline=start+240
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()},'audit_limit_seconds':240,'method':'Reconstruct all80 required original profile pairs and full stock-relative Y intervals. Independently use analytic boundary-segment interpolation to verify every sampled extreme, then separately verify strict whole-central-rectangle containment in the actual audited source obstacle. Recompute each integer disjunction threshold and profile-wise conservative aggregation, checking every aggregated rectangle independently. Verify the common cog spacing and exact positive contradiction margins proving monotone side flags for x-sorted cogs. This is a necessary full-source implication for all original profiles, not a sufficient compact restriction; no solver.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SOURCE/'audit/checks.json')['passed'] and load(BASE/'result.json')['passed_construction'];s=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');bounds=s['anchor_bounds_units1000'];phases=s['allowed_profiles'][5];pa_values=list(range(8))+[8,10];rows=load(BASE/'pair-bounds.json');assert {tuple(r['profiles']) for r in rows}==set(product(pa_values,phases)) and len(rows)==80
geoms={};samples=0
for r in rows:
    assert time.perf_counter()<deadline
    pa,pb=r['profiles'];c=next(c for c in s['mutual_cases'] if [c['profile_a'],c['profile_b']]==[pa,pb]);assert c['index']==r['source_case'];g=shape(load(SOURCE/'mutual'/f"{c['index']:03d}.json")['expanded_forbidden']);geoms[pa,pb]=g;aa,bb=bounds[str(pa)],bounds[str(pb)];lo,hi=bb[1]-aa[3],bb[3]-aa[1];assert r['relative_y_units1000']==[lo,hi]
    ys=sorted({lo/1000,hi/1000}|{y for ring in rings(g) for x,y in ring.coords if lo/1000<=y<=hi/1000});assert ys==[v['y_mm'] for v in r['samples']]
    for sample in r['samples']:
        L,R=extremes(g,sample['y_mm']);assert abs(L-sample['left_mm'])<1e-7 and abs(R-sample['right_mm'])<1e-7;samples+=1
    L=math.ceil(max(v['left_mm'] for v in r['samples'])*1000);R=math.floor(min(v['right_mm'] for v in r['samples'])*1000);assert L==r['left_maximum_dx_units1000'] and R==r['right_minimum_dx_units1000'] and R>L+1;rect=box((L+1)/1000,lo/1000,(R-1)/1000,hi/1000);assert rect.equals(shape(r['forbidden_rectangle'])) and g.contains(rect) and g.boundary.distance(rect)>1e-8 and r['rectangle_contained'] and abs(g.boundary.distance(rect)-r['boundary_margin_mm'])<1e-10
spacing=load(SOURCE/'audit/spacing-case-checks.json');assert {tuple(r['profiles']) for r in spacing}==set(product(phases,repeat=2)) and all(r['passed'] for r in spacing);common=min(r['minimum_integer_dx_units1000'] for r in spacing);groups=load(BASE/'profile-bounds.json');assert [r['profile'] for r in groups]==sorted(pa_values);aggregate_checks=0
for row in groups:
    selected=[r for r in rows if r['profiles'][0]==row['profile']];L=max(r['left_maximum_dx_units1000'] for r in selected);R=min(r['right_minimum_dx_units1000'] for r in selected);assert row['left_maximum_dx_units1000']==L and row['right_minimum_dx_units1000']==R and row['common_cog_dx_units1000']==common and row['order_contradiction_margin_units1000']==R+common-L>0;proofs=[]
    for r in selected:
        lo,hi=r['relative_y_units1000'];g=geoms[tuple(r['profiles'])];rect=box((L+1)/1000,lo/1000,(R-1)/1000,hi/1000);assert g.contains(rect) and g.boundary.distance(rect)>1e-8;proofs.append({'profiles':r['profiles'],'rectangle_boundary_margin_mm':g.boundary.distance(rect)});aggregate_checks+=1
    assert proofs==row['all_cog_profile_rectangles']
write(OUT/'implication.json',{'necessary_for_all_recorded_original_profiles':True,'compact_sufficient_restriction_used':False,'statement':'All integer relative X values strictly between L and R and all stock-allowed relative Y lie in a proved forbidden source rectangle. A valid source pair therefore satisfies dx<=L or dx>=R. Taking the largest L and smallest R over cog choices weakens that implication and remains necessary for each fixed non-cog profile. Assign a side flag according to its actual valid branch. For adjacent x-ordered cogs, right then left would imply dx_second-dx_first<=L-R, contradicting the proved minimum cog gap because R+gap-L>0. Thus monotone flags add no restriction. All eight bracket profiles, both insert orientations and all eight cog phases are covered. The source guards and micrometre stock grid remain the scope.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_pair_rectangles_verified':80,'aggregate_profile_rectangles_verified':aggregate_checks,'non_cog_profiles':10,'analytic_boundary_samples_checked':samples,'common_cog_dx_units1000':common,'minimum_order_contradiction_margin_units1000':min(r['order_contradiction_margin_units1000'] for r in groups),'necessary_full_source_disjunctions_verified':True,'monotone_side_flags_necessary':True,'audit_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
