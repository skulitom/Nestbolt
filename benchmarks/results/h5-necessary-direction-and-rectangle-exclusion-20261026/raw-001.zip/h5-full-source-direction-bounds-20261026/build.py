"""Certify central forbidden rectangles for original nonidentical-part/cog source pairs."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,math,shutil,time
from shapely.geometry import LineString,box,shape,mapping
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=ROOT/'output/h5-full-source-direction-bounds-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def rings(g):
    for p in [g] if g.geom_type=='Polygon' else g.geoms:
        yield p.exterior
        yield from p.interiors
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();deadline=start+240
assert load(SOURCE/'audit/checks.json')['passed'];spec=load(SOURCE/'plan.json');profiles=load(SOURCE/'profiles.json');bounds=spec['anchor_bounds_units1000'];cases=[c for c in spec['mutual_cases'] if profiles[c['profile_a']]['family']!='cog' and profiles[c['profile_b']]['family']=='cog'];assert len(cases)==80
paths=[SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json',SOURCE/'audit/spacing-case-checks.json']+[SOURCE/'mutual'/f"{c['index']:03d}.json" for c in cases]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'construction_limit_seconds':240,'method':'For each of80 original bracket/cog and insert/cog source cases, screen extreme horizontal boundary intersections at every guarded vertex height and full stock-relative Y endpoints. Define integer L=ceil(maximum left boundary*1000), R=floor(minimum right boundary*1000). Separately prove the entire central rectangle X=(L+1)..(R-1), Y=full relative interval lies strictly within the actual source guarded obstacle. Whole-rectangle containment, not samples, proves every valid integer source difference satisfies dx<=L or dx>=R. Aggregate L upward and R downward across all eight cog profiles for each fixed non-cog profile, and separately verify every resulting smaller rectangle. Together with the proven common cog spacing, a right-side cog cannot precede a left-side cog in x order. These are necessary original-source implications, with no compact geometry restriction. No solver.'})
rows=[];geometry={}
for c in cases:
    assert time.perf_counter()<deadline
    pa,pb=c['profile_a'],c['profile_b'];aa,bb=bounds[str(pa)],bounds[str(pb)];lo,hi=bb[1]-aa[3],bb[3]-aa[1];g=shape(load(SOURCE/'mutual'/f"{c['index']:03d}.json")['expanded_forbidden']);geometry[pa,pb]=g
    ys=sorted({lo/1000,hi/1000}|{y for ring in rings(g) for x,y in ring.coords if lo/1000<=y<=hi/1000});samples=[]
    for y in ys:
        cut=g.intersection(LineString([(-3000,y),(3000,y)]));assert not cut.is_empty;samples.append({'y_mm':y,'left_mm':cut.bounds[0],'right_mm':cut.bounds[2]})
    L=math.ceil(max(r['left_mm'] for r in samples)*1000);R=math.floor(min(r['right_mm'] for r in samples)*1000);assert R>L+1;rectangle=box((L+1)/1000,lo/1000,(R-1)/1000,hi/1000);margin=g.boundary.distance(rectangle);contained=g.contains(rectangle) and margin>1e-8
    rows.append({'profiles':[pa,pb],'source_case':c['index'],'relative_y_units1000':[lo,hi],'samples':samples,'left_maximum_dx_units1000':L,'right_minimum_dx_units1000':R,'forbidden_rectangle':mapping(rectangle),'rectangle_contained':contained,'boundary_margin_mm':margin})
write(OUT/'pair-bounds.json',rows)
if not all(r['rectangle_contained'] for r in rows):
    write(OUT/'result.json',{'seconds':time.perf_counter()-start,'passed_construction':False,'failed_pairs':[r['profiles'] for r in rows if not r['rectangle_contained']],'solver_calls':0});print(load(OUT/'result.json'));raise SystemExit(0)
common=min(r['minimum_integer_dx_units1000'] for r in load(SOURCE/'audit/spacing-case-checks.json'));groups=[]
for pa in sorted({r['profiles'][0] for r in rows}):
    selected=[r for r in rows if r['profiles'][0]==pa];L=max(r['left_maximum_dx_units1000'] for r in selected);R=min(r['right_minimum_dx_units1000'] for r in selected);assert R>L+1;proofs=[]
    for row in selected:
        lo,hi=row['relative_y_units1000'];g=geometry[tuple(row['profiles'])];rect=box((L+1)/1000,lo/1000,(R-1)/1000,hi/1000);assert g.contains(rect) and g.boundary.distance(rect)>1e-8;proofs.append({'profiles':row['profiles'],'rectangle_boundary_margin_mm':g.boundary.distance(rect)})
    groups.append({'profile':pa,'left_maximum_dx_units1000':L,'right_minimum_dx_units1000':R,'common_cog_dx_units1000':common,'order_contradiction_margin_units1000':R+common-L,'all_cog_profile_rectangles':proofs})
write(OUT/'profile-bounds.json',groups);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'passed_construction':True,'source_pair_rectangles':80,'aggregate_profile_rectangles':80,'non_cog_profiles':10,'minimum_pair_rectangle_margin_mm':min(r['boundary_margin_mm'] for r in rows),'minimum_order_contradiction_margin_units1000':min(r['order_contradiction_margin_units1000'] for r in groups),'all_source_geometry_necessary':True,'construction_budget_honored':time.perf_counter()<deadline,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'));print([{k:v for k,v in r.items() if k!='all_cog_profile_rectangles'} for r in groups])
