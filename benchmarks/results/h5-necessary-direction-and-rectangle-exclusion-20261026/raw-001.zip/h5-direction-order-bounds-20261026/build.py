"""Project directional source requirements to prove valid ordering of side flags."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];DATA=ROOT/'output/h5-directional-cog-bin-planes-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=ROOT/'output/h5-direction-order-bounds-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();assert load(DATA/'audit/checks.json')['passed'] and load(SOURCE/'audit/checks.json')['passed']
paths=[DATA/'plan.json',DATA/'guards.json',DATA/'audit/checks.json',SOURCE/'plan.json',SOURCE/'audit/checks.json',SOURCE/'audit/spacing-case-checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'For every directional profile/bin branch derive a necessary lowerX on a right branch as the maximum of each positive-X plane minimum over its full Y interval and the stock lowerX. On a left branch derive a necessary upperX as the minimum of each negative-X plane maximum and stock upperX. Round outward for integer coordinates. Aggregate over all cog profiles and all bins separately for each fixed non-cog profile. If right-minimum plus the independently proved common adjacent-cog spacing exceeds left-maximum, an earlier x-sorted cog cannot be on the right while a later adjacent cog is on the left. This proves monotone right-side Booleans for that original non-cog profile without imposing a new geometric restriction. Check all allowed profiles before adding any unconditional order clause. No solver.'})
rows=load(DATA/'guards.json');spacing=load(SOURCE/'audit/spacing-case-checks.json');common=min(r['minimum_integer_dx_units1000'] for r in spacing);projections=[]
for r in rows:
    lo,hi=r['relative_y_units1000'];xmin,xmax=r['relative_x_units1000'];values=[[F(h['bound']-h['b']*y,h['a']) for y in [lo,hi]] for h in r['requirements']]
    if r['side']=='right':assert all(h['a']>0 for h in r['requirements']);bound=math.ceil(max([F(xmin)]+[min(v) for v in values]))
    else:assert all(h['a']<0 for h in r['requirements']);bound=math.floor(min([F(xmax)]+[max(v) for v in values]))
    projections.append({'profiles':r['profiles'],'bin':r['bin'],'side':r['side'],'necessary_x_bound_units1000':bound})
summaries=[]
for pa in sorted({r['profiles'][0] for r in rows}):
    lower=min(r['necessary_x_bound_units1000'] for r in projections if r['profiles'][0]==pa and r['side']=='right');upper=max(r['necessary_x_bound_units1000'] for r in projections if r['profiles'][0]==pa and r['side']=='left');margin=lower+common-upper
    summaries.append({'profile':pa,'right_minimum_dx_units1000':lower,'left_maximum_dx_units1000':upper,'common_cog_dx_units1000':common,'contradiction_margin_units1000':margin,'monotone_side_order_proved':margin>0})
write(OUT/'projections.json',projections);write(OUT/'profile-bounds.json',summaries);write(OUT/'result.json',{'seconds':time.perf_counter()-start,'directional_rows':len(projections),'non_cog_profiles':len(summaries),'common_cog_dx_units1000':common,'all_profile_side_orders_proved':all(r['monotone_side_order_proved'] for r in summaries),'minimum_contradiction_margin_units1000':min(r['contradiction_margin_units1000'] for r in summaries),'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'));print(summaries)
