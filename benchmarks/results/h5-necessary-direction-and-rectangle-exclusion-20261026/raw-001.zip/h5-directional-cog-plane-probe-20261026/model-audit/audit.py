"""Independently reconstruct every retained field and prove safe compact substitution."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
from itertools import product
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-directional-cog-plane-probe-20261026';PARENT=ROOT/'output/h5-compact-cog-plane-probe-20261026';DATA=ROOT/'output/h5-directional-cog-bin-planes-20261026';OUT=BASE/'model-audit'
SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently derive exactly79704 removed bracket/cog and insert/cog shared plane flags, reconstruct their source implications and2384 face clauses, and retain every other parent field by exact index remapping. Rebuild each of20 physical pairs with a right-vs-left Boolean and complete1mm relative-Y bins derived from full union stock domains. Verify every allowed phase pair and every clipped bin/side is represented, then reconstruct all62944 sloping source-plane requirements. Keep prior compact cog requirements, all original count/stock/angle/band constraints and all bracket/bracket and bracket/insert source clauses. Require whole-proto equality, actual import/export and forward source implication; no fixed x order for nonidentical shapes and no reverse equivalence.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'] and load(PARENT/'search/000/result.json')['status']=='UNKNOWN' and load(DATA/'audit/checks.json')['passed']
parent=proto(PARENT/'models/000.pb');actual=proto(BASE/'models/000.pb');assert {f.name for f,v in parent.ListFields()}=={'variables','constraints'};planes=load(PARENT/'shared-planes.json');maps=load(PARENT/'models/000-mapping.json');dropped_vars={r['flag'] for r in planes if r['parts'][0]<5 and r['parts'][1]>=5};assert len(dropped_vars)==79704
remove_linear=Counter();remove_or=Counter()
for row in planes:
    if row['flag'] not in dropped_vars:continue
    a,b=row['parts'];terms={2*a:-row['a'],2*a+1:-row['b'],2*b:row['a'],2*b+1:row['b']};ids=sorted(v for v,k in terms.items() if k);c=cp_model_pb2.ConstraintProto();c.enforcement_literal.append(row['flag']);c.linear.vars.extend(ids);c.linear.coeffs.extend(terms[v] for v in ids);c.linear.domain.extend([row['bound'],2**63-1]);remove_linear[c.SerializeToString()]+=1
for mode in maps:
    if not (mode['parts'][0]<5 and mode['parts'][1]>=5):continue
    for face in mode['faces']:
        if face.get('tautological'):continue
        assert all(v in dropped_vars for v in face['shared_flags']);c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-v-1 for v in mode['active']]+face['shared_flags']);remove_or[c.SerializeToString()]+=1
assert sum(remove_linear.values())==79704 and sum(remove_or.values())==2384
expected=cp_model_pb2.CpModelProto();kept_vars=[i for i in range(len(parent.variables)) if i not in dropped_vars];mapping={old:new for new,old in enumerate(kept_vars)};remap=[mapping.get(i,-1) for i in range(len(parent.variables))]
for old in kept_vars:expected.variables.add().CopyFrom(parent.variables[old])
def literal(v):
    return mapping[v] if v>=0 else -mapping[-v-1]-1
kept_constraints=[];dropped=[]
for ordinal,c in enumerate(parent.constraints):
    raw=c.SerializeToString()
    if remove_linear[raw]:remove_linear[raw]-=1;dropped.append({'parent_constraint':ordinal,'kind':'directional-plane'});continue
    if remove_or[raw]:remove_or[raw]-=1;dropped.append({'parent_constraint':ordinal,'kind':'directional-face'});continue
    kept_constraints.append(ordinal);new=expected.constraints.add();new.CopyFrom(c);new.enforcement_literal[:]=[literal(v) for v in c.enforcement_literal]
    if c.WhichOneof('constraint')=='linear':new.linear.vars[:]=[mapping[v] for v in c.linear.vars]
    else:assert c.WhichOneof('constraint')=='bool_or';new.bool_or.literals[:]=[literal(v) for v in c.bool_or.literals]
assert not +remove_linear and not +remove_or and (len(expected.variables),len(expected.constraints))==(5995,21063)
for name,value in [('variable-remap.json',remap),('kept-parent-variables.json',kept_vars),('kept-parent-constraints.json',kept_constraints),('dropped-parent-constraints.json',dropped)]:assert load(BASE/name)==value
flags={i:{p:mapping[v] for p,v in f.items()} for i,f in load(PARENT/'profile-flags.json').items()};assert flags==load(BASE/'profile-flags.json') and all(mapping[v]==v for f in load(PARENT/'profile-flags.json').values() for v in f.values())
retained_planes=[{**r,'flag':mapping[r['flag']]} for r in planes if r['flag'] not in dropped_vars];retained_maps=[]
for r in maps:
    if r['parts'][0]<5 and r['parts'][1]>=5:continue
    retained_maps.append({**r,'active':[mapping[v] for v in r['active']],'faces':[{**f,'shared_flags':[mapping[v] for v in f['shared_flags']]} if not f.get('tautological') else f for f in r['faces']]})
assert retained_planes==load(BASE/'shared-planes.json') and retained_maps==load(BASE/'models/000-mapping.json')
assert load(BASE/'cell-selectors.json')==[{**r,'variable':mapping[r['variable']]} for r in load(PARENT/'cell-selectors.json')]
assert load(BASE/'cell-groups.json')==[{**r,'profile_flag':mapping[r['profile_flag']],'cell_flags':[mapping[v] for v in r['cell_flags']]} for r in load(PARENT/'cell-groups.json')]
assert (BASE/'spacing-constraints.json').read_bytes()==(PARENT/'spacing-constraints.json').read_bytes()
assert load(BASE/'relative-y-selectors.json')==[{**r,'variable':mapping[r['variable']]} for r in load(PARENT/'relative-y-selectors.json')]
assert (BASE/'compact-requirements.json').read_bytes()==(PARENT/'compact-requirements.json').read_bytes()
source=load(SOURCE/'plan.json');allowed=source['allowed_profiles'];bounds=source['anchor_bounds_units1000'];rows=load(DATA/'guards.json');assert len(rows)==15680;selectors=[];requirements=[];directions={};pair_domains=[]
for a,b in product(range(5),range(5,9)):
    pair_ranges=[(bounds[str(pb)][1]-bounds[str(pa)][3],bounds[str(pb)][3]-bounds[str(pa)][1]) for pa,pb in product(allowed[a],allowed[b])];dylo=min(r[0] for r in pair_ranges);dyhi=max(r[1] for r in pair_ranges);direction=len(expected.variables);expected.variables.add(name=f'pair-{a}-{b}-right-side',domain=[0,1]);directions[f'{a}-{b}']=direction;ids={};pair_domains.append({'parts':[a,b],'relative_y_units1000':[dylo,dyhi]});following=dylo
    for k in range(dylo//1000,dyhi//1000+1):
        low,high=max(dylo,k*1000),min(dyhi,k*1000+999);assert low==following;following=high+1;v=len(expected.variables);expected.variables.add(name=f'pair-{a}-{b}-directional-y-bin{k}',domain=[0,1]);c=expected.constraints.add();c.enforcement_literal.append(v);c.linear.vars.extend([2*a+1,2*b+1]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([low,high]);ids[k]=v;selectors.append({'parts':[a,b],'bin':k,'variable':v,'relative_y_units1000':[low,high]})
    assert following==dyhi+1;c=expected.constraints.add();c.linear.vars.extend(ids.values());c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([1,1])
    selected=[r for r in rows if r['profiles'][0] in allowed[a] and r['profiles'][1] in allowed[b]]
    wanted=set()
    for pa,pb in product(allowed[a],allowed[b]):
        low,high=bounds[str(pb)][1]-bounds[str(pa)][3],bounds[str(pb)][3]-bounds[str(pa)][1]
        for k in range(low//1000,high//1000+1):
            for side in ['left','right']:wanted.add((pa,pb,k,side))
    assert {(r['profiles'][0],r['profiles'][1],r['bin'],r['side']) for r in selected}==wanted and len(selected)==len(wanted)
    for row in selected:
        pa,pb=row['profiles'];k=row['bin'];assert k in ids;low,high=bounds[str(pb)][1]-bounds[str(pa)][3],bounds[str(pb)][3]-bounds[str(pa)][1];assert row['relative_y_units1000']==[max(low,k*1000),min(high,k*1000+999)];side_literal=direction if row['side']=='right' else -direction-1
        for ordinal,h in enumerate(row['requirements']):
            assert (h['a']>0)==(row['side']=='right');coefficients={2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']};vs=sorted(v for v,k in coefficients.items() if k);c=expected.constraints.add();c.enforcement_literal.extend([flags[str(a)][str(pa)],flags[str(b)][str(pb)],ids[k],side_literal]);c.linear.vars.extend(vs);c.linear.coeffs.extend(coefficients[v] for v in vs);c.linear.domain.extend([h['bound'],2**63-1]);requirements.append({'parts':[a,b],'profiles':[pa,pb],'bin':k,'side':row['side'],'requirement':ordinal,'a':h['a'],'b':h['b'],'bound':h['bound']})
for name,value in [('direction-flags.json',directions),('directional-bin-selectors.json',selectors),('directional-requirements.json',requirements),('directional-pair-domains.json',pair_domains)]:assert load(BASE/name)==value
assert len(selectors)==2120 and len(directions)==20 and len(requirements)==62944 and expected==actual and len(actual.variables)==8135 and len(actual.constraints)==86147
old=load(PARENT/'inventory.json')[0];record={**old,'variables':8135,'constraints':86147,'model_sha256':digest(BASE/'models/000.pb'),'shared_planes':4009,'edge_uses':6043,'face_clauses':88,'tautological_faces':18,'retained_physical_modes':40,'compact_directional_physical_modes':320,'removed_shared_planes':227778,'removed_parent_shared_planes':79704,'direction_flags':20,'directional_bin_selectors':2120,'directional_exact_one_sums':20,'directional_sloping_constraints':62944,'retained_parent_variables':5995,'retained_parent_constraints':21063};assert load(BASE/'inventory.json')==[record]
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb')) and proto(OUT/'roundtrip.pb')==actual
write(OUT/'implication.json',{'compact_witness_implies_parent_and_full_source':True,'reverse_implication_claimed':False,'negative_excludes_full_source_family':False,'fixed_relative_x_order_for_nonidentical_parts':False,'statement':'Every retained parent variable and constraint is restored exactly by remapping. The actual original phase flags and stock domains place each nonidentical pair difference in a unique complete relative-Y bin; its side Boolean selects one independently proved alternative. All selected sloping requirements therefore imply every removed rounded source-face edge clause. Set removed plane flags from their actual truth values to extend the witness to the parent, whose independent proof then extends it to the complete original source. Both sides are available, and no x order is imposed between bracket/insert and cog. The sufficient restrictions need not accept every full-source witness, so a negative cannot exclude that family.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':8135,'constraints':86147,'removed_parent_plane_variables':79704,'removed_parent_face_clauses':2384,'retained_parent_variables':5995,'retained_parent_constraints':21063,'all_retained_fields_exactly_reconstructed':True,'nonidentical_direction_flags':20,'complete_directional_y_selectors':2120,'directional_sloping_constraints':62944,'both_sides_all_profiles_all_bins_verified':True,'all_original_identities_preserved':True,'compact_witness_implies_full_source':True,'reverse_equivalence_claimed':False,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
