"""Replace nonidentical-part/cog source clauses with complete bidirectional bin planes."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
from itertools import product
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-compact-cog-plane-probe-20261026';DATA=ROOT/'output/h5-directional-cog-bin-planes-20261026';SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026';OUT=ROOT/'output/h5-directional-cog-plane-probe-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def lit(v,remap):
    old=v if v>=0 else -v-1;new=remap[old];assert new>=0;return new if v>=0 else -new-1
def remapped(c,remap):
    copy=cp_model_pb2.ConstraintProto();copy.CopyFrom(c);copy.enforcement_literal[:]=[lit(v,remap) for v in c.enforcement_literal]
    if c.WhichOneof('constraint')=='linear':copy.linear.vars[:]=[remap[v] for v in c.linear.vars];assert all(v>=0 for v in copy.linear.vars)
    else:assert c.WhichOneof('constraint')=='bool_or';copy.bool_or.literals[:]=[lit(v,remap) for v in c.bool_or.literals]
    return copy
def target(parts):return parts[0]<5 and parts[1]>=5
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['passed'] and load(PARENT/'search/000/result.json')['status']=='UNKNOWN' and load(DATA/'audit/checks.json')['passed']
paths=[PARENT/n for n in ['plan.json','models/000.pb','models/000-mapping.json','profile-flags.json','shared-planes.json','cell-selectors.json','cell-groups.json','spacing-constraints.json','relative-y-selectors.json','compact-requirements.json','inventory.json','model-audit/checks.json','model-audit/implication.json','response-audit/checks.json','search/000/result.json']]+[SOURCE/'plan.json',SOURCE/'profiles.json',SOURCE/'audit/checks.json']+[p for p in DATA.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'maximum_calls':1,'solver_seconds':45,'shared_seconds':60,'workers':4,'seed':0,'method':'Remove exactly79704 shared plane flags and their implications for bracket/cog and insert/cog pairs, plus2384 corresponding full source face clauses. Retain all other parent variables and constraints with exact remapping, including compact cog/cog requirements, all original stock/count/angle/symmetry rules and all vertical-area cells. Add one right-vs-left Boolean for each of20 nonidentical physical pairs and a complete1mm relative-Y bin cover derived from its full union stock domains. Enforce each independently proved sloping source plane by both profile flags, the selected bin and the selected side. No fixed x order between nonidentical shapes. Every compact witness implies all removed source clauses and extends through the previous compact model to full source geometry. The construction is sufficient, not equivalent, so negatives cannot exclude the full source family. One45solver/60shared4worker seed0 call after full model/import audit; prior calls closed.'})
parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'models/000.pb').read_bytes());assert {f.name for f,v in parent.ListFields()}=={'variables','constraints'}
planes=load(PARENT/'shared-planes.json');maps=load(PARENT/'models/000-mapping.json');removed={r['flag'] for r in planes if target(r['parts'])};assert len(removed)==79704;counts=Counter()
for mode in maps:
    if not target(mode['parts']):continue
    for f in mode['faces']:
        if f.get('tautological'):continue
        c=cp_model_pb2.ConstraintProto();c.bool_or.literals.extend([-v-1 for v in mode['active']]+f['shared_flags']);counts[c.SerializeToString()]+=1
assert sum(counts.values())==2384
m=cp_model_pb2.CpModelProto();remap=[];kept_variables=[]
for i,v in enumerate(parent.variables):
    if i in removed:remap.append(-1)
    else:remap.append(len(m.variables));kept_variables.append(i);m.variables.add().CopyFrom(v)
kept_constraints=[];dropped=[]
for i,c in enumerate(parent.constraints):
    if c.WhichOneof('constraint')=='linear' and len(c.enforcement_literal)==1 and c.enforcement_literal[0] in removed:dropped.append({'parent_constraint':i,'kind':'directional-plane'});continue
    key=c.SerializeToString()
    if c.WhichOneof('constraint')=='bool_or' and counts[key]:counts[key]-=1;dropped.append({'parent_constraint':i,'kind':'directional-face'});continue
    kept_constraints.append(i);m.constraints.add().CopyFrom(remapped(c,remap))
assert not +counts and Counter(r['kind'] for r in dropped)=={'directional-plane':79704,'directional-face':2384};nv,nc=len(m.variables),len(m.constraints);assert (nv,nc)==(5995,21063)
flags={i:{p:remap[v] for p,v in f.items()} for i,f in load(PARENT/'profile-flags.json').items()};s=load(SOURCE/'plan.json');allowed=s['allowed_profiles'];bounds=s['anchor_bounds_units1000'];rows=load(DATA/'guards.json');selectors=[];requirements=[];directions={};pair_domains=[]
for a,b in product(range(5),range(5,9)):
    dylo=min(bounds[str(p)][1] for p in allowed[b])-max(bounds[str(p)][3] for p in allowed[a]);dyhi=max(bounds[str(p)][3] for p in allowed[b])-min(bounds[str(p)][1] for p in allowed[a]);direction=len(m.variables);m.variables.add(name=f'pair-{a}-{b}-right-side',domain=[0,1]);directions[f'{a}-{b}']=direction;ids={};pair_domains.append({'parts':[a,b],'relative_y_units1000':[dylo,dyhi]})
    for k in range(dylo//1000,dyhi//1000+1):
        low,high=max(dylo,k*1000),min(dyhi,k*1000+999);v=len(m.variables);m.variables.add(name=f'pair-{a}-{b}-directional-y-bin{k}',domain=[0,1]);c=m.constraints.add();c.enforcement_literal.append(v);c.linear.vars.extend([2*a+1,2*b+1]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([low,high]);ids[k]=v;selectors.append({'parts':[a,b],'bin':k,'variable':v,'relative_y_units1000':[low,high]})
    c=m.constraints.add();c.linear.vars.extend(ids.values());c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([1,1])
    for r in rows:
        pa,pb=r['profiles']
        if pa not in allowed[a] or pb not in allowed[b]:continue
        assert r['bin'] in ids;side_literal=direction if r['side']=='right' else -direction-1
        for j,h in enumerate(r['requirements']):
            terms={2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']};vs=sorted(v for v,k in terms.items() if k);c=m.constraints.add();c.enforcement_literal.extend([flags[str(a)][str(pa)],flags[str(b)][str(pb)],ids[r['bin']],side_literal]);c.linear.vars.extend(vs);c.linear.coeffs.extend(terms[v] for v in vs);c.linear.domain.extend([h['bound'],2**63-1]);requirements.append({'parts':[a,b],'profiles':[pa,pb],'bin':r['bin'],'side':r['side'],'requirement':j,'a':h['a'],'b':h['b'],'bound':h['bound']})
assert len(directions)==20 and len(requirements)==15736*4
for n,v in [('variable-remap.json',remap),('kept-parent-variables.json',kept_variables),('kept-parent-constraints.json',kept_constraints),('dropped-parent-constraints.json',dropped),('profile-flags.json',flags),('direction-flags.json',directions),('directional-bin-selectors.json',selectors),('directional-requirements.json',requirements),('directional-pair-domains.json',pair_domains)]:write(OUT/n,v)
kept_planes=[{**r,'flag':remap[r['flag']]} for r in planes if r['flag'] not in removed];kept_maps=[{**r,'active':[remap[v] for v in r['active']],'faces':[{**f,'shared_flags':[remap[v] for v in f['shared_flags']]} if not f.get('tautological') else f for f in r['faces']]} for r in maps if not target(r['parts'])]
write(OUT/'shared-planes.json',kept_planes);write(OUT/'models/000-mapping.json',kept_maps);write(OUT/'cell-selectors.json',[{**r,'variable':remap[r['variable']]} for r in load(PARENT/'cell-selectors.json')]);write(OUT/'cell-groups.json',[{**r,'profile_flag':remap[r['profile_flag']],'cell_flags':[remap[v] for v in r['cell_flags']]} for r in load(PARENT/'cell-groups.json')]);write(OUT/'relative-y-selectors.json',[{**r,'variable':remap[r['variable']]} for r in load(PARENT/'relative-y-selectors.json')])
for n in ['spacing-constraints.json','compact-requirements.json']:shutil.copyfile(PARENT/n,OUT/n)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
old=load(PARENT/'inventory.json')[0];record={**old,'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(p),'shared_planes':len(kept_planes),'edge_uses':sum(len(f['shared_flags']) for r in kept_maps for f in r['faces'] if not f.get('tautological')),'face_clauses':88,'tautological_faces':18,'retained_physical_modes':40,'compact_directional_physical_modes':320,'removed_shared_planes':old['removed_shared_planes']+len(removed),'removed_parent_shared_planes':len(removed),'direction_flags':20,'directional_bin_selectors':len(selectors),'directional_exact_one_sums':20,'directional_sloping_constraints':len(requirements),'retained_parent_variables':nv,'retained_parent_constraints':nc};write(OUT/'inventory.json',[record]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**record,'solver_calls':0});print(load(OUT/'prepared.json'))
