"""Prepare separate runner and full optional-rectangle response checks."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,dest in [('run_h5_necessary_direction_projection.py','run_h5_rectangle_direction_projection.py'),('audit_h5_necessary_projection_response.py','audit_h5_rectangle_projection_response.py')]:
    s=(ROOT/'output'/source).read_text().replace('h5-necessary-direction-projection-20261026','h5-rectangle-direction-projection-20261026')
    if source.startswith('audit'):
        old="        else:assert c.WhichOneof('constraint')=='bool_or' and any(truth(v) for v in c.bool_or.literals)"
        new="""        elif c.WhichOneof('constraint')=='bool_or':assert any(truth(v) for v in c.bool_or.literals)
        elif c.WhichOneof('constraint')=='interval':
            value=lambda e:e.offset+sum(sol[v]*k for v,k in zip(e.vars,e.coeffs))
            assert value(c.interval.start)+value(c.interval.size)==value(c.interval.end)
        else:
            assert c.WhichOneof('constraint')=='no_overlap_2d';rects=[]
            value=lambda e:e.offset+sum(sol[v]*k for v,k in zip(e.vars,e.coeffs))
            for xi,yi in zip(c.no_overlap_2d.x_intervals,c.no_overlap_2d.y_intervals):
                xc,yc=m.constraints[xi],m.constraints[yi];assert list(xc.enforcement_literal)==list(yc.enforcement_literal)
                if all(truth(v) for v in xc.enforcement_literal):rects.append([value(xc.interval.start),value(yc.interval.start),value(xc.interval.end),value(yc.interval.end)])
            for i,a in enumerate(rects):
                for b in rects[i+1:]:assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]"""
        assert old in s;s=s.replace(old,new)
    with (ROOT/'output'/dest).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Separate runner and response audit prepared; no call started.')
