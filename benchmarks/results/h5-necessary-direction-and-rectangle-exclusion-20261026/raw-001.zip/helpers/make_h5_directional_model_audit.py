"""Create an independent full directional-substitution audit from the prior exact-field audit."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
def rep(s,a,b):
    assert a in s,a
    return s.replace(a,b)
s=(ROOT/'output/audit_h5_compact_cog_model.py').read_text(encoding='utf-8')
s=rep(s,"BASE=ROOT/'output/h5-compact-cog-plane-probe-20261026'","BASE=ROOT/'output/h5-directional-cog-plane-probe-20261026'")
s=rep(s,"PARENT=ROOT/'output/h5-eight-phase-balanced-probe-20261026'","PARENT=ROOT/'output/h5-compact-cog-plane-probe-20261026'")
s=rep(s,"DATA=ROOT/'output/h5-compact-cog-bin-planes-20261026'","DATA=ROOT/'output/h5-directional-cog-bin-planes-20261026'")
s=rep(s,"load=lambda p:","SOURCE=ROOT/'output/h5-eight-phase-balanced-source-20261026'\nload=lambda p:")
s=rep(s,'from itertools import combinations','from itertools import product')
s=rep(s,"r['parts'][0]>=5 and r['parts'][1]>=5","r['parts'][0]<5 and r['parts'][1]>=5")
s=rep(s,"if min(mode['parts'])<5:continue","if not (mode['parts'][0]<5 and mode['parts'][1]>=5):continue")
s=rep(s,"if min(r['parts'])>=5:continue","if r['parts'][0]<5 and r['parts'][1]>=5:continue")
s=s.replace('148074','79704').replace('3660','2384').replace('85489','5995').replace('88493','21063').replace("'cog-plane'","'directional-plane'").replace("'cog-face'","'directional-face'")
a=s.index("'method':'Independently derive");b=s.index("'})",a)
s=s[:a]+"'method':'Independently derive exactly79704 removed bracket/cog and insert/cog shared plane flags, reconstruct their source implications and2384 face clauses, and retain every other parent field by exact index remapping. Rebuild each of20 physical pairs with a right-vs-left Boolean and complete1mm relative-Y bins derived from full union stock domains. Verify every allowed phase pair and every clipped bin/side is represented, then reconstruct all62944 sloping source-plane requirements. Keep prior compact cog requirements, all original count/stock/angle/band constraints and all bracket/bracket and bracket/insert source clauses. Require whole-proto equality, actual import/export and forward source implication; no fixed x order for nonidentical shapes and no reverse equivalence.'"+s[b+1:]
a=s.index("spec=load(DATA/'plan.json');rows=");b=s.index('real=cp_model.CpModel();',a)
body='''assert load(BASE/'relative-y-selectors.json')==[{**r,'variable':mapping[r['variable']]} for r in load(PARENT/'relative-y-selectors.json')]
assert (BASE/'compact-requirements.json').read_bytes()==(PARENT/'compact-requirements.json').read_bytes()
source=load(SOURCE/'plan.json');allowed=source['allowed_profiles'];bounds=source['anchor_bounds_units1000'];rows=load(DATA/'guards.json');assert len(rows)==15680;selectors=[];requirements=[];directions={};pair_domains=[]
for a,b in product(range(5),range(5,9)):
    pair_ranges=[(bounds[str(pb)][1]-bounds[str(pa)][3],bounds[str(pb)][3]-bounds[str(pa)][1]) for pa,pb in product(allowed[a],allowed[b])];dylo=min(r[0] for r in pair_ranges);dyhi=max(r[1] for r in pair_ranges);direction=len(expected.variables);expected.variables.add(name=f'pair-{a}-{b}-right-side',domain=[0,1]);directions[f'{a}-{b}']=direction;ids={};pair_domains.append({'parts':[a,b],'relative_y_units1000':[dylo,dyhi]});following=dylo
    for k in range(dylo//1000,dyhi//1000+1):
        low,high=max(dylo,k*1000),min(dyhi,k*1000+999);assert low==following;following=high+1;v=len(expected.variables);expected.variables.add(name=f'pair-{a}-{b}-directional-y-bin{k}',domain=[0,1]);c=expected.constraints.add();c.enforcement_literal.append(v);c.linear.vars.extend([2*a+1,2*b+1]);c.linear.coeffs.extend([-1,1]);c.linear.domain.extend([low,high]);ids[k]=v;selectors.append({'parts':[a,b],'bin':k,'variable':v,'relative_y_units1000':[low,high]})
    assert following==dyhi+1;c=expected.constraints.add();c.linear.vars.extend(ids.values());c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([1,1])
    selected=[r for r in rows if r['profiles'][0] in allowed[a] and r['profiles'][1] in allowed[b]]
    wanted=set()
    for pa,pb in product(allowed[a],allowed[b]):
        low,high=bounds[str(pb)][1]-bounds[str(pa)][3],bounds[str(pb)][3]-bounds[str(pa)][1]
        for k in range(low//1000,high//1000+1):
            for side in ['left','right']:wanted.add((pa,pb,k,side))
    assert {(r['profiles'][0],r['profiles'][1],r['bin'],r['side']) for r in selected}==wanted and len(selected)==len(wanted)
    for row in selected:
        pa,pb=row['profiles'];k=row['bin'];assert k in ids;low,high=bounds[str(pb)][1]-bounds[str(pa)][3],bounds[str(pb)][3]-bounds[str(pa)][1];assert row['relative_y_units1000']==[max(low,k*1000),min(high,k*1000+999)];side_literal=direction if row['side']=='right' else -direction-1
        for ordinal,h in enumerate(row['requirements']):
            assert (h['a']>0)==(row['side']=='right');coefficients={2*a:-h['a'],2*a+1:-h['b'],2*b:h['a'],2*b+1:h['b']};vs=sorted(v for v,k in coefficients.items() if k);c=expected.constraints.add();c.enforcement_literal.extend([flags[str(a)][str(pa)],flags[str(b)][str(pb)],ids[k],side_literal]);c.linear.vars.extend(vs);c.linear.coeffs.extend(coefficients[v] for v in vs);c.linear.domain.extend([h['bound'],2**63-1]);requirements.append({'parts':[a,b],'profiles':[pa,pb],'bin':k,'side':row['side'],'requirement':ordinal,'a':h['a'],'b':h['b'],'bound':h['bound']})
for name,value in [('direction-flags.json',directions),('directional-bin-selectors.json',selectors),('directional-requirements.json',requirements),('directional-pair-domains.json',pair_domains)]:assert load(BASE/name)==value
assert len(selectors)==2120 and len(directions)==20 and len(requirements)==62944 and expected==actual and len(actual.variables)==8135 and len(actual.constraints)==86147
old=load(PARENT/'inventory.json')[0];record={**old,'variables':8135,'constraints':86147,'model_sha256':digest(BASE/'models/000.pb'),'shared_planes':4009,'edge_uses':6043,'face_clauses':88,'tautological_faces':18,'retained_physical_modes':40,'compact_directional_physical_modes':320,'removed_shared_planes':227778,'removed_parent_shared_planes':79704,'direction_flags':20,'directional_bin_selectors':2120,'directional_exact_one_sums':20,'directional_sloping_constraints':62944,'retained_parent_variables':5995,'retained_parent_constraints':21063};assert load(BASE/'inventory.json')==[record]
'''
s=s[:a]+body+s[b:]
a=s.index("write(OUT/'implication.json'")
s=s[:a]+'''write(OUT/'implication.json',{'compact_witness_implies_parent_and_full_source':True,'reverse_implication_claimed':False,'negative_excludes_full_source_family':False,'fixed_relative_x_order_for_nonidentical_parts':False,'statement':'Every retained parent variable and constraint is restored exactly by remapping. The actual original phase flags and stock domains place each nonidentical pair difference in a unique complete relative-Y bin; its side Boolean selects one independently proved alternative. All selected sloping requirements therefore imply every removed rounded source-face edge clause. Set removed plane flags from their actual truth values to extend the witness to the parent, whose independent proof then extends it to the complete original source. Both sides are available, and no x order is imposed between bracket/insert and cog. The sufficient restrictions need not accept every full-source witness, so a negative cannot exclude that family.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':8135,'constraints':86147,'removed_parent_plane_variables':79704,'removed_parent_face_clauses':2384,'retained_parent_variables':5995,'retained_parent_constraints':21063,'all_retained_fields_exactly_reconstructed':True,'nonidentical_direction_flags':20,'complete_directional_y_selectors':2120,'directional_sloping_constraints':62944,'both_sides_all_profiles_all_bins_verified':True,'all_original_identities_preserved':True,'compact_witness_implies_full_source':True,'reverse_equivalence_claimed':False,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
'''
ast.parse(s)
with (ROOT/'output/audit_h5_directional_cog_model.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for name in ['run_h5_compact_cog_probe.py','audit_h5_compact_cog_response.py']:
    s=(ROOT/'output'/name).read_text(encoding='utf-8');old="BASE=ROOT/'output/h5-compact-cog-plane-probe-20261026'";assert old in s;s=s.replace(old,"BASE=ROOT/'output/h5-directional-cog-plane-probe-20261026'");ast.parse(s)
    with (ROOT/'output'/name.replace('compact_cog','directional_cog')).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'created_helpers':3,'all_helpers_parse':True})
