"""Prepare the declared one-shot runner, without starting it."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/run_h5_capacity_phase_mix_probe.py').read_text()
new=old.replace('h5-capacity-phase-mix-probe-20261026','h5-necessary-direction-projection-20261026').replace('45solver seconds within60shared seconds','20solver seconds within30shared seconds').replace("budget['deadline_perf_counter']-50","budget['deadline_perf_counter']-25").replace('start+60','start+30').replace("'shared_seconds':60","'shared_seconds':30").replace("'per_group_solver_seconds':45","'per_group_solver_seconds':20")
p=ROOT/'output/run_h5_necessary_direction_projection.py'
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(new)
print('Prepared one20solver/30shared second call; not started.')
