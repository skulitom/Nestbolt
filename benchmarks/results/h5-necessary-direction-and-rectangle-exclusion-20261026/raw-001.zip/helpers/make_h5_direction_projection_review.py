from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_compact_checkpoint.py').read_text().replace('h5-compact-cog-checkpoint-review-20261026','h5-direction-projection-review-20261026').replace("head=='7271cc8beb5caae3a3dced77d129ffcdcb1ec7ed'","head=='bc9edc2b82caa501c92052f2bcc0aa78ca068053'")
p=ROOT/'output/review_h5_direction_projection_checkpoint.py'
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
