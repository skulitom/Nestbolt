from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
for name in ['run_h5_relative_y_spacing_probe.py','audit_h5_relative_y_spacing_response.py']:
    s=(ROOT/'output'/name).read_text(encoding='utf-8');old="BASE=ROOT/'output/h5-relative-y-spacing-probe-20261026'";assert old in s;s=s.replace(old,"BASE=ROOT/'output/h5-capacity-phase-mix-probe-20261026'")
    if name.startswith('audit'):
        s=s.replace('eight declared cog angles and both insert choices','three profile9 cogs and one profile15 cog, both insert choices')
        needle="    for i,p in enumerate(selected):";assert needle in s;s=s.replace(needle,"    assert selected[5:].count(9)==3 and selected[5:].count(15)==1\n"+needle)
    ast.parse(s)
    with (ROOT/'output'/name.replace('relative_y_spacing','capacity_phase_mix')).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'created_helpers':2,'all_helpers_parse':True})
