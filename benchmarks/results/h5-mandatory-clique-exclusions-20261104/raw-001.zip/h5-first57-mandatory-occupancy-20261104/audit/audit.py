from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-mandatory-occupancy-20261104';OUT=BASE/'audit'
BR=ROOT/'output/h5-first57-local-conflict-covers-20261104';AREA=ROOT/'output/h5-first57-clique-pruned-areas-20261104';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
HELPER=ROOT/'output/audit_h5_first57_reachable_area_20261104.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,BR/'audit',AREA/'audit']:
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [BR,AREA]:assert load(base/'audit/checks.json')['passed']
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='exact_area'];assert len(functions)==1
scope={};exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'),scope);exact_area=scope['exact_area']
geometry=load(SOURCE/'geometry-domains.json');records=[];component_count=0
for i in range(3):
    data=load(BASE/f'choice-{i:02d}.json');br=load(BR/f'choice-{i:02d}.json');area=load(AREA/f'choice-{i:02d}.json')
    assert data['empty_sites']==br['empty_sites']==area['empty_sites'] and br['bracket_capacity_upper_bound']==8
    obstacles=area['reachable_rectangles']['insert']+area['fixed_inner_obstacles'];node_bounds=[]
    assert len(data['nodes'])==len(br['nodes'])
    for node,claim in zip(br['nodes'],data['nodes']):
        assert node['node']==claim['node'];x,y,z,w=node['bounds_um']
        rectangles=geometry[node['geometry']]['inner_rectangles_um'];assert len(claim['components'])==len(rectangles);lower=0
        for component,(a,b,c,d) in zip(claim['components'],rectangles):
            swept=[x+a,y+b,z+c,w+d];outside,stats=exact_area([swept],obstacles);inner=(c-a)*(d-b);inside=max(0,inner-outside);lower+=inside
            assert component=={'swept_rectangle_um':swept,'source_inner_area_um2':inner,'outside_area_upper_um2':outside,'inside_area_lower_um2':inside};component_count+=1
        assert lower==claim['inside_area_lower_um2'];node_bounds.append(lower)
    cliques=[min(node_bounds[n] for n in c['nodes']) for c in br['cliques']];assert cliques==data['clique_minimum_inside_areas_um2']
    mandatory=sum(cliques);reachable=load(AREA/'audit/checks.json')['choices'][i]['exact_areas_um2']['insert'];remaining=reachable-mandatory;required=area['required_inner_areas_um2']['insert']
    assert mandatory==data['mandatory_bracket_area_inside_insert_region_um2'] and reachable==data['insert_reachable_area_um2'] and remaining==data['remaining_insert_area_upper_um2'] and required==data['required_insert_inner_area_um2']
    excluded=remaining<required;assert excluded==data['diagnostic_excluded']
    records.append({'empty_sites':data['empty_sites'],'mandatory_bracket_area_inside_insert_region_um2':mandatory,'remaining_insert_area_upper_um2':remaining,'required_insert_inner_area_um2':required,'continuous_insert_count_upper_bound':remaining//(required//8),'excluded':excluded})
inputs=[Path(__file__),HELPER,BASE/'plan.json',BASE/'checks.json']+[BASE/f'choice-{i:02d}.json' for i in range(3)]+[b/n for b in [BR,AREA] for n in ['audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'For each source-inner component, independently compute the exact integer area of its swept rectangle outside the insert swept union and fixed inner obstacles. Every legal component avoids those fixed obstacles, so its area outside the insert-accessible region cannot exceed this value. Its source area minus the bound, clipped at zero, is a valid lower bound inside the insert-accessible region. Inner components are disjoint; sum their bounds for each node, minimize over each mandatory bracket clique, and add all eight clique minima. Different original bracket and insert interiors are disjoint. Subtracting the mandatory bracket area from the exact insert-accessible area therefore bounds remaining insert source area. This is conditional on the required eight brackets and current fixed29/cog poses.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':records,'exact_component_outside_areas':component_count,'mandatory_clique_minima':24,'new_site_choices_excluded':sum(r['excluded'] for r in records),'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
