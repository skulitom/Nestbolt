from pathlib import Path
import ast,json,shutil,subprocess
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];NAME='h5-mandatory-clique-exclusions-20261104';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=ROOT,text=True).strip()
stages=[
    ('local-conflict-covers','bracket-clique'),('mandatory-clique-insert-bounds','initial-insert'),
    ('clique-pruned-areas','initial-area'),('mandatory-occupancy','initial-occupancy'),
    ('mandatory-clique-consistency','bracket-consistency'),('consistent-insert-bounds','consistent-insert'),
    ('consistent-pruned-areas','consistent-area'),('consistent-occupancy','consistent-occupancy'),
    ('joint-clique-distributions','joint-distribution')]
prep_total=0;stage_records=[]
for stem,label in stages:
    base=ROOT/'output'/f'h5-first57-{stem}-20261104';process=ROOT/'output'/f'h5-first57-{stem}-process-20261104'
    checks=load(base/'audit/checks.json');record=load(process/'process.json')
    assert checks['passed'] and record['exit_code']==0 and not record['timeout'] and record['closed'] and record['complete_process_cap_overrun_seconds']==0
    prep_total+=record['complete_process_seconds'];stage_records.append({'stage':stem,'complete_process_seconds':record['complete_process_seconds'],'independent_audit_seconds':checks['seconds']})
FINAL=ROOT/'output/h5-first57-joint-clique-distributions-20261104'
result=load(FINAL/'audit/checks.json');assert result['new_fixed29_choices_excluded']==3 and result['remaining_fixed29_choices']==256 and result['complete_distributions_verified']==549
prior=ROOT/'output/seal_h5_first57_edge_controls_20261104.py';tree=ast.parse(prior.read_text(encoding='utf-8'))
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARENTS' for t in n.targets))
exec(compile(ast.Module(body=[assignment],type_ignores=[]),str(prior),'exec'))
PARENTS.extend([ROOT/'benchmarks/results'/n for n in ['h5-first57-edge-controls-and-companion-20261104','h5-shelf-and-edge-capacity-proofs-20261104','h5-single-edge-choice-construction-20261104','h5-broader-core-positive-construction-20261104','h5-source-polygons-and-joint-frontier-20261104']])
walker=ROOT/'output/seal_h5_translated_packet_checkpoint_20261104.py';old=walker.read_text(encoding='utf-8')
setup=old[old.index('parent_by_hash={}'):old.index('processes=[')].replace("['plan.json','opened.json']","['plan.json','opened.json','final-preparation-charges.json']")
exec(setup)
for stem,label in stages:
    for suffix in ['', '-process']:
        folder=ROOT/'output'/f'h5-first57-{stem}{suffix}-20261104'
        for p in folder.rglob('*'):
            if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
for pattern in ['*h5_local_conflict*20261104.py','*h5_mandatory*20261104.py','*h5_clique*20261104.py','*h5_consistent*20261104.py','*h5_joint_clique*20261104.py','*h5_occupancy*20261104.py']:
    for p in (ROOT/'output').glob(pattern):add('helpers/'+p.name,p)
for name in ['pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name,walker.name,prior.name,'h5-mandatory-clique-exclusions-report-20261104.md']:add('helpers/'+name,ROOT/'output'/name)
exec(old[old.index('while queue:'):old.index('for source,name in [(')])
for stem,label in stages:shutil.copyfile(ROOT/'output'/f'h5-first57-{stem}-20261104/audit/checks.json',OUT/f'{label}-audit.json')
shutil.copyfile(FINAL/'audit/remaining-fixed29-choices.json',OUT/'remaining-fixed29-choices.json')
write(OUT/'process-ledger.json',{'complete_preparation_seconds':prep_total,'stages':stage_records,'all_process_cap_overruns_seconds':0,'placement_solver_calls':0,'native_calls':0})
write(OUT/'next-step.json',{'all_prior_placement_calls_closed':True,'new_continuous_exclusions':[[0,4,14],[5,11,13],[5,11,14]],'remaining_fixed29_choices':256,
    'next_method':'Apply the complete continuous bracket subcell/self-conflict/clique-cover proof to every remaining fixed29 pose choice. Independently replay full domain coverage and every clique certificate. A clique cover below eight excludes that choice even at zero clearance. A cover of exactly eight makes all cliques mandatory and permits the certified bracket consistency and insert-pruning rules. Any later joint distribution proof must cover every eight-of-k insert-clique selection, or preserve unresolved selections without exclusion. Freeze bounded process limits and preserve all outcomes. Do not rerun any closed placement call.',
    'necessary_cover':'output/h5-first57-necessary-mask-cover-20261104','source_inner_bodies':'output/h5-first57-necessary-rectangles-20261104',
    'bracket_proof_example':'output/prepare_h5_local_conflict_covers_20261104.py','complete_frontier_bound_prepared':False,'whole_allocation_candidates':440,'source_valid66_required_before_native':True,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),
    'continuous_choices_excluded':3,'remaining_fixed29_choices':256,'total_fixed29_choices_excluded':199,'original_fixed29_choices':455,
    'complete_distributions_verified':549,'ordered_final_removals_verified':4618,'strict_final_source_pair_checks':15087,
    'complete_preparation_seconds':prep_total,'placement_solver_calls':0,'native_calls':0,'whole_allocations_excluded':0,'whole_allocation_candidates':440,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=(ROOT/'output/h5-mandatory-clique-exclusions-report-20261104.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@MEMBERS@@',str(archive['archive_members'])).replace('@@BYTES@@',f"{archive['archive_bytes']:,}").replace('@@PREP@@',f'{prep_total:.6f}')
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='\n\n**2026-11-04 H5 mandatory-clique continuous exclusions:** [independent complete-cover and contradiction proofs]({link}) exclude fixed29 cog selections [0,4,14], [5,11,13] and [5,11,14] even at zero clearance. Eight certified bracket cliques make every group mandatory; exact consistency removes 232 bracket cells, then certified insert pruning leaves covers with 9/10/12 cliques. Every one of the 9/45/495 eight-insert-group selections reaches a replayed contradiction: 549 distributions, 4,618 ordered removals and 15,087 strict source-inner pair checks. Intermediate area bounds and all nine preparation processes are preserved; no placement solver or native call runs. The broader fixed29 frontier falls from 259 to 256 (199 of 455 excluded). Whole allocations remain 440; full66 checks and H2/H5 remain open at 60%. Next extend the cheap complete bracket-clique bound to all 256 survivors. All prior placement calls stay closed.\n'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8')
a='Latest H5 evidence: [source polygons and joint frontier](../benchmarks/results/h5-source-polygons-and-joint-frontier-20261104.md).'
assert s.count(a)==1;s=s.replace(a,f'Latest H5 evidence: [mandatory-clique continuous exclusions](../benchmarks/results/{NAME}.md).',1)
a='The broader fixed29 frontier remains 259 choices. Exact local conflict bounds\nover the continuous necessary anchor cover are next to assess. All prior calls stay closed.'
b='New exact continuous conflict proofs exclude [0,4,14], [5,11,13] and [5,11,14].\nAll 549 possible insert-clique distributions reach independently replayed\ncontradictions. The broader fixed29 frontier now has 256 choices (199 of 455\nexcluded). Extending the complete bracket-clique bound to those survivors is\nnext. All prior calls stay closed.'
assert s.count(a)==1;s=s.replace(a,b,1)
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s)
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings),'complete_preparation_seconds':prep_total})
