from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_local_conflict_covers_20261104.py').read_text(encoding='utf-8').replace('local-conflict-covers','clique-pruned-areas').replace('prepare_h5_local_conflict_covers_20261104.py','prepare_h5_clique_pruned_areas_20261104.py').replace('35','25')
with (O/'run_h5_clique_pruned_areas_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
