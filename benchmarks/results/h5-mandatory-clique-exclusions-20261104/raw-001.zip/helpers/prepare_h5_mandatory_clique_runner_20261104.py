from pathlib import Path
O=Path(__file__).resolve().parent
s=(O/'run_h5_local_conflict_covers_20261104.py').read_text(encoding='utf-8').replace('local-conflict-covers','mandatory-clique-insert-bounds').replace('prepare_h5_local_conflict_covers_20261104.py','prepare_h5_mandatory_clique_insert_bounds_20261104.py')
with (O/'run_h5_mandatory_clique_insert_bounds_20261104.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
