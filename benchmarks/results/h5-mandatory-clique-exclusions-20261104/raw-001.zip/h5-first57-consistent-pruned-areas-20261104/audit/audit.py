from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first57-consistent-pruned-areas-20261104';OUT=BASE/'audit'
BR=ROOT/'output/h5-first57-local-conflict-covers-20261104';INS=ROOT/'output/h5-first57-consistent-insert-bounds-20261104';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
HELPER=ROOT/'output/audit_h5_first57_reachable_area_20261104.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
AC=ROOT/'output/h5-first57-mandatory-clique-consistency-20261104'
def refined_br(index):
    assert load(AC/'audit/checks.json')['passed']
    data=load(BR/f'choice-{index:02d}.json');refined=load(AC/f'choice-{index:02d}.json')
    assert refined['empty_sites']==data['empty_sites'] and not refined['diagnostic_excluded']
    assert len(refined['remaining_cliques'])==len(data['cliques'])==8
    for clique,nodes in zip(data['cliques'],refined['remaining_cliques']):
        assert nodes and set(nodes)<=set(clique['nodes']);clique['nodes']=nodes
    return data
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py')
for base in [BASE,BR/'audit',INS/'audit']:
    for name,h in load(base/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
for base in [BR,INS]:assert load(base/'audit/checks.json')['passed']
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='exact_area'];assert len(functions)==1
scope={};exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'),scope);exact_area=scope['exact_area']
geometry=load(SOURCE/'geometry-domains.json');sources=load(SOURCE/'fixed-core-inner-rectangles.json')+load(SOURCE/'world-cog-inner-rectangles.json')
minima={family:min(sum((c-a)*(d-b) for a,b,c,d in g['inner_rectangles_um']) for g in geometry if g['aliases'][0][0]==family) for family in ['bracket','insert']}
records=[]
for i in range(3):
    data=load(BASE/f'choice-{i:02d}.json');br=refined_br(i);ins=load(INS/f'choice-{i:02d}.json')
    empty=br['empty_sites'];assert data['empty_sites']==ins['empty_sites']==empty;bodies={}
    for family,nodes in [('bracket',br['nodes']),('insert',[ins['nodes'][j] for j in ins['retained']])]:
        rects=set()
        for node in nodes:
            x,y,z,w=node['bounds_um']
            for a,b,c,d in geometry[node['geometry']]['inner_rectangles_um']:rects.add((x+a,y+b,z+c,w+d))
        bodies[family]=sorted(map(list,rects))
    bodies['joint']=sorted(map(list,set(map(tuple,bodies['bracket']+bodies['insert']))))
    assert bodies==data['reachable_rectangles']
    obstacles=[r['bounds_um'] for r in sources if r['site_bit'] not in empty];assert obstacles==data['fixed_inner_obstacles']
    areas={family:exact_area(rects,obstacles)[0] for family,rects in bodies.items()}
    assert areas==data['diagnostic_areas_um2']
    required={'bracket':8*minima['bracket'],'insert':8*minima['insert'],'joint':8*sum(minima.values())};assert required==data['required_inner_areas_um2']
    excluded=any(areas[k]<required[k] for k in areas);assert excluded==data['diagnostic_excluded']
    records.append({'empty_sites':empty,'exact_areas_um2':areas,'required_inner_areas_um2':required,'excluded':excluded})
inputs=[Path(__file__),ROOT/'output/prepare_h5_consistent_clique_helpers_20261104.py',AC/'audit/plan.json',AC/'audit/checks.json',AC/'choice-00.json',AC/'choice-01.json',AC/'choice-02.json',HELPER,BASE/'plan.json',BASE/'checks.json']+[BASE/f'choice-{i:02d}.json' for i in range(3)]+[b/n for b in [BR,INS] for n in ['audit/plan.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'proof':'Independently reconstruct every swept source-inner rectangle from the complete retained continuous cover, subtract selected fixed source-inner obstacles, and compute all nine union-minus-obstacle areas with exact integer sweep arithmetic. Disjoint original moving bodies require their source-inner areas within these unions. This is a necessary conditional bound after independently certified mandatory-clique pruning.'})
result={'passed':True,'seconds':time.perf_counter()-started,'choices':records,'exact_areas_verified':9,'new_site_choices_excluded':sum(r['excluded'] for r in records),'whole_allocations_excluded':0,'solver_calls':0,'native_calls':0,'H5_complete':False}
write(OUT/'checks.json',result);print(result)
