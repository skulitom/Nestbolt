"""Remove insert cells that conflict with a mandatory continuous bracket clique."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,json,time,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-mandatory-clique-insert-bounds-20261104'
BR=ROOT/'output/h5-first57-local-conflict-covers-20261104'
SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104';COVER=ROOT/'output/h5-first57-necessary-mask-cover-20261104'
HELPER=ROOT/'output/prepare_h5_local_conflict_covers_20261104.py'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(BR/'audit/checks.json')['passed']
geometry=load(SOURCE/'geometry-domains.json')
functions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in ['intervals','conflict','first_fit','saturation_cover']]
assert len(functions)==4;exec(compile(ast.Module(body=functions,type_ignores=[]),str(HELPER),'exec'))
inputs=[Path(__file__),HELPER,SOURCE/'geometry-domains.json']+[BR/n for n in ['audit/plan.json','audit/checks.json']]+[BR/f'choice-{i:02d}.json' for i in range(3)]+[COVER/f'geometry-{g:02d}-cover.json' for g in [8,9]]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Every valid eight-bracket packing occupies each of its eight certified conflict cliques. Subdivide all necessary insert anchor boxes into closed50mm cells. An insert cell is impossible if it conflicts for all anchors with every bracket cell in any mandatory clique. Record every strict-overlap witness for each removed cell. Then certify a conflict-clique upper bound on remaining inserts; no source placement or solver call is used.',
    'preparation_cap_seconds':25,'maximum_process_seconds':35,'solver_calls':0,'native_calls':0})
summaries=[]
for choice,bc in enumerate(load(BR/'audit/checks.json')['choices']):
    assert bc['every_clique_mandatory_for_eight_brackets']
    br=load(BR/f'choice-{choice:02d}.json');empty=br['empty_sites'];bits=sum(1<<i for i in empty);nodes=[]
    for gid in [8,9]:
        for ri,(mask,x,y,z,w,*_) in enumerate(load(COVER/f'geometry-{gid:02d}-cover.json')):
            if mask&~bits:continue
            for xi,(l,r) in enumerate(intervals(x,z)):
                for yi,(b,t) in enumerate(intervals(y,w)):nodes.append({'node':len(nodes),'geometry':gid,'cover_box':ri,'cell':[xi,yi],'bounds_um':[l,b,r,t]})
    removed=[];retained=[]
    for node in nodes:
        for ci,clique in enumerate(br['cliques']):
            proofs=[]
            for b in clique['nodes']:
                proof=conflict(node,br['nodes'][b])
                if proof is None:break
                proofs.append([b,*proof])
            else:
                removed.append({'insert_node':node['node'],'mandatory_bracket_clique':ci,'strict_overlap_certificates':proofs});break
        else:retained.append(node['node'])
    active=[nodes[i] for i in retained];n=len(active);adj=[1<<i for i in range(n)];self_cert=[]
    for i,a in enumerate(active):
        proof=conflict(a,a);assert proof is not None;self_cert.append(proof)
        for j in range(i):
            if conflict(a,active[j]) is not None:adj[i]|=1<<j;adj[j]|=1<<i
    orders=[list(range(n)),list(reversed(range(n))),sorted(range(n),key=lambda v:(adj[v].bit_count(),v)),sorted(range(n),key=lambda v:(-adj[v].bit_count(),v))]
    attempts=[first_fit(order,adj) for order in orders]+[saturation_cover(adj)]
    best=min(range(len(attempts)),key=lambda i:(len(attempts[i]),i));groups=attempts[best];cert=[]
    for group in groups:
        original=[retained[v] for v in group];pairs=[]
        for k,a in enumerate(original):
            for b in original[k+1:]:
                proof=conflict(nodes[a],nodes[b]);assert proof is not None;pairs.append([a,b,*proof])
        cert.append({'nodes':original,'strict_overlap_certificates':pairs})
    data={'empty_sites':empty,'nodes':nodes,'removed':removed,'retained':retained,'retained_self_certificates':self_cert,
        'candidate_cover_counts':[len(g) for g in attempts],'selected_cover':best,'insert_cliques':cert,'insert_capacity_upper_bound':len(groups),'diagnostic_excluded':len(groups)<8}
    write(OUT/f'choice-{choice:02d}.json',data)
    row={'empty_sites':empty,'insert_cells':len(nodes),'removed_by_mandatory_bracket_clique':len(removed),'remaining_cells':len(retained),'candidate_cover_counts':data['candidate_cover_counts'],'upper_bound':len(groups),'diagnostic_excluded':len(groups)<8}
    summaries.append(row);print(row,flush=True);assert time.perf_counter()-started<25
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':summaries,'independent_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
