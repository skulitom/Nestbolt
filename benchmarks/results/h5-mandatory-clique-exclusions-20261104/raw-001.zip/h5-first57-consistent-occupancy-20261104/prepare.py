from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from shapely import box,union_all
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-consistent-occupancy-20261104'
BR=ROOT/'output/h5-first57-local-conflict-covers-20261104';AREA=ROOT/'output/h5-first57-consistent-pruned-areas-20261104';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
AC=ROOT/'output/h5-first57-mandatory-clique-consistency-20261104'
def refined_br(index):
    assert load(AC/'audit/checks.json')['passed']
    data=load(BR/f'choice-{index:02d}.json');refined=load(AC/f'choice-{index:02d}.json')
    assert refined['empty_sites']==data['empty_sites'] and not refined['diagnostic_excluded']
    assert len(refined['remaining_cliques'])==len(data['cliques'])==8
    for clique,nodes in zip(data['cliques'],refined['remaining_cliques']):
        assert nodes and set(nodes)<=set(clique['nodes']);clique['nodes']=nodes
    return data
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for base in [BR,AREA]:assert load(base/'audit/checks.json')['passed']
geometry=load(SOURCE/'geometry-domains.json')
inputs=[Path(__file__),ROOT/'output/prepare_h5_consistent_clique_helpers_20261104.py',AC/'audit/plan.json',AC/'audit/checks.json',AC/'choice-00.json',AC/'choice-01.json',AC/'choice-02.json',SOURCE/'geometry-domains.json']+[b/n for b in [BR,AREA] for n in ['audit/plan.json','audit/checks.json']]+[b/f'choice-{i:02d}.json' for b in [BR,AREA] for i in range(3)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'Use the independently verified surviving bracket nodes after mandatory-clique consistency; every valid packing remains covered. Let R be the union of retained insert swept inner bodies minus fixed inner obstacles. Every mandatory bracket clique contributes one source body. For each node/component, its area outside R is bounded by the swept component area outside both the insert swept union and fixed inner obstacles. The component area minus that bound, clipped at zero, is a guaranteed area inside R. Sum over disjoint inner components, minimize over each mandatory clique, and sum all eight clique minima. Insert source bodies are disjoint from these bracket areas. Independent exact area arithmetic is required before any exclusion.',
    'preparation_cap_seconds':15,'maximum_process_seconds':25,'solver_calls':0,'native_calls':0})
records=[]
for i in range(3):
    br=refined_br(i);area=load(AREA/f'choice-{i:02d}.json');assert br['empty_sites']==area['empty_sites']
    forbidden=union_all([box(*r) for r in area['reachable_rectangles']['insert']+area['fixed_inner_obstacles']]);node_bounds=[]
    for node in br['nodes']:
        x,y,z,w=node['bounds_um'];components=[];lower=0
        for a,b,c,d in geometry[node['geometry']]['inner_rectangles_um']:
            swept=[x+a,y+b,z+c,w+d];outside=float(box(*swept).difference(forbidden).area)
            inner=(c-a)*(d-b);component_lower=max(0,inner-outside);lower+=component_lower
            components.append({'swept_rectangle_um':swept,'source_inner_area_um2':inner,'outside_area_upper_um2':outside,'inside_area_lower_um2':component_lower})
        node_bounds.append({'node':node['node'],'components':components,'inside_area_lower_um2':lower})
    cliques=[min(node_bounds[n]['inside_area_lower_um2'] for n in g['nodes']) for g in br['cliques']]
    mandatory=sum(cliques);reachable=area['diagnostic_areas_um2']['insert'];remaining=reachable-mandatory;required=area['required_inner_areas_um2']['insert']
    result={'empty_sites':br['empty_sites'],'nodes':node_bounds,'clique_minimum_inside_areas_um2':cliques,'mandatory_bracket_area_inside_insert_region_um2':mandatory,'insert_reachable_area_um2':reachable,'remaining_insert_area_upper_um2':remaining,'required_insert_inner_area_um2':required,'diagnostic_excluded':remaining<required}
    write(OUT/f'choice-{i:02d}.json',result);records.append({k:v for k,v in result.items() if k!='nodes'});print(records[-1],flush=True);assert time.perf_counter()-started<15
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':records,'independent_exact_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
