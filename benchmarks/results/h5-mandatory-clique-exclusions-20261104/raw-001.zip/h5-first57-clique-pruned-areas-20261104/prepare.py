from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,time,shutil
from shapely import box,union_all
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-first57-clique-pruned-areas-20261104'
BR=ROOT/'output/h5-first57-local-conflict-covers-20261104';INS=ROOT/'output/h5-first57-mandatory-clique-insert-bounds-20261104';SOURCE=ROOT/'output/h5-first57-necessary-rectangles-20261104'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'prepare.py')
for base in [BR,INS]:assert load(base/'audit/checks.json')['passed']
geometry=load(SOURCE/'geometry-domains.json');sources=load(SOURCE/'fixed-core-inner-rectangles.json')+load(SOURCE/'world-cog-inner-rectangles.json')
inputs=[Path(__file__)]+[b/n for b in [BR,INS] for n in ['audit/plan.json','audit/checks.json']]+[b/f'choice-{i:02d}.json' for b in [BR,INS] for i in range(3)]+[SOURCE/n for n in ['geometry-domains.json','fixed-core-inner-rectangles.json','world-cog-inner-rectangles.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
    'method':'After mandatory bracket-clique pruning, form the swept inner-body union for all remaining insert cells, all bracket cells, and both families. Subtract fixed29 and selected12 cog source-inner obstacles. Bound required source-body areas in each family and the combined union. Floating areas are diagnostic until independent exact integer union-minus-obstacle replay.',
    'preparation_cap_seconds':15,'maximum_process_seconds':25,'solver_calls':0,'native_calls':0})
minima={family:min(sum((c-a)*(d-b) for a,b,c,d in g['inner_rectangles_um']) for g in geometry if g['aliases'][0][0]==family) for family in ['bracket','insert']}
results=[]
for i in range(3):
    br=load(BR/f'choice-{i:02d}.json');ins=load(INS/f'choice-{i:02d}.json');empty=br['empty_sites'];assert ins['empty_sites']==empty
    bodies={}
    for family,nodes in [('bracket',br['nodes']),('insert',[ins['nodes'][j] for j in ins['retained']])]:
        rects=[]
        for node in nodes:
            x,y,z,w=node['bounds_um']
            for a,b,c,d in geometry[node['geometry']]['inner_rectangles_um']:rects.append([x+a,y+b,z+c,w+d])
        bodies[family]=sorted(map(list,set(map(tuple,rects))))
    bodies['joint']=sorted(map(list,set(map(tuple,bodies['bracket']+bodies['insert']))))
    obstacles=[r['bounds_um'] for r in sources if r['site_bit'] not in empty];fixed=union_all([box(*r) for r in obstacles])
    areas={family:float(union_all([box(*r) for r in rects]).difference(fixed).area) for family,rects in bodies.items()}
    required={'bracket':8*minima['bracket'],'insert':8*minima['insert'],'joint':8*sum(minima.values())}
    row={'empty_sites':empty,'reachable_rectangles':bodies,'fixed_inner_obstacles':obstacles,'diagnostic_areas_um2':areas,'required_inner_areas_um2':required,'diagnostic_excluded':any(areas[k]<required[k] for k in areas)}
    write(OUT/f'choice-{i:02d}.json',row);results.append({k:v for k,v in row.items() if k not in ['reachable_rectangles','fixed_inner_obstacles']});print(results[-1],flush=True)
    assert time.perf_counter()-started<15
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-started,'choices':results,'independent_exact_audit_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
