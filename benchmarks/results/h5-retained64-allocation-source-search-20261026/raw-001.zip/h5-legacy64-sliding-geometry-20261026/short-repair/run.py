"""One fixed-mode translation repair of the retained short sheet, followed by source readback."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
import numpy as np
from scipy.optimize import minimize
from h5_global_sliding_objective import SlidingObjective
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-legacy64-sliding-geometry-20261026';OUT=BASE/'short-repair';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');plan=load(BASE/'plan.json');obj=SlidingObjective(BASE/'short');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');seed=load(BASE/'short/seed-placements.json');expected=[(p['part_id'],p['copy_index']) for p in seed];stocks={'sheet-1':[6.5,6.5,1493.5,plan['short_height_mm']-6.5]};before=audit(job,seed,stocks,plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected);write(OUT/'before-source.json',before)
inputs={p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents};inputs.update({str(p.relative_to(ROOT).as_posix()):digest(p) for p in [ROOT/'output/h5_global_sliding_objective.py',ROOT/'output/h5_legacy64_source_readback.py']})
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'search_seconds':10,'maximum_iterations':1000,'maximum_evaluations':2500,'initial_configurations':1,'mode_changes':False,'retry_permitted':False,'method':'Translate only the9 retained short originals once to the current .22430867250963943 configuration clearance and .0126 extra stock margin. Preserve their exact original angle/mirror attributes. Compare source validation before and after; only a strict source pass permits a first-sheet search.'})
modes=[r['initial_mode'] for r in obj.moving];x=np.asarray([r['initial_anchor'] for r in obj.moving]).reshape(-1);calls=0;best=None;start=time.perf_counter();status=None
class Stop(Exception):pass
def fun(z):
    global calls,best
    if calls>=2500 or time.perf_counter()-start>=10:raise Stop()
    v,g,d=obj.evaluate(z,modes);calls+=1
    if best is None or v<best['value']:best={'value':v,'anchors':np.asarray(z).reshape(-1,2).tolist(),'diagnostics':d,'evaluation':calls}
    return v,g
try:
    result=minimize(fun,x,jac=True,method='L-BFGS-B',options={'maxiter':1000,'maxfun':2500,'maxls':30,'ftol':1e-15,'gtol':1e-9});status=str(result.message)
except Stop:status='DECLARED_LIMIT'
seconds=time.perf_counter()-start;rows=obj.placements(best['anchors'],modes)
for p in rows:p['sheet_id']='sheet-1'
after=audit(job,rows,stocks,plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected)
write(OUT/'best.json',best);write(OUT/'placements.json',rows);write(OUT/'after-source.json',after);write(OUT/'result.json',{'closed':True,'status':status,'seconds':seconds,'evaluations':calls,'best_penalty_mm2':best['value'],'before_source_valid':before['valid'],'source_valid':after['valid'],'pair_failures':after['pair_failures'],'stock_failures':after['stock_failures'],'minimum_pair_gap_mm':after['minimum_pair_gap_mm'],'minimum_extra_stock_mm':after['minimum_extra_stock_mm'],'next_first_search_qualified':after['valid'],'native_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
