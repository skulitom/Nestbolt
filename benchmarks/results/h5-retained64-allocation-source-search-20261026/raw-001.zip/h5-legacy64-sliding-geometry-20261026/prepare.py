"""Rebuild a different 57/9 allocation using the exact retained source rotations."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import copy,json,math,shutil,time
from shapely.geometry import Polygon,shape,mapping
from shapely.affinity import affine_transform
import diagnose_h5_concave_gaps as geom
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-global-sliding-source-geometry-20261026';OUT=ROOT/'output/h5-legacy64-sliding-geometry-20261026';LEGACY=ROOT/'output/h5-latest-wide-joint-20261023/layout-audit/layout-final.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();job=load(JOB);legacy=load(LEGACY);parts={p['id']:p for p in job['parts']};items=load(ROOT/'output/h5-source-orientation-construction-20261025/items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)}
guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);geom.EPS=.0126;short_height=325.9269023299994
inputs=[JOB,LEGACY,OLD/'modes.json',ROOT/'output/h5-source-orientation-construction-20261025/items.json',ROOT/'output/h5_global_sliding_objective.py',Path(geom.__file__)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'preparation_seconds':180,'short_height_mm':short_height,'required_pair_gap_mm':required,'stock_guard_mm':guard,'construction_eps_mm':geom.EPS,'method':'Different retained64-original allocation: short4brackets2inserts3cogs; first18frames8brackets19inserts12cogs with all57 mandatory and movable. Reconstruct the exact seed cog angle -2.2428996024478143 radians and insert pi mode from original vertices; do not infer rotational symmetry. First perform one bounded fixed-mode translation repair of the9 short originals under current guards. Only if independent original-ring checks pass may its placement be fixed for a fresh57-part search. All prior53-part searches remain closed. No geometry/source-acceptance threshold is relaxed.'})
modes=load(OLD/'modes.json');needed=sorted(set((p['part_id'],p['transform']['rotation_radians'],p['transform']['mirrored']) for p in legacy['placements']))
for family,angle,mirrored in needed:
    if any(m['family']==family and m['angle']==angle and m['mirrored']==mirrored for m in modes):continue
    c,s=math.cos(angle),math.sin(angle);mi=-1 if mirrored else 1;g=affine_transform(Polygon(parts[family]['geometry'][0]['outer']),[mi*c,-s,mi*s,c,0,0])
    if family=='cog':offset=[-c*139.723742+s*139.723742,-s*139.723742-c*139.723742];kind='original cog center'
    else:offset=[-g.bounds[0],-g.bounds[1]];kind='rotated outer lower left'
    g=affine_transform(g,[1,0,0,1,*offset]);modes.append({'index':len(modes),'family':family,'angle':angle,'mirrored':mirrored,'source_translation_offset':offset,'anchor_kind':kind,'geometry':mapping(g)})
assert len(modes)==18;write(OUT/'modes.json',modes);shapes=[shape(m['geometry']) for m in modes];reused={}
for i,a in enumerate(shapes):
    for j in range(i,len(shapes)):
        assert time.perf_counter()-start<180
        if j<16:p=OLD/'obstacles'/f'{i:02d}-{j:02d}.json';shutil.copyfile(p,OUT/'obstacles'/p.name);reused[p.relative_to(ROOT).as_posix()]=digest(p)
        else:write(OUT/'obstacles'/f'{i:02d}-{j:02d}.json',mapping(geom.obstacle(a,shapes[j],required)))
for sheet,n in [('short',1),('first',0)]:
    base=OUT/sheet;base.mkdir();(base/'free').mkdir();(base/'obstacles').mkdir();shutil.copyfile(OUT/'modes.json',base/'modes.json');stock=copy.deepcopy(job['stocks'][0])
    if n==1:stock['height']=short_height
    for i,g in enumerate(shapes):
        free=geom.regions(g,[],stock,job['edge_clearance'],required)
        write(base/'free'/f'{i:02d}.json',mapping(free))
    for p in (OUT/'obstacles').glob('*.json'):shutil.copyfile(p,base/'obstacles'/p.name)
    seed=sorted([p for p in legacy['placements'] if p['sheet_id']==f'sheet-{n}'],key=lambda p:ids[p['part_id'],p['copy_index']]);moving=[]
    for p in seed:
        t=p['transform'];mi=next(m['index'] for m in modes if m['family']==p['part_id'] and m['angle']==t['rotation_radians'] and m['mirrored']==t['mirrored']);offset=modes[mi]['source_translation_offset'];moving.append({'original':ids[p['part_id'],p['copy_index']],'family':p['part_id'],'copy_index':p['copy_index'],'allowed_modes':[mi] if n==1 else [m['index'] for m in modes if m['family']==p['part_id']],'initial_mode':mi,'initial_anchor':[t['translation'][k]-offset[k] for k in range(2)]})
    write(base/'moving.json',moving);write(base/'seed-placements.json',seed);write(base/'stock.json',stock)
    assert len(moving)==(9 if n==1 else 55)
write(OUT/'reused-intrinsic-obstacles.json',reused)
write(OUT/'inventory.json',{'legacy_originals':64,'fixed_short_originals':[r['original'] for r in load(OUT/'short/moving.json')],'first_seed_originals':[r['original'] for r in load(OUT/'first/moving.json')],'missing_first_originals':[28,29],'missing_family_copies':[['bracket',10],['bracket',11]],'required_first_counts':{'frame':18,'bracket':8,'insert':19,'cog':12},'all66_required':True})
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'modes':18,'intrinsic_obstacles_reused':136,'new_intrinsic_obstacles':35,'total_obstacles':171,'old_source_angles_preserved':True,'initial_short_originals':9,'initial_first_originals':55,'missing_first_brackets':2,'first_search_opened':False,'native_calls':0});print(load(OUT/'prepared.json'))
