"""Positive adaptive penalties for the same complete original-source geometry."""
import numpy as np
import shapely
from h5_global_sliding_objective import SlidingObjective
class GuidedObjective(SlidingObjective):
    def weighted(self,flat,modes,pair_weights,stock_weights):
        xy=np.asarray(flat,dtype=float).reshape(-1,2);modes=np.asarray(modes,dtype=int);pw=np.asarray(pair_weights);sw=np.asarray(stock_weights);assert pw.shape==self.left.shape and sw.shape==(len(xy),) and np.all(pw>0) and np.all(sw>0);delta=xy[self.right]-xy[self.left];points=shapely.points(delta);indices=modes[self.left]*len(self.modes)+modes[self.right];inside=shapely.contains(self.obstacles[indices],points);gradient=np.zeros_like(xy);pair_q=np.zeros(len(self.left));stock_q=np.zeros(len(xy))
        if np.any(inside):
            nearest=shapely.get_coordinates(shapely.get_point(shapely.shortest_line(points[inside],self.boundaries[indices[inside]]),1));difference=delta[inside]-nearest;pair_q[inside]=np.sum(difference*difference,axis=1);np.add.at(gradient,self.right[inside],2*pw[inside,None]*difference);np.add.at(gradient,self.left[inside],-2*pw[inside,None]*difference)
        anchors=shapely.points(xy);outside=~shapely.covers(self.free[modes],anchors)
        if np.any(outside):
            nearest=shapely.get_coordinates(shapely.get_point(shapely.shortest_line(anchors[outside],self.free[modes[outside]]),1));difference=xy[outside]-nearest;stock_q[outside]=np.sum(difference*difference,axis=1);gradient[outside]+=2*sw[outside,None]*difference
        unweighted=float(np.sum(pair_q)+4*np.sum(stock_q));value=float(np.dot(pw,pair_q)+np.dot(sw,stock_q));diag={'unweighted_penalty_mm2':unweighted,'pair_penalty_mm2':float(np.sum(pair_q)),'fixed_penalty_mm2':float(np.sum(stock_q)),'overlapping_configuration_pairs':int(np.sum(inside)),'anchors_outside_free_regions':int(np.sum(outside)),'maximum_pair_depth_mm':float(np.sqrt(np.max(pair_q,initial=0.))),'maximum_fixed_depth_mm':float(np.sqrt(np.max(stock_q,initial=0.)))};return value,gradient.reshape(-1),diag,pair_q,stock_q
