"""One declared adaptive-penalty run; every positional stage changes objective weights."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-legacy57-guided-search-20261026';GEO=ROOT/'output/h5-legacy57-sliding-source-20261026';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
class BudgetStop(Exception):pass
class StageStop(Exception):pass
def child():
    import numpy as np
    import scipy
    from scipy.optimize import minimize
    from h5_guided_sliding_objective import GuidedObjective
    assert load(BASE/'checks.json')['passed']
    for n,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    obj=GuidedObjective(GEO);seed=load(BASE/'seed.json');x=np.asarray(seed['anchors']).reshape(-1);modes=list(seed['modes']);npairs=len(obj.left);n=len(obj.moving);pair_weights=np.ones(npairs);stock_weights=np.full(n,4.);base=np.r_[np.ones(npairs),np.full(n,4.)];best=None;calls=0;improvements=[];updates=[];stages=[];trials=[];changes=[];start=time.perf_counter();deadline=start+60
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'search_seconds':60,'maximum_guided_iterations':100,'maxiter_per_stage':300,'maxfun_per_stage':700,'mode_sweep_every_iterations':4,'initial_configurations':1,'random_restarts':0,'scipy_version':scipy.__version__,'numpy_version':np.__version__})
    def evaluate(z,mi,kind):
        nonlocal calls,best
        if time.perf_counter()>=deadline:raise BudgetStop()
        value,gradient,diag,pq,sq=obj.weighted(z,mi,pair_weights,stock_weights);calls+=1;raw=diag['unweighted_penalty_mm2']
        if best is None or raw<best['value']:
            best={'value':raw,'anchors':np.asarray(z).reshape(-1,2).tolist(),'modes':list(mi),'evaluation':calls,'seconds':time.perf_counter()-start,'diagnostics':diag};improvements.append({'evaluation':calls,'seconds':best['seconds'],'value':raw,'kind':kind,**diag})
        return value,gradient,diag,pq,sq
    status='ITERATION_LIMIT'
    try:
        value,_,diag,pq,sq=evaluate(x,modes,'initial')
        for iteration in range(100):
            q=np.r_[pq,sq];weights=np.r_[pair_weights,stock_weights];ratio=weights/base;eligible=np.flatnonzero((q>1e-12)&(ratio<1e6))
            if not len(eligible):status='ZERO_PENALTY_CANDIDATE' if diag['unweighted_penalty_mm2']<=1e-12 else 'WEIGHT_CAP';break
            utility=q/ratio;ordered=sorted(eligible.tolist(),key=lambda k:(-utility[k],k));selected=ordered[:max(1,int(np.ceil(len(ordered)*.25)))];entries=[]
            for k in selected:
                old=float(weights[k]);weights[k]=min(1e6*base[k],1.5*old);assert weights[k]>old;entries.append({'term':k,'depth_squared':float(q[k]),'utility':float(utility[k]),'before':old,'after':float(weights[k])})
            pair_weights=weights[:npairs].copy();stock_weights=weights[npairs:].copy();updates.append({'iteration':iteration,'eligible_terms':len(eligible),'selected':entries});value,_,diag,pq,sq=evaluate(x,modes,f'weighted-start-{iteration}');stage_start=time.perf_counter();stage_modes=list(modes);stage_calls=0;stage_best={'value':value,'x':x.copy()};returned=None
            def fun(z):
                nonlocal stage_calls,stage_best
                if stage_calls>=700:raise StageStop()
                v,g,d,a,b=evaluate(z,stage_modes,f'position-{iteration}');stage_calls+=1
                if v<stage_best['value']:stage_best={'value':v,'x':np.asarray(z).copy()}
                return v,g
            try:returned=minimize(fun,x,jac=True,method='L-BFGS-B',options={'maxiter':300,'maxfun':700,'maxls':20,'ftol':1e-12,'gtol':1e-6});x=np.asarray(returned.x)
            except StageStop:x=stage_best['x']
            value,_,diag,pq,sq=evaluate(x,modes,f'position-returned-{iteration}');stages.append({'iteration':iteration,'seconds':time.perf_counter()-stage_start,'weighted_value':float(value),'unweighted_value':diag['unweighted_penalty_mm2'],'function_evaluations':stage_calls,'scipy_success':bool(returned.success) if returned is not None else False,'scipy_status':int(returned.status) if returned is not None else None,'message':str(returned.message) if returned is not None else 'Hard700-evaluation stage limit','iterations':int(returned.nit) if returned is not None else None})
            if best['value']<=1e-12:status='ZERO_PENALTY_CANDIDATE';break
            if iteration%4==0:
                for i,item in enumerate(obj.moving):
                    original_mode=modes[i];chosen=original_mode;chosen_value=value
                    for alternate in item['allowed_modes']:
                        if alternate==original_mode:continue
                        mi=list(modes);mi[i]=alternate;v,_,d,a,b=evaluate(x,mi,f'mode-{iteration}-{i}');trials.append({'iteration':iteration,'original':item['original'],'from_mode':original_mode,'alternative_mode':alternate,'weighted_value':float(v)})
                        if v<chosen_value-1e-8:chosen,chosen_value=alternate,v
                    if chosen!=original_mode:changes.append({'iteration':iteration,'original':item['original'],'from_mode':original_mode,'to_mode':chosen,'before_weighted':float(value),'after_weighted':float(chosen_value)});modes[i]=chosen;value=chosen_value
                value,_,diag,pq,sq=evaluate(x,modes,f'mode-returned-{iteration}')
            if best['value']<=1e-12:status='ZERO_PENALTY_CANDIDATE';break
            if (iteration+1)%20==0:print({'iteration':iteration+1,'seconds':time.perf_counter()-start,'best_unweighted':best['value']},flush=True)
    except BudgetStop:status='TIME_LIMIT'
    assert best is not None
    if best['value']<=1e-12:status='ZERO_PENALTY_CANDIDATE'
    write(OUT/'best.json',best);write(OUT/'best-moving-placements.json',obj.placements(best['anchors'],best['modes']));write(OUT/'improvements.json',improvements);write(OUT/'weight-updates.json',updates);write(OUT/'final-weights.json',{'pair':pair_weights.tolist(),'stock':stock_weights.tolist()});write(OUT/'position-stages.json',stages);write(OUT/'mode-trials.json',trials);write(OUT/'accepted-mode-changes.json',changes)
    write(OUT/'result.json',{'status':status,'search_seconds':time.perf_counter()-start,'objective_evaluations':calls,'weight_updates':len(updates),'position_stages_returned':len(stages),'mode_trials':len(trials),'accepted_mode_changes':len(changes),'best_unweighted_penalty_mm2':best['value'],'best_diagnostics':best['diagnostics'],'closed':True,'initial_configurations':1,'random_restarts':0,'all57_movers_mandatory':True,'source_terms_removed':0,'weighted_values_not_used_as_fit_scores':True,'actual_source_geometry_valid_claimed':False,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');inputs={p.relative_to(ROOT).as_posix():digest(p) for p in BASE.iterdir() if p.is_file()};inputs.update({p.relative_to(ROOT).as_posix():digest(p) for folder in [GEO/'free',GEO/'obstacles'] for p in folder.iterdir() if p.is_file()})
    for p in [GEO/'modes.json',GEO/'moving.json',GEO/'inventory.json',ROOT/'output/h5_guided_sliding_objective.py',ROOT/'output/h5_global_sliding_objective.py']:inputs[p.relative_to(ROOT).as_posix()]=digest(p)
    write(OUT/'plan.json',{'inputs':inputs,'search_seconds':60,'shared_seconds':90,'maximum_runs':1,'retry_permitted':False});start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90);(OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);record={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:(OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No returned result; this run remains closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
