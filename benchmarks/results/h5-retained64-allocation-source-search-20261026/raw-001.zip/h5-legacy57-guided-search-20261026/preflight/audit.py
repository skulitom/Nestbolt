"""Independent source modes, stock samples, gradients and repaired-short acceptance."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon,Point,shape
from h5_guided_sliding_objective import GuidedObjective
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-legacy64-sliding-geometry-20261026';GEO=ROOT/'output/h5-legacy57-sliding-source-20261026';BASE=ROOT/'output/h5-legacy57-guided-search-20261026';OUT=BASE/'preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for plan in [load(OLD/'plan.json'),load(OLD/'short-repair/plan.json'),load(BASE/'plan.json')]:
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
for n,h in load(OLD/'reused-intrinsic-obstacles.json').items():assert digest(ROOT/n)==h and digest(GEO/'obstacles'/Path(n).name)==h,n
plan=load(OLD/'plan.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};obj=GuidedObjective(GEO);inventory=load(GEO/'inventory.json');seed=load(BASE/'seed.json');required=plan['required_pair_gap_mm'];guard=plan['stock_guard_mm'];assert len(obj.moving)==57 and len(obj.modes)==18 and sorted([r['original'] for r in obj.moving]+inventory['fixed_short_originals'])==list(range(66))
short=inventory['fixed_short_placements'];short_audit=audit(job,short,{'sheet-1':[6.5,6.5,1493.5,plan['short_height_mm']-6.5]},required,guard,[(p['part_id'],p['copy_index']) for p in load(OLD/'short/seed-placements.json')]);assert short_audit['valid'];write(OUT/'short-source-readback.json',short_audit)
def source(mi,xy):
    mode=obj.modes[mi];c,s=math.cos(mode['angle']),math.sin(mode['angle']);m=-1 if mode['mirrored'] else 1;tx,ty=[mode['source_translation_offset'][k]+xy[k] for k in range(2)];return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[mode['family']]['geometry'][0]['outer']])
shapes=[];free_samples=0
for mi,mode in enumerate(obj.modes):
    g=source(mi,[0.,0.]);part=parts[mode['family']];assert g.is_valid and g.symmetric_difference(shape(mode['geometry'])).area<1e-8 and abs(g.area-Polygon(part['geometry'][0]['outer']).area)<1e-6;assert not mode['mirrored'] or part['allow_mirror'];assert part['rotations']['kind']=='free' or any(abs(math.remainder(mode['angle']-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees']);shapes.append(g);region=obj.free[mi];assert region.geom_type=='Polygon' and region.equals(region.envelope)
    for xy in list(region.exterior.coords)+[list(region.representative_point().coords)[0]]:
        b=source(mi,xy).bounds;assert min(b[0]-6.5,b[1]-6.5,1493.5-b[2],2993.5-b[3])>guard;free_samples+=1
samples=outside=0
for i in range(18):
    for j in range(i,18):
        obstacle=obj.obstacles[i*18+j];b=obstacle.bounds
        for x in np.linspace(b[0]-1,b[2]+1,5):
            for y in np.linspace(b[1]-1,b[3]+1,5):
                samples+=1
                if not obstacle.covers(Point(x,y)):assert shapes[i].distance(source(j,[x,y]))>required;outside+=1
actual=obj.placements(seed['anchors'],seed['modes']);poses={(r['part_id'],r['copy_index']):r for r in actual}
for b in load(OLD/'first/seed-placements.json'):
    a=poses[b['part_id'],b['copy_index']];at,bt=a['transform'],b['transform'];assert at['rotation_radians']==bt['rotation_radians'] and at['mirrored']==bt['mirrored'] and max(abs(at['translation'][k]-bt['translation'][k]) for k in range(2))<1e-9
x=np.asarray(seed['anchors']).reshape(-1);modes=seed['modes'];npairs=len(obj.left);n=len(obj.moving);assert npairs==1596 and n==57;pw=np.ones(npairs);sw=np.full(n,4.);v,g,diag,pq,sq=obj.weighted(x,modes,pw,sw);v0,g0,d0=obj.evaluate(x,modes);assert abs(v-v0)<1e-8 and max(abs(g-g0))<1e-8;gradients=[]
for variant in range(3):
    xx=x+.037*np.sin(np.arange(len(x))*1.7+variant*.31);wp=1.5**((np.arange(npairs)+variant)%5);ws=4*1.5**((np.arange(n)+variant)%4);value,analytic,*_=obj.weighted(xx,modes,wp,ws)
    for coordinate in np.linspace(0,len(x)-1,20,dtype=int):
        h=1e-5;plus=xx.copy();minus=xx.copy();plus[coordinate]+=h;minus[coordinate]-=h;numeric=(obj.weighted(plus,modes,wp,ws)[0]-obj.weighted(minus,modes,wp,ws)[0])/(2*h);error=abs(numeric-analytic[coordinate]);assert error<.003+1e-5*abs(analytic[coordinate]);gradients.append({'variant':variant,'coordinate':int(coordinate),'numeric':numeric,'analytic':float(analytic[coordinate]),'error':error})
initial=audit(job,actual+short,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,plan['short_height_mm']-6.5]},required,guard,[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])]);write(OUT/'initial-all66-readback.json',initial);write(OUT/'gradient-checks.json',gradients)
checks={'passed':True,'seconds':time.perf_counter()-start,'moving_originals':57,'fixed_short_originals':9,'source_modes_verified':18,'original_seed_poses_preserved':55,'fresh_source_obstacle_samples':samples,'outside_obstacle_source_checks':outside,'geometry_sampling_is_not_a_continuous_proof':True,'stock_samples':free_samples,'weighted_gradient_checks':len(gradients),'maximum_gradient_error':max(r['error'] for r in gradients),'positive_pair_terms':npairs,'positive_stock_terms':n,'initial_penalty_mm2':v,'initial_source_pair_failures':initial['pair_failures'],'initial_source_stock_failures':initial['stock_failures'],'short_source_valid':True,'all66_required':True,'optimizer_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);write(BASE/'checks.json',checks);print(checks)
