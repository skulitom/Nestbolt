"""Build one full57-source seed by deterministic insertion; retain the repaired short9."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time
import numpy as np
import shapely
from h5_global_sliding_objective import SlidingObjective
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-legacy64-sliding-geometry-20261026';GEO=ROOT/'output/h5-legacy57-sliding-source-20261026';OUT=ROOT/'output/h5-legacy57-guided-search-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(OLD/'short-repair/result.json')['source_valid'];GEO.mkdir();OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs={p.relative_to(ROOT).as_posix():digest(p) for p in OLD.rglob('*') if p.is_file()}
for p in [ROOT/'output/h5_global_sliding_objective.py',ROOT/'output/h5_guided_sliding_objective.py']:inputs[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'preparation_seconds':45,'search_seconds':60,'shared_seconds':90,'maximum_guided_iterations':100,'maxiter_per_position_stage':300,'maxfun_per_position_stage':700,'mode_sweep_every_iterations':4,'weight_multiplier':1.5,'maximum_weight_ratio':1000000,'violated_constraint_fraction_to_reweight':.25,'initial_configurations':1,'random_restarts':0,'insertion_grid_mm':50,'method':'Use a different short allocation from the preserved64-original result. Repaired short9 fixed; all57 first originals mandatory and movable. Preserve exact55 first seed poses and original source cog angle. Insert missing brackets10 and11 deterministically, choosing least squared configuration penetration over all8 legal bracket modes and a50mm stock grid including all boundary rows/columns. The second insertion sees the first. This is one seed, no random restart. One adaptive-positive-penalty search uses all1596 first-pair and57 stock terms; changing weights never removes any source constraint. Independent original-ring readback is mandatory; no native call without all66 passing.'})
for n in ['free','obstacles']:shutil.copytree(OLD/'first'/n,GEO/n)
for n in ['modes.json','moving.json']:shutil.copyfile(OLD/'first'/n,GEO/n)
obj=SlidingObjective(GEO);moving=list(obj.moving);xy=np.asarray([r['initial_anchor'] for r in moving]);mis=np.asarray([r['initial_mode'] for r in moving]);br_modes=[m['index'] for m in obj.modes if m['family']=='bracket'];proposals=[];chosen=[]
for original,copy_index in [(28,10),(29,11)]:
    best=None
    for mi in br_modes:
        assert time.perf_counter()-start<45
        a,b,c,d=obj.free[mi].bounds;xs=np.unique(np.r_[a,np.arange(np.ceil(a/50)*50,c,50),c]);ys=np.unique(np.r_[b,np.arange(np.ceil(b/50)*50,d,50),d]);xx,yy=np.meshgrid(xs,ys);points=np.c_[xx.reshape(-1),yy.reshape(-1)];cost=np.zeros(len(points))
        for k in range(0,len(points),256):
            chunk=points[k:k+256];delta=chunk[:,None,:]-xy[None,:,:];flat=delta.reshape(-1,2);p=shapely.points(flat);indices=np.tile(mis*len(obj.modes)+mi,len(chunk));inside=shapely.contains(obj.obstacles[indices],p);q=np.zeros(len(flat))
            if np.any(inside):
                near=shapely.get_coordinates(shapely.get_point(shapely.shortest_line(p[inside],obj.boundaries[indices[inside]]),1));diff=flat[inside]-near;q[inside]=np.sum(diff*diff,axis=1)
            cost[k:k+len(chunk)]=q.reshape(len(chunk),len(xy)).sum(axis=1)
        for anchor,value in zip(points,cost):
            r={'original':original,'mode':mi,'anchor':anchor.tolist(),'incremental_penalty_mm2':float(value)};proposals.append(r)
            if best is None or value<best['incremental_penalty_mm2']:best=r
    chosen.append(best);moving.append({'original':original,'family':'bracket','copy_index':copy_index,'allowed_modes':br_modes,'initial_mode':best['mode'],'initial_anchor':best['anchor']});xy=np.vstack([xy,best['anchor']]);mis=np.r_[mis,best['mode']]
moving.sort(key=lambda r:r['original']);assert len(moving)==57 and Counter(r['family'] for r in moving)=={'frame':18,'bracket':8,'insert':19,'cog':12}
# This file is construction output and has not been bound by any search plan yet.
with (GEO/'moving.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(moving,f,indent=2);f.write('\n')
short=load(OLD/'short-repair/placements.json');oldinv=load(OLD/'inventory.json');assert sorted([r['original'] for r in moving]+oldinv['fixed_short_originals'])==list(range(66))
write(GEO/'inventory.json',{'fixed_first_originals':[],'fixed_first_placements':[],'fixed_short_originals':oldinv['fixed_short_originals'],'fixed_short_placements':short,'mandatory_moving_first_originals':[r['original'] for r in moving],'mandatory_moving_family_counts':dict(Counter(r['family'] for r in moving)),'all57_movers_mandatory':True,'all66_originals_accounted_once':True})
write(OUT/'insertion-proposals.json',proposals);write(OUT/'chosen-insertions.json',chosen);write(OUT/'seed.json',{'anchors':[r['initial_anchor'] for r in moving],'modes':[r['initial_mode'] for r in moving]});write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'insertion_proposals':len(proposals),'initial_source_poses_preserved':55,'missing_originals_inserted':[28,29],'moving_originals':57,'short_originals':9,'all66_required':True,'source_fit_claimed':False,'search_opened':False});print(load(OUT/'prepared.json'));print(chosen)
