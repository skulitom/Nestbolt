"""All-angle original-tip exclusions against exact inset fixed rectangles."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import product
import json,math,shutil,time
from shapely.geometry import Polygon,Point,box,mapping
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];SCREEN=ROOT/'output/h5-paired-strip-cog-space-20261026';INVENTORY=ROOT/'output/h5-paired-strip-core-20261026/audit';GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';SUPPORT=ROOT/'output/h5-all-angle-support-bounds-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-paired-strip-support-domains-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[SCREEN/n for n in ['plan.json','fixed-originals-and-obstacles.json','center-stock.json','result.json']]+[INVENTORY/'checks.json',INVENTORY/'next-neighborhood.json',GEOM/'original-cog-proof.json',GEOM/'audit/checks.json',SUPPORT/'cog-spacing-proof.json',SUPPORT/'audit/checks.json',JOB]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_limit_seconds':120,'coordinate_units_per_mm':1000,'fixed_rectangle_inset_units':2,'forbidden_rectangle_inset_units':1,'original_cog_inscribed_radius_units':109115,'original_cog_hull_support_units':139270,'original_cog_outer_radius_units':140001,'support_vertex_transverse_bound_units':15000,'method':'Decompose all34 fixed orthogonal non-cog filled outers into source grid rectangles. Transform each rectangle and inset its rounded world bounding box by2micrometres; independently verify exact interval corner containment before use. For each contained rectangle, original support vertices have longitudinal projection >=139270 and transverse absolute projection <=15000. The original109115 disk joins the two support-tip intervals whenever width/height+109115>140001. Construct horizontal and vertical closed forbidden center rectangles inset1micrometre from the strict source exclusions. Partition the entire center-stock rectangle at every forbidden-box edge. Drop only closed cells completely contained in a single certified forbidden box; retain every other whole closed cell, including all boundaries. All arithmetic after source construction is integer. This is a necessary all-angle domain, not a source-feasible map. No solver call.'})
assert load(INVENTORY/'checks.json')['passed'] and load(SUPPORT/'audit/checks.json')['passed'];families={p['id']:p for p in load(JOB)['parts']};fixed=load(SCREEN/'fixed-originals-and-obstacles.json');assert len(fixed)==34 and all(r['family']!='cog' for r in fixed);rects=[]
for owner in fixed:
    vertices=families[owner['family']]['geometry'][0]['outer'];poly=Polygon(vertices);xs=sorted({x for x,y in vertices});ys=sorted({y for x,y in vertices});t=owner['placement']['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    for a,b in zip(xs,xs[1:]):
        for d,e in zip(ys,ys[1:]):
            if not poly.contains(Point((a+b)/2,(d+e)/2)):continue
            corners=[[a,d],[b,d],[b,e],[a,e]];world=[(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in corners];bounds=[math.ceil(min(x for x,y in world)*1000)+2,math.ceil(min(y for x,y in world)*1000)+2,math.floor(max(x for x,y in world)*1000)-2,math.floor(max(y for x,y in world)*1000)-2];assert bounds[0]<bounds[2] and bounds[1]<bounds[3];rects.append({'index':len(rects),'item':owner['item'],'family':owner['family'],'source_rectangle':[a,d,b,e],'source_corners':corners,'world_inner_rectangle_units1000':bounds,'placement':owner['placement']})
root=[math.floor(F(v)*1000) if i<2 else math.ceil(F(v)*1000) for i,v in enumerate(load(SCREEN/'center-stock.json')['bounds'])];forbidden=[]
for r in rects:
    a,b,c,d=r['world_inner_rectangle_units1000'];w,h=c-a,d-b;assert min(w,h)+109115>140001 and min(w,h)>30000
    for direction,bb in [('horizontal-support',[a+15001,b-139269,c-15001,d+139269]),('vertical-support',[a-139269,b+15001,c+139269,d-15001])]:
        clipped=[max(root[0],bb[0]),max(root[1],bb[1]),min(root[2],bb[2]),min(root[3],bb[3])]
        if clipped[0]<clipped[2] and clipped[1]<clipped[3]:forbidden.append({'index':len(forbidden),'fixed_rectangle':r['index'],'direction':direction,'unclipped_bounds_units1000':bb,'bounds_units1000':clipped})
xs=sorted({root[0],root[2]}|{b['bounds_units1000'][i] for b in forbidden for i in [0,2]});ys=sorted({root[1],root[3]}|{b['bounds_units1000'][i] for b in forbidden for i in [1,3]});cells=[];excluded=[]
for xi,(a,c) in enumerate(zip(xs,xs[1:])):
    for yi,(b,d) in enumerate(zip(ys,ys[1:])):
        cover=next((r['index'] for r in forbidden if r['bounds_units1000'][0]<=a and r['bounds_units1000'][1]<=b and c<=r['bounds_units1000'][2] and d<=r['bounds_units1000'][3]),None)
        row={'grid':[xi,yi],'bounds_units1000':[a,b,c,d]}
        if cover is None:cells.append({'index':len(cells),**row})
        else:excluded.append({**row,'forbidden_box':cover})
    assert time.perf_counter()-start<120
free=unary_union([box(*(x/1000 for x in r['bounds_units1000'])) for r in cells]);write(OUT/'fixed-source-rectangles.json',rects);write(OUT/'forbidden-support-rectangles.json',forbidden);write(OUT/'grid.json',{'root_bounds_units1000':root,'x_breaks_units1000':xs,'y_breaks_units1000':ys});write(OUT/'allowed-closed-cells.json',cells);write(OUT/'excluded-cells.json',excluded);write(OUT/'allowed-union-diagnostic.json',mapping(free))
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'fixed_originals':34,'source_rectangles':len(rects),'forbidden_support_boxes':len(forbidden),'grid_columns':len(xs)-1,'grid_rows':len(ys)-1,'all_grid_cells':(len(xs)-1)*(len(ys)-1),'allowed_closed_cells':len(cells),'excluded_cells':len(excluded),'allowed_union_area_mm2':free.area,'allowed_union_bounds_mm':list(free.bounds) if not free.is_empty else None,'all_boundaries_covered':True,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
