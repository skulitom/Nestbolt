"""Independent full partition, exact farthest-corner graph and clique-cover proof."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import gzip,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-capacity-cells-20261026';DOMAIN=ROOT/'output/h5-paired-strip-refined-domains-20261026';OUT=BASE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(DOMAIN/'audit/checks.json')['passed'];proof=load(ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit/checks.json');assert proof['passed'] and proof['original_all_angle_center_separation_units1000']==254300 and proof['rounded_center_separation_units1000']==254297;D=254297;expected=[]
for r in load(DOMAIN/'domains.json'):
    a,b,c,d=r['bounds_units1000'];xs=sorted({a,c}|{x for x in range(0,1500001,25000) if a<x<c});ys=sorted({b,d}|{y for y in range(0,3000001,25000) if b<y<d})
    for i,j in product(range(len(xs)-1),range(len(ys)-1)):
        bb=[xs[i],ys[j],xs[i+1],ys[j+1]];assert (bb[2]-bb[0])**2+(bb[3]-bb[1])**2<D*D;expected.append({'index':len(expected),'domain':r['index'],'grid':[i,j],'bounds_units1000':bb})
cells=load(BASE/'cells.json');assert cells==expected;n=len(cells);nb=(n+7)//8;raw=gzip.decompress((BASE/'graph.bin.gz').read_bytes());assert len(raw)==n*nb and sha256(raw).hexdigest()==load(BASE/'result.json')['graph_uncompressed_sha256'];graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)];pairs=0;conflicts=0
for i,a in enumerate(cells):
    assert not(graph[i]>>i)&1 and graph[i]>>n==0;aa=a['bounds_units1000'];corners_a=list(product([aa[0],aa[2]],[aa[1],aa[3]]))
    for j in range(i+1,n):
        b=cells[j]['bounds_units1000'];corners_b=list(product([b[0],b[2]],[b[1],b[3]]));maximum=max((x-u)**2+(y-v)**2 for x,y in corners_a for u,v in corners_b);edge=maximum<D*D;assert edge==bool((graph[i]>>j)&1)==bool((graph[j]>>i)&1);pairs+=1;conflicts+=edge
covered=[0]*n;cliques=load(BASE/'cliques.json');left=load(BASE/'residual-pairs.json')
for clique in cliques:
    assert len(set(clique))==len(clique)>=2 and all(0<=i<n for i in clique);mask=sum(1<<i for i in clique)
    for i in clique:others=mask^(1<<i);assert graph[i]&others==others;covered[i]|=others
for i,j in left:assert 0<=i<j<n and (graph[i]>>j)&1;covered[i]|=1<<j;covered[j]|=1<<i
assert covered==graph
write(OUT/'necessity-proof.json',{'statement':'The54 merged current-owner domains retain every continuous feasible source center and every floor-rounded center. Their complete integer-edge25mm cell partition retains all boundaries. A source15-cog layout has rounded pair distances at least254297 micrometres by the full-circle original-source certificate. Each cell diameter is strictly smaller, so no two centers can share a cell. The farthest possible points in two rectangular cells occur at corners; an exact maximum below254297 squared certifies that both cells cannot be occupied. Choose one containing cell for each source center, resolving shared boundaries arbitrarily. This yields15 distinct cells satisfying every verified graph clique and residual edge. The two remaining inserts are omitted only to enlarge feasibility. A negative exact-cardinality cell model would therefore be a solver-derived exclusion for this fixed34/short15 arrangement with all cog angles and positions unrestricted. A positive is not a source layout.'});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'cells_verified':n,'continuous_partition_coverage':True,'unit_capacities_verified':n,'farthest_corner_pair_checks':pairs,'incompatible_pairs_verified':conflicts,'cliques_verified':len(cliques),'residual_edges_verified':len(left),'complete_graph_coverage':True,'all15_cogs_required':True,'two_inserts_still_required_for_full_layout':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
