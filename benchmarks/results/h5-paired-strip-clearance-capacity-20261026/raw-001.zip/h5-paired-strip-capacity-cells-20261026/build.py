"""Necessary25mm occupancy cells covering every continuous cog center in the new core."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import gzip,json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];DOMAIN=ROOT/'output/h5-paired-strip-refined-domains-20261026';PAIR=ROOT/'output/h5-cog-pair-rotation-certificate-20261026';OUT=ROOT/'output/h5-paired-strip-capacity-cells-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();assert load(DOMAIN/'audit/checks.json')['passed'] and load(PAIR/'audit/checks.json')['passed'];D=load(PAIR/'audit/checks.json')['rounded_center_separation_units1000'];assert D==254297
for n,h in load(PAIR/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [DOMAIN/'domains.json',DOMAIN/'audit/checks.json',DOMAIN/'audit/necessity-proof.json',PAIR/'audit/checks.json',PAIR/'plan.json',ROOT/'output/h5-paired-strip-core-20261026/audit/next-neighborhood.json']},'cell_step_units1000':25000,'rounded_center_minimum_separation_units1000':D,'graph_build_seconds':60,'clique_cover_seconds':20,'required_occupied_cells':15,'maximum_solver_calls':1,'solver_seconds':20,'shared_seconds':30,'method':'Split every complete necessary merged domain at the global25mm grid and keep all closed subrectangles. Their diameter is less than254297 micrometres, so each can contain at most one floor-rounded cog center. Mark two cells incompatible only when their maximum possible squared point distance is strictly below254297 squared. All continuous source centers, at arbitrary original angles, remain covered through the audited domain and separation proofs. Any valid15-cog placement induces15 distinct compatible cells; therefore a negative audited occupancy model excludes this fixed34 neighborhood even with the two inserts relaxed away. A positive cell selection is only necessary and is not a source layout. No old domains or finite-pose exclusions transfer. All previous calls remain closed.'})
domains=load(DOMAIN/'domains.json');cells=[]
for r in domains:
    a,b,c,d=r['bounds_units1000'];xs=[a]+list(range((a//25000+1)*25000,c,25000))+[c];ys=[b]+list(range((b//25000+1)*25000,d,25000))+[d]
    for i in range(len(xs)-1):
        for j in range(len(ys)-1):
            bb=[xs[i],ys[j],xs[i+1],ys[j+1]];assert (bb[2]-bb[0])**2+(bb[3]-bb[1])**2<D*D;cells.append({'index':len(cells),'domain':r['index'],'grid':[i,j],'bounds_units1000':bb})
n=len(cells);array=np.asarray([r['bounds_units1000'] for r in cells],dtype=np.int64);adj=np.zeros((n,n),dtype=np.bool_)
for i in range(n):
    assert time.perf_counter()-start<60
    b=array[i+1:];a=array[i];dx=np.maximum(np.abs(a[0]-b[:,2]),np.abs(a[2]-b[:,0]));dy=np.maximum(np.abs(a[1]-b[:,3]),np.abs(a[3]-b[:,1]));row=dx*dx+dy*dy<D*D;adj[i,i+1:]=row;adj[i+1:,i]=row
raw=np.packbits(adj,axis=1,bitorder='little').tobytes();nb=(n+7)//8;graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)];residual=list(graph);cliques=[];coverstart=time.perf_counter()
def bits(v):
    while v:l=v&-v;yield l.bit_length()-1;v-=l
while time.perf_counter()-coverstart<20:
    v=max(range(n),key=lambda i:residual[i].bit_count())
    if not residual[v]:break
    clique=[v];candidates=residual[v]
    while candidates:u=max(bits(candidates),key=lambda i:(graph[i]&candidates).bit_count());clique.append(u);candidates&=graph[u]
    mask=sum(1<<i for i in clique)
    for i in clique:assert graph[i]&(mask^(1<<i))==mask^(1<<i);residual[i]&=~mask
    cliques.append(clique)
left=[[i,j] for i in range(n) for j in bits(residual[i]) if i<j];covered=[0]*n
for clique in cliques:
    mask=sum(1<<i for i in clique)
    for i in clique:covered[i]|=mask^(1<<i)
for i,j in left:covered[i]|=1<<j;covered[j]|=1<<i
assert covered==graph
for name,value in [('cells.json',cells),('cliques.json',cliques),('residual-pairs.json',left)]:write(OUT/name,value)
with gzip.open(OUT/'graph.bin.gz','xb') as f:f.write(raw)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'merged_domains':len(domains),'occupancy_cells':n,'unordered_cell_pair_checks':n*(n-1)//2,'incompatible_pairs':sum(r.bit_count() for r in graph)//2,'cliques':len(cliques),'residual_edges':len(left),'clique_cover_seconds':time.perf_counter()-coverstart,'graph_uncompressed_sha256':sha256(raw).hexdigest(),'all_continuous_centers_covered':True,'all15_cogs_required':True,'two_inserts_relaxed_only_for_necessary_check':True,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
