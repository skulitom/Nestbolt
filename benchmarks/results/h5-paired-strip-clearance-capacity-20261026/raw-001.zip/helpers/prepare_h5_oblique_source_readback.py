"""Bind the source sampler and its independent readback to the newly certified cell selection."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for source,target in [('build_h5_paired_strip_source_cells.py','build_h5_paired_strip_oblique_source_cells.py'),('audit_h5_paired_strip_source_cells.py','audit_h5_paired_strip_oblique_source_cells.py')]:
    s=(ROOT/'output'/source).read_text(encoding='utf-8');s=s.replace('h5-paired-strip-source-cell-proposals-20261026','h5-paired-strip-oblique-source-cell-proposals-20261026').replace('h5-paired-strip-capacity-cells-20261026/response-audit','h5-paired-strip-oblique-capacity-20261026/response-audit')
    s=s.replace('Use only the first returned necessary15-cell selection.','Use only the first selection from the strictly strengthened all-angle model with61 certified cell exclusions. The earlier finite source sampler is closed and is not continued.')
    s=s.replace("[i for i in range(15) if counts[i]==0]==[2,12]","[i for i in range(15) if counts[i]==0]==load(BASE/'result.json')['empty_cell_groups']").replace("'empty_cell_groups':[2,12]","'empty_cell_groups':[i for i in range(15) if counts[i]==0]")
    with (ROOT/'output'/target).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
