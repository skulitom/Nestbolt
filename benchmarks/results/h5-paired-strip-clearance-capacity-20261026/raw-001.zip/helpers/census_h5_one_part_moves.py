"""Enumerate every one-core-part replacement and certify insert-count upper bounds."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import gzip,json,shutil,time
from reduce_h5_free_cog_pool import ROOT,SRC,OLD,OUT as PARENT,load,write,digest
OUT=ROOT/'output/h5-one-core-move-census-20261020'
def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'census.py')
    inputs=[PARENT/n for n in ['audit.json','kept-candidates.json','seed-indices.json','result-audit/checks.json']]
    inputs += [SRC/'candidates.json',OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in inputs},
        'method':'Exhaustively enumerate no change and every same-family replacement of one of the 45 seed frames/brackets/cogs by a different retained original pose, retaining all other 44. All insert poses remain free. Use original graph conflicts to retain exactly the feasible core replacements. Deduplicate by the exact surviving insert set. Greedily cover that set by original pairwise-conflicting cliques or singleton vertices; each cover is an independently checkable upper bound on simultaneous inserts, not necessarily a tight optimum. No solver calls.',
        'scope':'Only this finite one-core-move neighborhood. Failure cannot bound larger coordinated moves or continuous placements. No original-job acceptance credit.',
        'solver_calls':0,'native_packing_calls':0,'quality_runs':0})
    start=time.perf_counter();pool=load(SRC/'candidates.json');kept=set(load(PARENT/'kept-candidates.json'))
    seed=load(PARENT/'seed-indices.json');core={i for i in seed if pool[i]['placement']['part_id']!='insert'}
    ins={i for i in kept if pool[i]['placement']['part_id']=='insert'};assert len(core)==45
    adjacency=[0]*len(pool);clique_masks=[]
    for path in [OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']:
        with gzip.open(path,'rt',encoding='utf-8') as f:
            for line in f:
                group=json.loads(line);mask=sum(1<<i for i in group);clique_masks.append(mask)
                for i in group:adjacency[i]|=mask^(1<<i)
    coremask=sum(1<<i for i in core);insmask=sum(1<<i for i in ins)
    def union_neighbors(ids):
        result=0
        for i in ids:result|=adjacency[i]
        return result
    others={b:union_neighbors(core-{b}) for b in core}
    available=insmask&~union_neighbors(core);groups={available:[None]}
    replacements=0
    for a in sorted(kept-core-ins):
        conflicting=adjacency[a]&coremask
        if conflicting.bit_count()>1:continue
        removed=list(bits(conflicting)) if conflicting else sorted(core)
        for b in removed:
            if pool[a]['placement']['part_id']!=pool[b]['placement']['part_id']:continue
            assert not(adjacency[a]&(coremask^(1<<b)))
            remaining=insmask&~(others[b]|adjacency[a])
            groups.setdefault(remaining,[]).append([b,a]);replacements+=1
    projected={}
    for ci,mask in enumerate(clique_masks):
        intersection=mask&insmask
        if intersection.bit_count()>1:projected.setdefault(intersection,ci)
    records=[]
    for index,(available,moves) in enumerate(sorted(groups.items())):
        options={}
        for mask,ci in projected.items():
            intersection=mask&available
            if intersection.bit_count()>1:options.setdefault(intersection,ci)
        uncovered=available;cover=[]
        while uncovered:
            best=max(options,key=lambda mask:((mask&uncovered).bit_count(),-options[mask]),default=0)
            covered=best&uncovered
            if covered.bit_count()<2:
                covered=uncovered&-uncovered;ci=None
            else:ci=options[best]
            cover.append({'source_clique':ci,'candidates':list(bits(covered))});uncovered&=~covered
        records.append({'index':index,'insert_candidates':list(bits(available)),'replacements':moves,
            'cover':cover,'certified_insert_upper_bound':len(cover),'can_improve_not_ruled_out':len(cover)>13,
            'full_21_not_ruled_out':len(cover)>=21})
    write(OUT/'neighborhoods.json',records)
    result={'seconds':time.perf_counter()-start,'retained_pool':len(kept),'seed_core_parts':len(core),
        'eligible_insert_poses':len(ins),'feasible_single_replacements':replacements,
        'distinct_insert_sets_including_no_change':len(records),
        'cover_bound_histogram':dict(Counter(r['certified_insert_upper_bound'] for r in records)),
        'groups_not_ruled_out_for_improvement':sum(r['can_improve_not_ruled_out'] for r in records),
        'groups_not_ruled_out_for_full21':sum(r['full_21_not_ruled_out'] for r in records),
        'maximum_cover_bound':max(r['certified_insert_upper_bound'] for r in records),
        'full_target_witness':False}
    write(OUT/'result.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':main()
