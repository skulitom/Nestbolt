"""Restore all original cog choices and certify same-family pose substitutions."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from hashlib import sha256
import gzip,json,shutil,time
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'output/h5-coordinated-placement-selection-20261018'
OLD=ROOT/'output/h5-contact-placement-selection-20261018'
SEED=ROOT/'output/h5-skeleton-contact-selection-20261020'
OUT=ROOT/'output/h5-free-cog-pool-20261020'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'reduce.py')
    manifest=ROOT/'benchmarks/results/h5-coordinated-contact-selection-20261020/raw-manifest.json'
    hashes={r['path']:r['sha256'] for r in load(manifest)['files']}
    sources=[SRC/n for n in ['candidates.json','new-cliques.jsonl.gz','new-conflicts.jsonl.gz','audit/checks.json',
        'generation.json','job.json','library.json','request.json','conditional-target.json']]
    sources += [OLD/n for n in ['cliques.jsonl.gz','conflicts.jsonl.gz','audit/checks.json']]
    for p in sources:
        name=p.relative_to(ROOT/'output').as_posix()
        key=name if name in hashes else 'source-inputs/'+name
        assert digest(p)==hashes[key],name
    sources += [manifest,SEED/'selected-indices.json',SEED/'candidates.json',SEED/'audit/checks.json']
    write(OUT/'plan.json',{'opened_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):digest(p) for p in sources},
        'maximum_reduction_seconds':60,'maximum_comparisons':30000000,
        'method':'Use the sealed original 9059-pose full pool, including all 3947 cog poses. The later 2260 fixed-cog contact additions are outside this existing fully audited graph; do not invent their missing free-cog edges. Remove only same-family adjacent poses with a final surviving substitute whose full original neighbor set is contained after excluding the compared pair. All four families may move, and no artificial old-frame exclusions apply. Keep all unprocessed poses if a reduction limit is reached.',
        'followup':'After independent substitution and original-geometry checks, build one full integer model requiring 18 frames,12 brackets,15 cogs and maximizing inserts from the known feasible seed count13 through the original cap21. Use every surviving pose and conflict and a complete feasible hint. Declare one60-second solver call, eight workers, seed0, no retry. Retain all outcomes.',
        'scope':'Finite construction only; original quantities, stock and material target are unchanged. A partial still lacks original-job credit and full candidates still require native margins and H5 qualification.',
        'native_packing_calls':0,'quality_runs':0})
    pool=load(SRC/'candidates.json');seed=load(SEED/'selected-indices.json')
    assert len(pool)==9059 and pool==load(SEED/'candidates.json')[:9059] and max(seed)<9059
    adjacency=[0]*len(pool);clique_count=0
    for path in [OLD/'cliques.jsonl.gz',SRC/'new-cliques.jsonl.gz']:
        with gzip.open(path,'rt',encoding='utf-8') as f:
            for line in f:
                group=json.loads(line);mask=sum(1<<i for i in group);clique_count+=1
                for i in group:adjacency[i]|=mask^(1<<i)
    edges=sum(a.bit_count() for a in adjacency)//2
    assert edges==2517051+132531
    order=sorted(range(len(pool)),key=lambda i:(adjacency[i].bit_count(),i))
    byfamily={p['placement']['part_id']:[] for p in pool};kept=[];removed=[];comparisons=0;bounded=False
    start=time.perf_counter()
    for at,b in enumerate(order):
        if time.perf_counter()-start>=60 or comparisons>=30000000:
            kept.extend(order[at:]);bounded=True;break
        family=pool[b]['placement']['part_id'];dominator=None
        for a in byfamily[family]:
            comparisons+=1
            if comparisons>=30000000:break
            if not(adjacency[a]&(1<<b)):continue
            if adjacency[a]&~adjacency[b]&~(1<<b):continue
            dominator=a;break
        if dominator is None:kept.append(b);byfamily[family].append(b)
        else:removed.append({'removed':b,'kept':dominator,'family':family})
    assert set(kept)|{r['removed'] for r in removed}==set(range(len(pool)))
    assert not(set(kept)&{r['removed'] for r in removed})
    sub={r['removed']:r['kept'] for r in removed};mapped=sorted(sub.get(i,i) for i in seed)
    assert len(mapped)==len(set(mapped))==58 and set(mapped)<=set(kept)
    assert Counter(pool[i]['placement']['part_id'] for i in mapped)=={'frame':18,'bracket':12,'cog':15,'insert':13}
    mask=sum(1<<i for i in mapped);assert all(not(adjacency[i]&mask) for i in mapped)
    write(OUT/'kept-candidates.json',sorted(kept));write(OUT/'substitutions.json',removed);write(OUT/'seed-indices.json',mapped)
    check={'original_candidates':len(pool),'original_by_family':dict(Counter(p['placement']['part_id'] for p in pool)),
        'retained_candidates':len(kept),'retained_by_family':dict(Counter(pool[i]['placement']['part_id'] for i in kept)),
        'removed_candidates':len(removed),'removed_by_family':dict(Counter(r['family'] for r in removed)),
        'full_graph_edges':edges,'cliques':clique_count,'comparisons':comparisons,'reduction_seconds':time.perf_counter()-start,
        'bounded_early':bounded,'original_seed_count':58,'mapped_seed_count':58,'seed_insert_count':13,
        'seed_changed_candidates':sum(i in sub for i in seed),'full_target_witness':False}
    write(OUT/'result.json',check);print(json.dumps(check),flush=True)
if __name__=='__main__':main()
