"""Verify every parent and newly added constraint of the strengthened positive result."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import gzip,json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-oblique-capacity-20261026';DATA=ROOT/'output/h5-paired-strip-capacity-cells-20261026';SEARCH=BASE/'search';OUT=BASE/'response-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();assert load(BASE/'model/checks.json')['passed']
for n,h in load(BASE/'model/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert digest(SEARCH/'model.pb')==load(BASE/'model/checks.json')['model_sha256'];params=text_format.Parse((SEARCH/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=20.,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False)
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((SEARCH/'response.pb').read_bytes());result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<30 and cp_model_pb2.CpSolverStatus.Name(response.status)==result['status']=='OPTIMAL' and result['closed'] and result['solver_calls']==1;assert 0<response.wall_time==result['solver_wall_seconds']<=result['returned_solve_seconds']<=process['seconds'] and result['returned_solve_seconds']<20
cells=load(DATA/'cells.json');n=len(cells);values=list(response.solution);assert len(values)==n and set(values)<={0,1} and sum(values)==15;model=cp_model_pb2.CpModelProto();model.ParseFromString((SEARCH/'model.pb').read_bytes())
for row in model.constraints:
    kind=row.WhichOneof('constraint')
    if kind=='linear':
        value=sum(values[i]*c for i,c in zip(row.linear.vars,row.linear.coeffs));domain=list(row.linear.domain);assert any(domain[k]<=value<=domain[k+1] for k in range(0,len(domain),2))
    else:assert kind=='at_most_one' and all(i>=0 for i in row.at_most_one.literals) and sum(values[i] for i in row.at_most_one.literals)<=1
removed=[r['cell'] for r in load(BASE/'excluded-cells.json')];assert all(values[i]==0 for i in removed);selected=[i for i,v in enumerate(values) if v];assert selected==result['selected_cells'];raw=gzip.decompress((DATA/'graph.bin.gz').read_bytes());nb=(n+7)//8;graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)]
for a,b in combinations(selected,2):assert not(graph[a]>>b)&1
log=(SEARCH/'solver.log').read_text();assert abs(float(re.findall(r'^walltime:\s+([0-9.]+)',log,re.M)[-1])-response.wall_time)<.0005;worker_stats=[];lines=log.splitlines()
if any(line.startswith('Search stats') for line in lines):
    k=next(i for i,line in enumerate(lines) if line.startswith('Search stats'))+1
    while k<len(lines) and lines[k].strip():
        match=re.match(r"\s+'([^']+)':\s+([0-9']+)\s+([0-9']+)\s+([0-9']+)",lines[k]);assert match;name,bools,conflicts,branches=match.groups();worker_stats.append({'worker':name,'booleans':int(bools.replace("'",'')),'conflicts':int(conflicts.replace("'",'')),'branches':int(branches.replace("'",''))});k+=1
write(OUT/'selected-cells.json',[cells[i] for i in selected]);write(OUT/'worker-stats.json',worker_stats);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'status':'OPTIMAL','closed_solver_calls':1,'solver_wall_seconds':response.wall_time,'returned_solve_seconds':result['returned_solve_seconds'],'shared_process_seconds':process['seconds'],'shared_budget_honored':True,'soft_overruns':False,'all_model_constraints_verified':len(model.constraints),'all61_exclusions_honored':True,'selected_cells_verified':15,'selected_cell_pairs_verified':105,'search_started':any(line.startswith('Starting search at') for line in lines),'necessary_positive_only':True,'fixed34_neighborhood_excluded':False,'source_cog_coordinates_or_angles_verified':False,'two_inserts_still_required':True,'full66_target_witness':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
