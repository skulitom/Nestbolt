"""Independent exact rational support boxes and floor-safe whole-cell exclusions."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-oblique-capacity-20261026';OUT=BASE/'audit';OLD=ROOT/'output/h5-paired-strip-capacity-cells-20261026';SUPPORT=ROOT/'output/h5-paired-strip-support-domains-20261026';REF=ROOT/'output/h5-paired-strip-refined-domains-20261026';GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEOM/'audit/checks.json')['passed'] and load(SUPPORT/'audit/checks.json')['passed'] and load(REF/'audit/checks.json')['passed'];proof=load(GEOM/'original-cog-proof.json');assert proof['all_angle_stock_support_radius_units1000']==139270 and proof['original_inscribed_radius_units1000']==109115;h,R,beta=139270,140001,15000;assert R*R-h*h<=beta*beta and 109112+2<109115
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');source=next(p for p in job['parts'] if p['id']=='cog')['geometry'][0]['outer'];center=list(map(F,proof['center']));assert [[F(x)-center[0],F(y)-center[1]] for x,y in source]==[[F(*x),F(*y)] for x,y in proof['centered_vertices_rational']]
for x,y in proof['centered_vertices_rational']:assert F(*x)**2+F(*y)**2<=F(R,1000)**2
normals=load(BASE/'unit-normals.json');expected=set()
for a,b,c in [(1,0,1),(3,4,5),(5,12,13),(20,21,29)]:
    for x,y in [(a,b),(b,a)]:
        for sx,sy in product([-1,1],repeat=2):expected.add((sx*x,sy*y,c))
assert normals==[list(r) for r in sorted(expected)] and len(normals)==28 and all(a*a+b*b==c*c and c>0 for a,b,c in normals);rects=load(SUPPORT/'fixed-source-rectangles.json');boxes=[];margin_checks=0
for r in rects:
    a,b,c,d=r['world_inner_rectangle_units1000']
    for ni,(nx,ny,den) in enumerate(normals):
        vertices=[(F(nx*p-ny*q,den),F(ny*p+nx*q,den)) for p,q in product([h,R],[-beta,beta])];lx=min(v[0] for v in vertices);ux=max(v[0] for v in vertices);ly=min(v[1] for v in vertices);uy=max(v[1] for v in vertices);bb=[math.ceil(F(a)-lx)+2,math.ceil(F(b)-ly)+2,math.floor(F(c)-ux)-2,math.floor(F(d)-uy)-2]
        if bb[0]>=bb[2] or bb[1]>=bb[3]:continue
        assert bb[0]+lx>a and bb[1]+ly>b and bb[2]+1+ux<c and bb[3]+1+uy<d;margin_checks+=4;boxes.append({'index':len(boxes),'rectangle':r['index'],'normal':ni,'support_coordinate_intervals_rational':[[v.numerator,v.denominator] for v in [lx,ux,ly,uy]],'bounds_units1000':bb})
assert boxes==load(BASE/'support-vertex-boxes.json');points=load(REF/'source-points.json')
for point in points:
    a,b,c,d=rects[point['rectangle']]['world_inner_rectangle_units1000'];x,y=point['point_units1000'];assert a<=x<=c and b<=y<=d
removed=[];kept=[];cells=load(OLD/'cells.json')
for cell in cells:
    a,b,c,d=cell['bounds_units1000'];cover=next((p['index'] for p in points if max((p['point_units1000'][0]-a)**2,(p['point_units1000'][0]-c)**2)+max((p['point_units1000'][1]-b)**2,(p['point_units1000'][1]-d)**2)<109112**2),None)
    if cover is not None:removed.append({'cell':cell['index'],'kind':'floor_safe_inner_disk','point':cover});continue
    found=next((r['index'] for r in boxes if r['bounds_units1000'][0]<=a and r['bounds_units1000'][1]<=b and c<=r['bounds_units1000'][2] and d<=r['bounds_units1000'][3]),None)
    if found is None:kept.append(cell['index'])
    else:removed.append({'cell':cell['index'],'kind':'floor_safe_support_vertex','box':found})
assert removed==load(BASE/'excluded-cells.json') and kept==load(BASE/'retained-cell-indices.json') and sorted(kept+[r['cell'] for r in removed])==list(range(len(cells)));assert {132,1038}<={r['cell'] for r in removed}
write(OUT/'necessity-proof.json',{'statement':'For any original cog angle and any chosen exact unit normal n, rotating the already audited all-angle support statement gives a source vertex v with p=n dot v>=h. Its norm is at mostR, so p<=R and its transverse coordinate q satisfies q squared<=R squared-h squared<=beta squared. The four corners of [h,R]x[-beta,beta] bound both coordinates of v=n*p+t*q exactly. For every rounded center in a retained forbidden box and every fractional offset in closed[0,1]^2 micrometres, all such support-vertex coordinates lie strictly inside a current source-contained rectangle; the2-micrometre inset is checked with exact rationals. This necessarily collides with the fixed filled outer. Separately, a whole rounded cell strictly within109112 micrometres of a fixed source point is within109114 of that point after any rounding offset of norm<2, strictly inside the original109115 inner disk. Thus no source-feasible floor-rounded center can belong to any removed cell. Removing these61 cells from the complete1111-cell map preserves every valid15-cog layout, for arbitrary original rotations and continuous positions, with the two inserts still relaxed away. Sampled-angle failures play no role in the proof.'});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_vertices_rebound_exactly':80,'exact_unit_normals_verified':28,'support_boxes_verified':len(boxes),'exact_rounding_margin_checks':margin_checks,'current_fixed_points_verified':len(points),'excluded_cells_verified':len(removed),'retained_cells_verified':len(kept),'excluded_by_disk':sum(r['kind']=='floor_safe_inner_disk' for r in removed),'excluded_by_vertex':sum(r['kind']=='floor_safe_support_vertex' for r in removed),'previous_failed_sample_cells_proved_excluded':[132,1038],'all_angles_and_continuous_positions_covered':True,'sampled_failures_used_as_proof':False,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
