"""New exact all-angle support-vertex exclusions, safe for floor-rounded centers."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-paired-strip-oblique-capacity-20261026';OLD=ROOT/'output/h5-paired-strip-capacity-cells-20261026';SUPPORT=ROOT/'output/h5-paired-strip-support-domains-20261026';REF=ROOT/'output/h5-paired-strip-refined-domains-20261026';GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[OLD/'cells.json',OLD/'model/model.pb',OLD/'model/model.pbtxt',OLD/'model/checks.json',OLD/'audit/checks.json',OLD/'response-audit/checks.json',OLD/'response-audit/selected-cells.json',SUPPORT/'fixed-source-rectangles.json',SUPPORT/'audit/checks.json',REF/'source-points.json',REF/'audit/checks.json',GEOM/'original-cog-proof.json',GEOM/'audit/checks.json',ROOT/'output/h5-paired-strip-source-cell-proposals-20261026/audit/checks.json'];assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Strengthen the complete necessary cell model using new universal source-geometry certificates, not sampled-angle failures. For28 exact rational unit normals, every original cog orientation has a support vertex with longitudinal coordinate at least139270 and at most140001 micrometres; its transverse magnitude is at most15000 by the audited outer-radius bound. Enclose all such support vertices in exact rational coordinate boxes. A center translated into a corresponding eroded fixed rectangle necessarily puts that original vertex strictly inside a proved current source rectangle. Inset the resulting forbidden center rectangle by2micrometres to cover every submicrometre floor-rounding remainder. Also use current fixed source points with a109112-micrometre disk, leaving more than2micrometres before the original109115 inner radius. Remove a whole cell only when one such exact certificate covers it. Retain every other cell unchanged. Independently audit all formulas and source bindings, then append one zero-sum row for excluded Booleans to the exact unchanged parent model. One new20/30-second call only; the prior positive capacity call and finite source sampling remain closed. All15 cogs remain required; two inserts remain relaxed only in this necessity check.','support_units1000':139270,'outer_radius_units1000':140001,'transverse_bound_units1000':15000,'fixed_point_exclusion_radius_units1000':109112,'source_inner_radius_units1000':109115,'forbidden_box_inset_units1000':2,'maximum_solver_calls':1,'solver_seconds':20,'shared_seconds':30})
normals=set()
for x,y,z in [(1,0,1),(3,4,5),(5,12,13),(20,21,29)]:
    for a,b in [(x,y),(y,x)]:
        for sx in [-1,1]:
            for sy in [-1,1]:normals.add((sx*a,sy*b,z))
normals=sorted(normals);assert len(normals)==28 and all(x*x+y*y==z*z for x,y,z in normals);rects=load(SUPPORT/'fixed-source-rectangles.json');boxes=[];h,R,beta=139270,140001,15000
for r in rects:
    a,b,c,d=r['world_inner_rectangle_units1000']
    for ni,(nx,ny,den) in enumerate(normals):
        lx=F(min(nx*h,nx*R)-abs(ny)*beta,den);ux=F(max(nx*h,nx*R)+abs(ny)*beta,den);ly=F(min(ny*h,ny*R)-abs(nx)*beta,den);uy=F(max(ny*h,ny*R)+abs(nx)*beta,den);bb=[math.ceil(F(a)-lx)+2,math.ceil(F(b)-ly)+2,math.floor(F(c)-ux)-2,math.floor(F(d)-uy)-2]
        if bb[0]<bb[2] and bb[1]<bb[3]:boxes.append({'index':len(boxes),'rectangle':r['index'],'normal':ni,'support_coordinate_intervals_rational':[[v.numerator,v.denominator] for v in [lx,ux,ly,uy]],'bounds_units1000':bb})
points=load(REF/'source-points.json');array=np.asarray([r['point_units1000'] for r in points],dtype=np.int64);removed=[];kept=[];cells=load(OLD/'cells.json')
for cell in cells:
    a,b,c,d=cell['bounds_units1000'];dx=np.maximum(np.abs(array[:,0]-a),np.abs(array[:,0]-c));dy=np.maximum(np.abs(array[:,1]-b),np.abs(array[:,1]-d));cover=np.flatnonzero(dx*dx+dy*dy<109112**2)
    if len(cover):removed.append({'cell':cell['index'],'kind':'floor_safe_inner_disk','point':int(cover[0])});continue
    box=next((q for q in boxes if q['bounds_units1000'][0]<=a and q['bounds_units1000'][1]<=b and c<=q['bounds_units1000'][2] and d<=q['bounds_units1000'][3]),None)
    if box is not None:removed.append({'cell':cell['index'],'kind':'floor_safe_support_vertex','box':box['index']})
    else:kept.append(cell['index'])
write(OUT/'unit-normals.json',[list(n) for n in normals]);write(OUT/'support-vertex-boxes.json',boxes);write(OUT/'excluded-cells.json',removed);write(OUT/'retained-cell-indices.json',kept);old_selected=[r['index'] for r in load(OLD/'response-audit/selected-cells.json')];write(OUT/'result.json',{'seconds':time.perf_counter()-start,'exact_unit_normals':28,'support_vertex_boxes':len(boxes),'excluded_cells':len(removed),'retained_cells':len(kept),'excluded_by_disk':sum(r['kind']=='floor_safe_inner_disk' for r in removed),'excluded_by_vertex':sum(r['kind']=='floor_safe_support_vertex' for r in removed),'previous_selected_cells_excluded':[i for i in old_selected if i not in set(kept)],'sampled_angle_failure_used_as_exclusion':False,'all_original_rotations_covered':True,'all15_cogs_required':True,'two_inserts_still_required':True,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
