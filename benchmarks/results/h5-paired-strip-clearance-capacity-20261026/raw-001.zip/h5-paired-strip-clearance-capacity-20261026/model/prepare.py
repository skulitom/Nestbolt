"""Preserve the audited oblique parent and add one exact required-clearance row."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-clearance-capacity-20261026';PARENT=ROOT/'output/h5-paired-strip-oblique-capacity-20261026';OUT=BASE/'model'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(BASE/'audit/checks.json')['passed'] and load(PARENT/'model/checks.json')['passed']
removed=[r['cell'] for r in load(BASE/'new-excluded-cells.json')];assert len(removed)==len(set(removed))==5
assert not set(removed)&{r['cell'] for r in load(PARENT/'excluded-cells.json')}
inputs=[BASE/'plan.json',BASE/'new-excluded-cells.json',BASE/'audit/checks.json',BASE/'audit/necessity-proof.json',PARENT/'model/model.pb',PARENT/'model/checks.json',PARENT/'excluded-cells.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Append exactly one zero-sum equality over the five new independently certified required-clearance cell exclusions to the unchanged oblique parent. Preserve all1111 Boolean variables, fifteen occupied-cell requirement, complete distance-conflict graph, and prior61 cell exclusions. Compare the complete serialized model to this exact parent plus one row, then allow one20-second solver call within30 shared seconds. No retry, reseed or extension. Both remaining inserts stay required for any full layout.','maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0})
parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'model/model.pb').read_bytes());assert len(parent.constraints)==1817
expected=cp_model_pb2.CpModelProto();expected.CopyFrom(parent);row=expected.constraints.add().linear;row.vars.extend(removed);row.coeffs.extend([1]*len(removed));row.domain.extend([0,0])
model=cp_model.CpModel();assert model.proto.parse_text_format(text_format.MessageToString(expected)) and model.validate()==''
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'))
saved=cp_model_pb2.CpModelProto();saved.ParseFromString((OUT/'model.pb').read_bytes());assert saved==expected and text_format.Parse((OUT/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())==expected
copy=cp_model_pb2.CpModelProto();copy.CopyFrom(saved);del copy.constraints[-1];assert copy==parent and not saved.HasField('objective') and not saved.solution_hint.vars
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':len(saved.variables),'constraints':len(saved.constraints),'parent_constraints_unchanged':len(parent.constraints),'new_exact_exclusion_rows':1,'new_excluded_cells':len(removed),'previous_excluded_cells':61,'required_occupied_cells':15,'complete_parent_proto_equality':True,'exact_added_row_verified':True,'model_sha256':digest(OUT/'model.pb'),'source_geometry_audit_sha256':digest(BASE/'audit/checks.json'),'solver_calls':0,'H5_complete':False})
s=(ROOT/'output/run_h5_paired_strip_oblique_model.py').read_text(encoding='utf-8').replace('h5-paired-strip-oblique-capacity-20261026','h5-paired-strip-clearance-capacity-20261026')
with (ROOT/'output/run_h5_paired_strip_clearance_model.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print(load(OUT/'checks.json'))
