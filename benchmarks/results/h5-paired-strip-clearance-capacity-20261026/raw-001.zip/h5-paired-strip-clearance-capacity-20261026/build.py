"""Join current rectangle clearance neighborhoods with exact integer coverage."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-paired-strip-clearance-capacity-20261026';OBLIQUE=ROOT/'output/h5-paired-strip-oblique-capacity-20261026';OLD=ROOT/'output/h5-paired-strip-capacity-cells-20261026';SUPPORT=ROOT/'output/h5-paired-strip-support-domains-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[JOB,SUPPORT/'fixed-source-rectangles.json',SUPPORT/'audit/checks.json',OBLIQUE/'audit/checks.json',OBLIQUE/'unit-normals.json',OBLIQUE/'excluded-cells.json',OBLIQUE/'model/model.pb',OBLIQUE/'model/checks.json',OBLIQUE/'response-audit/checks.json',OBLIQUE/'response-audit/selected-cells.json',OLD/'cells.json',ROOT/'output/h5-paired-strip-oblique-source-cell-proposals-20261026/audit/checks.json'];assert all(load(p)['passed'] for p in inputs if p.name=='checks.json');clearance=F(load(JOB)['clearance'])*1000;assert 2*140**2<clearance**2
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'expanded_rectangle_units1000':140,'fixed_point_radius_units1000':109112,'source_inner_radius_units1000':109115,'method':'Use the required original0.2mm pair clearance, previously relaxed away in domain construction. Expand each proved current source-contained rectangle by140 micrometres in both axes. Every expanded point is within sqrt(2)*140<200 micrometres of a true fixed source point, so no valid moving cog point can enter it. Partition the union at every integer edge, retaining cells only when entirely covered by an expanded rectangle; merge only exact adjacent cells. These merged rectangles are clearance-forbidden regions, not new physical artwork. Generate the same exact all-angle support-vertex center boxes and inner-disk exclusions against them, with2micrometre/3micrometre rounding safeguards. Remove whole current occupancy cells only by these certified conditions. Keep all prior61 exclusions. Independently check exact union coverage and every new exclusion before appending a new zero row to the unchanged oblique parent model. One additional20/30-second mathematical necessity call; no retry of earlier models. Sampled failures are not certificates. All15 cogs remain required and both inserts remain required for any full layout.','maximum_solver_calls':1,'solver_seconds':20,'shared_seconds':30})
rects=load(SUPPORT/'fixed-source-rectangles.json');expanded=[{'index':r['index'],'source_rectangle':r['index'],'bounds_units1000':[r['world_inner_rectangle_units1000'][0]-140,r['world_inner_rectangle_units1000'][1]-140,r['world_inner_rectangle_units1000'][2]+140,r['world_inner_rectangle_units1000'][3]+140]} for r in rects];xs=sorted({b['bounds_units1000'][i] for b in expanded for i in [0,2]});ys=sorted({b['bounds_units1000'][i] for b in expanded for i in [1,3]});atoms=[]
for xi,(a,c) in enumerate(zip(xs,xs[1:])):
    for yi,(b,d) in enumerate(zip(ys,ys[1:])):
        owner=next((r['index'] for r in expanded if r['bounds_units1000'][0]<=a and r['bounds_units1000'][1]<=b and c<=r['bounds_units1000'][2] and d<=r['bounds_units1000'][3]),None)
        if owner is not None:atoms.append({'index':len(atoms),'grid':[xi,yi],'bounds_units1000':[a,b,c,d],'expanded_rectangle':owner})
merged=[{'bounds_units1000':r['bounds_units1000'],'atoms':[r['index']]} for r in atoms];changed=True
while changed:
    changed=False
    for axis in [0,1]:
        other=1-axis;groups={}
        for r in merged:
            b=r['bounds_units1000'];groups.setdefault((b[other],b[other+2]),[]).append(r)
        rows=[]
        for _,group in sorted(groups.items()):
            active=None
            for r in sorted(group,key=lambda r:r['bounds_units1000'][axis]):
                b=list(r['bounds_units1000'])
                if active is not None and active['bounds_units1000'][axis+2]==b[axis]:active['bounds_units1000'][axis+2]=b[axis+2];active['atoms']+=r['atoms'];changed=True
                else:
                    if active is not None:rows.append(active)
                    active={'bounds_units1000':b,'atoms':list(r['atoms'])}
            if active is not None:rows.append(active)
        merged=rows
merged.sort(key=lambda r:tuple(r['bounds_units1000']));merged=[{'index':i,**r} for i,r in enumerate(merged)];normals=load(OBLIQUE/'unit-normals.json');boxes=[];points=[];seen=set();h,R,beta=139270,140001,15000
for r in merged:
    a,b,c,d=r['bounds_units1000']
    for ni,(nx,ny,den) in enumerate(normals):
        lx=F(min(nx*h,nx*R)-abs(ny)*beta,den);ux=F(max(nx*h,nx*R)+abs(ny)*beta,den);ly=F(min(ny*h,ny*R)-abs(nx)*beta,den);uy=F(max(ny*h,ny*R)+abs(nx)*beta,den);bb=[math.ceil(F(a)-lx)+2,math.ceil(F(b)-ly)+2,math.floor(F(c)-ux)-2,math.floor(F(d)-uy)-2]
        if bb[0]<bb[2] and bb[1]<bb[3]:boxes.append({'index':len(boxes),'clearance_rectangle':r['index'],'normal':ni,'bounds_units1000':bb})
    for x in list(range(a,c,50000))+[c]:
        for y in list(range(b,d,50000))+[d]:
            if (x,y) not in seen:seen.add((x,y));points.append({'index':len(points),'clearance_rectangle':r['index'],'point_units1000':[x,y]})
array=np.asarray([p['point_units1000'] for p in points],dtype=np.int64);removed=[];previous={r['cell'] for r in load(OBLIQUE/'excluded-cells.json')};cells=load(OLD/'cells.json')
for cell in cells:
    if cell['index'] in previous:continue
    a,b,c,d=cell['bounds_units1000'];dx=np.maximum(np.abs(array[:,0]-a),np.abs(array[:,0]-c));dy=np.maximum(np.abs(array[:,1]-b),np.abs(array[:,1]-d));cover=np.flatnonzero(dx*dx+dy*dy<109112**2)
    if len(cover):removed.append({'cell':cell['index'],'kind':'clearance_inner_disk','point':int(cover[0])});continue
    q=next((r for r in boxes if r['bounds_units1000'][0]<=a and r['bounds_units1000'][1]<=b and c<=r['bounds_units1000'][2] and d<=r['bounds_units1000'][3]),None)
    if q is not None:removed.append({'cell':cell['index'],'kind':'clearance_support_vertex','box':q['index']})
kept=[r['index'] for r in cells if r['index'] not in previous|{r['cell'] for r in removed}]
for name,value in [('expanded-rectangles.json',expanded),('union-grid.json',{'x':xs,'y':ys}),('union-atoms.json',atoms),('merged-clearance-rectangles.json',merged),('support-vertex-boxes.json',boxes),('clearance-points.json',points),('new-excluded-cells.json',removed),('retained-cell-indices.json',kept)]:write(OUT/name,value)
selected=[r['index'] for r in load(OBLIQUE/'response-audit/selected-cells.json')];write(OUT/'result.json',{'seconds':time.perf_counter()-start,'source_rectangles':len(rects),'expanded_rectangles':len(expanded),'exact_union_atoms':len(atoms),'merged_clearance_rectangles':len(merged),'support_vertex_boxes':len(boxes),'clearance_points':len(points),'previous_exclusions':len(previous),'new_exclusions':len(removed),'retained_cells':len(kept),'previous_selected_cells_newly_excluded':[i for i in selected if i in {r['cell'] for r in removed}],'sampled_failures_used_as_exclusions':False,'all_original_rotations_covered':True,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
