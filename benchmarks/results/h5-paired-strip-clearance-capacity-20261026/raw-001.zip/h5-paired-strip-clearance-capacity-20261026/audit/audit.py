"""Independent exact coverage, required-clearance and all-angle exclusion checks."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product, combinations
from hashlib import sha256
import json, math, shutil, time
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-paired-strip-clearance-capacity-20261026'
OUT=BASE/'audit'
OLD=ROOT/'output/h5-paired-strip-capacity-cells-20261026'
PARENT=ROOT/'output/h5-paired-strip-oblique-capacity-20261026'
SUPPORT=ROOT/'output/h5-paired-strip-support-domains-20261026'
load=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def inside(a,b):return b[0]<=a[0] and b[1]<=a[1] and a[2]<=b[2] and a[3]<=b[3]
def area(a):return (a[2]-a[0])*(a[3]-a[1])
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'audit/checks.json')['passed'] and load(SUPPORT/'audit/checks.json')['passed']
clearance=F(load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json')['clearance'])*1000
assert clearance>=200 and 2*140**2<200**2
source=load(SUPPORT/'fixed-source-rectangles.json');expanded=load(BASE/'expanded-rectangles.json')
assert len(source)==len(expanded)==46
for i,(s,e) in enumerate(zip(source,expanded)):
    a,b,c,d=s['world_inner_rectangle_units1000']
    assert e=={'index':i,'source_rectangle':i,'bounds_units1000':[a-140,b-140,c+140,d+140]}
    assert s['index']==i
grid=load(BASE/'union-grid.json')
assert grid=={'x':sorted({r['bounds_units1000'][i] for r in expanded for i in (0,2)}),'y':sorted({r['bounds_units1000'][i] for r in expanded for i in (1,3)})}
expected=[]
for xi in range(len(grid['x'])-1):
    for yi in range(len(grid['y'])-1):
        box=[grid['x'][xi],grid['y'][yi],grid['x'][xi+1],grid['y'][yi+1]]
        owners=[r['index'] for r in expanded if inside(box,r['bounds_units1000'])]
        if owners:expected.append({'index':len(expected),'grid':[xi,yi],'bounds_units1000':box,'expanded_rectangle':owners[0]})
atoms=load(BASE/'union-atoms.json');assert atoms==expected
merged=load(BASE/'merged-clearance-rectangles.json');seen=[];pair_checks=0
for i,r in enumerate(merged):
    assert r['index']==i and area(r['bounds_units1000'])>0 and r['atoms']
    members=[atoms[k] for k in r['atoms']];assert len(set(r['atoms']))==len(members)
    assert all(inside(a['bounds_units1000'],r['bounds_units1000']) for a in members)
    assert sum(area(a['bounds_units1000']) for a in members)==area(r['bounds_units1000'])
    for a,b in combinations(members,2):
        aa,bb=a['bounds_units1000'],b['bounds_units1000'];pair_checks+=1
        assert min(aa[2],bb[2])<=max(aa[0],bb[0]) or min(aa[3],bb[3])<=max(aa[1],bb[1])
    seen+=r['atoms']
assert sorted(seen)==list(range(len(atoms)))
assert sum(area(r['bounds_units1000']) for r in merged)==sum(area(r['bounds_units1000']) for r in atoms)
h,R,beta=139270,140001,15000;assert R*R-h*h<=beta*beta and 109112+2<109115
normals=load(PARENT/'unit-normals.json');assert len(normals)==28 and all(x*x+y*y==d*d and d>0 for x,y,d in normals)
boxes=[];points=[];seen=set();margin_checks=0
for r in merged:
    a,b,c,d=r['bounds_units1000']
    for ni,(nx,ny,den) in enumerate(normals):
        corners=[(F(nx*p-ny*q,den),F(ny*p+nx*q,den)) for p,q in product([h,R],[-beta,beta])]
        lx=min(v[0] for v in corners);ux=max(v[0] for v in corners);ly=min(v[1] for v in corners);uy=max(v[1] for v in corners)
        bb=[math.ceil(a-lx)+2,math.ceil(b-ly)+2,math.floor(c-ux)-2,math.floor(d-uy)-2]
        if bb[0]<bb[2] and bb[1]<bb[3]:
            assert bb[0]+lx>a and bb[1]+ly>b and bb[2]+1+ux<c and bb[3]+1+uy<d
            margin_checks+=4;boxes.append({'index':len(boxes),'clearance_rectangle':r['index'],'normal':ni,'bounds_units1000':bb})
    for x in list(range(a,c,50000))+[c]:
        for y in list(range(b,d,50000))+[d]:
            if (x,y) not in seen:
                seen.add((x,y));assert a<=x<=c and b<=y<=d
                points.append({'index':len(points),'clearance_rectangle':r['index'],'point_units1000':[x,y]})
assert boxes==load(BASE/'support-vertex-boxes.json') and points==load(BASE/'clearance-points.json')
previous={r['cell'] for r in load(PARENT/'excluded-cells.json')};assert len(previous)==61
removed=[];kept=[];cells=load(OLD/'cells.json')
for cell in cells:
    i=cell['index']
    if i in previous:continue
    a,b,c,d=cell['bounds_units1000']
    point=next((p['index'] for p in points if max((p['point_units1000'][0]-a)**2,(p['point_units1000'][0]-c)**2)+max((p['point_units1000'][1]-b)**2,(p['point_units1000'][1]-d)**2)<109112**2),None)
    if point is not None:removed.append({'cell':i,'kind':'clearance_inner_disk','point':point});continue
    box=next((r['index'] for r in boxes if inside(cell['bounds_units1000'],r['bounds_units1000'])),None)
    if box is not None:removed.append({'cell':i,'kind':'clearance_support_vertex','box':box})
    else:kept.append(i)
assert removed==load(BASE/'new-excluded-cells.json') and kept==load(BASE/'retained-cell-indices.json')
assert sorted(list(previous)+[r['cell'] for r in removed]+kept)==list(range(len(cells)))
write(OUT/'necessity-proof.json',{'statement':'Every point in a source-contained rectangle expanded by140 micrometres on each axis is within Euclidean distance at most sqrt(39200)<200 micrometres of a point of a true fixed filled outer. A valid moving filled outer must stay at least200 micrometres away. Exact Cartesian atoms and disjoint-interior equal-area coverage prove each merged rectangle consists entirely of such forbidden points. The closed atoms have no uncovered line gaps: a finite closed union with equal area and no interior overlap fills its enclosing rectangle. These are clearance exclusion regions only, not modified physical parts. For every original cog rotation, each audited unit normal admits a source vertex with longitudinal coordinate p in[h,R] and transverse q in[-beta,beta]. Exact rational bounding corners and four strict margin inequalities place that vertex within a merged forbidden rectangle for every rounded center in its support box and every fractional rounding offset in closed[0,1]^2 micrometres. Alternatively, a forbidden point within109112 micrometres of every rounded center remains within109114 after rounding of norm<2, strictly inside the original109115 inner disk. Each removed occupancy cell is wholly contained in one such proven exclusion. Previous61 excluded cells remain unchanged. Thus all source-feasible continuous cog centers and arbitrary original angles remain covered by the retained cells. The original two inserts are relaxed only for this necessary test and remain required for a full66 layout. Sampled angle failures are not used in the proof.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_rectangles_verified':len(source),'clearance_expansions_verified':len(expanded),'exact_union_atoms_verified':len(atoms),'merged_clearance_rectangles_verified':len(merged),'atom_pair_interior_checks':pair_checks,'support_boxes_verified':len(boxes),'rounding_margin_checks':margin_checks,'clearance_points_verified':len(points),'previous_exclusions_preserved':len(previous),'new_exclusions_verified':len(removed),'retained_cells_verified':len(kept),'all_angles_and_continuous_positions_covered':True,'sampled_failures_used_as_proof':False,'source_geometry_changed':False,'solver_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
