"""Independently verify every accepted and rejected finite source proposal."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-oblique-source-cell-proposals-20261026';OUT=BASE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};spec=load(ROOT/'output/h5-paired-strip-core-20261026/audit/next-neighborhood.json');cells=load(ROOT/'output/h5-paired-strip-oblique-capacity-20261026/response-audit/selected-cells.json');pool=load(BASE/'candidates.json');events=load(BASE/'events.json');guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];bounds=[m['left']+e+guard,m['bottom']+e+guard,st['width']-m['right']-e-guard,st['height']-m['top']-e-guard]
def shape(p):
    t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[p['part_id']]['geometry'][0]['outer']])
fixed=np.asarray([shape(p) for p in spec['fixed_first_placements']],dtype=object);seen={};accepted=[];counts=Counter();rejections=Counter();queries={}
for ev in events:
    o=ev['source']
    if o['kind']=='cell_cog':
        group=o['cog_group'];cell=cells[group];assert cell['index']==o['cell'] and o['original']==51+group;a,b,c,d=cell['bounds_units1000'];fx,fy=o['fractions'];assert fx in [0,.5,1] and fy in [0,.5,1] and o['degrees'] in [i/2 for i in range(36)];cx=(a+fx*(c-a))/1000;cy=(b+fy*(d-b))/1000;assert o['center_mm']==[cx,cy];angle=math.radians(o['degrees']);co,si=math.cos(angle),math.sin(angle);family='cog';translation=[cx-139.723742*co+139.723742*si,cy-139.723742*si-139.723742*co]
    else:
        assert o['kind']=='insert_free_region';q=o['orientation'];assert q in [0,1]
        if q not in queries:queries[q]=load(BASE/'regions'/f'insert-{q}.json')
        family='insert';angle=q*math.pi/2;translation=queries[q]['proposals'][o['proposal']]['point'];group='insert'
    p={'part_id':family,'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':False,'translation':translation}};key=(family,float(angle).hex(),*(float(v).hex() for v in translation));index=None
    if key in seen:status='duplicate';index=seen[key]
    else:
        g=shape(p);bb=g.bounds
        if not(bb[0]>bounds[0] and bb[1]>bounds[1] and bb[2]<bounds[2] and bb[3]<bounds[3]):status='stock'
        else:
            distance=float(np.min(shapely.distance(g,fixed)))
            if distance<=required:status='fixed_geometry'
            else:
                index=len(accepted);status='added';seen[key]=index;assert pool[index]['index']==index and pool[index]['placement']==p and pool[index]['source']==o and abs(pool[index]['fixed_minimum_distance_mm']-distance)<1e-8;accepted.append(index);counts[group]+=1
    assert status==ev['result'] and index==ev['candidate'];rejections[status]+=1
assert len(accepted)==len(pool) and len(events)==4914 and [i for i in range(15) if counts[i]==0]==load(BASE/'result.json')['empty_cell_groups']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'proposals_verified':len(events),'accepted_poses_verified':len(accepted),'accepted_cog_counts':[counts[i] for i in range(15)],'insert_candidates_verified':counts['insert'],'classification_counts':dict(rejections),'empty_cell_groups':[i for i in range(15) if counts[i]==0],'solver_opened':False,'finite_sample_only':True,'no_continuous_cell_exclusion_inferred':True,'all15_cogs_and2_inserts_still_required':True,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
