"""Independent source vertices and rational anchor formulas for all49 originals."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-core-20261026';OUT=BASE/'audit';SRC=ROOT/'output/h5-source-orientation-construction-20261025';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};rows=load(BASE/'placements.json');first=[p for p in rows if p['sheet_id']=='sheet-0'];short=[p for p in rows if p['sheet_id']=='sheet-1'];assert len(first)==34 and len(short)==15 and short==load(ROOT/'output/h5-nine-insert-short-sheet-20261026/short-sheet-placements.json')
expected={}
for i in range(16):
    r,c=divmod(i,4);expected[i]=(F('6.525')+c*F('350.225'),F('6.525')+r*F('670.675' if c==3 else '450.225'),1,False)
expected.update({16:(F('6.525'),F('1807.425'),0,False),17:(F('456.75'),F('1807.425'),0,False)})
brackets=[18,19,20,23,24,27]
for k in range(3):
    y=F('456.75')+k*F('670.675');expected[brackets[2*k]]=(F('1243.475'),y-200,1,True);expected[brackets[2*k+1]]=(F('1243.475'),y+F('100.225'),1,False)
    for j in range(2):expected[38+2*k+j]=(F('1057.2'),y+j*F('110.225'),0,False)
for k in range(4):expected[44+k]=(F('906.975'),F('1807.65')+k*F('180.225'),1,False)
stocks=[[float(F(*v)) for v in r] for r in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);shapes={};holes=vertices=0;stock=[]
for p in rows:
    original=ids[p['part_id'],p['copy_index']];assert original not in shapes;t=p['transform'];part=parts[p['part_id']];assert not t['mirrored'] or part['allow_mirror'];assert part['rotations']['kind']=='list' and any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-12 for a in part['rotations']['degrees']);c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation'];g=part['geometry'][0]
    def ring(r):return [(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in r]
    filled=Polygon(ring(g['outer']));full=Polygon(ring(g['outer']),[ring(h) for h in g.get('holes',[])]);assert filled.is_valid and full.is_valid and abs(filled.area-Polygon(g['outer']).area)<1e-6 and abs(full.area-Polygon(g['outer'],g.get('holes',[])).area)<1e-6;sheet=int(p['sheet_id'].split('-')[1]);b=filled.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;stock.append({'original':original,'margins_mm':extra});shapes[original]=(sheet,filled);holes+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]))
    if sheet==0:
        x,y,q,mirror=expected[original];assert t['mirrored']==mirror and t['rotation_radians']==q*math.pi/2 and max(abs(b[0]-float(x)),abs(b[1]-float(y)))<1e-9
assert set(expected)=={ids[p['part_id'],p['copy_index']] for p in first};pairs=[]
for i,j in combinations(sorted(shapes),2):
    a,p=shapes[i];b,q=shapes[j]
    if a==b:d=p.distance(q);assert p.disjoint(q) and d>required;pairs.append({'originals':[i,j],'distance_mm':d})
remaining=sorted(set(range(66))-set(shapes));assert remaining==[48,49]+list(range(51,66))==load(BASE/'mandatory-remaining-originals.json')
def area(r):return abs(sum(F(x)*F(v)-F(y)*F(u) for (x,y),(u,v) in zip(r,r[1:]+r[:1])))/2
old=load(ROOT/'output/h5-staggered-frame-bracket-core-repaired-20261026/placements.json');oldarea=sum(area(parts[p['part_id']]['geometry'][0]['outer']) for p in old if p['sheet_id']=='sheet-0');newarea=sum(area(parts[p['part_id']]['geometry'][0]['outer']) for p in first);assert newarea-oldarea==219000
inventory={'fixed_first_originals':sorted(expected),'fixed_first_placements':first,'fixed_short_originals':sorted(ids[p['part_id'],p['copy_index']] for p in short),'fixed_short_placements':short,'mandatory_moving_first_originals':remaining,'mandatory_moving_first_cogs':list(range(51,66)),'mandatory_moving_first_noncogs':[48,49],'mandatory_moving_family_counts':{'insert':2,'cog':15},'all17_movers_mandatory':True,'all66_originals_accounted_once':True,'prior_cog_poses_asserted_feasible':False,'old_domains_or_exclusions_transferred':False};write(OUT/'next-neighborhood.json',inventory);write(OUT/'pair-readback.json',pairs);write(OUT/'stock-readback.json',stock)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_verified':49,'fixed_first_originals':34,'fixed_short_originals':15,'mandatory_remaining_counts':inventory['mandatory_moving_family_counts'],'all66_originals_accounted_once':True,'same_sheet_pairs':len(pairs),'stock_edge_checks':196,'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_pair_gap_mm':min(p['distance_mm'] for p in pairs),'minimum_extra_stock_mm':min(min(p['margins_mm']) for p in stock),'required_native_pair_gap_mm':required,'previous_first_filled_area_mm2':float(oldarea),'new_first_filled_area_mm2':float(newarea),'remaining_first_filled_demand_reduction_mm2':219000,'highest_fixed_first_y_mm':max(g.bounds[3] for s,g in shapes.values() if s==0),'short_sheet_exactly_preserved':True,'all34_first_anchors_reconstructed_from_rationals':True,'part_in_hole_used':False,'old64_partial_preserved':True,'old_domains_or_exclusions_transferred':False,'solver_calls':0,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
