"""Place all brackets using paired side-strip feet, retaining all17 missing originals."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-paired-strip-core-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';SRC=ROOT/'output/h5-source-orientation-construction-20261025';OLD=ROOT/'output/h5-staggered-frame-bracket-core-repaired-20261026';SHORT=ROOT/'output/h5-nine-insert-short-sheet-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[JOB,SRC/'items.json',SRC/'geometry.json',OLD/'placements.json',OLD/'audit/checks.json',SHORT/'short-sheet-placements.json',SHORT/'audit/checks.json',ROOT/'output/h5-staggered-core-contact-pool-20261026/response-audit-worker-table-repaired/checks.json'];assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'A changed side-strip composition after the former finite pool is closed. Preserve fifteen short originals. Keep twelve turned frames in their first three columns and two adjacent unturned upper frames. Place the fourth column of four turned frames at670.675mm row spacing. In each220.225mm-high guarded gap, use a mirrored90-degree bracket with its foot at the bottom of the gap and its stem extending downward, followed by an unmirrored90-degree bracket with its foot100.225mm higher and its stem extending upward. Put two180x110 inserts beside those feet. Four vertical110x180 inserts occupy the opening next to the upper frames. All six first-sheet brackets and ten first-sheet inserts are fixed, leaving two inserts48/49 and all15 cogs51..65 mandatory. This49-original core is not a higher partial count than the preserved64. The taller right frame column and last notch insert change the remaining region; rebuild exact necessary cog domains before a search. No solver/native call and no full-job material claim.','construction_gap_mm':.225,'extra_stock_mm':.025,'maximum_seconds':30,'first_bracket_originals':[18,19,20,23,24,27],'first_insert_originals':list(range(38,48))})
job=load(JOB);parts={p['id']:p for p in job['parts']};items=load(SRC/'items.json');ids={(p['family'],p['copy']):i for i,p in enumerate(items)};placements=[];anchors=[]
def add(original,angle,mirror,x,y,role):
    family=items[original]['family'];c,s=math.cos(angle),math.sin(angle);m=-1 if mirror else 1;raw=parts[family]['geometry'][0]['outer'];px=min(m*u*c-v*s for u,v in raw);py=min(m*u*s+v*c for u,v in raw);p={'part_id':family,'copy_index':items[original]['copy'],'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':mirror,'translation':[x-px,y-py]}};placements.append(p);anchors.append({'original':original,'lower_left_mm':[x,y],'angle_radians':angle,'mirrored':mirror,'role':role})
for row in range(4):
    for col in range(4):add(4*row+col,math.pi/2,False,6.525+col*350.225,6.525+row*(670.675 if col==3 else 450.225),'right paired-gap frame' if col==3 else 'retained left grid')
for original,x in [(16,6.525),(17,456.75)]:add(original,0.,False,x,1807.425,'adjacent upper frame')
brackets=[18,19,20,23,24,27]
for k in range(3):
    y=456.75+k*670.675;add(brackets[2*k],math.pi/2,True,1243.475,y-200,'lower mirrored stem');add(brackets[2*k+1],math.pi/2,False,1243.475,y+100.225,'upper stem')
    for j in range(2):add(38+2*k+j,0.,False,1057.2,y+j*110.225,'insert beside paired feet')
for k in range(4):add(44+k,math.pi/2,False,906.975,1807.65+k*180.225,'vertical notch insert')
first=list(placements);short=load(SHORT/'short-sheet-placements.json');placements+=short;placed=[ids[p['part_id'],p['copy_index']] for p in placements];remaining=sorted(set(range(66))-set(placed));assert len(set(placed))==len(placements)==49 and len(first)==34 and remaining==[48,49]+list(range(51,66));stocks=[[float(F(*v)) for v in r] for r in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);shapes={};edges=[];holes=vertices=0
for p in placements:
    original=ids[p['part_id'],p['copy_index']];t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;g=parts[p['part_id']]['geometry'][0];a=[m*c,-s,m*s,c,*t['translation']];filled=affine_transform(Polygon(g['outer']),a);full=affine_transform(Polygon(g['outer'],g.get('holes',[])),a);assert filled.is_valid and full.is_valid;sheet=int(p['sheet_id'].split('-')[1]);b=filled.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard,(original,extra);shapes[original]=(sheet,filled);edges.append({'original':original,'bounds_mm':b,'extra_margins_mm':extra});holes+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]))
pairs=[]
for i,j in combinations(sorted(shapes),2):
    sa,a=shapes[i];sb,b=shapes[j]
    if sa==sb:d=a.distance(b);assert a.disjoint(b) and d>required,(i,j,d);pairs.append({'originals':[i,j],'distance_mm':d})
oldfirst=[p for p in load(OLD/'placements.json') if p['sheet_id']=='sheet-0'];oldarea=sum(Polygon(parts[p['part_id']]['geometry'][0]['outer']).area for p in oldfirst);newarea=sum(Polygon(parts[p['part_id']]['geometry'][0]['outer']).area for p in first);assert newarea-oldarea==219000.
for name,value in [('placements.json',placements),('first-sheet-placements.json',first),('anchors.json',anchors),('mandatory-remaining-originals.json',remaining),('pairs.json',pairs),('stock-edges.json',edges)]:write(OUT/name,value)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_placed':49,'first_originals':34,'short_originals':15,'first_counts':dict(Counter(p['part_id'] for p in first)),'mandatory_remaining_counts':dict(Counter(items[i]['family'] for i in remaining)),'all66_originals_accounted_once':True,'same_sheet_pairs':len(pairs),'stock_edge_checks':196,'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_pair_gap_mm':min(p['distance_mm'] for p in pairs),'minimum_extra_stock_mm':min(min(p['extra_margins_mm']) for p in edges),'previous_first_filled_area_mm2':oldarea,'new_first_filled_area_mm2':newarea,'remaining_first_filled_demand_reduction_mm2':219000,'highest_fixed_first_y_mm':max(g.bounds[3] for s,g in shapes.values() if s==0),'right_column_top_mm':2468.55,'old64_partial_preserved':True,'old_domains_or_exclusions_transferred':False,'independent_readback_pending':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
