"""Check actual original poses inside the sole returned necessary15-cell selection."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,mapping
from shapely.affinity import affine_transform
import diagnose_h5_concave_gaps as geom
from build_h5_cog_free_regions import proposals,identity
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-paired-strip-source-cell-proposals-20261026';CORE=ROOT/'output/h5-paired-strip-core-20261026/audit';CAP=ROOT/'output/h5-paired-strip-capacity-cells-20261026/response-audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'regions').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();assert load(CORE/'checks.json')['passed'] and load(CAP/'checks.json')['passed'];job=load(JOB);spec=load(CORE/'next-neighborhood.json');cells=load(CAP/'selected-cells.json');parts={p['id']:p for p in job['parts']};source={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};items=load(ROOT/'output/h5-source-orientation-construction-20261025/items.json');guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);fractions=[0.,.5,1.];phases=[i*.5 for i in range(36)]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [JOB,CORE/'checks.json',CORE/'next-neighborhood.json',CAP/'checks.json',CAP/'selected-cells.json',Path(geom.__file__),ROOT/'output/build_h5_cog_free_regions.py']},'generation_seconds':60,'cog_angles_degrees':phases,'cell_anchor_fractions':fractions,'cog_proposals_per_cell':324,'mandatory_cogs':list(range(51,66)),'mandatory_inserts':[48,49],'method':'Use only the first returned necessary15-cell selection. For each required original cog, sample a3x3 grid over its closed cell and all36 actual half-degree orientations from0 to17.5 degrees. Check each source filled outer directly against all34 fixed originals and guarded stock. Do not assume exact rotational symmetry. Generate both allowed axis-distinct insert orientations from fresh conservative free translation regions against the34 fixed originals, retaining every boundary/representative proposal after source checks. All15 cell groups and both remaining inserts are mandatory. If a cell group is empty, record the finite preflight failure and open no solver; this does not exclude continuous positions or other angles. Otherwise a complete original conflict graph and independent audit are required before one joint source solve. The prior capacity call remains closed; no occupancy-model retry.'})
def shape(p):
    t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;return affine_transform(source[p['part_id']],[m*c,-s,m*s,c,*t['translation']])
fixed=np.asarray([shape(p) for p in spec['fixed_first_placements']],dtype=object);st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];bounds=[m['left']+e+guard,m['bottom']+e+guard,st['width']-m['right']-e-guard,st['height']-m['top']-e-guard];pool=[];events=[];seen={};counts=Counter()
def consider(p,origin):
    assert time.perf_counter()-start<60;key=identity(p)
    if key in seen:return seen[key],'duplicate'
    g=shape(p);bb=g.bounds
    if not(bb[0]>bounds[0] and bb[1]>bounds[1] and bb[2]<bounds[2] and bb[3]<bounds[3]):return None,'stock'
    ds=shapely.distance(g,fixed);distance=float(np.min(ds))
    if distance<=required:return None,'fixed_geometry'
    i=len(pool);pool.append({'index':i,'placement':p,'source':origin,'fixed_minimum_distance_mm':distance});seen[key]=i;counts[origin.get('cog_group','insert')]+=1;return i,'added'
for group,cell in enumerate(cells):
    a,b,c,d=cell['bounds_units1000']
    for fx in fractions:
        for fy in fractions:
            cx=(a+fx*(c-a))/1000;cy=(b+fy*(d-b))/1000
            for degrees in phases:
                angle=math.radians(degrees);co,si=math.cos(angle),math.sin(angle);p={'part_id':'cog','sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':False,'translation':[cx-139.723742*co+139.723742*si,cy-139.723742*si-139.723742*co]}};o={'kind':'cell_cog','cog_group':group,'original':51+group,'cell':cell['index'],'fractions':[fx,fy],'degrees':degrees,'center_mm':[cx,cy]};i,status=consider(p,o);events.append({'source':o,'candidate':i,'result':status})
geom.EPS=.0126
for q in range(2):
    p={'part_id':'insert','sheet_id':'sheet-0','transform':{'rotation_radians':q*math.pi/2,'mirrored':False,'translation':[0.,0.]}};region=geom.regions(shape(p),list(fixed),st,e,required);points=proposals(region);write(OUT/'regions'/f'insert-{q}.json',{'orientation':q,'geometry':mapping(region),'proposals':points})
    for k,row in enumerate(points):
        p={'part_id':'insert','sheet_id':'sheet-0','transform':{'rotation_radians':q*math.pi/2,'mirrored':False,'translation':row['point']}};o={'kind':'insert_free_region','orientation':q,'proposal':k};i,status=consider(p,o);events.append({'source':o,'candidate':i,'result':status})
write(OUT/'candidates.json',pool);write(OUT/'events.json',events);empty=[i for i in range(15) if counts[i]==0];write(OUT/'result.json',{'seconds':time.perf_counter()-start,'candidates':len(pool),'accepted_cog_poses_by_cell':[counts[i] for i in range(15)],'accepted_insert_poses':counts['insert'],'empty_cell_groups':empty,'event_counts':dict(Counter(e['result'] for e in events)),'all15_cogs_and2_inserts_required':True,'solver_eligible':not empty and counts['insert']>=2,'empty_finite_group_not_continuous_exclusion':True,'solver_calls':0,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
