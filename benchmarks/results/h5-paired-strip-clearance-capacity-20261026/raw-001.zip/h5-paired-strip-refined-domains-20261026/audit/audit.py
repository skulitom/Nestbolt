"""Exact integer source-point containment, recursive partition and merged-domain coverage."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-refined-domains-20261026';SUPPORT=ROOT/'output/h5-paired-strip-support-domains-20261026';OUT=BASE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SUPPORT/'audit/checks.json')['passed'];rects=load(SUPPORT/'fixed-source-rectangles.json');points=load(BASE/'source-points.json');nodes=load(BASE/'partition-nodes.json');atoms=load(BASE/'retained-atoms.json');domains=load(BASE/'domains.json');roots=load(SUPPORT/'allowed-closed-cells.json');expected=[];seen=set()
for r in rects:
    a,b,c,d=r['world_inner_rectangle_units1000']
    for x in list(range(a,c,50000))+[c]:
        for y in list(range(b,d,50000))+[d]:
            if (x,y) not in seen:seen.add((x,y));expected.append({'index':len(expected),'rectangle':r['index'],'point_units1000':[x,y]})
assert expected==points;children={};rootnodes={}
for i,row in enumerate(nodes):
    assert row['index']==i
    if row['parent'] is None:assert row['source_cell'] not in rootnodes;rootnodes[row['source_cell']]=i;assert row['bounds_units1000']==roots[row['source_cell']]['bounds_units1000']
    else:assert 0<=row['parent']<i;children.setdefault(row['parent'],[]).append(i);assert row['source_cell']==nodes[row['parent']]['source_cell']
assert sorted(rootnodes)==list(range(len(roots)));excluded=0;retained=[]
for row in nodes:
    a,b,c,d=row['bounds_units1000'];assert a<c and b<d;action=row['action']
    if action=='split':
        assert len(children[row['index']])==2;axis=row['axis'];mid=row['mid'];assert mid==((a+c)//2 if axis==0 else (b+d)//2);lo=[a,b,c,d];hi=[a,b,c,d];lo[axis+2]=mid;hi[axis]=mid;assert [nodes[i]['bounds_units1000'] for i in children[row['index']]]==[lo,hi]
    elif action=='exclude':
        assert row['index'] not in children;pt=points[row['point']];r=rects[pt['rectangle']]['world_inner_rectangle_units1000'];x,y=pt['point_units1000'];assert r[0]<=x<=r[2] and r[1]<=y<=r[3];assert max((x-a)**2,(x-c)**2)+max((y-b)**2,(y-d)**2)<109114**2;excluded+=1
    else:
        assert action in ['retain','retain_budget'] and row['index'] not in children;assert row['atomic_index']==len(retained);retained.append({'index':len(retained),'node':row['index'],'bounds_units1000':row['bounds_units1000']})
assert atoms==retained
def area(b):return (b[2]-b[0])*(b[3]-b[1])
seen=[]
for i,r in enumerate(domains):
    assert r['index']==i and len(set(r['atoms']))==len(r['atoms']);bb=r['bounds_units1000'];bs=[atoms[j]['bounds_units1000'] for j in r['atoms']]
    for b in bs:assert bb[0]<=b[0]<b[2]<=bb[2] and bb[1]<=b[1]<b[3]<=bb[3]
    for a,b in combinations(bs,2):assert min(a[2],b[2])<=max(a[0],b[0]) or min(a[3],b[3])<=max(a[1],b[1])
    assert sum(map(area,bs))==area(bb);seen+=r['atoms']
assert sorted(seen)==list(range(len(atoms)))
for a,b in combinations([r['bounds_units1000'] for r in domains],2):assert min(a[2],b[2])<=max(a[0],b[0]) or min(a[3],b[3])<=max(a[1],b[1])
write(OUT/'necessity-proof.json',{'statement':'Every fresh fixed point is in a current source-contained rectangle already proved by exact trigonometric interval containment. If the farthest corner of a whole closed center cell is strictly closer than109114 micrometres to that point, convexity of the disk contains the entire cell. The source cog contains the109115-micrometre disk for all angles, so those centers necessarily collide. Every split exactly partitions its parent with all boundaries retained; all unexcluded leaves remain. The integer merged rectangles cover all atomic leaves with equal area and no interior overlap. Since all boundaries are integer micrometres, flooring any continuous feasible center remains within a retained closed domain. No remaining insert obstacle is used, making this a permissive necessity condition for all15 cogs.'});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'fresh_source_points_verified':len(points),'partition_nodes_verified':len(nodes),'excluded_nodes_verified':excluded,'retained_atoms_verified':len(atoms),'merged_domains_verified':len(domains),'retained_area_units1000_squared':sum(area(r['bounds_units1000']) for r in domains),'continuous_center_coverage':True,'all15_cogs_required':True,'two_moving_inserts_still_required':True,'old_owner_transforms_used':False,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
