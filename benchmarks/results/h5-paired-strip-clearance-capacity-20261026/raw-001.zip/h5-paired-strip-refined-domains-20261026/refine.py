"""Complete all-angle center domains from exact current contained rectangles and inner disks."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-paired-strip-support-domains-20261026';OUT=ROOT/'output/h5-paired-strip-refined-domains-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'refine.py');start=time.perf_counter();assert load(BASE/'audit/checks.json')['passed'];inputs=[BASE/'audit/checks.json',BASE/'audit/necessity-proof.json',BASE/'fixed-source-rectangles.json',BASE/'allowed-closed-cells.json',BASE/'grid.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'fixed_point_grid_units1000':50000,'strict_disk_radius_units1000':109114,'source_inscribed_radius_units1000':109115,'minimum_split_span_units1000':5000,'maximum_nodes':50000,'maximum_seconds':120,'method':'Generate fresh integer points in each exact-contained current world rectangle, including every boundary and a50mm internal grid. Every point belongs to the fixed filled outer. A cog center at distance strictly below109114 micrometres collides with the audited source inner disk of radius109115 for every rotation. Drop a whole closed cell only when its farthest corner is strictly within one such disk. Bisect unresolved cells at integer midpoints until5mm span; if budget expires, retain every pending whole cell. Integer area partition preserves all continuous feasible centers and their floor-rounded positions. Merge only adjacent whole rectangles with matching transverse extents; preserve atomic membership. This is a necessary domain, not a source-feasible map. All15 cogs remain required; the two moving inserts are ignored only in this permissive preprocessing.'})
rects=load(BASE/'fixed-source-rectangles.json');points=[];seen={}
for r in rects:
    a,b,c,d=r['world_inner_rectangle_units1000'];xs=list(range(a,c,50000))+[c];ys=list(range(b,d,50000))+[d]
    for x in xs:
        for y in ys:
            if (x,y) not in seen:seen[x,y]=len(points);points.append({'index':len(points),'rectangle':r['index'],'point_units1000':[x,y]})
array=np.asarray([p['point_units1000'] for p in points],dtype=np.int64);R=109114;R2=R*R;roots=load(BASE/'allowed-closed-cells.json');queue=[{'parent':None,'source_cell':r['index'],'bounds_units1000':r['bounds_units1000']} for r in reversed(roots)];nodes=[];retained=[];excluded=[];limited=False
while queue:
    row=queue.pop();a,b,c,d=row['bounds_units1000'];index=len(nodes);row={'index':index,**row};nodes.append(row)
    if time.perf_counter()-start>=120 or len(nodes)>=50000:
        row['action']='retain_budget';row['atomic_index']=len(retained);retained.append({'index':len(retained),'node':index,'bounds_units1000':[a,b,c,d]});limited=True;continue
    dx=np.maximum(np.abs(array[:,0]-a),np.abs(array[:,0]-c));dy=np.maximum(np.abs(array[:,1]-b),np.abs(array[:,1]-d));covers=np.flatnonzero(dx*dx+dy*dy<R2)
    if len(covers):row['action']='exclude';row['point']=int(covers[0]);excluded.append(index);continue
    dx=np.maximum(np.maximum(a-array[:,0],array[:,0]-c),0);dy=np.maximum(np.maximum(b-array[:,1],array[:,1]-d),0);touch=np.any(dx*dx+dy*dy<R2)
    if not touch or max(c-a,d-b)<=5000:
        row['action']='retain';row['atomic_index']=len(retained);retained.append({'index':len(retained),'node':index,'bounds_units1000':[a,b,c,d]});continue
    axis=0 if c-a>=d-b else 1;mid=((a+c)//2 if axis==0 else (b+d)//2);lo=[a,b,c,d];hi=[a,b,c,d];lo[axis+2]=mid;hi[axis]=mid;row['action']='split';row['axis']=axis;row['mid']=mid
    for bb in [hi,lo]:queue.append({'parent':index,'source_cell':row['source_cell'],'bounds_units1000':bb})
domains=[{'bounds_units1000':r['bounds_units1000'],'atoms':[r['index']]} for r in retained];changed=True
while changed:
    changed=False
    for axis in [0,1]:
        other=1-axis;groups={}
        for r in domains:
            b=r['bounds_units1000'];groups.setdefault((b[other],b[other+2]),[]).append(r)
        merged=[]
        for key,rows in sorted(groups.items()):
            rows.sort(key=lambda r:r['bounds_units1000'][axis]);active=None
            for row in rows:
                b=list(row['bounds_units1000'])
                if active is not None and active['bounds_units1000'][axis+2]==b[axis]:active['bounds_units1000'][axis+2]=b[axis+2];active['atoms']+=row['atoms'];changed=True
                else:
                    if active is not None:merged.append(active)
                    active={'bounds_units1000':b,'atoms':list(row['atoms'])}
            if active is not None:merged.append(active)
        domains=merged
domains.sort(key=lambda r:tuple(r['bounds_units1000']));domains=[{'index':i,**r} for i,r in enumerate(domains)]
for name,value in [('source-points.json',points),('partition-nodes.json',nodes),('retained-atoms.json',retained),('domains.json',domains)]:write(OUT/name,value)
area=sum((r['bounds_units1000'][2]-r['bounds_units1000'][0])*(r['bounds_units1000'][3]-r['bounds_units1000'][1]) for r in retained);bounds=[min(r['bounds_units1000'][i] for r in retained) if i<2 else max(r['bounds_units1000'][i] for r in retained) for i in range(4)] if retained else None
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'fresh_source_points':len(points),'partition_nodes':len(nodes),'excluded_nodes':len(excluded),'retained_atoms':len(retained),'merged_domains':len(domains),'retained_area_mm2':area/1000000,'retained_bounds_units1000':bounds,'budget_limited':limited,'all_continuous_centers_covered':True,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
