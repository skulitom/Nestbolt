from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_geometric_nine_decision.py').read_text().replace('h5-geometric-nine-decision-20261026','h5-stem-ordered-nine-decision-20261026')
with (ROOT/'output/run_h5_stem_ordered_nine_decision.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_geometric_nine_response.py').read_text().replace('h5-geometric-nine-decision-20261026','h5-stem-ordered-nine-decision-20261026')
s=s.replace("xs=[sol[2*i] for i in slots if presence[i]];assert xs==sorted(xs)","xs=[sol[load(BASE/'stem-variables.json')[i]] if i<6 else sol[2*i] for i in slots if presence[i]];assert xs==sorted(xs)").replace('Check presence prefixes and active x order','Check presence prefixes, active bracket stem order and cog x order')
with (ROOT/'output/audit_h5_stem_ordered_response.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Separate stem-ordered decision runner and response audit prepared.')
