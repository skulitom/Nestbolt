from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for kind in ['run','audit']:
    source=(ROOT/'output'/f'{kind}_h5_core_count_case_2.py').read_text().replace('h5-core-count-partition-20261026/case-002','h5-last-count-bands-20261026')
    if kind=='audit':
        source=source.replace("loads=[sum(r['demands'][j] for r in cells) for j in range(63)];caps=", "loads=[sum(r['demands'][j] for r in cells) for j in range(63)];caps=")
        needle="    fixed=spec['checked_first_originals'];"
        assert needle in source;source=source.replace(needle,"    assert all(a<=b for a,b in zip(loads,caps))\n"+needle)
    target='run_h5_last_count_bands.py' if kind=='run' else 'audit_h5_last_count_bands_response.py'
    with (ROOT/'output'/target).open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print('Prepared last-case band runner and response auditor.')
