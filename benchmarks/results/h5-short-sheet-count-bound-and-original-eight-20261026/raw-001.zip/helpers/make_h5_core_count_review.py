from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/review_h5_composition_selection_checkpoint.py').read_text()
s=s.replace('h5-composition-selection-review-20261026','h5-core-count-review-20261026').replace('5025ace18886dfa503fd74572a7e4dc1715f3b94','9842e4c1d5953970a8698d7f9600a713f154554b').replace('6246967c2962095d78b15693ae34550fbe163743','9842e4c1d5953970a8698d7f9600a713f154554b')
with (ROOT/'output/review_h5_core_count_checkpoint.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
