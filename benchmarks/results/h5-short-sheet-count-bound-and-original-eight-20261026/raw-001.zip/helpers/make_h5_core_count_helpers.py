from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
runner=(ROOT/'output/run_h5_stem_ordered_nine_decision.py').read_text()
audit=(ROOT/'output/audit_h5_stem_ordered_response.py').read_text()
needle="        elif kind=='interval':assert value(c.interval.start)+value(c.interval.size)==value(c.interval.end)\n"
addition="""        elif kind=='no_overlap':
            segments=[]
            for ref in c.no_overlap.intervals:
                ic=m.constraints[ref];assert ic.WhichOneof('constraint')=='interval'
                if all(truth(v) for v in ic.enforcement_literal):segments.append((value(ic.interval.start),value(ic.interval.end)))
            segments.sort()
            assert all(a[1]<=b[0] for a,b in zip(segments,segments[1:]))
"""
assert needle in audit;audit=audit.replace(needle,needle+addition)
needle="    totals=Counter(p['family'] for p in selected);assert totals['bracket']<=3 or totals['cog']<=3\n"
assert needle in audit;audit=audit.replace(needle,needle+"    assert all(totals[k]==v for k,v in spec['exact_family_counts'].items())\n")
for i in range(4):
    target=f'h5-core-count-partition-20261026/case-{i:03d}'
    for kind,source in [('run',runner),('audit',audit)]:
        with (ROOT/'output'/f'{kind}_h5_core_count_case_{i}.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source.replace('h5-stem-ordered-nine-decision-20261026',target))
print('Prepared four separately bounded case runners and complete positive-constraint auditors.')
