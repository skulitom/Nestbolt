"""Necessary geometry decision ordered by full-height bracket stems."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-geometric-nine-decision-20261026';DATA=ROOT/'output/h5-stem-order-reduction-plan-20261026';OUT=ROOT/'output/h5-stem-ordered-nine-decision-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter();assert load(PARENT/'model-audit/checks.json')['passed'] and load(PARENT/'response-audit/checks.json')['status']=='UNKNOWN' and load(DATA/'checks.json')['passed'];plan=load(DATA/'reduction-plan.json');old=load(PARENT/'plan.json');copied=['profile-flags.json','presence-flags.json','direction-flags.json','direction-requirements.json'];paths=[PARENT/n for n in ['plan.json','models/000.pb','inventory.json','optional-rectangles.json','model-audit/checks.json','model-audit/necessity-proof.json','response-audit/checks.json']+copied]+[p for p in DATA.rglob('*') if p.is_file()]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'allowed_profiles':old['allowed_profiles'],'originals':old['originals'],'families':old['families'],'checked_first_originals':old['checked_first_originals'],'minimum_short_sheet_count':9,'maximum_calls':1,'solver_seconds':20,'shared_seconds':30,'workers':4,'seed':0,'method':'Remove exactly the five former bracket bounding-box-anchor order constraints; retain selected-prefix symmetry. Relabel selected identical bracket copies by their full-height stem starts. All audited stems span Y160mm, so source-disjoint originals require disjoint stem X intervals. Add six stem-start variables,48 conditional profile/anchor channels and40 conditional adjacent profile-width separations. Retain all other necessary geometry, original-support, first-sheet area, identity and cardinality rules, with exact interval-reference remapping. Never impose both bracket orders. This necessary source formulation is not claimed equivalent to the proxy-only parent. Independently audit fields, source relabelling and actual import before one20solver/30shared4worker seed0 call; the former call remains closed.'})
parent=cp_model_pb2.CpModelProto();parent.ParseFromString((PARENT/'models/000.pb').read_bytes());m=cp_model_pb2.CpModelProto();m.variables.extend(parent.variables);removed=set(plan['remove_old_bracket_anchor_order_constraints']);assert removed=={120,122,124,126,128};kept=[i for i in range(len(parent.constraints)) if i not in removed];remap={old:new for new,old in enumerate(kept)}
for oldindex in kept:
    c=m.constraints.add();c.CopyFrom(parent.constraints[oldindex])
    if c.WhichOneof('constraint')=='no_overlap_2d':c.no_overlap_2d.x_intervals[:]=[remap[v] for v in c.no_overlap_2d.x_intervals];c.no_overlap_2d.y_intervals[:]=[remap[v] for v in c.no_overlap_2d.y_intervals]
assert (len(m.variables),len(m.constraints))==(116,854);stems=[]
for i in range(6):stems.append(len(m.variables));m.variables.add(name=f'p{i}-stem-start',domain=plan['new_stem_start_union_domain'])
flags=load(PARENT/'profile-flags.json');presence=load(PARENT/'presence-flags.json');profiles={r['profile']:r for r in plan['profiles']}
def lin(terms,lo,hi,enforce):
    vs=sorted(terms);c=m.constraints.add();c.enforcement_literal.extend(enforce);c.linear.vars.extend(vs);c.linear.coeffs.extend(terms[v] for v in vs);c.linear.domain.extend([lo,hi])
channels=[];separations=[]
for i in range(6):
    for p in range(8):
        offset=profiles[p]['stem_x_offset_units1000'];lin({2*i:-1,stems[i]:1},offset,offset,[flags[str(i)][str(p)]]);channels.append({'part':i,'profile':p,'stem_variable':stems[i],'offset_units1000':offset})
for i in range(5):
    for p in range(8):
        width=profiles[p]['stem_width_units1000'];lin({stems[i]:-1,stems[i+1]:1},width,2**63-1,[flags[str(i)][str(p)],presence[i+1]]);separations.append({'parts':[i,i+1],'profile':p,'width_units1000':width})
assert (len(m.variables),len(m.constraints))==(122,942)
for n in copied:shutil.copyfile(PARENT/n,OUT/n)
for n,v in [('kept-parent-constraints.json',kept),('removed-parent-order-constraints.json',sorted(removed)),('stem-variables.json',stems),('stem-profile-channels.json',channels),('stem-adjacent-separations.json',separations),('optional-rectangles.json',[{**r,'interval_constraints':[remap[v] for v in r['interval_constraints']]} for r in load(PARENT/'optional-rectangles.json')])]:write(OUT/n,v)
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n');record={**load(PARENT/'inventory.json')[0],'variables':len(m.variables),'constraints':len(m.constraints),'model_sha256':digest(p),'removed_old_bracket_anchor_orders':5,'stem_start_variables':6,'conditional_stem_channels':48,'conditional_stem_separations':40};write(OUT/'inventory.json',[record]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,**record,'solver_calls':0});print(load(OUT/'prepared.json'))
