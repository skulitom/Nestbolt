"""Independent original-stem ordering, retained fields and source symmetry audit."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product,permutations
import json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-stem-ordered-nine-decision-20261026';PARENT=ROOT/'output/h5-geometric-nine-decision-20261026';DATA=ROOT/'output/h5-stem-order-reduction-plan-20261026';SUPPORT=ROOT/'output/h5-all-angle-support-bounds-20261026';GEOMETRY=ROOT/'output/h5-rotation-independent-geometry-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify exact removal of five old bracket-anchor symmetry constraints and retention of all other parent fields with correct optional-interval remapping. Independently derive every stem offset/width, complete variable domain and common-line coverage from original-support data. Reconstruct all six variables and88 new constraints. Verify identical-family presence/rank relabelling and actual import/export. Source validity follows from common-line stem disjointness, not simultaneous anchor/stem order.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'] and load(DATA/'checks.json')['passed'] and load(SUPPORT/'audit/checks.json')['passed'];parent=proto(PARENT/'models/000.pb');m=proto(BASE/'models/000.pb');presence=load(PARENT/'presence-flags.json');flags=load(PARENT/'profile-flags.json');removed=[120,122,124,126,128]
for i,index in enumerate(removed):assert parent.constraints[index]==cp_model_pb2.ConstraintProto(enforcement_literal=[presence[i],presence[i+1]],linear=cp_model_pb2.LinearConstraintProto(vars=[2*i,2*(i+1)],coeffs=[1,-1],domain=[-2**63,0]))
kept=[i for i in range(len(parent.constraints)) if i not in removed];remap={old:new for new,old in enumerate(kept)};assert kept==load(BASE/'kept-parent-constraints.json') and removed==load(BASE/'removed-parent-order-constraints.json');expected=cp_model_pb2.CpModelProto();expected.variables.extend(parent.variables)
for index in kept:
    c=expected.constraints.add();c.CopyFrom(parent.constraints[index])
    if c.WhichOneof('constraint')=='no_overlap_2d':c.no_overlap_2d.x_intervals[:]=[remap[v] for v in c.no_overlap_2d.x_intervals];c.no_overlap_2d.y_intervals[:]=[remap[v] for v in c.no_overlap_2d.y_intervals]
rows=load(SUPPORT/'bracket-direction-bounds.json');bounds=load(GEOMETRY/'anchor-bounds.json');profile={r['profile']:r['stem_bounds_units1000'] for r in rows};domain=[min(bounds[str(p)][0]+b[0] for p,b in profile.items()),max(bounds[str(p)][2]+b[0] for p,b in profile.items())];assert domain==[6482,1418522]
for p,b in profile.items():assert bounds[str(p)][3]+b[1]<160000<bounds[str(p)][1]+b[3]
stems=[]
for i in range(6):stems.append(len(expected.variables));expected.variables.add(name=f'p{i}-stem-start',domain=domain)
def lin(terms,lo,hi,enforce):
    vs=sorted(terms);expected.constraints.add().CopyFrom(cp_model_pb2.ConstraintProto(enforcement_literal=enforce,linear=cp_model_pb2.LinearConstraintProto(vars=vs,coeffs=[terms[v] for v in vs],domain=[lo,hi])))
channels=[];separations=[]
for i in range(6):
    for p in range(8):
        offset=profile[p][0];lin({2*i:-1,stems[i]:1},offset,offset,[flags[str(i)][str(p)]]);channels.append({'part':i,'profile':p,'stem_variable':stems[i],'offset_units1000':offset})
for i in range(5):
    for p in range(8):
        width=profile[p][2]-profile[p][0];assert width>0;lin({stems[i]:-1,stems[i+1]:1},width,2**63-1,[flags[str(i)][str(p)],presence[i+1]]);separations.append({'parts':[i,i+1],'profile':p,'width_units1000':width})
assert expected==m and len(m.variables)==122 and len(m.constraints)==942 and stems==load(BASE/'stem-variables.json') and channels==load(BASE/'stem-profile-channels.json') and separations==load(BASE/'stem-adjacent-separations.json')
assert load(BASE/'optional-rectangles.json')==[{**r,'interval_constraints':[remap[v] for v in r['interval_constraints']]} for r in load(PARENT/'optional-rectangles.json')]
for n in ['profile-flags.json','presence-flags.json','direction-flags.json','direction-requirements.json']:assert (BASE/n).read_bytes()==(PARENT/n).read_bytes()
spec=load(BASE/'plan.json');assert spec['allowed_profiles'][:6]==[list(range(8))]*6 and spec['families'][:6]==['bracket']*6;count=0
for mask in product([0,1],repeat=6):
    for ranks in permutations(range(6)):
        order=sorted(range(6),key=lambda i:(-mask[i],ranks[i]));k=sum(mask);assert [mask[i] for i in order]==sorted(mask,reverse=True) and [ranks[i] for i in order[:k]]==sorted(ranks[i] for i in range(6) if mask[i]);count+=1
assert count==46080
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'necessity-proof.json',{'all_angle_continuous_original_count_subfamily_covered':True,'simultaneous_old_anchor_order_retained':False,'parent_proxy_equivalence_claimed':False,'statement':'The five bracket bounding-box-anchor order constraints are removed; selected-prefix presence is retained. Every source-disjoint bracket contains its quantization-safe full-height stem spanning the common160mm line, hence selected stem X intervals are disjoint. Relabel identical selected bracket copies with their profiles in increasing stem-start order. Every original profile/stock/direction/resource/cardinality/rectangle rule is family-symmetric and remains represented; cog ordering is independent. The new affine channels recover each stem start from its original anchor, and adjacent width inequalities follow from source disjointness. Absent stems impose no first-sheet pose. Thus every original continuation with at least9 short-sheet parts still maps to this necessary model. Positives must still pass omitted bands and full original geometry; a negative would concern only this continuation and stock target.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':122,'constraints':942,'old_anchor_orders_removed':5,'retained_parent_constraints_verified':854,'new_stem_channels_verified':48,'new_stem_separations_verified':40,'common_line_profiles_verified':8,'presence_rank_cases_verified':count,'all_retained_interval_references_verified':True,'actual_import_export_verified':True,'source_relabelling_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
