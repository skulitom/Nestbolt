"""Independent inverse mapping of restored variables and every band-model field."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2 as pb
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-last-count-bands-20261026';PARENT=ROOT/'output/h5-core-count-partition-20261026/case-002';SOURCE=ROOT/'output/h5-support-composition-selector-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=pb.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Reverse the fresh cell-index mapping and compare every appended variable and all2417 constraints to the independently audited universal-angle source. Verify exact retention of parent fields and unchanged common flags. Verify all profile groups, all63 capacity rows, no objectives and actual import/export.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'] and load(SOURCE/'model-audit/checks.json')['passed']
m=proto(BASE/'models/000.pb');parent=proto(PARENT/'models/000.pb');source=proto(SOURCE/'models/000.pb')
assert len(parent.variables)==122 and len(parent.constraints)==998 and len(m.variables)==2422 and len(m.constraints)==3415
restored=pb.CpModelProto();restored.CopyFrom(m);del restored.variables[122:];del restored.constraints[998:];assert restored==parent
assert m.variables[:116]==source.variables[:116] and m.variables[122:]==source.variables[116:]
assert load(BASE/'restored-source-constraints.json')==list(range(565,2982))
for index,c in enumerate(m.constraints[998:]):
    original=pb.ConstraintProto();original.CopyFrom(c);assert original.WhichOneof('constraint')=='linear'
    assert all(v<116 or v>=122 for v in original.linear.vars) and all(v<116 or v>=122 for v in original.enforcement_literal)
    original.linear.vars[:]=[v-6 if v>=122 else v for v in original.linear.vars];original.enforcement_literal[:]=[v-6 if v>=122 else v for v in original.enforcement_literal]
    assert original==source.constraints[565+index]
for n in ['profile-flags.json','presence-flags.json']:assert (BASE/n).read_bytes()==(PARENT/n).read_bytes()==(SOURCE/n).read_bytes()
assert not m.HasField('objective') and load(BASE/'plan.json')['exact_family_counts']=={'bracket':6,'insert':1,'cog':2}
real=cp_model.CpModel();assert real.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(OUT/'roundtrip.pb'));assert proto(OUT/'roundtrip.pb')==m
write(OUT/'necessity-proof.json',{'all_real_angles_and_continuous_anchors_covered':True,'original_count_case':[6,1,2],'parent_retained_exactly':True,'independently_audited_universal_angle_bands_restored':True,'statement':'The common116 base variables and all profile flags have identical meanings. Appended source cell variables use fresh indices displaced by6 around the retained stem variables. Each physical profile/anchor maps to its unique audited Y cell, so every source layout admits all restored cell implications, profile sums and band capacities. Every constraint is byte-field equal after reverse remapping. No old finite-angle coefficients are used. A negative excludes this count case only in the checked55 continuation and stated stock target; positives still require original geometry and first-sheet additions.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':2422,'constraints':3415,'retained_parent_variables':122,'retained_parent_constraints':998,'restored_cell_variables':2300,'restored_constraints_verified':2417,'restored_profile_groups':54,'restored_band_rows':63,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
