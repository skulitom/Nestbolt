"""Restore audited universal-angle band constraints to the last exact count case."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'output/h5-core-count-partition-20261026/case-002';SOURCE=ROOT/'output/h5-support-composition-selector-20261026';OUT=ROOT/'output/h5-last-count-bands-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=pb.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
assert load(PARENT/'response-audit/checks.json')['status']=='UNKNOWN' and load(SOURCE/'model-audit/checks.json')['passed']
files=[p for p in PARENT.rglob('*') if p.is_file()]+[SOURCE/n for n in ['plan.json','models/000.pb','model-audit/checks.json','model-audit/plan.json','profile-flags.json','presence-flags.json']]
write(OUT/'plan.json',{**load(PARENT/'plan.json'),'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'method':'Retain all122 variables and998 constraints of the exact6-bracket/1-insert/2-cog core model. Restore all2300 universal-angle vertical-cell variables and2417 constraints (2300 implications,54 profile groups,63 band capacity rows) from the independently audited complete support selector. Shift every cell reference by6, preserving all116 common base variables and six appended stem variables. No new coefficients or finite-angle substitutions. One new20solver/30shared call after independent reconstruction/import.'})
m=proto(PARENT/'models/000.pb');source=proto(SOURCE/'models/000.pb');assert m.variables[:116]==source.variables[:116];m.variables.extend(source.variables[116:]);indices=list(range(565,2982))
for k in indices:
    c=m.constraints.add();c.CopyFrom(source.constraints[k]);assert c.WhichOneof('constraint')=='linear'
    c.linear.vars[:]=[v+6 if v>=116 else v for v in c.linear.vars]
    assert all(v>=0 for v in c.enforcement_literal);c.enforcement_literal[:]=[v+6 if v>=116 else v for v in c.enforcement_literal]
assert len(m.variables)==2422 and len(m.constraints)==3415
for n in ['profile-flags.json','presence-flags.json','direction-flags.json','direction-requirements.json','stem-variables.json','optional-rectangles.json']:shutil.copyfile(PARENT/n,OUT/n)
write(OUT/'restored-source-constraints.json',indices);p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
record={**load(PARENT/'inventory.json')[0],'variables':2422,'constraints':3415,'model_sha256':digest(p),'cell_selectors':2300,'profile_cell_equalities':54,'band_inequalities':63,'geometry_only_necessary_relaxation':False,'restored_band_constraints':2417}
write(OUT/'inventory.json',[record]);write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'solver_calls':0,'variables':2422,'constraints':3415});print(load(OUT/'prepared.json'))
