"""Independent objective/constraint/identity readback of the sole selector call."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time,math
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-core-count-partition-20261026/case-003';RUN=BASE/'search';RESOURCE=ROOT/'output/h5-composition-resources-20261026';OUT=BASE/'response-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=cp_model_pb2.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify sole actual imported model, exact parameters, terminal response, hard shared deadline, every returned variable/active constraint/optional interval/2D nonoverlap and exact objective. Independently derive selected short-sheet profiles/cells and mandatory first-sheet complements, accounting for all66 identities exactly once. Check presence prefixes, active bracket stem order and cog x order, band capacities and rounded first-sheet area resource. Verify selected count is at least9; no objective remains and no actual layout is claimed. No retry.'})
for plan in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(plan)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];proc=load(RUN/'process.json');budget=load(RUN/'budget.json');census=load(RUN/'census.json');assert proc['exit_code']==0 and not proc['timeout'] and proc['seconds']<=30 and budget['shared_seconds']==30 and budget['deadline_perf_counter']==budget['start_perf_counter']+30 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==20 and budget['workers']==4 and budget['seed']==0
assert not census['pending_pairs'] and len(census['results'])==census['solver_calls']==len(list(RUN.rglob('opened.json')))==1
folder=RUN/'000';r=load(folder/'result.json');opened=load(folder/'opened.json');assert r==census['results'][0] and opened['maximum_calls']==r['solver_calls']==1 and r['parts']==list(range(11));m=proto(folder/'model.pb');assert m==proto(BASE/'models/000.pb') and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=20,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'] and opened['seconds_limit']==20
response=cp_model_pb2.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert cp_model_pb2.CpSolverStatus.Name(response.status)==r['status'] and abs(response.wall_time-r['seconds'])<.2 and r['seconds']<=r['stage_seconds'] and r['solver_soft_overshoot_seconds']==max(0,r['seconds']-20);sol=list(response.solution);positive=r['status'] in ['OPTIMAL','FEASIBLE'];active=0;selected_count=None;objective=None
if positive:
    assert len(sol)==len(m.variables) and sol[:22]==r['original_coordinates_units1000']
    for v,n in zip(m.variables,sol):assert any(lo<=n<=hi for lo,hi in zip(v.domain[::2],v.domain[1::2]))
    def truth(v):return bool(sol[v]) if v>=0 else not bool(sol[-v-1])
    def value(e):return e.offset+sum(sol[v]*k for v,k in zip(e.vars,e.coeffs))
    for c in m.constraints:
        if not all(truth(v) for v in c.enforcement_literal):continue
        kind=c.WhichOneof('constraint')
        if kind=='linear':n=sum(sol[v]*a for v,a in zip(c.linear.vars,c.linear.coeffs));assert any(lo<=n<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        elif kind=='bool_or':assert any(truth(v) for v in c.bool_or.literals)
        elif kind=='interval':assert value(c.interval.start)+value(c.interval.size)==value(c.interval.end)
        elif kind=='no_overlap':
            segments=[]
            for ref in c.no_overlap.intervals:
                ic=m.constraints[ref];assert ic.WhichOneof('constraint')=='interval'
                if all(truth(v) for v in ic.enforcement_literal):segments.append((value(ic.interval.start),value(ic.interval.end)))
            segments.sort()
            assert all(a[1]<=b[0] for a,b in zip(segments,segments[1:]))
        else:
            assert kind=='no_overlap_2d';rects=[]
            for xi,yi in zip(c.no_overlap_2d.x_intervals,c.no_overlap_2d.y_intervals):
                xc,yc=m.constraints[xi],m.constraints[yi];assert list(xc.enforcement_literal)==list(yc.enforcement_literal)
                if all(truth(v) for v in xc.enforcement_literal):rects.append([value(xc.interval.start),value(yc.interval.start),value(xc.interval.end),value(yc.interval.end)])
            for i,a in enumerate(rects):
                for b in rects[i+1:]:assert a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
        active+=1
    spec=load(BASE/'plan.json');flags=load(BASE/'profile-flags.json');presence=[sol[v] for v in load(BASE/'presence-flags.json')];selected_count=sum(presence);chosen=[];selected=[];pending=[]
    for i,item in enumerate(spec['originals']):
        ps=[int(p) for p,v in flags[str(i)].items() if sol[v]];assert len(ps)==presence[i];chosen.append(ps[0] if ps else None)
        if ps:selected.append({'original':item,'slot':i,'family':spec['families'][i],'profile':ps[0],'anchor_units1000':sol[2*i:2*i+2]})
        else:pending.append(item)
    for slots in [list(range(6)),list(range(7,11))]:
        assert [presence[i] for i in slots]==sorted((presence[i] for i in slots),reverse=True);xs=[sol[load(BASE/'stem-variables.json')[i]] if i<6 else sol[2*i] for i in slots if presence[i]];assert xs==sorted(xs)
    assert all(chosen[i]==11 for i in range(7,11) if presence[i])
    # Omitted parent bands are checked diagnostically, never asserted as model constraints.
    cells=[]
    for i,p in enumerate(chosen):
        if p is None:continue
        datum=load(ROOT/'output/h5-rotation-independent-bands-20261026/profiles'/f'{p:03d}.json')
        matching=[c for c in datum['cells'] if c['y_bounds_units1000'][0]<=sol[2*i+1]<=c['y_bounds_units1000'][1]]
        assert len(matching)==1;cell=matching[0];cells.append({'part':i,'profile':p,'cell':cell['index'],'y_bounds_units1000':cell['y_bounds_units1000'],'demands':cell['band_lower_area_units']})
    loads=[sum(r['demands'][j] for r in cells) for j in range(63)];caps=load(ROOT/'output/h5-rotation-independent-bands-20261026/band-capacities.json');resource=load(RESOURCE/'resources.json');area=sum(resource['rounded_up_area_units'][p['family']] for p in selected);assert area>=resource['necessary_short_sheet_minimum_area_units'];expected=selected_count*resource['count_objective_weight']+area;objective=expected;assert selected_count>=9 and not m.HasField('objective') and response.objective_value==response.best_objective_bound==0
    fixed=spec['checked_first_originals'];assert sorted(fixed+pending+[p['original'] for p in selected])==list(range(66)) and len(set(fixed+pending+[p['original'] for p in selected]))==66
    totals=Counter(p['family'] for p in selected);assert totals['bracket']<=3 or totals['cog']<=3
    assert all(totals[k]==v for k,v in spec['exact_family_counts'].items())
    write(OUT/'verified-necessary-allocation.json',{'selected_short_sheet_parts':selected,'selected_short_counts':totals,'mandatory_first_sheet_additions':pending,'checked_first_originals':fixed,'cells':cells,'band_loads':loads,'band_capacities':caps,'omitted_bands_satisfied':all(a<=b for a,b in zip(loads,caps)),'selected_rounded_area_units':area,'minimum_rounded_area_units':resource['necessary_short_sheet_minimum_area_units'],'objective':int(objective),'objective_upper_bound':response.best_objective_bound,'lexicographic_optimal':False,'maximum_necessary_selected_count':None,'all66_originals_accounted_once':True,'original_short_sheet_geometry_verified':False,'first_sheet_additions_placed':False,'full66_target_witness':False})
else:assert r['status'] in ['INFEASIBLE','UNKNOWN'] and not sol and r['original_coordinates_units1000'] is None
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':1,'status':r['status'],'necessary_allocation':positive,'selected_short_sheet_count':selected_count,'objective':objective,'objective_optimal':False,'solver_seconds':r['seconds'],'shared_seconds':proc['seconds'],'shared_budget_honored':True,'soft_overrun_seconds':r['solver_soft_overshoot_seconds'],'positive_variables_checked':len(sol),'positive_active_constraints_checked':active,'all66_original_identity_obligations_preserved':True,'full_geometry_verified':False,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
