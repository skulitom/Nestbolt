"""Reconstruct every field and prove global-core pair implications independently."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
from itertools import product,combinations
import json,shutil,time
from ortools.sat import cp_model_pb2 as pb
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-core-count-partition-20261026';PARENT=ROOT/'output/h5-stem-ordered-nine-decision-20261026';SUPPORT=ROOT/'output/h5-all-angle-support-bounds-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(p):
    m=pb.CpModelProto();m.ParseFromString(p.read_bytes());return m
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Independently enumerate all70 remaining family counts and select all >=9 satisfying the previously proved count cut. Rebuild all core intervals and all three exact-count constraints, retaining every parent byte field. Check core pair implications from original-support directional rules, cog spacing, full-height stem ordering and mutually exclusive profile flags. Import/export every actual case before allowing one call each.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(PARENT/'model-audit/checks.json')['passed'] and load(SUPPORT/'audit/checks.json')['passed']
allcounts=list(product(range(7),range(2),range(5)))
cases=[list(c) for c in allcounts if sum(c)>=9 and (c[0]<4 or c[2]<4)]
assert len(allcounts)==70 and cases==load(BASE/'plan.json')['exact_counts']==[[5,1,3],[6,0,3],[6,1,2],[6,1,3]]
parent=proto(PARENT/'models/000.pb');presence=load(PARENT/'presence-flags.json');flags=load(PARENT/'profile-flags.json');stems=load(PARENT/'stem-variables.json')
profiles={r['profile']:r['stem_bounds_units1000'] for r in load(SUPPORT/'bracket-direction-bounds.json')}
directions=load(PARENT/'direction-requirements.json');bc=[]
for r in directions:
    i,j=r['parts'];p=r['profile']
    if i<6 and j>=7:
        a,_,c,_=profiles[p];assert r['left']+122517<=a and r['right']-122517>=c
        bc.append({'parts':[i,j],'profile':p,'left_slack':a-r['left']-122517,'right_slack':r['right']-122517-c})
assert len(bc)==192
# Verify retained actual constraints contain all six conditional cog gaps.
cog_rows=[]
for i,j in combinations(range(7,11),2):
    expected=pb.ConstraintProto(enforcement_literal=[presence[i],presence[j]],linear=pb.LinearConstraintProto(vars=[2*i,2*j],coeffs=[-1,1],domain=[245034,2**63-1]))
    matches=[k for k,c in enumerate(parent.constraints) if c==expected]
    assert len(matches)==1;(cog_rows.append({'parts':[i,j],'constraint':matches[0]}))
expected=pb.CpModelProto();expected.CopyFrom(parent);refs=[]
for i in range(6):
    for p in range(8):
        width=profiles[p][2]-profiles[p][0];refs.append(len(expected.constraints))
        e=lambda offset:pb.LinearExpressionProto(vars=[stems[i]],coeffs=[1],offset=offset)
        expected.constraints.add().CopyFrom(pb.ConstraintProto(enforcement_literal=[flags[str(i)][str(p)]],interval=pb.IntervalConstraintProto(start=e(0),end=e(width),size=pb.LinearExpressionProto(offset=width))))
for i in range(7,11):
    refs.append(len(expected.constraints));e=lambda offset:pb.LinearExpressionProto(vars=[2*i],coeffs=[1],offset=offset)
    expected.constraints.add().CopyFrom(pb.ConstraintProto(enforcement_literal=[presence[i]],interval=pb.IntervalConstraintProto(start=e(-122517),end=e(122517),size=pb.LinearExpressionProto(offset=245034))))
expected.constraints.add().CopyFrom(pb.ConstraintProto(no_overlap=pb.NoOverlapConstraintProto(intervals=refs)))
assert refs==load(BASE/'core-intervals.json') and len(refs)==52
proof={'all70_family_counts_enumerated':True,'exhaustive_counts':cases,'source_coverage':'Every >=9 continuation of the checked55 must satisfy the all-angle four-bracket/four-cog exclusion and lies in exactly one listed family-count case. All original identity complements and parent resource constraints are retained; no dropping-part monotonicity assumption is used.','core_implication':'Profile flags of each bracket are exclusive. Selected stems are disjoint by adjacent width constraints and prefix order; transitivity covers all selected stem pairs. Every bracket/cog original-support left/right bound separates the bracket stem from the 122517-unit cog half-core, with strictly nonnegative checked slacks. Every selected cog pair has retained245034 separation. Consequently the added global1D no-overlap is entailed by the retained parent constraints. Its intervals are propagation devices, not claimed original source subsets.','bracket_cog_implications':bc,'cog_gap_constraints':cog_rows,'no_original_layout_claimed':True}
write(OUT/'necessity-proof.json',proof)
for index,counts in enumerate(cases):
    folder=BASE/f'case-{index:03d}';audit=folder/'model-audit';audit.mkdir();m=proto(folder/'models/000.pb');ex=pb.CpModelProto();ex.CopyFrom(expected)
    for slots,n in zip([range(6),[6],range(7,11)],counts):
        vs=[presence[i] for i in slots];ex.constraints.add().CopyFrom(pb.ConstraintProto(linear=pb.LinearConstraintProto(vars=vs,coeffs=[1]*len(vs),domain=[n,n])))
    assert ex==m and len(m.variables)==122 and len(m.constraints)==998 and not m.HasField('objective')
    for n in ['profile-flags.json','presence-flags.json','direction-flags.json','direction-requirements.json','stem-variables.json','optional-rectangles.json']:assert (folder/n).read_bytes()==(PARENT/n).read_bytes()
    real=cp_model.CpModel();assert real.proto.parse_text_format((folder/'models/000.pbtxt').read_text()) and real.validate()=='' and real.export_to_file(str(audit/'roundtrip.pb'));assert proto(audit/'roundtrip.pb')==m
    write(audit/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in list(folder.rglob('*'))+[OUT/'necessity-proof.json',OUT/'audit.py'] if p.is_file() and audit not in p.parents},'method':'Exact independently reconstructed case and actual import/export, with parent implication proof.'})
    write(audit/'checks.json',{'passed':True,'case':index,'counts':counts,'variables':122,'constraints':998,'parent_constraints_retained':942,'optional_core_intervals':52,'global_no_overlap':1,'exact_count_constraints':3,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'cases':4,'all_family_counts_checked':70,'bracket_cog_implications_checked':192,'cog_gap_constraints_checked':6,'all_parent_fields_retained':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
