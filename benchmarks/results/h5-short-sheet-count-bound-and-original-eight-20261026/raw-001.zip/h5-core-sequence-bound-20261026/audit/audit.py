"""Independent integer forbidden-set union and backward dynamic-program audit."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from itertools import product
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-core-sequence-bound-20261026';GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';SUPPORT=ROOT/'output/h5-all-angle-support-bounds-20261026';PARENT=ROOT/'output/h5-stem-ordered-nine-decision-20261026';PARTITION=ROOT/'output/h5-core-count-partition-20261026';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Rebuild every necessary pair distance with an independently merged union of closed integer forbidden intervals. Derive all Y-overlap inequalities from complete relative-anchor ranges, preserving open X endpoints. Verify every forward Bellman state and transition by independent recurrence; also run a backward latest-position dynamic program. Both cover every profile/shape-order sequence. Combine the proven six-bracket/two-cog exclusion with all four exact count cases and their audited terminal statuses, preserving all66 identity obligations and source scope.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEOM/'audit/checks.json')['passed'] and load(SUPPORT/'audit/checks.json')['passed'] and load(PARENT/'model-audit/checks.json')['passed'] and load(PARTITION/'model-audit/checks.json')['passed']
profiles={r['index']:r for r in load(GEOM/'profiles.json')};box=load(GEOM/'anchor-bounds.json');stems={r['profile']:r['stem_bounds_units1000'] for r in load(SUPPORT/'bracket-direction-bounds.json')};directions={r['profile']:r for r in load(PARENT/'direction-requirements.json') if r['parts']==[0,7]};rows={tuple(r['profiles']):r for r in load(BASE/'pair-distance-bounds.json')};types=list(range(8))+[11];domains={p:tuple(box[str(p)][k]+(stems[p][0] if p<8 else 0) for k in [0,2]) for p in types};assert {str(k):list(v) for k,v in domains.items()}==load(BASE/'coordinate-domains.json');dist={};proofrows=[];pairschecked=0
for p,q in product(types,repeat=2):
    if p<8 and q<8:
        a,b=stems[p],stems[q];closed=[];expected=[]
        for i,r in enumerate(profiles[p]['rectangles_units1000']+[a]):
            for j,s in enumerate(profiles[q]['rectangles_units1000']+[b]):
                relative_min=box[str(q)][1]-box[str(p)][3];relative_max=box[str(q)][3]-box[str(p)][1]
                # r and translated s overlap for every allowed relative Y.
                if relative_min+s[3]>r[1] and relative_max+s[1]<r[3]:
                    left=r[0]-s[2]+b[0]-a[0];right=r[2]-s[0]+b[0]-a[0]
                    expected.append({'rectangles':[i,j],'y_overlap_slacks':[relative_min+s[3]-r[1],r[3]-relative_max-s[1]],'forbidden_open':[left,right]});closed.append([left+1,right-1]);pairschecked+=1
        assert expected==rows[p,q]['guaranteed_y_pairs'];merged=[]
        for lo,hi in sorted(closed):
            if merged and lo<=merged[-1][1]+1:merged[-1][1]=max(hi,merged[-1][1])
            else:merged.append([lo,hi])
        minimum=a[2]-a[0];initial=minimum
        for lo,hi in merged:
            if lo<=minimum<=hi:minimum=hi+1
        assert not any(lo<=minimum<=hi for lo,hi in merged)
        # Every integer below the selected lower bound, starting at stem width,
        # is covered by the merged forbidden set; no open endpoint is removed.
        cursor=initial
        for lo,hi in merged:
            if hi<cursor:continue
            if cursor>=minimum:break
            assert lo<=cursor;cursor=hi+1
        assert cursor>=minimum
        proofrows.append({'profiles':[p,q],'closed_forbidden_union':merged,'initial_stem_width':initial,'minimum_distance':minimum})
    elif p==q==11:minimum=245034
    elif q==11:
        assert directions[p]['left']-stems[p][0]<0<directions[p]['right']-stems[p][0];minimum=directions[p]['right']-stems[p][0]
    else:
        assert directions[q]['left']-stems[q][0]<0<directions[q]['right']-stems[q][0];minimum=stems[q][0]-directions[q]['left']
    assert minimum==rows[p,q]['minimum_distance'] and minimum>0;dist[p,q]=minimum
write(OUT/'independent-forbidden-unions.json',proofrows)
# Direct Bellman recurrence, rather than replaying the builder's transition loop.
forward={};backward={}
for total in range(1,9):
    for b in range(7):
        c=total-b
        if not 0<=c<=2:continue
        for p in types:
            nb,nc=b-int(p<8),c-int(p==11)
            if min(nb,nc)<0:continue
            if nb==nc==0:earliest,latest=domains[p]
            else:
                left=[max(domains[p][0],value+dist[q,p]) for (bb,cc,q),value in forward.items() if (bb,cc)==(nb,nc)]
                right=[min(domains[p][1],value-dist[p,q]) for (bb,cc,q),value in backward.items() if (bb,cc)==(nb,nc)]
                earliest=min(left,default=domains[p][1]+1);latest=max(right,default=domains[p][0]-1)
            if earliest<=domains[p][1]:forward[b,c,p]=earliest
            if latest>=domains[p][0]:backward[b,c,p]=latest
assert forward=={tuple(r['key']):r['earliest'] for r in load(BASE/'states.json')}
for r in load(BASE/'states.json'):
    ps=r['profiles'];xs=r['coordinates'];assert len(ps)==len(xs)==sum(r['key'][:2]) and ps[-1]==r['key'][2] and xs[-1]==r['earliest']
    assert sum(p<8 for p in ps)==r['key'][0] and sum(p==11 for p in ps)==r['key'][1]
    assert all(domains[p][0]<=x<=domains[p][1] for p,x in zip(ps,xs)) and all(y-x>=dist[p,q] for p,q,x,y in zip(ps,ps[1:],xs,xs[1:]))
observed=load(BASE/'transitions.json');expected=[]
for (b,c,p),value in forward.items():
    if b+c==8:continue
    for q in types:
        nb,nc=b+int(q<8),c+int(q==11)
        if nb<=6 and nc<=2:
            pos=max(domains[q][0],value+dist[p,q]);expected.append({'from':[b,c,p],'to':[nb,nc,q],'earliest':pos,'within_domain':pos<=domains[q][1]})
key=lambda r:(r['from'],r['to']);assert sorted(expected,key=key)==sorted(observed,key=key)
assert not any(k[:2]==(6,2) for k in forward) and not any(k[:2]==(6,2) for k in backward)
write(OUT/'backward-latest-states.json',[{'key':list(k),'latest':v} for k,v in sorted(backward.items())])
result=load(BASE/'result.json');assert result['six_brackets_two_cogs_excluded'] and result['terminal_states']==[] and result['states']==len(forward) and result['transitions']==len(observed)
cases=load(PARTITION/'plan.json')['exact_counts'];assert cases==[[5,1,3],[6,0,3],[6,1,2],[6,1,3]]
for i,status in enumerate(['INFEASIBLE','INFEASIBLE','UNKNOWN','INFEASIBLE']):
    record=load(PARTITION/f'case-{i:03d}/response-audit/checks.json');assert record['passed'] and record['status']==status
coverage=[{'counts':case,'exclusion':'independent exact six-bracket/two-cog necessary projection' if i==2 else 'audited exact-count necessary model INFEASIBLE'} for i,case in enumerate(cases)]
write(OUT/'necessity-proof.json',{'six_brackets_two_cogs_excluded':True,'all_real_cog_angles_and_continuous_original_anchors':True,'integer_rounding_covered_by_source_proxy_proofs':True,'statement':'Every source layout admits the audited quantization-safe stems, rectangles and rounded cog centers within the stated X/Y domains. Stems and cog centers have a strict total X order: bracket/cog support gaps are positive in their corresponding direction, stem widths and cog spacing are positive. Any ordered bracket pair must avoid each open X-overlap interval for rectangle pairs whose Y intervals overlap throughout both allowed Y domains. Merging the equivalent closed INTEGER forbidden sets preserves touching endpoints. The computed lower gap applies to every adjacent ordered pair. Every physical arrangement therefore maps to a path of six bracket types and two cogs in this weaker one-dimensional model. Dynamic-program states record earliest position of the last profile; earlier positions dominate later ones because all remaining constraints are lower differences and fixed coordinate domains. A backward latest-position recurrence independently reaches the same empty terminal set. Insert and nonadjacent exclusions were omitted, so their addition cannot create a solution.','count_coverage':coverage,'checked55_continuation_maximum_short_count':8,'mandatory_first_sheet_additions_at_least':3,'global66_layout_impossibility_claimed':False,'scope':'Same relaxed short-sheet target, original profiles, allowed bracket transforms and all real cog angles. Combined <=8 claim concerns the current checked55 continuation; other first-sheet arrangements and other targets remain open.','H5_complete':False})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'pair_distance_bounds_verified':81,'guaranteed_y_rectangle_pairs_checked':pairschecked,'forward_states_verified':len(forward),'forward_transitions_verified':len(expected),'independent_backward_states':len(backward),'six_brackets_two_cogs_excluded':True,'checked55_maximum_short_count':8,'all_four_count_cases_excluded':True,'no_originals_dropped':True,'solver_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
