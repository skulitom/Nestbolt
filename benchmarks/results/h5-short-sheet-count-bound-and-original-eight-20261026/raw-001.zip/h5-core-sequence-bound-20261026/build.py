"""Finite exact dynamic program over a necessary ordered horizontal projection."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import product
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';SUPPORT=ROOT/'output/h5-all-angle-support-bounds-20261026';PARENT=ROOT/'output/h5-stem-ordered-nine-decision-20261026';OUT=ROOT/'output/h5-core-sequence-bound-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
inputs=[GEOM/n for n in ['profiles.json','anchor-bounds.json','audit/checks.json','audit/necessity-proof.json']]+[SUPPORT/n for n in ['bracket-direction-bounds.json','cog-spacing-proof.json','audit/checks.json']]+[PARENT/n for n in ['direction-requirements.json','model-audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Use bracket stem-start and cog-center X coordinates, ordered together by the audited global-core separation. For each ordered bracket profile pair, find all rectangle pairs with strict Y overlap throughout both complete anchor domains. Their open X-overlap intervals forbid integer stem distances. Starting at the left stem width, skip forbidden intervals to derive the smallest allowed distance. Add original-support bracket/cog and cog/cog distances. Compute earliest feasible positions by a complete dynamic program for6 brackets and2 cogs. Omit insert and nonadjacent constraints, so a negative is necessary-source exclusion; positives are projection-only. All arithmetic is integer; no solver call.'})
profiles={r['index']:r for r in load(GEOM/'profiles.json')};bounds=load(GEOM/'anchor-bounds.json');stem={r['profile']:r['stem_bounds_units1000'] for r in load(SUPPORT/'bracket-direction-bounds.json')};directions={r['profile']:r for r in load(PARENT/'direction-requirements.json') if r['parts']==[0,7]}
domains={p:[bounds[str(p)][0]+stem[p][0],bounds[str(p)][2]+stem[p][0]] for p in range(8)};domains[11]=[bounds['11'][0],bounds['11'][2]]
edges=[]
for p,q in product(list(range(8))+[11],repeat=2):
    overlaps=[]
    if p<8 and q<8:
        a,b=stem[p],stem[q];rp=profiles[p]['rectangles_units1000']+[a];rq=profiles[q]['rectangles_units1000']+[b]
        for ri,r in enumerate(rp):
            for si,s in enumerate(rq):
                slack1=bounds[str(q)][1]+s[3]-(bounds[str(p)][3]+r[1]);slack2=bounds[str(p)][1]+r[3]-(bounds[str(q)][3]+s[1])
                if min(slack1,slack2)>0:overlaps.append({'rectangles':[ri,si],'y_overlap_slacks':[slack1,slack2],'forbidden_open':[r[0]-s[2]-a[0]+b[0],r[2]-s[0]-a[0]+b[0]]})
        gap=a[2]-a[0];initial=gap;steps=[]
        while True:
            candidates=[r['forbidden_open'][1] for r in overlaps if r['forbidden_open'][0]<gap<r['forbidden_open'][1]]
            if not candidates:break
            new=max(candidates);steps.append([gap,new]);gap=new
        kind='guaranteed-Y rectangle exclusion'
    elif p==q==11:gap=245034;initial=gap;steps=[];kind='original cog spacing'
    elif q==11:gap=directions[p]['right']-stem[p][0];initial=gap;steps=[];kind='bracket before cog original support'
    else:gap=stem[q][0]-directions[q]['left'];initial=gap;steps=[];kind='cog before bracket original support'
    assert gap>0;edges.append({'profiles':[p,q],'minimum_distance':gap,'initial_distance':initial,'kind':kind,'guaranteed_y_pairs':overlaps,'interval_advances':steps})
write(OUT/'coordinate-domains.json',domains);write(OUT/'pair-distance-bounds.json',edges);dist={tuple(r['profiles']):r['minimum_distance'] for r in edges};states={};transitions=[]
for p in domains:
    key=(int(p<8),int(p==11),p);states[key]={'earliest':domains[p][0],'previous':None,'profiles':[p],'coordinates':[domains[p][0]]}
for total in range(1,8):
    for key,value in sorted(list(states.items())):
        b,c,p=key
        if b+c!=total:continue
        for q in domains:
            nb,nc=b+int(q<8),c+int(q==11)
            if nb>6 or nc>2:continue
            position=max(domains[q][0],value['earliest']+dist[p,q]);valid=position<=domains[q][1]
            transitions.append({'from':list(key),'to':[nb,nc,q],'earliest':position,'within_domain':valid})
            if valid:
                nk=(nb,nc,q)
                if nk not in states or position<states[nk]['earliest']:states[nk]={'earliest':position,'previous':list(key),'profiles':value['profiles']+[q],'coordinates':value['coordinates']+[position]}
write(OUT/'states.json',[{'key':list(k),**v} for k,v in sorted(states.items())]);write(OUT/'transitions.json',transitions);terminal=[{'key':list(k),**v} for k,v in sorted(states.items()) if k[:2]==(6,2)]
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'pair_bounds':len(edges),'states':len(states),'transitions':len(transitions),'terminal_states':terminal,'six_brackets_two_cogs_excluded':not terminal,'solver_calls':0,'original_geometry_witness':False,'H5_complete':False});print(load(OUT/'result.json'))
