"""Construct an original-geometry eight-part strip, leaving three first-sheet cogs."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-six-bracket-short-sheet-20261026';FIRST=ROOT/'output/h5-insert36-cog53-exchange-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';PROFILE=ROOT/'output/h5-eight-phase-balanced-source-20261026/profiles.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def transformed(g,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1
    return affine_transform(g,[mi*c,-s,mi*s,c,*t['translation']])
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[FIRST/n for n in ['checks.json','first-sheet-placements.json','first-sheet-identities.json']]+[SRC/'items.json',SRC/'geometry.json',PROFILE,JOB,ROOT/'output/h5-core-sequence-bound-20261026/audit/checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Construct three interlocking mirrored quarter-turn bracket pairs, followed by one0-degree original cog and one0-degree original insert. Use0.225mm separation and0.025mm extra stock guard. Preserve the checked55 first-sheet placements byte-for-byte. All six outstanding brackets, insert37 and cog53 go to the short sheet; cogs63/64/65 remain mandatory first-sheet additions. Verify every original outer and cutout, every same-sheet pair and all stock edges. This new63-original branch is not a completed job or native validator input.'})
assert load(FIRST/'checks.json')['passed'] and load(ROOT/'output/h5-core-sequence-bound-20261026/audit/checks.json')['checked55_maximum_short_count']==8
job=load(JOB);families={p['id']:p for p in job['parts']};items=load(SRC/'items.json');profiles={p['index']:p for p in load(PROFILE)};short=[];records=[];clearance=.225
def placed(item,pid,x,y):
    profile=profiles[pid];t={'rotation_radians':profile['rotation_radians'],'mirrored':profile['mirrored'],'translation':[x-profile['rotated_original_min'][0],y-profile['rotated_original_min'][1]]};short.append({'part_id':items[item]['family'],'copy_index':items[item]['copy'],'sheet_id':'sheet-1','transform':t});records.append({'item':item,'profile':pid,'lower_left':[x,y]})
for pair,ids in enumerate([[21,22],[25,26],[28,29]]):
    x=6.525+pair*(325+2*clearance);placed(ids[0],7,x,6.525);placed(ids[1],5,x+75+clearance,6.525)
right=max(transformed(Polygon(families['bracket']['geometry'][0]['outer']),p['transform']).bounds[2] for p in short)
cog_original=Polygon(families['cog']['geometry'][0]['outer']);cb=cog_original.bounds;cgx=right+clearance;cgt={'rotation_radians':0.,'mirrored':False,'translation':[cgx-cb[0],6.525-cb[1]]};short.append({'part_id':'cog','copy_index':items[53]['copy'],'sheet_id':'sheet-1','transform':cgt});records.append({'item':53,'rotation_radians':0.,'lower_left':[cgx,6.525]});placed(37,10,cgx+(cb[2]-cb[0])+clearance,6.525)
first=load(FIRST/'first-sheet-placements.json');allp=first+short;identities={(r['family'],r['copy']):i for i,r in enumerate(items)};ids=[identities[p['part_id'],p['copy_index']] for p in allp];pending=[63,64,65];assert len(set(ids))==63 and sorted(ids+pending)==list(range(66))
stocks=[[float(F(*v)) for v in s] for s in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;native_gap=(job['clearance']+guard)/math.cos(.05);polys={};pairs=[];edges=[];cutouts=vertices=0
for p in allp:
    item=identities[p['part_id'],p['copy_index']];family=families[p['part_id']];t=p['transform'];assert not t['mirrored'] or family['allow_mirror'];degrees=math.degrees(t['rotation_radians'])%360
    assert family['rotations']['kind']=='free' or any(abs(degrees-d)<1e-9 for d in family['rotations']['degrees'])
    g=family['geometry'][0];filled=transformed(Polygon(g['outer']),t);cut=transformed(Polygon(g['outer'],g.get('holes',[])),t);assert filled.is_valid and cut.is_valid and len(cut.interiors)==len(g.get('holes',[]));polys[item]=(p['sheet_id'],filled);cutouts+=len(g.get('holes',[]));vertices+=sum(len(h) for h in g.get('holes',[]));stock=stocks[int(p['sheet_id'].split('-')[1])];b=filled.bounds;extra=[b[0]-stock[0],b[1]-stock[1],stock[2]-b[2],stock[3]-b[3]];assert min(extra)>guard;edges.append({'item':item,'extra_margins_mm':extra})
for a,b in combinations(sorted(polys),2):
    sa,pa=polys[a];sb,pb=polys[b]
    if sa!=sb:continue
    gap=pa.distance(pb);assert pa.intersection(pb).area==0 and gap>native_gap;pairs.append({'items':[a,b],'sheet_id':sa,'distance_mm':gap})
write(OUT/'short-sheet-placements.json',short);write(OUT/'short-sheet-anchors.json',records);write(OUT/'partial63-placements.json',allp);write(OUT/'placed-identities.json',ids);write(OUT/'mandatory-first-additions.json',pending);write(OUT/'original-pair-checks.json',pairs);write(OUT/'original-stock-checks.json',edges)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_placed':63,'first_sheet_originals':55,'short_sheet_originals':8,'short_counts':dict(Counter(p['part_id'] for p in short)),'short_count_matches_proved_upper_bound':True,'first_placements_unchanged':allp[:55]==first,'all66_originals_accounted_once':True,'mandatory_first_sheet_cogs':pending,'original_pair_checks':len(pairs),'stock_edge_checks':4*len(edges),'cutouts_preserved':cutouts,'cutout_vertices_preserved':vertices,'minimum_original_pair_gap_mm':min(r['distance_mm'] for r in pairs),'required_native_pair_gap_mm':native_gap,'minimum_original_stock_extra_mm':min(min(r['extra_margins_mm']) for r in edges),'solver_calls':0,'native_calls':0,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
