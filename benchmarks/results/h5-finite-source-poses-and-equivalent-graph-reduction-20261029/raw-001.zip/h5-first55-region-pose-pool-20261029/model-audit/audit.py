"""Exhaustively verify the finite pose selectors, family counts, site clauses and complete conflict cover."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from itertools import combinations
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-region-pose-pool-20261029';MODEL=BASE/'model';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();assert load(BASE/'audit/checks.json')['passed']
queue=[MODEL/'plan.json'];seen=set();bindings={}
while queue:
    path=queue.pop()
    if path in seen:continue
    seen.add(path)
    for n,h in load(path).get('inputs',{}).items():
        q=ROOT/n;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,n
        bindings[n]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());assert p==text_format.Parse((MODEL/'model.pbtxt').read_text(),cp_model_pb2.CpModelProto())
assert {f.name for f,v in p.ListFields()}=={'variables','constraints'} and len(p.variables)==1540 and len(p.constraints)==7640
pool=load(BASE/'candidates.json');cliques=load(BASE/'cliques.json');residual=load(BASE/'residual-pairs.json');allowed=load(BASE/'allowed-empty-site-pairs.json');mapping=load(MODEL/'mapping.json');n=len(pool)
assert mapping['pose_selectors']==list(range(n)) and mapping['empty_site_selectors']==list(range(n,n+15));empty=mapping['empty_site_selectors']
for i,v in enumerate(p.variables):assert list(v.domain)==[0,1] and v.name==(f'pose_{i}' if i<n else f'empty_cog_site_{i-n}') and {f.name for f,x in v.ListFields()}=={'name','domain'}
used=set()
def constraint(index,kind,guard=()):
    assert index not in used;used.add(index);c=p.constraints[index];assert c.WhichOneof('constraint')==kind and list(c.enforcement_literal)==list(guard) and {f.name for f,v in c.ListFields()}=={kind}|({'enforcement_literal'} if guard else set());return getattr(c,kind)
assert [(r['family'],r['quantity']) for r in mapping['family_constraints']]==[('bracket',7),('insert',6)]
for r in mapping['family_constraints']:
    ids=[x['index'] for x in pool if x['family']==r['family']];assert ids==r['candidates'];c=constraint(r['constraint'],'linear');assert list(c.vars)==ids and list(c.coeffs)==[1]*len(ids) and list(c.domain)==[r['quantity']]*2
c=constraint(mapping['exactly_two_empty_sites_constraint'],'linear');assert list(c.vars)==empty and list(c.coeffs)==[1]*15 and list(c.domain)==[2,2]
forbidden=[list(pair) for pair in combinations(range(15),2) if list(pair) not in allowed];assert [r['empty_sites'] for r in mapping['forbidden_site_pairs']]==forbidden and len(forbidden)==76
for r in mapping['forbidden_site_pairs']:
    c=constraint(r['constraint'],'bool_or');assert list(c.literals)==[-empty[i]-1 for i in r['empty_sites']]
expected=[(r['index'],s) for r in pool for s in r['required_empty_sites']];assert [(r['candidate'],r['site']) for r in mapping['mask_constraints']]==expected
for r in mapping['mask_constraints']:
    c=constraint(r['constraint'],'bool_and',[r['candidate']]);assert list(c.literals)==[empty[r['site']]]
assert len(mapping['clique_constraints'])==len(cliques)==5281 and not residual and not mapping['residual_constraints']
for ix,clique in zip(mapping['clique_constraints'],cliques):c=constraint(ix,'at_most_one');assert list(c.literals)==clique
assert used==set(range(len(p.constraints))) and len(expected)==2280
charges=load(MODEL/'preparation-charges.json');assert sum(charges.values())==load(MODEL/'checks.json')['preparation_seconds_charged']<56
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[MODEL/n for n in ['plan.json','checks.json','model.pb','model.pbtxt','mapping.json','preparation-charges.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'variables_verified':1540,'constraints_verified':7640,'source_pose_selectors':1525,'required_brackets':7,'required_inserts':6,'exactly_two_empty_sites':True,'remaining_site_pairs':29,'forbidden_site_pairs':76,'mask_implications':2280,'complete_conflict_cliques':5281,'all_model_fields_exhaustively_verified':True,'binary_and_text_models_identical':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
