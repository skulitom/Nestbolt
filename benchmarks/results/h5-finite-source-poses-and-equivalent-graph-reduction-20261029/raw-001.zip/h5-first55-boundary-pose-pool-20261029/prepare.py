"""Finite original-source poses at exact convex-region representatives, with a complete conflict graph."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
from itertools import combinations
from copy import deepcopy
import gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';LOCAL=ROOT/'output/h5-first55-local-grid-regions-20261029';OUT=ROOT/'output/h5-first55-boundary-pose-pool-20261029';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(LOCAL/'component-halfspace-bound/audit/checks.json')['passed'] and load(PRIOR/'source-region-audit/checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
inputs=[Path(__file__),JOB,FIRST/'plan.json',FIRST/'fixed29.json',SLOTS/'plan.json',SLOTS/'source-cog-sites.json',PRIOR/'plan.json',PRIOR/'inventory.json',PRIOR/'family-modes.json',PRIOR/'integer-preparation/plan.json',PRIOR/'integer-preparation/unary-templates.json',PRIOR/'source-region-audit/plan.json',PRIOR/'source-region-audit/checks.json',LOCAL/'component-halfspace-bound/audit/plan.json',LOCAL/'component-halfspace-bound/audit/checks.json',LOCAL/'component-halfspace-bound/audit/allowed-empty-site-pairs.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For each original convex source region compatible with one of29 site choices, regenerate its exact vertex mean, then add both endpoints of an exact farthest-vertex pair inset by1/1000 toward that mean. Retain all legal source modes and aliases. This independent three-representative construction regenerates every pose and graph directly from the source regions; it does not resume or extend the closed centroid solve. Reconstruct original polygons, check stock, fixed29 and nonempty cog sites, and enumerate all unordered pose conflicts in bounded-memory batches at0.225mm clearance. Compress only actual conflict cliques for at most5seconds, retaining every residual edge. Select7 brackets and6 inserts jointly with13 of15 cog sites; assign original copy identities after selection. Independently audit the complete pool, graph, cover and model before a single60/90-second call. Finite-pool negatives are not global exclusions.','preparation_cap_seconds':20,'clique_cover_cap_seconds':5,'pair_gap_mm':0.225,'algorithm_seconds':60,'shared_seconds':90,'source_validation_reserve_seconds':4,'maximum_calls':1,'retry_permitted':False,'solver_calls':0,'native_calls':0})
started=time.perf_counter();job=load(JOB);parts={p['id']:p for p in job['parts']};modes=load(PRIOR/'family-modes.json');unary=load(PRIOR/'integer-preparation/unary-templates.json');allowed=load(LOCAL/'component-halfspace-bound/audit/allowed-empty-site-pairs.json');fixed=load(FIRST/'fixed29.json');sites=load(SLOTS/'source-cog-sites.json')
def polygon(family,t):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    return Polygon([(m*x*c-y*s+tx,m*x*s+y*c+ty) for x,y in parts[family]['geometry'][0]['outer']])
fixed_polys=np.asarray([polygon(r['part_id'],r['transform']) for r in fixed],dtype=object);site_polys=np.asarray([polygon('cog',r['transform']) for r in sites],dtype=object)
pool=[];polys=[];fixed_min=site_min=math.inf;stock_min=math.inf
for family,opts in modes.items():
    for mode in opts:
        gid=mode['normalized_geometry']
        for region in unary[gid]['regions']:
            if not any(set(region['required_empty_sites'])<=set(pair) for pair in allowed):continue
            points=[tuple(map(F,p)) for p in region['hull_vertices']];center=[sum(p[k] for p in points)/len(points) for k in [0,1]];xy=list(map(float,center));t={'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]+mode['translation_from_lower_left'][k] for k in [0,1]]};p=polygon(family,t)
            assert p.is_valid and not p.is_empty
            l,b,r,top=p.bounds;extra=min(l-6.5,b-6.5,1493.5-r,2993.5-top);assert extra>0.011444091796875;stock_min=min(stock_min,extra)
            df=float(np.min(shapely.distance(p,fixed_polys)));assert df>=0.224999999;fixed_min=min(fixed_min,df)
            eligible=[i for i in range(15) if i not in region['required_empty_sites']];ds=float(np.min(shapely.distance(p,site_polys[eligible])));assert ds>=0.225;site_min=min(site_min,ds)
            pool.append({'index':len(pool),'family':family,'mode':mode['mode'],'geometry':gid,'region':region['region'],'required_empty_sites':region['required_empty_sites'],'exact_lower_left_mm':[str(v) for v in center],'lower_left_mm':xy,'transform':t});polys.append(p)
assert Counter(p['family'] for p in pool)=={'bracket':707,'insert':818} and len(pool)==1525
parents=list(pool)
for parent in parents:
    region=unary[parent['geometry']]['regions'][parent['region']];points=[tuple(map(F,p)) for p in region['hull_vertices']];center=tuple(map(F,parent['exact_lower_left_mm']))
    endpoints=max(combinations(range(len(points)),2),key=lambda pair:sum((points[pair[0]][k]-points[pair[1]][k])**2 for k in [0,1]))
    for vertex in endpoints:
        exact=[(999*points[vertex][k]+center[k])/1000 for k in [0,1]];xy=list(map(float,exact));mode=modes[parent['family']][parent['mode']]
        t={'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]+mode['translation_from_lower_left'][k] for k in [0,1]]};p=polygon(parent['family'],t)
        l,b,r,top=p.bounds;extra=min(l-6.5,b-6.5,1493.5-r,2993.5-top);assert p.is_valid and extra>0.011444091796875;stock_min=min(stock_min,extra)
        df=float(np.min(shapely.distance(p,fixed_polys)));assert df>=0.224999999;fixed_min=min(fixed_min,df)
        eligible=[i for i in range(15) if i not in parent['required_empty_sites']];ds=float(np.min(shapely.distance(p,site_polys[eligible])));assert ds>=0.225;site_min=min(site_min,ds)
        record=deepcopy(parent);record.update({'index':len(pool),'exact_lower_left_mm':[str(v) for v in exact],'lower_left_mm':xy,'transform':t,'parent_centroid':parent['index'],'endpoint_vertex':vertex,'inset_fraction':'1/1000'})
        pool.append(record);polys.append(p)
assert Counter(p['family'] for p in pool)=={'bracket':2121,'insert':2454} and len(pool)==4575
assert time.perf_counter()-started<20
n=len(pool);arr=np.asarray(polys,dtype=object);graph=[0]*n;distance_checks=0
for first in range(0,n,128):
    row_ids=range(first,min(n,first+128));ii=np.concatenate([np.full(n-i-1,i,dtype=np.int32) for i in row_ids]);jj=np.concatenate([np.arange(i+1,n,dtype=np.int32) for i in row_ids]);distance=shapely.distance(arr[ii],arr[jj]);bad=distance<0.225;distance_checks+=len(ii)
    for i,j in zip(ii[bad],jj[bad]):i,j=int(i),int(j);graph[i]|=1<<j;graph[j]|=1<<i
    assert time.perf_counter()-started<20,'Complete generation and graph preparation cap reached'
assert distance_checks==n*(n-1)//2
edge_count=sum(row.bit_count() for row in graph)//2;nb=(n+7)//8;raw=b''.join(row.to_bytes(nb,'little') for row in graph)
with (OUT/'graph.bin.gz').open('xb') as f:f.write(gzip.compress(raw,mtime=0))
generation_seconds=time.perf_counter()-started;assert generation_seconds<20
remaining=list(graph);cliques=[];cover_start=time.perf_counter();cover_deadline=cover_start+5
for v in sorted(range(n),key=lambda i:(-graph[i].bit_count(),i)):
    while remaining[v] and time.perf_counter()<cover_deadline:
        clique=[v];common=remaining[v]
        while common:
            bit=common&-common;u=bit.bit_length()-1;clique.append(u);common&=graph[u]
        mask=sum(1<<i for i in clique)
        for i in clique:assert graph[i]&(mask^(1<<i))==mask^(1<<i);remaining[i]&=~mask
        cliques.append(clique)
    if time.perf_counter()>=cover_deadline:break
cover_seconds=time.perf_counter()-cover_start
residual=[]
for i,row in enumerate(remaining):
    while row:
        bit=row&-row;j=bit.bit_length()-1;row^=bit
        if i<j:residual.append([i,j])
recovered=[0]*n
for clique in cliques:
    mask=sum(1<<i for i in clique)
    for i in clique:recovered[i]|=mask^(1<<i)
for i,j in residual:recovered[i]|=1<<j;recovered[j]|=1<<i
assert recovered==graph
for name,data in [('candidates.json',pool),('allowed-empty-site-pairs.json',allowed),('cliques.json',cliques),('residual-pairs.json',residual)]:write(OUT/name,data)
shutil.copyfile(PRIOR/'inventory.json',OUT/'inventory.json')
elapsed=time.perf_counter()-started
checks={'passed':True,'seconds':elapsed,'candidate_and_graph_seconds':generation_seconds,'cover_seconds':cover_seconds,'cover_cap_overrun_seconds':max(0,cover_seconds-5),'preparation_cap_overrun_seconds':max(0,elapsed-20),'candidates':n,'bracket_candidates':2121,'insert_candidates':2454,'centroid_candidates':1525,'boundary_candidates':3050,'source_family_modes':len({(p['family'],p['mode']) for p in pool}),'remaining_site_pairs':29,'all_unordered_pairs_checked':distance_checks,'conflicts':edge_count,'cliques':len(cliques),'residual_conflicts':len(residual),'exact_graph_cover':True,'minimum_fixed29_gap_mm':fixed_min,'minimum_nonempty_cog_gap_mm':site_min,'minimum_extra_source_stock_gap_mm':stock_min,'source_valid66':False,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
