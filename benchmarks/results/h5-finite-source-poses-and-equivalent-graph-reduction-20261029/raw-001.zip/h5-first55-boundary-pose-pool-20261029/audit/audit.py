"""Independently reconstruct all source poses and compare the complete graph with geometric predicates."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
from itertools import combinations
import gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-boundary-pose-pool-20261029';PRIOR=ROOT/'output/h5-first55-cog-site-masks-20261029';OUT=BASE/'audit';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
parts={p['id']:p for p in load(JOB)['parts']};originals={k:Polygon(p['geometry'][0]['outer']) for k,p in parts.items()};modes=load(PRIOR/'family-modes.json');unary=load(PRIOR/'integer-preparation/unary-templates.json');allowed=load(BASE/'allowed-empty-site-pairs.json');pool=load(BASE/'candidates.json');expected=[]
for family,opts in modes.items():
    for mode in opts:
        for region in unary[mode['normalized_geometry']]['regions']:
            if any(set(region['required_empty_sites'])<=set(pair) for pair in allowed):expected.append((family,mode,region))
assert len(expected)==1525 and len(pool)==4575 and len(allowed)==29
expanded=[];endpoints=[]
for parent,(family,mode,region) in enumerate(expected):
    points=[tuple(map(F,v)) for v in region['hull_vertices']];mean=tuple(sum(p[k] for p in points)/len(points) for k in [0,1]);expanded.append((family,mode,region,mean,None))
    ranked=sorted(((-sum((points[a][k]-points[b][k])**2 for k in [0,1]),a,b) for a,b in combinations(range(len(points)),2)))
    _,a,b=ranked[0]
    for vertex in [a,b]:endpoints.append((family,mode,region,tuple((999*points[vertex][k]+mean[k])/1000 for k in [0,1]),{'parent_centroid':parent,'endpoint_vertex':vertex,'inset_fraction':'1/1000'}))
expected=expanded+endpoints
assert len(endpoints)==3050
def pose(family,t):
    c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    return affine_transform(originals[family],[m*c,-s,m*s,c,tx,ty])
polys=[];hull_edges=0
for i,(record,(family,mode,region,expected_center,endpoint)) in enumerate(zip(pool,expected)):
    assert record['index']==i and record['family']==family and record['mode']==mode['mode'] and record['geometry']==mode['normalized_geometry'] and record['region']==region['region'] and record['required_empty_sites']==region['required_empty_sites']
    points=[tuple(map(F,v)) for v in region['hull_vertices']];center=tuple(map(F,record['exact_lower_left_mm']));assert center==expected_center
    assert {k:record[k] for k in ['parent_centroid','endpoint_vertex','inset_fraction'] if k in record}==(endpoint or {})
    for a,b in zip(points,points[1:]+points[:1]):assert (b[0]-a[0])*(center[1]-a[1])-(b[1]-a[1])*(center[0]-a[0])>=0;hull_edges+=1
    xy=list(map(float,center));assert record['lower_left_mm']==xy
    assert record['transform']=={'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]+mode['translation_from_lower_left'][k] for k in [0,1]]}
    p=pose(family,record['transform']);l,b,r,t=p.bounds;assert min(l-6.5,b-6.5,1493.5-r,2993.5-t)>0.011444091796875 and p.is_valid;polys.append(p)
fixed=np.asarray([pose(r['part_id'],r['transform']) for r in load(FIRST/'fixed29.json')],dtype=object);cogs=np.asarray([pose('cog',r['transform']) for r in load(SLOTS/'source-cog-sites.json')],dtype=object)
for r,p in zip(pool,polys):
    assert not shapely.dwithin(p,fixed,0.224999999).any()
    assert not shapely.dwithin(p,cogs[[j for j in range(15) if j not in r['required_empty_sites']]],0.225).any()
n=len(pool);nb=(n+7)//8;raw=gzip.decompress((BASE/'graph.bin.gz').read_bytes());assert len(raw)==n*nb;graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)];arr=np.asarray(polys,dtype=object);threshold_distance=math.inf;expected_graph=[0]*n;pair_checks=0
for first in range(0,n,128):
    ids=range(first,min(n,first+128));ii=np.concatenate([np.full(n-i-1,i,dtype=np.int32) for i in ids]);jj=np.concatenate([np.arange(i+1,n,dtype=np.int32) for i in ids]);pair_checks+=len(ii)
    distances=shapely.distance(arr[ii],arr[jj]);threshold_distance=min(threshold_distance,float(np.min(np.abs(distances-0.225))))
    conflicts=shapely.dwithin(arr[ii],arr[jj],0.225)
    for i,j in zip(ii[conflicts],jj[conflicts]):i,j=int(i),int(j);expected_graph[i]|=1<<j;expected_graph[j]|=1<<i
assert threshold_distance>1e-8 and pair_checks==n*(n-1)//2
assert expected_graph==graph
recovered=[0]*n;cliques=load(BASE/'cliques.json');residual=load(BASE/'residual-pairs.json')
for clique in cliques:
    assert len(clique)>=2 and len(set(clique))==len(clique);mask=sum(1<<i for i in clique)
    for i in clique:assert graph[i]&(mask^(1<<i))==mask^(1<<i);recovered[i]|=mask^(1<<i)
for i,j in residual:assert i<j and graph[i]>>j&1;recovered[i]|=1<<j;recovered[j]|=1<<i
assert recovered==graph and Counter(r['family'] for r in pool)=={'bracket':2121,'insert':2454}
source_checks=load(BASE/'checks.json');assert source_checks['preparation_cap_overrun_seconds']==source_checks['cover_cap_overrun_seconds']==0
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','candidates.json','allowed-empty-site-pairs.json','inventory.json','graph.bin.gz','cliques.json','residual-pairs.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'source_poses_verified':n,'source_family_modes':12,'exact_hull_membership_edges_verified':hull_edges,'all_candidate_pairs_verified':pair_checks,'conflicts_verified':sum(r.bit_count() for r in graph)//2,'cliques_verified':len(cliques),'residual_pairs_verified':len(residual),'minimum_pair_distance_to_graph_threshold_mm':threshold_distance,'exact_graph_cover':True,'stock_and_fixed_sources_checked':True,'remaining_site_pairs':29,'source_valid66':False,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
