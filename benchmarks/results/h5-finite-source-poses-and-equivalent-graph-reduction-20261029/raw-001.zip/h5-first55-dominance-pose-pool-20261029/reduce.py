"""Exact same-family closed-neighbourhood and dominance reduction of the fixed finite source pool."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import defaultdict,Counter
import gzip,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];PRIOR=ROOT/'output/h5-first55-boundary-pose-pool-20261029';OUT=ROOT/'output/h5-first55-dominance-pose-pool-20261029'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(PRIOR/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'reduce.py')
inputs=[Path(__file__)]+[PRIOR/n for n in ['plan.json','checks.json','audit/plan.json','audit/checks.json','candidates.json','graph.bin.gz','cliques.json','residual-pairs.json','allowed-empty-site-pairs.json','inventory.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Start from the complete audited finite source-pose graph. Remove only a pose B with a currently active same-family replacement A that conflicts with B, requires a subset of B empty sites, and has no active neighbour other than B that is absent from B neighbours other than A. An independent set containing B cannot already contain A, so replacing B with A preserves exact family counts, site feasibility and compatibility. Record each sequential removal; first collapse equal closed-neighbourhood/mask twins, then bounded greedy dominance. Project the original exact clique cover onto retained vertices, drop singleton/duplicate clauses, and verify the complete induced graph. This preserves finite-pool feasibility, not global continuous feasibility.','dominance_discovery_cap_seconds':5,'unprocessed_vertices_retained':True,'solver_calls':0,'new_source_poses':0,'global_allocation_exclusions':0})
started=time.perf_counter();pool=load(PRIOR/'candidates.json');n=len(pool);nb=(n+7)//8;raw=gzip.decompress((PRIOR/'graph.bin.gz').read_bytes());graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)];active=(1<<n)-1;groups=defaultdict(list);masks=[sum(1<<s for s in p['required_empty_sites']) for p in pool];family_masks={f:sum(1<<i for i,p in enumerate(pool) if p['family']==f) for f in ['bracket','insert']};proofs=[]
def remove(b,a,kind):
    global active
    assert a!=b and active>>a&1 and active>>b&1 and pool[a]['family']==pool[b]['family'] and graph[a]>>b&1 and masks[a]&~masks[b]==0
    na=graph[a]&active&~(1<<b);nb=graph[b]&active&~(1<<a);assert na&~nb==0
    proofs.append({'removed':b,'replacement':a,'kind':kind,'active_count_before':active.bit_count(),'replacement_external_degree':na.bit_count(),'removed_external_degree':nb.bit_count()});active&=~(1<<b)
for i,p in enumerate(pool):groups[(p['family'],masks[i],graph[i]|1<<i)].append(i)
for members in groups.values():
    for b in members[1:]:remove(b,members[0],'identical_closed_neighbourhood')
twins=len(proofs);deadline=time.perf_counter()+5;passes=0;cap_reached=False
while True:
    before=len(proofs);nodes=[i for i in range(n) if active>>i&1];degrees={i:(graph[i]&active).bit_count() for i in nodes};passes+=1
    for b in sorted(nodes,key=lambda i:(-degrees[i],i)):
        if time.perf_counter()>=deadline:cap_reached=True;break
        if not active>>b&1:continue
        possible=graph[b]&active&family_masks[pool[b]['family']];candidates=[]
        while possible:
            bit=possible&-possible;a=bit.bit_length()-1;possible^=bit
            if masks[a]&~masks[b]==0:candidates.append(a)
        for a in sorted(candidates,key=lambda i:(degrees[i],i)):
            na=graph[a]&active&~(1<<b);nbits=graph[b]&active&~(1<<a)
            if na&~nbits==0:remove(b,a,'active_neighbourhood_dominance');break
    if cap_reached or len(proofs)==before:break
retained=[i for i in range(n) if active>>i&1];lookup={old:new for new,old in enumerate(retained)};reduced=[{**pool[old],'index':new,'original_candidate':old} for new,old in enumerate(retained)];new_graph=[0]*len(retained)
for i,old in enumerate(retained):
    row=graph[old]&active
    while row:bit=row&-row;j=bit.bit_length()-1;row^=bit;new_graph[i]|=1<<lookup[j]
assert not load(PRIOR/'residual-pairs.json')
cliques=sorted({tuple(sorted(lookup[i] for i in c if i in lookup)) for c in load(PRIOR/'cliques.json')});cliques=[list(c) for c in cliques if len(c)>=2];recovered=[0]*len(retained)
for c in cliques:
    mask=sum(1<<i for i in c)
    for i in c:recovered[i]|=mask^(1<<i)
assert recovered==new_graph
for name,data in [('candidates.json',reduced),('retained-indices.json',retained),('removal-proofs.json',proofs),('cliques.json',cliques),('residual-pairs.json',[])]:write(OUT/name,data)
for name in ['allowed-empty-site-pairs.json','inventory.json']:shutil.copyfile(PRIOR/name,OUT/name)
width=(len(retained)+7)//8
with (OUT/'graph.bin.gz').open('xb') as f:f.write(gzip.compress(b''.join(row.to_bytes(width,'little') for row in new_graph),mtime=0))
elapsed=time.perf_counter()-started
checks={'passed':True,'seconds':elapsed,'original_candidates':n,'retained_candidates':len(retained),'retained_by_family':dict(Counter(p['family'] for p in reduced)),'removed_identical_closed_neighbourhoods':twins,'removed_other_dominated_vertices':len(proofs)-twins,'sequential_removal_proofs':len(proofs),'dominance_passes':passes,'discovery_cap_reached':cap_reached,'remaining_site_pairs':29,'induced_conflicts':sum(r.bit_count() for r in new_graph)//2,'projected_cliques':len(cliques),'residual_conflicts':0,'finite_pool_feasibility_equivalence_claim_requires_independent_audit':True,'new_source_poses':0,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
