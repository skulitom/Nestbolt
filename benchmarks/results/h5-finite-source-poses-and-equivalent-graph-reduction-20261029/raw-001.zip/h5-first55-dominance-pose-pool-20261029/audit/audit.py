"""Verify every replacement preserves family counts, site guards and all active non-conflicts."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import gzip,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-dominance-pose-pool-20261029';PRIOR=ROOT/'output/h5-first55-boundary-pose-pool-20261029';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def graph(folder,n):
    width=(n+7)//8;raw=gzip.decompress((folder/'graph.bin.gz').read_bytes());assert len(raw)==n*width
    return [int.from_bytes(raw[i*width:(i+1)*width],'little') for i in range(n)]
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();queue=[BASE/'plan.json'];seen=set();bindings={}
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    for name,h in load(p).get('inputs',{}).items():
        q=ROOT/name;assert q.is_relative_to(ROOT) and not {'.claude','.cache'}&set(q.parts) and digest(q)==h,name
        bindings[name]=h
        if q.name in ['plan.json','opened.json']:queue.append(q)
pool=load(PRIOR/'candidates.json');original=graph(PRIOR,len(pool));active=set(range(len(pool)));active_mask=(1<<len(pool))-1;proofs=load(BASE/'removal-proofs.json');twins=0
for proof in proofs:
    b,a=proof['removed'],proof['replacement'];assert a!=b and a in active and b in active and proof['active_count_before']==len(active)
    assert pool[a]['family']==pool[b]['family'] and set(pool[a]['required_empty_sites'])<=set(pool[b]['required_empty_sites']) and original[a]>>b&1 and original[b]>>a&1
    replacement_neighbors=original[a]&active_mask&~(1<<b);removed_neighbors=original[b]&active_mask&~(1<<a)
    assert replacement_neighbors|removed_neighbors==removed_neighbors
    assert proof['replacement_external_degree']==replacement_neighbors.bit_count() and proof['removed_external_degree']==removed_neighbors.bit_count()
    if proof['kind']=='identical_closed_neighbourhood':assert original[a]|1<<a==original[b]|1<<b and pool[a]['required_empty_sites']==pool[b]['required_empty_sites'];twins+=1
    else:assert proof['kind']=='active_neighbourhood_dominance'
    active.remove(b);active_mask^=1<<b
retained=load(BASE/'retained-indices.json');assert retained==sorted(active);new_pool=load(BASE/'candidates.json');assert len(new_pool)==len(retained)
for i,(record,old) in enumerate(zip(new_pool,retained)):assert record=={**pool[old],'index':i,'original_candidate':old}
new_graph=graph(BASE,len(retained));lookup={old:i for i,old in enumerate(retained)}
for i,old in enumerate(retained):
    expected=sum(1<<lookup[j] for j in retained if original[old]>>j&1);assert new_graph[i]==expected
projected=sorted({tuple(sorted(lookup[i] for i in c if i in lookup)) for c in load(PRIOR/'cliques.json')});projected=[list(c) for c in projected if len(c)>=2];assert projected==load(BASE/'cliques.json') and not load(BASE/'residual-pairs.json');recovered=[0]*len(retained)
for c in projected:
    mask=sum(1<<i for i in c)
    for i in c:assert new_graph[i]&(mask^(1<<i))==mask^(1<<i);recovered[i]|=mask^(1<<i)
assert recovered==new_graph
for n in ['allowed-empty-site-pairs.json','inventory.json']:assert digest(BASE/n)==digest(PRIOR/n)
write(OUT/'source-bindings.json',bindings)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','checks.json','candidates.json','retained-indices.json','removal-proofs.json','graph.bin.gz','cliques.json','residual-pairs.json','allowed-empty-site-pairs.json','inventory.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'recursive_bindings':len(bindings),'original_candidates':len(pool),'retained_candidates':len(retained),'sequential_replacement_proofs_verified':len(proofs),'identical_closed_neighbourhoods_verified':twins,'same_family_counts_preserved':True,'replacement_cannot_already_be_selected_with_removed_pose':True,'all_active_external_neighbours_subset_verified':True,'site_guards_never_strengthened':True,'induced_graph_and_complete_projected_cover_verified':True,'finite_pool_feasibility_equivalent':True,'new_source_poses':0,'global_allocation_exclusions':0,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
