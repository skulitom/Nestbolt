from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import gzip,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-dominance-pose-pool-20261029';COVER=BASE/'maximal-cover';OUT=COVER/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for name,h in load(COVER/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
old=load(BASE/'cliques.json');new=load(COVER/'cliques.json');indices=load(COVER/'kept-original-indices.json');proofs=load(COVER/'covering-clique-indices.json');assert len(new)==len(indices) and len(proofs)==len(old) and len(set(indices))==len(indices)
for c,i in zip(new,indices):assert c==old[i]
for c,target in zip(old,proofs):assert 0<=target<len(new) and set(c)<=set(new[target])
n=len(load(BASE/'candidates.json'));width=(n+7)//8;raw=gzip.decompress((BASE/'graph.bin.gz').read_bytes());graph=[int.from_bytes(raw[i*width:(i+1)*width],'little') for i in range(n)];recovered=[0]*n
for c in new:
    mask=sum(1<<i for i in c)
    for i in c:assert graph[i]&(mask^(1<<i))==mask^(1<<i);recovered[i]|=mask^(1<<i)
assert recovered==graph
inputs=[Path(__file__)]+[COVER/n for n in ['plan.json','checks.json','cliques.json','kept-original-indices.json','covering-clique-indices.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'original_rows_verified':len(old),'retained_rows_verified':len(new),'subset_implications_verified':len(old)-len(new),'exact_complete_graph_cover_verified':True,'finite_pool_feasibility_equivalent':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
