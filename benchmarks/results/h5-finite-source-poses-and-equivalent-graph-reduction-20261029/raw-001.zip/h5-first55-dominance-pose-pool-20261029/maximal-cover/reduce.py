"""Remove only clique constraints contained in retained supersets."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import gzip,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-dominance-pose-pool-20261029';OUT=BASE/'maximal-cover'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'reduce.py');started=time.perf_counter()
cliques=load(BASE/'cliques.json');n=len(load(BASE/'candidates.json'));members=[[] for _ in range(n)];kept=[];kept_masks=[];kept_indices=[];proofs=[None]*len(cliques)
for index in sorted(range(len(cliques)),key=lambda i:(-len(cliques[i]),cliques[i])):
    c=cliques[index];mask=sum(1<<i for i in c);pivot=min(c,key=lambda i:len(members[i]));parent=next((j for j in members[pivot] if mask&~kept_masks[j]==0),None)
    if parent is None:
        parent=len(kept);kept.append(c);kept_masks.append(mask);kept_indices.append(index)
        for i in c:members[i].append(parent)
    proofs[index]=parent
width=(n+7)//8;raw=gzip.decompress((BASE/'graph.bin.gz').read_bytes());graph=[int.from_bytes(raw[i*width:(i+1)*width],'little') for i in range(n)];recovered=[0]*n
for c,mask in zip(kept,kept_masks):
    for i in c:recovered[i]|=mask^(1<<i)
assert recovered==graph
write(OUT/'cliques.json',kept);write(OUT/'kept-original-indices.json',kept_indices);write(OUT/'covering-clique-indices.json',proofs)
inputs=[Path(__file__)]+[BASE/n for n in ['plan.json','audit/plan.json','audit/checks.json','candidates.json','graph.bin.gz','cliques.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Process projected cliques in descending size. Keep a clique unless a previously kept clique contains every one of its vertices; use the least frequent vertex only to accelerate searching for such a superset. Record a retained covering clique for every original row and reconstruct the complete graph from the retained rows. No candidate, edge or source pose changes.','solver_calls':0})
checks={'passed':True,'seconds':time.perf_counter()-started,'original_cliques':len(cliques),'retained_cliques':len(kept),'removed_subset_rows':len(cliques)-len(kept),'graph_unchanged':True,'independent_audit_required':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
