"""Independent direct evaluation of the finite pose model's Boolean and counting rows."""
def violations(p,values):
    assert len(values)==len(p.variables)
    for v,x in zip(p.variables,values):assert any(a<=x<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    def truth(i):return bool(values[i]) if i>=0 else not bool(values[-i-1])
    failed=[];checked=0
    for index,c in enumerate(p.constraints):
        if not all(truth(i) for i in c.enforcement_literal):continue
        kind=c.WhichOneof('constraint')
        if kind=='linear':
            total=sum(a*values[i] for i,a in zip(c.linear.vars,c.linear.coeffs));ok=any(lo<=total<=hi for lo,hi in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        elif kind=='bool_or':ok=any(truth(i) for i in c.bool_or.literals)
        elif kind=='bool_and':ok=all(truth(i) for i in c.bool_and.literals)
        elif kind=='at_most_one':ok=sum(truth(i) for i in c.at_most_one.literals)<=1
        else:raise AssertionError(kind)
        checked+=1
        if not ok:failed.append({'constraint':index,'kind':kind})
    return {'failed_constraints':failed,'active_constraints_checked':checked,'all_boolean_domains_checked':True}
