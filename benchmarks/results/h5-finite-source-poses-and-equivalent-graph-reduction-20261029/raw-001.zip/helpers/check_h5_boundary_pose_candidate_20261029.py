"""Assign original copy identities and validate all66 source parts from selected complete poses."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from copy import deepcopy
from collections import Counter
import json,sys,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-boundary-pose-pool-20261029';SEARCH=BASE/'search';OUT=SEARCH/'source-response';FIRST=ROOT/'output/h5-first55-after-source-valid11-20261029';SLOTS=ROOT/'output/h5-first55-integer-mode-regions-v2-20261029/cog-slot-selection-preflight';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029/search/source-response/candidate-source11.json';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
started=float(sys.argv[1]);OUT.mkdir();mapping=load(BASE/'model/mapping.json');pool=load(BASE/'candidates.json');values=load(SEARCH/'assignment.json');inventory=load(BASE/'inventory.json');sites=load(SLOTS/'source-cog-sites.json');empty=[i for i,v in enumerate(mapping['empty_site_selectors']) if values[v]];assert len(empty)==2 and empty in load(BASE/'allowed-empty-site-pairs.json')
selected=[p for p,v in zip(pool,mapping['pose_selectors']) if values[v]];assert Counter(p['family'] for p in selected)=={'bracket':7,'insert':6}
rows=load(FIRST/'fixed29.json');site_choices=[]
occupied=[i for i in range(15) if i not in empty]
for site,identity in zip(occupied,inventory['required_cog13_identities']):
    row=deepcopy(sites[site]);assert identity[0]=='cog';row['copy_index']=identity[1];rows.append(row);site_choices.append({'site':site,'identity':identity,'transform':row['transform']})
rows+=load(SHORT);chosen=[]
for family in ['bracket','insert']:
    candidates=sorted((p for p in selected if p['family']==family),key=lambda p:(*p['lower_left_mm'],p['mode'],p['index']));identities=sorted((p for p in inventory['moving13_orthogonal_identities'] if p[0]==family),key=lambda p:p[1]);assert len(candidates)==len(identities)
    for pose,identity in zip(candidates,identities):
        assert set(pose['required_empty_sites'])<=set(empty)
        rows.append({'part_id':family,'copy_index':identity[1],'sheet_id':'sheet-0','transform':pose['transform']});chosen.append({'candidate':pose['index'],'identity':identity,'mode':pose['mode'],'lower_left_mm':pose['lower_left_mm'],'region':pose['region']})
job=load(JOB);spec=load(FIRST/'plan.json');assert len(rows)==66
check=audit(job,rows,spec['source_stocks'],spec['required_pair_gap_mm'],spec['stock_guard_mm'],list(map(tuple,inventory['full66_identities'])))
assert check['cutouts']==90 and check['hole_vertices']==10026 and check['same_sheet_pairs']==1540 and check['stock_edges']==264
write(OUT/'candidate-source66.json',rows);write(OUT/'selected-source-poses.json',chosen);write(OUT/'selected-cog-sites.json',{'empty_sites':empty,'occupied_sites':site_choices});write(OUT/'original-source-checks.json',check)
inputs=[Path(__file__),ROOT/'output/h5_legacy64_source_readback.py',JOB,SHORT,FIRST/'plan.json',FIRST/'fixed29.json',SLOTS/'source-cog-sites.json',BASE/'candidates.json',BASE/'allowed-empty-site-pairs.json',BASE/'inventory.json',BASE/'model/mapping.json',SEARCH/'assignment.json',SEARCH/'assignment-check.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
result={'source_valid66':check['valid'],'originals':66,'first_originals':55,'short_originals':11,'empty_cog_sites':empty,'same_sheet_pairs':1540,'stock_edges':264,'cutouts':90,'hole_vertices':10026,'source_checker_calls':1,'algorithm_seconds_including_preparation':time.perf_counter()-started,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',result);print(result)
