from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/run_h5_local_grid_model_20261029.py').read_text(encoding='utf-8')
changes=[('h5-first55-local-grid-regions-20261029','h5-first55-region-pose-pool-20261029'),('geometry-audit','audit'),('h5_source_projection_short_core_reader_20261029','h5_region_pose_assignment_reader_20261029'),('check_h5_local_grid_candidate_20261029.py','check_h5_region_pose_candidate_20261029.py')]
for a,b in changes:
    assert a in s,a
    s=s.replace(a,b)
p=ROOT/'output/run_h5_region_pose_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'maximum_calls':1,'full66_source_reader_ready':True})
