from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_region_pose_pool_20261029.py').read_text(encoding='utf-8').replace('from collections import Counter','from collections import Counter\nfrom itertools import combinations').replace("BASE=ROOT/'output/h5-first55-region-pose-pool-20261029'","BASE=ROOT/'output/h5-first55-boundary-pose-pool-20261029'")
needle="assert len(expected)==len(pool)==1525 and len(allowed)==29"
replacement='''assert len(expected)==1525 and len(pool)==4575 and len(allowed)==29
expanded=[];endpoints=[]
for parent,(family,mode,region) in enumerate(expected):
    points=[tuple(map(F,v)) for v in region['hull_vertices']];mean=tuple(sum(p[k] for p in points)/len(points) for k in [0,1]);expanded.append((family,mode,region,mean,None))
    ranked=sorted(((-sum((points[a][k]-points[b][k])**2 for k in [0,1]),a,b) for a,b in combinations(range(len(points)),2)))
    _,a,b=ranked[0]
    for vertex in [a,b]:endpoints.append((family,mode,region,tuple((999*points[vertex][k]+mean[k])/1000 for k in [0,1]),{'parent_centroid':parent,'endpoint_vertex':vertex,'inset_fraction':'1/1000'}))
expected=expanded+endpoints
assert len(endpoints)==3050'''
assert needle in s;s=s.replace(needle,replacement)
s=s.replace("for i,(record,(family,mode,region)) in enumerate(zip(pool,expected)):","for i,(record,(family,mode,region,expected_center,endpoint)) in enumerate(zip(pool,expected)):")
old="assert all(center[k]*len(points)==sum(p[k] for p in points) for k in [0,1])"
new="assert center==expected_center\n    assert {k:record[k] for k in ['parent_centroid','endpoint_vertex','inset_fraction'] if k in record}==(endpoint or {})"
assert old in s;s=s.replace(old,new)
a=s.index('n=len(pool);nb=');b=s.index('assert expected_graph==graph',a)
s=s[:a]+'''n=len(pool);nb=(n+7)//8;raw=gzip.decompress((BASE/'graph.bin.gz').read_bytes());assert len(raw)==n*nb;graph=[int.from_bytes(raw[i*nb:(i+1)*nb],'little') for i in range(n)];arr=np.asarray(polys,dtype=object);threshold_distance=math.inf;expected_graph=[0]*n;pair_checks=0
for first in range(0,n,128):
    ids=range(first,min(n,first+128));ii=np.concatenate([np.full(n-i-1,i,dtype=np.int32) for i in ids]);jj=np.concatenate([np.arange(i+1,n,dtype=np.int32) for i in ids]);pair_checks+=len(ii)
    distances=shapely.distance(arr[ii],arr[jj]);threshold_distance=min(threshold_distance,float(np.min(np.abs(distances-0.225))))
    conflicts=shapely.dwithin(arr[ii],arr[jj],0.225)
    for i,j in zip(ii[conflicts],jj[conflicts]):i,j=int(i),int(j);expected_graph[i]|=1<<j;expected_graph[j]|=1<<i
assert threshold_distance>1e-8 and pair_checks==n*(n-1)//2
'''+s[b:]
s=s.replace("{'bracket':707,'insert':818}","{'bracket':2121,'insert':2454}").replace("'all_candidate_pairs_verified':len(ii)","'all_candidate_pairs_verified':pair_checks")
p=ROOT/'output/audit_h5_boundary_pose_pool_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
build=(ROOT/'output/build_h5_region_pose_model_20261029.py').read_text(encoding='utf-8').replace('h5-first55-region-pose-pool-20261029','h5-first55-boundary-pose-pool-20261029')
with (ROOT/'output/build_h5_boundary_pose_model_20261029.py').open('x',encoding='utf-8',newline='\n') as f:f.write(build)
print({'prepared_audit':p.name,'source_candidates':4575,'independent_farthest_endpoint_and_full_graph_readback':True})
