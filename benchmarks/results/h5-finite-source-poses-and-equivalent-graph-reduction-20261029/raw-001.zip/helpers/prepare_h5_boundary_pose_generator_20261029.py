"""Prepare a separate three-representative source pool without reopening the centroid call."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/prepare_h5_region_pose_pool_20261029.py').read_text(encoding='utf-8')
s=s.replace('from collections import Counter','from collections import Counter\nfrom itertools import combinations\nfrom copy import deepcopy').replace("OUT=ROOT/'output/h5-first55-region-pose-pool-20261029'","OUT=ROOT/'output/h5-first55-boundary-pose-pool-20261029'")
a=s.index("'method':");b=s.index(",'preparation_cap_seconds'",a)
method='For each original convex source region compatible with one of29 site choices, regenerate its exact vertex mean, then add both endpoints of an exact farthest-vertex pair inset by1/1000 toward that mean. Retain all legal source modes and aliases. This independent three-representative construction regenerates every pose and graph directly from the source regions; it does not resume or extend the closed centroid solve. Reconstruct original polygons, check stock, fixed29 and nonempty cog sites, and enumerate all unordered pose conflicts in bounded-memory batches at0.225mm clearance. Compress only actual conflict cliques for at most5seconds, retaining every residual edge. Select7 brackets and6 inserts jointly with13 of15 cog sites; assign original copy identities after selection. Independently audit the complete pool, graph, cover and model before a single60/90-second call. Finite-pool negatives are not global exclusions.'
s=s[:a]+"'method':"+repr(method)+s[b:]
needle="assert Counter(p['family'] for p in pool)=={'bracket':707,'insert':818} and len(pool)==1525"
assert needle in s
expansion='''assert Counter(p['family'] for p in pool)=={'bracket':707,'insert':818} and len(pool)==1525
parents=list(pool)
for parent in parents:
    region=unary[parent['geometry']]['regions'][parent['region']];points=[tuple(map(F,p)) for p in region['hull_vertices']];center=tuple(map(F,parent['exact_lower_left_mm']))
    endpoints=max(combinations(range(len(points)),2),key=lambda pair:sum((points[pair[0]][k]-points[pair[1]][k])**2 for k in [0,1]))
    for vertex in endpoints:
        exact=[(999*points[vertex][k]+center[k])/1000 for k in [0,1]];xy=list(map(float,exact));mode=modes[parent['family']][parent['mode']]
        t={'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'translation':[xy[k]+mode['translation_from_lower_left'][k] for k in [0,1]]};p=polygon(parent['family'],t)
        l,b,r,top=p.bounds;extra=min(l-6.5,b-6.5,1493.5-r,2993.5-top);assert p.is_valid and extra>0.011444091796875;stock_min=min(stock_min,extra)
        df=float(np.min(shapely.distance(p,fixed_polys)));assert df>=0.224999999;fixed_min=min(fixed_min,df)
        eligible=[i for i in range(15) if i not in parent['required_empty_sites']];ds=float(np.min(shapely.distance(p,site_polys[eligible])));assert ds>=0.225;site_min=min(site_min,ds)
        record=deepcopy(parent);record.update({'index':len(pool),'exact_lower_left_mm':[str(v) for v in exact],'lower_left_mm':xy,'transform':t,'parent_centroid':parent['index'],'endpoint_vertex':vertex,'inset_fraction':'1/1000'})
        pool.append(record);polys.append(p)
assert Counter(p['family'] for p in pool)=={'bracket':2121,'insert':2454} and len(pool)==4575'''
s=s.replace(needle,expansion)
a=s.index('n=len(pool);arr=');b=s.index('edge_count=',a)
s=s[:a]+'''n=len(pool);arr=np.asarray(polys,dtype=object);graph=[0]*n;distance_checks=0
for first in range(0,n,128):
    row_ids=range(first,min(n,first+128));ii=np.concatenate([np.full(n-i-1,i,dtype=np.int32) for i in row_ids]);jj=np.concatenate([np.arange(i+1,n,dtype=np.int32) for i in row_ids]);distance=shapely.distance(arr[ii],arr[jj]);bad=distance<0.225;distance_checks+=len(ii)
    for i,j in zip(ii[bad],jj[bad]):i,j=int(i),int(j);graph[i]|=1<<j;graph[j]|=1<<i
    assert time.perf_counter()-started<20,'Complete generation and graph preparation cap reached'
assert distance_checks==n*(n-1)//2
'''+s[b:]
s=s.replace("'bracket_candidates':707,'insert_candidates':818", "'bracket_candidates':2121,'insert_candidates':2454,'centroid_candidates':1525,'boundary_candidates':3050").replace("'all_unordered_pairs_checked':len(ii)","'all_unordered_pairs_checked':distance_checks")
p=ROOT/'output/prepare_h5_boundary_pose_pool_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'finite_representatives_per_source_region':3,'previous_solver_call_unchanged':True})
