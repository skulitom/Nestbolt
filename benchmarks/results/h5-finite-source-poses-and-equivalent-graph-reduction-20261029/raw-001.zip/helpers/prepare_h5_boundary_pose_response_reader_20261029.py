from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_region_pose_response_20261029.py').read_text(encoding='utf-8')
changes=[('h5-first55-region-pose-pool-20261029','h5-first55-boundary-pose-pool-20261029'),('len(model.variables)==1540 and len(model.constraints)==7640','len(model.variables)==4590 and len(model.constraints)==24470'),('cp_model_pb2.INFEASIBLE','cp_model_pb2.UNKNOWN'),("'INFEASIBLE'","'UNKNOWN'"),('status: INFEASIBLE','status: UNKNOWN'),("result['returned_response_branches']==78307", "result['returned_response_branches']==112732"),("result['returned_response_conflicts']==22126", "result['returned_response_conflicts']==23089"),("result['returned_solve_seconds']-result['allocated_solve_seconds'])==0", "result['returned_solve_seconds']-result['allocated_solve_seconds'])>0"),("'max_lp_sym':          0            0      27         0    945           0", "'max_lp_sym':          0            0      41         0    469           0"),("'default_lp':          0            0      67         0  4'040           0", "'default_lp':          0            4     309         0  3'260           0"),("'max_lp_sym_adjust_statistic':27,'max_lp_sym_overflow_statistic':0,'max_lp_sym_bad_statistic':945,'default_lp_adjust_statistic':67,'default_lp_bad_statistic':4040", "'max_lp_sym_adjust_statistic':41,'max_lp_sym_overflow_statistic':0,'max_lp_sym_bad_statistic':469,'default_lp_cut_equal_propagations':4,'default_lp_adjust_statistic':309,'default_lp_bad_statistic':3260"),("'finite_pool_solver_reported_infeasible':True", "'finite_pool_solver_reported_infeasible':False"),("'finite_source_candidates':1525", "'finite_source_candidates':4575")]
for a,b in changes:
    assert a in s,a
    s=s.replace(a,b)
p=ROOT/'output/audit_h5_boundary_pose_response_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'closed_call_overrun_preserved':True})
