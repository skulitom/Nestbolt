from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/prepare_h5_boundary_pose_pool_20261029.py').read_text(encoding='utf-8').replace('from shapely.geometry import Polygon','from shapely.geometry import Polygon\nfrom shapely.strtree import STRtree').replace("OUT=ROOT/'output/h5-first55-boundary-pose-pool-20261029'","OUT=ROOT/'output/h5-first55-indexed-pose-pool-20261029'")
a=s.index('n=len(pool);arr=');b=s.index('edge_count=',a)
s=s[:a]+'''n=len(pool);arr=np.asarray(polys,dtype=object);graph=[0]*n
tree=STRtree(arr);pairs=tree.query(arr,predicate='dwithin',distance=0.225);pairs=pairs[:,pairs[0]<pairs[1]];ii,jj=pairs;distance=shapely.distance(arr[ii],arr[jj]);bad=distance<0.225;distance_checks=len(ii)
for i,j in zip(ii[bad],jj[bad]):i,j=int(i),int(j);graph[i]|=1<<j;graph[j]|=1<<i
assert time.perf_counter()-started<20,'Complete indexed graph preparation cap reached'
'''+s[b:]
s=s.replace('enumerate all unordered pose conflicts in bounded-memory batches at0.225mm clearance','enumerate possible pose conflicts using an STRtree dwithin query at0.225mm, then classify every returned unordered pair by original polygon distance. A separate audit must prove exact candidate and graph byte agreement with the prior complete all-pairs construction')
s=s.replace("'all_unordered_pairs_checked':distance_checks","'spatial_index_unordered_pairs_returned':distance_checks,'all_unordered_pairs_covered_by_index':n*(n-1)//2")
p=ROOT/'output/prepare_h5_indexed_pose_pool_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'same_pose_generation_new_graph_algorithm':True})
