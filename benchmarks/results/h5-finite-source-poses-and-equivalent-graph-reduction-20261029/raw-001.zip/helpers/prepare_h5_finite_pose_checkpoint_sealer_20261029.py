from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'output/seal_h5_local_grid_checkpoint_20261029.py').read_text(encoding='utf-8')
archive=old[old.index('OUT.mkdir();members='):old.index('copies=[')]
archive=archive.replace('for folder in [BASE,SLOTS,SYNC]:','for folder in [CENTROID,BOUNDARY,FAST,BASE,DIAGONAL,SYNC]:')
a=archive.index('helpers=set()');b=archive.index('while queue:')
archive=archive[:a]+'''helpers=set()
for pattern in ['*h5_region_pose*20261029.py','*h5_boundary_pose*20261029.py','*h5_dominance*20261029.py','*h5_indexed_pose*20261029.py','*h5_diagonal*20261029.py','*h5_finite_pose*20261029.py']:
    helpers.update((ROOT/'output').glob(pattern))
helpers.update(ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','ccd1.py','push_h5_local_grid_checkpoint_20261029.py',Path(__file__).name])
for p in sorted(helpers):add('helpers/'+p.name,p)
'''+archive[b:]
header='''"""Seal the finite source pools, exact graph reductions and three closed solver calls."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
CENTROID=ROOT/'output/h5-first55-region-pose-pool-20261029';BOUNDARY=ROOT/'output/h5-first55-boundary-pose-pool-20261029';FAST=ROOT/'output/h5-first55-indexed-pose-pool-20261029';BASE=ROOT/'output/h5-first55-dominance-pose-pool-20261029'
DIAGONAL=ROOT/'output/h5-first55-local-grid-regions-20261029/diagonal-component-bound';SYNC=ROOT/'output/h5-local-grid-main-sync-20261029';PUB=BASE/'publication';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
NAME='h5-finite-source-poses-and-equivalent-graph-reduction-20261029';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\\n') as f:json.dump(v,f,indent=2);f.write('\\n')

def append(p,v):
    with p.open('a',encoding='utf-8',newline='\\n') as f:f.write(v)

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='286223aee0bead996d02a5c1ef4d8b4b403b904b' and not git('diff','HEAD','--name-only')
responses=[]
for folder,status in [(CENTROID,'INFEASIBLE'),(BOUNDARY,'UNKNOWN'),(BASE,'INFEASIBLE')]:
    for n in ['audit','model-audit','response-audit']:assert load(folder/n/'checks.json')['passed'],(folder,n)
    r=load(folder/'response-audit/checks.json');responses.append(r)
    assert r['solver_status']==status and r['closed_solver_calls']==1 and r['assignments']==0 and r['source_checker_calls']==0 and r['overall_algorithm_shared_overruns_seconds']==0
    assert not r['independent_unsatisfiability_certificate'] and not r['global_infeasibility_proven'] and not r['any_allocation_excluded'] and r['native_calls']==0
assert responses[1]['solve_slice_overrun_seconds']>0 and responses[0]['solve_slice_overrun_seconds']==responses[2]['solve_slice_overrun_seconds']==0
assert load(BOUNDARY/'audit/checks.json')['all_candidate_pairs_verified']==10463025
assert load(BASE/'audit/checks.json')['finite_pool_feasibility_equivalent'] and load(BASE/'audit/checks.json')['sequential_replacement_proofs_verified']==2758
assert load(BASE/'maximal-cover/audit/checks.json')['passed'] and load(BASE/'maximal-cover/audit/checks.json')['finite_pool_feasibility_equivalent']
assert load(FAST/'audit/checks.json')['passed'] and load(FAST/'audit/checks.json')['no_source_or_feasibility_change']
diag=load(DIAGONAL/'diagnostic-audit/checks.json');assert diag['passed'] and diag['new_restricted_exclusions']==0 and not diag['all19102_material_bounds_independently_recomputed']
assert digest(SHORT/'search/source-response/candidate-source11.json')=='8b7fa5f6ad765aab6fdba1a586c29d8cac2cce607ed1d7fcd0fb6938c4eeada0'
assert digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
prior=load(ROOT/'benchmarks/results/h5-local-grid-construction-and-component-halfspaces-20261029/publication-review.json')
production=source_digest();readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert production==prior['production_digest'] and readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert load(PUB/'main.json')['commit']['sha']==ci['head_sha']==head and ci['id']==40831504620
assert len(jobs)==6 and sum(j['conclusion']=='success' for j in jobs)==4 and all(j['status']!='completed' or j['conclusion']=='success' for j in jobs)
receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['normal_atomic_fast_forward'] and receipt['prior_main_all6_pass']
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json';assert sum(r['excluded_by'] is None for r in load(frontier))==440
'''
footer='''copies=[]
for prefix,folder in [('centroid',CENTROID),('boundary',BOUNDARY),('dominance',BASE)]:
    copies.extend([(folder/'checks.json',prefix+'-preparation.json'),(folder/'audit/checks.json',prefix+('-source-audit.json' if prefix!='dominance' else '-audit.json')),(folder/'model-audit/checks.json',prefix+'-model-audit.json'),(folder/'model/preparation-charges.json',prefix+'-preparation-charges.json'),(folder/'response-audit/checks.json',prefix+'-response-audit.json'),(folder/'response-audit/lp-diagnostics.txt',prefix+'-lp-diagnostics.txt')])
copies.extend([(BASE/'maximal-cover/checks.json','clique-cover-preparation.json'),(BASE/'maximal-cover/audit/checks.json','clique-cover-audit.json'),(FAST/'checks.json','indexed-preparation.json'),(FAST/'audit/checks.json','indexed-equivalence-audit.json'),(DIAGONAL/'checks.json','diagonal-preparation.json'),(DIAGONAL/'diagnostic-audit/checks.json','diagonal-diagnostic-audit.json'),(BASE/'allowed-empty-site-pairs.json','allowed-empty-site-pairs.json'),(BASE/'next-step.json','next-step.json'),(SYNC/'receipt.json','prior-main-push-receipt.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')])
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40831504620,'main_all6_pass':False,'successful_jobs_at_snapshot':4,'normal_push_requires_all6_and_fresh_head_and_live_run_checks':True,'unchanged_frontier_path':frontier.relative_to(ROOT).as_posix(),'unchanged_frontier_sha256':digest(frontier),'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'closed_new_solver_calls':3,'solver_statuses':[r['solver_status'] for r in responses],'source_assignments':0,'independent_unsatisfiability_certificate':False,'global_infeasibility_proven':False,'all_expanded_source_poses_verified':4575,'all_expanded_source_pairs_verified':10463025,'sequential_dominance_removals_verified':2758,'retained_equivalent_source_poses':1817,'redundant_clique_rows_removed':2735,'finite_pool_feasibility_equivalent':True,'boundary_solve_slice_overrun_seconds':responses[1]['solve_slice_overrun_seconds'],'overall_algorithm_shared_overruns_seconds':0,'diagonal_diagnostic_only':True,'all_diagonal_material_bounds_independently_recomputed':False,'new_restricted_site_exclusions':0,'restricted_site_pairs_remaining':29,'source_valid_short11_preserved':True,'valid64_preserved':True,'first55_constructed':False,'source_valid66_created':False,'new_allocation_exclusions':0,'remaining_candidates':440,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';content=status.read_text(encoding='utf-8');old='Latest H5 evidence: [local-coordinate construction and component halfspace bounds](../benchmarks/results/h5-local-grid-construction-and-component-halfspaces-20261029.md).';new=f'Latest H5 evidence: [finite source poses and equivalent graph reduction](../benchmarks/results/{NAME}.md).';assert content.count(old)==1
with status.open('w',encoding='utf-8',newline='\\n') as f:f.write(content.replace(old,new,1))
append(ROOT/'.gitattributes',f'\\nbenchmarks/results/{NAME}/** -text -whitespace\\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'closed_calls':3,'source_valid66':False,'restricted_site_pairs_remaining':29,'remaining_candidates':440,'completion_percent':60})
'''
s=header+archive+footer;p=ROOT/'output/seal_h5_finite_pose_checkpoint_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
v=(ROOT/'output/verify_h5_local_grid_archive_20261029.py').read_text(encoding='utf-8').replace('h5-local-grid-construction-and-component-halfspaces-20261029','h5-finite-source-poses-and-equivalent-graph-reduction-20261029')
with (ROOT/'output/verify_h5_finite_pose_archive_20261029.py').open('x',encoding='utf-8',newline='\n') as f:f.write(v)
print({'prepared':p.name,'all_three_calls_preserved':True})
