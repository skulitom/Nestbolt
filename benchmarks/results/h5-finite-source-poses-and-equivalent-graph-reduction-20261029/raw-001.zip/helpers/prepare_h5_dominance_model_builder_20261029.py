from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/build_h5_boundary_pose_model_20261029.py').read_text(encoding='utf-8').replace('h5-first55-boundary-pose-pool-20261029','h5-first55-dominance-pose-pool-20261029')
s=s.replace("load=lambda p:json.loads", "FAST=ROOT/'output/h5-first55-indexed-pose-pool-20261029';COVER=BASE/'maximal-cover'\nload=lambda p:json.loads")
s=s.replace("assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir()", "assert load(BASE/'audit/checks.json')['passed'] and load(COVER/'audit/checks.json')['passed'] and load(FAST/'audit/checks.json')['passed'];OUT.mkdir()")
s=s.replace("cliques=load(BASE/'cliques.json')", "cliques=load(COVER/'cliques.json')")
a="'finite_pool_graph_and_cover_seconds':load(BASE/'checks.json')['seconds']"
b="'finite_pool_graph_and_cover_seconds':load(FAST/'checks.json')['seconds'],'exact_dominance_reduction_seconds':load(BASE/'checks.json')['seconds'],'exact_clique_subset_reduction_seconds':load(COVER/'checks.json')['seconds']"
assert a in s;s=s.replace(a,b)
s=s.replace("inputs=[Path(__file__),", "inputs=[Path(__file__),FAST/'plan.json',FAST/'checks.json',FAST/'audit/plan.json',FAST/'audit/checks.json',COVER/'plan.json',COVER/'checks.json',COVER/'cliques.json',COVER/'audit/plan.json',COVER/'audit/checks.json',")
s=s.replace('One Boolean per complete source pose;', 'One Boolean per retained complete source pose after independently proved same-family replacements; the indexed source pool is byte-identical to the audited original all-pairs graph, and projected clique subsets preserve every conflict;')
p=ROOT/'output/build_h5_dominance_pose_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'all_fast_preparation_and_reduction_costs_charged':True})
