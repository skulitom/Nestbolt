from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_boundary_pose_model_20261029.py').read_text(encoding='utf-8').replace('h5-first55-boundary-pose-pool-20261029','h5-first55-dominance-pose-pool-20261029')
for a,b in [('4590','1832'),('24470','12564'),('4575','1817'),('17551','9690'),('6840','2795')]:
    assert a in s,a
    s=s.replace(a,b)
s=s.replace("cliques=load(BASE/'cliques.json')", "cliques=load(BASE/'maximal-cover/cliques.json')")
needle="assert sum(charges.values())==load(MODEL/'checks.json')['preparation_seconds_charged']<56"
assert needle in s
s=s.replace(needle,needle+"\nassert charges['finite_pool_graph_and_cover_seconds']==load(ROOT/'output/h5-first55-indexed-pose-pool-20261029/checks.json')['seconds']\nassert charges['exact_dominance_reduction_seconds']==load(BASE/'checks.json')['seconds']\nassert charges['exact_clique_subset_reduction_seconds']==load(BASE/'maximal-cover/checks.json')['seconds']\nassert load(BASE/'maximal-cover/audit/checks.json')['passed'] and load(ROOT/'output/h5-first55-indexed-pose-pool-20261029/audit/checks.json')['passed']")
p=ROOT/'output/audit_h5_dominance_pose_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for src,dst in [('check_h5_boundary_pose_candidate_20261029.py','check_h5_dominance_pose_candidate_20261029.py'),('run_h5_boundary_pose_model_20261029.py','run_h5_dominance_pose_model_20261029.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-first55-boundary-pose-pool-20261029','h5-first55-dominance-pose-pool-20261029').replace('check_h5_boundary_pose_candidate_20261029.py','check_h5_dominance_pose_candidate_20261029.py');p=ROOT/'output'/dst;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':3,'previous_calls_remain_closed':True,'single_equivalent_reduced_model_call':True})
