from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_local_grid_response_20261029.py').read_text(encoding='utf-8')
changes=[('h5-first55-local-grid-regions-20261029','h5-first55-region-pose-pool-20261029'),('len(model.variables)==8336 and len(model.constraints)==43571','len(model.variables)==1540 and len(model.constraints)==7640'),('cp_model_pb2.UNKNOWN','cp_model_pb2.INFEASIBLE'),("'UNKNOWN'","'INFEASIBLE'"),('status: UNKNOWN','status: INFEASIBLE'),("result['returned_response_branches']==33140", "result['returned_response_branches']==78307"),("result['returned_response_conflicts']==770", "result['returned_response_conflicts']==22126"),("result['returned_solve_seconds']-result['allocated_solve_seconds'])>0", "result['returned_solve_seconds']-result['allocated_solve_seconds'])==0"),("'max_lp':          0            9       0         0  12'829           0", "'max_lp_sym':          0            0      27         0    945           0"),("'default_lp':          0            0       0         0      19           0", "'default_lp':          0            0      67         0  4'040           0"),("'max_lp_cut_equal_propagations':9,'max_lp_overflow_statistic':0,'max_lp_bad_statistic':12829,'default_lp_bad_statistic':19", "'max_lp_sym_adjust_statistic':27,'max_lp_sym_overflow_statistic':0,'max_lp_sym_bad_statistic':945,'default_lp_adjust_statistic':67,'default_lp_bad_statistic':4040"),("'infeasibility_proven':False", "'finite_pool_solver_reported_infeasible':True,'independent_unsatisfiability_certificate':False,'global_infeasibility_proven':False,'finite_source_candidates':1525")]
for a,b in changes:
    assert a in s,a
    s=s.replace(a,b)
p=ROOT/'output/audit_h5_region_pose_response_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'finite_pool_scope_only':True,'no_overruns':True})
