from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_region_pose_response_20261029.py').read_text(encoding='utf-8')
changes=[
('h5-first55-region-pose-pool-20261029','h5-first55-dominance-pose-pool-20261029'),
('len(model.variables)==1540 and len(model.constraints)==7640','len(model.variables)==1832 and len(model.constraints)==12564'),
("result['returned_response_branches']==78307","result['returned_response_branches']==168776"),
("result['returned_response_conflicts']==22126","result['returned_response_conflicts']==34252"),
("'max_lp_sym':          0            0      27         0    945           0","'max_lp':          0            0      14         0  3'970           0"),
("'default_lp':          0            0      67         0  4'040           0","'default_lp':          0            0     162         0  2'189           0"),
("'max_lp_sym_adjust_statistic':27,'max_lp_sym_overflow_statistic':0,'max_lp_sym_bad_statistic':945,'default_lp_adjust_statistic':67,'default_lp_bad_statistic':4040","'max_lp_adjust_statistic':14,'max_lp_overflow_statistic':0,'max_lp_bad_statistic':3970,'default_lp_adjust_statistic':162,'default_lp_bad_statistic':2189"),
("'finite_source_candidates':1525","'finite_source_candidates':1817,'equivalent_unreduced_source_candidates':4575")]
for a,b in changes:
    assert a in s,a
    s=s.replace(a,b)
a="assert load(BASE/'model-audit/checks.json')['passed']"
b=a+"\nassert load(BASE/'audit/checks.json')['passed'] and load(BASE/'audit/checks.json')['finite_pool_feasibility_equivalent']\nassert load(BASE/'maximal-cover/audit/checks.json')['passed']"
assert a in s;s=s.replace(a,b)
p=ROOT/'output/audit_h5_dominance_pose_response_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'only_finite_pool_infeasibility_claimed':True})
