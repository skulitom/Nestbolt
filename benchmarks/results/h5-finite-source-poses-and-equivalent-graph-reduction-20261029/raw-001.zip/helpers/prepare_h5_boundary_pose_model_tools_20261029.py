from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_region_pose_model_20261029.py').read_text(encoding='utf-8').replace('h5-first55-region-pose-pool-20261029','h5-first55-boundary-pose-pool-20261029')
for a,b in [('1540','4590'),('7640','24470'),('1525','4575'),('5281','17551'),('2280','6840')]:
    assert a in s,a
    s=s.replace(a,b)
p=ROOT/'output/audit_h5_boundary_pose_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for src,dst in [('check_h5_region_pose_candidate_20261029.py','check_h5_boundary_pose_candidate_20261029.py'),('run_h5_region_pose_model_20261029.py','run_h5_boundary_pose_model_20261029.py')]:
    s=(ROOT/'output'/src).read_text(encoding='utf-8').replace('h5-first55-region-pose-pool-20261029','h5-first55-boundary-pose-pool-20261029').replace('check_h5_region_pose_candidate_20261029.py','check_h5_boundary_pose_candidate_20261029.py');p=ROOT/'output'/dst;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':3,'previous_centroid_call_remains_closed':True,'maximum_boundary_pool_calls':1})
