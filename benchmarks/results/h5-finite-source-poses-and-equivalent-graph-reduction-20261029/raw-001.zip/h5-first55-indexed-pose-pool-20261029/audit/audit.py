"""Compare the indexed preparation with every byte of the independently checked all-pairs pool."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import gzip,json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-first55-indexed-pose-pool-20261029';PRIOR=ROOT/'output/h5-first55-boundary-pose-pool-20261029';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();assert load(PRIOR/'audit/checks.json')['passed']
for folder in [BASE,PRIOR,PRIOR/'audit']:
    for name,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/name)==h,name
files=['candidates.json','allowed-empty-site-pairs.json','inventory.json','graph.bin.gz','cliques.json','residual-pairs.json']
for n in files:assert (BASE/n).read_bytes()==(PRIOR/n).read_bytes(),n
assert gzip.decompress((BASE/'graph.bin.gz').read_bytes())==gzip.decompress((PRIOR/'graph.bin.gz').read_bytes())
c=load(BASE/'checks.json');assert c['candidates']==4575 and c['conflicts']==1695837 and c['cliques']==17551 and c['preparation_cap_overrun_seconds']==c['cover_cap_overrun_seconds']==0
assert c['all_unordered_pairs_covered_by_index']==10463025 and c['spatial_index_unordered_pairs_returned']==1695837
inputs=[Path(__file__),BASE/'plan.json',BASE/'checks.json',PRIOR/'plan.json',PRIOR/'checks.json',PRIOR/'audit/plan.json',PRIOR/'audit/checks.json']+[folder/n for folder in [BASE,PRIOR] for n in files]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
checks={'passed':True,'seconds':time.perf_counter()-started,'source_pose_bytes_identical':True,'source_poses':4575,'graph_bytes_identical':True,'all10463025_pairs_previously_independently_verified':True,'explicit_index_pairs':1695837,'conflicts':1695837,'complete_clique_cover_bytes_identical':True,'original_preparation_seconds':load(PRIOR/'checks.json')['seconds'],'indexed_preparation_seconds':c['seconds'],'no_source_or_feasibility_change':True,'solver_calls':0,'native_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
