"""Preserve the rejected allocation and prepare read-only checks of captured evidence."""
from pathlib import Path
from hashlib import sha256
import json,shutil
root=Path(__file__).resolve().parents[1];out=root/'output/h5-continuous-repair-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');stages=load(out/'progress.json');assert stages[-1]['label']=='core-tests' and stages[-1]['exit_code']==101
log=(out/'core-tests.log').read_text(encoding='utf-8');assert '142 passed; 3 failed' in log
failed=out/'failed-long-source';failed.mkdir()
for rel in plan['changed_files']:
 p=failed/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(out/'candidate'/rel,p)
for name in ['core-tests.log','progress.json','build-failure.json']:shutil.copyfile(out/name,failed/name)
bins=list((Path(plan['target'])/'release/deps').glob('nestbolt_core-*.exe'));assert len(bins)==1;shutil.copyfile(bins[0],failed/'authored-tests.exe')
record={'candidate_qualification_passed':False,'passed_tests':142,'failed_tests':3,'failures':['larger_return_moves_both_incoming_with_strict_material_guard','mixed_pair_moves_different_parts_and_three_returns','mixed_pair_preserves_a_frozen_sheet'],'source_sha256':{rel:digest(failed/rel) for rel in plan['changed_files']},'log_sha256':digest(failed/'core-tests.log'),'test_binary_sha256':digest(failed/'authored-tests.exe'),'stages':stages,'lint_or_observer_build_started':False,'new_quality_runs':0,'assertions_relaxed':False}
(failed/'checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(__file__,failed/'freeze.py')
for stage in ['source','witness']:
 p=root/f'output/check_h5_continuous_repair_{stage}.py';s=p.read_text(encoding='utf-8')
 s=s.replace("assert load(out/'build.json')['all_checks_passed']", "assert load(out/'failed-long-source/checks.json')['failed_tests']==3")
 s=s.replace("assert load(probe/'build.json')['all_checks_passed']", "assert load(probe/'failed-long-source/checks.json')['failed_tests']==3")
 s=s.replace("'145 passed; 0 failed'", "'142 passed; 3 failed'")
 s=s.replace("'all_checks_passed':True", "'all_checks_passed':True,'candidate_qualification_passed':False")
 path=root/f'output/check_h5_continuous_repair_failed_{stage}.py';compile(s,str(path),'exec');path.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'preserved_failed_candidate':True,'passed':142,'failed':3,'new_quality_runs':0}))
