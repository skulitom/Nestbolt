from pathlib import Path
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-continuous-repair-probe-20261018'
assert json.loads((out/'before-continuous-repair/checks.json').read_bytes())['expected_runtime_failure']
path=out/'candidate/crates/core/src/sheets/vstrip/exchange.rs';s=path.read_text(encoding='utf-8');stub=(out/'stub.txt').read_text(encoding='utf-8')
implementation='''// Internal allocation only; the caller supplies the existing relocation deadline.
pub(super) fn exchange_deadline(_now: f64, budget: f64) -> f64 {
    budget
}

fn repair_deadlines(now: f64, until: f64) -> (f64, f64) {
    let former_pair_end = now + ((until - now) * 0.5).min(0.4);
    // Preserve receiver work; give one continuous source repair the phase remainder.
    ((now + former_pair_end) / 2.0, until)
}

'''
assert s.count(stub)==1;s=s.replace(stub,implementation)
assert s.count('the rest of this phase, including the validation reserve.')==1
s=s.replace('the rest of this phase, including the validation reserve.','the rest of this phase, respecting the validation reserve.')
path.write_text(s,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
shutil.copyfile(__file__,out/'apply.py');print('Applied continuous source repair within the existing relocation allowance; total budget and acceptance guards unchanged.')
