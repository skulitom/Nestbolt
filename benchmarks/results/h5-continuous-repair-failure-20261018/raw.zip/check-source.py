"""Reconstruct the candidate and isolate only the internal deadline allocation delta."""
from pathlib import Path
from hashlib import sha256
import ast,difflib,json,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-continuous-repair-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(out/'preparation.json');assert load(out/'failed-long-source/checks.json')['failed_tests']==3;parent=Path(plan['old_probe'])/'candidate';rel=plan['changed_files'][0]
prior=(parent/rel).read_text(encoding='utf-8');current=(out/'candidate'/rel).read_text(encoding='utf-8')
old_runtime,old_tests=prior.split('#[cfg(test)]\nmod tests {',1);runtime,tests=current.split('#[cfg(test)]\nmod tests {',1)
a=runtime.index('// Internal allocation only;');b=runtime.index('// A successful flat exchange',a);helper=runtime[a:b];restored=runtime[:a]+runtime[b:]
a=old_runtime.index('                    // Bound each pair');b=old_runtime.index('                    let mut receiver_sep',a);old_block=old_runtime[a:b]
a=restored.index('                    // Keep the short receiver');b=restored.index('                    let mut receiver_sep',a);call=restored[a:b];restored=restored[:a]+old_block+restored[b:]
assert 'repair_deadlines(now, self.last_step(exchange_until))' in call
assert restored==old_runtime
assert tests.split('    // BEGIN continuous-repair tests',1)[0].rstrip()==old_tests.rsplit('\n}',1)[0].rstrip()
caller=plan['changed_files'][1];a=(parent/caller).read_text(encoding='utf-8');b=(out/'candidate'/caller).read_text(encoding='utf-8')
assert b.replace('exchange::exchange_deadline(t, budget)','(t + 1.2).min(budget)')==a
red=(out/'before-continuous-repair'/rel).read_text(encoding='utf-8');script=ast.parse((out/'apply.py').read_text(encoding='utf-8'))
implementation=next(ast.literal_eval(n.value) for n in script.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='implementation' for t in n.targets))
stub=(out/'stub.txt').read_text(encoding='utf-8');assert red.count(stub)==1
fresh=root/'output/h5-continuous-repair-reconstruction-20261018';shutil.copytree(out/'candidate',fresh)
reconstructed=red.replace(stub,implementation).replace('the rest of this phase, including the validation reserve.','the rest of this phase, respecting the validation reserve.')
(fresh/rel).write_text(reconstructed,encoding='utf-8',newline='\n');subprocess.run(['cargo','fmt','--all'],cwd=fresh,check=True)
for row in plan['old_source_files']['candidate']:
 name=row['path'];assert digest(parent/name)==row['sha256'];assert (fresh/name).read_bytes()==(out/'candidate'/name).read_bytes()
 if name not in plan['changed_files']:assert digest(out/'candidate'/name)==row['sha256']
record={'all_checks_passed':True,'candidate_qualification_passed':False,'prior_tests_unchanged':141,'new_tests':4,'other_runtime_exact_after_deadline_adapter_reversal':True,'caller_exact_after_deadline_adapter_reversal':True,'all_formatted_reconstructed_files_exact':True,'reconstructed_files':len(plan['old_source_files']['candidate']),'unchanged_other_files':len(plan['old_source_files']['candidate'])-2,'receiver_slice_formula_unchanged':True,'single_continuous_source_repair_until_existing_phase_end':True,'existing_validation_reserve_preserved':True,'unchanged_relocation_fraction':0.1,'old_exchange_cap_seconds':1.2,'new_exchange_cap':'Existing relocation deadline only','old_source_repair_cap':'End of a pair limited to 0.4 seconds and half remaining phase','new_source_repair_cap':'Existing phase deadline less existing validation reserve','paired_single_phase_allocation_unchanged':True,'whole_search_budget_unchanged':True,'acceptance_guards_unchanged':True,'no_new_validation_or_geometry_work':True,'no_new_random_samples':True,'new_searches':0}
for name in ['reconstruction.json','source-checks.json']:(out/name).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
patch=''
for rel in plan['changed_files']:patch+=''.join(difflib.unified_diff((parent/rel).read_text(encoding='utf-8').splitlines(True),(out/'candidate'/rel).read_text(encoding='utf-8').splitlines(True),fromfile='exchange-chain/'+rel,tofile='continuous-repair/'+rel))
(out/'candidate.patch').write_text(patch,encoding='utf-8',newline='\n');shutil.copyfile(__file__,out/'check-source.py');print(json.dumps(record))
