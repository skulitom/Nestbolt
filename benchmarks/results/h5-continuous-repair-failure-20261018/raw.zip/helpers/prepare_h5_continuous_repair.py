"""Prepare longer continuous source repair within the existing relocation allowance."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];old=root/'output/h5-exchange-chain-probe-20261018';out=root/'output/h5-continuous-repair-probe-20261018'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert json.loads((root/'benchmarks/results/h5-exchange-chain-pilot-20261018/interpretation.json').read_bytes())['failed_material_pairs']==4
out.mkdir()
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
rel='crates/core/src/sheets/vstrip/exchange.rs';path=out/'candidate'/rel;s=path.read_text(encoding='utf-8')
stub='''// Internal allocation only; the caller supplies the existing relocation deadline.
pub(super) fn exchange_deadline(now: f64, budget: f64) -> f64 {
    (now + 1.2).min(budget)
}

fn repair_deadlines(now: f64, until: f64) -> (f64, f64) {
    let pair_end = now + ((until - now) * 0.5).min(0.4);
    ((now + pair_end) / 2.0, pair_end)
}

'''
needle='// A successful flat exchange';assert s.count(needle)==1;s=s.replace(needle,stub+needle)
old_block='''                    // Bound each pair so one hard proposal cannot consume all
                    // remaining opportunities. Each repair gets half the pair.
                    let pair_end = now + ((self.last_step(exchange_until) - now) * 0.5).min(0.4);
                    let middle = (now + pair_end) / 2.0;'''
new_block='''                    // Keep the short receiver allowance; source repair may use
                    // the rest of this phase, including the validation reserve.
                    let (middle, pair_end) = repair_deadlines(now, self.last_step(exchange_until));'''
assert s.count(old_block)==1;s=s.replace(old_block,new_block)
caller=out/'candidate/crates/core/src/sheets/vstrip.rs';c=caller.read_text(encoding='utf-8');needle='let exchange_until = (t + 1.2).min(budget);';assert c.count(needle)==1
caller.write_text(c.replace(needle,'let exchange_until = exchange::exchange_deadline(t, budget);'),encoding='utf-8',newline='\n')
tests='''
    // BEGIN continuous-repair tests
    #[test]
    fn continuous_repair_uses_existing_window_and_preserves_receiver_allocation() {
        for (now,budget) in [(0.0,5.4),(2.0,2.1),(10.0,25.0)] {
            assert_eq!(exchange_deadline(now,budget),budget,"Use the existing relocation allowance");
            let (receiver,source)=repair_deadlines(now,budget);
            let former_pair=now+((budget-now)*0.5).min(0.4);
            assert_eq!(receiver,(now+former_pair)/2.0);
            assert_eq!(source,budget);assert!(receiver<=source);
        }
    }

    #[test]
    fn continuous_repair_can_clear_source_after_short_slice_has_elapsed() {
        let (mut job,mut layout)=fixture();job.name="Authored source repair after elapsed short slice".into();
        job.parts=vec![rectangle("tile",17.0,17.0)];job.parts[0].quantity=25;
        layout.sheets.truncate(1);layout.placements.clear();
        for row in 0..5 {for col in 0..5 {
            layout.placements.push(Placement{part_id:"tile".into(),copy_index:row*5+col,sheet_id:"sheet-0".into(),transform:RigidTransform{translation:[2.0+16.0*f64::from(col),2.0+16.0*f64::from(row)],..Default::default()}});
        }}
        assert!(!validate(&job,&layout).unwrap().valid,"This is an overlapping proposed source, not an accepted layout");
        let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&layout).unwrap();
        let clock=Clock::new(Timing::Work,60.0);
        let mut source=Separator::new(JLayout::from_snapshot(&sheets[0].layout().save()),0,EXPLORE,clock.clone());
        assert!(source.tracker.total_loss()>0.0);
        let now=clock.now();let former_source=now+0.4;let full_until=now+3.0;
        let (_,source_until)=repair_deadlines(now,full_until);
        // Explicitly simulate prior receiver work consuming the short slice.
        // This charged delay is a policy fixture, never a timing measurement.
        clock.charge(Work::Evaluation,300_000.0);
        let started=clock.now();assert!(started>former_source && started<full_until);
        let (snapshot,tracker)=source.separate(&crate::clock::Deadline{clock:clock.clone(),at:source_until});
        assert_eq!(tracker.total_loss(),0.0,"Remaining phase must permit actual source repair");
        assert!(clock.now()<full_until,"Repair must finish before the shared phase ends");
        let repaired=JLayout::from_snapshot(&snapshot);
        let after=free_return_public(&model,&model.to_layout(&sheets),&repaired,"sheet-0");
        let report=validate(&job,&after).unwrap();assert!(report.valid,"{:?}",report.violations);
        eprintln!("CONTINUOUS_REPAIR_WITNESS {}",serde_json::json!({"job":job,"before":layout,"after":after,"source_started":started,"former_source_until":former_source,"full_until":full_until,"source_until":source_until,"finished":clock.now(),"simulated_prior_evaluations":300000,"work":clock.counts()}));
    }

    #[test]
    fn continuous_repair_expired_disabled_and_mid_validation_keep_incumbent() {
        let (job,layout)=chain_fixture();let (_,before,_)=chain_exercise(&job,&layout,0,false,10.0,0);
        for (enabled,budget) in [(false,10.0),(true,0.0),(true,1e-12)] {
            let (moved,after,stats)=chain_exercise(&job,&layout,0,enabled,budget,0);
            assert_eq!(moved,0);assert_eq!(stats.directed_exchanges,0);
            assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(&before).unwrap());
        }
    }

    #[test]
    fn continuous_repair_failed_source_still_rolls_back_all_parts() {
        let (mut job,layout)=fixture();job.parts[1]=rectangle("return",5.0,90.0);job.parts[2]=rectangle("incoming",30.0,30.0);
        let (moved,_,stats)=chain_exercise(&job,&layout,0,true,3.0,0);
        assert_eq!(moved,0);assert_eq!(stats.directed_exchanges,0);assert!(stats.directed_exchange_attempts>0);
    }
    // END continuous-repair tests
'''
pos=s.rindex('\n}');s=s[:pos]+'\n'+tests+s[pos:];path.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),'old_source_files':{arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']},'changed_files':[rel,'crates/core/src/sheets/vstrip.rs'],'added_files':{},'production_digest':source_digest(),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),'target':str(root/'output/h5-continuous-repair-target-20261018'),'unchanged_prior_tests':141,'new_tests':4,'normal_mode_unchanged':True,'measured_search_started':False}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n');(out/'stub.txt').write_text(stub,encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py');print(json.dumps({'prepared':True,'prior_tests':141,'new_tests':4,'new_searches':0}))
