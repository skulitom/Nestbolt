"""Compare saved failed and preceding successful authored outcomes without rerunning search."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,shutil,subprocess,math
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-continuous-repair-probe-20261018';parent=root/'output/h5-exchange-chain-probe-20261018';out=probe/'regression-checks'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'failed-long-source/checks.json')['failed_tests']==3;out.mkdir()
def read(folder):
 rows=[]
 for line in (folder/'core-tests.log').read_text(encoding='utf-8').splitlines():
  for marker in ['LARGER_RETURN_WITNESS ','MIXED_WITNESS ']:
   if marker in line:rows.append(json.loads(line.split(marker,1)[1]))
 return {(r['case'],r['seed']):r for r in rows}
old=read(parent);new=read(probe);selections=[('larger_positive',3),('mixed_positive',0),('mixed_frozen',0)]
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
records=[]
for case,seed in selections:
 prior,current=old[(case,seed)],new[(case,seed)];assert prior['job']==current['job'] and prior['before']==current['before'];assert prior['moved']==1 and current['moved']==0
 folder=out/f'{case}-s{seed}';folder.mkdir();write(folder/'job.json',current['job']);write(folder/'authored-before.json',current['before']);metrics={};pairs=0
 parts={p['id']:p for p in current['job']['parts']}
 for arm,row in [('parent',prior),('candidate',current)]:
  write(folder/(arm+'-witness.json'),row);write(folder/(arm+'-layout.json'),row['after']);args=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/(arm+'-layout.json'))]
  r=subprocess.run(args,capture_output=True,timeout=60);(folder/(arm+'-stdout.json')).write_bytes(r.stdout);(folder/(arm+'-stderr.log')).write_bytes(r.stderr);write(folder/(arm+'-command.json'),{'command':args,'exit_code':r.returncode});assert r.returncode==0
  report=json.loads(r.stdout);assert report['valid'];metrics[arm]=report['metrics']
  assert Counter(p['part_id'] for p in row['after']['placements'])==Counter({p['id']:p['quantity'] for p in row['job']['parts']})
  assert len({(p['part_id'],p['copy_index']) for p in row['after']['placements']})==len(row['after']['placements'])
  shapes=[]
  for p in row['after']['placements']:
   t=p['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
   def tr(q):return (m*c*q[0]-s*q[1]+t['translation'][0],m*s*q[0]+c*q[1]+t['translation'][1])
   for g in parts[p['part_id']]['geometry']:
    shape=Polygon([tr(q) for q in g['outer']]);assert shape.is_valid
    for sheet,other in shapes:
     if sheet==p['sheet_id']:
      pairs+=1;assert shape.disjoint(other) and shape.distance(other)+1e-7>=row['job']['clearance']
    shapes.append((p['sheet_id'],shape))
 assert metrics['parent']['material_area']<=metrics['candidate']['material_area']
 records.append({'case':case,'seed':seed,'parent_moved':prior['moved'],'candidate_moved':current['moved'],'parent_stats':prior['stats'],'candidate_stats':current['stats'],'parent_material':metrics['parent']['material_area'],'candidate_material':metrics['candidate']['material_area'],'both_outputs_valid':True,'filled_outer_pairs':pairs,'native_exact_rollback_assertion_passed_before_failed_expectation':True})
checks={'all_saved_output_checks_passed':True,'candidate_qualification_passed':False,'failed_regressions':3,'public_CLI_validations':6,'filled_outer_pairs':sum(r['filled_outer_pairs'] for r in records),'records':records,'parent_log_sha256':digest(parent/'core-tests.log'),'candidate_log_sha256':digest(probe/'core-tests.log'),'CLI_sha256':expected,'new_searches':0,'limits':'These are saved authored outcomes. The candidate preserves valid incumbents but loses required opportunities. Aggregate counters do not identify the exact source-loss trajectory or time spent in each proposal.'}
write(out/'checks.json',checks);shutil.copyfile(__file__,out/'check.py');print(json.dumps({'failed_regressions':3,'saved_CLI_checks':6,'filled_outer_pairs':checks['filled_outer_pairs'],'quality_runs':0,'material':[(r['case'],r['seed'],r['parent_material'],r['candidate_material']) for r in records]}))
