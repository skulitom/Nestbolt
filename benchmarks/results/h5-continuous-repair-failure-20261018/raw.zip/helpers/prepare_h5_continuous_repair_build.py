from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'output/build_h5_exchange_chain.py').read_text(encoding='utf-8').replace('h5-exchange-chain','h5-continuous-repair')
(root/'output/build_h5_continuous_repair.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared full core test, lint and executable build with a fresh target directory.')
