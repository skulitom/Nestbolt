"""Create a dedicated reader, keeping the previous closed-run reader intact."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/audit_h5_feasible_cog_response_20261028.py').read_text(encoding='utf-8')
source=source.replace('h5-feasible-cog-source-20261028','h5-cog-feature-source-20261028')
source=source.replace('from h5_legacy64_source_readback import audit','from h5_legacy64_source_readback import audit\nfrom h5_cog_feature_independent_20261028 import audit_matrix')
source=source.replace("accepted=[load(q) for q in sorted((BASE/'search/accepted').glob('*.json'))];records=[]","accepted=[load(q) for q in sorted((BASE/'search/accepted').glob('*.json'))];records=[];initial_top=accepted[0]['variables'][45]")
source=source.replace('778.717','initial_top')
start=source.index('    r,bb=independent(current);jac=np.asarray')
end=source.index('    A=np.asarray',start)
source=source[:start]+'''    jac=np.asarray(inp['jacobian'])
    matrix=audit_matrix(part,current,radius,inp['residuals_mm'],jac,inp['metadata'],p)
    err=matrix['maximum_gradient_difference'];matrix_error=max(matrix_error,err);entries+=matrix['independent_derivative_entries_checked']
'''+source[end:]
source=source.replace("'checked_jacobian_entries':int(jac.size)","'checked_feature_derivative_entries':matrix['independent_derivative_entries_checked'],'feature_rows':matrix['feature_rows'],'stock_feature_rows':matrix['stock_feature_rows'],'pair_feature_rows':matrix['pair_feature_rows'],'all_required_features_included':matrix['all_required_features_included']")
source=source.replace("assert len(steps)==run['lp_calls']==25 and len(trials)==run['backtracking_trials']==145 and len(steps)<=80","assert len(steps)==run['lp_calls']==80 and len(trials)==run['backtracking_trials']==232 and len(steps)==p['max_iterations']")
source=source.replace("assert run['status']=='MINIMUM_RADIUS' and radius<p['minimum_radius_scale'] and run['geometry_evaluations']<=10000","assert run['status']=='ITERATION_LIMIT' and len(steps)==80 and run['geometry_evaluations']<=10000")
source=source.replace("'independent_jacobian_entries_verified':int(entries)","'independent_feature_derivative_entries_verified':int(entries),'independent_vertex_edge_distance_checks':1344000*len(directions),'all80_feature_windows_complete':True")
source=source.replace("ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'","ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5_cog_feature_independent_20261028.py',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'")
target=ROOT/'output/audit_h5_cog_feature_response_20261028.py'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'created':str(target),'closed_previous_reader_unchanged':True})
