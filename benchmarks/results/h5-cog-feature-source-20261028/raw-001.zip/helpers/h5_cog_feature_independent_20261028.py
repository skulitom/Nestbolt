"""Independent original-index feature values and completeness/derivative reader."""
from itertools import combinations
import math
import numpy as np

def point(part,q,owner,index):
    px,py=part['geometry'][0]['outer'][index];a=math.radians(q[3*owner+2]);c,s=math.cos(a),math.sin(a)
    return ((px-139.723742)*c-(py-139.723742)*s+q[3*owner],(px-139.723742)*s+(py-139.723742)*c+q[3*owner+1])

def feature_value(part,q,f):
    if f['kind']!='pair':
        x,y=point(part,q,f['owner'],f['vertex'])
        return {'left':x-6.513,'right':1493.487-x,'bottom':y-6.513,'stock-top':2993.487-y,'top':q[45]-y}[f['kind']]
    px,py=point(part,q,f['vertex_owner'],f['vertex']);ax,ay=point(part,q,f['edge_owner'],f['edge']);bx,by=point(part,q,f['edge_owner'],(f['edge']+1)%80)
    dx,dy=bx-ax,by-ay;t=max(0,min(1,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy)))
    return math.hypot(px-ax-t*dx,py-ay-t*dy)-.224

def key(f):
    return ('pair',f['vertex_owner'],f['vertex'],f['edge_owner'],f['edge']) if f['kind']=='pair' else (f['kind'],f['owner'],f['vertex'])

def audit_matrix(part,q,scale,residuals,jac,meta,plan,derivatives=True):
    residuals=np.asarray(residuals);jac=np.asarray(jac);features=meta['features'];assert len(features)==len(residuals)==len(jac)
    radius=math.ceil(max(math.hypot(x-139.723742,y-139.723742) for x,y in part['geometry'][0]['outer'])*1e6)/1e6
    displacement=math.ceil((math.sqrt(8)*scale+radius*math.pi/180*.25*scale)*1e6)/1e6
    window=.224+plan['linear_reserve_mm']+2*displacement+.000001
    assert radius==meta['source_radius_upper_mm'] and displacement==meta['point_displacement_upper_mm'] and abs(window-meta['pair_window_mm'])<1e-12
    wanted=set();points=[np.array([point(part,q,i,j) for j in range(80)]) for i in range(15)];minimum_distances=[]
    for owner in range(15):
        for vertex in range(80):
            for kind in ['left','right','bottom','stock-top','top']:
                f={'kind':kind,'owner':owner,'vertex':vertex};limit=displacement+(2*scale if kind=='top' else 0)+plan['linear_reserve_mm']+.000001
                if feature_value(part,q,f)<=limit:wanted.add(key(f))
    stock_count=len(wanted)
    for ia,ib in combinations(range(15),2):
        minimum=math.inf;excluded=math.inf;count=0
        for iv,ie in [(ia,ib),(ib,ia)]:
            a,b=points[iv],points[ie];end=np.roll(b,-1,axis=0);direction=end-b;num=np.sum((a[:,None,:]-b[None,:,:])*direction[None,:,:],axis=2);den=np.sum(direction*direction,axis=1)
            t=np.maximum(0,np.minimum(1,num/den));projection=b[None,:,:]+t[:,:,None]*direction[None,:,:];dist=np.sqrt(np.sum((a[:,None,:]-projection)**2,axis=2))
            minimum=min(minimum,float(dist.min()));outside=dist[dist>window]
            if outside.size:excluded=min(excluded,float(outside.min()))
            for vertex,edge in np.argwhere(dist<=window):wanted.add(('pair',iv,int(vertex),ie,int(edge)));count+=1
        minimum_distances.append({'pair':[ia,ib],'minimum_feature_distance_mm':minimum,'included_features':count,'minimum_excluded_feature_distance_mm':excluded if math.isfinite(excluded) else None})
    assert len(wanted)==len(features) and wanted=={key(f) for f in features}
    assert stock_count==meta['stock_features'] and len(features)-stock_count==meta['pair_features']
    for a,b in zip(minimum_distances,meta['pairs']):
        assert a['pair']==b['pair'] and a['included_features']==b['included_features'] and abs(a['minimum_feature_distance_mm']-b['minimum_feature_distance_mm'])<1e-9
        if a['minimum_excluded_feature_distance_mm'] is not None:assert abs(a['minimum_excluded_feature_distance_mm']-b['minimum_excluded_feature_distance_mm'])<1e-9
    max_value_error=0.;max_gradient_error=0.;checked=0
    for i,f in enumerate(features):
        value=feature_value(part,q,f);max_value_error=max(max_value_error,abs(value-residuals[i]));assert abs(value-residuals[i])<1e-9
        owners=f['pair'] if f['kind']=='pair' else [f['owner']];columns=[3*o+j for o in owners for j in range(3)]
        if f['kind']=='top':columns.append(45)
        assert all(jac[i,j]==0 for j in range(46) if j not in columns)
        if derivatives:
            for j in columns:
                step=.00001 if j<45 and j%3==2 else .0001;left=np.asarray(q).copy();right=left.copy();left[j]-=step;right[j]+=step
                reference=(feature_value(part,right,f)-feature_value(part,left,f))/(2*step);err=abs(reference-jac[i,j]);max_gradient_error=max(max_gradient_error,err);assert err<5e-6,(i,j,err);checked+=1
    return {'feature_rows':len(features),'stock_feature_rows':stock_count,'pair_feature_rows':len(features)-stock_count,'source_pairs_checked':105,'vertex_edge_distances_checked':1344000,'stock_vertex_distances_checked':6000,'independent_derivative_entries_checked':checked,'maximum_feature_value_difference_mm':max_value_error,'maximum_gradient_difference':max_gradient_error,'displacement_upper_mm':displacement,'pair_window_mm':window,'all_required_features_included':True}
