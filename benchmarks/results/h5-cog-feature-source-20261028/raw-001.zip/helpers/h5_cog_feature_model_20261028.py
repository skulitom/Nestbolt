"""Separate moving vertex/edge distances, with a displacement-derived window."""
import math
from itertools import combinations
import numpy as np
from h5_feasible_cog_model_20261028 import FeasibleProblem

class FeatureProblem(FeasibleProblem):
    def vertices(self,q):
        result=[]
        for i in range(15):
            x,y,a=q[3*i:3*i+3];a=math.radians(a);c,s=math.cos(a),math.sin(a)
            local=self.source.local
            result.append(np.column_stack((local[:,0]*c-local[:,1]*s+x,local[:,0]*s+local[:,1]*c+y)))
        return result

    def linearize_features(self,q,radius_scale):
        points=self.vertices(q);rbound=math.ceil(float(np.linalg.norm(self.source.local,axis=1).max())*1e6)/1e6
        displacement=math.ceil((math.hypot(2*radius_scale,2*radius_scale)+rbound*math.radians(.25*radius_scale))*1e6)/1e6
        pair_window=.224+self.plan['linear_reserve_mm']+2*displacement+.000001
        features=[];residuals=[];gradients=[];pair_summaries=[]
        def add(meta,value,gradient):features.append(meta);residuals.append(value);gradients.append(gradient)
        for i,ring in enumerate(points):
            for v,point in enumerate(ring):
                rx,ry=point-np.asarray(q[3*i:3*i+2]);dx=-ry*math.pi/180;dy=rx*math.pi/180
                for kind,value,sign,axis,da in [('left',point[0]-6.513,1,0,dx),('right',1493.487-point[0],-1,0,dx),('bottom',point[1]-6.513,1,1,dy),('stock-top',2993.487-point[1],-1,1,dy),('top',q[45]-point[1],-1,1,dy)]:
                    window=displacement+(2*radius_scale if kind=='top' else 0)+self.plan['linear_reserve_mm']+.000001
                    if value<=window:
                        g=np.zeros(46);g[3*i+axis]=sign;g[3*i+2]=sign*da
                        if kind=='top':g[45]=1
                        add({'kind':kind,'owner':i,'vertex':v,'window_mm':window},float(value),g)
        stock_count=len(features)
        for ia,ib in combinations(range(15),2):
            initial_count=len(features);minimum=float('inf');minimum_excluded=float('inf')
            for reverse in [False,True]:
                iv,ie=(ib,ia) if reverse else (ia,ib);a,b=points[iv],points[ie];edge=np.roll(b,-1,axis=0)-b;diff=a[:,None,:]-b[None,:,:]
                parameters=np.clip(np.sum(diff*edge[None,:,:],axis=2)/np.sum(edge*edge,axis=1)[None,:],0,1)
                closest=b[None,:,:]+parameters[:,:,None]*edge[None,:,:];distances=np.linalg.norm(closest-a[:,None,:],axis=2)
                minimum=min(minimum,float(distances.min()));excluded=distances[distances>pair_window]
                if excluded.size:minimum_excluded=min(minimum_excluded,float(excluded.min()))
                for v,e in np.argwhere(distances<=pair_window):
                    pa,pb=(closest[v,e],a[v]) if reverse else (a[v],closest[v,e]);distance=float(distances[v,e]);assert distance>0
                    normal=(pb-pa)/distance;ra=pa-np.asarray(q[3*ia:3*ia+2]);rb=pb-np.asarray(q[3*ib:3*ib+2]);g=np.zeros(46)
                    g[3*ia:3*ia+3]=[-normal[0],-normal[1],-float(normal@np.array([-ra[1],ra[0]]))*math.pi/180]
                    g[3*ib:3*ib+3]=[normal[0],normal[1],float(normal@np.array([-rb[1],rb[0]]))*math.pi/180]
                    add({'kind':'pair','pair':[ia,ib],'vertex_owner':iv,'vertex':int(v),'edge_owner':ie,'edge':int(e),'edge_parameter':float(parameters[v,e]),'distance_mm':distance},distance-.224,g)
            pair_summaries.append({'pair':[ia,ib],'minimum_feature_distance_mm':minimum,'included_features':len(features)-initial_count,'minimum_excluded_feature_distance_mm':minimum_excluded if math.isfinite(minimum_excluded) else None})
        return np.asarray(residuals),np.asarray(gradients),{'features':features,'stock_features':stock_count,'pair_features':len(features)-stock_count,'source_radius_upper_mm':rbound,'point_displacement_upper_mm':displacement,'pair_window_mm':pair_window,'pairs':pair_summaries}
