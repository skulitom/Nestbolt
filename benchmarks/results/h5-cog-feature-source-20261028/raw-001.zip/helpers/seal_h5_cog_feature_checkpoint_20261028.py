"""Seal separate-contact motion and redirect work to all remaining mixed parts."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-cog-feature-source-20261028';PUB=BASE/'publication';NAME='h5-cog-feature-source-20261028';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='feae47d7e71619592560c5f66f318314504eefd6' and not git('diff','HEAD','--name-only')
pre=load(BASE/'preflight/checks.json');source=load(BASE/'source-audit/checks.json');run=load(BASE/'search/result.json');assert pre['passed'] and source['passed'] and run['closed'] and run['status']=='ITERATION_LIMIT' and source['source_accepted_verified_including_control']==81
prior=load(ROOT/'benchmarks/results/h5-feasible-cog-source-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main=='8713c6e13a1ad2a9ce33a7276722016264105244';jobs=load(PUB/'main-ci-jobs.json')['jobs'];passed=[r['name'] for r in jobs if r['status']=='completed' and r['conclusion']=='success'];live=[r['name'] for r in jobs if r['status']!='completed'];assert len(jobs)==6 and len(passed)==5 and live==['checks (windows-latest)']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-feasible-cog-pending-main-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['h5_cog_feature_model_20261028.py','h5_cog_feature_independent_20261028.py','prepare_h5_cog_features_20261028.py','audit_h5_cog_feature_preflight_20261028.py','run_h5_cog_features_20261028.py','make_h5_cog_feature_response_reader_20261028.py','audit_h5_cog_feature_response_20261028.py','audit_h5_feasible_cog_response_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for a,b in [('preflight/checks.json','preflight-audit.json'),('preflight/saved-unsafe-direction.json','rejected-direction-check.json'),('source-audit/checks.json','source-audit.json'),('source-audit/accepted-summary.json','accepted-source-states.json'),('source-audit/best-source15.json','source15.json'),('search/result.json','search-result.json'),('publication/main-ci-jobs.json','main-ci-snapshot.json')]:shutil.copyfile(BASE/a,OUT/b)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'queued_verified_commits':['a2c0ba463da06f947f6ae8a65dd577a9e437b5f0',head],'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'main_CI':40742366525,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
next_action='The separate-contact sequence is CLOSED ITERATION_LIMIT after80 LPs,232 backtracking trials and233 full source-acceptance evaluations (8.964570s search,12.407827s shared). All81 accepted states pass original source checks; all80 displacement-derived feature windows and57283 active derivative entries are independently audited. The saved old unsafe direction is correctly rejected. Best packet height771.963626616mm improves the new control by0.236004500mm but width grows9.392840842mm to1445.843185057mm. Do not extend/restart this closed call or continue isolated cog-height optimization: it does not place the other51 originals and widens the packet. Preserve the old valid64 and all444 necessary allocation counts. Next investigate a materially different full mixed-part model: conservative disjoint axis-aligned rectangle covers of complete source outer polygons, allowing NoOverlap2D to handle all25 remaining originals together around the independently validated mixed26 core plus short15. Use source41 from output/h5-mixed26-height-20261028/response-audit/source41.json (18frames/3brackets/5inserts first,6brackets/9inserts short); remaining first originals are15cogs,br5/6/9 andins13..19. Reconstruct geometry from originals; source-contained capacity rectangles are NOT outer covers and cannot certify disjointness. Derive and audit an outer cover of the full clearance-expanded polygon before partitioning it; avoid separately padding components or treating same-owner overlapping covers as separate conflicting parts. Choose and record a bounded cover resolution, audit complete coverage and integer rounding, and establish a new56-original geometry/model control (41fixed plus15cogs) with honest10-original omission. The actual target must keep all25 movers mandatory and all66 originals accounted for. This is a new constructive subset/model, not a restart of the closed free25 no-fit-cell search; no global claim follows from a failure. Audit all placement links, rotations, stock domains and necessary capacities before one frozen bounded CP call. A returned full66 must pass independent source/native/material checks before integration/fullH5. Preserve H2 original gate and22 unopened vectors. Three verified evidence checkpoints wait for Windows in main CI40742366525 (five jobs pass) before fresh refs/ancestry/live-run guards and normal atomic push. No production/README change or qualified release.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'search_sequences':1,'search_closed':True,'status':run['status'],'accepted_source_states_verified':81,'source_trials_verified':232,'feature_windows_verified':80,'height_improvement_mm':source['height_reduction_mm'],'width_cost_mm':source['width_increase_mm'],'material_gate_solved':False,'previous_source64_preserved':True,'remaining_necessary_allocations':444,'full66_witness':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=f'''# Separate cog edge contacts — 2026-10-28

The contact correction permits 80 valid moves, but the packet becomes only
**0.236005 mm shorter while growing 9.392841 mm wider**. It does not solve the
mechanical material requirement. This isolated height search is closed; the
next formulation must place the missing mixed parts. H2/H5 remain open at
**60% completed milestone weight**.

The model retains separate distances from original cog vertices to original
edges, instead of differentiating a single minimum-distance function. Original
stock vertices are also kept separate. Every point's motion is bounded by
translation norm plus radius times angle change, rounded upward to a micrometre.
The maximum initial point displacement is 3.439293 mm; the pair-feature window
is 7.102607 mm. This covers every feature that could approach the construction
clearance within the declared step. Linearized constraints still propose moves
only; full original polygons decide acceptance.

The preflight checks 238 initial rows (36 stock / 202 pair), all 1,344,000
vertex-edge distances and 6,000 stock-vertex distances, 1,335 active derivative
entries, objective, bounds and the feasible zero step. The source control
passes all 105 pairs, 60 edges, 15 holes and 3,000 hole vertices. For the saved
unsafe direction from the preceding experiment, the new model predicts a
−0.000350522 mm residual; the original source check confirms it. Maximum feature
prediction error for that check is 4.92e-8 mm.

The sole predeclared sequence stops at **80 iterations**, after 232 backtracking
trials and 233 full source-acceptance evaluations. These counts exclude the
separate feature enumerations used to build each LP. Search takes **8.964570 s**
and shared time **12.407827 s**, within the 60/90-second limits. No restart or
extension occurs. The preserved SciPy warning reports that the one-thread option
is forwarded to HiGHS.

Independent readback checks every one of the **81 accepted states**, including
the initial control, and all **232 trials**. It reconstructs all 80 feature
windows and LPs, performing **107,520,000 vertex-edge distance checks** and
**57,283 active derivative checks**. Maximum derivative discrepancy is 1.15e-8.
Every accepted state retains all original holes. The 152 rejected trials that
meet the looser physical source threshold remain rejected under the frozen,
stricter proposal rules.

| Best final packet | Value |
| --- | ---: |
| Actual height | 771.963626616 mm |
| Actual width | 1,445.843185057 mm |
| Height gain from control | 0.236004500 mm |
| Width cost | 9.392840842 mm |
| Minimum source gap | 0.224014009 mm |
| Minimum extra stock clearance | 0.013020174 mm |
| Angle range | 6.273079°–7.324893° |

Top decreases by 0.237464431 mm, including translation; physical height gain is
only 0.236004500 mm. No optimum or full66 result is claimed. The other 51
originals remain required, and this wider packet is not transplanted into the
previous valid64 layout.

The next investigation uses conservative outer rectangle covers and a different
NoOverlap2D formulation for **all 25 remaining originals together** around the
verified mixed26 core and short15. Covers must contain the complete expanded
source polygon; the previously audited *contained* capacity rectangles cannot
serve as outer covers. Coverage, partitioning, integer rounding, stock domains
and all placement links must pass independent checks. A 56-original control
may validate geometry and constraints, but the actual target must retain all
25 movers and account for all 66 originals. This is a new constructive subset,
not a restart of the closed no-fit-cell call. Full original-source, native and
material validation remain prerequisites for integration and the H5 matrix.

Main remains 8713c6e1. Five jobs pass in
[CI 40742366525](https://github.com/skulitom/Nestbolt/actions/runs/40742366525);
Windows checks are live. Queued verified checkpoints wait for all six jobs and
fresh remote guards before normal push. Production, READMEs and upstream heads
and releases are unchanged. The previous valid64, 444 necessary allocations,
original H2 gate and 22 unopened reserved vectors are preserved. No release
qualifies.

Evidence: [preflight]({NAME}/preflight-audit.json),
[saved unsafe-direction check]({NAME}/rejected-direction-check.json),
[all source/model audits]({NAME}/source-audit.json),
[accepted source states]({NAME}/accepted-source-states.json),
[next step]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The archive preserves {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including every source readback, proposal, trial and input.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 separate cog contacts, 2026-10-28:** [the audited feature model]({link})
correctly rejects the prior unsafe direction and keeps all 81 accepted states
source-valid. The sole sequence is CLOSED at 80 iterations, with 232 trials,
8.964570 s search and 12.407827 s shared time. All 80 displacement-derived
feature windows and 57,283 active derivatives are independently verified.
Height improves 0.236005 mm to 771.963627 mm, but width grows 9.392841 mm to
1445.843185 mm. Do not extend the call or continue isolated height optimization.
Next audit conservative *outer* rectangle covers and a new full25 mixed-part
NoOverlap2D formulation around the verified mixed26/short15; source-contained
capacity rectangles are not outer covers. A 56-original control never replaces
the mandatory full66 target. Source/native/material checks remain required.
Main 8713c6e1 has five passing jobs and Windows live; queued checkpoints wait
for all six and fresh guards before normal push. Production/READMEs, valid64,
444-count frontier, H2 gate and 22 reserved vectors stay unchanged. H2/H5
remain open at 60%; no release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
