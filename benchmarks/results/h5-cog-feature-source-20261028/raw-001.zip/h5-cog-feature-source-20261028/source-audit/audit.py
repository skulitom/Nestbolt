"""Read every source trial and LP proposal independently after the closed run."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
from h5_cog_feature_independent_20261028 import audit_matrix
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-feature-source-20261028';OUT=BASE/'source-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'readbacks').mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
p=load(BASE/'plan.json');run=load(BASE/'search/result.json');assert run['closed'] and run['search_sequences']==1 and not run['random_restarts']
for n,h in load(BASE/'search/plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(x for x in job['parts'] if x['id']=='cog');expected={('cog',i) for i in range(15)};stocks={'sheet-0':[6.5,6.5,1493.5,2993.5]}
def rows(q):
    rr=[]
    for i in range(15):
        x,y,d=q[3*i:3*i+3];a=math.radians(d);c,s=math.cos(a),math.sin(a)
        rr.append({'part_id':'cog','copy_index':i,'sheet_id':'sheet-0','transform':{'rotation_radians':a,'mirrored':False,'translation':[x-139.723742*c+139.723742*s,y-139.723742*s-139.723742*c]}})
    return rr
def independent(q):
    polygons=[]
    for r in rows(q):
        t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation']
        polygons.append(Polygon([(x*c-y*s+tx,x*s+y*c+ty) for x,y in part['geometry'][0]['outer']]))
    residuals=[];bb=[min(a.bounds[0] for a in polygons),min(a.bounds[1] for a in polygons),max(a.bounds[2] for a in polygons),max(a.bounds[3] for a in polygons)]
    for shape in polygons:
        x0,y0,x1,y1=shape.bounds;residuals += [x0-6.513,1493.487-x1,y0-6.513,2993.487-y1,q[45]-y1]
    for a,b in combinations(polygons,2):residuals.append((a.distance(b) if a.disjoint(b) else -math.sqrt(a.intersection(b).area))-.224)
    return np.asarray(residuals),bb
accepted=[load(q) for q in sorted((BASE/'search/accepted').glob('*.json'))];records=[];initial_top=accepted[0]['variables'][45]
for saved in accepted:
    q=np.asarray(saved['variables']);rr=rows(q);checked=audit(job,rr,stocks,p['required_source_gap_mm'],p['native_stock_guard_mm'],expected);assert checked['valid'];residuals,bb=independent(q)
    assert residuals.min()>=p['accepted_reserve_mm']-1e-9 and all(0<=q[i]<=18 for i in range(2,45,3)) and 0<=q[45]<=initial_top
    assert abs(bb[3]-bb[1]-saved['diagnostics']['height_mm'])<1e-9 and abs(bb[2]-bb[0]-saved['diagnostics']['width_mm'])<1e-9
    if records:assert q[45]<records[-1]['top_mm']-p['minimum_top_decrease_mm']
    record={'sequence':saved['sequence'],'iteration':saved['iteration'],'top_mm':float(q[45]),'bounds_mm':bb,'height_mm':bb[3]-bb[1],'width_mm':bb[2]-bb[0],'minimum_residual_mm':float(residuals.min()),'source_valid':True,'angle_degrees':q[2:45:3].tolist(),**{k:checked[k] for k in ['minimum_pair_gap_mm','minimum_extra_stock_mm','same_sheet_pairs','stock_edges','cutouts','hole_vertices']}}
    records.append(record);write(OUT/'readbacks'/f"accepted-{saved['sequence']:03d}.json",checked)
assert len(records)==run['accepted_including_control']
best=min(records,key=lambda x:x['height_mm']);saved_best=load(BASE/'search/best.json');assert best['sequence']==run['best_sequence']==saved_best['sequence']
best_rows=rows(saved_best['variables']);published=load(BASE/'search/best-source15.json')
for a,b in zip(best_rows,published):
    assert a['copy_index']==b['copy_index'] and abs(a['transform']['rotation_radians']-b['transform']['rotation_radians'])<1e-15
    assert max(abs(x-y) for x,y in zip(a['transform']['translation'],b['transform']['translation']))<1e-9
write(OUT/'best-source15.json',best_rows);write(OUT/'accepted-summary.json',records)
trials=load(BASE/'search/trials.json');steps=load(BASE/'search/iterations.json');trial_records=[];physical_valid_rejected=0;current=np.asarray(accepted[0]['variables']);radius=1.;directions=[];matrix_error=0.;entries=0
for step in steps:
    i=step['iteration'];inp=load(BASE/'search/directions'/f'{i:03d}-input.json');response=load(BASE/'search/directions'/f'{i:03d}-response.json')
    assert inp['variables']==current.tolist() and inp['radius_scale']==radius and response['success'] and response['status']==0
    jac=np.asarray(inp['jacobian'])
    matrix=audit_matrix(part,current,radius,inp['residuals_mm'],jac,inp['metadata'],p)
    err=matrix['maximum_gradient_difference'];matrix_error=max(matrix_error,err);entries+=matrix['independent_derivative_entries_checked']
    A=np.asarray(inp['A_ub']);b=np.asarray(inp['b_ub']);delta=np.asarray(response['direction'])
    assert np.array_equal(A,-jac) and np.array_equal(b,np.asarray(inp['residuals_mm'])-p['linear_reserve_mm']) and inp['objective']==[0.]*45+[1.]
    bounds=[]
    for j,v in enumerate(current):
        upper=[1500,3000,18][j%3] if j<45 else initial_top;trust=([2,2,.25][j%3] if j<45 else 2)*radius;bounds.append([max(-v,-trust),min(upper-v,trust)])
    assert inp['bounds']==bounds and (A@delta-b).max()<=1e-7 and all(lo-1e-7<=v<=hi+1e-7 for v,(lo,hi) in zip(delta,bounds))
    assert abs(response['objective']-delta[45])<1e-9
    here=[t for t in trials if t['iteration']==i];assert len(here)==step['trials']<=p['max_backtracking_trials_per_direction']
    accepted_trial=None
    for k,t in enumerate(here):
        alpha=2.**(-k);v=np.asarray(t['variables']);assert alpha==t['alpha'] and np.max(np.abs(v-(current+alpha*delta)))<1e-10
        rr=rows(v);check=audit(job,rr,stocks,p['required_source_gap_mm'],p['native_stock_guard_mm'],expected);res,ext=independent(v)
        bound_ok=all(-1e-9<=value<=( [1500,3000,18][j%3] if j<45 else initial_top)+1e-9 for j,value in enumerate(v))
        expected_accept=bool(bound_ok and check['valid'] and res.min()>=p['accepted_reserve_mm'] and v[45]<current[45]-p['minimum_top_decrease_mm'])
        assert expected_accept==t['accepted'],(i,k,res.min(),t['accepted'])
        assert abs(float(res.min())-t['minimum_residual_mm'])<1e-9 and abs(ext[3]-ext[1]-t['diagnostics']['height_mm'])<1e-9
        if check['valid'] and not t['accepted']:physical_valid_rejected+=1
        number=len(trial_records);write(OUT/'readbacks'/f'trial-{number:03d}.json',check)
        trial_records.append({'iteration':i,'backtracking_index':k,'accepted':t['accepted'],'actual_source_valid':check['valid'],'pair_failures':check['pair_failures'],'stock_failures':check['stock_failures'],'minimum_proposal_residual_mm':float(res.min())})
        if t['accepted']:assert k==len(here)-1;accepted_trial=t
    assert bool(accepted_trial)==step['accepted']
    if accepted_trial:
        current=np.asarray(accepted_trial['variables']);same=next(x for x in accepted if x['iteration']==i);assert same['variables']==current.tolist();alpha=accepted_trial['alpha']
        radius=min(1.,radius*1.5) if alpha==1 else radius*.5 if alpha<.25 else radius
    else:radius*=.5
    directions.append({'iteration':i,'checked_feature_derivative_entries':matrix['independent_derivative_entries_checked'],'feature_rows':matrix['feature_rows'],'stock_feature_rows':matrix['stock_feature_rows'],'pair_feature_rows':matrix['pair_feature_rows'],'all_required_features_included':matrix['all_required_features_included'],'maximum_jacobian_difference':err,'linear_proposal_valid':True,'trials':len(here),'accepted':step['accepted']})
assert len(steps)==run['lp_calls']==80 and len(trials)==run['backtracking_trials']==232 and len(steps)==p['max_iterations']
assert run['status']=='ITERATION_LIMIT' and len(steps)==80 and run['geometry_evaluations']<=10000
process=load(BASE/'search/process.json');assert process['exit_code']==0 and not process['timeout'] and process['seconds']<90 and run['search_seconds']<60
write(OUT/'trial-summary.json',trial_records);write(OUT/'direction-audit.json',directions)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'closed_status':run['status'],'source_accepted_verified_including_control':len(records),'source_trial_readbacks':len(trial_records),'lp_directions_verified':len(directions),'independent_feature_derivative_entries_verified':int(entries),'independent_vertex_edge_distance_checks':1344000*len(directions),'all80_feature_windows_complete':True,'maximum_jacobian_difference':matrix_error,'source_pairs_per_readback':105,'stock_edges_per_readback':60,'holes_per_readback':15,'hole_vertices_per_readback':3000,'best_sequence':best['sequence'],'best_height_mm':best['height_mm'],'best_width_mm':best['width_mm'],'height_reduction_mm':records[0]['height_mm']-best['height_mm'],'width_increase_mm':best['width_mm']-records[0]['width_mm'],'top_reduction_at_best_mm':records[0]['top_mm']-best['top_mm'],'last_height_mm':records[-1]['height_mm'],'last_top_mm':records[-1]['top_mm'],'physical_valid_rejected_by_stricter_proposal_rules':physical_valid_rejected,'minimum_extra_stock_mm':best['minimum_extra_stock_mm'],'minimum_pair_gap_mm':best['minimum_pair_gap_mm'],'angle_range_degrees':[min(best['angle_degrees']),max(best['angle_degrees'])],'final_radius_scale':radius,'other_originals_required':51,'global_optimum_claimed':False,'full66_witness':False,'native_calls':0,'H5_complete':False})
inputs=[x for x in (BASE/'search').rglob('*') if x.is_file()]+[BASE/'plan.json',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5_cog_feature_independent_20261028.py',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json']
write(OUT/'plan.json',{'inputs':{x.relative_to(ROOT).as_posix():digest(x) for x in inputs}})
print(load(OUT/'checks.json'))
