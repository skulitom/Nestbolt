"""Freeze a separate-contact model from the best verified feasible packet."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,math,shutil
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-feasible-cog-source-20261028';OUT=ROOT/'output/h5-cog-feature-source-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');old=load(OLD/'plan.json');assert load(OLD/'source-audit/checks.json')['passed'] and load(OLD/'search/result.json')['closed']
q=load(OLD/'search/best.json')['variables'];z=[value/(180/math.pi if i<45 and i%3==2 else 1000) for i,value in enumerate(q)]
write(OUT/'initial.json',z);shutil.copyfile(OLD/'part.json',OUT/'part.json');shutil.copyfile(OLD/'source-audit/best-source15.json',OUT/'control-source15.json')
inputs=[OLD/'plan.json',OLD/'part.json',OLD/'search/best.json',OLD/'source-audit/best-source15.json',OLD/'source-audit/checks.json',OLD/'contact-diagnosis-corrected/checks.json',ROOT/'output/h5_cog_feature_model_20261028.py',ROOT/'output/h5_feasible_cog_model_20261028.py',ROOT/'output/h5_continuous_cog_source_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
plan={k:v for k,v in old.items() if k not in ['inputs','algorithm','derivative_steps','utc']}
plan.update({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'algorithm':'one separate vertex-edge contact LP sequence; analytic feature gradients and exact source acceptance','feature_count_is_dynamic':True,'constraint_count':'dynamic individual stock-vertex and vertex-edge constraints; exact acceptance still180 source constraints','source_radius_bound':'ceil(max original radius * 1e6) / 1e6 mm','point_displacement_bound':'ceil((hypot(dx,dy)+radius_upper*abs(angle_delta_radians))*1e6)/1e6 mm','pair_feature_window':'construction gap + linear reserve + twice point displacement bound + 0.000001 mm','stock_vertex_window':'point displacement + top displacement when applicable + linear reserve + 0.000001 mm','window_basis':'each vertex moves at most translation norm plus radius times rotation angle; segment points inherit the endpoint bound; point-to-segment distance changes by at most the sum of owner displacement bounds','finite_features_are_proposals_only':True,'maximum_search_sequences':1})
write(OUT/'plan.json',plan);print({'prepared':str(OUT),'source_control_sequence':12,'search_started':False})
