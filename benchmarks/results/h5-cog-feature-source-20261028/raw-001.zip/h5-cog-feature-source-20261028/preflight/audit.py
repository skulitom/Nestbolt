"""Audit every separate contact and demonstrate rejection of the old unsafe move."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
import numpy as np
from h5_cog_feature_model_20261028 import FeatureProblem
from h5_cog_feature_independent_20261028 import audit_matrix,feature_value
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-cog-feature-source-20261028';OLD=ROOT/'output/h5-feasible-cog-source-20261028';OUT=BASE/'preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();model=FeatureProblem(BASE);p=model.plan
for n,h in p['inputs'].items():assert digest(ROOT/n)==h,n
jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';job=load(jobpath);part=next(x for x in job['parts'] if x['id']=='cog');assert part==load(BASE/'part.json')
control=load(BASE/'control-source15.json');checked=audit(job,control,{'sheet-0':[6.5,6.5,1493.5,2993.5]},p['required_source_gap_mm'],p['native_stock_guard_mm'],{('cog',i) for i in range(15)});assert checked['valid'];write(OUT/'source-control.json',checked)
q=model.initial;r,jac,meta=model.linearize_features(q,1);read=audit_matrix(part,q,1,r,jac,meta,p)
assert r.min()>=p['linear_reserve_mm'];exact,diag=model.evaluate(q);assert exact.min()>=p['accepted_reserve_mm'] and diag['physical_source_outer_valid']
c,A,b,bounds=model.proposal(q,r,jac,1);assert np.array_equal(A,-jac) and np.array_equal(b,r-p['linear_reserve_mm']) and c.tolist()==[0.]*45+[1.] and all(lo<=0<=hi for lo,hi in bounds)
write(OUT/'initial-model.json',{'variables':q.tolist(),'residuals_mm':r.tolist(),'jacobian':jac.tolist(),'metadata':meta,'objective':c.tolist(),'A_ub':A.tolist(),'b_ub':b.tolist(),'bounds':bounds})
oldq=np.asarray(load(OLD/'search/directions/000-input.json')['variables']);delta=np.asarray(load(OLD/'search/directions/000-response.json')['direction']);alpha=1/2048
oldr,oldj,oldmeta=model.linearize_features(oldq,1);oldread=audit_matrix(part,oldq,1,oldr,oldj,oldmeta,p)
prediction=oldr+alpha*(oldj@delta);candidate=oldq+alpha*delta;actual,_=model.evaluate(candidate)
feature_actual=np.asarray([feature_value(part,candidate,f) for f in oldmeta['features']]);error=float(np.max(np.abs(prediction-feature_actual)))
assert prediction.min()<0 and actual.min()<0 and error<1e-6
write(OUT/'saved-unsafe-direction.json',{'fraction':alpha,'predicted_minimum_feature_residual_mm':float(prediction.min()),'actual_minimum_source_residual_mm':float(actual.min()),'maximum_feature_prediction_error_mm':error,'separate_feature_constraints_reject_saved_unsafe_move':True,'old_control_matrix_audit':oldread})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,**read,'complete_source_control':True,'source_holes':checked['cutouts'],'source_hole_vertices':checked['hole_vertices'],'source_pairs':105,'stock_edges':60,'objective_bounds_and_zero_step_checked':True,'saved_unsafe_direction_rejected':True,'saved_direction_minimum_predicted_residual_mm':float(prediction.min()),'saved_direction_minimum_actual_residual_mm':float(actual.min()),'saved_direction_maximum_feature_prediction_error_mm':error,'new_solver_calls':0,'linear_models_are_not_geometry_certificates':True})
inputs=[BASE/'plan.json',BASE/'initial.json',BASE/'part.json',BASE/'control-source15.json',jobpath,OLD/'search/directions/000-input.json',OLD/'search/directions/000-response.json',ROOT/'output/h5_cog_feature_model_20261028.py',ROOT/'output/h5_cog_feature_independent_20261028.py',ROOT/'output/h5_legacy64_source_readback.py'];write(OUT/'plan.json',{'inputs':{x.relative_to(ROOT).as_posix():digest(x) for x in inputs}})
print(load(OUT/'checks.json'))
