"""Pure original-vertex geometry for independent cog centers and angles."""
import json
import math
from itertools import combinations
import numpy as np
import shapely


class SourceProblem:
    def __init__(self, base):
        self.base = base
        self.plan = json.loads((base / 'plan.json').read_bytes())
        self.part = json.loads((base / 'part.json').read_bytes())
        self.source = np.asarray(self.part['geometry'][0]['outer'], dtype=float)
        self.center = np.asarray(self.plan['source_center_mm'])
        self.local = self.source - self.center
        self.pairs = np.asarray(list(combinations(range(15), 2)))
        self.initial = np.asarray(json.loads((base / 'initial.json').read_bytes()))

    def geometry(self, z):
        q = np.asarray(z[:45]).reshape(15, 3)
        c, s = np.cos(q[:, 2]), np.sin(q[:, 2])
        points = np.empty((15, len(self.source), 2))
        points[:, :, 0] = (c[:, None] * self.local[:, 0] - s[:, None] * self.local[:, 1] + q[:, 0, None] * 1000)
        points[:, :, 1] = (s[:, None] * self.local[:, 0] + c[:, None] * self.local[:, 1] + q[:, 1, None] * 1000)
        polygons = shapely.polygons(points)
        bounds = np.column_stack((points[:, :, 0].min(axis=1), points[:, :, 1].min(axis=1), points[:, :, 0].max(axis=1), points[:, :, 1].max(axis=1)))
        left, right = polygons[self.pairs[:, 0]], polygons[self.pairs[:, 1]]
        distances = shapely.distance(left, right)
        disjoint = shapely.disjoint(left, right)
        signed = distances.copy()
        overlap = ~disjoint
        if overlap.any():
            signed[overlap] = -np.sqrt(shapely.area(shapely.intersection(left[overlap], right[overlap])))
        # Every residual is in metres; positions and top are metres, angles radians.
        stock = np.column_stack((bounds[:, 0] - 6.513, 1493.487 - bounds[:, 2], bounds[:, 1] - 6.513, 2993.487 - bounds[:, 3], z[45] * 1000 - bounds[:, 3]))
        residuals = np.concatenate((stock.reshape(-1), signed - .224)) / 1000
        extent = [float(bounds[:, 0].min()), float(bounds[:, 1].min()), float(bounds[:, 2].max()), float(bounds[:, 3].max())]
        actual_extra = np.column_stack((bounds[:, 0] - 6.5, 1493.5 - bounds[:, 2], bounds[:, 1] - 6.5, 2993.5 - bounds[:, 3])).min()
        physical_valid = bool(disjoint.all() and distances.min() > self.plan['required_source_gap_mm'] and actual_extra > self.plan['native_stock_guard_mm'])
        diagnostics = {'bounds_mm': extent, 'height_mm': extent[3] - extent[1], 'width_mm': extent[2] - extent[0], 'minimum_pair_gap_mm': float(distances.min()), 'minimum_extra_stock_mm': float(actual_extra), 'minimum_residual_m': float(residuals.min()), 'physical_source_outer_valid': physical_valid}
        return residuals, diagnostics

    def rows(self, z):
        rows = []
        for i, (x, y, angle) in enumerate(np.asarray(z[:45]).reshape(15, 3)):
            c, s = math.cos(angle), math.sin(angle)
            rows.append({'part_id': 'cog', 'copy_index': i, 'sheet_id': 'sheet-0', 'transform': {'rotation_radians': float(angle), 'mirrored': False, 'translation': [float(x * 1000 - c * self.center[0] + s * self.center[1]), float(y * 1000 - s * self.center[0] - c * self.center[1])]}})
        return rows
