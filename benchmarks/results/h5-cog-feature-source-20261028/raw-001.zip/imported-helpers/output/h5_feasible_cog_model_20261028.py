"""Mixed-unit finite-difference proposal model; source checks decide acceptance."""
import math
import numpy as np
from h5_continuous_cog_source_20261028 import SourceProblem

SCALE = np.array([1000., 1000., 180/math.pi]*15 + [1000.])

class FeasibleProblem:
    def __init__(self, base):
        self.source = SourceProblem(base)
        self.plan = self.source.plan
        self.initial = self.source.initial*SCALE
        self.bounds = [(0.,1500.),(0.,3000.),(0.,18.)]*15+[(0.,float(self.initial[45]))]
        self.steps = np.array([1e-4,1e-4,1e-5]*15+[1e-4])
        self.radius = np.array([2.,2.,.25]*15+[2.])

    def evaluate(self,q):
        residuals,diag=self.source.geometry(np.asarray(q)/SCALE)
        return residuals*1000,diag

    def linearize(self,q,evaluate):
        residuals,_=evaluate(q)
        jac=np.zeros((180,46)); used=[]
        for i,step in enumerate(self.steps):
            lo,hi=self.bounds[i]; a=max(lo,q[i]-step); b=min(hi,q[i]+step)
            assert b>a
            left=np.asarray(q).copy(); right=left.copy(); left[i]=a; right[i]=b
            ra,_=evaluate(left); rb,_=evaluate(right)
            jac[:,i]=(rb-ra)/(b-a); used.append([float(a),float(b)])
        return residuals,jac,used

    def proposal(self,q,residuals,jac,radius_scale):
        trust=self.radius*radius_scale
        bounds=[(max(lo-v,-r),min(hi-v,r)) for v,(lo,hi),r in zip(q,self.bounds,trust)]
        objective=np.zeros(46); objective[45]=1
        # This is only a local proposal. No linear residual certifies source geometry.
        rhs=residuals-self.plan['linear_reserve_mm']
        return objective,-jac,rhs,bounds
