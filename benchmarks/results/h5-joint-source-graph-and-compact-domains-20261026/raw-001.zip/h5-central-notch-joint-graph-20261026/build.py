"""Complete guarded original-shape adjacency for the new joint pool."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
from shapely.strtree import STRtree
ROOT=Path(__file__).resolve().parents[1];POOL=ROOT/'output/h5-central-notch-joint-pool-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-central-notch-joint-graph-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
inputs=[POOL/n for n in ['plan.json','candidates.json','result.json','pending.json']]+[JOB]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_seconds':300,'method':'Construct a fresh complete original-shape conflict graph for every saved candidate. Each STRtree dwithin query uses the full guarded original pair gap, keeping every returned conflict and excluding only self. Store n consecutive ceil(n/8)-byte little-endian rows in gzip, with no graph pruning. A separate direct-vertex audit will independently evaluate every unordered pair using conservative integer bounding-box rejection and source polygon distances, verify symmetry and every stored row, and recheck all provenance, fixed original clearances and stock edges. Finite pool only; all27 originals remain mandatory. No solver is opened.'})
pool=load(POOL/'candidates.json');job=load(JOB);families={p['id']:p for p in job['parts']};gs=[]
for r in pool:
    p=r['placement'];t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1
    gs.append(affine_transform(Polygon(families[p['part_id']]['geometry'][0]['outer']),[mi*co,-si,mi*si,co,*t['translation']]))
gs=np.asarray(gs,dtype=object);tree=STRtree(gs);required=load(POOL/'plan.json')['required_pair_gap_mm'];n=len(pool);width=(n+7)//8;directed=0
with gzip.open(OUT/'adjacency.bin.gz','wb') as f:
    for i,g in enumerate(gs):
        js=tree.query(g,predicate='dwithin',distance=required);js=js[js!=i];mask=np.zeros(n,dtype=np.uint8);mask[js]=1;data=np.packbits(mask,bitorder='little').tobytes();assert len(data)==width;f.write(data);directed+=len(js)
        assert time.perf_counter()-start<300,'Declared graph limit reached; no completed graph claim'
        if (i+1)%2000==0:print({'rows':i+1,'directed_conflicts':directed,'seconds':time.perf_counter()-start},flush=True)
assert directed%2==0
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'candidates':n,'conflicts':directed//2,'row_bytes':width,'graph_sha256':digest(OUT/'adjacency.bin.gz'),'every_candidate_retained':True,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
