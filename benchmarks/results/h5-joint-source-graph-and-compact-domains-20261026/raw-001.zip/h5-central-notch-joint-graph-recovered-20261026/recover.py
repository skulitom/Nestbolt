"""Preserve completed graph rows and finish missing rows with circle/box pruning."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-central-notch-joint-graph-20261026';POOL=ROOT/'output/h5-central-notch-joint-pool-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=ROOT/'output/h5-central-notch-joint-graph-recovered-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not(OLD/'result.json').exists();pool=load(POOL/'candidates.json');n=len(pool);width=(n+7)//8
with gzip.open(OLD/'adjacency.bin.gz','rb') as f:prior=f.read()
assert len(prior)%width==0;done=len(prior)//width;assert 0<done<n
write(OLD/'failure-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'exit_code':1,'declared_seconds_limit':300,'failed_assertion':'Declared graph limit reached; no completed graph claim','completed_rows_preserved':done,'result_json_emitted':False,'solver_calls':0,'repair':'Keep every completed row byte-for-byte. In a separate recovered folder finish only missing rows using proposed contained-disk overlap and conservative integer outer-box separation before original polygon distance. An independent direct-vertex audit must prove every disk and box and verify all199990000 unordered pairs plus full symmetry; no incomplete result is promoted.'})
OUT.mkdir();shutil.copyfile(__file__,OUT/'recover.py');start=time.perf_counter();inputs=[OLD/n for n in ['plan.json','build.py','adjacency.bin.gz','failure-review.json']]+[POOL/n for n in ['plan.json','candidates.json','result.json']]+[JOB]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'remaining_rows_seconds_limit':300,'method':'Recover only missing rows after the original300-second graph builder failed. Preserve its completed row bytes exactly. For each remaining original source polygon, use conservative integer outer boxes for safe separation and small proposed inner disks for certain overlaps, evaluating every unresolved original polygon distance. These pruning conditions are provisional until the separate independent audit proves every finite-edge disk certificate, exact outward box and all pair classifications. No old candidate limit or solver is extended or repeated; source pool remains byte-identical.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};gs=[];centers=[];radii=[];circle={'cog':(139.723742,139.723742,109100),'bracket':(50.,50.,49990),'insert':(90.,55.,54990)}
for r in pool:
    p=r['placement'];t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];gs.append(affine_transform(Polygon(parts[p['part_id']]['geometry'][0]['outer']),[mi*co,-si,mi*si,co,tx,ty]));x,y,rr=circle[p['part_id']];centers.append([round((mi*co*x-si*y+tx)*1000),round((mi*si*x+co*y+ty)*1000)]);radii.append(rr)
gs=np.asarray(gs,dtype=object);bb=shapely.bounds(gs);ib=np.column_stack([np.floor(bb[:,:2]*1000),np.ceil(bb[:,2:]*1000)]).astype(np.int64);centers=np.asarray(centers,dtype=np.int64);radii=np.asarray(radii,dtype=np.int64);required=load(POOL/'plan.json')['required_pair_gap_mm'];threshold=math.ceil(required*1000)
# One additional micrometre on every box edge protects floating multiply rounding.
ib[:,:2]-=1;ib[:,2:]+=1;directed=sum(int.from_bytes(prior[i*width:(i+1)*width],'little').bit_count() for i in range(done));near=far=exact=0
with gzip.open(OUT/'adjacency.bin.gz','wb') as f:
    f.write(prior)
    for i in range(done,n):
        safe=(ib[:,0]-ib[i,2]>threshold)|(ib[i,0]-ib[:,2]>threshold)|(ib[:,1]-ib[i,3]>threshold)|(ib[i,1]-ib[:,3]>threshold);delta=centers-centers[i];overlap=np.sum(delta*delta,axis=1)<(radii+radii[i])**2;assert not bool(np.any(safe&overlap));js=np.flatnonzero(~(safe|overlap));mask=overlap.astype(np.uint8);mask[js]=(shapely.distance(gs[i],gs[js])<=required).astype(np.uint8);mask[i]=0;f.write(np.packbits(mask,bitorder='little').tobytes());directed+=int(mask.sum());near+=int(overlap.sum())-1;far+=int(safe.sum());exact+=len(js)
        assert time.perf_counter()-start<300,'Recovery limit reached; no result'
        if (i+1)%2000==0:print({'rows':i+1,'original_distances':exact,'seconds':time.perf_counter()-start},flush=True)
assert directed%2==0
with gzip.open(OUT/'adjacency.bin.gz','rb') as f:assert f.read(len(prior))==prior
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'candidates':n,'conflicts':directed//2,'row_bytes':width,'graph_sha256':digest(OUT/'adjacency.bin.gz'),'original_completed_rows_preserved':done,'new_rows':n-done,'prior_row_bytes_preserved':True,'new_row_provisional_circle_conflicts':near,'new_row_provisional_box_separations':far,'new_row_original_polygon_distances':exact,'every_candidate_retained':True,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'),flush=True)
