"""Direct source readback and all-pair verification, independent of spatial-tree construction."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from collections import Counter
import gzip,json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-central-notch-joint-graph-recovered-20261026';POOL=ROOT/'output/h5-central-notch-joint-pool-20261026';INV=ROOT/'output/h5-central-notch-mixed-core-20261026/audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def identity(p):
    t=p['transform'];return(p['part_id'],p.get('sheet_id','sheet-0'),t['mirrored'],float(t['rotation_radians']).hex(),*(float(x).hex() for x in t['translation']))
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
inputs=[p for folder in [BASE,POOL] for p in folder.rglob('*') if p.is_file() and OUT not in p.parents]+[INV/'next-neighborhood.json',INV/'checks.json',JOB]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_seconds':300,'method':'Directly transform all original vertices, verify provenance and permissions, every fixed-owner gap and stock edge. Reconstruct all unordered pair classifications without a spatial tree. Floor minimum and ceil maximum original floating vertex coordinates on a1-micrometre grid using exact integer ratios; this gives certified outer boxes. Exact integer winding and distance to every finite edge certify a contained disk for each original polygon. Strict overlap of these integer-center disks proves a conflict. A separated outer box proves safety. Evaluate every unresolved original polygon distance. Compare every saved upper adjacency bit and independently check the entire saved graph is symmetric with zero diagonal. Retain every original identity and complete27 requirement. Lattice and boundary proposals are finite candidates, not continuous or all-angle coverage.'})
for folder in [BASE,POOL]:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
job=load(JOB);parts={p['id']:p for p in job['parts']};spec=load(INV/'next-neighborhood.json');pool=load(POOL/'candidates.json');plan=load(POOL/'plan.json');n=len(pool);guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05)
assert required==plan['required_pair_gap_mm'] and guard==plan['required_stock_extra_mm'] and len(spec['mandatory_moving_first_originals'])==27
assert sorted(spec['fixed_first_originals']+spec['fixed_short_originals']+spec['mandatory_moving_first_originals'])==list(range(66))
def shape(p):
    t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation']
    return Polygon([(mi*x*co-y*si+tx,mi*x*si+y*co+ty) for x,y in parts[p['part_id']]['geometry'][0]['outer']])
fixed=np.asarray([shape(p) for p in spec['fixed_first_placements']],dtype=object);st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];bounds=[m['left']+e+guard,m['bottom']+e+guard,st['width']-m['right']-e-guard,st['height']-m['top']-e-guard]
lattice=load(POOL/'lattice-proposals.json');old={};queries={};gs=[];seen=set();minimum=math.inf
for i,r in enumerate(pool):
    assert i==r['index'];p=r['placement'];f=parts[p['part_id']];t=p['transform'];k=identity(p);assert k not in seen;seen.add(k);o=r['source'];assert p['part_id'] in ['bracket','insert','cog'] and p['sheet_id']=='sheet-0'
    if o['kind']=='lattice':
        saved=lattice[o['index']];assert saved['source']==o;lat=plan['lattice'];assert o['degrees'] in lat['angles_degrees'] and o['pitch'] in lat['horizontal_pitches_mm'] and o['parity'] in lat['parities'] and o['x_fraction'] in lat['horizontal_anchor_fractions'] and o['y_fraction'] in lat['vertical_anchor_fractions'] and 0<=o['row']<3 and 0<=o['column']<5
        x0,y0,x1,y1=lat['center_box_mm'];pitch=o['pitch'];dy=math.sqrt(3)*pitch/2;cx=x0+(x1-x0-4.5*pitch)*o['x_fraction']+(o['column']+((o['row']+o['parity'])%2)/2)*pitch;cy=y0+(y1-y0-2*dy)*o['y_fraction']+o['row']*dy
        assert o['center_mm']==[cx,cy];a=math.radians(o['degrees']);co,si=math.cos(a),math.sin(a);expected={'part_id':'cog','transform':{'rotation_radians':a,'mirrored':False,'translation':[cx-139.723742*co+139.723742*si,cy-139.723742*si-139.723742*co]}};assert identity(expected)==identity(saved['placement'])
    elif o['kind']=='historical':
        path=o['path']
        if path not in old:old[path]=load(ROOT/path)
        saved=old[path][o['index']];assert saved['index']==o['index'];expected=saved['placement']
    else:
        assert o['kind']=='boundary contact';q=o['query']
        if q not in queries:queries[q]=load(POOL/'regions'/f'{q:03d}.json')
        v=queries[q];a=v['orientation'];assert a in plan['orientations'];expected={'part_id':a['family'],'transform':{'rotation_radians':a['angle'],'mirrored':a['mirrored'],'translation':v['proposals'][o['proposal']]['point']}}
    assert identity(expected)==k and (not t['mirrored'] or f['allow_mirror'])
    assert f['rotations']['kind']=='free' or any(abs(math.remainder(t['rotation_radians']-math.radians(a),math.tau))<1e-9 for a in f['rotations']['degrees'])
    g=shape(p);assert g.is_valid;bb=g.bounds;assert bb[0]>bounds[0] and bb[1]>bounds[1] and bb[2]<bounds[2] and bb[3]<bounds[3];ds=shapely.distance(g,fixed);assert bool(np.all(ds>required));minimum=min(minimum,float(ds.min()));gs.append(g)
    assert time.perf_counter()-start<300,'Declared audit limit reached; no pass'
gs=np.asarray(gs,dtype=object);bb=shapely.bounds(gs)
circle_specs={'cog':(139.723742,139.723742,109100),'bracket':(50.,50.,49990),'insert':(90.,55.,54990)}
centers=[];radii=[];circle_edges=0
for r,g in zip(pool,gs):
    p=r['placement'];t=p['transform'];x,y,radius=circle_specs[p['part_id']];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];center=[round((mi*x*co-y*si+tx)*1000),round((mi*x*si+y*co+ty)*1000)];centers.append(center);radii.append(radius)
    ratios=[[float(x).as_integer_ratio(),float(y).as_integer_ratio()] for x,y in list(g.exterior.coords)[:-1]];scale=math.lcm(1000,*(v[1] for pt in ratios for v in pt));vertices=[(a*(scale//b),c*(scale//d)) for (a,b),(c,d) in ratios];q=[v*(scale//1000) for v in center];rr=radius*(scale//1000);winding=0
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1];ux,uy=q[0]-a[0],q[1]-a[1];length=dx*dx+dy*dy;dot=ux*dx+uy*dy;cross=dx*uy-dy*ux;assert length>0
        if dot<=0:assert ux*ux+uy*uy>rr*rr
        elif dot>=length:assert(q[0]-b[0])**2+(q[1]-b[1])**2>rr*rr
        else:assert cross*cross>rr*rr*length
        if a[1]<=q[1]<b[1] and cross>0:winding+=1
        if b[1]<=q[1]<a[1] and cross<0:winding-=1
        circle_edges+=1
    assert abs(winding)==1
centers=np.asarray(centers,dtype=np.int64);radii=np.asarray(radii,dtype=np.int64);assert int(np.abs(centers).max())<10**8
write(OUT/'contained-disks.json',{'centers_units1000':centers.tolist(),'radii_units1000':radii.tolist(),'exact_finite_edge_checks':circle_edges,'statement':'Each certified disk has an interior center by nonzero exact winding and strictly avoids every finite boundary segment. It is contained in the original filled polygon. Strict overlap of two such disks proves conflict. All center-distance squared operations fit signed64-bit integers under the checked coordinate bound.'})
def floor1000(x):
    a,b=float(x).as_integer_ratio();return(a*1000)//b
def ceil1000(x):
    a,b=float(x).as_integer_ratio();return-((-a*1000)//b)
ib=np.asarray([[floor1000(a),floor1000(b),ceil1000(c),ceil1000(d)] for a,b,c,d in bb],dtype=np.int64)
threshold=math.ceil(required*1000);width=(n+7)//8
with gzip.open(BASE/'adjacency.bin.gz','rb') as f:data=f.read()
assert len(data)==n*width
matrix=np.unpackbits(np.frombuffer(data,dtype=np.uint8).reshape(n,width),axis=1,bitorder='little')[:,:n]
assert not bool(np.any(np.diag(matrix)))
for i in range(0,n,512):assert np.array_equal(matrix[i:i+512],matrix[:,i:i+512].T)
pairs=far=near=conflicts=inner=0
for i in range(n):
    js=np.arange(i+1,n);pairs+=len(js);b=ib[i+1:]
    safe=(b[:,0]-ib[i,2]>threshold)|(ib[i,0]-b[:,2]>threshold)|(b[:,1]-ib[i,3]>threshold)|(ib[i,1]-b[:,3]>threshold)
    delta=centers[i+1:]-centers[i];overlap=np.sum(delta*delta,axis=1)<(radii[i+1:]+radii[i])**2;assert not bool(np.any(overlap&safe));unresolved=js[~(safe|overlap)];blocked=shapely.distance(gs[i],gs[unresolved])<=required;expected=overlap.astype(np.uint8);expected[unresolved[blocked]-i-1]=1
    assert np.array_equal(matrix[i,i+1:],expected),i;far+=int(safe.sum());inner+=int(overlap.sum());near+=len(unresolved);conflicts+=int(expected.sum())
    assert time.perf_counter()-start<300,'Declared audit limit reached; no pass'
    if (i+1)%2000==0:print({'rows':i+1,'original_distances':near,'seconds':time.perf_counter()-start},flush=True)
assert pairs==n*(n-1)//2==far+near+inner and conflicts==load(BASE/'result.json')['conflicts'] and digest(BASE/'adjacency.bin.gz')==load(BASE/'result.json')['graph_sha256']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_candidates_verified':n,'family_counts':dict(Counter(r['placement']['part_id'] for r in pool)),'fixed_original_pair_checks':n*len(fixed),'stock_edge_checks':4*n,'all_unordered_candidate_pairs_verified':pairs,'conservative_integer_box_separations':far,'exact_contained_disk_edge_checks':circle_edges,'contained_disk_overlap_conflicts':inner,'original_polygon_distances':near,'complete_conflicts_verified':conflicts,'every_graph_row_verified':True,'graph_symmetric_zero_diagonal':True,'minimum_fixed_original_gap_mm':minimum,'required_original_gap_mm':required,'all66_original_identities_accounted_once':True,'required_moving_counts':{'bracket':4,'insert':8,'cog':15},'finite_pool_only':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
