"""Audit the single mandatory27-original response and all positive constraints."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb,sat_parameters_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-central-notch-joint-selection-20261026';RUN=BASE/'search';OUT=BASE/'response-audit-timing-repaired';RED=ROOT/'output/h5-central-notch-joint-graph-recovered-20261026/reduced';POOL=ROOT/'output/h5-central-notch-joint-pool-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def model(p):
    v=pb.CpModelProto();v.ParseFromString(p.read_bytes());return v
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents},'method':'Verify one closed60solver/90shared call, exact imported model and parameters, terminal response and timings. Independently evaluate every returned variable and active at-most-one, conditional bool-and and exact family count. Positives require all27 mandatory original movers; no partial count is accepted. Negative/UNKNOWN results do not exclude unrestricted geometry. No retries, reseeds or extensions.'})
for p in [BASE/'plan.json',BASE/'model-audit/plan.json']:
    for n,h in load(p)['inputs'].items():assert digest(ROOT/n)==h,n
assert load(BASE/'model-audit/checks.json')['passed'];proc=load(RUN/'process.json');budget=load(RUN/'budget.json');census=load(RUN/'census.json');assert proc['exit_code']==0 and not proc['timeout'] and proc['seconds']<=90 and budget['shared_seconds']==90 and budget['deadline_perf_counter']==budget['start_perf_counter']+90 and budget['maximum_calls']==1 and budget['per_group_solver_seconds']==60
folder=RUN/'000';r=load(folder/'result.json');opened=load(folder/'opened.json');assert census['solver_calls']==len(census['results'])==len(list(RUN.rglob('opened.json')))==1 and not census['pending_pairs'] and r==census['results'][0] and opened['maximum_calls']==r['solver_calls']==1 and r['parts']==load(BASE/'inventory.json')[0]['parts'] and len(r['parts'])==27
m=model(folder/'model.pb');assert m==model(BASE/'models/000.pb') and digest(folder/'model.pb')==opened['model_sha256'];params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params==sat_parameters_pb2.SatParameters(max_time_in_seconds=60,num_search_workers=4,random_seed=0,cp_model_probing_level=0,symmetry_level=0,log_search_progress=True,log_to_stdout=False) and digest(folder/'parameters.pbtxt')==opened['parameters_sha256'] and opened['seconds_limit']==60
response=pb.CpSolverResponse();response.ParseFromString((folder/'response.pb').read_bytes());assert pb.CpSolverStatus.Name(response.status)==r['status'] and 0<response.wall_time<=r['seconds']<=r['stage_seconds']<=proc['seconds'] and r['solver_soft_overshoot_seconds']==max(0,r['seconds']-60) and r['seconds']<=r['stage_seconds'];sol=list(response.solution);positive=r['status'] in ['FEASIBLE','OPTIMAL'];active=0;selected=[];counts={}
log=(folder/'solver.log').read_text();reported=float(re.findall(r'^walltime: ([0-9.]+)$',log,re.M)[-1]);assert abs(reported-response.wall_time)<.00005
assert r['status']!='UNKNOWN' or ('Stopped after presolve.' in log and response.num_branches==0 and response.num_conflicts==0)
if positive:
    assert len(sol)==len(m.variables) and sol[:54]==r['original_coordinates_units1000'] and all(v in [0,1] for v in sol) and sum(sol)==27
    def truth(i):return bool(sol[i]) if i>=0 else not bool(sol[-i-1])
    for v,n in zip(m.variables,sol):assert any(a<=n<=b for a,b in zip(v.domain[::2],v.domain[1::2]))
    for c in m.constraints:
        if not all(truth(i) for i in c.enforcement_literal):continue
        kind=c.WhichOneof('constraint')
        if kind=='linear':value=sum(sol[i]*coef for i,coef in zip(c.linear.vars,c.linear.coeffs));assert any(a<=value<=b for a,b in zip(c.linear.domain[::2],c.linear.domain[1::2]))
        elif kind=='at_most_one':assert sum(truth(i) for i in c.at_most_one.literals)<=1
        else:assert kind=='bool_and' and all(truth(i) for i in c.bool_and.literals)
        active+=1
    kept=load(RED/'kept-indices.json');pool=load(POOL/'candidates.json');selected=[kept[i] for i,v in enumerate(sol) if v];counts=dict(Counter(pool[i]['placement']['part_id'] for i in selected));assert counts=={'bracket':4,'insert':8,'cog':15};write(OUT/'selected-candidate-indices.json',selected)
else:assert r['status'] in ['INFEASIBLE','UNKNOWN'] and not sol
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'closed_calls':1,'status':r['status'],'solver_seconds':r['seconds'],'shared_seconds':proc['seconds'],'shared_budget_honored':True,'soft_overrun_seconds':r['solver_soft_overshoot_seconds'],'solver_reported_wall_seconds':response.wall_time,'solver_reported_soft_overrun_seconds':max(0,response.wall_time-60),'returned_call_overhead_seconds':r['seconds']-response.wall_time,'clock_scopes_and_log_verified':True,'stopped_after_presolve':r['status']=='UNKNOWN' and 'Stopped after presolve.' in log,'solver_branches':response.num_branches,'positive_variables_verified':len(sol),'positive_active_constraints_verified':active,'selected_originals':len(selected),'selected_family_counts':counts,'all27_originals_mandatory':True,'finite_pool_only':True,'unrestricted_exclusion_claimed':False,'original66_readback_pending':positive,'full66_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
