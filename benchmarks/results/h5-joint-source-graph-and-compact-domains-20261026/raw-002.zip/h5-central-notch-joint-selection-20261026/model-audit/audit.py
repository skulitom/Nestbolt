"""Recheck substitutions, full graph equivalence and the exact27-original model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import gzip,json,shutil,time
from ortools.sat import cp_model_pb2 as pb
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-central-notch-joint-selection-20261026';GRAPH=ROOT/'output/h5-central-notch-joint-graph-recovered-20261026';RED=GRAPH/'reduced';POOL=ROOT/'output/h5-central-notch-joint-pool-20261026';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def read_graph(p,n):
    w=(n+7)//8
    with gzip.open(p,'rb') as f:d=f.read()
    assert len(d)==n*w;return[int.from_bytes(d[i*w:(i+1)*w],'little') for i in range(n)]
def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents}})
for folder in [BASE,RED]:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GRAPH/'audit/checks.json')['passed'] and load(RED/'checks.json')['passed'];pool=load(POOL/'candidates.json');kept=load(RED/'kept-indices.json');n=len(kept);ks=set(kept);original=read_graph(GRAPH/'adjacency.bin.gz',len(pool));subs=load(RED/'substitutions.json');removed={r['removed'] for r in subs};assert ks.isdisjoint(removed) and len(removed)==len(subs) and ks|removed==set(range(len(pool)))
for r in subs:
    a,b=r['replacement'],r['removed'];assert a in ks and pool[a]['placement']['part_id']==pool[b]['placement']['part_id'] and (original[a]>>b)&1 and not(original[a]&~(original[b]|(1<<b)))
induced=read_graph(RED/'adjacency.bin.gz',n);remain=read_graph(RED/'residual-adjacency.bin.gz',n);expected=pb.CpModelProto();represented=remain.copy()
kept_mask=sum(1<<i for i in kept);local={i:j for j,i in enumerate(kept)}
for i,row in zip(kept,induced):assert row==sum(1<<local[j] for j in bits(original[i]&kept_mask))
for i in kept:expected.variables.add(name=f"original-{pool[i]['placement']['part_id']}-pose{i}",domain=[0,1])
with gzip.open(RED/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
    for line in f:
        row=json.loads(line);assert row==sorted(set(row)) and len(row)>=2 and 0<=row[0]<row[-1]<n;mask=sum(1<<i for i in row)
        for i in row:represented[i]|=mask^(1<<i)
        expected.constraints.add().at_most_one.literals.extend(row)
assert represented==induced
for i,mask in enumerate(remain):
    upper=mask&~((1<<(i+1))-1)
    if upper:c=expected.constraints.add();c.enforcement_literal.append(i);c.bool_and.literals.extend(-j-1 for j in bits(upper))
counts={'bracket':4,'insert':8,'cog':15}
for family,count in counts.items():
    c=expected.constraints.add();ids=[j for j,i in enumerate(kept) if pool[i]['placement']['part_id']==family];c.linear.vars.extend(ids);c.linear.coeffs.extend([1]*len(ids));c.linear.domain.extend([count,count])
actual=pb.CpModelProto();actual.ParseFromString((BASE/'models/000.pb').read_bytes());assert actual==expected and not actual.HasField('objective') and not actual.HasField('solution_hint')
model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'models/000.pbtxt').read_text()) and model.validate()=='' and model.export_to_file(str(OUT/'roundtrip.pb'));actual.ParseFromString((OUT/'roundtrip.pb').read_bytes());assert actual==expected
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables':n,'constraints':len(expected.constraints),'same_family_substitutions_reverified':len(subs),'all_retained_conflicts_reconstructed':True,'induced_conflicts':sum(a.bit_count() for a in induced)//2,'exact_required_counts':counts,'required_originals':27,'all_protobuf_fields_reconstructed':True,'no_relaxed_quantity_or_objective':True,'actual_import_export_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
