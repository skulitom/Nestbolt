"""Require every remaining original in one joint finite-pose model."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import Counter
import gzip,json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2 as pb
ROOT=Path(__file__).resolve().parents[1];GRAPH=ROOT/'output/h5-central-notch-joint-graph-recovered-20261026';RED=GRAPH/'reduced';POOL=ROOT/'output/h5-central-notch-joint-pool-20261026';INV=ROOT/'output/h5-central-notch-mixed-core-20261026/audit';OUT=ROOT/'output/h5-central-notch-joint-selection-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit
assert load(RED/'checks.json')['passed'] and load(GRAPH/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'models').mkdir();shutil.copyfile(__file__,OUT/'prepare.py');start=time.perf_counter()
inputs=[RED/n for n in ['plan.json','checks.json','kept-indices.json','substitutions.json','adjacency.bin.gz','residual-adjacency.bin.gz','cliques.jsonl.gz']]+[POOL/'candidates.json',GRAPH/'audit/checks.json',INV/'next-neighborhood.json',INV/'checks.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'maximum_calls':1,'solver_seconds':60,'shared_seconds':90,'workers':4,'seed':0,'required_moving_counts':{'bracket':4,'insert':8,'cog':15},'mandatory_originals':27,'fixed_first_originals':24,'fixed_short_originals':15,'method':'Select exactly four original bracket poses, eight insert poses and fifteen cog poses from the completely audited joint pool around the changed24-original first-sheet core. All retained cliques and every residual original conflict remain. Every omitted pool candidate has a checked same-family substitution preserving all exact count feasibility. No objective or relaxed quantity is used. Full protobuf and actual import/export must pass an independent audit before the sole60solver/90shared call. A positive requires independent original66 readback and native/material validation; an INFEASIBLE result excludes only the saved finite pool. No repeat, reseed or extension. Diagnostic construction is not a production60-second integration result.'})
pool=load(POOL/'candidates.json');kept=load(RED/'kept-indices.json');n=len(kept);m=pb.CpModelProto()
for i in kept:m.variables.add(name=f"original-{pool[i]['placement']['part_id']}-pose{i}",domain=[0,1])
with gzip.open(RED/'cliques.jsonl.gz','rt',encoding='utf-8') as f:cliques=[json.loads(l) for l in f]
for row in cliques:m.constraints.add(at_most_one=pb.BoolArgumentProto(literals=row))
with gzip.open(RED/'residual-adjacency.bin.gz','rb') as f:data=f.read()
width=(n+7)//8;assert len(data)==n*width;forward=edges=0
for i in range(n):
    mask=int.from_bytes(data[i*width:(i+1)*width],'little')&~((1<<(i+1))-1)
    if mask:m.constraints.add(enforcement_literal=[i],bool_and=pb.BoolArgumentProto(literals=[-j-1 for j in bits(mask)]));forward+=1;edges+=mask.bit_count()
for family,count in [('bracket',4),('insert',8),('cog',15)]:
    ids=[j for j,i in enumerate(kept) if pool[i]['placement']['part_id']==family];assert len(ids)>=count;m.constraints.add(linear=pb.LinearConstraintProto(vars=ids,coeffs=[1]*len(ids),domain=[count,count]))
p=OUT/'models/000.pb';p.write_bytes(m.SerializeToString());p.with_suffix('.pbtxt').write_text(text_format.MessageToString(m),encoding='utf-8',newline='\n')
write(OUT/'inventory.json',[{'index':0,'parts':load(INV/'next-neighborhood.json')['mandatory_moving_first_originals'],'variables':n,'constraints':len(m.constraints),'model_sha256':digest(p),'solver_seconds':60,'original_coordinates_field_is_pose_selection_bits_only':True}])
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'variables':n,'constraints':len(m.constraints),'cliques':len(cliques),'forward_implications':forward,'represented_residual_edges':edges,'exact_required_counts':{'bracket':4,'insert':8,'cog':15},'solver_calls':0});print(load(OUT/'prepared.json'))
