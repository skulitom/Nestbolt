"""Exact disk refinement, complete domain coverage, merges and capacity propagation."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations,product
import json,math,shutil,time
from h5_rational_geometry_helpers import point_bounds,contains
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-fixed24-joint-combined-domains-20261026';SUPPORT=ROOT/'output/h5-fixed24-joint-support-domains-20261026';SCREEN=ROOT/'output/h5-fixed24-joint-cog-space-20261026';SRC=ROOT/'output/h5-source-orientation-construction-20261025';GEOM=ROOT/'output/h5-rotation-independent-geometry-20261026';TIP=ROOT/'output/h5-all-angle-support-bounds-20261026';INVENTORY=ROOT/'output/h5-fixed24-joint-neighborhood-20261026';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=BASE/'audit'
PAIRPROOF=ROOT/'output/h5-cog-pair-rotation-certificate-20261026/audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();ratio=lambda x:[x.numerator,x.denominator]
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();paths=[p for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents]+[ROOT/'output/h5_rational_geometry_helpers.py',SRC/'geometry.json',TIP/'cog-spacing-proof.json',TIP/'audit/checks.json',INVENTORY/'next-neighborhood.json',INVENTORY/'checks.json',JOB,GEOM/'original-cog-proof.json',PAIRPROOF/'checks.json',PAIRPROOF/'necessity-proof.json'];write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in paths},'method':'Verify exact all-angle center-stock root, all24 fixed owner transforms, each used source-point collision disk by exact winding and trig intervals, and every refinement split/leaf. Check complete retention of every original support-grid cell and every boundary. Verify merged rectangles by exact containment, area and single-use atomic membership. Derive necessary cell capacities and incompatible-cell pairs from the254297-unit rounded center separation. No prior cog seed is asserted feasible in the changed core. All12 moving non-cogs remain mandatory for the later joint model; their omission from fixed obstacles only weakens this necessary domain.'})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(SUPPORT/'audit/checks.json')['passed'] and load(TIP/'audit/checks.json')['passed'] and load(INVENTORY/'checks.json')['passed'];stock=[F(*v) for v in load(SRC/'geometry.json')['stock_bounds_rational'][0]];h=F(139270,1000);e=F(1,50);expected=[stock[0]-e+h,stock[1]-e+h,stock[2]+e-h,stock[3]+e-h];root=[math.floor(v*1000) if i<2 else math.ceil(v*1000) for i,v in enumerate(expected)];assert root==load(SUPPORT/'grid.json')['root_bounds_units1000']==[145750,145750,1354250,2854250]
owners={r['item']:r for r in load(SCREEN/'fixed-originals-and-obstacles.json')};items=load(SRC/'items.json');ids={(r['family'],r['copy']):i for i,r in enumerate(items)};expected_owners={ids[p['part_id'],p['copy_index']]:p for p in load(INVENTORY/'next-neighborhood.json')['fixed_first_placements']};assert len(owners)==24 and set(owners)==set(expected_owners) and all(o['placement']==expected_owners[i] for i,o in owners.items());families={p['id']:p for p in load(JOB)['parts']};circles={r['index']:r for r in load(BASE/'collision-circles.json')};nodes=load(BASE/'refinement-tree.json');used=sorted({n['excluded_by_circle'] for n in nodes if 'excluded_by_circle' in n});certs=[]
for i in used:
    r=circles[i];owner=owners[r['item']];assert r['kind']=='original-point' and r['radius_units1000']==109100;point=[F(*v) for v in r['source_point_rational']];vs=[tuple(map(F,v)) for v in families[owner['family']]['geometry'][0]['outer']];assert contains(vs,point);p=point_bounds(point,owner['placement']['transform']);c=[F(v,1000) for v in r['center_units1000']];error=sum(max(abs(v-c[k]) for v in p[k])**2 for k in range(2));assert error<F(15,1000)**2;certs.append({'circle':i,'item':r['item'],'squared_center_error_upper_mm2':ratio(error)})
source=load(SUPPORT/'allowed-closed-cells.json');visited=set();stack=list(range(len(source)));kept=set();excluded=0
for i,r in enumerate(source):assert nodes[i]['source_cell']==i and nodes[i]['bounds_units1000']==r['bounds_units1000']
while stack:
    i=stack.pop();assert i not in visited;visited.add(i);n=nodes[i];assert n['index']==i;b=n['bounds_units1000'];assert b[0]<b[2] and b[1]<b[3]
    if 'children' in n:
        axis=n['axis'];mid=n['split'];assert axis in [0,1] and b[axis]<mid<b[axis+2];left=list(b);right=list(b);left[axis+2]=mid;right[axis]=mid;l,r=n['children'];assert nodes[l]['bounds_units1000']==left and nodes[r]['bounds_units1000']==right;stack.extend([l,r])
    elif 'excluded_by_circle' in n:
        c=circles[n['excluded_by_circle']];x,y=c['center_units1000'];margin=c['radius_units1000']**2-max((u-x)**2+(v-y)**2 for u in [b[0],b[2]] for v in [b[1],b[3]]);assert margin>0 and margin==n['strict_corner_margin_squared'];excluded+=1
    else:assert n['retained'] in ['outside disks','unresolved boundary'];kept.add(i)
assert visited==set(range(len(nodes))) and kept==set(load(BASE/'retained-atomic-nodes.json'))
domains=load(BASE/'merged-domain-rectangles.json');members=[]
for i,d in enumerate(domains):
    assert d['index']==i;b=d['bounds_units1000'];area=0
    for j in d['atomic_nodes']:
        assert j in kept;a=nodes[j]['bounds_units1000'];assert b[0]<=a[0] and b[1]<=a[1] and a[2]<=b[2] and a[3]<=b[3];area+=(a[2]-a[0])*(a[3]-a[1]);members.append(j)
    assert area==(b[2]-b[0])*(b[3]-b[1])
assert len(members)==len(set(members))==len(kept) and set(members)==kept
# All source circles have original center distance >=254300; the two floor
# errors differ by <1micrometre per coordinate, so a3micrometre loss is safe.
assert load(PAIRPROOF/'checks.json')['passed'] and load(PAIRPROOF/'checks.json')['original_all_angle_center_separation_units1000']==254300
D=254297;assert 3*3>2;caps=[]
for d in domains:
    a,b,c,e=d['bounds_units1000'];w,h=c-a,e-b;options=[15]
    for span,transverse in [(w,h),(h,w)]:
        if transverse<D:
            square=D*D-transverse*transverse;q=math.isqrt(square);q+=q*q<square;options.append(span//q+1)
    caps.append({'domain':d['index'],'capacity':min(options)})
conflicts=[]
for a,b in combinations(domains,2):
    aa,bb=a['bounds_units1000'],b['bounds_units1000'];dx=max(abs(aa[0]-bb[2]),abs(aa[2]-bb[0]));dy=max(abs(aa[1]-bb[3]),abs(aa[3]-bb[1]))
    if dx*dx+dy*dy<D*D:conflicts.append([a['index'],b['index']])
# Retain all cross-domain presence exclusions, but use count-sum rows only for unit endpoints.
presence_conflicts=list(conflicts);conflicts=[(a,b) for a,b in presence_conflicts if caps[a]['capacity']==caps[b]['capacity']==1]
write(OUT/'incompatible-presence-pairs.json',presence_conflicts)
assert all(caps[a]['capacity']==caps[b]['capacity']==1 for a,b in conflicts)
seed_checks=[];center=load(GEOM/'original-cog-proof.json')['center']
for seed in load(INVENTORY/'next-neighborhood.json')['prior_original_cog_poses_for_diagnostics_only']:
    bounds=point_bounds(center,seed['placement']['transform']);points=list(product(range(math.floor(bounds[0][0]*1000),math.floor(bounds[0][1]*1000)+1),range(math.floor(bounds[1][0]*1000),math.floor(bounds[1][1]*1000)+1)));assert 1<=len(points)<=4;matches=[]
    for x,y in points:
        ds=[d['index'] for d in domains if d['bounds_units1000'][0]<=x<=d['bounds_units1000'][2] and d['bounds_units1000'][1]<=y<=d['bounds_units1000'][3]];assert ds,(seed['item'],x,y);matches.append({'point_units1000':[x,y],'domains':ds})
    seed_checks.append({'item':seed['item'],'possible_floor_centers':matches})
write(OUT/'source-point-certificates.json',certs);write(OUT/'cell-capacities.json',caps);write(OUT/'incompatible-cell-pairs.json',conflicts);write(OUT/'existing-seed-domain-checks.json',seed_checks)
write(OUT/'necessity-proof.json',{'fixed_first_originals':24,'all15_moving_cogs_mandatory':True,'all_real_cog_angles_and_continuous_anchors':True,'statement':'The parent support-grid cells cover every source-feasible continuous center. Each removed refinement leaf is wholly within a source-point collision disk by exact corner distances and independently bounded transform error. Binary splits preserve closed coverage; all unresolved boundary leaves remain. Each merged rectangle contains disjoint atomic interiors with equal exact area; the finite closed union therefore fills the entire merged rectangle. Every source center floors into a retained integer rectangle. Cell capacities follow from full pair separation and complete transverse span; incompatible domain pairs have maximum corner-to-corner distance strictly less than254297 units. The254300 source center bound loses a conservative3 units on relative flooring. No old source seeds are assumed feasible. All12 moving non-cogs remain mandatory in the subsequent joint formulation. No actual fifteen-cog witness is claimed.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'exact_root_verified':True,'fixed_owner_transforms_verified':24,'used_source_disks_verified':len(used),'refinement_nodes_verified':len(nodes),'excluded_leaves_verified':excluded,'retained_atomic_leaves':len(kept),'merged_domains_verified':len(domains),'cell_capacities_verified':len(caps),'incompatible_cell_pairs_verified':len(conflicts),'existing_seed_centers_preserved':len(seed_checks),'source_center_separation_units':254300,'rounded_center_separation_units':D,'all_conflict_endpoints_separately_capacity1':True,'continuous_boundary_coverage_verified':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
