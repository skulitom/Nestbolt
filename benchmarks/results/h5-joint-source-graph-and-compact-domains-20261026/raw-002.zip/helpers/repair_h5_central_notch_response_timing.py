"""Keep the failed timing assertion and audit distinct measured clock scopes explicitly."""
from pathlib import Path
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-central-notch-joint-selection-20261026'
failure={'utc':datetime.now(timezone.utc).isoformat(),'exit_code':1,'checks_json_emitted':False,'failed_assertion':'Absolute difference between internal solver wall time and returned solve-call elapsed must be below0.2seconds','solver_reported_wall_seconds':60.5158472,'returned_call_elapsed_seconds':61.01589320006315,'returned_call_overhead_seconds':0.5000460000631435,'shared_elapsed_seconds':63.90977790008765,'solver_seconds_limit':60,'shared_seconds_limit':90,'repair':'The internal solver timer and caller timer have different scopes; the arbitrary200ms equality check is not a requirement. Preserve both measurements, verify the internal wall time against the saved solver log, require their chronological ordering within the actual shared process, and explicitly report both soft solver-limit overruns. The90-second shared budget is unchanged. The sole UNKNOWN call remains closed with zero branches; no solver is rerun.'}
with (BASE/'response-audit/failure-review.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(failure,f,indent=2);f.write('\n')
s=(ROOT/'output/audit_h5_central_notch_joint_selection_response.py').read_text()
s=s.replace("OUT=BASE/'response-audit'","OUT=BASE/'response-audit-timing-repaired'").replace('import json,shutil,time','import json,re,shutil,time')
s=s.replace("abs(response.wall_time-r['seconds'])<.2", "0<response.wall_time<=r['seconds']<=r['stage_seconds']<=proc['seconds']")
needle="if positive:\n"
extra="log=(folder/'solver.log').read_text();reported=float(re.findall(r'^walltime: ([0-9.]+)$',log,re.M)[-1]);assert abs(reported-response.wall_time)<.00005\nassert r['status']!='UNKNOWN' or ('Stopped after presolve.' in log and response.num_branches==0 and response.num_conflicts==0)\n"
assert needle in s;s=s.replace(needle,extra+needle,1)
s=s.replace("'soft_overrun_seconds':r['solver_soft_overshoot_seconds'],", "'soft_overrun_seconds':r['solver_soft_overshoot_seconds'],'solver_reported_wall_seconds':response.wall_time,'solver_reported_soft_overrun_seconds':max(0,response.wall_time-60),'returned_call_overhead_seconds':r['seconds']-response.wall_time,'clock_scopes_and_log_verified':True,'stopped_after_presolve':r['status']=='UNKNOWN' and 'Stopped after presolve.' in log,'solver_branches':response.num_branches,")
with (ROOT/'output/audit_h5_central_notch_joint_selection_response_timing_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print(failure)
