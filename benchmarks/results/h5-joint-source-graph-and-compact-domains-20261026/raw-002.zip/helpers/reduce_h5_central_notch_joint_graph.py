"""Certified same-family substitutions and lossless constraint compression."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from collections import Counter
import gzip,heapq,itertools,json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-central-notch-joint-graph-20261026';POOL=ROOT/'output/h5-central-notch-joint-pool-20261026';OUT=BASE/'reduced'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def read_graph(p,n):
    width=(n+7)//8
    with gzip.open(p,'rb') as f:data=f.read()
    assert len(data)==n*width;return[int.from_bytes(data[i*width:(i+1)*width],'little') for i in range(n)]
def save_graph(p,rows):
    width=(len(rows)+7)//8
    with gzip.open(p,'wb') as f:
        for row in rows:f.write(row.to_bytes(width,'little'))
def bits(mask):
    while mask:
        bit=mask&-mask;yield bit.bit_length()-1;mask^=bit
assert load(BASE/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'reduce.py');start=time.perf_counter()
inputs=[BASE/n for n in ['plan.json','adjacency.bin.gz','result.json','audit/checks.json']]+[POOL/'candidates.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'reduction_seconds':30,'maximum_comparisons':40000000,'compression_seconds':20,'method':'Remove candidate b only if an earlier retained original pose a has the same family, conflicts with b, and every neighbor of a except b is also a neighbor of b in the entire original graph. Such a substitution preserves any independent set and exact family counts. Keep all unprocessed candidates at either cap. Save every substitution and the complete induced graph on retained poses. Compress verified cliques for20seconds, storing every residual edge as a full binary adjacency matrix. Independently verify every substitution, projected original adjacency row, clique membership and complete residual coverage before preparing a mandatory4-bracket/8-insert/15-cog model. No solver is opened here.'})
pool=load(POOL/'candidates.json');n=len(pool);adj=read_graph(BASE/'adjacency.bin.gz',n);family=[r['placement']['part_id'] for r in pool];order=sorted(range(n),key=lambda i:(adj[i].bit_count(),i));kept=[];removed=[];byfamily={f:[] for f in set(family)};comparisons=0;bounded=False;began=time.perf_counter()
for at,b in enumerate(order):
    if time.perf_counter()-began>=30 or comparisons>=40000000:kept.extend(order[at:]);bounded=True;break
    replacement=None
    for a in byfamily[family[b]]:
        comparisons+=1
        if (adj[b]>>a)&1 and not(adj[a]&~(adj[b]|(1<<b))):replacement=a;break
        if comparisons>=40000000 or time.perf_counter()-began>=30:break
    if replacement is None:kept.append(b);byfamily[family[b]].append(b)
    else:removed.append({'removed':b,'replacement':replacement})
reduction_seconds=time.perf_counter()-began;kept=sorted(kept);ks=set(kept);assert ks.isdisjoint(r['removed'] for r in removed) and ks|{r['removed'] for r in removed}==set(range(n))
certificate_neighbors=0
for r in removed:
    b,a=r['removed'],r['replacement'];assert a in ks and family[a]==family[b] and (adj[a]>>b)&1
    remaining=adj[a]^(1<<b);assert remaining&adj[b]==remaining;certificate_neighbors+=remaining.bit_count()
width=(n+7)//8;data=b''.join(a.to_bytes(width,'little') for a in adj);matrix=np.unpackbits(np.frombuffer(data,dtype=np.uint8).reshape(n,width),axis=1,bitorder='little')[:,:n];sub=matrix[np.ix_(kept,kept)];packed=np.packbits(sub,axis=1,bitorder='little');projected=[int.from_bytes(row.tobytes(),'little') for row in packed];del matrix,sub,packed,data
save_graph(OUT/'adjacency.bin.gz',projected);assert read_graph(OUT/'adjacency.bin.gz',len(kept))==projected
# Check projection by extracting source bit positions directly from original row bytes.
source_bytes=np.asarray(kept,dtype=np.int64)//8;source_bits=(np.asarray(kept,dtype=np.int64)%8).astype(np.uint8)
for old,new in zip(kept,projected):
    row=np.frombuffer(adj[old].to_bytes(width,'little'),dtype=np.uint8)
    wanted=int.from_bytes(np.packbits((row[source_bytes]>>source_bits)&1,bitorder='little').tobytes(),'little')
    assert wanted==new
write(OUT/'kept-indices.json',kept);write(OUT/'substitutions.json',removed)
remain=projected.copy();heap=[(-a.bit_count(),i) for i,a in enumerate(projected) if a];heapq.heapify(heap);cliques=[];began=time.perf_counter()
while heap and time.perf_counter()-began<20:
    degree,i=heapq.heappop(heap)
    if -degree!=remain[i].bit_count() or not remain[i]:continue
    choices=remain[i];row=[i];mask=1<<i
    while choices:
        sample=list(itertools.islice(bits(choices),16));j=max(sample,key=lambda j:((projected[j]&choices).bit_count(),-j));row.append(j);mask|=1<<j;choices&=projected[j]
    assert all(not((mask^(1<<j))&~projected[j]) for j in row);cliques.append(sorted(row))
    for j in row:
        remain[j]&=~mask
        if remain[j]:heapq.heappush(heap,(-remain[j].bit_count(),j))
compression_seconds=time.perf_counter()-began
with gzip.open(OUT/'cliques.jsonl.gz','xt',encoding='utf-8',newline='\n') as f:
    for row in cliques:f.write(json.dumps(row,separators=(',',':'))+'\n')
save_graph(OUT/'residual-adjacency.bin.gz',remain);covered=read_graph(OUT/'residual-adjacency.bin.gz',len(kept))
with gzip.open(OUT/'cliques.jsonl.gz','rt',encoding='utf-8') as f:
    for line in f:
        row=json.loads(line);assert row==sorted(set(row));mask=sum(1<<j for j in row)
        for j in row:assert not((mask^(1<<j))&~projected[j]);covered[j]|=mask^(1<<j)
assert covered==projected
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'original_candidates':n,'kept_candidates':len(kept),'kept_family_counts':dict(Counter(family[i] for i in kept)),'removed_candidates':len(removed),'reduction_seconds':reduction_seconds,'reduction_comparisons':comparisons,'reduction_limit_reached':bounded,'certified_original_neighbor_memberships':certificate_neighbors,'exact_family_counts_preserved':True,'every_induced_original_row_verified':True,'induced_conflicts':sum(a.bit_count() for a in projected)//2,'compression_seconds':compression_seconds,'cliques':len(cliques),'residual_edges':sum(a.bit_count() for a in remain)//2,'compression_limit_reached':bool(heap),'all_original_induced_conflicts_reconstructed':True,'all27_originals_mandatory':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
