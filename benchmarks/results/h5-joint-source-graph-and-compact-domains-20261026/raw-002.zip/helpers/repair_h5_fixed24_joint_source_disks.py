"""Preserve the rejected stale-position preparation and reproject original local points."""
from pathlib import Path
from datetime import datetime,timezone
import json
ROOT=Path(__file__).resolve().parents[1];FAILED=ROOT/'output/h5-fixed24-joint-combined-domains-20261026'
assert not(FAILED/'result.json').exists()
failure={'utc':datetime.now(timezone.utc).isoformat(),'exit_code':1,'failed_assertion':'Every fixed owner transform equals the prior first-three-cog transform','checks_or_result_emitted':False,'stale_world_circles_used':False,'solver_calls':0,'repair':'The changed frame arrangement invalidates old world-space circles. Reuse only original local source-point coordinates, reproject every point with its current owner transform into a new folder, and require the independent exact winding/Taylor audit before any domain use. Keep all failed input manifests and helpers.'}
with (FAILED/'failure-review.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(failure,f,indent=2);f.write('\n')
s=(ROOT/'output/refine_h5_fixed24_joint_support_domains.py').read_text()
s=s.replace('import json,shutil,time','import copy,json,math,shutil,time\nfrom fractions import Fraction as F')
s=s.replace("OUT=ROOT/'output/h5-fixed24-joint-combined-domains-20261026'","OUT=ROOT/'output/h5-fixed24-joint-combined-domains-repaired-20261026'")
s=s.replace("OLD_SCREEN/'fixed-originals-and-obstacles.json']","OLD_SCREEN/'fixed-originals-and-obstacles.json',ROOT/'output/h5-fixed24-joint-combined-domains-20261026/failure-review.json']")
s=s.replace('Retain exactly the24 fixed non-cog owners from the previous source-point disk construction; their transforms are unchanged.','Use only local original-point coordinates from the prior source sample, and reproject all of them through the current24 fixed owner transforms. No old world-space circle center is retained without recomputation.')
old="old={r['item']:r for r in load(OLD_SCREEN/'fixed-originals-and-obstacles.json')};assert len(owners)==24 and all(r['placement']==old[i]['placement'] for i,r in owners.items());circles=[r for r in load(COVER/'circles.json') if r['item'] in owners];assert all(r['kind']=='original-point' and r['radius_units1000']==109100 for r in circles);xy="
new="""assert len(owners)==24;circles=[]
for source in load(COVER/'circles.json'):
    if source['item'] not in owners:continue
    assert source['kind']=='original-point' and source['radius_units1000']==109100
    r=copy.deepcopy(source);t=owners[r['item']]['placement']['transform'];x,y=[float(F(*v)) for v in r['source_point_rational']];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];r['center_units1000']=[round((mi*x*co-y*si+tx)*1000),round((mi*x*si+y*co+ty)*1000)];circles.append(r)
assert set(r['item'] for r in circles)==set(owners)
xy="""
assert old in s;s=s.replace(old,new)
with (ROOT/'output/refine_h5_fixed24_joint_support_domains_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(ROOT/'output/audit_h5_fixed24_joint_combined_domains.py').read_text().replace('h5-fixed24-joint-combined-domains-20261026','h5-fixed24-joint-combined-domains-repaired-20261026')
with (ROOT/'output/audit_h5_fixed24_joint_combined_domains_repaired.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print(failure)
