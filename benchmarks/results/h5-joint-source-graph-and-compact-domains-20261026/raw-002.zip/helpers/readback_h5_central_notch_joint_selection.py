"""Read back every original vertex and cutout of an exact27-mover positive."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
from collections import Counter
import copy,json,math,shutil,time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-central-notch-joint-selection-20261026';POOL=ROOT/'output/h5-central-notch-joint-pool-20261026';INV=ROOT/'output/h5-central-notch-mixed-core-20261026/audit';SRC=ROOT/'output/h5-source-orientation-construction-20261025';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';OUT=BASE/'original-readback'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'response-audit/checks.json')['original66_readback_pending'];OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
inputs=[BASE/'response-audit/checks.json',BASE/'response-audit/selected-candidate-indices.json',POOL/'candidates.json',INV/'next-neighborhood.json',INV/'checks.json',SRC/'items.json',SRC/'geometry.json',JOB]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Assign each selected pose to one mandatory original of the same family. Retain every fixed first and short pose exactly. Directly reconstruct every outer and hole vertex, permissions, area, all same-sheet filled-outer pair distances and all original guarded stock edges. All66 original identities and90 cutouts must pass. This source check does not substitute for native/material validation, production integration or the H5 matrix.'})
spec=load(INV/'next-neighborhood.json');items=load(SRC/'items.json');ids={(i['family'],i['copy']):j for j,i in enumerate(items)};pool=load(POOL/'candidates.json');indices=load(BASE/'response-audit/selected-candidate-indices.json');placements=copy.deepcopy(spec['fixed_first_placements']+spec['fixed_short_placements']);assign=[]
for family in ['bracket','insert','cog']:
    selected=[i for i in indices if pool[i]['placement']['part_id']==family];originals=[i for i in spec['mandatory_moving_first_originals'] if items[i]['family']==family];assert len(selected)==len(originals)
    for index,original in zip(selected,originals):
        p=copy.deepcopy(pool[index]['placement']);p['copy_index']=items[original]['copy'];placements.append(p);assign.append({'candidate':index,'original':original})
assert len(placements)==66 and sorted(ids[p['part_id'],p['copy_index']] for p in placements)==list(range(66));job=load(JOB);families={p['id']:p for p in job['parts']};stocks=[[float(F(*v)) for v in row] for row in load(SRC/'geometry.json')['stock_bounds_rational']];guard=3000*32*2**-23;gap=(job['clearance']+guard)/math.cos(.05);polys={};holes=vertices=0;edges=[]
for p in placements:
    original=ids[p['part_id'],p['copy_index']];f=families[p['part_id']];g=f['geometry'][0];t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];assert not t['mirrored'] or f['allow_mirror'];assert f['rotations']['kind']=='free' or any(abs(math.remainder(t['rotation_radians']-math.radians(v),math.tau))<1e-9 for v in f['rotations']['degrees'])
    def ring(vs):return [(mi*x*co-y*si+tx,mi*x*si+y*co+ty) for x,y in vs]
    outer=ring(g['outer']);inside=[ring(h) for h in g.get('holes',[])];full=Polygon(outer,inside);filled=Polygon(outer);source=Polygon(g['outer'],g.get('holes',[]));assert full.is_valid and filled.is_valid and abs(full.area-source.area)<1e-7 and len(full.interiors)==len(inside)
    for a,b in zip(full.interiors,inside):assert list(a.coords)[:-1]==b
    holes+=len(inside);vertices+=sum(map(len,inside));sheet=int(p['sheet_id'].split('-')[1]);b=filled.bounds;st=stocks[sheet];extra=[b[0]-st[0],b[1]-st[1],st[2]-b[2],st[3]-b[3]];assert min(extra)>guard;polys[original]=(sheet,filled);edges.append({'original':original,'extra_margins_mm':extra})
pairs=[]
for i,j in combinations(sorted(polys),2):
    sa,a=polys[i];sb,b=polys[j]
    if sa==sb:d=a.distance(b);assert a.disjoint(b) and d>gap;pairs.append({'originals':[i,j],'distance_mm':d})
assert holes==90 and vertices==10026 and len(pairs)==1380
write(OUT/'placements.json',placements);write(OUT/'assignment.json',assign);write(OUT/'pairs.json',pairs);write(OUT/'stock-edges.json',edges)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'originals_placed':66,'mandatory_movers_placed':27,'original_pair_checks':len(pairs),'stock_edge_checks':264,'cutouts_preserved':holes,'cutout_vertices_preserved':vertices,'minimum_pair_gap_mm':min(p['distance_mm'] for p in pairs),'required_native_pair_gap_mm':gap,'minimum_extra_stock_mm':min(min(p['extra_margins_mm']) for p in edges),'all_fixed_poses_preserved':True,'part_in_hole_used':False,'original66_source_witness':True,'native_material_validation_pending':True,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
