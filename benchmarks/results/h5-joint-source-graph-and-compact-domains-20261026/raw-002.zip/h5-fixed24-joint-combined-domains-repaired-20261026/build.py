"""Refine support-box domains with exact-cover collision disks; retain all boundary cells."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from collections import defaultdict
import copy,json,math,shutil,time
from fractions import Fraction as F
import numpy as np
from shapely.geometry import box,mapping
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];SOURCE=ROOT/'output/h5-fixed24-joint-support-domains-20261026';COVER=ROOT/'output/h5-fixed55-cog-coverage-20261026';SCREEN=ROOT/'output/h5-fixed24-joint-cog-space-20261026';OLD_SCREEN=ROOT/'output/h5-first-three-cog-space-20261026';OUT=ROOT/'output/h5-fixed24-joint-combined-domains-repaired-20261026'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[SOURCE/n for n in ['plan.json','allowed-closed-cells.json','grid.json','audit/checks.json','audit/necessity-proof.json']]+[COVER/'circles.json',COVER/'audit/checks.json',SCREEN/'fixed-originals-and-obstacles.json',OLD_SCREEN/'fixed-originals-and-obstacles.json',ROOT/'output/h5-fixed24-joint-combined-domains-20261026/failure-review.json']
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'construction_limit_seconds':120,'maximum_nodes':100000,'boundary_leaf_maximum_side_units1000':5000,'method':'Use only local original-point coordinates from the prior source sample, and reproject all of them through the current24 fixed owner transforms. No old world-space circle center is retained without recomputation. Begin with every audited closed support-grid allowed cell. Delete a cell only if all corners are strictly in a collision disk. Retain cells outside all disks immediately; otherwise bisect the longer side until at most5mm, retaining every unresolved boundary cell. Exact source-point/Taylor and tree audits precede use. Merge retained closed rectangles only by exact adjoining full sides; preserve atomic membership for an independent area/containment proof of each merge. No solver call.'})
assert load(SOURCE/'audit/checks.json')['passed'];owners={r['item']:r for r in load(SCREEN/'fixed-originals-and-obstacles.json')};assert len(owners)==24;circles=[]
for source in load(COVER/'circles.json'):
    if source['item'] not in owners:continue
    assert source['kind']=='original-point' and source['radius_units1000']==109100
    r=copy.deepcopy(source);t=owners[r['item']]['placement']['transform'];x,y=[float(F(*v)) for v in r['source_point_rational']];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];r['center_units1000']=[round((mi*x*co-y*si+tx)*1000),round((mi*x*si+y*co+ty)*1000)];circles.append(r)
assert set(r['item'] for r in circles)==set(owners)
xy=np.asarray([r['center_units1000'] for r in circles],dtype=np.int64);rsq=np.asarray([r['radius_units1000']**2 for r in circles],dtype=np.int64)
source=load(SOURCE/'allowed-closed-cells.json');nodes=[{'index':i,'source_cell':i,'bounds_units1000':r['bounds_units1000']} for i,r in enumerate(source)];queue=list(range(len(nodes)));retained=[];excluded=0
while queue and len(nodes)<100000 and time.perf_counter()-start<120:
    i=queue.pop();n=nodes[i];a,b,c,d=n['bounds_units1000'];dx=np.maximum(np.abs(xy[:,0]-a),np.abs(xy[:,0]-c));dy=np.maximum(np.abs(xy[:,1]-b),np.abs(xy[:,1]-d));scores=dx*dx+dy*dy-rsq;best=int(np.argmin(scores))
    if scores[best]<0:n.update({'excluded_by_circle':circles[best]['index'],'strict_corner_margin_squared':int(-scores[best])});excluded+=1;continue
    dx=np.maximum(0,np.maximum(a-xy[:,0],xy[:,0]-c));dy=np.maximum(0,np.maximum(b-xy[:,1],xy[:,1]-d));outside=bool(np.all(dx*dx+dy*dy>=rsq))
    if outside or max(c-a,d-b)<=5000:n['retained']='outside disks' if outside else 'unresolved boundary';retained.append(i);continue
    axis=0 if c-a>=d-b else 1;bb=[a,b,c,d];mid=(bb[axis]+bb[axis+2])//2;left=list(bb);right=list(bb);left[axis+2]=mid;right[axis]=mid;children=[len(nodes),len(nodes)+1];n.update({'axis':axis,'split':mid,'children':children});nodes.extend([{'index':children[0],'bounds_units1000':left},{'index':children[1],'bounds_units1000':right}]);queue.extend(children)
assert not queue,'Construction cap reached: no complete domain produced';current=[{'bounds_units1000':nodes[i]['bounds_units1000'],'atomic_nodes':[i]} for i in retained];merge_rounds=[]
while True:
    before=len(current)
    for axis in [0,1]:
        groups=defaultdict(list)
        for r in current:
            b=r['bounds_units1000'];groups[(b[1-axis],b[3-axis])].append(r)
        merged=[]
        for key,rs in sorted(groups.items()):
            rs.sort(key=lambda r:r['bounds_units1000'][axis]);acc=None
            for r in rs:
                if acc is not None and acc['bounds_units1000'][axis+2]==r['bounds_units1000'][axis]:acc['bounds_units1000'][axis+2]=r['bounds_units1000'][axis+2];acc['atomic_nodes']+=r['atomic_nodes']
                else:
                    if acc is not None:merged.append(acc)
                    acc={'bounds_units1000':list(r['bounds_units1000']),'atomic_nodes':list(r['atomic_nodes'])}
            if acc is not None:merged.append(acc)
        current=merged
    merge_rounds.append([before,len(current)])
    if len(current)==before:break
for i,r in enumerate(current):r['index']=i
free=unary_union([box(*(v/1000 for v in r['bounds_units1000'])) for r in current]);write(OUT/'collision-circles.json',circles);write(OUT/'refinement-tree.json',nodes);write(OUT/'retained-atomic-nodes.json',retained);write(OUT/'merged-domain-rectangles.json',current);write(OUT/'allowed-union-diagnostic.json',mapping(free));write(OUT/'result.json',{'seconds':time.perf_counter()-start,'fixed_originals':24,'collision_disks':len(circles),'support_source_cells':len(source),'refinement_nodes':len(nodes),'excluded_leaves':excluded,'retained_atomic_leaves':len(retained),'merged_domain_rectangles':len(current),'merge_rounds':merge_rounds,'used_collision_disks':len({n['excluded_by_circle'] for n in nodes if 'excluded_by_circle' in n}),'allowed_area_mm2':free.area,'allowed_bounds_mm':list(free.bounds),'complete_boundary_coverage':True,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'result.json'))
