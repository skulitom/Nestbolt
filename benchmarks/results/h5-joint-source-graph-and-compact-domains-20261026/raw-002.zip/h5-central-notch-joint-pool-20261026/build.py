"""Fresh joint original-shape candidates around the independently verified24-part core."""
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from collections import Counter, deque
import itertools, json, math, shutil, time
import numpy as np
import shapely
from shapely.geometry import Polygon, mapping
from shapely.affinity import affine_transform
import diagnose_h5_concave_gaps as gap
from build_h5_cog_free_regions import proposals, identity
ROOT=Path(__file__).resolve().parents[1]
INV=ROOT/'output/h5-central-notch-mixed-core-20261026/audit'
JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
OUT=ROOT/'output/h5-central-notch-joint-pool-20261026'
POOLS=[ROOT/'output'/n/'candidates.json' for n in ['h5-dense-cog-completion-20261023','h5-expanded-frame-joint-20261023']]
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();(OUT/'regions').mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter()
spec=load(INV/'next-neighborhood.json');assert load(INV/'checks.json')['passed'];job=load(JOB)
families={p['id']:p for p in job['parts']};source={k:Polygon(p['geometry'][0]['outer']) for k,p in families.items()}
guard=3000*32*2**-23;required=(job['clearance']+guard)/math.cos(.05)
orientations=[{'family':'bracket','angle':a*math.pi/2,'mirrored':m} for m in [False,True] for a in range(4)]+[{'family':'insert','angle':a*math.pi/2,'mirrored':False} for a in range(2)]+[{'family':'cog','angle':math.radians(a),'mirrored':False} for a in [0,4.5,6.25,7.75,9,11.25,13.5]]
inputs=[INV/'next-neighborhood.json',INV/'checks.json',JOB,Path(gap.__file__),ROOT/'output/build_h5_cog_free_regions.py']+POOLS
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'generation_seconds_limit':120,'maximum_candidates':20000,'maximum_new_boundary_contacts':3000,'required_pair_gap_mm':required,'required_stock_extra_mm':guard,'orientations':orientations,'lattice':{'angles_degrees':[0,4.5,9,13.5],'horizontal_pitches_mm':[254.5,260,270,279.675],'rows':3,'columns':5,'parities':[0,1],'horizontal_anchor_fractions':[0,.5,1],'vertical_anchor_fractions':[0,.5,1],'center_box_mm':[146.535,2297.66,1353.465,2853.465]},'method':'Keep the independently checked24 first-sheet originals and15 short originals fixed. All27 remaining originals stay mandatory: four brackets, eight inserts and fifteen cogs. Build finite cog lattice proposals, then directly recheck every compatible first-sheet small-part pose from two historical pools, then query fresh conservative source Minkowski translation regions at17 declared orientations and round-robin their boundary contacts. Exact float-transform deduplication only. Retain every event and all unfinished lists at the declared limits. Every accepted pose must satisfy the native-guard gap against all24 fixed original filled outers and the original guarded stock. This is a new joint pool; no previous36-owner domain, seed-feasibility or finite optimum is transferred. A separate complete original conflict graph and independent audit must precede one joint solver. No solver/native/quality call is opened here.'})
def shape(p):
    t=p['transform'];co,si=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1
    return affine_transform(source[p['part_id']],[mi*co,-si,mi*si,co,*t['translation']])
fixed=np.asarray([shape(p) for p in spec['fixed_first_placements']],dtype=object)
st=job['stocks'][0];m=st['margins'];e=job['edge_clearance'];bounds=[m['left']+e+guard,m['bottom']+e+guard,st['width']-m['right']-e-guard,st['height']-m['top']-e-guard]
pool=[];keys={};seen={};events=[];pending=[]
def consider(p,origin):
    p={'part_id':p['part_id'],'sheet_id':'sheet-0','transform':p['transform']};key=identity(p)
    if key in seen:return seen[key]
    g=shape(p);bb=g.bounds
    if not(bb[0]>bounds[0] and bb[1]>bounds[1] and bb[2]<bounds[2] and bb[3]<bounds[3]):result=(None,'stock')
    else:
        blocked=np.flatnonzero(shapely.distance(g,fixed)<=required).tolist()
        if blocked:result=(None,{'fixed_blockers':blocked})
        else:
            i=len(pool);keys[key]=i;pool.append({'index':i,'placement':p,'source':origin});result=(i,'added')
    seen[key]=result;return result
def record(p,origin):
    if len(pool)>=20000 or time.perf_counter()-start>=120:pending.append(origin);return False
    i,status=consider(p,origin);events.append({'source':origin,'candidate':i,'result':status});return True
lat=load(OUT/'plan.json')['lattice'];lattice=[]
for degrees,pitch,parity,xf,yf in itertools.product(lat['angles_degrees'],lat['horizontal_pitches_mm'],lat['parities'],lat['horizontal_anchor_fractions'],lat['vertical_anchor_fractions']):
    x0,y0,x1,y1=lat['center_box_mm'];dy=math.sqrt(3)*pitch/2;left=x0+(x1-x0-4.5*pitch)*xf;bottom=y0+(y1-y0-2*dy)*yf
    for row,col in itertools.product(range(3),range(5)):
        cx=left+(col+((row+parity)%2)/2)*pitch;cy=bottom+row*dy;a=math.radians(degrees);co,si=math.cos(a),math.sin(a)
        p={'part_id':'cog','transform':{'rotation_radians':a,'mirrored':False,'translation':[cx-139.723742*co+139.723742*si,cy-139.723742*si-139.723742*co]}}
        origin={'kind':'lattice','index':len(lattice),'degrees':degrees,'pitch':pitch,'parity':parity,'x_fraction':xf,'y_fraction':yf,'row':row,'column':col,'center_mm':[cx,cy]};lattice.append({'placement':p,'source':origin});record(p,origin)
write(OUT/'lattice-proposals.json',lattice);lattice_count=len(pool)
for path in POOLS:
    for r in load(path):
        p=r['placement']
        if p['sheet_id']!='sheet-0' or p['part_id']=='frame':continue
        record(p,{'kind':'historical','path':path.relative_to(ROOT).as_posix(),'index':r['index']})
historical_count=len(pool)-lattice_count;queries=[];gap.EPS=.0126
for oi,o in enumerate(orientations):
    if time.perf_counter()-start>=120:pending.extend({'kind':'unbuilt query','orientation':i} for i in range(oi,len(orientations)));break
    p={'part_id':o['family'],'transform':{'rotation_radians':o['angle'],'mirrored':o['mirrored'],'translation':[0.,0.]}};began=time.perf_counter();region=gap.regions(shape(p),list(fixed),st,e,required)
    q={'index':len(queries),'orientation':o,'seconds':time.perf_counter()-began,'geometry':mapping(region),'proposals':proposals(region)};queries.append(q);write(OUT/'regions'/f"{q['index']:03d}.json",q)
    print({'query':q['index'],'family':o['family'],'proposals':len(q['proposals']),'seconds':q['seconds']},flush=True)
queue=deque((q['index'],0) for q in queries if q['proposals']);new=0;before=len(pool)
while queue and len(pool)-before<3000 and len(pool)<20000 and time.perf_counter()-start<120:
    qi,pi=queue.popleft();q=queries[qi];o=q['orientation'];p={'part_id':o['family'],'transform':{'rotation_radians':o['angle'],'mirrored':o['mirrored'],'translation':q['proposals'][pi]['point']}}
    record(p,{'kind':'boundary contact','query':qi,'proposal':pi})
    if pi+1<len(q['proposals']):queue.append((qi,pi+1))
write(OUT/'candidates.json',pool);write(OUT/'events.json',events);write(OUT/'pending.json',{'omitted_proposals':pending,'boundary_lists':list(queue)})
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'candidates':len(pool),'candidate_family_counts':dict(Counter(r['placement']['part_id'] for r in pool)),'lattice_candidates':lattice_count,'historical_candidates':historical_count,'boundary_candidates':len(pool)-before,'queries':len(queries),'pending_proposals':len(pending),'pending_boundary_lists':len(queue),'mandatory_originals':27,'required_moving_counts':{'bracket':4,'insert':8,'cog':15},'fixed_first_originals':24,'fixed_short_originals':15,'all66_originals_required':True,'independent_audit_pending':True,'solver_calls':0,'H5_complete':False})
print(load(OUT/'result.json'),flush=True)
