"""Independent dynamic field readback, reusable inside the charged pipeline."""
import numpy as np
def verify(model,library,modes,values):
    assert len(modes)==28 and len(values)==68 and model['families']==library['families'] and model['pairs']==library['pairs'] and model['fixed_source_rows']==library['fixed_source_rows'] and model['objective_weights']=={'original_area':1,'clearance_area':1}
    expected=[];bounds=[]
    for i,identity in enumerate(library['identities']):
        mode=next(m for m in library['family_modes'][identity[0]] if m['mode']==modes[i]);free=identity[0]=='cog'
        expected.append({'owner':i,'identity':identity,'mode':modes[i],'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'source_center':library['families'][identity[0]]['source_center'],'angle_coordinate':56+i-16 if free else None,'angle_scale_mm':library['angle_scale_mm'] if free else None});bounds+=mode['center_bounds_mm']
    bounds+=library['angle_bounds'];assert model['owners']==expected and model['bounds']==bounds;expected_x=[min(max(float(v),b[0]),b[1]) for v,b in zip(values,bounds)];assert model['initial']==expected_x
    assert model['pairs']==[[i,j] for i in range(28) for j in range(i+1,28)]
    return True
