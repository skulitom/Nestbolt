"""Pure dynamic legal-mode model; every original uses a source-center pivot."""
import math,copy
import numpy as np
import shapely
from shapely.geometry import Polygon
from h5_direct_pose_model_20261107 import Objective as BaseObjective,transformed

def source_pose(owner,values):
    i=owner['owner'];theta=float(values[owner['angle_coordinate']])/owner['angle_scale_mm'] if owner['angle_coordinate'] is not None else owner['rotation_radians'];c,s=math.cos(theta),math.sin(theta);mirror=-1 if owner['mirrored'] else 1;px,py=owner['source_center'];return {'rotation_radians':theta,'mirrored':owner['mirrored'],'translation':[float(values[2*i])-(mirror*px*c-py*s),float(values[2*i+1])-(mirror*px*s+py*c)]}

def source_rows(model,values):
    return list(model['fixed_source_rows'])+[{'part_id':o['identity'][0],'copy_index':o['identity'][1],'sheet_id':'sheet-0','transform':source_pose(o,values)} for o in model['owners']]

def compile_model(library,modes,values):
    assert len(modes)==28 and len(values)==68;owners=[];bounds=[]
    for i,(identity,mode_index) in enumerate(zip(library['identities'],modes)):
        mode=library['family_modes'][identity[0]][mode_index];assert mode['mode']==mode_index
        owners.append({'owner':i,'identity':identity,'mode':mode_index,'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'source_center':library['families'][identity[0]]['source_center'],'angle_coordinate':56+i-16 if identity[0]=='cog' else None,'angle_scale_mm':library['angle_scale_mm'] if identity[0]=='cog' else None});bounds.extend(mode['center_bounds_mm'])
    bounds.extend(library['angle_bounds']);model={'families':library['families'],'owners':owners,'pairs':library['pairs'],'fixed_source_rows':library['fixed_source_rows'],'bounds':bounds,'initial':np.clip(values,np.asarray(bounds)[:,0],np.asarray(bounds)[:,1]).tolist(),'objective_weights':{'original_area':1,'clearance_area':1}}
    return model

class Objective(BaseObjective):
    def geometry(self,values):
        result=[]
        for kind in ['original','clearance']:
            entries=[]
            for o in self.model['owners']:
                pose=source_pose(o,values);v=transformed(self.model['families'][o['identity'][0]][kind],pose);p=Polygon(v);entries.append((v,p,shapely.linestrings(np.stack([v,np.roll(v,-1,axis=0)],axis=1)),[float(values[2*o['owner']]),float(values[2*o['owner']+1])]))
            result.append(entries)
        return result

def owner_shapes(library,family,mode_index,center,angle=0.):
    mode=library['family_modes'][family][mode_index];theta=angle if family=='cog' else mode['rotation_radians'];c,s=math.cos(theta),math.sin(theta);mirror=-1 if mode['mirrored'] else 1;px,py=library['families'][family]['source_center'];pose={'rotation_radians':theta,'mirrored':mode['mirrored'],'translation':[center[0]-(mirror*px*c-py*s),center[1]-(mirror*px*s+py*c)]}
    return [Polygon(transformed(library['families'][family][kind],pose)) for kind in ['original','clearance']]

def pair_energy(shapes,other):
    return sum(float(np.sum(shapely.area(shapely.intersection(p,np.asarray([s[k] for s in other],dtype=object))))) for k,p in enumerate(shapes)) if other else 0.
