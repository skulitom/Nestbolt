"""Full pair scoring without derivative work; no cached pair substitutions."""
import numpy as np
import shapely
from shapely.geometry import Polygon
from h5_mixed_direct_pose_20261107 import source_pose,transformed

def score(model,values):
    total=0.
    left=np.asarray([p[0] for p in model['pairs']]);right=np.asarray([p[1] for p in model['pairs']])
    for kind in ['original','clearance']:
        shapes=np.asarray([Polygon(transformed(model['families'][o['identity'][0]][kind],source_pose(o,values))) for o in model['owners']],dtype=object)
        total+=float(np.sum(shapely.area(shapely.intersection(shapes[left],shapes[right]))))
    assert np.isfinite(total)
    return total
