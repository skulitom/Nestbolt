from pathlib import Path
from hashlib import sha256
import json,math,time
import numpy as np
from shapely.geometry import Polygon
from h5_mixed_direct_pose_20261107 import compile_model
from h5_mixed_direct_readback_20261107 import verify
from h5_mixed_direct_score_20261107 import score
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=BASE/'score-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();lib=load(BASE/'library.json');modes=lib['initial_modes'];initial=np.array(lib['initial_values']);cases=[]
for variation in range(2):
    values=initial+.23*variation*np.cos(np.arange(68));vectors=[modes.copy()]
    for i,identity in enumerate(lib['identities'][:16]):
        for mode in lib['family_modes'][identity[0]]:
            if mode['mode']!=modes[i]:changed=modes.copy();changed[i]=mode['mode'];vectors.append(changed)
    for selected in vectors:
        model=compile_model(lib,selected,values);assert verify(model,lib,selected,values);x=np.array(model['initial']);expected=0.
        for kind in ['original','clearance']:
            shapes=[]
            for i,identity in enumerate(lib['identities']):
                mode=lib['family_modes'][identity[0]][selected[i]];theta=x[56+i-16]/lib['angle_scale_mm'] if i>=16 else mode['rotation_radians'];c,s=math.cos(theta),math.sin(theta);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][identity[0]]['source_center'];shapes.append(Polygon([(sign*(xx-px)*c-(yy-py)*s+x[2*i],sign*(xx-px)*s+(yy-py)*c+x[2*i+1]) for xx,yy in lib['families'][identity[0]][kind]]))
            expected+=sum(shapes[i].intersection(shapes[j]).area for i in range(28) for j in range(i+1,28))
        actual=score(model,x);error=abs(actual-expected);assert error<1e-7;cases.append({'variation':variation,'modes':selected,'maximum_absolute_error_mm2':error})
assert len(cases)==162
write(OUT/'cases.json',cases);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'independent_full_pair_score_controls':len(cases),'pairs_per_case':378,'maximum_absolute_error_mm2':max(r['maximum_absolute_error_mm2'] for r in cases),'source_optimizer_calls':0,'verification_only':True,'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),BASE/'library.json',ROOT/'output/h5_mixed_direct_pose_20261107.py',ROOT/'output/h5_direct_pose_model_20261107.py',ROOT/'output/h5_mixed_direct_readback_20261107.py',ROOT/'output/h5_mixed_direct_score_20261107.py']}});print(load(OUT/'checks.json'))
