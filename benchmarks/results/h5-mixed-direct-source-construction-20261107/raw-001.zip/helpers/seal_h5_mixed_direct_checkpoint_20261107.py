"""Preserve the source-only mixed model and its closed local search."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1];source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
replacements={"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-mixed-direct-source-construction-20261107'","BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-mixed-direct-pose-v2-20261107';F=ROOT/'output/h5-mixed-direct-checkpoint-20261107';D=ROOT/'output/h5-mixed-direct-pose-20261107'","PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-direct-source-pose-construction-20261107'","front['source_pair_failures']==39":"front['source_pair_failures']==41","folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,F,D]+[ROOT/'output'/n for n in ['h5-mixed-direct-preparation-process-20261107','h5-mixed-direct-preparation-v2-process-20261107','h5-mixed-direct-audit-process-20261107','h5-mixed-direct-score-audit-process-20261107','h5-mixed-direct-response-audit-process-20261107','h5-direct-pose-main-sync-20261107']]","['*h5*mixed*mode*20261107.py']":"['*h5*mixed*direct*20261107.py']","'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_mixed_direct_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"}
for old,new in replacements.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
copies=[(F/'checks.json','checkpoint-audit.json'),(F/'next-step.json','next-step.json'),(F/'historical-frame-scope.json','historical-frame-scope.json'),(F/'main-ci-at-review.json','main-ci-at-review.json'),(BASE/'audit/checks.json','source-and-model-audit.json'),(BASE/'audit/short-row-exact-readback.json','short-row-exact-proof.json'),(BASE/'audit/preserved-failed-phase-controls.json','failed-short-phase-controls.json'),(BASE/'audit/derivative-controls.json','derivative-controls.json'),(BASE/'audit/seed-directional-controls.json','directional-controls.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(BASE/'score-audit/checks.json','full-pair-score-audit.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/mode-selection-controls.json','mode-selection-controls.json'),(BASE/'response-audit/collision-details.json','source-failures.json'),(BASE/'search/process.json','closed-search-process.json'),(ROOT/'output/h5-mixed-direct-preparation-process-20261107/process.json','failed-preparation-process.json'),(ROOT/'output/h5-mixed-direct-preparation-v2-process-20261107/process.json','corrected-preparation-process.json'),(ROOT/'output/h5-mixed-direct-audit-process-20261107/process.json','model-audit-process.json'),(ROOT/'output/h5-mixed-direct-response-audit-process-20261107/process.json','response-audit-process.json'),(ROOT/'output/h5-direct-pose-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
report=f'''# Source-only mixed orientation and continuous-angle construction — 2026-11-07

The broader original-source model closes after **one optimizer call and 80
orientation trials**. Its best candidate remains invalid: **41 overlapping
pairs**, with all stock checks passing. Summed original intersection area
falls from **143,568.273079 to 32,299.348636 mm²**, while the number of failing
pairs rises from22 to41. This is neither a valid layout nor an improvement
in every measure. No native or LightBurn call follows. H2/H5 remain open at
**60% completed milestone weight**, with four fixed arrangements and440
whole allocations remaining. No continuous space or allocation is excluded.

## Independent original-source initialization

The preceding continuous-angle model held all bracket/insert orientations
fixed and exhausted its consumed budget. This new physical model combines
**every legal bracket/insert quarter-turn and mirror mode with12continuous
cog angles**. It does not load the previous candidate, selected orientations,
partitions, clearance contours, gradients or transforms as initialization.
Pure geometry and objective code is reused; all algorithm data is freshly
constructed from the frozen original job. The three original normal-mode
archives, CRCs, nested job hashes and validation metrics independently retain
the unchanged **4,988,890.353495 mm²** material target.

Fresh constrained triangulation and exact convex merges produce2bracket,
1insert and21cog pieces. Signed boundary cancellation and exact areas verify
the partitions. Expanded clearance contours pass **9,344 exact support
proofs**, with minimum certified local gap **0.114999999975 mm**. The original
pair threshold remains **0.211708672510 mm**; the construction gap is0.23mm.
The source-only fixed recipe places18frames in three columns of six and11
turned inserts in the side strip. All29 originals pass source checks.

The first frozen short-sheet construction tries four declared cog phases.
Each has zero pair failures but one stock failure. This preparation closes
unsuccessfully after **1.113545 s**, before the initializer or any optimizer.
[All four original failures]({NAME}/failed-short-phase-controls.json) and their
complete process cost remain preserved; that phase batch is not extended.

A distinct analytic construction derives tooth pitch and the first tooth
bisector from the original cog vertices. Requiring reflected opposing tooth
bisectors to differ by half a pitch gives **6.750000000058°**. An independent
[exact rational readback of441 convex-piece pair sections]({NAME}/short-row-exact-proof.json)
verifies the forbidden row-translation maximum and the upward-rounded
**261.766 mm** pitch. The resulting short sheet holds four brackets, two
inserts and three cogs, with all36 source pairs passing.

The twelve remaining cogs start in a deterministic5/5/2circle-safe arrangement.
The eight brackets and eight inserts are placed sequentially by scoring every
legal mode on a frozen5×5center grid. All **2,400 candidates** and deterministic
selections replay independently. The full66-part seed fails22pairs and passes
all stock checks. [Corrected preparation]({NAME}/corrected-preparation-process.json)
takes **1.875282 s**. Complete charged preparation is **2.988826 s**, including
the entire failed attempt. The failed and corrected preparations are separate,
immutable records; no original result is replaced.

## Source, mode and numerical controls

[The full audit]({NAME}/source-and-model-audit.json) verifies all66 identities,
90holes,10,026hole vertices,108owner/mode bindings and81dynamic mode vectors.
All28 moving originals use their exact original-source center as the rotation
pivot.56center coordinates and12scaled angle coordinates remain independent.
Every one of the378 moving pairs appears in both original-area and
clearance-area terms; filled outers enforce noPIH.

**528 source stock-corner controls**,88scalar/batched gradient comparisons,
[136 central-coordinate checks]({NAME}/derivative-controls.json),
[three projected seed-descent checks]({NAME}/directional-controls.json) and
[seven corruption controls]({NAME}/negative-controls.json) pass. The shared-edge
gradient retains its explicit symmetric convention; no unique classical
derivative or global convergence is claimed there. A separate area-only
scorer passes [162 independent full-pair comparisons]({NAME}/full-pair-score-audit.json)
before execution. Verification is recorded separately and does not supply
candidate data to the search.

## Closed bounded pipeline

The frozen pipeline permits at most four calls, ten seconds each, with a
60-second algorithm limit,90-second shared limit,2GiB memory cap and four-second
source-check reserve. After the initial call, another call requires a strictly
improving, never-optimized discrete mode vector. Only the changed owner's
coordinates may be clamped to its new certified bounds. All66 originals must
be checked after every candidate.

The initial call stops on time after **81 evaluations and66 saved points**,
including its starting point. It returns no numerical convergence result.
Combined original-plus-clearance area falls from **288,506.463746 to
65,518.432149 mm²**. [Independent response replay]({NAME}/response-audit.json)
checks every saved value and gradient, all68 coordinates, every legal source
transform,1,632 same-sheet pairs,264stock edges,90holes and10,026hole vertices.
[All41 failed pairs]({NAME}/source-failures.json) have positive overlap area.

[All80 single-owner orientation changes]({NAME}/mode-selection-controls.json)
are then scored, with no change exceeding the declared1e-6mm² strict-improvement
threshold. The pipeline closes at this stop condition. Its unused time does
not authorize repeating the same call, continuing its mode vector or changing
the closed stop rule. The result is a local search failure, not infeasibility.

The10-second optimizer slice returns in **10.078549 s**; its **0.078549 s**
overrun is preserved. Preparation-inclusive algorithm/shared totals are
**14.719117 /14.791915 s**, within their original limits. [All five processes
close normally]({NAME}/closed-search-process.json); peak committed memory is
**92,991,488 bytes**. The separate [response audit]({NAME}/response-audit-process.json)
takes **9.770944 s** and also closes normally.

## Next source scope and repository state

[Historical review]({NAME}/historical-frame-scope.json) finds that four-column
frame patterns were already tested in a closed finite-mode distance-objective
search on26October. The frame topology is not a new discovery, and that batch
will not be reopened. [Next assess]({NAME}/next-step.json) a construction that
also frees the eleven side-strip inserts, while retaining all legal discrete
nonframe modes and continuous cog angles. This would require39moving originals
and newly certified nonrectangular free domains around the frames. Its exact
scope, deterministic initialization and all source interactions must be
verified before execution. No such new model, preparation or call is opened.
Any reused geometry or candidate must carry its complete consumed cost.

H2's original gate remains open under the earlier user decision. Full66 source,
native, material, unchanged H5 matrix and production UI/CLI/MCP parity remain
required. [The preceding two checkpoints reached main30a26572 normally]({NAME}/prior-main-push-receipt.json),
preserving all52 protected remote files. [Five current CI jobs pass]({NAME}/main-ci-at-review.json);
Windows native CI is live at review. This checkpoint awaits the ordinary push
gate. Production, README and releases are unchanged.

[Raw evidence]({NAME}/raw-manifest.json) preserves {archive['archive_members']}
canonical members and {archive['archive_bytes']:,} ZIP bytes. [Historical
references]({NAME}/external-evidence.json) and [source bindings]({NAME}/source-bindings.json)
retain exact provenance. Independent archive readback is required before commit.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 source-only mixed-mode construction:** [independent source/model/response audits]({link}) verify fresh original partitions, 9,344 clearance supports, all 2,400 initialization trials, 108 owner/mode bindings, 528 stock-corner controls and 162 full-pair scoring controls. A source-derived 6.75-degree tooth phase and 261.766 mm pitch produce a valid nine-part small sheet after four preserved phase failures. Complete failed-plus-corrected preparation is 2.988826 s. One ten-second call lowers summed original overlap from 143,568.273079 to 32,299.348636 mm², but all66 source replay finds 41 overlapping pairs and no stock failures. All 80 subsequent orientation changes fail the strict improvement threshold, closing the pipeline. All 66 saved points and 81 evaluations replay. Algorithm/shared totals are 14.719117/14.791915 s; the 0.078549 s optimizer-slice overrun remains recorded and all processes close. No valid layout or exclusion follows. Historical four-column frame patterns are acknowledged; next assess a changed continuous-angle model that also frees eleven side-strip inserts, with new original-source domains and complete accounting before execution. No successor is prepared. Four fixed arrangements and 440 allocations remain, H2/H5 stay open at 60%, and all closed calls stay closed. Main30a26572 has five passed jobs and live Windows native CI at review. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
path=ROOT/'docs/STATUS.md';s=path.read_text(encoding='utf-8');begin=s.index('Latest H5 evidence:');end=s.index('\nThe earlier fixed 13-cog construction',begin)
intro=f'''Latest H5 evidence: [source-only mixed-mode construction](../benchmarks/results/{NAME}.md).
Fresh source initialization, every legal bracket/insert mode and twelve continuous
cog angles pass complete geometry, mode, stock and numerical controls. One bounded
call lowers summed original overlap, but its candidate fails41pairs; all stock
checks pass. None of80single-owner orientation changes improves it, closing the
pipeline after81evaluations and66saved points. Preparation-inclusive algorithm/
shared totals are14.719117/14.791915s; the0.078549s optimizer-slice overrun is preserved.
The failed short-sheet preparation remains charged and unchanged; a new analytic
tooth-phase construction produces a source-valid nine-part short sheet.
Next assess a changed frame/free-insert construction with continuous cog angles,
acknowledging that the frame topology has been tested before. Its new source domains,
initializer and complete accounting must be verified before any call; none is prepared.
Four fixed arrangements and440allocations remain; H2/H5 stay open at60%.
Full source/native/material validation, production parity and the unchanged H5
matrix remain required. Main30a26572 contains the preceding two checkpoints.
Five current CI jobs pass; Windows native CI is live. This checkpoint awaits the
ordinary push gate. No release qualifies.
'''
path.write_text(s[:begin]+intro+s[end:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
