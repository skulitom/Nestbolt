from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from itertools import combinations,product
from statistics import median
from hashlib import sha256
from datetime import datetime,timezone
import json,math,time,shutil,copy,zipfile
import numpy as np
import shapely
from shapely.geometry import Polygon
from h5_exact_convex_partition_tools_20261029 import hull,area,cross
from h5_mixed_direct_pose_20261107 import compile_model,Objective,source_rows,owner_shapes,pair_energy
from h5_mixed_direct_readback_20261107 import verify
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=BASE/'audit';OLD=ROOT/'output/h5-mixed-direct-pose-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';BENCH=ROOT/'benchmarks/results/h5-source-frontier-pilot-20261018';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');lib=load(BASE/'library.json');job=load(JOB);parts={p['id']:p for p in job['parts']};recipe=load(BASE/'source-recipe.json');partitions=load(BASE/'partitions.json');proofs=load(BASE/'clearance-supports.json');saved_target=load(BASE/'benchmark-target.json');stock=job['stocks'][0];m=stock['margins'];edge=job['edge_clearance'];lower=[m['left']+edge,m['bottom']+edge];upper=[stock['width']-m['right']-edge,stock['height']-m['top']-edge]
normals=[r for r in load(BENCH/'results.json')['records'] if r['job']==job['name'] and r['kerf_mm']==.2 and r['arm']=='normal'];normal_areas=[]
for r in normals:
    p=BENCH/r['archive'];assert digest(p)==r['archive_sha256']
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None and sha256(z.read('nested/job.json')).hexdigest()==digest(JOB);validation=json.loads(z.read('validate-stdout.json'));assert validation['valid'] and validation['metrics']==r['metrics'];normal_areas.append(validation['metrics']['material_area'])
normal=median(normal_areas);target=normal*1.01;short_height=(target-stock['width']*stock['height'])/stock['width'];stocks={'sheet-0':lower+upper,'sheet-1':lower+[upper[0],short_height-m['top']-edge]};guard=max(stock['width'],stock['height'])*32*2**-23;required=(job['clearance']+guard)/math.cos(.05);gap=math.ceil((required+.01)*100)/100
assert saved_target['normal_median_material_mm2']==normal and saved_target['target_material_mm2']==target and saved_target['source_stocks']==lib['source_stocks']==stocks and lib['required_pair_gap_mm']==required and lib['stock_guard_mm']==guard
partition_counts={};support_count=0;min_gap=math.inf
def ccw(points):
    v=[tuple(map(F,p)) for p in points]
    return v if area(v)>0 else v[::-1]
for family in ['bracket','insert','cog']:
    original=ccw(parts[family]['geometry'][0]['outer']);pieces=[ccw(p) for p in partitions[family]['pieces']];assert lib['families'][family]['original']==parts[family]['geometry'][0]['outer'];vertices=set(original)|{v for p in pieces for v in p}
    def boundary(polygons):
        edges=Counter()
        for p in polygons:
            for a,b in zip(p,p[1:]+p[:1]):
                vv=sorted(v for v in vertices if cross(a,b,v)==0 and all(min(a[k],b[k])<=v[k]<=max(a[k],b[k]) for k in [0,1]));vv=vv if a<b else vv[::-1];assert vv[0]==a and vv[-1]==b
                for x,y in zip(vv,vv[1:]):edges[min(x,y),max(x,y)]+=1 if x<y else -1
        return {k:v for k,v in edges.items() if v}
    assert boundary(pieces)==boundary([original]) and sum(map(area,pieces))==area(original) and all(area(p)>0 and area(p)==area(hull(p)) for p in pieces);partition_counts[family]=len(pieces)
    expanded=ccw(lib['families'][family]['clearance']);poly=Polygon(expanded);assert poly.is_valid and not poly.interiors;point=original[0];winding=0
    for a,b in zip(expanded,expanded[1:]+expanded[:1]):
        if a[1]<=point[1]<b[1] and cross(a,b,point)>0:winding+=1
        elif b[1]<=point[1]<a[1] and cross(a,b,point)<0:winding-=1
    assert winding!=0 and len(proofs[family])==len(original)*len(expanded);seen=set()
    for p in proofs[family]:
        ai,bi=p['source_edge'],p['expanded_edge'];assert (ai,bi) not in seen;seen.add((ai,bi));a,b=original[ai],original[(ai+1)%len(original)];c,d=expanded[bi],expanded[(bi+1)%len(expanded)];nx,ny=map(F,p['normal']);norm=nx*nx+ny*ny;distance=min(nx*x+ny*y for x,y in [c,d])-max(nx*x+ny*y for x,y in [a,b]);assert norm>0 and distance>0 and distance*distance>=F('.114')**2*norm;min_gap=min(min_gap,float(distance)/math.sqrt(float(norm)));support_count+=1
    center=[float((min(p[k] for p in original)+max(p[k] for p in original))/2) for k in [0,1]];assert lib['families'][family]['source_center']==center
assert partition_counts=={'bracket':2,'insert':1,'cog':21} and support_count==9344
write(OUT/'exact-source-partitions.json',partition_counts)
def normrow(family,index,theta,xy,sheet='sheet-0'):
    c,s=math.cos(theta),math.sin(theta);v=[(x*c-y*s,x*s+y*c) for x,y in parts[family]['geometry'][0]['outer']];return {'part_id':family,'copy_index':index,'sheet_id':sheet,'transform':{'rotation_radians':theta,'mirrored':False,'translation':[xy[k]-min(p[k] for p in v) for k in [0,1]]}}
origin=[v+.025 for v in lower];frame=parts['frame']['geometry'][0]['outer'];fw=max(v[0] for v in frame)-min(v[0] for v in frame);fh=max(v[1] for v in frame)-min(v[1] for v in frame);cols=math.floor((upper[0]-.025-origin[0]+gap)/(fw+gap));nrows=math.ceil(parts['frame']['quantity']/cols);right=origin[0]+cols*fw+(cols-1)*gap;top=origin[1]+nrows*fh+(nrows-1)*gap;insert=parts['insert']['geometry'][0]['outer'];iw=max(p[0] for p in insert)-min(p[0] for p in insert);ih=max(p[1] for p in insert)-min(p[1] for p in insert);side=math.floor((top-origin[1]+gap)/(iw+gap));fixed=[normrow('frame',i,0,[origin[0]+(i%cols)*(fw+gap),origin[1]+(i//cols)*(fh+gap)]) for i in range(18)]+[normrow('insert',i,math.pi/2,[right+gap,origin[1]+i*(iw+gap)]) for i in range(side)];assert cols==3 and nrows==6 and side==11 and fixed==load(BASE/'fixed29-source.json')
assert audit(job,fixed,stocks,required,guard)==load(BASE/'fixed29-checks.json') and load(BASE/'fixed29-checks.json')['valid']
br=parts['bracket']['geometry'][0]['outer'];arm,stem=br[2][1],br[3][0];mw,mh=2*arm+iw+2*gap,2*stem+ih+2*gap;short_orth=[]
for n in range(2):
    x=origin[0]+n*(mw+gap);y=origin[1];short_orth.extend([{'part_id':'bracket','copy_index':2*n,'sheet_id':'sheet-1','transform':{'rotation_radians':3*math.pi/2,'mirrored':False,'translation':[x,y+mh]}},{'part_id':'bracket','copy_index':2*n+1,'sheet_id':'sheet-1','transform':{'rotation_radians':math.pi/2,'mirrored':False,'translation':[x+mw,y]}},normrow('insert',side+n,0,[x+arm+gap,y+stem+gap],'sheet-1')])
analytic=load(BASE/'short-analytic-phase.json');center=lib['families']['cog']['source_center'];v=parts['cog']['geometry'][0]['outer'];rr=[math.dist(p,center) for p in v];outer={i for i,r in enumerate(rr) if r>(min(rr)+max(rr))/2};starts=[i for i in sorted(outer) if (i-1)%len(v) not in outer];polar=lambda i:math.atan2(v[i][1]-center[1],v[i][0]-center[0]);period=(polar(starts[1])-polar(starts[0]))%math.tau;bisector=polar(starts[0])+((polar(starts[0]+1)-polar(starts[0]))%math.tau)/2;phase=math.degrees(.75*period-bisector);assert analytic['rotation_degrees']==phase and analytic['outer_vertex_indices']==sorted(outer) and analytic['tooth_start_indices']==starts and len(starts)==20
# Independent rational source NFP row intersection, not the producer's GEOS clip.
c,s=map(F,[math.cos(math.radians(phase)),math.sin(math.radians(phase))]);pieces=[[(F(x)*c-F(y)*s,F(x)*s+F(y)*c) for x,y in p] for p in partitions['cog']['pieces']];square=list(product([-F(gap),F(gap)],repeat=2));maximum=None
for a,b in product(pieces,pieces):
    p=hull([(x[0]-y[0]+z[0],x[1]-y[1]+z[1]) for x,y,z in product(a,b,square)]);ends=[x[0] for x in p if x[1]==0]
    for x,y in zip(p,p[1:]+p[:1]):
        if x[1]*y[1]<0:ends.append(x[0]-x[1]*(y[0]-x[0])/(y[1]-x[1]))
    if ends:maximum=max([max(ends)]+([] if maximum is None else [maximum]))
derivation=load(BASE/'short-cog-derivation.json');assert len(derivation)==1 and abs(float(maximum)-derivation[0]['maximum_forbidden_row_translation_mm'])<1e-9;pitch=derivation[0]['pitch_mm'];assert F(pitch)>maximum and pitch==math.ceil((float(maximum)+.000002)*1000)/1000
left=origin[0]+2*(mw+gap);short=short_orth+[normrow('cog',i,math.radians(phase),[left+i*pitch,origin[1]],'sheet-1') for i in range(3)];assert short==load(BASE/'short9-source.json');short_check=audit(job,short,stocks,required,guard);assert short_check==load(BASE/'short-00-checks.json') and short_check['valid'];write(OUT/'short-row-exact-readback.json',{'source_phase_degrees':phase,'source_piece_pairs':441,'exact_maximum_forbidden_row_translation_mm':str(maximum),'chosen_pitch_mm':pitch,'positive_source_pairs':36,'minimum_source_gap_mm':short_check['minimum_pair_gap_mm'],'source_valid':True})
failure_controls=[]
for i in range(4):
    oldrows=load(OLD/f'short-{i:02d}-source.json');oldcheck=audit(job,oldrows,stocks,required,guard);assert oldcheck==load(OLD/f'short-{i:02d}-checks.json') and oldcheck['pair_failures']==0 and oldcheck['stock_failures']==1 and not oldcheck['valid'];failure_controls.append({'case':i,'source_pair_failures':0,'source_stock_failures':1,'minimum_stock_mm':oldcheck['minimum_extra_stock_mm']})
write(OUT/'preserved-failed-phase-controls.json',failure_controls)
ids=[[p['id'],i] for p in job['parts'] for i in range(p['quantity'])];used={(r['part_id'],r['copy_index']) for r in fixed+short};identities=[[family,i] for family in ['bracket','insert','cog'] for i in range(parts[family]['quantity']) if (family,i) not in used];assert lib['fixed_source_rows']==fixed+short and lib['identities']==identities and lib['all66_identities']==ids and len(ids)==66
safe=[lower[0]+.025,top+gap,upper[0]-.025,upper[1]-.025];radius=lib['angle_scale_mm'];exact_radius=max(sum((F(p[k])-F(center[k]))**2 for k in [0,1]) for p in v);assert F(radius)**2>exact_radius and lib['safe_moving_stock_mm']==safe and lib['angle_bounds']==[[-math.pi*radius,math.pi*radius] for _ in range(12)]
for family,modes in lib['family_modes'].items():
    px,py=lib['families'][family]['source_center']
    if family=='cog':assert modes==[{'mode':0,'rotation_radians':0.,'mirrored':False,'center_bounds_mm':[[safe[k]+radius,safe[k+2]-radius] for k in [0,1]],'continuous_rotation':True}];continue
    expected_modes=[(mirror,math.radians(theta)) for mirror in ([False,True] if parts[family]['allow_mirror'] else [False]) for theta in parts[family]['rotations']['degrees']];assert len(modes)==len(expected_modes)
    for index,(mode,(mirror,theta)) in enumerate(zip(modes,expected_modes)):
        assert mode['mode']==index and mode['mirrored']==mirror and mode['rotation_radians']==theta and not mode['continuous_rotation'];c,s=map(F,[math.cos(theta),math.sin(theta)]);sign=-1 if mirror else 1;vv=[(sign*(F(x)-F(px))*c-(F(y)-F(py))*s,sign*(F(x)-F(px))*s+(F(y)-F(py))*c) for x,y in lib['families'][family]['original']]
        for k,(lo,hi) in enumerate(mode['center_bounds_mm']):assert F(lo)+min(p[k] for p in vv)>F(safe[k]) and F(hi)+max(p[k] for p in vv)<F(safe[k+2])
modes=lib['initial_modes'];values=np.asarray(lib['initial_values']);model=compile_model(lib,modes,values);assert model==load(BASE/'initial-model.json') and verify(model,lib,modes,values)
def own_shapes(family,mode,xy,theta=0.):
    mm=lib['family_modes'][family][mode];angle=theta if family=='cog' else mm['rotation_radians'];c,s=math.cos(angle),math.sin(angle);sign=-1 if mm['mirrored'] else 1;px,py=lib['families'][family]['source_center'];tx,ty=xy[0]-(sign*px*c-py*s),xy[1]-(sign*px*s+py*c);return [Polygon([(sign*x*c-y*s+tx,sign*x*s+y*c+ty) for x,y in lib['families'][family][kind]]) for kind in ['original','clearance']]
placed=[];cogseed=load(BASE/'cog-source-seed.json');bb=lib['family_modes']['cog'][0]['center_bounds_mm'];columns=math.floor((safe[2]-safe[0]+gap)/(2*radius+gap));rows_count=math.ceil(12/columns)
for n,row in enumerate(cogseed):
    r=n//columns;column=n%columns;nr=min(columns,12-r*columns);xy=[bb[0][0]+(bb[0][1]-bb[0][0])*(column/(nr-1) if nr>1 else .5),bb[1][0]+(bb[1][1]-bb[1][0])*(r/(rows_count-1) if rows_count>1 else .5)];assert row=={'owner':16+n,'row':r,'column':column,'row_count':nr,'center':xy,'angle':0.} and values[2*(16+n):2*(16+n)+2].tolist()==xy;placed.append(own_shapes('cog',0,xy))
trial_count=0;trial_energy=0.;trial_records=load(BASE/'initializer-trials.json')
for i,record in enumerate(trial_records):
    assert record['owner']==i and record['identity']==identities[i];family=identities[i][0];expected_options=[]
    for mode in lib['family_modes'][family]:
        bb=mode['center_bounds_mm']
        for xi,yi in product(range(5),range(5)):
            xy=[bb[0][0]+xi/4*(bb[0][1]-bb[0][0]),bb[1][0]+yi/4*(bb[1][1]-bb[1][0])];shapes=own_shapes(family,mode['mode'],xy);energy=sum(sum(p.intersection(other[k]).area for other in placed) for k,p in enumerate(shapes));saved=record['candidates'][len(expected_options)];assert saved['mode']==mode['mode'] and saved['grid']==[xi,yi] and saved['center']==xy and abs(saved['score_mm2']-energy)<1e-7;expected_options.append(saved);trial_count+=1
    chosen=min(expected_options,key=lambda r:(r['score_mm2'],r['mode'],r['grid']));assert chosen==record['selected'] and chosen['mode']==modes[i] and chosen['center']==values[2*i:2*i+2].tolist();placed.append(own_shapes(family,modes[i],chosen['center']));trial_energy+=chosen['score_mm2']
assert trial_count==2400
rows=source_rows(model,values);source=audit(job,rows,stocks,required,guard,list(map(tuple,ids)));assert rows==load(BASE/'seed-source66.json') and source==load(BASE/'seed-source-checks.json') and source['pair_failures']==22 and source['stock_failures']==0;write(OUT/'seed-source-checks.json',source)
obj=Objective(model);energy,g,details=obj.evaluate(values,True);initial=load(BASE/'initial-objective.json');assert energy==initial['energy_mm2'] and g.tolist()==initial['gradient'] and details=={k:v for k,v in initial.items() if k not in ['energy_mm2','gradient']};assert abs(trial_energy-energy)<1e-7
vectors=1;mode_options=0;stock_controls=[]
for i,identity in enumerate(identities):
    for mode in lib['family_modes'][identity[0]]:
        changed=modes.copy();changed[i]=mode['mode'];mm=compile_model(lib,changed,values);assert verify(mm,lib,changed,values);mode_options+=1;vectors+=changed!=modes
        phases=[None] if identity[0]!='cog' else [-math.pi/3,0,math.pi/4]
        for phase in phases:
            for corner in product(*mm['bounds'][2*i:2*i+2]):
                x=np.asarray(mm['initial']);x[2*i:2*i+2]=corner
                if phase is not None:x[56+i-16]=radius*phase
                candidate=source_rows(mm,x)[38+i];check=audit(job,fixed+short+[candidate],stocks,required,guard);assert check['valid'];stock_controls.append({'owner':i,'mode':mode['mode'],'phase':phase,'minimum_gap_mm':check['minimum_pair_gap_mm'],'minimum_stock_mm':check['minimum_extra_stock_mm']})
assert mode_options==108 and vectors==81 and len(stock_controls)==528;write(OUT/'all-mode-stock-controls.json',stock_controls)
# Scalar and batched source gradients at the actual nonsmooth seed.
reference=np.zeros(68);gradient_cases=0
for shapes in obj.geometry(values):
    for i,j in lib['pairs']:
        if shapes[i][1].intersection(shapes[j][1]).area<=0:continue
        for own,other in [(i,j),(j,i)]:
            gg,_,_=moving_boundary_gradient(shapes[own][1],shapes[other][1],shapes[own][3]);reference[2*own:2*own+2]+=gg[:2]
            if own>=16:reference[56+own-16]+=gg[2]/radius
            gradient_cases+=1
assert np.max(np.abs(reference-g))<1e-7
def independent_energy(mm,x):
    shapes=[own_shapes(o['identity'][0],o['mode'],[x[2*i],x[2*i+1]],x[56+i-16]/radius if i>=16 else 0.) for i,o in enumerate(mm['owners'])];return sum(sum(shapes[i][k].intersection(shapes[j][k]).area for i,j in lib['pairs']) for k in [0,1])
derivatives=[];directions=[]
for phase in [0,1]:
    chosen=modes.copy()
    if phase:chosen[:16]=[(m+1)%len(lib['family_modes'][identities[i][0]]) for i,m in enumerate(chosen[:16])]
    mm=compile_model(lib,chosen,values);bb=np.asarray(mm['bounds']);point=np.asarray(mm['initial'])+.137*np.sin(np.arange(68)*2**.5+.2+phase);margin=.03+np.arange(68)*.00037;point=np.minimum(np.maximum(point,bb[:,0]+margin),bb[:,1]-margin);value,gg=Objective(mm).evaluate(point);assert abs(independent_energy(mm,point)-value)<1e-6;errors=[]
    for k in range(68):
        plus=point.copy();minus=point.copy();plus[k]+=1e-4;minus[k]-=1e-4;numeric=(independent_energy(mm,plus)-independent_energy(mm,minus))/2e-4;error=abs(numeric-gg[k]);assert error<.01+3e-6*abs(gg[k]),(phase,k,numeric,gg[k],error);errors.append(float(error))
    derivatives.append({'phase':phase,'coordinates':68,'maximum_error':max(errors)})
for step in [1e-7,1e-6,1e-5]:
    bb=np.asarray(model['bounds']);candidate=np.clip(values-step*g,bb[:,0],bb[:,1]);after=independent_energy(model,candidate);assert after<energy;directions.append({'step':step,'before':energy,'after':after,'strictly_decreases':True})
write(OUT/'derivative-controls.json',derivatives);write(OUT/'seed-directional-controls.json',directions)
negatives=[]
for kind in ['mode_angle','mirror','source_pivot','angle_coupling','stock','pair','coordinate']:
    mm=copy.deepcopy(model)
    if kind=='mode_angle':mm['owners'][0]['rotation_radians']+=.01
    elif kind=='mirror':mm['owners'][0]['mirrored']=not mm['owners'][0]['mirrored']
    elif kind=='source_pivot':mm['owners'][0]['source_center'][0]+=1
    elif kind=='angle_coupling':mm['owners'][16]['angle_coordinate']=57
    elif kind=='stock':mm['bounds'][0][0]+=1
    elif kind=='pair':mm['pairs'][0]=mm['pairs'][0][::-1]
    else:mm['initial'][0]+=1
    caught=False
    try:verify(mm,lib,modes,values)
    except AssertionError:caught=True
    assert caught;negatives.append({'corruption':kind,'rejected':True})
write(OUT/'negative-controls.json',negatives)
oldtool=ROOT/'output/h5-mixed-mode-union-20261107/audit';controls=load(oldtool/'optimizer-controls.json');provenance=load(oldtool/'tool-provenance.json');assert controls['passed']
for name,r in provenance['tool_files'].items():assert digest(ROOT/name)==r['sha256']
write(OUT/'optimizer-controls.json',{'passed':True,'method':'L-BFGS-B','options':controls['options'],'source_optimizer_calls':0,'synthetic_tool_controls_previously_verified':True});write(OUT/'tool-provenance.json',provenance)
failure=load(ROOT/'output/h5-mixed-direct-preparation-process-20261107/prepare.json');success=load(ROOT/'output/h5-mixed-direct-preparation-v2-process-20261107/prepare.json');assert not failure['passed'] and success['passed'] and failure['job']['closed'] and success['job']['closed'] and load(BASE/'plan.json')['previous_failed_preparation_seconds_charged']==failure['complete_seconds'];charge=failure['complete_seconds']+success['complete_seconds']
inputs=[Path(__file__),JOB,BENCH/'results.json',ROOT/'output/h5_mixed_direct_pose_20261107.py',ROOT/'output/h5_mixed_direct_readback_20261107.py',ROOT/'output/h5_original_overlap_gradient_v2_20261107.py',ROOT/'output/h5_direct_pose_model_20261107.py',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5-mixed-direct-source-correction-20261107.json']+[BASE/n for n in ['plan.json','checks.json','library.json','initial-model.json','partitions.json','clearance-supports.json','benchmark-target.json','source-recipe.json','fixed29-source.json','fixed29-checks.json','short-analytic-phase.json','short-cog-derivation.json','short9-source.json','short-00-checks.json','cog-source-seed.json','initializer-trials.json','seed-source66.json','seed-source-checks.json','initial-objective.json']]+[ROOT/'output'/n/'prepare.json' for n in ['h5-mixed-direct-preparation-process-20261107','h5-mixed-direct-preparation-v2-process-20261107']]+[oldtool/n for n in ['optimizer-controls.json','tool-provenance.json']]+[BENCH/r['archive'] for r in normals]+[OLD/f'short-{i:02d}-{suffix}.json' for i in range(4) for suffix in ['source','checks']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Verify unchanged normalbenchmark target from3originalarchives;fresh exact sourcepartitions and9344clearance supports;independently reconstructfixed29 andshort9. Derive toothphase fromoriginalradii,then compute441exactrational NFP rowsections and validate short9. Preserve4failedphase sourcecontrols andallfailedcost. Replay2400initializer scores/selections,all108owner-mode bindings and81vectors,528stock/sourcecontrols,136centralderivatives,3actualseeddescentsteps and7corruptions. No historicalsourcecandidate/mode/geometrydata is used toinitialize. Nooptimizeropened.'})
checks={'passed':True,'seconds':time.perf_counter()-started,'normal_archives_verified':3,'normal_material_target_mm2':target,'exact_source_partitions':partition_counts,'exact_clearance_supports':support_count,'minimum_certified_local_gap_mm':min_gap,'exact_short_cog_piece_pair_sections':441,'short_source_valid':True,'failed_phase_cases_preserved':4,'initializer_candidates_verified':trial_count,'owner_mode_bindings':mode_options,'dynamic_mode_vectors':vectors,'source_stock_corner_controls':len(stock_controls),'scalar_batched_gradient_comparisons':gradient_cases,'independent_central_controls':136,'seed_directional_controls':3,'negative_controls':7,'initial_objective_mm2':energy,'seed_source_pair_failures':22,'seed_source_stock_failures':0,'complete_failed_and_corrected_preparation_seconds':charge,'library_sha256':digest(BASE/'library.json'),'initial_model_sha256':digest(BASE/'initial-model.json'),'source_valid66':False,'optimizer_calls':0,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
