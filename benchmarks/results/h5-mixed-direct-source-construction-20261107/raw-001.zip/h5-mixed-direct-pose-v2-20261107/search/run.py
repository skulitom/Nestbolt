"""One bounded source-only mixed-mode and continuous-angle pipeline."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time,sys,os,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=BASE/'search';PY=ROOT/'.cache/shop-venv/Scripts/python.exe';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')

def child(started):
    import numpy as np,scipy
    from scipy.optimize import minimize
    from h5_mixed_direct_pose_20261107 import compile_model,Objective,source_rows
    from h5_mixed_direct_readback_20261107 import verify
    from h5_mixed_direct_score_20261107 import score
    from h5_legacy64_source_readback import audit
    assert scipy.__version__=='1.17.1';plan=load(OUT/'plan.json');checked=load(BASE/'audit/checks.json');assert checked['passed'] and load(BASE/'score-audit/checks.json')['passed']
    for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
    for name,r in load(BASE/'audit/tool-provenance.json')['tool_files'].items():assert digest(ROOT/name)==r['sha256'],name
    assert digest(BASE/'library.json')==checked['library_sha256'];lib=load(BASE/'library.json');lib_bytes=json.dumps(lib,sort_keys=True);options=load(BASE/'audit/optimizer-controls.json')['options'];job=load(JOB);ids=list(map(tuple,lib['all66_identities']));modes=lib['initial_modes'].copy();values=np.array(lib['initial_values']);visited=set();summaries=[];trials_total=0;calls=0;valid=False;stop='MAXIMUM_OPTIMIZER_CALLS'
    for round_index in range(plan['maximum_optimizer_calls']):
        if time.perf_counter()-started>=56:stop='ALGORITHM_TIME_STOP_BEFORE_ROUND';break
        folder=OUT/f'round-{round_index:02d}';folder.mkdir();(folder/'incumbents').mkdir();incoming_modes=modes.copy();incoming_values=values.copy();current=compile_model(lib,modes,values);assert verify(current,lib,modes,values);current_score=score(current,current['initial']);write(folder/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'modes':modes,'values':values.tolist(),'objective_mm2':current_score,'previously_optimized_modes':[list(v) for v in sorted(visited)],'algorithm_seconds_including_preparation':time.perf_counter()-started})
        if round_index:
            trials=[];skipped=[];best=None;complete=True
            for i,identity in enumerate(lib['identities'][:16]):
                for alternative in lib['family_modes'][identity[0]]:
                    new=alternative['mode']
                    if new==modes[i]:continue
                    candidate=modes.copy();candidate[i]=new
                    if tuple(candidate) in visited:skipped.append({'owner':i,'mode':new,'reason':'already_optimized_mode_vector'});continue
                    if time.perf_counter()-started>=56:complete=False;break
                    mm=compile_model(lib,candidate,values);assert verify(mm,lib,candidate,values);value=score(mm,mm['initial']);changed=[k for k in range(68) if mm['initial'][k]!=values[k]];assert all(k//2==i for k in changed);trial={'sequence':len(trials),'owner':i,'identity':identity,'mode':new,'modes':candidate,'objective_mm2':value,'decrease_mm2':current_score-value,'clamped_coordinates':{str(k):mm['initial'][k] for k in changed},'dynamic_readback_passed':True};trials.append(trial);trials_total+=1;key=(value,identity[0],identity[1],new)
                    if current_score-value>1e-6 and (best is None or key<best[0]):best=(key,trial,mm)
                if not complete:break
            write(folder/'mode-trials.json',{'complete':complete,'evaluated':trials,'skipped':skipped,'strict_improvement_threshold_mm2':1e-6})
            if not complete:stop='ALGORITHM_TIME_STOP_DURING_MODE_ENUMERATION';break
            if best is None:stop='NO_IMPROVING_UNVISITED_MODE_VECTOR';break
            _,selected,model=best;write(folder/'selected-mode.json',selected);modes=selected['modes'];assert verify(model,lib,modes,values)
        else:model=current
        assert tuple(modes) not in visited;write(folder/'model.json',model);assert load(folder/'model.json')==model and verify(load(folder/'model.json'),lib,modes,incoming_values);values=np.asarray(model['initial']);objective=Objective(model);energy,gradient=objective.evaluate(values);assert abs(energy-score(model,values))<1e-7;bounds=np.asarray(model['bounds']);remaining=min(plan['maximum_one_optimizer_seconds'],56-(time.perf_counter()-started))
        if remaining<=0:stop='ALGORITHM_TIME_STOP_BEFORE_CALL';break
        state={'evaluations':0,'best':energy,'values':values.copy(),'gradient':gradient.copy(),'incumbents':1};write(folder/'incumbents/00000.json',{'sequence':0,'evaluation':0,'objective_mm2':energy,'values':values.tolist(),'gradient':gradient.tolist(),'algorithm_seconds_including_preparation':time.perf_counter()-started})
        class Deadline(Exception):pass
        def function(x):
            if time.perf_counter()>=deadline:raise Deadline()
            value,g=objective.evaluate(x);state['evaluations']+=1
            if value<state['best']:
                state.update(best=value,values=x.copy(),gradient=g.copy());write(folder/'incumbents'/f'{state["incumbents"]:05d}.json',{'sequence':state['incumbents'],'evaluation':state['evaluations'],'objective_mm2':value,'values':x.tolist(),'gradient':g.tolist(),'algorithm_seconds_including_preparation':time.perf_counter()-started});state['incumbents']+=1
            return value,g
        def callback(x):
            if state['best']<=1e-16:raise StopIteration()
        write(folder/'optimizer-opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'method':'L-BFGS-B','options':options,'analytic_jacobian':True,'shared_boundary_convention':'symmetric half weight;directional checks passed;no global convergence claim','parameters':68,'allocated_optimizer_seconds':remaining,'modes':modes,'never_previously_optimized':True,'maximum_calls_for_this_vector':1,'retry_permitted':False,'model_sha256':digest(folder/'model.json'),'algorithm_seconds_including_preparation_at_open':time.perf_counter()-started});visited.add(tuple(modes));calls+=1;before=time.perf_counter();deadline=before+remaining;numerical=None
        try:
            result=minimize(function,values.copy(),jac=True,bounds=bounds,method='L-BFGS-B',callback=callback,options=options);status='RETURNED';numerical={'success':bool(result.success),'status':int(result.status),'message':str(result.message),'iterations':int(result.nit),'function_evaluations':int(result.nfev),'gradient_evaluations':int(result.njev),'objective_mm2':float(result.fun),'values':result.x.tolist(),'gradient':result.jac.tolist()}
        except Deadline:status='TIME_STOP'
        elapsed=time.perf_counter()-before;values=state['values'];value,g,details=objective.evaluate(values,True);assert value==state['best'] and np.array_equal(g,state['gradient']) and np.all(values>=bounds[:,0]) and np.all(values<=bounds[:,1]);assert json.dumps(lib,sort_keys=True)==lib_bytes
        write(folder/'response.json',{'closed':True,'optimizer_calls':1,'status':status,'numerical_result':numerical,'allocated_optimizer_seconds':remaining,'returned_optimizer_seconds':elapsed,'optimizer_slice_overrun_seconds':max(0.,elapsed-remaining),'evaluations':state['evaluations'],'incumbents':state['incumbents'],'best_objective_mm2':value,'best_values':values.tolist(),'best_gradient':g.tolist(),'best_details':details,'modes':modes,'algorithm_seconds_including_preparation':time.perf_counter()-started})
        rows=source_rows(model,values);write(folder/'candidate-source66.json',rows);before=time.perf_counter();source=audit(job,rows,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm'],ids);source_seconds=time.perf_counter()-before;assert source['originals']==66 and source['same_sheet_pairs']==1632 and source['stock_edges']==264 and source['cutouts']==90 and source['hole_vertices']==10026;write(folder/'original-source-checks.json',source);valid=source['valid'];summary={'round':round_index,'modes':modes,'optimizer_status':status,'objective_before_call_mm2':energy,'best_objective_mm2':value,'original_overlap_area_mm2':details['original_overlap_area_mm2'],'source_valid66':valid,'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'source_checker_seconds':source_seconds,'algorithm_seconds_including_preparation':time.perf_counter()-started};write(folder/'result.json',summary);summaries.append(summary);print(summary,flush=True)
        if valid:stop='SOURCE_VALID_CANDIDATE';break
        if time.perf_counter()-started>=56:stop='ALGORITHM_TIME_STOP_AFTER_SOURCE_CHECK';break
    elapsed=time.perf_counter()-started;write(OUT/'result.json',{'closed':True,'status':stop,'optimizer_calls':calls,'source_checker_calls':len(summaries),'mode_trials':trials_total,'rounds':summaries,'final_modes':modes,'final_values':values.tolist(),'source_valid66':valid,'algorithm_seconds_including_preparation':elapsed,'algorithm_overrun_seconds':max(0.,elapsed-60),'native_calls':0,'any_allocation_excluded':False,'H5_complete':False,'retry_permitted':False});print(load(OUT/'result.json'))

def main():
    assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'score-audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');charges={'complete_failed_source_preparation':load(ROOT/'output/h5-mixed-direct-preparation-process-20261107/prepare.json')['complete_seconds'],'complete_corrected_source_preparation':load(ROOT/'output/h5-mixed-direct-preparation-v2-process-20261107/prepare.json')['complete_seconds']};charge=sum(charges.values());started=time.perf_counter()-charge;write(OUT/'preparation-charges.json',charges)
    files=[Path(__file__),JOB]+[ROOT/'output'/n for n in ['h5_mixed_direct_pose_20261107.py','h5_mixed_direct_readback_20261107.py','h5_mixed_direct_score_20261107.py','h5_direct_pose_model_20261107.py','h5_legacy64_source_readback.py','h5-mixed-direct-preparation-process-20261107/prepare.json','h5-mixed-direct-preparation-v2-process-20261107/prepare.json']]+[BASE/n for n in ['plan.json','library.json','audit/plan.json','audit/checks.json','audit/optimizer-controls.json','audit/tool-provenance.json','score-audit/checks.json']]
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in files},'preparation_seconds_charged':charge,'algorithm_seconds':60,'shared_seconds':90,'source_check_reserve_seconds':4,'memory_bytes':2**31,'maximum_optimizer_calls':4,'maximum_one_optimizer_seconds':10,'restarts':0,'retry_permitted':False,'blas_threads':1,'strict_mode_improvement_mm2':1e-6,'tie_order':['objective_mm2','part_id','copy_index','mode'],'visited_definition':'Every complete discrete vector that has opened a continuous call. A vector can be optimized only once, including the source-only initial vector. Unselected alternatives may be scored at changed coordinates.','method':'Genuinely broader legal bracket/insert modes plus12continuous cogangles fromsource-only initialization. First optimize the initial vector once;then score all80single-owner alternatives (skipping visitedvectors),clamp onlychangedowner and choose strictbest. Full scalar/vector scoring controls and per-model independent dynamicreadback required. At most4calls,10s percall. After each best response independently checkall66originals. A percall time stop never permits itsrepeat;onlya strictlyimproving unvisitedmode canopenthe nextcall. Stop atvalidity,firstnoimprovement,callcap orbudget. No restart,reseed,extension or allocationexclusion. Failedpreparation plusallfreshpreparation/runtime charged.'})
    controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE);cap=max(1,int((90-(time.perf_counter()-started))*1000));write(OUT/'supervisor-opened.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),EXE,EXE.parent/'checks.json']},'maximum_ms':cap,'memory_bytes':2**31,'preparation_seconds_charged':charge,'retry_permitted':False});env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    r=subprocess.run([str(EXE),str(cap),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(Path(__file__)),'--child',str(started)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=cap/1000+8,env=env);(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');assert job['closed'] and job['active_processes']==0;write(OUT/'process.json',{'closed':True,'seconds_including_preparation':time.perf_counter()-started,'exit_code':r.returncode,'job':job,'tree_closed':True,'repeat_permitted':False});print(load(OUT/'process.json'));print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed result;pipeline stays closed.')
if __name__=='__main__':
    if '--child' in sys.argv:child(float(sys.argv[2]))
    else:main()
