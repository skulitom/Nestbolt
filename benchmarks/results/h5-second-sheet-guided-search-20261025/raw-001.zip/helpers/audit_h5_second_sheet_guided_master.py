"""Verify all new pair exclusions and advisory hints on the unchanged full master."""
from itertools import combinations
from ortools.sat import cp_model_pb2
from audit_h5_original_core_master import verify as verify_previous

def verify(actual,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional,atlas,mutual,added,new_pairs,witness):
    assert new_pairs['query']==19 and len(new_pairs['domain_row_pairs'])==10
    prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(actual)
    del prefix.constraints[-150:];prefix.ClearField('solution_hint')
    mapping,stats=verify_previous(prefix,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional,atlas,mutual,added)
    ci=len(prefix.constraints)
    for i,j in combinations(regional['applicable_cog_parts'],2):
        a=next(m for m in mapping['parts'][i]['modes'] if m['query']==19)
        b=next(m for m in mapping['parts'][j]['modes'] if m['query']==19)
        for ra,rb in new_pairs['domain_row_pairs']:
            p=cp_model_pb2.ConstraintProto();p.bool_or.literals.extend([-a['domains'][ra]-1,-b['domains'][rb]-1])
            assert actual.constraints[ci]==p;ci+=1
    assert ci==len(actual.constraints) and len(actual.variables)==len(prefix.variables)
    assert witness['domain_rows']==[1,1] and len(witness['positions'])==2
    hints=[]
    for target,source in zip([7,8],witness['positions']):
        assert spec['parts'][target]['family']=='cog' and spec['parts'][target]['profiles']==[9] and spec['parts'][target]['queries']==[18,19]
        assert source['query']==19 and source['profile']==9 and source['sheet']==1 and source['domain_row']==1
        p=mapping['parts'][target];q=next(m for m in p['modes'] if m['query']==19);first=next(m for m in p['modes'] if m['query']==18)
        xy=next(m for m in mapping['simultaneous_cog_coordinates'] if m['part']==target)
        choice=sum(len(m['domains']) for m in p['modes'][:p['modes'].index(q)])+1
        hints += [(p['sheet'],1),(first['active'],0),(q['active'],1),(q['domains'][1],1),(p['choice'],choice),(xy['x'],source['x_units']),(xy['y'],source['y_units'])]
    assert len(hints)==len({v for v,_ in hints})==14
    expected=cp_model_pb2.PartialVariableAssignment();expected.vars.extend(v for v,_ in hints);expected.values.extend(x for _,x in hints)
    assert actual.solution_hint==expected
    for v,value in hints:assert actual.variables[v].domain[0]<=value<=actual.variables[v].domain[-1]
    return mapping,{**stats,'constraints':ci,'new_exact_second_sheet_pair_clauses':150,'all15_physical_cog_pairs_covered_by_new_proofs':True,
        'hints':14,'hinted_cog_copies':[7,8],'hints_verified_from_original_geometry_witness':True,'hints_add_no_constraint_or_fixed_domain':True,
        'all66_originals_still_required':True}
