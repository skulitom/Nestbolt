"""Reconstruct inherited master, query-bounded anchors and every original cog piece."""
from itertools import combinations,product
from collections import Counter
from ortools.sat import cp_model_pb2
from audit_h5_added_guarded_pairs_master import verify as verify_base
def verify(actual,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional,atlas,mutual,added):
    cogs=regional['applicable_cog_parts'];assert len(cogs)==6 and atlas['profile']==9 and atlas['mutual_case']==81
    nplanes=sum(len(f['halfplanes']) for q in [18,19] for f in queries[q]['domains'])*6
    retained=[]
    for f,row in zip(mutual['faces'],atlas['faces']):
        assert f['index']==row['face'];always=False;possible=[]
        for i,h in enumerate(f['outside_halfplanes']):
            values=[h['a']*x+h['b']*y for r in atlas['same_sheet_difference_bounds'].values() for x,y in product([r[0],r[2]],[r[1],r[3]])]
            always|=min(values)>=h['bound']
            if max(values)>=h['bound']:possible.append(i)
        assert always==row['always_separated'] and row['possible_edges']==([] if always else possible)
        if not always:retained.append((f,possible))
    ndirs=15*sum(len(edges) for _,edges in retained);nvars=12+ndirs;nconstraints=nplanes+48+ndirs+30*len(retained)
    prefix=cp_model_pb2.CpModelProto();prefix.CopyFrom(actual);del prefix.variables[-nvars:];del prefix.constraints[-nconstraints:]
    mapping,stats=verify_base(prefix,spec,queries,census,groups,aux,orders,certificate,pairs,capacity,regional,added);vi=len(prefix.variables);ci=len(prefix.constraints);positions=[]
    def var(name,lo,hi):
        nonlocal vi
        assert actual.variables[vi]==cp_model_pb2.IntegerVariableProto(name=name,domain=[lo,hi]);vi+=1;return vi-1
    def linear(terms,lo,hi,en):
        nonlocal ci
        values=Counter()
        for v,c in terms:values[v]+=c
        ids=sorted(v for v,c in values.items() if c);p=cp_model_pb2.ConstraintProto();p.linear.vars.extend(ids);p.linear.coeffs.extend(values[v] for v in ids);p.linear.domain.extend([lo,hi]);p.enforcement_literal.extend(en)
        assert p==actual.constraints[ci];ci+=1
    allboxes=[f['coordinate_bounds'] for q in [18,19] for f in queries[q]['domains']];bounds=[min(b[k] for b in allboxes) if k<2 else max(b[k] for b in allboxes) for k in range(4)]
    for i in cogs:
        assert spec['parts'][i]['profiles']==[9] and spec['parts'][i]['queries']==[18,19]
        x=var(f'cog{i}-anchor-x',bounds[0],bounds[2]);y=var(f'cog{i}-anchor-y',bounds[1],bounds[3]);positions.append({'part':i,'x':x,'y':y})
        for m in mapping['parts'][i]['modes']:
            q=m['query'];ds=queries[q]['domains'];box=[min(f['coordinate_bounds'][k] for f in ds) if k<2 else max(f['coordinate_bounds'][k] for f in ds) for k in range(4)]
            assert atlas['query_anchor_bounds'][str(q)]==box and atlas['same_sheet_difference_bounds'][str(q)]==[box[0]-box[2],box[1]-box[3],box[2]-box[0],box[3]-box[1]]
            for v,lo,hi in [(x,box[0],box[2]),(y,box[1],box[3])]:
                linear([(v,1)],lo,2**63-1,[m['active']]);linear([(v,1)],-2**63,hi,[m['active']])
            for row,selector in enumerate(m['domains']):
                for h in ds[row]['halfplanes']:linear([(x,h['a']),(y,h['b'])],-2**63,h['bound'],[selector])
    for a,b in combinations(positions,2):
        i,j=a['part'],b['part'];sa,sb=mapping['parts'][i]['sheet'],mapping['parts'][j]['sheet']
        for f,edges in retained:
            dirs=[]
            for k in edges:
                h=f['outside_halfplanes'][k];d=var(f"cog-pair{i}-{j}-original-face{f['index']}-edge{k}",0,1);dirs.append(d)
                linear([(b['x'],h['a']),(a['x'],-h['a']),(b['y'],h['b']),(a['y'],-h['b'])],h['bound'],2**63-1,[d])
            for literals in [dirs+[sa,sb],dirs+[-sa-1,-sb-1]]:
                p=cp_model_pb2.ConstraintProto();p.bool_or.literals.extend(literals);assert actual.constraints[ci]==p;ci+=1
    assert vi==len(actual.variables) and ci==len(actual.constraints);mapping['simultaneous_cog_coordinates']=positions
    return mapping,{**stats,'variables':vi,'constraints':ci,'simultaneous_cog_anchor_variables':12,'conditional_inward_domain_halfplanes':nplanes,
        'explicit_selected_query_box_constraints':48,'complete_necessary_original_core_faces_per_pair':len(mutual['faces']),'retained_necessary_original_core_pieces_per_pair':len(retained),
        'necessary_original_core_direction_variables':ndirs,'same_sheet_original_piece_clauses':30*len(retained),'exact_integer_piece_and_direction_reductions_verified':True,
        'full_guarded_original_coordinates_for_all_parts_still_required':True}
