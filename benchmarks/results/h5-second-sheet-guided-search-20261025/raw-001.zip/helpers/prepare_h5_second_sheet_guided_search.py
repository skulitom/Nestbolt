"""Prepare a distinct complete master with certified pair clauses and optional hints."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'output'
OLD='output/h5-original-core-search-20261025/shared-search'
NEW='output/h5-second-sheet-guided-search-20261025/shared-search'
PAIR="ROOT/'output/h5-original-core-search-20261025/remaining-second-sheet-pairs'"
def save(name,s):
    with (R/name).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(R/'solve_h5_original_core_master.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace('from audit_h5_original_core_master import verify','from audit_h5_second_sheet_guided_master import verify')
needle="    pair_exclusions=load(PROOF/'certified-pair-exclusions.json');capacity=load(PROOF/'capacity-certificate.json')"
extra="    pairpath="+PAIR+";assert load(pairpath/'audit/checks.json')['passed'] and load(pairpath/'geometry-audit-repaired/checks.json')['passed'];new_pairs=load(pairpath/'audit/certified-new-exclusions.json');witness=load(pairpath/'audit/verified-pair-witnesses.json')[0]\n"
assert needle in s;s=s.replace(needle,extra+needle)
s=s.replace("ROOT/'output/audit_h5_original_core_master.py',","ROOT/'output/audit_h5_second_sheet_guided_master.py',pairpath/'audit/checks.json',pairpath/'geometry-audit-repaired/checks.json',pairpath/'audit/certified-new-exclusions.json',pairpath/'audit/verified-pair-witnesses.json',pairpath/'audit/complete-pair-classification.json',")
needle="    mapping={'parts':parts"
extra="""    for i,j in combinations(regional['applicable_cog_parts'],2):
        a=next(q for q in parts[i]['modes'] if q['query']==19);b=next(q for q in parts[j]['modes'] if q['query']==19)
        for ra,rb in new_pairs['domain_row_pairs']:model.add_bool_or([vs[a['domains'][ra]].Not(),vs[b['domains'][rb]].Not()])
    for target,source in zip([7,8],witness['positions']):
        p=parts[target];q=next(m for m in p['modes'] if m['query']==19);first=next(m for m in p['modes'] if m['query']==18)
        xy=next(m for m in cog_positions if m['part']==target);choice=sum(len(m['domains']) for m in p['modes'][:p['modes'].index(q)])+source['domain_row']
        for v,value in [(p['sheet'],1),(first['active'],0),(q['active'],1),(q['domains'][source['domain_row']],1),(p['choice'],choice),(xy['x'],source['x_units']),(xy['y'],source['y_units'])]:model.add_hint(vs[v],value)
"""
assert s.count(needle)==1;s=s.replace(needle,extra+needle)
s=s.replace('regional,atlas,mutual,added);','regional,atlas,mutual,added,new_pairs,witness);')
s=s.replace("'method':'Keep every", "'method':'Add the ten independently proved second-sheet pair exclusions across all fifteen cog pairings, and fourteen advisory values from the verified two-cog witness, mapped only to interchangeable final copies. Hints add no constraint and fix no placement; all other originals remain mandatory. This is a new model, not continuation or a seed change of a closed call. Keep every")
save('solve_h5_second_sheet_guided_master.py',s)
s=(R/'audit_h5_original_core_selection.py').read_text(encoding='utf-8').replace(OLD,NEW)
needle="    positions=load(NEW/'solve/necessary-cog-positions.json');"
extra="""    exact_pairs=load(ROOT/'output/h5-original-core-search-20261025/remaining-second-sheet-pairs/audit/certified-new-exclusions.json');exact_checks=0
    for a,b in combinations([p for p in parts if p['family']=='cog'],2):
        for rows in exact_pairs['domain_row_pairs']:
            assert not (a['query']==b['query']==19 and [a['domain_row'],b['domain_row']]==rows);exact_checks+=1
    assert exact_checks==150
    write(OUT/'new-exact-pairs-check.json',{'passed':True,'physical_clauses_checked':exact_checks})
"""
assert needle in s;s=s.replace(needle,extra+needle)
s=s.replace("    write(OUT/'plan.json',","    inputs.extend(["+PAIR+"/'audit/certified-new-exclusions.json',"+PAIR+"/'audit/checks.json'])\n    write(OUT/'plan.json',")
save('audit_h5_second_sheet_guided_selection.py',s)
s=(R/'solve_h5_original_core_anchors.py').read_text(encoding='utf-8').replace(OLD,NEW)
s=s.replace("inputs=[BASE/'selection-audit/new-guarded-pairs-check.json'","inputs=[BASE/'selection-audit/new-exact-pairs-check.json',BASE/'selection-audit/new-guarded-pairs-check.json'")
save('solve_h5_second_sheet_guided_anchors.py',s)
s=(R/'run_h5_original_core_search.py').read_text(encoding='utf-8')
s=s.replace("BASE=ROOT/'output/h5-original-core-search-20261025'","BASE=ROOT/'output/h5-second-sheet-guided-search-20261025';EVIDENCE=ROOT/'output/h5-original-core-search-20261025'")
s=s.replace("OUT.mkdir();","BASE.mkdir();OUT.mkdir();")
for name in ['solve_h5_original_core_master','audit_h5_original_core_selection','solve_h5_original_core_anchors']:s=s.replace(name,name.replace('original_core','second_sheet_guided'))
for path in ['audit/checks.json','atlas.json','added-pairs.json']:s=s.replace("BASE/'"+path+"'","EVIDENCE/'"+path+"'")
s=s.replace("'method':'One shared60-second pipeline.","'method':'New master includes all ten exact second-sheet pair exclusions and advisory hints from a verified original two-cog witness, with no fixed placements or omitted originals. One shared60-second pipeline.")
save('run_h5_second_sheet_guided_search.py',s)
print('Prepared distinct guided full-original search; no solver run yet.')
