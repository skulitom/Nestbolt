"""Record exact new model/hint inputs before one bounded construction test."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-alias-source-hints-20261025'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def main():
    source=ROOT/'output/solve_h5_compound_proxy.py';target=ROOT/'output/solve_h5_alias_source_hints.py';text=source.read_text(encoding='utf-8');changes=[
        ("BASE=ROOT/'output/h5-compound-cog-proxy-20261025'","BASE=ROOT/'output/h5-alias-source-hints-20261025'"),
        ('from h5_compound_proxy_encoding import build as build_propagation, verify as verify_propagation','from h5_compound_proxy_encoding import build as build_propagation, verify as verify_propagation\nfrom h5_verified_source_hints import build as build_hints, verify as verify_hints'),
        ("geo=load(BASE/'geometry.json');aux=load(BASE/'propagation.json');", "geo=load(BASE/'geometry.json');aux=load(BASE/'propagation.json');hints=load(BASE/'hint-poses.json');"),
        ("inputs=[BASE/'plan.json',BASE/'geometry.json',BASE/'propagation.json',BASE/'audit/checks.json',BASE/'solver-template-provenance.json']", "inputs=[BASE/'plan.json',BASE/'geometry.json',BASE/'propagation.json',BASE/'aliases.json',BASE/'source-poses.json',BASE/'hint-poses.json',BASE/'audit/checks.json',BASE/'solver-template-provenance.json']"),
        ("'hint':None", "'hint':{'source':(BASE/'hint-poses.json').relative_to(ROOT).as_posix(),'parts':len(hints),'binding':False}"),
        ("    assert model.validate()=='';assert model.export_to_file", "    hint_record=build_hints(model,vs,items,propagation,geo,aux,hints);write(OUT/'hint-construction.json',hint_record)\n    assert model.validate()=='';assert model.export_to_file"),
        ("extra.ClearField('constraints');assert not extra.ListFields();solver=cp_model.CpSolver()", "extra.ClearField('constraints');hint_audit=verify_hints(actual,geo,aux,hints,required);assert hint_audit==hint_record;write(OUT/'hint-audit.json',{'passed':True,**hint_audit});extra.ClearField('solution_hint');assert not extra.ListFields();solver=cp_model.CpSolver()"),
        ("    for n,v in parameters.items():setattr(solver.parameters,n,v)", "    for n,v in parameters.items():setattr(solver.parameters,n,v)\n    assert not solver.parameters.fix_variables_to_their_hinted_value"),
        ("'copy_order_constraints':62", "'copy_order_constraints':62,'hinted_parts':hint_audit['hinted_parts'],'hinted_variables':hint_audit['hinted_variables'],'hints_verified_independently_and_nonbinding':True,'original_mode_aliases_audited':True"),
        ("'interpretation':'All66 parts remain movable under original area bounds and complete inner-rectangle global propagation. Each cog has five coupled, disjoint inner rectangles; pairwise polygon disjunctions are omitted. A positive proxy outcome requires larger-polygon and original-outline diagnosis. No native or H5 qualification.'", "'interpretation':'All66 parts remain movable under the unchanged compound-proxy constraints after exact mode aliasing. Compatible source poses are nonbinding hints only; seven incompatible original poses are retained as omissions. The original source exceeds the target. A positive proxy outcome still requires original-outline/native diagnosis. No H5 qualification.'")]
    for a,b in changes:assert text.count(a)==1,(a,text.count(a));text=text.replace(a,b)
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
    shutil.copyfile(source,BASE/'model-template.py');shutil.copyfile(ROOT/'output/h5_verified_source_hints.py',BASE/'hint-encoding.py')
    with (BASE/'solver-template-provenance.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'template':source.relative_to(ROOT).as_posix(),'template_sha256':digest(source),'target_sha256':digest(target),'hint_helper_sha256':digest(ROOT/'output/h5_verified_source_hints.py'),'changes':[{'old':a,'new':b} for a,b in changes],'random_seed_time_limit_and_workers_unchanged':True,'all66_required_and_all_placements_free':True,'solver_calls':0},f,indent=2);f.write('\n')
    print({'target':str(target),'template_changes':len(changes),'sha256':digest(target)})
if __name__=='__main__':main()
