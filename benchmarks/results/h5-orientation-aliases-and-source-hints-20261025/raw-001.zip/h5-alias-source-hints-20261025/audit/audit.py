"""Independent mode equivalence, original source and nonbinding pose-hint audit."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations,product
from collections import Counter,defaultdict
import json,math,shutil,time
from shapely.geometry import Polygon,box
from shapely.affinity import affine_transform
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-alias-source-hints-20261025';OLD=ROOT/'output/h5-compound-cog-proxy-20261025';SRC=ROOT/'output/h5-coordinated-placement-selection-20261018';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();plan=load(BASE/'plan.json');g=load(BASE/'geometry.json');og=load(OLD/'geometry.json');aux=load(BASE/'propagation.json');aliases=load(BASE/'aliases.json')['aliases'];source=load(ROOT/plan['hint_source']);job=load(SRC/'job.json');target=load(SRC/'conditional-target.json');parts={p['id']:p for p in job['parts']};disk=load(ROOT/'output/h5-cog-center-capacity-20261020/disk.json');rows=load(BASE/'source-poses.json');hints=load(BASE/'hint-poses.json');provenance=[]
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    for manifest,paths in [(ROOT/'benchmarks/results/h5-global-propagation-and-compound-proxy-20261025/raw-manifest.json',[OLD/'geometry.json',OLD/'propagation.json',OLD/'audit/checks.json',OLD/'solve/result.json',SRC/'job.json',SRC/'conditional-target.json']),(ROOT/'benchmarks/results/h5-cog-lattices-20261018/raw-manifest.json',[ROOT/plan['hint_source']])]:
        mf=load(manifest);files=mf['files']+mf.get('aliases',[])
        for p in paths:
            matches=[r for r in files if r['sha256']==digest(p)];assert matches,p;provenance.append({'source':p.relative_to(ROOT).as_posix(),'sha256':digest(p),'manifest':manifest.relative_to(ROOT).as_posix(),'manifest_sha256':digest(manifest),'member':matches[0]['path']})
    assert digest(ROOT/plan['hint_source'])==target['layout_sha256'];assert load(OLD/'audit/checks.json')['passed'] and load(OLD/'solve/result.json')['status']=='UNKNOWN';assert digest(BASE/'propagation.json')==digest(OLD/'propagation.json');assert {k:v for k,v in g.items() if k!='modes'}=={k:v for k,v in og.items() if k!='modes'};assert len(aliases)==28 and len(g['modes'])==22;byold={r['original_mode']:r for r in aliases};bynew={m['index']:m for m in g['modes']};equivalence=0;inverse=defaultdict(list)
    for m in og['modes']:
        a=byold[m['index']];r=bynew[a['representative_mode']];c,d=og['classes'][m['class']],g['classes'][r['class']];assert m['family']==r['family'] and m['sheet']==r['sheet'] and m['coordinate_bounds']==r['coordinate_bounds'];assert c['components']==d['components'];assert c['width']==d['width'] and c['height']==d['height'];assert Polygon(c['polygon']).symmetric_difference(Polygon(d['polygon'])).area==0;assert a=={'original_mode':m['index'],'representative_mode':r['index'],'original_class':m['class'],'representative_class':r['class'],'sheet':m['sheet'],'family':m['family'],'original_zero_bounds_min':c['original_zero_bounds_min'],'representative_zero_bounds_min':d['original_zero_bounds_min']};inverse[r['index']].append(m['index']);equivalence+=1
    assert set(inverse)==set(bynew) and sorted(x for v in inverse.values() for x in v)==sorted(m['index'] for m in og['modes']);assert all(len(v)==(1 if bynew[k]['family']=='bracket' else 2) for k,v in inverse.items());assert Counter(m['family'] for m in g['modes'])=={'frame':2,'bracket':16,'insert':4};assert Counter(p['part_id'] for p in source['placements'])==Counter(plan['required_counts']) and len(rows)==66
    for family,n in plan['required_counts'].items():assert sorted(p['copy_index'] for p in source['placements'] if p['part_id']==family)==list(range(n))
    shapes=[];proxy=[];hintproxy=[];fullareas=[0,0];hintareas=[0,0];maxerr=0;stockviolations=[];stockbounds=[[float(F(*v)) for v in b] for b in g['stock_bounds_rational']];center=[float(F(*x)) for x in disk['center']];matrices=[(1,0,0,1),(0,-1,1,0),(-1,0,0,-1),(0,1,-1,0)];rowlookup={r['source_index']:r for r in rows}
    for idx,p in enumerate(source['placements']):
        r=rowlookup[idx];f=p['part_id'];t=p['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];sheet=int(p['sheet_id'][-1]);shape=affine_transform(Polygon(parts[f]['geometry'][0]['outer']),[mi*c,-s,mi*s,c,tx,ty]);shapes.append((sheet,shape));bounds=stockbounds[sheet];sb=shape.bounds;v=[{'axis':axis,'side':side,'overrun_mm':d} for axis,side,d in [('x','left',bounds[0]-sb[0]),('y','bottom',bounds[1]-sb[1]),('x','right',sb[2]-bounds[2]),('y','top',sb[3]-bounds[3])] if d>1e-7];reasons=['original_outline_outside_target'] if v else [];assert len(v)==len(r['target_violations']) and all(abs(vv['overrun_mm']-rr['overrun_mm'])<1e-9 and vv['axis']==rr['axis'] and vv['side']==rr['side'] for vv,rr in zip(v,r['target_violations']));assert all(abs(a-b)<1e-9 for a,b in zip(sb,r['original_bounds_mm']))
        if v:stockviolations.append({'source_index':idx,'part_id':f,'copy_index':p['copy_index'],'violations':v})
        if f=='cog':
            assert not t['mirrored'] and parts[f]['rotations']=={'kind':'free'};anchor=[tx+c*center[0]-s*center[1],ty+s*center[0]+c*center[1]];boundsgrid=g['cog_center_bounds'][sheet];assert r['mode']==sheet and r['original_class'] is None and r['representative_class'] is None;rects=aux['cog_inner_components']
        else:
            k=round(t['rotation_radians']*2/math.pi)%4;assert abs(math.remainder(t['rotation_radians']-k*math.pi/2,2*math.pi))<1e-12;assert not t['mirrored'] or parts[f]['allow_mirror'];a,b,d,e=matrices[k];pts=[(a*mi*x+b*y,d*mi*x+e*y) for x,y in parts[f]['geometry'][0]['outer']];localmin=[min(x for x,y in pts),min(y for x,y in pts)];anchor=[tx+localmin[0],ty+localmin[1]];cl=next(z for z in og['classes'] if z['family']==f and z['quarter_turn']==k and z['mirrored']==t['mirrored']);assert cl['index']==r['original_class'];om=next((z for z in og['modes'] if z['class']==cl['index'] and z['sheet']==sheet),None)
            if om is None:assert r['mode'] is None and r['representative_class'] is None;boundsgrid=None;reasons.append('no_original_mode_on_source_sheet');rep=cl
            else:am=byold[om['index']];rep=g['classes'][am['representative_class']];assert r['mode']==am['representative_mode'] and r['representative_class']==rep['index'];boundsgrid=bynew[am['representative_mode']]['coordinate_bounds']
            normalized=Polygon([(tx+x,ty+y) for x,y in pts]);maxerr=max(maxerr,shape.hausdorff_distance(normalized));rects=aux['inner_non_cog_components'][rep['index']]['components']
        x,y=[math.floor(z*100) for z in anchor];assert (x,y)==(r['x_units'],r['y_units']);assert r['family']==f and r['sheet']==sheet and r['source_copy']==p['copy_index'];assert all(abs(a-b)<1e-7 for a,b in zip(shape.bounds,[sb[0],sb[1],sb[2],sb[3]]))
        if boundsgrid is not None and not(boundsgrid[0]<=x<=boundsgrid[2] and boundsgrid[1]<=y<=boundsgrid[3]):reasons.append('grid_anchor_outside_source_sheet_mode')
        assert r['omission_reasons']==reasons and r['eligible']==(not reasons);fullareas[sheet]+=aux['part_areas'][f]['lower_units']
        if r['eligible']:hintareas[sheet]+=aux['part_areas'][f]['lower_units']
        for arm,rr in enumerate(rects):
            boxcoords=[x+rr[0],y+rr[1],x+rr[2],y+rr[3]];rec={'source_index':idx,'family':f,'sheet':sheet,'arm':arm,'rectangle':boxcoords};proxy.append(rec)
            if r['eligible']:hintproxy.append(rec)
    assert maxerr<1e-9;assert hints==[r for r in rows if r['eligible']] and len(hints)==59;assert {(v['part_id'],v['copy_index']) for v in stockviolations}=={(v['part_id'],v['copy_index']) for v in target['crossing_parts']};assert len(stockviolations)==7
    original_pairs=0;min_gap=float('inf')
    for (sa,a),(sb,b) in combinations(shapes,2):
        if sa!=sb:continue
        gap=a.distance(b);assert gap>=job['clearance']-1e-7,(gap,original_pairs);min_gap=min(min_gap,gap);original_pairs+=1
    proxy_pairs=hintpairs=0
    for a,b in combinations(proxy,2):
        if a['sheet']!=b['sheet']:continue
        x,y=a['rectangle'],b['rectangle'];assert x[2]<=y[0] or y[2]<=x[0] or x[3]<=y[1] or y[3]<=x[1];proxy_pairs+=1
        if rowlookup[a['source_index']]['eligible'] and rowlookup[b['source_index']]['eligible']:hintpairs+=1
    for family,n in plan['required_counts'].items():
        rs=[r for r in rows if r['family']==family];assert [r['copy'] for r in rs]==list(range(n));assert [r['key'] for r in rs]==sorted(r['key'] for r in rs);assert all(r['key']==r['sheet']*150001*300001+r['y_units']*150001+r['x_units'] for r in rs)
    profiles=[]
    for sheet in [0,1]:
        assert hintareas[sheet]<=aux['sheet_capacities'][sheet]['upper_area_units']
        for axis in [0,1]:
            events=defaultdict(int)
            for p in hintproxy:
                if p['sheet']!=sheet:continue
                r=p['rectangle'];d=r[3-axis]-r[1-axis];events[r[axis]]+=d;events[r[axis+2]]-=d
            active=peak=0
            for z in sorted(events):active+=events[z];peak=max(peak,active);assert active>=0
            assert not active;capacity=aux['sheet_capacities'][sheet]['height_upper_coordinate_units' if axis==0 else 'width_upper_coordinate_units'];assert peak<=capacity;profiles.append({'sheet':sheet,'axis':axis,'peak':peak,'capacity':capacity})
    write(OUT/'provenance.json',{'source_members_matching_committed_evidence':provenance});write(OUT/'original-stock-violations.json',stockviolations);write(OUT/'hint-inner-rectangles.json',hintproxy);write(OUT/'hint-profiles.json',profiles);write(OUT/'inverse-mode-map.json',dict(inverse));write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'committed_input_matches':len(provenance),'original_modes_covered':equivalence,'representative_modes':len(bynew),'original_orientation_classes_retained':len(g['classes']),'bracket_modes_kept_distinct':16,'source_original_parts':66,'source_original_same_sheet_pairs':original_pairs,'source_minimum_original_pair_gap_mm':min_gap,'maximum_original_quarter_turn_error_mm':maxerr,'source_proxy_component_pairs_checked':proxy_pairs,'hint_parts':len(hints),'hint_inner_rectangles':len(hintproxy),'hint_component_pairs_checked':hintpairs,'omitted_parts':7,'original_area_units_by_sheet':fullareas,'hint_subset_area_units_by_sheet':hintareas,'hint_profile_checks':4,'all_copy_orders_match_full_source_sort':True,'hints_are_not_constraints':True,'full_original_source_meets_target':False,'full_target_witness':False,'H5_complete':False});print(load(OUT/'checks.json'),flush=True)
if __name__=='__main__':main()
