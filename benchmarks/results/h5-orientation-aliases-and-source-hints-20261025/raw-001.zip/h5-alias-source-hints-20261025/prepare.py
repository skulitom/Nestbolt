"""Exact mode aliases and audited-source-compatible nonbinding initial hints."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from fractions import Fraction as F
from collections import Counter
import json,math,shutil,time
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-compound-cog-proxy-20261025';OUT=ROOT/'output/h5-alias-source-hints-20261025';SRC=ROOT/'output/h5-coordinated-placement-selection-20261018';LAYOUT=ROOT/'output/h5-cog-lattices-20261018/original.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');plan=load(OLD/'plan.json');inputs=[OLD/n for n in ['plan.json','geometry.json','propagation.json','audit/checks.json','solve/result.json']]+[SRC/'job.json',SRC/'conditional-target.json',LAYOUT,ROOT/'output/h5-cog-center-capacity-20261020/disk.json',ROOT/'benchmarks/results/h5-cog-lattices-20261018/raw-manifest.json',ROOT/'benchmarks/results/h5-global-propagation-and-compound-proxy-20261025/raw-manifest.json',ROOT/'benchmarks/results/h5-global-propagation-and-compound-proxy-20261025/next-step.json'];plan.update({'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'The same all66 mandatory, all-movable compound proxy model, with exact equivalent orientation/sheet modes collapsed using identical ordered normalized rectangle components and identical stock bounds. Every original mode retains an alias and inverse reconstruction map. Add only compatible poses from the original66-part production layout as nonbinding coordinate/mode/component hints, sorted by full-source copy keys. Retain every omitted source pose and exact reason. No fixed placements, reduced inventory, changed target, objective, seed change or time increase. All original area and global propagation constraints remain.','scope':'One bounded data-informed construction test after exact equivalence and source geometry/provenance audits. Hints do not constrain the feasible region; all66 remain mandatory and every part can move. Original source exceeds target and is not an accepted layout. Positive proxy results require larger disks, original shapes/angles, native guards and full H5 validation. UNKNOWN stays unresolved.','hint_source':LAYOUT.relative_to(ROOT).as_posix(),'maximum_solver_calls':1});write(OUT/'plan.json',plan);start=time.perf_counter();g=load(OLD/'geometry.json');shutil.copyfile(OLD/'propagation.json',OUT/'propagation.json');classes=g['classes'];representatives={};aliases=[];kept=[]
    for m in g['modes']:
        c=classes[m['class']];signature=json.dumps([m['family'],m['sheet'],m['coordinate_bounds'],c['components']],separators=(',',':'))
        if signature not in representatives:representatives[signature]=m;kept.append(m)
        rep=representatives[signature];aliases.append({'original_mode':m['index'],'representative_mode':rep['index'],'original_class':m['class'],'representative_class':rep['class'],'sheet':m['sheet'],'family':m['family'],'original_zero_bounds_min':c['original_zero_bounds_min'],'representative_zero_bounds_min':classes[rep['class']]['original_zero_bounds_min']})
    original_modes=g['modes'];g['modes']=kept;write(OUT/'geometry.json',g);write(OUT/'aliases.json',{'original_mode_count':len(original_modes),'representative_mode_count':len(kept),'aliases':aliases,'reconstruction':'Use the same normalized anchor; for any chosen original class, translate by anchor minus that class original_zero_bounds_min and use its allowed quarter-turn/mirror. Its filled outer components occupy exactly the same normalized region. All source classes remain recorded, including their hole-bearing original part geometry; this equivalence concerns holes-reserved packing only.'})
    job=load(SRC/'job.json');parts={p['id']:p for p in job['parts']};source=load(LAYOUT);target=load(SRC/'conditional-target.json');assert digest(LAYOUT)==target['layout_sha256'];disk=load(ROOT/'output/h5-cog-center-capacity-20261020/disk.json');center=[float(F(*v)) for v in disk['center']];stockbounds=[[float(F(*v)) for v in b] for b in g['stock_bounds_rational']];rows=[];allshapes=[];maxerr=0
    for source_index,p in enumerate(source['placements']):
        family=p['part_id'];t=p['transform'];a=t['rotation_radians'];c,s=math.cos(a),math.sin(a);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation'];sheet=int(p['sheet_id'].split('-')[1]);pts=[(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in parts[family]['geometry'][0]['outer']];shape=Polygon(pts);allshapes.append(shape);reasons=[];bounds=stockbounds[sheet];sb=list(shape.bounds);violations=[{'axis':axis,'side':side,'overrun_mm':d} for axis,side,d in [('x','left',bounds[0]-sb[0]),('y','bottom',bounds[1]-sb[1]),('x','right',sb[2]-bounds[2]),('y','top',sb[3]-bounds[3])] if d>1e-7]
        if violations:reasons.append('original_outline_outside_target')
        oldclass=repclass=None;mode=None
        if family=='cog':xy=[mi*center[0]*c-center[1]*s+tx,mi*center[0]*s+center[1]*c+ty];mode=sheet;bb=g['cog_center_bounds'][sheet]
        else:
            k=round(a/(math.pi/2))%4;assert abs(math.remainder(a-k*math.pi/2,2*math.pi))<1e-12;oldclass=next(o['index'] for o in classes if o['family']==family and o['quarter_turn']==k and o['mirrored']==t['mirrored']);o=classes[oldclass];xy=[tx+o['original_zero_bounds_min'][0],ty+o['original_zero_bounds_min'][1]];original_mode=next((m for m in original_modes if m['class']==oldclass and m['sheet']==sheet),None)
            if original_mode is None:bb=None;reasons.append('no_original_mode_on_source_sheet')
            else:
                alias=next(r for r in aliases if r['original_mode']==original_mode['index']);mode=alias['representative_mode'];repclass=alias['representative_class'];bb=next(m['coordinate_bounds'] for m in kept if m['index']==mode)
            for actual,v in zip(pts,o['polygon']):maxerr=max(maxerr,math.hypot(actual[0]-(xy[0]+v[0]),actual[1]-(xy[1]+v[1])))
        x,y=[math.floor(v*100) for v in xy]
        if bb is not None and not (bb[0]<=x<=bb[2] and bb[1]<=y<=bb[3]):reasons.append('grid_anchor_outside_source_sheet_mode')
        rows.append({'source_index':source_index,'source_copy':p['copy_index'],'family':family,'sheet':sheet,'x_units':x,'y_units':y,'original_class':oldclass,'representative_class':repclass,'mode':mode,'original_bounds_mm':sb,'target_violations':violations,'eligible':not reasons,'omission_reasons':reasons})
    stride=150001*300001
    for family in ['frame','bracket','insert','cog']:
        familyrows=sorted([r for r in rows if r['family']==family],key=lambda r:(r['sheet'],r['y_units'],r['x_units'],r['source_index']))
        for copy,r in enumerate(familyrows):r['copy']=copy;r['key']=r['sheet']*stride+r['y_units']*150001+r['x_units']
    rows.sort(key=lambda r:(['frame','bracket','insert','cog'].index(r['family']),r['copy']));write(OUT/'source-poses.json',rows);write(OUT/'hint-poses.json',[r for r in rows if r['eligible']]);elapsed=time.perf_counter()-start;assert elapsed<120
    write(OUT/'generation.json',{'seconds':elapsed,'original_modes':len(original_modes),'representative_modes':len(kept),'original_counts':dict(Counter(r['family'] for r in rows)),'source_parts':len(rows),'hint_parts':sum(r['eligible'] for r in rows),'omitted_parts':sum(not r['eligible'] for r in rows),'maximum_exact_quarter_turn_error_mm':maxerr,'solver_calls':0,'H5_complete':False});print(load(OUT/'generation.json'),flush=True)
if __name__=='__main__':main()
