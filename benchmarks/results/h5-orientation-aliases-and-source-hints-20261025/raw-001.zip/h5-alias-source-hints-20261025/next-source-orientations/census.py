"""Record source-derived orientation counts for a different constructive model."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-alias-source-hints-20261025';OUT=BASE/'next-source-orientations';SOURCE=ROOT/'output/h5-latest-wide-joint-20261023/layout-audit/layout-final.json';MAN=ROOT/'benchmarks/results/h5-latest-wide-joint-progress-20261023/raw-manifest.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'census.py');jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';mf=load(MAN);matches=[r for r in mf['files']+mf.get('aliases',[]) if r['sha256']==digest(SOURCE)];assert matches;write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [SOURCE,MAN,jobpath]},'archive_member':matches[0]['path'],'scope':'Read-only census for a possible new finite constructive formulation. No solver call, added placements or acceptance. Keep two missing brackets mandatory and orientation-free in any subsequent model.'});job=load(jobpath);parts={p['id']:p for p in job['parts']};counts=Counter();groups=Counter()
    for p in load(SOURCE)['placements']:
        f=p['part_id'];counts[f]+=1
        if f=='cog':continue
        t=p['transform'];k=round(t['rotation_radians']*2/math.pi)%4;assert abs(math.remainder(t['rotation_radians']-k*math.pi/2,2*math.pi))<1e-12 and (not t['mirrored'] or parts[f]['allow_mirror']);assert k*90 in parts[f]['rotations']['degrees'];k=k%2 if f in ['frame','insert'] else k;groups[(f,k,t['mirrored'])]+=1
    assert counts=={'frame':18,'bracket':10,'insert':21,'cog':15};rows=[{'family':f,'normalized_quarter_turn':k,'mirrored':m,'quantity':n} for (f,k,m),n in sorted(groups.items())];write(OUT/'census.json',{'passed':True,'source_parts':64,'source_counts':dict(counts),'normalized_orientation_inventory':rows,'missing_original_brackets':2,'next_candidate_inventory_total':66,'additional_brackets_keep_all_original_orientations':True,'all_positions_and_allowed_sheets_remain_free':True,'copy_order_only_within_interchangeable_orientation_groups':True,'finite_constructive_subset_not_unrestricted_relaxation':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'census.json'),flush=True)
if __name__=='__main__':main()
