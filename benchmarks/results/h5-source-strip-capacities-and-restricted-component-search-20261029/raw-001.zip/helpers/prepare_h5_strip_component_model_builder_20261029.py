from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/build_h5_canonical_component_model_20261029.py').read_text(encoding='utf-8')
changes=[('h5-first55-canonical-components-model-20261029','h5-first55-strip-components-model-20261029'),("COUNT=ROOT/'output/h5-first55-vectorized-component-capacity-20261029'","COUNT=ROOT/'output/h5-first55-strip-filtered-components-20261029';GENERIC=ROOT/'output/h5-first55-vectorized-component-capacity-20261029';STRIP=ROOT/'output/h5-first55-component-strip-capacity-20261029'"),('all29-vectorized-bounds.json','all25-filtered-bounds.json'),('assert len(forbidden)==76','assert len(forbidden)==80'),("'generic_component_count_preparation_seconds':load(COUNT/'checks.json')['seconds']","'generic_component_count_preparation_seconds':load(GENERIC/'checks.json')['seconds'],'component_strip_bound_seconds':load(STRIP/'checks.json')['seconds'],'component_count_filter_seconds':load(COUNT/'checks.json')['seconds']"),("inputs=[Path(__file__),","inputs=[Path(__file__),GENERIC/'checks.json',STRIP/'plan.json',STRIP/'checks.json',STRIP/'audit/plan.json',STRIP/'audit/checks.json',"),('and29 audited surviving empty-site pairs, with all132','and25 audited surviving empty-site pairs, with all82'),("'retained_empty_site_pairs':29,'forbidden_site_pair_constraints':76","'retained_empty_site_pairs':25,'forbidden_site_pair_constraints':80")]
for a,b in changes:
    assert a in s,a;s=s.replace(a,b)
p=ROOT/'output/build_h5_strip_component_model_20261029.py';compile(s,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':p.name,'all_required_strip_construction_charged':True})
