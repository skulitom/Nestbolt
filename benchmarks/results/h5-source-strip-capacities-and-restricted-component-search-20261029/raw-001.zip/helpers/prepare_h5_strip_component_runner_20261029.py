from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('check_h5_canonical_component_candidate_20261029.py','check_h5_strip_component_candidate_20261029.py'),('run_h5_canonical_component_model_20261029.py','run_h5_strip_component_model_20261029.py')]:
    s=(ROOT/'output'/old).read_text(encoding='utf-8').replace('h5-first55-canonical-components-model-20261029','h5-first55-strip-components-model-20261029').replace('check_h5_canonical_component_candidate_20261029.py','check_h5_strip_component_candidate_20261029.py')
    p=ROOT/'output'/new;compile(s,str(p),'exec')
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print({'prepared':'run_h5_strip_component_model_20261029.py','maximum_new_calls':1})
