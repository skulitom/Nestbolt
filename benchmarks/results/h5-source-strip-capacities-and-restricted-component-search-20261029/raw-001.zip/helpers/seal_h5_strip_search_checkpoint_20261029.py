"""Seal exact axis-strip exclusions, preserved source counts and the closed placement call."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
STRIP=ROOT/'output/h5-first55-component-strip-capacity-20261029';FILTER=ROOT/'output/h5-first55-strip-filtered-components-20261029';BASE=ROOT/'output/h5-first55-strip-components-model-20261029';PUB=BASE/'publication';SHORT=ROOT/'output/h5-short11-integer-mode-regions-20261029'
NAME='h5-source-strip-capacities-and-restricted-component-search-20261029';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,v):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(v)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='1a3cf85e65090d8b3828ed6d7e741984cd1d732f' and not git('diff','HEAD','--name-only')
strip=load(STRIP/'audit/checks.json');assert strip['passed'] and strip['necessary_strip_certificates_verified']==24 and strip['count_distributions_excluded']==50 and strip['remaining_count_distributions']==82 and strip['restricted_pairs_remaining']==25 and strip['new_restricted_site_exclusions']==4 and strip['independent_polygon_clipping_operations']==1952
assert load(STRIP/'checks.json')['cap_overrun_seconds']==0 and load(STRIP/'checks.json')['scan_complete']
assert load(FILTER/'audit/checks.json')['passed'] and load(FILTER/'audit/checks.json')['all_source_mode_aliases_agree_on_component']
model=load(BASE/'model-audit/checks.json');assert model['passed'] and model['all_model_fields_exhaustively_verified'] and model['variables_verified']==8443 and model['constraints_verified']==44837 and model['canonical_relabelling_preserves_every_feasible_placement']
response=load(BASE/'response-audit/checks.json');assert response['passed'] and response['solver_status']=='UNKNOWN' and response['closed_solver_calls']==1 and response['assignments']==0 and response['source_checker_calls']==response['native_calls']==0 and response['solve_slice_overrun_seconds']>0 and response['overall_algorithm_shared_overruns_seconds']==0 and not response['infeasibility_proven'] and not response['any_allocation_excluded']
assert digest(SHORT/'search/source-response/candidate-source11.json')=='8b7fa5f6ad765aab6fdba1a586c29d8cac2cce607ed1d7fcd0fb6938c4eeada0'
assert digest(ROOT/'output/h5-oblique64-source-20261028/source64.json')=='bab709f97ac044ede2bcf8c40d75ba14162607c3c17c05bcacc1b4fa1614e9ee'
prior=load(ROOT/'benchmarks/results/h5-vectorized-capacities-and-canonical-component-search-20261029/publication-review.json');production=source_digest();readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert production==prior['production_digest'] and readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
assert [(r['tag_name'],r['prerelease'],r['draft']) for r in load(PUB/'nestbolt-releases.json')]==[('v0.2.0-alpha.1',True,False),('v0.1.0',False,False)]
ci=load(PUB/'main-ci.json');jobs=load(PUB/'main-ci-jobs.json')['jobs'];remote=load(PUB/'main.json')['commit']['sha'];assert remote==ci['head_sha']=='bd68c96727069582227ce5826453724ccc719bb4' and ci['id']==40836007698 and ci['status']=='completed' and ci['conclusion']=='success'
assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
frontier=ROOT/'benchmarks/results/h5-short12-exclusion-and-seven-part-readback-20261029/updated-allocations.json';assert sum(r['excluded_by'] is None for r in load(frontier))==440
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(name,path):
    assert path.is_file() and '.claude' not in path.parts
    members[name]=path
    if path.name in ['plan.json','opened.json'] or path.suffix=='.py':queue.append(path)
for folder in [STRIP,FILTER,BASE]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=set()
for pattern in ['*h5_component_strips*20261029.py','*h5_strip_component*20261029.py','*h5_strip_filtered*20261029.py','*h5_strip_search*20261029.py']:
    helpers.update((ROOT/'output').glob(pattern))
helpers.update(ROOT/'output'/n for n in ['pack_h5_evidence_archive.py','ccd1.py','push_h5_component_search_checkpoint_20261029.py','build_h5_canonical_component_model_20261029.py','audit_h5_canonical_component_model_20261029.py','run_h5_canonical_component_model_20261029.py','check_h5_canonical_component_candidate_20261029.py','audit_h5_canonical_component_response_20261029.py',Path(__file__).name])
for p in sorted(helpers):add('helpers/'+p.name,p)
add('publication/prior-push-pending.json',ROOT/'output/h5-component-search-push-pending-20261029.json')
while queue:
    path=queue.pop()
    if path in seen:continue
    seen.add(path)
    if path.name in ['plan.json','opened.json']:
        for name,h in load(path).get('inputs',{}).items():
            p=ROOT/name;assert p.is_relative_to(ROOT) and not {'.claude','.cache'}&set(p.parts) and digest(p)==h,name
            bindings[name]=h;add('source-inputs/'+name,p)
    elif path.suffix=='.py':
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    p=ROOT/folder/(module+'.py')
                    if p.is_file():add('imported-helpers/'+folder+'/'+p.name,p)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(STRIP/'checks.json','strip-preparation.json'),(STRIP/'audit/checks.json','strip-audit.json'),(STRIP/'all29-strip-bounds.json','all29-strip-bounds.json'),(STRIP/'audit/allowed-empty-site-pairs.json','allowed-empty-site-pairs.json'),(STRIP/'audit/excluded-empty-site-pairs.json','excluded-empty-site-pairs.json'),(FILTER/'checks.json','filtered-count-preparation.json'),(FILTER/'audit/checks.json','filtered-count-audit.json'),(BASE/'model/checks.json','model.json'),(BASE/'model-audit/checks.json','model-audit.json'),(BASE/'model/preparation-charges.json','preparation-charges.json'),(BASE/'response-audit/checks.json','response-audit.json'),(BASE/'response-audit/lp-diagnostics.txt','lp-diagnostics.txt'),(BASE/'next-step.json','next-step.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':remote,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'stable_release':'v0.1.0','preview_release':'v0.2.0-alpha.1','main_CI':40836007698,'main_all6_pass':True,'successful_jobs_at_snapshot':6,'normal_push_still_requires_fresh_head_and_live_run_checks':True,'unchanged_frontier_path':frontier.relative_to(ROOT).as_posix(),'unchanged_frontier_sha256':digest(frontier),'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'necessary_strip_certificates_verified':24,'source_hull_projection_intervals_verified':13880,'merged_projection_intervals_verified':1014,'independent_polygon_clipping_operations':1952,'count_distributions_excluded':50,'remaining_count_distributions':82,'new_restricted_site_exclusions':4,'restricted_site_pairs_remaining':25,'restricted_site_pairs_excluded_total':80,'only_independently_proved_count_exclusions_applied':True,'complete_model_audit_passed':True,'closed_new_solver_calls':1,'solver_status':'UNKNOWN','assignments':0,'solve_slice_overrun_seconds':response['solve_slice_overrun_seconds'],'overall_algorithm_shared_overruns_seconds':0,'source_checker_calls':0,'native_calls':0,'infeasibility_proven':False,'new_allocation_exclusions':0,'remaining_candidates':440,'source_valid_short11_preserved':True,'valid64_preserved':True,'source_valid66_created':False,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=(BASE/'report-template.md').read_text(encoding='utf-8').format(name=NAME,files=archive['archive_members'],aliases=archive['verified_aliases'],bytes=archive['archive_bytes'])
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note=(BASE/'docs-note-template.md').read_text(encoding='utf-8')
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/name,note.format(link=('' if name=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
status=ROOT/'docs/STATUS.md';s=status.read_text(encoding='utf-8');old='Latest H5 evidence: [vectorized capacities and canonical component search](../benchmarks/results/h5-vectorized-capacities-and-canonical-component-search-20261029.md).';new=f'Latest H5 evidence: [source-strip capacities and restricted component search](../benchmarks/results/{NAME}.md).';assert s.count(old)==1
with status.open('w',encoding='utf-8',newline='\n') as f:f.write(s.replace(old,new,1))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'closed_calls':1,'new_restricted_site_exclusions':4,'remaining_count_distributions':82,'restricted_site_pairs_remaining':25,'remaining_allocations':440,'completion_percent':60})
