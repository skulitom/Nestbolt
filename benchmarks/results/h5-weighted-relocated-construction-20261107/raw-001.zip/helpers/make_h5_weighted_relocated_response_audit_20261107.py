"""Version complete response replay for finite conditional relocation choices."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_weighted_mixed_rows_response_20261107.py').read_text(encoding='utf-8')
s=s.replace('from h5_weighted_original_model_20261107 import compile_model,Objective','from h5_cross_pair_weighted_model_20261107 import compile_model,Objective\nfrom h5_relocated_selection_readback_20261107 import verify_selection')
s=s.replace("BASE=ROOT/'output/h5-weighted-mixed-rows-model-20261107';S=BASE/'search'", "BASE=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107';S=BASE/'search'")
s=s.replace("load(BASE/'library.json')","load(W/'library.json')").replace("load(BASE/'initial-state.json')","load(BASE/'selected-state.json')").replace("load(BASE/'audit-v2/optimizer-controls.json')","load(W/'audit-v2/optimizer-controls.json')")
s=s.replace('visited=set();points=evals=trials_total=calls=updates=0',"old_closed={r['key'] for r in load(BASE/'closed-weighted-problems.json')};visited=set(old_closed);center_total=0;points=evals=trials_total=calls=updates=0")
s=s.replace("[BASE/n for n in ['plan.json','library.json','initial-state.json','initial-objective.json','audit-v2/plan.json','audit-v2/checks.json','audit-v2/optimizer-controls.json','audit-v2/tool-provenance.json']]", "[BASE/n for n in ['plan.json','plan-v2.json','selected-state.json','selected-model.json','closed-weighted-problems.json','audit-v2/plan.json','audit-v2/checks.json']]+[W/n for n in ['library.json','audit-v2/optimizer-controls.json','audit-v2/tool-provenance.json']]+[ROOT/'output/h5_relocated_selection_readback_20261107.py']")
a=s.index('        choices=[modes.copy()]');b=s.index('    else:model=compile_model',a)
s=s[:a]+'''        records=load(folder/'neighbors.json');aliases=load(folder/'owner-aliases.json');centers=load(folder/'center-trials.json');selections=load(folder/'center-selections.json');selection=verify_selection(lib,modes,incoming,weights,classes,visited,records,aliases,centers,selections,OUT/f'epoch-{epoch:02d}-selection')
        assert selection==load(folder/'selection.json');trials_total+=len(records);center_total+=len(centers);inputs+=[folder/n for n in ['neighbors.json','owner-aliases.json','center-trials.json','center-selections.json','selection.json']]
        if result['status']=='TIME_STOP_AFTER_SELECTION' and not (folder/'optimizer-opened.json').exists():assert result['algorithm_seconds_including_preparation']>=56;break
        if not selection['joint_improves_current_and_single']:assert result['status']=='NO_IMPROVING_JOINT_RELOCATION' and not (folder/'optimizer-opened.json').exists();break
        selected=selection['best_joint'];assert selected==load(folder/'selected-mode.json');modes=selected['modes'];incoming=incoming.copy()
        for (i,mi),center in zip(selected['changes'],selected['centers']):incoming[2*i:2*i+2]=center
        model=compile_model(lib,modes,incoming,weights);inputs.append(folder/'selected-mode.json')
''' +s[b:]
s=s.replace("calls==result['optimizer_calls']==result['unique_weighted_problems']==len(visited)<=4", "calls==result['optimizer_calls']==result['unique_weighted_problems']==len(visited)-len(old_closed)<=3 and center_total==result['center_trials'] and result['historical_closed_keys']==len(old_closed)==4")
s=s.replace("'TIME_STOP_DURING_MODE_SELECTION'", "'TIME_STOP_AFTER_SELECTION'").replace("'NO_NEW_WEIGHTED_PROBLEM'", "'NO_IMPROVING_JOINT_RELOCATION'")
s=s.replace("if result['status']=='MAXIMUM_EPOCHS':assert calls==4", "if result['status']=='MAXIMUM_EPOCHS':assert calls==3")
s=s.replace("'unique_weighted_problems':len(visited)", "'unique_weighted_problems':len(visited)-len(old_closed),'historical_closed_keys':len(old_closed),'runtime_center_trials_verified':center_total")
s=s.replace("every distinct physical/coefficient mode proposal", "every nominal grid/control center trial and distinct one/two-owner physical/coefficient proposal")
with (ROOT/'output/audit_h5_weighted_relocated_response_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
wrapper=(ROOT/'output/run_h5_weighted_relocated_neighbors_preparation_20261107.py').read_text(encoding='utf-8').replace('h5-weighted-relocated-neighbors-preparation-process-20261107','h5-weighted-relocated-response-audit-process-20261107').replace('prepare_h5_weighted_relocated_neighbors_20261107.py','audit_h5_weighted_relocated_response_20261107.py').replace('CAP=20','CAP=600')
with (ROOT/'output/run_h5_weighted_relocated_response_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(wrapper)
