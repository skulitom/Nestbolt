"""Independent full pair vectors and exact-product bounds around score ties."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,time
import numpy as np
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107';OUT=BASE/'rounding-diagnostic'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();lib=load(W/'library.json');state=load(W/'initial-state.json');modes=state['modes'];point=state['values'];weights=state['pair_weights'];trials=load(BASE/'center-trials.json');selections=load(BASE/'center-selections.json');records=[];differences=[];source_files=[Path(__file__),BASE/'plan.json',BASE/'center-trials.json',BASE/'center-selections.json',BASE/'selected-model.json',BASE/'selected-state.json',W/'library.json',W/'initial-state.json',ROOT/'output/h5-weighted-relocated-neighbors-audit-process-20261107/process.json',ROOT/'output/h5-weighted-relocated-neighbors-audit-process-20261107/stderr.txt']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in source_files},'method':'For every owner-mode select all recorded centers within1e-6mm2 of its lowest score. Independently transform all33original/clearance polygons and reconstruct all528pair losses. Compare declared NumPy dot ordering, sequential Python sum and the exact rational sum of products of binary64 weights/losses. This diagnoses ranking only; no trial, center, model, tolerance or optimizer changes.','near_best_window_mm2':1e-6,'optimizer_calls':0})
def loss_vector(chosen,x):
    ps=[]
    for i,(family,_) in enumerate(lib['identities']):
        mode=lib['family_modes'][family][chosen[i]];angle=x[66+i-18]/lib['angle_scale_mm'] if i>=18 else mode['rotation_radians'];c,s=math.cos(angle),math.sin(angle);sign=-1 if mode['mirrored'] else 1;cx,cy=lib['families'][family]['source_center'];tx=x[2*i]-(sign*cx*c-cy*s);ty=x[2*i+1]-(sign*cx*s+cy*c);ps.append([Polygon([(sign*a*c-b*s+tx,sign*a*s+b*c+ty) for a,b in lib['families'][family][kind]]) for kind in ['original','clearance']])
    return [sum(ps[i][k].intersection(ps[j][k]).area for k in [0,1]) for i,j in combinations(range(33),2)]
for selection in selections:
    owner,mode=selection['owner'],selection['mode'];group=[r for r in trials if r['owner']==owner and r['mode']==mode];minimum=min(r['weighted_objective_mm2'] for r in group);near=[r for r in group if r['weighted_objective_mm2']<=minimum+1e-6];local=[]
    for r in near:
        chosen=modes.copy();chosen[owner]=mode;x=point.copy();x[2*owner:2*owner+2]=r['center'];losses=loss_vector(chosen,x);dot=float(np.dot(weights,losses));sequential=sum(w*a for w,a in zip(weights,losses));exact=sum((F(w)*F(a) for w,a in zip(weights,losses)),F(0));dot_error=float(abs(F(dot)-exact));sum_error=float(abs(F(sequential)-exact));bound=float(exact)*((2*528+1)*2**-52)/(1-(2*528+1)*2**-52)
        assert dot==r['weighted_objective_mm2'] and dot_error<=bound and sum_error<=bound
        record={'sequence':r['sequence'],'owner':owner,'mode':mode,'center':r['center'],'local_index':r['local_index'],'dot':dot,'sequential_sum':sequential,'nearest_exact_sum':float(exact),'dot_exact_error':dot_error,'sequential_exact_error':sum_error,'conservative_rounding_bound':bound};local.append(record);records.append(record)
    dot_best=min(local,key=lambda r:(r['dot'],r['center'],r['local_index']));sum_best=min(local,key=lambda r:(r['sequential_sum'],r['center'],r['local_index']));assert dot_best['sequence']==selection['selected']['sequence']
    if dot_best['sequence']!=sum_best['sequence']:differences.append({'owner':owner,'mode':mode,'dot_choice':dot_best,'sequential_choice':sum_best})
write(OUT/'near-best-controls.json',records);write(OUT/'ranking-differences.json',differences)
checks={'passed':True,'seconds':time.perf_counter()-start,'owner_modes':78,'near_best_full_vectors':len(records),'exact_product_terms_per_vector':528,'recorded_dot_scores_exactly_reproduced':True,'ranking_disagreements':len(differences),'maximum_dot_exact_error':max(r['dot_exact_error'] for r in records),'maximum_sequential_exact_error':max(r['sequential_exact_error'] for r in records),'maximum_conservative_bound':max(r['conservative_rounding_bound'] for r in records),'kernels_models_trials_centers_unchanged':True,'optimizer_calls':0};write(OUT/'checks.json',checks);print(checks)
