"""Freeze and prepare conditional center relocation from the original state."""
from pathlib import Path
from hashlib import sha256
import json,time,os
from h5_weighted_relocated_neighbors_20261107 import neighbors,problem_key,rank,apply_neighbor
from h5_hard_cell_compound_modes_20261107 import family_classes,physical_key
from h5_cross_pair_weighted_model_20261107 import Objective
from h5_weighted_original_readback_20261107 import verify
from h5_checked_affinity_20261107 import affinity_mask
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'output/h5-weighted-mixed-rows-model-20261107';J=ROOT/'output/h5-weighted-joint-neighbors-20261107';OUT=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();assert load(W/'audit-v2/checks.json')['passed'] and load(J/'audit/checks.json')['passed'];assert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])
runtime=load(ROOT/'benchmarks/results/h5-weighted-joint-selection-20261107/runtime-bindings.json')
for name,h in runtime.items():assert digest(ROOT/name)==h,name
write(OUT/'runtime-bindings.json',runtime)
source_plan=ROOT/'output/h5-mixed-rows-continuous-model-20261107/plan.json';assert load(source_plan)['grid_fractions']==[i/8 for i in range(9)]
inputs=[Path(__file__),source_plan]+[ROOT/'output'/n for n in ['h5_weighted_relocated_neighbors_20261107.py','h5_weighted_joint_neighbors_20261107.py','h5_cross_pair_weighted_model_20261107.py','h5_cross_pair_boundary_gradient_20261107.py','h5_weighted_original_readback_20261107.py','h5_hard_cell_compound_modes_20261107.py','h5_mixed_direct_pose_20261107.py','h5_checked_affinity_20261107.py']]+[W/n for n in ['library.json','initial-state.json','model.json','audit-v2/checks.json']]+[J/n for n in ['plan.json','neighbors.json','owner-aliases.json','closed-weighted-problems.json','audit/checks.json']]+[ROOT/'benchmarks/results/h5-weighted-joint-selection-20261107'/n for n in ['next-step.json','archive-checks.json','runtime-bindings.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Source initializer only. For every physically changed owner-mode evaluate the original9x9grid plus nearest-clamped center against all32other originals already present. Record exact duplicate coordinates and all6396nominal trials. Reconstruct full528weighted pair scores for each trial; select center by unrounded weighted score thenXY thenlocal index. Build current,78single,2775joint vectors with selected centers and recompute mutual pair interaction once. Full score then complete mode-vector ranking; preserve fourclosed weighted keys. No grid refinement, optimizer, iterative initializer or optimized ancestor consumed.','grid_fractions':[i/8 for i in range(9)],'nominal_center_trials':6396,'maximum_centers_per_owner_mode':82,'expected_singles':78,'expected_joint':2775,'score_tolerance_mm2':1e-6,'strict_joint_improvement_mm2':1e-6,'prior_preparation_seconds':load(J/'audit/checks.json')['complete_preparation_seconds'],'cap_seconds':20,'memory_bytes':2**31,'cpu_affinity_mask':4294901760,'blas_threads':1,'optimizer_calls':0,'retry_permitted':False})
lib=load(W/'library.json');initial=load(W/'initial-state.json');closed=load(J/'closed-weighted-problems.json');write(OUT/'closed-weighted-problems.json',closed)
records,aliases,trials,centers=neighbors(lib,initial['modes'],initial['values'],initial['pair_weights'],{r['key'] for r in closed});assert aliases==load(J/'owner-aliases.json')
old_single={tuple(r['changes'][0]):r for r in load(J/'neighbors.json') if len(r['changes'])==1}
for trial in trials:
    if trial['local_index']==0:assert trial['weighted_objective_mm2']==old_single[trial['owner'],trial['mode']]['weighted_objective_mm2']
write(OUT/'neighbors.json',records);write(OUT/'owner-aliases.json',aliases);write(OUT/'center-trials.json',trials);write(OUT/'center-selections.json',centers)
single=min((r for r in records if not r['excluded'] and len(r['changes'])==1),key=rank);joint=min((r for r in records if not r['excluded'] and len(r['changes'])==2),key=rank);improves=joint['weighted_objective_mm2']<single['weighted_objective_mm2']-1e-6
write(OUT/'selection.json',{'best_single':single,'best_joint':joint,'joint_strictly_improves_single':improves,'improvement_mm2':single['weighted_objective_mm2']-joint['weighted_objective_mm2']})
if improves:
    modes,mm,x=apply_neighbor(lib,initial['modes'],initial['values'],initial['pair_weights'],joint);assert verify(mm,lib,modes,x,initial['pair_weights']);assert Objective(mm).score(x)==joint['weighted_objective_mm2'];write(OUT/'selected-model.json',mm);write(OUT/'selected-state.json',{'modes':modes,'values':x.tolist(),'pair_weights':initial['pair_weights'],'key':joint['key']})
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-start,'single_neighbors':78,'joint_neighbors':2775,'complete_proposal_scores':2854,'nominal_center_trials':len(trials),'unique_center_trials':sum(s['unique_centers'] for s in centers),'center_aliases':sum(t['duplicate_of'] is not None for t in trials),'old_clamped_scores_reproduced':78,'closed_keys':4,'excluded_choices':sum(r['excluded'] for r in records),'original_initializer_only':True,'joint_strictly_improves_single':improves,'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False});print({'choices':2854,'center_trials':len(trials),'best_single':single['weighted_objective_mm2'],'best_joint':joint['weighted_objective_mm2'],'joint_changes':joint['changes'],'strict_improvement':improves})
