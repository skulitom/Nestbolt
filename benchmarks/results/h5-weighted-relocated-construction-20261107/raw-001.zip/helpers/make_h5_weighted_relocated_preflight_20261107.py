"""Version the exhaustive audit for frozen conditional center relocations."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/audit_h5_weighted_joint_neighbors_20261107.py').read_text(encoding='utf-8')
source=source.replace('h5-weighted-joint-neighbors-20261107','h5-weighted-relocated-neighbors-20261107').replace('h5-weighted-joint-neighbors-preparation-process-20261107','h5-weighted-relocated-neighbors-preparation-process-20261107')
source=source.replace('from h5_cross_pair_weighted_model_20261107 import Objective','from h5_cross_pair_weighted_model_20261107 import Objective\nfrom h5_weighted_original_readback_20261107 import verify\nfrom h5_checked_affinity_20261107 import affinity_mask\nimport os')
marker="for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name"
source=source.replace(marker,marker+"\nassert affinity_mask()==4294901760 and all(os.environ[k]=='1' for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'])\nfor name,h in load(BASE/'runtime-bindings.json').items():assert digest(ROOT/name)==h,name")
marker='errors=[];keys=set();full_scores=[]'
assert source.count(marker)==1
block='''# Independent full geometry replay of every nominal grid/control trial.
trials=load(BASE/'center-trials.json');center_selections=load(BASE/'center-selections.json');assert len(trials)==6396 and len(center_selections)==78
assert plan['grid_fractions']==[i/8 for i in range(9)] and plan['maximum_centers_per_owner_mode']==82
assert {(r['owner'],r['mode']) for r in center_selections}=={(i,m) for i in range(33) for m in opts[i]}
trial_scores={};trial_errors=[];chosen_centers={};center_aliases=0;unique_centers=0;trial_records=[];expected_sequence=0
for selection in center_selections:
    i,mi=selection['owner'],selection['mode'];rows=[r for r in trials if r['owner']==i and r['mode']==mi];assert len(rows)==82 and [r['local_index'] for r in rows]==list(range(82));bb=lib['family_modes'][lib['identities'][i][0]][mi]['center_bounds_mm']
    clamped=[min(hi,max(lo,values[2*i+k])) for k,(lo,hi) in enumerate(bb)];nominal=[clamped]+[[bb[0][0]+xi/8*(bb[0][1]-bb[0][0]),bb[1][0]+yi/8*(bb[1][1]-bb[1][0])] for yi in range(9) for xi in range(9)];first={};ordinal={}
    for local,row in enumerate(rows):
        assert row['sequence']==expected_sequence;expected_sequence+=1;assert row['center']==nominal[local] and row['kind']==('clamped' if local==0 else 'grid') and row['grid_index']==(None if local==0 else [(local-1)%9,(local-1)//9]);key=tuple(row['center']);duplicate=first.get(key)
        if key not in first:ordinal[key]=len(first);first[key]=row['sequence'];unique_centers+=1
        else:center_aliases+=1
        assert row['duplicate_of']==duplicate and row['unique_index']==ordinal[key] and all(lo<=value<=hi for value,(lo,hi) in zip(row['center'],bb))
        chosen=modes.copy();chosen[i]=mi;point=values.copy();point[2*i:2*i+2]=row['center'];actual=full_score(chosen,point);error=abs(actual-row['weighted_objective_mm2']);assert error<plan['score_tolerance_mm2'],('center',row['sequence'],actual,row['weighted_objective_mm2']);trial_scores[row['sequence']]=actual;trial_errors.append(error);trial_records.append({'sequence':row['sequence'],'independent_weighted_score':actual,'absolute_error':error})
        if row['sequence']%500==0:print({'verified_center_scores':row['sequence']+1},flush=True)
    best=min(rows,key=lambda r:(r['weighted_objective_mm2'],r['center'],r['local_index']));independent=min(rows,key=lambda r:(trial_scores[r['sequence']],r['center'],r['local_index']));assert selection['selected']==best and best['sequence']==independent['sequence'] and selection['nominal_trials']==82 and selection['unique_centers']==len(first);chosen_centers[i,mi]=best['center']
assert center_aliases+unique_centers==6396;write(OUT/'center-score-controls.json',trial_records);write(OUT/'center-controls.json',{'nominal_trials':6396,'unique_centers':unique_centers,'aliases':center_aliases,'selected_owner_modes':78,'maximum_independent_score_error':max(trial_errors),'grid_refined':False})
'''
source=source.replace(marker,block+marker)
old="chosen[i]=mi;bb=lib['family_modes'][lib['identities'][i][0]][mi]['center_bounds_mm'];expected_center=[min(hi,max(lo,values[2*i+k])) for k,(lo,hi) in enumerate(bb)];assert center==expected_center;point[2*i:2*i+2]=center"
new="chosen[i]=mi;assert center==chosen_centers[i,mi];point[2*i:2*i+2]=center"
assert source.count(old)==1;source=source.replace(old,new)
old="obj=Objective(mm);value,g=obj.evaluate(point);"
new="assert verify(mm,lib,chosen,point,weights) and mm['initial']==point\n    obj=Objective(mm);value,g=obj.evaluate(point);"
assert source.count(old)==1;source=source.replace(old,new)
source=source.replace("charge=load(W/'audit-v2/checks.json')['complete_preparation_seconds']+process['complete_seconds']","charge=plan['prior_preparation_seconds']+process['complete_seconds']")
source=source.replace("'complete_scores':2854,'single_neighbors':78", "'complete_scores':2854,'nominal_center_scores':6396,'unique_center_trials':unique_centers,'center_aliases':center_aliases,'maximum_center_score_error':max(trial_errors),'single_neighbors':78")
source=source.replace("'method':'Independent exact rational physical classes and aliases; exhaustive full geometry score for all2854 proposals, explicit closed keys and independent rankings. Independent scalar gradient and81-coordinate/two-step central controls on selected model. No optimizer.'", "'method':'Independent exact rational classes/aliases; full geometry scores for all6396 nominal center trials and2854 proposals; exact grid, duplicate coordinates, selected centers, closed keys and independent rankings. Selected model has full schema, scalar and81-coordinate/two-step central controls. No optimizer.'")
with (ROOT/'output/audit_h5_weighted_relocated_neighbors_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
for stage,script,cap in [('preparation','prepare',20),('audit','audit',240)]:
    source=(ROOT/'output/run_h5_weighted_joint_neighbors_preparation_20261107.py').read_text(encoding='utf-8').replace('h5-weighted-joint-neighbors-preparation-process-20261107',f'h5-weighted-relocated-neighbors-{stage}-process-20261107').replace('prepare_h5_weighted_joint_neighbors_20261107.py',f'{script}_h5_weighted_relocated_neighbors_20261107.py').replace('CAP=20',f'CAP={cap}')
    with (ROOT/'output'/f'run_h5_weighted_relocated_neighbors_{stage}_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
