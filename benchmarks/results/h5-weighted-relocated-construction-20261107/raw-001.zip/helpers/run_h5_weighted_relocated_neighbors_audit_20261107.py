"""One bounded preparation stage; audits are separately accounted."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,time,os
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-weighted-relocated-neighbors-audit-process-20261107';EXE=ROOT/'output/h5-windows-job-controls-v4-20261107/job-runner.exe';PY=ROOT/'.cache/shop-venv/Scripts/python.exe';SCRIPT=ROOT/'output/audit_h5_weighted_relocated_neighbors_20261107.py';CAP=240
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();start=time.perf_counter();controls=load(EXE.parent/'checks.json');assert controls['passed'] and controls['runner_sha256']==digest(EXE)
write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [Path(__file__),SCRIPT,EXE,EXE.parent/'checks.json']},'cap_seconds':CAP,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False});env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1');r=subprocess.run([str(EXE),str(CAP*1000),str(2**31),str(OUT/'job.json'),str(OUT/'stdout.txt'),str(OUT/'stderr.txt'),str(OUT/'stop'),subprocess.list2cmdline([str(PY),str(SCRIPT)]),str(ROOT),'version4'],cwd=ROOT,capture_output=True,timeout=CAP+8,env=env);(OUT/'runner-stdout.txt').write_bytes(r.stdout);(OUT/'runner-stderr.txt').write_bytes(r.stderr);job=load(OUT/'job.json');passed=r.returncode==0 and job['reason_code']==job['error_code']==0 and job['closed'] and job['active_processes']==0;write(OUT/'process.json',{'closed':True,'complete_seconds':time.perf_counter()-start,'passed':passed,'exit_code':r.returncode,'job':job,'retry_permitted':False});print(load(OUT/'process.json'))
