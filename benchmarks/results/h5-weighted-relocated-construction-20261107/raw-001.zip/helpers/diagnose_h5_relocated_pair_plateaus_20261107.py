"""Test flat pair-overlap terms in a closed, independently verified candidate."""
from pathlib import Path
from hashlib import sha256
import json,time
import numpy as np
from shapely.affinity import translate
from h5_cross_pair_weighted_model_20261107 import Objective
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-weighted-relocated-neighbors-20261107';OUT=BASE/'pair-plateau-diagnostic';E=BASE/'search/epoch-02'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();checked=load(BASE/'response-audit/checks.json');assert checked['passed'] and checked['best_global_epoch']==2;model=load(E/'model.json');response=load(E/'response.json');assert response['closed'];values=response['unweighted_best']['values'];steps=[.001,.1,1.,5.];tolerance=1e-7
inputs=[Path(__file__),BASE/'response-audit/checks.json',E/'model.json',E/'response.json',ROOT/'output/h5_cross_pair_weighted_model_20261107.py',ROOT/'output/h5_original_overlap_gradient_v2_20261107.py']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read-only diagnostic of every positive original/clearance pair in the final independently replayed candidate. Independently calculate scalar pair boundary gradients. For terms whose available model-coordinate gradient is zero within1e-7, evaluate pair overlap after fixed±0.001,0.1,1,5mm translations of either owner on each axis, only within its hard bounds. Source candidate stays unchanged; no optimizer, pose selection, warm-start or allocation exclusion. A flat crossed-strip intersection need not be a containment.','gradient_zero_tolerance':tolerance,'pair_loss_change_tolerance_mm2':tolerance,'translation_steps_mm':steps,'optimizer_calls':0})
entries=Objective(model).geometry(values);records=[];flat=[]
for index,(i,j) in enumerate(model['pairs']):
    areas=[entries[k][i][1].intersection(entries[k][j][1]).area for k in range(2)];loss=sum(areas)
    if loss<=0:continue
    gradients=[];available=[]
    for own,other in [(i,j),(j,i)]:
        gradient=np.zeros(3)
        for k in range(2):
            gg,_,_=moving_boundary_gradient(entries[k][own][1],entries[k][other][1],values[2*own:2*own+2]);gradient+=gg
        gradients.append(gradient.tolist());available.extend(gradient[:2])
        if model['owners'][own]['angle_coordinate'] is not None:available.append(gradient[2]/model['owners'][own]['angle_scale_mm'])
    zero=max(abs(g) for g in available)<tolerance;record={'pair_index':index,'owners':[i,j],'identities':[model['owners'][i]['identity'],model['owners'][j]['identity']],'original_overlap_mm2':areas[0],'clearance_overlap_mm2':areas[1],'pair_loss_mm2':loss,'weight':model['pair_weights'][index],'scalar_gradients':gradients,'available_coordinate_gradient_zero':bool(zero),'strict_containment_original':bool(entries[0][i][1].contains_properly(entries[0][j][1]) or entries[0][j][1].contains_properly(entries[0][i][1]))}
    if zero:
        probes=[]
        for own,other in [(i,j),(j,i)]:
            for axis in range(2):
                coordinate=2*own+axis;lo,hi=model['bounds'][coordinate]
                for step in steps:
                    for sign in [-1,1]:
                        delta=step*sign
                        if not lo<=values[coordinate]+delta<=hi:continue
                        moved=[translate(entries[k][own][1],xoff=delta if axis==0 else 0.,yoff=delta if axis==1 else 0.) for k in range(2)];next_loss=sum(moved[k].intersection(entries[k][other][1]).area for k in range(2));probes.append({'owner':own,'axis':axis,'translation_mm':delta,'pair_loss_mm2':next_loss,'change_mm2':next_loss-loss})
        record['probes']=probes;record['tested_directions']=len({(p['owner'],p['axis'],p['translation_mm']>0) for p in probes});record['all_feasible_probes_flat']=bool(probes) and all(abs(p['change_mm2'])<tolerance for p in probes);record['maximum_absolute_probe_change']=max((abs(p['change_mm2']) for p in probes),default=0.);flat.append(record)
    records.append(record)
write(OUT/'all-positive-pairs.json',records);write(OUT/'flat-pair-probes.json',flat);checks={'passed':True,'seconds':time.perf_counter()-start,'positive_original_or_clearance_pairs':len(records),'flat_available_gradient_pairs':len(flat),'noncontained_flat_pairs':sum(not r['strict_containment_original'] for r in flat),'flat_pairs_with_all_feasible_probes_flat':sum(r['all_feasible_probes_flat'] for r in flat),'flat_original_overlap_mm2':sum(r['original_overlap_mm2'] for r in flat),'flat_pair_loss_mm2':sum(r['pair_loss_mm2'] for r in flat),'bounded_translation_probes':sum(len(r['probes']) for r in flat),'optimizer_calls':0,'candidate_changed':False,'any_allocation_excluded':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
