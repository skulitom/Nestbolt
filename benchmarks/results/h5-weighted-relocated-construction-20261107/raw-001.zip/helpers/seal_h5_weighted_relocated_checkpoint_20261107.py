"""Preserve conditional relocation, exact ranking correction and closed search."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-weighted-relocated-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-weighted-relocated-neighbors-20261107';F=BASE/'response-audit';D=BASE/'audit-v2'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-weighted-joint-selection-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==46 and not front['source_valid66']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE]+[ROOT/'output'/n for n in ['h5-weighted-relocated-neighbors-preparation-process-20261107','h5-weighted-relocated-neighbors-audit-process-20261107','h5-relocated-score-rounding-process-20261107','h5-weighted-relocated-neighbors-audit-v2-process-20261107','h5-weighted-relocated-response-audit-process-20261107','h5-weighted-joint-main-sync-20261107']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*relocat*20261107.py','push_h5_weighted_joint_checkpoints_20261107.py','audit_h5_weighted_mixed_rows_response_20261107.py','run_h5_weighted_mixed_rows_search_20261107.py','audit_h5_weighted_joint_neighbors_20261107.py','run_h5_weighted_joint_neighbors_preparation_20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_weighted_relocated_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"'next-step-correction.json']":"'next-step-correction.json','plan-v2.json']"
}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,row in load(ROOT/'output/h5-weighted-mixed-rows-model-20261107/audit-v2/tool-provenance.json')['tool_files'].items():runtime[name]=row['sha256']
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(D/'checks.json','model-audit.json'),(D/'center-controls.json','center-controls.json'),(D/'enumeration-controls.json','enumeration-controls.json'),(BASE/'selection.json','initial-selection.json'),(BASE/'rounding-diagnostic/checks.json','rounding-diagnostic.json'),(BASE/'rounding-diagnostic/ranking-differences.json','rounding-ranking-differences.json'),(ROOT/'output/h5-weighted-relocated-neighbors-audit-process-20261107/process.json','preserved-failed-audit-process.json'),(ROOT/'output/h5-weighted-relocated-neighbors-audit-v2-process-20261107/process.json','model-audit-process.json'),(F/'checks.json','response-audit.json'),(F/'epoch-reconciliation.json','epoch-reconciliation.json'),(F/'epoch-02-unweighted-source-checks.json','source-failures.json'),(BASE/'search/process.json','closed-process.json'),(BASE/'outcome-diagnostic/checks.json','outcome-diagnostic.json'),(BASE/'outcome-diagnostic/comparison.json','prior-result-comparison.json'),(BASE/'outcome-diagnostic/records.json','outcome-records.json'),(BASE/'pair-plateau-diagnostic/checks.json','pair-plateau-diagnostic.json'),(BASE/'pair-plateau-diagnostic/flat-pair-probes.json','flat-pair-probes.json'),(ROOT/'output/h5-weighted-joint-main-sync-20261107/receipt.json','prior-main-push-receipt.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
plateau=load(BASE/'pair-plateau-diagnostic/checks.json');assert plateau['passed'] and plateau['flat_available_gradient_pairs']==plateau['noncontained_flat_pairs']==plateau['flat_pairs_with_all_feasible_probes_flat']==1 and plateau['bounded_translation_probes']==26
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']},'flat_noncontained_pair_verified':True,'flat_pair_bounded_probes':26})
write(OUT/'next-step.json',{'status':'flat_bracket_collision_region_depth_preflight_required','finding':'The closed best candidate has a bracket7/bracket8 crossed-arm intersection of5625mm2 (11284.5529mm2 including clearance). Neither polygon strictly contains the other. All available pair-coordinate gradients are zero within1e-7, and26 feasible translations at the frozen±0.001/0.1/1/5mm steps leave this term unchanged. Positive constant pair reweighting cannot supply a direction for this term. This is one local observation, not a global exclusion.','proposal':'Reconcile earlier configuration-space/surrogate work, then assess a supplementary squared distance-to-exit penalty for the exact nominal bracket/bracket collision translation region. The source bracket is a six-vertex orthogonal L, expressible as two rectangles with disjoint interiors. A union of component Minkowski-difference regions can represent its pair collision region and supply a direction on the crossed-arm area plateau. This is a new numerical/geometry preflight only; no auxiliary kernel or optimizer is prepared.','requirements':['Independently reconstruct the exact source bracket rectangle union and all fixed quarter-turn/mirror modes, retaining domain aliases separately. Build and verify collision translation regions from source components with rational boundary/inside/outside controls; reconcile nominal quarter turns with the actual floating source transforms and required source-gap tolerance. Do not replace exact original/clearance areas with a proxy.','Define the supplementary loss before measurements: squared distance from an interior relative translation to the exterior of the collision region, zero outside; retain deterministic closest-feature ties and nonsmooth cases explicitly. Freeze coefficient1 if the proof supports the same square-mm units. Independently verify values and both owner derivatives, including off-center rotation pivots where applicable; bracket angles are fixed in this model.','Retain every original/clearance term, all528pair identities, positive bounded weights and hard stock/fixed domains. Prove that the additional nonnegative term cannot hide an original overlap; establish its behavior on source-valid gap-separated pairs. Final acceptance remains full original-source validation.','Use the saved crossed-arm candidate only as a validation counterexample demonstrating zero area gradient and a verified separating direction from the proposed loss. It may not seed a successor optimizer. No closed weighted/unweighted call may resume, change objective, reset time or receive an extension.','Only after independent source/gradient/score preflight may a separately versioned objective and finite complete-accounting contract be considered from the unoptimized source initializer. Record objective identity in closure keys, preserve all seven closed weighted problems and all older calls, and charge every consumed preparation stage. No such model or call exists in this checkpoint.'],'new_auxiliary_kernel_prepared':False,'new_optimizer_calls':0,'closed_calls_remain_closed':True,'H5_complete':False})
ci=load(BASE/'main-ci-at-review.json');success=sum(r['conclusion']=='success' for r in ci['jobs']);live=sum(r['status']!='completed' for r in ci['jobs'])
report=f'''# Weighted conditional-relocation construction — 2026-11-07

The conditional-relocation model passes independent checks and closes three
new weighted calls. It still has no valid full layout: the final candidate
fails **46 source pairs**, with **28,414.189788 mm²** overlap. It has fewer
failing pairs than the preceding weighted result but a worse overlap-area
score. H2/H5 remain open at **60% completed milestone weight**.

## Fixed-grid relocation and preserved ranking failure

The [model audit]({NAME}/model-audit.json) verifies **6,396 nominal center
trials** over78 changed owner modes, retaining32 exact-coordinate aliases and
6,364 unique centers. The existing9-by-9 source grid and clamped-center control
are frozen before scoring. Each trial considers all32 other originals already
present, unlike sequential greedy initialization. The78 old clamped scores
reproduce exactly. The [same complete enumeration]({NAME}/enumeration-controls.json)
then scores the current vector,78 single-owner and2,775 two-owner alternatives
using all528 original/clearance pair losses.

[The best joint proposal]({NAME}/initial-selection.json) moves inserts10 and20
(owners16 and17) into mode2. Its weighted score is216,054.847421mm² versus
229,297.518758mm² for the best single, an improvement of **13,242.671337 mm²**.
It also improves the original244,566.416868mm² initializer. Independent source
transforms reproduce every center/proposal score; the selected model passes
148 scalar boundary terms and162 central samples, with maximum central error
0.000103 under the unchanged tolerance.

The [original audit failure]({NAME}/preserved-failed-audit-process.json) remains
preserved. It demanded identical winners from NumPy dot-product scores and a
sequential scalar sum. One owner-mode has a binary64 near-tie where the
reduction orders disagree. [Independent exact-product controls]({NAME}/rounding-diagnostic.json)
cover all89 near-best vectors across78 modes, reproducing every recorded score.
[The one ranking difference]({NAME}/rounding-ranking-differences.json) is on
the order of1e-11mm². Version2 independently reconstructs every pair vector
for the specified score ordering and separately checks sequential sums within
the unchanged1e-6 tolerance. Model, weights, geometry, trials and selected
centers remain unchanged. The failed wrapper takes86.431769s; the passing
[versioned audit wrapper]({NAME}/model-audit-process.json) takes194.258318s.
No optimizer precedes the passing audit.

## Three distinct closed calls and complete accounting

The new pipeline starts from the audited unoptimized source-grid selection.
It excludes all four previous weighted coefficient/mode keys. At each later
epoch it updates bounded positive coefficients, repeats the frozen conditional
center calculation, and admits a new joint choice only if it beats both the
current point and the best admissible single choice. No grid refinement occurs.
The contract permits at most three ten-second calls within preparation-inclusive
60/90-second limits, shortening a call at the source-check reserve boundary.

[Response replay]({NAME}/response-audit.json) verifies **12,792 runtime center
trials**, **5,708 complete proposals**, **1,056 updated coefficients** and
**206 retained points**, reconciling246 function evaluations. It independently
reconstructs both full66 winners after each call: six checks of1,380 same-sheet
pairs,264 stock edges,90 holes and10,026 hole vertices. The weighted/unweighted
winner positions coincide in these three epochs; both streams remain explicit.
All fixed-part and stock checks pass. [Epoch outcomes]({NAME}/epoch-reconciliation.json)
retain55,52 and46 failing pairs.

Complete preparation is **15.046673s**: the original9.437444s, the consumed
negative joint-selection stage1.517851s and the new relocation wrapper4.091379s.
Validation-only audits are separately retained. The first two calls receive10s;
the third receives5.458502s. Algorithm/shared totals are
**56.586553/56.748614s**. Slice overruns of0.074402,0.034575 and0.039643s are
preserved. The pipeline stops after its final source check. All five
[search processes close]({NAME}/closed-process.json), with114,229,248bytes peak
aggregate committed memory, below2GiB. None of the seven combined weighted
problems may resume. The response-audit wrapper closes in384.974831s.

The [46 final failures]({NAME}/source-failures.json) comprise40 positive
intersections and six clearance-only failures. [Comparison with the preceding
weighted result]({NAME}/prior-result-comparison.json) shows the tradeoff:
three fewer failing pairs, but206.434815mm² more original overlap and
297.328738mm² more unweighted original-plus-clearance penalty. Neither result
is a valid full layout; no material-quality improvement is claimed.

## A verified flat crossed-arm collision

[Failure composition]({NAME}/outcome-diagnostic.json) finds21 companion/cog
failures totaling11,466.537157mm² overlap,16 cog/cog failures totaling
9,441.760037mm², and failures between companions. Three cogs have lower-y
bounds active with their local negative weighted gradient blocked. These are
candidate observations, not a global packing exclusion.

A [separate fixed-probe diagnostic]({NAME}/pair-plateau-diagnostic.json)
checks all47 positive original/clearance pairs. Brackets7 and8 have a
**5,625mm²** crossed-arm overlap, with neither strictly containing the other.
Their combined original/clearance term is11,284.552900mm². Every available
pair-coordinate gradient is zero within1e-7. All **26 feasible translations**
at the predeclared±0.001,0.1,1 and5mm steps leave that pair term unchanged.
[Every probe is retained]({NAME}/flat-pair-probes.json). Increasing a constant
positive coefficient cannot provide a direction for a zero-gradient term.
No probe modifies the saved candidate or seeds an optimizer.

[The next preflight]({NAME}/next-step.json) therefore assesses a supplementary
squared distance-to-exit loss for a source-derived bracket collision translation
region. The original L can be decomposed into two rectangles. The proposal
needs independent source, configuration-space, boundary and derivative proofs,
including deterministic ties and floating-transform reconciliation. It must
retain every exact original/clearance term and all existing acceptance rules.
The saved flat pair is validation-only. No auxiliary kernel, new objective
model or successor optimizer is prepared here.

## Repository and evidence

The three preceding checkpoints0af0c522, f03aadc1 andc7e4b305 reached main
normally after all six previous checks passed, preserving52 remote files.
[The push receipt]({NAME}/prior-main-push-receipt.json) records both branch
updates and fresh CI42369490349. [At review]({NAME}/main-ci-at-review.json),
{success} jobs pass and{live} remain live. This checkpoint awaits the ordinary
push gate. Product code, README claims and releases remain unchanged. Four
earlier fixed arrangements and440 allocations remain unresolved.

[Manifest]({NAME}/raw-manifest.json), [source bindings]({NAME}/source-bindings.json),
[historical references]({NAME}/external-evidence.json) and
[runtime pins]({NAME}/runtime-bindings.json) preserve the failures, correction,
all trials, closed calls and readbacks.
'''
for a,b in [('over78','over 78'),('retaining32','retaining 32'),('existing9','existing 9'),('all32','all 32'),('The78','The 78'),('vector,78','vector, 78'),('and2,','and 2,'),('all528','all 528'),('inserts10','inserts 10'),('and20','and 20'),('owners16','owners 16'),('and17','and 17'),('mode2','mode 2'),('is216','is 216'),('421mm','421 mm'),('758mm','758 mm'),('original244','original 244'),('868mm','868 mm'),('and162','and 162'),('all89','all 89'),('across78','across 78'),('of1e','of 1e'),('e-11mm','e-11 mm'),('unchanged1e','unchanged 1e'),('takes86','takes 86'),('takes194','takes 194'),('reconciling246','reconciling 246'),('of1,','of 1,'),('pairs,264','pairs, 264'),('edges,90','edges, 90'),('and10,','and 10,'),('retain55,52','retain 55, 52'),('and46','and 46'),('original9','original 9'),('stage1','stage 1'),('wrapper4','wrapper 4'),('receive10','receive 10'),('receives5','receives 5'),('of0.','of 0.'),(',0.034',', 0.034'),('and0.','and 0.'),('with114','with 114'),('248bytes','248 bytes'),('below2','below 2'),('in384','in 384'),('comprise40','comprise 40'),('but206','but 206'),('815mm','815 mm'),('738mm','738 mm'),('finds21','finds 21'),('totaling11','totaling 11'),('157mm','157 mm'),('overlap,16','overlap, 16'),('037mm','037 mm'),('all47','all 47'),('Brackets7','Brackets 7'),('and8','and 8'),('5,625mm','5,625 mm'),('is11,','is 11,'),('900mm','900 mm'),('within1e','within 1e'),('predeclared±','predeclared ±'),('001,0.1,1','001, 0.1, 1'),('and5mm','and 5 mm'),('checkpoints0af','checkpoints 0af'),('andc7','and c7'),('preserving52','preserving 52'),('CI423','CI 423'),('and440','and 440'),('and{live}','and {live}')]:report=report.replace(a,b)
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 weighted conditional relocation:** [independent preflight and response replay]({link}) verify 6,396 initial center trials, 2,854 initial proposals, 148 scalar terms and 162 central samples. A preserved ranking-check failure is resolved by independently reconstructing dot ordering and checking scalar sums; exact rational controls reproduce 89 near-best vectors without changing trials, models or tolerances. Three new weighted problems close after 12,792 runtime center trials and 5,708 proposals; 1,056 coefficient updates, 206 retained points, 246 evaluations and six full66 winner readbacks replay. The final candidate still fails 46 pairs with 28,414.189788 mm² overlap: fewer failing pairs but worse overlap/penalty than the prior weighted result. Fixed-part and stock checks pass. Complete preparation is 15.046673 s and algorithm/shared totals are 56.586553/56.748614 s; all processes close and slice overruns remain. A separate diagnostic verifies one noncontained bracket crossing with 5,625 mm² overlap, zero available pair gradient and 26 flat feasible translation probes. Next preflight a supplementary source-derived collision-region depth loss while retaining every exact area term; no auxiliary kernel or successor call exists. No native call or exclusion follows. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. The preceding three checkpoints reached main c7e4b305 after all six CI checks passed, preserving 52 remote files; fresh CI42369490349 is running. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [weighted conditional relocation](../benchmarks/results/{NAME}.md).
Independent preflight verifies the fixed center grid, all joint scores and
selected model derivatives. The original summation-order ranking failure and
exact correction are preserved without changing the model or trials.
Three new weighted problems close; 12,792 runtime center trials, 5,708 mode
proposals, 1,056 coefficient updates, 206 retained points and six full66 winner
readbacks replay. The best candidate still fails 46 pairs with 28,414.189788 mm²
overlap, worse in overlap/penalty than the preceding weighted result despite
fewer failing pairs. Fixed-part and stock checks pass. Complete preparation is
15.046673 s; algorithm/shared totals are 56.586553/56.748614 s, with all
processes closed and slice overruns preserved. A separate read-only diagnostic
finds a noncontained crossed-bracket plateau: 5,625 mm² overlap, zero available
pair gradient and 26 flat feasible translation probes. Next independently
assess a source-derived collision-region depth term while retaining exact
area terms. No auxiliary kernel, new objective or successor call is prepared.
No native call or allocation exclusion follows. Four earlier arrangements and
440 allocations remain; H2/H5 stay at 60% completed milestone weight.
The three preceding checkpoints reached main c7e4b305 after all six CI jobs
passed, preserving 52 remote files; fresh CI42369490349 is running.
This checkpoint awaits the ordinary push gate. Product code, README and
releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
