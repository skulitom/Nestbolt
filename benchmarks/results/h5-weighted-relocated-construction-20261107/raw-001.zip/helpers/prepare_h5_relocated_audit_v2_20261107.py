"""Preserve the scalar-reduction ranking failure; correct only its oracle."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-weighted-relocated-neighbors-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
diagnostic=load(BASE/'rounding-diagnostic/checks.json');assert diagnostic['passed'] and diagnostic['ranking_disagreements']==1 and diagnostic['recorded_dot_scores_exactly_reproduced']
failure=ROOT/'output/h5-weighted-relocated-neighbors-audit-process-20261107/process.json';assert load(failure)['closed'] and not load(failure)['passed']
original=ROOT/'output/audit_h5_weighted_relocated_neighbors_20261107.py';s=original.read_text(encoding='utf-8').replace("OUT=BASE/'audit'","OUT=BASE/'audit-v2'").replace("plan=load(BASE/'plan.json')","plan=load(BASE/'plan-v2.json')")
old="def full_score(chosen,point):\n    ps=shapes(chosen,point);return sum(w*sum(ps[i][k].intersection(ps[j][k]).area for k in [0,1]) for (i,j),w in zip(combinations(range(33),2),weights))"
new="""maximum_scalar_reduction_difference=0.;independent_full_score_calls=0
def full_score(chosen,point):
    global maximum_scalar_reduction_difference,independent_full_score_calls
    ps=shapes(chosen,point);losses=[sum(ps[i][k].intersection(ps[j][k]).area for k in [0,1]) for i,j in combinations(range(33),2)]
    ordered=float(np.dot(weights,losses));scalar=sum(w*a for w,a in zip(weights,losses));difference=abs(ordered-scalar);assert difference<plan['score_tolerance_mm2'];maximum_scalar_reduction_difference=max(maximum_scalar_reduction_difference,difference);independent_full_score_calls+=1
    return ordered"""
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace("'maximum_center_score_error':max(trial_errors)","'maximum_center_score_error':max(trial_errors),'maximum_scalar_reduction_difference':maximum_scalar_reduction_difference,'independent_full_score_calls':independent_full_score_calls")
corrected=ROOT/'output/audit_h5_weighted_relocated_neighbors_v2_20261107.py'
with corrected.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
wrapper=ROOT/'output/run_h5_weighted_relocated_neighbors_audit_20261107.py';s=wrapper.read_text(encoding='utf-8').replace('h5-weighted-relocated-neighbors-audit-process-20261107','h5-weighted-relocated-neighbors-audit-v2-process-20261107').replace('audit_h5_weighted_relocated_neighbors_20261107.py','audit_h5_weighted_relocated_neighbors_v2_20261107.py');newwrapper=ROOT/'output/run_h5_weighted_relocated_neighbors_audit_v2_20261107.py'
with newwrapper.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
plan=load(BASE/'plan.json')
for name,h in plan['inputs'].items():assert digest(ROOT/name)==h,name
for p in [Path(__file__),original,corrected,newwrapper,BASE/'plan.json',failure,BASE/'rounding-diagnostic/plan.json',BASE/'rounding-diagnostic/checks.json',BASE/'rounding-diagnostic/ranking-differences.json',ROOT/'output/h5-relocated-score-rounding-process-20261107/process.json',ROOT/'output/h5-weighted-relocated-neighbors-audit-process-20261107/stderr.txt']:plan['inputs'][p.relative_to(ROOT).as_posix()]=digest(p)
plan['audit_correction']='Independently reconstruct all528 losses from source polygons, reproduce the frozen unrounded NumPy-dot score ordering, and separately verify sequential scalar sums within the unchanged1e-6 tolerance at every full-score evaluation. The prior verifier incorrectly required sequential-sum ranking to exactly equal dot-product ranking at binary64 ties. Exact rational controls cover all89 near-best vectors across78owner-modes and identify one ranking difference. Model, trials, selected centers, geometry, coefficients, tolerances and optimizer state are unchanged. Original failed audit retained.'
write(BASE/'plan-v2.json',plan);print({'verifier_versioned':True,'frozen_trials_unchanged':6396,'near_best_exact_controls':89,'optimizer_calls':0})
# The search runner is still unexecuted. Point its prerequisite at the corrected audit.
for name in ['make_h5_weighted_relocated_search_20261107.py','run_h5_weighted_relocated_search_20261107.py']:
    p=ROOT/'output'/name;s=p.read_text(encoding='utf-8').replace("BASE/'audit/checks.json'","BASE/'audit-v2/checks.json'").replace("'audit/plan.json','audit/checks.json'","'audit-v2/plan.json','audit-v2/checks.json'")
    p.write_text(s,encoding='utf-8',newline='\n')
