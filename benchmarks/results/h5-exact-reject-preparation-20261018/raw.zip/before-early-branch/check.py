"""Preserve the expected failing regression before installing the early branch."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-exact-reject-probe-20261018'
plan=json.loads((out/'preparation.json').read_bytes());target=Path(plan['target']);assert not target.exists()
work=out/'candidate';failed=out/'before-early-branch';failed.mkdir()
subprocess.run(['cargo','fmt','--all'],cwd=work,check=True)
for rel in plan['changed_files']:
    p=failed/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/rel,p)
name='sheets::vstrip::exchange::tests::'+plan['first_expected_failure']
command=['cargo','test','--release','--locked','-p','nestbolt-core','--lib','--target-dir',str(target),name,'--','--exact','--nocapture']
started=datetime.now(timezone.utc).isoformat()
with (failed/'expected-failure.log').open('xb') as log:r=subprocess.run(command,cwd=work,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
text=(failed/'expected-failure.log').read_text(encoding='utf-8')
record={'command':command,'started':started,'finished':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,
    'log_sha256':sha256((failed/'expected-failure.log').read_bytes()).hexdigest(),
    'expected_runtime_failure':r.returncode!=0 and '0 passed; 1 failed' in text and 'The observed identical trial must reject before full validation' in text,
    'new_measured_searches':0}
bins=list((target/'release/deps').glob('nestbolt_core-*.exe'))
if len(bins)==1:
    shutil.copyfile(bins[0],failed/'authored-tests.exe');record['binary_sha256']=sha256(bins[0].read_bytes()).hexdigest()
(failed/'checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,failed/'check.py');print(json.dumps(record),flush=True)
assert record['expected_runtime_failure']
