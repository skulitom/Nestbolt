"""Preserve the unchanged paired quality protocol and public functional checks."""
from pathlib import Path
from hashlib import sha256
import ast,json
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-exact-reject-probe-20261018'
def adapt(s):return s.replace('h5-larger-return-probe','h5-exact-reject-probe').replace('h5-larger-return-preparation','h5-exact-reject-preparation').replace('h5_larger_return_pilot','h5_exact_reject_pilot')
source=root/'scripts/h5_larger_return_pilot.py';original=source.read_text(encoding='utf-8');text=adapt(original);end=text.index('"""',3)+3
text='''"""Paired development pilot for exact-state early rejection of exchange trials.

Four frozen H5 jobs, both kerfs, seeds 0-2 and matched 60-second wall budgets.
The baseline is the unchanged preview. The candidate adds only a conservative
exact-state early rejection to the rejected larger-return algorithm. Complete
original-item identity, transform bits, reflection, multiplicity and shared
immutable container are required. Changed states and all accepted exchanges
retain the original full geometry/material guards, repairs and phase budgets.
All 113 prior tests remain unchanged; four new tests cover identity and actual
early rejection, including disabled/expired calls and exact rollback.
This descriptive pilot cannot close H5 or justify a public comparative claim.
"""'''+text[end:]
text=text.replace("PROBE/'refined-checks.json'","PROBE/'source-checks.json'").replace("PROBE/'witness-checks/checks.json'","PROBE/'branch-checks/checks.json'")
text=text.replace('Isolated larger-return-area pair candidate, common-line search bonus on','Isolated exact-state early-rejection candidate, common-line search bonus on')
text=text.replace("'previous_failed_pilot': 'benchmarks/results/h5-mixed-exchange-pilot-20261018/results.json'","'previous_failed_pilot': 'benchmarks/results/h5-larger-return-pilot-20261018/results.json'")
needle="ROOT/'benchmarks/results/h5-larger-return-witness-20261018/checks.json'])";assert text.count(needle)==1
text=text.replace(needle,"ROOT/'benchmarks/results/h5-larger-return-witness-20261018/checks.json',\n                  ROOT/'benchmarks/results/h5-exact-state-20261018/layout-checks.json',\n                  ROOT/'benchmarks/results/h5-exact-state-20261018/source-review.json'])")
path=root/'scripts/h5_exact_reject_pilot.py';assert not path.exists();path.write_text(text,encoding='utf-8',newline='\n');compile(text,str(path),'exec')
functions=lambda s:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
a,b=functions(original),functions(text);names=['blocks','summarize','case','measure'];assert all(a[n]==b[n] for n in names)
record={'reference':source.relative_to(root).as_posix(),'reference_sha256':sha256(source.read_bytes()).hexdigest(),
    'candidate_runner':path.relative_to(root).as_posix(),'runner_sha256':sha256(path.read_bytes()).hexdigest(),
    'identical_function_ASTs':names,'scoring_or_measurement_changed':False}
(probe/'pilot-method.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
for suffix in ['public','harness']:
    s=adapt((root/f'output/check_h5_larger_return_{suffix}.py').read_text(encoding='utf-8'))
    p=root/f'output/check_h5_exact_reject_{suffix}.py';p.write_text(s,encoding='utf-8',newline='\n');compile(s,str(p),'exec')
print(json.dumps(record))
