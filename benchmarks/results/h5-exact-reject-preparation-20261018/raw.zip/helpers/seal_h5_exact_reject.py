"""Seal the experimental exact-state candidate before its unchanged quality pilot."""
from pathlib import Path
from hashlib import sha256
import json,shutil,sys,zipfile
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-exact-reject-probe-20261018';out=root/'benchmarks/results/h5-exact-reject-preparation-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
plan=load(probe/'preparation.json');build=load(probe/'build.json');public=load(probe/'public-checks/checks.json');branch=load(probe/'branch-checks/checks.json');source=load(probe/'source-checks.json')
assert build['all_checks_passed'] and public['all_checks_passed'] and branch['all_checks_passed']
assert '117 passed; 0 failed' in (probe/'core-tests.log').read_text(encoding='utf-8')
assert branch['actual_outcomes']==12 and branch['public_validations']==24
assert source['all_113_original_tests_unchanged'] and source['other_exchange_runtime_exact'] and source['no_accepted_validation_bypass']
red=load(probe/'before-early-branch/checks.json');assert red['expected_runtime_failure']
assert digest(probe/'before-early-branch/expected-failure.log')==red['log_sha256']
assert digest(probe/'before-early-branch/authored-tests.exe')==red['binary_sha256']
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
for arm,rows in plan['old_source_files'].items():
    for row in rows:
        assert digest(Path(plan['old_probe'])/arm/row['path'])==row['sha256']
        if not(arm=='candidate' and row['path'] in plan['changed_files']):assert digest(probe/arm/row['path'])==row['sha256']
for rel,expected in build['source_sha256'].items():assert digest(probe/'candidate'/rel)==expected
stats='crates/core/src/sheets.rs'
field='\n    #[serde(skip_serializing_if = "is_zero")]\n    pub exact_state_exchange_rejections: u64,'
s=(probe/'candidate'/stats).read_text(encoding='utf-8');assert s.count(field)==1
assert s.replace(field,'')==(Path(plan['old_probe'])/'candidate'/stats).read_text(encoding='utf-8')
for arm in ['baseline','candidate']:assert digest(probe/(arm+'-observer.exe'))==build['binaries'][arm]
for name,expected in load(probe/'public-checks/plan.json')['guards'].items():assert digest(root/name)==expected
assert public['observer_outcomes']==10 and public['CLI_cross_checks']==4
assert all(row['canonical_layout_and_metrics_exact'] for row in branch['records'])
assert sum(r['stats'].get('exact_state_exchange_rejections',0)>0 for r in branch['records'])==4
harness=(probe/'pilot-harness-tests.log').read_text(encoding='utf-8');assert 'Ran 5 tests' in harness and harness.rstrip().endswith('OK')
method=load(probe/'pilot-method.json');assert digest(root/method['reference'])==method['reference_sha256'] and digest(root/method['candidate_runner'])==method['runner_sha256']
ci=load(root/'output/ci-main-924336a-confirmed-20261018.json');assert ci['conclusion']=='success' and len(ci['jobs'])==6
out.mkdir();files={p.relative_to(probe).as_posix():p for p in probe.rglob('*') if p.is_file()}
helpers=['prepare_h5_exact_reject.py','check_h5_exact_reject_red.py','apply_h5_exact_reject.py','build_h5_exact_reject.py','prepare_h5_exact_reject_checks.py','check_h5_exact_reject_branch.py','check_h5_exact_reject_public.py','check_h5_exact_reject_harness.py','seal_h5_exact_reject.py','record_h5_exact_reject_preparation.py']
for name in helpers:files['helpers/'+name]=root/'output'/name
files['runner.py']=root/'scripts/h5_exact_reject_pilot.py'
inventory={name:{'bytes':p.stat().st_size,'sha256':digest(p)} for name,p in files.items()};archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(inventory)
    for name,row in inventory.items():
        b=z.read(name);assert len(b)==row['bytes'] and sha256(b).hexdigest()==row['sha256']
write(out/'integrity.json',{'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive),'all_members_and_crc_verified':True,'members':inventory})
checks={'all_functional_checks_pass':True,'optimized_core_tests_passed':117,'prior_tests_unchanged':113,'new_tests':4,
    'expected_failure_preserved':True,'exact_exchange_runtime_reversal':True,'stats_only_added_counter':True,'strict_lint_passed':True,'observer_build_passed':True,
    'actual_branch_outcomes':12,'branch_frozen_CLI_checks':24,'public_observer_outcomes':10,'public_CLI_cross_checks':4,
    'normal_exact_except_wall':True,'common_replay_exact_except_wall':True,'pilot_harness_tests':5,
    'production_unchanged':True,'measurement_started':False,'H5_complete':False,'completed_weight_percent':60}
write(out/'checks.json',checks)
for name in ['preparation.json','build.json','source-checks.json','candidate.patch','pilot-method.json']:shutil.copyfile(probe/name,out/name)
shutil.copyfile(probe/'before-early-branch/checks.json',out/'expected-failure.json')
shutil.copyfile(probe/'branch-checks/checks.json',out/'branch-checks.json');shutil.copyfile(probe/'public-checks/checks.json',out/'public-checks.json')
shutil.copyfile(root/'output/ci-main-924336a-confirmed-20261018.json',out/'main-ci-924336a.json')
doc='''# Exact-state early rejection — preparation, 2026-10-18

The [two panel diagnostics](h5-exact-state-20261018.md) identify one exactly
unchanged trial among six neutral rejections. All twelve saved incumbent/trial
layouts validate independently; the other five change poses despite equal
material. This supports a narrow early rejection, not a quality claim.

This isolated candidate starts from the rejected larger-return build and
rejects only a full exact internal-state match before repeated validation.
It requires shared immutable container and original-item objects, item IDs,
full float bits, reflection and multiplicity. It ignores only placement keys
and insertion order. No tolerance or rounded-pose comparison is used. Every
changed state and every accepted exchange keeps the full original geometry
and strict material checks. Repairs, choices, samples, caps, work charges
outside the skipped validator and all time limits remain unchanged. A new
counter distinguishes early exact-state rejections from later neutral ones.

Before installing the branch, the new regression fails as expected; its
source, executable and log are preserved. Afterwards all 117 optimized core
tests pass: all 113 prior tests unchanged, the three qualified identity tests
and one actual branch regression. The latter executes active, disabled and
expired calls across four seeds. Twelve outcomes pass 24 frozen-CLI checks;
active/expired public layouts and metrics exactly match the disabled internal
incumbent. Original authored f64 metrics are retained separately from the
existing conversion into the internal f32 frame. Exact rollback remains
asserted within the original exercise helper.

Strict lint/build, ten public observer outcomes, four CLI comparisons and
five adversarial pilot checks pass. Normal results and deterministic common
replays match exactly except wall time. The planned 72-outcome pilot retains
the preceding four jobs, two kerfs, three seeds, rotating sequential three-arm
blocks, eight physical CCD0 cores and 60-second budgets. Block, case, scoring
and measurement functions are AST-identical to the preceding pilot.

All six hosted checks on main `924336a` passed before this checkpoint. The
experimental solver is not integrated; production and frozen inputs remain
unchanged. This candidate has no development quality result yet and does not
warrant another release. The published preview and three READMEs remain
current. H2/H5 stay open and completed milestone weight remains 60%.

[Checks](h5-exact-reject-preparation-20261018/checks.json),
[preserved expected failure](h5-exact-reject-preparation-20261018/expected-failure.json),
[branch outcomes](h5-exact-reject-preparation-20261018/branch-checks.json),
[source review](h5-exact-reject-preparation-20261018/source-checks.json),
[archive integrity](h5-exact-reject-preparation-20261018/integrity.json).
'''
(out.parent/(out.name+'.md')).write_text(doc,encoding='utf-8',newline='\n')
with (root/'.gitattributes').open('a',encoding='utf-8',newline='\n') as f:
    for name in [out.name,'h5-exact-reject-pilot-20261018']:f.write('\nbenchmarks/results/'+name+'/** -text -whitespace\n')
print(json.dumps({'all_functional_checks_pass':True,'sealed_members':len(inventory),'archive_bytes':archive.stat().st_size}))
