"""Prepare a regression for rejecting only exactly unchanged exchange trials."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,sys
root=Path(__file__).resolve().parents[1];out=root/'output/h5-exact-reject-probe-20261018'
old=root/'output/h5-larger-return-probe-20261018';out.mkdir()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(root/'benchmarks/results/h5-exact-state-20261018/layout-checks.json')['internal_exact_pairs']==1
for arm in ['baseline','candidate']:shutil.copytree(old/arm,out/arm)
shutil.copyfile(old/'baseline-observer.exe',out/'baseline-observer.exe')
rel='crates/core/src/sheets/vstrip/exchange.rs';source=root/'output/h5-exact-state-20261018/workspace'/rel
observed=source.read_text(encoding='utf-8');path=out/'candidate'/rel;text=path.read_text(encoding='utf-8')
begin=observed.index('// Diagnostic only: exact bits');end=observed.index('fn exchange_increases_material(',begin)
helper=observed[begin:end].replace('// Diagnostic only: exact bits','// Conservative equality: exact bits')
assert text.count('fn exchange_increases_material(')==1;text=text.replace('fn exchange_increases_material(',helper+'fn exchange_increases_material(')
start=observed.index('    // BEGIN exact-state observation tests');end=observed.index('    // END exact-state observation tests',start)+len('    // END exact-state observation tests')
tests=observed[start:end]
needle='    fn rectangle(id: &str, width: f64, height: f64) -> Part {';assert text.count(needle)==1;text=text.replace(needle,tests+'\n\n'+needle)
test='''
    #[test]
    fn exact_duplicate_rejection_preserves_incumbent_and_disabled_boundaries() {
        let (job, layout) = equal_inventory_fixture(false);
        for seed in 0..4 {
            for (enabled, expired) in [(true,false),(false,false),(true,true)] {
                let (moved, after, stats)=exercise(&job,&layout,seed,enabled,expired,0);
                eprintln!("EXACT_REJECT_WITNESS {}",serde_json::json!({
                    "job":&job,"before":&layout,"after":&after,"seed":seed,
                    "enabled":enabled,"expired":expired,"moved":moved,"stats":&stats
                }));
                assert_eq!(moved,0);
                assert_eq!(stats.directed_exchanges,0);
                if enabled && !expired {
                    assert!(stats.exact_state_exchange_rejections>0,
                        "The observed identical trial must reject before full validation: {stats:?}");
                    assert!(stats.exact_state_exchange_rejections<=stats.neutral_exchange_rejections);
                } else {
                    assert_eq!(stats.exact_state_exchange_rejections,0);
                    assert_eq!(stats.directed_exchange_attempts,0);
                }
            }
        }
    }
'''
pos=text.rindex('\n}');text=text[:pos]+test+text[pos:];path.write_text(text,encoding='utf-8',newline='\n')
stats='crates/core/src/sheets.rs';p=out/'candidate'/stats;s=p.read_text(encoding='utf-8');needle='    pub neutral_exchange_rejections: u64,'
assert s.count(needle)==1;s=s.replace(needle,needle+'\n    #[serde(skip_serializing_if = "is_zero")]\n    pub exact_state_exchange_rejections: u64,');p.write_text(s,encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
rows={arm:[{'path':p.relative_to(old/arm).as_posix(),'sha256':digest(p)} for p in sorted((old/arm).rglob('*')) if p.is_file()] for arm in ['baseline','candidate']}
plan={'utc':datetime.now(timezone.utc).isoformat(),'purpose':__doc__,'old_probe':str(old),'old_source_files':rows,
    'changed_files':[rel,stats],'added_files':{},'production_digest':source_digest(),'baseline_observer_sha256':digest(out/'baseline-observer.exe'),
    'target':str(root/'output/h5-exact-reject-target-20261018'),'unchanged_original_tests':113,'copied_identity_tests':3,'new_branch_regression':1,
    'early_branch_installed':False,'first_expected_failure':'exact_duplicate_rejection_preserves_incumbent_and_disabled_boundaries',
    'held_out_access':False,'whole_job_acceptance_guards_preserved':True}
(out/'preparation.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
builder=(root/'output/build_h5_larger_return.py').read_text(encoding='utf-8').replace('h5-larger-return','h5-exact-reject')
(root/'output/build_h5_exact_reject.py').write_text(builder,encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'prepare.py')
print(json.dumps({'candidate_prepared':True,'expected_tests':117,'early_branch_installed':False,'production_changed':False}))
