"""Install the conservative early rejection after the preserved red regression."""
from pathlib import Path
from hashlib import sha256
import difflib,json,re,shutil,subprocess
root=Path(__file__).resolve().parents[1];out=root/'output/h5-exact-reject-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
red=load(out/'before-early-branch/checks.json');assert red['expected_runtime_failure']
assert digest(out/'before-early-branch/expected-failure.log')==red['log_sha256']
plan=load(out/'preparation.json');rel='crates/core/src/sheets/vstrip/exchange.rs';p=out/'candidate'/rel
assert p.read_bytes()==(out/'before-early-branch'/rel).read_bytes()
text=p.read_text(encoding='utf-8');needle='                    let report = self.exchange_report(strip, frozen, &trial, shape)?;'
branch='''                    if exact_physical_state(&sep.layout, &trial) {
                        self.stats.neutral_exchange_rejections += 1;
                        self.stats.exact_state_exchange_rejections += 1;
                        continue;
                    }
'''
assert text.count(needle)==1;text=text.replace(needle,branch+needle);p.write_text(text,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=out/'candidate',check=True)
after=p.read_text(encoding='utf-8');before=(Path(plan['old_probe'])/'candidate'/rel).read_text(encoding='utf-8')
start=after.index('// Conservative equality: exact bits');end=after.index('fn exchange_increases_material(',start);helper=after[start:end]
runtime=after.split('#[cfg(test)]')[0];assert runtime.count(helper)==runtime.count(branch)==1
assert runtime.replace(helper,'').replace(branch,'')==before.split('#[cfg(test)]')[0]
def functions(s):
    s=s.split('#[cfg(test)]',1)[1];matches=list(re.finditer(r'^    fn (\w+)\(',s,re.M));result={}
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(s);chunk=s[m.start():end]
        result[m[1]]=chunk[:chunk.rfind('\n    }')+6]
    return result
a=functions(before);b=functions(after)
for name,body in a.items():assert b[name]==body,name
assert len(set(b)-set(a))==4
patch=[]
for name in plan['changed_files']:
    left=(Path(plan['old_probe'])/'candidate'/name).read_text(encoding='utf-8');right=(out/'candidate'/name).read_text(encoding='utf-8')
    patch.extend(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='larger-return/'+name,tofile='exact-reject/'+name))
(out/'candidate.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
record={'early_rejection_installed':True,'all_original_exchange_test_helpers_exact':list(a),'all_113_original_tests_unchanged':True,
    'new_tests':4,'other_exchange_runtime_exact':True,'branch':branch,'predicate':helper,'no_accepted_validation_bypass':True,
    'no_budget_change':True,'expected_regression_failure_preserved':True,'source_sha256':digest(p)}
(out/'source-checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,out/'apply.py');print(json.dumps({k:v for k,v in record.items() if k not in ['branch','predicate','all_original_exchange_test_helpers_exact']}))
