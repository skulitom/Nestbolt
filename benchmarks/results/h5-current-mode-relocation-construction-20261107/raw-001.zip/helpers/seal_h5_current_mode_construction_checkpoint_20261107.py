"""Archive the bounded current-mode construction and complete response replay."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
    "NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-current-mode-relocation-construction-20261107'",
    "BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107';F=BASE/'response-audit';D=BASE/'outcome-diagnostic'",
    "PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-current-mode-relocation-preflight-20261107'",
    "front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==2 and front['best_original']['pair_failures']==47 and not front['source_valid66']",
    "folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,ROOT/'output/h5-current-mode-relocation-response-audit-process-20261107',ROOT/'output/h5-current-mode-relocation-main-sync-20261107']",
    "['*h5*mixed*mode*20261107.py']":"['*h5*current*mode*20261107.py']",
    "'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_current_mode_construction_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
    "'next-step-correction.json']":"'next-step-correction.json','plan-v2.json','center-combination-coverage.json']",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
runtime=load(BASE/'runtime-bindings.json')
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(F/'checks.json','response-audit.json'),(F/'epoch-reconciliation.json','epoch-reconciliation.json'),(F/'epoch-01/original-source-checks.json','best-original-source-checks.json'),(F/'epoch-01-selection/checks.json','runtime-selection-audit.json'),(BASE/'search/epoch-01/selection.json','runtime-selection.json'),(BASE/'search/plan.json','search-plan.json'),(BASE/'search/result.json','closed-search-result.json'),(BASE/'search/process.json','closed-search-process.json'),(D/'checks.json','outcome-diagnostic.json'),(D/'family-failures.json','family-failures.json'),(D/'prior-comparisons.json','prior-comparisons.json'),(D/'center-combination-coverage.json','center-combination-coverage.json'),(BASE/'search/main-ci-at-review.json','main-ci-at-review.json'),(ROOT/'output/h5-current-mode-relocation-main-sync-20261107/receipt.json','prior-main-push-receipt.json'),(ROOT/'output/h5-current-mode-relocation-response-audit-process-20261107/process.json','response-audit-process.json')]
for epoch in [0,1]:copies.append((BASE/f'search/epoch-{epoch:02d}/closed-problem.json',f'closed-problem-{epoch:02d}.json'))
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'alternate_center_combinations_preflight_required','finding':'The complete current-mode pipeline closes at its frozen two-call maximum with47source-pair failures and20008.826544255266mm2original overlap. Coverage of the original-source and runtime pools independently confirms that each owner/mode contributes only its individually best scored center to every joint proposal. Joint mutual areas are recomputed correctly, but alternative scored centers are never combined. This is an omitted finite neighborhood, not evidence of a better placement or feasibility.',
    'proposal':'Assess a separately versioned finite source neighborhood retaining the first two distinct centers by the existing individual score/XY/local-index ordering for each physical owner/mode, and scoring every resulting single/joint center combination. Keep the existing9x9grid/clamped trials, original A/W state, geometry, objective and weights unchanged. The proposed count is23419raw proposals (1current,222singles,23196joints), still only2854physical vectors. No such broader scores, selected state or search are prepared.',
    'requirements':['Use only original unoptimized A/W source coordinates/angles/weights. Reuse the verified original-source9102trial table only with exact hashes and the entire27.20468939933926second preparation charge. Current and historical optimized/stopping states remain validation-only.','Retain every raw placement; independently reconstruct every new full objective score and every per-key minimum. Both members of a joint move must replace their mutual pair exactly once under all528weighted original/clearance terms and15coefficient1auxiliary terms. Preserve current-mode choices and continuous cog angles.','Exclude all16closed complete objective/physical-mode/weight keys. Coordinate combinations do not create new keys. Require a strict1e-6improvement from the original baseline, and retain raw single/joint diagnostics. Do not reopen either call or this finite pipeline.','Preflight larger-pool cooperative deadlines and partial grouping/proposal serialization before any call. Preserve incomplete evidence and select nothing on interruption. Charge all additional construction, including failed preparation, and freeze a new finite60/90second contract with the source reserve based on actual measured cost.','Do not extend the call count, tune objective/grid/weights, or seed from audit/optimized results to rescue a failed attempt. Any possible initializer still needs model/domain and source readback. Full66validity is required before native checks, material claims or H5credit.'],
    'source_only_preparation_seconds_before_new_work':front['complete_preparation_seconds'],'closed_augmented_problems':9,'closed_prior_weighted_problems':7,'new_center_combinations_prepared':False,'new_source_state_prepared':False,'new_optimizer_calls':0,'remaining_fixed_arrangements':4,'remaining_allocation_candidates':440,'H5_complete':False})
diag=load(D/'checks.json');cover=load(D/'center-combination-coverage.json');ci=load(BASE/'search/main-ci-at-review.json');success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs']);audit_process=load(OUT/'response-audit-process.json');result=load(BASE/'search/result.json');selected=load(BASE/'search/epoch-01/selection.json')['accepted_choice']
assert selected['changes']==[[9,0],[11,0]] and result['status']=='MAXIMUM_EPOCHS' and audit_process['passed']
source_cover,runtime_cover=cover['contexts'];assert cover['passed'] and all(r['one_individually_chosen_center_per_owner_mode'] for r in cover['contexts'])
rows='\n'.join(f"| {r['epoch']} | {r['function_evaluations']} | {r['saved_points']} | {r['source_readbacks']['original']['original_overlap_mm2']:,.6f} | {r['source_readbacks']['original']['pair_failures']} |" for r in result['epochs'])
report=f'''# Current-mode relocation construction — 2026-11-07

The broader current-mode pipeline closes after its frozen **two-call maximum**.
Its best candidate has **20,008.826544 mm² original overlap** and still fails
**47 source-pair checks**. All fixed-part and stock checks pass, but no valid
full66 packing is established. H2/H5 remain open at **60% completed milestone
weight**. No native validation or allocation exclusion follows.

## Finite contract and complete replay

The [audited source preflight](h5-current-mode-relocation-preflight-20261107.md)
supplies the fresh unoptimized initializer, with **27.204689 s** of retained
source preparation. [The frozen contract]({NAME}/search-plan.json) allows at most
two 8 s calls, shortening a slice at the 54 s source-reserve boundary. Both
neighborhood scoring and key grouping stop cooperatively at 52 s. Algorithm
and shared limits remain preparation-inclusive 60/90 s, inside the verified
2 GiB Windows Job. The larger measured selector cost motivates the two-call
ceiling; no count or deadline is extended.

All fourteen previous problem identities are excluded. Both
[new]({NAME}/closed-problem-00.json) [identities]({NAME}/closed-problem-01.json)
close after their sole call. The [one runtime selection]({NAME}/runtime-selection.json)
changes insert owners 9 and 11 to mode 0 after the unchanged bounded area-only
weight update. Its chosen score is 91,297.424785 mm² against a current score
of 138,890.837795 mm² under the same updated weights. Auxiliary coefficients
remain exactly 1. All fifteen cog angles stay continuous.

| Epoch | Optimizer evaluations | Saved improvements | Best original overlap (mm²) | Failed source pairs |
| --- | ---: | ---: | ---: | ---: |
{rows}

The three winner streams coincide within each epoch, and all six full66 outputs
are preserved. [Complete response replay]({NAME}/response-audit.json) verifies
**{front['total_evaluation_records_verified']} evaluation records**,
**{front['saved_points_verified']} saved points**, all **528 updated coefficients**,
and every dynamic model. [Runtime neighborhood reconstruction]({NAME}/runtime-selection-audit.json)
checks all **9,102 nominal centers**, **5,911 raw proposals** and **2,854 key minima**:
**15,013 independently rebuilt full scores**, including current modes. Raw
placements are grouped by complete objective/physical-mode/weight identity;
coordinates alone never authorize another call.

Every winner readback reconstructs all 66 originals, 1,380 same-sheet pairs,
264 stock edges, 90 cutouts and 10,026 hole vertices. The
[failed source pairs]({NAME}/best-original-source-checks.json) remain visible.
Maximum independent evaluation score error is
{front['max_independent_score_error_mm2']:.3e} mm²; maximum winner scalar gradient
error is {front['max_winner_scalar_gradient_error_mm']:.3e} mm under the documented
boundary conventions. No blanket smoothness claim follows.

Preparation-inclusive algorithm/shared totals are
**{front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s**. Slice overruns
are **{front['slice_overruns_seconds'][0]:.6f}** and
**{front['slice_overruns_seconds'][1]:.6f} s**, preserved inside the overall limits.
[All five search processes close]({NAME}/closed-search-process.json), with peak
aggregate committed memory of 120,455,168 bytes. The separate
[independent audit]({NAME}/response-audit-process.json) closes in
{audit_process['complete_seconds']:.6f} s. The finite pipeline remains closed.

## Residual geometry and center-combination coverage

[Read-only diagnosis]({NAME}/outcome-diagnostic.json) records
{diag['positive_area_pairs']} positive original/clearance pair terms,
{diag['flat_available_pair_gradient_count']} flat available pair gradients,
{diag['bracket_bracket_source_failures']} bracket/bracket source failures and
{diag['cog_lower_y_negative_gradient_blocked']} cogs whose negative-gradient
descent is blocked by their lower-y hard bound. [Family composition]({NAME}/family-failures.json)
and [historical comparisons]({NAME}/prior-comparisons.json) preserve unsuccessful
outcomes. Lower overlap than some earlier runs does not establish packing
validity or a causal algorithm improvement.

[Complete center-combination coverage]({NAME}/center-combination-coverage.json)
checks the original source and runtime pools. Every owner/mode scores 82 nominal
centers, but contributes only its single individually best center to all
proposals. Thus each joint proposal recomputes its mutual pair correctly,
while never considering another combination of already scored centers.
Among the 5,799 joint proposals, the two moved originals fail mutual clearance
in **{source_cover['joint_proposals_with_mutual_clearance_failure']} source** and
**{runtime_cover['joint_proposals_with_mutual_clearance_failure']} runtime** cases.
These measurements identify missing combinations; they do not prove any omitted
combination would improve the objective or produce a valid layout.

[Next]({NAME}/next-step.json), assess retaining two distinct scored centers per
owner/mode in a separately versioned original-source neighborhood. Prospective
coverage is 23,419 raw proposals and still 2,854 complete physical vectors.
All sixteen closed keys must remain excluded, every new full score and per-key
minimum must replay, and added preparation must fit a newly frozen finite
contract. No broader scores, selected state or search are prepared. Existing
optimized winners remain validation only. Four earlier arrangements and all
440 allocation candidates remain unresolved.

Both preceding checkpoints reached main **b8a14317** through an ordinary atomic
push after all six preceding checks and the aggregate passed, preserving all
52 protected files. [The push receipt]({NAME}/prior-main-push-receipt.json) is
retained. [Fresh main CI at review]({NAME}/main-ci-at-review.json) has {success}
passed jobs and {live} live jobs; this checkpoint awaits the ordinary push gate.
Product code, README claims and releases remain unchanged.

[Archive verification]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) retain complete evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 current-mode relocation construction:** [independent full response and source replay]({{link}}) verifies the frozen two-call pipeline, all {front["total_evaluation_records_verified"]} evaluation records, {front["saved_points_verified"]} saved points, 528 updated coefficients, 9,102 runtime centers, 5,911 proposals and 2,854 complete key minima. Both calls close at the declared maximum. The best candidate has 20,008.826544 mm² original overlap and 47 failed source pairs; fixed-part and stock checks pass. All six full66 winner outputs replay; no valid packing or native call follows. Complete preparation remains 27.204689 s and algorithm/shared totals are {front["algorithm_seconds"]:.6f}/{front["shared_seconds"]:.6f} s. Both slice overruns are preserved and all processes close. A read-only coverage audit verifies that each owner/mode contributes only one individually chosen center to joint moves, omitting combinations of alternate scored centers. Next assess two distinct centers per owner/mode from the original source with complete score/key/deadline preflight; no broader state or search is prepared. All sixteen keys and this finite pipeline remain closed. Four earlier arrangements and 440 allocations remain; H2/H5 stay at 60%. Prior checkpoints reached main b8a14317 normally, preserving 52 files; fresh CI has {success} passed jobs and {live} live jobs at review. Product code, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [current-mode relocation construction](../benchmarks/results/{NAME}.md).
The broader current-mode pipeline closes at its frozen two-call maximum.
Independent replay verifies all {front['total_evaluation_records_verified']} evaluation records, {front['saved_points_verified']} saved points, 528 updated
coefficients, 9,102 runtime centers, 5,911 proposals and 2,854 complete key minima.
The best candidate has 20,008.826544 mm² original overlap and 47 failing pairs;
all fixed-part and stock checks pass. Six full66 winner outputs replay, but no
valid packing is established. Preparation is 27.204689 s and algorithm/shared
totals are {front['algorithm_seconds']:.6f}/{front['shared_seconds']:.6f} s; both slice overruns remain and all processes close.
Read-only coverage confirms that each owner/mode contributes only one scored
center to joint moves. Next assess combinations of two distinct scored centers
from the original source, with complete score/key/deadline preflight. No broader
state or search is prepared. All sixteen keys and prior pipelines stay closed.
Four earlier arrangements and 440 allocations remain; H2/H5 stay open at 60%.
Both preceding checkpoints reached main b8a14317 normally, preserving 52 files.
Fresh CI has {success} passed jobs and {live} live jobs at review; this checkpoint awaits the
ordinary push gate. Product code, README and releases remain unchanged.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_references':len(external),'source_bindings':len(bindings)})
