"""Read-only family failures, boundary obstruction and residual flat terms."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,time
import numpy as np
from shapely.affinity import translate
from h5_bracket_augmented_objective_20261107 import Objective
from h5_original_overlap_gradient_v2_20261107 import moving_boundary_gradient
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107';P=ROOT/'output/h5-adaptive-augmented-preflight-20261107';N=ROOT/'output/h5-augmented-conditional-neighbors-20261107';A=ROOT/'output/h5-bracket-augmented-model-20261107';OUT=BASE/'outcome-diagnostic';B=ROOT/'output/h5-bracket-collision-depth-20261107';R=ROOT/'output/h5-weighted-relocated-neighbors-20261107';W=ROOT/'output/h5-weighted-mixed-rows-model-20261107'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();start=time.perf_counter();checked=load(BASE/'response-audit/checks.json');assert checked['passed'] and checked['best_original']['epoch']==1
inputs=[Path(__file__)]+[BASE/n for n in ['response-audit/checks.json','response-audit/epoch-01/original-source-checks.json','search/epoch-01/response.json','search/epoch-01/model.json']]+[A/'objective-identity.json',A/'response-audit/checks.json',N/'response-audit/checks.json',P/'response-audit/checks.json',B/'regions.json',R/'response-audit/checks.json',W/'response-audit/checks.json',Q/'response-audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Read-only composition of source failures, hard-bound descent obstruction and every positive original/clearance pair gradient in the closed original-area winner. Test only flat pair terms with the earlier fixed±.001/.1/1/5mm feasible translation probes. Compare prior audited outcomes without attributing a causal improvement. No candidate change, new initializer, search or allocation exclusion.','gradient_zero_tolerance':1e-7,'translation_steps_mm':[.001,.1,1.,5.],'optimizer_calls':0})
response=load(BASE/'search/epoch-01/response.json');assert all(v['auxiliary_bracket_depth_mm2']==0 for v in response['source_readbacks'].values());model=load(BASE/'search/epoch-01/model.json');x=response['winners']['original']['values'];gradient=response['winners']['original']['gradient'];source=load(BASE/'response-audit/epoch-01/original-source-checks.json');obj=Objective(model,load(B/'regions.json'),load(A/'objective-identity.json'));shapes=obj.geometry(x);groups=defaultdict(lambda:{'pair_failures':0,'positive_intersections':0,'overlap_mm2':0.})
for pair in source['pairs']:
    if pair['passed']:continue
    group=groups['/'.join(sorted(k[0] for k in pair['keys']))];group['pair_failures']+=1;group['positive_intersections']+=int(pair['intersection_area_mm2']>0);group['overlap_mm2']+=pair['intersection_area_mm2']
owners=[]
for i,o in enumerate(model['owners']):
    axes=[]
    for k in [2*i,2*i+1]:
        lo,hi=model['bounds'][k];bound='lower' if abs(x[k]-lo)<1e-7 else 'upper' if abs(x[k]-hi)<1e-7 else None;gg=gradient[k]
        axes.append({'axis':'x' if k%2==0 else 'y','bound':bound,'gradient':gg,'negative_gradient_blocked':bool((bound=='lower' and gg>1e-8) or (bound=='upper' and gg< -1e-8))})
    owners.append({'owner':i,'identity':o['identity'],'mode':o['mode'],'axes':axes})
positive=[];flat=[]
for index,(i,j) in enumerate(model['pairs']):
    areas=[shapes[k][i][1].intersection(shapes[k][j][1]).area for k in [0,1]];loss=sum(areas)
    if loss<=0:continue
    available=[];gradients=[]
    for own,other in [(i,j),(j,i)]:
        gg=np.zeros(3)
        for k in [0,1]:gg+=moving_boundary_gradient(shapes[k][own][1],shapes[k][other][1],x[2*own:2*own+2])[0]
        gradients.append(gg.tolist());available.extend(gg[:2]);o=model['owners'][own]
        if o['angle_coordinate'] is not None:available.append(gg[2]/o['angle_scale_mm'])
    record={'pair_index':index,'owners':[i,j],'identities':[model['owners'][i]['identity'],model['owners'][j]['identity']],'original_overlap_mm2':areas[0],'pair_area_loss_mm2':loss,'scalar_pair_gradients':gradients,'available_coordinate_gradient_zero':bool(max(abs(z) for z in available)<1e-7)}
    if record['available_coordinate_gradient_zero']:
        probes=[]
        for own,other in [(i,j),(j,i)]:
            for axis in [0,1]:
                k=2*own+axis
                for h in [.001,.1,1.,5.]:
                    for sign in [-1,1]:
                        delta=h*sign
                        if not model['bounds'][k][0]<=x[k]+delta<=model['bounds'][k][1]:continue
                        moved=sum(translate(shapes[level][own][1],xoff=delta if axis==0 else 0,yoff=delta if axis==1 else 0).intersection(shapes[level][other][1]).area for level in [0,1])
                        probes.append({'owner':own,'axis':axis,'delta_mm':delta,'pair_area_loss_mm2':moved,'change_mm2':moved-loss})
        record['probes']=probes;record['all_feasible_probes_flat']=bool(probes) and all(abs(p['change_mm2'])<1e-7 for p in probes);flat.append(record)
    positive.append(record)
comparisons=[]
for name,parent in [('prior_weighted',W),('prior_conditional_relocation',R),('prior_augmented',A),('prior_augmented_conditional',N),('prior_adaptive_augmented',P),('prior_best_admissible',Q)]:
    prior=load(parent/'response-audit/checks.json');comparisons.append({'prior':name,'prior_pair_failures':prior.get('source_pair_failures',prior.get('best_original_pair_failures',prior.get('best_original',{}).get('pair_failures'))),'current_pair_failures':source['pair_failures'],'prior_original_overlap_mm2':prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'current_original_overlap_mm2':checked['best_original']['score_mm2'],'overlap_change_mm2':checked['best_original']['score_mm2']-prior.get('original_overlap_mm2',prior.get('best_original_overlap_mm2',prior.get('best_original',{}).get('score_mm2'))),'comparable_bounded_experiment':False,'packing_improvement_claimed':False})
assert sum(r['pair_failures'] for r in groups.values())==source['pair_failures'] and abs(sum(r['overlap_mm2'] for r in groups.values())-checked['best_original']['score_mm2'])<1e-7
cogs=[o for o in owners if o['identity'][0]=='cog']
write(OUT/'family-failures.json',dict(groups));write(OUT/'owner-bound-controls.json',owners);write(OUT/'positive-pair-gradients.json',positive);write(OUT/'flat-pair-probes.json',flat);write(OUT/'prior-comparisons.json',comparisons)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_pair_failures':source['pair_failures'],'original_overlap_mm2':checked['best_original']['score_mm2'],'positive_area_pairs':len(positive),'flat_available_pair_gradient_count':len(flat),'flat_pairs_with_all_probes_flat':sum(r['all_feasible_probes_flat'] for r in flat),'bounded_translation_probes':sum(len(r['probes']) for r in flat),'auxiliary_bracket_depth_mm2':response['source_readbacks']['original']['auxiliary_bracket_depth_mm2'],'bracket_bracket_source_failures':groups.get('bracket/bracket',{}).get('pair_failures',0),'cog_lower_y_bounds_active':sum(o['axes'][1]['bound']=='lower' for o in cogs),'cog_lower_y_negative_gradient_blocked':sum(o['axes'][1]['bound']=='lower' and o['axes'][1]['negative_gradient_blocked'] for o in cogs),'optimizer_calls':0,'candidate_changed':False,'any_allocation_excluded':False,'H5_complete':False})
print(load(OUT/'checks.json'))


# Executed after the independent complete response audit and residual diagnosis.
# These are reads of recorded centers/proposals; no alternate candidate is made.
from shapely.geometry import Polygon
from math import cos,sin
from collections import Counter
lib=load(A/'library.json');job_path=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';parts={p['id']:p for p in load(job_path)['parts']};coverage=[];coverage_bindings={job_path.relative_to(ROOT).as_posix():digest(job_path)}
for label,state_path,pool in [('original_source',A/'initial-state.json',BASE),('runtime_1',BASE/'search/epoch-01/opened.json',BASE/'search/epoch-01')]:
    state=load(state_path);modes=state.get('modes',state.get('incoming_modes'));values=state.get('values',state.get('incoming_values'));trials=load(pool/'center-trials.json');selections=load(pool/'center-selections.json');records=load(pool/'neighbors.json');choice=load(pool/'selection.json')['accepted_choice'];assert len(trials)==9102 and len(selections)==111 and len(records)==5911
    selected_centers={(r['owner'],r['mode']):r['selected']['center'] for r in selections};shapes={};options=[]
    for selection in selections:
        i,mi=selection['owner'],selection['mode'];family,_=lib['identities'][i];mode=lib['family_modes'][family][mi];part=parts[family];assert part['geometry'][0]['outer']==lib['families'][family]['original']
        angle=values[66+i-18]/lib['angle_scale_mm'] if family=='cog' else mode['rotation_radians'];c,s=cos(angle),sin(angle);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];cx,cy=selected_centers[i,mi]
        outer=[(sign*(x-px)*c-(y-py)*s+cx,sign*(x-px)*s+(y-py)*c+cy) for x,y in part['geometry'][0]['outer']];shape=Polygon(outer);assert shape.is_valid;shapes[i,mi]=shape
        own=[r for r in trials if (r['owner'],r['mode'])==(i,mi)];unique={tuple(r['center']) for r in own};used={tuple(center) for record in records for change,center in zip(record['changes'],record['centers']) if change==[i,mi]}
        assert len(own)==82 and used=={tuple(selected_centers[i,mi])} and tuple(selected_centers[i,mi]) in unique
        options.append({'owner':i,'mode':mi,'nominal_centers_scored':82,'unique_centers_scored':len(unique),'distinct_centers_used_in_proposals':len(used),'unused_scored_centers':len(unique)-1,'selected_center':selected_centers[i,mi]})
    joints=[];family_counts=Counter()
    for row in records:
        if len(row['changes'])!=2:continue
        first,second=map(tuple,row['changes']);left,right=shapes[first],shapes[second];area=left.intersection(right).area;gap=left.distance(right);clear=left.disjoint(right) and gap>lib['required_pair_gap_mm'];family='/'.join(lib['identities'][i][0] for i,mi in [first,second])
        joints.append({'sequence':row['sequence'],'key':row['key'],'owners_modes':row['changes'],'mutual_original_intersection_mm2':area,'mutual_original_gap_mm':gap,'mutual_clearance_passed':clear,'selected_proposal':choice is not None and row['sequence']==choice['sequence']})
        if not clear:family_counts[family]+=1
    assert len(joints)==5799;write(OUT/f'{label}-joint-mutual-source-pairs.json',joints)
    coverage.append({'context':label,'owner_mode_options':options,'raw_proposals':5911,'joint_proposals':len(joints),'joint_proposals_with_mutual_original_intersection':sum(r['mutual_original_intersection_mm2']>0 for r in joints),'joint_proposals_with_mutual_clearance_failure':sum(not r['mutual_clearance_passed'] for r in joints),'mutual_failures_by_family':dict(family_counts),'selected_joint_pair':next((r for r in joints if r['selected_proposal']),None),'one_individually_chosen_center_per_owner_mode':True,'joint_center_cross_product_evaluated':False,'new_candidate_created':False})
    for path in [state_path]+[pool/n for n in ['center-trials.json','center-selections.json','neighbors.json','selection.json']]:coverage_bindings[path.relative_to(ROOT).as_posix()]=digest(path)
write(OUT/'center-combination-coverage.json',{'passed':True,'inputs':coverage_bindings,'contexts':coverage,'interpretation':'Every owner/mode scores82nominal centers but contributes only its individual best center to every single/joint proposal. Joint proposals correctly recompute the mutual pair once, but never combine alternate scored centers for either owner. The recorded mutual collisions quantify this omitted finite center-combination neighborhood; they do not prove any alternate combination is better or a valid packing exists. Any broader construction must start from original source, preserve complete key minima/closed-key exclusions, charge all prior preparation and pass independent full-score/deadline checks before one bounded call. No optimized/stopping winner may seed a successor.','optimizer_calls':0,'candidate_changed':False,'new_initializer_prepared':False,'closed_pipeline_resumed':False})
