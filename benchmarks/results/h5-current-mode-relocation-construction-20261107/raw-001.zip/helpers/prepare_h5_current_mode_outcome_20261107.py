"""Version the residual diagnosis and add exact center-combination coverage."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/diagnose_h5_best_admissible_augmented_outcome_20261107.py').read_text(encoding='utf-8')
source=source[:source.index('\n\nfrom h5_augmented_selection_readback_20261107 import independent_classes')]
changes={
    "BASE=ROOT/'output/h5-best-admissible-augmented-preflight-20261107'":"BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107';Q=ROOT/'output/h5-best-admissible-augmented-preflight-20261107'",
    "checked['best_original']['epoch']==2":"checked['best_original']['epoch']==1",
    'epoch-02':'epoch-01',
    "W/'response-audit/checks.json']":"W/'response-audit/checks.json',Q/'response-audit/checks.json']",
    "('prior_adaptive_augmented',P)]":"('prior_adaptive_augmented',P),('prior_best_admissible',Q)]",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
extra=(ROOT/'output/h5_current_mode_center_coverage_20261107.py').read_text(encoding='utf-8')
source+='\n\n'+extra
compile(source,'diagnose_h5_current_mode_outcome_20261107.py','exec')
with (ROOT/'output/diagnose_h5_current_mode_outcome_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
