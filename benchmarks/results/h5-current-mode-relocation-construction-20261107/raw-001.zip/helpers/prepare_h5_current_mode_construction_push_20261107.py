"""Pin the next ordinary push to the newly published main and its CI run."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/push_h5_current_mode_checkpoints_20261107.py').read_text(encoding='utf-8')
changes={
    'h5-current-mode-relocation-main-sync-20261107':'h5-current-mode-construction-main-sync-20261107',
    'a69021b6f67de0cf1c01cbf3f2d33209d5cca4b9':'b8a14317a240988eb22b58a238e712bce2f0e061',
    '42377560004':'42380700484',
    "prefixes=('benchmarks/results/h5-best-admissible-augmented-construction-20261107','benchmarks/results/h5-current-mode-relocation-preflight-20261107')":"prefixes=('benchmarks/results/h5-current-mode-relocation-construction-20261107',)",
    "['h5-best-admissible-augmented-construction-20261107','h5-current-mode-relocation-preflight-20261107']":"['h5-current-mode-relocation-construction-20261107']",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
compile(source,'push_h5_current_mode_construction_checkpoints_20261107.py','exec')
with (ROOT/'output/push_h5_current_mode_construction_checkpoints_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
