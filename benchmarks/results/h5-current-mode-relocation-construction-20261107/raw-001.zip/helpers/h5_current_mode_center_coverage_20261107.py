# Executed after the independent complete response audit and residual diagnosis.
# These are reads of recorded centers/proposals; no alternate candidate is made.
from shapely.geometry import Polygon
from math import cos,sin
from collections import Counter
lib=load(A/'library.json');job_path=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';parts={p['id']:p for p in load(job_path)['parts']};coverage=[];coverage_bindings={job_path.relative_to(ROOT).as_posix():digest(job_path)}
for label,state_path,pool in [('original_source',A/'initial-state.json',BASE),('runtime_1',BASE/'search/epoch-01/opened.json',BASE/'search/epoch-01')]:
    state=load(state_path);modes=state.get('modes',state.get('incoming_modes'));values=state.get('values',state.get('incoming_values'));trials=load(pool/'center-trials.json');selections=load(pool/'center-selections.json');records=load(pool/'neighbors.json');choice=load(pool/'selection.json')['accepted_choice'];assert len(trials)==9102 and len(selections)==111 and len(records)==5911
    selected_centers={(r['owner'],r['mode']):r['selected']['center'] for r in selections};shapes={};options=[]
    for selection in selections:
        i,mi=selection['owner'],selection['mode'];family,_=lib['identities'][i];mode=lib['family_modes'][family][mi];part=parts[family];assert part['geometry'][0]['outer']==lib['families'][family]['original']
        angle=values[66+i-18]/lib['angle_scale_mm'] if family=='cog' else mode['rotation_radians'];c,s=cos(angle),sin(angle);sign=-1 if mode['mirrored'] else 1;px,py=lib['families'][family]['source_center'];cx,cy=selected_centers[i,mi]
        outer=[(sign*(x-px)*c-(y-py)*s+cx,sign*(x-px)*s+(y-py)*c+cy) for x,y in part['geometry'][0]['outer']];shape=Polygon(outer);assert shape.is_valid;shapes[i,mi]=shape
        own=[r for r in trials if (r['owner'],r['mode'])==(i,mi)];unique={tuple(r['center']) for r in own};used={tuple(center) for record in records for change,center in zip(record['changes'],record['centers']) if change==[i,mi]}
        assert len(own)==82 and used=={tuple(selected_centers[i,mi])} and tuple(selected_centers[i,mi]) in unique
        options.append({'owner':i,'mode':mi,'nominal_centers_scored':82,'unique_centers_scored':len(unique),'distinct_centers_used_in_proposals':len(used),'unused_scored_centers':len(unique)-1,'selected_center':selected_centers[i,mi]})
    joints=[];family_counts=Counter()
    for row in records:
        if len(row['changes'])!=2:continue
        first,second=map(tuple,row['changes']);left,right=shapes[first],shapes[second];area=left.intersection(right).area;gap=left.distance(right);clear=left.disjoint(right) and gap>lib['required_pair_gap_mm'];family='/'.join(lib['identities'][i][0] for i,mi in [first,second])
        joints.append({'sequence':row['sequence'],'key':row['key'],'owners_modes':row['changes'],'mutual_original_intersection_mm2':area,'mutual_original_gap_mm':gap,'mutual_clearance_passed':clear,'selected_proposal':choice is not None and row['sequence']==choice['sequence']})
        if not clear:family_counts[family]+=1
    assert len(joints)==5799;write(OUT/f'{label}-joint-mutual-source-pairs.json',joints)
    coverage.append({'context':label,'owner_mode_options':options,'raw_proposals':5911,'joint_proposals':len(joints),'joint_proposals_with_mutual_original_intersection':sum(r['mutual_original_intersection_mm2']>0 for r in joints),'joint_proposals_with_mutual_clearance_failure':sum(not r['mutual_clearance_passed'] for r in joints),'mutual_failures_by_family':dict(family_counts),'selected_joint_pair':next((r for r in joints if r['selected_proposal']),None),'one_individually_chosen_center_per_owner_mode':True,'joint_center_cross_product_evaluated':False,'new_candidate_created':False})
    for path in [state_path]+[pool/n for n in ['center-trials.json','center-selections.json','neighbors.json','selection.json']]:coverage_bindings[path.relative_to(ROOT).as_posix()]=digest(path)
write(OUT/'center-combination-coverage.json',{'passed':True,'inputs':coverage_bindings,'contexts':coverage,'interpretation':'Every owner/mode scores82nominal centers but contributes only its individual best center to every single/joint proposal. Joint proposals correctly recompute the mutual pair once, but never combine alternate scored centers for either owner. The recorded mutual collisions quantify this omitted finite center-combination neighborhood; they do not prove any alternate combination is better or a valid packing exists. Any broader construction must start from original source, preserve complete key minima/closed-key exclusions, charge all prior preparation and pass independent full-score/deadline checks before one bounded call. No optimized/stopping winner may seed a successor.','optimizer_calls':0,'candidate_changed':False,'new_initializer_prepared':False,'closed_pipeline_resumed':False})
