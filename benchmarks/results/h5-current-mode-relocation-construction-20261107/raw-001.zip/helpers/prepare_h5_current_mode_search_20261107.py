"""Version a two-call finite pipeline and full readback for current-mode centers."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
runner=(ROOT/'output/run_h5_best_admissible_augmented_search_20261107.py').read_text(encoding='utf-8')
old_choice="""            selection=choose(records);write(folder/'selection.json',selection)
            if not selection['strictly_improves_current']:stop='NO_IMPROVING_ADMISSIBLE';break"""
new_choice="""            try:
                selection,groups,minima=choose(records,deadline=started+plan['selection_boundary_seconds'])
            except KeySelectionDeadline as exc:
                write(folder/'partial-key-selection.json',exc.evidence);stop='KEY_SELECTION_DEADLINE';break
            write(folder/'selection.json',selection);write(folder/'group-members.json',groups);write(folder/'key-minima.json',minima)
            if not selection['strictly_improves_current']:stop='NO_IMPROVING_ADMISSIBLE';break"""
changes={
    "BASE=ROOT/'output/h5-best-admissible-augmented-preflight-20261107'":"BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107'",
    'from h5_augmented_deadline_neighbors_20261107 import neighbors,rank,apply_neighbor,SelectionDeadline':'from h5_current_mode_relocations_20261107 import neighbors,apply_neighbor,SelectionDeadline',
    'from h5_augmented_admissible_choice_20261107 import choose':'from h5_current_mode_key_choice_20261107 import choose,KeySelectionDeadline',
    old_choice:new_choice,
    "'audit/inherited-controls.json','audit/selected-model-controls.json','audit/choice-policy-controls.json','audit/policy-stop-controls.json'":"'audit/deadline-controls.json','audit/selected-model-controls.json','audit/selection-replay/checks.json','audit/source-domains/checks.json','audit/policy-stop-controls.json'",
    "['h5_augmented_admissible_choice_20261107.py','h5_augmented_admissible_readback_20261107.py','h5_augmented_deadline_neighbors_20261107.py'":"['audit_h5_current_mode_response_20261107.py','run_h5_current_mode_response_stage_20261107.py','h5_current_mode_key_choice_20261107.py','h5_current_mode_key_readback_20261107.py','h5_current_mode_selection_readback_20261107.py','h5_current_mode_relocations_20261107.py'",
    "'maximum_optimizer_calls':3":"'maximum_optimizer_calls':2",
    'Exclude all eleven prior identities':'Exclude all fourteen prior identities',
    'At most three eight-second calls':'At most two eight-second calls',
    'Deadline-aware selection evaluates all6396source centers and2854full augmented proposals; accept the minimum augmented score among all admissible single and joint choices only if it strictly improves current by1e-6; retain both separate rankings and reject incomplete pools. Stop at52seconds during selection, preserving partial evidence with no chosen candidate.':'Deadline-aware selection includes current modes and evaluates all9102source centers and5911raw augmented proposals. Independently audited grouping retains the minimum of every complete2854objective/physical-mode/weight key, excludes all visited keys, and accepts only a strict current-score improvement by1e-6. Keep raw single/joint diagnostics, all group members and key minima. Different coordinates never reopen a key. Stop at52seconds during neighborhood scoring or grouping, preserving partial evidence with no chosen candidate. The27.20468939933926seconds of retained preparation and larger measured selector motivate the two-call ceiling; neither the count nor time boundary can be extended.',
}
for a,b in changes.items():assert a in runner,a;runner=runner.replace(a,b)

audit=(ROOT/'output/audit_h5_best_admissible_augmented_response_20261107.py').read_text(encoding='utf-8')
old_selection="""        legacy=verify_selection(lib,modes,incoming,weights,identity,regions,visited,records,aliases,trials,selections,OUT/f'epoch-{epoch:02d}-selection');selection=load(folder/'selection.json')
        assert all(selection[k]==v for k,v in legacy.items())
        merged=verify_choice(records,load(OUT/f'epoch-{epoch:02d}-selection/proposal-score-controls.json'),selection);write(OUT/f'epoch-{epoch:02d}-merged-choice.json',merged);centers+=len(trials);proposals+=len(records)
        inputs+=[folder/n for n in ['neighbors.json','owner-aliases.json','center-trials.json','center-selections.json','selection.json']]"""
new_selection="""        selection,groups,minima=verify_selection(lib,modes,incoming,weights,identity,regions,visited,records,aliases,trials,selections,OUT/f'epoch-{epoch:02d}-selection');centers+=len(trials);proposals+=len(records)
        inputs+=[folder/n for n in ['neighbors.json','owner-aliases.json','center-trials.json','center-selections.json']]
        if (folder/'partial-key-selection.json').exists():
            captured=load(folder/'partial-key-selection.json');assert not captured['complete'] and captured['status']=='KEY_SELECTION_DEADLINE' and captured['selected_proposal'] is None and captured['optimizer_calls']==0 and result['status']=='KEY_SELECTION_DEADLINE'
            assert captured['group_members']==dict(list(groups.items())[:len(captured['group_members'])]) and captured['key_minima']==minima[:len(captured['key_minima'])]
            checkpoint=captured['checkpoints'];assert checkpoint in [1,2,3,4] and len(captured['group_members'])==(0 if checkpoint==1 else 2854) and len(captured['key_minima'])==(0 if checkpoint<3 else 2854)
            assert captured['observed']>=captured['deadline'] and captured['overrun_seconds']==captured['observed']-captured['deadline'] and not (folder/'optimizer-opened.json').exists() and not (folder/'selection.json').exists()
            partial+=1;inputs.append(folder/'partial-key-selection.json');break
        assert selection==load(folder/'selection.json') and groups==load(folder/'group-members.json') and minima==load(folder/'key-minima.json')
        inputs+=[folder/n for n in ['selection.json','group-members.json','key-minima.json']]"""
changes={
    "BASE=ROOT/'output/h5-best-admissible-augmented-preflight-20261107'":"BASE=ROOT/'output/h5-current-mode-relocation-preflight-20261107'",
    'from h5_augmented_selection_readback_20261107 import verify_selection,independent_classes':'from h5_current_mode_selection_readback_20261107 import verify_selection,independent_classes',
    'from h5_augmented_admissible_readback_20261107 import verify_choice\n':'',
    "['h5_augmented_admissible_readback_20261107.py','h5_adaptive_augmented_epoch_readback_20261107.py','h5_augmented_selection_readback_20261107.py'":"['h5_current_mode_key_readback_20261107.py','h5_adaptive_augmented_epoch_readback_20261107.py','h5_current_mode_selection_readback_20261107.py'",
    'h5_augmented_deadline_neighbors_20261107':'h5_current_mode_relocations_20261107',
    old_selection:new_selection,
    'len(old_closed)==11':'len(old_closed)==14',
    "len(old_closed)==result['historical_closed_keys']==11":"len(old_closed)==result['historical_closed_keys']==14",
    "'prior_closed_keys':11":"'prior_closed_keys':14",
    'len(visited)-len(old_closed)<=3':'len(visited)-len(old_closed)<=2',
    "if result['status']=='MAXIMUM_EPOCHS':assert len(epochs)==3":"if result['status']=='MAXIMUM_EPOCHS':assert len(epochs)==2",
    "plan['maximum_optimizer_calls']==3":"plan['maximum_optimizer_calls']==2",
    "'SELECTION_DEADLINE','NO_IMPROVING_ADMISSIBLE'":"'SELECTION_DEADLINE','KEY_SELECTION_DEADLINE','NO_IMPROVING_ADMISSIBLE'",
    "if result['status']=='SELECTION_DEADLINE':assert partial==1":"if result['status'] in ['SELECTION_DEADLINE','KEY_SELECTION_DEADLINE']:assert partial==1",
}
for a,b in changes.items():assert a in audit,a;audit=audit.replace(a,b)
# Capture exact real interruption timing in both independent partial controls.
old="assert captured['observed']>=captured['deadline'] and not (folder/'optimizer-opened.json').exists()"
new="assert captured['observed']>=captured['deadline'] and captured['overrun_seconds']==captured['observed']-captured['deadline'] and not (folder/'optimizer-opened.json').exists()"
assert old in audit;audit=audit.replace(old,new)
stage=(ROOT/'output/run_h5_current_mode_relocations_stage_20261107.py').read_text(encoding='utf-8')
stage=stage.replace('stage=sys.argv[1]',"stage='response-audit'")
old="{'preparation':('prepare_h5_current_mode_relocations_20261107.py',30),'audit':('audit_h5_current_mode_relocations_20261107.py',1200)}"
assert old in stage;stage=stage.replace(old,"{'response-audit':('audit_h5_current_mode_response_20261107.py',1200)}")
outputs={'run_h5_current_mode_search_20261107.py':runner,'audit_h5_current_mode_response_20261107.py':audit,'run_h5_current_mode_response_stage_20261107.py':stage}
for name,source in outputs.items():compile(source,name,'exec');assert not (ROOT/'output'/name).exists()
for name,source in outputs.items():
    with (ROOT/'output'/name).open('x',encoding='utf-8',newline='\n') as f:f.write(source)
