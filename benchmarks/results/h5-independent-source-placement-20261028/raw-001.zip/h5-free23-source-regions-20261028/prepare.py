"""Prepare convex placement/displacement cells for independent source coordinates."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-free23-source-regions-20261028';OLD=ROOT/'output/h5-oblique24-source-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    from fractions import Fraction as F
    from shapely.geometry import shape,box,mapping
    from shapely.geometry.polygon import orient
    from shapely.ops import unary_union
    import diagnose_h5_concave_gaps as geom
    start=time.perf_counter();records=[];planes=0
    def encode(g,kind,key):
        nonlocal planes
        parts=[p for q in geom.polygons(g) for p in geom.convex_pieces(q)];assert unary_union(parts).equals(g)
        cells=[]
        for p in parts:
            p=orient(p,sign=1);points=list(p.exterior.coords)[:-1];hp=[]
            for a,b in zip(points,points[1:]+points[:1]):
                px,py=map(lambda v:F(str(v)),a);qx,qy=map(lambda v:F(str(v)),b);nx,ny=py-qy,qx-px
                scale=max(abs(nx),abs(ny));assert scale>0;nx/=scale;ny/=scale
                aa=round(nx*10**9);bb=round(ny*10**9)
                error=abs(F(aa)-nx*10**9)*1600000+abs(F(bb)-ny*10**9)*3100000
                target=(nx*px+ny*py)*10**12+error
                cc=-((-target.numerator)//target.denominator)+1
                hp.append([aa,bb,cc]);planes+=1
            cells.append({'geometry':mapping(p),'halfplanes':hp})
        write(OUT/kind/f'{key}.json',{'cells':cells,'domain_geometry':mapping(g)})
        records.append({'kind':kind,'key':key,'cells':len(cells),'halfplanes':sum(len(c['halfplanes']) for c in cells),'area_mm2':g.area})
    modes=load(OLD/'modes.json');assert len(modes)==11;write(OUT/'modes.json',modes)
    source=load(ROOT/'output/h5-short7-7-source-20261028/source63.json')
    fixed=[r for r in source if r['sheet_id']=='sheet-1' or (r['sheet_id']=='sheet-0' and (r['part_id']=='frame' or (r['part_id']=='insert' and 5<=r['copy_index']<=15)))]
    assert len(fixed)==43 and [r for r in fixed if r['sheet_id']=='sheet-0']==[r for r in load(OLD/'fixed42.json') if r['sheet_id']=='sheet-0']
    write(OUT/'fixed43.json',fixed)
    for i in range(11):encode(shape(load(OLD/'free'/f'{i:02d}.json')),'free',f'{i:02d}')
    for i in range(11):
        for j in range(i,11):
            forbidden=shape(load(OLD/'obstacles'/f'{i:02d}-{j:02d}.json'))
            encode(box(-1600,-3100,1600,3100).difference(forbidden),'relative',f'{i:02d}-{j:02d}')
    write(OUT/'cells-summary.json',records)
    write(OUT/'result.json',{'status':'COMPLETE','closed':True,'seconds':time.perf_counter()-start,'source_modes':11,
        'fixed_originals':43,'convex_domains':len(records),'convex_cells':sum(r['cells'] for r in records),'integer_halfplanes':planes,
        'coordinate_grid_um':1,'exact_fraction_inner_halfplanes':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();(OUT/'free').mkdir();(OUT/'relative').mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    inputs=[OLD/'plan.json',OLD/'modes.json',OLD/'fixed42.json',OLD/'preflight/checks.json',ROOT/'output/h5-short7-7-source-20261028/source63.json',
        ROOT/'output/h5-short7-7-source-20261028/audit/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/diagnose_h5_concave_gaps.py']
    inputs+=sorted((OLD/'free').glob('*.json'))+sorted((OLD/'obstacles').glob('*.json'))
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
        'maximum_preparation_seconds':120,'maximum_runs':1,'retry_permitted':False,'coordinate_grid_um':1,'absolute_coordinate_bounds_um':[1600000,3100000],
        'method':'Prepare a new constructive constraint model for23 independently positioned originals, retaining the29-original first-sheet core and14 short originals of the7/7 allocation. Reuse11 exact source modes and all66 intrinsic forbidden-displacement polygons plus11 fixed-core free regions, because source shapes, clearance and the29 fixed first-sheet poses are unchanged. This does not restart or resume the closed24-mover L-BFGS call. The single cog phase7degrees is a constructive subset only; all8 legal bracket modes and2 legal insert angles are retained. Decompose each free region and the bounded complement of each forbidden polygon into convex cells with exact geometry-union assertions. Convert CCW cell edges into conservative integer halfplanes on a1micrometre coordinate grid using exact Fractions, normal coefficients rounded at1e9 and a worst-case coordinate-error allowance plus1. Every encoded cell is a subset of the stored free region. This may miss real placements and supports no global infeasibility claim. Independently prove source-conservative obstacles/free regions and halfplane direction, then audit the serialized model and a source-valid partial control before any bounded solver call.'})
    start=time.perf_counter()
    try:
        p=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=120)
        (OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);process={'seconds':time.perf_counter()-start,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds':time.perf_counter()-start,'timeout':True}
    write(OUT/'process.json',process);print(process);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'Preparation closed without a final result.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
