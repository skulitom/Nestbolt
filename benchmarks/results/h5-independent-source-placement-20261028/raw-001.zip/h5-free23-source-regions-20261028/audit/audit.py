"""Independent source conservatism and exact integer-halfplane audit."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import combinations
import json,math,shutil,time
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,shape,box
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free23-source-regions-20261028';OLD=ROOT/'output/h5-oblique24-source-20261028';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
process=load(BASE/'process.json');assert not process['timeout'] and process['exit_code']==0 and process['seconds']<120
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');parts={p['id']:p for p in job['parts']};modes=load(BASE/'modes.json');local=[]
def transform(part,a,mirrored,offset):
    c,s=math.cos(a),math.sin(a);sign=-1 if mirrored else 1
    return Polygon([(sign*x*c-y*s+offset[0],sign*x*s+y*c+offset[1]) for x,y in part['geometry'][0]['outer']])
for i,m in enumerate(modes):
    assert i==m['index'];g=transform(parts[m['family']],m['angle'],m['mirrored'],m['source_translation_offset'])
    assert g.is_valid and g.equals_exact(shape(m['geometry']),1e-10);local.append(g)
assert {(m['family'],m['angle'],m['mirrored']) for m in modes}=={('cog',math.radians(7),False)}|{('bracket',q*math.pi/2,mir) for q in range(4) for mir in [False,True]}|{('insert',0.,False),('insert',math.pi/2,False)}
fixed=load(BASE/'fixed43.json');assert len(fixed)==43 and sum(r['sheet_id']=='sheet-0' for r in fixed)==29
world=[transform(parts[r['part_id']],r['transform']['rotation_radians'],r['transform']['mirrored'],r['transform']['translation']) for r in fixed if r['sheet_id']=='sheet-0']
triangle_cache={};raw_cache={};triangles_verified=0;hulls=0
def pieces(g):
    global triangles_verified
    key=g.wkb
    if key not in triangle_cache:
        vv=[g] if g.equals(g.convex_hull) else list(shapely.constrained_delaunay_triangles(g).geoms)
        assert all(v.is_valid and v.equals(v.convex_hull) for v in vv) and unary_union(vv).equals(g)
        triangles_verified+=len(vv);triangle_cache[key]=vv
    return triangle_cache[key]
def expanded(a,b):
    global hulls
    key=(a.wkb,b.wkb)
    if key not in raw_cache:
        sums=[]
        for p in pieces(a):
            for q in pieces(b):
                sums.append(MultiPoint([(u[0]-v[0],u[1]-v[1]) for u in list(p.exterior.coords)[:-1] for v in list(q.exterior.coords)[:-1]]).convex_hull);hulls+=1
        raw=unary_union(sums)
        # Each circular chord at sixteen segments/quadrant is moved outward
        # enough to contain the true required-clearance disc, with 0.1 nm extra.
        raw_cache[key]=raw.buffer(.21170867250963943/math.cos(math.pi/64)+1e-7,quad_segs=16)
    return raw_cache[key]
obstacle_checks=[]
for i in range(11):
    for j in range(i,11):
        saved=shape(load(OLD/'obstacles'/f'{i:02d}-{j:02d}.json'));required=expanded(local[i],local[j]);assert saved.covers(required),(i,j,required.difference(saved).area)
        obstacle_checks.append({'modes':[i,j],'contains_source_clearance_obstacle':True,'extra_area_mm2':saved.area-required.area})
write(OUT/'obstacles.json',obstacle_checks)
free_checks=[]
for i,g in enumerate(local):
    free=shape(load(OLD/'free'/f'{i:02d}.json'));assert free.is_valid and not free.is_empty
    xmin,ymin,xmax,ymax=g.bounds;guard=.011444091796875
    allowed=box(6.5+guard-xmin,6.5+guard-ymin,1493.5-guard-xmax,2993.5-guard-ymax);assert allowed.covers(free)
    for k,w in enumerate(world):assert free.disjoint(expanded(w,g)),(i,k)
    free_checks.append({'mode':i,'source_neighbours_checked':29,'source_stock_guard_verified':True})
write(OUT/'free.json',free_checks)
counts={'domains':0,'convex_cells':0,'integer_halfplanes':0};rows=[]
for folder in ['free','relative']:
    for path in sorted((BASE/folder).glob('*.json')):
        data=load(path);g=shape(data['domain_geometry']);polys=[]
        if folder=='free':assert g.equals(shape(load(OLD/'free'/path.name)))
        else:assert g.equals(box(-1600,-3100,1600,3100).difference(shape(load(OLD/'obstacles'/path.name))))
        for cell in data['cells']:
            p=shape(cell['geometry']);assert p.is_valid and not p.interiors and p.equals(p.convex_hull);polys.append(p)
            vertices=[tuple(F(str(x)) for x in pt) for pt in list(p.exterior.coords)[:-1]]
            area=sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(vertices,vertices[1:]+vertices[:1]));assert area>0
            assert len(vertices)==len(cell['halfplanes'])
            for k,(u,v) in enumerate(zip(vertices,vertices[1:]+vertices[:1])):
                ex,ey=v[0]-u[0],v[1]-u[1];nx,ny=-ey,ex;norm=max(abs(nx),abs(ny));nx/=norm;ny/=norm
                assert all(nx*(w[0]-u[0])+ny*(w[1]-u[1])>=0 for w in vertices)
                a,b,c=cell['halfplanes'][k];assert a==round(nx*10**9) and b==round(ny*10**9)
                target=10**12*(nx*u[0]+ny*u[1]);error=abs(a-10**9*nx)*1600000+abs(b-10**9*ny)*3100000
                assert F(c)>target+error and F(c-1)<=target+error+1
                # A*x+B*y>=C implies the exact inward-edge inequality because
                # the coefficient-error dot product is bounded by error.
                counts['integer_halfplanes']+=1
            counts['convex_cells']+=1
        assert unary_union(polys).equals(g);counts['domains']+=1;rows.append({'kind':folder,'key':path.stem,'cells':len(polys)})
result=load(BASE/'result.json');assert counts=={'domains':result['convex_domains'],'convex_cells':result['convex_cells'],'integer_halfplanes':result['integer_halfplanes']}
inputs=[BASE/'plan.json',BASE/'modes.json',BASE/'fixed43.json',BASE/'result.json']+sorted((BASE/'free').glob('*.json'))+sorted((BASE/'relative').glob('*.json'))
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'source_modes_verified':11,'source_obstacles_verified':66,'fixed_neighbour_checks':319,
    'source_convex_pieces_verified':triangles_verified,'independent_minkowski_hulls':hulls,**counts,'coordinate_bounds_um':[1600000,3100000],
    'constructive_subset_proved':True,'integer_halfplane_error_bound_proved':True,'actual_or_global_infeasibility_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
