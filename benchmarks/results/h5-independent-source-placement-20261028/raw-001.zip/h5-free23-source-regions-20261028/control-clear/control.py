"""Prepare and independently read a quantized positive partial source control."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free23-source-regions-20261028';OUT=BASE/'control-clear'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'control.py');assert load(BASE/'audit/checks.json')['passed']
oldpath=ROOT/'output/h5-rectangular-cog-grid-20261028/insertion/source-candidate.json';old=load(oldpath);fixed=load(BASE/'fixed43.json');modes=load(BASE/'modes.json')
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [oldpath,BASE/'control/failure.json',BASE/'control/plan.json',BASE/'modes.json',BASE/'fixed43.json',BASE/'audit/checks.json']},
    'method':'Deterministic positive partial control, no solver. Keep43 originals exact. Reuse the aligned-row source62 moving originals, increasing cog grid spacing from258.86 to258.90mm to clear the existing conservative no-fit buffer; each cog shifts by0.04mm times its original grid column/row. Round moving anchors to1micrometre and reconstruct originals with the audited modes. Relabel identical cog and insert copies in increasing anchorX,Y order; the single bracket is labelled11 so missing brackets7..10 can precede it in a partial X-order hint. Verify all original source geometry and all occupied free/relative integer cells. This is a partial control only, with all four missing brackets explicitly unplaced.'})
fixedkeys={(r['part_id'],r['copy_index']) for r in fixed};chosen=[]
for r in old:
    if (r['part_id'],r['copy_index']) in fixedkeys:continue
    t=r['transform'];mi=[i for i,m in enumerate(modes) if m['family']==r['part_id'] and m['mirrored']==t['mirrored'] and abs(m['angle']-t['rotation_radians'])<1e-12];assert len(mi)==1;m=modes[mi[0]]
    xy=[t['translation'][k]-m['source_translation_offset'][k] for k in [0,1]]
    if r['part_id']=='cog':row,col=divmod(r['copy_index'],5);xy[0]+=.04*col;xy[1]+=.04*row
    chosen.append({'family':r['part_id'],'mode':mi[0],'anchor_um':[round(v*1000) for v in xy]})
records=[];rows=list(fixed)
for family,ids in [('cog',range(15)),('bracket',[11]),('insert',range(18,21))]:
    group=sorted([r for r in chosen if r['family']==family],key=lambda r:r['anchor_um']);assert len(group)==len(ids)
    for r,copy in zip(group,ids):
        r={**r,'copy_index':copy};records.append(r);m=modes[r['mode']]
        rows.append({'part_id':family,'copy_index':copy,'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],'mirrored':m['mirrored'],
            'translation':[r['anchor_um'][k]/1000+m['source_translation_offset'][k] for k in [0,1]]}})
def matches(data,x,y):return [i for i,c in enumerate(data['cells']) if all(a*x+b*y>=v for a,b,v in c['halfplanes'])]
free=[];pairs=[]
for r in records:
    cells=matches(load(BASE/'free'/f'{r["mode"]:02d}.json'),*r['anchor_um']);assert cells,r;free.append({'key':[r['family'],r['copy_index']],'mode':r['mode'],'cell':cells[0]})
for a,b in combinations(records,2):
    ma,mb=a['mode'],b['mode'];dx,dy=[b['anchor_um'][k]-a['anchor_um'][k] for k in [0,1]];sign=1 if ma<=mb else -1
    cells=matches(load(BASE/'relative'/f'{min(ma,mb):02d}-{max(ma,mb):02d}.json'),sign*dx,sign*dy);assert cells,(a,b)
    pairs.append({'keys':[[a['family'],a['copy_index']],[b['family'],b['copy_index']]],'cell':cells[0]})
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');missing={('bracket',i) for i in range(7,11)};expected={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])}-missing
readback=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},.21170867250963943,.011444091796875,expected)
write(OUT/'source-readback.json',readback);assert readback['valid'];write(OUT/'source62.json',rows);write(OUT/'moving19.json',records);write(OUT/'free.json',free);write(OUT/'pairs.json',pairs)
write(OUT/'checks.json',{'passed':True,'source_originals':62,'moving_originals':19,'unchanged_fixed_originals':43,'occupied_integer_free_cells':len(free),
    'occupied_integer_relative_cells':len(pairs),'source_pairs_verified':readback['same_sheet_pairs'],'source_stock_edges':readback['stock_edges'],
    'minimum_pair_gap_mm':readback['minimum_pair_gap_mm'],'minimum_extra_stock_mm':readback['minimum_extra_stock_mm'],
    'unplaced_originals':[list(k) for k in sorted(missing)],'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
