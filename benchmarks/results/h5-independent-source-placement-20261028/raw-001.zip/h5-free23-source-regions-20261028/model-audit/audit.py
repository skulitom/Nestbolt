"""Independent exhaustive serialized-model reader and partial-control evaluation."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations,product
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-free23-source-regions-20261028';MODEL=BASE/'model';OUT=BASE/'model-audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
assert load(BASE/'audit/checks.json')['passed'] and load(BASE/'control-clear/checks.json')['passed']
for n,h in load(MODEL/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
p=cp_model_pb2.CpModelProto();p.ParseFromString((MODEL/'model.pb').read_bytes());mapping=load(MODEL/'mapping.json');built=load(MODEL/'built.json')
assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'}
assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256']
items=mapping['items'];assert len(items)==23 and mapping['coordinate_scale']==1000
expected=[('cog',i,[0]) for i in range(15)]+[('bracket',i,list(range(1,9))) for i in range(7,12)]+[('insert',i,[9,10]) for i in range(18,21)]
free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)}
usedvars=set();usedcts=set();wanted_hints={};controls={(r['family'],r['copy_index']):r for r in load(BASE/'control-clear/moving19.json')}
MIN=-9223372036854775808;MAX=9223372036854775807
def variable(index,name,domain):
    assert index not in usedvars;usedvars.add(index);v=p.variables[index]
    assert {f.name for f,x in v.ListFields()}=={'name','domain'} and v.name==name and list(v.domain)==domain
def linear(index,coeffs,lo=MIN,hi=MAX,on=None):
    assert index not in usedcts;usedcts.add(index);ct=p.constraints[index]
    assert ct.WhichOneof('constraint')=='linear' and {f.name for f,v in ct.ListFields()}<= {'linear','enforcement_literal'}
    assert list(ct.enforcement_literal)==([] if on is None else [on])
    assert {f.name for f,v in ct.linear.ListFields()}<= {'vars','coeffs','domain'} and len(ct.linear.vars)==len(set(ct.linear.vars))
    assert dict(zip(ct.linear.vars,ct.linear.coeffs))=={i:c for i,c in coeffs.items() if c!=0}
    assert list(ct.linear.domain)==[lo,hi]
def chosen(cells,point):
    good=[i for i,c in enumerate(cells) if all(a*point[0]+b*point[1]>=v for a,b,v in c['halfplanes'])];assert good;return good[0]
for i,(item,(family,copy,allowed)) in enumerate(zip(items,expected)):
    assert item['index']==i and item['family']==family and item['copy_index']==copy
    x,y=item['x'],item['y'];variable(x,f'x_{i}',[0,1500000]);variable(y,f'y_{i}',[0,3000000]);assert [o['mode'] for o in item['options']]==allowed
    control=controls.get((family,copy))
    if control:wanted_hints[x],wanted_hints[y]=control['anchor_um']
    for o in item['options']:
        m=o['mode'];v=o['selector'];ss=o['cells'];variable(v,f'mode_{i}_{m}',[0,1]);assert len(ss)==len(free[m])==len(o['plane_constraints'])
        linear(o['choice_constraint'],{**{s:1 for s in ss},v:-1},0,0)
        for k,(s,cell,cs) in enumerate(zip(ss,free[m],o['plane_constraints'])):
            variable(s,f'free_{i}_{m}_{k}',[0,1]);assert len(cs)==len(cell['halfplanes'])
            for ix,(a,b,c) in zip(cs,cell['halfplanes']):linear(ix,{x:a,y:b},lo=c,on=s)
        if control:
            wanted_hints[v]=int(control['mode']==m);selected=chosen(free[m],control['anchor_um']) if control['mode']==m else None
            for k,s in enumerate(ss):wanted_hints[s]=int(selected==k)
    ix=item['mode_choice_constraint'];assert ix not in usedcts;usedcts.add(ix);ct=p.constraints[ix]
    assert {f.name for f,v in ct.ListFields()}=={'exactly_one'} and list(ct.exactly_one.literals)==[o['selector'] for o in item['options']]
assert len(mapping['pairs'])==253
for row,(left,right) in zip(mapping['pairs'],combinations(items,2)):
    li,ri=left['index'],right['index'];assert (row['left'],row['right'])==(li,ri)
    expected_modes=list(product(left['options'],right['options']));assert len(row['groups'])==len(expected_modes)
    ca=controls.get((left['family'],left['copy_index']));cb=controls.get((right['family'],right['copy_index']))
    for g,(oa,ob) in zip(row['groups'],expected_modes):
        a,b=oa['mode'],ob['mode'];assert (g['left_mode'],g['right_mode'])==(a,b);sign=1 if a<=b else -1;cells=relative[min(a,b),max(a,b)]
        ss=g['cells'];assert len(ss)==len(cells)==len(g['plane_constraints']);choice=g['choice_constraints'];assert len(choice)==3
        linear(choice[0],{**{s:1 for s in ss},oa['selector']:-1},hi=0)
        linear(choice[1],{**{s:1 for s in ss},ob['selector']:-1},hi=0)
        linear(choice[2],{**{s:1 for s in ss},oa['selector']:-1,ob['selector']:-1},lo=-1)
        for k,(s,c,cs) in enumerate(zip(ss,cells,g['plane_constraints'])):
            variable(s,f'pair_{li}_{ri}_{a}_{b}_{k}',[0,1]);assert len(cs)==len(c['halfplanes'])
            for ix,(aa,bb,cc) in zip(cs,c['halfplanes']):linear(ix,{left['x']:-sign*aa,left['y']:-sign*bb,right['x']:sign*aa,right['y']:sign*bb},lo=cc,on=s)
        if ca and cb:
            active=(ca['mode'],cb['mode'])==(a,b);point=[sign*(cb['anchor_um'][k]-ca['anchor_um'][k]) for k in [0,1]]
            selected=chosen(cells,point) if active else None
            for k,s in enumerate(ss):wanted_hints[s]=int(selected==k)
expected_orders=[(a,b) for f in ['cog','bracket','insert'] for group in [[i for i in items if i['family']==f]] for a,b in zip(group,group[1:])]
assert len(mapping['orders'])==20
for order,(a,b) in zip(mapping['orders'],expected_orders):
    assert (order['left'],order['right'])==(a['index'],b['index']);linear(order['constraint'],{a['x']:1,b['x']:-1},hi=0)
assert usedvars==set(range(len(p.variables))) and usedcts==set(range(len(p.constraints)))
assert len(p.solution_hint.vars)==len(set(p.solution_hint.vars))
assert dict(zip(p.solution_hint.vars,p.solution_hint.values))==wanted_hints=={int(k):v for k,v in load(MODEL/'hint-values.json').items()}
assert len(usedvars)==built['variables'] and len(usedcts)==built['constraints'] and len(wanted_hints)==built['hints']
evaluated=inactive=unassigned=0
for ct in p.constraints:
    known=[wanted_hints.get(v) for v in ct.enforcement_literal]
    if 0 in known:inactive+=1;continue
    if None in known:unassigned+=1;continue
    if ct.WhichOneof('constraint')=='linear':
        if any(v not in wanted_hints for v in ct.linear.vars):unassigned+=1;continue
        value=sum(c*wanted_hints[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs));assert ct.linear.domain[0]<=value<=ct.linear.domain[1]
    else:
        assert ct.WhichOneof('constraint')=='exactly_one'
        if any(v not in wanted_hints for v in ct.exactly_one.literals):unassigned+=1;continue
        assert sum(wanted_hints[v] for v in ct.exactly_one.literals)==1
    evaluated+=1
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':len(usedvars),'constraints_verified':len(usedcts),
    'mandatory_originals':23,'independent_position_variables':46,'unordered_mover_pairs':253,'mode_pair_groups':built['mode_pair_groups'],
    'hint_values_verified':len(wanted_hints),'partial_control_constraints_evaluated':evaluated,'partial_control_inactive_constraints':inactive,
    'constraints_involving_unplaced_parts':unassigned,'unplaced_bracket_positions_unhinted':4,'no_objective_lattice_or_fixed_position':True,
    'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'plan_sha256':digest(MODEL/'plan.json'),
    'constructive_subset_only':True,'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(OUT/'checks.json'))
