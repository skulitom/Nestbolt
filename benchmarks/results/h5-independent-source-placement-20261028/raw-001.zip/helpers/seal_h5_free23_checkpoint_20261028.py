"""Seal audited independent-position source geometry and its sole closed search."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-independent-source-placement-20261028';OUT=ROOT/'benchmarks/results'/NAME;BASE=ROOT/'output/h5-free23-source-regions-20261028';PUB=BASE/'publication'
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='a23ee7837d859060d4c0452603758f55b90a6b7a' and not git('diff','HEAD','--name-only')
geo=load(BASE/'audit/checks.json');control=load(BASE/'control-clear/checks.json');model=load(BASE/'model-audit/checks.json');response=load(BASE/'response-audit/checks.json')
assert all(x['passed'] for x in [geo,control,model,response]);assert response['status']=='UNKNOWN' and not response['has_source66_candidate']
assert geo['constructive_subset_proved'] and model['mandatory_originals']==23 and model['independent_position_variables']==46
assert control['source_originals']==62 and len(control['unplaced_originals'])==4
prior=load(ROOT/'benchmarks/results/h5-cog-topology-source-checks-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest']
readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],
    'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]}
assert all(up[k]==prior[k] for k in up);assert load(PUB/'main.json')['commit']['sha']==head
jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-cog-topology-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_free23_regions_20261028.py','audit_h5_free23_regions_20261028.py','prepare_h5_free23_control_20261028.py',
    'prepare_h5_free23_clear_control_20261028.py','build_h5_free23_model_20261028.py','audit_h5_free23_model_20261028.py',
    'run_h5_free23_model_20261028.py','audit_h5_free23_response_20261028.py','push_cog_topology_checkpoint_20261028.py',
    'pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for f in ['output','scripts']:
                    q=ROOT/f/(module+'.py')
                    if q.is_file():add('imported-helpers/'+f+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(BASE/'audit/checks.json','geometry-audit.json'),(BASE/'control/failure.json','initial-control-failure.json'),
    (BASE/'control-clear/checks.json','partial-control-audit.json'),(BASE/'control-clear/source62.json','partial-source62.json'),
    (BASE/'model/built.json','model-size.json'),(BASE/'model-audit/checks.json','model-audit.json'),
    (BASE/'response-audit/checks.json','response-audit.json'),(BASE/'search/result.json','solver-result.json'),
    (BASE/'cells-summary.json','cells-summary.json'),(PUB/'main-ci-jobs.json','prior-main-ci.json'),
    (ROOT/'output/h5-cog-topology-main-sync-20261028/receipt.json','preceding-main-push.json')]
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':head,
    'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,
    'main_CI':40723142543,'main_all6_pass':True,'normal_push_requires_fresh_remote_guards':True,
    'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'source_conservative_domains_verified':77,'independent_mover_coordinates':46,
    'mandatory_movers':23,'source_modes':11,'model_variables':58151,'model_constraints':210518,'solver_status':'UNKNOWN','solver_calls':1,
    'full66_candidate':False,'previous_source64_preserved':True,'remaining_necessary_allocations':444,
    'actual_or_global_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='The first independent-coordinate source model is fully audited and its sole60-second call is closed UNKNOWN,143475branches/4080conflicts; preserve the response and0.151582s returned soft overrun. It is not an infeasibility result and changes none of the444 necessary allocations. Do not resume, reseed or extend that call. The source geometry now supports a materially stronger new formulation: derive disjoint axis-aligned rectangles contained in each original filled mode, audit containment and all offsets independently, then add necessary cumulative sheet-capacity constraints (including the29 fixed first-sheet originals) to propagate crowded X/Y sections. Keep all23 movers mandatory and all independent coordinates/modes; do not introduce a lattice or silently drop parts. Prove the extra constraints hold for original disjoint parts and verify the positive partial control before predeclaring one bounded new model call. If that geometry/model is not justified, revisit the frame/core arrangement or another still-allowed count allocation explicitly. The original fixed43 and mode/free/obstacle inputs remain reusable only while hashes and source semantics match. Full66 source, native and material checks are still required before integration or the full H5 matrix. All H2 decisions and22 reserved vectors remain unchanged. Main a23ee783 passes allsix CI jobs; a normal checkpoint push needs fresh remote/ancestry checks. Upstream heads/releases and production/README hashes are unchanged; no release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Independent source placement — 2026-10-28

The new construction model lets all **23 remaining originals move
independently**, with no lattice or fixed cog coordinates. Its sole bounded
search returns **UNKNOWN** without a complete layout. This is not an
infeasibility result. The earlier source-valid64 remains the best partial
layout; H2/H5 remain open at **60% completed milestone weight**.

## Original-source geometry and conservative cells

The 7/7 short-sheet allocation retains 43 originals: 29 first-sheet frames and
side inserts, plus the 14 short-sheet originals. The remaining 15 cogs, five
brackets and three inserts are all mandatory. Cogs use the legal constructive
phase 7°; brackets have all eight legal modes and inserts use 0°/90°.
No claim covers every possible cog angle.

The original 11 source modes, 66 forbidden-displacement polygons and 11
fixed-neighbour free regions are reused because their source shapes, guards
and 29 fixed first-sheet poses are unchanged. This does not resume any earlier
local search. Preparation decomposes the 77 domains into **1,124 convex cells**
with **4,079 integer halfplanes**, in 8.712509 shared seconds.

An independent reader reconstructs original modes, verifies 141 source convex
pieces, and builds **12,627 independent Minkowski hulls**. All 66 stored
obstacles cover the original-source required-clearance obstacles; all 319
fixed-neighbour checks and stock guards pass. Every convex-cell union is read
back. Exact rational arithmetic bounds coefficient-rounding error, proving
that the integer halfplanes describe subsets of the safe cells on a 1 µm grid.
This conservative construction may miss real placements.

## Partial source control and complete model audit

The first partial control at 258.88 mm cog pitch is preserved as a failure:
its 0.222662845 mm source gap exceeds the required acceptance gap, but is below
the existing conservative obstacle buffer of 0.224308673 mm. Tooth-edge slope
means pitch and clearance increments are not equal.

A separately recorded deterministic control uses 258.90 mm pitch, rounds moving
anchors to 1 µm and relabels identical copies for X ordering. All 43 fixed
originals remain exact. Its **62 original parts** pass 1,219 source pairs and
248 stock edges, with minimum pair gap 0.224800281 mm and minimum extra stock
clearance 0.024800286 mm. All 19 occupied fixed-neighbour cells and 171 occupied
relative cells pass. Four missing bracket positions remain unhinted.

The independent serialized-model reader checks **58,151 variables and 210,518
constraints**, including all 46 independent coordinates, 253 unordered mover
pairs, 1,687 mode-pair groups and 24,203 hint values. Every part is mandatory.
Mode and cell choices, relative-displacement signs, source halfplanes and
identical-copy X ordering are checked exhaustively. The partial control
satisfies its 2,111 active constraints; 83,687 are inactive and 124,720 involve
unplaced parts. No objective, lattice or fixed position is introduced.

## Closed search and next construction

The sole predeclared call uses four workers, seed0, a 60-second solver setting
and a 90-second shared limit. It returns **UNKNOWN**, with **143,475 branches
and 4,080 conflicts**, in 60.129179 solver seconds, 60.151582 returned seconds
and 61.636477 shared seconds. The **0.151582-second returned soft overrun** is
retained. No assignment or native call exists. The independent response reader
verifies hashes, parameters, protobuf status, log rounding and timing.

This result changes none of the 444 necessary count allocations. The call is
closed. Next derive and independently audit rectangles contained in the
original filled modes, then use them for necessary cumulative sheet-capacity
constraints in a separately declared model. Such constraints can improve
propagation while retaining independent positions and every mandatory part.
Any full layout still requires all66 original-source, native and unchanged
material-target checks before integration or a full H5 rerun.

All six jobs pass in
[main CI 40723142543](https://github.com/skulitom/Nestbolt/actions/runs/40723142543).
The preceding normal push receipt is archived. Production, READMEs and upstream
heads/releases are unchanged; all22 reserved H2 vectors remain unopened.
No new release qualifies.

[Source geometry audit]({NAME}/geometry-audit.json),
[retained failed control]({NAME}/initial-control-failure.json),
[valid partial control]({NAME}/partial-control-audit.json),
[complete model audit]({NAME}/model-audit.json),
[response audit]({NAME}/response-audit.json),
[next work]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The archive preserves {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including all source inputs, cells, halfplanes, model,
mapping, hints, failures, control, logs, response and independent readers.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 independent-coordinate source model, 2026-10-28:** [the evidence]({link})
audits 77 source-conservative domains, 1,124 convex cells and 4,079 integer
halfplanes. All23 remaining originals have independent coordinates; every
58,151 variable and 210,518 constraint is read back. The corrected source62
partial control passes original-ring and integer-cell checks; its earlier
buffer failure is retained. The sole60-second call closes UNKNOWN after
143,475 branches, with a retained0.151582-second returned soft overrun and no
assignment. No native or infeasibility claim follows; the valid64 and444-count
frontier remain unchanged. Next audit source-contained rectangles and necessary
cumulative sheet-capacity constraints in a new formulation; do not restart the
closed call. Main a23ee783 passes allsix jobs. Production, READMEs and upstream
heads/releases are unchanged. H2/H5 remain open at60%, all22 reserved vectors
remain unopened, and no release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'bound_source_inputs':len(bindings),'completion_percent':60,'main_all6_pass':True})
