"""Joint full-frame construction maximizing retained brackets and cogs."""
from collections import Counter
from datetime import datetime, timezone
import json, shutil, time
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT, load, write, digest

POOL = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
PARENT = ROOT / 'output/h5-insert-aligned-frame-completion-20261020'
SMALL = ROOT / 'output/h5-fixed-frame-small-capacity-20261020'
OUT = ROOT / 'output/h5-joint-full-frame-small-search-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'search.py')
    sources = [POOL / 'candidates.json', PARENT / 'model.pbtxt', PARENT / 'model-audit.json',
               PARENT / 'mapping.json', SMALL / 'audit/checks.json', SMALL / 'case-0/selected-indices.json']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'seconds_limit': 30, 'workers': 8, 'seed': 0,
        'method': 'Change the audited expanded fixed-insert model to require all18 frames. Keep all21 inserts fixed, allow0..12 brackets and0..15 cogs, require at least16 small parts from the best audited fixed-frame completion, and maximize small-part count then rounded filled area. All frame/bracket/cog poses move jointly. Preserve every original/new conflict and supply a complete feasible18-frame/11-bracket/5-cog hint. One bounded call, no retry.',
        'reason': 'The two frame-only outputs independently allow fewer than15 cogs. Joint selection must account for the actual small-part inventory instead of selecting frames alone.',
        'scope': 'Finite conditional construction. Missing small parts remain original-job failures. All27 small parts requires full original geometry/CLI/native qualification.',
        'native_packing_calls': 0, 'quality_runs': 0})
    parent_audit = load(PARENT / 'model-audit.json')
    assert digest(PARENT / 'model.pbtxt') == parent_audit['model_sha256']
    pool = load(POOL / 'candidates.json')
    mapping = load(PARENT / 'mapping.json')
    ids = mapping['candidates']
    fixed = mapping['fixed_insert_candidates']
    seed = set(load(SMALL / 'case-0/selected-indices.json'))
    assert Counter(pool[i]['placement']['part_id'] for i in seed) == Counter(frame=18, insert=21, bracket=11, cog=5)
    families = {f: [j for j, i in enumerate(ids) if pool[i]['placement']['part_id'] == f]
                for f in ['frame', 'bracket', 'cog']}
    dominant = 27 * 50063 + 1
    weights = {'bracket': dominant + 40000, 'cog': dominant + 50063}
    small_vars = sorted(families['bracket'] + families['cog'])
    model = cp_model.CpModel()
    assert model.proto.parse_text_format((PARENT / 'model.pbtxt').read_text())
    model.rebuild_constant_map()
    model.clear_objective()
    model.clear_hints()
    parent = text_format.Parse((PARENT / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
    expected = cp_model_pb2.CpModelProto()
    expected.CopyFrom(parent)
    expected.ClearField('objective')
    expected.ClearField('solution_hint')
    quantity_constraints = {}
    for f, domain in [('frame', [18, 18]), ('bracket', [0, 12]), ('cog', [0, 15])]:
        matches = [k for k, c in enumerate(parent.constraints)
                   if c.WhichOneof('constraint') == 'linear' and list(c.linear.vars) == families[f]]
        assert len(matches) == 1
        k = matches[0]
        quantity_constraints[f] = k
        model.proto.constraints[k].linear.domain[0] = domain[0]
        model.proto.constraints[k].linear.domain[1] = domain[1]
        expected.constraints[k].linear.domain[:] = domain
    variables = [model.get_int_var_from_proto_index(j) for j in range(len(ids))]
    model.add_linear_constraint(sum(variables[j] for j in small_vars), 16, 27)
    model.maximize(sum(weights[pool[ids[j]]['placement']['part_id']] * variables[j] for j in small_vars))
    hint = [int(i in seed) for i in ids]
    for j, value in enumerate(hint):
        model.add_hint(variables[j], value)
    c = expected.constraints.add().linear
    c.vars.extend(small_vars)
    c.coeffs.extend([1] * len(small_vars))
    c.domain.extend([16, 27])
    expected.objective.vars.extend(small_vars)
    expected.objective.coeffs.extend(-weights[pool[ids[j]]['placement']['part_id']] for j in small_vars)
    expected.objective.scaling_factor = -1
    expected.solution_hint.vars.extend(range(len(ids)))
    expected.solution_hint.values.extend(hint)
    assert model.validate() == ''
    model.export_to_file(str(OUT / 'model.pbtxt'))
    actual = text_format.Parse((OUT / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
    assert actual.SerializeToString(deterministic=True) == expected.SerializeToString(deterministic=True)
    for c in actual.constraints:
        if c.WhichOneof('constraint') == 'at_most_one':
            assert sum(hint[j] for j in c.at_most_one.literals) <= 1
        else:
            value = sum(co * hint[j] for j, co in zip(c.linear.vars, c.linear.coeffs))
            assert c.linear.domain[0] <= value <= c.linear.domain[1]
    write(OUT / 'mapping.json', {'candidates': ids, 'fixed_insert_candidates': fixed,
                               'complete_hint': hint, 'objective_weights': weights, 'count_coefficient': dominant})
    write(OUT / 'model-audit.json', {
        'all_model_fields_reconstructed_against_audited_parent': True,
        'complete_hint_exactly_feasible': True, 'variables': len(ids), 'constraints': len(actual.constraints),
        'quantity_constraint_indexes': quantity_constraints, 'original_conflicts_preserved': True,
        'model_sha256': digest(OUT / 'model.pbtxt')})
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 30
    solver.parameters.num_search_workers = 8
    solver.parameters.random_seed = 0
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = False
    (OUT / 'parameters.pbtxt').write_text(str(solver.parameters), encoding='utf-8', newline='\n')
    records = []
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            selected = [i for j, i in enumerate(ids) if self.value(variables[j])]
            counts = Counter(pool[i]['placement']['part_id'] for i in selected)
            r = {'index': len(records), 'selected_indices': sorted(fixed + selected),
                 'brackets': counts['bracket'], 'cogs': counts['cog'],
                 'small_parts': counts['bracket'] + counts['cog'], 'seconds': self.wall_time,
                 'objective': self.objective_value, 'best_bound': self.best_objective_bound}
            assert counts['frame'] == 18
            assert sum(weights[f] * counts[f] for f in weights) == r['objective']
            write(OUT / f"incumbent-{r['index']}.json", r)
            records.append(r)
            print(json.dumps({k: v for k, v in r.items() if k != 'selected_indices'}), flush=True)
    write(OUT / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'seconds_limit': 30})
    with (OUT / 'solver.log').open('x', encoding='utf-8', newline='\n') as log:
        solver.log_callback = lambda s: (log.write(s + '\n'), log.flush())
        start = time.perf_counter()
        status = solver.solve(model, Capture())
        seconds = time.perf_counter() - start
    feasible = status in [cp_model.FEASIBLE, cp_model.OPTIMAL]
    result = {'status': solver.status_name(status), 'seconds': seconds,
              'incumbents': len(records), 'feasible': feasible, 'response_stats': solver.response_stats(),
              'full_target_witness': False, 'native_margin_qualified': False}
    if feasible:
        selected = [i for j, i in enumerate(ids) if solver.value(variables[j])]
        write(OUT / 'selected-indices.json', sorted(fixed + selected))
        counts = Counter(pool[i]['placement']['part_id'] for i in selected)
        result.update(brackets=counts['bracket'], cogs=counts['cog'],
                      small_parts=counts['bracket'] + counts['cog'], objective=solver.objective_value,
                      best_bound=solver.best_objective_bound,
                      full_inventory_candidate=counts == Counter(frame=18, bracket=12, cog=15))
    else:
        assert not records
    write(OUT / 'result.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'response_stats'}), flush=True)

if __name__ == '__main__':
    main()
