"""Independently validate every full-frame joint result and exact CLI reuse."""
from collections import Counter, defaultdict
from itertools import combinations
import copy, gzip, json, math, shutil, subprocess
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT, SRC as ORIGINAL, load, write, digest

POOL = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
OLD = ROOT / 'output/h5-fixed-frame-small-capacity-20261020'
RUN = ROOT / 'output/h5-joint-full-frame-small-search-20261020'
OUT = RUN / 'audit'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'audit.py')
    for p, h in load(RUN / 'plan.json')['inputs'].items():
        assert digest(ROOT / p) == h
    pool = load(POOL / 'candidates.json')
    job = load(ORIGINAL / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    required = Counter({k: p['quantity'] for k, p in parts.items()})
    target = load(ORIGINAL / 'conditional-target.json')
    stock = job['stocks'][0]
    m, edge = stock['margins'], job['edge_clearance']
    sheets = load(ROOT / 'output/h5-full-insert-blockers-20261020/audit/layout-final.json')['sheets']
    mapping = load(RUN / 'mapping.json')
    fixed = set(mapping['fixed_insert_candidates'])
    allowed = set(mapping['candidates']) | fixed
    cliques = []
    for name in ['old-projected-cliques.jsonl.gz', 'new-cliques.jsonl.gz']:
        with gzip.open(POOL / name, 'rt', encoding='utf-8') as f:
            cliques.extend(set(json.loads(line)) for line in f)
    cached = {}
    for row in load(OLD / 'audit/checks.json')['records']:
        case, key = row['case'], row['incumbent']
        source = OLD / f'case-{case}'
        if key == 'final':
            ids = load(source / 'selected-indices.json')
        else:
            ids = load(source / f'incumbent-{key}.json')['selected_indices']
        folder = OLD / f'audit/case-{case}'
        cached[tuple(ids)] = [folder / f'{prefix}-{key}.json' for prefix in ['layout', 'public', 'command']]
    result = load(RUN / 'result.json')
    outcomes = [load(RUN / f'incumbent-{i}.json') for i in range(result['incumbents'])]
    if result['feasible']:
        final = load(RUN / 'selected-indices.json')
        if not outcomes or outcomes[-1]['selected_indices'] != final:
            outcomes.append({'index': 'final', 'selected_indices': final,
                             'brackets': result['brackets'], 'cogs': result['cogs'], 'objective': result['objective']})
    else:
        assert not outcomes
    cli = ROOT / 'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli) == '97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    records = []
    fresh = reused = 0
    for r in outcomes:
        ids = r['selected_indices']
        chosen = set(ids)
        assert len(ids) == len(chosen) and fixed <= chosen <= allowed
        assert all(len(c & chosen) <= 1 for c in cliques)
        score = sum(mapping['objective_weights'].get(pool[i]['placement']['part_id'], 0) for i in chosen)
        assert score == r['objective']
        counts = Counter()
        placements = []
        geoms = defaultdict(list)
        tops = Counter()
        for i in ids:
            p = copy.deepcopy(pool[i]['placement'])
            part, t = parts[p['part_id']], p['transform']
            assert not t['mirrored'] or part['allow_mirror']
            if part['rotations']['kind'] == 'list':
                assert any(abs(math.remainder(t['rotation_radians'] - math.radians(a), math.tau)) < 1e-9
                           for a in part['rotations']['degrees'])
            p['copy_index'] = counts[p['part_id']]
            counts[p['part_id']] += 1
            placements.append(p)
            g = shape(part, t)
            x0, y0, x1, y1 = g.bounds
            height = stock['height'] if p['sheet_id'] == 'sheet-0' else target['required_used_height_mm']
            assert g.is_valid and x0 >= m['left'] + edge - 1e-7 and y0 >= m['bottom'] + edge - 1e-7
            assert x1 <= stock['width'] - m['right'] - edge + 1e-7 and y1 <= height - m['top'] - edge + 1e-7
            geoms[p['sheet_id']].append(g)
            tops[p['sheet_id']] = max(tops[p['sheet_id']], y1 + m['top'] + edge)
        assert counts == Counter(frame=18, insert=21, bracket=r['brackets'], cog=r['cogs'])
        assert counts['bracket'] <= 12 and counts['cog'] <= 15 and counts['bracket'] + counts['cog'] >= 16
        minimum = math.inf
        pairs = 0
        for gs in geoms.values():
            for a, b in combinations(gs, 2):
                pairs += 1
                minimum = min(minimum, a.distance(b))
                assert a.disjoint(b) and a.distance(b) >= job['clearance'] - 1e-7
        key = r['index']
        layout = {'version': 1, 'units': 'mm', 'sheets': sheets, 'placements': placements}
        path = OUT / f'layout-{key}.json'
        write(path, layout)
        cache_paths = cached.get(tuple(ids))
        if cache_paths:
            prior_layout, prior_public, prior_cmd = cache_paths
            assert layout == load(prior_layout)
            public = load(prior_public)
            code = load(prior_cmd)['exit_code']
            write(OUT / f'validation-reuse-{key}.json', {
                'rerun': False, 'exact_layout_match': True,
                'source_files': {str(p.relative_to(ROOT)): digest(p) for p in cache_paths}})
            shutil.copyfile(prior_public, OUT / f'public-{key}.json')
            reused += 1
        else:
            cmd = [str(cli), 'validate', '--library', str(ORIGINAL / 'library.json'),
                   '--request', str(ORIGINAL / 'request.json'), '--layout', str(path)]
            cp = subprocess.run(cmd, capture_output=True, timeout=60)
            code = cp.returncode
            (OUT / f'public-{key}.json').write_bytes(cp.stdout)
            (OUT / f'public-{key}.stderr').write_bytes(cp.stderr)
            write(OUT / f'command-{key}.json', {'command': cmd, 'exit_code': code})
            public = json.loads(cp.stdout)
            fresh += 1
        missing = required - counts
        assert public['valid'] == (not missing)
        if missing:
            assert code != 0 and all(v['code'] == 'quantity' for v in public['violations'])
            assert sorted(v['message'] for v in public['violations']) == sorted(
                f'part {f}: expected {required[f]}, found {counts[f]}' for f in missing)
        else:
            assert code == 0 and not public['violations']
        material = stock['width'] * (stock['height'] + tops['sheet-1'])
        assert material <= target['target_material_mm2'] + 1e-6
        records.append({'incumbent': key, 'brackets': counts['bracket'], 'cogs': counts['cog'],
                        'small_parts': counts['bracket'] + counts['cog'], 'missing': dict(missing),
                        'pairs': pairs, 'minimum_distance_mm': minimum, 'charged_material_mm2': material,
                        'filled_area_mm2': sum(g.area for gs in geoms.values() for g in gs),
                        'original_CLI_valid': public['valid'], 'exact_prior_validation_reused': bool(cache_paths)})
    check = {'all_returned_layouts_checked': len(records), 'records': records,
             'fresh_frozen_CLI_calls': fresh, 'reused_frozen_CLI_results': reused,
             'starting_small_parts': 16, 'best_small_parts': max((r['small_parts'] for r in records), default=0),
             'full_target_witness': any(r['original_CLI_valid'] for r in records),
             'native_margin_qualified': False, 'native_packing_calls': 0, 'quality_runs': 0}
    write(OUT / 'checks.json', check)
    print(json.dumps({k: v for k, v in check.items() if k != 'records'}), flush=True)

if __name__ == '__main__':
    main()
