"""Audit all conditional small-part layouts and certify necessary count bounds."""
from collections import Counter, defaultdict
from itertools import combinations
import copy, gzip, json, math, shutil, subprocess
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT, SRC as ORIGINAL, load, write, digest
from census_h5_one_part_moves import bits

POOL = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
RUN = ROOT / 'output/h5-fixed-frame-small-capacity-20261020'
OUT = RUN / 'audit'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'audit.py')
    for p, h in load(RUN / 'plan.json')['inputs'].items():
        assert digest(ROOT / p) == h
    pool = load(POOL / 'candidates.json')
    job = load(ORIGINAL / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    required = Counter({k: p['quantity'] for k, p in parts.items()})
    target = load(ORIGINAL / 'conditional-target.json')
    stock = job['stocks'][0]
    m, edge = stock['margins'], job['edge_clearance']
    sheets = load(ROOT / 'output/h5-full-insert-blockers-20261020/audit/layout-final.json')['sheets']
    cliques = []
    for name in ['old-projected-cliques.jsonl.gz', 'new-cliques.jsonl.gz']:
        with gzip.open(POOL / name, 'rt', encoding='utf-8') as f:
            cliques.extend(set(json.loads(line)) for line in f)
    parent_ids = load(POOL / 'mapping.json')['candidates']
    small = {i for i in parent_ids if pool[i]['placement']['part_id'] in ['bracket', 'cog']}
    all_geometry = {i: shape(parts[pool[i]['placement']['part_id']], pool[i]['placement']['transform'])
                    for i in set(parent_ids) | set(load(POOL / 'mapping.json')['fixed_insert_candidates'])}
    cli = ROOT / 'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli) == '97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    records = []
    bounds = []
    filter_pairs = 0
    for result in load(RUN / 'results.json'):
        case = result['case']
        src = RUN / f'case-{case}'
        dest = OUT / f'case-{case}'
        dest.mkdir()
        mapping = load(src / 'mapping.json')
        fixed = set(mapping['fixed_candidates'])
        allowed = set(mapping['candidates'])
        # Audit every small-part eligibility against original geometry, not just graph membership.
        expected = set()
        for i in small:
            blocked = False
            for j in fixed:
                if pool[i]['placement']['sheet_id'] != pool[j]['placement']['sheet_id']:
                    continue
                filter_pairs += 1
                if all_geometry[i].distance(all_geometry[j]) < job['clearance'] - 1e-7:
                    blocked = True
            if not blocked:
                expected.add(i)
        assert expected == allowed
        outcomes = [load(src / f'incumbent-{i}.json') for i in range(result['incumbents'])]
        if result['feasible']:
            final = load(src / 'selected-indices.json')
            if not outcomes or outcomes[-1]['selected_indices'] != final:
                outcomes.append({'index': 'final', 'selected_indices': final,
                                 'brackets': result['brackets'], 'cogs': result['cogs'],
                                 'objective': result['objective']})
        else:
            assert not outcomes
        for r in outcomes:
            ids = r['selected_indices']
            chosen = set(ids)
            assert len(ids) == len(chosen) and fixed <= chosen <= allowed | fixed
            assert all(len(c & chosen) <= 1 for c in cliques)
            score = sum(mapping['objective_weights'][pool[i]['placement']['part_id']] for i in chosen - fixed)
            assert score == r['objective']
            counts = Counter()
            placements = []
            geoms = defaultdict(list)
            tops = Counter()
            for i in ids:
                p = copy.deepcopy(pool[i]['placement'])
                part, t = parts[p['part_id']], p['transform']
                assert not t['mirrored'] or part['allow_mirror']
                if part['rotations']['kind'] == 'list':
                    assert any(abs(math.remainder(t['rotation_radians'] - math.radians(a), math.tau)) < 1e-9
                               for a in part['rotations']['degrees'])
                p['copy_index'] = counts[p['part_id']]
                counts[p['part_id']] += 1
                placements.append(p)
                g = all_geometry[i]
                x0, y0, x1, y1 = g.bounds
                height = stock['height'] if p['sheet_id'] == 'sheet-0' else target['required_used_height_mm']
                assert g.is_valid and x0 >= m['left'] + edge - 1e-7 and y0 >= m['bottom'] + edge - 1e-7
                assert x1 <= stock['width'] - m['right'] - edge + 1e-7 and y1 <= height - m['top'] - edge + 1e-7
                geoms[p['sheet_id']].append(g)
                tops[p['sheet_id']] = max(tops[p['sheet_id']], y1 + m['top'] + edge)
            assert counts == Counter(frame=18, insert=21, bracket=r['brackets'], cog=r['cogs'])
            assert counts['bracket'] <= 12 and counts['cog'] <= 15
            minimum = math.inf
            pairs = 0
            for gs in geoms.values():
                for a, b in combinations(gs, 2):
                    pairs += 1
                    minimum = min(minimum, a.distance(b))
                    assert a.disjoint(b) and a.distance(b) >= job['clearance'] - 1e-7
            key = r['index']
            path = dest / f'layout-{key}.json'
            write(path, {'version': 1, 'units': 'mm', 'sheets': sheets, 'placements': placements})
            cmd = [str(cli), 'validate', '--library', str(ORIGINAL / 'library.json'),
                   '--request', str(ORIGINAL / 'request.json'), '--layout', str(path)]
            cp = subprocess.run(cmd, capture_output=True, timeout=60)
            (dest / f'public-{key}.json').write_bytes(cp.stdout)
            (dest / f'public-{key}.stderr').write_bytes(cp.stderr)
            write(dest / f'command-{key}.json', {'command': cmd, 'exit_code': cp.returncode})
            public = json.loads(cp.stdout)
            missing = required - counts
            assert public['valid'] == (not missing)
            if missing:
                assert cp.returncode != 0 and all(v['code'] == 'quantity' for v in public['violations'])
                assert sorted(v['message'] for v in public['violations']) == sorted(
                    f'part {f}: expected {required[f]}, found {counts[f]}' for f in missing)
            else:
                assert cp.returncode == 0 and not public['violations']
            material = stock['width'] * (stock['height'] + tops['sheet-1'])
            assert material <= target['target_material_mm2'] + 1e-6
            records.append({'case': case, 'incumbent': key, 'brackets': counts['bracket'], 'cogs': counts['cog'],
                            'missing': dict(missing), 'pairs': pairs, 'minimum_distance_mm': minimum,
                            'charged_material_mm2': material,
                            'filled_area_mm2': sum(g.area for gs in geoms.values() for g in gs),
                            'original_CLI_valid': public['valid']})
        case_bounds = {'case': case}
        for family in ['bracket', 'cog', 'both']:
            candidates = {i for i in allowed if family == 'both' or pool[i]['placement']['part_id'] == family}
            mask = sum(1 << i for i in candidates)
            options = {}
            for ci, c in enumerate(cliques):
                cut = c & candidates
                if len(cut) > 1:
                    options.setdefault(sum(1 << i for i in cut), ci)
            remaining = mask
            cover = []
            while remaining:
                best = max(options, key=lambda v: ((v & remaining).bit_count(), -options[v]), default=0)
                covered = best & remaining
                ci = options[best] if covered.bit_count() > 1 else None
                if ci is None:
                    covered = remaining & -remaining
                cover.append({'source_clique': ci, 'candidates': list(bits(covered))})
                remaining &= ~covered
            seen = set()
            for row in cover:
                nodes = set(row['candidates'])
                assert nodes and nodes <= candidates and not(nodes & seen)
                if row['source_clique'] is None:
                    assert len(nodes) == 1
                else:
                    assert nodes <= cliques[row['source_clique']]
                seen |= nodes
            assert seen == candidates
            write(dest / f'{family}-cover.json', cover)
            case_bounds[family + '_upper_bound'] = len(cover)
        case_bounds['full_original_counts_ruled_out_by_covers'] = (
            case_bounds['bracket_upper_bound'] < 12 or case_bounds['cog_upper_bound'] < 15
            or case_bounds['both_upper_bound'] < 27)
        bounds.append(case_bounds)
    check = {'all_returned_layouts_checked': len(records), 'records': records,
             'all_original_geometry_filter_pairs': filter_pairs, 'all_filters_exact': True,
             'independently_verified_cover_bounds': bounds, 'fresh_frozen_CLI_calls': len(records),
             'full_target_witness': any(r['original_CLI_valid'] for r in records),
             'native_margin_qualified': False, 'native_packing_calls': 0, 'quality_runs': 0}
    write(OUT / 'checks.json', check)
    print(json.dumps({k: v for k, v in check.items() if k != 'records'}), flush=True)

if __name__ == '__main__':
    main()
