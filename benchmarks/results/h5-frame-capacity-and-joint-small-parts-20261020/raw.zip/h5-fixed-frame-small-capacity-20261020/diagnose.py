"""Complete brackets/cogs for each audited 18-frame/21-insert arrangement."""
from collections import Counter
from datetime import datetime, timezone
import gzip, json, shutil, time
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT, load, write, digest

SRC = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
FRAME = ROOT / 'output/h5-fixed-insert-frame-capacity-20261020'
DIAG = ROOT / 'output/h5-full-insert-blockers-20261020'
OUT = ROOT / 'output/h5-fixed-frame-small-capacity-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'diagnose.py')
    sources = [SRC / n for n in ['candidates.json', 'mapping.json', 'audit/checks.json',
                                'old-projected-cliques.jsonl.gz', 'new-cliques.jsonl.gz']]
    sources += [FRAME / 'audit/checks.json', FRAME / 'audit/complete-frame-groups.json', DIAG / 'selected-indices.json']
    groups = load(FRAME / 'audit/complete-frame-groups.json')
    assert 1 <= len(groups) <= 2
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in sources},
        'cases': len(groups), 'seconds_per_case': 20, 'workers': 8, 'seed': 0,
        'method': 'For every distinct audited18-frame/21-insert output, fix those39 poses. Retain every compatible original bracket/cog pose and every projected conflict. Allow0..12 brackets and0..15 cogs; maximize their total count, then rounded filled area using a count-dominating weight. Supply a complete feasible hint from the compatible subset of the old diagnostic small parts. Reconstruct all filters, model fields and hints; one bounded call per distinct group, no retry.',
        'scope': 'Conditional finite-pool capacity only. Every omitted bracket/cog remains an original-job failure. Full27 small parts is a candidate pending geometry/CLI/native qualification.',
        'native_packing_calls': 0, 'quality_runs': 0})
    pool = load(SRC / 'candidates.json')
    parent_mapping = load(SRC / 'mapping.json')
    seed = set(load(DIAG / 'selected-indices.json'))
    cliques = []
    for name in ['old-projected-cliques.jsonl.gz', 'new-cliques.jsonl.gz']:
        with gzip.open(SRC / name, 'rt', encoding='utf-8') as f:
            cliques.extend(set(json.loads(line)) for line in f)
    small = {i for i in parent_mapping['candidates'] if pool[i]['placement']['part_id'] in ['bracket', 'cog']}
    neighbors = {i: set() for i in small}
    for c in cliques:
        for i in c & small:
            neighbors[i].update(c - {i})
    dominant = 27 * 50063 + 1
    weights = {'bracket': dominant + 40000, 'cog': dominant + 50063}
    all_results = []
    audits = []
    for group in groups:
        case = group['case']
        dest = OUT / f'case-{case}'
        dest.mkdir()
        fixed = set(group['selected_indices'])
        fixed_frames = {i for i in fixed if pool[i]['placement']['part_id'] == 'frame'}
        assert len(fixed_frames) == 18 and len(fixed) == 39
        blocked = set()
        for c in cliques:
            assert len(c & fixed_frames) <= 1
            if c & fixed_frames:
                blocked |= c - fixed_frames
        ids = sorted(small - blocked)
        assert ids == sorted(i for i in small if not(neighbors[i] & fixed_frames))
        local = {i: j for j, i in enumerate(ids)}
        rows = sorted({tuple(sorted(c & local.keys())) for c in cliques if len(c & local.keys()) > 1})
        families = {f: [j for j, i in enumerate(ids) if pool[i]['placement']['part_id'] == f]
                    for f in ['bracket', 'cog']}
        model = cp_model.CpModel()
        variables = [model.new_bool_var(f'p{i}') for i in ids]
        for row in rows:
            model.add_at_most_one(variables[local[i]] for i in row)
        for f, cap in [('bracket', 12), ('cog', 15)]:
            assert families[f]
            model.add_linear_constraint(sum(variables[j] for j in families[f]), 0, cap)
        coeffs = [weights[pool[i]['placement']['part_id']] for i in ids]
        model.maximize(sum(co * v for co, v in zip(coeffs, variables)))
        hint = [int(i in seed) for i in ids]
        for j, value in enumerate(hint):
            model.add_hint(variables[j], value)
        assert model.validate() == ''
        model.export_to_file(str(dest / 'model.pbtxt'))
        expected = cp_model_pb2.CpModelProto()
        for i in ids:
            v = expected.variables.add()
            v.name = f'p{i}'
            v.domain.extend([0, 1])
        indexed = {tuple(sorted(local[i] for i in c if i in local)) for c in cliques}
        for row in sorted(r for r in indexed if len(r) > 1):
            expected.constraints.add().at_most_one.literals.extend(row)
        for f, cap in [('bracket', 12), ('cog', 15)]:
            c = expected.constraints.add().linear
            c.vars.extend(families[f])
            c.coeffs.extend([1] * len(families[f]))
            c.domain.extend([0, cap])
        expected.objective.vars.extend(range(len(ids)))
        expected.objective.coeffs.extend(-co for co in coeffs)
        expected.objective.scaling_factor = -1
        expected.solution_hint.vars.extend(range(len(ids)))
        expected.solution_hint.values.extend(hint)
        actual = text_format.Parse((dest / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
        assert actual.SerializeToString(deterministic=True) == expected.SerializeToString(deterministic=True)
        for c in actual.constraints:
            if c.WhichOneof('constraint') == 'at_most_one':
                assert sum(hint[j] for j in c.at_most_one.literals) <= 1
            else:
                value = sum(co * hint[j] for j, co in zip(c.linear.vars, c.linear.coeffs))
                assert c.linear.domain[0] <= value <= c.linear.domain[1]
        write(dest / 'mapping.json', {'candidates': ids, 'fixed_candidates': sorted(fixed),
                                    'complete_hint': hint, 'objective_weights': weights,
                                    'count_coefficient': dominant})
        audit = {'case': case, 'all_model_fields_independently_reconstructed': True,
                 'all_filters_exact': True, 'complete_hint_exactly_feasible': True,
                 'variables': len(ids), 'constraints': len(actual.constraints),
                 'eligible_by_family': {f: len(v) for f, v in families.items()},
                 'model_sha256': digest(dest / 'model.pbtxt')}
        write(dest / 'model-audit.json', audit)
        audits.append(audit)
        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = 20
        solver.parameters.num_search_workers = 8
        solver.parameters.random_seed = 0
        solver.parameters.log_search_progress = True
        solver.parameters.log_to_stdout = False
        (dest / 'parameters.pbtxt').write_text(str(solver.parameters), encoding='utf-8', newline='\n')
        records = []
        class Capture(cp_model.CpSolverSolutionCallback):
            def on_solution_callback(self):
                selected = [i for j, i in enumerate(ids) if self.value(model.get_int_var_from_proto_index(j))]
                counts = Counter(pool[i]['placement']['part_id'] for i in selected)
                r = {'index': len(records), 'selected_indices': sorted(fixed | set(selected)),
                     'brackets': counts['bracket'], 'cogs': counts['cog'], 'seconds': self.wall_time,
                     'objective': self.objective_value, 'best_bound': self.best_objective_bound}
                assert sum(weights[f] * n for f, n in counts.items()) == r['objective']
                write(dest / f"incumbent-{r['index']}.json", r)
                records.append(r)
                print(json.dumps({'case': case, **{k: v for k, v in r.items() if k != 'selected_indices'}}), flush=True)
        write(dest / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'seconds_limit': 20})
        with (dest / 'solver.log').open('x', encoding='utf-8', newline='\n') as log:
            solver.log_callback = lambda s: (log.write(s + '\n'), log.flush())
            start = time.perf_counter()
            status = solver.solve(model, Capture())
            seconds = time.perf_counter() - start
        feasible = status in [cp_model.FEASIBLE, cp_model.OPTIMAL]
        result = {'case': case, 'status': solver.status_name(status), 'seconds': seconds,
                  'incumbents': len(records), 'feasible': feasible,
                  'response_stats': solver.response_stats(), 'full_target_witness': False}
        if feasible:
            selected = [i for j, i in enumerate(ids) if solver.value(model.get_int_var_from_proto_index(j))]
            write(dest / 'selected-indices.json', sorted(fixed | set(selected)))
            counts = Counter(pool[i]['placement']['part_id'] for i in selected)
            result.update(brackets=counts['bracket'], cogs=counts['cog'], small_parts=len(selected),
                          best_bound=solver.best_objective_bound, objective=solver.objective_value,
                          full_inventory_candidate=counts == Counter(bracket=12, cog=15))
        else:
            assert not records
        write(dest / 'result.json', result)
        all_results.append(result)
        print(json.dumps({k: v for k, v in result.items() if k != 'response_stats'}), flush=True)
    write(OUT / 'model-audit.json', audits)
    write(OUT / 'results.json', all_results)

if __name__ == '__main__':
    main()
