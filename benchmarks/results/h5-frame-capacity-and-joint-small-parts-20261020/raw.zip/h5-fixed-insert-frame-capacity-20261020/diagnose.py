"""One frame-only necessary relaxation of the audited fixed-insert construction."""
from datetime import datetime, timezone
import gzip, json, shutil, time
from ortools.sat.python import cp_model
from ortools.sat import cp_model_pb2
from google.protobuf import text_format
from reduce_h5_free_cog_pool import ROOT, load, write, digest

SRC = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
DIAG = ROOT / 'output/h5-full-insert-blockers-20261020'
OUT = ROOT / 'output/h5-fixed-insert-frame-capacity-20261020'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'diagnose.py')
    inputs = [SRC / n for n in ['candidates.json', 'mapping.json', 'audit/checks.json',
                               'old-projected-cliques.jsonl.gz', 'new-cliques.jsonl.gz']]
    inputs += [DIAG / 'selected-indices.json', DIAG / 'audit/checks.json']
    write(OUT / 'plan.json', {
        'opened_utc': datetime.now(timezone.utc).isoformat(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in inputs},
        'seconds_limit': 10, 'workers': 8, 'seed': 0,
        'method': 'Fix the audited21 inserts, remove all bracket/cog restrictions, retain all compatible1719 original/new frame poses and every frame conflict. Maximize whole frames16..18 from the exact feasible16-frame hint. Reconstruct every model field and hint before one bounded call.',
        'scope': 'Necessary relaxation only. Brackets and cogs remain required by the original job. Feasible18 frames will require separate bracket/cog capacity diagnosis; a finite-pool optimum below18 is not unrestricted impossibility.',
        'native_packing_calls': 0, 'quality_runs': 0})
    pool = load(SRC / 'candidates.json')
    mapping = load(SRC / 'mapping.json')
    ids = [i for i in mapping['candidates'] if pool[i]['placement']['part_id'] == 'frame']
    local = {i: j for j, i in enumerate(ids)}
    fixed = mapping['fixed_insert_candidates']
    source_rows = []
    for name in ['old-projected-cliques.jsonl.gz', 'new-cliques.jsonl.gz']:
        with gzip.open(SRC / name, 'rt', encoding='utf-8') as f:
            source_rows.extend(set(json.loads(line)) for line in f)
    rows = sorted({tuple(sorted(c & local.keys())) for c in source_rows if len(c & local.keys()) > 1})
    model = cp_model.CpModel()
    variables = [model.new_bool_var(f'p{i}') for i in ids]
    for row in rows:
        model.add_at_most_one(variables[local[i]] for i in row)
    model.add_linear_constraint(sum(variables), 16, 18)
    model.maximize(sum(variables))
    seed = set(load(DIAG / 'selected-indices.json'))
    hint = [int(i in seed) for i in ids]
    assert sum(hint) == 16
    for j, value in enumerate(hint):
        model.add_hint(variables[j], value)
    assert model.validate() == ''
    model.export_to_file(str(OUT / 'model.pbtxt'))
    expected = cp_model_pb2.CpModelProto()
    for i in ids:
        v = expected.variables.add()
        v.name = f'p{i}'
        v.domain.extend([0, 1])
    indexed = {tuple(sorted(local[i] for i in c if i in local)) for c in source_rows}
    for row in sorted(r for r in indexed if len(r) > 1):
        expected.constraints.add().at_most_one.literals.extend(row)
    c = expected.constraints.add().linear
    c.vars.extend(range(len(ids)))
    c.coeffs.extend([1] * len(ids))
    c.domain.extend([16, 18])
    expected.objective.vars.extend(range(len(ids)))
    expected.objective.coeffs.extend([-1] * len(ids))
    expected.objective.scaling_factor = -1
    expected.solution_hint.vars.extend(range(len(ids)))
    expected.solution_hint.values.extend(hint)
    actual = text_format.Parse((OUT / 'model.pbtxt').read_text(), cp_model_pb2.CpModelProto())
    assert actual.SerializeToString(deterministic=True) == expected.SerializeToString(deterministic=True)
    assert all(sum(hint[j] for j in c.at_most_one.literals) <= 1
               for c in actual.constraints if c.WhichOneof('constraint') == 'at_most_one')
    write(OUT / 'mapping.json', {'candidates': ids, 'fixed_insert_candidates': fixed, 'complete_hint': hint})
    write(OUT / 'model-audit.json', {
        'all_model_fields_independently_reconstructed': True,
        'complete_hint_exactly_feasible': True, 'variables': len(ids),
        'constraints': len(actual.constraints), 'model_sha256': digest(OUT / 'model.pbtxt')})
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 10
    solver.parameters.num_search_workers = 8
    solver.parameters.random_seed = 0
    solver.parameters.log_search_progress = True
    solver.parameters.log_to_stdout = False
    (OUT / 'parameters.pbtxt').write_text(str(solver.parameters), encoding='utf-8', newline='\n')
    records = []
    class Capture(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            selected = [i for j, i in enumerate(ids) if self.value(model.get_int_var_from_proto_index(j))]
            r = {'index': len(records), 'selected_indices': sorted(fixed + selected),
                 'frames': len(selected), 'seconds': self.wall_time,
                 'objective': self.objective_value, 'best_bound': self.best_objective_bound}
            assert r['frames'] == r['objective']
            write(OUT / f"incumbent-{r['index']}.json", r)
            records.append(r)
            print(json.dumps({k: v for k, v in r.items() if k != 'selected_indices'}), flush=True)
    write(OUT / 'opened.json', {'utc': datetime.now(timezone.utc).isoformat(), 'seconds_limit': 10})
    with (OUT / 'solver.log').open('x', encoding='utf-8', newline='\n') as log:
        solver.log_callback = lambda s: (log.write(s + '\n'), log.flush())
        start = time.perf_counter()
        status = solver.solve(model, Capture())
        seconds = time.perf_counter() - start
    feasible = status in [cp_model.FEASIBLE, cp_model.OPTIMAL]
    result = {'status': solver.status_name(status), 'seconds': seconds, 'incumbents': len(records),
              'feasible': feasible, 'response_stats': solver.response_stats(),
              'full_target_witness': False, 'native_margin_qualified': False}
    if feasible:
        selected = [i for j, i in enumerate(ids) if solver.value(model.get_int_var_from_proto_index(j))]
        write(OUT / 'selected-indices.json', sorted(fixed + selected))
        result.update(frames=len(selected), best_bound=solver.best_objective_bound,
                      required_frame_count_reached=len(selected) == 18)
    else:
        assert not records
    write(OUT / 'result.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'response_stats'}), flush=True)

if __name__ == '__main__':
    main()
