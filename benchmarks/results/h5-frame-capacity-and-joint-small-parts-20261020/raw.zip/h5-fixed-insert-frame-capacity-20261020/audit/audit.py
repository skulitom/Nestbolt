"""Check every necessary frame-only layout, retaining its original quantity failures."""
from collections import Counter, defaultdict
from itertools import combinations
import copy, json, math, shutil, subprocess
from audit_h5_cog_lattices import shape
from reduce_h5_free_cog_pool import ROOT, SRC as ORIGINAL, load, write, digest

POOL = ROOT / 'output/h5-insert-aligned-frame-pool-20261020'
RUN = ROOT / 'output/h5-fixed-insert-frame-capacity-20261020'
OUT = RUN / 'audit'

def main():
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'audit.py')
    for p, h in load(RUN / 'plan.json')['inputs'].items():
        assert digest(ROOT / p) == h
    pool = load(POOL / 'candidates.json')
    job = load(ORIGINAL / 'job.json')
    parts = {p['id']: p for p in job['parts']}
    required = Counter({k: p['quantity'] for k, p in parts.items()})
    target = load(ORIGINAL / 'conditional-target.json')
    stock = job['stocks'][0]
    m, edge = stock['margins'], job['edge_clearance']
    sheets = load(ROOT / 'output/h5-full-insert-blockers-20261020/audit/layout-final.json')['sheets']
    mapping = load(RUN / 'mapping.json')
    fixed = set(mapping['fixed_insert_candidates'])
    allowed = set(mapping['candidates']) | fixed
    result = load(RUN / 'result.json')
    outcomes = [load(RUN / f'incumbent-{i}.json') for i in range(result['incumbents'])]
    if result['feasible']:
        final = load(RUN / 'selected-indices.json')
        if not outcomes or outcomes[-1]['selected_indices'] != final:
            outcomes.append({'index': 'final', 'selected_indices': final, 'frames': result['frames']})
    else:
        assert not outcomes
    cli = ROOT / 'output/h5-joint-repair-probe-20261018/public-checks/nestbolt-validator.exe'
    assert digest(cli) == '97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
    records = []
    complete_groups = {}
    for r in outcomes:
        ids = r['selected_indices']
        assert len(ids) == len(set(ids)) and fixed <= set(ids) <= allowed
        counts = Counter()
        placements = []
        geoms = defaultdict(list)
        tops = Counter()
        for i in ids:
            p = copy.deepcopy(pool[i]['placement'])
            part, t = parts[p['part_id']], p['transform']
            assert not t['mirrored'] or part['allow_mirror']
            assert any(abs(math.remainder(t['rotation_radians'] - math.radians(a), math.tau)) < 1e-9
                       for a in part['rotations']['degrees'])
            p['copy_index'] = counts[p['part_id']]
            counts[p['part_id']] += 1
            placements.append(p)
            g = shape(part, t)
            x0, y0, x1, y1 = g.bounds
            height = stock['height'] if p['sheet_id'] == 'sheet-0' else target['required_used_height_mm']
            assert g.is_valid and x0 >= m['left'] + edge - 1e-7 and y0 >= m['bottom'] + edge - 1e-7
            assert x1 <= stock['width'] - m['right'] - edge + 1e-7 and y1 <= height - m['top'] - edge + 1e-7
            geoms[p['sheet_id']].append(g)
            tops[p['sheet_id']] = max(tops[p['sheet_id']], y1 + m['top'] + edge)
        assert counts == Counter(frame=r['frames'], insert=21) and 16 <= r['frames'] <= 18
        minimum = math.inf
        pairs = 0
        for gs in geoms.values():
            for a, b in combinations(gs, 2):
                pairs += 1
                minimum = min(minimum, a.distance(b))
                assert a.disjoint(b) and a.distance(b) >= job['clearance'] - 1e-7
        key = r['index']
        path = OUT / f'layout-{key}.json'
        write(path, {'version': 1, 'units': 'mm', 'sheets': sheets, 'placements': placements})
        cmd = [str(cli), 'validate', '--library', str(ORIGINAL / 'library.json'),
               '--request', str(ORIGINAL / 'request.json'), '--layout', str(path)]
        cp = subprocess.run(cmd, capture_output=True, timeout=60)
        (OUT / f'public-{key}.json').write_bytes(cp.stdout)
        (OUT / f'public-{key}.stderr').write_bytes(cp.stderr)
        write(OUT / f'command-{key}.json', {'command': cmd, 'exit_code': cp.returncode})
        public = json.loads(cp.stdout)
        missing = required - counts
        assert cp.returncode != 0 and not public['valid']
        assert all(v['code'] == 'quantity' for v in public['violations'])
        assert sorted(v['message'] for v in public['violations']) == sorted(
            f'part {f}: expected {required[f]}, found {counts[f]}' for f in missing)
        material = stock['width'] * (stock['height'] + tops['sheet-1'])
        assert material <= target['target_material_mm2'] + 1e-6
        records.append({'incumbent': key, 'frames': counts['frame'], 'inserts': 21,
                        'missing': dict(missing), 'pairs': pairs, 'minimum_distance_mm': minimum,
                        'charged_material_mm2': material, 'original_CLI_quantity_only_failure': True})
        if r['frames'] == 18:
            complete_groups.setdefault(tuple(ids), []).append(key)
    groups = [{'case': n, 'selected_indices': list(ids), 'source_incumbents': incs}
              for n, (ids, incs) in enumerate(complete_groups.items())]
    write(OUT / 'complete-frame-groups.json', groups)
    check = {'all_returned_layouts_checked': len(records), 'records': records,
             'complete_18_frame_groups': len(groups), 'fresh_frozen_CLI_calls': len(records),
             'necessary_frame_capacity_reached': bool(groups), 'full_target_witness': False,
             'native_margin_qualified': False, 'native_packing_calls': 0, 'quality_runs': 0}
    write(OUT / 'checks.json', check)
    print(json.dumps({k: v for k, v in check.items() if k != 'records'}), flush=True)

if __name__ == '__main__':
    main()
