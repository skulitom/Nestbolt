"""Freeze a feasible-iterate search, distinct from the closed SLSQP call."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil
ROOT=Path(__file__).resolve().parents[1]; PRIOR=ROOT/'output/h5-continuous-cog-source-20261028'; OUT=ROOT/'output/h5-feasible-cog-source-20261028'
load=lambda p:json.loads(p.read_bytes()); digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
assert load(PRIOR/'contract-audit/checks.json')['passed'] and load(PRIOR/'search/result.json')['closed']
plan=load(PRIOR/'plan.json')
inputs=[PRIOR/'plan.json',PRIOR/'initial.json',PRIOR/'part.json',PRIOR/'control-source15.json',PRIOR/'contract-audit/checks.json',ROOT/'output/h5_feasible_cog_model_20261028.py',ROOT/'output/h5_continuous_cog_source_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
for n in ['part.json','initial.json','control-source15.json']:shutil.copyfile(PRIOR/n,OUT/n)
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'source_center_mm':plan['source_center_mm'],'required_source_gap_mm':plan['required_source_gap_mm'],'native_stock_guard_mm':plan['native_stock_guard_mm'],'construction_gap_mm':.224,'construction_stock_extra_mm':.013,'variables':'15 independent (centerX mm, centerY mm, angle degrees), top mm; underlying geometry converts to metres/radians','variable_count':46,'constraint_count':180,'angle_domain_degrees':[0,18],'constructive_subset_only':True,'source_symmetry_claimed':False,'algorithm':'one deterministic feasible-iterate sequence; finite-difference LP directions, exact-source backtracking, adaptive bounded trust region','objective':'top mm; actual height checked independently','derivative_steps':[.0001,.0001,.00001],'initial_radius':[2,2,.25],'top_radius_mm':2,'linear_reserve_mm':.00002,'accepted_reserve_mm':.00001,'minimum_radius_scale':.00005,'radius_shrink':.5,'radius_growth':1.5,'radius_maximum_scale':1,'max_iterations':80,'max_backtracking_trials_per_direction':14,'max_geometry_evaluations':10000,'search_seconds':60,'shared_seconds':90,'lp_time_limit_seconds':2,'maximum_search_sequences':1,'random_restarts':0,'retry_permitted':False,'minimum_top_decrease_mm':.0000001,'source_checks_required_before_acceptance':True,'other_originals_required':51,'native_calls':0,'full66_witness':False,'H5_complete':False})
print({'prepared':str(OUT),'search_started':False})
