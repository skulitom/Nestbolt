"""One bounded feasible-iterate trust-region search with exact acceptance."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-feasible-cog-source-20261028';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
class BudgetStop(Exception):pass
def child():
    import numpy as np
    import scipy
    from scipy.optimize import linprog
    from h5_feasible_cog_model_20261028 import FeasibleProblem,SCALE
    model=FeasibleProblem(BASE);p=model.plan;q=model.initial.copy();scale=1.;calls=0;accepted=[];trials=[];iterations=[];best=None
    assert load(BASE/'preflight/checks.json')['passed']
    for n,h in load(OUT/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    started=time.perf_counter();deadline=started+p['search_seconds']
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'scipy_version':scipy.__version__,'numpy_version':np.__version__,'one_search_sequence':True,'plan_sha256':digest(BASE/'plan.json'),'search_seconds':60,'shared_seconds':90,'maximum_iterations':80,'max_geometry_evaluations':10000,'max_backtracking_trials_per_direction':14,'lp_method':'highs-ds','lp_threads':1,'lp_maxiter':10000,'lp_primal_feasibility_tolerance':1e-8,'lp_dual_feasibility_tolerance':1e-8})
    def evaluate(x):
        nonlocal calls
        if time.perf_counter()>=deadline:raise BudgetStop('TIME_LIMIT')
        if calls>=p['max_geometry_evaluations']:raise BudgetStop('EVALUATION_LIMIT')
        r,d=model.evaluate(x);calls+=1;assert np.isfinite(r).all() and np.isfinite(x).all();return r,d
    def save(x,diag,iteration,alpha):
        nonlocal best
        entry={'sequence':len(accepted),'iteration':iteration,'alpha':alpha,'evaluation':calls,'seconds':time.perf_counter()-started,'variables':x.tolist(),'diagnostics':diag}
        write(OUT/'accepted'/f'{len(accepted):04d}.json',entry);accepted.append(entry)
        if best is None or diag['height_mm']<best['diagnostics']['height_mm']:best=entry
    status='ITERATION_LIMIT';error=None
    try:
        r,diag=evaluate(q);assert r.min()>=p['accepted_reserve_mm'] and diag['physical_source_outer_valid'];save(q,diag,-1,0)
        for iteration in range(p['max_iterations']):
            if time.perf_counter()>=deadline:raise BudgetStop('TIME_LIMIT')
            if scale<p['minimum_radius_scale']:status='MINIMUM_RADIUS';break
            r,jac,endpoints=model.linearize(q,evaluate)
            c,A,b,bounds=model.proposal(q,r,jac,scale)
            lp_input={'iteration':iteration,'variables':q.tolist(),'radius_scale':scale,'residuals_mm':r.tolist(),'jacobian':jac.tolist(),'finite_difference_endpoints':endpoints,'objective':c.tolist(),'A_ub':A.tolist(),'b_ub':b.tolist(),'bounds':bounds}
            write(OUT/'directions'/f'{iteration:03d}-input.json',lp_input)
            remaining=deadline-time.perf_counter()
            if remaining<=0:raise BudgetStop('TIME_LIMIT')
            limit=min(p['lp_time_limit_seconds'],remaining);before=time.perf_counter()
            result=linprog(c,A_ub=A,b_ub=b,bounds=bounds,method='highs-ds',options={'time_limit':limit,'maxiter':10000,'presolve':True,'threads':1,'primal_feasibility_tolerance':1e-8,'dual_feasibility_tolerance':1e-8})
            lp={'iteration':iteration,'success':bool(result.success),'status':int(result.status),'message':str(result.message),'seconds':time.perf_counter()-before,'time_limit_seconds':limit,'nit':int(result.nit),'objective':float(result.fun) if result.fun is not None else None,'direction':result.x.tolist() if result.x is not None else None}
            write(OUT/'directions'/f'{iteration:03d}-response.json',lp)
            step={'iteration':iteration,'radius_scale':scale,'lp_status':lp['status'],'accepted':False,'trials':0}
            iterations.append(step)
            if not result.success:status='LP_NOT_OPTIMAL';break
            delta=np.asarray(result.x);assert (A@delta-b).max()<=1e-7 and all(lo-1e-7<=v<=hi+1e-7 for v,(lo,hi) in zip(delta,bounds))
            if -delta[45]<p['minimum_top_decrease_mm']:status='NO_LOCAL_DESCENT';break
            for k in range(p['max_backtracking_trials_per_direction']):
                alpha=2.**(-k);candidate=q+alpha*delta
                rr,dd=evaluate(candidate)
                bounded=all(lo-1e-9<=v<=hi+1e-9 for v,(lo,hi) in zip(candidate,model.bounds))
                ok=bool(bounded and dd['physical_source_outer_valid'] and rr.min()>=p['accepted_reserve_mm'] and candidate[45]<q[45]-p['minimum_top_decrease_mm'])
                trials.append({'iteration':iteration,'backtracking_index':k,'alpha':alpha,'variables':candidate.tolist(),'minimum_residual_mm':float(rr.min()),'accepted':ok,'diagnostics':dd});step['trials']+=1
                if ok:
                    q=candidate;save(q,dd,iteration,alpha);step['accepted']=True;step['alpha']=alpha
                    scale=min(1.,scale*p['radius_growth']) if alpha==1 else scale*p['radius_shrink'] if alpha<.25 else scale
                    break
            if not step['accepted']:scale*=p['radius_shrink']
    except BudgetStop as e:status=str(e)
    except Exception as e:status='ERROR';error=repr(e)
    seconds=time.perf_counter()-started
    if best is not None:
        write(OUT/'best.json',best);write(OUT/'best-source15.json',model.source.rows(np.asarray(best['variables'])/SCALE))
    write(OUT/'trials.json',trials);write(OUT/'iterations.json',iterations)
    write(OUT/'result.json',{'status':status,'error':error,'closed':True,'search_sequences':1,'random_restarts':0,'lp_calls':len(iterations),'geometry_evaluations':calls,'accepted_including_control':len(accepted),'backtracking_trials':len(trials),'search_seconds':seconds,'soft_overrun_seconds':max(0,seconds-60),'best_height_mm':best['diagnostics']['height_mm'] if best else None,'best_width_mm':best['diagnostics']['width_mm'] if best else None,'best_sequence':best['sequence'] if best else None,'source_readback_required':True,'global_optimum_claimed':False,'full66_witness':False,'native_calls':0,'H5_complete':False})
def main():
    OUT.mkdir();(OUT/'directions').mkdir();(OUT/'accepted').mkdir();shutil.copyfile(__file__,OUT/'run.py')
    inputs=[p for p in BASE.rglob('*') if p.is_file() and OUT not in p.parents]+[ROOT/'output/h5_feasible_cog_model_20261028.py',ROOT/'output/h5_continuous_cog_source_20261028.py',Path(__file__)]
    write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'search_sequences':1,'retry_permitted':False,'search_seconds':60,'shared_seconds':90})
    started=time.perf_counter()
    try:
        process=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90)
        (OUT/'stdout.txt').write_bytes(process.stdout);(OUT/'stderr.txt').write_bytes(process.stderr);record={'seconds':time.perf_counter()-started,'exit_code':process.returncode,'timeout':False,'closed':True}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');record={'seconds':time.perf_counter()-started,'timeout':True,'closed':True}
    write(OUT/'process.json',record);print(record);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No completed response; shared call closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
