"""No search: explain the saved first LP direction using original edge features."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-feasible-cog-source-20261028';OUT=BASE/'contact-diagnosis';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'diagnose.py');started=time.perf_counter()
jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';job=load(jobpath);part=next(p for p in job['parts'] if p['id']=='cog');vertices=np.asarray(part['geometry'][0]['outer'])-139.723742
inp=load(BASE/'search/directions/000-input.json');returned=load(BASE/'search/directions/000-response.json');q=np.asarray(inp['variables']);delta=np.asarray(returned['direction']);jac=np.asarray(inp['jacobian']);alpha=.0001
assert load(BASE/'search/result.json')['closed'] and load(BASE/'source-audit/checks.json')['passed']
def shapes(z):
    result=[]
    for i in range(15):
        x,y,d=z[3*i:3*i+3];a=math.radians(d);c,s=math.cos(a),math.sin(a)
        result.append(np.array([(px*c-py*s+x,px*s+py*c+y) for px,py in vertices]))
    return result
initial=shapes(q);forward=shapes(q+alpha*delta);backward=shapes(q-alpha*delta)
def features(a,b):
    start=b;edge=np.roll(b,-1,axis=0)-b;diff=a[:,None,:]-start[None,:,:]
    t=np.clip(np.sum(diff*edge[None,:,:],axis=2)/np.sum(edge*edge,axis=1)[None,:],0,1)
    closest=start[None,:,:]+t[:,:,None]*edge[None,:,:];separation=closest-a[:,None,:];dist=np.linalg.norm(separation,axis=2)
    return dist,closest,t
records=[];max_error=0.;feature_count=0;direction_error=[];near_pairs=0
for pair_index,(ia,ib) in enumerate(combinations(range(15),2)):
    a,b=initial[ia],initial[ib];source_distance=Polygon(a).distance(Polygon(b))
    da,ca,ta=features(a,b);db,cb,tb=features(b,a)
    minimum=min(float(da.min()),float(db.min()));assert abs(minimum-source_distance)<1e-10
    if source_distance>1:continue
    near_pairs+=1;rows=[]
    for reverse,(dist,closest,t) in enumerate([(da,ca,ta),(db,cb,tb)]):
        for vertex,edge in np.argwhere(dist<=minimum+.01):
            pa,pb=(a[vertex],closest[vertex,edge]) if not reverse else (closest[vertex,edge],b[vertex])
            d=float(dist[vertex,edge]);normal=(pb-pa)/d;ra=pa-q[3*ia:3*ia+2];rb=pb-q[3*ib:3*ib+2]
            ga=np.array([-normal[0],-normal[1],-float(normal@np.array([-ra[1],ra[0]]))*math.pi/180])
            gb=np.array([normal[0],normal[1],float(normal@np.array([-rb[1],rb[0]]))*math.pi/180])
            slope=float(ga@delta[3*ia:3*ia+3]+gb@delta[3*ib:3*ib+3])
            rows.append({'vertex_owner':ib if reverse else ia,'vertex':int(vertex),'edge_owner':ia if reverse else ib,'edge':int(edge),'edge_parameter':float(t[vertex,edge]),'distance_mm':d,'gradient_a':ga.tolist(),'gradient_b':gb.tolist(),'directional_slope_mm':slope})
    plus=Polygon(forward[ia]).distance(Polygon(forward[ib]));minus=Polygon(backward[ia]).distance(Polygon(backward[ib]));predict_plus=min(r['distance_mm']+alpha*r['directional_slope_mm'] for r in rows);predict_minus=min(r['distance_mm']-alpha*r['directional_slope_mm'] for r in rows)
    err=max(abs(predict_plus-plus),abs(predict_minus-minus));assert err<1e-6;max_error=max(max_error,err)
    averaged=float(jac[75+pair_index]@delta);one_sided=(plus-source_distance)/alpha;optimism=averaged-one_sided
    active=[r for r in rows if r['distance_mm']<=minimum+1e-7]
    feature_count+=len(rows);direction_error.append(optimism)
    records.append({'copies':[ia,ib],'source_pair_index':pair_index,'source_distance_mm':source_distance,'near_features':rows,'features_within_1e_7mm_of_minimum':len(active),'finite_difference_model_directional_slope':averaged,'actual_forward_secant_slope':one_sided,'model_optimism_mm_per_unit_step':optimism,'direct_forward_distance_mm':plus,'feature_forward_prediction_mm':predict_plus,'direct_backward_distance_mm':minus,'feature_backward_prediction_mm':predict_minus,'max_linear_feature_error_mm':err})
assert records and max(direction_error)>1
worst=max(records,key=lambda r:r['model_optimism_mm_per_unit_step'])
write(OUT/'pairs.json',records)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_pairs_enumerated':105,'vertex_edge_distance_checks':105*2*80*80,'near_pairs_diagnosed':near_pairs,'retained_near_vertex_edge_features':feature_count,'forward_and_backward_direct_source_checks':2*near_pairs,'direction_fraction':alpha,'maximum_feature_prediction_error_mm':max_error,'maximum_finite_difference_directional_optimism':max(direction_error),'worst_cog_pair':worst['copies'],'worst_pair_active_features':worst['features_within_1e_7mm_of_minimum'],'worst_pair_model_slope':worst['finite_difference_model_directional_slope'],'worst_pair_actual_forward_slope':worst['actual_forward_secant_slope'],'near_tied_features_can_make_coordinate_finite_differences_overoptimistic':True,'local_feature_models_are_not_global_geometry_certificates':True,'new_optimizer_calls':0,'new_placement_accepted':False,'full66_witness':False,'H5_complete':False})
write(OUT/'plan.json',{'inputs':{x.relative_to(ROOT).as_posix():digest(x) for x in [jobpath,BASE/'plan.json',BASE/'search/result.json',BASE/'search/directions/000-input.json',BASE/'search/directions/000-response.json',BASE/'source-audit/checks.json']},'proposal':'saved first LP direction only','new_solver_calls':0,'fraction':alpha,'near_pair_gap_limit_mm':1,'feature_distance_window_mm':.01,'near_tie_reporting_window_mm':1e-7})
print(load(OUT/'checks.json'))
