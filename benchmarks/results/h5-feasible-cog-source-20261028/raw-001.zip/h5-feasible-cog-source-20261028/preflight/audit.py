"""Scalar original-ring finite differences audit the mixed-unit proposal matrix."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,shutil,time
import numpy as np
from shapely.geometry import Polygon
from h5_feasible_cog_model_20261028 import FeasibleProblem,SCALE
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-feasible-cog-source-20261028';OUT=BASE/'preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();model=FeasibleProblem(BASE);p=model.plan
for n,h in p['inputs'].items():assert digest(ROOT/n)==h,n
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');part=next(x for x in job['parts'] if x['id']=='cog');assert part==load(BASE/'part.json')
q=model.initial; rows=load(BASE/'control-source15.json');source=audit(job,rows,{'sheet-0':[6.5,6.5,1493.5,2993.5]},p['required_source_gap_mm'],p['native_stock_guard_mm'],{('cog',i) for i in range(15)});assert source['valid']
write(OUT/'source-control.json',source)
def independent(v):
    polygons=[]
    for i in range(15):
        x,y,deg=v[3*i:3*i+3];a=math.radians(deg);c,s=math.cos(a),math.sin(a)
        polygons.append(Polygon([((px-139.723742)*c-(py-139.723742)*s+x,(px-139.723742)*s+(py-139.723742)*c+y) for px,py in part['geometry'][0]['outer']]))
    residuals=[]
    for shape in polygons:
        x0,y0,x1,y1=shape.bounds;residuals += [x0-6.513,1493.487-x1,y0-6.513,2993.487-y1,v[45]-y1]
    for a,b in combinations(polygons,2):residuals.append((a.distance(b) if a.disjoint(b) else -math.sqrt(a.intersection(b).area))-.224)
    return np.asarray(residuals)
r,jac,used=model.linearize(q,model.evaluate);ref=independent(q);assert np.max(np.abs(ref-r))<1e-9 and r.min()>p['linear_reserve_mm']
reference=np.zeros_like(jac)
for i,step in enumerate(model.steps):
    lo,hi=model.bounds[i];a=max(lo,q[i]-step);b=min(hi,q[i]+step);left=q.copy();right=q.copy();left[i]=a;right[i]=b
    assert used[i]==[a,b];reference[:,i]=(independent(right)-independent(left))/(b-a)
error=float(np.max(np.abs(reference-jac)));assert error<1e-6
# Finite differences are local approximations, not source-feasibility certificates.
assert np.max(np.abs(jac[75:,0:45:3].sum(axis=1)))<1e-7
assert np.max(np.abs(jac[75:,1:45:3].sum(axis=1)))<1e-7
top=np.zeros(180);top[4:75:5]=1;assert np.max(np.abs(jac[:,45]-top))<1e-8
c,A,b,bounds=model.proposal(q,r,jac,1)
assert c.tolist()==[0.]*45+[1.] and np.array_equal(A,-jac) and np.array_equal(b,r-p['linear_reserve_mm'])
assert (b>=0).all() and all(lo<=0<=hi for lo,hi in bounds)
assert bounds==[(max(lo-v,-radius),min(hi-v,radius)) for v,(lo,hi),radius in zip(q,model.bounds,model.radius)]
bad=q.copy();bad[3:6]=bad[:3];bad_r,bad_diag=model.evaluate(bad);assert bad_r.min()<-.2 and not bad_diag['physical_source_outer_valid']
write(OUT/'linearization.json',{'variables':q.tolist(),'residuals_mm':r.tolist(),'jacobian':jac.tolist(),'finite_difference_endpoints':used,'objective':c.tolist(),'A_ub':A.tolist(),'b_ub':b.tolist(),'step_bounds':bounds})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'source_pairs':105,'stock_edges':60,'source_holes':source['cutouts'],'source_hole_vertices':source['hole_vertices'],'independently_checked_jacobian_entries':int(jac.size),'maximum_jacobian_difference':error,'constraints_checked':180,'global_translation_derivative_checks':210,'objective_and_top_derivative_checked':True,'zero_step_satisfies_proposal_model':True,'bounds_checked':46,'independent_geometry_evaluations':93,'overlap_rejection_control':True,'finite_differences_are_approximations':True,'linearized_feasibility_never_certifies_source':True,'search_started':False})
write(OUT/'plan.json',{'inputs':{x.relative_to(ROOT).as_posix():digest(x) for x in [BASE/'plan.json',BASE/'initial.json',BASE/'part.json',BASE/'control-source15.json',ROOT/'output/h5_feasible_cog_model_20261028.py',ROOT/'output/h5_continuous_cog_source_20261028.py',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json']}})
print(load(OUT/'checks.json'))
