"""Seal feasible source iterates and the independently checked contact diagnosis."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
BASE=ROOT/'output/h5-feasible-cog-source-20261028';PUB=BASE/'publication';NAME='h5-feasible-cog-source-20261028';OUT=ROOT/'benchmarks/results'/NAME
load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='a2c0ba463da06f947f6ae8a65dd577a9e437b5f0' and not git('diff','HEAD','--name-only')
pre=load(BASE/'preflight/checks.json');source=load(BASE/'source-audit/checks.json');diagnosis=load(BASE/'contact-diagnosis-corrected/checks.json');run=load(BASE/'search/result.json')
assert all(x['passed'] for x in [pre,source,diagnosis]) and source['source_accepted_verified_including_control']==26 and run['closed'] and .0027<source['height_reduction_mm']<.0028
prior=load(ROOT/'benchmarks/results/h5-continuous-cog-source-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest']
readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main=='8713c6e13a1ad2a9ce33a7276722016264105244'
jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6;passed=[r['name'] for r in jobs if r['status']=='completed' and r['conclusion']=='success'];live=[r['name'] for r in jobs if r['status']!='completed'];assert len(passed)==4 and sorted(live)==['checks (ubuntu-latest)','checks (windows-latest)']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [BASE,ROOT/'output/h5-continuous-cog-pending-main-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['h5_feasible_cog_model_20261028.py','prepare_h5_feasible_cog_20261028.py','audit_h5_feasible_cog_preflight_20261028.py','run_h5_feasible_cog_20261028.py','audit_h5_feasible_cog_response_20261028.py','diagnose_h5_feasible_cog_contacts_20261028.py','diagnose_h5_feasible_cog_contacts_corrected_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for a,b in [('preflight/checks.json','preflight-audit.json'),('source-audit/checks.json','source-audit.json'),('source-audit/accepted-summary.json','source-accepted.json'),('source-audit/best-source15.json','source15.json'),('contact-diagnosis-corrected/checks.json','contact-diagnosis.json'),('contact-diagnosis/failure.json','diagnostic-erratum.json'),('search/result.json','search-result.json'),('publication/main-ci-jobs.json','main-ci-snapshot.json')]:shutil.copyfile(BASE/a,OUT/b)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'queued_verified_commit':head,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'main_CI':40742366525,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
next_action='The sole finite-difference feasible-iterate sequence is CLOSED MINIMUM_RADIUS after25 LP directions,145 source trials and2471 geometry evaluations (3.735082s search,4.707303s shared). All26 accepted states including the control pass105 original pairs/60stock edges/15holes/3000hole vertices; all145 source trials and207000 independent derivative entries were audited. Best is sequence12:height772.199631116mm,width1436.450344214mm, only0.002768279mm shorter and0.002944820mm wider; later lower top values do not give the best actual height. Do not extend/restart this closed sequence or claim local/global optimality. The saved-first-direction diagnosis enumerates1,344,000 original vertex-edge distances and tracks56 nearby features for20 near pairs. Their40 forward/backward source checks agree within1.85e-10mm, while coordinate finite differences overestimate one combined directional slope by0.935299679mm per full step. Preserve the initial failed diagnostic assumption (>1mm optimism) and corrected measured result; no optimizer was rerun. Next replace the single minimum-distance finite-difference constraint with separate near vertex-edge contact constraints, retaining exact source acceptance. Derive a conservative distance window from the declared maximum center/angle displacement; audit all included feature gradients against original-edge motion and test the saved rejected direction before any new solver call. Finite source features and linearizations are proposal machinery, not feasibility or impossibility proofs. Freeze one finite iteration/evaluation/time budget only after a complete positive control passes; do not count micron-scale packet gains as solving the required mixed-part material problem. All other51 originals/full66 source/native/material checks and full H5 matrix remain required. Preserve old source64,444 necessary counts,H2 gate/22 unopened vectors. Local a2c0ba46 and this checkpoint wait for Linux/Windows in main CI40742366525, four jobs passed, before fresh remote guards and normal push. Production/READMEs and upstream versions unchanged; no release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'search_sequences':1,'search_closed':True,'status':run['status'],'source_accepted_verified_including_control':26,'source_trials_verified':145,'original_feature_distance_checks':1344000,'height_improvement_mm':source['height_reduction_mm'],'width_increase_mm':source['width_increase_mm'],'failed_diagnostic_preserved':True,'new_valid_full66':False,'previous_source64_preserved':True,'remaining_necessary_allocations':444,'global_optimum_or_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=f'''# Feasible cog moves and contact diagnosis — 2026-10-28

Exact source checks keep every accepted packet valid, but the height gain is
only **0.002768 mm**, with a **0.002945 mm width increase**. This does not solve
the mechanical material requirement. The sole search is closed at its declared
minimum trust radius. H2/H5 remain open at **60% completed milestone weight**.

Unlike the preceding failed SLSQP call, this sequence accepts a move only when
its actual original polygons pass every pair, stock and top constraint. It uses
15 independent centers and angles plus top, in mm/degrees, and retains the
constructive 0°–18° angle window. Construction clearance remains 0.224 mm and
extra stock clearance 0.013 mm. Linear proposals reserve another 0.000020 mm;
exact acceptance requires a 0.000010 mm residual. These are stricter proposal
rules; the unchanged source acceptance thresholds still govern the audit.

The starting source control passes 105 pairs, 60 stock edges, 15 holes and
3,000 hole vertices. Independent scalar original-ring calculations verify all
8,280 initial derivative entries, the 180 constraints, objective, stock/top
derivatives, mixed units, 46 bounds and the feasible zero step. Finite
differences are approximations, so this model audit never substitutes for
actual source acceptance.

The frozen budget permits one deterministic sequence, at most 80 LP directions,
14 backtracking trials per direction, 10,000 geometry evaluations, 60 seconds
of search and 90 seconds shared time. The initial trust bounds are 2 mm of
translation/top and 0.25° of angle change. Repeatedly short accepted moves shrink
the radius; it cannot be reduced below 0.00005 of the initial radius. Every LP
uses one HiGHS thread and at most two seconds. SciPy's warning that the `threads`
option is passed through to HiGHS is preserved in the raw stderr.

The sequence closes after **25 LP directions, 145 backtracking trials and
2,471 geometry evaluations**, using **3.735082 s search / 4.707303 s shared**.
There are 25 accepted moves plus the original control. Final radius scale is
0.0000457763671875, below the declared floor; no restart or extension occurs.
Independent readback verifies all 26 accepted states and every one of the 145
trials against original rings, angles, holes and stock. It reconstructs all 25
LPs, their bounds and accepted/rejected decisions, including **207,000 derivative
entries**, with maximum discrepancy 4.55e-8. Eighty-two rejected trials meet the
looser physical source threshold but fail the predeclared stricter proposal
rules; they are not silently accepted after the run.

The best actual packet is accepted state **12**:

| Measure | Value |
| --- | ---: |
| Actual height | 772.199631116 mm |
| Actual width | 1,436.450344214 mm |
| Height gain from starting packet | 0.002768279 mm |
| Width cost | 0.002944820 mm |
| Minimum source gap | 0.224056239 mm |
| Minimum extra stock clearance | 0.013707291 mm |
| Cog angle range | 6.999641°–7.000338° |

Its top decreases by 0.002868652 mm, but part of that is translation. Later
states have lower top values yet a slightly greater actual height. Selection
therefore uses independently measured height rather than the top objective.
No local or global optimum is claimed.

## Why the steps shrink

A separate read-only diagnosis uses the saved first LP direction; it does not
start another optimizer. It checks **1,344,000 original vertex-to-edge distances**
over all 105 source pairs. Twenty pairs are within 1 mm. Fifty-six nearby edge
features reproduce 40 direct forward/backward source-distance checks to within
**1.85e-10 mm**, at 0.0001 of the saved direction.

The coordinate finite-difference matrix is too optimistic for some combined
moves as the closest edge feature changes. For cogs 0 and 2, it predicts a
distance slope of 1.841549 mm per full step; direct forward motion gives
0.906249 mm. The pair has two features within 1e-7 mm of its closest distance.
This identifies a limitation of a single derivative for the minimum-distance
function. The source acceptance checks correctly prevented invalid moves.

The first diagnostic incorrectly asserted that this effect must exceed 1 mm
per full step. It failed; that code and failure are preserved. A separate
corrected diagnostic removes the unsupported effect-size assumption and reports
the measured **0.935300 mm** difference. No optimizer or placement was rerun.

The next proposal model should keep the nearby vertex/edge constraints separate,
using an audited distance window derived from the allowed center and angle
motion. Its gradients must be checked against original edge motion and the
saved rejected direction before a new bounded call. Exact source checks remain
mandatory. This does not yet supply the other 51 originals or a complete layout;
all 66 original parts and source/native/material checks remain prerequisites
for integration and the full H5 matrix.

## Publication

Main remains **8713c6e1**, with four successful jobs in
[CI 40742366525](https://github.com/skulitom/Nestbolt/actions/runs/40742366525).
Linux and Windows checks are live. The verified a2c0ba46 checkpoint and this
evidence wait for all six jobs and fresh remote/ancestry/live-run guards before
a normal push. Production and READMEs are unchanged. Sparrow remains
6f7b9d35 / v0.3.0; Studio remains c0bb9e86 without a release. No stop rule fires.
The previous valid64, 444 necessary allocations, original H2 gate and all 22
unopened reserved vectors remain preserved. No release qualifies.

Evidence: [preflight]({NAME}/preflight-audit.json),
[all source/model audits]({NAME}/source-audit.json),
[accepted source states]({NAME}/source-accepted.json),
[contact diagnosis]({NAME}/contact-diagnosis.json),
[preserved diagnostic correction]({NAME}/diagnostic-erratum.json),
[next step]({NAME}/next-step.json),
[raw manifest]({NAME}/raw-manifest.json).
The verified archive contains {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including every LP, trial, original-source readback, input,
script, initial failed diagnostic and corrected contact calculation.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 feasible cog moves and contact diagnosis, 2026-10-28:** [the evidence]({link})
keeps all 26 accepted states source-valid, auditing 145 trials and 207,000
derivative entries. The sole sequence is CLOSED MINIMUM_RADIUS after 25 LPs
(3.735082 s search / 4.707303 s shared). Best actual height is 772.199631 mm,
only 0.002768 mm shorter, with 0.002945 mm added width; no full66/material result.
A read-only original-edge diagnosis finds that changing closest features makes
the single finite-difference constraint too optimistic for combined moves.
Fifty-six nearby features match 40 direct checks within 1.85e-10 mm. Preserve
the failed diagnostic's unsupported >1 mm assertion and corrected measured
0.935300 mm effect; no optimizer was repeated. Next audit separate nearby
vertex/edge constraints and a displacement-derived feature window before any
new bounded call, keeping exact acceptance. The other 51 originals remain
required. Main 8713c6e1 has four passing jobs; Linux/Windows checks remain live.
Queued evidence waits for all six and fresh remote guards before normal push.
Production/READMEs, prior valid64, 444-count frontier, H2 gate and 22 reserved
vectors remain unchanged. H2/H5 stay open at 60%; no release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
