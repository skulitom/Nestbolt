"""Necessary one-dimensional source projection with all mandatory originals."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-insert-order-projection-20261028';SHAPES=ROOT/'output/h5-short13-necessary-geometry-20261028';OUT=ROOT/'output/h5-short13-x-capacity-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(GEO/'audit/checks.json')['passed'];OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();inputs=[GEO/n for n in ['plan.json','profiles.json','pair-distances.json','audit/checks.json']]+[SHAPES/n for n in ['variants.json','stock.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_seconds':60,'shared_seconds':90,'maximum_solver_calls':1,'retry_permitted':False,'method':'A new reduced necessary projection retains all13 original X coordinates, all8 bracket modes, both insert classes and every real cog angle. Include the audited stronger directed spacing for every selected pair, with a free reference-X ordering literal. Optional source-contained rectangle X intervals consume their full source Y heights against the complete312967um short-stock capacity. Use the three disjoint bracket rectangles, one insert rectangle and16 disjoint source-contained cog strips; never double-count the additional full stem used only for spacing proofs. Same-family X order relabels identical copies. There are no Y choices, source cog angles, hints or objectives. This smaller necessary model tests a new structural projection; earlier full2D and source optimizer calls stay closed. Audit every constraint before one60-second/four-worker call inside90 shared seconds. A positive projection requires additional 2D source construction, and is not a source13 or full66 witness.'})
profiles=load(GEO/'profiles.json');ps={p['variant']:p for p in profiles};vs={v['id']:v for v in load(SHAPES/'variants.json')};dist={tuple(r['profiles']):r['minimum_reference_distance_um'] for r in load(GEO/'pair-distances.json')};m=cp_model.CpModel();items=[];xx=[];flags={};families=['bracket']*7+['insert']*5+['cog']
for i,f in enumerate(families):
    choices=[p for p in profiles if p['family']==f];x=m.new_int_var(min(p['reference_x_domain_um'][0] for p in choices),max(p['reference_x_domain_um'][1] for p in choices),f'x_{i}');zs=[m.new_bool_var(f'option_{i}_{p["variant"]}') for p in choices];one=m.add_exactly_one(zs);options=[]
    for p,z in zip(choices,zs):
        lo,hi=p['reference_x_domain_um'];cs=[m.add(x>=lo).only_enforce_if(z),m.add(x<=hi).only_enforce_if(z)];options.append({'variant':p['variant'],'selector':z.index,'domain_constraints':[c.index for c in cs]});flags[i,p['variant']]=z
    items.append({'index':i,'family':f,'x':x.index,'exactly_one':one.index,'options':options});xx.append(x)
symmetry=[{'items':[a,b],'constraint':m.add(xx[a]<=xx[b]).index} for ids in [list(range(7)),list(range(7,12))] for a,b in zip(ids,ids[1:])];rects=[];intervals=[];demands=[]
for it in items:
    i=it['index']
    for o in it['options']:
        v=o['variant'];boxes=vs[v]['source_capacity_rectangles_um'] if v==12 else vs[v]['coarse_rectangles_um']
        for k,b in enumerate(boxes):
            ix=m.new_optional_fixed_size_interval_var(xx[i]+b[0]-ps[v]['reference_x_um'],b[2]-b[0],flags[i,v],f'source_x_{len(rects)}');rects.append({'item':i,'variant':v,'component':k,'bounds_um':b,'presence':o['selector'],'interval':ix.index});intervals.append(ix);demands.append(b[3]-b[1])
cap=m.add_cumulative(intervals,demands,load(SHAPES/'stock.json')['capacity_um'][1]);pairs=[]
for i in range(13):
    for j in range(i+1,13):
        order=m.new_bool_var(f'before_{i}_{j}');choices=[]
        for a in items[i]['options']:
            for b in items[j]['options']:
                p,q=a['variant'],b['variant'];ct1=m.add(xx[j]-xx[i]>=dist[p,q]).only_enforce_if([flags[i,p],flags[j,q],order]);ct2=m.add(xx[i]-xx[j]>=dist[q,p]).only_enforce_if([flags[i,p],flags[j,q],~order]);choices.append({'variants':[p,q],'constraints':[ct1.index,ct2.index]})
        pairs.append({'items':[i,j],'order':order.index,'choices':choices})
assert m.validate()=='' and m.export_to_file(str(OUT/'model.pb')) and m.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',{'items':items,'symmetry':symmetry,'rectangles':rects,'capacity_constraint':cap.index,'pairs':pairs})
write(OUT/'built.json',{'seconds':time.perf_counter()-start,'variables':len(m.proto.variables),'constraints':len(m.proto.constraints),'mandatory_originals':13,'source_rectangles':len(rects),'original_pairs':len(pairs),'all13_required':True,'all_allowed_modes_and_real_cog_angles_retained':True,'model_sha256':digest(OUT/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
