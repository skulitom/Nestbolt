"""Seal the complete short-count exclusion, its source necessity and raw response."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
NAME='h5-short13-x-exclusion-20261028';OUT=ROOT/'benchmarks/results'/NAME;MIXED=ROOT/'output/h5-short-mixed-projection-20261028';FRONT=ROOT/'output/h5-projected-short-frontier-20261028';INSERT=ROOT/'output/h5-insert-order-projection-20261028';MODEL=ROOT/'output/h5-short13-x-capacity-20261028';FAILED=ROOT/'output/h5-short13-x-capacity-preparation-failure-20261028';PUB=MODEL/'publication';SYNC=ROOT/'output/h5-short13-band-main-sync-20261028';load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='541d5bc94c32d4852cc9146dbcc3ff3c6ef67e2d' and not git('diff','HEAD','--name-only')
audits=[MIXED/'audit/checks.json',FRONT/'audit/checks.json',INSERT/'audit/checks.json',MODEL/'model-audit/checks.json',MODEL/'response-audit/checks.json',MODEL/'necessity-audit/checks.json'];assert all(load(p)['passed'] for p in audits)
result=load(MODEL/'response-audit/checks.json');necessity=load(MODEL/'necessity-audit/checks.json');assert result['status']=='INFEASIBLE' and result['closed'] and result['solver_calls']==1 and necessity['remaining_necessary_allocations']==452
old=load(ROOT/'benchmarks/results/h5-short13-source-band-20261028/publication-review.json');production=source_digest();assert production==old['production_digest'];readmes={n:digest(ROOT/n) for n in old['current_readmes']};assert readmes==old['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==old[k] for k in up)
assert load(PUB/'main.json')['commit']['sha']==head;ci=load(PUB/'main-ci-jobs.json')['jobs'];passed=sum(j['conclusion']=='success' for j in ci);running=sum(j['status']!='completed' for j in ci);assert len(ci)==6 and passed==5 and running==1 and next(j for j in ci if j['status']!='completed')['name']=='checks (windows-latest)'
receipt=load(SYNC/'receipt.json');assert receipt['new_main']==head and receipt['normal_atomic_fast_forward'] and receipt['prior_main_all6_pass']
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name=='plan.json' or p.suffix=='.py':queue.append(p)
for folder in [MIXED,FRONT,INSERT,MODEL,FAILED,SYNC]:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['project_h5_short_mixed_spacing_20261028.py','audit_h5_short_mixed_projection_20261028.py','build_h5_projected_short_frontier_20261028.py','audit_h5_projected_short_frontier_20261028.py','prepare_h5_insert_order_projection_20261028.py','audit_h5_insert_order_projection_20261028.py','build_h5_short13_x_capacity_20261028.py','audit_h5_short13_x_capacity_model_20261028.py','run_h5_short13_x_capacity_20261028.py','audit_h5_short13_x_capacity_response_20261028.py','audit_h5_short13_x_capacity_necessity_20261028.py','push_short13_band_checkpoint_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name=='plan.json':
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for f in ['output','scripts']:
                    q=ROOT/f/(module+'.py')
                    if q.is_file():add('imported-helpers/'+f+'/'+q.name,q)
archive,manifest=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
copies=[(MIXED/'audit/checks.json','projection-checks.json'),(MIXED/'projections.json','directed-spacing.json'),(FRONT/'audit/checks.json','core-frontier-checks.json'),(INSERT/'audit/checks.json','insert-projection-checks.json'),(MODEL/'model-audit/checks.json','model-checks.json'),(MODEL/'search/result.json','solver-result.json'),(MODEL/'response-audit/checks.json','response-checks.json'),(MODEL/'necessity-audit/checks.json','necessity-checks.json'),(MODEL/'necessity-audit/necessity-proof.json','necessity-proof.json'),(MODEL/'necessity-audit/newly-excluded-allocations.json','newly-excluded-allocations.json'),(MODEL/'necessity-audit/updated-allocations.json','updated-allocations.json'),(FAILED/'diagnostics.json','preparation-repair.json'),(PUB/'main-ci-jobs.json','main-ci-snapshot.json'),(SYNC/'receipt.json','prior-main-push.json')]
for p,n in copies:shutil.copyfile(p,OUT/n)
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'main_CI':40685021297,'main_CI_five_pass_windows_running':True,'no_main_push_before_all6_pass':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
write(OUT/'checks.json',{'passed':True,'all6_independent_audits_passed':True,'complete_integer_y_values_verified':983930,'source_projection_coverage_segments':34,'new_mixed_direction_improvements':8,'model_variables_verified':158,'model_constraints_verified':4372,'status':'INFEASIBLE','solver_calls':1,'closed':True,'excluded_short_counts':[7,5,1],'upward_closure_new_exclusions':[[7,5,1],[7,6,1]],'remaining_necessary_allocations':452,'known_source12_false_rejections':0,'full66_exclusion_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
next_action='The7-bracket/5-insert/1-cog short allocation is now excluded by a complete, audited necessary source X-capacity model, not merely a failed construction. Its upward closure also excludes7/6/1. Update all future count choices to the complete452-survivor frontier in updated-allocations.json; never return to7/5/1 or7/6/1, and do not repeat the closed2.037863-second INFEASIBLE call. Every previous UNKNOWN and failed-source result remains preserved. The known valid7/4/1 prefix and8/5/0 short construction remain possible. Return to the best full source64 layout, whose8 brackets/5 inserts on the short sheet already pass original geometry. A materially different source completion can free the entire first-sheet packet: all15 cogs, all4 first-sheet brackets8..11 and all5 upper inserts16..20, while retaining only the independently valid42-original core (first-sheet18 frames plus inserts5..15, and short-sheet8 brackets plus inserts0..4). This has24 mandatory movers; the earlier17-mover phase7 call fixed the two existing corner brackets and allfive upper inserts, so its failure does not exclude the larger24-mover domain. Audit a newly prepared original-source model before any single bounded call; keep all originals, guards, stock and material metric unchanged. Only a full source-valid66 can proceed to native and the full H5 matrix. Main541d5bc9 contains both prior checkpoints and its CI40685021297 has five successful jobs with Windows checks still live at this checkpoint. Commit this evidence locally and preserve that run until allsix jobs pass before the next normal main push. H2 retains the explicit unchanged-gate decision, all22 reserved vectors remain unopened, and no release qualifies.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
report=f'''# Source projection excludes the short-sheet 7/5/1 allocation — 2026-10-28

**Seven brackets, five inserts and one cog cannot fit the target short sheet.**
The new necessary model returns INFEASIBLE, and its geometry, complete serialized
model, solver response and source-to-model mapping pass independent audits.
Deleting extra parts preserves feasibility, so seven brackets, six inserts and
one cog is excluded too. The complete count frontier shrinks from **454 to 452**
remaining candidates. This does not exclude the full 66-part job or establish
that any surviving allocation is feasible.

## Exact horizontal spacing

Project the audited inner-octagon, actual-vertex edge and closed-corner regions
over every integer cog-minus-anchor Y in the complete outward stock domains.
Thirty-four interval-chain certificates cover all **983,930 integer Y values**.
The independent reader checks 13,825,864 integer facet inequalities and 780
outside-endpoint region checks. Every cog angle remains covered by the original
source theorems; no angle sampling is used to establish completeness.

Eight bracket–cog directions become stricter, by up to **23.375 mm**. Combining
them with the previous source-support directions preserves the stronger bound
on each side. All 6,985 mixed spacing checks across 635 valid source12 prefixes
pass. Recomputing the complete ordered core frontier advances 79 earliest
positions but, on its own, excludes no additional count allocation.

The next projection includes all five mandatory inserts. Its 11 profile types
and 121 directed pair distances pass an independent reader, including 49
complete-domain rectangle overlap cases. All 41,910 pair checks and 1,270
insert-triple checks across the valid prefixes pass. Three source-inner insert
heights exceed the relaxed sheet height by 17.021 mm, providing a further
necessary capacity condition.

## Complete source X-capacity model

The reduced model keeps all 13 original reference-X coordinates, every allowed
bracket/insert mode and all real cog angles. A free ordering literal for each
pair selects its audited directional spacing. Optional source-contained X
intervals consume their full Y heights against the relaxed 312.967 mm stock
height. These comprise the disjoint bracket rectangles, insert rectangles and
16 disjoint cog strips. Full stems used only in spacing proofs are never added
again to cumulative demand.

All **158 variables and 4,372 constraints** are independently verified, including
194 optional source rectangles, 78 original pairs and 2,010 selected-mode pairs.
Same-family X order only relabels identical copies. No Y position or cog angle
is fixed, and there are no objectives, hints or assumptions. Every valid
original-source placement would map to this relaxed model.

The sole call, using four workers with `fj` excluded, returns **INFEASIBLE** after
68,907 branches and 25,215 conflicts. Solver wall time is 2.036771 seconds;
returned solve time **2.037863 seconds**; shared process time 2.713545 seconds.
There is no overrun, retry or extension. The response reader confirms the exact
model bytes, parameters, counters and terminal status. As positive controls,
all 635 source-valid12 prefixes pass independent cumulative sweeps of 26,035
rectangles, with at least 2.979 mm spare height.

An initial preparation failed because the installed OR-Tools list overload of
`only_enforce_if` returned no fluent constraint object. Its scripts, diagnostic
and premature missing-model audit failure are retained. The fix stores the
constraint before applying enforcement; no solver call had opened. The repaired
model subsequently passed the full audit before its single call.

## Scope and next construction

Among all 4,576 original count allocations, only `[7,5,1]` and `[7,6,1]` are newly
excluded. The 452 survivors and all original complementary first-sheet counts
are preserved. The known valid `[7,4,1]` prefix and `[8,5,0]` short construction
remain allowed. There is no full66 exclusion, source66 witness or native pass.

Return to the best source64 layout and consider freeing its whole first-sheet
packet: 15 cogs, four brackets and five upper inserts, with the valid 42-part
core retained. This allows the two existing corner brackets and five inserts
to move, unlike the closed 17-mover phase7 construction. Any new source model
must pass preflight and retain all parts, guards and the original material
target. Native validation still requires a complete source-valid66.

Main `541d5bc9` contains both prior checkpoints. Its
[CI 40685021297](https://github.com/skulitom/Nestbolt/actions/runs/40685021297)
has five successful jobs and Windows checks still running at this checkpoint;
preserve that run before the next main push. Production, READMEs and upstream
heads/releases are unchanged. H2/H5 remain open at **60% completed milestone
weight**; all 22 reserved vectors remain unopened, and no release qualifies.

[Projection audit]({NAME}/projection-checks.json),
[full model audit]({NAME}/model-checks.json),
[closed response]({NAME}/response-checks.json),
[source necessity proof]({NAME}/necessity-proof.json),
[updated complete frontier]({NAME}/updated-allocations.json),
[next step]({NAME}/next-step.json),
[byte-verified archive]({NAME}/raw-manifest.json).
The archive preserves {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including all source inputs, coverage certificates, models,
auditors, failed preparation, raw logs and the previous main-push receipt.
'''
with (ROOT/'benchmarks/results'/f'{NAME}.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 short-sheet 7/5/1 exclusion, 2026-10-28:** [the evidence]({link})
certifies stronger horizontal source spacing across all 983,930 integer relative
Y values and every real cog angle. Eight mixed directions improve by up to
23.375 mm; the core-only frontier still has 454 survivors. Including every
mandatory insert and source height in a reduced X-capacity model gives 158
variables / 4,372 independently verified constraints. Its sole call returns
INFEASIBLE after 68,907 branches / 25,215 conflicts in 2.037863 returned /
2.713545 shared seconds, without overrun. Source mapping and positive controls
pass: all 635 valid source12 prefixes satisfy 41,910 pair-spacing checks and
26,035 source-rectangle capacity checks. Seven brackets/five inserts/one cog is
excluded on the target short sheet; upward closure also excludes 7/6/1. The
complete frontier retains 452 possible count allocations. This is not a full66
exclusion or witness. Stop both excluded allocation branches and return to a
different full source construction, such as freeing all 24 first-sheet packet
parts around the valid 42-part core. Main541d5bc9 has five passing CI jobs and
Windows still running; preserve it before the next main push. Production,
READMEs and upstream releases are unchanged. H2/H5 stay open at 60%; all 22
reserved vectors remain unopened, and no new release qualifies.
'''
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'bound_source_inputs':len(bindings),'remaining_necessary_allocations':452,'completion_percent':60})
