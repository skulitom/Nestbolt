"""Independent readback of the complete one-dimensional necessary model."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from ortools.sat import cp_model_pb2
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short13-x-capacity-20261028';GEO=ROOT/'output/h5-insert-order-projection-20261028';SHAPES=ROOT/'output/h5-short13-necessary-geometry-20261028';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEO/'audit/checks.json')['passed'];p=cp_model_pb2.CpModelProto();p.ParseFromString((BASE/'model.pb').read_bytes());assert not p.HasField('objective') and not p.HasField('floating_point_objective') and not p.solution_hint.vars and not p.assumptions and not p.search_strategy
profiles=load(GEO/'profiles.json');ps={p['variant']:p for p in profiles};vs={v['id']:v for v in load(SHAPES/'variants.json')};dist={tuple(r['profiles']):r['minimum_reference_distance_um'] for r in load(GEO/'pair-distances.json')};mp=load(BASE/'mapping.json');vi=ci=0;LOW=-9223372036854775808;HIGH=9223372036854775807
def var(ix,name,domain):
    global vi
    assert ix==vi and p.variables[ix].name==name and list(p.variables[ix].domain)==domain;vi+=1
def linear(ix,co,domain,enforcement=[]):
    global ci
    assert ix==ci;ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='linear' and list(ct.enforcement_literal)==enforcement and dict(zip(ct.linear.vars,ct.linear.coeffs))==co and list(ct.linear.domain)==domain;ci+=1
def expr(e,co,offset=0):assert dict(zip(e.vars,e.coeffs))==co and e.offset==offset
assert len(mp['items'])==13
for i,(f,r) in enumerate(zip(['bracket']*7+['insert']*5+['cog'],mp['items'])):
    assert r['index']==i and r['family']==f;choices=[s for s in profiles if s['family']==f];var(r['x'],f'x_{i}',[min(s['reference_x_domain_um'][0] for s in choices),max(s['reference_x_domain_um'][1] for s in choices)]);assert len(r['options'])==len(choices)
    for o,s in zip(r['options'],choices):assert o['variant']==s['variant'];var(o['selector'],f'option_{i}_{s["variant"]}',[0,1])
    assert r['exactly_one']==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='exactly_one' and not ct.enforcement_literal and list(ct.exactly_one.literals)==[o['selector'] for o in r['options']];ci+=1
    for o,s in zip(r['options'],choices):
        lo,hi=s['reference_x_domain_um'];assert len(o['domain_constraints'])==2;linear(o['domain_constraints'][0],{r['x']:1},[lo,HIGH],[o['selector']]);linear(o['domain_constraints'][1],{r['x']:1},[LOW,hi],[o['selector']])
expected_order=list(zip(range(6),range(1,7)))+list(zip(range(7,11),range(8,12)));assert len(mp['symmetry'])==10
for (a,b),r in zip(expected_order,mp['symmetry']):assert r['items']==[a,b];linear(r['constraint'],{mp['items'][a]['x']:1,mp['items'][b]['x']:-1},[LOW,0])
ri=0;intervals=[];demands=[]
for it in mp['items']:
    for o in it['options']:
        v=o['variant'];boxes=vs[v]['source_capacity_rectangles_um'] if v==12 else vs[v]['coarse_rectangles_um']
        for k,b in enumerate(boxes):
            r=mp['rectangles'][ri];assert r=={'item':it['index'],'variant':v,'component':k,'bounds_um':b,'presence':o['selector'],'interval':ci};ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='interval' and ct.name==f'source_x_{ri}' and list(ct.enforcement_literal)==[o['selector']];expr(ct.interval.start,{it['x']:1},b[0]-ps[v]['reference_x_um']);expr(ct.interval.end,{it['x']:1},b[2]-ps[v]['reference_x_um']);expr(ct.interval.size,{},b[2]-b[0]);intervals.append(ci);demands.append(b[3]-b[1]);ci+=1;ri+=1
assert ri==len(mp['rectangles'])==194 and mp['capacity_constraint']==ci;ct=p.constraints[ci];assert ct.WhichOneof('constraint')=='cumulative' and not ct.enforcement_literal and list(ct.cumulative.intervals)==intervals;assert len(ct.cumulative.demands)==len(demands)
for e,d in zip(ct.cumulative.demands,demands):expr(e,{},d)
expr(ct.cumulative.capacity,{},312967);ci+=1;pi=0;modepairs=0
for i in range(13):
    for j in range(i+1,13):
        r=mp['pairs'][pi];assert r['items']==[i,j];z=r['order'];var(z,f'before_{i}_{j}',[0,1]);expected=[(a,b) for a in mp['items'][i]['options'] for b in mp['items'][j]['options']];assert len(r['choices'])==len(expected)
        for saved,(a,b) in zip(r['choices'],expected):
            aa,bb=a['variant'],b['variant'];assert saved['variants']==[aa,bb] and len(saved['constraints'])==2;x,y=mp['items'][i]['x'],mp['items'][j]['x'];linear(saved['constraints'][0],{y:1,x:-1},[dist[aa,bb],HIGH],[a['selector'],b['selector'],z]);linear(saved['constraints'][1],{x:1,y:-1},[dist[bb,aa],HIGH],[a['selector'],b['selector'],-z-1]);modepairs+=1
        pi+=1
assert pi==len(mp['pairs'])==78 and vi==len(p.variables) and ci==len(p.constraints)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variables_verified':vi,'constraints_verified':ci,'source_rectangles_verified':ri,'original_pairs_verified':pi,'selected_mode_pairs_verified':modepairs,'all13_required':True,'every_mode_and_all_real_cog_angles_retained':True,'no_fixed_coordinates_objective_hints_or_assumptions':True,'double_counted_stems':False,'model_sha256':digest(BASE/'model.pb'),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
