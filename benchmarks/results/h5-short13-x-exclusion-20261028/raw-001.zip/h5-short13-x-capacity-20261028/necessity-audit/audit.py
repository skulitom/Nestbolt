"""Source-capacity consistency and upward closure of the audited count exclusion."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short13-x-capacity-20261028';OUT=BASE/'necessity-audit';GEO=ROOT/'output/h5-insert-order-projection-20261028';SHAPES=ROOT/'output/h5-short13-necessary-geometry-20261028';SOURCE=ROOT/'output/h5-short13-source-sliding-20261028';FRONT=ROOT/'output/h5-projected-short-frontier-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter();inputs=[BASE/n for n in ['plan.json','model-audit/checks.json','response-audit/checks.json']]+[GEO/n for n in ['profiles.json','pair-distances.json','audit/checks.json']]+[SHAPES/n for n in ['variants.json','stock.json','audit/checks.json']]+[SOURCE/n for n in ['prefix-bank.json','preflight/checks.json']]+[FRONT/n for n in ['allocations.json','audit/checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
for p in inputs:
    if p.name=='checks.json':assert load(p)['passed']
assert load(BASE/'response-audit/checks.json')['status']=='INFEASIBLE';vs={v['id']:v for v in load(SHAPES/'variants.json')};profiles={p['variant']:p for p in load(GEO/'profiles.json')};capacity=load(SHAPES/'stock.json')['capacity_um'][1];assert capacity==312967
def check(rows,label):
    events={};n=0
    for v,anchor in rows:
        r=profiles[v];reference=anchor+r['reference_x_um'];boxes=vs[v]['source_capacity_rectangles_um'] if v==12 else vs[v]['coarse_rectangles_um']
        for x,y,xx,yy in boxes:
            lo=reference+x-r['reference_x_um'];hi=reference+xx-r['reference_x_um'];assert lo<hi and yy>y;events[lo]=events.get(lo,0)+yy-y;events[hi]=events.get(hi,0)-(yy-y);n+=1
    at=peak=0;profile=[]
    for x,delta in sorted(events.items()):
        at+=delta;assert 0<=at<=capacity;peak=max(peak,at);profile.append([x,at])
    assert at==0;return {'label':label,'source_rectangles':n,'peak_height_um':peak,'minimum_capacity_slack_um':capacity-peak,'sweep':profile}
checks=[]
for p in load(SOURCE/'prefix-bank.json'):
    rows=[]
    for i,(xy,mi) in enumerate(zip(p['anchors'],p['modes'])):
        if xy is None:continue
        v=12 if i==12 else mi-36 if mi<44 else 9 if mi==44 else 8;rows.append((v,math.floor(xy[0]*1000)))
    checks.append(check(rows,p['prefix']))
write(OUT/'known-source-capacity.json',checks)
prior=load(FRONT/'allocations.json');updated=[];new=[]
for row in prior:
    b,i,c=row['short_counts'];r=dict(row)
    if r['excluded_by'] is None and b>=7 and i>=5 and c>=1:r['excluded_by']='source_x_capacity_7_5_1';new.append(r)
    updated.append(r)
assert [r['short_counts'] for r in new]==[[7,5,1],[7,6,1]];survivors=[r['short_counts'] for r in updated if r['excluded_by'] is None];assert len(survivors)==452 and [7,4,1] in survivors and [8,5,0] in survivors
pareto=[r for r in survivors if not any(q!=r and all(q[k]>=r[k] for k in range(3)) for q in survivors)]
write(OUT/'updated-allocations.json',updated);write(OUT/'newly-excluded-allocations.json',new);write(OUT/'pareto-necessary-counts.json',pareto)
write(OUT/'necessity-proof.json',{'source_geometry_basis':'All noncog rectangles are the disjoint source-contained, inward-rounded rectangles independently verified in the prior geometry audit. The16 cog strips are disjoint in Y and contained in the all-angle source disk after center flooring. The full bracket stems used to establish directed spacing are not added to cumulative demand and therefore are never double-counted. PIH OFF reserves each original filled outer, including its holes.','complete_mapping':'Floor each original anchor/center, then use the audited stem/insert left-edge offset to obtain reference X. The complete outward domains contain those coordinates, and all8 bracket modes and both insert outer classes remain available. Every real cog angle maps to the same guaranteed source strips and all-angle directed spacing. Relabeling identical bracket/insert copies yields the same-family X ordering. For each pair choose the ordering literal matching its reference-X order; ties are allowed wherever the verified bound is zero. All selected pair inequalities then hold by the audited source projection.','capacity_argument':'At every X in an open interval, the active source-contained rectangles have disjoint interior vertical sections in a valid source layout. Their heights therefore sum to at most the relaxed stock height312967um. Components of one source are disjoint, so adding their demands also cannot double-count area. Half-open interval events ignore isolated boundary coincidences conservatively. The serialized model exactly encodes these necessary constraints for all13 mandatory originals. Its audited INFEASIBLE response therefore excludes7 brackets/5 inserts/1 cog on the original, smaller target stock.','upward_closure':'Any source-valid short allocation containing at least7 brackets,5 inserts and1 cog would retain a valid7/5/1 subset after deleting extras; deletion cannot create collisions or stock violations. Therefore all such allocations are excluded. Only[7,5,1] and[7,6,1] were previously surviving among all4576 original count allocations. The other452 survivors remain necessary candidates. No first-sheet arrangement, full66 exclusion, source feasibility of a survivor, native validation or H5 completion follows.','positive_controls':'All635 independently source-valid12 prefixes pass the exact cumulative X sweep and earlier full pair-spacing reader. They contain7 brackets/4 inserts/1 cog and remain allowed by the updated count frontier.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'known_source12_capacity_checks':len(checks),'known_source_rectangles_swept':sum(r['source_rectangles'] for r in checks),'minimum_known_capacity_slack_um':min(r['minimum_capacity_slack_um'] for r in checks),'false_rejections':0,'count_exclusion':[7,5,1],'upward_closure_new_exclusions':[r['short_counts'] for r in new],'all_count_allocations_retained':len(updated),'remaining_necessary_allocations':len(survivors),'pareto_necessary_count_vectors':len(pareto),'short_7_4_1_retained':True,'short_8_5_0_retained':True,'full66_exclusion_claimed':False,'source13_witness':False,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
