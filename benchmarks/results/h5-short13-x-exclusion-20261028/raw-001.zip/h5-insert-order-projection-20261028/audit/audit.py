"""Verify source cores, all directed distances and the insert capacity theorem."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-insert-order-projection-20261028';OUT=BASE/'audit';GEO=ROOT/'output/h5-short13-necessary-geometry-20261028';MIXED=ROOT/'output/h5-short-mixed-projection-20261028';FRONT=ROOT/'output/h5-projected-short-frontier-20261028';STEM=ROOT/'output/h5-all-angle-support-bounds-20261026';SOURCE=ROOT/'output/h5-short13-source-sliding-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'profiles.json',BASE/'pair-distances.json',BASE/'triple-insert-proof.json',SOURCE/'prefix-bank.json',SOURCE/'preflight/checks.json']}})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
vs={v['id']:v for v in load(GEO/'variants.json')};ds={d['variant']:d['bounds_um'] for d in load(GEO/'domains.json')};stems={r['profile']:r['stem_bounds_units1000'] for r in load(STEM/'bracket-direction-bounds.json')};mixed={r['variant']:r for r in load(MIXED/'audit/combined-spacing.json')};prior={tuple(r['profiles']):r['minimum_distance'] for r in load(FRONT/'pair-distances.json')};ps=load(BASE/'profiles.json');assert [r['variant'] for r in ps]==list(range(10))+[12];prof={r['variant']:r for r in ps}
for r in ps:
    p=r['variant'];v=vs[p];core=stems[p] if p<8 else v['coarse_rectangles_um'][0] if p<10 else None;ref=core[0] if core else 0;assert r=={'variant':p,'family':v['family'],'reference_x_um':ref,'source_core_um':core,'source_rectangles_um':v['coarse_rectangles_um']+([core] if p<8 else []),'anchor_domain_um':ds[p],'reference_x_domain_um':[ds[p][0]+ref,ds[p][2]+ref],'insert_width_um':core[2]-core[0] if p in [8,9] else None}
pairs=load(BASE/'pair-distances.json');assert len(pairs)==121 and len({tuple(r['profiles']) for r in pairs})==121;distance={};interval_count=0
for row in pairs:
    a,b=row['profiles'];d=row['minimum_reference_distance_um'];assert a in prof and b in prof and d>=0;distance[a,b]=d
    if a not in [8,9] and b not in [8,9]:assert d==prior[11 if a==12 else a,11 if b==12 else b];continue
    if a==12:assert d==mixed[b]['ordered_cog_to_bracket_minimum_um'];continue
    if b==12:assert d==mixed[a]['ordered_bracket_to_cog_minimum_um'];continue
    pa,pb=prof[a],prof[b];ca,cb=pa['source_core_um'],pb['source_core_um'];da,db=ds[a],ds[b];guaranteed=(da[3]+ca[1]<db[1]+cb[3] and db[3]+cb[1]<da[1]+ca[3]);initial=ca[2]-ca[0] if guaranteed else 0;assert initial==row['initial_distance_um'];expected=[]
    for ri,r in enumerate(pa['source_rectangles_um']):
        for si,s in enumerate(pb['source_rectangles_um']):
            slacks=[db[1]+s[3]-da[3]-r[1],da[1]+r[3]-db[3]-s[1]]
            if min(slacks)>0:expected.append({'rectangles':[ri,si],'strict_y_slacks_um':slacks,'forbidden_open_um':[r[0]-s[2]-pa['reference_x_um']+pb['reference_x_um'],r[2]-s[0]-pa['reference_x_um']+pb['reference_x_um']]})
    assert expected==row['guaranteed_y_overlaps'];interval_count+=len(expected);at=initial
    for lo,hi in row['interval_advances']:
        assert lo==at and hi>lo and hi==max(z['forbidden_open_um'][1] for z in expected if z['forbidden_open_um'][0]<lo<z['forbidden_open_um'][1]);at=hi
    assert at==d and not any(z['forbidden_open_um'][0]<d<z['forbidden_open_um'][1] for z in expected)
t=load(BASE/'triple-insert-proof.json');heights={str(p):prof[p]['source_core_um'][3]-prof[p]['source_core_um'][1] for p in [8,9]};widths={str(p):prof[p]['insert_width_um'] for p in [8,9]};height=load(GEO/'stock.json')['capacity_um'][1];assert t['insert_heights_um']==heights and t['insert_widths_um']==widths and t['relaxed_stock_height_um']==height==312967 and t['three_minimum_heights_um']==3*min(heights.values())>height
known=[];checks=triples=0;minslack=10**12
for row in load(SOURCE/'prefix-bank.json'):
    poses=[]
    for i,(xy,mi) in enumerate(zip(row['anchors'],row['modes'])):
        if xy is None:continue
        v=12 if i==12 else mi-36 if mi<44 else 9 if mi==44 else 8;x=math.floor(xy[0]*1000)+prof[v]['reference_x_um'];assert prof[v]['reference_x_domain_um'][0]<=x<=prof[v]['reference_x_domain_um'][1];poses.append({'item':i,'variant':v,'x_um':x})
    poses.sort(key=lambda p:(p['x_um'],p['item']));slack=10**12
    for i,a in enumerate(poses):
        for b in poses[i+1:]:s=b['x_um']-a['x_um']-distance[a['variant'],b['variant']];assert s>=0;slack=min(slack,s);checks+=1
    inserts=[p for p in poses if p['variant'] in [8,9]]
    for a,b,c in zip(inserts,inserts[1:],inserts[2:]):assert c['x_um']>=min(a['x_um']+widths[str(a['variant'])],b['x_um']+widths[str(b['variant'])]);triples+=1
    known.append({'prefix':row['prefix'],'ordered_projection':poses,'minimum_pair_spacing_slack_um':slack});minslack=min(minslack,slack)
write(OUT/'known-prefixes.json',known)
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'profiles_verified':11,'directed_pair_distances_verified':121,'guaranteed_y_rectangle_pairs_verified':interval_count,'source12_prefixes_checked':len(known),'known_prefix_all_pair_checks':checks,'known_prefix_insert_triples':triples,'minimum_known_prefix_pair_slack_um':minslack,'false_rejections':0,'insert_capacity_theorem_verified':True,'all_original_modes_retained':True,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
