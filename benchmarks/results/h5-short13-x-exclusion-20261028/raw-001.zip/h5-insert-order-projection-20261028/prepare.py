"""Include mandatory inserts in the exact ordered short-stock projection."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-insert-order-projection-20261028';GEO=ROOT/'output/h5-short13-necessary-geometry-20261028';MIXED=ROOT/'output/h5-short-mixed-projection-20261028';FRONT=ROOT/'output/h5-projected-short-frontier-20261028';STEM=ROOT/'output/h5-all-angle-support-bounds-20261026';OLD=ROOT/'output/h5-global-short-frontier-20261026';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
BASE.mkdir();shutil.copyfile(__file__,BASE/'prepare.py');start=time.perf_counter()
inputs=[GEO/n for n in ['variants.json','domains.json','stock.json','audit/checks.json']]+[MIXED/n for n in ['audit/checks.json','audit/combined-spacing.json']]+[FRONT/n for n in ['pair-distances.json','audit/checks.json']]+[STEM/n for n in ['bracket-direction-bounds.json','audit/checks.json']]+[OLD/n for n in ['coordinate-domains.json','anchor-bounds.json']]
assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'target_counts':[7,5,1],'method':'Extend the verified ordered core projection to include all five mandatory inserts and both quarter-turn outer classes. Reference each bracket by its source-contained full-height stem left edge, each insert by its source-inner rectangle left edge, and the cog by its floored center. Derive all new directed noncog distances from complete-domain strict Y overlap and exact open X-overlap intervals. Reuse stronger audited mixed directions and existing bracket/bracket/cog spacing. For any three successive inserts in reference-X order, their109996um minimum heights sum above short-stock height312967um; hence the third start must reach the earlier end of the preceding two source-inner intervals. This is a necessary three-insert condition even when other originals lie between them. Later use an exact dominance-pruned dynamic program over counts, last profile and the last two insert profiles/positions; audit geometry before any bounded enumeration. No actual source feasibility follows from a surviving projection.'})
vs={v['id']:v for v in load(GEO/'variants.json')};ds={d['variant']:d['bounds_um'] for d in load(GEO/'domains.json')};stems={r['profile']:r['stem_bounds_units1000'] for r in load(STEM/'bracket-direction-bounds.json')};mixed={r['variant']:r for r in load(MIXED/'audit/combined-spacing.json')};oldpairs={tuple(r['profiles']):r['minimum_distance'] for r in load(FRONT/'pair-distances.json')};oldcoords={int(k):v for k,v in load(OLD/'coordinate-domains.json').items()};profiles=[]
for p in list(range(10))+[12]:
    v=vs[p];core=stems[p] if p<8 else v['coarse_rectangles_um'][0] if p<10 else None;ref=core[0] if core else 0;rects=v['coarse_rectangles_um']+([core] if p<8 else []);domain=[ds[p][0]+ref,ds[p][2]+ref]
    if p<8:assert domain==oldcoords[p]
    profiles.append({'variant':p,'family':v['family'],'reference_x_um':ref,'source_core_um':core,'source_rectangles_um':rects,'anchor_domain_um':ds[p],'reference_x_domain_um':domain,'insert_width_um':core[2]-core[0] if p in [8,9] else None})
prof={r['variant']:r for r in profiles};pairs=[]
for a in prof:
    for b in prof:
        overlaps=[];advances=[];initial=None
        if a not in [8,9] and b not in [8,9]:d=oldpairs[11 if a==12 else a,11 if b==12 else b];kind='audited core pair'
        elif a==12:d=mixed[b]['ordered_cog_to_bracket_minimum_um'];kind='audited cog before insert'
        elif b==12:d=mixed[a]['ordered_bracket_to_cog_minimum_um'];kind='audited insert before cog'
        else:
            pa,pb=prof[a],prof[b];ca,cb=pa['source_core_um'],pb['source_core_um'];da,db=ds[a],ds[b];slacks=[db[1]+cb[3]-(da[3]+ca[1]),da[1]+ca[3]-(db[3]+cb[1])];initial=ca[2]-ca[0] if min(slacks)>0 else 0;d=initial
            for ri,r in enumerate(pa['source_rectangles_um']):
                for si,s in enumerate(pb['source_rectangles_um']):
                    sy=[db[1]+s[3]-(da[3]+r[1]),da[1]+r[3]-(db[3]+s[1])]
                    if min(sy)>0:overlaps.append({'rectangles':[ri,si],'strict_y_slacks_um':sy,'forbidden_open_um':[r[0]-s[2]-pa['reference_x_um']+pb['reference_x_um'],r[2]-s[0]-pa['reference_x_um']+pb['reference_x_um']]})
            while True:
                ends=[r['forbidden_open_um'][1] for r in overlaps if r['forbidden_open_um'][0]<d<r['forbidden_open_um'][1]]
                if not ends:break
                n=max(ends);advances.append([d,n]);d=n
            kind='guaranteed-Y source-rectangle projection'
        assert d>=0;pairs.append({'profiles':[a,b],'minimum_reference_distance_um':d,'kind':kind,'initial_distance_um':initial,'guaranteed_y_overlaps':overlaps,'interval_advances':advances})
widths={str(p):prof[p]['insert_width_um'] for p in [8,9]};heights={str(p):prof[p]['source_core_um'][3]-prof[p]['source_core_um'][1] for p in [8,9]};stock=load(GEO/'stock.json')['capacity_um'];assert 3*min(heights.values())>stock[1]
write(BASE/'profiles.json',profiles);write(BASE/'pair-distances.json',pairs);write(BASE/'triple-insert-proof.json',{'insert_widths_um':widths,'insert_heights_um':heights,'relaxed_stock_height_um':stock[1],'three_minimum_heights_um':3*min(heights.values()),'rule':'For insert references xa<=xb<=xc, require xc>=min(xa+width_a,xb+width_b). Otherwise the three source-contained rectangles share a nonempty open X interval, and disjoint source placement would need at least three minimum insert heights, exceeding the relaxed stock height. Apply to every consecutive triple in the insert-only subsequence. This condition is necessary, not sufficient for all insert triples or source feasibility.'})
write(BASE/'prepared.json',{'seconds':time.perf_counter()-start,'profile_types':len(profiles),'directed_distances':len(pairs),'nonnegative_ordered_distances':True,'target_counts':[7,5,1],'all_original_modes_retained':True,'triple_insert_height_excess_um':3*min(heights.values())-stock[1],'solver_calls':0,'enumerations_opened':0,'native_calls':0,'H5_complete':False});print(load(BASE/'prepared.json'))
