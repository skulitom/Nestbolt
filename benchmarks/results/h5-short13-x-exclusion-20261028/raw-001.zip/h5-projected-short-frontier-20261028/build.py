"""Complete finite count frontier using the newly verified directed source spacings."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-global-short-frontier-20261026';GEO=ROOT/'output/h5-short-mixed-projection-20261028';OUT=ROOT/'output/h5-projected-short-frontier-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');start=time.perf_counter();assert load(GEO/'audit/checks.json')['passed'] and load(OLD/'audit/checks.json')['passed']
inputs=[GEO/n for n in ['plan.json','audit/plan.json','audit/checks.json','audit/combined-spacing.json','audit/necessity-proof.json']]+[OLD/n for n in ['plan.json','coordinate-domains.json','pair-distances.json','area-proof.json','allocations.json','forward-states.json','audit/checks.json']]
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Recompute the complete necessary ordered core projection for every0..12 bracket and0..15 cog count, replacing only mixed directed bounds with the independently verified stronger source projections. Keep all prior bracket/bracket and cog/cog bounds, complete coordinate domains and all8 bracket modes. An exact earliest-position dynamic program enumerates every profile sequence without a solver. Combine with the unchanged exact original filled-area bound for every0..21 insert count. Compare all4576 allocations with the prior frontier, including every survivor rather than only Pareto vectors. Positive projection survival is not source feasibility; no fixed first-sheet core or source13 witness is assumed.'})
domains={int(k):v for k,v in load(OLD/'coordinate-domains.json').items()};dist={tuple(r['profiles']):r['minimum_distance'] for r in load(OLD/'pair-distances.json')};old_dist=dist.copy()
for r in load(GEO/'audit/combined-spacing.json')[:8]:
    p=r['variant'];assert r['ordered_bracket_to_cog_minimum_um']>=dist[p,11] and r['ordered_cog_to_bracket_minimum_um']>=dist[11,p];dist[p,11]=r['ordered_bracket_to_cog_minimum_um'];dist[11,p]=r['ordered_cog_to_bracket_minimum_um']
states={(int(p<8),int(p==11),p):{'earliest':lo,'profiles':[p],'coordinates':[lo]} for p,(lo,hi) in domains.items()};transitions=[]
for total in range(1,27):
    for (b,c,p),value in sorted(list(states.items())):
        if b+c!=total:continue
        for q,(lo,hi) in domains.items():
            nb,nc=b+int(q<8),c+int(q==11)
            if nb>12 or nc>15:continue
            x=max(lo,value['earliest']+dist[p,q]);valid=x<=hi;transitions.append({'from':[b,c,p],'to':[nb,nc,q],'earliest':x,'within_domain':valid})
            if valid and ((nb,nc,q) not in states or x<states[nb,nc,q]['earliest']):states[nb,nc,q]={'earliest':x,'profiles':value['profiles']+[q],'coordinates':value['coordinates']+[x]}
ap=load(OLD/'area-proof.json');areas={k:F(*v) for k,v in ap['filled_source_areas_rational'].items()};available=F(*ap['stock_area_rational']);prior={tuple(r['short_counts']):r for r in load(OLD/'allocations.json')};allocations=[];frontier=[];newly=[]
for b in range(13):
    for c in range(16):
        survives=(b==c==0) or any(k[:2]==(b,c) for k in states);cap=min(21,(available-b*areas['bracket']-c*areas['cog'])//areas['insert']) if survives else -1;frontier.append({'brackets':b,'cogs':c,'ordered_projection_survives':survives,'maximum_inserts_from_area':max(-1,cap)})
        for i in range(22):
            reason='ordered_projection' if not survives else 'filled_outer_area' if i>cap else None;row={'short_counts':[b,i,c],'first_counts':[18,12-b,21-i,15-c],'excluded_by':reason};allocations.append(row)
            assert reason is not None or prior[b,i,c]['excluded_by'] is None
            if reason is not None and prior[b,i,c]['excluded_by'] is None:newly.append(row)
survivors=[r['short_counts'] for r in allocations if r['excluded_by'] is None];pareto=[r for r in survivors if not any(q!=r and all(q[k]>=r[k] for k in range(3)) for q in survivors)];old_states={tuple(r['key']):r['earliest'] for r in load(OLD/'forward-states.json')};advances=[{'key':list(k),'prior_earliest':old_states[k],'new_earliest':v['earliest'],'advance_um':v['earliest']-old_states[k]} for k,v in sorted(states.items()) if v['earliest']>old_states[k]]
write(OUT/'pair-distances.json',[{'profiles':list(k),'minimum_distance':v,'prior_minimum_distance':old_dist[k]} for k,v in sorted(dist.items())]);write(OUT/'states.json',[{'key':list(k),**v} for k,v in sorted(states.items())]);write(OUT/'transitions.json',transitions);write(OUT/'frontier.json',frontier);write(OUT/'allocations.json',allocations);write(OUT/'newly-excluded.json',newly);write(OUT/'pareto-necessary-counts.json',pareto);write(OUT/'state-advances.json',advances)
write(OUT/'result.json',{'seconds':time.perf_counter()-start,'directed_bounds_strictly_stronger':sum(v>old_dist[k] for k,v in dist.items()),'states':len(states),'transitions':len(transitions),'all_allocations':len(allocations),'prior_surviving_allocations':sum(r['excluded_by'] is None for r in prior.values()),'surviving_allocations':len(survivors),'newly_excluded_allocations':len(newly),'pareto_necessary_count_vectors':len(pareto),'states_with_stronger_earliest_positions':len(advances),'maximum_earliest_advance_um':max((r['advance_um'] for r in advances),default=0),'short_7_5_1_excluded':next(r['excluded_by'] is not None for r in allocations if r['short_counts']==[7,5,1]),'solver_calls':0,'native_calls':0,'source13_witness':False,'H5_complete':False});print(load(OUT/'result.json'));print('Newly excluded:',newly)
