"""Independent backwards recurrence and all-allocation readback."""
from pathlib import Path
from functools import lru_cache
from fractions import Fraction as F
from hashlib import sha256
import json,shutil,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-projected-short-frontier-20261028';OLD=ROOT/'output/h5-global-short-frontier-20261026';GEO=ROOT/'output/h5-short-mixed-projection-20261028';OUT=BASE/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEO/'audit/checks.json')['passed'];ds={int(k):v for k,v in load(OLD/'coordinate-domains.json').items()};dist={tuple(r['profiles']):r['minimum_distance'] for r in load(BASE/'pair-distances.json')};prior={tuple(r['profiles']):r['minimum_distance'] for r in load(OLD/'pair-distances.json')};combined={r['variant']:r for r in load(GEO/'audit/combined-spacing.json')}
for (a,b),d in dist.items():assert d==(combined[a]['ordered_bracket_to_cog_minimum_um'] if a<8 and b==11 else combined[b]['ordered_cog_to_bracket_minimum_um'] if a==11 and b<8 else prior[a,b])
INF=10**12
@lru_cache(None)
def earliest(b,c,q):
    if b<0 or c<0 or b+c==0:return INF
    pb,pc=b-int(q<8),c-int(q==11)
    if pb<0 or pc<0:return INF
    if pb+pc==0:return ds[q][0]
    x=min(max(ds[q][0],earliest(pb,pc,p)+dist[p,q]) for p in ds)
    return x if x<=ds[q][1] else INF
expected={(b,c,q):earliest(b,c,q) for b in range(13) for c in range(16) for q in ds if earliest(b,c,q)<INF};saved={tuple(r['key']):r for r in load(BASE/'states.json')};assert set(expected)==set(saved)
for k,x in expected.items():
    row=saved[k];assert row['earliest']==x and len(row['profiles'])==len(row['coordinates'])==sum(k[:2]) and row['coordinates'][-1]==x and row['profiles'][-1]==k[2];assert sum(p<8 for p in row['profiles'])==k[0] and sum(p==11 for p in row['profiles'])==k[1]
    for p,xx in zip(row['profiles'],row['coordinates']):assert ds[p][0]<=xx<=ds[p][1]
    for a,b,x,y in zip(row['profiles'],row['profiles'][1:],row['coordinates'],row['coordinates'][1:]):assert y-x>=dist[a,b]
edges=[]
for k,x in sorted(expected.items()):
    b,c,p=k
    if b+c>=27:continue
    for q,(lo,hi) in ds.items():
        nb,nc=b+int(q<8),c+int(q==11)
        if nb>12 or nc>15:continue
        xx=max(lo,x+dist[p,q]);edges.append({'from':list(k),'to':[nb,nc,q],'earliest':xx,'within_domain':xx<=hi})
assert sorted(edges,key=lambda r:(r['from'],r['to']))==sorted(load(BASE/'transitions.json'),key=lambda r:(r['from'],r['to']))
job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json')
def area(ps):return abs(sum(F(x)*F(v)-F(y)*F(u) for (x,y),(u,v) in zip(ps,ps[1:]+ps[:1])))/2
areas={p['id']:sum(area(g['outer']) for g in p['geometry']) for p in job['parts']};ap=load(OLD/'area-proof.json');assert areas=={k:F(*v) for k,v in ap['filled_source_areas_rational'].items()};available=F(1487)*(F('319.42699')-F('6.5'));assert available==F(*ap['stock_area_rational']);alloc=load(BASE/'allocations.json');assert len(alloc)==4576 and len({tuple(r['short_counts']) for r in alloc})==4576
for r in alloc:
    b,i,c=r['short_counts'];assert r['first_counts']==[18,12-b,21-i,15-c];ok=(b+c==0) or any((b,c,p) in expected for p in ds);reason='ordered_projection' if not ok else 'filled_outer_area' if b*areas['bracket']+i*areas['insert']+c*areas['cog']>available else None;assert r['excluded_by']==reason
previous={tuple(r['short_counts']):r for r in load(OLD/'allocations.json')};new=[r for r in alloc if r['excluded_by'] is not None and previous[tuple(r['short_counts'])]['excluded_by'] is None];assert new==load(BASE/'newly-excluded.json')==[];survivors=[r['short_counts'] for r in alloc if r['excluded_by'] is None];pareto=[r for r in survivors if not any(q!=r and all(q[k]>=r[k] for k in range(3)) for q in survivors)];assert pareto==load(BASE/'pareto-necessary-counts.json')
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'states_verified_by_backwards_recurrence':len(expected),'transitions_verified':len(edges),'allocations_verified':len(alloc),'remaining_necessary_allocations':len(survivors),'new_count_exclusions':0,'all8_bracket_modes_and_all_real_cog_angles_retained':True,'short_7_5_1_survives':True,'source_feasibility_claimed':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
