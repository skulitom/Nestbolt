"""Verify complete integer-Y union coverage without rerunning the producer closure."""
from pathlib import Path
from hashlib import sha256
import json,math,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-short-mixed-projection-20261028';GEO=ROOT/'output/h5-short13-necessary-geometry-20261028';OLD=ROOT/'output/h5-global-short-frontier-20261026';SOURCE=ROOT/'output/h5-short13-source-sliding-20261028';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'projections.json',BASE/'regions.json',BASE/'coverage-certificates.json',SOURCE/'prefix-bank.json',SOURCE/'modes.json',SOURCE/'preflight/checks.json']}})
for n,h in load(BASE/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
assert load(GEO/'audit/checks.json')['passed'] and load(OLD/'audit/checks.json')['passed'] and load(SOURCE/'preflight/checks.json')['passed']
ds={d['variant']:d['bounds_um'] for d in load(GEO/'domains.json')};components=load(GEO/'components.json');records=load(BASE/'projections.json');regions=load(BASE/'regions.json');certs=load(BASE/'coverage-certificates.json');assert len(records)==len(regions)==len(certs)==10
oldcoords={int(k):v for k,v in load(OLD/'coordinate-domains.json').items()};oldanchors={int(k):v for k,v in load(OLD/'anchor-bounds.json').items()};oldpairs={tuple(r['profiles']):r['minimum_distance'] for r in load(OLD/'pair-distances.json')}
values=segments=facets=endpoint_checks=0;combined=[]
for vid,(r,reg,cert) in enumerate(zip(records,regions,certs)):
    assert r['variant']==reg['variant']==cert['variant']==vid;expected=[{'component':c['component'],'forbidden_index':k,'kind':f['kind'],'faces':f['faces']} for c in components if c['variant']==vid for k,f in enumerate(c['forbidden'])];assert reg['regions']==expected;fs=reg['regions'];yl,yh=ds[12][1]-ds[vid][3],ds[12][3]-ds[vid][1];assert r['relative_y_range_um']==[yl,yh] and r['integer_y_values']==yh-yl+1
    reference=oldcoords[vid][0]-oldanchors[vid][0] if vid<8 else 2;L,R=r['necessary_left_or_right_x_um'];assert r['reference_x_um']==reference and L<reference<R and r['closed_forbidden_x_um']==[L+1,R-1];assert r['reference_to_cog_right_minimum_um']==R-reference and r['cog_to_reference_right_minimum_um']==reference-L
    next_y=yl
    for segment in cert['segments']:
        lo,hi=segment['y_range_um'];chain=segment['region_chain'];assert lo==next_y and lo<=hi<=yh and chain and len(chain)==len(set(chain));next_y=hi+1;y=np.arange(lo,hi+1,dtype=np.int64);x=np.full(len(y),L+1,dtype=np.int64)
        for ix in chain:
            assert 0<=ix<len(fs) and np.all(x<R)
            # Translate strict integer facets into closed inequalities >=rhs+1.
            lower=np.full(len(y),-(2**50),dtype=np.int64);upper=-lower
            for nx,ny,rhs in fs[ix]['faces']:
                if nx>0:lower=np.maximum(lower,-((ny*y-rhs-1)//nx))
                elif nx<0:upper=np.minimum(upper,(ny*y-rhs-1)//(-nx))
                else:assert np.all(ny*y>=rhs+1)
                facets+=len(y)
            assert np.all(lower<=x) and np.all(x<=upper);x=upper+1
        assert np.all(x>=R);values+=len(y);segments+=1
    assert next_y==yh+1 and len(cert['segments'])==r['certificate_segments']
    for w,side,xx in zip(r['endpoint_outside_region_witnesses'],['left','right'],[L,R]):
        x,y=w['point_um'];assert w['side']==side and x==xx and yl<=y<=yh
        for f in fs:assert any(nx*x+ny*y<=rhs for nx,ny,rhs in f['faces']);endpoint_checks+=1
    if vid<8:
        prior=[reference-oldpairs[11,vid],reference+oldpairs[vid,11]];assert r['previous_necessary_x_um']==prior and r['left_spacing_gain_um']==max(0,prior[0]-L) and r['right_spacing_gain_um']==max(0,R-prior[1]);effective=[min(prior[0],L),max(prior[1],R)]
    else:assert r['previous_necessary_x_um'] is None;effective=[L,R]
    combined.append({'variant':vid,'reference_x_um':reference,'necessary_left_or_right_x_um':effective,'ordered_bracket_to_cog_minimum_um':effective[1]-reference,'ordered_cog_to_bracket_minimum_um':reference-effective[0]})
assert values==983930 and segments==34
known=[];modes=load(SOURCE/'modes.json');count=0;smallest=None
for p in load(SOURCE/'prefix-bank.json'):
    cx,cy=[math.floor(x*1000) for x in p['anchors'][12]];rows=[]
    for i in range(12):
        if p['anchors'][i] is None:continue
        mi=p['modes'][i];mode=modes[mi];vid=mi-36 if mi<44 else 9 if mi==44 else 8;assert (mode['family']=='bracket')==(vid<8)
        x,y=[math.floor(t*1000) for t in p['anchors'][i]];dx,dy=cx-x,cy-y;r=records[vid];lo,hi=r['relative_y_range_um'];assert lo<=dy<=hi;left,right=combined[vid]['necessary_left_or_right_x_um'];assert dx<=left or dx>=right;margin=left-dx if dx<=left else dx-right;smallest=margin if smallest is None else min(smallest,margin);rows.append({'item':i,'variant':vid,'relative_um':[dx,dy],'separation_slack_um':margin});count+=1
    known.append({'prefix':p['prefix'],'checks':rows})
write(OUT/'combined-spacing.json',combined);write(OUT/'known-prefix-checks.json',known)
write(OUT/'necessity-proof.json',{'all_real_cog_angles':True,'complete_integer_relative_y_domains':True,'argument':'The previously audited outward stock domains contain every floored valid anchor and cog center. Their full difference interval therefore contains every integer relative Y of a valid pair. For every such Y, the independent reader verifies a chain of audited forbidden X intervals covers all integers from L+1 through R-1 with no gap. Membership in each interval means every audited outside facet is violated, hence a certified collision of source-contained geometry or an actual source vertex. Thus every valid source pair has relative X<=L or>=R. The common interval contains the bracket stem start, so ordering stem starts and cog centers gives the stated directed spacings. Prior source-support intervals also contain that reference; their union yields min(left endpoints), max(right endpoints). Exact arithmetic preserves closed-corner boundaries. Insert references use their left source-inner edge. Original placements can always be floored into these coordinates, so enumerating all integer Y covers continuous source placements; no cog angle is sampled or chosen. Endpoint witnesses only establish maximality for this common interval in the listed mixed regions, not original-source feasibility. Passing source12 prefixes are consistency checks, not source13 or full66 witnesses.'})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-start,'variants_verified':10,'complete_integer_y_values_verified':values,'coverage_segments_verified':segments,'facet_integer_inequalities_verified':facets,'outside_endpoint_region_checks':endpoint_checks,'bracket_directions_strictly_improved':sum(r[k]>0 for r in records[:8] for k in ['left_spacing_gain_um','right_spacing_gain_um']),'maximum_bracket_spacing_gain_um':max(r[k] for r in records[:8] for k in ['left_spacing_gain_um','right_spacing_gain_um']),'known_valid_source12_prefixes':len(known),'known_prefix_pair_spacings_verified':count,'minimum_known_prefix_spacing_slack_um':smallest,'false_rejections':0,'all_real_cog_angles':True,'solver_calls':0,'native_calls':0,'source13_witness':False,'H5_complete':False});print(load(OUT/'checks.json'))
