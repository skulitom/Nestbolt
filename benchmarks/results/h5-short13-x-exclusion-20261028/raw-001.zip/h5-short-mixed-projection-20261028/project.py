"""Exact complete integer-Y projection of all audited mixed forbidden regions."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,shutil,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];GEO=ROOT/'output/h5-short13-necessary-geometry-20261028';OLD=ROOT/'output/h5-global-short-frontier-20261026';OUT=ROOT/'output/h5-short-mixed-projection-20261028'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def intervals(faces,y):
    lo=np.full(len(y),-10**9,dtype=np.int64);hi=np.full(len(y),10**9,dtype=np.int64);valid=np.ones(len(y),bool)
    for nx,ny,rhs in faces:
        if nx>0:lo=np.maximum(lo,(rhs-ny*y)//nx+1)
        elif nx<0:hi=np.minimum(hi,(ny*y-rhs-1)//(-nx))
        else:valid &= ny*y>rhs
    lo[~valid]=1;hi[~valid]=0
    return lo,hi
OUT.mkdir();shutil.copyfile(__file__,OUT/'project.py');start=time.perf_counter()
inputs=[GEO/n for n in ['components.json','variants.json','domains.json','audit/checks.json']]+[OLD/n for n in ['coordinate-domains.json','anchor-bounds.json','pair-distances.json','audit/checks.json']]
assert all(load(p)['passed'] for p in inputs if p.name=='checks.json')
write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'For every noncog variant, enumerate every integer cog-minus-anchor Y in its complete outward-rounded stock domain. At each Y, derive the exact integer X interval where all facets of each audited mixed forbidden region are strictly violated. This includes closed-corner semantics encoded by the audited minus-one facets. Find the connected forbidden integer run containing the bracket stem start or insert left inner edge. Its common intersection over every Y is a certified whole-domain forbidden X interval. Retain greedy interval-chain coverage certificates compressed only across consecutive Y values with identical chains. Independently verify every integer Y and every certificate before using the spacing. Keep explicit outside-region endpoint witnesses to show the common interval cannot be extended with these regions alone. Compare bracket directions with the previous all-angle support bounds; retain the stronger bound only after audit. No solver, finite-angle sampling, full source witness or count exclusion is claimed by this preparation.'})
vs={v['id']:v for v in load(GEO/'variants.json')};ds={d['variant']:d['bounds_um'] for d in load(GEO/'domains.json')};components=load(GEO/'components.json');oldcoords={int(k):v for k,v in load(OLD/'coordinate-domains.json').items()};oldanchors={int(k):v for k,v in load(OLD/'anchor-bounds.json').items()};oldpairs={tuple(r['profiles']):r['minimum_distance'] for r in load(OLD/'pair-distances.json')};records=[];regions=[];certificates=[]
for vid in range(10):
    reference=oldcoords[vid][0]-oldanchors[vid][0] if vid<8 else 2
    yl,yh=ds[12][1]-ds[vid][3],ds[12][3]-ds[vid][1];y=np.arange(yl,yh+1,dtype=np.int64);fs=[]
    for comp in components:
        if comp['variant']==vid:
            for k,f in enumerate(comp['forbidden']):fs.append({'component':comp['component'],'forbidden_index':k,'kind':f['kind'],'faces':f['faces']})
    bounds=[intervals(f['faces'],y) for f in fs];lo=np.asarray([b[0] for b in bounds]);hi=np.asarray([b[1] for b in bounds]);left=np.full(len(y),reference,dtype=np.int64);right=left.copy();iterations=0
    while True:
        before_l=left.copy();before_r=right.copy()
        for a,b in zip(lo,hi):
            mask=(a<=left)&(left<=b);left[mask]=a[mask]-1
            mask=(a<=right)&(right<=b);right[mask]=b[mask]+1
        iterations+=1
        if np.array_equal(left,before_l) and np.array_equal(right,before_r):break
        assert iterations<=len(fs)+1
    assert np.all(left<reference) and np.all(right>reference)
    L,R=int(left.max()),int(right.min());assert L<reference<R
    # Certify coverage of every integer X strictly between the projected endpoints.
    point=np.full(len(y),L+1,dtype=np.int64);chains=[];steps=0
    while np.any(point<R):
        active=point<R;eligible=(lo<=point[None,:])&(point[None,:]<=hi);ends=np.where(eligible,hi,-10**9);selected=np.argmax(ends,axis=0);best=ends[selected,np.arange(len(y))];assert np.all(best[active]>=point[active]);selected[~active]=-1;chains.append(selected.astype(np.int16));point[active]=best[active]+1;steps+=1;assert steps<=len(fs)
    arr=np.stack(chains,axis=1);starts=np.r_[0,np.flatnonzero(np.any(arr[1:]!=arr[:-1],axis=1))+1];ends=np.r_[starts[1:]-1,len(y)-1];segments=[]
    for a,b in zip(starts,ends):segments.append({'y_range_um':[int(y[a]),int(y[b])],'region_chain':[int(k) for k in arr[a] if k>=0]})
    witnesses=[]
    for label,x,values in [('left',L,left),('right',R,right)]:
        iy=int(np.flatnonzero(values==x)[0]);yy=int(y[iy]);assert all(any(nx*x+ny*yy<=rhs for nx,ny,rhs in f['faces']) for f in fs);witnesses.append({'side':label,'point_um':[x,yy]})
    oldleft=reference-oldpairs[11,vid] if vid<8 else None;oldright=reference+oldpairs[vid,11] if vid<8 else None
    rec={'variant':vid,'family':vs[vid]['family'],'reference_x_um':reference,'relative_y_range_um':[yl,yh],'integer_y_values':len(y),'region_count':len(fs),'closed_forbidden_x_um':[L+1,R-1],'necessary_left_or_right_x_um':[L,R],'reference_to_cog_right_minimum_um':R-reference,'cog_to_reference_right_minimum_um':reference-L,'previous_necessary_x_um':[oldleft,oldright] if vid<8 else None,'left_spacing_gain_um':max(0,oldleft-L) if vid<8 else None,'right_spacing_gain_um':max(0,R-oldright) if vid<8 else None,'closure_passes':iterations,'certificate_segments':len(segments),'max_chain_regions':steps,'endpoint_outside_region_witnesses':witnesses}
    records.append(rec);regions.append({'variant':vid,'regions':fs});certificates.append({'variant':vid,'segments':segments})
write(OUT/'projections.json',records);write(OUT/'regions.json',regions);write(OUT/'coverage-certificates.json',certificates)
write(OUT/'prepared.json',{'seconds':time.perf_counter()-start,'variants':len(records),'integer_y_values':sum(r['integer_y_values'] for r in records),'certificate_segments':sum(r['certificate_segments'] for r in records),'bracket_directions_strictly_improved':sum(r[k]>0 for r in records[:8] for k in ['left_spacing_gain_um','right_spacing_gain_um']),'maximum_bracket_spacing_gain_um':max(r[k] for r in records[:8] for k in ['left_spacing_gain_um','right_spacing_gain_um']),'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'prepared.json'));print([{k:r[k] for k in ['variant','necessary_left_or_right_x_um','previous_necessary_x_um','left_spacing_gain_um','right_spacing_gain_um']} for r in records])
