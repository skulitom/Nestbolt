"""Independent exact conservative-cell coverage and complete source controls."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from itertools import product,combinations
import json,math,time,copy,shutil
from h5_exact_convex_partition_tools_20261029 import area,hull
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-movable-roof-source-20261107';SOURCE=ROOT/'output/h5-mixed-roof-source-20261107';Q=ROOT/'output/h5-mixed-direct-pose-v2-20261107';OUT=BASE/'audit';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest();UNIT=10**6
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def rd(v):return F(math.floor(v*UNIT),UNIT)
def ru(v):return F(math.ceil(v*UNIT),UNIT)
def rect(values):return list(map(F,values))
def covered(a,b):return b[0]<=a[0] and b[1]<=a[1] and a[2]<=b[2] and a[3]<=b[3]
def separate(a,b):return a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1]
def rectangle_area(r):return (r[2]-r[0])*(r[3]-r[1])
OUT.mkdir();start=time.perf_counter();shutil.copyfile(__file__,OUT/'audit.py');lib=load(BASE/'library.json');source=load(SOURCE/'source-geometry.json');prior=load(SOURCE/'audit/checks.json');assert prior['passed'] and prior['source_geometry_sha256']==digest(SOURCE/'source-geometry.json');job=load(JOB);parts={p['id']:p for p in job['parts']};partitions=load(Q/'partitions.json');fixed=[r for r in source['fixed_source_rows'] if not(r['part_id']=='frame' and r['copy_index'] in [16,17])];assert fixed==lib['fixed_source_rows']==load(BASE/'fixed31-source.json') and {f:lib['families'][f] for f in source['families']}==source['families'];stocks=source['source_stocks'];required=source['required_pair_gap_mm'];guard=source['stock_guard_mm'];check=audit(job,fixed,stocks,required,guard);assert check==load(BASE/'fixed31-checks.json') and check['valid'];safe=[F(str(stocks['sheet-0'][0]))+F('.025'),F(str(stocks['sheet-0'][1]))+F('.025'),F(str(stocks['sheet-0'][2]))-F('.025'),F(str(stocks['sheet-0'][3]))-F('.025')];epsilon=F(1,UNIT);gap=F('.23');cores=[];records=[]
for name,indices in [('base',range(16))]:
    vv=[];actual=[]
    for i in indices:
        t=fixed[i]['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);tx,ty=t['translation'];assert not t['mirrored']
        for x,y in parts['frame']['geometry'][0]['outer']:vv.append((F(x)*F(c)-F(y)*F(s)+F(tx),F(x)*F(s)+F(y)*F(c)+F(ty)));actual.append((F(x*c-y*s+tx),F(x*s+y*c+ty)))
    core=[rd(min(x for x,y in vv)),rd(min(y for x,y in vv)),ru(max(x for x,y in vv)),ru(max(y for x,y in vv))];assert all(core[0]<=x<=core[2] and core[1]<=y<=core[3] for x,y in actual);cores.append(core);records.append({'group':name,'frame_indices':list(indices),'outer_rectangle':list(map(str,core)),'source_vertices':[[str(x),str(y)] for x,y in vv]})
assert records==load(BASE/'fixed-core-boxes.json') and lib['fixed_core_outer_rectangles_mm']==[list(map(float,c)) for c in cores] and lib['safe_source_stock_mm']==list(map(float,safe))

frame=parts['frame'];outer=frame['geometry'][0]['outer'];assert outer==[[0.,0.],[450.,0.],[450.,350.],[0.,350.]] and not frame['allow_mirror'] and frame['rotations']['degrees']==[0.,90.,180.,270.]
partitions['frame']={'pieces':[outer],'construction':'exact convex source rectangle; no triangulation'};assert partitions==load(BASE/'partitions.json')
fg=lib['families']['frame'];assert fg['original']==outer and fg['source_center']==[225.,175.] and fg['source_holes']==frame['geometry'][0]['holes'] and len(fg['source_holes'])==1
expected_corners={(float(x),float(y)) for x in [F('-.115'),F('450.115')] for y in [F('-.115'),F('350.115')]};assert len(fg['clearance'])==4 and set(map(tuple,fg['clearance']))==expected_corners
fc=load(BASE/'frame-clearance-supports.json');assert fc['required_mm']=='.114' and fc['square_halfwidth_mm']=='.115';supports=fc['supports'];assert len(supports)==16 and {(p['source_edge'],p['expanded_edge']) for p in supports}==set(product(range(4),repeat=2));minimum=math.inf
original=list(map(lambda p:tuple(map(F,p)),outer));expanded=list(map(lambda p:tuple(map(F,p)),fg['clearance']))
assert area(original)>0 and area(expanded)>0
for p in supports:
    ai,bi=p['source_edge'],p['expanded_edge'];nx,ny=map(F,p['normal']);n2=nx*nx+ny*ny;distance=min(x*nx+y*ny for x,y in [expanded[bi],expanded[(bi+1)%4]])-max(x*nx+y*ny for x,y in [original[ai],original[(ai+1)%4]])
    assert n2>0 and distance>0 and distance**2>=F('.114')**2*n2;minimum=min(minimum,float(distance)/math.sqrt(float(n2)))
assert minimum==fc['minimum_certified_gap_mm'];write(OUT/'frame-clearance-controls.json',{'passed':True,'source_rectangle':[450,350],'source_holes':1,'source_legal_rotations':[0,90,180,270],'mirror_allowed':False,'exact_edge_supports':16,'minimum_certified_clearance_mm':minimum,'filled_outer_enforces_PIH_off':True})

for family in ['frame','bracket','insert']:
    original=[tuple(map(F,p)) for p in parts[family]['geometry'][0]['outer']];pieces=[[tuple(map(F,p)) for p in pp] for pp in partitions[family]['pieces']];assert parts[family]['geometry'][0]['outer']==lib['families'][family]['original'] and sum(abs(area(p)) for p in pieces)==abs(area(original));boxes=[[min(x for x,y in original),min(y for x,y in original),max(x for x,y in original),max(y for x,y in original)]]
    if family=='bracket':boxes=[[original[0][0],original[0][1],original[3][0],original[4][1]],[original[0][0],original[0][1],original[1][0],original[2][1]]]
    for piece in pieces:
        assert abs(area(hull(piece)))==abs(area(piece));bb=[min(x for x,y in piece),min(y for x,y in piece),max(x for x,y in piece),max(y for x,y in piece)];assert any(covered(bb,b) for b in boxes)
    for a,b in combinations(pieces,2):
        axes=[(q[1]-p[1],p[0]-q[0]) for pp in [a,b] for p,q in zip(pp,pp[1:]+pp[:1])];assert any(max(x*nx+y*ny for x,y in a)<=min(x*nx+y*ny for x,y in b) or max(x*nx+y*ny for x,y in b)<=min(x*nx+y*ny for x,y in a) for nx,ny in axes)
radius=lib['angle_scale_mm'];center=lib['families']['cog']['source_center'];assert F(radius)**2>max(sum((F(p[k])-F(center[k]))**2 for k in [0,1]) for p in parts['cog']['geometry'][0]['outer']);decompositions=load(BASE/'rectangle-decompositions.json');certificates=load(BASE/'cell-support-certificates.json');expected_modes={};atom_count=proof_count=0;min_gap=math.inf
for family in ['frame','bracket','insert','cog']:
    expected_modes[family]=[];px,py=lib['families'][family]['source_center'];options=[(False,0.)] if family=='cog' else [(mir,math.radians(deg)) for mir in ([False,True] if parts[family]['allow_mirror'] else [False]) for deg in parts[family]['rotations']['degrees']]
    for source_mode,(mirror,angle) in enumerate(options):
        local=[];c,s=map(F,[math.cos(angle),math.sin(angle)]);sign=-1 if mirror else 1
        if family=='cog':local=[[-ru(F(radius)),-ru(F(radius)),ru(F(radius)),ru(F(radius))]]
        else:
            for piece in partitions[family]['pieces']:
                v=[(sign*(F(x)-F(px))*c-(F(y)-F(py))*s,sign*(F(x)-F(px))*s+(F(y)-F(py))*c) for x,y in piece];local.append([rd(min(x for x,y in v)),rd(min(y for x,y in v)),ru(max(x for x,y in v)),ru(max(y for x,y in v))])
        root=[safe[0]-min(r[0] for r in local)+epsilon,safe[1]-min(r[1] for r in local)+epsilon,safe[2]-max(r[2] for r in local)-epsilon,safe[3]-max(r[3] for r in local)-epsilon];blocked=[[core[0]-gap-r[2],core[1]-gap-r[3],core[2]+gap-r[0],core[3]+gap-r[1]] for core,r in product(cores,local)];record=next(r for r in decompositions if r['family']==family and r['source_mode']==source_mode);assert record['rotation_radians']==angle and record['mirrored']==mirror and list(map(rect,record['local_piece_outer_boxes']))==local and rect(record['stock_center_root'])==root and list(map(rect,record['forbidden_center_rectangles']))==blocked
        axes=[sorted({root[k],root[k+2]}|{r[j] for r in blocked for j in [k,k+2] if root[k]<r[j]<root[k+2]}) for k in [0,1]];expected={}
        for x0,x1 in zip(axes[0],axes[0][1:]):
            for y0,y1 in zip(axes[1],axes[1][1:]):expected[x0,y0,x1,y1]=not any(r[0]<(x0+x1)/2<r[2] and r[1]<(y0+y1)/2<r[3] for r in blocked)
        actual={tuple(rect(r['bounds'])):r['retained'] for r in record['atomic_cells']};assert len(actual)==len(record['atomic_cells']) and actual==expected;atom_count+=len(actual);merged=list(map(rect,record['merged_cells']));assert merged==sorted(merged,key=lambda r:(r[1],r[0],r[3],r[2])) and all(covered(r,root) and all(separate(r,b) for b in blocked) for r in merged) and all(separate(a,b) for a,b in combinations(merged,2));assert sum(rectangle_area(r) for r in merged)==sum(rectangle_area(r) for r,keep in expected.items() if keep)
        for atom,keep in expected.items():
            if keep:assert sum(covered(atom,r) for r in merged)==1
        assert record['complete_for_conservative_rectangle_arrangement'] and not record['complete_for_original_free_space']
        for cell_index,cell in enumerate(merged):
            bb=list(map(float,[cell[0]+epsilon,cell[1]+epsilon,cell[2]-epsilon,cell[3]-epsilon]));ff=list(map(F,bb));assert all(ff[k]>cell[k] for k in [0,1]) and all(ff[k]<cell[k] for k in [2,3]);mode={'mode':len(expected_modes[family]),'source_mode':source_mode,'cell_index':cell_index,'rotation_radians':angle,'mirrored':mirror,'continuous_rotation':family=='cog','center_bounds_mm':[[bb[0],bb[2]],[bb[1],bb[3]]],'rectangle_mm':bb};expected_modes[family].append(mode);proofs=[]
            for pi,piece in enumerate(local):
                moved=[ff[0]+piece[0],ff[1]+piece[1],ff[2]+piece[2],ff[3]+piece[3]];assert covered(moved,safe)
                for fi,core in enumerate(cores):
                    gaps=[core[0]-moved[2],core[1]-moved[3],moved[0]-core[2],moved[1]-core[3]];axis=max(range(4),key=lambda k:gaps[k]);assert gaps[axis]>=F('.22');proofs.append({'piece':pi,'core':fi,'axis':axis,'exact_gap_mm':str(gaps[axis])});proof_count+=1;min_gap=min(min_gap,float(gaps[axis]))
            saved=next(r for r in certificates if r['family']==family and r['compound_mode']==mode['mode']);assert saved=={'family':family,'compound_mode':mode['mode'],'source_mode':source_mode,'cell_index':cell_index,'piece_core_axis_supports':proofs}
assert expected_modes==lib['family_modes'] and len(decompositions)==17 and len(expected_modes['frame'])>=4 and len(expected_modes['cog'])>=1;ids=[['frame',16],['frame',17]]+[['bracket',i] for i in range(6,12)]+[['insert',i] for i in range(11)]+[['insert',20]]+[['cog',i] for i in range(15)];assert lib['identities']==ids and lib['pairs']==[list(p) for p in combinations(range(35),2)] and lib['continuous_parameters']==85 and lib['angle_coordinate_start']==70 and lib['angle_owners']==list(range(20,35)) and lib['angle_bounds']==[[-math.pi*radius,math.pi*radius] for _ in range(15)];assert sorted(lib['all66_identities'])==sorted([[r['part_id'],r['copy_index']] for r in fixed]+ids)
partial=copy.deepcopy(load(SOURCE/'source48-control.json'));seeds=[]
for row in partial:
    identity=[row['part_id'],row['copy_index']]
    if identity not in ids:continue
    family=identity[0];assert family in ['frame','cog'];owner=ids.index(identity);t=row['transform'];theta=t['rotation_radians'];c,s=math.cos(theta),math.sin(theta);px,py=lib['families'][family]['source_center'];oldcenter=[px*c-py*s+t['translation'][0],px*s+py*c+t['translation'][1]];choices=[]
    eligible=[m for m in lib['family_modes'][family] if family=='cog' or (not m['mirrored'] and abs(math.remainder(m['rotation_radians']-theta,math.tau))<1e-12)]
    for mode in eligible:
        point=[min(max(oldcenter[k],mode['center_bounds_mm'][k][0]),mode['center_bounds_mm'][k][1]) for k in [0,1]];choices.append((sum((a-b)**2 for a,b in zip(point,oldcenter)),mode['mode'],point))
    squared,mi,point=min(choices);assert squared<.0001**2;t['translation']=[point[0]-(px*c-py*s),point[1]-(px*s+py*c)];available=[m['mode'] for m in eligible if all(m['center_bounds_mm'][k][0]<=point[k]<=m['center_bounds_mm'][k][1] for k in [0,1])];seeds.append({'owner':owner,'identity':identity,'source_original_center':oldcenter,'center':point,'source_pose':t,'angle_radians':theta,'projection_distance_mm':math.sqrt(squared),'selected_projection_compound_mode':mi,'covering_compound_modes':available})
assert seeds==lib['source_moving_seed']==load(BASE/'source17-moving-seed.json') and partial==load(BASE/'source48-control.json');control=audit(job,partial,stocks,required,guard);assert control==load(BASE/'source48-checks.json') and control['valid'];corner_controls=[];bindings=0
for owner,(family,identity) in enumerate(ids):
    px,py=lib['families'][family]['source_center']
    for mode in lib['family_modes'][family]:
        bindings+=1
        for point in product(*mode['center_bounds_mm']):
            for theta in ([-math.pi/3,0.,math.pi/4] if family=='cog' else [mode['rotation_radians']]):
                c,s=math.cos(theta),math.sin(theta);m=-1 if mode['mirrored'] else 1;r={'part_id':family,'copy_index':identity,'sheet_id':'sheet-0','transform':{'rotation_radians':theta,'mirrored':mode['mirrored'],'translation':[point[0]-(m*px*c-py*s),point[1]-(m*px*s+py*c)]}};checked=audit(job,fixed+[r],stocks,required,guard);assert checked['valid'];corner_controls.append({'owner':owner,'mode':mode['mode'],'center':point,'angle':theta,'minimum_source_gap_mm':checked['minimum_pair_gap_mm'],'minimum_stock_mm':checked['minimum_extra_stock_mm']})
write(OUT/'source-corner-controls.json',corner_controls);process=load(ROOT/'output/h5-movable-roof-source-preparation-process-20261107/process.json');assert process['closed'] and process['passed'];charge=prior['complete_preparation_seconds']+process['complete_seconds'];inputs=[Path(__file__),JOB,Q/'partitions.json',ROOT/'output/h5_exact_convex_partition_tools_20261029.py',ROOT/'output/h5_legacy64_source_readback.py']+[SOURCE/n for n in ['plan.json','source-geometry.json','source48-control.json','audit/checks.json']]+[BASE/n for n in ['plan.json','library.json','partitions.json','frame-clearance-supports.json','fixed31-source.json','fixed31-checks.json','fixed-core-boxes.json','rectangle-decompositions.json','cell-support-certificates.json','source48-control.json','source48-checks.json','source17-moving-seed.json']]+[ROOT/'output/h5-movable-roof-source-preparation-process-20261107/process.json'];write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Independent exact source-piece coverage, all-angle radius, containment of actual frame vertices in the single base core box, all17 rational arrangements/atomic cells/merged coverage, every whole-cell piece/core support and stock bound. Verify every compound mode and all35 owner bindings,17 nearest-cell source projections including two frames, source48 partial and every source corner control. All legal frame cells preserved; both roof frames remain movable. Frame clearance independently checked from exact rectangle vertices and16 supports. No optimizer.'});checks={'passed':True,'seconds':time.perf_counter()-start,'fixed_originals':31,'fixed_source_valid':True,'moving_originals':35,'continuous_parameters':85,'continuous_cog_angles':15,'moving_pairs':595,'fixed_containing_boxes_verified':1,'base_arrangements_verified':17,'atomic_cells_verified':atom_count,'compound_modes_by_family':{f:len(v) for f,v in expected_modes.items()},'owner_compound_bindings':bindings,'whole_cell_piece_core_supports':proof_count,'minimum_certified_axis_gap_mm':min_gap,'source_corner_controls':len(corner_controls),'source_control_originals':48,'source_control_valid':True,'seed_moving_projections_verified':17,'moving_frame_copies_verified':[16,17],'frame_clearance_supports_verified':16,'maximum_projection_nanometres':max(s['projection_distance_mm'] for s in seeds)*1e6,'complete_preparation_seconds':charge,'library_sha256':digest(BASE/'library.json'),'complete_initializer_prepared':False,'complete_model_prepared':False,'source_optimizer_calls':0,'source_valid66':False,'H5_complete':False};write(OUT/'checks.json',checks);print(checks)
