"""Dynamic source-center model with explicit angle-owner coordinates."""
from itertools import combinations
import numpy as np
from h5_hard_cell_vector_model_20261107 import Objective as PriorObjective
from h5_mixed_direct_pose_20261107 import source_pose,source_rows,owner_shapes,pair_energy

def compile_model(library,modes,values):
    count=len(library['identities']);angle_owners=[i for i,(family,_) in enumerate(library['identities']) if family=='cog']
    parameters=2*count+len(angle_owners)
    assert len(modes)==count and len(values)==parameters==library['continuous_parameters']
    assert library['angle_coordinate_start']==2*count and library['angle_owners']==angle_owners
    assert library['pairs']==[list(p) for p in combinations(range(count),2)]
    owners=[];bounds=[]
    for i,(identity,mi) in enumerate(zip(library['identities'],modes)):
        mode=library['family_modes'][identity[0]][mi];assert mode['mode']==mi
        free=i in angle_owners;bounds.extend(mode['center_bounds_mm'])
        owners.append({'owner':i,'identity':identity,'mode':mi,'source_mode':mode['source_mode'],'cell_index':mode['cell_index'],'rotation_radians':mode['rotation_radians'],'mirrored':mode['mirrored'],'source_center':library['families'][identity[0]]['source_center'],'angle_coordinate':2*count+angle_owners.index(i) if free else None,'angle_scale_mm':library['angle_scale_mm'] if free else None})
    bounds.extend(library['angle_bounds'])
    return {'families':library['families'],'owners':owners,'pairs':library['pairs'],'fixed_source_rows':library['fixed_source_rows'],'parameters':parameters,'bounds':bounds,'initial':np.clip(values,np.asarray(bounds)[:,0],np.asarray(bounds)[:,1]).tolist(),'objective_weights':{'original_area':1,'clearance_area':1}}

# The independently checked vector kernel only assumed a fixed gradient length.
# Keep its geometry and score implementation; the new evaluator derives the size.
class Objective(PriorObjective):
    def evaluate(self,values,details=False):
        import shapely
        from h5_vector_boundary_gradient_20261107 import boundary_gradient
        g=np.zeros(self.model['parameters']);levels=[];records=[];shared=0.;segments=0
        for kind,entries in zip(['original','clearance'],self.geometry(values)):
            shapes=np.asarray([e[1] for e in entries],dtype=object)
            areas=shapely.area(shapely.intersection(shapes[self.left],shapes[self.right]));levels.append(float(np.sum(areas)))
            for index in np.flatnonzero(areas>0):
                i,j=self.model['pairs'][index]
                if details:records.append({'kind':kind,'owners':[i,j],'area_mm2':float(areas[index])})
                for own,other in [(i,j),(j,i)]:
                    v,poly,lines,pivot=entries[own];gg,n,coincident=boundary_gradient(v,lines,entries[other][1],pivot);g[2*own:2*own+2]+=gg[:2];o=self.model['owners'][own]
                    if o['angle_coordinate'] is not None:g[o['angle_coordinate']]+=gg[2]/o['angle_scale_mm']
                    shared+=coincident;segments+=n
        total=sum(levels);assert np.isfinite(total) and np.all(np.isfinite(g))
        if details:return total,g,{'original_overlap_area_mm2':levels[0],'clearance_overlap_area_mm2':levels[1],'positive_terms':records,'clipped_segments':segments,'coincident_boundary_length_mm':shared}
        return total,g
