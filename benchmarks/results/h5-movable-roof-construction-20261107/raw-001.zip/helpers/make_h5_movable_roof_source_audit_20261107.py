from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_mixed_roof_hard_cells_20261107.py').read_text(encoding='utf-8')
def replace(a,b):
    global s
    assert a in s,a;s=s.replace(a,b)
replace('h5-mixed-roof-hard-cells-20261107','h5-movable-roof-source-20261107')
replace('h5-mixed-roof-hard-cells-preparation-process-20261107','h5-movable-roof-source-preparation-process-20261107')
replace('fixed33','fixed31')
replace("fixed=source['fixed_source_rows'];", "fixed=[r for r in source['fixed_source_rows'] if not(r['part_id']=='frame' and r['copy_index'] in [16,17])];")
replace("lib['families']==source['families']", "{f:lib['families'][f] for f in source['families']}==source['families']")
replace("[('base',range(16)),('roof',range(16,18))]", "[('base',range(16))]")
insert="""
frame=parts['frame'];outer=frame['geometry'][0]['outer'];assert outer==[[0.,0.],[450.,0.],[450.,350.],[0.,350.]] and not frame['allow_mirror'] and frame['rotations']['degrees']==[0.,90.,180.,270.]
partitions['frame']={'pieces':[outer],'construction':'exact convex source rectangle; no triangulation'};assert partitions==load(BASE/'partitions.json')
fg=lib['families']['frame'];assert fg['original']==outer and fg['source_center']==[225.,175.] and fg['source_holes']==frame['geometry'][0]['holes'] and len(fg['source_holes'])==1
expected_corners={(float(x),float(y)) for x in [F('-.115'),F('450.115')] for y in [F('-.115'),F('350.115')]};assert len(fg['clearance'])==4 and set(map(tuple,fg['clearance']))==expected_corners
fc=load(BASE/'frame-clearance-supports.json');assert fc['required_mm']=='.114' and fc['square_halfwidth_mm']=='.115';supports=fc['supports'];assert len(supports)==16 and {(p['source_edge'],p['expanded_edge']) for p in supports}==set(product(range(4),repeat=2));minimum=math.inf
original=list(map(lambda p:tuple(map(F,p)),outer));expanded=list(map(lambda p:tuple(map(F,p)),fg['clearance']))
assert area(original)>0 and area(expanded)>0
for p in supports:
    ai,bi=p['source_edge'],p['expanded_edge'];nx,ny=map(F,p['normal']);n2=nx*nx+ny*ny;distance=min(x*nx+y*ny for x,y in [expanded[bi],expanded[(bi+1)%4]])-max(x*nx+y*ny for x,y in [original[ai],original[(ai+1)%4]])
    assert n2>0 and distance>0 and distance**2>=F('.114')**2*n2;minimum=min(minimum,float(distance)/math.sqrt(float(n2)))
assert minimum==fc['minimum_certified_gap_mm'];write(OUT/'frame-clearance-controls.json',{'passed':True,'source_rectangle':[450,350],'source_holes':1,'source_legal_rotations':[0,90,180,270],'mirror_allowed':False,'exact_edge_supports':16,'minimum_certified_clearance_mm':minimum,'filled_outer_enforces_PIH_off':True})
"""
replace("for family in ['bracket','insert']:",insert+"\nfor family in ['frame','bracket','insert']:")
replace("for family in ['bracket','insert','cog']:","for family in ['frame','bracket','insert','cog']:")
replace("len(decompositions)==13 and len(expected_modes['cog'])>1", "len(decompositions)==17 and len(expected_modes['frame'])>=4 and len(expected_modes['cog'])>=1")
replace("ids=[['bracket',i]", "ids=[['frame',16],['frame',17]]+[['bracket',i]")
replace('combinations(range(33),2)','combinations(range(35),2)')
replace("lib['continuous_parameters']==81 and lib['angle_coordinate_start']==66 and lib['first_cog_owner']==18", "lib['continuous_parameters']==85 and lib['angle_coordinate_start']==70 and lib['angle_owners']==list(range(20,35))")
replace("if row['part_id']!='cog':continue\n    identity=['cog',row['copy_index']];", "identity=[row['part_id'],row['copy_index']]\n    if identity not in ids:continue\n    family=identity[0];assert family in ['frame','cog'];")
replace("px,py=lib['families']['cog']['source_center'];oldcenter=", "px,py=lib['families'][family]['source_center'];oldcenter=")
replace("for mode in lib['family_modes']['cog']:\n        point=", "eligible=[m for m in lib['family_modes'][family] if family=='cog' or (not m['mirrored'] and abs(math.remainder(m['rotation_radians']-theta,math.tau))<1e-12)]\n    for mode in eligible:\n        point=")
replace("for m in lib['family_modes']['cog'] if all", "for m in eligible if all")
replace('source15-moving-seed.json','source17-moving-seed.json')
replace("'plan.json','library.json','fixed31-source.json'", "'plan.json','library.json','partitions.json','frame-clearance-supports.json','fixed31-source.json'")
replace('in both coreboxes, all13', 'in the single base core box, all17')
replace('all33 owner bindings,15 nearest-cell source projections', 'all35 owner bindings,17 nearest-cell source projections including two frames')
replace('Multiple cog cells preserved.', 'All legal frame cells preserved; both roof frames remain movable. Frame clearance independently checked from exact rectangle vertices and16 supports.')
replace("'fixed_originals':33", "'fixed_originals':31")
replace("'moving_originals':33", "'moving_originals':35")
replace("'continuous_parameters':81", "'continuous_parameters':85")
replace("'moving_pairs':528", "'moving_pairs':595")
replace("'fixed_containing_boxes_verified':2", "'fixed_containing_boxes_verified':1")
replace("'base_arrangements_verified':13", "'base_arrangements_verified':17")
replace("'seed_cog_projections_verified':15", "'seed_moving_projections_verified':17,'moving_frame_copies_verified':[16,17],'frame_clearance_supports_verified':16")
with (ROOT/'output/audit_h5_movable_roof_source_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
w=(ROOT/'output/run_h5_mixed_roof_hard_cells_audit_20261107.py').read_text(encoding='utf-8').replace('h5-mixed-roof-hard-cells-audit-process','h5-movable-roof-source-audit-process').replace('audit_h5_mixed_roof_hard_cells','audit_h5_movable_roof_source')
with (ROOT/'output/run_h5_movable_roof_source_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(w)
