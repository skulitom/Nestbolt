"""Archive source-safe movable frames, verified model and closed results."""
from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=source[:source.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-movable-roof-construction-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-movable-roof-model-20261107';F=BASE/'response-audit';D=ROOT/'output/h5-movable-roof-source-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-mixed-roof-joint-construction-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['closed_optimizer_calls']==3 and front['source_pair_failures']==52 and not front['source_valid66']",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D]+[ROOT/'output'/n for n in ['h5-movable-roof-source-preparation-process-20261107','h5-movable-roof-source-audit-process-20261107','h5-movable-roof-initializer-process-20261107','h5-movable-roof-model-audit-process-20261107','h5-movable-roof-response-audit-process-20261107']]",
"['*h5*mixed*mode*20261107.py']":"['*h5*movable*roof*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_movable_roof_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'"
}
for old,new in changes.items():assert old in prefix,old;prefix=prefix.replace(old,new)
exec(prefix)
runtime={name:r['sha256'] for name,r in load(BASE/'audit/tool-provenance.json')['tool_files'].items()}
for name,h in runtime.items():assert name.startswith('.cache/') and digest(ROOT/name)==h
write(OUT/'runtime-bindings.json',runtime)
copies=[(D/'audit/checks.json','source-domain-audit.json'),(D/'audit/frame-clearance-controls.json','frame-clearance-controls.json'),(BASE/'audit/checks.json','model-audit.json'),(BASE/'audit/physical-mode-controls.json','physical-mode-controls.json'),(BASE/'audit/derivative-controls.json','derivative-controls.json'),(BASE/'audit/negative-controls.json','negative-controls.json'),(F/'checks.json','response-audit.json'),(F/'mode-selection-controls.json','mode-selection-controls.json'),(F/'round-reconciliation.json','round-reconciliation.json'),(F/'round-02-collision-details.json','source-failures.json'),(BASE/'frame-constraint-diagnostic/checks.json','frame-constraint-diagnostic.json'),(BASE/'frame-constraint-diagnostic/records.json','frame-constraint-records.json'),(BASE/'search/process.json','closed-process.json'),(BASE/'main-ci-at-review.json','main-ci-at-review.json')]
for p,name in copies:shutil.copyfile(p,OUT/name)
write(OUT/'checks.json',{'passed':True,**archive,'external_evidence_references':len(external),'source_bindings':len(bindings),'separately_pinned_runtime_files':len(runtime),**{k:v for k,v in front.items() if k not in ['passed','seconds']}})
write(OUT/'next-step.json',{'status':'larger_movable_frame_group_source_preflight_required','proposal':'Assess freeing frame copies12..17, including the upper four base frames and both roof frames; retain only frame copies0..11 plus the15 short-sheet originals as fixed.','reason':'In the current best candidate both moving frames remain at their base-imposed lower y bound, and their negative local objective gradients point below that bound. Five moving-frame pairs still fail. This describes these candidates only and does not prove the smaller model infeasible.','proposed_inventory':{'fixed_originals':27,'moving_originals':39,'moving_frame_copies':list(range(12,18)),'center_parameters':78,'continuous_cog_angles':15,'continuous_parameters':93,'moving_pairs':741},'requirements':['Reconstruct the twelve-frame fixed core and all six newly movable frame source poses from original geometry, with legal quarter turns and no mirroring. Keep source holes and common-line PIHoff intact.','Certify new source-safe domains against the smaller fixed core and audit the changed39-owner/93-parameter/741-pair mapping. Do not reuse the35-owner readback unchanged.','Prepare one fresh complete source-only initializer, charge all consumed source lineage and new preparation, and independently verify geometry, gradients, inventory, bounds and the complete model before a bounded call.','No optimized current or historical candidate may reset its clock. All closed35-owner and fixed-roof pipelines remain closed. The older39-mover construction had different fixed parts and is not this proposed frame-mobility model.'],'new_source_geometry_prepared':False,'new_complete_model_prepared':False,'new_optimizer_calls':0,'H5_complete':False})
report=f'''# Movable roof-frame construction — 2026-11-07

The broader model frees the two roof-frame originals, but its complete bounded
search still produces no valid layout. Three distinct calls close with a best
candidate containing **52 failing original pairs** and **32,645.952364 mm²**
overlap. Every fixed-part and stock check passes. No native call or allocation
exclusion follows. H2/H5 remain open at **60% completed milestone weight**.

## Original geometry and expanded movement

Only sixteen base frames and fifteen short-sheet originals remain fixed.
The two roof frames join six brackets, twelve inserts and fifteen cogs: **35
moving originals, 85 continuous parameters and all 595 moving pairs**. Each
frame keeps its original 450×350 mm outer rectangle and hole. Its allowed
rotations are 0°, 90°, 180° and 270°, with no mirroring. Filled outer geometry
continues to enforce common-line mode's prohibition on part-in-hole placement.

[Independent source-domain checks]({NAME}/source-domain-audit.json) verify
the twelve bracket/insert arrangements, four frame orientations and all-angle
cog envelope against one outward-rounded box containing the sixteen base frames.
All **44 atomic cells, 27 exact support proofs, 125 owner bindings and 620
original-source corner controls** pass. Minimum certified axis gap is
0.230001 mm. Domains conservatively restrict source free space; they do not
claim complete coverage of every legal placement.

[Frame clearance checks]({NAME}/frame-clearance-controls.json) independently
verify the exact expanded rectangle and all sixteen edge supports, certifying
at least 0.114 mm local offset. The inherited bracket/insert/cog source contours
and evidence remain unchanged. Source projections of the two frames and fifteen
cogs are at most **2.828427 nanometres**. Their 48-part control stays valid but
still lacks the eighteen companions. Complete source preparation is 4.494252 s.

## Fresh complete initializer and model

One new initializer starts from the seventeen unoptimized source poses, then
greedily places the six brackets and twelve inserts on all legal compound
9×9 grids. It consumes no optimized ancestor and no previous companion
initializer. Canonical alias-bound cuts require at most another 1.414214 nm
seed projection; the resulting original 48-part control independently passes.

[Full model readback]({NAME}/model-audit.json) replays **8,262 candidate trials,
125 owner/mode full scores and 91 mode vectors**. There are 97 physical owner
options and 62 distinct single-owner neighbors after outline/domain equivalence.
All [114 equivalence comparisons]({NAME}/physical-mode-controls.json) preserve
different frame orientations and different effective domains. The new compiler
derives angle coordinates from owner identities and parameter counts; the
independent verifier checks every frame and cog binding.

Controls include 148 scalar boundary-gradient comparisons, **340 central
samples over 170 coordinates**, three descent steps and eleven deliberately
corrupted models. [Both derivative step sizes pass]({NAME}/derivative-controls.json).
The complete initializer starts with 37 failing pairs and 100,406.579957 mm²
original overlap; it is not a valid full66 layout. Complete consumed source
and initializer preparation, including both wrapper processes, is **7.951382 s**.

## Closed bounded search and independent replay

The finite pipeline permits at most three distinct physical vectors, with
16/14/14-second slices and preparation-inclusive 60/90-second algorithm/shared
limits. All centers remain free inside certified hard domains, and all fifteen
cog angles remain continuous. The two later mode choices affect inserts;
frame quarter-turn alternatives are considered but not selected.

[Independent response replay]({NAME}/response-audit.json) verifies **123 mode
trials and 380 retained points**, and reconciles the counters for **469 recorded
function evaluations**. Every candidate reconstructs all 66 original parts,
1,380 same-sheet pairs, 264 stock edges, 90 holes and 10,026 hole vertices.
The successive candidates fail 60, 61 and 52 pairs; the third is best by the
declared objective. [Its source failures]({NAME}/source-failures.json) comprise
50 positive intersections and two clearance failures, all between moving parts.

The declared call limit closes the pipeline. Algorithm/shared totals are
**54.899362/54.970363 s**. Slice overruns of 0.019038, 0.027600 and 0.086949 s
are retained within the overall limits. [All five search processes close]({NAME}/closed-process.json),
with peak aggregate committed memory 94,683,136 bytes. These calls cannot resume,
repeat or receive a reset clock; local failure proves no allocation impossible.

## Observed frame limits and next source scope

[A separate read-only diagnostic]({NAME}/frame-constraint-diagnostic.json)
reconstructs frame motion and active bounds at all three saved candidates.
In the best one, the frames move **0 and 0.004160 mm**, retain their original
orientation, and both sit at the lower y bound imposed by the fixed base.
Their local negative objective-gradient directions point below that bound.
Five failing pairs involve these frames, totaling **5,177.537220 mm²** overlap.
[The complete observations]({NAME}/frame-constraint-records.json) describe these
specific candidates; they are not a global stationarity or infeasibility proof.

[The next preflight]({NAME}/next-step.json) assesses freeing the upper four
base frames as well, making original frame copies12–17 movable. With twelve base
frames and fifteen short-sheet parts fixed, the proposed model would have
39 movers, 93 parameters and 741 moving pairs. The smaller fixed core requires
new source-safe domains, a fresh source-only initializer, complete accounting
and independent model/gradient verification. No successor geometry or call is
prepared. Every earlier closed pipeline remains closed.

Four earlier fixed arrangements and 440 whole allocations remain unresolved.
Full66 source/native/material checks, production parity and the unchanged H5
matrix remain required. H2 retains its original gate and reserved vectors.
[Main CI at review]({NAME}/main-ci-at-review.json) has five passed jobs and a live
Windows native job on main61ae8141. Checkpoint4b666d51 and this checkpoint await
the ordinary push gate. Production, README and releases are unchanged; no
release qualifies. [Raw evidence]({NAME}/raw-manifest.json) and
[source bindings]({NAME}/source-bindings.json) retain exact historical references;
six installed runtime files are [separately pinned]({NAME}/runtime-bindings.json).
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry='**2026-11-07 H5 movable roof frames:** [independent source/model/response audits]({link}) verify two newly movable frame originals, 44 atomic cells, 27 exact supports, 620 source corner controls and sixteen frame-clearance supports. The 35-mover/85-parameter model scores all 595 moving pairs. One fresh initializer replays 8,262 trials; checks cover 125 owner options, 91 vectors, 114 equivalence pairs and 340 derivative samples. Three distinct calls and 123 mode trials close at the declared limit; 380 retained points replay and 469 recorded evaluations reconcile. The best candidate still fails 52 original pairs with 32,645.952364 mm² overlap; all fixed-part and stock checks pass. Complete preparation is 7.951382 s and algorithm/shared totals are 54.899362/54.970363 s. All slice overruns are retained and all processes close. A read-only diagnostic finds frame motions of 0 and 0.004160 mm, both at their lower y bounds with downward local descent blocked; five frame-related pairs contribute 5,177.537220 mm² overlap. These are candidate observations, not an infeasibility proof. Next assess freeing original frame copies12–17, requiring new domains and a 39-mover/93-parameter/741-pair model; no new geometry or call is prepared. Four earlier fixed arrangements and 440 allocations remain; H2/H5 stay open at 60%. Main61ae8141 has five passed jobs and a live Windows native job; 4b666d51 and this checkpoint await the ordinary push gate. Production, README and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';s=p.read_text(encoding='utf-8');a=s.index('Latest H5 evidence:');b=s.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [movable roof frames](../benchmarks/results/{NAME}.md).
The broader model frees both top frames, with 35 moving parts, 85 parameters
and 595 pair interactions. Source/model audits verify all 8,262 initializer
trials, 125 owner options and 340 derivative samples. Three distinct calls and
123 mode trials close at the declared limit. All 380 retained points replay
and 469 recorded evaluations reconcile. The best candidate still fails 52
original pairs, with 32,645.952364 mm² overlap; fixed-part and stock checks pass.
Algorithm/shared totals are 54.899362/54.970363 s including 7.951382 s preparation.
All processes close and all slice overruns remain preserved. No full66 witness,
native call or allocation exclusion follows. The two frames move at most
0.004160 mm and reach their lower y bounds; five frame-related pairs still fail.
Next assess freeing frame copies12–17, which requires newly certified domains
and a 39-mover/93-parameter/741-pair model. No successor geometry is prepared.
All closed calls remain closed. Four earlier fixed arrangements and 440
allocations remain; H2/H5 stay at 60% completed milestone weight.
Main61ae8141 has five passed jobs and a live Windows native job. Checkpoint
4b666d51 and this checkpoint await the ordinary push gate. Full66 source/native/
material checks, production parity and the unchanged H5 matrix remain required.
No release qualifies.
'''
p.write_text(s[:a]+intro+s[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n')
print({'artifact':NAME,**archive,'external_evidence':len(external),'source_bindings':len(bindings)})
