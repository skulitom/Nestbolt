from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'output/audit_h5_hard_cell_direct_model_20261107.py').read_text(encoding='utf-8')
def replace(a,b):
    global s
    assert a in s,a;s=s.replace(a,b)
replace('h5_hard_cell_direct_model_20261107','h5_movable_roof_model_20261107')
replace('h5_hard_cell_direct_readback_20261107','h5_movable_roof_readback_20261107')
replace('h5-three-column-hard-cells-v2-20261107','h5-movable-roof-source-20261107')
replace('h5-hard-cell-direct-model-20261107','h5-movable-roof-model-20261107')
replace("{'bracket':list(range(10)),'insert':[0,1,2,0,1,2],'cog':[0]}","{'frame':[0,1,0,1],'bracket':list(range(9)),'insert':[0,1,0,1],'cog':[0]}")
replace("        for seed in lib['source_moving_seed']:\n            p=seed['center']\n            if seed['identity'][0]==family and all(bb[k][0]<=p[k]<=bb[k][1] for k in [0,1]):points.add(tuple(p))\n",'')
a=s.index("for seed in lib['source_moving_seed']:\n    if seed['identity'][0]!='cog':continue")
b=s.index("records=load(BASE/'initializer-trials.json')",a)
s=s[:a]+"""seed_records=[]
for seed in lib['source_moving_seed']:
    i=seed['owner'];family=seed['identity'][0];theta=seed['angle_radians'];eligible=[o for o in lib['family_modes'][family] if family=='cog' or (not o['mirrored'] and abs(math.remainder(o['rotation_radians']-theta,math.tau))<1e-12)];choices=[]
    for o in eligible:
        point=[min(hi,max(lo,seed['center'][k])) for k,(lo,hi) in enumerate(o['center_bounds_mm'])];choices.append((sum((a-b)**2 for a,b in zip(point,seed['center'])),o['mode'],point))
    squared,mi,point=min(choices);assert squared<.0001**2 and modes[i]==mi and values[2*i:2*i+2].tolist()==point
    if family=='cog':assert values[lib['angle_coordinate_start']+lib['angle_owners'].index(i)]==theta*radius
    placed.append(independent_shapes(family,mi,point,theta));seed_records.append({'owner':i,'identity':seed['identity'],'source_center':seed['center'],'center':point,'mode':mi,'angle_radians':theta,'projection_distance_mm':math.sqrt(squared)})
assert seed_records==load(BASE/'canonical-seed-projections.json') and len(placed)==17
seed_energy=sum(placed[i][k].intersection(placed[j][k]).area for i in range(17) for j in range(i+1,17) for k in [0,1])
"""+s[b:]
replace("list(range(18));trials=0;total=0.","list(range(2,20));trials=0;total=seed_energy")
replace('trials==10932','trials==8262')
replace('66+i-18','70+i-20')
replace('if i>=18 else','if i>=20 else')
replace('if own>=18:reference[66+own-18]','if own>=20:reference[70+own-20]')
replace('bindings==147 and vectors==115','bindings==125 and vectors==91')
replace('np.zeros(81)','np.zeros(85)')
replace('np.arange(81)','np.arange(85)')
replace('range(81)','range(85)')
replace("chosen[:18]=[(m+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,m in enumerate(chosen[:18])]", "chosen=[(m+1)%len(lib['family_modes'][lib['identities'][i][0]]) for i,m in enumerate(chosen)]")
old="""    for k in range(85):
        plus=point.copy();minus=point.copy();plus[k]+=1e-4;minus[k]-=1e-4;numeric=(full_energy(mm,plus)-full_energy(mm,minus))/2e-4;error=abs(numeric-gg[k]);assert error<.02+3e-6*abs(gg[k]),(variation,k,numeric,gg[k],error);errors.append(float(error))
    derivatives.append({'variation':variation,'coordinates':81,'maximum_absolute_error':max(errors)})"""
new="""    for k in range(85):
        for step in [1e-5,1e-6]:
            plus=point.copy();minus=point.copy();plus[k]+=step;minus[k]-=step;numeric=(full_energy(mm,plus)-full_energy(mm,minus))/(2*step);error=abs(numeric-gg[k]);assert error<.02+3e-6*abs(gg[k]),(variation,k,step,numeric,gg[k],error);errors.append(float(error))
    derivatives.append({'variation':variation,'coordinates':85,'steps':[1e-5,1e-6],'samples':170,'maximum_absolute_error':max(errors)})"""
replace(old,new)
replace("len(equivalence_controls)==137 and classes['bracket'][2]!=classes['bracket'][3] and classes['insert'][1]!=classes['insert'][2] and classes['insert'][0]==classes['insert'][3]", "len(equivalence_controls)==114 and classes['bracket'][2]!=classes['bracket'][3] and classes['insert'][0]==classes['insert'][2] and classes['frame'][0]==classes['frame'][2] and classes['frame'][0]!=classes['frame'][1]")
replace("enumerate(lib['identities'][:18])","enumerate(lib['identities'])")
replace('len(keys)==78 and equivalent==12 and raw==114','len(keys)==62 and equivalent==14 and raw==90')
replace("'compound_equivalence_pair_controls':137,'source_owner_options':147,'physical_owner_options':111,'unique_single_owner_physical_neighbors':78,'raw_current_equivalents':12,'raw_alternatives':114", "'compound_equivalence_pair_controls':114,'source_owner_options':125,'physical_owner_options':97,'unique_single_owner_physical_neighbors':62,'raw_current_equivalents':14,'raw_alternatives':90")
replace("mm['owners'][18]['angle_coordinate']=67","mm['owners'][20]['angle_coordinate']=71")
replace("mm['parameters']=80","mm['parameters']=84")
replace('h5-hard-cell-initializer-process-20261107/prepare.json','h5-movable-roof-initializer-process-20261107/process.json')
replace("prep['passed'] and prep['job']['closed']","prep['passed'] and prep['closed'] and all(r['job']['closed'] and r['job']['active_processes']==0 for r in prep['stages'])")
replace("'audit/checks.json','audit/unit-label-correction.json'","'audit/checks.json','audit/plan.json','frame-clearance-supports.json'")
replace("'compound-candidates.json','initializer-trials.json'","'compound-candidates.json','canonical-seed-projections.json','initializer-trials.json'")
replace("'h5_movable_roof_model_20261107.py','h5_movable_roof_readback_20261107.py'","'h5_movable_roof_model_20261107.py','h5_hard_cell_vector_model_20261107.py','h5_vector_boundary_gradient_20261107.py','h5_movable_roof_readback_20261107.py'")
replace('All10932trial scores/choices,147ownercompoundbindings/fullscores,115vectors,528pairs/81parameters','All8262trial scores/choices,125ownercompoundbindings/fullscores,91vectors,595pairs/85parameters including two movable frame owners')
replace('162centralderivatives,137compoundequivalencecontrols','170centralcoordinates at two steps (340samples),114compoundequivalencecontrols')
replace("'independent_central_coordinates':162", "'independent_central_coordinates':170,'independent_central_samples':340")
replace("'compound_equivalence_controls':137", "'compound_equivalence_controls':114")
# Reconstruct a fresh partial48 after canonical seed projections as well.
replace("obj=Objective(model);energy,g,details=obj.evaluate(values,True);", "seed_ids={tuple(r['identity']) for r in seed_records};partial=[r for r in rows if (r['part_id'],r['copy_index']) in fixedids|seed_ids];partial_check=audit(job,partial,lib['source_stocks'],lib['required_pair_gap_mm'],lib['stock_guard_mm']);assert partial_check['valid'] and partial_check['originals']==48;write(OUT/'canonical-source48-checks.json',partial_check);obj=Objective(model);energy,g,details=obj.evaluate(values,True);")
replace("'source_pair_failures':source['pair_failures']", "'canonical_source48_valid':True,'frame_center_coordinates_verified':4,'source_pair_failures':source['pair_failures']")
with (ROOT/'output/audit_h5_movable_roof_model_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
w=(ROOT/'output/run_h5_mixed_roof_continuous_model_audit_20261107.py').read_text(encoding='utf-8').replace('h5-mixed-roof-continuous-model-audit-process','h5-movable-roof-model-audit-process').replace('audit_h5_mixed_roof_continuous_model','audit_h5_movable_roof_model')
with (ROOT/'output/run_h5_movable_roof_model_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(w)
