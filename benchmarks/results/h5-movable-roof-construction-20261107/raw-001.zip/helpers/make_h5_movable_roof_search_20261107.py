from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
common=[('h5-hard-cell-direct-model-20261107','h5-movable-roof-model-20261107'),('h5-three-column-hard-cells-v2-20261107','h5-movable-roof-source-20261107'),('h5_hard_cell_direct_model_20261107','h5_movable_roof_model_20261107'),('h5_hard_cell_direct_readback_20261107','h5_movable_roof_readback_20261107'),('h5-hard-cell-initializer-process-20261107/prepare.json','h5-movable-roof-initializer-process-20261107/process.json'),("lib['identities'][:18]","lib['identities']"),('range(81)','range(85)')]
def transform(old,extra):
    s=(ROOT/'output'/old).read_text(encoding='utf-8')
    for a,b in common+extra:
        assert a in s,(old,a);s=s.replace(a,b)
    return s
s=transform('run_h5_hard_cell_direct_search_20261107.py',[("'parameters':81","'parameters':85"),("'optimizer_slice_seconds':[16,12,12]","'optimizer_slice_seconds':[16,14,14]")])
a=s.index("'method':'One finite new33-mover");b=s.index('});controls=',a)
method='One bounded source-only pipeline for the broader movable-roof model. Two roof-frame originals now have free centers and legal quarter-turn modes, alongside6brackets,12inserts and15continuously rotating cogs. All35centers/15angles are optimized jointly:85parameters and595movingpairs. Only16baseframes and15short-sheet originals remainfixed. Source-certified hardcells protect them andstock. Consume the fresh8262-trial sourceinitializer once; do not consume any optimized fixed-roof ancestor. At mostthree distinct physicalvectors:initial call16s then atmosttwo14s calls selected by complete fullobjective over unvisited single-owner frame/bracket/insert compound changes. All35owners participate, with62distinct physicalneighbors and90raw alternatives before closedvector exclusions. A neighbor neednotimprove initially; retain globalbest separately. Exact nominal filledoutlines plusidentical effective hardrectangles remove aliases. Whole source+initializer wrapper costs are charged. Independentlyreadback each selected85coordinate model and reconstructall66 originals aftereverycall. No restart,repeat,extension,weightchange orclockreset. Stopatvalidity,declaredcount,time,no unvisited neighbor or inconsistency. Local failure never excludes anallocation.'
s=s[:a]+"'method':"+repr(method)+s[b:]
with (ROOT/'output/run_h5_movable_roof_search_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=transform('audit_h5_hard_cell_direct_response_20261107.py',[
 ('len(evaluated)+len(skipped)==114','len(evaluated)+len(skipped)==90'),
 ("opened_optimizer['parameters']==81","opened_optimizer['parameters']==85"),
 ('values[66+i-18]','values[70+i-20]'),('if i>=18 else','if i>=20 else'),
 ('len(moving_pairs)==528','len(moving_pairs)==595'),
 ('81coordinategradients','85coordinategradients'),('All528movingpairs','All595movingpairs'),
 ("result['status']=='MAXIMUM_CALLS' and calls==3 and not result['source_valid66']", "result['status'] in ['MAXIMUM_CALLS','ALGORITHM_TIME_STOP_AFTER_SOURCE_CHECK'] and calls==3 and not result['source_valid66'] and (result['status']=='MAXIMUM_CALLS' or result['rounds'][-1]['algorithm_seconds_including_preparation']>=56)")
])
with (ROOT/'output/audit_h5_movable_roof_response_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
w=(ROOT/'output/run_h5_mixed_roof_continuous_response_audit_20261107.py').read_text(encoding='utf-8').replace('h5-mixed-roof-continuous-response-audit-process','h5-movable-roof-response-audit-process').replace('audit_h5_mixed_roof_continuous_response','audit_h5_movable_roof_response')
with (ROOT/'output/run_h5_movable_roof_response_audit_20261107.py').open('x',encoding='utf-8',newline='\n') as f:f.write(w)
