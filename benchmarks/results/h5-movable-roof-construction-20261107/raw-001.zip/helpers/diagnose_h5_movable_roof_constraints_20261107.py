"""Read-only frame movement and active-bound evidence from closed responses."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import json,math,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-movable-roof-model-20261107';OUT=BASE/'frame-constraint-diagnostic'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
OUT.mkdir();started=time.perf_counter();initial=load(BASE/'initial-mode-values.json');initial_model=load(BASE/'model.json');result=load(BASE/'search/result.json');assert result['closed'] and result['optimizer_calls']==3
inputs=[Path(__file__),BASE/'initial-mode-values.json',BASE/'model.json',BASE/'search/result.json'];rounds=[]
for index in range(3):
    folder=BASE/f'search/round-{index:02d}';model=load(folder/'model.json');response=load(folder/'response.json');source=load(folder/'original-source-checks.json');inputs += [folder/n for n in ['model.json','response.json','original-source-checks.json']]
    frames=[];point=response['best_values'];gradient=response['best_gradient']
    for i,o in enumerate(model['owners']):
        if o['identity'][0]!='frame':continue
        assert o['identity']==initial_model['owners'][i]['identity'] and o['angle_coordinate'] is None
        axes=[]
        for k,name in [(2*i,'x'),(2*i+1,'y')]:
            lo,hi=model['bounds'][k];active='lower' if abs(point[k]-lo)<1e-7 else ('upper' if abs(point[k]-hi)<1e-7 else None)
            blocked=(active=='lower' and gradient[k]>0) or (active=='upper' and gradient[k]<0)
            axes.append({'axis':name,'coordinate_mm':point[k],'bounds_mm':[lo,hi],'gradient_mm':gradient[k],'active_bound_at_1e7mm_tolerance':active,'local_negative_gradient_points_outside_domain':blocked})
        frames.append({'identity':o['identity'],'rotation_radians':o['rotation_radians'],'initial_rotation_radians':initial_model['owners'][i]['rotation_radians'],'center_movement_mm':math.dist(point[2*i:2*i+2],initial['values'][2*i:2*i+2]),'axes':axes})
    bad=[p for p in source['pairs'] if not p['passed']];families=defaultdict(lambda:{'failures':0,'original_overlap_mm2':0.})
    for p in bad:
        name='/'.join(sorted(k[0] for k in p['keys']));families[name]['failures']+=1;families[name]['original_overlap_mm2']+=p['intersection_area_mm2']
    frame_bad=[p for p in bad if any(k[0]=='frame' and k[1] in [16,17] for k in p['keys'])]
    assert len(frames)==2 and sum(r['failures'] for r in families.values())==source['pair_failures']
    rounds.append({'round':index,'frames':frames,'failing_pairs_by_family':dict(families),'moving_frame_pair_failures':len(frame_bad),'moving_frame_original_overlap_mm2':sum(p['intersection_area_mm2'] for p in frame_bad)})
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Inspect every closed response without changing any point or calling an optimizer. Report actual roof-frame translations, orientations, observed active bounds and directions of negative local objective gradients. Group original-source failures by family. Active bounds at a1e-7mm readback tolerance describe these candidates only; this is neither a global stationarity nor an impossibility proof.','optimizer_calls':0,'closed_calls_resumed':False})
write(OUT/'records.json',rounds);best=rounds[result['best_global']['round']]
checks={'passed':True,'seconds':time.perf_counter()-started,'closed_rounds_verified':3,'best_round':best['round'],'best_frame_center_movements_mm':[r['center_movement_mm'] for r in best['frames']],'best_frame_rotations_unchanged':all(r['rotation_radians']==r['initial_rotation_radians'] for r in best['frames']),'best_frame_pair_failures':best['moving_frame_pair_failures'],'best_frame_overlap_mm2':best['moving_frame_original_overlap_mm2'],'best_frame_y_lower_bounds_active':all(r['axes'][1]['active_bound_at_1e7mm_tolerance']=='lower' for r in best['frames']),'best_frame_negative_y_gradients_blocked':all(r['axes'][1]['local_negative_gradient_points_outside_domain'] for r in best['frames']),'optimizer_calls':0,'any_allocation_excluded':False,'H5_complete':False}
write(OUT/'checks.json',checks);print(checks)
