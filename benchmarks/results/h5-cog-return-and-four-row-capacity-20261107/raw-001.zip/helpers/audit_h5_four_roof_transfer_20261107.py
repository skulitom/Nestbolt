"""Independent recipes, full contact census and original-source44 replay."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,time
import numpy as np
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-four-roof-transfer-20261107';OUT=BASE/'audit';OLD=ROOT/'output/h5-orientation-roofs-20261107';SHORT=ROOT/'output/h5-roof-one-short-cog-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def world(r):
    t=r['transform'];c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);assert not t['mirrored'];return np.array(parts[r['part_id']]['geometry'][0]['outer'])@np.array([[c,s],[-s,c]])+t['translation']
def distance(p,q):
    def directed(a,b):
        d=np.roll(b,-1,axis=0)-b;v=a[:,None,:]-b[None,:,:];t=np.clip((v*d[None,:,:]).sum(2)/(d*d).sum(1)[None,:],0,1);v-=t[:,:,None]*d[None,:,:];return float(np.sqrt((v*v).sum(2).min()))
    return min(directed(p,q),directed(q,p))
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+[p for p in BASE.rglob('*') if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Independently derive the four-turned fourth row and two-unturned cap from original frame dimensions; verify all original source identities and exact declared cog sites. Reconstruct polygons by matrix transforms, verify every pool pair/frame contact by vertex-to-segment distance plus filled intersections, check stock and replay all44 source bodies with original holes. Compare the orientation multiset with closed39-owner history without claiming class novelty or authorizing a resumed call.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};rec=load(OLD/'source-recipe.json');der=load(OLD/'cog-derivation.json');origin=rec['origin'];gap=rec['gap_mm'];v=parts['frame']['geometry'][0]['outer'];fw=max(p[0] for p in v)-min(p[0] for p in v);fh=max(p[1] for p in v)-min(p[1] for p in v);row1=origin[1]+3*fw+3*gap;row2=origin[1]+4*fw+4*gap;top=row2+fh;right=origin[0]+2*fw+gap;roof=load(BASE/'roof-source.json');assert len(roof)==6 and [r['copy_index'] for r in roof]==list(range(12,18))
for i,r in enumerate(roof):
    angle=math.pi/2 if i<4 else 0.;xy=[origin[0]+i*(fh+gap),row1] if i<4 else [origin[0]+(i-4)*(fw+gap),row2];assert r['part_id']=='frame' and r['sheet_id']=='sheet-0' and r['transform']['rotation_radians']==angle;assert np.allclose(world(r).min(0),xy,rtol=0,atol=1e-10)
radius=der['radius_upper_mm'];pitch=der['axis_pitch_mm'];sites=load(BASE/'sites.json');expected=[(0,[x,y],[origin[0]+radius+x*pitch,top+gap+radius+y*pitch]) for y in range(3) for x in range(4)]+[(1,[x,0],[right+gap+radius+x*pitch,row2+radius]) for x in range(2)];assert len(sites)==14
for i,(site,(block,grid,xy)) in enumerate(zip(sites,expected)):assert site['site']==i and site['block']==block and site['grid']==grid and np.allclose(site['center'],xy,rtol=0,atol=1e-10)
theta=der['rotation_radians'];c,s=math.cos(theta),math.sin(theta);matrix=np.array([[c,s],[-s,c]]);center=np.array(der['source_center']);pv=[(np.array(parts['cog']['geometry'][0]['outer'])-center)@matrix+site['center'] for site in sites];pp=list(map(Polygon,pv));base=[r for r in load(OLD/'fixed27-source.json') if r['sheet_id']=='sheet-0'];frames=base+roof;fv=list(map(world,frames));fp=list(map(Polygon,fv));checks=load(BASE/'pool-checks.json');required=rec['required_pair_gap_mm'];guard=rec['stock_guard_mm'];assert [r['sites'] for r in checks['pairs']]==list(map(list,combinations(range(14),2))) and [(r['site'],r['frame']) for r in checks['frames']]==[(i,j) for i in range(14) for j in range(18)];contacts=0;minimum=math.inf
for r in checks['pairs']:
    i,j=r['sites'];a=pp[i].intersection(pp[j]).area;g=0. if a>0 else distance(pv[i],pv[j]);assert abs(a-r['intersection_mm2'])<1e-7 and abs(g-r['gap_mm'])<1e-8 and r['passed']==(g+1e-7>=required);contacts+=1
    if r['passed']:minimum=min(minimum,g)
for r in checks['frames']:
    i,j=r['site'],r['frame'];a=pp[i].intersection(fp[j]).area;g=0. if a>0 else distance(pv[i],fv[j]);assert abs(a-r['intersection_mm2'])<1e-7 and abs(g-r['gap_mm'])<1e-8 and r['passed']==(g+1e-7>=required);contacts+=1
assert [r['site'] for r in checks['stock']]==list(range(14))
for r in checks['stock']:
    b=pp[r['site']].bounds;st=rec['source_stocks']['sheet-0'];assert np.allclose(b,r['bounds'],rtol=0,atol=1e-10);assert r['passed']==(b[0]>=st[0]+guard and b[1]>=st[1]+guard and b[2]<=st[2]-guard and b[3]<=st[3]-guard)
rows=load(BASE/'source44.json');assert rows[:18]==frames and rows[-12:]==load(SHORT/'short12-source.json')
for i,(r,site) in enumerate(zip(rows[18:32],sites)):
    assert r['part_id']=='cog' and r['copy_index']==i and r['sheet_id']=='sheet-0' and r['transform']['rotation_radians']==theta;assert np.allclose(world(r),pv[site['site']],rtol=0,atol=1e-10)
allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};ids={(r['part_id'],r['copy_index']) for r in rows};assert len(rows)==len(ids)==44 and list(map(list,sorted(allids-ids)))==load(BASE/'remaining-identities.json');fresh=audit(job,rows,rec['source_stocks'],required,guard);assert fresh==load(BASE/'source44-checks.json');history=load(ROOT/'benchmarks/results/h5-six-unturned-frame-construction-20261107/orientation-comparison.json');assert all(r['frame_physical_multiset']==[0,0,1,1,1,1] for r in history['prior_calls']);process=load(ROOT/'output/h5-four-roof-transfer-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'source44_valid':fresh['valid'],'pool_contacts_verified':contacts,'minimum_passing_cog_pair_gap_mm':minimum,'same_sheet_pairs':fresh['same_sheet_pairs'],'original_holes':sum(len(parts[r['part_id']]['geometry'][0]['holes']) for r in rows),'remaining_brackets':6,'remaining_inserts':16,'complete_preparation_seconds_if_consumed':charge,'matches_prior_closed_frame_orientation_multiset':True,'new_orientation_class_claimed':False,'complete_model_prepared':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
