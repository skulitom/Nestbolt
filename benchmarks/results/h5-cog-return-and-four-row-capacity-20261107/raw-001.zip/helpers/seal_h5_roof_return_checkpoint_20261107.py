"""Archive two fixed-core exclusions and a genuinely changed source construction."""
from pathlib import Path
import json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];s=(ROOT/'output/seal_h5_mixed_mode_checkpoint_20261107.py').read_text(encoding='utf-8');prefix=s[:s.index('copies=[')]
changes={
"NAME='h5-mixed-mode-source-repair-20261107'":"NAME='h5-cog-return-and-four-row-capacity-20261107'",
"BASE=ROOT/'output/h5-mixed-mode-union-20261107';F=ROOT/'output/h5-mixed-mode-checkpoint-20261107';D=ROOT/'output/h5-mixed-mode-coverage-diagnostic-20261107'":"BASE=ROOT/'output/h5-four-roof-inventory-20261107';F=BASE;D=ROOT/'output/h5-four-roof-covers-20261107'",
"PARENT=ROOT/'benchmarks/results/h5-joint-region-and-continuous-repairs-20261107'":"PARENT=ROOT/'benchmarks/results/h5-one-three-transfer-capacity-20261107'",
"front['closed_optimizer_calls']==1 and front['source_pair_failures']==39":"front['all286_companion_splits_excluded'] and front['optimizer_calls']==0",
"folders=[BASE,F,D,ROOT/'output/h5-mixed-mode-union-preparation-process-20261107',ROOT/'output/h5-mixed-mode-coverage-process-20261107',ROOT/'output/h5-joint-union-main-sync-20261107']":"folders=[BASE,D,ROOT/'output/h5-one-roof-all-cogs-20261107',ROOT/'output/h5-four-roof-transfer-20261107',ROOT/'output/h5-one-three-main-sync-20261107']+[ROOT/'output'/('h5-'+n+'-process-20261107') for n in ['one-roof-all-cogs','one-roof-all-cogs-audit','four-roof-transfer','four-roof-transfer-audit','four-roof-covers','four-roof-covers-audit','four-roof-inventory']]",
"['*h5*mixed*mode*20261107.py']":"['*h5_one_roof_all_cogs*20261107.py','*h5_four_roof*20261107.py','*h5_roof_return*20261107.py']",
"'verify_h5_mixed_mode_checkpoint_20261107.py'":"'verify_h5_roof_return_checkpoint_20261107.py','seal_h5_mixed_mode_checkpoint_20261107.py','verify_h5_mixed_mode_checkpoint_20261107.py'",
"for name,h in load(F/'source-bindings.json').items():":"for name,h in {}.items():",
}
for a,b in changes.items():assert a in prefix,a;prefix=prefix.replace(a,b)
exec(prefix)
R=ROOT/'output/h5-one-roof-all-cogs-20261107';S=ROOT/'output/h5-four-roof-transfer-20261107';process=load(ROOT/'output/h5-four-roof-inventory-process-20261107/process.json');assert process['passed'] and process['closed'];total=front['inherited_preparation_seconds']+process['complete_seconds']
copies=[(R/'plan.json','all15-first-plan.json'),(R/'audit/checks.json','all15-first-audit.json'),(R/'first33-source.json','all15-first-source.json'),(R/'whole-part-splits.json','all15-first-splits.json'),(S/'plan.json','four-row-source-plan.json'),(S/'audit/checks.json','four-row-source-audit.json'),(D/'plan.json','four-row-cover-plan.json'),(D/'audit/checks.json','four-row-cover-audit.json'),(D/'audit/class-controls.json','four-row-class-controls.json'),(D/'audit/capacity-results.json','four-row-capacity.json'),(BASE/'plan.json','inventory-corollary-plan.json'),(BASE/'checks.json','inventory-corollary-audit.json'),(BASE/'split-results.json','inventory-corollary-splits.json'),(ROOT/'output/h5-one-three-main-sync-20261107/receipt.json','prior-main-push-receipt.json')]
for n in ['one-roof-all-cogs','one-roof-all-cogs-audit','four-roof-transfer','four-roof-transfer-audit','four-roof-covers','four-roof-covers-audit','four-roof-inventory']:copies.append((ROOT/'output'/('h5-'+n+'-process-20261107')/'process.json',n+'-process.json'))
for p,n in copies:shutil.copyfile(p,OUT/n)
runtime=load(PARENT/'runtime-bindings.json')
for n,h in runtime.items():assert n.startswith('.cache/') and digest(ROOT/n)==h
write(OUT/'runtime-bindings.json',runtime);ci=json.loads(subprocess.check_output(['gh','run','view','42410023316','--json','databaseId,status,conclusion,headSha,jobs,url'],cwd=ROOT,text=True));assert ci['headSha']=='9eb6698eb3f734439be6c04bca5b5c9927de1edc';write(OUT/'main-ci-at-review.json',ci);success=sum(j['conclusion']=='success' for j in ci['jobs']);live=sum(j['status']!='completed' for j in ci['jobs'])
write(OUT/'checks.json',{**front,**archive,'passed':True,'complete_preparation_seconds_if_consumed':total,'source_bindings':len(bindings),'historical_references':len(external),'pinned_runtime_files':len(runtime)})
write(OUT/'next-step.json',{'status':'both_exact_fixed_core_scopes_excluded','proposal':'Keep the newly verified four-turned fourth frame row and two-unturned cap, but enlarge the anonymous source cog pool from four to five columns by three rows above the cap, plus the existing two side sites, giving17 proposed sites. Derive the fifth column from the same original pitch/radius and verify every stock/frame/cog contact before using it. Do not infer capacity from17 anonymous sites. Initially assess every15-of17 subset (136choices) with all original15cogs on the first sheet and the earlier source-valid short6bracket/9insert rows from orientation-roofs/fixed27-source.json. Each complete source48 partial must retain all6remaining brackets and12inserts. These exact cores differ from the just-excluded14site core; earlier four-turned optimization calls remain closed and the orientation class is not globally new. If source valid, derive fresh full-domain masks for the17site geometry, using a distinct fixed-frame bit17 (bit16 is now a cog), retaining at most2empty bits. Independently audit boundary classes and component occupied areas. First assess fixedshort6/9 completion, then unrestricted companion inventories if needed. No optimizer is authorized by a necessary bound alone.','inherited_preparation_seconds':total,'charge_all_new_preparation':True,'proposed_pool_count':17,'proposed_first_cogs':15,'proposed_subsets':136,'source48_prepared':False,'complete_model_prepared':False,'optimizer_calls':0,'earlier_arrangements_remaining':4,'whole_allocation_candidates_remaining':440,'H5_complete':False})
report=f'''# Cog return and four-row frame capacity — 2026-11-07

**Returning the fifteenth cog to its original one-turned roof site cannot
complete that layout.** A different four-row frame construction produces a
valid 44-part partial, but it also fails capacity, even with every bracket
and insert free while the short-sheet cog stays fixed. No whole allocation or
orientation class is excluded. H2/H5 remain open at **60% completed milestone
weight**; the valid 64-part result remains best.

[The original one-turned all15-cog core]({NAME}/all15-first-plan.json) restores
one common first-sheet arrangement rather than opening separate calls for its
four earlier omissions. [Independent source and cover replay]({NAME}/all15-first-audit.json)
checks all33 original parts,528 pairs and33 original holes. Selecting only
zero-conflict labels from the complete masks accounts for **21,858,720
continuous classes**, including every boundary, and exactly covers22,902
zero-conflict classes. All fifteen cog sites are mandatory obstacles.

Separate component-region sweeps verify three exact occupied-area bounds.
At most **317,439.296785 mm²** can hold companions on the first sheet. Adding
the entire outward short-sheet area still leaves a **113,001.654357 mm²**
deficit against all twelve brackets and twenty-one inserts. [Every one of286
whole-part splits fails]({NAME}/all15-first-splits.json). The original-source
first33 remains a valid partial; the impossibility concerns extending that
exact core with all remaining original parts.

[The next source construction]({NAME}/four-row-source-plan.json) keeps twelve
turned base frames, adds four turned frames as a complete fourth row, then
two unturned frames above them at the left. Twelve cog sites occupy a four-
column/three-row grid above the cap, and two sit beside it. Source dimensions,
the declared gap and the existing analytic phase/pitch determine every pose.
The verified short sheet retains six brackets, five inserts and original cog14.

[Independent source checks]({NAME}/four-row-source-audit.json) verify all
**343 pool contacts,562 same-sheet pairs and56 original holes**. All44 original
parts pass; six brackets and sixteen inserts remain unplaced. This upper-frame
orientation multiset already occurs in earlier closed39-owner calls. The new
source placement and one-short-cog allocation do not reopen those calls, and
no global novelty claim is made.

[Fresh necessary-center covers]({NAME}/four-row-cover-plan.json) rebuild all
world obstacles and twelve mode masks. [Independent readback]({NAME}/four-row-cover-audit.json)
verifies **1,096 source inner rectangles,20 component bounds and18,195,372
continuous classes**. Every zero-conflict class is covered exactly once.
Three separate exact interval sweeps verify the source-component occupied
regions after stock clipping and removal of definitely occupied interiors.

[The new fixed44 partial cannot extend to66]({NAME}/four-row-capacity.json):
the combined companion region is at most **439,326.739298 mm²**, below the
required **556,778 mm²**. Bracket/insert family capacities alone do not catch
this failure; their shared available area does.

[The inventory corollary]({NAME}/inventory-corollary-plan.json) reconciles the
exact original short-sheet cog pose with the previously audited rational cog
area and whole-part inventory proof. Freeing every bracket and insert across
both sheets still forces at least **495,777 mm²** of companions onto the first
sheet. [All286 splits fail]({NAME}/inventory-corollary-splits.json), by at least
**56,450.260702 mm²**. [The explicit scope]({NAME}/inventory-corollary-audit.json)
keeps the first eighteen frames/fourteen cogs and original short cog fixed;
it does not exclude moving that last cog elsewhere or changing a fixed pose.

| Bounded stage | Complete preparation (s) | Separate audit (s) |
|---|---:|---:|
| One-turned all15-cog core | 0.427485 | 0.588558 |
| Four-row source partial | 0.369004 | 0.506650 |
| Four-row covers and area | 4.854799 | 6.651112 |
| Inventory corollary | 0.252936 | Direct proof readback |

Complete process records for the [first core]({NAME}/one-roof-all-cogs-process.json)
and its [audit]({NAME}/one-roof-all-cogs-audit-process.json), [new source]({NAME}/four-roof-transfer-process.json)
and its [audit]({NAME}/four-roof-transfer-audit-process.json), [covers]({NAME}/four-roof-covers-process.json)
and their [audit]({NAME}/four-roof-covers-audit-process.json), and [corollary]({NAME}/four-roof-inventory-process.json)
close all three processes in each Job Object. The total charged preparation
is **{total:.6f} s**, retaining all inherited work. No optimizer runs, retries,
extensions or resource-limit changes occur.

[Next]({NAME}/next-step.json), assess the proposed fifth source cog column
above the four-row frame cap. Together with the two side sites this proposes
seventeen anonymous sites, subject to all contact and stock checks. Every
15-of17 choice would give136 first-sheet alternatives with all fifteen cogs
and the earlier short6/9 companion layout. The new masks must give fixed frames
a separate bit17 because site16 becomes a cog. Necessary bounds never establish
feasibility or authorize repetition of a closed solver.

Four earlier fixed arrangements and440 whole-job allocations remain. Full66
source/native/material acceptance, product integration, parity and the H5
matrix still need completion.

[Main and the remote working branch now contain9eb6698e]({NAME}/prior-main-push-receipt.json),
including both preceding checkpoints, after all six prior CI checks passed
with52 protected files unchanged. [Fresh CI]({NAME}/main-ci-at-review.json)
records **{success} passed / {live} live jobs**. This evidence awaits the next
ordinary push gate. Product code, README and releases remain unchanged.

[Archive checks]({NAME}/archive-checks.json), [manifest]({NAME}/raw-manifest.json),
[source bindings]({NAME}/source-bindings.json), [historical references]({NAME}/external-evidence.json)
and [runtime pins]({NAME}/runtime-bindings.json) preserve all evidence.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
entry=f'**2026-11-07 H5 cog return and four-row capacity:** [independent source, cover and inventory proofs]({{link}}) exclude the exact one-turned first33 core with all fifteen original cogs restored: 21,858,720 continuous classes, three area readbacks and286 whole-part splits yield a113,001.654357 mm² combined inventory deficit. A changed four-row frame construction passes all44 source parts,343 pool contacts and562 same-sheet pairs. Its fresh12 masks verify18,195,372 classes and three exact occupied-area bounds, leaving439,326.739298 mm² versus556,778 required. Keeping its short-sheet cog fixed while freeing every bracket and insert still needs495,777 mm² on the first sheet, a56,450.260702 mm² deficit. Neither proof excludes a whole allocation or orientation class; earlier four-turned optimization calls stay closed. All bounded stages close, no optimizer runs, and consumed preparation totals{total:.6f} s. Next validate the proposed fifth cog column and every15-of17 source subset before fresh covers, with the fixed-frame bit kept distinct from all17 sites. Four earlier arrangements and440 allocations remain; valid64 remains best, H2/H5 stay open at60%. Main9eb6698e includes both earlier checkpoints with{success} passed/{live} live fresh CI jobs; this checkpoint awaits the ordinary push gate. Product and releases are unchanged.'
for name in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:
    link=('' if name=='BENCHMARKS.md' else '../')+'benchmarks/results/'+NAME+'.md';append(ROOT/name,'\n\n'+entry.format(link=link)+'\n')
p=ROOT/'docs/STATUS.md';text=p.read_text(encoding='utf-8');a=text.index('Latest H5 evidence:');b=text.index('\nThe earlier fixed 13-cog construction',a)
intro=f'''Latest H5 evidence: [cog return and four-row capacity](../benchmarks/results/{NAME}.md).
The exact one-turned first33 core with all15 original cogs cannot extend to66:
21,858,720 continuous classes and286 whole-part split checks yield a
113,001.654357 mm² combined inventory deficit. A changed four-row frame layout
passes all44 source parts,343 pool contacts and562 pairs, but fresh12 masks
covering18,195,372 classes leave439,326.739298 mm² versus556,778 required.
Keeping its short cog fixed while freeing every companion also fails, by
56,450.260702 mm². No whole allocation or orientation class is excluded; all
old calls remain closed. No optimizer runs; valid64 remains best. Charged
preparation totals{total:.6f} s. Next assess a fifth source cog column and all
15-of17 subsets, validating source geometry before fresh covers. Four earlier
arrangements and440 allocations remain. H2/H5 stay open at60%. Main9eb6698e
includes both earlier checkpoints with{success} passed/{live} live fresh CI
jobs; this checkpoint awaits the ordinary push gate. Product and releases
remain unchanged.
'''
p.write_text(text[:a]+intro+text[b:],encoding='utf-8',newline='\n');append(ROOT/'.gitattributes','\nbenchmarks/results/'+NAME+'/** -text -whitespace\n');print({'artifact':NAME,**archive,'historical_references':len(external),'source_bindings':len(bindings),'total_consumed_preparation_seconds':total})
