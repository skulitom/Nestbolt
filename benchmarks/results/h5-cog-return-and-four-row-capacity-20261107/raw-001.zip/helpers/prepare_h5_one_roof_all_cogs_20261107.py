"""One fixed first33 core, restoring all original cogs to their source sites."""
from pathlib import Path
from hashlib import sha256
from bisect import bisect_left
from itertools import product
import json,time
import numpy as np
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-one-roof-all-cogs-20261107';COVER=ROOT/'output/h5-one-three-covers-20261107';OLD=ROOT/'output/h5-orientation-roofs-20261107';PRIOR=ROOT/'output/h5-one-three-inventory-20261107';STOCK=ROOT/'output/h5-roof-inventory-bound-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def difference_area(region,obstacles):
    rects=region+obstacles;xs=sorted({r[k] for r in rects for k in [0,2]});ys=sorted({r[k] for r in rects for k in [1,3]});assert len(xs)*len(ys)<40000000
    def grid(rows):
        d=np.zeros((len(ys),len(xs)),dtype=np.int32)
        for a,b,c,e in rows:
            i,j=bisect_left(xs,a),bisect_left(xs,c);k,l=bisect_left(ys,b),bisect_left(ys,e);d[k,i]+=1;d[l,i]-=1;d[k,j]-=1;d[l,j]+=1
        return np.cumsum(np.cumsum(d,0,dtype=np.int32),1,dtype=np.int32)[:-1,:-1]>0
    covered=grid(region);blocked=grid(obstacles);weight=np.diff(ys)[:,None]*np.diff(xs)[None,:];return int(np.sum(weight*(covered&~blocked),dtype=np.int64))
OUT.mkdir();began=time.perf_counter();prior=load(PRIOR/'audit/checks.json');assert prior['passed'] and load(COVER/'audit/checks.json')['passed'] and load(STOCK/'audit/checks.json')['passed'];inputs=[Path(__file__),JOB,PRIOR/'audit/checks.json',COVER/'audit/checks.json',COVER/'geometries.json',COVER/'stock-cover.json',COVER/'turned-1/source-inner-rectangles.json',OLD/'turned-1/all15-source.json',OLD/'source-recipe.json',OLD/'audit/checks.json',STOCK/'stock-and-inventory.json',STOCK/'audit/checks.json',ROOT/'output/h5_legacy64_source_readback.py']+[COVER/'turned-1'/f'geometry-{i:02d}.json' for i in range(12)]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Restore all15 source cog sites in the original one-turned roof. This is one common first33 core, regardless of which earlier empty site is restored. Revalidate every original first33 body. Select label0 only from the complete independently audited one-turned full-domain covers; all18frame and15cog inner obstacles are mandatory. Sweep original bracket/insert component bounds over every zero-conflict box, clip to outward physical stock, and subtract mandatory source interiors. Compute exact family/combined occupied areas. Release every bracket and insert across both sheets and enumerate all286 integer splits against physical short area, family capacities and first combined area. Preserve any survivors; no optimizer or whole-allocation exclusion.','inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':10,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False})
job=load(JOB);rec=load(OLD/'source-recipe.json');rows=[r for r in load(OLD/'turned-1/all15-source.json') if r['sheet_id']=='sheet-0'];assert len(rows)==33 and {r['copy_index'] for r in rows if r['part_id']=='frame'}==set(range(18)) and {r['copy_index'] for r in rows if r['part_id']=='cog'}==set(range(15));check=audit(job,rows,rec['source_stocks'],rec['required_pair_gap_mm'],rec['stock_guard_mm']);assert check['valid'];write(OUT/'first33-source.json',rows);write(OUT/'first33-source-checks.json',check)
g=load(COVER/'geometries.json');sb=load(COVER/'stock-cover.json')['outward_stock_rectangle_um'];sources=load(COVER/'turned-1/source-inner-rectangles.json');fixed=[r['bounds_um'] for r in sources];regions={};areas={};covers=[]
for mode in g:
    zero=[r for r in load(COVER/'turned-1'/f"geometry-{mode['geometry']:02d}.json")['cover'] if r[0]==0];covers.append({'geometry':mode['geometry'],'zero_conflict_cover':zero})
for family in ['bracket','insert']:
    rr=[]
    for mode in g:
        if mode['family']!=family:continue
        for label,l,b,r,t,*_ in covers[mode['geometry']]['zero_conflict_cover']:
            for a,c,d,e in mode['outer_component_bounds_um']:
                q=[max(l+a,sb[0]),max(b+c,sb[1]),min(r+d,sb[2]),min(t+e,sb[3])]
                if q[0]<q[2] and q[1]<q[3]:rr.append(q)
    regions[family]=list(map(list,sorted(set(map(tuple,rr)))));areas[family]=difference_area(regions[family],fixed)
joint=list(map(list,sorted(set(map(tuple,regions['bracket']))|set(map(tuple,regions['insert'])))));combined=difference_area(joint,fixed);short=load(STOCK/'stock-and-inventory.json')['short_area_upper_um2'];required=(12*39999+21*19799)*10**6;bc=areas['bracket']//(39999*10**6);ic=areas['insert']//(19799*10**6);splits=[]
for b,i in product(range(13),range(22)):
    flags=[((b*39999+i*19799)*10**6>short,'short_area'),(12-b>bc,'first_bracket_capacity'),(21-i>ic,'first_insert_capacity'),(((12-b)*39999+(21-i)*19799)*10**6>combined,'first_combined_area')];reasons=[name for fail,name in flags if fail];splits.append({'short_brackets':b,'short_inserts':i,'failure_reasons':reasons,'necessary_conditions_pass':not reasons})
write(OUT/'zero-conflict-covers.json',covers);write(OUT/'occupied-regions.json',{'family_regions_um':regions,'combined_region_um':joint,'fixed_inner_obstacles_um':fixed,'family_area_upper_um2':areas,'combined_area_upper_um2':combined});write(OUT/'whole-part-splits.json',splits);write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'fixed_source_parts':33,'source_valid':True,'first_bracket_capacity_upper':bc,'first_insert_capacity_upper':ic,'first_companion_area_upper_mm2':combined/1e6,'whole_companion_area_lower_mm2':required/1e6,'short_area_upper_mm2':short/1e6,'combined_area_deficit_mm2':(required-short-combined)/1e6,'necessary_splits_remaining':sum(r['necessary_conditions_pass'] for r in splits),'provisional_fixed_first33_excluded':all(not r['necessary_conditions_pass'] for r in splits),'independent_audit_pending':True,'whole_allocations_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
