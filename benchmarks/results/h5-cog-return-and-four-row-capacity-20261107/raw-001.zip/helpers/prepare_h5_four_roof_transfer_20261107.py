"""Source-derived fourth frame row and two-frame cap, with one short cog."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json,math,time
from shapely.geometry import Polygon
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/h5-four-roof-transfer-20261107';OLD=ROOT/'output/h5-orientation-roofs-20261107';SHORT=ROOT/'output/h5-roof-one-short-cog-20261107';PRIOR=ROOT/'output/h5-one-roof-all-cogs-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def frame(i,angle,xy):
    c,s=math.cos(angle),math.sin(angle);v=[(x*c-y*s,x*s+y*c) for x,y in parts['frame']['geometry'][0]['outer']];return {'part_id':'frame','copy_index':i,'sheet_id':'sheet-0','transform':{'rotation_radians':angle,'mirrored':False,'translation':[xy[k]-min(p[k] for p in v) for k in range(2)]}}
def cog(i,site):return {'part_id':'cog','copy_index':i,'sheet_id':'sheet-0','transform':{'rotation_radians':phase,'mirrored':False,'translation':[site['center'][0]-(cx*c-cy*s),site['center'][1]-(cx*s+cy*c)]}}
def world(r):
    t=r['transform'];cs,sn=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);assert not t['mirrored'];return Polygon([(x*cs-y*sn+t['translation'][0],x*sn+y*cs+t['translation'][1]) for x,y in parts[r['part_id']]['geometry'][0]['outer']])
OUT.mkdir();began=time.perf_counter();prior=load(PRIOR/'audit/checks.json');assert prior['passed'] and load(SHORT/'audit/checks.json')['passed'] and load(OLD/'audit/checks.json')['passed'];inputs=[Path(__file__),JOB,PRIOR/'audit/checks.json',OLD/'source-recipe.json',OLD/'cog-derivation.json',OLD/'fixed27-source.json',OLD/'audit/checks.json',SHORT/'short12-source.json',SHORT/'audit/checks.json',ROOT/'output/h5_legacy64_source_readback.py',ROOT/'benchmarks/results/h5-six-unturned-frame-construction-20261107/orientation-comparison.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'Keep twelve turned base frames; append four turned frames as a complete fourth row and two unturned frames as a cap at the left. Retain the verified short6bracket/5insert/1cog. Four columns by three rows of source cog sites sit above the cap; two adjacent sites sit to its right. Derive every coordinate from original dimensions, declared gap, audited source radius and single analytic phase/axis pitch; no sweep or optimized point. Check all14 anonymous cog sites against stock, every frame and each other before complete original-source44 replay. Four-turned upper-frame multisets occur in older closed39-owner calls; this is not claimed a new orientation class or a resumed search. The short-sheet cog and first14-cog allocation differ from those older all15-first constructions. Any full model requires further independent source/capacity checks and review of closed-call identities.','inherited_numeric_preparation_seconds':prior['complete_preparation_seconds_if_consumed'],'charge_entire_process_if_consumed':True,'process_cap_seconds':10,'memory_bytes':2**31,'optimizer_calls':0,'retry_permitted':False,'new_orientation_class_claimed':False})
job=load(JOB);parts={p['id']:p for p in job['parts']};rec=load(OLD/'source-recipe.json');der=load(OLD/'cog-derivation.json');o=rec['origin'];gap=rec['gap_mm'];v=parts['frame']['geometry'][0]['outer'];fw=max(p[0] for p in v)-min(p[0] for p in v);fh=max(p[1] for p in v)-min(p[1] for p in v);radius=der['radius_upper_mm'];pitch=der['axis_pitch_mm'];phase=der['rotation_radians'];c,s=math.cos(phase),math.sin(phase);cx,cy=der['source_center'];row1=o[1]+3*(fw+gap);row2=row1+fw+gap;top=row2+fh;right=o[0]+2*fw+gap;roof=[frame(12+i,math.pi/2,[o[0]+i*(fh+gap),row1]) for i in range(4)]+[frame(16+i,0.,[o[0]+i*(fw+gap),row2]) for i in range(2)];blocks=[(4,3,o[0]+radius,top+gap+radius),(2,1,right+gap+radius,row2+radius)];sites=[]
for block,(nx,ny,x0,y0) in enumerate(blocks):
    for yy in range(ny):
        for xx in range(nx):sites.append({'site':len(sites),'block':block,'grid':[xx,yy],'center':[x0+xx*pitch,y0+yy*pitch]})
base=[r for r in load(OLD/'fixed27-source.json') if r['sheet_id']=='sheet-0'];short=load(SHORT/'short12-source.json');frames=base+roof;polys=[world(cog(i,site)) for i,site in enumerate(sites)];fps=list(map(world,frames));pairs=[];contacts=[];stockchecks=[];required=rec['required_pair_gap_mm'];guard=rec['stock_guard_mm'];st=rec['source_stocks']['sheet-0']
for i,j in combinations(range(14),2):
    g=polys[i].distance(polys[j]);pairs.append({'sites':[i,j],'gap_mm':g,'intersection_mm2':polys[i].intersection(polys[j]).area,'passed':g+1e-7>=required})
for i,p in enumerate(polys):
    for j,q in enumerate(fps):
        g=p.distance(q);contacts.append({'site':i,'frame':j,'gap_mm':g,'intersection_mm2':p.intersection(q).area,'passed':g+1e-7>=required})
    b=p.bounds;stockchecks.append({'site':i,'bounds':list(b),'passed':b[0]>=st[0]+guard and b[1]>=st[1]+guard and b[2]<=st[2]-guard and b[3]<=st[3]-guard})
rows=frames+[cog(i,site) for i,site in enumerate(sites)]+short;check=audit(job,rows,rec['source_stocks'],required,guard);allids={(p['id'],i) for p in job['parts'] for i in range(p['quantity'])};ids={(r['part_id'],r['copy_index']) for r in rows};assert len(rows)==len(ids)==44;remaining=sorted(allids-ids);assert len(remaining)==22 and sum(f=='bracket' for f,i in remaining)==6 and sum(f=='insert' for f,i in remaining)==16
for n,v in [('roof-source.json',roof),('sites.json',sites),('source44.json',rows),('source44-checks.json',check),('remaining-identities.json',remaining),('pool-checks.json',{'pairs':pairs,'frames':contacts,'stock':stockchecks})]:write(OUT/n,v)
write(OUT/'checks.json',{'prepared':True,'seconds':time.perf_counter()-began,'source44_valid':check['valid'],'failed_pool_pairs':sum(not r['passed'] for r in pairs),'failed_pool_frame_contacts':sum(not r['passed'] for r in contacts),'failed_pool_stock_sites':sum(not r['passed'] for r in stockchecks),'independent_audit_pending':True,'complete_model_prepared':False,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
