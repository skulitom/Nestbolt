"""Independent zero-mask coverage, source geometry and exact area/inventory proof."""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
from bisect import bisect_left
import json,time,math
import numpy as np
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-one-roof-all-cogs-20261107';OUT=BASE/'audit';COVER=ROOT/'output/h5-one-three-covers-20261107';SOURCE=ROOT/'output/h5-one-three-transfers-20261107';OLD=ROOT/'output/h5-orientation-roofs-20261107';STOCK=ROOT/'output/h5-roof-inventory-bound-20261107';PRIOR=ROOT/'output/h5-one-three-inventory-20261107';JOB=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def sweep(region,obstacles):
    if not region:return 0
    rects=region+obstacles;ys=sorted({r[k] for r in rects for k in [1,3]});events=defaultdict(list)
    for kind,rows in enumerate([region,obstacles]):
        for a,b,c,e in rows:events[a].append((kind,b,e,1));events[c].append((kind,b,e,-1))
    live=np.zeros((2,len(ys)-1),dtype=np.int32);height=np.diff(ys);xs=sorted(events);total=0
    for i,x in enumerate(xs):
        for kind,a,b,change in events[x]:live[kind,bisect_left(ys,a):bisect_left(ys,b)]+=change
        assert live.min()>=0
        if i+1<len(xs):total+=(xs[i+1]-x)*int(height[(live[0]>0)&(live[1]==0)].sum())
    assert not np.any(live);return total
OUT.mkdir();began=time.perf_counter();plan=load(BASE/'plan.json');bindings={}
for p,h in plan['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for old in [COVER/'audit',SOURCE/'audit',STOCK/'audit',PRIOR/'audit']:
    assert load(old/'checks.json')['passed']
    for p,h in load(old/'plan.json')['inputs'].items():assert digest(ROOT/p)==h;bindings[p]=h
for p in [Path(__file__)]+[p for p in BASE.rglob('*') if p.is_file()]:bindings[p.relative_to(ROOT).as_posix()]=digest(p)
write(OUT/'plan.json',{'inputs':bindings,'method':'Reconcile all original source/cover/material inputs and every fixed first33 pose. Independently rederive each original cog pose from the source center, analytic phase and matching anonymous site; verify original frame identities and source geometry. Check the selected zero-label boxes against every continuous class of the audited full one-turned masks, including boundaries and exactly-once cover. Reconstruct all source-component regions and mandatory obstacles. Separate interval-event sweep verifies three union-minus-union areas. Integer division derives every feasible short inventory, then checks all286 complete split reason flags against first-sheet family and combined capacities. The exact fixed first33 hypothesis remains explicit.'})
job=load(JOB);parts={p['id']:p for p in job['parts']};rec=load(OLD/'source-recipe.json');rows=load(BASE/'first33-source.json');frames=[r for r in load(OLD/'fixed27-source.json') if r['sheet_id']=='sheet-0']+load(SOURCE/'turned-1/roof-source.json');assert rows[:18]==frames and len(rows)==33;deriv=load(OLD/'cog-derivation.json');theta=deriv['rotation_radians'];c,s=math.cos(theta),math.sin(theta);center=np.array(deriv['source_center']);rot=np.array([[c,s],[-s,c]]);sites=load(SOURCE/'turned-1/sites.json');assert len(sites)==15
for i,(r,site) in enumerate(zip(rows[18:],sites)):
    t=r['transform'];assert r['part_id']=='cog' and r['copy_index']==i and r['sheet_id']=='sheet-0' and t['rotation_radians']==theta and not t['mirrored'];expected=(np.array(parts['cog']['geometry'][0]['outer'])-center)@rot+site['center'];actual=np.array(parts['cog']['geometry'][0]['outer'])@rot+t['translation'];assert np.allclose(actual,expected,rtol=0,atol=1e-10)
fresh=audit(job,rows,rec['source_stocks'],rec['required_pair_gap_mm'],rec['stock_guard_mm']);assert fresh==load(BASE/'first33-source-checks.json') and fresh['valid'];g=load(COVER/'geometries.json');saved=load(BASE/'zero-conflict-covers.json');classes=0;retained=0
for mode,z in zip(g,saved):
    gi=mode['geometry'];assert z['geometry']==gi;previous=load(COVER/'turned-1'/f'geometry-{gi:02d}.json')['cover'];assert z['zero_conflict_cover']==[r for r in previous if r[0]==0]
    with np.load(COVER/'turned-1'/f'geometry-{gi:02d}-classes.npz',allow_pickle=False) as a:mask=a['mask'];xs=a['xcuts_um'];ys=a['ycuts_um'];covered=np.zeros(mask.shape,dtype=np.bool_)
    for label,l,b,r,t,xa,ya,xb,yb in z['zero_conflict_cover']:
        assert label==0 and [l,b,r,t]==[int(xs[xa//2]),int(ys[ya//2]),int(xs[(xb+1)//2]),int(ys[(yb+1)//2])];assert np.all(mask[ya:yb+1,xa:xb+1]==0) and not np.any(covered[ya:yb+1,xa:xb+1]);covered[ya:yb+1,xa:xb+1]=True
    assert np.array_equal(covered,mask==0);classes+=mask.size;retained+=int(covered.sum())
data=load(BASE/'occupied-regions.json');sources=load(COVER/'turned-1/source-inner-rectangles.json');fixed=[r['bounds_um'] for r in sources];assert fixed==data['fixed_inner_obstacles_um'];assert {tuple(r['identity']) for r in sources if r['kind']=='frame'}=={('frame',i) for i in range(18)} and {r['site_bit'] for r in sources if r['kind']=='cog'}==set(range(15));sb=load(COVER/'stock-cover.json')['outward_stock_rectangle_um'];regions={};areas={}
for family in ['bracket','insert']:
    rr=[]
    for mode in g:
        if mode['family']!=family:continue
        for label,l,b,r,t,*_ in saved[mode['geometry']]['zero_conflict_cover']:
            for a,c0,d,e in mode['outer_component_bounds_um']:
                q=[max(l+a,sb[0]),max(b+c0,sb[1]),min(r+d,sb[2]),min(t+e,sb[3])]
                if q[0]<q[2] and q[1]<q[3]:rr.append(q)
    rr=list(map(list,sorted(set(map(tuple,rr)))));assert rr==data['family_regions_um'][family];regions[family]=rr;areas[family]=sweep(rr,fixed);assert areas[family]==data['family_area_upper_um2'][family]
joint=list(map(list,sorted(set(map(tuple,regions['bracket']))|set(map(tuple,regions['insert'])))));assert joint==data['combined_region_um'];combined=sweep(joint,fixed);assert combined==data['combined_area_upper_um2'];short=load(STOCK/'stock-and-inventory.json')['short_area_upper_um2'];bc=areas['bracket']//(39999*10**6);ic=areas['insert']//(19799*10**6);feasible_short={(b,i) for b in range(13) for i in range(min(21,(short-b*39999*10**6)//(19799*10**6))+1)};splits=load(BASE/'whole-part-splits.json');assert [(r['short_brackets'],r['short_inserts']) for r in splits]==[(b,i) for b in range(13) for i in range(22)];remaining=[]
for r in splits:
    b,i=r['short_brackets'],r['short_inserts'];reasons=[]
    if (b,i) not in feasible_short:reasons.append('short_area')
    if 12-b>bc:reasons.append('first_bracket_capacity')
    if 21-i>ic:reasons.append('first_insert_capacity')
    if ((12-b)*39999+(21-i)*19799)*10**6>combined:reasons.append('first_combined_area')
    assert r['failure_reasons']==reasons and r['necessary_conditions_pass']==(not reasons)
    if not reasons:remaining.append(r)
required=(12*39999+21*19799)*10**6;prepared=load(BASE/'checks.json');assert prepared['necessary_splits_remaining']==len(remaining) and prepared['provisional_fixed_first33_excluded']==(not remaining);assert prepared['combined_area_deficit_mm2']==(required-short-combined)/1e6;process=load(ROOT/'output/h5-one-roof-all-cogs-process-20261107/process.json');assert process['passed'] and process['closed'];charge=plan['inherited_numeric_preparation_seconds']+process['complete_seconds']
write(OUT/'remaining-splits.json',remaining);write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-began,'fixed_first33_source_valid':True,'same_sheet_pairs':fresh['same_sheet_pairs'],'original_holes':sum(len(parts[r['part_id']]['geometry'][0]['holes']) for r in rows),'continuous_classes_verified':int(classes),'retained_zero_conflict_classes':retained,'exact_union_difference_areas_verified':3,'whole_part_splits_verified':286,'first_bracket_capacity_upper':bc,'first_insert_capacity_upper':ic,'first_companion_area_upper_mm2':combined/1e6,'combined_inventory_deficit_mm2':(required-short-combined)/1e6,'necessary_splits_remaining':len(remaining),'exact_fixed_first33_excluded':not remaining,'complete_preparation_seconds_if_consumed':charge,'whole_allocations_excluded':0,'whole_orientation_classes_excluded':0,'optimizer_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
