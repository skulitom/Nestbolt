"""Reconstruct the isolated policy and verify prior tests and unrelated runtime."""
from pathlib import Path
from hashlib import sha256
import difflib,json,re,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-repair-probe-20261018'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(probe/'policy-preparation.json');old=Path(plan['old_probe']);rel='crates/core/src/sheets/vstrip/exchange.rs'
initial=(probe/'initial-witness/exchange.rs').read_text(encoding='utf-8')
after=(probe/'candidate'/rel).read_text(encoding='utf-8');marker='#[cfg(test)]\nmod tests'
old_tests=initial.split(marker,1)[1];current_tests=after.split(marker,1)[1]
assert current_tests.startswith(old_tests[:old_tests.rindex('\n}')])
assert after.count('#[test]')==initial.count('#[test]')+8
def function(text,name):
 m=re.search(r'(?m)^(?:    )?(?:pub\(super\) )?fn '+name+r'\(',text);assert m,name
 start=text.index('{',m.start());depth=0
 for i in range(start,len(text)):
  depth+=(text[i]=='{')-(text[i]=='}')
  if depth==0:return text[m.start():i+1]
 raise AssertionError(name)
before_runtime=initial.split(marker,1)[0];after_runtime=after.split(marker,1)[0]
names=re.findall(r'(?m)^(?:    )?(?:pub\(super\) )?fn (\w+)\(',before_runtime)
unchanged=[]
for name in names:
 if name not in ['assignment_bridge_chain','directed_exchange_policy']:
  assert function(before_runtime,name)==function(after_runtime,name),name;unchanged.append(name)
# Every old test and runtime line was intact before the new policy, apart from
# the explicit old-behavior contract adapter placed immediately before it.
red=(probe/'before-joint-repair'/rel).read_text(encoding='utf-8');runtime=red.split(marker,1)[0]
a=runtime.index('    pub(super) fn joint_exchange_window(');b=runtime.index('    pub(super) fn assignment_bridge_window(',a)
assert runtime[:a]+runtime[b:]==before_runtime
caller='crates/core/src/sheets/vstrip.rs'
assert (probe/'candidate'/caller).read_text(encoding='utf-8').replace('self.joint_exchange_window(','self.assignment_bridge_window(')==(old/'candidate'/caller).read_text(encoding='utf-8')
stats='crates/core/src/sheets.rs';s=(probe/'candidate'/stats).read_text(encoding='utf-8')
for name in load(probe/'red-preparation.json')['stats_fields']:
 needle='    #[serde(skip_serializing_if = "is_zero")]\n    pub '+name+': u64,\n';assert s.count(needle)==1;s=s.replace(needle,'')
assert s==(old/'candidate'/stats).read_text(encoding='utf-8')
rebuild=root/'output/h5-joint-repair-saved-fixture-reconstruction-20261018';shutil.copytree(probe/'candidate',rebuild)
for name in [rel,stats]:shutil.copyfile(probe/'before-joint-repair'/name,rebuild/name)
shutil.copyfile(old/'candidate'/caller,rebuild/caller)
s=(rebuild/rel).read_text(encoding='utf-8')
for a,b in load(probe/'implementation-substitutions.json'):
 assert s.count(a)==1;s=s.replace(a,b)
(rebuild/rel).write_text(s,encoding='utf-8',newline='\n')
p=rebuild/caller;s=p.read_text(encoding='utf-8');assert s.count('self.assignment_bridge_window(')==1
p.write_text(s.replace('self.assignment_bridge_window(','self.joint_exchange_window('),encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=rebuild,check=True)
p=rebuild/rel;s=p.read_text(encoding='utf-8');a,b=load(probe/'lowering-substitution.json')
assert s.count(a)==1;s=s.replace(a,b);p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=rebuild,check=True)
p=rebuild/rel;s=p.read_text(encoding='utf-8');a,b=load(probe/'rollback-fixture-substitution.json')
assert s.count(a)==1;s=s.replace(a,b);p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=rebuild,check=True)
reconstructed={p.relative_to(rebuild).as_posix():digest(p) for p in rebuild.rglob('*') if p.is_file()}
current={p.relative_to(probe/'candidate').as_posix():digest(p) for p in (probe/'candidate').rglob('*') if p.is_file()}
assert reconstructed==current
assert set(current)=={r['path'] for r in plan['old_source_files']['candidate']}|set(plan['added_files'])
for name,expected in plan['added_files'].items():assert current[name]==expected
fixture=load(probe/'rollback-fixture-provenance.json')
assert current[fixture['fixture']]==fixture['sha256']
old_log=(probe/'before-rollback-fixture-correction/core-tests.log').read_text(encoding='utf-8')
rows=[json.loads(line.split('JOINT_POLICY_WITNESS ',1)[1]) for line in old_log.splitlines() if 'JOINT_POLICY_WITNESS ' in line]
rows=[r for r in rows if r['mode']==3];assert len(rows)==1
assert load(probe/'candidate'/fixture['fixture'])==rows[0]['after']
unchanged_files=0
for arm,rows in plan['old_source_files'].items():
 for r in rows:
  assert digest(old/arm/r['path'])==r['sha256']
  if not(arm=='candidate' and r['path'] in plan['changed_files']):
   assert digest(probe/arm/r['path'])==r['sha256']
   if arm=='candidate':unchanged_files+=1
sys.path.insert(0,str(root/'scripts'));from h2_import_audit import source_digest
assert source_digest()==plan['production_digest']
patch=''
for name in plan['changed_files']:
 patch+=''.join(difflib.unified_diff((old/'candidate'/name).read_text(encoding='utf-8').splitlines(True),
    (probe/'candidate'/name).read_text(encoding='utf-8').splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(probe/'candidate.patch').write_text(patch,encoding='utf-8',newline='\n')
record={'all_checks_passed':True,'all_157_prior_test_bodies_unchanged':True,'new_policy_tests':8,
 'unchanged_runtime_functions':unchanged,'reconstructed_source_files':len(current),'all_formatted_files_reconstruct_exactly':True,
 'unchanged_other_candidate_files':unchanged_files,'caller_change_only':True,'new_stats_zero_omitted':True,
 'production_unchanged':True,'source_sha256':current,'runtime_review':[
 'Original short phase and per-step nonjoint repair order remain.',
 'Shared provisional loop selects policy and restores joint accepted count with its existing checkpoint.',
 'Joint repair uses only the selected two inventories, with original item models and cropped source container.',
 'Both reconstructed single-sheet outputs are checked; thin blocker omission cannot authorize a taller source.',
 'Existing bounded free-pose sampling lowers source members after both exact output containers validate; orientation/reflection and the deadline remain.',
 'Original whole-job geometry/material acceptance and deadline check remain after repair.',
 'Completed pair repair is diagnostic; joint_exchanges counts only committed accepted steps after rollback.']}
(probe/'source-checks.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(__file__,probe/'check-source.py')
print(json.dumps({k:v for k,v in record.items() if k not in ['source_sha256','runtime_review','unchanged_runtime_functions']}))
