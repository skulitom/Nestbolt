"""Independently validate actual joint repairs and transactional policy outputs."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math,shutil,subprocess
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-repair-probe-20261018'
out=probe/'joint-checks';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(probe/'build.json')['all_checks_passed'];out.mkdir()
log=(probe/'core-tests.log').read_text(encoding='utf-8');assert '165 passed; 0 failed' in log
def captured(text,marker):return [json.loads(s.split(marker,1)[1]) for s in text.splitlines() if marker in s]
pair_rows=captured(log,'JOINT_PAIR_WITNESS ');policy_rows=captured(log,'JOINT_POLICY_WITNESS ')
assert len(pair_rows)==8 and len(policy_rows)==8
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
records=[];pairs=0
for index,(kind,row) in enumerate([('pair',r) for r in pair_rows]+[('policy',r) for r in policy_rows]):
 folder=out/f'case-{index}';folder.mkdir();write(folder/'witness.json',row);write(folder/'job.json',row['job'])
 parts={p['id']:p for p in row['job']['parts']};metrics={}
 for side in ['before','after']:
  write(folder/(side+'.json'),row[side]);args=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/(side+'.json'))]
  result=subprocess.run(args,capture_output=True,timeout=60)
  (folder/(side+'-stdout.json')).write_bytes(result.stdout);(folder/(side+'-stderr.log')).write_bytes(result.stderr)
  write(folder/(side+'-command.json'),{'command':args,'exit_code':result.returncode})
  report=json.loads(result.stdout);assert result.returncode==0 and report['valid'];metrics[side]=report['metrics']['material_area']
  layout=row[side];assert Counter(p['part_id'] for p in layout['placements'])==Counter({p['id']:p['quantity'] for p in parts.values()})
  assert len({(p['part_id'],p['copy_index']) for p in layout['placements']})==len(layout['placements'])
  shapes=[]
  for p in layout['placements']:
   t=p['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
   def tr(v):return(m*c*v[0]-s*v[1]+t['translation'][0],m*s*v[0]+c*v[1]+t['translation'][1])
   for g in parts[p['part_id']]['geometry']:
    polygon=Polygon([tr(v) for v in g['outer']]);assert polygon.is_valid
    for sheet,other in shapes:
     if sheet==p['sheet_id']:
      pairs+=1;assert polygon.disjoint(other) and polygon.distance(other)+1e-7>=row['job']['clearance']
    shapes.append((p['sheet_id'],polygon))
 stats=row['stats'];counts={k:stats.get(k,0) for k in ['joint_repair_attempts','joint_repair_completed','joint_repair_failed','joint_repair_expired','joint_exchanges']}
 assert all(type(v)is int and v>=0 for v in counts.values())
 attempted,completed,failed,expired,accepted=counts.values();assert attempted==completed+failed+expired
 assert accepted<=completed
 assert metrics['after']<=metrics['before']
 if kind=='pair':
  assert counts['joint_exchanges']==0 # component repair never accepts the whole job
  if row['success']:
   assert completed==1 and row['finished']<row['until'] and metrics['after']<metrics['before']
   assert next(p for p in row['after']['placements'] if p['part_id']=='extra')['sheet_id']=='sheet-1'
  else:assert row['before']==row['after'] and completed==0
  last=row['before']['sheets'][-1]['id']
  for sheet in row['before']['sheets']:
   if sheet['id'] in ['sheet-1',last]:continue
   assert [p for p in row['before']['placements'] if p['sheet_id']==sheet['id']]==[p for p in row['after']['placements'] if p['sheet_id']==sheet['id']]
 else:
  total=stats.get('assignment_bridge_steps',0);committed=stats.get('assignment_bridge_committed',0);rolled=stats.get('assignment_bridge_rolled_back',0)
  assert total==committed+rolled and total<=completed and stats.get('assignment_bridge_flat_steps',0)<=total
  assert accepted==committed<=stats.get('extended_exchanges',0)<=stats.get('directed_exchanges',0)
  assert row['moved']==stats.get('directed_exchanges',0) and 0<=row['moved']<=4
  if not row['moved']:assert row['before']==row['after']
  if row['mode'] in [1,3]:
   assert row['moved']==committed
   if committed:assert metrics['after']<metrics['before']
  if row['mode']==2:assert row['after']==row['fast_layout'] and attempted==total==accepted==0
  if row['mode']==3:assert total==rolled==1 and accepted==0
 records.append({'case':index,'kind':kind,'job':row['job']['name'],'metrics':metrics,'counts':counts,
                 'mode':row.get('mode'),'success':row.get('success'),'moved':row.get('moved'),
                 'finished':row['finished'],'until':row['until'],'bridge_rolled_back':stats.get('assignment_bridge_rolled_back',0)})
assert sum(r['success']is True for r in records)==3
assert any(r['counts']['joint_repair_expired']>0 for r in records)
assert any(r['kind']=='policy' and r['bridge_rolled_back']>0 and r['counts']['joint_exchanges']==0 for r in records)
old=Path(load(probe/'policy-preparation.json')['old_probe']);old_log=(old/'core-tests.log').read_text(encoding='utf-8')
markers=['EXTENDED_REPAIR_WITNESS ','CHAIN_WITNESS ','PROFILE_REJECT_WITNESS ','CONTINUOUS_REPAIR_WITNESS ',
         'LARGER_RETURN_WITNESS ','MIXED_WITNESS ','BRIDGE_STEP_WITNESS ','BRIDGE_MANUAL_WITNESS ','BRIDGE_RESULT_WITNESS ']
retained=[]
for marker in markers:
 before=Counter(json.dumps(r,sort_keys=True) for r in captured(old_log,marker));after=Counter(json.dumps(r,sort_keys=True) for r in captured(log,marker))
 assert before and not(before-after),(marker,'prior witness changed')
 retained.append({'marker':marker,'old_outcomes_exact':sum(before.values()),'new_additional_outcomes':sum(after.values())-sum(before.values())})
initial=(probe/'initial-witness/witness.log').read_text(encoding='utf-8')
for marker in ['JOINT_REPAIR_SOURCE_WITNESS ','JOINT_REPAIR_WITNESS ']:assert captured(initial,marker)==captured(log,marker)
refs={str(p.relative_to(root)):digest(p) for p in [old/'bridge-checks/checks.json',old/'initial-geometry/checks.json',probe/'initial-geometry/checks.json']}
record={'all_checks_passed':True,'saved_joint_pair_outcomes':len(pair_rows),'saved_joint_policy_outcomes':len(policy_rows),
 'public_CLI_checks':2*len(records),'filled_outer_pairs':pairs,'actual_extra_migration_observed':True,'nonadjacent_fixed_middle_preserved':True,
 'failed_expired_and_thin_crop_proposals_keep_incumbents':True,'provisional_joint_accepts_roll_back':True,
 'prior_witnesses_retained_exactly':retained,'prior_independent_checks_reused_only_for_exact_witnesses':refs,
 'CLI_sha256':expected,'core_log_sha256':digest(probe/'core-tests.log'),'records':records,'new_searches':0,'quality_claim':False}
write(out/'checks.json',record);shutil.copyfile(__file__,out/'check.py')
print(json.dumps({k:record[k] for k in ['saved_joint_pair_outcomes','saved_joint_policy_outcomes','public_CLI_checks','filled_outer_pairs']}))
