"""Check filled outer rings for every saved common-mode public replay."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import itertools,json,math,shutil
from shapely.geometry import Polygon
from shapely.affinity import affine_transform
import shapely
root=Path(__file__).resolve().parents[1];out=root/'output/h5-joint-repair-probe-20261018/public-checks'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert load(out/'checks.json')['all_checks_passed']
folders=sorted(p for p in out.iterdir() if p.is_dir() and '-common-' in p.name and not p.name.endswith('-cli'))
assert len(folders)==6
records=[];holes=0;attempts=0
for folder in folders:
 job=load(folder/'job.json');layout=load(folder/'layout.json');search=load(folder/'search.json')
 assert search['validation']['valid'] and search['riders']==0
 if folder.name.startswith('candidate-'):attempts+=search['stats'].get('joint_repair_attempts',0)
 parts={p['id']:p for p in job['parts']};holes+=sum(len(g['holes']) for p in parts.values() for g in p['geometry'])
 assert Counter(p['part_id'] for p in layout['placements'])==Counter({p['id']:p['quantity'] for p in parts.values()})
 shapes={};pairs=0;minimum=math.inf
 for p in layout['placements']:
  assert len(parts[p['part_id']]['geometry'])==1
  polygon=Polygon(parts[p['part_id']]['geometry'][0]['outer']);assert polygon.is_valid
  t=p['transform'];c=math.cos(t['rotation_radians']);s=math.sin(t['rotation_radians']);m=-1 if t['mirrored'] else 1
  polygon=affine_transform(polygon,[m*c,-s,m*s,c,*t['translation']]);assert polygon.is_valid
  shapes.setdefault(p['sheet_id'],[]).append(polygon)
 for group in shapes.values():
  for a,b in itertools.combinations(group,2):
   pairs+=1;assert a.disjoint(b)
   slack=a.distance(b)-job['clearance'];minimum=min(minimum,slack);assert slack>=-1e-7
 records.append({'folder':folder.name,'job_sha256':digest(folder/'job.json'),'layout_sha256':digest(folder/'layout.json'),
    'same_sheet_pairs':pairs,'minimum_clearance_slack_mm':minimum})
assert holes>0 and attempts>0,'Public check must include actual holes and reach joint repair'
record={'all_checks_passed':True,'common_outcomes':len(records),'filled_outer_pairs':sum(r['same_sheet_pairs'] for r in records),
 'minimum_clearance_slack_mm':min(r['minimum_clearance_slack_mm'] for r in records),'absolute_tolerance_mm':1e-7,
 'source_holes_present':True,'candidate_joint_repair_attempts_including_replays':attempts,
 'holes_reserved':True,'shapely_version':shapely.__version__,'records':records,'new_searches':0,'quality_claim':False}
with (out/'filled-outer-audit.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
shutil.copyfile(__file__,out/'audit-filled-outers.py')
print(json.dumps({k:v for k,v in record.items() if k not in ['records']}))
