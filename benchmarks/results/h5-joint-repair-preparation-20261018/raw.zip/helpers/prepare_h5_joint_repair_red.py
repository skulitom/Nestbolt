"""Add joint-repair contracts against old independent-repair behavior first."""
from pathlib import Path
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-repair-probe-20261018'
assert json.loads((probe/'initial-geometry/checks.json').read_bytes())['actual_useful_joint_repair_observed']
rel='crates/core/src/sheets/vstrip/exchange.rs';p=probe/'candidate'/rel;s=p.read_text(encoding='utf-8')
stub='''    pub(super) fn joint_exchange_window(&mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,short_until:f64,until:f64)->Result<usize> {
        self.assignment_bridge_window(strip,frozen,sep,shape,short_until,until)
    }
    fn joint_exchange_chain(&mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,until:f64,accepted:usize)->Result<usize> {
        self.assignment_bridge_chain(strip,frozen,sep,shape,until,accepted)
    }
    fn joint_repair_pair(&mut self,strip:&Strip,receiver:JLayout,source:JLayout,_last:f32,
        until:f64)->Result<Option<[LayoutSnapshot;2]>> {
        if !self.allow_exchange || self.clock.now()>=self.last_step(until) {return Ok(None);}
        self.stats.joint_repair_attempts+=1;
        let now=self.clock.now();let pair_end=now+((self.last_step(until)-now)*0.5).min(0.4);
        let mut receiver=Separator::new(receiver,self.rng.next_u64(),EXPLORE,strip.clock.clone());
        let (a,at)=receiver.separate(&self.deadline((now+pair_end)/2.0));
        let mut source=Separator::new(source,self.rng.next_u64(),EXPLORE,strip.clock.clone());
        let (b,bt)=source.separate(&self.deadline(self.last_step(until)));
        if self.clock.now()>=self.last_step(until) {self.stats.joint_repair_expired+=1;return Ok(None);}
        if at.total_loss()>0.0 || bt.total_loss()>0.0 {self.stats.joint_repair_failed+=1;return Ok(None);}
        self.stats.joint_repair_completed+=1;Ok(Some([a,b]))
    }

'''
needle='    pub(super) fn assignment_bridge_window('
assert s.count(needle)==1;s=s.replace(needle,stub+needle)
a=s.index('    fn assignment_bridge_exercise(');b=s.index('    // BEGIN assignment-bridge new policy tests',a)
helper=s[a:b].replace('fn assignment_bridge_exercise(','fn joint_policy_exercise(')
helper=helper.replace('.assignment_bridge_window(','.joint_exchange_window(').replace('.assignment_bridge_chain(','.joint_exchange_chain(')
helper=helper.replace('"BRIDGE_RESULT_WITNESS {}"','"JOINT_POLICY_WITNESS {}"')
tests=r'''
    // BEGIN joint-repair policy tests
    fn joint_fixture(middle:bool)->(Job,Layout,Layout) {
        let (mut job,mut layout)=fixture();
        job.name="Joint repair contract".into();
        job.parts=vec![rectangle("prefix",96.0,94.0),rectangle("filler",20.0,94.0),
            rectangle("return",60.0,85.0),rectangle("incoming",30.0,94.0),rectangle("extra",40.0,50.0)];
        let last=if middle {3} else {2};
        layout.sheets=(0..=last).map(|i|Sheet{id:format!("sheet-{i}"),stock_id:"stock".into()}).collect();
        layout.placements=[("prefix",0,[2.0,2.0]),("filler",1,[78.0,2.0]),("return",1,[2.0,2.0]),
            ("incoming",last,[2.0,2.0]),("extra",last,[34.0,2.0])].into_iter().map(|(id,sheet,translation)|Placement {
                part_id:id.into(),copy_index:0,sheet_id:format!("sheet-{sheet}"),
                transform:RigidTransform{translation,..Default::default()}}).collect();
        if middle {
            job.parts.push(rectangle("middle",96.0,94.0));
            layout.placements.push(Placement{part_id:"middle".into(),copy_index:0,sheet_id:"sheet-2".into(),
                transform:RigidTransform{translation:[2.0,2.0],..Default::default()}});
        }
        assert!(validate(&job,&layout).unwrap().valid);
        let mut proposal=layout.clone();
        for p in &mut proposal.placements {
            if p.part_id=="incoming" {p.sheet_id="sheet-1".into();}
            if p.part_id=="return" {p.sheet_id=format!("sheet-{last}");}
        }
        (job,layout,proposal)
    }
    #[derive(Clone,Copy)]
    struct JointProbe {enabled:bool,budget:f64,last:Option<f32>}
    impl Default for JointProbe {
        fn default()->Self {Self{enabled:true,budget:12.0,last:None}}
    }
    fn joint_pair_exercise(job:&Job,layout:&Layout,proposal:&Layout,options:JointProbe)->(bool,Layout,Stats) {
        let report=validate(job,layout).unwrap();assert!(report.valid);
        let model=Model::new(job).unwrap();let clock=Clock::new(Timing::Work,60.0);
        let mut search=Search {model:&model,allow_exchange:options.enabled,rng:Xoshiro256PlusPlus::seed_from_u64(0),
            clock:clock.clone(),best:(layout.clone(),report,0.0),history:vec![],stats:Stats::default(),
            progress:|_:&Progress,_:&dyn Fn()->Option<Layout>|{},check_cost:0.0,check_every:5.0};
        let strip=Strip {model:&model,gap:2.0,clock:clock.clone(),containers:Default::default()};
        let sheets=model.sheets_of(layout).unwrap();let proposed=model.sheets_of(proposal).unwrap();
        let (frozen,window)=sheets.split_at(1);let mut shape=Shape{sheets:window.len(),last:model.full_width};
        let whole=strip.layout(window,shape).unwrap();shape.last=strip.fit_last(&whole,shape);
        let before=search.exchange_layout(&strip,frozen,&whole,shape).unwrap();
        let original=fingerprint(&whole);let last=options.last.unwrap_or(shape.last);
        let receiver=JLayout::from_snapshot(&proposed[1].layout().save());
        let source=JLayout::from_snapshot(&proposed.last().unwrap().layout().save());
        let until=if options.budget<=0.0 {0.0} else {clock.now()+options.budget};
        let repaired=search.joint_repair_pair(&strip,receiver,source,last,until).unwrap();
        let mut trial=JLayout::from_snapshot(&whole.save());
        let success=repaired.is_some();
        if let Some(snapshots)=repaired {
            let keys:Vec<_>=trial.placed_items().iter().filter(|(_,p)|!strip.is_blocker(p) &&
                [0,shape.sheets-1].contains(&strip.sheet_of(p.shape()))).map(|(k,_)|k).collect();
            for key in keys {trial.remove_item(key);}
            for (snapshot,index) in snapshots.into_iter().zip([0,shape.sheets-1]) {
                let local=JLayout::from_snapshot(&snapshot);
                for p in local.placed_items().values() {trial.place_item(p.item(),shift(p.d_transf(),strip.start(index)));}
            }
        } else {assert_eq!(fingerprint(&trial),original);}
        assert_eq!(fingerprint(&whole),original,"Helper cannot mutate the incumbent");
        let after=search.exchange_layout(&strip,frozen,&trial,shape).unwrap();
        let after_report=validate(job,&after).unwrap();
        eprintln!("JOINT_PAIR_WITNESS {}",serde_json::json!({"job":job,"before":before,"proposal":proposal,
            "after":after,"success":success,"enabled":options.enabled,"budget":options.budget,"source_last":last,
            "until":until,"finished":clock.now(),"valid":after_report.valid,"stats":search.stats,"work":clock.counts()}));
        assert!(after_report.valid);
        for i in 0..sheets.len() {
            if i==1 || i==sheets.len()-1 {continue;}
            let id=format!("sheet-{i}");
            assert_eq!(serde_json::to_value(before.placements.iter().filter(|p|p.sheet_id==id).collect::<Vec<_>>()).unwrap(),
                serde_json::to_value(after.placements.iter().filter(|p|p.sheet_id==id).collect::<Vec<_>>()).unwrap());
        }
        (success,after,search.stats)
    }
    #[test]
    fn joint_new_pair_moves_extra_member_and_replays() {
        let (job,before,proposal)=joint_fixture(false);
        let (ok,after,stats)=joint_pair_exercise(&job,&before,&proposal,JointProbe::default());
        assert!(ok,"Joint helper must repair the impossible fixed source assignment");
        assert_eq!(stats.joint_repair_completed,1);
        assert_eq!(after.placements.iter().find(|p|p.part_id=="extra").unwrap().sheet_id,"sheet-1");
        assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area<29000.0);
        let (again,replay,replay_stats)=joint_pair_exercise(&job,&before,&proposal,JointProbe::default());
        assert!(again);assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(replay).unwrap());
        assert_eq!(serde_json::to_value(stats).unwrap(),serde_json::to_value(replay_stats).unwrap());
    }
    #[test]
    fn joint_new_nonadjacent_pair_preserves_middle_and_prefix() {
        let (job,before,proposal)=joint_fixture(true);
        let (ok,after,_)=joint_pair_exercise(&job,&before,&proposal,JointProbe::default());
        assert!(ok,"Selected nonadjacent sheets must be repaired together");
        assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area<39000.0);
    }
    #[test]
    fn joint_new_failed_cropped_pair_keeps_incumbent() {
        let (job,before,proposal)=joint_fixture(false);
        let (ok,_,stats)=joint_pair_exercise(&job,&before,&proposal,JointProbe{last:Some(10.0),..Default::default()});
        assert!(!ok);assert_eq!(stats.joint_repair_completed,0);
        assert_eq!(stats.joint_repair_attempts,stats.joint_repair_failed+stats.joint_repair_expired);
    }
    #[test]
    fn joint_new_disabled_expired_and_construction_expiry_do_not_publish() {
        let (job,before,proposal)=joint_fixture(false);
        for options in [JointProbe{enabled:false,..Default::default()},JointProbe{budget:0.0,..Default::default()},
            JointProbe{budget:1e-9,..Default::default()}] {
            let (ok,_,stats)=joint_pair_exercise(&job,&before,&proposal,options);
            assert!(!ok);assert_eq!(stats.joint_repair_completed,0);
        }
    }
    #[test]
    fn joint_new_short_sliver_still_enforces_the_cropped_source() {
        let (job,mut before,_)=joint_fixture(false);
        before.placements.iter_mut().find(|p|p.part_id=="incoming").unwrap().transform.translation[1]=4.8;
        assert!(validate(&job,&before).unwrap().valid);
        let model=Model::new(&job).unwrap();let sheets=model.sheets_of(&before).unwrap();
        let last=sheets.last().unwrap().layout().placed_items().values().map(|p|p.shape().bbox().x_max)
            .fold(0.0_f32,f32::max)-0.05;
        assert!(model.full_width-last<0.01*model.instance.base_strip.fixed_height);
        let (ok,_,stats)=joint_pair_exercise(&job,&before,&before,JointProbe{last:Some(last),..Default::default()});
        assert!(!ok,"No blocker sliver must not mean unrestricted source height");
        assert_eq!(stats.joint_repair_completed,0);assert_eq!(stats.joint_repair_failed,1);
    }
    #[test]
    fn joint_new_policy_accepts_valid_improvement_and_replays() {
        let (job,before)=fixture();
        let (moved,after,stats)=joint_policy_exercise(&job,&before,0,true,(0.0,12.0,1),0);
        assert!(moved>0);assert!(stats.joint_exchanges>0,"Whole-job acceptance must use joint repair");
        assert!(validate(&job,&after).unwrap().metrics.unwrap().material_area<19000.0);
        let (again,replay,replay_stats)=joint_policy_exercise(&job,&before,0,true,(0.0,12.0,1),0);
        assert_eq!(moved,again);assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(replay).unwrap());
        assert_eq!(serde_json::to_value(stats).unwrap(),serde_json::to_value(replay_stats).unwrap());
    }
    #[test]
    fn joint_new_flat_partial_sequences_restore_acceptance_counts() {
        let (job,before)=assignment_bridge_fixture();
        let (moved,_,stats)=joint_policy_exercise(&job,&before,0,true,(0.0,12.0,3),0);
        assert_eq!(moved,0);assert_eq!(stats.directed_exchanges,0);assert_eq!(stats.joint_exchanges,0);
        assert!(stats.assignment_bridge_rolled_back>0,"Actual provisional joint step must roll back");
        assert!(stats.joint_repair_completed>0,"Rollback must follow actual joint repair");
    }
    #[test]
    fn joint_new_policy_preserves_fast_phase_and_deadline_guards() {
        for (job,before,seed) in [ {let(a,b)=larger_return_fixture();(a,b,3)},
            {let(a,b)=mixed_fixture();(a,b,0)}] {
            let (fast,baseline,_)=chain_exercise(&job,&before,seed,true,3.0,0);
            assert!(fast>0);
            let (moved,after,stats)=joint_policy_exercise(&job,&before,seed,true,(3.0,5.0,2),0);
            assert_eq!(moved,fast);assert_eq!(serde_json::to_value(after).unwrap(),serde_json::to_value(baseline).unwrap());
            assert_eq!(stats.joint_repair_attempts,0);
        }
        let (job,before)=fixture();
        for (enabled,budget) in [(false,5.0),(true,0.0),(true,1e-9)] {
            let (moved,_,stats)=joint_policy_exercise(&job,&before,0,enabled,(0.0,budget,1),0);
            assert_eq!(moved,0);assert_eq!(stats.joint_exchanges,0);
        }
    }
    // END joint-repair policy tests
'''
pos=s.rindex('\n}');s=s[:pos]+'\n'+helper+tests+s[pos:];p.write_text(s,encoding='utf-8',newline='\n')
stats=probe/'candidate/crates/core/src/sheets.rs';s=stats.read_text(encoding='utf-8');needle='    pub assignment_bridge_rollbacks: u64,\n';assert s.count(needle)==1
fields=['joint_repair_attempts','joint_repair_completed','joint_repair_failed','joint_repair_expired','joint_exchanges']
s=s.replace(needle,needle+''.join('    #[serde(skip_serializing_if = "is_zero")]\n    pub '+n+': u64,\n' for n in fields));stats.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=probe/'candidate',check=True)
record={'prior_tests_unchanged':157,'new_policy_tests':8,'stub':'Original independent receiver/source repair; whole policy delegates to preceding bridge policy.',
 'changed_files':[rel,'crates/core/src/sheets.rs'],'stats_fields':fields,'expected_contract_failures':['positive joint pair','nonadjacent joint pair','short-sliver crop guard','whole-policy joint acceptance','joint rollback counters']}
(probe/'red-preparation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(__file__,probe/'prepare-red.py')
print(json.dumps(record))
