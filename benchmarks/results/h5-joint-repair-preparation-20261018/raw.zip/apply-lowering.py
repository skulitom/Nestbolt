"""Use already-qualified free poses after joint repair frees source space."""
from pathlib import Path
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-repair-probe-20261018'
assert json.loads((probe/'before-source-lowering/failure.json').read_bytes())['native_tests_failed']==2
p=probe/'candidate/crates/core/src/sheets/vstrip/exchange.rs';s=p.read_text(encoding='utf-8')
needle='        self.stats.joint_repair_completed += 1;\n        Ok(Some([receiver.layout.save(), source.layout.save()]))'
replacement='''        // Repair can migrate an obstruction yet leave a source part raised.
        // With both output inventories already valid in their exact containers,
        // lower source members into free space without changing their poses'
        // rotation/reflection, membership or the original phase deadline.
        let mut source = source;
        let mut keys: Vec<_> = source.layout.placed_items().keys().collect();
        rank_incoming(&source.layout, &mut keys);
        for key in keys {
            if self.clock.now() >= self.last_step(until) { break; }
            let placed = source.layout.remove_item(key);
            let item = placed.item().clone();
            let pose = free_return_pose(&source.layout,&item,placed.d_transf(),&self.clock,self.last_step(until));
            source.layout.place_item(&item,pose);
            self.clock.charge(Work::RegisteredItem,2.0);
        }
        source.rebuild();
        if self.clock.now() >= self.last_step(until) {
            self.stats.joint_repair_expired += 1; return Ok(None);
        }
        if source.tracker.total_loss() > 0.0 {
            self.stats.joint_repair_failed += 1; return Ok(None);
        }
        self.stats.joint_repair_completed += 1;
        Ok(Some([receiver.layout.save(), source.layout.save()]))'''
assert s.count(needle)==1;s=s.replace(needle,replacement);p.write_text(s,encoding='utf-8',newline='\n')
(probe/'lowering-substitution.json').write_text(json.dumps([needle,replacement],indent=2)+'\n',encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=probe/'candidate',check=True)
shutil.copyfile(__file__,probe/'apply-lowering.py')
print('Added bounded source lowering after both cropped outputs validate; all tests unchanged.')
