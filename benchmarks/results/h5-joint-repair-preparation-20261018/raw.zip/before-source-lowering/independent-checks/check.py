"""Validate both saved failed-target repairs without repeating search."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math,subprocess,shutil
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-repair-probe-20261018'
old=probe/'before-source-lowering';out=old/'independent-checks';out.mkdir()
digest=lambda p:sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_bytes())
assert digest(old/'core-tests.log')==load(old/'failure.json')['log_sha256']
rows=[json.loads(s.split('JOINT_PAIR_WITNESS ',1)[1]) for s in (old/'core-tests.log').read_text(encoding='utf-8').splitlines() if 'JOINT_PAIR_WITNESS ' in s]
rows=[r for r in rows if r['success']];assert len(rows)==2
cli=root/'target/release/nestbolt.exe';expected='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b';assert digest(cli)==expected
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
records=[];pairs=0
for i,r in enumerate(rows):
 folder=out/f'case-{i}';folder.mkdir();write(folder/'witness.json',r);write(folder/'job.json',r['job'])
 metrics={};parts={p['id']:p for p in r['job']['parts']}
 for side in ['before','after']:
  write(folder/(side+'.json'),r[side]);args=[str(cli),'validate','--job',str(folder/'job.json'),'--layout',str(folder/(side+'.json'))]
  result=subprocess.run(args,capture_output=True,timeout=60)
  (folder/(side+'-stdout.json')).write_bytes(result.stdout);(folder/(side+'-stderr.log')).write_bytes(result.stderr)
  write(folder/(side+'-command.json'),{'command':args,'exit_code':result.returncode})
  report=json.loads(result.stdout);assert result.returncode==0 and report['valid'];metrics[side]=report['metrics']['material_area']
  assert Counter(p['part_id'] for p in r[side]['placements'])==Counter({p['id']:p['quantity'] for p in parts.values()})
  shapes=[]
  for p in r[side]['placements']:
   t=p['transform'];assert t['rotation_radians']==0 and not t['mirrored']
   polygon=Polygon([(x+t['translation'][0],y+t['translation'][1]) for x,y in parts[p['part_id']]['geometry'][0]['outer']]);assert polygon.is_valid
   for sheet,q in shapes:
    if sheet==p['sheet_id']:pairs+=1;assert polygon.disjoint(q) and polygon.distance(q)+1e-7>=r['job']['clearance']
   shapes.append((p['sheet_id'],polygon))
 target=len(r['after']['sheets'])*10000-1000
 assert metrics['before']>metrics['after']>=target
 returned=next(p for p in r['after']['placements'] if p['part_id']=='return')
 extra=next(p for p in r['after']['placements'] if p['part_id']=='extra');assert extra['sheet_id']=='sheet-1'
 for sheet in r['before']['sheets']:
  if sheet['id'] in ['sheet-1',r['before']['sheets'][-1]['id']]:continue
  assert [p for p in r['before']['placements'] if p['sheet_id']==sheet['id']]==[p for p in r['after']['placements'] if p['sheet_id']==sheet['id']]
 records.append({'sheets':len(r['after']['sheets']),'material_mm2':metrics,'failed_test_upper_bound_mm2':target,
    'gain_mm2':metrics['before']-metrics['after'],'source_return_translation':returned['transform']['translation']})
record={'all_saved_layouts_valid':True,'tests_still_fail_original_targets':True,'CLI_checks':4,'filled_outer_pairs':pairs,
 'fixed_prefix_and_middle_exact':True,'no_search_rerun':True,'CLI_sha256':expected,'records':records,
 'diagnosis':'The actual joint repair migrates extra but raises return. Both outputs improve material slightly; neither meets the unchanged new test target. Source free space can be investigated without changing any test assertion.'}
write(out/'checks.json',record);shutil.copyfile(__file__,out/'check.py');print(json.dumps(record))
