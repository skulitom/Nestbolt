"""Use a temporary two-sheet repair in the remaining original exchange allowance."""
from pathlib import Path
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-repair-probe-20261018'
assert json.loads((probe/'before-joint-repair/checks.json').read_bytes())['expected_runtime_failure']
rel='crates/core/src/sheets/vstrip/exchange.rs';p=probe/'candidate'/rel;s=p.read_text(encoding='utf-8')
original=s;substitutions=[]
def replace(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b);substitutions.append([a,b])
replace('    AssignmentBridge,\n','    #[cfg_attr(not(test), allow(dead_code))]\n    AssignmentBridge,\n    JointRepair,\n')
a=s.index('    pub(super) fn joint_exchange_window(');b=s.index('    pub(super) fn assignment_bridge_window(',a)
replace(s[a:b],'''    pub(super) fn joint_exchange_window(
        &mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,short_until:f64,until:f64,
    )->Result<usize> {
        let accepted=self.directed_exchange_chain(strip,frozen,sep,shape,short_until)?;
        let extra=self.joint_exchange_chain(strip,frozen,sep,shape,until,accepted)?;
        Ok(accepted+extra)
    }

    fn joint_exchange_chain(
        &mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,until:f64,accepted:usize,
    )->Result<usize> {
        self.provisional_exchange_chain(strip,frozen,sep,shape,until,(accepted,ExchangePolicy::JointRepair))
    }

    // Repair only these two inventories. Other active sheets are absent from
    // this temporary strip and therefore cannot be moved by collision repair.
    // A proposal selects its initial members, not the final number of movers.
    fn joint_repair_pair(
        &mut self,strip:&Strip,receiver:JLayout,source:JLayout,last:f32,until:f64,
    )->Result<Option<[LayoutSnapshot;2]>> {
        if !self.allow_exchange || self.clock.now()>=self.last_step(until) {return Ok(None);}
        self.stats.joint_repair_attempts+=1;
        let shape=Shape{sheets:2,last};
        let mut trial=JLayout::new(strip.container(shape)?);
        let count=receiver.placed_items().len()+source.placed_items().len();
        for (layout,offset) in [(&receiver,0.0),(&source,strip.start(1))] {
            for p in layout.placed_items().values() {trial.place_item(p.item(),shift(p.d_transf(),offset));}
        }
        self.clock.charge(Work::RegisteredItem,count as f64);
        strip.set_blocker(&mut trial,shape)?;
        let mut repair=Separator::new(trial,self.rng.next_u64(),EXPLORE,self.clock.clone());
        repair.pin(blocker_index(self.model));
        repair.region=Rect::try_new(0.0,0.0,strip.width(shape),strip.height()).ok();
        let (snapshot,tracker)=repair.separate(&self.deadline(self.last_step(until)));
        if self.clock.now()>=self.last_step(until) {self.stats.joint_repair_expired+=1;return Ok(None);}
        if tracker.total_loss()>0.0 {self.stats.joint_repair_failed+=1;return Ok(None);}
        let repaired=JLayout::from_snapshot(&snapshot);
        let mut outputs=[JLayout::new(strip.container(Shape{sheets:1,last:self.model.full_width})?),
            JLayout::new(strip.container(Shape{sheets:1,last})?)];
        for p in repaired.placed_items().values().filter(|p|!strip.is_blocker(p)) {
            let index=strip.sheet_of(p.shape());
            if index>=2 {self.stats.joint_repair_failed+=1;return Ok(None);}
            outputs[index].place_item(p.item(),shift(p.d_transf(),-strip.start(index)));
        }
        self.clock.charge(Work::RegisteredItem,count as f64);
        // A thin end sliver may have no stable blocker. Validate both actual
        // single-sheet containers, including the original source crop, before
        // returning any repair. These constructors charge their geometry work.
        let [receiver,source]=outputs;
        let receiver=Separator::new(receiver,0,EXPLORE,self.clock.clone());
        let source=Separator::new(source,0,EXPLORE,self.clock.clone());
        if self.clock.now()>=self.last_step(until) {self.stats.joint_repair_expired+=1;return Ok(None);}
        if receiver.tracker.total_loss()>0.0 || source.tracker.total_loss()>0.0 {
            self.stats.joint_repair_failed+=1;return Ok(None);
        }
        self.stats.joint_repair_completed+=1;
        Ok(Some([receiver.layout.save(),source.layout.save()]))
    }

    #[cfg(test)]
''')
a=s.index('    fn assignment_bridge_chain(');b=s.index('        if accepted >= 4',a)
replace(s[a:b],'''    #[cfg(test)]
    fn assignment_bridge_chain(
        &mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,until:f64,accepted:usize,
    )->Result<usize> {
        self.provisional_exchange_chain(strip,frozen,sep,shape,until,(accepted,ExchangePolicy::AssignmentBridge))
    }

    fn provisional_exchange_chain(
        &mut self,strip:&Strip,frozen:&[SPProblem],sep:&mut Separator,
        shape:Shape,until:f64,phase:(usize,ExchangePolicy),
    )->Result<usize> {
        let (accepted,policy)=phase;
''')
# The common sequence differs only in selecting the per-step policy and keeping
# the additional accepted counter with the checkpoint. Old paths leave it zero.
a=s.index('    fn provisional_exchange_chain(');b=s.index('    #[cfg(test)]\n    pub(super) fn directed_exchange_window(',a)
old=s[a:b];new=old.replace('ExchangePolicy::AssignmentBridge,','policy,')
new=new.replace('self.stats.extended_exchanges,','self.stats.extended_exchanges,\n                self.stats.joint_exchanges,')
replace(old,new)
replace('        let bridge = policy == ExchangePolicy::AssignmentBridge;',
'''        let bridge = matches!(policy,ExchangePolicy::AssignmentBridge | ExchangePolicy::JointRepair);
        let joint = policy == ExchangePolicy::JointRepair;''')
a=s.index('                    let now = self.clock.now();\n                    // Bound each pair');b=s.index('                    let mut trial = JLayout::from_snapshot(&sep.layout.save());',a)
old=s[a:b]
new='''                    let repaired = if joint {
                        self.joint_repair_pair(strip,next_receiver,next_source,shape.last,exchange_until)?
                    } else {
'''+old+'''                        Some([receiver_snapshot,source_snapshot])
                    };
                    let Some([receiver_snapshot,source_snapshot])=repaired else {continue;};
'''
replace(old,new)
replace('                    self.stats.extended_exchanges += u64::from(extended);',
'''                    self.stats.extended_exchanges += u64::from(extended);
                    self.stats.joint_exchanges += u64::from(joint);''')
p.write_text(s,encoding='utf-8',newline='\n')
caller=probe/'candidate/crates/core/src/sheets/vstrip.rs';c=caller.read_text(encoding='utf-8')
assert c.count('self.assignment_bridge_window(')==1
caller.write_text(c.replace('self.assignment_bridge_window(','self.joint_exchange_window('),encoding='utf-8',newline='\n')
(probe/'implementation-substitutions.json').write_text(json.dumps(substitutions,indent=2)+'\n',encoding='utf-8',newline='\n')
subprocess.run(['cargo','fmt','--all'],cwd=probe/'candidate',check=True)
shutil.copyfile(__file__,probe/'apply.py')
print(json.dumps({'implemented':True,'short_phase_retained':True,'original_budget_retained':True,
 'temporary_two_sheet_repair':True,'original_crop_rechecked':True,'joint_accepted_counter_transactional':True}))
