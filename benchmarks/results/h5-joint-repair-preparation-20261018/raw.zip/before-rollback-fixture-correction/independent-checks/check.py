"""Show that the original new rollback fixture now makes a real strict gain."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,math,shutil,subprocess
from shapely.geometry import Polygon
root=Path(__file__).resolve().parents[1];probe=root/'output/h5-joint-repair-probe-20261018'
old=probe/'before-rollback-fixture-correction';out=old/'independent-checks';out.mkdir()
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert digest(old/'core-tests.log')==load(old/'failure.json')['log_sha256']
rows=[json.loads(s.split('JOINT_POLICY_WITNESS ',1)[1]) for s in (old/'core-tests.log').read_text(encoding='utf-8').splitlines() if 'JOINT_POLICY_WITNESS ' in s]
rows=[r for r in rows if r['mode']==3];assert len(rows)==1;r=rows[0]
cli=root/'target/release/nestbolt.exe';assert digest(cli)=='97de6a34f17760ca30230742e716b3e74940f1a2ede71453ecb3b13bac73dc2b'
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
write(out/'witness.json',r);write(out/'job.json',r['job']);metrics={};pairs=0;parts={p['id']:p for p in r['job']['parts']}
for side in ['before','after']:
 write(out/(side+'.json'),r[side]);args=[str(cli),'validate','--job',str(out/'job.json'),'--layout',str(out/(side+'.json'))]
 result=subprocess.run(args,capture_output=True,timeout=60)
 (out/(side+'-stdout.json')).write_bytes(result.stdout);(out/(side+'-stderr.log')).write_bytes(result.stderr)
 write(out/(side+'-command.json'),{'command':args,'exit_code':result.returncode})
 report=json.loads(result.stdout);assert result.returncode==0 and report['valid'];metrics[side]=report['metrics']['material_area']
 assert Counter(p['part_id'] for p in r[side]['placements'])==Counter({p['id']:p['quantity'] for p in parts.values()})
 shapes=[]
 for p in r[side]['placements']:
  t=p['transform'];assert t['rotation_radians']==0 and not t['mirrored']
  poly=Polygon([(x+t['translation'][0],y+t['translation'][1]) for x,y in parts[p['part_id']]['geometry'][0]['outer']]);assert poly.is_valid
  for sheet,q in shapes:
   if sheet==p['sheet_id']:pairs+=1;assert poly.disjoint(q) and poly.distance(q)+1e-7>=r['job']['clearance']
  shapes.append((p['sheet_id'],poly))
assert metrics['after']<metrics['before'] and r['moved']==r['stats']['joint_exchanges']==1
assert r['stats']['assignment_bridge_committed']==1 and r['stats'].get('assignment_bridge_flat_steps',0)==0
record={'both_saved_layouts_valid':True,'actual_strict_material_gain_confirmed':True,'CLI_checks':2,'filled_outer_pairs':pairs,
 'metrics':metrics,'gain_mm2':metrics['before']-metrics['after'],'no_search_rerun':True,
 'failed_assertion_preserved':True,'diagnosis':'This original new test was no longer flat after source lowering. Its committed gain obeys the policy; a different starting layout is needed to test rollback. No acceptance threshold or assertion is relaxed.'}
write(out/'checks.json',record);shutil.copyfile(__file__,out/'check.py');print(json.dumps(record))
