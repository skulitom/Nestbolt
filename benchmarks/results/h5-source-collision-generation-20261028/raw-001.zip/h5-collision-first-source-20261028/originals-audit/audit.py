"""Re-read saved original rings for the negative diagnostic and rejected full candidate."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-collision-first-source-20261028';OUT=BASE/'originals-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');plan=load(BASE/'plan.json');expected=[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])];summary=[];inputs=[BASE/'plan.json',BASE/'response-audit/checks.json',ROOT/'output/h5-coordinated-placement-selection-20261018/job.json',ROOT/'output/h5_legacy64_source_readback.py']
for name,folder,failures in [('negative-diagnostic',BASE/'colliding66-diagnostic',68),('rejected-candidate',BASE/'search/00',43)]:
    rows=load(folder/'candidate66.json');result=audit(job,rows,plan['source_stocks'],plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected);saved=load(folder/'source-audit.json');assert all(saved[k]==v for k,v in result.items());assert not result['valid'] and result['pair_failures']==failures and result['stock_failures']==0 and result['cutouts']==90 and result['hole_vertices']==10026
    write(OUT/f'{name}.json',result);summary.append({'case':name,'originals':len(rows),'pairs':result['same_sheet_pairs'],'stock_edges':result['stock_edges'],'pair_failures':failures,'stock_failures':0,'holes':90,'hole_vertices':10026,'valid':False});inputs += [folder/'candidate66.json',folder/'source-audit.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'cases':summary,'both_invalid_layouts_preserved':True,'source_valid66_count':0,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
