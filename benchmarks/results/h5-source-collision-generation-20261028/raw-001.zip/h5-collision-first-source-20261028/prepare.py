"""Prepare a distinct collision-first relaxation without changing any closed model."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-mixed25-lazy-source-20261028';BASE=ROOT/'output/h5-collision-first-source-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
BASE.mkdir();(BASE/'model').mkdir();shutil.copyfile(__file__,BASE/'prepare.py')
assert load(OLD/'response-audit/checks.json')['passed'] and load(OLD/'search/result.json')['closed'] and load(OLD/'search/result.json')['reason']=='NO_CANDIDATE_UNKNOWN'
assert load(OLD/'band-capacity-diagnosis/audit/checks.json')['passed']
inputs=[OLD/n for n in ['plan.json','audit/checks.json','capacity-audit/checks.json','model/model.pb','model/mapping.json','model/checks.json','response-audit/checks.json','band-capacity-diagnosis/audit/checks.json']]
inputs += [OLD/n for n in ['remaining25.json','fixed41.json','modes.json','control.json','control-source56.json','mode-inner-rectangles.json','fixed-inner-rectangles-inset.json']]
inputs += sorted((OLD/'free').glob('*.json'))+sorted((OLD/'relative').glob('*.json'))
write(BASE/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'method':'New collision-first generation policy. Remove exactly2942 optional/fixed rectangle intervals and2 cumulative capacity constraints from the closed relaxation, preserving all342 variables, every required-part/free-cell/order constraint and every hint. All25 movers remain mandatory around the same41 source-verified fixed originals. Start with no mover-pair exclusions; full original-source pair/stock/hole validation rejects all collisions and supplies the exposed pairs for complete audited mode-pair cell constraints. Dropping necessary model capacities never relaxes source acceptance. This is a different initial model and policy, not a repeated or continued call.','fixed_originals':41,'mandatory_movers':25,'target_originals':66,'modes':'phase7 cog, all8 bracket quarter/mirror modes, insert0/90: constructive subset only','required_pair_gap_mm':.21170867250963943,'stock_guard_mm':.011444091796875,'source_stocks':{'sheet-0':[6.5,6.5,1493.5,2993.5],'sheet-1':[6.5,6.5,1493.5,319.42690232999934]},'algorithm_seconds':60,'shared_seconds':90,'maximum_distinct_solves':8,'maximum_seconds_per_solve':15,'workers':4,'random_seed':0,'ignore_subsolvers':['fj'],'stop_after_no_candidate_response':True,'no_repeat_identical_model':True,'budget_includes_dynamic_build_solve_and_source_checks':True,'deliberately_colliding66_diagnostic_required_before_solve':True,'all_source_checks_required_for_acceptance':True,'native_calls':0,'H5_complete':False})
for n in ['remaining25.json','fixed41.json','modes.json','control.json','control-source56.json','mode-inner-rectangles.json','fixed-inner-rectangles-inset.json']:shutil.copyfile(OLD/n,BASE/n)
for n in ['free','relative']:shutil.copytree(OLD/n,BASE/n)
old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model/model.pb').read_bytes());p=cp_model_pb2.CpModelProto();p.CopyFrom(old);p.ClearField('constraints');remap={};removed=[]
for i,c in enumerate(old.constraints):
    kind=c.WhichOneof('constraint')
    if kind in ['interval','cumulative']:removed.append({'old_index':i,'kind':kind,'sha256':sha256(c.SerializeToString()).hexdigest()})
    else:assert kind=='linear';remap[i]=len(p.constraints);p.constraints.add().CopyFrom(c)
assert len(removed)==2944 and sum(r['kind']=='interval' for r in removed)==2942 and sum(r['kind']=='cumulative' for r in removed)==2
mp=load(OLD/'model/mapping.json');mp.pop('components');mp.pop('x_cumulative');mp.pop('y_cumulative');assert not mp['pairs']
for item in mp['items']:
    for k in ['mandatory','choice']:item[k]=remap[item[k]]
    for o in item['options']:
        o['choice_constraint']=remap[o['choice_constraint']];o['plane_constraints']=[[remap[i] for i in row] for row in o['plane_constraints']]
for r in mp['orders']:r['constraint']=remap[r['constraint']]
assert len(p.variables)==342 and len(p.constraints)==1073 and p.variables==old.variables and p.solution_hint==old.solution_hint
(BASE/'model/model.pb').write_bytes(p.SerializeToString());(BASE/'model/model.pbtxt').write_text(text_format.MessageToString(p),encoding='utf-8',newline='\n')
cm=cp_model.CpModel();assert cm.proto.parse_text_format((BASE/'model/model.pbtxt').read_text()) and cm.validate()==''
write(BASE/'model/mapping.json',mp);write(BASE/'model/removed-constraints.json',removed);write(BASE/'model/retained-constraint-map.json',{str(k):v for k,v in remap.items()})
write(BASE/'model/plan.json',{'inputs':{q.relative_to(ROOT).as_posix():digest(q) for q in [BASE/'plan.json',OLD/'model/model.pb',OLD/'model/mapping.json',OLD/'model/checks.json']},'all_original_variables_and_hints_preserved':True,'removed_only_2944_capacity_constraints':True,'no_source_acceptance_relaxation':True})
source=(ROOT/'output/h5_lazy_cp_reader_20261028.py').read_text(encoding='utf-8');begin=source.index('    expected=[]\n');end=source.index('    orders=[',begin)
source=source[:begin]+"    assert set(mp)=={'items','orders','pairs'}\n"+source[end:];source=source.replace("'contained_component_options':1471","'contained_component_options':0")
with (ROOT/'output/h5_collision_cp_reader_20261028.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
checker=(ROOT/'output/check_h5_lazy_source_candidate_20261028.py').read_text(encoding='utf-8').replace('h5-mixed25-lazy-source-20261028','h5-collision-first-source-20261028')
with (ROOT/'output/check_h5_collision_source_candidate_20261028.py').open('x',encoding='utf-8',newline='\n') as f:f.write(checker)
write(BASE/'prepared.json',{'variables':len(p.variables),'constraints':len(p.constraints),'all25_mandatory':True,'removed_intervals':2942,'removed_cumulatives':2,'same_variables_and_hints':True,'model_sha256':digest(BASE/'model/model.pb'),'mapping_sha256':digest(BASE/'model/mapping.json'),'solver_calls':0,'native_calls':0,'H5_complete':False})
print(load(BASE/'prepared.json'))
