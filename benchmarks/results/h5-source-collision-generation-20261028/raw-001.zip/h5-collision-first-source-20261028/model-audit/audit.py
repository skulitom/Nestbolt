"""Audit the exact capacity deletion, full66 negative diagnostic and pair additions."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
from h5_collision_cp_reader_20261028 import audit
from h5_lazy_cp_builder_20261028 import add_pairs
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-collision-first-source-20261028';OLD=ROOT/'output/h5-mixed25-lazy-source-20261028';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,BASE/'model',BASE/'colliding66-diagnostic']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model/model.pb').read_bytes());p=cp_model_pb2.CpModelProto();p.ParseFromString((BASE/'model/model.pb').read_bytes());assert p.variables==old.variables and p.solution_hint==old.solution_hint
retained=[(i,c) for i,c in enumerate(old.constraints) if c.WhichOneof('constraint')=='linear'];removed=[(i,c) for i,c in enumerate(old.constraints) if c.WhichOneof('constraint')!='linear'];assert len(p.constraints)==len(retained)==1073 and len(removed)==2944
assert all(c==p.constraints[j] for j,(i,c) in enumerate(retained));assert load(BASE/'model/retained-constraint-map.json')=={str(i):j for j,(i,c) in enumerate(retained)}
assert load(BASE/'model/removed-constraints.json')==[{'old_index':i,'kind':c.WhichOneof('constraint'),'sha256':sha256(c.SerializeToString()).hexdigest()} for i,c in removed]
mp=load(BASE/'model/mapping.json');remaining=load(BASE/'remaining25.json');modes=load(BASE/'modes.json');free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)};fixed=load(BASE/'fixed-inner-rectangles-inset.json');rects=load(BASE/'mode-inner-rectangles.json');control=load(BASE/'control.json')
check,partial=audit(p,mp,remaining,modes,free,fixed,rects,relative,control);write(OUT/'partial-control-assignment.json',partial);negative=load(BASE/'colliding66-diagnostic/checks.json');assert negative['passed'] and negative['expected_source_rejection'];assignment_check=evaluate(p,load(BASE/'colliding66-diagnostic/assignment.json'),0);write(OUT/'negative-diagnostic-model-check.json',assignment_check)
cm=cp_model.CpModel();assert cm.proto.parse_text_format((BASE/'model/model.pbtxt').read_text());groups={f:[i['index'] for i in mp['items'] if i['family']==f] for f in ['bracket','cog','insert']};b,c,i=[groups[f] for f in ['bracket','cog','insert']];pairs=[(b[0],b[1]),(b[0],c[0]),(b[0],i[0]),(c[0],c[1]),(c[0],i[0]),(i[0],i[1])];preflight=copy.deepcopy(mp);add_pairs(cm,preflight,pairs,relative);assert cm.export_to_file(str(OUT/'pair-preflight.pb'));write(OUT/'pair-preflight-mapping.json',preflight)
q=cp_model_pb2.CpModelProto();q.ParseFromString((OUT/'pair-preflight.pb').read_bytes());assert list(q.variables[:len(p.variables)])==list(p.variables) and list(q.constraints[:len(p.constraints)])==list(p.constraints) and q.solution_hint==p.solution_hint
pc,_=audit(q,preflight,remaining,modes,free,fixed,rects,relative,control);write(OUT/'pair-preflight-checks.json',{**pc,'all6_family_pairs':True,'all66_intrinsic_domains':True,'prefix_unchanged':True,'solver_calls':0})
write(OUT/'checks.json',{**check,'seconds':time.perf_counter()-started,'retained_linear_constraints_verified':1073,'removed_only_capacity_constraints':2944,'negative66_passes_relaxation_but_source_rejects':True,'negative_source_pair_failures':negative['source_pair_failures'],'negative_source_stock_failures':0,'pair_preflight_passed':True,'model_sha256':digest(BASE/'model/model.pb'),'mapping_sha256':digest(BASE/'model/mapping.json'),'solver_calls':0,'H5_complete':False})
inputs=[BASE/'plan.json',BASE/'model/plan.json',BASE/'model/model.pb',BASE/'model/model.pbtxt',BASE/'model/mapping.json',BASE/'colliding66-diagnostic/plan.json',BASE/'colliding66-diagnostic/checks.json',BASE/'colliding66-diagnostic/assignment.json',BASE/'colliding66-diagnostic/source-audit.json',ROOT/'output/h5_collision_cp_reader_20261028.py',ROOT/'output/h5_lazy_cp_builder_20261028.py',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});print(load(OUT/'checks.json'))
