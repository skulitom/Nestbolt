"""One closed source-checked sequence; distinct models share60s and90s process budget."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-collision-first-source-20261028';OUT=BASE/'search';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def child():
    from google.protobuf import text_format
    from ortools.sat import cp_model_pb2
    from ortools.sat.python import cp_model
    from h5_lazy_cp_builder_20261028 import add_pairs
    from h5_collision_cp_reader_20261028 import audit
    from h5_rectangle_cp_evaluator_20261028 import evaluate
    started=time.perf_counter();deadline=started+60
    for folder in [BASE,BASE/'model',BASE/'model-audit']:
        for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
    assert load(BASE/'model-audit/checks.json')['passed'] and load(BASE/'model-audit/pair-preflight-checks.json')['passed']
    inputs=[BASE/'model/model.pb',BASE/'model/model.pbtxt',BASE/'model/mapping.json',BASE/'model-audit/checks.json',BASE/'model-audit/pair-preflight-checks.json',ROOT/'output/h5_lazy_cp_builder_20261028.py',ROOT/'output/h5_collision_cp_reader_20261028.py',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py',ROOT/'output/check_h5_collision_source_candidate_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']
    write(OUT/'opened.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'algorithm_seconds':60,'shared_seconds':90,'maximum_distinct_solves':8,'maximum_seconds_per_solve':15,'stop_after_no_candidate':True})
    model=cp_model.CpModel();assert model.proto.parse_text_format((BASE/'model/model.pbtxt').read_text());mp=load(BASE/'model/mapping.json')
    remaining=load(BASE/'remaining25.json');modes=load(BASE/'modes.json');free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)};fixed=load(BASE/'fixed-inner-rectangles-inset.json');rects=load(BASE/'mode-inner-rectangles.json');control=load(BASE/'control.json')
    records=[];seen_hashes=set();pending=[];previous=None;reason='MAXIMUM_DISTINCT_SOLVES';valid=False
    for sequence in range(8):
        if time.perf_counter()>=deadline:reason='ALGORITHM_DEADLINE';break
        folder=OUT/f'{sequence:02d}';folder.mkdir();iteration_start=time.perf_counter()
        if pending:add_pairs(model,mp,pending,relative)
        assert model.export_to_file(str(folder/'model.pb'));assert model.export_to_file(str(folder/'model.pbtxt'));write(folder/'mapping.json',mp)
        p=cp_model_pb2.CpModelProto();p.ParseFromString((folder/'model.pb').read_bytes());modelhash=digest(folder/'model.pb');assert modelhash not in seen_hashes;seen_hashes.add(modelhash)
        if previous is not None:
            assert list(p.variables[:len(previous.variables)])==list(previous.variables) and list(p.constraints[:len(previous.constraints)])==list(previous.constraints) and p.solution_hint==previous.solution_hint
        else:assert modelhash==load(BASE/'model-audit/checks.json')['model_sha256']
        checks,_=audit(p,mp,remaining,modes,free,fixed,rects,relative,control);write(folder/'model-audit.json',{**checks,'model_sha256':modelhash,'mapping_sha256':digest(folder/'mapping.json'),'new_owner_pairs':pending,'previous_model_prefix_unchanged':previous is not None})
        allowance=min(15.,deadline-time.perf_counter())
        if allowance<=0:reason='ALGORITHM_DEADLINE_DURING_BUILD_AUDIT';break
        solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=allowance;solver.parameters.num_search_workers=4;solver.parameters.random_seed=0;solver.parameters.ignore_subsolvers.append('fj');solver.parameters.log_search_progress=True;solver.parameters.log_to_stdout=False
        (folder/'parameters.pbtxt').write_text(str(solver.parameters),encoding='utf-8',newline='\n');write(folder/'opened.json',{'sequence':sequence,'algorithm_elapsed_seconds':time.perf_counter()-started,'max_solve_seconds':allowance,'model_sha256':modelhash})
        class Capture(cp_model.CpSolverSolutionCallback):
            def __init__(self):super().__init__();self.count=0
            def on_solution_callback(self):
                write(folder/f'incumbent-{self.count:02d}.json',{'solver_wall_seconds':self.wall_time,'values':[self.value(model.get_int_var_from_proto_index(i)) for i in range(len(model.proto.variables))]});self.count+=1
        capture=Capture()
        with (folder/'solver.log').open('x',encoding='utf-8',newline='\n') as f:
            solver.log_callback=lambda s:(f.write(s+'\n'),f.flush());solve_start=time.perf_counter();status=solver.solve(model,capture);elapsed=time.perf_counter()-solve_start
        response=text_format.Parse(str(solver.response_proto),cp_model_pb2.CpSolverResponse());(folder/'response.pb').write_bytes(response.SerializeToString())
        record={'sequence':sequence,'status':solver.status_name(status),'model_sha256':modelhash,'variables':len(p.variables),'constraints':len(p.constraints),'pair_constraints':len(mp['pairs']),'max_solve_seconds':allowance,'returned_solve_seconds':elapsed,'solver_wall_seconds':response.wall_time,'soft_overrun_seconds':max(0.,elapsed-allowance),'has_solution':bool(response.solution),'incumbents':capture.count,'returned_response_branches':response.num_branches,'returned_response_conflicts':response.num_conflicts}
        if not response.solution:
            assert capture.count==0;reason='NO_CANDIDATE_'+record['status'];write(folder/'result.json',record);records.append(record);break
        assert status in [cp_model.OPTIMAL,cp_model.FEASIBLE];values=list(response.solution);write(folder/'assignment.json',values);write(folder/'assignment-audit.json',evaluate(p,values,0))
        for path in sorted(folder.glob('incumbent-*.json')):evaluate(p,load(path)['values'],0)
        source_allowance=deadline-time.perf_counter()
        if source_allowance<=0:reason='ALGORITHM_DEADLINE_BEFORE_SOURCE';write(folder/'result.json',record);records.append(record);break
        try:
            proc=subprocess.run([str(ROOT/'.cache/shop-venv/Scripts/python.exe'),str(ROOT/'output/check_h5_collision_source_candidate_20261028.py'),str(folder)],cwd=ROOT,capture_output=True,timeout=source_allowance)
            (folder/'source-stdout.txt').write_bytes(proc.stdout);(folder/'source-stderr.txt').write_bytes(proc.stderr);assert proc.returncode==0
        except subprocess.TimeoutExpired as e:
            (folder/'source-stdout.txt').write_bytes(e.stdout or b'');(folder/'source-stderr.txt').write_bytes(e.stderr or b'');reason='ALGORITHM_DEADLINE_IN_SOURCE';write(folder/'result.json',record);records.append(record);break
        source=load(folder/'source-audit.json');record.update({'source_valid':source['valid'],'source_pair_failures':source['pair_failures'],'source_stock_failures':source['stock_failures'],'iteration_seconds':time.perf_counter()-iteration_start});write(folder/'result.json',record);records.append(record)
        if source['valid']:valid=True;reason='SOURCE_VALID66';break
        assert source['stock_failures']==0;key_to_index={(r['family'],r['copy_index']):r['index'] for r in mp['items']};pending=[];existing={(r['left'],r['right']) for r in mp['pairs']}
        for failure in source['pairs']:
            if failure['passed']:continue
            a,b=map(tuple,failure['keys']);assert a in key_to_index and b in key_to_index,'fixed-owner collision contradicts audited free cells'
            pair=tuple(sorted([key_to_index[a],key_to_index[b]]));assert pair not in existing,'source collision contradicts existing pair cells';pending.append(pair)
        pending=sorted(set(pending));assert pending;write(folder/'next-owner-pairs.json',pending);previous=p
    write(OUT/'result.json',{'reason':reason,'closed':True,'algorithm_seconds':time.perf_counter()-started,'algorithm_soft_overrun_seconds':max(0.,time.perf_counter()-deadline),'distinct_solves':len(records),'records':records,'source_full66_verified':valid,'native_calls':0,'full66_exclusion_claimed':False,'H5_complete':False})
def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'run.py');started=time.perf_counter();write(OUT/'budget.json',{'algorithm_seconds':60,'shared_seconds':90,'maximum_distinct_solves':8,'maximum_seconds_per_solve':15,'retry_permitted':False})
    try:
        p=subprocess.run([str(ROOT/'.cache/h5-cpsat-cpython-venv/Scripts/python.exe'),str(Path(__file__)),'--child'],cwd=ROOT,capture_output=True,timeout=90)
        (OUT/'stdout.txt').write_bytes(p.stdout);(OUT/'stderr.txt').write_bytes(p.stderr);process={'seconds':time.perf_counter()-started,'exit_code':p.returncode,'timeout':False}
    except subprocess.TimeoutExpired as e:
        (OUT/'stdout.txt').write_bytes(e.stdout or b'');(OUT/'stderr.txt').write_bytes(e.stderr or b'');process={'seconds':time.perf_counter()-started,'timeout':True}
    write(OUT/'process.json',process);print(process);print(load(OUT/'result.json') if (OUT/'result.json').exists() else 'No final response; sequence remains closed.')
if __name__=='__main__':child() if '--child' in sys.argv else main()
