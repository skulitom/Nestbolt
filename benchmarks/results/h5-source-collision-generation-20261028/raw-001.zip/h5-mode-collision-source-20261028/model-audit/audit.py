"""Independently bind observed-mode constraints, rejected evidence and unseen-mode diagnostic."""
from pathlib import Path
from hashlib import sha256
import copy,json,shutil,time
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
from h5_mode_cp_reader_20261028 import audit
from h5_mode_case_builder_20261028 import add_cases
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mode-collision-source-20261028';OLD=ROOT/'output/h5-collision-first-source-20261028';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for folder in [BASE,BASE/'model',BASE/'colliding66-diagnostic']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model/model.pb').read_bytes());p=cp_model_pb2.CpModelProto();p.ParseFromString((BASE/'model/model.pb').read_bytes());assert list(p.variables[:len(old.variables)])==list(old.variables) and list(p.constraints[:len(old.constraints)])==list(old.constraints) and p.solution_hint==old.solution_hint
mp=load(BASE/'model/mapping.json');remaining=load(BASE/'remaining25.json');modes=load(BASE/'modes.json');free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)};fixed=load(BASE/'fixed-inner-rectangles-inset.json');rects=load(BASE/'mode-inner-rectangles.json');control=load(BASE/'control.json')
check,partial=audit(p,mp,remaining,modes,free,fixed,rects,relative,control);write(OUT/'partial-control-assignment.json',partial)
oldsol=load(OLD/'search/00/assignment.json');oldsource=load(OLD/'search/00/source-audit.json');bykey={(it['family'],it['copy_index']):it for it in mp['items']};expected=[]
for failure in oldsource['pairs']:
    if failure['passed']:continue
    left,right=sorted((bykey[tuple(k)] for k in failure['keys']),key=lambda r:r['index']);a,b=[next(o['mode'] for o in it['options'] if oldsol[o['selector']]) for it in [left,right]];expected.append([left['index'],right['index'],a,b]);sign=1 if a<=b else -1;dx=sign*(oldsol[right['x']]-oldsol[left['x']]);dy=sign*(oldsol[right['y']]-oldsol[left['y']])
    assert not any(all(aa*dx+bb*dy>=cc for aa,bb,cc in c['halfplanes']) for c in relative[min(a,b),max(a,b)])
actual=sorted([pair['left'],pair['right'],g['left_mode'],g['right_mode']] for pair in mp['pairs'] for g in pair['groups']);assert sorted(expected)==actual==load(BASE/'model/initial-cases.json') and len(actual)==43
negative=load(BASE/'colliding66-diagnostic/checks.json');assert negative['passed'] and negative['expected_source_rejection'];negvalues=load(BASE/'colliding66-diagnostic/assignment.json');negcheck=evaluate(p,negvalues,0)
for pair in mp['pairs']:
    for group in pair['groups']:
        active=[next(o['selector'] for o in mp['items'][pair[k]]['options'] if o['mode']==group[k+'_mode']) for k in ['left','right']];assert not all(negvalues[v] for v in active) and all(negvalues[v]==0 for v in group['cells'])
write(OUT/'unseen-mode-negative-model-check.json',negcheck)
cm=cp_model.CpModel();assert cm.proto.parse_text_format((BASE/'model/model.pbtxt').read_text());trial=copy.deepcopy(mp);groups={f:[it for it in mp['items'] if it['family']==f] for f in ['bracket','cog','insert']};b,c,i=[groups[f] for f in ['bracket','cog','insert']];owner_pairs=[(b[0],b[1]),(b[0],c[0]),(b[0],i[0]),(c[0],c[1]),(c[0],i[0]),(i[0],i[1])];seen=set(map(tuple,actual));more=sorted((a['index'],b['index'],oa['mode'],ob['mode']) for a,b in owner_pairs for oa in a['options'] for ob in b['options'] if (a['index'],b['index'],oa['mode'],ob['mode']) not in seen);add_cases(cm,trial,more,relative);assert cm.export_to_file(str(OUT/'pair-preflight.pb'));write(OUT/'pair-preflight-mapping.json',trial)
q=cp_model_pb2.CpModelProto();q.ParseFromString((OUT/'pair-preflight.pb').read_bytes());assert list(q.variables[:len(p.variables)])==list(p.variables) and list(q.constraints[:len(p.constraints)])==list(p.constraints) and q.solution_hint==p.solution_hint
pc,_=audit(q,trial,remaining,modes,free,fixed,rects,relative,control);used={tuple(sorted([g['left_mode'],g['right_mode']])) for pair in trial['pairs'] for g in pair['groups']};assert used==set(relative)
write(OUT/'pair-preflight-checks.json',{**pc,'all66_intrinsic_domains':True,'new_mode_cases_appended':len(more),'existing_and_new_owner_pairs_exercised':True,'prefix_unchanged':True,'solver_calls':0})
write(OUT/'checks.json',{**check,'seconds':time.perf_counter()-started,'initial_observed_mode_cases_verified':43,'previous_rejected_candidate_excluded_in_all43_cases':True,'all_source_modes_not_yet_constrained':True,'unseen_modes_negative66_passes_model_but_source_rejects':True,'negative_source_pair_failures':negative['source_pair_failures'],'negative_source_stock_failures':0,'pair_preflight_passed':True,'model_sha256':digest(BASE/'model/model.pb'),'mapping_sha256':digest(BASE/'model/mapping.json'),'solver_calls':0,'H5_complete':False})
inputs=[BASE/'plan.json',BASE/'model/plan.json',BASE/'model/model.pb',BASE/'model/model.pbtxt',BASE/'model/mapping.json',BASE/'model/initial-cases.json',BASE/'colliding66-diagnostic/plan.json',BASE/'colliding66-diagnostic/checks.json',BASE/'colliding66-diagnostic/assignment.json',BASE/'colliding66-diagnostic/source-audit.json',ROOT/'output/h5_mode_cp_reader_20261028.py',ROOT/'output/h5_mode_case_builder_20261028.py',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});print(load(OUT/'checks.json'))
