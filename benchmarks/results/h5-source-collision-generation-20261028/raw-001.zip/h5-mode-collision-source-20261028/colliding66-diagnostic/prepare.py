"""Construct an intentionally colliding full66 assignment, without searching."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess,sys
from shapely.geometry import shape
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mode-collision-source-20261028';OUT=BASE/'colliding66-diagnostic';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');shutil.copyfile(BASE/'model/mapping.json',OUT/'mapping.json');mp=load(OUT/'mapping.json');control=load(BASE/'control.json');free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};values={};chosen=[]
def selected(cells,x,y):return next(i for i,c in enumerate(cells) if all(a*x+b*y>=v for a,b,v in c['halfplanes']))
for item in mp['items']:
    known=next((v for v in control if (v['family'],v['copy_index'])==(item['family'],item['copy_index'])),None)
    if known:mode=known['mode'];x,y=known['anchor_um']
    else:
        mode=item['options'][1]['mode'];center=shape(free[mode][0]['geometry']).centroid;x,y=round(center.x*1000),round(center.y*1000)
    cell=selected(free[mode],x,y);values[item['presence']]=1;values[item['x']]=x;values[item['y']]=y
    for o in item['options']:
        active=o['mode']==mode;values[o['selector']]=int(active)
        for k,v in enumerate(o['cells']):values[v]=int(active and k==cell)
    chosen.append({'family':item['family'],'copy_index':item['copy_index'],'mode':mode,'anchor_um':[x,y],'selected_free_cell':cell})
assert len(values)==342 and len(chosen)==25
for pair in mp['pairs']:
    for group in pair['groups']:
        assert group['left_mode'] in [0,1,9] and group['right_mode'] in [0,1,9]
        for v in group['cells']:values[v]=0
write(OUT/'assignment.json',[values[i] for i in range(len(values))]);write(OUT/'construction.json',chosen)
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in [BASE/'plan.json',BASE/'model/model.pb',BASE/'model/mapping.json',BASE/'control.json',ROOT/'output/check_h5_mode_source_candidate_20261028.py',ROOT/'output/h5_legacy64_source_readback.py']},'purpose':'Negative full66 acceptance-path diagnostic. All three brackets use mode2 at one legal free-cell centroid; all seven inserts use mode10 at another. Every initial observed-mode group is inactive. Fifteen cogs use the source-valid partial control. This must pass the relaxed model but fail full original-source collision checks. It is not a solver candidate, a valid layout or an H5 result.','solver_calls':0})
proc=subprocess.run([sys.executable,str(ROOT/'output/check_h5_mode_source_candidate_20261028.py'),str(OUT)],cwd=ROOT,capture_output=True,timeout=30);(OUT/'stdout.txt').write_bytes(proc.stdout);(OUT/'stderr.txt').write_bytes(proc.stderr);assert proc.returncode==0,proc.stderr.decode()
r=load(OUT/'source-audit.json');assert not r['valid'] and r['pair_failures']>=24 and r['stock_failures']==0 and r['cutouts']==90 and r['hole_vertices']==10026
keys={(v['family'],v['copy_index']) for v in chosen};failed=[p for p in r['pairs'] if not p['passed']];assert all(tuple(k) in keys for p in failed for k in p['keys'])
write(OUT/'checks.json',{'passed':True,'unseen_modes_assignment_requires_independent_protobuf_audit':True,'originals':r['originals'],'original_pairs':r['same_sheet_pairs'],'stock_edges':r['stock_edges'],'holes':r['cutouts'],'hole_vertices':r['hole_vertices'],'expected_source_rejection':True,'source_pair_failures':r['pair_failures'],'source_stock_failures':r['stock_failures'],'all_failures_are_mover_pairs':True,'not_a_valid_layout':True,'solver_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
