"""Audit the complete mode-case sequence, all assignments and every generated case."""
from pathlib import Path
from hashlib import sha256
import json,re,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2,sat_parameters_pb2
from h5_mode_cp_reader_20261028 import audit
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mode-collision-source-20261028';SEARCH=BASE/'search';OUT=BASE/'response-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter()
for path in [BASE/'plan.json',BASE/'model-audit/plan.json',SEARCH/'opened.json']:
    for n,h in load(path)['inputs'].items():assert digest(ROOT/n)==h,n
result=load(SEARCH/'result.json');process=load(SEARCH/'process.json');assert result['closed'] and result['reason']=='NO_CANDIDATE_UNKNOWN' and result['distinct_solves']==len(result['records'])==3
assert process['exit_code']==0 and not process['timeout'] and process['seconds']<=90 and result['algorithm_seconds']<60 and result['algorithm_soft_overrun_seconds']==0 and not result['source_full66_verified']
assert load(SEARCH/'budget.json')['maximum_distinct_solves']==load(BASE/'plan.json')['maximum_distinct_solves']==32
free={i:load(BASE/'free'/f'{i:02d}.json')['cells'] for i in range(11)};relative={(i,j):load(BASE/'relative'/f'{i:02d}-{j:02d}.json')['cells'] for i in range(11) for j in range(i,11)};modes=load(BASE/'modes.json');stats=[];previous=None;oldsol=None;pending=[];expected=set(map(tuple,load(BASE/'model/initial-cases.json')));hashes=set();candidate_count=0
assert sorted(p.name for p in SEARCH.iterdir() if p.is_dir())==['00','01','02']
for sequence,record in enumerate(result['records']):
    folder=SEARCH/f'{sequence:02d}';p=cp_model_pb2.CpModelProto();p.ParseFromString((folder/'model.pb').read_bytes());mp=load(folder/'mapping.json');assert record==load(folder/'result.json') and record['sequence']==sequence;h=digest(folder/'model.pb');assert h==record['model_sha256'] and h not in hashes;hashes.add(h)
    checks,_=audit(p,mp,load(BASE/'remaining25.json'),modes,free,load(BASE/'fixed-inner-rectangles-inset.json'),load(BASE/'mode-inner-rectangles.json'),relative,load(BASE/'control.json'));actual={(r['left'],r['right'],g['left_mode'],g['right_mode']) for r in mp['pairs'] for g in r['groups']};assert actual==expected and len(actual)==record['mode_case_constraints'];assert load(folder/'model-audit.json')['new_mode_cases']==[list(v) for v in pending]
    if previous is None:assert h==digest(BASE/'model/model.pb')
    else:
        assert list(p.variables[:len(previous.variables)])==list(previous.variables) and list(p.constraints[:len(previous.constraints)])==list(previous.constraints) and p.solution_hint==previous.solution_hint
        for li,ri,a,b in pending:
            left,right=mp['items'][li],mp['items'][ri];sign=1 if a<=b else -1;dx=sign*(oldsol[right['x']]-oldsol[left['x']]);dy=sign*(oldsol[right['y']]-oldsol[left['y']]);assert not any(all(aa*dx+bb*dy>=cc for aa,bb,cc in c['halfplanes']) for c in relative[min(a,b),max(a,b)])
    params=text_format.Parse((folder/'parameters.pbtxt').read_text(),sat_parameters_pb2.SatParameters());assert params.max_time_in_seconds==15 and params.num_search_workers==4 and params.random_seed==0 and list(params.ignore_subsolvers)==['fj'] and params.log_search_progress and not params.log_to_stdout
    assert {f.name for f,v in params.ListFields()}=={'max_time_in_seconds','num_search_workers','random_seed','ignore_subsolvers','log_search_progress','log_to_stdout'}
    r=cp_model_pb2.CpSolverResponse();r.ParseFromString((folder/'response.pb').read_bytes());assert record['solver_wall_seconds']==r.wall_time and record['returned_response_branches']==r.num_branches and record['returned_response_conflicts']==r.num_conflicts and record['soft_overrun_seconds']==max(0.,record['returned_solve_seconds']-15)
    search_start=float(re.search(r'Starting search at ([0-9.]+)s',(folder/'solver.log').read_text()).group(1))
    if sequence<2:
        assert r.status==cp_model_pb2.OPTIMAL and r.solution and record['has_solution'] and record['incumbents']==1;sol=list(r.solution);assert sol==load(folder/'assignment.json');evaluate(p,sol,0);incumbents=list(folder.glob('incumbent-*.json'));assert len(incumbents)==1 and load(incumbents[0])['values']==sol;evaluate(p,load(incumbents[0])['values'],0)
        source=load(folder/'source-audit.json');assert not source['valid'] and source['pair_failures']==[20,48][sequence] and source['stock_failures']==0 and source['originals']==66 and source['same_sheet_pairs']==1380 and source['cutouts']==90 and source['hole_vertices']==10026
        rows=load(folder/'candidate66.json');expected_rows=load(BASE/'fixed41.json');poses=[]
        for it in mp['items']:
            assert sol[it['presence']]==1;selected=[o['mode'] for o in it['options'] if sol[o['selector']]];assert len(selected)==1;m=modes[selected[0]];x,y=sol[it['x']],sol[it['y']]
            expected_rows.append({'part_id':it['family'],'copy_index':it['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],'translation':[x/1000+m['source_translation_offset'][0],y/1000+m['source_translation_offset'][1]],'mirrored':m['mirrored']}});poses.append({'family':it['family'],'copy_index':it['copy_index'],'mode':m['index'],'anchor_um':[x,y]})
        assert rows==expected_rows and poses==load(folder/'selected-poses.json');key_to_index={(it['family'],it['copy_index']):it['index'] for it in mp['items']};pending=[]
        for failure in source['pairs']:
            if failure['passed']:continue
            li,ri=sorted(key_to_index[tuple(k)] for k in failure['keys']);a,b=[next(o['mode'] for o in mp['items'][i]['options'] if sol[o['selector']]) for i in [li,ri]];case=(li,ri,a,b);assert case not in expected;pending.append(case)
        pending=sorted(set(pending));assert len(pending)==source['pair_failures'] and [list(v) for v in pending]==load(folder/'next-mode-cases.json');expected.update(pending);candidate_count+=1;oldsol=sol
    else:assert r.status==cp_model_pb2.UNKNOWN and not r.solution and not r.additional_solutions and not record['has_solution'] and record['incumbents']==0 and not list(folder.glob('incumbent-*.json')) and not (folder/'assignment.json').exists()
    stats.append({'sequence':sequence,'status':record['status'],'variables':len(p.variables),'constraints':len(p.constraints),'mode_cases':len(actual),'owner_pairs':len(mp['pairs']),'source_pair_failures':record.get('source_pair_failures'),'search_started_seconds':search_start,'returned_solve_seconds':record['returned_solve_seconds'],'soft_overrun_seconds':record['soft_overrun_seconds']});previous=p
write(OUT/'model-response-checks.json',stats)
inputs=[BASE/'plan.json',BASE/'model-audit/checks.json',SEARCH/'opened.json',SEARCH/'result.json',SEARCH/'process.json']+[p for folder in [SEARCH/'00',SEARCH/'01',SEARCH/'02'] for p in folder.iterdir() if p.is_file()]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}})
write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,'distinct_models_and_solves':3,'source_candidates_rejected':candidate_count,'source_pair_failures':[20,48],'initial_mode_cases':43,'generated_mode_cases':68,'final_mode_cases':111,'previous_candidates_excluded_by_every_generated_case':True,'all_model_prefixes_preserved':True,'actual_geometry_readback_pending_separate_process':True,'last_status':'UNKNOWN','sequence_closed':True,'algorithm_seconds':result['algorithm_seconds'],'shared_seconds':process['seconds'],'solve_soft_overrun_seconds':stats[-1]['soft_overrun_seconds'],'no_candidate_stop_obeyed':True,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
