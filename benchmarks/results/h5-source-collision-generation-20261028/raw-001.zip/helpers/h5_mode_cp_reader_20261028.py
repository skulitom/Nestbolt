"""Independent protobuf field reader: source identities, domains, intervals and pair signs."""
from ortools.sat import cp_model_pb2
from h5_rectangle_cp_evaluator_20261028 import evaluate
MIN=-9223372036854775808;MAX=9223372036854775807
def audit(p,mp,remaining,modes,free,fixed,rects,relative,control):
    assert {f.name for f,v in p.ListFields()}=={'variables','constraints','solution_hint'}
    seenvars=set();seencts=set();hints={};control_values={};allx=[];ally=[];widths=[];heights=[]
    def var(ix,name,domain):
        assert ix not in seenvars;seenvars.add(ix);v=p.variables[ix];assert v.name==name and list(v.domain)==domain and {f.name for f,z in v.ListFields()}=={'name','domain'}
    def linear(ix,coeffs,lo=MIN,hi=MAX,on=None):
        assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='linear' and {f.name for f,z in ct.ListFields()}<={'linear','enforcement_literal'}
        assert list(ct.enforcement_literal)==([] if on is None else [on]) and dict(zip(ct.linear.vars,ct.linear.coeffs))==coeffs and len(ct.linear.vars)==len(coeffs) and list(ct.linear.domain)==[lo,hi]
    def expr(e,v,offset):
        assert e.offset==offset and list(e.vars)==([] if v is None else [v]) and list(e.coeffs)==([] if v is None else [1]) and {f.name for f,z in e.ListFields()}<={'vars','coeffs','offset'}
    def interval(ix,name,variable,lo,hi,selector=None):
        assert ix not in seencts;seencts.add(ix);ct=p.constraints[ix];assert ct.WhichOneof('constraint')=='interval' and ct.name==name and list(ct.enforcement_literal)==([] if selector is None else [selector])
        assert {f.name for f,z in ct.ListFields()}==({'name','interval'} if selector is None else {'name','interval','enforcement_literal'})
        expr(ct.interval.start,variable,lo);expr(ct.interval.size,None,hi-lo);expr(ct.interval.end,variable,hi)
    def cell(cells,x,y):return next(k for k,c in enumerate(cells) if all(a*x+b*y>=v for a,b,v in c['halfplanes']))
    assert len(mp['items'])==len(remaining)==25
    for i,(item,r) in enumerate(zip(mp['items'],remaining)):
        family,copy=r['family'],r['copy_index'];assert (item['index'],item['family'],item['copy_index'])==(i,family,copy)
        present,x,y=item['presence'],item['x'],item['y'];var(present,f'present_{i}',[0,1]);var(x,f'x_{i}',[0,1500000]);var(y,f'y_{i}',[0,3000000]);linear(item['mandatory'],{present:1},1,1);hints[present]=1
        known=next((v for v in control if (v['family'],v['copy_index'])==(family,copy)),None);control_values[present]=int(known is not None);control_values[x],control_values[y]=known['anchor_um'] if known else [0,0]
        if known:hints[x],hints[y]=known['anchor_um']
        assert [o['mode'] for o in item['options']]==[m['index'] for m in modes if m['family']==family]
        for o in item['options']:
            mi=o['mode'];mv=o['selector'];var(mv,f'mode_{i}_{mi}',[0,1]);assert len(o['cells'])==len(free[mi])==len(o['plane_constraints'])
            linear(o['choice_constraint'],{**{v:1 for v in o['cells']},mv:-1},0,0);active=known is not None and known['mode']==mi;sc=cell(free[mi],*known['anchor_um']) if active else None;control_values[mv]=int(active)
            if known:hints[mv]=int(active)
            for k,(sv,domain,pcs) in enumerate(zip(o['cells'],free[mi],o['plane_constraints'])):
                var(sv,f'free_{i}_{mi}_{k}',[0,1]);assert len(pcs)==len(domain['halfplanes']);control_values[sv]=int(active and k==sc)
                if known:hints[sv]=control_values[sv]
                for ix,(a,b,c) in zip(pcs,domain['halfplanes']):linear(ix,{v:coef for v,coef in [(x,a),(y,b)] if coef},lo=c,on=sv)
        linear(item['choice'],{**{o['selector']:1 for o in item['options']},present:-1},0,0)
    assert set(mp)=={'items','orders','pairs'}
    orders=[(a,b) for family in ['bracket','cog','insert'] for group in [[r for r in mp['items'] if r['family']==family]] for a,b in zip(group,group[1:])];assert len(orders)==len(mp['orders'])==22
    for row,(a,b) in zip(mp['orders'],orders):assert (row['left'],row['right'])==(a['index'],b['index']);linear(row['constraint'],{a['x']:1,b['x']:-1},hi=0)
    seenpairs=set();group_count=0
    for pair in mp['pairs']:
        li,ri=pair['left'],pair['right'];assert li<ri and (li,ri) not in seenpairs;seenpairs.add((li,ri));left,right=mp['items'][li],mp['items'][ri]
        seen_cases=set();assert pair['groups']
        ca=next((c for c in control if (c['family'],c['copy_index'])==(left['family'],left['copy_index'])),None);cb=next((c for c in control if (c['family'],c['copy_index'])==(right['family'],right['copy_index'])),None)
        for group in pair['groups']:
            key=(group['left_mode'],group['right_mode']);assert key not in seen_cases;seen_cases.add(key);oa=next(o for o in left['options'] if o['mode']==key[0]);ob=next(o for o in right['options'] if o['mode']==key[1])
            a,b=oa['mode'],ob['mode'];assert (group['left_mode'],group['right_mode'])==(a,b);sign=1 if a<=b else -1;domains=relative[min(a,b),max(a,b)];ss=group['cells'];assert len(ss)==len(domains)==len(group['plane_constraints']);assert len(group['choice_constraints'])==3
            va,vb=oa['selector'],ob['selector'];c1,c2,c3=group['choice_constraints'];linear(c1,{**{v:1 for v in ss},va:-1},hi=0);linear(c2,{**{v:1 for v in ss},vb:-1},hi=0);linear(c3,{**{v:1 for v in ss},va:-1,vb:-1},lo=-1)
            active=ca is not None and cb is not None and (ca['mode'],cb['mode'])==(a,b);sc=cell(domains,*[sign*(cb['anchor_um'][k]-ca['anchor_um'][k]) for k in [0,1]]) if active else None
            for k,(v,domain,pcs) in enumerate(zip(ss,domains,group['plane_constraints'])):
                var(v,f'pair_{li}_{ri}_{a}_{b}_{k}',[0,1]);control_values[v]=int(active and sc==k);assert len(pcs)==len(domain['halfplanes'])
                for ix,(aa,bb,cc) in zip(pcs,domain['halfplanes']):linear(ix,{j:coef for j,coef in [(right['x'],sign*aa),(left['x'],-sign*aa),(right['y'],sign*bb),(left['y'],-sign*bb)] if coef},lo=cc,on=v)
            group_count+=1
    assert seenvars==set(range(len(p.variables))) and seencts==set(range(len(p.constraints)))
    assert dict(zip(p.solution_hint.vars,p.solution_hint.values))==hints and len(p.solution_hint.vars)==len(hints)
    sol=[control_values[i] for i in range(len(p.variables))];partial=cp_model_pb2.CpModelProto();partial.CopyFrom(p);disabled=[r['mandatory'] for r in mp['items'] if r['family']!='cog'];assert len(disabled)==10
    for ix in disabled:partial.constraints[ix].linear.domain[:]=[0,0]
    control_check=evaluate(partial,sol,0)
    for ix in disabled:
        ct=p.constraints[ix];assert sum(c*sol[v] for v,c in zip(ct.linear.vars,ct.linear.coeffs))==0 and list(ct.linear.domain)==[1,1];partial.constraints[ix].linear.domain[:]=[1,1]
    assert partial.SerializeToString()==p.SerializeToString()
    return {'passed':True,'variables':len(p.variables),'constraints':len(p.constraints),'mandatory_movers':25,'all_target_originals':66,'independent_coordinates':50,'contained_component_options':0,'pair_constraints':len(seenpairs),'mode_pair_groups':group_count,'partial_hints':len(hints),'partial_control':control_check,'partial_control_fails_actual_target':True,'all_model_fields_verified':True},sol
