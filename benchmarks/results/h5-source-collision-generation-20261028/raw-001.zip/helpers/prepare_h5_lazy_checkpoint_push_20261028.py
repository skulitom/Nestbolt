"""Create a new single-use push guard for the two newly audited checkpoints."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head.startswith('a0d6f9af')
source=(ROOT/'output/push_cog_feature_checkpoints_20261028.py').read_text(encoding='utf-8')
changes={
    "output/h5-cog-feature-main-sync-20261028":"output/h5-lazy-source-main-sync-20261028",
    "OLD='8713c6e13a1ad2a9ce33a7276722016264105244';NEW='b699d1c1845828fe1bfaa675804b32fc4a894528'":f"OLD='b699d1c1845828fe1bfaa675804b32fc4a894528';NEW='{head}'",
    "['benchmarks/results/h5-continuous-cog-source-20261028','benchmarks/results/h5-feasible-cog-source-20261028','benchmarks/results/h5-cog-feature-source-20261028']":"['benchmarks/results/h5-mixed25-outer-covers-20261028','benchmarks/results/h5-mixed25-lazy-source-20261028']",
    '40742366525':'40748909850',
}
for a,b in changes.items():assert a in source;source=source.replace(a,b)
target=ROOT/'output/push_h5_lazy_source_checkpoints_20261028.py'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
print({'helper':str(target),'head':head,'prior_main_CI':40748909850,'checkpoints':2})
