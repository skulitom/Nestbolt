"""Seal two closed collision-generation policies and all rejected complete candidates."""
from pathlib import Path
from datetime import datetime,timezone
import ast,json,shutil,subprocess,sys
from pack_h5_evidence_archive import pack,digest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from h2_import_audit import source_digest
FIRST=ROOT/'output/h5-collision-first-source-20261028';BASE=ROOT/'output/h5-mode-collision-source-20261028';PUB=BASE/'publication';NAME='h5-source-collision-generation-20261028';OUT=ROOT/'benchmarks/results'/NAME;load=lambda p:json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def append(p,s):
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(s)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');assert head=='a0d6f9af9c1e577263e138c3b2993f2c17591ec7' and not git('diff','HEAD','--name-only')
for folder in [FIRST,BASE]:
    assert all(load(folder/n)['passed'] for n in ['model-audit/checks.json','response-audit/checks.json','originals-audit/checks.json']) and load(folder/'search/result.json')['closed'] and not load(folder/'search/result.json')['source_full66_verified']
assert load(FIRST/'search/result.json')['distinct_solves']==2 and load(BASE/'search/result.json')['distinct_solves']==3
prior=load(ROOT/'benchmarks/results/h5-mixed25-lazy-source-20261028/publication-review.json');production=source_digest();assert production==prior['production_digest'];readmes={n:digest(ROOT/n) for n in prior['current_readmes']};assert readmes==prior['current_readmes']
up={'sparrow_head':load(PUB/'sparrow-head.json')['sha'],'studio_head':load(PUB/'studio-head.json')['sha'],'sparrow_release':load(PUB/'sparrow-release.json')['tag_name'],'studio_latest_release':[r['tag_name'] for r in load(PUB/'studio-releases.json')]};assert all(up[k]==prior[k] for k in up)
main=load(PUB/'main.json')['commit']['sha'];assert main==head;receipt=load(ROOT/'output/h5-lazy-source-main-sync-20261028/receipt.json');assert receipt['new_main']==head and receipt['prior_main_all6_pass'] and receipt['normal_atomic_fast_forward']
jobs=load(PUB/'main-ci-jobs.json')['jobs'];assert len(jobs)==6;passed=[j['name'] for j in jobs if j['status']=='completed' and j['conclusion']=='success'];live=[j['name'] for j in jobs if j['status']!='completed'];assert len(passed)==4 and len(live)==2
OUT.mkdir();members={};queue=[];seen=set();bindings={}
def add(n,p):
    members[n]=p
    if p.name in ['plan.json','opened.json'] or p.suffix=='.py':queue.append(p)
for folder in [FIRST,BASE,ROOT/'output/h5-lazy-source-main-sync-20261028']:
    for p in folder.rglob('*'):
        if p.is_file():add(folder.name+'/'+p.relative_to(folder).as_posix(),p)
helpers=['prepare_h5_collision_first_20261028.py','prepare_h5_collision_diagnostic_20261028.py','audit_h5_collision_base_20261028.py','make_h5_collision_runner_20261028.py','run_h5_collision_constraint_generation_20261028.py','audit_h5_collision_response_20261028.py','audit_h5_collision_originals_20261028.py','h5_collision_cp_reader_20261028.py','check_h5_collision_source_candidate_20261028.py','h5_mode_case_builder_20261028.py','prepare_h5_mode_collision_20261028.py','h5_mode_cp_reader_20261028.py','check_h5_mode_source_candidate_20261028.py','prepare_h5_mode_diagnostic_20261028.py','audit_h5_mode_base_20261028.py','make_h5_mode_runner_20261028.py','run_h5_mode_constraint_generation_20261028.py','audit_h5_mode_response_20261028.py','make_h5_mode_originals_reader_20261028.py','audit_h5_mode_originals_20261028.py','prepare_h5_lazy_checkpoint_push_20261028.py','push_h5_lazy_source_checkpoints_20261028.py','pack_h5_evidence_archive.py','ccd1.py',Path(__file__).name]
for n in helpers:add('helpers/'+n,ROOT/'output'/n)
while queue:
    p=queue.pop()
    if p in seen:continue
    seen.add(p)
    if p.name in ['plan.json','opened.json']:
        for n,h in load(p).get('inputs',{}).items():
            q=ROOT/n;assert digest(q)==h,n;bindings[n]=h;add('source-inputs/'+n,q)
    elif p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            modules=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for module in modules:
                if '.' in module:continue
                for folder in ['output','scripts']:
                    q=ROOT/folder/(module+'.py')
                    if q.is_file():add('imported-helpers/'+folder+'/'+q.name,q)
archive,_=pack(ROOT,OUT,NAME,members);write(OUT/'source-bindings.json',bindings)
for folder,prefix in [(FIRST,'owner'),(BASE,'mode')]:
    for a,b in [('model-audit/checks.json','model-audit.json'),('response-audit/checks.json','response-audit.json'),('response-audit/model-response-checks.json','model-progression.json'),('originals-audit/checks.json','originals-audit.json'),('search/result.json','search-result.json')]:shutil.copyfile(folder/a,OUT/f'{prefix}-{b}')
shutil.copyfile(BASE/'research/continuous-arithmetic-review.json',OUT/'continuous-arithmetic-review.json');shutil.copyfile(PUB/'main-ci-jobs.json',OUT/'main-ci-snapshot.json')
write(OUT/'publication-review.json',{'utc':datetime.now(timezone.utc).isoformat(),'source_head':head,'remote_main':main,'production_digest':production,'current_readmes':readmes,**up,'upstream_heads_and_releases_unchanged':True,'previous_two_checkpoints_pushed':True,'prior_main_CI':40748909850,'prior_main_all6_pass':True,'main_CI':40753599821,'main_all6_pass':False,'main_passed_jobs':passed,'main_live_jobs':live,'normal_push_requires_remaining_checks':True,'reserved_H2_vectors_evaluated':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,'new_release_qualified':False})
next_action='Both CP-SAT generation policies are CLOSED. Collision-first full owner-pair policy: source66 candidate43collisions, then386modegroups/8452vars31193cts UNKNOWN after13.26s presolve and15.034608s returned; total16.418178s algorithm17.172596s shared. Finer mode-case policy starts with43 observed cases, not another initial solve; models43->63->111cases produce20 and48 collisions, then UNKNOWN. Final5871vars20824cts starts search11.94s and returns15.014759s; total22.995023s algorithm23.688067s shared. All3complete candidates and2 negative diagnostics fail source checks, with zero stock failures and all90holes10026vertices retained; no new valid66 or native call. Preserve all5solver responses and overrun records. All constraints, prefixes, generated cases and saved original rings independently audited; every new case excludes its previous violating candidate. Next investigate a materially different continuous-rational QF_LRA formulation/solver with direct disjunctions of the audited conservative halfplanes,50 real XY variables, Boolean legal mode choices and all25 movers mandatory around unchangedfixed41. Official Z3 sources confirm MIT license, exact rationals and a linear-real arithmetic engine; full notice and source links are saved. No Z3 dependency installed or solver called. Verify a pinned wheel/version/license/hash in an isolated local environment, formulate and independently audit all111 known owner/mode exclusions, source-free domains, mandatory-part accounting, same-family ordering and a partial56 positive control; evaluate exact rational assignments and float-converted original geometry separately. Preserve the same constructive11mode subset and original source/native/material gates. Before solving freeze one60s total algorithm90s shared budget, no per-iteration reset, and stop after a no-candidate response; do not rerun any closed CP model or mislabel UNKNOWN as infeasibility. If the alternate engine is not suitable, use read-only geometry/encoding evidence to choose another substantive approach rather than reseeding. Preserve valid64,444 necessary allocations, originalH2 gate and22 unopened vectors. Maina0d6f9af contains the previous2checkpoints; CI40753599821 has4passes with Linux/Windows checks live. Queue this commit until all6pass, then fresh remote/live-run/ancestry guards for normal atomic push. Production/READMEs unchanged; no qualified release.'
write(OUT/'next-step.json',{'action':next_action,'completion_percent':60,'H2_complete':False,'H5_complete':False})
write(OUT/'checks.json',{'passed':True,'independent_audit_groups':6,'closed_sequences':2,'distinct_solver_calls':5,'complete_source_candidates_rejected':3,'negative_full66_diagnostics_rejected':2,'source_valid66_count':0,'all25_mandatory':True,'source56_control_is_partial_only':True,'source64_preserved':True,'remaining_necessary_allocations':444,'actual_or_global_infeasibility_claimed':False,'native_calls':0,'completion_percent':60,'H2_complete':False,'H5_complete':False,**archive})
report=f'''# Source collision generation — 2026-10-28

Two different bounded policies produced **three complete 66-part candidates**.
All three fail original-source collision checks and remain rejected. Both
sequences are closed; neither produces a valid full layout, an infeasibility
proof or H5 completion credit. H2/H5 remain open at **60% milestone weight**.

The first policy removes exactly 2,942 rectangle interval constraints and two
cumulative constraints from the previous relaxation. All 342 variables, 1,073
remaining constraints, mandatory-part requirements and hints are preserved.
This allows a complete candidate before the large capacity system is imposed;
the original-source acceptance tests remain unchanged. An intentionally
overlapping 66-part diagnostic passes the relaxed model and is correctly
rejected for **68 collisions**, with no stock failures.

The first solve returns a relaxation assignment in **0.302964 s**, retaining
all 15 hinted cog poses. Source readback finds **43 collisions**: three bracket
pairs, 12 bracket/cog pairs, seven cog/insert pairs and 21 insert pairs. The
next model adds all legal mode combinations for those 43 owner pairs:
**386 groups, 8,452 variables and 31,193 constraints**. Search begins only at
**13.26 s** and the call returns UNKNOWN without a candidate at **15.034608 s**.
The preserved solve soft overrun is **0.034608 s**. The whole sequence takes
**16.418178 s algorithm / 17.172596 s shared** and stops immediately.

The second policy changes the granularity: it constrains only the owner/mode
combinations actually observed colliding. Its first model already contains
those 43 cases from the saved rejected candidate; the old initial solve is
not repeated. Independent reading verifies **1,424 variables and 5,066
constraints**, all 43 exclusions, retained mandatory constraints and a valid
partial56 control. A complete diagnostic using unobserved bracket/insert modes
passes the relaxation and is correctly rejected for **65 source collisions**.
This demonstrates why every changed mode still needs full source validation.

| Mode-policy model | Cases | Variables / constraints | Source result | Returned solve |
|---|---:|---:|---|---:|
| 0 | 43 | 1,424 / 5,066 | Rejected: 20 collisions | 1.654828 s |
| 1 | 63 | 2,274 / 8,126 | Rejected: 48 collisions | 4.847328 s |
| 2 | 111 | 5,871 / 20,824 | UNKNOWN; no candidate | 15.014759 s |

Every newly observed case adds all conservative relative cells for that mode
combination. Unseen mode combinations stay unconstrained until source readback
exposes them. The independent reader verifies all saved model fields, unchanged
prefixes, every assignment and every new case; each new case excludes its
previous violating candidate. A no-solve preflight exercises all 66 intrinsic
mode domains, including reversed displacements and appending both a new mode
to an existing owner pair and a new owner pair.

The second sequence freezes at most 32 distinct models because its cuts are
finer, but retains **one 60-second algorithm budget, a 90-second shared limit
and at most 15 seconds per solve**. It stops at the third call, after
**22.995023 s algorithm / 23.688067 s shared**. Final presolve lasts to the
logged **11.94 s** search transition; the **0.014759 s solve soft overrun** is
preserved. Neither unused time nor an UNKNOWN response starts another call.
Solver OPTIMAL statuses apply only to the corresponding collision relaxation;
they do not certify a physically valid layout or optimal nesting.

Independent saved-ring readback checks all five invalid layouts: the two
negative diagnostics and three runtime candidates. Each retains **66 originals,
1,380 same-sheet pair checks, 264 stock edges, 90 holes and 10,026 hole vertices**.
All stock checks pass; the collision counts are respectively 68, 65, 43, 20
and 48. Every collision is between moving originals. No source-valid full66,
native validation, production integration or new H5 matrix result exists.

The current evidence points to substantial Boolean/cell preprocessing cost.
The next investigation is a direct continuous-rational formulation using the
same conservative halfplanes and all 111 observed mode cases. The official
[Z3 arithmetic guide](https://microsoft.github.io/z3guide/docs/theories/Arithmetic/)
describes its linear-real arithmetic engine; the
[Python guide](https://microsoft.github.io/z3guide/programming/Z3%20Python/Introduction/)
documents exact rational values. Its upstream MIT notice is saved in the raw
evidence. This is research only: **no Z3 package is installed and no Z3 solve
has run**. A pinned dependency, serialized-formula audit, rational readback,
float-conversion/source checks and one fixed budget are prerequisites.

The previous two checkpoints were pushed normally and atomically to main
**a0d6f9af** after all six prior checks passed.
[CI 40753599821](https://github.com/skulitom/Nestbolt/actions/runs/40753599821)
currently has four passing jobs; Linux and Windows checks remain live. This
checkpoint waits for all six jobs and fresh remote guards before pushing.
Production, READMEs and upstream heads/releases are unchanged. The valid64,
444 necessary allocations, original H2 gate and 22 unopened vectors remain
preserved. No new release qualifies.

Evidence: [owner-policy model audit]({NAME}/owner-model-audit.json),
[owner-policy response]({NAME}/owner-response-audit.json),
[mode-policy model audit]({NAME}/mode-model-audit.json),
[mode-policy response]({NAME}/mode-response-audit.json),
[independent original-ring readback]({NAME}/mode-originals-audit.json),
[continuous-arithmetic review]({NAME}/continuous-arithmetic-review.json),
[next step]({NAME}/next-step.json), [raw manifest]({NAME}/raw-manifest.json).
The verified archive contains {archive['archive_members']} canonical files and
{archive['verified_aliases']} identical-byte aliases in {archive['archive_bytes']:,}
compressed bytes, including every candidate, failure, model, assignment, source
readback, generated case, solver log/response and input dependency.
'''
with OUT.with_suffix('.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
note='''

**N4 complete source collision candidates, 2026-10-28:** [the evidence]({link})
preserves two closed generation policies and three complete66 candidates,
all rejected for43,20 and48 source collisions. All original stock/hole checks
pass, but no valid full layout or native claim follows. The first policy adds
all386 mode groups for43 owner pairs and returns UNKNOWN; the finer policy
starts with43 observed cases, adds20 then48, and also closes UNKNOWN at111 cases.
All model fields, prefixes, generated cases and saved original rings are
independently checked. Separate full66 negative diagnostics correctly fail
with68/65 collisions. Preserve both soft overruns and all five solver responses;
neither unused budget nor UNKNOWN authorizes a repeat. Next investigate direct
continuous-rational halfplane disjunctions after license/dependency/formula
audits; no alternate solver is installed or run yet. The previous two checkpoints
are pushed to main a0d6f9af; CI40753599821 has four passes and two live checks.
Production/READMEs, valid64,444 necessary allocations,H2 gate and22 unopened
vectors remain unchanged. H2/H5 stay open at60%; no new release qualifies.
'''
for a,b in [('complete66','complete 66-part'),('for43,20 and48','for 43, 20 and 48'),('all386','all 386'),('for43','for 43'),('with43','with 43'),('adds20 then48','adds 20 then 48'),('at111','at 111'),('full66','full 66-part'),('with68/65','with 68/65'),('CI40753599821','CI 40753599821'),('valid64,444','valid 64, 444'),('allocations,H2','allocations, H2'),('and22','and 22'),('at60%','at 60%')]:note=note.replace(a,b)
for n in ['BENCHMARKS.md','docs/PLAN_V1_1.md','docs/V1_1_RESEARCH.md','docs/STATUS.md']:append(ROOT/n,note.format(link=('' if n=='BENCHMARKS.md' else '../')+f'benchmarks/results/{NAME}.md'))
append(ROOT/'.gitattributes',f'\nbenchmarks/results/{NAME}/** -text -whitespace\n')
print({'sealed':NAME,**archive,'source_bindings':len(bindings),'completion_percent':60})
