"""Create and freeze the mode-case sequence, retaining a single60s budget."""
from pathlib import Path
from hashlib import sha256
import json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mode-collision-source-20261028';source=(ROOT/'output/run_h5_collision_constraint_generation_20261028.py').read_text(encoding='utf-8')
changes={
 'h5-collision-first-source-20261028':'h5-mode-collision-source-20261028',
 'from h5_collision_cp_reader_20261028 import audit':'from h5_mode_cp_reader_20261028 import audit',
 'from h5_lazy_cp_builder_20261028 import add_pairs':'from h5_mode_case_builder_20261028 import add_cases',
 'h5_lazy_cp_builder_20261028.py':'h5_mode_case_builder_20261028.py',
 'h5_collision_cp_reader_20261028.py':'h5_mode_cp_reader_20261028.py',
 'check_h5_collision_source_candidate_20261028.py':'check_h5_mode_source_candidate_20261028.py',
 'if pending:add_pairs(model,mp,pending,relative)':'if pending:add_cases(model,mp,pending,relative)',
 "'maximum_distinct_solves':8":"'maximum_distinct_solves':32",
 'for sequence in range(8):':'for sequence in range(32):',
 "'new_owner_pairs':pending":"'new_mode_cases':pending",
 "existing={(r['left'],r['right']) for r in mp['pairs']}":"existing={(r['left'],r['right'],g['left_mode'],g['right_mode']) for r in mp['pairs'] for g in r['groups']}",
 "pair=tuple(sorted([key_to_index[a],key_to_index[b]]));assert pair not in existing,'source collision contradicts existing pair cells';pending.append(pair)":"li,ri=sorted([key_to_index[a],key_to_index[b]]);ma,mb=[next(o['mode'] for o in mp['items'][i]['options'] if values[o['selector']]) for i in [li,ri]];case=(li,ri,ma,mb);assert case not in existing,'source collision contradicts an existing mode case';pending.append(case)",
 'next-owner-pairs.json':'next-mode-cases.json',
 "'pair_constraints':len(mp['pairs']),'max_solve_seconds'":"'pair_constraints':len(mp['pairs']),'mode_case_constraints':sum(len(p['groups']) for p in mp['pairs']),'max_solve_seconds'",
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
target=ROOT/'output/run_h5_mode_constraint_generation_20261028.py'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
assert not (BASE/'search').exists();audit=json.loads((BASE/'model-audit/checks.json').read_bytes());assert audit['passed'] and audit['unseen_modes_negative66_passes_model_but_source_rejects']
with (BASE/'runner-preflight.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'runner_sha256':sha256(target.read_bytes()).hexdigest(),'maximum_distinct_solves':32,'maximum_seconds_per_solve':15,'algorithm_seconds':60,'shared_seconds':90,'stop_after_no_candidate':True,'initial_model_already_contains43_observed_mode_cases':True,'same_previous_base_not_resolved':True,'source_rejection_diagnostic_passed':True,'solver_calls':0},f,indent=2);f.write('\n')
print({'runner':str(target),'model_audit_passed':True,'solver_calls':0})
