"""Separate Shapely process reconstructing each full candidate from original job rings."""
from pathlib import Path
from hashlib import sha256
import json,sys,time
from h5_legacy64_source_readback import audit
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-mode-collision-source-20261028';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def main():
    started=time.perf_counter();out=Path(sys.argv[1]).resolve();assert out.is_relative_to(BASE.resolve())
    plan=load(BASE/'plan.json');job=load(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json');rows=load(BASE/'fixed41.json');modes=load(BASE/'modes.json');mp=load(out/'mapping.json');sol=load(out/'assignment.json');poses=[]
    assert len(rows)==41 and len(mp['items'])==25
    for item in mp['items']:
        assert sol[item['presence']]==1;chosen=[o['mode'] for o in item['options'] if sol[o['selector']]];assert len(chosen)==1;m=modes[chosen[0]];x,y=sol[item['x']],sol[item['y']]
        poses.append({'family':item['family'],'copy_index':item['copy_index'],'mode':m['index'],'anchor_um':[x,y]})
        rows.append({'part_id':item['family'],'copy_index':item['copy_index'],'sheet_id':'sheet-0','transform':{'rotation_radians':m['angle'],'translation':[x/1000+m['source_translation_offset'][0],y/1000+m['source_translation_offset'][1]],'mirrored':m['mirrored']}})
    expected=[(p['id'],i) for p in job['parts'] for i in range(p['quantity'])];assert len(expected)==len(rows)==66
    result=audit(job,rows,plan['source_stocks'],plan['required_pair_gap_mm'],plan['stock_guard_mm'],expected)
    assert result['cutouts']==90 and result['hole_vertices']==10026 and result['same_sheet_pairs']==1380
    write(out/'candidate66.json',rows);write(out/'selected-poses.json',poses);write(out/'source-audit.json',{**result,'seconds':time.perf_counter()-started,'candidate_sha256':digest(out/'candidate66.json'),'job_sha256':digest(ROOT/'output/h5-coordinated-placement-selection-20261018/job.json')})
    print({k:v for k,v in result.items() if k not in ['pairs','stock']})
if __name__=='__main__':main()
