"""Create the independent saved-source reader for all three mode-policy cases."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];source=(ROOT/'output/audit_h5_collision_originals_20261028.py').read_text(encoding='utf-8').replace('h5-collision-first-source-20261028','h5-mode-collision-source-20261028')
old="[('negative-diagnostic',BASE/'colliding66-diagnostic',68),('rejected-candidate',BASE/'search/00',43)]"
new="[('negative-diagnostic',BASE/'colliding66-diagnostic',65),('rejected-candidate-00',BASE/'search/00',20),('rejected-candidate-01',BASE/'search/01',48)]"
assert old in source;source=source.replace(old,new).replace('both_invalid_layouts_preserved','all_three_invalid_layouts_preserved')
with (ROOT/'output/audit_h5_mode_originals_20261028.py').open('x',encoding='utf-8',newline='\n') as f:f.write(source)
