"""Create the new bounded sequence without reopening the old search directory."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-collision-first-source-20261028'
source=(ROOT/'output/run_h5_lazy_constraint_generation_20261028.py').read_text(encoding='utf-8')
changes={
 'h5-mixed25-lazy-source-20261028':'h5-collision-first-source-20261028',
 'from h5_lazy_cp_reader_20261028 import audit':'from h5_collision_cp_reader_20261028 import audit',
 "[BASE,BASE/'model',BASE/'capacity-audit',BASE/'pair-preflight']":"[BASE,BASE/'model',BASE/'model-audit']",
 'model/checks.json':'model-audit/checks.json',
 'pair-preflight/checks.json':'model-audit/pair-preflight-checks.json',
 'h5_lazy_cp_reader_20261028.py':'h5_collision_cp_reader_20261028.py',
 'check_h5_lazy_source_candidate_20261028.py':'check_h5_collision_source_candidate_20261028.py',
}
for a,b in changes.items():assert a in source,a;source=source.replace(a,b)
target=ROOT/'output/run_h5_collision_constraint_generation_20261028.py'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
with (BASE/'runner-preflight.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'runner_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'adapted_only_base_paths_and_reader':'The existing bounded-control implementation is reused with a new input model, source checker binding and independent reader. Budget/stop logic is byte-identical after these explicit substitutions.','maximum_distinct_solves':8,'maximum_seconds_per_solve':15,'algorithm_seconds':60,'shared_seconds':90,'negative_diagnostic_passed':json.loads((BASE/'model-audit/checks.json').read_bytes())['negative66_passes_relaxation_but_source_rejects'],'solver_calls':0},f,indent=2);f.write('\n')
print({'runner':str(target),'preflight':str(BASE/'runner-preflight.json')})
