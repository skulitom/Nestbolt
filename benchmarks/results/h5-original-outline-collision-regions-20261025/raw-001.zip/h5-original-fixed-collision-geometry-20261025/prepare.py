"""Floor-safe moving proxies against actual fixed original outer polygons."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
from fractions import Fraction
import json,math,shutil,time,traceback
import shapely
from shapely.geometry import Polygon,box,Point,mapping
from shapely.affinity import affine_transform,translate
from shapely.ops import unary_union
from conservative_h5_round_obstacles import raw_obstacle

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
PRIOR=ROOT/'output/h5-pair-core-relocation-regions-20261025'
OUT=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def transform(shape,t,zero=False):
    c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1
    return affine_transform(shape,[mi*c,-s,mi*s,c,*( [0.,0.] if zero else t['translation'])])

def main():
    OUT.mkdir();(OUT/'obstacles').mkdir();shutil.copyfile(__file__,OUT/'prepare.py')
    sourcepath=ROOT/load(SRC/'plan.json')['hint_source'];jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json'
    diskpath=ROOT/'output/h5-cog-center-capacity-20261020/disk.json'
    inputs=[SRC/n for n in ['plan.json','geometry.json','propagation.json','items.json','hint-poses.json']]
    inputs += [PRIOR/n for n in ['audit/checks.json','solve/positions.json','solution-audit/checks.json','solution-audit/angle-independent-cog-conflicts.json']]
    inputs += [sourcepath,jobpath,diskpath,ROOT/'benchmarks/results/h5-pair-core-relocation-and-outline-diagnosis-20261025/raw-manifest.json',
               ROOT/'output/conservative_h5_round_obstacles.py',ROOT/'output/diagnose_h5_concave_gaps.py']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'construction_limit_seconds':120,'maximum_cache_cases':100,'geometry_units_per_mm':10000,'coordinate_units_per_mm':100,
          'cog_polygon_vertex_radius_units':1091000,'conservative_forbidden_erosion_mm':0.001,
          'method':'Create a fixed-axis16-gon whose vertices remain strictly inside the certified cog disk after every corner of the0.01mm floor-center uncertainty square. Preserve the existing floor-safe rectangle components for every movable bracket orientation and the recorded horizontal frame inventory. Use all64 source original filled outer polygons as potential fixed obstacles. Deduplicate only identical family/rotation/mirror fixed styles; retain every original transform and owner. Construct zero-clearance Minkowski obstacles for all10 fixed styles by all10 moving proxies, eroding each by0.001mm and intersecting with its raw obstacle to exclude only a strict interior subset. Preserve every raw and eroded obstacle. Check all43 frame/bracket/cog source floor poses remain compatible with the other fixed originals. Diagnose the four selected false proxy placements against all62 remaining originals. This prepares necessary geometry only; no region census, solver call, layout acceptance or unrestricted exclusion.'})
    start=time.perf_counter();g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json');items=load(SRC/'items.json');hints=load(SRC/'hint-poses.json')
    source=load(sourcepath);job=load(jobpath);parts={p['id']:p for p in job['parts']};disk=load(diskpath)
    radius=disk['radius_units'];v_radius=1091000
    vertices=[[round(v_radius*math.cos(math.tau*k/16)),round(v_radius*math.sin(math.tau*k/16))] for k in range(16)]
    tests=[(v[0]-ex)**2+(v[1]-ey)**2 for v in vertices for ex in [0,100] for ey in [0,100]]
    assert max(tests)<radius**2
    cog=Polygon([(x/10000,y/10000) for x,y in vertices]);assert cog.is_valid and cog.equals(cog.convex_hull)
    moving=[]
    for cl in [c for c in g['classes'] if c['family']=='bracket' or c['index']==0]:
        rectangles=aux['inner_non_cog_components'][cl['index']]['components'];polygons=[box(*(x/100 for x in r)) for r in rectangles]
        moving.append({'index':len(moving),'family':cl['family'],'class':cl['index'],'components_units100':rectangles,
                       'component_polygons':[mapping(p) for p in polygons],'geometry':mapping(unary_union(polygons))})
    moving.append({'index':len(moving),'family':'cog','class':None,'vertices_units10000':vertices,
                   'component_polygons':[mapping(cog)],'geometry':mapping(cog)})
    assert len(moving)==10
    styles=[];lookup={};fixed=[];geometries={};style_shapes={};max_translation_error=0.
    for item in items:
        if item['source_index'] is None:continue
        p=source['placements'][item['source_index']];t=p['transform'];family=p['part_id'];key=(family,float(t['rotation_radians']).hex(),t['mirrored'])
        original=Polygon(parts[family]['geometry'][0]['outer']);actual=transform(original,t)
        if key not in lookup:
            index=len(styles);lookup[key]=index;local=transform(original,t,zero=True);style_shapes[index]=local
            styles.append({'index':index,'family':family,'rotation_hex':key[1],'mirrored':key[2],
                           'zero_transform':{**t,'translation':[0.,0.]},'geometry':mapping(local),'first_item':item['index']})
        index=lookup[key];shifted=translate(style_shapes[index],*t['translation']);error=actual.hausdorff_distance(shifted)
        assert error<1e-7;max_translation_error=max(max_translation_error,error)
        geometries[item['index']]=actual
        fixed.append({'item':item['index'],'source_index':item['source_index'],'family':family,'sheet':int(p['sheet_id'][-1]),
                      'style':index,'transform':t,'geometry':mapping(actual),'translation_hausdorff_error_mm':error})
    assert len(styles)==10 and len(fixed)==64 and Counter(r['family'] for r in fixed)=={'frame':18,'bracket':10,'insert':21,'cog':15}
    write(OUT/'moving-proxies.json',moving);write(OUT/'fixed-styles.json',styles);write(OUT/'fixed-originals.json',fixed)
    write(OUT/'cog-floor-certificate.json',{'disk_source':diskpath.relative_to(ROOT).as_posix(),'disk_sha256':digest(diskpath),
          'radius_units':radius,'geometry_units_per_mm':10000,'floor_error_corners_units':[[0,0],[0,100],[100,0],[100,100]],
          'vertices_units':vertices,'vertex_error_corner_checks':64,'maximum_squared_distance':max(tests),
          'strict_squared_margin':radius**2-max(tests),'convexity_extends_vertex_and_corner_checks_to_all_points_and_errors':True})
    planned=[{'index':len(styles)*0+si*len(moving)+mi,'fixed_style':si,'moving_proxy':mi} for si in range(len(styles)) for mi in range(len(moving))]
    write(OUT/'cache-plan.json',planned);completed=[];cache={};minimum_margin=float('inf')
    for q in planned:
        if time.perf_counter()-start>=120:break
        fixedshape=style_shapes[q['fixed_style']];m=moving[q['moving_proxy']]
        shape=shapely.geometry.shape(m['geometry']);raw=raw_obstacle(fixedshape,shape)
        exclusion=raw.buffer(-.001,quad_segs=8).intersection(raw)
        assert raw.is_valid and exclusion.is_valid and not exclusion.is_empty and exclusion.difference(raw).is_empty
        margin=exclusion.distance(raw.boundary);assert margin>.0005;minimum_margin=min(minimum_margin,margin)
        row={**q,'raw_forbidden':mapping(raw),'strict_interior_exclusion':mapping(exclusion),
             'actual_boundary_margin_mm':margin,'raw_area_mm2':raw.area,'excluded_area_mm2':exclusion.area}
        write(OUT/'obstacles'/f"{q['index']:03d}.json",row);cache[(q['fixed_style'],q['moving_proxy'])]=exclusion;completed.append(q['index'])
    pending=planned[len(completed):];write(OUT/'pending.json',pending)
    write(OUT/'generation.json',{'seconds':time.perf_counter()-start,'fixed_originals':64,'fixed_styles':10,'moving_proxies':10,
          'cache_cases_planned':100,'cache_cases_completed':len(completed),'pending_cases':len(pending),
          'cog_vertex_floor_corner_checks':64,'maximum_source_translation_error_mm':max_translation_error,
          'minimum_raw_boundary_exclusion_margin_mm':minimum_margin,'solver_calls':0,'full_target_witness':False,'H5_complete':False})
    if pending:print(load(OUT/'generation.json'),flush=True);return
    # Known original source poses are compatible; the new necessary proxy cannot exclude them.
    moving_by_class={m['class']:m['index'] for m in moving};sanity=[]
    for h in hints:
        if h['family']=='insert':continue
        mi=moving_by_class[h['representative_class']];tested=0
        for r in fixed:
            if r['item']==h['item'] or r['sheet']!=h['sheet']:continue
            point=Point(h['x_units']/100-r['transform']['translation'][0],h['y_units']/100-r['transform']['translation'][1])
            assert not cache[(r['style'],mi)].covers(point),(h['item'],r['item']);tested+=1
        sanity.append({'item':h['item'],'moving_proxy':mi,'compatible_fixed_originals_checked':tested})
    solution=load(PRIOR/'solve/positions.json');failures=[];selected_checks=0
    for p in solution['movable_parts']:
        mi=moving_by_class[p['class']]
        for r in fixed:
            if r['item'] in solution['released_items'] or r['sheet']!=p['sheet']:continue
            point=Point(p['x_units']/100-r['transform']['translation'][0],p['y_units']/100-r['transform']['translation'][1]);exclusion=cache[(r['style'],mi)]
            selected_checks+=1
            if exclusion.contains(point):failures.append({'part':p['part'],'role':p['role'],'moving_family':p['family'],
                 'fixed_item':r['item'],'fixed_family':r['family'],'fixed_style':r['style'],'moving_proxy':mi,
                 'local_anchor':[point.x,point.y],'distance_to_exclusion_boundary_mm':point.distance(exclusion.boundary)})
    assert all(any(r['part']==3 and r['fixed_item']==i for r in failures) for i in [57,62])
    write(OUT/'source-sanity.json',sanity);write(OUT/'selected-anchor-conflicts.json',failures)
    write(OUT/'diagnosis.json',{'source_poses_checked':len(sanity),'compatible_source_pairs_checked':sum(r['compatible_fixed_originals_checked'] for r in sanity),
          'selected_anchor_fixed_original_checks':selected_checks,'selected_anchor_conflicts':len(failures),
          'both_prior_robust_disk_conflicts_rejected':True,'all_source_poses_preserved':True,
          'other_coordinates_or_neighborhoods_excluded':False,'solver_calls':0,'H5_complete':False})
    print(load(OUT/'generation.json'),flush=True);print(load(OUT/'diagnosis.json'),flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
