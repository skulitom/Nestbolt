"""Independent rational subset certificates and unmerged-triangle Minkowski oracle."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from datetime import datetime,timezone
from itertools import product
from collections import Counter
import json,math,shutil,time,traceback
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint,Point,box,shape
from shapely.affinity import translate
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'output/h5-source-orientation-construction-20261025';PRIOR=ROOT/'output/h5-pair-core-relocation-regions-20261025'
BASE=ROOT/'output/h5-original-fixed-collision-geometry-20261025';OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    plan=load(BASE/'plan.json');generation=load(BASE/'generation.json');sourcepath=ROOT/load(SRC/'plan.json')['hint_source']
    jobpath=ROOT/'output/h5-coordinated-placement-selection-20261018/job.json';diskpath=ROOT/'output/h5-cog-center-capacity-20261020/disk.json'
    inputs=[BASE/n for n in ['plan.json','generation.json','moving-proxies.json','fixed-styles.json','fixed-originals.json',
                            'cog-floor-certificate.json','cache-plan.json','source-sanity.json','selected-anchor-conflicts.json','diagnosis.json']]
    inputs += [sourcepath,jobpath,diskpath,SRC/'geometry.json',SRC/'propagation.json',SRC/'items.json',SRC/'hint-poses.json',PRIOR/'solve/positions.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'audit_limit_seconds':120,'obstacle_hashes':{p.name:digest(p) for p in sorted((BASE/'obstacles').glob('*.json'))},
          'method':'Re-prove the original inscribed disk with rational winding and all80 original edge distances; certify every new16-gon vertex over all four floor-error corners using exact integers. Independently reconstruct every non-cog quarter-turn/reflection and verify all inner rectangle vertices for every floor-error corner. Check the old five cog rectangles are contained in the new polygon with exact integer halfplanes. Reconstruct64 actual original transforms. For all100 local obstacles, use unmerged constrained triangles and direct moving-component vertex sums as an independent Minkowski oracle; verify raw agreement and strict eroded-exclusion subset. Independently recheck all source-compatible proxy poses and selected false anchors using direct original/proxy intersections.'})
    start=time.perf_counter();assert generation['cache_cases_completed']==generation['cache_cases_planned']==100 and not load(BASE/'pending.json')
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    manifest=ROOT/'benchmarks/results/h5-pair-core-relocation-and-outline-diagnosis-20261025/raw-manifest.json'
    mf=load(manifest);files=mf['files']+mf['aliases'];provenance=[]
    for p in [sourcepath,jobpath,diskpath]+[SRC/n for n in ['plan.json','geometry.json','propagation.json','items.json','hint-poses.json']]+[PRIOR/'solve/positions.json',PRIOR/'solution-audit/checks.json']:
        matches=[r for r in files if r['sha256']==digest(p)];assert matches,p
        provenance.append({'source':p.relative_to(ROOT).as_posix(),'sha256':digest(p),'manifest':manifest.relative_to(ROOT).as_posix(),
                           'manifest_sha256':digest(manifest),'member':matches[0]['path']})
    job=load(jobpath);parts={p['id']:p for p in job['parts']};disk=load(diskpath);source=load(sourcepath)
    g=load(SRC/'geometry.json');aux=load(SRC/'propagation.json');items=load(SRC/'items.json');hints=load(SRC/'hint-poses.json')
    center=[F(*v) for v in disk['center']];radius=F(disk['radius_units'],10000);outer=[[F(v) for v in p] for p in parts['cog']['geometry'][0]['outer']]
    winding=0;distance_margin=[]
    for a,b in zip(outer,outer[1:]+outer[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1];px,py=center[0]-a[0],center[1]-a[1]
        cross=dx*py-dy*px
        if a[1]<=center[1]<b[1] and cross>0:winding+=1
        if b[1]<=center[1]<a[1] and cross<0:winding-=1
        dot=px*dx+py*dy;length=dx*dx+dy*dy
        distance2=px*px+py*py if dot<=0 else (center[0]-b[0])**2+(center[1]-b[1])**2 if dot>=length else cross*cross/length
        assert distance2>radius*radius;distance_margin.append(distance2-radius*radius)
    assert winding!=0 and len(distance_margin)==80
    moving=load(BASE/'moving-proxies.json');styles=load(BASE/'fixed-styles.json');fixed=load(BASE/'fixed-originals.json');certificate=load(BASE/'cog-floor-certificate.json')
    vertices=certificate['vertices_units'];assert len(vertices)==16 and vertices==moving[-1]['vertices_units10000']
    squared=[(x-ex)**2+(y-ey)**2 for x,y in vertices for ex,ey in product([0,100],repeat=2)]
    assert max(squared)<disk['radius_units']**2 and max(squared)==certificate['maximum_squared_distance']
    assert certificate['strict_squared_margin']==disk['radius_units']**2-max(squared)
    # Exact oriented edge checks prove convexity and old inner-proxy containment.
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        assert all((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])>=0 for p in vertices)
    old_points=[(r[x]*100,r[y]*100) for r in aux['cog_inner_components'] for x,y in [(0,1),(2,1),(2,3),(0,3)]]
    containment=[]
    for p in old_points:
        for a,b in zip(vertices,vertices[1:]+vertices[:1]):
            cross=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);assert cross>0;containment.append(cross)
    cog=Polygon([(x/10000,y/10000) for x,y in vertices]);assert shape(moving[-1]['geometry']).equals(cog)
    assert shape(moving[-1]['component_polygons'][0]).equals(cog)
    rect_checks=0;moving_shapes={};expected_classes=[0]+list(range(4,12));assert [m['class'] for m in moving[:-1]]==expected_classes
    for m in moving[:-1]:
        cl=g['classes'][m['class']];family=cl['family'];assert family==m['family']
        original=[]
        for x,y in parts[family]['geometry'][0]['outer']:
            assert float(x).is_integer() and float(y).is_integer();x,y=int(x),int(y)
            if cl['mirrored']:x=-x
            original.append([(x,y),(-y,x),(-x,-y),(y,-x)][cl['quarter_turn']])
        minima=[min(p[k] for p in original) for k in [0,1]]
        polygon=Polygon([(x-minima[0],y-minima[1]) for x,y in original])
        assert unary_union([box(*r) for r in cl['components']]).equals(polygon)
        inner=m['components_units100'];assert inner==aux['inner_non_cog_components'][cl['index']]['components']
        for r,outer_r in zip(inner,cl['components']):
            assert r==[int(outer_r[k])*100+(1 if k<2 else -1) for k in range(4)]
            for x,y in [(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])]:
                for ex,ey in product([0,1],repeat=2):
                    assert outer_r[0]*100<=x-ex<=outer_r[2]*100 and outer_r[1]*100<=y-ey<=outer_r[3]*100;rect_checks+=1
        pieces=[box(*(v/100 for v in r)) for r in inner]
        assert len(pieces)==len(m['component_polygons']) and all(p.equals(shape(s)) for p,s in zip(pieces,m['component_polygons']))
        assert unary_union(pieces).equals(shape(m['geometry']));moving_shapes[m['index']]=pieces
    moving_shapes[moving[-1]['index']]=[cog]
    byitem={};maximum_source_error=0.;style_triangles={}
    for r in fixed:
        item=items[r['item']];p=source['placements'][item['source_index']];t=p['transform'];assert r['source_index']==item['source_index'] and r['transform']==t and r['family']==p['part_id'] and r['sheet']==int(p['sheet_id'][-1])
        c,s=math.cos(t['rotation_radians']),math.sin(t['rotation_radians']);mi=-1 if t['mirrored'] else 1;tx,ty=t['translation']
        coords=[(mi*x*c-y*s+tx,mi*x*s+y*c+ty) for x,y in parts[p['part_id']]['geometry'][0]['outer']]
        actual=Polygon(coords);saved=shape(r['geometry']);err=actual.hausdorff_distance(saved);assert err<1e-7;maximum_source_error=max(maximum_source_error,err);byitem[r['item']]=actual
        style=styles[r['style']];assert style['family']==r['family'] and style['rotation_hex']==float(t['rotation_radians']).hex() and style['mirrored']==t['mirrored']
        local=Polygon([(mi*x*c-y*s,mi*x*s+y*c) for x,y in parts[r['family']]['geometry'][0]['outer']]);assert local.hausdorff_distance(shape(style['geometry']))<1e-7
        assert actual.hausdorff_distance(translate(local,tx,ty))<1e-7
    assert len(fixed)==64 and len(byitem)==64 and len(styles)==len({(s['family'],s['rotation_hex'],s['mirrored']) for s in styles})==10
    triangle_count=0
    for st in styles:
        local=shape(st['geometry']);triangles=list(shapely.constrained_delaunay_triangles(local).geoms)
        assert triangles and unary_union(triangles).equals(local)
        assert all(t.equals(t.convex_hull) and len(t.exterior.coords)==4 for t in triangles)
        style_triangles[st['index']]=triangles;triangle_count+=len(triangles)
    rows=[];cache={};hull_count=0;max_hd=0.;max_area=0.;min_margin=float('inf')
    expected=[{'index':si*10+mi,'fixed_style':si,'moving_proxy':mi} for si in range(10) for mi in range(10)]
    assert load(BASE/'cache-plan.json')==expected
    for q in expected:
        assert time.perf_counter()-start<120
        stored=load(BASE/'obstacles'/f"{q['index']:03d}.json");assert all(stored[k]==v for k,v in q.items())
        hulls=[]
        for triangle,part in product(style_triangles[q['fixed_style']],moving_shapes[q['moving_proxy']]):
            points=[(a[0]-b[0],a[1]-b[1]) for a in list(triangle.exterior.coords)[:-1] for b in list(part.exterior.coords)[:-1]]
            hulls.append(MultiPoint(points).convex_hull)
        reconstructed=unary_union(hulls);hull_count+=len(hulls);raw=shape(stored['raw_forbidden']);exclusion=shape(stored['strict_interior_exclusion'])
        hd=raw.hausdorff_distance(reconstructed);symmetric=raw.symmetric_difference(reconstructed).area
        assert hd<1e-7 and symmetric<1e-4,(q,hd,symmetric)
        assert exclusion.difference(reconstructed).is_empty and exclusion.is_valid and not exclusion.is_empty
        margin=exclusion.distance(reconstructed.boundary);assert margin>.0005
        assert abs(stored['raw_area_mm2']-raw.area)<1e-7 and abs(stored['excluded_area_mm2']-exclusion.area)<1e-7
        max_hd=max(max_hd,hd);max_area=max(max_area,symmetric);min_margin=min(min_margin,margin)
        cache[(q['fixed_style'],q['moving_proxy'])]=exclusion
        rows.append({**q,'triangle_minkowski_hulls':len(hulls),'raw_hausdorff_error_mm':hd,'raw_symmetric_difference_mm2':symmetric,'strict_exclusion_margin_mm':margin})
    moving_by_class={m['class']:m['index'] for m in moving};source_sanity=[];source_intersections=0
    for h in hints:
        if h['family']=='insert':continue
        mi=moving_by_class[h['representative_class']];anchor=[h['x_units']/100,h['y_units']/100]
        proxy=translate(unary_union(moving_shapes[mi]),*anchor);checked=0
        for r in fixed:
            if r['item']==h['item'] or r['sheet']!=h['sheet']:continue
            point=Point(anchor[0]-r['transform']['translation'][0],anchor[1]-r['transform']['translation'][1])
            assert not cache[(r['style'],mi)].covers(point)
            assert proxy.intersection(byitem[r['item']]).is_empty
            checked+=1;source_intersections+=1
        source_sanity.append({'item':h['item'],'moving_proxy':mi,'compatible_fixed_originals_checked':checked})
    assert source_sanity==load(BASE/'source-sanity.json')
    solution=load(PRIOR/'solve/positions.json');conflicts=[];diagnoses=[]
    for p in solution['movable_parts']:
        mi=moving_by_class[p['class']];anchor=[p['x_units']/100,p['y_units']/100];proxy=translate(unary_union(moving_shapes[mi]),*anchor)
        for r in fixed:
            if r['item'] in solution['released_items'] or r['sheet']!=p['sheet']:continue
            point=Point(anchor[0]-r['transform']['translation'][0],anchor[1]-r['transform']['translation'][1]);exclusion=cache[(r['style'],mi)]
            actual_area=proxy.intersection(byitem[r['item']]).area;blocked=exclusion.contains(point)
            if blocked:
                assert actual_area>1e-7
                conflicts.append({'part':p['part'],'role':p['role'],'moving_family':p['family'],'fixed_item':r['item'],
                    'fixed_family':r['family'],'fixed_style':r['style'],'moving_proxy':mi,'local_anchor':[point.x,point.y],
                    'distance_to_exclusion_boundary_mm':point.distance(exclusion.boundary)})
            diagnoses.append({'part':p['part'],'fixed_item':r['item'],'conservatively_excluded':blocked,'direct_intersection_area_mm2':actual_area})
    assert conflicts==load(BASE/'selected-anchor-conflicts.json')
    assert all(any(r['part']==3 and r['fixed_item']==i for r in conflicts) for i in [57,62])
    write(OUT/'provenance.json',{'source_members_matching_committed_evidence':provenance});write(OUT/'obstacle-checks.json',rows)
    write(OUT/'selected-direct-intersections.json',diagnoses)
    checks={'passed':True,'seconds':time.perf_counter()-start,'committed_source_matches':len(provenance),
            'original_cog_edges_exactly_checked':80,'exact_winding_number':winding,'cog_vertex_floor_corner_checks':64,
            'strict_cog_floor_squared_margin_units':disk['radius_units']**2-max(squared),
            'non_cog_vertex_floor_corner_checks':rect_checks,'old_cog_rectangles_strict_subset_halfplane_checks':len(containment),
            'original_fixed_transforms':64,'fixed_styles':10,'moving_proxies':10,'unmerged_fixed_triangles':triangle_count,
            'independent_minkowski_component_hulls':hull_count,'complete_cache_cases':100,
            'maximum_source_transform_error_mm':maximum_source_error,'maximum_raw_obstacle_hausdorff_error_mm':max_hd,
            'maximum_raw_obstacle_symmetric_difference_mm2':max_area,'minimum_exclusion_interior_margin_mm':min_margin,
            'source_poses_preserved':len(source_sanity),'direct_source_compatibility_pairs':source_intersections,
            'selected_anchor_pairs_checked':len(diagnoses),'selected_anchor_conflicts':len(conflicts),
            'both_prior_angle_independent_conflicts_rejected':True,'every_exclusion_is_strict_subset_of_independent_raw_obstacle':True,
            'full_floor_error_square_and_all_cog_angles_covered':True,'free_region_census_or_solver_executed':False,
            'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
