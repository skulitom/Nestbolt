from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/h5-original-fixed-collision-geometry-20261025/source-sync'
OUT.mkdir()
r=subprocess.run(['gh','run','view','40233299884','--json','status,conclusion,jobs,headSha,url'],cwd=ROOT,capture_output=True)
(OUT/'ci.stderr.txt').write_bytes(r.stderr)
assert r.returncode==0,r.stderr.decode(errors='replace')
ci=json.loads(r.stdout)
assert ci['headSha']=='247e823a9feef2bf906e27204981b957dc55cdfc'
for name,value in [('main-ci.json',ci),('snapshot.json',{'utc':datetime.now(timezone.utc).isoformat(),'run_id':40233299884,
        'status':ci['status'],'conclusion':ci['conclusion'],'successful_jobs':sum(j['conclusion']=='success' for j in ci['jobs']),
        'total_jobs':len(ci['jobs']),'same_run_not_restarted':True})]:
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.loads((OUT/'snapshot.json').read_bytes()))
