"""Preserve the mixed-dimension guard failure and resume only unfinished queries."""
from pathlib import Path
from datetime import datetime
from hashlib import sha256
import json,time
ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'output/h5-original-fixed-pair-regions-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
plan=load(OLD/'plan.json');done=sorted((OLD/'queries').glob('*.json'))
assert len(done)==1262 and [p.name for p in done]==[f'{i:04d}.json' for i in range(1262)]
wall=(OLD/'failure.txt').stat().st_mtime-datetime.fromisoformat(plan['utc']).timestamp()
assert 0<wall<15 and not (OLD/'result.json').exists()
source=ROOT/'output/build_h5_original_fixed_pair_regions.py'
target=ROOT/'output/build_h5_original_fixed_pair_regions_recovered.py'
text=source.read_text(encoding='utf-8')
replacements=[
 ("OUT=ROOT/'output/h5-original-fixed-pair-regions-20261025'", "OLD=ROOT/'output/h5-original-fixed-pair-regions-20261025'\nOUT=ROOT/'output/h5-original-fixed-pair-regions-recovered-20261025'"),
 ("'construction_limit_seconds':120", "'construction_limit_seconds':60,'original_total_construction_limit_seconds':120,'first_failed_phase_charged_seconds':60,'completed_queries_reused_unchanged':1262"),
 ("    start=time.perf_counter();local=", "    original_plan=load(OLD/'plan.json');assert queries==original_plan['queries'] and case_specs==original_plan['cases']\n    shutil.copyfile(OLD/'failure.txt',OUT/'original-failure.txt');shutil.copyfile(OLD/'build.py',OUT/'original-build.py');shutil.copyfile(OLD/'plan.json',OUT/'original-plan.json')\n    shutil.copyfile(ROOT/'output/h5-pair-region-recovery-plan.json',OUT/'recovery-plan.json')\n    for i in range(1262):shutil.copyfile(OLD/'queries'/f'{i:04d}.json',OUT/'queries'/f'{i:04d}.json')\n    start=time.perf_counter();local="),
 ("    results=[];vertices=0\n    for q in queries:", "    results=[];vertices=0\n    for i in range(1262):\n        r=load(OUT/'queries'/f'{i:04d}.json');q=r['query'];assert q==queries[i];assert digest(OUT/'queries'/f'{i:04d}.json')==digest(OLD/'queries'/f'{i:04d}.json')\n        vertices+=r['output_vertices'];results.append({'query':i,'case':q['case'],'role':q['role'],'sheet':q['sheet'],'empty':r['free_empty'],'area_mm2':r['free_area_mm2'],'vertices':r['output_vertices']})\n    for q in queries[1262:]:"),
 ("if time.perf_counter()-start>=120 or vertices>=1000000", "if time.perf_counter()-start>=60 or vertices>=1000000"),
 ("        assert free.difference(cover).is_empty", "        # GEOS mixed-dimension self-difference can throw despite a valid result.\n        # The subtraction above is unchanged. Independent coverage is audited\n        # component by component; this optional reverse-subset guard is omitted."),
 ("'time_limit_reached':bool(pending) and time.perf_counter()-start>=120", "'time_limit_reached':bool(pending) and time.perf_counter()-start>=60,'completed_queries_reused_unchanged':1262,'queries_newly_completed':len(results)-1262,'first_failed_phase_charged_seconds':60")]
for old,new in replacements:
    assert text.count(old)==1,(old,text.count(old));text=text.replace(old,new)
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
record={'original_source':source.relative_to(ROOT).as_posix(),'original_source_sha256':digest(source),
        'corrected_source':target.relative_to(ROOT).as_posix(),'corrected_source_sha256':digest(target),
        'original_plan':(OLD/'plan.json').relative_to(ROOT).as_posix(),'original_plan_sha256':digest(OLD/'plan.json'),
        'original_failure':(OLD/'failure.txt').relative_to(ROOT).as_posix(),'original_failure_sha256':digest(OLD/'failure.txt'),
        'completed_queries':1262,'first_unwritten_query':1262,'total_planned_queries':len(plan['queries']),
        'completed_query_hashes':{p.name:digest(p) for p in done},'wall_seconds_plan_to_failure':wall,
        'original_limit_seconds':120,'failed_phase_conservative_charge_seconds':60,'remaining_query_limit_seconds':60,
        'reason':'GEOS raised an overlay-dimension assertion only in the optional free.difference(cover) reverse-subset guard, after the required cover.difference(forbidden) calculation succeeded. A reverse-subset guard is not necessary to show an outer relaxation covers admissible anchors. Preserve the original failure and every completed result. Continue the exact same subtraction and all queries with only the faulty optional guard omitted; audit coverage and component geometry independently before any exclusion. No cap was reached. No completed query or solver call is repeated.',
        'replacements':[{'old':a,'new':b} for a,b in replacements]}
with (ROOT/'output/h5-pair-region-recovery-plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print({k:record[k] for k in ['completed_queries','first_unwritten_query','total_planned_queries','wall_seconds_plan_to_failure','remaining_query_limit_seconds']})
