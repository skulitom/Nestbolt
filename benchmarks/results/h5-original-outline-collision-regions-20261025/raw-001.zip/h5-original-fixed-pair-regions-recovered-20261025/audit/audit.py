"""Component-wise reconstruction and outward coverage certificates for all regions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil,time,traceback
from shapely.geometry import Point,LineString,box,shape,mapping,GeometryCollection
from shapely.affinity import translate
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'output/h5-original-fixed-pair-regions-recovered-20261025'
OLD=ROOT/'output/h5-original-fixed-pair-regions-20261025'
GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
PRIOR=ROOT/'output/h5-pair-core-relocation-regions-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
OUT=BASE/'audit'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def leaves(g):
    if g.is_empty:return []
    if hasattr(g,'geoms'):return [v for p in g.geoms for v in leaves(p)]
    return [g]

def main():
    OUT.mkdir();(OUT/'covers').mkdir();shutil.copyfile(__file__,OUT/'audit.py')
    plan=load(BASE/'plan.json');result=load(BASE/'result.json');recovery=load(BASE/'recovery-plan.json')
    inputs=[BASE/n for n in ['plan.json','result.json','recovery-plan.json','case-availability.json']]
    inputs += [GEO/n for n in ['audit/checks.json','fixed-originals.json','moving-proxies.json']]
    inputs += [PRIOR/'audit/surviving-neighborhoods.json',PRIOR/'solve/positions.json',SRC/'hint-poses.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'audit_limit_seconds':120,'outward_cover_padding_parameter_mm':0.001,
          'query_hashes':{p.name:digest(p) for p in sorted((BASE/'queries').glob('*.json'))},
          'method':'Verify exhaustive role/mode coverage for all229 cases and424 prior allocations, plus byte-identical reuse of1262 completed pre-failure queries. Reconstruct all remaining fixed-owner obstacles without the construction intersection filter. Reconstruct free space independently for each prior cell primitive separately, so mixed-dimensional overlay is never used for a reverse-subset guard. Union positively padded primitive outputs from both reconstructions; preserve every point/line and use a0.001mm positive padding parameter only as a numerical outer cover, not an acceptance tolerance. Verify this polygonal cover contains every raw free primitive and that cover union independently reconstructed forbidden geometry covers EVERY WHOLE prior cell. This is a complete outer-coverage certificate including all integer anchors, not sampling. Recompute empty-role allocations from these certified outward covers. No solver or accepted layout.'})
    start=time.perf_counter();assert load(GEO/'audit/checks.json')['passed']
    assert result['queries_completed']==result['queries_planned']==2650 and result['cases_completed']==229
    assert not load(BASE/'pending.json') and not result['vertex_cap_reached'] and not result['time_limit_reached']
    assert result['queries_newly_completed']==1388 and result['completed_queries_reused_unchanged']==1262
    assert recovery['failed_phase_conservative_charge_seconds']+recovery['remaining_query_limit_seconds']==120
    assert recovery['wall_seconds_plan_to_failure']<60 and result['seconds']<60
    for name,h in recovery['completed_query_hashes'].items():assert digest(OLD/'queries'/name)==digest(BASE/'queries'/name)==h
    for n,h in plan['inputs'].items():assert digest(ROOT/n)==h
    for name,h in plan['obstacle_hashes'].items():assert digest(GEO/'obstacles'/name)==h
    for name,h in plan['prior_case_hashes'].items():assert digest(PRIOR/'cases'/f'{int(name):03d}.json')==h
    survivors=load(PRIOR/'audit/surviving-neighborhoods.json');cases={s['case']:load(PRIOR/'cases'/f"{s['case']:03d}.json") for s in survivors}
    moving=load(GEO/'moving-proxies.json');byclass={m['class']:m['index'] for m in moving};fixed=load(GEO/'fixed-originals.json')
    expected=[];expected_cases=[]
    for s in survivors:
        ids=[]
        for row in cases[s['case']]['queries']:
            q=row['query'];allowed=set()
            for a in s['surviving_allocations']:
                if q['role']=='bracket':allowed.update(sheet for sheet in [0,1] if a['brackets_per_sheet'][sheet])
                else:allowed.add(a['restored_sheets'][int(q['role'][-1])])
            if q['sheet'] not in allowed:continue
            i=len(expected);expected.append({'index':i,'case':s['case'],'prior_query':q['index'],'role':q['role'],
                   'family':q['family'],'mode':q['mode'],'class':q['class'],'sheet':q['sheet'],'moving_proxy':byclass[q['class']]});ids.append(i)
        expected_cases.append({**s,'queries':ids})
    assert plan['queries']==expected and plan['cases']==expected_cases
    local={(q['fixed_style'],q['moving_proxy']):shape(load(GEO/'obstacles'/f"{q['index']:03d}.json")['strict_interior_exclusion']) for q in load(GEO/'cache-plan.json')}
    absolute={(r['item'],mi):translate(local[(r['style'],mi)],*r['transform']['translation']) for r in fixed for mi in range(10)}
    hintmap={h['item']:h for h in load(SRC/'hint-poses.json')};query_checks=[];cells_checked=lower_cells=raw_primitives=independent_primitives=source_pose_checks=0
    max_added_area=0.;covers={};empty_changes=[]
    for q in expected:
        assert time.perf_counter()-start<120
        saved=load(BASE/'queries'/f"{q['index']:04d}.json");assert saved['query']==q
        case=cases[q['case']];owners=case['case']['released_items'];row=case['queries'][q['prior_query']]
        primitives=[]
        for r in row['free_integer_cells']:
            lo=(r[0]/100,r[1]/100);hi=(r[2]/100,r[3]/100)
            if lo==hi:g=Point(lo);lower_cells+=1
            elif r[0]==r[2] or r[1]==r[3]:g=LineString([lo,hi]);lower_cells+=1
            else:g=box(lo[0],lo[1],hi[0],hi[1])
            primitives.append(g)
        remaining=[r['item'] for r in fixed if r['sheet']==q['sheet'] and r['item'] not in owners]
        assert remaining==saved['remaining_fixed_items']
        all_forbidden=unary_union([absolute[(i,q['moving_proxy'])] for i in remaining]) if remaining else GeometryCollection()
        prior_cover=unary_union(primitives) if primitives else GeometryCollection()
        recorded_cover=shape(saved['prior_closed_cell_cover']);assert prior_cover.equals(recorded_cover)
        relevant=[i for i in remaining if not prior_cover.is_empty and absolute[(i,q['moving_proxy'])].intersects(prior_cover)]
        assert relevant==saved['intersecting_fixed_items']
        raw=shape(saved['free_outer_region']);assert raw.is_valid and raw.is_empty==saved['free_empty']
        old_leaves=leaves(raw);new_leaves=[]
        for primitive in primitives:new_leaves.extend(leaves(primitive.difference(all_forbidden)))
        # Positive buffers contain each primitive, including isolated lines and
        # points. Their union is a deliberate outer cover, never accepted geometry.
        padded=[p.buffer(.001,quad_segs=8,cap_style='square',join_style='mitre') for p in old_leaves+new_leaves]
        cover=unary_union(padded) if padded else GeometryCollection();assert cover.is_valid
        assert all(cover.covers(p) for p in old_leaves+new_leaves)
        complete=unary_union([cover,all_forbidden]);assert all(complete.covers(p) for p in primitives)
        cells_checked+=len(primitives);raw_primitives+=len(old_leaves);independent_primitives+=len(new_leaves)
        if cover.is_empty!=raw.is_empty:empty_changes.append(q['index'])
        max_added_area=max(max_added_area,cover.area-raw.area)
        if q['role']!='bracket':
            hint=hintmap[owners[int(q['role'][-1])]]
            if hint['sheet']==q['sheet'] and hint['mode']==q['mode']:
                point=Point(hint['x_units']/100,hint['y_units']/100);assert cover.covers(point);source_pose_checks+=1
        record={'query':q['index'],'case':q['case'],'role':q['role'],'sheet':q['sheet'],'empty':cover.is_empty,
                'whole_prior_cells_covered':len(primitives),'raw_free_primitives':len(old_leaves),
                'independent_free_primitives':len(new_leaves),'outward_cover_area_mm2':cover.area,
                'extra_outer_area_mm2':cover.area-raw.area,'cover':mapping(cover)}
        write(OUT/'covers'/f"{q['index']:04d}.json",record);covers[q['index']]=cover
        query_checks.append({k:v for k,v in record.items() if k!='cover'})
        if len(query_checks)%500==0:print({'queries_audited':len(query_checks),'seconds':time.perf_counter()-start},flush=True)
    case_checks=[]
    for s in expected_cases:
        allocations=[]
        for j,a in enumerate(s['surviving_allocations']):
            required=[('bracket',si) for si in [0,1] if a['brackets_per_sheet'][si]]+[(f'restored{k}',a['restored_sheets'][k]) for k in [0,1]]
            missing=[{'role':role,'sheet':sheet} for role,sheet in required if not any(not covers[qi].is_empty for qi in s['queries'] if expected[qi]['role']==role and expected[qi]['sheet']==sheet)]
            allocations.append({'prior_allocation':j,'allocation':a,'excluded_by_empty_role':bool(missing),'empty_roles':missing})
        case_checks.append({'case':s['case'],'released_items':s['released_items'],'families':s['families'],
                            'excluded':all(a['excluded_by_empty_role'] for a in allocations),'allocations':allocations})
    assert case_checks==load(BASE/'case-availability.json')
    selected=[]
    for p in load(PRIOR/'solve/positions.json')['movable_parts']:
        qi=next(q['index'] for q in expected if q['case']==p['case'] and q['prior_query']==p['query'])
        admitted=covers[qi].covers(Point(p['x_units']/100,p['y_units']/100))
        selected.append({'part':p['part'],'query':qi,'role':p['role'],'admitted_by_outward_cover':admitted})
    assert not next(r['admitted_by_outward_cover'] for r in selected if r['part']==3)
    write(OUT/'query-checks.json',query_checks);write(OUT/'case-checks.json',case_checks)
    write(OUT/'surviving-neighborhoods.json',[r for r in case_checks if not r['excluded']]);write(OUT/'selected-anchor-checks.json',selected)
    checks={'passed':True,'seconds':time.perf_counter()-start,'complete_queries':len(query_checks),'complete_cases':len(case_checks),
            'previously_completed_query_bytes_preserved':1262,'newly_completed_queries':1388,
            'whole_prior_integer_cells_covered':cells_checked,'lower_dimensional_prior_cells_preserved':lower_cells,
            'raw_free_primitives_covered':raw_primitives,'independently_reconstructed_free_primitives_covered':independent_primitives,
            'all_whole_cells_covered_by_outward_cover_or_strict_collision_exclusions':True,
            'outward_padding_parameter_mm':.001,'maximum_extra_outer_area_mm2':max_added_area,
            'empty_status_changes':empty_changes,'released_source_pose_memberships':source_pose_checks,
            'empty_queries':sum(r['empty'] for r in query_checks),'cases_excluded':sum(r['excluded'] for r in case_checks),
            'surviving_cases':sum(not r['excluded'] for r in case_checks),
            'surviving_allocations':sum(not a['excluded_by_empty_role'] for r in case_checks for a in r['allocations']),
            'selected_anchor_rejections':sum(not r['admitted_by_outward_cover'] for r in selected),
            'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'checks.json',checks);print(checks,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
