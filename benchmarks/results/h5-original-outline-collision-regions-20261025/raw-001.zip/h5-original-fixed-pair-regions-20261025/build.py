"""Complete stronger free-region census, preserving lower-dimensional grid cells."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import json,shutil,time,traceback
from shapely.geometry import Point,LineString,box,shape,mapping,GeometryCollection
from shapely.affinity import translate
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1]
GEO=ROOT/'output/h5-original-fixed-collision-geometry-20261025'
PRIOR=ROOT/'output/h5-pair-core-relocation-regions-20261025'
SRC=ROOT/'output/h5-source-orientation-construction-20261025'
OUT=ROOT/'output/h5-original-fixed-pair-regions-20261025'
load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')

def cell_geometry(cell):
    a,b,c,d=[v/100 for v in cell]
    if a==c and b==d:return Point(a,b)
    if a==c or b==d:return LineString([(a,b),(c,d)])
    return box(a,b,c,d)

def count_vertices(g):
    if g.is_empty:return 0
    if g.geom_type=='Polygon':return len(g.exterior.coords)+sum(len(r.coords) for r in g.interiors)
    if hasattr(g,'geoms'):return sum(count_vertices(p) for p in g.geoms)
    return len(g.coords)

def main():
    assert load(GEO/'audit/checks.json')['passed'];OUT.mkdir();(OUT/'queries').mkdir();shutil.copyfile(__file__,OUT/'build.py')
    survivors=load(PRIOR/'audit/surviving-neighborhoods.json');cases={s['case']:load(PRIOR/'cases'/f"{s['case']:03d}.json") for s in survivors}
    fixed=load(GEO/'fixed-originals.json');moving=load(GEO/'moving-proxies.json');byclass={m['class']:m['index'] for m in moving}
    queries=[];case_specs=[]
    for s in survivors:
        ids=[]
        for row in cases[s['case']]['queries']:
            q=row['query'];role=q['role']
            allowed=any(a['brackets_per_sheet'][q['sheet']]>0 if role=='bracket' else a['restored_sheets'][int(role[-1])]==q['sheet'] for a in s['surviving_allocations'])
            if not allowed:continue
            index=len(queries);queries.append({'index':index,'case':s['case'],'prior_query':q['index'],'role':role,
               'family':q['family'],'mode':q['mode'],'class':q['class'],'sheet':q['sheet'],'moving_proxy':byclass[q['class']]});ids.append(index)
        case_specs.append({**s,'queries':ids})
    inputs=[GEO/n for n in ['plan.json','generation.json','audit/checks.json','moving-proxies.json','fixed-originals.json','fixed-styles.json']]
    inputs += [PRIOR/n for n in ['audit/checks.json','audit/surviving-neighborhoods.json','solve/positions.json']]
    inputs += [SRC/'hint-poses.json']
    write(OUT/'plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},
          'prior_case_hashes':{str(k):digest(PRIOR/'cases'/f'{k:03d}.json') for k in cases},
          'obstacle_hashes':{p.name:digest(p) for p in sorted((GEO/'obstacles').glob('*.json'))},
          'construction_limit_seconds':120,'maximum_total_output_vertices':1000000,'cases':case_specs,'queries':queries,
          'required_original_counts':{'frame':18,'bracket':12,'insert':21,'cog':15},'fixed_parts_per_case':62,'mandatory_movable_parts':4,
          'method':'Use every role/mode sheet appearing in all424 surviving allocations of all229 prior cases. Form the continuous closed union of every prior exact integer free cell, retaining point/line cells explicitly. Subtract only the independently verified strict-interior exclusion for every remaining fixed original on that sheet. The smaller cog disk-floor polygon and original fixed outlines give necessary collision geometry; positive original clearance remains omitted only in this diagnostic. Keep each whole resulting geometry, including lines/points, without sampling, triangulation, quantization or dropping components. Empty-role availability can exclude an allocation only after all its queries finish. Caps preserve pending queries and unfinished cases. This census is an outer relaxation, not an accepted layout or unrestricted packing result.'})
    start=time.perf_counter();local={(q['fixed_style'],q['moving_proxy']):shape(load(GEO/'obstacles'/f"{q['index']:03d}.json")['strict_interior_exclusion']) for q in load(GEO/'cache-plan.json')}
    absolute={(r['item'],mi):translate(local[(r['style'],mi)],*r['transform']['translation']) for r in fixed for mi in range(10)}
    results=[];vertices=0
    for q in queries:
        if time.perf_counter()-start>=120 or vertices>=1000000:break
        case=cases[q['case']];owners=case['case']['released_items'];old=case['queries'][q['prior_query']]
        cells=old['free_integer_cells'];cover=unary_union([cell_geometry(c) for c in cells]) if cells else GeometryCollection()
        fixed_ids=[r['item'] for r in fixed if r['sheet']==q['sheet'] and r['item'] not in owners]
        # This filter is only an exact intersection optimization, not a candidate cap.
        relevant=[i for i in fixed_ids if not cover.is_empty and absolute[(i,q['moving_proxy'])].intersects(cover)]
        obstacles=unary_union([absolute[(i,q['moving_proxy'])] for i in relevant]) if relevant else GeometryCollection()
        free=cover.difference(obstacles);assert cover.is_valid and free.is_valid
        assert free.difference(cover).is_empty
        n=count_vertices(free);vertices+=n
        write(OUT/'queries'/f"{q['index']:04d}.json",{'query':q,'remaining_fixed_items':fixed_ids,'intersecting_fixed_items':relevant,
              'prior_integer_cells':len(cells),'prior_lower_dimensional_cells':sum(c[0]==c[2] or c[1]==c[3] for c in cells),
              'prior_closed_cell_cover':mapping(cover),'strict_interior_forbidden_union':mapping(obstacles),'free_outer_region':mapping(free),
              'free_empty':free.is_empty,'free_geometry_type':free.geom_type,'free_area_mm2':free.area,'output_vertices':n})
        results.append({'query':q['index'],'case':q['case'],'role':q['role'],'sheet':q['sheet'],'empty':free.is_empty,
                        'area_mm2':free.area,'vertices':n})
        if len(results)%500==0:print({'queries_completed':len(results),'seconds':time.perf_counter()-start,'vertices':vertices},flush=True)
    pending=queries[len(results):];write(OUT/'pending.json',pending);byquery={r['query']:r for r in results};checks=[]
    for s in case_specs:
        if any(qi not in byquery for qi in s['queries']):continue
        availability={(role,si):any(not byquery[qi]['empty'] for qi in s['queries'] if byquery[qi]['role']==role and byquery[qi]['sheet']==si)
                      for role in ['bracket','restored0','restored1'] for si in [0,1]}
        allocations=[]
        for index,a in enumerate(s['surviving_allocations']):
            failures=[{'role':'bracket','sheet':si} for si in [0,1] if a['brackets_per_sheet'][si] and not availability[('bracket',si)]]
            failures += [{'role':f'restored{k}','sheet':a['restored_sheets'][k]} for k in [0,1] if not availability[(f'restored{k}',a['restored_sheets'][k])]]
            allocations.append({'prior_allocation':index,'allocation':a,'excluded_by_empty_role':bool(failures),'empty_roles':failures})
        checks.append({'case':s['case'],'released_items':s['released_items'],'families':s['families'],
                       'excluded':all(a['excluded_by_empty_role'] for a in allocations),'allocations':allocations})
    write(OUT/'case-availability.json',checks)
    result={'seconds':time.perf_counter()-start,'queries_planned':len(queries),'queries_completed':len(results),'queries_pending':len(pending),
            'cases_planned':229,'cases_completed':len(checks),'empty_queries':sum(r['empty'] for r in results),'nonempty_queries':sum(not r['empty'] for r in results),
            'output_vertices':vertices,'vertex_cap_reached':vertices>=1000000,'time_limit_reached':bool(pending) and time.perf_counter()-start>=120,
            'cases_excluded_by_empty_roles':sum(r['excluded'] for r in checks),'surviving_cases':sum(not r['excluded'] for r in checks),
            'surviving_allocations':sum(not a['excluded_by_empty_role'] for r in checks for a in r['allocations']),
            'independent_region_audit_pending':True,'solver_calls':0,'full_target_witness':False,'H5_complete':False}
    write(OUT/'query-summary.json',results);write(OUT/'result.json',result);print(result,flush=True)

if __name__=='__main__':
    try:main()
    except Exception:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8',newline='\n')
        raise
