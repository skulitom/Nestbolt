"""Verify the rejected periodic inventory and its size/equality accounting."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json,shutil,time
from shapely.geometry import shape,box
from shapely.affinity import translate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-capacity-20261028';OLD=ROOT/'output/h5-row-bracket-source-20261028';STUDY=ROOT/'output/h5-bracket-row-clearance-20261028';DATA=BASE/'periodic-inventory';OUT=DATA/'audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');started=time.perf_counter();plan=load(DATA/'plan.json');assert plan['pitch_um']==258900 and plan['remainder_bounds_um']==[0,258899]
for n,h in plan['inputs'].items():assert digest(ROOT/n)==h,n
totals={'types':0,'quotient_cases':0,'distinct_typed_groups':0,'exact_geometric_equal_cases':0,'exact_geometric_discrepancies':0,'projected_expanded_planes':0,'projected_expanded_cells':0};rows=[]
for path in sorted((DATA/'groups').glob('*.json')):
    saved=load(path);s=saved['summary'];original=load(OLD/'row-bracket'/path.name);assert s['row_mode']==original['row_mode'] and s['bracket_mode']==original['bracket_mode'];n=5 if s['row_mode']==12 else 4;a,_,b,_=shape(load(STUDY/'obstacles'/f"{s['bracket_mode']:02d}-cog-phase7.json")).bounds;lo,ylo,hi,yhi=original['relative_bounds_um'];expected=list(range(lo//258900,hi//258900+1));assert [c['quotient'] for c in s['cases']]==expected;seen=[]
    for g in saved['groups']:
        assert g['index']==saved['groups'].index(g) and g['quotients'];seen+=g['quotients'];region=shape(g['coded']['domain_geometry'])
        for q in g['quotients']:
            c=next(v for v in s['cases'] if v['quotient']==q);rlo,rhi=max(0,lo-q*258900),min(258899,hi-q*258900);assert c['group']==g['index'] and c['remainder_bounds_um']==g['remainder_bounds_um']==[rlo,rhi];indices=[j-q for j in range(n) if F(str(a))*1000+(j-q)*258900<=rhi and F(str(b))*1000+(j-q)*258900>=rlo];assert c['relative_cog_indices']==g['indices']==indices
            translated=translate(shape(original['domain_geometry']).intersection(box((q*258900+rlo)/1000,ylo/1000,(q*258900+rhi)/1000,yhi/1000)),xoff=-q*258900/1000);same=region.equals(translated);assert same==c['exact_domain_equal'] and region.symmetric_difference(translated).area==c['symmetric_difference_area_mm2'];totals['exact_geometric_equal_cases']+=int(same);totals['exact_geometric_discrepancies']+=int(not same)
    assert sorted(seen)==expected;cells=sum(len(g['coded']['cells']) for g in saved['groups']);planes=sum(len(c['halfplanes']) for g in saved['groups'] for c in g['coded']['cells']);assert (cells,planes,len(expected),len(saved['groups']))==(s['cells'],s['planes'],s['quotient_cases'],s['groups']);weight=10 if s['row_mode']==12 else 5;totals['types']+=1;totals['quotient_cases']+=len(expected);totals['distinct_typed_groups']+=len(saved['groups']);totals['projected_expanded_planes']+=weight*planes;totals['projected_expanded_cells']+=weight*cells;rows.append(s)
assert rows==load(DATA/'summary.json');r=load(DATA/'result.json');assert all(r[k]==v for k,v in totals.items()) and not r['passes_size_prefilter'] and totals['projected_expanded_planes']>28640 and not r['accepted_replacement'] and not r['integer_no_loss_proof_completed'] and not r['model_created'] and r['solver_calls']==0
inputs=[DATA/'plan.json',DATA/'result.json',DATA/'summary.json']+list((DATA/'groups').glob('*.json'));write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{'passed':True,'seconds':time.perf_counter()-started,**totals,'plane_count_increase_fraction':totals['projected_expanded_planes']/28640-1,'size_prefilter_failed':True,'equality_discrepancies_preserved':True,'replacement_geometry_or_integer_no_loss_not_certified':True,'selected':False,'model_created':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
