"""Generate fresh, hash-recorded runner/readback helpers; never modify closed helpers."""
from pathlib import Path
from hashlib import sha256
import json,shutil
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-capacity-20261028';OUT=BASE/'search-helper-generation';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
for folder in ['capacity-audit','model-audit','source-bridge-audit','row-identity-audit']:assert load(BASE/folder/'checks.json')['passed']
OUT.mkdir();shutil.copyfile(__file__,OUT/'prepare.py');records=[]
for oldname,newname in [('run_h5_row_bracket_model_20261028.py','run_h5_row_capacity_model_20261028.py'),('audit_h5_row_bracket_response_20261028.py','audit_h5_row_capacity_response_20261028.py')]:
    original=ROOT/'output'/oldname;source=original.read_text(encoding='utf-8');source=source.replace('output/h5-row-bracket-source-20261028','output/h5-row-bracket-capacity-20261028').replace('h5_row_bracket_cp_reader_20261028','h5_row_capacity_cp_reader_20261028').replace('check_h5_row_bracket_candidate_20261028','check_h5_row_capacity_candidate_20261028')
    source=source.replace("BASE/'geometry-audit']:","BASE/'geometry-audit',BASE/'capacity-audit']:")
    source=source.replace("inputs=[BASE/'geometry-audit/plan.json'","inputs=[BASE/'capacity-audit/plan.json',BASE/'capacity-audit/checks.json',BASE/'mode-contained-rectangles.json',BASE/'geometry-audit/plan.json'")
    if oldname.startswith('run_'):
        source=source.replace("ma=load(BASE/'model-audit/checks.json');assert ma['passed']","ma=load(BASE/'model-audit/checks.json');assert load(BASE/'capacity-audit/checks.json')['passed'] and ma['passed']")
    else:
        line=next(l for l in source.splitlines() if l.startswith('p=cp_model_pb2.CpModelProto();'))
        replacement="p=cp_model_pb2.CpModelProto();p.ParseFromString((SEARCH/'model.pb').read_bytes());mp=load(MODEL/'mapping.json');oldbase=ROOT/'output/h5-row-bracket-source-20261028';old=cp_model_pb2.CpModelProto();old.ParseFromString((oldbase/'model/model.pb').read_bytes());model_check=inspect(p,mp,old,load(oldbase/'model/mapping.json'),load(BASE/'mode-contained-rectangles.json'));write(OUT/'model-recheck.json',model_check)"
        source=source.replace(line,replacement)
        source=source.replace("'row_bracket_owner_pairs':15,'row_bracket_mode_cases':120,","'row_bracket_owner_pairs':15,'row_bracket_mode_cases':120,'source_capacity_components':1438,'source_capacity_constraints':2878,'prior_model_fields_preserved':True,")
    target=ROOT/'output'/newname
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
    compile(source,str(target),'exec');records.append({'source':original.relative_to(ROOT).as_posix(),'source_sha256':digest(original),'generated':target.relative_to(ROOT).as_posix(),'generated_sha256':digest(target)})
with (OUT/'generation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(records,f,indent=2);f.write('\n')
print({'helpers_prepared':len(records),'solver_calls':0})
