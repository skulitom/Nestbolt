"""Add only proved necessary source capacities to the unchanged precise model."""
from pathlib import Path
from hashlib import sha256
import json,shutil,time
from google.protobuf import text_format
from ortools.sat import cp_model_pb2
from ortools.sat.python import cp_model
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-capacity-20261028';OLD=ROOT/'output/h5-row-bracket-source-20261028';OUT=BASE/'model';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(BASE/'capacity-audit/checks.json')['passed'] and load(BASE/'geometry-audit/checks.json')['passed']
for folder in [BASE,BASE/'capacity-audit',BASE/'geometry-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
OUT.mkdir();shutil.copyfile(__file__,OUT/'build.py');started=time.perf_counter();old=cp_model_pb2.CpModelProto();old.ParseFromString((OLD/'model/model.pb').read_bytes());model=cp_model.CpModel();assert model.proto.parse_text_format(text_format.MessageToString(old));mp=load(OLD/'model/mapping.json');rects=load(BASE/'mode-contained-rectangles.json');records=[];xs=[];ys=[];widths=[];heights=[]
for item in mp['items']:
    x=model.get_int_var_from_proto_index(item['x']);y=model.get_int_var_from_proto_index(item['y'])
    for option in item['options']:
        mi=option['mode'];selector=model.get_int_var_from_proto_index(option['selector']);components=[]
        for k,r in enumerate(rects[mi]['components']):
            a,b,c,d=r['rectangle_um'];ix=model.new_optional_fixed_size_interval_var(x+a,c-a,selector,f'inner_x_{item["index"]}_{mi}_{k}');iy=model.new_optional_fixed_size_interval_var(y+b,d-b,selector,f'inner_y_{item["index"]}_{mi}_{k}');xs.append(ix);ys.append(iy);widths.append(c-a);heights.append(d-b);components.append({'component':k,'source_instance':r['source_instance'],'x_interval':ix.index,'y_interval':iy.index})
        records.append({'block':item['index'],'mode':mi,'selector':option['selector'],'components':components})
xc=model.add_cumulative(xs,heights,2987000).index;yc=model.add_cumulative(ys,widths,1487000).index;mp.update({'capacity_base_variable_count':len(old.variables),'capacity_base_constraint_count':len(old.constraints),'source_capacities':records,'source_x_cumulative':xc,'source_y_cumulative':yc})
assert len(model.proto.variables)==len(old.variables)==7932 and len(model.proto.constraints)==len(old.constraints)+2878==35015 and len(xs)==1438 and model.validate()==''
assert model.export_to_file(str(OUT/'model.pb')) and model.export_to_file(str(OUT/'model.pbtxt'));write(OUT/'mapping.json',mp)
for name in ['partial-hints.json','partial-control-assignment.json','negative-assignment.json']:shutil.copyfile(OLD/'model'/name,OUT/name)
inputs=[BASE/n for n in ['plan.json','geometry-audit/plan.json','geometry-audit/checks.json','capacity-audit/plan.json','capacity-audit/checks.json','mode-contained-rectangles.json']]+[OLD/n for n in ['model/model.pb','model/mapping.json','model/plan.json','model-audit/plan.json','model-audit/checks.json']]
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'solver_calls':0});write(OUT/'built.json',{'seconds':time.perf_counter()-started,'variables':len(model.proto.variables),'constraints':len(model.proto.constraints),'old_variables':len(old.variables),'old_constraints':len(old.constraints),'added_intervals':2876,'added_global_cumulatives':2,'extra_variables':0,'mandatory_blocks':43,'first_sheet_originals':54,'fixed_short_originals':12,'target_originals':66,'optional_source_components':len(xs),'model_sha256':digest(OUT/'model.pb'),'mapping_sha256':digest(OUT/'mapping.json'),'solver_calls':0,'H5_complete':False});print(load(OUT/'built.json'))
