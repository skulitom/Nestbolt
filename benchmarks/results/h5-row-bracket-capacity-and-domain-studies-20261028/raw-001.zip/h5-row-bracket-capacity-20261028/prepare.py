"""Freeze a fresh necessary-capacity construction; all previous calls stay closed."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,shutil
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'output/h5-row-bracket-source-20261028';BASE=ROOT/'output/h5-row-bracket-capacity-20261028';CAP=OLD/'capacity-preflight';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(OLD/'search/result.json')['closed'] and load(OLD/'response-audit/checks.json')['passed'] and load(CAP/'audit/checks.json')['passed']
BASE.mkdir();shutil.copyfile(__file__,BASE/'prepare.py');inputs=[]
for n in ['modes.json','blocks43.json','short12.json','control.json','negative.json','control-source52.json','negative-source66.json']:
    shutil.copyfile(OLD/n,BASE/n);inputs.append(OLD/n)
for folder in ['relative','row-bracket']:
    (BASE/folder).mkdir()
    for p in (OLD/folder).glob('*.json'):shutil.copyfile(p,BASE/folder/p.name);inputs.append(p)
shutil.copyfile(CAP/'mode-contained-rectangles.json',BASE/'mode-contained-rectangles.json');inputs.append(CAP/'mode-contained-rectangles.json')
inputs += [OLD/n for n in ['plan.json','model/plan.json','model/model.pb','model/mapping.json','model/partial-hints.json','model/partial-control-assignment.json','model/negative-assignment.json','model-audit/plan.json','model-audit/checks.json','geometry-audit/plan.json','geometry-audit/checks.json','response-audit/plan.json','response-audit/checks.json','search/result.json']]+[CAP/n for n in ['plan.json','audit/plan.json','audit/checks.json','audit/necessity-proof.json']]
plan=load(OLD/'plan.json');plan.update({'utc':datetime.now(timezone.utc).isoformat(),'method':'Fresh necessary-capacity strengthening of the closed precise row/bracket model. Preserve every existing variable, constraint and hint byte-for-byte. Add only1438 source-contained optional rectangles as2876 intervals and2 global cumulatives using the original mode selectors and1487000um width/2987000um height stock capacities. No extra clearance or false occupied area is added. Full source containment, all9 positive controls, negative66, all66 identities and the complete model chain must pass before one frozen60/90second search. No closed call may be restarted, reseeded or extended.','inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs},'capacity_width_um':1487000,'capacity_height_um':2987000,'capacity_optional_components':1438,'capacity_extra_variables':0,'capacity_interval_constraints':2876,'capacity_cumulative_constraints':2,'independently_movable_first_sheet_blocks':43,'target_originals':66,'fixed_short_originals':12,'source_capacity_proof_required':True})
write(BASE/'plan.json',plan)
audit=BASE/'geometry-audit';audit.mkdir();unchanged=[]
for folder in ['relative','row-bracket']:
    for p in (BASE/folder).glob('*.json'):assert digest(p)==digest(OLD/folder/p.name);unchanged.append(p)
for name in ['modes.json','blocks43.json','short12.json']:assert digest(BASE/name)==digest(OLD/name);unchanged.append(BASE/name)
assert digest(BASE/'mode-contained-rectangles.json')==digest(CAP/'mode-contained-rectangles.json');unchanged.append(BASE/'mode-contained-rectangles.json')
write(audit/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in unchanged+[BASE/'plan.json',OLD/'geometry-audit/plan.json',OLD/'geometry-audit/checks.json',CAP/'audit/plan.json',CAP/'audit/checks.json']}})
write(audit/'checks.json',{'passed':True,'method':'Byte-identical reuse of all independently audited source modes, relative domains, source-contained rectangles and short-sheet geometry; no geometry recomputation claimed. Fresh capacity containment audit required separately.','unchanged_files':len(unchanged),'solver_calls':0,'H5_complete':False})
generated=[]
for original,new in [('audit_h5_row_bracket_source_bridge_20261028.py','audit_h5_row_capacity_source_bridge_20261028.py'),('audit_h5_row_bracket_row_identities_20261028.py','audit_h5_row_capacity_row_identities_20261028.py'),('check_h5_row_bracket_candidate_20261028.py','check_h5_row_capacity_candidate_20261028.py'),('audit_h5_row_bracket_capacity_20261028.py','audit_h5_row_capacity_containment_20261028.py')]:
    p=ROOT/'output'/original;source=p.read_text(encoding='utf-8');source=source.replace('output/h5-row-bracket-source-20261028','output/h5-row-bracket-capacity-20261028')
    if 'capacity_20261028' in original:
        source=source.replace("DATA=BASE/'capacity-preflight';OUT=DATA/'audit'","DATA=ROOT/'output/h5-row-bracket-source-20261028/capacity-preflight';OUT=BASE/'capacity-audit'")
    target=ROOT/'output'/new
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
    generated.append({'source':p.relative_to(ROOT).as_posix(),'source_sha256':digest(p),'generated':target.relative_to(ROOT).as_posix(),'generated_sha256':digest(target)})
write(BASE/'helper-generation.json',generated);print({'prepared':str(BASE),'source_files_unchanged':len(unchanged),'fresh_auxiliary_audits':len(generated),'solver_calls':0})
