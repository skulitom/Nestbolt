"""Recheck all ancestor fields, the necessary delta and every saved control."""
from pathlib import Path
from hashlib import sha256
from itertools import product
import json,shutil,time
from ortools.sat import cp_model_pb2
from h5_transfer43_cp_reader_20261028 import inspect as inspect_original
from h5_hybrid43_cp_reader_20261028 import inspect as inspect_hybrid
from h5_row_bracket_cp_reader_20261028 import inspect as inspect_precise
from h5_row_capacity_cp_reader_20261028 import inspect,control_values,violations
from h5_rectangle_cp_evaluator_20261028 import evaluate
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'output/h5-row-bracket-capacity-20261028';OLD=ROOT/'output/h5-row-bracket-source-20261028';HYBRID=ROOT/'output/h5-hybrid43-guarded-source-20261028';ORIGINAL=ROOT/'output/h5-transfer43-source-20261028';STUDY=ROOT/'output/h5-bracket-row-clearance-20261028';CAP=OLD/'capacity-preflight';MODEL=BASE/'model';OUT=BASE/'model-audit';load=lambda p:json.loads(p.read_bytes());digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def proto(path):
    p=cp_model_pb2.CpModelProto();p.ParseFromString(path.read_bytes());return p
def saved(base,name):return load(base/'model'/name)
OUT.mkdir();shutil.copyfile(__file__,OUT/'audit.py');start=time.perf_counter()
for folder in [BASE,BASE/'geometry-audit',BASE/'capacity-audit',MODEL,OLD/'model-audit',HYBRID/'model-audit',ORIGINAL/'model-audit']:
    for n,h in load(folder/'plan.json')['inputs'].items():assert digest(ROOT/n)==h,n
relative={k:load(BASE/'relative'/f'{k}.json') for k in ['5-5','5-4']};typed={(ri,mi):load(BASE/'row-bracket'/f'{ri:02d}-{mi:02d}.json') for ri,mi in product([12,13],range(2,10))}
original=proto(ORIGINAL/'model/model.pb');omp=saved(ORIGINAL,'mapping.json');result,_=inspect_original(original,omp,load(ORIGINAL/'blocks43.json'),load(ORIGINAL/'modes.json'),load(ORIGINAL/'control.json'),load(ORIGINAL/'negative.json'),saved(ORIGINAL,'partial-hints.json'),saved(ORIGINAL,'partial-control-assignment.json'),saved(ORIGINAL,'negative-assignment.json'));write(OUT/'original-model-recheck.json',result)
hybrid=proto(HYBRID/'model/model.pb');hmp=saved(HYBRID,'mapping.json');result,_=inspect_hybrid(hybrid,hmp,original,omp,load(HYBRID/'modes.json'),relative,load(HYBRID/'control.json'),load(HYBRID/'negative.json'),saved(HYBRID,'partial-hints.json'),saved(HYBRID,'partial-control-assignment.json'),saved(HYBRID,'negative-assignment.json'));write(OUT/'hybrid-model-recheck.json',result)
old=proto(OLD/'model/model.pb');oldmp=saved(OLD,'mapping.json');result,disabled=inspect_precise(old,oldmp,hybrid,hmp,load(OLD/'modes.json'),relative,typed,load(OLD/'control.json'),load(OLD/'negative.json'),saved(OLD,'partial-hints.json'),saved(OLD,'partial-control-assignment.json'),saved(OLD,'negative-assignment.json'));write(OUT/'precise-model-recheck.json',result)
p=proto(MODEL/'model.pb');mp=load(MODEL/'mapping.json');checked=inspect(p,mp,old,oldmp,load(BASE/'mode-contained-rectangles.json'));built=load(MODEL/'built.json');assert digest(MODEL/'model.pb')==built['model_sha256'] and digest(MODEL/'mapping.json')==built['mapping_sha256']
for n in ['partial-hints.json','partial-control-assignment.json','negative-assignment.json']:assert (MODEL/n).read_bytes()==(OLD/'model'/n).read_bytes()
def partial_check(values,absent):
    copy=cp_model_pb2.CpModelProto();copy.CopyFrom(p)
    for ix in absent:copy.constraints[ix].linear.domain[:]=[0,0]
    checked=evaluate(copy,values,0);assert not violations(copy,values)['failed_constraints']
    for ix in absent:copy.constraints[ix].linear.domain[:]=[1,1]
    assert copy.SerializeToString()==p.SerializeToString();return checked
def sweeps(values):
    result=[]
    def ev(e):return e.offset+sum(v*values[k] for k,v in zip(e.vars,e.coeffs))
    for axis,key in [(0,'source_x_cumulative'),(1,'source_y_cumulative')]:
        ct=p.constraints[mp[key]].cumulative;events={}
        for ix,d in zip(ct.intervals,ct.demands):
            interval=p.constraints[ix]
            if not all(values[k] for k in interval.enforcement_literal):continue
            a,b,amount=ev(interval.interval.start),ev(interval.interval.end),ev(d);events[a]=events.get(a,0)+amount;events[b]=events.get(b,0)-amount
        current=maximum=0;states=[]
        for where,delta in sorted(events.items()):current+=delta;maximum=max(maximum,current);states.append([where,current])
        assert current==0;capacity=ev(ct.capacity);result.append({'axis':axis,'capacity_um':capacity,'maximum_demand_um':maximum,'slack_um':capacity-maximum,'events':states})
    return result
cases=[('source52',load(BASE/'control.json'),True)]+[(f"source62-mode{w['mode']}",load(HYBRID/'control.json')+[w['pose']],True) for w in load(STUDY/'witness-summary.json')]+[('negative66',load(BASE/'negative.json'),False)];records=[]
for name,poses,valid in cases:
    values=control_values(p,mp,relative,typed,poses);known={r['block'] for r in poses};absent=[r['mandatory'] for r in mp['items'] if r['index'] not in known];fail=violations(p,values);capacity=sweeps(values);assert capacity==load(CAP/(name+'-sweeps.json'))
    if valid:
        assert fail['failed_constraints']==[{'constraint':ix,'kind':'linear'} for ix in absent] and not fail['cover_collisions'];evaluation=partial_check(values,absent);assert evaluation['expanded_pairs']==(102184 if name=='source52' else 112002) and all(s['slack_um']>=0 for s in capacity)
    else:
        oldfail=violations(old,values);expected={r['constraint'] for r in oldfail['failed_constraints']}|{mp['source_x_cumulative'],mp['source_y_cumulative']};assert len(expected)==32 and {r['constraint'] for r in fail['failed_constraints']}==expected and all(s['slack_um']<0 for s in capacity);evaluation=None
    if name=='source52':assert values==load(MODEL/'partial-control-assignment.json') and absent==disabled and len(absent)==14
    elif valid:assert len(absent)==4
    else:assert values==load(MODEL/'negative-assignment.json') and not absent
    records.append({'name':name,'partial_control_valid':valid,'absent_mandatory':len(absent),'failed_constraints':fail['failed_constraints'],'cover_pairs_checked':fail['cover_pairs_checked'],'cover_collisions':fail['cover_collisions'],'capacity_slack_um':[v['slack_um'] for v in capacity],'all_capacity_events_match_independent_geometric_preflight':True,'evaluation':evaluation})
write(OUT/'control-checks.json',records)
inputs=[BASE/n for n in ['plan.json','geometry-audit/plan.json','geometry-audit/checks.json','capacity-audit/plan.json','capacity-audit/checks.json','mode-contained-rectangles.json','modes.json','blocks43.json','control.json','negative.json']]+[MODEL/n for n in ['plan.json','model.pb','mapping.json','partial-hints.json','partial-control-assignment.json','negative-assignment.json']]+[OLD/n for n in ['model/plan.json','model/model.pb','model/mapping.json','model-audit/plan.json','model-audit/checks.json']]+[ROOT/'output/h5_row_capacity_cp_reader_20261028.py',ROOT/'output/h5_rectangle_cp_evaluator_20261028.py',STUDY/'witness-summary.json',CAP/'plan.json',CAP/'audit/plan.json',CAP/'audit/checks.json']
write(OUT/'plan.json',{'inputs':{p.relative_to(ROOT).as_posix():digest(p) for p in inputs}});write(OUT/'checks.json',{**checked,'seconds':time.perf_counter()-start,'all3_ancestor_models_fully_reverified':True,'all903_block_pairs_preserved':True,'primary_control_rejects_only14_missing_parts':True,'all8_source62_controls_reject_only4_missing_parts':True,'negative66_rejected_by32_constraints':True,'all10_capacity_sweeps_match_geometric_preflight':True,'model_sha256':digest(MODEL/'model.pb'),'mapping_sha256':digest(MODEL/'mapping.json'),'source_full66_verified':False,'solver_calls':0,'native_calls':0,'H5_complete':False});print(load(OUT/'checks.json'))
